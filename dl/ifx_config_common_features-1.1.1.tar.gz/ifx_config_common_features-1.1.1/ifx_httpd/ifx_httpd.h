#ifndef	__IFX_WEB_SUPPORT
#define	__IFX_WEB_SUPPORT

#define IFX_COMMENT_BEG "<!--"
#define IFX_COMMENT_END "-->"
#define IFX_TOKEN_BEG 	"<%"
#define IFX_TOKEN_END	"%>"

// Length of command between <% %>
#define IFX_COMMAND_LENGTH 500
// Length of the name of get/set function
#define IFX_FUN_NAME_LENGTH 100 
// 
#define IFX_MAX_NO_ARG 10
#define IFX_ARG_LEN 100
#define IFX_DATA_BUFF (1024*32)
#define IFX_MAX_DOWNLOAD_SIZE ((1024*1024*CONFIG_IFX_CONFIG_FLASH_SIZE) - (64*1024))
#define IFX_MIN_DOWNLOAD_SIZE (1024*500)
#define IFX_TEMP_BUFF 128
#define IFX_REDIRECT_URL_LEN	128
#define IFX_HOST_NAME_LEN 	256
#define IFX_PARA_NAME_LEN	128
#define IFX_PARA_VAL_LEN	128

#define MALLOC_BUF_SIZE	IFX_DATA_BUFF

#define FORWARD	1
#define BACKWARD 0

typedef struct multi_buf {
	char *buf;
	int  len;
}T_MULTI_BUF;

struct ifx_arg_list
{
	char *pifx_param_name;
	int	numMultiBufs;
	union param_value{
		char *buf;
		T_MULTI_BUF *pArrMultiBuf;
	}ifx_param_value;
	int totBufLen;
    struct ifx_arg_list *next;
};

struct ifx_wp
{
  int ifx_no_argument;
  struct ifx_arg_list * ifx_ptr_arg_list;
  char ipaddr[32];
#if 0
  int multiDatalen;
  char multiData[256];
#endif
  char host[IFX_HOST_NAME_LEN];
  int ifxReadFd;
  int ifxWriteFd;
  int bSendHeader;
  char *pBoundary;
};

typedef struct ifx_wp *httpd_t;
typedef struct ifx_wp httpdType;

#endif
