
// 510251:sumedh Support for DoS Attacks, ALGs, QoS, Policy based Routing

#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>		/* open */
#include <sys/ioctl.h>		/* ioctl */
#include <stdlib.h>		/*atoi */
#include <string.h>

/* device specifics, such as ioctl numbers and the 
 * major device file. */
#include <ifx_common.h>
#include "ifx_alg.h"

#if 0
#define NPRINTF(format,args...) printf(format,##args)
#else
#define NPRINTF(format,args...)
#endif

struct alg_info *alg_list_head = NULL;
char command[500] = { '\0' };

#define ENABLE 		1
#define DISABLE 	2

//#define system(str)   0

struct nf_alg_map {
	char alg_name[100];
	int alg_proto;
};

//510251:sumedh (modified to add rtsp, netmeeting, ipsec, ftp, pptp)
struct nf_alg_map nf_alg_array[] = {
	{"rtsp", PROTO_RTSP},
	{"netmeeting", PROTO_NETMEETING},
	{"ipsec", PROTO_IPSEC},
	{"pptp", PROTO_PPTP},
	{"ftp", PROTO_FTP},
	{"sip", PROTO_SIP}
};

#define ALG_NODES_FILE	"/var/nfappinfo"
#define COPY_ITF(dest,src) ((src != NULL)?(strcpy((dest), (src))):strcpy((dest),""))
#define COMP_ITF(dest,src) ((src)?strcmp((dest),(src)):((dest)[0] != '\0'))

int ifx_open_device(char *dev_name);
int ifx_ioctl(int dev_file, int request, void *param);
int ifx_add_node(int protocol_name, int ip_protocol, int port,
		 char *lan_itf_name, char *wan_itf_name, int flag,
		 int dump_flag);

static int write_alg_nodes_file(void)
{
	FILE *fp = NULL;
	struct alg_info *pnode;

	fp = fopen(ALG_NODES_FILE, "wb");
	if (!fp)
		return -1;

	for (pnode = alg_list_head; (pnode); pnode = pnode->next) {
		/* Write node info to file */
		if (fwrite(pnode, sizeof(*pnode), 1, fp) == 0) {
			break;
		}
	}
	fclose(fp);
	return 0;
}

static int read_alg_nodes_file(void)
{
	FILE *fp = NULL;
	struct alg_info node;

	fp = fopen(ALG_NODES_FILE, "rb");
	if (!fp)
		return -1;
	while (!feof(fp)) {
		if (fread(&node, sizeof(node), 1, fp) <= 0) {
			break;
		}
		NPRINTF
		    ("ALG <%s>, Transport <%s>, Port<%d>, Lan<%s>, Wan<%s>, NAT<%s>\n",
		     node.protocol_name == 1 ? "RTSP" : node.protocol_name ==
		     2 ? "SIP" : "UNKNOWN",
		     node.ip_protocol == 1 ? "tcp" : node.ip_protocol ==
		     2 ? "udp" : "UNKNOWN", node.port, node.lanitf, node.wanitf,
		     node.nat_flag == 1 ? "enabled" : node.nat_flag ==
		     2 ? "disabled" : node.nat_flag ==
		     0 ? "don't care" : "unknown");
		ifx_add_node(node.protocol_name, node.ip_protocol, node.port,
			     node.lanitf, node.wanitf, node.nat_flag, 0);
	}
	fclose(fp);

	return (0);
}

int ifx_alg_app_init(int first_init)
{
	if (first_init == 1) {
		remove(ALG_NODES_FILE);
	} else {
		read_alg_nodes_file();
	}
	return 0;
}

int ifx_set_init_rules_for_conntrack(char *lan_itf_name, char *wan_itf_name,
				     char flag, int bidir)
{
	int ret = 0;
	char rule = 0;
	char lanifstr[20] = " ";
	char wanifstr[20] = " ";
	char laniffmt[3] = "";
	char waniffmt[3] = "";

	if (flag == ADD_RULE)
		rule = 'A';
	if (flag == DELETE_RULE)
		rule = 'D';

	if (wan_itf_name) {
		sprintf(lanifstr, "%s", wan_itf_name);
		strcpy(laniffmt, "-i");
	}
	if (lan_itf_name) {
		sprintf(wanifstr, "%s", lan_itf_name);
		strcpy(waniffmt, "-o");
	}

	sprintf(command, "iptables -%c FORWARD %s %s %s %s -m state "
		"--state ESTABLISHED,RELATED -j ACCEPT",
		rule, waniffmt, wanifstr, laniffmt, lanifstr);
	NPRINTF("\n Now Command is %s\n", command);
	ret = ifx_run_command(command);
	if (ret == 0 && bidir) {
		char tmpfmt[3];
		strcpy(tmpfmt, laniffmt);
		if (waniffmt[0] != '\0') {
			strcpy(laniffmt, "-i");
		} else {
			laniffmt[0] = '\0';
		}
		if (tmpfmt[0] != '\0') {
			strcpy(waniffmt, "-o");
		} else {
			waniffmt[0] = '\0';
		}

		sprintf(command,
			"iptables -%c FORWARD %s %s %s %s -m state --state ESTABLISHED,"
			"RELATED -j ACCEPT", rule, waniffmt, lanifstr, laniffmt,
			wanifstr);
		NPRINTF("\n Now Command is %s\n", command);
		ret = ifx_run_command(command);
	}

	NPRINTF("ifx_run_command [%s] returned [%d]!\n", command, ret);

	return (ret);

}

//////////////////////////////////////////////////////////////////////////
//510251: sumedh (Function to add iptables rules for algs)
int ifx_set_alg_rules(int table, int trans_proto, int portid, char *ports,
		      char *state, char flag)
{
	int ret = 0;
	char rule = 0, protocol[10];
	char portstr[50] = " ";
	char statestr[60] = "";
	char chainstr[40] = " ";

	if (flag == ADD_RULE)
		rule = 'A';
	if (flag == DELETE_RULE)
		rule = 'D';

	if (portid > 0) {
		if (portid == BOTH_PORTS) {
			strcpy(portstr, "--dport ");
			strcat(portstr, ports);
			strcat(portstr, " --sport ");
			strcat(portstr, ports);
		} else {
			strcpy(portstr, "-m multiport ");
			if (portid == SRC_PORTS) {
				strcat(portstr, "--sports ");
				strcat(portstr, ports);
			} else if (portid == DST_PORTS) {
				strcat(portstr, "--dports ");
				strcat(portstr, ports);
			}
		}

	}
	if (table == FORWARD)
		strcpy(chainstr, ALG_FORWARD_CHAIN);
	else if (table == INPUT)
		strcpy(chainstr, ALG_INPUT_CHAIN);
	else if (table == OUTPUT)
		strcpy(chainstr, ALG_OUTPUT_CHAIN);
	else if (table == NAT) {
		strcpy(chainstr, ALG_NAT_CHAIN);
		strcat(chainstr, " -t nat ");
	}

	if (trans_proto == IP_PROTO_TCP)
		strcpy(protocol, "tcp");
	else if (trans_proto == IP_PROTO_UDP)
		strcpy(protocol, "udp");
	else if (trans_proto == IP_PROTO_TCP_UDP)
		strcpy(protocol, "tcp");	/* start with tcp then add udp also */
	else if (trans_proto == IP_PROTO_ESP)
		strcpy(protocol, "50");
	else if (trans_proto == IP_PROTO_AH)
		strcpy(protocol, "51");
	else if (trans_proto == IP_PROTO_GRE)
		strcpy(protocol, "47");

	if (strlen(state)) {
		strcpy(statestr, "-m state --state ");
		strcat(statestr, state);
	}

      lbl_doagain:

	sprintf(command, "iptables -%c %s -p %s %s %s -j ACCEPT", rule,
		chainstr, protocol, portstr, statestr);

	NPRINTF("\n Now Command is %s\n", command);
	ret = ifx_run_command(command);
	if (ret == SUCCESS) {
		if (trans_proto == IP_PROTO_TCP_UDP) {
			trans_proto = IP_PROTO_UDP;
			strcpy(protocol, "udp");
			goto lbl_doagain;
		}
	}
	return (ret);
}

//510251:sumedh end
//////////////////////////////////////////////////////////////////////////

/*  Set rules on Nat machine */
int ifx_set_rules(char *lan_itf_name, char *wan_itf_name, int trans_proto,
		  int port, char flag, int bidir)
{
	int ret = 0;
	int orig_trans_proto;
	char rule = 0, protocol[10];
	char lanifstr[20] = " ";
	char wanifstr[20] = " ";
	char laniffmt[3] = "";
	char waniffmt[3] = "";

	orig_trans_proto = trans_proto;

	if (flag == ADD_RULE)
		rule = 'A';
	if (flag == DELETE_RULE)
		rule = 'D';

	if (lan_itf_name) {
		sprintf(lanifstr, "%s", lan_itf_name);
		strcpy(laniffmt, "-i");
	}
	if (wan_itf_name) {
		sprintf(wanifstr, "%s", wan_itf_name);
		strcpy(waniffmt, "-o");
	}

      lbl_bidir:
	if (trans_proto == IP_PROTO_TCP)
		strcpy(protocol, "tcp");
	else if (trans_proto == IP_PROTO_UDP)
		strcpy(protocol, "udp");
	else if (trans_proto == IP_PROTO_TCP_UDP)
		strcpy(protocol, "tcp");	/* start with tcp then add udp also */

      lbl_doagain:

	sprintf(command,
		"iptables -%c FORWARD %s %s %s %s -p %s --dport %d -j ACCEPT",
		rule, laniffmt, lanifstr, waniffmt, wanifstr, protocol, port);

	NPRINTF("\n Now Command is %s\n", command);
	ret = ifx_run_command(command);
	if (ret == SUCCESS) {
		if (trans_proto == IP_PROTO_TCP_UDP) {
			trans_proto = IP_PROTO_UDP;
			strcpy(protocol, "udp");
			goto lbl_doagain;
		}
		if (bidir) {
			char tmp[20];
			char tmpfmt[3];
			bidir = 0;
			trans_proto = orig_trans_proto;
			strcpy(tmp, lanifstr);
			strcpy(tmpfmt, laniffmt);
			strcpy(lanifstr, wanifstr);
			strcpy(wanifstr, tmp);
			if (waniffmt[0] != '\0') {
				strcpy(laniffmt, "-i");
			} else {
				laniffmt[0] = '\0';
			}
			if (tmpfmt[0] != '\0') {
				strcpy(waniffmt, "-o");
			} else {
				waniffmt[0] = '\0';
			}
			goto lbl_bidir;
		}
	}

	return (ret);
}

struct alg_info *ifx_get_node(int protocol_name, int ip_protocol, int port,
			      char *lan_itf_name, char *wan_itf_name,
			      int nat_flag)
{
	struct alg_info *node = NULL;

	if (alg_list_head == NULL)
		return NULL;

	node = alg_list_head;

	while (node != NULL) {

		if ((node->protocol_name == protocol_name) &&
		    (!ip_protocol || (int)node->ip_protocol == ip_protocol) &&
		    (!port || node->port == port) &&
		    (!COMP_ITF(node->lanitf, lan_itf_name)) &&
		    (!COMP_ITF(node->wanitf, wan_itf_name)) &&
		    (!nat_flag || node->nat_flag == nat_flag)) {
			return (node);
		}

		node = node->next;
	}

	/* Node not found */
	return (NULL);
}

/*  Create and add new node to the list */
int ifx_add_node(int protocol_name, int ip_protocol, int port,
		 char *lan_itf_name, char *wan_itf_name, int flag,
		 int dump_flag)
{
	struct alg_info *node;

	NPRINTF("Calling ifx_add_node!\n");
	/* Check if node exists already */
	if (ifx_get_node(protocol_name, ip_protocol, port, lan_itf_name,
			 wan_itf_name, 0) != NULL) {
		NPRINTF("ALG already enabled for App <%d>, IP Proto<%d>, Port"
			"<%d>, LanIf<%s>, WanIf<%s>, NAT<%d>\n",
			protocol_name, ip_protocol, port, lan_itf_name,
			wan_itf_name, flag);
		return -1;
	}

	node = (struct alg_info *)malloc(sizeof(struct alg_info));
	if (node == NULL)
		return -1;

	node->protocol_name = protocol_name;
	node->ip_protocol = ip_protocol;
	node->port = port;
	node->nat_flag = flag;

	COPY_ITF(node->lanitf, lan_itf_name);
	COPY_ITF(node->wanitf, wan_itf_name);

	node->next = alg_list_head;
	alg_list_head = node;

	NPRINTF("\n Node is addedd successfully \n");

	if (dump_flag) {
		write_alg_nodes_file();	/* save to disk */
	}

	return 0;
}

/* Delete node form the list */
int ifx_delete_node(struct alg_info *del_node)
{
	struct alg_info *node = NULL, *prev = NULL;

	if (alg_list_head == NULL)
		return -1;

	node = alg_list_head;
	prev = alg_list_head;

	while (node != NULL) {

		if ((node->protocol_name == del_node->protocol_name) &&
		    ((int)node->ip_protocol == (int)del_node->ip_protocol) &&
		    (node->port == del_node->port) &&
		    (node->lanitf == del_node->lanitf) &&
		    (node->wanitf == del_node->wanitf) &&
		    (!del_node->nat_flag ||
		     node->nat_flag == del_node->nat_flag)) {
			if (node != alg_list_head)
				prev->next = node->next;
			else
				alg_list_head = node->next;

			free(node);
			/* Node successfully deleated */
			NPRINTF("\n Node is deleted successfully. \n");

			write_alg_nodes_file();	/* save to disk */
			return 0;
		}

		prev = node;
		node = node->next;
	}

	/* Node not found */
	return -1;
}

int ifx_disable_sip_alg(int port, int ip_proto, int nat_flag)
{
	int dev_file = 0, dev_file_conn = 0, ret = 0;
	struct sip_params parameters;
	char portstr[20];

	NPRINTF("\nifx_disable_sip_alg is called \n");

	dev_file_conn = ifx_open_device(DEVICE_FILE_NAME_SIP_CONN);
	if (dev_file_conn < 0)
		return -1;

	if (nat_flag == NAT_ENABLE) {
		NPRINTF("nat flag is enabled\n");
		dev_file = ifx_open_device(DEVICE_FILE_NAME_SIP);
		if (dev_file < 0) {
			close(dev_file_conn);
			return -1;
		}
	}

	sprintf(portstr, "%d", port);
	//sumedh -adding iptables rules for SIP
	ifx_set_alg_rules(FORWARD, ip_proto, SRC_PORTS, portstr, STATE_EST_REL,
			  DELETE_RULE);
	ifx_set_alg_rules(NAT, ip_proto, SRC_PORTS, portstr, STATE_EST_REL,
			  DELETE_RULE);
	ifx_set_alg_rules(FORWARD, ip_proto, DST_PORTS, portstr, "",
			  DELETE_RULE);
	ifx_set_alg_rules(NAT, ip_proto, DST_PORTS, portstr, "", DELETE_RULE);
	ifx_set_alg_rules(INPUT, ip_proto, DST_PORTS, portstr, "", DELETE_RULE);
	ifx_set_alg_rules(INPUT, ip_proto, 0, NULL, STATE_EST_REL, DELETE_RULE);
	ifx_set_alg_rules(OUTPUT, ip_proto, DST_PORTS, portstr, "",
			  DELETE_RULE);
	ifx_set_alg_rules(OUTPUT, ip_proto, 0, NULL, STATE_EST_REL,
			  DELETE_RULE);

	parameters.src_port = port;
	parameters.dst_port = 0;
	parameters.ip_proto = ip_proto;

	if (nat_flag == NAT_ENABLE) {
		ret =
		    ifx_ioctl(dev_file, IOCTL_DEREGISTER_SIP_PORT, &parameters);
		close(dev_file);
	}

	ret =
	    ifx_ioctl(dev_file_conn, IOCTL_DEREGISTER_SIP_PORT_CONN,
		      &parameters);

	close(dev_file_conn);
	return ret;
}

//510251:sumedh starts (disable ALG functions)
int ifx_disable_ipsec_alg(int port, enum AlgControlProtocol ip_proto,
			  int nat_flag)
{
	char all_ports[60];
	char xport[20];
	char *tempPtr = NULL;

	NPRINTF("\nifx_disable_ipsec_alg is called \n");

	strcpy(all_ports, IPSEC_PORT_LIST);
	strcat(all_ports, ",@");
	if ((tempPtr = strtok(all_ports, ",")) != NULL)
		strcpy(xport, tempPtr);
	else
		xport[0] = '\0';
	while (strcmp(xport, "@") != 0) {
		ifx_set_alg_rules(NAT, IP_PROTO_UDP, BOTH_PORTS, xport, "",
				  DELETE_RULE);
		ifx_set_alg_rules(FORWARD, IP_PROTO_UDP, BOTH_PORTS, xport, "",
				  DELETE_RULE);
		tempPtr = NULL;
		if ((tempPtr = strtok(NULL, ",")) != NULL)
			strcpy(xport, tempPtr);
		else
			xport[0] = '\0';
		NPRINTF("~~~~~~ Value of xport = %s", xport);
	}
	ifx_set_alg_rules(NAT, IP_PROTO_ESP, 0, "", "", DELETE_RULE);
	ifx_set_alg_rules(FORWARD, IP_PROTO_ESP, 0, "", "", DELETE_RULE);
	ifx_set_alg_rules(NAT, IP_PROTO_AH, 0, "", "", DELETE_RULE);
	ifx_set_alg_rules(FORWARD, IP_PROTO_AH, 0, "", "", DELETE_RULE);
	return 0;
}

int ifx_disable_ftp_alg(int port, enum AlgControlProtocol ip_proto,
			int nat_flag)
{
	NPRINTF("\nifx_disable_ftp_alg is called \n");
	ifx_set_alg_rules(INPUT, IP_PROTO_TCP, DST_PORTS, FTP_PORT_LIST, "",
			  DELETE_RULE);
	ifx_set_alg_rules(OUTPUT, IP_PROTO_TCP, SRC_PORTS, FTP_PORT_LIST,
			  STATE_EST, DELETE_RULE);
	ifx_set_alg_rules(FORWARD, IP_PROTO_TCP, DST_PORTS, FTP_PORT_LIST, "",
			  DELETE_RULE);
	ifx_set_alg_rules(FORWARD, IP_PROTO_TCP, SRC_PORTS, FTP_PORT_LIST,
			  STATE_EST_REL, DELETE_RULE);
	ifx_set_alg_rules(NAT, IP_PROTO_TCP, SRC_PORTS, FTP_PORT_LIST, "",
			  DELETE_RULE);
	ifx_set_alg_rules(NAT, IP_PROTO_TCP, DST_PORTS, FTP_PORT_LIST, "",
			  DELETE_RULE);
	return 0;
}

int ifx_disable_pptp_alg(int port, enum AlgControlProtocol ip_proto,
			 int nat_flag)
{
	NPRINTF("\nifx_disable_ptpp_alg is called \n");
	ifx_set_alg_rules(FORWARD, IP_PROTO_TCP, DST_PORTS, PPTP_PORT_LIST, "",
			  DELETE_RULE);
	ifx_set_alg_rules(FORWARD, IP_PROTO_TCP, SRC_PORTS, PPTP_PORT_LIST,
			  STATE_EST_REL, DELETE_RULE);
	ifx_set_alg_rules(NAT, IP_PROTO_TCP, SRC_PORTS, PPTP_PORT_LIST, "",
			  DELETE_RULE);
	ifx_set_alg_rules(NAT, IP_PROTO_TCP, DST_PORTS, PPTP_PORT_LIST, "",
			  DELETE_RULE);
	ifx_set_alg_rules(FORWARD, IP_PROTO_GRE, 0, "", STATE_EST_REL,
			  DELETE_RULE);

	return 0;
}
int ifx_disable_netmeeting_alg(int port, enum AlgControlProtocol ip_proto,
			       int nat_flag)
{
	NPRINTF("\nifx_disable_netmeeting_alg is called \n");
	ifx_set_alg_rules(FORWARD, IP_PROTO_TCP, DST_PORTS,
			  NETMEETING_PORT_LIST, "", DELETE_RULE);
	ifx_set_alg_rules(FORWARD, IP_PROTO_TCP, SRC_PORTS,
			  NETMEETING_PORT_LIST, "", DELETE_RULE);
	ifx_set_alg_rules(NAT, IP_PROTO_TCP, SRC_PORTS, NETMEETING_PORT_LIST,
			  "", DELETE_RULE);
	return 0;

}
int ifx_disable_rtsp_alg(int port, enum AlgControlProtocol ip_proto,
			 int nat_flag)
{
//      int dev_file = 0,dev_file_conn,ret = 0;
//      struct rtsp_params parameters;

	NPRINTF("\nifx_disable_rtsp_alg is called \n");
/*
	if (nat_flag == NAT_ENABLE) {
		dev_file = 	ifx_open_device(DEVICE_FILE_NAME_RTSP);
		if (dev_file < 0)
			return -1;
	}

	dev_file_conn = ifx_open_device(DEVICE_FILE_NAME_RTSP_CONN);
	if (dev_file_conn < 0)
		return -1;

	
	parameters.alg_port = port;
	parameters.ip_proto = ip_proto;

	if (nat_flag == NAT_ENABLE) {
		ret = ifx_ioctl(dev_file,IOCTL_DEREGISTER_RTSP_PORT,&parameters);
		NPRINTF("\n ifx_ioctl for deregister RTSP return value is %d\n",ret);
		close(dev_file);
	}

	ret = ifx_ioctl(dev_file_conn,IOCTL_DEREGISTER_RTSP_PORT_CONN,&parameters);
	NPRINTF("\n ifx_ioctl for deregister RTSP conn return value is %d\n",ret);

	close(dev_file_conn);
	NPRINTF("\n ifx_disable_rtsp_alg return value is %d\n",ret);
	return ret;
*/
	ifx_set_alg_rules(FORWARD, IP_PROTO_TCP, DST_PORTS, RTSP_PORT_LIST, "",
			  DELETE_RULE);
	ifx_set_alg_rules(FORWARD, IP_PROTO_TCP, SRC_PORTS, RTSP_PORT_LIST,
			  STATE_EST_REL, DELETE_RULE);
	ifx_set_alg_rules(NAT, IP_PROTO_TCP, DST_PORTS, RTSP_PORT_LIST, "",
			  DELETE_RULE);

#ifndef IPT_VER_1_4_6
	sprintf(command,
		"iptables -D %s -t nat -p udp --sport 6970:6980 -m state --state NEW -j DROP",
		ALG_NAT_CHAIN);
	system(command);
#endif				// IPT_VER_1_4_6
	return 0;
}

//510251:sumedh ends (disable ALGs functions end)

/* Disable protocol specific ALG and delete all corresponding nodes from list */
int ifx_disable_alg(int protocol_name, int trans_proto, int port,
		    char *lan_itf_name, char *wan_itf_name, int bidir)
{
	struct alg_info *node;
	int ret = 0;

	node = ifx_get_node(protocol_name, trans_proto, port, lan_itf_name,
			    wan_itf_name, NAT_DONTCARE);

	if (node == NULL) {
		NPRINTF("Entry not found! \n");
		return -1;
	}

	if (protocol_name == PROTO_SIP) {
		if ((ret =
		     ifx_disable_sip_alg(node->port, node->ip_protocol,
					 node->nat_flag) < 0)) {
			NPRINTF("\n Error : SIP ALG could not be disabled\n");
		}
	} else if (protocol_name == PROTO_RTSP) {
		if ((ret =
		     ifx_disable_rtsp_alg(node->port, node->ip_protocol,
					  node->nat_flag) < 0)) {
			NPRINTF("\n Error : RTSP ALG could not be disabled\n");
		}
	} else if (protocol_name == PROTO_NETMEETING) {
		if ((ret =
		     ifx_disable_netmeeting_alg(node->port, node->ip_protocol,
						node->nat_flag) < 0)) {
			NPRINTF
			    ("\n Error : NETMEETING ALG could not be disabled\n");
		}
	} else if (protocol_name == PROTO_IPSEC) {
		if ((ret =
		     ifx_disable_ipsec_alg(node->port, node->ip_protocol,
					   node->nat_flag) < 0)) {
			NPRINTF("\n Error : IPSEC ALG could not be disabled\n");
		}
	} else if (protocol_name == PROTO_FTP) {
		if ((ret =
		     ifx_disable_ftp_alg(node->port, node->ip_protocol,
					 node->nat_flag) < 0)) {
			NPRINTF("\n Error : FTP ALG could not be disabled\n");
		}
	} else if (protocol_name == PROTO_PPTP) {
		if ((ret =
		     ifx_disable_pptp_alg(node->port, node->ip_protocol,
					  node->nat_flag) < 0)) {
			NPRINTF("\n Error : PPTP ALG could not be disabled\n");
		}
	}

	if (ifx_delete_node(node) < 0) {
		NPRINTF("\n Error : Node Not found\n");
	}

/* 510251:sumedh (commeted out)

	//ret = ifx_set_rules(lan_itf_name, wan_itf_name, node->ip_protocol, port, DELETE_RULE,
	//		bidir);

	if (alg_list_head == NULL)
	{
		NPRINTF("\n Trying to reset Rulesxxxxxxxxxxxxxxxxxxxxxxxxxx \n");
		return ifx_set_init_rules_for_conntrack(lan_itf_name,wan_itf_name,DELETE_RULE, bidir);
	}
****************/
	return 0;
	//return ret;           
}

/* Disable protocol specific ALG and delete all corresponding nodes from list */
int ifx_disable_alg_all_ports(int protocol_name)
{
	struct alg_info *node;

	node = alg_list_head;

	/* Search all node for Corresponding ALG */
	while (node != NULL) {
		ifx_disable_alg(protocol_name, node->ip_protocol, node->port,
				node->lanitf, node->wanitf, 1);
		node = node->next;

	}

	return 0;
}

int ifx_open_device(char *dev_name)
{
	int dev_file;

	NPRINTF("ifx_open_device is called");
	dev_file = open(dev_name, 0);
	if (dev_file < 0) {
		NPRINTF("\n Error : Can't open device file: %s\n", dev_name);
		return -1;
	}

	return dev_file;
}

int ifx_ioctl(int dev_file, int request, void *param)
{
	int ret = 0;
	NPRINTF("\n ifx_ioctl is called");

	ret = ioctl(dev_file, request, param);
	if (ret < 0) {
		NPRINTF("\n Error : ioctl call fails \n");
		return -1;
	}

	NPRINTF("\n ioctl return value is %d\n", ret);
	return ret;
}

//510251:sumedh starts (enable ALGs functions)
int ifx_enable_ipsec_alg(int *pport, int *pip_proto, char *lan_itf_name,
			 char *wan_itf_name, int nat_flag)
{
	char all_ports[60];
	char xport[20];
	char *tempPtr = NULL;

	if (*pport == 0)
		*pport = DEFAULT_IPSEC_PORT;
	if (*pip_proto == 0)
		*pip_proto = IP_PROTO_TCP;

	NPRINTF("\nifx_enable_ipsec_alg is called..... \n");
	if (ifx_add_node
	    (PROTO_IPSEC, *pip_proto, *pport, lan_itf_name, wan_itf_name,
	     nat_flag, 1) < 0)
		return -1;

	NPRINTF("\nAbout to call ifx_set_alg_rules \n");
	NPRINTF("\nValue of IPSEC_PORT_LIST = %s\n", IPSEC_PORT_LIST);

	strcpy(all_ports, IPSEC_PORT_LIST);
	strcat(all_ports, ",@");
	if ((tempPtr = strtok(all_ports, ",")) != NULL)
		strcpy(xport, tempPtr);
	else
		xport[0] = '\0';
	while (strcmp(xport, "@") != 0) {
		ifx_set_alg_rules(NAT, IP_PROTO_UDP, BOTH_PORTS, xport, "",
				  ADD_RULE);
		ifx_set_alg_rules(FORWARD, IP_PROTO_UDP, BOTH_PORTS, xport, "",
				  ADD_RULE);
		if ((tempPtr = strtok(NULL, ",")) != NULL)
			strcpy(xport, tempPtr);
		else
			xport[0] = '\0';
		NPRINTF("~~~~~~ Value of xport = %s", xport);
	}

	ifx_set_alg_rules(NAT, IP_PROTO_ESP, 0, "", "", ADD_RULE);
	ifx_set_alg_rules(FORWARD, IP_PROTO_ESP, 0, "", "", ADD_RULE);
	ifx_set_alg_rules(NAT, IP_PROTO_AH, 0, "", "", ADD_RULE);
	ifx_set_alg_rules(FORWARD, IP_PROTO_AH, 0, "", "", ADD_RULE);

	return 0;

}

int ifx_enable_netmeeting_alg(int *pport, int *pip_proto, char *lan_itf_name,
			      char *wan_itf_name, int nat_flag)
{
	if (*pport == 0)
		*pport = DEFAULT_NETMEETING_PORT;
	if (*pip_proto == 0)
		*pip_proto = IP_PROTO_TCP;

	NPRINTF("\nifx_enable_netmeeting_alg is called..... \n");
	if (ifx_add_node
	    (PROTO_NETMEETING, *pip_proto, *pport, lan_itf_name, wan_itf_name,
	     nat_flag, 1) < 0)
		return -1;

	NPRINTF("\nAbout to call ifx_set_alg_rules \n");
	NPRINTF("\nValue of NETMEETING_PORT_LIST = %s", NETMEETING_PORT_LIST);
	ifx_set_alg_rules(FORWARD, IP_PROTO_TCP, DST_PORTS,
			  NETMEETING_PORT_LIST, "", ADD_RULE);
	ifx_set_alg_rules(FORWARD, IP_PROTO_TCP, SRC_PORTS,
			  NETMEETING_PORT_LIST, "", ADD_RULE);
	ifx_set_alg_rules(NAT, IP_PROTO_TCP, SRC_PORTS, NETMEETING_PORT_LIST,
			  "", ADD_RULE);

	return 0;

}

int ifx_enable_ftp_alg(int *pport, int *pip_proto, char *lan_itf_name,
		       char *wan_itf_name, int nat_flag)
{
	if (*pport == 0)
		*pport = DEFAULT_FTP_PORT;
	if (*pip_proto == 0)
		*pip_proto = IP_PROTO_TCP;

	NPRINTF("\nifx_enable_ftp_alg is called..... \n");
	if (ifx_add_node
	    (PROTO_FTP, *pip_proto, *pport, lan_itf_name, wan_itf_name,
	     nat_flag, 1) < 0)
		return -1;

	NPRINTF("\nAbout to call ifx_set_alg_rules \n");
	NPRINTF("\nValue of FTP_PORT_LIST = %s", FTP_PORT_LIST);

	ifx_set_alg_rules(INPUT, IP_PROTO_TCP, DST_PORTS, FTP_PORT_LIST, "",
			  ADD_RULE);
	ifx_set_alg_rules(OUTPUT, IP_PROTO_TCP, SRC_PORTS, FTP_PORT_LIST,
			  STATE_EST, ADD_RULE);
	ifx_set_alg_rules(FORWARD, IP_PROTO_TCP, DST_PORTS, FTP_PORT_LIST, "",
			  ADD_RULE);
	ifx_set_alg_rules(FORWARD, IP_PROTO_TCP, SRC_PORTS, FTP_PORT_LIST,
			  STATE_EST_REL, ADD_RULE);
	ifx_set_alg_rules(NAT, IP_PROTO_TCP, SRC_PORTS, FTP_PORT_LIST, "",
			  ADD_RULE);
	ifx_set_alg_rules(NAT, IP_PROTO_TCP, DST_PORTS, FTP_PORT_LIST, "",
			  ADD_RULE);

	return 0;
}

int ifx_enable_pptp_alg(int *pport, int *pip_proto, char *lan_itf_name,
			char *wan_itf_name, int nat_flag)
{
	if (*pport == 0)
		*pport = DEFAULT_PPTP_PORT;
	if (*pip_proto == 0)
		*pip_proto = IP_PROTO_TCP;

	NPRINTF("\nifx_enable_pptp_alg is called..... \n");
	if (ifx_add_node
	    (PROTO_PPTP, *pip_proto, *pport, lan_itf_name, wan_itf_name,
	     nat_flag, 1) < 0)
		return -1;

	NPRINTF("\nAbout to call ifx_set_alg_rules \n");
	NPRINTF("\nValue of PPTP_PORT_LIST = %s", PPTP_PORT_LIST);

	ifx_set_alg_rules(FORWARD, IP_PROTO_TCP, DST_PORTS, PPTP_PORT_LIST, "",
			  ADD_RULE);
	ifx_set_alg_rules(FORWARD, IP_PROTO_TCP, SRC_PORTS, PPTP_PORT_LIST,
			  STATE_EST_REL, ADD_RULE);
	ifx_set_alg_rules(NAT, IP_PROTO_TCP, SRC_PORTS, PPTP_PORT_LIST, "",
			  ADD_RULE);
	ifx_set_alg_rules(NAT, IP_PROTO_TCP, DST_PORTS, PPTP_PORT_LIST, "",
			  ADD_RULE);
	ifx_set_alg_rules(FORWARD, IP_PROTO_GRE, 0, "", STATE_EST_REL,
			  ADD_RULE);

	return 0;
}
int ifx_enable_sip_alg(int *pport, int *pip_proto, char *lan_itf_name,
		       char *wan_itf_name, int nat_flag)
{
	int ret = 0, dev_file = 0, dev_file_conn = 0;
	struct sip_params parameters;
	int proto, port;
	char portstr[20];

	NPRINTF("\n ifx_enable_sip_alg is called \n");

	/* Check if node exists already */
	if (ifx_get_node(PROTO_SIP, *pip_proto, *pport, lan_itf_name,
			 wan_itf_name, 0) != NULL) {
		NPRINTF("ALG already enabled for App <%d>, IP Proto<%d>, Port"
			"<%d>, LanIf<%s>, WanIf<%s>, NAT<%d>\n",
			PROTO_SIP, *pip_proto, *pport, lan_itf_name,
			wan_itf_name, nat_flag);
		ret = -1;
		goto lbl_ret;
	}

	if (*pport == 0)
		*pport = DEFAULT_SIP_PORT;
	if (*pip_proto == 0)
		*pip_proto = IP_PROTO_TCP_UDP;

	//printf("\nprotocol = %d\nport=%d\n",*pip_proto, *pport);
	proto = *pip_proto;
	port = *pport;
	sprintf(portstr, "%d", port);
	//printf("\nNEW\nprotocol = %d\nport=%d\n",proto, port);

	//sumedh -adding iptables rules for SIP
	ifx_set_alg_rules(FORWARD, proto, SRC_PORTS, portstr, STATE_EST_REL,
			  ADD_RULE);
	ifx_set_alg_rules(NAT, proto, SRC_PORTS, portstr, STATE_EST_REL,
			  ADD_RULE);
	ifx_set_alg_rules(FORWARD, proto, DST_PORTS, portstr, "", ADD_RULE);
	ifx_set_alg_rules(NAT, proto, DST_PORTS, portstr, "", ADD_RULE);
	ifx_set_alg_rules(INPUT, proto, DST_PORTS, portstr, "", ADD_RULE);
	ifx_set_alg_rules(INPUT, proto, 0, NULL, STATE_EST_REL, ADD_RULE);
	ifx_set_alg_rules(OUTPUT, proto, DST_PORTS, portstr, "", ADD_RULE);
	ifx_set_alg_rules(OUTPUT, proto, 0, NULL, STATE_EST_REL, ADD_RULE);

	dev_file_conn = ifx_open_device(DEVICE_FILE_NAME_SIP_CONN);
	if (dev_file_conn < 0) {
		ret = -1;
		goto lbl_ret;
	}

	if (nat_flag == NAT_ENABLE) {
		NPRINTF("Nat flag is enabled\n");
		dev_file = ifx_open_device(DEVICE_FILE_NAME_SIP);
		if (dev_file < 0) {
			ret = -1;
			goto lbl_ret;
		}
	}
#if 0
	parameters.src_port = *pport;
	parameters.dst_port = 0;
#else
	printf("\nSetting SIP Parameter, dst_port=%d\n", *pport);
	parameters.dst_port = *pport;
	parameters.src_port = 0;
#endif
	parameters.ip_proto = *pip_proto;

	ret =
	    ifx_ioctl(dev_file_conn, IOCTL_REGISTER_SIP_PORT_CONN, &parameters);

	if (nat_flag == NAT_ENABLE) {
		ret = ifx_ioctl(dev_file, IOCTL_REGISTER_SIP_PORT, &parameters);
		if (ret < 0) {
			/* NAT enable failed for whatever reasons (no insmod ?) */
			nat_flag = NAT_DISABLE;
		}
	}

	if (ifx_add_node
	    (PROTO_SIP, *pip_proto, *pport, lan_itf_name, wan_itf_name,
	     nat_flag, 1) < 0) {
		ret = -1;	/* shouldn't happen, since we already checked. Not taking care! */
	} else {
		ret = 0;
	}

      lbl_ret:
	if (dev_file >= 0)
		close(dev_file);
	if (dev_file_conn >= 0)
		close(dev_file_conn);

      
	return ret;
}

int ifx_enable_rtsp_alg(int *pport, int *pip_proto, char *lan_itf_name,
			char *wan_itf_name, int nat_flag)
{
//      int ret =0,dev_file = 0,dev_file_conn = 0;
//      struct rtsp_params parameters;

	if (*pport == 0)
		*pport = DEFAULT_RTSP_PORT;
	if (*pip_proto == 0)
		*pip_proto = IP_PROTO_TCP;

	NPRINTF("\nifx_enable_rtsp_alg is called..... \n");
	if (ifx_add_node
	    (PROTO_RTSP, *pip_proto, *pport, lan_itf_name, wan_itf_name,
	     nat_flag, 1) < 0)
		return -1;
/*
	dev_file_conn = ifx_open_device(DEVICE_FILE_NAME_RTSP_CONN);
	if (dev_file_conn < 0)
		return -1;

	if (nat_flag == NAT_ENABLE) {
		dev_file = ifx_open_device(DEVICE_FILE_NAME_RTSP);
		if (dev_file < 0)
			return -1;
	}

	parameters.alg_port = *pport;
	parameters.ip_proto = *pip_proto;
	
	ret = ifx_ioctl(dev_file_conn,IOCTL_REGISTER_RTSP_PORT_CONN,&parameters);
	NPRINTF("\n ifx_ioctl for register RTSP CONN return value is %d\n",ret);
 
	if (nat_flag == NAT_ENABLE) {
		ret = ifx_ioctl(dev_file,IOCTL_REGISTER_RTSP_PORT,&parameters);
		NPRINTF("\n ifx_ioctl for register RTSP return value is %d\n",ret);
	}

	close(dev_file);
	close(dev_file_conn);
*/
	NPRINTF("\nAbout to call ifx_set_alg_rules \n");
	NPRINTF("\nValue of RTSP_PORT_LIST = %s", RTSP_PORT_LIST);
	ifx_set_alg_rules(FORWARD, IP_PROTO_TCP, DST_PORTS, RTSP_PORT_LIST, "",
			  ADD_RULE);
	ifx_set_alg_rules(FORWARD, IP_PROTO_TCP, SRC_PORTS, RTSP_PORT_LIST,
			  STATE_EST_REL, ADD_RULE);
	ifx_set_alg_rules(NAT, IP_PROTO_TCP, DST_PORTS, RTSP_PORT_LIST, "",
			  ADD_RULE);

#ifndef IPT_VER_1_4_6
	sprintf(command,
		"iptables -A %s -t nat -p udp --sport 6970:6980 -m state --state NEW -j DROP",
		ALG_NAT_CHAIN);
	system(command);
#endif				// IPT_VER_1_4_6

	return 0;

}

//510251:sumedh ends (enable ALGs functions end)

int ifx_enable_alg(int protocol_name, int ip_proto, int port,
		   char *lan_itf_name, char *wan_itf_name, int nat_flag,
		   int bidir)
{
	int ret = 0;
	//struct rtsp_params parameters; 

	NPRINTF("\n ifx_enable_alg is called... \n");
	if (protocol_name == PROTO_SIP) {
		if ((ret =
		     ifx_enable_sip_alg(&port, &ip_proto, lan_itf_name,
					wan_itf_name, nat_flag)) < 0) {
			NPRINTF("\n Error : SIP ALG could not be enabled\n");
		}
	}

	if (protocol_name == PROTO_RTSP) {
		if ((ret =
		     ifx_enable_rtsp_alg(&port, &ip_proto, lan_itf_name,
					 wan_itf_name, nat_flag)) < 0) {
			NPRINTF("\n Error : RTSP ALG could not be enabled\n");
		}
	}
	if (protocol_name == PROTO_NETMEETING) {
		if ((ret =
		     ifx_enable_netmeeting_alg(&port, &ip_proto, lan_itf_name,
					       wan_itf_name, nat_flag)) < 0) {
			NPRINTF
			    ("\n Error : NETMEETING ALG could not be enabled\n");
		}
	}
	if (protocol_name == PROTO_IPSEC) {
		if ((ret =
		     ifx_enable_ipsec_alg(&port, &ip_proto, lan_itf_name,
					  wan_itf_name, nat_flag)) < 0) {
			NPRINTF("\n Error : IPSEC ALG could not be enabled\n");
		}
	}
	if (protocol_name == PROTO_FTP) {
		if ((ret =
		     ifx_enable_ftp_alg(&port, &ip_proto, lan_itf_name,
					wan_itf_name, nat_flag)) < 0) {
			NPRINTF("\n Error : FTP ALG could not be enabled\n");
		}
	}
	if (protocol_name == PROTO_PPTP) {
		if ((ret =
		     ifx_enable_pptp_alg(&port, &ip_proto, lan_itf_name,
					 wan_itf_name, nat_flag)) < 0) {
			NPRINTF("\n Error : PPTP ALG could not be enabled\n");
		}
	}

//      strcpy(lan_interface,lan_itf_name);
//      strcpy(wan_interface,wan_itf_name);

	NPRINTF("\n Trying to set Rules \n");

//510251:sumedh (commented out)
/*
	if (alg_list_head->next == NULL) {
		ret = ifx_set_init_rules_for_conntrack(lan_itf_name,wan_itf_name,ADD_RULE, bidir);
		if (ret == -1) {
			return (ret);
		}
	}
*/
//510251:sumedh (commented out)
	//ret = ifx_set_rules(lan_itf_name, wan_itf_name, ip_proto, port, ADD_RULE, bidir);
	//return ret;
	return 0;
}

int ifx_find_app_proto(char *app_name)
{
	int i = 0;
	for (i = 0; i < sizeof(nf_alg_array) / sizeof(struct nf_alg_map); i++) {
		if (strcmp(app_name, nf_alg_array[i].alg_name) == 0) {
			return (nf_alg_array[i].alg_proto);
		}
	}
	return -1;
}

#if 0
#define PROGNAME "nfappcfg"
void usage(void)
{
	printf("%s usage:\n", PROGNAME);
	printf("\t\t %s <app protocol> <enable> [-llanif] [-wwanif]\n"
	       "\t\t\t	[<-ttransportproto> <-pdestport> <-b>]\n", PROGNAME);
	printf
	    ("\t\t %s <app protocol> <disable>  [<-ttransport proto> <-pport> <-b>]\n",
	     PROGNAME);

	exit(1);
}

int main(int argc, char *argv[])
{

	int proto_id, flag, trans_proto = 0, port = 0;
	int ret = 0;
	int i = 0;
	int bidir = 0;
	char *lanif = NULL, *wanif = NULL;
	int nat_flag = 1;
	NPRINTF("\n program started \n");

	if (argc < 3)
		usage();

	proto_id = find_app_proto(argv[1]);

	if (proto_id < 0) {
		NPRINTF("Invalid application [%s] !\n", argv[1]);
		usage();
	}

	if (strcmp(argv[2], "enable") == 0) {
		flag = ENABLE;
	} else {
		flag = DISABLE;
	}

	for (i = 3; i < argc; i++) {
		if (argv[i][0] != '-') {
			usage();
		}

		switch (argv[i][1]) {
		case 'l':
			lanif = &argv[i][2];
			break;
		case 'w':
			wanif = &argv[i][2];
			break;
		case 't':
			if (!strcmp(&argv[i][2], "tcp"))
				trans_proto = IP_PROTO_TCP;
			else if (!strcmp(&argv[i][2], "udp"))
				trans_proto = IP_PROTO_UDP;
			else if (!strcmp(&argv[i][2], "tcpudp"))
				trans_proto = IP_PROTO_TCP_UDP;
			else
				usage();
			break;
		case 'p':
			port = strtol(&argv[i][2], NULL, 10);
			break;
		case 'b':
			bidir = 1;
			break;
		default:
			/* do nothing */
		}
	}

	if (trans_proto == 0 || port == 0) {
		if (!(trans_proto == 0 && port == 0)) {
			usage();
		}
	}

	NPRINTF("app<%d>, enable<%d>, Transport <%d>, Port <%d>, Lan <%s>, Wan"
		"<%s> bidir <%d>\n", proto_id, flag, trans_proto, port, lanif,
		wanif, bidir);

	if (flag == ENABLE) {

		if (ifx_enable_alg(proto_id, trans_proto, port, lanif, wanif,
				   nat_flag, bidir) < 0)
			NPRINTF("\n Error : Enable fails\n");
		else
			NPRINTF("\n Enable successfull \n");
	} else {
		if ((ret =
		     ifx_disable_alg(proto_id, trans_proto, port, lanif, wanif,
				     bidir)) < 0)
			NPRINTF("\n Error : Enable fails\n");
		else
			NPRINTF("\n Enable successfull \n");
	}

	return ret;
}

#endif
