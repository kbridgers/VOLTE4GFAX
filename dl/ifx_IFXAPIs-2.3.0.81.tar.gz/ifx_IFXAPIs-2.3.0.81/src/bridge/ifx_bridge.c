/* ============================================================================
 * Copyright (C) 2004 - Infineon Technologies.
 *
 * All rights reserved.
 * ============================================================================
 *
 * ============================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ============================================================================
 *
 * Revision History:
 *      - 2004/07/13, MarsLin
 *         init version
 *
 * ============================================================================
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>

#include "ifx_common.h"

int ifx_bridge_enable(char *pServerName, int iTimeMinuteOffset)
{
	char aCommand[100] = { '\0' };

	sprintf(aCommand, "ntpclient -s -h %s -o %d", pServerName,
		iTimeMinuteOffset);
	return ifx_run_command(aCommand);
}

int ifx_bridge_disable()
{
	char aCommand[100] = { '\0' };

	sprintf(aCommand, "killall ntpclient");
	return ifx_run_command(aCommand);
}
