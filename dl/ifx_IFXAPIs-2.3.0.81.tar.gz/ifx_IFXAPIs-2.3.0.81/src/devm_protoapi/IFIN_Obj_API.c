
/*
** =============================================================================
** FILE NAME     : IFIN_Obj_API.c
** PROJECT       : TR69
** MODULES       : Object API
** DATE          : 11-08-2006
** AUTHOR        : TR69 team
** DESCRIPTION   :
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author      $Comment
**
** ============================================================================
*/

/* =============================================================================
**                                <INCLUDE FILES>
** =============================================================================
*/
#include "ifx_common.h"
#include "ifx_api_include.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include "ifx_api_util.h"

/* =============================================================================
**                              <LOCAL DEFINITIONS>
** =============================================================================
*/

#define IFX_MGMT_SERVER_SECTION                   "mgmt_server"
#define IFX_MGMT_SERVER_URL                       "acsurl"
#define IFX_MGMT_SERVER_USERNAME                  "acsuname"
#define IFX_MGMT_SERVER_PASSWORD                  "acspasswd"
#define IFX_MGMT_SERVER_PERIODICINFORMENABLE      "perinfena"
#define IFX_MGMT_SERVER_PERIODICINFORMINTERVAL    "perinfint"
#define IFX_MGMT_SERVER_PERIODICINFORMTIME        "perinftime"
#define IFX_MGMT_SERVER_PARAMETERKEY              "paramkey"
#define IFX_MGMT_SERVER_CONNECTIONREQUESTURL      "conrequrl"
#define IFX_MGMT_SERVER_CONNECTIONREQUESTUSERNAME "conrequname"
#define IFX_MGMT_SERVER_CONNECTIONREQUESTPASSWORD "conreqpasswd"
#define IFX_MGMT_SERVER_UPGRADESMANAGED           "upgsmanaged"
#define IFX_MGMT_SERVER_ENABLECWMP		  "enablecwmp"

//TR-111 related parameters
#define IFX_MGMT_SERVER_UDPCONNREQADDRESS         "udpconrequrl"
#define IFX_MGMT_SERVER_UDPCONNREQADDRESSNOTIFYLIMIT    "udpconreqnotifylimit"
#define IFX_MGMT_SERVER_STUNENABLE                "stunenable"
#define IFX_MGMT_SERVER_STUNSERVERADDRESS         "stunserveripaddress"
#define IFX_MGMT_SERVER_STUNSERVERPORT            "stunserverport"
#define IFX_MGMT_SERVER_STUNUSERNAME              "stunusername"
#define IFX_MGMT_SERVER_STUNPASSWORD              "stunpasswd"
#define IFX_MGMT_SERVER_STUNMAXKEEPALIVEPERIOD    "stunmaxkeepalivetime"
#define IFX_MGMT_SERVER_STUNMINKEEPALIVEPERIOD    "stunminkeepalivetime"
#define IFX_MGMT_SERVER_STUNNATDETECTED           "natdetected"
#define IFX_MGMT_SERVER_MNGDEVICENOTIFYLIMIT      "mngdevnotifylimit"

#define IFX_DEVICE_INFO_SECTION                   "device_info"
#define IFX_DEVICE_INFO_MANUFACTURER              "manu"
#define IFX_DEVICE_INFO_MANUFACTUREROUI           "oui"
#define IFX_DEVICE_INFO_MODELNAME                 "modname"
#define IFX_DEVICE_INFO_DESCRIPTION               "desc"
#define IFX_DEVICE_INFO_PRODUCTCLASS              "prodclass"
#define IFX_DEVICE_INFO_SERIALNUMBER              "sernum"
#define IFX_DEVICE_INFO_HARDWAREVERSION           "hwver"
#define IFX_DEVICE_INFO_SOFTWAREVERSION           "swver"
#define IFX_DEVICE_INFO_MODEMFIRMWAREVERSION      "modfwver"
#define IFX_DEVICE_INFO_SPECVERSION               "specver"
#define IFX_DEVICE_INFO_PROVISIONINGCODE          "provcode"
#define IFX_DEVICE_INFO_UPTIME                    "uptime"
#define IFX_GATEWAY_INFO_SECTION                  "gwinfo"
#define IFX_GATEWAY_INFO_MANUFACTUREROUI          "oui"
#define IFX_GATEWAY_INFO_PRODUCTCLASS             "prodclass"
#define IFX_GATEWAY_INFO_SERIALNUMBER             "sernum"

#define IFX_DEVICE_INFO_SYSCONTACT                "syscontact"
#define IFX_DEVICE_INFO_SYSNAME                   "sysname"
#define IFX_DEVICE_INFO_SYSLOCATION               "syslocation"
#define IFX_DEVICE_INFO_SYSOBJECT_ID              "sysobjid"
#define IFX_DEVICE_INFO_SYSSERVICES               "sysservices"

#define IFX_GATEWAY_INFO_SECTION                  "gwinfo"
#define IFX_GATEWAY_INFO_MANUFACTUREROUI          "oui"
#define IFX_GATEWAY_INFO_PRODUCTCLASS             "prodclass"
#define IFX_GATEWAY_INFO_SERIALNUMBER             "sernum"

#define IFX_MANAGEABLE_DEVICE_SECTION             "manageable_device"
#define IFX_MANAGEABLE_DEVICE_SECTION_PREFIX      "ManagDev"
#define IFX_MANAGEABLE_DEVICE_MANUFACTUREROUI     "oui"
#define IFX_MANAGEABLE_DEVICE_PRODUCTCLASS        "prodclass"
#define IFX_MANAGEABLE_DEVICE_SERIALNUMBER        "sernum"
#define IFX_MANAGEABLE_DEVICE_IPADDR              "ipaddr"

#define IFX_DL_AUTH_SECTION                       "dl_auth"
#define IFX_DL_AUTH_USERNAME                      "uname"
#define IFX_DL_AUTH_PASSWORD                      "passwd"
#define IFX_DL_AUTH_REALM                         "realm"
#define IFX_DL_AUTH_NONCE                         "nonce"
#define IFX_DL_AUTH_URI                           "uri"
#define IFX_DL_AUTH_ALGO                          "algo"
#define IFX_DL_AUTH_CNONCE                        "cnonce"
#define IFX_DL_AUTH_OPAQUE                        "opaque"
#define IFX_DL_AUTH_QOP                           "qop"
#define IFX_DL_AUTH_NC                            "nc"
#define IFX_DL_AUTH_PROCESSCOOKIE                 "procookie"
#define IFX_DL_AUTH_FILETYPE                      "ftype"
#define IFX_DL_AUTH_FILENAME                      "fname"
#define IFX_DL_AUTH_COMMANDKEY                    "cmdkey"
#define IFX_DL_AUTH_STATUS                        "status"
#define IFX_DL_AUTH_STARTTIME                     "starttime"
#define IFX_DL_AUTH_ENDTIME                       "endtime"
#define IFX_DL_AUTH_FUTURETIME                    "futuretime"
#define IFX_DL_AUTH_SIZE                          "size"

#define IFX_TR69_AUTH_SECTION                     "tr69_auth"
#define IFX_TR69_AUTH_REALM                       "realm"
#define IFX_TR69_AUTH_NONCE                       "nonce"
#define IFX_TR69_AUTH_URI                         "uri"
#define IFX_TR69_AUTH_ALGO                        "algo"
#define IFX_TR69_AUTH_CNONCE                      "cnonce"
#define IFX_TR69_AUTH_OPAQUE                      "opaque"
#define IFX_TR69_AUTH_QOP                         "qop"
#define IFX_TR69_AUTH_NC                          "nc"

#define IFX_TR69_MISC_SECTION                     "tr69_misc"
#define IFX_TR69_MISC_AUTHACS                     "authacs"
#define IFX_TR69_MISC_AUTHTYPE                    "authtype"
#define IFX_TR69_MISC_EVENTCODE                   "event"
#define IFX_TR69_MISC_COMMANDKEY                  "cmdkey"
#define IFX_TR69_MISC_INCLUDEXML                  "incxml"
#define IFX_TR69_MISC_INCLUDESOAPACTION           "incsoapact"
#define IFX_TR69_MISC_ACSGETRPC                   "acsgetrpc"
#define IFX_TR69_MISC_BOOTSTRAP                   "bootstrap"
#define IFX_TR69_MISC_TR69ENABLE                  "tr69enable"
#define IFX_TR69_MISC_TR64ENABLE                  "tr64enable"
#define IFX_TR69_MISC_UPNPENABLE                  "upnpenable"
#define IFX_TR69_MISC_TR64PORT			  "tr64port"
#define IFX_TR69_MISC_UPNPPORT			  "upnpport"
#define IFX_TR69_MISC_PREVIOUSTIME                "prevtime"
#define IFX_TR69_MISC_URLSTATUS                   "urlstatus"

#define IFX_IPPING_DIAG_SECTION                   "ipping_diag"
#define IFX_IPPING_DIAG_DIAGSTATE                 "diagstate"
#define IFX_IPPING_DIAG_INTERFACE                 "interface"
#define IFX_IPPING_DIAG_HOST                      "host"
#define IFX_IPPING_DIAG_NUMREPEAT                 "numrepeat"
#define IFX_IPPING_DIAG_TIMEOUT                   "timeout"
#define IFX_IPPING_DIAG_DATASIZE                  "datasize"
#define IFX_IPPING_DIAG_DSCP                      "dscp"
#define IFX_IPPING_DIAG_SUCCESSCNT                "successcnt"
#define IFX_IPPING_DIAG_FAILURECNT                "failurecnt"
#define IFX_IPPING_DIAG_AVGRESPTIME               "avgresptime"
#define IFX_IPPING_DIAG_MINRESPTIME               "minresptime"
#define IFX_IPPING_DIAG_MAXRESPTIME               "maxresptime"

#define IFX_LAN_CONF_SECURITY_SECTION             "lanconf_security"
#define IFX_LAN_CONF_CONFPASSWORD                 "confPassword"
#define IFX_LAN_CONF_RESETPASSWORD                "resetPassword"

#if 1				// traceroute
#define IFX_TRACEROUTE_DIAG_SECTION               "traceroute_diag"
#define IFX_TRACEROUTE_DIAG_DIAGSTATE             "diagstate"
#define IFX_TRACEROUTE_DIAG_INTERFACE             "interface"
#define IFX_TRACEROUTE_DIAG_HOST                  "host"
#define IFX_TRACEROUTE_DIAG_NUMTRY                "numtry"
#define IFX_TRACEROUTE_DIAG_TIMEOUT               "timeout"
#define IFX_TRACEROUTE_DIAG_DATASIZE              "datasize"
#define IFX_TRACEROUTE_DIAG_DSCP                  "dscp"
#define IFX_TRACEROUTE_DIAG_MAXHOPCNT             "maxhopcnt"
#define IFX_TRACEROUTE_DIAG_RESPTIME              "resptime"
#define IFX_TRACEROUTE_DIAG_NUMOFROUTEHOPS        "numofroutehops"

#define IFX_ROUTEHOPS_SECTION             "traceroute_routehops"
#define IFX_ROUTEHOPS_HOPHOST             "hophost"
#define IFX_ROUTEHOPS_HOPHOSTADDR         "hophostaddr"
#define IFX_ROUTEHOPS_HOPERRCODE          "hoperrcode"
#define IFX_ROUTEHOPS_HOPRTTTIMES         "hoprtttimes"

#define IFX_TR69_MAP_SECTION                       "tr69_map"
#endif

// nslookup
#define IFX_NSLOOKUP_DIAG_SECTION               "nslookup_diag"
#define IFX_NSLOOKUP_DIAG_DIAGSTATE             "diagstate"
#define IFX_NSLOOKUP_DIAG_INTERFACE             "interface"
#define IFX_NSLOOKUP_DIAG_HOSTNAME              "hostname"
#define IFX_NSLOOKUP_DIAG_DNSSERVER             "dnssrvr"
#define IFX_NSLOOKUP_DIAG_TIMEOUT               "timeout"
#define IFX_NSLOOKUP_DIAG_NUMBEROFREPETITIONS   "numberofrepetitions"
#define IFX_NSLOOKUP_DIAG_SUCCESSCOUNT          "successcount"
#define IFX_NSLOOKUP_DIAG_RESULTNUMBEROFENTRIES "resultnumberofentries"



#define IFX_RESULT_SECTION             "nslookup_result"
#define IFX_RESULT_STATUS              "status"
#define IFX_RESULT_ANSWERTYPE          "anstype"
#define IFX_RESULT_HOSTNAMERETURNED    "hostnameret"
#define IFX_RESULT_IPADDRESSES         "ipaddrs"
#define IFX_RESULT_DNSSERVERIP         "dnssrvrip"
#define IFX_RESULT_RESPONSETIME        "resptime"


#define IFX_QUEUED_DOWNLOAD_SECTION                "queued_download"
#define IFX_QUEUED_DOWNLOAD_COUNT                  "count"
#define IFX_QUEUED_DOWNLOAD_NEXT_QUEUED_IDX        "next_queued_idx"
#define IFX_QUEUED_DOWNLOAD_COMMANDKEY             "CommandKey"
#define IFX_QUEUED_DOWNLOAD_FILETYPE               "FileType"
#define IFX_QUEUED_DOWNLOAD_FILENAME               "FileName"
#define IFX_QUEUED_DOWNLOAD_USERNAME               "Username"
#define IFX_QUEUED_DOWNLOAD_PASSWORD               "Password"
#define IFX_QUEUED_DOWNLOAD_FILESIZE               "Filesize"
#define IFX_QUEUED_DOWNLOAD_FUTURETIME             "FutureTime"
#define IFX_QUEUED_DOWNLOAD_STARTTIME              "StartTime"
#define IFX_QUEUED_DOWNLOAD_ENDTIME                "EndTime"
#define IFX_QUEUED_DOWNLOAD_STATUS                 "Status"
#define IFX_QUEUED_DOWNLOAD_CPEID                  "cpeId"
#define IFX_DOWNLOAD_STATUS_COMPLETE               "0"
#define IFX_DOWNLOAD_STATUS_NONE                   "-1"
#define IFX_DOWNLOAD_STATUS_ERROR                  "9010"
#define IFX_DOWNLOAD_STATUS_NOTSTARTED             "3"
#define IFX_DOWNLOAD_STATUS_PENDING                "1"
#define MIN_QUEUED_DOWNLOAD_TIME_DIFF              250
#define IFX_QUEUED_DOWNLOAD_IS_COMPLETE            "is_Complete"

#define IFX_QUEUED_UPLOAD_SECTION                "queued_upload"
#define IFX_QUEUED_UPLOAD_COUNT                  "count"
#define IFX_QUEUED_UPLOAD_NEXT_QUEUED_IDX        "next_queued_idx"
#define IFX_QUEUED_UPLOAD_COMMANDKEY             "CommandKey"
#define IFX_QUEUED_UPLOAD_FILETYPE               "FileType"
#define IFX_QUEUED_UPLOAD_FILENAME               "FileName"
#define IFX_QUEUED_UPLOAD_USERNAME               "Username"
#define IFX_QUEUED_UPLOAD_PASSWORD               "Password"
#define IFX_QUEUED_UPLOAD_FILESIZE               "Filesize"
#define IFX_QUEUED_UPLOAD_FUTURETIME             "FutureTime"
#define IFX_QUEUED_UPLOAD_STARTTIME              "StartTime"
#define IFX_QUEUED_UPLOAD_ENDTIME                "EndTime"
#define IFX_QUEUED_UPLOAD_STATUS                 "Status"
#define IFX_QUEUED_UPLOAD_CPEID                  "cpeId"
#define IFX_UPLOAD_STATUS_COMPLETE               "0"
#define IFX_UPLOAD_STATUS_NONE                   "-1"
#define IFX_UPLOAD_STATUS_ERROR                  "9011"
#define IFX_UPLOAD_STATUS_NOTSTARTED             "3"
#define IFX_UPLOAD_STATUS_PENDING                "1"
#define IFX_QUEUED_UPLOAD_IS_COMPLETE            "is_Complete"
#define IFX_MAX_QUEUED_ENTRY                     3

#define IFX_QUEUED_TRANSFERS_STATUS_NOTSTARTED       1
#define IFX_QUEUED_TRANSFERS_STATUS_IN_PROGRESS      2
#define IFX_QUEUED_TRANSFERS_STATUS_COMPLETED        3
#define IFX_QUEUED_TRANSFERS_STATUS_NONE            -1
#define IFX_QUEUED_TRANSFERS_STATUS_INCOMPLETE       0

#define IFX_DOWNLOAD_DIAG_SECTION               "download_diag"
#define IFX_DOWNLOAD_DIAG_DIAGSTATE             "diagstate"
#define IFX_DOWNLOAD_DIAG_INTERFACE             "iface"
#define IFX_DOWNLOAD_DIAG_DWNLDURL              "dwnldurl"
#define IFX_DOWNLOAD_DIAG_ETHERNETPRIORITY      "ethernet_priority"
#define IFX_DOWNLOAD_DIAG_ROMTIME               "ROMTime"
#define IFX_DOWNLOAD_DIAG_BOMTIME               "BOMTime"
#define IFX_DOWNLOAD_DIAG_EOMTIME               "EOMTime"
#define IFX_DOWNLOAD_DIAG_RXTESTBYTES           "rxtestbytes"
#define IFX_DOWNLOAD_DIAG_RXTOTALBYTES          "rxtotalbytes"
#define IFX_DOWNLOAD_DIAG_TCPOPENRQSTTIME       "tcp_open_rqst_time"
#define IFX_DOWNLOAD_DIAG_TCPOPENRESPTIME       "tcp_open_resp_time"
#define IFX_DOWNLOAD_DIAG_DSCP                  "dscp"


#define IFX_UPLOAD_DIAG_SECTION               "upload_diag"
#define IFX_UPLOAD_DIAG_DIAGSTATE             "diagstate"
#define IFX_UPLOAD_DIAG_INTERFACE             "iface"
#define IFX_UPLOAD_DIAG_UPLDURL               "upldurl"
#define IFX_UPLOAD_DIAG_ETHERNETPRIORITY      "ethernet_priority"
#define IFX_UPLOAD_DIAG_ROMTIME               "ROMTime"
#define IFX_UPLOAD_DIAG_BOMTIME               "BOMTime"
#define IFX_UPLOAD_DIAG_EOMTIME               "EOMTime"
#define IFX_UPLOAD_DIAG_TESTFILELENGTH        "test_file_len"
#define IFX_UPLOAD_DIAG_TXTOTALBYTES          "txtotalbytes"
#define IFX_UPLOAD_DIAG_TCPOPENRQSTTIME       "tcp_open_rqst_time"
#define IFX_UPLOAD_DIAG_TCPOPENRESPTIME       "tcp_open_resp_time"
#define IFX_UPLOAD_DIAG_DSCP                  "dscp"

#define IFX_SCHEDULE_DOWNLOAD_SECTION                "schedule_download"
#define IFX_SCHEDULE_DOWNLOAD_COUNT                  "count"
#define IFX_SCHEDULE_DOWNLOAD_NEXT_QUEUED_IDX        "next_queued_idx"
#define IFX_SCHEDULE_DOWNLOAD_COMMANDKEY             "CommandKey"
#define IFX_SCHEDULE_DOWNLOAD_FILETYPE               "FileType"
#define IFX_SCHEDULE_DOWNLOAD_FILENAME               "FileName"
#define IFX_SCHEDULE_DOWNLOAD_URL                    "URL"
#define IFX_SCHEDULE_DOWNLOAD_USERNAME               "Username"
#define IFX_SCHEDULE_DOWNLOAD_PASSWORD               "Password"
#define IFX_SCHEDULE_DOWNLOAD_FILESIZE               "Filesize"
#define IFX_SCHEDULE_DOWNLOAD_FUTURETIME             "FutureTime"
#define IFX_SCHEDULE_DOWNLOAD_STARTTIME              "StartTime"
#define IFX_SCHEDULE_DOWNLOAD_ENDTIME                "EndTime"
#define IFX_SCHEDULE_DOWNLOAD_STATUS                 "Status"
#define IFX_SCHEDULE_DOWNLOAD_CPEID                  "cpeId"
#define IFX_SCHEDULE_DOWNLOAD_IS_COMPLETE            "is_Complete"
#define IFX_SCHEDULE_DOWNLOAD_WINDOW1_START          "Window1_Start"
#define IFX_SCHEDULE_DOWNLOAD_WINDOW1_END            "Window1_End"
#define IFX_SCHEDULE_DOWNLOAD_WINDOW1_MODE           "Window1_Mode"
#define IFX_SCHEDULE_DOWNLOAD_WINDOW1_USERMSG        "Window1_UserMsg"
#define IFX_SCHEDULE_DOWNLOAD_WINDOW1_MAXRETRIES     "Window1_MaxRetries"
#define IFX_SCHEDULE_DOWNLOAD_WINDOW2_START          "Window2_Start"
#define IFX_SCHEDULE_DOWNLOAD_WINDOW2_END            "Window2_End"
#define IFX_SCHEDULE_DOWNLOAD_WINDOW2_MODE           "Window2_Mode"
#define IFX_SCHEDULE_DOWNLOAD_WINDOW2_USERMSG        "Window2_UserMsg"
#define IFX_SCHEDULE_DOWNLOAD_WINDOW2_MAXRETRIES     "Window2_MaxRetries"


#define IFX_SDL_INFO_SECTION                  "sdl_info"
#define IFX_SDL_INFO_COMMANDKEY               "cmdkey"
#define IFX_SDL_INFO_FILETYPE                 "filetype"
#define IFX_SDL_INFO_STATUS                   "status"
#define IFX_SDL_INFO_STARTTIME                "starttime"
#define IFX_SDL_INFO_ENDTIME                  "endtime"
#define IFX_SDL_INFO_FUTURETIME               "futuretime"
#define IFX_SDL_INFO_FILENAME                 "filename"



#define IFX_VENDOR_CONF_FILE_SECTION	"vendorconfigfile"

#define MAKE_PARAM_ELEMENT_TAG(tag_prefix, index, field, buf)  sprintf(buf, "%s_%d_%s", tag_prefix, index, field);

/* ORP - SHould be moved to ifx_amazon_cfg.h */
#define TAG_DHCP_OPTION                     "dhcp_opt"
#define PREFIX_DHCP_OPTION              "dhcp_opt"
#define TAG_LAN_MAIN                        "lan_main"
/* Should go with MAPI  dhcp_option.c file */
#define DHCP_OPTION_PARAM_COUNT   6
char8 *dhcp_opt_params[] = { "cpeId", "pcpeId", "ena", "req", "tag", "val" };

/* Would come from ifx_api_util.h . Placed here to resolve compilation errors */
int32 ifx_fill_ArrayFvp_FName(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index,
			      int32 nDataCount, char8 * pData[]);
int32 ifx_fill_ArrayFvp_intValues(IFX_NAME_VALUE_PAIR arrayFvp[],
				  int32 start_index, int32 nDataCount,
				  int32 * pData, ...);
int32 ifx_fill_ArrayFvp_strValues(IFX_NAME_VALUE_PAIR arrayFvp[],
				  int32 start_index, int32 nDataCount,
				  char8 * pData, ...);

// #ifdef IFX_DBG
// #undef IFX_DBG
// #define IFX_DBG(fmt, args...)    
// #endif

/* =============================================================================
**                                <LOCAL TYPES>
** =============================================================================
*/

/* =============================================================================
**                                 <LOCAL DATA>
** =============================================================================
*/

/* =============================================================================
**                           <LOCAL FUNCTION PROTOTYPES>
** =============================================================================
*/

/* =============================================================================
**                               <LOCAL FUNCTIONS>
** =============================================================================
*/

/* =============================================================================
**                             <EXPORTED FUNCTIONS>
** =============================================================================
*/
extern int32 ifx_copy_file(char8 * src_file, char8 * dst_file);
extern int32 ifx_get_IID(IFX_ID * passed_iid, char8 * distinct_param);

#if 1				//traceroute
extern int32 ifx_GetSection(const char8 * pFileName, const char8 * pTag,
			    char8 ** pRetSec, uint32 * secPosition);
#endif

int32 ifx_get_lan_conf_security(char8 * ConfPassword, char8 * ResetPassword)
{
	int32 iRtn = IFX_SUCCESS;
	char8 sVal[MAX_FILELINE_LEN];
	uint32 flags = IFX_F_GET_ANY;
	uint32 ulOutFlag;

	memset(sVal, '\0', MAX_FILELINE_LEN);
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_LAN_CONF_SECURITY_SECTION,
				   IFX_LAN_CONF_SECURITY_SECTION "_"
				   IFX_LAN_CONF_CONFPASSWORD, flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get LANConfigSec Conf Password !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}

	strcpy(ConfPassword, sVal);

	memset(sVal, '\0', MAX_FILELINE_LEN);
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_LAN_CONF_SECURITY_SECTION,
				   IFX_LAN_CONF_SECURITY_SECTION "_"
				   IFX_LAN_CONF_RESETPASSWORD, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get LANConfigSec Reset Password !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}

	strcpy(ResetPassword, sVal);

	return IFX_SUCCESS;

      IFX_Handler:
	return iRtn;

}

int32 ifx_set_lan_conf_security(int32 operation, char8 * password, uint32 flags)
{
	int count = 0, ret = IFX_SUCCESS;
	uint32 changed_fcount = 0;
	char8 buf[MAX_DATA_LEN];
	char8 sConfPassword[65] = { 0 };
	char8 sResetPassword[65] = { 0 };
	IFX_ID iid;
	IFX_NAME_VALUE_PAIR array_fvp[MAX_FIELD_RANGE], *array_changed_fvp =
	    NULL;

	memset(buf, 0, sizeof(buf));
	memset(&iid, 0, sizeof(iid));
	memset(array_fvp, 0, sizeof(array_fvp));

    /***  PROLOG BLOCK  ***/

	/* Append internal flags */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_MOD)
		flags |= IFX_F_MODIFY;
	else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
		flags |= IFX_F_INT_ADD;

    /********  VALIDATION BLOCK  ***********/
	/* For ops other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags)) {
	/*** Validation Checking Block ***/
		if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
			/* Do simple validation of pointer such as NULL */
			// IFX_VALIDATE_PTR(mgmt_server)
			/* Do simple validation of flags such as less than 0 */
			IFX_VALIDATE_FLAGS(flags)
		}
	}

    /*******  VALIDATION BLOCK END *********/

	/* Read the iid structure from rc.conf */
	// iid = mgmt_server->iid;
	// strcpy(iid.cpeId.secName, IFX_LAN_CONF_SECURITY_SECTION);
	if (ifx_get_iid_from_conf
	    (&iid, FILE_RC_CONF, IFX_LAN_CONF_SECURITY_SECTION)
	    != IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

   /********** Get the resetPassword from DB file **************/
	if (ifx_get_lan_conf_security(sConfPassword, sResetPassword) !=
	    IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

    /*********** Name Value Formation As Per RC.CONF ****************/
	/* Build the API Specific name value pair */
	sprintf(array_fvp[0].fieldname, "%s_%s", IFX_LAN_CONF_SECURITY_SECTION,
		"cpeId");
	sprintf(array_fvp[0].value, "%d", iid.cpeId.Id);
	sprintf(array_fvp[1].fieldname, "%s_%s", IFX_LAN_CONF_SECURITY_SECTION,
		"pcpeId");
	sprintf(array_fvp[1].value, "%d", iid.pcpeId.Id);
	sprintf(array_fvp[2].fieldname, "%s_%s", IFX_LAN_CONF_SECURITY_SECTION,
		IFX_LAN_CONF_CONFPASSWORD);
	sprintf(array_fvp[2].value, "%s", password);
	sprintf(array_fvp[3].fieldname, "%s_%s", IFX_LAN_CONF_SECURITY_SECTION,
		IFX_LAN_CONF_RESETPASSWORD);
	sprintf(array_fvp[3].value, "%s", sResetPassword);
	count = 4;

    /***  PROLOG BLOCK END  ***/

    /**************** ACL CHECK BLOCK *****************/

	CHECK_ACL_RET(iid, count, array_fvp,
		      changed_fcount, array_changed_fvp, flags, IFX_Handler)

    /**************** ACL CHECK BLOCK END *****************/
    /********* SYSTEM CONFIG FILE UPDATE BLOCK  **********/
	    /* Convert the name value pair in array_fvp into string format expected 
	       by rc.conf file */
	    if (IFX_MODIFY_F_SET(flags)) {
		// form_cfgdb_buf(buf, changed_fcount, array_changed_fvp);
		form_cfgdb_buf(buf, count, array_fvp);
	} else {
		form_cfgdb_buf(buf, count, array_fvp);
	}

	/* Backup rc.conf before proceeding with configuration */
	CHECKPOINT_RET(flags, FILE_RC_CONF, CHKPOINT_FILE, IFX_Handler)

	    /* Update rc.conf */
	    ret =
	    ifx_SetObjData(FILE_RC_CONF, IFX_LAN_CONF_SECURITY_SECTION, flags,
			   1, buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup
	   rc.conf */
	if (ret != IFX_SUCCESS) {
		ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE,
				    flags | IFX_F_INT_DONT_RESTART_SERVICES,
				    IFX_Handler)
	}

    /********* SYSTEM CONFIG FILE UPDATE BLOCK END **********/

    /************ DEVICE CONFIGURATION BLOCK ***********/
    /************ DEVICE CONFIGURATION BLOCK END ***********/

    /**************** NOTIFICATION BLOCK ******************/

	/* Notify the Internal TR69 Stack */
	CHECK_N_SEND_NOTIFICATION(iid, changed_fcount, array_changed_fvp, flags,
				  IFX_Handler)

    /**************** NOTIFICATION BLOCK ******************/
    /***************** EPILOG BLOCK **********************/
	    ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE,
				    flags | IFX_F_INT_DONT_RESTART_SERVICES,
				    IFX_Handler)
	}
    /***************** EPILOG BLOCK END **********************/

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	    if (ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}

/* function is used to set defualt port in url in case of url is 
   not specified by user 
   port  --> Get info whether url contains port or not
   pAURL --> Actual url
   type  --> 1 for https,0 for http
   return value --> returns url with default port append to actual url

*/
static void parse_url(char *port, char *pAURL,int type)
{

   char https_port[5] = ":443";
   char http_port[4] = ":80";
   char tmp_url[256] = { 0 };
   char buf[20]={0};
   int i=0,check=0;

   while (*port != '\0'){  //copy charters after '\' to local buf
      buf[i]=*port;
      i++;
      port++;
   }
   buf[i]='\0';
   i=0;
   while ( pAURL[i] != '\0'){
      if (pAURL[i] == '/'){
         check++;
      }
      if(check != 3 )
         tmp_url[i]=pAURL[i];
         i++;
   }
/*assign port based on the type*/
   if( type == 1 ){
       strcat(tmp_url,https_port);
       strcat(tmp_url,buf);
    }else{
       strcat(tmp_url,http_port);
       strcat(tmp_url,buf);
    }

    pAURL[0]='\0';
    strcpy(pAURL,tmp_url);
    pAURL[strlen(pAURL)+1]='\0';
}


int32
ifx_set_mgmt_server(int32 operation, MGMT_SERVER * mgmt_server, uint32 flags)
{
	int count = 0, ret = IFX_SUCCESS;
	uint32 changed_fcount = 0;
	char8 buf[MAX_DATA_LEN];
	IFX_ID iid;
	IFX_NAME_VALUE_PAIR array_fvp[MAX_FIELD_RANGE], *array_changed_fvp =
	    NULL;

	char *port = NULL;

	memset(buf, 0, sizeof(buf));
	memset(&iid, 0, sizeof(iid));
	memset(array_fvp, 0, sizeof(array_fvp));

    /***  PROLOG BLOCK  ***/

	/* Append internal flags */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_MOD)
		flags |= IFX_F_MODIFY;
	else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
		flags |= IFX_F_INT_ADD;

    /********  VALIDATION BLOCK  ***********/
	/* For ops other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags)) {
	/*** Validation Checking Block ***/
		if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
			/* Do simple validation of pointer such as NULL */
			IFX_VALIDATE_PTR(mgmt_server)
			    /* Do simple validation of flags such as less than 0 */
			    IFX_VALIDATE_FLAGS(flags)
		}
	}

    /*******  VALIDATION BLOCK END *********/

	/* Read the iid structure from rc.conf */
	iid = mgmt_server->iid;
	if (ifx_get_iid_from_conf(&iid, FILE_RC_CONF, IFX_MGMT_SERVER_SECTION)
	    != IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
      	
	if(!strncmp(mgmt_server->url,"https://", strlen("https://")))
      	{
            port = strchr((mgmt_server->url)+strlen("https://"),':');
            if (port == NULL)     // ':' character not found append default port.
            {
               port = strchr((mgmt_server->url)+strlen("https://"),'/');
               if (port != NULL){
                  parse_url(port,mgmt_server->url,1); 
#ifdef IFX_LOG_DEBUG
                  IFX_DBG("[%s:%d]URL #########received : %s \n",__func__,__LINE__,mgmt_server->url);
#endif
                  }else{
                  strcat(mgmt_server->url,":443");
#ifdef IFX_LOG_DEBUG
                  IFX_DBG("[%s:%d]URL #########received : %s \n",__func__,__LINE__,mgmt_server->url);
#endif
                  }
             }
        }else{
               port = strchr((mgmt_server->url)+strlen("http://"),':');
               if (port == NULL)
               {
                  port = strchr((mgmt_server->url)+strlen("http://"),'/');
                  if (port != NULL){
                     parse_url(port,mgmt_server->url,0);
#ifdef IFX_LOG_DEBUG
                     IFX_DBG("[%s:%d]URL #########received : %s \n",__func__,__LINE__,mgmt_server->url);
#endif
              	  }else{
                    strcat(mgmt_server->url,":80");
#ifdef IFX_LOG_DEBUG
                    IFX_DBG("[%s:%d]URL #########received : %s \n",__func__,__LINE__,mgmt_server->url);
#endif
              	  }
             }
        }

    /*********** Name Value Formation As Per RC.CONF ****************/
	/* Build the API Specific name value pair */
	sprintf(array_fvp[0].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		"cpeId");
	sprintf(array_fvp[0].value, "%d", iid.cpeId.Id);
	sprintf(array_fvp[1].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		"pcpeId");
	sprintf(array_fvp[1].value, "%d", iid.pcpeId.Id);
	sprintf(array_fvp[2].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		IFX_MGMT_SERVER_URL);
	sprintf(array_fvp[2].value, "%s", mgmt_server->url);
	sprintf(array_fvp[3].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		IFX_MGMT_SERVER_USERNAME);
	sprintf(array_fvp[3].value, "%s", mgmt_server->uname);
	sprintf(array_fvp[4].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		IFX_MGMT_SERVER_PASSWORD);
	sprintf(array_fvp[4].value, "%s", mgmt_server->passwd);
	sprintf(array_fvp[5].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		IFX_MGMT_SERVER_PERIODICINFORMENABLE);
	sprintf(array_fvp[5].value, "%d", mgmt_server->period_inform_enable);
	sprintf(array_fvp[6].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		IFX_MGMT_SERVER_PERIODICINFORMINTERVAL);
	sprintf(array_fvp[6].value, "%u", mgmt_server->period_inform_interval);
	sprintf(array_fvp[7].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		IFX_MGMT_SERVER_PERIODICINFORMTIME);
	sprintf(array_fvp[7].value, "%u", mgmt_server->period_abs_inform_time);
	sprintf(array_fvp[8].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		IFX_MGMT_SERVER_PARAMETERKEY);
	sprintf(array_fvp[8].value, "%s", mgmt_server->parameter_key);
	sprintf(array_fvp[9].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		IFX_MGMT_SERVER_CONNECTIONREQUESTURL);
	sprintf(array_fvp[9].value, "%s", mgmt_server->conn_req_url);
	sprintf(array_fvp[10].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		IFX_MGMT_SERVER_CONNECTIONREQUESTUSERNAME);
	sprintf(array_fvp[10].value, "%s", mgmt_server->conn_req_uname);
	sprintf(array_fvp[11].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		IFX_MGMT_SERVER_CONNECTIONREQUESTPASSWORD);
	sprintf(array_fvp[11].value, "%s", mgmt_server->conn_req_passwd);
	sprintf(array_fvp[12].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		IFX_MGMT_SERVER_UPGRADESMANAGED);
	sprintf(array_fvp[12].value, "%d", mgmt_server->upgrades_managed);

	/* TR111 related parameters */
	sprintf(array_fvp[13].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		IFX_MGMT_SERVER_UDPCONNREQADDRESS);
	sprintf(array_fvp[13].value, "%s", mgmt_server->udp_conn_req_url);
	sprintf(array_fvp[14].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		IFX_MGMT_SERVER_UDPCONNREQADDRESSNOTIFYLIMIT);
	sprintf(array_fvp[14].value, "%d",
		mgmt_server->udp_conn_req_address_notification_limit);
	sprintf(array_fvp[15].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		IFX_MGMT_SERVER_STUNENABLE);
	sprintf(array_fvp[15].value, "%d", mgmt_server->stun_enable);
	sprintf(array_fvp[16].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		IFX_MGMT_SERVER_STUNSERVERADDRESS);
	// sprintf(array_fvp[15].value, "%d", mgmt_server->stun_server_address); 
	strncpy(array_fvp[16].value,
		inet_ntoa(mgmt_server->stun_server_address), (MAX_IP_ADDR_LEN));
	sprintf(array_fvp[17].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		IFX_MGMT_SERVER_STUNSERVERPORT);
	sprintf(array_fvp[17].value, "%d", mgmt_server->stun_server_port);
	sprintf(array_fvp[18].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		IFX_MGMT_SERVER_STUNUSERNAME);
	sprintf(array_fvp[18].value, "%s", mgmt_server->stun_server_uname);
	sprintf(array_fvp[19].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		IFX_MGMT_SERVER_STUNPASSWORD);
	sprintf(array_fvp[19].value, "%s", mgmt_server->stun_passwd);
	sprintf(array_fvp[20].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		IFX_MGMT_SERVER_STUNMAXKEEPALIVEPERIOD);
	sprintf(array_fvp[20].value, "%d",
		mgmt_server->stun_max_keep_alive_period);
	sprintf(array_fvp[21].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		IFX_MGMT_SERVER_STUNMINKEEPALIVEPERIOD);
	sprintf(array_fvp[21].value, "%d",
		mgmt_server->stun_min_keep_alive_period);
	sprintf(array_fvp[22].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		IFX_MGMT_SERVER_STUNNATDETECTED);
	sprintf(array_fvp[22].value, "%d", mgmt_server->nat_detected);
	sprintf(array_fvp[23].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
		IFX_MGMT_SERVER_MNGDEVICENOTIFYLIMIT);
	sprintf(array_fvp[23].value, "%d", mgmt_server->mngdevnotifylimit);
        sprintf(array_fvp[24].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION,
                IFX_MGMT_SERVER_ENABLECWMP);
        sprintf(array_fvp[24].value, "%d", mgmt_server->enable_cwmp);


	count = 25;

    /***  PROLOG BLOCK END  ***/

    /**************** ACL CHECK BLOCK *****************/

	CHECK_ACL_RET(iid, count, array_fvp,
		      changed_fcount, array_changed_fvp, flags, IFX_Handler)

    /**************** ACL CHECK BLOCK END *****************/
    /********* SYSTEM CONFIG FILE UPDATE BLOCK  **********/
	    /* Convert the name value pair in array_fvp into string format expected 
	       by rc.conf file */
	    if (IFX_MODIFY_F_SET(flags)) {
		// form_cfgdb_buf(buf, changed_fcount, array_changed_fvp);
		form_cfgdb_buf(buf, count, array_fvp);
	} else {
		form_cfgdb_buf(buf, count, array_fvp);
	}

	/* Backup rc.conf before proceeding with configuration */
	CHECKPOINT_RET(flags, FILE_RC_CONF, CHKPOINT_FILE, IFX_Handler)

	    /* Update rc.conf */
	    IFX_DBG("mgmt buf [%s]", buf);
	ret =
	    ifx_SetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION, flags, 1,
			   buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup
	   rc.conf */
	if (ret != IFX_SUCCESS) {
		ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE,
				    flags | IFX_F_INT_DONT_RESTART_SERVICES,
				    IFX_Handler)
		    goto IFX_Handler;
	}

    /********* SYSTEM CONFIG FILE UPDATE BLOCK END **********/

    /************ DEVICE CONFIGURATION BLOCK ***********/
    /************ DEVICE CONFIGURATION BLOCK END ***********/

    /**************** NOTIFICATION BLOCK ******************/

	/* Notify the Internal TR69 Stack */
	CHECK_N_SEND_NOTIFICATION(iid, changed_fcount, array_changed_fvp, flags,
				  IFX_Handler)

    /**************** NOTIFICATION BLOCK ******************/
    /***************** EPILOG BLOCK **********************/
	    ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE,
				    flags | IFX_F_INT_DONT_RESTART_SERVICES,
				    IFX_Handler)
	}
    /***************** EPILOG BLOCK END **********************/
	system("echo mgmt server set done >> /tmp/t_log");

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	    if (ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}

int32 ifx_get_mgmt_server(MGMT_SERVER * mgmt_server, uint32 flags)
{
	int32 iRtn = IFX_SUCCESS;
	char8 sVal[MAX_FILELINE_LEN];
	uint32 ulOutFlag;
	MGMT_SERVER xMS;

	memset(&xMS, 0, sizeof(xMS));

	memset(sVal, '\0', MAX_FILELINE_LEN);
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
				   IFX_MGMT_SERVER_SECTION "_"
				   IFX_MGMT_SERVER_URL, flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get URL !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_URL_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> URL len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xMS.url, sVal, MAX_URL_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
				   IFX_MGMT_SERVER_SECTION "_"
				   IFX_MGMT_SERVER_USERNAME, flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get UserName !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_UNAME_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> UserName len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xMS.uname, sVal, MAX_UNAME_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
				   IFX_MGMT_SERVER_SECTION "_"
				   IFX_MGMT_SERVER_PASSWORD, flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get Password !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_PASSWORD_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Password len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xMS.passwd, sVal, MAX_PASSWORD_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
				   IFX_MGMT_SERVER_SECTION "_"
				   IFX_MGMT_SERVER_PERIODICINFORMENABLE, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get PeriodicInformEnable !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMS.period_inform_enable = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
				   IFX_MGMT_SERVER_SECTION "_"
				   IFX_MGMT_SERVER_PERIODICINFORMINTERVAL,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get PeriodicInformInterval !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMS.period_inform_interval = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
				   IFX_MGMT_SERVER_SECTION "_"
				   IFX_MGMT_SERVER_PERIODICINFORMTIME, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get PeriodicInformTime !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMS.period_abs_inform_time = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
				   IFX_MGMT_SERVER_SECTION "_"
				   IFX_MGMT_SERVER_PARAMETERKEY, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get ParameterKey !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_PARAMETER_KEY_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> ParameterKey len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xMS.parameter_key, sVal, MAX_PARAMETER_KEY_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
				   IFX_MGMT_SERVER_SECTION "_"
				   IFX_MGMT_SERVER_CONNECTIONREQUESTURL, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get ConnectionRequestURL !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_CONN_REQ_URL_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> ConnectionRequestURL len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xMS.conn_req_url, sVal, MAX_CONN_REQ_URL_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
				   IFX_MGMT_SERVER_SECTION "_"
				   IFX_MGMT_SERVER_CONNECTIONREQUESTUSERNAME,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get ConnectionRequestUserName !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_CONN_REQ_UNAME_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> ConnectionRequestUserName len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xMS.conn_req_uname, sVal, MAX_CONN_REQ_UNAME_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
				   IFX_MGMT_SERVER_SECTION "_"
				   IFX_MGMT_SERVER_CONNECTIONREQUESTPASSWORD,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get ConnectionRequestPassword !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_CONN_REQ_PASSWD_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> ConnectionRequestPassword len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xMS.conn_req_passwd, sVal, MAX_CONN_REQ_PASSWD_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
				   IFX_MGMT_SERVER_SECTION "_"
				   IFX_MGMT_SERVER_UPGRADESMANAGED, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get UpgradesManaged !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMS.upgrades_managed = atoi(sVal);

   /****** TR-111 related parameters ************/

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
				   IFX_MGMT_SERVER_SECTION "_"
				   IFX_MGMT_SERVER_UDPCONNREQADDRESS, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get udpconrequrl !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_CONN_REQ_URL_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> udpconrequrl len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xMS.udp_conn_req_url, sVal, MAX_CONN_REQ_URL_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
				   IFX_MGMT_SERVER_SECTION "_"
				   IFX_MGMT_SERVER_UDPCONNREQADDRESSNOTIFYLIMIT,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get udpconreqnotifylimit !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMS.udp_conn_req_address_notification_limit = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
				   IFX_MGMT_SERVER_SECTION "_"
				   IFX_MGMT_SERVER_STUNENABLE, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get stunenable !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMS.stun_enable = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
				   IFX_MGMT_SERVER_SECTION "_"
				   IFX_MGMT_SERVER_STUNSERVERADDRESS, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get stunserveripaddress !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	// xMS.stun_enable= atoi(sVal);
	if (strcmp(sVal, "") == 0)
		LTQ_STRNCPY(sVal, "0.0.0.0", MAX_FILELINE_LEN);
	if ((inet_aton(sVal, &(xMS.stun_server_address))) == 0) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get stunserveripaddress !!\n\n",
		     __FUNCTION__);
		iRtn = IFX_FAILURE;
		goto IFX_Handler;
	}

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
				   IFX_MGMT_SERVER_SECTION "_"
				   IFX_MGMT_SERVER_STUNSERVERPORT, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get stunserverport !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMS.stun_server_port = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
				   IFX_MGMT_SERVER_SECTION "_"
				   IFX_MGMT_SERVER_STUNUSERNAME, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get stunusername !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_CONN_REQ_UNAME_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> stunusername len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xMS.stun_server_uname, sVal, MAX_CONN_REQ_UNAME_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
				   IFX_MGMT_SERVER_SECTION "_"
				   IFX_MGMT_SERVER_STUNPASSWORD, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get stunpasswd !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_CONN_REQ_PASSWD_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> stunpasswd len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xMS.stun_passwd, sVal, MAX_CONN_REQ_PASSWD_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
				   IFX_MGMT_SERVER_SECTION "_"
				   IFX_MGMT_SERVER_STUNMAXKEEPALIVEPERIOD,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get stunmaxkeepalivetime !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMS.stun_max_keep_alive_period = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
				   IFX_MGMT_SERVER_SECTION "_"
				   IFX_MGMT_SERVER_STUNMINKEEPALIVEPERIOD,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get stunminkeepalivetime !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMS.stun_min_keep_alive_period = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
				   IFX_MGMT_SERVER_SECTION "_"
				   IFX_MGMT_SERVER_STUNNATDETECTED, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get natdetected !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMS.nat_detected = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
				   IFX_MGMT_SERVER_SECTION "_"
				   IFX_MGMT_SERVER_MNGDEVICENOTIFYLIMIT, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get mngdevnotifylimit !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMS.mngdevnotifylimit = atoi(sVal);

        memset(sVal, '\0', sizeof(sVal));
        if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
                                   IFX_MGMT_SERVER_SECTION "_"
                                   IFX_MGMT_SERVER_ENABLECWMP, flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
                IFX_DBG
                    ("\n\n In Function [%s] : Error--> Failed to get PeriodicInformEnable !!\n\n",
                     __FUNCTION__);
                goto IFX_Handler;
        }
        xMS.enable_cwmp = atoi(sVal);


	/* Fill the structure to be returned to the user */
	LTQ_STRNCPY(mgmt_server->url, xMS.url, MAX_URL_LEN);
	LTQ_STRNCPY(mgmt_server->uname, xMS.uname, MAX_UNAME_LEN);
	LTQ_STRNCPY(mgmt_server->passwd, xMS.passwd, MAX_PASSWORD_LEN);
	mgmt_server->period_inform_enable = xMS.period_inform_enable;
	mgmt_server->period_inform_interval = xMS.period_inform_interval;
	mgmt_server->period_abs_inform_time = xMS.period_abs_inform_time;
	LTQ_STRNCPY(mgmt_server->parameter_key, xMS.parameter_key,
		MAX_PARAMETER_KEY_LEN);
	LTQ_STRNCPY(mgmt_server->conn_req_url, xMS.conn_req_url,
		MAX_CONN_REQ_URL_LEN);
	LTQ_STRNCPY(mgmt_server->conn_req_uname, xMS.conn_req_uname,
		MAX_CONN_REQ_UNAME_LEN);
	LTQ_STRNCPY(mgmt_server->conn_req_passwd, xMS.conn_req_passwd,
		MAX_CONN_REQ_PASSWD_LEN);
	mgmt_server->upgrades_managed = xMS.upgrades_managed;
#if 0
	strcpy(mgmt_server->udp_conn_req_url, xMS.udp_conn_req_url);
	mgmt_server->udp_conn_req_address_notification_limit =
	    xMS.udp_conn_req_address_notification_limit;
	mgmt_server->stun_enable = xMS.stun_enable;
	mgmt_server->stun_server_address = xMS.stun_server_address;
	mgmt_server->stun_server_port = xMS.stun_server_port;
	strcpy(mgmt_server->stun_server_uname, xMS.stun_server_uname);
	strcpy(mgmt_server->stun_passwd, xMS.stun_passwd);
	mgmt_server->stun_max_keep_alive_period =
	    xMS.stun_max_keep_alive_period;
	mgmt_server->stun_min_keep_alive_period =
	    xMS.stun_min_keep_alive_period;
	mgmt_server->nat_detected = xMS.nat_detected;
	mgmt_server->mngdevnotifylimit = xMS.mngdevnotifylimit;
#endif
	LTQ_STRNCPY(mgmt_server->udp_conn_req_url, xMS.udp_conn_req_url,
		MAX_CONN_REQ_URL_LEN);
	mgmt_server->udp_conn_req_address_notification_limit =
	    xMS.udp_conn_req_address_notification_limit;
	mgmt_server->stun_enable = xMS.stun_enable;
	mgmt_server->stun_server_address = xMS.stun_server_address;
	mgmt_server->stun_server_port = xMS.stun_server_port;
	LTQ_STRNCPY(mgmt_server->stun_server_uname, xMS.stun_server_uname,
		MAX_CONN_REQ_UNAME_LEN);
	LTQ_STRNCPY(mgmt_server->stun_passwd, xMS.stun_passwd,
		MAX_CONN_REQ_PASSWD_LEN);
	mgmt_server->stun_max_keep_alive_period =
	    xMS.stun_max_keep_alive_period;
	mgmt_server->stun_min_keep_alive_period =
	    xMS.stun_min_keep_alive_period;
	mgmt_server->nat_detected = xMS.nat_detected;
	mgmt_server->mngdevnotifylimit = xMS.mngdevnotifylimit;
	mgmt_server->enable_cwmp = xMS.enable_cwmp;

      IFX_Handler:
	return (iRtn);
}

//IPv6

int32 ifx_set_ipprotver()
{
	int32 iRet = IFX_SUCCESS;
	char8 sVal[MAX_IF_NAME];
	uint32 ulInFlag = IFX_F_DEFAULT, ulOutFlag;
	char8 *status = NULL;

	status = (char8 *) malloc(512);
        if (!status)
            return IFX_FAILURE;

	iRet = ifx_GetObjData(FILE_RC_CONF, "ipv6_features", "ipv6_status",
			      ulInFlag, &ulOutFlag, sVal);
	if (iRet != IFX_SUCCESS)
		goto errorHandler;

	if (strcmp(sVal, "0") == 0) {
		sprintf(status, "mode=\"IPv4\"\n");

		iRet = ifx_SetObjData(FILE_RC_CONF, "ipprotver",
				      IFX_F_MODIFY, 1, status);
		if (iRet != IFX_SUCCESS)
			goto errorHandler;
	}

      errorHandler:
        IFX_MEM_FREE(status);
	return IFX_SUCCESS;
}

int32 ifx_get_x_ltq_ipprotocolversion_mode(X_LTQ_IPPROTOCOLVERSION * ipprot_ver,
					   uint32 flags)
{

	int32 iRet = IFX_SUCCESS;

	char8 sVal[50];
	uint32 ulInFlag = IFX_F_DEFAULT, ulOutFlag;

	memset(ipprot_ver, '\0', sizeof(X_LTQ_IPPROTOCOLVERSION));

	if ((iRet = ifx_GetObjData(FILE_RC_CONF, "ipprotver",
				   "mode",
				   ulInFlag, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		iRet = IFX_FAILURE;
		goto IFX_Handler;
	}

	strcpy(ipprot_ver->mode, sVal);
      IFX_Handler:
	return (iRet);

	return IFX_SUCCESS;
}

int32 ifx_ipprot_ver_set_ipv6(int32 status, char8 * ipprotver)
{
	int32 iRet = IFX_SUCCESS;

	char8 *sVal = NULL;

	char8 buf[MAX_FILELINE_LEN], sCommand[MAX_FILELINE_LEN],
	    sValue[MAX_FILELINE_LEN];
	int32 ret = IFX_SUCCESS, outFlag = IFX_SUCCESS;
	int32 flags = IFX_F_MODIFY, prev_state = 0;
	int32 cmdret = -1;

	NULL_TERMINATE(buf, 0, sizeof(buf));
	NULL_TERMINATE(sCommand, 0, sizeof(sCommand));

	if (status == 1) {

#ifdef IPV6MODULE
		NULL_TERMINATE(sValue, 0, sizeof(sValue));
		sprintf(sCommand, "/usr/sbin/version.sh -k");
		if (ifx_GetCfgData((char_t *) sCommand, NULL, "1", sValue) == 0) {
			return IFX_FAILURE;
		}

		memset(sCommand, 0, sizeof(sCommand));
		sprintf(sCommand, "/sbin/insmod /lib/modules/");
		strncat(sCommand, sValue, strlen(sValue));
		strcat(sCommand, "/ipv6.ko");
#else
		snprintf(sCommand, sizeof(sCommand),
			 "echo 0 >  /proc/sys/net/ipv6/conf/all/disable_ipv6");
#endif
	}

	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, "ipv6_features", "ipv6_status",
			    IFX_F_GET_ANY, (IFX_OUT uint32 *) & outFlag,
			    sValue)) != IFX_SUCCESS) {
		return IFX_FAILURE;
	}

	prev_state = atoi(sValue);

	sVal = (char8 *) malloc(50);
	sprintf(sVal, "mode=\"%s\"\n", ipprotver);

	if (prev_state == status) {
		if ((iRet =
		     ifx_SetObjData(FILE_RC_CONF, "ipprotver", IFX_F_MODIFY, 1,
				    sVal)) != IFX_SUCCESS)
			goto IFX_Handler;
	}

	sprintf(buf, "ipv6_status=\"%d\"\n", status);
	if ((ret =
	     ifx_SetObjData(FILE_RC_CONF, "ipv6_features", flags, 1,
			    buf)) != IFX_SUCCESS) {
		return IFX_FAILURE;
	}

	if ((iRet =
	     ifx_SetObjData(FILE_RC_CONF, "ipprotver", IFX_F_MODIFY, 1,
			    sVal)) != IFX_SUCCESS)
		return IFX_FAILURE;

	if (status == 0 && prev_state != status) {
		if (ifx_flash_write() <= 0) {
			return IFX_FAILURE;
		}
#if 1				/*FIXME */
		system("/etc/rc.d/rebootcpe.sh 5 &");
#else
		if (system("echo 1 > /proc/sys/net/ipv6/conf/all/disable_ipv6")) {
			return IFX_FAILURE;
		}
#endif
	}

//Runtime change

	cmdret = system(sCommand);
	if (!cmdret) {		// if success return 0 else 256
		system("echo 1 > /proc/sys/net/ipv6/conf/all/forwarding");
		system(". /etc/rc.d/bringup_wan_dhcp6c");
		system(" /etc/rc.d/rc.bringup_lan v6start");
		ret = IFX_SUCCESS;
	} else {
		/* In case of failure of system configuration , just rollback the configuration */
		sprintf(buf, "ipv6_status=\"%d\"\n", prev_state);
		ifx_SetObjData(FILE_RC_CONF, "ipv6_features", flags, 1, buf);

		return IFX_FAILURE;
	}

//save settings

	if (ifx_flash_write() <= 0) {
		return IFX_FAILURE;
	}

      IFX_Handler:
	free(sVal);
	if (!cmdret && ret == IFX_SUCCESS) {
		system(". /etc/rc.d/start_ipv6_apps telnetd ftpd httpd web &");
	}
	return ret;

	return IFX_SUCCESS;

}

// End IPv6

int32 ifx_get_ipping_diag(IPPING_DIAG * ipping_diag, uint32 flags)
{
	int32 iRet = IFX_SUCCESS;
#ifdef IFX_TR69_IPPING
	/* sVal buffer should be large enough to accomodate the biggest string in
	   the obj */
	char8 sVal[MAX_IF_NAME];
	uint32 ulInFlag = IFX_F_DEFAULT, ulOutFlag;

	/* TBD: flags are not considered. Also iid struct in IPPING_DIAG is not
	   considered */

	memset(ipping_diag, '\0', sizeof(IPPING_DIAG));

	if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
				   IFX_IPPING_DIAG_SECTION "_"
				   IFX_IPPING_DIAG_DIAGSTATE, ulInFlag,
				   &ulOutFlag, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;

	if ((strlen(sVal) + 1) > MAX_DIAGSTATE_LEN) {
		fprintf(stderr, "DiagState Value len exceeded=%d\n",
			strlen(sVal));
		iRet = IFX_FAILURE;
		goto IFX_Handler;
	}
	strcpy(ipping_diag->diag_state, sVal);

	if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
				   IFX_IPPING_DIAG_SECTION "_"
				   IFX_IPPING_DIAG_INTERFACE, ulInFlag,
				   &ulOutFlag, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;
	if ((strlen(sVal) + 1) > MAX_IF_NAME) {
		fprintf(stderr, "Interface Value len exceeded=%d\n",
			strlen(sVal));
		iRet = IFX_FAILURE;
		goto IFX_Handler;
	}
	strcpy(ipping_diag->interface, sVal);

	if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
				   IFX_IPPING_DIAG_SECTION "_"
				   IFX_IPPING_DIAG_HOST, ulInFlag, &ulOutFlag,
				   sVal)) != IFX_SUCCESS)
		goto IFX_Handler;
	if ((strlen(sVal) + 1) > MAX_HOST_NAME) {
		fprintf(stderr, "Host Value len exceeded=%d\n", strlen(sVal));
		iRet = IFX_FAILURE;
		goto IFX_Handler;
	}
	strcpy(ipping_diag->host, sVal);

	if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
				   IFX_IPPING_DIAG_SECTION "_"
				   IFX_IPPING_DIAG_NUMREPEAT, ulInFlag,
				   &ulOutFlag, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;

	ipping_diag->num_repeat = atoi(sVal);

	if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
				   IFX_IPPING_DIAG_SECTION "_"
				   IFX_IPPING_DIAG_TIMEOUT, ulInFlag,
				   &ulOutFlag, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;

	ipping_diag->timeout = atoi(sVal);

	if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
				   IFX_IPPING_DIAG_SECTION "_"
				   IFX_IPPING_DIAG_DATASIZE, ulInFlag,
				   &ulOutFlag, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;

	ipping_diag->data_size = atoi(sVal);

	if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
				   IFX_IPPING_DIAG_SECTION "_"
				   IFX_IPPING_DIAG_DSCP, ulInFlag, &ulOutFlag,
				   sVal)) != IFX_SUCCESS)
		goto IFX_Handler;

	ipping_diag->dscp = atoi(sVal);

	if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
				   IFX_IPPING_DIAG_SECTION "_"
				   IFX_IPPING_DIAG_SUCCESSCNT, ulInFlag,
				   &ulOutFlag, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;

	ipping_diag->success_cnt = atoi(sVal);

	if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
				   IFX_IPPING_DIAG_SECTION "_"
				   IFX_IPPING_DIAG_FAILURECNT, ulInFlag,
				   &ulOutFlag, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;

	ipping_diag->failure_cnt = atoi(sVal);

	if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
				   IFX_IPPING_DIAG_SECTION "_"
				   IFX_IPPING_DIAG_AVGRESPTIME, ulInFlag,
				   &ulOutFlag, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;

	ipping_diag->avg_resp_time = atoi(sVal);

	if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
				   IFX_IPPING_DIAG_SECTION "_"
				   IFX_IPPING_DIAG_MINRESPTIME, ulInFlag,
				   &ulOutFlag, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;

	ipping_diag->min_resp_time = atoi(sVal);

	if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
				   IFX_IPPING_DIAG_SECTION "_"
				   IFX_IPPING_DIAG_MAXRESPTIME, ulInFlag,
				   &ulOutFlag, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;

	ipping_diag->max_resp_time = atoi(sVal);

      IFX_Handler:
#endif
	return (iRet);
}

int32
ifx_set_ipping_diag(int32 operation, IPPING_DIAG * ipping_diag, uint32 flags)
{
	int32 iRet = IFX_SUCCESS;
#ifdef IFX_TR69_IPPING
	/* sVal should always be large enough to accomodate the biggest string in
	   the obj */
	char8 *sVal = NULL;

	sVal = (char8 *) malloc(512);

	if (sVal == NULL) {
		IFX_DBG("%s:%d Error--> Failed to Malloc !!\n", __FUNCTION__,
			__LINE__);
		goto IFX_Handler;
	}

	/* TBD: flags are not considered. Also iid struct in IPPING_DIAG is not
	   considered */

	sprintf(sVal, "%s_%s=\"%s\"\n", IFX_IPPING_DIAG_SECTION,
		IFX_IPPING_DIAG_DIAGSTATE, ipping_diag->diag_state);

	sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_IPPING_DIAG_SECTION,
		IFX_IPPING_DIAG_INTERFACE, ipping_diag->interface);

	sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_IPPING_DIAG_SECTION,
		IFX_IPPING_DIAG_HOST, ipping_diag->host);

	sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_IPPING_DIAG_SECTION,
		IFX_IPPING_DIAG_NUMREPEAT, ipping_diag->num_repeat);

	sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_IPPING_DIAG_SECTION,
		IFX_IPPING_DIAG_TIMEOUT, ipping_diag->timeout);

	sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_IPPING_DIAG_SECTION,
		IFX_IPPING_DIAG_DATASIZE, ipping_diag->data_size);

	sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_IPPING_DIAG_SECTION,
		IFX_IPPING_DIAG_DSCP, ipping_diag->dscp);

	sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_IPPING_DIAG_SECTION,
		IFX_IPPING_DIAG_SUCCESSCNT, ipping_diag->success_cnt);

	sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_IPPING_DIAG_SECTION,
		IFX_IPPING_DIAG_FAILURECNT, ipping_diag->failure_cnt);

	sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_IPPING_DIAG_SECTION,
		IFX_IPPING_DIAG_AVGRESPTIME, ipping_diag->avg_resp_time);

	sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_IPPING_DIAG_SECTION,
		IFX_IPPING_DIAG_MINRESPTIME, ipping_diag->min_resp_time);

	sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_IPPING_DIAG_SECTION,
		IFX_IPPING_DIAG_MAXRESPTIME, ipping_diag->max_resp_time);

	if ((iRet = ifx_SetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
				   flags, 1, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;

      IFX_Handler:
	free(sVal);
#endif
	return iRet;
}

int32 ifx_get_dl_auth(DL_AUTH * dl_auth, uint32 flags)
{
	int32 iRtn = IFX_SUCCESS;
	char8 sVal[MAX_FILELINE_LEN];
	uint32 ulOutFlag;
	DL_AUTH xAuth;

	memset(&xAuth, 0, sizeof(DL_AUTH));

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
				   IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_USERNAME,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get Username !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_UNAME_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Username len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xAuth.uname, sVal, MAX_UNAME_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
				   IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_PASSWORD,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get Password !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_PASSWORD_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Password len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xAuth.passwd, sVal, MAX_PASSWORD_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
				   IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_REALM,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get Realm !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Realm len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xAuth.realm, sVal, MAX_AUTH_PARAM_LONG_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
				   IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_NONCE,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get Nonce !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Nonce len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xAuth.nonce, sVal, MAX_AUTH_PARAM_LONG_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
				   IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_URI,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get URI !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> URI len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xAuth.uri, sVal, MAX_AUTH_PARAM_LONG_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
				   IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_ALGO,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get Algo !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_SHORT_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Algo len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xAuth.algo, sVal, MAX_AUTH_PARAM_SHORT_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
				   IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_CNONCE,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get CNonce !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> CNonce len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xAuth.cnonce, sVal, MAX_AUTH_PARAM_LONG_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
				   IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_OPAQUE,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get Opaque !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Opaque len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xAuth.opaque, sVal, MAX_AUTH_PARAM_LONG_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
				   IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_QOP,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get QOP !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> QOP len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xAuth.qop, sVal, MAX_AUTH_PARAM_LONG_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
				   IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_NC,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get NC !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_SHORT_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> NC len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xAuth.nc, sVal, MAX_AUTH_PARAM_SHORT_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
				   IFX_DL_AUTH_SECTION "_"
				   IFX_DL_AUTH_PROCESSCOOKIE, flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get ProcessCookie !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xAuth.process_cookie = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
				   IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_FILETYPE,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get FileType !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> FileType len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xAuth.file_type, sVal, MAX_AUTH_PARAM_LONG_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
				   IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_FILENAME,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get FileName !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_FILE_NAME_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> FileName len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xAuth.file_name, sVal, MAX_FILE_NAME_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
				   IFX_DL_AUTH_SECTION "_"
				   IFX_DL_AUTH_COMMANDKEY, flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get CommandKey !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_COMMAND_KEY_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> CommandKey len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xAuth.cmd_key, sVal, MAX_COMMAND_KEY_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
				   IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_STATUS,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get Status !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xAuth.status = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
				   IFX_DL_AUTH_SECTION "_"
				   IFX_DL_AUTH_STARTTIME, flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get StartTime !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xAuth.abs_start_time = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
				   IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_ENDTIME,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get EndTime !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xAuth.abs_end_time = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
				   IFX_DL_AUTH_SECTION "_"
				   IFX_DL_AUTH_FUTURETIME, flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get EndTime !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xAuth.abs_fut_time = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
				   IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_SIZE,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get EndTime !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xAuth.size = atoi(sVal);

	/* Fill the structure to be returned to the user */
	LTQ_STRNCPY(dl_auth->uname, xAuth.uname, MAX_UNAME_LEN);
	LTQ_STRNCPY(dl_auth->passwd, xAuth.passwd, MAX_PASSWORD_LEN);
	LTQ_STRNCPY(dl_auth->realm, xAuth.realm, MAX_AUTH_PARAM_LONG_LEN);
	LTQ_STRNCPY(dl_auth->nonce, xAuth.nonce, MAX_AUTH_PARAM_LONG_LEN);
	LTQ_STRNCPY(dl_auth->uri, xAuth.uri, MAX_AUTH_PARAM_LONG_LEN);
	LTQ_STRNCPY(dl_auth->algo, xAuth.algo, MAX_AUTH_PARAM_SHORT_LEN);
	LTQ_STRNCPY(dl_auth->cnonce, xAuth.cnonce, MAX_AUTH_PARAM_LONG_LEN);
	LTQ_STRNCPY(dl_auth->opaque, xAuth.opaque, MAX_AUTH_PARAM_LONG_LEN);
	LTQ_STRNCPY(dl_auth->qop, xAuth.qop, MAX_AUTH_PARAM_LONG_LEN);
	LTQ_STRNCPY(dl_auth->nc, xAuth.nc, MAX_AUTH_PARAM_SHORT_LEN);
	dl_auth->process_cookie = xAuth.process_cookie;
	LTQ_STRNCPY(dl_auth->file_type, xAuth.file_type, MAX_AUTH_PARAM_LONG_LEN);
	LTQ_STRNCPY(dl_auth->file_name, xAuth.file_name, MAX_FILE_NAME_LEN);
	LTQ_STRNCPY(dl_auth->cmd_key, xAuth.cmd_key, MAX_COMMAND_KEY_LEN);
	dl_auth->status = xAuth.status;
	dl_auth->abs_start_time = xAuth.abs_start_time;
	dl_auth->abs_end_time = xAuth.abs_end_time;
	dl_auth->abs_fut_time = xAuth.abs_fut_time;
	dl_auth->size = xAuth.size;

      IFX_Handler:
	return (iRtn);
}

int32 ifx_get_tr69_auth(TR69_AUTH * tr69_auth, uint32 flags)
{
	int32 iRtn = IFX_SUCCESS;
	char8 sVal[MAX_FILELINE_LEN];
	uint32 ulOutFlag;
	TR69_AUTH xAuth;

	memset(&xAuth, 0, sizeof(TR69_AUTH));

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_AUTH_SECTION,
				   IFX_TR69_AUTH_SECTION "_"
				   IFX_TR69_AUTH_REALM, flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get Realm !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Realm len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xAuth.realm, sVal, MAX_AUTH_PARAM_LONG_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_AUTH_SECTION,
				   IFX_TR69_AUTH_SECTION "_"
				   IFX_TR69_AUTH_NONCE, flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get Nonce !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Nonce len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xAuth.nonce, sVal, MAX_AUTH_PARAM_LONG_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_AUTH_SECTION,
				   IFX_TR69_AUTH_SECTION "_" IFX_TR69_AUTH_URI,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get URI !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> URI len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xAuth.uri, sVal, MAX_AUTH_PARAM_LONG_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_AUTH_SECTION,
				   IFX_TR69_AUTH_SECTION "_" IFX_TR69_AUTH_ALGO,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get Algo !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_SHORT_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Algo len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xAuth.algo, sVal, MAX_AUTH_PARAM_SHORT_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_AUTH_SECTION,
				   IFX_TR69_AUTH_SECTION "_"
				   IFX_TR69_AUTH_CNONCE, flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get CNonce !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> CNonce len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xAuth.cnonce, sVal, MAX_AUTH_PARAM_LONG_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_AUTH_SECTION,
				   IFX_TR69_AUTH_SECTION "_"
				   IFX_TR69_AUTH_OPAQUE, flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get Opaque !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Opaque len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xAuth.opaque, sVal, MAX_AUTH_PARAM_LONG_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_AUTH_SECTION,
				   IFX_TR69_AUTH_SECTION "_" IFX_TR69_AUTH_QOP,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get QOP !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> QOP len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xAuth.qop, sVal, MAX_AUTH_PARAM_LONG_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_AUTH_SECTION,
				   IFX_TR69_AUTH_SECTION "_" IFX_TR69_AUTH_NC,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get NC !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_SHORT_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> NC len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xAuth.nc, sVal, MAX_AUTH_PARAM_SHORT_LEN);

	/* Fill the structure to be returned to the user */
	LTQ_STRNCPY(tr69_auth->realm, xAuth.realm, MAX_AUTH_PARAM_LONG_LEN);
	LTQ_STRNCPY(tr69_auth->nonce, xAuth.nonce, MAX_AUTH_PARAM_LONG_LEN);
	LTQ_STRNCPY(tr69_auth->uri, xAuth.uri, MAX_AUTH_PARAM_LONG_LEN);
	LTQ_STRNCPY(tr69_auth->algo, xAuth.algo, MAX_AUTH_PARAM_SHORT_LEN);
	LTQ_STRNCPY(tr69_auth->cnonce, xAuth.cnonce, MAX_AUTH_PARAM_LONG_LEN);
	LTQ_STRNCPY(tr69_auth->opaque, xAuth.opaque, MAX_AUTH_PARAM_LONG_LEN);
	LTQ_STRNCPY(tr69_auth->qop, xAuth.qop, MAX_AUTH_PARAM_LONG_LEN);
	LTQ_STRNCPY(tr69_auth->nc, xAuth.nc, MAX_AUTH_PARAM_SHORT_LEN);

      IFX_Handler:
	return (iRtn);
}

int32 ifx_get_tr69_misc(TR69_MISC * tr69_misc, uint32 flags)
{
	int32 iRtn = IFX_SUCCESS;
	char8 sVal[MAX_FILELINE_LEN];
	uint32 ulOutFlag;
	TR69_MISC xMisc;

	memset(&xMisc, 0, sizeof(TR69_MISC));

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
				   IFX_TR69_MISC_SECTION "_"
				   IFX_TR69_MISC_AUTHACS, flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get AuthACS !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMisc.auth_acs = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
				   IFX_TR69_MISC_SECTION "_"
				   IFX_TR69_MISC_AUTHTYPE, flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get AuthType !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_AUTH_TYPE_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> AuthType len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xMisc.auth_type, sVal, MAX_AUTH_TYPE_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
				   IFX_TR69_MISC_SECTION "_"
				   IFX_TR69_MISC_EVENTCODE, flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get EventCode !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMisc.event = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
				   IFX_TR69_MISC_SECTION "_"
				   IFX_TR69_MISC_COMMANDKEY, flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get CommandKey !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_COMMAND_KEY_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> CommandKey len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xMisc.cmd_key, sVal, MAX_COMMAND_KEY_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
				   IFX_TR69_MISC_SECTION "_"
				   IFX_TR69_MISC_INCLUDEXML, flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get IncludeXML !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMisc.inc_xml = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
				   IFX_TR69_MISC_SECTION "_"
				   IFX_TR69_MISC_INCLUDESOAPACTION, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get IncludeSoapAction !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMisc.inc_soap_action = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
				   IFX_TR69_MISC_SECTION "_"
				   IFX_TR69_MISC_ACSGETRPC, flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get ACSGetRPC !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMisc.acs_get_rpc = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
				   IFX_TR69_MISC_SECTION "_"
				   IFX_TR69_MISC_BOOTSTRAP, flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get Bootstrap !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMisc.bootstrap = atoi(sVal);
	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
				   IFX_TR69_MISC_SECTION "_"
				   IFX_TR69_MISC_TR64ENABLE, flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get Bootstrap !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMisc.tr64_enable = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
				   IFX_TR69_MISC_SECTION "_"
				   IFX_TR69_MISC_UPNPENABLE, flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get Bootstrap !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMisc.upnp_enable = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
				   IFX_TR69_MISC_SECTION "_"
				   IFX_TR69_MISC_TR64PORT, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get tr64 port !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMisc.tr64_port = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
				   IFX_TR69_MISC_SECTION "_"
				   IFX_TR69_MISC_UPNPPORT, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get upnp port !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMisc.upnp_port = atoi(sVal);



	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
				   IFX_TR69_MISC_SECTION "_"
				   IFX_TR69_MISC_PREVIOUSTIME, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get previoustime !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMisc.abs_prev_time = atoi(sVal);
	
	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
				   IFX_TR69_MISC_SECTION "_"
				   IFX_TR69_MISC_URLSTATUS, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get urlstatus !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	xMisc.url_status = atoi(sVal);

	/* Fill the structure to be returned to the user */
	tr69_misc->auth_acs = xMisc.auth_acs;
	LTQ_STRNCPY(tr69_misc->auth_type, xMisc.auth_type, MAX_AUTH_TYPE_LEN);
	tr69_misc->event = xMisc.event;
	LTQ_STRNCPY(tr69_misc->cmd_key, xMisc.cmd_key, MAX_COMMAND_KEY_LEN);
	tr69_misc->inc_xml = xMisc.inc_xml;
	tr69_misc->inc_soap_action = xMisc.inc_soap_action;
	tr69_misc->acs_get_rpc = xMisc.acs_get_rpc;
	tr69_misc->bootstrap = xMisc.bootstrap;
	tr69_misc->tr64_enable = xMisc.tr64_enable;
	tr69_misc->upnp_enable = xMisc.upnp_enable;
	tr69_misc->tr64_port = xMisc.tr64_port;
	tr69_misc->upnp_port = xMisc.upnp_port;
	tr69_misc->abs_prev_time = xMisc.abs_prev_time;
	tr69_misc->url_status = xMisc.url_status;
      IFX_Handler:
	return (iRtn);
}

int32 ifx_set_dl_auth(int32 operation, DL_AUTH * dl_auth, uint32 flags)
{
	int count = 0, ret = IFX_SUCCESS;
	uint32 changed_fcount = 0;
	char8 buf[MAX_DATA_LEN];
	IFX_ID iid;
	IFX_NAME_VALUE_PAIR array_fvp[MAX_FIELD_RANGE], *array_changed_fvp =
	    NULL;

	memset(buf, 0, sizeof(buf));
	memset(&iid, 0, sizeof(iid));
	memset(array_fvp, 0, sizeof(array_fvp));

    /***  PROLOG BLOCK  ***/

	/* Append internal flags */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_MOD)
		flags |= IFX_F_MODIFY;
	else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
		flags |= IFX_F_INT_ADD;

    /********  VALIDATION BLOCK  ***********/
	/* For ops other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags)) {
	/*** Validation Checking Block ***/
		if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
			/* Do simple validation of pointer such as NULL */
			IFX_VALIDATE_PTR(dl_auth)
			    /* Do simple validation of flags such as less than 0 */
			    IFX_VALIDATE_FLAGS(flags)
		}
	}

    /*******  VALIDATION BLOCK END *********/

	/* Read the iid structure from rc.conf */
	iid = dl_auth->iid;
	if (ifx_get_iid_from_conf(&iid, FILE_RC_CONF, IFX_DL_AUTH_SECTION) !=
	    IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

    /*********** Name Value Formation As Per RC.CONF ****************/
	/* Build the API Specific name value pair */
	sprintf(array_fvp[0].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, "cpeId");
	sprintf(array_fvp[0].value, "%d", iid.cpeId.Id);
	sprintf(array_fvp[1].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, "pcpeId");
	sprintf(array_fvp[1].value, "%d", iid.pcpeId.Id);
	sprintf(array_fvp[2].fieldname, "%s_%s", IFX_DL_AUTH_SECTION,
		IFX_DL_AUTH_USERNAME);
	sprintf(array_fvp[2].value, "%s", dl_auth->uname);
	sprintf(array_fvp[3].fieldname, "%s_%s", IFX_DL_AUTH_SECTION,
		IFX_DL_AUTH_PASSWORD);
	sprintf(array_fvp[3].value, "%s", dl_auth->passwd);
	sprintf(array_fvp[4].fieldname, "%s_%s", IFX_DL_AUTH_SECTION,
		IFX_DL_AUTH_REALM);
	sprintf(array_fvp[4].value, "%s", dl_auth->realm);
	sprintf(array_fvp[5].fieldname, "%s_%s", IFX_DL_AUTH_SECTION,
		IFX_DL_AUTH_NONCE);
	sprintf(array_fvp[5].value, "%s", dl_auth->nonce);
	sprintf(array_fvp[6].fieldname, "%s_%s", IFX_DL_AUTH_SECTION,
		IFX_DL_AUTH_URI);
	sprintf(array_fvp[6].value, "%s", dl_auth->uri);
	sprintf(array_fvp[7].fieldname, "%s_%s", IFX_DL_AUTH_SECTION,
		IFX_DL_AUTH_ALGO);
	sprintf(array_fvp[7].value, "%s", dl_auth->algo);
	sprintf(array_fvp[8].fieldname, "%s_%s", IFX_DL_AUTH_SECTION,
		IFX_DL_AUTH_CNONCE);
	sprintf(array_fvp[8].value, "%s", dl_auth->cnonce);
	sprintf(array_fvp[9].fieldname, "%s_%s", IFX_DL_AUTH_SECTION,
		IFX_DL_AUTH_OPAQUE);
	sprintf(array_fvp[9].value, "%s", dl_auth->opaque);
	sprintf(array_fvp[10].fieldname, "%s_%s", IFX_DL_AUTH_SECTION,
		IFX_DL_AUTH_QOP);
	sprintf(array_fvp[10].value, "%s", dl_auth->qop);
	sprintf(array_fvp[11].fieldname, "%s_%s", IFX_DL_AUTH_SECTION,
		IFX_DL_AUTH_NC);
	sprintf(array_fvp[11].value, "%s", dl_auth->nc);
	sprintf(array_fvp[12].fieldname, "%s_%s", IFX_DL_AUTH_SECTION,
		IFX_DL_AUTH_PROCESSCOOKIE);
	sprintf(array_fvp[12].value, "%d", dl_auth->process_cookie);
	sprintf(array_fvp[13].fieldname, "%s_%s", IFX_DL_AUTH_SECTION,
		IFX_DL_AUTH_FILETYPE);
	sprintf(array_fvp[13].value, "%s", dl_auth->file_type);
	sprintf(array_fvp[14].fieldname, "%s_%s", IFX_DL_AUTH_SECTION,
		IFX_DL_AUTH_FILENAME);
	sprintf(array_fvp[14].value, "%s", dl_auth->file_name);
	sprintf(array_fvp[15].fieldname, "%s_%s", IFX_DL_AUTH_SECTION,
		IFX_DL_AUTH_COMMANDKEY);
	sprintf(array_fvp[15].value, "%s", dl_auth->cmd_key);
	sprintf(array_fvp[16].fieldname, "%s_%s", IFX_DL_AUTH_SECTION,
		IFX_DL_AUTH_STATUS);
	sprintf(array_fvp[16].value, "%d", dl_auth->status);
	sprintf(array_fvp[17].fieldname, "%s_%s", IFX_DL_AUTH_SECTION,
		IFX_DL_AUTH_STARTTIME);
	sprintf(array_fvp[17].value, "%u", dl_auth->abs_start_time);
	sprintf(array_fvp[18].fieldname, "%s_%s", IFX_DL_AUTH_SECTION,
		IFX_DL_AUTH_ENDTIME);
	sprintf(array_fvp[18].value, "%u", dl_auth->abs_end_time);
	sprintf(array_fvp[19].fieldname, "%s_%s", IFX_DL_AUTH_SECTION,
		IFX_DL_AUTH_FUTURETIME);
	sprintf(array_fvp[19].value, "%u", dl_auth->abs_fut_time);
	sprintf(array_fvp[20].fieldname, "%s_%s", IFX_DL_AUTH_SECTION,
		IFX_DL_AUTH_SIZE);
	sprintf(array_fvp[20].value, "%u", dl_auth->size);
	count = 21;

    /***  PROLOG BLOCK END  ***/

    /**************** ACL CHECK BLOCK *****************/

	CHECK_ACL_RET(iid, count, array_fvp,
		      changed_fcount, array_changed_fvp, flags, IFX_Handler)

    /**************** ACL CHECK BLOCK END *****************/
    /********* SYSTEM CONFIG FILE UPDATE BLOCK  **********/
	    /* Convert the name value pair in array_fvp into string format expected 
	       by rc.conf file */
	    if (IFX_MODIFY_F_SET(flags)) {
		// form_cfgdb_buf(buf, changed_fcount, array_changed_fvp);
		form_cfgdb_buf(buf, count, array_fvp);
	} else {
		form_cfgdb_buf(buf, count, array_fvp);
	}

	/* Backup rc.conf before proceeding with configuration */
	CHECKPOINT_RET(flags, FILE_RC_CONF, CHKPOINT_FILE, IFX_Handler)

	    /* Update rc.conf */
	    ret =
	    ifx_SetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION, flags, 1, buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup
	   rc.conf */
	if (ret != IFX_SUCCESS) {
		ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE,
				    flags | IFX_F_INT_DONT_RESTART_SERVICES,
				    IFX_Handler)
	}

    /********* SYSTEM CONFIG FILE UPDATE BLOCK END **********/

    /************ DEVICE CONFIGURATION BLOCK ***********/
    /************ DEVICE CONFIGURATION BLOCK END ***********/

    /**************** NOTIFICATION BLOCK ******************/

	/* Notify the Internal TR69 Stack */
	CHECK_N_SEND_NOTIFICATION(iid, changed_fcount, array_changed_fvp, flags,
				  IFX_Handler)

    /**************** NOTIFICATION BLOCK ******************/
    /***************** EPILOG BLOCK **********************/
	    ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE,
				    flags | IFX_F_INT_DONT_RESTART_SERVICES,
				    IFX_Handler)
	}
    /***************** EPILOG BLOCK END **********************/

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	    if (ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}

int32 ifx_set_tr69_auth(int32 operation, TR69_AUTH * tr69_auth, uint32 flags)
{
	int count = 0, ret = IFX_SUCCESS;
	uint32 changed_fcount = 0;
	char8 buf[MAX_DATA_LEN];
	IFX_ID iid;
	IFX_NAME_VALUE_PAIR array_fvp[MAX_FIELD_RANGE], *array_changed_fvp =
	    NULL;

	memset(buf, 0, sizeof(buf));
	memset(&iid, 0, sizeof(iid));
	memset(array_fvp, 0, sizeof(array_fvp));

    /***  PROLOG BLOCK  ***/

	/* Append internal flags */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_MOD)
		flags |= IFX_F_MODIFY;
	else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
		flags |= IFX_F_INT_ADD;

    /********  VALIDATION BLOCK  ***********/
	/* For ops other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags)) {
	/*** Validation Checking Block ***/
		if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
			/* Do simple validation of pointer such as NULL */
			IFX_VALIDATE_PTR(tr69_auth)
			    /* Do simple validation of flags such as less than 0 */
			    IFX_VALIDATE_FLAGS(flags)
		}
	}

    /*******  VALIDATION BLOCK END *********/

	/* Read the iid structure from rc.conf */
	iid = tr69_auth->iid;
	if (ifx_get_iid_from_conf(&iid, FILE_RC_CONF, IFX_TR69_AUTH_SECTION) !=
	    IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

    /*********** Name Value Formation As Per RC.CONF ****************/
	/* Build the API Specific name value pair */
	sprintf(array_fvp[0].fieldname, "%s_%s", IFX_TR69_AUTH_SECTION,
		"cpeId");
	sprintf(array_fvp[0].value, "%d", iid.cpeId.Id);
	sprintf(array_fvp[1].fieldname, "%s_%s", IFX_TR69_AUTH_SECTION,
		"pcpeId");
	sprintf(array_fvp[1].value, "%d", iid.pcpeId.Id);
	sprintf(array_fvp[2].fieldname, "%s_%s", IFX_TR69_AUTH_SECTION,
		IFX_TR69_AUTH_REALM);
	sprintf(array_fvp[2].value, "%s", tr69_auth->realm);
	sprintf(array_fvp[3].fieldname, "%s_%s", IFX_TR69_AUTH_SECTION,
		IFX_TR69_AUTH_NONCE);
	sprintf(array_fvp[3].value, "%s", tr69_auth->nonce);
	sprintf(array_fvp[4].fieldname, "%s_%s", IFX_TR69_AUTH_SECTION,
		IFX_TR69_AUTH_URI);
	sprintf(array_fvp[4].value, "%s", tr69_auth->uri);
	sprintf(array_fvp[5].fieldname, "%s_%s", IFX_TR69_AUTH_SECTION,
		IFX_TR69_AUTH_ALGO);
	sprintf(array_fvp[5].value, "%s", tr69_auth->algo);
	sprintf(array_fvp[6].fieldname, "%s_%s", IFX_TR69_AUTH_SECTION,
		IFX_TR69_AUTH_CNONCE);
	sprintf(array_fvp[6].value, "%s", tr69_auth->cnonce);
	sprintf(array_fvp[7].fieldname, "%s_%s", IFX_TR69_AUTH_SECTION,
		IFX_TR69_AUTH_OPAQUE);
	sprintf(array_fvp[7].value, "%s", tr69_auth->opaque);
	sprintf(array_fvp[8].fieldname, "%s_%s", IFX_TR69_AUTH_SECTION,
		IFX_TR69_AUTH_QOP);
	sprintf(array_fvp[8].value, "%s", tr69_auth->qop);
	sprintf(array_fvp[9].fieldname, "%s_%s", IFX_TR69_AUTH_SECTION,
		IFX_TR69_AUTH_NC);
	sprintf(array_fvp[9].value, "%s", tr69_auth->nc);
	count = 10;

    /***  PROLOG BLOCK END  ***/

    /**************** ACL CHECK BLOCK *****************/

	CHECK_ACL_RET(iid, count, array_fvp,
		      changed_fcount, array_changed_fvp, flags, IFX_Handler)

    /**************** ACL CHECK BLOCK END *****************/
    /********* SYSTEM CONFIG FILE UPDATE BLOCK  **********/
	    /* Convert the name value pair in array_fvp into string format expected 
	       by rc.conf file */
	    if (IFX_MODIFY_F_SET(flags)) {
		// form_cfgdb_buf(buf, changed_fcount, array_changed_fvp);
		form_cfgdb_buf(buf, count, array_fvp);
	} else {
		form_cfgdb_buf(buf, count, array_fvp);
	}

	/* Backup rc.conf before proceeding with configuration */
	CHECKPOINT_RET(flags, FILE_RC_CONF, CHKPOINT_FILE, IFX_Handler)

	    /* Update rc.conf */
	    ret =
	    ifx_SetObjData(FILE_RC_CONF, IFX_TR69_AUTH_SECTION, flags, 1, buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup
	   rc.conf */
	if (ret != IFX_SUCCESS) {
		ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE,
				    flags | IFX_F_INT_DONT_RESTART_SERVICES,
				    IFX_Handler)
	}

    /********* SYSTEM CONFIG FILE UPDATE BLOCK END **********/

    /************ DEVICE CONFIGURATION BLOCK ***********/
    /************ DEVICE CONFIGURATION BLOCK END ***********/

    /**************** NOTIFICATION BLOCK ******************/

	/* Notify the Internal TR69 Stack */
	CHECK_N_SEND_NOTIFICATION(iid, changed_fcount, array_changed_fvp, flags,
				  IFX_Handler)

    /**************** NOTIFICATION BLOCK ******************/
    /***************** EPILOG BLOCK **********************/
	    ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE,
				    flags | IFX_F_INT_DONT_RESTART_SERVICES,
				    IFX_Handler)
	}
    /***************** EPILOG BLOCK END **********************/

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	    if (ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}

int32 ifx_set_tr69_misc(int32 operation, TR69_MISC * tr69_misc, uint32 flags)
{
	int count = 0, ret = IFX_SUCCESS;
	uint32 changed_fcount = 0;
	char8 buf[MAX_DATA_LEN];
	char8 syscmd[64];
	IFX_ID iid;
	IFX_NAME_VALUE_PAIR array_fvp[MAX_FIELD_RANGE], *array_changed_fvp =
	    NULL;

	memset(buf, 0, sizeof(buf));
	memset(syscmd, 0, sizeof(syscmd));
	memset(&iid, 0, sizeof(iid));
	memset(array_fvp, 0, sizeof(array_fvp));

    /***  PROLOG BLOCK  ***/

	/* Append internal flags */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_MOD)
		flags |= IFX_F_MODIFY;
	else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
		flags |= IFX_F_INT_ADD;

    /********  VALIDATION BLOCK  ***********/
	/* For ops other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags)) {
	/*** Validation Checking Block ***/
		if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
			/* Do simple validation of pointer such as NULL */
			IFX_VALIDATE_PTR(tr69_misc)
			    /* Do simple validation of flags such as less than 0 */
			    IFX_VALIDATE_FLAGS(flags)
		}
	}

    /*******  VALIDATION BLOCK END *********/

	/* Read the iid structure from rc.conf */
	iid = tr69_misc->iid;
	if (ifx_get_iid_from_conf(&iid, FILE_RC_CONF, IFX_TR69_MISC_SECTION) !=
	    IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

    /*********** Name Value Formation As Per RC.CONF ****************/
	/* Build the API Specific name value pair */
	sprintf(array_fvp[0].fieldname, "%s_%s", IFX_TR69_MISC_SECTION,
		"cpeId");
	sprintf(array_fvp[0].value, "%d", iid.cpeId.Id);
	sprintf(array_fvp[1].fieldname, "%s_%s", IFX_TR69_MISC_SECTION,
		"pcpeId");
	sprintf(array_fvp[1].value, "%d", iid.pcpeId.Id);
	sprintf(array_fvp[2].fieldname, "%s_%s", IFX_TR69_MISC_SECTION,
		IFX_TR69_MISC_AUTHACS);
	sprintf(array_fvp[2].value, "%d", tr69_misc->auth_acs);
	sprintf(array_fvp[3].fieldname, "%s_%s", IFX_TR69_MISC_SECTION,
		IFX_TR69_MISC_AUTHTYPE);
	sprintf(array_fvp[3].value, "%s", tr69_misc->auth_type);
	sprintf(array_fvp[4].fieldname, "%s_%s", IFX_TR69_MISC_SECTION,
		IFX_TR69_MISC_EVENTCODE);
	sprintf(array_fvp[4].value, "%u", tr69_misc->event);
	sprintf(array_fvp[5].fieldname, "%s_%s", IFX_TR69_MISC_SECTION,
		IFX_TR69_MISC_COMMANDKEY);
	sprintf(array_fvp[5].value, "%s", tr69_misc->cmd_key);
	sprintf(array_fvp[6].fieldname, "%s_%s", IFX_TR69_MISC_SECTION,
		IFX_TR69_MISC_INCLUDEXML);
	sprintf(array_fvp[6].value, "%d", tr69_misc->inc_xml);
	sprintf(array_fvp[7].fieldname, "%s_%s", IFX_TR69_MISC_SECTION,
		IFX_TR69_MISC_INCLUDESOAPACTION);
	sprintf(array_fvp[7].value, "%d", tr69_misc->inc_soap_action);
	sprintf(array_fvp[8].fieldname, "%s_%s", IFX_TR69_MISC_SECTION,
		IFX_TR69_MISC_ACSGETRPC);
	sprintf(array_fvp[8].value, "%d", tr69_misc->acs_get_rpc);
	sprintf(array_fvp[9].fieldname, "%s_%s", IFX_TR69_MISC_SECTION,
		IFX_TR69_MISC_BOOTSTRAP);
	sprintf(array_fvp[9].value, "%d", tr69_misc->bootstrap);
	sprintf(array_fvp[10].fieldname, "%s_%s", IFX_TR69_MISC_SECTION,
		IFX_TR69_MISC_TR64ENABLE);
	sprintf(array_fvp[10].value, "%d", tr69_misc->tr64_enable);
	sprintf(array_fvp[11].fieldname, "%s_%s", IFX_TR69_MISC_SECTION,
		IFX_TR69_MISC_UPNPENABLE);
	sprintf(array_fvp[11].value, "%d", tr69_misc->upnp_enable);
	sprintf(array_fvp[12].fieldname, "%s_%s", IFX_TR69_MISC_SECTION,
		IFX_TR69_MISC_TR64PORT);
	sprintf(array_fvp[12].value, "%d", tr69_misc->tr64_port);
	sprintf(array_fvp[13].fieldname, "%s_%s", IFX_TR69_MISC_SECTION,
		IFX_TR69_MISC_UPNPPORT);
	sprintf(array_fvp[13].value, "%d", tr69_misc->upnp_port);
	sprintf(array_fvp[14].fieldname, "%s_%s", IFX_TR69_MISC_SECTION,
		IFX_TR69_MISC_PREVIOUSTIME);
	sprintf(array_fvp[14].value, "%d", tr69_misc->abs_prev_time);
	sprintf(array_fvp[15].fieldname, "%s_%s", IFX_TR69_MISC_SECTION,
		IFX_TR69_MISC_URLSTATUS);
	sprintf(array_fvp[15].value, "%d", tr69_misc->url_status);

	count = 16;

    /***  PROLOG BLOCK END  ***/

    /**************** ACL CHECK BLOCK *****************/

	CHECK_ACL_RET(iid, count, array_fvp,
		      changed_fcount, array_changed_fvp, flags, IFX_Handler)

    /**************** ACL CHECK BLOCK END *****************/
    /********* SYSTEM CONFIG FILE UPDATE BLOCK  **********/
	    /* Convert the name value pair in array_fvp into string format expected 
	       by rc.conf file */
	    if (IFX_MODIFY_F_SET(flags)) {
		// form_cfgdb_buf(buf, changed_fcount, array_changed_fvp);
		form_cfgdb_buf(buf, count, array_fvp);
	} else {
		form_cfgdb_buf(buf, count, array_fvp);
	}

	/* Backup rc.conf before proceeding with configuration */
	CHECKPOINT_RET(flags, FILE_RC_CONF, CHKPOINT_FILE, IFX_Handler)

	    /* Update rc.conf */
	    ret =
	    ifx_SetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION, flags, 1, buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup
	   rc.conf */
	if (ret != IFX_SUCCESS) {
		ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE,
				    flags | IFX_F_INT_DONT_RESTART_SERVICES,
				    IFX_Handler)
	}

    /********* SYSTEM CONFIG FILE UPDATE BLOCK END **********/

    /************ DEVICE CONFIGURATION BLOCK ***********/
	if ( (tr69_misc->tr64_enable == 0) && (tr69_misc->upnp_enable == 0)) {                      
                    system("killall -9 minissdpd > /dev/null");                                 
	}  
	else
	{
                    system("killall -9 minissdpd > /dev/null");           //respawn the minissdp
                    sprintf(syscmd,"/usr/sbin/minissdpd %d %d %d %d &", tr69_misc->tr64_enable , tr69_misc->upnp_enable ,tr69_misc->tr64_port,tr69_misc->upnp_port);  
                    system(syscmd);                                                             
	}
	
    /************ DEVICE CONFIGURATION BLOCK END ***********/

    /**************** NOTIFICATION BLOCK ******************/

	/* Notify the Internal TR69 Stack */
	CHECK_N_SEND_NOTIFICATION(iid, changed_fcount, array_changed_fvp, flags,
				  IFX_Handler)

    /**************** NOTIFICATION BLOCK ******************/
    /***************** EPILOG BLOCK **********************/
	    ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE,
				    flags | IFX_F_INT_DONT_RESTART_SERVICES,
				    IFX_Handler)
	}
    /***************** EPILOG BLOCK END **********************/

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	    if (ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}

int32 ifx_get_gateway_info(GATEWAY_INFO * gateway_info, uint32 flags)
{
	int32 iRtn = IFX_SUCCESS;
#ifdef DEVICE_SUPPORT
#ifdef DEVICE_ASSO_SUPPORT
	char8 sVal[MAX_FILELINE_LEN];
	uint32 ulOutFlag;
	GATEWAY_INFO xGI;

	memset(&xGI, 0, sizeof(GATEWAY_INFO));

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_GATEWAY_INFO_SECTION,
				   IFX_GATEWAY_INFO_SECTION "_" "cpeId",
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get Manufacturer OUI !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}

	xGI.iid.cpeId.Id = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_GATEWAY_INFO_SECTION,
				   IFX_GATEWAY_INFO_SECTION "_" "pcpeId",
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get Manufacturer OUI !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}

	xGI.iid.pcpeId.Id = atoi(sVal);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_GATEWAY_INFO_SECTION,
				   IFX_GATEWAY_INFO_SECTION "_"
				   IFX_GATEWAY_INFO_MANUFACTUREROUI, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get Manufacturer OUI !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_OUI_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Manufacturer OUI len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xGI.oui, sVal, MAX_OUI_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_GATEWAY_INFO_SECTION,
				   IFX_GATEWAY_INFO_SECTION "_"
				   IFX_GATEWAY_INFO_PRODUCTCLASS, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get Product class !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_PROD_CLASS_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Product class len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xGI.product_class, sVal, MAX_PROD_CLASS_LEN);

	memset(sVal, '\0', sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_GATEWAY_INFO_SECTION,
				   IFX_GATEWAY_INFO_SECTION "_"
				   IFX_DEVICE_INFO_SERIALNUMBER, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get Serial Number !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_SERIAL_NUM_LEN) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Serial Number len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xGI.serial_number, sVal, MAX_SERIAL_NUM_LEN);

	gateway_info->iid.cpeId.Id = xGI.iid.cpeId.Id;
	gateway_info->iid.pcpeId.Id = xGI.iid.pcpeId.Id;
	strcpy(gateway_info->oui, xGI.oui);
	strcpy(gateway_info->product_class, xGI.product_class);
	strcpy(gateway_info->serial_number, xGI.serial_number);

	return IFX_SUCCESS;

      IFX_Handler:
#endif
#endif
	return (iRtn);
}

int32
ifx_set_gateway_info(int32 operation, GATEWAY_INFO * gateway_info, uint32 flags)
{
#ifdef DEVICE_SUPPORT
#ifdef DEVICE_ASSO_SUPPORT
	int count = 0, ret = IFX_SUCCESS;
	uint32 changed_fcount = 0;
	char8 buf[MAX_DATA_LEN];
	IFX_ID iid;
	IFX_NAME_VALUE_PAIR array_fvp[MAX_FIELD_RANGE], *array_changed_fvp =
	    NULL;

	memset(buf, 0, sizeof(buf));
	memset(&iid, 0, sizeof(iid));
	memset(array_fvp, 0, sizeof(array_fvp));

    /***  PROLOG BLOCK  ***/

	/* Append internal flags */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_MOD)
		flags |= IFX_F_MODIFY;
	else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
		flags |= IFX_F_INT_ADD;

    /********  VALIDATION BLOCK  ***********/
	/* For ops other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags)) {
	/*** Validation Checking Block ***/
		if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
			/* Do simple validation of pointer such as NULL */
			IFX_VALIDATE_PTR(gateway_info)
			    /* Do simple validation of flags such as less than 0 */
			    IFX_VALIDATE_FLAGS(flags)
		}
	}

    /*******  VALIDATION BLOCK END *********/

	/* Read the iid structure from rc.conf */
	iid = gateway_info->iid;
	if (ifx_get_iid_from_conf(&iid, FILE_RC_CONF, IFX_GATEWAY_INFO_SECTION)
	    != IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

    /*********** Name Value Formation As Per RC.CONF ****************/
	/* Build the API Specific name value pair */
	sprintf(array_fvp[0].fieldname, "%s_%s", IFX_GATEWAY_INFO_SECTION,
		"cpeId");
	sprintf(array_fvp[0].value, "%d", iid.cpeId.Id);
	sprintf(array_fvp[1].fieldname, "%s_%s", IFX_GATEWAY_INFO_SECTION,
		"pcpeId");
	sprintf(array_fvp[1].value, "%d", iid.pcpeId.Id);

	sprintf(array_fvp[2].fieldname, "%s_%s", IFX_GATEWAY_INFO_SECTION,
		IFX_DEVICE_INFO_MANUFACTUREROUI);
	sprintf(array_fvp[2].value, "%s", gateway_info->oui);
	sprintf(array_fvp[3].fieldname, "%s_%s", IFX_GATEWAY_INFO_SECTION,
		IFX_DEVICE_INFO_PRODUCTCLASS);
	sprintf(array_fvp[3].value, "%s", gateway_info->product_class);
	sprintf(array_fvp[4].fieldname, "%s_%s", IFX_GATEWAY_INFO_SECTION,
		IFX_DEVICE_INFO_SERIALNUMBER);
	sprintf(array_fvp[4].value, "%s", gateway_info->serial_number);

	count = 5;

    /***  PROLOG BLOCK END  ***/

    /**************** ACL CHECK BLOCK *****************/

	CHECK_ACL_RET(iid, count, array_fvp,
		      changed_fcount, array_changed_fvp, flags, IFX_Handler)

    /**************** ACL CHECK BLOCK END *****************/
    /********* SYSTEM CONFIG FILE UPDATE BLOCK  **********/
	    /* Convert the name value pair in array_fvp into string format expected 
	       by rc.conf file */
	    if (IFX_MODIFY_F_SET(flags)) {
		// form_cfgdb_buf(buf, changed_fcount, array_changed_fvp);
		form_cfgdb_buf(buf, count, array_fvp);
	} else {
		form_cfgdb_buf(buf, count, array_fvp);
	}

	/* Backup rc.conf before proceeding with configuration */
	CHECKPOINT_RET(flags, FILE_RC_CONF, CHKPOINT_FILE, IFX_Handler)

	    /* Update rc.conf */
	    ret =
	    ifx_SetObjData(FILE_RC_CONF, IFX_GATEWAY_INFO_SECTION, flags, 1,
			   buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup
	   rc.conf */
	if (ret != IFX_SUCCESS) {
		ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE,
				    flags | IFX_F_INT_DONT_RESTART_SERVICES,
				    IFX_Handler)
	}

    /********* SYSTEM CONFIG FILE UPDATE BLOCK END **********/

    /************ DEVICE CONFIGURATION BLOCK ***********/
    /************ DEVICE CONFIGURATION BLOCK END ***********/

    /**************** NOTIFICATION BLOCK ******************/

	/* Notify the Internal TR69 Stack */
	CHECK_N_SEND_NOTIFICATION(iid, changed_fcount, array_changed_fvp, flags,
				  IFX_Handler)

    /**************** NOTIFICATION BLOCK ******************/
    /***************** EPILOG BLOCK **********************/
	    ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE,
				    flags | IFX_F_INT_DONT_RESTART_SERVICES,
				    IFX_Handler)
	}
    /***************** EPILOG BLOCK END **********************/

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	    if (ret != IFX_SUCCESS)
		return ret;
	else
#endif
#endif
		return IFX_SUCCESS;

}

int32
ifx_get_all_manageable_devices(int32 * num_entries,
			       MANAGEABLE_DEVICE ** Manageable_device,
			       uint32 flags)
{
#ifndef DEVICE_SUPPORT
#ifdef DEVICE_ASSO_SUPPORT
	char8 sValue[MAX_FILELINE_LEN];
	char8 command[MAX_FILELINE_LEN];
	int i = 0;
	int ret = IFX_SUCCESS;
	char num;
	uint32 inflag = flags, outflag = 0;
	void *pReallocTmp = NULL;

	memset(sValue, '\0', sizeof(sValue));
	memset(command, '\0', sizeof(command));

	/* get the count of vc channels present in rc.conf */
	if (ifx_GetObjData(FILE_RC_CONF, IFX_MANAGEABLE_DEVICE_SECTION,
			   "manageable_device_Count", inflag, &outflag, sValue) != IFX_SUCCESS)
	{
		IFX_DBG("\n\n Error : In function [%s] --> Failed to get manageable_device_Count from rc.conf !! \n\n", __FUNCTION__);
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	else
	{
		num = atoi(sValue);
		*num_entries = num;
	}

	if(num == 0)
	{
		*Manageable_device = NULL;
		IFX_DBG
		    ("\n\n Warn : In function [%s] --> No Manageable Device added !! \n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}

	/* allocate memory for num_entries of vcchannels in the output array
	   vcc_array */
	for (i = 0; i < num; i++)
	{

		pReallocTmp = *Manageable_device;

		*Manageable_device =
		    (MANAGEABLE_DEVICE *) realloc(*Manageable_device,
						  (i + 1) * sizeof(MANAGEABLE_DEVICE));

		if (*Manageable_device == NULL)
		{
			IFX_MEM_FREE(pReallocTmp);
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		else
		{
			pReallocTmp = NULL;
		}

		/* get the cpeid for this vc channel index i */
		MAKE_PARAM_ELEMENT_TAG(IFX_MANAGEABLE_DEVICE_SECTION_PREFIX, i,
				       "cpeId", command);
		memset(sValue, '\0', sizeof(sValue));
		if ((ifx_GetObjData(FILE_RC_CONF, IFX_MANAGEABLE_DEVICE_SECTION,
				    command, inflag, &outflag,
				    sValue)) != IFX_SUCCESS)
		{
			IFX_DBG("\n\n In Function [%s] : Error--> Not Found [%s] !! \n\n",
			     __FUNCTION__, command);
		} else
			(*Manageable_device + i)->iid.cpeId.Id = atoi(sValue);

		/* get the parent cpeid for this vc channel index i */
		MAKE_PARAM_ELEMENT_TAG(IFX_MANAGEABLE_DEVICE_SECTION_PREFIX, i,
				       "pcpeId", command);
		memset(sValue, '\0', sizeof(sValue));
		if ((ifx_GetObjData(FILE_RC_CONF, IFX_MANAGEABLE_DEVICE_SECTION,
				    command, inflag, &outflag,
				    sValue)) != IFX_SUCCESS)
		{
			IFX_DBG("\n\n In Function [%s] : Error--> Not Found [%s] !! \n\n",
			     __FUNCTION__, command);
		} else
			(*Manageable_device + i)->iid.pcpeId.Id = atoi(sValue);

		/* get the qos mode for this vcchannel index i */
		MAKE_PARAM_ELEMENT_TAG(IFX_MANAGEABLE_DEVICE_SECTION_PREFIX, i,
				       IFX_MANAGEABLE_DEVICE_MANUFACTUREROUI,
				       command);
		memset(sValue, '\0', sizeof(sValue));
		if ((ifx_GetObjData(FILE_RC_CONF, IFX_MANAGEABLE_DEVICE_SECTION,
				    command, inflag, &outflag,
				    sValue)) != IFX_SUCCESS)
		{
			IFX_DBG("\n\n In Function [%s] : Error--> Not Found [%s] !! \n\n",
			     __FUNCTION__, command);
		} else
			LTQ_STRNCPY((*Manageable_device + i)->oui, sValue, MAX_OUI_LEN);

		/* get the mbs value for this vcchannel index i */
		MAKE_PARAM_ELEMENT_TAG(IFX_MANAGEABLE_DEVICE_SECTION_PREFIX, i,
				       IFX_MANAGEABLE_DEVICE_PRODUCTCLASS,
				       command);
		memset(sValue, '\0', sizeof(sValue));
		if ((ifx_GetObjData(FILE_RC_CONF, IFX_MANAGEABLE_DEVICE_SECTION,
				    command, inflag, &outflag,
				    sValue)) != IFX_SUCCESS)
		{
			IFX_DBG("\n\n In Function [%s] : Error--> Not Found [%s] !! \n\n",
			     __FUNCTION__, command);
		} else {
			LTQ_STRNCPY((*Manageable_device + i)->product_class, sValue,
				MAX_PROD_CLASS_LEN);
		}

		/* get the max pcr value for this vcchannel index i */
		MAKE_PARAM_ELEMENT_TAG(IFX_MANAGEABLE_DEVICE_SECTION_PREFIX, i,
				       IFX_MANAGEABLE_DEVICE_SERIALNUMBER,
				       command);
		memset(sValue, '\0', sizeof(sValue));
		if ((ifx_GetObjData(FILE_RC_CONF, IFX_MANAGEABLE_DEVICE_SECTION,
				    command, inflag, &outflag,
				    sValue)) != IFX_SUCCESS)
		{
			IFX_DBG("\n\n In Function [%s] : Error--> Not Found [%s] !! \n\n",
			     __FUNCTION__, command);
		} else {
			LTQ_STRNCPY((*Manageable_device + i)->serial_number, sValue,
				MAX_SERIAL_NUM_LEN);
		}

		MAKE_PARAM_ELEMENT_TAG(IFX_MANAGEABLE_DEVICE_SECTION_PREFIX, i,
				       IFX_MANAGEABLE_DEVICE_IPADDR, command);
		memset(sValue, '\0', sizeof(sValue));
		if ((ifx_GetObjData(FILE_RC_CONF, IFX_MANAGEABLE_DEVICE_SECTION,
				    command, inflag, &outflag,
				    sValue)) != IFX_SUCCESS)
		{
			IFX_DBG("\n\n In Function [%s] : Error--> Not Found [%s] !! \n\n",
			     __FUNCTION__, command);
		} else {
			LTQ_STRNCPY((*Manageable_device + i)->ipaddr, sValue, MAX_IPADDR_LIST_LEN);
		}

	}

IFX_Handler:
	if (ret != IFX_SUCCESS)
	{
		*num_entries = 0;
		IFX_MEM_FREE(*Manageable_device)
		return ret;
	} else
#endif
#endif
		return IFX_SUCCESS;
}

int32
ifx_set_manageable_device(int32 operation, MANAGEABLE_DEVICE * entry,
			  uint32 flags)
{
#ifndef DEVICE_SUPPORT
#ifdef DEVICE_ASSO_SUPPORT
	char8 sbuf[MAX_FILELINE_LEN], conf_buf[MAX_DATA_LEN],
	    sValue[MAX_NAME_LEN];
	int32 passed_index = -1, ret = IFX_SUCCESS;
	uint32 count = 0, changed_count = 0;
	IFX_ID iid, piid;
	// MGMT_SERVER dev;
	IFX_NAME_VALUE_PAIR array_fvp[MAX_FIELD_RANGE], *array_changed_fvp =
	    NULL;

	// memset(&dev, 0x00, sizeof(dev));
	// memset(&iid, 0x00, sizeof(iid));

	memset(&iid, 0, sizeof(iid));
	memset(&piid, 0, sizeof(piid));
	memset(sbuf, 0, sizeof(sbuf));
	memset(conf_buf, 0, sizeof(conf_buf));
	memset(sValue, 0, sizeof(sValue));
	memset(array_fvp, 0, sizeof(array_fvp));

	 /*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY) append the flag with
	   internal flags */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

	 /**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(entry)
		    /* Do simple validation of flags sucha as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)

	}

	 /**************** ID Allocation Block - Only for ADD Operation **************/
	sprintf(entry->iid.cpeId.secName, "%s", IFX_MANAGEABLE_DEVICE_SECTION);
	sprintf(entry->iid.pcpeId.secName, "%s", IFX_MGMT_SERVER_SECTION);
	entry->iid.pcpeId.Id = 1;

	if (IFX_ADD_F_SET(flags)) {
		/* before getting iid for this, create a parent instance in wan conn
		   device section and get the parent cpeid */

		/* Allocate the IID for this manageable device */
		if (ifx_get_IID(&entry->iid, IFX_MGMT_SERVER_PARAMETERKEY) !=
		    IFX_SUCCESS) {
			IFX_DBG
			    ("\nIn Function [%s] : Failed to get the iid !!\n\n",
			     __FUNCTION__);
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	 /**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given structure for ADD/MODIFY Operations */
	count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {

		sprintf(array_fvp[count].fieldname, "%s", "cpeId");
		sprintf(array_fvp[count].value, "%d", entry->iid.cpeId.Id);
		count++;

		sprintf(array_fvp[count].fieldname, "%s", "pcpeId");
		sprintf(array_fvp[count].value, "%d", entry->iid.pcpeId.Id);
		count++;

		sprintf(array_fvp[count].fieldname, "%s",
			IFX_MANAGEABLE_DEVICE_MANUFACTUREROUI);
		sprintf(array_fvp[count].value, "%s", entry->oui);
		count++;

		sprintf(array_fvp[count].fieldname, "%s",
			IFX_MANAGEABLE_DEVICE_PRODUCTCLASS);
		sprintf(array_fvp[count].value, "%s", entry->product_class);
		count++;

		sprintf(array_fvp[count].fieldname, "%s",
			IFX_MANAGEABLE_DEVICE_SERIALNUMBER);
		sprintf(array_fvp[count].value, "%s", entry->serial_number);
		count++;

		sprintf(array_fvp[count].fieldname, "%s",
			IFX_MANAGEABLE_DEVICE_IPADDR);
		snprintf(array_fvp[count].value, MAX_TAG_VALUE_LEN, "%s",
			 entry->ipaddr);
		// strncpy(array_fvp[count].value, inet_ntoa(entry->ipaddr),
		// (MAX_IP_ADDR_LEN));
		count++;

		passed_index = -1;
	} else {
		/* For Delete operation set the count based on the qos mode */
		count = 6;
	}

	/* Get the existing configuration Index in case of modify/delete operations 
	   from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		if (ifx_get_index_from_cpe_id(FILE_RC_CONF, &entry->iid.cpeId,
					      &passed_index) != IFX_SUCCESS) {
			IFX_DBG
			    ("\n\n In function [%s] : Error--> cpeId [%d] not found in section !! \n\n",
			     __FUNCTION__, entry->iid.cpeId.Id);
#ifdef DEBUG_STMT
			system
			    ("echo \"failed to get index from cpeid for static route!!\" >> /tmp/error_log");
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	/* Determine the new configuration index - for Add Add/Modify - form the
	   fully qualified Name value pairs from array_fvp Delete -read the fully
	   qualified Name value pairs from rc.conf Fill array_fvp[] */
	if (ifx_get_conf_index_and_nv_pairs
	    (&entry->iid, passed_index, IFX_MANAGEABLE_DEVICE_SECTION_PREFIX,
	     count, array_fvp, flags) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In function [%s] : Error--> Duplicate entry !! \n\n",
		     __FUNCTION__);
#ifdef DEBUG_STMT
		system
		    ("echo \"failed to form fqnv for manageable device!!\" >> /tmp/error_log");
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	    /************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	if (IFX_ADD_F_NOT_SET(flags)) {
		CHECK_ACL_RET(entry->iid, count, array_fvp,
			      changed_count, array_changed_fvp, flags,
			      IFX_Handler)
	}
#ifdef DEBUG_STMT
	system("echo \"acl done !!\" >> /tmp/error_log");
#endif

	    /************** System Config File Update Block ****************/
	snprintf(sbuf, strlen(CHKPOINT_FILE2) + 6, "rm -f %s", CHKPOINT_FILE2);
	system(sbuf);

	/* Backup rc.conf before proceeding with configuration */
	CHECKPOINT_RET(flags, FILE_RC_CONF, CHKPOINT_FILE, IFX_Handler)

	    /* Convert the name value pair in array_fvp into string format expected 
	       by rc.conf file */
	    form_cfgdb_buf(conf_buf, count, array_fvp);

	/* RC.CONF Configuration block */
	ret =
	    ifx_SetObjData(FILE_RC_CONF, IFX_MANAGEABLE_DEVICE_SECTION, flags,
			   1, conf_buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup
	   rc.conf */
	if (ret != IFX_SUCCESS) {
		ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE,
				    flags | IFX_F_INT_DONT_RESTART_SERVICES,
				    IFX_Handler)
#ifdef DEBUG_STMT
		    system("echo \"SetCfgData failed !!\" >> /tmp/error_log");
#endif
	}

	/* this will Compact the section and also update the count for both ADD and 
	   DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF,
				      IFX_MANAGEABLE_DEVICE_SECTION, flags);

#ifdef DEBUG_STMT
	system("echo \"system config done !!\" >> /tmp/error_log");
#endif
	  /*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

	  /*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_MODIFY_F_SET(flags)) {

		CHECK_N_SEND_NOTIFICATION(entry->iid, changed_count,
					  array_changed_fvp, flags, IFX_Handler)
	} else if (IFX_INT_ADD_F_SET(flags)) {

		/* In case of ADD operation, first update the ID Mappings and then send 
		   the Notification for the attributes */
		      /*********** Epilog Block **************/
		UPDATE_ID_MAP_N_ATTRIBUTES(&entry->iid, count, array_fvp, flags,
					   IFX_Handler)

		    CHECK_N_SEND_NOTIFICATION(entry->iid, count, array_fvp,
					      flags, IFX_Handler)

		    /* Manipulate nextCpeId only for ADD operations */
		    ifx_increment_next_cpeId(FILE_RC_CONF,
					     IFX_MANAGEABLE_DEVICE_SECTION);

	} else if (IFX_DELETE_F_SET(flags)) {

		/* In case of DELETE operation, first send the notificatioupdate the ID 
		   Mappings and then send the Notification for the attributes */
		      /*********** Epilog Block **************/
		CHECK_N_SEND_NOTIFICATION(entry->iid, count, array_fvp, flags,
					  IFX_Handler)

		    UPDATE_ID_MAP_N_ATTRIBUTES(&entry->iid, count, array_fvp,
					       flags, IFX_Handler)
	}

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE,
				    flags | IFX_F_INT_DONT_RESTART_SERVICES,
				    IFX_Handler)
	}

      IFX_Handler:

	IFX_MEM_FREE(array_changed_fvp);
	if (ret != IFX_SUCCESS)
		return ret;
	else
#endif
#endif
		return IFX_SUCCESS;
}

int32
ifx_get_all_dhcp_option(int32 * numEntries, DHCP_OPTION ** dhcp_option,
			uint32 flags)
{
#ifdef DEVICE_SUPPORT
#ifdef IFX_TR69_DEVICE_LAN
	int32 ret = IFX_SUCCESS, nCount = 0, i = 0;
	char8 sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN];
	uint32 outFlag = IFX_F_DEFAULT;

	MAKE_SECTION_COUNT_TAG(TAG_DHCP_OPTION, buf);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_DHCP_OPTION,
				  buf, flags, &outFlag,
				  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	nCount = atoi(sValue);
	if (nCount == 0) {
		*numEntries = 0;
		*dhcp_option = NULL;
		goto IFX_Handler;
	}

	*dhcp_option = NULL;
	IFX_MEM_ALLOC((*dhcp_option), DHCP_OPTION *, nCount,
		      sizeof(DHCP_OPTION))

	    for (i = 0; i < nCount; i++) {
		/* get the cpeid of this instance */
		sprintf(buf, "%s_%d_cpeId", PREFIX_DHCP_OPTION, i);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_DHCP_OPTION,
					  buf, flags, &outFlag,
					  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		(*dhcp_option + i)->iid.cpeId.Id = atoi(sValue);

		if ((ret =
		     ifx_get_dhcp_option((*dhcp_option + i),
					 flags)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("[%s:%d] failed to get main params for instance dhcp_option%d",
			     __FUNCTION__, __LINE__, i);
#endif
			goto IFX_Handler;
		}
	}
	*numEntries = nCount;

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*dhcp_option)
		    IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
#endif
#endif
		return IFX_SUCCESS;
}

int32 ifx_get_dhcp_option(DHCP_OPTION * dhcp_option, uint32 flags)
{
#ifdef DEVICE_SUPPORT
#ifdef IFX_TR69_DEVICE_LAN
	int32 passed_index = -1, ret = IFX_SUCCESS, count = 0;
	char8 sBuf[MAX_FILELINE_LEN], *sValue = NULL;
	IFX_NAME_VALUE_PAIR array_fvp[DHCP_OPTION_PARAM_COUNT + 1];

	sprintf(dhcp_option->iid.cpeId.secName, "%s", TAG_DHCP_OPTION);

	/* get index from cpeid */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, dhcp_option->iid.cpeId,
				 passed_index)

	    sprintf(sBuf, "%s_%d_", PREFIX_DHCP_OPTION, passed_index);
	if ((ret =
	     ifx_GetCfgObject(FILE_RC_CONF, TAG_DHCP_OPTION, sBuf, flags,
			      &sValue)) != IFX_SUCCESS) {
		/* 
		   if(ret == IFX_E_UNMATCHED_INPUT) { continue; } */
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);

	dhcp_option->iid.cpeId.Id = atoi(array_fvp[0].value);
	dhcp_option->iid.pcpeId.Id = atoi(array_fvp[1].value);
	dhcp_option->enable = (char8) atoi(array_fvp[2].value);
	dhcp_option->request = (char8) atoi(array_fvp[3].value);
	dhcp_option->tag = (uint8) atoi(array_fvp[4].value);
	strcpy(dhcp_option->value, array_fvp[5].value);

      IFX_Handler:
	IFX_MEM_FREE(sValue)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
#endif
#endif
		return IFX_SUCCESS;
}

int32
ifx_set_dhcp_option(uint32 operation, DHCP_OPTION * dhcp_option, uint32 flags)
{
#ifdef DEVICE_SUPPORT
#ifdef IFX_TR69_DEVICE_LAN
	char8 conf_buf[MAX_DATA_LEN];
	int32 count = 0, changed_count = 0, passed_index = -1, ret =
	    IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR array_fvp[DHCP_OPTION_PARAM_COUNT + 1],
	    *array_changed_fvp = NULL;

	memset(array_fvp, 0, sizeof(array_fvp));
	NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));

	/*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY) append the flag with
	   internal flags */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

	sprintf(dhcp_option->iid.cpeId.secName, "%s", TAG_DHCP_OPTION);
	sprintf(dhcp_option->iid.pcpeId.secName, "%s", TAG_LAN_MAIN);

	/**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(dhcp_option)
		    /* Do simple validation of flags sucha as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

	/**************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_ADD_F_SET(flags)) {
		if (ifx_get_IID(&dhcp_option->iid, "req") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	/**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given structure for ADD/MODIFY Operations */
	count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, 0, DHCP_OPTION_PARAM_COUNT,
					dhcp_opt_params);

		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 2,
					    &dhcp_option->iid.cpeId.Id,
					    &dhcp_option->iid.pcpeId.Id);
		sprintf(array_fvp[2].value, "%d", dhcp_option->enable);
		sprintf(array_fvp[3].value, "%d", dhcp_option->request);
		sprintf(array_fvp[4].value, "%d", dhcp_option->tag);
//                ifx_fill_ArrayFvp_strValues(array_fvp, 5, 1, dhcp_option->value);
		sprintf(array_fvp[5].value, "%s", dhcp_option->value);

		passed_index = -1;
	}

	count = DHCP_OPTION_PARAM_COUNT;

	/* Get Config Index in case of modify/delete operations from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, dhcp_option->iid.cpeId,
					 passed_index)
	}

	/* Determine the configuration index - for Add, Delete, Modify operations * 
	   Name is partial since index is not known * Fill array_fvp[] */
	if (ifx_get_conf_index_and_nv_pairs
	    (&dhcp_option->iid, passed_index, PREFIX_DHCP_OPTION, count,
	     array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	if (IFX_ADD_F_NOT_SET(flags)) {
		CHECK_ACL_RET(dhcp_option->iid, count, array_fvp,
			      changed_count, array_changed_fvp, flags,
			      IFX_Handler)
	}

	/* before config file update, for modify or delete operation stop this */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    (IFX_DELETE_F_SET(flags) || IFX_MODIFY_F_SET(flags))) {

	}

	/************** System Config File Update Block ****************/
	/* Convert the name value pair in array_fvp into string format expected by
	   rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_DHCP_OPTION, flags, 1, conf_buf);

	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* after config file update, for modify or add operation start all ap/vap */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    (IFX_INT_ADD_F_SET(flags) || IFX_MODIFY_F_SET(flags))) {
	}

	/* this will Compact the section and also update the count for both ADD and 
	   DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_DHCP_OPTION, flags);

	/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

	/*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_MODIFY_F_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION(dhcp_option->iid, changed_count,
					  array_changed_fvp, flags, IFX_Handler)
	} else if (IFX_INT_ADD_F_SET(flags)) {
		/* In case of ADD operation, first update the ID Mappings and then send 
		   the Notification for the attributes */
		/*********** Epilog Block **************/
		UPDATE_ID_MAP_N_ATTRIBUTES(&dhcp_option->iid, count, array_fvp,
					   flags, IFX_Handler)

		    CHECK_N_SEND_NOTIFICATION(dhcp_option->iid, count,
					      array_fvp, flags, IFX_Handler)

		    /* Manipulate nextCpeId only for ADD operations */
		    ifx_increment_next_cpeId(FILE_RC_CONF, TAG_DHCP_OPTION);
	} else if (IFX_DELETE_F_SET(flags)) {
		/* In case of DELETE operation, first send the notificatioupdate the ID 
		   Mappings and then send the Notification for the attributes */
		/*********** Epilog Block **************/
		CHECK_N_SEND_NOTIFICATION(dhcp_option->iid, count, array_fvp,
					  flags, IFX_Handler)

		    UPDATE_ID_MAP_N_ATTRIBUTES(&dhcp_option->iid, count,
					       array_fvp, flags, IFX_Handler)
	}

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
#endif
#endif
		return IFX_SUCCESS;
}

int32 ifx_get_dhcp_option_count(uint32 * count)
{
#ifdef DEVICE_SUPPORT
#ifdef IFX_TR69_DEVICE_LAN
	uint32 outFlag = IFX_F_DEFAULT;
	char8 sValue[MAX_FILELINE_LEN];

	sValue[0] = '\0';
	*count = 0;
	if (ifx_GetObjData
	    (FILE_RC_CONF, TAG_DHCP_OPTION, "dhcp_opt_Count", IFX_F_GET_ANY,
	     &outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;
	}
	*count = atoi(sValue);

#endif
#endif
	return IFX_SUCCESS;
}


int32 ifx_get_nslookup_diag(NSLOOKUP_DIAG * nslookup_diag)
{
        int32 iRet = IFX_SUCCESS;

        /* sVal buffer should be large enough to accomodate
           the biggest string in the obj */
        char8 sVal[MAX_IF_NAME];
        uint32 ulInFlag = IFX_F_DEFAULT, ulOutFlag;

        /* TBD: flags are not considered. Also iid struct in NSLOOKUP_DIAG is not
           considered */

        memset(nslookup_diag, '\0', sizeof(NSLOOKUP_DIAG));

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_NSLOOKUP_DIAG_SECTION,
                                   IFX_NSLOOKUP_DIAG_SECTION "_"
                                   IFX_NSLOOKUP_DIAG_DIAGSTATE, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {

                goto IFX_Handler;
        }
        if ((strlen(sVal) + 1) > MAX_DIAGSTATE_LEN) {

                fprintf(stderr, "DiagState Value len exceeded=%d\n",
                        strlen(sVal));
                iRet = IFX_FAILURE;
                goto IFX_Handler;
        }
        strcpy(nslookup_diag->diag_state, sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_NSLOOKUP_DIAG_SECTION,
                                   IFX_NSLOOKUP_DIAG_SECTION "_"
                                   IFX_NSLOOKUP_DIAG_INTERFACE, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {

                goto IFX_Handler;
        }

        if ((strlen(sVal) + 1) > MAX_IF_NAME) {

                fprintf(stderr, "Interface Value len exceeded=%d\n",
                        strlen(sVal));
                iRet = IFX_FAILURE;
                goto IFX_Handler;
        }
        strcpy(nslookup_diag->interface, sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_NSLOOKUP_DIAG_SECTION,
                                   IFX_NSLOOKUP_DIAG_SECTION "_"
                                   IFX_NSLOOKUP_DIAG_HOSTNAME, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {

                goto IFX_Handler;
        }
        if ((strlen(sVal) + 1) > MAX_HOST_NAME) {

                fprintf(stderr, "Hostname Value len exceeded=%d\n",
                        strlen(sVal));
                iRet = IFX_FAILURE;
                goto IFX_Handler;
        }
        strcpy(nslookup_diag->hostname, sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_NSLOOKUP_DIAG_SECTION,
                                   IFX_NSLOOKUP_DIAG_SECTION "_"
                                   IFX_NSLOOKUP_DIAG_DNSSERVER, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {

                goto IFX_Handler;
        }

        if ((strlen(sVal) + 1) > MAX_HOST_NAME) {

                fprintf(stderr, "DNS Server Value len exceeded=%d\n",
                        strlen(sVal));
                iRet = IFX_FAILURE;
                goto IFX_Handler;
        }
        strcpy(nslookup_diag->dnsserver, sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_NSLOOKUP_DIAG_SECTION,
                                   IFX_NSLOOKUP_DIAG_SECTION "_"
                                   IFX_NSLOOKUP_DIAG_TIMEOUT, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {

                goto IFX_Handler;
        }        
        nslookup_diag->timeout =  atoi(sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_NSLOOKUP_DIAG_SECTION,
                                   IFX_NSLOOKUP_DIAG_SECTION "_"
                                   IFX_NSLOOKUP_DIAG_NUMBEROFREPETITIONS, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {

                goto IFX_Handler;
        }
        nslookup_diag->num_repetitions =  atoi(sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_NSLOOKUP_DIAG_SECTION,
                                   IFX_NSLOOKUP_DIAG_SECTION "_"
                                   IFX_NSLOOKUP_DIAG_SUCCESSCOUNT, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {

                goto IFX_Handler;
        }
        nslookup_diag->success_count =  atoi(sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_NSLOOKUP_DIAG_SECTION,
                                   IFX_NSLOOKUP_DIAG_SECTION "_"
                                   IFX_NSLOOKUP_DIAG_RESULTNUMBEROFENTRIES, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {

                goto IFX_Handler;
        }
        nslookup_diag->result_num_entries =  atoi(sVal);

 IFX_Handler:
        return (iRet);
}

int32 ifx_set_nslookup_diag(NSLOOKUP_DIAG * nslookup_diag, uint32 flags)
{
        int32 iRet = IFX_SUCCESS;

        /* sVal should always be large enough to accomodate
           the biggest string in the obj */
        char8 *sVal = NULL;
        sVal = (char8 *) malloc(512);

        if (sVal == NULL) {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("%s:%d Error--> Failed to Malloc !!\n", __FUNCTION__,
                        __LINE__);
#endif
                goto IFX_Handler;
        }
        sprintf(sVal, "%s_cpeId=\"%d\"\n", IFX_NSLOOKUP_DIAG_SECTION,
                nslookup_diag->iid.cpeId.Id);

        sprintf(sVal, "%s%s_pcpeId=\"%d\"\n", sVal,IFX_NSLOOKUP_DIAG_SECTION,
                nslookup_diag->iid.pcpeId.Id);

        sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_NSLOOKUP_DIAG_SECTION,
                IFX_NSLOOKUP_DIAG_DIAGSTATE, nslookup_diag->diag_state);

        sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_NSLOOKUP_DIAG_SECTION,
                IFX_NSLOOKUP_DIAG_INTERFACE, nslookup_diag->interface);

        sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_NSLOOKUP_DIAG_SECTION,
                IFX_NSLOOKUP_DIAG_HOSTNAME, nslookup_diag->hostname);

        sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_NSLOOKUP_DIAG_SECTION,
                IFX_NSLOOKUP_DIAG_DNSSERVER, nslookup_diag->dnsserver);

        sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_NSLOOKUP_DIAG_SECTION,
                IFX_NSLOOKUP_DIAG_TIMEOUT, nslookup_diag->timeout);

        sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_NSLOOKUP_DIAG_SECTION,
                IFX_NSLOOKUP_DIAG_NUMBEROFREPETITIONS, nslookup_diag->num_repetitions);

        sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_NSLOOKUP_DIAG_SECTION,
                IFX_NSLOOKUP_DIAG_SUCCESSCOUNT, nslookup_diag->success_count);

        sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_NSLOOKUP_DIAG_SECTION,
                IFX_NSLOOKUP_DIAG_RESULTNUMBEROFENTRIES,nslookup_diag->result_num_entries);

        if ((iRet = ifx_SetObjData(IFX_DIAG_FILE, IFX_NSLOOKUP_DIAG_SECTION,
                                   flags, 1, sVal)) != IFX_SUCCESS)
                goto IFX_Handler;

      IFX_Handler:
            IFX_MEM_FREE(sVal);
        return iRet;
}

int32 ifx_get_result(RESULT * result)
{
        int32 ret = IFX_SUCCESS;
        uint32 outFlag = IFX_F_DEFAULT;
        uint32 resultIdx;
        char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];

        sprintf(result->iid.cpeId.secName, "%s", IFX_RESULT_SECTION);
        sprintf(result->iid.pcpeId.secName, "%s", IFX_NSLOOKUP_DIAG_SECTION);

        resultIdx = result->iid.cpeId.Id - 1;

        sprintf(buf, "%s_%d_%s", IFX_RESULT_SECTION, resultIdx,
                IFX_RESULT_STATUS);
        if ((ret = ifx_GetObjData(IFX_DIAG_FILE, IFX_RESULT_SECTION,
                                  buf, IFX_F_GET_ANY, &outFlag,
                                  sValue)) != IFX_SUCCESS) {
                goto IFX_Handler;
        }
        sprintf(result->status, "%s", sValue);

        sprintf(buf, "%s_%d_%s", IFX_RESULT_SECTION, resultIdx,
                IFX_RESULT_ANSWERTYPE);
        if ((ret = ifx_GetObjData(IFX_DIAG_FILE, IFX_RESULT_SECTION,
                                  buf, IFX_F_GET_ANY, &outFlag,
                                  sValue)) != IFX_SUCCESS) {
                goto IFX_Handler;
        }
        sprintf(result->anstype, "%s", sValue);

        sprintf(buf, "%s_%d_%s", IFX_RESULT_SECTION, resultIdx,
                IFX_RESULT_HOSTNAMERETURNED);
        if ((ret = ifx_GetObjData(IFX_DIAG_FILE, IFX_RESULT_SECTION,
                                  buf, IFX_F_GET_ANY, &outFlag,
                                  sValue)) != IFX_SUCCESS) {
                goto IFX_Handler;
        }
        sprintf(result->hostname_ret, "%s", sValue);

        sprintf(buf, "%s_%d_%s", IFX_RESULT_SECTION, resultIdx,
                IFX_RESULT_IPADDRESSES);
        if ((ret = ifx_GetObjData(IFX_DIAG_FILE, IFX_RESULT_SECTION,
                                  buf, IFX_F_GET_ANY, &outFlag,
                                  sValue)) != IFX_SUCCESS) {
                goto IFX_Handler;
        }
        sprintf(result->ipaddresses, "%s", sValue);

        sprintf(buf, "%s_%d_%s", IFX_RESULT_SECTION, resultIdx,
                IFX_RESULT_DNSSERVERIP);
        if ((ret = ifx_GetObjData(IFX_DIAG_FILE, IFX_RESULT_SECTION,
                                  buf, IFX_F_GET_ANY, &outFlag,
                                  sValue)) != IFX_SUCCESS) {
                goto IFX_Handler;
        }
        sprintf(result->dnsserver_ip, "%s", sValue);

        sprintf(buf, "%s_%d_%s", IFX_RESULT_SECTION, resultIdx,
                IFX_RESULT_RESPONSETIME);
        if ((ret = ifx_GetObjData(IFX_DIAG_FILE, IFX_RESULT_SECTION,
                                  buf, IFX_F_GET_ANY, &outFlag,
                                  sValue)) != IFX_SUCCESS) {
                goto IFX_Handler;
        }
        result->resp_time = atoi( sValue);

      IFX_Handler:

        if (ret != IFX_SUCCESS) {
                IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
                return ret;
        } else
    return IFX_SUCCESS;
}

int32 ifx_set_result(int32 operation, RESULT * result, uint32 flags)
{
        int32 ret = IFX_SUCCESS;
        char8 sbuf[MAX_FILELINE_LEN], conf_buf[MAX_DATA_LEN];
        uint32 count = 0;
        IFX_NAME_VALUE_PAIR array_fvp[MAX_FIELD_RANGE];

        memset(sbuf, 0, sizeof(sbuf));
        memset(conf_buf, 0, sizeof(conf_buf));
        memset(array_fvp, 0, sizeof(array_fvp));

        if (operation == IFX_OP_DEL)
                flags |= IFX_F_DELETE;
        else if (operation == IFX_OP_ADD)
                flags |= IFX_F_INT_ADD;

        if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags))
        {
                IFX_VALIDATE_PTR(result)
                    IFX_VALIDATE_FLAGS(flags)
        }

        sprintf(result->iid.cpeId.secName, "%s", IFX_RESULT_SECTION);
        sprintf(result->iid.pcpeId.secName, "%s",
                IFX_NSLOOKUP_DIAG_SECTION);
        result->iid.pcpeId.Id = 1;

        /* Allocate CpeId and pCpeId */
        if (IFX_ADD_F_SET(flags)) {

                result->iid.cpeId.Id = 0;

                if (ifx_get_IID(&result->iid, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("[%s:%d] ifx_get_IID failed.\n", __func__,
                                __LINE__);
#endif
                        ret = IFX_FAILURE;
                        goto IFX_Handler;
                }
        }

        /* We assumed that instance id = cpe ID and result is supplied
 * properly by caller */
        count = 0;

        sprintf(array_fvp[count].fieldname, "%s_%d_%s", IFX_RESULT_SECTION,
                result->iid.cpeId.Id - 1, "cpeId");
        sprintf(array_fvp[count].value, "%d", result->iid.cpeId.Id);
        count++;

        sprintf(array_fvp[count].fieldname, "%s_%d_%s", IFX_RESULT_SECTION,
                result->iid.cpeId.Id - 1, "pcpeId");
        sprintf(array_fvp[count].value, "%d", result->iid.pcpeId.Id);
        count++;
        sprintf(array_fvp[count].fieldname, "%s_%d_%s", IFX_RESULT_SECTION,
                result->iid.cpeId.Id - 1, IFX_RESULT_STATUS);
        sprintf(array_fvp[count].value, "%s", result->status);
        count++;

        sprintf(array_fvp[count].fieldname, "%s_%d_%s", IFX_RESULT_SECTION,
                result->iid.cpeId.Id - 1, IFX_RESULT_ANSWERTYPE);
        sprintf(array_fvp[count].value, "%s", result->anstype);
        count++;

        sprintf(array_fvp[count].fieldname, "%s_%d_%s", IFX_RESULT_SECTION,
                result->iid.cpeId.Id - 1, IFX_RESULT_HOSTNAMERETURNED);
        sprintf(array_fvp[count].value, "%s", result->hostname_ret);
        count++;

        sprintf(array_fvp[count].fieldname, "%s_%d_%s", IFX_RESULT_SECTION,
                result->iid.cpeId.Id - 1, IFX_RESULT_IPADDRESSES);
        sprintf(array_fvp[count].value, "%s", result->ipaddresses);
        count++;

        sprintf(array_fvp[count].fieldname, "%s_%d_%s", IFX_RESULT_SECTION,
                result->iid.cpeId.Id - 1, IFX_RESULT_DNSSERVERIP);
        sprintf(array_fvp[count].value, "%s", result->dnsserver_ip);
        count++;

        sprintf(array_fvp[count].fieldname, "%s_%d_%s", IFX_RESULT_SECTION,
                result->iid.cpeId.Id - 1, IFX_RESULT_RESPONSETIME);
        sprintf(array_fvp[count].value, "%d", result->resp_time);
        count++;

        /* Convert the name value pair in array_fvp into string format
 * expected by rc.conf file */
        form_cfgdb_buf(conf_buf, count, array_fvp);

        /* RC.CONF Configuration block */
        ret =
            ifx_SetObjData(IFX_DIAG_FILE, IFX_RESULT_SECTION, flags, 1,
                           conf_buf);
        if (ret != IFX_SUCCESS) {

                // IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"PROBLEM LIES IN
                // SetObjData");
#ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] for conf_buf [%s] ret [%d]", __FUNCTION__,
                        __LINE__, conf_buf, ret);
#endif
                goto IFX_Handler;
        }

        /* Notify TR69 */
        if (IFX_INT_ADD_F_SET(flags)) {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] IFX_INT_ADD_F_SET.\n", __func__, __LINE__);
#endif
                UPDATE_ID_MAP_N_ATTRIBUTES(&result->iid, count, array_fvp,
                                           flags, IFX_Handler)
                    CHECK_N_SEND_NOTIFICATION(result->iid, count,array_fvp,
                                              flags, IFX_Handler)
                    ifx_increment_next_cpeId(FILE_RC_CONF,
                                             IFX_RESULT_SECTION);
        } else if (IFX_DELETE_F_SET(flags)) {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] IFX_DELETE_F_SET.\n", __func__, __LINE__);
#endif
                CHECK_N_SEND_NOTIFICATION(result->iid, count, array_fvp,
                                          flags, IFX_Handler)
                    UPDATE_ID_MAP_N_ATTRIBUTES(&result->iid, count,
                                               array_fvp, flags, IFX_Handler)
        }
#ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] DONE !!!!!!!\n", __func__, __LINE__);
#endif
      IFX_Handler:
        if (ret != IFX_SUCCESS)
                return ret;
        else
                return IFX_SUCCESS;
}


int32
ifx_get_cfgfile_version(char *version){
    
    char8 sVal[MAX_IF_NAME];
    uint32 ulInFlag = IFX_F_DEFAULT, outFlag;
    int32 ret = IFX_SUCCESS;

    if ((ret = ifx_GetObjData(FILE_RC_CONF, "ConfigID",
                                  "config_version", ulInFlag, &outFlag,
                                  sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Failed to get config_version!!!\n", __func__, __LINE__);
#endif
        goto IFX_Handler;
    }

    strcpy(version , sVal);

IFX_Handler:
    return ret;
}

int32 ifx_set_routehops(int32 operation, ROUTE_HOPS * route_hops, uint32 flags)
{
#ifdef IFX_TR69_TRACEROUTE
	int32 ret = IFX_SUCCESS;
	char8 sbuf[MAX_FILELINE_LEN], conf_buf[MAX_DATA_LEN];
	uint32 count = 0;
	IFX_NAME_VALUE_PAIR array_fvp[MAX_FIELD_RANGE];

	memset(sbuf, 0, sizeof(sbuf));
	memset(conf_buf, 0, sizeof(conf_buf));
	memset(array_fvp, 0, sizeof(array_fvp));

	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD)
		flags |= IFX_F_INT_ADD;

	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		IFX_VALIDATE_PTR(route_hops)
		    IFX_VALIDATE_FLAGS(flags)
	}

	sprintf(route_hops->iid.cpeId.secName, "%s", IFX_ROUTEHOPS_SECTION);
	sprintf(route_hops->iid.pcpeId.secName, "%s",
		IFX_TRACEROUTE_DIAG_SECTION);
	route_hops->iid.pcpeId.Id = 1;

	/* Allocate CpeId and pCpeId */
	if (IFX_ADD_F_SET(flags)) {

		route_hops->iid.cpeId.Id = 0;

		if (ifx_get_IID(&route_hops->iid, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] ifx_get_IID failed.\n", __func__,
				__LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	/* We assumed that instance id = cpe ID and route_hops is supplied properly by caller */
	count = 0;

	sprintf(array_fvp[count].fieldname, "%s_%d_%s", IFX_ROUTEHOPS_SECTION,
		route_hops->iid.cpeId.Id - 1, "cpeId");
	sprintf(array_fvp[count].value, "%d", route_hops->iid.cpeId.Id);
	count++;

	sprintf(array_fvp[count].fieldname, "%s_%d_%s", IFX_ROUTEHOPS_SECTION,
		route_hops->iid.cpeId.Id - 1, "pcpeId");
	sprintf(array_fvp[count].value, "%d", route_hops->iid.pcpeId.Id);
	count++;

	sprintf(array_fvp[count].fieldname, "%s_%d_%s", IFX_ROUTEHOPS_SECTION,
		route_hops->iid.cpeId.Id - 1, IFX_ROUTEHOPS_HOPHOST);
	sprintf(array_fvp[count].value, "%s", route_hops->hophost);
	count++;

	sprintf(array_fvp[count].fieldname, "%s_%d_%s", IFX_ROUTEHOPS_SECTION,
		route_hops->iid.cpeId.Id - 1, IFX_ROUTEHOPS_HOPHOSTADDR);
	sprintf(array_fvp[count].value, "%s", route_hops->hophost_address);
	count++;

	sprintf(array_fvp[count].fieldname, "%s_%d_%s", IFX_ROUTEHOPS_SECTION,
		route_hops->iid.cpeId.Id - 1, IFX_ROUTEHOPS_HOPERRCODE);
	sprintf(array_fvp[count].value, "%d", route_hops->hop_err_code);
	count++;

	sprintf(array_fvp[count].fieldname, "%s_%d_%s", IFX_ROUTEHOPS_SECTION,
		route_hops->iid.cpeId.Id - 1, IFX_ROUTEHOPS_HOPRTTTIMES);
	sprintf(array_fvp[count].value, "%s", route_hops->hop_rtt_time);
	count++;

	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);

	/* RC.CONF Configuration block */
	ret =
	    ifx_SetObjData(IFX_DIAG_FILE, IFX_ROUTEHOPS_SECTION, flags, 1,
			   conf_buf);
	if (ret != IFX_SUCCESS) {

		// IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"PROBLEM LIES IN SetObjData");
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] for conf_buf [%s] ret [%d]", __FUNCTION__,
			__LINE__, conf_buf, ret);
#endif
		goto IFX_Handler;
	}

	/* Notify TR69 */
	if (IFX_INT_ADD_F_SET(flags)) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] IFX_INT_ADD_F_SET.\n", __func__, __LINE__);
#endif
		UPDATE_ID_MAP_N_ATTRIBUTES(&route_hops->iid, count, array_fvp,
					   flags, IFX_Handler)
		    CHECK_N_SEND_NOTIFICATION(route_hops->iid, count, array_fvp,
					      flags, IFX_Handler)
		    ifx_increment_next_cpeId(FILE_RC_CONF,
					     IFX_ROUTEHOPS_SECTION);
	} else if (IFX_DELETE_F_SET(flags)) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] IFX_DELETE_F_SET.\n", __func__, __LINE__);
#endif
		CHECK_N_SEND_NOTIFICATION(route_hops->iid, count, array_fvp,
					  flags, IFX_Handler)
		    UPDATE_ID_MAP_N_ATTRIBUTES(&route_hops->iid, count,
					       array_fvp, flags, IFX_Handler)
	}
#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] DONE !!!!!!!\n", __func__, __LINE__);
#endif
      IFX_Handler:
	if (ret != IFX_SUCCESS)
		return ret;
	else
#endif
		return IFX_SUCCESS;

}

int32 ifx_get_routehops(ROUTE_HOPS * route_hops)
{
#ifdef IFX_TR69_TRACEROUTE
	int32 ret = IFX_SUCCESS;
	uint32 outFlag = IFX_F_DEFAULT;
	uint32 hopIdx;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];

	sprintf(route_hops->iid.cpeId.secName, "%s", IFX_ROUTEHOPS_SECTION);
	sprintf(route_hops->iid.pcpeId.secName, "%s",
		IFX_TRACEROUTE_DIAG_SECTION);

	hopIdx = route_hops->iid.cpeId.Id - 1;

	sprintf(buf, "%s_%d_%s", IFX_ROUTEHOPS_SECTION, hopIdx,
		IFX_ROUTEHOPS_HOPHOST);
	if ((ret = ifx_GetObjData(IFX_DIAG_FILE, IFX_ROUTEHOPS_SECTION,
				  buf, IFX_F_GET_ANY, &outFlag,
				  sValue)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	sprintf(route_hops->hophost, "%s", sValue);

	sprintf(buf, "%s_%d_%s", IFX_ROUTEHOPS_SECTION, hopIdx,
		IFX_ROUTEHOPS_HOPHOSTADDR);
	if ((ret = ifx_GetObjData(IFX_DIAG_FILE, IFX_ROUTEHOPS_SECTION,
				  buf, IFX_F_GET_ANY, &outFlag,
				  sValue)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	sprintf(route_hops->hophost_address, "%s", sValue);

	sprintf(buf, "%s_%d_%s", IFX_ROUTEHOPS_SECTION, hopIdx,
		IFX_ROUTEHOPS_HOPERRCODE);
	if ((ret = ifx_GetObjData(IFX_DIAG_FILE, IFX_ROUTEHOPS_SECTION,
				  buf, IFX_F_GET_ANY, &outFlag,
				  sValue)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	route_hops->hop_err_code = atoi(sValue);

	sprintf(buf, "%s_%d_%s", IFX_ROUTEHOPS_SECTION, hopIdx,
		IFX_ROUTEHOPS_HOPRTTTIMES);
	if ((ret = ifx_GetObjData(IFX_DIAG_FILE, IFX_ROUTEHOPS_SECTION,
				  buf, IFX_F_GET_ANY, &outFlag,
				  sValue)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	sprintf(route_hops->hop_rtt_time, "%s", sValue);

      IFX_Handler:

	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
#endif
		return IFX_SUCCESS;
}

int32 ifx_get_traceroute_diag(TRACEROUTE_DIAG * traceroute_diag)
{
	int32 iRet = IFX_SUCCESS;
#ifdef IFX_TR69_TRACEROUTE

	/* sVal buffer should be large enough to accomodate
	   the biggest string in the obj */
	char8 sVal[MAX_IF_NAME];
	uint32 ulInFlag = IFX_F_DEFAULT, ulOutFlag;

	/* TBD: flags are not considered. Also iid struct in TRACEROUTE_DIAG is not
	   considered */

	memset(traceroute_diag, '\0', sizeof(TRACEROUTE_DIAG));

	if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_TRACEROUTE_DIAG_SECTION,
				   IFX_TRACEROUTE_DIAG_SECTION "_"
				   IFX_TRACEROUTE_DIAG_DIAGSTATE, ulInFlag,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {

		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_DIAGSTATE_LEN) {

		fprintf(stderr, "DiagState Value len exceeded=%d\n",
			strlen(sVal));
		iRet = IFX_FAILURE;
		goto IFX_Handler;
	}
	strcpy(traceroute_diag->diag_state, sVal);

	if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_TRACEROUTE_DIAG_SECTION,
				   IFX_TRACEROUTE_DIAG_SECTION "_"
				   IFX_TRACEROUTE_DIAG_INTERFACE, ulInFlag,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {

		goto IFX_Handler;
	}

	if ((strlen(sVal) + 1) > MAX_IF_NAME) {

		fprintf(stderr, "Interface Value len exceeded=%d\n",
			strlen(sVal));
		iRet = IFX_FAILURE;
		goto IFX_Handler;
	}
	strcpy(traceroute_diag->interface, sVal);

	if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_TRACEROUTE_DIAG_SECTION,
				   IFX_TRACEROUTE_DIAG_SECTION "_"
				   IFX_TRACEROUTE_DIAG_HOST, ulInFlag,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {

		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_HOST_NAME) {

		fprintf(stderr, "Host Value len exceeded=%d\n", strlen(sVal));
		iRet = IFX_FAILURE;
		goto IFX_Handler;
	}
	strcpy(traceroute_diag->host, sVal);

	if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_TRACEROUTE_DIAG_SECTION,
				   IFX_TRACEROUTE_DIAG_SECTION "_"
				   IFX_TRACEROUTE_DIAG_NUMTRY, ulInFlag,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {

		goto IFX_Handler;
	}
	traceroute_diag->num_tries = atoi(sVal);

	if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_TRACEROUTE_DIAG_SECTION,
				   IFX_TRACEROUTE_DIAG_SECTION "_"
				   IFX_TRACEROUTE_DIAG_TIMEOUT, ulInFlag,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	traceroute_diag->timeout = atoi(sVal);

	if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_TRACEROUTE_DIAG_SECTION,
				   IFX_TRACEROUTE_DIAG_SECTION "_"
				   IFX_TRACEROUTE_DIAG_DATASIZE, ulInFlag,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	traceroute_diag->data_size = atoi(sVal);

	if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_TRACEROUTE_DIAG_SECTION,
				   IFX_TRACEROUTE_DIAG_SECTION "_"
				   IFX_TRACEROUTE_DIAG_DSCP, ulInFlag,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}

	traceroute_diag->dscp = atoi(sVal);

	if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_TRACEROUTE_DIAG_SECTION,
				   IFX_TRACEROUTE_DIAG_SECTION "_"
				   IFX_TRACEROUTE_DIAG_MAXHOPCNT, ulInFlag,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	traceroute_diag->max_hop_count = atoi(sVal);

	if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_TRACEROUTE_DIAG_SECTION,
				   IFX_TRACEROUTE_DIAG_SECTION "_"
				   IFX_TRACEROUTE_DIAG_RESPTIME, ulInFlag,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	traceroute_diag->resp_time = atoi(sVal);

	if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_TRACEROUTE_DIAG_SECTION,
				   IFX_TRACEROUTE_DIAG_SECTION "_"
				   IFX_TRACEROUTE_DIAG_NUMOFROUTEHOPS, ulInFlag,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	traceroute_diag->root_hop_num_entries = atoi(sVal);

      IFX_Handler:
#endif
	return (iRet);
}

int32 ifx_set_traceroute_diag(TRACEROUTE_DIAG * traceroute_diag, uint32 flags)
{
	int32 iRet = IFX_SUCCESS;
#ifdef IFX_TR69_TRACEROUTE

	/* sVal should always be large enough to accomodate
	   the biggest string in the obj */
	char8 *sVal = NULL;

	sVal = (char8 *) malloc(512);

	if (sVal == NULL) {
		IFX_DBG("%s:%d Error--> Failed to Malloc !!\n", __FUNCTION__,
			__LINE__);
		goto IFX_Handler;
	}

	sprintf(sVal, "%s_cpeId=\"%d\"\n", IFX_TRACEROUTE_DIAG_SECTION,
		traceroute_diag->iid.cpeId.Id);

	sprintf(sVal, "%s%s_pcpeId=\"%d\"\n", sVal, IFX_TRACEROUTE_DIAG_SECTION,
		traceroute_diag->iid.pcpeId.Id);

	sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_TRACEROUTE_DIAG_SECTION,
		IFX_TRACEROUTE_DIAG_DIAGSTATE, traceroute_diag->diag_state);

	sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_TRACEROUTE_DIAG_SECTION,
		IFX_TRACEROUTE_DIAG_INTERFACE, traceroute_diag->interface);

	sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_TRACEROUTE_DIAG_SECTION,
		IFX_TRACEROUTE_DIAG_HOST, traceroute_diag->host);

	sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_TRACEROUTE_DIAG_SECTION,
		IFX_TRACEROUTE_DIAG_NUMTRY, traceroute_diag->num_tries);

	sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_TRACEROUTE_DIAG_SECTION,
		IFX_TRACEROUTE_DIAG_TIMEOUT, traceroute_diag->timeout);

	sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_TRACEROUTE_DIAG_SECTION,
		IFX_TRACEROUTE_DIAG_DATASIZE, traceroute_diag->data_size);

	sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_TRACEROUTE_DIAG_SECTION,
		IFX_TRACEROUTE_DIAG_DSCP, traceroute_diag->dscp);

	sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_TRACEROUTE_DIAG_SECTION,
		IFX_TRACEROUTE_DIAG_MAXHOPCNT, traceroute_diag->max_hop_count);

	sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_TRACEROUTE_DIAG_SECTION,
		IFX_TRACEROUTE_DIAG_RESPTIME, traceroute_diag->resp_time);

	sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_TRACEROUTE_DIAG_SECTION,
		IFX_TRACEROUTE_DIAG_NUMOFROUTEHOPS,
		traceroute_diag->root_hop_num_entries);

	if ((iRet = ifx_SetObjData(IFX_DIAG_FILE, IFX_TRACEROUTE_DIAG_SECTION,
				   flags, 1, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;

      IFX_Handler:
	    IFX_MEM_FREE(sVal);
#endif
	return iRet;
}

#if 1				/* Cleanup routines for TraceRouteDiagnostics profile */

int32 ifx_cleanup_traceroute_tr69_maps(void)
{
	char8 *sVal = NULL;
	uint32 secOffset1 = 0;
	uint32 flags = 0;
	int len;
	char *str = NULL, *sVal_mod = NULL, tmp[100], *str_end;

        ifx_GetSection(FILE_RC_CONF, IFX_TR69_MAP_SECTION, &sVal, &secOffset1);
        if(sVal == NULL)
            return IFX_FAILURE;


	sVal_mod = (char *)malloc(20000);

        if(sVal_mod == NULL){
#ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Failed to malloc!! \n", __func__, __LINE__);
#endif
            IFX_MEM_FREE(sVal);
            return IFX_FAILURE;
        }

	len = strlen(sVal);

	str_end = sVal + len - 1;

	str = strstr(sVal, "#traceroute_routehops");

	memset(sVal_mod, '\0', 20000);

	if (str != NULL) {
		strncpy(sVal_mod, sVal, (str - sVal));
		do {
			str++;
			if (*str == '#') {
				memset(tmp, '\0', 100);
				strncpy(tmp, str, 21);

				if (strcmp(tmp, "#traceroute_routehops") != 0) {
					strcat(sVal_mod, str);
					break;
				}
			}
			if (str >= str_end)
				break;
		} while (1);

		ifx_SetObjData(FILE_RC_CONF, IFX_TR69_MAP_SECTION, flags, 1,
			       sVal_mod);
	}
	IFX_MEM_FREE(sVal);
	IFX_MEM_FREE(sVal_mod);
	return 0;

}

int32 ifx_cleanup_traceroute_tr69_instances(void)
{

	char8 *sVal = NULL;
	uint32 secOffset1 = 0;
	uint32 flags = 0;
	char *buff = NULL, line[100], tmp[100], nxt_str[10];
	char *str = NULL;
	int nxt = 1, len, index, i;

        if (ifx_GetSection(FILE_RC_CONF, "tr69_instances", &sVal, &secOffset1)
            != IFX_SUCCESS) {
                IFX_DBG("[%s:%d]\n", __func__, __LINE__);
                return IFX_FAILURE;
        }
	len = strlen(sVal);
        str = sVal;
	buff = (char *)malloc(len + 1);
	if (buff == NULL) {
		IFX_DBG("[%s:%d] Failed to allocate %d bytes\n", __func__,
			__LINE__, len + 1);
                IFX_MEM_FREE(sVal);
		return IFX_FAILURE;
	}
	memset(buff, '\0', len + 1);

	do {
		if (*str == '#') {
			memset(line, '\0', 100);
			i = 0;
			do {
				line[i++] = *str;
				str++;
				if (*(str) == '\n')
					break;
			} while (1);

			memset(tmp, '\0', 100);
			sscanf(line, "#%d=%s", &index, tmp);
			if (strstr(line, "-1000.-3600.-3611.") == NULL) {
				memset(nxt_str, '\0', 10);
				sprintf(nxt_str, "%d", nxt);
				strcat(buff, "#");
				strcat(buff, nxt_str);
				strcat(buff, "=");
				strcat(buff, tmp);
				strcat(buff, "\n");
				nxt++;
			}

		} else
			str++;

		if (str >= sVal + len)
			break;

	} while (1);
	if (ifx_SetObjData(FILE_RC_CONF, "tr69_instances", flags, 1, buff) !=
	    IFX_SUCCESS) {
		IFX_DBG("Failed to set tr69_instances [%s:%d]\n", __func__, __LINE__);
	}
	IFX_MEM_FREE(sVal);
	IFX_MEM_FREE(buff);
	return 0;
}

int32 ifx_reset_traceroute_next_cpeid(void)
{

	char8 sValue[50];
	memset(sValue, '\0', 50);

	strcpy(sValue, "traceroute_routehops_nextCpeId=\"2\"\n");

	if((ifx_SetObjData(FILE_RC_CONF, "next_cpeid", IFX_F_MODIFY, 1, sValue)) != IFX_SUCCESS){
#ifdef IFX_LOG_DEBUG
                    IFX_DBG("[%s:%d] ifx_SetObjData Failed !! \n", __func__, __LINE__);
#endif
        }
	return 0;
}

#endif


int32 ifx_cleanup_nslookup_tr69_maps(void)
{
        char8 *sVal = NULL;
        uint32 secOffset1 = 0;
        uint32 flags = 0;
        int len;
        char *str = NULL, *sVal_mod = NULL, tmp[100], *str_end;

        ifx_GetSection(FILE_RC_CONF, IFX_TR69_MAP_SECTION, &sVal, &secOffset1);
        if(sVal == NULL)
            return 0;
       
        sVal_mod = (char *)malloc(20000); 
        if(sVal_mod == NULL){
#ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Failed to malloc!! \n", __func__, __LINE__);
#endif
            IFX_MEM_FREE(sVal);
            return IFX_FAILURE;
        }


        len = strlen(sVal);

        str_end = sVal + len - 1;

        str = strstr(sVal, "#nslookup_result");

        memset(sVal_mod, '\0', 20000);

        if (str != NULL) {
                strncpy(sVal_mod, sVal, (str - sVal));
                do {
                        str++;
                        if (*str == '#') {
                                memset(tmp, '\0', 100);
                                strncpy(tmp, str, 16);

                                if (strcmp(tmp, "#nslookup_result") != 0) {
                                        strcat(sVal_mod, str);
                                        break;
                                }
                        }
                        if (str >= str_end)
                                break;
                } while (1);

                if((ifx_SetObjData(FILE_RC_CONF, IFX_TR69_MAP_SECTION, flags, 1,
                               sVal_mod)) != IFX_SUCCESS){
#ifdef IFX_LOG_DEBUG
                    IFX_DBG("[%s:%d] ifx_SetObjData Failed !! \n", __func__, __LINE__);
#endif
                }            
        }
        IFX_MEM_FREE(sVal);
        IFX_MEM_FREE(sVal_mod);
        return 0;

}

int32 ifx_cleanup_nslookup_tr69_instances(void)
{

        char8 *sVal = NULL;
        uint32 secOffset1 = 0;
        uint32 flags = 0;
        char *buff = NULL, line[100], tmp[100], nxt_str[10];
        char *str = NULL;
        int nxt = 1, len, index, i;

        if (ifx_GetSection(FILE_RC_CONF, "tr69_instances", &sVal, &secOffset1)
            != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] Get tr69_instances failed!!\n", __func__, __LINE__);
#endif
                return IFX_FAILURE;
        }

        len = strlen(sVal);
        str = sVal;
        buff = (char *)malloc(len + 1);
        if (buff == NULL) {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] Failed to allocate %d bytes\n", __func__,
                        __LINE__, len + 1);
#endif
                IFX_MEM_FREE(sVal);
                return IFX_FAILURE;
        }
        memset(buff, '\0', len + 1);

        do {
                if (*str == '#') {
                        memset(line, '\0', 100);
                        i = 0;
                        do {
                                line[i++] = *str;
                                str++;
                                if (*(str) == '\n')
                                        break;
                        } while (1);

                        memset(tmp, '\0', 100);
                        sscanf(line, "#%d=%s", &index, tmp);
                        if (strstr(line, "-1000.-6000.-6011.") == NULL) {
                                memset(nxt_str, '\0', 10);
                                sprintf(nxt_str, "%d", nxt);
                                strcat(buff, "#");
                                strcat(buff, nxt_str);
                                strcat(buff, "=");
                                strcat(buff, tmp);
                                strcat(buff, "\n");
                                nxt++;
                        }
                } else
                        str++;

                if (str >= sVal + len)
                        break;

        } while (1);

        if (ifx_SetObjData(FILE_RC_CONF, "tr69_instances", flags, 1, buff) !=
            IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("Set failed for tr69_instances [%s:%d]\n", __func__, __LINE__);
#endif
        }

        IFX_MEM_FREE(sVal);
        IFX_MEM_FREE(buff);

        return 0;
}

int32 ifx_reset_nslookup_next_cpeid(void)
{

        char8 sValue[50];
        memset(sValue, '\0', 50);

        strcpy(sValue, "nslookup_result_nextCpeId=\"2\"\n");

        ifx_SetObjData(FILE_RC_CONF, "next_cpeid", IFX_F_MODIFY, 1, sValue);

        return 0;
}


int32 ifx_get_next_download(QUEUED_DOWNLOAD_STRUCT *xQD)
{
    char8 sVal[MAX_FILELINE_LEN] , sBuf[MAX_FILELINE_LEN];
    uint32 flags = IFX_F_GET_ANY;
    uint32 ulOutFlag;
    int32 iRtn = IFX_SUCCESS , iIdx = 0;

    if(xQD == NULL){
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : Null Pointer  !!\n\n",
                    __func__,__LINE__);
#endif
        return IFX_FAILURE;
    }

    memset(sVal, '\0', MAX_FILELINE_LEN);
    memset(xQD , '\0' , sizeof(QUEUED_DOWNLOAD_STRUCT));
    strcpy(xQD->FutureTime," ");

    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   IFX_QUEUED_DOWNLOAD_SECTION "_"
                                   IFX_QUEUED_DOWNLOAD_COUNT , flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed  !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }

    if(atoi(sVal) == 0){
        // If no pending downloads, return success
        iRtn = IFX_SUCCESS;
        goto IFX_Handler;
    }

    // Get index of the next download and populate the structure using it.

    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   IFX_QUEUED_DOWNLOAD_SECTION "_"
                                   IFX_QUEUED_DOWNLOAD_NEXT_QUEUED_IDX, flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }

    iIdx = atoi(sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_DOWNLOAD_SECTION,iIdx,IFX_QUEUED_DOWNLOAD_COMMANDKEY);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xQD->CommandKey , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_DOWNLOAD_SECTION,iIdx,IFX_QUEUED_DOWNLOAD_FILETYPE);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xQD->FileType , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_DOWNLOAD_SECTION,iIdx,IFX_QUEUED_DOWNLOAD_FILENAME);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xQD->FileName , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_DOWNLOAD_SECTION,iIdx,IFX_QUEUED_DOWNLOAD_USERNAME);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xQD->Username , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_DOWNLOAD_SECTION,iIdx,IFX_QUEUED_DOWNLOAD_PASSWORD);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xQD->Password , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_DOWNLOAD_SECTION,iIdx,IFX_QUEUED_DOWNLOAD_FILESIZE);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xQD->FileSize , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_DOWNLOAD_SECTION,iIdx,IFX_QUEUED_DOWNLOAD_FUTURETIME);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xQD->FutureTime , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_DOWNLOAD_SECTION,iIdx,IFX_QUEUED_DOWNLOAD_STARTTIME);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xQD->StartTime , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_DOWNLOAD_SECTION,iIdx,IFX_QUEUED_DOWNLOAD_ENDTIME);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xQD->EndTime , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_DOWNLOAD_SECTION,iIdx,IFX_QUEUED_DOWNLOAD_STATUS);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xQD->Status , sVal);

    iRtn = iIdx;

IFX_Handler:
    return iRtn;

}

/*Reset the values of queued_download section entry based on index passed*/
int32 ltq_reset_download(int32 iIdx, int32 iFlags)
{
    char8 sVal[MAX_DATA_LEN] = {0}; 
    int32 iRtn = 0;
    char8 sBuf[MAX_FILELINE_LEN] ;
    uint32 ulOutFlag = 0, iCount = 0;

    sprintf(sVal, "%s_%d_%s=\"\"\n", IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                               IFX_QUEUED_DOWNLOAD_COMMANDKEY);

    sprintf(sVal, "%s%s_%d_%s=\"\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                IFX_QUEUED_DOWNLOAD_FILETYPE);

    sprintf(sVal, "%s%s_%d_%s=\"\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                IFX_QUEUED_DOWNLOAD_FILENAME);

    sprintf(sVal, "%s%s_%d_%s=\"\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                IFX_QUEUED_DOWNLOAD_USERNAME);

    sprintf(sVal, "%s%s_%d_%s=\"\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                IFX_QUEUED_DOWNLOAD_PASSWORD);

    sprintf(sVal, "%s%s_%d_%s=\"\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                IFX_QUEUED_DOWNLOAD_FILESIZE);

    sprintf(sVal, "%s%s_%d_%s=\"0\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                IFX_QUEUED_DOWNLOAD_FUTURETIME);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                IFX_QUEUED_DOWNLOAD_STARTTIME, "0001-01-01T00:00:00Z");

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                IFX_QUEUED_DOWNLOAD_ENDTIME, "0001-01-01T00:00:00Z");

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                IFX_QUEUED_DOWNLOAD_STATUS, IFX_DOWNLOAD_STATUS_NONE);

    sprintf(sVal, "%s%s_%d_%s=\"%d\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                IFX_QUEUED_DOWNLOAD_IS_COMPLETE, IFX_TRANSFER_ISCOMPLETE_DEFAULT);

    if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_QUEUED_DOWNLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sVal)) != IFX_SUCCESS)
    {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_SetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
        goto IFX_Handler;
    }
    if(iFlags == 1)
    {
        if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   IFX_QUEUED_DOWNLOAD_SECTION "_"
                                   IFX_QUEUED_DOWNLOAD_COUNT, IFX_F_GET_ANY,
                                   &ulOutFlag, sBuf)) != IFX_SUCCESS)
        {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }
        iCount = atoi(sBuf);
        iCount--;

        sprintf(sBuf, "%s_%s=\"%d\"\n", IFX_QUEUED_DOWNLOAD_SECTION, IFX_QUEUED_DOWNLOAD_COUNT, iCount);
        if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_QUEUED_DOWNLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sBuf)) != IFX_SUCCESS)
        {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }
        if (ifx_flash_write() <= 0)
        {
            return IFX_FAILURE;
        }
    }
IFX_Handler:
    return iRtn;
}

/*Set values in the queued_download section.
Find the minimum future time.
Set the index to that id
Return value will contain the future time of the next download or error value
*/
int32 ifx_set_download(char download_params[10][256] ,int32 xTime, int32 * curr_index)
{
    char8 sVal[MAX_FILELINE_LEN] , sBuf[MAX_FILELINE_LEN] ;
    uint32 flags = IFX_F_GET_ANY;
    uint32 ulOutFlag;
    int32 iI , iRtn = IFX_SUCCESS , iIdx = 0 , nextCpeId = 0 , prevIdx = 0 , nextIdx = 0;
    int32 min_FutureTime = 0 , iCount = 0 ;

    // Get index of the current pending download
    sprintf(sBuf,"%s_%s",IFX_QUEUED_DOWNLOAD_SECTION,IFX_QUEUED_DOWNLOAD_NEXT_QUEUED_IDX);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   sBuf, flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
        goto IFX_Handler;
    }

    prevIdx = atoi(sVal);

    // Get the 3 status and overwrite the available index

    for(iI = 1 ; iI <=3 ; iI++)
    {
       sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_DOWNLOAD_SECTION,iI,IFX_QUEUED_DOWNLOAD_STATUS);
       if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   sBuf
                                   , flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }
        if(strcmp(IFX_DOWNLOAD_STATUS_NONE,sVal) == 0)
        {
            // If the value is uninitiated overwrite it
            iIdx = iI;
            break;
        }
        else if(((strcmp(sVal,IFX_DOWNLOAD_STATUS_PENDING) != 0) && (strcmp(sVal,IFX_DOWNLOAD_STATUS_NOTSTARTED) != 0)))
        {
                if(iI != prevIdx)
                {
                    iIdx = iI;
                    break;
                }
        }
    }
    *curr_index = iIdx;

    // Overwriting the available section   
    sprintf(sBuf,"%s_%s",IFX_QUEUED_DOWNLOAD_SECTION,"nextCpeId");
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,"next_cpeid" ,
                                   sBuf, flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
                                   
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
        goto IFX_Handler;
    }

    nextCpeId = atoi(sVal);

    sprintf(sVal, "%s_%d_cpeId=\"%d\"\n", IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                nextCpeId);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                IFX_QUEUED_DOWNLOAD_COMMANDKEY, download_params[0]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                IFX_QUEUED_DOWNLOAD_FILETYPE, download_params[1]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                IFX_QUEUED_DOWNLOAD_FILENAME, download_params[2]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                IFX_QUEUED_DOWNLOAD_USERNAME, download_params[3]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                IFX_QUEUED_DOWNLOAD_PASSWORD, download_params[4]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                IFX_QUEUED_DOWNLOAD_FILESIZE, download_params[5]);

    sprintf(sVal, "%s%s_%d_%s=\"%d\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                IFX_QUEUED_DOWNLOAD_FUTURETIME, xTime);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                IFX_QUEUED_DOWNLOAD_STARTTIME, "0001-01-01T00:00:00Z");

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                IFX_QUEUED_DOWNLOAD_ENDTIME, "0001-01-01T00:00:00Z");

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                IFX_QUEUED_DOWNLOAD_STATUS, IFX_DOWNLOAD_STATUS_NOTSTARTED);

    sprintf(sVal, "%s%s_%d_%s=\"%d\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iIdx,
                IFX_QUEUED_DOWNLOAD_IS_COMPLETE, 0);

    if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_QUEUED_DOWNLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sVal)) != IFX_SUCCESS)
    {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_SetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
        goto IFX_Handler;    
    }

    ifx_increment_next_cpeId(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION);

    // Checking for the least future time and modifying the status and next queue index accordingly
    for(iI = 1 ; iI <= 3 ; iI++)
    {
        sprintf(sBuf , "%s_%d_%s" , IFX_QUEUED_DOWNLOAD_SECTION , iI , IFX_QUEUED_DOWNLOAD_FUTURETIME);
        if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }
        if((strcmp(sVal,"0")!=0) && ((min_FutureTime == 0) || (min_FutureTime > atoi(sVal))))
        {
            nextIdx = iI;
            min_FutureTime = atoi(sVal);
        }
    }

    /* 
       Get the no of pending downloads and increment it, 
       If scheduled download has changed, set the status of the previously scheduled download and the new one
    */
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   IFX_QUEUED_DOWNLOAD_SECTION "_"
                                   IFX_QUEUED_DOWNLOAD_COUNT, flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
    }
    iCount = atoi(sVal);
    iCount++;
    sprintf(sVal, "%s_%s=\"%d\"\n", IFX_QUEUED_DOWNLOAD_SECTION,IFX_QUEUED_DOWNLOAD_COUNT,iCount);

    if(prevIdx != nextIdx)
    {
        /*Change index to the new one*/
        sprintf(sVal , "%s%s_%s=\"%d\"\n" , sVal, IFX_QUEUED_DOWNLOAD_SECTION , IFX_QUEUED_DOWNLOAD_NEXT_QUEUED_IDX, nextIdx);
        /* If there was another download sceduled, then set it's status*/
        if(prevIdx != 0)
            sprintf(sVal , "%s%s_%d_%s=\"%s\"\n" , sVal,IFX_QUEUED_DOWNLOAD_SECTION , prevIdx , IFX_QUEUED_DOWNLOAD_STATUS,IFX_DOWNLOAD_STATUS_NOTSTARTED);
        /*Set the status of the newly scheduled one*/
        sprintf(sVal , "%s%s_%d_%s=\"%s\"\n" , sVal,IFX_QUEUED_DOWNLOAD_SECTION , nextIdx , IFX_QUEUED_DOWNLOAD_STATUS,IFX_DOWNLOAD_STATUS_PENDING);
    }

    if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_QUEUED_DOWNLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sVal)) != IFX_SUCCESS)
    {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_SetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
        goto IFX_Handler;
    }

    if (ifx_flash_write() <= 0) {
        iRtn =  IFX_FAILURE;
        goto IFX_Handler;
    }

    return min_FutureTime;
IFX_Handler:
return iRtn;
                
}
    
int ifx_validate_download(int xTime)
{
    char8 sVal[MAX_FILELINE_LEN] ;
    uint32 flags = IFX_F_GET_ANY;
    uint32 ulOutFlag;
    int32 iRtn = IFX_SUCCESS;

    memset(sVal, '\0', MAX_FILELINE_LEN);
    
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   IFX_QUEUED_DOWNLOAD_SECTION "_"
                                   IFX_QUEUED_DOWNLOAD_COUNT, flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    if(atoi(sVal) == IFX_MAX_QUEUED_ENTRY)
        iRtn = 9004;

IFX_Handler:
    return iRtn;
}
int32 ifx_update_download(int status , char * StartTime , char * EndTime ,int iIsComplete , int iStatusFlag)
{
    char8 sVal[MAX_FILELINE_LEN]={0} , sBuf[MAX_FILELINE_LEN] = {0};
    uint32 flags = IFX_F_GET_ANY;
    uint32 ulOutFlag;
    int32 iI , iRtn = IFX_SUCCESS , iIdx = 0 , iCount = 0, min_FutureTime = 0 , nextIdx = 0;

    memset(sVal, '\0', MAX_FILELINE_LEN);
    

    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   IFX_QUEUED_DOWNLOAD_SECTION "_"
                                   IFX_QUEUED_DOWNLOAD_NEXT_QUEUED_IDX, flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
        goto IFX_Handler;
    }            
        
    iIdx = atoi(sVal);

    /*Update the status , start time and end time of the present download when called before reboot. Not required once 
      reboot is done(StatusFlag = FALSE)*/
    if(iStatusFlag != FALSE)
    {
        sprintf(sBuf , "%s_%d_%s=\"%d\"\n" , IFX_QUEUED_DOWNLOAD_SECTION , iIdx , IFX_QUEUED_DOWNLOAD_STATUS , status);
        sprintf(sBuf , "%s%s_%d_%s=\"%s\"\n" , sBuf,IFX_QUEUED_DOWNLOAD_SECTION , iIdx , IFX_QUEUED_DOWNLOAD_STARTTIME , StartTime);
        sprintf(sBuf , "%s%s_%d_%s=\"%s\"\n" , sBuf,IFX_QUEUED_DOWNLOAD_SECTION , iIdx , IFX_QUEUED_DOWNLOAD_ENDTIME , EndTime);
    } 
    sprintf(sBuf, "%s%s_%d_%s=\"%d\"\n", sBuf, IFX_QUEUED_DOWNLOAD_SECTION,iIdx,IFX_QUEUED_DOWNLOAD_IS_COMPLETE, iIsComplete);
    if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_QUEUED_DOWNLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sBuf)) != IFX_SUCCESS)
    {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_SetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
        goto IFX_Handler;
    }
    // if iStatus flag is FALSE update the section to point to the next download
    if(iStatusFlag == FALSE)
    {
        // Setting future time of the download just completed to blank
        sprintf(sBuf , "%s_%d_%s=\"0\"\n" , IFX_QUEUED_DOWNLOAD_SECTION , iIdx , IFX_QUEUED_DOWNLOAD_FUTURETIME);    

        if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_QUEUED_DOWNLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sBuf)) != IFX_SUCCESS)
        {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_SetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        } 

        if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   IFX_QUEUED_DOWNLOAD_SECTION "_"
                                   IFX_QUEUED_DOWNLOAD_COUNT, flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }
        iCount = atoi(sVal);
        iCount--;

        if(iCount != 0)
        {
            // Checking for the least future time and modifying the status and next queue index accordingly
            for(iI = 1 ; iI <= 3 ; iI++)
            {
                sprintf(sBuf , "%s_%d_%s" , IFX_QUEUED_DOWNLOAD_SECTION , iI , IFX_QUEUED_DOWNLOAD_FUTURETIME);
                if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   sBuf, flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
                {
#ifdef IFX_LOG_DEBUG
                    IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                    goto IFX_Handler;
                }
                if((strcmp(sVal,"0")!=0) && ((min_FutureTime == 0) || (min_FutureTime > atoi(sVal))))
                {
                    nextIdx = iI;
                    min_FutureTime = atoi(sVal);
                }
            }

        }
        else
        {
            nextIdx = 0;
        }
        sprintf(sVal, "%s_%s=\"%d\"\n", IFX_QUEUED_DOWNLOAD_SECTION, IFX_QUEUED_DOWNLOAD_COUNT, iCount);
        sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION, IFX_QUEUED_DOWNLOAD_NEXT_QUEUED_IDX, nextIdx);
        if(nextIdx != 0)
            sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,nextIdx,IFX_QUEUED_DOWNLOAD_STATUS,IFX_DOWNLOAD_STATUS_PENDING);
        if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_QUEUED_DOWNLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sVal)) != IFX_SUCCESS)
        {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }
    }
IFX_Handler:
    if (ifx_flash_write() <= 0) {
        return IFX_FAILURE;
    }
    return iRtn;
}



// QUEUED_UPLOAD
int32 ifx_get_next_upload(QUEUED_DOWNLOAD_STRUCT *xQU)
{   
    char8 sVal[MAX_FILELINE_LEN] , sBuf[MAX_FILELINE_LEN];
    uint32 flags = IFX_F_GET_ANY;
    uint32 ulOutFlag;
    int32 iRtn = IFX_SUCCESS , iIdx = 0;

    if(xQU == NULL){
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : Null Pointer  !!\n\n",
                    __func__,__LINE__);
#endif
        return IFX_FAILURE;
    }

    memset(sVal, '\0', MAX_FILELINE_LEN);
    memset(xQU , '\0' , sizeof(QUEUED_DOWNLOAD_STRUCT));
    strcpy(xQU->FutureTime," ");

    // Get the index of the next upload and use it to populate the structure

    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   IFX_QUEUED_UPLOAD_SECTION "_"
                                   IFX_QUEUED_UPLOAD_COUNT , flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed  !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    
    if(atoi(sVal) == 0){
        iRtn = IFX_SUCCESS;
        goto IFX_Handler;
    }

    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   IFX_QUEUED_UPLOAD_SECTION "_"
                                   IFX_QUEUED_UPLOAD_NEXT_QUEUED_IDX, flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }

    iIdx = atoi(sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_UPLOAD_SECTION,iIdx,IFX_QUEUED_UPLOAD_COMMANDKEY);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xQU->CommandKey , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_UPLOAD_SECTION,iIdx,IFX_QUEUED_UPLOAD_FILETYPE);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xQU->FileType , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_UPLOAD_SECTION,iIdx,IFX_QUEUED_UPLOAD_FILENAME);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xQU->FileName , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_UPLOAD_SECTION,iIdx,IFX_QUEUED_UPLOAD_USERNAME);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xQU->Username , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_UPLOAD_SECTION,iIdx,IFX_QUEUED_UPLOAD_PASSWORD);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xQU->Password , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_UPLOAD_SECTION,iIdx,IFX_QUEUED_UPLOAD_FUTURETIME);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xQU->FutureTime , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_UPLOAD_SECTION,iIdx,IFX_QUEUED_UPLOAD_STARTTIME);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xQU->StartTime , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_UPLOAD_SECTION,iIdx,IFX_QUEUED_UPLOAD_ENDTIME);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xQU->EndTime , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_UPLOAD_SECTION,iIdx,IFX_QUEUED_UPLOAD_STATUS);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xQU->Status , sVal);

    iRtn = iIdx;

IFX_Handler:
    return iRtn;
}

int32 ifx_set_upload(char download_params[10][256] ,int32 xTime)
{
    char *sVal=NULL , sBuf[MAX_FILELINE_LEN] ;   
    uint32 flags = IFX_F_GET_ANY;
    uint32 ulOutFlag;
    int32 iI , iRtn = IFX_SUCCESS , iIdx = 0 , prevCpeId = 0 , nextCpeId = 0 , prevIdx = 0 , nextIdx = 0;
    int32 min_FutureTime = 0 , iCount = 0 ;

    // Saving index of the next pending upload


    sVal = (char *)malloc(2000); //memleak fix

    sprintf(sBuf,"%s_%s",IFX_QUEUED_UPLOAD_SECTION,IFX_QUEUED_UPLOAD_NEXT_QUEUED_IDX);

    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   sBuf
                                   , flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
    }

    prevIdx = atoi(sVal);

    // Get the 3 status and overwrite the available index
    for(iI = 1 ; iI <=3 ; iI++)
    {
       sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_UPLOAD_SECTION,iI,IFX_QUEUED_UPLOAD_STATUS);
       if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   sBuf
                                   , flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }
        if(strcmp(IFX_UPLOAD_STATUS_NONE,sVal) == 0)
        {
            // If the value is uninitiated overwrite it
            iIdx = iI;
            goto overwrite;
        }
        else if(((strcmp(sVal,IFX_UPLOAD_STATUS_PENDING) != 0) && (strcmp(sVal,IFX_UPLOAD_STATUS_NOTSTARTED) != 0)))
        {
           // If the status is not pending and not started check for the older cpeId and overwrite
           sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_UPLOAD_SECTION,iI,IFX_QUEUED_UPLOAD_CPEID);
           if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   sBuf
                                   , flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
            }
            if(prevCpeId == 0)
            {
                iIdx = iI;
                prevCpeId = atoi(sVal);
            }
            else if(atoi(sVal) < prevCpeId)
            {
                iIdx = iI;
                prevCpeId = atoi(sVal);
            }
        }
    }

overwrite:
    // Overwriting the available section   
    sprintf(sBuf,"%s_%s",IFX_QUEUED_UPLOAD_SECTION,"nextCpeId");

    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,"next_cpeid" ,
                                   sBuf
                                   , flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
        goto IFX_Handler;
    }

    nextCpeId = atoi(sVal);

    sprintf(sVal, "%s_%d_cpeId=\"%d\"\n", IFX_QUEUED_UPLOAD_SECTION,iIdx,
                nextCpeId);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_UPLOAD_SECTION,iIdx,
                IFX_QUEUED_UPLOAD_COMMANDKEY, download_params[0]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_UPLOAD_SECTION,iIdx,
                IFX_QUEUED_UPLOAD_FILETYPE, download_params[1]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_UPLOAD_SECTION,iIdx,
                IFX_QUEUED_UPLOAD_FILENAME, download_params[2]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_UPLOAD_SECTION,iIdx,
                IFX_QUEUED_UPLOAD_USERNAME, download_params[3]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_UPLOAD_SECTION,iIdx,
                IFX_QUEUED_UPLOAD_PASSWORD, download_params[4]);

    sprintf(sVal, "%s%s_%d_%s=\"%d\"\n", sVal, IFX_QUEUED_UPLOAD_SECTION,iIdx,
                IFX_QUEUED_UPLOAD_FUTURETIME, xTime);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_UPLOAD_SECTION,iIdx,
                IFX_QUEUED_UPLOAD_STARTTIME, "0001-01-01T00:00:00Z");

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_UPLOAD_SECTION,iIdx,
                IFX_QUEUED_UPLOAD_ENDTIME, "0001-01-01T00:00:00Z");

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_UPLOAD_SECTION,iIdx,
                IFX_QUEUED_UPLOAD_STATUS, IFX_UPLOAD_STATUS_NOTSTARTED);
    sprintf(sVal, "%s%s_%d_%s=\"%d\"\n", sVal, IFX_QUEUED_UPLOAD_SECTION,iIdx,
                IFX_QUEUED_UPLOAD_IS_COMPLETE, 0);


    if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_QUEUED_UPLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sVal)) != IFX_SUCCESS)
    {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_SetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
        goto IFX_Handler;    
    }

    ifx_increment_next_cpeId(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION);

    // Checking for the least future time and modifying the status and next queue index accordingly
    for(iI = 1 ; iI <= 3 ; iI++)
    {
        sprintf(sBuf , "%s_%d_%s" , IFX_QUEUED_UPLOAD_SECTION , iI , IFX_QUEUED_UPLOAD_FUTURETIME);
        if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }
        if((strcmp(sVal,"0")!=0) && ((min_FutureTime == 0) || (min_FutureTime > atoi(sVal))))
        {
            nextIdx = iI;
            min_FutureTime = atoi(sVal);
        }
    }

    /* 
       Get the no of pending downloads and increment it, 
       If scheduled download has changed, set the status of the previously scheduled download and the new one
    */
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   IFX_QUEUED_UPLOAD_SECTION "_"
                                   IFX_QUEUED_UPLOAD_COUNT, flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
    }
    iCount = atoi(sVal);
    iCount++;
    sprintf(sVal, "%s_%s=\"%d\"\n", IFX_QUEUED_UPLOAD_SECTION,IFX_QUEUED_UPLOAD_COUNT,iCount);

    if(prevIdx != nextIdx)
    {
        //Update index and status of the previous and next, if older index and current calculated index are not equal
        sprintf(sVal , "%s%s_%s=\"%d\"\n" , sVal, IFX_QUEUED_UPLOAD_SECTION , IFX_QUEUED_UPLOAD_NEXT_QUEUED_IDX, nextIdx);
        if(prevIdx != 0)
            sprintf(sVal , "%s%s_%d_%s=\"%s\"\n" , sVal,IFX_QUEUED_UPLOAD_SECTION , prevIdx , IFX_QUEUED_UPLOAD_STATUS,IFX_UPLOAD_STATUS_NOTSTARTED);
        sprintf(sVal , "%s%s_%d_%s=\"%s\"\n" , sVal,IFX_QUEUED_UPLOAD_SECTION , nextIdx , IFX_QUEUED_UPLOAD_STATUS,IFX_UPLOAD_STATUS_PENDING);
    }

    if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_QUEUED_UPLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sVal)) != IFX_SUCCESS)
    {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_SetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
        goto IFX_Handler;
    }

    if (ifx_flash_write() <= 0) {
        iRtn = IFX_FAILURE;
        goto IFX_Handler;
    }
    if(sVal) free(sVal);
    return min_FutureTime;
IFX_Handler:
    if(sVal) free(sVal);
return iRtn;
}

int ifx_validate_upload(int xTime)
{
    char8 sVal[MAX_FILELINE_LEN] ;
    uint32 flags = IFX_F_GET_ANY;
    uint32 ulOutFlag;
    int32 iRtn = IFX_SUCCESS;

    memset(sVal, '\0', MAX_FILELINE_LEN);
    
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   IFX_QUEUED_UPLOAD_SECTION "_"
                                   IFX_QUEUED_UPLOAD_COUNT, flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    if(atoi(sVal) == 0)
        return IFX_SUCCESS;
    else if(atoi(sVal) == IFX_MAX_QUEUED_ENTRY)
        return 9004;    // Resource Exceeded

IFX_Handler:
    return iRtn;

}

int32 ifx_update_upload(int status , char * StartTime , char * EndTime , int iIsComplete , int iStatusFlag)
{
    char8 sVal[MAX_FILELINE_LEN] , sBuf[MAX_FILELINE_LEN];
    uint32 flags = IFX_F_GET_ANY;
    uint32 ulOutFlag;
    int32 iI , iRtn = IFX_SUCCESS , iIdx = 0 , iCount = 0, min_FutureTime = 0 , nextIdx = 0;

    memset(sVal, '\0', MAX_FILELINE_LEN);
    

    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   IFX_QUEUED_UPLOAD_SECTION "_"
                                   IFX_QUEUED_UPLOAD_NEXT_QUEUED_IDX, flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
        goto IFX_Handler;
    }            
    // Update the status , start time and end time of the present upload 
    iIdx = atoi(sVal);

    sprintf(sBuf , "%s_%d_%s=\"%d\"\n" , IFX_QUEUED_UPLOAD_SECTION , iIdx , IFX_QUEUED_UPLOAD_STATUS , status);
    sprintf(sBuf , "%s%s_%d_%s=\"%s\"\n" , sBuf,IFX_QUEUED_UPLOAD_SECTION , iIdx , IFX_QUEUED_UPLOAD_STARTTIME , StartTime);
    sprintf(sBuf , "%s%s_%d_%s=\"%s\"\n" , sBuf,IFX_QUEUED_UPLOAD_SECTION , iIdx , IFX_QUEUED_UPLOAD_ENDTIME , EndTime);
    sprintf(sBuf, "%s%s_%d_%s=\"%d\"\n", sBuf, IFX_QUEUED_UPLOAD_SECTION,iIdx,IFX_QUEUED_UPLOAD_IS_COMPLETE, iIsComplete);
    if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_QUEUED_UPLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sBuf)) != IFX_SUCCESS)
    {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_SetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
        goto IFX_Handler;
    }
    if(iStatusFlag == FALSE)
    {
        // if iStatus flag is FALSE update the section to point to the next upload
        sprintf(sBuf , "%s_%d_%s=\"0\"\n" , IFX_QUEUED_UPLOAD_SECTION , iIdx , IFX_QUEUED_UPLOAD_FUTURETIME);    

        if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_QUEUED_UPLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sBuf)) != IFX_SUCCESS)
        {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_SetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        } 

        /* 
            Decrement number of pending uploads
            Checking for the least future time and modifying the status and next queue index accordingly
        */
        if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   IFX_QUEUED_UPLOAD_SECTION "_"
                                   IFX_QUEUED_UPLOAD_COUNT, flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }
        iCount = atoi(sVal);
        iCount--;

        if(iCount != 0)
        {        
            // Checking for the least future time and modifying the status and next queue index accordingly
            for(iI = 1 ; iI <= 3 ; iI++)
            {
                sprintf(sBuf , "%s_%d_%s" , IFX_QUEUED_UPLOAD_SECTION , iI , IFX_QUEUED_UPLOAD_FUTURETIME);
                if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                    IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                    goto IFX_Handler;
                }
                if((strcmp(sVal,"0")!=0) && ((min_FutureTime == 0) || (min_FutureTime > atoi(sVal))))
                {
                    nextIdx = iI;
                    min_FutureTime = atoi(sVal);
                }
            } 
        }

        
        sprintf(sVal, "%s_%s=\"%d\"\n", IFX_QUEUED_UPLOAD_SECTION,IFX_QUEUED_UPLOAD_COUNT,iCount);
        sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_QUEUED_UPLOAD_SECTION,IFX_QUEUED_UPLOAD_NEXT_QUEUED_IDX,nextIdx);
        if(nextIdx != 0)
            sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_UPLOAD_SECTION,nextIdx,IFX_QUEUED_UPLOAD_STATUS,IFX_UPLOAD_STATUS_PENDING);
        if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_QUEUED_UPLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sVal)) != IFX_SUCCESS)
        {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }
    }
IFX_Handler:
    if (ifx_flash_write() <= 0) {
        return IFX_FAILURE;
    }
    return iRtn;
}
// TransferResponse
int32
get_all_queued_transfers(TRANSFER_LIST *xaTL)
{
    int32  iI = 0 , iJ = 0 , iCount = 0;
    char8 *pSecBuf = NULL , *sTmpValStart = NULL , *sTmp = NULL , sTmpVal[512] , sBuf[512];
    uint32 secOffset = 0;
    char8 caParams[9][32] = {"CommandKey" , "FileType" , "FileName" , "Filesize" , "Status" , "is_Complete"};
    
    while(1)
    {
        if(iCount == 0)
            sprintf(sBuf , IFX_QUEUED_DOWNLOAD_SECTION);
        else if(iCount == 3)
            sprintf(sBuf , IFX_QUEUED_UPLOAD_SECTION);
        else 
            sprintf(sBuf , IFX_SCHEDULE_DOWNLOAD_SECTION);
        pSecBuf = NULL;
        if (ifx_GetSection(FILE_RC_CONF , sBuf , &pSecBuf,
                              &secOffset) != IFX_SUCCESS) 
            goto errorHandler;
        for (iI = 1 ; iI <= 3 ; iI++)
        {
            for ( iJ = 0 ; iJ < 6 ; iJ++)
            {
                memset(sTmpVal , '\0' , sizeof(sTmpVal));
                memset(sBuf , '\0' , sizeof(sBuf));
                if(iCount < 3)
                   sprintf(sBuf , "%s_%d_%s" , IFX_QUEUED_DOWNLOAD_SECTION , iI ,caParams[iJ]);
                else if(iCount >= 3 && iCount < 6)
                   sprintf(sBuf , "%s_%d_%s" , IFX_QUEUED_UPLOAD_SECTION, iI ,caParams[iJ]);
                else
                    sprintf(sBuf , "%s_%d_%s" , IFX_SCHEDULE_DOWNLOAD_SECTION , iI ,caParams[iJ]);
                if((iJ == 3) && ((iCount > 2) && (iCount < 6)))
                    continue;
                sTmp = strstr(pSecBuf,sBuf);
                sTmpValStart = sTmp = strchr(sTmp , '\"') + 1; 
                sTmp = strchr(sTmp , '\"');
                strncpy(sTmpVal,sTmpValStart,(sTmp - sTmpValStart));
                if(iJ == 0){
                    strcpy(xaTL[iCount].CommandKey,sTmpVal);
                }
                else if(iJ == 1){
                    strcpy(xaTL[iCount].FileType,sTmpVal);
                }
                else if(iJ == 2){
                    strcpy(xaTL[iCount].TargetFileName,sTmpVal);
                }
                else if((iJ == 3) && (iCount <=2)){
                    sscanf(sTmpVal, "%u" , &(xaTL[iCount].FileSize));
                }
                else if(iJ == 4)
                {
                    if(strcmp(sTmpVal,IFX_DOWNLOAD_STATUS_PENDING) == 0)
                        xaTL[iCount].State = IFX_QUEUED_TRANSFERS_STATUS_IN_PROGRESS;
                    else if(strcmp(sTmpVal,IFX_DOWNLOAD_STATUS_NOTSTARTED) == 0)
                        xaTL[iCount].State = IFX_QUEUED_TRANSFERS_STATUS_NOTSTARTED;
                    else if(strcmp(sTmpVal,IFX_DOWNLOAD_STATUS_NONE) == 0)
                        xaTL[iCount].State = IFX_QUEUED_TRANSFERS_STATUS_NONE;
                    else
                        xaTL[iCount].State = IFX_QUEUED_TRANSFERS_STATUS_COMPLETED;
                }
                else if(iJ == 5)
                {
                    xaTL[iCount].isComplete = atoi(sTmpVal);
                }
            }
  
            
            xaTL[iCount].IsDownload = ((iCount < 3) || (iCount > 5))?1:0;
            iCount++; 
        }
        IFX_MEM_FREE(pSecBuf);
        if(iCount > 8)
            break;
    };

    return IFX_SUCCESS;

errorHandler:
    IFX_MEM_FREE(pSecBuf);
    return IFX_FAILURE;
}

int32 ifx_set_download_diag(DOWNLOAD_DIAG * download_diag, uint32 flags)
{
        int32 iRet = IFX_SUCCESS;

        /* sVal should always be large enough to accomodate
           the biggest string in the obj */
        char8 sVal[1024] = {0};

        sprintf(sVal, "%s_cpeId=\"%d\"\n", IFX_DOWNLOAD_DIAG_SECTION,
                download_diag->iid.cpeId.Id);
        sprintf(sVal, "%s%s_pcpeId=\"%d\"\n", sVal, IFX_DOWNLOAD_DIAG_SECTION,
                download_diag->iid.pcpeId.Id);
        sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_DOWNLOAD_DIAG_SECTION,
                IFX_DOWNLOAD_DIAG_DIAGSTATE, download_diag->diag_state);
        sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_DOWNLOAD_DIAG_SECTION,
                IFX_DOWNLOAD_DIAG_INTERFACE, download_diag->interface);
        sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_DOWNLOAD_DIAG_SECTION,
                IFX_DOWNLOAD_DIAG_DWNLDURL, download_diag->download_url);
        sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_DOWNLOAD_DIAG_SECTION,
                IFX_DOWNLOAD_DIAG_ETHERNETPRIORITY, download_diag->ethernet_priority);
        sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_DOWNLOAD_DIAG_SECTION,
                IFX_DOWNLOAD_DIAG_ROMTIME, download_diag->ROMTime);
        sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_DOWNLOAD_DIAG_SECTION,
                IFX_DOWNLOAD_DIAG_BOMTIME, download_diag->BOMTime);
        sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_DOWNLOAD_DIAG_SECTION,
                IFX_DOWNLOAD_DIAG_DSCP, download_diag->dscp);
        sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_DOWNLOAD_DIAG_SECTION,
                IFX_DOWNLOAD_DIAG_EOMTIME, download_diag->EOMTime);
        sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_DOWNLOAD_DIAG_SECTION,
                IFX_DOWNLOAD_DIAG_RXTESTBYTES, download_diag->rxTestBytes);
        sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_DOWNLOAD_DIAG_SECTION,
                IFX_DOWNLOAD_DIAG_RXTOTALBYTES,
                download_diag->rxTotalBytes);
        sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_DOWNLOAD_DIAG_SECTION,
                IFX_DOWNLOAD_DIAG_TCPOPENRQSTTIME, download_diag->tcpOpenRqstTime);
        sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_DOWNLOAD_DIAG_SECTION,
                IFX_DOWNLOAD_DIAG_TCPOPENRESPTIME, download_diag->tcpOpenRespTime);
        iRet = ifx_SetObjData(IFX_DIAG_FILE, IFX_DOWNLOAD_DIAG_SECTION,
                                   flags, 1, sVal) ;
        return iRet;
}

int32 ifx_get_download_diag(DOWNLOAD_DIAG * download_diag)
{
        int32 iRet = IFX_SUCCESS;

        /* sVal buffer should be large enough to accomodate
           the biggest string in the obj */
        char8 sVal[MAX_IF_NAME];
        uint32 ulInFlag = IFX_F_DEFAULT, ulOutFlag;

        memset(download_diag, '\0', sizeof(DOWNLOAD_DIAG));

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_DOWNLOAD_DIAG_SECTION,
                                   IFX_DOWNLOAD_DIAG_SECTION "_"
                                   IFX_DOWNLOAD_DIAG_DIAGSTATE, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {

                goto IFX_Handler;
        }
        if ((strlen(sVal) + 1) > MAX_DIAGSTATE_LEN) {

                fprintf(stderr, "DiagState Value len exceeded=%d\n",
                        strlen(sVal));
                iRet = IFX_FAILURE;
                goto IFX_Handler;
        }
        strcpy(download_diag->diag_state, sVal);
        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_DOWNLOAD_DIAG_SECTION,
                                   IFX_DOWNLOAD_DIAG_SECTION "_"
                                   IFX_DOWNLOAD_DIAG_INTERFACE, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {

                goto IFX_Handler;
        }
        if ((strlen(sVal) + 1) > MAX_IF_NAME) {

                fprintf(stderr, "Interface Value len exceeded=%d\n",
                        strlen(sVal));
                iRet = IFX_FAILURE;
                goto IFX_Handler;
        }
        strcpy(download_diag->interface, sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_DOWNLOAD_DIAG_SECTION,
                                   IFX_DOWNLOAD_DIAG_SECTION "_"
                                   IFX_DOWNLOAD_DIAG_DWNLDURL, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {

                goto IFX_Handler;
        }
        if ((strlen(sVal) + 1) > MAX_URL_LEN) {

                fprintf(stderr, "Host Value len exceeded=%d\n", strlen(sVal));
                iRet = IFX_FAILURE;
                goto IFX_Handler;
        }
        strcpy(download_diag->download_url, sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_DOWNLOAD_DIAG_SECTION,
                                   IFX_DOWNLOAD_DIAG_SECTION "_"
                                   IFX_DOWNLOAD_DIAG_ETHERNETPRIORITY, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {

                goto IFX_Handler;
        }
        download_diag->ethernet_priority = atoi(sVal);
        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_DOWNLOAD_DIAG_SECTION,
                                   IFX_DOWNLOAD_DIAG_SECTION "_"
                                   IFX_DOWNLOAD_DIAG_ROMTIME, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
                goto IFX_Handler;
        }
        strcpy(download_diag->ROMTime , sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_DOWNLOAD_DIAG_SECTION,
                                   IFX_DOWNLOAD_DIAG_SECTION "_"
                                   IFX_DOWNLOAD_DIAG_BOMTIME, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
                goto IFX_Handler;
        }
        strcpy(download_diag->BOMTime , sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_DOWNLOAD_DIAG_SECTION,
                                   IFX_DOWNLOAD_DIAG_SECTION "_"
                                   IFX_DOWNLOAD_DIAG_DSCP, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
                goto IFX_Handler;
        }

        download_diag->dscp = atoi(sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_DOWNLOAD_DIAG_SECTION,
                                   IFX_DOWNLOAD_DIAG_SECTION "_"
                                   IFX_DOWNLOAD_DIAG_EOMTIME, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
                goto IFX_Handler;
        }
        strcpy(download_diag->EOMTime , sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_DOWNLOAD_DIAG_SECTION,
                                   IFX_DOWNLOAD_DIAG_SECTION "_"
                                   IFX_DOWNLOAD_DIAG_RXTESTBYTES, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
                goto IFX_Handler;
        }
        download_diag->rxTestBytes = atoi(sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_DOWNLOAD_DIAG_SECTION,
                                   IFX_DOWNLOAD_DIAG_SECTION "_"
                                   IFX_DOWNLOAD_DIAG_RXTOTALBYTES, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
                goto IFX_Handler;
        }
        download_diag->rxTotalBytes = atoi(sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_DOWNLOAD_DIAG_SECTION,
                                   IFX_DOWNLOAD_DIAG_SECTION "_"
                                   IFX_DOWNLOAD_DIAG_TCPOPENRQSTTIME, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
                goto IFX_Handler;
        }
        strcpy(download_diag->tcpOpenRqstTime,sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_DOWNLOAD_DIAG_SECTION,
                                   IFX_DOWNLOAD_DIAG_SECTION "_"
                                   IFX_DOWNLOAD_DIAG_TCPOPENRESPTIME, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
                goto IFX_Handler;
        }
        strcpy(download_diag->tcpOpenRespTime,sVal);

      IFX_Handler:
        return (iRet);
}

// UploadTCP
int32 ifx_set_upload_diag(UPLOAD_DIAG * upload_diag, uint32 flags)
{
        int32 iRet = IFX_SUCCESS;

        /* sVal should always be large enough to accomodate
           the biggest string in the obj */
        char8 sVal[1024] = {0};

        sprintf(sVal, "%s_cpeId=\"%d\"\n", IFX_UPLOAD_DIAG_SECTION,
                upload_diag->iid.cpeId.Id);
        sprintf(sVal, "%s%s_pcpeId=\"%d\"\n", sVal, IFX_UPLOAD_DIAG_SECTION,
                upload_diag->iid.pcpeId.Id);
        sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_UPLOAD_DIAG_SECTION,
                IFX_UPLOAD_DIAG_DIAGSTATE, upload_diag->diag_state);
        sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_UPLOAD_DIAG_SECTION,
                IFX_UPLOAD_DIAG_INTERFACE, upload_diag->interface);
        sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_UPLOAD_DIAG_SECTION,
                IFX_UPLOAD_DIAG_UPLDURL, upload_diag->upload_url);
        sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_UPLOAD_DIAG_SECTION,
                IFX_UPLOAD_DIAG_ETHERNETPRIORITY, upload_diag->ethernet_priority);
        sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_UPLOAD_DIAG_SECTION,
                IFX_UPLOAD_DIAG_ROMTIME, upload_diag->ROMTime);
        sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_UPLOAD_DIAG_SECTION,
                IFX_UPLOAD_DIAG_BOMTIME, upload_diag->BOMTime);
        sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_UPLOAD_DIAG_SECTION,
                IFX_UPLOAD_DIAG_DSCP, upload_diag->dscp);
        sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_UPLOAD_DIAG_SECTION,
                IFX_UPLOAD_DIAG_EOMTIME, upload_diag->EOMTime);
        sprintf(sVal, "%s%s_%s=\"%u\"\n", sVal, IFX_UPLOAD_DIAG_SECTION,
                IFX_UPLOAD_DIAG_TESTFILELENGTH, upload_diag->test_file_len);
        sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_UPLOAD_DIAG_SECTION,
                IFX_UPLOAD_DIAG_TXTOTALBYTES,
                upload_diag->txTotalBytes);
        sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_UPLOAD_DIAG_SECTION,
                IFX_UPLOAD_DIAG_TCPOPENRQSTTIME, upload_diag->tcpOpenRqstTime);
        sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_UPLOAD_DIAG_SECTION,
                IFX_UPLOAD_DIAG_TCPOPENRESPTIME, upload_diag->tcpOpenRespTime);
        iRet = ifx_SetObjData(IFX_DIAG_FILE, IFX_UPLOAD_DIAG_SECTION,
                                   flags, 1, sVal) ;
        return iRet;
}

int32 ifx_get_upload_diag(UPLOAD_DIAG * upload_diag)
{
        int32 iRet = IFX_SUCCESS;

        /* sVal buffer should be large enough to accomodate
           the biggest string in the obj */
        char8 sVal[MAX_IF_NAME];
        uint32 ulInFlag = IFX_F_DEFAULT, ulOutFlag;

        memset(upload_diag, '\0', sizeof(UPLOAD_DIAG));

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_UPLOAD_DIAG_SECTION,
                                   IFX_UPLOAD_DIAG_SECTION "_"
                                   IFX_UPLOAD_DIAG_DIAGSTATE, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {

                goto IFX_Handler;
        }
        if ((strlen(sVal) + 1) > MAX_DIAGSTATE_LEN) {

                fprintf(stderr, "DiagState Value len exceeded=%d\n",
                        strlen(sVal));
                iRet = IFX_FAILURE;
                goto IFX_Handler;
        }
        strcpy(upload_diag->diag_state, sVal);
        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_UPLOAD_DIAG_SECTION,
                                   IFX_UPLOAD_DIAG_SECTION "_"
                                   IFX_UPLOAD_DIAG_INTERFACE, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {

                goto IFX_Handler;
        }
        if ((strlen(sVal) + 1) > MAX_IF_NAME) {

                fprintf(stderr, "Interface Value len exceeded=%d\n",
                        strlen(sVal));
                iRet = IFX_FAILURE;
                goto IFX_Handler;
        }
        strcpy(upload_diag->interface, sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_UPLOAD_DIAG_SECTION,
                                   IFX_UPLOAD_DIAG_SECTION "_"
                                   IFX_UPLOAD_DIAG_UPLDURL, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {

                goto IFX_Handler;
        }
        if ((strlen(sVal) + 1) > MAX_URL_LEN) {

                fprintf(stderr, "Host Value len exceeded=%d\n", strlen(sVal));
                iRet = IFX_FAILURE;
                goto IFX_Handler;
        }
        strcpy(upload_diag->upload_url, sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_UPLOAD_DIAG_SECTION,
                                   IFX_UPLOAD_DIAG_SECTION "_"
                                   IFX_UPLOAD_DIAG_ETHERNETPRIORITY, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {

                goto IFX_Handler;
        }
        upload_diag->ethernet_priority = atoi(sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_UPLOAD_DIAG_SECTION,
                                   IFX_UPLOAD_DIAG_SECTION "_"
                                   IFX_UPLOAD_DIAG_TESTFILELENGTH, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {

                goto IFX_Handler;
        }
        upload_diag->test_file_len = (uint32)atoi(sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_UPLOAD_DIAG_SECTION,
                                   IFX_UPLOAD_DIAG_SECTION "_"
                                   IFX_UPLOAD_DIAG_ROMTIME, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
                goto IFX_Handler;
        }
        strcpy(upload_diag->ROMTime , sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_UPLOAD_DIAG_SECTION,
                                   IFX_UPLOAD_DIAG_SECTION "_"
                                   IFX_UPLOAD_DIAG_BOMTIME, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
                goto IFX_Handler;
        }
        strcpy(upload_diag->BOMTime , sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_UPLOAD_DIAG_SECTION,
                                   IFX_UPLOAD_DIAG_SECTION "_"
                                   IFX_UPLOAD_DIAG_DSCP, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
                goto IFX_Handler;
        }

        upload_diag->dscp = atoi(sVal);
        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_UPLOAD_DIAG_SECTION,
                                   IFX_UPLOAD_DIAG_SECTION "_"
                                   IFX_UPLOAD_DIAG_EOMTIME, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
                goto IFX_Handler;
        }
        strcpy(upload_diag->EOMTime , sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_UPLOAD_DIAG_SECTION,
                                   IFX_UPLOAD_DIAG_SECTION "_"
                                   IFX_UPLOAD_DIAG_TXTOTALBYTES, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
                goto IFX_Handler;
        }
        upload_diag->txTotalBytes = atoi(sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_UPLOAD_DIAG_SECTION,
                                   IFX_UPLOAD_DIAG_SECTION "_"
                                   IFX_UPLOAD_DIAG_TCPOPENRQSTTIME, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
                goto IFX_Handler;
        }
        strcpy(upload_diag->tcpOpenRqstTime,sVal);

        if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_UPLOAD_DIAG_SECTION,
                                   IFX_UPLOAD_DIAG_SECTION "_"
                                   IFX_UPLOAD_DIAG_TCPOPENRESPTIME, ulInFlag,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
                goto IFX_Handler;
        }
        strcpy(upload_diag->tcpOpenRespTime,sVal);

      IFX_Handler:
        return (iRet);
}

int32
ifx_cancel_uploads(char caCmdKey[32] , QUEUED_DOWNLOAD_STRUCT *xQD)
{
    char8 sVal[MAX_FILELINE_LEN] = {0} , sBuf[MAX_FILELINE_LEN] = {0}, sVal_mod[MAX_FILELINE_LEN] = {0};
    uint32 flags = IFX_F_GET_ANY;
    uint32 ulOutFlag;
    int32 iRtn = IFX_SUCCESS , iIdx = 0 , iCrntUpld = 0 , icount = 0 , icount_copy = 0 , min_FutureTime = 0 , nextIdx = 0 , iI = 0 , istatus = 0;
    
    if(xQD == NULL){
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : Null Pointer  !!\n\n",
                    __func__,__LINE__);
#endif
        return IFX_FAILURE;
    }

    memset(sVal, '\0', MAX_FILELINE_LEN);
    memset(xQD , '\0' , sizeof(QUEUED_DOWNLOAD_STRUCT));

    /* Get index of the pending upload */
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   IFX_QUEUED_UPLOAD_SECTION "_"
                                   IFX_QUEUED_UPLOAD_NEXT_QUEUED_IDX, flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }

    iIdx = atoi(sVal);

    if(iIdx == 0){
        /* If index is 0 ,then there are no pending uploads to be cancelled */
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
        iRtn = IFX_CT_CMDKEY_NOT_FOUND;
        goto IFX_Handler;
    }

    for(iI = 1 ; iI <= 3 ; iI++)
    {
        /* Get the command key for all the 3 entries in the queued_upload section */
        sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_UPLOAD_SECTION,iI,IFX_QUEUED_UPLOAD_COMMANDKEY);

        if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
        }
        if(strcmp(sVal , caCmdKey) == 0)
        {
            /* If command key for an entry matches the command key passed in the CancelTransfer RPC check whether that upload is complete or not */
            memset(sBuf , '\0' , MAX_FILELINE_LEN);
            sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_UPLOAD_SECTION,iI,IFX_QUEUED_UPLOAD_IS_COMPLETE);
            if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
            }
            if(atoi(sVal) == IFX_TRANSFER_ISCOMPLETE_INPROGRESS)
            {
                /* Unable to cancel if upload is already in progress */
                istatus = 9021;
#ifdef IFX_LOG_DEBUG
                IFX_DBG("\n\n In Function [%s %d] : Upload already done,cannot cancel transfer for iIdx:%d !!\n\n",
                    __func__,__LINE__,iI);
#endif
            }
            else if(atoi(sVal) == IFX_TRANSFER_ISCOMPLETE_DEFAULT)
            {
                /* If upload is not complete (not yet started) check its status */
                memset(sBuf , '\0' , MAX_FILELINE_LEN);
                sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_UPLOAD_SECTION,iI,IFX_QUEUED_UPLOAD_STATUS);
                if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                    IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                     __func__,__LINE__);
#endif
                    goto IFX_Handler;
                }
                if(atoi(sVal) == atoi(IFX_UPLOAD_STATUS_PENDING) || atoi(sVal) == atoi(IFX_UPLOAD_STATUS_NOTSTARTED))
                {
                    /* If this is the pending upload then set a flag to 1, 
                       else just set the section to default values */
                    if(atoi(sVal) == atoi(IFX_UPLOAD_STATUS_PENDING))
                        iCrntUpld = 1;

                    sprintf(sVal, "%s_%d_%s=\"%s\"\n",  IFX_QUEUED_UPLOAD_SECTION,iI,
                    IFX_QUEUED_UPLOAD_COMMANDKEY, "");

                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_UPLOAD_SECTION,iI,
                    IFX_QUEUED_UPLOAD_FILETYPE, "");

                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_UPLOAD_SECTION,iI,
                    IFX_QUEUED_UPLOAD_FILENAME, "");

                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_UPLOAD_SECTION,iI,
                    IFX_QUEUED_UPLOAD_USERNAME, "");

                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_UPLOAD_SECTION,iI,
                    IFX_QUEUED_UPLOAD_PASSWORD, "");

                    sprintf(sVal, "%s%s_%d_%s=\"%d\"\n", sVal, IFX_QUEUED_UPLOAD_SECTION,iI,
                    IFX_QUEUED_UPLOAD_FUTURETIME, 0);

                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_UPLOAD_SECTION,iI,
                    IFX_QUEUED_UPLOAD_STARTTIME, "0001-01-01T00:00:00Z");
                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_UPLOAD_SECTION,iI,
                    IFX_QUEUED_UPLOAD_ENDTIME, "0001-01-01T00:00:00Z");

                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_UPLOAD_SECTION,iI,
                    IFX_QUEUED_UPLOAD_STATUS, IFX_UPLOAD_STATUS_NONE);

                    sprintf(sVal, "%s%s_%d_%s=\"%d\"\n", sVal, IFX_QUEUED_UPLOAD_SECTION,iI,
                    IFX_QUEUED_UPLOAD_IS_COMPLETE, 0);

                    if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_QUEUED_UPLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sVal)) != IFX_SUCCESS)
                    {
#ifdef IFX_LOG_DEBUG
                       IFX_DBG("\n\n In Function [%s %d] : ifx_SetObjData Failed !!\n\n",
                       __func__,__LINE__);
#endif
                       goto IFX_Handler;
                    }
                    icount++;    // Increment for modification of each entry
                }
            }
        }
    }

    if(icount != 0)
    {
        /* If atleast one entry in the section has been modified (cancelled), set the count of the section to proper value */
        icount_copy = icount;

        if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   IFX_QUEUED_UPLOAD_SECTION "_"
                                   IFX_QUEUED_UPLOAD_COUNT , flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed  !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }

        icount = atoi(sVal) - icount;
        sprintf(sVal_mod, "%s_%s=\"%d\"\n", IFX_QUEUED_UPLOAD_SECTION,IFX_QUEUED_UPLOAD_COUNT,icount);

        if(iCrntUpld == 1)
        {
            /* If the section was reset for the pending upload then get the future times of all the entries 
               and determine if there are any other uploads to be scheduled and modify the section accordingly 
               to point to that entry as the next pending upload */
            for(iI = 1 ; iI <=3 ; iI++)
            {
                sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_UPLOAD_SECTION,iI,IFX_QUEUED_UPLOAD_FUTURETIME);
                if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_UPLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                    IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                    goto IFX_Handler;
                }
                if((strcmp(sVal,"0")!=0) && ((min_FutureTime == 0) || (min_FutureTime > atoi(sVal))))
                {
                    nextIdx = iI;
                    min_FutureTime = atoi(sVal);
                }
            }
            sprintf(sVal_mod, "%s%s_%s=\"%d\"\n", sVal_mod, IFX_QUEUED_UPLOAD_SECTION,IFX_QUEUED_UPLOAD_NEXT_QUEUED_IDX,nextIdx);
            if(nextIdx != 0)
            {
                sprintf(sVal_mod, "%s%s_%d_%s=\"%s\"\n", sVal_mod, IFX_QUEUED_UPLOAD_SECTION,nextIdx,IFX_QUEUED_UPLOAD_STATUS,IFX_UPLOAD_STATUS_PENDING);
            }

        }

        if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_QUEUED_UPLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sVal_mod)) != IFX_SUCCESS)
        {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                        __func__,__LINE__);
#endif
            goto IFX_Handler;
        }
    }
    else
    {
        /* No entry has been modified means matching command key was not found */
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : Matching CommandKey not Found !!\n\n",
                        __func__,__LINE__);
#endif
        iRtn = IFX_CT_CMDKEY_NOT_FOUND;
        goto IFX_Handler;
    }

    if((iCrntUpld == 1) && (nextIdx != 0))
    {
        /* If the pending upload entry has been reset AND there is another upload to be scheduled 
           get the values for that upload and populate the structure 
           set return value accordingly */
        if((iRtn = ifx_get_next_upload(xQD)) < IFX_SUCCESS){
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }
        iRtn = IFX_CT_SCHEDULE_NEXT;
        goto IFX_Handler;
    }
    else if((iCrntUpld == 1) && (nextIdx == 0))
    {
        /* If the pending upload entry has been reset AND there is no other upload to be scheduled
           set return value accordingly */
        iRtn = IFX_CT_ONLY;
        goto IFX_Handler;
    }
    if((iCrntUpld == 0) && (icount_copy != 0))
    {
        /* If the entry that was reset was not the pending upload return success */
        iRtn = IFX_SUCCESS;
    }
IFX_Handler:
    /* If the command key matched for the download already in progress send error accordingly */
    if(istatus == 9021)
        iRtn = 9021;

return iRtn;

}

int32
ifx_cancel_downloads(char caCmdKey[32] , QUEUED_DOWNLOAD_STRUCT *xQD)
{
    char8 sVal[MAX_FILELINE_LEN] = {0} , sBuf[MAX_FILELINE_LEN] = {0}, sVal_mod[MAX_FILELINE_LEN] = {0};
    uint32 flags = IFX_F_GET_ANY;
    uint32 ulOutFlag;
    int32 iRtn = IFX_SUCCESS , iIdx = 0 , iCrntDwnld = 0 , icount = 0 , icount_copy = 0 , min_FutureTime = 0 , nextIdx = 0 , iI = 0 , istatus = 0;
    
    if(xQD == NULL){
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : Null Pointer  !!\n\n",
                    __func__,__LINE__);
#endif
        return IFX_FAILURE;
    }

    memset(sVal, '\0', MAX_FILELINE_LEN);
    memset(xQD , '\0' , sizeof(QUEUED_DOWNLOAD_STRUCT));

    /* Get index of the pending download */        
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   IFX_QUEUED_DOWNLOAD_SECTION "_"
                                   IFX_QUEUED_DOWNLOAD_NEXT_QUEUED_IDX, flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }

    iIdx = atoi(sVal);

    if(iIdx == 0){
        /* If index is 0 ,then there are no pending downloads to be cancelled */

#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
        iRtn = IFX_CT_CMDKEY_NOT_FOUND;
        goto IFX_Handler;
    }

    for(iI = 1 ; iI <= 3 ; iI++)
    {   
        /* Get the command key for all the 3 entries in the queued_download section */
        sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_DOWNLOAD_SECTION,iI,IFX_QUEUED_DOWNLOAD_COMMANDKEY);
        if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
        }
        if(strcmp(sVal , caCmdKey) == 0)
        {
            /* If command key for an entry matches the command key passed in the CancelTransfer RPC check whether that download is complete or not */
            memset(sBuf , '\0' , MAX_FILELINE_LEN);
            sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_DOWNLOAD_SECTION,iI,IFX_QUEUED_DOWNLOAD_IS_COMPLETE);
            if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
            }
            
            if(atoi(sVal) == IFX_TRANSFER_ISCOMPLETE_INPROGRESS)
            {
                /* Unable to cancel if download is already in progress */
                istatus = 9021;
#ifdef IFX_LOG_DEBUG
                IFX_DBG("\n\n In Function [%s %d] : Download already done,cannot cancel transfer for iIdx:%d !!\n\n",
                    __func__,__LINE__,iI);
#endif
            }
            else if(atoi(sVal) == IFX_TRANSFER_ISCOMPLETE_DEFAULT)
            {
                /* If download is not complete (not yet started) check its status */
                memset(sBuf , '\0' , MAX_FILELINE_LEN);
                sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_DOWNLOAD_SECTION,iI,IFX_QUEUED_DOWNLOAD_STATUS);
                if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                    IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                     __func__,__LINE__);
#endif
                    goto IFX_Handler;
                }
                
                if(atoi(sVal) == atoi(IFX_DOWNLOAD_STATUS_PENDING) || atoi(sVal) == atoi(IFX_DOWNLOAD_STATUS_NOTSTARTED))
                {
                    /* If this is the pending download then set a flag to 1, 
                       else just set the section to default values */
                    if(atoi(sVal) == atoi(IFX_DOWNLOAD_STATUS_PENDING))
                        iCrntDwnld = 1;

                    sprintf(sVal, "%s_%d_%s=\"%s\"\n",  IFX_QUEUED_DOWNLOAD_SECTION,iI,
                    IFX_QUEUED_DOWNLOAD_COMMANDKEY, "");

                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iI,
                    IFX_QUEUED_DOWNLOAD_FILETYPE, "");

                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iI,
                    IFX_QUEUED_DOWNLOAD_FILENAME, "");

                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iI,
                    IFX_QUEUED_DOWNLOAD_USERNAME, "");

                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iI,
                    IFX_QUEUED_DOWNLOAD_PASSWORD, "");

                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iI,
                    IFX_QUEUED_DOWNLOAD_FILESIZE, "0");

                    sprintf(sVal, "%s%s_%d_%s=\"%d\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iI,
                    IFX_QUEUED_DOWNLOAD_FUTURETIME, 0);

                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iI,
                    IFX_QUEUED_DOWNLOAD_STARTTIME, "0001-01-01T00:00:00Z");

                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iI,
                    IFX_QUEUED_DOWNLOAD_ENDTIME, "0001-01-01T00:00:00Z");

                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iI,
                    IFX_QUEUED_DOWNLOAD_STATUS, IFX_DOWNLOAD_STATUS_NONE);

                    sprintf(sVal, "%s%s_%d_%s=\"%d\"\n", sVal, IFX_QUEUED_DOWNLOAD_SECTION,iI,
                    IFX_QUEUED_DOWNLOAD_IS_COMPLETE, 0);

                   if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_QUEUED_DOWNLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sVal)) != IFX_SUCCESS)
                   {
#ifdef IFX_LOG_DEBUG
                       IFX_DBG("\n\n In Function [%s %d] : ifx_SetObjData Failed !!\n\n",
                       __func__,__LINE__);
#endif
                       goto IFX_Handler;
                   }
                   icount++;   // Increment for modification of each entry
               } 
           }
        }
    }
    
    if(icount != 0)
    {   /* If atleast one entry in the section has been modified (cancelled), set the count of the section to proper value */
        icount_copy = icount;

        if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   IFX_QUEUED_DOWNLOAD_SECTION "_"
                                   IFX_QUEUED_DOWNLOAD_COUNT , flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed  !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }

        icount = atoi(sVal) - icount;
        sprintf(sVal_mod, "%s_%s=\"%d\"\n", IFX_QUEUED_DOWNLOAD_SECTION,IFX_QUEUED_DOWNLOAD_COUNT,icount);

        if(iCrntDwnld == 1)
        {
            /* If the section was reset for the pending download then get the future times of all the entries 
               and determine if there are any other downloads to be scheduled and modify the section accordingly 
               to point to that entry as the next pending download */
            for(iI = 1 ; iI <=3 ; iI++)
            {
                sprintf(sBuf,"%s_%d_%s",IFX_QUEUED_DOWNLOAD_SECTION,iI,IFX_QUEUED_DOWNLOAD_FUTURETIME);
                if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_QUEUED_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                    IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                    goto IFX_Handler;
                }
                if((strcmp(sVal,"0")!=0) && ((min_FutureTime == 0) || (min_FutureTime > atoi(sVal))))
                {
                    nextIdx = iI;
                    min_FutureTime = atoi(sVal);
                }
            }
            sprintf(sVal_mod, "%s%s_%s=\"%d\"\n", sVal_mod, IFX_QUEUED_DOWNLOAD_SECTION,IFX_QUEUED_DOWNLOAD_NEXT_QUEUED_IDX,nextIdx);
            if(nextIdx != 0)
            {
                sprintf(sVal_mod, "%s%s_%d_%s=\"%s\"\n", sVal_mod, IFX_QUEUED_DOWNLOAD_SECTION,nextIdx,IFX_QUEUED_DOWNLOAD_STATUS,IFX_DOWNLOAD_STATUS_PENDING);
            }
 
        }
        
        if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_QUEUED_DOWNLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sVal_mod)) != IFX_SUCCESS)
        {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                        __func__,__LINE__);
#endif
            goto IFX_Handler;
        }
    }
    else
    {  /* No entry has been modified means matching command key was not found */
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : Matching CommandKey not Found !!\n\n",
                        __func__,__LINE__);
#endif
        iRtn = IFX_CT_CMDKEY_NOT_FOUND;
        goto IFX_Handler;
    }

    if((iCrntDwnld == 1) && (nextIdx != 0))
    {   
        /* If the pending download entry has been reset AND there is another download to be scheduled 
           get the values for that download and populate the structure 
           set return value accordingly */
        if((iRtn = ifx_get_next_download(xQD)) < IFX_SUCCESS){
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }
        iRtn = IFX_CT_SCHEDULE_NEXT;
        goto IFX_Handler;
    }
    else if((iCrntDwnld == 1) && (nextIdx == 0))
    {
        /* If the pending download entry has been reset AND there is no other download to be scheduled
           set return value accordingly */
        iRtn = IFX_CT_ONLY;
        goto IFX_Handler;
    }
    if((iCrntDwnld == 0) && (icount_copy != 0))
    {
        /* If the entry that was reset was not the pending download return success */
        iRtn = IFX_SUCCESS;
    }
IFX_Handler:
    /* If the command key matched for the download already in progress send error accordingly */
    if(istatus == 9021)
        iRtn = 9021;

return iRtn;
}
int32 ifx_get_configfile(char8 *configFile)
{

    FILE *fp = NULL;
    int32 ret = IFX_SUCCESS;

    if(configFile == NULL)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Invalid out pointer \n", __func__, __LINE__);
        #endif 
        ret = IFX_FAILURE;
        goto errorHandler;
    }
    fp = fopen("/tmp/rc.conf.gz" , "r");

    if(fp == NULL){
#ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Cannot open encrypted rc.conf.gz \n", __func__, __LINE__);
#endif
        ret = IFX_FAILURE;
        goto errorHandler;
    }
    fgets(configFile , 32768 , fp);

    fclose(fp);

errorHandler:
return ret;
}

int32 ifx_set_configfile(char8 *configFile)
{

    FILE * fp = NULL;
    int32 ret = IFX_SUCCESS;

    fp = fopen("/tmp/sysconf.gz" , "w");

    if(fp == NULL){
#ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Cannot open sysconf.gz \n", __func__, __LINE__);
#endif
        ret = IFX_FAILURE;
        goto errorHandler;
    }

    fprintf(fp , "%s" , configFile);
    fclose(fp);


errorHandler:
return ret;
}

#if 1 /* VendorConfigFile Object */
char *vend_conf_file_param[] = 
  { "cpeId", "pcpeId", "name", "version", "date", "desc" };
#define VEND_CONF_FILE_PARAM_CNT        6

int32 ifx_set_vend_conf_file(int32 operation, VEND_CONF_FILE *conf_file, uint32 flags)
{
    int32 count = 0, passed_index = -1, ret = IFX_SUCCESS;
    int32 changed_count = 0;
    char8 conf_buf[MAX_DATA_LEN];
    IFX_NAME_VALUE_PAIR array_fvp[VEND_CONF_FILE_PARAM_CNT + 1],
                        *array_changed_fvp = NULL;

    NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));
    memset(array_fvp, 0, sizeof(array_fvp));

    if (operation == IFX_OP_DEL)
        flags |= IFX_F_DELETE;
    else if (operation == IFX_OP_ADD) {
        if ((IFX_MODIFY_F_NOT_SET(flags)))
            flags |= IFX_F_INT_ADD;
    } else
        flags |= IFX_F_MODIFY;

    if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
        IFX_VALIDATE_PTR(conf_file);
    }
    IFX_DBG("[%s:%d] Validation done.\n", __FUNCTION__, __LINE__);

    sprintf(conf_file->iid.cpeId.secName, "%s", IFX_VENDOR_CONF_FILE_SECTION);

    if (IFX_ADD_F_SET(flags)) {
        if (ifx_get_IID(&conf_file->iid, "uname") != IFX_SUCCESS) {
            IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }
    }
    IFX_DBG("[%s:%d] Got IID.\n", __FUNCTION__, __LINE__);
    count = 0;
    if (IFX_DELETE_F_NOT_SET(flags)) {
        ifx_fill_ArrayFvp_FName(array_fvp, 0,
                           VEND_CONF_FILE_PARAM_CNT, vend_conf_file_param);
        ifx_fill_ArrayFvp_intValues(array_fvp, 0, 2,
                           (int32 *) &conf_file->iid.cpeId.Id,
                           (int32 *) &conf_file->iid.pcpeId.Id);
        ifx_fill_ArrayFvp_strValues(array_fvp, 2, 4, conf_file->name,
                                    &conf_file->version,
                                    &conf_file->date,
                                    &conf_file->desc);
        passed_index = -1;
    }
    IFX_DBG("[%s:%d] PV array is ready.\n", __FUNCTION__, __LINE__);

    count = VEND_CONF_FILE_PARAM_CNT;
    if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
        IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, conf_file->iid.cpeId,
                                  passed_index);
    }
    IFX_DBG("[%s:%d] Got index from cpeid.\n", __FUNCTION__, __LINE__);

    if (ifx_get_conf_index_and_nv_pairs(&conf_file->iid, passed_index,
        IFX_VENDOR_CONF_FILE_SECTION, count, array_fvp, flags) != IFX_SUCCESS) {
        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }
    IFX_DBG("[%s:%d] Got config index and all.\n", __FUNCTION__, __LINE__);

    if (IFX_ADD_F_NOT_SET(flags)) {
        CHECK_ACL_RET(conf_file->iid, count, array_fvp,
                              changed_count, array_changed_fvp, flags,
                              IFX_Handler)
    }
    IFX_DBG("[%s:%d] ACL check done.\n", __FUNCTION__, __LINE__);


    form_cfgdb_buf(conf_buf, count, array_fvp);
    ret = ifx_SetObjData(FILE_RC_CONF, IFX_VENDOR_CONF_FILE_SECTION,
                         flags, 1, conf_buf);
    if (ret != IFX_SUCCESS) {
        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
        goto IFX_Handler;
    }
    IFX_DBG("[%s:%d] Written into rc.conf.\n", __FUNCTION__, __LINE__);


    if (IFX_MODIFY_F_NOT_SET(flags))
        ifx_CompactCfgSection(FILE_RC_CONF, IFX_VENDOR_CONF_FILE_SECTION, flags);

    if (IFX_MODIFY_F_SET(flags)) {
        CHECK_N_SEND_NOTIFICATION(conf_file->iid, changed_count,
                                          array_changed_fvp, flags, IFX_Handler)
        IFX_DBG("[%s:%d] Notification sent.\n", __FUNCTION__, __LINE__);
    } else if (IFX_INT_ADD_F_SET(flags)) {
        UPDATE_ID_MAP_N_ATTRIBUTES(&conf_file->iid, count, array_fvp,
                                           flags, IFX_Handler)
        IFX_DBG("[%s:%d]Updated map section.\n", __FUNCTION__, __LINE__);
        CHECK_N_SEND_NOTIFICATION(conf_file->iid, count,
                                              array_fvp, flags, IFX_Handler)
        IFX_DBG("[%s:%d] Notification sent.\n", __FUNCTION__, __LINE__);
        ifx_increment_next_cpeId(FILE_RC_CONF, IFX_VENDOR_CONF_FILE_SECTION);
    } else if (IFX_DELETE_F_SET(flags)) {
        CHECK_N_SEND_NOTIFICATION(conf_file->iid, count, array_fvp,
                                          flags, IFX_Handler)
        IFX_DBG("[%s:%d] Notification sent.\n", __FUNCTION__, __LINE__);
        UPDATE_ID_MAP_N_ATTRIBUTES(&conf_file->iid, count,
                                               array_fvp, flags, IFX_Handler)
        IFX_DBG("[%s:%d]Updated map section.\n", __FUNCTION__, __LINE__);
    }

    ret = ifx_config_write(FILE_RC_CONF, flags);
    if (ret != IFX_SUCCESS) {
        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
        goto IFX_Handler;
    }
    IFX_DBG("[%s:%d] Written in flash.\n", __FUNCTION__, __LINE__);
IFX_Handler:
    IFX_MEM_FREE(array_changed_fvp);
    if (ret != IFX_SUCCESS) {
        IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
        return ret;
    } else
        return IFX_SUCCESS;
}


int32 ifx_get_vend_conf_file(VEND_CONF_FILE *conf_file, uint32 flags)
{
    int32 ret = IFX_SUCCESS;
    int32 passed_index = -1, count = 0; 
    char8 sBuf[MAX_FILELINE_LEN], *sValue = NULL;
    IFX_NAME_VALUE_PAIR array_fvp[VEND_CONF_FILE_PARAM_CNT + 1];

    sprintf(conf_file->iid.cpeId.secName, "%s", IFX_VENDOR_CONF_FILE_SECTION);
    
    IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, conf_file->iid.cpeId, passed_index);

    sprintf(sBuf, "%s_%d_", IFX_VENDOR_CONF_FILE_SECTION, passed_index);

    if ((ret = ifx_GetCfgObject(FILE_RC_CONF, IFX_VENDOR_CONF_FILE_SECTION,
                          sBuf, flags, &sValue)) != IFX_SUCCESS) {
        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }
    
    memset(array_fvp, 0x00, sizeof(array_fvp));

    form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);

    ifx_fill_intValues_ArrayFvp(array_fvp, 0, 2,
                            (int32 *) &conf_file->iid.cpeId.Id,
                            (int32 *) &conf_file->iid.pcpeId.Id);

    ifx_fill_strValues_ArrayFvp(array_fvp, 2, 4, conf_file->name,
                                &conf_file->version,
                                &conf_file->date,
                                &conf_file->desc);

IFX_Handler:
    IFX_MEM_FREE(sValue);
    if (ret != IFX_SUCCESS) {
        IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
        return ret;
    } else
        return IFX_SUCCESS;
}
#endif
int32 ifx_set_schedule_download(char download_params[17][256] ,int32 xTime)
{
    char8 sVal[MAX_DATA_LEN] , sBuf[MAX_DATA_LEN] ;
    uint32 flags = IFX_F_GET_ANY;
    uint32 ulOutFlag;
    int32 iI , iRtn = IFX_SUCCESS , iIdx = 0 ,  nextCpeId = 0 , prevIdx = 0 , nextIdx = 0;
    int32 min_FutureTime = 0 , iCount = 0 ;

    // Saving index of the next pending download
    sprintf(sBuf,"%s_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,IFX_SCHEDULE_DOWNLOAD_NEXT_QUEUED_IDX);

    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf
                                   , flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
    }

    prevIdx = atoi(sVal);

    // Get the 3 status and overwrite the available index

    for(iI = 1 ; iI <=3 ; iI++)
    {
       sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iI,IFX_SCHEDULE_DOWNLOAD_STATUS);
       if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf
                                   , flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }
        if(strcmp(IFX_DOWNLOAD_STATUS_NONE,sVal) == 0)
        {

            // If the value is uninitiated overwrite it
            iIdx = iI;
            goto overwrite;
        }
        else if(((strcmp(sVal,IFX_DOWNLOAD_STATUS_PENDING) != 0) && (strcmp(sVal,IFX_DOWNLOAD_STATUS_NOTSTARTED) != 0)))
        {
            // If the status is not pending and not started save the index to overwrite
            if(iI != prevIdx)
            {
                iIdx = iI;
                goto overwrite;
            }
        }
    }


overwrite:
    // Overwriting the available section   
    sprintf(sBuf,"%s_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,"nextCpeId");

    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,"next_cpeid" ,
                                   sBuf
                                   , flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
        goto IFX_Handler;
    }

    nextCpeId = atoi(sVal);
    sprintf(sVal, "%s_%d_cpeId=\"%d\"\n", IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                nextCpeId);
    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_COMMANDKEY, download_params[0]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_FILETYPE, download_params[1]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_URL, download_params[2]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_USERNAME, download_params[3]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_PASSWORD, download_params[4]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_FILESIZE, download_params[5]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_FILENAME, download_params[6]);

    sprintf(sVal, "%s%s_%d_%s=\"%d\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_FUTURETIME, xTime);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_STARTTIME, "0001-01-01T00:00:00Z");

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_ENDTIME, "0001-01-01T00:00:00Z");

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_STATUS, IFX_DOWNLOAD_STATUS_NOTSTARTED);

    sprintf(sVal, "%s%s_%d_%s=\"%d\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_IS_COMPLETE, 0);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_WINDOW1_START, download_params[7]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_WINDOW1_END, download_params[8]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_WINDOW1_MODE, download_params[9]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_WINDOW1_USERMSG, download_params[10]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_WINDOW1_MAXRETRIES, download_params[11]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_WINDOW2_START, download_params[12]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_WINDOW2_END, download_params[13]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_WINDOW2_MODE, download_params[14]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_WINDOW2_USERMSG, download_params[15]);

    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_WINDOW2_MAXRETRIES, download_params[16]);
    if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_SCHEDULE_DOWNLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sVal)) != IFX_SUCCESS)
    {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_SetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
        goto IFX_Handler;
    }

    ifx_increment_next_cpeId(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION);

    // Checking for the least future time and modifying the status and next queue index accordingly
    for(iI = 1 ; iI <= 3 ; iI++)
    {
        sprintf(sBuf , "%s_%d_%s" , IFX_SCHEDULE_DOWNLOAD_SECTION , iI , IFX_SCHEDULE_DOWNLOAD_FUTURETIME);
        if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }
        if((strcmp(sVal,"0")!=0) && ((min_FutureTime == 0) || (min_FutureTime > atoi(sVal))))
        {
            nextIdx = iI;
            min_FutureTime = atoi(sVal);
        }
    }
    /* 
       Get the no of pending downloads and increment it, 
       If scheduled download has changed, set the status of the previously scheduled download and the new one
    */
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   IFX_SCHEDULE_DOWNLOAD_SECTION "_"
                                   IFX_SCHEDULE_DOWNLOAD_COUNT, flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
    }
    iCount = atoi(sVal);
    iCount++;
    sprintf(sVal, "%s_%s=\"%d\"\n", IFX_SCHEDULE_DOWNLOAD_SECTION,IFX_SCHEDULE_DOWNLOAD_COUNT,iCount);

    if(prevIdx != nextIdx)
    {
        sprintf(sVal , "%s%s_%s=\"%d\"\n" , sVal, IFX_SCHEDULE_DOWNLOAD_SECTION , IFX_SCHEDULE_DOWNLOAD_NEXT_QUEUED_IDX, nextIdx);
        if(prevIdx != 0)
            sprintf(sVal , "%s%s_%d_%s=\"%s\"\n" , sVal,IFX_SCHEDULE_DOWNLOAD_SECTION , prevIdx , IFX_SCHEDULE_DOWNLOAD_STATUS,IFX_DOWNLOAD_STATUS_NOTSTARTED);
        sprintf(sVal , "%s%s_%d_%s=\"%s\"\n" , sVal,IFX_SCHEDULE_DOWNLOAD_SECTION , nextIdx , IFX_SCHEDULE_DOWNLOAD_STATUS,IFX_DOWNLOAD_STATUS_PENDING);
    }

    if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_SCHEDULE_DOWNLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sVal)) != IFX_SUCCESS)
    {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_SetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
        goto IFX_Handler;
    }

    if (ifx_flash_write() <= 0) {
        iRtn =  IFX_FAILURE;
        goto IFX_Handler;
    }

    return min_FutureTime;
IFX_Handler:
return iRtn;

}
int32 ifx_get_next_schedule_download(SCHEDULE_DOWNLOAD_STRUCT *xSD)
{
    char8 sVal[MAX_FILELINE_LEN] , sBuf[MAX_FILELINE_LEN];
    uint32 flags = IFX_F_GET_ANY;
    uint32 ulOutFlag;
    int32 iRtn = IFX_SUCCESS , iIdx = 0;

    if(xSD == NULL){
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : Null Pointer  !!\n\n",
                    __func__,__LINE__);
#endif
        return IFX_FAILURE;
    }

    memset(sVal, '\0', MAX_FILELINE_LEN);
    memset(xSD , '\0' , sizeof(QUEUED_DOWNLOAD_STRUCT));
    strcpy(xSD->FutureTime," ");

    // Get the number of queued ScheduleDownloads
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   IFX_SCHEDULE_DOWNLOAD_SECTION "_"
                                   IFX_SCHEDULE_DOWNLOAD_COUNT , flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed  !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }

    if(atoi(sVal) == 0){
        // If no pending downloads, return success
        iRtn = IFX_SUCCESS;
        goto IFX_Handler;
    }

    // Get index of the next download and populate the structure using it.

    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   IFX_SCHEDULE_DOWNLOAD_SECTION "_"
                                   IFX_SCHEDULE_DOWNLOAD_NEXT_QUEUED_IDX, flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    iIdx = atoi(sVal);
    sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,IFX_SCHEDULE_DOWNLOAD_COMMANDKEY);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->CommandKey , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,IFX_SCHEDULE_DOWNLOAD_FILETYPE);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->FileType , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,IFX_SCHEDULE_DOWNLOAD_FILENAME);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->FileName , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,IFX_SCHEDULE_DOWNLOAD_USERNAME);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
                                            
    }
    strcpy(xSD->Username , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,IFX_SCHEDULE_DOWNLOAD_PASSWORD);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->Password , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,IFX_SCHEDULE_DOWNLOAD_FILESIZE);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->FileSize , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,IFX_SCHEDULE_DOWNLOAD_FUTURETIME);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->FutureTime , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,IFX_SCHEDULE_DOWNLOAD_STARTTIME);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->StartTime , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,IFX_SCHEDULE_DOWNLOAD_ENDTIME);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->EndTime , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,IFX_SCHEDULE_DOWNLOAD_STATUS);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->Status , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,IFX_SCHEDULE_DOWNLOAD_URL);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->URL , sVal);

    // Window 1
    sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,IFX_SCHEDULE_DOWNLOAD_WINDOW1_START);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->Window1_Start , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,IFX_SCHEDULE_DOWNLOAD_WINDOW1_END);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->Window1_End , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,IFX_SCHEDULE_DOWNLOAD_WINDOW1_MODE);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->Window1_Mode , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,IFX_SCHEDULE_DOWNLOAD_WINDOW1_USERMSG);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->Window1_UserMsg , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,IFX_SCHEDULE_DOWNLOAD_WINDOW1_MAXRETRIES);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->Window1_MaxRetries , sVal);

    //Window 2

        sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,IFX_SCHEDULE_DOWNLOAD_WINDOW2_START);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->Window2_Start , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,IFX_SCHEDULE_DOWNLOAD_WINDOW2_END);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->Window2_End , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,IFX_SCHEDULE_DOWNLOAD_WINDOW2_MODE);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->Window2_Mode , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,IFX_SCHEDULE_DOWNLOAD_WINDOW2_USERMSG);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->Window2_UserMsg , sVal);

    sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,IFX_SCHEDULE_DOWNLOAD_WINDOW2_MAXRETRIES);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->Window2_MaxRetries , sVal);


    iRtn = iIdx;

IFX_Handler:
    return iRtn;

}
int ifx_validate_schedule_download()
{
    char8 sVal[MAX_FILELINE_LEN] ;
    uint32 flags = IFX_F_GET_ANY;
    uint32 ulOutFlag;
    int32 iRtn = IFX_SUCCESS;

    memset(sVal, '\0', MAX_FILELINE_LEN);
    /* Get the count in the ScheduleDownload section and return ResourceExceeded if 3 
       ScheduleDownloads are already queued */
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   IFX_SCHEDULE_DOWNLOAD_SECTION "_"
                                   IFX_SCHEDULE_DOWNLOAD_COUNT, flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    if(atoi(sVal) == IFX_MAX_QUEUED_ENTRY)
        return 9004;

IFX_Handler:
    return iRtn;
}
int32 ifx_update_schedule_download(int status , char * StartTime , char * EndTime , int iIsComplete ,int iStatusFlag )
{
    char8 sVal[MAX_FILELINE_LEN] , sBuf[MAX_FILELINE_LEN];
    uint32 flags = IFX_F_GET_ANY;
    uint32 ulOutFlag;
    int32 iI , iRtn = IFX_SUCCESS , iIdx = 0 , iCount = 0, min_FutureTime = 0 , nextIdx = 0 , iFutureTime = 0;
    SCHEDULE_DOWNLOAD_STRUCT xSD;
    memset(sVal, '\0', MAX_FILELINE_LEN);


    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   IFX_SCHEDULE_DOWNLOAD_SECTION "_"
                                   IFX_SCHEDULE_DOWNLOAD_NEXT_QUEUED_IDX, flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
        goto IFX_Handler;
    }

    iIdx = atoi(sVal);
    if(iIdx == 0)
    {
        iRtn = IFX_SUCCESS;
        goto IFX_Handler;
    }
    // Update the status , start time and end time of the present download
    if(iStatusFlag != FALSE)
    {
        sprintf(sBuf , "%s_%d_%s=\"%d\"\n" , IFX_SCHEDULE_DOWNLOAD_SECTION , iIdx , IFX_SCHEDULE_DOWNLOAD_STATUS , status);
        sprintf(sBuf , "%s%s_%d_%s=\"%s\"\n" , sBuf,IFX_SCHEDULE_DOWNLOAD_SECTION , iIdx , IFX_SCHEDULE_DOWNLOAD_STARTTIME , StartTime);
        sprintf(sBuf , "%s%s_%d_%s=\"%s\"\n" , sBuf,IFX_SCHEDULE_DOWNLOAD_SECTION , iIdx , IFX_SCHEDULE_DOWNLOAD_ENDTIME , EndTime);
        sprintf(sBuf , "%s%s_%d_%s=\"%d\"\n" , sBuf,IFX_SCHEDULE_DOWNLOAD_SECTION , iIdx , IFX_SCHEDULE_DOWNLOAD_IS_COMPLETE , iIsComplete);
        if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_SCHEDULE_DOWNLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sBuf)) != IFX_SUCCESS)
        {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_SetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }
    }
    if(iStatusFlag == 2)
    {
        // Get the Entries for the pending download
// NEW
        if ((iRtn = ifx_get_next_schedule_download(&xSD)) < IFX_SUCCESS)
        {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }
        else
            iRtn = IFX_SUCCESS;
#if 0
        if(atoi(xSD.Status) == 9010 && atoi(xSD.Window1_Start) != -1 && atoi(xSD.Window2_Start) == 0)
        {
            /* Window 1 failed and there is no window 2 
               Nothing to be done
               skip to end and return
            */
        }
#endif
        if(atoi(xSD.Status) == 9010 && atoi(xSD.Window1_Start) != -1 && atoi(xSD.Window2_Start) != 0)
        {
            /* Wndow 1 failed and there is window 2
               Set Window 1 Start to -1
               Calulate the future time based on the Window2 Start , status to 3 and update section
            */
            memset(sBuf , '\0' , sizeof(sBuf));
            iFutureTime = (atoi(xSD.FutureTime) - atoi(xSD.Window1_Start)) + atoi(xSD.Window2_Start);
            sprintf(sBuf , "%s_%d_%s=\"%d\"\n" , IFX_SCHEDULE_DOWNLOAD_SECTION , iIdx , IFX_SCHEDULE_DOWNLOAD_FUTURETIME,iFutureTime);
            sprintf(sBuf , "%s%s_%d_%s=\"-1\"\n" , sBuf,IFX_SCHEDULE_DOWNLOAD_SECTION , iIdx , IFX_SCHEDULE_DOWNLOAD_WINDOW1_START);
            sprintf(sBuf , "%s%s_%d_%s=\"3\"\n" , sBuf,IFX_SCHEDULE_DOWNLOAD_SECTION , iIdx , IFX_SCHEDULE_DOWNLOAD_STATUS);
            sprintf(sBuf , "%s%s_%d_%s=\"0\"\n" , sBuf,IFX_SCHEDULE_DOWNLOAD_SECTION , iIdx , IFX_SCHEDULE_DOWNLOAD_IS_COMPLETE);
            sprintf(sBuf , "%s%s_%d_%s=\"%s\"\n" , sBuf,IFX_SCHEDULE_DOWNLOAD_SECTION , iIdx , IFX_SCHEDULE_DOWNLOAD_STARTTIME , "0001-01-01T00:00:00Z");
            sprintf(sBuf , "%s%s_%d_%s=\"%s\"\n" , sBuf,IFX_SCHEDULE_DOWNLOAD_SECTION , iIdx , IFX_SCHEDULE_DOWNLOAD_ENDTIME , "0001-01-01T00:00:00Z");
            if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_SCHEDULE_DOWNLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sBuf)) != IFX_SUCCESS)
            {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("\n\n In Function [%s %d] : ifx_SetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
            }

            // Checking for the least future time and modifying the status and next queue index accordingly
            for(iI = 1 ; iI <= 3 ; iI++)
            {
                sprintf(sBuf , "%s_%d_%s" , IFX_SCHEDULE_DOWNLOAD_SECTION , iI , IFX_SCHEDULE_DOWNLOAD_FUTURETIME);
                if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                    IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                    goto IFX_Handler;
                }
                if((strcmp(sVal,"0")!=0) && ((min_FutureTime == 0) || (min_FutureTime > atoi(sVal))))
                {
                    nextIdx = iI;
                    min_FutureTime = atoi(sVal);
                }
            }
            memset(sVal , '\0' , sizeof(sVal));
            sprintf(sVal, "%s_%s=\"%d\"\n",  IFX_SCHEDULE_DOWNLOAD_SECTION,IFX_SCHEDULE_DOWNLOAD_NEXT_QUEUED_IDX,nextIdx);
            sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,nextIdx,IFX_SCHEDULE_DOWNLOAD_STATUS,IFX_DOWNLOAD_STATUS_PENDING);
            if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_SCHEDULE_DOWNLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sVal)) != IFX_SUCCESS)
            {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("\n\n In Function [%s %d] : ifx_SetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
            }
            iRtn = 2;
        }
#if 0
        else if(atoi(xSD.Status) == 0 && atoi(xSD.Window1_Start) != -1)
        {
            /* Window 1 has passed
               Do nothing
            */
        }
        else if(atoi(xSD.Window1_Start) == -1)
        {
            /* Window 2 is over can be fail or pass
               Do nothing
            */
        }
#endif
    }
// END NEW
    // if iStatus flag is FALSE update the section to point to the next download
    if(iStatusFlag == FALSE)
    {
        // Setting future time of the download just completed to blank
        sprintf(sBuf , "%s_%d_%s=\"0\"\n" , IFX_SCHEDULE_DOWNLOAD_SECTION , iIdx , IFX_SCHEDULE_DOWNLOAD_FUTURETIME);
        sprintf(sBuf, "%s%s_%d_%s=\"%d\"\n", sBuf, IFX_SCHEDULE_DOWNLOAD_SECTION,iIdx,
                IFX_SCHEDULE_DOWNLOAD_IS_COMPLETE, 1);

        if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_SCHEDULE_DOWNLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sBuf)) != IFX_SUCCESS)
        {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_SetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }



        if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   IFX_SCHEDULE_DOWNLOAD_SECTION "_"
                                   IFX_SCHEDULE_DOWNLOAD_COUNT, flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }
        iCount = atoi(sVal);
        iCount--;

        if(iCount != 0)
        {
            // Checking for the least future time and modifying the status and next queue index accordingly
            for(iI = 1 ; iI <= 3 ; iI++)
            {
                sprintf(sBuf , "%s_%d_%s" , IFX_SCHEDULE_DOWNLOAD_SECTION , iI , IFX_SCHEDULE_DOWNLOAD_FUTURETIME);
                if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                    IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                    goto IFX_Handler;
                }
                if((strcmp(sVal,"0")!=0) && ((min_FutureTime == 0) || (min_FutureTime > atoi(sVal))))
                {
                    nextIdx = iI;
                    min_FutureTime = atoi(sVal);
                }
            }

        }

        sprintf(sVal, "%s_%s=\"%d\"\n", IFX_SCHEDULE_DOWNLOAD_SECTION,IFX_SCHEDULE_DOWNLOAD_COUNT,iCount);
        if(iCount == 0)
            nextIdx = 0;
        sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,IFX_SCHEDULE_DOWNLOAD_NEXT_QUEUED_IDX,nextIdx);
        if(nextIdx != 0)
            sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,nextIdx,IFX_SCHEDULE_DOWNLOAD_STATUS,IFX_DOWNLOAD_STATUS_PENDING);
        if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_SCHEDULE_DOWNLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sVal)) != IFX_SUCCESS)
        {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }
    }
IFX_Handler:
    if (ifx_flash_write() <= 0) {
        return IFX_FAILURE;
    }
    return iRtn;
}

int32
ifx_cancel_schedule_downloads(char caCmdKey[32] , SCHEDULE_DOWNLOAD_STRUCT *xSD)
{
    char8 sVal[MAX_FILELINE_LEN] = {0} , sBuf[MAX_FILELINE_LEN] = {0}, sVal_mod[MAX_FILELINE_LEN] = {0};
    uint32 flags = IFX_F_GET_ANY;
    uint32 ulOutFlag;
    int32 iRtn = IFX_SUCCESS , iIdx = 0 , iCrntDwnld = 0 , icount = 0 , icount_copy = 0 , min_FutureTime = 0 , nextIdx = 0 , iI = 0 , istatus = 0;

    if(xSD == NULL){
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : Null Pointer  !!\n\n",
                    __func__,__LINE__);
#endif
        return IFX_FAILURE;
    }

    memset(sVal, '\0', MAX_FILELINE_LEN);
    memset(xSD , '\0' , sizeof(SCHEDULE_DOWNLOAD_STRUCT));

    /* Get index of the pending download */
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   IFX_SCHEDULE_DOWNLOAD_SECTION "_"
                                   IFX_SCHEDULE_DOWNLOAD_NEXT_QUEUED_IDX, flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }

    iIdx = atoi(sVal);

    if(iIdx == 0){
        /* If index is 0 ,then there are no pending downloads to be cancelled */

#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
        iRtn = IFX_CT_CMDKEY_NOT_FOUND;
        goto IFX_Handler;
    }

    for(iI = 1 ; iI <= 3 ; iI++)
    {
        /* Get the command key for all the 3 entries in the queued_download section */
        sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iI,IFX_SCHEDULE_DOWNLOAD_COMMANDKEY);
        if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
        }
        if(strcmp(sVal , caCmdKey) == 0)
        {
            /* If command key for an entry matches the command key passed in the CancelTransfer RPC check whether that download is complete or not */
            memset(sBuf , '\0' , MAX_FILELINE_LEN);
            sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iI,IFX_SCHEDULE_DOWNLOAD_IS_COMPLETE);
            if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
            }

            if(atoi(sVal) == IFX_TRANSFER_ISCOMPLETE_INPROGRESS)
            {
                /* Unable to cancel if download is already in progress */
                istatus = 9021;
#ifdef IFX_LOG_DEBUG
                IFX_DBG("\n\n In Function [%s %d] : Download already done,cannot cancel transfer for iIdx:%d !!\n\n",
                    __func__,__LINE__,iI);
#endif
            }
            else if(atoi(sVal) == IFX_TRANSFER_ISCOMPLETE_DEFAULT)
            {
                /* If download is not complete (not yet started) check its status */
                memset(sBuf , '\0' , MAX_FILELINE_LEN);
                sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iI,IFX_SCHEDULE_DOWNLOAD_STATUS);
                if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                    IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                     __func__,__LINE__);
#endif
                    goto IFX_Handler;
                }

                if(atoi(sVal) == atoi(IFX_DOWNLOAD_STATUS_PENDING) || atoi(sVal) == atoi(IFX_DOWNLOAD_STATUS_NOTSTARTED))
                {
                    /* If this is the pending download then set a flag to 1, 
                       else just set the section to default values */
                    if(atoi(sVal) == atoi(IFX_DOWNLOAD_STATUS_PENDING))
                        iCrntDwnld = 1;

                    sprintf(sVal, "%s_%d_%s=\"%s\"\n",  IFX_SCHEDULE_DOWNLOAD_SECTION,iI,
                    IFX_SCHEDULE_DOWNLOAD_COMMANDKEY, "");

                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iI,
                    IFX_SCHEDULE_DOWNLOAD_FILETYPE, "");

                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iI,
                    IFX_SCHEDULE_DOWNLOAD_FILENAME, "");

                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iI,
                    IFX_SCHEDULE_DOWNLOAD_USERNAME, "");

                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iI,
                    IFX_SCHEDULE_DOWNLOAD_PASSWORD, "");

                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iI,
                    IFX_SCHEDULE_DOWNLOAD_FILESIZE, "0");

                    sprintf(sVal, "%s%s_%d_%s=\"%d\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iI,
                    IFX_SCHEDULE_DOWNLOAD_FUTURETIME, 0);

                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iI,
                    IFX_SCHEDULE_DOWNLOAD_STARTTIME, "0001-01-01T00:00:00Z");

                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iI,
                    IFX_SCHEDULE_DOWNLOAD_ENDTIME, "0001-01-01T00:00:00Z");

                    sprintf(sVal, "%s%s_%d_%s=\"%s\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iI,
                    IFX_SCHEDULE_DOWNLOAD_STATUS, IFX_DOWNLOAD_STATUS_NONE);

                    sprintf(sVal, "%s%s_%d_%s=\"%d\"\n", sVal, IFX_SCHEDULE_DOWNLOAD_SECTION,iI,
                    IFX_SCHEDULE_DOWNLOAD_IS_COMPLETE, 0);

                   if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_SCHEDULE_DOWNLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sVal)) != IFX_SUCCESS)
                   {
#ifdef IFX_LOG_DEBUG
                       IFX_DBG("\n\n In Function [%s %d] : ifx_SetObjData Failed !!\n\n",
                       __func__,__LINE__);
#endif
                       goto IFX_Handler;
                   }
                   icount++;   // Increment for modification of each entry
               }
           }
        }
    }

    if(icount != 0)
    {   /* If atleast one entry in the section has been modified (cancelled), set the count of the section to proper value */
        icount_copy = icount;

        if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   IFX_SCHEDULE_DOWNLOAD_SECTION "_"
                                   IFX_SCHEDULE_DOWNLOAD_COUNT , flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed  !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }

        icount = atoi(sVal) - icount;
        sprintf(sVal_mod, "%s_%s=\"%d\"\n", IFX_SCHEDULE_DOWNLOAD_SECTION,IFX_SCHEDULE_DOWNLOAD_COUNT,icount);

        if(iCrntDwnld == 1)
        {
            /* If the section was reset for the pending download then get the future times of all the entries 
               and determine if there are any other downloads to be scheduled and modify the section accordingly 
               to point to that entry as the next pending download */
            for(iI = 1 ; iI <=3 ; iI++)
            {
                sprintf(sBuf,"%s_%d_%s",IFX_SCHEDULE_DOWNLOAD_SECTION,iI,IFX_SCHEDULE_DOWNLOAD_FUTURETIME);
                if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SCHEDULE_DOWNLOAD_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                    IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                    goto IFX_Handler;
                }
                if((strcmp(sVal,"0")!=0) && ((min_FutureTime == 0) || (min_FutureTime > atoi(sVal))))
                {
                    nextIdx = iI;
                    min_FutureTime = atoi(sVal);
                }
            }
            sprintf(sVal_mod, "%s%s_%s=\"%d\"\n", sVal_mod, IFX_SCHEDULE_DOWNLOAD_SECTION,IFX_SCHEDULE_DOWNLOAD_NEXT_QUEUED_IDX,nextIdx);
            if(nextIdx != 0)
            {
                sprintf(sVal_mod, "%s%s_%d_%s=\"%s\"\n", sVal_mod, IFX_SCHEDULE_DOWNLOAD_SECTION,nextIdx,IFX_SCHEDULE_DOWNLOAD_STATUS,IFX_DOWNLOAD_STATUS_PENDING);
            }

        }

        if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_SCHEDULE_DOWNLOAD_SECTION, IFX_F_MODIFY, 1,
                                    sVal_mod)) != IFX_SUCCESS)
        {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                        __func__,__LINE__);
#endif
            goto IFX_Handler;
        }
    }
    else
    {  /* No entry has been modified means matching command key was not found */
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : Matching CommandKey not Found !!\n\n",
                        __func__,__LINE__);
#endif
        iRtn = IFX_CT_CMDKEY_NOT_FOUND;
        goto IFX_Handler;
    }

    if((iCrntDwnld == 1) && (nextIdx != 0))
    {
        /* If the pending download entry has been reset AND there is another download to be scheduled 
           get the values for that download and populate the structure 
           set return value accordingly */
        if((iRtn = ifx_get_next_schedule_download(xSD)) < IFX_SUCCESS){
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
            goto IFX_Handler;
        }
        iRtn = IFX_CT_SCHEDULE_NEXT;
        goto IFX_Handler;
    }
    else if((iCrntDwnld == 1) && (nextIdx == 0))
    {
        /* If the pending download entry has been reset AND there is no other download to be scheduled
           set return value accordingly */
        iRtn = IFX_CT_ONLY;
        goto IFX_Handler;
    }
    if((iCrntDwnld == 0) && (icount_copy != 0))
    {
        /* If the entry that was reset was not the pending download return success */
        iRtn = IFX_SUCCESS;
    }
IFX_Handler:
    /* If the command key matched for the download already in progress send error accordingly */
    if(istatus == 9021)
        iRtn = 9021;

return iRtn;
}

int32 ifx_get_sdl_info(SCHEDULE_DOWNLOAD_STRUCT *xSD)
{
    char8 sVal[MAX_FILELINE_LEN] , sBuf[MAX_FILELINE_LEN];
    uint32 flags = IFX_F_GET_ANY;
    uint32 ulOutFlag;
    int32 iRtn = IFX_SUCCESS ;

    if(xSD == NULL){
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : Null Pointer  !!\n\n",
                    __func__,__LINE__);
#endif
        goto IFX_Handler;
    }

    memset(sVal, '\0', MAX_FILELINE_LEN);
    memset(xSD , '\0' , sizeof(QUEUED_DOWNLOAD_STRUCT));
    strcpy(xSD->FutureTime," ");

    sprintf(sBuf,"%s_%s",IFX_SDL_INFO_SECTION,IFX_SDL_INFO_COMMANDKEY);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SDL_INFO_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->CommandKey , sVal);

    
    sprintf(sBuf,"%s_%s",IFX_SDL_INFO_SECTION,IFX_SDL_INFO_STARTTIME);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SDL_INFO_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->StartTime , sVal);

    sprintf(sBuf,"%s_%s",IFX_SDL_INFO_SECTION,IFX_SDL_INFO_ENDTIME);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SDL_INFO_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->EndTime , sVal);

    sprintf(sBuf,"%s_%s",IFX_SDL_INFO_SECTION,IFX_SDL_INFO_STATUS);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF,IFX_SDL_INFO_SECTION ,
                                   sBuf,
                                   flags,
                                   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_GetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
                goto IFX_Handler;
    }
    strcpy(xSD->Status , sVal);

IFX_Handler:
return iRtn;

}
int32 ifx_set_sdl_info(char sdl_params[5][256])
{
    char8 sVal[MAX_DATA_LEN] ={0} ;
    int32 iRtn = IFX_SUCCESS;
    sprintf(sVal, "%s_%s=\"%s\"\n",  IFX_SDL_INFO_SECTION,
                IFX_SDL_INFO_COMMANDKEY, sdl_params[0]);

    sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_SDL_INFO_SECTION,
                IFX_SDL_INFO_FILETYPE, sdl_params[4]);

    sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_SDL_INFO_SECTION,
                IFX_SDL_INFO_STARTTIME, sdl_params[1]);

    sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_SDL_INFO_SECTION,
                IFX_SDL_INFO_ENDTIME, sdl_params[2]);

    sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_SDL_INFO_SECTION,
                IFX_SDL_INFO_STATUS,sdl_params[3] );
    if ((iRtn = ifx_SetObjData(FILE_RC_CONF, IFX_SDL_INFO_SECTION, IFX_F_MODIFY, 1,
                                    sVal)) != IFX_SUCCESS)
    {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s %d] : ifx_SetObjData Failed !!\n\n",
                    __func__,__LINE__);
#endif
    }
    if (ifx_flash_write() <= 0) {
        iRtn =  IFX_FAILURE;
    }
return iRtn;
}
