#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

#include "ifx_common.h"

/* External definition */
extern int32 dw_last_probe_status_get(int32 probe_wan_mode,
              dw_wan_status_info_t * probe_status);
extern int32 default_wan_iface_get_for_wan_phymode(WAN_PHY_CFG * wan_phy,
               char8 * iface);

extern int32 dw_check_ip_url(char8 *IpUrlStr, char8 *retStr);


/***************************** Local definition *******************************/
#define DW_STATE_PRIMARY     0
#define DW_STATE_SECONDARY   1

/* Retry count configured from web */
static int32 snRetryCount = 0;
/* Probe to be continued from beggining or only for secondary*/
static int32 dwWanState =  DW_STATE_PRIMARY;

static bool bStopDaemon = FALSE;

/* Currently active wan information */
dw_wan_info_t curr_wan_info = { -1, -1 };

/* Configuration information for dual wan from web */
dw_config_info_t dw_cfg_info = { 0 };

/* Internal functions */
static void dw_daemon_probe_wait(void);
static void dw_daemon_ProbeTimeout(int signum);

static void dw_daemon_probe_wan( int32 probe_wan_mode, 
                                 dw_wan_status_info_t* pWanStatus);

static void dw_daemon_use_wan(int32);

/* Signal hanlders */
static void dw_daemon_stop( int32 signal);

#if 0 /* This signal handler is required in future */
static void dw_daemon_UsrSigHandler(int32 signal);
#endif

#define dw_IsWanUp(wanStatus) ( ((wanStatus)->phy_status == PHY_LINK_UP) && \
                                 ((wanStatus)->wan_status == WAN_LINK_UP) )



int main()
{
  int32 retVal = IFX_SUCCESS;
 
  //TODO: Make it real daemon 

  /* get the config parameters from rc.conf and update the global structure */
  retVal = dw_mapi_cfg_get(&dw_cfg_info, IFX_F_GET_ANY);
  if (retVal != IFX_SUCCESS) {
    IFX_DBG("Dual WAN Config Get Failed. Exit daemon!!\n");
    exit(0);
  }

  /* Update the current wan mode information */
  /* Since we start with primary wan probing, set it to primary wan config */
  curr_wan_info.phy_mode = dw_cfg_info.pri_wan_cfg.phy_mode;
  curr_wan_info.wan_tc = dw_cfg_info.pri_wan_cfg.wan_tc;

  /* catch the signal kill and stop the daemon */
  signal(SIGTERM, dw_daemon_stop);
  signal(SIGINT, dw_daemon_stop);
  
  /* signal to catch any updation in DSL or 3G status or default gateway change */
  //signal(SIGUSR1, dw_daemon_UsrSigHandler);

  /* wait for the proble interval and send alarm when time out happens */
  dw_daemon_probe_wait();

  IFX_DBG("<DW>: Dual WAN daemon terminated\n");

  return IFX_SUCCESS;
}

static void dw_daemon_probe_wait()
{
  uint32 uRemainingTime = dw_cfg_info.probe_info.probe_int ;

  while( bStopDaemon == FALSE ) { 
    uRemainingTime = sleep( uRemainingTime );
   
    /* If eventing (SIGUSR1) is used, need few more conditions */
    if( uRemainingTime > 0 ) 
      continue ;

    dw_daemon_ProbeTimeout(0);
    uRemainingTime = dw_cfg_info.probe_info.probe_int ;
  }
  
  /*
   * Since this dw_daemon is stopped gracefully, so executing following scripts
   * is not required.
   */
#if 0  
  /* stop primary wan */
  /* if HSB or if (CSB && WANc = WANs), stop WANs */
  /* if DSL and ETH combination, reset LAN Switch Config */
  system("/etc/init.d/dw_daemon.sh stop"); 
#endif

}


static void dw_daemon_ProbeTimeout(int signum)
{

  dw_wan_status_info_t wanStatus = { {0} };
  
  IFX_DBG("<DW>: Mode: %s DualWan State: %s RetryCount: %d\n",
          (dw_cfg_info.fo_type == FO_HSB)?("Hybrid"):("Failover"),
          (DW_STATE_PRIMARY == dwWanState)?("Primary"):("Secondary"),
          snRetryCount );

  if (dw_cfg_info.fo_type == FO_HSB) {  /* if HSB */
    
    /* probe for primary wan and secondary wan */
    dw_daemon_probe_wan(DW_PROBE_WAN_BOTH, &wanStatus);

    if( dw_IsWanUp(&(wanStatus.pri_wan_status)) ) {
      
      IFX_DBG("<DW>: Primary UP\n");
      if( dwWanState == DW_STATE_SECONDARY ) {

        /* Primary wan is UP, so start using it now */      
        IFX_DBG("<DW>: Switching to Primary\n");
        dw_daemon_use_wan(DW_PROBE_WAN_PRIMARY);
        dwWanState = DW_STATE_PRIMARY;
      }
    } else {

      IFX_DBG("<DW>: Primary DOWN\n");
      if( dwWanState == DW_STATE_PRIMARY) {

        if( snRetryCount ) {
          --snRetryCount;
          return; /* Try for snRetryCount times */
        } else if( dw_IsWanUp(&(wanStatus.sec_wan_status)) ) {
          IFX_DBG("<DW>: Switching to Secondary\n");
          dw_daemon_use_wan(DW_PROBE_WAN_SECONDARY);
          dwWanState = DW_STATE_SECONDARY;
        }
        return ;
      }
    }

  } else { /* CSB: Failover case */

    /*
     * Probe primary: If primary is down and tried retry count times, then
     * start probing secondary.
     * Probe Secondary:
     */    
    dw_daemon_probe_wan(DW_PROBE_WAN_PRIMARY, &wanStatus);

    if( dw_IsWanUp(&(wanStatus.pri_wan_status)) ) {
     
      IFX_DBG("<DW>: Primary UP\n");
      /* Primary UP. If probing secondary also, stop probing secondary and use
         primary */
      if( dwWanState == DW_STATE_SECONDARY ) {
        IFX_DBG("<DW>: Switching to Primary\n");
        dw_daemon_use_wan(DW_PROBE_WAN_PRIMARY);
        dwWanState = DW_STATE_PRIMARY;
      }

    } else {

      IFX_DBG("<DW>: Primary DOWN. ProbeStat=%d Retry Count=%d\n",
              dwWanState,
              snRetryCount);
      /* If probing primary and tried retry count times, then start probing 
         secondary. */
      if( dwWanState == DW_STATE_PRIMARY ) {
        if( snRetryCount ) {
          --snRetryCount;
          return ; /* Try snRetryCount times on primary */
        } else {
        
          /* Use secondary wan */
          IFX_DBG("<DW>: Switching to secondary\n");
          dw_daemon_use_wan(DW_PROBE_WAN_SECONDARY);
          dwWanState = DW_STATE_SECONDARY;
          return;
        }
      } else {
        dw_daemon_probe_wan(DW_PROBE_WAN_SECONDARY,&wanStatus);
        if( dw_IsWanUp(&(wanStatus.sec_wan_status)) ) {
          IFX_DBG("<DW>: Secondary UP\n");
        }
        return ;
      }
    }
  } /* Failover */
  
  /*
   * We reach here only when primary is UP
   * Reload the retry count.
   */ 
  //IFX_DBG("<DW>: %s exit normal\n",__FUNCTION__); 
  snRetryCount = dw_cfg_info.probe_info.probe_retry;
  return ;
}

static void dw_daemon_probe_wan( int32 probe_wan_mode, 
                                 dw_wan_status_info_t* pWanStatus)
{
  char8 strBuf[MAX_FILELINE_LEN] = { 0 };
  char8 retStr[MAX_STR_LEN];

  NULL_TERMINATE(retStr, 0, sizeof(retStr));

#ifdef DBG
  IFX_DBG("[%s] : Porbe type: %d\n", __FUNCTION__, probe_wan_mode);
#endif

  if (dw_check_ip_url(dw_cfg_info.probe_info.probe_ip_url, retStr) == IFX_FAILURE) {
    strcpy(retStr, "URL");
  }

  sprintf(strBuf, "/etc/init.d/dw_daemon_probe_wan.sh %s %d",
                  retStr, 
                  probe_wan_mode);

#ifdef DBG
  IFX_DBG("probe command: %s\n", strBuf);
#endif
  /* Call the script that is formed*/
  system(strBuf);
  /* Call the MAPI to Get the status structure updated */
  memset(pWanStatus,0,sizeof(dw_wan_status_info_t));
  if (dw_last_probe_status_get(probe_wan_mode, pWanStatus) !=  IFX_SUCCESS) {
    IFX_DBG("Failed to Get Status information from file %s\n",
            FILE_SYSTEM_STATUS);
  }
#ifdef DBG
  else {
    IFX_DBG("Probed Status - %d %d %d %d \n",
      pWanStatus->pri_wan_status.phy_status,
      pWanStatus->pri_wan_status.wan_status,
      pWanStatus->sec_wan_status.phy_status,
      pWanStatus->sec_wan_status.wan_status);
  }
#endif

  return ;
}

static void dw_daemon_use_wan(int32 wan_mode)
{
  char8 cmdStr[MAX_FILELINE_LEN];
#ifdef DBG
  IFX_DBG("[%s] : with WAN Type = %d\n", __FUNCTION__, wan_mode);
#endif
  /* if WANx = WANs, WANprev = WANp */
  /* if WANx = WANs, WANprev = WANs */
  /* Stop previous wan WANprev */
  /* if HSB Start default wan connection on WANprev */
  /* Update Wc = Wx */
  /* Update rc.conf parameters for WAN mode change */
  /* Default WAN Connection is already Up.
     Start the other WAN connections on WANx and the services on it */
  /* This should set the default GW by itself */

/*  sprintf(cmdStr, "/etc/init.d/dw_daemon_use_wan.sh %d %d %d", wan_mode, curr_wan_info.phy_mode, curr_wan_info.wan_tc); */
  sprintf(cmdStr, "/etc/init.d/dw_daemon_use_wan.sh %d", wan_mode);

  /* Update the current wan mode information in the global structure */
  if (wan_mode == DW_PROBE_WAN_SECONDARY) {
    curr_wan_info.phy_mode = dw_cfg_info.sec_wan_cfg.phy_mode;
    curr_wan_info.wan_tc = dw_cfg_info.sec_wan_cfg.wan_tc;
  } else if (wan_mode == DW_PROBE_WAN_PRIMARY) {
    curr_wan_info.phy_mode = dw_cfg_info.pri_wan_cfg.phy_mode;
    curr_wan_info.wan_tc = dw_cfg_info.pri_wan_cfg.wan_tc;
  }


  /* IFX_DBG("Calling Script with WANx = mode %d, WANc = %d\n",
             wan_mode, curr_wan_info.phy_mode);
   */
  /* Start WANx and its services all together */
  /* if WANx = WANs, Start WANp Default */
  //IFX_DBG("use wan string %s\n", cmdStr);
  system(cmdStr);

  return;
}

static void dw_daemon_stop( int32 signal )
{
#ifdef DBG
  IFX_DBG("<DW>: Dual Wan Daemon Is Terminating....\n");
#endif
  bStopDaemon = TRUE;
}

#if 0
void dw_daemon_UsrSigHandler(int signal)
{
  printf("<DwDaemon>:  [%s] caught signal %d\n",__FUNCTION__,signal);
  return;
}
#endif
