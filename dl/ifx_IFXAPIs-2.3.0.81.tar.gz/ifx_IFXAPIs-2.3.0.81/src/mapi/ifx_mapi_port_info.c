#define _GNU_SOURCE
#include <stdio.h>
#include <syslog.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
/* 000002:Nirav start */
/* file locks & versioning */
#include <sys/time.h>
#include <sys/file.h>
/* 000002:Nirav end */
#if defined(IFX_SMALL_FOOTPRINT) && defined(IFX_DLOAD_LIBCRYPT)
//6090602:hsumc change default libcrypt-0.9.26.so to libcrypt.so
#define LIBCRYPT        "libcrypt.so"
#include <dlfcn.h>
#else
#include "crypt.h"
#endif

#define USE_SWITCH_API_ENUM_H
#include "ifx_common.h"
#include "ifx_api_include.h"
#ifdef CONFIG_PACKAGE_SWITCH_CLI
#ifdef IFX_SUCCESS
#undef IFX_SUCCESS
#endif

#include "ifx_ethsw.h"
#include "ifx_ethsw_api.h"
//static char switch_dev[]="/dev/switch_api/1";
#endif				/*CONFIG_PACKAGE_SWITCH_CLI */

int ifx_get_phyport_info(int num, struct ifx_phyport_info *pstPortInfo,
			 int node)
{
#ifdef CONFIG_PACKAGE_SWITCH_CLI
	void *ioctl_params = NULL;
	union ifx_sw_param x;
	int retval = IFX_SUCCESS;
	int switch_fd = 0;
	char switch_dev[20] = { 0 };
#endif

	if (pstPortInfo == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("Invalid input parameters\n");
#endif
		return -1;
	}
	memset(pstPortInfo, 0x00, sizeof(struct ifx_phyport_info));

#ifdef CONFIG_PACKAGE_SWITCH_CLI
	if ((node != 1) && (node != 0)) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]Invalid node value\n", __FUNCTION__, __LINE__);
#endif
		return -1;
	}
#if defined(PLATFORM_AR9) && !defined(PLATFORM_AR10)
	if(num == 5)	
	{
		num = 1;
		node = 0;
	}
#endif
	sprintf(switch_dev, "/dev/switch_api/%d", node);
	if ((switch_fd = open(switch_dev, O_RDONLY)) == -1) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n [%s:%d] Unable to open switch dev\n", __FUNCTION__,
			__LINE__);
#endif
		return -1;
	}
	/* Enable */

	memset(&x.portcfg, 0x00, sizeof(x.portcfg));
#if defined(PLATFORM_AR10) && !defined(CONFIG_PACKAGE_KMOD_LTQCPE_AR10_F2_SUPPORT)
	if (num == 3) {
		num++;
	}
#endif
	x.portcfg.nPortId = num;
	ioctl_params = (void *)&x.portcfg;

	/* pass data to device driver by means of ioctl command */
	retval = ioctl(switch_fd, IFX_ETHSW_PORT_CFG_GET, ioctl_params);
	if (retval != IFX_SUCCESS) {
		printf("IOCTL failed for ioctl command 0x%08X, returned %d\n",
		       IFX_ETHSW_PORT_CFG_GET, retval);
		close(switch_fd);
		return -1;
	}

	if (x.portcfg.eEnable == 0) {
		pstPortInfo->enable = 0;
	} else {
		pstPortInfo->enable = 1;
	}

	/* Status */
	memset(&x.portlinkcfgGet, 0x00, sizeof(x.portlinkcfgGet));
#if defined(PLATFORM_AR10) && !defined(CONFIG_PACKAGE_KMOD_LTQCPE_AR10_F2_SUPPORT)
	if (num == 3 || num == 4) {
		num++;
	}
#endif
	x.portlinkcfgGet.nPortId = num;
	ioctl_params = (void *)&x.portlinkcfgGet;

	/* pass data to device driver by means of ioctl command */

	retval = ioctl(switch_fd, IFX_ETHSW_PORT_LINK_CFG_GET, ioctl_params);
	if (retval != IFX_SUCCESS) {
		printf("IOCTL failed for ioctl command 0x%08X, returned %d\n",
		       IFX_ETHSW_PORT_LINK_CFG_GET, retval);
		close(switch_fd);
		return -1;
	}
	if (x.portlinkcfgGet.eLink == IFX_ETHSW_PORT_LINK_DOWN) {
		pstPortInfo->link = 0;
	} else if (x.portlinkcfgGet.eLink == IFX_ETHSW_PORT_LINK_UP) {
		pstPortInfo->link = 1;
	}

	/* MaxBitRate */
	pstPortInfo->speed = x.portlinkcfgGet.eSpeed;

	/* Duplex mode */
	if (x.portlinkcfgGet.eDuplex == IFX_ETHSW_DUPLEX_FULL) {
		pstPortInfo->duplex = 1;
	} else if (x.portlinkcfgGet.eDuplex == IFX_ETHSW_DUPLEX_HALF) {
		pstPortInfo->duplex = 0;
	}

	close(switch_fd);
#endif				/*CONFIG_PACKAGE_SWITCH_CLI */

	return 0;
}

int ifx_get_phyportstats_info(int num,
			      struct ifx_phyportstats_info *pstPortStatsInfo,
			      int node)
{
	int retval = 0;
#ifdef CONFIG_PACKAGE_SWITCH_CLI
	void *ioctl_params = NULL;
	union ifx_sw_param x;
	int switch_fd = 0;
	char switch_dev[20] = { 0 };
#endif
	if (pstPortStatsInfo == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("Invalid input parameters \n");
#endif
		return -1;
	}
	memset(pstPortStatsInfo, 0x00, sizeof(struct ifx_phyportstats_info));

#ifdef CONFIG_PACKAGE_SWITCH_CLI
	if ((node != 1) && (node != 0)) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]Invalid node value\n", __FUNCTION__, __LINE__);
#endif
		return -1;
	}
	sprintf(switch_dev, "/dev/switch_api/%d", node);
	if ((switch_fd = open(switch_dev, O_RDONLY)) == -1) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n [%s:%d] Unable to open switch dev\n", __FUNCTION__,
			__LINE__);
#endif
		return -1;
	}

	/* Stats */
	memset(&x.RMON_cnt, 0x00, sizeof(x.RMON_cnt));
#if defined(PLATFORM_VR9) || ((defined(PLATFORM_AR9) || defined(PLATFORM_AR10)) && !defined(CONFIG_PACKAGE_KMOD_LTQCPE_AR10_F2_SUPPORT))
	if (num == 3) {
		num++;
	}
#endif
	x.RMON_cnt.nPortId = num;
	ioctl_params = (void *)&x.RMON_cnt;

	/* pass data to device driver by means of ioctl command */
	retval = ioctl(switch_fd, IFX_ETHSW_RMON_GET, ioctl_params);
	if (retval != IFX_SUCCESS) {
		printf("IOCTL failed for ioctl command 0x%08X, returned %d\n",
		       IFX_ETHSW_PORT_LINK_CFG_GET, retval);
		close(switch_fd);
		return -1;
	}
	pstPortStatsInfo->txPktCnt =
	    x.RMON_cnt.nTxUnicastPkts + x.RMON_cnt.nTxBroadcastPkts +
	    x.RMON_cnt.nTxMulticastPkts;
	pstPortStatsInfo->rxPktCnt =
	    x.RMON_cnt.nRxUnicastPkts + x.RMON_cnt.nRxBroadcastPkts +
	    x.RMON_cnt.nRxMulticastPkts;
	pstPortStatsInfo->txByteCnt = x.RMON_cnt.nTxGoodBytes;
	pstPortStatsInfo->rxByteCnt =
	    x.RMON_cnt.nRxGoodBytes + x.RMON_cnt.nRxBadBytes;
        pstPortStatsInfo->txErrors = x.RMON_cnt.nTxDroppedPkts;
        pstPortStatsInfo->txDscrdPktCnt = x.RMON_cnt.nTxAcmDroppedPkts;
        pstPortStatsInfo->rxErrors = x.RMON_cnt.nRxFCSErrorPkts + x.RMON_cnt.nRxOversizeErrorPkts + x.RMON_cnt.nRxUnderSizeErrorPkts;
        pstPortStatsInfo->rxDscrdPktCnt = ((x.RMON_cnt.nRxUnicastPkts + x.RMON_cnt.nRxMulticastPkts + x.RMON_cnt.nRxBroadcastPkts) - x.RMON_cnt.nRxGoodPkts);
        pstPortStatsInfo->txUnicastPktCnt = x.RMON_cnt.nTxUnicastPkts;
        pstPortStatsInfo->rxUnicastPktCnt = x.RMON_cnt.nRxUnicastPkts;
        pstPortStatsInfo->txMulticastPktCnt = x.RMON_cnt.nTxMulticastPkts;
        pstPortStatsInfo->rxMulticastPktCnt = x.RMON_cnt.nRxMulticastPkts;
        pstPortStatsInfo->txBroadcastPktCnt = x.RMON_cnt.nTxBroadcastPkts;
        pstPortStatsInfo->rxBroadcastPktCnt = x.RMON_cnt.nRxBroadcastPkts;

        pstPortStatsInfo->rxUnknownProtoPktCnt = 0;

	close(switch_fd);
#endif				/*CONFIG_PACKAGE_SWITCH_CLI */
	return retval;
}

int ifx_set_phyport_info(int num, IFX_MAPI_PhyPort_Info_Param phyport_param,
			 char8 * value, int node)
{
	int retval = 0;
#ifdef CONFIG_PACKAGE_SWITCH_CLI
	void *ioctl_params = NULL;
	union ifx_sw_param x;
	int switch_fd = 0;
	char switch_dev[20] = { 0 };

	if (value == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("Invalid input parameter\n");
#endif
		return -1;
	}

	if ((node != 1) && (node != 0)) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]Invalid node value\n", __FUNCTION__, __LINE__);
#endif
		return -1;
	}
	sprintf(switch_dev, "/dev/switch_api/%d", node);

	if ((switch_fd = open(switch_dev, O_RDONLY)) == -1) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n [%s:%d] Unable to open switch dev\n", __FUNCTION__,
			__LINE__);
#endif
		return -1;
	}

	switch (phyport_param) {
	case IFX_MAPI_LANEIC_ENABLE:
		{
			memset(&x.portcfg, 0x00, sizeof(x.portcfg));
#if defined(PLATFORM_AR9) && !defined(CONFIG_PACKAGE_KMOD_LTQCPE_GW188_SUPPORT) && defined(PLATFORM_AR10)
			if (num == 3) {
				num++;
			}
#endif
			x.portcfg.nPortId = num;
			ioctl_params = (void *)&x.portcfg;

			/* pass data to device driver by means of ioctl command */
			retval =
			    ioctl(switch_fd, IFX_ETHSW_PORT_CFG_GET,
				  ioctl_params);
			if (retval != IFX_SUCCESS) {
				printf
				    ("IOCTL failed for ioctl command 0x%08X, returned %d\n",
				     IFX_ETHSW_PORT_CFG_GET, retval);
				close(switch_fd);
				return -1;
			}
			/*Set */
			if (atoi(value) == 1)
				x.portcfg.eEnable = IFX_ETHSW_PORT_ENABLE_RXTX;
			else
				x.portcfg.eEnable = 0;

			ioctl_params = (void *)&x.portcfg;

			/* pass data to device driver by means of ioctl command */
			retval =
			    ioctl(switch_fd, IFX_ETHSW_PORT_CFG_SET,
				  ioctl_params);
			if (retval != IFX_SUCCESS) {
				printf
				    ("IOCTL failed for ioctl command 0x%08X, returned %d\n",
				     IFX_ETHSW_PORT_CFG_SET, retval);
				close(switch_fd);
				return -1;
			}
			break;
		}
	case IFX_MAPI_LANEIC_SPEED:
	case IFX_MAPI_LANEIC_DUPLEX:
	default:
		{
			break;
		}
	}			//End of switch

	close(switch_fd);
#endif				/*CONFIG_PACKAGE_SWITCH_CLI */

	return retval;
}
