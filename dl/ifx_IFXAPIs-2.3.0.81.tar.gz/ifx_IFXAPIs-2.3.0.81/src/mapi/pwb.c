/*######################################################################################*/
/*#  filename : pwb.c  									*/
/*#  Description : MAPI functions for Port Binding					*/
/*#  Date: 07-03-2013									*/
/*#  Author: lantiq.com									*/
/*######################################################################################*/

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#include <arpa/inet.h>
#include "ifx_common.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"

//TBD : This needs to be removed
#define FEATURE_MULTI_WAN 1

// rc.conf parameter names
char8 * port_wan_params[] = {"cpeId", "pcpeId", "pwbName", "pwbEnable" , "bitMask", 
				"numLANIfs", "lanIfNames", "wanConName", "wanMode"};

#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)

// global variables used for updating the port binding entries on WAN modification
pwb_cfg_t *cgi_pwb=NULL, *mapi_pwb=NULL;

/****************************************************************************************/
/* Function: mapi_port_binding_cfg_get_all					*/
/* Description: Reads all the existing port binding entries from system			*/
/* Parameters: 										*/
/*	out: uint32 num_entries : number of port binding entries			*/
/*	out: Port_WAN_Binding pwb_array : entries read from rc.conf			*/
/* 	in: uint32 flags : flags from the WEB						*/
/****************************************************************************************/
int32 mapi_port_binding_cfg_get_all (uint32 *num_entries, 
					pwb_cfg_t **pwb_array, uint32 flags)
{
	char8	sValue[MAX_FILELINE_LEN];
	char8	command[MAX_FILELINE_LEN]= "";
	uint32	pwb_index_cnt = 0, ifName_index = 0, buf_index = 0, interface_index  = 0;
	uint32	num=0, ret = IFX_SUCCESS;
	char8   buf[MAX_FILELINE_LEN];
	uint32  inflag = flags, outflag = 0;
	pwb_cfg_t *t_ptr = NULL;
	
	IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_cfg_get_all", "");
	
	if (ifx_GetObjData(FILE_RC_CONF, TAG_PORT_WAN_BINDING,
	                   "port_wan_binding_Count", inflag, &outflag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	} else {
		num = atoi(sValue);
		if (num <=0 || num > 255) {
			*pwb_array = NULL;
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		*num_entries = num;	
	}

	IFX_MEM_ALLOC(t_ptr, pwb_cfg_t*, num, sizeof(pwb_cfg_t));
	if(t_ptr == NULL) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	*pwb_array = t_ptr;
	
	for (pwb_index_cnt=0; pwb_index_cnt<num; pwb_index_cnt++) {

		memset(command,'\0',MAX_FILELINE_LEN);
		MAKE_SECTION_ELEMENT_TAG(PREFIX_PORT_WAN_BINDING, pwb_index_cnt, "cpeId", command);
		if ((ifx_GetObjData(FILE_RC_CONF, TAG_PORT_WAN_BINDING,
		                    command, inflag, &outflag, sValue)) == IFX_SUCCESS) {
			(*pwb_array+pwb_index_cnt)->iid.cpeId.Id = atoi(sValue);
		}

		memset(command,'\0',MAX_FILELINE_LEN);
		MAKE_SECTION_ELEMENT_TAG(PREFIX_PORT_WAN_BINDING, pwb_index_cnt, "pcpeId", command);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_PORT_WAN_BINDING,
		                          command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
		} else
			(*pwb_array+pwb_index_cnt)->iid.pcpeId.Id = atoi(sValue);

		memset(command,'\0',MAX_FILELINE_LEN);
		MAKE_SECTION_ELEMENT_TAG(PREFIX_PORT_WAN_BINDING, pwb_index_cnt, "pwbName", command);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_PORT_WAN_BINDING,
		                          command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
		} else
			strncpy((*pwb_array+pwb_index_cnt)->pwbName,sValue,MAX_NAME_LEN);

		memset(command,'\0',MAX_FILELINE_LEN);
		MAKE_SECTION_ELEMENT_TAG(PREFIX_PORT_WAN_BINDING, pwb_index_cnt, "pwbEnable", command);
		if ((ifx_GetObjData(FILE_RC_CONF, TAG_PORT_WAN_BINDING,
		                    command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
		} else
			(*pwb_array+pwb_index_cnt)->pwbEnable=atoi(sValue);

		memset(command,'\0',MAX_FILELINE_LEN);
		MAKE_SECTION_ELEMENT_TAG(PREFIX_PORT_WAN_BINDING, pwb_index_cnt, "bitMask", command);
		if ((ifx_GetObjData(FILE_RC_CONF, TAG_PORT_WAN_BINDING,
		                    command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
		} else
			(*pwb_array+pwb_index_cnt)->bitMask = (uint32)(strtoul(sValue,NULL,10));

		memset(command,'\0',MAX_FILELINE_LEN);
		MAKE_SECTION_ELEMENT_TAG(PREFIX_PORT_WAN_BINDING, pwb_index_cnt, "numLANIfs", command);
		if ((ifx_GetObjData(FILE_RC_CONF, TAG_PORT_WAN_BINDING,
		                    command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
		} else
			(*pwb_array+pwb_index_cnt)->numLANIfs = atoi(sValue);

		memset(command,'\0',MAX_FILELINE_LEN);
		MAKE_SECTION_ELEMENT_TAG(PREFIX_PORT_WAN_BINDING, pwb_index_cnt, "lanIfNames", command);
		if ((ifx_GetObjData(FILE_RC_CONF, TAG_PORT_WAN_BINDING,
		                    command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
		} else {
			interface_index=0;
			buf_index=0;
			/* separating string by "," and storing in ifName */
			for(ifName_index =0; sValue[ifName_index ]!='\0'; ifName_index ++) {
				if(sValue[ifName_index ] == ',') {
					buf[buf_index] = '\0';
					strncpy(((*pwb_array+pwb_index_cnt)->lanifNames[interface_index++]),buf,MAX_IF_NAME);
					buf_index=0;
					continue;
				}
				buf[buf_index++] = sValue[ifName_index ];
			}
			buf[buf_index++]='\0';
			strncpy(((*pwb_array+pwb_index_cnt)->lanifNames[interface_index++]),buf,MAX_IF_NAME);
		}

		memset(command,'\0',MAX_FILELINE_LEN);
		MAKE_SECTION_ELEMENT_TAG(PREFIX_PORT_WAN_BINDING, pwb_index_cnt, "wanConName", command);
		if ((ifx_GetObjData(FILE_RC_CONF, TAG_PORT_WAN_BINDING,
		                    command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
		} else
			strncpy((*pwb_array+pwb_index_cnt)->wanIf.conName, sValue, MAX_CONN_NAME_LEN);

		memset(command,'\0',MAX_FILELINE_LEN);
		MAKE_SECTION_ELEMENT_TAG(PREFIX_PORT_WAN_BINDING, pwb_index_cnt, "wanMode", command);
		if ((ifx_GetObjData(FILE_RC_CONF, TAG_PORT_WAN_BINDING,
		                    command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
		} else
			(*pwb_array+pwb_index_cnt)->wanIf.mode = atoi(sValue);

	}
IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_cfg_get_all", "return");
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		*num_entries = 0;
		IFX_MEM_FREE(*pwb_array)
		return ret;
	} else
		return IFX_SUCCESS;
}
/****************************************************************************************/
/* Function: mapi_port_binding_cfg_set						*/
/* Description: sets the port binding configurations					*/
/* Parameters: 										*/
/*	in: int32 operation :- ADD/MODIFY/DELETE operations				*/
/*	in: Port_WAN_Binding *entry :- Values to be modified/added/deleted		*/
/* 	in: uint32 flags : flags from the WEB						*/
/****************************************************************************************/

int32 mapi_port_binding_cfg_set(int32 operation, pwb_cfg_t *entry, uint32 flags)
{
	char8  	command[MAX_FILELINE_LEN];
	char8 *retStr = NULL,sValue[MAX_FILELINE_LEN];
	char8       conf_buf[MAX_FILELINE_LEN * 4],buf[MAX_FILELINE_LEN];
	int32       count = 0, passed_index = -1, ret = IFX_SUCCESS, interface_index;
	//int32 wanIndx = 0;
	int32 outflag = IFX_F_DEFAULT;
	pwb_cfg_t *pwb = NULL;
	uint32 num=0, flgarr[8],icnt=0;

	IFX_NAME_VALUE_PAIR array_fvp[12];
	NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));
	memset(array_fvp, 0, sizeof(array_fvp));

	IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_cfg_set", "");
	/*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY)
	* append the flag with internal flags */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if ( (IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

	/**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(entry)
		/* Do simple validation of flags such as less than 0 */
		IFX_VALIDATE_FLAGS(flags)
	}
	sprintf(entry->iid.cpeId.secName, "%s", TAG_PORT_WAN_BINDING);
	
	if (entry->iid.pcpeId.Id == 0) {
		
		IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_cfg_set", "%s", entry->wanIf.conName);
		/* Then WAN Connection name MUST HAVE been specified
		 * Use this ConnectionName to extract the parent Section
		 * and the parent's cpeID */
		/* Extract the WAN Connection Name for which PortMap needs to be created */
		if ((ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_IP, 
			"connName", entry->wanIf.conName, &retStr) != IFX_SUCCESS) &&
		    (ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_PPP, 
			"connName", entry->wanIf.conName, &retStr) != IFX_SUCCESS)) {

#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_cfg_set", "coudn't find the wan connection name");

			goto IFX_Handler;
		} else {
			IFX_MAPI_DEBUG(fd,"/tmp/mapi_port_binding_cfg_set","WAN found %s", retStr);
			/* Now we would have got "wan_x" in the retStr
			 * Using this retStr extract out the wanIndx
			 * For this wanIndx there should be either a WANIP
			 * or WANPPP Connection */
			//wanIndx = atoi(strrchr(retStr, '_') + 1);
			//sprintf(buf, "%s_%d_%s", PREFIX_WAN_IP, wanIndx, "cpeId");
			sprintf(buf, "%s_%s", retStr, "cpeId");
			IFX_MAPI_DEBUG(fd,"/tmp/mapi_port_binding_cfg_set", "%s",buf);
			if((ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, IFX_F_GET_ANY,
			                   (IFX_OUT uint32 *)&outflag, sValue)) != IFX_SUCCESS) {
				/* In WANIP we couldn't find the parent for this PortMap
				 * Now Check in WANPPP Section for the same */
				//sprintf(buf, "%s_%d_%s", PREFIX_WAN_PPP, wanIndx, "cpeId");
				if((ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, IFX_F_GET_ANY,
				                   (IFX_OUT uint32 *)&outflag, sValue)) != IFX_SUCCESS) {
					/* Here it could be that it belongs to "ALL" category
					 * How do we handle it ?? For now we ignore adding it!
					 * Return an Error!! */
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
					ret = IFX_FAILURE;
					IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_cfg_set","coundn't find cpeid");

					goto IFX_Handler;
				} else {
					/* Populate the pcpeId for PortMap entry */
					/* Update the Parent's cpeID and Section Name in piid
					 * This would be required only for ADD operation */
					entry->iid.pcpeId.Id = atoi(sValue);
					sprintf(entry->iid.pcpeId.secName, "%s", TAG_WAN_PPP);
					IFX_MAPI_DEBUG(fd,"/tmp/mapi_port_binding_cfg_set","WAN_PPP");
				}
			} else {
				/* Populate the pcpeId for PortMap entry */
				/* Update the Parent's cpeID and Section Name in piid
				 * This would be required only for ADD operation */
				entry->iid.pcpeId.Id = atoi(sValue);
				sprintf(entry->iid.pcpeId.secName, "%s", TAG_WAN_IP);
				IFX_MAPI_DEBUG(fd,"/tmp/mapi_port_binding_cfg_set","WAN_IP");
			}
		}
	} else {
		/* Parent's cpeId is specified, now get the corresponding parent's
		 * section - which is either WANIP or WANPPP */
		IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_cfg_set", "entry->iid.pcpeId.Id=%d",entry->iid.pcpeId.Id);
		memset(conf_buf,0,sizeof(conf_buf));
		sprintf(conf_buf, "%d", entry->iid.pcpeId.Id);
		if (ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_IP, "cpeId",
		                                  conf_buf, &retStr) != IFX_SUCCESS) {
			/* In WANIP we couldn't find the parent for this PortMap
			 * Now Check in WANPPP Section for the same */
			if (ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_PPP, "cpeId",
			                                  conf_buf, &retStr) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				IFX_MAPI_DEBUG(fd,"/tmp/mapi_port_binding_cfg_set","coundn't find cpeid");
				goto IFX_Handler;
			} else {
				sprintf(entry->iid.pcpeId.secName, "%s", TAG_WAN_PPP);
			}
		} else {
			sprintf(entry->iid.pcpeId.secName, "%s", TAG_WAN_IP);
		}
	}
	/**************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_ADD_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_cfg_set", "");
		entry->iid.cpeId.Id = 0;
		/* Allocate the IID 
		*/

		IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_cfg_set", "cpeid=%d pcpeid=%d cpe_secName=%s pcpe_secName=%s", 
				entry->iid.cpeId.Id, entry->iid.pcpeId.Id,entry->iid.cpeId.secName,entry->iid.pcpeId.secName);
		if (ifx_get_IID_Without_TR69(&entry->iid, "enable") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_cfg_set","ifx_get_IID_Without_TR69 failed");
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}

		if(mapi_port_binding_cfg_get_all(&num, &pwb, IFX_F_DEFAULT) != IFX_SUCCESS) {
                        IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_cfg_set", "Fail to get all port wan mapping info !!");
                        goto IFX_Handler;
                }
			
		IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_cfg_set", "num=%d",num);
		// find all the bitmasks in use
		bzero(&flgarr,sizeof(flgarr));
		for(icnt=0;icnt<num;icnt++) {
		    flgarr[(((pwb+icnt)->bitMask)>>29)-1]=1;
		}
		
		// allocating a free bitmask
		for(icnt=0;icnt<8;icnt++){
		    if(flgarr[icnt]==0){
			entry->bitMask=((icnt+1)<<29);
			break;
		    }
		}

                IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_cfg_set", "icnt=%x entry->bitMask=%x",icnt+1,entry->bitMask);
	}
	/**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given stru5ture for ADD/MODIFY Operations */
	count = 0;
	if(IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, 0, 9, port_wan_params);
		ifx_fill_ArrayFvp_uintValues(array_fvp, 0, 2, &entry->iid.cpeId.Id, &entry->iid.pcpeId.Id);
		sprintf(array_fvp[2].value, "%s", entry->pwbName);
                IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_cfg_set", "pwbName=%s, pwbEnable=%d",entry->pwbName,entry->pwbEnable);
		sprintf(array_fvp[3].value, "%d", entry->pwbEnable);
		ifx_fill_ArrayFvp_uintValues(array_fvp, 4, 2,&entry->bitMask,&entry->numLANIfs);
		memset(buf,0,sizeof(buf));
		strcpy(buf,entry->lanifNames[0]);
		/* putting "," between two interface name and storing in buf */
		for(interface_index=1; interface_index < entry->numLANIfs; interface_index++) {
			strcat(buf,",");
			strcat(buf,entry->lanifNames[interface_index]);
		}
                IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_cfg_set", "numlanif=%d, lanifNames=%s",entry->numLANIfs,buf);

		sprintf(array_fvp[6].value, "%s", buf);
		sprintf(array_fvp[7].value, "%s", entry->wanIf.conName);
		sprintf(array_fvp[8].value, "%d", entry->wanIf.mode);
		passed_index = -1;
	}
	count = 9;
	/* Get Config Index in case of modify/delete operations from CPEID */
	if((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, entry->iid.cpeId, passed_index);
	}
	/* Determine the configuration index - for Add, Delete, Modify operations
	 * Name is partial since index is not known Fill array_fvp[] */
	if(ifx_get_conf_index_and_nv_pairs(&entry->iid, passed_index,PREFIX_PORT_WAN_BINDING, count, array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_cfg_set","ifx_get_conf_index_and_nv_pairs failed");
		goto IFX_Handler;
	}
	/************** System Config File Update Block ****************/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);
	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
		if (IFX_DELETE_F_SET(flags) || IFX_MODIFY_F_SET(flags) ) {
			memset(command,'\0',MAX_FILELINE_LEN);
			sprintf(command,"/etc/rc.d/ltq_pwb_config.sh delete %d",passed_index);
			system(command);
		}
	}
	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_PORT_WAN_BINDING, flags, 1, conf_buf);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] %s", __FUNCTION__, __LINE__, conf_buf);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_cfg_set","ifx_SetObjData failed");
		goto IFX_Handler;
	}
	/* find the index of  newly added entry from rc.conf*/
	if(IFX_INT_ADD_F_SET(flags)) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, entry->iid.cpeId, passed_index);
	}
	/* this will Compact the section and also update the count for both ADD and DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags)) {
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_PORT_WAN_BINDING, flags);
	}
	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
		if (IFX_INT_ADD_F_SET(flags) || IFX_MODIFY_F_SET(flags)) {
			if(entry->pwbEnable) {
				sprintf(command,"/etc/rc.d/ltq_pwb_config.sh add %d",passed_index);
				system(command);
			}
		}
	}
	if(IFX_INT_ADD_F_SET(flags)) {
		/* Increment nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_PORT_WAN_BINDING);
	}
	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd,"/tmp/mapi_port_binding_cfg_set","ifx_config_write failed");
		goto IFX_Handler;
	}
	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
IFX_Handler:
	
	IFX_MEM_FREE(retStr);
	IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_cfg_set", "return");
	
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		IFX_MEM_FREE(pwb);
		return ret;
	} else
		IFX_MEM_FREE(pwb);
		return IFX_SUCCESS;
}

/****************************************************************************************/
/* Function: mapi_port_binding_status_get							*/
/* Description: get the status of port binding feature 					*/
/* Parameters: 										*/
/*	out: pwb_status_t *pwb_status :- enable/disable status				*/
/* 	in: uint32 flags : flags from the WEB						*/
/****************************************************************************************/
int32 mapi_port_binding_status_get(pwb_status_t *pwb_status, uint32 flags)
{
	int32       iRet = IFX_SUCCESS;
	char8       sVal[MAX_IF_NAME];
	uint32      ulOutFlag=0;
        IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_status_get", "");

	memset(pwb_status, '\0', sizeof(pwb_status_t));

	if ((iRet = ifx_GetObjData(FILE_RC_CONF, TAG_PORT_WAN_BINDING_STATUS,
	                           TAG_PORT_WAN_BINDING_STATUS "_enable",
	                           flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;
	IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_status_get", "");
	pwb_status->enable = atoi(sVal);
IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_status_get", "return");
	return (iRet);
}
/****************************************************************************************/
/* Function: mapi_port_binding_status_set							*/
/* Description: To Enable/Disable PortBinding feature.					*/
/* Parameters: 										*/
/*	in: pwb_status_t *pwb_status :- enable/disable status				*/
/* 	in: uint32 flags : flags from the WEB						*/
/****************************************************************************************/
int32 mapi_port_binding_status_set(pwb_status_t *pwb_status, uint32 flags)
{
	int32   ret = IFX_SUCCESS;
	char8   buf[MAX_FILELINE_LEN],command[MAX_FILELINE_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[1], *array_changed_fvp = NULL;
	uint32 count =1;
	NULL_TERMINATE(buf, 0, sizeof(buf));
	memset(array_fvp, 0, sizeof(array_fvp));
	flags |= IFX_F_MODIFY;

	IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_status_set", "");

	/************* Name Value Formation as per RC.CONF *************/
	strcpy(array_fvp[0].fieldname, "port_wan_binding_status_enable");
	sprintf(array_fvp[0].value, "%d", pwb_status->enable);
	form_cfgdb_buf(buf, count, array_fvp);
	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_PORT_WAN_BINDING_STATUS, flags, 1, buf);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	if ( pwb_status->enable == 1) {
		memset(command, 0, sizeof(command));
		sprintf(command,"/etc/rc.d/ltq_pwb_config.sh add_all");
		system(command);
	} else {
		memset(command, 0, sizeof(command));
		sprintf(command,"/etc/rc.d/ltq_pwb_config.sh del_all");
		system(command);
	}
	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
IFX_Handler:

	IFX_MAPI_DEBUG(fd, "/tmp/mapi_port_binding_status_set", "return");

	IFX_MEM_FREE(array_changed_fvp)
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/****************************************************************************************/
/* Function: mapi_pwb_delentry_on_wanchange						*/
/* Description: to delete a port binding entry when the wan connection is getting 	*/
/* modified. the deleted enty will be buffered si that the entry can be added once 	*/
/* the wan modification is done								*/
/* Parameters: 										*/
/*	in: char *wanName : WAN connection name						*/
/*      in/out pwb_cfg_t *pwb_entry buffer to store the deleted entry			*/
/****************************************************************************************/
int32 mapi_pwb_delentry_on_wanchange(char *wanName, pwb_cfg_t **pwb_entry)
{
        int ret = IFX_SUCCESS;
	uint32 num_entries=0,i;
	pwb_cfg_t *pwb=NULL, *tptr=NULL;
        uint32 flags = IFX_F_DELETE | IFX_F_DONT_ACTIVATE;

	IFX_MAPI_DEBUG(fd, "/tmp/mapi_pwb_delentry_on_wanchange", "begin %s", wanName);
	
	if(mapi_port_binding_cfg_get_all(&num_entries, &pwb, IFX_F_GET_ANY) != IFX_SUCCESS) {
        	ret=IFX_FAILURE;	
                goto IFX_Handler;
	}
	
	IFX_MAPI_DEBUG(fd, "/tmp/mapi_pwb_delentry_on_wanchange", "num pwb entries  %d", num_entries);
	if(num_entries) {
		for(i=0;i<num_entries;i++) {
			if(strncmp(wanName,(pwb+i)->wanIf.conName, strlen((pwb+i)->wanIf.conName))==0) {
				IFX_MEM_ALLOC (tptr, pwb_cfg_t*, 1, sizeof(pwb_cfg_t)); 
				memcpy(tptr,pwb+i,sizeof(pwb_cfg_t));
				if(mapi_port_binding_cfg_set(IFX_OP_DEL, pwb+i, flags)!= IFX_SUCCESS) {
                        		ret=IFX_FAILURE;
					IFX_MEM_FREE(tptr);	
                        		goto IFX_Handler;
                		}	
				IFX_MAPI_DEBUG(fd, "/tmp/mapi_pwb_delentry_on_wanchange", "entry found %s,%s", (pwb+i)->pwbName, tptr->pwbName);
				*pwb_entry=tptr;
				break;
			}
		}
	}
IFX_Handler:
	IFX_MEM_FREE(pwb);
	IFX_MAPI_DEBUG(fd, "/tmp/mapi_pwb_delentry_on_wanchange", "end %s", wanName);
	return ret;	
}

/****************************************************************************************/
/* Function: mapi_pwb_modentry_on_wanchange						*/
/* Description: to update a port binding entry after the wan connection got modified 	*/
/* The previously buffered entry added back with the new wan connection.	 	*/
/* Parameters: 										*/
/*	in: char *new_wanName : new WAN connection name					*/
/*      in/out pwb_cfg_t *pwb_entry buffer to store the deleted entry			*/
/****************************************************************************************/
int32 mapi_pwb_modentry_on_wanchange(char *new_wanName, pwb_cfg_t *pwb_entry)
{
        int ret = IFX_SUCCESS;
	int i,wanCnt=0;
        uint32 flags = IFX_F_DEFAULT;
	WAN_CONN_CFG mod_wan_cfg;

	IFX_MAPI_DEBUG(fd, "/tmp/mapi_pwb_modentry_on_wanchange", "begin %s", new_wanName);
	
	if(pwb_entry==NULL) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapi_pwb_modentry_on_wanchange", "pwb_entry is NULL");
		ret = IFX_FAILURE;
#ifdef IFX_LOG_DEBUG
	      	IFX_DBG("function [%s] line [%d]  !!", __FUNCTION__, __LINE__);
#endif
	} else {
		
	    if(strstr(new_wanName,"WANIP")) {
		if (ifx_get_sec_count(TAG_WAN_IP, &wanCnt) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		      	IFX_DBG("function [%s] line [%d]  !!", __FUNCTION__, __LINE__);
#endif
		}
		IFX_MAPI_DEBUG(fd, "/tmp/mapi_pwb_modentry_on_wanchange", "WANIP count =%d",wanCnt);
		for (i = 0; i < wanCnt; i++) {
			memset(&mod_wan_cfg, 0x00, sizeof(mod_wan_cfg));
			mod_wan_cfg.type = WAN_TYPE_IP;
			if (mapi_get_wan_config(i, &mod_wan_cfg, IFX_F_GET_ENA) == IFX_SUCCESS) {
				if(!strcmp(mod_wan_cfg.WAN_IP_CONN.wan_cfg.conn_name, new_wanName)) {
					memset(pwb_entry->wanIf.conName,'\0',sizeof(pwb_entry->wanIf.conName));
					strncpy(pwb_entry->wanIf.conName,new_wanName,strlen(new_wanName));
					pwb_entry->wanIf.mode=mod_wan_cfg.WAN_IP_CONN.wan_cfg.wan_mode.mode;
					pwb_entry->iid.pcpeId.Id = mod_wan_cfg.WAN_IP_CONN.wan_cfg.iid.cpeId.Id;
				 	if(mapi_port_binding_cfg_set(IFX_OP_ADD, pwb_entry, flags)!= IFX_SUCCESS) { 
						ret = IFX_FAILURE;
						goto IFX_Handler;
					}
					
		IFX_MAPI_DEBUG(fd, "/tmp/mapi_pwb_modentry_on_wanchange", "entry added = %s",pwb_entry->pwbName);
					break;	
				}
			}
		}
	    } else {
		if (ifx_get_sec_count(TAG_WAN_PPP, &wanCnt) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		      	IFX_DBG("function [%s] line [%d]  !!", __FUNCTION__, __LINE__);
#endif
		}
		IFX_MAPI_DEBUG(fd, "/tmp/mapi_pwb_modentry_on_wanchange", "WANPPP count =%d",wanCnt);
		for (i = 0; i < wanCnt; i++) {
			memset(&mod_wan_cfg, 0x00, sizeof(mod_wan_cfg));
			mod_wan_cfg.type = WAN_TYPE_PPP;
			if (mapi_get_wan_config(i, &mod_wan_cfg, IFX_F_GET_ENA) == IFX_SUCCESS) {
				if(!strcmp(mod_wan_cfg.WAN_PPP_CONN.wan_cfg.conn_name, new_wanName)) {
					memset(pwb_entry->wanIf.conName,'\0',sizeof(pwb_entry->wanIf.conName));
					strncpy(pwb_entry->wanIf.conName,new_wanName,strlen(new_wanName));
					pwb_entry->wanIf.mode=mod_wan_cfg.WAN_PPP_CONN.wan_cfg.wan_mode.mode;
					pwb_entry->iid.pcpeId.Id = mod_wan_cfg.WAN_PPP_CONN.wan_cfg.iid.cpeId.Id;
				 	if(mapi_port_binding_cfg_set(IFX_OP_ADD, pwb_entry, flags)!= IFX_SUCCESS) { 
						ret = IFX_FAILURE;
						goto IFX_Handler;
					}
		IFX_MAPI_DEBUG(fd, "/tmp/mapi_pwb_modentry_on_wanchange", "entry added = %s",pwb_entry->pwbName);
					break;	
				}
			}
		}
	    }
	}
IFX_Handler:
	IFX_MEM_FREE(pwb_entry);
	IFX_MAPI_DEBUG(fd, "/tmp/mapi_pwb_modentry_on_wanchange", "end %s", new_wanName);
	return ret;	
}

#endif //CONFIG_FEATURE_LTQ_PORT_WAN_BINDING
