
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"

#ifdef CONFIG_FEATURE_IPv6
char8 *ipv6_route_param_names[] =
    { "cpeId", "pcpeId", "isPR", "srcIp", "srcprefixlen", "srcStartPort",
"srcEndPort", "dstIp", "dstprefixlen", "dstStartPort", "dstEndPort", "gw", "routeIf",
"routeProto", "diffserv", "metric", "fEnable", "mtuSize", "type" };

#define IS_WILD_CARD(val) ((!strcmp(val, "*"))?1:0)

#define IFX_VALIDATE_DUPLICATE_ROUTE6_ENTRY(entry, flags) { \
        int32     num; \
        int32     ret = IFX_SUCCESS, i; \
        uint32  Flags = IFX_F_DEFAULT; \
        ROUTE6_ENTRY *route = NULL; \
	char ipv6_addr[INET6_ADDRSTRLEN];\
	char ipv6_addr1[INET6_ADDRSTRLEN];\
        ret = ifx_get_all_ipv6_static_route_entries(&num, &route, Flags); \
        if(ret == IFX_SUCCESS)  { \
                for (i=0; i<num; i++)   { \
			inet_ntop(AF_INET6, &((route+i)->ip_dst.ip), ipv6_addr, INET6_ADDRSTRLEN);\
			inet_ntop(AF_INET6, &(entry->ip_dst.ip), ipv6_addr1, INET6_ADDRSTRLEN);\
                        if ( (!strcmp(ipv6_addr, ipv6_addr1)) \
                          && (((route+i)->ip_dst.prefix_len) == entry->ip_dst.prefix_len)) { \
				inet_ntop(AF_INET6, &((route+i)->gw), ipv6_addr, INET6_ADDRSTRLEN);\
				inet_ntop(AF_INET6, &(entry->gw), ipv6_addr1, INET6_ADDRSTRLEN);\
                          	if ((!strcmp(ipv6_addr, ipv6_addr1)) \
                          	&& ((route+i)->iid.cpeId.Id != entry->iid.cpeId.Id) ) { \
                                	IFX_MEM_FREE(route); \
                                	return IFX_DUPLICATE_ENTRY; \
				}\
                        } \
                } \
        } \
        IFX_MEM_FREE(route); \
}

/*//////////////////////////////////////////////////////////////////////////////
 * ifx_get_all_ipv6_static_route_entries(...)
 * num_entries     ==>  outut number of static routes
 * route_entries   ==>  output pointer to an array of static routes
 * flags           ==>
 * Return Value :   IFX_SUCCESS or IFX_FAILURE
                Description:
                        This Function reads the ipv6 static routes in rc.conf file,
                        and stores eah route in the array route6_entries. This
                        also determines the status of each static route by
                          reading the status from running config file.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_all_ipv6_static_route_entries(int32 * num_routes,
					    ROUTE6_ENTRY ** route_entries,
					    uint32 flags)
{
	int nCount = 0, nIndex = 0;
	int ret = IFX_SUCCESS, routes_count = 0, count = 0;
	uint32 outFlag = IFX_F_DEFAULT;
	char *sValue = NULL, temp_buf[MAX_NAME_SIZE];
	char8 sIP[64], sGateway[64];
	//int   prefix_len;
	IFX_NAME_VALUE_PAIR array_fvp[19];
	char8 sCommand[MAX_FILELINE_LEN];
	char8 sBuf[MAX_FILELINE_LEN];
	ROUTE6_ENTRY *t_ptr = NULL;

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(sIP, 0x00, sizeof(sIP));
	NULL_TERMINATE(sGateway, 0x00, sizeof(sGateway));
	NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));

	/* first, get the number of static routes from rc.conf */
	MAKE_SECTION_COUNT_TAG(TAG_ROUTING6, sCommand);
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_ROUTING6, sCommand, flags,
			    &outFlag, sBuf)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	nCount = atoi(sBuf);
	if (nCount < 1 || nCount > 32767) {
		*num_routes = 0;
		*route_entries = NULL;
		goto IFX_Handler;
	}
	*route_entries = NULL;
	t_ptr = (ROUTE6_ENTRY *) IFX_MALLOC(nCount * sizeof(ROUTE6_ENTRY));
	if (t_ptr == NULL) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	*route_entries = t_ptr;
	for (nIndex = 0; nIndex < nCount; nIndex++) {
		/* initialize the cache for this instance */
		snprintf(sBuf, sizeof(sBuf), "%s_%d_", PREFIX_ROUTING6, nIndex);
		if (ifx_GetObjDataOpt
		    (FILE_RC_CONF, TAG_ROUTING6, sBuf,
		     IFX_F_INT_CACHE_INIT | flags, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("[%s:%d] Failed to initialize cache for this instance",
			     __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		/* get each of the route instance from the rc.conf file and convert
		 * it to field value pair array to copy to output array of ipv6 static routes */
		snprintf(sBuf, sizeof(sBuf), "%s_%d_", PREFIX_ROUTING6, nIndex);
		if ((ret =
		     ifx_GetCfgObject(FILE_RC_CONF, TAG_ROUTING6, sBuf, flags,
				      &sValue)) != IFX_SUCCESS) {
			if (ret == IFX_E_UNMATCHED_INPUT) {
				continue;
			}
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		memset(array_fvp, 0x00, sizeof(array_fvp));
		form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);
		if (atoi(array_fvp[2].value) == 0) {
			/* copy the route read into the structure */
			(*route_entries + routes_count)->iid.cpeId.Id =
			    atoi(array_fvp[0].value);
			(*route_entries + routes_count)->iid.pcpeId.Id =
			    atoi(array_fvp[1].value);
			    inet_pton(AF_INET6,
				      (const char *)array_fvp[7].value,
				      &((*route_entries +
					 routes_count)->ip_dst.ip));
			/*if (ret_val <= 0 ) {
			   (*route_entries + routes_count)->ip_dst.ip.s6_addr[0] = '\0';
			   } */
			(*route_entries + routes_count)->ip_dst.prefix_len =
			    atoi(array_fvp[8].value);
			    inet_pton(AF_INET6,
				      (const char *)array_fvp[11].value,
				      &((*route_entries + routes_count)->gw));
			/*if (ret_val <= 0 ) {
			   (*route_entries + routes_count)->gw.s6_addr[0] = '\0';
			   } */
			snprintf((*route_entries + routes_count)->route_if,
				 IFNAMSIZE, "%s", array_fvp[12].value);
			(*route_entries + routes_count)->metric =
			    atoi(array_fvp[15].value);
			(*route_entries + routes_count)->f_enable =
			    atoi(array_fvp[16].value);
			(*route_entries + routes_count)->type =
			    atoi(array_fvp[18].value);
			if ((*route_entries + routes_count)->f_enable == 0)
				(*route_entries + routes_count)->status =
				    ROUTE_STATUS_DISABLED;
			else {
				memset(temp_buf, 0x00, sizeof(temp_buf));
				/* Search this route on cpeId in the running config file */
				snprintf(sBuf, sizeof(sBuf), "route6_%d_status",
					 (*route_entries +
					  routes_count)->iid.cpeId.Id);
				snprintf(sCommand, sizeof(sBuf), "route6_%d",
					 (*route_entries +
					  routes_count)->iid.cpeId.Id);
				/* In case the file doesn't exist or entry missing just have the route status as ERROR */
				if (ifx_GetObjData
				    (FILE_SYSTEM_STATUS, sCommand, sBuf, flags,
				     NULL, temp_buf) != IFX_SUCCESS) {
					(*route_entries +
					 routes_count)->status =
			   ROUTE_STATUS_ERROR;
					routes_count++;
					IFX_MEM_FREE(sValue)
					    continue;
				} else {
					if (!strcmp(temp_buf, "DOWN"))
						/* If cpeId is not found in the file, status is Disabled */
						(*route_entries +
						 routes_count)->status =
				   ROUTE_STATUS_DISABLED;
					else if (!strcmp(temp_buf, "UP"))
						/* If cpeId is found in the file, status is Enabled */
						(*route_entries +
						 routes_count)->status =
				   ROUTE_STATUS_ENABLED;
					else
						(*route_entries +
						 routes_count)->status =
				   ROUTE_STATUS_ERROR;
				}
			}
			routes_count++;
		}
		IFX_MEM_FREE(sValue)
		    /* initialize the cache for this instance */
		    snprintf(sBuf, sizeof(sBuf), "%s_%d_", PREFIX_ROUTING6,
			     nIndex);
		if (ifx_GetObjDataOpt
		    (FILE_RC_CONF, TAG_ROUTING6, sBuf, IFX_F_INT_CACHE_DESTROY,
		     NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("[%s:%d] Failed to initialize cache for this instance",
			     __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}
	*num_routes = routes_count;

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*route_entries)
		    * num_routes = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;

}

int32 ifx_form_ipv6_route_fvp(int32 oper, ROUTE6_ENTRY route, int32 route_flags,
			      IFX_NAME_VALUE_PAIR * arrayFvp,
			      int32 * route_count)
{
	char8 dstIp[INET6_ADDRSTRLEN], gw_addr[INET6_ADDRSTRLEN],
	    dstprefix_len[10];
	int32 dstprefixlen;
	inet_ntop(AF_INET6, &(route.ip_dst.ip), dstIp, INET6_ADDRSTRLEN);
	dstprefixlen = route.ip_dst.prefix_len;
	snprintf(dstprefix_len, sizeof(dstprefix_len), "%d", dstprefixlen);
	inet_ntop(AF_INET6, &(route.gw), gw_addr, INET6_ADDRSTRLEN);
	ifx_fill_ArrayFvp_FName(arrayFvp, 0, 19, ipv6_route_param_names);
	snprintf(arrayFvp[0].value, sizeof(arrayFvp[0].value), "%d",
		 route.iid.cpeId.Id);
	snprintf(arrayFvp[1].value, sizeof(arrayFvp[1].value), "%d",
		 route.iid.pcpeId.Id);
	snprintf(arrayFvp[2].value, sizeof(arrayFvp[2].value), "%d", 0);
	ifx_fill_ArrayFvp_strValues(arrayFvp, 3, 12, "*", "*", "*", "*", dstIp,
				    dstprefix_len, "*", "*", gw_addr,
				    route.route_if, "*", "*");
	snprintf(arrayFvp[15].value, sizeof(arrayFvp[15].value), "%d",
		 route.metric);
	snprintf(arrayFvp[16].value, sizeof(arrayFvp[16].value), "%d",
		 route.f_enable);
	snprintf(arrayFvp[17].value, sizeof(arrayFvp[17].value), "%s", "*");
	/* Determine the Route Type based on the prefix length */
	if (route.type == 0) {
		if (route.ip_dst.prefix_len == 0)
			route.type = ROUTE_TYPE_DEFAULT;
		else if (route.ip_dst.prefix_len == 128)
			route.type = ROUTE_TYPE_HOST;
		else
			route.type = ROUTE_TYPE_NET;
	}
	snprintf(arrayFvp[18].value, sizeof(arrayFvp[18].value), "%d",
		 route.type);
	*route_count = 19;
	return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_ipv6_static_route(...)
* operation       ==>   the operation to be performed for this route entry, can be ADD, DELETE 
* entry           ==>   pointer to ROUTE6_ENTRY structure that has the route details
* flags           ==>   flags that define the behaviour
* Return Value :   IFX_SUCCESS or IFX_FAILURE
                Description:
                        The API will either ADD, DELETE or MODIFY a route entry. It takes the route details such as
                        destination ipv6 address, prefix length, interface .... from the ROUTE6_ENTRY structure and either
                          adds, deletes this route based on the value of operation paramter.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_ipv6_static_route(int32 operation, ROUTE6_ENTRY * entry,
				uint32 flags)
{
	char8 sbuf[MAX_FILELINE_LEN], sval[MAX_FILELINE_LEN];
	int count = 0;		// changed_count = 0;
	int ret = IFX_SUCCESS, passed_index = -1;
	IFX_ID iid;
	IFX_NAME_VALUE_PAIR array_fvp[20];
	//IFX_NAME_VALUE_PAIR  *array_changed_fvp = NULL;
	ROUTE6_ENTRY route_entry;
	uint32 outflag = flags;
	int32 new_type = 0, old_type = 0;
	char8 conf_buf[MAX_DATA_LEN], sCommand[MAX_FILELINE_LEN];	// sCommand1[MAX_FILELINE_LEN];
	char8 new_ip[64], new_gw[64];
	int32 new_prefixlen = 0;
	char8 old_ip[64], old_gw[64];
	int32 old_prefixlen = 0;
	char8 old_prefix_len[10];
	char8 old_route_if[IFNAMSIZE], old_metric[MAX_NAME_SIZE];

	memset(sbuf, '\0', sizeof(sbuf));
	memset(conf_buf, '\0', sizeof(conf_buf));
	memset(sCommand, '\0', sizeof(sCommand));
	//memset(sCommand1,'\0', sizeof(sCommand1));
	memset(new_ip, '\0', sizeof(new_ip));
	memset(new_gw, '\0', sizeof(new_gw));
	memset(old_ip, '\0', sizeof(old_ip));
	memset(old_gw, '\0', sizeof(old_gw));
	memset(old_route_if, '\0', sizeof(old_route_if));
	memset(old_metric, '\0', sizeof(old_metric));
	memset(&iid, 0x00, sizeof(iid));
	memset(array_fvp, 0, sizeof(array_fvp));
	memset(&route_entry, 0x00, sizeof(route_entry));

	/*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE)
	 * append the flag with internal flags */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD)
		flags |= IFX_F_INT_ADD;

	/**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(entry)
		    /* Do simple validation of flags sucha as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
		    /* Check if netmask or ip address is null */
		    //IFX_VALIDATE_ROUTE6_ENTRY(entry, flags)
		    /* check for duplicate entry */
		    IFX_VALIDATE_DUPLICATE_ROUTE6_ENTRY(entry, flags)
	}
	/**************** ID Allocation Block - Only for ADD Operation **************/
	snprintf(entry->iid.cpeId.secName, sizeof(entry->iid.cpeId.secName),
		 "%s", TAG_ROUTING6);
	snprintf(entry->iid.pcpeId.secName, sizeof(entry->iid.pcpeId.secName),
		 "%s", TAG_DEFAULT_WAN);
	entry->iid.pcpeId.Id = 1;
	if (IFX_ADD_F_SET(flags)) {
		/* Allocate the IID for this route instance
		 * Set the parent SectionName and parent IID values
		 * to NULL as there is no parent for Route Entity
		 */
		if (ifx_get_IID(&entry->iid, "dstIp") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}
	if (IFX_DELETE_F_SET(flags)) {
		iid = entry->iid;
		snprintf(entry->iid.cpeId.secName,
			 sizeof(entry->iid.cpeId.secName), "%s", TAG_ROUTING6);
	}
	if (IFX_DELETE_F_NOT_SET(flags)) {
		memcpy(&route_entry, entry, sizeof(ROUTE6_ENTRY));
		ifx_form_ipv6_route_fvp(operation, route_entry, flags,
					array_fvp, &count);
		passed_index = -1;
		LTQ_STRNCPY(new_ip, array_fvp[7].value, sizeof(new_ip));
		new_prefixlen = atoi(array_fvp[8].value);
		LTQ_STRNCPY(new_gw, array_fvp[11].value, sizeof(new_gw));
		if (strlen(array_fvp[18].value))
			new_type = atoi(array_fvp[18].value);
	} else {
		count = 19;
	}
	/* Get Config Index in case of delete operations from CPEID */
	if (IFX_DELETE_F_SET(flags)) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, entry->iid.cpeId,
					 passed_index)
	}
	/* Determine the configuration index - for Add, Delete operations
	 * Name is partial since index is not known  
	 * Fill array_fvp[] */
	if (ifx_get_conf_index_and_nv_pairs
	    (&entry->iid, passed_index, PREFIX_ROUTING6, count, array_fvp,
	     flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	/* Get the old ipaddress, prefix length, gateway, metric and interface from RC.CONF */
	if (IFX_DELETE_F_SET(flags)) {
		snprintf(sbuf, sizeof(sbuf), "%s_%d_dstIp", PREFIX_ROUTING6,
			 passed_index);
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, TAG_ROUTING6, sbuf,
				    IFX_F_GET_ANY, &outflag,
				    old_ip)) != IFX_SUCCESS) {
			goto IFX_Handler;
		}
		snprintf(sbuf, sizeof(sbuf), "%s_%d_dstprefixlen",
			 PREFIX_ROUTING6, passed_index);
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, TAG_ROUTING6, sbuf,
				    IFX_F_GET_ANY, &outflag,
				    old_prefix_len)) != IFX_SUCCESS) {
			goto IFX_Handler;
		}
		old_prefixlen = atoi(old_prefix_len);
		snprintf(sbuf, sizeof(sbuf), "%s_%d_gw", PREFIX_ROUTING6,
			 passed_index);
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, TAG_ROUTING6, sbuf,
				    IFX_F_GET_ANY, &outflag,
				    old_gw)) != IFX_SUCCESS) {
			goto IFX_Handler;
		}
		snprintf(sbuf, sizeof(sbuf), "%s_%d_routeIf", PREFIX_ROUTING6,
			 passed_index);
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, TAG_ROUTING6, sbuf,
				    IFX_F_GET_ANY, &outflag,
				    old_route_if)) != IFX_SUCCESS) {
			goto IFX_Handler;
		}
		snprintf(sbuf, sizeof(sbuf), "%s_%d_metric", PREFIX_ROUTING6,
			 passed_index);
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, TAG_ROUTING6, sbuf,
				    IFX_F_GET_ANY, &outflag,
				    old_metric)) != IFX_SUCCESS) {
			goto IFX_Handler;
		}
		snprintf(sbuf, sizeof(sbuf), "%s_%d_type", PREFIX_ROUTING6,
			 passed_index);
		sval[0] = '\0';
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, TAG_ROUTING6, sbuf,
				    IFX_F_GET_ANY, &outflag,
				    sval)) != IFX_SUCCESS) {
			goto IFX_Handler;
		}
		old_type = atoi(sval);
	}
	/************* ACL Checking block - MUST for DELETE operations ***********/
	if (IFX_ADD_F_NOT_SET(flags)) {
		//CHECK_ACL_RET(entry->iid, count, array_fvp, changed_count, array_changed_fvp, flags, IFX_Handler)
	}
	/************** System Config File Update Block ****************/
	/* Backup rc.conf before proceeding with configuration */
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);
	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_ROUTING6, flags, 1, conf_buf);
	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	/* this will Compact the section and also update the count for both ADD and DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_ROUTING6, flags);
	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* System call to Add/Delete Route */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
		if (IFX_ADD_F_SET(flags)) {
			snprintf(sCommand, sizeof(sCommand),
				 "/etc/rc.d/rc.bringup_ipv6_staticRoutes %s %d %s %d %s %d %s",
				 new_ip, new_prefixlen, new_gw, new_type, "add",
				 entry->metric, entry->route_if);
		} else if (IFX_DELETE_F_SET(flags)) {
			snprintf(sCommand, sizeof(sCommand),
				 "/etc/rc.d/rc.bringup_ipv6_staticRoutes %s %d %s %d %s %d %s",
				 old_ip, old_prefixlen, old_gw, old_type, "del",
				 atoi(old_metric), old_route_if);
		}
		if ((IFX_DELETE_F_SET(flags) || IFX_ADD_F_SET(flags))
		    && entry->f_enable) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			if (system(sCommand))
				ret = IFX_SUCCESS;
		}
		/* checks if ret is not IFX_SUCCESS then restores the rc.conf with CHKPOINT_FILE */
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		if (IFX_ADD_F_SET(flags))
			snprintf(sCommand, sizeof(sCommand),
				 "/etc/rc.d/rc.bringup_ipv6_staticRoutes add %d",
				 entry->iid.cpeId.Id);
		else if (IFX_DELETE_F_SET(flags))
			snprintf(sCommand, sizeof(sCommand),
				 "/etc/rc.d/rc.bringup_ipv6_staticRoutes delete %d",
				 entry->iid.cpeId.Id);
		if (system(sCommand))
			ret = IFX_SUCCESS;
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
	}
	if (IFX_INT_ADD_F_SET(flags)) {
		/* Manipulate nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_ROUTING6);
	}
	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	//IFX_MEM_FREE(array_changed_fvp);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
//      return 0;
}
#endif
