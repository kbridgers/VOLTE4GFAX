/*
 **************************************************************************
 *       file       : crypt.c                                             *
 *       Description: Module for encryption algorithms                    *
 *       Author     : UDAYA SHANKARA KS, RTSS Team                        *
 *       Date       : Thu Aug 23 12:36:27 IST 2012                        *
 **************************************************************************
 */


/*
 *********************************************************************************************
    ALGORITHM DESCRIPTION :
    =======================

    ONE TIME PADDING :
    ==================
    One Time Padding does the modular addition of each bit in the plain text with
    each bit in the secrete key.


    BASE64 :
    ========
    Base64 encoding is the encoding of 6 bit octate to 4 byte encoded charecters.
    The encoding table contains the printable charecters. (A-Z)(a-z)(1-9)+/ charecters and 
    charecter '=' acts as a padding charecter for encoding 6 bit octate to encoded charecters

    eg:
      input string   :  ABCD
      encoded string :  UYNDVA==

    step 1)     A(65)     B(66)       C(67)     D(68)
             0100 0001  0100 0010  0100 0011  0100 0100
  
    step 2)  Reassemble into 6 bit octates.
              (16)    (20)     (9)    (3)     (17)    (0)    (padd)  (padd)
             010000  010100  001001  000011  010001  000000  000000  000000

    step 3)  Reprasent the pritable charecter from lookup table with this offset 
               U       Y       N      D        V      A       =      = 
      
 *********************************************************************************************
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "ifx_config.h"


#ifdef CONFIG_FEATURE_LTQ_PARAMETER_ENCRYPTION

#define KEY_LEN 40
// Key Used for encrypt/Decrypt for one time padding algorithm
int key[KEY_LEN] = { 0x00, 0x11, 0x34, };

/*
 * These values in the lookup table are the suffled values table from the
 * base64 encoding table specified in RFC1113.
 * To avoid possibility of decoding from available opensource commands
 */

static const char cb64[]="ABCDIJKLMNOPQRSTUVWXYZabcdefghiEFGHjklmnopqrstuvwxyz0123456789+/";

/*
 * TRANSLATION HAS BEEN CREATED FROM LATIQ FOR ABOVE ENCODING TABLE 
 *   NOTE: Update the translation table for the above encoding charecters
 */
static const char cd64[]="|$$$}rstuvwxyz{$$$$$$$>?@A]^_`BCDEFGHIJKLMNOPQRS$$$$$$TUVWXYZ[\\abcdefghijklmnopq";

//
// rev_str
//   function to reverse the string
//
void rev_str( char *buf)
{
   int i, j ;
   char temp;

   for ( i = 0, j = strlen(buf)-1; i < j ; i++, j--){
      temp = buf[j];
      buf[j] = buf[i];
      buf[i] = temp;
   }
   
   return;
}

//
// itoa
//   function to convert integer to asci value
//
int itoa( char *char_buf, int value )
{
   int rem = 0;
   int i = 0;

   while( value ){
     rem = value % 10;
     char_buf[i++] = '0' + rem;
     value /= 10; 
   }

   char_buf[i] = '\0';
   rev_str( char_buf);

   return 0;
}

//
// encrypt_OTP
//   function to encrypt the data in ONE TIME PADDING format
//
int encrypt_OTP( register char *out_buf, register const char * in_buf_1, int len ,void *key )
{
  int *key_buf= (int*)key;
  int idx, value ;
  char msg_buf[10];
  char *ptr_buf = out_buf;
  char *in_buf;

  
  in_buf = strdup(in_buf_1);
  for ( idx = 0; idx < len; idx ++){
    if (in_buf[idx] == '\0') break;
    value = in_buf[idx] ^ key_buf[idx]; 
    itoa( msg_buf,value );
    ptr_buf += sprintf( ptr_buf,"%s:",msg_buf);
  }
  
  for ( ; in_buf[idx] != '\0'; idx++){
    value = in_buf[idx] ^ 0 ;
    itoa( msg_buf, value );
    ptr_buf += sprintf( ptr_buf,"%s:", msg_buf);
  }

  *ptr_buf = '\0';
  free(in_buf);

  return 0;
}


//
// get_value 
//   function to get the encrypted value 
//
int get_value( int *value, const char *in_buf, char deli)
{
    char *p = (char*)in_buf,*q;
    char buf[50];

    q = strchr( in_buf,deli);
    if (!q)  
       return -1;
    strncpy(buf,p,q-p);
    buf[q-p] = '\0';
    *value = atoi(buf);
    return (q-p+1);
}

//
// decrypt_OTP
//   function to decrypt the data in ONE TIME PADDING  format 
//
int decrypt_OTP( register char *out_buf, register const char *in_buf, int len ,void *key)
{
  int idx,value;
  int char_len;
  char *ptr_buf = (char*)in_buf;
  int *key_buf = (int*)key;
  int eos = -1;

  for (idx = 0  ; idx < len && *ptr_buf != '\0' && *ptr_buf != '\n';idx++ ){
     char_len = get_value( &value,ptr_buf,':');
     if ( char_len < 0){
        eos = 1;
        break;
     }
     ptr_buf += char_len ;
     out_buf[idx] = value ^ key_buf[idx];
  }

  if ( eos != 1 ){
    for( ; *ptr_buf != '\0' && *ptr_buf != '\n'; idx++){
      char_len = get_value( &value, ptr_buf, ':');
      if (char_len < 0 )
          break;

      ptr_buf += char_len ;
      out_buf[idx] = value ^ 0;
    }
  }

  out_buf[idx] = '\0';
  
  return 0;
}

//
// encodeblock
//   function to encode the 3 bytes octate values into base64 encoded 4 bytes values
//
static void encodeblock( register unsigned char *in, register unsigned char *out, int len )
{
    out[0] = (unsigned char) cb64[ (int)(in[0] >> 2) ];
    out[1] = (unsigned char) cb64[ (int)(((in[0] & 0x03) << 4) | ((in[1] & 0xf0) >> 4)) ];
    out[2] = (unsigned char) (len > 1 ? cb64[ (int)(((in[1] & 0x0f) << 2) | ((in[2] & 0xc0) >> 6)) ] : '=');
    out[3] = (unsigned char) (len > 2 ? cb64[ (int)(in[2] & 0x3f) ] : '=');
}

//
// decodeblock
//  function to decode the base64 encrypted 4 bytes into 3 bytes data
//
static void decodeblock( register unsigned char *in, register unsigned char *out )
{   
    out[0] = (unsigned char ) (in[0] << 2 | in[1] >> 4);
    out[1] = (unsigned char ) (in[1] << 4 | in[2] >> 2);
    out[2] = (unsigned char ) (((in[2] << 6) & 0xc0) | in[3]);
}

//
// encode_base64
//   function to encode the string in customised base64 formate
//
int encode_base64(register char *out_buf, register const char *in_buf, int len,void *key)
{
  int idx = 0,j;
  int chr_len ;
  unsigned char in[4];

  while( idx < len ) {
    chr_len = 0;
    for ( j = 0; j < 3; j++, idx++){
      if (idx < len ){
        in[j] = in_buf[idx];
        chr_len++;
      }
      else 
        in[j] = 0;
    }

    if ( j > 0 ){
       encodeblock( in, (unsigned char*)out_buf,chr_len);
       out_buf += 4;
    }
  }

  *out_buf = '\0';
  return 0;
}



//
// decode_base64
//  function to decode the base64 encrypted string.
//    
int decode_base64( register char *out_buf, register const char *in_buf, int len, void *key)
{
  int idx = 0;
  int j, chr_len;
  char v = 0 ; unsigned char in[4];

  while ( idx < len ){
    for ( j = 0,chr_len = 0,v = 0 ; j < 4; j++){
       v = 0; 
       while( v == 0 && idx < len ){
            v = in_buf[idx];
            v = ((v < 43 || v > 122) ? 0 : (int) cd64[ v -43]);
            if ( v != 0 ){
                v = ((v == (int)'$') ? 0 : v - 61);
            }
            idx++;
       }

       if ( v != 0 ){
           chr_len ++;
           in[j] = (v - 1);
       }
       else 
           in[j] = 0;
    }
    if ( chr_len > 0 ){
        decodeblock( in, (unsigned char*)out_buf);
        out_buf += (chr_len-1);
    }
  }

  out_buf = '\0';
  return 0;
}

//
// ltq_encrypt_par
//     function to encrypt the parameter
//
inline int ltq_encrypt_par( char *out_buf, const char *in_buf, int len , void * enc_key)
{
   return 
      encrypt_OTP( out_buf, in_buf, len, enc_key);
}

//
// ltq_decrypt_par
//    function to decrypt the parameter 
//
inline int ltq_decrypt_par( char *out_buf, const char *in_buf, int len , void *dec_key)
{
   return 
      decrypt_OTP( out_buf, in_buf, len, dec_key );
}

#endif //PARAMETER_ENCRYPTION_FEATURE MACRO
