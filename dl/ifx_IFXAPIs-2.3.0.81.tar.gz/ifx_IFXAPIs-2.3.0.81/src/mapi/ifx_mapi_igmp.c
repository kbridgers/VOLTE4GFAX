
#include <stdio.h>
#include <ctype.h>
#include <fcntl.h>
#include <string.h>
#include <syslog.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <sys/sysinfo.h>
#include "ifx_config.h"
#include "ifx_amazon_cfg.h"
#ifdef CONFIG_PACKAGE_LQ_IGMPD
#include <ifx_emf.h>
#include <string.h>
#include <signal.h>
#include <stdbool.h>
#include <sys/types.h>
#include <sys/wait.h>
#endif				/*  */

#define USE_SWITCH_API_ENUM_H
#include "ifx_common.h"
#include "ifx_api_include.h"
#ifdef CONFIG_PACKAGE_IFX_ETHSW
#ifdef IFX_SUCCESS
#undef IFX_SUCCESS
#endif				/*  */

#include "ifx_ethsw.h"
#include "ifx_ethsw_api.h"
#endif				// CONFIG_PACKAGE_IFX_ETHSW

#ifdef CONFIG_PACKAGE_LQ_IGMPD
#define IFNAMSIZ 16
#define TAG_MULTICAST	"mcast_proxy_snooping"
#define IFACE_SIZE		256
    struct igmp_rc {
	uint32 igmp_query_interval;
	uint32 igmp_query_resp_interval;
	uint32 igmp_last_mem_query_interval;
	uint32 igmp_last_mem_query_count;
	int32 igmp_query_interval_status;
	int32 igmp_query_resp_interval_status;
	int32 igmp_last_mem_query_interval_status;
	int32 igmp_last_mem_query_count_status;
	int32 igmp_fast_leave_status;
	int32 igmp_snooping_status;
	int32 igmp_proxy_status;
	int32 igmp_snooping_mode;
	uint32 mld_query_interval;
	uint32 mld_query_resp_interval;
	uint32 mld_last_mem_query_interval;
	uint32 mld_last_mem_query_count;
	int32 mld_query_interval_status;
	int32 mld_query_resp_interval_status;
	int32 mld_last_mem_query_interval_status;
	int32 mld_last_mem_query_count_status;
	int32 mld_fast_leave_status;
	int32 mld_snooping_status;
	int32 mld_proxy_status;
	int32 mld_snooping_mode;
#ifdef FEATURE_LTQ_MCAST_FILTER_PORT       
	int32 mcast_iface_filter_status;
#endif
	char8 mcast_grp_entry[MAX_DATA_LEN];
	char8 up_iface_str[IFACE_SIZE];
	char8 up_wan_iface_str[IFACE_SIZE];
	char8 down_iface_str[IFACE_SIZE];
#ifdef FEATURE_LTQ_MCAST_FILTER_PORT       
	char8 mcast_iface_filter_str[IFACE_SIZE];
#endif	
};

#endif				/*  */

/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_set_igmp_snoop_cfg(...)
*    	cmd	==>     ioctl command	
*	flags   ==>     not used for now
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
/////////////////////////////////////////////////////////////////////////////*/
int32 ifx_mapi_set_igmp_snoop_cfg(uint32 cmd, uint32 flags)
{

#ifdef CONFIG_FEATURE_IFX_IGMPPROXY

#ifdef CONFIG_PACKAGE_IFX_ETHSW
	IFX_ETHSW_multicastSnoopCfg_t multicast_SnoopCfgSet;
	int retval = -1, ret = IFX_FAILURE;
	int switch_fd = -1;
	char switch_dev[] = "/dev/switch_api/1";
	void *ioctl_params = NULL;
	
	    /* open char device for ioctl communication */
	    if ((switch_fd = open(switch_dev, O_RDONLY)) == -1)
		 {

#ifdef IFX_LOG_DEBUG
		IFX_DBG("Error opening char device %s\n", switch_dev);

#endif				/*  */
		return IFX_FAILURE;
		}
	memset(&multicast_SnoopCfgSet, 0x00, sizeof(multicast_SnoopCfgSet));
	switch (cmd) {
	case IFX_IGMPv2_SNOOPING_ENABLE:
		multicast_SnoopCfgSet.eIGMP_Mode =
		    IFX_ETHSW_MULTICAST_SNOOP_MODE_AUTOLEARNING;
		multicast_SnoopCfgSet.bIGMPv3 = 0;
		multicast_SnoopCfgSet.bCrossVLAN = 0;
		multicast_SnoopCfgSet.eForwardPort = 2;
		multicast_SnoopCfgSet.nClassOfService = 0;
		multicast_SnoopCfgSet.nRobust = 2;
		multicast_SnoopCfgSet.nQueryInterval = 124;
		multicast_SnoopCfgSet.eSuppressionAggregation = 0;
		multicast_SnoopCfgSet.bFastLeave = 1;
		ioctl_params = (void *)&multicast_SnoopCfgSet;
		break;
	case IFX_IGMPv2_SNOOPING_DISABLE:
		multicast_SnoopCfgSet.eIGMP_Mode =
		    IFX_ETHSW_MULTICAST_SNOOP_MODE_DISABLED;
		multicast_SnoopCfgSet.bIGMPv3 = 0;
		multicast_SnoopCfgSet.bCrossVLAN = 0;
		multicast_SnoopCfgSet.eForwardPort = 2;
		multicast_SnoopCfgSet.nClassOfService = 0;
		multicast_SnoopCfgSet.nRobust = 0;
		multicast_SnoopCfgSet.nQueryInterval = 124;
		multicast_SnoopCfgSet.eSuppressionAggregation = 0;
		multicast_SnoopCfgSet.bFastLeave = 0;
		ioctl_params = (void *)&multicast_SnoopCfgSet;
		break;
	default:
		goto IFX_Handler;
	}
	ioctl_params = (void *)&multicast_SnoopCfgSet;
	retval =
	    ioctl(switch_fd, IFX_ETHSW_MULTICAST_SNOOP_CFG_SET, ioctl_params);
	if (retval < 0)
		 {

#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s]:[%d]\n", __FUNCTION__, __LINE__);

#endif				/*  */
		ret = IFX_FAILURE;
		goto IFX_Handler;
		}
	ret = IFX_SUCCESS;
      IFX_Handler:close(switch_fd);
	if (ret != IFX_SUCCESS) {
		return IFX_FAILURE;
	}
	return IFX_SUCCESS;
	
#else				/*  */
	return IFX_FAILURE;

#endif				/*  */

#else				/*  */
	return IFX_SUCCESS;

#endif				/*  */
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_set_igmp_router_port(...)
*	port	==> 	port info 
*    	cmd	==>     ioctl command	
*    	flags	==>     not used for now	
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
/////////////////////////////////////////////////////////////////////////////*/
    int32 ifx_mapi_set_igmp_router_port(uint32 port, uint32 cmd, uint32 flags)
{

#ifdef CONFIG_FEATURE_IFX_IGMPPROXY

#ifdef CONFIG_PACKAGE_IFX_ETHSW
	IFX_ETHSW_multicastRouter_t multicast_RouterPortConfig;
	int retval = -1, ret = IFX_FAILURE;
	int switch_fd = -1;
	char switch_dev[] = "/dev/switch_api/1";
	void *ioctl_params = NULL;
	
#ifdef IFX_LOG_DEBUG
	    IFX_DBG("[%s]:[%d]\n", __FUNCTION__, __LINE__);

#endif				/*  */

	/* open char device for ioctl communication */
	if ((switch_fd = open(switch_dev, O_RDONLY)) == -1)
		 {

#ifdef IFX_LOG_DEBUG
		IFX_DBG("Error opening char device %s\n", switch_dev);

#endif				/*  */
		return IFX_FAILURE;
		}
	memset(&multicast_RouterPortConfig, 0x00,
		sizeof(multicast_RouterPortConfig));
	multicast_RouterPortConfig.nPortId = port;	/* CPU port */
	ioctl_params = (void *)&multicast_RouterPortConfig;
	switch (cmd) {
	case IFX_MCAST_ROUTER_PORT_ADD:

#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s]:[%d]\n", __FUNCTION__, __LINE__);

#endif				/*  */
		retval =
		    ioctl(switch_fd, IFX_ETHSW_MULTICAST_ROUTER_PORT_ADD,
			  ioctl_params);
		break;
	case IFX_MCAST_ROUTER_PORT_REMOVE:

#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s]:[%d]\n", __FUNCTION__, __LINE__);

#endif				/*  */
		retval =
		    ioctl(switch_fd, IFX_ETHSW_MULTICAST_ROUTER_PORT_REMOVE,
			  ioctl_params);
		break;
	default:

#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s]:[%d]\n", __FUNCTION__, __LINE__);

#endif				/*  */
		goto IFX_Handler;
	}
	if (retval < 0)
		 {

#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s]:[%d]\n", __FUNCTION__, __LINE__);

#endif				/*  */
		ret = IFX_FAILURE;
		goto IFX_Handler;
		}
	ret = IFX_SUCCESS;
      IFX_Handler:close(switch_fd);
	if (ret != IFX_SUCCESS) {
		return IFX_FAILURE;
	}
	return IFX_SUCCESS;
	
#else				/*  */
	return IFX_FAILURE;

#endif				/*  */

#else				/*  */
	return IFX_FAILURE;

#endif				/*  */
}


#ifdef CONFIG_PACKAGE_LQ_IGMPD
static void signal_daemon(int sig)
{
	FILE * fd = NULL;
	int32 pid = 0;
	fd = fopen("/var/run/mcastd.pid", "r");
	if (fd) {
		fscanf(fd, "%d", &pid);
		kill(pid, sig);
		fclose(fd);
	}

	else {
		if (sig != SIGINT)
            		system("/etc/rc.d/init.d/igmpd wan_restart");
	}
}

/*//////////////////////////////////////////////////////////////////////////////
* update_mcast_sys_lan_info(...)
*       ptrSet    ==>     mcast parameter values
*
*       Return Value :   void
                Description: Updates the mcast system lan info into the 
				igmp_rc structure
/////////////////////////////////////////////////////////////////////////////*/
static void update_mcast_sys_lan_info(struct igmp_rc *ptrSet)
{

	int32 ret = IFX_SUCCESS, flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT;
	char buf[MAX_FILELINE_LEN], sIndxes[MAX_FILELINE_LEN];
	char sIfName[MAX_IF_NAME_LEN], outbuf[MAX_FILELINE_LEN];
	int lanCount, i;

	char cfg_file_g[512];
	

	sprintf(buf, "%s", "lan_main_Count");
	memset(outbuf, 0, MAX_FILELINE_LEN);
	strcpy(cfg_file_g,"/etc/rc.conf");
	if ((ret =
	     ifx_GetObjData(cfg_file_g, TAG_LAN_MAIN, buf, flags,
			    (IFX_OUT uint32 *) & outFlag,
			    sIndxes)) != IFX_SUCCESS) {
		return;
	}

	if (sIndxes[0] == '0')
		return;

	lanCount = atoi(sIndxes);
	for (i = 0; i < lanCount; i++) {
		sprintf(buf, "lan_main_%d_interface", i);
		memset(sIfName, 0, MAX_IF_NAME_LEN);
		if ((ret =
		     ifx_GetObjData(cfg_file_g, TAG_LAN_MAIN, buf, flags,
				    (IFX_OUT uint32 *) & outFlag,
				    sIfName)) != IFX_SUCCESS) {
			return;
		}
		if (sIfName[0] == '0')
			continue;

		strcat(outbuf, sIfName);
		if (i < (lanCount - 1))
			strcat(outbuf, ",");
	}
	strcpy(ptrSet->down_iface_str,outbuf);
}

static char **read_buffer(char *fname,int *num)
{

	char *ptr = NULL, *name = NULL;
	int count = 0;
	char **str_list;

	if (fname != NULL && (strlen(fname)>0)) {
		ptr = strchr(fname, ',');
		while (ptr) {
			ptr = strchr(ptr + 1, ',');
			count++;
		}

		*num = count + 1;

		str_list = malloc(sizeof(char *) * (*num));
		if (str_list == NULL) {
			*num = 0;
			return NULL;
		}

		count = 0;

		name = malloc(sizeof(char )*strlen(fname));
		if(name == NULL)
		{
			free(str_list);
			return NULL;
		}
		strcpy(name,fname);
		
		ptr = strtok(name, ",");
		while (ptr) {
			str_list[count] = malloc(IFNAMSIZ);
			if (str_list[count] == NULL) {
				int i;
				for (i = 0; i < count - 1; i++)
					free(str_list[i]);
				free(str_list);
				*num = 0;
				free(name);
				return NULL;
			}
			strcpy(str_list[count], ptr);
			ptr = strtok(NULL, ",");
			count++;
		}
		free(name);
		
		return str_list;
	} 

	*num = 0;
	return NULL;
}

/*//////////////////////////////////////////////////////////////////////////////
* update_mcast_sys_wan_info(...)
*       ptrSet    ==>     mcast parameter values
*
*       Return Value :   void
                Description: Updates the mcast system wan info into the 
                                igmp_rc structure
/////////////////////////////////////////////////////////////////////////////*/
static void update_mcast_sys_wan_info(struct igmp_rc *ptrSet)
{

	int ucnt = 0, j = 0;
	char **uwbuf = NULL,  ubuf[512], *ptr_ubuf = NULL;
	int i = 0;
	char ifname[MAX_FILELINE_LEN], secName[MAX_NAME_LEN];
	WAN_TYPE wan_type;

	uwbuf = read_buffer(ptrSet->up_wan_iface_str,&ucnt);
	if(uwbuf != NULL)
	{
		if (ucnt == 0) {
			goto cleanup;
		}
		memset(ubuf, 0, sizeof(ubuf));
		ptr_ubuf = ubuf;
				
		for (j = 0; j < ucnt; j++)
		{
			/* TBD */
			GET_WAN_TYPE_N_SEC_FROM_CONN_NAME(uwbuf[j], wan_type, secName)
			if (IFX_SUCCESS != 
				ifx_get_wan_ifname_from_connName(uwbuf[j], ifname, wan_type))
			{
				continue;
			}
				
			if (ifname[0] == '\0')
			{
				continue;
			}
				
			if (ptr_ubuf != ubuf)
			{
				strcpy(ptr_ubuf, ",");
				ptr_ubuf += strlen(",");
			}
				strcpy(ptr_ubuf, ifname);
				ptr_ubuf += strlen(ifname);

		}

		if (ptr_ubuf != ubuf) 
		{
			strcpy(ptrSet->up_iface_str, ubuf);
		}
				
		cleanup:
			for (i = 0; i < ucnt; i++)
				free(uwbuf[i]);
			if (uwbuf)
				free(uwbuf);
	}

}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_SetIgmpParam_ToRcConf(...)
*       ptrSet    ==>     mcast parameter values
*
*       Return Value :   IFX_FAILURE or IFX_SUCCESS
                Description: Set the igmp parameters from ptrSet into the rc file
/////////////////////////////////////////////////////////////////////////////*/
int ifx_SetIgmpParam_ToRcConf(struct igmp_rc *ptrSet)
{
	char_t sAdvparameter[1024];
	char_t sAdvparameter1[1024];
	char_t sAdvparameter2[1024];
	char_t sAdvparameter3[1024];
	char_t sAdvparameter4[1024];
#ifdef FEATURE_LTQ_MCAST_FILTER_PORT       
	char_t sAdvparameter5[1024];
#endif
 	update_mcast_sys_wan_info(ptrSet);
	update_mcast_sys_lan_info(ptrSet);
	
	/* Populate parameters in rc.conf */
	snprintf(sAdvparameter, sizeof(sAdvparameter),
		     "mcast_grp_entries=\"%s\"\nmcast_upstream=\"%s\"\nmcast_upstream_wan=\"%s\"\nmcast_downstream=\"%s\"\n",
		     ptrSet->mcast_grp_entry, ptrSet->up_iface_str,
		     ptrSet->up_wan_iface_str, ptrSet->down_iface_str);
	gsprintf(sAdvparameter1,
		   "mcast_igmp_query_interval=\"%d\"\nmcast_igmp_query_resp_interval=\"%d\"\nmcast_igmp_last_mem_query_interval=\"%d\"\nmcast_igmp_last_mem_query_count=\"%d\"\n",
		   ptrSet->igmp_query_interval,
		   ptrSet->igmp_query_resp_interval,
		   ptrSet->igmp_last_mem_query_interval,
		   ptrSet->igmp_last_mem_query_count);
	gsprintf(sAdvparameter2,
		   "mcast_igmp_query_interval_status=\"%d\"\nmcast_igmp_query_resp_interval_status=\"%d\"\nmcast_igmp_last_mem_query_interval_status=\"%d\"\nmcast_igmp_last_mem_query_count_status=\"%d\"\nmcast_igmp_fast_leave_status=\"%d\"\nmcast_igmp_snooping_status=\"%d\"\nmcast_igmp_proxy_status=\"%d\"\nmcast_igmp_snooping_mode=\"%d\"\n",
		   ptrSet->igmp_query_interval_status,
		   ptrSet->igmp_query_resp_interval_status,
		   ptrSet->igmp_last_mem_query_interval_status,
		   ptrSet->igmp_last_mem_query_count_status,
		   ptrSet->igmp_fast_leave_status, ptrSet->igmp_snooping_status,
		   ptrSet->igmp_proxy_status, ptrSet->igmp_snooping_mode);
	gsprintf(sAdvparameter3,
		   "mcast_mld_query_interval=\"%d\"\nmcast_mld_query_resp_interval=\"%d\"\nmcast_mld_last_mem_query_interval=\"%d\"\nmcast_mld_last_mem_query_count=\"%d\"\n",
		   ptrSet->mld_query_interval, ptrSet->mld_query_resp_interval,
		   ptrSet->mld_last_mem_query_interval,
		   ptrSet->mld_last_mem_query_count);
	gsprintf(sAdvparameter4,
		   "mcast_mld_query_interval_status=\"%d\"\nmcast_mld_query_resp_interval_status=\"%d\"\nmcast_mld_last_mem_query_interval_status=\"%d\"\nmcast_mld_last_mem_query_count_status=\"%d\"\nmcast_mld_fast_leave_status=\"%d\"\nmcast_mld_snooping_status=\"%d\"\nmcast_mld_proxy_status=\"%d\"\nmcast_mld_snooping_mode=\"%d\"\n",
		   ptrSet->mld_query_interval_status,
		   ptrSet->mld_query_resp_interval_status,
		   ptrSet->mld_last_mem_query_interval_status,
		   ptrSet->mld_last_mem_query_count_status,
		   ptrSet->mld_fast_leave_status, ptrSet->mld_snooping_status,
		   ptrSet->mld_proxy_status, ptrSet->mld_snooping_mode);

#ifdef FEATURE_LTQ_MCAST_FILTER_PORT     
	/* Populate interface filter parameters in rc.conf */
	snprintf(sAdvparameter5, sizeof(sAdvparameter5),
		     "mcast_interface_filter=\"%s\"\nmcast_interface_filter_status=\"%d\"\n",
		   ptrSet->mcast_iface_filter_str,
		   ptrSet->mcast_iface_filter_status);
	if (ifx_SetCfgData
	      (FILE_RC_CONF, TAG_MULTICAST, 6, sAdvparameter, sAdvparameter1,
	       sAdvparameter2, sAdvparameter3, sAdvparameter4, sAdvparameter5) == 0) {
		return IFX_FAILURE;
	}

#else

	if (ifx_SetCfgData
	      (FILE_RC_CONF, TAG_MULTICAST, 5, sAdvparameter, sAdvparameter1,
	       sAdvparameter2, sAdvparameter3, sAdvparameter4) == 0) {
		return IFX_FAILURE;
	}
#endif	
	    /* Save to flash */
	    if (ifx_flash_write() <= 0) {
		return IFX_FAILURE;
	}

#ifdef FEATURE_LTQ_MCAST_FILTER_PORT     
	system("/etc/rc.d/ltq_pwb_config.sh update_mcast_conf");
#endif

	    /* Set/Reset the proc entry */
	    if (1) {
		FILE * fp =
		    fopen("/proc/sys/net/bridge/bridge-igmp-snooping", "w");
		if (fp) {
			fprintf(fp, "%d", ptrSet->igmp_snooping_status);
			fclose(fp);
		}
	}
	if (1) {
		FILE * fp =
		    fopen("/proc/sys/net/bridge/bridge-mld-snooping", "w");
		if (fp) {
			fprintf(fp, "%d", ptrSet->mld_snooping_status);
			fclose(fp);
		}
	}
	
	    /* Signal the daemon */
	    if (ptrSet->mld_snooping_status == 0
		&& ptrSet->mld_proxy_status == 0
		&& ptrSet->igmp_snooping_status == 0
		&& ptrSet->igmp_proxy_status == 0)
		signal_daemon(SIGINT);

	else
		signal_daemon(SIGHUP);
	return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_GetIgmpParam_ToRcConf(...)
*       ptrGet    ==>     mcast parameter values 
*
*       Return Value :   void
                Description: Get the igmp parameters from rc file into the 
				ptrGet struct
/////////////////////////////////////////////////////////////////////////////*/
void ifx_GetIgmpParam_FromRcConf(struct igmp_rc *ptrGet)
{
	int range_val = 0;
	char sVal[MAX_DATA_LEN];
	
	    /* <==== IGMP params ====> */
	    if (ifx_GetCfgData
		(FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_query_interval",
		 sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_query_interval = range_val;
		range_val = 0;
	} else {
		ptrGet->igmp_query_interval = 125;
	}
	if (ifx_GetCfgData
	     (FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_query_resp_interval",
	      sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_query_resp_interval = range_val;
		range_val = 0;
	} else {
		ptrGet->igmp_query_resp_interval = 10;
	}
	if (ifx_GetCfgData
	     (FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_last_mem_query_interval",
	      sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_last_mem_query_interval = range_val;
		range_val = 0;
	} else {
		ptrGet->igmp_last_mem_query_interval = 1;
	}
	if (ifx_GetCfgData
	     (FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_last_mem_query_count",
	      sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_last_mem_query_count = range_val;
		range_val = 0;
	} else {
		ptrGet->igmp_last_mem_query_count = 2;
	}
	
	    // Status checking 
	    if (ifx_GetCfgData
		(FILE_RC_CONF, TAG_MULTICAST,
		 "mcast_igmp_query_interval_status", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_query_interval_status = range_val;
		range_val = 0;
	} else {
		ptrGet->igmp_query_interval_status = 0;
	}
	if (ifx_GetCfgData
	     (FILE_RC_CONF, TAG_MULTICAST,
	      "mcast_igmp_query_resp_interval_status", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_query_resp_interval_status = range_val;
		range_val = 0;
	} else {
		ptrGet->igmp_query_resp_interval_status = 0;
	}
	if (ifx_GetCfgData
	     (FILE_RC_CONF, TAG_MULTICAST,
	      "mcast_igmp_last_mem_query_interval_status", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_last_mem_query_interval_status = range_val;
		range_val = 0;
	} else {
		ptrGet->igmp_last_mem_query_interval_status = 0;
	}
	if (ifx_GetCfgData
	     (FILE_RC_CONF, TAG_MULTICAST,
	      "mcast_igmp_last_mem_query_count_status", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_last_mem_query_count_status = range_val;
		range_val = 0;
	} else {
		ptrGet->igmp_last_mem_query_count_status = 0;
	}
	if (ifx_GetCfgData
	     (FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_fast_leave_status",
	      sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_fast_leave_status = range_val;
		range_val = 0;
	} else {
		ptrGet->igmp_fast_leave_status = 0;
	}
	if (ifx_GetCfgData
	     (FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_snooping_status",
	      sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_snooping_status = range_val;
		range_val = 0;
	} else {
		ptrGet->igmp_snooping_status = range_val;
	}
	if (ifx_GetCfgData
	     (FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_proxy_status",
	      sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_proxy_status = range_val;
		range_val = 0;
	} else {
		ptrGet->igmp_proxy_status = range_val;
	}
	if (ifx_GetCfgData
	     (FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_snooping_mode",
	      sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_snooping_mode = range_val;
		range_val = 0;
	} else {
		ptrGet->igmp_snooping_mode = range_val;
	}
	
	    /* <==== MLD params ====> */
	    if (ifx_GetCfgData
		(FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_query_interval",
		 sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_query_interval = range_val;
		range_val = 0;
	} else {
		ptrGet->mld_query_interval = 125;
	}
	if (ifx_GetCfgData
	     (FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_query_resp_interval",
	      sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_query_resp_interval = range_val;
		range_val = 0;
	} else {
		ptrGet->mld_query_resp_interval = 10;
	}
	if (ifx_GetCfgData
	     (FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_last_mem_query_interval",
	      sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_last_mem_query_interval = range_val;
		range_val = 0;
	} else {
		ptrGet->mld_last_mem_query_interval = 1;
	}
	if (ifx_GetCfgData
	     (FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_last_mem_query_count",
	      sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_last_mem_query_count = range_val;
		range_val = 0;
	} else {
		ptrGet->mld_last_mem_query_count = 2;
	}
	
	    // Status checking 
	    if (ifx_GetCfgData
		(FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_query_interval_status",
		 sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_query_interval_status = range_val;
		range_val = 0;
	} else {
		ptrGet->mld_query_interval_status = 0;
	}
	if (ifx_GetCfgData
	     (FILE_RC_CONF, TAG_MULTICAST,
	      "mcast_mld_query_resp_interval_status", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_query_resp_interval_status = range_val;
		range_val = 0;
	} else {
		ptrGet->mld_query_resp_interval_status = 0;
	}
	if (ifx_GetCfgData
	     (FILE_RC_CONF, TAG_MULTICAST,
	      "mcast_mld_last_mem_query_interval_status", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_last_mem_query_interval_status = range_val;
		range_val = 0;
	} else {
		ptrGet->mld_last_mem_query_interval_status = 0;
	}
	if (ifx_GetCfgData
	     (FILE_RC_CONF, TAG_MULTICAST,
	      "mcast_mld_last_mem_query_count_status", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_last_mem_query_count_status = range_val;
		range_val = 0;
	} else {
		ptrGet->mld_last_mem_query_count_status = 0;
	}
	if (ifx_GetCfgData
	     (FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_fast_leave_status",
	      sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_fast_leave_status = range_val;
		range_val = 0;
	} else {
		ptrGet->mld_fast_leave_status = 0;
	}
	if (ifx_GetCfgData
	     (FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_snooping_status",
	      sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_snooping_status = range_val;
		range_val = 0;
	} else {
		ptrGet->mld_snooping_status = range_val;
	}
	if (ifx_GetCfgData
	     (FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_proxy_status",
	      sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_proxy_status = range_val;
		range_val = 0;
	} else {
		ptrGet->mld_proxy_status = range_val;
	}
	if (ifx_GetCfgData
	     (FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_snooping_mode",
	      sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_snooping_mode = range_val;
		range_val = 0;
	} else {
		ptrGet->mld_snooping_mode = range_val;
	}
	
	    // Multicast Group Entries
	    if (ifx_GetCfgData
		(FILE_RC_CONF, TAG_MULTICAST, "mcast_grp_entries", sVal) == 1) {
		strcpy(ptrGet->mcast_grp_entry, sVal);
	} else {
		strcpy(ptrGet->mcast_grp_entry, "\0");
	}
	
	    // UPSTREAM Interface Checking
	    if (ifx_GetCfgData
		(FILE_RC_CONF, TAG_MULTICAST, "mcast_upstream", sVal)
		== 1) {
		strncpy(ptrGet->up_iface_str, sVal, IFACE_SIZE);
	} else {
		strcpy(ptrGet->up_iface_str, "\0");
	}

	// UPSTREAM WAN Interface Checking
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_MULTICAST, "mcast_upstream_wan", sVal) == 1) {
		strncpy(ptrGet->up_wan_iface_str, sVal, IFACE_SIZE);
	} else {
		strcpy(ptrGet->up_wan_iface_str, "\0");
	}

	// DOWNSTREAM Interface Checking
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_MULTICAST, "mcast_downstream", sVal)
	    == 1) {
		strncpy(ptrGet->down_iface_str, sVal, IFACE_SIZE);
	} else {
		strcpy(ptrGet->down_iface_str, "\0");
	}

#ifdef FEATURE_LTQ_MCAST_FILTER_PORT       
	// Interface Filter
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_MULTICAST, "mcast_interface_filter", sVal)
	    == 1) {
		strncpy(ptrGet->mcast_iface_filter_str, sVal, IFACE_SIZE);
	} else {
		strcpy(ptrGet->mcast_iface_filter_str, "\0");
	}
	if (ifx_GetCfgData
	     (FILE_RC_CONF, TAG_MULTICAST,
	      "mcast_interface_filter_status", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mcast_iface_filter_status = range_val;
		range_val = 0;
	} else {
		ptrGet->mcast_iface_filter_status = 0;
	}

#endif

}

#endif				/*  */

