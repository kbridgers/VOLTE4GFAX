#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#include <arpa/inet.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"
#include <linux/if.h>
#include "ifx_api_ipt_common.h"
#include <ifx_api_ipt_common_private.h>

#if  defined(CONFIG_FEATURE_FIREWALL) && defined(CONFIG_FEATURE_IPv6)

#ifdef IFX_LOG_DEBUG
//#define ltq_mapi_getobj_err_log(str) syslog(3, "[%s:%d]Unable to get value %s", __FUNCTION__, __LINE__, str)
#else
//#define ltq_mapi_getobj_err_log(str)
#endif
#define ltq_mapi_getobj_err_log(str) syslog(3, "[%s:%d]Unable to get value %s", __FUNCTION__, __LINE__, str)

#define firewall6_dbg(fmt, args...)  /* syslog(1, fmt, ##args) */

#define sncpy(dst, src)	snprintf(dst, sizeof(dst), "%s", src)
#define intcpy(dst, src)	snprintf(dst, sizeof(dst), "%u",(unsigned int) src)

#define ltq_get_mapi_err_ret(rc_file, tag, inbuf, inflag, outbuf, outflag, err_ret_value) \
	do {\
		outbuf[0]='\0';\
		if(ifx_GetObjData(rc_file, tag, inbuf, inflag, (IFX_OUT uint32 *) &outflag, outbuf) != IFX_SUCCESS ) {\
			syslog(1,"%s,%s,%s failed\n", rc_file, tag, inbuf);\
			ltq_mapi_getobj_err_log(inbuf);\
			return err_ret_value;\
		}\
	}while(0)

#define ltq_get_firewall_config_err_ret(inbuf,outbuf, outflag, err_ret_value) \
	ltq_get_mapi_err_ret(FILE_RC_CONF, TAG_FIREWALL_CONFIG, inbuf, IFX_F_DEFAULT, outbuf, outflag, err_ret_value)
#define ltq_get_firewall_config_int_err_ret(inbuf,outbuf, outflag, err_ret_value, dst) do {\
		ltq_get_firewall_config_err_ret(inbuf,outbuf, outflag, err_ret_value);\
		dst = atoi(outbuf);\
	} while(0)

#define ltq_get_firewall_config_str_err_ret(inbuf,outbuf, outflag, err_ret_value, dst) do {\
		ltq_get_firewall_config_err_ret(inbuf,outbuf, outflag, err_ret_value);\
		sncpy(dst, outbuf);\
	} while(0)


#define ltq_get_firewall_level_err_ret(inbuf,outbuf, outflag, err_ret_value, idx) do {\
	char8 buf[MAX_FILELINE_LEN];\
	snprintf(buf, sizeof(buf), "%s_%d_%s", PREFIX_FIREWALL_LEVEL, idx, inbuf);\
	ltq_get_mapi_err_ret(FILE_RC_CONF, TAG_FIREWALL_LEVEL, buf, IFX_F_DEFAULT, outbuf, outflag, err_ret_value);\
	} while(0)
#define ltq_get_firewall_level_int_err_ret(inbuf,outbuf, outflag, err_ret_value, dst, idx) do {\
		ltq_get_firewall_level_err_ret(inbuf,outbuf, outflag, err_ret_value, idx);\
		dst = atoi(outbuf);\
	} while(0)

#define ltq_get_firewall_level_str_err_ret(inbuf,outbuf, outflag, err_ret_value, dst, idx) do {\
		ltq_get_firewall_level_err_ret(inbuf,outbuf, outflag, err_ret_value, idx);\
		sncpy(dst, outbuf);\
	} while(0)

#define ltq_get_firewall_chain_err_ret(inbuf,outbuf, outflag, err_ret_value, idx) do {\
	char8 buf[MAX_FILELINE_LEN];\
	snprintf(buf, sizeof(buf), "%s_%d_%s", PREFIX_FIREWALL_CHAIN, idx, inbuf);\
	ltq_get_mapi_err_ret(FILE_RC_CONF, TAG_FIREWALL_CHAIN, buf, IFX_F_DEFAULT, outbuf, outflag, err_ret_value);\
	} while(0)

#define ltq_get_firewall_chain_int_err_ret(inbuf,outbuf, outflag, err_ret_value, dst, idx) do {\
		ltq_get_firewall_chain_err_ret(inbuf,outbuf, outflag, err_ret_value, idx);\
		dst = atoi(outbuf);\
	} while(0)

#define ltq_get_firewall_chain_str_err_ret(inbuf,outbuf, outflag, err_ret_value, dst, idx) do {\
		ltq_get_firewall_chain_err_ret(inbuf,outbuf, outflag, err_ret_value, idx);\
		sncpy(dst, outbuf);\
	} while(0)

#define ltq_get_firewall_rule_err_ret(inbuf,outbuf, outflag, err_ret_value, idx) do {\
	char8 buf[MAX_FILELINE_LEN];\
	snprintf(buf, sizeof(buf), "%s_%d_%s", TAG_FIREWALL_RULE, idx, inbuf);\
	ltq_get_mapi_err_ret(FILE_RC_CONF, TAG_FIREWALL_RULE, buf, IFX_F_DEFAULT, outbuf, outflag, err_ret_value);\
	} while(0)

#define ltq_get_firewall_rule_int_err_ret(inbuf,outbuf, outflag, err_ret_value, dst, idx) do {\
		ltq_get_firewall_rule_err_ret(inbuf,outbuf, outflag, err_ret_value, idx);\
		dst = atoi(outbuf);\
	} while(0)

#define ltq_get_firewall_rule_str_err_ret(inbuf,outbuf, outflag, err_ret_value, dst, idx) do {\
		ltq_get_firewall_rule_err_ret(inbuf,outbuf, outflag, err_ret_value, idx);\
		sncpy(dst, outbuf);\
	} while(0)


#define fill_array_fvp_val_str(str) sncpy(array_fvp[count].value, str)
#define fill_array_fvp_val_int(str) intcpy(array_fvp[count]value str)
#define fill_array_fvp_field(str) sncpy(array_fvp[count++].fieldname, str)
#define fill_array_fvp_field_val_str(str, val) do { \
	sncpy(array_fvp[count].fieldname, str);\
	sncpy(array_fvp[count].value, val);\
	count++;\
	}while(0)
#define fill_array_fvp_field_val_int(str, val) do { \
	sncpy(array_fvp[count].fieldname, str);\
	intcpy(array_fvp[count].value, val);\
	count++;\
	}while(0)

#define fwl_level_fill_array_fvp_field_val_int(str, val, idx) do { \
	char8 buf[MAX_FILELINE_LEN];\
	snprintf(buf, sizeof(buf), "%s_%d_%s", PREFIX_FIREWALL_LEVEL, idx, str);\
	fill_array_fvp_field_val_int(buf, val);\
	}while(0)
#define fwl_level_fill_array_fvp_field_val_str(str, val, idx) do { \
	char8 buf[MAX_FILELINE_LEN];\
	snprintf(buf, sizeof(buf), "%s_%d_%s", PREFIX_FIREWALL_LEVEL, idx, str);\
	fill_array_fvp_field_val_str(buf, val);\
	}while(0)

#define fwl_chain_fill_array_fvp_field_val_int(str, val, idx) do { \
	char8 buf[MAX_FILELINE_LEN];\
	snprintf(buf, sizeof(buf), "%s_%d_%s", PREFIX_FIREWALL_CHAIN, idx, str);\
	fill_array_fvp_field_val_int(buf, val);\
	}while(0)
#define fwl_chain_fill_array_fvp_field_val_str(str, val, idx) do { \
	char8 buf[MAX_FILELINE_LEN];\
	snprintf(buf, sizeof(buf), "%s_%d_%s", PREFIX_FIREWALL_CHAIN, idx, str);\
	fill_array_fvp_field_val_str(buf, val);\
	}while(0)
#define fwl_rule_fill_array_fvp_field_val_int(str, val) do { \
	char8 buf[MAX_FILELINE_LEN];\
	snprintf(buf, sizeof(buf), "%s", str );\
	fill_array_fvp_field_val_int(buf, val);\
	}while(0)
#define fwl_rule_fill_array_fvp_field_val_str(str, val) do { \
	char8 buf[MAX_FILELINE_LEN];\
	snprintf(buf, sizeof(buf), "%s", str );\
	fill_array_fvp_field_val_str(buf, val);\
	}while(0)

int mapi_get_int(char *variable, void *val, int len, char *rc_file, char *tag) 
{
	char8  outbuf[MAX_FILELINE_LEN]={0};
	int32  outflag = IFX_F_DEFAULT;

	outbuf[0]='\0';
	if(ifx_GetObjData(rc_file, tag, variable, IFX_F_DEFAULT, (IFX_OUT uint32 *) &outflag, outbuf) != IFX_SUCCESS ) {
			syslog(1,"%s,%s,%s failed\n", rc_file, tag, variable);
			ltq_mapi_getobj_err_log(variable);
			return -1;
	}

	*((int *)val) = atoi(outbuf);
	return IFX_SUCCESS;
}

int mapi_get_str(char *variable, void *val, int len, char *rc_file, char *tag) 
{
	char8  outbuf[MAX_FILELINE_LEN]={0};
	int32  outflag = IFX_F_DEFAULT;

	outbuf[0]='\0';
	if(ifx_GetObjData(rc_file, tag, variable, IFX_F_DEFAULT, (IFX_OUT uint32 *) &outflag, outbuf) != IFX_SUCCESS ) {
			syslog(1,"%s,%s,%s failed\n", rc_file, tag, variable);
			ltq_mapi_getobj_err_log(variable);
			return -1;
	}

	snprintf(val, len, "%s", outbuf);
	return IFX_SUCCESS;
}

int mapi_set_str(char *variable, char *val, char *rc_file, char *tag) 
{
	char8  setbuf[512]={0};
	int32  flags = IFX_F_DEFAULT |IFX_F_MODIFY;
	int ret;

	snprintf(setbuf, sizeof(setbuf), "%s=\"%s\"\n", variable, val);

	ret = ifx_SetObjData(rc_file, tag, flags, 1, setbuf);

	if (ret != IFX_SUCCESS) {
		firewall6_dbg("Unable to write\n");
		return -1;
	}
	return IFX_SUCCESS;
}

int mapi_set_int(char *variable, int val, char *rc_file, char *tag) 
{
	char8  setbuf[512]={0};
	int32  flags = IFX_F_DEFAULT |IFX_F_MODIFY;
	int ret;

	snprintf(setbuf, sizeof(setbuf), "%s=\"%d\"\n", variable, val);

	ret = ifx_SetObjData(rc_file, tag, flags, 1, setbuf);

	if (ret != IFX_SUCCESS) {
		firewall6_dbg("Unable to write\n");
		return -1;
	}
	return IFX_SUCCESS;
}


#define GI(variable, VAL, rc_file, tag, ret) do {\
	int t; \
	if ( mapi_get_int(variable, &(t), sizeof(t), rc_file, tag) != IFX_SUCCESS) {\
		return ret;\
	}\
	VAL = t;\
}while(0)
#define GS(variable, VAL, rc_file, tag, ret) do {\
	if ( mapi_get_str(variable, &(VAL), sizeof(VAL), rc_file, tag) != IFX_SUCCESS) {\
		return ret;\
	}\
}while(0)

#define SI(dstbuf, variable, VAL) do {\
	char tmpbuf[256];\
	snprintf(tmpbuf, sizeof(tmpbuf), "%s=\"%d\"\n", variable, VAL);\
	strcat(dstbuf, tmpbuf);\
}while(0)
#define SS(dstbuf, variable, VAL) do {\
	char tmpbuf[256];\
	snprintf(tmpbuf, sizeof(tmpbuf), "%s=\"%s\"\n", variable, VAL);\
	strcat(dstbuf, tmpbuf);\
}while(0)


/* ifx_get_conf_index_and_nv_pairs */
LTQ_MAPI_Firewall_Config * mapi_get_firewall_config(LTQ_MAPI_Firewall_Config *fwl_config)
{
	/* ref: mapi_get_url_entry */

	GI(PREFIX_FIREWALL_CONFIG "_cpeId", fwl_config->iid.cpeId.Id, FILE_RC_CONF, TAG_FIREWALL_CONFIG, NULL);
	GI(PREFIX_FIREWALL_CONFIG "_pcpeId", fwl_config->iid.pcpeId.Id, FILE_RC_CONF, TAG_FIREWALL_CONFIG, NULL);
	GI(PREFIX_FIREWALL_CONFIG "_Enable", fwl_config->Enable, FILE_RC_CONF, TAG_FIREWALL_CONFIG, NULL);
	GI(PREFIX_FIREWALL_CONFIG "_Config", fwl_config->Config, FILE_RC_CONF, TAG_FIREWALL_CONFIG, NULL);
	GI(PREFIX_FIREWALL_CONFIG "_AdvancedLevel", fwl_config->AdvancedLevel, FILE_RC_CONF, TAG_FIREWALL_CONFIG, NULL);
	GS(PREFIX_FIREWALL_CONFIG "_Type", fwl_config->Type, FILE_RC_CONF, TAG_FIREWALL_CONFIG, NULL);
	GS(PREFIX_FIREWALL_CONFIG "_Version", fwl_config->Version, FILE_RC_CONF, TAG_FIREWALL_CONFIG, NULL);
	GI(PREFIX_FIREWALL_CONFIG "_LastChange", fwl_config->LastChange, FILE_RC_CONF, TAG_FIREWALL_CONFIG, NULL);
	GI(PREFIX_FIREWALL_CONFIG "_LevelNumberOfEntries", fwl_config->LevelNumberOfEntries, FILE_RC_CONF, TAG_FIREWALL_CONFIG, NULL);
	GI(PREFIX_FIREWALL_CONFIG "_ChainNumberOfEntries", fwl_config->ChainNumberOfEntries, FILE_RC_CONF, TAG_FIREWALL_CONFIG, NULL);
	return fwl_config;	
}

LTQ_MAPI_Firewall_Config * __mapi_set_firewall_config(LTQ_MAPI_Firewall_Config *fwl_config, uint32 flags)
{
	int32 ret = IFX_SUCCESS;
	char8 buf[2048];

	NULL_TERMINATE(buf, 0, sizeof(buf));

	flags |= IFX_F_MODIFY;

	if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		if ((IFX_INT_ADD_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
			firewall6_dbg("Invalid flag\n");
			return NULL;
		}
		if(flags < 0) {
			return NULL;
		}
	}

	SI(buf, PREFIX_FIREWALL_CONFIG"_cpeId", 0);
	SI(buf, PREFIX_FIREWALL_CONFIG"_pcpeId", 0);
	SI(buf, PREFIX_FIREWALL_CONFIG"_Enable", fwl_config->Enable);
	SI(buf, PREFIX_FIREWALL_CONFIG"_Config", fwl_config->Config);
	SI(buf, PREFIX_FIREWALL_CONFIG"_AdvancedLevel", fwl_config->AdvancedLevel);
	SS(buf, PREFIX_FIREWALL_CONFIG"_Type", fwl_config->Type);
	SS(buf, PREFIX_FIREWALL_CONFIG"_Version", fwl_config->Version);
	SI(buf, PREFIX_FIREWALL_CONFIG"_LastChange", (int )fwl_config->LastChange);
	SI(buf, PREFIX_FIREWALL_CONFIG"_LevelNumberOfEntries", fwl_config->LevelNumberOfEntries);
	SI(buf, PREFIX_FIREWALL_CONFIG"_ChainNumberOfEntries", fwl_config->ChainNumberOfEntries);


	ret = ifx_SetObjData(FILE_RC_CONF, TAG_FIREWALL_CONFIG, flags, 1, buf);

	if (ret != IFX_SUCCESS) {
		firewall6_dbg("Unable to write\n");
		return NULL;
	}
	return fwl_config;
}

LTQ_MAPI_Firewall_Config * mapi_set_firewall_config(LTQ_MAPI_Firewall_Config *fwl_config)
{
	return  __mapi_set_firewall_config(fwl_config, IFX_F_MODIFY);
}

LTQ_MAPI_Firewall_Level * mapi_get_firewall_level(LTQ_MAPI_Firewall_Level *fwl_level, int32 index)
{
	char8  outbuf[MAX_FILELINE_LEN]={0};
	int32  outflag = IFX_F_DEFAULT;

	ltq_get_firewall_level_int_err_ret("cpeId", outbuf, outflag, NULL, fwl_level->iid.cpeId.Id, index);
	ltq_get_firewall_level_int_err_ret("pcpeId", outbuf, outflag, NULL, fwl_level->iid.pcpeId.Id, index);
	ltq_get_firewall_level_int_err_ret("Enable", outbuf, outflag, NULL, fwl_level->Enable, index);
	ltq_get_firewall_level_str_err_ret("Name", outbuf, outflag, NULL, fwl_level->Name, index);
	ltq_get_firewall_level_str_err_ret("Description", outbuf, outflag, NULL, fwl_level->Description, index);
	ltq_get_firewall_level_int_err_ret("Chain", outbuf, outflag, NULL, fwl_level->Chain, index);
	ltq_get_firewall_level_int_err_ret("DefaultPolicy", outbuf, outflag, NULL, fwl_level->DefaultPolicy, index);
	ltq_get_firewall_level_int_err_ret("DefaultLogPolicy", outbuf, outflag, NULL, fwl_level->DefaultLogPolicy, index);
	return fwl_level;	
}

LTQ_MAPI_Firewall_Level * __mapi_set_firewall_level(LTQ_MAPI_Firewall_Level *fwl_level, int32 index, uint32 flags)
{
	int32 ret = IFX_SUCCESS;
	char8 buf[MAX_FILELINE_LEN * 4];
	IFX_NAME_VALUE_PAIR array_fvp[10];
	uint32 count = 0;

	NULL_TERMINATE(buf, 0, sizeof(buf));
	memset(array_fvp, 0, sizeof array_fvp);

	flags |= IFX_F_MODIFY;

	if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		if ((IFX_INT_ADD_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
			firewall6_dbg("Invalid flag\n");
			return NULL;
		}
		if(flags < 0) {
			return NULL;
		}

	}

	sncpy(fwl_level->iid.cpeId.secName, TAG_FIREWALL_LEVEL);
	fwl_level_fill_array_fvp_field_val_int("cpeId", index, index);
	fwl_level_fill_array_fvp_field_val_int("pcpeId", index, index);
	fwl_level_fill_array_fvp_field_val_int("Enable", fwl_level->Enable, index);
	fwl_level_fill_array_fvp_field_val_str("Name", fwl_level->Name, index);
	fwl_level_fill_array_fvp_field_val_str("Description", fwl_level->Description, index);
	fwl_level_fill_array_fvp_field_val_int("Chain", fwl_level->Chain, index);
	fwl_level_fill_array_fvp_field_val_int("PortMappingEnabled", fwl_level->PortMappingEnabled, index);
	fwl_level_fill_array_fvp_field_val_int("DefaultPolicy", fwl_level->DefaultPolicy, index);
	fwl_level_fill_array_fvp_field_val_int("DefaultLogPolicy", fwl_level->DefaultLogPolicy, index);

	form_cfgdb_buf(buf, count, array_fvp);

	ret = ifx_SetObjData(FILE_RC_CONF, TAG_FIREWALL_LEVEL, flags, 1, buf);

	if (ret != IFX_SUCCESS) {
		firewall6_dbg("Unable to write\n");
		return NULL;
	}
	return fwl_level;
}

LTQ_MAPI_Firewall_Level * mapi_set_firewall_level(LTQ_MAPI_Firewall_Level *fwl_level, int32 index)
{

	return  __mapi_set_firewall_level(fwl_level, index, IFX_F_MODIFY);
}


LTQ_MAPI_Firewall_Chain * mapi_get_firewall_chain(LTQ_MAPI_Firewall_Chain *fwl_chain, int32 index)
{
	char8  outbuf[MAX_FILELINE_LEN]={0};
	int32  outflag = IFX_F_DEFAULT;

	ltq_get_firewall_chain_int_err_ret("cpeId", outbuf, outflag, NULL, fwl_chain->iid.cpeId.Id, index);
	ltq_get_firewall_chain_int_err_ret("pcpeId", outbuf, outflag, NULL, fwl_chain->iid.pcpeId.Id, index);
	ltq_get_firewall_chain_int_err_ret("Enable", outbuf, outflag, NULL, fwl_chain->Enable, index);
	ltq_get_firewall_chain_str_err_ret("Name", outbuf, outflag, NULL, fwl_chain->Name, index);
	ltq_get_firewall_chain_str_err_ret("Creator", outbuf, outflag, NULL, fwl_chain->Creator, index);
	ltq_get_firewall_chain_int_err_ret("RuleNumberOfEntries", outbuf, outflag, NULL, fwl_chain->RuleNumberOfEntries, index);
	return fwl_chain;	
}

LTQ_MAPI_Firewall_Chain * __mapi_set_firewall_chain(LTQ_MAPI_Firewall_Chain *fwl_chain, int32 index, uint32 flags)
{
	int32 ret = IFX_SUCCESS;
	char8 buf[MAX_FILELINE_LEN * 4];
	IFX_NAME_VALUE_PAIR array_fvp[10];
	uint32 count = 0;

	NULL_TERMINATE(buf, 0, sizeof(buf));
	memset(array_fvp, 0, sizeof array_fvp);

	flags |= IFX_F_MODIFY;

	if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		if ((IFX_INT_ADD_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
			firewall6_dbg("Invalid flag\n");
			return NULL;
		}
		if(flags < 0) {
			return NULL;
		}

	}

	sncpy(fwl_chain->iid.cpeId.secName, TAG_FIREWALL_CHAIN);
	fwl_chain_fill_array_fvp_field_val_int("cpeId", index, index);
	fwl_chain_fill_array_fvp_field_val_int("pcpeId", index, index);
	fwl_chain_fill_array_fvp_field_val_int("Enable", fwl_chain->Enable, index);
	fwl_chain_fill_array_fvp_field_val_str("Name", fwl_chain->Name, index);
	fwl_chain_fill_array_fvp_field_val_str("Creator", fwl_chain->Creator, index);
	fwl_chain_fill_array_fvp_field_val_int("RuleNumberOfEntries", fwl_chain->RuleNumberOfEntries, index);

	form_cfgdb_buf(buf, count, array_fvp);

	ret = ifx_SetObjData(FILE_RC_CONF, TAG_FIREWALL_CHAIN, flags, 1, buf);

	if (ret != IFX_SUCCESS) {
		firewall6_dbg("Unable to write\n");
		return NULL;
	}
	return fwl_chain;
}

LTQ_MAPI_Firewall_Chain * mapi_set_firewall_chain(LTQ_MAPI_Firewall_Chain *fwl_chain, int32 index)
{
	return __mapi_set_firewall_chain(fwl_chain, index, IFX_F_MODIFY);
}

LTQ_MAPI_Firewall_Rule * mapi_get_firewall_rule(LTQ_MAPI_Firewall_Rule *fwl_rule, int32 index)
{
	char8  outbuf[MAX_FILELINE_LEN]={0};
	int32  outflag = IFX_F_DEFAULT;


	ltq_get_firewall_rule_int_err_ret("cpeId", outbuf, outflag, NULL, fwl_rule->iid.cpeId.Id, index);
	ltq_get_firewall_rule_int_err_ret("pcpeId", outbuf, outflag, NULL, fwl_rule->iid.pcpeId.Id, index);
	ltq_get_firewall_rule_int_err_ret("Enable", outbuf, outflag, NULL, fwl_rule->Enable, index);
	ltq_get_firewall_rule_int_err_ret("Status", outbuf, outflag, NULL, fwl_rule->Status, index);
	ltq_get_firewall_rule_str_err_ret("Target", outbuf, outflag, NULL, fwl_rule->Target, index);
	ltq_get_firewall_rule_int_err_ret("Log", outbuf, outflag, NULL, fwl_rule->Log, index);
	ltq_get_firewall_rule_str_err_ret("SourceInterface", outbuf, outflag, NULL, fwl_rule->SourceInterface, index);
	ltq_get_firewall_rule_int_err_ret("SourceInterfaceExclude", outbuf, outflag, NULL, fwl_rule->SourceInterfaceExclude, index);
	ltq_get_firewall_rule_str_err_ret("DestInterface", outbuf, outflag, NULL, fwl_rule->DestInterface, index);
	ltq_get_firewall_rule_int_err_ret("DestInterfaceExclude", outbuf, outflag, NULL, fwl_rule->DestInterfaceExclude, index);
	ltq_get_firewall_rule_int_err_ret("IPVersion", outbuf, outflag, NULL, fwl_rule->IPVersion, index);
	ltq_get_firewall_rule_str_err_ret("DestIP", outbuf, outflag, NULL, fwl_rule->DestIP, index);
	ltq_get_firewall_rule_int_err_ret("DestMask", outbuf, outflag, NULL, fwl_rule->DestMask, index);
	ltq_get_firewall_rule_int_err_ret("DestIPExclude", outbuf, outflag, NULL, fwl_rule->DestIPExclude, index);
	ltq_get_firewall_rule_str_err_ret("SourceIP", outbuf, outflag, NULL, fwl_rule->SourceIP, index);
	ltq_get_firewall_rule_int_err_ret("SourceMask", outbuf, outflag, NULL, fwl_rule->SourceMask, index);
	ltq_get_firewall_rule_int_err_ret("SourceIPExclude", outbuf, outflag, NULL, fwl_rule->SourceIPExclude, index);
	ltq_get_firewall_rule_int_err_ret("Protocol", outbuf, outflag, NULL, fwl_rule->Protocol, index);
	ltq_get_firewall_rule_int_err_ret("ProtocolExclude", outbuf, outflag, NULL, fwl_rule->ProtocolExclude, index);
	ltq_get_firewall_rule_int_err_ret("DestPort", outbuf, outflag, NULL, fwl_rule->DestPort, index);
	ltq_get_firewall_rule_int_err_ret("DestPortRangeMax", outbuf, outflag, NULL, fwl_rule->DestPortRangeMax, index);
	ltq_get_firewall_rule_int_err_ret("DestPortExclude", outbuf, outflag, NULL, fwl_rule->DestPortExclude, index);
	ltq_get_firewall_rule_int_err_ret("SourcePort", outbuf, outflag, NULL, fwl_rule->SourcePort, index);
	ltq_get_firewall_rule_int_err_ret("SourcePortRangeMax", outbuf, outflag, NULL, fwl_rule->SourcePortRangeMax, index);
	ltq_get_firewall_rule_int_err_ret("SourcePortExclude", outbuf, outflag, NULL, fwl_rule->SourcePortExclude, index);
	return fwl_rule;	
}



int32 ifx_mapi_set_firewall_rule_ng(int32 operation, LTQ_MAPI_Firewall_Rule * fwl_rule, uint32 flags)
{
	char8 conf_buf[MAX_DATA_LEN];
	int32 count = 0, passed_index = -1, ret =
	    IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR  *array_changed_fvp = NULL;
	char8 *retStr = NULL;
	//int num_entries = 0; 
	LTQ_MAPI_Firewall_Rule *firewallRules = NULL;
	char ifName[IFNAMSIZE];
	static IFX_NAME_VALUE_PAIR array_fvp[25];

	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
	NULL_TERMINATE(ifName, 0x00, sizeof(ifName));
	memset(array_fvp, 0x00, sizeof(array_fvp));

	/*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY)
	 * append the flag with internal flags */

	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

	/**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */

	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(fwl_rule)
		    /* Do simple validation of flags such as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)

	}
	strcpy(fwl_rule->iid.cpeId.secName, TAG_FIREWALL_RULE);
	strcpy(fwl_rule->iid.pcpeId.secName, TAG_FIREWALL_RULE);
	fwl_rule->iid.pcpeId.Id = 1;

	/**************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_ADD_F_SET(flags)) {
		fwl_rule->iid.cpeId.Id = 0;
		/* Allocate the IID for this route instance
		 * Set the parent SectionName and parent IID values
		 * to NULL as there is no parent for Route Entity
		 */
		/* if (ifx_get_IID(&fwl_rule->iid, "enable") != IFX_SUCCESS) { */
		if(ifx_get_IID_Without_TR69(&fwl_rule->iid, "DestIP") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	/**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given structure for ADD/MODIFY
	 * Operations
	 */
	if (IFX_DELETE_F_NOT_SET(flags)) {
		sncpy(fwl_rule->iid.cpeId.secName, TAG_FIREWALL_RULE);
		fwl_rule_fill_array_fvp_field_val_int("cpeId",  fwl_rule->iid.cpeId.Id ); 
		fwl_rule_fill_array_fvp_field_val_int("pcpeId", 1);
		fwl_rule_fill_array_fvp_field_val_int("Enable", fwl_rule->Enable);
		fwl_rule_fill_array_fvp_field_val_int("Status", fwl_rule->Status);
		fwl_rule_fill_array_fvp_field_val_str("Target", fwl_rule->Target);
		fwl_rule_fill_array_fvp_field_val_int("Log",  fwl_rule->Log);
		fwl_rule_fill_array_fvp_field_val_str("SourceInterface",  fwl_rule->SourceInterface);
		fwl_rule_fill_array_fvp_field_val_int("SourceInterfaceExclude",  fwl_rule->SourceInterfaceExclude);
		fwl_rule_fill_array_fvp_field_val_str("DestInterface",  fwl_rule->DestInterface);
		fwl_rule_fill_array_fvp_field_val_int("DestInterfaceExclude", fwl_rule->DestInterfaceExclude);
		fwl_rule_fill_array_fvp_field_val_int("IPVersion", fwl_rule->IPVersion);
		fwl_rule_fill_array_fvp_field_val_str("DestIP", fwl_rule->DestIP);
		fwl_rule_fill_array_fvp_field_val_int("DestMask", fwl_rule->DestMask);
		fwl_rule_fill_array_fvp_field_val_int("DestIPExclude", fwl_rule->DestIPExclude);
		fwl_rule_fill_array_fvp_field_val_str("SourceIP", fwl_rule->SourceIP);
		fwl_rule_fill_array_fvp_field_val_int("SourceMask", fwl_rule->SourceMask);
		fwl_rule_fill_array_fvp_field_val_int("SourceIPExclude", fwl_rule->SourceIPExclude);
		fwl_rule_fill_array_fvp_field_val_int("Protocol", fwl_rule->Protocol);
		fwl_rule_fill_array_fvp_field_val_int("ProtocolExclude", fwl_rule->ProtocolExclude);
		fwl_rule_fill_array_fvp_field_val_int("DestPort", fwl_rule->DestPort);
		fwl_rule_fill_array_fvp_field_val_int("DestPortRangeMax", fwl_rule->DestPortRangeMax);
		fwl_rule_fill_array_fvp_field_val_int("DestPortExclude", fwl_rule->DestPortExclude);
		fwl_rule_fill_array_fvp_field_val_int("SourcePort", fwl_rule->SourcePort);
		fwl_rule_fill_array_fvp_field_val_int("SourcePortRangeMax", fwl_rule->SourcePortRangeMax);
		fwl_rule_fill_array_fvp_field_val_int("SourcePortExclude", fwl_rule->SourcePortExclude);
	}
	count = 25;

	/* Get Config Index in case of modify/delete operations from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, fwl_rule->iid.cpeId, passed_index)

		    /* Now inoder to modify or delete the fwl_rule, we should be deleting
		     * the firewall fwl_rule from the PF Chains */
		    //num_entries = 0;

		    /* mapi_get_int(TAG_FIREWALL_RULE"_Count", &num_entries, sizeof(num_entries), FILE_RC_CONF, TAG_FIREWALL_RULE); */
	}


	/* Determine the configuration index - for Add, Delete, Modify operations
	 * Name is partial since index is not known
	 * Fill array_fvp[] */
	if (ifx_get_conf_index_and_nv_pairs
	    (&fwl_rule->iid, passed_index, TAG_FIREWALL_RULE, count,
	     array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	/************** System Config File Update Block ****************/

	/* Backup rc.conf before proceeding with configuration */
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);


	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_FIREWALL_RULE, flags, 1, conf_buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] for conf_buf [%s] ret [%d]", __FUNCTION__,
			__LINE__, conf_buf, ret);
#endif
		goto IFX_Handler;
	}

	/* This will Compact the section and also update the count for both ADD and DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags)) {
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_FIREWALL_RULE, flags);
	}

	if (IFX_INT_ADD_F_SET(flags)) {
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_FIREWALL_RULE);
	}

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(retStr)
	    IFX_MEM_FREE(firewallRules)
	    IFX_MEM_FREE(array_changed_fvp)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
		return ret;
	} else
	return IFX_SUCCESS;
}

LTQ_MAPI_Firewall_Rule * mapi_set_firewall_rule(LTQ_MAPI_Firewall_Rule *fwl_rule, int32 index)
{
	
	int ret;
	
 	ret = ifx_mapi_set_firewall_rule_ng(IFX_OP_MOD, fwl_rule, IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT);
	if ( ret != IFX_SUCCESS)
		return NULL;
	else
		return fwl_rule;
}

LTQ_MAPI_Firewall_Rule * mapi_set_firewall_rule_add(LTQ_MAPI_Firewall_Rule *fwl_rule, int32 index)
{
	int ret;
	
 	ret = ifx_mapi_set_firewall_rule_ng(IFX_OP_ADD, fwl_rule, IFX_F_INT_ADD | IFX_F_DONT_CHECKPOINT);
	if ( ret != IFX_SUCCESS)
		return NULL;
	else
		return fwl_rule;

	
}

LTQ_MAPI_Firewall_Rule * mapi_set_firewall_rule_del(LTQ_MAPI_Firewall_Rule *fwl_rule, int32 index)
{
	int ret;
	
 	ret = ifx_mapi_set_firewall_rule_ng(IFX_OP_DEL, fwl_rule, IFX_F_DELETE | IFX_F_DONT_CHECKPOINT);

	if ( ret != IFX_SUCCESS)
		return NULL;
	else
		return fwl_rule;

}
#endif
