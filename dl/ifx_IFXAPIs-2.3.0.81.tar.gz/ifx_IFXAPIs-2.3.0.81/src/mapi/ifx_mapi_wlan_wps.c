/******************************************************************************

                               Copyright (c) 2008
                            Infineon Technologies AG
                     Am Campeon 1-12; 81726 Munich, Germany

  THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED NON-EXCLUSIVE,
  WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE AND SUBLICENSE THIS
  SOFTWARE IS FREE OF CHARGE.

  THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY DISCLAIMS
  ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR IMPLIED, INCLUDING
  WITHOUT LIMITATION, WARRANTIES OR REPRESENTATIONS OF WORKMANSHIP,
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, DURABILITY, THAT THE
  OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR FREE OR FREE OF ANY THIRD
  PARTY CLAIMS, INCLUDING WITHOUT LIMITATION CLAIMS OF THIRD PARTY INTELLECTUAL
  PROPERTY INFRINGEMENT.

  EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND EXCEPT
  FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE FOR ANY CLAIM
  OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
  ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
  DEALINGS IN THE SOFTWARE.

******************************************************************************/

/**
   \file ifx_mapi_wlan_wps.c
*/

#if defined (CONFIG_FEATURE_IFX_WIRELESS)
/* ========================================================================== */
/*                                 Includes                                   */
/* ========================================================================== */
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"

/* included for definition of bool */
#include "ifx_api_ipt_common.h"
/* ========================================================================== */
/*                             Macro definitions                              */
/* ========================================================================== */

/* ========================================================================== */
/*                             Type definitions                               */
/* ========================================================================== */

/* ========================================================================== */
/*                             Global variables                               */
/* ========================================================================== */
IFX_MAPI_WLAN_WPS_Cfg 			g_wlWpsConfig[LTQ_MAX_NUM_VAP];
int								g_flagWpsConfig = 0;
int								g_wpsState[LTQ_MAX_NUM_VAP];
LTQ_MAPI_WLAN_WPS_EP_MAC_Cfg	g_wlWpsEpMacAllConfig[160];
int								g_flagWpsEpMacAllConfig = 0;
int								g_nEpMacAll = 0;
extern int 						g_nVap;
extern IFX_MAPI_WLAN_MainCfg g_wlMain[];

char8 *wlan_wps_params[] =
    { "cpeId", "pcpeId", "enable", "enrolleeEna", "proxyEna",
	"intRegsEna", "apDevName", "PIN", "cfgMthds",
	"setupLock", "cfgState", "maxPinLockout"
};

char8 *wlan_wps_regs_params[] = { "cpeId", "pcpeId", "enable", "regDevName" };

char8 *wlan_wps_ep_mac_params[] = { "cpeId", "pcpeId", "macAddr" };
/* ========================================================================== */
/*                           Function prototypes                              */
/* ========================================================================== */
static bool mapiWlanChkWpsCfgChg(int32 idx, IFX_MAPI_WLAN_WPS_Cfg * wlWpsCfg);

/* ========================================================================== */
/*                         Function implementation                            */
/* ========================================================================== */

/**
   \param   wlWpsCfg - pointer to IFX_MAPI_WLAN_WPS_Cfg structure

   \return
      TRUE or FALSE

   \remarks -  checks all parameters of WPS configuration for change
   	   	   	   returns TRUE if one or more parameter changed
   	   	   	   returns FALSE if no parameter changed
*/
static bool mapiWlanChkWpsCfgChg(int32 idx, IFX_MAPI_WLAN_WPS_Cfg * wlWpsCfg)
{
	IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkWpsCfgChg", "idx: %d", idx);

	if (wlWpsCfg->enable != g_wlWpsConfig[idx].enable) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkWpsCfgChg", "");
		return TRUE;
	}

	if (wlWpsCfg->enrolleeEna != g_wlWpsConfig[idx].enrolleeEna) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkWpsCfgChg", "");
		return TRUE;
	}

	if (wlWpsCfg->proxyEna != g_wlWpsConfig[idx].proxyEna) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkWpsCfgChg", "");
		return TRUE;
	}

	if (wlWpsCfg->intRegEna != g_wlWpsConfig[idx].intRegEna) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkWpsCfgChg", "");
		return TRUE;
	}

	if (strcmp(wlWpsCfg->apWpsName, g_wlWpsConfig[idx].apWpsName)) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkWpsCfgChg", "");
		return TRUE;
	}

	if (wlWpsCfg->setupLockedState != g_wlWpsConfig[idx].setupLockedState) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkWpsCfgChg", "");
		return TRUE;
	}

	if (wlWpsCfg->maxPinLockout != g_wlWpsConfig[idx].maxPinLockout) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkWpsCfgChg", "");
		return TRUE;
	}

	return FALSE;
}

/*//////////////////////////////////////////////////////////////////////////////
* ltq_mapi_get_wps_config_state(...)
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads the wps config state from script.
*/// ///////////////////////////////////////////////////////////////////////////
int32 ltq_mapi_get_wps_config_state(uint32 mainCpeId)
{
	int32 wpsCfgState = IFX_MAPI_WPS_NOT_CONFIGURED;
	int32 ret = IFX_SUCCESS;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	uint32 outFlag = IFX_F_DEFAULT;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wps_config_state",
		"mainCpeId: %d", mainCpeId);
	/* WPS is only enabled on first AP */
	if (mainCpeId > 1) {
		return IFX_MAPI_WPS_NOT_CONFIGURED;
	} else {
		/* get global mode */
		sprintf(buf, "%s%d_0_cfgState", PREFIX_WLAN_WPS, mainCpeId);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_WPS, buf, IFX_F_DEFAULT,
			&outFlag, sValue)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wps_config_state", "");
			return IFX_MAPI_WPS_NOT_CONFIGURED;
		}
		wpsCfgState = atoi(sValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wps_config_state",
			"wpsCfgState: %d", wpsCfgState);
		return wpsCfgState;
	}
}

/**
   This api reads the count, gets the complete wlan_wps object and saves
   the configuration to g_wlWpsConfig

   \param   numEntries  -

   \param   wlWpsCfg - pointer to IFX_MAPI_WLAN_WPS_Cfg structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ltq_mapi_get_all_wlan_wps_config(uint32 *numEntries,
		IFX_MAPI_WLAN_WPS_Cfg ** wlWpsCfg, uint32 flags)
{
	int32 ret = IFX_SUCCESS, nCount = 0, i = 0, j = 0, nParamCount = 0;
	char8 sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN];
	char8 *sWlanWpsObject = NULL, *tok = NULL;
	uint32 outFlag = IFX_F_DEFAULT;
	IFX_NAME_VALUE_PAIR	array_fvp[LTQ_MAX_NUM_VAP*WLAN_WPS_PARAM_COUNT];
	IFX_MAPI_WLAN_Capability wlCaps;
	IFX_MAPI_WLAN_MainCfg	*wlMain = NULL;
	uint32	nVap = 0;

	LTQ_LOG_TIMESTAMP();

	MAKE_SECTION_COUNT_TAG(TAG_WLAN_WPS, buf);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_WPS, buf, flags, &outFlag,
		sValue)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_config", "");
			goto IFX_Handler;
	}

	nCount = atoi(sValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_config", "nCount: %d",
		nCount);

	if (nCount <= 0) {
		*numEntries = 0;
		*wlWpsCfg = NULL;
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_config", "");
		goto IFX_Handler;
	}

	*wlWpsCfg = NULL;
	if (nCount <= LTQ_MAX_NUM_VAP) {
		IFX_MEM_ALLOC((*wlWpsCfg), IFX_MAPI_WLAN_WPS_Cfg *, nCount,
			sizeof(IFX_MAPI_WLAN_WPS_Cfg))
	} else {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* if configuration is already available, return immediately */
	if (g_flagWpsConfig) {
		memcpy(*wlWpsCfg, g_wlWpsConfig,
			sizeof(IFX_MAPI_WLAN_WPS_Cfg) * nCount);
		goto IFX_Handler;
	}

	/*
	 * determine the supported capabilites
	*/
	if (ifx_mapi_get_wlan_capability(&wlCaps, IFX_F_DEFAULT) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_config", "");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	if (ifx_mapi_get_all_wlan_main_config(&nVap, &wlMain,
		IFX_F_DEFAULT) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_config", "");
			goto IFX_Handler;
	}

	sprintf(buf, "%s", PREFIX_WLAN_WPS);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_config", "buf: %s",
		buf);
	if ((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_WPS, buf, IFX_F_DEFAULT,
		&sWlanWpsObject)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_config", "");
			goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_config",
		"sWlanWpsObject: %s", sWlanWpsObject);

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sWlanWpsObject, &nParamCount, array_fvp);

	for (i = 0; i < nCount; i++) {
		sprintf((*wlWpsCfg + i)->iid.cpeId.secName, "%s", TAG_WLAN_WPS);
		sprintf((*wlWpsCfg + i)->iid.pcpeId.secName, "%s", TAG_WLAN_SEC);
		(*wlWpsCfg + i)->iid.cpeId.Id 	= atoi(array_fvp[i * WLAN_WPS_PARAM_COUNT].value);
		(*wlWpsCfg + i)->iid.pcpeId.Id 	= atoi(array_fvp[i * WLAN_WPS_PARAM_COUNT + 1].value);
		(*wlWpsCfg + i)->enable 		= atoi(array_fvp[i * WLAN_WPS_PARAM_COUNT + 2].value);
		(*wlWpsCfg + i)->enrolleeEna 	= atoi(array_fvp[i * WLAN_WPS_PARAM_COUNT + 3].value);
		(*wlWpsCfg + i)->proxyEna 		= atoi(array_fvp[i * WLAN_WPS_PARAM_COUNT + 4].value);
		(*wlWpsCfg + i)->intRegEna 		= atoi(array_fvp[i * WLAN_WPS_PARAM_COUNT + 5].value);

		if (strlen(array_fvp[i * WLAN_WPS_PARAM_COUNT + 6].value) <=
			IFX_MAPI_WPS_DEV_NAME_LEN - 1) {
				snprintf((*wlWpsCfg + i)->apWpsName, IFX_MAPI_WPS_DEV_NAME_LEN,
					"%s", array_fvp[i * WLAN_WPS_PARAM_COUNT + 6].value);
		} else {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_config",
				"WPS name too long: %d",
				strlen(array_fvp[i * WLAN_WPS_PARAM_COUNT + 6].value));
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}

		if (ltq_mapi_get_wlan_vendor(wlMain[i].radioCpeId, IFX_F_DEFAULT) ==
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			(*wlWpsCfg + i)->apWpsPin		= atoi(array_fvp[i * WLAN_WPS_PARAM_COUNT + 7].value);
			(*wlWpsCfg + i)->setupLock		= atoi(array_fvp[i * WLAN_WPS_PARAM_COUNT + 9].value);
			(*wlWpsCfg + i)->cfgState		= atoi(array_fvp[i * WLAN_WPS_PARAM_COUNT + 10].value);
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_config",
				"cfgState: %d", (*wlWpsCfg + i)->cfgState);
		}
		(*wlWpsCfg + i)->maxPinLockout	= atoi(array_fvp[i * WLAN_WPS_PARAM_COUNT + 11].value);

		/* store comma separated list in sValue */
		strcpy(sValue, array_fvp[i * WLAN_WPS_PARAM_COUNT + 8].value);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_config", "sValue: %s", sValue);
		j = 0;
		tok = strtok(sValue,",");
		do {
			if (tok == NULL) {
				IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_config", "");
				break;
			}
			if(!strcmp(tok,"1"))
				(*wlWpsCfg + i)->enaCfgMethods[j++] = IFX_MAPI_WPS_USB_FLASH_DRIVE;
			else if(!strcmp(tok,"2"))
				(*wlWpsCfg + i)->enaCfgMethods[j++] = IFX_MAPI_WPS_ETHERNET;
			else if(!strcmp(tok,"3"))
				(*wlWpsCfg + i)->enaCfgMethods[j++] = IFX_MAPI_WPS_LABEL;
			else if(!strcmp(tok,"4"))
				(*wlWpsCfg + i)->enaCfgMethods[j++] = IFX_MAPI_WPS_DISPLAY;
			else if(!strcmp(tok,"5"))
				(*wlWpsCfg + i)->enaCfgMethods[j++] = IFX_MAPI_WPS_EXTERNAL_NFC_TOKEN;
			else if(!strcmp(tok,"6"))
				(*wlWpsCfg + i)->enaCfgMethods[j++] = IFX_MAPI_WPS_INTEGRATED_NFC_TOKEN;
			else if(!strcmp(tok,"7"))
				(*wlWpsCfg + i)->enaCfgMethods[j++] = IFX_MAPI_WPS_NFC_INTERFACE;
			else if(!strcmp(tok,"8"))
				(*wlWpsCfg + i)->enaCfgMethods[j++] = IFX_MAPI_WPS_PUSH_BUTTON;
			else if(!strcmp(tok,"9"))
				(*wlWpsCfg + i)->enaCfgMethods[j++] = IFX_MAPI_WPS_KEY_PAD;
			else {
				IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_config", "");
				j++;
			}
                                
			tok = strtok(NULL,", ");
		} while (j <= IFX_MAPI_WPS_MAX_CFG_METHODS);

		/* take supported cfg methods from capabilities */
		for (j = 0; j < IFX_MAPI_WPS_MAX_CFG_METHODS; j++) {
			if (wlCaps.WPSMthdsArray[j] == 0xFF) {
				(*wlWpsCfg + i)->suppCfgMethods[j] = 0;
				break;
			}
			else
				(*wlWpsCfg + i)->suppCfgMethods[j] = wlCaps.WPSMthdsArray[j];
		}
		for (j = 0; j < IFX_MAPI_WPS_MAX_CFG_METHODS; j++)
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_config",
				"enaCfg[%d]: %d\nsuppCfg[%d]: %d",
				j, (*wlWpsCfg + i)->enaCfgMethods[j],
				j, (*wlWpsCfg + i)->suppCfgMethods[j]);
	}

	*numEntries = nCount;
	/* store in global variable for later usage */
	memcpy(g_wlWpsConfig, *wlWpsCfg, sizeof(IFX_MAPI_WLAN_WPS_Cfg) * nCount);
	g_flagWpsConfig = 1;
	g_nVap = nCount;

IFX_Handler:
	IFX_MEM_FREE(sWlanWpsObject);
	IFX_MEM_FREE(wlMain);
	/* free memory in case of error, otherwise it gets freed in calling function */
	if (ret != IFX_SUCCESS)
		IFX_MEM_FREE(*wlWpsCfg)

	LTQ_LOG_TIMESTAMP();
	return ret;
}

/**
   This api reads wlan wps parameters from rc.conf and returns them in wlWps

   \param   wlWps - pointer to IFX_MAPI_WLAN_WPS_Cfg structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_wps_config(IFX_MAPI_WLAN_WPS_Cfg * wlWps, uint32 flags)
{
	int32 ret = IFX_SUCCESS, apIdx = -1;
	char8 *sValue = NULL;
	IFX_MAPI_WLAN_WPS_Cfg *wlWpsAll = NULL;
	uint32	numEntries = 0;
	char8 sWpsDynInfo[MAX_DATA_LEN], sWpsDynTmp[MAX_DATA_LEN];
	char8 *pTmpStr = NULL, *pTmpStr2, buf[MAX_DATA_LEN];
	IFX_MAPI_WLAN_MainCfg	*wlMain = NULL;

	LTQ_LOG_TIMESTAMP();

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig",
		"g_flagWpsConfig: %d", g_flagWpsConfig);
	if (!g_flagWpsConfig) {
		if (ltq_mapi_get_all_wlan_wps_config(&numEntries, &wlWpsAll,
			IFX_F_DEFAULT) != IFX_SUCCESS) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "");
				goto IFX_Handler;
		}
		/*
		 * get index from pcpeid, we need the index of the AP, i.e. the
		 * configuration index of the parent object (wlan_main), therefore we use
		 * the pcpeId here
		 */
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlWps->iid.pcpeId, apIdx)
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "apIdx: %d", apIdx);
		memcpy(wlWps, &g_wlWpsConfig[apIdx], sizeof(IFX_MAPI_WLAN_WPS_Cfg));
	} else {
		/*
		 * get index from pcpeid, we need the index of the AP, i.e. the
		 * configuration index of the parent object (wlan_main), therefore we use
		 * the pcpeId here
		 */
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlWps->iid.pcpeId, apIdx)
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "apIdx: %d", apIdx);
		memcpy(wlWps, &g_wlWpsConfig[apIdx], sizeof(IFX_MAPI_WLAN_WPS_Cfg));
		if (wlWps->cfgState == IFX_MAPI_WPS_NOT_CONFIGURED)
			wlWps->cfgState = ltq_mapi_get_wps_config_state(wlWps->iid.pcpeId.Id);
	}
	IFX_MEM_FREE(wlWpsAll);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "");

	/*
	 * get the dynamic information if wps is enabled: - UUID - WPS version -
	 * Setup Locked Stated - Config State - last config error
	 */
	if (wlWps->enable == TRUE) {
		NULL_TERMINATE(buf, 0x00, sizeof(buf));
		memset(sWpsDynInfo, 0x00, sizeof(sWpsDynInfo));
		sprintf(buf, "%s %d", SERVICE_WLAN_GET_WPS_DYN_INFO, apIdx);

		/* get dynamic WPS information */
		if (ifx_GetCfgData((char8 *) buf, NULL, "-1", sWpsDynInfo) == 0) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "sWpsDynInfo: %s",
			sWpsDynInfo);

		/* save buffer in sWpsDynTmp */
		strcpy(sWpsDynTmp, sWpsDynInfo);

		/* get UUID information */
		if ((pTmpStr = strstr(sWpsDynInfo, "UUID=")) != NULL) {
			pTmpStr2 = strtok(pTmpStr, "\"");
			if (pTmpStr2 != NULL) {
				pTmpStr2 = strtok(NULL, "\"");
				if (pTmpStr2 == NULL) {
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}
				strcpy(wlWps->uuidAp, pTmpStr2);
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "uuidAp: %s",
					wlWps->uuidAp);
			}
		} else
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig",
				       "sWpsDynInfo: %s", sWpsDynInfo);

		/* restore sValue buffer from sValueTmp */
		strcpy(sWpsDynInfo, sWpsDynTmp);
	}

	if (ifx_mapi_get_all_wlan_main_config(&numEntries, &wlMain,
		IFX_F_DEFAULT) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "");
		goto IFX_Handler;
	}
	if (ltq_mapi_get_wlan_vendor(wlMain[apIdx].radioCpeId, IFX_F_DEFAULT) !=
		LTQ_MAPI_WLAN_VENDOR_WAVE300) {
		if (wlWps->enable == TRUE) {
			/* get status information */
			if ((pTmpStr = strstr(sWpsDynInfo, "configState=")) != NULL) {
				pTmpStr2 = strtok(pTmpStr, "\"");
				if (pTmpStr2 != NULL) {
					pTmpStr2 = strtok(NULL, "\"");
					if (pTmpStr2 == NULL) {
						ret = IFX_FAILURE;
						goto IFX_Handler;
					}
					wlWps->cfgState = atoi(pTmpStr2);
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig",
						"status: %d", wlWps->cfgState);
				}
			} else {
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig",
					"sWpsDynInfo: %s", sWpsDynInfo);
			}
			/* restore sValue buffer from sValueTmp */
			strcpy(sWpsDynInfo, sWpsDynTmp);

			/* get Setup Locked State information */
			if ((pTmpStr = strstr(sWpsDynInfo, "setupLockedState=")) != NULL) {
				pTmpStr2 = strtok(pTmpStr, "\"");
				if (pTmpStr2 != NULL) {
					pTmpStr2 = strtok(NULL, "\"");
					if (pTmpStr2 == NULL) {
						ret = IFX_FAILURE;
						goto IFX_Handler;
					}
					wlWps->setupLockedState = atoi(pTmpStr2);
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig",
						"setupLockedState: %d", wlWps->setupLockedState);
				}
			} else
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig",
						   "sWpsDynInfo: %s", sWpsDynInfo);

			/* restore sValue buffer from sValueTmp */
			strcpy(sWpsDynInfo, sWpsDynTmp);

			/* get Last Config Error information */
			if ((pTmpStr = strstr(sWpsDynInfo, "lastConfigError=")) != NULL) {
				pTmpStr2 = strtok(pTmpStr, "\"");
				if (pTmpStr2 != NULL) {
					pTmpStr2 = strtok(NULL, "\"");
					if (pTmpStr2 == NULL) {
						ret = IFX_FAILURE;
						goto IFX_Handler;
					}
					wlWps->lastConfigError = atoi(pTmpStr2);
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig",
						"lastConfigError: %d", wlWps->lastConfigError);
				}
			} else
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig",
						   "sWpsDynInfo: %s", sWpsDynInfo);
		} else {
			wlWps->cfgState = IFX_MAPI_WPS_NOT_CONFIGURED;
		}

		/* get AP pin */
		NULL_TERMINATE(buf, 0x00, sizeof(buf));
		memset(sWpsDynInfo, 0x00, sizeof(sWpsDynInfo));
		sprintf(buf, "%s %d", SERVICE_WLAN_GET_WPS_PIN, apIdx);

		/* get WPS AP information */
		if (ifx_GetCfgData((char8 *) buf, NULL, "-1", sWpsDynInfo) == 0) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "sWpsDynInfo: %s",
				   sWpsDynInfo);

		/* get status information */
		if ((pTmpStr = strstr(sWpsDynInfo, "PIN=")) != NULL) {
			pTmpStr2 = strtok(pTmpStr, "\"");
			if (pTmpStr2 != NULL) {
				pTmpStr2 = strtok(NULL, "\"");
				if (pTmpStr2 == NULL) {
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}
				wlWps->apWpsPin = atoi(pTmpStr2);
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig",
						   "PIN: %d", wlWps->apWpsPin);
			}
		} else
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig",
					   "sWpsDynInfo: %s", sWpsDynInfo);

		/*
		 * AP has been configured through WPS (cfgState), but this is not yet
		 * reflected in setupLock parameter of wlan_wps object => write back this
		 * configuration now
		 */
		if ((wlWps->enable == TRUE) &&
			(wlWps->cfgState == IFX_MAPI_WPS_CONFIGURED) &&
			(wlWps->setupLock == FALSE)) {
			wlWps->setupLock = TRUE;
			if ((ret = ifx_mapi_set_wlan_wps_config(IFX_OP_MOD, wlWps,
				IFX_F_INT_DONT_CONFIGURE)) != IFX_SUCCESS) {
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig",
						"Setting setupLock failed");
					goto IFX_Handler;
			}
		}
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "ret: %d", ret);
	/* free buffer allocated in ifx_GetCfgObject */
	IFX_MEM_FREE(sValue);
	IFX_MEM_FREE(wlMain);
	LTQ_LOG_TIMESTAMP();
	return ret;
}

/**
   This api gets the confiuration of a wlan wps registrar of one AP/VAP and
   returns the information in wlWpsRegs.

   \param   mainCpeId

   \param   numEntries

   \param   wlWpsRegs - pointer to IFX_MAPI_WLAN_WPS_Regs_Cfg structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE

   \todo check if numEntries can be removed
*/
int32
ifx_mapi_get_wlan_wps_registrar_config(IFX_MAPI_WLAN_WPS_Regs_Cfg * wlWpsRegs,
				       uint32 flags)
{
	int32 ret = IFX_SUCCESS, passed_index = -1, count, i;
	char8 buf[MAX_DATA_LEN], *sValue = NULL;
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_WPS_REGISTRAR_PARAM_COUNT + 1];
	char8 sWpsDynInfo[MAX_DATA_LEN], *pTmpStr = NULL, *pTmpStr2 = NULL;
	IFX_MAPI_WLAN_MainCfg	*wlMain = NULL;
	uint32	nVap = 0;

	LTQ_LOG_TIMESTAMP();

	sprintf(wlWpsRegs->iid.pcpeId.secName, "%s", TAG_WLAN_WPS);
	sprintf(wlWpsRegs->iid.cpeId.secName, "%s", TAG_WLAN_WPS_REGISTRAR);

	/* get index from pcpeid first */
	IFX_GET_INDEX_FROM_PCPEID(FILE_RC_CONF, wlWpsRegs->iid.pcpeId,
				  passed_index)
	    if (passed_index < 0) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsRegsConfig",
			       "passed_index: %d", passed_index);
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	if (ifx_mapi_get_all_wlan_main_config(&nVap, &wlMain,
		IFX_F_DEFAULT) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsRegsConfig", "");
			goto IFX_Handler;
	}
	if (ltq_mapi_get_wlan_vendor(wlMain[passed_index].radioCpeId,
		IFX_F_DEFAULT) == LTQ_MAPI_WLAN_VENDOR_QCA) {
		/*  first get the dynamic information: - UUID */
		NULL_TERMINATE(buf, 0x00, sizeof(buf));
		memset(sWpsDynInfo, 0x00, sizeof(sWpsDynInfo));
		sprintf(buf, "%s %d", SERVICE_WLAN_GET_WPS_REGS_DYN_INFO, passed_index);

		/* get dynamic WPS registrar information */
		if (ifx_GetCfgData((char8 *) buf, NULL, "-1", sWpsDynInfo) == 0) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsRegsConfig", "sWpsDynInfo: %s",
			sWpsDynInfo);

		/* get UUID */
		if ((pTmpStr = strstr(sWpsDynInfo, "UUID=")) != NULL) {
			pTmpStr2 = strtok(pTmpStr, "\"");
			if (pTmpStr2 == NULL) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			pTmpStr2 = strtok(NULL, "\"");
			if (pTmpStr2 == NULL) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			strcpy(wlWpsRegs->uuidRegs, pTmpStr2);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsRegsConfig",
					   "uuidRegs: %s", wlWpsRegs->uuidRegs);
		} else
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsRegsConfig",
					   "sWpsDynInfo: %s", sWpsDynInfo);
	}

	/*
	   the format for wlan_wps_regs object is wlwpsRegs<pCpeId>_<Index>_param
	   for this purpose we are defining the used prefix wlWps<pCpeId> here */
	sprintf(buf, "%s%d_0_", PREFIX_WLAN_WPS_REGS, wlWpsRegs->iid.pcpeId.Id);
	if ((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_WPS_REGISTRAR,
				    buf, IFX_F_DEFAULT, &sValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsRegsConfig",
			       "buf: %s", buf);
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsRegsConfig",
		       "buf: %s, passed_index: %d, sValue: %s",
		       buf, passed_index, sValue);

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsRegsConfig", "count: %d",
		       count);
	for (i = 0; i < count; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsRegsConfig", "%s:%s",
			       array_fvp[i].fieldname, array_fvp[i].value);

	wlWpsRegs->iid.cpeId.Id = atoi(array_fvp[0].value);
	wlWpsRegs->iid.pcpeId.Id = atoi(array_fvp[1].value);
	wlWpsRegs->enable = atoi(array_fvp[2].value);

	if (strlen(array_fvp[3].value) <= IFX_MAPI_WPS_DEV_NAME_LEN - 1) {
		sprintf(wlWpsRegs->regsWpsName, "%s", array_fvp[3].value);
	} else {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsRegsConfig",
			       "WPS registrar name length: %d",
			       strlen(array_fvp[3].value));
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsRegsConfig", "ret: %d", ret);
	/* free buffer allocated in ifx_GetCfgObject */
	IFX_MEM_FREE(sValue);
	IFX_MEM_FREE(wlMain);
	LTQ_LOG_TIMESTAMP();
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return IFX_FAILURE;
	} else
		return IFX_SUCCESS;
}

/**
   This api gets the configuration of all wlan wps registrar of one AP/VAP and
   returns the information in wlWpsRegs.

   \param   mainCpeId

   \param   numEntries

   \param   wlWpsRegs - pointer to array of IFX_MAPI_WLAN_WPS_Regs_Cfg structures

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ifx_mapi_get_all_wlan_wps_registrar_config(uint32 mainCpeId,
					   uint32 * numEntries,
					   IFX_MAPI_WLAN_WPS_Regs_Cfg **
					   wlWpsRegs, uint32 flags)
{
	LTQ_LOG_TIMESTAMP();
	return (IFX_SUCCESS);
}

/**
   This api sets wlan wps parameters available in wlWps

   \param oper

   \param   wlWps - pointer to IFX_MAPI_WLAN_WPS_Cfg structure

   \param flags

   \return
   - IFX_SUCCESS
   - IFX_FAILURE

   \remarks - This API differs a little from the usual set APIs. The format for
              storage in rc.conf is prefix{pcpeid}_<Inst>_param which
              is against conventional prefix_0_param. Therefore the usage
              of the utility functions must be done carefully
*/
int32
ifx_mapi_set_wlan_wps_config(uint32 operation,
			     IFX_MAPI_WLAN_WPS_Cfg * wlWps, uint32 flags)
{
	CPE_ID pCpeId;
	int32 ret = IFX_SUCCESS, count = 0, changed_count = 0;
	char8 conf_buf[MAX_SECTION_DATA_LEN], prefix[MAX_FILELINE_LEN];
	int32 objConfigIdx = -1, apIdx = -1, i = 0;
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_WPS_PARAM_COUNT];
	IFX_NAME_VALUE_PAIR *array_changed_fvp = NULL;
	bool	f_MacFilterDisable = FALSE, f_HiddenSsidDisable = FALSE;
	IFX_MAPI_WLAN_MainCfg wlMain;
	IFX_MAPI_WLAN_SecCfg wlSec;
	LTQ_MAPI_WLAN_Feature	features = LTQ_MAPI_WLAN_FEATURE_NONE;

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");

	/*
	   initalize buffer conf_buf which is used for two purposes: - holding the
	   configuration for wlWps to be written to rc.conf - holding the commands
	   for system calls */
	memset(conf_buf, 0x00, sizeof(conf_buf));
	/*
	   initalize buffer array_fvp which is used for storing the new
	   configuration of wlWps in field-value format */
	memset(array_fvp, 0x00, sizeof(array_fvp));

   /*************** Validation Block *****************/
	/*
	   for operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer (such as is NULL) */
		IFX_VALIDATE_PTR(wlWps)
		/* Do simple validation of flags such as less than 0 */
		IFX_VALIDATE_FLAGS(flags)
	}

	/*************** Prolog Block *********************/
	/*
	   based on the operation (ADD or DELETE or MODIFY), the flags variable is
	   appended with internal flags */

	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");

	/* section name of this object is TAG_WLAN_WPS */
	sprintf(wlWps->iid.cpeId.secName, "%s", TAG_WLAN_WPS);
	/* section name of parent object is TAG_WLAN_MAIN */
	sprintf(wlWps->iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);

	/* for modify and delete determine apIdx */
	if (IFX_ADD_F_NOT_SET(flags)) {
		/* use the parent cpeid to get index of the parent instance */
		pCpeId.Id = wlWps->iid.pcpeId.Id;
		sprintf(pCpeId.secName, "%s", TAG_WLAN_MAIN);
		/*
		   for stopping the correct AP/VAP we need to get the index of the AP;
		   this is not the index of the wlan_sta_wmm object, but the index of
		   the correspondig parent (wlan_main object); therefore we pass the
		   pCpeId (cpeId of wlan_main) to this macro; the retrieved index is
		   saved in apIdx */
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, pCpeId, apIdx)
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "apIdx: %d", apIdx);
	}

	if (IFX_MODIFY_F_SET(flags)) {
		/* for config via web, check if any parameter changed */
		if (wlWps->iid.config_owner == IFX_WEB) {
			/* return immediately if no parameter changed */
			if (mapiWlanChkWpsCfgChg(apIdx, wlWps) == FALSE) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig",
					"apIdx: %d", apIdx);
				return IFX_SUCCESS;
			}
		}

		/* get the main configuration required for hidden SSID mode and radioCpeId*/
		memset(&wlMain, 0, sizeof(IFX_MAPI_WLAN_MainCfg));
		wlMain.iid.cpeId.Id = wlWps->iid.cpeId.Id;
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig",
			"wlMain.iid.cpeId.Id: %d", wlMain.iid.cpeId.Id);
		sprintf(wlMain.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
		sprintf(wlMain.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
		if ((ret = ifx_mapi_get_wlan_main_config(&wlMain, IFX_F_DEFAULT)) !=
			IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "cpeId: %s, %d",
				wlMain.iid.cpeId.secName, wlMain.iid.cpeId.Id);
			goto IFX_Handler;
		}

		/*
			Perform below checks if WPS is enabled:
			1. MAC filter must be disabled
			2. Hidden SSID mode must be disabled
		*/
		if (wlWps->enable) {
			/* first get the security configuration */
			memset(&wlSec, 0, sizeof(IFX_MAPI_WLAN_SecCfg));
			sprintf(wlSec.iid.cpeId.secName, "%s", TAG_WLAN_SEC);
			sprintf(wlSec.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
			wlSec.iid.cpeId.Id = wlWps->iid.cpeId.Id;
			if ((ret = ifx_mapi_get_wlan_security_config(&wlSec, flags)) !=
				IFX_SUCCESS) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");
				goto IFX_Handler;
			}
			/*
				* if WPS is enabled and MAC filter is enabled (black or white list),
				* then MAC filter must be disabled
			*/
			if ((wlSec.macAddrCntrlEna == IFX_MAPI_MACADDR_CONTROL_ALLOW)
				|| (wlSec.macAddrCntrlEna == IFX_MAPI_MACADDR_CONTROL_DENY)) {
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");
					wlSec.macAddrCntrlEna = IFX_MAPI_MACADDR_CONTROL_DISABLE;
					if ((ret = ifx_mapi_set_wlan_security_config(IFX_OP_MOD, &wlSec,
						IFX_F_MODIFY | IFX_F_INT_DONT_CONFIGURE)) != IFX_SUCCESS) {
							IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");
							goto IFX_Handler;
					}
					f_MacFilterDisable = TRUE;
			}

			/*
				* if WPS is enabled and hidden SSID mode is active,
				* hidden SSID mode must be disabled
			*/
			if (wlMain.ssidMode == IFX_MAPI_WLAN_SSID_HIDDEN) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");
				wlMain.ssidMode = IFX_MAPI_WLAN_SSID_ADVERTISE;
				if ((ret = ifx_mapi_set_wlan_main_config(IFX_OP_MOD, &wlMain,
					IFX_F_MODIFY | IFX_F_INT_DONT_CONFIGURE)) != IFX_SUCCESS) {
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");
					goto IFX_Handler;
				}
				f_HiddenSsidDisable = TRUE;
			}
		}
	}

	/*************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_ADD_F_SET(flags)) {
		/*
		   get the next cpe id for the section wlWps from the next_cpe_id
		   section in rc.conf and store it as cpeId; the distinct parameter
		   enable is provided for TR69 */
		if (ifx_get_IID(&wlWps->iid, "enable") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "tr69Id: %s",
			       wlWps->iid.tr69Id);
	}

	/*
	   the format for wlWps object is wlwps<pCpeId>_<Index>_param for this
	   purpose we are defining the used prefix wlWps<pCpeId> here */
	sprintf(prefix, "%s%d", PREFIX_WLAN_WPS, wlWps->iid.pcpeId.Id);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "prefix: %s",
		       prefix);

   /**************** Name Value Formation as per RC.CONF ********************/
	/*
	   form the field-value pairs(FVP) from the given structure for ADD/MODIFY
	   Operations */
	count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		/*
		   the buffer array_fvp is filled in a first step with the field names
		   of wlan_sta_wmm object */
		ifx_fill_ArrayFvp_FName(array_fvp, count, WLAN_WPS_PARAM_COUNT,
					wlan_wps_params);

		sprintf(array_fvp[0].value, "%d", wlWps->iid.cpeId.Id);
		sprintf(array_fvp[1].value, "%d", wlWps->iid.pcpeId.Id);
		sprintf(array_fvp[2].value, "%d", wlWps->enable);
		sprintf(array_fvp[3].value, "%d", wlWps->enrolleeEna);
		sprintf(array_fvp[4].value, "%d", wlWps->proxyEna);
		if (ltq_mapi_get_wlan_vendor(wlMain.radioCpeId, IFX_F_DEFAULT) ==
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			/* Internal registrar support must always be enabled if WPS is enabled */
			if (wlWps->enable)
				wlWps->intRegEna = TRUE;
			else
				wlWps->intRegEna = FALSE;
		}

		sprintf(array_fvp[5].value, "%d", wlWps->intRegEna);
		sprintf(array_fvp[6].value, "%s", wlWps->apWpsName);
		sprintf(array_fvp[7].value, "%d", wlWps->apWpsPin);

		sprintf(array_fvp[8].value, "%s", "");
		for (i = 0; i < IFX_MAPI_WPS_MAX_CFG_METHODS; i++) {
			if( wlWps->enaCfgMethods[i] != 0 ) {
				switch(wlWps->enaCfgMethods[i]) {
				case IFX_MAPI_WPS_USB_FLASH_DRIVE:
					strcat(array_fvp[8].value, "1");
					break;
				case IFX_MAPI_WPS_ETHERNET:
					strcat(array_fvp[8].value, "2");
					break;
				case IFX_MAPI_WPS_LABEL:
					strcat(array_fvp[8].value, "3");
					break;
				case IFX_MAPI_WPS_DISPLAY:
					strcat(array_fvp[8].value, "4");
					break;
				case IFX_MAPI_WPS_EXTERNAL_NFC_TOKEN:
					strcat(array_fvp[8].value, "5");
					break;
				case IFX_MAPI_WPS_INTEGRATED_NFC_TOKEN:
					strcat(array_fvp[8].value, "6");
					break;
				case IFX_MAPI_WPS_NFC_INTERFACE:
					strcat(array_fvp[8].value, "7");
					break;
				case IFX_MAPI_WPS_PUSH_BUTTON:
					strcat(array_fvp[8].value, "8");
					break;
				case IFX_MAPI_WPS_KEY_PAD:
					strcat(array_fvp[8].value, "9");
					break;
				}
				if( (i+1 < IFX_MAPI_WPS_MAX_CFG_METHODS) &&
					(wlWps->enaCfgMethods[i+1] != 0))
					strcat(array_fvp[8].value, ",");
			} else
				break;
		}

		/* leave setupLock unchanged */
		sprintf(array_fvp[9].value, "%d", wlWps->setupLock);
		sprintf(array_fvp[10].value, "%d", wlWps->cfgState);
		sprintf(array_fvp[11].value, "%d", wlWps->maxPinLockout);
	}

	/* store number of parameters for wlan_sta_wmm object in count */
	count = WLAN_WPS_PARAM_COUNT;

	/*
	   configuration index = 0 for all instances - for Add, Delete, Modify
	   operations; instead pcpeId is appended in prefix name; example:
	   wlWps<pcpeId>_0_param */
	objConfigIdx = 0;
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "objConfigIdx: %d",
		       objConfigIdx);
	if (ifx_get_conf_index_and_nv_pairs(&wlWps->iid, objConfigIdx, prefix,
					    count, array_fvp,
					    flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif				/* #ifdef IFX_LOG_DEBUG */
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "objConfigIdx: %d",
		       objConfigIdx);

	for (i = 0; i < WLAN_WPS_PARAM_COUNT; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig",
			       "name: %s, value: %s", array_fvp[i].fieldname,
			       array_fvp[i].value);

   /********* ACL Checking block - MUST for MODIFY/DELETE operations **********/
	if(IFX_ADD_F_NOT_SET(flags) && IFX_INT_DONT_CHECK_ACL_F_NOT_SET(flags)) {
		/*
		   for modify operations only an array for changed parameters is saved
		   in array_changed_fvp; for modify and delete operation also a TR69
		   plugin is called for access control check */
		CHECK_ACL_RET(wlWps->iid, count, array_fvp,
			      changed_count, array_changed_fvp, flags,
			      IFX_Handler)
	}

	for (i = 0; i < WLAN_WPS_PARAM_COUNT; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig",
			       "name: %s, value: %s", array_fvp[i].fieldname,
			       array_fvp[i].value);
	/*
	   before updating the config file: stop the AP/VAP in case of delete
	   operation only */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags) && IFX_DELETE_F_SET(flags)) {
	    sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, apIdx);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "conf_buf: %s",
			conf_buf);
		system(conf_buf);
	}

   /*************** System Config File Update Block ****************/
	/*
	   convert the name value pair in array_fvp into string format expected by
	   rc.conf file */
	if ((ret = form_cfgdb_buf(conf_buf, count, array_fvp)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "conf_buf: %s",
		       conf_buf);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_WPS, flags, 1, conf_buf);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");
		goto IFX_Handler;
	}

   /**************** Device Configuration Block *********************/
	/*
	   Device config thru Scripts/Utilities or Functions after config file
	   update, for modify operation start script for applying the changes */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags)) {
		if (operation == IFX_OP_MOD) {
			features = ltq_mapi_get_wlan_supported_features(
				wlMain.radioCpeId, IFX_F_DEFAULT);
			if (features & LTQ_MAPI_WLAN_FEATURE_OPT_SCRIPTS) {
				if (f_MacFilterDisable) {
					sprintf(conf_buf, "%s %d", SERVICE_WLAN_MAC_CTRL_MODIFY, apIdx);
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "conf_buf: %s",
						conf_buf);
					LTQ_LOG_TIMESTAMP();
					system(conf_buf);
					LTQ_LOG_TIMESTAMP();
				}
				if (f_HiddenSsidDisable) {
					sprintf(conf_buf, "%s %d 0 1", SERVICE_WLAN_MODIFY, apIdx);
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "conf_buf: %s",
						conf_buf);
					LTQ_LOG_TIMESTAMP();
					system(conf_buf);
					LTQ_LOG_TIMESTAMP();
				}
			} else {
				if (f_MacFilterDisable || f_HiddenSsidDisable) {
					sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, apIdx);
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig",
						"conf_buf: %s",	conf_buf);
					LTQ_LOG_TIMESTAMP();
					system(conf_buf);
					LTQ_LOG_TIMESTAMP();
				}
			}

			sprintf(conf_buf, "%s %d", SERVICE_WLAN_WPS_CONFIG, apIdx);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "conf_buf: %s",
				       conf_buf);
			LTQ_LOG_TIMESTAMP();
			system(conf_buf);
			LTQ_LOG_TIMESTAMP();

			if (!(features & LTQ_MAPI_WLAN_FEATURE_NETMODE_PER_VAP)) {
				if (f_MacFilterDisable || f_HiddenSsidDisable) {
					sprintf(conf_buf, "%s %d", SERVICE_WLAN_START, apIdx);
					IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration",
						"conf_buf: %s", conf_buf);
					LTQ_LOG_TIMESTAMP();
					system(conf_buf);
					LTQ_LOG_TIMESTAMP();
				}
			}
		}
	}

	/* this will Compact the section and also update the count for both ADD and
	   DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags)) {
		ret =
		    ifx_UpdateCountInSection(FILE_RC_CONF, TAG_WLAN_WPS, flags);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig",
				       "ret: %d", ret);
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");
	}

   /*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	/*
	   \todo is something missing here? */

   /*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_MODIFY_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");
		CHECK_N_SEND_NOTIFICATION(wlWps->iid, changed_count,
					  array_changed_fvp, flags, IFX_Handler)
	} else if (IFX_INT_ADD_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");
		/*
		   in case of ADD operation update the ID Mappings, then send
		   notification */
      /*********** Epilog Block **************/
		UPDATE_ID_MAP_N_ATTRIBUTES(&wlWps->iid, count, array_fvp, flags,
					   IFX_Handler)
		    CHECK_N_SEND_NOTIFICATION(wlWps->iid, count, array_fvp,
					      flags, IFX_Handler)

		    /* Manipulate nextCpeId only for ADD operations */
		    ret = ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WLAN_WPS);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig",
				       "ret: %d", ret);
			goto IFX_Handler;
		}
	} else if (IFX_DELETE_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");
		/*
		   in case of DELETE operation send notification, then update the ID
		   Mappings */
		CHECK_N_SEND_NOTIFICATION(wlWps->iid, count, array_fvp, flags,
					  IFX_Handler)
		    /*
		       The TR69 mapping section is updated. Also the TR69 parameter
		       Attribute section is updated. This is required to keep the TR69
		       specific sections up-to-date. */
		    UPDATE_ID_MAP_N_ATTRIBUTES(&wlWps->iid, count, array_fvp,
					       flags, IFX_Handler)
		    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig",
				   "ret: %d", ret);

	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "ret: %d",
			       ret);
		goto IFX_Handler;
	}
	g_wlMain[apIdx].WPSena = wlWps->enable;

IFX_Handler:
	/* reset flags to reload configuration */
	g_flagWpsConfig = 0;
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "ret: %d", ret);
	IFX_MEM_FREE(array_changed_fvp);
	return ret;
}

/**
   This api sets wlan wps registrar parameters available in wlWpsRegs

   \param oper

   \param   wlWpsRegs - pointer to IFX_MAPI_WLAN_WPS_Regs_Cfg structure

   \param flags

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int32
ifx_mapi_set_wlan_wps_registrar_config(uint32 operation,
				       IFX_MAPI_WLAN_WPS_Regs_Cfg * wlWpsRegs,
				       uint32 flags)
{
	CPE_ID pCpeId;
	int32 ret = IFX_SUCCESS, count = 0, changed_count = 0;
	char8 conf_buf[MAX_SECTION_DATA_LEN], prefix[MAX_FILELINE_LEN];
	int32 objConfigIdx = -1, apIdx = -1, i;
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_WPS_REGISTRAR_PARAM_COUNT + 1];
	IFX_NAME_VALUE_PAIR *array_changed_fvp = NULL;

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");

	/*
	   initalize buffer conf_buf which is used for two purposes: - holding the
	   configuration for wlWpsRegs to be written to rc.conf - holding the
	   commands for system calls */
	memset(conf_buf, 0x00, sizeof(conf_buf));

	/*
	   initalize buffer array_fvp which is used for storing the new
	   configuration of wlWpsRegs in field-value format */
	memset(array_fvp, 0x00, sizeof(array_fvp));

   /*************** Prolog Block *********************/
	/*
	   based on the operation (ADD or DELETE or MODIFY), the flags variable is
	   appended with internal flags */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");

   /*************** Validation Block *****************/
	/*
	   for operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer (such as is NULL) */
		IFX_VALIDATE_PTR(wlWpsRegs)
		    /* Do simple validation of flags such as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}
	/* section name of this object is TAG_WLAN_WPS_REGISTRAR */
	sprintf(wlWpsRegs->iid.cpeId.secName, "%s", TAG_WLAN_WPS_REGISTRAR);
	/* section name of parent object is TAG_WLAN_MAIN */
	sprintf(wlWpsRegs->iid.pcpeId.secName, "%s", TAG_WLAN_WPS);

   /*************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_ADD_F_SET(flags)) {
		/*
		   get the next cpe id for the section wlWpsRegs from the next_cpe_id
		   section in rc.conf and store it as cpeId; the distinct parameter
		   enable is provided for TR69 */
		if (ifx_get_IID(&wlWpsRegs->iid, "enable") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			IFX_MAPI_DEBUG(fd,
				       "/tmp/ifxMapiSetWlanWpsRegistrarConfig",
				       "");
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}

		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig",
			       "tr69Id: %s", wlWpsRegs->iid.tr69Id);
	}

	/*
	   the format for wlWpsRegs object is wlwpsregs_<pCpeId>_<Index>_param for
	   this purpose we are defining the used prefix wlWps<pcpeId> here */
	sprintf(prefix, "%s%d", PREFIX_WLAN_WPS_REGS, wlWpsRegs->iid.pcpeId.Id);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "prefix: %s",
		       prefix);

   /**************** Name Value Formation as per RC.CONF ********************/
	/*
	   form the field-value pairs(FVP) from the given structure for ADD/MODIFY
	   Operations */
	count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		/*
		   the buffer array_fvp is filled in a first step with the field names
		   of wlan_wps_regs object */
		ifx_fill_ArrayFvp_FName(array_fvp, count,
					WLAN_WPS_REGISTRAR_PARAM_COUNT,
					wlan_wps_regs_params);

		sprintf(array_fvp[0].value, "%d", wlWpsRegs->iid.cpeId.Id);
		sprintf(array_fvp[1].value, "%d", wlWpsRegs->iid.pcpeId.Id);
		sprintf(array_fvp[2].value, "%d", wlWpsRegs->enable);
		sprintf(array_fvp[3].value, "%s", wlWpsRegs->regsWpsName);
		objConfigIdx = -1;
	}

	/* store number of parameters for wlan_wps_regs object in count */
	count = WLAN_WPS_REGISTRAR_PARAM_COUNT;

	/*
	   configuration index = 0 for all instances - for Add, Delete, Modify
	   operations; instead pcpeId is appended in prefix name; example:
	   wlWps<pcpeId>_0_param */
	objConfigIdx = 0;
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "objConfigIdx: %d",
		       objConfigIdx);
	if (ifx_get_conf_index_and_nv_pairs
	    (&wlWpsRegs->iid, objConfigIdx, prefix, count, array_fvp,
	     flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif				/* #ifdef IFX_LOG_DEBUG */
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig",
		       "objConfigIdx: %d", objConfigIdx);

   /********* ACL Checking block - MUST for MODIFY/DELETE operations **********/
	if (IFX_ADD_F_NOT_SET(flags) && IFX_INT_DONT_CHECK_ACL_F_NOT_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "flags: 0x%x", flags);
		/*
		   for modify operations only an array of changed parameters is saved
		   in array_changed_fvp; for modify and delete operation also a TR69
		   plugin is called for access control check */
		CHECK_ACL_RET(wlWpsRegs->iid, count, array_fvp,
			      changed_count, array_changed_fvp, flags,
			      IFX_Handler)
	}

	for (i = 0; i < WLAN_WPS_REGISTRAR_PARAM_COUNT; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig",
			       "name: %s, value: %s", array_fvp[i].fieldname,
			       array_fvp[i].value);
	/*
	   before updating the config file: stop the AP/VAP in case of delete
	   operation only */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags) && IFX_DELETE_F_SET(flags)) {
		/* use the parent cpeid to get index of the parent instance */
		pCpeId.Id = wlWpsRegs->iid.pcpeId.Id;
		sprintf(pCpeId.secName, "%s", TAG_WLAN_MAIN);
		/*
		   for stopping the correct AP/VAP we need to get the index of the AP;
		   this is not the index of the wlan_sta_wmm object, but the index of
		   the correspondig parent (wlan_main object); therefore we pass the
		   pCpeId (cpeId of wlan_main) to this macro; the retrieved index is
		   saved in apIdx */
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, pCpeId, apIdx)
		    sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, apIdx);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig",
			       "conf_buf: %s", conf_buf);
		system(conf_buf);
	}

   /*************** System Config File Update Block ****************/
	/*
	   convert the name value pair in array_fvp into string format expected by
	   rc.conf file */
	if ((ret = form_cfgdb_buf(conf_buf, count, array_fvp)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig",
		       "conf_buf: %s", conf_buf);

	/* RC.CONF Configuration block */
	ret =
	    ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_WPS_REGISTRAR, flags, 1,
			   conf_buf);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");
		goto IFX_Handler;
	}

   /**************** Device Configuration Block *********************/
	/*
	   Device config thru Scripts/Utilities or Functions after config file
	   update, for modify operation start script for applying the changes */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags)) {
		if (operation == IFX_OP_MOD) {
			IFX_MAPI_DEBUG(fd,
				       "/tmp/ifxMapiSetWlanWpsRegistrarConfig",
				       "");
			/* use the parent cpeid to get index of the parent instance */
			pCpeId.Id = wlWpsRegs->iid.pcpeId.Id;
			sprintf(pCpeId.secName, "%s", TAG_WLAN_MAIN);
			/*
			   for stopping the correct AP/VAP we need to get the index of the
			   AP; this is not the index of the wlan_sta_wmm object, but the
			   index of the correspondig parent (wlan_main object); therefore
			   we pass the pCpeId (cpeId of wlan_main) to this macro; the
			   retrieved index is saved in apIdx */
			IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, pCpeId, apIdx)
			    sprintf(conf_buf, "%s %d &",
				    SERVICE_WLAN_WPS_CONFIG, apIdx);
			system(conf_buf);
		}
	}

	/* this will Compact the section and also update the count for both ADD and
	   DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags)) {
		ret =
		    ifx_UpdateCountInSection(FILE_RC_CONF,
					     TAG_WLAN_WPS_REGISTRAR, flags);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			IFX_MAPI_DEBUG(fd,
				       "/tmp/ifxMapiSetWlanWpsRegistrarConfig",
				       "ret: %d", ret);
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");
	}

   /*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	/*
	   \todo is something missing here? */

   /*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_MODIFY_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");
		CHECK_N_SEND_NOTIFICATION(wlWpsRegs->iid, changed_count,
					  array_changed_fvp, flags, IFX_Handler)
	} else if (IFX_INT_ADD_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");
		/*
		   in case of ADD operation update the ID Mappings, then send
		   notification */
      /*********** Epilog Block **************/
		UPDATE_ID_MAP_N_ATTRIBUTES(&wlWpsRegs->iid, count, array_fvp,
					   flags, IFX_Handler) {
			IFX_MAPI_DEBUG(fd,
				       "/tmp/ifxMapiSetWlanWpsRegistrarConfig",
				       "");
			CHECK_N_SEND_NOTIFICATION(wlWpsRegs->iid, count,
						  array_fvp, flags, IFX_Handler)
			    IFX_MAPI_DEBUG(fd,
					   "/tmp/ifxMapiSetWlanWpsRegistrarConfig",
					   "");
		}
		/* Manipulate nextCpeId only for ADD operations */
		ret =
		    ifx_increment_next_cpeId(FILE_RC_CONF,
					     TAG_WLAN_WPS_REGISTRAR);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			IFX_MAPI_DEBUG(fd,
				       "/tmp/ifxMapiSetWlanWpsRegistrarConfig",
				       "ret: %d", ret);
			goto IFX_Handler;
		}
	} else if (IFX_DELETE_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");
		/*
		   in case of DELETE operation send notification, then update the ID
		   Mappings */
		{
			IFX_MAPI_DEBUG(fd,
				       "/tmp/ifxMapiSetWlanWpsRegistrarConfig",
				       "");
			CHECK_N_SEND_NOTIFICATION(wlWpsRegs->iid, count,
						  array_fvp, flags, IFX_Handler)
			    IFX_MAPI_DEBUG(fd,
					   "/tmp/ifxMapiSetWlanWpsRegistrarConfig",
					   "");
		}
		/*
		   The TR69 mapping section is updated. Also the TR69 parameter
		   Attribute section is updated. This is required to keep the TR69
		   specific sections up-to-date. */
		UPDATE_ID_MAP_N_ATTRIBUTES(&wlWpsRegs->iid, count, array_fvp,
					   flags, IFX_Handler)
		    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig",
				   "ret: %d", ret);
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig",
			       "ret: %d", ret);
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "ret: %d",
		       ret);
	IFX_MEM_FREE(array_changed_fvp);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/**
   This api triggers the WPS push button control method on the wlan

   \param wlMnCpeId -   mainCpeID of AP/VAP the WPS PBC method shall be started for

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int32 ifx_mapi_trigger_wps_pbc(uint32 wlMnCpeId)
{
	int32 ret = IFX_SUCCESS, passed_index = -1;
	CPE_ID mainCpeId;
	char8 conf_buf[MAX_DATA_LEN];

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiTriggerWpsPbc", "");

	/*
	   initalize buffer conf_buf which is used for holding the commands for
	   system calls */
	memset(conf_buf, 0x00, sizeof(conf_buf));

	sprintf(mainCpeId.secName, "%s", TAG_WLAN_MAIN);
	mainCpeId.Id = wlMnCpeId;
	/*
	   get configuration index from CPEID and save it in passed_index */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, mainCpeId, passed_index)
	    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiTriggerWpsPbc", "passed_index: %d",
			   passed_index);

#if defined (CONFIG_FEATURE_LTQ_WIRELESS_VB) || defined (CONFIG_FEATURE_LTQ_WIRELESS_STA_SUPPORT)
	/* call system script to remove temp file */
	sprintf(conf_buf, "rm /tmp/wps_2web_status");
	system(conf_buf);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiTriggerWpsPbc", "conf_buf: %s",
		       conf_buf);
#endif

	/* call system script to initiate pbc based pairing */
	sprintf(conf_buf, "%s %d &", SERVICE_WLAN_WPS_PBC_PAIRING,
		passed_index);
	system(conf_buf);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiTriggerWpsPbc", "conf_buf: %s",
		       conf_buf);

      IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiTriggerWpsPbc", "ret: %d", ret);
	return ret;
}

/**
   This api triggers the WPS PIN method on the wlan

   \param wlMnCpeId -   mainCpeID of AP/VAP the WPS PBC method shall be started for

   \param clientPIN -   PIN entered on the Web page that must be given to wlan

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int32 ifx_mapi_trigger_wps_pin(uint32 wlMnCpeId,
		char8 * clientPIN,
		char8 * authEpMacAddr)
{
	int32 ret = IFX_SUCCESS, passed_index = -1;
	CPE_ID mainCpeId;
	char8 conf_buf[MAX_DATA_LEN];
	IFX_MAPI_WLAN_MainCfg	*wlMain = NULL;
	uint32	nVap = 0;

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiTriggerWpsPin", "");

	/*
	   initalize buffer conf_buf which is used for holding the commands for
	   system calls */
	memset(conf_buf, 0x00, sizeof(conf_buf));

	sprintf(mainCpeId.secName, "%s", TAG_WLAN_MAIN);
	mainCpeId.Id = wlMnCpeId;
	/*
	   get configuration index from CPEID and save it in passed_index */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, mainCpeId, passed_index)
	    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiTriggerWpsPin", "passed_index: %d",
			   passed_index);

#if defined (CONFIG_FEATURE_LTQ_WIRELESS_VB) || defined (CONFIG_FEATURE_LTQ_WIRELESS_STA_SUPPORT)
	/* call system script to remove temp file */
	sprintf(conf_buf, "rm /tmp/wps_2web_status");
	system(conf_buf);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiTriggerWpsPin", "conf_buf: %s",
		       conf_buf);
#endif

	if (ifx_mapi_get_all_wlan_main_config(&nVap, &wlMain,
		IFX_F_DEFAULT) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiTriggerWpsPin", "");
			goto IFX_Handler;
	}
	if (ltq_mapi_get_wlan_vendor(wlMain[passed_index].radioCpeId, IFX_F_DEFAULT) ==
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
	/* call system script to initiate pin based pairing */
		sprintf(conf_buf, "%s %d %s %s &", SERVICE_WLAN_WPS_PIN_PAIRING,
			passed_index, clientPIN, authEpMacAddr);
	} else {
		sprintf(conf_buf, "%s %d %s &", SERVICE_WLAN_WPS_PIN_PAIRING,
			passed_index, clientPIN);
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiTriggerWpsPin", "conf_buf: %s",
		       conf_buf);
	system(conf_buf);

IFX_Handler:
	IFX_MEM_FREE(wlMain);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiTriggerWpsPin", "ret: %d", ret);
	return ret;
}

/**
   This api restores the WPS pin to default.

   \param wlMnCpeId -   mainCpeID of AP/VAP

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int32 ifx_mapi_restore_wps_pin(uint32 wlMnCpeId)
{
	int32 ret = IFX_SUCCESS, passed_index = -1;
	CPE_ID mainCpeId;
	char8 conf_buf[MAX_DATA_LEN];

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiRestoreWpsPin", "");

	/*
	   initalize buffer conf_buf which is used for holding the commands for
	   system calls */
	memset(conf_buf, 0x00, sizeof(conf_buf));

	sprintf(mainCpeId.secName, "%s", TAG_WLAN_MAIN);
	mainCpeId.Id = wlMnCpeId;
	/*
	   get configuration index from CPEID and save it in passed_index */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, mainCpeId, passed_index)
	    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiRestoreWpsPin", "passed_index: %d",
			   passed_index);

	/* call system script to restore default AP pin */
	sprintf(conf_buf, "%s %d &", SERVICE_WLAN_RESTORE_WPS_PIN,
		passed_index);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiRestoreWpsPin", "conf_buf: %s",
		       conf_buf);
	system(conf_buf);

      IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiRestoreWpsPin", "ret: %d", ret);
	return ret;
}

/**
   This api generates a new WPS pin for the AP/VAP.

   \param wlMnCpeId -   mainCpeID of AP/VAP

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int32 ifx_mapi_generate_wps_pin(uint32 wlMnCpeId)
{
	int32 ret = IFX_SUCCESS, passed_index = -1;
	CPE_ID mainCpeId;
	char8 conf_buf[MAX_DATA_LEN];
	char8 sWpsPinInfo[MAX_DATA_LEN];
	char8 *pTmpStr = NULL, *pTmpStr2;
	char8 sWpsPin[9];
	IFX_MAPI_WLAN_WPS_Cfg wlWps;
	IFX_MAPI_WLAN_MainCfg	*wlMain = NULL;
	uint32	nVap = 0;

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGenerateWpsPin", "");

	/*
	   initalize buffer conf_buf which is used for holding the commands for
	   system calls */
	memset(conf_buf, 0x00, sizeof(conf_buf));

	sprintf(mainCpeId.secName, "%s", TAG_WLAN_MAIN);
	mainCpeId.Id = wlMnCpeId;
	/*
	   get configuration index from CPEID and save it in passed_index */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, mainCpeId, passed_index)
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGenerateWpsPin", "passed_index: %d",
		passed_index);

	if (ifx_mapi_get_all_wlan_main_config(&nVap, &wlMain,
		IFX_F_DEFAULT) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGenerateWpsPin", "");
		goto IFX_Handler;
	}
	if (ltq_mapi_get_wlan_vendor(wlMain[passed_index].radioCpeId, IFX_F_DEFAULT) ==
		LTQ_MAPI_WLAN_VENDOR_WAVE300) {
		memset(sWpsPinInfo, 0x00, sizeof(sWpsPinInfo));
		sprintf(conf_buf, "%s %d", SERVICE_WLAN_GENERATE_WPS_PIN, passed_index);
		/* get new device PIN information */
		if (ifx_GetCfgData((char8 *) conf_buf, NULL, "-1", sWpsPinInfo) == 0) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGenerateWpsPin",
				   "sWpsPinInfo: Q%sQ", sWpsPinInfo);

		/* get new WPS PIN */
		if ((pTmpStr = strstr(sWpsPinInfo, "pin=")) != NULL) {
			pTmpStr2 = strtok(pTmpStr, "\"");
			if (pTmpStr2 == NULL) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			pTmpStr2 = strtok(NULL, "\"");
			if (pTmpStr2 == NULL) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			strcpy(sWpsPin, pTmpStr2);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGenerateWpsPin",
					   "WPS PIN: %s", sWpsPin);
		}
		else {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGenerateWpsPin",
					   "sWpsPinInfo: %s", sWpsPinInfo);
			goto IFX_Handler;
		}

		if (strlen(sWpsPin) == 9) {
			sWpsPin[8]='\0';
		}
		else if (strlen(sWpsPin) != 8) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGenerateWpsPin",
					   "sWpsPinLength: %d", strlen(sWpsPin));
//			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		/*
		 * now store new pin in rc.conf
		 */
		memset(&wlWps, 0x00, sizeof(IFX_MAPI_WLAN_WPS_Cfg));
		/* get WPS information */
		wlWps.iid.config_owner = IFX_WEB;
		sprintf(wlWps.iid.cpeId.secName, "%s", TAG_WLAN_WPS);
		sprintf(wlWps.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
		/* parent cpeid of wps object, is cpeID of main object */
		wlWps.iid.pcpeId.Id = wlMnCpeId;

		if ((ret =
			 ifx_mapi_get_wlan_wps_config(&wlWps,
						  IFX_F_DEFAULT)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGenerateWpsPin", "");
			goto IFX_Handler;
		}
		wlWps.apWpsPin = atoi(sWpsPin);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGenerateWpsPin", "newDevPin: %d",
				wlWps.apWpsPin);

		if ((ret =
			 ifx_mapi_set_wlan_wps_config(IFX_OP_MOD, &wlWps, IFX_F_DEFAULT)) !=
			IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGenerateWpsPin","");
			goto IFX_Handler;
		}
	} else {
		/* call system script to generate new AP pin */
		sprintf(conf_buf, "%s %d &", SERVICE_WLAN_GENERATE_WPS_PIN,
			passed_index);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGenerateWpsPin", "conf_buf: %s",
				   conf_buf);
		system(conf_buf);
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGenerateWpsPin", "ret: %d", ret);
	IFX_MEM_FREE(wlMain);
	return ret;
}

/**
   This api resets the WPS to out-of-box configuration.

   \param wlMnCpeId -   mainCpeID of AP/VAP

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int32 ifx_mapi_reset_wps(uint32 wlMnCpeId)
{
	int32 ret = IFX_SUCCESS, passed_index = -1;
	CPE_ID mainCpeId;
	char8 conf_buf[MAX_DATA_LEN];
	IFX_MAPI_WLAN_WPS_Cfg wlWps;
	IFX_MAPI_WLAN_MainCfg wlMain;
	IFX_MAPI_WLAN_SecCfg wlSec;

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps", "");

	/*
	   initalize buffer conf_buf which is used for holding the commands for
	   system calls */
	memset(conf_buf, 0x00, sizeof(conf_buf));

	sprintf(mainCpeId.secName, "%s", TAG_WLAN_MAIN);
	mainCpeId.Id = wlMnCpeId;
	/*
	   get configuration index from CPEID and save it in passed_index */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, mainCpeId, passed_index)
	    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps", "passed_index: %d",
			   passed_index);

	memset(&wlMain, 0, sizeof(IFX_MAPI_WLAN_MainCfg));
	wlMain.iid.cpeId.Id = wlMnCpeId;
	sprintf(wlMain.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
	sprintf(wlMain.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
	if ((ret = ifx_mapi_get_wlan_main_config(&wlMain, IFX_F_DEFAULT)) !=
		IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps", "cpeId: %s, %d",
			wlMain.iid.cpeId.secName, wlMain.iid.cpeId.Id);
		goto IFX_Handler;
	}
	if (ltq_mapi_get_wlan_vendor(wlMain.radioCpeId, IFX_F_DEFAULT) !=
		LTQ_MAPI_WLAN_VENDOR_WAVE300) {
		/* call system script to restore default AP pin */
		sprintf(conf_buf, "%s %d %s %s &", SERVICE_WLAN_RESET_WPS, passed_index,
			"SSID_AFTER_WPS_RESET", "PASSPHRASE_AFTER_WPS_RESET");
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps", "conf_buf: %s", conf_buf);
		system(conf_buf);
	}

	memset(&wlWps, 0x00, sizeof(IFX_MAPI_WLAN_WPS_Cfg));
	/* get WPS information */
	wlWps.iid.config_owner = IFX_WEB;
	sprintf(wlWps.iid.cpeId.secName, "%s", TAG_WLAN_WPS);
	sprintf(wlWps.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
	/* parent cpeid of wps object, is cpeID of main object */
	wlWps.iid.pcpeId.Id = wlMnCpeId;

	if ((ret = ifx_mapi_get_wlan_wps_config(&wlWps, IFX_F_DEFAULT)) !=
		IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps", "conf_buf: %s", conf_buf);
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps", "setupLock: %d", wlWps.setupLock);

	/* re-set setupLock to FALSE */
	wlWps.setupLock = FALSE;
	wlWps.cfgState = IFX_MAPI_WPS_NOT_CONFIGURED;
#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d]: wlWps.cfgState: %d", __FUNCTION__, __LINE__, wlWps.cfgState);
#endif
	if ((ret = ifx_mapi_set_wlan_wps_config(IFX_OP_MOD, &wlWps,
		IFX_F_INT_DONT_CONFIGURE)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps", "conf_buf: %s", conf_buf);
		goto IFX_Handler;
	}

	if (ltq_mapi_get_wlan_vendor(wlMain.radioCpeId, IFX_F_DEFAULT) ==
		LTQ_MAPI_WLAN_VENDOR_WAVE300) {
		/* call system script to reset WPS to unconfigured */
		sprintf(conf_buf, "%s %d", SERVICE_WLAN_RESET_WPS, passed_index);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps", "conf_buf: %s", conf_buf);
		system(conf_buf);
	} else {
		memset(&wlMain, 0, sizeof(IFX_MAPI_WLAN_MainCfg));
		wlMain.iid.cpeId.Id = wlMnCpeId;
		sprintf(wlMain.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
		sprintf(wlMain.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
		if ((ret =
			 ifx_mapi_get_wlan_main_config(&wlMain,
						   IFX_F_DEFAULT)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps", "cpeId: %s, %d",
					   wlMain.iid.cpeId.secName, wlMain.iid.cpeId.Id);
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps", "SSID: %s", wlMain.ssid);

		memset(&wlSec, 0, sizeof(IFX_MAPI_WLAN_SecCfg));
		sprintf(wlSec.iid.cpeId.secName, "%s", TAG_WLAN_SEC);
		sprintf(wlSec.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
		wlSec.iid.cpeId.Id = wlMnCpeId;

		if ((ret = ifx_mapi_get_wlan_security_config(&wlSec, IFX_F_DEFAULT)) !=
			IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps", "");
			goto IFX_Handler;
		}
	}
	g_wpsState[passed_index] = IFX_MAPI_WPS_NOT_CONFIGURED;

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps", "ret: %d", ret);
	return ret;
}

/**
   \param   mainCpeId  -

   \param   numEntries  -

   \param   wlMacControl - pointer to IFX_MAPI_WLAN_MAC_Control config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ltq_mapi_get_all_wlan_wps_endpoint_mac(uint32 mnCpeId,
					  uint32 * numEntries,
					  LTQ_MAPI_WLAN_WPS_EP_MAC_Cfg **wpsEpMac, uint32 flags)
{
	int32 ret = IFX_SUCCESS, nAllMacEntries = 0, i = 0, nMacEntries = 0;
	int32 count = 0;
	char8 sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN], *sValue2 = NULL;
	uint32 outFlag = IFX_F_DEFAULT, pcpeId;
	/* size of array: max. number of AP * max.number of entries * number of params = 10*16*3 = 480 */
	IFX_NAME_VALUE_PAIR array_fvp[LTQ_MAX_NUM_VAP*LTQ_MAX_NUM_MAC_FILTER_ENTRIES*WLAN_WPS_EPS_PARAM_COUNT];	

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_endpoint_mac",
		"mnCpeId: %d", mnCpeId);

	if (!g_flagWpsEpMacAllConfig) {
	MAKE_SECTION_COUNT_TAG(TAG_WLAN_WPS_EP_MAC, buf);
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_WPS_EP_MAC, buf, flags,
			    &outFlag, sValue)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}

	nAllMacEntries = atoi(sValue);
	if (nAllMacEntries == 0) {
		*numEntries = 0;
		*wpsEpMac = NULL;
		goto IFX_Handler;
	}

	*wpsEpMac = NULL;
	/* 160 = 16 per VAP * max number of VAP = 16 * 10 = 160 */
	if (nAllMacEntries <= 160) {
		IFX_MEM_ALLOC((*wpsEpMac), LTQ_MAPI_WLAN_WPS_EP_MAC_Cfg *,
			      nAllMacEntries, sizeof(LTQ_MAPI_WLAN_WPS_EP_MAC_Cfg))
	} else {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_endpoint_mac",
			       "max number of entries reached");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
		g_nEpMacAll = nAllMacEntries;

	sprintf(buf, "%s_", PREFIX_WLAN_WPS_EP_MAC);
	if ((ret =
	     ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_WPS_EP_MAC, buf, IFX_F_DEFAULT,
			      &sValue2)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_endpoint_mac",
			       "buf: %s", buf);
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_endpoint_mac",
		       "buf: %s, sValue2: %s", buf, sValue2);

	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sValue2, &count, array_fvp);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_endpoint_mac",
		       "count: %d", count);
	for (i = 0; i < count; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_endpoint_mac",
			       "%s:%s", array_fvp[i].fieldname,
			       array_fvp[i].value);

	for (i = 0; i < nAllMacEntries; i++) {
		/* store complete EP MAC list in global array */
		g_wlWpsEpMacAllConfig[i].iid.cpeId.Id = atoi(array_fvp[3 * i].value);
		g_wlWpsEpMacAllConfig[i].iid.pcpeId.Id = atoi(array_fvp[3 * i + 1].value);
		snprintf(g_wlWpsEpMacAllConfig[i].macAddr, IFX_MAPI_MAC_ADDR_LEN, "%s",
			array_fvp[3 * i + 2].value);

		pcpeId = atoi(array_fvp[3 * i + 1].value);
		if (pcpeId == mnCpeId) {
			(*wpsEpMac + nMacEntries)->iid.cpeId.Id =
			    atoi(array_fvp[3 * i].value);
			(*wpsEpMac + nMacEntries)->iid.pcpeId.Id = pcpeId;
			sprintf((*wpsEpMac +
				 nMacEntries)->iid.cpeId.secName, "%s",
				 TAG_WLAN_WPS_EP_MAC);
			sprintf((*wpsEpMac +
				 nMacEntries)->iid.pcpeId.secName, "%s",
				TAG_WLAN_MAIN);
			snprintf((*wpsEpMac + nMacEntries)->macAddr,
				 IFX_MAPI_MAC_ADDR_LEN, "%s",
				 array_fvp[3 * i + 2].value);
			IFX_MAPI_DEBUG(fd,
				       "/tmp/ltq_mapi_get_all_wlan_wps_endpoint_mac",
				       "macAddr: %s",
				       (*wpsEpMac + nMacEntries)->macAddr);
			nMacEntries++;
		}
	}
		g_flagWpsEpMacAllConfig = 1;
	}
	else {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_endpoint_mac",
			"g_nEpMacAll: %d", g_nEpMacAll);
		IFX_MEM_ALLOC((*wpsEpMac), LTQ_MAPI_WLAN_WPS_EP_MAC_Cfg *,
			g_nEpMacAll, sizeof(LTQ_MAPI_WLAN_WPS_EP_MAC_Cfg))

		nMacEntries = 0;
		for (i = 0; i < g_nEpMacAll; i++) {
			pcpeId = g_wlWpsEpMacAllConfig[i].iid.pcpeId.Id;
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_endpoint_mac",
				"pcpeId: %d", pcpeId);
			if (pcpeId == mnCpeId) {
				(*wpsEpMac + nMacEntries)->iid.cpeId.Id =
					g_wlWpsEpMacAllConfig[i].iid.cpeId.Id;
				(*wpsEpMac + nMacEntries)->iid.pcpeId.Id = pcpeId;
				sprintf((*wpsEpMac +
					 nMacEntries)->iid.cpeId.secName, "%s",
					 TAG_WLAN_WPS_EP_MAC);
				sprintf((*wpsEpMac +
					 nMacEntries)->iid.pcpeId.secName, "%s",
					TAG_WLAN_MAIN);
				snprintf((*wpsEpMac + nMacEntries)->macAddr,
					 IFX_MAPI_MAC_ADDR_LEN, "%s",
					 g_wlWpsEpMacAllConfig[i].macAddr);
				IFX_MAPI_DEBUG(fd,
						   "/tmp/ltq_mapi_get_all_wlan_wps_endpoint_mac",
						   "macAddr: %s",
						   (*wpsEpMac + nMacEntries)->macAddr);
				nMacEntries++;
			}
		}
	}
	*numEntries = nMacEntries;
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_endpoint_mac",
		       "numEntries: %d", *numEntries);

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wps_endpoint_mac", "ret: %d",
		       ret);
	IFX_MEM_FREE(sValue2)
	/*
	   in case of error free allocated memory here, otherwise it must be
	   freed in calling function */
	if (ret != IFX_SUCCESS)
		IFX_MEM_FREE(*wpsEpMac)

	return ret;
}

/**
   This API configures the WLAN MAC filter

   \param   oper  - type of operation (ADD, MODIFY, DELETE)

   \param   wlMacControl - pointer to IFX_MAPI_WLAN_MAC_Control structure

   \param   flags - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ltq_mapi_set_wlan_wps_endpoint_mac(uint32 oper,
		LTQ_MAPI_WLAN_WPS_EP_MAC_Cfg * wlWpsEpMac,
		uint32 flags)
{
	int32				ret = IFX_SUCCESS, passed_index = -1, count = 0;
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_WPS_EPS_PARAM_COUNT];
	char8				conf_buf[MAX_SECTION_DATA_LEN];
	IFX_ID 				parent_iid;

#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif

	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
	memset(array_fvp, 0x00, sizeof(array_fvp));
	memset(&parent_iid, 0, sizeof(parent_iid));

	/*************** Prolog Block *********************/
	/*
	 * Based on operation (ADD or DELETE or MODIFY) append the flag with
	 * internal flags
	*/
	if (oper == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (oper == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	}
	else
		flags |= IFX_F_MODIFY;

	/**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(wlWpsEpMac)
	    /* do simple validation of flags sucha as less than 0 */
	    IFX_VALIDATE_FLAGS(flags)
	}

	sprintf(wlWpsEpMac->iid.cpeId.secName, "%s", TAG_WLAN_WPS_EP_MAC);
	/* since this object is not in tr69-model */
	sprintf(wlWpsEpMac->iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);

	parent_iid.cpeId.Id = wlWpsEpMac->iid.pcpeId.Id;
	sprintf(parent_iid.cpeId.secName, "%s",
			wlWpsEpMac->iid.pcpeId.secName);

#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d: parent_iid.cpeId: %s, %d]",
			__FUNCTION__, __LINE__,
			parent_iid.cpeId.secName, parent_iid.cpeId.Id);
#endif

	if (IFX_ADD_F_SET(flags)) {
		/* Allocate the IID for this mac-control instance Set the parent
		   SectionName and parent IID values to NULL as there is no parent for
		   Route Entity */
		if (ifx_get_iid(TAG_WLAN_WPS_EP_MAC, TAG_WLAN_MAIN, &parent_iid,
				&wlWpsEpMac->iid) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	/*********************** Name Value Formation as per RC.CONF **********************/
	if (IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, 0, WLAN_WPS_EPS_PARAM_COUNT,
				wlan_wps_ep_mac_params);

		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 2,
				(int32 *) & wlWpsEpMac->iid.cpeId.Id,
				&wlWpsEpMac->iid.pcpeId.Id);
		sprintf(array_fvp[2].value, "%s", wlWpsEpMac->macAddr);
		passed_index = -1;
	}
	count = WLAN_WPS_EPS_PARAM_COUNT;

	/* Get Config Index in case of modify/delete operations from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]: cpeId: %s: %d",
				__FUNCTION__, __LINE__,
				wlWpsEpMac->iid.cpeId.secName, wlWpsEpMac->iid.cpeId.Id);
#endif
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlWpsEpMac->iid.cpeId,
					 passed_index)
	}

	if (ifx_get_conf_index_and_nv_pairs(&wlWpsEpMac->iid, passed_index,
			PREFIX_WLAN_WPS_EP_MAC, count, array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* Convert the name value pair in array_fvp into string format expected by
	   rc.conf file */
	memset(conf_buf, 0x00, sizeof(conf_buf));
	form_cfgdb_buf(conf_buf, count, array_fvp);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_WPS_EP_MAC, flags, 1, conf_buf);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/*********** Device Configuration Block ****************/
	/* empty for WPS EP MAC */

	/*********** Epilog Block **************/
	/*
	 * this will Compact the section and also update the count for both ADD and
	 * DELETE
	 */
	if (IFX_MODIFY_F_NOT_SET(flags)) {
			ifx_CompactCfgSection(FILE_RC_CONF, TAG_WLAN_WPS_EP_MAC, flags);
	}

	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_INT_ADD_F_SET(flags)) {
		/* since this object is not in tr-98 model no need to call update_map
		   and notification here */
		/* Manipulate nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WLAN_WPS_EP_MAC);
	}
	else if (IFX_DELETE_F_SET(flags)) {
			/* since this object is not in tr-98 model no need to call update_map
			   and notification here */
	}
	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		IFX_DBG("[%s:%d] upgrade failed", __FUNCTION__, __LINE__);
		goto IFX_Handler;
	}
	/* reset flag and count to reload config */
	g_flagWpsEpMacAllConfig = 0;
	g_nEpMacAll = 0;

IFX_Handler:
	IFX_DBG("[%s:%d]: ret: %d", __FUNCTION__, __LINE__, ret);
	return ret;
}

/**
   \param   wpsConnectionStatus - pointer to LTQ_MAPI_WPS_ConnectionStatus

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ltq_mapi_get_wps_connection_status(LTQ_MAPI_WPS_ConnectionStatus *wpsConnectionStatus)
{
	int32 ret = IFX_SUCCESS;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_DATA_LEN];

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wps_connection_status", "");

	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	memset(sValue, 0x00, sizeof(sValue));
	sprintf(buf, "%s", "/tmp/wps_2web_status");

	if (ifx_GetCfgData((char8 *) buf, "WPS_Status", "STATE", sValue) == 0) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wps_connection_status",
			"buf: %s", buf);
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wps_connection_status",
		"sValue: %s", sValue);

	/* Configured is not set to "Yes", therefore return */
	if (!(strcmp(sValue, "IDLE"))) {
		*wpsConnectionStatus = LTQ_MAPI_WPS_CONNECTION_IDLE;
	} else if (!(strcmp(sValue, "OVERLAP_ERR"))) {
		*wpsConnectionStatus =
		    LTQ_MAPI_WPS_CONNECTION_OVERLAP_ERR;
	} else if (!(strcmp(sValue, "SUCCESS"))) {
		*wpsConnectionStatus = LTQ_MAPI_WPS_CONNECTION_SUCCESS;
	} else if (!(strcmp(sValue, "TIMEOUT_ERR"))) {
		*wpsConnectionStatus = LTQ_MAPI_WPS_CONNECTION_TIMEOUT;
	} else if (!(strcmp(sValue, "IN_PROCESS"))) {
		*wpsConnectionStatus =
		    LTQ_MAPI_WPS_CONNECTION_IN_PROGRESS;
	} else {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wps_connection_status",
			       "Invalid WPS state: %s", sValue);
		*wpsConnectionStatus =
		    LTQ_MAPI_WPS_CONNECTION_STATE_INVALID;
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	}

LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wps_connection_status", "");
	return ret;
}
#endif				/* #if defined (CONFIG_FEATURE_IFX_WIRELESS) */
