#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "ifx_common.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"

#if defined(CONFIG_FEATURE_LTQ_VLAN_SWITCH_PORT_ISOLATION) ||  defined(CONFIG_FEATURE_LTQ_SWITCH_PORT_ISOLATION) 
////////////////////////////////////////////////////////////////////////////////////
// Function: mapi_lan_get_ifname_from_conname
// Parameters: 	in ifname : interface name of the lan interface
//		out conname: conection name of lan interface
// return: IFX_SUCCESS/IFX_FAILURE
/////////////////////////////////////////////////////////////////////////////////// 
int32 mapi_lan_get_ifname_from_conname(char *ifname, char *conname)
{
	char8 *retStr = NULL,sValue[MAX_FILELINE_LEN];	
	uint32 outflag = IFX_F_DEFAULT;
	uint32 ret = IFX_SUCCESS;
	char8 buf[MAX_FILELINE_LEN];	
		
	IFX_MAPI_DEBUG(fd, "/tmp/mapi_lan_get_ifname_from_conname", "ifname=%s",ifname);
	if (ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_LAN_PORT_SEP, 
		"interface", ifname, &retStr) != IFX_SUCCESS) {
		ret = IFX_FAILURE;
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/mapi_lan_get_ifname_from_conname", "coudn't find the LAN interface name");
		goto IFX_Handler;
	} else {
		IFX_MAPI_DEBUG(fd, "/tmp/mapi_lan_get_ifname_from_conname", "retStr=%s",retStr);
		bzero(buf,MAX_FILELINE_LEN);
		sprintf(buf, "%s_%s", retStr, "conName");		
		IFX_MAPI_DEBUG(fd, "/tmp/mapi_lan_get_ifname_from_conname", "buf=%s",buf);
		if((ifx_GetObjData(FILE_RC_CONF, TAG_LAN_PORT_SEP, buf, IFX_F_GET_ANY,
				(IFX_OUT uint32 *)&outflag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			IFX_MAPI_DEBUG(fd, "/tmp/mapi_lan_get_ifname_from_conname", "coudn't find the lan connection name");
			goto IFX_Handler;					
		} else {
			strncpy(conname,sValue,MAX_NAME_LEN);	
		}
	}

IFX_Handler:
	 IFX_MEM_FREE(retStr);
	 return(ret);
}

/////////////////////////////////////////////////////////////////////////////////////
// Function: lan_port_sep_enable_get
// Parameters : none
// Return: enabled/ Disabled
// Description: returns the status of LAN port separation in the system
////////////////////////////////////////////////////////////////////////////////////
int32 lan_port_sep_enable_get()
{
        char8 sValue[MAX_FILELINE_LEN];
        lan_port_sep_status_t pSep;

        sValue[0] = '\0';

        memset(&pSep, 0x00, sizeof(pSep));

	IFX_MAPI_DEBUG(fd,"/tmp/mapi_lan_port_sep_status_get","");

        mapi_lan_port_sep_status_get(&pSep, IFX_F_DEFAULT);

        if (pSep.enable)     
                return IFX_SUCCESS;
        else
                return IFX_FAILURE;
}

///////////////////////////////////////////////////////////////////////////
// Function: mapi_lan_port_sep_info_get
// Parameters: 	out num_entries = number of lan ports
// 		out lan_port_sep_cfg_t **lps_conn_names = structure to return
//		in flags = flags passed from web
// Description: Reads lan port information
///////////////////////////////////////////////////////////////////////////
int32 mapi_lan_port_sep_info_get(int32 * num_entries,lan_port_sep_cfg_t **lps_conn_names,uint32 flags) {
	char8 sValue[MAX_FILELINE_LEN];
	char8 command[MAX_FILELINE_LEN];

	int i = 0;
	int ret = IFX_SUCCESS;
	char num;
	uint32 inflag = flags, outflag = 0;
	lan_port_sep_cfg_t *t_ptr = NULL;

	/* get the count of lan port present in rc.conf */
	memset(sValue, '\0', sizeof(sValue));
	if (ifx_GetObjData(FILE_RC_CONF, TAG_LAN_PORT_SEP,"lan_port_Count", inflag,&outflag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] COuld not retreive lan port count",__FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	} else {
		num = atoi(sValue);
		*num_entries = num;
	}

	if (num < 1 || num > 32767) {
		*num_entries = 0;
		*lps_conn_names = NULL;
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] No lan port sep",__FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	IFX_MEM_ALLOC(t_ptr, lan_port_sep_cfg_t*, num, sizeof(lan_port_sep_cfg_t));
	/* check if malloc failed, if so jump to IFX_Handler and free the already allocated buffer */
	if (t_ptr == NULL) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	/* otherwise assign  pointer to  the lps_conn_names */
	*lps_conn_names = t_ptr;

	/* allocate memory for num_entries of lan port in the output array lps_conn_names */
	for (i = 0; i < num; i++) {
		/* initialize the cache for this instance */
		sprintf(command, "%s_%d_",PREFIX_LAN_PORT_SEP,i);
		if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_LAN_PORT_SEP, command,IFX_F_INT_CACHE_INIT | flags, NULL,NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Failed to initialize cache for this instance",__FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}

		/* get the bridge value for this lan port index i */
		MAKE_SECTION_ELEMENT_TAG(PREFIX_LAN_PORT_SEP, i,"bridge", command);
		memset(sValue, '\0', sizeof(sValue));
		if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_LAN_PORT_SEP, command,inflag, &outflag,sValue)) == IFX_SUCCESS) {
			snprintf((*lps_conn_names + i)->bridge,MAX_NAME_LEN, "%s", sValue);
		}

		/* get the interface value for this lan port index i */
		MAKE_SECTION_ELEMENT_TAG(PREFIX_LAN_PORT_SEP, i,"interface", command);
		memset(sValue, '\0', sizeof(sValue));
		if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF,TAG_LAN_PORT_SEP, command,inflag, &outflag,sValue)) == IFX_SUCCESS) {
			snprintf((*lps_conn_names + i)->interface,MAX_NAME_LEN, "%s", sValue);
		}

		/* get the connName value for this lan port index i */
		MAKE_SECTION_ELEMENT_TAG(PREFIX_LAN_PORT_SEP, i,"conName", command);
		memset(sValue, '\0', sizeof(sValue));
		if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF,TAG_LAN_PORT_SEP, command,inflag, &outflag,sValue)) == IFX_SUCCESS) {
			snprintf((*lps_conn_names + i)->conName,MAX_NAME_LEN, "%s", sValue);
		}

		/* destroy the cache for this instance */
		sprintf(command, "%s_%d_", PREFIX_LAN_PORT_SEP,i);
		if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_LAN_PORT_SEP, command,IFX_F_INT_CACHE_DESTROY, NULL,NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Failed to destroy cache for this instance",__FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!",__FUNCTION__);
		*num_entries = 0;
		IFX_MEM_FREE(*lps_conn_names)
	}
	return IFX_SUCCESS;
}
///////////////////////////////////////////////////////////////////////////
// Function: mapi_lan_port_sep_status_get 
// Parameters: 	out lan_port_sep_status_t *lps = structure to return
//		in flags = flags passed from web
// Description: Reads the LAN port separation status 
///////////////////////////////////////////////////////////////////////////
int32 mapi_lan_port_sep_status_get(lan_port_sep_status_t *lps, uint32 flags)
{
	int32       iRet = IFX_SUCCESS;
	char8       sVal[MAX_IF_NAME];
	uint32      ulOutFlag=0;
        IFX_MAPI_DEBUG(fd, "/tmp/mapi_lan_port_sep_status_get", "");

	memset(lps, '\0', sizeof(lan_port_sep_status_t));

	if ((iRet = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_PORT_SEP,
	                           TAG_LAN_PORT_SEP "_enable",
	                           flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;

	IFX_MAPI_DEBUG(fd, "/tmp/mapi_lan_port_sep_status_get", "");
	lps->enable = atoi(sVal);
	
	if ((iRet = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_PORT_SEP,
	                           TAG_LAN_PORT_SEP "_drv",
	                           flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;

	IFX_MAPI_DEBUG(fd, "/tmp/mapi_lan_port_sep_status_get", "");
	lps->drvEnable = atoi(sVal);

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/mapi_lan_port_sep_status_get", "return");
	return (iRet);
}
/////////////////////////////////////////////////////////////////////////////////
// Function : mapi_lan_port_sep_status_set
// Parameters: 	in lan_port_sep_status_t lps = Enabled / Disable
//		in flags = IFX_F_MODIFY
// Description: function used to enable / disable LAN port sepataton
/////////////////////////////////////////////////////////////////////////////////
int32 mapi_lan_port_sep_status_set(lan_port_sep_status_t *lps, uint32 flags)
{
	int32   ret = IFX_SUCCESS;
	char8   buf[MAX_FILELINE_LEN],command[MAX_FILELINE_LEN],sVal[MAX_IF_NAME];
	IFX_NAME_VALUE_PAIR array_fvp[1], *array_changed_fvp = NULL;
	uint32 count =1,ulOutFlag=0, cur_val;
	NULL_TERMINATE(buf, 0, sizeof(buf));
	memset(array_fvp, 0, sizeof(array_fvp));
	flags |= IFX_F_MODIFY;

	IFX_MAPI_DEBUG(fd, "/tmp/mapi_lan_port_sep_status_set", "");

	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_PORT_SEP,
                                   TAG_LAN_PORT_SEP "_enable",
                                   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	cur_val = atoi(sVal);

	/************* Name Value Formation as per RC.CONF *************/
	strcpy(array_fvp[0].fieldname, "lan_port_sep_enable");
	sprintf(array_fvp[0].value, "%d", lps->enable);
	form_cfgdb_buf(buf, count, array_fvp);
	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_LAN_PORT_SEP, flags, 1, buf);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/mapi_lan_port_sep_status_set", "written rc.conf");
	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */	
	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/mapi_lan_port_sep_status_set", "config write succeeded");
	if(cur_val==0 && lps->enable==1) {
		memset(command, 0, sizeof(command));
	        sprintf(command,"/etc/rc.d/ltq_vlan_sep.sh start");
        	system(command);
	        sleep(3);
	} else if(cur_val==1 && lps->enable==0) {
		memset(command, 0, sizeof(command));
                sprintf(command,"/etc/rc.d/ltq_vlan_sep.sh stop");
                system(command);
                sleep(3);
	} 
IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/mapi_lan_port_sep_status_set", "return");

	IFX_MEM_FREE(array_changed_fvp)
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}
#endif //CONFIG_FEATURE_LTQ_VLAN_SWITCH_PORT_ISOLATION
