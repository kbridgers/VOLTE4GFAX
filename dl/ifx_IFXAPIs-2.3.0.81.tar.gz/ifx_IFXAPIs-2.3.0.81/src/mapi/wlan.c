/******************************************************************************

                               Copyright (c) 2008
                            Infineon Technologies AG
                     Am Campeon 1-12; 81726 Munich, Germany

  THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED NON-EXCLUSIVE,
  WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE AND SUBLICENSE THIS
  SOFTWARE IS FREE OF CHARGE.

  THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY DISCLAIMS
  ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR IMPLIED, INCLUDING
  WITHOUT LIMITATION, WARRANTIES OR REPRESENTATIONS OF WORKMANSHIP,
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, DURABILITY, THAT THE
  OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR FREE OR FREE OF ANY THIRD
  PARTY CLAIMS, INCLUDING WITHOUT LIMITATION CLAIMS OF THIRD PARTY INTELLECTUAL
  PROPERTY INFRINGEMENT.

  EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND EXCEPT
  FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE FOR ANY CLAIM
  OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
  ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
  DEALINGS IN THE SOFTWARE.

******************************************************************************/

/**
   \file wlan.c
*/

#ifdef CONFIG_FEATURE_IFX_WIRELESS
/* ========================================================================== */
/*                                 Includes                                   */
/* ========================================================================== */
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"

#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/socket.h>

int g_flagConfigLoaded = 0;

int g_flagSubsystemConfig = 0;
int g_flagPhyConfig = 0;
int g_flagMainConfig = 0;
int g_flagSecConfig = 0;
int g_flagCapabilities = 0;
int g_flagCapabilitiesSec = 0;
int g_flagMacControlAllConfig = 0;
extern int g_nVap;
int g_nMacControlAll = 0;
int g_flag_ssid_changed = 0;
int g_flagRadioEnaChanged = FALSE;
int g_flagRadioCfgChanged = FALSE;
int g_flagNetModeVapCfgChanged = FALSE;
extern int g_wpsState[];

LTQ_MAPI_WLAN_SubsystemCfg g_wlSs[LTQ_MAX_NUM_RADIO];
IFX_MAPI_WLAN_Capability g_wlCaps[LTQ_MAX_NUM_RADIO];
IFX_MAPI_WLAN_PhyCfg g_wlPhy[LTQ_MAX_NUM_RADIO];
IFX_MAPI_WLAN_MainCfg g_wlMain[LTQ_MAX_NUM_VAP];
IFX_MAPI_WLAN_SecCfg g_wlSec[LTQ_MAX_NUM_VAP];
IFX_MAPI_WLAN_MAC_Control g_wlMacControlAllConfig[LTQ_MAX_NUM_VAP*LTQ_MAX_NUM_MAC_FILTER_ENTRIES];
int g_flagAutoCocCfgChanged = FALSE;
LTQ_MAPI_WLAN_PhyAutoCocCfg	g_wlAutoCoc[LTQ_MAX_NUM_RADIO];

int g_flagWaveConfig = FALSE;
int g_flagWaveCfgChg = FALSE;
LTQ_MAPI_WLAN_VendorWaveCfg g_wlWaveCfg[LTQ_MAX_NUM_VAP];

#if defined (LTQ_AEI_CUST)
IFX_MAPI_WLAN_Standard gOpMode = IFX_MAPI_WLAN_STD_802_11_ALL;
#endif

/* included for definition of bool */
#include "ifx_api_ipt_common.h"

#if defined IFX_CONFIG_TSC_WLAN && !(defined HOST_PLATFORM)
//#include "max_errHandling.h"
#include "max_mac_typedefs.h"
#include "max_mib_define.h"
#endif				// IFX_CONFIG_TSC_WLAN

/* ========================================================================== */
/*                             Macro definitions                              */
/* ========================================================================== */
#define ISALNUM(ch) (isalnum(ch))
#define ISSPACE(ch) (isspace(ch))
#define ISASCII(ch) (isascii(ch))

/* allowed characters for SSID are all ASCII from code 32-126
	according to Wi-FI Testplan 2.0.19 */
#define ISALLOWED_SPECIAL(ch) (ch == '!' || ch == '_' || ch == '.' || \
                               ch == '-' || ch == '*' || ch == '?' || \
                               ch == '/' || ch == '(' || ch == ')' || \
							   ch == ';' || ch == '"' || ch == '#' || \
							   ch == '$' || ch == '%' || ch == '&' || \
							   ch == '\'' || ch == '+' || ch == ',' || \
							   ch == ':' || ch == '<' || ch == '=' || \
							   ch == '>' || ch == '`' || ch == '{' || \
							   ch == '}' || ch == '|' || ch == '~' || \
							   ch == '@' || ch == '\\' || ch == ']' || \
							   ch == '^' || ch == '[')

#define IFX_VALIDATE_SSID(wlan_main) { \
                           if((strlen(wlan_main->ssid) < 1) || (strlen(wlan_main->ssid) > 32)) { \
                              IFX_DBG("Please input valid ssid. Length of ssid should be between 1 and 32"); \
                              ret = IFX_FAILURE; \
                              goto IFX_Handler; \
                           } \
                           int32 i = 0, found = 0; \
                           for(i=0; i<strlen(wlan_main->ssid); i++) { \
                              /* check if any alphynumerical or allowed special character is present */ \
                              if(ISALNUM(wlan_main->ssid[i]) || ISALLOWED_SPECIAL(wlan_main->ssid[i])) { \
                                 found = 1; \
                                 break; \
                              } \
                           } \
                           /* check if any special character other than allowed list is present */ \
                           for (i=0; i<strlen(wlan_main->ssid); i++) \
                           { \
                              if(!(ISALNUM(wlan_main->ssid[i])) && \
                                 !(ISALLOWED_SPECIAL(wlan_main->ssid[i])) && \
                                 !(ISSPACE(wlan_main->ssid[i]))) \
                              { \
                                 found = 0; \
                                 goto flag_check; \
                              } \
                           } \
                           flag_check: \
                           if(!found) { \
                              IFX_DBG("Please input valid ssid. SSID cannot be blank"); \
                              ret = IFX_FAILURE; \
                              goto IFX_Handler; \
                           } \
                        }

#define WLAN_SUBSYSTEM_PARAM_COUNT			26
#define WLAN_PHY_PARAM_COUNT				45
#define WLAN_PHY_AUTO_COC_PARAM_COUNT		13
#define WLAN_VENDOR_WAVE_PARAM_COUNT		3
#define WLAN_MAIN_PARAM_COUNT				21
#define WLAN_SEC_PARAM_COUNT				15
#define WLAN_WEP_CONFIG_PARAM_COUNT			3
#define WLAN_PSK_PARAM_COUNT				5
#define WLAN_802_1X_PARAM_COUNT				14
#define WLAN_GLOBAL_MAC_CNTRL_PARAM_COUNT	5
#define WLAN_MAC_CNTRL_PARAM_COUNT			3

/* ========================================================================== */
/*                             Type definitions                               */
/* ========================================================================== */
/* lookup table for supported data rates based on standard */
struct basic_data_rate {
	int32 length;
	float rates[IFX_MAPI_WLAN_MAX_DATA_RATES_NUM];
};
struct basic_data_rate basic_data_rates_11a =
    { 8, {6.0, 9.0, 12.0, 18.0, 24.0, 36.0, 48.0, 54.0} };
struct basic_data_rate basic_data_rates_11b = { 4, {1.0, 2.0, 5.5, 11.0} };
struct basic_data_rate basic_data_rates_11bg =
    { 12, {1.0, 2.0, 5.5, 6.0, 9.0, 11.0, 12.0, 18.0, 24.0, 36.0, 48.0, 54.0} };

/* ========================================================================== */
/*                             Global variables                               */
/* ========================================================================== */

char8 *wlan_main_params[] = { "cpeId", "pcpeId", "radioCpeId", "apEnable",
	"apName", "apType", "ssid", "ssidMode", "bssidOverride", "bssid",
	"basicDataRate", "operDataRate", "maxBitRate", "vlanId", "apIsolationEna",
	"wmmEna", "uapsdEna", "wdsEna", "maxSta", "minSta", "networkMode"
};

char8 *wlan_phy_params[] =
    { "cpeId", "pcpeId", "standard", "country", "usageEnv",
	"freqBand", "channelNo", "autoChanEna", "beaconTxEna",
	"beaconInt", "dtimInt", "rts", "fts", "powerLvl",
	"radioEnable", "autoRateFallbackEna", "staticRate",
	"preamble", "nChanWidth", "nExtChanPos", "nGuardIntvl", "nMCS",
	"nDivEna", "nDivDir", "nDivAntennaNum", "nSTBCrx", "nBAWsize",
	"nAMPDUena", "nAMPDUdir", "nAMPDUlen", "nAMPDUfrms",
	"nAMSDUena", "nAMSDUdir", "nAMSDUlen", "hRadarEna", "nLDPCen",
	"beamFrmType", "mctoUcEna", "boostMode", "n2040CoexEna",
	"n40IntoleranceEna", "nTransDelay", "nObssScanInt", "nCoexForceApParams",
	"netModeClass"
};

char8 *wlan_phy_auto_coc_params[] = { "cpeId", "pcpeId", "autoCoC",
	"prevAutoCoC", "numAntennas", "prevNumAntennas", "autoCoC1x1TimerInterval",
	"autoCoC2x2TimerInterval", "autoCoC3x3TimerInterval",
	"autoCoC1x1HighLimit", "autoCoC2x2LowLimit", "autoCoC2x2HighLimit",
	"autoCoC3x3LowLimit"
};

char8 *wlan_vendor_wave_params[] = { "cpeId", "pcpeId", "logServerEna"
};

char8 *wlan_sec_params[] = { "cpeId", "pcpeId", "beaconType", "authType",
	"encrType", "basicAuthType", "basicEncrType", "wpaAuthType",
	"wpaEncrType", "wpa2AuthType", "wpa2EncrType", "wepEncrLvl",
	"wepKeyType", "wepKeyIndx", "macAddrCntrlType"
};

char8 *wlan_wep_config_params[] = { "cpeId", "pcpeId", "key" };

char8 *wlan_psk_params[] =
    { "cpeId", "pcpeId", "pskFlag", "passPhrase", "psk" };

char8 *wlan_802_1x_params[] = { "cpeId", "pcpeId", "grpKeyEna", "grpKeyIntvl",
	"wpa2PreAuthEna", "reAuthIntvl", "localRadius",
	"authType", "authProto", "radiusIP", "radiusPort",
	"radiusSecret", "domainName", "userName"
};

char8 *wlan_global_mac_cntrl_params[] =
    { "cpeId", "pcpeId", "ifType", "macAddr", "control" };
char8 *wlan_mac_cntrl_params[] = { "cpeId", "pcpeId", "macAddr" };

IFX_MAPI_WLAN_RegDomain chList_2_4 	= { 1, {0} },
						chList_5 	= { 1, {0} };

/** definition of used wlan channels in different regulatory domains */
static const IFX_MAPI_WLAN_RegDomain regDomainWorld_11a =
    { IFX_MAPI_WLAN_REGDOMAIN_WORLD_11A_LENGTH,
	{IFX_MAPI_WLAN_CHANNEL_36, IFX_MAPI_WLAN_CHANNEL_40,
	 IFX_MAPI_WLAN_CHANNEL_44, IFX_MAPI_WLAN_CHANNEL_48,
	 IFX_MAPI_WLAN_CHANNEL_52, IFX_MAPI_WLAN_CHANNEL_56,
	 IFX_MAPI_WLAN_CHANNEL_60, IFX_MAPI_WLAN_CHANNEL_64,
	 IFX_MAPI_WLAN_CHANNEL_100, IFX_MAPI_WLAN_CHANNEL_104,
	 IFX_MAPI_WLAN_CHANNEL_108, IFX_MAPI_WLAN_CHANNEL_112,
	 IFX_MAPI_WLAN_CHANNEL_116, IFX_MAPI_WLAN_CHANNEL_120,
	 IFX_MAPI_WLAN_CHANNEL_124, IFX_MAPI_WLAN_CHANNEL_128,
	 IFX_MAPI_WLAN_CHANNEL_132, IFX_MAPI_WLAN_CHANNEL_136,
	 IFX_MAPI_WLAN_CHANNEL_140, IFX_MAPI_WLAN_CHANNEL_149,
	 IFX_MAPI_WLAN_CHANNEL_153, IFX_MAPI_WLAN_CHANNEL_157,
	 IFX_MAPI_WLAN_CHANNEL_161, IFX_MAPI_WLAN_CHANNEL_165}
};
static const IFX_MAPI_WLAN_RegDomain regDomainEurope_11a =
    { IFX_MAPI_WLAN_REGDOMAIN_EUROPE_11A_LENGTH,
	{IFX_MAPI_WLAN_CHANNEL_36, IFX_MAPI_WLAN_CHANNEL_40,
	 IFX_MAPI_WLAN_CHANNEL_44, IFX_MAPI_WLAN_CHANNEL_48,
	 IFX_MAPI_WLAN_CHANNEL_52, IFX_MAPI_WLAN_CHANNEL_56,
	 IFX_MAPI_WLAN_CHANNEL_60, IFX_MAPI_WLAN_CHANNEL_64,
	 IFX_MAPI_WLAN_CHANNEL_100, IFX_MAPI_WLAN_CHANNEL_104,
	 IFX_MAPI_WLAN_CHANNEL_108, IFX_MAPI_WLAN_CHANNEL_112,
	 IFX_MAPI_WLAN_CHANNEL_116, IFX_MAPI_WLAN_CHANNEL_120,
	 IFX_MAPI_WLAN_CHANNEL_124, IFX_MAPI_WLAN_CHANNEL_128,
	 IFX_MAPI_WLAN_CHANNEL_132, IFX_MAPI_WLAN_CHANNEL_136,
	 IFX_MAPI_WLAN_CHANNEL_140}
};
static const IFX_MAPI_WLAN_RegDomain regDomainJapan_11a =
    { IFX_MAPI_WLAN_REGDOMAIN_JAPAN_11A_LENGTH,
	{IFX_MAPI_WLAN_CHANNEL_36, IFX_MAPI_WLAN_CHANNEL_40,
	 IFX_MAPI_WLAN_CHANNEL_44, IFX_MAPI_WLAN_CHANNEL_48,
	 IFX_MAPI_WLAN_CHANNEL_52, IFX_MAPI_WLAN_CHANNEL_56,
	 IFX_MAPI_WLAN_CHANNEL_60, IFX_MAPI_WLAN_CHANNEL_64,
	 IFX_MAPI_WLAN_CHANNEL_100, IFX_MAPI_WLAN_CHANNEL_104,
	 IFX_MAPI_WLAN_CHANNEL_108, IFX_MAPI_WLAN_CHANNEL_112,
	 IFX_MAPI_WLAN_CHANNEL_116, IFX_MAPI_WLAN_CHANNEL_120,
	 IFX_MAPI_WLAN_CHANNEL_124, IFX_MAPI_WLAN_CHANNEL_128,
	 IFX_MAPI_WLAN_CHANNEL_132, IFX_MAPI_WLAN_CHANNEL_136,
	 IFX_MAPI_WLAN_CHANNEL_140, IFX_MAPI_WLAN_CHANNEL_184,
	 IFX_MAPI_WLAN_CHANNEL_188, IFX_MAPI_WLAN_CHANNEL_192,
	 IFX_MAPI_WLAN_CHANNEL_196}
};
static const IFX_MAPI_WLAN_RegDomain regDomainChina_11a =
    { IFX_MAPI_WLAN_REGDOMAIN_CHINA_11A_LENGTH,
	{IFX_MAPI_WLAN_CHANNEL_149, IFX_MAPI_WLAN_CHANNEL_153,
	 IFX_MAPI_WLAN_CHANNEL_157,
	 IFX_MAPI_WLAN_CHANNEL_161, IFX_MAPI_WLAN_CHANNEL_165}
};
static const IFX_MAPI_WLAN_RegDomain regDomainWorld_11g =
    { IFX_MAPI_WLAN_REGDOMAIN_WORLD_11G_LENGTH,
	{IFX_MAPI_WLAN_CHANNEL_1, IFX_MAPI_WLAN_CHANNEL_2,
	 IFX_MAPI_WLAN_CHANNEL_3,
	 IFX_MAPI_WLAN_CHANNEL_4,
	 IFX_MAPI_WLAN_CHANNEL_5, IFX_MAPI_WLAN_CHANNEL_6,
	 IFX_MAPI_WLAN_CHANNEL_7,
	 IFX_MAPI_WLAN_CHANNEL_8,
	 IFX_MAPI_WLAN_CHANNEL_9, IFX_MAPI_WLAN_CHANNEL_10,
	 IFX_MAPI_WLAN_CHANNEL_11, IFX_MAPI_WLAN_CHANNEL_12,
	 IFX_MAPI_WLAN_CHANNEL_13}
};
static const IFX_MAPI_WLAN_RegDomain regDomainUSA_11g =
    { IFX_MAPI_WLAN_REGDOMAIN_USA_11G_LENGTH,
	{IFX_MAPI_WLAN_CHANNEL_1, IFX_MAPI_WLAN_CHANNEL_2,
	 IFX_MAPI_WLAN_CHANNEL_3,
	 IFX_MAPI_WLAN_CHANNEL_4,
	 IFX_MAPI_WLAN_CHANNEL_5, IFX_MAPI_WLAN_CHANNEL_6,
	 IFX_MAPI_WLAN_CHANNEL_7,
	 IFX_MAPI_WLAN_CHANNEL_8,
	 IFX_MAPI_WLAN_CHANNEL_9, IFX_MAPI_WLAN_CHANNEL_10,
	 IFX_MAPI_WLAN_CHANNEL_11}
};
static const IFX_MAPI_WLAN_RegDomain regDomainJapan_11g =
    { IFX_MAPI_WLAN_REGDOMAIN_JAPAN_11G_LENGTH,
	{IFX_MAPI_WLAN_CHANNEL_1, IFX_MAPI_WLAN_CHANNEL_2,
	 IFX_MAPI_WLAN_CHANNEL_3,
	 IFX_MAPI_WLAN_CHANNEL_4,
	 IFX_MAPI_WLAN_CHANNEL_5, IFX_MAPI_WLAN_CHANNEL_6,
	 IFX_MAPI_WLAN_CHANNEL_7,
	 IFX_MAPI_WLAN_CHANNEL_8,
	 IFX_MAPI_WLAN_CHANNEL_9, IFX_MAPI_WLAN_CHANNEL_10,
	 IFX_MAPI_WLAN_CHANNEL_11, IFX_MAPI_WLAN_CHANNEL_12,
	 IFX_MAPI_WLAN_CHANNEL_13}
};
static const IFX_MAPI_WLAN_RegDomain regDomainJapan_11b =
    { IFX_MAPI_WLAN_REGDOMAIN_JAPAN_11B_LENGTH,
	{IFX_MAPI_WLAN_CHANNEL_1, IFX_MAPI_WLAN_CHANNEL_2,
	 IFX_MAPI_WLAN_CHANNEL_3,
	 IFX_MAPI_WLAN_CHANNEL_4,
	 IFX_MAPI_WLAN_CHANNEL_5, IFX_MAPI_WLAN_CHANNEL_6,
	 IFX_MAPI_WLAN_CHANNEL_7,
	 IFX_MAPI_WLAN_CHANNEL_8,
	 IFX_MAPI_WLAN_CHANNEL_9, IFX_MAPI_WLAN_CHANNEL_10,
	 IFX_MAPI_WLAN_CHANNEL_11, IFX_MAPI_WLAN_CHANNEL_12,
	 IFX_MAPI_WLAN_CHANNEL_13, IFX_MAPI_WLAN_CHANNEL_14}
};

/* global string array to hold the buffer returned from varous scripts */
char8 sResultFromScript[MAX_DATA_LEN];

#if defined (IFX_CONFIG_TSC_WLAN) && !(defined HOST_PLATFORM)
/* lookup table for list of channels supported based on country and mode */
/* 802.11A Standard */
// static const mac_channelDomain_t  macChannelDomainIND5 = {11, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11}};
static const mac_channelDomain_t macChannelDomainFCC5 =
    { 12, {36, 40, 44, 48, 52, 56, 60, 64, 149, 153, 157, 161} };
static const mac_channelDomain_t macChannelDomainIC5 =
    { 12, {36, 40, 44, 48, 52, 56, 60, 64, 149, 153, 157, 161} };
static const mac_channelDomain_t macChannelDomainESP5 =
    { 17, {36, 40, 44, 48, 52, 56, 60, 64, 104, 108, 112, 116, 120, 124, 128,
	   132, 140}
};
static const mac_channelDomain_t macChannelDomainFRA5 =
    { 8, {36, 40, 44, 48, 52, 56, 60, 64} };
static const mac_channelDomain_t macChannelDomainCHA5 =
    { 4, {149, 153, 157, 161} };
// static const mac_channelDomain_t  macChannelDomainJPN5 = {8, {36, 40, 44, 48, 52, 56, 60, 64}};
static const mac_channelDomain_t macChannelDomainJPN5 =
    { 7, {1, 2, 3, 34, 38, 42, 46} };
/* 802.11b or 802.11b/g Standard */
static const mac_channelDomain_t macChannelDomainIND24 =
    { 11, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11} };
static const mac_channelDomain_t macChannelDomainFCC24 =
    { 11, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11} };
static const mac_channelDomain_t macChannelDomainIC24 =
    { 11, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11} };
static const mac_channelDomain_t macChannelDomainEMEA24 =
    { 13, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13} };
// static const mac_channelDomain_t  macChannelDomainESP24 = {2, {10, 11}}; as per TSC
static const mac_channelDomain_t macChannelDomainESP24 =
    { 11, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11} };
// static const mac_channelDomain_t  macChannelDomainFRA24 = {4, {10, 11, 12, 13}}; as per TSC
static const mac_channelDomain_t macChannelDomainFRA24 =
    { 11, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11} };
static const mac_channelDomain_t macChannelDomainCHA24 =
    { 13, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13} };
static const mac_channelDomain_t macChannelDomainJPN24b =
    { 14, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14} };
static const mac_channelDomain_t macChannelDomainJPN24bg =
    { 13, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13} };
#endif				// IFX_CONFIG_TSC_WLAN

/* ========================================================================== */
/*                           Function prototypes                              */
/* ========================================================================== */
static int32 mapiWlanPersonalConfig(uint32 oper, IFX_MAPI_WLAN_SecCfg * wlSec);
static int32 mapiWlan8021XConfig(uint32 oper, IFX_MAPI_WLAN_SecCfg * wlSec);
static int32 mapiWlanWepConfig(uint32 oper, IFX_MAPI_WLAN_SecCfg * wlSec, int32 flags);
static int32 mapiWlanSetPersonalConfig(uint32 oper, IFX_MAPI_WLAN_PSKey * wlPsk,
				       uint32 flags);
static int32 mapiWlanSetWepInSecurity(uint32 operation,
				      IFX_MAPI_WLAN_WEP_Cfg * wlWepCfg,
				      int32 passed_index, uint32 flags);
static int32 mapiWlanGetObjectFromRcConf(IFX_ID iid,
					 IFX_NAME_VALUE_PAIR * array_fvp);

static
int32 get_mac_addr(int id , char *mac_addr);
static
int32 get_mac_from_base_lan_mac(char8 *psMac , int32 passed_index);

static void mapiWlanChkPhyCfgChg(int32 idx, IFX_MAPI_WLAN_PhyCfg * wlPhy);
static bool mapiWlanChkMainCfgChg(int32 idx, IFX_MAPI_WLAN_MainCfg * wlMain);
static bool mapiWlanChkSecCfgChg(int32 idx, IFX_MAPI_WLAN_SecCfg * wlSec);
static int32 ltq_mapi_set_wlan_phy_auto_coc_config(uint32 oper,
	LTQ_MAPI_WLAN_PhyAutoCocCfg * wlPhyAutoCocCfg, uint32 flags);

/* ========================================================================== */
/*                         Function implementation                            */
/* ========================================================================== */
static int32
ltq_mapi_set_wlan_phy_auto_coc_config(uint32 oper,
	LTQ_MAPI_WLAN_PhyAutoCocCfg *wlPhyAutoCocCfg, uint32 flags)
{
	int32 count=0, changed_count=0, passed_index=-1, ret=IFX_SUCCESS, i=0;
	char8 conf_buf[MAX_SECTION_DATA_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_PHY_AUTO_COC_PARAM_COUNT];
	IFX_NAME_VALUE_PAIR *array_changed_fvp = NULL;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_phy_auto_coc_config", "");
	/*
	   initalize buffer conf_buf which is used for two purposes: - holding the
	   configuration for wlPhyAutoCocCfg to be written to rc.conf - holding the commands
	   for system calls */
	memset(conf_buf, 0x00, sizeof(conf_buf));
	/*
	   initalize buffer array_fvp which is used for storing the new
	   configuration of wlWdsCfg in field-value format */
	memset(array_fvp, 0x00, sizeof(array_fvp));

	/*************************** Validation Block ****************************/
	/* for operations other than DELETE do the verification of input params */
	if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer (such as is NULL) */
		IFX_VALIDATE_PTR(wlPhyAutoCocCfg)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_phy_auto_coc_config",
			"flags: 0x%x", flags);
		/* Do simple validation of flags such as less than 0 */
		IFX_VALIDATE_FLAGS(flags)
	}

   /****************************** Prolog Block ******************************/
	/*
	   based on the operation (ADD or DELETE or MODIFY), the flags variable is
	   appended with internal flags
	*/
	if (oper == IFX_OP_MOD)
		flags |= IFX_F_MODIFY;
	else {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_phy_auto_coc_config",
			"oper: 0x%x", oper);
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* section name of this object is TAG_WLAN_PHY_AUTO_COC */
	sprintf(wlPhyAutoCocCfg->iid.cpeId.secName, "%s", TAG_WLAN_PHY_AUTO_COC);
	/* section name of parent object is TAG_WLAN_PHY */
	sprintf(wlPhyAutoCocCfg->iid.pcpeId.secName, "%s", TAG_WLAN_PHY);

	/***************** Name Value Formation as per RC.CONF *******************/
	ifx_fill_ArrayFvp_FName(array_fvp, 0, WLAN_PHY_AUTO_COC_PARAM_COUNT,
		wlan_phy_auto_coc_params);

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_phy_auto_coc_config",
		"cpeId: %d", wlPhyAutoCocCfg->iid.cpeId.Id);
	ifx_fill_ArrayFvp_intValues(array_fvp, 0, 2,
		(int32 *) &wlPhyAutoCocCfg->iid.cpeId.Id,
		&wlPhyAutoCocCfg->iid.pcpeId.Id);

	sprintf(array_fvp[2].value, "%u", wlPhyAutoCocCfg->autoCocEnable);
	sprintf(array_fvp[3].value, "%u", wlPhyAutoCocCfg->prevAutoCocEnable);
	sprintf(array_fvp[4].value, "%u", wlPhyAutoCocCfg->nAntennas);
	sprintf(array_fvp[5].value, "%u", wlPhyAutoCocCfg->nPrevAntennas);
	sprintf(array_fvp[6].value, "%d", wlPhyAutoCocCfg->timerIntval_1x1);
	sprintf(array_fvp[7].value, "%d", wlPhyAutoCocCfg->timerIntval_2x2);
	sprintf(array_fvp[8].value, "%d", wlPhyAutoCocCfg->timerIntval_3x3);
	sprintf(array_fvp[9].value, "%d", wlPhyAutoCocCfg->highLim_1x1);
	sprintf(array_fvp[10].value, "%d", wlPhyAutoCocCfg->lowLim_2x2);
	sprintf(array_fvp[11].value, "%d", wlPhyAutoCocCfg->highLim_2x2);
	sprintf(array_fvp[12].value, "%d", wlPhyAutoCocCfg->lowLim_3x3);

	passed_index = -1;
	count = WLAN_PHY_AUTO_COC_PARAM_COUNT;

	for (i = 0; i < count; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_phy_auto_coc_config",
			"fvp_field: %s, fvp_value:%s", array_fvp[i].fieldname,
			array_fvp[i].value);

	/* Get Config Index in case of modify/delete operations from CPEID */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlPhyAutoCocCfg->iid.cpeId,
		passed_index)

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_phy_auto_coc_config",
		"passed_index: %d", passed_index);
    /* determine the configuration index name is partial since index is not
       known fill array_fvp[] */
    if (ifx_get_conf_index_and_nv_pairs(&wlPhyAutoCocCfg->iid, passed_index,
		PREFIX_WLAN_PHY_AUTO_COC, count, array_fvp, flags) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_phy_auto_coc_config", "");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	for (i = 0; i < count; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_phy_auto_coc_config",
			"fvp_field: %s, fvp_value:%s", array_fvp[i].fieldname,
			array_fvp[i].value);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_phy_auto_coc_config",
		"passed_index: %d", passed_index);

	/********* ACL Checking block - MUST for MODIFY/DELETE operations ********/
	if (IFX_INT_DONT_CHECK_ACL_F_NOT_SET(flags)) {
		CHECK_ACL_RET(wlPhyAutoCocCfg->iid, count, array_fvp, changed_count,
			array_changed_fvp, flags, IFX_Handler)
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_phy_auto_coc_config", "");

	/******************* System Config File Update Block *********************/
	/**
		Convert the name value pair in array_fvp into string format expected by
		rc.conf file
	*/
	form_cfgdb_buf(conf_buf, count, array_fvp);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_phy_auto_coc_config",
		"conf_buf: %s", conf_buf);

	/* RC.CONF Configuration block */
	if ((ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_PHY_AUTO_COC, flags, 1,
		conf_buf)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_phy_auto_coc_config", "");
		goto IFX_Handler;
	}

	/******************** Device Configuration Block *************************/
	/**
		n/a as coc config is only called as subfunction from phy config
	*/

	/*************************** Notification Block **************************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if (IFX_MODIFY_F_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION(wlPhyAutoCocCfg->iid, changed_count,
			array_changed_fvp, flags, IFX_Handler)
	}

	/**************************** Epilog Block *******************************/
	/**
		Update the IID mappings in the mappings section for ADD/DELETE
		no add/delete for coc object
	*/

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_phy_auto_coc_config", "");
	/* Updating Persistent Storage */
	if ((ret = ifx_config_write(FILE_RC_CONF, flags)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_phy_auto_coc_config", "");
		goto IFX_Handler;
	}


IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_phy_auto_coc_config",
		"ret: %d", ret);
	return ret;
}

/**
	This api reads wlan wave specific parameters from rc.conf and returns them
	in wlVendorWaveCfg

   \param   wlVendorWaveCfg - pointer to LTQ_MAPI_WLAN_VendorWaveCfg structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/

int32 ltq_mapi_get_wlan_vendor_wave_cfg(
	LTQ_MAPI_WLAN_VendorWaveCfg * wlVendorWaveCfg, uint32 flags)
{
	int32					passed_index = -1, ret = IFX_SUCCESS;
	LTQ_MAPI_WLAN_VendorWaveCfg	*wlVendorWaveCfgAll = NULL;
	uint32					nEntries = 0;

	LTQ_LOG_TIMESTAMP("Begin");

	sprintf(wlVendorWaveCfg->iid.cpeId.secName, "%s", TAG_WLAN_VENDOR_WAVE);

	/* get index from cpeid: example wlwds_0_cpeId="2" => passed_index = 2 */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlVendorWaveCfg->iid.cpeId, passed_index)
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_vendor_wave_cfg", "passed_index: %d",
		passed_index);

	/* if configuration is already available, take it from there (g_wlWdsCfg) */
	if (!g_flagWaveConfig) {
		if ((ret = ltq_mapi_get_all_wlan_vendor_wave_cfg(&nEntries,
			&wlVendorWaveCfgAll, IFX_F_DEFAULT)) != IFX_SUCCESS) {
				goto IFX_Handler;
		}
	}
	memcpy(wlVendorWaveCfg, &g_wlWaveCfg[passed_index], sizeof(LTQ_MAPI_WLAN_VendorWaveCfg));

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_vendor_wave_cfg", "ret: %d", ret);
	IFX_MEM_FREE(wlVendorWaveCfgAll);
	LTQ_LOG_TIMESTAMP("Done");
	return ret;
}

/**
   This api reads the count, gets the complete wlan_wds object and saves
   the configuration to wlWdsCfg

   \param   numEntries  -

   \param   wlWdsCfg    - pointer to LTQ_MAPI_WLAN_WDS_Cfg structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ltq_mapi_get_all_wlan_vendor_wave_cfg(uint32 * numEntries,
	LTQ_MAPI_WLAN_VendorWaveCfg ** wlVendorWaveCfg, uint32 flags)
{
	int32	ret = IFX_SUCCESS, nCount = 0, i = 0, nParamCount = 0;
	char8	sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN], *sWlanWaveObject = NULL;
	IFX_NAME_VALUE_PAIR	array_fvp[LTQ_MAX_NUM_VAP*WLAN_VENDOR_WAVE_PARAM_COUNT];
	uint32 outFlag = IFX_F_DEFAULT;

	LTQ_LOG_TIMESTAMP("Begin");
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_vendor_wave_cfg", "");

	MAKE_SECTION_COUNT_TAG(TAG_WLAN_VENDOR_WAVE, buf);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_VENDOR_WAVE, buf, flags,
		&outFlag, sValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_vendor_wave_cfg", "");
		goto IFX_Handler;
	}

	nCount = atoi(sValue);
	if (nCount <= 0) {
		*numEntries = 0;
		*wlVendorWaveCfg = NULL;
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_vendor_wave_cfg", "");
		goto IFX_Handler;
	}

	*wlVendorWaveCfg = NULL;
	if (nCount <= LTQ_MAX_NUM_VAP) {
		IFX_MEM_ALLOC((*wlVendorWaveCfg), LTQ_MAPI_WLAN_VendorWaveCfg *, nCount,
			sizeof(LTQ_MAPI_WLAN_VendorWaveCfg))
	} else {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_vendor_wave_cfg", "");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* if configuration is already available, return immediately */
	if (g_flagWaveConfig) {
		memcpy(*wlVendorWaveCfg, g_wlWaveCfg,
			sizeof(LTQ_MAPI_WLAN_VendorWaveCfg) * nCount);
		*numEntries = g_nVap;
		goto IFX_Handler;
	}

	sprintf(buf, "%s_", PREFIX_WLAN_VENDOR_WAVE);
	if ((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_VENDOR_WAVE, buf,
		IFX_F_DEFAULT, &sWlanWaveObject)) != IFX_SUCCESS)
		goto IFX_Handler;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_vendor_wave_cfg",
		"buf: %s, sValue: %s", buf, sWlanWaveObject);

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sWlanWaveObject, &nParamCount, array_fvp);

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_vendor_wave_cfg", "");
	for (i = 0; i < nCount; i++) {
		sprintf((*wlVendorWaveCfg + i)->iid.cpeId.secName, "%s", TAG_WLAN_VENDOR_WAVE);
		sprintf((*wlVendorWaveCfg + i)->iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
		(*wlVendorWaveCfg + i)->iid.cpeId.Id 	=
			atoi(array_fvp[i * WLAN_VENDOR_WAVE_PARAM_COUNT].value);
		(*wlVendorWaveCfg + i)->iid.pcpeId.Id 	=
			atoi(array_fvp[i * WLAN_VENDOR_WAVE_PARAM_COUNT + 1].value);
		(*wlVendorWaveCfg + i)->logServerEna 	=
			atoi(array_fvp[i * WLAN_VENDOR_WAVE_PARAM_COUNT + 2].value);
	}
	*numEntries = nCount;
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_vendor_wave_cfg", "*numEntries: %d", *numEntries);

	/* store in global variables for later usage */
	memcpy(g_wlWaveCfg, *wlVendorWaveCfg, sizeof(LTQ_MAPI_WLAN_VendorWaveCfg) * nCount);

	/* flag to indicate that WAVE configuration is available in global variable */
	g_flagWaveConfig = 1;

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_vendor_wave_cfg", "ret: %d", ret);
	IFX_MEM_FREE(sWlanWaveObject);
	/* free memory in case of error, otherwise it gets freed in calling
	   function */
	if (ret != IFX_SUCCESS)
		IFX_MEM_FREE(*wlVendorWaveCfg)
	LTQ_LOG_TIMESTAMP("Done");
	return ret;
}

int32 ltq_mapi_set_wlan_vendor_wave_cfg(uint32 oper,
	LTQ_MAPI_WLAN_VendorWaveCfg *wlVendorWaveCfg, uint32 flags)
{
	int32 count=0, passed_index = -1, ret = IFX_SUCCESS, i = 0;
	char8 conf_buf[MAX_SECTION_DATA_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_VENDOR_WAVE_PARAM_COUNT];
	IFX_NAME_VALUE_PAIR *array_changed_fvp = NULL;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg", "");
	/*
	   initalize buffer conf_buf which is used for two purposes: - holding the
	   configuration for wlFwRecoverCfg to be written to rc.conf - holding the commands
	   for system calls */
	memset(conf_buf, 0x00, sizeof(conf_buf));
	/*
	   initalize buffer array_fvp which is used for storing the new
	   configuration of wlWdsCfg in field-value format */
	memset(array_fvp, 0x00, sizeof(array_fvp));

	/*************************** Validation Block ****************************/
	/* for operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer (such as is NULL) */
		IFX_VALIDATE_PTR(wlVendorWaveCfg)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg",
			"flags: 0x%x", flags);
		/* Do simple validation of flags such as less than 0 */
		IFX_VALIDATE_FLAGS(flags)
	}

   /****************************** Prolog Block ******************************/
	/*
	   based on the operation (ADD or DELETE or MODIFY), the flags variable is
	   appended with internal flags
	*/
	if (oper == IFX_OP_DEL) {
		flags |= IFX_F_DELETE;
	} else if (oper == IFX_OP_ADD) {
		flags |= IFX_F_INT_ADD;
	} else {
		flags |= IFX_F_MODIFY;
	}

	/* section name of this object is TAG_WLAN_PHY_AUTO_COC */
	sprintf(wlVendorWaveCfg->iid.cpeId.secName, "%s", TAG_WLAN_VENDOR_WAVE);
	/* section name of parent object is TAG_WLAN_PHY */
	sprintf(wlVendorWaveCfg->iid.pcpeId.secName, "%s", TAG_WLAN_PHY);

	/*************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_ADD_F_SET(flags)) {
		/*
		   get the next cpe id for the section wlFwRecoverCfg from the next_cpe_id
		   section in rc.conf and store it as cpeId; the distinct parameter
		   fwFastRecoverEna is provided for TR69 */
		if (ifx_get_IID(&wlVendorWaveCfg->iid, "logServerEna") !=
			IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg", "");
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg", "tr69Id: %s",
			wlVendorWaveCfg->iid.tr69Id);
	}

	/***************** Name Value Formation as per RC.CONF *******************/
	if (IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, 0, WLAN_VENDOR_WAVE_PARAM_COUNT,
			wlan_vendor_wave_params);

		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg",
			"cpeId: %d", wlVendorWaveCfg->iid.cpeId.Id);
		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 2,
			(int32 *) &wlVendorWaveCfg->iid.cpeId.Id,
			&wlVendorWaveCfg->iid.pcpeId.Id);

		sprintf(array_fvp[2].value, "%u", wlVendorWaveCfg->logServerEna);
	}	
	passed_index = -1;
	count = WLAN_VENDOR_WAVE_PARAM_COUNT;

	for (i = 0; i < count; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg",
			"fvp_field: %s, fvp_value:%s", array_fvp[i].fieldname,
			array_fvp[i].value);

	/* Get Config Index in case of modify/delete operations from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlVendorWaveCfg->iid.cpeId,
			passed_index)
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg",
		"passed_index: %d", passed_index);
    /* determine the configuration index name is partial since index is not
       known fill array_fvp[] */
    if (ifx_get_conf_index_and_nv_pairs(&wlVendorWaveCfg->iid, passed_index,
		PREFIX_WLAN_VENDOR_WAVE, count, array_fvp, flags) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg", "");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	for (i = 0; i < count; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg",
			"fvp_field: %s, fvp_value:%s", array_fvp[i].fieldname,
			array_fvp[i].value);

	/********* ACL Checking block - MUST for MODIFY/DELETE operations ********/

	/******************* System Config File Update Block *********************/
	/**
		Convert the name value pair in array_fvp into string format expected by
		rc.conf file
	*/
	form_cfgdb_buf(conf_buf, count, array_fvp);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg",
		"conf_buf: %s", conf_buf);

	/* RC.CONF Configuration block */
	if ((ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_VENDOR_WAVE, flags, 1,
		conf_buf)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg", "");
		goto IFX_Handler;
	}

	/******************** Device Configuration Block *************************/
	if (IFX_MODIFY_F_NOT_SET(flags)) {
		ret = ifx_UpdateCountInSection(FILE_RC_CONF, TAG_WLAN_VENDOR_WAVE, flags);
		if (ret != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg", "ret: %d", ret);
			goto IFX_Handler;
		}
	}

	/*************************** Notification Block **************************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	/* n/a ? */

	/**************************** Epilog Block *******************************/
	/*
	 * this will Compact the section and also update the count for both ADD and
	 * DELETE
	 */
	if (IFX_MODIFY_F_NOT_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg", "");
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_WLAN_VENDOR_WAVE, flags);
	}

	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_MODIFY_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg", "");
	} else if (IFX_INT_ADD_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg", "");
		/*
			in case of ADD operation update the ID Mappings, then send
			notification
		*/
		ret = ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WLAN_VENDOR_WAVE);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg", "");
		if (ret != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg",
				"ret: %d", ret);
			goto IFX_Handler;
		}
	} else if (IFX_DELETE_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg", "");
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg", "");
	/* Updating Persistent Storage */
	if ((ret = ifx_config_write(FILE_RC_CONF, flags)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg", "");
		goto IFX_Handler;
	}

	if (IFX_MODIFY_F_SET(flags)) {
		if (wlVendorWaveCfg->logServerEna != g_wlWaveCfg[passed_index].logServerEna) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg", "");
			g_flagWaveCfgChg = TRUE;
		}
	}
	if (IFX_DELETE_F_SET(flags)) {
		/* reset flags to reload configuration */
		g_flagWaveConfig = 0;
	} else {
		/* update cpeId and pcpeID and save to global storage */
		wlVendorWaveCfg->iid.cpeId.Id 	= atoi(array_fvp[0].value);
		wlVendorWaveCfg->iid.pcpeId.Id = atoi(array_fvp[1].value);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg",
			"cpeId: %d, pcpeId: %d", wlVendorWaveCfg->iid.cpeId.Id,
			wlVendorWaveCfg->iid.pcpeId.Id);
		memcpy(&g_wlWaveCfg[passed_index], wlVendorWaveCfg,
			sizeof(LTQ_MAPI_WLAN_VendorWaveCfg));
	}

IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vendor_wave_cfg", "ret: %d", ret);
	return ret;
}

static void
mapi_wlan_convert_ascii_to_hex(char8 * ascii_str, char8 * hex_str)
{
	int32 i = 0;
	char8 temp[MAX_FILELINE_LEN];

	IFX_MAPI_DEBUG(fd, "/tmp/mapi_wlan_convert_ascii_to_hex",
		"strlen(ascii_str): %d", strlen(ascii_str));

	memset(hex_str, 0x00, sizeof(hex_str));

	for (i = 0; i < strlen(ascii_str); i++) {
		temp[0] = '\\';
		temp[1] = 'x';
		sprintf(&temp[2], "%02x", ascii_str[i]);
		strcat(hex_str, temp);
	}
	IFX_MAPI_DEBUG(fd, "/tmp/mapi_wlan_convert_ascii_to_hex",
		"hex_str: %s", hex_str);
}

static int32
mapi_wlan_convert_hex_to_ascii(char8 * hex_str, char8 * ascii_str)
{
	int32 a1 = 0, a2 = 0, i = 0, count = strlen(hex_str) / 4;
	char8 *ptr = hex_str;

	IFX_MAPI_DEBUG(fd, "/tmp/mapi_wlan_convert_hex_to_ascii",
		"convert: %s", hex_str);
	for (i = 0; i < count; i++, ptr += 4) {
		if ((ptr[0] != '\\') || (ptr[1] != 'x')) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapi_wlan_convert_hex_to_ascii", "");
			return IFX_FAILURE;
		}

		if (ptr[2] >= 'A' && ptr[2] <= 'F') {
			a1 = 10 + ptr[2] - 'A';
		} else if (ptr[2] >= 'a' && ptr[2] <= 'f') {
			a1 = 10 + ptr[2] - 'a';
		} else {
			a1 = ptr[2] - '0';
		}

		if (ptr[3] >= 'A' && ptr[3] <= 'F') {
			a2 = 10 + ptr[3] - 'A';
		} else if (ptr[3] >= 'a' && ptr[3] <= 'f') {
			a2 = 10 + ptr[3] - 'a';
		} else {
			a2 = ptr[3] - '0';
		}
		ascii_str[i] = (a1 * 16) + a2;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/mapi_wlan_convert_hex_to_ascii",
		"ascii_str: %s", ascii_str);
	return IFX_SUCCESS;
}

int32 ltq_get_param(const char8 * param, char8 * result)
{
	int32 ret = IFX_SUCCESS;
	char8 sValue[MAX_DATA_LEN];
	char8 *pTmpStr = NULL, *pTmpStr2 = NULL, *pTmpStr3;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_param", "param: %s", param);
	/* restore sValue buffer from global variable */
	strcpy(sValue, sResultFromScript);
	if ((pTmpStr = strstr(sValue, param)) != NULL) {
		if (!(strncmp(param, "SSID_", 5))) {
			/* The algorithm with strstr to detect the pattern in the output
			   has a flaw: If two very similar parameter like SSID and BSSID
			   are in the output, then BSSID is mistakenly detected as SSID.
			   THis is a dirty hack to overcome this for the moment. Move the
			   pointer to the next character and search again for SSID. */
			pTmpStr3 = pTmpStr + 1;
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_param", "pTmpStr: %s",
				       pTmpStr);
			if ((pTmpStr = strstr(pTmpStr3, param)) != NULL) {
				IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_param",
					       "pTmpStr: %s", pTmpStr);
			}
		}
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto LTQ_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto LTQ_Handler;
		}
	} else {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_param",
			       "sResultFromScript: %s", sResultFromScript);
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	}
	strcpy(result, pTmpStr2);

LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_param", "ret=%d", ret);
	return ret;
}

/**

   \param wlSec

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
static int32 mapiWlanPersonalConfig(uint32 oper, IFX_MAPI_WLAN_SecCfg * wlSec)
{
	IFX_MAPI_WLAN_PSKey wlPsk;
	int32 flags, ret = IFX_SUCCESS;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	uint32 outFlag = IFX_F_DEFAULT;

	IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanPersonalConfig", "");

	memset(&wlPsk, 0, sizeof(IFX_MAPI_WLAN_PSKey));
	wlPsk.iid.pcpeId.Id = wlSec->iid.cpeId.Id;
	wlPsk.iid.config_owner = wlSec->iid.config_owner;

	if ((oper == IFX_OP_ADD) || (oper == IFX_OP_DEL)) {
		flags = IFX_F_INT_DONT_CONFIGURE | IFX_F_DONT_WRITE_TO_FLASH;

		/* for add operation set some default values */
		if (oper == IFX_OP_ADD) {
			/* default values for wlPsk */
			strcpy(wlPsk.passPhrase, "NEW_PASS_PHRASE");
			strcpy(wlPsk.preSharedKey, "NEW_PSK");
		} else {
			/* get cpeId */
			sprintf(buf, "%s%d_0_cpeId", PREFIX_WLAN_PASSPHRASE,
				wlSec->iid.cpeId.Id);
			if ((ret =
			     ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_PASSPHRASE,
					    buf, IFX_F_GET_ANY, &outFlag,
					    sValue)) != IFX_SUCCESS) {
				IFX_MAPI_DEBUG(fd,
					       "/tmp/mapiWlanPersonalConfig",
					       "");
				goto IFX_Handler;
			}
			wlPsk.iid.cpeId.Id = atoi(sValue);
		}

		if ((ret = mapiWlanSetPersonalConfig(oper, &wlPsk, flags | IFX_F_INT_DONT_SEND_SET_NOTIFICATION))
		    != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanPersonalConfig",
				       "mapiWlanSetPersonalConfig has failed");
			goto IFX_Handler;
		}
	}

      IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanPersonalConfig", "ret: %d", ret);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/**

   \param wlSec

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
static int32 mapiWlan8021XConfig(uint32 oper, IFX_MAPI_WLAN_SecCfg * wlSec)
{
	IFX_MAPI_WLAN_802_1x wlRadius;
	int32 flags, ret = IFX_SUCCESS, passed_index = -1;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	uint32 outFlag = IFX_F_DEFAULT;

	IFX_MAPI_DEBUG(fd, "/tmp/mapiWlan8021XConfig", "");

	memset(&wlRadius, 0, sizeof(IFX_MAPI_WLAN_802_1x));
	wlRadius.iid.pcpeId.Id = wlSec->iid.cpeId.Id;
	wlRadius.iid.config_owner = wlSec->iid.config_owner;

	if ((oper == IFX_OP_ADD) || (oper == IFX_OP_DEL)) {
		flags =
		    IFX_F_INT_DONT_CONFIGURE | IFX_F_INT_DONT_SEND_NOTIFICATION
		    | IFX_F_INT_DONT_CHECK_ACL | IFX_F_DONT_WRITE_TO_FLASH;

		/* for add operation set some default values */
		if (oper == IFX_OP_ADD) {
			/* default values for wlRadius */
			wlRadius.groupKeyEna = TRUE;
			wlRadius.groupKeyIntvl = 3600;
			wlRadius.wpa2PreAuthEna = FALSE;
			wlRadius.wpa2ReAuthIntvl = 3600;
			if (!
			    (inet_aton
			     ("192.168.1.1", &wlRadius.radiusServerIP))) {
				IFX_MAPI_DEBUG(fd, "/tmp/mapiWlan8021XConfig",
					       "inet_aton has failed");
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}

			wlRadius.radiusPort = 1812;
			strcpy(wlRadius.radiusServerSecret,
			       "NEW_RADIUS_SECRET");
			strcpy(wlRadius.domainName, "");
			strcpy(wlRadius.userName, "");
			wlRadius.authType = IFX_MAPI_1X_AUTH_TYPE_LEAP;
			wlRadius.authProto = IFX_MAPI_1X_AUTH_PROTO_PAP;
		} else {
			IFX_GET_INDEX_FROM_PCPEID(FILE_RC_CONF,
						  wlSec->iid.cpeId,
						  passed_index)

			    sprintf(buf, "%s_%d_cpeId", PREFIX_WLAN_SEC_1X,
				    passed_index);
			if ((ret =
			     ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_1X, buf,
					    flags, &outFlag,
					    sValue)) != IFX_SUCCESS) {
				IFX_MAPI_DEBUG(fd, "/tmp/mapiWlan8021XConfig",
					       "");
				goto IFX_Handler;
			}
			wlRadius.iid.cpeId.Id = atoi(sValue);
		}

		if ((ret =
		     ifx_mapi_set_wlan_802_1x_config(oper, &wlRadius,
						     flags | IFX_F_INT_DONT_SEND_SET_NOTIFICATION)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlan8021XConfig",
				       "ifx_mapi_set_wlan_802_1x_config has failed");
			goto IFX_Handler;
		}
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/mapiWlan8021XConfig", "ret: %d", ret);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/**

   \param wlSec

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
static int32 mapiWlanWepConfig(uint32 oper, IFX_MAPI_WLAN_SecCfg * wlSec, int32 flags)
{
	int32 i, ret = IFX_SUCCESS;
	IFX_MAPI_WLAN_WEP_Key wlWepKey;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	uint32 outFlag = IFX_F_DEFAULT;

	IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanWepConfig", "");

	memset(&wlWepKey, 0, sizeof(IFX_MAPI_WLAN_WEP_Key));
	wlWepKey.iid.pcpeId.Id = wlSec->iid.cpeId.Id;
	wlWepKey.iid.config_owner = wlSec->iid.config_owner;

	if ((oper == IFX_OP_ADD) || (oper == IFX_OP_DEL)) {
		flags |= (IFX_F_INT_DONT_CONFIGURE | IFX_F_DONT_WRITE_TO_FLASH);

		/* default values for wlWepKey */
		if (oper == IFX_OP_ADD)
			sprintf(wlWepKey.wepKey, "123456789abcdef0123456789a");

		for (i = 0; i < IFX_MAPI_NUM_WEP_KEYS; i++) {
			if (oper == IFX_OP_DEL) {
				sprintf(buf, "%s%d_%d_cpeId", PREFIX_WLAN_WEP,
					wlSec->iid.cpeId.Id, i);
				if ((ret =
				     ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_WEP,
						    buf, IFX_F_GET_ANY,
						    &outFlag,
						    sValue)) != IFX_SUCCESS) {
					IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanWepConfig", "");
					goto IFX_Handler;
				}
				wlWepKey.iid.cpeId.Id = atoi(sValue);
			}

//This fn is called from ifx_mapi_set_wlan_security_config so no need to send
//notification to devm
		 flags |= IFX_F_INT_DONT_SEND_SET_NOTIFICATION | IFX_F_INT_DONT_CHECK_ACL;
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanWepConfig", "flags:0x%x", flags);

		if ((ret = ifx_mapi_set_wlan_wep_key(oper, i, &wlWepKey, flags)) != 
			IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanWepConfig",
				"ifx_mapi_set_wlan_wep_key has failed\nFlags:0x%x", flags);
				goto IFX_Handler;
			}
		}
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanWepConfig", "ret: %d", ret);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/**
   \param iid

   \param array_fvp

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
static int32
mapiWlanGetObjectFromRcConf(IFX_ID iid, IFX_NAME_VALUE_PAIR * array_fvp)
{
	int32 ret = IFX_SUCCESS, passed_index = -1, count = 0, i;
	char8 *sValue = NULL, conf_buf[MAX_DATA_LEN];

	if (!strcmp(iid.cpeId.secName, TAG_WLAN_SEC)) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, iid.cpeId, passed_index)
		    sprintf(conf_buf, "%s_%d_", PREFIX_WLAN_SEC, passed_index);
	} else {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetObjectFromRcConf",
			       "Tag not yet supported: %s", iid.cpeId.secName);
	}

	if ((ret = ifx_GetCfgObject(FILE_RC_CONF, iid.cpeId.secName, conf_buf,
				    IFX_F_DEFAULT, &sValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetObjectFromRcConf",
			       "conf_buf: %s, passed_index: %d",
			       conf_buf, passed_index);
		goto IFX_Handler;
	}

	/* form an array of field value pairs for easier access to parameters */
	form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);

	for (i = 0; i < count; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetObjectFromRcConf", "%s:%s",
			       array_fvp[i].fieldname, array_fvp[i].value);
IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetObjectFromRcConf", "ret: %d", ret);
	IFX_MEM_FREE(sValue);
	return ret;
}

/**
   \param   wlMainCfg - pointer to IFX_MAPI_WLAN_MainCfg structure

   \return
      TRUE or FALSE

   \remarks -  checks all parameters of MAIN configuration for change
   	   	   	   returns TRUE if one or more parameter changed
   	   	   	   returns FALSE if no parameter changed
*/
static bool mapiWlanChkMainCfgChg(int32 idx, IFX_MAPI_WLAN_MainCfg * wlMainCfg)
{
	LTQ_MAPI_WLAN_Vendor	vendor = LTQ_MAPI_WLAN_VENDOR_NONE;
	LTQ_MAPI_WLAN_Feature	features = LTQ_MAPI_WLAN_FEATURE_NONE;

	IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkMainCfgChg", "idx: %d", idx);

	if (strcmp(wlMainCfg->apName, g_wlMain[idx].apName)) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkMainCfgChg", "");
		return TRUE;
	}

	if (strcmp(wlMainCfg->ssid, g_wlMain[idx].ssid)) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkMainCfgChg", "");
		return TRUE;
	}

	if (wlMainCfg->apEnable != g_wlMain[idx].apEnable) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkMainCfgChg", "");
		return TRUE;
	}

	if (wlMainCfg->devType != g_wlMain[idx].devType) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkMainCfgChg", "");
		return TRUE;
	}

	if (wlMainCfg->ssidMode != g_wlMain[idx].ssidMode) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkMainCfgChg", "");
		return TRUE;
	}

	if (wlMainCfg->maxBitRate != g_wlMain[idx].maxBitRate) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkMainCfgChg", "");
		return TRUE;
	}

	if (wlMainCfg->vlanId != g_wlMain[idx].vlanId) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkMainCfgChg", "");
		return TRUE;
	}

	if (wlMainCfg->apIsolationEna != g_wlMain[idx].apIsolationEna) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkMainCfgChg", "");
		return TRUE;
	}

	if (wlMainCfg->WMMena != g_wlMain[idx].WMMena) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkMainCfgChg", "");
		return TRUE;
	}

	if (wlMainCfg->UAPSDena != g_wlMain[idx].UAPSDena) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkMainCfgChg", "");
		return TRUE;
	}

	if (wlMainCfg->WPSena != g_wlMain[idx].WPSena) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkMainCfgChg", "");
		return TRUE;
	}

	if (wlMainCfg->WDSena != g_wlMain[idx].WDSena) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkMainCfgChg", "");
		return TRUE;
	}

	if (wlMainCfg->maxStations != g_wlMain[idx].maxStations) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkMainCfgChg", "");
		return TRUE;
	}

	vendor = ltq_mapi_get_wlan_vendor(wlMainCfg->radioCpeId, IFX_F_DEFAULT);
	if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
		if (wlMainCfg->minResSta != g_wlMain[idx].minResSta) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkMainCfgChg", "");
			return TRUE;
		}
	}
	features = ltq_mapi_get_wlan_supported_features(wlMainCfg->radioCpeId,
		IFX_F_DEFAULT);
	if (features & LTQ_MAPI_WLAN_FEATURE_NETMODE_PER_VAP) {
		if (wlMainCfg->networkMode != g_wlMain[idx].networkMode) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkMainCfgChg", "");
			return TRUE;
		}
	}
	return FALSE;
}

/**
   \param   wlSecCfg - pointer to IFX_MAPI_WLAN_SecCfg structure

   \return
      TRUE or FALSE

   \remarks -  checks all parameters of security configuration for change
   	   	   	   returns TRUE if one or more parameter changed
   	   	   	   returns FALSE if no parameter changed
*/
static bool mapiWlanChkSecCfgChg(int32 idx, IFX_MAPI_WLAN_SecCfg * wlSecCfg)
{
	int32	i = 0;
	char8	newRadiusIp[MAX_IP_ADDR_LEN], oldRadiusIp[MAX_IP_ADDR_LEN];

	IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "idx: %d", idx);

	if (wlSecCfg->beaconType != g_wlSec[idx].beaconType) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
		return TRUE;
	}

	if (wlSecCfg->wlAuth != g_wlSec[idx].wlAuth) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
		return TRUE;
	}

	if (wlSecCfg->wlEncr != g_wlSec[idx].wlEncr) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
		return TRUE;
	}

	if (wlSecCfg->macAddrCntrlEna != g_wlSec[idx].macAddrCntrlEna) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
		return TRUE;
	}

	switch (wlSecCfg->beaconType) {
	case IFX_MAPI_WLAN_BEACON_NONE:
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
		break;
	case IFX_MAPI_WLAN_BEACON_BASIC:
		/* WEP security => compare wep related parameters */
		if (wlSecCfg->wlEncr == IFX_MAPI_WLAN_ENCR_WEP) {
			if (wlSecCfg->secParams.wepCfg.wepKeyType !=
				g_wlSec[idx].secParams.wepCfg.wepKeyType) {
				IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
				return TRUE;
			}
			if (wlSecCfg->secParams.wepCfg.wepEncrLevel !=
				g_wlSec[idx].secParams.wepCfg.wepEncrLevel) {
				IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
				return TRUE;
			}
			if (wlSecCfg->secParams.wepCfg.wepKeyIndex !=
				g_wlSec[idx].secParams.wepCfg.wepKeyIndex) {
				IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
				return TRUE;
			}
			for (i = 0; i < IFX_MAPI_NUM_WEP_KEYS; i++) {
				if (strcmp(wlSecCfg->secParams.wepCfg.wepKey[i].wepKey,
					g_wlSec[idx].secParams.wepCfg.wepKey[i].wepKey)) {
					IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
					return TRUE;
				}
			}
		}
		/* open security => no more parameters need to be compared */
		else {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
		}
		break;
	case IFX_MAPI_WLAN_BEACON_WPA:
	case IFX_MAPI_WLAN_BEACON_WPA2:
	case IFX_MAPI_WLAN_BEACON_WPA_WPA2:
	case IFX_MAPI_WLAN_BEACON_WPA_WPA2_NON_COMPLIANT:
		if (wlSecCfg->wlAuth == IFX_MAPI_WLAN_AUTH_RADIUS) {
			if (wlSecCfg->secParams.wlRadius.groupKeyEna !=
				g_wlSec[idx].secParams.wlRadius.groupKeyEna) {
				IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
				return TRUE;
			}
			if (wlSecCfg->secParams.wlRadius.groupKeyIntvl !=
				g_wlSec[idx].secParams.wlRadius.groupKeyIntvl) {
				IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
				return TRUE;
			}
			if (wlSecCfg->secParams.wlRadius.wpa2PreAuthEna !=
				g_wlSec[idx].secParams.wlRadius.wpa2PreAuthEna) {
				IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
				return TRUE;
			}
			if (wlSecCfg->secParams.wlRadius.wpa2ReAuthIntvl !=
				g_wlSec[idx].secParams.wlRadius.wpa2ReAuthIntvl) {
				IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
				return TRUE;
			}
			if (wlSecCfg->secParams.wlRadius.radiusPort !=
				g_wlSec[idx].secParams.wlRadius.radiusPort) {
				IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
				return TRUE;
			}
			if (wlSecCfg->secParams.wlRadius.authType !=
				g_wlSec[idx].secParams.wlRadius.authType) {
				IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
				return TRUE;
			}
			if (wlSecCfg->secParams.wlRadius.authProto !=
				g_wlSec[idx].secParams.wlRadius.authProto) {
				IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
				return TRUE;
			}
			if (strcmp(wlSecCfg->secParams.wlRadius.radiusServerSecret,
				g_wlSec[idx].secParams.wlRadius.radiusServerSecret)) {
				IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
				return TRUE;
			}
			if (strcmp(wlSecCfg->secParams.wlRadius.domainName,
				g_wlSec[idx].secParams.wlRadius.domainName)) {
				IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
				return TRUE;
			}
			if (strcmp(wlSecCfg->secParams.wlRadius.userName,
				g_wlSec[idx].secParams.wlRadius.userName)) {
				IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
				return TRUE;
			}
			sprintf(newRadiusIp, "%s",
				inet_ntoa(wlSecCfg->secParams.wlRadius.radiusServerIP));
			sprintf(oldRadiusIp, "%s",
				inet_ntoa(g_wlSec[idx].secParams.wlRadius.radiusServerIP));
			if (strcmp(newRadiusIp, oldRadiusIp)) {
				IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
				return TRUE;
			}
		} else if (wlSecCfg->wlAuth == IFX_MAPI_WLAN_AUTH_PERSONAL) {
			if (wlSecCfg->secParams.personalCfg.pskType !=
				g_wlSec[idx].secParams.personalCfg.pskType) {
				IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
				return TRUE;
			}
			if (wlSecCfg->secParams.personalCfg.groupKeyEna !=
				g_wlSec[idx].secParams.personalCfg.groupKeyEna) {
				IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
				return TRUE;
			}
			if (wlSecCfg->secParams.personalCfg.groupKeyIntvl !=
				g_wlSec[idx].secParams.personalCfg.groupKeyIntvl) {
				IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
				return TRUE;
			}
			if (wlSecCfg->secParams.personalCfg.pskType == IFX_MAPI_WLAN_ASCII_KEY) {
				if (strcmp(wlSecCfg->secParams.personalCfg.psk.passPhrase,
					g_wlSec[idx].secParams.personalCfg.psk.passPhrase)) {
					IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
					return TRUE;
				}
			} else {
				if (strcmp(wlSecCfg->secParams.personalCfg.psk.preSharedKey,
					g_wlSec[idx].secParams.personalCfg.psk.preSharedKey)) {
					IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
					return TRUE;
				}
			}
		} else {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkSecCfgChg", "");
		}
		break;
	default:
		break;
	}

	return FALSE;
}

/**
   \param   wlPhyCfg - pointer to IFX_MAPI_WLAN_PhyCfg structure

   \return
      TRUE or FALSE

   \remarks -  checks all parameters of PHY configuration for change
   	   	   	   returns TRUE if one or more parameter changed
   	   	   	   returns FALSE if no parameter changed
*/
static void mapiWlanChkPhyCfgChg(int32 idx, IFX_MAPI_WLAN_PhyCfg * wlPhy)
{
	LTQ_MAPI_WLAN_Vendor	vendor = LTQ_MAPI_WLAN_VENDOR_NONE;
	LTQ_MAPI_WLAN_Feature	features = LTQ_MAPI_WLAN_FEATURE_NONE;

	IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "idx: %d", idx);

	if (wlPhy->radioEnable != g_wlPhy[idx].radioEnable) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioEnaChanged = TRUE;
		/*
		 * do not return now, we need to know if any other radio configuration
		 * changed other than radio enable
		*/
	}

	/* it is still true from previous call, but script has not yet been called */
	if (g_flagRadioCfgChanged == TRUE)
		goto auto_cfg_changed;

	if (strcmp(wlPhy->country, g_wlPhy[idx].country)) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->standard != g_wlPhy[idx].standard) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->freqBand != g_wlPhy[idx].freqBand) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->usageEnv != g_wlPhy[idx].usageEnv) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->preamble != g_wlPhy[idx].preamble) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->autoChannelEna != g_wlPhy[idx].autoChannelEna) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (!wlPhy->autoChannelEna) {
		if (wlPhy->channelNo != g_wlPhy[idx].channelNo) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
			g_flagRadioCfgChanged = TRUE;
			goto auto_cfg_changed;
		}
	}

	if (wlPhy->beaconTxEna != g_wlPhy[idx].beaconTxEna) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->beaconIntvl != g_wlPhy[idx].beaconIntvl) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->dtimInt != g_wlPhy[idx].dtimInt) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->powerLvl != g_wlPhy[idx].powerLvl) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->rts != g_wlPhy[idx].rts) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->fts != g_wlPhy[idx].fts) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->insecOOBAccEna != g_wlPhy[idx].insecOOBAccEna) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->autoRateFallBackEna != g_wlPhy[idx].autoRateFallBackEna) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->staticRate != g_wlPhy[idx].staticRate) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->phy11N.chanBW != g_wlPhy[idx].phy11N.chanBW) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->phy11N.extChPos != g_wlPhy[idx].phy11N.extChPos) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->phy11N.mcs != g_wlPhy[idx].phy11N.mcs) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->phy11N.baWinSize != g_wlPhy[idx].phy11N.baWinSize) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->phy11N.guardIntvl != g_wlPhy[idx].phy11N.guardIntvl) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->phy11N.rxStbc != g_wlPhy[idx].phy11N.rxStbc) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->phy11N.twentyFourtyCoex != g_wlPhy[idx].phy11N.twentyFourtyCoex) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->phy11N.fourtyMHzIntolerant != g_wlPhy[idx].phy11N.fourtyMHzIntolerant) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->phy11N.transDelayFactor != g_wlPhy[idx].phy11N.transDelayFactor) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->phy11N.obssScan != g_wlPhy[idx].phy11N.obssScan) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	if (wlPhy->phy11N.twentyFourtyCoex != g_wlPhy[idx].phy11N.twentyFourtyCoex) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
		g_flagRadioCfgChanged = TRUE;
		goto auto_cfg_changed;
	}

	vendor = ltq_mapi_get_wlan_vendor(wlPhy->iid.cpeId.Id, IFX_F_DEFAULT);
	if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
		if (wlPhy->radarEna != g_wlPhy[idx].radarEna) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
			g_flagRadioCfgChanged = TRUE;
			goto auto_cfg_changed;
		}

		if (wlPhy->beamForm != g_wlPhy[idx].beamForm) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
			g_flagRadioCfgChanged = TRUE;
			goto auto_cfg_changed;
		}

		if (wlPhy->mc2ucEna != g_wlPhy[idx].mc2ucEna) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
			g_flagRadioCfgChanged = TRUE;
			goto auto_cfg_changed;
		}

		if (wlPhy->boostMode != g_wlPhy[idx].boostMode) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
			g_flagRadioCfgChanged = TRUE;
			goto auto_cfg_changed;
		}

		if (wlPhy->phy11N.ldpcEna != g_wlPhy[idx].phy11N.ldpcEna) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
			g_flagRadioCfgChanged = TRUE;
			goto auto_cfg_changed;
		}

		if (wlPhy->wlVendorWaveCfg.logServerEna !=
			g_wlPhy[idx].wlVendorWaveCfg.logServerEna) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
			g_flagRadioCfgChanged = TRUE;
			goto auto_cfg_changed;
		}
	}

auto_cfg_changed:
	features = ltq_mapi_get_wlan_supported_features(wlPhy->iid.cpeId.Id, IFX_F_DEFAULT);
	if (features & LTQ_MAPI_WLAN_FEATURE_AUTOCOC) {
		if (wlPhy->phyAutoCoC.autoCocEnable != g_wlPhy[idx].phyAutoCoC.autoCocEnable) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
			g_flagRadioCfgChanged = TRUE;
			g_flagAutoCocCfgChanged = TRUE;
			goto net_mode_vap_changed;
		}

		if (wlPhy->phyAutoCoC.nAntennas != g_wlPhy[idx].phyAutoCoC.nAntennas) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
			g_flagRadioCfgChanged = TRUE;
			g_flagAutoCocCfgChanged = TRUE;
			goto net_mode_vap_changed;
		}

		if (wlPhy->phyAutoCoC.timerIntval_1x1 != g_wlPhy[idx].phyAutoCoC.timerIntval_1x1) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
			g_flagRadioCfgChanged = TRUE;
			g_flagAutoCocCfgChanged = TRUE;
			goto net_mode_vap_changed;
		}

		if (wlPhy->phyAutoCoC.timerIntval_2x2 != g_wlPhy[idx].phyAutoCoC.timerIntval_2x2) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
			g_flagRadioCfgChanged = TRUE;
			g_flagAutoCocCfgChanged = TRUE;
			goto net_mode_vap_changed;
		}

		if (wlPhy->phyAutoCoC.timerIntval_3x3 != g_wlPhy[idx].phyAutoCoC.timerIntval_3x3) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
			g_flagRadioCfgChanged = TRUE;
			g_flagAutoCocCfgChanged = TRUE;
			goto net_mode_vap_changed;
		}

		if (wlPhy->phyAutoCoC.highLim_1x1 != g_wlPhy[idx].phyAutoCoC.highLim_1x1) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
			g_flagRadioCfgChanged = TRUE;
			g_flagAutoCocCfgChanged = TRUE;
			goto net_mode_vap_changed;
		}

		if (wlPhy->phyAutoCoC.highLim_2x2 != g_wlPhy[idx].phyAutoCoC.highLim_2x2) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
			g_flagRadioCfgChanged = TRUE;
			g_flagAutoCocCfgChanged = TRUE;
			goto net_mode_vap_changed;
		}

		if (wlPhy->phyAutoCoC.lowLim_2x2 != g_wlPhy[idx].phyAutoCoC.lowLim_2x2) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
			g_flagRadioCfgChanged = TRUE;
			g_flagAutoCocCfgChanged = TRUE;
			goto net_mode_vap_changed;
		}

		if (wlPhy->phyAutoCoC.lowLim_3x3 != g_wlPhy[idx].phyAutoCoC.lowLim_3x3) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
			g_flagRadioCfgChanged = TRUE;
			g_flagAutoCocCfgChanged = TRUE;
			goto net_mode_vap_changed;
		}
	}

net_mode_vap_changed:
	if (features & LTQ_MAPI_WLAN_FEATURE_NETMODE_PER_VAP) {
		if (wlPhy->netModeClass != g_wlPhy[idx].netModeClass) {
			IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkPhyCfgChg", "");
			g_flagNetModeVapCfgChanged = TRUE;
			return;
		}
	}
}

/**

   \param oper

   \param wlMain

   \param flags

   \return
   - IFX_SUCCESS
   - IFX_FAILURE

   \notes   - should an add here, add object for security config also?
              no it should be done from ifx_set_wlan_ap_config
            - notification and tr69 map update should be called locally?
               yes
            - validation to check for combination of standard, country,
              op-reates, basic-rates and channels
            - wireless start script checks if both phy-radio and this ap/vap is
              enabled, then only starts the service
*/
int32
ifx_mapi_set_wlan_main_config(uint32 oper, IFX_MAPI_WLAN_MainCfg * wlMain,
			      uint32 flags)
{
	bool found = 0;
	char8 conf_buf[MAX_DATA_LEN], buf[MAX_FILELINE_LEN];
	int32 count = 0, changed_count = 0, passed_index = -1;
	int32 ret = IFX_SUCCESS, i = 0;
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_MAIN_PARAM_COUNT];
	IFX_NAME_VALUE_PAIR *array_changed_fvp = NULL;
	char8 ssidInHex[4*IFX_MAPI_WLAN_SSID_LEN]; /* IFX_MAPI_WLAN_SSID_LEN already includes closing \0 */
	IFX_MAPI_WLAN_SecCfg wlSec;
	bool f_secConfChg = FALSE;
	LTQ_MAPI_WLAN_Vendor	vendor = LTQ_MAPI_WLAN_VENDOR_NONE;
	LTQ_MAPI_WLAN_Feature	features = LTQ_MAPI_WLAN_FEATURE_NONE;

	LTQ_LOG_TIMESTAMP("Begin");

	memset(array_fvp, 0, sizeof(array_fvp));
	NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));

   /*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY) append the flag with
	   internal flags */
	if (oper == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (oper == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

	sprintf(wlMain->iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
	sprintf(wlMain->iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

   /**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(wlMain)
		    /* Do simple validation of flags sucha as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
		    /* validate max-bit rate here */
		    if (wlMain->maxBitRate == 0)
			found = 1;
		else {
			i = 0;
			while (wlMain->operDataRates[i] != 0) {
				if (wlMain->operDataRates[i] ==
				    wlMain->maxBitRate) {
					found = 1;
					break;
				}
				i++;
			}
		}
		if (!found) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("[%s:%d] Validation failed : max bit rate should be one of operational data rates",
			     __FUNCTION__, __LINE__);
#endif
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig",
				       "Validation failed : max bit rate should be one of "
				       "operational data rates");
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "ssid: %s",
			       wlMain->ssid);
		IFX_VALIDATE_SSID(wlMain)
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "cpeID: %d, pCpeID: %d",
			wlMain->iid.cpeId.Id, wlMain->iid.pcpeId.Id);

	/* Get Config Index in case of modify/delete operations from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlMain->iid.cpeId, passed_index)
	}

	/* get vendor information */
	vendor = ltq_mapi_get_wlan_vendor(wlMain->radioCpeId, IFX_F_DEFAULT);
	features = ltq_mapi_get_wlan_supported_features(wlMain->radioCpeId, IFX_F_DEFAULT);

	if (IFX_MODIFY_F_SET(flags)) {
		/* return immediately if no parameter changed */
		if ((mapiWlanChkMainCfgChg(passed_index, wlMain) == FALSE) &&
			!g_flagWaveCfgChg) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig",
				"passed_index: %d", passed_index);
			LTQ_LOG_TIMESTAMP("Done");
			return IFX_SUCCESS;
		}
		if (features & LTQ_MAPI_WLAN_FEATURE_NETMODE_PER_VAP) {
			if (LTQ_F_INT_DONT_RECONFIG_SECURITY_F_NOT_SET(flags)) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
				memset(&wlSec, 0, sizeof(IFX_MAPI_WLAN_SecCfg));
				sprintf(wlSec.iid.cpeId.secName, "%s", TAG_WLAN_SEC);
				sprintf(wlSec.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
				wlSec.iid.cpeId.Id = wlMain->iid.cpeId.Id;

				if ((ret = ifx_mapi_get_wlan_security_config(&wlSec, IFX_F_DEFAULT)) !=
					IFX_SUCCESS) {
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
					goto IFX_Handler;
				}

				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig",
					"beacon: %d, encr: %d, netMode: %d",
					wlSec.beaconType, wlSec.wlEncr, wlMain->networkMode);
				/*
					if security == WEP or security == WPA/TKIP and network mode == any HT,
					or if security == WPA_WPA2_mixed and network mode == 802.11N,
					then reconfigure to WPA2 unless prevented by flag
				*/
				if ((((wlSec.wlEncr == IFX_MAPI_WLAN_ENCR_WEP) ||
					(wlSec.wlEncr == IFX_MAPI_WLAN_ENCR_TKIP)) &&
					(wlMain->networkMode >= IFX_MAPI_WLAN_STD_802_11N)) ||
					((wlSec.beaconType == IFX_MAPI_WLAN_BEACON_WPA_WPA2) &&
					(wlMain->networkMode == IFX_MAPI_WLAN_STD_802_11N))) {
					/* set security has changed flag for later usage */
					f_secConfChg = TRUE;
					wlSec.wlEncr = IFX_MAPI_WLAN_ENCR_CCMP;
					wlSec.wlAuth = IFX_MAPI_WLAN_AUTH_PERSONAL;
					wlSec.beaconType = IFX_MAPI_WLAN_BEACON_WPA2;
					/* get personal security configuration */
					wlSec.secParams.personalCfg.psk.iid.pcpeId.Id = wlSec.iid.cpeId.Id;
					if ((ret = ifx_mapi_get_wlan_personal_config(
						&wlSec.secParams.personalCfg, IFX_F_DEFAULT)) != IFX_SUCCESS) {
						IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig",
							"ifx_mapi_get_wlan_personal_config returned an error");
						goto IFX_Handler;
					}
					if ((ret = ifx_mapi_set_wlan_security_config(IFX_OP_MOD, &wlSec,
						IFX_F_DONT_WRITE_TO_FLASH | 
						IFX_F_INT_DONT_SEND_SET_NOTIFICATION |
						LTQ_F_INT_DONT_RECONFIG_MAIN)) != IFX_SUCCESS) {
						IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
						goto IFX_Handler;
					}
				}
			}
		}

		/* WPS cannot coexist with hidden SSID mode */
		if ( (wlMain->ssidMode == IFX_MAPI_WLAN_SSID_HIDDEN) && wlMain->WPSena) {
			IFX_MAPI_WLAN_WPS_Cfg wlWps;

			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
			memset(&wlWps, 0, sizeof(IFX_MAPI_WLAN_WPS_Cfg));
			sprintf(wlWps.iid.cpeId.secName, "%s", TAG_WLAN_WPS);
			sprintf(wlWps.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);

			wlWps.iid.cpeId.Id = g_wlSec[passed_index].iid.cpeId.Id;
			wlWps.iid.pcpeId.Id = g_wlSec[passed_index].iid.cpeId.Id;
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig",
				"cpeId: %d, pcpeId: %d",
				wlWps.iid.cpeId.Id, wlWps.iid.pcpeId.Id);

			/* get the wlan wps configuration from MAPI */
			if ((ret = ifx_mapi_get_wlan_wps_config(&wlWps, IFX_F_DEFAULT)) !=
				IFX_SUCCESS) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
				goto IFX_Handler;
			}
			/* disable WPS and subfeatures and set the new config */
			wlWps.enable = 0;
			wlWps.enrolleeEna = 0;
			wlWps.proxyEna = 0;
			wlWps.intRegEna = 0;
			if ((ret = ifx_mapi_set_wlan_wps_config(IFX_OP_MOD, &wlWps,
				IFX_F_MODIFY | IFX_F_DONT_WRITE_TO_FLASH)) != IFX_SUCCESS) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
				goto IFX_Handler;
			}
		}
	}

	/**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given structure for ADD/MODIFY Operations */
	count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, 0, WLAN_MAIN_PARAM_COUNT,
					wlan_main_params);

		/* apEnable is uint32 here !! */
		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 4,
					    (int32 *) & wlMain->iid.cpeId.Id,
					    &wlMain->iid.pcpeId.Id,
					    &wlMain->radioCpeId,
					    &wlMain->apEnable);
		sprintf(array_fvp[4].value, "%s", wlMain->apName);	/* apName */
		sprintf(array_fvp[5].value, "%d", wlMain->devType);	/* devType */

		if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			memset(ssidInHex, 0, sizeof(ssidInHex));
			/* convert ascii representation of ssid to hex representation */
			mapi_wlan_convert_ascii_to_hex(wlMain->ssid, ssidInHex);
			sprintf(array_fvp[6].value, "%s", ssidInHex);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig",
				"ssid: %s", array_fvp[6].value);
		} else {
			sprintf(array_fvp[6].value, "%s", wlMain->ssid);
		}

		sprintf(array_fvp[7].value, "%d", wlMain->ssidMode);
		sprintf(array_fvp[8].value, "%d", wlMain->bssidOverride);
		if (strlen(wlMain->bssid) == 17)
			sprintf(array_fvp[9].value, "%s", wlMain->bssid);
		else
			sprintf(array_fvp[9].value, "%s", "");
		/* Pramod - how to fill basic and operational data rates have them as
		   comma seperated integers in a string */
		i = 0;
		while (wlMain->basicDataRates[i] != 0) {
			memset(buf, 0x00, sizeof(buf));
			sprintf(buf, "%.1f,", wlMain->basicDataRates[i]);
			strcat(array_fvp[10].value, buf);
			i++;
		}
		array_fvp[10].value[strlen(array_fvp[10].value) - 1] = '\0';

		i = 0;
		while (wlMain->operDataRates[i] != 0) {
			memset(buf, 0x00, sizeof(buf));
			sprintf(buf, "%.1f,", wlMain->operDataRates[i]);
			strcat(array_fvp[11].value, buf);
			i++;
		}
		array_fvp[11].value[strlen(array_fvp[11].value) - 1] = '\0';

		sprintf(array_fvp[12].value, "%2.1f", wlMain->maxBitRate);
		ifx_fill_ArrayFvp_intValues(array_fvp, 13, 1,
					    (int32 *) & wlMain->vlanId);
		sprintf(array_fvp[14].value, "%d", wlMain->apIsolationEna);

		sprintf(array_fvp[15].value, "%d", wlMain->WMMena);
		sprintf(array_fvp[16].value, "%d", wlMain->UAPSDena);
		sprintf(array_fvp[17].value, "%d", wlMain->WDSena);
		sprintf(array_fvp[18].value, "%d", wlMain->maxStations);
		sprintf(array_fvp[19].value, "%d", wlMain->minResSta);
		sprintf(array_fvp[20].value, "%d", wlMain->networkMode);
	}

	count = WLAN_MAIN_PARAM_COUNT;

	/* Determine the configuration index - for Add, Delete, Modify operations *
	   Name is partial since index is not known * Fill array_fvp[] */
	if (ifx_get_conf_index_and_nv_pairs
	    (&wlMain->iid, passed_index, PREFIX_WLAN_MAIN, count, array_fvp,
	     flags) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	if (IFX_INT_ADD_F_SET(flags)) {
		/* Get index value from Section Count if it exists */
		if ((ret =
		     (ifx_get_index_from_sec_count
		      (FILE_RC_CONF, wlMain->iid.cpeId.secName, &passed_index,
		       flags))) != IFX_SUCCESS) {
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig",
			       "passed_index: %d", passed_index);
	}

   /************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
	if (IFX_ADD_F_NOT_SET(flags) && IFX_INT_DONT_CHECK_ACL_F_NOT_SET(flags)) {
		CHECK_ACL_RET(wlMain->iid, count, array_fvp,
			      changed_count, array_changed_fvp, flags,
			      IFX_Handler)
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");

	/*
	 * before the configuration file is updated, the ap/vap is stopped in case
	 * of a modify operation; in case of a delete operation the vap is removed
	 */
		IFX_DBG("[%s:%d]: flags: 0x%x", __FUNCTION__, __LINE__, flags);
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags)) {
		if (IFX_MODIFY_F_SET(flags)) {
			/* disable AP before updating with new configuration */
			if (!(features & LTQ_MAPI_WLAN_FEATURE_OPT_SCRIPTS)) {
				sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, passed_index);
				LTQ_LOG_TIMESTAMP();
				system(conf_buf);
				LTQ_LOG_TIMESTAMP();
				g_flagWaveCfgChg = FALSE;
			}
		} else if (IFX_DELETE_F_SET(flags)) {
			/* remove AP */
			sprintf(conf_buf, "%s %d", SERVICE_WLAN_REMOVE_VAP, passed_index);
			LTQ_LOG_TIMESTAMP();
			system(conf_buf);
			LTQ_LOG_TIMESTAMP();
		}
	}

   /************** System Config File Update Block ****************/
	/* Convert the name value pair in array_fvp into string format expected by
	   rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "conf_buf: %s",
		       conf_buf);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_MAIN, flags, 1, conf_buf);

	if (ret != IFX_SUCCESS) {
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		goto IFX_Handler;
	}

   /*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* after config file update, for modify or add operation start all ap/vap */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags) &&
	    (IFX_INT_ADD_F_SET(flags) || IFX_MODIFY_F_SET(flags))) {
		if (!(features & LTQ_MAPI_WLAN_FEATURE_OPT_SCRIPTS)) {
			if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
				sprintf(conf_buf, "%s", SERVICE_WLAN_START);
			} else {
				sprintf(conf_buf, "%s %d", SERVICE_WLAN_START, passed_index);
			}

			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig",
				"conf_buf: %s", conf_buf);
			LTQ_LOG_TIMESTAMP();
			system(conf_buf);
			LTQ_LOG_TIMESTAMP();
			g_flagWaveCfgChg = FALSE;
		} else {
			if (IFX_INT_ADD_F_SET(flags)) {
				sprintf(conf_buf, "%s %d", SERVICE_WLAN_START, passed_index);
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "conf_buf: %s",
					conf_buf);
				LTQ_LOG_TIMESTAMP();
				system(conf_buf);
				LTQ_LOG_TIMESTAMP();
			}
			else {
				if (wlMain->apEnable != g_wlMain[passed_index].apEnable) {
					if (wlMain->apEnable) {
						sprintf(conf_buf, "%s %d", SERVICE_WLAN_VAP_ENABLE,
							passed_index);
						LTQ_LOG_TIMESTAMP("SERVICE_WLAN_VAP_ENABLE Begin");
					} else {
						sprintf(conf_buf, "%s %d", SERVICE_WLAN_VAP_DISABLE,
							passed_index);
						LTQ_LOG_TIMESTAMP("SERVICE_WLAN_VAP_DISABLE Begin");
					}
				} else if (!strcmp(wlMain->ssid, g_wlMain[passed_index].ssid) &&
					!f_secConfChg) {
					sprintf(conf_buf, "%s %d 0 1", SERVICE_WLAN_MODIFY,
						passed_index);
					LTQ_LOG_TIMESTAMP("SERVICE_WLAN_MODIFY Begin");
				} else {
					sprintf(conf_buf, "%s %d 1 1", SERVICE_WLAN_MODIFY,
						passed_index);
						LTQ_LOG_TIMESTAMP("SERVICE_WLAN_MODIFY Begin");
				}
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig",
					"conf_buf: %s", conf_buf);
				system(conf_buf);
				LTQ_LOG_TIMESTAMP("SERVICE Done");
				g_flagWaveCfgChg = FALSE;
			}
		}
	}

	if (features & LTQ_MAPI_WLAN_FEATURE_OPT_SCRIPTS) {
		if (IFX_INT_DONT_CONFIGURE_F_SET(flags) && (wlMain->iid.config_owner != IFX_WEB)) {
			if (strcmp(wlMain->ssid, g_wlMain[passed_index].ssid)) {
				g_flag_ssid_changed = 1;
			}
		}
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "flags: 0x%x", flags);

	/* this will Compact the section and also update the count for both ADD and
	   DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_WLAN_MAIN, flags);

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
   /*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
   /*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_MODIFY_F_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION(wlMain->iid, changed_count,
					  array_changed_fvp, flags, IFX_Handler)
	} else if (IFX_INT_ADD_F_SET(flags)) {
		/* In case of ADD operation, first update the ID Mappings and then send
		   the Notification for the attributes */
      /*********** Epilog Block **************/
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig",
			       "UPDATE_ID_MAP_N_ATTRIBUTES");
		UPDATE_ID_MAP_N_ATTRIBUTES(&wlMain->iid, count, array_fvp,
					   flags, IFX_Handler)

		if (IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(flags)) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
			CHECK_N_SEND_NOTIFICATION(wlMain->iid, count, array_fvp,
						  flags, IFX_Handler)
		}

		/* Manipulate nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WLAN_MAIN);
	} else if (IFX_DELETE_F_SET(flags)) {
		/* In case of DELETE operation, first send the notificatioupdate the ID
		   Mappings and then send the Notification for the attributes */
      /*********** Epilog Block **************/
		if (IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(flags)) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
			CHECK_N_SEND_NOTIFICATION(wlMain->iid, count, array_fvp,
						  flags, IFX_Handler)
		}

		UPDATE_ID_MAP_N_ATTRIBUTES(&wlMain->iid, count, array_fvp,
					   flags, IFX_Handler)
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "flags: 0x%x",
		       flags);
	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
		goto IFX_Handler;
	}
	/* reset flags to reload the configuration */
	g_flagConfigLoaded = 0;
	system("echo 0 > /tmp/web_Mainflg &");
	g_flagMainConfig = 0;

#ifdef TR69_DEFINED
	/* notify devm regarding the set in mapi */
	if(IFX_INT_DONT_SEND_SET_NOTIFICATION_F_NOT_SET(flags) && (wlMain->iid.config_owner == IFX_WEB)) {
//                ifx_tr69_value_change_notify(&wlMain->iid);
	}
#endif /* #ifdef TR69_DEFINED */

IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "ret: %d", ret);
	LTQ_LOG_TIMESTAMP("Done");
	return ret;
}

/**
   \param   wlPhyCfg - pointer to IFX_MAPI_WLAN_PhyCfg structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE

   \remarks -  Only modify operation is supported on device type = AP
            -  validation to check for combination of standard, country, op-reates, basic-rates and channels
            -  wireless start script checks if both phy-radio and this ap/vap is enabled, then only starts the service
*/
int32
ifx_mapi_set_wlan_phy_config(uint32 oper, IFX_MAPI_WLAN_PhyCfg * wlPhyCfg,
			     uint32 flags)
{
	char8 conf_buf[MAX_DATA_LEN];
	int32 count = 0, changed_count = 0, passed_index = -1, ret = IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_PHY_PARAM_COUNT];
	IFX_NAME_VALUE_PAIR *array_changed_fvp = NULL;
	IFX_MAPI_WLAN_MainCfg	wlMain;
	IFX_MAPI_WLAN_MainCfg	*wlMainAll = NULL;
	IFX_MAPI_WLAN_SecCfg	*wlSecAll = NULL;
	uint32	nVap = 0;
	int32 i = 0, f_chgNetMode = FALSE, f_chgNetModeVap = FALSE;
	LTQ_MAPI_WLAN_Vendor	vendor = LTQ_MAPI_WLAN_VENDOR_NONE;
	LTQ_MAPI_WLAN_Feature	features = LTQ_MAPI_WLAN_FEATURE_NONE;

	LTQ_LOG_TIMESTAMP("Begin");

	memset(array_fvp, 0, sizeof(array_fvp));
	NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));

   /*************** Prolog Block *********************/
	/* only modify operation is supported */
	if (oper == IFX_OP_MOD)
		flags |= IFX_F_MODIFY;
	else {
		ret = IFX_FAILURE;
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "");
		goto IFX_Handler;
	}

   /**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(wlPhyCfg)
		    /* Do simple validation of flags sucha as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

	/* set cpeId.ID and pcpeId.ID of wlPhyCfg */
	/*
	   \todo check for dual radio setup, for now assume only one radio and set
	   to fixed (default) value */
	sprintf(wlPhyCfg->iid.cpeId.secName, "%s", TAG_WLAN_PHY);
	sprintf(wlPhyCfg->iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
	/* default is 1 */

	// kamal: change
	// wlPhyCfg->iid.cpeId.Id = 1;
	/* parent is always LAN -> fixed value = 1 */
	wlPhyCfg->iid.pcpeId.Id = 1;	// cpeid of lan device

	/* return immediately if no parameter changed */
	mapiWlanChkPhyCfgChg(wlPhyCfg->iid.cpeId.Id - 1, wlPhyCfg);
	if (!g_flagRadioEnaChanged && !g_flagRadioCfgChanged && !g_flagNetModeVapCfgChanged) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "");
		LTQ_LOG_TIMESTAMP("Done");
		return IFX_SUCCESS;
	}

	/* get vendor information */
	vendor = ltq_mapi_get_wlan_vendor(wlPhyCfg->iid.cpeId.Id, IFX_F_DEFAULT);
	features = ltq_mapi_get_wlan_supported_features(wlPhyCfg->iid.cpeId.Id, IFX_F_DEFAULT);

	if (features & LTQ_MAPI_WLAN_FEATURE_AUTOCOC) {
		if (g_flagRadioEnaChanged) {
			/* Radio gets enabled, thus re-establish old CoC configuration */
			if (wlPhyCfg->radioEnable) {
				wlPhyCfg->phyAutoCoC.autoCocEnable = wlPhyCfg->phyAutoCoC.prevAutoCocEnable;
				wlPhyCfg->phyAutoCoC.nAntennas = wlPhyCfg->phyAutoCoC.nPrevAntennas;
			} else {
				/* Radio gets disabled, thus save CoC configuration and disable CoC*/
				wlPhyCfg->phyAutoCoC.prevAutoCocEnable = wlPhyCfg->phyAutoCoC.autoCocEnable;
				wlPhyCfg->phyAutoCoC.nPrevAntennas = wlPhyCfg->phyAutoCoC.nAntennas;
				wlPhyCfg->phyAutoCoC.autoCocEnable = 0;
				wlPhyCfg->phyAutoCoC.nAntennas = 0;
				g_flagAutoCocCfgChanged = TRUE;
			}
		}
		if (g_flagAutoCocCfgChanged) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "cpeId: %d",
				wlPhyCfg->phyAutoCoC.iid.cpeId.Id);
			if ((ret = ltq_mapi_set_wlan_phy_auto_coc_config(
				IFX_OP_MOD, &wlPhyCfg->phyAutoCoC, flags | IFX_F_DONT_WRITE_TO_FLASH |
				IFX_F_INT_DONT_CHECK_ACL)) != IFX_SUCCESS) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig",
					"ltq_mapi_set_wlan_phy_auto_coc_config has failed");
				goto IFX_Handler;
			}
		}
	}

	if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
		if ((ret = ltq_mapi_set_wlan_vendor_wave_cfg(
			IFX_OP_MOD, &wlPhyCfg->wlVendorWaveCfg, flags |
			IFX_F_DONT_WRITE_TO_FLASH | IFX_F_INT_DONT_CHECK_ACL)) !=
			IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig",
				"ltq_mapi_set_wlan_vendor_wave_cfg has failed");
			goto IFX_Handler;
		}
	}

	if (features & LTQ_MAPI_WLAN_FEATURE_NETMODE_PER_VAP) {
		if (ifx_mapi_get_all_wlan_main_config(&nVap, &wlMainAll,
			IFX_F_DEFAULT) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "");
				goto IFX_Handler;
		}
		if (ifx_mapi_get_all_wlan_security_config(&nVap, &wlSecAll,
			IFX_F_DEFAULT) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "");
				goto IFX_Handler;
		}
		/* loop through all VAPs in system */
		for (i = 0; i < nVap; i++) {
			f_chgNetModeVap = FALSE;
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "i: %d", i);
			/* do this for all vaps of this phy */
			if (wlMainAll[i].radioCpeId == wlPhyCfg->iid.cpeId.Id) {
				memset(&wlMain, 0, sizeof(IFX_MAPI_WLAN_MainCfg));
				/* copy wlan main configuration from global variable */
				memcpy(&wlMain, &wlMainAll[i], sizeof(IFX_MAPI_WLAN_MainCfg));
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig",
					"netModeClass: %d, old netModeClass: %d, "
					"standard: %d, old standard: %d", wlPhyCfg->netModeClass,
					g_wlPhy[wlPhyCfg->iid.cpeId.Id-1].netModeClass,
					wlPhyCfg->standard,
					g_wlPhy[wlPhyCfg->iid.cpeId.Id-1].standard);

				if (wlPhyCfg->netModeClass != LTQ_MAPI_WLAN_NET_CLASS_OFF) {
					/* network mode per vap is enabled; check if each vap has correct setting */
					switch (wlPhyCfg->netModeClass) {
					case LTQ_MAPI_WLAN_NET_CLASS_B_N:
						if ((wlMain.networkMode != IFX_MAPI_WLAN_STD_802_11B) &&
							(wlMain.networkMode != IFX_MAPI_WLAN_STD_802_11N)) {
							f_chgNetMode = f_chgNetModeVap = TRUE;
							wlMain.networkMode = IFX_MAPI_WLAN_STD_802_11N;
						}
						break;
					case LTQ_MAPI_WLAN_NET_CLASS_G_BG_GN_BGN:
						if ((wlMain.networkMode != IFX_MAPI_WLAN_STD_802_11G) &&
							(wlMain.networkMode != IFX_MAPI_WLAN_STD_802_11BG) &&
							(wlMain.networkMode != IFX_MAPI_WLAN_STD_802_11GN) &&
							(wlMain.networkMode != IFX_MAPI_WLAN_STD_802_11BGN)) {
							f_chgNetMode = f_chgNetModeVap = TRUE;
							wlMain.networkMode = IFX_MAPI_WLAN_STD_802_11BGN;
						}
						break;
					case LTQ_MAPI_WLAN_NET_CLASS_A_N_AN:
						if ((wlMain.networkMode != IFX_MAPI_WLAN_STD_802_11A) &&
							(wlMain.networkMode != IFX_MAPI_WLAN_STD_802_11N) &&
							(wlMain.networkMode != IFX_MAPI_WLAN_STD_802_11AN)) {
							f_chgNetMode = f_chgNetModeVap = TRUE;
							wlMain.networkMode = IFX_MAPI_WLAN_STD_802_11N;
						}
						break;
					default:
						IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "i: %d", i);
						break;
					}
				} else {
					/* else: Network per VAP is disabled */
					/*
						we need to check if global network mode has changed or
						if network per VAP feature has been disabled;
						in those two cases the network mode per vap must be set
					*/
					if ((wlPhyCfg->standard != g_wlPhy[wlPhyCfg->iid.cpeId.Id-1].standard) ||
						(wlPhyCfg->netModeClass != g_wlPhy[wlPhyCfg->iid.cpeId.Id-1].netModeClass)) {
						wlMain.networkMode = wlPhyCfg->standard;
						IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig",
							"wlMain[%d].networkMode: %d", i, wlMain.networkMode);
						f_chgNetMode = TRUE;
					} 
				}
				if ((f_chgNetModeVap) || (f_chgNetMode)) {
					if ((wlSecAll[i].wlEncr == IFX_MAPI_WLAN_ENCR_WEP) ||
						(wlSecAll[i].wlEncr == IFX_MAPI_WLAN_ENCR_TKIP)) {
						switch (wlMain.networkMode) {
						case IFX_MAPI_WLAN_STD_802_11BGN:
							wlMain.networkMode = IFX_MAPI_WLAN_STD_802_11BG;
							break;
						case IFX_MAPI_WLAN_STD_802_11GN:
							wlMain.networkMode = IFX_MAPI_WLAN_STD_802_11G;
							break;
						case IFX_MAPI_WLAN_STD_802_11AN:
							wlMain.networkMode = IFX_MAPI_WLAN_STD_802_11A;
							break;
						default:
							break;
						}
					}
					if ((ret = ifx_mapi_set_wlan_main_config(IFX_OP_MOD, &wlMain,
						IFX_F_INT_DONT_CONFIGURE | IFX_F_DONT_WRITE_TO_FLASH | 
						IFX_F_INT_DONT_SEND_SET_NOTIFICATION)) != IFX_SUCCESS) {
						IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig",
							"ifx_mapi_set_wlan_main_config has failed");
						goto IFX_Handler;
					}
				}
			}
		}
	}

	/*********************** Name Value Formation as per RC.CONF **********************/
	ifx_fill_ArrayFvp_FName(array_fvp, 0, WLAN_PHY_PARAM_COUNT,
		wlan_phy_params);

	ifx_fill_ArrayFvp_intValues(array_fvp, 0, 3,
		(int32 *) & wlPhyCfg->iid.cpeId.Id, &wlPhyCfg->iid.pcpeId.Id,
		&wlPhyCfg->standard);

	sprintf(array_fvp[3].value, "%s", wlPhyCfg->country);
	sprintf(array_fvp[4].value, "%d", wlPhyCfg->usageEnv);
	sprintf(array_fvp[5].value, "%d", wlPhyCfg->freqBand);

	/* channel number is uint8 type and can not be set with
	   ifx_fill_ArrayFvp_intValues */
	sprintf(array_fvp[6].value, "%u", wlPhyCfg->channelNo);
	sprintf(array_fvp[7].value, "%d", wlPhyCfg->autoChannelEna);
	sprintf(array_fvp[8].value, "%d", wlPhyCfg->beaconTxEna);
	sprintf(array_fvp[9].value, "%d", wlPhyCfg->beaconIntvl);

	/* DTIM interval is uint8 type and can not be set with
	   ifx_fill_ArrayFvp_intValues */
	sprintf(array_fvp[10].value, "%d", wlPhyCfg->dtimInt);
	ifx_fill_ArrayFvp_intValues(array_fvp, 11, 3, (int32 *) & wlPhyCfg->rts,
				    &wlPhyCfg->fts, &wlPhyCfg->powerLvl);
	sprintf(array_fvp[14].value, "%d", wlPhyCfg->radioEnable);
	sprintf(array_fvp[15].value, "%d", wlPhyCfg->autoRateFallBackEna);

	/* if network mode changed, staticRate is reset to AUTO to be save */
	if (wlPhyCfg->standard != g_wlPhy[wlPhyCfg->iid.cpeId.Id - 1].standard) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "old mode: %d, new mode: %d",
			g_wlPhy[wlPhyCfg->iid.cpeId.Id - 1].standard, wlPhyCfg->standard);
		wlPhyCfg->staticRate = 0;
	}

	if (wlPhyCfg->staticRate == 0)
		sprintf(array_fvp[16].value, "%d", (int32) wlPhyCfg->staticRate);
	else
		sprintf(array_fvp[16].value, "%.1f", wlPhyCfg->staticRate);

	sprintf(array_fvp[17].value, "%d", wlPhyCfg->preamble);

	sprintf(array_fvp[18].value, "%d", wlPhyCfg->phy11N.chanBW);

	sprintf(array_fvp[19].value, "%d", wlPhyCfg->phy11N.extChPos);

	sprintf(array_fvp[20].value, "%d", wlPhyCfg->phy11N.guardIntvl);

	sprintf(array_fvp[21].value, "%d", wlPhyCfg->phy11N.mcs);

	sprintf(array_fvp[22].value, "%d",
		wlPhyCfg->phy11N.diversity.diversityEna);
	sprintf(array_fvp[23].value, "%d",
		wlPhyCfg->phy11N.diversity.diversityDir);
	sprintf(array_fvp[24].value, "%d", wlPhyCfg->phy11N.diversity.antenna);
	sprintf(array_fvp[25].value, "%d", wlPhyCfg->phy11N.rxStbc);

	sprintf(array_fvp[26].value, "%d", wlPhyCfg->phy11N.baWinSize);

	sprintf(array_fvp[27].value, "%d", wlPhyCfg->phy11N.aggr.ampduEna);
	sprintf(array_fvp[28].value, "%d", wlPhyCfg->phy11N.aggr.ampduDir);
	sprintf(array_fvp[29].value, "%d", wlPhyCfg->phy11N.aggr.ampduLen);
	sprintf(array_fvp[30].value, "%d",
		wlPhyCfg->phy11N.aggr.ampduFrmsDensity);
	sprintf(array_fvp[31].value, "%d", wlPhyCfg->phy11N.aggr.amsduEna);
	sprintf(array_fvp[32].value, "%d", wlPhyCfg->phy11N.aggr.amsduDir);
	sprintf(array_fvp[33].value, "%d", wlPhyCfg->phy11N.aggr.amsduLen);

	/* validation: channel bandwidth cannot have values for 80MHz or 160MHz 
		if selected standard is not 802.11ac */
	if ((wlPhyCfg->standard < IFX_MAPI_WLAN_STD_802_11AC) &&
		(wlPhyCfg->phy11N.chanBW >= IFX_MAPI_WLAN_BW_80MHZ)) {
		wlPhyCfg->phy11N.chanBW = IFX_MAPI_WLAN_BW_40MHZ;
	}

	if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
		sprintf(array_fvp[34].value, "%d", wlPhyCfg->radarEna);
		sprintf(array_fvp[35].value, "%d", wlPhyCfg->phy11N.ldpcEna);
		sprintf(array_fvp[36].value, "%d", wlPhyCfg->beamForm);
		sprintf(array_fvp[37].value, "%d", wlPhyCfg->mc2ucEna);
		sprintf(array_fvp[38].value, "%d", wlPhyCfg->boostMode);
		/* turn off 40MHz for bg mode */
		if (wlPhyCfg->standard < IFX_MAPI_WLAN_STD_802_11N) {
			wlPhyCfg->phy11N.chanBW = IFX_MAPI_WLAN_BW_20MHZ;
		}
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "chanBW: %d",
		wlPhyCfg->phy11N.chanBW);

	/* turn off 20/40 coex for bg mode */
	if (wlPhyCfg->standard < IFX_MAPI_WLAN_STD_802_11N) {
		wlPhyCfg->phy11N.twentyFourtyCoex = 0;
	}
	sprintf(array_fvp[39].value, "%d", wlPhyCfg->phy11N.twentyFourtyCoex);
	sprintf(array_fvp[40].value, "%d", wlPhyCfg->phy11N.fourtyMHzIntolerant);
	sprintf(array_fvp[41].value, "%d", wlPhyCfg->phy11N.transDelayFactor);
	sprintf(array_fvp[42].value, "%d", wlPhyCfg->phy11N.obssScan);
	sprintf(array_fvp[43].value, "%d", wlPhyCfg->phy11N.twentyFortyCoexForceApParams);
	sprintf(array_fvp[44].value, "%d", wlPhyCfg->netModeClass);

	passed_index = -1;
	count = WLAN_PHY_PARAM_COUNT;

	/* Get Config Index in case of modify/delete operations from CPEID */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlPhyCfg->iid.cpeId, passed_index)
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "passed_index: %d",
		passed_index);

    /* determine the configuration index name is partial since index is not
       known fill array_fvp[] */
    if (ifx_get_conf_index_and_nv_pairs (&wlPhyCfg->iid, passed_index,
		PREFIX_WLAN_PHY, count, array_fvp, flags) != IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

   /************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	if (IFX_INT_DONT_CHECK_ACL_F_NOT_SET(flags)) {
		CHECK_ACL_RET(wlPhyCfg->iid, count, array_fvp, changed_count, 
			array_changed_fvp, flags, IFX_Handler)
	}

	/* before config file update, for modify or delete operation stop all
	   ap/vap */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) && IFX_MODIFY_F_SET(flags)) {
		if (!(features & LTQ_MAPI_WLAN_FEATURE_OPT_SCRIPTS)) {
			/* only stop AP */
			sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, passed_index);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig",
					   "conf_buf: %s", conf_buf);
			system(conf_buf);
		}
	}

   /************** System Config File Update Block ****************/
	/* Convert the name value pair in array_fvp into string format expected by
	   rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig",
		"conf_buf: %s", conf_buf);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_PHY, flags, 1, conf_buf);

	if (ret != IFX_SUCCESS)
		goto IFX_Handler;

   /*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* after config file update, for modify or add operation start all ap/vap */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_MODIFY_F_SET(flags)) {
		if (features & LTQ_MAPI_WLAN_FEATURE_OPT_SCRIPTS) {
			/* check if radio status has changed */
			if (wlPhyCfg->radioEnable != g_wlPhy[passed_index].radioEnable) {
				/* if radio config has changed call radio_modify script also */
				if (g_flagRadioCfgChanged) {
					sprintf(conf_buf, "%s %d 1", SERVICE_WLAN_RADIO_MODIFY,
						passed_index);
					LTQ_LOG_TIMESTAMP("SERVICE_WLAN_RADIO_MODIFY Begin");
					system(conf_buf);
					LTQ_LOG_TIMESTAMP("SERVICE_WLAN_RADIO_MODIFY Done");
					g_flagRadioCfgChanged = FALSE;
				}
				sprintf(conf_buf, "%s %d", SERVICE_WLAN_RADIO_ENABLE, passed_index);
				LTQ_LOG_TIMESTAMP("SERVICE_WLAN_RADIO_ENABLE Begin");
				system(conf_buf);
				LTQ_LOG_TIMESTAMP("SERVICE_WLAN_RADIO_ENABLE Done");
				g_flagRadioEnaChanged = FALSE;
			} else {
				if ((g_flagRadioCfgChanged) || (f_chgNetMode)) {
				sprintf(conf_buf, "%s %d 1", SERVICE_WLAN_RADIO_MODIFY, passed_index);
				g_flagRadioCfgChanged = FALSE;
				LTQ_LOG_TIMESTAMP("SERVICE_WLAN_RADIO_MODIFY Begin");
				system(conf_buf);
				LTQ_LOG_TIMESTAMP("SERVICE_WLAN_RADIO_MODIFY Done");
				}	
			}
		} else {
			if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
				sprintf(conf_buf, "%s", SERVICE_WLAN_START);
			} else {
				sprintf(conf_buf, "%s %d", SERVICE_WLAN_START, passed_index);
			}

			LTQ_LOG_TIMESTAMP();
			system(conf_buf);
			LTQ_LOG_TIMESTAMP();
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "conf_buf: %s",
			conf_buf);
	}

	/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if (IFX_MODIFY_F_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION(wlPhyCfg->iid, changed_count,
					  array_changed_fvp, flags, IFX_Handler)
	}

	/*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	/* no add/delete for phy object */

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* reset flags to reload the configuration */
	g_flagConfigLoaded = 0;
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "");
	system("echo 0 > /tmp/web_Phyflg &");

	//g_flagPhyConfig = 0;
	memcpy(&g_wlPhy[passed_index], wlPhyCfg, sizeof(IFX_MAPI_WLAN_PhyCfg));

#ifdef TR69_DEFINED
	/* notify devm regarding the set in mapi */
	if(IFX_INT_DONT_SEND_SET_NOTIFICATION_F_NOT_SET(flags) && (wlPhyCfg->iid.config_owner == IFX_WEB)) {
//                ifx_tr69_value_change_notify(&wlPhyCfg->iid);
	}
#endif /* #ifdef TR69_DEFINED */

IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp);
	IFX_MEM_FREE(wlMainAll);
	IFX_MEM_FREE(wlSecAll);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "ret: %d", ret);
	if (ret != IFX_SUCCESS) {
		g_flagConfigLoaded = 0;
		g_flagPhyConfig = 0;
	}
	LTQ_LOG_TIMESTAMP("Done");
	return ret;
}

/**
   This API configures the WLAN WEP parameters for given AP/VAP.

   \param   operation   - type of operation (ADD, MODIFY, DELETE)

   \param   wepKeyIndex -

   \param   wlWepKey    - pointer to IFX_MAPI_WLAN_SecCfg structure

   \param   flags       - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE

   \remarks - this api is a little different from the usual set apis. in that
               the format it stores in rc.conf is prefix{pcpeid}_0_param which
               is against conventional prefix_0_param. so be careful while
               calling the utility functions
            - this api cannot be called for all the 4 keys combined. since
              notification, update map and acl need single instance iid we
              cannot have the api handle all the 4 instances at a time. so it
              should be called for each of the 4 wep key objects one by one.
            - the api should be called with wlan_sec->wepKeyIndex filled with
              the wep key index that is operated irrespective of the operation
            - for this object WEP_KEY structure should be used and this will have
              cpeid and pcpeid filled for modify operation also key index should
              be given as seperate argument to this api
            - for wep key value can be either decimal or hex, so we need to
              introduce field in struct which says the key type in which the key
              is input
            - validation for wep key type and passphrase key type
            - wireless start script checks if both phy-radio and this ap/vap is
              enabled, then only starts the service
*/
int32
ifx_mapi_set_wlan_wep_key(uint32 operation, int32 wepKeyIndex,
			  IFX_MAPI_WLAN_WEP_Key * wlWepKey, uint32 flags)
{
	CPE_ID P_CPEID;
	char8 conf_buf[MAX_DATA_LEN], wep_key_prefix[MAX_FILELINE_LEN];
	int32 count = 0, changed_count = 0, passed_index = -1, ret =
	    IFX_SUCCESS, i;
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_WEP_CONFIG_PARAM_COUNT],
	    *array_changed_fvp = NULL;
	char8 *tmp, buf[12];
	char8 wepKeyInHex[4*IFX_MAPI_WEP_KEY_MAX_LEN]; /* IFX_MAPI_WEP_KEY_MAX_LEN already includes closing \0 */
	IFX_MAPI_WLAN_MainCfg wlMain;
	LTQ_MAPI_WLAN_Vendor	vendor = LTQ_MAPI_WLAN_VENDOR_NONE;
	LTQ_MAPI_WLAN_Feature	features = LTQ_MAPI_WLAN_FEATURE_NONE;

	LTQ_LOG_TIMESTAMP("Begin");

	memset(conf_buf, 0x00, sizeof(conf_buf));
	memset(array_fvp, 0x00, sizeof(array_fvp));

   /*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY) append the flag with
	   internal flags */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
   /**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(wlWepKey)
		    /* Do simple validation of flags sucha as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

	sprintf(wlWepKey->iid.cpeId.secName, "%s", TAG_WLAN_WEP);
	sprintf(wlWepKey->iid.pcpeId.secName, "%s", TAG_WLAN_SEC);

   /**************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_ADD_F_SET(flags)) {
		if (ifx_get_IID(&wlWepKey->iid, "key") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}

		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "tr69Id: %s",
			       wlWepKey->iid.tr69Id);
		/* workaround for changing the tr69id */
		tmp = NULL;
		tmp = strrchr(wlWepKey->iid.tr69Id, '.');
		if (tmp)
			*tmp = '\0';

		tmp = strrchr(wlWepKey->iid.tr69Id, '.');
		if (tmp != NULL) {
			sprintf(buf, "%d.", wepKeyIndex + 1);
			strcpy(tmp + 1, buf);
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "tr69Id: %s",
			       wlWepKey->iid.tr69Id);
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
   /**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given structure for ADD/MODIFY Operations */

	sprintf(wep_key_prefix, "%s%d", PREFIX_WLAN_WEP,
		wlWepKey->iid.pcpeId.Id);

	/* get the main configuration (required for vendor and features) */
	memset(&wlMain, 0, sizeof(IFX_MAPI_WLAN_MainCfg));
	sprintf(wlMain.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
	sprintf(wlMain.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
	wlMain.iid.cpeId.Id = wlWepKey->iid.pcpeId.Id;
	if ((ret = ifx_mapi_get_wlan_main_config(&wlMain, IFX_F_DEFAULT)) !=
			IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
		goto IFX_Handler;
	}
	/* get vendor information and supported features */
	vendor = ltq_mapi_get_wlan_vendor(wlMain.radioCpeId, IFX_F_DEFAULT);
	features = ltq_mapi_get_wlan_supported_features(wlMain.radioCpeId,
		IFX_F_DEFAULT);

	count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, count, WLAN_WEP_CONFIG_PARAM_COUNT,
			wlan_wep_config_params);

		sprintf(array_fvp[0].value, "%d", wlWepKey->iid.cpeId.Id);
		sprintf(array_fvp[1].value, "%d", wlWepKey->iid.pcpeId.Id);

		if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			/*
				only do the conversion if WEP key is ASCII
				(length == 5 or length == 13)
			*/
			if ((strlen(wlWepKey->wepKey) == 5) ||
				(strlen(wlWepKey->wepKey) == 13)) {
				memset(wepKeyInHex, 0, sizeof(wepKeyInHex));
				/* convert ascii representation of ssid to hex representation */
				mapi_wlan_convert_ascii_to_hex(wlWepKey->wepKey, wepKeyInHex);
				sprintf(array_fvp[2].value, "%s", wepKeyInHex);
			} else {
				sprintf(array_fvp[2].value, "%s", wlWepKey->wepKey);
			}
		} else {
			sprintf(array_fvp[2].value, "%s", wlWepKey->wepKey);
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey",
			"wepKey: %s", array_fvp[2].value);
		passed_index = -1;
	}

	count = WLAN_WEP_CONFIG_PARAM_COUNT;

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "cpeID: %d, %s",
		wlWepKey->iid.cpeId.Id, wlWepKey->iid.cpeId.secName);
	/* Get Config Index in case of modify operation from CPEID */
	if ((IFX_MODIFY_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlWepKey->iid.cpeId,
					 passed_index)
	}

	/*
	   in case of add operation first assign wlan_sec->wepKeyIndex to
	   passed_index and then call the function, so that it does not try to get
	   the new index from section count */

	if (IFX_INT_ADD_F_SET(flags) || (IFX_DELETE_F_SET(flags)))
		passed_index = wepKeyIndex;

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "passed_index: %d",
		       passed_index);
	/*
	   Determine the configuration index - for Add, Delete, Modify operations
	   \note - Name is partial since index is not known - Fill array_fvp[] */
	if (ifx_get_conf_index_and_nv_pairs
	    (&wlWepKey->iid, passed_index, wep_key_prefix, count, array_fvp,
	     flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif				/* #ifdef IFX_LOG_DEBUG */
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

   /************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	if (IFX_ADD_F_NOT_SET(flags) && IFX_INT_DONT_CHECK_ACL_F_NOT_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey",
			       "config_owner: %d, cpeId: %d, pcpeId: %d",
			       wlWepKey->iid.config_owner,
			       wlWepKey->iid.cpeId.Id, wlWepKey->iid.pcpeId.Id);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey",
			       "cpeId.secName: %s, pcpeId.secName: %s",
			       wlWepKey->iid.cpeId.secName,
			       wlWepKey->iid.pcpeId.secName);
		CHECK_ACL_RET(wlWepKey->iid, count, array_fvp, changed_count,
			      array_changed_fvp, flags, IFX_Handler)
	}

	for (i = 0; i < WLAN_WEP_CONFIG_PARAM_COUNT; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey",
			       "name: %s, value: %s", array_fvp[i].fieldname,
			       array_fvp[i].value);
	/*
	   before updating the config file: stop the AP/VAP in case of delete
	   operation only */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags) && IFX_DELETE_F_SET(flags)) {
		if (!(features & LTQ_MAPI_WLAN_FEATURE_OPT_SCRIPTS)) {
			/* use the parent cpeid to get index of the parent instance */
			P_CPEID.Id = wlWepKey->iid.pcpeId.Id;
			sprintf(P_CPEID.secName, "%s", TAG_WLAN_MAIN);
			IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, P_CPEID, passed_index)
			sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, passed_index);
			LTQ_LOG_TIMESTAMP();
			system(conf_buf);
			LTQ_LOG_TIMESTAMP();
		}
	}

   /************** System Config File Update Block ****************/
	/* Convert the name value pair in array_fvp into string format expected by
	   rc.conf file */
	ret = form_cfgdb_buf(conf_buf, count, array_fvp);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "conf_buf: %s",
		       conf_buf);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_WEP, flags, 1, conf_buf);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
		goto IFX_Handler;
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");

   /**************** Device Configuration Block *********************/
	/*
	   Device config thru Scripts/Utilities or Functions after config file
	   update, for modify operation start script for applying the changes */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags)) {
		if (operation == IFX_OP_MOD) {
			if (g_wlMain[passed_index].apEnable) {
				sprintf(conf_buf, "%s %d &", SERVICE_WLAN_SEC_MODIFY,
					passed_index);
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "conf_buf: %s",
					conf_buf);
				LTQ_LOG_TIMESTAMP();
				system(conf_buf);
				LTQ_LOG_TIMESTAMP();
			}
		}
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");

	/* this will Compact the section and also update the count for both ADD and
	   DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags)) {
		ret =
		    ifx_UpdateCountInSection(FILE_RC_CONF, TAG_WLAN_WEP, flags);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey",
				       "ret: %d", ret);
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
	}
   /*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

   /*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_MODIFY_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
		CHECK_N_SEND_NOTIFICATION(wlWepKey->iid, changed_count,
					  array_changed_fvp, flags, IFX_Handler)
	} else if (IFX_INT_ADD_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
		/* In case of ADD operation, first update the ID Mappings and then send
		   the Notification for the attributes */
      /*********** Epilog Block **************/
		UPDATE_ID_MAP_N_ATTRIBUTES(&wlWepKey->iid, count, array_fvp,
					   flags, IFX_Handler)

		    if (IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(flags)) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
			CHECK_N_SEND_NOTIFICATION(wlWepKey->iid, count,
						  array_fvp, flags, IFX_Handler)
		}

		/* Manipulate nextCpeId only for ADD operations */
		ret = ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WLAN_WEP);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey",
				       "ret: %d", ret);
			goto IFX_Handler;
		}
	} else if (IFX_DELETE_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
		/* In case of DELETE operation, first send the notificatioupdate the ID
		   Mappings and then send the Notification for the attributes */
      /*********** Epilog Block **************/
		if (IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(flags)) {
			CHECK_N_SEND_NOTIFICATION(wlWepKey->iid, count,
						  array_fvp, flags, IFX_Handler)
			    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey",
					   "ret: %d", ret);
		}

		UPDATE_ID_MAP_N_ATTRIBUTES(&wlWepKey->iid, count, array_fvp,
					   flags, IFX_Handler)
		    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "ret: %d",
				   ret);
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "ret: %d", ret);
		goto IFX_Handler;
	}

	/* reset flags to reload the configuration */
	g_flagConfigLoaded = 0;
	g_flagSecConfig = 0;
	system("echo 0 > /tmp/web_Secflg &");

#ifdef TR69_DEFINED
	/* notify devm regarding the set in mapi */
	if(IFX_INT_DONT_SEND_SET_NOTIFICATION_F_NOT_SET(flags) && (wlWepKey->iid.config_owner == IFX_WEB)) {
//		ifx_tr69_value_change_notify(&wlWepKey->iid);
	}
#endif

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "ret: %d", ret);
	IFX_MEM_FREE(array_changed_fvp);
	LTQ_LOG_TIMESTAMP("Done");
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/**
   This API configures a set of WLAN WEP keys for a given AP/VAP.

   \param   operation   - type of operation (ADD, MODIFY, DELETE)

   \param   wlWepCfg    - pointer to IFX_MAPI_WLAN_WEP_Cfg structure

   \param   flags       - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE

   \remarks this api can only be called for modify operation
*/
int32
ifx_mapi_set_wlan_wep_config(uint32 oper, IFX_MAPI_WLAN_WEP_Cfg * wlWepCfg,
			     uint32 flags)
{
	CPE_ID parentCpeId;
	char8 conf_buf[MAX_DATA_LEN];
	int32 passed_index = -1, ret = IFX_SUCCESS, i;
	IFX_MAPI_WLAN_WEP_Key wlWepKey;
	LTQ_MAPI_WLAN_Feature	features = LTQ_MAPI_WLAN_FEATURE_NONE;

	LTQ_LOG_TIMESTAMP("Begin");

	memset(conf_buf, 0x00, sizeof(conf_buf));
	memset(&wlWepKey, 0, sizeof(IFX_MAPI_WLAN_WEP_Key));

   /*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY) append the flag with
	   internal flags */
	if ((oper == IFX_OP_ADD) || (oper == IFX_OP_DEL)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepConfig", "");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

   /**************** Validation Block *****************/
	if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(wlWepCfg)
		    /* Do simple validation of flags such as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

	sprintf(wlWepKey.iid.cpeId.secName, "%s", TAG_WLAN_WEP);
	sprintf(wlWepKey.iid.pcpeId.secName, "%s", TAG_WLAN_SEC);

	for (i = 0; i < IFX_MAPI_NUM_WEP_KEYS; i++) {
		wlWepKey.iid.cpeId.Id = wlWepCfg->wepKey[i].iid.cpeId.Id;
		wlWepKey.iid.pcpeId.Id = wlWepCfg->wepKey[i].iid.pcpeId.Id;
		wlWepKey.iid.config_owner =
		    wlWepCfg->wepKey[i].iid.config_owner;
		strncpy(wlWepKey.wepKey, wlWepCfg->wepKey[i].wepKey,
			sizeof(wlWepCfg->wepKey[i].wepKey));
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepConfig", "wepKey: %s",
			       wlWepKey.wepKey);

		if ((ret =
		     ifx_mapi_set_wlan_wep_key(oper, i, &wlWepKey,
					       flags | IFX_F_INT_DONT_CONFIGURE
					       | IFX_F_DONT_WRITE_TO_FLASH | IFX_F_INT_DONT_SEND_SET_NOTIFICATION)) !=
		    IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepConfig",
				       "ifx_mapi_set_wlan_wep_key has failed");
			goto IFX_Handler;
		}
	}

	/* use the parent cpeid to get index of the parent instance */
	parentCpeId.Id = wlWepKey.iid.pcpeId.Id;
	sprintf(parentCpeId.secName, "%s", TAG_WLAN_MAIN);
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, parentCpeId, passed_index)
	    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepConfig",
			   "passed_index: %d", passed_index);

	if ((ret =
	     mapiWlanSetWepInSecurity(oper, wlWepCfg, passed_index,
				      flags)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepConfig",
			       "ifx_mapi_set_wlan_wep_key has failed");
		goto IFX_Handler;
	}

	/* Device config thru Scripts/Utilities or Functions */
	/* after config file update, for modify or add operation start all ap/vap */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags)) {
		if (g_wlMain[passed_index].apEnable) {
			features = ltq_mapi_get_wlan_supported_features(
				g_wlMain[passed_index].radioCpeId, IFX_F_DEFAULT);
			if (features & LTQ_MAPI_WLAN_FEATURE_OPT_SCRIPTS) {
				if (IFX_F_INT_DONT_START_WLAN_IF_ON_SECURITY_CHANGE_F_SET(flags)) {
					sprintf(conf_buf, "%s %d 0", SERVICE_WLAN_SEC_MODIFY, passed_index);
				}
				else {
					sprintf(conf_buf, "%s %d 1", SERVICE_WLAN_SEC_MODIFY, passed_index);
				}
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepConfig", "conf_buf: %s",
					conf_buf);
				LTQ_LOG_TIMESTAMP();
				system(conf_buf);
				LTQ_LOG_TIMESTAMP();
			} else {
				sprintf(conf_buf, "%s %d", SERVICE_WLAN_SEC_MODIFY, passed_index);
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepConfig", "conf_buf: %s",
					conf_buf);
				LTQ_LOG_TIMESTAMP();
				system(conf_buf);
				LTQ_LOG_TIMESTAMP();
			}
		}
	}

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepConfig", "ret: %d",
			       ret);
		goto IFX_Handler;
	}

	/* reset flags to reload the configuration */
	g_flagConfigLoaded = 0;
	g_flagSecConfig = 0;
	system("echo 0 > /tmp/web_Secflg &");

#ifdef TR69_DEFINED
	/* notify devm regarding the set in mapi */
	if(IFX_INT_DONT_SEND_SET_NOTIFICATION_F_NOT_SET(flags) && (wlWepKey.iid.config_owner == IFX_WEB)) {
//		ifx_tr69_value_change_notify(&wlWepKey.iid);
	}
#endif

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepConfig", "ret: %d", ret);
	LTQ_LOG_TIMESTAMP("Done");
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/**
   This API configures the WLAN WEP parameters in the security objecet for given AP/VAP.

   \param   operation   - type of operation (ADD, MODIFY, DELETE)

   \param   wlWepCfg    - pointer to IFX_MAPI_WLAN_WEP_Cfg structure

   \param   passed_index - index of security object

   \param   flags       - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
static int32
mapiWlanSetWepInSecurity(uint32 operation,
			 IFX_MAPI_WLAN_WEP_Cfg * wlWepCfg, int32 passed_index,
			 uint32 flags)
{
	int32 ret = IFX_SUCCESS, count, i, changed_count = 0;
	char8 buf[MAX_FILELINE_LEN], *sValue = NULL, conf_buf[MAX_DATA_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_SEC_PARAM_COUNT], *array_changed_fvp = NULL;
	IFX_ID wlSecId;

	IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanSetWepInSecurity",
		       "passed_index: %d, flags: %d", passed_index, flags);

	memset(&wlSecId, 0x00, sizeof(wlSecId));
	memset(array_fvp, 0x00, sizeof(array_fvp));

	wlSecId.cpeId.Id = wlWepCfg->wepKey[0].iid.pcpeId.Id;
	wlSecId.config_owner = wlWepCfg->wepKey[0].iid.config_owner;
	sprintf(wlSecId.cpeId.secName, "%s", TAG_WLAN_SEC);
	sprintf(wlSecId.pcpeId.secName, "%s", TAG_LAN_DEVICE);

   /*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY) append the flag with
	   internal flags */
	if (operation != IFX_OP_MOD) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanSetWepInSecurity",
			       "only modify operation");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	flags |= IFX_F_MODIFY;

   /**************** Validation Block *****************/

	sprintf(buf, "%s_%d_", PREFIX_WLAN_SEC, passed_index);
	if ((ret =
	     ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_SEC, buf, IFX_F_DEFAULT,
			      &sValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanSetWepInSecurity", "buf: %s",
			       buf);
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanSetWepInSecurity",
		       "buf: %s, passed_index: %d, sValue: %s",
		       buf, passed_index, sValue);

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);

	sprintf(array_fvp[11].value, "%d", wlWepCfg->wepEncrLevel);
	sprintf(array_fvp[12].value, "%d", wlWepCfg->wepKeyType);
	sprintf(array_fvp[13].value, "%d", wlWepCfg->wepKeyIndex);
	for (i = 0; i < count; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanSetWepInSecurity", "%s:%s",
			       array_fvp[i].fieldname, array_fvp[i].value);

   /************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	if (IFX_INT_DONT_CHECK_ACL_F_NOT_SET(flags)) {
		CHECK_ACL_RET(wlSecId, count, array_fvp,
			      changed_count, array_changed_fvp, flags,
			      IFX_Handler)
	}

   /************** System Config File Update Block ****************/
	/* Convert the name value pair in array_fvp into string format expected by
	   rc.conf file */
	ret = form_cfgdb_buf(conf_buf, count, array_fvp);
	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanSetWepInSecurity", "");
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanSetWepInSecurity", "conf_buf: %s",
		       conf_buf);
	/* RC.CONF Configuration block */
	if ((ret =
	     ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_SEC, flags, 1,
			    conf_buf)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanSetWepInSecurity", "");
		goto IFX_Handler;
	}

   /*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* after config file update, for modify or add operation start all ap/vap */

   /*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

   /*********** Epilog Block **************/
	CHECK_N_SEND_NOTIFICATION(wlSecId, changed_count, array_changed_fvp,
				  flags, IFX_Handler)

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanSetWepInSecurity", "");
		goto IFX_Handler;
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanSetWepInSecurity", "ret: %d", ret);
	IFX_MEM_FREE(array_changed_fvp);
	IFX_MEM_FREE(sValue);
	return ret;
}

/**
   This API configures the WLAN PSK parameters for given AP/VAP.

   \param   operation   - type of operation (ADD, MODIFY, DELETE)

   \param   wlPsk       - pointer to IFX_MAPI_WLAN_PSKey structure

   \param   flags       - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE

   \remarks - this api is a little different from the usual set apis. in that
               the format it stores in rc.conf is prefix{pcpeid}_0_param which
               is against conventional prefix_0_param.
            - for passphrase key value can be either decimal or hex, so we need
               to introduce field in struct which says the key type in which the
               key is input
*/
static int32
mapiWlanSetPersonalConfig(uint32 operation, IFX_MAPI_WLAN_PSKey * wlPsk,
			  uint32 flags)
{
	CPE_ID P_CPEID;
	char8 conf_buf[MAX_DATA_LEN], psk_prefix[MAX_FILELINE_LEN];
	int32 count = 0, changed_count = 0, passed_index = -1;
	int32 ret = IFX_SUCCESS, i;
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_PSK_PARAM_COUNT], *array_changed_fvp = NULL;
	char8 *tmp, buf[] = "1.";
	char8 passphraseInHex[4*IFX_MAPI_PSK_MAX_LEN]; /* IFX_MAPI_PSK_MAX_LEN already includes closing \0 */
	IFX_MAPI_WLAN_MainCfg wlMain;
	LTQ_MAPI_WLAN_Vendor	vendor = LTQ_MAPI_WLAN_VENDOR_NONE;
	LTQ_MAPI_WLAN_Feature	features = LTQ_MAPI_WLAN_FEATURE_NONE;

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");

	memset(&P_CPEID, 0x00, sizeof(P_CPEID));
	memset(array_fvp, 0x00, sizeof(array_fvp));

   /*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY) append the flag with
	   internal flags */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

	sprintf(wlPsk->iid.cpeId.secName, "%s", TAG_WLAN_PASSPHRASE);
	sprintf(wlPsk->iid.pcpeId.secName, "%s", TAG_WLAN_SEC);

   /**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(wlPsk)
		    /* Do simple validation of flags sucha as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
		    /* Validate key type for ascii value */
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
   /**************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_ADD_F_SET(flags)) {
		/*
		   get the next cpe id for the section wlPsk from the next_cpe_id
		   section in rc.conf and store it as cpeId; the distinct parameter
		   passPhrase is provided for TR69 */
		if (ifx_get_IID(&wlPsk->iid, "passPhrase") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase",
			       "tr69Id: %s", wlPsk->iid.tr69Id);
		/* workaround for changing the tr69id as 1 for all psk objects */
		tmp = NULL;
		tmp = strrchr(wlPsk->iid.tr69Id, '.');
		if (tmp)
			*tmp = '\0';

		tmp = strrchr(wlPsk->iid.tr69Id, '.');
		if (tmp != NULL)
			strcpy(tmp + 1, buf);

		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase",
			       "tr69Id: %s", wlPsk->iid.tr69Id);
	}

   /**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given structure for ADD/MODIFY Operations */

	/*
	   the format for wlPsk object is wlPsk<pCpeId>_<Index>_param for this
	   purpose we are defining the used prefix wlPsk<pCpeId> here */
	sprintf(psk_prefix, "%s%d", PREFIX_WLAN_PASSPHRASE,
		wlPsk->iid.pcpeId.Id);

	memset(&wlMain, 0, sizeof(IFX_MAPI_WLAN_MainCfg));
	sprintf(wlMain.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
	sprintf(wlMain.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
	wlMain.iid.cpeId.Id = wlPsk->iid.pcpeId.Id;
	if ((ret = ifx_mapi_get_wlan_main_config(&wlMain, IFX_F_DEFAULT)) !=
		IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
		goto IFX_Handler;
	}
	/* get vendor information and supported features */
	vendor = ltq_mapi_get_wlan_vendor(wlMain.radioCpeId, IFX_F_DEFAULT);
	features = ltq_mapi_get_wlan_supported_features(wlMain.radioCpeId,
		IFX_F_DEFAULT);

	count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, count, WLAN_PSK_PARAM_COUNT,
					wlan_psk_params);
		sprintf(array_fvp[0].value, "%d", wlPsk->iid.cpeId.Id);
		sprintf(array_fvp[1].value, "%d", wlPsk->iid.pcpeId.Id);

		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase",
			       "passPhrase: %s, psk: %s", wlPsk->passPhrase,
			       wlPsk->preSharedKey);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase",
			       "passPhraseLength: %d, pskLength: %d",
			       strlen(wlPsk->passPhrase),
			       strlen(wlPsk->preSharedKey));

		if (strlen(wlPsk->passPhrase) > 0) {
			sprintf(array_fvp[2].value, "%d", IFX_MAPI_WLAN_ASCII_KEY);
			if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
				memset(passphraseInHex, 0, sizeof(passphraseInHex));
				/* convert ascii representation of ssid to hex representation */
				mapi_wlan_convert_ascii_to_hex(wlPsk->passPhrase, passphraseInHex);
				sprintf(array_fvp[3].value, "%s", passphraseInHex);
			} else {
				sprintf(array_fvp[3].value, "%s", wlPsk->passPhrase);
			}

			sprintf(array_fvp[4].value, "%s", "");
		} else if (strlen(wlPsk->preSharedKey) > 0) {
			sprintf(array_fvp[2].value, "%d", IFX_MAPI_WLAN_HEX_KEY);
			sprintf(array_fvp[3].value, "%s", "");
			sprintf(array_fvp[4].value, "%s", wlPsk->preSharedKey);
		} else {
			sprintf(array_fvp[2].value, "%d", IFX_MAPI_WLAN_HEX_KEY);
			sprintf(array_fvp[3].value, "%s", "");
			sprintf(array_fvp[4].value, "%s", "");
		}

		for (i = 0; i < WLAN_PSK_PARAM_COUNT; i++)
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase",
				       "fvp_field: %s, fvp_value:%s",
				       array_fvp[i].fieldname,
				       array_fvp[i].value);

		passed_index = -1;
	}

	count = WLAN_PSK_PARAM_COUNT;

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");

	/*
	   configuration index = 0 for all instances - for Add, Delete, Modify
	   operations; instead pcpeId is appended in prefix name; example:
	   wlpsk<pcpeId>_0_param */
	passed_index = 0;
	if (ifx_get_conf_index_and_nv_pairs
	    (&wlPsk->iid, passed_index, psk_prefix, count, array_fvp,
	     flags) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	for (i = 0; i < WLAN_PSK_PARAM_COUNT; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase",
			       "fvp_field: %s, fvp_value:%s",
			       array_fvp[i].fieldname, array_fvp[i].value);

   /************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	if (IFX_ADD_F_NOT_SET(flags) && IFX_INT_DONT_CHECK_ACL_F_NOT_SET(flags)) {
		CHECK_ACL_RET(wlPsk->iid, count, array_fvp,
			      changed_count, array_changed_fvp, flags,
			      IFX_Handler)
	}

	/*
	   before updating the config file: stop the AP/VAP in case of delete
	   operation only */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags) && IFX_DELETE_F_SET(flags)) {
		if (!(features & LTQ_MAPI_WLAN_FEATURE_OPT_SCRIPTS)) {
			/* use the parent cpeid to get index of the parent instance */
			P_CPEID.Id = wlPsk->iid.pcpeId.Id;
			sprintf(P_CPEID.secName, "%s", TAG_WLAN_MAIN);
			IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, P_CPEID, passed_index)
			sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, passed_index);
			/* passed index should be that of wlan_main instance */
			LTQ_LOG_TIMESTAMP();
			system(conf_buf);
			LTQ_LOG_TIMESTAMP();
		}
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
   /************** System Config File Update Block ****************/
	/* Convert the name value pair in array_fvp into string format expected by
	   rc.conf file */
	ret = form_cfgdb_buf(conf_buf, count, array_fvp);
	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
		goto IFX_Handler;
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "conf_buf: %s",
		       conf_buf);
	/* RC.CONF Configuration block */
	ret =
	    ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_PASSPHRASE, flags, 1,
			   conf_buf);

	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
		goto IFX_Handler;
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
   /*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* after config file update, for modify or add operation start all ap/vap */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags)) {
		if (operation == IFX_OP_ADD) {
			/* passed index should be that of wlan_main instance */
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
			sprintf(conf_buf, "%s %d", SERVICE_WLAN_START, passed_index);
			LTQ_LOG_TIMESTAMP();
			system(conf_buf);
			LTQ_LOG_TIMESTAMP();
		} else if (operation == IFX_OP_MOD) {
			if (g_wlMain[passed_index].apEnable) {
				/* passed index should be that of wlan_main instance */
				sprintf(conf_buf, "%s %d &", SERVICE_WLAN_SEC_MODIFY,
					passed_index);
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase",
					"conf_buf: %s", conf_buf);
				LTQ_LOG_TIMESTAMP();
				system(conf_buf);
				LTQ_LOG_TIMESTAMP();
			}
		}
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
	/* this will update the count for both ADD and DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags))
		ifx_UpdateCountInSection(FILE_RC_CONF, TAG_WLAN_PASSPHRASE,
					 flags);

   /*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
   /*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_MODIFY_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
		CHECK_N_SEND_NOTIFICATION(wlPsk->iid, changed_count,
					  array_changed_fvp, flags, IFX_Handler)
	} else if (IFX_INT_ADD_F_SET(flags)) {
      /*********** Epilog Block **************/
		/*
		   in case of ADD operation, first update the ID Mappings and then send
		   the Notification for the attributes */
		UPDATE_ID_MAP_N_ATTRIBUTES(&wlPsk->iid, count, array_fvp, flags,
					   IFX_Handler)

		    if (IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(flags)) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
			CHECK_N_SEND_NOTIFICATION(wlPsk->iid, count, array_fvp,
						  flags, IFX_Handler)
		}

		/* Manipulate nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WLAN_PASSPHRASE);

	} else if (IFX_DELETE_F_SET(flags)) {
		/* In case of DELETE operation, first send the notificatioupdate the ID
		   Mappings and then send the Notification for the attributes */
      /*********** Epilog Block **************/
		if (IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(flags)) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
			CHECK_N_SEND_NOTIFICATION(wlPsk->iid, count, array_fvp,
						  flags, IFX_Handler)
		}
		UPDATE_ID_MAP_N_ATTRIBUTES(&wlPsk->iid, count, array_fvp, flags,
					   IFX_Handler)
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
		goto IFX_Handler;
	}

#ifdef TR69_DEFINED
	/* notify devm regarding the set in mapi */
	if(IFX_INT_DONT_SEND_SET_NOTIFICATION_F_NOT_SET(flags) && (wlPsk->iid.config_owner == IFX_WEB)) {
//		ifx_tr69_value_change_notify(&wlPsk->iid);
	}
#endif

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "ret: %d", ret);
	IFX_MEM_FREE(array_changed_fvp);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/**
   This API is a wrapper function required for devm.
   Basically it simply calls mapiWlanSetPersonalConfig.

   \param   operation   - type of operation (ADD, MODIFY, DELETE)

   \param   wlPsk       - pointer to IFX_MAPI_WLAN_PSKey structure

   \param   flags       - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ifx_mapi_set_wlan_passphrase_config(uint32 operation,
				    IFX_MAPI_WLAN_PSKey * wlPsk, uint32 flags)
{
	CPE_ID P_CPEID;
	char8 conf_buf[MAX_DATA_LEN];
	int32 passed_index = -1;
	int32 ret = IFX_SUCCESS;
	LTQ_MAPI_WLAN_Feature	features = LTQ_MAPI_WLAN_FEATURE_NONE;

	LTQ_LOG_TIMESTAMP("Begin");

	memset(&P_CPEID, 0x00, sizeof(P_CPEID));

   /*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY) append the flag with
	   internal flags */
	if ((operation == IFX_OP_ADD) || (operation == IFX_OP_DEL)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphraseConfig", "");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	sprintf(wlPsk->iid.cpeId.secName, "%s", TAG_WLAN_PASSPHRASE);
	sprintf(wlPsk->iid.pcpeId.secName, "%s", TAG_WLAN_SEC);

   /**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(wlPsk)
		    /* Do simple validation of flags sucha as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
		    /* Validate key type for ascii value */
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphraseConfig", "");

	if ((ret =
	     mapiWlanSetPersonalConfig(operation, wlPsk,
				       flags | IFX_F_INT_DONT_CONFIGURE |
				       IFX_F_DONT_WRITE_TO_FLASH)) !=
	    IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphraseConfig",
			       "mapiWlanSetPersonalConfig has failed");
		goto IFX_Handler;
	}

	/* use the parent cpeid to get index of the parent instance */
	P_CPEID.Id = wlPsk->iid.pcpeId.Id;
	sprintf(P_CPEID.secName, "%s", TAG_WLAN_MAIN);
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, P_CPEID, passed_index)
	    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphraseConfig",
			   "passed_index: %d", passed_index);

	/* Device config thru Scripts/Utilities or Functions */
	/* after config file update, for modify or add operation start all ap/vap */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags)) {
		if (g_wlMain[passed_index].apEnable) {
			sprintf(conf_buf, "%s %d", SERVICE_WLAN_SEC_MODIFY, passed_index);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphraseConfig",
				"conf_buf: %s", conf_buf);
			LTQ_LOG_TIMESTAMP();
			system(conf_buf);
			LTQ_LOG_TIMESTAMP();
		}
	}

	/* before config file update, for modify or delete operation stop all
	   ap/vap */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags)) {
		features = ltq_mapi_get_wlan_supported_features(
			g_wlMain[passed_index].radioCpeId, IFX_F_DEFAULT);
		if (!(features & LTQ_MAPI_WLAN_FEATURE_OPT_SCRIPTS)) {
			sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, passed_index);
			LTQ_LOG_TIMESTAMP();
			system(conf_buf);
			LTQ_LOG_TIMESTAMP();
		}
	}

   /*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* after config file update, for modify or add operation start all ap/vap */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags)) {
		if (!(features & LTQ_MAPI_WLAN_FEATURE_OPT_SCRIPTS)) {
			sprintf(conf_buf, "%s %d", SERVICE_WLAN_START, passed_index);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphraseConfig",
				"conf_buf: %s", conf_buf);
			LTQ_LOG_TIMESTAMP();
			system(conf_buf);
			LTQ_LOG_TIMESTAMP();
		}
	}

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepConfig", "ret: %d",
			       ret);
		goto IFX_Handler;
	}

	/* reset flags to reload the configuration */
	g_flagConfigLoaded = 0;
	g_flagSecConfig = 0;
	system("echo 0 > /tmp/web_Secflg &");

#ifdef TR69_DEFINED
	/* notify devm regarding the set in mapi */
	if(IFX_INT_DONT_SEND_SET_NOTIFICATION_F_NOT_SET(flags) && (wlPsk->iid.config_owner == IFX_WEB)) {
//		ifx_tr69_value_change_notify(&wlPsk->iid);
	}
#endif

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphraseConfig", "ret: %d", ret);
	LTQ_LOG_TIMESTAMP("Done");
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/**
   This API configures the WLAN 802.1X parameters for a given AP/VAP.

   \param   operation   - type of operation (ADD, MODIFY, DELETE)

   \param   wlRadius       - pointer to IFX_MAPI_WLAN_802_1x structure

   \param   flags       - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE

   \remarks the wlan_1x objects has not corresponding TR69 object, therefore
            no interaction with TR69 is required in this function
*/
int32
ifx_mapi_set_wlan_802_1x_config(uint32 operation,
				IFX_MAPI_WLAN_802_1x * wlRadius, uint32 flags)
{
	CPE_ID pCpeId;
	char8 conf_buf[MAX_DATA_LEN], radiusPrefix[MAX_FILELINE_LEN];
	int32 count = 0, changed_count = 0, passed_index = -1;
	int32 ret = IFX_SUCCESS, i;
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_802_1X_PARAM_COUNT],
	    *array_changed_fvp = NULL;
	IFX_ID parent_iid;
	char8 radSecretInHex[4*IFX_MAPI_PSK_MAX_LEN]; /* IFX_MAPI_PSK_MAX_LEN already includes closing \0 */
	IFX_MAPI_WLAN_MainCfg wlMain;
	LTQ_MAPI_WLAN_Vendor	vendor = LTQ_MAPI_WLAN_VENDOR_NONE;
	LTQ_MAPI_WLAN_Feature	features = LTQ_MAPI_WLAN_FEATURE_NONE;

	LTQ_LOG_TIMESTAMP("Begin");

	memset(&pCpeId, 0x00, sizeof(CPE_ID));
	memset(array_fvp, 0x00, sizeof(array_fvp));
	memset(&parent_iid, 0, sizeof(parent_iid));

	/*
	 *************** Prolog Block *******************
	 Based on operation (ADD or DELETE or MODIFY)
	 append the flag with internal flags
	 */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

	/*
	 *************** Validation Block *****************
	 For Operations other than DELETE do the verification of input params
	 */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(wlRadius)
		    /* Do simple validation of flags sucha as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
		    /* Validate key type for ascii value */
	}

	sprintf(wlRadius->iid.cpeId.secName, "%s", TAG_WLAN_1X);
	sprintf(wlRadius->iid.pcpeId.secName, "%s", TAG_WLAN_SEC);

	parent_iid.cpeId.Id = wlRadius->iid.pcpeId.Id;
	sprintf(parent_iid.cpeId.secName, "%s", wlRadius->iid.pcpeId.secName);

	/*
	 *************** ID Allocation Block - Only for ADD Operation *************
	 */
	if (IFX_ADD_F_SET(flags)) {
		/*
		   This function call gets the cpeId of parent_iid and copies it to
		   pcpdId of wlRadius->iid. */
		if (ifx_get_iid(TAG_WLAN_1X, TAG_WLAN_SEC, &parent_iid,
				&wlRadius->iid) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig",
				       "");
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	/*
	 *************** Name Value Formation as per RC.CONF ********************
	 Form the FVP from the given structure for ADD/MODIFY
	 Operations
	 */
	sprintf(radiusPrefix, "%s", PREFIX_WLAN_SEC_1X);

	memset(&wlMain, 0, sizeof(IFX_MAPI_WLAN_MainCfg));
	sprintf(wlMain.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
	sprintf(wlMain.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
	wlMain.iid.cpeId.Id = wlRadius->iid.pcpeId.Id;
	if ((ret = ifx_mapi_get_wlan_main_config(&wlMain, IFX_F_DEFAULT)) !=
			IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
		goto IFX_Handler;
	}
	/* get vendor information and supported features */
	vendor = ltq_mapi_get_wlan_vendor(wlMain.radioCpeId, IFX_F_DEFAULT);
	features = ltq_mapi_get_wlan_supported_features(wlMain.radioCpeId,
		IFX_F_DEFAULT);

	count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, count,
					WLAN_802_1X_PARAM_COUNT,
					wlan_802_1x_params);
		/*
		   this function call is used to fill the array array_fvp with
		   parameters of type integer; \note - this function can only be used
		   for successive parameters of type integer; if one of the parameters
		   is for example of type string, then this function can only be used
		   to fill in the parameters up to the paramter of type string; */
		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 2,
					    (int32 *) & wlRadius->iid.cpeId.Id,
					    &wlRadius->iid.pcpeId.Id);

		sprintf(array_fvp[2].value, "%d", wlRadius->groupKeyEna);
		sprintf(array_fvp[3].value, "%d", wlRadius->groupKeyIntvl);
		sprintf(array_fvp[4].value, "%d", wlRadius->wpa2PreAuthEna);
		sprintf(array_fvp[5].value, "%d", wlRadius->wpa2ReAuthIntvl);

		sprintf(array_fvp[7].value, "%d", wlRadius->authType);
		sprintf(array_fvp[8].value, "%d", wlRadius->authProto);

		sprintf(array_fvp[9].value, "%s",
			inet_ntoa(wlRadius->radiusServerIP));
		sprintf(array_fvp[10].value, "%d", wlRadius->radiusPort);

		if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			memset(radSecretInHex, 0, sizeof(radSecretInHex));
			/* convert ascii representation of ssid to hex representation */
			mapi_wlan_convert_ascii_to_hex(wlRadius->radiusServerSecret, radSecretInHex);
			sprintf(array_fvp[11].value, "%s", radSecretInHex);
		} else {
			sprintf(array_fvp[11].value, "%s", wlRadius->radiusServerSecret);
		}

		sprintf(array_fvp[12].value, "%s", wlRadius->domainName);
		sprintf(array_fvp[13].value, "%s", wlRadius->userName);

		for (i = 0; i < WLAN_802_1X_PARAM_COUNT; i++)
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig",
				       "name: %s, value: %s",
				       array_fvp[i].fieldname,
				       array_fvp[i].value);
		passed_index = -1;
	}

	count = WLAN_802_1X_PARAM_COUNT;

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
	/* Get Config Index in case of modify/delete operations from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_PCPEID(FILE_RC_CONF, wlRadius->iid.pcpeId,
					  passed_index)
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
	/*
	   Determine the configuration index - for Add, Delete, Modify operations
	   Name is partial since index is not known Fill array_fvp[] */
	if (ifx_get_conf_index_and_nv_pairs
	    (&wlRadius->iid, passed_index, radiusPrefix, count, array_fvp,
	     flags) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
	/*
	 ********** ACL Checking block - MUST for MODIFY/DELETE operations *********
	 */

	if (IFX_ADD_F_NOT_SET(flags) && IFX_INT_DONT_CHECK_ACL_F_NOT_SET(flags)) {
		CHECK_ACL_RET(wlRadius->iid, count, array_fvp, changed_count,
			      array_changed_fvp, flags, IFX_Handler)
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");

	/* before config file update, for modify or delete operation stop all
	   ap/vap */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags) &&
	    (IFX_DELETE_F_SET(flags) || IFX_MODIFY_F_SET(flags))) {
		if (!(features & LTQ_MAPI_WLAN_FEATURE_OPT_SCRIPTS)) {
			/* use the parent cpeid to get index of the parent instance */
			pCpeId.Id = wlRadius->iid.pcpeId.Id;
			sprintf(pCpeId.secName, "%s", TAG_WLAN_SEC);
			IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, pCpeId, passed_index)
			sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, passed_index);
			/* passed index	should be that of wlan_main instance??? */
			LTQ_LOG_TIMESTAMP();
			system(conf_buf);
			LTQ_LOG_TIMESTAMP();
		}
	}

	/*
	 ************* System Config File Update Block ****************
	 Convert the name value pair in array_fvp into string format expected by
	 rc.conf file
	 */
	ret = form_cfgdb_buf(conf_buf, count, array_fvp);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
		goto IFX_Handler;
	}

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_1X, flags, 1, conf_buf);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
		goto IFX_Handler;
	}

	/*
	 ********** Device Configuration Block ****************
	 Device config thru Scripts/Utilities or Functions
	 after config file update, for modify or add operation start all ap/vap
	 */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags) &&
	    (IFX_INT_ADD_F_SET(flags) || IFX_MODIFY_F_SET(flags))) {
		if (operation == IFX_OP_ADD) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
			/* passed index should be that of wlan_main instance */
			sprintf(conf_buf, "%s %d", SERVICE_WLAN_START, passed_index);
			LTQ_LOG_TIMESTAMP();
			system(conf_buf);
			LTQ_LOG_TIMESTAMP();
		} else if (operation == IFX_OP_MOD) {
			if (g_wlMain[passed_index].apEnable) {
				/* passed index should be that of wlan_main instance */
				sprintf(conf_buf, "%s %d &", SERVICE_WLAN_SEC_MODIFY,
					passed_index);
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig",
					"conf_buf: %s", conf_buf);
				LTQ_LOG_TIMESTAMP();
				system(conf_buf);
				LTQ_LOG_TIMESTAMP();
			}
		}
	}

	/* this will Compact the section and also update the count for both ADD and
	   DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_WLAN_1X, flags);

	/*
	 ********* Notification Block *************
	 Notify the Internal TR69 Stack in case of MODIFY
	 \todo check here
	 */

	/*
	 ********** Epilog Block **************
	 Update the IID mappings in the mappings section for ADD/DELETE
	 */
	if (IFX_MODIFY_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
	} else if (IFX_INT_ADD_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
		/*
		   In case of ADD operation, first update the ID Mappings and then send
		   the Notification for the attributes */
		/* Manipulate nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WLAN_1X);
	} else if (IFX_DELETE_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
	}

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif				/* #ifdef IFX_LOG_DEBUG */
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
		goto IFX_Handler;
	}

	/* reset flags to reload the configuration */
	g_flagConfigLoaded = 0;
	g_flagSecConfig = 0;
	system("echo 0 > /tmp/web_Secflg &");

#ifdef TR69_DEFINED
	/* notify devm regarding the set in mapi */
	if(IFX_INT_DONT_SEND_SET_NOTIFICATION_F_NOT_SET(flags) && (wlRadius->iid.config_owner == IFX_WEB)) {
//		ifx_tr69_value_change_notify(&wlRadius->iid);
	}
#endif

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "ret: %d", ret);
	IFX_MEM_FREE(array_changed_fvp);
	LTQ_LOG_TIMESTAMP("Done");
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/**
   This API configures the WLAN security parameters for given AP/VAP
   specified by CpeId

   \param   oper  - type of operation (ADD, MODIFY, DELETE)

   \param   wlSec - pointer to IFX_MAPI_WLAN_SecCfg structure

   \param   flags - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE

   \remarks - irrespective of protocol to be used, each instance should be added/deleted/modified in wep and passphrase
            - should have same cpeid and pcpeid as the wlan_main instance
            - wireless start script checks if both phy-radio and this ap/vap is enabled, then only starts the service
*/
int32
ifx_mapi_set_wlan_security_config(uint32 oper, IFX_MAPI_WLAN_SecCfg * wlSec,
				  uint32 flags)
{
	char8 conf_buf[MAX_DATA_LEN];
	int32 count = 0, changed_count = 0, passed_index = -1;
	int32 ret = IFX_SUCCESS, i = 0;
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_SEC_PARAM_COUNT];
	IFX_NAME_VALUE_PAIR *array_changed_fvp = NULL;
	IFX_MAPI_WLAN_MainCfg wlMain;
	IFX_MAPI_WLAN_PhyCfg 	wlPhy;
	int32					phyIdx = -1;
	LTQ_MAPI_WLAN_Vendor	vendor = LTQ_MAPI_WLAN_VENDOR_NONE;
	LTQ_MAPI_WLAN_Feature	features = LTQ_MAPI_WLAN_FEATURE_NONE;

	LTQ_LOG_TIMESTAMP("Begin");

	/* initialize array */
	memset(array_fvp, 0x00, sizeof(array_fvp));
	memset(conf_buf, 0x00, sizeof(conf_buf));

	/*
	 *************** Prolog Block *******************
	 Based on operation (ADD or DELETE or MODIFY)
	 append the flag with internal flags
	 */
	if (oper == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (oper == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

	sprintf(wlSec->iid.cpeId.secName, "%s", TAG_WLAN_SEC);	/* Pramod -TAG_WLAN_SEC or TAG_WLAN_MAIN */
	sprintf(wlSec->iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);	/* Pramod - who is the parent here */

	/*
	   Get the configuration index in case of modify/delete operations from
	   CPEID \note - CPEID must be filled by calling function */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlSec->iid.cpeId, passed_index)
	}

#if defined (LTQ_AEI_CUST)
if (IFX_MODIFY_F_SET(flags)) {
	IFX_MAPI_WLAN_Standard 	opMode = IFX_MAPI_WLAN_STD_802_11_ALL;

	memset(&wlPhy, 0, sizeof(IFX_MAPI_WLAN_PhyCfg));
	sprintf(wlPhy.iid.cpeId.secName, "%s", TAG_WLAN_PHY);
	sprintf(wlPhy.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
	phyIdx = g_wlMain[passed_index].radioCpeId - 1;
	wlPhy.iid.cpeId.Id = phyIdx + 1;

	if (wlSec->wlEncr == IFX_MAPI_WLAN_ENCR_WEP) {
		opMode = g_wlPhy[phyIdx].standard;
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "opMode: %d",
			opMode);
		/*
		 * if security is WEP and oper mode is any 802.11xn, then the OP
		 * mode must be set back to non-N mode
		 */
		if (opMode >= IFX_MAPI_WLAN_STD_802_11N) {
			/* get the PHY configuration */
			if ((ret = ifx_mapi_get_wlan_phy_config(&wlPhy, IFX_F_GET_ANY)) !=
				IFX_SUCCESS) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
				goto IFX_Handler;
			}
			/* save opMode in global variable */
			gOpMode = opMode;
			switch (gOpMode) {
				case IFX_MAPI_WLAN_STD_802_11N:
					if (wlPhy.freqBand == IFX_MAPI_WLAN_2_4_GHz_Freq) {
						wlPhy.standard = IFX_MAPI_WLAN_STD_802_11BG;
					}
					else {
						wlPhy.standard = IFX_MAPI_WLAN_STD_802_11A;
					}
					break;
				case IFX_MAPI_WLAN_STD_802_11BGN:
					wlPhy.standard = IFX_MAPI_WLAN_STD_802_11BG;
					break;
				case IFX_MAPI_WLAN_STD_802_11GN:
					wlPhy.standard = IFX_MAPI_WLAN_STD_802_11G;
					break;
				case IFX_MAPI_WLAN_STD_802_11AN:
					wlPhy.standard = IFX_MAPI_WLAN_STD_802_11A;
					break;
				default:
					break;
			}
			if ((ret = ifx_mapi_set_wlan_phy_config(IFX_OP_MOD, &wlPhy,
				flags | IFX_F_DONT_WRITE_TO_FLASH)) !=
				IFX_SUCCESS) {
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
						"ifx_set_wlan_phy_config has failed");
				goto IFX_Handler;
			}
		}
	}
}
#endif /* #if defined (LTQ_AEI_CUST) */

	if (IFX_DELETE_F_NOT_SET(flags)) {
		memset(&wlMain, 0, sizeof(IFX_MAPI_WLAN_MainCfg));
		sprintf(wlMain.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
		sprintf(wlMain.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
		wlMain.iid.pcpeId.Id = wlSec->iid.pcpeId.Id;
		wlMain.iid.cpeId.Id = wlSec->iid.cpeId.Id;
		if ((ret = ifx_mapi_get_wlan_main_config(&wlMain, IFX_F_DEFAULT)) !=
			 IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
			goto IFX_Handler;
		}
	}

	if (IFX_MODIFY_F_SET(flags)) {
		/* return immediately if no parameter changed */
		if (mapiWlanChkSecCfgChg(passed_index, wlSec) == FALSE) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
				"passed_index: %d", passed_index);
			LTQ_LOG_TIMESTAMP("Done");
			return IFX_SUCCESS;
		}

		features = ltq_mapi_get_wlan_supported_features(wlMain.radioCpeId,
			IFX_F_DEFAULT);
		if (features & LTQ_MAPI_WLAN_FEATURE_NETMODE_PER_VAP) {
			if (LTQ_F_INT_DONT_RECONFIG_MAIN_F_NOT_SET(flags)) {
				/* if WEP security and HT rates, then fallback to legacy net mode */
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
					"networkMode: %d, encryption: %d, encryptionOld: %d",
					wlMain.networkMode, wlSec->wlEncr, g_wlSec[passed_index].wlEncr);
				if ((wlMain.networkMode >= IFX_MAPI_WLAN_STD_802_11N) &&
					((wlSec->wlEncr == IFX_MAPI_WLAN_ENCR_WEP) ||
					(wlSec->wlEncr == IFX_MAPI_WLAN_ENCR_TKIP))) {
					switch (wlMain.networkMode) {
					case IFX_MAPI_WLAN_STD_802_11N:
						memset(&wlPhy, 0, sizeof(IFX_MAPI_WLAN_PhyCfg));
						sprintf(wlPhy.iid.cpeId.secName, "%s", TAG_WLAN_PHY);
						sprintf(wlPhy.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
						phyIdx = wlMain.radioCpeId - 1;
						wlPhy.iid.cpeId.Id = phyIdx + 1;

						/* get the PHY configuration */
						if ((ret = ifx_mapi_get_wlan_phy_config(&wlPhy, IFX_F_GET_ANY)) !=
							IFX_SUCCESS) {
							IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
							goto IFX_Handler;
						}

						if (wlPhy.freqBand == IFX_MAPI_WLAN_5_GHz_Freq)
							wlMain.networkMode = IFX_MAPI_WLAN_STD_802_11A;
						else
							wlMain.networkMode = IFX_MAPI_WLAN_STD_802_11B;
						break;
					case IFX_MAPI_WLAN_STD_802_11BGN:
						wlMain.networkMode = IFX_MAPI_WLAN_STD_802_11BG;
						break;
					case IFX_MAPI_WLAN_STD_802_11GN:
						wlMain.networkMode = IFX_MAPI_WLAN_STD_802_11G;
						break;
					case IFX_MAPI_WLAN_STD_802_11AN:
						wlMain.networkMode = IFX_MAPI_WLAN_STD_802_11A;
						break;
					default:
						IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
						goto IFX_Handler;
					}
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
						"networkMode: %d", wlMain.networkMode);
					if ((ret = ifx_mapi_set_wlan_main_config(IFX_OP_MOD, &wlMain,
						IFX_F_DONT_WRITE_TO_FLASH | LTQ_F_INT_DONT_RECONFIG_SECURITY |
						IFX_F_INT_DONT_SEND_SET_NOTIFICATION)) != IFX_SUCCESS) {
						IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
							"ifxMapiSetWlanSecurityConfig has failed");
						goto IFX_Handler;
					}
				} else if (wlMain.networkMode < IFX_MAPI_WLAN_STD_802_11N) {
					if (((wlSec->wlEncr != IFX_MAPI_WLAN_ENCR_WEP) &&
						(wlSec->wlEncr != IFX_MAPI_WLAN_ENCR_TKIP)) &&
						(((g_wlSec[passed_index].wlEncr == IFX_MAPI_WLAN_ENCR_WEP) ||
						 (g_wlSec[passed_index].wlEncr == IFX_MAPI_WLAN_ENCR_TKIP)))) {
						/*
							changing from WEP ton non-WEP security or from TKIP to non-TKIP
							but only if global network Mode is in HT mode
						*/
						memset(&wlPhy, 0, sizeof(IFX_MAPI_WLAN_PhyCfg));
						sprintf(wlPhy.iid.cpeId.secName, "%s", TAG_WLAN_PHY);
						sprintf(wlPhy.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
						phyIdx = wlMain.radioCpeId - 1;
						wlPhy.iid.cpeId.Id = phyIdx + 1;

						/* get the PHY configuration */
						if ((ret = ifx_mapi_get_wlan_phy_config(&wlPhy, IFX_F_GET_ANY)) !=
							IFX_SUCCESS) {
							IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
							goto IFX_Handler;
						}

						IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
							"netMode: %d", wlPhy.standard);
						if (wlPhy.standard >= IFX_MAPI_WLAN_STD_802_11N) {
							switch (wlMain.networkMode) {
							case IFX_MAPI_WLAN_STD_802_11A:
								wlMain.networkMode = IFX_MAPI_WLAN_STD_802_11AN;
								break;
							case IFX_MAPI_WLAN_STD_802_11B:
								wlMain.networkMode = IFX_MAPI_WLAN_STD_802_11N;
								break;
							case IFX_MAPI_WLAN_STD_802_11G:
								wlMain.networkMode = IFX_MAPI_WLAN_STD_802_11GN;
								break;
							case IFX_MAPI_WLAN_STD_802_11BG:
								wlMain.networkMode = IFX_MAPI_WLAN_STD_802_11BGN;
								break;
							default:
								IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
								break;
							}
							IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
								"networkMode: %d", wlMain.networkMode);
							if ((ret = ifx_mapi_set_wlan_main_config(IFX_OP_MOD, &wlMain,
								IFX_F_DONT_WRITE_TO_FLASH | LTQ_F_INT_DONT_RECONFIG_SECURITY |
								IFX_F_INT_DONT_SEND_SET_NOTIFICATION)) != IFX_SUCCESS) {
								IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
									"ifx_mapi_set_wlan_main_config has failed");
								goto IFX_Handler;
							}
						}
					}
				}
			}
		}

		/* 1. WAVE300_SW_1853: Disable WPS if security is WEP, WPA/TKIP or Enterprise (RADIUS) */
		/* 2. Disable WPS if MAC filter is enabled */
		if (wlMain.WPSena) {
			IFX_MAPI_WLAN_WPS_Cfg wlWps;
			int32 f_disableWps = 0;

			if ((wlSec->macAddrCntrlEna == IFX_MAPI_MACADDR_CONTROL_ALLOW) ||
				(wlSec->macAddrCntrlEna == IFX_MAPI_MACADDR_CONTROL_DENY)) {
				f_disableWps = 1;
			} else {
				switch (wlSec->beaconType) {
				case IFX_MAPI_WLAN_BEACON_BASIC:
					switch (wlSec->wlEncr) {
						case IFX_MAPI_WLAN_ENCR_WEP:
							/* WPS must be disabled if WEP security is selected */
							f_disableWps = 1;
							break;
						default:
							break;
					}
					break;
				case IFX_MAPI_WLAN_BEACON_WPA:
					switch (wlSec->wlAuth) {
					case IFX_MAPI_WLAN_AUTH_RADIUS:
						/* WPS must be disabled if Enterprise security is selected */
						f_disableWps = 1;
						break;
					default:
						break;
					}
					switch (wlSec->wlEncr) {
						case IFX_MAPI_WLAN_ENCR_TKIP:
							/* WPS must be disabled if WPA/TKIP security is selected */
							f_disableWps = 1;
							break;
						default:
							break;
					}
					break;
				case IFX_MAPI_WLAN_BEACON_WPA2:
				case IFX_MAPI_WLAN_BEACON_WPA_WPA2_NON_COMPLIANT:
				case IFX_MAPI_WLAN_BEACON_WPA_WPA2:
					switch (wlSec->wlAuth) {
					case IFX_MAPI_WLAN_AUTH_RADIUS:
						/* WPS must be disabled if Enterprise security is selected */
						f_disableWps = 1;
						break;
					default:
						break;
					}
					break;
				default:
					break;
				}
			}

			if (f_disableWps) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
				memset(&wlWps, 0, sizeof(IFX_MAPI_WLAN_WPS_Cfg));
				sprintf(wlWps.iid.cpeId.secName, "%s", TAG_WLAN_WPS);
				sprintf(wlWps.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);

				wlWps.iid.cpeId.Id = wlSec->iid.cpeId.Id;
				wlWps.iid.pcpeId.Id = wlSec->iid.cpeId.Id;
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
					"cpeId: %d, pcpeId: %d", wlWps.iid.cpeId.Id, wlWps.iid.pcpeId.Id);

				/* get the wlan wps configuration from MAPI */
				if ((ret = ifx_mapi_get_wlan_wps_config(&wlWps, IFX_F_DEFAULT)) !=
					IFX_SUCCESS) {
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
					goto IFX_Handler;
				}
				/* disable WPS and subfeatures and set the new config */
				wlWps.enable = 0;
				wlWps.enrolleeEna = 0;
				wlWps.proxyEna = 0;
				wlWps.intRegEna = 0;
				if ((ret = ifx_mapi_set_wlan_wps_config(IFX_OP_MOD, &wlWps,
					IFX_F_MODIFY | IFX_F_DONT_WRITE_TO_FLASH)) != IFX_SUCCESS) {
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
					goto IFX_Handler;
				}
				g_wlMain[passed_index].WPSena = 0;
			}
		}
	}

	if (IFX_DELETE_F_SET(flags)) {
      /**
         on a delete operation for the wlan security object, first all child
         objects have to be deleted
      */
		if ((ret = mapiWlanPersonalConfig(oper, wlSec)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
				       "mapiWlanPersonalConfig has failed");
			goto IFX_Handler;
		}
		if ((ret = mapiWlan8021XConfig(oper, wlSec)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
				       "mapiWlan8021XConfig has failed");
			goto IFX_Handler;
		}
		if ((ret = mapiWlanWepConfig(oper, wlSec, flags)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
				"mapiWlanWepConfig has failed.\nFlags: 0x%x", flags);
			goto IFX_Handler;
		}
	}

	/*
	 *************** Validation Block ***************
	 For Operations other than DELETE do the verification of input params
	 */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(wlSec)
		    /* Do simple validation of flags sucha as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

	/*
	   Name Value Formation as per RC.CONF \note - form the FVP from the given
	   structure for ADD/MODIFY operations */
	count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		IFX_MAPI_WLAN_WEP_Cfg wlWepCfg;
		int32 j;

		memset(&wlWepCfg, 0x00, sizeof(IFX_MAPI_WLAN_WEP_Cfg));
		for (j = 0; j < IFX_MAPI_NUM_WEP_KEYS; j++)
			wlWepCfg.wepKey[j].iid.pcpeId.Id = wlSec->iid.cpeId.Id;

		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
		if (IFX_INT_ADD_F_NOT_SET(flags)) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
			/* some wep parameters are stored in wlan security objecct in
			   rc.conf */
			if ((ret =
			     ifx_mapi_get_wlan_wep_config(&wlWepCfg,
							  IFX_F_DEFAULT)) !=
			    IFX_SUCCESS) {
				IFX_MAPI_DEBUG(fd,
					       "/tmp/ifxMapiSetWlanSecurityConfig",
					       "");
				goto IFX_Handler;
			}
		}

		/* based on beacon type get authentication and encryption mode from
		   respective fields */
		if (wlSec->beaconType == IFX_MAPI_WLAN_BEACON_BASIC) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
#ifdef LTQ_AEI_CUST
			wlSec->wlEncr 		= IFX_MAPI_WLAN_ENCR_WEP;
			if (wlSec->wlAuth != IFX_MAPI_WLAN_AUTH_SHARED)
				wlSec->wlAuth = IFX_MAPI_WLAN_AUTH_OPEN;

			/* set auth type */
			wlSec->basicAuth = wlSec->wlAuth;
			/* set encrypt type */
			wlSec->basicEncr = IFX_MAPI_WLAN_ENCR_WEP;
			if (IFX_INT_ADD_F_NOT_SET(flags)) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
				wlWepCfg.wepEncrLevel = wlSec->secParams.wepCfg.wepEncrLevel;
				wlWepCfg.wepKeyType   = wlSec->secParams.wepCfg.wepKeyType;
				wlWepCfg.wepKeyIndex  = wlSec->secParams.wepCfg.wepKeyIndex;
			}
#else
			/* set auth type */
			wlSec->basicAuth = wlSec->wlAuth;
			/* set encrypt type */
			wlSec->basicEncr = wlSec->wlEncr;

			if (IFX_INT_ADD_F_NOT_SET(flags)) {
				/* if encryption is WEP take values stored in wlSec */
				if (wlSec->wlEncr == IFX_MAPI_WLAN_ENCR_WEP) {
					IFX_MAPI_DEBUG(fd,
						       "/tmp/ifxMapiSetWlanSecurityConfig",
						       "");
					wlWepCfg.wepEncrLevel =
					    wlSec->secParams.wepCfg.
					    wepEncrLevel;
					wlWepCfg.wepKeyType =
					    wlSec->secParams.wepCfg.wepKeyType;
					wlWepCfg.wepKeyIndex =
					    wlSec->secParams.wepCfg.wepKeyIndex;
				}
			}
#endif /* #ifdef LTQ_AEI_CUST */
			else {
				wlWepCfg.wepEncrLevel =
				    IFX_MAPI_WEP_ENCR_LVL_128BIT;
				wlWepCfg.wepKeyType = IFX_MAPI_WLAN_HEX_KEY;
				wlWepCfg.wepKeyIndex = IFX_MAPI_WEP_KEY_INDX_1;
			}
		} else if (wlSec->beaconType == IFX_MAPI_WLAN_BEACON_WPA) {
			if (wlSec->iid.config_owner == IFX_WEB) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
				/* set auth type */
				wlSec->wpaAuth = wlSec->wlAuth;
				/* set encrypt type */
				wlSec->wpaEncr = wlSec->wlEncr;
			} else {
				/*
				   check if authentication and encryption type are valid in
				   wlSec if not: take values for wpaAuthType/wpaEncrType from
				   rc.conf */
				if (((wlSec->wlAuth ==
				      IFX_MAPI_WLAN_AUTH_RADIUS)
				     || (wlSec->wlAuth ==
					 IFX_MAPI_WLAN_AUTH_PERSONAL))
				    &&
				    ((wlSec->wlEncr == IFX_MAPI_WLAN_ENCR_TKIP)
				     || (wlSec->wlEncr ==
					 IFX_MAPI_WLAN_ENCR_CCMP)
				     || (wlSec->wlEncr ==
					 IFX_MAPI_WLAN_ENCR_TKIP_CCMP))) {
					IFX_MAPI_DEBUG(fd,
						       "/tmp/ifxMapiSetWlanSecurityConfig",
						       "");
					/* set auth type */
					wlSec->wpaAuth = wlSec->wlAuth;
					/* set encrypt type */
					wlSec->wpaEncr = wlSec->wlEncr;
				} else {
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig","");
					if ((ret = mapiWlanGetObjectFromRcConf(
						wlSec->iid, array_fvp)) != IFX_SUCCESS) {
						IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
							"");
						goto IFX_Handler;
					}

					/* get value for authentication and encryption from rc.conf
					 */
					wlSec->wpaAuth =
					    atoi(array_fvp[7].value);
					wlSec->wpaEncr =
					    atoi(array_fvp[8].value);
					/* store values for authentication and encryption also in
					   general param */
					wlSec->wlAuth = wlSec->wpaAuth;
					wlSec->wlEncr = wlSec->wpaEncr;
					/* get the remaining values from rc.conf, so they do not
					   get lost */
					wlSec->basicAuth =
					    atoi(array_fvp[5].value);
					wlSec->basicEncr =
					    atoi(array_fvp[6].value);
					wlSec->wpa2Auth =
					    atoi(array_fvp[9].value);
					wlSec->wpa2Encr =
					    atoi(array_fvp[10].value);
					wlSec->macAddrCntrlEna =
					    atoi(array_fvp[14].value);
				}
			}
		} else if (wlSec->beaconType == IFX_MAPI_WLAN_BEACON_WPA2) {
			if (wlSec->iid.config_owner == IFX_WEB) {
				IFX_MAPI_DEBUG(fd,
					       "/tmp/ifxMapiSetWlanSecurityConfig",
					       "");
				/* set auth type */
				wlSec->wpa2Auth = wlSec->wlAuth;
				/* set encrypt type */
				wlSec->wpa2Encr = wlSec->wlEncr;
			} else {
				/*
				   check if authentication and encryption type are valid in
				   wlSec if not: take values for wpaAuthType/wpaEncrType from
				   rc.conf */
				if (((wlSec->wlAuth ==
				      IFX_MAPI_WLAN_AUTH_RADIUS)
				     || (wlSec->wlAuth ==
					 IFX_MAPI_WLAN_AUTH_PERSONAL))
				    &&
				    ((wlSec->wlEncr == IFX_MAPI_WLAN_ENCR_TKIP)
				     || (wlSec->wlEncr ==
					 IFX_MAPI_WLAN_ENCR_CCMP)
				     || (wlSec->wlEncr ==
					 IFX_MAPI_WLAN_ENCR_TKIP_CCMP))) {
					IFX_MAPI_DEBUG(fd,
						       "/tmp/ifxMapiSetWlanSecurityConfig",
						       "");
					/* set auth type */
					wlSec->wpa2Auth = wlSec->wlAuth;
					/* set encrypt type */
					wlSec->wpa2Encr = wlSec->wlEncr;
				} else {
					IFX_MAPI_DEBUG(fd,
						       "/tmp/ifxMapiSetWlanSecurityConfig",
						       "");
					if ((ret =
					     mapiWlanGetObjectFromRcConf(wlSec->
									 iid,
									 array_fvp))
					    != IFX_SUCCESS) {
						IFX_MAPI_DEBUG(fd,
							       "/tmp/ifxMapiSetWlanSecurityConfig",
							       "");
						goto IFX_Handler;
					}
					/* get value for authentication and encryption from rc.conf
					 */
					wlSec->wpa2Auth =
					    atoi(array_fvp[9].value);
					wlSec->wpa2Encr =
					    atoi(array_fvp[10].value);
					/* store values for authentication and encryption also in
					   general param */
					wlSec->wlAuth = wlSec->wpa2Auth;
					wlSec->wlEncr = wlSec->wpa2Encr;
					/* get the remaining values from rc.conf, so they do not
					   get lost */
					wlSec->basicAuth =
					    atoi(array_fvp[5].value);
					wlSec->basicEncr =
					    atoi(array_fvp[6].value);
					wlSec->wpaAuth =
					    atoi(array_fvp[7].value);
					wlSec->wpaEncr =
					    atoi(array_fvp[8].value);
					wlSec->macAddrCntrlEna =
					    atoi(array_fvp[14].value);
				}
			}
		} else if ((wlSec->beaconType == IFX_MAPI_WLAN_BEACON_WPA_WPA2) ||
			(wlSec->beaconType == IFX_MAPI_WLAN_BEACON_WPA_WPA2_NON_COMPLIANT)) {
			if (wlSec->iid.config_owner == IFX_WEB) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
				/* set auth type */
				wlSec->wpaAuth = wlSec->wlAuth;
				/* set encrypt type */
				wlSec->wpaEncr = wlSec->wlEncr;
				/* set auth type */
				wlSec->wpa2Auth = wlSec->wlAuth;
				/* set encrypt type */
				wlSec->wpa2Encr = wlSec->wlEncr;
			} else {
				/*
				   check if authentication and encryption type are valid in
				   wlSec if not: take values for wpaAuthType/wpaEncrType from
				   rc.conf */
				if (((wlSec->wlAuth ==
				      IFX_MAPI_WLAN_AUTH_RADIUS)
				     || (wlSec->wlAuth ==
					 IFX_MAPI_WLAN_AUTH_PERSONAL))
				    &&
				    ((wlSec->wlEncr == IFX_MAPI_WLAN_ENCR_TKIP)
				     || (wlSec->wlEncr ==
					 IFX_MAPI_WLAN_ENCR_CCMP)
				     || (wlSec->wlEncr ==
					 IFX_MAPI_WLAN_ENCR_TKIP_CCMP))) {
					IFX_MAPI_DEBUG(fd,
						       "/tmp/ifxMapiSetWlanSecurityConfig",
						       "");
					/* set auth type */
					wlSec->wpaAuth = wlSec->wlAuth;
					/* set encrypt type */
					wlSec->wpaEncr = wlSec->wlEncr;
					/* set auth type */
					wlSec->wpa2Auth = wlSec->wlAuth;
					/* set encrypt type */
					wlSec->wpa2Encr = wlSec->wlEncr;
				} else {
					IFX_MAPI_DEBUG(fd,
						       "/tmp/ifxMapiSetWlanSecurityConfig",
						       "");
					if ((ret =
					     mapiWlanGetObjectFromRcConf(wlSec->
									 iid,
									 array_fvp))
					    != IFX_SUCCESS) {
						IFX_MAPI_DEBUG(fd,
							       "/tmp/ifxMapiSetWlanSecurityConfig",
							       "");
						goto IFX_Handler;
					}
					/* get value for authentication and encryption from rc.conf
					 */
					wlSec->wpaAuth =
					    atoi(array_fvp[7].value);
					wlSec->wpaEncr =
					    atoi(array_fvp[8].value);
					wlSec->wpa2Auth =
					    atoi(array_fvp[9].value);
					wlSec->wpa2Encr =
					    atoi(array_fvp[10].value);
					/* store values for authentication and encryption also in
					   general param */
					wlSec->wlAuth = wlSec->wpaAuth;
					wlSec->wlEncr = wlSec->wpaEncr;
					/* get the remaining values from rc.conf, so they do not
					   get lost */
					wlSec->basicAuth =
					    atoi(array_fvp[5].value);
					wlSec->basicEncr =
					    atoi(array_fvp[6].value);
					wlSec->macAddrCntrlEna =
					    atoi(array_fvp[14].value);
				}
			}
		}
#ifdef LTQ_AEI_CUST
		else if (wlSec->beaconType == IFX_MAPI_WLAN_BEACON_NONE) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");

 			wlSec->beaconType = IFX_MAPI_WLAN_BEACON_BASIC;
			wlSec->wlAuth = IFX_MAPI_WLAN_AUTH_OPEN;
			wlSec->wlEncr = IFX_MAPI_WLAN_ENCR_NONE;

			/* set auth type */
			wlSec->basicAuth = IFX_MAPI_WLAN_AUTH_OPEN;
			/* set encrypt type */
			wlSec->basicEncr = IFX_MAPI_WLAN_ENCR_NONE;

			wlWepCfg.wepEncrLevel = IFX_MAPI_WEP_ENCR_LVL_128BIT;
			wlWepCfg.wepKeyType = IFX_MAPI_WLAN_HEX_KEY;
			wlWepCfg.wepKeyIndex = IFX_MAPI_WEP_KEY_INDX_1;
		}
#endif /* #ifdef LTQ_AEI_CUST */

		/* initialize array */
		memset(array_fvp, 0x00, sizeof(array_fvp));
		/*
		   array_fvp is an array holding parameters of IFX_NAME_VALUE_PAIR
		   type; here the fieldnames of wlan security parameters are filled in
		   the array */
		ifx_fill_ArrayFvp_FName(array_fvp, 0, WLAN_SEC_PARAM_COUNT,
					wlan_sec_params);
		/*
		   this function call is used to fill the array array_fvp with
		   parameters of type integer; \note - this function can only be used
		   for successive parameters of type integer; if one of the parameters
		   is for example of type string, then this function can only be used
		   to fill in the parameters up to the paramter of type string; */
		ifx_fill_ArrayFvp_intValues(array_fvp, 0, WLAN_SEC_PARAM_COUNT,
					    (int32 *) & wlSec->iid.cpeId.Id,
					    &wlSec->iid.pcpeId.Id,
					    &wlSec->beaconType, &wlSec->wlAuth,
					    &wlSec->wlEncr, &wlSec->basicAuth,
					    &wlSec->basicEncr, &wlSec->wpaAuth,
					    &wlSec->wpaEncr, &wlSec->wpa2Auth,
					    &wlSec->wpa2Encr,
					    &wlWepCfg.wepEncrLevel,
					    &wlWepCfg.wepKeyType,
					    &wlWepCfg.wepKeyIndex,
					    &wlSec->macAddrCntrlEna);

		vendor = ltq_mapi_get_wlan_vendor(wlMain.radioCpeId, IFX_F_DEFAULT);
		if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			/*
			 * To be Wi-Fi compliant we need to set the correct WPA_WPA2_mixed mode
			 */
			if (wlSec->beaconType == IFX_MAPI_WLAN_BEACON_WPA_WPA2_NON_COMPLIANT)
				sprintf(array_fvp[2].value, "%d", 3);
			else if (wlSec->beaconType == IFX_MAPI_WLAN_BEACON_WPA_WPA2)
				sprintf(array_fvp[2].value, "%d", 4);
		}

		for (i = 0; i < WLAN_SEC_PARAM_COUNT; i++)
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
				"name: %s, value: %s", array_fvp[i].fieldname,
				array_fvp[i].value);
	}
	count = WLAN_SEC_PARAM_COUNT;

	/*
	   Determine the configuration index and the fully qualified field value
	   pairs in array_fvp \note - for Add, Delete, Modify operations */
	if (ifx_get_conf_index_and_nv_pairs
	    (&wlSec->iid, passed_index, PREFIX_WLAN_SEC, count, array_fvp,
	     flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif				/* #ifdef IFX_LOG_DEBUG */
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	for (i = 0; i < WLAN_SEC_PARAM_COUNT; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
			       "name: %s, value: %s",
			       array_fvp[i].fieldname, array_fvp[i].value);

	/*
	   ACL (access control) checking block - MUST for MODIFY/DELETE operations */
	if (IFX_ADD_F_NOT_SET(flags) && IFX_INT_DONT_CHECK_ACL_F_NOT_SET(flags)) {
		CHECK_ACL_RET(wlSec->iid, count, array_fvp,
			      changed_count, array_changed_fvp, flags,
			      IFX_Handler)
	}

	if (!(features & LTQ_MAPI_WLAN_FEATURE_OPT_SCRIPTS)) {
		/* stop this ap/vap before calling apis below */
		if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
			IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
			IFX_DEACTIVATE_F_NOT_SET(flags)) {
			/* only stop the ap on delete operation */
			if (oper == IFX_OP_DEL) {
				/* both wlan main and wlan security instances share same index */
				sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, passed_index);
				LTQ_LOG_TIMESTAMP();
				system(conf_buf);
				LTQ_LOG_TIMESTAMP();
			}
		}
	}

	/*
	 ************* System Config File Update Block ***************
	 convert the name value pair in array_fvp into string format expected by rc.conf file
	 */
	ret = form_cfgdb_buf(conf_buf, count, array_fvp);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif				/* #ifdef IFX_LOG_DEBUG */
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
		goto IFX_Handler;
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
		       "conf_buf: %s, flags: 0x%x", conf_buf, flags);
	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_SEC, flags, 1, conf_buf);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif				/* #ifdef IFX_LOG_DEBUG */
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
		goto IFX_Handler;
	}

	if (IFX_MODIFY_F_SET(flags)) {
		/*
		   if beacon type is basic and encryption type is wep then call api to
		   set all wep keys */
		if (wlSec->beaconType == IFX_MAPI_WLAN_BEACON_BASIC) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
				       "passed_index: %d", passed_index);
			if (wlSec->wlEncr == IFX_MAPI_WLAN_ENCR_WEP) {
				/*
				   call ifx_mapi_set_wlan_wep_key \note - this api is called
				   irrespective of the operation for each of the 4 keys. For
				   modify operation cpeid should be passed, so that api will
				   come to know the index of the wep key which is being
				   modified. - the wep key api should be called with
				   wlSec->wepKeyIndex filled with the wep key index that is
				   operated irrespective of the operation - if
				   IFX_F_INT_DONT_CONFIGURE flag is not set then set the flag
				   bit before calling apis below this is to avoid device
				   configuration at multiple points which may be inconsistent
				   and also maintain virtual single entry point when calling
				   the below apis */
#if 1
				for (i = 0; i < IFX_MAPI_NUM_WEP_KEYS; i++) {
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
					if ((ret =
					     ifx_mapi_set_wlan_wep_key(oper, i,
								       &wlSec->secParams.wepCfg.wepKey[i],
								       flags |
								       IFX_F_INT_DONT_CONFIGURE |
								       IFX_F_DONT_WRITE_TO_FLASH | IFX_F_INT_DONT_SEND_SET_NOTIFICATION))
					    != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
						IFX_DBG
						    ("[%s:%d] ifx_mapi_set_wlan_wep_key has failed",
						     __FUNCTION__, __LINE__);
#endif				/* #ifdef IFX_LOG_DEBUG */
						IFX_MAPI_DEBUG(fd,
							       "/tmp/ifxMapiSetWlanSecurityConfig",
							       "ifx_mapi_set_wlan_wep_key has failed");
						goto IFX_Handler;
					}
				}
#else
				if ((ret =
				     ifx_mapi_set_wlan_wep_config(oper,
								  &wlSec->secParams.wepCfg,
								  flags | IFX_F_INT_DONT_CONFIGURE |
								  IFX_F_INT_DONT_SEND_SET_NOTIFICATION))
				    != IFX_SUCCESS) {
					IFX_MAPI_DEBUG(fd,
						       "/tmp/ifxMapiSetWlanSecurityConfig",
						       "ifx_mapi_set_wlan_wep_config has failed");
					goto IFX_Handler;
				}
#endif				/* if 0 */
			}
		} else if ((wlSec->beaconType == IFX_MAPI_WLAN_BEACON_WPA) ||
			   (wlSec->beaconType == IFX_MAPI_WLAN_BEACON_WPA2) ||
			   (wlSec->beaconType == IFX_MAPI_WLAN_BEACON_WPA_WPA2)
		    ) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");

			if (wlSec->wlAuth == IFX_MAPI_WLAN_AUTH_PERSONAL) {
				/* call mapiWlanSetPersonalConfig config */
				wlSec->secParams.personalCfg.psk.iid.pcpeId.Id =
				    wlSec->iid.cpeId.Id;
				wlSec->secParams.personalCfg.psk.iid.
				    config_owner = wlSec->iid.config_owner;
				wlSec->secParams.personalCfg.psk.iid.cpeId.Id =
				    wlSec->iid.cpeId.Id;

				if ((ret =
				     mapiWlanSetPersonalConfig(oper,
							       &wlSec->secParams.personalCfg.psk,
							       flags |
							       IFX_F_INT_DONT_CONFIGURE |
							       IFX_F_DONT_WRITE_TO_FLASH |
							       IFX_F_INT_DONT_SEND_SET_NOTIFICATION))
				    != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] ifx_set_wlan_passphrase_config has failed",
					     __FUNCTION__, __LINE__);
#endif				/* #ifdef IFX_LOG_DEBUG */
					IFX_MAPI_DEBUG(fd,
						       "/tmp/ifxMapiSetWlanSecurityConfig",
						       "mapiWlanSetPersonalConfig has failed");
					goto IFX_Handler;
				}

				{
					IFX_MAPI_WLAN_802_1x wlRadius;

					memset(&wlRadius, 0x00,
					       sizeof(IFX_MAPI_WLAN_802_1x));
					/* parent CPE ID of wlRadius object is cpeID of wlan
					   security object */
					wlRadius.iid.pcpeId.Id =
					    wlSec->iid.cpeId.Id;
					if ((ret =
					     ifx_mapi_get_wlan_802_1x_config
					     (&wlRadius,
					      IFX_F_DEFAULT)) != IFX_SUCCESS) {
						IFX_MAPI_DEBUG(fd,
							       "/tmp/ifxMapiSetWlanSecurityConfig",
							       "ifx_mapi_get_wlan_802_1x_config has failed");
						goto IFX_Handler;
					}
					wlRadius.groupKeyEna =
					    wlSec->secParams.personalCfg.
					    groupKeyEna;
					wlRadius.groupKeyIntvl =
					    wlSec->secParams.personalCfg.
					    groupKeyIntvl;
					/*
					   \todo check flags, when TR69 is available for Radius */
					if ((ret =
					     ifx_mapi_set_wlan_802_1x_config
					     (oper, &wlRadius,
					      (flags | IFX_F_INT_DONT_CONFIGURE |
                      IFX_F_DONT_WRITE_TO_FLASH |
					       IFX_F_INT_DONT_SEND_NOTIFICATION |
                      IFX_F_INT_DONT_CHECK_ACL |
                      IFX_F_INT_DONT_SEND_SET_NOTIFICATION))
					    ) != IFX_SUCCESS) {
						IFX_MAPI_DEBUG(fd,
							       "/tmp/ifxMapiSetWlanSecurityConfig",
							       "ifx_mapi_set_wlan_802_1x_config has failed");
						goto IFX_Handler;
					}
				}
			} else if (wlSec->wlAuth == IFX_MAPI_WLAN_AUTH_RADIUS) {
				/* call ifx_set_wlan_passphrase config */
				wlSec->secParams.wlRadius.iid.pcpeId.Id =
				    wlSec->iid.cpeId.Id;
				wlSec->secParams.wlRadius.iid.config_owner =
				    wlSec->iid.config_owner;
				wlSec->secParams.wlRadius.iid.cpeId.Id =
				    wlSec->iid.cpeId.Id;
				/*
				   \todo check flags, when TR69 is available for Radius */
				if ((ret =
				     ifx_mapi_set_wlan_802_1x_config(oper,
								     &wlSec->secParams.wlRadius,
								     (flags | IFX_F_INT_DONT_CONFIGURE |
								      IFX_F_DONT_WRITE_TO_FLASH |
								      IFX_F_INT_DONT_SEND_NOTIFICATION |
                              IFX_F_INT_DONT_CHECK_ACL |
                              IFX_F_INT_DONT_SEND_SET_NOTIFICATION))
				    ) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] ifx_mapi_set_wlan_802_1x_config has failed",
					     __FUNCTION__, __LINE__);
#endif				/* #ifdef IFX_LOG_DEBUG */
					IFX_MAPI_DEBUG(fd,
						       "/tmp/ifxMapiSetWlanSecurityConfig",
						       "ifx_mapi_set_wlan_802_1x_config has failed");
					goto IFX_Handler;
				}
			}
		}
	}

	/*
	 ********** Device Configuration Block ****************
	 Device config thru Scripts/Utilities or Functions
	 */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags)) {
		if (oper == IFX_OP_MOD) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
				"phyIdx: %d, radioEnabled: %d, apEnabled: %d",
				g_wlMain[passed_index].radioCpeId - 1,
				g_wlPhy[g_wlMain[passed_index].radioCpeId - 1].radioEnable,
				g_wlMain[passed_index].apEnable);
			if (g_wlMain[passed_index].apEnable) {
				/* both wlan main and wlan security instances share same index */
				if (features & LTQ_MAPI_WLAN_FEATURE_OPT_SCRIPTS) {
					if (g_flag_ssid_changed) {
						if (IFX_F_INT_DONT_START_WLAN_IF_ON_SECURITY_CHANGE_F_SET(flags)) {
							sprintf(conf_buf, "%s %d 1 0", SERVICE_WLAN_MODIFY,
								passed_index);
						}
						else {
							sprintf(conf_buf, "%s %d 1 1", SERVICE_WLAN_MODIFY,
								passed_index);
						}
						LTQ_LOG_TIMESTAMP("SERVICE_WLAN_MODIFY Begin");
					} else {
						if (IFX_F_INT_DONT_START_WLAN_IF_ON_SECURITY_CHANGE_F_SET(flags)) {
							sprintf(conf_buf, "%s %d 0", SERVICE_WLAN_SEC_MODIFY, passed_index);
						}
						else {
							sprintf(conf_buf, "%s %d 1", SERVICE_WLAN_SEC_MODIFY, passed_index);
						}
						LTQ_LOG_TIMESTAMP("SERVICE_WLAN_SEC_MODIFY");
					}
					g_flag_ssid_changed = 0;
				} else {
					sprintf(conf_buf, "%s %d", SERVICE_WLAN_SEC_MODIFY, passed_index);
				}
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
					"conf_buf: %s", conf_buf);
				system(conf_buf);
				LTQ_LOG_TIMESTAMP("SERVICE Done");
			}
		}
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "flags: 0x%x", flags);

	/* this will Compact the section and also update the count for both ADD and
	   DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_WLAN_SEC, flags);

   /*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

   /*********** Epilog Block **************/
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_MODIFY_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
		CHECK_N_SEND_NOTIFICATION(wlSec->iid, changed_count,
					  array_changed_fvp, flags, IFX_Handler)
	} else if (IFX_INT_ADD_F_SET(flags)) {
		/* In case of ADD operation, first update the ID Mappings and then send
		   the Notification for the attributes */
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
      /*********** Epilog Block **************/
		UPDATE_ID_MAP_N_ATTRIBUTES(&wlSec->iid, count, array_fvp, flags,
					   IFX_Handler)

		    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
				   "cpeId: %d, pCpeId:%d, owner: %d",
				   wlSec->iid.cpeId.Id, wlSec->iid.pcpeId.Id,
				   wlSec->iid.config_owner);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
			       "cpeId.secName: %s, pcpeId.secName: %s",
			       wlSec->iid.cpeId.secName,
			       wlSec->iid.pcpeId.secName);

		if (IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(flags)) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
				       "");
			CHECK_N_SEND_NOTIFICATION(wlSec->iid, count, array_fvp,
						  flags, IFX_Handler)
		}

		/* Manipulate nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WLAN_SEC);

	} else if (IFX_DELETE_F_SET(flags)) {
		/* In case of DELETE operation, first send the notificatioupdate the ID
		   Mappings and then send the Notification for the attributes */
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
      /*********** Epilog Block **************/
		if (IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(flags)) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
				       "");
			CHECK_N_SEND_NOTIFICATION(wlSec->iid, count, array_fvp,
						  flags, IFX_Handler)
		}

		UPDATE_ID_MAP_N_ATTRIBUTES(&wlSec->iid, count, array_fvp, flags,
					   IFX_Handler)
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");

	if (oper == IFX_OP_ADD) {
		/*
		   objects for personal configuration and enterprise configuration have
		   to be added as well (use some default values) */
		if ((ret = mapiWlan8021XConfig(oper, wlSec)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
				       "mapiWlan8021XConfig has failed");
			goto IFX_Handler;
		}
		if ((ret = mapiWlanPersonalConfig(oper, wlSec)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
				       "mapiWlanPersonalConfig has failed");
			goto IFX_Handler;
		}
		if ((ret = mapiWlanWepConfig(oper, wlSec, flags)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
				"mapiWlanWepConfig has failed\nFlags: 0x%x", flags);
			goto IFX_Handler;
		}
	}

#if defined (LTQ_AEI_CUST)
if (IFX_MODIFY_F_SET(flags)) {
	IFX_MAPI_WLAN_PhyCfg 	wlPhy;
	bool 					f_isWepActive = FALSE;
	int32					phyIdx = -1;

	memset(&wlPhy, 0, sizeof(IFX_MAPI_WLAN_PhyCfg));
	sprintf(wlPhy.iid.cpeId.secName, "%s", TAG_WLAN_PHY);
	sprintf(wlPhy.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
	phyIdx = g_wlMain[passed_index].radioCpeId - 1;
	wlPhy.iid.cpeId.Id = phyIdx + 1;

	if ((wlSec->wlEncr != IFX_MAPI_WLAN_ENCR_WEP) &&
		(gOpMode < IFX_MAPI_WLAN_STD_802_11_ALL)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "g_nVap: %d",
			g_nVap);
		f_isWepActive = FALSE;
		for (i = 0; i < g_nVap; i++) {
			/* do not check passed_index as this is the new configuration */
			if (i == passed_index) {
				continue;
			}
			if (g_wlSec[i].wlEncr == IFX_MAPI_WLAN_ENCR_WEP) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
					"VAP%d is WEP", i);
				f_isWepActive = TRUE;
				break;
			}
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
			"f_isWepActive: %d", f_isWepActive);
		if (!f_isWepActive) {
			if ((ret = ifx_mapi_get_wlan_phy_config(&wlPhy, IFX_F_GET_ANY)) !=
				IFX_SUCCESS) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
				goto IFX_Handler;
			}
			/* if user switched freqBand, avoid illegal combinations */
			if (wlPhy.freqBand == IFX_MAPI_WLAN_2_4_GHz_Freq) {
				if ((gOpMode == IFX_MAPI_WLAN_STD_802_11N) ||
					(gOpMode == IFX_MAPI_WLAN_STD_802_11BGN) ||
					(gOpMode == IFX_MAPI_WLAN_STD_802_11GN)) {
						IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
							"");
						/* restore previous operating mode */
						wlPhy.standard = gOpMode;
				}
				else {
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
					wlPhy.standard = IFX_MAPI_WLAN_STD_802_11BGN;
				}
			}
			else {
				if ((gOpMode == IFX_MAPI_WLAN_STD_802_11N) ||
					(gOpMode == IFX_MAPI_WLAN_STD_802_11AN)) {
						IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
							"");
						/* restore previous operating mode */
						wlPhy.standard = gOpMode;
				}
				else {
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
					wlPhy.standard = IFX_MAPI_WLAN_STD_802_11AN;
				}
			}
			if ((ret = ifx_mapi_set_wlan_phy_config(IFX_OP_MOD, &wlPhy,
				flags | IFX_F_INT_DONT_SEND_SET_NOTIFICATION |
				IFX_F_DONT_WRITE_TO_FLASH)) != IFX_SUCCESS) {
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
						"ifx_set_wlan_phy_config has failed");
				goto IFX_Handler;
			}
			gOpMode = IFX_MAPI_WLAN_STD_802_11_ALL;
		}
	}
}
#endif /* #if defined (LTQ_AEI_CUST) */

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif				/* #ifdef IFX_LOG_DEBUG */
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
		goto IFX_Handler;
	}

	/* reset flags to reload the configuration */
	g_flagConfigLoaded = 0;
	g_flagSecConfig = 0;
	system("echo 0 > /tmp/web_Secflg &");

#ifdef TR69_DEFINED
	/* notify devm regarding the set in mapi */
	if(IFX_INT_DONT_SEND_SET_NOTIFICATION_F_NOT_SET(flags) && (wlSec->iid.config_owner == IFX_WEB)) {
//		ifx_tr69_value_change_notify(&wlSec->iid);
	}
#endif

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "ret: %d", ret);
	IFX_MEM_FREE(array_changed_fvp)
	LTQ_LOG_TIMESTAMP("Done");
	return ret;
}

/**
   \param   oper  - type of operation (ADD, MODIFY, DELETE)

   \param   wlApCfg - pointer to IFX_MAPI_WLAN_AP_Cfg structure

   \param   flags - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE

   \remarks - ap should not be deleted
            - web when calling for delete will pass ssid only or something more ??
            - validation for wep key type and passphrase key type
            - validation to check for combination of standard, country, op-reates, basic-rates and channels
            - wireless start script checks if both phy-radio and this ap/vap is enabled, then only starts the service
*/
int32
ifx_mapi_set_wlan_ap_config(uint32 oper, IFX_MAPI_WLAN_AP_Cfg * wlApCfg,
			    uint32 flags)
{
	CPE_ID cpe_id;
	char8 conf_buf[MAX_FILELINE_LEN];
	int32 ret = IFX_SUCCESS, passed_index = -1, i = 0;
	uint32 flags_save = IFX_F_DEFAULT;
	LTQ_MAPI_WLAN_Vendor	vendor = LTQ_MAPI_WLAN_VENDOR_NONE;
	LTQ_MAPI_WLAN_Feature	features = LTQ_MAPI_WLAN_FEATURE_NONE;

	LTQ_LOG_TIMESTAMP("Begin");

	if (wlApCfg->main.devType == IFX_MAPI_WLAN_DEV_TYPE_AP) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_set_wlan_ap_config_timing", "AP:");
	}
	else {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_set_wlan_ap_config_timing", "VAP:");
	}
	
	IFX_MAPI_DEBUG(fd,
		       "/tmp/ifxMapiSetWlanApConfig",
		       "wlApCfg->iid.cpeId.Id: %d, wlApCfg->iid.pcpeId.Id: %d "
		       "wlApCfg->iid.cpeId.secName: %s, wlApCfg->iid.pcpeId.secName: %s "
		       "oper: %d, flags: 0x%x",
		       wlApCfg->iid.cpeId.Id, wlApCfg->iid.pcpeId.Id,
		       wlApCfg->iid.cpeId.secName, wlApCfg->iid.pcpeId.secName,
		       oper, flags);

	sprintf(wlApCfg->iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
	sprintf(wlApCfg->iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

	if (oper == IFX_OP_ADD) {
		/* validate operation: add and delete operation must not be used with AP */
		if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
			if (wlApCfg->main.devType == IFX_MAPI_WLAN_DEV_TYPE_AP) {
				IFX_MAPI_DEBUG(fd,
					       "/tmp/ifxMapiSetWlanApConfig",
					       "Add operation is not supported on AP");
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}

		/*
		   get iid for this ap in case of add and use this iid for wlan_main,
		   wlan_sec and wlan_802.1X -> requirement for TR69, which uses only
		   one tr69id; other objects like wlan_wep, wlan_psk, wlan_ap_wmm, etc.
		   request a unique tr69id when a new object is generated */
		if (ifx_get_IID(&wlApCfg->iid, "ssid") != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "");
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
			"cpeId: %d, tr69Id: %s",
			wlApCfg->iid.cpeId.Id, wlApCfg->iid.tr69Id);

		/* save given flags to in flags_local */
		flags_save = flags;
		/*
		   set the IFX_F_INT_DONT_CONFIGURE flag bit before calling apis below;
		   this is to avoid device configuration at multiple points which may be
		   inconsistent and also maintain virtual single entry point when calling
		   the below apis */
		flags |= IFX_F_INT_DONT_CONFIGURE;
		/*
		   set the IFX_F_DONT_WRITE_TO_FLASH flag bit before calling apis
		   below; this is to avoid that the device configuration is writtten
		   multiple times to the flash; it is sufficient to do this once at the
		   end of this function */
		flags |= IFX_F_DONT_WRITE_TO_FLASH;

		/*
		   before calling main api, make sure iid settings are set correct, in
		   case they are not already set from upper layer */
		sprintf(wlApCfg->main.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
		sprintf(wlApCfg->main.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
		wlApCfg->main.iid.config_owner = wlApCfg->iid.config_owner;
		wlApCfg->main.iid.cpeId.Id = wlApCfg->iid.cpeId.Id;
		wlApCfg->main.iid.pcpeId.Id = wlApCfg->iid.pcpeId.Id;
		strcpy(wlApCfg->main.iid.tr69Id, wlApCfg->iid.tr69Id);
		wlApCfg->main.radioCpeId = wlApCfg->phy.iid.cpeId.Id;

		/*
		   in case of add and delete operation, the two functions
		   ifx_mapi_set_wlan_main_config and ifx_mapi_set_wlan_security_config
		   send notifications to TR69 stack; this must be avoided; therefore
		   ifx_mapi_set_wlan_security config is called with no additional
		   flags, e.g. the TR69 stack is notified, the latter call to
		   ifx_mapi_set_wlan_main_config will have additional flags set to
		   avoid sending another notification */
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
			       "oper: %d, flags: 0x%x", oper, flags);
		if ((ret =
		     ifx_mapi_set_wlan_main_config(oper, &wlApCfg->main,
						   flags | IFX_F_INT_DONT_SEND_SET_NOTIFICATION)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
				       "ifx_set_wlan_main_config has failed");
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] ifx_set_wlan_main_config has failed",
				__FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		/*
		   before calling security api, make sure iid settings are set correct,
		   in case they are not already set from upper layer */
		sprintf(wlApCfg->sec.iid.cpeId.secName, "%s", TAG_WLAN_SEC);
		sprintf(wlApCfg->sec.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
		wlApCfg->sec.iid.config_owner = wlApCfg->iid.config_owner;
		wlApCfg->sec.iid.cpeId.Id = wlApCfg->iid.cpeId.Id;
		wlApCfg->sec.iid.pcpeId.Id = wlApCfg->iid.pcpeId.Id;
		strcpy(wlApCfg->sec.iid.tr69Id, wlApCfg->iid.tr69Id);

		/*
		   Dont send a notification to TR69 stack: notification has already
		   been sent from ifx_mapi_set_wlan_main_config; now set the flags to
		   avoid sending notification again */
		flags = IFX_SET_DONT_SEND_NOTIFICATION_FLAG(flags);
		flags = IFX_SET_DONT_CHECK_ACL_FLAG(flags);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
			       "oper: %d, flags: 0x%x", oper, flags);
		if ((ret =
			ifx_mapi_set_wlan_security_config(oper, &wlApCfg->sec, flags | IFX_F_INT_DONT_SEND_SET_NOTIFICATION)) !=
			IFX_SUCCESS) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
				"ifx_set_wlan_security_config has failed");
				goto IFX_Handler;
		}
		/* enable notifications to TR69 */
		flags = IFX_UNSET_DONT_SEND_NOTIFICATION_FLAG(flags);
		/* enable check of ACL */
		flags = IFX_UNSET_DONT_CHECK_ACL_FLAG(flags);

		/* set flag to avoid writing to flash */
		flags |= IFX_F_DONT_WRITE_TO_FLASH;
		for (i = 0; i < IFX_MAPI_WLAN_WMM_NUM_AC; i++) {
			/*
			   before calling wmm api, make sure iid settings are set correct,
			   in case they are not already set from upper layer */
			sprintf(wlApCfg->apWmm[i].iid.cpeId.secName, "%s",
				TAG_WLAN_WMM_AP);
			sprintf(wlApCfg->apWmm[i].iid.pcpeId.secName, "%s",
				TAG_WLAN_MAIN);
			wlApCfg->apWmm[i].iid.config_owner =
			    wlApCfg->iid.config_owner;
			/* set pCpeId, which is cpeId of parent (wlan_main) */
			wlApCfg->apWmm[i].iid.pcpeId.Id = wlApCfg->iid.cpeId.Id;
#if 0
			strcpy(wlApCfg->apWmm[i].iid.tr69Id,
			       wlApCfg->iid.tr69Id);
#endif

			if ((ret =
			     ifx_mapi_set_wlan_wmm_ap_config(oper,
							     &wlApCfg->apWmm[i],
							     flags | IFX_F_INT_DONT_SEND_SET_NOTIFICATION)) !=
			    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("[%s:%d] ifx_mapi_set_wlan_wmm_ap_config has failed",
				     __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}

			/*
			   before calling main api, make sure iid settings are set correct,
			   in case they are not already set from upper layer */
			sprintf(wlApCfg->staWmm[i].iid.cpeId.secName, "%s",
				TAG_WLAN_WMM_STA);
			sprintf(wlApCfg->staWmm[i].iid.pcpeId.secName, "%s",
				TAG_WLAN_MAIN);
			wlApCfg->staWmm[i].iid.config_owner =
			    wlApCfg->iid.config_owner;
			/* set pCpeId, which is cpeId of parent (wlan_main) */
			wlApCfg->staWmm[i].iid.pcpeId.Id =
			    wlApCfg->iid.cpeId.Id;

#if 0
			/*
			   \todo check if tr69 id can be copied */
			strcpy(wlApCfg->staWmm[i].iid.tr69Id,
			       wlApCfg->iid.tr69Id);
#endif
			if ((ret =
			     ifx_mapi_set_wlan_wmm_sta_config(oper,
							      &wlApCfg->
							      staWmm[i],
							      flags | IFX_F_INT_DONT_SEND_SET_NOTIFICATION)) !=
			    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("[%s:%d] ifx_mapi_set_wlan_wmm_ap_config has failed",
				     __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}
		}

		/* get supported features */
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "radioCpeId: %d",
			wlApCfg->main.radioCpeId);
		features = ltq_mapi_get_wlan_supported_features(wlApCfg->main.radioCpeId,
			IFX_F_DEFAULT);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
			"features: %d", features);
		if (features & LTQ_MAPI_WLAN_FEATURE_WPS) {
			/*
			   before calling api, make sure iid settings are set correct, in case
			   they are not already set from upper layer */
			sprintf(wlApCfg->wps.iid.cpeId.secName, "%s", TAG_WLAN_WPS);
			sprintf(wlApCfg->wps.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
			wlApCfg->wps.iid.config_owner = wlApCfg->iid.config_owner;
			/* set pCpeId, which is cpeId of parent (wlan_main) */
			wlApCfg->wps.iid.pcpeId.Id = wlApCfg->iid.cpeId.Id;
			if ((ret = ifx_mapi_set_wlan_wps_config(oper, &wlApCfg->wps,
				flags | IFX_F_INT_DONT_SEND_SET_NOTIFICATION)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
					("[%s:%d] ifx_mapi_set_wlan_wps_config has failed",
					 __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}

			/*
			   before calling api, make sure iid settings are set correct, in case
			   they are not already set from upper layer */
			sprintf(wlApCfg->wpsRegs.iid.cpeId.secName, "%s",
				TAG_WLAN_WPS_REGISTRAR);
			sprintf(wlApCfg->wpsRegs.iid.pcpeId.secName, "%s",
				TAG_WLAN_WPS);
			wlApCfg->wpsRegs.iid.config_owner = wlApCfg->iid.config_owner;
			/* set pCpeId, which is cpeId of parent (wlan_wps) */
			wlApCfg->wpsRegs.iid.pcpeId.Id = wlApCfg->wps.iid.cpeId.Id;

			/*
			   \todo available for tr69 make as soon as required changes are
			   available in devm */
			if ((ret = ifx_mapi_set_wlan_wps_registrar_config(oper,
				&wlApCfg->wpsRegs, flags | IFX_F_INT_DONT_SEND_SET_NOTIFICATION))
				!= IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] ifx_mapi_set_wlan_wps_registrar_config has failed:\n"
					"oper: %d, flags: 0x%x", __FUNCTION__, __LINE__, oper, flags);
#endif
				goto IFX_Handler;
			}
		}

		if (features & LTQ_MAPI_WLAN_FEATURE_WDS) {
			/*
			   before calling api, make sure iid settings are set correct, in case
			   they are not already set from upper layer */
			sprintf(wlApCfg->wds.iid.cpeId.secName, "%s", TAG_WLAN_WDS);
			sprintf(wlApCfg->wds.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
			wlApCfg->wds.iid.config_owner = wlApCfg->iid.config_owner;
			/* set pCpeId, which is cpeId of parent (wlan_main) */
			wlApCfg->wds.iid.pcpeId.Id = wlApCfg->iid.cpeId.Id;

			flags = IFX_SET_DONT_SEND_NOTIFICATION_FLAG(flags);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "flags: 0x%x", flags);
			if ((ret =
				ltq_mapi_set_wlan_wds_config(oper, &wlApCfg->wds, flags)) !=
				IFX_SUCCESS) {
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
						"ltq_mapi_set_wlan_wds_config has failed");
				goto IFX_Handler;
			}
			/* enable check of ACL */
			flags = IFX_UNSET_DONT_SEND_NOTIFICATION_FLAG(flags);
		}

		/* reset do not write to flash flag */
		flags &= ~((uint32) IFX_F_DONT_WRITE_TO_FLASH);
		/*
		   start this ap/vap if the original variable flags does not contain
		   any flags, preventing this */
		if (IFX_DONT_ACTIVATE_F_NOT_SET(flags_save)) {
			cpe_id.Id = wlApCfg->iid.cpeId.Id;
			sprintf(cpe_id.secName, "%s", TAG_WLAN_MAIN);
			IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpe_id, passed_index);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
				"passed_index: %d", passed_index);
			if (passed_index < 0) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}

			/* passed index should be that of wlan_main instance */
			sprintf(conf_buf, "%s %d", SERVICE_WLAN_ADD_VAP, passed_index);
			LTQ_LOG_TIMESTAMP();
			system(conf_buf);
			LTQ_LOG_TIMESTAMP();
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
			       "oper: %d, flags_save: 0x%x", oper, flags_save);
	} else if (oper == IFX_OP_DEL) {
		/* validate operation: add and delete operation must not be used with AP */
		if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
			if (wlApCfg->main.devType == IFX_MAPI_WLAN_DEV_TYPE_AP) {
				IFX_MAPI_DEBUG(fd,
					       "/tmp/ifxMapiSetWlanApConfig",
					       "Delete operation is not supported on AP");
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}

		/* Get object from system */
		ret = ifx_mapi_get_wlan_ap_config(wlApCfg, IFX_F_DEFAULT);
		if (ret != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "");
			goto IFX_Handler;
		}

		/* get vendor information */
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "radioCpeId: %d",
			wlApCfg->main.radioCpeId);
		vendor = ltq_mapi_get_wlan_vendor(wlApCfg->main.radioCpeId, IFX_F_DEFAULT);
		features = ltq_mapi_get_wlan_supported_features(wlApCfg->main.radioCpeId,
			IFX_F_DEFAULT);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
			"vendor: %d, features: %d", vendor, features);

		/*
		   stop this ap/vap before calling apis below, if the original variable
		   flags does not contain any flags, preventing this */
		if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
			cpe_id.Id = wlApCfg->iid.cpeId.Id;
			sprintf(cpe_id.secName, "%s", TAG_WLAN_MAIN);
			IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpe_id, passed_index);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
				"passed_index: %d", passed_index);
			sprintf(conf_buf, "%s %d", SERVICE_WLAN_REMOVE_VAP, passed_index);

			LTQ_LOG_TIMESTAMP();
			system(conf_buf);
			LTQ_LOG_TIMESTAMP();
		}

		/* save given flags to in flags_local */
		flags_save = flags;
		/*
		   set the IFX_F_INT_DONT_CONFIGURE flag bit before calling apis below;
		   this is to avoid device configuration at multiple points which may be
		   inconsistent and also maintain virtual single entry point when calling
		   the below apis */
		flags |= IFX_F_INT_DONT_CONFIGURE;
		/*
		   set the IFX_F_DONT_WRITE_TO_FLASH flag bit before calling apis
		   below; this is to avoid that the device configuration is writtten
		   multiple times to the flash; it is sufficient to do this once at the
		   end of this function */
		flags |= IFX_F_DONT_WRITE_TO_FLASH;

		/* first delete the child objects wds, wmm, wps, psk, wep, 8021x */
		if (features & LTQ_MAPI_WLAN_FEATURE_WDS) {
			/*
			   before calling api, make sure iid settings are set correct, in case
			   they are not already set from upper layer */
			sprintf(wlApCfg->wds.iid.cpeId.secName, "%s", TAG_WLAN_WDS);
			sprintf(wlApCfg->wds.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
			wlApCfg->wds.iid.config_owner = wlApCfg->iid.config_owner;
			/* set pCpeId, which is cpeId of parent (wlan_main) */
			wlApCfg->wds.iid.pcpeId.Id = wlApCfg->iid.cpeId.Id;

			/*
			   \todo available for tr69 make as soon as required changes are
			   available in devm */
			/* enable notifications to TR69 */
			flags = IFX_SET_DONT_SEND_NOTIFICATION_FLAG(flags);
			/* enable check of ACL */
			flags = IFX_SET_DONT_CHECK_ACL_FLAG(flags);

			if ((ret = ltq_mapi_set_wlan_wds_config(oper, &wlApCfg->wds, flags))
				!= IFX_SUCCESS) {
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
					"ltq_mapi_set_wlan_wds_config has failed");
					goto IFX_Handler;
			}

			/* enable notifications to TR69 */
			flags = IFX_UNSET_DONT_SEND_NOTIFICATION_FLAG(flags);
			/* enable check of ACL */
			flags = IFX_UNSET_DONT_CHECK_ACL_FLAG(flags);
		}

		if (features & LTQ_MAPI_WLAN_FEATURE_WPS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "");
			/*
			   before calling api, make sure iid settings are set correct, in case
			   they are not already set from upper layer */
			sprintf(wlApCfg->wpsRegs.iid.cpeId.secName, "%s",
				TAG_WLAN_WPS_REGISTRAR);
			sprintf(wlApCfg->wpsRegs.iid.pcpeId.secName, "%s",
				TAG_WLAN_MAIN);
			wlApCfg->wpsRegs.iid.config_owner = wlApCfg->iid.config_owner;
			/* set pCpeId, which is cpeId of parent (wlan_main) */
			wlApCfg->wpsRegs.iid.pcpeId.Id = wlApCfg->iid.cpeId.Id;

			/*
			   \todo available for tr69 make as soon as required changes are
			   available in devm */
			/* enable notifications to TR69 */
			flags = IFX_SET_DONT_SEND_NOTIFICATION_FLAG(flags);
			/* enable check of ACL */
			flags = IFX_SET_DONT_CHECK_ACL_FLAG(flags);
			if ((ret =
				ifx_mapi_set_wlan_wps_registrar_config(oper, &wlApCfg->wpsRegs,
				flags| IFX_F_INT_DONT_SEND_SET_NOTIFICATION)) != IFX_SUCCESS) {
					IFX_DBG
					("[%s:%d] ifx_mapi_set_wlan_wps_registrar_config has failed",
					 __FUNCTION__, __LINE__);
				goto IFX_Handler;
			}
			/* enable notifications to TR69 */
			flags = IFX_UNSET_DONT_SEND_NOTIFICATION_FLAG(flags);
			/* enable check of ACL */
			flags = IFX_UNSET_DONT_CHECK_ACL_FLAG(flags);

			/*
			   before calling api, make sure iid settings are set correct, in case
			   they are not already set from upper layer */
			sprintf(wlApCfg->wps.iid.cpeId.secName, "%s", TAG_WLAN_WPS);
			sprintf(wlApCfg->wps.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
			wlApCfg->wps.iid.config_owner = wlApCfg->iid.config_owner;
			/* set pCpeId, which is cpeId of parent (wlan_main) */
			wlApCfg->wps.iid.pcpeId.Id = wlApCfg->iid.cpeId.Id;

			if ((ret = ifx_mapi_set_wlan_wps_config(oper, &wlApCfg->wps,
				flags | IFX_F_INT_DONT_SEND_SET_NOTIFICATION)) != IFX_SUCCESS) {
				IFX_DBG ("[%s:%d] ifx_mapi_set_wlan_wps_config has failed: flags: 0x%x",
					__FUNCTION__, __LINE__, flags | IFX_F_INT_DONT_SEND_SET_NOTIFICATION);
				goto IFX_Handler;
			}
		}

		for (i = 3; i >= 0; i--) {
			/*
			   before calling wmm api, make sure iid settings are set correct,
			   in case they are not already set from upper layer */
			sprintf(wlApCfg->apWmm[i].iid.cpeId.secName, "%s",
				TAG_WLAN_WMM_AP);
			sprintf(wlApCfg->apWmm[i].iid.pcpeId.secName, "%s",
				TAG_WLAN_MAIN);
			wlApCfg->apWmm[i].iid.config_owner =
			    wlApCfg->iid.config_owner;
			/* set pCpeId, which is cpeId of parent (wlan_main) */
			wlApCfg->apWmm[i].iid.pcpeId.Id = wlApCfg->iid.cpeId.Id;

			/* set cpeId = (pCpeId-1)*4 + i */
			/* \todo check if this is correct after multiple add/remove VAP */
			wlApCfg->apWmm[i].iid.cpeId.Id =
				((wlApCfg->apWmm[i].iid.pcpeId.Id - 1) * 4) + i + 1;
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "cpeId: %d",
				wlApCfg->apWmm[i].iid.cpeId.Id);

			/* set access category */
			wlApCfg->apWmm[i].ac = i;

			if ((ret =
				ifx_mapi_set_wlan_wmm_ap_config(oper, &wlApCfg->apWmm[i],
					flags | IFX_F_INT_DONT_SEND_SET_NOTIFICATION)) !=
					IFX_SUCCESS) {
				IFX_DBG ("[%s:%d] ifx_mapi_set_wlan_wmm_ap_config has failed",
				     __FUNCTION__, __LINE__);
				goto IFX_Handler;
			}

			/*
			   before calling wmm sta api, make sure iid settings are set
			   correct, in case they are not already set from upper layer */
			sprintf(wlApCfg->staWmm[i].iid.cpeId.secName, "%s",
				TAG_WLAN_WMM_STA);
			sprintf(wlApCfg->staWmm[i].iid.pcpeId.secName, "%s",
				TAG_WLAN_MAIN);
			wlApCfg->staWmm[i].iid.config_owner =
			    wlApCfg->iid.config_owner;
			/* set pCpeId, which is cpeId of parent (wlan_main) */
			wlApCfg->staWmm[i].iid.pcpeId.Id =
			    wlApCfg->iid.cpeId.Id;

			/* set cpeId = (pCpeId-1)*4 + i */
			/* \todo check if this is correct after multiple add/remove VAP */
			wlApCfg->staWmm[i].iid.cpeId.Id =
				((wlApCfg->staWmm[i].iid.pcpeId.Id - 1) * 4) + i + 1;
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "cpeId: %d",
				wlApCfg->staWmm[i].iid.cpeId.Id);

			/* set access category */
			wlApCfg->staWmm[i].ac = i;

			if ((ret = ifx_mapi_set_wlan_wmm_sta_config(oper,
							      &wlApCfg->
							      staWmm[i],
							      flags | IFX_F_INT_DONT_SEND_SET_NOTIFICATION)) !=
			    IFX_SUCCESS) {
				IFX_DBG("[%s:%d] ifx_mapi_set_wlan_wmm_ap_config has failed",
					__FUNCTION__, __LINE__);
				goto IFX_Handler;
			}
		}

		/*
		   before calling security api, make sure iid settings are set correct,
		   in case they are not already set from upper layer */
		sprintf(wlApCfg->sec.iid.cpeId.secName, "%s", TAG_WLAN_SEC);
		sprintf(wlApCfg->sec.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
		wlApCfg->sec.iid.config_owner = wlApCfg->iid.config_owner;
		wlApCfg->sec.iid.cpeId.Id = wlApCfg->iid.cpeId.Id;
		wlApCfg->sec.iid.pcpeId.Id = wlApCfg->iid.pcpeId.Id;
		strcpy(wlApCfg->sec.iid.tr69Id, wlApCfg->iid.tr69Id);

		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
			       "oper: %d, flags: 0x%x", oper, flags);
		/*
		   in case of add and delete operation, the two functions
		   ifx_mapi_set_wlan_main_config and ifx_mapi_set_wlan_security_config
		   send notifications to TR69 stack; this must be avoided; therefore
		   ifx_mapi_set_wlan_security config is called with no additional
		   flags, e.g. the TR69 stack is notified, the latter call to
		   ifx_mapi_set_wlan_main_config will have additional flags set to
		   avoid sending another notification */
		if ((ret =
		     ifx_mapi_set_wlan_security_config(oper, &wlApCfg->sec,
						       flags | IFX_F_INT_DONT_SEND_SET_NOTIFICATION)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
				       "ifx_set_wlan_security_config has failed");
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("[%s:%d] ifx_set_wlan_security_config has failed",
			     __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		/*
		   before calling main api, make sure iid settings are set correct, in
		   case they are not already set from upper layer */
		sprintf(wlApCfg->main.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
		sprintf(wlApCfg->main.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
		wlApCfg->main.iid.config_owner = wlApCfg->iid.config_owner;
		wlApCfg->main.iid.cpeId.Id = wlApCfg->iid.cpeId.Id;
		wlApCfg->main.iid.pcpeId.Id = wlApCfg->iid.pcpeId.Id;
#if 0
		strcpy(wlApCfg->main.iid.tr69Id, wlApCfg->iid.tr69Id);
#endif
		wlApCfg->main.radioCpeId = wlApCfg->phy.iid.cpeId.Id;

		/*
		   Dont send a notification to TR69 stack: notification has already
		   been sent from ifx_mapi_set_wlan_security_config; now set the flags
		   to avoid sending notification again */
		flags = IFX_SET_DONT_SEND_NOTIFICATION_FLAG(flags);
		flags = IFX_SET_DONT_CHECK_ACL_FLAG(flags);
		/*
		   unset the IFX_F_INT_DONT_CONFIGURE flag bit before calling
		   ifx_mapi_set_wlan_main_config api below; this is to ensure device
		   configuration at the last stage of VAP removal */
//		flags &= ~((uint32) IFX_F_INT_DONT_CONFIGURE);
//		flags &= ~((uint32) IFX_F_DONT_WRITE_TO_FLASH);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
			       "oper: %d, flags: 0x%x", oper, flags);
		if ((ret =
		     ifx_mapi_set_wlan_main_config(oper, &wlApCfg->main,
						   flags | IFX_F_INT_DONT_SEND_SET_NOTIFICATION)) != IFX_SUCCESS) {
			IFX_DBG("[%s:%d] ifx_set_wlan_main_config has failed",
				__FUNCTION__, __LINE__);
			goto IFX_Handler;
		}
	} else if (oper == IFX_OP_MOD) {
#if defined (LTQ_AEI_CUST)
{
		IFX_MAPI_WLAN_Standard 	opMode;
		bool f_isWepActive = FALSE;

		if (wlApCfg->sec.wlEncr == IFX_MAPI_WLAN_ENCR_WEP) {
			opMode = g_wlPhy[0].standard;
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "opMode: %d",
				opMode);
			/*
			 * if security is WEP and oper mode is any 802.11xn, then the OP mode
			 * is set back to non-N mode
			 */
			if (opMode >= IFX_MAPI_WLAN_STD_802_11N) {
				/* save opMode in global variable */
				gOpMode = opMode;
	
				switch (gOpMode) {
				case IFX_MAPI_WLAN_STD_802_11N:
					if (wlApCfg->phy.freqBand == IFX_MAPI_WLAN_2_4_GHz_Freq) {
						wlApCfg->phy.standard = IFX_MAPI_WLAN_STD_802_11BG;
					}
					else {
						wlApCfg->phy.standard = IFX_MAPI_WLAN_STD_802_11A;
					}
					break;
				case IFX_MAPI_WLAN_STD_802_11BGN:
					wlApCfg->phy.standard = IFX_MAPI_WLAN_STD_802_11BG;
					break;
				case IFX_MAPI_WLAN_STD_802_11GN:
					wlApCfg->phy.standard = IFX_MAPI_WLAN_STD_802_11G;
					break;
				case IFX_MAPI_WLAN_STD_802_11AN:
					wlApCfg->phy.standard = IFX_MAPI_WLAN_STD_802_11A;
					break;
				default:
					break;
				}
			}
		}
		else if (gOpMode < IFX_MAPI_WLAN_STD_802_11_ALL) {
			f_isWepActive = FALSE;
			IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlApCfg->iid.cpeId,
					passed_index);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
				"passed_index: %d", passed_index);
			for (i = 0; i < g_nVap; i++) {
				/* do not check passed_index as this is the new configuration */
				if (i == passed_index) {
					continue;
				}
				if (g_wlSec[i].wlEncr == IFX_MAPI_WLAN_ENCR_WEP) {
					f_isWepActive = TRUE;
					break;
				}
			}
			if (!f_isWepActive) {
				/* if user switched freqBand, avoid illegal combinations */
				if (wlApCfg->phy.freqBand == IFX_MAPI_WLAN_2_4_GHz_Freq) {
					if ((gOpMode == IFX_MAPI_WLAN_STD_802_11N) ||
						(gOpMode == IFX_MAPI_WLAN_STD_802_11BGN) ||
						(gOpMode == IFX_MAPI_WLAN_STD_802_11GN)) {
							/* restore previous operating mode */
						wlApCfg->phy.standard = gOpMode;
					}
					else {
						wlApCfg->phy.standard = IFX_MAPI_WLAN_STD_802_11BGN;
					}
				}
				else {
					if ((gOpMode == IFX_MAPI_WLAN_STD_802_11N) ||
						(gOpMode == IFX_MAPI_WLAN_STD_802_11AN)) {
							/* restore previous operating mode */
						wlApCfg->phy.standard = gOpMode;
					}
					else {
						wlApCfg->phy.standard = IFX_MAPI_WLAN_STD_802_11AN;
					}
				}
				gOpMode = IFX_MAPI_WLAN_STD_802_11_ALL;
			}
		}
}
#endif /* #if defined (LTQ_AEI_CUST) */

		/* save given flags to in flags_local */
		flags_save = flags;
		/*
		   set the IFX_F_INT_DONT_CONFIGURE flag bit before calling apis below;
		   this is to avoid device configuration at multiple points which may be
		   inconsistent and also maintain virtual single entry point when calling
		   the below apis */
		flags |= IFX_F_INT_DONT_CONFIGURE;
		/*
		   set the IFX_F_DONT_WRITE_TO_FLASH flag bit before calling apis
		   below; this is to avoid that the device configuration is writtten
		   multiple times to the flash; it is sufficient to do this once at the
		   end of this function */
		flags |= IFX_F_DONT_WRITE_TO_FLASH;

		/*
		   stop this ap/vap before calling apis below, if the original variable
		   flags does not contain any flags, preventing this */
		if (IFX_DONT_ACTIVATE_F_NOT_SET(flags_save)) {
			cpe_id.Id = wlApCfg->iid.cpeId.Id;
			sprintf(cpe_id.secName, "%s", TAG_WLAN_MAIN);
			IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpe_id,
						 passed_index);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
				       "passed_index: %d", passed_index);
			sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, passed_index);
			LTQ_LOG_TIMESTAMP();
			system(conf_buf);
			LTQ_LOG_TIMESTAMP();
		}

		/*
		 * before calling security api, make sure iid settings are set correct,
		 * in case they are not already set from upper layer
		 */
		sprintf(wlApCfg->sec.iid.cpeId.secName, "%s", TAG_WLAN_SEC);
		sprintf(wlApCfg->sec.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
		wlApCfg->sec.iid.config_owner = wlApCfg->iid.config_owner;
		wlApCfg->sec.iid.cpeId.Id = wlApCfg->iid.cpeId.Id;
		wlApCfg->sec.iid.pcpeId.Id = wlApCfg->iid.pcpeId.Id;
		strcpy(wlApCfg->sec.iid.tr69Id, wlApCfg->iid.tr69Id);

		/*
		   in case of add and delete operation, the two functions
		   ifx_mapi_set_wlan_main_config and ifx_mapi_set_wlan_security_config
		   send notifications to TR69 stack; this must be avoided; therefore
		   ifx_mapi_set_wlan_security config is called with no additional
		   flags, e.g. the TR69 stack is notified, the latter call to
		   ifx_mapi_set_wlan_main_config will have additional flags set to
		   avoid sending another notification */
		if ((ret =
		     ifx_mapi_set_wlan_security_config(oper, &wlApCfg->sec,
						       flags | IFX_F_INT_DONT_SEND_SET_NOTIFICATION)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
				       "ifx_set_wlan_security_config has failed");
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("[%s:%d] ifx_set_wlan_security_config has failed",
			     __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		/*
		   before calling main api, make sure iid settings are set correct, in
		   case they are not already set from upper layer */
		sprintf(wlApCfg->main.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
		sprintf(wlApCfg->main.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
		wlApCfg->main.iid.config_owner = wlApCfg->iid.config_owner;
		wlApCfg->main.iid.cpeId.Id = wlApCfg->iid.cpeId.Id;
		wlApCfg->main.iid.pcpeId.Id = wlApCfg->iid.pcpeId.Id;
		strcpy(wlApCfg->main.iid.tr69Id, wlApCfg->iid.tr69Id);
		wlApCfg->main.radioCpeId = wlApCfg->phy.iid.cpeId.Id;

		/*
		   Dont send a notification to TR69 stack: notification has already
		   been sent from ifx_mapi_get_wlan_security_config; now set the flags
		   to avoid sending notification again */
		flags = IFX_SET_DONT_SEND_NOTIFICATION_FLAG(flags);
		flags = IFX_SET_DONT_CHECK_ACL_FLAG(flags);
		flags |= IFX_F_DONT_WRITE_TO_FLASH;
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
			       "oper: %d, flags: 0x%x", oper, flags);
		if ((ret =
		     ifx_mapi_set_wlan_main_config(oper, &wlApCfg->main,
						   flags | IFX_F_INT_DONT_SEND_SET_NOTIFICATION)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
				       "ifx_set_wlan_main_config has failed");
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] ifx_set_wlan_main_config has failed",
				__FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		/* call set api for wlan phy only if its modify operation */
		if (oper == IFX_OP_MOD) {
			sprintf(wlApCfg->phy.iid.cpeId.secName, "%s",
				TAG_WLAN_PHY);
			sprintf(wlApCfg->phy.iid.pcpeId.secName, "%s",
				TAG_LAN_DEVICE);
			wlApCfg->phy.iid.config_owner =
			    wlApCfg->iid.config_owner;
			wlApCfg->phy.iid.cpeId.Id = wlApCfg->main.radioCpeId;
			wlApCfg->phy.iid.pcpeId.Id = wlApCfg->iid.pcpeId.Id;
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
				       "oper: %d, flags: %d", oper, flags);
			if ((ret =
			     ifx_mapi_set_wlan_phy_config(oper, &wlApCfg->phy,
							  flags | IFX_F_INT_DONT_SEND_SET_NOTIFICATION)) !=
			    IFX_SUCCESS) {
				IFX_MAPI_DEBUG(fd,
					       "/tmp/ifxMapiSetWlanApConfig",
					       "ifx_set_wlan_phy_config has failed");
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("[%s:%d] ifx_mapi_set_wlan_phy_config has failed",
				     __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
			       "oper: %d, flags: 0x%x", oper, flags);

		/*
		   start this ap/vap if the original variable flags does not contain
		   any flags, preventing this */
		if (IFX_DONT_ACTIVATE_F_NOT_SET(flags_save)) {
			cpe_id.Id = wlApCfg->iid.cpeId.Id;
			sprintf(cpe_id.secName, "%s", TAG_WLAN_MAIN);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
				       "cpeId.secName: %s, cpeId.Id: %d",
				       cpe_id.secName, cpe_id.Id);
			IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpe_id, passed_index);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
				       "passed_index: %d", passed_index);

			/* get vendor information */
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "radioCpeId: %d",
				wlApCfg->main.radioCpeId);
			vendor = ltq_mapi_get_wlan_vendor(wlApCfg->main.radioCpeId, IFX_F_DEFAULT);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "vendor: %d", vendor);
			if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
				sprintf(conf_buf, "%s", SERVICE_WLAN_START);
			} else {
				sprintf(conf_buf, "%s %d", SERVICE_WLAN_START, passed_index);
			}

			LTQ_LOG_TIMESTAMP();
			/* passed index should be that of wlan_main instance */
			system(conf_buf);
			LTQ_LOG_TIMESTAMP();
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
			       "oper: %d, flags_save: 0x%x", oper, flags_save);
	}

	/* updating Persistent Storage, if original flags variable allows this */
	if ((ret = ifx_config_write(FILE_RC_CONF, flags_save)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
			"ifx_config_write has failed");
		goto IFX_Handler;
	}

	g_flagConfigLoaded = 0;
	/* reset flags to reload the configuration */
	g_flagPhyConfig 	= 0;
	g_flagMainConfig 	= 0;
	g_flagSecConfig 	= 0;
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "");
	system("echo 0 > /tmp/web_Phyflg &");
	system("echo 0 > /tmp/web_Mainflg &");
	system("echo 0 > /tmp/web_Secflg &");

#ifdef TR69_DEFINED
	/* notify devm regarding the set in mapi */
	if(IFX_INT_DONT_SEND_SET_NOTIFICATION_F_NOT_SET(flags) && (wlApCfg->iid.config_owner == IFX_WEB)) {
//		ifx_tr69_value_change_notify(&wlApCfg->iid);
	}
#endif

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "ret: %d", ret);
	LTQ_LOG_TIMESTAMP("Done");
	return ret;
}

#if 0
/**
   \param   oper  - type of operation (ADD, MODIFY, DELETE)

   \param

   \param   flags - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ifx_mapi_set_global_mac_control_status(uint32 operation,
				       IFX_MAPI_GlobalMacControl *
				       glblMacControl, uint32 flags)
{
	int32 ret = IFX_SUCCESS, passed_index = -1;
	char8 buf[MAX_FILELINE_LEN];

	if (operation != IFX_OP_MOD) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Only modify operation is supported",
			__FUNCTION__, __LINE__);
#endif				// IFX_LOG_DEBUG
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrlStatus",
			       "Only modify operation is supported");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	flags |= IFX_F_MODIFY;

	sprintf(glblMacControl->iid.cpeId.secName, "%s",
		TAG_WLAN_GLOBAL_MAC_CONTROL);
	sprintf(glblMacControl->iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, glblMacControl->iid.cpeId,
				 passed_index)

	    /* before config file update, stop ap/vap's, unless the acl wont take
	       effect */
	    if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
		IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
		IFX_DEACTIVATE_F_NOT_SET(flags)) {
		sprintf(buf, "%s", SERVICE_WLAN_STOP);
		LTQ_LOG_TIMESTAMP();
		system(buf);
		LTQ_LOG_TIMESTAMP();
	}

	sprintf(buf, "%s_%d_control=\"%d\"\n", PREFIX_WLAN_GLOBAL_MAC_CONTROL,
		passed_index, glblMacControl->cntrlMode);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrlStatus", "buf: %s",
		       buf);
	ret =
	    ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL, flags, 1,
			   buf);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif				// IFX_LOG_DEBUG
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrlStatus", "");
		goto IFX_Handler;
	}

   /*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* after config file update, for modify or add operation start all ap/vap */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags)) {
		sprintf(buf, "%s", SERVICE_WLAN_START);
		LTQ_LOG_TIMESTAMP();
		system(buf);
		LTQ_LOG_TIMESTAMP();
	}

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrlStatus", "ret: %d",
		       ret);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/**
   This API configures the WLAN global MAC filter

   \param   oper  - type of operation (ADD, MODIFY, DELETE)

   \param   glblMacControl - pointer to IFX_MAPI_GlobalMacControl structure

   \param   flags - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE

   \remarks - what should be interface type for each rule added ??
              for each wlan mac filter rule interface type is assumed to be wlan
            - since the object is not present in tr69 use owner as tr69 to bypass acl and notification
              otherwise it may return error
            - TSC supports configuring only 6 mac filter entries
*/
int32
ifx_mapi_set_global_mac_control(uint32 oper,
				IFX_MAPI_GlobalMacControl * glblMacControl,
				uint32 flags)
{
	int32 ret = IFX_SUCCESS, passed_index = -1, count = 0, changedCount = 0;
	char8 conf_buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	uint32 outFlag = IFX_F_DEFAULT;
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_GLOBAL_MAC_CNTRL_PARAM_COUNT],
	    *array_changed_fvp = NULL;
	IFX_ID parent_iid;

	LTQ_LOG_TIMESTAMP("Begin");

	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
	memset(array_fvp, 0x00, sizeof(array_fvp));
	memset(&parent_iid, 0, sizeof(parent_iid));

   /**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(glblMacControl)
	}

	sprintf(glblMacControl->iid.cpeId.secName, "%s",
		TAG_WLAN_GLOBAL_MAC_CONTROL);
	/* since this object is not in tr69-model */
	sprintf(glblMacControl->iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

	parent_iid.cpeId.Id = glblMacControl->iid.pcpeId.Id;
	sprintf(parent_iid.cpeId.secName, "%s",
		glblMacControl->iid.pcpeId.secName);

	glblMacControl->iid.config_owner = IFX_WEB;

   /*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY) append the flag with
	   internal flags */
	if (oper == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (oper == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
   /**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
#if 0
		IFX_VALIDATE_PTR(wlanMacControl->macAddrList)
#endif				/* #if 0 */
		    /* do simple validation of flags sucha as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
		    /* validate for no. of mac filter rules in acl table, if its 6
		       return error tsc driver can accomodate only 6 rules in acl table
		     */
		    if (IFX_ADD_F_SET(flags)) {
			MAKE_SECTION_COUNT_TAG(TAG_WLAN_GLOBAL_MAC_CONTROL,
					       conf_buf);
			if ((ret =
			     ifx_GetObjData(FILE_RC_CONF,
					    TAG_WLAN_GLOBAL_MAC_CONTROL,
					    conf_buf, IFX_F_DEFAULT, &outFlag,
					    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				IFX_MAPI_DEBUG(fd,
					       "/tmp/ifxMapiSetGlobalMacCntrl",
					       "");
				goto IFX_Handler;
			}
			if (atoi(sValue) == IFX_MAPI_WLAN_NUM_ENTRIES_ACL_TABLE) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("[%s:%d] wlan acl table can only accomodate 6 entries",
				     __FUNCTION__, __LINE__);
#endif
				IFX_MAPI_DEBUG(fd,
					       "/tmp/ifxMapiSetGlobalMacCntrl",
					       "");
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
	}

	if (IFX_ADD_F_SET(flags)) {
		/* Allocate the IID for this mac-control instance Set the parent
		   SectionName and parent IID values to NULL as there is no parent for
		   Route Entity */
		if (ifx_get_iid
		    (TAG_WLAN_GLOBAL_MAC_CONTROL, TAG_LAN_DEVICE, &parent_iid,
		     &glblMacControl->iid) != IFX_SUCCESS) {
			// if (ifx_get_IID(&glblMacControl->iid, "macAddr") != IFX_SUCCESS) {
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

   /*********************** Name Value Formation as per RC.CONF **********************/
	if (IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, 0,
					WLAN_GLOBAL_MAC_CNTRL_PARAM_COUNT,
					wlan_global_mac_cntrl_params);

		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 3,
					    (int32 *) & glblMacControl->iid.
					    cpeId.Id,
					    &glblMacControl->iid.pcpeId.Id,
					    &glblMacControl->ifType);
		sprintf(array_fvp[3].value, "%s", glblMacControl->macAddr);
		sprintf(array_fvp[4].value, "%d", glblMacControl->cntrlMode);
		passed_index = -1;
	}
	count = WLAN_GLOBAL_MAC_CNTRL_PARAM_COUNT;

	/* Get Config Index in case of modify/delete operations from PCPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_PCPEID(FILE_RC_CONF,
					  glblMacControl->iid.pcpeId,
					  passed_index)
		    // IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF,
		    // glblMacControl->iid.cpeId, passed_index)
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "passed_index: %d",
		       passed_index);

	if (ifx_get_conf_index_and_nv_pairs
	    (&glblMacControl->iid, passed_index, PREFIX_WLAN_GLOBAL_MAC_CONTROL,
	     count, array_fvp, flags) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
	/* Check ACL in case of Delete - as notification must be sent to TR69 Stack
	   TR69 does a delete from CHECK_ACL_RET function Here the changed array
	   consists of the whole parameter set for DELETE */
	if (IFX_DELETE_F_SET(flags) && IFX_INT_DONT_CHECK_ACL_F_NOT_SET(flags)) {
		CHECK_ACL_RET(glblMacControl->iid, count, array_fvp,
			      changedCount, array_changed_fvp, flags,
			      IFX_Handler)
	}

	/* before config file update, stop ap/vap's */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl",
			       "SERVICE_WLAN_STOP");
		sprintf(conf_buf, "%s", SERVICE_WLAN_STOP);
		LTQ_LOG_TIMESTAMP();
		system(conf_buf);
		LTQ_LOG_TIMESTAMP();
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
	/* this object has a object level parameter, which is stored irrespective
	   of instances. so a seperate modify operation should be done this
	   parameter if operation == IFX_OP_MOD */
	if (IFX_MODIFY_F_SET(flags)) {
		sprintf(conf_buf, "%s_control=\"%d\"\n",
			PREFIX_WLAN_GLOBAL_MAC_CONTROL,
			glblMacControl->cntrlMode);

		ret =
		    ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL,
				   flags, 1, conf_buf);

		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
			goto IFX_Handler;
		}
	}

	/* Convert the name value pair in array_fvp into string format expected by
	   rc.conf file */
	memset(conf_buf, 0x00, sizeof(conf_buf));
	form_cfgdb_buf(conf_buf, count, array_fvp);

	/* RC.CONF Configuration block */
	ret =
	    ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL, flags, 1,
			   conf_buf);

	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
		goto IFX_Handler;
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
   /*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* after config file update, for modify or add operation start all ap/vap */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags)) {
		/* \todo replace hard-coded index 0 */
//		if (g_wlPhy[0].radioEnable) {
			sprintf(conf_buf, "%s &", SERVICE_WLAN_MAC_CTRL_MODIFY);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "conf_buf: %s",
				conf_buf);
			LTQ_LOG_TIMESTAMP();
			system(conf_buf);
			LTQ_LOG_TIMESTAMP();
//		}
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
   /*********** Epilog Block **************/
	/* this will Compact the section and also update the count for both ADD and
	   DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags)) {
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL,
				      flags);
	}
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_INT_ADD_F_SET(flags)) {
		/* since this object is not in tr-98 model no need to call update_map
		   and notification here */
		/* Manipulate nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF,
					 TAG_WLAN_GLOBAL_MAC_CONTROL);
	} else if (IFX_DELETE_F_SET(flags)) {
		/* since this object is not in tr-98 model no need to call update_map
		   and notification here */
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] upgrade failed", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "ret: %d", ret);
	LTQ_LOG_TIMESTAMP("Done");
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}
#endif /* #if 0 */

/**
   This API configures the WLAN MAC filter

   \param   oper  - type of operation (ADD, MODIFY, DELETE)

   \param   wlMacControl - pointer to IFX_MAPI_WLAN_MAC_Control structure

   \param   flags - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ifx_mapi_set_wlan_mac_control(uint32 oper,
			      IFX_MAPI_WLAN_MAC_Control * wlMacControl,
			      uint32 flags)
{
	int32 ret = IFX_SUCCESS, passed_index = -1, count = 0;
	char8 conf_buf[MAX_FILELINE_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_MAC_CNTRL_PARAM_COUNT];
	IFX_ID parent_iid;

	LTQ_LOG_TIMESTAMP("Begin");

	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
	memset(array_fvp, 0x00, sizeof(array_fvp));
	memset(&parent_iid, 0, sizeof(parent_iid));

   /*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY) append the flag with
	   internal flags */
	if (oper == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (oper == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

   /**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(wlMacControl)
		    /* do simple validation of flags sucha as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

	sprintf(wlMacControl->iid.cpeId.secName, "%s", TAG_WLAN_MAC_CONTROL);
	/* since this object is not in tr69-model */
	sprintf(wlMacControl->iid.pcpeId.secName, "%s", TAG_WLAN_SEC);

	parent_iid.cpeId.Id = wlMacControl->iid.pcpeId.Id;
	sprintf(parent_iid.cpeId.secName, "%s",
		wlMacControl->iid.pcpeId.secName);

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl",
		       "parent_iid.cpeId: %s, %d", parent_iid.cpeId.secName,
		       parent_iid.cpeId.Id);

   /**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {

/*
   For the moment comment this check for RALINK
   \todo implement a check on per vap base
*/
#if !defined(CONFIG_FEATURE_IFX_WIRELESS_RALINK)
		/* validate for no. of mac filter rules in acl table, if its 6 return
		   error tsc driver can accomodate only 6 rules in acl table */
		if (IFX_ADD_F_SET(flags)) {
			IFX_MAPI_WLAN_Capability wlCaps;
			char8 sValue[MAX_FILELINE_LEN];
			uint32 outFlag = IFX_F_DEFAULT;

			MAKE_SECTION_COUNT_TAG(TAG_WLAN_MAC_CONTROL, conf_buf);
			if ((ret =
			     ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAC_CONTROL,
					    conf_buf, IFX_F_DEFAULT, &outFlag,
					    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "");
				goto IFX_Handler;
			}

			if ((ret = ifx_mapi_get_wlan_capability(&wlCaps, IFX_F_DEFAULT)) !=
			    IFX_SUCCESS) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			if (atoi(sValue) == wlCaps.numMacCntrlEntries) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("[%s:%d] wlan acl table can only accomodate %d entries",
				     __FUNCTION__, __LINE__,
				     wlCaps.numMacCntrlEntries);
#endif
				IFX_MAPI_DEBUG(fd,
					       "/tmp/ifxMapiSetWlanMacCntrl",
					       "wlan acl table can only accomodate %d entries",
					       wlCaps.numMacCntrlEntries);
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
#endif				/* #if !defined(CONFIG_FEATURE_IFX_WIRELESS_RALINK) */
	}

	if (IFX_ADD_F_SET(flags)) {
		/* Allocate the IID for this mac-control instance Set the parent
		   SectionName and parent IID values to NULL as there is no parent for
		   Route Entity */
		if (ifx_get_iid(TAG_WLAN_MAC_CONTROL, TAG_WLAN_SEC, &parent_iid,
				&wlMacControl->iid) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "");
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl",
			       "parent_iid.pcpeId: %s, %d",
			       parent_iid.pcpeId.secName, parent_iid.pcpeId.Id);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl",
			       "parent_iid.cpeId: %s, %d",
			       parent_iid.cpeId.secName, parent_iid.cpeId.Id);
	}

   /*********************** Name Value Formation as per RC.CONF **********************/
	if (IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, 0,
					WLAN_MAC_CNTRL_PARAM_COUNT,
					wlan_mac_cntrl_params);

		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 2,
					    (int32 *) & wlMacControl->iid.cpeId.
					    Id, &wlMacControl->iid.pcpeId.Id);
		sprintf(array_fvp[2].value, "%s", wlMacControl->macAddr);
		passed_index = -1;
	}
	count = WLAN_MAC_CNTRL_PARAM_COUNT;

	/* Get Config Index in case of modify/delete operations from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl",
			       "cpeId: %s: %d", wlMacControl->iid.cpeId.secName,
			       wlMacControl->iid.cpeId.Id);
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlMacControl->iid.cpeId,
					 passed_index)
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "passed_index: %d",
		       passed_index);

	if (ifx_get_conf_index_and_nv_pairs(&wlMacControl->iid, passed_index,
					    PREFIX_WLAN_MAC_CONTROL, count,
					    array_fvp, flags) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* Convert the name value pair in array_fvp into string format expected by
	   rc.conf file */
	memset(conf_buf, 0x00, sizeof(conf_buf));
	form_cfgdb_buf(conf_buf, count, array_fvp);

	/* RC.CONF Configuration block */
	ret =
	    ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_MAC_CONTROL, flags, 1,
			   conf_buf);

	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "");
		goto IFX_Handler;
	}

	if (IFX_INT_ADD_F_SET(flags) || (IFX_DELETE_F_SET(flags))) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl",
			       "parent_iid.pcpeId: %s, %d",
			       parent_iid.pcpeId.secName, parent_iid.pcpeId.Id);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl",
			       "parent_iid.cpeId: %s, %d",
			       parent_iid.cpeId.secName, parent_iid.cpeId.Id);
		/*
		   the correct index to be passed to low level script, must be obtained
		   from parent cpeId */
		IFX_GET_INDEX_FROM_PCPEID(FILE_RC_CONF, parent_iid.cpeId,
					  passed_index)
		    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl",
				   "passed_index: %d", passed_index);
	}

	/* this will Compact the section and also update the count for both ADD and
	   DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags)) {
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_WLAN_MAC_CONTROL,
					  flags);
	}

   /*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* after config file update, for modify or add operation start all ap/vap */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags)) {
		if (passed_index < 0) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl",
				       "conf_buf: %s", conf_buf);
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
//		if (g_wlPhy[g_wlMain[passed_index].radioCpeId - 1].radioEnable) {
			sprintf(conf_buf, "%s %d &", SERVICE_WLAN_MAC_CTRL_MODIFY,
				passed_index);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl",
				"conf_buf: %s", conf_buf);
			LTQ_LOG_TIMESTAMP();
			system(conf_buf);
			LTQ_LOG_TIMESTAMP();
//		}
	}

   /*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_INT_ADD_F_SET(flags)) {
		/* since this object is not in tr-98 model no need to call update_map
		   and notification here */
		/* Manipulate nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WLAN_MAC_CONTROL);
	} else if (IFX_DELETE_F_SET(flags)) {
		/* since this object is not in tr-98 model no need to call update_map
		   and notification here */
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "");
	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] upgrade failed", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "");
		goto IFX_Handler;
	}

	/* reset flag and count to reload config */
	g_flagMacControlAllConfig = 0;
	g_nMacControlAll = 0;

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "ret: %d", ret);
	LTQ_LOG_TIMESTAMP("Done");
	return ret;
}

/**
   \param   oper  - type of operation (ADD, MODIFY, DELETE)

   \param   wlMacControl - pointer to IFX_MAPI_WLAN_MAC_Control structure

   \param   flags - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ifx_mapi_set_wlan_mac_control_status(uint32 mainCpeId, uint32 oper,
				     uint32 flags)
{
	int32 ret = IFX_SUCCESS, passed_index = -1;
	char8 conf_buf[MAX_FILELINE_LEN];
	CPE_ID cpe_id;

	LTQ_LOG_TIMESTAMP("Begin");

   /*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY) append the flag with
	   internal flags */
	if (oper != IFX_OP_MOD) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrlStatus", "");
   /*********************** Name Value Formation as per RC.CONF **********************/

	/* Get Config Index in case of modify/delete operations from CPEID */
	if (IFX_MODIFY_F_SET(flags)) {
		sprintf(cpe_id.secName, "%s", TAG_WLAN_SEC);
		cpe_id.Id = mainCpeId;
		/* get index from cpeid first */
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpe_id, passed_index)
		    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrlStatus",
				   "passed_index: %d", passed_index);
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrlStatus", "");
   /*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* after config file update, for modify or add operation start all ap/vap */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags)) {
//		if (g_wlPhy[g_wlMain[passed_index].radioCpeId - 1].radioEnable) {
			sprintf(conf_buf, "%s %d", SERVICE_WLAN_MAC_CTRL_MODIFY,
				passed_index);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrlStatus",
				"conf_buf: %s", conf_buf);
			LTQ_LOG_TIMESTAMP();
			system(conf_buf);
			LTQ_LOG_TIMESTAMP();
//		}
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrlStatus", "");
   /*********** Epilog Block **************/
	/* this will Compact the section and also update the count for both ADD and
	   DELETE */

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrlStatus", "ret: %d", ret);
	LTQ_LOG_TIMESTAMP("Done");
	if (ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}

/**
   this api reads wlan capabilities from /tmp/wlan_caps, which was generated
   during bootup

   \param   wlCaps - pointer to Capability structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ifx_mapi_get_wlan_capability(IFX_MAPI_WLAN_Capability * wlCaps, uint32 flags)
{
	int32 ret = IFX_SUCCESS, i = 0, f_CapValid = TRUE;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_DATA_LEN], sValueTmp[MAX_DATA_LEN];
	char8 *pTmpStr = NULL, *pTmpStr2 = NULL, *pTmpStr3 = NULL;
	int32	vendor = LTQ_MAPI_WLAN_VENDOR_NONE;

	LTQ_LOG_TIMESTAMP("Begin");

	if (g_flagCapabilities) {
		/* restore from global variable */
		memcpy(wlCaps, &g_wlCaps[0], sizeof(IFX_MAPI_WLAN_Capability));
		goto IFX_Handler;
	}
	else {
		memset(&g_wlCaps[0], 0xFF, sizeof(IFX_MAPI_WLAN_Capability));
	}

	NULL_TERMINATE(buf, 0x00, sizeof(buf));

	memset(sValue, 0x00, sizeof(sValue));
	/* capability of first radio (hard-code AP index to "0" */
	sprintf(buf, "%s 0", SERVICE_WLAN_GET_DEV_CAP);

	if (ifx_GetCfgData((char8 *) buf, NULL, "-1", sValue) == 0) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s",
		       sValue);
	/* save buffer in sValueTmp */
	strcpy(sValueTmp, sValue);

	/* get vendor information */
	if ((pTmpStr = strstr(sValue, "vendor")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		strcpy(wlCaps->vendor, pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "vendor: %s", wlCaps->vendor);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get supported standards */
	if ((pTmpStr = strstr(sValue, "standard")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		i = 0;
		pTmpStr3 = strtok(pTmpStr2, ",");
		while (pTmpStr3 != NULL) {
			wlCaps->std[i] = atoi(pTmpStr3);
			/* check if this is a valid standard */
			if (wlCaps->std[i] >= IFX_MAPI_WLAN_MAX_STD) {
				IFX_MAPI_DEBUG(fd,
					       "/tmp/ifxMapiGetWlanCapability",
					       "wlCaps->std[%d] = %d; IFX_MAPI_WLAN_MAX_STD = %d",
					       i, wlCaps->std[i],
					       IFX_MAPI_WLAN_MAX_STD);
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			i++;
			pTmpStr3 = strtok(NULL, ",");
		}
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "Not found in capabilities: \nsValue: %s",
			       sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get supported frequency band */
	if ((pTmpStr = strstr(sValue, "freq")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->freq = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "freq: %d",
			       wlCaps->freq);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get supported power levels */
	if ((pTmpStr = strstr(sValue, "powerLvl")) != NULL) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "pTmpStr: %s", pTmpStr);
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		i = 0;
		/* now parse the comma separated list */
		pTmpStr3 = strtok(pTmpStr2, ",");
		while ((pTmpStr3 != NULL) && (i < IFX_MAPI_MAX_POWER_LEVELS)) {
			wlCaps->powerLevelsSupported[i] = atoi(pTmpStr3);
			/* check if this is a valid value */
			if (wlCaps->powerLevelsSupported[i] > 100) {
				IFX_MAPI_DEBUG(fd,
					       "/tmp/ifxMapiGetWlanCapability",
					       "");
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			i++;
			pTmpStr3 = strtok(NULL, ",");
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
				       "wlCaps->powerLevelsSupported[%d] = %d",
				       i - 1,
				       wlCaps->powerLevelsSupported[i - 1]);
		}
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get supported security */
	if ((pTmpStr = strstr(sValue, "security")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->secType = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "secType: %d", wlCaps->secType);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get radius support */
	if ((pTmpStr = strstr(sValue, "radius")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->radiusSupport = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "radiusSupport: %d", wlCaps->radiusSupport);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get WMM support */
	if ((pTmpStr = strstr(sValue, "WMM")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->WMMcapable = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "WMMcapable: %d", wlCaps->WMMcapable);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get UAPSD support */
	if ((pTmpStr = strstr(sValue, "UAPSD")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->UAPSDcapable = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "UAPSDcapable: %d", wlCaps->UAPSDcapable);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get WPS support */
	if ((pTmpStr = strstr(sValue, "WPS")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->WPScapable = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "WPScapable: %d", wlCaps->WPScapable);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get WPS config methods if WPS is supported */
	if ((pTmpStr = strstr(sValue, "WPS_CfgMethods")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		/* supported methods are a comma separated list of integer values */
		i = 0;
		pTmpStr2 = strtok(NULL, ",");
		while (pTmpStr2 != NULL) {
			wlCaps->WPSMthdsArray[i++] = atoi(pTmpStr2);
			pTmpStr2 = strtok(NULL, ",");
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
				       "wlCaps->WPSMthdsArray[%d] = %d", i - 1,
				       wlCaps->WPSMthdsArray[i - 1]);
		}
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get WDS support */
	if ((pTmpStr = strstr(sValue, "WDS")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->WDScapable = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "WDScapable: %d", wlCaps->WDScapable);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get WDS repetition count if WDS is supported */
	if ((pTmpStr = strstr(sValue, "WDS_RepCount")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->WDSRepsCount = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "WDSRepsCount: %d", wlCaps->WDSRepsCount);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get max. number of supported VAP */
	if ((pTmpStr = strstr(sValue, "maxVAP")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		if (atoi(pTmpStr2) == 0)
			f_CapValid = FALSE;
		wlCaps->maxVAPSupported = ((atoi(pTmpStr2) > 0) ? atoi(pTmpStr2) : 1);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability","maxVAPSupported: %d",
			wlCaps->maxVAPSupported);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get max. number of clients per VAP */
	if ((pTmpStr = strstr(sValue, "maxClientsPerVAP")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		if (atoi(pTmpStr2) == 0)
			f_CapValid = FALSE;
		wlCaps->maxClientsPerVAP = ((atoi(pTmpStr2) > 0) ? atoi(pTmpStr2) : 32);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "maxClientsPerVAP: %d",
			       wlCaps->maxClientsPerVAP);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "sValue: %s", sValue);

	/* get vendor information, radioCpeId hard-coded to 1 */
	vendor = ltq_mapi_get_wlan_vendor(1, IFX_F_DEFAULT);
	if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
		/* restore sValue buffer from sValueTmp */
		strcpy(sValue, sValueTmp);
		/* get max. number of clients per Radio */
		if ((pTmpStr = strstr(sValue, "maxWlanClients")) != NULL) {
			pTmpStr2 = strtok(pTmpStr, "\"");
			if (pTmpStr2 == NULL) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "");
				wlCaps->maxWlanClients = 0;
			}
			else {
				pTmpStr2 = strtok(NULL, "\"");
				if (pTmpStr2 == NULL) {
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "");
					wlCaps->maxWlanClients = 0;
				}
				else {
					wlCaps->maxWlanClients = atoi(pTmpStr2);
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
							   "maxWlanClients: %d",
							   wlCaps->maxWlanClients);
				}
			}
		}
		else {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
					   "sValue: %s", sValue);
			wlCaps->maxWlanClients = wlCaps->maxClientsPerVAP;
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
					   "maxWlanClients: %d",
					   wlCaps->maxWlanClients);
		}
	}

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get MAC filtering support */
	if ((pTmpStr = strstr(sValue, "macAddrCntrlPerVAP")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->macCntrlPerVAP = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "macCntrlPerVAP: %d", wlCaps->macCntrlPerVAP);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get MAC filtering support */
	if ((pTmpStr = strstr(sValue, "numMACCntrlEntries")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		if (atoi(pTmpStr2) == 0)
			f_CapValid = FALSE;
		wlCaps->numMacCntrlEntries = atoi(pTmpStr2);
		if ((wlCaps->numMacCntrlEntries > LTQ_MAX_NUM_MAC_FILTER_ENTRIES) ||
			(wlCaps->numMacCntrlEntries == 0))
			wlCaps->numMacCntrlEntries = LTQ_MAX_NUM_MAC_FILTER_ENTRIES;

		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "numMacCntrlEntries: %d",
			       wlCaps->numMacCntrlEntries);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get number of RX antennas */
	if ((pTmpStr = strstr(sValue, "numRxAntenna")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->numRxAntns = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "numRxAntenna: %d", wlCaps->numRxAntns);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get number of TX antennas */
	if ((pTmpStr = strstr(sValue, "numTxAntenna")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->numTxAntns = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "numTxAntenna: %d", wlCaps->numTxAntns);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get wide channel (40MHz) support */
	if ((pTmpStr = strstr(sValue, "wideChanSupport")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->wideChanSupport = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "wideChanSupport: %d", wlCaps->wideChanSupport);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get MCS range */
	if ((pTmpStr = strstr(sValue, "MCSrange")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->mcsRange = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "MCSrange: %d", wlCaps->mcsRange);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get A-MPDU support */
	if ((pTmpStr = strstr(sValue, "AMPDUsupport")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->ampduSupport = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "AMPDUsupport: %d", wlCaps->ampduSupport);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get A-MSDU support */
	if ((pTmpStr = strstr(sValue, "AMSDUsupport")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->amsduSupport = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "AMSDUsupport: %d", wlCaps->amsduSupport);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
			       "sValue: %s", sValue);

	if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
		/* restore sValue buffer from sValueTmp */
		strcpy(sValue, sValueTmp);
		/* is capability complete? */
		if ((pTmpStr = strstr(sValue, "wlanInitIncomplete")) != NULL) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
				"sValue: %s", sValue);
			f_CapValid = FALSE;
		}
	}

	if (f_CapValid) {
		wlCaps->wlanCapValid = TRUE;
		g_flagCapabilities = 1;
	} else {
		wlCaps->wlanCapValid = FALSE;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability",
		"wlanCapValid: %d, g_flagCapabilities: %d",
		wlCaps->wlanCapValid, g_flagCapabilities);

	/* store in global variable for later usage */
	memcpy(&g_wlCaps[0], wlCaps, sizeof(IFX_MAPI_WLAN_Capability));

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "ret: %d", ret);
	LTQ_LOG_TIMESTAMP("Done");
	return ret;
}

#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
/**
   this api reads secondary wlan capabilities from /tmp/wlan_caps, which was generated
   during bootup

   \param   wlCaps - pointer to Capability structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ifx_mapi_get_wlan_sec_capability(IFX_MAPI_WLAN_Capability * wlCaps,
				 uint32 flags)
{
	int32 ret = IFX_SUCCESS, i = 0, f_CapValid = TRUE;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_DATA_LEN], sValueTmp[MAX_DATA_LEN];
	char8 *pTmpStr = NULL, *pTmpStr2 = NULL, *pTmpStr3 = NULL;
	int32	vendor = LTQ_MAPI_WLAN_VENDOR_NONE;

	LTQ_LOG_TIMESTAMP("Begin");

	if (g_flagCapabilitiesSec) {
		/* restore from global variable */
		memcpy(wlCaps, &g_wlCaps[1], sizeof(IFX_MAPI_WLAN_Capability));
		goto IFX_Handler;
	}
	else {
		memset(&g_wlCaps[1], 0xFF, sizeof(IFX_MAPI_WLAN_Capability));
	}
	NULL_TERMINATE(buf, 0x00, sizeof(buf));

	memset(sValue, 0x00, sizeof(sValue));
	/* capability of second radio (hard-code AP index to "1" */
	sprintf(buf, "%s 1", SERVICE_WLAN_GET_DEV_CAP);

	if (ifx_GetCfgData((char8 *) buf, NULL, "-1", sValue) == 0) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s",
		       sValue);
	/* save buffer in sValueTmp */
	strcpy(sValueTmp, sValue);

	/* get vendor information */
	if ((pTmpStr = strstr(sValue, "vendor")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		strcpy(wlCaps->vendor, pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "vendor: %s", wlCaps->vendor);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get supported standards */
	if ((pTmpStr = strstr(sValue, "standard")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		i = 0;
		pTmpStr3 = strtok(pTmpStr2, ",");
		while (pTmpStr3 != NULL) {
			wlCaps->std[i] = atoi(pTmpStr3);
			/* check if this is a valid standard */
			if (wlCaps->std[i] >= IFX_MAPI_WLAN_MAX_STD) {
				IFX_MAPI_DEBUG(fd,
					       "/tmp/ifxMapiGetWlanSecCapability",
					       "wlCaps->std[%d] = %d; IFX_MAPI_WLAN_MAX_STD = %d",
					       i, wlCaps->std[i],
					       IFX_MAPI_WLAN_MAX_STD);
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			i++;
			pTmpStr3 = strtok(NULL, ",");
		}
	} else {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", 
			"Not found in capabilities: \nsValue: %s", sValue);
	}

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get supported frequency band */
	if ((pTmpStr = strstr(sValue, "freq")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->freq = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "freq: %d", wlCaps->freq);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get supported power levels */
	if ((pTmpStr = strstr(sValue, "powerLvl")) != NULL) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "pTmpStr: %s", pTmpStr);
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		i = 0;
		/* now parse the comma separated list */
		pTmpStr3 = strtok(pTmpStr2, ",");

		while ((pTmpStr3 != NULL) && (i < IFX_MAPI_MAX_POWER_LEVELS)) {
			wlCaps->powerLevelsSupported[i] = atoi(pTmpStr3);
			/* check if this is a valid value */
			if (wlCaps->powerLevelsSupported[i] > 100) {
				IFX_MAPI_DEBUG(fd,
					       "/tmp/ifxMapiGetWlanSecCapability",
					       "");
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			i++;
			pTmpStr3 = strtok(NULL, ",");
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
				       "wlCaps->powerLevelsSupported[%d] = %d",
				       i - 1,
				       wlCaps->powerLevelsSupported[i - 1]);
		}
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get supported security */
	if ((pTmpStr = strstr(sValue, "security")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->secType = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "secType: %d", wlCaps->secType);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get radius support */
	if ((pTmpStr = strstr(sValue, "radius")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->radiusSupport = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "radiusSupport: %d", wlCaps->radiusSupport);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get WMM support */
	if ((pTmpStr = strstr(sValue, "WMM")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->WMMcapable = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "WMMcapable: %d", wlCaps->WMMcapable);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get UAPSD support */
	if ((pTmpStr = strstr(sValue, "UAPSD")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->UAPSDcapable = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "UAPSDcapable: %d", wlCaps->UAPSDcapable);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get WPS support */
	if ((pTmpStr = strstr(sValue, "WPS")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->WPScapable = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "WPScapable: %d", wlCaps->WPScapable);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get WPS config methods if WPS is supported */
	if ((pTmpStr = strstr(sValue, "WPS_CfgMethods")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		/* supported methods are a comma separated list of integer values */
		i = 0;
		pTmpStr2 = strtok(NULL, ",");
		while (pTmpStr2 != NULL) {
			wlCaps->WPSMthdsArray[i++] = atoi(pTmpStr2);
			pTmpStr2 = strtok(NULL, ",");
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
				       "wlCaps->WPSMthdsArray[%d] = %d", i - 1,
				       wlCaps->WPSMthdsArray[i - 1]);
		}
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get WDS support */
	if ((pTmpStr = strstr(sValue, "WDS")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->WDScapable = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "WDScapable: %d", wlCaps->WDScapable);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get WDS repetition count if WDS is supported */
	if ((pTmpStr = strstr(sValue, "WDS_RepCount")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->WDSRepsCount = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "WDSRepsCount: %d", wlCaps->WDSRepsCount);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get max. number of supported VAP */
	if ((pTmpStr = strstr(sValue, "maxVAP")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		if (atoi(pTmpStr2) == 0)
			f_CapValid = FALSE;
		wlCaps->maxVAPSupported = ((atoi(pTmpStr2) > 0) ? atoi(pTmpStr2) : 1);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "maxVAPSupported: %d", wlCaps->maxVAPSupported);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get max. number of clients per VAP */
	if ((pTmpStr = strstr(sValue, "maxClientsPerVAP")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		if (atoi(pTmpStr2) == 0)
			f_CapValid = FALSE;
		wlCaps->maxClientsPerVAP = ((atoi(pTmpStr2) > 0) ? atoi(pTmpStr2) : 32);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "maxClientsPerVAP: %d",
			       wlCaps->maxClientsPerVAP);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "sValue: %s", sValue);

	/* get vendor information, radioCpeId hard-coded to 1 */
	vendor = ltq_mapi_get_wlan_vendor(2, IFX_F_DEFAULT);
	if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
		/* restore sValue buffer from sValueTmp */
		strcpy(sValue, sValueTmp);
		/* get max. number of clients per Radio */
		if ((pTmpStr = strstr(sValue, "maxWlanClients")) != NULL) {
			pTmpStr2 = strtok(pTmpStr, "\"");
			if (pTmpStr2 == NULL) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "");
				wlCaps->maxWlanClients = 0;
			}
			else {
				pTmpStr2 = strtok(NULL, "\"");
				if (pTmpStr2 == NULL) {
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "");
					wlCaps->maxWlanClients = 0;
				}
				else {
					wlCaps->maxWlanClients = atoi(pTmpStr2);
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
							   "maxWlanClients: %d",
							   wlCaps->maxWlanClients);
				}
			}
		}
		else {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
					   "sValue: %s", sValue);
			wlCaps->maxWlanClients = wlCaps->maxClientsPerVAP;
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
					   "maxWlanClients: %d",
					   wlCaps->maxWlanClients);
		}
	}

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get MAC filtering support */
	if ((pTmpStr = strstr(sValue, "macAddrCntrlPerVAP")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->macCntrlPerVAP = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "macCntrlPerVAP: %d", wlCaps->macCntrlPerVAP);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get MAC filtering support */
	if ((pTmpStr = strstr(sValue, "numMACCntrlEntries")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		if (atoi(pTmpStr2) == 0)
			f_CapValid = FALSE;
		wlCaps->numMacCntrlEntries = atoi(pTmpStr2);
		if ((wlCaps->numMacCntrlEntries > LTQ_MAX_NUM_MAC_FILTER_ENTRIES) ||
			(wlCaps->numMacCntrlEntries == 0))
			wlCaps->numMacCntrlEntries = LTQ_MAX_NUM_MAC_FILTER_ENTRIES;
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "numMacCntrlEntries: %d",
			       wlCaps->numMacCntrlEntries);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get number of RX antennas */
	if ((pTmpStr = strstr(sValue, "numRxAntenna")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->numRxAntns = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "numRxAntenna: %d", wlCaps->numRxAntns);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get number of TX antennas */
	if ((pTmpStr = strstr(sValue, "numTxAntenna")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->numTxAntns = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "numTxAntenna: %d", wlCaps->numTxAntns);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get wide channel (40MHz) support */
	if ((pTmpStr = strstr(sValue, "wideChanSupport")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->wideChanSupport = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "wideChanSupport: %d", wlCaps->wideChanSupport);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get MCS range */
	if ((pTmpStr = strstr(sValue, "MCSrange")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->mcsRange = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "MCSrange: %d", wlCaps->mcsRange);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get A-MPDU support */
	if ((pTmpStr = strstr(sValue, "AMPDUsupport")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->ampduSupport = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "AMPDUsupport: %d", wlCaps->ampduSupport);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get A-MSDU support */
	if ((pTmpStr = strstr(sValue, "AMSDUsupport")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlCaps->amsduSupport = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "AMSDUsupport: %d", wlCaps->amsduSupport);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
			       "sValue: %s", sValue);

	if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
		/* restore sValue buffer from sValueTmp */
		strcpy(sValue, sValueTmp);
		/* is capability complete? */
		if ((pTmpStr = strstr(sValue, "wlanInitIncomplete")) != NULL) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
				"sValue: %s", sValue);
			f_CapValid = FALSE;
		}
	}

	if (f_CapValid) {
		wlCaps->wlanCapValid = TRUE;
		g_flagCapabilitiesSec = 1;
	} else {
		wlCaps->wlanCapValid = FALSE;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability",
		"wlanCapValid: %d", wlCaps->wlanCapValid);
	/* store in global variable for later usage */
	memcpy(&g_wlCaps[1], wlCaps, sizeof(IFX_MAPI_WLAN_Capability));

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "ret: %d", ret);
	LTQ_LOG_TIMESTAMP("Done");
	return ret;
}
#endif				// CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS

/**
   This api reads the count, gets the complete wlan_phy object and saves
   the configuration to wlPhyCfg

   \param   numEntries  -

   \param   wlPhyCfg    - pointer to IFX_MAPI_WLAN_PhyCfg structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ifx_mapi_get_all_wlan_phy_config(uint32 * numEntries,
				 IFX_MAPI_WLAN_PhyCfg ** wlPhyCfg, uint32 flags)
{
	int32 ret = IFX_SUCCESS, nCount = 0, i = 0, nParamCount = 0;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	char8 mapi_flg=0, *sWlanPhyObject = NULL;
	uint32 outFlag = IFX_F_DEFAULT;
	FILE *fptr = NULL;
	IFX_NAME_VALUE_PAIR array_fvp[LTQ_MAX_NUM_RADIO*WLAN_PHY_PARAM_COUNT];
	IFX_NAME_VALUE_PAIR array_fvp_coc[LTQ_MAX_NUM_RADIO*WLAN_PHY_AUTO_COC_PARAM_COUNT];
	LTQ_MAPI_WLAN_Vendor	vendor = LTQ_MAPI_WLAN_VENDOR_NONE;

	LTQ_LOG_TIMESTAMP("Begin");

	MAKE_SECTION_COUNT_TAG(TAG_WLAN_PHY, buf);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_PHY,
				  buf, flags, &outFlag,
				  sValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanPhyConfig", "");
		goto IFX_Handler;
	}

	nCount = atoi(sValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanPhyConfig", "nCount: %d", nCount);
	if (nCount <= 0) {
		*numEntries = 0;
		*wlPhyCfg = NULL;
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanPhyConfig", "");
		goto IFX_Handler;
	}

	*wlPhyCfg = NULL;
	if (nCount <= LTQ_MAX_NUM_RADIO) {
		IFX_MEM_ALLOC((*wlPhyCfg), IFX_MAPI_WLAN_PhyCfg *, nCount,
			      sizeof(IFX_MAPI_WLAN_PhyCfg))
	} else {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanPhyConfig", "");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	// to synchronize between web and tr069/UPnP/etc. at the mapi level
	fptr = fopen("/tmp/web_Phyflg","r+");
	if(fptr) {
		mapi_flg=fgetc(fptr);
		fclose(fptr);
	}

	if (IFX_RESET_WEB_CFG_F_SET(flags)) {
		if ((mapi_flg == '0') || (mapi_flg == '2'))
			g_flagPhyConfig = 0;
	}
	else {
		if ((mapi_flg == '0') || (mapi_flg == '1'))
			g_flagPhyConfig = 0;
	}

	/* return immediately if config is already loaded */
	if (g_flagPhyConfig) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanPhyConfig", "");
		memcpy(*wlPhyCfg, g_wlPhy, sizeof(IFX_MAPI_WLAN_PhyCfg) * nCount);
		*numEntries = nCount;
		goto IFX_Handler;
	}
	else {
		/* initialize all structures */
		for (i = 0; i < LTQ_MAX_NUM_RADIO; i++) {
			memset(&g_wlPhy[i], 0, sizeof(IFX_MAPI_WLAN_PhyCfg));

			/* wlan phy structure needs some initial values */
			sprintf(g_wlPhy[i].iid.cpeId.secName, "%s", TAG_WLAN_PHY);
			sprintf(g_wlPhy[i].iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
			g_wlPhy[i].iid.cpeId.Id = i+1;
		}
	}

	sprintf(buf, "%s_", PREFIX_WLAN_PHY);
	if ((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_PHY, buf, IFX_F_DEFAULT,
		&sWlanPhyObject)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanPhyConfig", "buf: %s, "
			"flags: 0x%x", buf, flags);
		goto IFX_Handler;
	}

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sWlanPhyObject, &nParamCount, array_fvp);
	IFX_MEM_FREE(sWlanPhyObject);

	for (i = 0; i < nCount; i++) {
		sprintf((*wlPhyCfg + i)->iid.cpeId.secName, "%s", TAG_WLAN_PHY);
		sprintf((*wlPhyCfg + i)->iid.pcpeId.secName, "%s", TAG_LAN_MAIN);
		(*wlPhyCfg + i)->iid.cpeId.Id 	= atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT].value);
		(*wlPhyCfg + i)->iid.pcpeId.Id 	= atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 1].value);
		(*wlPhyCfg + i)->standard 		= atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 2].value);
		snprintf((*wlPhyCfg + i)->country, sizeof((*wlPhyCfg + i)->country),
				"%s", array_fvp[i * WLAN_PHY_PARAM_COUNT +3].value);
		(*wlPhyCfg + i)->usageEnv = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 4].value);
		(*wlPhyCfg + i)->freqBand = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 5].value);
		(*wlPhyCfg + i)->channelNo = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 6].value);
		(*wlPhyCfg + i)->autoChannelEna = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 7].value);
		(*wlPhyCfg + i)->beaconTxEna = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 8].value);
		(*wlPhyCfg + i)->beaconIntvl = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 9].value);
		(*wlPhyCfg + i)->dtimInt = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 10].value);
		(*wlPhyCfg + i)->rts = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 11].value);
		(*wlPhyCfg + i)->fts = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 12].value);
		(*wlPhyCfg + i)->powerLvl = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 13].value);
		(*wlPhyCfg + i)->radioEnable = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 14].value);
		(*wlPhyCfg + i)->autoRateFallBackEna = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 15].value);
		(*wlPhyCfg + i)->staticRate = atof(array_fvp[i * WLAN_PHY_PARAM_COUNT + 16].value);
		(*wlPhyCfg + i)->preamble = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 17].value);
		(*wlPhyCfg + i)->phy11N.chanBW = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 18].value);
		(*wlPhyCfg + i)->phy11N.extChPos = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 19].value);
		(*wlPhyCfg + i)->phy11N.guardIntvl = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 20].value);
		(*wlPhyCfg + i)->phy11N.mcs = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 21].value);
		(*wlPhyCfg + i)->phy11N.diversity.diversityEna = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 22].value);
		(*wlPhyCfg + i)->phy11N.diversity.diversityDir = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 23].value);
		(*wlPhyCfg + i)->phy11N.diversity.antenna = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 24].value);
		(*wlPhyCfg + i)->phy11N.rxStbc = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 25].value);
		(*wlPhyCfg + i)->phy11N.baWinSize = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 26].value);
		(*wlPhyCfg + i)->phy11N.aggr.ampduEna = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 27].value);
		(*wlPhyCfg + i)->phy11N.aggr.ampduDir = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 28].value);
		(*wlPhyCfg + i)->phy11N.aggr.ampduLen = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 29].value);
		(*wlPhyCfg + i)->phy11N.aggr.ampduFrmsDensity = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 30].value);
		(*wlPhyCfg + i)->phy11N.aggr.amsduEna = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 31].value);
		(*wlPhyCfg + i)->phy11N.aggr.amsduDir = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 32].value);
		(*wlPhyCfg + i)->phy11N.aggr.amsduLen = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 33].value);

		/* get vendor information */
		vendor = ltq_mapi_get_wlan_vendor((*wlPhyCfg + i)->iid.cpeId.Id, IFX_F_DEFAULT);
		if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			(*wlPhyCfg + i)->radarEna = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 34].value);
			(*wlPhyCfg + i)->phy11N.ldpcEna = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 35].value);
			(*wlPhyCfg + i)->beamForm = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 36].value);
			(*wlPhyCfg + i)->mc2ucEna = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 37].value);
			(*wlPhyCfg + i)->boostMode = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 38].value);
		}

		(*wlPhyCfg + i)->phy11N.twentyFourtyCoex = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 39].value);
		(*wlPhyCfg + i)->phy11N.fourtyMHzIntolerant = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 40].value);
		(*wlPhyCfg + i)->phy11N.transDelayFactor = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 41].value);
		(*wlPhyCfg + i)->phy11N.obssScan = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 42].value);
		(*wlPhyCfg + i)->phy11N.twentyFortyCoexForceApParams = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 43].value);
		(*wlPhyCfg + i)->netModeClass = atoi(array_fvp[i * WLAN_PHY_PARAM_COUNT + 44].value);
	}
	*numEntries = nCount;
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanPhyConfig", "numEntries: %d",
		*numEntries);

	sprintf(buf, "%s_", PREFIX_WLAN_PHY_AUTO_COC);
	if ((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_PHY_AUTO_COC, buf,
		IFX_F_DEFAULT, &sWlanPhyObject)) != IFX_SUCCESS)
		goto IFX_Handler;

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp_coc, 0x00, sizeof(array_fvp_coc));
	form_array_fvp_from_cfgdb_buf(sWlanPhyObject, &nParamCount, array_fvp_coc);
	IFX_MEM_FREE(sWlanPhyObject);

	for (i = 0; i < nCount; i++) {
		sprintf((*wlPhyCfg + i)->phyAutoCoC.iid.cpeId.secName, "%s", TAG_WLAN_PHY_AUTO_COC);
		sprintf((*wlPhyCfg + i)->phyAutoCoC.iid.pcpeId.secName, "%s", TAG_WLAN_PHY);
		(*wlPhyCfg + i)->phyAutoCoC.iid.cpeId.Id 		=
			atoi(array_fvp_coc[i * WLAN_PHY_AUTO_COC_PARAM_COUNT].value);
		(*wlPhyCfg + i)->phyAutoCoC.iid.pcpeId.Id 		=
			atoi(array_fvp_coc[i * WLAN_PHY_AUTO_COC_PARAM_COUNT + 1].value);
		(*wlPhyCfg + i)->phyAutoCoC.autoCocEnable		=
			atoi(array_fvp_coc[i * WLAN_PHY_AUTO_COC_PARAM_COUNT + 2].value);
		(*wlPhyCfg + i)->phyAutoCoC.prevAutoCocEnable	=
			atoi(array_fvp_coc[i * WLAN_PHY_AUTO_COC_PARAM_COUNT + 3].value);
		(*wlPhyCfg + i)->phyAutoCoC.nAntennas			=
			atoi(array_fvp_coc[i * WLAN_PHY_AUTO_COC_PARAM_COUNT + 4].value);
		(*wlPhyCfg + i)->phyAutoCoC.nPrevAntennas		=
			atoi(array_fvp_coc[i * WLAN_PHY_AUTO_COC_PARAM_COUNT + 5].value);
		(*wlPhyCfg + i)->phyAutoCoC.timerIntval_1x1		=
			atoi(array_fvp_coc[i * WLAN_PHY_AUTO_COC_PARAM_COUNT + 6].value);
		(*wlPhyCfg + i)->phyAutoCoC.timerIntval_2x2		=
			atoi(array_fvp_coc[i * WLAN_PHY_AUTO_COC_PARAM_COUNT + 7].value);
		(*wlPhyCfg + i)->phyAutoCoC.timerIntval_3x3		=
			atoi(array_fvp_coc[i * WLAN_PHY_AUTO_COC_PARAM_COUNT + 8].value);
		(*wlPhyCfg + i)->phyAutoCoC.highLim_1x1			=
			atoi(array_fvp_coc[i * WLAN_PHY_AUTO_COC_PARAM_COUNT + 9].value);
		(*wlPhyCfg + i)->phyAutoCoC.lowLim_2x2			=
			atoi(array_fvp_coc[i * WLAN_PHY_AUTO_COC_PARAM_COUNT + 10].value);
		(*wlPhyCfg + i)->phyAutoCoC.highLim_2x2			=
			atoi(array_fvp_coc[i * WLAN_PHY_AUTO_COC_PARAM_COUNT + 11].value);
		(*wlPhyCfg + i)->phyAutoCoC.lowLim_3x3			=
			atoi(array_fvp_coc[i * WLAN_PHY_AUTO_COC_PARAM_COUNT + 12].value);
	}

	for (i = 0; i < nCount; i++) {
		sprintf((*wlPhyCfg + i)->wlVendorWaveCfg.iid.cpeId.secName, "%s", TAG_WLAN_VENDOR_WAVE);
		sprintf((*wlPhyCfg + i)->wlVendorWaveCfg.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
		(*wlPhyCfg + i)->wlVendorWaveCfg.iid.cpeId.Id = (*wlPhyCfg + i)->iid.cpeId.Id;
		if ((ret = ltq_mapi_get_wlan_vendor_wave_cfg(&(*wlPhyCfg + i)->wlVendorWaveCfg,
			IFX_F_DEFAULT))	!= IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif				/* #ifdef IFX_LOG_DEBUG */
			goto IFX_Handler;
		}
	}

	/* store in global variable for later usage */
	memcpy(g_wlPhy, *wlPhyCfg, sizeof(IFX_MAPI_WLAN_PhyCfg) * nCount);
	g_flagPhyConfig = 1;
	if (IFX_RESET_WEB_CFG_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanPhyConfig", "");
		if (mapi_flg == '0')
			system("echo 1 > /tmp/web_Phyflg &");
		else if (mapi_flg == '2')
			system("echo 3 > /tmp/web_Phyflg &");
		else
			system("echo 1 > /tmp/web_Phyflg &");
	}
	else {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanPhyConfig", "");
		if (mapi_flg == '0')
			system("echo 2 > /tmp/web_Phyflg &");
		else if (mapi_flg == '1')
			system("echo 3 > /tmp/web_Phyflg &");
		else
			system("echo 2 > /tmp/web_Phyflg &");
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanPhyConfig", "ret: %d", ret);
	LTQ_LOG_TIMESTAMP("Done");
	return ret;
}

/**
   This api reads wlan phy parameters (such as country, channel no.) from
   rc.conf and returns them in wlan_phy

   \param   wlan_phy - pointer to Phy config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ifx_mapi_get_wlan_phy_config(IFX_MAPI_WLAN_PhyCfg * wlan_phy, uint32 flags)
{
	int32 ret = IFX_SUCCESS;
	
	LTQ_LOG_TIMESTAMP("Begin");

	if ((ret = ifx_mapi_get_wlan_static_phy_config(wlan_phy, flags)) !=
		IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPhyConfig", "");
		goto IFX_Handler;
	}

	/* now get the dynamic info */
	if (wlan_phy->iid.config_owner == IFX_WEB) {
		if ((ret = ifx_mapi_get_wlan_dyn_phy_config(wlan_phy, flags)) !=
			IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPhyConfig", "");
			goto IFX_Handler;
		}
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPhyConfig", "ret: %d", ret);
	LTQ_LOG_TIMESTAMP("Done");
	return ret;
}

/**
   This api reads wlan phy parameters (such as country, etc.) from
   rc.conf and returns them in wlan_phy

   \param   wlan_phy - pointer to Phy config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ifx_mapi_get_wlan_static_phy_config(IFX_MAPI_WLAN_PhyCfg * wlan_phy, uint32 flags)
{
	int32 ret = IFX_SUCCESS, index = -1, nPhyEntries = 0;
	IFX_MAPI_WLAN_PhyCfg * wlPhyCfgAll = NULL;
	FILE *fptr = NULL;
	char mapi_flg=0;
	
	LTQ_LOG_TIMESTAMP("Begin");

	// to synchronize between web and tr069 ot UPnP at the mapi level
	fptr = fopen("/tmp/web_Phyflg","r+");
	if(fptr) {
		mapi_flg=fgetc(fptr);
		fclose(fptr);
	}

	if (wlan_phy->iid.config_owner == IFX_WEB) {
		if ((mapi_flg == '0') || (mapi_flg == '2'))
			g_flagPhyConfig = 0;
	}
	else {
		if ((mapi_flg == '0') || (mapi_flg == '1'))
			g_flagPhyConfig = 0;
	}

	/* if configuration is not yet available, get it by calling
		ifx_mapi_get_all_wlan_phy_config */
	if (!g_flagPhyConfig) {
		if ((ret = ifx_mapi_get_all_wlan_phy_config((uint32 *) &nPhyEntries,
			&wlPhyCfgAll, IFX_F_DEFAULT)) != IFX_SUCCESS) {
			goto IFX_Handler;
		}
		IFX_MEM_FREE(wlPhyCfgAll);
	}

	index = wlan_phy->iid.cpeId.Id-1;
	if ((index == 0) || (index == 1)) {
		memcpy(wlan_phy, &g_wlPhy[index], sizeof(IFX_MAPI_WLAN_PhyCfg));
	}
	else {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStaticPhyConfig", "");
		ret = IFX_FAILURE;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStaticPhyConfig",
		"index: %d, channel: %d", index, wlan_phy->channelNo );
IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStaticPhyConfig", "ret: %d", ret);
	LTQ_LOG_TIMESTAMP("Done");
	return ret;
}

/**
   This api reads dynamic wlan phy parameters (such as status, channel no.) from
   scripts and returns them in wlan_phy

   \param   wlan_phy - pointer to Phy config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ifx_mapi_get_wlan_dyn_phy_config(IFX_MAPI_WLAN_PhyCfg * wlan_phy, uint32 flags)
{
	int32 ret = IFX_SUCCESS, index = -1;
	char8 buf[MAX_FILELINE_LEN];
	char8 sParamValue[MAX_FILELINE_LEN];
	char8 sRadioDynInfo[MAX_DATA_LEN];
	uint8	channel = 0;

	LTQ_LOG_TIMESTAMP("Begin");

	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	NULL_TERMINATE(sParamValue, 0x00, sizeof(sParamValue));

	/*
	 * get the dynamic information:
	 * - status
	 * - channelsInUse
	 * - channelNo (if autoChannelEna is TRUE)
	 */
	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	memset(sRadioDynInfo, 0x00, sizeof(sRadioDynInfo));
	index = wlan_phy->iid.cpeId.Id - 1;
	sprintf(buf, "%s %d", SERVICE_WLAN_GET_RADIO_DYN_INFO, index);

	/* get bssid information */
	if (ifx_GetCfgData((char8 *) buf, NULL, "-1", sRadioDynInfo) == 0) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_phy_config",
		"sRadioDynInfo: %s", sRadioDynInfo);

	/* save buffer in sResultFromScript */
	strcpy(sResultFromScript, sRadioDynInfo);

	if ((ret = ltq_get_param("status=", sParamValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_phy_config",
			       "Status not available");
		wlan_phy->status = 2;
	} else {
		wlan_phy->status = atoi(sParamValue);
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_phy_config", "status: %d",
		wlan_phy->status);

	if (g_flagPhyConfig && g_wlPhy[index].radioEnable) {
    	if ((ret = ltq_get_param("channel=", sParamValue)) != IFX_SUCCESS) {
    		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_phy_config",
    			       "Channel not available");
    		wlan_phy->channelNo = 0;
    	} else {
			channel = atoi(sParamValue);
			if (channel != 0)
		    	wlan_phy->channelNo = atoi(sParamValue);
			else
				IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_phy_config",
					"Channel not available");
		}
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_phy_config", "channel: %d",
		wlan_phy->channelNo);

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_phy_config", "");
	LTQ_LOG_TIMESTAMP("Done");
	return IFX_SUCCESS;
}

/**
   This api reads wlan main parameters from rc.conf and returns them in wlan_main

   \param   wlan_main - pointer to Main config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE

   \note - pcpeid for each ap/vap (instance in wlan main) is lan device
*/
int32
ifx_mapi_get_wlan_main_config(IFX_MAPI_WLAN_MainCfg * wlan_main, uint32 flags)
{
	int32 passed_index = -1, ret = IFX_SUCCESS;
	char8 *sValue = NULL;
	IFX_MAPI_WLAN_MainCfg * wlMainCfgAll = NULL;
	uint32					nMainEntries, wpsCfgState = IFX_MAPI_WPS_CONFIGURED;
	// to synchronize between web and tr069 ot UPnP at the mapi level
	FILE *fptr = NULL;
	char8 mapi_flg=0;

	switch (wlan_main->iid.cpeId.Id) {
	case 1:
		LTQ_LOG_TIMESTAMP("AP");
		break;
	case 2:
		LTQ_LOG_TIMESTAMP("VAP1");
		break;
	case 3:
		LTQ_LOG_TIMESTAMP("VAP2");
		break;
	case 4:
		LTQ_LOG_TIMESTAMP("VAP3");
		break;
	}

	sprintf(wlan_main->iid.cpeId.secName, "%s", TAG_WLAN_MAIN);

	/*
	   get index from cpeid: example wlmn_1_cpeId="3" => passed_index = 1 */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlan_main->iid.cpeId,
				 passed_index)
	    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMainConfig",
			   "passed_index: %d", passed_index);

	/* if configuration is already available, check if WPS config state changed
		if yes main and security config must be updated */
	if (g_flagMainConfig) {
		/* if WPS enabled and old state == UNCONFIGURED, check if state == CONFIGURED */
		if ((g_wlMain[passed_index].WPSena) &&
			(g_wpsState[passed_index] != IFX_MAPI_WPS_CONFIGURED)) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMainConfig", "");
			wpsCfgState = ltq_mapi_get_wps_config_state(
							g_wlMain[passed_index].iid.cpeId.Id);
			if (wpsCfgState == IFX_MAPI_WPS_CONFIGURED) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMainConfig", "");
				system("echo 0 > /tmp/web_Mainflg &");
				system("echo 0 > /tmp/web_Secflg &");
				/* reset flags to reload the configuration */
				g_flagMainConfig = 0;
				g_flagSecConfig = 0;
				g_wpsState[passed_index] = IFX_MAPI_WPS_CONFIGURED;
			} else {
				g_wpsState[passed_index] = IFX_MAPI_WPS_NOT_CONFIGURED;
			}
		}
	}

	// to synchronize between web and tr069 ot UPnP at the mapi level
	fptr = fopen("/tmp/web_Mainflg","r+");
	if(fptr) {
		mapi_flg=fgetc(fptr);
		fclose(fptr);
	}

	if (wlan_main->iid.config_owner == IFX_WEB) {
		if ((mapi_flg == '0') || (mapi_flg == '2'))
			g_flagMainConfig = 0;
	}
	else {
		if ((mapi_flg == '0') || (mapi_flg == '1'))
			g_flagMainConfig = 0;
	}

	/* if configuration is already available, take it from there */
	if (!g_flagMainConfig) {
		if (ifx_mapi_get_all_wlan_main_config(&nMainEntries, &wlMainCfgAll,
			IFX_F_DEFAULT) != IFX_SUCCESS) {
				LTQ_LOG_TIMESTAMP("Done");
				return IFX_FAILURE;
		}
		g_nVap = nMainEntries;
		IFX_MEM_FREE(wlMainCfgAll);
	}
	memcpy(wlan_main, &g_wlMain[passed_index], sizeof(IFX_MAPI_WLAN_MainCfg));
	LTQ_LOG_TIMESTAMP("Done");
	return IFX_SUCCESS;

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMainConfig", "ret: %d", ret);
	IFX_MEM_FREE(sValue)
	LTQ_LOG_TIMESTAMP("Done");
	return ret;
}

/**
   This api reads dynamic wlan ap info from scripts and returns them in wlan_main

   \param   wlan_main - pointer to Main config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE

   \note - pcpeid for each ap/vap (instance in wlan main) is lan device
*/
int32
ifx_mapi_get_wlan_dyn_vap_info(IFX_MAPI_WLAN_MainCfg * wlan_main, uint32 flags)
{
	int32 passed_index = -1, ret = IFX_SUCCESS;
	char8 buf[MAX_FILELINE_LEN], *sValue = NULL;
	char8 sParamValue[MAX_FILELINE_LEN], sApInfo[MAX_DATA_LEN];

	LTQ_LOG_TIMESTAMP("Begin");
	sprintf(wlan_main->iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
	NULL_TERMINATE(sParamValue, 0x00, sizeof(sParamValue));

	/*
	 * get index from cpeid: example wlmn_1_cpeId="3" => passed_index = 1
	 */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlan_main->iid.cpeId,
				 passed_index)
	    IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_vap_info",
			   "passed_index: %d", passed_index);

	/* if AP is disabled, no need to get the status */
	if (g_flagMainConfig) {
		if (!g_wlMain[passed_index].apEnable) {
			wlan_main->status = 0;
			LTQ_LOG_TIMESTAMP("Done");
			return IFX_SUCCESS;
		}
	}

	if (passed_index < 0) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_vap_info",
			       "passed_index: %d", passed_index);
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	memset(sApInfo, 0x00, sizeof(sApInfo));
	sprintf(buf, "%s %d", SERVICE_WLAN_GET_AP_DYN_INFO, passed_index);

	/* get the dynamic information */
	if (ifx_GetCfgData((char8 *) buf, NULL, "-1", sApInfo) == 0) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_vap_info", "sApInfo: %s",
		       sApInfo);

	/* save buffer in global variable sResultFromScript */
	strcpy(sResultFromScript, sApInfo);

	if ((ret = ltq_get_param("status=", sParamValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_vap_info",
			"BSSID not available");
		wlan_main->status = 0;
	} else {
		wlan_main->status = atoi(sParamValue);
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_vap_info", "status: %d",
		wlan_main->status);

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_vap_info", "ret: %d", ret);
	IFX_MEM_FREE(sValue)
	LTQ_LOG_TIMESTAMP("Done");
    return IFX_SUCCESS;
}

/**
   This api gets a complete wep configuration, containing a set of four wep
   keys, the encryption type and level (ASCII or HEX, 64 or 128 bit) and
   the selected index.

   \param   wlWepCfg - pointer to IFX_MAPI_WLAN_WEP_Cfg structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ifx_mapi_get_wlan_wep_config(IFX_MAPI_WLAN_WEP_Cfg * wlWepCfg, uint32 flags)
{
	int32 ret = IFX_SUCCESS, passed_index = -1;
	char8 buf[MAX_DATA_LEN];
	CPE_ID cpe_id;
	char8 *sValueNew = NULL;
	int32 count, i;
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_SEC_PARAM_COUNT + 1];

	LTQ_LOG_TIMESTAMP("Begin");

	sprintf(cpe_id.secName, "%s", TAG_WLAN_SEC);
	cpe_id.Id = wlWepCfg->wepKey[0].iid.pcpeId.Id;
    /*
	   get index from pcpeid, we need the index of the AP, i.e. the
	   configuration index of the parent object (wlan_sec), therefore we use
	   the pcpeId here */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpe_id, passed_index)
	    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWepConfig",
			   "passed_index:%d", passed_index);

	/* get security object from rc.conf */
	sprintf(buf, "%s_%d_", PREFIX_WLAN_SEC, passed_index);
	if ((ret =
	     ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_SEC, buf, IFX_F_DEFAULT,
			      &sValueNew)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWepConfig", "buf: %s",
			       buf);
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWepConfig",
		       "buf: %s, sValue: %s", buf, sValueNew);

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sValueNew, &count, array_fvp);
	IFX_MEM_FREE(sValueNew);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWepConfig", "count: %d", count);
	for (i = 0; i < count; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWepConfig", "%s:%s",
			       array_fvp[i].fieldname, array_fvp[i].value);

	wlWepCfg->wepEncrLevel = atoi(array_fvp[11].value);
	wlWepCfg->wepKeyType = atoi(array_fvp[12].value);
	wlWepCfg->wepKeyIndex = atoi(array_fvp[13].value);

	if ((ret = ifx_mapi_get_all_wlan_wep_keys(cpe_id.Id, wlWepCfg->wepKey,
		flags) != IFX_SUCCESS)) {
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
			goto IFX_Handler;
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWepConfig", "ret: %d", ret);
	IFX_MEM_FREE(sValueNew);
	LTQ_LOG_TIMESTAMP("Done");
	return ret;
}

/**
   This api will get all four wep keys of ap defined by
   mainCpeId and it assumes that there are only 4 wep key instances.

   \param   mainCpeId  -

   \param   wlWeKey      - pointer to WLAN Wep Key array

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ifx_mapi_get_all_wlan_wep_keys(uint32 mainCpeId,
		IFX_MAPI_WLAN_WEP_Key * wlWepKey, uint32 flags)
{
	int32 				ret = IFX_SUCCESS, nParamCount = 0, i = 0;
	IFX_NAME_VALUE_PAIR	array_fvp[13];
	char8				*sWlanWepObject = NULL, buf[MAX_DATA_LEN];
	char8 wepKeyInAscii[IFX_MAPI_WEP_KEY_MAX_LEN]; /* IFX_MAPI_WEP_KEY_MAX_LEN already includes closing \0 */
	IFX_MAPI_WLAN_MainCfg wlMain;
	int32	vendor = LTQ_MAPI_WLAN_VENDOR_NONE;

	LTQ_LOG_TIMESTAMP("Begin");

	sprintf(buf, "%s%d_", PREFIX_WLAN_WEP, mainCpeId);
	if ((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_WEP, buf, IFX_F_DEFAULT,
		&sWlanWepObject)) != IFX_SUCCESS)
		goto IFX_Handler;

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sWlanWepObject, &nParamCount, array_fvp);

	for (i = 0; i < nParamCount; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_all_wlan_wep_keys", "%s:%s",
			array_fvp[i].fieldname, array_fvp[i].value);

	memset(&wlMain, 0, sizeof(IFX_MAPI_WLAN_MainCfg));
	sprintf(wlMain.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
	sprintf(wlMain.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
	wlMain.iid.cpeId.Id = atoi(array_fvp[1].value);
	if ((ret = ifx_mapi_get_wlan_main_config(&wlMain, IFX_F_DEFAULT)) !=
			IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_all_wlan_wep_keys", "");
		goto IFX_Handler;
	}
	/* get vendor information */
	vendor = ltq_mapi_get_wlan_vendor(wlMain.radioCpeId, IFX_F_DEFAULT);
	for (i = 0; i < IFX_MAPI_NUM_WEP_KEYS; i++) {
		sprintf((wlWepKey+i)->iid.cpeId.secName, "%s", TAG_WLAN_WEP);
		sprintf((wlWepKey+i)->iid.pcpeId.secName, "%s", TAG_WLAN_SEC);
		(wlWepKey+i)->iid.cpeId.Id = atoi(array_fvp[3*i].value);
		(wlWepKey+i)->iid.pcpeId.Id = atoi(array_fvp[3*i+1].value);

		if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			memset(wepKeyInAscii, 0, sizeof(wepKeyInAscii));
			/* convert hex representation of wep key to ascii representation */
			if (mapi_wlan_convert_hex_to_ascii(array_fvp[3*i + 2].value,
				wepKeyInAscii) != IFX_SUCCESS) {
				snprintf((wlWepKey+i)->wepKey, IFX_MAPI_WEP_KEY_MAX_LEN, "%s", array_fvp[3*i + 2].value);
			} else {
				snprintf((wlWepKey+i)->wepKey, IFX_MAPI_WEP_KEY_MAX_LEN, "%s", wepKeyInAscii);
			}
		} else {
			snprintf((wlWepKey+i)->wepKey, IFX_MAPI_WEP_KEY_MAX_LEN, "%s", array_fvp[3*i + 2].value);
		}
	}

IFX_Handler:
	IFX_MEM_FREE(sWlanWepObject)
	IFX_DBG("[%s:%d]: ret: %d",	__FUNCTION__, __LINE__, ret);
	LTQ_LOG_TIMESTAMP("Done");
	return ret;
}

/**
   This api reads

   \param keyIdx

   \param   wlPersonal - pointer to IFX_MAPI_WLAN_PersonalCfg structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE

   \note - assume instance no. is always 1 for any instance but prefix is
   	   	   unique, pcpeid is must
*/
int32
ifx_mapi_get_wlan_personal_config(IFX_MAPI_WLAN_PersonalCfg * wlPersonal,
				  uint32 flags)
{
	int32 ret = IFX_SUCCESS, passed_index = -1, count, i;
	CPE_ID pcpeId_wl802_1X;
	char8 buf[MAX_DATA_LEN], *sValueNew = NULL;
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_802_1X_PARAM_COUNT];
	char8 passphraseInAscii[IFX_MAPI_PASSPHRASE_MAX_LEN];
	IFX_MAPI_WLAN_MainCfg wlMain;
	int32	vendor = LTQ_MAPI_WLAN_VENDOR_NONE;

	switch (wlPersonal->psk.iid.pcpeId.Id) {
	case 1:
		LTQ_LOG_TIMESTAMP("AP");
		break;
	case 2:
		LTQ_LOG_TIMESTAMP("VAP1");
		break;
	case 3:
		LTQ_LOG_TIMESTAMP("VAP2");
		break;
	case 4:
		LTQ_LOG_TIMESTAMP("VAP3");
		break;
	}

	sprintf(wlPersonal->psk.iid.cpeId.secName, "%s", TAG_WLAN_PASSPHRASE);
	sprintf(wlPersonal->psk.iid.pcpeId.secName, "%s", TAG_WLAN_SEC);

	memset(buf, 0x00, sizeof(buf));
	/* get wlpsk object from rc.conf */
	sprintf(buf, "%s%d_0_", PREFIX_WLAN_PASSPHRASE,
		wlPersonal->psk.iid.pcpeId.Id);
	if ((ret =
	     ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_PASSPHRASE, buf, IFX_F_DEFAULT,
			      &sValueNew)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPersonalConfig",
			       "buf: %s, flags: 0x%x", buf, flags);
		goto IFX_Handler;
	}

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sValueNew, &count, array_fvp);
	for (i = 0; i < count; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPersonalConfig", "%s:%s",
			array_fvp[i].fieldname, array_fvp[i].value);
	IFX_MEM_FREE(sValueNew);

	wlPersonal->psk.iid.cpeId.Id = atoi(array_fvp[0].value);
	wlPersonal->psk.iid.pcpeId.Id = atoi(array_fvp[1].value);
	wlPersonal->pskType = atoi(array_fvp[2].value);
	if (wlPersonal->pskType == IFX_MAPI_WLAN_ASCII_KEY) {
		memset(&wlMain, 0, sizeof(IFX_MAPI_WLAN_MainCfg));
		sprintf(wlMain.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
		sprintf(wlMain.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
		wlMain.iid.cpeId.Id = wlPersonal->psk.iid.pcpeId.Id;
		if ((ret = ifx_mapi_get_wlan_main_config(&wlMain, IFX_F_DEFAULT)) !=
			 IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPersonalConfig", "");
			goto IFX_Handler;
		}
		/* get vendor information */
		vendor = ltq_mapi_get_wlan_vendor(wlMain.radioCpeId, IFX_F_DEFAULT);
		if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			memset(passphraseInAscii, 0, sizeof(passphraseInAscii));
			/* convert hex representation of ssid to ascii representation */
			if (mapi_wlan_convert_hex_to_ascii(array_fvp[3].value, passphraseInAscii) != IFX_SUCCESS) {
				snprintf(wlPersonal->psk.passPhrase, IFX_MAPI_PASSPHRASE_MAX_LEN,
					"%s", array_fvp[3].value);
			} else {
				snprintf(wlPersonal->psk.passPhrase, IFX_MAPI_PASSPHRASE_MAX_LEN,
					"%s", passphraseInAscii);
			}
		} else {
			snprintf(wlPersonal->psk.passPhrase, IFX_MAPI_PASSPHRASE_MAX_LEN,
				"%s", array_fvp[3].value);
		}
	} else {
		if (strlen(array_fvp[4].value) > 0) {
			snprintf(wlPersonal->psk.preSharedKey,
				 IFX_MAPI_PSK_MAX_LEN, "%s",
				 array_fvp[4].value);
			wlPersonal->pskType = IFX_MAPI_WLAN_HEX_KEY;
		}
	}

	/*
	   get group key update interval and group key enable from WLAN_802_1X
	   object; a different index is required for this */
	sprintf(pcpeId_wl802_1X.secName, "%s", TAG_WLAN_1X);
	pcpeId_wl802_1X.Id = wlPersonal->psk.iid.pcpeId.Id;
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, pcpeId_wl802_1X, passed_index)
	    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPersonalConfig",
			   "passed_index: %d", passed_index);

	/* get wl1x object from rc.conf */
	sprintf(buf, "%s_%d_", PREFIX_WLAN_SEC_1X, passed_index);
	if ((ret =
	     ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_1X, buf, IFX_F_DEFAULT,
			      &sValueNew)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPersonalConfig",
			       "buf: %s", buf);
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPersonalConfig",
		       "buf: %s, sValue: %s", buf, sValueNew);

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sValueNew, &count, array_fvp);
	for (i = 0; i < count; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPersonalConfig", "%s:%s",
			       array_fvp[i].fieldname, array_fvp[i].value);
	IFX_MEM_FREE(sValueNew);

	wlPersonal->groupKeyIntvl = atoi(array_fvp[3].value);
	wlPersonal->groupKeyEna = atoi(array_fvp[2].value);

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPersonalConfig", "ret: %d", ret);
	IFX_MEM_FREE(sValueNew);
	LTQ_LOG_TIMESTAMP("Done");
	return ret;
}

/**
   This API queries WLAN security configuration for given AP/VAP specified by
   CpeId (wlSec->iid.cpeId.Id)

   \param   wlSec - pointer to IFX_MAPI_WLAN_SecCfg config structure,
                    wlSec->iid.cpeId.Id already must have been filled

   \param   flags - valid flag

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ifx_mapi_get_wlan_security_config(IFX_MAPI_WLAN_SecCfg * wlSec, uint32 flags)
{
	int32 passed_index = -1, ret = IFX_SUCCESS;
	char8 *sValue = NULL, mapi_flg = 0;
	CPE_ID cpe_id;
	IFX_MAPI_WLAN_SecCfg * 	wlSecCfgAll = NULL;
	uint32					nSecEntries;
	FILE *fptr = NULL;

	LTQ_LOG_TIMESTAMP("Begin");

	memset(&cpe_id, 0x00, sizeof(cpe_id));

	sprintf(cpe_id.secName, "%s", TAG_WLAN_SEC);
	cpe_id.Id = wlSec->iid.cpeId.Id;

	/* get index from cpeid first */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpe_id, passed_index)

	// to synchronize between web and tr069 or UPnP at the mapi level
	fptr = fopen("/tmp/web_Secflg","r+");
	if(fptr) {
		mapi_flg=fgetc(fptr);
		fclose(fptr);
	}

	if (wlSec->iid.config_owner == IFX_WEB) {
		if ((mapi_flg == '0') || (mapi_flg == '2'))
			g_flagSecConfig = 0;
	}
	else {
		if ((mapi_flg == '0') || (mapi_flg == '1'))
			g_flagSecConfig = 0;
	}

	/* if configuration is already available, take it from there */
	if (!g_flagSecConfig) {
		if ((ret = ifx_mapi_get_all_wlan_security_config(&nSecEntries, &wlSecCfgAll,
			IFX_F_DEFAULT)) != IFX_SUCCESS) {
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
			goto IFX_Handler;
		}
		g_nVap = nSecEntries;
		IFX_MEM_FREE(wlSecCfgAll);
	}
	memcpy(wlSec, &g_wlSec[passed_index], sizeof(IFX_MAPI_WLAN_SecCfg));

IFX_Handler:
	IFX_MEM_FREE(sValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecurityConfig", "ret: %d", ret);
	LTQ_LOG_TIMESTAMP("Done");
	return ret;
}

/**
   This api reads the count and then for each IFX_MAPI_WLAN_SecCfg instance gets
   cpeid, fills it in the structure	and calls ifx_mapi_get_wlan_security_config
   api with this structure

   \param   numEntries  -

   \param   wlSec - pointer to IFX_MAPI_WLAN_SecCfg Main config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ifx_mapi_get_all_wlan_security_config(uint32 * numEntries,
				      IFX_MAPI_WLAN_SecCfg ** wlSec,
				      uint32 flags)
{
	int32 ret = IFX_SUCCESS, nCount = 0, i = 0, nParamCount = 0;
	char8 sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN];
	char8 mapi_flg=0, *sWlanSecObject = NULL;
	uint32 outFlag = IFX_F_DEFAULT;
	// to synchronize between web and tr069 ot UPnP at the mapi level
	FILE *fptr = NULL;
	IFX_NAME_VALUE_PAIR array_fvp[LTQ_MAX_NUM_VAP*WLAN_SEC_PARAM_COUNT];
	IFX_MAPI_WLAN_MainCfg wlMain;
	int32	vendor = LTQ_MAPI_WLAN_VENDOR_NONE;

	LTQ_LOG_TIMESTAMP("Begin");

	MAKE_SECTION_COUNT_TAG(TAG_WLAN_SEC, buf);
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_SEC, buf, flags, &outFlag,
			    sValue)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}

	nCount = atoi(sValue);
	if (nCount == 0) {
		*numEntries = 0;
		*wlSec = NULL;
		goto IFX_Handler;
	}

	*wlSec = NULL;
	/*
	 * \todo
	 * additional check required for nCount?
	 */
	IFX_MEM_ALLOC((*wlSec), IFX_MAPI_WLAN_SecCfg *, nCount,
			      sizeof(IFX_MAPI_WLAN_SecCfg))

	// to synchronize between web and tr069 or UPnP at the mapi level
	fptr = fopen("/tmp/web_Secflg","r+");
	if(fptr) {
		mapi_flg=fgetc(fptr);
		fclose(fptr);
	}

	if (IFX_RESET_WEB_CFG_F_SET(flags)) {
		if ((mapi_flg == '0') || (mapi_flg == '2'))
			g_flagSecConfig = 0;
	}
	else {
		if ((mapi_flg == '0') || (mapi_flg == '1'))
			g_flagSecConfig = 0;
	}

	/* if configuration is already available, return immediately */
	if (g_flagSecConfig) {
		memcpy(*wlSec, g_wlSec, sizeof(IFX_MAPI_WLAN_SecCfg) * nCount);
		*numEntries = g_nVap;
		goto IFX_Handler;
	}

	sprintf(buf, "%s_", PREFIX_WLAN_SEC);
	if ((ret =
	     ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_SEC, buf, IFX_F_DEFAULT, &sWlanSecObject))
	    != IFX_SUCCESS)
		goto IFX_Handler;

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sWlanSecObject, &nParamCount, array_fvp);
	IFX_MEM_FREE(sWlanSecObject)

	for (i = 0; i < nCount; i++) {
		sprintf((*wlSec + i)->iid.cpeId.secName, "%s", TAG_WLAN_SEC);
		sprintf((*wlSec + i)->iid.pcpeId.secName, "%s", TAG_LAN_MAIN);
		(*wlSec + i)->iid.cpeId.Id 		= atoi(array_fvp[i*15].value);;
		(*wlSec + i)->iid.pcpeId.Id 	= atoi(array_fvp[i*15 + 1].value);;
		(*wlSec + i)->beaconType 		= atoi(array_fvp[i*15 + 2].value);

		memset(&wlMain, 0, sizeof(IFX_MAPI_WLAN_MainCfg));
		sprintf(wlMain.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
		sprintf(wlMain.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
		wlMain.iid.cpeId.Id = (*wlSec + i)->iid.cpeId.Id;
		if ((ret = ifx_mapi_get_wlan_main_config(&wlMain, IFX_F_DEFAULT)) !=
			 IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanSecurityConfig", "");
			goto IFX_Handler;
		}
		/* get vendor information */
		vendor = ltq_mapi_get_wlan_vendor(wlMain.radioCpeId, IFX_F_DEFAULT);
		if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			/*
			 * for Wi-FI compliance we set a different mode in rc.conf on set operation
			 * now we reverse this to show the correct mode in tr69 and web
			 */
			if ((*wlSec + i)->beaconType == IFX_MAPI_WLAN_BEACON_WPA_WPA2_NON_COMPLIANT)
				(*wlSec + i)->beaconType = IFX_MAPI_WLAN_BEACON_WPA_WPA2;
			else if ((*wlSec + i)->beaconType == IFX_MAPI_WLAN_BEACON_WPA_WPA2)
				(*wlSec + i)->beaconType = IFX_MAPI_WLAN_BEACON_WPA_WPA2_NON_COMPLIANT;
		}

		(*wlSec + i)->wlAuth 			= atoi(array_fvp[i*15 + 3].value);
		(*wlSec + i)->wlEncr 			= atoi(array_fvp[i*15 + 4].value);
		(*wlSec + i)->basicAuth 		= atoi(array_fvp[i*15 + 5].value);
		(*wlSec + i)->basicEncr 		= atoi(array_fvp[i*15 + 6].value);
		(*wlSec + i)->wpaAuth 			= atoi(array_fvp[i*15 + 7].value);
		(*wlSec + i)->wpaEncr 			= atoi(array_fvp[i*15 + 8].value);
		(*wlSec + i)->wpa2Auth 			= atoi(array_fvp[i*15 + 9].value);
		(*wlSec + i)->wpa2Encr 			= atoi(array_fvp[i*15 + 10].value);
		(*wlSec + i)->macAddrCntrlEna	= atoi(array_fvp[i*15 + 14].value);
		/*
		 * if encryption is WEP, call api to get all wep keys;
		*/
		if ((*wlSec + i)->wlEncr == IFX_MAPI_WLAN_ENCR_WEP) {
			/* get wep configuration */

			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanSecurityConfig", "cpeID: %d",
				(*wlSec + i)->iid.cpeId.Id);
			if ((ret = ifx_mapi_get_all_wlan_wep_keys((*wlSec + i)->iid.cpeId.Id,
				(*wlSec + i)->secParams.wepCfg.wepKey, flags) != IFX_SUCCESS)) {
					IFX_DBG("[%s:%d]: cpeId: %d", __FUNCTION__, __LINE__,
					(*wlSec + i)->iid.cpeId.Id);
				goto IFX_Handler;
}
			(*wlSec + i)->secParams.wepCfg.wepEncrLevel	= atoi(array_fvp[i*15 + 11].value);
			(*wlSec + i)->secParams.wepCfg.wepKeyType 	= atoi(array_fvp[i*15 + 12].value);
			(*wlSec + i)->secParams.wepCfg.wepKeyIndex 	= atoi(array_fvp[i*15 + 13].value);
		}
		else if (((*wlSec + i)->beaconType >= IFX_MAPI_WLAN_BEACON_WPA)
			   && ((*wlSec + i)->wlAuth == IFX_MAPI_WLAN_AUTH_PERSONAL)) {
			(*wlSec + i)->secParams.personalCfg.pskType = IFX_MAPI_WLAN_ASCII_KEY;

			/* if beacon type is wpa then call api to get passphrase */
			/* get passphrase configuration */
			(*wlSec + i)->secParams.personalCfg.psk.iid.pcpeId.Id =
					(*wlSec + i)->iid.cpeId.Id;
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanSecurityConfig", "pcpeID: %d",
				       (*wlSec + i)->secParams.personalCfg.psk.iid.pcpeId.Id);
			if ((ret = ifx_mapi_get_wlan_personal_config
					(&(*wlSec + i)->secParams.personalCfg, IFX_F_DEFAULT)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}
		} else if (((*wlSec + i)->beaconType >= IFX_MAPI_WLAN_BEACON_WPA)
			   && ((*wlSec + i)->wlAuth == IFX_MAPI_WLAN_AUTH_RADIUS)) {
			/*
			   if beacon type is wpa and auth type radius, then call api to get
			   802.1x configuration */
			(*wlSec + i)->secParams.wlRadius.iid.pcpeId.Id = (*wlSec + i)->iid.cpeId.Id;
			if ((ret =
				ifx_mapi_get_wlan_802_1x_config(&(*wlSec + i)->secParams.wlRadius,
				IFX_F_DEFAULT)) != IFX_SUCCESS) {
				goto IFX_Handler;
			}
		}
#ifdef LTQ_AEI_CUST
		else if (
			((*wlSec + i)->beaconType == IFX_MAPI_WLAN_BEACON_BASIC) &&
			((*wlSec + i)->wlAuth == IFX_MAPI_WLAN_AUTH_OPEN) &&
			((*wlSec + i)->wlEncr == IFX_MAPI_WLAN_ENCR_NONE)) {

			/* an open AP is reported back as beacon type NONE */
			(*wlSec + i)->beaconType = IFX_MAPI_WLAN_BEACON_NONE;
		}
#endif /* #ifdef LTQ_AEI_CUST */
	}
	*numEntries = nCount;

	/* store in global variable for later usage */
	memcpy(g_wlSec, *wlSec, sizeof(IFX_MAPI_WLAN_SecCfg) * nCount);
	g_flagSecConfig = 1;
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanSecurityConfig", "flags: 0x%x",
		flags);
	if (IFX_RESET_WEB_CFG_F_SET(flags)) {
		if (mapi_flg == '0')
			system("echo 1 > /tmp/web_Secflg &");
		else if (mapi_flg == '2')
			system("echo 3 > /tmp/web_Secflg &");
		else
			system("echo 1 > /tmp/web_Secflg &");
	}
	else {
		if (mapi_flg == '0')
			system("echo 2 > /tmp/web_Secflg &");
		else if (mapi_flg == '1')
			system("echo 3 > /tmp/web_Secflg &");
		else
			system("echo 2 > /tmp/web_Secflg &");
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanSecurityConfig", "ret: %d", ret);
	/* free memory in case of error, otherwise it gets freed in calling
	   function */
	if (ret != IFX_SUCCESS)
		IFX_MEM_FREE(*wlSec)
	LTQ_LOG_TIMESTAMP("Done");
		    return ret;
}

/**
   This api reads the count and then for each wlan instance gets the cpeid, fills it in the structure
   and calls ifx_mapi_get_wlan_main_config api with this structure

   \param   numEntries  -

   \param   wlMain      - pointer to WLAN Main config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ifx_mapi_get_all_wlan_main_config(uint32 * numEntries,
				  IFX_MAPI_WLAN_MainCfg ** wlMain, uint32 flags)
{
	int32 ret = IFX_SUCCESS, nCount = 0, i = 0, nParamCount = 0, j = 0;
	char8 sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN];
	char8 mac_addr[20], mapi_flg=0, *sWlanRcConfObject = NULL, *ptr = NULL;
	// to synchronize between web and tr069 ot UPnP at the mapi level
	FILE *fptr = NULL;
	uint32 outFlag = IFX_F_DEFAULT, wpsCfgState = IFX_MAPI_WPS_CONFIGURED;
	IFX_NAME_VALUE_PAIR	array_fvp[LTQ_MAX_NUM_VAP*WLAN_MAIN_PARAM_COUNT];
	IFX_NAME_VALUE_PAIR	array_fvp_wps[LTQ_MAX_NUM_VAP*WLAN_WPS_PARAM_COUNT];
	char8 ssidInAscii[IFX_MAPI_WLAN_SSID_LEN];
	LTQ_MAPI_WLAN_Vendor	vendor = LTQ_MAPI_WLAN_VENDOR_NONE;

	LTQ_LOG_TIMESTAMP("Begin");

	MAKE_SECTION_COUNT_TAG(TAG_WLAN_MAIN, buf);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAIN,
				  buf, flags, &outFlag,
				  sValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMainConfig", "");
		goto IFX_Handler;
	}

	nCount = atoi(sValue);
	if (nCount <= 0) {
		*numEntries = 0;
		*wlMain = NULL;
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMainConfig", "");
		goto IFX_Handler;
	}

	*wlMain = NULL;
	/*
	 * \todo
	 * additional check required for nCount?
	 */
	if (nCount <= LTQ_MAX_NUM_VAP) {
		IFX_MEM_ALLOC((*wlMain), IFX_MAPI_WLAN_MainCfg *, nCount,
			      sizeof(IFX_MAPI_WLAN_MainCfg))
	} else {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMainConfig", "nCount: %d", nCount);
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMainConfig",
		"g_flagMainConfig: %d", g_flagMainConfig);
	/* if configuration is already available, check if WPS config state changed
		if yes main and security config must be updated (web and TR69) */
	if (g_flagMainConfig) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMainConfig",
			"nCount: %d", nCount);
		for (i = 0; i < nCount; i++) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMainConfig",
				"wpsEna: %d, wpsState[%d]: %d",
				g_wlMain[i].WPSena, i, g_wpsState[i]);
			/* if WPS enabled and old state == UNCONFIGURED, check if state == CONFIGURED */
			if ((g_wlMain[i].WPSena) && (g_wpsState[i] != IFX_MAPI_WPS_CONFIGURED)) {
				wpsCfgState = ltq_mapi_get_wps_config_state(g_wlMain[i].iid.cpeId.Id);
				if (wpsCfgState == IFX_MAPI_WPS_CONFIGURED) {
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMainConfig", "");
					system("echo 0 > /tmp/web_Mainflg &");
					system("echo 0 > /tmp/web_Secflg &");
					/* reset flags to reload the configuration */
					g_flagMainConfig = 0;
					g_flagSecConfig = 0;
					g_wpsState[i] = IFX_MAPI_WPS_CONFIGURED;
				} else {
					g_wpsState[i] = IFX_MAPI_WPS_NOT_CONFIGURED;
				}
			}
		}
	}

	// to synchronize between web and tr069 ot UPnP at the mapi level
	fptr = fopen("/tmp/web_Mainflg","r+");
	if(fptr) {
		mapi_flg=fgetc(fptr);
		fclose(fptr);
	}

	if (IFX_RESET_WEB_CFG_F_SET(flags)) {
		if ((mapi_flg == '0') || (mapi_flg == '2'))
			g_flagMainConfig = 0;
	}
	else {
		if ((mapi_flg == '0') || (mapi_flg == '1'))
			g_flagMainConfig = 0;
	}

	/* if configuration is already available, return immediately */
	if (g_flagMainConfig) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMainConfig", "");
		memcpy(*wlMain, g_wlMain, sizeof(IFX_MAPI_WLAN_MainCfg) * nCount);
		*numEntries = g_nVap;
		goto IFX_Handler;
	}

	sprintf(buf, "%s_", PREFIX_WLAN_MAIN);
	if ((ret =
	     ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_MAIN, buf, IFX_F_DEFAULT, &sWlanRcConfObject))
	    != IFX_SUCCESS)
		goto IFX_Handler;

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMainConfig", "buf: %s, sValue: %s",
		buf, sWlanRcConfObject);

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sWlanRcConfObject, &nParamCount, array_fvp);
	IFX_MEM_FREE(sWlanRcConfObject);

	for (i = 0; i < nCount; i++) {
		sprintf((*wlMain + i)->iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
		sprintf((*wlMain + i)->iid.pcpeId.secName, "%s", TAG_LAN_MAIN);
		(*wlMain + i)->iid.cpeId.Id 	= atoi(array_fvp[i * WLAN_MAIN_PARAM_COUNT].value);
		(*wlMain + i)->iid.pcpeId.Id 	= atoi(array_fvp[i * WLAN_MAIN_PARAM_COUNT + 1].value);
		(*wlMain + i)->radioCpeId 		= atoi(array_fvp[i * WLAN_MAIN_PARAM_COUNT + 2].value);
		(*wlMain + i)->apEnable 		= atoi(array_fvp[i * WLAN_MAIN_PARAM_COUNT + 3].value);

		snprintf((*wlMain + i)->apName, IFX_MAPI_WLAN_AP_NAME, "%s",
			 array_fvp[i * WLAN_MAIN_PARAM_COUNT + 4].value);
		(*wlMain + i)->devType = atoi(array_fvp[i * WLAN_MAIN_PARAM_COUNT + 5].value);


		/* get vendor information */
		vendor = ltq_mapi_get_wlan_vendor((*wlMain + i)->radioCpeId, IFX_F_DEFAULT);
		if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			memset(ssidInAscii, 0, sizeof(ssidInAscii));
			/* convert hex representation of ssid to ascii representation */
			if (mapi_wlan_convert_hex_to_ascii(
				array_fvp[i * WLAN_MAIN_PARAM_COUNT + 6].value, ssidInAscii) !=
				IFX_SUCCESS) {
				snprintf((*wlMain + i)->ssid, IFX_MAPI_WLAN_SSID_LEN, "%s",
					 array_fvp[i * WLAN_MAIN_PARAM_COUNT + 6].value);
			} else {
				snprintf((*wlMain + i)->ssid, IFX_MAPI_WLAN_SSID_LEN, "%s", ssidInAscii);
			}
		} else {
			snprintf((*wlMain + i)->ssid, IFX_MAPI_WLAN_SSID_LEN, "%s",
				 array_fvp[i * WLAN_MAIN_PARAM_COUNT + 6].value);
		}

		(*wlMain + i)->ssidMode = atoi(array_fvp[i * WLAN_MAIN_PARAM_COUNT + 7].value);
		(*wlMain + i)->bssidOverride = atoi(array_fvp[i * WLAN_MAIN_PARAM_COUNT + 8].value);
		get_mac_addr(i , &mac_addr[0]);
		strncpy((*wlMain + i)->bssid , mac_addr  , strlen(mac_addr));

		/*
		 * parse the string based on ',' and store it in array basicDataRates
		 */
		j = 0;
		sprintf(buf, "%s", array_fvp[i * WLAN_MAIN_PARAM_COUNT + 10].value);
		ptr = strtok(buf, ",");
		while (ptr != NULL) {
			(*wlMain + i)->basicDataRates[j++] = atof(ptr);
			ptr = strtok(NULL, ",");
		}
		(*wlMain + i)->basicDataRates[j] = 0;

		/*
		 * parse the string based on ',' and store it in array
		 * operationalDataRates
		 */
		j = 0;
		sprintf(buf, "%s", array_fvp[i * WLAN_MAIN_PARAM_COUNT + 11].value);
		ptr = strtok(buf, ",");
		while (ptr != NULL) {
			(*wlMain + i)->operDataRates[j++] = atof(ptr);
			ptr = strtok(NULL, ",");
		}
		(*wlMain + i)->operDataRates[j] = 0;

		(*wlMain + i)->maxBitRate =
		    (float)strtod(array_fvp[i * WLAN_MAIN_PARAM_COUNT + 12].value, (char **)NULL);

		(*wlMain + i)->vlanId = atoi(array_fvp[i * WLAN_MAIN_PARAM_COUNT + 13].value);
		(*wlMain + i)->apIsolationEna = atoi(array_fvp[i * WLAN_MAIN_PARAM_COUNT + 14].value);
		(*wlMain + i)->WMMena = atoi(array_fvp[i * WLAN_MAIN_PARAM_COUNT + 15].value);
		(*wlMain + i)->UAPSDena = atoi(array_fvp[i * WLAN_MAIN_PARAM_COUNT + 16].value);
		(*wlMain + i)->WDSena = atoi(array_fvp[i * WLAN_MAIN_PARAM_COUNT + 17].value);
		(*wlMain + i)->maxStations = atoi(array_fvp[i * WLAN_MAIN_PARAM_COUNT + 18].value);
		(*wlMain + i)->minResSta = atoi(array_fvp[i * WLAN_MAIN_PARAM_COUNT + 19].value);
		(*wlMain + i)->networkMode = atoi(array_fvp[i * WLAN_MAIN_PARAM_COUNT + 20].value);
	}

	/* get wlan_wps object from rc.conf */
	sprintf(buf, "%s", PREFIX_WLAN_WPS);
	if ((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_WPS, buf, IFX_F_DEFAULT,
		&sWlanRcConfObject)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMainConfig","buf: %s", buf);
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMainConfig",
		"buf: %s, sValue: %s", buf, sValue);

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp_wps, 0x00, sizeof(array_fvp_wps));
	form_array_fvp_from_cfgdb_buf(sWlanRcConfObject, &nParamCount, array_fvp_wps);
	for (i = 0; i < nCount; i++) {
		(*wlMain + i)->WPSena 		= atoi(array_fvp_wps[i * WLAN_WPS_PARAM_COUNT + 2].value);
	}
	IFX_MEM_FREE(sWlanRcConfObject);

	*numEntries = nCount;

	/* store in global variable for later usage */
	memcpy(g_wlMain, *wlMain, sizeof(IFX_MAPI_WLAN_MainCfg) * nCount);
	g_flagMainConfig = 1;
	if (IFX_RESET_WEB_CFG_F_SET(flags)) {
		if (mapi_flg == '0')
			system("echo 1 > /tmp/web_Mainflg &");
		else if (mapi_flg == '2')
			system("echo 3 > /tmp/web_Mainflg &");
		else
			system("echo 1 > /tmp/web_Mainflg &");
	}
	else {
		if (mapi_flg == '0')
			system("echo 2 > /tmp/web_Mainflg &");
		else if (mapi_flg == '1')
			system("echo 3 > /tmp/web_Mainflg &");
		else
			system("echo 2 > /tmp/web_Mainflg &");
	}
	g_nVap = nCount;

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMainConfig", "ret: %d", ret);
	/* free memory in case of error, otherwise it gets freed in calling
	   function */
	if (ret != IFX_SUCCESS)
		IFX_MEM_FREE(*wlMain)
	LTQ_LOG_TIMESTAMP("Done");
	return ret;
}

/**
   \param   numEntries  -

   \param   glblMacControl - pointer to IFX_MAPI_GlobalMacControl config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ifx_mapi_get_all_global_mac_control_entries(uint32 * numEntries,
					    IFX_MAPI_GlobalMacControl **
					    glblMacControl, uint32 flags)
{
	int32 ret = IFX_SUCCESS, nCount = 0, i = 0;
	char8 sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN];
	uint32 outFlag = IFX_F_DEFAULT;

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllGlobalMacControlEntries", "");

	MAKE_SECTION_COUNT_TAG(TAG_WLAN_GLOBAL_MAC_CONTROL, buf);
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL, buf,
			    flags, &outFlag, sValue)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}

	nCount = atoi(sValue);
	if (nCount == 0) {
		*numEntries = 0;
		*glblMacControl = NULL;
		goto IFX_Handler;
	}

	*glblMacControl = NULL;
	IFX_MEM_ALLOC((*glblMacControl), IFX_MAPI_GlobalMacControl *, nCount,
		      sizeof(IFX_MAPI_GlobalMacControl))

	    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllGlobalMacControlEntries",
			   "nCount: %d", nCount);
	for (i = 0; i < nCount; i++) {
		/* get the cpeid of this instance */
		sprintf(buf, "%s_%d_cpeId", PREFIX_WLAN_GLOBAL_MAC_CONTROL, i);
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL,
				    buf, flags, &outFlag,
				    sValue)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd,
				       "/tmp/ifxMapiGetAllGlobalMacControlEntries",
				       "i=%d, nCount=%d", i, nCount);
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllGlobalMacControlEntries",
			       "buf:%s, sValue=%s", buf, sValue);
		(*glblMacControl + i)->iid.cpeId.Id = atoi(sValue);

		if ((ret =
		     ifx_mapi_get_global_mac_control_entry((*glblMacControl +
							    i),
							   flags)) !=
		    IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd,
				       "/tmp/ifxMapiGetAllGlobalMacControlEntries",
				       "failed to get security params for instance wlan%d",
				       i);
			goto IFX_Handler;
		}
	}
	*numEntries = nCount;

      IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllGlobalMacControlEntries",
		       "ret: %d", ret);
	if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*glblMacControl)
		    return ret;
	} else
		return IFX_SUCCESS;
}

/**
   \param   mainCpeId  -

   \param   numEntries  -

   \param   wlMacControl - pointer to IFX_MAPI_WLAN_MAC_Control config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ifx_mapi_get_all_wlan_mac_control_entries(uint32 mainCpeId,
					  uint32 * numEntries,
					  IFX_MAPI_WLAN_MAC_Control **
					  wlMacControl, uint32 flags)
{
	int32 ret = IFX_SUCCESS, nAllMacEntries = 0, i = 0, nMacEntries = 0;
	int32 count = 0;
	char8 sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN], *sValue2 = NULL;
	uint32 outFlag = IFX_F_DEFAULT, pcpeId;
	/* size of array: max. number of AP * number of params * max.number of entries = 16*3*32 */
	IFX_NAME_VALUE_PAIR array_fvp[LTQ_MAX_NUM_VAP * WLAN_MAC_CNTRL_PARAM_COUNT * 32];

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMacControlEntries", "mnCpeId: %d",
		mainCpeId);
	if (!g_flagMacControlAllConfig) {
		MAKE_SECTION_COUNT_TAG(TAG_WLAN_MAC_CONTROL, buf);
		if ((ret =
			 ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAC_CONTROL, buf, flags,
					&outFlag, sValue)) != IFX_SUCCESS) {
			goto IFX_Handler;
		}
	
		nAllMacEntries = atoi(sValue);
		if (nAllMacEntries == 0) {
			*numEntries = 0;
			*wlMacControl = NULL;
			goto IFX_Handler;
		}
	
		*wlMacControl = NULL;
		/* 32 per VAP * max number of VAP */
		if (nAllMacEntries <= LTQ_MAX_NUM_VAP * 32) {
			IFX_MEM_ALLOC((*wlMacControl), IFX_MAPI_WLAN_MAC_Control *,
					  nAllMacEntries, sizeof(IFX_MAPI_WLAN_MAC_Control))
		} else {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMacControlEntries",
					   "max number of entries reached");
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		g_nMacControlAll = nAllMacEntries;
	
		sprintf(buf, "%s_", PREFIX_WLAN_MAC_CONTROL);
		if ((ret =
			 ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_MAC_CONTROL, buf, IFX_F_DEFAULT,
					  &sValue2)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMacControlEntries",
				"buf: %s", buf);
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMacControlEntries",
			"buf: %s, sValue2: %s", buf, sValue2);
	
		memset(array_fvp, 0x00, sizeof(array_fvp));
		form_array_fvp_from_cfgdb_buf(sValue2, &count, array_fvp);
	
		for (i = 0; i < nAllMacEntries; i++) {
			/* store complete MAC list in global array */
			g_wlMacControlAllConfig[i].iid.cpeId.Id = atoi(array_fvp[3 * i].value);
			g_wlMacControlAllConfig[i].iid.pcpeId.Id = atoi(array_fvp[3 * i + 1].value);
			snprintf(g_wlMacControlAllConfig[i].macAddr, IFX_MAPI_MAC_ADDR_LEN,
				"%s", array_fvp[3 * i + 2].value);

			pcpeId = atoi(array_fvp[3 * i + 1].value);
			if (pcpeId == mainCpeId) {
				(*wlMacControl + nMacEntries)->iid.cpeId.Id =
					atoi(array_fvp[3 * i].value);
				(*wlMacControl + nMacEntries)->iid.pcpeId.Id = pcpeId;
				sprintf((*wlMacControl + nMacEntries)->iid.cpeId.secName, "%s",
					TAG_WLAN_MAC_CONTROL);
				sprintf((*wlMacControl + nMacEntries)->iid.pcpeId.secName, "%s",
					TAG_WLAN_SEC);
				snprintf((*wlMacControl + nMacEntries)->macAddr,
					 IFX_MAPI_MAC_ADDR_LEN, "%s", array_fvp[3 * i + 2].value);
				IFX_MAPI_DEBUG(fd,
					"/tmp/ifxMapiGetAllWlanMacControlEntries","macAddr: %s",
					(*wlMacControl + nMacEntries)->macAddr);
				nMacEntries++;
			}
		}
		g_flagMacControlAllConfig = 1;
	}
	else {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMacControlEntries",
			"g_nMacControlAll: %d", g_nMacControlAll);
		IFX_MEM_ALLOC((*wlMacControl), IFX_MAPI_WLAN_MAC_Control *,
			g_nMacControlAll, sizeof(IFX_MAPI_WLAN_MAC_Control))

		nMacEntries = 0;
		for (i = 0; i < g_nMacControlAll; i++) {
			pcpeId = g_wlMacControlAllConfig[i].iid.pcpeId.Id;
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMacControlEntries",
				"pcpeId: %d", pcpeId);
			if (pcpeId == mainCpeId) {
				(*wlMacControl + nMacEntries)->iid.cpeId.Id =
					g_wlMacControlAllConfig[i].iid.cpeId.Id;
				(*wlMacControl + nMacEntries)->iid.pcpeId.Id = pcpeId;
				sprintf((*wlMacControl + nMacEntries)->iid.cpeId.secName, "%s",
					 TAG_WLAN_MAC_CONTROL);
				sprintf((*wlMacControl + nMacEntries)->iid.pcpeId.secName, "%s",
					TAG_WLAN_SEC);
				snprintf((*wlMacControl + nMacEntries)->macAddr,
					IFX_MAPI_MAC_ADDR_LEN, "%s",
					g_wlMacControlAllConfig[i].macAddr);
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMacControlEntries",
					"macAddr: %s", (*wlMacControl + nMacEntries)->macAddr);
				nMacEntries++;
			}
		}
	}
	*numEntries = nMacEntries;
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMacControlEntries",
		       "numEntries: %d", *numEntries);

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMacControlEntries", "ret: %d",
		       ret);
	IFX_MEM_FREE(sValue2)
    /* in case of error free allocated memory here, otherwise it must be
		freed in calling function */
	if (ret != IFX_SUCCESS)
		IFX_MEM_FREE(*wlMacControl)

	return ret;
}

/**
   \param   numEntries  -

   \param   wlApCfg     - pointer to IFX_MAPI_WLAN_AP_Cfg structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ifx_mapi_get_all_wlan_ap_config(uint32 * numEntries,
				IFX_MAPI_WLAN_AP_Cfg ** wlApCfg, uint32 flags)
{
	int32 ret = IFX_SUCCESS, nCount = 0, i = 0;
	char8 sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN];
	uint32 outFlag = IFX_F_DEFAULT;

	LTQ_LOG_TIMESTAMP("Begin");
	IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_all_wlan_ap_config", "");

	/* get the count first */
	/* then for each object read object from wlan_main into buffer, parse
	   buffer to form array_fvp, from array_fvp fill to wlApCfg get wlansec
	   instance of this object from cpeId (where wlansec_<inst>_pcpeId=wlan
	   main instance cpeId) then get wep key instance of this object using
	   wlanwepkey_<obj_cpeId>_1_cpeId .... similarly wlanwpapskkey instance */

	MAKE_SECTION_COUNT_TAG(TAG_WLAN_MAIN, buf);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAIN,
				  buf, flags, &outFlag,
				  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	nCount = atoi(sValue);
	if (nCount == 0) {
		*numEntries = 0;
		*wlApCfg = NULL;
		goto IFX_Handler;
	}

	*wlApCfg = NULL;

	/*
	 * \todo
	 * get max number of supported VAPs from capabilities
	 * implement check for nCount with this value instead of hard-coded
	 * value below
	 */
	if (nCount <= 10) {
		IFX_MEM_ALLOC((*wlApCfg), IFX_MAPI_WLAN_AP_Cfg *, nCount,
			      sizeof(IFX_MAPI_WLAN_AP_Cfg))
	} else {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	for (i = 0; i < nCount; i++) {
		/*
		   get each of the wlan main (ap/vap) instance from the rc.conf file
		   and convert it to field value pair array to copy to output array of
		   wlan ap's */
		sprintf(buf, "%s_%d_cpeId", PREFIX_WLAN_MAIN, i);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAIN,
					  buf, IFX_F_GET_ANY, &outFlag,
					  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		(*wlApCfg + i)->iid.cpeId.Id = atoi(sValue);
		sprintf((*wlApCfg + i)->iid.cpeId.secName, "%s", TAG_WLAN_MAIN);

		(*wlApCfg + i)->main.iid.cpeId.Id = atoi(sValue);	/* fill cpeid
									   for main */
		sprintf((*wlApCfg + i)->main.iid.cpeId.secName, "%s",
			TAG_WLAN_MAIN);

		(*wlApCfg + i)->sec.iid.cpeId.Id = atoi(sValue);	/* fill pcpeid
									   for sec */
		sprintf((*wlApCfg + i)->sec.iid.cpeId.secName, "%s",
			TAG_WLAN_MAIN);

		sprintf(buf, "%s_%d_pcpeId", PREFIX_WLAN_MAIN, i);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAIN,
					  buf, IFX_F_GET_ANY, &outFlag,
					  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		(*wlApCfg + i)->iid.pcpeId.Id = atoi(sValue);
		sprintf((*wlApCfg + i)->iid.pcpeId.secName, "%s",
			TAG_LAN_DEVICE);

		(*wlApCfg + i)->main.iid.pcpeId.Id = atoi(sValue);	/* fill pcpeid
									   for main */
		sprintf((*wlApCfg + i)->main.iid.pcpeId.secName, "%s",
			TAG_LAN_DEVICE);

		(*wlApCfg + i)->sec.iid.pcpeId.Id = atoi(sValue);	/* fill pcpeid
									   for sec */
		sprintf((*wlApCfg + i)->sec.iid.pcpeId.secName, "%s",
			TAG_LAN_DEVICE);

		/*
		   call ifx_mapi_get_wlan_phy_config to get phy level radio parameters
		   for each ap/vap */
		if ((ret = ifx_mapi_get_wlan_phy_config(&(*wlApCfg + i)->phy,
			IFX_F_DEFAULT)) != IFX_SUCCESS) {
			goto IFX_Handler;
		}

		/*
		   call ifx_mapi_get_wlan_main_config to get wlan main section
		   parameters of each ap/vap; make sure cpeId and pcpeId is filled for
		   main before calling the api */
		if ((ret = ifx_mapi_get_wlan_main_config(&(*wlApCfg + i)->main,
			IFX_F_DEFAULT)) != IFX_SUCCESS) {
			goto IFX_Handler;
		}

		/*
		   call ifx_mapi_get_wlan_security_config to get wlan security
		   parameters of each ap/vap; make sure cpeId and pcpeId is filled for
		   main before calling the api */
		if ((ret = ifx_mapi_get_wlan_security_config(&(*wlApCfg + i)->sec,
			IFX_F_DEFAULT)) != IFX_SUCCESS) {
			goto IFX_Handler;
		}
	}
	*numEntries = nCount;

IFX_Handler:
	LTQ_LOG_TIMESTAMP("Done");
	IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_all_wlan_ap_config", "ret: %d", ret);
	return ret;
}

/**

   \param   wlApCfg  - pointer to IFX_MAPI_WLAN_AP_Cfg structure

   \param   flags    -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_ap_config(IFX_MAPI_WLAN_AP_Cfg * wlApCfg, uint32 flags)
{
	int32 ret = IFX_SUCCESS, i = 0;
	IFX_MAPI_WLAN_AP_WMM_Cfg *wlApWmm = NULL;
	IFX_MAPI_WLAN_STA_WMM_Cfg *wlStaWmm = NULL;
	uint32 numEntries = -1;
	LTQ_MAPI_WLAN_Feature	features = LTQ_MAPI_WLAN_FEATURE_NONE;

	IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_ap_config", "");
	switch (wlApCfg->iid.cpeId.Id) {
	case 1:
		LTQ_LOG_TIMESTAMP("AP");
		break;
	case 2:
		LTQ_LOG_TIMESTAMP("VAP1");
		break;
	case 3:
		LTQ_LOG_TIMESTAMP("VAP2");
		break;
	case 4:
		LTQ_LOG_TIMESTAMP("VAP3");
		break;
	}

	/*
	   probably redundant, should already have been initialized by calling
	   function */
	sprintf(wlApCfg->iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
	sprintf(wlApCfg->iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

	/*
	   call ifx_mapi_get_wlan_main_config to get wlan main section parameters
	   of each ap/vap; cpeId and pcpeId is filled with values from wlApCfg->iid
	 */
	sprintf(wlApCfg->main.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
	sprintf(wlApCfg->main.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
	wlApCfg->main.iid.cpeId.Id = wlApCfg->iid.cpeId.Id;
	if ((ret = ifx_mapi_get_wlan_main_config(&(wlApCfg->main), IFX_F_DEFAULT)) !=
		IFX_SUCCESS) {
		goto IFX_Handler;
	}

	/*
	   call ifx_mapi_get_wlan_phy_config to get phy level radio parameters for
	   each ap/vap cpeId of phy object can be taken from wlan_main object
	   (parameter radioCpeId) */
	sprintf(wlApCfg->phy.iid.cpeId.secName, "%s", TAG_WLAN_PHY);
	sprintf(wlApCfg->phy.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
	wlApCfg->phy.iid.cpeId.Id = wlApCfg->main.radioCpeId;
	wlApCfg->phy.iid.config_owner = wlApCfg->iid.config_owner;
	if ((ret = ifx_mapi_get_wlan_phy_config(&(wlApCfg->phy), IFX_F_DEFAULT)) !=
		IFX_SUCCESS) {
		goto IFX_Handler;
	}

	/*
	   call ifx_mapi_get_wlan_security_config to get wlan security parameters
	   of each ap/vap; cpeId and pcpeId is filled with values from wlApCfg->iid
	 */
	sprintf(wlApCfg->sec.iid.cpeId.secName, "%s", TAG_WLAN_SEC);
	sprintf(wlApCfg->sec.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
	wlApCfg->sec.iid.cpeId.Id = wlApCfg->iid.cpeId.Id;
	wlApCfg->sec.iid.config_owner = wlApCfg->iid.config_owner;
	if ((ret = ifx_mapi_get_wlan_security_config(&(wlApCfg->sec),
		IFX_F_DEFAULT)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}

	/*
	   call ifx_mapi_get_all_wlan_wmm_ap_config to get wlan wmm parameters of
	   each ap/vap; */
	if ((ret = ifx_mapi_get_all_wlan_wmm_ap_config(wlApCfg->iid.cpeId.Id,
						       &numEntries, &wlApWmm,
						       flags)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("[%s:%d] failed to get wmm outbound params for instance wlApCfg->apWmm",
		     __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	/* copy wmm ap parameters to ap configuration */
//   memcpy(wlApCfg->apWmm, wlApWmm, (sizeof(IFX_MAPI_WLAN_AP_WMM_Cfg) * numEntries));
	for (i = 0; i < numEntries; i++) {
		memcpy(&wlApCfg->apWmm[i], wlApWmm + i,
		       sizeof(IFX_MAPI_WLAN_AP_WMM_Cfg));
	}

	/*
	   call ifx_mapi_get_all_wlan_wmm_sta_config to get wlan wmm parameters of
	   each ap/vap; */
	if ((ret = ifx_mapi_get_all_wlan_wmm_sta_config(wlApCfg->iid.cpeId.Id,
							&numEntries, &wlStaWmm,
							flags)) !=
	    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("[%s:%d] failed to get wmm inbound params for instance wlApCfg->staWmm",
		     __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	/* copy wmm sta parameters to ap configuration */
//   memcpy(wlApCfg->staWmm, wlStaWmm, (sizeof(IFX_MAPI_WLAN_STA_WMM_Cfg) * numEntries));
	for (i = 0; i < numEntries; i++) {
		memcpy(&wlApCfg->staWmm[i], wlStaWmm + i,
		       sizeof(IFX_MAPI_WLAN_STA_WMM_Cfg));
	}

	features = ltq_mapi_get_wlan_supported_features(wlApCfg->phy.iid.cpeId.Id,
		IFX_F_DEFAULT);
	if (features & LTQ_MAPI_WLAN_FEATURE_WPS) {
		/*
		   call ifx_mapi_get_wlan_wps_config to get wlan wps parameters of each
		   ap/vap; */
		sprintf(wlApCfg->wps.iid.cpeId.secName, "%s", TAG_WLAN_WPS);
		sprintf(wlApCfg->wps.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
		wlApCfg->wps.iid.pcpeId.Id = wlApCfg->iid.cpeId.Id;
		wlApCfg->wps.iid.config_owner = wlApCfg->iid.config_owner;
		/*
		   \todo cpeId? */
		if ((ret = ifx_mapi_get_wlan_wps_config(&(wlApCfg->wps),
			IFX_F_DEFAULT)) != IFX_SUCCESS) {
			goto IFX_Handler;
		}

		/*
		   call ifx_mapi_get_wlan_wps_registrar_config to get wlan wps registrar
		   parameters of each ap/vap; */
		sprintf(wlApCfg->wpsRegs.iid.cpeId.secName, "%s",
			TAG_WLAN_WPS_REGISTRAR);
		sprintf(wlApCfg->wpsRegs.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
		wlApCfg->wpsRegs.iid.pcpeId.Id = wlApCfg->iid.cpeId.Id;
		/*
		   \todo cpeId? */
		if ((ret = ifx_mapi_get_wlan_wps_registrar_config(&(wlApCfg->wpsRegs),
			IFX_F_DEFAULT)) != IFX_SUCCESS) {
			goto IFX_Handler;
		}
	}

IFX_Handler:
	IFX_MEM_FREE(wlApWmm);
	IFX_MEM_FREE(wlStaWmm);
	LTQ_LOG_TIMESTAMP("Done");
	IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_ap_config", "ret: %d", ret);
	return ret;
}

/* Pramod - this api will return the global filter mode only in the structure */
int32 ifx_get_wlan_mac_control_status(WLAN_MAC_CONTROL * wlan_mac, uint32 flags)
{
	int32 ret = IFX_SUCCESS;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	uint32 outFlag = IFX_F_DEFAULT;

	/* get global mode */
	sprintf(buf, "%s_control", PREFIX_WLAN_GLOBAL_MAC_CONTROL);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL,
				  buf, flags, &outFlag,
				  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wlan_mac->global_mode = atoi(sValue);

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/**
   \param   glblMacControl - pointer to IFX_MAPI_GlobalMacControl config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
   \remarks
   - does compactcfgsection remove tags other than count and param related ??
     yes
   - why should wlanMacControl be pointer to pointer ??
     no, its sufficient to be a single pointer
   - as of now compactcfgsection assumes that possible tags in an instantiated section are
      section_name_Count
      prefix_index1_param1
      prefix_index1_param2
      ....
      prefix_index2_param1
      prefix_index2_param2
      ....
      any other tag than these may result in error or may be lost during compaction
      but this object has one section param global_mac_filter_mode
      support for this is not there as of now 27.08
      proposed section format is,
      section_param1=val1
      section_param2=val2
      ....
      section_name_Count
      prefix_index1_param1
      prefix_index1_param2
      ....
      prefix_index2_param1
      prefix_index2_param2
      ....
*/
int32
ifx_mapi_get_global_mac_control_entry(IFX_MAPI_GlobalMacControl * gMacControl,
				      uint32 flags)
{
	int32 ret = IFX_SUCCESS, passed_index = -1;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry", "");

	sprintf(gMacControl->iid.cpeId.secName, "%s",
		TAG_WLAN_GLOBAL_MAC_CONTROL);
	sprintf(gMacControl->iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

	/*
	   get index from cpeid: example gmaccntrl_1_cpeId="3" => passed_index = 1 */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, gMacControl->iid.cpeId,
				 passed_index)
//manohar
/* initialize the cache for this instance */
	    sprintf(buf, "%s_%d_", PREFIX_WLAN_GLOBAL_MAC_CONTROL,
		    passed_index);
	if (ifx_GetObjDataOpt
	    (FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL, buf,
	     IFX_F_INT_CACHE_INIT | flags, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance",
			__FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
//manohar

	sprintf(buf, "%s_%d_cpeId", PREFIX_WLAN_GLOBAL_MAC_CONTROL,
		passed_index);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL, buf,
			       flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry", "");
		goto IFX_Handler;
	}
	gMacControl->iid.cpeId.Id = atoi(sValue);
	sprintf(gMacControl->iid.cpeId.secName, "%s",
		TAG_WLAN_GLOBAL_MAC_CONTROL);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry", "cpeId: %d",
		       gMacControl->iid.cpeId.Id);

	sprintf(buf, "%s_%d_pcpeId", PREFIX_WLAN_GLOBAL_MAC_CONTROL,
		passed_index);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL, buf,
			       flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry", "");
		goto IFX_Handler;
	}
	gMacControl->iid.pcpeId.Id = atoi(sValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry",
		       "buf: %s, pcpeId: %d", buf, gMacControl->iid.pcpeId.Id);

	sprintf(buf, "%s_%d_ifType", PREFIX_WLAN_GLOBAL_MAC_CONTROL,
		passed_index);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL, buf,
			       flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry", "");
		goto IFX_Handler;
	}
	gMacControl->ifType = atoi(sValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry",
		       "buf: %s, ifType: %d", buf, gMacControl->ifType);

	sprintf(buf, "%s_%d_macAddr", PREFIX_WLAN_GLOBAL_MAC_CONTROL,
		passed_index);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL, buf,
			       flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry", "");
	}
	if (strlen(sValue) <= MAX_MAC_ADDR_LEN - 1) {
		sprintf(gMacControl->macAddr, "%s", sValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry",
			       "buf: %s, macAddr: %s", buf,
			       gMacControl->macAddr);
	} else {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry",
			       "sValue: %s", sValue);
	}

	/* get global mode */
	sprintf(buf, "%s_0_control", PREFIX_WLAN_GLOBAL_MAC_CONTROL);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL,
				  buf, flags, &outFlag,
				  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry", "");
		goto IFX_Handler;
	}
	gMacControl->cntrlMode = atoi(sValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry",
		       "buf: %s, control: %d", buf, gMacControl->cntrlMode);

      IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry", "ret: %d",
		       ret);
//manohar
	/* destroy the cache for this instance */
	sprintf(buf, "%s_%d_", PREFIX_WLAN_GLOBAL_MAC_CONTROL, passed_index);
	if (ifx_GetObjDataOpt
	    (FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL, buf,
	     IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to destroy cache for this instance",
			__FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
	}
//manohar
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/**
   \param   glblMacControl - pointer to IFX_MAPI_GlobalMacControl config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
   \remarks
   - does compactcfgsection remove tags other than count and param related ??
     yes
   - why should wlanMacControl be pointer to pointer ??
     no, its sufficient to be a single pointer
   - as of now compactcfgsection assumes that possible tags in an instantiated section are
      section_name_Count
      prefix_index1_param1
      prefix_index1_param2
      ....
      prefix_index2_param1
      prefix_index2_param2
      ....
      any other tag than these may result in error or may be lost during compaction
      but this object has one section param global_mac_filter_mode
      support for this is not there as of now 27.08
      proposed section format is,
      section_param1=val1
      section_param2=val2
      ....
      section_name_Count
      prefix_index1_param1
      prefix_index1_param2
      ....
      prefix_index2_param1
      prefix_index2_param2
      ....
*/
int32
ifx_mapi_get_wlan_mac_control_entry(IFX_MAPI_WLAN_MAC_Control * wlMacControl,
				    uint32 flags)
{
	int32 ret = IFX_SUCCESS, passed_index = -1;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];

	LTQ_LOG_TIMESTAMP();

	sprintf(wlMacControl->iid.cpeId.secName, "%s", TAG_WLAN_MAC_CONTROL);
	sprintf(wlMacControl->iid.pcpeId.secName, "%s", TAG_WLAN_SEC);

	/*
	   get index from cpeid: example wlMaccntrl_1_cpeId="3" => passed_index = 1
	 */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlMacControl->iid.cpeId,
				 passed_index)
//manohar
	    /* initialize the cache for this instance */
	    sprintf(buf, "%s_%d_", PREFIX_WLAN_MAC_CONTROL, passed_index);
	if (ifx_GetObjDataOpt
	    (FILE_RC_CONF, TAG_WLAN_MAC_CONTROL, buf,
	     IFX_F_INT_CACHE_INIT | flags, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance",
			__FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
//manohar

	sprintf(buf, "%s_%d_pcpeId", PREFIX_WLAN_MAC_CONTROL, passed_index);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAC_CONTROL,
				  buf, flags, &outFlag,
				  sValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMacControlEntry", "");
		goto IFX_Handler;
	}
	wlMacControl->iid.pcpeId.Id = atoi(sValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMacControlEntry",
		       "buf: %s, pcpeId: %d", buf, wlMacControl->iid.pcpeId.Id);

	sprintf(buf, "%s_%d_macAddr", PREFIX_WLAN_MAC_CONTROL, passed_index);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAC_CONTROL,
				  buf, flags, &outFlag,
				  sValue)) != IFX_SUCCESS) {
		goto IFX_Handler;
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMacControlEntry", "");
	}

	if (strlen(sValue) <= MAX_MAC_ADDR_LEN - 1) {
		sprintf(wlMacControl->macAddr, "%s", sValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMacControlEntry",
			       "macAddr: %s", wlMacControl->macAddr);
	} else {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMacControlEntry",
			       "sValue: %s", sValue);
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMacControlEntry",
		       "buf: %s, macAddr: %s", buf, wlMacControl->macAddr);

      IFX_Handler:
//manohar
	/* initialize the cache for this instance */
	sprintf(buf, "%s_%d_", PREFIX_WLAN_MAC_CONTROL, passed_index);
	if (ifx_GetObjDataOpt
	    (FILE_RC_CONF, TAG_WLAN_MAC_CONTROL, buf, IFX_F_INT_CACHE_DESTROY,
	     NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance",
			__FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
//manohar
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMacControlEntry", "ret: %d", ret);
	LTQ_LOG_TIMESTAMP();
	return ret;
}

/**

   \param   mainCpeId   -

   \param   numEntries  -

   \param   wlAssocInfo      - pointer to IFX_MAPI_WLAN_AssocInfo structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ifx_mapi_get_all_wlan_assoc_devices(uint32 mainCpeId,
				    uint32 * numEntries,
				    IFX_MAPI_WLAN_AssocInfo ** wlAssocInfo,
				    uint32 flags)
{
	int32 ret = IFX_SUCCESS, mac_count = 0, apIndex = -1, nDhcpClients = 0;
	int32 i = 0, j = 0;
	uint32 radioIdx = 0;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_DATA_LEN], sValueTmp[MAX_DATA_LEN];
	char8 sParam[MAX_FILELINE_LEN], *pTmpStr = NULL, *pTmpStr2 = NULL;
	char8 ip[MAX_FILELINE_LEN], hwType[MAX_FILELINE_LEN], arpFlags[MAX_FILELINE_LEN];
	char8 mask[MAX_FILELINE_LEN], device[MAX_FILELINE_LEN], hwAddr[MAX_FILELINE_LEN];
	DHCP_LEASE_INFO *lease_info = NULL;
	FILE *fp = NULL;
	CPE_ID cpeId;
	bool authState = 0, flagIpFound = 0;
	float lastDataRate;

	LTQ_LOG_TIMESTAMP("Begin");

	/* call staAssocIndAp here to get list of mac address of associated
	   stations */

	/*
	 * Get the Parent section count
	 * Get the first AP/VAP ssid
	 * Get the Corresponding APType
	 * Call the script to get List of Stations
	 * Malloc/calloc for no of stations
	 * Copy the SSID,MacAddress,AuthState,AssocState,ipaddr
	 * Continue for next AP/VAP
	 */

	*wlAssocInfo = NULL;

	memset(&cpeId, 0x00, sizeof(cpeId));

	cpeId.Id = mainCpeId;
	sprintf(cpeId.secName, "%s", TAG_WLAN_MAIN);

	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpeId, apIndex)
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "apIndex: %d",
		apIndex);

	/* if AP is disabled, no need to get the associated device list */
	if (g_flagMainConfig) {
		if (!g_wlMain[apIndex].apEnable) {
			*numEntries = 0;
			LTQ_LOG_TIMESTAMP("Done");
			return IFX_SUCCESS;
		}
	}

	/* get dhcp leases to obtain ip address below */
    ret = ifx_get_lan_dhcp_leases(&nDhcpClients, &lease_info, flags);
	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "");
		goto IFX_Handler;
	} else {
		for (i = 0; i < nDhcpClients; i++) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
				       "macAddr_%d: %s", i,
				       (lease_info + i)->cli_id);
		}
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
		       "nDhcpClients: %d", nDhcpClients);
	NULL_TERMINATE(buf, 0x00, sizeof(buf));

	if (apIndex < 0) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
			       "passed_index: %d", apIndex);
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	sprintf(buf, "%s %d", SERVICE_WLAN_GET_ASSOC_DEV, apIndex);
	memset(sValue, 0x00, sizeof(sValue));

	if (ifx_GetCfgData((char8 *) buf, NULL, "-1", sValue) == 0) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "sValue: %s",
		       sValue);
	/* save buffer in sValueTmp */
	strcpy(sValueTmp, sValue);

	if ((pTmpStr = strstr(sValue, "assoc_count=")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		mac_count = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
			       "mac_count: %d", mac_count);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
			       "sValue: %s", sValue);

	radioIdx = g_wlMain[apIndex].radioCpeId - 1;
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "radioIdx: %d", radioIdx);
	if ((mac_count > 0) && (mac_count <= g_wlCaps[radioIdx].maxWlanClients)) {
		IFX_MEM_ALLOC((*wlAssocInfo), IFX_MAPI_WLAN_AssocInfo *,
			      mac_count, sizeof(IFX_MAPI_WLAN_AssocInfo))
	} else {
		*numEntries = 0;
		if (mac_count == 0)
			ret = IFX_SUCCESS;
		else
			ret = IFX_FAILURE;

		goto IFX_Handler;
	}

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	system("cat /proc/net/arp > /tmp/try");
	for (i = 0; i < mac_count; i++) {
		sprintf(sParam, "mac_%d=", i);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
			       "sParam: %s", sParam);
		if ((pTmpStr = strstr(sValue, sParam)) != NULL) {
			pTmpStr2 = strtok(pTmpStr, "\"");
			if (pTmpStr2 == NULL) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			pTmpStr2 = strtok(NULL, "\"");
			if (pTmpStr2 == NULL) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			sprintf((*wlAssocInfo + i)->macAddress, "%s", pTmpStr2);
			ifx_make_canonical_key((*wlAssocInfo + i)->macAddress);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
				       "macAddress: %s",
				       (*wlAssocInfo + i)->macAddress);
		}
		/* restore sValue buffer from sValueTmp */
		strcpy(sValue, sValueTmp);

		/*
		   check for each entry in dhcp lease list, if the mac address is
		   equal, if yes get the corresponding ip address */
		flagIpFound = 0;
		for (j = 0; j < nDhcpClients; j++) {
			char8 lease_mac[MAX_MAC_ADDR_LEN];

			strcpy(lease_mac, (lease_info + j)->cli_id);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
				       "lease_mac: %s", lease_mac);
			ifx_make_canonical_key(lease_mac);
			if (!(strcmp(lease_mac, (*wlAssocInfo + i)->macAddress)))
			{
				pTmpStr = inet_ntoa((lease_info + j)->ip);
				inet_aton(pTmpStr,
					  &(*wlAssocInfo + i)->ipAddress);
				IFX_MAPI_DEBUG(fd,
					       "/tmp/ifxMapiGetAllWlanAssocDevices",
					       "ipAddr: %s",
					       inet_ntoa((*wlAssocInfo +
							  i)->ipAddress));
				flagIpFound = 1;
				break;
			} else {
				IFX_MAPI_DEBUG(fd,
					       "/tmp/ifxMapiGetAllWlanAssocDevices",
					       "lease_mac: %s, wlan_mac: %s",
					       lease_mac,
					       (*wlAssocInfo + i)->macAddress);
			}
		}
		/* if IP not found in DHCP lease list, also check arp table */
		if (flagIpFound == 0) {
			fp = fopen("/tmp/try", "r");
			if (fp != NULL) {
				fgets(device, MAX_FILELINE_LEN, fp);
				while (fscanf
				       (fp,
					"%[^ ] %[^ ] %[^ ] %[^ ] %[^ ] %[^\n]\n",
					ip, hwType, arpFlags, hwAddr, mask,
					device) > 0) {
					ifx_make_canonical_key(hwAddr);
					if (!
					    (strcmp
					     (hwAddr,
					      (*wlAssocInfo +
					       i)->macAddress))) {
						inet_aton(ip,
							  &(*wlAssocInfo +
							    i)->ipAddress);
						IFX_MAPI_DEBUG(fd,
							       "/tmp/ifxMapiGetAllWlanAssocDevices",
							       "ipAddr: %s",
							       inet_ntoa((*wlAssocInfo + i)->ipAddress));
						break;
					} else {
						IFX_MAPI_DEBUG(fd,
							       "/tmp/ifxMapiGetAllWlanAssocDevices",
							       "mac: %s, wlan_mac: %s",
							       hwAddr,
							       (*wlAssocInfo +
								i)->macAddress);
					}
				}
				fclose(fp);
			}
		}

		sprintf(sParam, "auth_%d=", i);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
			       "sParam: %s", sParam);
		if ((pTmpStr = strstr(sValue, sParam)) != NULL) {
			pTmpStr2 = strtok(pTmpStr, "\"");
			if (pTmpStr2 == NULL) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			pTmpStr2 = strtok(NULL, "\"");
			if (pTmpStr2 == NULL) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			if ((authState = atoi(pTmpStr2)))
				(*wlAssocInfo + i)->staAuthenticated =
				    IFX_MAPI_WLAN_STA_AUTHENTICATED;
			else
				(*wlAssocInfo + i)->staAuthenticated =
				    IFX_MAPI_WLAN_STA_UNAUTHENTICATED;
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
				       "authState: %d",
				       (*wlAssocInfo + i)->staAuthenticated);
		}
		/* restore sValue buffer from sValueTmp */
		strcpy(sValue, sValueTmp);

		sprintf(sParam, "rate_%d=", i);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
			       "sParam: %s", sParam);
		if ((pTmpStr = strstr(sValue, sParam)) != NULL) {
			pTmpStr2 = strtok(pTmpStr, "\"");
			if (pTmpStr2 == NULL) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			pTmpStr2 = strtok(NULL, "\"");
			if (pTmpStr2 == NULL) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			lastDataRate = (float)strtod(pTmpStr2, (char **)NULL);
			(*wlAssocInfo + i)->lastDataTxRate = lastDataRate;
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
				       "dataRate: %f",
				       (*wlAssocInfo + i)->lastDataTxRate);
		}
		/* restore sValue buffer from sValueTmp */
		strcpy(sValue, sValueTmp);

		sprintf(sParam, "wpa2UCcipher_%d=", i);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
			       "sParam: %s", sParam);
		if ((pTmpStr = strstr(sValue, sParam)) != NULL) {
			pTmpStr2 = strtok(pTmpStr, "\"");
			if (pTmpStr2 == NULL) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			pTmpStr2 = strtok(NULL, "\"");
			if (pTmpStr2 == NULL) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			sprintf((*wlAssocInfo + i)->wpa2LastUCcipher, "%s",
				pTmpStr2);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
				       "wpa2LastUCcipher: %s",
				       (*wlAssocInfo + i)->wpa2LastUCcipher);
		}
		/* restore sValue buffer from sValueTmp */
		strcpy(sValue, sValueTmp);

		sprintf(sParam, "wpa2MCcipher%d=", i);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
			       "sParam: %s", sParam);
		if ((pTmpStr = strstr(sValue, sParam)) != NULL) {
			pTmpStr2 = strtok(pTmpStr, "\"");
			if (pTmpStr2 == NULL) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			pTmpStr2 = strtok(NULL, "\"");
			if (pTmpStr2 == NULL) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			sprintf((*wlAssocInfo + i)->wpa2LastMCcipher, "%s",
				pTmpStr2);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
				       "wpa2LastMCcipher: %s",
				       (*wlAssocInfo + i)->wpa2LastMCcipher);
		}
		/* restore sValue buffer from sValueTmp */
		strcpy(sValue, sValueTmp);

		sprintf(sParam, "wpa2PMK%d=", i);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
			       "sParam: %s", sParam);
		if ((pTmpStr = strstr(sValue, sParam)) != NULL) {
			pTmpStr2 = strtok(pTmpStr, "\"");
			if (pTmpStr2 == NULL) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			pTmpStr2 = strtok(NULL, "\"");
			if (pTmpStr2 == NULL) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			sprintf((*wlAssocInfo + i)->wpa2LastPMKId, "%s",
				pTmpStr2);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
				       "wpa2LastPMKId: %s",
				       (*wlAssocInfo + i)->wpa2LastPMKId);
		}
		/* restore sValue buffer from sValueTmp */
		strcpy(sValue, sValueTmp);
	}
	system("rm -f /tmp/try");

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
		       "mac_count: %d", mac_count);
	*numEntries = mac_count;

      IFX_Handler:
	IFX_MEM_FREE(lease_info);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "ret: %d",
		       ret);
	LTQ_LOG_TIMESTAMP("Done");
	if (ret != IFX_SUCCESS) {
		*numEntries = 0;
		IFX_MEM_FREE(*wlAssocInfo);
		return ret;
	} else
		return IFX_SUCCESS;
}

/**
   \param   phyCpeId   -

   \param   wlSuppRates      - pointer to WLAN IFX_MAPI_WLAN_SupportedRate structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE

   \remarks - mode(standard) is input here
*/
int32
ifx_mapi_get_wlan_supported_datarates(uint32 phyCpeId,
				      IFX_MAPI_WLAN_SupportedRate * wlSuppRates,
				      uint32 flags)
{
	int32 i = 0;

	memset(wlSuppRates->dataRate, 0x00, sizeof(wlSuppRates->dataRate));
	switch (wlSuppRates->std) {
	case IFX_MAPI_WLAN_STD_802_11A:
		for (i = 0; i < basic_data_rates_11a.length; i++)
			wlSuppRates->dataRate[i] =
			    basic_data_rates_11a.rates[i];
		break;
	case IFX_MAPI_WLAN_STD_802_11B:
		for (i = 0; i < basic_data_rates_11b.length; i++)
			wlSuppRates->dataRate[i] =
			    basic_data_rates_11b.rates[i];
		break;
	case IFX_MAPI_WLAN_STD_802_11BG:
	case IFX_MAPI_WLAN_STD_802_11G:
		for (i = 0; i < basic_data_rates_11bg.length; i++)
			wlSuppRates->dataRate[i] =
			    basic_data_rates_11bg.rates[i];
		break;
	case IFX_MAPI_WLAN_STD_802_11N:
	case IFX_MAPI_WLAN_STD_802_11BGN:
	case IFX_MAPI_WLAN_STD_802_11GN:
	case IFX_MAPI_WLAN_STD_802_11AN:
	default:
		return IFX_FAILURE;
		break;
	}

	return IFX_SUCCESS;
}

/**
   \param   phyCpeId   -

   \param   wlChanList      - pointer to WLAN IFX_MAPI_WLAN_ChannelList structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE

   \remarks - mode(standard) and country is input here
            - the api should not use mode and country as input, it should call
               appropriate api with type as ap to get possible channel list for
               the current configuration only, as list of combinations is not
               given by this api
*/
int32
ifx_mapi_get_wlan_channel_list(uint32 phyCpeId,
			       IFX_MAPI_WLAN_ChannelList * wlChanList,
			       uint32 flags)
{
	uint32 i = 0;
	IFX_MAPI_WLAN_RegDomain chList;
	uint8 country = 0;

	memset(&chList, 0x00, sizeof(IFX_MAPI_WLAN_RegDomain));
	IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_channel_list",
		       "wlChanList->std:%d, wlChanList->country:%s, wlChanList->freqBand:%d",
		       wlChanList->std, wlChanList->country,
		       wlChanList->freqBand);

	if (strcmp(wlChanList->country, "IN") == 0)
		country = IFX_MAPI_WLAN_COUNTRY_INDIA;
	else if (strcmp(wlChanList->country, "US") == 0)
		country = IFX_MAPI_WLAN_COUNTRY_US;
	else if (strcmp(wlChanList->country, "CA") == 0)
		country = IFX_MAPI_WLAN_COUNTRY_IC;
	else if (strcmp(wlChanList->country, "FR") == 0)
		country = IFX_MAPI_WLAN_COUNTRY_FRANCE;
	else if (strcmp(wlChanList->country, "DE") == 0)
		country = IFX_MAPI_WLAN_COUNTRY_GER;
	else if (strcmp(wlChanList->country, "ES") == 0)
		country = IFX_MAPI_WLAN_COUNTRY_ESP;
	else if (strcmp(wlChanList->country, "CN") == 0)
		country = IFX_MAPI_WLAN_COUNTRY_CHINA;
	else if (strcmp(wlChanList->country, "JP") == 0)
		country = IFX_MAPI_WLAN_COUNTRY_JAPAN;
	else
		country = IFX_MAPI_WLAN_COUNTRY_US;

	switch (wlChanList->std) {
	case IFX_MAPI_WLAN_STD_802_11A:
	case IFX_MAPI_WLAN_STD_802_11AN:
	case IFX_MAPI_WLAN_STD_802_11AC:
	case IFX_MAPI_WLAN_STD_802_11ACN:
	case IFX_MAPI_WLAN_STD_802_11ACNA:
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_channel_list",
			       "std:%d", wlChanList->std);
		switch (country) {
			case IFX_MAPI_WLAN_COUNTRY_INDIA:
			case IFX_MAPI_WLAN_COUNTRY_US:
			case IFX_MAPI_WLAN_COUNTRY_IC:
				chList = regDomainWorld_11a;
				break;
			case IFX_MAPI_WLAN_COUNTRY_FRANCE:
			case IFX_MAPI_WLAN_COUNTRY_GER:
			case IFX_MAPI_WLAN_COUNTRY_ETSI:
			case IFX_MAPI_WLAN_COUNTRY_ESP:
				chList = regDomainEurope_11a;
				break;
			case IFX_MAPI_WLAN_COUNTRY_CHINA:
				chList = regDomainChina_11a;
				break;
			case IFX_MAPI_WLAN_COUNTRY_JAPAN:
				chList = regDomainJapan_11a;
				break;
			default:
				break;
			}
		break;
	case IFX_MAPI_WLAN_STD_802_11B:
	case IFX_MAPI_WLAN_STD_802_11G:
	case IFX_MAPI_WLAN_STD_802_11BG:
	case IFX_MAPI_WLAN_STD_802_11BGN:
	case IFX_MAPI_WLAN_STD_802_11GN:
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_channel_list",
			       "std:%d", wlChanList->std);
		switch (country) {
		case IFX_MAPI_WLAN_COUNTRY_INDIA:
		case IFX_MAPI_WLAN_COUNTRY_US:
		case IFX_MAPI_WLAN_COUNTRY_IC:
			chList = regDomainUSA_11g;
			break;
		case IFX_MAPI_WLAN_COUNTRY_CHINA:
		case IFX_MAPI_WLAN_COUNTRY_FRANCE:
		case IFX_MAPI_WLAN_COUNTRY_GER:
		case IFX_MAPI_WLAN_COUNTRY_ETSI:
		case IFX_MAPI_WLAN_COUNTRY_ESP:
			chList = regDomainWorld_11g;
			break;
		case IFX_MAPI_WLAN_COUNTRY_JAPAN:
			/*
			   in 802.11b mode Japan allows channel 1 to 14, in
			   802.11bg, 802.11g and 802.11n only channel 1 to 13 is
			   allowed */
			if (wlChanList->std == IFX_MAPI_WLAN_STD_802_11B)
				chList = regDomainJapan_11b;
			else
				chList = regDomainJapan_11g;
			break;
		default:
			chList = regDomainWorld_11g;
			break;
		}
		break;
	case IFX_MAPI_WLAN_STD_802_11N:
		if (wlChanList->freqBand != IFX_MAPI_WLAN_2_4_GHz_Freq) {
				switch (country) {
				case IFX_MAPI_WLAN_COUNTRY_INDIA:
				case IFX_MAPI_WLAN_COUNTRY_US:
				case IFX_MAPI_WLAN_COUNTRY_IC:
					chList = regDomainWorld_11a;
					break;
				case IFX_MAPI_WLAN_COUNTRY_FRANCE:
				case IFX_MAPI_WLAN_COUNTRY_GER:
				case IFX_MAPI_WLAN_COUNTRY_ETSI:
				case IFX_MAPI_WLAN_COUNTRY_ESP:
					chList = regDomainEurope_11a;
					break;
				case IFX_MAPI_WLAN_COUNTRY_CHINA:
					chList = regDomainChina_11a;
					break;
				case IFX_MAPI_WLAN_COUNTRY_JAPAN:
					chList = regDomainJapan_11a;
					break;
				default:
					break;
				}
		} else {
			switch (country) {
			case IFX_MAPI_WLAN_COUNTRY_INDIA:
			case IFX_MAPI_WLAN_COUNTRY_US:
			case IFX_MAPI_WLAN_COUNTRY_IC:
				chList = regDomainUSA_11g;
				break;
			case IFX_MAPI_WLAN_COUNTRY_CHINA:
			case IFX_MAPI_WLAN_COUNTRY_FRANCE:
			case IFX_MAPI_WLAN_COUNTRY_GER:
			case IFX_MAPI_WLAN_COUNTRY_ETSI:
			case IFX_MAPI_WLAN_COUNTRY_ESP:
				chList = regDomainWorld_11g;
				break;
			case IFX_MAPI_WLAN_COUNTRY_JAPAN:
				/*
				 * in 802.11b mode Japan allows channel 1 to 14, in 802.11bg,
				 * 802.11g and 802.11n only channel 1 to 13 is allowed:
				 * here we are in 802.11n case */
				chList = regDomainJapan_11g;
				break;
			default:
				chList = regDomainWorld_11g;
				break;
			}
		}
		break;
	default:
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_channel_list",
			       "failure");
		return IFX_FAILURE;
	}

	for (i = 0; i < chList.length; i++)
		wlChanList->chanNumList[i] = chList.channels[i];
	wlChanList->chanNumList[i] = 0;
	wlChanList->length = chList.length;
	LTQ_LOG_TIMESTAMP("Done");
	return IFX_SUCCESS;
}

/**

   \param   wlStats      - pointer to IFX_MAPI_WLAN_Stats structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_stats(IFX_MAPI_WLAN_Stats * wlStats, uint32 flags)
{
	int32 ret = IFX_SUCCESS, passedIndex = -1;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_DATA_LEN];
	char8 sParamValue[MAX_FILELINE_LEN];
	CPE_ID cpe_id;
	int32	vendor = LTQ_MAPI_WLAN_VENDOR_NONE;

	switch (wlStats->iid.cpeId.Id) {
	case 1:
		LTQ_LOG_TIMESTAMP("AP");
		break;
	case 2:
		LTQ_LOG_TIMESTAMP("VAP1");
		break;
	case 3:
		LTQ_LOG_TIMESTAMP("VAP2");
		break;
	case 4:
		LTQ_LOG_TIMESTAMP("VAP3");
		break;
	}

	memset(&cpe_id, 0x00, sizeof(cpe_id));
	cpe_id.Id = wlStats->iid.cpeId.Id;
	sprintf(cpe_id.secName, "%s", TAG_WLAN_MAIN);
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpe_id, passedIndex)
	    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "passedIndex: %d",
			   passedIndex);
	if (passedIndex < 0) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats",
			       "passed_index: %d", passedIndex);
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* get vendor information */
	vendor = ltq_mapi_get_wlan_vendor(g_wlMain[passedIndex].radioCpeId, IFX_F_DEFAULT);
	if (vendor == LTQ_MAPI_WLAN_VENDOR_NONE) {
		/* do not call any scripts if vendor is unknown
			(probably no WLAN card connected) */
		goto IFX_Handler;
	}

	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	memset(sValue, 0x00, sizeof(sValue));
	sprintf(buf, "%s %d", SERVICE_WLAN_GET_STATS, passedIndex);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "buf: %s", buf);

	LTQ_LOG_TIMESTAMP("SERVICE_WLAN_GET_STATS Begin");
	if (ifx_GetCfgData((char8 *) buf, NULL, "-1", sValue) == 0) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	LTQ_LOG_TIMESTAMP("SERVICE_WLAN_GET_STATS Done");
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "sValue: %s", sValue);

	/* save buffer in sResultFromScript */
	strcpy(sResultFromScript, sValue);

	if ((ret = ltq_get_param("bytesTx=", sParamValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats",
			       "bytesTx not available");
	}
	else {
		wlStats->bytesTx = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "bytesTx: %d",
				   wlStats->bytesTx);
	}

	if ((ret = ltq_get_param("bytesRx=", sParamValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats",
			       "bytesTx not available");
	}
	else {
		wlStats->bytesRx = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "bytesRx: %d",
				   wlStats->bytesRx);
	}

	if ((ret = ltq_get_param("errorsTx=", sParamValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats",
			       "errorsTx not available");
	}
	else {
		wlStats->errorsTx = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "errorsTx: %d",
				   wlStats->errorsTx);
	}

	if ((ret = ltq_get_param("errorsRx=", sParamValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats",
			       "errorsRx not available");
	}
	else {
		wlStats->errorsRx = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "errorsRx: %d",
				   wlStats->errorsRx);
	}

	if ((ret = ltq_get_param("pktsTx=", sParamValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats",
			       "pktsTx not available");
	}
	else {
		wlStats->pktsTx = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "pktsTx: %d",
				   wlStats->pktsTx);
	}

	if ((ret = ltq_get_param("pktsRx=", sParamValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats",
			       "pktsRx not available");
	}
	else {
		wlStats->pktsRx = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "pktsRx: %d",
				   wlStats->pktsRx);
	}

	if ((ret = ltq_get_param("ucPktsTx=", sParamValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats",
			       "ucPktsTx not available");
	}
	else {
		wlStats->ucPktsTx = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "ucPktsTx: %d",
				   wlStats->ucPktsTx);
	}

	if ((ret = ltq_get_param("ucPktsRx=", sParamValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats",
			       "ucPktsRx not available");
	}
	else {
		wlStats->ucPktsRx = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "ucPktsRx: %d",
				   wlStats->ucPktsRx);
	}

	if ((ret = ltq_get_param("mcPktsTx=", sParamValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats",
			       "mcPktsTx not available");
	}
	else {
		wlStats->mcPktsTx = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "mcPktsTx: %d",
				   wlStats->mcPktsTx);
	}

	if ((ret = ltq_get_param("mcPktsRx=", sParamValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats",
			       "mcPktsRx not available");
	}
	else {
		wlStats->mcPktsRx = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "mcPktsRx: %d",
				   wlStats->mcPktsRx);
	}

	if ((ret = ltq_get_param("bcPktsTx=", sParamValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats",
			       "bcPktsTx not available");
	}
	else {
		wlStats->bcPktsTx = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "bcPktsTx: %d",
				   wlStats->bcPktsTx);
	}

	if ((ret = ltq_get_param("bcPktsRx=", sParamValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats",
			       "bcPktsRx not available");
	}
	else {
		wlStats->bcPktsRx = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "bcPktsRx: %d",
				   wlStats->bcPktsRx);
	}

	if ((ret = ltq_get_param("discardPktsTx=", sParamValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats",
			       "discardPktsTx not available");
	}
	else {
		wlStats->discardPktsTx = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "discardPktsTx: %d",
				   wlStats->discardPktsTx);
	}

	if ((ret = ltq_get_param("discardPktsRx=", sParamValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats",
			       "discardPktsRx not available");
	}
	else {
		wlStats->discardPktsRx = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "discardPktsRx: %d",
				   wlStats->discardPktsRx);
	}

IFX_Handler:
	LTQ_LOG_TIMESTAMP("Done");
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "ret: %d", ret);
	return ret;
}

/**

   \param   wlStats      - pointer to IFX_MAPI_WLAN_Stats structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_phy_stats(IFX_MAPI_WLAN_PhyStats * wlPhyStats, uint32 flags)
{
	int32 ret = IFX_SUCCESS, passedIndex = -1;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_DATA_LEN];
	char8 sParamValue[MAX_FILELINE_LEN];
	CPE_ID cpe_id;

	LTQ_LOG_TIMESTAMP("Begin");

	memset(&cpe_id, 0x00, sizeof(cpe_id));
	cpe_id.Id = wlPhyStats->iid.cpeId.Id;
	sprintf(cpe_id.secName, "%s", TAG_WLAN_MAIN);
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpe_id, passedIndex)

	if (passedIndex < 0) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats",
			       "passed_index: %d", passedIndex);
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	memset(sValue, 0x00, sizeof(sValue));
	sprintf(buf, "%s %d", SERVICE_WLAN_GET_ADVANCED_STATS, passedIndex);
	IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats", "buf: %s", buf);

	if (ifx_GetCfgData((char8 *) buf, NULL, "-1", sValue) == 0) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats", "sValue: %s", sValue);
	if (!strlen(sValue)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats",
				"strlen(sValue): %d", strlen(sValue));
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* save buffer in sResultFromScript */
	strcpy(sResultFromScript, sValue);

	/*
	 * FCS Error Count
	 */
	if (ltq_get_param("FCSErrorCount=", sParamValue) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats",
			       "FCSErrorCount not available");
	}
	else {
		wlPhyStats->fcsErrorCount = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats", "fcsErrorCount: %d",
				wlPhyStats->fcsErrorCount);
	}

	/*
	 * RTS Success Count
	 */
	if (ltq_get_param("RTSSuccessCount=", sParamValue) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats",
			       "rtsSuccessCount not available");
	}
	else {
		wlPhyStats->rtsSuccessCount = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats", "rtsSuccessCount: %d",
				wlPhyStats->rtsSuccessCount);
	}

	/*
	 * RTS Failure Count
	 */
	if (ltq_get_param("RTSFailureCount=", sParamValue) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats",
			       "rtsFailureCount not available");
	}
	else {
		wlPhyStats->rtsFailureCount = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats", "rtsFailureCount: %d",
				wlPhyStats->rtsFailureCount);
	}

	/*
	 * Free TX MSDU's
	 */
	if (ltq_get_param("FreeTxMSDUs=", sParamValue) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats",
			       "freeTxMSDUs not available");
	}
	else {
		wlPhyStats->freeTxMSDUs = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats", "freeTxMSDUs: %d",
				wlPhyStats->freeTxMSDUs);
	}

	/*
	 * TX MSDU's Usage Peak
	 */
	if (ltq_get_param("TxMSDUsUsagePeak=", sParamValue) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats",
			       "TxMSDUsUsagePeak not available");
	}
	else {
		wlPhyStats->txMSDUsUsagePeak = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats", "txMSDUsUsagePeak: %d",
				wlPhyStats->txMSDUsUsagePeak);
	}

	/*
	 * BIST check passed
	 */
	if (ltq_get_param("BISTCheckPassed=", sParamValue) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats",
			       "BISTCheckPassed not available");
	}
	else {
		wlPhyStats->bistCheckPassed = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats", "bistCheckPassed: %d",
				wlPhyStats->bistCheckPassed);
	}

	/*
	 * MAN Messages Sent
	 */
	if (ltq_get_param("MANMsgSent=", sParamValue) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats",
			       "MANMsgSent not available");
	}
	else {
		wlPhyStats->manMsgSent = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats", "manMsgSent: %d",
				wlPhyStats->manMsgSent);
	}

	/*
	 * MAN Messages Confirmed
	 */
	if (ltq_get_param("MANMsgConfirmed=", sParamValue) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats",
			       "MANMsgConfirmed not available");
	}
	else {
		wlPhyStats->manMsgConfirmed = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats", "manMsgConfirmed: %d",
				wlPhyStats->manMsgConfirmed);
	}

	/*
	 * MAN Messages Peak
	 */
	if (ltq_get_param("MANMsgPeak=", sParamValue) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats",
			       "MANMsgPeak not available");
	}
	else {
		wlPhyStats->manMsgPeak = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats", "manMsgPeak: %d",
				wlPhyStats->manMsgPeak);
	}

	/*
	 * DBG Messages Sent
	 */
	if (ltq_get_param("DBGMsgSent=", sParamValue) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats",
			       "DBGMsgSent not available");
	}
	else {
		wlPhyStats->dbgMsgSent = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats", "dbgMsgSent: %d",
				wlPhyStats->dbgMsgSent);
	}

	/*
	 * DBG Messages Confirmed
	 */
	if (ltq_get_param("DBGMsgConfirmed=", sParamValue) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats",
			       "DBGMsgConfirmed not available");
	}
	else {
		wlPhyStats->dbgMsgConfirmed = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats", "dbgMsgConfirmed: %d",
				wlPhyStats->dbgMsgConfirmed);
	}

	/*
	 * DBG Messages Peak
	 */
	if (ltq_get_param("DBGMsgPeak=", sParamValue) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats",
			       "DBGMsgPeak not available");
	}
	else {
		wlPhyStats->dbgMsgPeak = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats", "dbgMsgPeak: %d",
				wlPhyStats->dbgMsgPeak);
	}

	/*
	 * FW Logger Packets Processed
	 */
	if (ltq_get_param("FWLoggerPacketsProcessed=", sParamValue) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats",
			       "FWLoggerPacketsProcessed not available");
	}
	else {
		wlPhyStats->fwLoggerPacketsProcessed = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats", "fwLoggerPacketsProcessed: %d",
				wlPhyStats->fwLoggerPacketsProcessed);
	}

	/*
	 * FW Logger Packets Dropped
	 */
	if (ltq_get_param("FWLoggerPacketsDropped=", sParamValue) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats",
			       "FWLoggerPacketsDropped not available");
	}
	else {
		wlPhyStats->fwLoggerPacketsDropped = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats", "fwLoggerPacketsDropped: %d",
				wlPhyStats->fwLoggerPacketsDropped);
	}

	/*
	 * DAT Frames Received
	 */
	if (ltq_get_param("DATFramesReceived=", sParamValue) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats",
			       "DATFramesReceived not available");
	}
	else {
		wlPhyStats->datFramesReceived = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats", "datFramesReceived: %d",
				wlPhyStats->datFramesReceived);
	}

	/*
	 * CTL Frames Received
	 */
	if (ltq_get_param("CTLFramesReceived=", sParamValue) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats",
			       "CTLFramesReceived not available");
	}
	else {
		wlPhyStats->ctlFramesReceived = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats", "ctlFramesReceived: %d",
				wlPhyStats->ctlFramesReceived);
	}

	/*
	 * MAN Frames Received
	 */
	if (ltq_get_param("MANFramesReceived=", sParamValue) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats",
			       "MANFramesReceived not available");
	}
	else {
		wlPhyStats->manFramesReceived = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_phy_stats", "manFramesReceived: %d",
				wlPhyStats->manFramesReceived);
	}

IFX_Handler:
	LTQ_LOG_TIMESTAMP("Done");
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]: ret: %d", __FUNCTION__, __LINE__, ret);
#endif
		return IFX_FAILURE;
	} else
		return IFX_SUCCESS;
}

/**
   This api reads

   \param   wlRadius

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ifx_mapi_get_wlan_802_1x_config(IFX_MAPI_WLAN_802_1x * wlRadius, uint32 flags)
{
	int32 ret = IFX_SUCCESS;
	int32 passed_index = -1, count, i;
	char8 buf[MAX_DATA_LEN], *sValueNew = NULL;
	char8 radSecretInAscii[IFX_MAPI_PSK_MAX_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_802_1X_PARAM_COUNT];
	IFX_MAPI_WLAN_MainCfg wlMain;
	int32	vendor = LTQ_MAPI_WLAN_VENDOR_NONE;

	LTQ_LOG_TIMESTAMP("Begin");
	sprintf(wlRadius->iid.cpeId.secName, "%s", TAG_WLAN_1X);
	sprintf(wlRadius->iid.pcpeId.secName, "%s", TAG_WLAN_1X);
	IFX_GET_INDEX_FROM_PCPEID(FILE_RC_CONF, wlRadius->iid.pcpeId,
				  passed_index)
	    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlan8021xConfig",
			   "passed_index: %d", passed_index);

	/* get wps object from rc.conf */
	sprintf(buf, "%s_%d_", PREFIX_WLAN_SEC_1X, passed_index);
	if ((ret =
	     ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_1X, buf, IFX_F_DEFAULT,
			      &sValueNew)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlan8021xConfig", "buf: %s",
			       buf);
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlan8021xConfig",
		       "buf: %s, sValue: %s", buf, sValueNew);

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sValueNew, &count, array_fvp);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlan8021xConfig", "count: %d",
		       count);
	for (i = 0; i < count; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlan8021xConfig", "%s:%s",
			       array_fvp[i].fieldname, array_fvp[i].value);

	wlRadius->iid.cpeId.Id = atoi(array_fvp[0].value);
	wlRadius->iid.pcpeId.Id = atoi(array_fvp[1].value);
	wlRadius->groupKeyEna = atoi(array_fvp[2].value);
	wlRadius->groupKeyIntvl = atoi(array_fvp[3].value);
	wlRadius->wpa2PreAuthEna = atoi(array_fvp[4].value);
	wlRadius->wpa2ReAuthIntvl = atoi(array_fvp[5].value);
	wlRadius->authType = atoi(array_fvp[7].value);
	wlRadius->authProto = atoi(array_fvp[8].value);
	if (!(inet_aton(array_fvp[9].value, &wlRadius->radiusServerIP))) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlan8021xConfig",
			       "inet_aton error");
		goto IFX_Handler;
	}
	wlRadius->radiusPort = atoi(array_fvp[10].value);

	memset(&wlMain, 0, sizeof(IFX_MAPI_WLAN_MainCfg));
	sprintf(wlMain.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
	sprintf(wlMain.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
	wlMain.iid.cpeId.Id = wlRadius->iid.pcpeId.Id;
	if ((ret = ifx_mapi_get_wlan_main_config(&wlMain, IFX_F_DEFAULT)) !=
		 IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
		goto IFX_Handler;
	}
	/* get vendor information */
	vendor = ltq_mapi_get_wlan_vendor(wlMain.radioCpeId, IFX_F_DEFAULT);
	if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
		memset(radSecretInAscii, 0, sizeof(radSecretInAscii));
		/* convert hex representation of ssid to ascii representation */
		if (mapi_wlan_convert_hex_to_ascii(array_fvp[11].value, radSecretInAscii) !=
			IFX_SUCCESS) {
			snprintf(wlRadius->radiusServerSecret, IFX_MAPI_PASSPHRASE_MAX_LEN,
				 "%s", array_fvp[11].value);
		} else {
			snprintf(wlRadius->radiusServerSecret, IFX_MAPI_PASSPHRASE_MAX_LEN,
				"%s", radSecretInAscii);
		}
	} else {
		snprintf(wlRadius->radiusServerSecret, IFX_MAPI_PASSPHRASE_MAX_LEN,
			 "%s", array_fvp[11].value);
	}

	snprintf(wlRadius->domainName, IFX_MAPI_RADIUS_AUTH_DOMAIN, "%s",
		 array_fvp[12].value);
	snprintf(wlRadius->userName, IFX_MAPI_RADIUS_AUTH_USER, "%s",
		 array_fvp[13].value);

      IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlan8021xConfig", "ret: %d", ret);
	IFX_MEM_FREE(sValueNew);
	LTQ_LOG_TIMESTAMP("Done");
	return ret;
}

/**
   This api reads

   \param   wepkeyindex

   \param   cpeid

   \return
      IFX_SUCCESS or IFX_FAILURE
*/

int32 ifx_mapi_get_wlan_wepkeyindex(uint32 cpeid, uint32 * keyindex)
{
	int32 ret = IFX_SUCCESS, passed_index = -1;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	CPE_ID cpe_id;
	uint32 outFlag = IFX_F_DEFAULT;

	LTQ_LOG_TIMESTAMP("Begin");

	sprintf(cpe_id.secName, "%s", TAG_WLAN_SEC);
	cpe_id.Id = cpeid;

	/* get index from cpeid first */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpe_id, passed_index)
	    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWepKeyIndex", "passed_index:%d",
			   passed_index);

	sprintf(buf, "%s_%d_wepKeyIndx", PREFIX_WLAN_SEC, passed_index);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_SEC,
				  buf, IFX_F_GET_ANY, &outFlag,
				  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif				/* #ifdef IFX_LOG_DEBUG */
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWepKeyIndex", "");
		goto IFX_Handler;
	}

	*keyindex = atoi(sValue);

IFX_Handler:
	LTQ_LOG_TIMESTAMP("Done");
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;

}

static int32 get_mac_addr(int index , char *mac_addr)
{
    FILE *fp = NULL;
    char line[180] , if_name[20];
    char wlan_if[100] ,  mac_bytes[5];
    int if_id , flag = 0 , ret = 0;

    int s;
    struct ifreq buffer;

    memset(mac_addr , '\0' , 20);
    fp = fopen("/tmp/wave300_map_apIndex" , "r");
    if(fp == NULL) {
	IFX_DBG("[%s:%d] Cannot open /tmp/wave300_map_apIndex file\n" , __FUNCTION__ , __LINE__);
        goto end;
    }

    sprintf(wlan_if , "w300_map_idx_%d=" , index);
    while((fgets(line , 100 , fp)) != NULL) {
        if( strstr(line , wlan_if)){
            flag = 1 ;
            break;
        }
    }
    fclose(fp);

    if(flag == 0){
        strcpy(mac_addr , "00:00:00:00:00:00");
        goto end;
    }

    sscanf(line, "w300_map_idx_%d=\"%s\"\n"  , &if_id , if_name);
    if_name[strlen(if_name) - 1] = '\0';

    s = socket(PF_INET, SOCK_DGRAM, 0);

    if (s == -1) {
	  IFX_DBG("[%s:%d] Failed to opoen socket\n" , __FUNCTION__,__LINE__);
        get_mac_from_base_lan_mac(mac_addr , index);
        goto end;
    }

    memset(&buffer, 0x00, sizeof(buffer));

    strcpy(buffer.ifr_name, if_name);

    ret = ioctl(s, SIOCGIFHWADDR, &buffer);

    if(ret != 0){
	IFX_DBG("[%s:%d}Failed ->ioctl SIOCGIFHWADDR", __FUNCTION__,__LINE__);
        get_mac_from_base_lan_mac(mac_addr , index);
        close(s);
        goto end;
    }

    close(s);

    for( s = 0; s < 6; s++ )
    {
        sprintf(mac_bytes , "%.2X", (unsigned char)buffer.ifr_hwaddr.sa_data[s]);
        strcat(mac_addr , mac_bytes);
        strcat(mac_addr , ":");
    }

    mac_addr[strlen(mac_addr) - 1] = '\0';

end:
return 0;
}

static int get_mac_from_base_lan_mac(char8 *psMac , int32 passed_index)
{
    char8  mac[19] = {0};
    FILE *fp = NULL;

    unsigned int octets[6];

    system("upgrade mac_get 0 > /tmp/tmp_mac");
    fp = fopen("/tmp/tmp_mac","r");
    if(fp)
    {
        fread(mac, 19, 1, fp);
        fclose(fp);
    }
    system("rm -rf /tmp/tmp_mac");

    strncpy(psMac, mac, (sizeof(mac) - 1));
    
    sscanf(psMac , "%x:%x:%x:%x:%x:%x" , &octets[0],&octets[1],&octets[2],&octets[3],&octets[4],&octets[5]);
    octets[5] = (8 + passed_index);
    
    sprintf(psMac , "%.2x:%.2x:%.2x:%.2x:%.2x:%.2x" , octets[0],octets[1],octets[2],octets[3],octets[4],octets[5]);
    return 0;
}

/**
   \param   numEntries  -

   \param   wlSsCfg      - pointer to WLAN subsystem config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ltq_mapi_get_all_wlan_ss_config (uint32 *numEntries,
	LTQ_MAPI_WLAN_SubsystemCfg **wlSsCfg, uint32 flags) {
	int32 ret = IFX_SUCCESS, nCount = 0, i = 0, nParamCount = 0;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN], *sWlanSsObject = NULL;
	uint32 outFlag = IFX_F_DEFAULT;
	IFX_NAME_VALUE_PAIR array_fvp[LTQ_MAX_NUM_RADIO*WLAN_SUBSYSTEM_PARAM_COUNT];

	LTQ_LOG_TIMESTAMP("Begin");

	MAKE_SECTION_COUNT_TAG(TAG_WLAN_SUBSYSTEM, buf);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_SUBSYSTEM, buf, flags,
		&outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Could not get wlan_ss count", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	nCount = atoi(sValue);
	if (nCount <= 0) {
		*numEntries = 0;
		*wlSsCfg = NULL;
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Invalid number of entries in wlan_ss",
			__FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	*wlSsCfg = NULL;
	if (nCount <= LTQ_MAX_NUM_RADIO) {
		IFX_MEM_ALLOC((*wlSsCfg), LTQ_MAPI_WLAN_SubsystemCfg *, nCount,
			sizeof(LTQ_MAPI_WLAN_SubsystemCfg))
	} else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Invalid number of entries in wlan_ss",
			__FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* return immediately if config is already loaded */
	if (g_flagSubsystemConfig) {
		memcpy(*wlSsCfg, g_wlSs, sizeof(LTQ_MAPI_WLAN_SubsystemCfg) * nCount);
		*numEntries = nCount;
		goto IFX_Handler;
	}
	else {
		/* initialize all structures */
		for (i = 0; i < LTQ_MAX_NUM_RADIO; i++) {
			memset(&g_wlSs[i], 0, sizeof(LTQ_MAPI_WLAN_SubsystemCfg));

			/* wlan ss structure needs some initial values */
			sprintf(g_wlSs[i].iid.cpeId.secName, "%s", TAG_WLAN_SUBSYSTEM);
			sprintf(g_wlSs[i].iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
			g_wlSs[i].iid.cpeId.Id = i+1;
		}
	}

	sprintf(buf, "%s_", PREFIX_WLAN_SUBSYSTEM);
	if ((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_SUBSYSTEM, buf, IFX_F_DEFAULT,
		&sWlanSsObject)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Could not get wlan_ss object", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sWlanSsObject, &nParamCount, array_fvp);

	for (i = 0; i < nCount; i++) {
		sprintf((*wlSsCfg + i)->iid.cpeId.secName, "%s", TAG_WLAN_SUBSYSTEM);
		sprintf((*wlSsCfg + i)->iid.pcpeId.secName, "%s", TAG_LAN_MAIN);
		(*wlSsCfg + i)->iid.cpeId.Id 	= atoi(array_fvp[i * WLAN_SUBSYSTEM_PARAM_COUNT].value);
		(*wlSsCfg + i)->iid.pcpeId.Id 	= atoi(array_fvp[i * WLAN_SUBSYSTEM_PARAM_COUNT + 1].value);
		snprintf((*wlSsCfg + i)->vendor, sizeof((*wlSsCfg + i)->vendor), "%s",
			array_fvp[i * WLAN_SUBSYSTEM_PARAM_COUNT +2].value);
		snprintf((*wlSsCfg + i)->hwName, sizeof((*wlSsCfg + i)->hwName), "%s",
			array_fvp[i * WLAN_SUBSYSTEM_PARAM_COUNT +3].value);
		snprintf((*wlSsCfg + i)->prefixScript, sizeof((*wlSsCfg + i)->prefixScript), "%s",
			array_fvp[i * WLAN_SUBSYSTEM_PARAM_COUNT +4].value);
	}
	*numEntries = nCount;

	/* store in global variable for later usage */
	memcpy(g_wlSs, *wlSsCfg, sizeof(LTQ_MAPI_WLAN_SubsystemCfg) * nCount);
	g_flagSubsystemConfig = 1;

IFX_Handler:
	IFX_MEM_FREE(sWlanSsObject);
	LTQ_LOG_TIMESTAMP("Done");
	return ret;
}

/*! \brief  This function is used to retrieve vendor information.
		\param[in] radioCpeId WLAN Radio CpeId
		\param[in] flags Filter Flags
        \return WAVE300, QCA
*/
int32 ltq_mapi_get_wlan_vendor(uint32 radioCpeId, uint32 flags) {
	int32 ret = IFX_SUCCESS, nEntries = 0;
	LTQ_MAPI_WLAN_Vendor	vendor = LTQ_MAPI_WLAN_VENDOR_NONE;
	LTQ_MAPI_WLAN_SubsystemCfg *wlSsCfgAll = NULL;

	if ((radioCpeId < 1) || (radioCpeId > 2)) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] radioCpeId invalid", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* get configuration of wlan subsystem to determine the vendor for this radio */
	if ((ret = ltq_mapi_get_all_wlan_ss_config((uint32 *) &nEntries,
		&wlSsCfgAll, IFX_F_DEFAULT)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Could not get wlan_ss", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* more validations */
	if ((nEntries < 1) || (nEntries > 2)) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] nEntries invalid", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	if ((radioCpeId == 2) && (nEntries == 1)) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Mismatch radioCpeId and nEntries", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* check if vendor is Lantiq or 3p vendor */
	if (!(strcmp(wlSsCfgAll[radioCpeId-1].vendor, "LANTIQ"))) {
		vendor = LTQ_MAPI_WLAN_VENDOR_WAVE300;
	} else if (!(strcmp(wlSsCfgAll[radioCpeId-1].vendor, "QCA"))) {
		vendor = LTQ_MAPI_WLAN_VENDOR_QCA;
	} else {
		vendor = LTQ_MAPI_WLAN_VENDOR_NONE;
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Invalid vendor: %s",
			__FUNCTION__, __LINE__, wlSsCfgAll[radioCpeId-1].vendor);
#endif
	}

IFX_Handler:
	IFX_MEM_FREE(wlSsCfgAll);
	return vendor;
}

/*! \brief  This function is used to get info about supported features of WLAN SS
		\param[in] radioCpeId WLAN Radio CpeId
		\param[in] flags Filter Flags
        \return bitmap of supported features (see LTQ_MAPI_WLAN_Feature)
*/
int32 ltq_mapi_get_wlan_supported_features(uint32 radioCpeId, uint32 flags) {
	LTQ_MAPI_WLAN_Feature feat = LTQ_MAPI_WLAN_FEATURE_NONE;
	IFX_MAPI_WLAN_Capability wlCaps;
	LTQ_MAPI_WLAN_Vendor	vendor = LTQ_MAPI_WLAN_VENDOR_NONE;
	int32 i;

	if ((radioCpeId < 1) || (radioCpeId > 2)) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] radioCpeId invalid", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	if (radioCpeId == 1) {
		if (ifx_mapi_get_wlan_capability(&wlCaps, IFX_F_DEFAULT) !=
			IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] could not get capabilities",
				__FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
	}
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	else {
		if (ifx_mapi_get_wlan_sec_capability(&wlCaps, IFX_F_DEFAULT) !=
			IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] could not get capabilities",
				__FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
	}
#endif
	vendor = ltq_mapi_get_wlan_vendor(radioCpeId, IFX_F_DEFAULT);
	if (vendor == LTQ_MAPI_WLAN_VENDOR_WAVE300) {
#if 0
		feat |= LTQ_MAPI_WLAN_FEATURE_AUTOCOC |
				LTQ_MAPI_WLAN_FEATURE_NETMODE_PER_VAP | 
				LTQ_MAPI_WLAN_FEATURE_OPT_SCRIPTS;
#else
		feat |= LTQ_MAPI_WLAN_FEATURE_OPT_SCRIPTS;
#endif
	} else if (vendor == LTQ_MAPI_WLAN_VENDOR_QCA) {
		for (i = 0; i < IFX_MAPI_WLAN_MAX_STD; i++) {
		    IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_supported_features",
				"wlCaps.std[%d]: %d", i, wlCaps.std[i]);
			if (wlCaps.std[i] == IFX_MAPI_WLAN_STD_802_11AC) {
				feat |= LTQ_MAPI_WLAN_FEATURE_80211AC;
				break;
			}
		}
	} else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Invalid vendor: %d",
			__FUNCTION__, __LINE__, vendor);
#endif
		feat = LTQ_MAPI_WLAN_FEATURE_NONE;
		goto IFX_Handler;
	}

	if (wlCaps.WMMcapable)
		feat |= LTQ_MAPI_WLAN_FEATURE_WMM;
	if (wlCaps.WPScapable)
		feat |= LTQ_MAPI_WLAN_FEATURE_WPS | LTQ_MAPI_WLAN_FEATURE_WPS_PROXY;
	if (wlCaps.WDScapable)
		feat |= LTQ_MAPI_WLAN_FEATURE_WDS;

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_supported_features",
		"radioCpeId%d: feat: 0x%x", radioCpeId, feat);
	return feat;
}
#endif				// CONFIG_FEATURE_IFX_WIRELESS
