#include <stdio.h>
#include <ctype.h>
#include <fcntl.h>
#include <string.h>
#include <syslog.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <sys/sysinfo.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"
#ifdef CONFIG_PACKAGE_IFX_DEVM
#include "IFIN_Proto_API.h"
#endif
#include "ifx_emf.h"

#define WAN_START { \
			system("/etc/rc.d/rc.bringup_l2if start"); \
			system("/etc/rc.d/rc.bringup_wan start"); /* rip will be started as part of this */ \
		}

#define WAN_STOP { \
			system("/etc/init.d/ripd stop"); \
			system("/etc/rc.d/rc.bringup_wan stop"); \
			system("/etc/rc.d/rc.bringup_l2if stop"); \
			system("/etc/init.d/ripd start"); /* so as to have it run on non WAN interfaces */ \
		}

#define CONFIG_WAN_LINK_UP(val) { \
			char8	buf[MAX_FILELINE_LEN]; \
			sprintf(buf, "%s=\"%d\"\n", "link_up_once", val); \
			SetObjData(FILE_SYSTEM_STATUS, "wan_link_status", IFX_F_MODIFY, 1, buf); \
		}

extern char newconnName[MAX_CONN_NAME_LEN];

int32 viTR69RdFd;
char8 vcOsModId = 1;

char8 *wan_ip_param_names[] = { "cpeId",
	"pcpeId",
	"fEnable",
	"linkType",
	"autoDiscTime",
	"idleDiscTime",
	"NATEnable",
	"macAddrOverride",
	"rxRouteProto",
	"wanMode",
	"connType",
	"maxMTU",
	"l3Proto",
	"ipv6CfgType",
	"mcProxyEna",
	"addrType",
	"connName",
	"confconnName",
	"macAddr",
	"l2ifName",
	"iface",
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
	"autodetect",
#endif
#ifdef CONFIG_FEATURE_WAN_CATEGORY_SUPPORT
	"wanCategory",
#endif
	"dnsoverride",
	"dnsservers"
};

#ifdef CONFIG_FEATURE_WAN_CATEGORY_SUPPORT
	#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
		#define WAN_IP_PARAM_COUNT 25
	#else
		#define WAN_IP_PARAM_COUNT 24
	#endif
#else
	#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
		#define WAN_IP_PARAM_COUNT 33
	#else
		#define WAN_IP_PARAM_COUNT 32
	#endif
#endif

char8 *wan_ppp_param_names[] = { "cpeId",
	"pcpeId",
	"fEnable",
	"linkType",
	"autoDiscTime",
	"idleDiscTime",
	"NATEnable",
	"macAddrOverride",
	"rxRouteProto",
	"wanMode",
	"connType",
	"maxMTU",
	"l3Proto",
	"ipv6CfgType",
	"mcProxyEna",
	"encrProto",
	"comprProto",
	"authProto",
	"maxMRU",
	"echoPeriod",
	"echoRetry",
	"bridgeEnable",
	"currMRU",
	"connTrigger",
	"connName",
	"confconnName",
	"macAddr",
	"l2ifName",
	"ACName",
	"serviceName",
	"user",
	"passwd",
	"iface",
	"ifppp",
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
	"autodetect",
#endif
#ifdef CONFIG_FEATURE_WAN_CATEGORY_SUPPORT
	"wanCategory",
#endif
	"dnsoverride",
	"dnsservers"
};

#ifdef CONFIG_FEATURE_WAN_CATEGORY_SUPPORT
	#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
		#define WAN_PPP_PARAM_COUNT 38
	#else
		#define WAN_PPP_PARAM_COUNT 37
	#endif
#else
	#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
		#define WAN_PPP_PARAM_COUNT 46
	#else
		#define WAN_PPP_PARAM_COUNT 45
	#endif
#endif
char8 *wan_ipv4_param_names[] =
    { "cpeId", "pcpeId", "ipAddr", "netmask", "gw", "ip6Addr", "prefixlen", "gw6", "lanprefix", "dns6server1", "dns6server2" };

char8 *wan_atmf5_param_names[] =
    { "cpeId", "pcpeId", "fEnable", "vpi", "vci", "scope", "diagnosticState",
	"timeout", "pingCount", "loopback", "contCheck", "successCount",
	"failureCount", "minRespTime",
	"maxRespTime", "avgRespTime", "contCheckOpt"
};

#define _AMAZON_ADSL_APP
#ifndef AMAZON_MEI_MIB_RFC3440
#define AMAZON_MEI_MIB_RFC3440
#endif				// AMAZON_MEI_MIB_RFC3440

#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
// #include <drv_dsl_cpe_api_config.h>
#include <drv_dsl_cpe_api.h>
#include <drv_dsl_cpe_api_ioctl.h>
#endif				/*!CONFIG_PACKAGE_IFX_DSL_CPE_API */

#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
	extern pwb_cfg_t *mapi_pwb;
#endif

#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
int32 is_auto_detect_enabled(WAN_MODE wanMode)
{
	int32	state = IFX_DISABLED;
	auto_detect_cfg_t config;

	ltq_mapi_get_autodetect_config(&config);

	if(wanMode == WAN_MODE_ATM){
//		Alternative of : if(config.auto_detect_L2 == 1 || config.auto_detect_L3 == 1 || config.auto_detect_Vlan_ATM == 1)
		if(config.auto_detect_L2 || config.auto_detect_L3 || config.auto_detect_Vlan_ATM)
			state = IFX_ENABLED;
		else
			state = IFX_DISABLED;
	}else if(wanMode == WAN_MODE_PTM){
		if(config.auto_detect_Vlan_ADSL_PTM || config.auto_detect_adsl_ptm_L3)
			state = IFX_ENABLED;
		else
			state = IFX_DISABLED;
	}else if(wanMode == WAN_MODE_VDSL_PTM){
		if(config.auto_detect_Vlan_VDSL_PTM || config.auto_detect_vdsl_ptm_L3)
			state = IFX_ENABLED;
		else
			state = IFX_DISABLED;
	}else if(wanMode == WAN_MODE_ETH1){
		if(config.auto_detect_Vlan_ETH1 || config.auto_detect_mii1_L3)
			state = IFX_ENABLED;
		else
			state = IFX_DISABLED;
	}else if(wanMode == WAN_MODE_ETH0){
		if(config.auto_detect_Vlan_ETH0 || config.auto_detect_mii0_L3)
			state = IFX_ENABLED;
		else
			state = IFX_DISABLED;
	}

	return state;
}

int32 mapi_autodetect_disable_for_wanmode(WAN_MODE wanMode)
{
	auto_detect_cfg_t config;
	bool flag = FALSE;
	ltq_mapi_get_autodetect_config(&config);
	if(wanMode == WAN_MODE_ATM){
		if(config.auto_detect_L2 == 0 && config.auto_detect_L3 == 0) {
			flag = TRUE;
		}
		else {
			config.auto_detect_L2 = 0;
			config.auto_detect_L3 = 0;
		}
	}else if(wanMode == WAN_MODE_PTM){
		if(config.auto_detect_Vlan_ADSL_PTM == 0 && config.auto_detect_adsl_ptm_L3 == 0) {
			flag = TRUE;
		}
		else {
			config.auto_detect_Vlan_ADSL_PTM = 0;
			config.auto_detect_adsl_ptm_L3	= 0;
		}
	}else if(wanMode == WAN_MODE_VDSL_PTM){
		if(config.auto_detect_Vlan_VDSL_PTM == 1 && config.auto_detect_vdsl_ptm_L3 == 0) {
			flag = TRUE;
		}
		else {
			config.auto_detect_Vlan_VDSL_PTM = 0;
			config.auto_detect_vdsl_ptm_L3 = 0;
		}
	}else if(wanMode == WAN_MODE_ETH1){
		if(config.auto_detect_Vlan_ETH1 == 0 && config.auto_detect_mii1_L3 == 0) {
			flag = TRUE;
		}
		else {
			config.auto_detect_Vlan_ETH1 = 0;
			config.auto_detect_mii1_L3 = 0;
		}
	}else if(wanMode == WAN_MODE_ETH0){
		if(config.auto_detect_Vlan_ETH0 == 0 && config.auto_detect_mii0_L3 == 0) {
			flag = TRUE;
		}
		else {
			config.auto_detect_Vlan_ETH0 = 0;
			config.auto_detect_mii0_L3 = 0;
		}
	}

	if(flag == FALSE) {
		if (ltq_mapi_set_autodetect_config(&config, IFX_F_MODIFY) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Failed to set auto detect parameter",__FUNCTION__, __LINE__);
#endif
			return IFX_FAILURE;
		}
	}
	return IFX_SUCCESS; 
}

int ltq_mapi_get_autodetect_config(auto_detect_cfg_t *config)
{
	int ret = 0, 
		cache_ret = IFX_SUCCESS;
	uint32 outFlag = IFX_F_DEFAULT;
 	char_t sValue[MAX_FILELINE_LEN],
		   buf[MAX_FILELINE_LEN];

	memset(sValue, 0x00, sizeof(sValue));
	memset(config, 0x00, sizeof(auto_detect_cfg_t));

	/* initialize the cache for this instance */
	strcpy(buf, "auto_");

	if (ifx_GetObjDataOpt (FILE_AUTO_DETECT, TAG_AUTO_DETECT_CFG, buf, 
		IFX_F_INT_CACHE_INIT, NULL, NULL) != IFX_SUCCESS) {
		IFX_DBG("[%s:%d] Failed to initialize cache for auto_detect instance",
				__FUNCTION__, __LINE__);
		cache_ret = IFX_FAILURE;
		goto IFX_Handler;
	} 

	inline int read_data_from_cache(char_t *parm, char_t *value, int *state) 
	{
		memset(value, 0x00, sizeof(value));
		if (ifx_GetObjDataOpt(FILE_AUTO_DETECT, TAG_AUTO_DETECT_CFG, parm, 0, 
			(IFX_OUT uint32 *) & outFlag, value) != IFX_SUCCESS) {
			IFX_DBG("[%s:%d] Unable to retrieve %s", __FUNCTION__, __LINE__, parm);
			*state = IFX_FAILURE;
			return -1;
		}
		*state = IFX_SUCCESS;
		return 0;
	}

	if(!read_data_from_cache("auto_detect", sValue, &ret))
		config->auto_detect = atoi(sValue);

	if(!read_data_from_cache("auto_detect_L3", sValue, &ret))
		config->auto_detect_L3= atoi(sValue);

	if(!read_data_from_cache("auto_detect_vdsl_atm_L3", sValue, &ret))
		config->auto_detect_vdsl_atm_L3= atoi(sValue);

	if(!read_data_from_cache("auto_detect_adsl_ptm_L3", sValue, &ret))
		config->auto_detect_adsl_ptm_L3= atoi(sValue);

	if(!read_data_from_cache("auto_detect_vdsl_ptm_L3", sValue, &ret))
		config->auto_detect_vdsl_ptm_L3= atoi(sValue);

	if(!read_data_from_cache("auto_detect_mii1_L3", sValue, &ret))
		config->auto_detect_mii1_L3= atoi(sValue);

	if(!read_data_from_cache("auto_detect_mii0_L3", sValue, &ret))
		config->auto_detect_mii0_L3= atoi(sValue);
	
	if(!read_data_from_cache("auto_detect_L2", sValue, &ret))
		config->auto_detect_L2 = atoi(sValue);	    
	
	if(!read_data_from_cache("auto_detect_vdsl_atm_L2", sValue, &ret))
		config->auto_detect_vdsl_atm_L2 = atoi(sValue);	    	

#if 0 //ATM VLAN NOT SUPPORTED
	if(!read_data_from_cache("auto_detect_Vlan_ATM", sValue, &ret))
		config->auto_detect_Vlan_ATM	= atoi(sValue);	    	
#endif

	if(!read_data_from_cache("auto_detect_Vlan_ADSL_PTM", sValue, &ret))
		config->auto_detect_Vlan_ADSL_PTM 	= atoi(sValue);

	if(!read_data_from_cache("auto_detect_Vlan_VDSL_PTM", sValue, &ret))
		config->auto_detect_Vlan_VDSL_PTM 	= atoi(sValue);

	if(!read_data_from_cache("auto_detect_Vlan_ETH1", sValue, &ret))
		config->auto_detect_Vlan_ETH1 	= atoi(sValue);
 	
	if(!read_data_from_cache("auto_detect_Vlan_ETH0", sValue, &ret))
		config->auto_detect_Vlan_ETH0 	= atoi(sValue);

	if(!read_data_from_cache("auto_vcc_pool", sValue, &ret))
		strcpy(config->auto_detect_Vcc, sValue);

#if 0 //ATM VLAN NOT SUPPORTED
 	if(!read_data_from_cache("auto_atm_vlan_pool", sValue, &ret))
		strcpy(config->auto_detect_ATM_VlanId, sValue);	 
#endif

 	if(!read_data_from_cache("auto_adsl_ptm_vlan_pool", sValue, &ret))
		strcpy(config->auto_detect_ADSL_PTM_VlanId, sValue);
 	
	if(!read_data_from_cache("auto_vdsl_ptm_vlan_pool", sValue, &ret))
		strcpy(config->auto_detect_VDSL_PTM_VlanId, sValue);
 	
	if(!read_data_from_cache("auto_eth1_vlan_pool", sValue, &ret))
		strcpy(config->auto_detect_ETH1_VlanId, sValue);
	
	if(!read_data_from_cache("auto_eth0_vlan_pool", sValue, &ret))
		strcpy(config->auto_detect_ETH0_VlanId, sValue);

	if(!read_data_from_cache("auto_detect_prev_val", sValue, &ret))
		sprintf(config->auto_detect_prev_val, "%s", sValue);

 	if(!read_data_from_cache("auto_detect_ppp_user", sValue, &ret))
		strcpy(config->auto_detect_ppp_user, sValue);

 	if(!read_data_from_cache("auto_detect_ppp_pass", sValue, &ret))
		strcpy(config->auto_detect_ppp_pass, sValue);

 	if(!read_data_from_cache("auto_atm_wan_pool", sValue, &ret))
		sprintf(config->auto_detect_atm_wan_pool, "%s", sValue);

 	if(!read_data_from_cache("auto_ptm_wan_pool", sValue, &ret))
		sprintf(config->auto_detect_ptm_wan_pool, "%s", sValue);

IFX_Handler:

	if(cache_ret == IFX_SUCCESS){
		if(ifx_GetObjDataOpt(FILE_AUTO_DETECT, TAG_AUTO_DETECT_CFG, buf, 
			IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS)
		{
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Failed to destroy cache for this instance",__FUNCTION__ ,
			__LINE__);
#endif
			ret = IFX_FAILURE;
		}
	}
	return ret;
}

void auto_detect_start()
{
	if(access(FILE_AUTO_DETECT_PID, F_OK) == 0) {
		IFX_DBG("<<<<<<<<=========probe status is already up>>>>>>=======>>>>>>>>>");
	}
	else {
		system("/usr/sbin/wan_autodetect");
	}
}


#define VPI_STATIC 255
#define VCI_STATIC 65535

/*//////////////////////////////////////////////////////////////////////////////
* ltq_mapi_set_autodetect_config(...)
*	config		==> 	specifies new WAN auto-detect configuration to be applied
*	inflags		==>	flags that indicate type of operation
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This API applies the input WAN auto-detect configuration,
			irrespective of operational WAN mode. Configuration change would cover,
			a. L2 probing pool updates : VLANs or VCs
				apart from configuration update, system update is necessary only for scenario -
				when auto-detect is running and pool update is requested
			b. enable/disable of L2 or L3 probing
				this would call updation of book keeping parameters in VC and VLAN objects.
				since this is book keeping update, no system configuration change is required.
*//////////////////////////////////////////////////////////////////////////////
int32 ltq_mapi_set_autodetect_config(auto_detect_cfg_t *config, uint32 inflags)
{
	int i = 0;
	int32 ret = IFX_SUCCESS, count = 0, num, idx_count = 0, autoDisable = 0, start_wan_status = 0;
	uint32 modflags = IFX_F_MODIFY, outFlag = IFX_F_DEFAULT, operation = 0;
	uint32 addflags = IFX_F_INT_ADD, getflags = IFX_F_DEFAULT, optflags = IFX_F_DEFAULT;
	char8 buf[1024], sValue[MAX_FILELINE_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[22];
	ATM_VCC_INFO vcc;
	ATM_VCC_INFO *vcc1 = NULL;
	WAN_CONN_DEV wan_connDev;
	WAN_ATMF5_LOOP_DIAGNOSTICS atmf5_diag;
	auto_detect_cfg_t prev_config;
	vlan_ch_cfg_t vlan_ch, *vlan_chcfg = NULL;
	WAN_PHY_CFG	wanPhy;
	WAN_MODE	wanMode = WAN_MODE_ATM;

	memset(&vlan_ch, 0x00, sizeof(vlan_ch)); 
	memset(&prev_config, 0x00, sizeof(auto_detect_cfg_t));
	memset(&atmf5_diag, 0x00, sizeof(atmf5_diag));    
	memset(&wan_connDev, 0x00, sizeof(wan_connDev));
	memset(buf, 0x00, sizeof(buf));
	memset(array_fvp, 0x00, sizeof(array_fvp));
	memset(&vcc, 0x00, sizeof(vcc));

	ltq_mapi_get_autodetect_config(&prev_config);
	/* can use functions instead */
	strcpy(array_fvp[0].fieldname, "auto_detect"); 
	strcpy(array_fvp[1].fieldname, "auto_detect_L3"); 
	strcpy(array_fvp[2].fieldname, "auto_detect_vdsl_atm_L3"); 
	strcpy(array_fvp[3].fieldname, "auto_detect_adsl_ptm_L3"); 
	strcpy(array_fvp[4].fieldname, "auto_detect_vdsl_ptm_L3"); 
	strcpy(array_fvp[5].fieldname, "auto_detect_mii1_L3"); 
	strcpy(array_fvp[6].fieldname, "auto_detect_mii0_L3"); 
	strcpy(array_fvp[7].fieldname, "auto_detect_L2"); 
	strcpy(array_fvp[8].fieldname, "auto_detect_vdsl_atm_L2"); 
	strcpy(array_fvp[9].fieldname, "auto_detect_Vlan_ATM"); 
	strcpy(array_fvp[10].fieldname, "auto_detect_Vlan_ADSL_PTM");
	strcpy(array_fvp[11].fieldname, "auto_detect_Vlan_VDSL_PTM");
	strcpy(array_fvp[12].fieldname, "auto_detect_Vlan_ETH1");
	strcpy(array_fvp[13].fieldname, "auto_detect_Vlan_ETH0");
	strcpy(array_fvp[14].fieldname, "auto_vcc_pool");
	strcpy(array_fvp[15].fieldname, "auto_atm_vlan_pool");
	strcpy(array_fvp[16].fieldname, "auto_adsl_ptm_vlan_pool");
	strcpy(array_fvp[17].fieldname, "auto_vdsl_ptm_vlan_pool");
	strcpy(array_fvp[18].fieldname, "auto_eth1_vlan_pool");
	strcpy(array_fvp[19].fieldname, "auto_eth0_vlan_pool");
	strcpy(array_fvp[20].fieldname, "auto_detect_ppp_user");
	strcpy(array_fvp[21].fieldname, "auto_detect_ppp_pass");

	/* can use functions instead */
	sprintf(array_fvp[0].value, "%d", config->auto_detect);
	sprintf(array_fvp[1].value, "%d", config->auto_detect_L3);
	sprintf(array_fvp[2].value, "%d", config->auto_detect_vdsl_atm_L3);
	sprintf(array_fvp[3].value, "%d", config->auto_detect_adsl_ptm_L3);
	sprintf(array_fvp[4].value, "%d", config->auto_detect_vdsl_ptm_L3);
	sprintf(array_fvp[5].value, "%d", config->auto_detect_mii1_L3);
	sprintf(array_fvp[6].value, "%d", config->auto_detect_mii0_L3);
	sprintf(array_fvp[7].value, "%d", config->auto_detect_L2);
	sprintf(array_fvp[8].value, "%d", config->auto_detect_vdsl_atm_L2);
	sprintf(array_fvp[9].value, "%d", config->auto_detect_Vlan_ATM);
	sprintf(array_fvp[10].value, "%d", config->auto_detect_Vlan_ADSL_PTM); 
	sprintf(array_fvp[11].value, "%d", config->auto_detect_Vlan_VDSL_PTM); 
	sprintf(array_fvp[12].value, "%d", config->auto_detect_Vlan_ETH1); 
	sprintf(array_fvp[13].value, "%d", config->auto_detect_Vlan_ETH0); 
	sprintf(array_fvp[14].value, "%s", config->auto_detect_Vcc); 
	sprintf(array_fvp[15].value, "%s", config->auto_detect_ATM_VlanId); 
	sprintf(array_fvp[16].value, "%s", config->auto_detect_ADSL_PTM_VlanId); 
	sprintf(array_fvp[17].value, "%s", config->auto_detect_VDSL_PTM_VlanId); 
	sprintf(array_fvp[18].value, "%s", config->auto_detect_ETH1_VlanId); 
	sprintf(array_fvp[19].value, "%s", config->auto_detect_ETH0_VlanId); 
	sprintf(array_fvp[20].value, "%s", config->auto_detect_ppp_user); 
	sprintf(array_fvp[21].value, "%s", config->auto_detect_ppp_pass); 
	count = 22;

	/* If auto detect is getting disabled at any level then, auto detect process needs to be stopped */
	if(ifx_get_wan_phy_cfg(&wanPhy) != IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	}

	wanMode = compute_wan_mode(wanPhy.phy_mode, wanPhy.wan_tc);

	if((wanMode == WAN_MODE_ATM) &&
	(config->auto_detect_L2 == 0 && config->auto_detect_L3 == 0 && config->auto_detect_Vlan_ATM == 0) && // new values are disable
	(prev_config.auto_detect_L2 == 1 || prev_config.auto_detect_L3 == 1 || prev_config.auto_detect_Vlan_ATM == 1)) { // one of old value is enable
		autoDisable = 1;
	}
	else if((wanMode == WAN_MODE_PTM) &&
	(config->auto_detect_adsl_ptm_L3 == 0 && config->auto_detect_Vlan_ADSL_PTM == 0) && // new values are disable
	(prev_config.auto_detect_adsl_ptm_L3 == 1 || prev_config.auto_detect_Vlan_ADSL_PTM == 1)) { // one of old value is enable
		autoDisable = 1;
	}
	else if((wanMode == WAN_MODE_VDSL_PTM) &&
	(config->auto_detect_vdsl_ptm_L3 == 0 && config->auto_detect_Vlan_VDSL_PTM == 0) && // new values are disable
	(prev_config.auto_detect_vdsl_ptm_L3 == 1 || prev_config.auto_detect_Vlan_VDSL_PTM == 1)) { // one of old value is enable
		autoDisable = 1;
	}
	else if((wanMode == WAN_MODE_ETH1) &&
	(config->auto_detect_mii1_L3 == 0 && config->auto_detect_Vlan_ETH1 == 0) && // new values are disable
	(prev_config.auto_detect_mii1_L3 == 1 || prev_config.auto_detect_Vlan_ETH1 == 1)) { // one of old value is enable
		autoDisable = 1;
	}
	else if((wanMode == WAN_MODE_ETH0) &&
	(config->auto_detect_mii0_L3 == 0 && config->auto_detect_Vlan_ETH0 == 0) && // new values are disable
	(prev_config.auto_detect_mii0_L3 == 1 || prev_config.auto_detect_Vlan_ETH0 == 1)) { // one of old value is enable
		autoDisable = 1;
	}

	if(autoDisable == 1 && access("/var/run/wan_autodetect.pid", F_OK) == 0) {
		system("kill -SIGTERM `cat /var/run/wan_autodetect.pid`");
		start_wan_status = 1;
	}
	/* what will happen in the case, auto detect is running and user configures vc/vlan pool only ??? should auto detect process needs to be restarted for this ??? */
	/* maybe check if pool has got changed and then start auto-detect at the end ??? */


	form_cfgdb_buf(buf, count, array_fvp);

	/*Updating  Auto detect config file*/
	ret = ifx_SetObjData(FILE_AUTO_DETECT, TAG_AUTO_DETECT_CFG, inflags, 1, buf);
	if (ret != IFX_SUCCESS) {
		IFX_DBG("[%s:%d] ERROR: Failed to write autodetect config to config file"
										, __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	} 

	optflags = IFX_F_MODIFY | IFX_F_DONT_VALIDATE | IFX_F_INT_DONT_CONFIGURE | IFX_F_DONT_WRITE_TO_FLASH;
	modflags |= optflags;
	addflags |= optflags;
	operation = IFX_OP_MOD;

	if((config->auto_detect_L2 == 1) && (prev_config.auto_detect_L2 == 0)){

		/* if same vpi/vci exist modify the entry and set autodetect to 1 */
		if (ifx_get_all_vcc_info(&num, &vcc1, IFX_F_DEFAULT) != IFX_SUCCESS)
		{
			IFX_MEM_FREE(vcc1);
			return IFX_FAILURE;
		}

		for(i=0; i<num; i++) {
			if(((vcc1 + i)->vc.pvc.vpi == VPI_STATIC) && ((vcc1 + i)->vc.pvc.vci == VCI_STATIC )){
				(vcc1 + i)->autodetect = 1;
				ret = ifx_set_vcc_cfg(operation, (vcc1+i), modflags);
				if(ret != IFX_SUCCESS){
					IFX_DBG("[%s:%d] ERROR: Failed to modify auto vcc section\n", 
								__FUNCTION__, __LINE__);
					return IFX_FAILURE;
				}

				if(vcc1)
					IFX_MEM_FREE(vcc1);	
				return IFX_SUCCESS; 
			}
		}

		if(vcc1)
			IFX_MEM_FREE(vcc1);
	
		wan_connDev.iid.config_owner = IFX_WEB;
		wan_connDev.iid.pcpeId.Id = 1;
		wan_connDev.vc.pvc.vpi = VPI_STATIC ; 
		wan_connDev.vc.pvc.vci = VCI_STATIC;  
		snprintf(wan_connDev.iid.cpeId.secName,strlen(TAG_WAN_CONN_DEVICE) + 1,
										"%s", TAG_WAN_CONN_DEVICE);
		ret = ifx_set_wan_conn_dev(IFX_OP_ADD , &wan_connDev , addflags);

		if (ret != IFX_SUCCESS)	{
			IFX_DBG("\n[%s][%d] ifx_set_wan_conn_dev SET Failed\n",__FUNCTION__, __LINE__);
			return IFX_FAILURE;
		}

		vcc.autodetect = IFX_ENABLED;
		vcc.iid.config_owner = IFX_WEB;
		vcc.vc.pvc.vpi = VPI_STATIC;
		vcc.vc.pvc.vci = VCI_STATIC;
		vcc.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
		vcc.type = LINK_TYPE_EOATM ; /* Default type is ATM for AUTO DETECT, Has to be modified later */
		vcc.f_enable = IFX_ENABLED;
		strcpy(vcc.vcc_ch_name, "auto_vcc_ch"); 
		snprintf(vcc.iid.cpeId.secName,strlen(TAG_ADSL_VCCHANNEL) + 1, "%s",TAG_ADSL_VCCHANNEL);
		strncpy(vcc.iid.pcpeId.secName,wan_connDev.iid.pcpeId.secName, strlen(wan_connDev.iid.pcpeId.secName));

		ret = ifx_set_vcc_cfg(IFX_OP_ADD, &vcc, addflags);
		if(ret != IFX_SUCCESS){
			IFX_DBG("[%s:%d] ERROR: Failed to create AUTO VCC Section\n", 
											__FUNCTION__, __LINE__);
			return IFX_FAILURE;
		}

		atmf5_diag.diagnostic_state = WAN_DIAG_START_DIAGNOSING;
		atmf5_diag.f_enable = IFX_ENABLED;
		atmf5_diag.iid.config_owner = IFX_WEB;
		atmf5_diag.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
		atmf5_diag.scope = '0';
		atmf5_diag.ping_timeout = 600;
		atmf5_diag.oam_pings = 5;
		atmf5_diag.vpi = 0;
		atmf5_diag.vci = 0;
		sprintf(atmf5_diag.iid.cpeId.secName, "%s", TAG_WAN_ATMF5);
		sprintf(atmf5_diag.iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);

		ret = ifx_set_atmf5_loop_diagnostics(IFX_OP_ADD, &atmf5_diag, IFX_F_INT_ADD 
										| IFX_F_DONT_WRITE_TO_FLASH);

		if (ret != IFX_SUCCESS)	{
			IFX_DBG("[%s][%d] SET FAILED atm f5 section\n", __FUNCTION__, __LINE__);
			return IFX_FAILURE;
		}	
		snprintf(vlan_ch.iid.cpeId.secName, strlen(TAG_VLAN_CHANNEL) + 1, "%s",
										TAG_VLAN_CHANNEL);
		snprintf(vlan_ch.iid.pcpeId.secName, strlen(TAG_ADSL_VCCHANNEL) + 1, "%s",
										TAG_ADSL_VCCHANNEL);

		vlan_ch.iid.pcpeId.Id = vcc.iid.cpeId.Id;
		vlan_ch.iid.config_owner = IFX_WEB;
		vlan_ch.fEnable = IFX_ENABLED;
		strcpy(vlan_ch.chName, "auto_atm_vlan");
		vlan_ch.vlanId = -1;
		vlan_ch.macAddrOvrd = 0;
		strcpy(vlan_ch.macAddr, "");
		strncpy(vlan_ch.baseIf, vcc.l2ifname,strlen(vcc.l2ifname));
		vlan_ch.autodetect = 0;

		ret = mapi_set_vlan_ch_entry(IFX_OP_ADD, &vlan_ch, addflags);
		if (ret != IFX_SUCCESS) {
			IFX_DBG("[%s][%d] SET FAILED vlan channel config\n", __FUNCTION__, __LINE__);
			return IFX_FAILURE;
		}
	}else if((config->auto_detect_L2 == 0) && (prev_config.auto_detect_L2 == 1)){
		/* Identify dummy vcc from rc.conf and set autodetect fieldname to 0 
		   BUG: 	If again autodetect is enabled another fresh instance will be created,
				Need to handle this part, otherwise rc.conf will grow */
		if (ifx_get_all_vcc_info(&num, &vcc1, IFX_F_DEFAULT) != IFX_SUCCESS)
		{
			IFX_MEM_FREE(vcc1);
			return IFX_FAILURE;
		}

		for(i=0; i<num; i++) {
			if((vcc1 + i)->autodetect == 1){
				(vcc1 + i)->autodetect = 0;
				ret = ifx_set_vcc_cfg(operation, (vcc1+i), modflags);
				if(ret != IFX_SUCCESS){
					IFX_DBG("[%s:%d] ERROR: Failed to create AUTO VCC Section\n", 
								__FUNCTION__, __LINE__);
					return IFX_FAILURE;
				} 
			}
		}

		if(vcc1)
			IFX_MEM_FREE(vcc1);	
	}

	if(((config->auto_detect_Vlan_ADSL_PTM == 1) && (prev_config.auto_detect_Vlan_ADSL_PTM == 0)) || ((config->auto_detect_Vlan_VDSL_PTM == 1) && (prev_config.auto_detect_Vlan_VDSL_PTM == 0)) || ((config->auto_detect_Vlan_ETH1 == 1) && (prev_config.auto_detect_Vlan_ETH1 == 0)) || ((config->auto_detect_Vlan_ETH0 == 1) && (prev_config.auto_detect_Vlan_ETH0 == 0))){
		/* if same vlan id exits for auto ptm set autodetect to 1 */
		if (mapi_get_all_vlan_ch_entries(&idx_count, &vlan_chcfg, getflags) != IFX_SUCCESS) {
			IFX_MEM_FREE(vlan_chcfg);
			return IFX_FAILURE;
		}

		for(i=0; i<idx_count; i++) {
			if(wanMode == WAN_MODE_ATM || wanMode == WAN_MODE_PTM || wanMode == WAN_MODE_VDSL_PTM){
				if(!strncmp((vlan_chcfg+i)->baseIf, "ptm", 3) && ((vlan_chcfg+i)->vlanId == -1)){
					(vlan_chcfg+i)->autodetect = 1;
					ret = mapi_set_vlan_ch_entry(operation, (vlan_chcfg+i), modflags);
					if (ret != IFX_SUCCESS)	{
						IFX_DBG("[%s][%d] Auto Detect VLAN MODIFY Failed\n",__FUNCTION__, __LINE__);
						return IFX_FAILURE;
					}         	
					IFX_MEM_FREE(vlan_chcfg);
					return IFX_SUCCESS;
				}
			}else if(wanMode == WAN_MODE_ETH1){
				if(!strncmp((vlan_chcfg+i)->baseIf, "eth1", 4) && ((vlan_chcfg+i)->vlanId == -1)){
					(vlan_chcfg+i)->autodetect = 1;
					ret = mapi_set_vlan_ch_entry(operation, (vlan_chcfg+i), modflags);
					if (ret != IFX_SUCCESS)	{
						IFX_DBG("[%s][%d] Auto Detect VLAN MODIFY Failed\n",__FUNCTION__, __LINE__);
						return IFX_FAILURE;
					}         	
					IFX_MEM_FREE(vlan_chcfg);
					return IFX_SUCCESS;
				}
			}else if(wanMode == WAN_MODE_ETH0){
				if(!strncmp((vlan_chcfg+i)->baseIf, "eth0", 4) && ((vlan_chcfg+i)->vlanId == -1)){
					(vlan_chcfg+i)->autodetect = 1;
					ret = mapi_set_vlan_ch_entry(operation, (vlan_chcfg+i), modflags);
					if (ret != IFX_SUCCESS)	{
						IFX_DBG("[%s][%d] Auto Detect VLAN MODIFY Failed\n",__FUNCTION__, __LINE__);
						return IFX_FAILURE;
					}
					IFX_MEM_FREE(vlan_chcfg);
					return IFX_SUCCESS;
				}
			}
		}
		IFX_MEM_FREE(vlan_chcfg);
		if(wanMode == WAN_MODE_PTM || wanMode == WAN_MODE_VDSL_PTM){
			snprintf(vlan_ch.iid.pcpeId.secName, strlen(TAG_PTM_CHANNEL) + 1, "%s", TAG_PTM_CHANNEL);
			sprintf(buf, "PtmChannel_0_cpeId");
			if (ifx_GetObjData(FILE_RC_CONF, TAG_PTM_CHANNEL , buf, IFX_F_DEFAULT, &outFlag, sValue) != IFX_SUCCESS) {
				IFX_DBG("[%s][%d] Get Failed\n", __FUNCTION__, __LINE__);
				return IFX_FAILURE;
			} 	
			vlan_ch.iid.pcpeId.Id = atoi(sValue);
			sprintf(buf, "PtmChannel_0_l2ifName");
			if (ifx_GetObjData(FILE_RC_CONF, TAG_PTM_CHANNEL , buf, IFX_F_DEFAULT, &outFlag, sValue) != IFX_SUCCESS) {
				return IFX_FAILURE;
			}     
		}
		else if(wanMode == WAN_MODE_ETH1 || wanMode == WAN_MODE_ETH0){
			snprintf(vlan_ch.iid.pcpeId.secName, strlen(TAG_ETH_CHANNEL) + 1, "%s", TAG_ETH_CHANNEL);
			sprintf(buf, "EthChannel_0_cpeId");
			if (ifx_GetObjData(FILE_RC_CONF, TAG_ETH_CHANNEL , buf, IFX_F_DEFAULT, &outFlag, sValue) != IFX_SUCCESS) {
				IFX_DBG("[%s][%d] Get Failed\n", __FUNCTION__, __LINE__);
				return IFX_FAILURE;
			}
			vlan_ch.iid.pcpeId.Id = atoi(sValue);
			sprintf(buf, "EthChannel_0_l2ifName");
			if (ifx_GetObjData(FILE_RC_CONF, TAG_ETH_CHANNEL , buf, IFX_F_DEFAULT, &outFlag, sValue) != IFX_SUCCESS) {
				return IFX_FAILURE;
			}
		} 
		strncpy(vlan_ch.baseIf, sValue, strlen(sValue));
		vlan_ch.vlanId = -1;
		vlan_ch.autodetect = 1;
		vlan_ch.iid.config_owner = IFX_WEB;
		vlan_ch.fEnable = IFX_ENABLED;
		strcpy(vlan_ch.chName, "auto_ptm_vlan");
		sprintf(vlan_ch.l2ifName, "%s.%d", vlan_ch.baseIf,vlan_ch.vlanId);
		/* Code is pending
		 */
		ret = mapi_set_vlan_ch_entry(IFX_OP_ADD, &vlan_ch, addflags);
		if (ret != IFX_SUCCESS)	{
			IFX_DBG("[%s][%d] Auto Detect VLAN SET Failed\n",__FUNCTION__, __LINE__);
			return IFX_FAILURE;
		}

	}else if(((config->auto_detect_Vlan_ADSL_PTM == 0) && (prev_config.auto_detect_Vlan_ADSL_PTM == 1)) || ((config->auto_detect_Vlan_VDSL_PTM == 0) && (prev_config.auto_detect_Vlan_VDSL_PTM == 1)) || ((config->auto_detect_Vlan_ETH1 == 0) && (prev_config.auto_detect_Vlan_ETH1 == 1)) || ((config->auto_detect_Vlan_ETH0 == 0) && (prev_config.auto_detect_Vlan_ETH0 == 1))){
		if (mapi_get_all_vlan_ch_entries(&idx_count, &vlan_chcfg, getflags) != IFX_SUCCESS) {
			IFX_MEM_FREE(vlan_chcfg);
			return IFX_FAILURE;
		}

		for(i=0; i<idx_count; i++) {
			/* 	Used extra check for "ptm" because both atm and ptm with autodetect enabled will 
			 *	have a vlan entry "-1"
			 */
			if(wanMode == WAN_MODE_PTM || wanMode == WAN_MODE_VDSL_PTM){
				if(!strncmp((vlan_chcfg+i)->baseIf, "ptm", 3) && (vlan_chcfg+i)->autodetect == 1){
					(vlan_chcfg+i)->autodetect = 0;
					ret = mapi_set_vlan_ch_entry(operation, (vlan_chcfg+i), modflags); 
					if (ret != IFX_SUCCESS)	{
						IFX_DBG("[%s][%d] Auto Detect VLAN MODIFY Failed\n",__FUNCTION__, __LINE__);
						return IFX_FAILURE;
					}         	
				}
			}else if(wanMode == WAN_MODE_ETH1){
				if(!strncmp((vlan_chcfg+i)->baseIf, "eth1", 4) && (vlan_chcfg+i)->autodetect == 1){
					(vlan_chcfg+i)->autodetect = 0;
					ret = mapi_set_vlan_ch_entry(operation, (vlan_chcfg+i), modflags); 
					if (ret != IFX_SUCCESS)	{
						IFX_DBG("[%s][%d] Auto Detect VLAN MODIFY Failed\n",__FUNCTION__, __LINE__);
						return IFX_FAILURE;
					}         	
				}
			}else if(wanMode == WAN_MODE_ETH0){
				if(!strncmp((vlan_chcfg+i)->baseIf, "eth0", 4) && (vlan_chcfg+i)->autodetect == 1){
					(vlan_chcfg+i)->autodetect = 0;
					ret = mapi_set_vlan_ch_entry(operation, (vlan_chcfg+i), modflags); 
					if (ret != IFX_SUCCESS)	{
						IFX_DBG("[%s][%d] Auto Detect VLAN MODIFY Failed\n",__FUNCTION__, __LINE__);
						return IFX_FAILURE;
					}         	
				}
			}
		}
		IFX_MEM_FREE(vlan_chcfg);
	}

	/*Need to update flash after setObjData */
	ret = ifx_config_write(FILE_AUTO_DETECT, inflags);
	if (ret != IFX_SUCCESS) {
		IFX_DBG("[%s:%d] ERROR: Failed to write autodetect config\n", __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	if (start_wan_status)
		system("/usr/sbin/ifx_event_util WAN START_ALL");

LTQ_Handler:
	return IFX_SUCCESS;
}
#endif

int32 compute_wan_mode(WAN_PHY_MODE phy, WAN_TC tc)
{
	int32 wan_mode = -1;

	if (phy == 0) {
		if (tc == 0) {	// ADSL and ATM
			wan_mode = 0;
		} else if (tc == 1) {	// ADSL and PTM
			wan_mode = 3;
		}
	} else if (phy == 3) {
		if (tc == 0) {	// VDSL and ATM
			wan_mode = 5;
		} else if (tc == 1) {	// VDSL and PTM
			wan_mode = 4;
		}
	} else if (phy == 1) {
		wan_mode = 1;
	} else if (phy == 2) {	// Eth on MII1
		wan_mode = 2;
	} else if (phy == 4) {	// AUTO
		wan_mode = 7;
	} else if (phy == 5) {	// 3G
		wan_mode = 6;
	}
#ifdef CONFIG_FEATURE_WWAN_LTE_SUPPORT
	else if (phy == 6) {
	wan_mode = 7;      // LTE WAN SUPPORT
	}
#endif 
	return wan_mode;
}

/**************************************************************************************
* Function    : do_wan_config_for_mode()
* Description : Function that will start/stop WAN connections (both IP and PPP) for given WAN mode.
		Check handled for start WAN is on status of WAN connection that is is not UP (CONNECTED/CONNECTING)
* Parameters  : wanMode -> specifies WAN mode (like WAN_MODE_ATM, WAN_MODE_VDSL_PTM)
*               state -> indicates WAN to be started/stopped
* Return      : None
**************************************************************************************/
void do_wan_config_for_mode(WAN_MODE wanMode, char8 *state)
{
	int32	count = 0, i = 0, ret = IFX_SUCCESS, wanIdx = -1;
	char8	buf[MAX_FILELINE_LEN];
	WAN_CONN_CFG	*wanCfg = NULL;

	if(mapi_get_all_wan_config_for_wan_mode(wanMode, &count, &wanCfg, IFX_F_GET_ANY) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to read WAN configuration", __FUNCTION__, __LINE__);
#endif
		//printf("[%s:%d] Unable to read WAN configuration", __FUNCTION__, __LINE__);
		return;
	}

	if(strstr(state, "stop")) {
		system("/etc/init.d/ripd stop");
	}

	//printf("[%d] wan to check for mode [%d]\n", count, wanMode);
	for(i=0; i<count; i++) {
		if((wanCfg + i)->type == WAN_TYPE_PPP) {
			sprintf((wanCfg+i)->WAN_PPP_CONN.WAN_CONN.iid.cpeId.secName, "%s", TAG_WAN_PPP);
			//printf("wan type for [%d] is ppp\n", i);
			if(!strcmp(state, "start")) {
				/* for PPP connection, status should not be already CONNECTED or CONNECTING */
				if((wanCfg + i)->wancfg.ppp.conn_status != WAN_PPP_CONN_STATUS_CONNECTED &&
					(wanCfg + i)->wancfg.ppp.conn_status != WAN_PPP_CONN_STATUS_CONNECTING) {
					//printf("wan status is down for [%d], so starting it\n", i);
					IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF,
						(wanCfg + i)->wancfg.ppp.wan_cfg.iid.cpeId, wanIdx)
					sprintf(buf, "%s %d", SERVICE_WANPPP_START, wanIdx);
				}
			}
			else {
				//printf("stopping wan [%d]\n", i);
				IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF,
					(wanCfg + i)->wancfg.ppp.wan_cfg.iid.cpeId, wanIdx)
				sprintf(buf, "%s %d", SERVICE_WANPPP_STOP, wanIdx);
			}
		}

		if((wanCfg + i)->type == WAN_TYPE_IP) {
			sprintf((wanCfg+i)->WAN_IP_CONN.WAN_CONN.iid.cpeId.secName, "%s", TAG_WAN_IP);
			if(!strcmp(state, "start")) {
				/* for DHCP connection, status should not be already CONNECTED or CONNECTING */
				if((wanCfg + i)->wancfg.ip.addr_type == IP_TYPE_DHCP &&
					((wanCfg + i)->wancfg.ip.conn_status != WAN_IP_CONN_STATUS_CONNECTED &&
					(wanCfg + i)->wancfg.ip.conn_status != WAN_IP_CONN_STATUS_CONNECTING)) {
					//printf("wan status is down for [%d], so starting it\n", i);
					IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF,
						(wanCfg + i)->wancfg.ip.wan_cfg.iid.cpeId, wanIdx)
					sprintf(buf, "%s %d", SERVICE_WANIP_START, wanIdx);
				}
				/* for static/bridge connection, status should not be already CONNECTED */
				else if((((wanCfg + i)->wancfg.ip.addr_type == IP_TYPE_STATIC) || ((wanCfg + i)->wancfg.ip.addr_type == IP_TYPE_AUTO)) &&
					((wanCfg + i)->wancfg.ip.conn_status != WAN_IP_CONN_STATUS_CONNECTED)) {
					//printf("wan status is down for [%d], so starting it\n", i);
					IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF,
						(wanCfg + i)->wancfg.ip.wan_cfg.iid.cpeId, wanIdx)
					sprintf(buf, "%s %d", SERVICE_WANIP_START, wanIdx);
				}
			}
			else {
				//printf("stopping wan [%d]\n", i);
				IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF,
					(wanCfg + i)->wancfg.ip.wan_cfg.iid.cpeId, wanIdx)
				sprintf(buf, "%s %d", SERVICE_WANIP_STOP, wanIdx);
			}
		}

		system(buf);
	}

	IFX_MEM_FREE(wanCfg)

	if(strstr(state, "stop")) {
		system("/etc/init.d/ripd start");
	}

IFX_Handler:
	return;
}

/**************************************************************************************
* Function    : do_wan_config()
* Description : Function that handles overall WAN connection bringup in the device.
		Either to start/stop WAN auto-detect or start/stop both L2, L3 services manually for given WAN mode
		Considerations included,
		1. in case WAN auto-detect is enabled,
			a. WAN auto-detect would be started every time for start state
			b. both L2 and L3 would be brought down every time for stop state
		2. in case WAN auto-detect is disabled,
			a. both L2 and L3 would be brought up/down on first link up/down for start/stop state respectively
			b. only L3 would be brought up/down on successive link up/down for start state respectively
			c. for case of stop_all, both L2 and L3 would be brought down always
			   this state would be used during WAN mode change
* Parameters  : state -> indicates WAN to be started/stopped
* Return      : None
**************************************************************************************/
void do_wan_config(char8 *state,char8* SecParam)
{
	WAN_MODE wanMode = WAN_MODE_ATM;
	WAN_PHY_CFG pstWanPhy;
	int32	dw_state = 0, ret = IFX_SUCCESS;
	char8	buf[MAX_FILELINE_LEN];

	memset(buf, 0, sizeof(buf));
	memset(&pstWanPhy, 0, sizeof(pstWanPhy));

	ifx_get_wan_phy_cfg(&pstWanPhy);
	wanMode = compute_wan_mode(pstWanPhy.phy_mode, pstWanPhy.wan_tc);

	if(!strcmp(state, "start") || !strcmp(state, "start_all")) {
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
		if(is_auto_detect_enabled(wanMode) == IFX_ENABLED) {
			/* auto detect enabled for current WAN mode */
			auto_detect_start();
			/* indicate WAN link has come up */
			CONFIG_WAN_LINK_UP(1)
		}
		else
#endif
		{
			/* auto detect disabled for current WAN mode */
#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
			dw_config_info_t dw_conf;

			memset(&dw_conf, 0, sizeof(dw_conf));
			dw_mapi_cfg_get(&dw_conf, IFX_F_GET_ANY);
			dw_state = dw_conf.fo_state;
#endif
			if(dw_state != 1) {
				if(!strcmp(state, "start_all")) {
					WAN_START
					/* indicate WAN link has come up */
					CONFIG_WAN_LINK_UP(1)
				}
				else {
					/* dual WAN is disabled. start WAN connections manually */
					/* 1. if this is first link up in case of DSL then set same info in system_status
					 *    and bringup both L2 and L3
					 * 2. otherwise just bringup L3
					 */
					ret = GetObjData(FILE_SYSTEM_STATUS, "wan_link_status", "link_up_once", buf, IFX_F_GET_ANY);
					if(ret == IFX_SUCCESS && atoi(buf) == 1) {
						do_wan_config_for_mode(wanMode, state);
					}
					else {
						WAN_START
						/* indicate WAN link has come up */
						CONFIG_WAN_LINK_UP(1)
					}
				}
			}
#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
			else {
				/* dual WAN is enabled */
	      if(SecParam != NULL && (0 == strcmp(SecParam, "DSL")) ) {
				
			    WAN_MODE priMode;
          WAN_MODE secMode;
          WAN_MODE dslWan = -1;
	        WAN_PHY_MODE phy_mode;	
        	WAN_TC wan_tc;	
				
          priMode = compute_wan_mode( dw_conf.pri_wan_cfg.phy_mode, 
                                      dw_conf.pri_wan_cfg.wan_tc);
					secMode = compute_wan_mode( dw_conf.sec_wan_cfg.phy_mode, 
                                      dw_conf.sec_wan_cfg.wan_tc);
				
            
          /* Find out which is DSL */
          /* To avoid warning, these assignments are outside if block */
          phy_mode = dw_conf.pri_wan_cfg.phy_mode; 
          wan_tc =  dw_conf.pri_wan_cfg.wan_tc;         

          if ( priMode == WAN_MODE_ATM || priMode == WAN_MODE_PTM || 
               priMode == WAN_MODE_VDSL_PTM || priMode == WAN_MODE_VDSL_ATM ) {

            dslWan = priMode; 
          
          } else if ( secMode == WAN_MODE_ATM || secMode == WAN_MODE_PTM ||   
               secMode == WAN_MODE_VDSL_PTM || secMode == WAN_MODE_VDSL_ATM ) {

            dslWan = secMode;
            phy_mode = dw_conf.sec_wan_cfg.phy_mode;
            wan_tc =  dw_conf.sec_wan_cfg.wan_tc;
          }

          if ( wanMode != dslWan ) {	
            sprintf(buf, "/etc/init.d/dw_daemon.sh start_def_wan %d %d",  
                    phy_mode, wan_tc);
            system(buf);
            wanMode = -1 ; /* WAN is started. so set wanMode to invalid */
          }
				}
				
        if( wanMode != -1 ) {
					if(!strcmp(state, "start_all")) {
						WAN_START
						/* indicate WAN link has come up */
						CONFIG_WAN_LINK_UP(1)
					}
					else {
						/* start WAN connections manually */
						/* 1. if this is first link up in case of DSL then set same info in system_status
						 *    and bringup both L2 and L3
						 * 2. otherwise just bringup L3
						 */
						ret = GetObjData(FILE_SYSTEM_STATUS, "wan_link_status", "link_up_once", buf, IFX_F_GET_ANY);
						if(ret == IFX_SUCCESS && atoi(buf) == 1) {
							do_wan_config_for_mode(wanMode, state);
						}
						else {
							WAN_START
							/* indicate WAN link has come up */
							CONFIG_WAN_LINK_UP(1)
						}
					}
				}
			}
#endif
		}
	}
	else if(!strcmp(state, "stop") || !strcmp(state, "stop_all")) {
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
		if(access(FILE_AUTO_DETECT_PID, F_OK) == 0) {
			//printf("auto detect is running, so stop it\n");
			/* auto detect is running */
			system("/etc/rc.d/killproc wan_autodetect");
		}
		else
#endif
		{
			/* auto detect is not running */
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
			if(is_auto_detect_enabled(wanMode) == IFX_ENABLED) {
				//printf("auto detect enabled for [%d]\n", wanMode);
				/* auto detect enabled for current WAN mode */
				WAN_STOP
				/* indicate WAN link has is down */
				CONFIG_WAN_LINK_UP(0)
			}
			else
#endif
			{
				//printf("auto detect disabled for [%d]\n", wanMode);
				/* stop WAN connections manually */
				if(!strcmp(state, "stop_all")) {
					//printf("event is stop_all\n");
					/* case of stop WAN for changeover */
					WAN_STOP
					/* indicate WAN link has is down */
					CONFIG_WAN_LINK_UP(0)
				}
				else {
					//printf("event is stop\n");
					/* link has to have come up */
					ret = GetObjData(FILE_SYSTEM_STATUS, "wan_link_status", "link_up_once", buf, IFX_F_GET_ANY);
					if(ret == IFX_SUCCESS && atoi(buf) == 1) {
						//printf("link has come up once, so stopping only WAN\n");
						do_wan_config_for_mode(wanMode, state);
					}
				}
			}
		}
	}

	return;
}

/* SET APIs */

/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_vcc_link_type(...)
*		vc			==> 	specifies vpi and vci values for which the link type has to be modified
*		type		==>		specified the new link type value
*    	flags		==>   flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
					This api takes the link type which has to be asscoiated with the vc having tha vpi/vci value pair
					it first checks if the vc is present, if present it does the updation and returns IFX_SUCCESS
  					otherwise returns IFX_FAILURE.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_vcc_link_type(union vcc *vc, LINK_TYPE type, uint32 flags)
{
	int32 ret = IFX_SUCCESS;
	char8 vpivci[MAX_NAME_LEN], conf_buf[MAX_DATA_LEN], *retStr = NULL;

	NULL_TERMINATE(vpivci, 0, sizeof(vpivci));
	NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));

	sprintf(vpivci, "%d/%d", vc->pvc.vpi, vc->pvc.vci);
	ret =
	    ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
					  "vcc", vpivci, &retStr);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] get index from vpi vci Fail", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}
	sprintf(conf_buf, "%s_linkType=\"%d\"\n", retStr, type);
	ret =
	    ifx_SetObjData(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, flags, 1,
			   conf_buf);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Get Link Type Fail", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(retStr)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

int32 ifx_set_channel_link_type(char8 * baseifname, LINK_TYPE type,
				uint32 flags)
{
	int32 ret = IFX_SUCCESS;
	//char8 vpivci[MAX_NAME_LEN],
	char8 conf_buf[MAX_DATA_LEN], *retStr = NULL;

	//NULL_TERMINATE(vpivci, 0, sizeof(vpivci));
	//NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));

	//sprintf(vpivci, "%d/%d", vc->pvc.vpi, vc->pvc.vci);
	ret =
	    ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
					  "l2ifName", baseifname, &retStr);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] get index from base i/f name Fail",
			__FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	sprintf(conf_buf, "%s_linkType=\"%d\"\n", retStr, type);
	ret =
	    ifx_SetObjData(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, flags, 1,
			   conf_buf);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Set Link Type Fail", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(retStr)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/**************************************************************************************
* Function    : mapi_get_wcd_from_vlan()
* Description : Get WAN connection device instance details based on VLAN instance configured below it
* Parameters  : vlan_cpeid -> ID details of VLAN instance
*               wcd_cpeid -> ID details of WAN connection device instance
* Return      : IFX_SUCCESS on success, IFX_FAILURE on error
**************************************************************************************/
int32 mapi_get_wcd_from_vlan(int32 vlan_cpeid, int32 * wcd_cpeid)
{
    char *ret_VlanStr = NULL;
    char sValue[MAX_FILELINE_LEN];
    char temp_buff[MAX_FILELINE_LEN];
    int32 outFlag = IFX_F_DEFAULT;
    int32 ret = 0;
    int pcpeId = 0;
    char parent1_secName[MAX_FILELINE_LEN];

    /*Get vlan substring for the cpe id*/
    sprintf(temp_buff, "%d", vlan_cpeid);
    if (ifx_ret_substr_from_distfield
		    (FILE_RC_CONF, TAG_VLAN_CFG, "cpeId", temp_buff, &ret_VlanStr) != IFX_SUCCESS)
    {
#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] Unable to retrieve vlan_ch coeId\n", __FUNCTION__, __LINE__);
#endif
	ret = IFX_FAILURE;
	goto ErrorHandler;
    }

    /*Use vlan substring to get the Pcpe id and section name*/
    sprintf(temp_buff, "%s_%s", ret_VlanStr, "pcpeId");
    if((ifx_GetObjData(FILE_RC_CONF, TAG_VLAN_CFG, temp_buff,
		      IFX_F_GET_ANY, (IFX_OUT uint32 *) & outFlag, sValue)) != IFX_SUCCESS)
    {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve parent cpe Id\n",__FUNCTION__, __LINE__);
#endif
        ret = IFX_FAILURE;
        goto ErrorHandler;
    }
    pcpeId = atoi(sValue);

    sprintf(temp_buff, "%s_%s", ret_VlanStr, "pcpeSec");
    if((ifx_GetObjData(FILE_RC_CONF, TAG_VLAN_CFG, temp_buff,
		      IFX_F_GET_ANY, (IFX_OUT uint32 *) & outFlag, sValue)) != IFX_SUCCESS)
    {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve parent section\n",__FUNCTION__, __LINE__);
#endif
        ret = IFX_FAILURE;
        goto ErrorHandler;
    }
    sprintf(parent1_secName,"%s",sValue);

    IFX_MEM_FREE(ret_VlanStr);

    /*Get channel substring for the cpe id*/
    sprintf(temp_buff, "%d", pcpeId);
    if(ifx_ret_substr_from_distfield(FILE_RC_CONF, parent1_secName,
		     "cpeId", temp_buff, &ret_VlanStr) != IFX_SUCCESS)
    {
#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] \n", __FUNCTION__, __LINE__);
#endif
	ret = IFX_FAILURE;
	goto ErrorHandler;
    }

    /*Use channel substring to get the cpe id of WCD*/
    sprintf(temp_buff, "%s_%s", ret_VlanStr, "pcpeId");
    if((ifx_GetObjData(FILE_RC_CONF, parent1_secName, temp_buff,
		      IFX_F_GET_ANY, (IFX_OUT uint32 *) & outFlag, sValue)) != IFX_SUCCESS)
    {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve parent cpe Id\n",__FUNCTION__, __LINE__);
#endif
        ret = IFX_FAILURE;
        goto ErrorHandler;
    }
    *wcd_cpeid = atoi(sValue);
    IFX_MEM_FREE(ret_VlanStr);

ErrorHandler:
    if(ret != IFX_SUCCESS)
        IFX_MEM_FREE(ret_VlanStr);

    return 0;
}

#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
/*//////////////////////////////////////////////////////////////////////////////
* Update_mcast_wan_flag(...)
*		operation	==>	If 1, then write to file the value of mcast_wan_flag. Else read from file.
*		mcast_wan_flag	==>	If operation is 1, then write this value to the file
*
*       Return Value :   0 in case of write and file value in case of read.
        Description:
				The api reads/writes the mcast_Wan_flag to /tmp/mcast_wan_flag file
*//////////////////////////////////////////////////////////////////////////////
int32 Update_mcast_wan_flag(int operation,int mcast_wan_flag) {
	FILE * fd = NULL;
	int val=mcast_wan_flag;
	if ( operation ) {
		fd = fopen("/tmp/mcast_wan_flag", "w");
		if ( fd ) {
			fprintf(fd,"%d",val);
			fclose(fd);
			IFX_DBG("writing mcast_wan_flag value %d\n",val);
			return(0);
		}else {
			IFX_DBG("[%s:%d] Could not open mcast_wan_flag file !!\n", __FUNCTION__, __LINE__);
			return(0);
		}
	} else {
		fd = fopen("/tmp/mcast_wan_flag", "r");
		if ( fd ) {
			fscanf(fd,"%d",&val);
			IFX_DBG("reading mcast_wan_flag value %d\n",val);
			fclose(fd);
			return(val);
		}else {
			IFX_DBG("[%s:%d] Could not open mcast_wan_flag file !!\n", __FUNCTION__, __LINE__);
			return(0);
		}
	}
}

/*//////////////////////////////////////////////////////////////////////////////
* Update_mcast_wan_strings(...)
*		igmpoldconnName	==>	WAN string to be removed from list
*		igmpnewconnName	==>	WAN string to be added to list
*
        Description:
				The api deletes igmpoldconnName, addes new connName and decreases WAN indices in case there is
				a WAN index mis-alignment.
*//////////////////////////////////////////////////////////////////////////////
void Update_mcast_wan_strings(char *sVal,char *igmpoldconnName,char *igmpnewconnName,char *iflist,char *wan_type,int delete)
{
	char wan_string[MAX_DATA_LEN];
	char *ptr = NULL;
	char *ptr_iflist = NULL;
	char write_list[MAX_DATA_LEN]="";
	int32 mcast_wan_flag;
	
	ptr_iflist = write_list;
	
	mcast_wan_flag = Update_mcast_wan_flag(0,0);
	IFX_DBG("delete=%d mcast_wan_flag=%d sVal=%s oldconnname=%s newconnname=%s wan_type=%s\n",delete,mcast_wan_flag,sVal,igmpoldconnName,igmpnewconnName,wan_type);
	if (delete || mcast_wan_flag == 3 || mcast_wan_flag == 1) {
		if ( igmpnewconnName != NULL ) {
			if (mcast_wan_flag == 1 ) {
				strcpy(ptr_iflist,sVal);
				ptr_iflist +=
				    strlen(sVal);
			}
			strcpy(ptr_iflist,
			       igmpnewconnName);
			ptr_iflist +=
			    strlen(igmpnewconnName);
			strcpy(ptr_iflist, ",");
			ptr_iflist += strlen(",");
		}
		if (mcast_wan_flag != 1 && delete != 2 ) {
			ptr = strtok(sVal, ",");
			while (ptr && ptr != '\0') {
				if ( (strcmp(ptr,igmpoldconnName)) == 0) {
					mcast_wan_flag=1;
				}
				else if ((strcmp (ptr,igmpoldconnName)) > 0 ) {
					if ( strstr(ptr,wan_type) != NULL ) {
						ptr += strlen(wan_type);
						sprintf(wan_string,"%s%d",wan_type,(atoi(&ptr[0])-1));
						strcpy(ptr_iflist,wan_string);
						ptr_iflist +=
						    strlen(wan_string);
						strcpy(ptr_iflist, ",");
						ptr_iflist += strlen(",");
					} else {
						strcpy(ptr_iflist,
						       ptr);
						ptr_iflist +=
						    strlen(ptr);
						strcpy(ptr_iflist, ",");
						ptr_iflist += strlen(",");
						}
					} else {
						strcpy(ptr_iflist,
						       ptr);
						ptr_iflist +=
						    strlen(ptr);
						strcpy(ptr_iflist, ",");
						ptr_iflist += strlen(",");
					}
					ptr = strtok(NULL, ",");
				}
			}
		} 
	ptr_iflist = iflist;
	ptr = strtok(write_list, ",");
	while (ptr && ptr != '\0') {
		if ( strlen(iflist)) {
			strcpy(ptr_iflist, ",");
			ptr_iflist += strlen(",");
		}
		strcpy(ptr_iflist,
		       ptr);
		ptr_iflist +=
		    strlen(ptr);
		ptr = strtok(NULL, ",");
	}
	Update_mcast_wan_flag(1,mcast_wan_flag);
						
}

/*//////////////////////////////////////////////////////////////////////////////
* Get_mcast_wan_iface_strings(...)
*               iflist ==>     WAN string that are added to the list
*               ptr_iflist ==>     WAN interface name to be added to list
*
        Description:
                                The api deletes igmp old iface Name, gets new iface Names from the 
				new added connNames
*//////////////////////////////////////////////////////////////////////////////
void Get_mcast_wan_iface_strings(char *iflist, char *ptr_iflist)
{
       char *ptr = NULL, *ptr_ifname = NULL;
       char write_list[MAX_DATA_LEN]="";
       char8 wan_name[MAX_NAME_SIZE];
       char8 ifname[MAX_NAME_SIZE];
       WAN_TYPE wan_type = WAN_TYPE_IP;

       ptr_ifname = ptr_iflist;
       strcpy(write_list,iflist);
       ptr = strtok(write_list, ",");
       while (ptr && ptr != '\0') {
               strcpy(wan_name,ptr);
               if (strstr(wan_name, "WANIP"))
                        wan_type = WAN_TYPE_IP;
               else if (strstr(wan_name, "WANPPP"))
                        wan_type = WAN_TYPE_PPP;

               if (IFX_SUCCESS != ifx_get_wan_ifname_from_connName(wan_name, ifname, wan_type)){
                        IFX_DBG("\n\n Function [%s] : Failed to get the interface name of %s !!\n",
                             __func__, wan_name);
                        ifname[0] = '\0';
                }

                strcpy(ptr_ifname, ifname);
                ptr_ifname += strlen(ifname);
                strcpy(ptr_ifname, ",");
                ptr_ifname += strlen(",");

                ptr = strtok(NULL, ",");
        }
        ptr_ifname--;
        ptr_ifname[0] = '\0';

}

/*//////////////////////////////////////////////////////////////////////////////
* sort_igmp_wan_strings(...)
*		str	==>	WAN strings list 	
*		n	==>	number of entries in WAN strings list
*
        Description:
				The api returns the sortd list of WAN strings
*//////////////////////////////////////////////////////////////////////////////
void sort_igmp_wan_strings(char *str[],int n) {
	char *tmp;
	int i=0;
	int j=0;
	for(i=0;i<n-1;i++) {
		for(j=i+1;j<n;j++) {
			if (strcmp(str[i],str[j])>0){
				tmp=str[i];
				str[i]=str[j];
				str[j]=tmp;
			}
		}
	}
}

/*//////////////////////////////////////////////////////////////////////////////
* Update_igmp_wan_config(...)
*		igmpoldconnName	==> 	specifies the old WAN connection name to be removed from igmp upstream list
*		igmpnewconnName	==>	specifies the new WAN connection name to be added for igmp upstream list
*		delete		==>	flag to delete the old WAN connection
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
        Description:
				The api removes old WAN string from rc.conf and adds new connection name.
*//////////////////////////////////////////////////////////////////////////////
int32 Update_igmp_wan_config(char8 *igmpoldconnName, char8 *igmpnewconnName,int delete)
{
	char sVal[MAX_DATA_LEN];
	char mcast_upstream_wan_string[MAX_DATA_LEN]="",wan_strings_array[MAX_DATA_LEN]="";
	char mcast_upstream_wan_iface_string[MAX_DATA_LEN]="";
	int j=0;
	char *str[8];
	char *temp_ptr=NULL;
	char *wan_type=NULL;
	int32 ret=IFX_SUCCESS;
	char *ptr = NULL;
	int i=0;
	int mcast_wan_flag;
	char_t sAdvparameter[1024];
	uint32 flags = IFX_F_DEFAULT;
	
	mcast_wan_flag = Update_mcast_wan_flag(0,0);
	if ( delete != 2 ) {
	if ( strstr(igmpoldconnName,"WANPPP") != NULL ) {
		wan_type=(malloc(strlen("WANPPP")));
		strcpy(wan_type,"WANPPP");
	} else {
		wan_type=(malloc(strlen("WANIP")));
		strcpy(wan_type,"WANIP");
	}
	}

	ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_upstream_wan",sVal);
	if (sVal[0] == '\0' && mcast_wan_flag == 1) {
		Update_mcast_wan_strings(sVal,igmpoldconnName,igmpnewconnName,mcast_upstream_wan_string,NULL,delete);
		gsprintf(sAdvparameter,"mcast_upstream_wan=\"%s\"\n",mcast_upstream_wan_string);
		if (ifx_SetObjData
		      (FILE_RC_CONF, TAG_MULTICAST, IFX_F_MODIFY,1, sAdvparameter) != 0) {
			return IFX_FAILURE;
		}

		Get_mcast_wan_iface_strings(mcast_upstream_wan_string,mcast_upstream_wan_iface_string);
                gsprintf(sAdvparameter,"mcast_upstream=\"%s\"\n",mcast_upstream_wan_iface_string);
                if (ifx_SetObjData
                      (FILE_RC_CONF, TAG_MULTICAST, IFX_F_MODIFY,1, sAdvparameter) != 0) {
                        return IFX_FAILURE;
                }

		ret = ifx_config_write(FILE_RC_CONF, flags);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		system("/etc/rc.d/init.d/igmpd wan_restart");
	} else if (sVal[0] != '\0') {
		if ( mcast_wan_flag != 1 && mcast_wan_flag != 3 ) {
			mcast_wan_flag=2;
			Update_mcast_wan_flag(1,mcast_wan_flag);
		}
		ptr = strtok(sVal, ",");
		while (ptr) {
			str[i] = ptr;
			ptr = strtok(NULL, ",");
			i++;
		}
		sort_igmp_wan_strings(str,i);
		temp_ptr=wan_strings_array;
		for ( j=0;j<i;j++ ) {
			strcpy(temp_ptr,str[j]);
			temp_ptr +=strlen(str[j]);
			strcpy(temp_ptr,",");
			temp_ptr +=strlen(",");
		}
		if ( delete !=2 ) {
			Update_mcast_wan_strings(wan_strings_array,igmpoldconnName,igmpnewconnName,mcast_upstream_wan_string,wan_type,delete);
			free(wan_type);
		} else {
			Update_mcast_wan_strings(wan_strings_array,NULL,igmpnewconnName,mcast_upstream_wan_string,NULL,delete);
		}
			
		gsprintf(sAdvparameter,"mcast_upstream_wan=\"%s\"\n",mcast_upstream_wan_string);
		if (ifx_SetObjData
		      (FILE_RC_CONF, TAG_MULTICAST, IFX_F_MODIFY,1, sAdvparameter) != 0) {
			return IFX_FAILURE;
		}
	
		Get_mcast_wan_iface_strings(mcast_upstream_wan_string,mcast_upstream_wan_iface_string);
                gsprintf(sAdvparameter,"mcast_upstream=\"%s\"\n",mcast_upstream_wan_iface_string);
                if (ifx_SetObjData
                      (FILE_RC_CONF, TAG_MULTICAST, IFX_F_MODIFY,1, sAdvparameter) != 0) {
                        return IFX_FAILURE;
                }
	
		ret = ifx_config_write(FILE_RC_CONF, flags);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		system("/etc/rc.d/init.d/igmpd wan_restart");
	}

      IFX_Handler:
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* Update_igmp_config(...)
*		igmpoldconnName	==> 	specifies the old WAN connection name to be removed from igmp upstream list
*		igmpnewconnName	==>	specifies the new WAN connection name to be added for igmp upstream list
*		delete		==>	flag to delete the old WAN connection
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
        Description:
				The api removes old WAN string from rc.conf and adds new connection name intrun by calling
				Update_igmp_wan_config.
*//////////////////////////////////////////////////////////////////////////////
int32 Update_igmp_config(char8 *igmpoldconnName, char8 *igmpnewconnName,int delete)
{
	char sVal[MAX_DATA_LEN];
	
	ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_upstream_wan", sVal);
		if ( delete == 1 ) {
			 return( Update_igmp_wan_config(igmpoldconnName,NULL,delete));
		} else if ( delete == 2) {
			 return( Update_igmp_wan_config(NULL,igmpnewconnName,delete));
		} else if ( igmpoldconnName != NULL && igmpnewconnName != NULL && strlen(igmpoldconnName) && strlen(igmpnewconnName) ) {
			 return(Update_igmp_wan_config(igmpoldconnName,igmpnewconnName,delete));
		}
	return IFX_SUCCESS;
}
#endif

/*//////////////////////////////////////////////////////////////////////////////
* mapi_get_wan_config_for_mode(...)
*	wanIdx		==>	input index of the wan connection for which configuration
*				has to be returned
*	wan_cfg		==>	output pointer to wan connection WAN_CONN_CFG
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads the wan connection configuration from rc.conf
			for the input wan index wanIdx and based on the link type it
			reads the specific connection parameters from either the
  			wan_ip or wan_ppp section from rc.conf
*//////////////////////////////////////////////////////////////////////////////
int32 mapi_get_wan_config_for_mode(int32 wanIdx, WAN_CONN_CFG * wan_conn_cfg, WAN_MODE wanMode,
				 uint32 flags)
{
	IFX_ID iid;
	int32 dist_wan_index = -1;
	char8 buf[MAX_FILELINE_LEN], retVal[MAX_FILELINE_LEN];
	int32 ret = IFX_SUCCESS, outFlag = IFX_F_DEFAULT;
	WAN_COMMON_CFG wan_comm_cfg;
	int32 wan_type = 0;
	char8 SECTION_TAG[MAX_TAG_LEN];
	char8 SECTION_PREFIX[MAX_TAG_LEN];

	memset(&wan_comm_cfg, 0x00, sizeof(wan_comm_cfg));
	memset(SECTION_PREFIX, 0x00, MAX_TAG_LEN);
	memset(SECTION_TAG, 0x00, MAX_TAG_LEN);

	/* Determine the WAN Connection Type - WAN_IP or WAN_PPP from
	 * the link type associated with the WAN device */
	wan_type = wan_conn_cfg->type;

	if (wan_type == WAN_TYPE_PPP) {
		sprintf(iid.cpeId.secName, "%s", TAG_WAN_PPP);
		wan_comm_cfg = wan_conn_cfg->WAN_PPP_CONN.WAN_CONN;
		sprintf(SECTION_TAG, "%s", TAG_WAN_PPP);
		sprintf(SECTION_PREFIX, "%s", PREFIX_WAN_PPP);
	} else if (wan_type == WAN_TYPE_IP) {
		sprintf(iid.cpeId.secName, "%s", TAG_WAN_IP);
		wan_comm_cfg = wan_conn_cfg->WAN_IP_CONN.WAN_CONN;
		sprintf(SECTION_TAG, "%s", TAG_WAN_IP);
		sprintf(SECTION_PREFIX, "%s", PREFIX_WAN_IP);
	} else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Invalid WAN type", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	if (wanIdx < 0) {
		/*check if cpe Id is passed */
		if (wan_comm_cfg.iid.cpeId.Id < 1) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] cpeId invalid", __FUNCTION__,
				__LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		iid.cpeId.Id = wan_comm_cfg.iid.cpeId.Id;

		if (ifx_get_index_from_cpe_id
		    (FILE_RC_CONF, &iid.cpeId,
		     &dist_wan_index) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("[%s:%d] Unable to retrieve wan index from cpeId",
			     __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	} else {
		dist_wan_index = wanIdx;
	}

	sprintf(buf, "%s_%d_wanMode", SECTION_PREFIX, dist_wan_index);
	memset(retVal, '\0', sizeof(retVal));
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, SECTION_TAG, buf, flags,
			       (IFX_OUT uint32 *) & outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve wan mode", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}
	/* if mode of this WAN connection is not requested wanMode, then return failure */
	if(atoi(retVal) != wanMode) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	ret = mapi_get_wan_config(wanIdx, wan_conn_cfg, flags);

IFX_Handler:
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s] : returned failure!", __FUNCTION__);
#endif
		return ret;
	} else {
		return IFX_SUCCESS;
	}
}

int32 mapi_get_all_wan_config_for_wan_mode(WAN_MODE wanMode, int32 * num_entries,
				     WAN_CONN_CFG ** pp_wancfg, uint32 flags)
{
	uint32 outFlag = IFX_F_DEFAULT;
	char8 buf[MAX_FILELINE_LEN], sVal[MAX_FILELINE_LEN];
	int32 count = 0, ret = IFX_SUCCESS, idx_count = 0,
	    i = 0, j = 0, wan_ipCount = 0, wan_pppCount = 0, wan_type = 0;
	WAN_CONN_CFG wan_cfg, *t_ptr = NULL;
	char8 secName[MAX_FILELINE_LEN], secPrefix[MAX_FILELINE_LEN];

	*num_entries = 0;

	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	NULL_TERMINATE(sVal, 0x00, sizeof(sVal));
	if (pp_wancfg == NULL)
        {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
                return ret;
	}

	for (j = 0; j < 2; j++) {
		if (j == 0) {
			sprintf(buf, "%s", "wan_ip_Count");
			sprintf(secName, "%s", TAG_WAN_IP);
		} else {
			sprintf(buf, "%s", "wan_ppp_Count");
			sprintf(secName, "%s", TAG_WAN_PPP);
		}
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, secName, buf, flags, &outFlag,
				    sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		idx_count = atoi(sVal);
		if (j == 0) {
			wan_ipCount = idx_count;
		} else {
			wan_pppCount = idx_count;
		}
	}

	idx_count = wan_ipCount + wan_pppCount;
	IFX_MEM_ALLOC(t_ptr, WAN_CONN_CFG *, idx_count, sizeof(WAN_CONN_CFG))
	*pp_wancfg = t_ptr;

	for (j = 0; j < 2; j++) {
		if (j == 0) {
			wan_type = WAN_TYPE_IP;
			idx_count = wan_ipCount;
			sprintf(secName, "%s", TAG_WAN_IP);
			sprintf(secPrefix, "%s", PREFIX_WAN_IP);
		} else {
			wan_type = WAN_TYPE_PPP;
			idx_count = wan_pppCount;
			sprintf(secName, "%s", TAG_WAN_PPP);
			sprintf(secPrefix, "%s", PREFIX_WAN_PPP);
		}

		for (i = 0; i < idx_count; i++) {
			memset(&wan_cfg, 0x00, sizeof(wan_cfg));

			wan_cfg.type = wan_type;

			sprintf(buf, "%s_%d_wanMode", secPrefix, i);
			if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, secName, buf, IFX_F_GET_ANY,
				       &outFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] ifx_GetObjDataOpt() Fail",
					__FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}

			if(atoi(sVal) == wanMode) {
				if ((ret = mapi_get_wan_config(i, &wan_cfg, flags)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}

				/* copy the wan_cfg into pp_wancfg */
				*(*pp_wancfg + count) = wan_cfg;
				count++;
			}
		}
	}
	*num_entries = count;

IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*pp_wancfg)
		* num_entries = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* mapi_get_wan_config(...)
*	wanIdx		==>	input index of the wan connection for which configuration
*				has to be returned
*	wan_cfg		==>	output pointer to wan connection WAN_CONN_CFG
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads the wan connection configuration from rc.conf
			for the input wan index wanIdx and based on the link type it
			reads the specific connection parameters from either the
  			wan_ip or wan_ppp section from rc.conf
*//////////////////////////////////////////////////////////////////////////////
int32 mapi_get_wan_config(int32 wanIdx, WAN_CONN_CFG * wan_conn_cfg,
				 uint32 flags)
{
	IFX_ID iid;
	int32 dist_wan_index = -1;
	char8 buf[MAX_FILELINE_LEN], retVal[MAX_FILELINE_LEN];
	int32 ret = IFX_SUCCESS, outFlag = IFX_F_DEFAULT;
	WAN_COMMON_CFG wan_comm_cfg;
	char8 name[16];
	NET_INTF_CFG params;
	int32 wan_type = 0;
	char8 SECTION_TAG[MAX_TAG_LEN];
	char8 SECTION_PREFIX[MAX_TAG_LEN];

	memset(&wan_comm_cfg, 0x00, sizeof(wan_comm_cfg));
	memset(SECTION_PREFIX, 0x00, MAX_TAG_LEN);
	memset(SECTION_TAG, 0x00, MAX_TAG_LEN);

	/* Determine the WAN Connection Type - WAN_IP or WAN_PPP from
	 * the link type associated with the WAN device */
	wan_type = wan_conn_cfg->type;

	if (wan_type == WAN_TYPE_PPP) {
		sprintf(SECTION_TAG, "%s", TAG_WAN_PPP);
		sprintf(SECTION_PREFIX, "%s", PREFIX_WAN_PPP);
		sprintf(iid.cpeId.secName, "%s", SECTION_TAG);
		wan_comm_cfg = wan_conn_cfg->WAN_PPP_CONN.WAN_CONN;
	} else if (wan_type == WAN_TYPE_IP) {
		sprintf(SECTION_TAG, "%s", TAG_WAN_IP);
		sprintf(SECTION_PREFIX, "%s", PREFIX_WAN_IP);
		sprintf(iid.cpeId.secName, "%s", SECTION_TAG);
		wan_comm_cfg = wan_conn_cfg->WAN_IP_CONN.WAN_CONN;
	} else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Invalid WAN type", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	if (wanIdx < 0) {
		/*check if cpe Id is passed */
		if (wan_comm_cfg.iid.cpeId.Id < 1) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] cpeId invalid", __FUNCTION__,
				__LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		iid.cpeId.Id = wan_comm_cfg.iid.cpeId.Id;

		if (ifx_get_index_from_cpe_id
		    (FILE_RC_CONF, &iid.cpeId,
		     &dist_wan_index) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("[%s:%d] Unable to retrieve wan index from cpeId",
			     __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	} else {
		dist_wan_index = wanIdx;
	}

	/* initialize the cache for this instance */
	sprintf(buf, "%s_%d_", SECTION_PREFIX, dist_wan_index);
	if (ifx_GetObjDataOpt
	    (FILE_RC_CONF, SECTION_TAG, buf, IFX_F_INT_CACHE_INIT | flags, NULL,
	     NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance",
			__FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	sprintf(buf, "%s_%d_cpeId", SECTION_PREFIX, dist_wan_index);
	memset(retVal, '\0', sizeof(retVal));
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, SECTION_TAG, buf, flags,
			       (IFX_OUT uint32 *) & outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve cpe Id", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.iid.cpeId.Id = atoi(retVal);

#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] wan_comm_cfg.iid.cpeId.Id = %d", __func__, __LINE__,
		wan_comm_cfg.iid.cpeId.Id);
#endif

	sprintf(buf, "%s_%d_pcpeId", SECTION_PREFIX, dist_wan_index);
	memset(retVal, '\0', sizeof(retVal));
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, SECTION_TAG, buf, flags,
			       (IFX_OUT uint32 *) & outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve  parent cpe Id",
			__FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.iid.pcpeId.Id = atoi(retVal);

	sprintf(buf, "%s_%d_fEnable", SECTION_PREFIX, dist_wan_index);
	memset(retVal, '\0', sizeof(retVal));
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, SECTION_TAG, buf, flags,
			       (IFX_OUT uint32 *) & outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve enable status",
			__FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.WAN_CONN_ENABLE = atoi(retVal);

	sprintf(buf, "%s_%d_linkType", SECTION_PREFIX, dist_wan_index);
	memset(retVal, '\0', sizeof(retVal));
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, SECTION_TAG, buf, flags,
			       (IFX_OUT uint32 *) & outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve Link type", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.link_type = atoi(retVal);

	sprintf(buf, "%s_%d_autoDiscTime", SECTION_PREFIX, dist_wan_index);
	memset(retVal, '\0', sizeof(retVal));
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, SECTION_TAG, buf, flags,
			       (IFX_OUT uint32 *) & outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve autoDiscTime", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.WAN_CONN_AUTO_DISCONNECT_TIME = atoi(retVal);

	sprintf(buf, "%s_%d_idleDiscTime", SECTION_PREFIX, dist_wan_index);
	memset(retVal, '\0', sizeof(retVal));
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, SECTION_TAG, buf, flags,
			       (IFX_OUT uint32 *) & outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve idleDiscTime", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.WAN_CONN_IDLE_DISCONNECT_TIME = atoi(retVal);

	sprintf(buf, "%s_%d_NATEnable", SECTION_PREFIX, dist_wan_index);
	memset(retVal, '\0', sizeof(retVal));
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, SECTION_TAG, buf, flags,
			       (IFX_OUT uint32 *) & outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve NAT Enable value",
			__FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.WAN_CONN_NAT_ENABLED = atoi(retVal);

	sprintf(buf, "%s_%d_macAddrOverride", SECTION_PREFIX, dist_wan_index);
	memset(retVal, '\0', sizeof(retVal));
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, SECTION_TAG, buf, flags,
			       (IFX_OUT uint32 *) & outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve mac override value",
			__FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.WAN_CONN_MAC_ADDR_OVERRIDE = atoi(retVal);

	sprintf(buf, "%s_%d_rxRouteProto", SECTION_PREFIX, dist_wan_index);
	memset(retVal, '\0', sizeof(retVal));
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, SECTION_TAG, buf, flags,
			       (IFX_OUT uint32 *) & outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve routing protocol",
			__FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.WAN_CONN_ROUTE_PROTO_RX = atoi(retVal);

	sprintf(buf, "%s_%d_wanMode", SECTION_PREFIX, dist_wan_index);
	memset(retVal, '\0', sizeof(retVal));
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, SECTION_TAG, buf, flags,
			       (IFX_OUT uint32 *) & outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve wan mode", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.wan_mode.mode = atoi(retVal);

#if 0
	if ((atoi(retVal) != WAN_MODE_ATM)) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Irelevant mode retrieved for WAN [%d] in [%s] as [%d]", __FUNCTION__,
			__LINE__, dist_wan_index, SECTION_TAG, atoi(retVal));
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
#endif // 0

	sprintf(buf, "%s_%d_maxMTU", SECTION_PREFIX, dist_wan_index);
	memset(retVal, '\0', sizeof(retVal));
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, SECTION_TAG, buf, flags,
			       (IFX_OUT uint32 *) & outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.max_mtu = atoi(retVal);

	sprintf(buf, "%s_%d_l3Proto", SECTION_PREFIX, dist_wan_index);
	memset(retVal, '\0', sizeof(retVal));
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, SECTION_TAG, buf, flags,
			       (IFX_OUT uint32 *) & outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve L3 Proto\n", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.l3_proto = atoi(retVal);

	sprintf(buf, "%s_%d_ipv6CfgType", SECTION_PREFIX, dist_wan_index);
	memset(retVal, '\0', sizeof(retVal));
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, SECTION_TAG, buf, flags,
			       (IFX_OUT uint32 *) & outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve ipv6 Cfg Type\n",
			__FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.ipv6CfgType = atoi(retVal);

	sprintf(buf, "%s_%d_mcProxyEna", SECTION_PREFIX, dist_wan_index);
	memset(retVal, '\0', sizeof(retVal));
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, SECTION_TAG, buf, flags,
			       (IFX_OUT uint32 *) & outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve Proxy Ena\n", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.mcProxyEna = atoi(retVal);

	sprintf(buf, "%s_%d_connName", SECTION_PREFIX, dist_wan_index);
	memset(retVal, '\0', sizeof(retVal));
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, SECTION_TAG, buf, flags,
			       (IFX_OUT uint32 *) & outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve connection name",
			__FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	STRNCPY(wan_comm_cfg.WAN_CONN_NAME, retVal,MAX_CONN_NAME_LEN-1);

	sprintf(buf, "%s_%d_confconnName", SECTION_PREFIX, dist_wan_index);
	memset(retVal, '\0', sizeof(retVal));
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, SECTION_TAG, buf, flags,
			       (IFX_OUT uint32 *) & outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve conf connection name",
			__FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	STRNCPY(wan_comm_cfg.WAN_CONF_CONN_NAME, retVal, MAX_CONN_NAME_LEN-1);

	NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
	NULL_TERMINATE(name, 0x00, sizeof(name));
	sprintf(buf, "%s_%d_l2ifName", SECTION_PREFIX, dist_wan_index);
	memset(retVal, '\0', sizeof(retVal));
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, SECTION_TAG, buf, flags,
			       (IFX_OUT uint32 *) & outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve interface name",
			__FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	snprintf(wan_comm_cfg.l2iface_name,MAX_IF_NAME, "%s", retVal);

	memset(&params, 0, sizeof(params));
	ifx_mod_interface_attr(name, IFX_GET_INTF_ATTR, &params);
	snprintf(wan_comm_cfg.WAN_CONN_MAC_ADDR, MAX_MAC_ADDR_LEN, "%s",
		 params.hwaddr);

	/* destroy the cache for this instance */
	sprintf(buf, "%s_%d_", SECTION_PREFIX, dist_wan_index);
	if (ifx_GetObjDataOpt
	    (FILE_RC_CONF, SECTION_TAG, buf, IFX_F_INT_CACHE_DESTROY, NULL,
	     NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to destroy cache for this instance",
			__FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] wan_comm_cfg.iid.cpeId.Id = %d", __func__, __LINE__,
		wan_comm_cfg.iid.cpeId.Id);
#endif
	if (wan_type == WAN_TYPE_PPP) {
		memcpy(&wan_conn_cfg->WAN_PPP_CONN.wan_cfg, &wan_comm_cfg,
		       sizeof(wan_comm_cfg));
		ifx_get_wan_ppp_config(dist_wan_index, wan_conn_cfg, flags);
	} else {
		memcpy(&wan_conn_cfg->WAN_IP_CONN.wan_cfg, &wan_comm_cfg,
		       sizeof(wan_comm_cfg));
		ifx_get_wan_ip_config(dist_wan_index, wan_conn_cfg, flags);
	}
#ifdef IFX_LOG_DEBUG
	IFX_DBG
	    ("[%s:%d] &wan_cfg->WAN_PPP_CONN.wan_cfg.iid.cpeId.Id = %d wan_comm_cfg.iid.cpeId.Id = %d",
	     __func__, __LINE__, wan_conn_cfg->WAN_PPP_CONN.wan_cfg.iid.cpeId.Id,
	     wan_comm_cfg.iid.cpeId.Id);
#endif

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s] : returned failure!", __FUNCTION__);
#endif
		return ret;
	} else {
		return IFX_SUCCESS;
	}
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_wan_ip_config(...)
*		operation	==> 	specifies the operation to be done such as ADD, DELETE or MODIFY
*		wan_index	==>		specifies the wan index of the wan connection to be configured
*		wan_ip_cfg	==>		pointer to WAN_IP_CONFIG structure which will store the ip connection specific parameters
*       flags       ==>  	flags that define the behaviour
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
        Description:
				The api adds, deletes or modifies wan ip connection. the api will store the wan ip connection specific
				parameters for the wan connection specified by wan_index. if the operation is modify the api will call
  				service stop on the wan_index, modify the ip parameters and call service start on the same wan_index.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_wan_ip_config(int32 operation, int32 wan_index,
			    WAN_IP_CONFIG * wan_ip_cfg, uint32 flags)
{
	char8 l2IfName[20];
	char8 wan_conn_name[MAX_CONN_NAME_LEN];
	char8 new_wan_conn_name[MAX_CONN_NAME_LEN];
#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
	char8 igmpoldconnName[MAX_CONN_NAME_LEN];
	int mcast_wan_flag;
#endif
	char8 cpeIDValStr[20];
	char8 *ret_WANStr = NULL, *ret_VlanStr = NULL;
	char8 buf_ifnas[MAX_FILELINE_LEN], ifnasStr[10];
	IFX_ID parent_iid, iid;
	int32 dist_wan_index = -1;
	IFX_NAME_VALUE_PAIR wan_main_array_fvp[WAN_IP_PARAM_COUNT];
	uint32 wan_main_fvp_count = 0;
	IFX_NAME_VALUE_PAIR *wan_main_changed_array_fvp = NULL;
	uint32 wan_main_changed_fcount = 0;
	char8 buf[MAX_DATA_LEN], conf_buf[MAX_FILELINE_LEN];
	int32 ret = IFX_SUCCESS;
	int32 outFlag = IFX_F_DEFAULT;
	char8 sValue[MAX_FILELINE_LEN], sCommand[MAX_FILELINE_LEN];
	WAN_CONN_CFG *p_wancfg = NULL;
	WAN_COMMON_CFG wan_comm_cfg;
	char8 sWan_IP[MAX_IP_ADDR_LEN], sWan_Mask[MAX_IP_ADDR_LEN];
	int i = 1, wipCnt=0 , wanIdx =0;
	char8 dns_servers[MAX_DNS_SERVERS * MAX_IP_ADDR_LEN + MAX_DNS_SERVERS + 1];
	char_t connbuf[BUF_SIZE_50K];
        connbuf[0] = '\0';
        int32  connnum = -1;
	int wanmode=0;
	//WAN_TYPE  type;
        IFX_ID tempIID; /*To get TR69ID for DevM*/
        int32 wcd_cpeid = 0;

	NULL_TERMINATE(l2IfName, 0, sizeof(l2IfName));
	NULL_TERMINATE(cpeIDValStr, 0, sizeof(cpeIDValStr));
	NULL_TERMINATE(buf_ifnas, 0, sizeof(buf_ifnas));
	NULL_TERMINATE(ifnasStr, 0, sizeof(ifnasStr));
	NULL_TERMINATE(sWan_IP, 0x00, sizeof(sWan_IP));
	NULL_TERMINATE(sWan_Mask, 0x00, sizeof(sWan_Mask));
	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
	memset(&wan_main_array_fvp, 0, sizeof(wan_main_array_fvp));
	memset(&wan_comm_cfg, 0x00, sizeof(wan_comm_cfg));
	memset(&parent_iid, 0, sizeof(parent_iid));
	memset(&tempIID, 0, sizeof(tempIID));
	memset(&iid, 0, sizeof(iid));
	memset(dns_servers, 0, sizeof(dns_servers));
	memset(&parent_iid, 0, sizeof(parent_iid));
	memset(&iid, 0, sizeof(iid));

	/*************** Prolog Block *********************/
	/* Set the flags based on operation */
	if (operation == IFX_OP_DEL) {
		flags |= IFX_F_DELETE;
	} else if (operation == IFX_OP_MOD) {
		flags |= IFX_F_MODIFY;
	} else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags))) {
		flags |= IFX_F_INT_ADD;
	}

	if ((IFX_DONT_VALIDATE_F_NOT_SET(flags))
	    && (IFX_DELETE_F_NOT_SET(flags))) {
		/* 1. Check whether the WAN_CONN_CFG is NULL, if so it's an Error!
		   Also check on valid flags condition */
		IFX_VALIDATE_PTR(wan_ip_cfg)
		    IFX_VALIDATE_FLAGS(flags)
	}

	/* Determine the WAN's parent Section from the pcpeId if it is
	 * passed or from VCC otherwise (incase of WEB/CLI configuration  */

	wan_comm_cfg = wan_ip_cfg->WAN_CONN;

	sprintf(wan_comm_cfg.iid.cpeId.secName, "%s", TAG_WAN_IP);
	sprintf(wan_comm_cfg.iid.pcpeId.secName, "%s", TAG_VLAN_CHANNEL);

	//iid = wan_comm_cfg.iid;
	if (wan_comm_cfg.iid.pcpeId.Id == 0) {
		/* Get the parent info from the passed baseifname information refering to WAN_CONN */
		snprintf(l2IfName,20, "%s", wan_ip_cfg->wan_cfg.l2iface_name);

		/* Get the base ifname from WAN Connection Device Section */
		if (ifx_ret_substr_from_distfield
		    (FILE_RC_CONF, wan_comm_cfg.iid.pcpeId.secName, "l2ifName",
		     l2IfName, &ret_VlanStr) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] \n", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		} else {
			/* Here we would have got the return string as wan_dev_x
			 * where 'x' denotes the device instance. Now get the cpeId
			 * for this instance 'x' */
			NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
			sprintf(conf_buf, "%s_%s", ret_VlanStr, "cpeId");
			if ((ifx_GetObjData
			     (FILE_RC_CONF, wan_comm_cfg.iid.pcpeId.secName,
			      conf_buf, IFX_F_GET_ANY,
			      (IFX_OUT uint32 *) & outFlag,
			      sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("[%s:%d] Unable to retrieve parent cpe Id",
				     __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			} else {
				wan_comm_cfg.iid.pcpeId.Id = atoi(sValue);
			}
		}
	}

	/* Update the Parent's cpeID and Section Name in piid
	 * This would be required only for ADD operation */
	//parent_iid.cpeId.Id = iid.pcpeId.Id;
	//sprintf(parent_iid.cpeId.secName, "%s", iid.pcpeId.secName);

	wan_ip_cfg->WAN_CONN.iid.cpeId = wan_comm_cfg.iid.cpeId;
	wan_ip_cfg->WAN_CONN.iid.pcpeId = wan_comm_cfg.iid.pcpeId;

	/**************** Validation Block *****************/
	if (IFX_INT_ADD_F_SET(flags)) {
		if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
			/* MANDATORY CHECK:
			 * Check if the wan_Connection Name is unique across WAN IP and PPP
			 * We assume that the wan_Connection Name must be unique across
			 * all connections ! */
			NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
			STRNCPY(conf_buf, wan_comm_cfg.WAN_CONN_NAME,
				strlen(wan_comm_cfg.WAN_CONN_NAME));

			/* Check if the wanConnName is configured, then it MUST be unique for any ADD Operation */
			if (strcmp(conf_buf, "")) {
				/*Check WANIP and WANPPP connection names */
				ret =
				    ifx_ret_substr_from_distfield(FILE_RC_CONF,
								  TAG_WAN_IP,
								  "connName",
								  conf_buf,
								  &ret_WANStr);
				if (ret == IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] connName = [%s] Not Unique",
					     __FUNCTION__, __LINE__,
					     ret_WANStr);
#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				} else {
					IFX_MEM_FREE(ret_WANStr);
					ret =
					    ifx_ret_substr_from_distfield
					    (FILE_RC_CONF, TAG_WAN_PPP,
					     "connName", conf_buf, &ret_WANStr);
					if (ret == IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
						IFX_DBG
						    ("[%s:%d]connName[%s] Not Unique",
						     __FUNCTION__, __LINE__,
						     ret_WANStr);
#endif
						ret = IFX_FAILURE;
						goto IFX_Handler;
					}
				}

			}
		}

		/**************** ID Allocation Block - Only for ADD Operation **************/
		/* Form tag of parent section and get cpeId Allocate iid for Add */
		//ret = ifx_get_IID(&wan_ip_cfg->WAN_CONN.iid, "connType");
                ret = mapi_get_wcd_from_vlan(wan_ip_cfg->WAN_CONN.iid.pcpeId.Id, &wcd_cpeid);
		if (ret != IFX_SUCCESS)
                {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to get WCD cpe Id\n",__FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	        tempIID.cpeId = wan_ip_cfg->WAN_CONN.iid.cpeId;
	        sprintf(tempIID.cpeId.secName, "%s", wan_ip_cfg->WAN_CONN.iid.cpeId.secName);
	        sprintf(tempIID.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);
                tempIID.pcpeId.Id = wcd_cpeid;
                tempIID.config_owner = wan_ip_cfg->WAN_CONN.iid.config_owner;
                strcpy(tempIID.tr69Id,wan_ip_cfg->WAN_CONN.iid.tr69Id);
		ret = ifx_get_IID(&tempIID, "connType");
		if (ret != IFX_SUCCESS)
                {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to allocate IID for ADD",
				__FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Allocated IID [%d]!", __FUNCTION__, __LINE__,
				tempIID.cpeId.Id);
#endif
		/* Update the allocated IID in WAN CONNECTION */
		wan_comm_cfg.iid.cpeId = tempIID.cpeId;
                wan_ip_cfg->WAN_CONN.iid.cpeId = tempIID.cpeId;
                strcpy(wan_ip_cfg->WAN_CONN.iid.tr69Id,tempIID.tr69Id);
                strcpy(wan_comm_cfg.iid.tr69Id,tempIID.tr69Id);
		wan_comm_cfg.iid.pcpeId = wan_ip_cfg->WAN_CONN.iid.pcpeId;
	}

	/* Get WAN Index in case of modify/delete operations from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wan_comm_cfg.iid.cpeId,
					 dist_wan_index)
		    wan_index = dist_wan_index;
	}
	/**************** Name Value Formation as per RC.CONF ********************/
	/* Form the name-value pairs for ACL Checking & Validation */
	if (IFX_DELETE_F_NOT_SET(flags)) {
		if (IFX_INT_ADD_F_SET(flags)) {
			dist_wan_index = -1;
			ifx_get_index_from_sec_count(FILE_RC_CONF, TAG_WAN_IP,
						     &dist_wan_index,
						     IFX_F_GET_ANY);
			sprintf(wan_conn_name, "%s%d", "WANIP", dist_wan_index);
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
	if(!strlen(wan_comm_cfg.WAN_CONN_NAME))
		sprintf(wan_comm_cfg.WAN_CONN_NAME, "%s", wan_conn_name);
	if(!strlen(wan_comm_cfg.WAN_CONF_CONN_NAME)) 
		sprintf(wan_comm_cfg.WAN_CONF_CONN_NAME, "%s", wan_conn_name);
#endif
			memset(&newconnName , 0x00, sizeof(newconnName));
	                sprintf(newconnName, "%s", wan_conn_name);
		}
	}

	ifx_fill_ArrayFvp_FName(wan_main_array_fvp, 0, 24, wan_ip_param_names);
	//ifx_fill_ArrayFvp_intValues(wan_main_array_fvp, 0, 17, (int32 *)&wan_comm_cfg.iid.cpeId.Id, &wan_comm_cfg.iid.pcpeId.Id, &wan_comm_cfg.WAN_CONN_ENABLE, &wan_comm_cfg.link_type, &wan_comm_cfg.WAN_CONN_AUTO_DISCONNECT_TIME, &wan_comm_cfg.WAN_CONN_IDLE_DISCONNECT_TIME, &wan_comm_cfg.WAN_CONN_NAT_ENABLED, &wan_comm_cfg.WAN_CONN_MAC_ADDR_OVERRIDE, &wan_comm_cfg.WAN_CONN_ROUTE_PROTO_RX, &wan_comm_cfg.wan_mode, &wan_comm_cfg.vlanId, &wan_comm_cfg.conn_type, &wan_comm_cfg.max_mtu, &wan_comm_cfg.l3_proto, &wan_comm_cfg.ipv6CfgTpe, &wan_comm_cfg.mcProxyEna, &wan_comm_cfg.addr_type);
	ifx_fill_ArrayFvp_intValues(wan_main_array_fvp, 0, 16,
				    (int32 *) & wan_comm_cfg.iid.cpeId.Id,
				    &wan_comm_cfg.iid.pcpeId.Id,
				    &wan_comm_cfg.WAN_CONN_ENABLE,
				    &wan_comm_cfg.link_type,
				    &wan_comm_cfg.WAN_CONN_AUTO_DISCONNECT_TIME,
				    &wan_comm_cfg.WAN_CONN_IDLE_DISCONNECT_TIME,
				    &wan_comm_cfg.WAN_CONN_NAT_ENABLED,
				    &wan_comm_cfg.WAN_CONN_MAC_ADDR_OVERRIDE,
				    &wan_comm_cfg.WAN_CONN_ROUTE_PROTO_RX,
				    &wan_comm_cfg.wan_mode.mode,
				    &wan_ip_cfg->conn_type,
				    &wan_comm_cfg.max_mtu,
				    &wan_comm_cfg.l3_proto,
				    &wan_comm_cfg.ipv6CfgType,
				    &wan_comm_cfg.mcProxyEna,
				    &wan_ip_cfg->addr_type);

	wan_main_fvp_count = 16;
	ifx_fill_ArrayFvp_strValues(wan_main_array_fvp, 16, 4,
				    strcmp(wan_comm_cfg.WAN_CONN_NAME,
					   "") ? wan_comm_cfg.
				    WAN_CONN_NAME : wan_conn_name,
				    strcmp(wan_comm_cfg.WAN_CONF_CONN_NAME,
					   "") ? wan_comm_cfg.
				    WAN_CONF_CONN_NAME : wan_conn_name,
				    strlen(wan_comm_cfg.
					   WAN_CONN_MAC_ADDR) ? wan_comm_cfg.
				    WAN_CONN_MAC_ADDR : "",
				    &wan_comm_cfg.l2iface_name);
	
	wan_main_fvp_count = 20;
	sprintf(wan_main_array_fvp[wan_main_fvp_count++].value, "%s", wan_comm_cfg.l2iface_name);

#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
	sprintf(wan_main_array_fvp[wan_main_fvp_count++].value, "%d", wan_comm_cfg.autodetect);
#endif 
	for(i=0; i<MAX_DNS_SERVERS; i++)
	{
		if(strlen(inet_ntoa(wan_comm_cfg.wandns.dns_servers[i])) && strcmp(inet_ntoa(wan_comm_cfg.wandns.dns_servers[i]), "0.0.0.0")) {
			strcat(dns_servers, inet_ntoa(wan_comm_cfg.wandns.dns_servers[i]));
			strcat(dns_servers, ",");
		}
	}
	dns_servers[strlen(dns_servers) - 1] = '\0';

	if(IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		if(wan_comm_cfg.wandns.WAN_CONN_DNS_OVERRIDE == 0 && strlen(dns_servers) == 0) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] DNS override is set to FALSE and DNS server values not provided. WAN IP configuration failed.",
								__FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	sprintf(wan_main_array_fvp[wan_main_fvp_count++].value, "%d", wan_comm_cfg.wandns.WAN_CONN_DNS_OVERRIDE);
	sprintf(wan_main_array_fvp[wan_main_fvp_count++].value, "%s", dns_servers);

	ifx_fill_ArrayFvp_intValues(wan_main_array_fvp, wan_main_fvp_count, 9,
				    &wan_comm_cfg.ipv4, &wan_comm_cfg.ipv6,
				    &wan_comm_cfg.dhcp_mode, &wan_comm_cfg.iana,
				    &wan_comm_cfg.iapd, &wan_comm_cfg.slaid,
				    &wan_comm_cfg.rapid, &wan_comm_cfg.tunnel,
				    &wan_comm_cfg.duid_t);
	sprintf(wan_main_array_fvp[wan_main_fvp_count++].fieldname, "%s", "ipv4");
	sprintf(wan_main_array_fvp[wan_main_fvp_count++].fieldname, "%s", "ipv6");
	sprintf(wan_main_array_fvp[wan_main_fvp_count++].fieldname, "%s", "dhcpv6State");
	sprintf(wan_main_array_fvp[wan_main_fvp_count++].fieldname, "%s", "ianaID");
	sprintf(wan_main_array_fvp[wan_main_fvp_count++].fieldname, "%s", "iapdID");
	sprintf(wan_main_array_fvp[wan_main_fvp_count++].fieldname, "%s", "slaID");
	sprintf(wan_main_array_fvp[wan_main_fvp_count++].fieldname, "%s", "rapid");
	sprintf(wan_main_array_fvp[wan_main_fvp_count++].fieldname, "%s", "tunnel");
	sprintf(wan_main_array_fvp[wan_main_fvp_count++].fieldname, "%s", "duidt");

	wan_main_fvp_count = WAN_IP_PARAM_COUNT;

	/* Form the fully qualified Name Value Pairs */
	if (ifx_get_conf_index_and_nv_pairs
    (&wan_comm_cfg.iid, dist_wan_index, PREFIX_WAN_IP, wan_main_fvp_count,
     wan_main_array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	/* Ignore the "ifnas" and "ifType" in WAN MAIN for ACL
	 * Hence count should be (count - 2)
	 */
	if (IFX_INT_ADD_F_SET(flags))
        {
            CHECK_ACL_RET(tempIID, (wan_main_fvp_count - 2), wan_main_array_fvp,
	          wan_main_changed_fcount, wan_main_changed_array_fvp, flags, IFX_Handler)
        }
        else
        {
            CHECK_ACL_RET(wan_comm_cfg.iid, (wan_main_fvp_count - 2), wan_main_array_fvp,
	          wan_main_changed_fcount, wan_main_changed_array_fvp, flags, IFX_Handler)
        }
	/********* System Config File Update Block  **********/
        /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
        memset(buf, 0x00, sizeof(buf));
        form_cfgdb_buf(buf, wan_main_fvp_count, wan_main_array_fvp);

        ret = IFX_SUCCESS;
        if (operation == IFX_OP_ADD)
        {
                ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_IP, flags, 1, buf);
                if (ret != IFX_SUCCESS) {
                #ifdef IFX_LOG_DEBUG
                	IFX_DBG("[%s:%d] Set Data in rc.conf Fail", __FUNCTION__, __LINE__);
                #endif
                	goto IFX_Handler;
                }

                ifx_CompactCfgSection(FILE_RC_CONF, TAG_WAN_IP, flags);
		/*********** Device Configuration Block ****************/
		/* Device config thru Scripts/Utilities or Functions */
                if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)
                    && IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags))
                {
                	/* For now we ignore all the stopped services and start
                	 * services again */

                	/* Irrespective of the operation, retrieve index from rc.conf */
                	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wan_ip_cfg->WAN_CONN.iid.cpeId,
	        			 dist_wan_index)

                }

		/* Copy tr69id from ip connection tr69id, because the tr69id allocation will happen in ip set api */
                if (wan_comm_cfg.iid.config_owner == IFX_WEB)
                {
                	STRNCPY(wan_comm_cfg.WAN_CONN_IID.tr69Id,
	                	wan_comm_cfg.WAN_CONN_IID.tr69Id,
//                		strlen(wan_comm_cfg.WAN_CONN_IID.tr69Id));
                		MAX_TR69_ID_LEN -1) ;
                }
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */
		/*********** Epilog Block **************/
		/* Manipulate nextCpeId only for ADD operations */
		//ifx_increment_wanindex(FILE_RC_CONF, TAG_WAN_INDEX, &dist_wan_index);

                //UPDATE_ID_MAP_N_ATTRIBUTES(&wan_ip_cfg->WAN_CONN.WAN_CONN_IID,
                UPDATE_ID_MAP_N_ATTRIBUTES(&tempIID,
			   wan_main_fvp_count, wan_main_array_fvp, flags,
			   IFX_Handler)

                CHECK_N_SEND_NOTIFICATION(tempIID, wan_main_fvp_count,
			      wan_main_array_fvp, flags, IFX_Handler)

                /* Manipulate nextCpeId only for ADD operations */
                ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WAN_IP);
                ifx_increment_idx_value(FILE_RC_CONF, "index_sec", "subnasIdx");
            }
            else if (operation == IFX_OP_MOD)
            {
        	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)
                	    && IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) 
                {
                        /* First deactivate */
        		sprintf(sCommand, "%s %d", SERVICE_WANIP_STOP, dist_wan_index);
        		ret = system(sCommand);
        		ret = IFX_SUCCESS;

        		if (ret != IFX_SUCCESS) {
        			goto IFX_Handler;
        		}
        	}

        	/* Activate with the new configuration */
        	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_IP, flags, 1, buf);
        	if (ret != IFX_SUCCESS) {
                        #ifdef IFX_LOG_DEBUG
        		IFX_DBG("[%s:%d] Set Data in rc.conf Fail", __FUNCTION__,
        			__LINE__);
                        #endif
        		goto IFX_Handler;
        	}

		/*********** Device Configuration Block ****************/
        	/* Device config thru Scripts/Utilities or Functions */
        	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)
                	    && IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) {
	        	/* For now we ignore all the stopped services and start
	        	 * services again */
			if(IFX_INT_DONT_START_SERVICES_F_NOT_SET(flags)) {
		        	if (IFX_DEACTIVATE_F_NOT_SET(flags)) {
		        		/* Just bring up this WAN interface for ADD/MODIFY-ENABLE cases */
	        			sprintf(sCommand, "%s %d", SERVICE_WANIP_START,
	        				wan_index);
	        			ret = system(sCommand);
	        			ret = IFX_SUCCESS;
	        		}
	
			}

        	}

		/*********** Notification Block *************/
        	/* Notify the Internal TR69 Stack in case of MODIFY
        	 * This Notification would only be for WAN MAIN params */
        	/* Notification for WAN MAIN mappings */
        	CHECK_N_SEND_NOTIFICATION(wan_comm_cfg.iid, wan_main_changed_fcount,
				  wan_main_changed_array_fvp, flags,
				  IFX_Handler)
        }
        else
        {
        	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)
        	    && IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags))
                {
#ifndef HOSTENV
        		sprintf(sCommand, "%s %d", SERVICE_WANIP_STOP, wan_index);
        		ret = system(sCommand);
        		ret = IFX_SUCCESS;

        		if (ret != IFX_SUCCESS) {
        			/* For now we just goto the IFX_Handler and return IFX_FAILURE */
        			goto IFX_Handler;
        		}
#endif
        	}

	        /* Case of Delete - so first remove the entry from wan_ip section */
        	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_IP, flags, 1, buf);
        	if (ret != IFX_SUCCESS) {
                        #ifdef IFX_LOG_DEBUG
        		IFX_DBG("[%s:%d] Set Data in rc.conf Fail", __FUNCTION__,
        			__LINE__);
                        #endif
        		goto IFX_Handler;
        	}
		
		if (ifx_get_sec_count(TAG_WAN_IP, &wipCnt) != IFX_SUCCESS) {

                }

		/*Stop wan services before compaction */
                for (i = 0; i < wipCnt; i++)
                {
                        #ifdef IFX_LOG_DEBUG
                        IFX_DBG("[%s:%d] ^^^^^^^^^^SERVICE_WANIP_STOP^^^^^^^^",__FUNCTION__, __LINE__ );
			#endif
                        sprintf(sCommand, "%s %d", SERVICE_WANIP_STOP,i);
                        system(sCommand);
                }
		
        	/* Update the TR69 ID obtained above to reflect in the Mappings for WAN MAIN */
        	ifx_CompactCfgSection(FILE_RC_CONF, TAG_WAN_IP, flags);

//rearrange wan connection names
                if (ifx_get_all_wan_config(&wipCnt, WAN_TYPE_IP, &p_wancfg, IFX_F_DEFAULT)) {

                }
                for (i = 0; i < wipCnt; i++) {
			
			/*Restart WAN IP service on each wan connection after compaction*/
                        #ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] ^^^^^^^^^^SERVICE_WANIP_START^^^^^^^^",__FUNCTION__, __LINE__ );
			#endif
                        sprintf(sCommand, "%s %d", SERVICE_WANIP_START,i);
                        system(sCommand);
		
			/*get wan connection details from connection name*/
                        sprintf(new_wan_conn_name, "%s",(p_wancfg + i)->wancfg.ip.wan_cfg.conn_name);
			//GET_WAN_DETAILS_FROM_CONN_NAME(new_wan_conn_name, type, connnum, buf);
			GET_WAN_IDX_FROM_CONN_NAME(new_wan_conn_name, connnum)
			
			/*If wan wan connection numbers dont allign update the section */
			if( (connnum != i) && (connnum != -1) ) {
                        #ifdef CONFIG_FEATURE_NAPT    
                        #ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] delete virtual server [%s] ",__FUNCTION__, __LINE__, new_wan_conn_name);
			#endif
                               
				/*delete virtual server section related to old wan connection name (save all the values in structure)*/ 
				ret = mapi_delete_old_virtualserver(new_wan_conn_name, "realign");
                                
				if (ret != IFX_SUCCESS) {
                                IFX_DBG("[%s:%d] unable to delete virtual server ",__FUNCTION__, __LINE__);
                                }
			#endif
#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
				if(mapi_pwb_delentry_on_wanchange(new_wan_conn_name, &mapi_pwb) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                                	IFX_DBG("delete pwb entry failed in function [%s] line [%d]  !!", __FUNCTION__, __LINE__);
#endif
                                }
#endif
				/*Modify wan connection name*/
				sprintf(connbuf,"wanip_%d_connName=\"WANIP%d\"\n",i,i);
                                if(ifx_SetObjData(FILE_RC_CONF, TAG_WAN_IP, IFX_F_MODIFY, 1, connbuf) != IFX_SUCCESS) {
                                }

				/*realign default wan fused section*/
				sprintf(conf_buf, "wanip_%d_wanMode",i);
				if ((ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP,conf_buf, IFX_F_GET_ANY,(IFX_OUT uint32 *) & outFlag,sValue)) != IFX_SUCCESS) 							{
					#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] fetch wan mode value failed",
					     __FUNCTION__, __LINE__);
					#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				} else {
					wanmode = atoi(sValue);
					sprintf(conf_buf,"default_wan_%d_conn_iface", wanmode);
	                		if ((ifx_GetObjData(FILE_RC_CONF,TAG_DEF_WAN_FUSED,conf_buf, IFX_F_GET_ANY,(IFX_OUT uint32 *) & outFlag,sValue)) != IFX_SUCCESS)
					{
						#ifdef IFX_LOG_DEBUG
			                        IFX_DBG("[%s:%d] ERROR ERROR fetch default wan fused iface value",__FUNCTION__, __LINE__);
						#endif
                                		ret = IFX_FAILURE;
                                		goto IFX_Handler;
                        		}
					else{
						if(!strncmp((p_wancfg + i)->wancfg.ip.wan_cfg.l2iface_name,sValue,strlen((p_wancfg + i)->wancfg.ip.wan_cfg.l2iface_name))){
							sprintf(connbuf,"default_wan_%d_conn_connName=\"WANIP%d\"\n",wanmode,i);
		                                	if(ifx_SetObjData(FILE_RC_CONF, TAG_DEF_WAN_FUSED, IFX_F_MODIFY, 1, connbuf) != IFX_SUCCESS) {
                		                	}
						}
					}
				}
				/*reallign default fused END**/
			#ifdef CONFIG_FEATURE_NAPT
                                memset(&newconnName , 0x00, sizeof(newconnName));
                                sprintf(newconnName, "WANIP%d",i);
#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
				memset(&igmpoldconnName , 0x00, sizeof(igmpoldconnName));
				strcpy(igmpoldconnName,newconnName);
#endif
				#ifdef IFX_LOG_DEBUG
	                                IFX_DBG("[%s:%d]  [%s] ",__FUNCTION__, __LINE__, newconnName);
				#endif

#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
                                sprintf(newconnName, "WANIP%d",i);
      		          	if(mapi_pwb_modentry_on_wanchange(newconnName, mapi_pwb) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                        		IFX_DBG("function [%s] line [%d]  !!", __FUNCTION__, __LINE__);
#endif
                		}               
#endif

				/* update virtual server section related to new wan connection name (uses stored values in structure)*/
                                ret = Update_virtual_server_config(newconnName,"realign");
                                if (ret != 0)
                                {
                                                IFX_DBG("   Update virtual server failed .....  in func [%s] line [%d]  !!", __FUNCTION__, __LINE__);
                                }
			#endif
#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
				mcast_wan_flag = Update_mcast_wan_flag(0,0);
				if ( mcast_wan_flag == 0 )
	                                ret = Update_igmp_config(igmpoldconnName,NULL,1);
                                if (ret != 0)
                                {
                                                IFX_DBG("   Update igmp failed .....  in func [%s] line [%d]  !!", __FUNCTION__, __LINE__);
                                }
#endif
				
				/*Update default wan interface section*/
				if (ifx_get_default_wan_if(&iid, &wanIdx, sValue, IFX_F_DEFAULT) != IFX_SUCCESS)
                                {

                                }
                                if(!strcmp(new_wan_conn_name ,sValue ))
				{
					ret =   ifx_set_default_wan_if(&(p_wancfg + i)->wancfg.ip.wan_cfg.iid, WAN_TYPE_IP, IFX_F_MODIFY);	
				}
                        }

                }
//rearrange wan connection names: end


        	CHECK_N_SEND_NOTIFICATION(wan_ip_cfg->WAN_CONN.WAN_CONN_IID,
				  wan_main_fvp_count, wan_main_array_fvp, flags,
				  IFX_Handler)

                UPDATE_ID_MAP_N_ATTRIBUTES(&wan_ip_cfg->WAN_CONN.WAN_CONN_IID,
				       wan_main_fvp_count, wan_main_array_fvp,
				       flags, IFX_Handler)
        }

#if 0
	/* Update the LinkType in VCChannel Section if config owner is WEB
	 * In case of WEB, we will be creating the VCC before creation of WAN
	 * Connection. So we wouldn't be knowing the LinkType of the VCC. This
	 * will be known only from the WAN IP or WAN PPP Connections */

if ((IFX_DELETE_F_NOT_SET(flags))
    && (wan_ip_cfg->wan_cfg.iid.config_owner == IFX_WEB)) {
	IFX_DBG("[%s:%d] l2iface [%s:%s] linktype [%d]", __FUNCTION__, __LINE__,
		wan_ip_cfg->wan_cfg.iface_name, wan_comm_cfg.iface_name,
		wan_comm_cfg.link_type);
	if ((ret =
	     ifx_set_channel_link_type(wan_ip_cfg->wan_cfg.iface_name,
				       wan_comm_cfg.link_type,
				       IFX_F_MODIFY)) != IFX_SUCCESS) {
		/* Here we need to put in ACL & Notification inside this function
		 * But if ACL prevents this modfication - how to revert back ??
		 */
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Update Link Type Fail", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}
}
#endif

	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions
	 * This would have been done from the WANIP or WANPPP calls */

	/* Updating Persistent Storage */
        ret = ifx_config_write(FILE_RC_CONF, flags);
        if (ret != IFX_SUCCESS) {
                #ifdef IFX_LOG_DEBUG
        	IFX_DBG("[%s:%d] Update persistent storage fail", __FUNCTION__,
        		__LINE__);
                #endif
        	goto IFX_Handler;
        }

IFX_Handler:
    IFX_MEM_FREE(ret_WANStr)
    IFX_MEM_FREE(ret_VlanStr)
    IFX_MEM_FREE(wan_main_changed_array_fvp)
    IFX_MEM_FREE(p_wancfg);
    if (ret != IFX_SUCCESS)
    {
        IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
        return ret;
    }
    else
	return IFX_SUCCESS;

}

int32 ifx_set_wan_ipv4_config(int32 operation, WAN_IPV4_CFG * wan_ipv4_cfg,
			      WAN_IPV6_CFG * wan_ipv6_cfg, uint32 flags)
{
	char8 l2IfName[20];
	char8 cpeIDValStr[20];
	char8 *ret_WANStr = NULL, *ret_WANConnDevStr = NULL;
	char8 buf_ifnas[MAX_FILELINE_LEN], ifnasStr[10];
	IFX_ID parent_iid, iid, wan_iid;
	int32 dist_wan_index = -1, dist_wanip_index = -1;
	IFX_NAME_VALUE_PAIR wan_main_array_fvp[36];
	uint32 wan_main_fvp_count = 0;
	IFX_NAME_VALUE_PAIR *wan_main_changed_array_fvp = NULL;
	uint32 wan_main_changed_fcount = 0;
	char8 buf[MAX_DATA_LEN], conf_buf[MAX_FILELINE_LEN];
	int32 ret = IFX_SUCCESS;
	char8 sCommand[MAX_FILELINE_LEN];
	WAN_COMMON_CFG wan_comm_cfg;
	char8 sWan_IP[MAX_IP_ADDR_LEN], sWan_Mask[MAX_IP_ADDR_LEN],
	    sWan_Gw[MAX_IP_ADDR_LEN], ipv4_wan_prefix[MAX_NAME_LEN];
        int8 ip6_addr[64] = "\0",  ip6_addr1[64] = "\0",  ip6_addr2[64] = "\0",  
            ip6_addr3[64] = "\0",  ip6_addr4[64] = "\0";

	NULL_TERMINATE(l2IfName, 0, sizeof(l2IfName));
	NULL_TERMINATE(cpeIDValStr, 0, sizeof(cpeIDValStr));
	NULL_TERMINATE(buf_ifnas, 0, sizeof(buf_ifnas));
	NULL_TERMINATE(ifnasStr, 0, sizeof(ifnasStr));
	NULL_TERMINATE(sWan_IP, 0x00, sizeof(sWan_IP));
	NULL_TERMINATE(sWan_Mask, 0x00, sizeof(sWan_Mask));
	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
	memset(&wan_main_array_fvp, 0, sizeof(wan_main_array_fvp));
	memset(&wan_comm_cfg, 0x00, sizeof(wan_comm_cfg));
	memset(&parent_iid, 0, sizeof(parent_iid));
	memset(&iid, 0, sizeof(iid));
	memset(&wan_iid, 0, sizeof(wan_iid));

		/*************** Prolog Block *********************/
	/* Set the flags based on operation */
	if (operation == IFX_OP_DEL) {
		flags |= IFX_F_DELETE;
	} else if (operation == IFX_OP_MOD) {
		flags |= IFX_F_MODIFY;
	} else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags))) {
		flags |= IFX_F_INT_ADD;
	}

		/**************** Validation Block *****************/
	if ((IFX_DONT_VALIDATE_F_NOT_SET(flags))
	    && (IFX_DELETE_F_NOT_SET(flags))) {
		/* 1. Check whether the WAN_CONN_CFG is NULL, if so it's an Error!
		   Also check on valid flags condition */
		IFX_VALIDATE_PTR(wan_ipv4_cfg)
		    IFX_VALIDATE_FLAGS(flags)
		    /* We assume this object is not exposed to outside MAPI. So the user of this MAPI is is ifx_set_wan_ip_config MAPI itself
		       And hence parent cpe id info will be passed by the user to this MAPI in all cases */
		    if (wan_ipv4_cfg->iid.pcpeId.Id == 0) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] pcpeid [%d] cant be", __FUNCTION__,
				__LINE__, wan_ipv4_cfg->iid.pcpeId.Id);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	/* Determine the WAN's parent Section from the pcpeId if it is
	 * passed or from VCC otherwise (incase of WEB/CLI configuration  */

	sprintf(wan_ipv4_cfg->iid.cpeId.secName, "%s", TAG_WAN_IPV4CFG);
	sprintf(wan_ipv4_cfg->iid.pcpeId.secName, "%s", TAG_WAN_IP);

	iid = wan_ipv4_cfg->iid;

	/* Update the Parent's cpeID and Section Name in piid
	 * This would be required only for ADD operation */
	parent_iid.cpeId = iid.pcpeId;
	//sprintf(parent_iid.cpeId.secName, "%s", iid.pcpeId.secName);

	if (IFX_INT_ADD_F_SET(flags)) {
				/**************** ID Allocation Block - Only for ADD Operation **************/
		/* Form tag of parent section and get cpeId Allocate iid for Add */
		memset(&iid, 0x00, sizeof(iid));
		ret =
		    ifx_get_iid(TAG_WAN_IPV4CFG, TAG_WAN_IP, &parent_iid, &iid);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to allocate IID for ADD",
				__FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		dist_wan_index = -1;
		/* Update the allocated IID in WAN CONNECTION */
		wan_ipv4_cfg->iid.cpeId = iid.cpeId;
		wan_ipv4_cfg->iid.pcpeId = iid.pcpeId;
	}

	/* Get WAN Index in case of modify/delete operations from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wan_ipv4_cfg->iid.cpeId,
					 dist_wan_index)
	}

	wan_iid.pcpeId = wan_ipv4_cfg->iid.pcpeId;

	/* Get WANIP conn's index for sys config */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wan_iid.pcpeId, dist_wanip_index)

		/**************** Name Value Formation as per RC.CONF ********************/
	    /* Form the name-value pairs for ACL Checking & Validation */
	    if (IFX_DELETE_F_NOT_SET(flags)) {
		/* TBD: place holder to get interface name atmX for CLIP connection type */
		if (IFX_INT_ADD_F_SET(flags)) {
		} else {
		}

		ifx_fill_ArrayFvp_FName(wan_main_array_fvp, 0, 11,
					wan_ipv4_param_names);

		//ifx_fill_ArrayFvp_intValues(wan_main_array_fvp, 0, 17, (int32 *)&wan_ipv4_cfg->iid.cpeId.Id, &wan_ipv4_cfg->iid.pcpeId.Id, &wan_ipv4_cfg->WAN_CONN_ENABLE, &wan_ipv4_cfg->link_type, &wan_ipv4_cfg->WAN_CONN_AUTO_DISCONNECT_TIME, &wan_ipv4_cfg->WAN_CONN_IDLE_DISCONNECT_TIME, &wan_ipv4_cfg->WAN_CONN_NAT_ENABLED, &wan_ipv4_cfg->WAN_CONN_MAC_ADDR_OVERRIDE, &wan_ipv4_cfg->WAN_CONN_ROUTE_PROTO_RX, &wan_ipv4_cfg->wan_mode, &wan_ipv4_cfg->vlanId, &wan_ipv4_cfg->conn_type, &wan_ipv4_cfg->max_mtu, &wan_ipv4_cfg->l3_proto, &wan_ipv4_cfg->ipv6CfgTpe, &wan_ipv4_cfg->mcProxyEna, &wan_ipv4_cfg->addr_type);
		ifx_fill_ArrayFvp_intValues(wan_main_array_fvp, 0, 2,
					    (int32 *) & wan_ipv4_cfg->iid.cpeId.
					    Id, &wan_ipv4_cfg->iid.pcpeId.Id);

		sprintf(sWan_IP, "%s",
			(char8 *) inet_ntoa(wan_ipv4_cfg->WAN_CONN_IPADDR));
		sprintf(sWan_Mask, "%s",
			(char8 *) inet_ntoa(wan_ipv4_cfg->WAN_CONN_IPMASK));
		sprintf(sWan_Gw, "%s",
			(char8 *) inet_ntoa(wan_ipv4_cfg->ip_gw));

		ifx_fill_ArrayFvp_strValues(wan_main_array_fvp, 2, 3, sWan_IP,
					    sWan_Mask, sWan_Gw);
#if 1 
                inet_ntop(AF_INET6,(int8 *)&wan_ipv6_cfg->WAN_CONN_IPADDR6, (int8 *)ip6_addr, sizeof(ip6_addr));
                sprintf(wan_main_array_fvp[5].value, "%s", (int8 *)ip6_addr);

                sprintf(wan_main_array_fvp[6].value, "%d", wan_ipv6_cfg->ip6_mask.prefixlen);

                inet_ntop(AF_INET6,(int8 *)&wan_ipv6_cfg->ip6_gw, (int8 *)ip6_addr1, sizeof(ip6_addr1));
                sprintf(wan_main_array_fvp[7].value, "%s", (int8 *)ip6_addr1);

                inet_ntop(AF_INET6,(int8 *)&wan_ipv6_cfg->lan_prefix, (int8 *)ip6_addr2, sizeof(ip6_addr2));
                sprintf(wan_main_array_fvp[8].value, "%s", (int8 *)ip6_addr2);

                inet_ntop(AF_INET6,(int8 *)&wan_ipv6_cfg->ip6_dns1, (int8 *)ip6_addr3, sizeof(ip6_addr3));
                if (!gstrcmp(ip6_addr3, "::"))
                    gstrcpy(ip6_addr3, "");
                sprintf(wan_main_array_fvp[9].value, "%s", (int8 *)ip6_addr3);

                inet_ntop(AF_INET6,(int8 *)&wan_ipv6_cfg->ip6_dns2, (int8 *)ip6_addr4, sizeof(ip6_addr4));
                if (!gstrcmp(ip6_addr4, "::"))
                    gstrcpy(ip6_addr4, "");
                sprintf(wan_main_array_fvp[10].value, "%s", (int8 *)ip6_addr4);
#endif
	}
	wan_main_fvp_count = 11;

	sprintf(ipv4_wan_prefix, "%s%d", PREFIX_WAN_IPV4,
		wan_ipv4_cfg->iid.pcpeId.Id);

	/* Form the fully qualified Name Value Pairs */
	if (ifx_get_conf_index_and_nv_pairs
	    (&wan_ipv4_cfg->iid, dist_wan_index, ipv4_wan_prefix,
	     wan_main_fvp_count, wan_main_array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__,
			__LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

		/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	/* Ignore the "ifnas" and "ifType" in WAN MAIN for ACL
	 * Hence count should be (count - 2)
	 */
	CHECK_ACL_RET(wan_ipv4_cfg->iid, (wan_main_fvp_count - 2),
		      wan_main_array_fvp, wan_main_changed_fcount,
		      wan_main_changed_array_fvp, flags, IFX_Handler)

		/********* System Config File Update Block  **********/
	    /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	    memset(buf, 0x00, sizeof(buf));
	form_cfgdb_buf(buf, wan_main_fvp_count, wan_main_array_fvp);

	ret = IFX_SUCCESS;
	if (operation == IFX_OP_ADD) {
		ret =
		    ifx_SetObjData(FILE_RC_CONF, TAG_WAN_IPV4CFG, flags, 1,
				   buf);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Set Data in rc.conf Fail",
				__FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		/* Unless this is done we cant find this instance in script */
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_WAN_IPV4CFG, flags);

		/* Copy tr69id from ip connection tr69id, because the tr69id allocation will happen in ip set api */
		if (wan_ipv4_cfg->WAN_CONN_IID.config_owner == IFX_WEB) {
			STRNCPY(wan_ipv4_cfg->WAN_CONN_IID.tr69Id,
				wan_ipv4_cfg->WAN_CONN_IID.tr69Id,
				strlen(wan_ipv4_cfg->WAN_CONN_IID.tr69Id));
		}
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */
				/*********** Epilog Block **************/
		/* Manipulate nextCpeId only for ADD operations */
		//ifx_increment_wanindex(FILE_RC_CONF, TAG_WAN_INDEX, &dist_wan_index);
		UPDATE_ID_MAP_N_ATTRIBUTES(&wan_ipv4_cfg->WAN_CONN_IID,
					   wan_main_fvp_count,
					   wan_main_array_fvp, flags,
					   IFX_Handler)
		    /*CHECK_N_SEND_NOTIFICATION(wan_ipv4_cfg->WAN_CONN_IID, wan_main_fvp_count,
		       wan_main_array_fvp, flags, IFX_Handler) */
		    /* Manipulate nextCpeId only for ADD operations */
		    ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WAN_IPV4CFG);
		/* TBD: place holder to increment value of nextAtmIdx for CLIP connection type */
		{
		}
	} else if (operation == IFX_OP_MOD) {
		if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)
		    && IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) {
#ifndef HOSTENV
			/* First deactivate */
			sprintf(sCommand, "%s %d", SERVICE_WANIP_STOP,
				dist_wanip_index);
			ret = system(sCommand);
			ret = IFX_SUCCESS;

			if (ret != IFX_SUCCESS) {
				goto IFX_Handler;
			}
#endif
		}

		/* Activate with the new configuration */
		ret =
		    ifx_SetObjData(FILE_RC_CONF, TAG_WAN_IPV4CFG, flags, 1,
				   buf);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Set Data in rc.conf Fail",
				__FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

				/*********** Device Configuration Block ****************/
		/* Device config thru Scripts/Utilities or Functions */
		if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)
		    && IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) {
			/* For now we ignore all the stopped services and start
			 * services again */
			if(IFX_INT_DONT_START_SERVICES_F_NOT_SET(flags)) {
				if (IFX_DEACTIVATE_F_NOT_SET(flags)) {
					/* Just bring up this WAN interface for ADD/MODIFY-ENABLE cases */
					sprintf(sCommand, "%s %d", SERVICE_WANIP_START,
						dist_wanip_index);
					ret = system(sCommand);
					ret = IFX_SUCCESS;
				}
	
			}
		}

				/*********** Notification Block *************/
		/* Notify the Internal TR69 Stack in case of MODIFY
		 * This Notification would only be for WAN MAIN params */
		/* Notification for WAN MAIN mappings */
		CHECK_N_SEND_NOTIFICATION(wan_ipv4_cfg->iid,
					  wan_main_changed_fcount,
					  wan_main_changed_array_fvp, flags,
					  IFX_Handler)
	} else {
		if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)
		    && IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) {
#ifndef HOSTENV
			sprintf(sCommand, "%s %d", SERVICE_WANIP_STOP,
				dist_wanip_index);
			ret = system(sCommand);
			ret = IFX_SUCCESS;

			if (ret != IFX_SUCCESS) {
				/* For now we just goto the IFX_Handler and return IFX_FAILURE */
				goto IFX_Handler;
			}
#endif
		}

		/* Case of Delete - so first remove the entry from wan_ip section */
		ret =
		    ifx_SetObjData(FILE_RC_CONF, TAG_WAN_IPV4CFG, flags, 1,
				   buf);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Set Data in rc.conf Fail",
				__FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}


		/* Update the TR69 ID obtained above to reflect in the Mappings for WAN MAIN */
		STRNCPY(wan_ipv4_cfg->WAN_CONN_IID.tr69Id,
			wan_ipv4_cfg->WAN_CONN_IID.tr69Id,
			strlen(wan_ipv4_cfg->WAN_CONN_IID.tr69Id));
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_WAN_IPV4CFG, flags);
		UPDATE_ID_MAP_N_ATTRIBUTES(&wan_ipv4_cfg->WAN_CONN_IID,
					   wan_main_fvp_count,
					   wan_main_array_fvp, flags,
					   IFX_Handler)
		    /*CHECK_N_SEND_NOTIFICATION(wan_ipv4_cfg->WAN_CONN_IID, wan_main_fvp_count,
		       wan_main_array_fvp, flags, IFX_Handler) */
	}

		/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions
	 * This would have been done from the WANIP or WANPPP calls */

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Update persistent storage fail", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(ret_WANStr)
	    IFX_MEM_FREE(ret_WANConnDevStr)
	    IFX_MEM_FREE(wan_main_changed_array_fvp)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_wan_ppp_config(...)
*		operation	==> 	specifies the operation to be done such as ADD, DELETE or MODIFY
*		wan_index	==>		specifies the wan index of the wan connection to be configured
*		wan_ppp_cfg	==>		pointer to WAN_PPP_CONFIG structure which will store the ppp connection specific parameters
*       flags       ==>  	flags that define the behaviour
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
        Description:
				The api adds, deletes or modifies wan ppp connection. the api will store the wan ppp connection specific
				parameters for the wan connection specified by wan_index. if the operation is modify the api will call
  				service stop on the wan_index, modify the ppp parameters and call service start on the same wan_index.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_wan_ppp_config(int32 operation, int32 wan_index,
			     WAN_PPP_CONFIG * wan_ppp_cfg, uint32 flags)
{
	char8 wan_conn_name[MAX_CONN_NAME_LEN];
	char8 cpeIDValStr[20];
	char8 *ret_WANStr = NULL, *ret_VlanStr = NULL;
	// char8    buf_ifnas[MAX_FILELINE_LEN], ifnasStr[10];
	char8 ifpppStr[10];
	int32 dist_wan_index = -1;
	//int32    dist_nas_index = -1;
	IFX_NAME_VALUE_PAIR wan_main_array_fvp[WAN_PPP_PARAM_COUNT];
	uint32 wan_main_fvp_count = 0;
	IFX_NAME_VALUE_PAIR *wan_main_changed_array_fvp = NULL;
	uint32 wan_main_changed_fcount = 0;
	char8 buf[MAX_DATA_LEN], conf_buf[MAX_FILELINE_LEN];
	int32 ret = IFX_SUCCESS;
	int32 outFlag = IFX_F_DEFAULT;
	char8 sValue[MAX_FILELINE_LEN];
	WAN_CONN_CFG *p_wancfg = NULL;
	char8 retVal[20], sCommand[MAX_FILELINE_LEN];
	WAN_COMMON_CFG wan_comm_cfg;
	char8 sWan_IP[MAX_IP_ADDR_LEN], sWan_Mask[MAX_IP_ADDR_LEN],
	    l2IfName[MAX_IF_NAME_LEN], ifppp[MAX_IF_NAME_LEN];
        IFX_ID tempIID, iid; /*To get TR69ID for DevM*/
        int32 wcd_cpeid = 0;
	int i=1, wpppCnt = 0, wanIdx;
	char8 new_wan_conn_name[MAX_CONN_NAME_LEN];
	char_t connbuf[BUF_SIZE_50K];
	char8 dns_servers[MAX_DNS_SERVERS * MAX_IP_ADDR_LEN + MAX_DNS_SERVERS + 1];
#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
	char8 igmpoldconnName[MAX_CONN_NAME_LEN];
	int mcast_wan_flag;
#endif
	connbuf[0] = '\0';
        int32  connnum = -1;
	int wanmode=0;
	//WAN_TYPE type;

	NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
	NULL_TERMINATE(l2IfName, 0, sizeof(l2IfName));
	NULL_TERMINATE(cpeIDValStr, 0, sizeof(cpeIDValStr));
	NULL_TERMINATE(sWan_IP, 0x00, sizeof(sWan_IP));
	NULL_TERMINATE(sWan_Mask, 0x00, sizeof(sWan_Mask));
	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
	memset(&wan_main_array_fvp, 0, sizeof(wan_main_array_fvp));
	memset(&wan_comm_cfg, 0x00, sizeof(wan_comm_cfg));
	memset(dns_servers, 0, sizeof(dns_servers));

	/*************** Prolog Block *********************/
	/* Set the flags based on operation */
	if (operation == IFX_OP_DEL) {
		flags |= IFX_F_DELETE;
	} else if (operation == IFX_OP_MOD) {
		flags |= IFX_F_MODIFY;
	} else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags))) {
		flags |= IFX_F_INT_ADD;
	}

	if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* 1. Check whether the WAN_CONN_CFG is NULL, if so it's an Error!
		   Also check on valid flags condition */
		IFX_VALIDATE_PTR(wan_ppp_cfg)
		    IFX_VALIDATE_FLAGS(flags)
	}

	/*************** Prolog Block Continued *********************/
	/* Determine the WAN's parent Section from the pcpeId if it is
	 * passed or from VCC otherwise (incase of WEB/CLI configuration
	 */
	wan_comm_cfg = wan_ppp_cfg->WAN_CONN;

	#if defined(CONFIG_FEATURE_LTQ_PARAMETER_ENCRYPTION)
        ltq_encrypt_par( buf,wan_ppp_cfg->ppp_user_passwd,strlen(wan_ppp_cfg->ppp_user_passwd),NULL);
	LTQ_STRNCPY(wan_ppp_cfg->ppp_user_passwd, buf, MAX_PASSWORD_SIZE);
	#endif
	sprintf(wan_comm_cfg.iid.cpeId.secName, "%s", TAG_WAN_PPP);	//secname is for wan_ppp_config
	sprintf(wan_comm_cfg.iid.pcpeId.secName, "%s", TAG_VLAN_CHANNEL);

	//iid = wan_comm_cfg.iid;
	if (wan_comm_cfg.iid.pcpeId.Id == 0) {
		/* Get the parent info from the passed baseifname information refering to WAN_CONN */
		snprintf(l2IfName,MAX_IF_NAME_LEN, "%s", wan_ppp_cfg->wan_cfg.l2iface_name);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] l2iface [%s:%s] file [%s] sec [%s]",
			__FUNCTION__, __LINE__,
			wan_ppp_cfg->wan_cfg.l2iface_name,
			wan_comm_cfg.l2iface_name, FILE_RC_CONF,
			wan_comm_cfg.iid.pcpeId.secName);
#endif

		/* Get the base ifname from WAN Connection Device Section */
		if (ifx_ret_substr_from_distfield
		    (FILE_RC_CONF, wan_comm_cfg.iid.pcpeId.secName, "l2ifName",
		     l2IfName, &ret_VlanStr) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] \n", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		} else {
			/* Here we would have got the return string as wan_dev_x
			 * where 'x' denotes the device instance. Now get the cpeId
			 * for this instance 'x' */
			sprintf(conf_buf, "%s_%s", ret_VlanStr, "cpeId");
			if ((ifx_GetObjData
			     (FILE_RC_CONF, wan_comm_cfg.iid.pcpeId.secName,
			      conf_buf, IFX_F_GET_ANY,
			      (IFX_OUT uint32 *) & outFlag,
			      sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("[%s:%d] Unable to retrieve parent cpe Id",
				     __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			} else {
				wan_comm_cfg.iid.pcpeId.Id = atoi(sValue);
			}
		}
	}

	/* Update the Parent's cpeID and Section Name in piid
	 * This would be required only for ADD operation */
	//parent_iid.cpeId.Id = iid.pcpeId.Id;
	//sprintf(parent_iid.cpeId.secName, "%s", iid.pcpeId.secName);

	wan_ppp_cfg->WAN_CONN.iid.cpeId = wan_comm_cfg.iid.cpeId;
	wan_ppp_cfg->WAN_CONN.iid.pcpeId = wan_comm_cfg.iid.pcpeId;
	/**************** Validation Block *****************/
	/* For Operations other than DELETE perform the following validation on input params */
	if (IFX_INT_ADD_F_SET(flags)) {
		if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
			/* MANDATORY CHECK:
			 * Check if the wan_Connection Name is unique across WAN IP and PPP
			 * We assume that the wan_Connection Name must be unique across
			 * all connections ! */
			NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
			STRNCPY(conf_buf, wan_comm_cfg.WAN_CONN_NAME,
				strlen(wan_comm_cfg.WAN_CONN_NAME));

			/* Check if the wanConnName is configured, then it MUST be unique for any ADD Operation */
			if ((strcmp(conf_buf, ""))) {
				/*Check WANIP and WANPPP connection names */
				ret =
				    ifx_ret_substr_from_distfield(FILE_RC_CONF,
								  TAG_WAN_IP,
								  "connName",
								  conf_buf,
								  &ret_WANStr);
				if (ret == IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] connName = [%s] Not Unique",
					     __FUNCTION__, __LINE__,
					     ret_WANStr);
#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				} else {	
					IFX_MEM_FREE(ret_WANStr);
					ret =
					    ifx_ret_substr_from_distfield
					    (FILE_RC_CONF, TAG_WAN_PPP,
					     "connName", conf_buf, &ret_WANStr);
					if (ret == IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
						IFX_DBG
						    ("[%s:%d] connName = [%s] Not Unique",
						     __FUNCTION__, __LINE__,
						     ret_WANStr);
#endif
						ret = IFX_FAILURE;
						goto IFX_Handler;
					}
				}
			}
		}
	/**************** ID Allocation Block - Only for ADD Operation **************/
		/* Form tag of parent section and get cpeId. Allocate iid for Add */
                ret = mapi_get_wcd_from_vlan(wan_ppp_cfg->WAN_CONN.iid.pcpeId.Id, &wcd_cpeid);
		if (ret != IFX_SUCCESS)
                {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to get WCD cpe Id\n",__FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	        tempIID.cpeId = wan_ppp_cfg->WAN_CONN.iid.cpeId;
	        sprintf(tempIID.cpeId.secName, "%s", wan_ppp_cfg->WAN_CONN.iid.cpeId.secName);
	        sprintf(tempIID.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);
                tempIID.pcpeId.Id = wcd_cpeid;
                tempIID.config_owner = wan_ppp_cfg->WAN_CONN.iid.config_owner;
                strcpy(tempIID.tr69Id,wan_ppp_cfg->WAN_CONN.iid.tr69Id);
		ret = ifx_get_IID(&tempIID, "connType");
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to allocate IID for ADD",
				__FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		dist_wan_index = -1;
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s] [%d] Allocated IID [%s]!", __FUNCTION__, __LINE__, tempIID.tr69Id);
#endif
		/* Update the allocated IID in WAN CONNECTION */
		wan_comm_cfg.iid.cpeId = tempIID.cpeId;
                wan_ppp_cfg->WAN_CONN.iid.cpeId = tempIID.cpeId;
		wan_comm_cfg.iid.pcpeId = wan_ppp_cfg->WAN_CONN.iid.pcpeId;
                strcpy(wan_ppp_cfg->WAN_CONN.iid.tr69Id,tempIID.tr69Id);
                strcpy(wan_comm_cfg.iid.tr69Id,tempIID.tr69Id);
	}

	/* Get WAN Index in case of modify/delete operations from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		/* If WAN index is not specified, only then get the wan Index
		 * from cpeId, else use the wan_index passed */
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wan_comm_cfg.iid.cpeId,
					 dist_wan_index)
#if 0
	      TBD: chk if needed
			/* Populate the OLD WAN Connection config structure for MODIFY */
			old_wan_cfg.wancfg.ppp.wan_cfg.iid = wan_comm_cfg.iid;
		old_wan_cfg.type = WAN_TYPE_PPP;

		if (mapi_get_wan_config
		    (wan_index, &old_wan_cfg, IFX_F_GET_ANY) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Get IP Configuration failed",
				__FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
#endif
	}

	/**************** Name Value Formation as per RC.CONF ********************/
	/* Form the name-value pairs for ACL Checking & Validation */
	if (IFX_DELETE_F_NOT_SET(flags)) {
		/*Get interface name */
		if (IFX_INT_ADD_F_SET(flags)) {
			dist_wan_index = -1;
			ifx_get_index_from_sec_count(FILE_RC_CONF, TAG_WAN_PPP,
						     &dist_wan_index,
						     IFX_F_GET_ANY);
			sprintf(wan_conn_name, "%s%d", "WANPPP",
				dist_wan_index);
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
	/* Have single reference of connection name in future, i.e. wan_comm_cfg.WAN_CONN_NAME */ 
	if(!strlen(wan_comm_cfg.WAN_CONN_NAME)) 
		sprintf(wan_comm_cfg.WAN_CONN_NAME, "%s", wan_conn_name);
	if(!strlen(wan_comm_cfg.WAN_CONF_CONN_NAME)) 
		sprintf(wan_comm_cfg.WAN_CONF_CONN_NAME, "%s", wan_conn_name);
#endif
			sprintf(ifppp, "ppp%d", wan_comm_cfg.iid.cpeId.Id);
			memset(&newconnName , 0x00, sizeof(newconnName));
                        sprintf(newconnName, "%s", wan_conn_name);
		} else {

			NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
			NULL_TERMINATE(ifpppStr, 0x00, sizeof(ifpppStr));
			sprintf(conf_buf, "%s_%d_ifppp", PREFIX_WAN_PPP,
				dist_wan_index);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_WAN_PPP, conf_buf, IFX_F_GET_ANY,
			     (IFX_OUT uint32 *) & outFlag,
			     ifpppStr) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("[%s:%d] Modify/Delete: Get nas interface Fail",
				     __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			sprintf(ifppp, "%s", ifpppStr);
		}

/*char8 *wan_ppp_param_names[] = {"cpeId", "pcpeId", "fEnable", "linkType", "autoDiscTime", "idleDiscTime", "NATEnable", "macAddrOverride", "rxRouteProto", "wanMode", "connType", "maxMTU", "l3Proto", "ipv6CfgType", "mcProxyEna", "encrProto", "comprProto", "authProto", "maxMRU", "echoPeriod", "echoRetry", "bridgeEnable", "currMRU", "connTrigger", "connName", "conf_connName", "macAddr", "ACName", "serviceName", "user", "passwd","l2IfName" "ifppp", "iface"};
*/
		ifx_fill_ArrayFvp_FName(wan_main_array_fvp, 0, 37,
					wan_ppp_param_names);

		ifx_fill_ArrayFvp_intValues(wan_main_array_fvp, 0, 24,
					    (int32 *) & wan_comm_cfg.iid.cpeId.
					    Id, &wan_comm_cfg.iid.pcpeId.Id,
					    &wan_comm_cfg.WAN_CONN_ENABLE,
					    &wan_comm_cfg.link_type,
					    &wan_comm_cfg.
					    WAN_CONN_AUTO_DISCONNECT_TIME,
					    &wan_comm_cfg.
					    WAN_CONN_IDLE_DISCONNECT_TIME,
					    &wan_comm_cfg.WAN_CONN_NAT_ENABLED,
					    &wan_comm_cfg.
					    WAN_CONN_MAC_ADDR_OVERRIDE,
					    &wan_comm_cfg.
					    WAN_CONN_ROUTE_PROTO_RX,
					    &wan_comm_cfg.wan_mode.mode,
					    &wan_ppp_cfg->conn_type,
					    &wan_comm_cfg.max_mtu,
					    &wan_comm_cfg.l3_proto,
					    &wan_comm_cfg.ipv6CfgType,
					    &wan_comm_cfg.mcProxyEna,
					    &wan_ppp_cfg->encr_proto,
					    &wan_ppp_cfg->compr_proto,
					    &wan_ppp_cfg->auth_proto,
					    &wan_ppp_cfg->max_mru_size,
					    &wan_ppp_cfg->ppp_lcp_echo_period,
					    &wan_ppp_cfg->ppp_lcp_echo_retry,
					    &wan_ppp_cfg->bridge_enable,
					    &wan_ppp_cfg->current_mru,
					    &wan_ppp_cfg->trigger);

		wan_main_fvp_count = 24;
		ifx_fill_ArrayFvp_strValues(wan_main_array_fvp, 24, 10,
					    strcmp(wan_comm_cfg.WAN_CONN_NAME,
						   "") ? wan_comm_cfg.
					    WAN_CONN_NAME : wan_conn_name,
					    strcmp(wan_comm_cfg.
						   WAN_CONF_CONN_NAME,
						   "") ? wan_comm_cfg.
					    WAN_CONF_CONN_NAME : wan_conn_name,
					    strlen(wan_comm_cfg.
						   WAN_CONN_MAC_ADDR) ?
					    wan_comm_cfg.WAN_CONN_MAC_ADDR : "",
					    &wan_comm_cfg.l2iface_name,
					    (strlen(wan_ppp_cfg->pppoe_ac_name))
					    ? wan_ppp_cfg->pppoe_ac_name : "",
					    (strlen
					     (wan_ppp_cfg->
					      pppoe_service_name)) ?
					    wan_ppp_cfg->
					    pppoe_service_name : "",
					    wan_ppp_cfg->ppp_user_name,
					    wan_ppp_cfg->ppp_user_passwd,
					    &wan_comm_cfg.l2iface_name, ifppp);

		wan_main_fvp_count = 34;

#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT 
	sprintf(wan_main_array_fvp[wan_main_fvp_count++].value, "%d", wan_comm_cfg.autodetect);
	//	ifx_fill_ArrayFvp_intValues(wan_main_array_fvp, wan_main_fvp_count++, 1, &wan_comm_cfg.autodetect);
#endif

		for(i=0; i<MAX_DNS_SERVERS; i++)
		{
			if(strlen(inet_ntoa(wan_comm_cfg.wandns.dns_servers[i])) && strcmp(inet_ntoa(wan_comm_cfg.wandns.dns_servers[i]), "0.0.0.0")) {
				strcat(dns_servers, inet_ntoa(wan_comm_cfg.wandns.dns_servers[i]));
				strcat(dns_servers, ",");
			}
		}
		dns_servers[strlen(dns_servers) - 1] = '\0';

		if(IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
			if(wan_comm_cfg.wandns.WAN_CONN_DNS_OVERRIDE == 0 && strlen(dns_servers) == 0) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] DNS override is set to FALSE and DNS server values not provided. WAN IP configuration failed.",
									__FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}

		sprintf(wan_main_array_fvp[wan_main_fvp_count++].value, "%d", wan_comm_cfg.wandns.WAN_CONN_DNS_OVERRIDE);
		sprintf(wan_main_array_fvp[wan_main_fvp_count++].value, "%s", dns_servers);

		ifx_fill_ArrayFvp_intValues(wan_main_array_fvp, wan_main_fvp_count, 9,
					    &wan_comm_cfg.ipv4,
					    &wan_comm_cfg.ipv6,
					    &wan_comm_cfg.dhcp_mode,
					    &wan_comm_cfg.iana,
					    &wan_comm_cfg.iapd,
					    &wan_comm_cfg.slaid,
					    &wan_comm_cfg.rapid,
       					    &wan_comm_cfg.tunnel,
	                                    &wan_comm_cfg.duid_t);

		sprintf(wan_main_array_fvp[wan_main_fvp_count++].fieldname, "%s", "ipv4");
		sprintf(wan_main_array_fvp[wan_main_fvp_count++].fieldname, "%s", "ipv6");
		sprintf(wan_main_array_fvp[wan_main_fvp_count++].fieldname, "%s", "dhcpv6State");
		sprintf(wan_main_array_fvp[wan_main_fvp_count++].fieldname, "%s", "ianaID");
		sprintf(wan_main_array_fvp[wan_main_fvp_count++].fieldname, "%s", "iapdID");
		sprintf(wan_main_array_fvp[wan_main_fvp_count++].fieldname, "%s", "slaID");
		sprintf(wan_main_array_fvp[wan_main_fvp_count++].fieldname, "%s", "rapid");
		sprintf(wan_main_array_fvp[wan_main_fvp_count++].fieldname, "%s", "tunnel");
		sprintf(wan_main_array_fvp[wan_main_fvp_count++].fieldname, "%s", "duidt");
	}
	else {
		wan_main_fvp_count = WAN_PPP_PARAM_COUNT;
	}

	/* Form the fully qualified Name Value Pairs */
	if (ifx_get_conf_index_and_nv_pairs
	    (&wan_comm_cfg.iid, dist_wan_index, PREFIX_WAN_PPP,
	     wan_main_fvp_count, wan_main_array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__,
			__LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	/* Ignore the "ifnas" and "ifType" in WAN MAIN for ACL
	 * Hence count should be (count - 2)
	 */
	if (IFX_INT_ADD_F_SET(flags))
        {
	    CHECK_ACL_RET(tempIID, (wan_main_fvp_count - 2),
		      wan_main_array_fvp, wan_main_changed_fcount,
		      wan_main_changed_array_fvp, flags, IFX_Handler)
        }
        else
        {
	    CHECK_ACL_RET(wan_comm_cfg.iid, (wan_main_fvp_count - 2),
		      wan_main_array_fvp, wan_main_changed_fcount,
		      wan_main_changed_array_fvp, flags, IFX_Handler)
        }

	/********* System Config File Update Block  **********/
	    /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	    memset(buf, 0x00, sizeof(buf));
	form_cfgdb_buf(buf, wan_main_fvp_count, wan_main_array_fvp);

	ret = IFX_SUCCESS;
	if (operation == IFX_OP_ADD) {
		ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_PPP, flags, 1, buf);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Set Data in rc.conf Fail",
				__FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		ifx_CompactCfgSection(FILE_RC_CONF, TAG_WAN_PPP, flags);
		/*********** Device Configuration Block ****************/
		/* Device config thru Scripts/Utilities or Functions */
		if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)
		    && IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) {
			/* For now we ignore all the stopped services and start
			 * services again */

			/* Irrespective of the operation, retrieve index from rc.conf */
			IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF,
						 wan_comm_cfg.iid.cpeId,
						 dist_wan_index)

			if(IFX_INT_DONT_START_SERVICES_F_NOT_SET(flags)) {
			    if (IFX_DEACTIVATE_F_NOT_SET(flags)) {
					/* Just bring up this WAN interface for ADD/MODIFY-ENABLE cases */
					sprintf(sCommand, "%s %d", SERVICE_WANPPP_START,
						dist_wan_index);
					ret = system(sCommand);
					ret = IFX_SUCCESS;
				}
	

			}
		}

		/*Copy tr69id field from ip connection tr69id, because the tr69id allocation will happen in ip set api */
		if (wan_comm_cfg.iid.config_owner == IFX_WEB) {
			STRNCPY(wan_comm_cfg.WAN_CONN_IID.tr69Id,
				wan_ppp_cfg->WAN_CONN.WAN_CONN_IID.tr69Id,
				strlen(wan_ppp_cfg->WAN_CONN.WAN_CONN_IID.
				       tr69Id));
		}
		/* Manipulate nextCpeId only for ADD operations */
		//ifx_increment_wanindex(FILE_RC_CONF, TAG_WAN_INDEX, &nasIdx);
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WAN_PPP);
		ifx_increment_idx_value(FILE_RC_CONF, "index_sec", "subnasIdx");

		/*********** Epilog Block **************/
/* Don't handle TR-069 yet */
#if 1
		//UPDATE_ID_MAP_N_ATTRIBUTES(&wan_comm_cfg.iid,
		UPDATE_ID_MAP_N_ATTRIBUTES(&tempIID,
					   wan_main_fvp_count,
					   wan_main_array_fvp, flags,
					   IFX_Handler)
	        CHECK_N_SEND_NOTIFICATION(tempIID,
					      wan_main_fvp_count,
					      wan_main_array_fvp, flags,
					      IFX_Handler)
#endif
	} else if (operation == IFX_OP_MOD) {
		if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)
		    && IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) {
			/* First deactivate */
			sprintf(sCommand, "%s %d", SERVICE_WANPPP_STOP,
				dist_wan_index);
			ret = system(sCommand);
			ret = IFX_SUCCESS;

			if (ret != IFX_SUCCESS) {
				goto IFX_Handler;
			}
		}

		/* Activate with the new configuration */
		ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_PPP, flags, 1, buf);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Set Data in rc.conf Fail",
				__FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		/*********** Device Configuration Block ****************/
		/* Device config thru Scripts/Utilities or Functions */
		if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)
		    && IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) {
			/* For now we ignore all the stopped services and start
			 * services again */

			/* Irrespective of the operation, retrieve index from rc.conf */
			IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF,
						 wan_ppp_cfg->WAN_CONN.iid.
						 cpeId, dist_wan_index)

			if(IFX_INT_DONT_START_SERVICES_F_NOT_SET(flags)) {
			    if (IFX_DEACTIVATE_F_NOT_SET(flags)) {
				/* Just bring up this WAN interface for ADD/MODIFY-ENABLE cases */
				sprintf(sCommand, "%s %d", SERVICE_WANPPP_START,
					dist_wan_index);
				ret = system(sCommand);
				ret = IFX_SUCCESS;
				}
	
			}

		}

		/*********** Notification Block *************/
		/* Notify the Internal TR69 Stack in case of MODIFY
		 * This Notification would only be for WAN MAIN params */
		/* Notification for WAN MAIN mappings */
/* Don't handle TR-069 yet */
#if 1
		CHECK_N_SEND_NOTIFICATION(wan_comm_cfg.iid,
					  wan_main_changed_fcount,
					  wan_main_changed_array_fvp, flags,
					  IFX_Handler)
#endif
	} else {
		if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)
		    && IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) {
			sprintf(sCommand, "%s %d", SERVICE_WANPPP_STOP,
				dist_wan_index);
			ret = system(sCommand);
			ret = IFX_SUCCESS;

			if (ret != IFX_SUCCESS) {
				/* For now we just goto the IFX_Handler and return IFX_FAILURE */
				goto IFX_Handler;
			}
		}

		/* Case of Delete - so first remove the entry from wan_ip section */
		ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_PPP, flags, 1, buf);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Set Data in rc.conf Fail",
				__FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		
                if (ifx_get_sec_count(TAG_WAN_PPP, &wpppCnt) != IFX_SUCCESS) {

        	} 
	

		/*Stop all wan services before compaction*/	
		for (i = 0; i < wpppCnt; i++) 
		{
			#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] ^^^^^^^^^^SERVICE_WANPPP_STOP^^^^^^^^",__FUNCTION__, __LINE__ );
			#endif
                                sprintf(sCommand, "%s %d", SERVICE_WANPPP_STOP,i);
                                system(sCommand);
		}
		 
		/* Update the TR69 ID obtained above to reflect in the Mappings for WAN MAIN */
		//STRNCPY(wan_ppp_cfg->WAN_CONN.WAN_CONN_IID.tr69Id, wan_comm_cfg.WAN_CONN_IID.tr69Id, strlen(wan_comm_cfg.WAN_CONN_IID.tr69Id));
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_WAN_PPP, flags);
		//rearrange wan connection names
                if (ifx_get_all_wan_config(&wpppCnt, WAN_TYPE_PPP, &p_wancfg, IFX_F_DEFAULT)) {

                }
                for (i = 0; i < wpppCnt; i++) {

			/*Restart WAN IP service on each wan connection after compaction*/
			#ifdef IFX_LOG_DEBUG
                        	IFX_DBG("[%s:%d] ^^^^^^^^^^SERVICE_WANPPP_START^^^^^^^^",__FUNCTION__, __LINE__ );
			#endif
                        sprintf(sCommand, "%s %d", SERVICE_WANPPP_START,i);
                        system(sCommand);

			/*Get wan connection details from wan connection name*/
                        sprintf(new_wan_conn_name, "%s",(p_wancfg + i)->wancfg.ppp.wan_cfg.conn_name);
			//GET_WAN_DETAILS_FROM_CONN_NAME(new_wan_conn_name, type, connnum, buf);
			GET_WAN_IDX_FROM_CONN_NAME(new_wan_conn_name, connnum)
			
			/*if wan connection numbers dont allign update the section */
			if( (connnum != i) && (connnum != -1) ) {
			
			/*Delete the virtual server related to old conn name */
			#ifdef CONFIG_FEATURE_NAPT
                                ret = mapi_delete_old_virtualserver(new_wan_conn_name, "realign");
                                if (ret != IFX_SUCCESS) {
				#ifdef IFX_LOG_DEBUG
                                IFX_DBG("[%s:%d] unable to delete virtual server ",__FUNCTION__, __LINE__);
				#endif
                                }
			#endif
#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
				if(mapi_pwb_delentry_on_wanchange(new_wan_conn_name, &mapi_pwb) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                                	IFX_DBG("delete pwb entry failed in function [%s] line [%d]  !!", __FUNCTION__, __LINE__);
#endif
                                }
#endif

				sprintf(connbuf,"wanppp_%d_connName=\"WANPPP%d\"\n",i,i);
                                if(ifx_SetObjData(FILE_RC_CONF, TAG_WAN_PPP, IFX_F_MODIFY, 1, connbuf) != IFX_SUCCESS) {
                                }
				/*realign default wan fused section*/
				sprintf(conf_buf, "wanppp_%d_wanMode",i);
				if ((ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP,conf_buf, IFX_F_GET_ANY,(IFX_OUT uint32 *) & outFlag,sValue)) != IFX_SUCCESS) 							{
					#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] fetch wan mode value failed",
					     __FUNCTION__, __LINE__);
					#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}else{
					wanmode = atoi(sValue);
					sprintf(conf_buf,"default_wan_%d_conn_iface", wanmode);
	                		if ((ifx_GetObjData(FILE_RC_CONF,TAG_DEF_WAN_FUSED,conf_buf, IFX_F_GET_ANY,(IFX_OUT uint32 *) & outFlag,sValue)) != IFX_SUCCESS) 						{
						#ifdef IFX_LOG_DEBUG
			                        IFX_DBG("[%s:%d] ERROR ERROR fetch default wan fused iface value",__FUNCTION__, __LINE__);
						#endif
                                		ret = IFX_FAILURE;
                                		goto IFX_Handler;
                        		}
					else{
						sprintf(ifppp,"%s",sValue);
						sprintf(conf_buf,"wanppp_%d_ifppp", i); //in case of wanppp iface in TAG_DEF_WAN_FUSED section is ifppp%d 
                                        	if ((ifx_GetObjData(FILE_RC_CONF,TAG_WAN_PPP,conf_buf, IFX_F_GET_ANY,(IFX_OUT uint32 *) & outFlag,sValue)) != IFX_SUCCESS)                                                	{
                                                	#ifdef IFX_LOG_DEBUG
	                                                IFX_DBG("[%s:%d] ERROR ERROR fetch default wan fused iface value",__FUNCTION__, __LINE__);
        	                                        #endif
                	                                ret = IFX_FAILURE;
                        	                        goto IFX_Handler;
                                	        }
						if(!strncmp(ifppp,sValue,strlen(sValue))){
							sprintf(connbuf,"default_wan_%d_conn_connName=\"WANPPP%d\"\n",wanmode,i);
		                                	if(ifx_SetObjData(FILE_RC_CONF, TAG_DEF_WAN_FUSED, IFX_F_MODIFY, 1, connbuf) != IFX_SUCCESS) {
                		                	}
						}
					}
				}
				/*reallign default fused END**/

			#ifdef CONFIG_FEATURE_NAPT

				memset(&newconnName , 0x00, sizeof(newconnName));
	                        sprintf(newconnName, "WANPPP%d",i);
			
#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
				memset(&igmpoldconnName , 0x00, sizeof(igmpoldconnName));
				strcpy(igmpoldconnName,newconnName);
#endif
#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
	                        sprintf(newconnName, "WANPPP%d",i);
      		          	if(mapi_pwb_modentry_on_wanchange(newconnName, mapi_pwb) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                        		IFX_DBG("function [%s] line [%d]  !!", __FUNCTION__, __LINE__);
#endif
                		}               
#endif

			/*Update virtual server with new wan conn name(use stored structure values */
                                ret = Update_virtual_server_config(newconnName,"realign");
                                if (ret != 0)
                                {
                                                IFX_DBG("   Update virtual server failed .....  in func [%s] line [%d]  !!", __FUNCTION__, __LINE__);
                                }
			#endif
			

#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
				mcast_wan_flag = Update_mcast_wan_flag(0,0);
				if ( mcast_wan_flag == 0 )
	                                ret = Update_igmp_config(igmpoldconnName,NULL,1);
                                if (ret != 0)
                                {
                                                IFX_DBG("   Update igmp failed .....  in func [%s] line [%d]  !!", __FUNCTION__, __LINE__);
                                }
#endif

				/*Update default wan connection with revised wan connection name */	
				if (ifx_get_default_wan_if(&iid, &wanIdx, sValue, IFX_F_DEFAULT) != IFX_SUCCESS) 
				{
                		
				}
				#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d: %s ]", __FUNCTION__, __LINE__,new_wan_conn_name);
				#endif			
				 if(!strcmp(new_wan_conn_name ,sValue ))
                                {
                        		ret =   ifx_set_default_wan_if(&(p_wancfg + i)->wancfg.ppp.wan_cfg.iid, WAN_TYPE_PPP, IFX_F_MODIFY);
				}
			}

                }
                //rearrange wan connection names: end

/* Don't handle TR-069 yet */
#if 1
		CHECK_N_SEND_NOTIFICATION(wan_comm_cfg.iid, wan_main_fvp_count,
					  wan_main_array_fvp, flags,
					  IFX_Handler)
		    UPDATE_ID_MAP_N_ATTRIBUTES(&wan_comm_cfg.iid,
					       wan_main_fvp_count,
					       wan_main_array_fvp, flags,
					       IFX_Handler)
#endif
	}

#if 0
	/* Update the LinkType in VCChannel Section if config owner is WEB
	 * In case of WEB, we will be creating the VCC before creation of WAN
	 * Connection. So we wouldn't be knowing the LinkType of the VCC. This
	 * will be known only from the WAN IP or WAN PPP Connections */

	if ((IFX_DELETE_F_NOT_SET(flags))
	    && (wan_ppp_cfg->wan_cfg.iid.config_owner == IFX_WEB)) {
		if ((ret =
		     ifx_set_channel_link_type(wan_ppp_cfg->wan_cfg.iface_name,
					       wan_comm_cfg.link_type,
					       IFX_F_MODIFY)) != IFX_SUCCESS) {
			/* Here we need to put in ACL & Notification inside this function
			 * But if ACL prevents this modfication - how to revert back ??
			 */
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Update Link Type Fail", __FUNCTION__,
				__LINE__);
#endif
			goto IFX_Handler;
		}
	}
#endif				// 0

	/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY
	 * This Notification would only be for WAN MAIN params */

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Update persistent storage fail", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(ret_WANStr)
	IFX_MEM_FREE(ret_VlanStr)
	IFX_MEM_FREE(wan_main_changed_array_fvp)
	IFX_MEM_FREE(p_wancfg);
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;

}

/*Temporarily added*/
/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_wan_ip_config_Without_TR69 (...)
*		operation	==> 	specifies the operation to be done such as ADD, DELETE or MODIFY
*		wan_index	==>		specifies the wan index of the wan connection to be configured
*		wan_ip_cfg	==>		pointer to WAN_IP_CONFIG structure which will store the ip connection specific parameters
*       flags       ==>  	flags that define the behaviour
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
        Description:
				This API is the same as ifx_set_wan_ip_config. Except that the TR69 related operations have been
  				left Out.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_wan_ip_config_Without_TR69(int32 operation, int32 wan_index,
					 WAN_IP_CONFIG * wan_ip_cfg,
					 uint32 flags)
{
	char8 buf[MAX_DATA_LEN];
	char8 linkTypeStr[30];
	char8 conf_buf[MAX_FILELINE_LEN];
	char8 ifatmStr[10];
	int32 ret = IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR wan_ip_array_fvp[9];
	uint32 wan_ip_fvp_count = 0;
	IFX_NAME_VALUE_PAIR *wanip_changed_array_fvp = NULL;
	//uint32 wanip_changed_fvp_count = 0;
	uint32 outFlag = IFX_F_DEFAULT;
	int32 dist_atm_index = -1;
	char8 sCommand[MAX_FILELINE_LEN];

	WAN_COMMON_CFG wan_comm_cfg;
	NULL_TERMINATE(linkTypeStr, 0, sizeof(linkTypeStr));
	NULL_TERMINATE(buf, 0, sizeof(buf));
	NULL_TERMINATE(sCommand, 0, sizeof(sCommand));
	memset(wan_ip_array_fvp, 0, sizeof(wan_ip_array_fvp));
	memset(&wan_comm_cfg, 0x00, sizeof(wan_comm_cfg));

	wan_comm_cfg = wan_ip_cfg->WAN_CONN;
#if 0				// TBD: No validation as of now */
	/* Validate the ipAddrType against the ipAddress, ipMask and ipGateway fields
	 * These fields are settable only if AddrType is STATIC
	 */
	if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		if (IFX_DELETE_F_NOT_SET(flags)) {
			if (wan_ip_cfg->addr_type != IP_TYPE_STATIC) {
				/* Check the values of IP Address, Mask and Gateway
				 * If these fields are non-zero then it's an Error!
				 */
				if ((wan_ip_cfg->WAN_CONN.WAN_CONN_IPADDR.
				     s_addr != INADDR_ANY)
				    || (wan_ip_cfg->WAN_CONN.WAN_CONN_IPMASK.
					s_addr != INADDR_ANY)
				    || (wan_ip_cfg->ip_gw.s_addr !=
					INADDR_ANY)) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] Validate IP address Fail",
					     __FUNCTION__, __LINE__);
#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}
			}
		}
	}
#endif				// 0

	/* IID Allocation Block */
	if (IFX_INT_ADD_F_SET(flags)) {
		/* Get the IID values from WAN_CONN_CFG - where the parent section
		 * would be that of WAN_MAIN and cpeID that of WAN_MAIN
		 * This is a deviation from other devices */

		/* The index used for WAN_IP Section is also derived from
		 * WAN_MAIN Section */
		/* Alloc TR69 ID for this instance of WAN IP Connection */
		//IFX_ALLOC_TR69ID(wan_ip_cfg->WAN_CONN.WAN_CONN_IID, "addrType", IFX_Handler);
	}

	/* Determine the linkType of this connection */
	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
	NULL_TERMINATE(linkTypeStr, 0x00, sizeof(linkTypeStr));
	MAKE_SECTION_ELEMENT_TAG(PREFIX_WAN_MAIN, wan_index, "linkType",
				 conf_buf);
	if (ifx_GetObjData
	    (FILE_RC_CONF, TAG_WAN_MAIN, conf_buf, IFX_F_GET_ANY, &outFlag,
	     linkTypeStr) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Get link Type of the connection Fail",
			__FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* The following fields will be used only for book keeping */
	/* For linkType CLIP, determine the operation is ADD/DELETE/MODIFY
	 * For ADD operation get a new atm interface index. For DELETE/MODIFY
	 * operations, get the already existing atm interface index */
	if (atoi(linkTypeStr) == LINK_TYPE_CLIP) {
		if (IFX_INT_ADD_F_SET(flags)) {
			if (ifx_get_available_distinct_index
			    (FILE_RC_CONF, TAG_WAN_IP, "atmIdx",
			     (MIN_WAN_INDEX - 1), MAX_WAN_INDEX,
			     &dist_atm_index) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("[%s:%d] ADD: Get available atm index fail",
				     __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		} else {
			/* For Modify/Delete operations get the "atm" index from rc.conf     */
			NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
			NULL_TERMINATE(ifatmStr, 0x00, sizeof(ifatmStr));
			MAKE_SECTION_ELEMENT_TAG(PREFIX_WAN_IP, wan_index,
						 "ifatm", conf_buf);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_WAN_IP, conf_buf, IFX_F_GET_ANY,
			     &outFlag, ifatmStr) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("[%s:%d] MODIFY/DELETE: Get atm index from rc.conf Fail",
				     __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			char8 tmpbuf[10];
			sscanf(ifatmStr, "%03s%d", tmpbuf, &dist_atm_index);
		}
	}

	/* Form the name-value pairs for ACL Checking & Validation */
	if (IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(wan_ip_array_fvp, 0, 8,
					wan_ip_param_names);

		if (!wan_comm_cfg.max_mtu)
			wan_comm_cfg.max_mtu = DEFAULT_MAX_MTU;

		ifx_fill_ArrayFvp_intValues(wan_ip_array_fvp, 0, 6,
					    (int32 *) & wan_ip_cfg->WAN_CONN.
					    WAN_CONN_IID.cpeId.Id,
					    &wan_ip_cfg->WAN_CONN.WAN_CONN_IID.
					    pcpeId.Id, &wan_ip_cfg->conn_status,
					    &wan_ip_cfg->conn_type,
					    &wan_ip_cfg->addr_type,
					    &wan_comm_cfg.max_mtu);

//              sprintf(wan_ip_array_fvp[6].value, "%s", inet_ntoa(wan_ip_cfg->ip_gw));

		if (atoi(linkTypeStr) == LINK_TYPE_CLIP) {
			sprintf(wan_ip_array_fvp[6].value, "%s%d", "atm",
				dist_atm_index);
		} else {
			sprintf(wan_ip_array_fvp[6].value, "%s", "");
		}
	}

	wan_ip_fvp_count = 7;
	/* Form the fully qualified Name Value Pairs */
	if (ifx_get_conf_index_and_nv_pairs
	    (&wan_ip_cfg->WAN_CONN.WAN_CONN_IID, wan_index, PREFIX_WAN_IP,
	     wan_ip_fvp_count, wan_ip_array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Form Name Value Pairs buffer Fail",
			__FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	/* Ignore the "ifatm" in WAN IP for ACL
	 * Hence count should be (count - 1)
	 */
#if 0
	CHECK_ACL_RET(wan_ip_cfg->WAN_CONN.WAN_CONN_IID, (wan_ip_fvp_count - 1),
		      wan_ip_array_fvp, wanip_changed_fvp_count,
		      wanip_changed_array_fvp, flags, IFX_Handler)
#endif
	/********* System Config File Update Block  **********/
	    /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	    NULL_TERMINATE(buf, 0x00, sizeof(buf));
	form_cfgdb_buf(buf, wan_ip_fvp_count, wan_ip_array_fvp);

	/* For MODIFY/DELETE operations, first we need to stop the running configuration
	 * with the CheckPointed file in WAN MAIN.
	 * Restore the CHECKPOINTED FILE in WAN MAIN to RC.CONF in order to stop service
	 */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)
	    || IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) {
		if (IFX_INT_ADD_F_NOT_SET(flags)) {
			/* Case of MODIFY & DELETE */
			/* Stop the Sevice with Checkpointed file in WAN MAIN */
			/* First get the CheckPointed file to rc.conf */
#ifdef NOT_REQUIRED_FOR_ZERO_DOT_FIVE
			ifx_config_write(CHKPOINT_FILE, IFX_F_DEFAULT);
#endif

			sprintf(sCommand, "%s %d", SERVICE_WANIP_STOP,
				wan_index);
			ret = system(sCommand);
			ret = IFX_SUCCESS;
		}
		if (ret != IFX_SUCCESS) {
			/* ??? What do we need to do if some services Stopped while others
			 * are still running ? Do we need to start the services again
			 * with the Check-Pointed file ?
			 * ??? */
			/* For now we just goto the IFX_Handler and return IFX_FAILURE */
			goto IFX_Handler;
		}
	}

	/* Here there is no Backup of rc.conf required as we have done backup at WAN MAIN
	 * Directly call SetCfgData function to update the system cofiguration in rc.conf */
	ret = IFX_SUCCESS;
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_IP, flags, 1, buf);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Set Data in rc.conf Fail", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}

	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)
	    || IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) {
		/* We need to invoke the scripts to bringup WAN interface.
		 * ??? What do we need to do if some services Started while others
		 * are stopped ? Do we need to stop the services again
		 * with the Check-Pointed file ?
		 * ??? */

		/* For now we ignore all the stopped services and start
		 * services again */
		if(IFX_INT_DONT_START_SERVICES_F_NOT_SET(flags)) {
			if (IFX_DELETE_F_NOT_SET(flags)
			    && (IFX_DEACTIVATE_F_NOT_SET(flags))) {
				/* Just bring up this WAN interface for ADD/MODIFY-ENABLE cases */
				sprintf(sCommand, "%s %d", SERVICE_WANIP_START,
					wan_index);
				ret = system(sCommand);
				ret = IFX_SUCCESS;
			}
	
		}

	}

	/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if (IFX_MODIFY_F_SET(flags)) {
#if 0
		CHECK_N_SEND_NOTIFICATION(wan_ip_cfg->WAN_CONN.WAN_CONN_IID,
					  wanip_changed_fvp_count,
					  wanip_changed_array_fvp, flags,
					  IFX_Handler)
#endif
	} else if (IFX_INT_ADD_F_SET(flags)) {
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */
		/*********** Epilog Block **************/
#if 0
		UPDATE_ID_MAP_N_ATTRIBUTES(&wan_ip_cfg->WAN_CONN.WAN_CONN_IID,
					   wan_ip_fvp_count, wan_ip_array_fvp,
					   flags, IFX_Handler)

		    CHECK_N_SEND_NOTIFICATION(wan_ip_cfg->WAN_CONN.WAN_CONN_IID,
					      wan_ip_fvp_count,
					      wan_ip_array_fvp, flags,
					      IFX_Handler)
#endif
		    /* Update the "atm" Index in WAN_IP Section */
		    if (atoi(linkTypeStr) == LINK_TYPE_CLIP) {
			if (ifx_manipulate_wan_indexs
			    (FILE_RC_CONF, TAG_WAN_IP, "wan_ip_atmIdx",
			     dist_atm_index, IFX_F_INT_ADD) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Manipulate wan indices Fail",
					__FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
	} else if (IFX_DELETE_F_SET(flags)) {
		/* In case of DELETE operation, first send the notificatioupdate the ID Mappings
		 * and then send the Notification for the attributes
		 */
		/*********** Epilog Block **************/
#if 0
		CHECK_N_SEND_NOTIFICATION(wan_ip_cfg->WAN_CONN.WAN_CONN_IID,
					  wan_ip_fvp_count, wan_ip_array_fvp,
					  flags, IFX_Handler)
		    UPDATE_ID_MAP_N_ATTRIBUTES(&wan_ip_cfg->WAN_CONN.
					       WAN_CONN_IID, wan_ip_fvp_count,
					       wan_ip_array_fvp, flags,
					       IFX_Handler)
#endif
		    /* Delete the "atm" Index in WAN_IP Section if linkType
		     * is CLIP */
		    if (atoi(linkTypeStr) == LINK_TYPE_CLIP) {
			if (ifx_manipulate_wan_indexs
			    (FILE_RC_CONF, TAG_WAN_IP, "wan_ip_atmIdx",
			     dist_atm_index, IFX_F_DELETE) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Manipulate wan indices Fail",
					__FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
	}

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Updating Persistent Storage Fail",
			__FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(wanip_changed_array_fvp)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return IFX_FAILURE;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_wan_ppp_configi_Without_TR69(...)
*		operation	==> 	specifies the operation to be done such as ADD, DELETE or MODIFY
*		wan_index	==>		specifies the wan index of the wan connection to be configured
*		wan_ppp_cfg	==>		pointer to WAN_PPP_CONFIG structure which will store the ppp connection specific parameters
*       flags       ==>  	flags that define the behaviour
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
        Description:
                This API is the same as ifx_set_wan_ppp_config. Except that the TR69 related operations have been
                  left Out.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_wan_ppp_config_Without_TR69(int32 operation, int32 wan_index,
					  WAN_PPP_CONFIG * wan_ppp_cfg,
					  uint32 flags)
{
	char8 buf[MAX_DATA_LEN];
	char8 conf_buf[MAX_FILELINE_LEN];
	char8 linkTypeStr[10];
	char8 ifpppStr[10];
	int32 ret = IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR wan_ppp_array_fvp[17];
	uint32 wan_ppp_fvp_count = 0;
	IFX_NAME_VALUE_PAIR *wan_ppp_changed_array_fvp = NULL;
//      uint32 wan_ppp_changed_fvp_count = 0;
	uint32 outFlag = IFX_F_DEFAULT;
	int32 dist_ppp_index = -1;
	char8 sCommand[MAX_FILELINE_LEN];

	NULL_TERMINATE(linkTypeStr, 0, sizeof(linkTypeStr));
	NULL_TERMINATE(sCommand, 0, sizeof(sCommand));

	memset(wan_ppp_array_fvp, 0, sizeof(wan_ppp_array_fvp));

	/* Any Validation identified as required needs to go in here */
	if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		if (IFX_DELETE_F_NOT_SET(flags)) {
			/* PPP UserName cannot be NULL */
			if (strlen(wan_ppp_cfg->ppp_user_name) == 0) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] PPP Username NULL",
					__FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
	}

	/* IID Allocation Block */
	if (IFX_INT_ADD_F_SET(flags)) {
		/* Get the IID values from WAN_CONN_CFG - where the parent section
		 * would be that of WAN_MAIN and cpeID that of WAN_MAIN
		 * This is a deviation from other devices */

		/* The index used for WAN_PPP Section is also derived from
		 * WAN_MAIN Section */
		/* Alloc TR69 ID for this instance of WAN PPP Connection */
		//IFX_ALLOC_TR69ID(wan_ppp_cfg->WAN_CONN.WAN_CONN_IID, "encrProto", IFX_Handler);
	}

	/* Determine the linkType of this connection */
	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
	NULL_TERMINATE(linkTypeStr, 0x00, sizeof(linkTypeStr));
	MAKE_SECTION_ELEMENT_TAG(PREFIX_WAN_MAIN, wan_index, "linkType",
				 conf_buf);
	if (ifx_GetObjData
	    (FILE_RC_CONF, TAG_WAN_MAIN, conf_buf, IFX_F_GET_ANY, &outFlag,
	     linkTypeStr) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("In [%s] : Unable to determine the LinkType for this Connection for [%d] (query [%s] in [%s] !!\n",
		     __FUNCTION__, wan_index, conf_buf, FILE_RC_CONF);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* The following fields will be used only for book keeping */
	/* Determine the ppp index to be used with operation */
	if (IFX_INT_ADD_F_SET(flags)) {
		if (ifx_get_available_distinct_index
		    (FILE_RC_CONF, TAG_WAN_PPP, "pppIdx", (MIN_WAN_INDEX - 1),
		     MAX_WAN_INDEX, &dist_ppp_index) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("Unable to determine the PPP index\n");
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	} else {
		/* For Modify/Delete operations get the "ppp" index from rc.conf     */
		NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
		NULL_TERMINATE(ifpppStr, 0x00, sizeof(ifpppStr));
		MAKE_SECTION_ELEMENT_TAG(PREFIX_WAN_PPP, wan_index, "ifppp",
					 conf_buf);
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_WAN_PPP, conf_buf, IFX_F_GET_ANY,
		     &outFlag, ifpppStr) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Get ppp index from rc.conf fail",
				__FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		char8 tmpbuf[10];
		sscanf(ifpppStr, "%03s%d", tmpbuf, &dist_ppp_index);
	}

	/* Form the name-value pairs for ACL Checking & Validation */
	if (IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(wan_ppp_array_fvp, 0, 16,
					wan_ppp_param_names);

		/* PPP Encryption, Compression, Authentication Protocols */
		/* LCP Echo intervals */
		/* PPPoE Access Concentrator, Service Name Configuration */

		ifx_fill_ArrayFvp_intValues(wan_ppp_array_fvp, 0, 11,
					    (int32 *) & wan_ppp_cfg->WAN_CONN.
					    WAN_CONN_IID.cpeId.Id,
					    &wan_ppp_cfg->WAN_CONN.WAN_CONN_IID.
					    pcpeId.Id, &wan_ppp_cfg->conn_type,
					    &wan_ppp_cfg->encr_proto,
					    &wan_ppp_cfg->compr_proto,
					    &wan_ppp_cfg->auth_proto,
					    &wan_ppp_cfg->max_mru_size,
					    &wan_ppp_cfg->ppp_lcp_echo_period,
					    &wan_ppp_cfg->ppp_lcp_echo_retry,
					    &wan_ppp_cfg->wan_cfg.max_mtu,
					    &wan_ppp_cfg->bridge_enable);

		/* PPP Username & Password */
		ifx_fill_ArrayFvp_strValues(wan_ppp_array_fvp, 11, 4,
					    (strlen(wan_ppp_cfg->pppoe_ac_name))
					    ? wan_ppp_cfg->pppoe_ac_name : "",
					    (strlen
					     (wan_ppp_cfg->
					      pppoe_service_name)) ?
					    wan_ppp_cfg->
					    pppoe_service_name : "",
					    wan_ppp_cfg->ppp_user_name,
					    wan_ppp_cfg->ppp_user_passwd);

		sprintf(wan_ppp_array_fvp[15].value, "%s%d", "ppp",
			dist_ppp_index);
	}

	wan_ppp_fvp_count = 16;

	/* Form the fully qualified Name Value Pairs */
	if (ifx_get_conf_index_and_nv_pairs
	    (&wan_ppp_cfg->WAN_CONN.WAN_CONN_IID, wan_index, PREFIX_WAN_PPP,
	     wan_ppp_fvp_count, wan_ppp_array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__,
			__LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	/* Ignore the "ifppp" in WAN IP for ACL
	 * Hence count should be (count - 1)
	 */
#if 0
	CHECK_ACL_RET(wan_ppp_cfg->WAN_CONN.WAN_CONN_IID,
		      (wan_ppp_fvp_count - 1), wan_ppp_array_fvp,
		      wan_ppp_changed_fvp_count, wan_ppp_changed_array_fvp,
		      flags, IFX_Handler)
#endif
	/********* System Config File Update Block  **********/
	    /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	    NULL_TERMINATE(buf, 0x00, sizeof(buf));
	form_cfgdb_buf(buf, wan_ppp_fvp_count, wan_ppp_array_fvp);

	/* For MODIFY/DELETE operations, first we need to stop the running configuration
	 * with the CheckPointed file in WAN MAIN.
	 * Restore the CHECKPOINTED FILE in WAN MAIN to RC.CONF in order to stop service
	 */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)
	    || IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) {
		if (IFX_INT_ADD_F_NOT_SET(flags)) {
			/* Case of MODIFY & DELETE */
			/* Stop the Sevice with Checkpointed file in WAN MAIN */
			/* First get the CheckPointed file to rc.conf */
#ifdef NOT_REQUIRED_FOR_ZERO_DOT_FIVE
			ifx_config_write(CHKPOINT_FILE, IFX_F_DEFAULT);
#endif
			IFX_DBG("[%s:%d] owner [%d]", __FUNCTION__, __LINE__,
				wan_ppp_cfg->WAN_CONN.WAN_CONN_IID.
				config_owner);
			sprintf(sCommand, "%s %d", SERVICE_WANIP_STOP,
				wan_index);
			ret = system(sCommand);
			ret = IFX_SUCCESS;
		}
		if (ret != IFX_SUCCESS) {
			/* ??? What do we need to do if some services Stopped while others
			 * are still running ? Do we need to start the services again
			 * with the Check-Pointed file ?
			 * ??? */

			/* For now we just goto the IFX_Handler and return IFX_FAILURE */
			goto IFX_Handler;
		}
	}

	/* Here we restore back the Temp CheckPointed file that
	 * contains the changes made in WAN MAIN */
#ifdef NOT_REQUIRED_FOR_ZERO_DOT_FIVE
	ifx_config_write(CHKPOINT_FILE2, IFX_F_DEFAULT);
#endif

	/* Here there is no Backup of rc.conf required as we have done backup at WAN MAIN
	 * Directly call SetCfgData function to update the system cofiguration in rc.conf */
	ret = IFX_SUCCESS;
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_PPP, flags, 1, buf);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Set Data in rc.conf Fail", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}

	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)
	    || IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) {
		/* We need to invoke the scripts to bringup WAN interface.
		 * ??? What do we need to do if some services Started while others
		 * are stopped ? Do we need to stop the services again
		 * with the Check-Pointed file ?
		 * ??? */
		/* For now we ignore all the stopped services and start
		 * services again */
		if(IFX_INT_DONT_START_SERVICES_F_NOT_SET(flags)) {
			if (IFX_DELETE_F_NOT_SET(flags)
			    && (IFX_DEACTIVATE_F_NOT_SET(flags))) {
				/* Just bring up this WAN interface for ADD/MODIFY-ENABLE cases */
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] owner [%d]", __FUNCTION__, __LINE__,
					wan_ppp_cfg->WAN_CONN.WAN_CONN_IID.
					config_owner);
#endif
				sprintf(sCommand, "%s %d", SERVICE_WANIP_START,
					wan_index);
				ret = system(sCommand);
				ret = IFX_SUCCESS;
	
			}
		}

	}

	/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if (IFX_MODIFY_F_SET(flags)) {
#if 0
		CHECK_N_SEND_NOTIFICATION(wan_ppp_cfg->WAN_CONN.WAN_CONN_IID,
					  wan_ppp_changed_fvp_count,
					  wan_ppp_changed_array_fvp, flags,
					  IFX_Handler)
#endif
	} else if (IFX_INT_ADD_F_SET(flags)) {
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */
		/*********** Epilog Block **************/
#if 0
		UPDATE_ID_MAP_N_ATTRIBUTES(&wan_ppp_cfg->WAN_CONN.WAN_CONN_IID,
					   wan_ppp_fvp_count, wan_ppp_array_fvp,
					   flags, IFX_Handler)
		    CHECK_N_SEND_NOTIFICATION(wan_ppp_cfg->WAN_CONN.
					      WAN_CONN_IID, wan_ppp_fvp_count,
					      wan_ppp_array_fvp, flags,
					      IFX_Handler)
#endif
		    /* Update the "ppp" Index in wan_ppp Section */
		    if (ifx_manipulate_wan_indexs
			(FILE_RC_CONF, TAG_WAN_PPP, "wan_ppp_pppIdx",
			 dist_ppp_index, IFX_F_INT_ADD) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Manipulate wan index Fail",
				__FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	} else if (IFX_DELETE_F_SET(flags)) {
		/* In case of DELETE operation, first send the notificatioupdate the ID Mappings
		 * and then send the Notification for the attributes
		 */
		/*********** Epilog Block **************/
#if 0
		CHECK_N_SEND_NOTIFICATION(wan_ppp_cfg->WAN_CONN.WAN_CONN_IID,
					  wan_ppp_fvp_count, wan_ppp_array_fvp,
					  flags, IFX_Handler)
		    UPDATE_ID_MAP_N_ATTRIBUTES(&wan_ppp_cfg->WAN_CONN.
					       WAN_CONN_IID, wan_ppp_fvp_count,
					       wan_ppp_array_fvp, flags,
					       IFX_Handler)
#endif
		    /* Delete the "ppp" Index in WAN_PPP Section */
		    if (ifx_manipulate_wan_indexs
			(FILE_RC_CONF, TAG_WAN_PPP, "wan_ppp_pppIdx",
			 dist_ppp_index, IFX_F_DELETE) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Manipulate ppp index Fail",
				__FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Updating Persistent Storage Fail",
			__FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(wan_ppp_changed_array_fvp)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return IFX_FAILURE;
	} else
		return IFX_SUCCESS;
}

#ifdef CONFIG_PACKAGE_IFX_OAM
int32 ifx_set_atmf5_loop_diagnostics(int32 operation,
				     WAN_ATMF5_LOOP_DIAGNOSTICS * atmf5_daigs,
				     uint32 flags)
{
	FILE *in = NULL;
	char8 conf_buf[MAX_DATA_LEN];
	char8 *ret_WANConnDevStr = NULL, sValue[MAX_FILELINE_LEN];
	char8 buf[MAX_FILELINE_LEN];
	int32 ret = IFX_SUCCESS, passed_index = -1, count = 0, changed_count =
	    0;
	int32 f_vpi = 0, f_vci = 0, itf = 0;
	uint32 outFlag = IFX_F_DELETE;
	IFX_NAME_VALUE_PAIR array_fvp[18], *array_changed_fvp = NULL;

	if (atmf5_daigs == NULL) {
		return IFX_FAILURE;
	}

	/*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY)
	 * append the flag with internal flags */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

	if (atmf5_daigs->iid.pcpeId.Id == 0) {
		/* Get the parent info from the passed VCC
		 * information refering to WAN_CONN_DEV.
		 * Here it is mandatory to pass the VCC info */

		/* First get the VCC information */
		NULL_TERMINATE(buf, 0x00, sizeof(buf));
		sprintf(buf, "%d/%d", atmf5_daigs->vpi, atmf5_daigs->vci);

		if (ifx_ret_substr_from_distfield
		    (FILE_RC_CONF, TAG_WAN_CONN_DEVICE, "vcc", buf,
		     &ret_WANConnDevStr) != IFX_SUCCESS) {
			/* Check if the given VCC exists in WAN Connection Device Section
			   If it doesn't exist then it's an error */
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		} else {
			/* Here we would have got the return string as wan_dev_x
			 * where 'x' denotes the device instance. Now get the cpeId
			 * for this instance 'x' */
			sprintf(buf, "%s_%s", ret_WANConnDevStr, "cpeId");
			if ((ifx_GetObjData
			     (FILE_RC_CONF, TAG_WAN_CONN_DEVICE, buf,
			      IFX_F_GET_ANY, &outFlag,
			      sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			} else {
				atmf5_daigs->iid.pcpeId.Id = atoi(sValue);
				sprintf(atmf5_daigs->iid.pcpeId.secName, "%s",
					TAG_WAN_CONN_DEVICE);
			}
		}
	}

	/**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		//IFX_VALIDATE_PTR(atmf5_daigs)
		/* Do simple validation of flags sucha as less than 0 */
		//IFX_VALIDATE_FLAGS(flags)
		if (flags == 0) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		/* if entry is disabled then deny a modify enable from non-tr69 entity */
		IFX_VALIDATE_OAM_F5_ENTRY(atmf5_daigs, operation)
	}

	/**************** ID Allocation Block - Only for ADD Operation **************/
	sprintf(atmf5_daigs->iid.cpeId.secName, "%s", TAG_WAN_ATMF5);
	sprintf(atmf5_daigs->iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);

	if (IFX_ADD_F_SET(flags)) {
		/* Allocate the IID for this route instance
		 * Set the parent SectionName and parent IID values
		 * to NULL as there is no parent for Route Entity
		 */
		if (ifx_get_IID(&atmf5_daigs->iid, "diagnosticState") !=
		    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	/*********** Device Configuration Block ****************/
	/* Call the API with respective values Call API if IFX_F_DON'T_CONFIGURE is not set
	 * and diagnostic_state=WAN_DIAG_START_DIAGNOSING */
	if ((IFX_DONT_ACTIVATE_F_NOT_SET(flags)
	     || IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags))
	    && atmf5_daigs->diagnostic_state == WAN_DIAG_START_DIAGNOSING) {
		/* check if the vcc is configured in kernel, if configured then only do the ping test otherwise set state to error */
#ifdef CPU_AMAZON
		if ((in = fopen(PROCF_AMZ_VC, "r"))) {
			while (buf == fgets(buf, sizeof(buf), in)) {
				if (strstr(buf, "vpi")) {
					sscanf(buf, "\tvpi=%d vci=%d ", &f_vpi,
					       &f_vci);
					if (atmf5_daigs->vpi == f_vpi
					    && atmf5_daigs->vci == f_vci) {
						if (ifx_oam_f5_ping
						    (atmf5_daigs->vpi,
						     atmf5_daigs->vci,
						     atmf5_daigs->scope,
						     atmf5_daigs->ping_timeout,
						     atmf5_daigs->oam_pings,
						     &atmf5_daigs->
						     success_count,
						     &atmf5_daigs->
						     max_resp_time,
						     &atmf5_daigs->
						     min_resp_time,
						     &atmf5_daigs->
						     avg_resp_time) !=
						    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
							IFX_DBG("[%s:%d]",
								__FUNCTION__,
								__LINE__);
#endif
							atmf5_daigs->
							    diagnostic_state =
							    WAN_DIAG_ERROR_INT;
						} else
							atmf5_daigs->
							    diagnostic_state =
							    WAN_DIAG_COMEPLETE;
					}
				}
			}
			fclose(in);
		}
#else

		if ((in = fopen(PROCF_DNB_VC, "r"))) {
			while (buf == fgets(buf, sizeof(buf), in)) {
				if (strstr(buf, "Address") != NULL)
					continue;
				sscanf(buf, "%s %3d %3d %5d ", sValue, &itf,
				       &f_vpi, &f_vci);
				if (atmf5_daigs->vpi == f_vpi
				    && atmf5_daigs->vci == f_vci) {
					if (ifx_oam_f5_ping
					    (atmf5_daigs->vpi, atmf5_daigs->vci,
					     atmf5_daigs->scope,
					     atmf5_daigs->ping_timeout,
					     atmf5_daigs->oam_pings,
					     (int *)&atmf5_daigs->success_count,
					     (int *)&atmf5_daigs->max_resp_time,
					     (int *)&atmf5_daigs->min_resp_time,
					     (int *)&atmf5_daigs->
					     avg_resp_time) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
						IFX_DBG("[%s:%d]", __FUNCTION__,
							__LINE__);
#endif
						atmf5_daigs->diagnostic_state =
						    WAN_DIAG_ERROR_INT;
					} else
						atmf5_daigs->diagnostic_state =
						    WAN_DIAG_COMEPLETE;
				}
			}
			if (strlen(buf) <= 0)
				atmf5_daigs->diagnostic_state =
				    WAN_DIAG_ERROR_INT;
			fclose(in);
		}
#endif
		else
			atmf5_daigs->diagnostic_state = WAN_DIAG_ERROR_INT;

	}

	/************** System Config File Update Block ****************/
	/* Form the complete field value pairs with the values updated from the ping api */
	if (IFX_DELETE_F_NOT_SET(flags)) {
		atmf5_daigs->failure_count =
		    atmf5_daigs->oam_pings - atmf5_daigs->success_count;

		memset(array_fvp, 0x00, sizeof(array_fvp));
		ifx_fill_ArrayFvp_FName(array_fvp, 0, 17,
					wan_atmf5_param_names);

		f_vpi = atmf5_daigs->vpi;
		f_vci = atmf5_daigs->vci;
		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 5,
					    (int32 *) & atmf5_daigs->iid.cpeId.
					    Id, &atmf5_daigs->iid.pcpeId.Id,
					    &atmf5_daigs->f_enable, &f_vpi,
					    &f_vci);

		sprintf(array_fvp[5].value, "%d", atmf5_daigs->scope);
		ifx_fill_ArrayFvp_intValues(array_fvp, 6, 10,
					    (int32 *) & atmf5_daigs->
					    diagnostic_state,
					    (int32 *) & atmf5_daigs->
					    ping_timeout,
					    (int32 *) & atmf5_daigs->oam_pings,
					    (int32 *) & atmf5_daigs->loopback,
					    (int32 *) & atmf5_daigs->cc_check,
					    (int32 *) & atmf5_daigs->
					    success_count,
					    (int32 *) & atmf5_daigs->
					    failure_count,
					    (int32 *) & atmf5_daigs->
					    min_resp_time,
					    (int32 *) & atmf5_daigs->
					    max_resp_time,
					    (int32 *) & atmf5_daigs->
					    avg_resp_time);

		sprintf(array_fvp[16].value, "%d",
			(atmf5_daigs->cc_check_opt + 1));
		passed_index = -1;
	}
	count = 17;

	/* Get Config Index in case of modify/delete operations from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, atmf5_daigs->iid.cpeId,
					 passed_index)
	}

	/* Determine the configuration index - for Add, Delete, Modify operations
	 * Name is partial since index is not known
	 * Fill array_fvp[] */
	if (ifx_get_conf_index_and_nv_pairs
	    (&atmf5_daigs->iid, passed_index, PREFIX_WAN_ATMF5, count,
	     array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	/* Clean up the changes array fvp pointer and count before calling ACL check with these parameters */
	changed_count = 0;
	IFX_MEM_FREE(array_changed_fvp)
	    if (IFX_ADD_F_NOT_SET(flags)) {
		CHECK_ACL_RET(atmf5_daigs->iid, count, array_fvp,
			      changed_count, array_changed_fvp, flags,
			      IFX_Handler)
	}

	/*************** System Config File Update Block *****************/
	/* Backup rc.conf before proceeding with configuration */
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_ATMF5, flags, 1, conf_buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/****************** Device configuration block *******************/
	/* this will Compact the section and also update the count for both ADD and DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_WAN_ATMF5, flags);

	/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if (IFX_MODIFY_F_SET(flags))
		CHECK_N_SEND_NOTIFICATION(atmf5_daigs->iid, changed_count,
					  array_changed_fvp, flags, IFX_Handler)

		    else
	if (IFX_INT_ADD_F_SET(flags)) {
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */
		UPDATE_ID_MAP_N_ATTRIBUTES(&atmf5_daigs->iid, count, array_fvp,
					   flags, IFX_Handler)

		    CHECK_N_SEND_NOTIFICATION(atmf5_daigs->iid, count,
					      array_fvp, flags, IFX_Handler)

		    /* Manipulate nextCpeId only for ADD operations */
		    ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WAN_ATMF5);
	} else if (IFX_DELETE_F_SET(flags)) {
		/* In case of DELETE operation, first send the notificatioupdate the ID Mappings
		 * and then send the Notification for the attributes
		 */
		CHECK_N_SEND_NOTIFICATION(atmf5_daigs->iid, count, array_fvp,
					  flags, IFX_Handler)

		    UPDATE_ID_MAP_N_ATTRIBUTES(&atmf5_daigs->iid, count,
					       array_fvp, flags, IFX_Handler)
	}

	/*********** Epilog Block **************/
	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(ret_WANConnDevStr)
	    IFX_MEM_FREE(array_changed_fvp)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;

}
#endif

#if 0
#ifndef CONFIG_PACKAGE_IFX_DSL_CPE_API
int32 ifx_set_wan_dsl_diagnostics(int32 operation,
				  WAN_DSL_DIAGNOSTICS * Wan_Dsl_Diag,
				  uint32 flags)
{
	char8 buf[MAX_FILELINE_LEN], conf_buf[MAX_DATA_LEN * MAX_FILELINE_LEN],
	    adsl_status[10];
	int32 i = 0, count = 0, t_count = 0, status = 0, Fd = 0, ret =
	    IFX_SUCCESS, t_fd = 0;
	struct adslAtucPhysEntry adslAtucPhysStruct;
	// struct       adslAturPhysEntry adslAturPhysStruct;
	struct adslATURSubcarrierInfo adslATURSubcarrierInfoStruct;
	struct adslPowerSpectralDensity adslPowerSpecDensityStruct;
	IFX_NAME_VALUE_PAIR array_fvp[2];

	NULL_TERMINATE(array_fvp, 0x00, sizeof(array_fvp));
	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
	NULL_TERMINATE(adsl_status, 0x00, sizeof(adsl_status));
	NULL_TERMINATE(&adslAtucPhysStruct, 0x00, sizeof(adslAtucPhysStruct));
	NULL_TERMINATE(&adslAturPhysStruct, 0x00, sizeof(adslAturPhysStruct));
	NULL_TERMINATE(&adslATURSubcarrierInfoStruct, 0x00,
		       sizeof(adslATURSubcarrierInfoStruct));
	NULL_TERMINATE(&adslPowerSpecDensityStruct, 0x00,
		       sizeof(adslPowerSpecDensityStruct));

	// Check if f_enable is set to enabled
	// and diagnostic_state is WAN_DSL_START_DIAGNOSING
	if ((Wan_Dsl_Diag->f_enable == IFX_ENABLED) &&
	    (Wan_Dsl_Diag->diagnostic_state == WAN_DIAG_START_DIAGNOSING)) {
		//Open the amazon_mei device
		Fd = open(ADSL_DEV_PATH, O_RDONLY);
		if (Fd <= 0) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		//Call the ioctl API start the DSL Diagnosis
		ioctl(Fd, SET_ADSL_LOOP_DIAGNOSTICS_MODE, 1);

		//Wait for some time
		//Check whether the diagnosis is complete
		//Check this in a loop after some sleep
		for (i = 0; i < 15; i++) {
			sleep(10);
			ioctl(Fd, IS_ADSL_LOOP_DIAGNOSTICS_MODE_COMPLETE,
			      &status);

			if (status == 1) {
				break;
			}
		}

		/* set the adsl loop diagnostic mode back to 0 */
		ioctl(Fd, SET_ADSL_LOOP_DIAGNOSTICS_MODE, 0);

		/* test for adsl showtime in a loop and then call ioctls to get values */
		for (i = 0; i < 15; i++) {
			sleep(2);
			t_fd = open("/tmp/adsl_status", O_RDONLY);
			read(t_fd, adsl_status, sizeof(adsl_status));
			close(t_fd);
			if (atoi(adsl_status) == 7)
				break;
		}

		//Get the values after the diagnostic test
		ioctl(Fd, GET_ADSL_POWER_SPECTRAL_DENSITY, (void *)&adslPowerSpecDensityStruct);	//ACTPSDds,ACTPSDus

		SET_FLAG(&adslAtucPhysStruct.flags, ATUC_CURR_OUT_PWR_FLAG);
		ioctl(Fd, GET_ADSL_ATUC_PHY, (void *)&adslAtucPhysStruct);	//ACTATPds(outputPwr)

		SET_FLAG(&adslAturPhysStruct.flags, ATUR_CURR_OUT_PWR_FLAG);
		ioctl(Fd, GET_ADSL_ATUR_PHY, (void *)&adslAturPhysStruct);	//ACTATPus(outputPwr)

		SET_FLAG(&adslATURSubcarrierInfoStruct.flags, FAREND_HLINSC);
		SET_FLAG(&adslATURSubcarrierInfoStruct.flags, FAREND_HLINPS);
		SET_FLAG(&adslATURSubcarrierInfoStruct.flags, FAREND_QLNPS);
		SET_FLAG(&adslATURSubcarrierInfoStruct.flags, FAREND_SNRPS);
		SET_FLAG(&adslATURSubcarrierInfoStruct.flags, FAREND_BITPS);
		SET_FLAG(&adslATURSubcarrierInfoStruct.flags, FAREND_GAINPS);

		ioctl(Fd, GET_ADSL_ATUR_SUBCARRIER_STATS,
		      (void *)&adslATURSubcarrierInfoStruct);

		sprintf(Wan_Dsl_Diag->iid.cpeId.secName, "%s", TAG_DSL_DIAG);
		sprintf(Wan_Dsl_Diag->iid.cpeId.secName, "%s", TAG_WAN_DEVICE);

		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 9,
					    &Wan_Dsl_Diag->iid.cpeId.Id,
					    &Wan_Dsl_Diag->iid.pcpeId.Id,
					    &Wan_Dsl_Diag->f_enable,
					    &Wan_Dsl_Diag->diagnostic_state,
					    &adslPowerSpecDensityStruct.
					    ACTPSDds,
					    &adslPowerSpecDensityStruct.
					    ACTPSDus,
					    &adslAtucPhysStruct.outputPwr,
					    &adslAturPhysStruct.outputPwr,
					    &adslATURSubcarrierInfoStruct.
					    HLINSCds);

		//Store it in rc.conf or copy the values to a static struct
		sprintf(array_fvp[count].fieldname, "%s_cpeId",
			PREFIX_DSL_DIAG);
		sprintf(array_fvp[count].fieldname, "%s_pcpeId",
			PREFIX_DSL_DIAG);
		sprintf(array_fvp[count].fieldname, "%s_fEnable",
			PREFIX_DSL_DIAG);
		// SetCfgData(adslATURSubcarrierInfoStruct.diagnostic_state); int
		sprintf(array_fvp[count].fieldname, "%s_diagnosticState",
			PREFIX_DSL_DIAG);
		// SetCfgData(adslAtucPhysStruct.ACTPSDds, adslAtucPhysStruct.ACTPSDus); both ints
		sprintf(array_fvp[count].fieldname, "%s_ACTPSDds",
			PREFIX_DSL_DIAG);
		sprintf(array_fvp[count].fieldname, "%s_ACTPSDus",
			PREFIX_DSL_DIAG);
		// SetCfgData(adslAtucPhysStruct.outputPwr); int
		sprintf(array_fvp[count].fieldname, "%s_ACTATPds",
			PREFIX_DSL_DIAG);
		// SetCfgData(adslAturPhysStruct.outputPwr); int
		sprintf(array_fvp[count].fieldname, "%s_ACTATPus",
			PREFIX_DSL_DIAG);
		// SetCfgData(adslATURSubcarrierInfoStruct.HLINSCds); int
		sprintf(array_fvp[count].fieldname, "%s_HLINSCds",
			PREFIX_DSL_DIAG);
		// SetCfgData(adslATURSubcarrierInfoStruct.HLINpsds); store as array
		t_count = 0;
		for (i = 0; i < 1024; i++) {
			sprintf(buf, "%d",
				adslATURSubcarrierInfoStruct.HLINpsds[i]);
			strcat(conf_buf, buf);
			if (((i + 1) % 32) == 0) {
				sprintf(array_fvp[count].fieldname,
					"%s_HLINpsds_%d", PREFIX_DSL_DIAG,
					t_count);
				sprintf(array_fvp[count].value, "%s", conf_buf);
				t_count++;
				count++;
			} else {
				strcat(conf_buf, ",");
			}
		}
		// SetCfgData(adslATURSubcarrierInfoStruct.QLNpsds); store as array
		t_count = 0;
		for (i = 0; i < 512; i++) {
			sprintf(buf, "%d",
				adslATURSubcarrierInfoStruct.QLNpsds[i]);
			strcat(conf_buf, buf);
			if (((i + 1) % 32) == 0) {
				sprintf(array_fvp[count].fieldname,
					"%s_QLNpsds_%d", PREFIX_DSL_DIAG,
					t_count);
				sprintf(array_fvp[count].value, "%s", conf_buf);
				t_count++;
				count++;
			} else {
				strcat(conf_buf, ",");
			}
		}
		// SetCfgData(adslATURSubcarrierInfoStruct.SNRpsds); store as array
		t_count = 0;
		for (i = 0; i < 512; i++) {
			sprintf(buf, "%d",
				adslATURSubcarrierInfoStruct.SNRpsds[i]);
			strcat(conf_buf, buf);
			if (((i + 1) % 32) == 0) {
				sprintf(array_fvp[count].fieldname,
					"%s_SNRpsds_%d", PREFIX_DSL_DIAG,
					t_count);
				sprintf(array_fvp[count].value, "%s", conf_buf);
				t_count++;
				count++;
			} else {
				strcat(conf_buf, ",");
			}
		}
		// SetCfgData(adslATURSubcarrierInfoStruct.BITSpsds); store as array
		t_count = 0;
		for (i = 0; i < 512; i++) {
			sprintf(buf, "%d",
				adslATURSubcarrierInfoStruct.BITpsds[i]);
			strcat(conf_buf, buf);
			if (((i + 1) % 32) == 0) {
				sprintf(array_fvp[count].fieldname,
					"%s_BITpsds_%d", PREFIX_DSL_DIAG,
					t_count);
				sprintf(array_fvp[count].value, "%s", conf_buf);
				t_count++;
				count++;
			} else {
				strcat(conf_buf, ",");
			}
		}
		// SetCfgData(adslATURSubcarrierInfoStruct.GAINSpsds); store as array
		t_count = 0;
		for (i = 0; i < 512; i++) {
			sprintf(buf, "%d",
				adslATURSubcarrierInfoStruct.GAINpsds[i]);
			strcat(conf_buf, buf);
			if (((i + 1) % 32) == 0) {
				sprintf(array_fvp[count].fieldname,
					"%s_GAINpsds_%d", PREFIX_DSL_DIAG,
					t_count);
				sprintf(array_fvp[count].value, "%s", conf_buf);
				t_count++;
				count++;
			} else {
				strcat(conf_buf, ",");
			}
		}

				/********* System Config File Update Block  **********/
		/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
		NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
		form_cfgdb_buf(conf_buf, count, array_fvp);

		ret =
		    ifx_SetObjData(FILE_DSL_DIAG, TAG_DSL_DIAG, flags, 1,
				   conf_buf);
		/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
	} else {
		sprintf(buf, "%s_diagnosticState=\"%d\"\n", PREFIX_DSL_DIAG,
			Wan_Dsl_Diag->diagnostic_state);

		ret =
		    ifx_SetObjData(FILE_DSL_DIAG, TAG_DSL_DIAG, flags, 1, buf);
		/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
	}

      IFX_Handler:
	close(Fd);
	if (ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}
#endif				//!CONFIG_PACKAGE_IFX_DSL_CPE_API
#endif

/* GET APIs */

/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_default_wan_if(...)
*		operation	==>   the operation to be performed for this route entry, can be ADD, DELETE or MODIFY
*    	entry		==>   pointer to ROUTE_ENTRY structure that has the route details
*    	flags		==>   flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description	 :	This api sets the default wan interface
						it gets the wan connection name and interface either from the input wan_index
   						or cpeId in iid structure.
*/////////////////////////////////////////////////////////////////////////////
int32 ifx_set_default_wan_if(IFX_ID * iid, int32 wan_type, uint32 flags)
{
	char8 def_iface[IFNAMSIZE], conn_name[MAX_CONN_NAME_LEN],
	    buf[MAX_DATA_LEN], prev_def_iface[IFNAMSIZE];
	char8 secName[MAX_FILELINE_LEN], gw_addr[MAX_IP_ADDR_LEN],
	    conf_conn_name[MAX_CONN_NAME_LEN], prefix[MAX_FILELINE_LEN];
	char8 sValue[MAX_FILELINE_LEN], qosenable[10], tcpackenable[10], g8021penable[10];
	int32 ret = IFX_SUCCESS, count = 0, changed_fcount =
	    0, acl_array_count = 0;
	int32 wan_index;
	char8 sCommand[MAX_FILELINE_LEN];
#ifdef  CONFIG_PACKAGE_NTPCLIENT
	char8 sVal[MAX_FILELINE_LEN];
	int32 ntp_fEnable = 0;
#endif
	uint32 outFlag = IFX_F_DEFAULT;
	FILE *fd = NULL;
	IFX_NAME_VALUE_PAIR array_fvp[5], *array_changed_fvp =
	    NULL, acl_array_fvp[1];
	IFX_ID t_iid, wan_id;
	WAN_CONN_CFG wan_cfg;
	int num_bytes = 0;
	char8 dw_buf[MAX_DATA_LEN];

//      IFX_MAPI_QoS_QM qos_qm;
	NULL_TERMINATE(prev_def_iface, 0, sizeof(prev_def_iface));
	NULL_TERMINATE(def_iface, 0, sizeof(def_iface));
	NULL_TERMINATE(conn_name, 0, sizeof(conn_name));
	NULL_TERMINATE(gw_addr, 0, sizeof(gw_addr));
	NULL_TERMINATE(buf, 0, sizeof(buf));
	NULL_TERMINATE(sCommand, 0, sizeof(sCommand));
	memset(&wan_cfg, 0, sizeof(wan_cfg));
	memset(&t_iid, 0, sizeof(t_iid));
	//memset(&qos_qm, 0x00, sizeof(qos_qm));

	/************* Prolog Block **************/
	/* Based on operation (ADD or DEL or MOD)
	 * append the flag with internal flags */
	flags |= IFX_F_MODIFY;

	/************* Validation Block ************/
	/* Do simple validation of flags such as less than 0 */
	if (IFX_DONT_VALIDATE_F_NOT_SET(flags))
		IFX_VALIDATE_FLAGS(flags)

	/******************* Id Block ************************/
		    sprintf(iid->cpeId.secName, "%s", TAG_DEFAULT_WAN);
	sprintf(iid->pcpeId.secName, "%s", TAG_IGD);
// #705244:Pramod start
#if 1
	t_iid = *iid;
	t_iid.cpeId.Id = 1;
	t_iid.pcpeId.Id = 1;
#endif
// #705244:Pramod end

	if (wan_type == WAN_TYPE_IP) {
		sprintf(secName, "%s", TAG_WAN_IP);
		sprintf(prefix, "%s", PREFIX_WAN_IP);
	} else if (wan_type == WAN_TYPE_PPP) {
		sprintf(secName, "%s", TAG_WAN_PPP);
		sprintf(prefix, "%s", PREFIX_WAN_PPP);
	}

	if((ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_enable", IFX_F_GET_ANY, &outFlag, qosenable)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	if((ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_tcpackprio", IFX_F_GET_ANY, &outFlag, tcpackenable)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	if((ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_P8021enable", IFX_F_GET_ANY, &outFlag, g8021penable)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/************* Name Value Formation as per RC.CONF *************/
	/* Pramod : should use wan_index if iid not given */
	sprintf(buf, "%d", iid->cpeId.Id);
	wan_id.cpeId.Id = iid->cpeId.Id;
	snprintf(wan_id.cpeId.secName, MAX_TAG_LEN,"%s", secName);
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wan_id.cpeId, wan_index)

	    /* from the substring such as wan_2_ form the wan_2_linkType
	     * tag and check the value for this */
	    sprintf(buf, "%s_%d_connName", prefix, wan_index);
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, secName, buf, IFX_F_GET_ANY, &outFlag,
			    conn_name)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}

	sprintf(buf, "%s_%d_confconnName", prefix, wan_index);
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, secName, buf, IFX_F_GET_ANY, &outFlag,
			    conf_conn_name)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}

	if (strstr(conn_name, "WANPPP"))
		ret =
		    ifx_get_wan_ifname_from_connName(conn_name, def_iface,
						     WAN_TYPE_PPP);
	else
		ret =
		    ifx_get_wan_ifname_from_connName(conn_name, def_iface,
						     WAN_TYPE_IP);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("failed to get default iface !!\n");
#endif
		goto IFX_Handler;
	}

/**********************************************************************************/
// "default_wan_cfg_fused" section setting
/************************** Default Wan Per Wan Mode ******************************/
	int32 current_wan_mode;
	int32 callers_wan_mode;
	int32 phy, tc;

	//Callers WAN MODE
	sprintf(buf, "%s_%d_wanMode", prefix, wan_index);
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, secName, buf, IFX_F_GET_ANY,
			    &outFlag, sValue)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	callers_wan_mode = atoi(sValue);

	//Current WAN MODE
	strcpy(buf, "wanphy_phymode");
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, buf, IFX_F_GET_ANY,
			    &outFlag, sValue)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	phy = atoi(sValue);

	strcpy(buf, "wanphy_tc");
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, buf, IFX_F_GET_ANY,
			    &outFlag, sValue)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	tc = atoi(sValue);

	current_wan_mode = compute_wan_mode(phy, tc);

#ifdef IFX_LOG_DEBUG
	IFX_DBG("current_wan_mode = %d \n", current_wan_mode);
	IFX_DBG("callers_wan_mode = %d \n", callers_wan_mode);
#endif

	//Field Name
	sprintf(array_fvp[0].fieldname, "%s_%d_%s", "default_wan",
		callers_wan_mode, "conn_cpeId");
	sprintf(array_fvp[1].fieldname, "%s_%d_%s", "default_wan",
		callers_wan_mode, "conn_pcpeId");
	sprintf(array_fvp[2].fieldname, "%s_%d_%s", "default_wan",
		callers_wan_mode, "conn_connName");
	sprintf(array_fvp[3].fieldname, "%s_%d_%s", "default_wan",
		callers_wan_mode, "conn_confconnName");
	sprintf(array_fvp[4].fieldname, "%s_%d_%s", "default_wan",
		callers_wan_mode, "conn_iface");

	/* get the connection name as wan2, wan6, .... */
	sprintf(array_fvp[0].value, "%d", iid->cpeId.Id);
	sprintf(array_fvp[1].value, "%d", iid->pcpeId.Id);
	sprintf(array_fvp[2].value, "%s", conn_name);
	sprintf(array_fvp[3].value, "%s", conf_conn_name);
	sprintf(array_fvp[4].value, "%s", def_iface);
	count = 5;

	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(buf, count, array_fvp);

	/*Updating TAG_DEF_WAN_FUSED */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_DEF_WAN_FUSED, flags, 1, buf);

	/*Vicky_Note: Need to update flash after setObjData */
	ret = ifx_config_write(FILE_RC_CONF, flags);

		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

if ((current_wan_mode != callers_wan_mode)){
				/* Current Wan Mode and Configured WAN Mode Are Different,
				 * Updated only the fused default wan config of other WAN Mode
				 */

				/* TBD : Send signal to dual wan daemon to update default WAN config */
				if(ret == IFX_SUCCESS) {
								IFX_DBG("Sending Update to dw_daemon ");
								memset(dw_buf, 0x00, sizeof(dw_buf));
								sprintf(dw_buf, "%s", "Def_GW_Modified=\"1\"\n");
								ifx_SetObjData(FILE_SYSTEM_STATUS, "DW_default_WAN_Status", IFX_F_MODIFY, 1, dw_buf);
				}
				return IFX_SUCCESS;
}

	/* get the connection name as wan2, wan6, .... */
	sprintf(array_fvp[0].fieldname, "%s", "default_wan_conn_cpeId");
	sprintf(array_fvp[0].value, "%d", iid->cpeId.Id);
	sprintf(array_fvp[1].fieldname, "%s", "default_wan_conn_pcpeId");
	sprintf(array_fvp[1].value, "%d", iid->pcpeId.Id);
	/*sprintf(array_fvp[2].fieldname, "%s", "default_wan_conn_wan_cpeId");
	   sprintf(array_fvp[2].value, "%s", wan_cpeId); */
	sprintf(array_fvp[2].fieldname, "%s", "default_wan_conn_connName");
	sprintf(array_fvp[2].value, "%s", conn_name);
	sprintf(array_fvp[3].fieldname, "%s", "default_wan_conn_confconnName");
	sprintf(array_fvp[3].value, "%s", conf_conn_name);
	sprintf(array_fvp[4].fieldname, "%s", "default_wan_conn_iface");
	sprintf(array_fvp[4].value, "%s", def_iface);
	count = 5;
	sprintf(acl_array_fvp[0].fieldname, "%s",
		"default_wan_conn_confconnName");
	sprintf(acl_array_fvp[0].value, "%s", conf_conn_name);
	acl_array_count = 1;

	/**************** ACL Checking Block *****************/
	CHECK_ACL_RET(t_iid, acl_array_count, acl_array_fvp,
		      changed_fcount, array_changed_fvp, flags, IFX_Handler)

	    /* Delete the previously configured default route */
	    if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)
		|| IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) {
		fd = popen
		    ("/sbin/route -n | grep ^0.0.0.0 | tr -s ' ' | cut -d ' ' -f 8",
		     "r");
		if (fd != NULL)
        {
			num_bytes = fread(prev_def_iface, 1, sizeof(prev_def_iface), fd);
			prev_def_iface[num_bytes] = '\0';
			if (isspace(prev_def_iface[strlen(prev_def_iface) - 1]))
				prev_def_iface[strlen(prev_def_iface) - 1] = '\0';

			if (strlen(prev_def_iface)) {
				sprintf(buf,
					"route del default dev %s > /dev/null 2> /dev/null",
					prev_def_iface);
				if (system(buf))
					// ret = IFX_FAILURE;
					ret = IFX_SUCCESS;
			}
		}
		if (fd)
			pclose(fd);

		/* need to call mgmt.sh stop for web */
/*		fd = popen("/etc/rc.d/ipqos_mgmt_traffic_config web stop", "r");
		if(fd == NULL) {
#ifdef IFX_LOG_DEBUG
		    IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
            ret = IFX_FAILURE;
		    goto IFX_Handler;
		}
		if (fd)
			pclose(fd);
		*/

		/* Call TCP ACK Prio script(through ipqos_common) with DELETE option to delete IPTABLE Postrouting rule with older default interface name */

        		if ((atoi(qosenable) == 0) && (atoi(tcpackenable) == 1))
        		{
                		sprintf(sCommand,". /etc/rc.d/ipqos_common 0 2");
                		system(sCommand);
        		}
			/* Call ipqos_common script to set egress map of vconfig to default values for ATM/PTM modes */
			if ((atoi(qosenable) == 1) && (atoi(g8021penable) == 1))
			{
                		sprintf(sCommand,". /etc/rc.d/ipqos_common 2 1");
                		system(sCommand);
			}

	}			// IFX_DONT_ACTIVATE_F_NOT_SET

	/********* System Config File Update Block  **********/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(buf, count, array_fvp);

	/*manohar : get the previous default configuration*/
        IFX_ID  pre_def_iid;
        int32   pre_def_wanIdx = -1;
        char8   pre_def_wanconnName[MAX_CONN_NAME_LEN];

        if((ret = ifx_get_default_wan_if(&pre_def_iid, &pre_def_wanIdx, pre_def_wanconnName, IFX_F_DEFAULT)) != IFX_SUCCESS) {
                IFX_DBG("[%s][%d] if get_default_wan_if function failed \n",__FUNCTION__,__LINE__);
        }

#ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s][%d] pre_def_iid.cpeId.Id = [%d] pre_def_iid.pcpeId.Id = [%d] pre_def_wanIdx = [%d] pre_def_wanconnName = [%s]\n",__FUNCTION__,__LINE__,pre_def_iid.cpeId.Id,pre_def_iid.pcpeId.Id,pre_def_wanIdx,pre_def_wanconnName);
#endif
	/*manohar end*/


	/* Backup rc.conf before proceeding with configuration */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_DEFAULT_WAN, flags, 1, buf);
	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
	else {
		/* update default WAN config flag as modified */
		IFX_DBG("Sending Update to dw_daemon ");

		memset(dw_buf, 0x00, sizeof(dw_buf));
		sprintf(dw_buf, "%s", "Def_GW_Modified=\"1\"\n");
		ifx_SetObjData(FILE_SYSTEM_STATUS, "DW_default_WAN_Status", IFX_F_MODIFY, 1, dw_buf);
	}
#endif
	
	/*manohar : get the new default configuration*/
        IFX_ID  new_def_iid;
        int32   new_def_wanIdx = -1;
        char8   new_def_wanconnName[MAX_CONN_NAME_LEN];

        if((ret = ifx_get_default_wan_if(&new_def_iid, &new_def_wanIdx, new_def_wanconnName, IFX_F_DEFAULT)) != IFX_SUCCESS) {
                IFX_DBG("[%s][%d] if get_default_wan_if function failed \n",__FUNCTION__,__LINE__);
        }
#ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s][%d] new_def_iid.cpeId.Id = [%d] new_def_iid.pcpeId.Id = [%d] new_def_wanIdx = [%d] new_def_wanconnName = [%s]\n",__FUNCTION__,__LINE__,new_def_iid.cpeId.Id,new_def_iid.pcpeId.Id,new_def_wanIdx,new_def_wanconnName);
#endif
	/*manohar end*/

	/*Send event to Devm if default wan is changeg*/	
	if(pre_def_iid.cpeId.Id != new_def_iid.cpeId.Id || pre_def_iid.pcpeId.Id != new_def_iid.pcpeId.Id || strcmp(pre_def_wanconnName,new_def_wanconnName) || pre_def_wanIdx != new_def_wanIdx)
	{
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s][%d] Calling event util for sending event to devm\n",__FUNCTION__,__LINE__);
#endif
                	sprintf(sCommand,"/usr/sbin/ifx_event_util \"DEFAULT_WAN_CHANGE\" \"MOD\" \"%s\" \"wan_index\" \"%d\"",secName,new_def_wanIdx);
                	system(sCommand);
	}
	/*manohar end*/

	/*********************** Device Configuration Block **************************/
	/* Pramod : commenting adding the default route, but this is a design issue to take up later
	   Call get api for this wan index, get the ip address from the returned structure and use it
	   as the gateway for the the default route */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)
	    || IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) {

		if (wan_type == WAN_TYPE_IP)
			sprintf(secName, "WanIP%d_GATEWAY", wan_index);
		else
			sprintf(secName, "WanPPP%d_GATEWAY", wan_index);

		if ((ret =
		     ifx_GetObjData(FILE_SYSTEM_STATUS, secName, "ROUTER1",
				    IFX_F_GET_ANY, &outFlag,
				    gw_addr)) == IFX_SUCCESS) {
			if (strlen(gw_addr) && strcmp(gw_addr, "0.0.0.0")) {
				sprintf(buf, "route add default gw %s dev %s",
					gw_addr, def_iface);
				if (system(buf))
					// ret = IFX_FAILURE;
					ret = IFX_SUCCESS;
			}
		}

		/* TODO : need comment here */
		//       sprintf(buf, "/etc/rc.d/ipqos_cfg_mgmt start %d", wan_index);
		//     system(buf);

		memset(buf, 0, sizeof(MAX_DATA_LEN));

		/* restart udhcpd since relay service, part of udhcpd, is dependant on default wan interface */
		sprintf(buf, "%s_0_dhcpMode", TAG_LAN_MAIN);
		ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, buf, IFX_F_GET_ANY,
			       &outFlag, sValue);
		if (!strcmp(sValue, "relay")) {
			system("/etc/rc.d/init.d/udhcpd stop");
			system("/etc/rc.d/init.d/udhcpd start");
		}

		/* need to call mgmt.sh start for web */
/*		fd = popen("/etc/rc.d/ipqos_mgmt_traffic_config web start", "r");
		if(fd == NULL) {
#ifdef IFX_LOG_DEBUG
		    IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
            ret = IFX_FAILURE;
		    goto IFX_Handler;
		}
		if (fd)
			pclose(fd);
		*/
#if 0
		/*Init PPE_IPQOS when ever default wan connection is changed from web page */
		sprintf(sCommand, "%s", PPE_IPQOS_MAIN);
		system(sCommand);
#endif
		/* Call Ipqos TCP ACK Prio script( through ipqos_common ) with ADD option to ADD new Iptables Postrouting rule with the new interface name */

		if ((atoi(qosenable) == 0) && (atoi(tcpackenable) == 1))
		{
        		sprintf(sCommand,". /etc/rc.d/ipqos_common 0 0");
        		system(sCommand);
		}
		/* Set egress map of vconfig for the new defaultwan for 8021P remarking in ATM/PTM modes */
		if ((atoi(qosenable) == 1) && (atoi(g8021penable) == 1))
		{
                	sprintf(sCommand,". /etc/rc.d/ipqos_common 2 0");
                	system(sCommand);
		}
	}			// IFX_DONT_ACTIVATE_F_NOT_SET

	/**************** Notification Block ******************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if (IFX_ADD_F_NOT_SET(flags) && IFX_DELETE_F_NOT_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION(t_iid, changed_fcount,
					  array_changed_fvp, flags, IFX_Handler)
	}

	/***************** Epilog Block **********************/
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* manage Internet LED for change in Default WAN */
	sprintf(buf, "/etc/rc.d/invoke_internet_led %d", wan_index);
	system(buf);

#ifdef CONFIG_PACKAGE_NTPCLIENT
	memset(sVal, 0x00, sizeof(sVal));
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_TIME_SECTION,
			    TAG_TIME_SECTION "_" IFX_TIME_NTPENABLE, flags,
			    &outFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get NTP Enable Value !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}
	ntp_fEnable = atoi(sVal);
	if (ntp_fEnable == 1) {
		fd = popen("/etc/rc.d/init.d/ntpc", "r");
		if (fd == NULL) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		if (fd) {
			system
			    (" . /etc/rc.d/init.d/ntpc restart > /dev/null 2>&1");
		}
		pclose(fd);
	}
#endif
#ifdef CONFIG_FEATURE_IFX_VOIP

        ifx_get_index_from_cpe_id( FILE_RC_CONF,&wan_id.cpeId, &wan_index);
	if (ifx_set_voip_interface(wan_index, wan_type, flags)
	    != IFX_SUCCESS) {
	//	ifx_httpdError(wp, 400,
	//	       "Failed to configure WAN[%s] as the default VoIP interface !!",
	//	       pWAN_VOIP_Iface);
             ret = IFX_FAILURE;
             goto IFX_Handler;
	}
#endif

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_all_wan(...)
*	num_entries	==>	number of wan connections
*	pp_wancfg	==>	output pointer to array of wan connections WAN_CONN_CFG
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This API retrieves all WAN connections into array pp_wancfg.
			Also the number of WAN connections read will be returned in num_entries.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_all_wan(int32 * num_entries,
				     WAN_CONN_CFG ** pp_wancfg, uint32 flags)
{
	uint32 outFlag = IFX_F_DEFAULT;
	char8 buf[MAX_FILELINE_LEN], sIndexes[MAX_FILELINE_LEN];
	int32 count = 0, ret = IFX_SUCCESS, idx_count = 0,i = 0, j = 0;
	int32 wan_ipCount = 0, wan_pppCount = 0, wan_type = 0;
	WAN_CONN_CFG wan_cfg, *t_ptr = NULL;
	char8 secName[MAX_FILELINE_LEN];

	*num_entries = 0;

	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	NULL_TERMINATE(sIndexes, 0x00, sizeof(sIndexes));
	memset(&wan_cfg, 0x00, sizeof(wan_cfg));

	if (pp_wancfg == NULL)
        {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	for (j = 0; j < 2; j++)
	{
		if (j == 0) {
			sprintf(buf, "%s", "wan_ip_Count");
			sprintf(secName, "%s", TAG_WAN_IP);
		} else {
			sprintf(buf, "%s", "wan_ppp_Count");
			sprintf(secName, "%s", TAG_WAN_PPP);
		}
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, secName, buf, flags, &outFlag,
				    sIndexes)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		idx_count = atoi(sIndexes);
		if (j == 0) {
			wan_ipCount = idx_count;
		} else {
			wan_pppCount = idx_count;
		}
	}
	idx_count = *num_entries = wan_ipCount + wan_pppCount;

	if( *num_entries == 0)
	{
            ret = IFX_SUCCESS;
            *pp_wancfg = NULL;
            goto IFX_Handler;
	}

	t_ptr = (WAN_CONN_CFG *) IFX_MALLOC(idx_count *
		           			sizeof(WAN_CONN_CFG));

	if (t_ptr == NULL) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}


	for (j = 0; j < 2; j++)
	{

		if (j == 0)
		{
			wan_type = WAN_TYPE_IP;
			idx_count = wan_ipCount;
		}
		else
		{
			wan_type = WAN_TYPE_PPP;
			idx_count = wan_pppCount;
		}

		if(idx_count == 0)
		{
			continue;
		}

		for (i = 0; i < idx_count; i++)
		{
			/* if there is no wan object in wan_main section for this wanIdx exit */
			//if ((ret = mapi_get_wan_config(i, &wan_cfg,flags)) != IFX_SUCCESS)
	                memset(&wan_cfg, 0x00, sizeof(wan_cfg));
			wan_cfg.type = wan_type;
			if ((ret = mapi_get_wan_config(i, &wan_cfg,flags)) != IFX_SUCCESS)
                        {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}

			/* copy the wan_cfg into pp_wancfg */
			*(t_ptr + count) = wan_cfg;
			count++;
		}
	}
	*pp_wancfg = t_ptr;
	*num_entries = count;

      IFX_Handler:
	    if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(t_ptr)
		* num_entries = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_all_wan_atm_vcc_config(...)
*	num_entries	==>	number of wan connections
*	pp_wancfg	==>	output pointer to array of wan connections WAN_CONN_CFG
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads all the wan connections from rc.conf
			and returns them in the array pp_wancfg. Also the number of wan
  			connections read will be returned in num_entries.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_all_wan_atm_vcc_config(int32 * num_entries,
				     WAN_CONN_CFG ** pp_wancfg, uint32 flags)
{
	uint32 outFlag = IFX_F_DEFAULT;
	char8 buf[MAX_FILELINE_LEN], sIndexes[MAX_FILELINE_LEN];
	int32 count = 0, ret = IFX_SUCCESS, idx_count = 0, *idx_array =
	    NULL, i = 0, j = 0;
	WAN_CONN_CFG wan_cfg, *t_ptr = NULL;
	char8 secName[MAX_FILELINE_LEN];

	*num_entries = 0;

	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	NULL_TERMINATE(sIndexes, 0x00, sizeof(sIndexes));
	if (pp_wancfg == NULL)
        {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
                return ret;
	}

	for (j = 0; j < 2; j++) {
		if (j == 0) {
			sprintf(buf, "%s", "wan_ip_Count");
			sprintf(secName, "%s", TAG_WAN_IP);
		} else {
			sprintf(buf, "%s", "wan_ppp_Count");
			sprintf(secName, "%s", TAG_WAN_PPP);
		}
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, secName, buf, flags, &outFlag,
				    sIndexes)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		idx_count = atoi(sIndexes);

		t_ptr = (WAN_CONN_CFG *) IFX_MALLOC(idx_count *
		           			sizeof(WAN_CONN_CFG));

		if (t_ptr == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}

		*pp_wancfg = t_ptr;

		for (i = 0; i < idx_count; i++) {
			memset(&wan_cfg, 0x00, sizeof(wan_cfg));
			if (j == 0)
				wan_cfg.type = WAN_TYPE_IP;
			else
				wan_cfg.type = WAN_TYPE_PPP;

			/* if there is no wan object in wan_main section for this wanIdx exit */
			//if ((ret = mapi_get_wan_config(i, &wan_cfg,flags)) != IFX_SUCCESS)
			if ((ret = mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_ATM, flags)) != IFX_SUCCESS)
                        {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}

			/* copy the wan_cfg into pp_wancfg */
			*(*pp_wancfg + count) = wan_cfg;
			count++;
		}
	}
	*num_entries = count;

      IFX_Handler:
	IFX_MEM_FREE(idx_array)
	    if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*pp_wancfg)
		    * num_entries = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/* get_all_eth_config*/

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_all_wan_eth_config(...)
*	num_entries	==>	number of wan connections
*	pp_wancfg	==>	output pointer to array of wan connections WAN_CONN_CFG
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads all the ethernet wan connections from rc.conf
			and returns them in the array pp_wancfg. Also the number of wan
  			connections read will be returned in num_entries.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_all_wan_eth_config(int32 * num_entries, uint32 mode,
				 WAN_CONN_CFG ** pp_wancfg, uint32 flags)
{
	uint32 outFlag = IFX_F_DEFAULT;
	char8 buf[MAX_FILELINE_LEN], sIndexes[MAX_FILELINE_LEN];
	char8 retVal[MAX_FILELINE_LEN];
	int32 count = 0, ret = IFX_SUCCESS, idx_count = 0, i = 0;
	WAN_CONN_CFG wan_cfg, *t_ptr = NULL;
	char8 secName[32], SECTION_PREFIX[MAX_TAG_LEN];

	*num_entries = 0;
	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	NULL_TERMINATE(sIndexes, 0x00, sizeof(sIndexes));

	if (mode == WAN_TYPE_IP) {
		sprintf(buf, "%s", "wan_ip_Count");
		sprintf(secName, "%s", TAG_WAN_IP);
		sprintf(SECTION_PREFIX, "%s", PREFIX_WAN_IP);
	} else {
		sprintf(buf, "%s", "wan_ppp_Count");
		sprintf(secName, "%s", TAG_WAN_PPP);
		sprintf(SECTION_PREFIX, "%s", PREFIX_WAN_PPP);
	}

//IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, secName, buf, flags, &outFlag,
			    sIndexes)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
//IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	idx_count = atoi(sIndexes);

//IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	IFX_MEM_ALLOC(t_ptr, WAN_CONN_CFG *, idx_count, sizeof(WAN_CONN_CFG))
//IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	    if (t_ptr == NULL) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}


//IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	if (pp_wancfg == NULL || t_ptr == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	//      *num_entries += idx_count;

	*pp_wancfg = t_ptr;
	/*
	   sprintf(buf, "%s", "wan_ppp_Count");
	   sprintf(secName, "%s", TAG_WAN_PPP);

	   if((ret = ifx_GetObjData(FILE_RC_CONF, secName, buf, flags, &outFlag, sIndexes)) != IFX_SUCCESS)
	   {
	   #ifdef IFX_LOG_DEBUG
	   IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	   #endif
	   goto IFX_Handler;
	   }

	   idx_count = atoi(sIndexes);

	   IFX_MEM_ALLOC(t_ptr, WAN_CONN_CFG *, idx_count, sizeof(WAN_CONN_CFG))

	   if(t_ptr == NULL)
	   {
	   ret = IFX_FAILURE;
	   goto IFX_Handler;
	   }

	   *pp_wancfg = t_ptr;

	   if(pp_wancfg == NULL || *pp_wancfg == NULL)
	   {
	   #ifdef IFX_LOG_DEBUG
	   IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	   #endif
	   ret = IFX_FAILURE;
	   goto IFX_Handler;
	   }
	   *num_entries += idx_count;
	 */

//IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);

	for (i = 0; i < idx_count; i++) {
		memset(&wan_cfg, 0x00, sizeof(wan_cfg));
		wan_cfg.type = mode;

		sprintf(buf, "%s_%d_wanMode", SECTION_PREFIX, i);
		if ((ret =
		     ifx_GetObjDataOpt(FILE_RC_CONF, secName, buf, flags,
				       &outFlag, retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] ifx_GetObjDataOpt() Fail",
				__FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		if ((atoi(retVal) == WAN_MODE_ETH0)) {
			*num_entries += 1;
			if ((ret = mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_ETH0,flags)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] mapi_get_wan_config() Fail",
					__FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}
		}
		if ((atoi(retVal) == WAN_MODE_ETH1)) {
			*num_entries += 1;
			if ((ret = mapi_get_wan_config_for_mode(i, &wan_cfg,WAN_MODE_ETH1,flags)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] mapi_get_wan_config() Fail",
					__FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}
		}
		*(*pp_wancfg + count) = wan_cfg;
		count++;
	}

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(t_ptr)	
		IFX_MEM_FREE(*pp_wancfg)
		    * num_entries = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/* get_all_ptm_config*/

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_all_wan_ptm_config(...)
*	num_entries	==>	number of wan connections
*	pp_wancfg	==>	output pointer to array of wan connections WAN_CONN_CFG
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads all the ptm wan connections from rc.conf
			and returns them in the array pp_wancfg. Also the number of wan
  			connections read will be returned in num_entries.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_all_wan_ptm_config(int32 * num_entries, uint32 mode,
				 WAN_CONN_CFG ** pp_wancfg, uint32 flags)
{
	uint32 outFlag = IFX_F_DEFAULT;
	char8 buf[MAX_FILELINE_LEN], sIndexes[MAX_FILELINE_LEN];
	char8 retVal[MAX_FILELINE_LEN];
	int32 count = 0, ret = IFX_SUCCESS, idx_count = 0, i = 0;
	WAN_CONN_CFG wan_cfg, *t_ptr = NULL;
	char8 secName[32], SECTION_PREFIX[MAX_TAG_LEN];

	*num_entries = 0;
	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	NULL_TERMINATE(sIndexes, 0x00, sizeof(sIndexes));

	if (mode == WAN_TYPE_IP) {
		sprintf(buf, "%s", "wan_ip_Count");
		sprintf(secName, "%s", TAG_WAN_IP);
		sprintf(SECTION_PREFIX, "%s", PREFIX_WAN_IP);
	} else {
		sprintf(buf, "%s", "wan_ppp_Count");
		sprintf(secName, "%s", TAG_WAN_PPP);
		sprintf(SECTION_PREFIX, "%s", PREFIX_WAN_PPP);
	}

//IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, secName, buf, flags, &outFlag,
			    sIndexes)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
//IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	idx_count = atoi(sIndexes);

//IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	IFX_MEM_ALLOC(t_ptr, WAN_CONN_CFG *, idx_count, sizeof(WAN_CONN_CFG))
//IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	    if (t_ptr == NULL) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}


//IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	if (pp_wancfg == NULL || t_ptr == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	//      *num_entries += idx_count;

	*pp_wancfg = t_ptr;
	/*
	   sprintf(buf, "%s", "wan_ppp_Count");
	   sprintf(secName, "%s", TAG_WAN_PPP);

	   if((ret = ifx_GetObjData(FILE_RC_CONF, secName, buf, flags, &outFlag, sIndexes)) != IFX_SUCCESS)
	   {
	   #ifdef IFX_LOG_DEBUG
	   IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	   #endif
	   goto IFX_Handler;
	   }

	   idx_count = atoi(sIndexes);

	   IFX_MEM_ALLOC(t_ptr, WAN_CONN_CFG *, idx_count, sizeof(WAN_CONN_CFG))

	   if(t_ptr == NULL)
	   {
	   ret = IFX_FAILURE;
	   goto IFX_Handler;
	   }

	   *pp_wancfg = t_ptr;

	   if(pp_wancfg == NULL || *pp_wancfg == NULL)
	   {
	   #ifdef IFX_LOG_DEBUG
	   IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	   #endif
	   ret = IFX_FAILURE;
	   goto IFX_Handler;
	   }
	   *num_entries += idx_count;
	 */

//IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);

	for (i = 0; i < idx_count; i++) {
		memset(&wan_cfg, 0x00, sizeof(wan_cfg));
		wan_cfg.type = mode;

		sprintf(buf, "%s_%d_wanMode", SECTION_PREFIX, i);
		if ((ret =
		     ifx_GetObjDataOpt(FILE_RC_CONF, secName, buf, flags,
				       &outFlag, retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] ifx_GetObjDataOpt() Fail",
				__FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		if ((atoi(retVal) == WAN_MODE_PTM)) {
			*num_entries += 1;
			if ((ret = mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_PTM,flags)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] mapi_get_wan_config() Fail",__FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}
		}
		if ((atoi(retVal) == WAN_MODE_VDSL_PTM)) {
			*num_entries += 1;
			if ((ret = mapi_get_wan_config_for_mode(i, &wan_cfg,WAN_MODE_VDSL_PTM,flags)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] mapi_get_wan_config() Fail",__FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}
		}
		*(*pp_wancfg + count) = wan_cfg;
		count++;
	}

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(t_ptr)
		    * num_entries = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_wan_ip_config(...)
*	wanIdx		==>	input index of the wan ip connection for which configuration
*				has to be returned
*	wan_cfg		==>	output pointer to wan ip connection WAN_CFG
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads the wan ip connection configuration from rc.conf
  			for the input wan index wanIdx.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_wan_ip_config(int32 wanIdx, WAN_CONN_CFG * wan_conn_cfg,
			    uint32 flags)
{
	int32 ret = IFX_SUCCESS, i = 0;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 buf[MAX_FILELINE_LEN], retVal[MAX_FILELINE_LEN],
	    wan_section[MAX_NAME_LEN];
	char8 *dns_servers = NULL, *retv4Str = NULL, *retv6Str = NULL;
	char8 pcpeIdVal[8];

	NULL_TERMINATE(wan_section, 0x00, sizeof(wan_section));
	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	NULL_TERMINATE(retVal, 0x00, sizeof(retVal));

	if (wan_conn_cfg == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> No WAN Connection config specified!!\n\n",
		     __FUNCTION__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* initialize the cache for this instance */
	sprintf(buf, "%s_%d_", PREFIX_WAN_IP, wanIdx);
	if (ifx_GetObjDataOpt
	    (FILE_RC_CONF, TAG_WAN_IP, buf, IFX_F_INT_CACHE_INIT | flags, NULL,
	     NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance",
			__FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	sprintf(buf, "WanIP%d_IF_Info", wanIdx);
	if ((ret =
	     ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "bringup_time_secs", flags,
			    (IFX_OUT uint32 *) & outFlag,
			    retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve bringup_time_secs in WanIP%d_IF_Info",
			__FUNCTION__, __LINE__, wanIdx);
#endif
	} else {
		struct sysinfo info;
		sysinfo(&info);
		wan_conn_cfg->wancfg.ip.wan_cfg.uptime =
		    info.uptime - atol(retVal);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Retrieved bringup_time_secs in WanIP%d_IF_Info [%d]",
			__FUNCTION__, __LINE__, wanIdx, wan_conn_cfg->wancfg.ip.wan_cfg.uptime);
#endif
	}

	/* Return the static values of possible connection types */
	wan_conn_cfg->WAN_IP_CONN.possible_conn_types[0] =
	    WAN_IP_CONN_TYPE_UNCONFIGURED;
	wan_conn_cfg->WAN_IP_CONN.possible_conn_types[1] =
	    WAN_IP_CONN_TYPE_IP_ROUTED;
	wan_conn_cfg->WAN_IP_CONN.possible_conn_types[2] =
	    WAN_IP_CONN_TYPE_IP_BRIDGED;

	/* Hard coding Last connection error to none */
	wan_conn_cfg->WAN_IP_CONN.last_conn_error = WANIP_LAST_CONN_ERROR_NONE;

	sprintf(buf, "wanip_%d_connType", wanIdx);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_IP, buf, flags, &outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wan_conn_cfg->wancfg.ip.conn_type = atoi(retVal);

	sprintf(buf, "wanip_%d_addrType", wanIdx);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_IP, buf, flags, &outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wan_conn_cfg->wancfg.ip.addr_type = atoi(retVal);

	sprintf(buf, "wanip_%d_iface", wanIdx);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_IP, buf, flags, &outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve interface name",
			__FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	snprintf(wan_conn_cfg->wancfg.ip.wan_cfg.iface_name,MAX_IF_NAME, "%s", retVal);

	snprintf(wan_section, MAX_NAME_LEN,"WanIP%d_IF_Info", wanIdx);

	if (wan_conn_cfg->WAN_IP_CONN.addr_type == IP_TYPE_STATIC) {
		/*Derive the ipv4/v6 and wandns sections string */
		/*Check L3 proto. IPv4/IPv6/both and accordingly use ipv4cfg or ipv6cfg */
		/* get the ipv4/ipv6/dns substrings from the distinct pcpeId=value pair */
#if 0
		if (wan_conn_cfg->wancfg.ip.wan_cfg.l3_proto == L3PROTO_IPV4
		    || wan_conn_cfg->wancfg.ip.wan_cfg.l3_proto == L3PROTO_V4V6)
#endif
		{
			snprintf(pcpeIdVal, 8, "%d",
				wan_conn_cfg->WAN_IP_CONN.WAN_CONN.iid.cpeId.
				Id);
			ret =
			    ifx_ret_substr_from_distfield(FILE_RC_CONF,
							  TAG_WAN_IPV4CFG,
							  "pcpeId", pcpeIdVal,
							  &retv4Str);
			if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Unable to retrieve IPV4 CFG\n",
					__FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			sprintf(buf, "%s_ipAddr", retv4Str);

			if ((ret =
			     ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IPV4CFG, buf,
					    flags, &outFlag,
					    retVal)) != IFX_SUCCESS) {
				sprintf(retVal, "%s", "0.0.0.0");
				goto IFX_Handler;
			}
			wan_conn_cfg->wanv4.WAN_CONN_IPADDR.s_addr =
			    inet_addr(retVal);

			sprintf(buf, "%s_netmask", retv4Str);
			if ((ret =
			     ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IPV4CFG, buf,
					    flags, &outFlag,
					    retVal)) != IFX_SUCCESS) {
				sprintf(retVal, "%s", "0.0.0.0");
				goto IFX_Handler;
			}
			wan_conn_cfg->wanv4.WAN_CONN_IPMASK.s_addr =
			    inet_addr(retVal);

			sprintf(buf, "%s_gw", retv4Str);
			if ((ret =
			     ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IPV4CFG, buf,
					    flags, &outFlag,
					    retVal)) != IFX_SUCCESS) {
				sprintf(retVal, "%s", "0.0.0.0");
				goto IFX_Handler;
			}

			wan_conn_cfg->wanv4.ip_gw.s_addr = inet_addr(retVal);
		}

		if (wan_conn_cfg->wancfg.ip.wan_cfg.l3_proto == L3PROTO_IPV6
		    || wan_conn_cfg->wancfg.ip.wan_cfg.l3_proto == L3PROTO_V4V6)
		{
			ret =
			    ifx_ret_substr_from_distfield(FILE_RC_CONF,
							  TAG_WAN_IPV6CFG,
							  "pCpeId", pcpeIdVal,
							  &retv6Str);
			if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("[%s:%d] Unable to retrieve IPv6 CFG \n",
				     __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			/* Not handled IPv6 */
/*
			sprintf(buf, "%s_ipAddr",retv6Str);
			if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IPV6CFG, buf, flags, &outFlag, retVal)) != IFX_SUCCESS)
			{
				sprintf(retVal, "%s", "0.0.0.0");
				goto IFX_Handler;
			}
			wan_conn_cfg->wanv6.WAN_CONN_IPADDR.s_addr = inet_addr(retVal);

			sprintf(buf, "%s_ipMask",retv6Str);
			if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IPV6CFG, buf, flags, &outFlag, retVal)) != IFX_SUCCESS)
			{
				sprintf(retVal, "%s", "0.0.0.0");
				goto IFX_Handler;
			}
			wan_conn_cfg->wanv6.WAN_CONN_IPMASK.s_addr = inet_addr(retVal);

			sprintf(buf, "%s_gateway", retv6Str);
			if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IPV6CFG, buf, flags, &outFlag, retVal)) != IFX_SUCCESS)
			{
				sprintf(retVal, "%s", "0.0.0.0");
				goto IFX_Handler;
			}
			wan_conn_cfg->wanv6.ip_gw.s_addr = inet_addr(retVal);
*/
		}

	}
	else {
	        NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
		if((ifx_GetObjDataOpt(FILE_SYSTEM_STATUS, wan_section, "IP", flags, (IFX_OUT uint32 *) &outFlag, retVal)) != IFX_SUCCESS) {
	        #ifdef IFX_LOG_DEBUG
	        	IFX_DBG("\nIn Function [%s] : [IP] not found under [%s] in [%s] !!\n",__FUNCTION__, wan_section, FILE_SYSTEM_STATUS);
	        #endif
			sprintf(retVal, "%s", "0.0.0.0");
	        }
	
		wan_conn_cfg->wanv4.WAN_CONN_IPADDR.s_addr =inet_addr(retVal);
	
	 	NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
	        if((ifx_GetObjDataOpt(FILE_SYSTEM_STATUS, wan_section, "MASK", flags, (IFX_OUT uint32 *) &outFlag, retVal)) != IFX_SUCCESS) {
		#ifdef IFX_LOG_DEBUG
		        IFX_DBG("\nIn Function [%s] : [MASK] not found under [%s] in [%s] !!\n",__FUNCTION__, wan_section, FILE_SYSTEM_STATUS);
	        #endif
	                sprintf(retVal, "%s", "0.0.0.0");
	
		}
		wan_conn_cfg->wanv4.WAN_CONN_IPMASK.s_addr =inet_addr(retVal);
	}

// DNS
	sprintf(buf, "%s_%d_dnsoverride", PREFIX_WAN_IP, wanIdx);
	if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_IP, buf, flags, &outFlag,
			       retVal) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wan_conn_cfg->WAN_IP_CONN.WAN_CONN.wandns.WAN_CONN_DNS_OVERRIDE = atoi(retVal);
	if (wan_conn_cfg->WAN_IP_CONN.WAN_CONN.wandns.WAN_CONN_DNS_OVERRIDE == IFX_DISABLED) {

		/* read dns server values from rc.conf */
		sprintf(buf, "%s_%d_dnsservers", PREFIX_WAN_IP, wanIdx);
		if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_IP, buf, flags, &outFlag,
		       retVal) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("[%s:%d] Unable to retrieve DNS servers value",
			     __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		dns_servers = strtok(retVal, ",");
		i = 0;
		while (dns_servers != NULL) {
			wan_conn_cfg->WAN_IP_CONN.WAN_CONN.wandns.dns_servers[i].s_addr = inet_addr(dns_servers);
			dns_servers = strtok(NULL, ",");
			i++;
		}
	} else {
		sprintf(buf, "WanIP%d_DNS_SERVER", wanIdx);
		if (ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "DNS1", flags, &outFlag,
		       retVal) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve DNS1 value",
				__FUNCTION__, __LINE__);
#endif
		} else {
			if(strcmp(retVal, "0"))  /* If entry is not present then dns value is left with 0.0.0.0 */
				wan_conn_cfg->WAN_IP_CONN.WAN_CONN.wandns.dns_servers[0].s_addr =
				 inet_addr(retVal);
		}
		if (ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "DNS2", flags, &outFlag,
		       retVal) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve DNS2 value",
				__FUNCTION__, __LINE__);
#endif
		} else {
                        if(strcmp(retVal, "0"))
				wan_conn_cfg->WAN_IP_CONN.WAN_CONN.wandns.dns_servers[1].s_addr =
				    inet_addr(retVal);
		}
		if (ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "DNS3", flags, &outFlag,
		       retVal) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve DNS3 value",
				__FUNCTION__, __LINE__);
#endif
		} else {
                        if(strcmp(retVal, "0"))
				wan_conn_cfg->WAN_IP_CONN.WAN_CONN.wandns.dns_servers[2].s_addr =
				    inet_addr(retVal);
		}
	}
//End DNS

	/* get the status of the wan ip connection from running config file */
	if ((ret = ifx_GetObjDataOpt
	     (FILE_SYSTEM_STATUS, wan_section, "STATUS", flags, &outFlag,
	      retVal)) != IFX_SUCCESS) {
		/* if the status tag is not found in running config file then dont return error
		 * instead put the status as disconnected */
		wan_conn_cfg->WAN_IP_CONN.conn_status =
		    WAN_IP_CONN_STATUS_UNCONFIGURED;
	} else {
		if (!strcmp(retVal, "CONNECTING"))
			wan_conn_cfg->WAN_IP_CONN.conn_status =
			    WAN_IP_CONN_STATUS_CONNECTING;
		else if (!strcmp(retVal, "CONNECTED"))
			wan_conn_cfg->WAN_IP_CONN.conn_status =
			    WAN_IP_CONN_STATUS_CONNECTED;
		else if (!strcmp(retVal, "DISCONNECTING"))
			wan_conn_cfg->WAN_IP_CONN.conn_status =
			    WAN_IP_CONN_STATUS_DISCONNECTING;
		else if (!strcmp(retVal, "DISCONNECTED"))
			wan_conn_cfg->WAN_IP_CONN.conn_status =
			    WAN_IP_CONN_STATUS_DISCONNECTED;
		else if (!strcmp(retVal, "PENDING_DISCONNECT"))
			wan_conn_cfg->WAN_IP_CONN.conn_status =
			    WAN_IP_CONN_STATUS_PENDING_DISCONNECT;
		else if (!strcmp(retVal, "UNCONFIGURED"))
			wan_conn_cfg->WAN_IP_CONN.conn_status =
			    WAN_IP_CONN_STATUS_UNCONFIGURED;
	}

      IFX_Handler:
	if (wan_conn_cfg != NULL) {
		/* destroy the cache for this instance */
		sprintf(buf, "%s_%d_", PREFIX_WAN_IP, wanIdx);
		if (ifx_GetObjDataOpt
		    (FILE_RC_CONF, TAG_WAN_IP, buf, IFX_F_INT_CACHE_DESTROY,
		     NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("[%s:%d] Failed to destroy cache for this instance",
			     __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
		}
	}
        if (retv4Str != NULL)
           IFX_MEM_FREE( retv4Str );
        if (retv6Str != NULL)
           IFX_MEM_FREE( retv6Str );
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
#endif
	}
	return ret;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_wan_ppp_config(...)
*	wanIdx		==>	input index of the wan ppp connection for which configuration
*				has to be returned
*	wan_cfg		==>	output pointer to wan ppp connection WAN_CFG
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads the wan ppp connection configuration from rc.conf
  			for the input wan index wanIdx.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_wan_ppp_config(int32 wanIdx, WAN_CONN_CFG * wan_conn_cfg,
			     uint32 flags)
{
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN],
	    ppp_ifname[MAX_FILELINE_LEN], secName[MAX_FILELINE_LEN];
	int32 ret = IFX_SUCCESS, i = 0;
	FILE *fp = NULL;
	char8 retVal[MAX_FILELINE_LEN];
	uint32 outFlag = IFX_F_DEFAULT;
	char8 *dns_servers = NULL;
	NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
	/* initialize the cache for this instance */
	sprintf(buf, "%s_%d_", PREFIX_WAN_PPP, wanIdx);
	if (ifx_GetObjDataOpt
	    (FILE_RC_CONF, TAG_WAN_PPP, buf, IFX_F_INT_CACHE_INIT | flags, NULL,
	     NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance",
			__FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	sprintf(buf, "WanPPP%d_IF_Info", wanIdx);
	if ((ret =
	     ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "bringup_time_secs", flags,
			    &outFlag,
			    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve bringup_time_secs from WanPPP%d_IF_Info",
			__FUNCTION__, __LINE__, wanIdx);
#endif
	} else {
		struct sysinfo info;
		sysinfo(&info);
		wan_conn_cfg->wancfg.ppp.wan_cfg.uptime =
		    info.uptime - atol(sValue);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Retrieved bringup_time_secs in WanPPP%d_IF_Info [%d]",
			__FUNCTION__, __LINE__, wanIdx, wan_conn_cfg->wancfg.ppp.wan_cfg.uptime);
#endif
	}
	/* Return the static values of possible connection types */
	wan_conn_cfg->wancfg.ppp.possible_conn_types[0] =
	    WAN_PPP_CONN_TYPE_UNCONFIGURED;
	wan_conn_cfg->wancfg.ppp.possible_conn_types[1] =
	    WAN_PPP_CONN_TYPE_IP_ROUTED;
	wan_conn_cfg->wancfg.ppp.possible_conn_types[2] =
	    WAN_PPP_CONN_TYPE_PPPOE_BRIDGED;
	wan_conn_cfg->wancfg.ppp.possible_conn_types[3] =
	    WAN_PPP_CONN_TYPE_PPPOE_RELAY;

	sprintf(buf, "wanppp_%d_connType", wanIdx);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			       &outFlag,
			       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wan_conn_cfg->wancfg.ppp.conn_type = atoi(sValue);

	sprintf(buf, "wanppp_%d_connTrigger", wanIdx);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			       &outFlag,
			       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve connection trigger",
			__FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wan_conn_cfg->wancfg.ppp.WAN_CONN_TRIGGER = atoi(sValue);

	sprintf(buf, "wanppp_%d_encrProto", wanIdx);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			       &outFlag,
			       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	} else
		wan_conn_cfg->wancfg.ppp.encr_proto = atoi(sValue);

	sprintf(buf, "wanppp_%d_comprProto", wanIdx);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			       &outFlag,
			       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	} else
		wan_conn_cfg->wancfg.ppp.compr_proto = atoi(sValue);

	sprintf(buf, "wanppp_%d_authProto", wanIdx);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			       &outFlag,
			       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	} else
		wan_conn_cfg->wancfg.ppp.auth_proto = atoi(sValue);

	sprintf(buf, "wanppp_%d_maxMRU", wanIdx);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			       &outFlag,
			       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wan_conn_cfg->wancfg.ppp.max_mru_size = atoi(sValue);

	/* Hard coding Last connection error to none */
	wan_conn_cfg->wancfg.ppp.last_conn_error = WANPPP_LAST_CONN_ERROR_NONE;

	/* Get connection status from system_status file */
	/* check if there is a auth_fail file for this ppp interface, if so set status auth failure */
	sprintf(buf, "wanppp_%d_ifppp", wanIdx);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			       &outFlag,
			       ppp_ifname)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	snprintf(buf, MAX_FILELINE_LEN,"/tmp/%s_auth_fail", ppp_ifname);
	fp = fopen(buf, "r");
	if (fp != NULL) {
		/* Hack : update status as auth failure in system_status for this wan, as web reads the status directly */
		memset(buf, 0x00, sizeof(buf));
		memset(secName, 0x00, sizeof(secName));
		sprintf(buf, "%s", "STATUS=\"AUTHENTICATION FAILURE\"\n");
		sprintf(secName, "WanPPP%d_IF_Info", wanIdx);
		ifx_SetObjData(FILE_SYSTEM_STATUS, secName, IFX_F_MODIFY, 1,
			       buf);
		wan_conn_cfg->WAN_PPP_CONN.conn_status =
		    WAN_PPP_CONN_STATUS_AUTHENTICATING;
		wan_conn_cfg->WAN_PPP_CONN.last_conn_error =
		    WANPPP_LAST_CONN_ERROR_AUTHENTICATION_FAILURE;
	} else {
		sprintf(buf, "WanPPP%d_IF_Info", wanIdx);
		if ((ret =
		     ifx_GetObjDataOpt(FILE_SYSTEM_STATUS, buf, "STATUS", flags,
				       &outFlag,
				       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			wan_conn_cfg->WAN_PPP_CONN.conn_status =
			    WAN_PPP_CONN_STATUS_UNCONFIGURED;
		} else {
			if (!strcmp(sValue, "CONNECTING"))
				wan_conn_cfg->WAN_PPP_CONN.conn_status =
				    WAN_PPP_CONN_STATUS_CONNECTING;
			else if (!strcmp(sValue, "CONNECTED"))
				wan_conn_cfg->WAN_PPP_CONN.conn_status =
				    WAN_PPP_CONN_STATUS_CONNECTED;
			else if (!strcmp(sValue, "DISCONNECTING"))
				wan_conn_cfg->WAN_PPP_CONN.conn_status =
				    WAN_PPP_CONN_STATUS_DISCONNECTING;
			else if (!strcmp(sValue, "DISCONNECTED"))
				wan_conn_cfg->WAN_PPP_CONN.conn_status =
				    WAN_PPP_CONN_STATUS_DISCONNECTED;
			else if (!strcmp(sValue, "PENDING_DISCONNECT"))
				wan_conn_cfg->WAN_PPP_CONN.conn_status =
				    WAN_PPP_CONN_STATUS_PENDING_DISCONNECT;
			else if (!strcmp(sValue, "AUTHENTICATING"))
				wan_conn_cfg->WAN_PPP_CONN.conn_status =
				    WAN_PPP_CONN_STATUS_AUTHENTICATING;
			else if (!strcmp(sValue, "UNCONFIGURED"))
				wan_conn_cfg->WAN_PPP_CONN.conn_status =
				    WAN_PPP_CONN_STATUS_UNCONFIGURED;
		}
	}
	if (fp)
		fclose(fp);

	sprintf(buf, "WanPPP%d_PPP_Info", wanIdx);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_SYSTEM_STATUS, buf, "REMOTE_IP", flags,
			       &outFlag,
			       sValue)) != IFX_SUCCESS) {
		if (wan_conn_cfg->wancfg.ppp.conn_status ==
		    WAN_PPP_CONN_STATUS_CONNECTED) {
			/* If ip addess not found for status connected return an error !! */
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		}
	} else
	wan_conn_cfg->wancfg.ppp.remote_addr.s_addr = inet_addr(sValue);

	sprintf(buf, "WanPPP%d_IF_Info", wanIdx);

	NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
        if((ifx_GetObjDataOpt(FILE_SYSTEM_STATUS,buf, "IP", flags, (IFX_OUT uint32 *) &outFlag, retVal)) != IFX_SUCCESS) {
        #ifdef IFX_LOG_DEBUG
                IFX_DBG("\nIn Function [%s] : [IP] not found under [%s] in [%s] !!\n",__FUNCTION__, buf, FILE_SYSTEM_STATUS);
        #endif
                sprintf(retVal, "%s", "0.0.0.0");
        }

        wan_conn_cfg->wanv4.WAN_CONN_IPADDR.s_addr =inet_addr(retVal);

        NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
        if((ifx_GetObjDataOpt(FILE_SYSTEM_STATUS,buf, "MASK", flags, (IFX_OUT uint32 *) &outFlag, retVal)) != IFX_SUCCESS) {
        #ifdef IFX_LOG_DEBUG
                IFX_DBG("\nIn Function [%s] : [MASK] not found under [%s] in [%s] !!\n",__FUNCTION__, buf, FILE_SYSTEM_STATUS);
        #endif
                sprintf(retVal, "%s", "0.0.0.0");

        }
        wan_conn_cfg->wanv4.WAN_CONN_IPMASK.s_addr =inet_addr(retVal);

            sprintf(buf, "WanPPP%d_GATEWAY", wanIdx);

    NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
    if((ifx_GetObjDataOpt
        (FILE_SYSTEM_STATUS, buf, "ROUTER1", flags,
         (IFX_OUT uint32 *) & outFlag, retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\nIn Function [%s] : [IP] not found under [%s] in [%s] !!\n",
                __FUNCTION__, buf, FILE_SYSTEM_STATUS);
#endif
        sprintf(retVal, "%s", "0.0.0.0");
    }

    wan_conn_cfg->wancfg.ppp.defaultgw.s_addr = inet_addr(retVal);


    sprintf(buf, "WanPPP%d_PPP_Info", wanIdx);
    if((ifx_GetObjDataOpt
        (FILE_SYSTEM_STATUS, buf, "SESSIONID", flags,
         (IFX_OUT uint32 *) & outFlag, retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\nIn Function [%s] : [MASK] not found under [%s] in [%s] !!\n",
                __FUNCTION__, buf, FILE_SYSTEM_STATUS);
#endif

    }
    wan_conn_cfg->wancfg.ppp.sessionid = atoi(retVal);

     

	/* Get transport type based on if the connection is pppoa or pppoe */
	/* if ifnas is null and iftype is ppp then its pppoa, if ifnas is not null and iftype is ppp its pppoe */
	/* For now we are using only PPPoE or PPPoA, not the remaining two optins PPTP and L2TP */
	if (wan_conn_cfg->wancfg.ppp.wan_cfg.link_type == WAN_LINK_TYPE_PPPOE) {
		wan_conn_cfg->wancfg.ppp.transport_type =
		    WAN_PPP_TRANSPORT_TYPE_PPPOE;
	} else if (wan_conn_cfg->wancfg.ppp.wan_cfg.link_type == WAN_LINK_TYPE_PPPOATM) {
		wan_conn_cfg->wancfg.ppp.transport_type =
		    WAN_PPP_TRANSPORT_TYPE_PPPOA;
	}

	/* Get echo period and echo retry from where ?? */
	sprintf(buf, "wanppp_%d_ACName", wanIdx);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			       &outFlag,
			       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	snprintf(wan_conn_cfg->wancfg.ppp.pppoe_ac_name, MAX_CONN_NAME_LEN,
		 "%s", sValue);

	sprintf(buf, "wanppp_%d_serviceName", wanIdx);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			       &outFlag,
			       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	snprintf(wan_conn_cfg->wancfg.ppp.pppoe_service_name, MAX_CONN_NAME_LEN,
		 "%s", sValue);

	sprintf(buf, "wanppp_%d_user", wanIdx);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			       &outFlag,
			       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	snprintf(wan_conn_cfg->wancfg.ppp.ppp_user_name,
		 MAX_PPP_USER_NAME_PASSWD_LEN, "%s", sValue);

	sprintf(buf, "wanppp_%d_passwd", wanIdx);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			       &outFlag,
			       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	#if defined(CONFIG_FEATURE_LTQ_PARAMETER_ENCRYPTION)
        ltq_decrypt_par(buf,sValue,strlen(sValue), NULL);
	snprintf(wan_conn_cfg->wancfg.ppp.ppp_user_passwd,MAX_PPP_USER_NAME_PASSWD_LEN, "%s", buf);
	#else
	snprintf(wan_conn_cfg->wancfg.ppp.ppp_user_passwd,MAX_PPP_USER_NAME_PASSWD_LEN, "%s", sValue);
	#endif

	sprintf(buf, "wanppp_%d_bridgeEnable", wanIdx);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			       &outFlag,
			       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wan_conn_cfg->wancfg.ppp.bridge_enable = atoi(sValue);

	sprintf(buf, "wanppp_%d_echoPeriod", wanIdx);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			       &outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve echo period\n",
			__FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wan_conn_cfg->wancfg.ppp.ppp_lcp_echo_period = atoi(retVal);

	sprintf(buf, "wanppp_%d_echoRetry", wanIdx);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			       &outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve echo retry\n", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}
	wan_conn_cfg->wancfg.ppp.ppp_lcp_echo_retry = atoi(retVal);

	sprintf(buf, "wanppp_%d_currMRU", wanIdx);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			       &outFlag,
			       retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve current MRU\n",
			__FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wan_conn_cfg->wancfg.ppp.current_mru = atoi(retVal);

// DNS
	sprintf(buf, "%s_%d_dnsoverride", PREFIX_WAN_PPP, wanIdx);
	if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags, &outFlag,
			       retVal) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wan_conn_cfg->WAN_PPP_CONN.WAN_CONN.wandns.WAN_CONN_DNS_OVERRIDE = atoi(retVal);
	if (wan_conn_cfg->WAN_PPP_CONN.WAN_CONN.wandns.WAN_CONN_DNS_OVERRIDE == IFX_DISABLED) {

		/* read dns server values from rc.conf */
		sprintf(buf, "%s_%d_dnsservers", PREFIX_WAN_PPP, wanIdx);
		if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags, &outFlag,
		       retVal) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("[%s:%d] Unable to retrieve DNS servers value",
			     __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		dns_servers = strtok(retVal, ",");
		i = 0;
		while (dns_servers != NULL) {
			wan_conn_cfg->WAN_PPP_CONN.WAN_CONN.wandns.dns_servers[i].s_addr = inet_addr(dns_servers);
			dns_servers = strtok(NULL, ",");
			i++;
		}
	} else {
		sprintf(buf, "WanPPP%d_DNS_SERVER", wanIdx);
		if (ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "DNS1", flags, &outFlag,
		       retVal) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve DNS1 value",
				__FUNCTION__, __LINE__);
#endif
		} else {
			if(strcmp(retVal, "0")) /* If entry is not present then dns value is left with 0.0.0.0 */	
				wan_conn_cfg->WAN_PPP_CONN.WAN_CONN.wandns.dns_servers[0].s_addr =
				    inet_addr(retVal);
		}
		if (ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "DNS2", flags, &outFlag,
		       retVal) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve DNS2 value",
				__FUNCTION__, __LINE__);
#endif
		} else {
			if(strcmp(retVal, "0"))
				wan_conn_cfg->WAN_PPP_CONN.WAN_CONN.wandns.dns_servers[1].s_addr =
				    inet_addr(retVal);
		}
		if (ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "DNS3", flags, &outFlag,
		       retVal) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve DNS3 value",
				__FUNCTION__, __LINE__);
#endif
		} else {
			if(strcmp(retVal, "0"))
				wan_conn_cfg->WAN_PPP_CONN.WAN_CONN.wandns.dns_servers[2].s_addr =
				    inet_addr(retVal);
		}
	}
//End DNS

IFX_Handler:
	/* destroy the cache for this instance */
	sprintf(buf, "%s_%d_", PREFIX_WAN_PPP, wanIdx);
	if (ifx_GetObjDataOpt
	    (FILE_RC_CONF, TAG_WAN_PPP, buf, IFX_F_INT_CACHE_DESTROY, NULL,
	     NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to destroy cache for this instance",
			__FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
#endif
		return ret;
	} else
		return IFX_SUCCESS;
}

#ifdef CONFIG_PACKAGE_IFX_OAM
int32 ifx_get_all_wan_atmf5_loop_diagnostics(int32 * num_entries,
					     WAN_ATMF5_LOOP_DIAGNOSTICS **
					     atmf5_diagnostics, uint32 flags)
{
	uint32 outFlag = IFX_F_DEFAULT;
	int32 i = 0, count = 0, atmf5_count = 0, ret = IFX_SUCCESS;
	char8 command[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	WAN_ATMF5_LOOP_DIAGNOSTICS t_atmf5, *t_ptr = NULL;

	sprintf(command, "%s_Count", TAG_WAN_ATMF5);
	if (ifx_GetObjData
	    (FILE_RC_CONF, TAG_WAN_ATMF5, command, flags, &outFlag,
	     sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;
	}

	atmf5_count = 0;
	count = atoi(sValue);
	if (count < 0 || count > 32767)
		return IFX_FAILURE;

	t_ptr =
	    (WAN_ATMF5_LOOP_DIAGNOSTICS *) IFX_MALLOC(count *
						      sizeof
						      (WAN_ATMF5_LOOP_DIAGNOSTICS));

	if (t_ptr == NULL) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	*atmf5_diagnostics = t_ptr;

	for (i = 0; i < count; i++) {
		memset(&t_atmf5, 0x00, sizeof(t_atmf5));

		sprintf(command, "%s_%d_cpeId", PREFIX_WAN_ATMF5, i);
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_WAN_ATMF5, command, flags, &outFlag,
		     sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			continue;
		}
		t_atmf5.iid.cpeId.Id = atoi(sValue);

		if (ifx_get_atmf5_loop_diagnostics(&t_atmf5, flags) !=
		    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			continue;
		}

		/*      t_ptr = (WAN_ATMF5_LOOP_DIAGNOSTICS *)realloc(*atmf5_diagnostics,
		   (atmf5_count + 1) * sizeof(WAN_ATMF5_LOOP_DIAGNOSTICS));

		   if(t_ptr == NULL) {
		   ret = IFX_FAILURE;
		   goto IFX_Handler;
		   }

		   *atmf5_diagnostics = t_ptr;
		 */
		if (*atmf5_diagnostics == NULL) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		*(*atmf5_diagnostics + atmf5_count) = t_atmf5;
		atmf5_count++;
	}
	*num_entries = atmf5_count;

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		*num_entries = 0;
		IFX_MEM_FREE(*atmf5_diagnostics)
		    IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

int32 ifx_get_atmf5_loop_diagnostics(WAN_ATMF5_LOOP_DIAGNOSTICS *
				     atmf5_diagnostics, uint32 flags)
{
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	uint32 outFlag = IFX_F_DEFAULT;
	int32 dist_wan_index = -1, ret = IFX_SUCCESS;

	sprintf(atmf5_diagnostics->iid.cpeId.secName, "%s", TAG_WAN_ATMF5);
	sprintf(atmf5_diagnostics->iid.pcpeId.secName, "%s",
		TAG_WAN_CONN_DEVICE);

	if (ifx_get_index_from_cpe_id
	    (FILE_RC_CONF, &atmf5_diagnostics->iid.cpeId,
	     &dist_wan_index) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* initialize the cache for this instance */
	sprintf(buf, "%s_%d_", PREFIX_WAN_ATMF5, dist_wan_index);
	if (ifx_GetObjDataOpt
	    (FILE_RC_CONF, TAG_WAN_ATMF5, buf, IFX_F_INT_CACHE_INIT | flags,
	     NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance",
			__FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	sprintf(buf, "%s_%d_pcpeId", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5,
			       buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	} else
		atmf5_diagnostics->iid.pcpeId.Id = atoi(sValue);

	sprintf(buf, "%s_%d_fEnable", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5,
			       buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	} else
		atmf5_diagnostics->f_enable = atoi(sValue);

	sprintf(buf, "%s_%d_vpi", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5,
			       buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	} else
		atmf5_diagnostics->vpi = atoi(sValue);

	sprintf(buf, "%s_%d_vci", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5,
			       buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	} else
		atmf5_diagnostics->vci = atoi(sValue);

	sprintf(buf, "%s_%d_scope", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5,
			       buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	} else
		atmf5_diagnostics->scope = atoi(sValue);

	sprintf(buf, "%s_%d_diagnosticState", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5,
			       buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	} else
		atmf5_diagnostics->diagnostic_state = atoi(sValue);

	sprintf(buf, "%s_%d_timeout", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5,
			       buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	} else
		atmf5_diagnostics->ping_timeout = atoi(sValue);

	sprintf(buf, "%s_%d_pingCount", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5,
			       buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	} else
		atmf5_diagnostics->oam_pings = atoi(sValue);

	sprintf(buf, "%s_%d_loopback", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5,
			       buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	} else
		atmf5_diagnostics->loopback = atoi(sValue);

	sprintf(buf, "%s_%d_contCheck", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5,
			       buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	} else
		atmf5_diagnostics->cc_check = atoi(sValue);

	sprintf(buf, "%s_%d_contCheckOpt", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5,
			       buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	} else
		/* Map the continuity check option value from {1,2,3} to {0,1,2} as understood by the enums */
		atmf5_diagnostics->cc_check_opt = (atoi(sValue) - 1);

	sprintf(buf, "%s_%d_successCount", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5,
			       buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	} else
		atmf5_diagnostics->success_count = atoi(sValue);

	sprintf(buf, "%s_%d_failureCount", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5,
			       buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	} else
		atmf5_diagnostics->failure_count = atoi(sValue);

	sprintf(buf, "%s_%d_minRespTime", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5,
			       buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	} else
		atmf5_diagnostics->min_resp_time = atoi(sValue);

	sprintf(buf, "%s_%d_maxRespTime", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5,
			       buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	} else
		atmf5_diagnostics->max_resp_time = atoi(sValue);

	sprintf(buf, "%s_%d_avgRespTime", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5,
			       buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	} else
		atmf5_diagnostics->avg_resp_time = atoi(sValue);

      IFX_Handler:
	/* destroy the cache for this instance */
	sprintf(buf, "%s_%d_", PREFIX_WAN_ATMF5, dist_wan_index);
	if (ifx_GetObjDataOpt
	    (FILE_RC_CONF, TAG_WAN_ATMF5, buf, IFX_F_INT_CACHE_DESTROY, NULL,
	     NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to destory cache for this instance",
			__FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}
#endif

#ifndef CONFIG_PACKAGE_IFX_DSL_CPE_API
int32 ifx_get_wan_dsl_diagnostics(WAN_DSL_DIAGNOSTICS * Wan_Dsl_Diag,
				  uint32 flags)
{
	int32 i = 0, j = 0, ret = IFX_SUCCESS;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_DATA_LEN];
	char8 *read_ptr = NULL, *t_ptr = NULL, *pptr = NULL;

//       initialize the cache for this instance
	sprintf(buf, "%s_", PREFIX_DSL_DIAG);
	if (ifx_GetObjDataOpt
	    (FILE_RC_CONF, TAG_DSL_DIAG, buf, IFX_F_INT_CACHE_INIT | flags,
	     NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance",
			__FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	sprintf(buf, "%s_cpeId", PREFIX_DSL_DIAG);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag,
			       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->iid.cpeId.Id = atoi(sValue);

	sprintf(buf, "%s_pcpeId", PREFIX_DSL_DIAG);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag,
			       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->iid.pcpeId.Id = atoi(sValue);

	sprintf(Wan_Dsl_Diag->iid.cpeId.secName, "%s", TAG_DSL_DIAG);
	sprintf(Wan_Dsl_Diag->iid.cpeId.secName, "%s", TAG_WAN_DEVICE);

	sprintf(buf, "%s_fEnable", PREFIX_DSL_DIAG);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag,
			       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->f_enable = atoi(sValue);

	sprintf(buf, "%s_diagnosticState", PREFIX_DSL_DIAG);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag,
			       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->diagnostic_state = atoi(sValue);

	sprintf(buf, "%s_ACTPSDds", PREFIX_DSL_DIAG);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag,
			       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->ACTPSDds = atoi(sValue);

	sprintf(buf, "%s_ACTPSDus", PREFIX_DSL_DIAG);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag,
			       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->ACTPSDus = atoi(sValue);

	sprintf(buf, "%s_ACTATPds", PREFIX_DSL_DIAG);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag,
			       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->ACTATPds = atoi(sValue);

	sprintf(buf, "%s_ACTATPus", PREFIX_DSL_DIAG);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag,
			       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->ACTATPus = atoi(sValue);

	sprintf(buf, "%s_HLINSCds", PREFIX_DSL_DIAG);
	if ((ret =
	     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag,
			       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->HLINSCds = atoi(sValue);

	j = 0;
	for (i = 0; i < 32; i++) {
		sprintf(buf, "%s_HLINpsds_%d", PREFIX_DSL_DIAG, i);
		if ((ret =
		     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags,
				       &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		read_ptr = sValue;
		t_ptr = strtok_r(read_ptr, ",", &pptr);
		while (t_ptr != NULL) {
			Wan_Dsl_Diag->HLINpsds[j++] = atoi(t_ptr);
			t_ptr = strtok_r(NULL, ",", &pptr);
		}
	}

	j = 0;
	for (i = 0; i < 16; i++) {
		sprintf(buf, "%s_QLNpsds_%d", PREFIX_DSL_DIAG, i);
		if ((ret =
		     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags,
				       &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		read_ptr = sValue;
		t_ptr = strtok_r(read_ptr, ",", &pptr);
		while (t_ptr != NULL) {
			Wan_Dsl_Diag->QLNpsds[j++] = atoi(t_ptr);
			t_ptr = strtok_r(NULL, ",", &pptr);
		}
	}

	j = 0;
	for (i = 0; i < 16; i++) {
		sprintf(buf, "%s_SNRpsds_%d", PREFIX_DSL_DIAG, i);
		if ((ret =
		     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags,
				       &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		read_ptr = sValue;
		t_ptr = strtok_r(read_ptr, ",", &pptr);
		while (t_ptr != NULL) {
			Wan_Dsl_Diag->SNRpsds[j++] = atoi(t_ptr);
			t_ptr = strtok_r(NULL, ",", &pptr);
		}
	}

	j = 0;
	for (i = 0; i < 16; i++) {
		sprintf(buf, "%s_BITpsds_%d", PREFIX_DSL_DIAG, i);
		if ((ret =
		     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags,
				       &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		read_ptr = sValue;
		t_ptr = strtok_r(read_ptr, ",", &pptr);
		while (t_ptr != NULL) {
			Wan_Dsl_Diag->BITSpsds[j++] = atoi(t_ptr);
			t_ptr = strtok_r(NULL, ",", &pptr);
		}
	}

	j = 0;
	for (i = 0; i < 16; i++) {
		sprintf(buf, "%s_GAINpsds_%d", PREFIX_DSL_DIAG, i);
		if ((ret =
		     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags,
				       &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		read_ptr = sValue;
		t_ptr = strtok_r(read_ptr, ",", &pptr);
		while (t_ptr != NULL) {
			Wan_Dsl_Diag->GAINSpsds[j++] = atoi(t_ptr);
			t_ptr = strtok_r(NULL, ",", &pptr);
		}
	}

      IFX_Handler:
	/* destroy the cache for this instance */
	sprintf(buf, "%s_", PREFIX_DSL_DIAG);
	if (ifx_GetObjDataOpt
	    (FILE_RC_CONF, TAG_DSL_DIAG, buf, IFX_F_INT_CACHE_DESTROY, NULL,
	     NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to destroy cache for this instance",
			__FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}
#endif				//!CONFIG_PACKAGE_IFX_DSL_CPE_API

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_default_wan_if(...)
*    	iid		==>  output ifx_id structure which will have the cpeid and parent cpeid of
*				the default wan connection
*    	wan_index	==>  index of the default wan connection in wan_main section
*		flags	==>
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function returns the cpeID, pcpeId and wan_index for the default
  			WAN connection configured in the system
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_default_wan_if(IFX_ID * iid, int32 * wan_index,
			     char8 * wan_connName, uint32 flags)
{
	int32 ret = IFX_SUCCESS;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 *retStr = NULL;
	char8 *sIdx = NULL;
	//char8 wan_connName[MAX_FILELINE_LEN];
	char8 sCommand[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN],
	    def_iface[IFNAMSIZE];
	char8 secName[MAX_FILELINE_LEN];

	NULL_TERMINATE(wan_connName, 0x00, sizeof(wan_connName));
	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(def_iface, 0x00, sizeof(def_iface));

	/* read the rc.conf for default_wan_iface section */
	sprintf(sCommand, "%s", "default_wan_conn_connName");
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_DEFAULT_WAN, sCommand,
			    IFX_F_GET_ANY, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Default Wan ConnName not found", __FUNCTION__,
			__LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* get the conn_name and form the distinct connName=value pair */
	sprintf(wan_connName, "%s", sValue);

	ret =
	    ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_IP, "connName",
					  wan_connName, &retStr);
	if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(retStr)
		ret =
		    ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_PPP,
						  "connName", wan_connName,
						  &retStr);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve wan_X index",
				__FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		sprintf(secName, "%s", TAG_WAN_PPP);
	} else {
		sprintf(secName, "%s", TAG_WAN_IP);

	}

	/* get the wan index out of the return string which is of the format wan_{index} */
	sIdx = strrchr(retStr, '_') + 1;
	if (sIdx == NULL) {
		*wan_index = -1;
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve wan index", __FUNCTION__,
			__LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	} else
		*wan_index = atoi(sIdx);

	/* get the cpeid and parent cpeid of the default wan connection */
	sprintf(sCommand, "%s_cpeId", retStr);
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, secName, sCommand, IFX_F_GET_ANY,
			    &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve cpe Id", __FUNCTION__,
			__LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	iid->cpeId.Id = atoi(sValue);

	sprintf(sCommand, "%s_pcpeId", retStr);
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, secName, sCommand, IFX_F_GET_ANY,
			    &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve parent cpe Id",
			__FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	iid->pcpeId.Id = atoi(sValue);

	/* copy the object section and parent section names to ouput IFX_ID */
	snprintf(iid->cpeId.secName, strlen(secName) + 1, "%s", secName);
	snprintf(iid->pcpeId.secName, strlen(WAN_PARENT_SEC_TAG) + 1, "%s",
			WAN_PARENT_SEC_TAG);

      IFX_Handler:
	IFX_MEM_FREE(retStr)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;

}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_vcc_encap_type(...)
*		vc			==> 	specifies vpi and vci values for which the link type has to be modified
*		type		==>		specified the new vcc encap value
*    	flags		==>   flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
					This api takes the link type which has to be asscoiated with the vc having tha vpi/vci value pair
					it first checks if the vc is present, if present it does the updation and returns IFX_SUCCESS
  					otherwise returns IFX_FAILURE.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_vcc_encap_type(char *vpivci, VC_ENCAP type, uint32 flags)
{
	int32 ret = IFX_SUCCESS;
	char8 conf_buf[MAX_DATA_LEN], *retStr = NULL;

	NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));

	ret =
	    ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
					  "vcc", vpivci, &retStr);
	if (ret != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	sprintf(conf_buf, "%s_encap=\"%d\"\n", retStr, type);
	ret =
	    ifx_SetObjData(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, flags, 1,
			   conf_buf);
	if (ret != IFX_SUCCESS) {
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(retStr)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_all_wan_config(...)
*	num_entries	==>	number of wan connections
*	pp_wancfg	==>	output pointer to array of wan connections WAN_CONN_CFG
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads all the wan connections from rc.conf
			and returns them in the array pp_wancfg. Also the number of wan
  			connections read will be returned in num_entries.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_all_wan_config(int32 * num_entries, uint32 mode,
			     WAN_CONN_CFG ** pp_wancfg, uint32 flags)
{
	uint32 outFlag = IFX_F_DEFAULT;
	char8 buf[MAX_FILELINE_LEN], sIndexes[MAX_FILELINE_LEN];
	char8 retVal[MAX_FILELINE_LEN];
	int32 count = 0, ret = IFX_SUCCESS, idx_count = 0, i = 0;
	WAN_CONN_CFG wan_cfg, *t_ptr = NULL;
	char8 secName[32], SECTION_PREFIX[MAX_TAG_LEN];

	*num_entries = 0;
	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	NULL_TERMINATE(sIndexes, 0x00, sizeof(sIndexes));

	if (mode == WAN_TYPE_IP) {
		sprintf(buf, "%s", "wan_ip_Count");
		sprintf(secName, "%s", TAG_WAN_IP);
		sprintf(SECTION_PREFIX, "%s", PREFIX_WAN_IP);
	} else {
		sprintf(buf, "%s", "wan_ppp_Count");
		sprintf(secName, "%s", TAG_WAN_PPP);
		sprintf(SECTION_PREFIX, "%s", PREFIX_WAN_PPP);
	}

//IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, secName, buf, flags, &outFlag,
			    sIndexes)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
//IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	idx_count = atoi(sIndexes);
	*num_entries = idx_count;

//IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	IFX_MEM_ALLOC(t_ptr, WAN_CONN_CFG *, idx_count, sizeof(WAN_CONN_CFG))
//IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	    if (t_ptr == NULL) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}


//IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	if (pp_wancfg == NULL || t_ptr == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
                goto IFX_Handler;
	}
//              *num_entries += idx_count;

	*pp_wancfg = t_ptr;
//IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);

	for (i = 0; i < *num_entries; i++) {
		memset(&wan_cfg, 0x00, sizeof(wan_cfg));
		//if(j == 0)
		wan_cfg.type = mode;
		//else
		//      wan_cfg.type = WAN_TYPE_PPP;

#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] inside num entries loop", __FUNCTION__,
			__LINE__);
#endif
		sprintf(buf, "%s_%d_wanMode", SECTION_PREFIX, i);
		if ((ret =
		     ifx_GetObjDataOpt(FILE_RC_CONF, secName, buf, flags,
				       &outFlag, retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] ifx_GetObjDataOpt() Fail",
				__FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		if (atoi(retVal) == WAN_MODE_ATM) {
			if ((ret =
			     mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_ATM,
							flags)) !=
			    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("[%s:%d] mapi_get_wan_config() Fail",
				     __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}
		} else if (atoi(retVal) == WAN_MODE_VDSL_ATM) {
			if ((ret = mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_VDSL_ATM,flags)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] mapi_get_wan_config() Fail",__FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}
		} 
		else if (atoi(retVal) == WAN_MODE_PTM) {
			if ((ret =  mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_PTM,flags)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] mapi_get_wan_config() Fail",__FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}
		} 
		else if (atoi(retVal) == WAN_MODE_VDSL_PTM) {
			if ((ret =  mapi_get_wan_config_for_mode(i, &wan_cfg,WAN_MODE_VDSL_PTM,flags)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] mapi_get_wan_config() Fail",__FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}
		} 
		else if ((atoi(retVal) == WAN_MODE_ETH0)) {
			if ((ret = mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_ETH0,flags)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] mapi_get_wan_config() Fail",__FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}
		} 
		else if ((atoi(retVal) == WAN_MODE_ETH1)) {
			if ((ret = mapi_get_wan_config_for_mode(i, &wan_cfg,WAN_MODE_ETH1,flags)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] mapi_get_wan_config() Fail",__FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}
		} 
#ifdef CONFIG_FEATURE_WWAN_LTE_SUPPORT
		else if (atoi(retVal) == WAN_MODE_LTE){
				if ((ret = mapi_get_wan_config_for_mode(i,&wan_cfg, WAN_MODE_LTE, flags)) != IFX_SUCCESS){
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] mapi_get_wan_config() Fail",__FUNCTION__, __LINE__);
#endif
        	goto IFX_Handler;
				}
		}
#endif 

//IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);

		*(*pp_wancfg + count) = wan_cfg;
//                      if((*pp_wancfg + count)->type == WAN_TYPE_IP)
//                              IFX_DBG("[%s:%d] for wan[%d] l2iface [%s]", __FUNCTION__, __LINE__, count, (*pp_wancfg + count)->wancfg.ip.wan_cfg.l2iface_name);
//                      else
//                              IFX_DBG("[%s:%d] for wan[%d] l2iface [%s]", __FUNCTION__, __LINE__, count, (*pp_wancfg + count)->wancfg.ip.wan_cfg.l2iface_name);
		count++;
	}

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(t_ptr)
		IFX_MEM_FREE(*pp_wancfg)
		    * num_entries = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
int32 ifx_set_xdsl_phy_cfg(XDSL_PHY_CFG * pstXdslPhy)
{
	int32 ret = IFX_SUCCESS;
	char8 data_buff[MAX_DATA_LEN];

	if (pstXdslPhy == NULL) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	memset(data_buff, 0x00, sizeof(data_buff));

	sprintf(data_buff, "ADSL_MODE=\"%s\"\n", pstXdslPhy->sAdsl_Mode);
	sprintf(data_buff, "%sDSL_API_DEBUG=\"%s\"\n", data_buff,
		pstXdslPhy->sDsl_Api_Debug);
	sprintf(data_buff, "%sVDSL_MODE=\"%s\"\n", data_buff,
		pstXdslPhy->sVdsl_Mode);
	sprintf(data_buff, "%sxDSL_MODE=\"%s\"\n", data_buff,
		pstXdslPhy->sXdsl_Mode);
	sprintf(data_buff, "%sCNTL_MODE_ENA=\"%d\"\n", data_buff,
		pstXdslPhy->cntl_mode_ena);
	sprintf(data_buff, "%sCNTL_MODE=\"%d\"\n", data_buff,
		pstXdslPhy->cntl_mode);
	sprintf(data_buff, "%sPWR_MODE_ENA=\"%d\"\n", data_buff,
		pstXdslPhy->pwr_mode_ena);
	sprintf(data_buff, "%sPWR_MODE=\"%d\"\n", data_buff,
		pstXdslPhy->pwr_mode);
	ret =
	    ifx_SetObjData(FILE_RC_CONF, TAG_ADSL_PHY, IFX_F_MODIFY, 1,
			   data_buff);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] ifx_SetObjData() Fail", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, IFX_F_DEFAULT);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Update Persistent Storage Fail", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s] : returned failure!", __FUNCTION__);
#endif
	}
	return ret;
}
#endif

/**************************************************************
* Function    : ifx_set_wan_phy_cfg()
* Description : Sets the value of phycfg_tc and phycfg_mode under
*               wan_phy_cfg section in rc.conf
* Parameters  : WAN_PHY_CFG *pstWanPhy -> should be filled by caller.
*               contains value of PHY TC and PHY Mode
* Return      : IFX_SUCCESS on success, IFX_FAILURE on error
**************************************************************/

int32 ifx_set_wan_phy_cfg(WAN_PHY_CFG * pstWanPhy)
{
	int32 ret = IFX_SUCCESS;
	char8 data_buff[MAX_DATA_LEN];
	IFX_MAPI_QoS_QM qm;
	char8 sLine[256];

	if (pstWanPhy == NULL) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	memset(data_buff, 0x00, sizeof(data_buff));
	memset(&qm, 0x00, sizeof(qm));

	sprintf(data_buff, "%s_tc=\"%d\"\n", PREFIX_WAN_PHY_CFG,
		pstWanPhy->wan_tc);
	sprintf(data_buff, "%s%s_phymode=\"%d\"\n", data_buff,
		PREFIX_WAN_PHY_CFG, pstWanPhy->phy_mode);
	sprintf(data_buff, "%s%s_settc=\"%d\"\n", data_buff, PREFIX_WAN_PHY_CFG,
		pstWanPhy->set_wan_tc);
	sprintf(data_buff, "%s%s_setphymode=\"%d\"\n", data_buff,
		PREFIX_WAN_PHY_CFG, pstWanPhy->set_phy_mode);
#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
	sprintf(data_buff, "%s%s_ptmVlanMode=\"%d\"\n", data_buff,
		PREFIX_WAN_PHY_CFG, pstWanPhy->ptm_vlan_mode);
#endif
#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
#if !defined(PLATFORM_VR9)
	sprintf(data_buff, "%s%s_ethVlanMode=\"%d\"\n", data_buff,
		PREFIX_WAN_PHY_CFG, pstWanPhy->eth_vlan_mode);
#endif
#if !defined(PLATFORM_DANUBE)
	sprintf(data_buff, "%s%s_mii1ethVlanMode=\"%d\"\n", data_buff,
		PREFIX_WAN_PHY_CFG, pstWanPhy->eth_mii1_vlan_mode);
#endif
#endif
	sprintf(data_buff, "%s%s_tr69_encaprequested=\"%s\"\n", data_buff,
		PREFIX_WAN_PHY_CFG, pstWanPhy->tr69_encaprequested);
	ret =
	    ifx_SetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, IFX_F_DEFAULT, 1,
			   data_buff);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] ifx_SetObjData() Fail", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}
	ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_atmQmode", IFX_F_GET_ENA,
		       0, sLine);
	if (atoi(sLine) == IFX_MAPI_QoS_ATM_PVC_BASED) {

		if (pstWanPhy->phy_mode == WAN_PHY_MODE_ADSL2
		    && pstWanPhy->wan_tc == WAN_TC_ATM) {
			if ((ret =
			     ifx_mapi_get_qos_qm(&qm,
						 IFX_F_DEFAULT)) !=
			    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] queue config read failed",
					__FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}

			if (!strcmp(qm.qIf, "0/0")) {
				qm.status = IFX_DISABLED;
				qm.enable = IFX_DISABLED;
				if ((ret =
				     ifx_mapi_set_qos_qm(IFX_OP_MOD, &qm,
							 IFX_F_MODIFY |
							 IFX_F_DONT_ACTIVATE))
				    != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] queue config set failed",
					     __FUNCTION__, __LINE__);
#endif
					goto IFX_Handler;
				}
			}
		}
	}
	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, IFX_F_DEFAULT);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Update Persistent Storage Fail", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}
/*
    if(pstWanPhy->phy_mode == WAN_PHY_MODE_ADSL2)
        system("/usr/sbin/upgrade ethwan_set 0");
    else if(pstWanPhy->phy_mode == WAN_PHY_MODE_ETH_MII0)
        system("/usr/sbin/upgrade ethwan_set 1");
    else if (pstWanPhy->phy_mode == WAN_PHY_MODE_ETH_MII1)
        system("/usr/sbin/upgrade ethwan_set 2");
    else if (pstWanPhy->phy_mode == WAN_PHY_MODE_VDSL2)
        system("/usr/sbin/upgrade ethwan_set 3");
*/
      IFX_Handler:
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s] : returned failure!", __FUNCTION__);
#endif
	}
	return ret;
}

/**************************************************************
* Function    : ifx_get_wan_phy_cfg()
* Description : Gets the value of phycfg_tc and phycfg_mode under
*               wan_phy_cfg section in rc.conf
* Parameters  : WAN_PHY_CFG *pstWanPhy -> should be allocated by caller.
* Return      : IFX_SUCCESS on success, IFX_FAILURE on error
**************************************************************/
int32 ifx_get_wan_phy_cfg(WAN_PHY_CFG * pstWanPhy)
{
	int32 ret = IFX_SUCCESS;
	char8 sValue[MAX_FILELINE_LEN];
	char8 data_buff[MAX_DATA_LEN];
	uint32 outFlag = IFX_F_DEFAULT;

	if (pstWanPhy == NULL) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	memset(data_buff, 0x00, sizeof(data_buff));
	sprintf(data_buff, "%s_tc", PREFIX_WAN_PHY_CFG);
	ret =
	    ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, data_buff,
			   IFX_F_GET_ANY, &outFlag, sValue);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] wanphy_tc: Get Fail", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	pstWanPhy->wan_tc = atoi(sValue);
	memset(data_buff, 0x00, sizeof(data_buff));
	sprintf(data_buff, "%s_phymode", PREFIX_WAN_PHY_CFG);
	ret =
	    ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, data_buff,
			   IFX_F_GET_ANY, &outFlag, sValue);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] wanphy_phymode: Get Fail", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}
	pstWanPhy->phy_mode = atoi(sValue);

	memset(data_buff, 0x00, sizeof(data_buff));
	sprintf(data_buff, "%s_settc", PREFIX_WAN_PHY_CFG);
	ret =
	    ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, data_buff,
			   IFX_F_GET_ANY, &outFlag, sValue);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] wanphy_settc: Get Fail", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}
	pstWanPhy->set_wan_tc = atoi(sValue);
	memset(data_buff, 0x00, sizeof(data_buff));
	sprintf(data_buff, "%s_setphymode", PREFIX_WAN_PHY_CFG);
	ret =
	    ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, data_buff,
			   IFX_F_GET_ANY, &outFlag, sValue);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] wanphy_setphymode: Get Fail", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}
	pstWanPhy->set_phy_mode = atoi(sValue);

#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
#if !defined(PLATFORM_AMAZON_SE) && !defined(PLATFORM_VR9)
	memset(data_buff, 0x00, sizeof(data_buff));
	sprintf(data_buff, "%s_ethVlanMode", PREFIX_WAN_PHY_CFG);
	ret =
	    ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, data_buff,
			   IFX_F_GET_ANY, &outFlag, sValue);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	pstWanPhy->eth_vlan_mode = atoi(sValue);
#endif				// PLATFORM_AMAZON_SE && VR9
#if !defined(PLATFORM_AMAZON_SE) && !defined(PLATFORM_DANUBE)
	memset(data_buff, 0x00, sizeof(data_buff));
	sprintf(data_buff, "%s_mii1ethVlanMode", PREFIX_WAN_PHY_CFG);
	ret =
	    ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, data_buff,
			   IFX_F_GET_ANY, &outFlag, sValue);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	pstWanPhy->eth_mii1_vlan_mode = atoi(sValue);
#endif				// PLATFORM_AMAZON_SE && DANUBE
#endif				// CONFIG_FEATURE_ETH_WAN_SUPPORT

#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
	memset(data_buff, 0x00, sizeof(data_buff));
	sprintf(data_buff, "%s_ptmVlanMode", PREFIX_WAN_PHY_CFG);
	ret =
	    ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, data_buff,
			   IFX_F_GET_ANY, &outFlag, sValue);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	pstWanPhy->ptm_vlan_mode = atoi(sValue);
#endif

	memset(data_buff, 0x00, sizeof(data_buff));
	sprintf(data_buff, "%s_tr69_encaprequested", PREFIX_WAN_PHY_CFG);
	ret =
	    ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, data_buff,
			   IFX_F_GET_ANY, &outFlag, sValue);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	snprintf(pstWanPhy->tr69_encaprequested, MAX_FIELD_RANGE, "%s", sValue);

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s] : returned failure!", __FUNCTION__);
#endif
	}
	return ret;
}

/**************************************************************************************
* Function    : mapi_check_dependent_obj_exist_on_wan()
* Description : Validation function to deny deletion of WAN connection in case any of
*               dependent objects (virtual server, multicast, firewall packet filter, ipsec)
*		are present on WAN connection to be deleted.
* Parameters  : wan_conn_cfg -> WAN connection to be deleted.
* Return      : IFX_SUCCESS on success, other listed codes on error
**************************************************************************************/
int32 mapi_check_dependent_obj_exist_on_wan(WAN_CONN_CFG *wan_conn_cfg)
{
	char8	sIface[MAX_IF_NAME_LEN], buf[MAX_FILELINE_LEN], sconnName[MAX_CONN_NAME_LEN];
	char8	sVal[MAX_FILELINE_LEN], prefix[MAX_FILELINE_LEN], secName[MAX_FILELINE_LEN];
	int32 count = 0, i = 0, dist_wan_index = -1, ret = IFX_SUCCESS;
	IFX_MAPI_Firewall_PFRule *pfRules = NULL;
	IFX_IPSEC_TUNNEL *ipsec_rules = NULL;

	if (wan_conn_cfg->type == WAN_TYPE_IP) {
		sprintf(prefix, "%s", PREFIX_WAN_IP);
		sprintf(secName, "%s", TAG_WAN_IP);
	}
	else {
		sprintf(prefix, "%s", PREFIX_WAN_PPP);
		sprintf(secName, "%s", TAG_WAN_PPP);
	}

	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wan_conn_cfg->wancfg.ip.wan_cfg.iid.cpeId, dist_wan_index)
	sprintf(buf, "%s_%d_connName", prefix, dist_wan_index);
	if(GetObjData(FILE_RC_CONF, secName, buf, sconnName, IFX_F_GET_ANY) != IFX_SUCCESS) {

	}
	else {
		/* dont allow delete if any packet filter rule configuration stores this WAN connection name */
		if ((ret = ifx_get_wan_ifname_from_connName(sconnName, sIface,
			      wan_conn_cfg->type)) != IFX_SUCCESS) {
		}

		printf("[%s:%d] name [%s] ifce [%s] type [%d]\n", __FUNCTION__, __LINE__, sconnName, sIface, wan_conn_cfg->type);
		if (ifx_get_sec_count(TAG_NAT_VIRTUALSER, &count) == IFX_SUCCESS)  {
			for (i=0; i< count ; i++) {
				sprintf(buf, "nat_virtualser_%d_wanConnIf", i);
                                if (GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf, sVal, IFX_F_GET_ANY) == IFX_SUCCESS) {
                	        	if ( !gstrcmp(sVal, sconnName)) {
						return VS_FOUND_ON_WAN_CONN;
					}
	                	}
			}
		}

#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
		GetObjData(FILE_RC_CONF, TAG_MULTICAST, "mcast_upstream_wan", sVal, IFX_F_GET_ANY);
		if ( strstr(sVal, sconnName) != NULL ) {
			return MCAST_FOUND_ON_WAN_CONN;	
		}
#endif

		count = 0;
		if(ifx_mapi_get_firewall_pfrules(&count, &pfRules, IFX_F_GET_ANY) != IFX_SUCCESS) {
	
		}
		else {
			for (i=0; i < count; i++) {
				if( (strcmp((pfRules + i)->oif, sIface) == 0) || (strcmp((pfRules + i)->iif, sIface) == 0) ) {
					IFX_MEM_FREE(pfRules)
					return FW_PF_FOUND_ON_WAN_CONN;
				}
			}
			IFX_MEM_FREE(pfRules)
		}
	
		/* dont allow delete if any ipsec rule configuration stores this WAN connection name */
		count = 0;
		if(ifx_get_all_ipsec_tunnel_entries(&count, &ipsec_rules, IFX_F_GET_ANY) != IFX_SUCCESS) {
	
		}
		else {
			for (i=0; i < count; i++) {
				if( strcmp((ipsec_rules + i)->wan_conn_if, sconnName) == 0) {
					IFX_MEM_FREE(ipsec_rules)
					return IPSEC_FOUND_ON_WAN_CONN;	
				}
			}
			IFX_MEM_FREE(ipsec_rules)
		}
	}

IFX_Handler:
	return ret;
}

/**************************************************************************************
* Function    : ifx_mapi_set_wan_config()
* Description : Wrapper mapi called from adaptation. Based on wan mode it calls
*               the appropriate internal set funciton to set wan config info in rc.conf
* Parameters  : operation -> specifies add/del/modify
*               flags     -> affect the kind of validation on the parameters
*               wan_conn_cfg -> contains the values to be set
* Return      : IFX_SUCCESS on success, IFX_FAILURE on error
**************************************************************************************/
int32 ifx_mapi_set_wan_config(int32 operation, WAN_CONN_CFG * wan_conn_cfg,
			      uint32 flags)
{
	int mode_wan = 0;
	IFX_ID def_wan_iid;
	int ret = IFX_SUCCESS, owner = 0;
	char8 buf[MAX_FILELINE_LEN], *retype = NULL, *retVal1 = NULL;
	char_t pNewId[MAX_FILELINE_LEN];
	int32 outFlag = IFX_F_DEFAULT, dist_wan_index = -1;
	uint32 newflags = IFX_F_DEFAULT;
#ifndef CONFIG_FEATURE_DUAL_WAN_SUPPORT /* TBD */
	//int32 nWAN_IDX = 0;
	// char8 wan_connName[MAX_FILELINE_LEN];
	// char8 passed_connName[MAX_FILELINE_LEN];
#endif // CONFIG_FEATURE_DUAL_WAN_SUPPORT

	IFX_VALIDATE_PTR(wan_conn_cfg)

	memset(&def_wan_iid, 0x00, sizeof(def_wan_iid));

	sprintf(pNewId, "%d", wan_conn_cfg->wancfg.ip.wan_cfg.iid.cpeId.Id);
	if (wan_conn_cfg->type == WAN_TYPE_IP)
	{
		mode_wan = wan_conn_cfg->WAN_IP_CONN.wan_cfg.wan_mode.mode;
		owner = wan_conn_cfg->WAN_IP_CONN.wan_cfg.iid.config_owner;
	}
	else if (wan_conn_cfg->type == WAN_TYPE_PPP)
	{
		mode_wan = wan_conn_cfg->WAN_PPP_CONN.wan_cfg.wan_mode.mode;
		owner = wan_conn_cfg->WAN_PPP_CONN.wan_cfg.iid.config_owner;
	}

#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
	WAN_MODE wanMode = WAN_MODE_ATM;
	WAN_PHY_CFG pstWanPhy;
	ifx_get_wan_phy_cfg(&pstWanPhy);
	wanMode = compute_wan_mode(pstWanPhy.phy_mode, pstWanPhy.wan_tc);
	if(owner != IFX_WEB && wanMode == mode_wan) {
		IFX_DBG("[%s:%d] Disabling auto-detect for WAN configuration from entity [%d]", __FUNCTION__, __LINE__, owner);
		if(is_auto_detect_enabled(wanMode) == IFX_ENABLED) {
			mapi_autodetect_disable_for_wanmode(wanMode);
	
			/* Disable autodetect parameters of this entry */
			if (wan_conn_cfg->type == WAN_TYPE_IP)
				wan_conn_cfg->WAN_IP_CONN.wan_cfg.autodetect = IFX_DISABLED;
			else if (wan_conn_cfg->type == WAN_TYPE_PPP)
				wan_conn_cfg->WAN_PPP_CONN.wan_cfg.autodetect = IFX_DISABLED;
		}
	}
#endif

	if (wan_conn_cfg->type == WAN_TYPE_IP) {
	 if (operation == IFX_OP_MOD || operation == IFX_OP_DEL) {
	 	if ((ret = ifx_ret_substr_from_distfield(FILE_RC_CONF,TAG_WAN_IP,"cpeId",pNewId, &retype)) !=IFX_SUCCESS) {
	 			//ifx_httpdError("cpeId doesn't exist!\n");
	 	}
	 	else {
	 			sprintf(buf, "%s_addrType", retype);
	 			if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags,(IFX_OUT uint32 *) & outFlag, retype)) != IFX_SUCCESS) {
	 			}
	 	}
	 	if ((ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_IPV4,"pcpeId", pNewId, &retVal1)) !=IFX_SUCCESS) {
	 		//ifx_httpdError("cpeId doesn't exist!\n");
	 	}
	 	else {
	 		sprintf(buf, "%s_cpeId", retVal1);
	 		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IPV4, buf, flags,(IFX_OUT uint32 *) & outFlag, retVal1)) != IFX_SUCCESS) {
	 		}
	 	}
	 }
	}
	else {
		if (operation == IFX_OP_MOD || operation == IFX_OP_DEL) {
			if ((ret = ifx_ret_substr_from_distfield(FILE_RC_CONF,TAG_WAN_PPP,"cpeId",pNewId, &retype)) !=IFX_SUCCESS) {
				//ifx_httpdError("cpeId doesn't exist!\n");
			}
			else {
				sprintf(buf, "%s_addrType", retype);
				if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,(IFX_OUT uint32 *) & outFlag, retype)) != IFX_SUCCESS) {
				}
			}
			if ((ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_IPV4,"pcpeId", pNewId, &retVal1)) !=IFX_SUCCESS) {
				//ifx_httpdError("cpeId doesn't exist!\n");
			}
			else {
				sprintf(buf, "%s_cpeId", retVal1);
				if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IPV4, buf, flags,(IFX_OUT uint32 *) & outFlag, retVal1)) != IFX_SUCCESS) {
				}
			}
		}
	}

	/* for Static WAN connections,
		 1. call ifx_set_wan_ipv4_config before calling ifx_set_wan_config or ifx_set_wan_config or ifx_set_wan_config for case of delete operation
		 2. call ifx_set_wan_ipv4_config after calling ifx_set_wan_config or ifx_set_wan_config or ifx_set_wan_config for case of add operation */
	if (operation == IFX_OP_DEL && atoi(retype) == IP_TYPE_STATIC){

		/* Fill pcpeId compulsorily */
		wan_conn_cfg->wanv4.iid.cpeId.Id = atoi(retVal1);
		wan_conn_cfg->wanv4.iid.pcpeId.Id =
		    wan_conn_cfg->wancfg.ip.wan_cfg.iid.cpeId.Id;
		ret =
		    ifx_set_wan_ipv4_config(operation, &wan_conn_cfg->wanv4,
					    &wan_conn_cfg->wanv6, flags);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Set wan Fail", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
	}

	/* For Static IP conn, we do sys config in ifx_set_wan_ipv4_config API, so no need to do any sys config here */
	if (mode_wan == WAN_MODE_ATM || mode_wan == WAN_MODE_VDSL_ATM || mode_wan  == WAN_MODE_PTM || mode_wan == WAN_MODE_VDSL_PTM || mode_wan == WAN_MODE_ETH0 || mode_wan == WAN_MODE_ETH1) {
		if (wan_conn_cfg->wancfg.ip.addr_type == IP_TYPE_STATIC && operation != IFX_OP_MOD) {
			if(wan_conn_cfg->type == WAN_TYPE_IP) {
				ret =
				ifx_set_wan_ip_config(operation, -1, &wan_conn_cfg->WAN_IP_CONN,
											flags | IFX_F_INT_DONT_CONFIGURE | IFX_F_INT_DONT_START_SERVICES);
			}
			else {
				ret =
				ifx_set_wan_ppp_config(operation, -1, &wan_conn_cfg->WAN_PPP_CONN,
											flags | IFX_F_INT_DONT_CONFIGURE | IFX_F_INT_DONT_START_SERVICES);
			}
		}
		else {
			if(wan_conn_cfg->type == WAN_TYPE_IP) {
				ret =
				ifx_set_wan_ip_config(operation, -1, &wan_conn_cfg->WAN_IP_CONN,
											flags | IFX_F_INT_DONT_START_SERVICES);
			}
			else {
				ret =
				ifx_set_wan_ppp_config(operation, -1, &wan_conn_cfg->WAN_PPP_CONN,
											flags | IFX_F_INT_DONT_START_SERVICES);
			}
		}
	}

	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Set wan Fail", __FUNCTION__, __LINE__);
#endif
	}
	else {
		if (operation == IFX_OP_MOD || operation == IFX_OP_ADD) {
			if ((operation == IFX_OP_ADD && wan_conn_cfg->wancfg.ip.addr_type == IP_TYPE_STATIC) || ((operation == IFX_OP_MOD) && (wan_conn_cfg->wancfg.ip.addr_type == IP_TYPE_STATIC) && (atoi(retype) != IP_TYPE_STATIC))) {
				/* Fill pcpeId compulsorily */
				IFX_DBG("[%s:%d] cpeId [%d:%d]", __FUNCTION__,
					__LINE__,
					wan_conn_cfg->wanv4.iid.pcpeId.Id,
					wan_conn_cfg->wancfg.ip.wan_cfg.iid.
					cpeId.Id);
				wan_conn_cfg->wanv4.iid.pcpeId.Id = wan_conn_cfg->wancfg.ip.wan_cfg.iid.cpeId.Id;
#ifdef CONFIG_PACKAGE_IFX_DEVM
				if((operation == IFX_OP_MOD) && (wan_conn_cfg->wancfg.ip.addr_type == IP_TYPE_STATIC) && (atoi(retype) != IP_TYPE_STATIC))
				{
				ret = IFX_GetTr69IdFromCpeId((IFX_Id *)&wan_conn_cfg->wancfg.ip.wan_cfg.iid);
				sprintf(wan_conn_cfg->wanv4.iid.tr69Id, "%s", wan_conn_cfg->wancfg.ip.wan_cfg.iid.tr69Id);
				}
				else
#endif 
				sprintf(wan_conn_cfg->wanv4.iid.tr69Id, "%s",
					wan_conn_cfg->wancfg.ip.wan_cfg.iid.
					tr69Id);
				
                                operation = IFX_OP_ADD;
				newflags = (~0) ^ IFX_F_MODIFY;
				flags = flags & newflags;
                                flags |= IFX_F_INT_ADD;

				ret =
				    ifx_set_wan_ipv4_config(operation,
							    &wan_conn_cfg->
							    wanv4, &wan_conn_cfg->wanv6, flags | IFX_F_INT_DONT_START_SERVICES);
				if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] Set wan Fail",
						__FUNCTION__, __LINE__);
#endif
					goto IFX_Handler;
				}
			}
			if ((operation == IFX_OP_MOD) && (wan_conn_cfg->wancfg.ip.addr_type == IP_TYPE_STATIC) && (atoi(retype) == IP_TYPE_STATIC))
			{
				if ((ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_IPV4,"pcpeId", pNewId, &retVal1)) !=IFX_SUCCESS) {
					//ifx_httpdError("cpeId doesn't exist!\n");
				}
				else {
					sprintf(buf, "%s_cpeId", retVal1);
					if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IPV4, buf, flags,(IFX_OUT uint32 *) & outFlag, retVal1)) != IFX_SUCCESS) {
					}
				}
				wan_conn_cfg->wanv4.iid.cpeId.Id = atoi(retVal1);
				wan_conn_cfg->wanv4.iid.pcpeId.Id = wan_conn_cfg->wancfg.ip.wan_cfg.iid.cpeId.Id;
				sprintf(wan_conn_cfg->wanv4.iid.tr69Id, "%s",wan_conn_cfg->wancfg.ip.wan_cfg.iid.tr69Id);
				ret = ifx_set_wan_ipv4_config(operation,&wan_conn_cfg->wanv4, &wan_conn_cfg->wanv6, flags | IFX_F_INT_DONT_START_SERVICES);
				if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] Set wan Fail",
							__FUNCTION__, __LINE__);
#endif
					goto IFX_Handler;
				}
			}
			if ((operation == IFX_OP_MOD) && (wan_conn_cfg->wancfg.ip.addr_type != IP_TYPE_STATIC) && (atoi(retype) == IP_TYPE_STATIC))
			{
				operation = IFX_OP_DEL;
				newflags = (~0) ^ IFX_F_MODIFY;
				flags = flags & newflags;
				flags |= IFX_F_DELETE;
				if ((ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_IPV4,"pcpeId", pNewId, &retVal1)) !=IFX_SUCCESS) {
					//ifx_httpdError("cpeId doesn't exist!\n");
				}
				else {
					sprintf(buf, "%s_cpeId", retVal1);
					if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IPV4, buf, flags,(IFX_OUT uint32 *) & outFlag, retVal1)) != IFX_SUCCESS) {
					}
				}
				wan_conn_cfg->wanv4.iid.cpeId.Id = atoi(retVal1);
				wan_conn_cfg->wanv4.iid.pcpeId.Id = wan_conn_cfg->wancfg.ip.wan_cfg.iid.cpeId.Id;
				sprintf(wan_conn_cfg->wanv4.iid.tr69Id, "%s",wan_conn_cfg->wancfg.ip.wan_cfg.iid.tr69Id);
				ret = ifx_set_wan_ipv4_config(operation,&wan_conn_cfg->wanv4, &wan_conn_cfg->wanv6, flags | IFX_F_INT_DONT_CONFIGURE);
				if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] Set wan Fail",
							__FUNCTION__, __LINE__);
#endif
					goto IFX_Handler;
				}
			}

			newflags = (~0) ^ IFX_F_INT_ADD;
			flags = flags & newflags;
			flags |= IFX_F_MODIFY;
			if(wan_conn_cfg->type == WAN_TYPE_IP) {
				if (wan_conn_cfg->wancfg.ip.wan_cfg.def_wan == 1) {
					//flags = flags | IFX_PER_WAN_DEFAULT_WAN;
					memcpy(&def_wan_iid, &wan_conn_cfg->wancfg.ip.wan_cfg.iid, sizeof(wan_conn_cfg->wancfg.ip.wan_cfg.iid));
					ret = ifx_set_default_wan_if(&def_wan_iid, wan_conn_cfg->type, flags | IFX_F_INT_DONT_START_SERVICES);
				}
			}
			else if(wan_conn_cfg->type == WAN_TYPE_PPP) {
				if (wan_conn_cfg->wancfg.ppp.wan_cfg.def_wan == 1) {
					//v reserved for future IFX_PER_WAN_DEFAULT_WAN
					//flags = flags | IFX_PER_WAN_DEFAULT_WAN;
					memcpy(&def_wan_iid, &wan_conn_cfg->wancfg.ppp.wan_cfg.iid, sizeof(wan_conn_cfg->wancfg.ppp.wan_cfg.iid));
					ret =	ifx_set_default_wan_if(&def_wan_iid, wan_conn_cfg->type, flags | IFX_F_INT_DONT_START_SERVICES);
				}
			}

			if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
					("\n\n In Function [%s][%d] : ifx_set_default_wan_if !!\n\n",
					 __FUNCTION__, __LINE__);
#endif
			}


#ifndef HOSTENV
		/* If IFX_F_INT_DONT_START_SERVICES is not set then none of WAN MAPI above
		 * would have started WAN services. Handle the same here.
		 * 1. WAN IP/PPP connection itself
		 * 2. RIPd and RIPng
		 * 3. default route and VoIP configuration would be taken care of in services start script from 1 above
		 */
		if(IFX_INT_DONT_START_SERVICES_F_NOT_SET(flags)
			&& IFX_DEACTIVATE_F_NOT_SET(flags)
			&& IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)
			&& IFX_DEACTIVATE_F_NOT_SET(flags)) {

			/* Retrieve index from rc.conf */
			if(wan_conn_cfg->type == WAN_TYPE_IP) {
				IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wan_conn_cfg->wancfg.ip.wan_cfg.iid.cpeId, dist_wan_index)

				sprintf(buf, "%s %d", SERVICE_WANIP_START, dist_wan_index);
			}
			else if(wan_conn_cfg->type == WAN_TYPE_PPP) {
				IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wan_conn_cfg->wancfg.ppp.wan_cfg.iid.cpeId, dist_wan_index)

				sprintf(buf, "%s %d", SERVICE_WANPPP_START, dist_wan_index);
			}
			
			ret = system(buf);
			ret = IFX_SUCCESS;

			ret = system(SERVICE_RIPD_RESTART);

			ret = system(SERVICE_RIPNGD_START);

		}
#endif
		}

	}

IFX_Handler:
IFX_MEM_FREE(retVal1);
IFX_MEM_FREE(retype);
return ret;
}

/**************************************************************************************
* Function    : default_wan_cfg_get_for_wan_mode()
* Description : Get default WAN instance details for the passed WAN mode
* Parameters  : def_wan_cfg_t -> default WAN instance structure
*               wan_mode	-> WAN mode for which default WAN needs to be found
* Return      : IFX_SUCCESS on success, IFX_FAILURE on error
**************************************************************************************/
int32 default_wan_cfg_get_for_wan_mode(def_wan_cfg_t * def_wan_cfg,
				       int32 wan_mode)
{

	int32 ret = IFX_SUCCESS, outFlag = IFX_F_DEFAULT;

	char8 sValue[MAX_NAME_SIZE], buf[MAX_FILELINE_LEN];

	memset(def_wan_cfg, 0, sizeof(def_wan_cfg_t));

	sprintf(buf, "%s_%d", PREFIX_DEFAULT_WAN, wan_mode);
	if (ifx_GetObjDataOpt
	    (FILE_RC_CONF, TAG_DEF_WAN_FUSED, buf, IFX_F_INT_CACHE_INIT, NULL,
	     NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance",
			__FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	inline char8 *read_file_cache(char *attr) {
		NULL_TERMINATE(sValue, 0, MAX_NAME_SIZE);
		sprintf(buf, "%s_%d_%s", PREFIX_DEFAULT_WAN, wan_mode, attr);
		if ((ret =
		     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DEF_WAN_FUSED, buf, 0,
				       (IFX_OUT uint32 *) & outFlag,
				       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve %s", __FUNCTION__,
				__LINE__, buf);
#endif
			ret = IFX_FAILURE;
			return NULL;
		}
		ret = IFX_SUCCESS;
		return sValue;
	}

	if (read_file_cache("conn_cpeId"))
		def_wan_cfg->iid.cpeId.Id = atoi(sValue);
	else
		goto IFX_Handler;

	if (read_file_cache("conn_pcpeId"))
		def_wan_cfg->iid.pcpeId.Id = atoi(sValue);
	else
		goto IFX_Handler;

	if (read_file_cache("conn_connName"))
		STRNCPY(def_wan_cfg->conn_name, sValue,MAX_CONN_NAME_LEN-1);
	else
		goto IFX_Handler;

	if (read_file_cache("conn_confconnName"))
		strcpy(def_wan_cfg->conf_conn_name, sValue);
	else
		goto IFX_Handler;

	if (read_file_cache("conn_iface"))
		STRNCPY(def_wan_cfg->iface, sValue,IFNAMSIZE-1);
	else
		goto IFX_Handler;

IFX_Handler:
	sprintf(buf, "%s_%d", PREFIX_DEFAULT_WAN, wan_mode);
	if(ifx_GetObjDataOpt
           (FILE_RC_CONF, TAG_DEF_WAN_FUSED, buf, IFX_F_INT_CACHE_DESTROY, NULL,
            NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to destroy cache for this instance",
                   __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
	}

	if(ret != IFX_SUCCESS)
		IFX_API_LOG("[%s] returned failure!", __FUNCTION__);

	return ret;
}

/* Derive wan_mode based on PHY and TC values from WAN_PHY_CFG.
 * Based on wan_mode, get default wan connection cfg from rc.conf
 */
int32 default_wan_cfg_get_for_wan_phymode(def_wan_cfg_t * def_wan_cfg,
					  WAN_PHY_CFG * wan_phy)
{
	int32 wan_mode;
	int32 ret;

	wan_mode = compute_wan_mode(wan_phy->phy_mode, wan_phy->wan_tc);
	ret = default_wan_cfg_get_for_wan_mode(def_wan_cfg, wan_mode);

	return ret;
}


int32 ifx_set_wan_phy_cfg_new(WAN_PHY_CFG * pstWanPhy, uint32 flags)
{
	int32 /*wan_type,*/ sTC;
	char8 /*sValue[MAX_FILELINE_LEN], sBuf[MAX_FILELINE_LEN],*/ secName[MAX_FILELINE_LEN];
	//int32 i = 0, *idx_array = NULL, idx_count = 0;

	uint32 outFlag = IFX_F_DEFAULT;
	char_t fw_type[8] = { 0 };
//	wan_type = pstWanPhy->set_phy_mode;
	sTC = pstWanPhy->set_wan_tc;

	def_wan_cfg_t def_wan_cfg;
	int32 wan_index;
	int32 wan_mode;

	WAN_PHY_CFG pstWanPhy_old;
	WAN_CONN_CFG wan_cfg;
	WAN_TYPE		type;
//	sValue[0] = '\0';
//	sBuf[0] = '\0';

/*Flush out the prev value in the auto configuration whenever wan mode is changed*/
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
  char8 sValue[MAX_NAME_LEN];
  NULL_TERMINATE(sValue, 0x0, MAX_NAME_LEN);
  sprintf(sValue, "auto_detect_prev_val=\"\"\n");
  ifx_SetObjData(FILE_RC_CONF,TAG_AUTO_DETECT_CFG, IFX_F_MODIFY, 1,sValue);
#endif


#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
	XDSL_PHY_CFG pstXdslPhy;
	memset(&pstXdslPhy, 0x00, sizeof(pstXdslPhy));
#endif

	memset(&wan_cfg, 0x00, sizeof(wan_cfg));
	memset(&pstWanPhy_old, 0x00, sizeof(pstWanPhy_old));

	ifx_get_wan_phy_cfg(&pstWanPhy_old);

	if (ifx_GetObjData (FILE_SYSTEM_STATUS, "dsl_fw_type", "type",
			     IFX_F_DEFAULT, &outFlag, fw_type) != IFX_SUCCESS) {
		IFX_DBG("[%s:%d] : DSL FW Type Unknown %s \n", __FUNCTION__, __LINE__, fw_type);
		/* set fw type = Annex A by Default */
		strcpy(fw_type, "a");
	}
		
	if (IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) {
#if defined(PLATFORM_VR9) || defined(PLATFORM_AR9) || defined(PLATFORM_AMAZON_SE)
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n [%s:%d] : old.set_wan_tc = %d , new.set_wan_tc = %d , old.wan_tc = %d , new.set_wan_tc = %d\n\n",
		     __FUNCTION__, __LINE__, pstWanPhy_old.set_wan_tc,
		     pstWanPhy->set_wan_tc, pstWanPhy_old.wan_tc,
		     pstWanPhy->wan_tc);
#endif
		/* If the current and new configured wan modes are different, initiate WCO */
		if ((pstWanPhy_old.set_phy_mode != pstWanPhy->set_phy_mode) ||
		    ((pstWanPhy_old.set_phy_mode == pstWanPhy->set_phy_mode) &&
		     (pstWanPhy_old.set_wan_tc != pstWanPhy->set_wan_tc))) {
			IFX_DBG("\n\n [%s:%d] : Calling WAN Stop \n\n",
				__FUNCTION__, __LINE__);
#ifdef CONFIG_FEATURE_ANY_WAN_SUPPORT
			if(pstWanPhy->config_owner == IFX_WEB)
				ifx_SetObjData(FILE_SYSTEM_STATUS, "AnyWan",
				                               IFX_F_MODIFY, 1, "status=\"1\"\n");
#endif
			char8 sCommand[MAX_FILELINE_LEN];
			NULL_TERMINATE(sCommand, 0x0, MAX_FILELINE_LEN);
			sprintf(sCommand, "/etc/init.d/ltq_wan_changeover_stop.sh %d", pstWanPhy->phy_mode); 
			system(sCommand);
		}
/* with ADSL PTM and VDSL ATM Mode coming in, it is not worth to have too many checks just to 
check if the switch is from AUTO <--> ADSL/VDSL. This will only make more checks and 
also makes too many configuration options to be set for xTSE setting and SIC setting.
Also, this is not a often tried our scenario that user changes from web on field
Hence removing this code
*/
#if 0 
		else {
#if defined PLATFORM_VR9
			char8 adsl_xTSE_bits[MAX_FILELINE_LEN] = { 0 };
			char8 command[MAX_FILELINE_LEN] = { 0 };
			if (!gstrcmp(fw_type, "a")) {
				sprintf(adsl_xTSE_bits, "0x4 0x0 0x4 0x0 0xc 0x1 0x0"); 
			}
			else { 
				sprintf(adsl_xTSE_bits, "0x10 0x0 0x10 0x0 0x0 0x4 0x0"); 
			}	
			if (pstWanPhy_old.set_phy_mode ==
			 WAN_PHY_MODE_AUTO) {
				if ((pstWanPhy->set_phy_mode ==
				     WAN_PHY_MODE_ADSL2)
			    	&& (pstWanPhy_old.phy_mode ==
					WAN_PHY_MODE_ADSL2)) {
					sprintf(command, "/opt/lantiq/bin/dsl_cpe_pipe.sh g997xtusecs %s 0x0", adsl_xTSE_bits);
					system(command);
				} else
				    if ((pstWanPhy->set_phy_mode ==
					 WAN_PHY_MODE_VDSL2)
					&& (pstWanPhy_old.phy_mode ==
					    WAN_PHY_MODE_VDSL2)) {
					system
					    ("/opt/lantiq/bin/dsl_cpe_pipe.sh g997xtusecs 0x0 0x0 0x0 0x0 0x0 0x0 0x0 0x7");
				}
			} else if ((pstWanPhy_old.set_phy_mode ==
				 WAN_PHY_MODE_VDSL2)
				&& (pstWanPhy->set_phy_mode ==
				    WAN_PHY_MODE_AUTO)) {
				sprintf(command, "/opt/lantiq/bin/dsl_cpe_pipe.sh g997xtusecs %s 0x7", adsl_xTSE_bits);
				system(command);
			}
#elif defined PLATFORM_AR9 || defined(PLATFORM_AMAZON_SE)
			if (pstWanPhy_old.set_wan_tc == 2) {	/* TC is AUTO */
				if ((pstWanPhy_old.wan_tc == WAN_TC_ATM)
				    && (pstWanPhy->set_wan_tc == WAN_TC_ATM)) {
					system
				    	("/opt/lantiq/bin/dsl_cpe_pipe.sh sics 0 1 1 1 3");
				} else if ((pstWanPhy_old.wan_tc == WAN_TC_PTM)
					   && (pstWanPhy->set_wan_tc ==
					       WAN_TC_PTM)) {
					system
					    ("/opt/lantiq/bin/dsl_cpe_pipe.sh sics 0 2 1 1 3");
				}
			} else if ((pstWanPhy_old.wan_tc == WAN_TC_ATM)
				   && (pstWanPhy->set_wan_tc == 2)) {
				system
				    ("/opt/lantiq/bin/dsl_cpe_pipe.sh sics 0 4 1 1 3");
			}
#endif
		}
#endif
#endif
	}			// IFX_F_INT_DONT_CONFIGURE

	ifx_set_wan_phy_cfg(pstWanPhy);

	/*BLOCK_001: Update "default_wan" and "default_wan_fused" section of rc.conf */

	wan_mode = compute_wan_mode(pstWanPhy->set_phy_mode, pstWanPhy->set_wan_tc);

	if(wan_mode != -1 ) 
	{
			default_wan_cfg_get_for_wan_mode(&def_wan_cfg, wan_mode);
			/*Vicky_Note:
			 *		We need to compute WAN INDEX from wan_conn_name and pass to ifx_set_default_wan_if.
			 */
#if 0
			/*Vicky_Note: Assuming WAN Connection name always have prefix "WAN" */
			if (def_wan_cfg.conn_name[2] == 'N') {
					wan_index = atoi(&(def_wan_cfg.conn_name[3]));
					if (wan_index >= 0)
							ifx_set_default_wan_if(&(def_wan_cfg.iid), wan_index,
																					IFX_F_MODIFY);
			} else {
					IFX_DBG ("\nNo Default WAN Connection Configured in WAN Mode [%d] \n", pstWanPhy->phy_mode);
			}
#endif // 0

				GET_WAN_DETAILS_FROM_CONN_NAME(def_wan_cfg.conn_name, type, wan_index, secName)
				if (wan_index >= 0) {
						ifx_set_default_wan_if(&(def_wan_cfg.iid), type, IFX_F_MODIFY);
				} else {
						IFX_DBG ("\nNo Default WAN Connection Configured in WAN Mode [%d] \n", pstWanPhy->phy_mode);
				}
#ifdef IFX_LOG_DEBUG
				IFX_DBG("\n\n In Function [%s:%d]  WT -> %d TC-> %d !!\n\n",__FUNCTION__, __LINE__, type, sTC);
#endif
	}
/*BLOCK_001 END */


	if ((pstWanPhy->set_phy_mode == WAN_PHY_MODE_ADSL2)
	    || (pstWanPhy->set_phy_mode == WAN_PHY_MODE_VDSL2)
	    || (pstWanPhy->set_phy_mode == 4)) {
		// xDSL_Config rc.conf section modification done here
#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
		sprintf(pstXdslPhy.sVdsl_Mode, "%s", "0_0_0_0_0_0_0_7");
		sprintf(pstXdslPhy.sDsl_Api_Debug, "%s", "DISABLE");
		if (pstWanPhy->set_phy_mode == 4)
			sprintf(pstXdslPhy.sXdsl_Mode, "Multimode-xDSL");
		else if (pstWanPhy->set_phy_mode == WAN_PHY_MODE_VDSL2) {
			sprintf(pstXdslPhy.sXdsl_Mode, "vdsl2");
			sprintf(pstXdslPhy.sAdsl_Mode, "00_00_00_00_00_00_00_07");
		} else if (pstWanPhy->set_phy_mode == WAN_PHY_MODE_ADSL2) {
			sprintf(pstXdslPhy.sXdsl_Mode, "Multimode-ADSL");
			sprintf(pstXdslPhy.sVdsl_Mode, "%s", "0_0_0_0_0_0_0_0");
		}
		if (pstWanPhy->set_phy_mode != WAN_PHY_MODE_VDSL2) {
			if (!gstrcmp(fw_type, "b")) {
  				if(pstWanPhy->set_phy_mode == 4 ){
					sprintf(pstXdslPhy.sAdsl_Mode, "10_00_10_00_00_04_00_07"); 
  				} else {
					sprintf(pstXdslPhy.sAdsl_Mode, "10_00_10_00_00_04_00_00"); 
				} 
 			} else {
 				if(pstWanPhy->set_phy_mode == 4 ){
					sprintf(pstXdslPhy.sAdsl_Mode, "05_00_04_00_0C_01_00_07");
				} else {    			
#if defined PLATFORM_VR9
					sprintf(pstXdslPhy.sAdsl_Mode, "05_00_04_00_0C_01_00_00");
#else
					sprintf(pstXdslPhy.sAdsl_Mode, "05_00_04_00_0C_01_00_00");
#endif
				}
			}
		}
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s:%d]  pstXdslPhy.sXdsl_Mode -> %s pstXdslPhy.sVdsl_Mode -> %s pstXdslPhy.sDsl_Api_Debug-> %s pstWanPhy->set_phy_mode %d pstXdslPhy.sAdsl_Mode -> %s !!\n\n",
		     __FUNCTION__, __LINE__, pstXdslPhy.sXdsl_Mode,
		     pstXdslPhy.sVdsl_Mode, pstXdslPhy.sDsl_Api_Debug,
		     pstWanPhy->set_phy_mode, pstXdslPhy.sAdsl_Mode);
#endif
		ifx_set_xdsl_phy_cfg(&pstXdslPhy);
#endif
	}
	if ((pstWanPhy->set_phy_mode == 4) || (pstWanPhy->set_phy_mode == WAN_PHY_MODE_ADSL2 && pstWanPhy->set_wan_tc == 2))	// Auto mode
	{
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In Function [%s:%d]  \n\n", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}
#if 0 // [ We will support PTM WAN configuration with and without VLAN at same time
#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
#ifdef IFX_LOG_DEBUG
	IFX_DBG
	    ("\n\n In Function [%s:%d]  pstWanPhy_old.ptm_vlan_mode -> %d  pstWanPhy->ptm_vlan_mode -> %d !!\n\n",
	     __FUNCTION__, __LINE__, pstWanPhy_old.ptm_vlan_mode,
	     pstWanPhy->ptm_vlan_mode);
#endif
	if ((pstWanPhy->wan_tc == WAN_TC_PTM) &&
	    (pstWanPhy->phy_mode == WAN_PHY_MODE_VDSL2
	     || pstWanPhy->phy_mode == WAN_PHY_MODE_ADSL2)
	    && (pstWanPhy_old.ptm_vlan_mode != pstWanPhy->ptm_vlan_mode)) {
		if (ifx_set_ptm_vlan_wan_display() != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("In function [%s:%d] web display failed!!",
				__FUNCTION__, __LINE__);
#endif
		}
	}
#endif
#endif // PTM WAN with or without VLAN support ]

#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
#ifdef IFX_LOG_DEBUG
	IFX_DBG
	    ("In function [%s] : pstWanPhy_old.eth_mii1_vlan_mode -> %d pstWanPhy->eth_mii1_vlan_mode -> %d pstWanPhy_old.eth_vlan_mode -> %d pstWanPhy->eth_vlan_mode -> %d !!",
	     __FUNCTION__, pstWanPhy_old.eth_mii1_vlan_mode,
	     pstWanPhy->eth_mii1_vlan_mode, pstWanPhy_old.eth_vlan_mode,
	     pstWanPhy->eth_vlan_mode);
#endif

#if 0 // [ We will support ETM WAN on MII1 configuration with and without VLAN at same time.
	if (((pstWanPhy->phy_mode == WAN_PHY_MODE_ETH_MII1)
	     && (pstWanPhy_old.eth_mii1_vlan_mode !=
		 pstWanPhy->eth_mii1_vlan_mode))
	    || ((pstWanPhy->phy_mode == WAN_PHY_MODE_ETH_MII0)
		&& (pstWanPhy_old.eth_vlan_mode != pstWanPhy->eth_vlan_mode))
	    ) {			// eth mii1 or mii0 vlan mode different
#endif // ETM WAN on MII1 with or without VLAN support ]

	// For MII0, we dont support ETH WAN configuratio with and without VLAN at same time
	if( (pstWanPhy->phy_mode == WAN_PHY_MODE_ETH_MII0) && (pstWanPhy_old.eth_vlan_mode != pstWanPhy->eth_vlan_mode))
	{//eth mii0 vlan mode different
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("In function [%s] : pstWanPhy_old.eth_mii1_vlan_mode -> %d pstWanPhy->eth_mii1_vlan_mode -> %d pstWanPhy_old.eth_mii1_vlan_mode -> %d pstWanPhy->eth_vlan_mode -> %d !!",
		     __FUNCTION__, pstWanPhy_old.eth_mii1_vlan_mode,
		     pstWanPhy->eth_mii1_vlan_mode, pstWanPhy_old.eth_vlan_mode,
		     pstWanPhy->eth_vlan_mode);
#endif
	}
#endif

	/* setting default route and voip is handled through ltq_wan_changeover.sh script (case of start) */

      IFX_Handler:
		if (IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) {
			if ((pstWanPhy_old.set_phy_mode != pstWanPhy->set_phy_mode) ||
		        ((pstWanPhy_old.set_phy_mode == pstWanPhy->set_phy_mode) &&
    		     (pstWanPhy_old.set_wan_tc != pstWanPhy->set_wan_tc))) {
				system
				    ("/etc/init.d/ltq_wan_changeover_start.sh");
			}
		}
	return IFX_SUCCESS;
}


/* Based on wan_mode, get default wan interface from rc.conf
 */
int32 default_wan_iface_get_for_wan_mode(WAN_MODE wan_mode, char8 * iface)
{
	int32 ret;
	def_wan_cfg_t def_wan_cfg;
	ret = default_wan_cfg_get_for_wan_mode(&def_wan_cfg, wan_mode);

	if (ret == IFX_SUCCESS) {
		strcpy(iface, def_wan_cfg.iface);
	}
/*
	else{
		strcpy(iface, " ");
	}
*/
	return ret;
}

/* derive wan_mode based on PHY and TC values as applicable
 * based on wan_mode, get default wan interface from rc.conf
 */
int32 default_wan_iface_get_for_wan_phymode(WAN_PHY_CFG * wan_phy,
					    char8 * iface)
{
	int32 ret;
	def_wan_cfg_t def_wan_cfg;

	ret = default_wan_cfg_get_for_wan_phymode(&def_wan_cfg, wan_phy);
	if (ret == IFX_SUCCESS) {
		strcpy(iface, def_wan_cfg.iface);
	}
/*
	else {
				strcpy(iface, " ");
		}
*/
		return ret;
}

/**************************************************************************************
* Function    : global_wan_mode_get()
* Description : Get current WAN mode
* Parameters  : 
* Return      : WAN mode value on success, IFX_FAILURE on error
**************************************************************************************/
int32 global_wan_mode_get(uint32 flags)
{
	WAN_PHY_CFG	pstWanPhy;

	ifx_get_wan_phy_cfg(&pstWanPhy);

	return compute_wan_mode(pstWanPhy.phy_mode, pstWanPhy.wan_tc);

}


/*//////////////////////////////////////////////////////////////////////////////
* (mapi_validate_wanconfig(...)
*     operation      ==>     specifies the operation to be done such as ADD, DELETE or MODIFY
*     old_wan_cfg        ==>     pointer to WAN_CONN_CFG structure which will store the existing common parameters of the wan
*                            connection and the wan ip/ppp specific parameters
*	new_wan_cfg  ==>	pointer to WAN_CONN_CFG structure which will store the new common parameters of the wan
*                            connection and the wan ip/ppp specific parameters
*     Return Value :   IFX_SUCCESS or IFX_FAILURE
*     Description:
*                    The api validates wan configuration sections in rc.conf, wan_ip (ip specific parameters) or wan_ppp (ppp specific parameters).
*                    The caller should pass the old_wan_cfg values, new_wan_cfg in the structue. 
*                    This function acts like check to avoid more wan connections than the existing limitaions.
*//////////////////////////////////////////////////////////////////////////////

int32 mapi_validate_wanconfig( int32 operation , WAN_CONN_CFG * old_wan_cfg, WAN_CONN_CFG * new_wan_cfg)
{

	int32 validate_flag =1,wanip_count= 0,wanppp_count = 0, wanchanppp_count=0,wanchanip_count=0,i=0,wanchanbr_count=0;
	char_t sValue[MAX_FILELINE_LEN], sCFG_NAME[MAX_DATA_LEN];
	char_t pWAN_VCC[MAX_NAME_LEN];
	uint32 outFlag = IFX_F_DEFAULT;




	NULL_TERMINATE(sValue, 0x00, sizeof(sValue));
	NULL_TERMINATE(pWAN_VCC , 0x00, sizeof(pWAN_VCC));
	NULL_TERMINATE(sCFG_NAME , 0x00, sizeof(sCFG_NAME));


	/*verify operation type */
        if (operation == IFX_OP_MOD)
	{
		if( old_wan_cfg->type == WAN_TYPE_IP)
		{
		if ((old_wan_cfg->wancfg.ip.conn_type == new_wan_cfg->wancfg.ip.conn_type) && (!strcmp(old_wan_cfg->wancfg.ip.wan_cfg.l2iface_name , new_wan_cfg->wancfg.ip.wan_cfg.l2iface_name)))
		{
		validate_flag =0;
		}
		}
		else
		{
		if ((old_wan_cfg->wancfg.ppp.wan_cfg.link_type == new_wan_cfg->wancfg.ppp.wan_cfg.link_type) && (!strcmp(old_wan_cfg->wancfg.ppp.wan_cfg.l2iface_name , new_wan_cfg->wancfg.ppp.wan_cfg.l2iface_name)))
                {
                validate_flag =0;
                }
		}

	}

	 if (ifx_get_sec_count(TAG_WAN_IP, &wanip_count) != IFX_SUCCESS)
         {
         	#ifdef IFX_LOG_DEBUG
                IFX_DBG("function [%s] LINE [%d]", __FUNCTION__, __LINE__);
                #endif
         }
	if (ifx_get_sec_count(TAG_WAN_PPP, &wanppp_count) != IFX_SUCCESS) 
	{
        	#ifdef IFX_LOG_DEBUG
                IFX_DBG("function [%s] LINE [%d]", __FUNCTION__, __LINE__);
                #endif
        }


	if(validate_flag == 1)
	{
		if( (wanip_count + wanppp_count) >= 17)
		{
			#ifdef IFX_LOG_DEBUG
                        	IFX_DBG("function [%s] LINE [%d]", __FUNCTION__, __LINE__);
                        #endif
                        return -1;
		}
		if( new_wan_cfg->type == WAN_TYPE_IP)
		{


			if( new_wan_cfg->wancfg.ip.conn_type==WAN_IP_CONN_TYPE_IP_ROUTED )
			{

				sprintf(pWAN_VCC,new_wan_cfg->wancfg.ip.wan_cfg.l2iface_name);
	        		for (i = 0; i < wanip_count; i++) 
				{
        	        	        sprintf(sCFG_NAME, "%s_%d_l2ifName", PREFIX_WAN_IP, i);
	                	        if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, sCFG_NAME, IFX_F_DEFAULT,
        	                	    (IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS) {
						#ifdef IFX_LOG_DEBUG
						IFX_DBG("function [%s] LINE [%d]", __FUNCTION__, __LINE__);
						#endif

                        		}
	                        	if (!gstrcmp(sValue, pWAN_VCC)){
						 sprintf(sCFG_NAME, "%s_%d_connType", PREFIX_WAN_IP, i);
                	                        if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, sCFG_NAME, IFX_F_DEFAULT,
                        	                (IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS) {
						#ifdef IFX_LOG_DEBUG                                    
                                        	IFX_DBG("function [%s] LINE [%d]", __FUNCTION__, __LINE__);
                                      	 	 #endif
                                        	}
						if (atoi(sValue) == WAN_IP_CONN_TYPE_IP_ROUTED){
        	        	                	wanchanip_count++;
						}
                        		}


                		}

        			if (wanchanip_count >= 1)
	                	{
        	        		#ifdef IFX_LOG_DEBUG
	        	                IFX_DBG("function [%s] LINE [%d]", __FUNCTION__, __LINE__);
        	        	        #endif
					return -1;
                		}
			}
			else if(new_wan_cfg->wancfg.ip.conn_type ==  WAN_IP_CONN_TYPE_IP_BRIDGED)
			{

				sprintf(pWAN_VCC,new_wan_cfg->wancfg.ip.wan_cfg.l2iface_name);
				
                		for (i = 0; i < wanip_count; i++) {

					sprintf(sCFG_NAME, "%s_%d_l2ifName", PREFIX_WAN_IP, i);
                                	if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, sCFG_NAME, IFX_F_DEFAULT,
	                                    (IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS)
					{
						#ifdef IFX_LOG_DEBUG
        	                	        	IFX_DBG("function [%s] LINE [%d]", __FUNCTION__, __LINE__);
                	                	#endif

                        	        }
                                	if (!gstrcmp(sValue, pWAN_VCC)){
						sprintf(sCFG_NAME, "%s_%d_connType", PREFIX_WAN_IP, i);
                        			if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, sCFG_NAME, IFX_F_DEFAULT,
	                            		(IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS) {
						#ifdef IFX_LOG_DEBUG
                	                        IFX_DBG("function [%s] LINE [%d]", __FUNCTION__, __LINE__);
                        	                #endif

                        			}

						if (atoi(sValue) == WAN_IP_CONN_TYPE_IP_BRIDGED){
                                			wanchanbr_count++;
                        			}
					}
				}

				if ((wanchanbr_count >= 1))
        	        	{
                	        	return -1;
                		}
			}
		}

		else if(new_wan_cfg->wancfg.ppp.wan_cfg.link_type == WAN_LINK_TYPE_PPPOE)
		{

			#ifdef IFX_LOG_DEBUG
                        IFX_DBG("function [%s] LINE [%d]", __FUNCTION__, __LINE__);
                        #endif


			sprintf(pWAN_VCC,new_wan_cfg->wancfg.ppp.wan_cfg.l2iface_name);
                	for (i = 0; i < wanppp_count; i++) {
                        	sprintf(sCFG_NAME, "%s_%d_l2ifName", PREFIX_WAN_PPP, i);
                        	if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, sCFG_NAME, IFX_F_DEFAULT,
                            	(IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS)
				{
	                        #ifdef IFX_LOG_DEBUG
        	                IFX_DBG("function [%s] LINE [%d]", __FUNCTION__, __LINE__);
                	        #endif
	                        }

                	        if (!gstrcmp(sValue, pWAN_VCC)){
        	                	wanchanppp_count++;
                        	}
                	}
			if (wanchanppp_count >= 4)
                	{
        	        	return -1;
                	}
		}
		else
		{
			sprintf(pWAN_VCC,new_wan_cfg->wancfg.ppp.wan_cfg.l2iface_name);
			for (i = 0; i < wanppp_count; i++) {
        	                sprintf(sCFG_NAME, "%s_%d_l2ifName", PREFIX_WAN_PPP, i);
                	        if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, sCFG_NAME, IFX_F_DEFAULT,
                        	    (IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS)
				{
	                       	#ifdef IFX_LOG_DEBUG
        	        	IFX_DBG("function [%s] LINE [%d]", __FUNCTION__, __LINE__);
                	        #endif
	                        }

        	                if (!gstrcmp(sValue, pWAN_VCC)){
                	                wanchanppp_count++;
                        	}
                	}
	                if (wanchanppp_count >= 1)
        	        {
		                return -1;
                	}
		}
	}
return 0;
}


/*//////////////////////////////////////////////////////////////////////////////
* wan_tuple_get(...)
*     wanIdx      ==>     specifies the index of which we need the values for.
*     wanType     ==>     this parameter is to be passed to specify whether its IP/PPP connection.
*     wanIp, wanMask, wanStatus ==> parts in the tuple which will have the values required.
*     Description:
*                    The API retrieves IP address, subnet mask, status values related of WAN connection
*											identified by index and type given.
*//////////////////////////////////////////////////////////////////////////////

int32 wan_tuple_get(int32 wanIdx, WAN_TYPE wanType, char8 *wanIp, char8 *wanMask, char8 *wanGW, char8 *wanStatus)
{
	char8	sType[10], sWAN_Sec1[MAX_FILELINE_LEN], sWAN_Sec2[MAX_FILELINE_LEN];
	uint32	outFlag = IFX_F_DEFAULT;
	int32	ret = IFX_SUCCESS;

	sprintf(wanIp,"Unconfigured");
	sprintf(wanMask,"Unconfigured");
	sprintf(wanGW,"Unconfigured");
	sprintf(wanStatus,"Unconfigured");

	if(wanType == WAN_TYPE_IP) {
		sprintf(sType, "%s", "WANIP");
		sprintf(sWAN_Sec1, "WanIP%d_IF_Info", wanIdx);
		sprintf(sWAN_Sec2, "WanIP%d_GATEWAY", wanIdx);
	}
	else {
		sprintf(sType, "%s", "WANPPP");
		sprintf(sWAN_Sec1, "WanPPP%d_IF_Info", wanIdx);
		sprintf(sWAN_Sec2, "WanPPP%d_GATEWAY", wanIdx);
	}


	if (ifx_GetObjData(FILE_SYSTEM_STATUS, sWAN_Sec1, "STATUS", IFX_F_GET_ENA,
					&outFlag, wanStatus) != IFX_SUCCESS) {
                ret = IFX_FAILURE;
                goto LTQ_Handler;
	}

	if (ifx_GetObjData(FILE_SYSTEM_STATUS, sWAN_Sec1, "IP", IFX_F_GET_ENA,
					&outFlag, wanIp) != IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	}

	if (ifx_GetObjData(FILE_SYSTEM_STATUS, sWAN_Sec1, "MASK", IFX_F_GET_ENA,
					&outFlag, wanMask) != IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	}

	if (ifx_GetObjData(FILE_SYSTEM_STATUS, sWAN_Sec2, "ROUTER1", IFX_F_GET_ENA,
					&outFlag, wanGW) != IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	}

LTQ_Handler:
	return ret;
}

/* ADD or DELETE vlan or vcc entry in the field_name passed 
 * field_name	: 	vcc pool, atm (or) ptm VLAN pool
 * value		: 	VPI/VCI (or) VLAN
 * operation 	:  	IFX_F_INT_ADD / IFX_F_DELETE
 * caller: 
				ltq_mapi_update_autodetect_pool("auto_vcc_pool", "0/35", IFX_F_INT_ADD/IFX_F_DELETE);
				lltq_mapi_update_autodetect_pool("auto_ptm_vlan_pool", "0/35", IFX_F_INT_ADD/IFX_F_DELETE);
				ltq_mapi_update_autodetect_pool("auto_atm_vlan_pool", "0/35", IFX_F_INT_ADD/IFX_F_DELETE);
 */
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
int ltq_mapi_update_autodetect_pool(char *field_name, char *value, uint32 operation)
{
				WAN_MODE wanMode = WAN_MODE_ATM;
				WAN_PHY_CFG pstWanPhy;
				ifx_get_wan_phy_cfg(&pstWanPhy);
				char8 sValue[MAX_NAME_LEN];
#if 0 //commented bocoz it has impact on automation
				char8 IndxStr[MAX_FILELINE_LEN];
				memset(IndxStr, '\0', sizeof(IndxStr));
#endif
				auto_detect_cfg_t config;
				memset(&config, 0x00, sizeof(config));
				NULL_TERMINATE(sValue, 0x0, MAX_NAME_LEN);
				sprintf(sValue, "auto_detect_prev_val=\"\"\n");
				ltq_mapi_get_autodetect_config(&config);
				wanMode = compute_wan_mode(pstWanPhy.phy_mode, pstWanPhy.wan_tc);

				/*manohar:Read the index string values from file */
#if 0 //commented becoz it has impact on automation
				if (ifx_GetObjData(FILE_AUTO_DETECT,TAG_AUTO_DETECT_CFG,field_name, 0, NULL, IndxStr) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
								IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
								return IFX_FAILURE;
				}
#endif

				if (!strcmp(field_name, VCC_POOL_FIELD)) {
								/*manohar:prev value should be flushed out whenever pool is updated*/
								if(wanMode == WAN_MODE_ATM){
												ifx_SetObjData(FILE_RC_CONF,TAG_AUTO_DETECT_CFG, IFX_F_MODIFY, 1,sValue);
								}
								/*manohar:when last entry in the pool is deleted then autodetect should be disabled*/
#if 0 //commented becoz it has impact on automation
								if(!strcmp(IndxStr,value)){
												config.auto_detect_L2 = 0;
												config.auto_detect_L3 = 0;
												config.auto_detect_Vlan_ATM = 0;
												if (ltq_mapi_set_autodetect_config(&config, IFX_F_MODIFY) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
																IFX_DBG("[%s:%d] Failed to set auto detect parameter",__FUNCTION__, __LINE__);
#endif
																return IFX_FAILURE;
												}
								}
#endif
								ifx_manipulate_string_indexs(FILE_AUTO_DETECT, TAG_AUTO_DETECT_CFG, VCC_POOL_FIELD, value, operation);

								/*manohar:atm wan pool also need to updated when one update vcc pool from the GUI*/
								NULL_TERMINATE(sValue, 0x0, MAX_NAME_LEN);
								sprintf(sValue, "%s:dhcp",value);
								ifx_manipulate_string_indexs(FILE_AUTO_DETECT, TAG_AUTO_DETECT_CFG, ATM_WAN_POOL_FIELD, sValue, operation);
								NULL_TERMINATE(sValue, 0x0, MAX_NAME_LEN);
								sprintf(sValue, "%s:pppoe",value);
								ifx_manipulate_string_indexs(FILE_AUTO_DETECT, TAG_AUTO_DETECT_CFG, ATM_WAN_POOL_FIELD, sValue, operation);
				} else if(!strcmp(field_name, ATM_VLAN_POOL_FIELD)) {
								/*manohar:prev value should be flushed out whenever pool is updated*/
								if(wanMode == WAN_MODE_ATM){
												ifx_SetObjData(FILE_RC_CONF,TAG_AUTO_DETECT_CFG, IFX_F_MODIFY, 1,sValue);
								}
								/*manohar:when last entry in the pool is deleted then autodetect should be disabled*/
#if 0 //commented becoz it has impact on automation
								if(!strcmp(IndxStr,value)){
												config.auto_detect_L2 = 0;
												config.auto_detect_L3 = 0;
												config.auto_detect_Vlan_ATM = 0;
												if (ltq_mapi_set_autodetect_config(&config, IFX_F_MODIFY) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
																IFX_DBG("[%s:%d] Failed to set auto detect parameter",__FUNCTION__, __LINE__);
#endif
																return IFX_FAILURE;
												}
								}
#endif
								ifx_manipulate_string_indexs(FILE_AUTO_DETECT, TAG_AUTO_DETECT_CFG, ATM_VLAN_POOL_FIELD, value, operation);
				} else if(!strcmp(field_name, ADSL_PTM_VLAN_POOL_FIELD)) {
								/*manohar:prev value should be flushed out whenever pool is updated*/
								if(wanMode == WAN_MODE_PTM){
												ifx_SetObjData(FILE_RC_CONF,TAG_AUTO_DETECT_CFG, IFX_F_MODIFY, 1,sValue);
								}
								/*manohar:when last entry in the pool is deleted then autodetect should be disabled*/
#if 0 //commented becoz it has impact on automation
								if(!strcmp(IndxStr,value)){
												config.auto_detect_Vlan_ADSL_PTM = 0;
												config.auto_detect_adsl_ptm_L3  = 0;
												if (ltq_mapi_set_autodetect_config(&config, IFX_F_MODIFY) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
																IFX_DBG("[%s:%d] Failed to set auto detect parameter",__FUNCTION__, __LINE__);
#endif
																return IFX_FAILURE;
												}
								}
#endif
								ifx_manipulate_string_indexs(FILE_AUTO_DETECT, TAG_AUTO_DETECT_CFG, ADSL_PTM_VLAN_POOL_FIELD, value, operation);
				} else if(!strcmp(field_name, VDSL_PTM_VLAN_POOL_FIELD)) {
								/*manohar:prev value should be flushed out whenever pool is updated*/
								if(wanMode == WAN_MODE_VDSL_PTM){
												ifx_SetObjData(FILE_RC_CONF,TAG_AUTO_DETECT_CFG, IFX_F_MODIFY, 1,sValue);
								}
								/*manohar:when last entry in the pool is deleted then autodetect should be disabled*/
#if 0 //commented becoz it has impact on automation
								if(!strcmp(IndxStr,value)){
												config.auto_detect_Vlan_VDSL_PTM = 0;
												config.auto_detect_vdsl_ptm_L3 = 0;
												if (ltq_mapi_set_autodetect_config(&config, IFX_F_MODIFY) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
																IFX_DBG("[%s:%d] Failed to set auto detect parameter",__FUNCTION__, __LINE__);
#endif
																return IFX_FAILURE;
												}
								}
#endif
								ifx_manipulate_string_indexs(FILE_AUTO_DETECT, TAG_AUTO_DETECT_CFG, VDSL_PTM_VLAN_POOL_FIELD, value, operation);
				} else if(!strcmp(field_name, ETH1_VLAN_POOL_FIELD)) {
								/*manohar:prev value should be flushed out whenever pool is updated*/
								if(wanMode == WAN_MODE_ETH1){
												ifx_SetObjData(FILE_RC_CONF,TAG_AUTO_DETECT_CFG, IFX_F_MODIFY, 1,sValue);
								}
								/*manohar:when last entry in the pool is deleted then autodetect should be disabled*/
#if 0 //commented becoz it has impact on automation 
								if(!strcmp(IndxStr,value)){
												config.auto_detect_Vlan_ETH1 = 0;
												config.auto_detect_mii1_L3  = 0;
												if (ltq_mapi_set_autodetect_config(&config, IFX_F_MODIFY) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
																IFX_DBG("[%s:%d] Failed to set auto detect parameter",__FUNCTION__, __LINE__);
#endif
																return IFX_FAILURE;
												}
								}
#endif
								ifx_manipulate_string_indexs(FILE_AUTO_DETECT, TAG_AUTO_DETECT_CFG, ETH1_VLAN_POOL_FIELD, value, operation);
				} else if(!strcmp(field_name, ETH0_VLAN_POOL_FIELD)) {
								/*manohar:prev value should be flushed out whenever pool is updated*/
								if(wanMode == WAN_MODE_ETH0){
												ifx_SetObjData(FILE_RC_CONF,TAG_AUTO_DETECT_CFG, IFX_F_MODIFY, 1,sValue);
								}
								/*manohar:when last entry in the pool is deleted then autodetect should be disabled*/
#if 0 //commented becoz it has impact on automation 
								if(!strcmp(IndxStr,value)){
												config.auto_detect_Vlan_ETH0 = 0;
												config.auto_detect_mii0_L3  = 0;
												if (ltq_mapi_set_autodetect_config(&config, IFX_F_MODIFY) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
																IFX_DBG("[%s:%d] Failed to set auto detect parameter",__FUNCTION__, __LINE__);
#endif
																return IFX_FAILURE;
												}
								}
#endif
								ifx_manipulate_string_indexs(FILE_AUTO_DETECT, TAG_AUTO_DETECT_CFG, ETH0_VLAN_POOL_FIELD, value, operation);
				}else{
								IFX_DBG("ERROR Unable to recognize POOL[%s]\n", field_name);
								return IFX_FAILURE;
				}
				return IFX_SUCCESS;
} 
#endif

/*//////////////////////////////////////////////////////////////////////////////
* mapi_default_wan_details_get(...)
*			wanCfg			==>		output pointer to default WAN instance of current WAN mode
*			flags				==>		input flags
*     Description:
*                    The API retrieves default WAN instance details of current WAN mode
*//////////////////////////////////////////////////////////////////////////////
int32 mapi_default_wan_details_get(WAN_CONN_CFG *wanCfg, uint32 flags)
{
	IFX_ID	iid;
	int32	ret = IFX_SUCCESS, wanIdx = -1;
	char8	secName[MAX_FILELINE_LEN];
	char8	wanconnName[MAX_CONN_NAME_LEN];

	if((ret = ifx_get_default_wan_if(&iid, &wanIdx, wanconnName, IFX_F_DEFAULT)) != IFX_SUCCESS) {
		goto LTQ_Handler;
	}

	GET_WAN_TYPE_N_SEC_FROM_CONN_NAME(wanconnName, wanCfg->type, secName)

	if((ret = mapi_get_wan_config(wanIdx, wanCfg, flags)) != IFX_SUCCESS) {
		goto LTQ_Handler;
	}

LTQ_Handler:
	return ret;
}


int32 mapi_get_all_user_obj_details(int32 *user_count, user_obj_t **user_obj, uint32 flags)
{
	user_obj_t *t_ptr = NULL, t_user_obj;
	int32 ret = IFX_SUCCESS, idx_count = 0, i = 0, cache_ret = IFX_SUCCESS;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 buf[MAX_FILELINE_LEN],
				sValue[MAX_FILELINE_LEN],
				secName[32], 
				SECTION_PREFIX[MAX_TAG_LEN];

	if((user_obj == NULL) || (user_count == NULL))
	{
		IFX_DBG("[%s:%d]ERROR ", __FUNCTION__, __LINE__);
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	*user_count = 0;
	*user_obj = NULL;
	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	sprintf(secName, "%s", "user_obj");
	sprintf(SECTION_PREFIX, "%s", "user");

	flags = IFX_F_DEFAULT;

	if ((cache_ret = ifx_GetObjDataOpt(FILE_RC_CONF, secName, SECTION_PREFIX, IFX_F_INT_CACHE_INIT | flags, NULL, NULL)) != IFX_SUCCESS)
	{
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
		goto IFX_Handler;
	}

	inline char8 *read_file_cache(char *attr)
	{
		NULL_TERMINATE(sValue, 0, MAX_NAME_SIZE);
		if (ifx_GetObjDataOpt(FILE_RC_CONF, secName, attr, 0,(IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS)
		{
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve %s", __FUNCTION__,	__LINE__, buf);
#endif
			return NULL;
		}
		return sValue;
	}

	sprintf(buf, "%s", "user_obj_Count");
			
	if (read_file_cache(buf)){
			idx_count = atoi(sValue);
			*user_count = idx_count;
	}else
			goto IFX_Handler;
	if(idx_count == 0)
	{
		*user_obj = NULL;
		goto IFX_Handler;
	}

	IFX_MEM_ALLOC(t_ptr, user_obj_t *, idx_count, sizeof(user_obj_t))

	if (t_ptr == NULL)
	{
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	*user_obj = t_ptr;
	for(i=0; i<idx_count; i++)
	{
		memset(&t_user_obj, 0x00, sizeof(t_user_obj));

		sprintf(buf, "%s_%d_%s", SECTION_PREFIX, i, "cpeId");
		if (read_file_cache(buf))
			t_user_obj.iid.cpeId.Id = atoi(sValue);
		else
			goto IFX_Handler;

		sprintf(buf, "%s_%d_%s", SECTION_PREFIX, i, "pcpeId");
		if (read_file_cache(buf))
			t_user_obj.iid.pcpeId.Id	 = atoi(sValue);
		else
			goto IFX_Handler;

		sprintf(buf, "%s_%d_%s", SECTION_PREFIX, i, "fEnable");
		if (read_file_cache(buf))
			t_user_obj.f_enable = atoi(sValue);
		else
			goto IFX_Handler;

		sprintf(buf, "%s_%d_%s", SECTION_PREFIX, i, "username");
		if (read_file_cache(buf))
			STRNCPY(t_user_obj.username, sValue,MAX_NAME_SIZE-1);
		else
			goto IFX_Handler;

		sprintf(buf, "%s_%d_%s", SECTION_PREFIX, i, "password");
		if (read_file_cache(buf))
			STRNCPY(t_user_obj.password, sValue,MAX_NAME_SIZE-1);
		else
			goto IFX_Handler;

		sprintf(buf, "%s_%d_%s", SECTION_PREFIX, i, "webAccess");
		if (read_file_cache(buf))
			t_user_obj.webAccess = atoi(sValue);
		else
			goto IFX_Handler;

		sprintf(buf, "%s_%d_%s", SECTION_PREFIX, i, "fileShareAccess");
		if (read_file_cache(buf))
			t_user_obj.fileShareAccess = atoi(sValue);
		else
			goto IFX_Handler;

		sprintf(buf, "%s_%d_%s", SECTION_PREFIX, i, "telnetAccess");
		if (read_file_cache(buf))
			t_user_obj.telnetAccess = atoi(sValue);
		else
			goto IFX_Handler;

		memcpy((*user_obj + i), &t_user_obj, sizeof(t_user_obj));
	}
IFX_Handler:
	if(cache_ret == IFX_SUCCESS)
		if ((cache_ret = ifx_GetObjDataOpt(FILE_RC_CONF, secName, SECTION_PREFIX, IFX_F_INT_CACHE_DESTROY, NULL, NULL)) != IFX_SUCCESS)
                {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Failed to destroy cache for this instance", __FUNCTION__, __LINE__);
#endif
			cache_ret = IFX_FAILURE;
		}


	if (ret != IFX_SUCCESS || cache_ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*user_obj);
		*user_count = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	return IFX_SUCCESS;
}

int32 mapi_user_obj_details_get(user_obj_t *user_obj, uint32 flags)
{
	user_obj_t *all_user_obj = NULL;
	int32 user_count = 0, i = 0;
	if(mapi_get_all_user_obj_details(&user_count, &all_user_obj, flags) == IFX_FAILURE){
			return IFX_FAILURE;
	}

	for(i=0;i<user_count;i++)
	{
			if((all_user_obj + i)->iid.cpeId.Id == user_obj->iid.cpeId.Id){
					user_obj->iid.cpeId.Id = (all_user_obj + i)->iid.cpeId.Id;
					user_obj->iid.pcpeId.Id = (all_user_obj + i)->iid.pcpeId.Id;
					user_obj->f_enable = (all_user_obj + i)->f_enable;
					strcpy(user_obj->username, (all_user_obj + i)->username);
					strcpy(user_obj->password, (all_user_obj + i)->password);
					user_obj->webAccess = (all_user_obj + i)->webAccess;
					user_obj->fileShareAccess = (all_user_obj + i)->fileShareAccess;
					user_obj->telnetAccess = (all_user_obj + i)->telnetAccess;
					

					break;
			}
	}

        IFX_MEM_FREE( all_user_obj);
        if ( i == user_count )
	   return IFX_FAILURE;
        else 
           return IFX_SUCCESS;
}


//
// is_user
//    function to check existance of the user in passwd file 
//
int is_user( FILE *fp, const char *uname )
{
   int found = -1;
   char line[MAX_FILELINE_LEN]; 
  
   while( fgets(line,MAX_FILELINE_LEN, fp )){
     if ( strncmp( line, uname , strlen (uname)) == 0 ){
         found = 0;
         break; 
     }
   }

   return found;
}


//
// ltq_deleteUser 
//   function to delete the user details from passwd file 
//
int32 ltq_deleteUser( const char *pfname, const char *username )
{
  FILE *ifp, *ofp;
  char *ofname = "/tmp/passwd-";
  char line[MAX_FILELINE_LEN];

  ifp = fopen(pfname, "r+");
  if(!ifp){
    return -1;
  }

  ofp = fopen( ofname,"w+");
  if (!ofp ){
    fclose(ifp);
    return -2;
  }

  while( fgets( line, MAX_FILELINE_LEN, ifp )){
    if (strncmp( line, username,strlen(username)) != 0)
        fprintf(ofp,"%s", line);
    else
        continue;
  }

  fclose(ifp);
  fclose(ofp);
  rename( ofname, pfname );
  return 0;
}
      
//
// ltq_addUser
//    function to add the user details to passwd file 
//

/* 
 *  format of passwd file 
 *  user_name:encrypted_passwd:uid:gid:user_info:home_directory:shell_type
 */
int32 ltq_addUser( const char * pfname, const char *username )
{
   FILE *fp;
   char buf[MAX_FILELINE_LEN];


   fp = fopen( pfname,"r+");
   if(!fp) 
      return -1;

   if( is_user( fp,username ) == 0 ){
      fclose(fp);
      return -2;
   }

   if(strcmp(username,"root") && strcmp(username,"admin") && strcmp(username,"support_user")) {
	sprintf( buf, "%s:x:201:0:Linux User:/mnt/usb:/bin/sh", username );
   } else {
	sprintf( buf, "%s:x:0:0:root:/tmp/%s:/bin/sh", username, username );
   }

   fseek(fp, 0, SEEK_END);
   fprintf(fp,"%s\n", buf);
   fclose(fp);
   return 0;
}

int32 mapi_user_obj_details_set(int32 operation, user_obj_t *user_obj, uint32 flags)
{
	int32 passed_index = -1;
	int32 ret = IFX_SUCCESS, count = 0; 
	char8 buf[1024];
	IFX_NAME_VALUE_PAIR array_fvp[10];
	user_obj_t prev_user_obj;
	char8 flg_passwd = 0;

	char8 *user_obj_param_names[] = { "cpeId", "pcpeId", "fEnable", "username", "password", "webAccess", "fileShareAccess", "telnetAccess" };

	memset(buf, 0x00, sizeof(buf));
	memset(array_fvp, 0x00, sizeof(array_fvp));
	memset(&prev_user_obj, 0x00, sizeof(prev_user_obj));

	if (operation == IFX_OP_DEL) {
		flags |= IFX_F_DELETE;
	} else if (operation == IFX_OP_MOD) {
		flags |= IFX_F_MODIFY;
	} else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags))) {
		flags |= IFX_F_INT_ADD;
	}

	sprintf(user_obj->iid.cpeId.secName, "%s", TAG_USER_OBJ);
	user_obj->iid.pcpeId.Id = 1;
	sprintf(user_obj->iid.pcpeId.secName, "%s", TAG_IGD);

	if (operation != IFX_OP_ADD) {
		/* Read existing user configuration */
		memcpy(&prev_user_obj.iid, &user_obj->iid, sizeof(user_obj->iid));
		if(mapi_user_obj_details_get(&prev_user_obj, IFX_F_GET_ANY) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Failed to read existing user configuration", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	} else {
		if (IFX_ADD_F_SET(flags)) {
			if (ifx_get_IID(&user_obj->iid, "webAccess") !=
			    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
	}
	
	if(IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		if(strlen(user_obj->password) < APPS_PASSWORD_MIN_SIZE || strlen(user_obj->password) > APPS_PASSWORD_MAX_SIZE) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] New password doesn't match recommended length criteria", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		/* I'm always alive - sd. admin */
		if(!strcmp(user_obj->username, "admin") && user_obj->f_enable == IFX_DISABLED) {
			IFX_DBG("[%s:%d] Disabling of admin account is not supported", __FUNCTION__, __LINE__);
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	count = 8;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, 0, count, user_obj_param_names);
		sprintf(array_fvp[0].value, "%d", user_obj->iid.cpeId.Id);
		sprintf(array_fvp[1].value, "%d", user_obj->iid.pcpeId.Id);
		sprintf(array_fvp[2].value, "%d", user_obj->f_enable);
		sprintf(array_fvp[3].value, "%s", user_obj->username); 
		sprintf(array_fvp[4].value, "%s", user_obj->password); 
		sprintf(array_fvp[5].value, "%d", user_obj->webAccess);
		sprintf(array_fvp[6].value, "%d", user_obj->fileShareAccess);
		sprintf(array_fvp[7].value, "%d", user_obj->telnetAccess);
		passed_index = -1;
	}

	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, user_obj->iid.cpeId, passed_index)
	}

	if (ifx_get_conf_index_and_nv_pairs
		(&user_obj->iid, passed_index, "user", count,
		array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
	}

	form_cfgdb_buf(buf, count, array_fvp);

	/*Updating  User Object config*/
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_USER_OBJ, flags, 1, buf);
	if (ret != IFX_SUCCESS) {
  		IFX_DBG("[%s:%d] ERROR: Failed to write USER OBJECT to config file", __FUNCTION__, __LINE__);
		goto IFX_Handler;
 	}

	/* This will Compact the section and also update the count for both ADD and DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_USER_OBJ, flags);

	/* Manipulate nextCpeId only for ADD operations */
	if (IFX_INT_ADD_F_SET(flags)) {
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_USER_OBJ);
	}

	/* System configuration block */
	/* Update password for the user in /etc/passwd file based on f_enable */
	/* 1. If previously user was enabled and now we are goint to disable, then execute command to comment the user entry */
	
	if(IFX_INT_ADD_F_SET(flags) && (user_obj->f_enable == IFX_ENABLED)) {
		ltq_addUser( PASSWD_FILE , user_obj->username );
		printf ("Updated password for user [%s]\n", user_obj->username);
		flg_passwd = 1;
	} else if (IFX_DELETE_F_SET(flags)) {
		ltq_deleteUser( PASSWD_FILE , user_obj->username);
		flg_passwd = 0;
	} else if (IFX_MODIFY_F_SET(flags)) {
		if (strcmp(user_obj->username, prev_user_obj.username) != 0) {
			if (prev_user_obj.f_enable == IFX_ENABLED) {
				ltq_deleteUser( PASSWD_FILE , prev_user_obj.username);
				flg_passwd = 0;
			}
			if (user_obj->f_enable == IFX_ENABLED) {
				ltq_addUser( PASSWD_FILE , user_obj->username );
				printf ("Updated password for user [%s]\n", user_obj->username);
				flg_passwd = 1;
			}
		} else if ((user_obj->f_enable == IFX_DISABLED) && (prev_user_obj.f_enable == IFX_ENABLED)) {
			ltq_deleteUser( PASSWD_FILE , user_obj->username);
			flg_passwd = 0;
		} else if ((user_obj->f_enable == IFX_ENABLED) && (prev_user_obj.f_enable == IFX_DISABLED)) {
			ltq_addUser( PASSWD_FILE , user_obj->username );
			printf ("Updated password for user [%s]\n", user_obj->username);
			flg_passwd = 1;
		} else {
			flg_passwd = 1;
		}
	}

	if (flg_passwd && (user_obj->f_enable == IFX_ENABLED)) {

		if ( access("/usr/bin/yes", X_OK) == 0 ){
			sprintf(buf,"/usr/bin/yes \"%s\" 2>/dev/null|/usr/bin/passwd %s >/dev/null 2>/dev/null",user_obj->password,user_obj->username);
			system(buf);
		} else{
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] yes command not found", __FUNCTION__,	__LINE__);
#endif
		}
		/* root user is not explicitly maintained. it inherits all properties of admin user */
		if(!strcmp(user_obj->username, "admin")) {
			if (access( "/usr/bin/yes", X_OK) == 0 ) {
				sprintf(buf,"/usr/bin/yes \"%s\" 2>/dev/null|/usr/bin/passwd %s >/dev/null 2>/dev/null",user_obj->password,"root");
				system(buf);
			} else {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] yes command not found ", __FUNCTION__,	__LINE__ );
#endif
			}
		}
#ifdef CONFIG_FEATURE_SAMBA
		if (user_obj->fileShareAccess > 1) {
			sprintf(buf,"smbpasswd \"%s\" \"%s\"", user_obj->username, user_obj->password);
			system (buf);
		} else {
			sprintf(buf,"smbpasswd -del \"%s\" >/dev/null 2>&1", user_obj->username);
			system (buf);
		}
	} else {
		sprintf(buf,"smbpasswd -del \"%s\" >/dev/null 2>&1", user_obj->username);
		system (buf);
#endif /*! CONFIG_FEATURE_SAMBA */
	}

	system ("/etc/init.d/vsftpd.filterusers.sh 2>/dev/null");

IFX_Handler:
		return ret;
}

int32 mapi_remote_access_details_get(remote_access_t *rt_access, uint32 flags)
{
	int32 ret = IFX_SUCCESS, cache_ret = IFX_SUCCESS;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN], secName[32], SECTION_PREFIX[MAX_TAG_LEN];

	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	if(rt_access == NULL)
	{
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	memset(rt_access, 0x00, sizeof(remote_access_t));
	sprintf(secName, "%s", "remote_access");
	sprintf(SECTION_PREFIX, "%s", "raccess");
	flags = IFX_F_DEFAULT;

	if ((cache_ret = ifx_GetObjDataOpt(FILE_RC_CONF, secName, SECTION_PREFIX, IFX_F_INT_CACHE_INIT | flags, NULL, NULL)) != IFX_SUCCESS) {
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
		cache_ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	inline char8 *read_file_cache(char *attr) {
		NULL_TERMINATE(sValue, 0, MAX_NAME_SIZE);
		if (ifx_GetObjDataOpt(FILE_RC_CONF, secName, attr, 0,(IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve %s", __FUNCTION__, __LINE__, buf);
#endif
			return NULL;
		}
		return sValue;
	}

	sprintf(buf, "%s", "raccess_fEnable");
	if (read_file_cache(buf)){
		rt_access->f_enable = atoi(sValue);
	}else
		goto IFX_Handler;

	sprintf(buf, "%s", "raccess_port");
	if (read_file_cache(buf)){
		rt_access->port = atoi(sValue);
	}else
		goto IFX_Handler;

#if 0 //Not Implemented
				sprintf(buf, "%s", "");
				if (read_file_cache(buf)){
						rt_access->supportedProto = "??"; //comma seperated to 2D Array
				}else
						goto IFX_Handler;
#endif

	sprintf(buf, "%s", "raccess_proto");
	if (read_file_cache(buf)){
		STRNCPY(rt_access->proto, sValue,MAX_NAME_SIZE-1);
	}else
		goto IFX_Handler;

IFX_Handler:
	if(cache_ret == IFX_SUCCESS) {
		if ((cache_ret = ifx_GetObjDataOpt(FILE_RC_CONF, secName, SECTION_PREFIX, 
			IFX_F_INT_CACHE_DESTROY, NULL, NULL)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Failed to destroy cache for this instance", __FUNCTION__, __LINE__);
#endif
			cache_ret = IFX_FAILURE;
		}
	}

	if (ret != IFX_SUCCESS || cache_ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return IFX_FAILURE;
	}

	return IFX_SUCCESS;
}

int32 mapi_remote_access_details_set(remote_access_t *rt_access, uint32 flags)
{
	remote_access_t rt_access_tmp, rt_access_old;
	int32 ret = IFX_SUCCESS, count = 0; 
	char8 buf[1024];
	IFX_NAME_VALUE_PAIR array_fvp[10];

	memset(buf, 0x00, sizeof(buf));
	memset(array_fvp, 0x00, sizeof(array_fvp));
	memset(&rt_access_tmp, 0, sizeof(rt_access_tmp));
	memset(&rt_access_old, 0, sizeof(rt_access_old));

	flags = IFX_F_MODIFY;

	/* Read existing remote access configuraton */
	if(mapi_remote_access_details_get(&rt_access_tmp, IFX_F_DEFAULT) == IFX_FAILURE){
		IFX_DBG("[%s][%d] Remote Access Parameters Read Failed\n",__func__, __LINE__);
		ret = IFX_FAILURE;
		goto Error_Handler;
	} 
	memcpy(&rt_access_old, &rt_access_tmp, sizeof(rt_access_tmp));

	//Ideally temp structure not required, In future if at all any possibility to update cpeid etc.
	//we may need a temp structure
	rt_access_tmp.f_enable = rt_access->f_enable;
	rt_access_tmp.port = rt_access->port;
	strcpy(rt_access_tmp.proto, rt_access->proto);
	
	sprintf(array_fvp[0].fieldname, "raccess_fEnable");
	sprintf(array_fvp[1].fieldname, "raccess_port");
	sprintf(array_fvp[2].fieldname, "raccess_proto");


	/* can use functions instead */
 	sprintf(array_fvp[0].value, "%d", rt_access_tmp.f_enable);
	sprintf(array_fvp[1].value, "%d", rt_access_tmp.port);
	sprintf(array_fvp[2].value, "%s", rt_access_tmp.proto);
	count = 3;
	form_cfgdb_buf(buf, count, array_fvp);

	/*Updating  User Object config*/
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_REMOTE_ACCESS, flags, 1, buf);
	if (ret != IFX_SUCCESS) {
  		IFX_DBG("[%s:%d] ERROR: Failed to write Remote Access Parmater to config file"
				, __FUNCTION__, __LINE__);
		goto Error_Handler;
 	} 

	/* Add/delete iptables rule to allow/block traffic on the mentioned port */
	/* Not specific to any protocol ? */
	if(rt_access_tmp.f_enable == rt_access_old.f_enable && rt_access_tmp.port != rt_access_old.port)
	{
#if 0
		IFX_DBG("[%s][%d] remote enable same but port change",__FUNCTION__,__LINE__);
#endif
		if(rt_access_old.f_enable == 1)
		{
			snprintf(buf, sizeof(buf), "/usr/sbin/iptables -D IFX_FW_ACCEPT_SERVICES ! -i br0 -p tcp --destination-port %d -j ACCEPT",rt_access_old.port);
			system(buf);
			snprintf(buf, sizeof(buf), "/usr/sbin/iptables -I IFX_FW_ACCEPT_SERVICES ! -i br0 -p tcp --destination-port %d -j ACCEPT",rt_access_tmp.port);
			system(buf);
		}
		else
		{
			snprintf(buf, sizeof(buf), "/usr/sbin/iptables -D IFX_FW_ACCEPT_SERVICES ! -i br0 -p tcp --destination-port %d -j DROP",rt_access_old.port);
			system(buf);
			snprintf(buf, sizeof(buf), "/usr/sbin/iptables -I IFX_FW_ACCEPT_SERVICES ! -i br0 -p tcp --destination-port %d -j DROP",rt_access_tmp.port);
			system(buf);
		}
	}
	else if(rt_access_tmp.f_enable != rt_access_old.f_enable && rt_access_tmp.port == rt_access_old.port)
	{
#if 0
		IFX_DBG("[%s][%d] remote enable chnage but port remain same\noldRemoteEnable = [%d] newRemoteEnable = [%d]\noldPort = [%d] newPort [%d]\n",__FUNCTION__,__LINE__,rt_access_old.f_enable,rt_access_tmp.f_enable,rt_access_old.port,rt_access_tmp.port);
#endif
		if(rt_access_old.f_enable == 1)
		{
			snprintf(buf, sizeof(buf), "/usr/sbin/iptables -D IFX_FW_ACCEPT_SERVICES ! -i br0 -p tcp --destination-port %d -j ACCEPT",rt_access_old.port);
			system(buf);
			snprintf(buf, sizeof(buf), "/usr/sbin/iptables -I IFX_FW_ACCEPT_SERVICES ! -i br0 -p tcp --destination-port %d -j DROP",rt_access_old.port);
			system(buf);
		}
		else
		{
			snprintf(buf, sizeof(buf), "/usr/sbin/iptables -D IFX_FW_ACCEPT_SERVICES ! -i br0 -p tcp --destination-port %d -j DROP",rt_access_old.port);
			system(buf);
			snprintf(buf, sizeof(buf), "/usr/sbin/iptables -I IFX_FW_ACCEPT_SERVICES ! -i br0 -p tcp --destination-port %d -j ACCEPT",rt_access_old.port);
			system(buf);
		}
	}
	else if(rt_access_tmp.f_enable != rt_access_old.f_enable && rt_access_tmp.port != rt_access_old.port)
	{
#if 0
		IFX_DBG("[%s][%d] remote enable chnage also port change",__FUNCTION__,__LINE__);
#endif
		if(rt_access_old.f_enable == 1)
		{
			snprintf(buf, sizeof(buf), "/usr/sbin/iptables -D IFX_FW_ACCEPT_SERVICES ! -i br0 -p tcp --destination-port %d -j ACCEPT",rt_access_old.port);
			system(buf);
			snprintf(buf, sizeof(buf), "/usr/sbin/iptables -I IFX_FW_ACCEPT_SERVICES ! -i br0 -p tcp --destination-port %d -j DROP",rt_access_tmp.port);
			system(buf);
		}
		else
		{
			snprintf(buf, sizeof(buf), "/usr/sbin/iptables -D IFX_FW_ACCEPT_SERVICES ! -i br0 -p tcp --destination-port %d -j DROP",rt_access_old.port);
			system(buf);
			snprintf(buf, sizeof(buf), "/usr/sbin/iptables -I IFX_FW_ACCEPT_SERVICES ! -i br0 -p tcp --destination-port %d -j ACCEPT",rt_access_tmp.port);
			system(buf);
		}
	}

	/* Stop stunnel service */
	system("/etc/init.d/stunnel stop");
	/* Start stunnel service */
	system("/etc/init.d/stunnel start");

Error_Handler:
	if(ret != IFX_SUCCESS) {
		IFX_DBG("%s returned failure", __FUNCTION__);
	}
	return ret;
}
