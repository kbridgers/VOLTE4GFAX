#if defined(CONFIG_PACKAGE_IFX_DSL_CPE_API)
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <time.h>
#include <string.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <sys/sysinfo.h>
#include <sys/ioctl.h>
#include <ifx_config.h>
#include <ifx_common.h>
#include <ifx_amazon_cfg.h>
#include "ifx_emf.h"
#include "ifx_snmpdefs.h"
#include "ifx_api_util.h"
#include <ifx_emf.h>
#include <sys/ioctl.h>

//#include <drv_dsl_cpe_api_config.h>
#include <drv_dsl_cpe_api.h>
#include <drv_dsl_cpe_api_ioctl.h>
#include <drv_dsl_cpe_api_g997.h>

DSL_IN DSL_DeltDataType_t gDeltDataType = DSL_DELT_DATA_SHOWTIME;

int32 ifx_mapi_get_dsl_test_params_line_status(DSL_TEST_PARAMS_LINE_STATUS *
					       pxDslTestParamsLINESTATUS,
					       uint32 flags)
{
	int32 cmd = 0, ret = IFX_SUCCESS;
	cmd = DSL_FIO_G997_LINE_STATUS_GET;
	memset(pxDslTestParamsLINESTATUS, 0x00,
	       sizeof(DSL_TEST_PARAMS_LINE_STATUS));
	pxDslTestParamsLINESTATUS->linestatus_ds.nDirection = DSL_DOWNSTREAM;
	pxDslTestParamsLINESTATUS->linestatus_ds.nDeltDataType = gDeltDataType;
	pxDslTestParamsLINESTATUS->linestatus_us.nDirection = DSL_UPSTREAM;
	pxDslTestParamsLINESTATUS->linestatus_us.nDeltDataType = gDeltDataType;
	ret =
	    ifx_cpe_api_device_get_operation(cmd,
					     (void *)
					     &(pxDslTestParamsLINESTATUS->
					       linestatus_us), flags);
	if (ret < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
		//              goto IFX_Handler;
	} else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  passed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
	}
	ret =
	    ifx_cpe_api_device_get_operation(cmd,
					     (void *)
					     &(pxDslTestParamsLINESTATUS->
					       linestatus_ds), flags);
	if (ret < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
		//              goto IFX_Handler;
	} else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  passed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
	}

//IFX_Handler:
	return IFX_SUCCESS;

}

int32 ifx_mapi_get_dsl_test_params_hlog(DSL_TEST_PARAMS_HLOG *
					pxDslTestParamsHLOG, uint32 flags)
{
	int32 cmd = 0, ret = IFX_SUCCESS;
	cmd = DSL_FIO_G997_DELT_HLOG_GET;
	memset(pxDslTestParamsHLOG, 0x00, sizeof(DSL_TEST_PARAMS_HLOG));
	pxDslTestParamsHLOG->hlog_ds.nDirection = DSL_DOWNSTREAM;
	pxDslTestParamsHLOG->hlog_ds.nDeltDataType = gDeltDataType;
	pxDslTestParamsHLOG->hlog_us.nDirection = DSL_UPSTREAM;
	pxDslTestParamsHLOG->hlog_us.nDeltDataType = gDeltDataType;
	ret =
	    ifx_cpe_api_device_get_operation(cmd,
					     (void *)&(pxDslTestParamsHLOG->
						       hlog_us), flags);
	if (ret < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
	} else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  passed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
	}
	ret =
	    ifx_cpe_api_device_get_operation(cmd,
					     (void *)&(pxDslTestParamsHLOG->
						       hlog_ds), flags);
	if (ret < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
	} else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  passed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
	}

//IFX_Handler:
	return IFX_SUCCESS;
}

int32 ifx_mapi_get_dsl_test_params_qln(DSL_TEST_PARAMS_QLN * pxDslTestParamsQLN,
				       uint32 flags)
{
	int32 cmd = 0, ret = IFX_SUCCESS;
	cmd = DSL_FIO_G997_DELT_QLN_GET;
	memset(pxDslTestParamsQLN, 0x00, sizeof(DSL_TEST_PARAMS_QLN));
	pxDslTestParamsQLN->qln_ds.nDirection = DSL_DOWNSTREAM;
	pxDslTestParamsQLN->qln_ds.nDeltDataType = gDeltDataType;
	pxDslTestParamsQLN->qln_us.nDirection = DSL_UPSTREAM;
	pxDslTestParamsQLN->qln_us.nDeltDataType = gDeltDataType;
	ret =
	    ifx_cpe_api_device_get_operation(cmd,
					     (void *)&(pxDslTestParamsQLN->
						       qln_us), flags);
	if (ret < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
		//              goto IFX_Handler;
	} else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  passed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
	}
	ret =
	    ifx_cpe_api_device_get_operation(cmd,
					     (void *)&(pxDslTestParamsQLN->
						       qln_ds), flags);
	if (ret < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
		//              goto IFX_Handler;
	} else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  passed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
	}

//IFX_Handler:
	return IFX_SUCCESS;

}

int32 ifx_mapi_get_dsl_test_params_snr(DSL_TEST_PARAMS_SNR * pxDslTestParamsSNR,
				       uint32 flags)
{
	int32 cmd = 0, ret = IFX_SUCCESS;
	cmd = DSL_FIO_G997_DELT_SNR_GET;
	memset(pxDslTestParamsSNR, 0x00, sizeof(DSL_TEST_PARAMS_SNR));
	pxDslTestParamsSNR->snr_ds.nDirection = DSL_DOWNSTREAM;
	pxDslTestParamsSNR->snr_ds.nDeltDataType = gDeltDataType;
	pxDslTestParamsSNR->snr_us.nDirection = DSL_UPSTREAM;
	pxDslTestParamsSNR->snr_us.nDeltDataType = gDeltDataType;
	ret =
	    ifx_cpe_api_device_get_operation(cmd,
					     (void *)&(pxDslTestParamsSNR->
						       snr_us), flags);
	if (ret < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
		//              goto IFX_Handler;
	} else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  passed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
	}
	ret =
	    ifx_cpe_api_device_get_operation(cmd,
					     (void *)&(pxDslTestParamsSNR->
						       snr_ds), flags);
	if (ret < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
		//              goto IFX_Handler;
	} else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  passed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
	}

//IFX_Handler:
	return IFX_SUCCESS;

}

int32
ifx_mapi_get_dsl_test_params_snr_alloc_status(DSL_TEST_PARAMS_SNR_ALLOC_STATUS *
					      pxDslTestParamsSNRALLOCSTATUS,
					      uint32 flags)
{
	int32 cmd = 0, ret = IFX_SUCCESS;
	cmd = DSL_FIO_G997_SNR_ALLOCATION_NSC_GET;
	memset(pxDslTestParamsSNRALLOCSTATUS, 0x00,
	       sizeof(DSL_TEST_PARAMS_SNR_ALLOC_STATUS));
	pxDslTestParamsSNRALLOCSTATUS->snr_alloc_status_ds.nDirection =
	    DSL_DOWNSTREAM;
	pxDslTestParamsSNRALLOCSTATUS->snr_alloc_status_us.nDirection =
	    DSL_UPSTREAM;
	ret = ifx_cpe_api_device_get_operation(cmd, (void *)
					       &(pxDslTestParamsSNRALLOCSTATUS->
						 snr_alloc_status_us), flags);
	if (ret < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
		//              goto IFX_Handler;
	} else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  passed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
	}
	ret = ifx_cpe_api_device_get_operation(cmd, (void *)
					       &(pxDslTestParamsSNRALLOCSTATUS->
						 snr_alloc_status_ds), flags);
	if (ret < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
		//              goto IFX_Handler;
	} else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  passed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
	}

//IFX_Handler:
	return IFX_SUCCESS;

}

#endif
