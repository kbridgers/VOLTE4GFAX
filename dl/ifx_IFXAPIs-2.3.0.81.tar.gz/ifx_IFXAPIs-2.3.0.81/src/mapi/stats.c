#ifndef __be16
#define __be16 short int
#endif

#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <net/if.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "ifx_common.h"
#include "ifx_amazon_cfg.h"

#include <net/if_arp.h>
#include <netinet/in.h>
#if __GLIBC__ >=2 && __GLIBC_MINOR >= 1
#include <netpacket/packet.h>
#include <net/ethernet.h>
#else
#include <asm/types.h>
#include <linux/if_ether.h>
#endif

#if 0
/* read MAX_FILELINE_LEN from _fp, search for character '\n' if found
	adjust _fp to pos_at('\n', _fp) + 1 */
#define READ_LINE_FROM_FILE(_fp, _conf_buf) { \
						memset(_conf_buf, 0x00, _conf_buf); \
						fread(_conf_buf, sizeof(_conf_buf), 1, _fp); \
						if(feof(_fp) || ferror(_fp)) {} \
						else { \
							if((_pos = strchr(_conf_buf, '\n')) != NULL) { \
								strncpy(o_buf, _conf_buf, strlen(_conf_buf) - strlen(_pos)); \
							} \
						} \
					}
#endif				// 0
char8 *string[] =
    { ".emerg", ".alert", ".crit", ".err", ".warn", ".notice", ".info",
".debug" };
int32 is_message(char8 * string1, int tmp)
{
	int i;
	for (i = 0; i <= tmp; i++)
		if (strstr(string1, string[i]))
			return (1);
	return (0);

}

/*	1. assign the buffer to a local pointer
	2. search for '\n' in the buffer pointer by this pointer
	3. if found, get this new line terminated line from the buffer
	4. search for the display filter pattern in this line
	5. if found realloc the output buffer with this line size and copy
	6. advance the pointer to '\n' + 1
	7. repeat the process till there are no more new line terminated lines
	8. apply the display filter pattern on the last line
 */
#define FILTER_SYSLOG_BUF(_filter, start_ptr) { \
	{ \
						char8	*t1_ptr = NULL, t_buf[MAX_FILELINE_LEN+1]; \
						int32	total_count = strlen(read_buf), tmp=0, t_count = 0; \
						read_count = 0; \
						switch(_filter) { \
							case SYSLOG_DISP_LEVEL_DEFAULT: \
							system("echo \"filter - default\" > /tmp/syslog_filter_level"); \
									IFX_MEM_ALLOC(sys_log->buf, char8 *, total_count + 1, sizeof(char8)) \
									memset(sys_log->buf, 0x00, total_count); \
									sprintf(sys_log->buf, "%s", read_buf); \
									break; \
							case SYSLOG_DISP_LEVEL_DEBUG: \
							system("echo \"filter - debug\" > /tmp/syslog_filter_level"); \
									tmp=SYSLOG_DISP_LEVEL_DEBUG;\
									break; \
							case SYSLOG_DISP_LEVEL_INFO: \
							system("echo \"filter - info\" > /tmp/syslog_filter_level"); \
									tmp=SYSLOG_DISP_LEVEL_INFO;\
									break; \
							case SYSLOG_DISP_LEVEL_NOTICE: \
							system("echo \"filter - notice\" > /tmp/syslog_filter_level"); \
									tmp=SYSLOG_DISP_LEVEL_NOTICE;\
									break; \
							case SYSLOG_DISP_LEVEL_WARN: \
							system("echo \"filter - warning\" > /tmp/syslog_filter_level"); \
									tmp=SYSLOG_DISP_LEVEL_WARN;\
									break; \
							case SYSLOG_DISP_LEVEL_CRIT: \
							system("echo \"filter - critical\" > /tmp/syslog_filter_level"); \
									tmp=SYSLOG_DISP_LEVEL_CRIT;\
									break; \
							case SYSLOG_DISP_LEVEL_ERR: \
							system("echo \"filter - err\" > /tmp/syslog_filter_level"); \
									tmp=SYSLOG_DISP_LEVEL_ERR;\
									break; \
							case SYSLOG_DISP_LEVEL_ALERT: \
							system("echo \"filter - alert\" > /tmp/syslog_filter_level"); \
									tmp=SYSLOG_DISP_LEVEL_ALERT;\
									break; \
							case SYSLOG_DISP_LEVEL_EMERG: \
							system("echo \"filter - emerg\" > /tmp/syslog_filter_level"); \
									tmp=SYSLOG_DISP_LEVEL_EMERG;\
									break; \
						} \
						if(_filter != SYSLOG_DISP_LEVEL_DEFAULT) { \
							system("echo \"filter - default. getting buffer\" > /tmp/syslog_filter_level"); \
							while((t_ptr = strstr(read_buf, "\n")) != NULL) { \
								memset(t_buf,'\0', sizeof(t_buf)); \
								LTQ_STRNCPY(t_buf, read_buf, t_ptr - read_buf); \
								t_count += (t_ptr - read_buf); \
								if(is_message(t_buf, tmp)){ \
									/* realloc buffer and copy */ \
									/* extra 2 bytes, 1 each for \n and \0 */ \
									t1_ptr = (char8 *)realloc(sys_log->buf, (read_count + strlen(t_buf) + 2) * sizeof(char8)); \
									if(t1_ptr == NULL) { \
										ret = IFX_FAILURE; \
										IFX_MEM_FREE(sys_log->buf); \
										goto IFX_Handler; \
									} \
			                        sys_log->buf = t1_ptr; \
									memset(sys_log->buf + read_count, 0x00, strlen(t_buf)+2); \
									strcat(sys_log->buf, t_buf); \
									strcat(sys_log->buf, "\n"); \
									read_count += strlen(t_buf) + 2; \
								} \
								/* advance the pointer after '\n' */ \
								if(t_count < total_count) \
									read_buf = t_ptr + 1; \
							} \
							if(strlen(read_buf) && is_message(t_buf, tmp)) { \
								/* realloc buffer and copy */ \
								t1_ptr = (char8 *)realloc(sys_log->buf, (read_count + strlen(read_buf) + 1) * sizeof(char8)); \
								if(t1_ptr == NULL) { \
									ret = IFX_FAILURE; \
									IFX_MEM_FREE(sys_log->buf); \
									goto IFX_Handler; \
								} \
			                    sys_log->buf = t1_ptr; \
								memset(sys_log->buf + read_count, 0x00, strlen(read_buf)+1); \
								strcat(sys_log->buf, read_buf); \
								read_count += strlen(read_buf); \
							} \
						} \
			} \
	}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_if_stats(...)
*	iface		==>	input name of the interface for which stats have to be returned
*	if_stats	==>	output pointer to the IF_STATS structure which will store the
*				interface configuration
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads the interface stats for the input interface iface
  			and returns them in the structure pointer if_stats.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_if_stats(char8 * iface, IF_STATS * if_stats, uint32 flags)
{
	char buf[MAX_FILELINE_LEN];
	FILE *fd = NULL;
	int32 ret = IFX_SUCCESS, rx_fifo = 0, rx_frame = 0, rx_comp =
	    0, rx_mult = 0;

	if (iface == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* call the script with the input interface name
	 * the script will write the interface stats in the /tmp/if_stats file */
	buf[0] = '\0';
	sprintf(buf, "/etc/rc.d/rc.getIfStats %s", iface);
	system(buf);

	fd = fopen("/tmp/if_stats", "r");
	if (fd == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* read the required parameters from the stats file and store it in the output
	 * structure if_stats */
//              fscanf(fd, " %s\n%lu\n%lu\n%lu\n%lu\n%lu\n%lu\n%lu\n%lu\n", iface, &if_stats->rx_bytes, &if_stats->rx_pkts,
	memset(buf, 0x00, sizeof(buf));
	fscanf(fd, " %s %lu %lu %lu %lu %d %d %d %d %lu %lu %lu %lu ", buf,
	       &if_stats->rx_bytes, &if_stats->rx_pkts,
	       &if_stats->rx_error_pkts, &if_stats->rx_discard_pkts, &rx_fifo,
	       &rx_frame, &rx_comp, &rx_mult, &if_stats->tx_bytes,
	       &if_stats->tx_pkts, &if_stats->tx_error_pkts,
	       &if_stats->tx_discard_pkts);

      IFX_Handler:
	if (fd)
		fclose(fd);
	/* remove the if_stats file */
	remove("/tmp/if_stats");
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return IFX_FAILURE;
	} else
		return IFX_SUCCESS;
}

int32 ifx_get_ifstats(char8 * name, IF_STATS * if_stats, uint32 flag)
{
	FILE *fp;
	char word[24], *temp;
	char ifname[24] = { 0 };
	char tmp[24];

	if ((name == NULL) || (strlen(name) >= 23))
		return IFX_FAILURE;

	strcpy(ifname, name);
	strcat(ifname, ":");

	fp = fopen("/proc/net/dev", "r");
	if (fp == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;
	}
	// word=(char*)malloc(24*sizeof(char));
	while (fscanf(fp, "%24s", word) != EOF) {
		if (strstr(word, ifname) != NULL) {
			temp = strchr(word, ':');
			if (strlen(ifname) != strlen(word))
				if_stats->rx_bytes = atoi(temp + 1);
			else

				fscanf(fp, " %lu", &if_stats->rx_bytes);

			fscanf(fp, "%lu %lu %lu %s %s %s %s %lu %lu %lu %lu",
			       &if_stats->rx_pkts, &if_stats->rx_error_pkts,
			       &if_stats->rx_discard_pkts, tmp, tmp, tmp, tmp,
			       &if_stats->tx_bytes, &if_stats->tx_pkts,
			       &if_stats->tx_error_pkts,
			       &if_stats->tx_discard_pkts);
			//fscanf(fp,"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",&if_stats->rx_pkts,&if_stats->rx_error_pkts,&if_stats->rx_discard_pkts,temp,temp,temp,temp,&if_stats->tx_bytes,&if_stats->tx_pkts,&if_stats->tx_error_pkts,&if_stats->tx_discard_pkts,temp,temp,temp,temp);
			//*flag=1;

		}
	}

	fclose(fp);
	return IFX_SUCCESS;
}

#ifdef CONFIG_FEATURE_LTQ_TR69_NETDEV_ADVSTATS
/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_ifadvstats(...)
*	iface		==>	input name of the interface for which stats have to be returned
*	if_stats	==>	output pointer to the IF_STATS structure which will store the
*				interface configuration
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
*	Description:
*			This function reads the advance stats counters for the input interface
*			iface and returns them in the structure pointer if_stats.
*//////////////////////////////////////////////////////////////////////////////

#define ADVSTATS_MEMB(st) \
	st->rx_unicast_pkts=st->tx_unicast_pkts=\
	st->rx_multicast_pkts=st->tx_multicast_pkts=\
	st->rx_broadcast_pkts=st->tx_broadcast_pkts=\
	st->rx_unknownproto_pkts

int32 ifx_get_ifadvstats(char8 *name, IF_STATS *if_stats, uint flag)
{
	FILE *fp;
	char word[24];
	char ifname[24] = { 0 };

	if ((name == NULL) || (strlen(name) >= 23))
		return IFX_FAILURE;

	strcpy(ifname, name);
	strcat(ifname, ":");

	ADVSTATS_MEMB(if_stats) = 0;

	fp = fopen("/proc/net/advstats", "r");
	if (fp == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;
	}

	while (fscanf(fp, "%24s", word) != EOF) {
		if (strstr(word, ifname) != NULL) {
			fscanf(fp, "%lu %lu %lu %lu %lu %lu %lu",
			       &if_stats->rx_unicast_pkts, &if_stats->rx_multicast_pkts,
			       &if_stats->rx_broadcast_pkts, &if_stats->rx_unknownproto_pkts,
			       &if_stats->tx_unicast_pkts, &if_stats->tx_multicast_pkts,
			       &if_stats->tx_broadcast_pkts);
		}
	}

	fclose(fp);
	return IFX_SUCCESS;
}
#endif

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_wan_if_stats(...)
*	iid		==>	pointer to IFX_ID structure
*	wan_index	==>	index of the wan connection
*	iface		==>	output interface name of the wan connection
*	if_stats	==>	output pointer to IF_STATS structure which will store
*				the interface stats of iface
*	flags		==>	
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function searches for a wan connection based on either the input iid
			or input wan_index. One of these two is a mandatory field. Given one of
			them the function returns the value for the other field. Based on these 
			two the function returns the physical interface name for this wan connection
			and returns in iface. Also the interface stats for this iface will be
  			returned in if_stats.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_wan_if_stats(IFX_ID * iid, int32 wan_index, char8 * iface,
			   IF_STATS * if_stats, uint32 flags)
{
	int32 ret = IFX_SUCCESS, outFlag = IFX_F_DEFAULT;
	char8 *retStr = NULL;
	char8 sValue[MAX_FILELINE_LEN], wan_iface[IFNAMSIZE],
	    wan_connname[MAX_CONN_NAME_LEN], secName[MAX_FILELINE_LEN];
	char8 sCommand[MAX_FILELINE_LEN];

	sValue[0] = '\0';
	wan_iface[0] = '\0';
	wan_connname[0] = '\0';
	sCommand[0] = '\0';

	if (iface != NULL) {
		// from TR69
		/* get the wan connection name for the input interface name */
		/* TBD: this is chicken and egg prob ! */
		if (!strcmp(iface, "ppp")) {
			sprintf(secName, "%s", TAG_WAN_PPP);
			ifx_get_wan_connName_from_ifname(wan_connname, iface,
							 WAN_TYPE_PPP);
		} else {
			sprintf(secName, "%s", TAG_WAN_IP);
			ifx_get_wan_connName_from_ifname(wan_connname, iface,
							 WAN_TYPE_IP);
		}
		/* get the wan substring retStr of the form wan_{index} for this wan connection name */
		ret =
		    ifx_ret_substr_from_distfield(FILE_RC_CONF, secName,
						  "connName", wan_connname,
						  &retStr);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("[%s:%d]failed to get substring out of distinct string !!\n",
			     __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		/* get the cpeid for the wan connection with substring retStr */
		sprintf(sCommand, "%s_cpeId", retStr);
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, secName, sCommand,
				    IFX_F_GET_ENA, (IFX_OUT uint32 *) & outFlag,
				    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		iid->cpeId.Id = atoi(sValue);

		/* get the parent cpeid for the wan connection with substring retStr */
		sprintf(sCommand, "%s_pcpeId", retStr);
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, secName, sCommand,
				    IFX_F_GET_ENA, (IFX_OUT uint32 *) & outFlag,
				    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		iid->pcpeId.Id = atoi(sValue);

		/* get the wan index out of the substring retStr */
		wan_index = atoi(strrchr(retStr, '_') + 1);

		sprintf(wan_iface, "%s", iface);
	}
#if 0				/* TBD: this condition might not be supported */
	else if (wan_index > 0) {	// from Web
		/* get the wan connection name for wan with index wan_index */
		sprintf(sCommand, "wan_%d_connName", wan_index);
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, sCommand,
				    IFX_F_GET_ANY, NULL,
				    wan_connname)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		/* cpeId is not given, get cpeId and pcpeId from rc.conf for the wan connection
		 * with index wan_index */
		sprintf(sCommand, "wan_%d_cpeId", wan_index);
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, sCommand,
				    IFX_F_GET_ANY, NULL,
				    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		iid->cpeId.Id = atoi(sValue);

		sprintf(sCommand, "wan_%d_pcpeId", wan_index);
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, sCommand,
				    IFX_F_GET_ANY, NULL,
				    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		iid->pcpeId.Id = atoi(sValue);

		/* Get the wan interface name from the retStr which is like wan_2, wan_4, .... */
		ret = ifx_get_wan_ifname_from_connName(wan_connname, wan_iface);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
	}
#endif				// 0

	else if (iid->cpeId.Id > 0) {
		/* get the wan substring retStr of the form wan_{index} for the cpeid specified
		 * from wan_main section */
		/* TBD: input section name is must */
		sprintf(sCommand, "%d", iid->cpeId.Id);
		ret =
		    ifx_ret_substr_from_distfield(FILE_RC_CONF,
						  iid->cpeId.secName, "cpeId",
						  sCommand, &retStr);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("[%s:%d]failed to get substring out of distinct string !!\n",
			     __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		/* get the connection name for this wan with substring retStr */
		sprintf(sCommand, "%s_connName", retStr);
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, iid->cpeId.secName, sCommand,
				    IFX_F_GET_ANY, NULL,
				    wan_connname)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		/* Get the wan interface name from the retStr which is like wan_2, wan_4, .... */
		if (!strcmp(iid->cpeId.secName, TAG_WAN_IP))
			ret =
			    ifx_get_wan_ifname_from_connName(wan_connname,
							     wan_iface,
							     WAN_TYPE_IP);
		else
			ret =
			    ifx_get_wan_ifname_from_connName(wan_connname,
							     wan_iface,
							     WAN_TYPE_PPP);

		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
	}

	else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	snprintf(iid->pcpeId.secName, strlen(TAG_WAN_CONN_DEVICE), "%s",
		 TAG_WAN_CONN_DEVICE);

	/* call the function to get the interface stats for the wan interface wan_iface
	 * in the output structure if_stats */
	ret = ifx_get_ifstats(wan_iface, if_stats, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

#ifdef CONFIG_FEATURE_LTQ_TR69_NETDEV_ADVSTATS
	ret = ifx_get_ifadvstats(wan_iface, if_stats, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		//goto IFX_Handler;
	}
#endif

      IFX_Handler:
	IFX_MEM_FREE(retStr)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

//#ifdef LAN_WAN_STATS
int32 ifx_get_all_wan_if_stats(int32 * wan_count, IFACE_STATS ** iface_stats,
			       uint32 flags)
{
	char8 ifName[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN];
	char8 sIndexes[MAX_FILELINE_LEN], connName[MAX_FILELINE_LEN];
	int32 ret = IFX_SUCCESS, idx_count = 0, *idx_array = NULL, i =
	    0, wipCnt = 0, wpppCnt = 0, j = 0;

	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	NULL_TERMINATE(sIndexes, 0x00, sizeof(sIndexes));

	if (ifx_get_sec_count(TAG_WAN_IP, &wipCnt) != IFX_SUCCESS) {

	}

	if (ifx_get_sec_count(TAG_WAN_PPP, &wpppCnt) != IFX_SUCCESS) {

	}

	idx_count = wipCnt + wpppCnt;

	/* alloc for iface_stats */
	IFX_MEM_ALLOC((*iface_stats), IFACE_STATS *, idx_count,
		      sizeof(IFACE_STATS))

	    if (*iface_stats == NULL) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	for (i = 0, j = 0; i < wipCnt; i++, j++) {
		NULL_TERMINATE(buf, 0x00, sizeof(buf));
		NULL_TERMINATE(connName, 0x00, sizeof(connName));
		NULL_TERMINATE(ifName, 0x00, sizeof(ifName));

		if (GetWanIface(i, ifName, WAN_TYPE_IP) != IFX_SUCCESS) {

		}

		/* copy interface name and wan index to iface_stats */
		(*iface_stats + j)->wan_index = i;
		snprintf((*iface_stats + j)->iface,MAX_NAME_SIZE, "%s", ifName);

		/* call ifx_get_ifstats for each of the interfaces */
		ifx_get_ifstats((*iface_stats + j)->iface,
				&(*iface_stats + j)->stats, flags);
	}

	for (i = 0; i < wpppCnt; i++, j++) {
		NULL_TERMINATE(buf, 0x00, sizeof(buf));
		NULL_TERMINATE(connName, 0x00, sizeof(connName));
		NULL_TERMINATE(ifName, 0x00, sizeof(ifName));

		if (GetWanIface(i, ifName, WAN_TYPE_PPP) != IFX_SUCCESS) {

		}

		/* copy interface name and wan index to iface_stats */
		(*iface_stats + j)->wan_index = i;
		snprintf((*iface_stats + j)->iface,MAX_NAME_SIZE, "%s", ifName);

		/* call ifx_get_ifstats for each of the interfaces */
		ifx_get_ifstats((*iface_stats + j)->iface,
				&(*iface_stats + j)->stats, flags);
	}

	*wan_count = idx_count;

      IFX_Handler:
	IFX_MEM_FREE(idx_array)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		IFX_MEM_FREE(*iface_stats)
		    return ret;
	} else
		return IFX_SUCCESS;
}

int32 ifx_get_all_lan_if_stats(IFACE_STATS ** iface_stats, uint32 flags)
{
	int32 i, ret = IFX_SUCCESS;
	/* alloc for iface_stats */
	IFX_MEM_ALLOC(*iface_stats, IFACE_STATS *, 2, sizeof(IFACE_STATS))	/* hard coded to include eth0 and usb0 */
	    memset(*iface_stats, 0x00, 2 * sizeof(IFACE_STATS));

	/* call ifx_get_ifstats for each of the interfaces */
	for (i = 0; i < 2; i++) {
		/* copy hard coded interface names to iface_stats */
		if (i == 0)
			sprintf((*iface_stats + i)->iface, "%s", "eth0");
		else
			sprintf((*iface_stats + i)->iface, "%s", "usb0");

		ifx_get_ifstats((*iface_stats + i)->iface,
				&(*iface_stats + i)->stats, flags);
	}

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		IFX_MEM_FREE(*iface_stats)
		    return ret;
	} else
		return IFX_SUCCESS;
}

//#endif

int32 ifx_get_syslog_info(SYSLOG_INFO * sys_log, uint32 flags)
{
	int32 ret = IFX_SUCCESS;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 conf_buf[MAX_FILELINE_LEN + 1], sValue[MAX_FILELINE_LEN],
	    *read_buf = NULL;
	FILE *fp = NULL;

	NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));
	sys_log->buf = NULL;

	/* read the syslog mode */
	memset(sValue, 0x00, sizeof(sValue));
	memset(conf_buf, 0x00, sizeof(conf_buf));
	sprintf(conf_buf, "%s_mode", TAG_SYSTEM_LOG);
	ret =
	    ifx_GetObjData(FILE_RC_CONF, TAG_SYSTEM_LOG, conf_buf, flags,
			   &outFlag, sValue);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	sys_log->mode = atoi(sValue);

	/* read the remote ip */
	memset(sValue, 0x00, sizeof(sValue));
	memset(conf_buf, 0x00, sizeof(conf_buf));
	sprintf(conf_buf, "%s_IP", TAG_SYSTEM_LOG);
	ret =
	    ifx_GetObjData(FILE_RC_CONF, TAG_SYSTEM_LOG, conf_buf, flags,
			   &outFlag, sValue);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	sys_log->remote_ip.s_addr = inet_addr(sValue);

	/* read the remote port */
	memset(sValue, 0x00, sizeof(sValue));
	memset(conf_buf, 0x00, sizeof(conf_buf));
	sprintf(conf_buf, "%s_port", TAG_SYSTEM_LOG);
	ret =
	    ifx_GetObjData(FILE_RC_CONF, TAG_SYSTEM_LOG, conf_buf, flags,
			   &outFlag, sValue);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	sys_log->port = atoi(sValue);

	/* read the log level mode */
	memset(sValue, 0x00, sizeof(sValue));
	memset(conf_buf, 0x00, sizeof(conf_buf));
	sprintf(conf_buf, "%s_log_level", TAG_SYSTEM_LOG);
	ret =
	    ifx_GetObjData(FILE_RC_CONF, TAG_SYSTEM_LOG, conf_buf, flags,
			   &outFlag, sValue);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	sys_log->log_level = atoi(sValue);

	ret = IFX_SUCCESS;
      IFX_Handler:
	if (fp != NULL)
		fclose(fp);
	if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(read_buf)
		    IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

int32 ifx_get_syslog_info_filter(SYSLOG_DISP_LEVEL log_level,
				 SYSLOG_INFO * sys_log, uint32 flags)
{
	int32 ret = IFX_SUCCESS;
	int32 read_count = 0;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 conf_buf[MAX_FILELINE_LEN + 1], sValue[MAX_FILELINE_LEN],
	    *read_buf = NULL, *t_ptr = NULL, *t1_ptr = NULL;
	FILE *fp = NULL;

	NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));
	sys_log->buf = NULL;

	/* read the syslog mode */
	memset(sValue, 0x00, sizeof(sValue));
	memset(conf_buf, 0x00, sizeof(conf_buf));
	sprintf(conf_buf, "%s_mode", TAG_SYSTEM_LOG);
	ret =
	    ifx_GetObjData(FILE_RC_CONF, TAG_SYSTEM_LOG, conf_buf, flags,
			   &outFlag, sValue);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	sys_log->mode = atoi(sValue);

	/* read the remote ip */
	memset(sValue, 0x00, sizeof(sValue));
	memset(conf_buf, 0x00, sizeof(conf_buf));
	sprintf(conf_buf, "%s_IP", TAG_SYSTEM_LOG);
	ret =
	    ifx_GetObjData(FILE_RC_CONF, TAG_SYSTEM_LOG, conf_buf, flags,
			   &outFlag, sValue);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	sys_log->remote_ip.s_addr = inet_addr(sValue);

	/* read the remote port */
	memset(sValue, 0x00, sizeof(sValue));
	memset(conf_buf, 0x00, sizeof(conf_buf));
	sprintf(conf_buf, "%s_port", TAG_SYSTEM_LOG);
	ret =
	    ifx_GetObjData(FILE_RC_CONF, TAG_SYSTEM_LOG, conf_buf, flags,
			   &outFlag, sValue);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	sys_log->port = atoi(sValue);

	ret = IFX_SUCCESS;
	/* Should be no IFX_DBG used till fclose, may crash otherwise */
	sprintf(conf_buf, "%s", FILE_MESSAGES);
	/* open FILE_MESSAGES to read the log */
	fp = fopen(conf_buf, "a+");
	if (fp == NULL) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	if (feof(fp) || ferror(fp)) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* Read MAX_FILELINE_LEN chunks from FILE_MESSAGES, realloc the destination buffer to hold this read buffer
	   append the read buffer into destination buffer and increment the read count */
	/* Read the whole log messages into buffer, use strstr on this buffer to read
	   each null terminated line and compare this line for the filter display level */
	while (!feof(fp)) {
		memset(conf_buf, 0x00, sizeof(conf_buf));
		fread(conf_buf, MAX_FILELINE_LEN, 1, fp);
		conf_buf[sizeof(conf_buf) - 1] = '\0';
		if (strlen(conf_buf)) {
			t_ptr =
			    (char8 *) realloc(read_buf,
					      (read_count + strlen(conf_buf) +
					       1) * sizeof(char8));
			if (t_ptr == NULL) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}

			read_buf = t_ptr;

			memset(read_buf + read_count, 0x00,
			       strlen(conf_buf) + 1);
			if (read_buf == NULL) {
				IFX_MEM_FREE(read_buf)
				    ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			strcat(read_buf, conf_buf);
			read_count += strlen(conf_buf);

			if (feof(fp) || ferror(fp))
				break;

		}

	}

	if (read_buf != NULL) {
		t1_ptr = read_buf;
		FILTER_SYSLOG_BUF(log_level, read_buf)
	}

      IFX_Handler:
	if (fp != NULL)
		fclose(fp);
	IFX_MEM_FREE(t1_ptr)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

int32 ifx_set_syslog_info(int32 operation, SYSLOG_INFO * sys_log, uint32 flags)
{
	int32 ret = IFX_SUCCESS;
	int32 count = 0;
	char8 conf_buf[MAX_FILELINE_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[5];

	memset(conf_buf, 0x00, sizeof(conf_buf));
	memset(array_fvp, 0x00, sizeof(array_fvp));

	/*************** Prolog Block ****************/
	/* Based on operation (ADD or DEL or MOD) 
	 * append the flag with internal flags. For other ops, 
	 * the flag denotes the action */
	if (operation == IFX_OP_MOD)
		flags |= IFX_F_MODIFY;

	/************* Validation Block **************/
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(sys_log)
		    /* Do simple validation of flags sucha as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

	/*********** Name Value Formation As Per RC.CONF ****************/
	sprintf(array_fvp[0].fieldname, "%s_mode", TAG_SYSTEM_LOG);
	sprintf(array_fvp[0].value, "%d", sys_log->mode);
	sprintf(array_fvp[1].fieldname, "%s_port", TAG_SYSTEM_LOG);
	sprintf(array_fvp[1].value, "%d", sys_log->port);
	sprintf(array_fvp[2].fieldname, "%s_IP", TAG_SYSTEM_LOG);
	sprintf(array_fvp[2].value, "%s", inet_ntoa(sys_log->remote_ip));
	sprintf(array_fvp[3].fieldname, "%s_log_level", TAG_SYSTEM_LOG);
	sprintf(array_fvp[3].value, "%d", sys_log->log_level);

	count = 4;

	/********* System Config File Update Block  **********/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);

	ret = ifx_SetObjData(FILE_RC_CONF, TAG_SYSTEM_LOG, flags, 1, conf_buf);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/************ Device Configuration Block ***********/
	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
		/* start syslogd daemon based on the mode configured */
		switch (sys_log->mode) {
		case SYSLOG_LOCAL:
			sprintf(conf_buf, "syslogd -s %d -b %d -l %d",
				CONFIG_FEATURE_SYSTEM_LOG_BUFFER_SIZE,
				CONFIG_FEATURE_SYSTEM_LOG_BUFFER_COUNT,
				sys_log->log_level);
			break;
		case SYSLOG_REMOTE:
			if (sys_log->port > 0)
				sprintf(conf_buf, "syslogd -R %s:%d -l %d",
					inet_ntoa(sys_log->remote_ip),
					sys_log->port, sys_log->log_level);
			else
				sprintf(conf_buf, "syslogd -R %s -l %d",
					inet_ntoa(sys_log->remote_ip),
					sys_log->log_level);
			break;
		case SYSLOG_BOTH_LOCAL_REMOTE:
			if (sys_log->port > 0)
				sprintf(conf_buf,
					"syslogd -L -s %d -b %d -R %s:%d -l %d",
					CONFIG_FEATURE_SYSTEM_LOG_BUFFER_SIZE,
					CONFIG_FEATURE_SYSTEM_LOG_BUFFER_COUNT,
					inet_ntoa(sys_log->remote_ip),
					sys_log->port, sys_log->log_level);
			else
				sprintf(conf_buf,
					"syslogd -L -s %d -b %d -R %s -l %d",
					CONFIG_FEATURE_SYSTEM_LOG_BUFFER_SIZE,
					CONFIG_FEATURE_SYSTEM_LOG_BUFFER_COUNT,
					inet_ntoa(sys_log->remote_ip),
					sys_log->log_level);
			break;
		}

		/* stop the syslogd daemon */
		system("killall -9 syslogd");

		/* start the syslog daemon */
		system(conf_buf);
	}			// IFX_DONT_ACTIVATE_F_NOT_SET

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

static int in_ether(char *bufp, struct sockaddr *sap)
{
	unsigned char *ptr;
	int i, j;
	unsigned char val;
	unsigned char c;
	int ret = IFX_SUCCESS;

	sap->sa_family = ARPHRD_ETHER;
	ptr = (unsigned char *)sap->sa_data;

	i = 0;
	do {
		j = val = 0;

		/* We might get a semicolon here - not required. */
		if (i && (*bufp == ':')) {
			bufp++;
		}

		do {
			c = *bufp;
			if (((unsigned char)(c - '0')) <= 9) {
				c -= '0';
			} else if (((unsigned char)((c | 0x20) - 'a')) <= 5) {
				c = (c | 0x20) - ('a' - 10);
			} else if (j && (c == ':' || c == 0)) {
				break;
			} else {
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			++bufp;
			val <<= 4;
			val += c;
		} while (++j < 2);
		*ptr++ = val;
	} while (++i < ETH_ALEN);

      IFX_Handler:
	return ret;		/* Error if we don't end at end of string. */

}

int32 ifx_mod_interface_attr(char8 * name, int32 oper, NET_INTF_CFG * params)
{
	int32 a = -1;
	int32 ret = IFX_SUCCESS;
	struct ifreq ifr;
	struct sockaddr_in *soad;

	if (strlen(name) >= IFNAMSIZ) {
		IFX_DBG("[%s:%d],%s", __FUNCTION__, __LINE__,
			"Name size is large");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	strcpy(ifr.ifr_name, name);
	a = socket(AF_INET, SOCK_STREAM, 0);
	if (a == -1) {
		IFX_DBG("[%s:%d],%s", __FUNCTION__, __LINE__,
			"Socket creation failed");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	if (oper == IFX_GET_INTF_ATTR) {

		soad = (struct sockaddr_in *)&ifr.ifr_addr;
		if (ioctl(a, SIOCGIFADDR, &ifr) != 0) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		} else {
			strcpy(params->ipaddr, inet_ntoa(soad->sin_addr));
		}
		soad = (struct sockaddr_in *)&ifr.ifr_netmask;
		if (ioctl(a, SIOCGIFNETMASK, &ifr) != 0) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		} else {
			strcpy(params->netmask, inet_ntoa(soad->sin_addr));
		}
		if (ioctl(a, SIOCGIFMTU, &ifr) != 0) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		} else {
			params->mtu = ifr.ifr_mtu;
		}
		soad = (struct sockaddr_in *)&ifr.ifr_hwaddr;
		if (ioctl(a, SIOCGIFHWADDR, (caddr_t) & ifr) != 0) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		} else {
			sprintf(params->hwaddr, "%02x:%02x:%02x:%02x:%02x:%02x",
				(int)((unsigned char *)&ifr.ifr_hwaddr.
				      sa_data)[0],
				(int)((unsigned char *)&ifr.ifr_hwaddr.
				      sa_data)[1],
				(int)((unsigned char *)&ifr.ifr_hwaddr.
				      sa_data)[2],
				(int)((unsigned char *)&ifr.ifr_hwaddr.
				      sa_data)[3],
				(int)((unsigned char *)&ifr.ifr_hwaddr.
				      sa_data)[4],
				(int)((unsigned char *)&ifr.ifr_hwaddr.
				      sa_data)[5]);
		}
		if (ioctl(a, SIOCGIFFLAGS, &ifr) != 0) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		} else {
			params->admin = (ifr.ifr_flags % 2);
		}
	} else if (oper == IFX_SET_INTF_ATTR) {

		if (strcmp(params->ipaddr, "")) {
			soad = (struct sockaddr_in *)&ifr.ifr_addr;
			soad->sin_family = AF_INET;
			inet_aton(params->ipaddr, (struct in_addr *)soad);
			if (ioctl(a, SIOCSIFADDR, (caddr_t) & ifr) != 0) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
		if (strcmp(params->hwaddr, "")) {
			soad = (struct sockaddr_in *)&ifr.ifr_hwaddr;
			//soad->sin_family=AF_INET;
			//soad->sin_addr.s_addr=inet_addr(params->hwaddr);
			if (in_ether(params->hwaddr, (struct sockaddr *)soad) !=
			    0) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;

			}
			if (ioctl(a, SIOCSIFHWADDR, &ifr) != 0) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
		if (strcmp(params->netmask, "")) {
			soad = (struct sockaddr_in *)&ifr.ifr_netmask;
			soad->sin_family = AF_INET;
			inet_aton(params->netmask, (struct in_addr *)soad);
			if (ioctl
			    (a, SIOCSIFNETMASK, (caddr_t) & ifr,
			     sizeof(struct ifreq)) != 0) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
		if (params->mtu != -1) {
			ifr.ifr_mtu = params->mtu;
			if (ioctl(a, SIOCSIFMTU, &ifr) != 0) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
		if ((params->admin == 0) || (params->admin == 1)) {
			ioctl(a, SIOCGIFFLAGS, &ifr);
			if ((ifr.ifr_flags % 2 == 1) && (params->admin == 0)) {
				ifr.ifr_flags--;
				if (ioctl(a, SIOCSIFFLAGS, &ifr) != 0) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d]", __FUNCTION__,
						__LINE__);
#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}
			} else if ((ifr.ifr_flags % 2 == 0)
				   && (params->admin == 1)) {
				ifr.ifr_flags++;
				if (ioctl(a, SIOCSIFFLAGS, &ifr) != 0) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d]", __FUNCTION__,
						__LINE__);
#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}
			}
		}

	}

      IFX_Handler:
	if (a >= 0)
		close(a);
	return ret;

}
