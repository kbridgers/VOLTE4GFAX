/* Copyright (c) 2010, Lantiq Communications
 *
 *  Management API's for dual wan feature
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <syslog.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"

#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT

int32 dw_check_ip_url(char8 *IpUrlStr, char8 *retStr)
{
	char8 inStr[MAX_URL_LEN] = {0};
#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d], InComing str = %s", __FUNCTION__, __LINE__, IpUrlStr);
#endif
	strcpy(inStr, IpUrlStr);
	if (isalpha(inStr[0])) {
		strcpy(retStr, "URL");
	} else if (isdigit(inStr[0])) {
		strcpy(retStr, "IP");
	} else {
		return IFX_FAILURE;
	}
#ifdef IFX_LOG_DEBUG
	IFX_DBG("result str = %s", retStr);
#endif
	return IFX_SUCCESS;
}

int32 dw_wan_phy_cfg_set(uint32 oper, dw_config_info_t * dw_attr, uint32 flags)
{
	int32 ret = IFX_SUCCESS;
	char8 buf[MAX_FILELINE_LEN * 3];
	IFX_NAME_VALUE_PAIR array_fvp[DW_ATTTIBUTES_COUNT];
	uint32 count = DW_ATTTIBUTES_COUNT;

	NULL_TERMINATE(buf, 0, sizeof(buf));
	memset(array_fvp, 0, sizeof(array_fvp));

	if ((oper == IFX_OP_DEL) || (oper == IFX_OP_ADD)) {
		flags |= IFX_F_MODIFY;
	} else
		flags |= IFX_F_MODIFY;

	if (dw_attr) {
		sprintf(array_fvp[0].fieldname, DW_FAILOVER);
		sprintf(array_fvp[0].value, "%d", dw_attr->fo_state);

		sprintf(array_fvp[1].fieldname, DW_STANDBY);
		sprintf(array_fvp[1].value, "%d", dw_attr->fo_type);

		sprintf(array_fvp[2].fieldname, DW_PROBE_INT);
		sprintf(array_fvp[2].value, "%d",
			dw_attr->probe_info.probe_int);

		sprintf(array_fvp[3].fieldname, DW_PROBE_RET);
		sprintf(array_fvp[3].value, "%d",
			dw_attr->probe_info.probe_retry);

		sprintf(array_fvp[4].fieldname, DW_IP);
		sprintf(array_fvp[4].value, "%s",
			dw_attr->probe_info.probe_ip_url);

				/*---------------------------------------------------------------*/

		sprintf(array_fvp[5].fieldname, DW_P_TC);
		sprintf(array_fvp[5].value, "%d", dw_attr->pri_wan_cfg.wan_tc);

		sprintf(array_fvp[6].fieldname, DW_P_PHY);
		sprintf(array_fvp[6].value, "%d",
			dw_attr->pri_wan_cfg.phy_mode);

		sprintf(array_fvp[7].fieldname, DW_P_SETTC);
		sprintf(array_fvp[7].value, "%d",
			dw_attr->pri_wan_cfg.set_wan_tc);

		sprintf(array_fvp[8].fieldname, DW_P_SETPHY);
		sprintf(array_fvp[8].value, "%d",
			dw_attr->pri_wan_cfg.set_phy_mode);
#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
		sprintf(array_fvp[9].fieldname, DW_P_PTM_VLAN);
		sprintf(array_fvp[9].value, "%d",
			dw_attr->pri_wan_cfg.ptm_vlan_mode);
#endif

#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
		sprintf(array_fvp[10].fieldname, DW_P_MII_VLAN);
		sprintf(array_fvp[10].value, "%d",
			dw_attr->pri_wan_cfg.eth_mii1_vlan_mode);
#endif

		sprintf(array_fvp[11].fieldname, DW_P_TR69);
		sprintf(array_fvp[11].value, "%s",
			dw_attr->pri_wan_cfg.tr69_encaprequested);

				/*---------------------------------------------------------------*/

		sprintf(array_fvp[12].fieldname, DW_S_TC);
		sprintf(array_fvp[12].value, "%d", dw_attr->sec_wan_cfg.wan_tc);

		sprintf(array_fvp[13].fieldname, DW_S_PHY);
		sprintf(array_fvp[13].value, "%d",
			dw_attr->sec_wan_cfg.phy_mode);

		sprintf(array_fvp[14].fieldname, DW_S_SETTC);
		sprintf(array_fvp[14].value, "%d",
			dw_attr->sec_wan_cfg.set_wan_tc);

		sprintf(array_fvp[15].fieldname, DW_S_SETPHY);
		sprintf(array_fvp[15].value, "%d",
			dw_attr->sec_wan_cfg.set_phy_mode);

#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
		sprintf(array_fvp[16].fieldname, DW_S_PTM_VLAN);
		sprintf(array_fvp[16].value, "%d",
			dw_attr->sec_wan_cfg.ptm_vlan_mode);
#endif

#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
		sprintf(array_fvp[17].fieldname, DW_S_MII_VLAN);
		sprintf(array_fvp[17].value, "%d",
			dw_attr->sec_wan_cfg.eth_mii1_vlan_mode);
#endif

		sprintf(array_fvp[18].fieldname, DW_S_TR69);
		sprintf(array_fvp[18].value, "%s",
			dw_attr->sec_wan_cfg.tr69_encaprequested);
	}

	form_cfgdb_buf(buf, count, array_fvp);

	ret = ifx_SetObjData(FILE_RC_CONF, TAG_DUAL_WAN_CFG, flags, 1, buf);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	if (ret != IFX_SUCCESS)
		IFX_API_LOG("s3 [%s] returned failure!", __FUNCTION__);
	return ret;
}

int32 dw_mapi_cfg_get(dw_config_info_t * dw_attr, uint32 flags)
{
	int32 ret = IFX_SUCCESS, outFlag = IFX_F_DEFAULT;
	int32 ret_cache = IFX_SUCCESS;

	char8 sValue[MAX_NAME_SIZE], buf[MAX_FILELINE_LEN];

	sprintf(buf, "%s_", PREFIX_DUAL_WAN);
	if (ifx_GetObjDataOpt
	    (FILE_RC_CONF, TAG_DUAL_WAN_CFG, buf, IFX_F_INT_CACHE_INIT | flags,
	     NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance",
			__FUNCTION__, __LINE__);
#endif
		ret = ret_cache = IFX_FAILURE;

		goto IFX_Handler;
	}

	inline char8 *read_file_cache(char *attr) {
		sprintf(buf, "%s", attr);
		if ((ret =
		     ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DUAL_WAN_CFG, buf,
				       flags, (IFX_OUT uint32 *) & outFlag,
				       sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve %s", __FUNCTION__,
				__LINE__, buf);
#endif
			ret = IFX_FAILURE;
			return NULL;
		}
		ret = IFX_SUCCESS;
		return sValue;
	}

	if (read_file_cache(DW_FAILOVER))
		dw_attr->fo_state = atoi(sValue);
	else
		goto IFX_Handler;

	if (read_file_cache(DW_STANDBY))
		dw_attr->fo_type = atoi(sValue);
	else
		goto IFX_Handler;

	if (read_file_cache(DW_PROBE_INT))
		dw_attr->probe_info.probe_int = atoi(sValue);
	else
		goto IFX_Handler;

	if (read_file_cache(DW_PROBE_RET))
		dw_attr->probe_info.probe_retry = atoi(sValue);
	else
		goto IFX_Handler;

	if (read_file_cache(DW_IP))
		strcpy(dw_attr->probe_info.probe_ip_url, sValue);
	else
		goto IFX_Handler;

	/*------------------------------------------------------------------------------*/

	if (read_file_cache(DW_P_TC))
		dw_attr->pri_wan_cfg.wan_tc = atoi(sValue);
	else
		goto IFX_Handler;

	if (read_file_cache(DW_P_PHY))
		dw_attr->pri_wan_cfg.phy_mode = atoi(sValue);
	else
		goto IFX_Handler;

	if (read_file_cache(DW_P_SETTC))
		dw_attr->pri_wan_cfg.set_wan_tc = atoi(sValue);
	else
		goto IFX_Handler;

	if (read_file_cache(DW_P_SETPHY))
		dw_attr->pri_wan_cfg.set_phy_mode = atoi(sValue);
	else
		goto IFX_Handler;
#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
	if (read_file_cache(DW_P_PTM_VLAN))
		dw_attr->pri_wan_cfg.ptm_vlan_mode = atoi(sValue);
	else
		goto IFX_Handler;
#endif

#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
	if (read_file_cache(DW_P_MII_VLAN))
		dw_attr->pri_wan_cfg.eth_mii1_vlan_mode = atoi(sValue);
	else
		goto IFX_Handler;
#endif

	if (read_file_cache(DW_P_TR69))
		strcpy(dw_attr->pri_wan_cfg.tr69_encaprequested, sValue);
	else
		goto IFX_Handler;

	/*----------------------------------------------------------------------------*/

	if (read_file_cache(DW_S_TC))
		dw_attr->sec_wan_cfg.wan_tc = atoi(sValue);
	else
		goto IFX_Handler;

	if (read_file_cache(DW_S_PHY))
		dw_attr->sec_wan_cfg.phy_mode = atoi(sValue);
	else
		goto IFX_Handler;

	if (read_file_cache(DW_S_SETTC))
		dw_attr->sec_wan_cfg.set_wan_tc = atoi(sValue);
	else
		goto IFX_Handler;

	if (read_file_cache(DW_S_SETPHY))
		dw_attr->sec_wan_cfg.set_phy_mode = atoi(sValue);
	else
		goto IFX_Handler;

#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
	if (read_file_cache(DW_S_PTM_VLAN))
		dw_attr->sec_wan_cfg.ptm_vlan_mode = atoi(sValue);
	else
		goto IFX_Handler;
#endif

#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
	if (read_file_cache(DW_S_MII_VLAN))
		dw_attr->sec_wan_cfg.eth_mii1_vlan_mode = atoi(sValue);
	else
		goto IFX_Handler;
#endif

	if (read_file_cache(DW_S_TR69))
		strcpy(dw_attr->sec_wan_cfg.tr69_encaprequested, sValue);
	else
		goto IFX_Handler;

IFX_Handler:
	if(ret_cache != IFX_FAILURE){
		ret_cache = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DUAL_WAN_CFG, buf, IFX_F_INT_CACHE_DESTROY, NULL, NULL);
		if (ret_cache != IFX_SUCCESS) {
		IFX_DBG("[%s:%d] Failed to destroy cache for this instance",
			__FUNCTION__, __LINE__);
		}
	}

	if (ret != IFX_SUCCESS){
		IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
	}

	return ret;
}

#define NEXT_MODE dw_attr->pri_wan_cfg.phy_mode==6?dw_attr->sec_wan_cfg.phy_mode:dw_attr->pri_wan_cfg.phy_mode
int32 dw_mapi_cfg_set(uint32 oper, dw_config_info_t * dw_attr, uint32 flags)
{
	int32 ret = IFX_SUCCESS;
	dw_config_info_t dw_conf_old;
	flags = IFX_F_MODIFY;
	WAN_PHY_CFG pstWanPhy_old;
	int32 wan_no_match = 0; /*prev and new wan mode matches*/
	char8 sCommand[MAX_FILELINE_LEN];

	NULL_TERMINATE(sCommand, 0x0, MAX_FILELINE_LEN);
	dw_mapi_cfg_get(&dw_conf_old, IFX_F_GET_ANY);
	if (dw_conf_old.fo_state == 1) {
		/* stop daemon */
		IFX_DBG("[%s] : Stopping the DW Daemon before config update", __FUNCTION__);
		system("/etc/init.d/dw_daemon.sh stop");
	}

#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
	system("/etc/rc.d/ltq_pwb_config.sh del_all");
#endif	

	if (dw_attr->fo_state != 1) {
		/* Check if the old and current wan connections are same */
		memset(&pstWanPhy_old, 0x00, sizeof(pstWanPhy_old));
		ifx_get_wan_phy_cfg(&pstWanPhy_old);
		if ((pstWanPhy_old.phy_mode != dw_attr->pri_wan_cfg.phy_mode) || 
			((pstWanPhy_old.phy_mode == dw_attr->pri_wan_cfg.phy_mode) &&
			 (pstWanPhy_old.wan_tc != dw_attr->pri_wan_cfg.wan_tc))) {
			/* wan modes do not match*/
			wan_no_match = 1;					
		}

		ret = ifx_set_wan_phy_cfg_new(&(dw_attr->pri_wan_cfg), flags);
		if (ret != IFX_SUCCESS) {
			IFX_DBG
			    ("\nFailed to update WAN configuration rc.conf\n");
			return IFX_FAILURE;
		}
		if ((dw_conf_old.fo_state == 1) && (wan_no_match != 1)) {
			IFX_DBG("[%s:%d] : WAN Stop\n", __FUNCTION__, __LINE__);
			/* if dual wan is disabled and the previously active wan 
			   and currently configured wan are not same, then call 
			   for changeover */
			sprintf(sCommand, "/etc/init.d/ltq_wan_changeover_stop.sh %d", dw_attr->pri_wan_cfg.phy_mode);
			system(sCommand);
		}
/* 		Not required so commenting out
		flags |= IFX_F_INT_DONT_CONFIGURE;
*/

		ret = dw_wan_phy_cfg_set(oper, dw_attr, flags);

		if (ret != IFX_SUCCESS) {
			IFX_DBG
			    ("\nFailed to update DUAL WAN configuration rc.conf\n");
			return IFX_FAILURE;
		}
		if ((dw_conf_old.fo_state == 1) && (wan_no_match != 1)) {
			IFX_DBG("[%s:%d] : Calling WAN Start", __FUNCTION__, __LINE__);
			system ("/etc/init.d/ltq_wan_changeover_start.sh");
		}
	} else {
		/* Update wan_main section of rc.conf. It will update only
		 * rc.conf and it will not activate any system related modules,
		 * Sys config will be taken care by Dual Wan Failover DAEMON
		 */
		IFX_DBG("[%s] - Stopping the Current WAN before config updation", __FUNCTION__);
		sprintf(sCommand, "/etc/init.d/ltq_wan_changeover_stop.sh %d", NEXT_MODE);
		system(sCommand);

		flags |= IFX_F_INT_DONT_CONFIGURE;

		if (ifx_set_wan_phy_cfg_new(&(dw_attr->pri_wan_cfg), flags) !=
		    IFX_SUCCESS) {
			return IFX_FAILURE;
		}
		flags &= ~IFX_F_INT_DONT_CONFIGURE;
		ret = dw_wan_phy_cfg_set(oper, dw_attr, flags);
		if (ret == IFX_SUCCESS) {
			/* Start daemon */
			IFX_DBG("Starting the Dual WAN Daemon in [%s]",	__FUNCTION__);
			system("/etc/init.d/dw_daemon.sh start");
		} else {
			IFX_DBG
			    ("\nFailed to update DUAL WAN configuration rc.conf\n");
			return IFX_FAILURE;
		}
	}

#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
	system("/etc/rc.d/ltq_pwb_config.sh add_all");
#endif

	return IFX_SUCCESS;
}

/* Return probe status according to "probe_wan_mode" passed.
 *
*/
int32 dw_last_probe_status_get(int32 probe_wan_mode,
			       dw_wan_status_info_t * probe_status)
{

	int32 outFlag = IFX_F_DEFAULT;
	char8 retVal[MAX_NAME_SIZE];

	memset(probe_status, 0, sizeof(dw_wan_status_info_t));

	inline int rd_sys_file(char *attr, char *retVal) {
		int32 ret = IFX_SUCCESS;
		ret =
		    ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_PROBE_STATUS,
				      attr, IFX_F_DEFAULT,
				      (IFX_OUT uint32 *) & outFlag, retVal);
		return ret;
	}

	if ((probe_wan_mode == DW_PROBE_WAN_PRIMARY)
	    || (probe_wan_mode == DW_PROBE_WAN_BOTH)) {
		if (rd_sys_file("dw_pri_l2_status", retVal) != IFX_SUCCESS) {
			goto IFX_Failure;
		}
		probe_status->pri_wan_status.phy_status = atoi(retVal);

		if (rd_sys_file("dw_pri_l3_status", retVal) != IFX_SUCCESS) {
			goto IFX_Failure;
		}
		probe_status->pri_wan_status.wan_status = atoi(retVal);
	}

	if ((probe_wan_mode == DW_PROBE_WAN_SECONDARY)
	    || (probe_wan_mode == DW_PROBE_WAN_BOTH)) {
		if (rd_sys_file("dw_sec_l2_status", retVal) != IFX_SUCCESS) {
			goto IFX_Failure;
		}
		probe_status->sec_wan_status.phy_status = atoi(retVal);

		if (rd_sys_file("dw_sec_l3_status", retVal) != IFX_SUCCESS) {
			goto IFX_Failure;
		}
		probe_status->sec_wan_status.wan_status = atoi(retVal);
	}

	return IFX_SUCCESS;

      IFX_Failure:
	IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
	return IFX_FAILURE;
}
#endif
