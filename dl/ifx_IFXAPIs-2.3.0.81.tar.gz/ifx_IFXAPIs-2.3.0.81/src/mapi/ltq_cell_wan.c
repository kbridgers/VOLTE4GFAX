/* Copyright (c) 2011, Lantiq Communications
 *
 *  Management API's for 3G WWAN
 */

#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#include <arpa/inet.h>
#include "ifx_common.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"

#if defined(CONFIG_FEATURE_CELL_WAN_SUPPORT) || defined(CONFIG_FEATURE_WWAN_LTE_SUPPORT)

char8 *cell_wan_info_params[] =
    { "cpeId", "pcpeId", "ena", "profName", "apn", "user", "passwd", "authType",
"usePIN", "PIN", "dialNum", "idleDisc", "idleDiscTO", "ifName" };

int32 ltq_mapi_get_cell_wan(LTQ_MAPI_Cell_WAN * cell_wan, uint32 index,
			    uint32 flags)
{
	int32 ret = IFX_SUCCESS;
	char8 sValue[MAX_NAME_SIZE], buf[MAX_FILELINE_LEN],
	    sTAG_NAME[MAX_DATA_LEN];
	int32 outflag = IFX_F_DEFAULT;

	sprintf(sTAG_NAME, "WanPPP0_IF_Info");

	sprintf(buf, "cwan_%d_cpeId", index);
	if (ifx_GetObjData(FILE_RC_CONF, TAG_CELL_WAN, buf, IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outflag,
			   sValue) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d:%d]", __FUNCTION__, __LINE__, index);
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	cell_wan->iid.cpeId.Id = atoi(sValue);

	sprintf(buf, "cwan_%d_ena", index);
	if (ifx_GetObjData(FILE_RC_CONF, TAG_CELL_WAN, buf, IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outflag,
			   sValue) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	cell_wan->ena = atoi(sValue);
	IFX_API_LOG("cwan_%d_ena[%s:%d]", index, __FUNCTION__, __LINE__);
	sprintf(buf, "cwan_%d_profName", index);
	if (ifx_GetObjData(FILE_RC_CONF, TAG_CELL_WAN, buf, IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outflag,
			   sValue) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	IFX_API_LOG("[%s:%d:%s]", __FUNCTION__, __LINE__, sValue);
	strcpy(cell_wan->profName, sValue);

	/* Get the Cell Wan Details from rc.conf */
	sprintf(buf, "cwan_%d_apn", index);
	if (ifx_GetObjData(FILE_RC_CONF, TAG_CELL_WAN, buf, IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	strcpy(cell_wan->apn, sValue);

	sprintf(buf, "cwan_%d_user", index);
	if (ifx_GetObjData(FILE_RC_CONF, TAG_CELL_WAN, buf, IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	strcpy(cell_wan->user, sValue);

	sprintf(buf, "cwan_%d_passwd", index);
	if (ifx_GetObjData(FILE_RC_CONF, TAG_CELL_WAN, buf, IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	strcpy(cell_wan->passwd, sValue);

	sprintf(buf, "cwan_%d_authType", index);
	if (ifx_GetObjData(FILE_RC_CONF, TAG_CELL_WAN, buf, IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	cell_wan->authType = atoi(sValue);

	sprintf(buf, "cwan_%d_usePIN", index);
	if (ifx_GetObjData(FILE_RC_CONF, TAG_CELL_WAN, buf, IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	cell_wan->usePIN = atoi(sValue);

	sprintf(buf, "cwan_%d_PIN", index);
	if (ifx_GetObjData(FILE_RC_CONF, TAG_CELL_WAN, buf, IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	cell_wan->pin = atoi(sValue);

	sprintf(buf, "cwan_%d_dialNum", index);
	if (ifx_GetObjData(FILE_RC_CONF, TAG_CELL_WAN, buf, IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	strcpy(cell_wan->dialNum, sValue);

	sprintf(buf, "cwan_%d_idleDisc", index);
	if (ifx_GetObjData(FILE_RC_CONF, TAG_CELL_WAN, buf, IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	cell_wan->idleDisc = atoi(sValue);

	sprintf(buf, "cwan_%d_idleDiscTO", index);
	if (ifx_GetObjData(FILE_RC_CONF, TAG_CELL_WAN, buf, IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d:%d]", __FUNCTION__, __LINE__, index);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	cell_wan->idleDiscTO = atoi(sValue);

	sprintf(buf, "cwan_%d_ifName", index);
	if (ifx_GetObjData(FILE_RC_CONF, TAG_CELL_WAN, buf, IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	strcpy(cell_wan->ifName, sValue);

	sprintf(buf, "STATUS");
	if (ifx_GetObjDataOpt(FILE_SYSTEM_STATUS, sTAG_NAME, buf, IFX_F_GET_ANY,
		(IFX_OUT uint32 *) & outflag,
		sValue) != IFX_SUCCESS) {

		sprintf(sValue, "UNCONFIGURED");

#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	strcpy(cell_wan->STATUS, sValue);

	sprintf(buf, "IP");
	if (ifx_GetObjDataOpt(FILE_SYSTEM_STATUS, sTAG_NAME, buf, IFX_F_GET_ANY,
		(IFX_OUT uint32 *) & outflag,
		sValue) != IFX_SUCCESS) {

		sprintf(sValue, "0.0.0.0");
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	strcpy(cell_wan->IP, sValue);

	sprintf(buf, "MASK");
	if (ifx_GetObjDataOpt(FILE_SYSTEM_STATUS, sTAG_NAME, buf, IFX_F_GET_ANY,
			(IFX_OUT uint32 *) & outflag,
			sValue) != IFX_SUCCESS) {

		sprintf(sValue, "0.0.0.0");
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	strcpy(cell_wan->MASK, sValue);

      IFX_Handler:
	if (ret != IFX_SUCCESS)
		IFX_API_LOG("[%s] returned failure!", __FUNCTION__);

	return ret;
}

/*//////////////////////////////////////////////////////////////////////////////
* ltq_mapi_set_cell_wan(...)
*               operation       ==>     specifies the operation to be done such as ADD, DELETE or MODIFY
*       flags           ==>             flags that define the behaviour
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
                Description:
                                        The api takes the structure entry which will have the values filled in to be configured.
                                        Based on the operation, it will either add, delete or modify a vcc connection.
                                        For Modify and Delete Validations are put to check for an existing Wan Connection on this vcc
                                          It will return IFX_SUCCESS or IFX_FAILURE
*//////////////////////////////////////////////////////////////////////////////
int32 ltq_mapi_set_cell_wan(uint32 operation, LTQ_MAPI_Cell_WAN * cellWANProf,
			    uint32 flags)
{
	char8 conf_buf[MAX_DATA_LEN];
	char8 sValue[MAX_NAME_SIZE], buf[MAX_FILELINE_LEN];
	uint32 count = 0, changed_count, ret =
	    IFX_SUCCESS;
	uint32 outflag = IFX_F_DEFAULT;
	int32 index = -1;
	int32 flgPIN = 0, flgidleDiscTO = 0;

	changed_count = 0;

	IFX_NAME_VALUE_PAIR array_fvp[18], *array_changed_fvp = NULL;

	NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));
	memset(array_fvp, 0, sizeof(array_fvp));

	/*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY) 
	 * append the flag with internal flags */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(cellWANProf)
		    /* Do simple validation of flags such as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

	cellWANProf->iid.pcpeId.Id = 1;
	sprintf(cellWANProf->iid.cpeId.secName, "%s", TAG_CELL_WAN);
	//sprintf(cellWANProf->iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);

/* Read old PIN number */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cellWANProf->iid.cpeId, index)
	sprintf(buf, "cwan_%d_PIN", index);
	if (ifx_GetObjData(FILE_RC_CONF, TAG_CELL_WAN, buf, IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	flgPIN = atoi(sValue);

/* Read old idle timeout value */
	sprintf(buf, "cwan_%d_idleDiscTO", index);
	if (ifx_GetObjData(FILE_RC_CONF, TAG_CELL_WAN, buf, IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	flgidleDiscTO = atoi(sValue);

	/**************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_ADD_F_SET(flags)) {
		if (ifx_get_IID(&cellWANProf->iid, "dialNum") != IFX_SUCCESS) {
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

/**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given structure for ADD/MODIFY
	 * Operations 
	 */
	count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, 0, 14, cell_wan_info_params);
		sprintf(array_fvp[0].value, "%d", cellWANProf->iid.cpeId.Id);
		sprintf(array_fvp[1].value, "%d", cellWANProf->iid.pcpeId.Id);
#ifdef CONFIG_FEATURE_WWAN_LTE_SUPPORT
		sprintf(array_fvp[2].value, "1");
		sprintf(array_fvp[3].value, "lte_profile");
		sprintf(array_fvp[4].value, "auto");
		sprintf(array_fvp[5].value, "%s", "");
		sprintf(array_fvp[6].value, "%s", "");
		sprintf(array_fvp[7].value, "0");
#else
		sprintf(array_fvp[2].value, "%d", cellWANProf->ena);
		sprintf(array_fvp[3].value, "%s", cellWANProf->profName);
		sprintf(array_fvp[4].value, "%s", cellWANProf->apn);
		sprintf(array_fvp[5].value, "%s", cellWANProf->user);
		sprintf(array_fvp[6].value, "%s", cellWANProf->passwd);
		sprintf(array_fvp[7].value, "%d", cellWANProf->authType);
#endif
		sprintf(array_fvp[8].value, "%d", cellWANProf->usePIN);
		if (cellWANProf->usePIN) {
			sprintf(array_fvp[9].value, "%d", cellWANProf->pin);
		} else {
			sprintf(array_fvp[9].value, "%d", flgPIN);
		}
		sprintf(array_fvp[10].value, "%s", cellWANProf->dialNum);
		sprintf(array_fvp[11].value, "%d", cellWANProf->idleDisc);
		if (cellWANProf->idleDisc) {
			sprintf(array_fvp[12].value, "%d", cellWANProf->idleDiscTO);
		} else {
			sprintf(array_fvp[12].value, "%d", flgidleDiscTO);
		}
		sprintf(array_fvp[13].value, "%s", cellWANProf->ifName);
	}
	count = 14;
	IFX_DBG("[%s:%d:%d]", __FUNCTION__, __LINE__,
		cellWANProf->iid.cpeId.Id);
	/* Get Config Index in case of modify/delete operations from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cellWANProf->iid.cpeId,
					 index)
	}

	/* Determine the configuration index - for Add, Delete, Modify operations 
	 * Name is partial since index is not known 
	 * Fill array_fvp[] */

	if (ifx_get_conf_index_and_nv_pairs
	    (&cellWANProf->iid, index, PREFIX_CELL_WAN, count, array_fvp,
	     flags) != IFX_SUCCESS) {

		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		IFX_DBG("[%s:%d] buf [%s] flags [%d]", __FUNCTION__, __LINE__,
			conf_buf, flags);
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/************** System Config File Update Block ****************/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_CELL_WAN, flags, 1, conf_buf);

	if (ret != IFX_SUCCESS) {
		IFX_DBG("[%s:%d] buf [%s] flags [%d]", __FUNCTION__, __LINE__,
			conf_buf, flags);
		goto IFX_Handler;
	}

	/* this will Compact the section and also update the count for both ADD and DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags)) {
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_CELL_WAN, flags);
	}

	/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

	/*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_MODIFY_F_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION(cellWANProf->iid, changed_count,
					  array_changed_fvp, flags, IFX_Handler)
	}

	else if (IFX_INT_ADD_F_SET(flags)) {
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */
		/*********** Epilog Block **************/
		UPDATE_ID_MAP_N_ATTRIBUTES(&cellWANProf->iid, count, array_fvp,
					   flags, IFX_Handler)

		    CHECK_N_SEND_NOTIFICATION(cellWANProf->iid, count,
					      array_fvp, flags, IFX_Handler)

		    /* Manipulate nextCpeId only for ADD operations */
		    //      ifx_increment_next_cpeId(FILE_RC_CONF, TAG_CELL_WAN);
	}
	/* In case of DELETE operation, first send the notification update the ID Mappings
	 * and then send the Notification for the attributes
	 */
		/*********** Epilog Block **************/

	else if (IFX_DELETE_F_SET(flags)) {

		CHECK_N_SEND_NOTIFICATION(cellWANProf->iid, count, array_fvp,
					  flags, IFX_Handler)

		    UPDATE_ID_MAP_N_ATTRIBUTES(&cellWANProf->iid, count,
					       array_fvp, flags, IFX_Handler)
	}
	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Update Persistent Storage fail", __FUNCTION__,
			__LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

int32 ltq_mapi_get_cell_modem_status(LTQ_MAPI_MODEM_STATUS * modem_status,
				     uint32 flags)
{

	FILE *fp;
	char prototype_str[20] = "";
	char prototype[20] = "";
	char modemmake_str[20] = "";
	char modemmake[20] = "";
	char modemmodel_str[20] = "";
	char modemmodel[20] = "";
	char esn_imei[20] = "";
	char esn_imei_val[20] = "";
	char cellOper_str[20] = "";
	char cellOper[20] = "";
	char signalstrength_str[20] = "";
	char signalstrength[20] = "";
	char simstatus_str[20] = "";
	char simstatus[20] = "";
	char cellWanSta_str[20] = "";
	char cellWanSta[20] = "";

	int ret = 0;

	//system ("/etc/init.d/usb_automount_status.sh status");
#ifdef CONFIG_FEATURE_WWAN_LTE_SUPPORT
	ifx_run_command ("/opt/altair/lte_check_signal.sh");
#endif
	fp = fopen("/tmp/cwan_status.txt", "r");

	if (fp == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] failed to read /tmp/cwan_status.txt",
			__FUNCTION__, __LINE__);
#endif
		ret = -1;
		goto IFX_Handler;
	}

	if (fscanf(fp, "%s %s", prototype_str, prototype) != 2) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] failed to read /tmp/cwan_status.txt",
			__FUNCTION__, __LINE__);
#endif
		ret = -1;
		goto IFX_Handler;
	}

	modem_status->cellWanType = atoi(prototype);

	if (fscanf(fp, "%s %s", modemmake_str, modemmake) != 2) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] failed to read /tmp/cwan_status.txt",
			__FUNCTION__, __LINE__);
#endif
		ret = -1;
		goto IFX_Handler;
	}

	strcpy(modem_status->modemManu, modemmake);

	if (fscanf(fp, "%s %s", modemmodel_str, modemmodel) != 2) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] failed to read /tmp/cwan_status.txt",
			__FUNCTION__, __LINE__);
#endif
		ret = -1;
		goto IFX_Handler;
	}

	strcpy(modem_status->modemModel, modemmodel);

	if (fscanf(fp, "%s %s", cellOper_str, cellOper) != 2) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] failed to read /tmp/cwan_status.txt",
			__FUNCTION__, __LINE__);
#endif
		ret = -1;
		goto IFX_Handler;
	}

	strcpy(modem_status->cellOper, cellOper);

	if (fscanf(fp, "%s %s", esn_imei, esn_imei_val) != 2) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] failed to read /tmp/cwan_status.txt",
			__FUNCTION__, __LINE__);
#endif
		ret = -1;
		goto IFX_Handler;
	}

	strcpy(modem_status->esn_imei, esn_imei_val);

	if (fscanf(fp, "%s %s", signalstrength_str, signalstrength) != 2) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] failed to read /tmp/cwan_status.txt",
			__FUNCTION__, __LINE__);
#endif
		ret = -1;
		goto IFX_Handler;
	}

	modem_status->sigStrngthPct = atoi(signalstrength);
	if ((modem_status->sigStrngthPct >= 99)
	    || (modem_status->sigStrngthPct <= 0)) {
		modem_status->sigStrngthPct = 0;
	} else {
		// Round it to 31 for compatbility with all modems
		if (modem_status->sigStrngthPct >= 31)
			modem_status->sigStrngthPct = 31;
	}

	if (fscanf(fp, "%s %s", simstatus_str, simstatus) != 2) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] failed to read /tmp/cwan_status.txt",
			__FUNCTION__, __LINE__);
#endif
		ret = -1;
		goto IFX_Handler;
	}

	modem_status->simSta = atoi(simstatus);

	if (fscanf(fp, "%s %s", cellWanSta_str, cellWanSta) != 2) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] failed to read /tmp/cwan_status.txt",
			__FUNCTION__, __LINE__);
#endif
		ret = -1;
		goto IFX_Handler;
	}

	modem_status->cellWanSta = atoi(cellWanSta);

	ret = 0;
IFX_Handler:
	if (fp)
		fclose(fp);
	else
		IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
	return ret;

}

#endif
