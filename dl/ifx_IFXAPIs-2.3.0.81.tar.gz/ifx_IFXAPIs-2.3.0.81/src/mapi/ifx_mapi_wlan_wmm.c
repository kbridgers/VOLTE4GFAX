
#if defined (CONFIG_FEATURE_IFX_WIRELESS)
/* ========================================================================== */
/*                                 Includes                                   */
/* ========================================================================== */
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"

/* included for definition of bool */
#include "ifx_api_ipt_common.h"
/* ========================================================================== */
/*                             Macro definitions                              */
/* ========================================================================== */
#define WLAN_WMM_AP_PARAM_COUNT              8
#define WLAN_WMM_STA_PARAM_COUNT             7

/* ========================================================================== */
/*                             Type definitions                               */
/* ========================================================================== */

/* ========================================================================== */
/*                             Global variables                               */
/* ========================================================================== */
IFX_MAPI_WLAN_AP_WMM_Cfg	g_wlWmmApConfig[LTQ_MAX_NUM_VAP][IFX_MAPI_WLAN_WMM_NUM_AC];
IFX_MAPI_WLAN_STA_WMM_Cfg	g_wlWmmStaConfig[LTQ_MAX_NUM_VAP][IFX_MAPI_WLAN_WMM_NUM_AC];
int							g_flagWmmApConfig = 0;
int							g_flagWmmStaConfig = 0;
int							g_nVap = 0;

char8 *wlan_ap_wmm_params[] = { "cpeId", "pcpeId", "ECWmin", "ECWmax",
	"AIFSN", "TXOP", "AckPolicy", "AdmCntrl"
};
char8 *wlan_sta_wmm_params[] = { "cpeId", "pcpeId", "ECWmin", "ECWmax",
	"AIFSN", "TXOP", "AckPolicy"
};

/* ========================================================================== */
/*                           Function prototypes                              */
/* ========================================================================== */

/* ========================================================================== */
/*                         Function implementation                            */
/* ========================================================================== */
/**
   This api reads wlan wmm parameters from rc.conf and returns them in wlApWmm

   \param   wlApWmm - pointer to IFX_MAPI_WLAN_AP_WMM_Cfg structure

   \param   flags - 

   \return
      IFX_SUCCESS or IFX_FAILURE

   \remarks
      before calling, make sure the following elements are filled
      - wlApWmm->ac
      - wlApWmm->iid.pcpeId.Id
      - wlApWmm->iid.config_owner
*/
int32 ifx_mapi_get_wlan_wmm_ap_config(IFX_MAPI_WLAN_AP_WMM_Cfg * wlApWmm,
				      uint32 flags)
{
	int32 ret = IFX_SUCCESS, passed_index = -1, count, i;
	char8 buf[MAX_DATA_LEN], *sValue = NULL;
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_WMM_AP_PARAM_COUNT + 1];

	LTQ_LOG_TIMESTAMP();

	sprintf(wlApWmm->iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
	sprintf(wlApWmm->iid.cpeId.secName, "%s", TAG_WLAN_WMM_AP);

	/* get index from cpeid first */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlApWmm->iid.cpeId, passed_index)
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWmmApConfig", "passed_index: %d",
		passed_index);

	if (!g_flagWmmApConfig) {
		sprintf(buf, "%s%d_%d_", PREFIX_WLAN_WMM_AP, wlApWmm->iid.pcpeId.Id,
			passed_index);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWmmApConfig", "buf: %s", buf);
		if ((ret =
			 ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_WMM_AP, buf, IFX_F_DEFAULT,
					  &sValue)) != IFX_SUCCESS)
			goto IFX_Handler;

		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWmmApConfig",
				   "buf: %s, passed_index: %d, sValue: %s",
				   buf, passed_index, sValue);

		/* form an array of field value pairs for easier access to parameters */
		memset(array_fvp, 0x00, sizeof(array_fvp));
		form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWmmApConfig", "count: %d",
				   count);
		for (i = 0; i < count; i++)
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWmmApConfig", "%s:%s",
					   array_fvp[i].fieldname, array_fvp[i].value);

		wlApWmm->iid.cpeId.Id = atoi(array_fvp[0].value);
		wlApWmm->iid.pcpeId.Id = atoi(array_fvp[1].value);
		wlApWmm->ECWmin = atoi(array_fvp[2].value);
		wlApWmm->ECWmax = atoi(array_fvp[3].value);
		wlApWmm->AIFSN = atoi(array_fvp[4].value);
		wlApWmm->TXOP = atoi(array_fvp[5].value);
		wlApWmm->ackPolicyEna = atoi(array_fvp[6].value);
		wlApWmm->admCntrl = atoi(array_fvp[7].value);
	}
	else {
		for (i = 0; i < g_nVap; i++) {
			if (g_wlWmmApConfig[i][passed_index].iid.cpeId.Id == wlApWmm->iid.cpeId.Id) {
				memcpy(wlApWmm, &g_wlWmmApConfig[i][passed_index],
					sizeof(IFX_MAPI_WLAN_AP_WMM_Cfg));
			}
		}
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWmmApConfig", "ret: %d", ret);
	/* free buffer allocated in ifx_GetCfgObject */
	IFX_MEM_FREE(sValue);
	LTQ_LOG_TIMESTAMP();
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return IFX_FAILURE;
	} else
		return IFX_SUCCESS;
}

/**
   This api gets the parameters for all four access categories of one AP/VAP and
   returns the information in wlApWmm.

   \param   mainCpeId

   \param   numEntries

   \param   wlApWmm - pointer to IFX_MAPI_WLAN_AP_WMM_Cfg structure

   \param   flags - 

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_all_wlan_wmm_ap_config(uint32 mainCpeId,
					  uint32 * numEntries,
					  IFX_MAPI_WLAN_AP_WMM_Cfg ** wlApWmm,
					  uint32 flags)
{
	int32 ret = IFX_SUCCESS, nCount = 0, i = 0, count, idxPerAc = 0, j = 0;
	char8 buf[MAX_NAME_LEN];
	/* number of parameters per VAP:
	 * = four access categories * number of parameters per ac
	 */
	int32 nParamsPerVap = IFX_MAPI_WLAN_WMM_NUM_AC*WLAN_WMM_AP_PARAM_COUNT;
	char8 *sWmmApConfig = NULL;
	IFX_NAME_VALUE_PAIR array_fvp[LTQ_MAX_NUM_VAP*IFX_MAPI_WLAN_WMM_NUM_AC*WLAN_WMM_AP_PARAM_COUNT];

	LTQ_LOG_TIMESTAMP();
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanWmmApConfig", "mainCpeId: %d",
		mainCpeId);

	/* in this case always four entries are present (four access categories) */
	nCount = IFX_MAPI_WLAN_WMM_NUM_AC;

	*wlApWmm = NULL;
	IFX_MEM_ALLOC((*wlApWmm), IFX_MAPI_WLAN_AP_WMM_Cfg *, nCount,
		      sizeof(IFX_MAPI_WLAN_AP_WMM_Cfg))

	if (!g_flagWmmApConfig) {
		sprintf(buf, "%s", PREFIX_WLAN_WMM_AP);
		if ((ret =
			ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_WMM_AP, buf, IFX_F_DEFAULT,
				&sWmmApConfig)) != IFX_SUCCESS) {
					goto IFX_Handler;
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanWmmApConfig", "");
		}
	
		/* form an array of field value pairs for easier access to parameters */
		memset(array_fvp, 0x00, sizeof(array_fvp));
		form_array_fvp_from_cfgdb_buf(sWmmApConfig, &count, array_fvp);
	
		for (j = 0; j < g_nVap; j++) {
			for (i = 0; i < nCount; i++) {
				idxPerAc = WLAN_WMM_AP_PARAM_COUNT*i;
				/* set some required params in wlApWmm */
				sprintf(g_wlWmmApConfig[j][i].iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
				sprintf(g_wlWmmApConfig[j][i].iid.cpeId.secName, "%s", TAG_WLAN_WMM_AP);
				g_wlWmmApConfig[j][i].ac = i;
				g_wlWmmApConfig[j][i].iid.cpeId.Id = atoi(array_fvp[idxPerAc + (j*nParamsPerVap)].value);
				g_wlWmmApConfig[j][i].iid.pcpeId.Id = atoi(array_fvp[idxPerAc + 1 + (j*nParamsPerVap)].value);
				g_wlWmmApConfig[j][i].ECWmin = atoi(array_fvp[idxPerAc + 2 + (j*nParamsPerVap)].value);
				g_wlWmmApConfig[j][i].ECWmax = atoi(array_fvp[idxPerAc + 3 + (j*nParamsPerVap)].value);
				g_wlWmmApConfig[j][i].AIFSN = atoi(array_fvp[idxPerAc + 4 + (j*nParamsPerVap)].value);
				g_wlWmmApConfig[j][i].TXOP = atoi(array_fvp[idxPerAc + 5 + (j*nParamsPerVap)].value);
				g_wlWmmApConfig[j][i].ackPolicyEna = atoi(array_fvp[idxPerAc + 6 + (j*nParamsPerVap)].value);
				g_wlWmmApConfig[j][i].admCntrl = atoi(array_fvp[idxPerAc + 7 + (j*nParamsPerVap)].value);
				if (g_wlWmmApConfig[j][i].iid.pcpeId.Id == mainCpeId) {
					memcpy((*wlApWmm+i), &g_wlWmmApConfig[j][i], sizeof(IFX_MAPI_WLAN_AP_WMM_Cfg));
				}
			}
		}
		g_flagWmmApConfig = 1;
	}
	else {
		for (j = 0; j < g_nVap; j++) {
			if (g_wlWmmApConfig[j][0].iid.pcpeId.Id == mainCpeId) {
				memcpy(*wlApWmm, &g_wlWmmApConfig[j][0],
					sizeof(IFX_MAPI_WLAN_AP_WMM_Cfg) * nCount);
			}
		}
	}
	*numEntries = nCount;

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanWmmApConfig", "ret: %d", ret);
	IFX_MEM_FREE(sWmmApConfig);
	if (ret != IFX_SUCCESS)
		IFX_MEM_FREE(*wlApWmm)

	LTQ_LOG_TIMESTAMP();
	return ret;
}

/**
   This api reads wlan wmm parameters from rc.conf and returns them in wlStaWmm

   \param   wlStaWmm - pointer to IFX_MAPI_WLAN_STA_WMM_Cfg structure

   \param   flags - 

   \return
      IFX_SUCCESS or IFX_FAILURE

   \remarks
      before calling, make sure the following elements are filled
      - wlStaWmm->ac
      - wlStaWmm->iid.pcpeId.Id
      - wlStaWmm->iid.config_owner
*/
int32 ifx_mapi_get_wlan_wmm_sta_config(IFX_MAPI_WLAN_STA_WMM_Cfg * wlStaWmm,
				       uint32 flags)
{
	int32 ret = IFX_SUCCESS, passed_index = -1, count, i;
	char8 buf[MAX_DATA_LEN], *sValue = NULL;
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_WMM_STA_PARAM_COUNT + 1];

	LTQ_LOG_TIMESTAMP();

	sprintf(wlStaWmm->iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
	sprintf(wlStaWmm->iid.cpeId.secName, "%s", TAG_WLAN_WMM_STA);
	/* get index from cpeid first */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlStaWmm->iid.cpeId, passed_index)

	if (!g_flagWmmApConfig) {
	sprintf(buf, "%s%d_%d_", PREFIX_WLAN_WMM_STA, wlStaWmm->iid.pcpeId.Id,
		passed_index);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWmmStaConfig", "buf: %s", buf);
	if ((ret =
	     ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_WMM_STA, buf, IFX_F_DEFAULT,
			      &sValue)) != IFX_SUCCESS)
		goto IFX_Handler;

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWmmStaConfig",
		       "buf: %s, passed_index: %d, sValue: %s",
		       buf, passed_index, sValue);

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWmmStaConfig", "count: %d",
		       count);
	for (i = 0; i < count; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWmmStaConfig", "%s:%s",
			       array_fvp[i].fieldname, array_fvp[i].value);

	wlStaWmm->iid.cpeId.Id = atoi(array_fvp[0].value);
	wlStaWmm->iid.pcpeId.Id = atoi(array_fvp[1].value);
	wlStaWmm->ECWmin = atoi(array_fvp[2].value);
	wlStaWmm->ECWmax = atoi(array_fvp[3].value);
	wlStaWmm->AIFSN = atoi(array_fvp[4].value);
	wlStaWmm->TXOP = atoi(array_fvp[5].value);
	wlStaWmm->ackPolicyEna = atoi(array_fvp[6].value);
	}
	else {
		for (i = 0; i < g_nVap; i++) {
			if (g_wlWmmStaConfig[i][passed_index].iid.cpeId.Id == wlStaWmm->iid.cpeId.Id) {
				memcpy(wlStaWmm, &g_wlWmmStaConfig[i][passed_index],
					sizeof(IFX_MAPI_WLAN_STA_WMM_Cfg));
			}
		}
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWmmStaConfig", "ret: %d", ret);
	/* free buffer allocated in ifx_GetCfgObject */
	IFX_MEM_FREE(sValue);
	LTQ_LOG_TIMESTAMP();
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return IFX_FAILURE;
	} else
		return IFX_SUCCESS;
}

/**
   This api gets the parameters for all four access categories of one AP/VAP and
   returns the information in wlStaWmm.

   \param   mainCpeId

   \param   numEntries

   \param   wlStaWmm - pointer to IFX_MAPI_WLAN_STA_WMM_Cfg structure

   \param   flags - 

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_all_wlan_wmm_sta_config(uint32 mainCpeId,
					   uint32 * numEntries,
					   IFX_MAPI_WLAN_STA_WMM_Cfg **wlStaWmm, uint32 flags)
{
	int32 ret = IFX_SUCCESS, nCount = 0, i = 0, count, idxPerAc = 0, j = 0;
	char8 buf[MAX_FILELINE_LEN], *sWmmStaConfig = NULL;
	/* number of parameters per VAP:
	 * = four access categories * number of parameters per ac
	 */
	int32 nParamsPerVap = IFX_MAPI_WLAN_WMM_NUM_AC*WLAN_WMM_STA_PARAM_COUNT;
	IFX_NAME_VALUE_PAIR array_fvp[LTQ_MAX_NUM_VAP*IFX_MAPI_WLAN_WMM_NUM_AC*WLAN_WMM_STA_PARAM_COUNT];

	LTQ_LOG_TIMESTAMP();
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanWmmStaConfig", "mainCpeId: %d",
		mainCpeId);

	/* in this case always four entries are present (four access categories) */
	nCount = IFX_MAPI_WLAN_WMM_NUM_AC;

	*wlStaWmm = NULL;
	IFX_MEM_ALLOC((*wlStaWmm), IFX_MAPI_WLAN_STA_WMM_Cfg *, nCount,
		      sizeof(IFX_MAPI_WLAN_STA_WMM_Cfg))

	if (!g_flagWmmStaConfig) {
		sprintf(buf, "%s", PREFIX_WLAN_WMM_STA);
		if ((ret =
			ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_WMM_STA, buf, IFX_F_DEFAULT,
				&sWmmStaConfig)) != IFX_SUCCESS) {
					goto IFX_Handler;
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanWmmStaConfig", "");
		}
	
		/* form an array of field value pairs for easier access to parameters */
		memset(array_fvp, 0x00, sizeof(array_fvp));
		form_array_fvp_from_cfgdb_buf(sWmmStaConfig, &count, array_fvp);
	
		for (j = 0; j < g_nVap; j++) {
			for (i = 0; i < nCount; i++) {
				idxPerAc = WLAN_WMM_STA_PARAM_COUNT*i;
				/* set some required params in wlApWmm */
				sprintf(g_wlWmmStaConfig[j][i].iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
				sprintf(g_wlWmmStaConfig[j][i].iid.cpeId.secName, "%s", TAG_WLAN_WMM_STA);
				g_wlWmmStaConfig[j][i].ac = i;
				g_wlWmmStaConfig[j][i].iid.cpeId.Id = atoi(array_fvp[idxPerAc + (j*nParamsPerVap)].value);
				g_wlWmmStaConfig[j][i].iid.pcpeId.Id = atoi(array_fvp[idxPerAc + 1 + (j*nParamsPerVap)].value);
				g_wlWmmStaConfig[j][i].ECWmin = atoi(array_fvp[idxPerAc + 2 + (j*nParamsPerVap)].value);
				g_wlWmmStaConfig[j][i].ECWmax = atoi(array_fvp[idxPerAc + 3 + (j*nParamsPerVap)].value);
				g_wlWmmStaConfig[j][i].AIFSN = atoi(array_fvp[idxPerAc + 4 + (j*nParamsPerVap)].value);
				g_wlWmmStaConfig[j][i].TXOP = atoi(array_fvp[idxPerAc + 5 + (j*nParamsPerVap)].value);
				g_wlWmmStaConfig[j][i].ackPolicyEna = atoi(array_fvp[idxPerAc + 6 + (j*nParamsPerVap)].value);
				if (g_wlWmmStaConfig[j][i].iid.pcpeId.Id == mainCpeId) {
					memcpy((*wlStaWmm+i), &g_wlWmmStaConfig[j][i], sizeof(IFX_MAPI_WLAN_STA_WMM_Cfg));
				}
			}
		}
		g_flagWmmStaConfig = 1;
	}
	else {
		for (j = 0; j < g_nVap; j++) {
			if (g_wlWmmStaConfig[j][0].iid.pcpeId.Id == mainCpeId) {
				memcpy(*wlStaWmm, &g_wlWmmStaConfig[j][0],
					sizeof(IFX_MAPI_WLAN_STA_WMM_Cfg) * nCount);
			}
		}
	}
	*numEntries = nCount;

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanWmmStaConfig", "ret: %d", ret);
	IFX_MEM_FREE(sWmmStaConfig);
	if (ret != IFX_SUCCESS)
		IFX_MEM_FREE(*wlStaWmm)

	LTQ_LOG_TIMESTAMP();
	return ret;
}

/**
   This API configures the WLAN WMM parameters for outbound traffic.

   \param oper

   \param wlApWmm

   \param flags

   \return
   - IFX_SUCCESS
   - IFX_FAILURE

   \remarks - This API differs a little from the usual set APIs. The format for
              storage in rc.conf is prefix{pcpeid}_<Inst>_param which
              is against conventional prefix_0_param. Therefore the usage
              of the utility functions must be done carefully
            - This API cannot be called for all four access categories (AC)
              combined. since notification, update map and acl need single
              instance iid, we cannot have the API handle all the 4 instances
              at a time. Therefore it should be called for each of the 4 ACs
              one by one.
*/
int32 ifx_mapi_set_wlan_wmm_ap_config(uint32 operation,
				      IFX_MAPI_WLAN_AP_WMM_Cfg * wlApWmm,
				      uint32 flags)
{
	CPE_ID pCpeId;
	int32 ret = IFX_SUCCESS, count = 0, changed_count = 0, passed_index = -1;
	char8 conf_buf[MAX_DATA_LEN], prefix[MAX_FILELINE_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_WMM_AP_PARAM_COUNT + 1];
	IFX_NAME_VALUE_PAIR *array_changed_fvp = NULL;
	char *tmp, buf[3];

	LTQ_LOG_TIMESTAMP();
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmApConfig", "cpeId: %s, %d",
		       wlApWmm->iid.cpeId.secName, wlApWmm->iid.cpeId.Id);

	memset(conf_buf, 0x00, sizeof(conf_buf));
	memset(array_fvp, 0x00, sizeof(array_fvp));

   /*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY) 
	 * append the flag with internal flags */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmApConfig", "");
   /**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(wlApWmm)
		    /* Do simple validation of flags sucha as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

	sprintf(wlApWmm->iid.cpeId.secName, "%s", TAG_WLAN_WMM_AP);
	sprintf(wlApWmm->iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);

   /**************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_ADD_F_SET(flags)) {
		if (ifx_get_IID(&wlApWmm->iid, "ECWmin") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmApConfig",
				       "");
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}

		/* workaround for changing the tr69id as 1 for all wmm objects */
		tmp = NULL;
		tmp = strrchr(wlApWmm->iid.tr69Id, '.');
		if (tmp)
			*tmp = '\0';

		tmp = strrchr(wlApWmm->iid.tr69Id, '.');
		if (tmp != NULL) {
			sprintf(buf, "%d.",
				(wlApWmm->iid.cpeId.Id % 4) >
				0 ? wlApWmm->iid.cpeId.Id % 4 : 4);
			strcpy(tmp + 1, buf);
		}

		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmApConfig",
			       "tr69Id: %s", wlApWmm->iid.tr69Id);
	}

   /**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given structure for ADD/MODIFY
	 * Operations 
	 */

	sprintf(prefix, "%s%d", PREFIX_WLAN_WMM_AP, wlApWmm->iid.pcpeId.Id);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmApConfig", "prefix: %s",
		       prefix);

	count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, count,
					WLAN_WMM_AP_PARAM_COUNT,
					wlan_ap_wmm_params);

		sprintf(array_fvp[0].value, "%d", wlApWmm->iid.cpeId.Id);
		sprintf(array_fvp[1].value, "%d", wlApWmm->iid.pcpeId.Id);
		sprintf(array_fvp[2].value, "%d", wlApWmm->ECWmin);
		sprintf(array_fvp[3].value, "%d", wlApWmm->ECWmax);
		sprintf(array_fvp[4].value, "%d", wlApWmm->AIFSN);
		sprintf(array_fvp[5].value, "%d", wlApWmm->TXOP);
		sprintf(array_fvp[6].value, "%d", wlApWmm->ackPolicyEna);
		sprintf(array_fvp[7].value, "%d", wlApWmm->admCntrl);
		passed_index = -1;
	}
	count = WLAN_WMM_AP_PARAM_COUNT;

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmApConfig", "cpeId: %s, %d",
		       wlApWmm->iid.cpeId.secName, wlApWmm->iid.cpeId.Id);
	/* get configuration index in case of modify operation from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags)))
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlApWmm->iid.cpeId,
					 passed_index)

		    /*
		       in case of add or delete operation first assign wlApWmm->ac to passed_index
		       and then call the function, so that it does not try to get the new index
		       from section count
		     */
		    if (IFX_INT_ADD_F_SET(flags))
			passed_index = wlApWmm->ac;

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmApConfig", "passed_index: %d",
		       passed_index);
	/*
	   Determine the configuration index - for Add, Delete, Modify operations 
	   \note - Name is partial since index is not known 
	   - Fill array_fvp[]
	 */
	if (ifx_get_conf_index_and_nv_pairs(&wlApWmm->iid, passed_index, prefix,
					    count, array_fvp,
					    flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif				/* #ifdef IFX_LOG_DEBUG */
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmApConfig", "");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

   /************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	if (IFX_ADD_F_NOT_SET(flags) && IFX_INT_DONT_CHECK_ACL_F_NOT_SET(flags)) {
		CHECK_ACL_RET(wlApWmm->iid, count, array_fvp,
			      changed_count, array_changed_fvp, flags,
			      IFX_Handler)
	}

	/*
	   for stopping the correct AP/VAP we need to get the index of the AP;
	   this is not the index of the wlan_sta_wmm object, but the index of
	   the correspondig parent (wlan_main object); therefore we pass the
	   pCpeId (cpeId of wlan_main) to this macro; the retrieved index is
	   saved in passed_index
	 */
	/* use the parent cpeid to get index of the parent instance */
	pCpeId.Id = wlApWmm->iid.pcpeId.Id;
	sprintf(pCpeId.secName, "%s", TAG_WLAN_MAIN);
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, pCpeId, passed_index)

	/*
	   before updating the config file:
	   stop the AP/VAP in case of delete operation only
	 */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags) && IFX_DELETE_F_SET(flags)) {
		    sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, passed_index);
		LTQ_LOG_TIMESTAMP();
		system(conf_buf);
		LTQ_LOG_TIMESTAMP();
	}

   /************** System Config File Update Block ****************/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	if ((ret = form_cfgdb_buf(conf_buf, count, array_fvp)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmApConfig", "");
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmApConfig", "conf_buf: %s",
		       conf_buf);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_WMM_AP, flags, 1, conf_buf);
	if (ret != IFX_SUCCESS) {
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		goto IFX_Handler;
	}

   /**************** Device Configuration Block *********************/
	/*
	   Device config thru Scripts/Utilities or Functions
	   after config file update, for modify operation start script for applying
	   the changes
	 */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags)) {
		if (operation == IFX_OP_MOD) {
			sprintf(conf_buf, "%s %d", SERVICE_WLAN_WMM_MODIFY, passed_index);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmApConfig", "conf_buf: %s",
				conf_buf);
			LTQ_LOG_TIMESTAMP();
			system(conf_buf);
			LTQ_LOG_TIMESTAMP();
		}
	}

	/* this will Compact the section and also update the count for both ADD and DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags)) {
		ret =
		    ifx_UpdateCountInSection(FILE_RC_CONF, TAG_WLAN_WMM_AP,
					     flags);
		if (ret != IFX_SUCCESS) {
			IFX_DBG("[%s:%d]: ret: %d", __FUNCTION__, __LINE__, ret);
			goto IFX_Handler;
		}
	}

   /*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_MODIFY_F_SET(flags)) {
      /*************** Notification Block *****************/
		/* Notify the Internal TR69 Stack in case of MODIFY */
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmApConfig", "");
		CHECK_N_SEND_NOTIFICATION(wlApWmm->iid, changed_count,
					  array_changed_fvp, flags, IFX_Handler)
	} else if (IFX_INT_ADD_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmApConfig", "");
		/*
		   in case of ADD operation update the ID Mappings and then send the
		   notification for the attributes
		 */
		UPDATE_ID_MAP_N_ATTRIBUTES(&wlApWmm->iid, count, array_fvp,
					   flags, IFX_Handler)
		    CHECK_N_SEND_NOTIFICATION(wlApWmm->iid, count, array_fvp,
					      flags, IFX_Handler)

		    /* Manipulate nextCpeId only for ADD operations */
	    ret = ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WLAN_WMM_AP);
		if (ret != IFX_SUCCESS) {
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
			goto IFX_Handler;
		}
	} else if (IFX_DELETE_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmApConfig", "");
		/*
		   in case of DELETE operation, first send notificaton, then update the
		   ID Mappings
		 */
		CHECK_N_SEND_NOTIFICATION(wlApWmm->iid, count, array_fvp, flags,
					  IFX_Handler)

		    /*
		       The TR69 mapping section is updated. Also the TR69 parameter
		       Attribute section is updated.
		       This is required to keep the TR69 specific sections up-to-date.
		     */
		    UPDATE_ID_MAP_N_ATTRIBUTES(&wlApWmm->iid, count, array_fvp,
					       flags, IFX_Handler)
		    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmApConfig",
				   "ret: %d", ret);
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmApConfig", "");
	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		goto IFX_Handler;
	}
	g_flagWmmApConfig = 0;

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmApConfig", "ret: %d", ret);
	IFX_MEM_FREE(array_changed_fvp);
	LTQ_LOG_TIMESTAMP();
		return ret;
}

/**
   This API configures the WLAN WMM parameters for inbound traffic.

   \param oper

   \param wlStaWmm

   \param flags

   \return
   - IFX_SUCCESS
   - IFX_FAILURE

   \remarks - This API differs a little from the usual set APIs. The format for
              storage in rc.conf is prefix{pcpeid}_<Inst>_param which
              is against conventional prefix_0_param. Therefore the usage
              of the utility functions must be done carefully
            - This API cannot be called for all four access categories (AC)
              combined. since notification, update map and acl need single
              instance iid, we cannot have the API handle all the 4 instances
              at a time. Therefore it should be called for each of the 4 ACs
              one by one.
*/
int32 ifx_mapi_set_wlan_wmm_sta_config(uint32 operation,
				       IFX_MAPI_WLAN_STA_WMM_Cfg * wlStaWmm,
				       uint32 flags)
{
	CPE_ID pCpeId;
	int32 ret = IFX_SUCCESS, count = 0, changed_count = 0, passed_index = -1;
	char8 conf_buf[MAX_DATA_LEN], prefix[MAX_FILELINE_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_WMM_AP_PARAM_COUNT + 1];
	IFX_NAME_VALUE_PAIR *array_changed_fvp = NULL;
	char *tmp, buf[3];

	LTQ_LOG_TIMESTAMP();

	/*
	   initalize buffer conf_buf which is used for two purposes:
	   - holding the configuration for wlan_ap_wmm to be written to rc.conf
	   - holding the commands for system calls
	 */
	memset(conf_buf, 0x00, sizeof(conf_buf));
	/*
	   initalize buffer array_fvp which is used for storing the new configuration
	   of wlan_ap_wmm in field-value format
	 */
	memset(array_fvp, 0x00, sizeof(array_fvp));

   /*************** Prolog Block *********************/
	/*
	   based on the operation (ADD or DELETE or MODIFY), the flags variable
	   is appended with internal flags
	 */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmStaConfig", "");
   /*************** Validation Block *****************/
	/*
	   for operations other than DELETE do the verification of input params
	 */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer (such as is NULL) */
		IFX_VALIDATE_PTR(wlStaWmm)
		    /* Do simple validation of flags such as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

	/* section name of this object is TAG_WLAN_WMM_STA */
	sprintf(wlStaWmm->iid.cpeId.secName, "%s", TAG_WLAN_WMM_STA);
	/* section name of parent object is TAG_WLAN_MAIN */
	sprintf(wlStaWmm->iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);

   /*************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_ADD_F_SET(flags)) {
		/*
		   get the next cpe id for the section wlan_sta_wmm from the next_cpe_id
		   section in rc.conf and stores it as cpeId; the distinct parameter
		   ECWmin is provided for TR69
		 */
		if (ifx_get_IID(&wlStaWmm->iid, "ECWmin") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmStaConfig",
				       "");
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}

		/* workaround for changing the tr69id as 1 for all wmm objects */
		tmp = NULL;
		tmp = strrchr(wlStaWmm->iid.tr69Id, '.');
		if (tmp)
			*tmp = '\0';

		tmp = strrchr(wlStaWmm->iid.tr69Id, '.');
		if (tmp != NULL) {
			sprintf(buf, "%d.",
				(wlStaWmm->iid.cpeId.Id % 4) >
				0 ? wlStaWmm->iid.cpeId.Id % 4 : 4);
			strcpy(tmp + 1, buf);
		}

		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmStaConfig",
			       "tr69Id: %s", wlStaWmm->iid.tr69Id);
	}

	/*
	   the format for wlan_sta_wmm object is wlswmm<pCpeId>_<Index>_param
	   for this purpose we are defining the used prefix wlswmm<pCpdId> here
	 */
	sprintf(prefix, "%s%d", PREFIX_WLAN_WMM_STA, wlStaWmm->iid.pcpeId.Id);
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmStaConfig", "prefix: %s",
		       prefix);

   /**************** Name Value Formation as per RC.CONF ********************/
	/*
	   form the field-value pairs(FVP) from the given structure for ADD/MODIFY
	   Operations 
	 */
	count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		/*
		   the buffer array_fvp is filled in a first step with the field names
		   of wlan_sta_wmm object
		 */
		ifx_fill_ArrayFvp_FName(array_fvp, count,
					WLAN_WMM_STA_PARAM_COUNT,
					wlan_sta_wmm_params);

		sprintf(array_fvp[0].value, "%d", wlStaWmm->iid.cpeId.Id);
		sprintf(array_fvp[1].value, "%d", wlStaWmm->iid.pcpeId.Id);
		sprintf(array_fvp[2].value, "%d", wlStaWmm->ECWmin);
		sprintf(array_fvp[3].value, "%d", wlStaWmm->ECWmax);
		sprintf(array_fvp[4].value, "%d", wlStaWmm->AIFSN);
		sprintf(array_fvp[5].value, "%d", wlStaWmm->TXOP);
		sprintf(array_fvp[6].value, "%d", wlStaWmm->ackPolicyEna);
		passed_index = -1;
	}

	/* store number of parameters for wlan_sta_wmm object in count */
	count = WLAN_WMM_STA_PARAM_COUNT;

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmStaConfig", "");
	/*
	   get configuration index in case of modify operation from CPEID and save
	   it in passed_index
	 */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags)))
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlStaWmm->iid.cpeId, passed_index)

		    /*
		       in case of add or delete operation first assign wlStaWmm->ac to
		       passed_index and then call the function ifx_get_conf_index_and_nv_pairs,
		       by doing that, the called function will not try to get the new index from
		       section count; this has to be done, because for wlan_sta_wmm object the
		       index is not incrementing continously, but corresponds directly to the
		       access category (AC)
		     */
		    if (IFX_INT_ADD_F_SET(flags))
			passed_index = wlStaWmm->ac;
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmStaConfig",
		       "passed_index: %d", passed_index);

	/*
	   determine the configuration index - for wlan_sta_wmm for Modify
	   operations only
	 */
	if (ifx_get_conf_index_and_nv_pairs
	    (&wlStaWmm->iid, passed_index, prefix, count, array_fvp,
	     flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif				/* #ifdef IFX_LOG_DEBUG */
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmStaConfig", "");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

   /********* ACL Checking block - MUST for MODIFY/DELETE operations **********/
	if (IFX_ADD_F_NOT_SET(flags) && IFX_INT_DONT_CHECK_ACL_F_NOT_SET(flags)) {
		/*
		   for modify operations only an array for changed parameters is saved
		   in array_changed_fvp;
		   for modify and delete operation also a TR69 plugin is called for access
		   control check
		 */
		CHECK_ACL_RET(wlStaWmm->iid, count, array_fvp,
			      changed_count, array_changed_fvp, flags,
			      IFX_Handler)
	}

		/*
		   for stopping the correct AP/VAP we need to get the index of the AP;
		   this is not the index of the wlan_sta_wmm object, but the index of
		   the correspondig parent (wlan_main object); therefore we pass the
		   pCpeId (cpeId of wlan_main) to this macro; the retrieved index is
		   saved in passed_index
		 */
	/* use the parent cpeid to get index of the parent instance */
	pCpeId.Id = wlStaWmm->iid.pcpeId.Id;
	sprintf(pCpeId.secName, "%s", TAG_WLAN_MAIN);
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, pCpeId, passed_index)

	/*
	   before updating the config file:
	   stop the AP/VAP in case of delete operation only
	 */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags) && IFX_DELETE_F_SET(flags)) {
#ifndef CONFIG_FEATURE_LTQ_WIRELESS_VB
		    sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, passed_index);
		LTQ_LOG_TIMESTAMP();
		system(conf_buf);
		LTQ_LOG_TIMESTAMP();
#endif
	}

   /*************** System Config File Update Block ****************/
	/*
	   convert the name value pair in array_fvp into string format expected by
	   rc.conf file
	 */
	if ((ret = form_cfgdb_buf(conf_buf, count, array_fvp)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmStaConfig", "");
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmStaConfig", "conf_buf: %s",
		       conf_buf);

	/* RC.CONF Configuration block */
	ret =
	    ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_WMM_STA, flags, 1, conf_buf);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmStaConfig", "");
		goto IFX_Handler;
	}

   /**************** Device Configuration Block *********************/
	/*
	   Device config thru Scripts/Utilities or Functions
	   after config file update, for modify operation start script for applying
	   the changes
	 */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags)) {
		if (operation == IFX_OP_MOD) {
			sprintf(conf_buf, "%s %d", SERVICE_WLAN_WMM_MODIFY, passed_index);
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmStaConfig",
					"conf_buf: %s", conf_buf);
			LTQ_LOG_TIMESTAMP();
			system(conf_buf);
			LTQ_LOG_TIMESTAMP();
		}
	}

	/* this will Compact the section and also update the count for both ADD and DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags)) {
		ret =
		    ifx_UpdateCountInSection(FILE_RC_CONF, TAG_WLAN_WMM_STA, flags);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]: ret: %d", __FUNCTION__, __LINE__, ret);
#endif
			goto IFX_Handler;
		}
	}

   /*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_MODIFY_F_SET(flags)) {
      /*********** Notification Block *************/
		/* Notify the Internal TR69 Stack in case of MODIFY */
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmStaConfig", "");
		CHECK_N_SEND_NOTIFICATION(wlStaWmm->iid, changed_count,
					  array_changed_fvp, flags, IFX_Handler)
	} else if (IFX_INT_ADD_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmStaConfig", "");
		/*
		   in case of ADD operation update the ID Mappings, then send notification
		 */
      /*********** Epilog Block **************/
		UPDATE_ID_MAP_N_ATTRIBUTES(&wlStaWmm->iid, count, array_fvp,
					   flags, IFX_Handler)

		    CHECK_N_SEND_NOTIFICATION(wlStaWmm->iid, count, array_fvp,
					      flags, IFX_Handler)

		    /* Manipulate nextCpeId only for ADD operations */
		    ret =
		    ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WLAN_WMM_STA);
		if (ret != IFX_SUCCESS) {
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
			goto IFX_Handler;
		}
	} else if (IFX_DELETE_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmStaConfig", "");
		/*
		   in case of DELETE operation first send a notificaton, then update the
		   ID Mappings
		 */
		CHECK_N_SEND_NOTIFICATION(wlStaWmm->iid, count, array_fvp,
					  flags, IFX_Handler)
		    UPDATE_ID_MAP_N_ATTRIBUTES(&wlStaWmm->iid, count, array_fvp,
					       flags, IFX_Handler)
		    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmStaConfig",
				   "ret: %d", ret);
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmStaConfig", "");
	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		goto IFX_Handler;
	}
	g_flagWmmStaConfig = 0;

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmStaConfig", "ret: %d", ret);
	IFX_MEM_FREE(array_changed_fvp);
	LTQ_LOG_TIMESTAMP();
		return ret;
}
#endif				/* #if defined (CONFIG_FEATURE_IFX_WIRELESS) */
