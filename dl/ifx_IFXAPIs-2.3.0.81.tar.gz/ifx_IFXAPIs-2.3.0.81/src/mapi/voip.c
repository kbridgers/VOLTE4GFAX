#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"

#ifdef CONFIG_FEATURE_IFX_VOIP
int32 ifx_set_voip_interface(int32 wan_idx, WAN_TYPE wan_type, uint32 flags)
{
	int32 prev_sip_if = 0, ret = IFX_SUCCESS;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN],
	    sCommand[MAX_FILELINE_LEN];
	WAN_TYPE prev_wan_type;

	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	NULL_TERMINATE(sValue, 0x00, sizeof(sValue));
	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));

	/* get the previous wan index on which voip is running */
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_SIP, "SIP_IF", IFX_F_GET_ANY,
			    &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	if (strstr(sValue, "WANIP") != NULL) {
		sscanf(sValue, "WANIP%d", &prev_sip_if);
		prev_wan_type = WAN_TYPE_IP;
	} else {
		sscanf(sValue, "WANPPP%d", &prev_sip_if);
		prev_wan_type = WAN_TYPE_PPP;
	}

	/* call voip stop with this wan index */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)
	    && IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) {
		sprintf(sCommand, "/etc/rc.d/rc.bringup_voip_stop %d %s",
			prev_sip_if, (prev_wan_type == WAN_TYPE_IP) ? "ip" : "ppp");
		ret = system(sCommand);
		ret = IFX_SUCCESS;
	}

	/* Backup rc.conf before proceeding with configuration */
	/* update wan index for voip in rc.conf with wan_idx */
	sprintf(buf, "SIP_IF=\"%s%d\"\n",
		(wan_type == WAN_TYPE_IP) ? "WANIP" : "WANPPP", wan_idx);
	if ((ret =
	     ifx_SetObjData(FILE_RC_CONF, TAG_SIP, flags, 1,
			    buf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* call voip start with wan_idx */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)
	    && IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)
			&& IFX_INT_DONT_START_SERVICES_F_NOT_SET(flags)) {
		sprintf(sCommand, "/etc/rc.d/rc.bringup_voip_start %d %s",
			wan_idx, (wan_type == WAN_TYPE_IP) ? "ip" : "ppp");
		ret = system(sCommand);
		ret = IFX_SUCCESS;
	}

	/***************** Epilog Block **********************/
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}
#endif
