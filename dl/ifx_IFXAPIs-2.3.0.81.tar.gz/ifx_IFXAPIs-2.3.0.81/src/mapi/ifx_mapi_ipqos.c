/*/////////////////////////////////////////////////////////////////////////////
Thie file contains all functions used for ifx_qos implementation
//////////////////////////////////////////////////////////////////////////////
*/

#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#include <stdlib.h>
#include <ifx_emf.h>
#include <arpa/inet.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"
//#include "ifx_mapi_qos.h"

#define INITIAL_CLASS_QUEUE_MAP "-1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1"

char8 *ipqos_classify_params[] = { "cpeId", "pcpeId", "tcId", "qId", "pId",
	"type", "classifType", "ifType", "proto", "l3proto", "srcPort", "srcPortEnd", "dstPort",
	"dstPortEnd", "inDscp", "dscpMark", "inPBits", "PBitsMark", "vlanId",
	    "rateLmt",
	"order", "fwPolicy", "enable", "srcIPExcl", "dstIPExcl", "protoExcl", "l3protoExcl", 
	    "srcPortExcl",
	"dstPortExcl", "srcMacExcl", "dstMacExcl", "inDscpExcl", "inPBitsExcl",
	"vlanIdExcl", "rateCtrlEnbl", "className", "ifname", "srcIP",
	    "srcIPMask",
	"dstIP", "dstIPMask", "srcMac", "srcMacMask", "dstMac", "dstMacMask",
	    "specIf", "disableAccel"
};

char8 *ipqos_ds_classify_params[] = { "cpeId", "pcpeId", "tcId", "qId", "pId",
	"type", "classifType", "ifType", "proto", "l3proto", "srcPort", "srcPortEnd", "dstPort",
	"dstPortEnd", "inDscp", "dscpMark", "inPBits", "PBitsMark", "vlanId",
	"rateLmt",
	"order", "fwPolicy", "enable", "srcIPExcl", "dstIPExcl", "protoExcl", "l3protoExcl", 
	"srcPortExcl",
	"dstPortExcl", "srcMacExcl", "dstMacExcl", "inDscpExcl", "inPBitsExcl",
	"vlanIdExcl", "rateCtrlEnbl", "className", "ifname", "srcIP",
	"srcIPMask",
	"dstIP", "dstIPMask", "srcMac", "srcMacMask", "dstMac", "dstMacMask",
	"specIf", "disableAccel"
};

char8 *ipqos_capabilty_params[] = {
	"qcap_cpeId", "qcap_pcpeId", "qcap_schedAlgo", "qcap_dropAlgo",
	    "qcap_meterType",
	"qcap_maxInQs", "qcap_maxOutQs", "qcap_maxClassifiers", "qcap_maxApps",
	    "qcap_maxFlows", "qcap_maxPolicers", "qcap_numID",
	"qcap_inShapSupport", "qcap_policerSupport"
};

char8 *ipqos_queue_params[] =
    { "cpeId", "pcpeId", "qIfType", "dropType", "schedType", "shapeRate",
	"qLen", "qWt", "qPrio", "redTh", "redPct", "sbs", "peakRate",
	    "commitRate",
	"enable", "wtEnable", "shaperEnable",
	"qName", "qIf", "trafficClass", "egressPVC", "uiRedTh", "flRedProb"
};

char8 *ipqos_qm_params[] = {
	"qm_cpeId", "qm_pcpeId", "qm_defDSCP", "qm_defPbits", "qm_defQ",
	    "qm_defPolicer", "qm_defTC", "qm_atmQmode",
	"qm_defFwPolicy", "qm_upPortRateLim", "qm_downPortRateLim",
	"qm_enable", "qm_USenable", "qm_DSenable", "qm_P8021enable", "qm_portRateLimEnab", "qm_DSportRateLimEnab", "qm_tcpackprio",
	"qm_appList",
	"qm_qIf", "qm_AccelMngr"
};

char8 *ipqos_policer_params[] = {
	"cpeId", "pcpeId", "mtrType", "cAc", "pcAc", "ncAc",
	"cr", "cbs", "ebs", "pr", "pbs", "cDscp", "cPbits", "pcDscp", "pcPbits",
	    "ncDscp", "ncPbits",
	"enable",
	"pName"
};

char8 *ipqos_queuestats_params[] = {
	"cpeId", "pcpeId", "interface", "queueinst",  "outpacks", "outbytes", "droppacks", "dropbytes", "qoccpacks", "qoccpercent", "enable", "status"
};

/*flag to control init and modify default QM parameters in QM object */
#define IFX_MAPI_MAX_IPQOS_CAPABILITY_SECTION_PARAMS 14
#define IFX_MAPI_MAX_IPQOS_QUEUEMGMT_SECTION_PARAMS 21
#define IFX_MAPI_MAX_IPQOS_CLASSIFIER_SECTION_PARAMS 47
#define IFX_MAPI_MAX_IPQOS_QUEUE_SECTION_PARAMS  23
#define IFX_MAPI_MAX_IPQOS_POLICER_SECTION_PARAMS  19
#define IFX_MAPI_MAX_IPQOS_QUEUESTATS_SECTION_PARAMS  12

#define DEFAULT_REDTH  30
#define DEFAULT_REDPCT  2
#define DEFAULT_QLEN   102400
/* SET APIs */

/*//////////////////////////////////////////////////////////////////////////////
*  ifx_mapi_set_qos_qm (uint32 Oper, IFX_MAPI_QoS_QM *qos_qm, uint32 flags)
*  operation   ==>   the operation to be performed for this route entry, can be ADD, DELETE or MODIFY
*  qm     ==>   pointer to IFX_MAPI_QoS_QM structure that has QoS details
*  flags       ==>   flags that define the behaviour
*  Return Value :   IFX_SUCCESS or IFX_FAILURE
   Description:
     This function configures the QoS Queue Management  paramters.
*//////////////////////////////////////////////////////////////////////////////

int32 ifx_mapi_set_qos_qm(uint32 Oper, IFX_MAPI_QoS_QM * qos_qm, uint32 flags)
{
	char8 conf_buf[MAX_DATA_LEN];
	int count = 0, changed_count = 0;
	int ret = IFX_SUCCESS, retval = IFX_SUCCESS, retval2 = IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR
	    array_fvp[IFX_MAPI_MAX_IPQOS_QUEUEMGMT_SECTION_PARAMS + 1];
	IFX_NAME_VALUE_PAIR *array_changed_fvp = NULL;
	char8 sCommand[MAX_FILELINE_LEN], old_enable[20], old_tcpackprio[20], old_USenable[20], old_DSenable[20], old_8021Penable[20], old_AccelMngr[20], old_P8021enable[20];
	uint32 outflag = flags;
	char8 sLine[256];
	/* IFX_MAPI_QoS_Interface_Type qIfType;
	IFX_MAPI_QoS_Interface_Type LqIfType; */
	
	//IFX_MAPI_QoS_Queue *Lqos_queues = NULL;
	WAN_PHY_CFG pstWanPhy;
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	ifx_get_wan_phy_cfg(&pstWanPhy);
	//int def_queue_cpeid = 0, ds_def_queue_cpeid = 0;
	int def_queue_cpeid = 0;

/* Get Active QoS Interface */
	//qIfType = ifx_mapi_get_active_qos_iface();
   int wan_changeover=0;

	memset(array_fvp, 0, sizeof(array_fvp));
/*************** Prolog Block *********************/
/* Based on operation (ADD or DELETE or MODIFY)
 * append the flag with internal flags */
	if (Oper == IFX_OP_DEL || Oper == IFX_OP_ADD) {

#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("[%s:%d] Add/Delete operation not supported on this object",
		     __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	} else
		flags |= IFX_F_MODIFY;

/**************** Validation Block *****************/
/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(qos_qm)
/* Do simple validation of flags sucha as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

	/* Set the parent SectioddnName and parent IID values
	 */
	sprintf(qos_qm->iid.cpeId.secName, "%s", TAG_IPQOS_QM);
	qos_qm->iid.pcpeId.Id = 1;	/*parent of QM object is IGD=1 */

	/* Set the port rate if it is not given by the user */
	if (!qos_qm->portRateLimitEnable) {
		if((ifx_GetObjData("/tmp/system_status", "qos_bk", "up_link_rate",
			       IFX_F_GET_ENA, 0, sLine)) != IFX_SUCCESS){
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			if ((ifx_GetObjData
		 		(FILE_RC_CONF, TAG_IPQOS_QM, "qm_upPortRateLim", IFX_F_GET_ANY,
		  		0, sLine)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
		qos_qm->upstreamPortRateLimit = atoi(sLine);
	}
	if (!qos_qm->DSportRateLimitEnable) {
		if((ifx_GetObjData("/tmp/system_status", "qos_bk", "down_link_rate",
			       IFX_F_GET_ENA, 0, sLine)) != IFX_SUCCESS){
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			if ((ifx_GetObjData
		 		(FILE_RC_CONF, TAG_IPQOS_QM, "qm_downPortRateLim", IFX_F_GET_ANY,
		  		0, sLine)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
		qos_qm->downstreamPortRateLimit = atoi(sLine);
	}
	if ((ifx_GetObjData
		 (FILE_RC_CONF, TAG_IPQOS_QM, "qm_enable", IFX_F_GET_ANY,
		  &outflag, old_enable)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	    //This is the US enable  as in RC.CONF
	if ((ifx_GetObjData
		 (FILE_RC_CONF, TAG_IPQOS_QM, "qm_USenable", IFX_F_GET_ANY,
		  &outflag, old_USenable)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	    //This is the DS enable  as in RC.CONF
	if ((ifx_GetObjData
		 (FILE_RC_CONF, TAG_IPQOS_QM, "qm_DSenable", IFX_F_GET_ANY,
		  &outflag, old_DSenable)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	    //This is the 8021P enable  as in RC.CONF
	if ((ifx_GetObjData
		 (FILE_RC_CONF, TAG_IPQOS_QM, "qm_P8021enable", IFX_F_GET_ANY,
		  &outflag, old_8021Penable)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	//Get old value of TCP ACK Prio from rc.conf
	if ((ifx_GetObjData
	     (FILE_RC_CONF, TAG_IPQOS_QM, "qm_tcpackprio", IFX_F_GET_ANY,
	      &outflag, old_tcpackprio)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	//Get old value of classifier Acceleration manager from RC.CONF
	if ((ifx_GetObjData
		 (FILE_RC_CONF, TAG_IPQOS_QM, "qm_AccelMngr", IFX_F_GET_ANY,
		  &outflag, old_AccelMngr)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	//Get old value of Global 8021p remarking from RC.CONF
	if ((ifx_GetObjData
		 (FILE_RC_CONF, TAG_IPQOS_QM, "qm_P8021enable", IFX_F_GET_ANY,
		  &outflag, old_P8021enable)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	//printf("[%s:%d] Acel_Mngr = %s old_Accel_Mngr = %s \n", __FUNCTION__, __LINE__, &qos_qm->class_accel_mngr, old_AccelMngr);
#if 0
	//Get old VCC value from RC.CONF
	if ((ifx_GetObjData
	     (FILE_RC_CONF, TAG_IPQOS_QM, "qm_qIf", IFX_F_GET_ANY, &outflag,
	      old_vcc)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]%s", __FUNCTION__, __LINE__, old_vcc);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
#endif


	if ((qos_qm->enable == IFX_ENABLED)
	    && (atoi(old_enable) == 0)) {
		qos_qm->USenable = 1;
		qos_qm->DSenable = 1;
	}
	if ((qos_qm->enable == IFX_DISABLED)
	    && (atoi(old_enable) == 1)) {
		qos_qm->USenable = 0;
		qos_qm->DSenable = 0;
		qos_qm->P8021enable = 0;
	}
	//printf("[%s:%d] ====qos_qm->enable = %d old_enable = %s US Enable =%d DS Enable =%d ====",__FUNCTION__, __LINE__,qos_qm->enable,old_enable,qos_qm->USenable,qos_qm->DSenable);
    /**************** ID Allocation Block - Only for ADD Operation **************/
	/* Nothing to be done here */

	 /**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given structure for ADD/MODIFY
	 * Operations
	 */

	ifx_fill_ArrayFvp_FName(array_fvp, 0,
				IFX_MAPI_MAX_IPQOS_QUEUEMGMT_SECTION_PARAMS,
				ipqos_qm_params);
	count = 0;
	ifx_fill_ArrayFvp_intValues(array_fvp, 0, 8,
				    (int *)&qos_qm->iid.cpeId.Id,
				    &qos_qm->iid.pcpeId.Id,
				    &qos_qm->defaultDSCP,
				    &qos_qm->defaultPbits,
				    &qos_qm->defaultQ,
				    &qos_qm->defaultPolicer,
				    &qos_qm->defaultTC, &qos_qm->atmQMode);

	ifx_fill_ArrayFvp_uintValues(array_fvp, 8, 3,
				     &qos_qm->defaultFwPolicy,
				     &qos_qm->upstreamPortRateLimit,
				     &qos_qm->downstreamPortRateLimit);

	ifx_fill_ArrayFvp_boolValues(array_fvp, 11, 7,
				     &qos_qm->enable,
				     &qos_qm->USenable,
				     &qos_qm->DSenable,
				     &qos_qm->P8021enable,
				     &qos_qm->portRateLimitEnable,
				     &qos_qm->DSportRateLimitEnable,
				     &qos_qm->tcpackprio);

	ifx_fill_ArrayFvp_strValues(array_fvp, 18, 1, qos_qm->availableAppList);
	//handling for qIf 
	ifx_fill_ArrayFvp_strValues(array_fvp, 19, 1, qos_qm->qIf);
	//handling for qIf
	//handling for classifier acceleration manager
	ifx_fill_ArrayFvp_boolValues(array_fvp, 20, 1, &qos_qm->class_accel_mngr);

	count = IFX_MAPI_MAX_IPQOS_QUEUEMGMT_SECTION_PARAMS;


/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	CHECK_ACL_RET(qos_qm->iid, count, array_fvp,
		      changed_count, array_changed_fvp, flags, IFX_Handler)

//Update RC.CONF with default information
	if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2) {
		if (pstWanPhy.wan_tc == WAN_TC_ATM) {
			//qIfType = IFX_MAPI_QoS_WAN_ATM;
			def_queue_cpeid = 9;
			//LqIfType = IFX_MAPI_QoS_LAN_ATM;
			//ds_def_queue_cpeid = 13;
		}
		if (pstWanPhy.wan_tc == WAN_TC_PTM) {
			//qIfType = IFX_MAPI_QoS_WAN_PTM;
			def_queue_cpeid = 12;
			//LqIfType = IFX_MAPI_QoS_LAN_PTM;
			//ds_def_queue_cpeid = 14;
		}
	} else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII0) {
		//qIfType = IFX_MAPI_QoS_WAN_ETH_0;
		def_queue_cpeid = 10;
		//LqIfType = IFX_MAPI_QoS_LAN_ETH_0;
		//ds_def_queue_cpeid = 15;
	} else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII1) {
		//qIfType = IFX_MAPI_QoS_WAN_ETH_1;
		def_queue_cpeid = 11;
		//LqIfType = IFX_MAPI_QoS_LAN_ETH_1;
		//ds_def_queue_cpeid = 16;
	} else if (pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2) {
		//qIfType = IFX_MAPI_QoS_WAN_PTM;
		def_queue_cpeid = 12;
		//LqIfType = IFX_MAPI_QoS_LAN_PTM;
		//ds_def_queue_cpeid = 14;
	} else {
		/* Setting def to ATM : This will never be hit */
		//qIfType = IFX_MAPI_QoS_WAN_ATM;
		def_queue_cpeid = 9;
		//LqIfType = IFX_MAPI_QoS_LAN_ATM;
		//ds_def_queue_cpeid = 13;
	}
	qos_qm->defaultQ = def_queue_cpeid;

	/* Perform some rate related validations */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) 
	{
		if (IFX_MODIFY_F_SET(flags)) {
			if (IFX_DEACTIVATE_F_NOT_SET(flags)) {


#if 1
				if ((qos_qm->enable == IFX_ENABLED)
				    && (atoi(old_enable) == 0)) {
					retval =
					    ipqos_rate_validate(8,
								qos_qm->
								upstreamPortRateLimit,
								NULL);
					retval2 =
					    ipqos_rate_validate_DS(8,
								qos_qm->
								downstreamPortRateLimit,
								NULL); 
					if (retval != IFX_SUCCESS)  {
						IFX_API_LOG
						    ("[%s:%d] [D->E].Upstream Rate Validation Failed",
						     __FUNCTION__, __LINE__);
						ret = retval;
						goto IFX_Handler;
					}
					if (retval2 != IFX_SUCCESS)  {
						IFX_API_LOG
						    ("[%s:%d] [D->E].Downstream Rate Validation Failed",
						     __FUNCTION__, __LINE__);
						ret = retval2;
						goto IFX_Handler;
					}
				}
				if ((qos_qm->enable == IFX_ENABLED)
				    && (atoi(old_enable) == 1)) {
					retval =
					    ipqos_rate_validate(8,
								qos_qm->
								upstreamPortRateLimit,
								NULL);
					retval2 =
					    ipqos_rate_validate_DS(8,
								qos_qm->
								downstreamPortRateLimit,
								NULL); 
					if (retval != IFX_SUCCESS) {
						IFX_API_LOG
						    ("[%s:%d] [E->E]. Upstream Rate Validation Failed.",
						     __FUNCTION__, __LINE__);
						ret = retval;
						goto IFX_Handler;
					}
					if (retval2 != IFX_SUCCESS)  {
						IFX_API_LOG
						    ("[%s:%d] [D->E].Downstream Rate Validation Failed",
						     __FUNCTION__, __LINE__);
						ret = retval2;
						goto IFX_Handler;
					}
				}
				if ((qos_qm->enable == IFX_DISABLED)
				    && (atoi(old_enable) == 1)) {
					retval =
					    ipqos_rate_validate(8,
								qos_qm->
								upstreamPortRateLimit,
								NULL);
					retval2 =
					    ipqos_rate_validate_DS(8,
								qos_qm->
								downstreamPortRateLimit,
								NULL); 
					if (retval != IFX_SUCCESS){
						IFX_API_LOG
						    ("[%s:%d] [E->D].Upstream  Rate Validation Failed.",
						     __FUNCTION__, __LINE__);
						ret = retval;
						goto IFX_Handler;
					}
					if (retval2 != IFX_SUCCESS)  {
						IFX_API_LOG
						    ("[%s:%d] [D->E].Downstream Rate Validation Failed",
						     __FUNCTION__, __LINE__);
						ret = retval2;
						goto IFX_Handler;
					}
				}
				if ((qos_qm->enable == IFX_DISABLED)
				    && (atoi(old_enable) == 0)) {
					retval =
					    ipqos_rate_validate(8,
								qos_qm->
								upstreamPortRateLimit,
								NULL);
					retval2 =
					    ipqos_rate_validate_DS(8,
								qos_qm->
								downstreamPortRateLimit,
								NULL);
					if (retval != IFX_SUCCESS) {
						IFX_API_LOG
						    ("[%s:%d] [D->D]. Upstream Rate Validation Failed.",
						     __FUNCTION__, __LINE__);
						ret = retval;
						goto IFX_Handler;
					}
					if (retval2 != IFX_SUCCESS)  {
						IFX_API_LOG
						    ("[%s:%d] [D->E].Downstream Rate Validation Failed",
						     __FUNCTION__, __LINE__);
						ret = retval2;
						goto IFX_Handler;
					}
				}
#else
				retval =
				    ipqos_rate_validate(8,
							qos_qm->
							upstreamPortRateLimit,
							NULL);
				retval2 =
				    ipqos_rate_validate_DS(8,
							qos_qm->
							downstreamPortRateLimit,
							NULL);
				if (retval != IFX_SUCCESS) {
					IFX_API_LOG
					    ("[%s:%d] Upstream Rate Validation Failed",
					     __FUNCTION__, __LINE__);
					ret = retval;
					goto IFX_Handler;
				}
				if (retval2 != IFX_SUCCESS)  {
					IFX_API_LOG
					    ("[%s:%d] [D->E].Downstream Rate Validation Failed",
					     __FUNCTION__, __LINE__);
					ret = retval2;
					goto IFX_Handler;
				}

				//Acceleration manager part
			
				if ((qos_qm->class_accel_mngr == IFX_ENABLED)
					&& (atoi(old_AccelMngr) == 1)) {
					
					//add disable classifier rules


				}
				if (qos_qm->enable == IFX_ENABLED) {
					//printf("[%s:%d],qm_enable=%d,class_accel_mngr=%d, old_accel_mngr=%d\n", __FUNCTION__, __LINE__,qos_qm->class_accel_mngr,atoi(old_AccelMngr));
					
					if ((qos_qm->class_accel_mngr == IFX_DISABLED) && (atoi(old_AccelMngr) == IFX_ENABLED)) {
			
						printf("Disable Acceleration ---- Re-init QoS\n");
						//Disable classifier manager
						//delete accel manager chains in prerouting
						//do not allow addition of class rules
						printf("Calling Acceleration Manager - delete classifier chains\n");
						sprintf(sCommand, ". /etc/rc.d/class_acceleration_manager 0");
						system(sCommand);
						
						
						sprintf(sCommand, "%s", IPQOS_DISABLE);
						system(sCommand); 
	
	        	            		sprintf(sCommand, "%s", ". /etc/init.d/ltq_wan_changeover_stop.sh qos");
	                	    		system(sCommand);
	                    
	                    			sprintf(sCommand, "%s", ". /etc/init.d/ltq_wan_changeover_start.sh");
	                    			system(sCommand);  
					}	

				}
				if (qos_qm->enable == IFX_DISABLED){
					//printf("[%s:%d],qm_enable=%d,class_accel_mngr=%d, old_accel_mngr=%d\n", __FUNCTION__, __LINE__,qos_qm->enable,qos_qm->class_accel_mngr,atoi(old_AccelMngr));
					      
					if ((qos_qm->class_accel_mngr == IFX_DISABLED) && (atoi(old_AccelMngr) == 1)) {
						
						//Disable classifier manager
						//delete accel manager chains in prerouting
						//do not allow addition of class rules
						printf("Calling Acceleration Manager - delete classifier chains\n");
						sprintf(sCommand, ". /etc/rc.d/class_acceleration_manager 0");
						system(sCommand);
					}

				}

#endif
			}
		}
	}

	/************** System Config File Update Block ****************/
	/* Convert the name value pair in array_fvp into string format
	   expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_IPQOS_QM, flags, 1, conf_buf);

	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */

	/* If QoS is enabled by webpage or QM object added by tr69
	 * Call ipqos_qos_init script
	 * This script will create IPQOS_LAN_ING and IPQOS_LOCAL_OUT chains in iptables
	 * These chains will by default have rule to skip, that means chains are in disabled state
	 Add 8 queues and filter rules reading rc.conf
	 */

	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) 
	{
		if (IFX_MODIFY_F_SET(flags)) {
			if (IFX_DEACTIVATE_F_NOT_SET(flags)) {
				/* Update Flags  - This is done after rate update. */
				sprintf(sCommand, "queuecfg -u 0/0");
				system(sCommand);

				/* Update Rates */
				sprintf(sCommand, "queuecfg -r 0/0");
				system(sCommand);

				//ORP: Should be compared with oldenable. should be ... && oldenable=0
				if ((qos_qm->enable == IFX_ENABLED)
				    && (atoi(old_enable) == 0)) {
				
				
					if ((qos_qm->class_accel_mngr == IFX_ENABLED)
					&& (atoi(old_AccelMngr) == 1)) {
					
						printf("[%s:%d],QoS Enabled, Acceleration Manager Enabled from enabled state\n",__FUNCTION__,__LINE__);
						printf("[%s:%d],Re-Initialize QoS with classifier accel enabled and removing Disable accel chains....\n",__FUNCTION__,__LINE__);
						sprintf(sCommand, ". /etc/rc.d/class_acceleration_manager 0");
						system(sCommand);
					}
					
					qos_qm->USenable = 1;
					qos_qm->DSenable = 1;
			
               if (atoi(old_tcpackprio) == 1) 
               {
					      sprintf(sCommand, ". /etc/rc.d/ipqos_tcp_ack_prio 2");
					      system(sCommand);
				   }


            	/* Manamohan: PPA module unload and reload */
					sprintf(sCommand, "%s", ". /etc/init.d/ltq_wan_changeover_stop.sh qos");
              	system(sCommand);
                    
              	sprintf(sCommand, "%s", ". /etc/init.d/ltq_wan_changeover_start.sh");
              	system(sCommand);  
               wan_changeover=1;

					sprintf(sCommand, "queuecfg -q 0/0");
					system(sCommand);

					/* US and DS QoS Enabled, modification of parameters */
					/*If QoS enabled and init has already happened, modify q_mgmt default paramt */
					if((qos_qm->USenable == IFX_ENABLED) && (atoi(old_USenable)==1))
					{
						sprintf(sCommand, "%s", IPQOS_MGMT);
						system(sCommand);

						/* Configure Queues */
						sprintf(sCommand, "queuecfg -q 1/0");
						system(sCommand);

					}
					if((qos_qm->DSenable == IFX_ENABLED) && (atoi(old_DSenable) == 1))
					{
						sprintf(sCommand, "%s", IPQOS_MGMT);
                    				system(sCommand);
                    
						/* Configure Queues */
						sprintf(sCommand, "queuecfg -q 2/0");
                    				system(sCommand);  
					}
					if((qos_qm->USenable == IFX_DISABLED) && (atoi(old_USenable)==1))
					{
						sprintf(sCommand, "%s", IPQOS_US_DISABLE);
						system(sCommand); 
					}
					if((qos_qm->DSenable == IFX_DISABLED) && (atoi(old_DSenable)==1))
					{
						sprintf(sCommand, "%s", IPQOS_DS_DISABLE);
						system(sCommand); 
					}

				}
				/*If QoS enabled and init has already happened, modify q_mgmt default paramt */
				if ((qos_qm->enable == IFX_ENABLED)
				    && (atoi(old_enable) == 1)) 
				{
					if(((qos_qm->USenable == IFX_DISABLED) && (atoi(old_USenable)==0)) || ((qos_qm->DSenable == IFX_DISABLED) && (atoi(old_DSenable) == 0)))
					{
						sprintf(sCommand, "%s", IPQOS_MGMT);
						system(sCommand);
						sprintf(sCommand, "queuecfg -q 0/0");
						system(sCommand);
					}

					if((qos_qm->USenable == IFX_ENABLED) && (atoi(old_USenable)==0))
					{
						sprintf(sCommand, "%s", IPQOS_US_INIT);
						system(sCommand);
					}
					if((qos_qm->DSenable == IFX_ENABLED) && (atoi(old_DSenable) == 0))
					{
						sprintf(sCommand, "%s", IPQOS_DS_INIT);
						system(sCommand);
					}
					if((qos_qm->USenable == IFX_DISABLED) && (atoi(old_USenable)==1))
					{
						sprintf(sCommand, "%s 1", IPQOS_Q_DISABLE);
						system(sCommand); 
						sprintf(sCommand, "%s", IPQOS_US_DISABLE);
						system(sCommand); 
					}
					if((qos_qm->DSenable == IFX_DISABLED) && (atoi(old_DSenable)==1))
					{
						sprintf(sCommand, "%s 2", IPQOS_Q_DISABLE);
						system(sCommand); 
						sprintf(sCommand, "%s", IPQOS_DS_DISABLE);
						system(sCommand); 
					}
					/*If QoS enabled and init has already happened, modify q_mgmt default paramt */
					if((qos_qm->USenable == IFX_ENABLED) && (atoi(old_USenable)==1))
					{
						sprintf(sCommand, "%s", IPQOS_MGMT);
						system(sCommand);

						/* Configure Queues */
						sprintf(sCommand, "queuecfg -q 1/0");
						system(sCommand);
					}
					if((qos_qm->DSenable == IFX_ENABLED) && (atoi(old_DSenable) == 1))
					{
						sprintf(sCommand, "%s", IPQOS_MGMT);
						system(sCommand);

						/* Configure Queues */
						sprintf(sCommand, "queuecfg -q 2/0");
						system(sCommand);
					}

					/* Initialize Hardware classifiers */
					sprintf(sCommand, "queuecfg -s 0/0");
					system(sCommand);

				}
				if ((qos_qm->enable == IFX_DISABLED)
				    && (atoi(old_enable) == 1)) 
				{
					qos_qm->USenable = 0;
					qos_qm->DSenable = 0;
					
					if (qos_qm->USenable == IFX_DISABLED){
							sprintf(sCommand, "%s 1", IPQOS_Q_DISABLE);
							system(sCommand); 
							sprintf(sCommand, "%s", IPQOS_US_DISABLE);
							system(sCommand); 
					}
					if (qos_qm->DSenable == IFX_DISABLED){
							sprintf(sCommand, "%s 2", IPQOS_Q_DISABLE);
							system(sCommand); 
							sprintf(sCommand, "%s", IPQOS_DS_DISABLE);
							system(sCommand); 
					}
					
					sprintf(sCommand, "%s", IPQOS_DISABLE);
					system(sCommand); 
						
					sprintf(sCommand, ". /etc/rc.d/ipqos_common 3 0");
					system(sCommand);

                    			sprintf(sCommand, "%s", ". /etc/init.d/ltq_wan_changeover_stop.sh qos");
                    			system(sCommand);
                    
                    			sprintf(sCommand, "%s", ". /etc/init.d/ltq_wan_changeover_start.sh");
                    			system(sCommand);  
                           wan_changeover=1;

				}

				if (qos_qm->enable == IFX_ENABLED) 
				{
					if((qos_qm->P8021enable == IFX_ENABLED) && (atoi(old_P8021enable) == 0))
					{
						sprintf(sCommand, ". /etc/rc.d/ipqos_common 3 1");
						system(sCommand);
						sprintf(sCommand, ". /etc/rc.d/ipqos_common 2 1");
						system(sCommand);
						sprintf(sCommand, ". /etc/rc.d/ipqos_common 2 0");
						system(sCommand);
					}
					if((qos_qm->P8021enable == IFX_DISABLED) && (atoi(old_P8021enable) == 1))
					{
						sprintf(sCommand, ". /etc/rc.d/ipqos_common 3 0");
						system(sCommand);
						sprintf(sCommand, ". /etc/rc.d/ipqos_common 2 1");
						system(sCommand);
					}
					if((qos_qm->P8021enable == IFX_DISABLED) && (atoi(old_P8021enable) == 0))
					{
						sprintf(sCommand, ". /etc/rc.d/ipqos_common 3 0");
						system(sCommand);
						sprintf(sCommand, ". /etc/rc.d/ipqos_common 2 1");
						system(sCommand);
					}
					if((qos_qm->P8021enable == IFX_ENABLED) && (atoi(old_P8021enable) == 1))
					{
						sprintf(sCommand, ". /etc/rc.d/ipqos_common 3 1");
						system(sCommand);
						sprintf(sCommand, ". /etc/rc.d/ipqos_common 2 1");
						system(sCommand);
						sprintf(sCommand, ". /etc/rc.d/ipqos_common 2 0");
						system(sCommand);
					}
				}
				//Classifier acceleration manager
				if (qos_qm->enable == IFX_ENABLED) {

					if ((qos_qm->class_accel_mngr == IFX_ENABLED)
					&& (atoi(old_AccelMngr) == 0)) {
					
						printf("[%s:%d],QoS Enabled, Acceleration Manager Enabled\n",__FUNCTION__,__LINE__);
						printf("[%s:%d],Re-Initialize QoS with classifier accel enabled ....\n",__FUNCTION__,__LINE__);
						//Re-initialize QoS
						sprintf(sCommand, "%s", IPQOS_DISABLE);
						system(sCommand); 

	                    			sprintf(sCommand, "%s", ". /etc/init.d/ltq_wan_changeover_stop.sh qos");
                	    			system(sCommand);
        	            
                    				sprintf(sCommand, "%s", ". /etc/init.d/ltq_wan_changeover_start.sh");
                    				system(sCommand);  
                              wan_changeover=1;
					}
					if ((qos_qm->class_accel_mngr == IFX_DISABLED)
					&& (atoi(old_AccelMngr) == 1)) {
					
						printf("[%s:%d],QoS Enabled, Acceleration Manager DISABLED\n",__FUNCTION__,__LINE__);
						printf("[%s:%d],Re-Initialize QoS with classifier accel disabled ....\n",__FUNCTION__,__LINE__);
						
						//Disable classifier manager
						//delete accel manager chains in prerouting
						//do not allow addition of class rules
						printf("Calling Acceleration Manager - delete classifier chains\n");
						sprintf(sCommand, ". /etc/rc.d/class_acceleration_manager 0");
						system(sCommand);
						
						//Re-initialize QoS
						sprintf(sCommand, "%s", IPQOS_DISABLE);
						system(sCommand); 

	                    			sprintf(sCommand, "%s", ". /etc/init.d/ltq_wan_changeover_stop.sh qos");
                	    			system(sCommand);
        	            
                    				sprintf(sCommand, "%s", ". /etc/init.d/ltq_wan_changeover_start.sh");
                    				system(sCommand); 
                              			wan_changeover=1;
						
                    				//sprintf(sCommand, "%s", ". /etc/init.d/init_ipqos.sh start");
                    				//system(sCommand); 
					}
				}
            /* This section calls TCP ACK Prio script with 0/2 for adding/deleting TCP ACK Prio rules */
				
            if( wan_changeover == 0 )
            {
               if (((qos_qm->tcpackprio == IFX_ENABLED)
					   && (atoi(old_tcpackprio)) == 0)) 
               {
					   sprintf(sCommand,
						   ". /etc/rc.d/ipqos_common 0 0");
					   system(sCommand);
				   }
            }
				if (((qos_qm->tcpackprio == IFX_DISABLED)
					&& (atoi(old_tcpackprio)) == 1)) 
            {
					sprintf(sCommand,
						". /etc/rc.d/ipqos_common 0 2");
					system(sCommand);
				}


				if (qos_qm->enable == IFX_DISABLED) {

					if ((qos_qm->class_accel_mngr == IFX_ENABLED)
					&& (atoi(old_AccelMngr) == 0)) {
					
						//enable classifier manager
						//Call script to enable chains in prerouting
						printf("[%s:%d],QoS DISABLED, Acceleration Manager Enabled\n",__FUNCTION__,__LINE__);
						printf(" Enabling DISABLE ACCEL CHAINS\n");
						sprintf(sCommand, ". /etc/rc.d/class_acceleration_manager 1");
						system(sCommand);
					}
					if ((qos_qm->class_accel_mngr == IFX_ENABLED)
					&& (atoi(old_AccelMngr) == 1)) {
					
						//Re-initialize QoS
						sprintf(sCommand, "%s", IPQOS_DISABLE);
						system(sCommand); 

	                    			sprintf(sCommand, "%s", ". /etc/init.d/ltq_wan_changeover_stop.sh qos");
                	    			system(sCommand);
        	            
                    				sprintf(sCommand, "%s", ". /etc/init.d/ltq_wan_changeover_start.sh");
                    				system(sCommand); 
                              			wan_changeover=1;
						
						//enable classifier manager
						//Call script to enable chains in prerouting
						printf("[%s:%d],QoS DISABLED, Acceleration Manager Enabled\n",__FUNCTION__,__LINE__);
						printf(" Enabling DISABLE ACCEL CHAINS\n");
						sprintf(sCommand, ". /etc/rc.d/class_acceleration_manager 1");
						system(sCommand);
					}
				}
			
				if (qos_qm->enable == IFX_DISABLED){
				      
					//printf("[%s:%d]class_accel_mngr=%d, old_accel_mngr=%d\n", __FUNCTION__, __LINE__,qos_qm->class_accel_mngr,atoi(old_AccelMngr));
					if ((qos_qm->class_accel_mngr == IFX_DISABLED) && (atoi(old_AccelMngr) == 1)) {
					
						//Disable classifier manager
						//delete accel manager chains in prerouting
						//do not allow addition of class rules
						printf("[%s:%d],QoS DISABLED, Acceleration Manager DISABLED\n",__FUNCTION__,__LINE__);
						printf("Calling Acceleration Manager - delete classifier chains\n");
						sprintf(sCommand, ". /etc/rc.d/class_acceleration_manager 0");
						system(sCommand);
					}

				}
				/* end of disable classifier handling */


			}
		}
	}

	/* this will Compact the section and also update the count for both ADD and DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_IPQOS_CLASSIFY, flags);

	 /*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

	 /*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_MODIFY_F_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION(qos_qm->iid, changed_count,
					  array_changed_fvp, flags, IFX_Handler)
	}

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
*	ifx_mapi_set_qos_classifier (uint32 Oper, IFX_MAPI_QoS_Classifier *classify, uint32 flags) 
*		operation	==>   the operation to be performed for this route entry, can be ADD, DELETE or MODIFY
*    	classify	==>   pointer to IFX_MAPI_QoS_Classifier structure that has QoS details
*    	flags		==>   flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
  			This function configures the QoS Classifier paramters. 
*//////////////////////////////////////////////////////////////////////////////
//#ifdef IFX_CONFIG_IPQoS
//#define ORDER_OFF 0
int32 ifx_mapi_set_qos_classifier(uint32 Oper,
				  IFX_MAPI_QoS_Classifier * classify,
				  uint32 flags)
{
	char8 sbuf[MAX_FILELINE_LEN];
	char8 conf_buf[MAX_DATA_LEN];
	int32 count = 0, changed_count = 0, passed_index = -1;
	int32 ret = IFX_SUCCESS, webReorder = 0;
	IFX_NAME_VALUE_PAIR
	    array_fvp[IFX_MAPI_MAX_IPQOS_CLASSIFIER_SECTION_PARAMS + 1];
	IFX_NAME_VALUE_PAIR *array_changed_fvp = NULL;
	uint32 outflag = flags, numInst = 0;
	WAN_PHY_CFG pstWanPhy;
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	ifx_get_wan_phy_cfg(&pstWanPhy);
	char8 sCommand[MAX_FILELINE_LEN];
	char8 old_order[20], new_order[20], web_newOr[20], old_qmenable[20], old_qmAccelMngr[20], qos_enable[20], USenable[20], DSenable[20];
	IFX_MAPI_QoS_Interface_Type qIfType;
	IFX_MAPI_QoS_Interface_Type ActiveIfType;
	IFX_MAPI_QoS_Interface_Type ActivelanIfType;
	char8 sLine[256];

	memset(sLine, 0, sizeof(sLine));

/* Manamohan: 10,July 2011,NULL check as per Klocwork report */
	IFX_VALIDATE_PTR(classify)
	    IFX_API_LOG("[%s:%d] passedorder = %d", __FUNCTION__, __LINE__,
			classify->order);
	memset(array_fvp, 0, sizeof(array_fvp));
	NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));

/* Get Active QoS Interface */
	ActiveIfType = ifx_mapi_get_active_qos_iface();

	//find the ifType of classifier from the  structure passed
	qIfType = classify->classIf;
	IFX_API_LOG("[%s:%d], Classifier IfType = %d", __FUNCTION__, __LINE__,
		    qIfType);
	ActivelanIfType = ActiveIfType;	
	switch(ActiveIfType)
	{
		case IFX_MAPI_QoS_WAN_ATM:
			ActivelanIfType = IFX_MAPI_QoS_LAN_ATM;
		break;
		case IFX_MAPI_QoS_WAN_PTM:
			ActivelanIfType = IFX_MAPI_QoS_LAN_PTM;
		break;
		case IFX_MAPI_QoS_WAN_ETH_0:
			ActivelanIfType = IFX_MAPI_QoS_LAN_ETH_0;
		break;
		case IFX_MAPI_QoS_WAN_ETH_1:
			ActivelanIfType = IFX_MAPI_QoS_LAN_ETH_1;
		break;
		default:
		break;
	}
	
/*************** Prolog Block *********************/
/* Based on operation (ADD or DELETE or MODIFY)
 * append the flag with internal flags */
	if (Oper == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (Oper == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

/**************** Validation Block *****************/
/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
/* Do simple validation of pointer such as NULL */

/* Manamohan: 10,June 2011, commented as it is moved up before deferencing */
/*    IFX_VALIDATE_PTR(classify) */

/* Do simple validation of flags sucha as less than 0 */
		IFX_VALIDATE_FLAGS(flags)
	}

	/* Set the parent SectioddnName and parent IID values
	 * to QM object
	 */
	sprintf(classify->iid.cpeId.secName, "%s", TAG_IPQOS_CLASSIFY);
	sprintf(classify->iid.pcpeId.secName, "%s", TAG_IPQOS_QM);
	classify->iid.pcpeId.Id = 1;

	/* Setting order = 0 if not MFC */
	if (classify->mfClass != IFX_MAPI_QoS_Multi_Field)
		classify->order = 0;

    /**************** ID Allocation Block - Only for ADD Operation **************/

	/* Allocate the IID for this classifier instance */
	if (IFX_ADD_F_SET(flags)) {
		if (ifx_get_IID(&classify->iid, "qId") != IFX_SUCCESS) {
			IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	 /**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given structure for ADD/MODIFY
	 * Operations
	 */
	/* Set the Classifier name if owner is tr69 */
	if ((classify->iid.config_owner == IFX_TR69) && (Oper == IFX_OP_ADD)) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
		sprintf(classify->classifierName, "tr69_class_%d",
			classify->iid.cpeId.Id);
	}

/* ordering while adding from web*/
	if ((classify->iid.config_owner == IFX_WEB) && (IFX_ADD_F_SET(flags))) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
		
		switch(classify->classIf)
		{
			case IFX_MAPI_QoS_LAN_ALL:
				numInst = ifx_mapi_get_classifier_mfc_count_for_wan_mode(ActiveIfType);
			break;
			case IFX_MAPI_QoS_ALL:
				numInst = ifx_mapi_get_classifier_mfc_count_for_wan_mode(ActiveIfType);
			break;
			case IFX_MAPI_QoS_LOCAL:
				numInst = ifx_mapi_get_classifier_mfc_count_for_wan_mode(ActiveIfType);
			break;
			case IFX_MAPI_QoS_WAN:
				numInst = ifx_mapi_get_classifier_mfc_count_for_wan_mode(ActivelanIfType);
			break;
			case IFX_MAPI_QoS_WAN_ALL:
				numInst = ifx_mapi_get_classifier_mfc_count_for_wan_mode(ActivelanIfType);
			break;
			default:
			break;
		}

		IFX_API_LOG("[%s:%d] Total numberof classifier numInst=%d",
			    __FUNCTION__, __LINE__, numInst);

		IFX_API_LOG("[%s:%d] order=%d", __FUNCTION__, __LINE__,
			    classify->order);
		if ((classify->order <= numInst)
		    && (classify->mfClass == IFX_MAPI_QoS_Multi_Field)) {
			sprintf(web_newOr, "%u", classify->order);
			IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);

			classify->order = numInst + 1;
			webReorder = 1;
		}

	}

	IFX_API_LOG("[%s:%d] New order=%d, web_reorder = %d", __FUNCTION__,
		    __LINE__, classify->order, webReorder);
	count = 0;

	if (IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, 0,
					IFX_MAPI_MAX_IPQOS_CLASSIFIER_SECTION_PARAMS,
					ipqos_classify_params);
		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 20,
					    (int *)&classify->iid.cpeId.Id,
					    &classify->iid.pcpeId.Id,
					    &classify->trafficClassId,
					    &classify->qId,
					    &classify->policerId,
					    &classify->mfClass,
					    &classify->classIf,
					    &classify->IngIf,
					    &classify->protoNum,
					    &classify->L3protoNum,
					    &classify->srcPortRange.start_port,
					    &classify->srcPortRange.end_port,
					    &classify->dstPortRange.start_port,
					    &classify->dstPortRange.end_port,
					    &classify->dscpCheck,
					    &classify->dscpMark,
					    &classify->pBitsCheck,
					    &classify->pBitsMark,
					    &classify->vlanCheck,
					    &classify->rateLmt);

		ifx_fill_ArrayFvp_uintValues(array_fvp, 20, 2,
					     &classify->order,
					     &classify->fwPolicy);

		ifx_fill_ArrayFvp_boolValues(array_fvp, 22, 13,
					     &classify->enable,
					     &classify->srcIPExcl,
					     &classify->dstIPExcl,
					     &classify->protoExcl,
					     &classify->L3protoExcl,
					     &classify->srcPortExcl,
					     &classify->dstPortExcl,
					     &classify->srcMacExcl,
					     &classify->dstMacExcl,
					     &classify->dscpExcl,
					     &classify->pBitsExcl,
					     &classify->vlanExcl,
					     &classify->rateCtrlEnbl);

			ifx_fill_ArrayFvp_strValues(array_fvp, 35, 11,
						    classify->classifierName,
						    classify->specIf,
						    classify->srcIP.ip,
						    classify->srcIP.mask,
						    classify->dstIP.ip,
						    classify->dstIP.mask,
						    classify->srcMac,
						    classify->srcMacMask,
						    classify->dstMac,
						    classify->dstMacMask,
						    classify->specIf);
		ifx_fill_ArrayFvp_boolValues(array_fvp, 46, 1,
					     &classify->disableAccel);
		passed_index = -1;
	}
	count = IFX_MAPI_MAX_IPQOS_CLASSIFIER_SECTION_PARAMS;

/* Get Config Index in case of modify/delete operations from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF,
					 classify->iid.cpeId, passed_index)
	}

	/* Get the order of classifier instance from RC.CONF for MODIFY and DELETE */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		sprintf(sbuf, "%s_%d_order", PREFIX_IPQOS_CLASSIFY,
			passed_index);

		//This is the order as in RC.CONF
		if ((ifx_GetObjData
		     (FILE_RC_CONF, TAG_IPQOS_CLASSIFY, sbuf, IFX_F_GET_ANY,
		      &outflag, old_order)) != IFX_SUCCESS) {
			IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		IFX_API_LOG("[%s:%d]old_order=%s ", __FUNCTION__, __LINE__,
			    old_order);
	}

/* Determine the configuration index - for Add, Delete, Modify operations
 * Name is partial since index is not known
 * Fill array_fvp[] */
	if (ifx_get_conf_index_and_nv_pairs(&classify->iid, passed_index,
					    PREFIX_IPQOS_CLASSIFY, count,
					    array_fvp, flags) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	if (IFX_ADD_F_NOT_SET(flags)) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
		CHECK_ACL_RET(classify->iid, count, array_fvp,
			      changed_count, array_changed_fvp, flags,
			      IFX_Handler)
	}
	//This is the enable  as in RC.CONF
	if ((ifx_GetObjData
	     (FILE_RC_CONF, TAG_IPQOS_QM, "qm_enable", IFX_F_GET_ANY, &outflag,
	      old_qmenable)) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	if ((ifx_GetObjData
	     (FILE_RC_CONF, TAG_IPQOS_QM, "qm_USenable", IFX_F_GET_ANY, &outflag,
	      USenable)) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	if ((ifx_GetObjData
	     (FILE_RC_CONF, TAG_IPQOS_QM, "qm_DSenable", IFX_F_GET_ANY, &outflag,
	      DSenable)) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	if ((ifx_GetObjData
	     (FILE_RC_CONF, TAG_IPQOS_QM, "qm_AccelMngr", IFX_F_GET_ANY, &outflag,
	      old_qmAccelMngr)) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}



	/*In case of modify operation, first update system configuration and then
	 * update the RC.CONF.This is required since if any parameter is changed
	 * new parameters can be obtained from struct, and old values from RC.CONF
	 * After changing system conf, update with rc.conf configuration
	 */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    (IFX_DELETE_F_SET(flags) || IFX_MODIFY_F_SET(flags))) {
		
		/* Handling for Classifier excluded from acceleration */
		//This section is not required  to check for qos_enable 
		
		//if (atoi(old_qmenable) == 0) {
		if (atoi(old_qmAccelMngr) == 1) {
				
				/*In case of Modify or Delete
				 * call script to delete rule to disable 13th bit in NF mark */
				
				//printf("[%s:%d],class_del: passed_index=%d\n",
				//	__FUNCTION__, __LINE__,passed_index);

				//sprintf(sCommand, "%s %d",CLASS_ACCEL_DELETE,
				sprintf(sCommand, "%s %d",US_CLASS_ACCEL_DELETE,
					passed_index);
				IFX_API_LOG("[%s:%d],class_del: passed_index=%d, ",
					__FUNCTION__, __LINE__,passed_index);
				system(sCommand);
		}		
		//}
		//end of disable accel handling
		
		if (atoi(old_qmenable) == 1) {
			/* If ClassIf is LAN/LOCAL and classifier is enabled */
			if ((classify->enable == IFX_ENABLED) && 
					((classify->classIf == IFX_MAPI_QoS_LAN_ALL) || 
					 (classify->classIf == IFX_MAPI_QoS_ALL) || 
					 (classify->classIf == IFX_MAPI_QoS_LOCAL))) {

				if (IFX_DELETE_F_SET(flags)) {
					/*Delete classification entry  */

					sprintf(sCommand, "%s %d",
						IPQOS_US_CLASSIFY_DELETE,
						passed_index);
					IFX_API_LOG
					    ("[%s:%d],US class_del: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);

				}
				/* Compare the order in RC.CONF with order from struct,
				 * If order is not equal to old_order call delete chain script
				 * and then add new chain with new parameters in the modify section after RC.CONF is updated
				 * add a skip entry in the place of old order.  
				 * If order == old_order, replace the exixting chain with newly
				 * formed chain
				 */

				if (IFX_MODIFY_F_SET(flags)) {
					/* replace the chain with corresponding order with new chain */
					/* Dont do anything here, new rule will be created in device config section
					 */

					sprintf(sCommand, "%s %d",
						IPQOS_US_CLASSIFY_DELETE,
						passed_index);
					IFX_API_LOG
					    ("[%s:%d],US class_del: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);
				}

			} 
			if ((classify->enable == IFX_DISABLED) && 
					((classify->classIf == IFX_MAPI_QoS_LAN_ALL) || 
					 (classify->classIf == IFX_MAPI_QoS_ALL) || 
					 (classify->classIf == IFX_MAPI_QoS_LOCAL))) {
		       
				if (IFX_DELETE_F_SET(flags)) {
					/* add skip rule classification chain  */

					sprintf(sCommand, "%s %d",
						IPQOS_US_CLASSIFY_DELETE,
						passed_index);
					IFX_API_LOG
					    ("[%s:%d],US class_del: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);

				}

				if (IFX_MODIFY_F_SET(flags)) {

					/* delete here and add updated entry after rc.conf update */
					sprintf(sCommand, "%s %d",
						IPQOS_US_CLASSIFY_DELETE,
						passed_index);
					IFX_API_LOG
					    ("[%s:%d],US class_del: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);

				}
			}
			/* If ClassIf is WAN and classifier is enabled */
			if ((classify->enable == IFX_ENABLED) && 
					((classify->classIf == IFX_MAPI_QoS_WAN_ALL) ||
					(classify->classIf == IFX_MAPI_QoS_WAN)))
			{
				if (IFX_DELETE_F_SET(flags)) {
					/*Delete classification entry  */

					sprintf(sCommand, "%s %d",
						IPQOS_DS_CLASSIFY_DELETE,
						passed_index);
					IFX_API_LOG
					    ("[%s:%d],DS class_del: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);

				}
				/* Compare the order in RC.CONF with order from struct,
				 * If order is not equal to old_order call delete chain script
				 * and then add new chain with new parameters in the modify section after RC.CONF is updated
				 * add a skip entry in the place of old order.  
				 * If order == old_order, replace the exixting chain with newly
				 * formed chain
				 */

				if (IFX_MODIFY_F_SET(flags)) {
					/* replace the chain with corresponding order with new chain */
					/* Dont do anything here, new rule will be created in device config section
					 */

					sprintf(sCommand, "%s %d",
						IPQOS_DS_CLASSIFY_DELETE,
						passed_index);
					IFX_API_LOG
					    ("[%s:%d],DS class_del: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);
				}

			} 
			if ((classify->enable == IFX_DISABLED) && 
					((classify->classIf == IFX_MAPI_QoS_WAN_ALL) ||
					(classify->classIf == IFX_MAPI_QoS_WAN))){
		       
				if (IFX_DELETE_F_SET(flags)) {
					/* add skip rule classification chain  */

					sprintf(sCommand, "%s %d",
						IPQOS_DS_CLASSIFY_DELETE,
						passed_index);
					IFX_API_LOG
					    ("[%s:%d],DS class_del: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);

				}

				if (IFX_MODIFY_F_SET(flags)) {

					/* delete here and add updated entry after rc.conf update */
					sprintf(sCommand, "%s %d",
						IPQOS_DS_CLASSIFY_DELETE,
						passed_index);
					IFX_API_LOG
					    ("[%s:%d],DS class_del: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);

				}
			}
		}		/*atoi(old_qmenable) == 1) */
	}
//============================================================================
/* Get the active interface */
/* Call ordering API to reorder rc.conf entries based on new order */
	if (IFX_MODIFY_F_SET(flags)) {

		sprintf(new_order, "%d", classify->order);
		if ((atoi(new_order)) && (atoi(old_order)))	//MFC -> MFC
		{
			IFX_API_LOG("[%s:%d],old_order=%s ", __FUNCTION__,
				    __LINE__, old_order);
			if (ifx_modify_n_reorder_fvp_queue
			    (TAG_IPQOS_CLASSIFY, PREFIX_IPQOS_CLASSIFY, "order",
			     old_order, new_order, IFX_F_MODIFY,
			     qIfType) != IFX_SUCCESS) {
				IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);

#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;

				goto IFX_Handler;
			}
		} else		//MFC -> DSCP/802.1P or DSCP/802.1p -> MFC or DSCP/802.1p to 802.1p/DSCP 
		{
			IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
			if ((!atoi(new_order)) && (atoi(old_order)))	// MFC -> DSCP/802.1p
			{
				IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
				if (ifx_modify_n_reorder_fvp_queue
				    (TAG_IPQOS_CLASSIFY, PREFIX_IPQOS_CLASSIFY,
				     "order", old_order, new_order,
				     IFX_F_DELETE, qIfType) != IFX_SUCCESS) {
					IFX_API_LOG("[%s:%d] ", __FUNCTION__,
						    __LINE__);

#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d]", __FUNCTION__,
						__LINE__);
#endif
					ret = IFX_FAILURE;

					goto IFX_Handler;
				}
			} else	//DSCP/802.1p -> MFC or DSCP/802.1p to 802.1p/DSCP 
			{
				IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
				if ((!atoi(old_order)) && (atoi(new_order)))	//DSCP/802.1p -> MFC 
				{
					IFX_API_LOG("[%s:%d] ", __FUNCTION__,
						    __LINE__);

					if (ifx_modify_n_reorder_fvp_queue
					    (TAG_IPQOS_CLASSIFY,
					     PREFIX_IPQOS_CLASSIFY, "order",
					     old_order, new_order,
					     IFX_F_INT_ADD,
					     qIfType) != IFX_SUCCESS) {
						IFX_API_LOG("[%s:%d] ",
							    __FUNCTION__,
							    __LINE__);

#ifdef IFX_LOG_DEBUG
						IFX_DBG("[%s:%d]", __FUNCTION__,
							__LINE__);
#endif
						ret = IFX_FAILURE;

						goto IFX_Handler;
					}
					//Actual newvalue will be written below during setval
				} else	//DSCP/802.1p to 802.1p/DSCP 
				{
					IFX_API_LOG("[%s:%d] ", __FUNCTION__,
						    __LINE__);
					//Nothing to be done
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d]", __FUNCTION__,
						__LINE__);
#endif
				}

			}
		}
	}
/************** System Config File Update Block ****************/
/* Convert the name value pair in array_fvp into string format
   expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);

/* RC.CONF Configuration block */
	ret =
	    ifx_SetObjData(FILE_RC_CONF, TAG_IPQOS_CLASSIFY, flags, 1,
			   conf_buf);

	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

/*call ordering for delete */

	if (IFX_DELETE_F_SET(flags)) {

		if (classify->mfClass == IFX_MAPI_QoS_Multi_Field) {
			IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
			if (ifx_modify_n_reorder_fvp_queue
			    (TAG_IPQOS_CLASSIFY, PREFIX_IPQOS_CLASSIFY, "order",
			     old_order, 0, IFX_F_DELETE,
			     qIfType) != IFX_SUCCESS) {
				IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
				IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);

#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;

				goto IFX_Handler;
			}

		}
	}
/* ordering while adding from web*/
	if ((classify->iid.config_owner == IFX_WEB) && (IFX_ADD_F_SET(flags))) {

		if (webReorder) {
			sprintf(sbuf, "%d", numInst + 1);
			IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
			if (ifx_modify_n_reorder_fvp_queue
			    (TAG_IPQOS_CLASSIFY, PREFIX_IPQOS_CLASSIFY, "order",
			     sbuf, web_newOr, IFX_F_INT_ADD,
			     qIfType) != IFX_SUCCESS) {
				IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
				IFX_DBG("[%s:%d]count=%d", __FUNCTION__,
					__LINE__, atoi(sbuf));

#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;

				goto IFX_Handler;
			}
		}

		IFX_API_LOG("[%s:%d],web_new_order=%s ", __FUNCTION__,
			    __LINE__, web_newOr);
		sprintf(new_order, "%s", web_newOr);
/* The instance number of the added entry will always be equal to the Count of the number of entries before adding the entry, since Compaction is done later. This passed_index is very much required by the ipqos_class_add script */
	}

/* get index from cpeid for add operation */
	if (IFX_ADD_F_SET(flags)) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, classify->iid.cpeId,
					 passed_index)
		    IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);

	}

/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* System call to Add/Delete/Modify Route */

	//Get qm_enable status from rc.conf
	if ((ifx_GetObjData
	     (FILE_RC_CONF, TAG_IPQOS_QM, "qm_enable", IFX_F_GET_ANY, &outflag,
	      qos_enable)) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
		if (IFX_DELETE_F_NOT_SET(flags) &&
		    (IFX_DEACTIVATE_F_NOT_SET(flags))) {

			if ((atoi(qos_enable) == 0 ) && (atoi(old_qmAccelMngr) == 0)){
			/* Handling for Classifier excluded from acceleration */
			//QoS Enable =0 Disable accel =1
			
				if (classify->disableAccel == IFX_ENABLED) {
				
				//	printf("[%s:%d],Shashi call US CLASS_ACCEL_ADD script \n ",__FUNCTION__, __LINE__);
					/*call script to add rule to enable 13th bit in NF mark */
				
					//sprintf(sCommand, "%s %d %d",CLASS_ACCEL_ADD,
					sprintf(sCommand, "%s %d %d",US_CLASS_ACCEL_ADD,
						passed_index, 0);
					IFX_API_LOG("[%s:%d],class_accel_add: passed_index=%d, ",
						__FUNCTION__, __LINE__,passed_index);
					system(sCommand);
				}
			}

			if ((atoi(qos_enable) == 0 ) && (atoi(old_qmAccelMngr) == 1)){
			/* Handling for Classifier excluded from acceleration */
			//This sec is outside QoS Enable check
			
				if (classify->disableAccel == IFX_ENABLED) {
				
					//printf("[%s:%d],Shashi call US CLASS_ACCEL_ADD script \n ",__FUNCTION__, __LINE__);
					/*call script to add rule to enable 13th bit in NF mark */
				
					//sprintf(sCommand, "%s %d %d",CLASS_ACCEL_ADD,
					sprintf(sCommand, "%s %d %d",US_CLASS_ACCEL_ADD,
						passed_index, 0);
					IFX_API_LOG("[%s:%d],class_accel_add: passed_index=%d, ",
						__FUNCTION__, __LINE__,passed_index);
					system(sCommand);
				}
			}



			if (atoi(old_qmenable) == 1) {
				
				//If QoS is enabled and Class acceleration Disable feature is enabled,
				//Disable chains outside QoS and use QoS chains and rules to mark traffic
				if (classify->disableAccel == IFX_ENABLED) {
				
					printf("[%s:%d],Accel disable call CLASS_ACCEL_DELETE script \n ",__FUNCTION__, __LINE__);
					/*call script to add rule to enable 13th bit in NF mark */
				
					//sprintf(sCommand, "%s %d %d",CLASS_ACCEL_DELETE,
					sprintf(sCommand, "%s %d %d",US_CLASS_ACCEL_DELETE,
						passed_index, 0);
					IFX_API_LOG("[%s:%d],class_accel_del: passed_index=%d, ",
						__FUNCTION__, __LINE__,passed_index);
					system(sCommand);
				}

				if ((classify->enable == IFX_ENABLED) &&
					((classify->classIf == IFX_MAPI_QoS_LAN_ALL) || 
					 (classify->classIf == IFX_MAPI_QoS_ALL) || 
					 (classify->classIf == IFX_MAPI_QoS_LOCAL))) {

					IFX_API_LOG("[%s:%d] ", __FUNCTION__,
						    __LINE__);
					/*Call script to add iptable rules for classifier
					 *ipqos_classify_add script reads from the rc.conf directly, finds
					 *what fields are updated in the ipqos_classify section and frames
					 *iptable rules before adding them on the system
					 */
					sprintf(sCommand, "%s %d %d",
						IPQOS_US_CLASSIFY_ADD,
						passed_index, 0);
					IFX_API_LOG
					    ("[%s:%d],US class_add: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);

				} 
				if ((classify->enable == IFX_DISABLED) &&
					((classify->classIf == IFX_MAPI_QoS_LAN_ALL) || 
					 (classify->classIf == IFX_MAPI_QoS_ALL) || 
					 (classify->classIf == IFX_MAPI_QoS_LOCAL))) {

					IFX_API_LOG("[%s:%d] ", __FUNCTION__,
						    __LINE__);
					/* enable ==0   */

					sprintf(sCommand, "%s %d %d",
						IPQOS_US_CLASSIFY_ADD,
						passed_index, 0);
					IFX_API_LOG
					    ("[%s:%d],US class_add: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);

				}
				if ((classify->enable == IFX_ENABLED) &&
					 //(classify->classIf == IFX_MAPI_QoS_WAN_ALL))
					((classify->classIf == IFX_MAPI_QoS_WAN_ALL) ||
					(classify->classIf == IFX_MAPI_QoS_WAN))){

					IFX_API_LOG("[%s:%d] ", __FUNCTION__,
						    __LINE__);
					/*Call script to add iptable rules for classifier
					 *ipqos_classify_add script reads from the rc.conf directly, finds
					 *what fields are updated in the ipqos_classify section and frames
					 *iptable rules before adding them on the system
					 */
					sprintf(sCommand, "%s %d %d",
						IPQOS_DS_CLASSIFY_ADD,
						passed_index, 0);
					IFX_API_LOG
					    ("[%s:%d],DS class_add: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);

				} 
				if ((classify->enable == IFX_DISABLED) &&
					 //(classify->classIf == IFX_MAPI_QoS_WAN_ALL))
					((classify->classIf == IFX_MAPI_QoS_WAN_ALL) ||
					(classify->classIf == IFX_MAPI_QoS_WAN))){

					IFX_API_LOG("[%s:%d] ", __FUNCTION__,
						    __LINE__);
					/* enable ==0   */

					sprintf(sCommand, "%s %d %d",
						IPQOS_DS_CLASSIFY_ADD,
						passed_index, 0);
					IFX_API_LOG
					    ("[%s:%d],DS class_add: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);

				}

			}	/* atoi(old_qmenable) == 1) */
		}
	}
	/* this will Compact the section and also update the count for both ADD and DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_IPQOS_CLASSIFY, flags);
	IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);

	 /*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

	 /*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_MODIFY_F_SET(flags)) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
		CHECK_N_SEND_NOTIFICATION(classify->iid, changed_count,
					  array_changed_fvp, flags, IFX_Handler)
	} else if (IFX_INT_ADD_F_SET(flags)) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);

		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */
		/*********** Epilog Block **************/
		UPDATE_ID_MAP_N_ATTRIBUTES(&classify->iid, count,
					   array_fvp, flags, IFX_Handler)

		    CHECK_N_SEND_NOTIFICATION(classify->iid, count,
					      array_fvp, flags, IFX_Handler)

		    /* Manipulate nextCpeId only for ADD operations */
		    ifx_increment_next_cpeId(FILE_RC_CONF, TAG_IPQOS_CLASSIFY);

	} else if (IFX_DELETE_F_SET(flags)) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);

		/* In case of DELETE operation,first send the notification update of the 
		 * IDMappings and then send the Notification for the attributes                                                                                                                    */

    /************ EpilogBlock * **************/
		CHECK_N_SEND_NOTIFICATION(classify->iid, count,
					  array_fvp, flags, IFX_Handler)
		    UPDATE_ID_MAP_N_ATTRIBUTES(&classify->iid, count,
					       array_fvp, flags, IFX_Handler)
	}
	// Retrieve the Older Rate Enable Value
	int old_class_rate_limit_enb = 0;
	memset(sLine, 0, sizeof(sLine));
	ifx_GetObjData("/tmp/system_status", "qos_bk", "class_rate_limit_enb",
		       IFX_F_GET_ENA, 0, sLine);
	old_class_rate_limit_enb = atoi(sLine);

	/* Update Flags  - This is done independant of whether qos is enabled or not. */
	sprintf(sCommand, "queuecfg -u 0/0");
	system(sCommand);

	/* Update Rates  - This is done independant of whether qos is enabled or not. */
	sprintf(sCommand, "queuecfg -r 0/0");
	system(sCommand);

#if 1
	if (atoi(old_qmenable) == 1) {

		/* Initialize Hardware classifiers */
		if(webReorder)
      {
         sprintf(sCommand, "queuecfg -s 0/0");
		   system(sCommand);
      }

		/* Configure Queues */
		if((classify->classIf == IFX_MAPI_QoS_LAN_ALL) || (classify->classIf == IFX_MAPI_QoS_ALL) || (classify->classIf == IFX_MAPI_QoS_LOCAL))
		{
			sprintf(sCommand, "queuecfg -q 1/0");
			/* system(sCommand); Moved inside classifier based rate limiting below */
		}
		if((classify->classIf == IFX_MAPI_QoS_WAN_ALL) || (classify->classIf == IFX_MAPI_QoS_WAN))
		{
			sprintf(sCommand, "queuecfg -q 2/0");
			/* system(sCommand);Moved inside classifier based rate limiting below */
		}
		// If software QOS Don't require Restart QOS Mechanism
		/*  Start of QOS Rate Limiting Changes */
		int queue_method = -1;
		char sLine[256];

		memset(sLine, 0, sizeof(sLine));
		ifx_GetObjData(FILE_SYSTEM_STATUS, "qos_bk", "queue_method",
			       IFX_F_GET_ENA, 0, sLine);
		queue_method = atoi(sLine);

		IFX_DBG("%s:Selected Queue Method: %d", __func__, queue_method);
		IFX_DBG
		    ("\n%s: Old Class Rate Enb: %d, New Class Rate Enb: %d\n",
		     __func__, old_class_rate_limit_enb,
		     classify->rateCtrlEnbl);

		/* If Queuing Mechanism is not Software or Previously any class was attached to
		 stream based rate shaping and currently no class is attached with stream based 
		 rate limiting, then configure the queues.*/
		/* if (queue_method != 1
		    || (old_class_rate_limit_enb == 1
			&& classify->rateCtrlEnbl == 0))  */
		if (( (old_class_rate_limit_enb == 1) && (classify->rateCtrlEnbl == 0)) || ((old_class_rate_limit_enb == 0) && (classify->rateCtrlEnbl == 1) )) 
      			{

			IFX_DBG
			    ("\n%s:Going To configure Queues Qmethod:%d old_class_rate_limit_enb: %d cur_class_rate_limit_enb: %d\n",
			     __func__, queue_method, old_class_rate_limit_enb,
			     classify->rateCtrlEnbl);
			system(sCommand);

			}
		/* End of QOS Rate Limiting Changes */
		}
#endif

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
*	ifx_mapi_set_qos_ds_classifier (uint32 Oper, IFX_MAPI_QoS_Classifier *classify, uint32 flags) 
*		operation	==>   the operation to be performed for this route entry, can be ADD, DELETE or MODIFY
*    	classify	==>   pointer to IFX_MAPI_QoS_Classifier structure that has QoS details
*    	flags		==>   flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
  			This function configures the Downstream QoS Classifier paramters. 
*//////////////////////////////////////////////////////////////////////////////
//#ifdef IFX_CONFIG_IPQoS
//#define ORDER_OFF 0
int32 ifx_mapi_set_qos_ds_classifier(uint32 Oper,
				  IFX_MAPI_QoS_Classifier * classify,
				  uint32 flags)
{
	char8 sbuf[MAX_FILELINE_LEN];
	char8 conf_buf[MAX_DATA_LEN];
	int32 count = 0, passed_index = -1;
#if 0
	int32 changed_count = 0;
#endif
	int32 ret = IFX_SUCCESS, webReorder = 0;
	IFX_NAME_VALUE_PAIR
	    array_fvp[IFX_MAPI_MAX_IPQOS_CLASSIFIER_SECTION_PARAMS + 1];
	IFX_NAME_VALUE_PAIR *array_changed_fvp = NULL;
	uint32 outflag = flags, numInst = 0;
	WAN_PHY_CFG pstWanPhy;
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	ifx_get_wan_phy_cfg(&pstWanPhy);
	char8 sCommand[MAX_FILELINE_LEN];
	char8 old_order[20], new_order[20], web_newOr[20], old_qmenable[20];
	char8 USenable[20], DSenable[20], old_qmAccelMngr[20], qos_enable[20];
	IFX_MAPI_QoS_Interface_Type qIfType;
	IFX_MAPI_QoS_Interface_Type ActiveIfType;
	IFX_MAPI_QoS_Interface_Type ActivelanIfType;
	char8 sLine[256];

	memset(sLine, 0, sizeof(sLine));

	IFX_VALIDATE_PTR(classify)
	    IFX_API_LOG("[%s:%d] passedorder = %d", __FUNCTION__, __LINE__,
			classify->order);
	memset(array_fvp, 0, sizeof(array_fvp));
	NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));

/* Get Active QoS Interface */
	ActiveIfType = ifx_mapi_get_active_qos_iface();

	//find the ifType of classifier from the  structure passed
	qIfType = classify->classIf;
	IFX_API_LOG("[%s:%d], Classifier IfType = %d", __FUNCTION__, __LINE__,
		    qIfType);
	ActivelanIfType = ActiveIfType;	
	switch(ActiveIfType)
	{
		case IFX_MAPI_QoS_WAN_ATM:
			ActivelanIfType = IFX_MAPI_QoS_LAN_ATM;
		break;
		case IFX_MAPI_QoS_WAN_PTM:
			ActivelanIfType = IFX_MAPI_QoS_LAN_PTM;
		break;
		case IFX_MAPI_QoS_WAN_ETH_0:
			ActivelanIfType = IFX_MAPI_QoS_LAN_ETH_0;
		break;
		case IFX_MAPI_QoS_WAN_ETH_1:
			ActivelanIfType = IFX_MAPI_QoS_LAN_ETH_1;
		break;
		default:
		break;
	}

/*************** Prolog Block *********************/
/* Based on operation (ADD or DELETE or MODIFY)
 * append the flag with internal flags */
	if (Oper == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (Oper == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

/**************** Validation Block *****************/
/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
/* Do simple validation of pointer such as NULL */

/* Do simple validation of flags sucha as less than 0 */
		IFX_VALIDATE_FLAGS(flags)
	}

	/* Set the parent SectioddnName and parent IID values
	 * to QM object
	 */
	sprintf(classify->iid.cpeId.secName, "%s", TAG_IPQOS_DS_CLASSIFY);
	sprintf(classify->iid.pcpeId.secName, "%s", TAG_IPQOS_QM);
	classify->iid.pcpeId.Id = 1;

	/* Setting order = 0 if not MFC */
	if (classify->mfClass != IFX_MAPI_QoS_Multi_Field)
		classify->order = 0;

    /**************** ID Allocation Block - Only for ADD Operation **************/

	/* Allocate the IID for this classifier instance */
	if (IFX_ADD_F_SET(flags)) {
		if (ifx_get_IID_Without_TR69(&classify->iid, "qId") != IFX_SUCCESS) {
			IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	 /**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given structure for ADD/MODIFY
	 * Operations
	 */
	/* Set the Classifier name if owner is tr69 */
	if ((classify->iid.config_owner == IFX_TR69) && (Oper == IFX_OP_ADD)) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
		sprintf(classify->classifierName, "tr69_class_%d",
			classify->iid.cpeId.Id);
	}

/* ordering while adding from web*/
	if ((classify->iid.config_owner == IFX_WEB) && (IFX_ADD_F_SET(flags))) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
		
		switch(classify->classIf)
		{
			case IFX_MAPI_QoS_LAN_ALL:
				numInst = ifx_mapi_get_ds_classifier_mfc_count_for_wan_mode(ActiveIfType);
			break;
			case IFX_MAPI_QoS_ALL:
				numInst = ifx_mapi_get_ds_classifier_mfc_count_for_wan_mode(ActiveIfType);
			break;
			case IFX_MAPI_QoS_LOCAL:
				numInst = ifx_mapi_get_ds_classifier_mfc_count_for_wan_mode(ActiveIfType);
			break;
			case IFX_MAPI_QoS_WAN:
				numInst = ifx_mapi_get_ds_classifier_mfc_count_for_wan_mode(ActivelanIfType);
			break;
			case IFX_MAPI_QoS_WAN_ALL:
				numInst = ifx_mapi_get_ds_classifier_mfc_count_for_wan_mode(ActivelanIfType);
			break;
			default:
			break;
		}

		IFX_API_LOG("[%s:%d] Total numberof classifier numInst=%d",
			    __FUNCTION__, __LINE__, numInst);

		IFX_API_LOG("[%s:%d] order=%d", __FUNCTION__, __LINE__,
			    classify->order);
		if ((classify->order <= numInst)
		    && (classify->mfClass == IFX_MAPI_QoS_Multi_Field)) {
			sprintf(web_newOr, "%u", classify->order);
			IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);

			classify->order = numInst + 1;
			webReorder = 1;
		}

	}

	IFX_API_LOG("[%s:%d] New order=%d, web_reorder = %d", __FUNCTION__,
		    __LINE__, classify->order, webReorder);
	count = 0;

	if (IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, 0,
					IFX_MAPI_MAX_IPQOS_CLASSIFIER_SECTION_PARAMS,
					ipqos_ds_classify_params);
		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 20,
					    (int *)&classify->iid.cpeId.Id,
					    &classify->iid.pcpeId.Id,
					    &classify->trafficClassId,
					    &classify->qId,
					    &classify->policerId,
					    &classify->mfClass,
					    &classify->classIf,
					    &classify->IngIf,
					    &classify->protoNum,
					    &classify->L3protoNum,
					    &classify->srcPortRange.start_port,
					    &classify->srcPortRange.end_port,
					    &classify->dstPortRange.start_port,
					    &classify->dstPortRange.end_port,
					    &classify->dscpCheck,
					    &classify->dscpMark,
					    &classify->pBitsCheck,
					    &classify->pBitsMark,
					    &classify->vlanCheck,
					    &classify->rateLmt);

		ifx_fill_ArrayFvp_uintValues(array_fvp, 20, 2,
					     &classify->order,
					     &classify->fwPolicy);

		ifx_fill_ArrayFvp_boolValues(array_fvp, 22, 13,
					     &classify->enable,
					     &classify->srcIPExcl,
					     &classify->dstIPExcl,
					     &classify->protoExcl,
					     &classify->L3protoExcl,
					     &classify->srcPortExcl,
					     &classify->dstPortExcl,
					     &classify->srcMacExcl,
					     &classify->dstMacExcl,
					     &classify->dscpExcl,
					     &classify->pBitsExcl,
					     &classify->vlanExcl,
					     &classify->rateCtrlEnbl);
		{

			ifx_fill_ArrayFvp_strValues(array_fvp, 35, 11,
						    classify->classifierName,
						    classify->specIf,
#if 0
						    srcIP,
						    srcIPMask, dstIP, dstIPMask,
#else
						    classify->srcIP.ip,
						    classify->srcIP.mask,
						    classify->dstIP.ip,
						    classify->dstIP.mask,
#endif
						    classify->srcMac,
						    classify->srcMacMask,
						    classify->dstMac,
						    classify->dstMacMask,
						    classify->specIf);
		ifx_fill_ArrayFvp_boolValues(array_fvp, 46, 1,
					     &classify->disableAccel);
		}
		passed_index = -1;
	}
	count = IFX_MAPI_MAX_IPQOS_CLASSIFIER_SECTION_PARAMS;

/* Get Config Index in case of modify/delete operations from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF,
					 classify->iid.cpeId, passed_index)
	}

	/* Get the order of classifier instance from RC.CONF for MODIFY and DELETE */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		sprintf(sbuf, "%s_%d_order", PREFIX_IPQOS_DS_CLASSIFY,
			passed_index);

		//This is the order as in RC.CONF
		if ((ifx_GetObjData
		     (FILE_RC_CONF, TAG_IPQOS_DS_CLASSIFY, sbuf, IFX_F_GET_ANY,
		      &outflag, old_order)) != IFX_SUCCESS) {
			IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		IFX_API_LOG("[%s:%d]old_order=%s ", __FUNCTION__, __LINE__,
			    old_order);
	}

/* Determine the configuration index - for Add, Delete, Modify operations
 * Name is partial since index is not known
 * Fill array_fvp[] */
	if (ifx_get_conf_index_and_nv_pairs(&classify->iid, passed_index,
					    PREFIX_IPQOS_DS_CLASSIFY, count,
					    array_fvp, flags) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}


/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
/*	if (IFX_ADD_F_NOT_SET(flags)) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
		CHECK_ACL_RET(classify->iid, count, array_fvp,
			      changed_count, array_changed_fvp, flags,
			      IFX_Handler)
	}*/
	//This is the enable  as in RC.CONF
	if ((ifx_GetObjData
	     (FILE_RC_CONF, TAG_IPQOS_QM, "qm_enable", IFX_F_GET_ANY, &outflag,
	      old_qmenable)) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	if ((ifx_GetObjData
	     (FILE_RC_CONF, TAG_IPQOS_QM, "qm_USenable", IFX_F_GET_ANY, &outflag,
	      USenable)) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	if ((ifx_GetObjData
	     (FILE_RC_CONF, TAG_IPQOS_QM, "qm_DSenable", IFX_F_GET_ANY, &outflag,
	      DSenable)) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	
	if ((ifx_GetObjData
	     (FILE_RC_CONF, TAG_IPQOS_QM, "qm_AccelMngr", IFX_F_GET_ANY, &outflag,
	      old_qmAccelMngr)) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}



	/*In case of modify operation, first update system configuration and then
	 * update the RC.CONF.This is required since if any parameter is changed
	 * new parameters can be obtained from struct, and old values from RC.CONF
	 * After changing system conf, update with rc.conf configuration
	 */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    (IFX_DELETE_F_SET(flags) || IFX_MODIFY_F_SET(flags))) {
		
		/* Handling for Classifier excluded from acceleration */
		//This section is not required  to check for qos_enable 
		
		//if (atoi(old_qmenable) == 0) {
		if (atoi(old_qmAccelMngr) == 1) {
				
				/*In case of Modify or Delete
				 * call script to delete rule to disable 13th bit in NF mark */
				
				printf("[%s:%d],class_del: passed_index=%d\n",
					__FUNCTION__, __LINE__,passed_index);

				//sprintf(sCommand, "%s %d",CLASS_ACCEL_DELETE,
				sprintf(sCommand, "%s %d",DS_CLASS_ACCEL_DELETE,
					passed_index);
				IFX_API_LOG("[%s:%d],class_del: passed_index=%d, ",
					__FUNCTION__, __LINE__,passed_index);
				system(sCommand);
		}		
		//}
		//end of disable accel handling
	
		if (atoi(old_qmenable) == 1) {
			/* If ClassIf is LAN/LOCAL and classifier is enabled */
			if ((classify->enable == IFX_ENABLED) && 
					((classify->classIf == IFX_MAPI_QoS_LAN_ALL) || 
					 (classify->classIf == IFX_MAPI_QoS_ALL) || 
					 (classify->classIf == IFX_MAPI_QoS_LOCAL))) {

				if (IFX_DELETE_F_SET(flags)) {
					/*Delete classification entry  */

					sprintf(sCommand, "%s %d",
						IPQOS_US_CLASSIFY_DELETE,
						passed_index);
					IFX_API_LOG
					    ("[%s:%d],US class_del: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);

				}
				/* Compare the order in RC.CONF with order from struct,
				 * If order is not equal to old_order call delete chain script
				 * and then add new chain with new parameters in the modify section after RC.CONF is updated
				 * add a skip entry in the place of old order.  
				 * If order == old_order, replace the exixting chain with newly
				 * formed chain
				 */

				if (IFX_MODIFY_F_SET(flags)) {
					/* replace the chain with corresponding order with new chain */
					/* Dont do anything here, new rule will be created in device config section
					 */

					sprintf(sCommand, "%s %d",
						IPQOS_US_CLASSIFY_DELETE,
						passed_index);
					IFX_API_LOG
					    ("[%s:%d],US class_del: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);
				}

			} 
			if ((classify->enable == IFX_DISABLED) && 
					((classify->classIf == IFX_MAPI_QoS_LAN_ALL) || 
					 (classify->classIf == IFX_MAPI_QoS_ALL) || 
					 (classify->classIf == IFX_MAPI_QoS_LOCAL))) {
		       
				/*enable ==0  */

				if (IFX_DELETE_F_SET(flags)) {
					/* add skip rule classification chain  */

					sprintf(sCommand, "%s %d",
						IPQOS_US_CLASSIFY_DELETE,
						passed_index);
					IFX_API_LOG
					    ("[%s:%d],US class_del: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);

				}

				if (IFX_MODIFY_F_SET(flags)) {

					/* delete here and add updated entry after rc.conf update */
					sprintf(sCommand, "%s %d",
						IPQOS_US_CLASSIFY_DELETE,
						passed_index);
					IFX_API_LOG
					    ("[%s:%d],US class_del: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);

				}
			}
			/* If ClassIf is WAN and classifier is enabled */
			if ((classify->enable == IFX_ENABLED) && 
					((classify->classIf == IFX_MAPI_QoS_WAN_ALL) ||
					(classify->classIf == IFX_MAPI_QoS_WAN)))
			{
				if (IFX_DELETE_F_SET(flags)) {
					/*Delete classification entry  */

					sprintf(sCommand, "%s %d",
						IPQOS_DS_CLASSIFY_DELETE,
						passed_index);
					IFX_API_LOG
					    ("[%s:%d],DS class_del: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);

				}
				/* Compare the order in RC.CONF with order from struct,
				 * If order is not equal to old_order call delete chain script
				 * and then add new chain with new parameters in the modify section after RC.CONF is updated
				 * add a skip entry in the place of old order.  
				 * If order == old_order, replace the exixting chain with newly
				 * formed chain
				 */

				if (IFX_MODIFY_F_SET(flags)) {
					/* replace the chain with corresponding order with new chain */
					/* Dont do anything here, new rule will be created in device config section
					 */

					sprintf(sCommand, "%s %d",
						IPQOS_DS_CLASSIFY_DELETE,
						passed_index);
					IFX_API_LOG
					    ("[%s:%d],DS class_del: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);
				}

			} 
			if ((classify->enable == IFX_DISABLED) && 
					((classify->classIf == IFX_MAPI_QoS_WAN_ALL) ||
					(classify->classIf == IFX_MAPI_QoS_WAN))){
		       
				if (IFX_DELETE_F_SET(flags)) {
					/* add skip rule classification chain  */

					sprintf(sCommand, "%s %d",
						IPQOS_DS_CLASSIFY_DELETE,
						passed_index);
					IFX_API_LOG
					    ("[%s:%d],DS class_del: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);

				}

				if (IFX_MODIFY_F_SET(flags)) {

					/* delete here and add updated entry after rc.conf update */
					sprintf(sCommand, "%s %d",
						IPQOS_DS_CLASSIFY_DELETE,
						passed_index);
					IFX_API_LOG
					    ("[%s:%d],DS class_del: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);

				}
			}
		}		/*atoi(old_qmenable) == 1) */
	}
	
//============================================================================
/* Get the active interface */
/* Call ordering API to reorder rc.conf entries based on new order */
	if (IFX_MODIFY_F_SET(flags)) {

		sprintf(new_order, "%d", classify->order);
		if ((atoi(new_order)) && (atoi(old_order)))	//MFC -> MFC
		{
			IFX_API_LOG("[%s:%d],old_order=%s ", __FUNCTION__,
				    __LINE__, old_order);
			if (ifx_modify_n_reorder_fvp_queue
			    (TAG_IPQOS_DS_CLASSIFY, PREFIX_IPQOS_DS_CLASSIFY, "order",
			     old_order, new_order, IFX_F_MODIFY,
			     qIfType) != IFX_SUCCESS) {
				IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);

#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;

				goto IFX_Handler;
			}
		} else		//MFC -> DSCP/802.1P or DSCP/802.1p -> MFC or DSCP/802.1p to 802.1p/DSCP 
		{
			IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
			if ((!atoi(new_order)) && (atoi(old_order)))	// MFC -> DSCP/802.1p
			{
				IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
				if (ifx_modify_n_reorder_fvp_queue
				    (TAG_IPQOS_DS_CLASSIFY, PREFIX_IPQOS_DS_CLASSIFY,
				     "order", old_order, new_order,
				     IFX_F_DELETE, qIfType) != IFX_SUCCESS) {
					IFX_API_LOG("[%s:%d] ", __FUNCTION__,
						    __LINE__);

#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d]", __FUNCTION__,
						__LINE__);
#endif
					ret = IFX_FAILURE;

					goto IFX_Handler;
				}
			} else	//DSCP/802.1p -> MFC or DSCP/802.1p to 802.1p/DSCP 
			{
				IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
				if ((!atoi(old_order)) && (atoi(new_order)))	//DSCP/802.1p -> MFC 
				{
					IFX_API_LOG("[%s:%d] ", __FUNCTION__,
						    __LINE__);

					if (ifx_modify_n_reorder_fvp_queue
					    (TAG_IPQOS_DS_CLASSIFY,
					     PREFIX_IPQOS_DS_CLASSIFY, "order",
					     old_order, new_order,
					     IFX_F_INT_ADD,
					     qIfType) != IFX_SUCCESS) {
						IFX_API_LOG("[%s:%d] ",
							    __FUNCTION__,
							    __LINE__);

#ifdef IFX_LOG_DEBUG
						IFX_DBG("[%s:%d]", __FUNCTION__,
							__LINE__);
#endif
						ret = IFX_FAILURE;

						goto IFX_Handler;
					}
					//Actual newvalue will be written below during setval
				} else	//DSCP/802.1p to 802.1p/DSCP 
				{
					IFX_API_LOG("[%s:%d] ", __FUNCTION__,
						    __LINE__);
					//Nothing to be done
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d]", __FUNCTION__,
						__LINE__);
#endif
				}

			}
		}
	}

/************** System Config File Update Block ****************/
/* Convert the name value pair in array_fvp into string format
   expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);

/* RC.CONF Configuration block */
	ret =
	    ifx_SetObjData(FILE_RC_CONF, TAG_IPQOS_DS_CLASSIFY, flags, 1,
			   conf_buf);

	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

/*call ordering for delete */

	if (IFX_DELETE_F_SET(flags)) {

		if (classify->mfClass == IFX_MAPI_QoS_Multi_Field) {
			IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
			if (ifx_modify_n_reorder_fvp_queue
			    (TAG_IPQOS_DS_CLASSIFY, PREFIX_IPQOS_DS_CLASSIFY, "order",
			     old_order, 0, IFX_F_DELETE,
			     qIfType) != IFX_SUCCESS) {
				IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
				IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);

#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;

				goto IFX_Handler;
			}

		}
	}
/* ordering while adding from web*/
	if ((classify->iid.config_owner == IFX_WEB) && (IFX_ADD_F_SET(flags))) {

		if (webReorder) {
			sprintf(sbuf, "%d", numInst + 1);
			IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
			if (ifx_modify_n_reorder_fvp_queue
			    (TAG_IPQOS_DS_CLASSIFY, PREFIX_IPQOS_DS_CLASSIFY, "order",
			     sbuf, web_newOr, IFX_F_INT_ADD,
			     qIfType) != IFX_SUCCESS) {
				IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
				IFX_DBG("[%s:%d]count=%d", __FUNCTION__,
					__LINE__, atoi(sbuf));

#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;

				goto IFX_Handler;
			}
		}

		IFX_API_LOG("[%s:%d],web_new_order=%s ", __FUNCTION__,
			    __LINE__, web_newOr);
		sprintf(new_order, "%s", web_newOr);
/* The instance number of the added entry will always be equal to the Count of the number of entries before adding the entry, since Compaction is done later. This passed_index is very much required by the ipqos_class_add script */
	}

/* get index from cpeid for add operation */
	if (IFX_ADD_F_SET(flags)) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, classify->iid.cpeId,
					 passed_index)
		    IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);

	}

/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* System call to Add/Delete/Modify Route */
	
	//Get qm_enable status from rc.conf
	if ((ifx_GetObjData
	     (FILE_RC_CONF, TAG_IPQOS_QM, "qm_enable", IFX_F_GET_ANY, &outflag,
	      qos_enable)) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
		if (IFX_DELETE_F_NOT_SET(flags) &&
		    (IFX_DEACTIVATE_F_NOT_SET(flags))) {
			
			if ((atoi(qos_enable) == 0 ) && (atoi(old_qmAccelMngr) == 0)){
			/* Handling for Classifier excluded from acceleration */
			//QoS Enable =0 Disable accel =1
			
				if (classify->disableAccel == IFX_ENABLED) {
				
					printf("[%s:%d],Class Accel Disable DS CLASS_ACCEL_ADD script \n ",__FUNCTION__, __LINE__);
					/*call script to add rule to enable 13th bit in NF mark */
				
					//sprintf(sCommand, "%s %d %d",CLASS_ACCEL_ADD,
					sprintf(sCommand, "%s %d %d",DS_CLASS_ACCEL_ADD,
						passed_index, 0);
					IFX_API_LOG("[%s:%d],class_accel_add: passed_index=%d, ",
						__FUNCTION__, __LINE__,passed_index);
					system(sCommand);
				}
			}

			if ((atoi(qos_enable) == 0 ) && (atoi(old_qmAccelMngr) == 1)){
			/* Handling for Classifier excluded from acceleration */
			//This sec is outside QoS Enable check
			
				if (classify->disableAccel == IFX_ENABLED) {
				
					printf("[%s:%d],Class Accel Disable call DS CLASS_ACCEL_ADD script \n ",__FUNCTION__, __LINE__);
					/*call script to add rule to enable 13th bit in NF mark */
				
					//sprintf(sCommand, "%s %d %d",CLASS_ACCEL_ADD,
					sprintf(sCommand, "%s %d %d",DS_CLASS_ACCEL_ADD,
						passed_index, 0);
					IFX_API_LOG("[%s:%d],class_accel_add: passed_index=%d, ",
						__FUNCTION__, __LINE__,passed_index);
					system(sCommand);
				}
			}
			
			if (atoi(old_qmenable) == 1) {

				//If QoS is enabled and Class acceleration Disable feature is enabled,
				//Disable chains outside QoS and use QoS chains and rules to mark traffic
				if (classify->disableAccel == IFX_ENABLED) {
				
					printf("[%s:%d],Class Accel Disable call CLASS_ACCEL_DELETE script \n ",__FUNCTION__, __LINE__);
					/*call script to add rule to enable 13th bit in NF mark */
				
					//sprintf(sCommand, "%s %d %d",CLASS_ACCEL_DELETE,
					sprintf(sCommand, "%s %d %d",DS_CLASS_ACCEL_DELETE,
						passed_index, 0);
					IFX_API_LOG("[%s:%d],class_accel_del: passed_index=%d, ",
						__FUNCTION__, __LINE__,passed_index);
					system(sCommand);
				}

				if ((classify->enable == IFX_ENABLED) &&
					((classify->classIf == IFX_MAPI_QoS_LAN_ALL) || 
					 (classify->classIf == IFX_MAPI_QoS_ALL) || 
					 (classify->classIf == IFX_MAPI_QoS_LOCAL))) {

					IFX_API_LOG("[%s:%d] ", __FUNCTION__,
						    __LINE__);
					/*Call script to add iptable rules for classifier
					 *ipqos_classify_add script reads from the rc.conf directly, finds
					 *what fields are updated in the ipqos_classify section and frames
					 *iptable rules before adding them on the system
					 */
					sprintf(sCommand, "%s %d %d",
						IPQOS_US_CLASSIFY_ADD,
						passed_index, 0);
					IFX_API_LOG
					    ("[%s:%d],US class_add: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);

				} 
				if ((classify->enable == IFX_DISABLED) &&
					((classify->classIf == IFX_MAPI_QoS_LAN_ALL) || 
					 (classify->classIf == IFX_MAPI_QoS_ALL) || 
					 (classify->classIf == IFX_MAPI_QoS_LOCAL))) {

					IFX_API_LOG("[%s:%d] ", __FUNCTION__,
						    __LINE__);

					sprintf(sCommand, "%s %d %d",
						IPQOS_US_CLASSIFY_ADD,
						passed_index, 0);
					IFX_API_LOG
					    ("[%s:%d],US class_add: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);

				}
				if ((classify->enable == IFX_ENABLED) &&
					((classify->classIf == IFX_MAPI_QoS_WAN_ALL) ||
					(classify->classIf == IFX_MAPI_QoS_WAN))){

					IFX_API_LOG("[%s:%d] ", __FUNCTION__,
						    __LINE__);
					/*Call script to add iptable rules for classifier
					 *ipqos_classify_add script reads from the rc.conf directly, finds
					 *what fields are updated in the ipqos_classify section and frames
					 *iptable rules before adding them on the system
					 */
					sprintf(sCommand, "%s %d %d",
						IPQOS_DS_CLASSIFY_ADD,
						passed_index, 0);
					IFX_API_LOG
					    ("[%s:%d],DS class_add: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);

				} 
				if ((classify->enable == IFX_DISABLED) &&
					((classify->classIf == IFX_MAPI_QoS_WAN_ALL) ||
					(classify->classIf == IFX_MAPI_QoS_WAN))){

					IFX_API_LOG("[%s:%d] ", __FUNCTION__,
						    __LINE__);
					/* enable ==0   */

					sprintf(sCommand, "%s %d %d",
						IPQOS_DS_CLASSIFY_ADD,
						passed_index, 0);
					IFX_API_LOG
					    ("[%s:%d],DS class_add: passed_index=%d, ",
					     __FUNCTION__, __LINE__,
					     passed_index);
					system(sCommand);

				}

			}	/* atoi(old_qmenable) == 1) */
		}
	}
	/* this will Compact the section and also update the count for both ADD and DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_IPQOS_DS_CLASSIFY, flags);
	IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);

	 /*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

	 /*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_MODIFY_F_SET(flags)) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#if 0
		CHECK_N_SEND_NOTIFICATION(classify->iid, changed_count,
					  array_changed_fvp, flags, IFX_Handler)
#endif
	} else if (IFX_INT_ADD_F_SET(flags)) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);

		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */
		/*********** Epilog Block **************/
#if 0
		UPDATE_ID_MAP_N_ATTRIBUTES(&classify->iid, count,
					   array_fvp, flags, IFX_Handler)

		    CHECK_N_SEND_NOTIFICATION(classify->iid, count,
					      array_fvp, flags, IFX_Handler)
#endif

		    /* Manipulate nextCpeId only for ADD operations */
		    ifx_increment_next_cpeId(FILE_RC_CONF, TAG_IPQOS_DS_CLASSIFY);

	} else if (IFX_DELETE_F_SET(flags)) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);

		/* In case of DELETE operation,first send the notification update of the 
		 * IDMappings and then send the Notification for the attributes                                                                                                                    */

    /************ EpilogBlock * **************/
	/*	CHECK_N_SEND_NOTIFICATION(classify->iid, count,
					  array_fvp, flags, IFX_Handler)
		    UPDATE_ID_MAP_N_ATTRIBUTES(&classify->iid, count,
					       array_fvp, flags, IFX_Handler)*/
	}
	// Retrieve the Older Rate Enable Value
	int old_class_rate_limit_enb = 0;
	memset(sLine, 0, sizeof(sLine));
	ifx_GetObjData("/tmp/system_status", "qos_bk", "class_rate_limit_enb",
		       IFX_F_GET_ENA, 0, sLine);
	old_class_rate_limit_enb = atoi(sLine);

	/* Update Flags  - This is done independant of whether qos is enabled or not. */
	sprintf(sCommand, "queuecfg -u 0/0");
	system(sCommand);

	/* Update Rates  - This is done independant of whether qos is enabled or not. */
	sprintf(sCommand, "queuecfg -r 0/0");
	system(sCommand);

#if 1
	if (atoi(old_qmenable) == 1) {

		/* Initialize Hardware classifiers */
		sprintf(sCommand, "queuecfg -s 0/0");
		system(sCommand);

		/* Configure Queues */
		if((classify->classIf == IFX_MAPI_QoS_LAN_ALL) || (classify->classIf == IFX_MAPI_QoS_ALL) || (classify->classIf == IFX_MAPI_QoS_LOCAL))
		{
			sprintf(sCommand, "queuecfg -q 1/0");
			/* system(sCommand); */
		}
		if((classify->classIf == IFX_MAPI_QoS_WAN_ALL) || (classify->classIf == IFX_MAPI_QoS_WAN))
		{
			sprintf(sCommand, "queuecfg -q 2/0");
			/* system(sCommand); */
		}
		// If software QOS Don't require Restart QOS Mechanism
		/*  Start of QOS Rate Limiting Changes */
		int queue_method = -1;
		char sLine[256];

		memset(sLine, 0, sizeof(sLine));
		ifx_GetObjData(FILE_SYSTEM_STATUS, "qos_bk", "queue_method",
			       IFX_F_GET_ENA, 0, sLine);
		queue_method = atoi(sLine);

		IFX_DBG("%s:Selected Queue Method: %d", __func__, queue_method);
		IFX_DBG
		    ("\n%s: Old Class Rate Enb: %d, New Class Rate Enb: %d\n",
		     __func__, old_class_rate_limit_enb,
		     classify->rateCtrlEnbl);

		// If Queuing Mechanism is not Software or Previously any class was attached to
		// stream based rate shaping and currently no class is attached with stream based 
		// rate limiting, then configure the queues.
		/* if (queue_method != 1
		    || (old_class_rate_limit_enb == 1
			&& classify->rateCtrlEnbl == 0))  */
		if (( (old_class_rate_limit_enb == 1) && (classify->rateCtrlEnbl == 0)) || ((old_class_rate_limit_enb == 0) && (classify->rateCtrlEnbl == 1) )) 
      			{

			IFX_DBG
			    ("\n%s:Going To configure Queues Qmethod:%d old_class_rate_limit_enb: %d cur_class_rate_limit_enb: %d\n",
			     __func__, queue_method, old_class_rate_limit_enb,
			     classify->rateCtrlEnbl);
			system(sCommand);

			}
		/* End of QOS Rate Limiting Changes */
		}
#endif

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
*   ifx_mapi_set_qos_queue_stats (uint32 Oper,
     IFX_MAPI_QoS_QueueStats *qos_queuestats, uint32 flags)
*   operation   ==>   the operation to be performed,
*     can be ADD, DELETE or MODIFY
*   queue    ==>   pointer to IFX_MAPI_QoS_QueueStats structure that has
*     QoS Queue Management statistics details
*   flags       ==>   flags that define the behaviour
*
*   Return Value :   IFX_SUCCESS or IFX_FAILURE
    Description:
      This function configures the QoS Queue Statistics paramters.
*//////////////////////////////////////////////////////////////////////////////

int32 ifx_mapi_set_qos_queue_stats(uint32 Oper, IFX_MAPI_QoS_QueueStats * qos_queuestats, uint32 flags)
{
	char8 conf_buf[MAX_DATA_LEN];
	int count = 0, passed_index = -1;
#if 0
	int changed_count = 0;
#endif
	int ret = IFX_SUCCESS;
	uint32 outflag = flags;
	IFX_NAME_VALUE_PAIR array_fvp[IFX_MAPI_MAX_IPQOS_QUEUESTATS_SECTION_PARAMS +
				      1];
	IFX_NAME_VALUE_PAIR *array_changed_fvp = NULL;
	char8 qmUSenable[20];
	/* IFX_MAPI_QoS_Interface_Type qIfType; */

	memset(array_fvp, 0, sizeof(array_fvp));
	NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));
	IFX_API_LOG("[%s:%d] !", __FUNCTION__, __LINE__);
	//qIfType = ifx_mapi_get_active_qos_iface();

	/*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY)
	 * append the flag with internal flags */
	
	if (Oper == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (Oper == IFX_OP_ADD) 
	{
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} 
	else
		flags |= IFX_F_MODIFY;

	/**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) 
	{ 
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(qos_queuestats) 
		/* Do simple validation of flags sucha as less than 0 */
		IFX_VALIDATE_FLAGS(flags)
	}
	
	/* Set the parent SectioddnName and parent IID values
	 * to QM object
	 */

	sprintf(qos_queuestats->iid.cpeId.secName, "%s", TAG_IPQOS_QUEUESTATS);
	sprintf(qos_queuestats->iid.pcpeId.secName, "%s", TAG_IPQOS_QM);
	qos_queuestats->iid.pcpeId.Id = 1;
 	
	/**************** ID Allocation Block - Only for ADD Operation **************/

	if (IFX_ADD_F_SET(flags)) 
	{
	/* Allocate the IID for this QueueStats instance */
		if (ifx_get_IID(&qos_queuestats->iid, "interface") != IFX_SUCCESS) 
		{
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}
	
	count = 0;
	

	if (IFX_DELETE_F_NOT_SET(flags)) 
	{
		ifx_fill_ArrayFvp_FName(array_fvp, 0,
					IFX_MAPI_MAX_IPQOS_QUEUESTATS_SECTION_PARAMS,
					ipqos_queuestats_params);
		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 3,
						(int *)&qos_queuestats->iid.cpeId.Id,
						&qos_queuestats->iid.pcpeId.Id,
						&qos_queuestats->Interface);
		ifx_fill_ArrayFvp_uintValues(array_fvp, 3, 7,
						&qos_queuestats->QueueInst,
						&qos_queuestats->OutPacks,
						&qos_queuestats->OutBytes,
						&qos_queuestats->DropPacks,
						&qos_queuestats->DropBytes,
						&qos_queuestats->QOccPacks,
						&qos_queuestats->QOccPercent);
		ifx_fill_ArrayFvp_boolValues(array_fvp, 10, 1,
						&qos_queuestats->Enable);
		ifx_fill_ArrayFvp_strValues(array_fvp, 11, 1,
						(char *)&qos_queuestats->Status);
	passed_index = -1;
	
	}
	count = IFX_MAPI_MAX_IPQOS_QUEUESTATS_SECTION_PARAMS;

	
	/* Get Config Index in case of modify/delete operations from CPEID */
	
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) 
	{
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, qos_queuestats->iid.cpeId,
					 passed_index)
	}
	
	/* Determine the configuration index - for Add, Delete, Modify operations
	 * Name is partial since index is not known
	 * Fill array_fvp[] */
	
	if (ifx_get_conf_index_and_nv_pairs(&qos_queuestats->iid, passed_index,
					    PREFIX_IPQOS_QUEUESTATS, count,
					    array_fvp, flags) != IFX_SUCCESS) 
	{
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	//This is the enable  as in RC.CONF
	if ((ifx_GetObjData
	     (FILE_RC_CONF, TAG_IPQOS_QM, "qm_USenable", IFX_F_GET_ANY, &outflag,
	      qmUSenable)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    (IFX_DELETE_F_SET(flags) || IFX_MODIFY_F_SET(flags))) 
	{
		
		/*Place holder to do something before configuration */
	}

	/************** System Config File Update Block ****************/
	/* Convert the name value pair in array_fvp into string format
	   expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);
	
	/* RC.CONF Configuration block */
	
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_IPQOS_QUEUESTATS, flags, 1, conf_buf);
	
	if (ret != IFX_SUCCESS) 
	{
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	
	if (IFX_ADD_F_SET(flags)) 
	{
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, qos_queuestats->iid.cpeId,
					 passed_index)

		IFX_DBG("[%s:%d] passed_index=%d", __FUNCTION__, __LINE__, passed_index);
	}
	
	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* System call to Add/Delete/Modify Route */

	/* Read the RC.CONF and call scripts  to add ip table rules 
	 */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) 
	{
		if (IFX_DELETE_F_NOT_SET(flags) &&
		    (IFX_DEACTIVATE_F_NOT_SET(flags))) 
		{

			/* Place holder to do something after configuration */
		}
	}
	
	if (IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_IPQOS_QUEUESTATS, flags);
	
       	/*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	
	if (IFX_MODIFY_F_SET(flags)) 
	{
#if 0
		CHECK_N_SEND_NOTIFICATION(qos_queuestats->iid, changed_count,
					  array_changed_fvp, flags, IFX_Handler)
#endif
		printf("\n");
	} 
	else if (IFX_INT_ADD_F_SET(flags)) 
	{

		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */
		/*********** Epilog Block **************/
		UPDATE_ID_MAP_N_ATTRIBUTES(&qos_queuestats->iid, count,
					   array_fvp, flags, IFX_Handler)

		CHECK_N_SEND_NOTIFICATION(qos_queuestats->iid, count,
					      array_fvp, flags, IFX_Handler)

		    /* Manipulate nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_IPQOS_QUEUESTATS);
		    
	} 
	else if (IFX_DELETE_F_SET(flags)) 
	{
		/* In case of DELETE operation,first send the notification update of the 
		 * IDMappings and then send the Notification for the attributes                                                                                                                    */

   		 /************ EpilogBlock * **************/
		CHECK_N_SEND_NOTIFICATION(qos_queuestats->iid, count,
					  array_fvp, flags, IFX_Handler)
		UPDATE_ID_MAP_N_ATTRIBUTES(&qos_queuestats->iid, count,
					       array_fvp, flags, IFX_Handler)
		printf("\n");
	}

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	
	if (ret != IFX_SUCCESS) 
	{
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	
      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp);
	if (ret != IFX_SUCCESS) 
	{
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
	return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_get_qos_queue_stats(...)
*       *queue    ==>  outut pointer to the structre IFX_MAPI_QOS_QueueStats
*   	flags       ==>
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
*        Description:
*	    This function reads the IPQoS QueueStats configuration  entries from rc.conf 
*		and returns a pointer to the struct IFX_MAPI_QoS_QueueStats.
*//////////////////////////////////////////////////////////////////////////

int32 ifx_mapi_get_qos_queue_stats(IFX_MAPI_QoS_QueueStats * qos_queuestats, uint32 flags)
{
	char8 sBuf[MAX_FILELINE_LEN], *sValue = NULL;
	int32 passed_index = -1, count = 0;
	int ret = IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR array_fvp[IFX_MAPI_MAX_IPQOS_QUEUESTATS_SECTION_PARAMS +
				      1];

	/* Fill the section tag */
	sprintf(qos_queuestats->iid.cpeId.secName, "%s", TAG_IPQOS_QUEUESTATS);

	/* get index from cpeid */
#ifdef IFX_LOG_DEBUG
	IFX_API_LOG("[%s:%d] cpeid=%d!", __FUNCTION__, __LINE__,
		    qos_queuestats->iid.cpeId.Id);
#endif
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, qos_queuestats->iid.cpeId,
				 passed_index)
	    sprintf(sBuf, "%s_%d_", PREFIX_IPQOS_QUEUESTATS, passed_index);
	if ((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_IPQOS_QUEUESTATS,
				    sBuf, flags, &sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	memset(array_fvp, 0x00, sizeof(array_fvp));

	form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);

	/* copy the queue entries into the structure */
	ifx_fill_intValues_ArrayFvp(array_fvp, 0, 3,
					(int *)&qos_queuestats->iid.cpeId.Id,
					&qos_queuestats->iid.pcpeId.Id,
					&qos_queuestats->Interface);
	ifx_fill_uintValues_ArrayFvp(array_fvp, 3, 7,
					&qos_queuestats->QueueInst,
					&qos_queuestats->OutPacks,
					&qos_queuestats->OutBytes,
					&qos_queuestats->DropPacks,
					&qos_queuestats->DropBytes,
					&qos_queuestats->QOccPacks,
					&qos_queuestats->QOccPercent);
	ifx_fill_boolValues_ArrayFvp(array_fvp, 10, 1,
					&qos_queuestats->Enable);
	ifx_fill_strValues_ArrayFvp(array_fvp, 11, 1,
					(char *)&qos_queuestats->Status);

      IFX_Handler:
	IFX_MEM_FREE(sValue)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;

}


/*//////////////////////////////////////////////////////////////////////////////
*   ifx_mapi_set_qos_queue (uint32 Oper,
     IFX_MAPI_QoS_Queue *qos_queue, uint32 flags)
*   operation   ==>   the operation to be performed,
*     can be ADD, DELETE or MODIFY
*   queue    ==>   pointer to IFX_MAPI_QoS_queue structure that has
*     QoS Queue Management details
*   flags       ==>   flags that define the behaviour
*
*   Return Value :   IFX_SUCCESS or IFX_FAILURE
    Description:
      This function configures the QoS Queue Management paramters.
*//////////////////////////////////////////////////////////////////////////////

int32 ifx_mapi_set_qos_queue(uint32 Oper, IFX_MAPI_QoS_Queue * qos_queue,
			     uint32 flags)
{
	char8 sbuf[MAX_FILELINE_LEN];
	char8 conf_buf[MAX_DATA_LEN];
	int count = 0, changed_count = 0, passed_index = -1;
	int ret = IFX_SUCCESS, retval = IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR array_fvp[IFX_MAPI_MAX_IPQOS_QUEUE_SECTION_PARAMS +
				      1];
	IFX_NAME_VALUE_PAIR *array_changed_fvp = NULL;
	uint32 outflag = flags, redth;
	/* IFX_MAPI_QoS_Interface_Type qIfType; */
	int q_flag;
	float redp;
	char8 sCommand[MAX_FILELINE_LEN];
	uint32 sensibleRedTh, sensibleRedPct;
	char8 old_enable[20],old_tcpackprio[20];
	char8 qmenable[20];
	char8 sLine[256];
	int QOS_MODE=0;
	//char8 vcc[20];


	memset(array_fvp, 0, sizeof(array_fvp));
	NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));
	IFX_API_LOG("[%s:%d] !", __FUNCTION__, __LINE__);

	//qIfType = ifx_mapi_get_active_qos_iface();
/*************** Prolog Block *********************/
/* Based on operation (ADD or DELETE or MODIFY)
 * append the flag with internal flags */
	if (Oper == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (Oper == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

/**************** Validation Block *****************/
/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(qos_queue)
/* Do simple validation of flags sucha as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

	/* Set the parent SectioddnName and parent IID values
	 * to QM object
	 */
	sprintf(qos_queue->iid.cpeId.secName, "%s", TAG_IPQOS_QUEUE);
	sprintf(qos_queue->iid.pcpeId.secName, "%s", TAG_IPQOS_QM);
	qos_queue->iid.pcpeId.Id = 1;

/**************** ID Allocation Block - Only for ADD Operation **************/

	if (IFX_ADD_F_SET(flags)) {
		/* Allocate the IID for this classifier instance */
		if (ifx_get_IID(&qos_queue->iid, "qPrio") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

    
    	if((!gstrcmp(qos_queue->qIf,"LAN")) && (qos_queue->iid.cpeId.Id < 20) && ( qos_queue->iid.cpeId.Id != 13) && ( qos_queue->iid.cpeId.Id != 14 ) && ( qos_queue->iid.cpeId.Id != 15) && ( qos_queue->iid.cpeId.Id != 16) )
	{
		qos_queue->iid.cpeId.Id+=10;
	}

	/* Set the peak rate if it is not given by the user */
	if (!qos_queue->shaperEnable) {
		if(!gstrcmp(qos_queue->qIf,"WAN"))
		{
			ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_upPortRateLim",
				       IFX_F_GET_ENA, 0, sLine);
			IFX_API_LOG("[%s:%d] Original Peak rate = %d", __FUNCTION__,
				    __LINE__, qos_queue->peakRate);
			qos_queue->peakRate = atoi(sLine);
			IFX_API_LOG("[%s:%d] Modified Upstream Peak rate = %d", __FUNCTION__,
				    __LINE__, qos_queue->peakRate);
		}
		if(!gstrcmp(qos_queue->qIf,"LAN"))
		{
			ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_downPortRateLim",
				       IFX_F_GET_ENA, 0, sLine);
			IFX_API_LOG("[%s:%d] Original Peak rate = %d", __FUNCTION__,
				    __LINE__, qos_queue->peakRate);
			qos_queue->peakRate = atoi(sLine);
			IFX_API_LOG("[%s:%d] Modified Downstream Peak rate = %d", __FUNCTION__,
				    __LINE__, qos_queue->peakRate);
		}
	}

	/* perform rate validation */
	if(!gstrcmp(qos_queue->qIf,"WAN"))
	{
		retval = ipqos_rate_validate(Oper, qos_queue->iid.cpeId.Id, qos_queue);
		if (retval != IFX_SUCCESS) {
			IFX_API_LOG("[%s:%d] Upstream Rate Validation Failed", __FUNCTION__,
				    __LINE__);
			ret = retval;	//IFX_FAILURE;
			goto IFX_Handler;
		}
	}
	if(!gstrcmp(qos_queue->qIf,"LAN"))
	{
		retval = ipqos_rate_validate_DS(Oper, qos_queue->iid.cpeId.Id, qos_queue);
		if (retval != IFX_SUCCESS) {
			IFX_API_LOG("[%s:%d] Downstream Rate Validation Failed", __FUNCTION__,
				    __LINE__);
			ret = retval;	//IFX_FAILURE;
			goto IFX_Handler;
		}
	}
	 /**************** Name Value Formation as per RC.CONF ********************/

	/* Form the FVP from the given structure for ADD/MODIFY
	 * Operations
	 */
	
	/* Set the Queue name if owner is tr69 */
	if ((qos_queue->iid.config_owner == IFX_TR69) && (Oper == IFX_OP_ADD)) {
		sprintf(qos_queue->qName, "tr69_queue_%d",
			qos_queue->iid.cpeId.Id);
	}

	/* Set the Queue len for add operation */
	/* TBD: QLen Set To Default. Should be removed */
	if (Oper == IFX_OP_ADD) {
		qos_queue->qLen = DEFAULT_QLEN;
	}

	count = 0;
	
	if (IFX_DELETE_F_NOT_SET(flags)) {

		ifx_fill_ArrayFvp_FName(array_fvp, 0,
					IFX_MAPI_MAX_IPQOS_QUEUE_SECTION_PARAMS,
					ipqos_queue_params);
		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 6,
					    (int *)&qos_queue->iid.cpeId.Id,
					    &qos_queue->iid.pcpeId.Id,
					    &qos_queue->qIfType,
					    &qos_queue->dropType,
					    &qos_queue->schedType,
					    &qos_queue->shapeRate);

		ifx_fill_ArrayFvp_uintValues(array_fvp, 6, 8,
					     &qos_queue->qLen,
					     &qos_queue->qWt,
					     &qos_queue->qPrio,
					     &qos_queue->redTh,
					     &qos_queue->redPct,
					     &qos_queue->sbs,
					     &qos_queue->peakRate,
					     &qos_queue->commitRate);

		ifx_fill_ArrayFvp_boolValues(array_fvp, 14, 3,
					     &qos_queue->enable,
					     &qos_queue->weightEnable,
					     &qos_queue->shaperEnable);

		ifx_fill_ArrayFvp_strValues(array_fvp, 17, 4,
					    qos_queue->qName,
					    qos_queue->qIf,
					    qos_queue->trafficClass,
					    qos_queue->egressPVC);

#if 1
		if (qos_queue->redTh == 0)
			sensibleRedTh = DEFAULT_REDTH;
		else
			sensibleRedTh = qos_queue->redTh;
		if (qos_queue->redPct == 0)
			sensibleRedPct = DEFAULT_REDPCT;
		else
			sensibleRedPct = qos_queue->redPct;

		redth = (uint32) ((float)sensibleRedTh / 100 * qos_queue->qLen);
		redp = (float)sensibleRedPct / 100;	//have to pass redprob as a decimal value
		sprintf(array_fvp[21].value, "%u", redth);
		sprintf(array_fvp[22].value, "%f", redp);
#endif
		passed_index = -1;
	}
	count = IFX_MAPI_MAX_IPQOS_QUEUE_SECTION_PARAMS;

/* Get Config Index in case of modify/delete operations from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, qos_queue->iid.cpeId,
					 passed_index)
	}

/* Determine the configuration index - for Add, Delete, Modify operations
 * Name is partial since index is not known
 * Fill array_fvp[] */
	if (ifx_get_conf_index_and_nv_pairs(&qos_queue->iid, passed_index,
					    PREFIX_IPQOS_QUEUE, count,
					    array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	
/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	if (IFX_ADD_F_NOT_SET(flags)) {
		CHECK_ACL_RET(qos_queue->iid, count, array_fvp,
			      changed_count, array_changed_fvp, flags,
			      IFX_Handler)
	}

	//This is the enable  as in RC.CONF
	if ((ifx_GetObjData
	     (FILE_RC_CONF, TAG_IPQOS_QM, "qm_enable", IFX_F_GET_ANY, &outflag,
	      qmenable)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* If modify flag is set, and queue is in enabled state first update system comfig 
	   before updating rc.conf IN this case, delete queue entry in this section and
	   add new queue entry in device config block. If delete flag is set, delete queue instance

	 */
	/* before config file update, for modify or delete operation stop this  */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    (IFX_DELETE_F_SET(flags) || IFX_MODIFY_F_SET(flags))) {

		sprintf(sbuf, "%s_%d_enable", PREFIX_IPQOS_QUEUE, passed_index);

		//This is the enable  as in RC.CONF
		if ((ifx_GetObjData
		     (FILE_RC_CONF, TAG_IPQOS_QUEUE, sbuf, IFX_F_GET_ANY,
		      &outflag, old_enable)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}

/*enter CPU path */
		if (((IFX_DELETE_F_SET(flags) && (atoi(old_enable) == 1)) ||
		     (IFX_MODIFY_F_SET(flags) && (atoi(old_enable) == 1))) &&
		    (atoi(qmenable) == 1)) {

			q_flag = 0;	//add = 1, delete =0, modify = 2

			if (!gstrcmp(qos_queue->qIf,"LAN")){
				QOS_MODE=2;/* DSQoS */
			}
			 
			if (!gstrcmp(qos_queue->qIf,"WAN")){
				QOS_MODE=1; /*UPStream QoS */
			}
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			sprintf(sCommand, "%s %d %d %d", IPQOS_QUEUE_MGMT,
				passed_index, q_flag, QOS_MODE);
			system(sCommand);
#if 0 
         //Get old value of TCP ACK Prio from rc.conf
         if ((ifx_GetObjData
	            (FILE_RC_CONF, TAG_IPQOS_QM, "qm_tcpackprio", IFX_F_GET_ANY,
	               &outflag, old_tcpackprio)) != IFX_SUCCESS) 
         {
#ifdef IFX_LOG_DEBUG
		      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
            ret = IFX_FAILURE;
            goto IFX_Handler;
	      }
         if (atoi(old_tcpackprio) == 1) 
         {
			   sprintf(sCommand,
						". /etc/rc.d/ipqos_common 0 2");
				system(sCommand);
			}
#endif
		}

	}

   //Get old value of TCP ACK Prio from rc.conf
    if ((ifx_GetObjData
	      (FILE_RC_CONF, TAG_IPQOS_QM, "qm_tcpackprio", IFX_F_GET_ANY,
	             &outflag, old_tcpackprio)) != IFX_SUCCESS) 
    {
#ifdef IFX_LOG_DEBUG
		      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
            ret = IFX_FAILURE;
            goto IFX_Handler;
	 }
    if (atoi(old_tcpackprio) == 1) 
    {
	   sprintf(sCommand,
				". /etc/rc.d/ipqos_common 0 2");
		system(sCommand);
	 }



/************** System Config File Update Block ****************/
/* Convert the name value pair in array_fvp into string format
   expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);

/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_IPQOS_QUEUE, flags, 1, conf_buf);

	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	if (IFX_ADD_F_SET(flags)) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, qos_queue->iid.cpeId,
					 passed_index)

		    IFX_DBG("[%s:%d] passed_index=%d", __FUNCTION__, __LINE__,
			    passed_index);
	}

	// TBD: Remove this if cond if it cover all the possibilities
	if (IFX_ADD_F_SET(flags) || IFX_MODIFY_F_SET(flags)
	    || IFX_DELETE_F_SET(flags)) {
		init_qspec_class_queue_map_file(qos_queue, flags);
	}
// Put qWt commited rate in /tmp/sysstatus

/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* System call to Add/Delete/Modify Route */

	/* Read the RC.CONF and call scripts  to add ip table rules 
	 */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {

		if (IFX_DELETE_F_NOT_SET(flags) &&
		    (IFX_DEACTIVATE_F_NOT_SET(flags))) {

			if (qos_queue->enable == IFX_ENABLED) {

#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				/*Queuing Instance is enabled. */
				if ((IFX_ADD_F_SET(flags)
				     || IFX_MODIFY_F_SET(flags))
				    && (atoi(qmenable) == 1)) {
					/*script to add queue needs classifiers cpeI and qId, queues Index, redPct, flag
					 */
					q_flag = 1;	//add = 1, delete =0, modify = 2
				}

			}

		}
	}

	/* this will Compact the section and also update the count for both ADD and DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_IPQOS_QUEUE, flags);

	 /*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

	 /*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_MODIFY_F_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION(qos_queue->iid, changed_count,
					  array_changed_fvp, flags, IFX_Handler)
	} else if (IFX_INT_ADD_F_SET(flags)) {

		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */
		/*********** Epilog Block **************/
		UPDATE_ID_MAP_N_ATTRIBUTES(&qos_queue->iid, count,
					   array_fvp, flags, IFX_Handler)

		    CHECK_N_SEND_NOTIFICATION(qos_queue->iid, count,
					      array_fvp, flags, IFX_Handler)

		    /* Manipulate nextCpeId only for ADD operations */
		    ifx_increment_next_cpeId(FILE_RC_CONF, TAG_IPQOS_QUEUE);

	} else if (IFX_DELETE_F_SET(flags)) {

		/* In case of DELETE operation,first send the notification update of the 
		 * IDMappings and then send the Notification for the attributes                                                                                                                    */

    /************ EpilogBlock * **************/
		CHECK_N_SEND_NOTIFICATION(qos_queue->iid, count,
					  array_fvp, flags, IFX_Handler)
		    UPDATE_ID_MAP_N_ATTRIBUTES(&qos_queue->iid, count,
					       array_fvp, flags, IFX_Handler)
	}

	/* Update Flags  - This is done independant of whether qos is enabled or not. */
	sprintf(sCommand, "queuecfg -u 0/0");
	system(sCommand);
	/* Update Rates */
	sprintf(sCommand, "queuecfg -r 0/0");
	system(sCommand);
	/* Updating Flags after Updating Rates */
	sprintf(sCommand, "queuecfg -u 0/0");
	system(sCommand);

	/* If QoS is enabled, create the new Queue Structure */
	if (atoi(qmenable) == 1) {

		/* Configure Queues */
		if (!gstrcmp(qos_queue->qIf,"WAN"))
		{
			sprintf(sCommand, "queuecfg -q 1/0");
			system(sCommand);
		}
		if (!gstrcmp(qos_queue->qIf,"LAN"))
		{
			sprintf(sCommand, "queuecfg -q 2/0");
			system(sCommand);
		}
      		if (atoi(old_tcpackprio) == 1) 
      		{
			sprintf(sCommand,
						". /etc/rc.d/ipqos_common 0 0");
			system(sCommand);
		}
		
		/* Initialize Hardware classifiers */
		sprintf(sCommand, "queuecfg -s 0/0");
		system(sCommand);

	}

	if (atoi(qmenable) == 1) {
		if (IFX_ADD_F_SET(flags)) {
			sprintf(sCommand, "queuecfg -p 0/0");
			system(sCommand);
		} else if (IFX_DELETE_F_SET(flags)) {
			sprintf(sCommand, "queuecfg -p 0/0");
			system(sCommand);
		} else if (IFX_MODIFY_F_SET(flags)) {
			sprintf(sCommand, "queuecfg -p 0/0");
			system(sCommand);
		}
	}

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
*   ifx_mapi_set_qos_policer (uint32 Oper,
     IFX_MAPI_QoS_Policer *qos_policer, uint32 flags)
*   operation   ==>   the operation to be performed,
*     can be ADD, DELETE or MODIFY
*   queue    ==>   pointer to IFX_MAPI_QoS_Policer structure that has
*     QoS Queue Management details
*   flags       ==>   flags that define the behaviour
*
*   Return Value :   IFX_SUCCESS or IFX_FAILURE
    Description:
      This function configures the Policer parameters 
*//////////////////////////////////////////////////////////////////////////////

int32 ifx_mapi_set_qos_policer(uint32 Oper, IFX_MAPI_QoS_Policer * qos_policer,
			       uint32 flags)
{
	char8 conf_buf[MAX_DATA_LEN];
	int count = 0, changed_count = 0, passed_index = -1;
	int ret = IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR array_fvp[IFX_MAPI_MAX_IPQOS_POLICER_SECTION_PARAMS
				      + 1];
	IFX_NAME_VALUE_PAIR *array_changed_fvp = NULL;

	memset(array_fvp, 0, sizeof(array_fvp));
	NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));

/*************** Prolog Block *********************/
/* Based on operation (ADD or DELETE or MODIFY)
 * append the flag with internal flags */
	if (Oper == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (Oper == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

/**************** Validation Block *****************/
/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(qos_policer)
/* Do simple validation of flags sucha as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

	/* Set the parent SectioddnName and parent IID values
	 * to QM object
	 */
	sprintf(qos_policer->iid.cpeId.secName, "%s", TAG_IPQOS_POLICER);
	sprintf(qos_policer->iid.pcpeId.secName, "%s", TAG_IPQOS_QM);
	qos_policer->iid.pcpeId.Id = 1;

/**************** ID Allocation Block - Only for ADD Operation **************/

	if (IFX_ADD_F_SET(flags)) {
		/* Allocate the IID for this classifier instance */
		if (ifx_get_IID(&qos_policer->iid, "cAc") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	 /**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given structure for ADD/MODIFY
	 * Operations
	 */

	/* Set the Policer name if owner is tr69 */
	if ((qos_policer->iid.config_owner == IFX_TR69) && (Oper == IFX_OP_ADD)) {
		sprintf(qos_policer->pName, "tr69_policer_%d",
			qos_policer->iid.cpeId.Id);
	}

	count = 0;

	if (IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, 0,
					IFX_MAPI_MAX_IPQOS_POLICER_SECTION_PARAMS,
					ipqos_policer_params);
		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 6,
					    (int *)&qos_policer->iid.cpeId.Id,
					    &qos_policer->iid.pcpeId.Id,
					    &qos_policer->mtrType,
					    &qos_policer->cfmAction,
					    &qos_policer->partCfmAction,
					    &qos_policer->nonCfmAction);

		ifx_fill_ArrayFvp_uintValues(array_fvp, 6, 11,
					     &qos_policer->cr,
					     &qos_policer->cbs,
					     &qos_policer->ebs,
					     &qos_policer->pr,
					     &qos_policer->pbs,
					     &qos_policer->cfmDscpMark,
					     &qos_policer->cfmPbitsMark,
					     &qos_policer->partCfmDscpMark,
					     &qos_policer->partCfmPbitsMark,
					     &qos_policer->nonCfmDscpMark,
					     &qos_policer->nonCfmPbitsMark);

		ifx_fill_ArrayFvp_boolValues(array_fvp, 17, 1,
					     &qos_policer->enable);

		ifx_fill_ArrayFvp_strValues(array_fvp, 18, 1,
					    qos_policer->pName);

		passed_index = -1;
	}
	count = IFX_MAPI_MAX_IPQOS_POLICER_SECTION_PARAMS;

/* Get Config Index in case of modify/delete operations from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF,
					 qos_policer->iid.cpeId, passed_index)
	}

/* Determine the configuration index - for Add, Delete, Modify operations
 * Name is partial since index is not known
 * Fill array_fvp[] */
	if (ifx_get_conf_index_and_nv_pairs(&qos_policer->iid, passed_index,
					    PREFIX_IPQOS_POLICER, count,
					    array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	if (IFX_ADD_F_NOT_SET(flags)) {
		CHECK_ACL_RET(qos_policer->iid, count, array_fvp,
			      changed_count, array_changed_fvp, flags,
			      IFX_Handler)
	}

	/* before config file update, for modify or delete operation stop this  */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    (IFX_DELETE_F_SET(flags) || IFX_MODIFY_F_SET(flags))) {

	}

/************** System Config File Update Block ****************/
/* Convert the name value pair in array_fvp into string format
   expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);

/* RC.CONF Configuration block */
	ret =
	    ifx_SetObjData(FILE_RC_CONF, TAG_IPQOS_POLICER, flags, 1, conf_buf);

	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* System call to Add/Delete/Modify Route */

/* Read the RC.CONF and call scripts  to add ip table rules 
*/
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
		if (IFX_ADD_F_SET(flags)) {
			/*Call script to add iptable rules for classifier
			 *ipqos_classify_add script reads from the rc.conf directly, finds
			 *what fields are updated in the ipqos_classify section and frames
			 *iptable rules before adding them on the system
			 */
/*			sprintf(sCommand, "%s", IPQOS_POLICER_ADD);
			system(sCommand);
*/
		} else if (IFX_MODIFY_F_SET(flags)) {
			if (IFX_DEACTIVATE_F_NOT_SET(flags)) {
				/*
				 */
/*			sprintf(sCommand, "%s", IPQOS_POLICER_MODIFY);
			system(sCommand);
*/

			}
		}

	}

	/* this will Compact the section and also update the count for both ADD and DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_IPQOS_POLICER, flags);

	 /*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

	 /*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_MODIFY_F_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION(qos_policer->iid, changed_count,
					  array_changed_fvp, flags, IFX_Handler)
	} else if (IFX_INT_ADD_F_SET(flags)) {

		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */
		/*********** Epilog Block **************/
		UPDATE_ID_MAP_N_ATTRIBUTES(&qos_policer->iid, count,
					   array_fvp, flags, IFX_Handler)

		    CHECK_N_SEND_NOTIFICATION(qos_policer->iid, count,
					      array_fvp, flags, IFX_Handler)

		    /* Manipulate nextCpeId only for ADD operations */
		    ifx_increment_next_cpeId(FILE_RC_CONF, TAG_IPQOS_POLICER);

	} else if (IFX_DELETE_F_SET(flags)) {

		/* In case of DELETE operation,first send the notification update of the 
		 * IDMappings and then send the Notification for the attributes                                                                                                                    */

    /************ EpilogBlock * **************/
		CHECK_N_SEND_NOTIFICATION(qos_policer->iid, count,
					  array_fvp, flags, IFX_Handler)
		    UPDATE_ID_MAP_N_ATTRIBUTES(&qos_policer->iid, count,
					       array_fvp, flags, IFX_Handler)
	}

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
*   ifx_mapi_get_qos_capability (IFX_MAPI_QoS_Capability *qos_capab,
*   uint32 flags)
*   *qos_capab   ==>   pointer to IFX_MAPI_QoS_Capability structure that has
*     QoS capabily  details
*   flags       ==>   flags that define the behaviour
*
*   Return Value :   IFX_SUCCESS or IFX_FAILURE
    Description:
    This function reads rc.conf and gets qos capbilities and returns pointer 
  	to updated IFX_MAPI_QoS_Capability structure.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_mapi_get_qos_capability(IFX_MAPI_QoS_Capability * qos_capab,
				  uint32 flags)
{
	char8 sBuf[MAX_FILELINE_LEN], *sValue = NULL;
	int32 count = 0;
	int ret = IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR
	    array_fvp[IFX_MAPI_MAX_IPQOS_CAPABILITY_SECTION_PARAMS + 1];

	sprintf(sBuf, "%s_", PREFIX_IPQOS_CAPABILITY);
	if ((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_IPQOS_CAPABILITY,
				    sBuf, flags, &sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);

	/*if ((qos_capab->enable = atoi(array_fvp[2].value))!= 1){
	   #ifdef IFX_LOG_DEBUG
	   IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	   #endif
	   ret = IFX_FAILURE;
	   goto IFX_Handler;
	   }
	 */

/* copy the queue entries into the structure */

	ifx_fill_intValues_ArrayFvp(array_fvp, 0, 5,
				    (int *)&qos_capab->iid.cpeId.Id,
				    &qos_capab->iid.pcpeId.Id,
				    &qos_capab->schedAlgo[0],
				    &qos_capab->dropAlgo[0],
				    &qos_capab->meterType[0]);

	ifx_fill_uintValues_ArrayFvp(array_fvp, 5, 7,
				     &qos_capab->maxInputQs,
				     &qos_capab->maxOutputQs,
				     &qos_capab->maxClassifiers,
				     &qos_capab->maxApps,
				     &qos_capab->maxFlows,
				     &qos_capab->maxPolicers,
				     &qos_capab->numID);

	ifx_fill_boolValues_ArrayFvp(array_fvp, 12, 2,
				     &qos_capab->ingressShapingSupport,
				     &qos_capab->policerSupport);

	qos_capab->schedAlgoCnt = 1;
	qos_capab->dropAlgoCnt = 1;
	qos_capab->meterTypeCnt = 1;

      IFX_Handler:
	IFX_MEM_FREE(sValue)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}

	return IFX_SUCCESS;

}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_all_qos_classifier(...)
*       num_entries ==>  outut number of classifier entries
*       classify   ==>  output pointer to an array of classify entries
		in rc.conf
*   	flags       ==> flags that define behaviour of get
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
        Description:
        This Function reads the classifier configuration in rc.conf file,
          and stores each classifier entry into the classify struct.
*//////////////////////////////////////////////////////////////////////////////

int32 ifx_mapi_get_all_qos_classifier(uint32 * numEntries,
				      IFX_MAPI_QoS_Classifier ** classify,
				      uint32 flags)
{
	int nCount = 0, nIndex = 0;
	int ret = IFX_SUCCESS, classify_count = 0;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 sCommand[MAX_FILELINE_LEN];
	char8 sBuf[MAX_FILELINE_LEN];
	IFX_MAPI_QoS_Classifier *t_ptr = NULL;
	/*IP_MASK *ipmask;
	   PORT_RANGE *ip_port; */
	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));

	/* first, get the number of classification entries from rc.conf */
	MAKE_SECTION_COUNT_TAG(TAG_IPQOS_CLASSIFY, sCommand);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_CLASSIFY,
				  sCommand, flags, &outFlag,
				  sBuf)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	nCount = atoi(sBuf);
/* Manamohan: 10,June 2011 , range check as per Klocwork report */
	if ((nCount < 0) || (nCount > 0xFFFFFFFF))
		return IFX_FAILURE;

	if (nCount == 0) {
		*numEntries = 0;
		*classify = NULL;
		goto IFX_Handler;
	}
	*classify = NULL;
	t_ptr =
	    (IFX_MAPI_QoS_Classifier *) IFX_MALLOC(nCount *
						   sizeof
						   (IFX_MAPI_QoS_Classifier));
	if (t_ptr == NULL) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	*classify = t_ptr;

	for (nIndex = 0; nIndex < nCount; nIndex++) {

		NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
		sprintf(sCommand, "%s_%d_cpeId", PREFIX_IPQOS_CLASSIFY, nIndex);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_CLASSIFY,
					  sCommand, flags, &outFlag,
					  sBuf)) != IFX_SUCCESS) {
			goto IFX_Handler;
		}

		(*classify + classify_count)->iid.cpeId.Id = atoi(sBuf);

		if ((ret =
		     ifx_mapi_get_qos_classifier((*classify + classify_count),
						 flags) != IFX_SUCCESS)) {
			goto IFX_Handler;
		}

		classify_count++;
	}			/*for loop */

	*numEntries = classify_count;

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*classify)
		    * numEntries = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}

	else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_all_qos_ds_classifier(...)
*       num_entries ==>  outut number of classifier entries
*       classify   ==>  output pointer to an array of classify entries
		in rc.conf
*   	flags       ==> flags that define behaviour of get
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
        Description:
        This Function reads the classifier configuration in rc.conf file,
          and stores each classifier entry into the classify struct.
*//////////////////////////////////////////////////////////////////////////////

int32 ifx_mapi_get_all_qos_ds_classifier(uint32 * numEntries,
				      IFX_MAPI_QoS_Classifier ** classify,
				      uint32 flags)
{
	int nCount = 0, nIndex = 0;
	int ret = IFX_SUCCESS, classify_count = 0;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 sCommand[MAX_FILELINE_LEN];
	char8 sBuf[MAX_FILELINE_LEN];
	IFX_MAPI_QoS_Classifier *t_ptr = NULL;
	/*IP_MASK *ipmask;
	   PORT_RANGE *ip_port; */
	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));

	/* first, get the number of classification entries from rc.conf */
	MAKE_SECTION_COUNT_TAG(TAG_IPQOS_DS_CLASSIFY, sCommand);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_DS_CLASSIFY,
				  sCommand, flags, &outFlag,
				  sBuf)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	nCount = atoi(sBuf);
/* Manamohan: 10,June 2011 , range check as per Klocwork report */
	if ((nCount < 0) || (nCount > 0xFFFFFFFF))
		return IFX_FAILURE;

	if (nCount == 0) {
		*numEntries = 0;
		*classify = NULL;
		goto IFX_Handler;
	}
	*classify = NULL;
	t_ptr =
	    (IFX_MAPI_QoS_Classifier *) IFX_MALLOC(nCount *
						   sizeof
						   (IFX_MAPI_QoS_Classifier));
	if (t_ptr == NULL) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	*classify = t_ptr;

	for (nIndex = 0; nIndex < nCount; nIndex++) {

		NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
		sprintf(sCommand, "%s_%d_cpeId", PREFIX_IPQOS_DS_CLASSIFY, nIndex);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_DS_CLASSIFY,
					  sCommand, flags, &outFlag,
					  sBuf)) != IFX_SUCCESS) {
			goto IFX_Handler;
		}

		(*classify + classify_count)->iid.cpeId.Id = atoi(sBuf);

		if ((ret =
		     ifx_mapi_get_qos_classifier((*classify + classify_count),
						 flags) != IFX_SUCCESS)) {
			goto IFX_Handler;
		}

		classify_count++;
	}			/*for loop */

	*numEntries = classify_count;

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*classify)
		    * numEntries = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}

	else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_get_qos_classifier(...)
*       *classify    ==>  outut pointer to the structre IFX_MAPI_QOS_Classifier
*   	flags       ==>
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
*        Description:
*	    This function reads the IPQoS classification entries from rc.conf 
  *		and returns a pointer to the struct IFX_MAPI_QoS_Classifier
*//////////////////////////////////////////////////////////////////////////

int32 ifx_mapi_get_qos_classifier(IFX_MAPI_QoS_Classifier * classify,
				  uint32 flags)
{
	char8 sBuf[MAX_FILELINE_LEN], *sValue = NULL;
	int32 passed_index = -1, count = 0;
	int ret = IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR
	    array_fvp[IFX_MAPI_MAX_IPQOS_CLASSIFIER_SECTION_PARAMS + 1];

	/* Fill the section tag */
	sprintf(classify->iid.cpeId.secName, "%s", TAG_IPQOS_CLASSIFY);

	/* get index from cpeid */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, classify->iid.cpeId,
				 passed_index)
	    sprintf(sBuf, "%s_%d_", PREFIX_IPQOS_CLASSIFY, passed_index);
	if ((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_IPQOS_CLASSIFY,
				    sBuf, flags, &sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	memset(array_fvp, 0x00, sizeof(array_fvp));

	form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);

	/* copy the classify entries into the structure */
	ifx_fill_intValues_ArrayFvp(array_fvp, 0, 20,
				    (int *)&classify->iid.cpeId.Id,
				    &classify->iid.pcpeId.Id,
				    &classify->trafficClassId,
				    &classify->qId,
				    &classify->policerId,
				    &classify->mfClass,
				    &classify->classIf,
				    &classify->IngIf,
				    &classify->protoNum,
				    &classify->L3protoNum,
				    &classify->srcPortRange.start_port,
				    &classify->srcPortRange.end_port,
				    &classify->dstPortRange.start_port,
				    &classify->dstPortRange.end_port,
				    &classify->dscpCheck,
				    &classify->dscpMark,
				    &classify->pBitsCheck,
				    &classify->pBitsMark,
				    &classify->vlanCheck, &classify->rateLmt);

	ifx_fill_uintValues_ArrayFvp(array_fvp, 20, 2,
				     &classify->order, &classify->fwPolicy);

	ifx_fill_boolValues_ArrayFvp(array_fvp, 22, 13,
				     &classify->enable,
				     &classify->srcIPExcl,
				     &classify->dstIPExcl,
				     &classify->protoExcl,
				     &classify->L3protoExcl,
				     &classify->srcPortExcl,
				     &classify->dstPortExcl,
				     &classify->srcMacExcl,
				     &classify->dstMacExcl,
				     &classify->dscpExcl,
				     &classify->pBitsExcl,
				     &classify->vlanExcl,
				     &classify->rateCtrlEnbl);

	{
#if 0
		//TBD: Max IPAddress Size. Considering 18 since no macro found in ifxapi include for it
		char8 srcIP[18];
		char8 srcIPMask[18];
		char8 dstIP[18];
		char8 dstIPMask[18];
#endif
		ifx_fill_strValues_ArrayFvp(array_fvp, 35, 11,
					    classify->classifierName,
					    classify->specIf,
#if 0
					    srcIP, srcIPMask, dstIP, dstIPMask,
#else
					    classify->srcIP.ip,
					    classify->srcIP.mask,
					    classify->dstIP.ip,
					    classify->dstIP.mask,
#endif
					    classify->srcMac,
					    classify->srcMacMask,
					    classify->dstMac,
					    classify->dstMacMask,
					    classify->specIf);

#if 0
		inet_aton(srcIP, &(classify->srcIP.ip));
		inet_aton(srcIPMask, &(classify->srcIP.mask));
		inet_aton(dstIP, &(classify->dstIP.ip));
		inet_aton(dstIPMask, &(classify->dstIP.mask));
#endif
		ifx_fill_boolValues_ArrayFvp(array_fvp, 46, 1,
					     &classify->disableAccel);
	}

	//TBD: Fill remaining fields in structure
	//Fill the status field in structure
	if (classify->enable != 1)
		classify->status = IFX_DISABLED;
	else
		classify->status = IFX_ENABLED;

      IFX_Handler:
	IFX_MEM_FREE(sValue)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_get_qos_ds_classifier(...)
*       *classify    ==>  outut pointer to the structre IFX_MAPI_QOS_Classifier
*   	flags       ==>
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
*        Description:
*	    This function reads the IPQoS classification entries from rc.conf 
  *		and returns a pointer to the struct IFX_MAPI_QoS_Classifier
*//////////////////////////////////////////////////////////////////////////

int32 ifx_mapi_get_qos_ds_classifier(IFX_MAPI_QoS_Classifier * classify,
				  uint32 flags)
{
	char8 sBuf[MAX_FILELINE_LEN], *sValue = NULL;
	int32 passed_index = -1, count = 0;
	int ret = IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR
	    array_fvp[IFX_MAPI_MAX_IPQOS_CLASSIFIER_SECTION_PARAMS + 1];

	/* Fill the section tag */
	sprintf(classify->iid.cpeId.secName, "%s", TAG_IPQOS_DS_CLASSIFY);

	/* get index from cpeid */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, classify->iid.cpeId,
				 passed_index)
	    sprintf(sBuf, "%s_%d_", PREFIX_IPQOS_DS_CLASSIFY, passed_index);
	if ((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_IPQOS_DS_CLASSIFY,
				    sBuf, flags, &sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	memset(array_fvp, 0x00, sizeof(array_fvp));

	form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);

	/* copy the classify entries into the structure */
	ifx_fill_intValues_ArrayFvp(array_fvp, 0, 20,
				    (int *)&classify->iid.cpeId.Id,
				    &classify->iid.pcpeId.Id,
				    &classify->trafficClassId,
				    &classify->qId,
				    &classify->policerId,
				    &classify->mfClass,
				    &classify->classIf,
				    &classify->IngIf,
				    &classify->protoNum,
				    &classify->L3protoNum,
				    &classify->srcPortRange.start_port,
				    &classify->srcPortRange.end_port,
				    &classify->dstPortRange.start_port,
				    &classify->dstPortRange.end_port,
				    &classify->dscpCheck,
				    &classify->dscpMark,
				    &classify->pBitsCheck,
				    &classify->pBitsMark,
				    &classify->vlanCheck, &classify->rateLmt);

	ifx_fill_uintValues_ArrayFvp(array_fvp, 20, 2,
				     &classify->order, &classify->fwPolicy);

	ifx_fill_boolValues_ArrayFvp(array_fvp, 22, 13,
				     &classify->enable,
				     &classify->srcIPExcl,
				     &classify->dstIPExcl,
				     &classify->protoExcl,
				     &classify->L3protoExcl,
				     &classify->srcPortExcl,
				     &classify->dstPortExcl,
				     &classify->srcMacExcl,
				     &classify->dstMacExcl,
				     &classify->dscpExcl,
				     &classify->pBitsExcl,
				     &classify->vlanExcl,
				     &classify->rateCtrlEnbl);

	{
#if 0
		//TBD: Max IPAddress Size. Considering 18 since no macro found in ifxapi include for it
		char8 srcIP[18];
		char8 srcIPMask[18];
		char8 dstIP[18];
		char8 dstIPMask[18];
#endif
		ifx_fill_strValues_ArrayFvp(array_fvp, 35, 11,
					    classify->classifierName,
					    classify->specIf,
#if 0
					    srcIP, srcIPMask, dstIP, dstIPMask,
#else
					    classify->srcIP.ip,
					    classify->srcIP.mask,
					    classify->dstIP.ip,
					    classify->dstIP.mask,
#endif
					    classify->srcMac,
					    classify->srcMacMask,
					    classify->dstMac,
					    classify->dstMacMask,
					    classify->specIf);

#if 0
		inet_aton(srcIP, &(classify->srcIP.ip));
		inet_aton(srcIPMask, &(classify->srcIP.mask));
		inet_aton(dstIP, &(classify->dstIP.ip));
		inet_aton(dstIPMask, &(classify->dstIP.mask));
#endif
		ifx_fill_boolValues_ArrayFvp(array_fvp, 46, 1,
					     &classify->disableAccel);
	}

	//TBD: Fill remaining fields in structure
	//Fill the status field in structure
	if (classify->enable != 1)
		classify->status = IFX_DISABLED;
	else
		classify->status = IFX_ENABLED;

      IFX_Handler:
	IFX_MEM_FREE(sValue)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_get_qos_queue(...)
*       *queue    ==>  outut pointer to the structre IFX_MAPI_QOS_Queue
*   	flags       ==>
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
*        Description:
*	    This function reads the IPQoS Queue configuration  entries from rc.conf 
*		and returns a pointer to the struct IFX_MAPI_QoS_Queue. Since Queues 
*       are maintained by adding and deleting tc filter rules, rc.conf will not
*       show real condition of queues. Check if qq_<inst>_enable = 1, if enabled,
*       output data from rc.conf to structure, else return and error "Queue is 
  *       not enabled "
*//////////////////////////////////////////////////////////////////////////
int32 ifx_mapi_get_qos_queue(IFX_MAPI_QoS_Queue * qos_queue, uint32 flags)
{
	char8 sBuf[MAX_FILELINE_LEN], *sValue = NULL;
	int32 passed_index = -1, count = 0;
	int ret = IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR array_fvp[IFX_MAPI_MAX_IPQOS_QUEUE_SECTION_PARAMS +
				      1];

	/* Fill the section tag */
	sprintf(qos_queue->iid.cpeId.secName, "%s", TAG_IPQOS_QUEUE);

	/* get index from cpeid */
#ifdef IFX_LOG_DEBUG
	IFX_API_LOG("[%s:%d] cpeid=%d!", __FUNCTION__, __LINE__,
		    qos_queue->iid.cpeId.Id);
#endif
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, qos_queue->iid.cpeId,
				 passed_index)
	    sprintf(sBuf, "%s_%d_", PREFIX_IPQOS_QUEUE, passed_index);
	if ((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_IPQOS_QUEUE,
				    sBuf, flags, &sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	memset(array_fvp, 0x00, sizeof(array_fvp));

	form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);

	/* copy the queue entries into the structure */
	ifx_fill_intValues_ArrayFvp(array_fvp, 0, 6,
				    (int *)&qos_queue->iid.cpeId.Id,
				    &qos_queue->iid.pcpeId.Id,
				    &qos_queue->qIfType,
				    &qos_queue->dropType,
				    &qos_queue->schedType,
				    &qos_queue->shapeRate);

	ifx_fill_uintValues_ArrayFvp(array_fvp, 6, 8,
				     &qos_queue->qLen,
				     &qos_queue->qWt,
				     &qos_queue->qPrio,
				     &qos_queue->redTh,
				     &qos_queue->redPct,
				     &qos_queue->sbs,
				     &qos_queue->peakRate,
				     &qos_queue->commitRate);

	ifx_fill_boolValues_ArrayFvp(array_fvp, 14, 3,
				     &qos_queue->enable,
				     &qos_queue->weightEnable,
				     &qos_queue->shaperEnable);

	ifx_fill_strValues_ArrayFvp(array_fvp, 17, 4,
				    qos_queue->qName,
				    qos_queue->qIf,
				    qos_queue->trafficClass,
				    qos_queue->egressPVC);

	// Retrieve RED threasold and probability of dropping value
	qos_queue->uiRedTh = atoi(array_fvp[21].value);
	qos_queue->flRedProb = atof(array_fvp[22].value);

	if (qos_queue->enable != 1)
		qos_queue->status = IFX_DISABLED;
	else
		qos_queue->status = IFX_ENABLED;

	if (qos_queue->schedType == IFX_MAPI_QoS_Sched_WFQ) {
		/* Deallocate previously allocated memory */
		IFX_MEM_FREE(sValue);
		sValue = NULL;
		memset(sBuf, 0, sizeof(sBuf));

		sprintf(sBuf, "%s_%d_", PREFIX_IPQOS_QUEUE,
			qos_queue->iid.cpeId.Id);

		if ((ret = ifx_GetCfgObject(FILE_SYSTEM_STATUS, "qos_bk",
					    sBuf, flags,
					    &sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("[%s:%d], First call not found the section, section not created",
			     __FUNCTION__, __LINE__);
#endif
			ret = IFX_SUCCESS;
			goto IFX_Handler;
		}

		memset(array_fvp, 0x00, sizeof(array_fvp));
		form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);

		/* copy the queue entries into the structure */
		ifx_fill_uintValues_ArrayFvp(array_fvp, 0, 2,
					     &qos_queue->qWt,
					     &qos_queue->commitRate);
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("%s: weight and commited rate from tmp_systemstatus %u %u",
		     __func__, qos_queue->qWt, qos_queue->commitRate);
#endif
	}

	if (qos_queue->shaperEnable == 0) {
		IFX_MAPI_QoS_QM xQoSQM;
		ifx_mapi_get_qos_qm(&xQoSQM, IFX_F_DEFAULT);
		if(!gstrcmp(qos_queue->qIf,"WAN"))
			qos_queue->peakRate = xQoSQM.upstreamPortRateLimit;
		if(!gstrcmp(qos_queue->qIf,"LAN"))
			qos_queue->peakRate = xQoSQM.downstreamPortRateLimit;

#ifdef IFX_LOG_DEBUG
		IFX_DBG("%s: peakrate from tmp sysstatus %d ", __func__,
			qos_queue->peakRate);
#endif
	}

      IFX_Handler:
	IFX_MEM_FREE(sValue)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_get_all_qos_queue(...)
*       numEntries ==> output pointer to IFX_MAPI_QOS_Queue
*       *queue    ==>  outut pointer to the structre IFX_MAPI_QOS_Queue
*   	flags     ==>
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
*        Description:
*	This function reads the IPQoS Queue configuration  entries from rc.conf 
*		and returns a pointer to the struct IFX_MAPI_QoS_Queue. It returns
  *		all instances of queues.
*//////////////////////////////////////////////////////////////////////////
int32 ifx_mapi_get_all_qos_queue(uint32 * numEntries,
				 IFX_MAPI_QoS_Queue ** qos_queue, uint32 flags)
{

	int nCount = 0, nIndex = 0;
	int ret = IFX_SUCCESS, queue_count = 0;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 sCommand[MAX_FILELINE_LEN];
	char8 sBuf[MAX_FILELINE_LEN];
	IFX_MAPI_QoS_Queue *t_ptr = NULL;
	//WAN_PHY_CFG pstWanPhy;

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));

	/* first, get the number of queues entries from rc.conf */
	MAKE_SECTION_COUNT_TAG(TAG_IPQOS_QUEUE, sCommand);

	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QUEUE,
				  sCommand, flags, &outFlag,
				  sBuf)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	nCount = atoi(sBuf);

/* Manamohan: 10,June 2011 , range check as per Klocwork report */
	if ((nCount < 0) || (nCount > 0xFFFFFFFF))
		return IFX_FAILURE;

	if (nCount == 0) {
		*numEntries = 0;
		*qos_queue = NULL;
		goto IFX_Handler;
	}
	*qos_queue = NULL;
	t_ptr =
	    (IFX_MAPI_QoS_Queue *) IFX_MALLOC(nCount *
					      sizeof(IFX_MAPI_QoS_Queue));
	if (t_ptr == NULL) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	*qos_queue = t_ptr;

	for (nIndex = 0; nIndex < nCount; nIndex++) {

		NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
		sprintf(sCommand, "%s_%d_cpeId", PREFIX_IPQOS_QUEUE, nIndex);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QUEUE,
					  sCommand, flags, &outFlag,
					  sBuf)) != IFX_SUCCESS) {
			goto IFX_Handler;
		}

		(*qos_queue + queue_count)->iid.cpeId.Id = atoi(sBuf);

		if ((ret =
		     ifx_mapi_get_qos_queue((*qos_queue + queue_count),
					    flags) != IFX_SUCCESS)) {
			goto IFX_Handler;
		}

		queue_count++;
	}			/*for loop */

	*numEntries = queue_count;

	/* If current operational WAN MODE is Ethernet on MII0/MII1, only first 4 queues should be shown */
	//ifx_get_wan_phy_cfg(&pstWanPhy);  

	//if(pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII0 || pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII1)
	//      *numEntries = 4;

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*qos_queue)
		    * numEntries = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_get_qos_policer(...)
*       *queue    ==>  outut pointer to the structre IFX_MAPI_QOS_iPolicer
*   	flags       ==>
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
*        Description:
*	    This function reads the IPQoS Policer configuration  entries from rc.conf 
  *		and returns a pointer to the struct IFX_MAPI_QoS_Policer.
*//////////////////////////////////////////////////////////////////////////
int32 ifx_mapi_get_qos_policer(IFX_MAPI_QoS_Policer * qos_policer, uint32 flags)
{
	char8 sBuf[MAX_FILELINE_LEN], *sValue = NULL;
	int32 passed_index = -1, count = 0;
	int ret = IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR array_fvp[IFX_MAPI_MAX_IPQOS_POLICER_SECTION_PARAMS
				      + 1];

	/* Fill the section tag */
	sprintf(qos_policer->iid.cpeId.secName, "%s", TAG_IPQOS_POLICER);

	/* get index from cpeid */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, qos_policer->iid.cpeId,
				 passed_index)
	    sprintf(sBuf, "%s_%d_", PREFIX_IPQOS_POLICER, passed_index);
	if ((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_IPQOS_POLICER,
				    sBuf, flags, &sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	memset(array_fvp, 0x00, sizeof(array_fvp));

	form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);

	/* copy the policer entries into the structure */
	ifx_fill_intValues_ArrayFvp(array_fvp, 0, 6,
				    (int *)&qos_policer->iid.cpeId.Id,
				    &qos_policer->iid.pcpeId.Id,
				    &qos_policer->mtrType,
				    &qos_policer->cfmAction,
				    &qos_policer->partCfmAction,
				    &qos_policer->nonCfmAction);

	ifx_fill_uintValues_ArrayFvp(array_fvp, 6, 11,
				     &qos_policer->cr,
				     &qos_policer->cbs,
				     &qos_policer->ebs,
				     &qos_policer->pr,
				     &qos_policer->pbs,
				     &qos_policer->cfmDscpMark,
				     &qos_policer->cfmPbitsMark,
				     &qos_policer->partCfmDscpMark,
				     &qos_policer->partCfmPbitsMark,
				     &qos_policer->nonCfmDscpMark,
				     &qos_policer->nonCfmPbitsMark);

	ifx_fill_boolValues_ArrayFvp(array_fvp, 17, 1, &qos_policer->enable);

	ifx_fill_strValues_ArrayFvp(array_fvp, 18, 1, qos_policer->pName);

	//TBD: Fill remaining fields in structure
	//Fill the status field in structure
	if (qos_policer->enable != 1)
		qos_policer->status = IFX_DISABLED;
	else
		qos_policer->status = IFX_ENABLED;

      IFX_Handler:
	IFX_MEM_FREE(sValue)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_get_qos_qm(...)
*       *qos_qm    ==>  outut pointer to the structre IFX_MAPI_QOS_QM
*   	flags       ==>
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
*        Description:
*	    This function reads the top level IPQoS Queue Management entries from rc.conf 
*		and returns a pointer to the struct IFX_MAPI_QoS_QM. Since Queues 
*       are maintained by adding and deleting tc filter rules, rc.conf will not
  *       show real condition of queues. 
*/////////////////////////////////////////////////////////////////////////

int32 ifx_mapi_get_qos_qm(IFX_MAPI_QoS_QM * qos_qm, uint32 flags)
{

	char8 sBuf[MAX_FILELINE_LEN], *sValue = NULL;
	int32 count = 0;
	int ret = IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR
	    array_fvp[IFX_MAPI_MAX_IPQOS_QUEUEMGMT_SECTION_PARAMS + 1];

	sprintf(sBuf, "%s_", PREFIX_IPQOS_QM);

	if ((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_IPQOS_QM,
				    sBuf, flags, &sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);

	/* copy the queue entries into the structure */
	ifx_fill_intValues_ArrayFvp(array_fvp, 0, 8,
				    (int *)&qos_qm->iid.cpeId.Id,
				    &qos_qm->iid.pcpeId.Id,
				    &qos_qm->defaultDSCP,
				    &qos_qm->defaultPbits,
				    &qos_qm->defaultQ,
				    &qos_qm->defaultPolicer,
				    &qos_qm->defaultTC, &qos_qm->atmQMode);

	ifx_fill_uintValues_ArrayFvp(array_fvp, 8, 3,
				     &qos_qm->defaultFwPolicy,
				     &qos_qm->upstreamPortRateLimit,
				     &qos_qm->downstreamPortRateLimit);

	ifx_fill_boolValues_ArrayFvp(array_fvp, 11, 7,
				     &qos_qm->enable,
				     &qos_qm->USenable,
				     &qos_qm->DSenable,
				     &qos_qm->P8021enable,
				     &qos_qm->portRateLimitEnable,
				     &qos_qm->DSportRateLimitEnable,
				     &qos_qm->tcpackprio);

	ifx_fill_strValues_ArrayFvp(array_fvp, 18, 1, qos_qm->availableAppList);
	ifx_fill_strValues_ArrayFvp(array_fvp, 19, 1, qos_qm->qIf);
	ifx_fill_boolValues_ArrayFvp(array_fvp, 20, 1, &qos_qm->class_accel_mngr);

	/* queue status = Enable when enable = 1 */
	if (qos_qm->enable != IFX_ENABLED)
		qos_qm->status = IFX_DISABLED;
	else
		qos_qm->status = IFX_ENABLED;

	memset(sBuf, 0, sizeof(sBuf));

	/* If port rate limit is not enabled then read the value from /tmp/system_status */
/*	if (0 == qos_qm->portRateLimitEnable) {
		if ((ret = ifx_GetObjData(FILE_SYSTEM_STATUS, "qos_bk",
					  "up_link_rate", IFX_F_GET_ENA, 0,
					  sBuf)) != IFX_SUCCESS) {

#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			if ((ifx_GetObjData
		 		(FILE_RC_CONF, TAG_IPQOS_QM, "qm_upPortRateLim", IFX_F_GET_ANY,
		  		0, sBuf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}

		qos_qm->upstreamPortRateLimit = atoi(sBuf);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("%s: upstream port ratelmt from tmp sysstatus %d ",
			__func__, qos_qm->upstreamPortRateLimit);
#endif
	}
	if (0 == qos_qm->DSportRateLimitEnable) {
		if ((ret = ifx_GetObjData(FILE_SYSTEM_STATUS, "qos_bk",
					  "down_link_rate", IFX_F_GET_ENA, 0,
					  sBuf)) != IFX_SUCCESS) {

#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			if ((ifx_GetObjData
		 		(FILE_RC_CONF, TAG_IPQOS_QM, "qm_downPortRateLim", IFX_F_GET_ANY,
		  		0, sBuf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}

		qos_qm->downstreamPortRateLimit = atoi(sBuf);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("%s: downstream port ratelmt from tmp sysstatus %d ",
			__func__, qos_qm->downstreamPortRateLimit);
#endif
	}*/

      IFX_Handler:
	IFX_MEM_FREE(sValue)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_get_all_qos_classifier_class_if_specific(...
* 	qIfType ==> Input WAN interface for which classifiers are required)
*       num_entries ==>  outut number of classifier entries
*       qos_classify   ==>  output pointer to an array of classify entries
		in rc.conf
*   	flags       ==> flags that define behaviour of get
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
        Description:
        This Function  takes the input interface and reads the classifier configuration in rc.conf file,
                                              and stores each classifier entry into the classify struct.
*/// ///////////////////////////////////////////////////////////////////////////
int32
ifx_mapi_get_all_qos_classifier_class_if_specific(IFX_MAPI_QoS_Interface_Type
						  qIfType, uint32 * numEntries,
						  IFX_MAPI_QoS_Classifier **
						  qos_classify, uint32 flags)
{

#ifdef IFX_LOG_DEBUG
	IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#endif
	int nCount = 0, nIndex = 0, /* q_cpeId=0, */ q_IfType = 0;
	int ret = IFX_SUCCESS, classify_count = 0;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 sCommand[MAX_FILELINE_LEN], *retVal = NULL;;
	char8 sBuf[MAX_FILELINE_LEN];
	IFX_MAPI_QoS_Classifier *t_ptr = NULL;
	/* IP_MASK *ipmask; PORT_RANGE *ip_port; */
	// uint32 num_qinst=0;
	// IFX_MAPI_QoS_Queue *q_ptr = NULL;

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));

	/* Get the queue structure and number of queue instances for wan interface
	   passed */

	/* if((ret =
	   ifx_mapi_get_all_qos_queue_if_specific(IFX_MAPI_QoS_Interface_Type
	   qIfType, (uint32 *)&num_qinst, *q_ptr, flags)) != IFX_SUCCESS){

	   IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__); goto IFX_Handler;

	   } */

	/* get the number of classification entries from rc.conf */
	MAKE_SECTION_COUNT_TAG(TAG_IPQOS_CLASSIFY, sCommand);

	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_CLASSIFY,
				  sCommand, flags, &outFlag,
				  sBuf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#endif
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	nCount = atoi(sBuf);

#ifdef IFX_LOG_DEBUG
	IFX_API_LOG("[%s:%d] nCount=%d ", __FUNCTION__, __LINE__, nCount);
#endif

/* Manamohan: 10,June 2011 , range check as per Klocwork report */
	if ((nCount < 0) || (nCount > 0xFFFFFFFF))
		return IFX_FAILURE;

	if (nCount == 0) {
		*numEntries = 0;
		*qos_classify = NULL;
		goto IFX_Handler;
	}

	*qos_classify = NULL;

	t_ptr =
	    (IFX_MAPI_QoS_Classifier *) IFX_MALLOC(nCount *
						   sizeof
						   (IFX_MAPI_QoS_Classifier));
	if (t_ptr == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	*qos_classify = t_ptr;

	for (nIndex = 0; nIndex < nCount; nIndex++) {

		NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
		/* find IfType of classifier instance */
		sprintf(sCommand, "%s_%d_ifType", PREFIX_IPQOS_CLASSIFY,
			nIndex);

		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_CLASSIFY,
					  sCommand, flags, &outFlag,
					  sBuf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		q_IfType = atoi(sBuf);

		NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
		/* If Passed interface type matches the interface type of queue and
		   also matches classifiers q_Id, get this instance of classifier */

		if (q_IfType == qIfType) {
#ifdef IFX_LOG_DEBUG
			IFX_API_LOG("[%s:%d] Classifier MATCHED index=%d",
				    __FUNCTION__, __LINE__, nIndex);
#endif

			classify_count++;
		}
		IFX_MEM_FREE(retVal)
	}			/* for loop */

	*numEntries = classify_count;

      IFX_Handler:
	IFX_MEM_FREE(retVal)
	    if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*qos_classify)
		    * numEntries = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}

	else

		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_get_all_qos_ds_classifier_class_if_specific(...
* 	qIfType ==> Input WAN interface for which classifiers are required)
*       num_entries ==>  outut number of classifier entries
*       qos_classify   ==>  output pointer to an array of classify entries
		in rc.conf
*   	flags       ==> flags that define behaviour of get
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
        Description:
        This Function  takes the input interface and reads the classifier configuration in rc.conf file,
                                              and stores each classifier entry into the classify struct.
*/// ///////////////////////////////////////////////////////////////////////////
int32
ifx_mapi_get_all_qos_ds_classifier_class_if_specific(IFX_MAPI_QoS_Interface_Type
						  qIfType, uint32 * numEntries,
						  IFX_MAPI_QoS_Classifier **
						  qos_classify, uint32 flags)
{

#ifdef IFX_LOG_DEBUG
	IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#endif
	int nCount = 0, nIndex = 0, /* q_cpeId=0, */ q_IfType = 0;
	int ret = IFX_SUCCESS, classify_count = 0;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 sCommand[MAX_FILELINE_LEN], *retVal = NULL;;
	char8 sBuf[MAX_FILELINE_LEN];
	IFX_MAPI_QoS_Classifier *t_ptr = NULL;
	/* IP_MASK *ipmask; PORT_RANGE *ip_port; */
	// uint32 num_qinst=0;
	// IFX_MAPI_QoS_Queue *q_ptr = NULL;

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));

	/* Get the queue structure and number of queue instances for wan interface
	   passed */

	/* if((ret =
	   ifx_mapi_get_all_qos_queue_if_specific(IFX_MAPI_QoS_Interface_Type
	   qIfType, (uint32 *)&num_qinst, *q_ptr, flags)) != IFX_SUCCESS){

	   IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__); goto IFX_Handler;

	   } */

	/* get the number of classification entries from rc.conf */
	MAKE_SECTION_COUNT_TAG(TAG_IPQOS_DS_CLASSIFY, sCommand);

	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_DS_CLASSIFY,
				  sCommand, flags, &outFlag,
				  sBuf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#endif
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	nCount = atoi(sBuf);

#ifdef IFX_LOG_DEBUG
	IFX_API_LOG("[%s:%d] nCount=%d ", __FUNCTION__, __LINE__, nCount);
#endif

/* Manamohan: 10,June 2011 , range check as per Klocwork report */
	if ((nCount < 0) || (nCount > 0xFFFFFFFF))
		return IFX_FAILURE;

	if (nCount == 0) {
		*numEntries = 0;
		*qos_classify = NULL;
		goto IFX_Handler;
	}

	*qos_classify = NULL;

	t_ptr =
	    (IFX_MAPI_QoS_Classifier *) IFX_MALLOC(nCount *
						   sizeof
						   (IFX_MAPI_QoS_Classifier));
	if (t_ptr == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	*qos_classify = t_ptr;

	for (nIndex = 0; nIndex < nCount; nIndex++) {

		NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
		/* find IfType of classifier instance */
		sprintf(sCommand, "%s_%d_ifType", PREFIX_IPQOS_DS_CLASSIFY,
			nIndex);

		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_DS_CLASSIFY,
					  sCommand, flags, &outFlag,
					  sBuf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		q_IfType = atoi(sBuf);

		NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
		/* If Passed interface type matches the interface type of queue and
		   also matches classifiers q_Id, get this instance of classifier */

		if (q_IfType == qIfType) {
#ifdef IFX_LOG_DEBUG
			IFX_API_LOG("[%s:%d] Classifier MATCHED index=%d",
				    __FUNCTION__, __LINE__, nIndex);
#endif

			classify_count++;
		}
		IFX_MEM_FREE(retVal)
	}			/* for loop */

	*numEntries = classify_count;

      IFX_Handler:
	IFX_MEM_FREE(retVal)
	    if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*qos_classify)
		    * numEntries = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}

	else

		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_get_all_qos_classifier_if_specific(...
* 	qIfType ==> Input WAN interface for which classifiers are required)
*       num_entries ==>  outut number of classifier entries
*       qos_classify   ==>  output pointer to an array of classify entries
		in rc.conf
*   	flags       ==> flags that define behaviour of get
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
        Description:
        This Function  takes the input interface and reads the classifier configuration in rc.conf file,
          and stores each classifier entry into the classify struct.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_mapi_get_all_qos_classifier_if_specific(IFX_MAPI_QoS_Interface_Type
						  qIfType, uint32 * numEntries,
						  IFX_MAPI_QoS_Classifier **
						  qos_classify, uint32 flags)
{

#ifdef IFX_LOG_DEBUG
	IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#endif
	/* int nCount = 0, nIndex = 0, cl_qId = 0, q_IfType = 0; */
	int nCount = 0, nIndex = 0, q_IfType = 0;
	int ret = IFX_SUCCESS, classify_count = 0;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 sCommand[MAX_FILELINE_LEN], *retVal = NULL;;
	char8 sBuf[MAX_FILELINE_LEN];
	IFX_MAPI_QoS_Classifier *t_ptr = NULL;
	/*IP_MASK *ipmask;
	   PORT_RANGE *ip_port; */
	//uint32 num_qinst=0;
	//IFX_MAPI_QoS_Queue *q_ptr = NULL;

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));

	/* Get the queue structure and number of queue instances for wan interface passed */

	/*if((ret = ifx_mapi_get_all_qos_queue_if_specific(IFX_MAPI_QoS_Interface_Type qIfType,
	   (uint32 *)&num_qinst, *q_ptr, flags)) != IFX_SUCCESS){

	   IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	   goto IFX_Handler;

	   }
	 */

	/* get the number of classification entries from rc.conf */
	MAKE_SECTION_COUNT_TAG(TAG_IPQOS_CLASSIFY, sCommand);

	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_CLASSIFY,
				  sCommand, flags, &outFlag,
				  sBuf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#endif
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	nCount = atoi(sBuf);

#ifdef IFX_LOG_DEBUG
	IFX_API_LOG("[%s:%d] nCount=%d ", __FUNCTION__, __LINE__, nCount);
#endif

/* Manamohan: 10,June 2011 , range check as per Klocwork report */
	if ((nCount < 0) || (nCount > 0xFFFFFFFF))
		return IFX_FAILURE;

	if (nCount == 0) {
		*numEntries = 0;
		*qos_classify = NULL;
		goto IFX_Handler;
	}

	*qos_classify = NULL;

	t_ptr =
	    (IFX_MAPI_QoS_Classifier *) IFX_MALLOC(nCount *
						   sizeof
						   (IFX_MAPI_QoS_Classifier));
	if (t_ptr == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	*qos_classify = t_ptr;

	for (nIndex = 0; nIndex < nCount; nIndex++) {

		NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
		/*find qId of classifier instance */
		sprintf(sCommand, "%s_%d_qId", PREFIX_IPQOS_CLASSIFY, nIndex);

		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_CLASSIFY,
					  sCommand, flags, &outFlag,
					  sBuf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		//cl_qId = atoi(sBuf);

		//for (qInst=0; qInst < num_qinst; qInst++)//

		/*find cpeId of queue instance for passed interface */
		/*      NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
		   sprintf(sCommand, "%s_%d_cpeId", PREFIX_IPQOS_QUEUE, qInst);

		   if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QUEUE,
		   sCommand, flags, &outFlag, sBuf)) != IFX_SUCCESS)//

		   IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		   goto IFX_Handler;
		   //
		   q_cpeId = atoi(sBuf);

		   if (q_cpeId == cl_qId)//
		   //
		 */
		/* Find Queue instance for the interface passed */
		//manohar start

		if ((ret =
		     ifx_ret_substr_from_distfield(FILE_RC_CONF,
						   TAG_IPQOS_QUEUE, "cpeId",
						   sBuf,
						   &retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("\n\nIn Function [%s] : cpeId [%s] !!\n\n",
				__FUNCTION__, sBuf);
#endif
			IFX_MEM_FREE(retVal)
			    return -1;
		}
		//manohar end

		NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));

		/*find the qIfType of instance */
//              sprintf(sCommand, "%s_%d_qIfType", PREFIX_IPQOS_QUEUE, cl_qId-1);
		sprintf(sCommand, "%s_qIfType", retVal);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QUEUE,
					  sCommand, flags, &outFlag,
					  sBuf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		q_IfType = atoi(sBuf);

		/*If Passed interface type matches the interface type of queue and also matches classifiers
		 * q_Id, get this instance of classifier*/

		if (q_IfType == qIfType) {
#ifdef IFX_LOG_DEBUG
			IFX_API_LOG("[%s:%d] MATCHED index=%d", __FUNCTION__,
				    __LINE__, nIndex);
#endif

#if 0
			/*get cpeid of queue instance */
			NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
			//              sprintf(sCommand, "%s_%d_cpeId", PREFIX_IPQOS_QUEUE,cl_qId-1);
			sprintf(sCommand, "%s_cpeId", retVal);
			if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QUEUE,
						  sCommand, flags, &outFlag,
						  sBuf)) != IFX_SUCCESS) {

				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
				goto IFX_Handler;
			}

			q_cpeId = atoi(sBuf);

			/* if queue instance's cpeId matches classifiers q_Id, get that classifier instacne into struct */
			if (q_cpeId == cl_qId)
#endif
			{
				NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
				sprintf(sCommand, "%s_%d_cpeId",
					PREFIX_IPQOS_CLASSIFY, nIndex);
				if ((ret =
				     ifx_GetObjData(FILE_RC_CONF,
						    TAG_IPQOS_CLASSIFY,
						    sCommand, flags, &outFlag,
						    sBuf)) != IFX_SUCCESS) {
					goto IFX_Handler;
				}

				(*qos_classify + classify_count)->iid.cpeId.Id =
				    atoi(sBuf);

				if ((ret =
				     ifx_mapi_get_qos_classifier((*qos_classify
								  +
								  classify_count),
								 flags) !=
				     IFX_SUCCESS)) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d]", __FUNCTION__,
						__LINE__);
#endif
					goto IFX_Handler;
				}

				classify_count++;
			}
		}
/* Manamohan:10 Jun 2010, Memory leak fix */
		IFX_MEM_FREE(retVal)
	}			/*for loop */

	*numEntries = classify_count;

      IFX_Handler:
	IFX_MEM_FREE(retVal)
	    if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*qos_classify)
		    * numEntries = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}

	else

		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_get_all_qos_ds_classifier_if_specific(...
* 	qIfType ==> Input WAN interface for which classifiers are required)
*       num_entries ==>  outut number of classifier entries
*       qos_classify   ==>  output pointer to an array of classify entries
		in rc.conf
*   	flags       ==> flags that define behaviour of get
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
        Description:
        This Function  takes the input interface and reads the classifier configuration in rc.conf file,
          and stores each classifier entry into the classify struct.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_mapi_get_all_qos_ds_classifier_if_specific(IFX_MAPI_QoS_Interface_Type
						  qIfType, uint32 * numEntries,
						  IFX_MAPI_QoS_Classifier **
						  qos_classify, uint32 flags)
{

#ifdef IFX_LOG_DEBUG
	IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#endif
	/* int nCount = 0, nIndex = 0, cl_qId = 0, q_IfType = 0; */
	int nCount = 0, nIndex = 0, q_IfType = 0;
	int ret = IFX_SUCCESS, classify_count = 0;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 sCommand[MAX_FILELINE_LEN], *retVal = NULL;;
	char8 sBuf[MAX_FILELINE_LEN];
	IFX_MAPI_QoS_Classifier *t_ptr = NULL;
	/*IP_MASK *ipmask;
	   PORT_RANGE *ip_port; */
	//uint32 num_qinst=0;
	//IFX_MAPI_QoS_Queue *q_ptr = NULL;

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));

	/* Get the queue structure and number of queue instances for wan interface passed */

	/*if((ret = ifx_mapi_get_all_qos_queue_if_specific(IFX_MAPI_QoS_Interface_Type qIfType,
	   (uint32 *)&num_qinst, *q_ptr, flags)) != IFX_SUCCESS){

	   IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	   goto IFX_Handler;

	   }
	 */

	/* get the number of classification entries from rc.conf */
	MAKE_SECTION_COUNT_TAG(TAG_IPQOS_DS_CLASSIFY, sCommand);

	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_DS_CLASSIFY,
				  sCommand, flags, &outFlag,
				  sBuf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d] ", __FUNCTION__, __LINE__);
#endif
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	nCount = atoi(sBuf);

#ifdef IFX_LOG_DEBUG
	IFX_API_LOG("[%s:%d] nCount=%d ", __FUNCTION__, __LINE__, nCount);
#endif

/* Manamohan: 10,June 2011 , range check as per Klocwork report */
	if ((nCount < 0) || (nCount > 0xFFFFFFFF))
		return IFX_FAILURE;

	if (nCount == 0) {
		*numEntries = 0;
		*qos_classify = NULL;
		goto IFX_Handler;
	}

	*qos_classify = NULL;

	t_ptr =
	    (IFX_MAPI_QoS_Classifier *) IFX_MALLOC(nCount *
						   sizeof
						   (IFX_MAPI_QoS_Classifier));
	if (t_ptr == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	*qos_classify = t_ptr;

	for (nIndex = 0; nIndex < nCount; nIndex++) {

		NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
		/*find qId of classifier instance */
		sprintf(sCommand, "%s_%d_qId", PREFIX_IPQOS_DS_CLASSIFY, nIndex);

		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_DS_CLASSIFY,
					  sCommand, flags, &outFlag,
					  sBuf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		//cl_qId = atoi(sBuf);

		//for (qInst=0; qInst < num_qinst; qInst++)//

		/*find cpeId of queue instance for passed interface */
		/*      NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
		   sprintf(sCommand, "%s_%d_cpeId", PREFIX_IPQOS_QUEUE, qInst);

		   if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QUEUE,
		   sCommand, flags, &outFlag, sBuf)) != IFX_SUCCESS)//

		   IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		   goto IFX_Handler;
		   //
		   q_cpeId = atoi(sBuf);

		   if (q_cpeId == cl_qId)//
		   //
		 */
		/* Find Queue instance for the interface passed */
		//manohar start

		if ((ret =
		     ifx_ret_substr_from_distfield(FILE_RC_CONF,
						   TAG_IPQOS_QUEUE, "cpeId",
						   sBuf,
						   &retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("\n\nIn Function [%s] : cpeId [%s] !!\n\n",
				__FUNCTION__, sBuf);
#endif
			IFX_MEM_FREE(retVal)
			    return -1;
		}
		//manohar end

		NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));

		/*find the qIfType of instance */
//              sprintf(sCommand, "%s_%d_qIfType", PREFIX_IPQOS_QUEUE, cl_qId-1);
		sprintf(sCommand, "%s_qIfType", retVal);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QUEUE,
					  sCommand, flags, &outFlag,
					  sBuf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		q_IfType = atoi(sBuf);

		/*If Passed interface type matches the interface type of queue and also matches classifiers
		 * q_Id, get this instance of classifier*/

		if (q_IfType == qIfType) {
#ifdef IFX_LOG_DEBUG
			IFX_API_LOG("[%s:%d] MATCHED index=%d", __FUNCTION__,
				    __LINE__, nIndex);
#endif

#if 0
			/*get cpeid of queue instance */
			NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
			//              sprintf(sCommand, "%s_%d_cpeId", PREFIX_IPQOS_QUEUE,cl_qId-1);
			sprintf(sCommand, "%s_cpeId", retVal);
			if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QUEUE,
						  sCommand, flags, &outFlag,
						  sBuf)) != IFX_SUCCESS) {

				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
				goto IFX_Handler;
			}

			q_cpeId = atoi(sBuf);

			/* if queue instance's cpeId matches classifiers q_Id, get that classifier instacne into struct */
			if (q_cpeId == cl_qId)
#endif
			{
				NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
				sprintf(sCommand, "%s_%d_cpeId",
					PREFIX_IPQOS_DS_CLASSIFY, nIndex);
				if ((ret =
				     ifx_GetObjData(FILE_RC_CONF,
						    TAG_IPQOS_DS_CLASSIFY,
						    sCommand, flags, &outFlag,
						    sBuf)) != IFX_SUCCESS) {
					goto IFX_Handler;
				}

				(*qos_classify + classify_count)->iid.cpeId.Id =
				    atoi(sBuf);

				if ((ret =
				     ifx_mapi_get_qos_ds_classifier((*qos_classify
								  +
								  classify_count),
								 flags) !=
				     IFX_SUCCESS)) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d]", __FUNCTION__,
						__LINE__);
#endif
					goto IFX_Handler;
				}

				classify_count++;
			}
		}
/* Manamohan:10 Jun 2010, Memory leak fix */
		IFX_MEM_FREE(retVal)
	}			/*for loop */

	*numEntries = classify_count;

      IFX_Handler:
	IFX_MEM_FREE(retVal)
	    if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*qos_classify)
		    * numEntries = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}

	else

		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_get_all_qos_queue_if_specific(...
* 	qIfType ==> Input WAN interface for which queue entries are required)
*       num_entries ==>  outut number of queue entries
*       qos_queue   ==>  output pointer to an array of queue entries
		in rc.conf
*   	flags       ==> flags that define behaviour of get
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
        Description:
        This Function  takes the input interface and reads the queue entries in rc.conf
          and stores each queue entry into the queue struct.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_mapi_get_all_qos_queue_if_specific(IFX_MAPI_QoS_Interface_Type
					     qIfType, uint32 * numEntries,
					     IFX_MAPI_QoS_Queue ** qos_queue,
					     uint32 flags)
{

	int nCount = 0, nIndex = 0, q_IfType = 4;
	int ret = IFX_SUCCESS, queue_count = 0;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 sCommand[MAX_FILELINE_LEN];
	char8 sBuf[MAX_FILELINE_LEN];

	IFX_MAPI_QoS_Queue *t_ptr = NULL;
	//WAN_PHY_CFG pstWanPhy;

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));

	/* first, get the number of queues entries from rc.conf */
	MAKE_SECTION_COUNT_TAG(TAG_IPQOS_QUEUE, sCommand);

	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QUEUE,
				  sCommand, flags, &outFlag,
				  sBuf)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}

	nCount = atoi(sBuf);

/* Manamohan: 10,June 2011 , range check as per Klocwork report */
	if ((nCount < 0) || (nCount > 0xFFFFFFFF))
		return IFX_FAILURE;

	if (nCount == 0) {
		*numEntries = 0;
		*qos_queue = NULL;
		goto IFX_Handler;
	}

	*qos_queue = NULL;
	t_ptr =
	    (IFX_MAPI_QoS_Queue *) IFX_MALLOC(nCount *
					      sizeof(IFX_MAPI_QoS_Queue));
	if (t_ptr == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	*qos_queue = t_ptr;

	for (nIndex = 0; nIndex < nCount; nIndex++) {

		NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));

		/*find the qIfType of instance */
		sprintf(sCommand, "%s_%d_qIfType", PREFIX_IPQOS_QUEUE, nIndex);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QUEUE,
					  sCommand, flags, &outFlag,
					  sBuf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		/*If Passed interface type matches the interface type of queue, get this instance of queue */
		q_IfType = atoi(sBuf);

		if (q_IfType == qIfType) {

			NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
			sprintf(sCommand, "%s_%d_cpeId", PREFIX_IPQOS_QUEUE,
				nIndex);
			if ((ret =
			     ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QUEUE,
					    sCommand, flags, &outFlag,
					    sBuf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}

			(*qos_queue + queue_count)->iid.cpeId.Id = atoi(sBuf);

			if ((ret =
			     ifx_mapi_get_qos_queue((*qos_queue + queue_count),
						    flags) != IFX_SUCCESS)) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}
			/*update q count for matching iterface type */
			queue_count++;
		}
		//queue_count++;
	}			/*for loop */

	/*number of queue entires with interface type as asked by user */
	*numEntries = queue_count;

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*qos_queue)
		    * numEntries = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else

		return IFX_SUCCESS;
}

int32
ifx_mapi_get_classifier_count_for_class_If(IFX_MAPI_QoS_Interface_Type qIfType)
{
	int32 count = 0;
	IFX_MAPI_QoS_Classifier *qos_class = NULL;

	if (ifx_mapi_get_all_qos_classifier_class_if_specific
	    (qIfType, (uint32 *) & count, &qos_class,
	     IFX_F_DEFAULT) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("[%s:%d] Failed to display configured classes for interface %d",
		     __FUNCTION__, __LINE__, qIfType);
#endif
	}
#ifdef IFX_LOG_DEBUG
	IFX_API_LOG("[%s:%d] count = %d", __FUNCTION__, __LINE__, count);
#endif
	IFX_MEM_FREE(qos_class);
	return count;
}

int32
ifx_mapi_get_ds_classifier_count_for_class_If(IFX_MAPI_QoS_Interface_Type qIfType)
{
	int32 count = 0;
	IFX_MAPI_QoS_Classifier *qos_class = NULL;

	if (ifx_mapi_get_all_qos_ds_classifier_class_if_specific
	    (qIfType, (uint32 *) & count, &qos_class,
	     IFX_F_DEFAULT) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("[%s:%d] Failed to display configured classes for interface %d",
		     __FUNCTION__, __LINE__, qIfType);
#endif
	}
#ifdef IFX_LOG_DEBUG
	IFX_API_LOG("[%s:%d] count = %d", __FUNCTION__, __LINE__, count);
#endif
	IFX_MEM_FREE(qos_class);
	return count;
}

int32 ifx_mapi_get_classifier_count_for_wan_mode(IFX_MAPI_QoS_Interface_Type
						 qIfType)
{
	int32 count = 0;
	IFX_MAPI_QoS_Classifier *qos_class = NULL;

	if (ifx_mapi_get_all_qos_classifier_if_specific
	    (qIfType, (uint32 *) & count, &qos_class,
	     IFX_F_DEFAULT) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("[%s:%d] Failed to display configured classes for interface %d",
		     __FUNCTION__, __LINE__, qIfType);
#endif
	}
#ifdef IFX_LOG_DEBUG
	IFX_API_LOG("[%s:%d] count = %d", __FUNCTION__, __LINE__, count);
#endif
	IFX_MEM_FREE(qos_class);
	return count;
}

int32 ifx_mapi_get_ds_classifier_count_for_wan_mode(IFX_MAPI_QoS_Interface_Type
						 qIfType)
{
	int32 count = 0;
	IFX_MAPI_QoS_Classifier *qos_class = NULL;

	if (ifx_mapi_get_all_qos_ds_classifier_if_specific
	    (qIfType, (uint32 *) & count, &qos_class,
	     IFX_F_DEFAULT) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("[%s:%d] Failed to display configured classes for interface %d",
		     __FUNCTION__, __LINE__, qIfType);
#endif
	}
#ifdef IFX_LOG_DEBUG
	IFX_API_LOG("[%s:%d] count = %d", __FUNCTION__, __LINE__, count);
#endif
	IFX_MEM_FREE(qos_class);
	return count;
}

int32 ifx_mapi_get_classifier_mfc_count_for_wan_mode(IFX_MAPI_QoS_Interface_Type
						     qIfType)
{
	int32 i = 0, count = 0, mfc_count = 0;
	IFX_MAPI_QoS_Classifier *qos_class = NULL;

	if (ifx_mapi_get_all_qos_classifier_if_specific
	    (qIfType, (uint32 *) & count, &qos_class,
	     IFX_F_DEFAULT) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("[%s:%d] Failed to display configured classes for interface %d",
		     __FUNCTION__, __LINE__, qIfType);
#endif
	   IFX_MEM_FREE(qos_class);
      return IFX_FAILURE;
	}
#ifdef IFX_LOG_DEBUG
	IFX_API_LOG("[%s:%d] count = %d", __FUNCTION__, __LINE__, count);
#endif
	for (i = 0; i < count; i++) {
		if (qos_class[i].mfClass == IFX_MAPI_QoS_Multi_Field) {
			mfc_count++;
		}
	}
	IFX_MEM_FREE(qos_class);
#ifdef IFX_LOG_DEBUG
	IFX_API_LOG("[%s:%d] mfc_count = %d", __FUNCTION__, __LINE__,
		    mfc_count);
#endif
	return mfc_count;
}


int32 ifx_mapi_get_ds_classifier_mfc_count_for_wan_mode(IFX_MAPI_QoS_Interface_Type
						     qIfType)
{
	int32 i = 0, count = 0, mfc_count = 0;
	IFX_MAPI_QoS_Classifier *qos_class = NULL;

	if (ifx_mapi_get_all_qos_ds_classifier_if_specific
	    (qIfType, (uint32 *) & count, &qos_class,
	     IFX_F_DEFAULT) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("[%s:%d] Failed to display configured classes for interface %d",
		     __FUNCTION__, __LINE__, qIfType);
#endif
	   IFX_MEM_FREE(qos_class);
      return IFX_FAILURE;
	}
#ifdef IFX_LOG_DEBUG
	IFX_API_LOG("[%s:%d] count = %d", __FUNCTION__, __LINE__, count);
#endif
	for (i = 0; i < count; i++) {
		if (qos_class[i].mfClass == IFX_MAPI_QoS_Multi_Field) {
			mfc_count++;
		}
	}
	IFX_MEM_FREE(qos_class);
#ifdef IFX_LOG_DEBUG
	IFX_API_LOG("[%s:%d] mfc_count = %d", __FUNCTION__, __LINE__,
		    mfc_count);
#endif
	return mfc_count;
}

int32 ifx_mapi_get_queue_count_for_wan_mode(IFX_MAPI_QoS_Interface_Type qIfType)
{
	int32 count = 0;
	IFX_MAPI_QoS_Queue *qos_queue = NULL;

	if (ifx_mapi_get_all_qos_queue_if_specific
	    (qIfType, (uint32 *) & count, &qos_queue,
	     IFX_F_DEFAULT) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("[%s:%d] Failed to display configured queues for interface %d",
		     __FUNCTION__, __LINE__, qIfType);
#endif
	}
	IFX_MEM_FREE(qos_queue);
	return count;
}

int32 ifx_get_wan_conn_count_for_ifType(int32 * count,
					IFX_MAPI_QoS_Interface_Type qIfType)
{
	uint32 flags = IFX_F_GET_ANY, outFlag = IFX_F_DEFAULT;
	char8 buf[MAX_FILELINE_LEN], sIndexes[MAX_FILELINE_LEN],
	    sValue[MAX_FILELINE_LEN];
	int32 match_count = 0, ret = IFX_SUCCESS, idx_count = 0, *idx_array =
	    NULL, i = 0;

	sprintf(buf, "%s", "wan_main_index");
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, &outFlag,
			    sIndexes)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	get_wan_indices(sIndexes, &idx_count, &idx_array);

	for (i = 0; i < idx_count; i++) {
		sprintf(buf, "%s_%d_wanMode", PREFIX_WAN_MAIN,
			*(idx_array + i));
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags,
				    &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		if (qIfType == IFX_MAPI_QoS_WAN_ATM && !strcmp(sValue, "0"))
			match_count++;
		else if (qIfType == IFX_MAPI_QoS_WAN_ETH_0
			 && !strcmp(sValue, "1"))
			match_count++;
		else if (qIfType == IFX_MAPI_QoS_WAN_ETH_1
			 && !strcmp(sValue, "2"))
			match_count++;
		else if (qIfType == IFX_MAPI_QoS_WAN_PTM
			 && !strcmp(sValue, "3"))
			match_count++;
	}

      IFX_Handler:
	*count = match_count;
	IFX_MEM_FREE(idx_array)
	    return ret;
}

int32 ifx_mapi_get_queue_add_check(IFX_MAPI_QoS_Interface_Type qIfType)
{
	int32 count = 0;
	int ret = IFX_SUCCESS, num = 0;
	IFX_MAPI_QoS_Queue *qos_queue = NULL;
	WAN_PHY_CFG pstWanPhy;
	WAN_CONN_CFG *wan_cfg = NULL;
	char sLine[256];

	memset(&qos_queue, 0x00, sizeof(qos_queue));
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	ifx_get_wan_phy_cfg(&pstWanPhy);
	if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2
	    && pstWanPhy.wan_tc == WAN_TC_ATM) {
		if (ifx_get_wan_conn_count_for_ifType(&num, qIfType) !=
		    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Failed to display configured vcc ",
				__FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}

		ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_atmQmode",
			       IFX_F_GET_ENA, 0, sLine);
		if (atoi(sLine) == IFX_MAPI_QoS_ATM_PVC_BASED) {

			if (ifx_mapi_get_all_qos_queue_if_specific
			    (qIfType, (uint32 *) & count, &qos_queue,
			     IFX_F_DEFAULT) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("[%s:%d] Failed to display configured queues for interface ",
				     __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		} else {
			count = 1;
		}
#if defined PLATFORM_DANUBE
		if (count + num <= 8) {
			/* Manamohan: 10,June 2011, Memory leak fix */
			IFX_MEM_FREE(qos_queue);
			return IFX_SUCCESS;
		} else {
			ret = IFX_FAILURE;
		}
#elif defined PLATFORM_AR9
		if (count + num <= 15) {
			/* Manamohan: 10,June 2011, Memory leak fix */
			IFX_MEM_FREE(qos_queue);
			return IFX_SUCCESS;
		} else {
			ret = IFX_FAILURE;
		}
#elif defined PLATFORM_AMAZON_SE
		if (count + num <= 8) {
			/* Manamohan: 10,June 2011, Memory leak fix */
			IFX_MEM_FREE(qos_queue);
			return IFX_SUCCESS;
		} else {
			ret = IFX_FAILURE;
		}
#elif defined PLATFORM_VR9
		if (count + num <= 15) {
			/* Manamohan: 10,June 2011, Memory leak fix */
			IFX_MEM_FREE(qos_queue);
			return IFX_SUCCESS;
		} else {
			ret = IFX_FAILURE;
		}
#endif
	}

      IFX_Handler:
	IFX_MEM_FREE(wan_cfg);
	IFX_MEM_FREE(qos_queue);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

IFX_MAPI_QoS_Interface_Type ifx_mapi_get_active_qos_iface()
{
	WAN_PHY_CFG sWanPhy;
	IFX_MAPI_QoS_Interface_Type iIfType = IFX_MAPI_QoS_ALL;
	if (ifx_get_wan_phy_cfg(&sWanPhy) != IFX_SUCCESS) {
		IFX_API_LOG
		    ("[%s:%d] : Unable to get the Active WAN Mode. QoS interface will be incorrect",
		     __FUNCTION__, __LINE__);
		goto cleanup;
	}
	if ((sWanPhy.phy_mode == WAN_PHY_MODE_ADSL2)
	    || ((sWanPhy.phy_mode == WAN_PHY_MODE_VDSL2))) {
		if (sWanPhy.wan_tc == WAN_TC_ATM) {
			iIfType = IFX_MAPI_QoS_WAN_ATM;
		}
		if (sWanPhy.wan_tc == WAN_TC_PTM) {
			iIfType = IFX_MAPI_QoS_WAN_PTM;
		}
	}
	if (sWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII0)
		iIfType = IFX_MAPI_QoS_WAN_ETH_0;
	if (sWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII1)
		iIfType = IFX_MAPI_QoS_WAN_ETH_1;
      cleanup:
#ifdef IFX_LOG_DEBUG
	IFX_API_LOG("[%s:%d] : Active qos iface = %d", __FUNCTION__, __LINE__,
		    iIfType);
#endif
	return iIfType;
}

int32 ifx_mapi_get_default_queue_cpeid(IFX_MAPI_QoS_Interface_Type mode)
{
	if (mode == IFX_MAPI_QoS_WAN_ATM) {
		return 9;
	} else if (mode == IFX_MAPI_QoS_WAN_ETH_0) {
		return 10;
	} else if (mode == IFX_MAPI_QoS_WAN_ETH_1) {
		return 11;
	}
	/*else                        // IFX_MAPI_QoS_WAN_PTM
	{
		return 12;
	}
	 */
	else if (mode == IFX_MAPI_QoS_WAN_PTM) {	// IFX_MAPI_QoS_WAN_PTM
		return 12;
	}
	//downstream default queue
	else if (mode == IFX_MAPI_QoS_LAN_ATM) {

		return 13;
	}
	else if (mode == IFX_MAPI_QoS_LAN_PTM) {	
		return 13;
	}
	else if (mode == IFX_MAPI_QoS_LAN_ETH_0) {	
		return 13;
	}
	else if (mode == IFX_MAPI_QoS_LAN_ETH_1) {	
		return 13;
	}
	IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
	return IFX_FAILURE;
}

IFX_MAPI_QoS_Interface_Type ifx_mapi_get_class_iface(char8 * cpeid)
{
	char8 sCommand[MAX_FILELINE_LEN], sBuf[MAX_FILELINE_LEN], *retVal =
	    NULL;
	uint32 outFlag = IFX_F_DEFAULT, flags = IFX_F_DEFAULT;
	int ret = IFX_SUCCESS;
	IFX_MAPI_QoS_Interface_Type ifType;
	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));

	if ((ret =
	     ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_IPQOS_CLASSIFY,
					   "cpeId", cpeid,
					   &retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\nIn Function [%s] : cpeId [%s] !!\n\n",
			__FUNCTION__, retVal);
#endif
		IFX_MEM_FREE(retVal)
		    return -1;
	}
	sprintf(sCommand, "%s_qId", retVal);
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_CLASSIFY, sCommand, flags,
			    &outFlag, sBuf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		/* Manamohan: 10,June 2011, Memory leak fix */
		IFX_MEM_FREE(retVal)
		    return -1;
	}
	IFX_API_LOG("[%s:%d] cl_qId=%d", __FUNCTION__, __LINE__, atoi(sBuf));
/*Manamohan: Klocwork updates,7March 2012  */
	IFX_MEM_FREE(retVal)
	if ((ret =
	     ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_IPQOS_QUEUE,
					   "cpeId", sBuf,
					   &retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\nIn Function [%s] : cpeId [%s] !!\n\n",
			__FUNCTION__, sBuf);
#endif
		IFX_MEM_FREE(retVal)
		    return -1;
	}
	sprintf(sCommand, "%s_qIfType", retVal);
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QUEUE, sCommand, flags,
			    &outFlag, sBuf)) != IFX_SUCCESS) {

#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		/*Manamohan: Klocwork updates,7March 2012  */
		IFX_MEM_FREE(retVal)
		return -1;
	}
	ifType = atoi(sBuf);
/*Manamohan: Klocwork updates,7March 2012  */
	IFX_MEM_FREE(retVal)
	return ifType;
}

IFX_MAPI_QoS_Interface_Type ifx_mapi_get_ds_class_iface(char8 * cpeid)
{
	char8 sCommand[MAX_FILELINE_LEN], sBuf[MAX_FILELINE_LEN], *retVal =
	    NULL;
	uint32 outFlag = IFX_F_DEFAULT, flags = IFX_F_DEFAULT;
	int ret = IFX_SUCCESS;
	IFX_MAPI_QoS_Interface_Type ifType;
	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));

	if ((ret =
	     ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_IPQOS_DS_CLASSIFY,
					   "cpeId", cpeid,
					   &retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\nIn Function [%s] : cpeId [%s] !!\n\n",
			__FUNCTION__, retVal);
#endif
		IFX_MEM_FREE(retVal)
		    return -1;
	}
	sprintf(sCommand, "%s_qId", retVal);
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_DS_CLASSIFY, sCommand, flags,
			    &outFlag, sBuf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		/* Manamohan: 10,June 2011, Memory leak fix */
		IFX_MEM_FREE(retVal)
		    return -1;
	}
	IFX_API_LOG("[%s:%d] cl_qId=%d", __FUNCTION__, __LINE__, atoi(sBuf));
/*Manamohan: Klocwork updates,7March 2012  */
	IFX_MEM_FREE(retVal)
	if ((ret =
	     ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_IPQOS_QUEUE,
					   "cpeId", sBuf,
					   &retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\nIn Function [%s] : cpeId [%s] !!\n\n",
			__FUNCTION__, sBuf);
#endif
		IFX_MEM_FREE(retVal)
		    return -1;
	}
	sprintf(sCommand, "%s_qIfType", retVal);
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QUEUE, sCommand, flags,
			    &outFlag, sBuf)) != IFX_SUCCESS) {

#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		/*Manamohan: Klocwork updates,7March 2012  */
		IFX_MEM_FREE(retVal)
		return -1;
	}
	ifType = atoi(sBuf);
/*Manamohan: Klocwork updates,7March 2012  */
	IFX_MEM_FREE(retVal)
	return ifType;
}

int32 ifx_check_unique_fvp_for_qos_iface(IFX_MAPI_QoS_Interface_Type mode,
					 char8 * fName, char8 * fValue,
					 char8 * fRetName, char8 * fRetValue,
					 uint32 flags)
{
	int32 count = 0, i = 0;
	IFX_MAPI_QoS_Queue *qos_queue = NULL;

	if (ifx_mapi_get_all_qos_queue_if_specific
	    (mode, (uint32 *) & count, &qos_queue,
	     IFX_F_DEFAULT) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("[%s:%d] Failed to display configured queues for interface %d",
		     __FUNCTION__, __LINE__, mode);
#endif
	   IFX_MEM_FREE(qos_queue);
      return IFX_FAILURE;
	}
	for (i = 0; i < count; i++) {
		if (!strcmp(fName, "qName")) {
			if ((qos_queue + i)->qIfType == mode
			    && !strcmp((qos_queue + i)->qName, fValue)) {
/*
               sprintf(sBuf, "qq_%d_%s",i, fRetName);
               IFX_API_LOG("[%s:%d]sBuf=%s : qNme matched!", __FUNCTION__,__LINE__,sBuf);
               NULL_TERMINATE(fRetValue, 0x00, sizeof(fRetValue));
               if (ifx_GetObjData(FILE_RC_CONF,TAG_IPQOS_QUEUE, sBuf,IFX_F_GET_ANY, &outflag, fRetValue) != IFX_SUCCESS)
  	           {
                  IFX_MEM_FREE(qos_queue);
                  IFX_API_LOG("[%s:%d] : returned failure retvalue=%s!", __FUNCTION__,__LINE__,fRetValue);
                  return IFX_FAILURE;
               }
*/
				if (!strcmp(fRetName, "cpeId")) {
					sprintf(fRetValue, "%d",
						(qos_queue + i)->iid.cpeId.Id);
					break;
				}
			}
		} else if (!strcmp(fName, "qPrio")) {
			if ((qos_queue + i)->qIfType == mode
			    && (qos_queue + i)->qPrio == atoi(fValue)) {
/*
               sprintf(sBuf, "qq_%d_%s",i, fRetName);
               IFX_API_LOG("[%s:%d]sBuf=%s : qPrio matched!", __FUNCTION__,__LINE__,sBuf);
               NULL_TERMINATE(fRetValue, 0x00, sizeof(fRetValue));
               if (ifx_GetObjData(FILE_RC_CONF,TAG_IPQOS_QUEUE, sBuf,IFX_F_GET_ANY, &outflag, fRetValue) != IFX_SUCCESS)
  	           {
                  IFX_MEM_FREE(qos_queue);
                  IFX_API_LOG("[%s:%d] : returned failure retvalue=%s!", __FUNCTION__,__LINE__,fRetValue);
                  return IFX_FAILURE;
               }
*/
				if (!strcmp(fRetName, "cpeId")) {
					sprintf(fRetValue, "%d",
						(qos_queue + i)->iid.cpeId.Id);
					break;
				}
			}
		}
	}
	IFX_MEM_FREE(qos_queue);
	IFX_API_LOG("[%s:%d] : returned success retvalue=%s!", __FUNCTION__,
		    __LINE__, fRetValue);
	return IFX_SUCCESS;
}

int32 ifx_check_unique_fvp_for_qos_class(IFX_MAPI_QoS_Interface_Type mode,
					 char8 * fName, char8 * fValue,
					 char8 * fRetName, char8 * fRetValue,
					 uint32 flags)
{
	int32 count = 0, i = 0;
	char8 sBuf[MAX_FILELINE_LEN];
	IFX_MAPI_QoS_Classifier *qos_class = NULL;

	if (ifx_mapi_get_all_qos_classifier_if_specific
	    (mode, (uint32 *) & count, &qos_class,
	     IFX_F_DEFAULT) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("[%s:%d] Failed to display configured queues for interface %d",
		     __FUNCTION__, __LINE__, mode);
#endif
	   IFX_MEM_FREE(qos_class);
      return IFX_FAILURE;
	}

	for (i = 0; i < count; i++) {
		sprintf(sBuf, "%d", (qos_class + i)->iid.cpeId.Id);
		if (mode == ifx_mapi_get_class_iface(sBuf)) {
			if (!strcmp(fName, "className")
			    && !strcmp((qos_class + i)->classifierName,
				       fValue)) {
				if (!strcmp(fRetName, "cpeId")) {
					sprintf(fRetValue, "%d",
						(qos_class + i)->iid.cpeId.Id);
					break;
				}
			}
		}
	}
	IFX_MEM_FREE(qos_class);
	IFX_API_LOG("[%s:%d] : returned success retvalue=%s!", __FUNCTION__,
		    __LINE__, fRetValue);
	return IFX_SUCCESS;
}

int32 ifx_check_unique_fvp_for_qos_ds_class(IFX_MAPI_QoS_Interface_Type mode,
					 char8 * fName, char8 * fValue,
					 char8 * fRetName, char8 * fRetValue,
					 uint32 flags)
{
	int32 count = 0, i = 0;
	char8 sBuf[MAX_FILELINE_LEN];
	IFX_MAPI_QoS_Classifier *qos_class = NULL;

	if (ifx_mapi_get_all_qos_ds_classifier_if_specific
	    (mode, (uint32 *) & count, &qos_class,
	     IFX_F_DEFAULT) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("[%s:%d] Failed to display configured queues for interface %d",
		     __FUNCTION__, __LINE__, mode);
#endif
	   IFX_MEM_FREE(qos_class);
      return IFX_FAILURE;
	}

	for (i = 0; i < count; i++) {
		sprintf(sBuf, "%d", (qos_class + i)->iid.cpeId.Id);
		if (mode == ifx_mapi_get_ds_class_iface(sBuf)) {
			if (!strcmp(fName, "className")
			    && !strcmp((qos_class + i)->classifierName,
				       fValue)) {
				if (!strcmp(fRetName, "cpeId")) {
					sprintf(fRetValue, "%d",
						(qos_class + i)->iid.cpeId.Id);
					break;
				}
			}
		}
	}
	IFX_MEM_FREE(qos_class);
	IFX_API_LOG("[%s:%d] : returned success retvalue=%s!", __FUNCTION__,
		    __LINE__, fRetValue);
	return IFX_SUCCESS;
}

int32 ifx_get_instance_count_from_dist_fvp_for_qos(IFX_MAPI_QoS_Interface_Type
						   mode, char8 * secName,
						   char8 * prefix,
						   char8 * fName,
						   char8 * fValue, uint32 flags)
{
	int32 i = 0, count = 0, match_count = 0;
	char8 sBuf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];

	IFX_MAPI_QoS_Queue *qos_queue = NULL;

	if (ifx_mapi_get_all_qos_queue_if_specific
	    (mode, (uint32 *) & count, &qos_queue,
	     IFX_F_DEFAULT) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("[%s:%d] Failed to display configured queues for interface %d",
		     __FUNCTION__, __LINE__, mode);
#endif
	   IFX_MEM_FREE(qos_queue);
      return IFX_FAILURE;
	}

	for (i = 0; i < count; i++) {
		IFX_API_LOG("[%s:%d] mode = %d!", __FUNCTION__, __LINE__,
			    (qos_queue + i)->qIfType);
		sprintf(sBuf, "%s_%d_%s", prefix, i, fName);
		IFX_API_LOG("[%s:%d]sBuf=%s : qNme or qPrio matched!",
			    __FUNCTION__, __LINE__, sBuf);
		NULL_TERMINATE(sValue, 0x00, sizeof(sValue));
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] fn:fv [%s:%s] qn:qp [%s:%d]", __FUNCTION__,
			__LINE__, fName, fValue, (qos_queue + i)->qName,
			(qos_queue + i)->qPrio);
#endif
		if ((!strcmp(fName, "qName")
		     && !strcmp((qos_queue + i)->qName, fValue))
		    || (!strcmp(fName, "qPrio")
			&& (qos_queue + i)->qPrio == atoi(fValue))) {
			match_count++;
		}

	}
	IFX_MEM_FREE(qos_queue);
	return match_count;
}

int32 ifx_get_instance_count_from_dist_fvp_for_class(IFX_MAPI_QoS_Interface_Type
						     mode, char8 * secName,
						     char8 * prefix,
						     char8 * fName,
						     char8 * fValue,
						     uint32 flags)
{
	int32 i = 0, count = 0, match_count = 0;
	char8 sBuf[MAX_FILELINE_LEN];
	IFX_MAPI_QoS_Classifier *qos_class = NULL;

	if (ifx_mapi_get_all_qos_classifier_if_specific
	    (mode, (uint32 *) & count, &qos_class,
	     IFX_F_DEFAULT) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("[%s:%d] Failed to display configured queues for interface %d",
		     __FUNCTION__, __LINE__, mode);
#endif
	   IFX_MEM_FREE(qos_class);
      return IFX_FAILURE;
	}

	for (i = 0; i < count; i++) {
		{
			sprintf(sBuf, "%d", (qos_class + i)->iid.cpeId.Id);
			if (mode == ifx_mapi_get_class_iface(sBuf)) {
				IFX_API_LOG("[%s:%d] mode = %d!", __FUNCTION__,
					    __LINE__,
					    ifx_mapi_get_class_iface(sBuf));
				sprintf(sBuf, "%s_%d_%s", prefix, i, fName);
				IFX_API_LOG
				    ("[%s:%d]sBuf=%s : class name matched!",
				     __FUNCTION__, __LINE__, sBuf);
				if (!strcmp
				    ((qos_class + i)->classifierName, fValue))
					match_count++;
			}
		}
	}
/* Manamohan: 10,June 2011, Memory leak fix */
	IFX_MEM_FREE(qos_class);
	return match_count;
}

int32 ifx_get_instance_count_from_dist_fvp_for_ds_class(IFX_MAPI_QoS_Interface_Type
						     mode, char8 * secName,
						     char8 * prefix,
						     char8 * fName,
						     char8 * fValue,
						     uint32 flags)
{
	int32 i = 0, count = 0, match_count = 0;
	char8 sBuf[MAX_FILELINE_LEN];
	IFX_MAPI_QoS_Classifier *qos_class = NULL;

	if (ifx_mapi_get_all_qos_ds_classifier_if_specific
	    (mode, (uint32 *) & count, &qos_class,
	     IFX_F_DEFAULT) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("[%s:%d] Failed to display configured queues for interface %d",
		     __FUNCTION__, __LINE__, mode);
#endif
	   IFX_MEM_FREE(qos_class);
      return IFX_FAILURE;
	}

	for (i = 0; i < count; i++) {
		{
			sprintf(sBuf, "%d", (qos_class + i)->iid.cpeId.Id);
			if (mode == ifx_mapi_get_ds_class_iface(sBuf)) {
				IFX_API_LOG("[%s:%d] mode = %d!", __FUNCTION__,
					    __LINE__,
					    ifx_mapi_get_ds_class_iface(sBuf));
				sprintf(sBuf, "%s_%d_%s", prefix, i, fName);
				IFX_API_LOG
				    ("[%s:%d]sBuf=%s : class name matched!",
				     __FUNCTION__, __LINE__, sBuf);
				if (!strcmp
				    ((qos_class + i)->classifierName, fValue))
					match_count++;
			}
		}
	}
/* Manamohan: 10,June 2011, Memory leak fix */
	IFX_MEM_FREE(qos_class);
	return match_count;
}

int32 ifx_get_instance_count_from_dist_fvps_for_qos(IFX_MAPI_QoS_Interface_Type
						    mode, char8 * secName,
						    char8 * prefix,
						    char8 * fName1,
						    char8 * fValue1,
						    char8 * fName2,
						    char8 * fValue2,
						    uint32 flags)
{
	uint32 outflag = IFX_F_DEFAULT;
	int32 i = 0, count = 0, match_count = 0;
	char8 sBuf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];

	MAKE_SECTION_COUNT_TAG(secName, sBuf)
	    NULL_TERMINATE(sValue, 0x00, sizeof(sValue));
	if (ifx_GetObjData(FILE_RC_CONF, secName, sBuf, flags, &outflag, sValue)
	    != IFX_SUCCESS) {
		return IFX_FAILURE;
	}

	count = atoi(sValue);
/* Manamohan: 10,June 2011 , range check as per Klocwork report */
	if ((count < 0) || (count > 0xFFFFFFFF))
		return IFX_FAILURE;

	for (i = 0; i < count; i++) {
		sprintf(sBuf, "%s_%d_%s", prefix, i, "qIfType");
		NULL_TERMINATE(sValue, 0x00, sizeof(sValue));
		if (ifx_GetObjData
		    (FILE_RC_CONF, secName, sBuf, flags, &outflag,
		     sValue) == IFX_SUCCESS) {
			if (!(atoi(sValue) == mode))
				continue;
		}
		sprintf(sBuf, "%s_%d_%s", prefix, i, fName1);
		NULL_TERMINATE(sValue, 0x00, sizeof(sValue));
		if (ifx_GetObjData
		    (FILE_RC_CONF, secName, sBuf, flags, &outflag,
		     sValue) == IFX_SUCCESS) {
			if (!strcmp(sValue, fValue1)) {

				sprintf(sBuf, "%s_%d_%s", prefix, i, fName2);
				NULL_TERMINATE(sValue, 0x00, sizeof(sValue));
				if (ifx_GetObjData
				    (FILE_RC_CONF, secName, sBuf, flags,
				     &outflag, sValue) == IFX_SUCCESS) {
					if (!strcmp(sValue, fValue2)) {
						match_count++;
					}
				}

			}
		}
	}

	return match_count;
}

int32 ifx_get_fvp_from_another_fvps_for_qos(IFX_MAPI_QoS_Interface_Type mode,
					    char8 * secName, char8 * prefix,
					    char8 * fName1, char8 * fValue1,
					    char8 * fName2, char8 * fValue2,
					    char8 * fName3, char8 * fValue3,
					    uint32 flags)
{
	uint32 outflag = IFX_F_DEFAULT;
	int32 i = 0, count = 0;
	char8 sBuf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];

	MAKE_SECTION_COUNT_TAG(secName, sBuf)
	    NULL_TERMINATE(sValue, 0x00, sizeof(sValue));
	if (ifx_GetObjData(FILE_RC_CONF, secName, sBuf, flags, &outflag, sValue)
	    != IFX_SUCCESS) {
		return IFX_FAILURE;
	}

	count = atoi(sValue);
	for (i = 0; i < count; i++) {
		sprintf(sBuf, "%s_%d_%s", prefix, i, "qIfType");
		NULL_TERMINATE(sValue, 0x00, sizeof(sValue));
		if (ifx_GetObjData
		    (FILE_RC_CONF, secName, sBuf, flags, &outflag,
		     sValue) == IFX_SUCCESS) {
			if (!(atoi(sValue) == mode))
				continue;
		}
		sprintf(sBuf, "%s_%d_%s", prefix, i, fName1);
		NULL_TERMINATE(sValue, 0x00, sizeof(sValue));
		if (ifx_GetObjData
		    (FILE_RC_CONF, secName, sBuf, flags, &outflag,
		     sValue) == IFX_SUCCESS) {
			if (!strcmp(sValue, fValue1)) {

				sprintf(sBuf, "%s_%d_%s", prefix, i, fName2);
				NULL_TERMINATE(sValue, 0x00, sizeof(sValue));
				if (ifx_GetObjData
				    (FILE_RC_CONF, secName, sBuf, flags,
				     &outflag, sValue) == IFX_SUCCESS) {
					if (!strcmp(sValue, fValue2)) {
						sprintf(sBuf, "%s_%d_%s",
							prefix, i, fName3);
						NULL_TERMINATE(sValue, 0x00,
							       sizeof(sValue));
						if (ifx_GetObjData
						    (FILE_RC_CONF, secName,
						     sBuf, flags, &outflag,
						     fValue3) == IFX_SUCCESS) {
							return IFX_SUCCESS;
						}

					}
				}

			}
		}
	}

	return IFX_FAILURE;
}

/*
int32 ifx_get_field_count_queue(char8 *field)
{
   int      count = 0, i = 0;
   int32 total_count = 0;
   IFX_MAPI_QoS_Queue *queues = NULL;
	 WAN_PHY_CFG pstWanPhy;
	 memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));      
	 ifx_get_wan_phy_cfg(&pstWanPhy);  
   
   if(pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2 && pstWanPhy.wan_tc == WAN_TC_ATM)
   {
      if(ifx_mapi_get_all_qos_queue_if_specific(IFX_MAPI_QoS_WAN_ATM,(uint32 *)&count, &queues, IFX_F_DEFAULT) != IFX_SUCCESS) {
      return -1;
   }
   }
   else if(pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII0)
   {
      if(ifx_mapi_get_all_qos_queue_if_specific(IFX_MAPI_QoS_WAN_ETH_0,(uint32 *)&count, &queues, IFX_F_DEFAULT) != IFX_SUCCESS) {
      return -1;
   }
   }
   else if(pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII1)
   {
      if(ifx_mapi_get_all_qos_queue_if_specific(IFX_MAPI_QoS_WAN_ETH_1,(uint32 *)&count, &queues, IFX_F_DEFAULT) != IFX_SUCCESS) {
      return -1;
   }
   }
   else
   {
      if(ifx_mapi_get_all_qos_queue_if_specific(IFX_MAPI_QoS_WAN_PTM,(uint32 *)&count, &queues, IFX_F_DEFAULT) != IFX_SUCCESS) {
      return -1;
      }
   }
   for(i=0; i<count; i++) 
   {
     if((queues+i)->enable == IFX_ENABLED)
     {
        if(!strcmp(field,"queue_wt"))
           total_count+=(queues+i)->qWt;
        else if(!strcmp(field,"commited_shape_rate"))
           total_count+=(queues+i)->commitRate;
        else if(!strcmp(field,"peak_shape_rate")) 
           total_count+=(queues+i)->peakRate;   
     }
    }
    IFX_MEM_FREE(queues)
    return total_count;
}*/

int32 ipqos_rate_update_DS()
{
	uint32 sum_wtd_rts = 0, sum_rtd_rts = 0, sum_wtd_wts = 0;
	uint32 count = 0, i = 0;
	uint32 basePortRate = 0, curr_portRate_rts = 0, curr_portRate_wts = 0;
	uint32 wtd_q_count = 0, qWt_temp = 0;
	char8 sLine[256];
	IFX_MAPI_QoS_Queue *qos_queue = NULL;
	IFX_MAPI_QoS_QM xQoSQM;

	IFX_MAPI_QoS_Interface_Type qIfType = IFX_MAPI_QoS_LAN_ATM;
	WAN_PHY_CFG pstWanPhy;
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	ifx_get_wan_phy_cfg(&pstWanPhy);

	if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2) {
		if (pstWanPhy.wan_tc == WAN_TC_ATM)
			qIfType = IFX_MAPI_QoS_LAN_ATM;
		if (pstWanPhy.wan_tc == WAN_TC_PTM)
			qIfType = IFX_MAPI_QoS_LAN_PTM;
	} else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII0)
		qIfType = IFX_MAPI_QoS_LAN_ETH_0;
	else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII1)
		qIfType = IFX_MAPI_QoS_LAN_ETH_1;
	else if (pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2)
		qIfType = IFX_MAPI_QoS_LAN_PTM;

	if(ifx_mapi_get_all_qos_queue_if_specific(qIfType, &count, &qos_queue,
					       IFX_F_DEFAULT) != IFX_SUCCESS)
   {
	   IFX_MEM_FREE(qos_queue);
      return IFX_FAILURE;
   }


/* Manamohan: 10,June 11  
   Added NULL check as per Klocwork report */
	if (qos_queue == NULL)
		return IFX_FAILURE;

	for (i = 0; i <= count; i++) {
		if ((qos_queue[i].enable == TRUE)
		    && (qos_queue[i].schedType == IFX_MAPI_QoS_Sched_WFQ)) {
			if ((qos_queue[i].weightEnable == TRUE)) {
				sum_wtd_wts += qos_queue[i].qWt;
				//printf("sum_wtd_wts = %u\n", sum_wtd_wts);
			} else {
				sum_rtd_rts += qos_queue[i].commitRate;
				//printf("sum_rtd_rts = %u\n", sum_rtd_rts);
			}
		}
		if ((qos_queue[i].enable == TRUE)
		    && (qos_queue[i].schedType == IFX_MAPI_QoS_Sched_WFQ)
		    && (qos_queue[i].weightEnable == TRUE)) {
			wtd_q_count++;
			//printf("wtd_q_count = %u\n", wtd_q_count);
		}
	}

	ifx_mapi_get_qos_qm(&xQoSQM, IFX_F_DEFAULT);

	basePortRate = xQoSQM.downstreamPortRateLimit;
	//printf("baseportrate = %u\n", basePortRate);
//Issue:UGW_SW-925: sum of rates must be <=  base port rate not <
	if (((sum_rtd_rts == basePortRate) && (!wtd_q_count == 0))
	    || (sum_rtd_rts < basePortRate)) {
		curr_portRate_rts = (basePortRate - sum_rtd_rts);
	} else if ((sum_rtd_rts == basePortRate) && (wtd_q_count == 0)) {
		curr_portRate_rts = basePortRate;
	}
	//printf("currentportrate_rts = %u\n",curr_portRate_rts);

	for (i = 0; i <= count; i++) {
		if ((qos_queue[i].enable == TRUE)
		    && (qos_queue[i].schedType == IFX_MAPI_QoS_Sched_WFQ)
		    && (qos_queue[i].weightEnable == TRUE)) {
			//printf("wt_of_queue %d = %d\n", i,qos_queue[i].qWt);
			wtd_q_count++;
			qos_queue[i].commitRate =
			    ((qos_queue[i].qWt * curr_portRate_rts) /
			     sum_wtd_wts);
			//printf("commit_rate_of_queue %u = %u\n",i,qos_queue[i].commitRate);
			sum_wtd_rts += qos_queue[i].commitRate;
			sprintf(sLine, "qq_%d_commitRate=\"%d\"\n",
				qos_queue[i].iid.cpeId.Id,
				qos_queue[i].commitRate);
			ifx_SetObjData(FILE_SYSTEM_STATUS, "qos_bk",
				       IFX_F_MODIFY, 1, sLine);
#ifdef IFX_LOG_DEBUG
			IFX_DBG("%s: qq_commitrate update in tmp %d ", __func__,
				qos_queue[i].commitRate);
#endif
		}
	}
	//printf("sum_rtd_rts = %u\n", sum_rtd_rts);
	//curr_portRate_wts = (basePortRate - sum_rtd_rts);
//Issue:UGW_SW-925: sum of rates must be <=  base port rate not <
	if (((sum_rtd_rts == basePortRate) && (!wtd_q_count == 0))
	    || (sum_rtd_rts < basePortRate)) {
		curr_portRate_wts = (basePortRate - sum_rtd_rts);
	} else if ((sum_rtd_rts == basePortRate) && (wtd_q_count == 0)) {
		curr_portRate_wts = basePortRate;
	}
	//printf("curr_portrate_wts = %u\n", curr_portRate_wts);
	for (i = 0; i <= count; i++) {
		if ((qos_queue[i].enable == TRUE)
		    && (qos_queue[i].schedType == IFX_MAPI_QoS_Sched_WFQ)
		    && !(qos_queue[i].weightEnable == TRUE)) {
			if (wtd_q_count) {
				if (!curr_portRate_wts)
					curr_portRate_wts = 1;
				qWt_temp =
				    (((qos_queue[i].commitRate) * sum_wtd_wts) /
				     curr_portRate_wts);
				if (!qWt_temp)
					qos_queue[i].qWt = 1;
				else
					qos_queue[i].qWt = qWt_temp;
			} else {
				qWt_temp =
				    ((100 * qos_queue[i].commitRate) /
				     basePortRate);
				//printf("qWt_temp_for_queue_%u = %u\n",i, qWt_temp);
				if (!qWt_temp)
					qos_queue[i].qWt = 1;
				else
					qos_queue[i].qWt = qWt_temp;
				//printf("Q_wt_when_only_rated_of_%u = %u",i,qos_queue[i].qWt);
				//qos_queue[i].qWt = qos_queue[i].commitRate;
			}
			//printf("cr_of_queue %d = %d\n", i,qos_queue[i].commitRate);
			//printf("q_wt_of_queue_%d = %u\n", i,qos_queue[i].qWt);
			//printf("index=%d\n wt = %d", index,qos_queue[i].qWt);
			sprintf(sLine, "qq_%d_qWt=\"%d\"\n",
				qos_queue[i].iid.cpeId.Id, qos_queue[i].qWt);
			ifx_SetObjData(FILE_SYSTEM_STATUS, "qos_bk",
				       IFX_F_MODIFY, 1, sLine);
#ifdef IFX_LOG_DEBUG
			IFX_DBG("%s: qq_qWt in tmp %d ", __func__,
				qos_queue[i].qWt);
#endif
		}
	}

	IFX_MEM_FREE(qos_queue);
	return IFX_SUCCESS;

}



int32 ipqos_rate_update()
{
	uint32 sum_wtd_rts = 0, sum_rtd_rts = 0, sum_wtd_wts = 0;
	uint32 count = 0, i = 0;
	uint32 basePortRate = 0, curr_portRate_rts = 0, curr_portRate_wts = 0;
	uint32 wtd_q_count = 0, qWt_temp = 0;
	char8 sLine[256];
	IFX_MAPI_QoS_Queue *qos_queue = NULL;
	IFX_MAPI_QoS_QM xQoSQM;
	IFX_MAPI_QoS_Interface_Type qIfType = IFX_MAPI_QoS_WAN_ATM;
	//int index;
	//int ret;
	WAN_PHY_CFG pstWanPhy;
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	ifx_get_wan_phy_cfg(&pstWanPhy);

	if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2) {
		if (pstWanPhy.wan_tc == WAN_TC_ATM)
			qIfType = IFX_MAPI_QoS_WAN_ATM;
		if (pstWanPhy.wan_tc == WAN_TC_PTM)
			qIfType = IFX_MAPI_QoS_WAN_PTM;
	} else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII0)
		qIfType = IFX_MAPI_QoS_WAN_ETH_0;
	else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII1)
		qIfType = IFX_MAPI_QoS_WAN_ETH_1;
	else if (pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2)
		qIfType = IFX_MAPI_QoS_WAN_PTM;

	if (ifx_mapi_get_all_qos_queue_if_specific(qIfType, &count, &qos_queue,
					       IFX_F_DEFAULT) != IFX_SUCCESS)
   {
	   IFX_MEM_FREE(qos_queue);
      return IFX_FAILURE;
   }
/* Manamohan: 10,June 11  
   Added NULL check as per Klocwork report */
	if (qos_queue == NULL)
		return IFX_FAILURE;

	for (i = 0; i <= count; i++) {
		if ((qos_queue[i].enable == TRUE)
		    && (qos_queue[i].schedType == IFX_MAPI_QoS_Sched_WFQ)) {
			if ((qos_queue[i].weightEnable == TRUE)) {
				sum_wtd_wts += qos_queue[i].qWt;
				//printf("sum_wtd_wts = %u\n", sum_wtd_wts);
			} else {
				sum_rtd_rts += qos_queue[i].commitRate;
				//printf("sum_rtd_rts = %u\n", sum_rtd_rts);
			}
		}
		if ((qos_queue[i].enable == TRUE)
		    && (qos_queue[i].schedType == IFX_MAPI_QoS_Sched_WFQ)
		    && (qos_queue[i].weightEnable == TRUE)) {
			wtd_q_count++;
		}
	}

	ifx_mapi_get_qos_qm(&xQoSQM, IFX_F_DEFAULT);

	basePortRate = xQoSQM.upstreamPortRateLimit;
	//printf("baseportrate = %u\n", basePortRate);
//Issue:UGW_SW-925: sum of rates must be <=  base port rate not <
	if (((sum_rtd_rts == basePortRate) && (!wtd_q_count == 0))
	    || (sum_rtd_rts < basePortRate)) {
		curr_portRate_rts = (basePortRate - sum_rtd_rts);
	} else if ((sum_rtd_rts == basePortRate) && (wtd_q_count == 0)) {
		curr_portRate_rts = basePortRate;
	}
	//printf("currentportrate_rts = %u\n",curr_portRate_rts);

	for (i = 0; i <= count; i++) {
		if ((qos_queue[i].enable == TRUE)
		    && (qos_queue[i].schedType == IFX_MAPI_QoS_Sched_WFQ)
		    && (qos_queue[i].weightEnable == TRUE)) {
			//printf("wt_of_queue %d = %d\n", i,qos_queue[i].qWt);
			//wtd_q_count++;
			qos_queue[i].commitRate =
			    ((qos_queue[i].qWt * curr_portRate_rts) /
			     sum_wtd_wts);
			//printf("commit_rate_of_queue %u = %u\n",i,qos_queue[i].commitRate);
			sum_wtd_rts += qos_queue[i].commitRate;
			sprintf(sLine, "qq_%d_commitRate=\"%d\"\n",
				qos_queue[i].iid.cpeId.Id,
				qos_queue[i].commitRate);
			ifx_SetObjData(FILE_SYSTEM_STATUS, "qos_bk",
				       IFX_F_MODIFY, 1, sLine);
#ifdef IFX_LOG_DEBUG
			IFX_DBG("%s: qq_commitrate update in tmp %d ", __func__,
				qos_queue[i].commitRate);
#endif
		}
	}
	//printf("sum_rtd_rts = %u\n", sum_rtd_rts);
	//curr_portRate_wts = (basePortRate - sum_rtd_rts);
//Issue:UGW_SW-925: sum of rates must be <=  base port rate not <
	if (((sum_rtd_rts == basePortRate) && (!wtd_q_count == 0))
	    || (sum_rtd_rts < basePortRate)) {
		curr_portRate_wts = (basePortRate - sum_rtd_rts);
	} else if ((sum_rtd_rts == basePortRate) && (wtd_q_count == 0)) {
		curr_portRate_wts = basePortRate;
	}
	//printf("curr_portrate_wts = %u\n", curr_portRate_wts);
	for (i = 0; i <= count; i++) {
		if ((qos_queue[i].enable == TRUE)
		    && (qos_queue[i].schedType == IFX_MAPI_QoS_Sched_WFQ)
		    && !(qos_queue[i].weightEnable == TRUE)) {
			if (wtd_q_count) {
				if (!curr_portRate_wts)
					curr_portRate_wts = 1;
				qWt_temp =
				    (((qos_queue[i].commitRate) * sum_wtd_wts) /
				     curr_portRate_wts);
				if (!qWt_temp)
					qos_queue[i].qWt = 1;
				else
					qos_queue[i].qWt = qWt_temp;
			} else {
				qWt_temp =
				    ((100 * qos_queue[i].commitRate) /
				     basePortRate);
				//printf("qWt_temp_for_queue_%u = %u\n",i, qWt_temp);
				if (!qWt_temp)
					qos_queue[i].qWt = 1;
				else
					qos_queue[i].qWt = qWt_temp;
				//printf("Q_wt_when_only_rated_of_%u = %u",i,qos_queue[i].qWt);
				//qos_queue[i].qWt = qos_queue[i].commitRate;
			}
			//printf("cr_of_queue %d = %d\n", i,qos_queue[i].commitRate);
			//printf("q_wt_of_queue_%d = %u\n", i,qos_queue[i].qWt);
			//printf("index=%d\n wt = %d", index,qos_queue[i].qWt);
			sprintf(sLine, "qq_%d_qWt=\"%d\"\n",
				qos_queue[i].iid.cpeId.Id, qos_queue[i].qWt);
			ifx_SetObjData(FILE_SYSTEM_STATUS, "qos_bk",
				       IFX_F_MODIFY, 1, sLine);
#ifdef IFX_LOG_DEBUG
			IFX_DBG("%s: qq_qWt in tmp %d ", __func__,
				qos_queue[i].qWt);
#endif
		}
	}
	IFX_MEM_FREE(qos_queue);
	return IFX_SUCCESS;

}



int32 ipqos_rate_validate(uint32 Oper, uint32 cpeId,
			  IFX_MAPI_QoS_Queue * qos_queue_passed)
{
	uint32 sum_wtd_rts = 0, sum_rtd_rts = 0, sum_wtd_wts = 0;
	uint32 count = 0, i = 0;
	uint32 basePortRate = 0, curr_portRate_rts = 0, curr_portRate_wts = 0;
	uint32 wtd_q_count = 0, qWt_temp = 0;
	char8 sLine[256]; 
	IFX_MAPI_QoS_Queue *qos_queue = NULL;
	IFX_MAPI_QoS_QM xQoSQM;
	IFX_MAPI_QoS_Interface_Type qIfType = IFX_MAPI_QoS_WAN_ATM;
	int sum_commit_rates = 0;
	int sum_peak_rates = 0;
	int up_link_rate = 0;
	int ret = IFX_SUCCESS;
	WAN_PHY_CFG pstWanPhy;
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	ifx_get_wan_phy_cfg(&pstWanPhy);

	if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2) {
		if (pstWanPhy.wan_tc == WAN_TC_ATM)
			qIfType = IFX_MAPI_QoS_WAN_ATM;
		if (pstWanPhy.wan_tc == WAN_TC_PTM)
			qIfType = IFX_MAPI_QoS_WAN_PTM;
	} else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII0)
		qIfType = IFX_MAPI_QoS_WAN_ETH_0;
	else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII1)
		qIfType = IFX_MAPI_QoS_WAN_ETH_1;
	else if (pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2)
		qIfType = IFX_MAPI_QoS_WAN_PTM;

	if( ifx_mapi_get_all_qos_queue_if_specific(qIfType, &count, &qos_queue,
					       IFX_F_DEFAULT) != IFX_SUCCESS)
   {
	   IFX_MEM_FREE(qos_queue);
      return IFX_FAILURE;
   }

/* Manamohan: 10,June 11  
   Added NULL check as per Klocwork report */
	if (qos_queue == NULL)
		return IFX_FAILURE;

	/* For Modify Operation, Modify the queue entry */
#ifdef IFX_LOG_DEBUG
	IFX_API_LOG("[%s:%d]count = %d", __FUNCTION__, __LINE__, count);
#endif
	if (Oper == IFX_OP_MOD) {
		for (i = 0; i <= count; i++) {
			if (qos_queue[i].iid.cpeId.Id != cpeId)
				continue;

			IFX_API_LOG
			    ("[%s:%d]Modifying queue with cpeid %d . passed peak rate = %d",
			     __FUNCTION__, __LINE__, cpeId,
			     qos_queue_passed->peakRate);
			/* Replace the new values in the structure */
			qos_queue[i].enable = qos_queue_passed->enable;
			qos_queue[i].qWt = qos_queue_passed->qWt;
			qos_queue[i].weightEnable =
			    qos_queue_passed->weightEnable;
			qos_queue[i].shaperEnable =
			    qos_queue_passed->shaperEnable;
			qos_queue[i].schedType = qos_queue_passed->schedType;
			qos_queue[i].peakRate = qos_queue_passed->peakRate;
			qos_queue[i].commitRate = qos_queue_passed->commitRate;
#ifdef IFX_LOG_DEBUG
			IFX_API_LOG("[%s:%d]index = %d", __FUNCTION__, __LINE__,
				    i);
#endif
		}

	}

	for (i = 0; i <= count; i++) {
		if ((qos_queue[i].enable == TRUE)
		    && (qos_queue[i].schedType == IFX_MAPI_QoS_Sched_WFQ)) {
			if ((qos_queue[i].weightEnable == TRUE)) {
				sum_wtd_wts += qos_queue[i].qWt;
				IFX_API_LOG("[%s:%d]sum_wtd_wts = %u\n",
					    __FUNCTION__, __LINE__,
					    sum_wtd_wts);
			} else {
				sum_rtd_rts += qos_queue[i].commitRate;
				IFX_API_LOG("[%s:%d]sum_rtd_rts = %u\n",
					    __FUNCTION__, __LINE__,
					    sum_rtd_rts);
			}
		}
		if ((qos_queue[i].enable == TRUE)
		    && (qos_queue[i].schedType == IFX_MAPI_QoS_Sched_WFQ)
		    && (qos_queue[i].weightEnable == TRUE)) {
			wtd_q_count++;
			IFX_API_LOG("[%s:%d]weighted queue count  = %d\n",
				    __FUNCTION__, __LINE__, wtd_q_count);
		}

	}

	if ((qos_queue_passed != NULL) && (!gstrcmp(qos_queue_passed->qIf, "WAN")) && (qos_queue_passed->enable == TRUE)
	    && (qos_queue_passed->schedType == IFX_MAPI_QoS_Sched_WFQ)) {
		if ((qos_queue_passed->weightEnable == TRUE)) {
			if (Oper == IFX_OP_ADD) {
				sum_wtd_wts += qos_queue_passed->qWt;
				IFX_API_LOG("[%s:%d]sum_wtd_wts = %u\n",
					    __FUNCTION__, __LINE__,
					    sum_wtd_wts);
			}
			if (Oper == IFX_OP_DEL) {
				sum_wtd_wts -= qos_queue_passed->qWt;
				IFX_API_LOG("[%s:%d]sum_wtd_wts = %u\n",
					    __FUNCTION__, __LINE__,
					    sum_wtd_wts);
			}
		} else {
			if (Oper == IFX_OP_ADD) {
				sum_rtd_rts += qos_queue_passed->commitRate;
				IFX_API_LOG("[%s:%d]sum_rtd_rts = %u\n",
					    __FUNCTION__, __LINE__,
					    sum_rtd_rts);
			}
			if (Oper == IFX_OP_DEL) {
				sum_rtd_rts -= qos_queue_passed->commitRate;
				IFX_API_LOG("[%s:%d]sum_rtd_rts = %u\n",
					    __FUNCTION__, __LINE__,
					    sum_rtd_rts);
			}
		}
	}

	ifx_mapi_get_qos_qm(&xQoSQM, IFX_F_DEFAULT);

	/* Oper will be 8 only if this is getting invoked from QoS Settings page and qos is enabled.
	   Also the user passed port tate limit will be present in cpeId  and will be nonzero. */
	if (Oper == 8) {
		if (cpeId) {
			basePortRate = cpeId;
		}
	} else {
		basePortRate = xQoSQM.upstreamPortRateLimit;
	}
	IFX_API_LOG("[%s:%d]baseportrate = %u\n", __FUNCTION__, __LINE__,
		    basePortRate);

//Issue:UGW_SW-925:changed sum_rtd_rts < baseport rate to <=
	if (((sum_rtd_rts == basePortRate) && (!wtd_q_count == 0))
	    || (sum_rtd_rts < basePortRate)) {
		curr_portRate_rts = (basePortRate - sum_rtd_rts);
	} else if ((sum_rtd_rts == basePortRate) && (wtd_q_count == 0)) {
		curr_portRate_rts = basePortRate;
	}

	IFX_API_LOG("[%s:%d]currentportrate_rts = %u\n", __FUNCTION__, __LINE__,
		    curr_portRate_rts);

	for (i = 0; i <= count; i++) {
		if (Oper == IFX_OP_DEL) {
			if (qos_queue[i].iid.cpeId.Id == cpeId)
				continue;
		}
		if ((qos_queue[i].enable == TRUE)
		    && (qos_queue[i].schedType == IFX_MAPI_QoS_Sched_WFQ)
		    && (qos_queue[i].weightEnable == TRUE)) {
			IFX_API_LOG("[%s:%d]wt_of_queue %d = %d\n",
				    __FUNCTION__, __LINE__, i,
				    qos_queue[i].qWt);
			wtd_q_count++;
			qos_queue[i].commitRate =
			    ((qos_queue[i].qWt * curr_portRate_rts) /
			     sum_wtd_wts);
			IFX_API_LOG("[%s:%d]commit_rate_of_queue %u = %u\n",
				    __FUNCTION__, __LINE__, i,
				    qos_queue[i].commitRate);
			sum_wtd_rts += qos_queue[i].commitRate;
		}
	}

	if ((qos_queue_passed != NULL) && (!gstrcmp(qos_queue_passed->qIf, "WAN")) && (qos_queue_passed->enable == TRUE)
	    && (qos_queue_passed->schedType == IFX_MAPI_QoS_Sched_WFQ)
	    && (qos_queue_passed->weightEnable == TRUE)) {
		if (Oper == IFX_OP_ADD) {
			IFX_API_LOG("[%s:%d]wt_of_queue = %d\n", __FUNCTION__,
				    __LINE__, qos_queue_passed->qWt);
			wtd_q_count++;
			qos_queue_passed->commitRate =
			    ((qos_queue_passed->qWt * curr_portRate_rts) /
			     sum_wtd_wts);
			IFX_API_LOG("[%s:%d]commit_rate_of_queue = %u\n",
				    __FUNCTION__, __LINE__,
				    qos_queue_passed->commitRate);
			sum_wtd_rts += qos_queue_passed->commitRate;
		}
	}

	IFX_API_LOG("[%s:%d]sum_rtd_rts = %u\n", __FUNCTION__, __LINE__,
		    sum_rtd_rts);
	//curr_portRate_wts = (basePortRate - sum_rtd_rts);
//Issue:UGW_SW-925: sum of rates must be <=  base port rate not <
	if (((sum_rtd_rts == basePortRate) && (!wtd_q_count == 0))
	    || (sum_rtd_rts < basePortRate)) {
		curr_portRate_wts = (basePortRate - sum_rtd_rts);
	} else if ((sum_rtd_rts == basePortRate) && (wtd_q_count == 0)) {
		curr_portRate_wts = basePortRate;
	}

	IFX_API_LOG("[%s:%d]curr_portrate_wts = %u\n", __FUNCTION__, __LINE__,
		    curr_portRate_wts);
	for (i = 0; i <= count; i++) {
		if (Oper == IFX_OP_DEL) {
			if (qos_queue[i].iid.cpeId.Id == cpeId)
				continue;
		}
		if ((qos_queue[i].enable == TRUE)
		    && (qos_queue[i].schedType == IFX_MAPI_QoS_Sched_WFQ)
		    && !(qos_queue[i].weightEnable == TRUE)) {
			if (wtd_q_count) {
				if (!curr_portRate_wts)
					curr_portRate_wts = 1;
				qos_queue[i].qWt =
				    (((qos_queue[i].commitRate) * sum_wtd_wts) /
				     curr_portRate_wts);
				if (!qWt_temp)
					qos_queue[i].qWt = 1;
				else
					qos_queue[i].qWt = qWt_temp;
			} else {
				qWt_temp =
				    ((100 * qos_queue[i].commitRate) /
				     basePortRate);
				IFX_API_LOG
				    ("[%s:%d]qWt_temp_for_queue_%u = %u\n",
				     __FUNCTION__, __LINE__, i, qWt_temp);
				if (!qWt_temp)
					qos_queue[i].qWt = 1;
				else
					qos_queue[i].qWt = qWt_temp;
				IFX_API_LOG
				    ("[%s:%d]Q_wt_when_only_rated_of_%u = %u",
				     __FUNCTION__, __LINE__, i,
				     qos_queue[i].qWt);
				//qos_queue[i].qWt = qos_queue[i].commitRate;
			}
			IFX_API_LOG("[%s:%d]cr_of_queue %d = %d\n",
				    __FUNCTION__, __LINE__, i,
				    qos_queue[i].commitRate);
			IFX_API_LOG("[%s:%d]q_wt_of_queue_%d = %u\n",
				    __FUNCTION__, __LINE__, i,
				    qos_queue[i].qWt);
		}
	}

	if ((qos_queue_passed != NULL) && (!gstrcmp(qos_queue_passed->qIf, "WAN")) && (qos_queue_passed->enable == TRUE)
	    && (qos_queue_passed->schedType == IFX_MAPI_QoS_Sched_WFQ)
	    && !(qos_queue_passed->weightEnable == TRUE)) {
		if (Oper == IFX_OP_ADD) {
			if (wtd_q_count) {
				qos_queue_passed->qWt =
				    (((qos_queue_passed->commitRate) *
				      sum_wtd_wts) / curr_portRate_wts);
			} else {
				qWt_temp =
				    ((100 * qos_queue_passed->commitRate) /
				     basePortRate);
				IFX_API_LOG("[%s:%d]qWt_temp_for_queue = %u\n",
					    __FUNCTION__, __LINE__, qWt_temp);
				if (!qWt_temp)
					qos_queue_passed->qWt = 1;
				else
					qos_queue_passed->qWt = qWt_temp;
				IFX_API_LOG
				    ("[%s:%d]Q_wt_when_only_rated_of = %u",
				     __FUNCTION__, __LINE__,
				     qos_queue_passed->qWt);
				//qos_queue[i].qWt = qos_queue[i].commitRate;
			}
			IFX_API_LOG("[%s:%d]cr_of_queue = %d\n", __FUNCTION__,
				    __LINE__, qos_queue_passed->commitRate);
			IFX_API_LOG("[%s:%d]q_wt_of_queue = %u\n", __FUNCTION__,
				    __LINE__, qos_queue_passed->qWt);
		}

	}

	/* Update The peak rates wherever user has not given */
	for (i = 0; i <= count; i++) {
		if (qos_queue[i].enable == TRUE) {
			if ((qos_queue[i].shaperEnable != TRUE)) {
				qos_queue[i].peakRate = basePortRate;
			}
		}
	}

	if ((qos_queue_passed != NULL) && (qos_queue_passed->enable == TRUE)) {
		if (Oper == IFX_OP_ADD) {
			if ((qos_queue_passed->shaperEnable != TRUE)) {
				qos_queue_passed->peakRate = basePortRate;
			}
		}
	}

	/* Validations */
	/* Peak Rate */
	/* Peak rate for any queue <= Port rate */
	/* Peak Rate for any queue  >= Commit Rate of that queue */
	/* if MII0 then, Sum of Peak Rates of all queues <= 3 * link rate */

	/* Port rate */
	/* Port Rate should be <=  link rate */

	/* commit rate */
	/* sum of Commit Rate of all queues should be <= port rate */

//	ifx_GetObjData("/tmp/system_status", "qos_bk", "up_link_rate",
//		       IFX_F_GET_ENA, 0, sLine);
	if((ifx_GetObjData("/tmp/system_status", "qos_bk", "up_link_rate",
		       IFX_F_GET_ENA, 0, sLine)) != IFX_SUCCESS){
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		if ((ifx_GetObjData
	 		(FILE_RC_CONF, TAG_IPQOS_QM, "qm_upPortRateLim", IFX_F_GET_ANY,
	  		0, sLine)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			return ret;
		}
	}
	up_link_rate = atoi(sLine);
	if (Oper == 8) {
		/* Port Rate should be <=  link rate */
		if (basePortRate > up_link_rate) {
			IFX_API_LOG("[%s:%d]Port rate %d > link rate %d",
				    __FUNCTION__, __LINE__, basePortRate,
				    up_link_rate);
			IFX_MEM_FREE(qos_queue);
			return -10;
		}

	}

	for (i = 0; i <= count; i++) {
		if ((qos_queue[i].enable == TRUE)
		    && (qos_queue[i].schedType == IFX_MAPI_QoS_Sched_SP)) {
			if (Oper == IFX_OP_DEL) {
				if (qos_queue[i].iid.cpeId.Id == cpeId)
					continue;
			}
			sum_peak_rates += qos_queue[i].peakRate;
			/* Peak rate for any queue <= Port rate */
			if (qos_queue[i].peakRate > basePortRate) {
				IFX_API_LOG
				    ("[%s:%d]Peak Rate %d > Port rate %d",
				     __FUNCTION__, __LINE__,
				     qos_queue[i].peakRate, basePortRate);
				IFX_MEM_FREE(qos_queue);
				return -20;
			}
		}
		if ((qos_queue[i].enable == TRUE)
		    && (qos_queue[i].schedType == IFX_MAPI_QoS_Sched_WFQ)) {
			if (Oper == IFX_OP_DEL) {
				if (qos_queue[i].iid.cpeId.Id == cpeId)
					continue;
			}
			sum_commit_rates += qos_queue[i].commitRate;
			sum_peak_rates += qos_queue[i].peakRate;
			/* Peak rate for any queue <= Port rate */
			IFX_API_LOG("[%s:%d]index = %d", __FUNCTION__, __LINE__,
				    i);
			if (qos_queue[i].peakRate > basePortRate) {
				IFX_API_LOG
				    ("[%s:%d]Peak Rate %d > Port rate %d",
				     __FUNCTION__, __LINE__,
				     qos_queue[i].peakRate, basePortRate);
				IFX_MEM_FREE(qos_queue);
				return -20;
			}
			/* Peak Rate for any queue  >= Commit Rate of that queue */
			if (qos_queue[i].peakRate < qos_queue[i].commitRate) {
				IFX_API_LOG
				    ("[%s:%d]Peak Rate %d < Commit rate %d",
				     __FUNCTION__, __LINE__,
				     qos_queue[i].peakRate,
				     qos_queue[i].commitRate);
				IFX_MEM_FREE(qos_queue);
				return -30;
			}
		}
	}
	if ((qos_queue_passed != NULL) && (!gstrcmp(qos_queue_passed->qIf, "WAN")) && (qos_queue_passed->enable == TRUE)) {
		if (Oper == IFX_OP_ADD) {
			sum_peak_rates += qos_queue_passed->peakRate;
			/* Peak rate for any queue <= Port rate */
			if (qos_queue_passed->peakRate > basePortRate) {
				IFX_API_LOG
				    ("[%s:%d]Peak Rate %d > Port rate %d",
				     __FUNCTION__, __LINE__,
				     qos_queue_passed->peakRate, basePortRate);
				IFX_MEM_FREE(qos_queue);
				return -20;
			}
		}
	}

	if ((qos_queue_passed != NULL) && (qos_queue_passed->enable == TRUE)
	    && (qos_queue_passed->schedType == IFX_MAPI_QoS_Sched_WFQ)) {
		if (Oper == IFX_OP_ADD) {
			sum_commit_rates += qos_queue_passed->commitRate;
			/* Peak Rate for any queue  >= Commit Rate of that queue */
			if (qos_queue_passed->peakRate <
			    qos_queue_passed->commitRate) {
				IFX_API_LOG
				    ("[%s:%d]Peak Rate %d < Commit rate %d",
				     __FUNCTION__, __LINE__,
				     qos_queue_passed->peakRate,
				     qos_queue_passed->commitRate);
				IFX_MEM_FREE(qos_queue);
				return -30;
			}
		}
	}

	/* sum of Commit Rate of all queues should be <= port rate */
	if (sum_commit_rates > basePortRate) {
		IFX_API_LOG("[%s:%d]Sum_CommitRates %d > Port rate %d",
			    __FUNCTION__, __LINE__, sum_commit_rates,
			    basePortRate);
		IFX_MEM_FREE(qos_queue);
		return -40;
	}

/* Manamohan: D5 FW MII0 QoS  */
#if 0
	/* if MII0 then, Sum of Peak Rates of all queues <= link rate */
	if ((sum_peak_rates > (3 * up_link_rate))
	    && (qIfType == IFX_MAPI_QoS_WAN_ETH_0)) {
		IFX_API_LOG("[%s:%d]Sum_PeakRates %d > (3*Link rate) %d",
			    __FUNCTION__, __LINE__, sum_peak_rates,
			    up_link_rate);
		IFX_MEM_FREE(qos_queue);
		return -50;
	}
#endif

	IFX_MEM_FREE(qos_queue);
	return IFX_SUCCESS;

}

int32 ipqos_rate_validate_DS(uint32 Oper, uint32 cpeId,
			  IFX_MAPI_QoS_Queue * qos_queue_passed)
{
	uint32 sum_wtd_rts = 0, sum_rtd_rts = 0, sum_wtd_wts = 0;
	uint32 count = 0, i = 0;
	uint32 basePortRate = 0, curr_portRate_rts = 0, curr_portRate_wts = 0;
	uint32 wtd_q_count = 0, qWt_temp = 0;
	char8 sLine[256];
	IFX_MAPI_QoS_Queue *qos_queue = NULL;
	IFX_MAPI_QoS_QM xQoSQM;
	IFX_MAPI_QoS_Interface_Type qIfType = IFX_MAPI_QoS_LAN_ATM;
	int sum_commit_rates = 0;
	int sum_peak_rates = 0;
	int down_link_rate = 0;
	int ret = IFX_SUCCESS;
	WAN_PHY_CFG pstWanPhy;
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	ifx_get_wan_phy_cfg(&pstWanPhy);

	if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2) {
		if (pstWanPhy.wan_tc == WAN_TC_ATM)
			qIfType = IFX_MAPI_QoS_LAN_ATM;
		if (pstWanPhy.wan_tc == WAN_TC_PTM)
			qIfType = IFX_MAPI_QoS_LAN_PTM;
	} else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII0)
		qIfType = IFX_MAPI_QoS_LAN_ETH_0;
	else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII1)
		qIfType = IFX_MAPI_QoS_LAN_ETH_1;
	else if (pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2)
		qIfType = IFX_MAPI_QoS_LAN_PTM;

	if(ifx_mapi_get_all_qos_queue_if_specific(qIfType, &count, &qos_queue,
					       IFX_F_DEFAULT) != IFX_SUCCESS)
   {
	   IFX_MEM_FREE(qos_queue);
      return IFX_FAILURE;

   }
/* Manamohan: 10,June 11  
   Added NULL check as per Klocwork report */
	if (qos_queue == NULL) 
		return IFX_FAILURE;

	/* For Modify Operation, Modify the queue entry */
#ifdef IFX_LOG_DEBUG
	IFX_API_LOG("[%s:%d]count = %d", __FUNCTION__, __LINE__, count);
#endif
	if (Oper == IFX_OP_MOD) {
		for (i = 0; i <= count; i++) {
			if (qos_queue[i].iid.cpeId.Id != cpeId)
				continue;

			IFX_API_LOG
			    ("[%s:%d]Modifying queue with cpeid %d . passed peak rate = %d",
			     __FUNCTION__, __LINE__, cpeId,
			     qos_queue_passed->peakRate);
			/* Replace the new values in the structure */
			qos_queue[i].enable = qos_queue_passed->enable;
			qos_queue[i].qWt = qos_queue_passed->qWt;
			qos_queue[i].weightEnable =
			    qos_queue_passed->weightEnable;
			qos_queue[i].shaperEnable =
			    qos_queue_passed->shaperEnable;
			qos_queue[i].schedType = qos_queue_passed->schedType;
			qos_queue[i].peakRate = qos_queue_passed->peakRate;
			qos_queue[i].commitRate = qos_queue_passed->commitRate;
#ifdef IFX_LOG_DEBUG
			IFX_API_LOG("[%s:%d]index = %d", __FUNCTION__, __LINE__,
				    i);
#endif
		}
	}

	for (i = 0; i <= count; i++) {
		if ((qos_queue[i].enable == TRUE)
		    && (qos_queue[i].schedType == IFX_MAPI_QoS_Sched_WFQ)) {
			if ((qos_queue[i].weightEnable == TRUE)) {
				sum_wtd_wts += qos_queue[i].qWt;
				IFX_API_LOG("[%s:%d]sum_wtd_wts = %u\n",
					    __FUNCTION__, __LINE__,
					    sum_wtd_wts);
			} else {
				sum_rtd_rts += qos_queue[i].commitRate;
				IFX_API_LOG("[%s:%d]sum_rtd_rts = %u\n",
					    __FUNCTION__, __LINE__,
					    sum_rtd_rts);
			}
		}
		if ((qos_queue[i].enable == TRUE)
		    && (qos_queue[i].schedType == IFX_MAPI_QoS_Sched_WFQ)
		    && (qos_queue[i].weightEnable == TRUE)) {
			wtd_q_count++;
			IFX_API_LOG("[%s:%d]weighted queue count  = %d\n",
				    __FUNCTION__, __LINE__, wtd_q_count);
		}

	}

	if (qos_queue_passed != NULL) 
	{
		if ((!gstrcmp(qos_queue_passed->qIf, "LAN")) && (qos_queue_passed->enable == TRUE)
	    		&& (qos_queue_passed->schedType == IFX_MAPI_QoS_Sched_WFQ)) 
		{
			if ((qos_queue_passed->weightEnable == TRUE)) 
			{
				if (Oper == IFX_OP_ADD) 
				{
					sum_wtd_wts += qos_queue_passed->qWt;
					IFX_API_LOG("[%s:%d]sum_wtd_wts = %u\n",
					    __FUNCTION__, __LINE__,
					    sum_wtd_wts);
				}
				if (Oper == IFX_OP_DEL) 
				{
					sum_wtd_wts -= qos_queue_passed->qWt;
					IFX_API_LOG("[%s:%d]sum_wtd_wts = %u\n",
					    __FUNCTION__, __LINE__,
					    sum_wtd_wts);
				}
			} 
			else 
			{
				if (Oper == IFX_OP_ADD) 
				{
					sum_rtd_rts += qos_queue_passed->commitRate;
					IFX_API_LOG("[%s:%d]sum_rtd_rts = %u\n",
					    __FUNCTION__, __LINE__,
					    sum_rtd_rts);
				}
				if (Oper == IFX_OP_DEL) 
				{
					sum_rtd_rts -= qos_queue_passed->commitRate;
					IFX_API_LOG("[%s:%d]sum_rtd_rts = %u\n",
					    __FUNCTION__, __LINE__,
					    sum_rtd_rts);
				}
			}
		}
	}

	ifx_mapi_get_qos_qm(&xQoSQM, IFX_F_DEFAULT);

	/* Oper will be 8 only if this is getting invoked from QoS Settings page and qos is enabled.
	   Also the user passed port tate limit will be present in cpeId  and will be nonzero. */
	if (Oper == 8) 
	{
		if (cpeId) 
		{
			basePortRate = cpeId;
		}
	} 
	else 
	{
		basePortRate = xQoSQM.downstreamPortRateLimit;
	}

	IFX_API_LOG("[%s:%d]baseportrate = %u\n", __FUNCTION__, __LINE__,
		    basePortRate);

//Issue:UGW_SW-925:changed sum_rtd_rts < baseport rate to <=
	if (((sum_rtd_rts == basePortRate) && (!wtd_q_count == 0))
	    || (sum_rtd_rts < basePortRate)) {
		curr_portRate_rts = (basePortRate - sum_rtd_rts);
	} else if ((sum_rtd_rts == basePortRate) && (wtd_q_count == 0)) {
		curr_portRate_rts = basePortRate;
	}

	IFX_API_LOG("[%s:%d]currentportrate_rts = %u\n", __FUNCTION__, __LINE__,
		    curr_portRate_rts);

	for (i = 0; i <= count; i++) {
		if (Oper == IFX_OP_DEL) {
			if (qos_queue[i].iid.cpeId.Id == cpeId)
				continue;
		}
		if ((qos_queue[i].enable == TRUE)
		    && (qos_queue[i].schedType == IFX_MAPI_QoS_Sched_WFQ)
		    && (qos_queue[i].weightEnable == TRUE)) {
			IFX_API_LOG("[%s:%d]wt_of_queue %d = %d\n",
				    __FUNCTION__, __LINE__, i,
				    qos_queue[i].qWt);
			wtd_q_count++;
			qos_queue[i].commitRate =
			    ((qos_queue[i].qWt * curr_portRate_rts) /
			     sum_wtd_wts);
			IFX_API_LOG("[%s:%d]commit_rate_of_queue %u = %u\n",
				    __FUNCTION__, __LINE__, i,
				    qos_queue[i].commitRate);
			sum_wtd_rts += qos_queue[i].commitRate;
		}
	}

	if (qos_queue_passed != NULL) 
	{
		if((!gstrcmp(qos_queue_passed->qIf, "LAN")) && (qos_queue_passed->enable == TRUE)
	    		&& (qos_queue_passed->schedType == IFX_MAPI_QoS_Sched_WFQ)
	    		&& (qos_queue_passed->weightEnable == TRUE)) 
		{
			if (Oper == IFX_OP_ADD) 
			{
				IFX_API_LOG("[%s:%d]wt_of_queue = %d\n", __FUNCTION__,
				    __LINE__, qos_queue_passed->qWt);
				wtd_q_count++;
				qos_queue_passed->commitRate =
			    	((qos_queue_passed->qWt * curr_portRate_rts) /
			    	sum_wtd_wts);
				IFX_API_LOG("[%s:%d]commit_rate_of_queue = %u\n",
				    __FUNCTION__, __LINE__,
				    qos_queue_passed->commitRate);
				sum_wtd_rts += qos_queue_passed->commitRate;
			}
		}
	}

	IFX_API_LOG("[%s:%d]sum_rtd_rts = %u\n", __FUNCTION__, __LINE__,
		    sum_rtd_rts);
	//curr_portRate_wts = (basePortRate - sum_rtd_rts);
//Issue:UGW_SW-925: sum of rates must be <=  base port rate not <
	if (((sum_rtd_rts == basePortRate) && (!wtd_q_count == 0))
	    || (sum_rtd_rts < basePortRate)) {
		curr_portRate_wts = (basePortRate - sum_rtd_rts);
	} else if ((sum_rtd_rts == basePortRate) && (wtd_q_count == 0)) {
		curr_portRate_wts = basePortRate;
	}

	IFX_API_LOG("[%s:%d]curr_portrate_wts = %u\n", __FUNCTION__, __LINE__,
		    curr_portRate_wts);
	for (i = 0; i <= count; i++) {
		if (Oper == IFX_OP_DEL) {
			if (qos_queue[i].iid.cpeId.Id == cpeId)
				continue;
		}
		if ((qos_queue[i].enable == TRUE)
		    && (qos_queue[i].schedType == IFX_MAPI_QoS_Sched_WFQ)
		    && !(qos_queue[i].weightEnable == TRUE)) {
			if (wtd_q_count) {
				if (!curr_portRate_wts)
					curr_portRate_wts = 1;
				qos_queue[i].qWt =
				    (((qos_queue[i].commitRate) * sum_wtd_wts) /
				     curr_portRate_wts);
				if (!qWt_temp)
					qos_queue[i].qWt = 1;
				else
					qos_queue[i].qWt = qWt_temp;
			} else {
				qWt_temp =
				    ((100 * qos_queue[i].commitRate) /
				     basePortRate);
				IFX_API_LOG
				    ("[%s:%d]qWt_temp_for_queue_%u = %u\n",
				     __FUNCTION__, __LINE__, i, qWt_temp);
				if (!qWt_temp)
					qos_queue[i].qWt = 1;
				else
					qos_queue[i].qWt = qWt_temp;
				IFX_API_LOG
				    ("[%s:%d]Q_wt_when_only_rated_of_%u = %u",
				     __FUNCTION__, __LINE__, i,
				     qos_queue[i].qWt);
				//qos_queue[i].qWt = qos_queue[i].commitRate;
			}
			IFX_API_LOG("[%s:%d]cr_of_queue %d = %d\n",
				    __FUNCTION__, __LINE__, i,
				    qos_queue[i].commitRate);
			IFX_API_LOG("[%s:%d]q_wt_of_queue_%d = %u\n",
				    __FUNCTION__, __LINE__, i,
				    qos_queue[i].qWt);
		}
	}

	if (qos_queue_passed != NULL)
	{
		if((!gstrcmp(qos_queue_passed->qIf, "LAN")) && (qos_queue_passed->enable == TRUE)
			&& (qos_queue_passed->schedType == IFX_MAPI_QoS_Sched_WFQ)
			&& !(qos_queue_passed->weightEnable == TRUE)) 
		{
			if (Oper == IFX_OP_ADD) 
			{
				if (wtd_q_count) 
				{
					qos_queue_passed->qWt = (((qos_queue_passed->commitRate) * sum_wtd_wts) / curr_portRate_wts);
				} 
				else 
				{
					qWt_temp = ((100 * qos_queue_passed->commitRate) / basePortRate);
					IFX_API_LOG("[%s:%d]qWt_temp_for_queue = %u\n",  __FUNCTION__, __LINE__, qWt_temp);
					if (!qWt_temp)
						qos_queue_passed->qWt = 1;
					else
						qos_queue_passed->qWt = qWt_temp;
					IFX_API_LOG("[%s:%d]Q_wt_when_only_rated_of = %u", __FUNCTION__, __LINE__, qos_queue_passed->qWt);
					//qos_queue[i].qWt = qos_queue[i].commitRate;
				}
				IFX_API_LOG("[%s:%d]cr_of_queue = %d\n", __FUNCTION__, __LINE__, qos_queue_passed->commitRate);
				IFX_API_LOG("[%s:%d]q_wt_of_queue = %u\n", __FUNCTION__, __LINE__, qos_queue_passed->qWt);
			}

		}
	}

	/* Update The peak rates wherever user has not given */
	for (i = 0; i <= count; i++) {
		if (qos_queue[i].enable == TRUE) {
			if ((qos_queue[i].shaperEnable != TRUE)) {
				qos_queue[i].peakRate = basePortRate;
			}
		}
	}

	if ((qos_queue_passed != NULL) && (qos_queue_passed->enable == TRUE)) {
		if (Oper == IFX_OP_ADD) {
			if ((qos_queue_passed->shaperEnable != TRUE)) {
				qos_queue_passed->peakRate = basePortRate;
			}
		}
	}

	/* Validations */
	/* Peak Rate */
	/* Peak rate for any queue <= Port rate */
	/* Peak Rate for any queue  >= Commit Rate of that queue */
	/* if MII0 then, Sum of Peak Rates of all queues <= 3 * link rate */

	/* Port rate */
	/* Port Rate should be <=  link rate */

	/* commit rate */
	/* sum of Commit Rate of all queues should be <= port rate */

//	ifx_GetObjData("/tmp/system_status", "qos_bk", "down_link_rate",
//		       IFX_F_GET_ENA, 0, sLine);
	if((ifx_GetObjData("/tmp/system_status", "qos_bk", "down_link_rate",
		       IFX_F_GET_ENA, 0, sLine)) != IFX_SUCCESS){
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		if ((ifx_GetObjData
	 		(FILE_RC_CONF, TAG_IPQOS_QM, "qm_downPortRateLim", IFX_F_GET_ANY,
	  		0, sLine)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			return ret;
		}
	}
	down_link_rate = atoi(sLine);
	if (Oper == 8) {
		/* Port Rate should be <=  link rate */
		if (basePortRate > down_link_rate) {
			IFX_API_LOG("[%s:%d]Port rate %d > link rate %d",
				    __FUNCTION__, __LINE__, basePortRate,
				    down_link_rate);
			IFX_MEM_FREE(qos_queue);
			return -10;
		}

	}

	for (i = 0; i <= count; i++) {
		if ((qos_queue[i].enable == TRUE)
		    && (qos_queue[i].schedType == IFX_MAPI_QoS_Sched_SP)) {
			if (Oper == IFX_OP_DEL) {
				if (qos_queue[i].iid.cpeId.Id == cpeId)
					continue;
			}
			sum_peak_rates += qos_queue[i].peakRate;
			/* Peak rate for any queue <= Port rate */
			if (qos_queue[i].peakRate > basePortRate) {
				IFX_API_LOG
				    ("[%s:%d]Peak Rate %d > Port rate %d",
				     __FUNCTION__, __LINE__,
				     qos_queue[i].peakRate, basePortRate);
				IFX_MEM_FREE(qos_queue);
				return -20;
			}
		}
		if ((qos_queue[i].enable == TRUE)
		    && (qos_queue[i].schedType == IFX_MAPI_QoS_Sched_WFQ)) {
			if (Oper == IFX_OP_DEL) {
				if (qos_queue[i].iid.cpeId.Id == cpeId)
					continue;
			}
			sum_commit_rates += qos_queue[i].commitRate;
			sum_peak_rates += qos_queue[i].peakRate;
			/* Peak rate for any queue <= Port rate */
			IFX_API_LOG("[%s:%d]index = %d", __FUNCTION__, __LINE__,
				    i);
			if (qos_queue[i].peakRate > basePortRate) {
				IFX_API_LOG
				    ("[%s:%d]Peak Rate %d > Port rate %d",
				     __FUNCTION__, __LINE__,
				     qos_queue[i].peakRate, basePortRate);
				IFX_MEM_FREE(qos_queue);
				return -20;
			}
			/* Peak Rate for any queue  >= Commit Rate of that queue */
			if (qos_queue[i].peakRate < qos_queue[i].commitRate) {
				IFX_API_LOG
				    ("[%s:%d]Peak Rate %d < Commit rate %d",
				     __FUNCTION__, __LINE__,
				     qos_queue[i].peakRate,
				     qos_queue[i].commitRate);
				IFX_MEM_FREE(qos_queue);
				return -30;
			}
		}
	}
	if ((qos_queue_passed != NULL) && ((!gstrcmp(qos_queue_passed->qIf, "LAN"))))
	{
		if ((qos_queue_passed->enable == TRUE)) {
			if (Oper == IFX_OP_ADD) {
				sum_peak_rates += qos_queue_passed->peakRate;
				/* Peak rate for any queue <= Port rate */
				if (qos_queue_passed->peakRate > basePortRate) {
					IFX_API_LOG
					    ("[%s:%d]Peak Rate %d > Port rate %d",
					     __FUNCTION__, __LINE__,
					     qos_queue_passed->peakRate, basePortRate);
					IFX_MEM_FREE(qos_queue);
					return -20;
				}
			}
		}

		if ((qos_queue_passed->enable == TRUE)
		    && (qos_queue_passed->schedType == IFX_MAPI_QoS_Sched_WFQ)) {
			if (Oper == IFX_OP_ADD) {
				sum_commit_rates += qos_queue_passed->commitRate;
				/* Peak Rate for any queue  >= Commit Rate of that queue */
				if (qos_queue_passed->peakRate <
			 	   qos_queue_passed->commitRate) {
					IFX_API_LOG
					    ("[%s:%d]Peak Rate %d < Commit rate %d",
					     __FUNCTION__, __LINE__,
					     qos_queue_passed->peakRate,
					     qos_queue_passed->commitRate);
					IFX_MEM_FREE(qos_queue);
					return -30;
				}
			}
		}
	}

	/* sum of Commit Rate of all queues should be <= port rate */
	if (sum_commit_rates > basePortRate) {
		IFX_API_LOG("[%s:%d]Sum_CommitRates %d > Port rate %d",
			    __FUNCTION__, __LINE__, sum_commit_rates,
			    basePortRate);
		IFX_MEM_FREE(qos_queue);
		return -40;
	}

/* Manamohan: D5 FW MII0 QoS  */
#if 0
	/* if MII0 then, Sum of Peak Rates of all queues <= link rate */
	if ((sum_peak_rates > (3 * up_link_rate))
	    && (qIfType == IFX_MAPI_QoS_WAN_ETH_0)) {
		IFX_API_LOG("[%s:%d]Sum_PeakRates %d > (3*Link rate) %d",
			    __FUNCTION__, __LINE__, sum_peak_rates,
			    up_link_rate);
		IFX_MEM_FREE(qos_queue);
		return -50;
	}
#endif

	IFX_MEM_FREE(qos_queue);
	return IFX_SUCCESS;

}
int32 init_qspec_class_queue_map_file(IFX_MAPI_QoS_Queue * qos_queue,
				      unsigned int flags)
{
	char sLine[2096];
	char *tstr;

#ifdef IFX_LOG_DEBUG
	IFX_DBG("%s: Queue Id: %d", __func__, qos_queue->iid.cpeId.Id);
#endif

	// create initial queue info into /tmp/system_status
	memset(sLine, 0, 2096);
	tstr = sLine;

	sprintf(tstr, "qq_%d_qWt=\"%u\"\n", qos_queue->iid.cpeId.Id,
		qos_queue->qWt);
	tstr = tstr + strlen(tstr);

	sprintf(tstr, "qq_%d_commitRate=\"%u\"\n", qos_queue->iid.cpeId.Id,
		qos_queue->commitRate);
	tstr = tstr + strlen(tstr);

	if (IFX_MODIFY_F_NOT_SET(flags)) {
		sprintf(tstr, "qq_%d_map_list=\"%s\"\n",
			qos_queue->iid.cpeId.Id, INITIAL_CLASS_QUEUE_MAP);
	}
#ifdef IFX_LOG_DEBUG
	IFX_DBG(sLine);
#endif

	// Set this value in temp system status in QOS_MAP Section
	if (ifx_SetObjData(FILE_SYSTEM_STATUS, "qos_bk",
			   flags, 1, sLine) != IFX_SUCCESS) {
		IFX_ERR("Unable to init queue_class_map");
	}

	return 0;
}
