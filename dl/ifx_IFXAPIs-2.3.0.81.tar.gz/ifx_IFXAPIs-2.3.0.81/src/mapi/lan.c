
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"

char8 *lan_dhcps_param_names[] =
    { "lan_dhcps_cpeId", "lan_dhcps_pcpeId", "lan_dhcps_maxLeases",
"lan_dhcps_leasetime", "lan_dhcps_dhcpMode", "lan_dhcps_iface", "lan_dhcps_netmask",
"lan_dhcps_startIp", "lan_dhcps_endIp", "lan_dhcps_gw", "lan_dhcps_domainName" };

char8 *lan_dhcpr_param_names[] =
    { "lan_dhcp_relay_cpeId", "lan_dhcp_relay_pcpeId",
"lan_dhcp_relay_serverIf", "lan_dhcp_relay_server" };

char8 *lan_ip_mask_param_names[] =
    { "cpeId", "pcpeId", "ipAddr", "netmask", "interface", "dhcpMode", "gw",
"DNSServers", "ipAddrType","VIPEnable","fEnable","connName" };

char8 *lan_dhcp_cond_info_params[] =
    { "cpeId", "pcpeId", "srcInterface", "vendorClassId", "ClientId",
"UserClassId",
	"macAddr", "macAddrMask", "minAddress", "maxAddress", "reservedAddr",
	    "netMask",
	"dnsServers", "domainName", "routers", "dhcpServerIpAddr", "poolOrder",
	"dhcpLease", "fEnable", "dhcpServerRelay"
};

#ifdef CONFIG_FEATURE_IPv6
char8 *lan_ipv6_mask_param_names[] =
    { "cpeId", "pcpeId", "ip6Addr", "prefix_len", "interface",
"lan_ipv6_mode" };

char8 *lan_ipv6_radvd_param_names[] =
    { "lan_radvd_cpeId", "lan_radvd_pcpeId", "lan_radvd_ip6addr",
"lan_radvd_prelen", "lan_radvd_gw6addr", "lan_radvd_dnsv6Addr", "lan_radvd_dnsv6SecAddr",
"lan_radvd_interface", "lan_radvd_fEnable" };
char8 *lan_ipv6_dhcpv6_param_names[] =
    { "lan_dhcpv6_cpeId", "lan_dhcpv6_cpeId", "lan_dhcpv6_sAddr",
"lan_dhcpv6_eAddr", "lan_dhcpv6_prelen", "lan_dhcpv6_dnsv6Addr", "lan_dhcpv6_dnsv6SecAddr",
"lan_dhcpv6_dName", "lan_dhcpv6_interface", "lan_dhcpv6_fEnable" };
#endif

char8 *lan_dhcp_static_lease_param[] =
    { "cpeId", "pcpeId", "enable", "ipAddr", "macAddr", "host" };
#define IFX_LAN_DHCP_STATIC_LEASE_COUNT 6

#define IFX_LAN_DHCP_COND_INFO_PARAM_COUNT 20

#define IFX_VALIDATE_LAN_DHCP_COND_ENTRY(p_dhcp_info, flags) { \
				char8 sBuf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN]; \
				char8 sCpeId[10], sMinAddr[MAX_IP_ADDR_LEN], sMaxAddr[MAX_IP_ADDR_LEN], sEnable[4], sMode[4]; \
				int32 nCount = 0, i = 0; \
				uint32 outflag = IFX_F_DEFAULT; \
\
                if(ifx_compare_ip_addr(p_dhcp_info->MinAddress, p_dhcp_info->MaxAddress) >= 0 && \
                     p_dhcp_info->LocallyServed == 1) { \
					ret = IFX_FAILURE; \
					goto IFX_Handler; \
                } \
\
				sprintf(sBuf, "%s_0_ipAddr", PREFIX_LAN_MAIN); \
				if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN,  \
						sBuf, IFX_F_GET_ENA, &outflag, sValue)) != IFX_SUCCESS) { \
					ret = IFX_FAILURE; \
					goto IFX_Handler; \
				} \
				if( ((ifx_compare_ip_addr(sValue, p_dhcp_info->MinAddress) >= 0) && \
					 (ifx_compare_ip_addr(sValue, p_dhcp_info->MaxAddress) <= 0)) && \
                     p_dhcp_info->LocallyServed == 1) { \
						ret = IFX_FAILURE; \
						goto IFX_Handler; \
				} \
\
              /* currently we have only one lan instance, so only checking dhcp mode of this single lan instance */ \
				sprintf(sBuf, "%s_0_dhcpMode", PREFIX_LAN_MAIN); \
				if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN,  \
						sBuf, IFX_F_GET_ENA, &outflag, sValue)) != IFX_SUCCESS) { \
					ret = IFX_FAILURE; \
		IFX_DBG("[%s:%d] 4", __FUNCTION__, __LINE__); \
					goto IFX_Handler; \
				} \
\
                if(!strcmp(sValue, "server")) { \
					sprintf(sBuf, "%s_startIp", PREFIX_LAN_DHCP_SERVER); \
					if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCPS,  \
							sBuf, IFX_F_GET_ENA, &outflag, sMinAddr)) != IFX_SUCCESS) { \
						ret = IFX_FAILURE; \
						goto IFX_Handler; \
					} \
					sprintf(sBuf, "%s_endIp", PREFIX_LAN_DHCP_SERVER); \
					if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCPS,  \
							sBuf, IFX_F_GET_ENA, &outflag, sMaxAddr)) != IFX_SUCCESS) { \
						ret = IFX_FAILURE; \
						goto IFX_Handler; \
					} \
                    if(ifx_compare_ip_addr(sMinAddr, p_dhcp_info->MaxAddress) > 0 || \
                            ifx_compare_ip_addr(sMaxAddr, p_dhcp_info->MinAddress) < 0) { \
                    } \
					else if( ((ifx_compare_ip_addr(p_dhcp_info->MinAddress, sMinAddr) >= 0) || \
						 (ifx_compare_ip_addr(p_dhcp_info->MinAddress, sMinAddr) < 0)) && \
						((ifx_compare_ip_addr(p_dhcp_info->MaxAddress, sMaxAddr) >= 0) || \
                         (ifx_compare_ip_addr(p_dhcp_info->MaxAddress, sMaxAddr) < 0)) ) { \
                        if(p_dhcp_info->LocallyServed == 1) { \
							ret = IFX_FAILURE; \
							goto IFX_Handler; \
					    } \
					} \
				} \
 \
				MAKE_SECTION_COUNT_TAG(TAG_LAN_DHCP_COND_INFO, sBuf); \
				if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCP_COND_INFO, \
				        sBuf, IFX_F_GET_ENA, &outflag, sValue)) != IFX_SUCCESS){ \
				   goto IFX_Handler; \
				} \
 \
				nCount = atoi(sValue); \
				if (nCount == 0) { \
				   ret = IFX_SUCCESS; \
				} \
				else { \
					for(i=0; i<nCount; i++) { \
						sprintf(sBuf, "%s_%d_cpeId", PREFIX_LAN_DHCP_COND_INFO, i); \
						if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCP_COND_INFO,  \
								sBuf, IFX_F_GET_ENA, &outflag, sCpeId)) != IFX_SUCCESS) { \
							continue; \
						} \
 \
						sprintf(sBuf, "%s_%d_minAddress", PREFIX_LAN_DHCP_COND_INFO, i); \
						if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCP_COND_INFO,  \
								sBuf, IFX_F_GET_ENA, &outflag, sMinAddr)) != IFX_SUCCESS) { \
							continue; \
						} \
 \
						sprintf(sBuf, "%s_%d_maxAddress", PREFIX_LAN_DHCP_COND_INFO, i); \
						if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCP_COND_INFO,  \
								sBuf, IFX_F_GET_ENA, &outflag, sMaxAddr)) != IFX_SUCCESS) { \
							continue; \
						} \
 \
						sprintf(sBuf, "%s_%d_fEnable", PREFIX_LAN_DHCP_COND_INFO, i); \
						if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCP_COND_INFO,  \
								sBuf, IFX_F_GET_ENA, &outflag, sEnable)) != IFX_SUCCESS) { \
							continue; \
						} \
 \
						sprintf(sBuf, "%s_%d_dhcpServerRelay", PREFIX_LAN_DHCP_COND_INFO, i); \
						if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCP_COND_INFO,  \
								sBuf, IFX_F_GET_ENA, &outflag, sMode)) != IFX_SUCCESS) { \
							continue; \
						} \
 \
                        if(ifx_compare_ip_addr(sMinAddr, p_dhcp_info->MaxAddress) > 0 || \
                                ifx_compare_ip_addr(sMaxAddr, p_dhcp_info->MinAddress) < 0) { \
                             continue; \
                        } \
\
						if( ((ifx_compare_ip_addr(p_dhcp_info->MinAddress, sMinAddr) >= 0) || \
                             (ifx_compare_ip_addr(p_dhcp_info->MinAddress, sMinAddr) < 0)) && \
							((ifx_compare_ip_addr(p_dhcp_info->MaxAddress, sMaxAddr) >= 0) || \
                             (ifx_compare_ip_addr(p_dhcp_info->MaxAddress, sMaxAddr) < 0)) ) { \
							if(atoi(sEnable) == IFX_ENABLED && atoi(sMode) == 1 && p_dhcp_info->LocallyServed == 1) { \
								if( (p_dhcp_info->iid.cpeId.Id != atoi(sCpeId)) && IFX_MODIFY_F_SET(flags) ) { \
									ret = IFX_FAILURE; \
									goto IFX_Handler; \
								} \
								if(IFX_INT_ADD_F_SET(flags)) { \
									ret = IFX_FAILURE; \
									goto IFX_Handler; \
								} \
							} \
						} \
					} \
				} \
			}

//////////////////////////////////////////////////////////////////////////////////////////
// vipul start 
#define IFX_VALIDATE_LAN_IP_MAC(p_dhcp_info, flags) { \
				char8 sBuf[MAX_FILELINE_LEN],sCommand[MAX_FILELINE_LEN]; \
                                char8 scpeid[10], sip[MAX_IP_ADDR_LEN], smac[MAX_MAC_ADDR_LEN],senable[4]; \
                                int32 nCount = 0, i = 0; \
                                uint32 outflag = IFX_F_DEFAULT; \
			        MAKE_SECTION_COUNT_TAG(TAG_LAN_DHCPS_STATIC_LEASE, sCommand); \
        			if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCPS_STATIC_LEASE, \
			                sCommand, flags, &outflag, sBuf)) != IFX_SUCCESS){ \
				           goto IFX_Handler; \
			        } \
		 		   nCount = atoi(sBuf); \
                                       for(i=0; i<nCount; i++) { \
                                                sprintf(sBuf, "%s_%d_cpeId", PREFIX_LAN_DHCPS_STATIC_LEASE, i); \
                                                if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCPS_STATIC_LEASE,  \
                                                                sBuf, IFX_F_GET_ENA, &outflag, scpeid)) == IFX_SUCCESS) { \
                                                        if(p_dhcp_info->iid.cpeId.Id!=atoi(scpeid)) \
                                                        { \
								sprintf(sBuf, "%s_%d_ipAddr", PREFIX_LAN_DHCPS_STATIC_LEASE, i); \
                                                		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCPS_STATIC_LEASE,  \
                                                                	sBuf, IFX_F_GET_ENA, &outflag, sip)) == IFX_SUCCESS) { \
                                             			   	if(strcmp(sip,p_dhcp_info->ipAddr)==0) \
									{ \
										ret = IFX_FAILURE; \
										goto IFX_Handler; \
									} \
								} \
                                                               sprintf(sBuf, "%s_%d_enable", PREFIX_LAN_DHCPS_STATIC_LEASE, i); \
                                                                if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCPS_STATIC_LEASE,  \
                                                                        sBuf, IFX_F_GET_ENA, &outflag, senable)) == IFX_SUCCESS) { \
                                                                        if(p_dhcp_info->enable==atoi(senable)) \
                                                                        { \
                                                                        } \
                                                                } \
								sprintf(sBuf, "%s_%d_macAddr", PREFIX_LAN_DHCPS_STATIC_LEASE, i); \
		                                                if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCPS_STATIC_LEASE,  \
                	                                                sBuf, IFX_F_GET_ENA, &outflag, smac)) == IFX_SUCCESS) { \
                        		                                 if(strcmp(smac,p_dhcp_info->macAddr)==0) \
                                        		                { \
                                                        		        ret = IFX_FAILURE; \
		                                                                goto IFX_Handler; \
                		                                        } \
                                		                } \
							} \
							else \
								continue; \
						} \
						else \
							continue; \
					} \
} \

//vipul end
///////////////////////////////////////////////////////////////////////////////////////////////////////////

/* SET APIs */

/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_lan_dhcp_server_config(...)
*		operation	==>   the operation to be performed for this route entry, can be ADD, DELETE or MODIFY
*    	dhcps_info	==>   pointer to DHCP_SERVER_INFO structure that has the dhcp server details
*    	flags		==>   flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function configures the DHCP Server paramters. It configures the dhcp server based on the
			values in the DHCP_SERVER_INFO structure and the operation which can be either ADD, DELETE or MODIFY
			of a dhcp server pool. It will also configure the hostname of the system from domain name
  			if specified.
*//////////////////////////////////////////////////////////////////////////////
#ifdef CONFIG_FEATURE_DHCP_SERVER
int32 ifx_set_lan_dhcp_server_config(int32 operation,
				     DHCP_SERVER_INFO * dhcps_info,
				     uint32 flags)
{
	int32 count = 0, changed_fcount = 0, mode = IFX_DISABLED;
	char8 sCommand[MAX_FILELINE_LEN], sMask[MAX_IP_ADDR_LEN];
	char8 sStartIP[MAX_IP_ADDR_LEN], sEndIP[MAX_IP_ADDR_LEN];
	char8 sGW[MAX_IP_ADDR_LEN], buf[MAX_DATA_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[12];
	IFX_NAME_VALUE_PAIR *array_changed_fvp = NULL;
	//  DHCP_SERVER_INFO  server;
	//  server=*dhcps_info;
	int32 ret = IFX_SUCCESS, maxLeases = 0;
	uint32 outflag = 0;
	char8 *pHostname =
	    NULL, sHostName[MAX_NAME_LEN], sHostValue[MAX_NAME_LEN];

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	NULL_TERMINATE(sGW, 0x00, sizeof(sGW));
	NULL_TERMINATE(sMask, 0x00, sizeof(sMask));
	NULL_TERMINATE(sEndIP, 0x00, sizeof(sEndIP));
	NULL_TERMINATE(sStartIP, 0x00, sizeof(sStartIP));
	NULL_TERMINATE(sHostName, 0x00, sizeof(sHostName));
	NULL_TERMINATE(sHostValue, 0x00, sizeof(sHostValue));

	memset(array_fvp, 0x00, sizeof(array_fvp));

	/*************** Prolog Block ****************/
	/* Based on operation (ADD or DEL or MOD) 
	 * append the flag with internal flags. For other ops, 
	 * the flag denotes the action */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
		flags |= IFX_F_INT_ADD;
	else
		flags |= IFX_F_MODIFY;

	/************* Validation Block **************/
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(dhcps_info)
		    /* Do simple validation of flags sucha as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

	dhcps_info->iid.cpeId.Id = 1;
	sprintf(dhcps_info->iid.cpeId.secName, "%s", TAG_LAN_DHCPS);
	dhcps_info->iid.pcpeId.Id = 1;
	sprintf(dhcps_info->iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

	/*********** Name Value Formation As Per RC.CONF ****************/
	/* Build the API Specific name value pair */
	sprintf(sGW, "%s", (char8 *) inet_ntoa(dhcps_info->ip_gw));
	sprintf(sMask, "%s", (char8 *) inet_ntoa(dhcps_info->netmask));
	sprintf(sEndIP, "%s", (char8 *) inet_ntoa(dhcps_info->end_ip));
	sprintf(sStartIP, "%s", (char8 *) inet_ntoa(dhcps_info->start_ip));

	ifx_fill_ArrayFvp_FName(array_fvp, 0, 11, lan_dhcps_param_names);

	ifx_get_maxLeases(dhcps_info->start_ip, dhcps_info->end_ip, &maxLeases);

	ifx_fill_ArrayFvp_intValues(array_fvp, 0, 5,
				    (int32 *) & dhcps_info->iid.cpeId.Id,
				    &dhcps_info->iid.pcpeId.Id, &maxLeases,
				    &dhcps_info->leasetime,
				    &dhcps_info->dhcp_mode);

	/* Domain Name if specified will be used, otherwise it will be NULL */
	ifx_fill_ArrayFvp_strValues(array_fvp, 5, 6, dhcps_info->iface, sMask,
				    sStartIP, sEndIP, sGW,
				    strlen(dhcps_info->
					   dhcp_domain_name) ? dhcps_info->
				    dhcp_domain_name : "\0");

	count = 11;

	if (strlen(dhcps_info->dhcp_domain_name) > 0) {
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, TAG_HOSTNAME, "hostname",
				    IFX_F_GET_ANY, &outflag,
				    sHostValue)) != IFX_SUCCESS) {
			goto IFX_Handler;
		}

		/* Get the new hostname from the new Domain Name specified */
		pHostname = strtok(sHostValue, ".");
		if (pHostname != NULL)
			snprintf(sHostName, sizeof(sHostName),
				 "hostname=\"%s.%s\"\n", pHostname,
				 dhcps_info->dhcp_domain_name);
		else
			snprintf(sHostName, sizeof(sHostName),
				 "hostname=\"localhost.%s\"\n",
				 dhcps_info->dhcp_domain_name);
	}

	/**************** ACL Checking Block *****************/
	/* The lan dhcp maxLeases field is a bookkeeping field. so we dont pass this field for acl checking */
	CHECK_ACL_RET(dhcps_info->iid, (count - 1), array_fvp,
		      changed_fcount, array_changed_fvp, flags, IFX_Handler)

	/********* System Config File Update Block  **********/
	    /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	    form_cfgdb_buf(buf, count, array_fvp);

	ret = ifx_SetObjData(FILE_RC_CONF, TAG_LAN_DHCPS, flags, 1, buf);

	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	ret = ifx_SetObjData(FILE_RC_CONF, TAG_HOSTNAME, flags, 1, sHostName);

	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/************ Device Configuration Block ***********/
	/* Multiple System Configuration Calls */
	/* Back up rc.conf to second temporary file before proceeding with configuration */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
		if (pHostname != NULL)
			snprintf(sCommand, sizeof(sCommand), "hostname %s.%s",
				 pHostname, dhcps_info->dhcp_domain_name);
		else
			snprintf(sCommand, sizeof(sCommand),
				 "hostname localhost.%s",
				 dhcps_info->dhcp_domain_name);

		if (system(sCommand))
			ret = IFX_SUCCESS;

		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		/* Call lan udhcpd start which will configure udhcpd.conf based on new configuration */
		mode = ifx_get_dhcp_server_mode(IFX_F_GET_ENA);
		if (dhcps_info->dhcp_mode && mode == IFX_DHCP_SERVER_MODE) {
			system("/etc/rc.d/init.d/udhcpd start");
		} else {
//			system("/etc/rc.d/killproc udhcpd");
			system("/etc/rc.d/init.d/udhcpd stop");
			unlink(UDHCPD_LEASES_FILE);

		}

		/* Rollback by stopping service with CHKPOINT_FILE2 and starting service with CHKPOINT_FILE */
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		/* Apply the new dns server ip to the dns relay server */
		sprintf(sCommand, "%s", SERVICE_DNS_RELAY_RESTART);
		if (system(sCommand))
			ret = IFX_SUCCESS;

		/* Rollback by stopping service with CHKPOINT_FILE2 and starting service with CHKPOINT_FILE */
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

	}			// IFX_DONT_ACTIVATE_F_NOT_SET

	/**************** Notification Block ******************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if (IFX_ADD_F_NOT_SET(flags) && IFX_DELETE_F_NOT_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION(dhcps_info->iid, changed_fcount,
					  array_changed_fvp, flags, IFX_Handler)
	}

	/***************** Epilog Block **********************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	/* Currently never addressed as there is no ADD/DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags)) {
		UPDATE_ID_MAP_N_ATTRIBUTES(&dhcps_info->iid, count, array_fvp,
					   flags, IFX_Handler)
	}

	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

//vipul start
int32 ifx_set_dhcps_static_lease(int32 operation,
				 IFX_MAPI_DHCPS_STATIC_LEASE * p_dhcp_info,
				 uint32 flags)
{
	int32 count = 0, passed_index = -1, ret = IFX_SUCCESS, mode = 0;
	int32 changed_count = 0;
	char8 conf_buf[MAX_DATA_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[IFX_LAN_DHCP_STATIC_LEASE_COUNT + 1],
	    *array_changed_fvp = NULL;

	NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));
	memset(array_fvp, 0, sizeof(array_fvp));

	/*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY)
	   append the flag with internal flags */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

	/**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(p_dhcp_info)
	}

	sprintf(p_dhcp_info->iid.cpeId.secName, "%s",
		TAG_LAN_DHCPS_STATIC_LEASE);
	sprintf(p_dhcp_info->iid.pcpeId.secName, "%s", TAG_LAN_DHCPS);

	p_dhcp_info->iid.pcpeId.Id = 1;	/* TODO */

	/**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		IFX_VALIDATE_LAN_IP_MAC(p_dhcp_info, flags)
	}

	/**************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_ADD_F_SET(flags)) {
		/* Allocate the IID for this vcc */
		if (ifx_get_IID(&p_dhcp_info->iid, "macAddr") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	/**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given structure for ADD/MODIFY
	   Operations */
	count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, 0,
					IFX_LAN_DHCP_STATIC_LEASE_COUNT,
					lan_dhcp_static_lease_param);

		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 2,
					    (int32 *) & p_dhcp_info->iid.cpeId.
					    Id, &p_dhcp_info->iid.pcpeId.Id);
		ifx_fill_ArrayFvp_boolValues(array_fvp, 2, 1,
					     (uchar8 *) & p_dhcp_info->enable);
		ifx_fill_ArrayFvp_strValues(array_fvp, 3, 3,
					    p_dhcp_info->ipAddr,
					    &p_dhcp_info->macAddr,
					    &p_dhcp_info->host);

		passed_index = -1;
	}

	count = IFX_LAN_DHCP_STATIC_LEASE_COUNT;

	/* Get Config Index in case of modify/delete operations from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, p_dhcp_info->iid.cpeId,
					 passed_index)
	}

	/* Determine the configuration index - for Add, Delete, Modify operations
	   Name is partial since index is not known
	   Fill array_fvp[] */
	if (ifx_get_conf_index_and_nv_pairs
	    (&p_dhcp_info->iid, passed_index, PREFIX_LAN_DHCPS_STATIC_LEASE,
	     count, array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	if (IFX_ADD_F_NOT_SET(flags)) {
		CHECK_ACL_RET(p_dhcp_info->iid, count, array_fvp,
			      changed_count, array_changed_fvp, flags,
			      IFX_Handler)
	}

	system("/etc/rc.d/init.d/udhcpd stop");

	/************** System Config File Update Block ****************/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);

	/* RC.CONF Configuration block */
	ret =
	    ifx_SetObjData(FILE_RC_CONF, TAG_LAN_DHCPS_STATIC_LEASE, flags, 1,
			   conf_buf);

	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* this will Compact the section and also update the count for both ADD and DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_LAN_DHCPS_STATIC_LEASE,
				      flags);

	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* System call to Add/Delete/Modify */

	mode = ifx_get_dhcp_server_mode(IFX_F_GET_ENA);
	if (mode != IFX_DISABLED) {
		system("/etc/rc.d/init.d/udhcpd start");
	} else {
		system("/etc/rc.d/udhcpd stop");
		unlink(UDHCPD_LEASES_FILE);
	}

	/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

	/*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_MODIFY_F_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION(p_dhcp_info->iid, changed_count,
					  array_changed_fvp, flags, IFX_Handler)
	} else if (IFX_INT_ADD_F_SET(flags)) {
		/* In case of ADD operation, first update the ID Mappings
		   and then send the Notification for the attributes */

		/*********** Epilog Block **************/
		UPDATE_ID_MAP_N_ATTRIBUTES(&p_dhcp_info->iid, count, array_fvp,
					   flags, IFX_Handler)

		    CHECK_N_SEND_NOTIFICATION(p_dhcp_info->iid, count,
					      array_fvp, flags, IFX_Handler)

		    /* Manipulate nextCpeId only for ADD operations */
		    ifx_increment_next_cpeId(FILE_RC_CONF,
					     TAG_LAN_DHCPS_STATIC_LEASE);

	} else if (IFX_DELETE_F_SET(flags)) {
		/* In case of DELETE operation, first send the notificatioupdate the ID Mappings
		   and then send the Notification for the attributes */
		/*********** Epilog Block **************/
		CHECK_N_SEND_NOTIFICATION(p_dhcp_info->iid, count, array_fvp,
					  flags, IFX_Handler)

		    UPDATE_ID_MAP_N_ATTRIBUTES(&p_dhcp_info->iid, count,
					       array_fvp, flags, IFX_Handler)
	}

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

int32 ifx_get_dhcps_static_lease(IFX_MAPI_DHCPS_STATIC_LEASE * pp_dhcp_info,
				 uint32 flags)
{
	char8 sBuf[MAX_FILELINE_LEN], *sValue = NULL;
	int32 passed_index = -1, count = 0;
	int ret = IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR array_fvp[IFX_LAN_DHCP_STATIC_LEASE_COUNT + 1];

	/* Fill the section tag */
	sprintf(pp_dhcp_info->iid.cpeId.secName, "%s",
		TAG_LAN_DHCPS_STATIC_LEASE);

	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	/* get index from cpeid */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, pp_dhcp_info->iid.cpeId,
				 passed_index)
	    sprintf(sBuf, "%s_%d_", PREFIX_LAN_DHCPS_STATIC_LEASE,
		    passed_index);
	if ((ret =
	     ifx_GetCfgObject(FILE_RC_CONF, TAG_LAN_DHCPS_STATIC_LEASE, sBuf,
			      flags, &sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	memset(array_fvp, 0x00, sizeof(array_fvp));

	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);

	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);

	/* copy the pp_dhcp_info entries into the structure */
	ifx_fill_intValues_ArrayFvp(array_fvp, 0, 2,
				    (int32 *) & pp_dhcp_info->iid.cpeId.Id,
				    &pp_dhcp_info->iid.pcpeId.Id);

	ifx_fill_boolValues_ArrayFvp(array_fvp, 2, 1,
				     (uchar8 *) & pp_dhcp_info->enable);
	ifx_fill_strValues_ArrayFvp(array_fvp, 3, 3, pp_dhcp_info->ipAddr,
				    &pp_dhcp_info->macAddr,
				    &pp_dhcp_info->host);

      IFX_Handler:
	IFX_MEM_FREE(sValue);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

int32 ifx_get_all_dhcps_static_lease(int32 * num_entries,
				     IFX_MAPI_DHCPS_STATIC_LEASE **
				     pp_dhcp_info, uint32 flags)
{
	int32 nCount = 0, nIndex = 0;
	int32 ret = IFX_SUCCESS, dhcp_count = 0;
	char8 sCommand[MAX_FILELINE_LEN], sBuf[MAX_FILELINE_LEN];
	uint32 outFlag = IFX_F_DEFAULT;

	IFX_MAPI_DHCPS_STATIC_LEASE *t_ptr = NULL;

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
	/* first, get the number of conditional entries from rc.conf */
	MAKE_SECTION_COUNT_TAG(TAG_LAN_DHCPS_STATIC_LEASE, sCommand);

	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCPS_STATIC_LEASE,
				  sCommand, flags, &outFlag,
				  sBuf)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	nCount = atoi(sBuf);
	if (nCount < 1 || nCount > 32767) {
		*num_entries = 0;
		*pp_dhcp_info = NULL;
		goto IFX_Handler;
	}
	*pp_dhcp_info = NULL;
	t_ptr = (IFX_MAPI_DHCPS_STATIC_LEASE *) IFX_MALLOC(nCount *
							   sizeof
							   (IFX_MAPI_DHCPS_STATIC_LEASE));
	if (t_ptr == NULL) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	*pp_dhcp_info = t_ptr;
	for (nIndex = 0; nIndex < nCount; nIndex++) {

		NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
		sprintf(sCommand, "%s_%d_cpeId", PREFIX_LAN_DHCPS_STATIC_LEASE,
			nIndex);
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCPS_STATIC_LEASE,
				    sCommand, flags, &outFlag,
				    sBuf)) != IFX_SUCCESS) {
			goto IFX_Handler;
		}

		(*pp_dhcp_info + dhcp_count)->iid.cpeId.Id = atoi(sBuf);

		if ((ret =
		     ifx_get_dhcps_static_lease((*pp_dhcp_info + dhcp_count),
						flags) != IFX_SUCCESS)) {
			goto IFX_Handler;
		}

		dhcp_count++;
	}
	*num_entries = dhcp_count;

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*pp_dhcp_info)
		    * num_entries = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

//vipul end

/* API assumes that existing single LAN instance has DHCP mode set to Server.
   Conditional pools are present under this global DHCP server.
 */
int32 ifx_set_dhcp_conditional_entry(int32 operation,
				     IFX_DHCP_COND_SERV_POOL * p_dhcp_info,
				     uint32 flags)
{
	uint32 outflag = IFX_F_DEFAULT;
	int32 count = 0, changed_count = 0, passed_index = -1, ret =
	    IFX_SUCCESS, mode = 0;
	char8 conf_buf[MAX_DATA_LEN], old_order[20], new_order[20], sValue[10];
	IFX_NAME_VALUE_PAIR array_fvp[IFX_LAN_DHCP_COND_INFO_PARAM_COUNT],
	    *array_changed_fvp = NULL;

	NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));
	memset(array_fvp, 0, sizeof(array_fvp));

	/*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY) 
	 * append the flag with internal flags */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

	/**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(p_dhcp_info)
		    /* Do simple validation of flags sucha as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

	sprintf(p_dhcp_info->iid.cpeId.secName, "%s", TAG_LAN_DHCP_COND_INFO);
	sprintf(p_dhcp_info->iid.pcpeId.secName, "%s", TAG_LAN_DHCPS);

	p_dhcp_info->iid.pcpeId.Id = 1;	/* TODO */

	/* currently we allow only 4 pools to be configured */
	MAKE_SECTION_COUNT_TAG(TAG_LAN_DHCP_COND_INFO, conf_buf);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCP_COND_INFO,
				  conf_buf, flags, &outflag,
				  sValue)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	if ((atoi(sValue) == 4) && IFX_INT_ADD_F_SET(flags)) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Check if the Minimum and Maximum Address matches with already existing
		 * Pool and if it is not THIS pool */
		IFX_VALIDATE_LAN_DHCP_COND_ENTRY(p_dhcp_info, flags)
	}

	/**************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_ADD_F_SET(flags)) {
		/* Allocate the IID for this vcc */
		if (ifx_get_IID(&p_dhcp_info->iid, "vendorClassId") !=
		    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	/**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given structure for ADD/MODIFY
	 * Operations 
	 */
	count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, 0,
					IFX_LAN_DHCP_COND_INFO_PARAM_COUNT,
					lan_dhcp_cond_info_params);

		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 2,
					    (int32 *) & p_dhcp_info->iid.cpeId.
					    Id, &p_dhcp_info->iid.pcpeId.Id);

		ifx_fill_ArrayFvp_strValues(array_fvp, 2, 14, p_dhcp_info->SourceInterface, &p_dhcp_info->VendorClassID, &p_dhcp_info->ClientID, &p_dhcp_info->UserClassID, &p_dhcp_info->Chaddr, &p_dhcp_info->ChaddrMask, &p_dhcp_info->MinAddress,	/* TODO */
					    &p_dhcp_info->MaxAddress,	/* TODO */
					    &p_dhcp_info->ReservedAddresses,	/* TODO */
					    &p_dhcp_info->SubnetMask,	/* TODO */
					    &p_dhcp_info->DNSServers,	/* TODO */
					    &p_dhcp_info->DomainName, &p_dhcp_info->IPRouters, &p_dhcp_info->DHCPServerIPAddress);	/* TODO */

//              ifx_fill_ArrayFvp_uintValues(array_fvp, 16, 2, &p_dhcp_info->PoolOrder, &p_dhcp_info->DHCPLeaseTime);
		sprintf(array_fvp[16].value, "%u", p_dhcp_info->PoolOrder);
		sprintf(array_fvp[17].value, "%d", p_dhcp_info->DHCPLeaseTime);

		ifx_fill_ArrayFvp_boolValues(array_fvp, 18, 2,
					     &p_dhcp_info->Enable,
					     &p_dhcp_info->LocallyServed);

		passed_index = -1;
	}

	count = IFX_LAN_DHCP_COND_INFO_PARAM_COUNT;

	/* Get Config Index in case of modify/delete operations from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, p_dhcp_info->iid.cpeId,
					 passed_index)
	}

	/* Determine the configuration index - for Add, Delete, Modify operations 
	 * Name is partial since index is not known 
	 * Fill array_fvp[] */
	if (ifx_get_conf_index_and_nv_pairs
	    (&p_dhcp_info->iid, passed_index, PREFIX_LAN_DHCP_COND_INFO, count,
	     array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	if (IFX_ADD_F_NOT_SET(flags)) {
		CHECK_ACL_RET(p_dhcp_info->iid, count, array_fvp,
			      changed_count, array_changed_fvp, flags,
			      IFX_Handler)
	}

	/* In case of Modify or Delete operation, call script to delete the routes associated
	   with the conditional pools. */

	/* We need to call stop irrespective of whether it is add/modify/del */

	//if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) && IFX_INT_ADD_F_NOT_SET(flags)) {
	system("/etc/rc.d/init.d/udhcpd stop");
	//}

	/* Ordering */
	if (IFX_MODIFY_F_SET(flags) || IFX_DELETE_F_SET(flags)) {
		sprintf(conf_buf, "%s_%d_poolOrder", PREFIX_LAN_DHCP_COND_INFO,
			passed_index);
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCP_COND_INFO,
				    conf_buf, IFX_F_GET_ANY, &outflag,
				    old_order)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		if (IFX_MODIFY_F_SET(flags)) {
			sprintf(new_order, "%d", p_dhcp_info->PoolOrder);

			if (ifx_modify_n_reorder_fvp
			    (TAG_LAN_DHCP_COND_INFO, PREFIX_LAN_DHCP_COND_INFO,
			     "poolOrder", old_order, new_order,
			     flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}
		}
	} else if (IFX_INT_ADD_F_SET(flags)
		   && p_dhcp_info->iid.config_owner == IFX_WEB) {
		/* ADD from WEB is currently not supported.. */
	}

	/************** System Config File Update Block ****************/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);

	/* RC.CONF Configuration block */
	ret =
	    ifx_SetObjData(FILE_RC_CONF, TAG_LAN_DHCP_COND_INFO, flags, 1,
			   conf_buf);

	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	if (IFX_DELETE_F_SET(flags)) {
		if (ifx_modify_n_reorder_fvp
		    (TAG_LAN_DHCP_COND_INFO, PREFIX_LAN_DHCP_COND_INFO,
		     "poolOrder", old_order, NULL, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
	}

	/* this will Compact the section and also update the count for both ADD and DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_LAN_DHCP_COND_INFO,
				      flags);

	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* System call to Add/Delete/Modify */
	//if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) && IFX_DEACTIVATE_F_NOT_SET(flags)) {
	mode = ifx_get_dhcp_server_mode(IFX_F_GET_ENA);
	if (mode != IFX_DISABLED) {
		system("/etc/rc.d/init.d/udhcpd start");
	} else {
		system("/etc/rc.d/udhcpd stop");
		unlink(UDHCPD_LEASES_FILE);
	}
	//}

	/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

	/*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_MODIFY_F_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION(p_dhcp_info->iid, changed_count,
					  array_changed_fvp, flags, IFX_Handler)
	} else if (IFX_INT_ADD_F_SET(flags)) {
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */
		/*********** Epilog Block **************/
		UPDATE_ID_MAP_N_ATTRIBUTES(&p_dhcp_info->iid, count, array_fvp,
					   flags, IFX_Handler)

		    CHECK_N_SEND_NOTIFICATION(p_dhcp_info->iid, count,
					      array_fvp, flags, IFX_Handler)

		    /* Manipulate nextCpeId only for ADD operations */
		    ifx_increment_next_cpeId(FILE_RC_CONF,
					     TAG_LAN_DHCP_COND_INFO);

	} else if (IFX_DELETE_F_SET(flags)) {
		/* In case of DELETE operation, first send the notificatioupdate the ID Mappings
		 * and then send the Notification for the attributes
		 */
		/*********** Epilog Block **************/
		CHECK_N_SEND_NOTIFICATION(p_dhcp_info->iid, count, array_fvp,
					  flags, IFX_Handler)

		    UPDATE_ID_MAP_N_ATTRIBUTES(&p_dhcp_info->iid, count,
					       array_fvp, flags, IFX_Handler)
	}

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_dhcp_server_mode(...)
*		mode		==>   mode of the Lan device such as Disable, Server or Relay
*    	flags		==>   flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
  			This function updates the Dhcp Mode with the mode passed.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_dhcp_server_mode(int32 mode, uint32 flags)
{
	int32 ret = IFX_SUCCESS, count = 0, outflag = IFX_F_DEFAULT;
	char8 sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN];
	IFX_ID iid;
	IFX_NAME_VALUE_PAIR array_fvp[4], *array_changed_fvp = NULL;

	NULL_TERMINATE(buf, 0, sizeof(buf));
	memset(&iid, 0, sizeof(iid));
	memset(array_fvp, 0, sizeof(array_fvp));

	/************* Prolog Block **************/
	/* Based on operation (ADD or DEL or MOD) 
	 * append the flag with internal flags */
	flags |= IFX_F_MODIFY;

	/************* Validation Block ************/
	/* Do simple validation of flags sucha as less than 0 */
	if (IFX_DONT_VALIDATE_F_NOT_SET(flags))
		IFX_VALIDATE_FLAGS(flags)

		    /* Read the iid structure from rc.conf */
		    sprintf(buf, "%s_0_cpeId", TAG_LAN_MAIN);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN,
				  buf, IFX_F_GET_ANY,
				  (IFX_OUT uint32 *) & outflag,
				  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	iid.cpeId.Id = atoi(sValue);
	sprintf(iid.cpeId.secName, "%s", TAG_LAN_MAIN);

	sprintf(buf, "%s_0_pcpeId", TAG_LAN_MAIN);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN,
				  buf, IFX_F_GET_ANY,
				  (IFX_OUT uint32 *) & outflag,
				  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	iid.pcpeId.Id = atoi(sValue);
	sprintf(iid.pcpeId.secName, "%s", TAG_LAN_DHCPS);

	sprintf(buf, "%s_0_dhcpMode", TAG_LAN_MAIN);
	ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, buf, IFX_F_GET_ANY,
		       (IFX_OUT uint32 *) & outflag, sValue);
	if (!strcmp(sValue, "server") && (mode != IFX_DHCP_SERVER_MODE)) {
//		system("/etc/rc.d/killproc udhcpd");
		system("/etc/rc.d/init.d/udhcpd stop");
		unlink(UDHCPD_LEASES_FILE);
	} else if (!strcmp(sValue, "relay") && (mode != IFX_DHCP_RELAY_MODE))
//		system("/etc/rc.d/killproc udhcpr");
		system("/etc/rc.d/init.d/udhcpd stop");

	/************* Name Value Formation as per RC.CONF *************/
	/* Convert the mode in string literal from the mode passed */
	NULL_TERMINATE(sValue, 0x00, sizeof(sValue));
	sprintf(sValue, "%s", ((mode == IFX_DHCP_SERVER_MODE) ? "server" :
			       ((mode ==
				 IFX_DHCP_RELAY_MODE) ? "relay" : "disable")));

	sprintf(array_fvp[0].fieldname, "%s", "lan_main_0_cpeId");
	sprintf(array_fvp[0].value, "%d", iid.cpeId.Id);
	sprintf(array_fvp[1].fieldname, "%s", "lan_main_0_pcpeId");
	sprintf(array_fvp[1].value, "%d", iid.pcpeId.Id);
	sprintf(array_fvp[2].fieldname, "%s", "lan_main_0_dhcpMode");
	sprintf(array_fvp[2].value, "%s", sValue);
	count = 3;

	/**************** ACL Checking Block *****************/
	/* This parameter is not part of any data structure. It is
	 * maintained only for WEB related configuration. So it doesn't
	 * require any ACL/NOTIFICATION Checks */

	/********* System Config File Update Block  **********/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(buf, count, array_fvp);

	/* Backup rc.conf before proceeding with configuration */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_LAN_MAIN, flags, 1, buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/**************** Notification Block ******************/
	/* Notify the Internal TR69 Stack in case of MODIFY 
	 * NOT REQUIRED - Check above */

	/***************** Epilog Block **********************/
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;

}
#endif

/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_dhcpr_dhcp_server(...)
*		operation	==> 	specified Add or delete a DHCP server IP address and the interface 
*							on which it can be reached. 
*		dhcps		==>		pointer to DHCP_RELAY_SERVER which provides the DHCP relay server configuration.
*    	flags		==>   	flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			The api will add, delete or modify a Relay server configuration parameters. Based on the
  			operation the relay server ip and interface will be configured
*//////////////////////////////////////////////////////////////////////////////
#ifdef CONFIG_FEATURE_DHCP_CLIENT
int32 ifx_set_dhcpr_dhcp_server(int32 operation, DHCP_RELAY_SERVER * dhcpr,
				uint32 flags)
{
	uint32 outflag = IFX_F_DEFAULT;
	int32 count = 0, changed_fcount = 0, ret = IFX_SUCCESS;
	char8 buf[MAX_FILELINE_LEN], *retStr = NULL;
	char8 sCommand[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[5];
	IFX_NAME_VALUE_PAIR *array_changed_fvp = NULL;

	NULL_TERMINATE(buf, 0, sizeof(buf));
	NULL_TERMINATE(sCommand, 0, sizeof(sCommand));

	/*************** Prolog Block ****************/
	/* Based on operation (ADD or DEL or MOD) 
	 * append the flag with internal flags. For other ops, 
	 * the flag denotes the action */
	if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
		flags |= IFX_F_INT_ADD;
	else
		flags |= IFX_F_MODIFY;

	/************* Validation Block **************/
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(dhcpr)
		    /* Do simple validation of flags sucha as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

	/* Get the substr (buf) of the parent lan interface which has dhcp mode relay */
	dhcpr->iid.cpeId.Id = 1;
	sprintf(dhcpr->iid.cpeId.secName, "%s", TAG_LAN_DHCP_RELAY);
	dhcpr->iid.pcpeId.Id = 1;
	sprintf(dhcpr->iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

	/*********** Name Value Formation As Per RC.CONF ****************/
	/* Build the API Specific name value pair */
	ifx_fill_ArrayFvp_FName(array_fvp, 0, 4, lan_dhcpr_param_names);

	sprintf(array_fvp[0].value, "%d", dhcpr->iid.cpeId.Id);
	sprintf(array_fvp[1].value, "%d", dhcpr->iid.pcpeId.Id);
	if (strlen(dhcpr->server_if) > 0) {
		snprintf(array_fvp[2].value, MAX_TAG_VALUE_LEN, "%s",
			 dhcpr->server_if);
	} else {
		ifx_GetObjData(FILE_RC_CONF, TAG_DEFAULT_WAN,
			       "default_wan_conn_iface", IFX_F_GET_ANY,
			       &outflag, sValue);
		sprintf(array_fvp[2].value, "%s", dhcpr->server_if);
	}
	sprintf(array_fvp[3].value, "%s",
		(char8 *) inet_ntoa(dhcpr->dhcp_relay_server));
	count = 4;

	/**************** ACL Checking Block *****************/
	CHECK_ACL_RET(dhcpr->iid, count, array_fvp,
		      changed_fcount, array_changed_fvp, flags, IFX_Handler)

	/********* System Config File Update Block  **********/
	    /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	    form_cfgdb_buf(buf, count, array_fvp);

	/* Backup rc.conf before proceeding with configuration */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
//		system("/etc/rc.d/killproc udhcpd");
		system("/etc/rc.d/init.d/udhcpd stop");
		unlink(UDHCPD_LEASES_FILE);
	}

	ret = ifx_SetObjData(FILE_RC_CONF, TAG_LAN_DHCP_RELAY, flags, 1, buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/************ Device Configuration Block ***********/
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
		sprintf(sCommand, "%s", SERVICE_LAN_RESTART);
		system(sCommand);
	}			// IFX_DONT_ACTIVATE_F_NOT_SET

	/**************** Notification Block ******************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if (IFX_ADD_F_NOT_SET(flags) && IFX_DELETE_F_NOT_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION(dhcpr->iid, changed_fcount,
					  array_changed_fvp, flags, IFX_Handler)
	}

	/***************** Epilog Block **********************/
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(retStr)
	    IFX_MEM_FREE(array_changed_fvp)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}
#endif

/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_lan_interface(...)
*		iface		==> 	The lan interface which has to be set for the lan device
*    	flags		==>   	flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
					This api takes the interface name and sets it for the lan 0th device.
  					It assumes that there is only one lan device and hence sets the interface to the same.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_lan_interface(char8 * iface, uint32 flags)
{
	int32 ret = IFX_SUCCESS, count = 0;	// changed_fcount = 0;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN];
	IFX_ID iid;
	IFX_NAME_VALUE_PAIR array_fvp[2], *array_changed_fvp = NULL;

	NULL_TERMINATE(sValue, 0, sizeof(sValue));
	NULL_TERMINATE(buf, 0, sizeof(buf));
	memset(array_fvp, 0, sizeof(array_fvp));
	memset(&iid, 0, sizeof(iid));

	/************* Prolog Block **************/
	/* Based on operation (ADD or DEL or MOD) 
	 * append the flag with internal flags */
	flags |= IFX_F_MODIFY;

	/************* Validation Block ************/
	/* Do simple validation of flags sucha as less than 0 */
	if (IFX_DONT_VALIDATE_F_NOT_SET(flags))
		IFX_VALIDATE_FLAGS(flags)

	/************* Name Value Formation as per RC.CONF *************/
		    /* Convert the mode in string literal from the mode passed */
		    sprintf(array_fvp[0].fieldname, "%s",
			    "lan_main_0_interface");
	sprintf(array_fvp[0].value, "%s", iface);
	count = 1;

	/**************** ACL Checking Block *****************/
	sprintf(buf, "%s", "lan_main_0_cpeId");
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, buf, IFX_F_GET_ANY,
			    &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	iid.cpeId.Id = atoi(sValue);
	sprintf(iid.cpeId.secName, "%s", TAG_LAN_MAIN);

	sprintf(buf, "%s", "lan_main_0_pcpeId");
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, buf, IFX_F_GET_ANY,
			    &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	iid.pcpeId.Id = atoi(sValue);
	sprintf(iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

	/********* System Config File Update Block  **********/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(buf, count, array_fvp);

	/* Backup rc.conf before proceeding with configuration */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_LAN_MAIN, flags, 1, buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* ??? Device Configuration Block ??? */
	/* Currently we dont do Device Restart, just for changing the interface name 
	 * This API is internal and not exposed outside. So no ACL/NOTIFICATION */

	/***************** Epilog Block **********************/
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_lan_ip_mask(...)
*		operation	==> 	specifies the operation to be done for the ipaddree - interface 
*							combination passed such as ADD, DELETE or MODIFY
*    	index		==>   	specifies the Lan device index for which configuration has to be done
*		name		==>		specifies the interface name
*		ip_array	==>		pointer to IP_MASK which will store the ip address and netmask
*    	flags		==>   flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
				The api either adds, deletes the ipaddress - interface combination specifies.
  				Based on the index field and interface the IP Address will be configured.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_lan_ip_mask(int32 operation, int32 index, char8 * name,
			  IP_MASK_TYPE * ip_array, uint32 flags)
{
	int32 count = 0, changed_fcount = 0, ret = IFX_SUCCESS, mode =
	    IFX_DISABLED, i = 0;
	char8 buf[MAX_DATA_LEN], sCommand[MAX_FILELINE_LEN],
	    ip[MAX_IP_ADDR_LEN], mask[MAX_IP_ADDR_LEN],
	    dns_servers[2 * MAX_IP_ADDR_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[12], *array_changed_fvp = NULL;


	if (ip_array == NULL) 
	{
                return IFX_FAILURE;
        }


	NULL_TERMINATE(ip, 0x00, sizeof(ip));
	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	NULL_TERMINATE(mask, 0x00, sizeof(mask));
	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	memset(array_fvp, 0x00, sizeof(array_fvp));

	/************* Prolog Block **************/
	/* Based on operation (ADD or DEL or MOD) 
	 * append the flag with internal flags */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
		flags |= IFX_F_INT_ADD;
	else
		flags |= IFX_F_MODIFY;

	/************* Validation Block ************/
	if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(ip_array)
		    /* Do simple validation of flags sucha as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

	/* for operations release and renew we just need to do system configuration,
	   no need to do any rc.conf updates. so we call scripts to do release and renew
	   based on the operation */
	if (operation == IFX_OP_DHCP_RELEASE) {
		sprintf(sCommand, "/etc/rc.d/init.d/udhcpc release %d", index);
		system(sCommand);

		ret = IFX_SUCCESS;
		goto IFX_Handler;
	} else if (operation == IFX_OP_DHCP_RENEW) {
		sprintf(sCommand, "/etc/rc.d/init.d/udhcpc renew %d", index);
		system(sCommand);

		ret = IFX_SUCCESS;
		goto IFX_Handler;
	}

	/************* Name Value Formation as per RC.CONF *************/
	mode = ifx_get_dhcp_server_mode(IFX_F_GET_ENA);
		ifx_fill_ArrayFvp_FName(array_fvp, 0, 12, lan_ip_mask_param_names);

		sprintf(array_fvp[0].value, "%d", ip_array->iid.cpeId.Id);
		sprintf(array_fvp[1].value, "%d", ip_array->iid.pcpeId.Id);

		sprintf(ip, "%s", (char8 *) inet_ntoa(ip_array->ip_mask.ip));
		sprintf(mask, "%s", (char8 *) inet_ntoa(ip_array->ip_mask.mask));

		ifx_fill_ArrayFvp_strValues(array_fvp, 2, 4, ip, mask,
				    (name == NULL) ? "br0" : name,
				    (mode ==
				     IFX_DHCP_SERVER_MODE) ? "server" : ((mode
									  ==
									  IFX_DHCP_RELAY_MODE)
									 ?
									 "relay"
									 :
									 "disable"));
	sprintf(array_fvp[6].value, "%s", (char8 *) inet_ntoa(ip_array->gw));

	memset(dns_servers, 0x00, sizeof(dns_servers));
	for (i = 0; i < 2; i++) {
		strcat(dns_servers, inet_ntoa(ip_array->dns_servers[i]));
		if (i < 1) {
			if (strcmp(inet_ntoa(ip_array->dns_servers[i + 1]), "0.0.0.0"))	/* check if next dns ip value is 0.0.0.0 */
				strcat(dns_servers, ",");	/* if it is not 0.0.0.0, add it to the end of the list */
			else
				break;	/* if its is 0.0.0.0 break out of the loop */
			}
		}
		sprintf(array_fvp[7].value, "%s", dns_servers);
		sprintf(array_fvp[8].value, "%d", ip_array->ip_type);
		sprintf(array_fvp[9].value, "%d", ip_array->vip_enable);
		sprintf(array_fvp[10].value, "%d", ip_array->f_enable);
		sprintf(array_fvp[11].value, "%s", ip_array->conn_name);
	count = 12;

	if (ifx_get_conf_index_and_nv_pairs(&ip_array->iid, index, TAG_LAN_MAIN,count, array_fvp,flags) != IFX_SUCCESS) 
	{
	#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/**************** ACL Checking Block *****************/
	/* Currently the structure does'nt provide the placeholder for 
	 * interface and dhcpMode. So in ACL against what parameters 
	 * will TR69 check */

		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	CHECK_ACL_RET(ip_array->iid, count - 2, array_fvp,changed_fcount, array_changed_fvp, flags, IFX_Handler)

	/********* System Config File Update Block  **********/
	    /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
    	form_cfgdb_buf(buf, count, array_fvp);

	/* Backup rc.conf before proceeding with configuration */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) 
	{
		sprintf(sCommand, "%s", SERVICE_LAN_STOP);
		system(sCommand);
	}

	ret = ifx_SetObjData(FILE_RC_CONF, TAG_LAN_MAIN, flags, 1, buf);

	/* checks if ret is not IFX_SUCCESS then restores the rc.conf with CHKPOINT_FILE */
	if (ret != IFX_SUCCESS) 
	{
	#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	#endif
		goto IFX_Handler;
	}

	/********** Device Configuration Block **************/
	/* System call to bring up the interface with the new ipaddress and netmask */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
			sprintf(sCommand, "%s",
				"/etc/rc.d/rc.bringup_lan start");

			if (system(sCommand))
				ret = IFX_SUCCESS;
			
			if (ip_array->vip_enable == IFX_ENABLED)
			{
				NULL_TERMINATE(sCommand, 0x00,sizeof(sCommand));
				sprintf(sCommand, "/usr/sbin/iptables -t nat -I POSTROUTING --source %s/%s -j RETURN", (char8 *) inet_ntoa(ip_array->ip_mask.ip), (char8 *) inet_ntoa(ip_array->ip_mask.mask));
				system(sCommand);
		
				NULL_TERMINATE(sCommand, 0x00,sizeof(sCommand));
				sprintf(sCommand, "ifconfig br0:1 %s up" , (char8 *) inet_ntoa(ip_array->ip_mask.ip));
				if (system(sCommand))
                                	ret = IFX_SUCCESS;
			}

		/* checks if ret is not IFX_SUCCESS then restores the rc.conf with CHKPOINT_FILE */
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
	}			// IFX_DONT_ACTIVATE_F_NOT_SET

	/**************** Notification Block ******************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if (IFX_MODIFY_F_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION(ip_array->iid, changed_fcount, array_changed_fvp, flags, IFX_Handler)
		
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	}

	/***************** Epilog Block **********************/
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

#ifdef CONFIG_FEATURE_IPv6
/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_lan_ula6(...)
*               operation       ==>     specifies the operation to be done for the ipaddree - interface
*                                                       combination passed such as ADD, DELETE or MODIFY
*       index           ==>     specifies the Lan device index for which configuration has to be done
*               name            ==>             specifies the interface name
*               ip_array        ==>             pointer to IP_MASK which will store the ip address and netmask
*       flags           ==>   flags that define the behaviour
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
                Description:
                                The api either adds, deletes the ipaddress - interface combination specifies.
                                  Based on the index field and interface the IP Address will be configured.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_lan_ula6(int32 operation, int32 lan_ipv6_mode, char8 * name,
		       IP6_ADDR_STRING * addrconf,
		       LAN_IPv6_SL_Config * radvd_conf,
		       LAN_IPv6_DHCPv6_Config * dhcpv6, uint32 flags)
{
	uint32 gflags = IFX_F_DEFAULT;
	uint32 outFlag = IFX_F_DEFAULT;
	int32 count = 0, ret = IFX_SUCCESS, index = 0;
	char8 buf[MAX_DATA_LEN], sCommand[MAX_FILELINE_LEN], ip[64], gw[64],
	    dns_server[64], dns_sec[64];
	char8 dhcp6s_saddr[64], dhcp6s_eaddr[64];
	IFX_NAME_VALUE_PAIR array_fvp[10];

	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	memset(array_fvp, 0x00, sizeof(array_fvp));

	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);

	/************* Prolog Block **************/
	/* Based on operation (ADD or DEL or MOD)
	 * append the flag with internal flags */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
		flags |= IFX_F_INT_ADD;
	else
		flags |= IFX_F_MODIFY;

	if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(radvd_conf)
		    /* Do simple validation of flags sucha as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

	ifx_fill_ArrayFvp_FName(array_fvp, 0, 6, lan_ipv6_mask_param_names);

	if (!inet_ntop(AF_INET6, addrconf->ip.s6_addr32, (char *)&ip, 46)) {
		IFX_DBG("/n/n ERROR in translating \n");
	}

	ifx_fill_ArrayFvp_intValues(array_fvp, 0, 2,
				    (int32 *) & addrconf->iid.cpeId.Id,
				    (int32 *) & addrconf->iid.pcpeId.Id);
	ifx_fill_ArrayFvp_strValues(array_fvp, 2, 1, ip);
	ifx_fill_ArrayFvp_intValues(array_fvp, 3, 1,
				    (int32 *) & addrconf->prefix_len);
	ifx_fill_ArrayFvp_strValues(array_fvp, 4, 1, name);
	ifx_fill_ArrayFvp_intValues(array_fvp, 5, 1, (int32 *) & lan_ipv6_mode);

	count = 6;

	if (ifx_get_conf_index_and_nv_pairs(&addrconf->iid, index, TAG_LAN_IPV6,
					    count, array_fvp,
					    flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	form_cfgdb_buf(buf, count, array_fvp);

	ret = ifx_SetObjData(FILE_RC_CONF, TAG_LAN_IPV6, flags, 1, buf);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	memset(ip, 0x00, sizeof(ip));
	memset(gw, 0x00, sizeof(gw));
	memset(buf, 0x00, sizeof(buf));
	memset(array_fvp, 0x00, sizeof(array_fvp));
	NULL_TERMINATE(dns_server, 0x00, sizeof(dns_server));
	NULL_TERMINATE(dns_sec, 0x00, sizeof(dns_sec));

	switch (lan_ipv6_mode) {
	case 0:		/* SLAAC */
		ifx_fill_ArrayFvp_FName(array_fvp, 0, 9,
					lan_ipv6_radvd_param_names);
		inet_ntop(AF_INET6, radvd_conf->ip6Addr.ip.s6_addr32,
			  (char *)&ip, 46);
		inet_ntop(AF_INET6, radvd_conf->gw6addr.ip.s6_addr32,
			  (char *)&gw, 46);
		inet_ntop(AF_INET6, radvd_conf->dnsv6Addr.ip.s6_addr32,
			  (char *)&dns_server, 46);
		inet_ntop(AF_INET6, radvd_conf->dnsv6SecAddr.ip.s6_addr32,
			  (char *)&dns_sec, 46);

		radvd_conf->iid.cpeId.Id = 1;
		radvd_conf->iid.pcpeId.Id = 1;

		sprintf(array_fvp[0].fieldname, "%s", "lan_radvd_cpeId");
		sprintf(array_fvp[0].value, "%d", radvd_conf->iid.cpeId.Id);
		sprintf(array_fvp[1].fieldname, "%s", "lan_radvd_pcpeId");
		sprintf(array_fvp[1].value, "%d", radvd_conf->iid.pcpeId.Id);

		ifx_fill_ArrayFvp_strValues(array_fvp, 2, 1, ip);
		ifx_fill_ArrayFvp_intValues(array_fvp, 3, 1,
					    &radvd_conf->ip6Addr.prefix_len);
		ifx_fill_ArrayFvp_strValues(array_fvp, 4, 3, gw, dns_server,
					    dns_sec);
		ifx_fill_ArrayFvp_strValues(array_fvp, 7, 1, name);
		ifx_fill_ArrayFvp_intValues(array_fvp, 8, 1,
					    &radvd_conf->f_enable);

		count = 9;

		form_cfgdb_buf(buf, count, array_fvp);
		ret =
		    ifx_SetObjData(FILE_RC_CONF, TAG_LAN_RADVD_IPV6, flags, 1,
				   buf);
		break;

	case 1:		/* SLAAC + Stateless DHCP */

		ifx_fill_ArrayFvp_FName(array_fvp, 0, 4,
					lan_ipv6_radvd_param_names);
		inet_ntop(AF_INET6, radvd_conf->ip6Addr.ip.s6_addr32,
			  (char *)&ip, 46);
		inet_ntop(AF_INET6, radvd_conf->gw6addr.ip.s6_addr32,
			  (char *)&gw, 46);

		radvd_conf->iid.cpeId.Id = 1;
		radvd_conf->iid.pcpeId.Id = 1;

		sprintf(array_fvp[0].fieldname, "%s", "lan_radvd_cpeId");
		sprintf(array_fvp[0].value, "%d", radvd_conf->iid.cpeId.Id);
		sprintf(array_fvp[1].fieldname, "%s", "lan_radvd_pcpeId");
		sprintf(array_fvp[1].value, "%d", radvd_conf->iid.pcpeId.Id);

		ifx_fill_ArrayFvp_strValues(array_fvp, 2, 1, ip);
		ifx_fill_ArrayFvp_intValues(array_fvp, 3, 1,
					    &radvd_conf->ip6Addr.prefix_len);

		count = 4;

		form_cfgdb_buf(buf, count, array_fvp);
		ret =
		    ifx_SetObjData(FILE_RC_CONF, TAG_LAN_RADVD_IPV6, flags, 1,
				   buf);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		memset(buf, 0x00, sizeof(buf));
		memset(array_fvp, 0x00, sizeof(array_fvp));
		memset(ip, 0x00, sizeof(ip));
		NULL_TERMINATE(dns_server, 0x00, sizeof(dns_server));
		NULL_TERMINATE(dns_sec, 0x00, sizeof(dns_sec));

		memset(dhcp6s_saddr, 0, sizeof(dhcp6s_saddr));
		memset(dhcp6s_eaddr, 0, sizeof(dhcp6s_eaddr));

		ret =
		    ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCP6S_IPV6,
				   "lan_dhcpv6_sAddr", gflags, &outFlag,
				   dhcp6s_saddr);
		if (ret != IFX_SUCCESS) {
			strcpy(dhcp6s_saddr, "::");
		}
		ret =
		    ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCP6S_IPV6,
				   "lan_dhcpv6_eAddr", gflags, &outFlag,
				   dhcp6s_eaddr);
		if (ret != IFX_SUCCESS) {
			strcpy(dhcp6s_eaddr, "::");
		}
		syslog(LOG_WARNING, "saddr = %s , eaddr = %s\n", dhcp6s_saddr,
		       dhcp6s_eaddr);

		ifx_fill_ArrayFvp_FName(array_fvp, 0, 10,
					lan_ipv6_dhcpv6_param_names);

		dhcpv6->iid.cpeId.Id = 1;
		dhcpv6->iid.pcpeId.Id = 1;

		ifx_fill_ArrayFvp_strValues(array_fvp, 2, 1, dhcp6s_saddr);
		ifx_fill_ArrayFvp_strValues(array_fvp, 3, 1, dhcp6s_eaddr);
		ifx_fill_ArrayFvp_intValues(array_fvp, 4, 1,
					    &dhcpv6->eaddr.prefix_len);

		inet_ntop(AF_INET6, dhcpv6->dnsv6Addr.ip.s6_addr32,
			  (char *)&dns_server, 46);
		inet_ntop(AF_INET6, dhcpv6->dnsv6SecAddr.ip.s6_addr32,
			  (char *)&dns_sec, 46);

		ifx_fill_ArrayFvp_strValues(array_fvp, 5, 3, dns_server,
					    dns_sec, dhcpv6->domainName ? : "");

		ifx_fill_ArrayFvp_strValues(array_fvp, 8, 1, name);
		ifx_fill_ArrayFvp_intValues(array_fvp, 9, 1, &dhcpv6->f_enable);

		count = 10;

		form_cfgdb_buf(buf, count, array_fvp);
		ret =
		    ifx_SetObjData(FILE_RC_CONF, TAG_LAN_DHCP6S_IPV6, flags, 1,
				   buf);

		break;

	case 2:		/* Stateful DHCP */

		ifx_fill_ArrayFvp_FName(array_fvp, 0, 10,
					lan_ipv6_dhcpv6_param_names);

		dhcpv6->iid.cpeId.Id = 1;
		dhcpv6->iid.pcpeId.Id = 1;

		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 2,
					    (int32 *) & dhcpv6->iid.cpeId.Id,
					    (int32 *) & dhcpv6->iid.pcpeId.Id);
		inet_ntop(AF_INET6, dhcpv6->saddr.ip.s6_addr32, (char *)&ip,
			  46);
		ifx_fill_ArrayFvp_strValues(array_fvp, 2, 1, ip);
		memset(ip, 0x00, sizeof(ip));
		inet_ntop(AF_INET6, dhcpv6->eaddr.ip.s6_addr32, (char *)&ip,
			  46);
		ifx_fill_ArrayFvp_strValues(array_fvp, 3, 1, ip);
		ifx_fill_ArrayFvp_intValues(array_fvp, 4, 1,
					    &dhcpv6->eaddr.prefix_len);

		inet_ntop(AF_INET6, dhcpv6->dnsv6Addr.ip.s6_addr32,
			  (char *)&dns_server, 46);
		inet_ntop(AF_INET6, dhcpv6->dnsv6SecAddr.ip.s6_addr32,
			  (char *)&dns_sec, 46);

		ifx_fill_ArrayFvp_strValues(array_fvp, 5, 3, dns_server,
					    dns_sec, dhcpv6->domainName ? : "");

		ifx_fill_ArrayFvp_strValues(array_fvp, 8, 1, name);
		ifx_fill_ArrayFvp_intValues(array_fvp, 9, 1, &dhcpv6->f_enable);

		count = 10;

		form_cfgdb_buf(buf, count, array_fvp);
		ret =
		    ifx_SetObjData(FILE_RC_CONF, TAG_LAN_DHCP6S_IPV6, flags, 1,
				   buf);
		break;
	default:
		IFX_DBG("[%s:%d]Unknown lanmode =%d", __FUNCTION__, __LINE__,
			lan_ipv6_mode);
	}

	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////                                               
* ifx_get_lan_ipv6(...) RAJENDRA                                                                                               
*      name            ==>     input name of the lan interface for which the lan ip                                            
*                              configuration which has to be returned                                                          
*      num_entries     ==>     number of lan connections with the interface name as name                                       
*      ip_array        ==>     pointer to an array of IP_MASK_TYPE which will store the                                        
*                              configuration for each lan device with interface as name                                        
*      flags           ==>                                                                                                     
*      Return Value :   IFX_SUCCESS or IFX_FAILURE                                                                             
               Description:                                                                                                    
                       This API reads the IP address . netmask combinations configured for the specified interface             
                       and return them as a pointer to an array of IP_MASK of ip addr and netmask.                             
                       The number of IP address and netmask entries will also be returned. The API allocates                   
                         the memory for "ip_array" and the caller is expected to free the memory allocated once done.            
*//////////////////////////////////////////////////////////////////////////////                                                
int32 ifx_get_lan_ipv6(char8 * name, int32 * num_entries,
		       LAN_IPv6_SL_Config ** ip_array,
		       IP6_ADDR_STRING * addrconf, int32 * lan_ipv6_mode,
		       uint32 flags)
{
	char8 sCommand[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN], *retStr =
	    NULL, *rretStr = NULL;
	int32 ret = IFX_SUCCESS, i = 0;
	uint32 outFlag = IFX_F_DEFAULT;
	LAN_IPv6_SL_Config *t_ptr = NULL;
	if (name == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* for the input interface name get the lan device index */
	if (ifx_ret_substr_from_distfield
	    (FILE_RC_CONF, TAG_LAN_IPV6, "interface", name,
	     &retStr) != IFX_SUCCESS) {
//#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
//#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* for the input interface name get the lan radvd device index */
	if (ifx_ret_substr_from_distfield
	    (FILE_RC_CONF, TAG_LAN_RADVD_IPV6, "interface", name,
	     &rretStr) != IFX_SUCCESS) {
//#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
//#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* Currently we assume that the number of lan entries with the same name as 1
	 * but going forward how do we resolve these name - multiple IP Addr values
	 * There should be an API to return the number of such entries */

	*num_entries = 1;
	*ip_array = NULL;

	for (i = 0; i < *num_entries; i++) {

		t_ptr = (LAN_IPv6_SL_Config *) realloc(*ip_array,
						       (i +
							1) *
						       sizeof
						       (LAN_IPv6_SL_Config));

		if (t_ptr == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}

		*ip_array = t_ptr;

		/* ZERO the realloced buffer */

		memset((*ip_array + i), 0x00, sizeof(LAN_IPv6_SL_Config));
		memset(addrconf, 0x00, sizeof(IP6_ADDR_STRING));

		/* get the cpeid for this lan device entry */
		sprintf(sCommand, "%s_lan_ipv6_mode", retStr);
		IFX_DBG("sCommand = %s \n", sCommand);
		sValue[0] = '\0';
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_IPV6, sCommand, flags,
				    &outFlag, sValue)) == IFX_SUCCESS) {
			*lan_ipv6_mode = atoi(sValue);
		}

		sprintf(sCommand, "%s_cpeId", retStr);

		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_IPV6, sCommand,
					  flags, &outFlag,
					  sValue)) != IFX_SUCCESS) {
//#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
//#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		} else {
			addrconf->iid.cpeId.Id = atoi(sValue);
			sprintf((*ip_array + i)->ip6Addr.iid.cpeId.secName,
				"%s", TAG_LAN_IPV6);
		}

		/* get the parent cpeid for this lan device entry */
		sprintf(sCommand, "%s_pcpeId", retStr);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_IPV6, sCommand,
					  flags, &outFlag,
					  sValue)) != IFX_SUCCESS) {
//#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
//#endif                                                                                                                       
			ret = IFX_FAILURE;
			goto IFX_Handler;
		} else {
			addrconf->iid.pcpeId.Id = atoi(sValue);

			sprintf(addrconf->iid.pcpeId.secName, "%s",
				TAG_LAN_IPV6);
		}

		/* get the ip address for this lan device entry */
		sprintf(sCommand, "%s_ip6Addr", retStr);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_IPV6, sCommand,
					  flags, &outFlag,
					  sValue)) != IFX_SUCCESS) {
//     #ifdef IFX_LOG_DEBUG                                                                                                    
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
//     #endif                                                                                                                  
			ret = IFX_FAILURE;
			goto IFX_Handler;
		} else
			inet_pton(AF_INET6, sValue, addrconf->ip.s6_addr);

		/* get the ipv6 prefixlength for this lan device entry */
		sprintf(sCommand, "%s_prefix_len", retStr);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_IPV6, sCommand,
					  flags, &outFlag,
					  sValue)) != IFX_SUCCESS) {
//     #ifdef IFX_LOG_DEBUG                                                                                                    
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
//     #endif                                                                                                                  

			ret = IFX_FAILURE;
			goto IFX_Handler;
		} else {
			addrconf->prefix_len = atoi(sValue);
		}

		sprintf(sCommand, "%s_ip6addr", rretStr);
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_RADVD_IPV6, sCommand,
				    flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif

			ret = IFX_FAILURE;
			goto IFX_Handler;
		} else
			inet_pton(AF_INET6, sValue,
				  (*ip_array + i)->ip6Addr.ip.s6_addr);

		/* get the ipv6 prefix for this lan device entry */
		sprintf(sCommand, "%s_prelen", rretStr);
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_RADVD_IPV6, sCommand,
				    flags, &outFlag, sValue)) != IFX_SUCCESS) {
			//#ifdef IFX_LOG_DEBUG                                                                                                 
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
			//#endif                                                                                                               
			ret = IFX_FAILURE;
			goto IFX_Handler;

		} else {
			(*ip_array + i)->ip6Addr.prefix_len = atoi(sValue);
		}

	}
      IFX_Handler:
	IFX_MEM_FREE(retStr);
	IFX_MEM_FREE(rretStr);
	if (ret != IFX_SUCCESS) {
		/* Free the memory for each IP ADD entry */
		IFX_MEM_FREE(addrconf)
		    while (i > 0) {
			IFX_MEM_FREE(ip_array[i])
			    i--;
		}
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);

		return ret;
	} else
		return IFX_SUCCESS;

}
#endif

/* int32 ifx_lan_dynamic_config(int32 operation, CPE_ID *cpe_id, uint32 flags)
{
}*/

/* GET APIs */

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_bridge_config(...)
*    	bridge_if	==>  input name of the bridge interface for which the configuration has
*				to be determined
*	bridge_cfg	==>  output pointer to BRIDGE_CONFIG which will store the bridge configuration
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function returns the present configuration for the input
			bridge interface specified. It reads the configuration by executing
			the brctl show command, parses the output and stores in bridge_cfg.
			The bridge configuration returned will be stp status, number of member
  			interfaces and their names.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_bridge_config(char8 * bridge_if, BRIDGE_CONFIG * bridge_cfg,
			    uint32 flags)
{
	FILE *fd = NULL;
	int32 i = 0, ret = IFX_SUCCESS;
	char8 sCommand[MAX_FILELINE_LEN], stp_status[10];

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(stp_status, 0x00, sizeof(stp_status));

	/* call the script with the bridge interface for which the configuration has to be read */
	sprintf(sCommand, "/etc/rc.d/rc.getBridgeStats %s", bridge_if);
	ret = system(sCommand);
	ret = IFX_SUCCESS;

	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* the script would have written the configuration in the /tmp/bridge_stats file
	 * parse the file and store the values in the output structure bridge_cfg */
	fd = fopen("/tmp/bridge_stats", "r");
	if (fd == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* copy name of the interface to output structure bridge_cfg */
	fscanf(fd, "%15s\n", bridge_cfg->bridge_if);

	/* copy stp status to output structure bridge_cfg */
	fscanf(fd, "%10s\n", stp_status);
	if (!strcmp(stp_status, "yes"))
		bridge_cfg->stp_enable = IFX_ENABLED;
	else
		bridge_cfg->stp_enable = IFX_DISABLED;

	/* copy number of interfaces configured for this bridge to output structure bridge_cfg */
	fscanf(fd, "%d\n", &bridge_cfg->num_ifs);

	/* copy each of the bridge member interfaces to output structure bridge_cfg */
	while (i < bridge_cfg->num_ifs) {
		*bridge_cfg->bridge_member_ifs =
		    (char8 *) realloc(*bridge_cfg->bridge_member_ifs,
				      (i + 1) * IFNAMSIZE);

		if (*bridge_cfg->bridge_member_ifs == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}

		fscanf(fd, "%s ", bridge_cfg->bridge_member_ifs[i]);
		i++;
	}

      IFX_Handler:
	if (fd)
		fclose(fd);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		bridge_cfg->num_ifs = 0;
		IFX_MEM_FREE(*bridge_cfg->bridge_member_ifs)
		    return ret;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_bridge_num_eth_ifs(...)
*    	bridge_if	==>  input name of the bridge interface for which the number of ethernet interfaces has to be returned
*	num_ifs		==>  output number of ethernet interfaces
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function returns the number of ethernet member interfaces for
			the given bridge interface. It executes brctl show command 
  			and parses for the number of "eth" pattern under the specified bridge_if.
*//////////////////////////////////////////////////////////////////////////////
int ifx_get_bridge_num_eth_ifs(char8 * bridge_if, int32 * num_ifs, int32 flags)
{
	FILE *fd = NULL;
	int ret = IFX_SUCCESS;
	char8 sCommand[MAX_FILELINE_LEN], sBuf[MAX_NAME_SIZE];

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));

	if (bridge_if == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* call the script with bridge interface and the pattern eth
	 * the script will write the number of interfaces with eth pattern configured
	 * for this bridge in /tmp/{bridge}_eth_ifs file */
	sprintf(sCommand, "/etc/rc.d/rc.getBridgeIfs %s eth", bridge_if);
	system(sCommand);
	sprintf(sCommand, "/tmp/%s_eth_ifs", bridge_if);

	fd = fopen(sCommand, "r");
	if (fd == NULL || feof(fd) || ferror(fd)) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* read the number of ethernet interfaces from the file into the outpute num_ifs */
	FREAD(sBuf, MAX_NAME_SIZE, 1, fd);
	if (strlen(sBuf) > 0) {
		*num_ifs = atoi(sBuf);
		ret = IFX_SUCCESS;
	} else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
	}

      IFX_Handler:
	if (fd)
		fclose(fd);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_bridge_num_usb_ifs(...)
*    	bridge_if	==>  input name of the bridge interface for which the number of usb interfaces has to be returned
*	num_ifs		==>  output number of usb interfaces
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function returns the number of usb member interfaces for
			the given bridge interface. It executes brctl show command 
  			and parses for the number of "usb" pattern under the specified bridge_if.
*//////////////////////////////////////////////////////////////////////////////
int ifx_get_bridge_num_usb_ifs(char8 * bridge_if, int32 * num_ifs, int32 flags)
{
	FILE *fd = NULL;
	int ret = IFX_SUCCESS;
	char8 sCommand[MAX_FILELINE_LEN], sBuf[MAX_NAME_SIZE];

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));

	if (bridge_if == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* call the script with bridge interface and the pattern usb
	 * the script will write the number of interfaces with usb pattern configured
	 * for this bridge in /tmp/{bridge}_usb_ifs file */
	sprintf(sCommand, "/etc/rc.d/rc.getBridgeIfs %s usb", bridge_if);
	system(sCommand);
	sprintf(sCommand, "/tmp/%s_usb_ifs", bridge_if);

	fd = fopen(sCommand, "r");
	if (fd == NULL || feof(fd) || ferror(fd)) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* read the number of usb interfaces from the file into the outpute num_ifs */
	FREAD(sBuf, MAX_NAME_SIZE, 1, fd);
	if (strlen(sBuf) > 0) {
		*num_ifs = atoi(sBuf);
		ret = IFX_SUCCESS;
	} else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
	}

      IFX_Handler:
	if (fd)
		fclose(fd);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_bridge_num_wlan_ifs(...)
*    	bridge_if	==>  input name of the bridge interface for which the number of wireless lan interfaces has to be returned
*	num_ifs		==>  output number of wlan interfaces
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function returns the number of wlan member interfaces for
			the given bridge interface. It executes brctl show command 
  			and parses for the number of "wlan" pattern under the specified bridge_if
*//////////////////////////////////////////////////////////////////////////////
int ifx_get_bridge_num_wlan_ifs(char8 * bridge_if, int32 * num_ifs, int32 flags)
{
#ifdef CONFIG_FEATURE_IFX_WIRELESS_ATH
	FILE *fd = NULL;
	int ret = IFX_SUCCESS;
	char8 sCommand[MAX_FILELINE_LEN], sBuf[MAX_NAME_SIZE];

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));

	if (bridge_if == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* call the script with bridge interface and the pattern wlan
	 * the script will write the number of interfaces with wlan pattern configured
	 * for this bridge in /tmp/{bridge}_eth_ifs file */
	sprintf(sCommand, "/etc/rc.d/rc.getBridgeIfs %s wlan", bridge_if);
	system(sCommand);
	sprintf(sCommand, "/tmp/%s_wlan_ifs", bridge_if);

	fd = fopen(sCommand, "r");
	if (fd == NULL || feof(fd) || ferror(fd)) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
	}

	/* read the number of wireless lan interfaces from the file into the outpute num_ifs */
	FREAD(sBuf, MAX_NAME_SIZE, 1, fd);
	if (strlen(sBuf) > 0) {
		*num_ifs = atoi(sBuf);
		ret = IFX_SUCCESS;
	} else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
	}

      IFX_Handler:
	if (fd)
		fclose(fd);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
#else
	*num_ifs = 0;
	return 0;
#endif
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_lan_dhcp_server_config(...)
*	dhcps_info	==>  output pointer to DHCP_SERVER_INFO which will store the dhcp server configuration
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads the dhcp server configuration from the rc.conf file
  			and returns it as in the pointer dhcps_info.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_lan_dhcp_server_config(DHCP_SERVER_INFO * dhcps_info,
				     uint32 flags)
{
#ifdef CONFIG_FEATURE_DHCP_SERVER
	char8 sValue[MAX_FILELINE_LEN];
	uint32 inflag = flags, outflag = IFX_F_DEFAULT;
	int ret = IFX_SUCCESS;

#if 0
// #705232:Pramod start
	if (ifx_GetCfgObject(FILE_RC_CONF, TAG_LAN_DHCPS, NULL, flags, buf) !=
	    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	form_array_fvp_from_cfgdb_buf(buf, &count, array_fvp);
// #705232:Pramod start
#endif

	/* The CPEID values for DHCP Server are pre-determined */
	/* get the cpeid for the dhcp server */
	if (ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCPS,
			   "lan_dhcps_cpeId", inflag, &outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	} else {
		dhcps_info->iid.cpeId.Id = atoi(sValue);
		strcpy(dhcps_info->iid.cpeId.secName, TAG_LAN_DHCPS);
	}

	/* get the parent cpeid for the dhcp server */
	if (ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCPS,
			   "lan_dhcps_pcpeId", inflag, &outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	} else {
		dhcps_info->iid.pcpeId.Id = atoi(sValue);
		strcpy(dhcps_info->iid.pcpeId.secName, TAG_LAN_DEVICE);
	}

	/* get the name of the interface on which the dhcp server is running */
	if (ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCPS,
			   "lan_dhcps_iface", inflag, &outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	} else
		snprintf(dhcps_info->iface, IFNAMSIZE, "%s", sValue);

	/* get the netmask of the dhcp server */
	if (ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCPS,
			   "lan_dhcps_netmask", inflag, &outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	} else
		dhcps_info->netmask.s_addr = inet_addr(sValue);

	/* get dhcp mode of the dhcp server which tells if the server is enabled or disabled 
	 * currently in the system */
	if (ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCPS,
			   "lan_dhcps_dhcpMode", inflag, &outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	} else
		dhcps_info->dhcp_mode = atoi(sValue);

	/* get the start ip address of the pool that this dhcp server offers */
	if (ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCPS,
			   "lan_dhcps_startIp", inflag, &outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	} else
		dhcps_info->start_ip.s_addr = inet_addr(sValue);

	/* get the end ip address of the pool that this dhcp server offers */
	if (ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCPS,
			   "lan_dhcps_endIp", inflag, &outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	} else
		dhcps_info->end_ip.s_addr = inet_addr(sValue);

	/* get the domain name of the pool that this dhcp server offers */
	if (ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCPS,
			   "lan_dhcps_domainName", inflag, &outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;

	} else {
		if (strlen(sValue) > 0)
			snprintf(dhcps_info->dhcp_domain_name,
				 MAX_DOMAIN_NAME_LEN, "%s", sValue);
		else
			snprintf(dhcps_info->dhcp_domain_name,
				 MAX_DOMAIN_NAME_LEN, "%s", "\0");
	}

	/* get the lease time offered to each of the client by this dhcp server */
	memset(sValue, '\0', sizeof(sValue));
	if (ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCPS,
			   "lan_dhcps_leasetime", inflag, &outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	} else
		dhcps_info->leasetime = atoi(sValue);

	/* get the gateway ip address */
	if (ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCPS,
			   "lan_dhcps_gw", inflag, &outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;

	} else
		dhcps_info->ip_gw.s_addr = inet_addr(sValue);

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
#else
	IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
	return IFX_FAILURE;
#endif
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_dhcp_relay_config(...)
*	dhcpr_info	==>  output pointer to DHCP_RELAY_INFO which will store the dhcp relay configuration
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads the dhcp relay configuration from the rc.conf file
  			and returns it as in the pointer dhcps_info.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_dhcp_relay_config(DHCP_RELAY_INFO * dhcpr_info, uint32 flags)
{
#ifdef CONFIG_FEATURE_DHCP_CLIENT

	char sValue[MAX_FILELINE_LEN];
	uint32 outFlag = IFX_F_DEFAULT;
	int ret = IFX_SUCCESS;

	IFX_MEM_ALLOC(dhcpr_info->dhcpr_servers, DHCP_RELAY_SERVER *, 1,
		      sizeof(DHCP_RELAY_SERVER))

	    /* The CPEID values for DHCP Relay are pre-determined */
	    /* get the cpeid for the dhcp relay */
	    memset(sValue, '\0', sizeof(sValue));
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCP_RELAY,
			    "lan_dhcp_relay_cpeId", flags, &outFlag,
			    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	} else {
		dhcpr_info->iid.cpeId.Id = atoi(sValue);
		strcpy(dhcpr_info->iid.cpeId.secName, TAG_LAN_DHCP_RELAY);
	}

	/* get the parent cpeid for the dhcp relay */
	memset(sValue, '\0', sizeof(sValue));
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCP_RELAY,
			    "lan_dhcp_relay_pcpeId", flags, &outFlag,
			    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	} else {
		dhcpr_info->iid.pcpeId.Id = atoi(sValue);
		/* No parent section for Relay interface */
		sprintf(dhcpr_info->iid.pcpeId.secName, "%s", "\0");
	}

	/* For now we assume there is only one Relay interface
	 * and only one Relay Server */
	dhcpr_info->num_dhcpr_ifs = 1;
	dhcpr_info->num_dhcp_servers = 1;

	/* get the name of the interface on which this dhcp relay server is running */
	memset(sValue, '\0', sizeof(sValue));
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCP_RELAY,
			    "lan_dhcp_relay_serverIf", flags, &outFlag,
			    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	} else {
		if (strlen(sValue) > 0) {
			memset(dhcpr_info->dhcpr_servers->server_if, '\0',
			       IFNAMSIZE);
			LTQ_STRNCPY(dhcpr_info->dhcpr_servers->server_if, sValue,
				IFNAMSIZE);
		} else
			sprintf(dhcpr_info->dhcpr_servers->server_if, "%s",
				"\0");
	}

	/* get the ip address of dhcp relay server */
	memset(sValue, '\0', sizeof(sValue));
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCP_RELAY,
			    "lan_dhcp_relay_server", flags, &outFlag,
			    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	} else
		dhcpr_info->dhcpr_servers->dhcp_relay_server.s_addr =
		    inet_addr(sValue);

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(dhcpr_info->dhcpr_servers)
		    IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
#else
	IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
	return IFX_FAILURE;
#endif
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_dhcp_server_module_support(...)
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function returns if the dhcp server support is enabled
  			in the system or not.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_dhcp_server_module_support(uint32 flags)
{
#ifdef CONFIG_FEATURE_DHCP_SERVER
	return IFX_SUPPORTED;
#else
	return IFX_NOT_SUPPORTED;
#endif
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_read_dhcp_lease_file(...)
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function returns the number of dhcp clients configured for
  			this dhcp server.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_read_dhcp_lease_file(const char *file, int *clients)
{
#ifdef CONFIG_FEATURE_DHCP_SERVER
	FILE *fd = NULL;
	char sValue[MAX_FILELINE_LEN];
	int ret = IFX_SUCCESS;
	size_t newLen = 0;
	if ((fd = popen(file, "r")) != NULL) {
		if (feof(fd) || ferror(fd)) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto end;
		}
	} else {
		/* Error on popen */
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;
	}
	newLen = fread(sValue, sizeof(char), 1, fd);
	sValue[newLen] = '\0';
	if (newLen == 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto end;
	}
	*clients = atoi(sValue);
      end:
	if (fd)
		pclose(fd);

	return ret;
#else
	return IFX_SUCCESS;
#endif
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_num_dhcp_clients(...)
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function returns the number of dhcp clients configured for
  			this dhcp server.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_num_dhcp_clients(uint32 flags)
{
#ifdef CONFIG_FEATURE_DHCP_SERVER
	//FILE  *fd = NULL;
	int clients = 0, ret = IFX_SUCCESS;
	int default_clients = 0, pool_1_clients = 0, pool_2_clients =
	    0, pool_3_clients = 0, pool_4_clients = 0;
	char sCommand[MAX_FILELINE_LEN] /*sValue[MAX_FILELINE_LEN] */ ;

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	system("killall -SIGUSR1 udhcpd");

	/* "dumpleases" can list all DHCP Client information and all line content "seconds" text
	 *  We use "grep -c" to count line, each line means one client */
	sprintf(sCommand, "%s", "dumpleases -s | grep -c seconds");
	ret = ifx_read_dhcp_lease_file(sCommand, &default_clients);
	if (ret != IFX_SUCCESS) {
		goto IFX_Handler;
	}

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	sprintf(sCommand, "%s",
		"dumpleases -s -f /var/lib/misc/udhcpd1.leases | grep -c seconds");
	ret = ifx_read_dhcp_lease_file(sCommand, &pool_1_clients);
	if (ret != IFX_SUCCESS) {
		goto IFX_Handler;
	}

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	sprintf(sCommand, "%s",
		"dumpleases -s -f /var/lib/misc/udhcpd2.leases | grep -c seconds");
	ret = ifx_read_dhcp_lease_file(sCommand, &pool_2_clients);
	if (ret != IFX_SUCCESS) {
		goto IFX_Handler;
	}

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	sprintf(sCommand, "%s",
		"dumpleases -s -f /var/lib/misc/udhcpd3.leases | grep -c seconds");
	ret = ifx_read_dhcp_lease_file(sCommand, &pool_3_clients);
	if (ret != IFX_SUCCESS) {
		goto IFX_Handler;
	}

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	sprintf(sCommand, "%s",
		"dumpleases -s -f /var/lib/misc/udhcpd4.leases | grep -c seconds");
	ret = ifx_read_dhcp_lease_file(sCommand, &pool_4_clients);

	if (ret != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	//else {
	clients =
	    default_clients + pool_1_clients + pool_2_clients + pool_3_clients +
	    pool_4_clients;
	//}

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return IFX_FAILURE;
	} else
		return clients;
#else
	return 0;
#endif
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_lan_dhcp_leases(...)
*	num_leases	==>	output number of leases
*	lease_entries	==>	pointer to array of DHCP_LEASE_INFO which stores information
*				about each of the lease offered.
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function gets the information about each of the offered leases
			by executing the dumpleases command and stores them in the
  			output array lease_entries
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_lan_dhcp_leases(int32 * num_leases,
			      DHCP_LEASE_INFO ** lease_entries, uint32 flags)
{

	char sMac[MAX_MAC_ADDR_LEN], sIP[MAX_IP_ADDR_LEN],
	    sValue[MAX_FILELINE_LEN], sCommand[MAX_FILELINE_LEN];
	char8 sHost[MAX_HOST_NAME];
	FILE *fp = NULL;
	int i = 0, ret = IFX_SUCCESS;

	NULL_TERMINATE(sIP, 0x00, sizeof(sIP));
	NULL_TERMINATE(sMac, 0x00, sizeof(sMac));
	NULL_TERMINATE(sValue, 0x00, sizeof(sValue));
	NULL_TERMINATE(sHost, 0x00, sizeof(sHost));
	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));

	/* get the number of leases already offered by the dhcp server */
	*num_leases = ifx_get_num_dhcp_clients(flags);
	if (*num_leases <= 0 || *num_leases > 32767) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_SUCCESS;
		goto IFX_Handler;
	}

	IFX_MEM_ALLOC((*lease_entries), DHCP_LEASE_INFO *, *num_leases,
		      sizeof(DHCP_LEASE_INFO))

	    if (*lease_entries == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] No memory allocated", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	system("killall -SIGUSR1 udhcpd");

	sprintf(sCommand, "%s",
		"dumpleases -s |sed '1d'|grep seconds |sed 's/seconds//'");
	fp = popen(sCommand, "r");
	/* for each of the offered leases copy the lease configuration into the
	 * output array lease_entries */
	if (fp != NULL) {
		for (i = 0; i < *num_leases; i++) {
			if (fscanf
			    (fp, "%s %s %s %s\n", sMac, sIP, sHost,
			     sValue) > 0) {
				strcpy((*lease_entries + i)->cli_id, sMac);
				(*lease_entries + i)->ip.s_addr =
				    inet_addr(sIP);
				(*lease_entries + i)->lease_time_left =
				    atoi(sValue);
				strncpy((*lease_entries + i)->host_name, sHost,
					MAX_HOST_NAME - 1);

				//i++;
				NULL_TERMINATE(sMac, 0x00, sizeof(sMac));
				NULL_TERMINATE(sIP, 0x00, sizeof(sIP));
				/* ??? How do we fill in IID values for these dynamic entries ??? */
			} else {
				break;
			}
		}
		pclose(fp);
	}

	sprintf(sCommand, "%s",
		"dumpleases -s -f /var/lib/misc/udhcpd1.leases |sed '1d'|grep seconds|sed 's/seconds//'");
	fp = popen(sCommand, "r");
	/* for each of the offered leases copy the lease configuration into the
	 * output array lease_entries */
	if (fp != NULL) {
		for (; i < *num_leases; i++) {
			if (fscanf
			    (fp, "%s %s %s %s\n", sMac, sIP, sHost,
			     sValue) > 0) {
				strcpy((*lease_entries + i)->cli_id, sMac);
				(*lease_entries + i)->ip.s_addr =
				    inet_addr(sIP);
				(*lease_entries + i)->lease_time_left =
				    atoi(sValue);
				strncpy((*lease_entries + i)->host_name, sHost,
					MAX_HOST_NAME - 1);
				//i++;
				NULL_TERMINATE(sMac, 0x00, sizeof(sMac));
				NULL_TERMINATE(sIP, 0x00, sizeof(sIP));
				/* ??? How do we fill in IID values for these dynamic entries ??? */
			} else {
				break;
			}
		}
		pclose(fp);
	}

	sprintf(sCommand, "%s",
		"dumpleases -s -f /var/lib/misc/udhcpd2.leases |sed '1d'|grep seconds|sed 's/seconds//'");
	fp = popen(sCommand, "r");
	/* for each of the offered leases copy the lease configuration into the
	 * output array lease_entries */
	if (fp != NULL) {
		for (; i < *num_leases; i++) {
			if (fscanf
			    (fp, "%s %s %s %s\n", sMac, sIP, sHost,
			     sValue) > 0) {
				strcpy((*lease_entries + i)->cli_id, sMac);
				(*lease_entries + i)->ip.s_addr =
				    inet_addr(sIP);
				(*lease_entries + i)->lease_time_left =
				    atoi(sValue);
				strncpy((*lease_entries + i)->host_name, sHost,
					MAX_HOST_NAME - 1);
				//i++;
				NULL_TERMINATE(sMac, 0x00, sizeof(sMac));
				NULL_TERMINATE(sIP, 0x00, sizeof(sIP));
				/* ??? How do we fill in IID values for these dynamic entries ??? */
			} else {
				break;
			}
		}
		pclose(fp);
	}

	sprintf(sCommand, "%s",
		"dumpleases -s -f /var/lib/misc/udhcpd3.leases |sed '1d'|grep seconds|sed 's/seconds//'");
	fp = popen(sCommand, "r");
	/* for each of the offered leases copy the lease configuration into the
	 * output array lease_entries */
	if (fp != NULL) {
		for (; i < *num_leases; i++) {
			if (fscanf
			    (fp, "%s %s %s %s\n", sMac, sIP, sHost,
			     sValue) > 0) {
				strcpy((*lease_entries + i)->cli_id, sMac);
				(*lease_entries + i)->ip.s_addr =
				    inet_addr(sIP);
				(*lease_entries + i)->lease_time_left =
				    atoi(sValue);
				strncpy((*lease_entries + i)->host_name, sHost,
					MAX_HOST_NAME - 1);
				//i++;
				NULL_TERMINATE(sMac, 0x00, sizeof(sMac));
				NULL_TERMINATE(sIP, 0x00, sizeof(sIP));
				/* ??? How do we fill in IID values for these dynamic entries ??? */
			} else {
				break;
			}
		}
		pclose(fp);
	}

	sprintf(sCommand, "%s",
		"dumpleases -s -f /var/lib/misc/udhcpd4.leases |sed '1d'|grep seconds|sed 's/seconds//'");
	fp = popen(sCommand, "r");
	/* for each of the offered leases copy the lease configuration into the
	 * output array lease_entries */
	if (fp != NULL) {
		for (; i < *num_leases; i++) {
			if (fscanf
			    (fp, "%s %s %s %s\n", sMac, sIP, sHost,
			     sValue) > 0) {
				strcpy((*lease_entries + i)->cli_id, sMac);
				(*lease_entries + i)->ip.s_addr =
				    inet_addr(sIP);
				(*lease_entries + i)->lease_time_left =
				    atoi(sValue);
				strncpy((*lease_entries + i)->host_name, sHost,
					MAX_HOST_NAME - 1);
				//i++;
				NULL_TERMINATE(sMac, 0x00, sizeof(sMac));
				NULL_TERMINATE(sIP, 0x00, sizeof(sIP));
				/* ??? How do we fill in IID values for these dynamic entries ??? */
			} else {
				break;
			}
		}
		pclose(fp);
	}

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*lease_entries)
		    IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;

}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_dhcp_server_mode(...)
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads the dhcp server mode from lan_main section
  			in rc.conf and returns the enumeration for the mode read.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_dhcp_server_mode(uint32 flags)
{
#ifdef CONFIG_FEATURE_DHCP_SERVER
	char8 sValue[MAX_NAME_SIZE];
	int32 dhcp_mode = 0;
	int32 ret = IFX_SUCCESS;
	uint32 inflag = flags, outflag = 0;

	/* here we assume that there is only one lan device that exists in the system
	 * and hence the lan dhcp server or relay runs on the same interface only */
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN,
				  "lan_main_0_dhcpMode", inflag, &outflag,
				  sValue)) == IFX_SUCCESS) {
		if (!strcmp(sValue, "server"))	//DHCP Enable
			dhcp_mode = IFX_DHCP_SERVER_MODE;
		else if (!strcmp(sValue, "relay"))	//DHCP Enable
			dhcp_mode = IFX_DHCP_RELAY_MODE;
		else		//DHCP Disable
			dhcp_mode = IFX_DISABLED;
		goto IFX_Handler;
	} else {
		dhcp_mode = IFX_DISABLED;
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return dhcp_mode;
#else
	IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
	return IFX_FAILURE;
#endif
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_lan_ip_mask(...)
*	name		==>	input name of the lan interface for which the lan ip
*				configuration which has to be returned
*	num_entries	==>	number of lan connections with the interface name as name
*	ip_array	==>	pointer to an array of IP_MASK_TYPE which will store the
*				configuration for each lan device with interface as name 
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This API reads the IP address . netmask combinations configured for the specified interface 
			and return them as a pointer to an array of IP_MASK of ip addr and netmask.
			The number of IP address and netmask entries will also be returned. The API allocates 
  			the memory for "ip_array" and the caller is expected to free the memory allocated once done.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_lan_ip_mask(char8 * name, int32 * num_entries,
			  IP_MASK_TYPE ** ip_array, uint32 flags)
{
	char8 sCommand[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN], *retStr = NULL, *ptr = NULL, *tptr = NULL;
	int32 ret = IFX_SUCCESS, i = 0;
	uint32 outFlag = IFX_F_DEFAULT;
	IP_MASK_TYPE *t_ptr = NULL;

	if (name == NULL) 
	{
	#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* for the input interface name get the lan device index */
	if (ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_LAN_MAIN, "interface", name,&retStr) != IFX_SUCCESS) 
	{
	#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* Currently we assume that the number of lan entries with the same name as 1 
	 * but going forward how do we resolve these name - multiple IP Addr values 
	 * There should be an API to return the number of such entries */

	*num_entries = 1;
	*ip_array = NULL;

	for (i = 0; i < *num_entries; i++) {

		t_ptr = (IP_MASK_TYPE *) realloc(*ip_array, (i + 1) * sizeof(IP_MASK_TYPE));
		if (t_ptr == NULL) 
		{
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}

		*ip_array = t_ptr;

		/* ZERO the realloced buffer */
		memset((*ip_array + i), 0x00, sizeof(IP_MASK_TYPE));

		/* get the cpeid for this lan device entry */
		sprintf(sCommand, "%s_cpeId", retStr);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, sCommand, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		} else {
			(*ip_array + i)->iid.cpeId.Id = atoi(sValue);
			sprintf((*ip_array + i)->iid.cpeId.secName, "%s",
				TAG_LAN_MAIN);
		}

		/* get the parent cpeid for this lan device entry */
		sprintf(sCommand, "%s_pcpeId", retStr);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, sCommand,
					  flags, &outFlag,
					  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		} else {
			(*ip_array + i)->iid.pcpeId.Id = atoi(sValue);
			sprintf((*ip_array + i)->iid.pcpeId.secName, "%s",
				TAG_LAN_DHCPS);
		}

  /* get the enable status of this lan device entry */
                sprintf(sCommand, "%s_VIPEnable", retStr);
                if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, sCommand,
                                          flags, &outFlag,
                                          sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                        ret = IFX_FAILURE;
                        goto IFX_Handler;
                } else
                        (*ip_array + i)->vip_enable = atoi(sValue);

		/* get the enable status of this lan device entry */
		sprintf(sCommand, "%s_fEnable", retStr);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, sCommand,
					  flags, &outFlag,
					  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		} else
			(*ip_array + i)->f_enable = atoi(sValue);

		/* get the enable status of this lan device entry */
		sprintf(sCommand, "%s_connName", retStr);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, sCommand,
					  flags, &outFlag,
					  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		} else
			snprintf((*ip_array + i)->conn_name,
                                         MAX_NAME_LEN, "%s", sValue);
		/* get the addressing type for this lan device entry */
		sprintf(sCommand, "%s_ipAddrType", retStr);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, sCommand,
					  flags, &outFlag,
					  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		} else
			(*ip_array + i)->ip_type = atoi(sValue);
		
		if ((*ip_array + i)->ip_type == IP_TYPE_STATIC) {
			/* get the ip address for this lan device entry */
			sprintf(sCommand, "%s_ipAddr", retStr);
			if ((ret =
			     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN,
					    sCommand, flags, &outFlag,
					    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			} else
				(*ip_array + i)->ip_mask.ip.s_addr =
				    inet_addr(sValue);

			/* get the network ip address for this lan device entry */
			sprintf(sCommand, "%s_netmask", retStr);
			if ((ret =
			     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN,
					    sCommand, flags, &outFlag,
					    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			} else
				(*ip_array + i)->ip_mask.mask.s_addr =
				    inet_addr(sValue);

			sprintf(sCommand, "%s_gw", retStr);
			if ((ret =
			     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN,
					    sCommand, flags, &outFlag,
					    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			} else
				(*ip_array + i)->gw.s_addr = inet_addr(sValue);

			sprintf(sCommand, "%s_DNSServers", retStr);
			if ((ret =
			     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN,
					    sCommand, flags, &outFlag,
					    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			} else {
				ptr = strtok_r(sValue, ",", &tptr);
				if (ptr != NULL) {
					(*ip_array + i)->dns_servers[0].s_addr =
					    inet_addr(ptr);
					ptr = strtok_r(NULL, ",", &tptr);
					if (ptr != NULL) {
						(*ip_array +
						 i)->dns_servers[1].s_addr =
					inet_addr(ptr);
					}
				}
			}
		} else if ((*ip_array + i)->ip_type == IP_TYPE_DHCP) {
			/* get the ip address for this lan device entry */
			sprintf(sCommand, "Lan%d_IF_Info", i);
			if (ifx_GetObjData(FILE_SYSTEM_STATUS, sCommand, "IP",
					   flags, &outFlag,
					   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				(*ip_array + i)->ip_mask.ip.s_addr =
				    inet_addr("0.0.0.0");
			} else
				(*ip_array + i)->ip_mask.ip.s_addr =
				    inet_addr(sValue);

			/* get the network ip address for this lan device entry */
			if (ifx_GetObjData(FILE_SYSTEM_STATUS, sCommand, "MASK",
					   flags, &outFlag,
					   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				(*ip_array + i)->ip_mask.mask.s_addr =
				    inet_addr("0.0.0.0");
			} else
				(*ip_array + i)->ip_mask.mask.s_addr =
				    inet_addr(sValue);

#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	
		sprintf(sCommand, "Lan%d_GATEWAY", i);
			if (ifx_GetObjData
			    (FILE_SYSTEM_STATUS, sCommand, "ROUTER1", flags,
			     &outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				(*ip_array + i)->gw.s_addr =
				    inet_addr("0.0.0.0");
			} else
				(*ip_array + i)->gw.s_addr = inet_addr(sValue);

			sprintf(sCommand, "Lan%d_DNS_SERVER", i);
			if (ifx_GetObjData(FILE_SYSTEM_STATUS, sCommand, "DNS1",
					   flags, &outFlag,
					   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				(*ip_array + i)->dns_servers[0].s_addr =
				    inet_addr("0.0.0.0");
			} else
				(*ip_array + i)->dns_servers[0].s_addr =
				    inet_addr(sValue);

			if (ifx_GetObjData(FILE_SYSTEM_STATUS, sCommand, "DNS2",
					   flags, &outFlag,
					   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				(*ip_array + i)->dns_servers[1].s_addr =
				    inet_addr("0.0.0.0");
			} else
				(*ip_array + i)->dns_servers[1].s_addr =
				    inet_addr(sValue);

			sprintf(sCommand, "Lan%d_DOMAIN", i);
			if (ifx_GetObjData
			    (FILE_SYSTEM_STATUS, sCommand, "DOMAIN", flags,
			     &outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				//sprintf((*ip_array + i) ->domainname, "%s", NULL);
				strcpy((*ip_array + i)->domainname, "");
			} else
				snprintf((*ip_array + i)->domainname,
					 MAX_DOMAIN_NAME_LEN, "%s", sValue);
		}
	}

      IFX_Handler:
	IFX_MEM_FREE(retStr)
	    if (ret != IFX_SUCCESS) {
		/* Free the memory for each IP ADD entry */
		while (i > 0) {
			IFX_MEM_FREE(ip_array[i])
			    i--;
		}
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

int32 ifx_get_one_lan_ip_mask(int32 index, IP_MASK_TYPE * ip_mask, uint32 flags)
{
	char8 sCommand[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN], *ptr =
	    NULL, *tptr = NULL;
	int32 ret = IFX_SUCCESS, i = 0, lan_index = -1;
	uint32 outFlag = IFX_F_DEFAULT;

	if (index < 0) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, ip_mask->iid.cpeId,
					 lan_index)
	} else {
		lan_index = index;

		/* get the cpeid for this lan device entry */
		sprintf(sCommand, "%s_%d_cpeId", PREFIX_LAN_MAIN, lan_index);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, sCommand,
					  flags, &outFlag,
					  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		} else {
			ip_mask->iid.cpeId.Id = atoi(sValue);
			sprintf(ip_mask->iid.cpeId.secName, "%s", TAG_LAN_MAIN);
		}

		/* get the parent cpeid for this lan device entry */
		sprintf(sCommand, "%s_%d_pcpeId", PREFIX_LAN_MAIN, lan_index);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, sCommand,
					  flags, &outFlag,
					  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		} else {
			ip_mask->iid.pcpeId.Id = atoi(sValue);
			sprintf(ip_mask->iid.pcpeId.secName, "%s",
				TAG_LAN_DHCPS);
		}
	}

	/* get the enable status of this lan device entry */
	sprintf(sCommand, "%s_%d_fEnable", PREFIX_LAN_MAIN, lan_index);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, sCommand,
				  flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	} else
		ip_mask->f_enable = atoi(sValue);

	/* get the addressing type for this lan device entry */
	sprintf(sCommand, "%s_%d_ipAddrType", PREFIX_LAN_MAIN, lan_index);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, sCommand,
				  flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	} else
		ip_mask->ip_type = atoi(sValue);

	if (ip_mask->ip_type == IP_TYPE_STATIC) {
		/* get the ip address for this lan device entry */
		sprintf(sCommand, "%s_%d_ipAddr", PREFIX_LAN_MAIN, lan_index);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, sCommand,
					  flags, &outFlag,
					  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		} else
			ip_mask->ip_mask.ip.s_addr = inet_addr(sValue);

		/* get the network ip address for this lan device entry */
		sprintf(sCommand, "%s_%d_netmask", PREFIX_LAN_MAIN, lan_index);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, sCommand,
					  flags, &outFlag,
					  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		} else
			ip_mask->ip_mask.mask.s_addr = inet_addr(sValue);

		sprintf(sCommand, "%s_%d_gw", PREFIX_LAN_MAIN, lan_index);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, sCommand,
					  flags, &outFlag,
					  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		} else
			ip_mask->gw.s_addr = inet_addr(sValue);

		sprintf(sCommand, "%s_%d_DNSServers", PREFIX_LAN_MAIN,
			lan_index);
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, sCommand, flags,
				    &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		} else {
			ptr = strtok_r(sValue, ",", &tptr);
			if (ptr != NULL) {
				ip_mask->dns_servers[0].s_addr = inet_addr(ptr);
				ptr = strtok_r(NULL, ",", &tptr);
				if (ptr != NULL) {
					ip_mask->dns_servers[1].s_addr =
					    inet_addr(ptr);
				}
			}
		}
	} else if (ip_mask->ip_type == IP_TYPE_DHCP) {
		/* get the ip address for this lan device entry */
		sprintf(sCommand, "Lan%d_IF_Info", i);
		if (ifx_GetObjData(FILE_SYSTEM_STATUS, sCommand, "IP",
				   flags, &outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ip_mask->ip_mask.ip.s_addr = inet_addr("0.0.0.0");
		} else
			ip_mask->ip_mask.ip.s_addr = inet_addr(sValue);

		/* get the network ip address for this lan device entry */
		if (ifx_GetObjData(FILE_SYSTEM_STATUS, sCommand, "MASK",
				   flags, &outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ip_mask->ip_mask.mask.s_addr = inet_addr("0.0.0.0");
		} else
			ip_mask->ip_mask.mask.s_addr = inet_addr(sValue);

		sprintf(sCommand, "Lan%d_GATEWAY", i);
		if (ifx_GetObjData(FILE_SYSTEM_STATUS, sCommand, "ROUTER1",
				   flags, &outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ip_mask->gw.s_addr = inet_addr("0.0.0.0");
		} else
			ip_mask->gw.s_addr = inet_addr(sValue);

		sprintf(sCommand, "Lan%d_DNS_SERVER", i);
		if (ifx_GetObjData(FILE_SYSTEM_STATUS, sCommand, "DNS1",
				   flags, &outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ip_mask->dns_servers[0].s_addr = inet_addr("0.0.0.0");
		} else
			ip_mask->dns_servers[0].s_addr = inet_addr(sValue);

		if (ifx_GetObjData(FILE_SYSTEM_STATUS, sCommand, "DNS2",
				   flags, &outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ip_mask->dns_servers[1].s_addr = inet_addr("0.0.0.0");
		} else
			ip_mask->dns_servers[1].s_addr = inet_addr(sValue);

		sprintf(sCommand, "Lan%d_DOMAIN", i);
		if (ifx_GetObjData(FILE_SYSTEM_STATUS, sCommand, "DOMAIN",
				   flags, &outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			sprintf(ip_mask->domainname, "%s", "");
		} else {
			snprintf(ip_mask->domainname, MAX_DOMAIN_NAME_LEN, "%s",
				 sValue);
		}
	}

      IFX_Handler:
	return ret;
}

static int32 ifx_get_lan_arp_entries(int32 * num_entries, LAN_HOST_INFO ** host)
{
	FILE *fp = NULL;
	char8 sCommand[MAX_FILELINE_LEN], sIP[MAX_IP_ADDR_LEN], 
	      sMac[MAX_MAC_ADDR_LEN], sIface[32], sFlags[8], 
	      sHWType[8], sMask[8], sBuf[1024];
	int32 iRet = IFX_FAILURE, arp_count = 0;

	*host = NULL;

	sprintf(sCommand, "%s", "cat /proc/net/arp");
	fp = popen(sCommand, "r");
	if (fp != NULL) {
		fgets(sBuf, sizeof(sBuf), fp);
		while(fgets(sBuf, sizeof(sBuf), fp)) {
			sscanf(sBuf, "%s %s %s %s %s %s", sIP, sHWType, sFlags, sMac, 
			             sMask, sIface);
			if (strncmp(sIface, "br0", 3))
				continue;
			arp_count += 1;
			*host = realloc(*host, sizeof(LAN_HOST_INFO) * arp_count);
			(*host + (arp_count - 1))->ipAddr.s_addr = inet_addr(sIP);
			sprintf((*host + (arp_count - 1))->macAddr, "%s", sMac);
			(*host + (arp_count - 1))->ipAddrType = LAN_HOST_STATIC_TYPE;
			(*host + (arp_count - 1))->leaseTimeRem = 0;
			(*host + (arp_count - 1))->hostName[0] = '\0';
			(*host + (arp_count - 1))->phyIfType = PHY_IF_ETHER_TYPE;
			(*host + (arp_count - 1))->status = LAN_HOST_STATUS_ACTIVE;
		}
		*num_entries = arp_count;
		pclose(fp);
		return IFX_SUCCESS;
	}

	return iRet;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_lan_hosts(...)
*	num_entries	==>	output number of host entries returned in *host
*	host		==>	output array of host entries
*	hType		==>	input host type (eth, usb ..)
*	lanIfName	==>	input interface name for which the host entries will be retrieved
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This API returns the details of hosts under the input lanIfName of type hType. the hosts' detailes will
			be returned in the array host.
  			Currently the api can only return the hosts of type dhcp connected to the brided interface.
*//////////////////////////////////////////////////////////////////////////////
#if 0
int32 ifx_get_lan_hosts(int32 * num_entries, LAN_HOST_INFO ** host,
			LAN_HOST_TYPE hType, char8 * lanIfName, uint32 flags)
{
	int32 num_leases = 0, ret = IFX_SUCCESS, i = 0;
	DHCP_LEASE_INFO *lease_entries = NULL;

	if (hType == LAN_HOST_ALL_TYPE || hType == LAN_HOST_DHCP_TYPE) {
		if (ifx_get_lan_dhcp_leases(&num_leases, &lease_entries, flags)
		    != IFX_SUCCESS) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		if (num_leases < 0 || num_leases > 32767)
		{
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		IFX_MEM_ALLOC((*host), LAN_HOST_INFO *, num_leases,
			      sizeof(LAN_HOST_INFO))

		    for (i = 0; i < num_leases; i++) {
			(*host + i)->ipAddr = (lease_entries + i)->ip;
			(*host + i)->ipAddrType = LAN_HOST_DHCP_TYPE;
			(*host + i)->leaseTimeRem =
			    (lease_entries + i)->lease_time_left;
			sprintf((*host + i)->macAddr, "%s",
				(lease_entries + i)->cli_id);
			strncpy((*host + i)->hostName, 
			   (lease_entries + i)->host_name, MAX_HOST_LEN - 1);
			(*host + i)->phyIfType = PHY_IF_ETHER_TYPE;
			(*host + i)->status = LAN_HOST_STATUS_ACTIVE;
		}

		*num_entries = num_leases;
	}

      IFX_Handler:
	IFX_MEM_FREE(lease_entries)
	    if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*host)
		    IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}
#else
int32 ifx_get_lan_hosts(int32 * num_entries, LAN_HOST_INFO ** host,
			LAN_HOST_TYPE hType, char8 * lanIfName, uint32 flags)
{
	int32 num_leases = 0, ret = IFX_SUCCESS, i = 0, j = 0;
	DHCP_LEASE_INFO *lease_entries = NULL;
	LAN_HOST_INFO *arp_entries = NULL;
	int32 num_arp_entries = 0, arp_count = 0;
        LAN_HOST_INFO * pTmpHost = NULL;
        FILE *fp = NULL;
        char8 sMacList[640] ={0} , sBuf[64] = {0};
        int32 iI = 0;

        if(host != NULL)
	{
		*host = NULL;
	}
	else
	{
		IFX_DBG("[%s:%d] ERROR: Invalid input!!!", __FUNCTION__, __LINE__);
		goto IFX_Handler; 
	}
	*num_entries = 0; /*Initialise*/

        fp = popen("mtdump wlan0 PeerList" , "r");
        if(fp!=NULL){
            while((fgets(sBuf, 64 , fp)) != NULL) {
                strcat(sMacList,sBuf);
                strcat(sMacList," ");
            }
            pclose(fp);
        }
        else
            IFX_DBG("[%s:%d]popen failed!!!", __FUNCTION__, __LINE__);

	if (hType == LAN_HOST_DHCP_TYPE)
	{
		if (ifx_get_lan_dhcp_leases(&num_leases, &lease_entries, flags) != IFX_SUCCESS)
		{
			ret = IFX_FAILURE;
			IFX_MEM_FREE(lease_entries)
			return ret;
		}
		if (num_leases < 0 || num_leases > 32767)
		{
			ret = IFX_FAILURE;
			IFX_MEM_FREE(lease_entries)
			return ret;
		}
		if(num_leases != 0)
		{
			IFX_MEM_ALLOC((*host), LAN_HOST_INFO *, num_leases,
			      sizeof(LAN_HOST_INFO))

			for (i = 0; i < num_leases; i++)
			{
				(*host + i)->ipAddr = (lease_entries + i)->ip;
				(*host + i)->ipAddrType = LAN_HOST_DHCP_TYPE;
				(*host + i)->leaseTimeRem = (lease_entries + i)->lease_time_left;
				sprintf((*host + i)->macAddr, "%s", (lease_entries + i)->cli_id);
				strncpy((*host + i)->hostName, (lease_entries + i)->host_name, MAX_HOST_LEN - 1);
                                strcpy(sBuf,(*host + i)->macAddr);
                                for(iI=0;iI<strlen(sBuf);iI++)
                                    sBuf[iI]=toupper(sBuf[iI]);
                                if((strstr(sMacList ,((*host + i)->macAddr))) || (strstr(sMacList,sBuf)))
                                    (*host + i)->phyIfType = PHY_IF_802_11_TYPE;
                                else
				(*host + i)->phyIfType = PHY_IF_ETHER_TYPE;
				(*host + i)->status = LAN_HOST_STATUS_ACTIVE;
			}
		}
		*num_entries = num_leases;
		IFX_MEM_FREE(lease_entries)
		return IFX_SUCCESS;
	}
	else if (hType == LAN_HOST_STATIC_TYPE)
	{
		if (ifx_get_lan_dhcp_leases(&num_leases, &lease_entries, flags) != IFX_SUCCESS)
		{
			ret = IFX_FAILURE;
			IFX_MEM_FREE(lease_entries)
			return ret;
		}

		if (num_leases < 0 || num_leases > 32767)
		{
			ret = IFX_FAILURE;
			IFX_MEM_FREE(lease_entries)
			return ret;
		}

		if (ifx_get_lan_arp_entries(&num_arp_entries, &arp_entries) != IFX_SUCCESS)
		{
			ret = IFX_FAILURE;
			IFX_MEM_FREE(lease_entries)
			IFX_MEM_FREE(arp_entries)
			return ret;
		}

		if (num_arp_entries < 0 || num_arp_entries > 32767)
		{
			ret = IFX_FAILURE;
			IFX_MEM_FREE(lease_entries)
			IFX_MEM_FREE(arp_entries)
			return ret;
		}

		*num_entries = 0;
		arp_count = 0;
		for (i = 0; i < num_arp_entries; i++)
		{
			for (j = 0; j < num_leases; j++)
			{
				if (lease_entries[j].ip.s_addr == arp_entries[i].ipAddr.s_addr)
					break;
			}
			if (j < num_leases)
				continue;

			arp_count++;
			*host = realloc(*host, sizeof(LAN_HOST_INFO) * arp_count);
			memcpy((*host + (arp_count - 1)), (arp_entries + i), sizeof(LAN_HOST_INFO));
		}
		*num_entries = arp_count;

		IFX_MEM_FREE(lease_entries)
		IFX_MEM_FREE(arp_entries)
		return IFX_SUCCESS;
	}
	else if (hType == LAN_HOST_ALL_TYPE)
	{
		if (ifx_get_lan_dhcp_leases(&num_leases, &lease_entries, flags)
		    != IFX_SUCCESS) {
			ret = IFX_FAILURE;
			IFX_MEM_FREE(lease_entries)
			return ret;
		}

		if (num_leases < 0 || num_leases > 32767)
		{
			ret = IFX_FAILURE;
			IFX_MEM_FREE(lease_entries)
			return ret;
		}

		if (ifx_get_lan_arp_entries(&num_arp_entries, &arp_entries)
		     != IFX_SUCCESS) {
			ret = IFX_FAILURE;
			IFX_MEM_FREE(lease_entries)
			IFX_MEM_FREE(arp_entries)
			return ret;
		}

		if (num_arp_entries < 0 || num_arp_entries > 32767)
		{
			ret = IFX_FAILURE;
			IFX_MEM_FREE(lease_entries)
			IFX_MEM_FREE(arp_entries)
			return ret;
		}
		if(num_leases != 0)
		{
			IFX_MEM_ALLOC((*host), LAN_HOST_INFO *, num_leases,
				      sizeof(LAN_HOST_INFO))

			for (i = 0; i < num_leases; i++)
			{
				(*host + i)->ipAddr.s_addr = (lease_entries + i)->ip.s_addr;
				(*host + i)->ipAddrType = LAN_HOST_DHCP_TYPE;
				(*host + i)->leaseTimeRem = (lease_entries + i)->lease_time_left;
				sprintf((*host + i)->macAddr, "%s", (lease_entries + i)->cli_id);
				strncpy((*host + i)->hostName, (lease_entries + i)->host_name, MAX_HOST_LEN - 1);
                                strcpy(sBuf,(*host + i)->macAddr);
                                for(iI=0;iI<strlen(sBuf);iI++)
                                    sBuf[iI]=toupper(sBuf[iI]);
                                if((strstr(sMacList ,((*host + i)->macAddr))) || (strstr(sMacList,sBuf)))
                                    (*host + i)->phyIfType = PHY_IF_802_11_TYPE;
                                else
				(*host + i)->phyIfType = PHY_IF_ETHER_TYPE;
				(*host + i)->status = LAN_HOST_STATUS_ACTIVE;
			}
		}
		IFX_MEM_FREE(lease_entries)
		*num_entries = num_leases;

		for (i = 0; i < num_arp_entries; i++)
		{
			for (j = 0; j < num_leases; j++)
			{
				if ((*host + j)->ipAddr.s_addr == (arp_entries + i)->ipAddr.s_addr)
					break;
			}
			if (j < num_leases)
				continue;
			*num_entries += 1;
			pTmpHost = realloc(*host, sizeof(LAN_HOST_INFO) * (*num_entries));
			if(pTmpHost != NULL)
			{
				*host = pTmpHost;
				memcpy((*host + (*num_entries - 1)), (arp_entries + i), sizeof(LAN_HOST_INFO));
			}
			else
			{
				IFX_MEM_FREE(*host)
				*num_entries = 0;
				goto IFX_Handler;
			}
		}

		IFX_MEM_FREE(arp_entries)
		return IFX_SUCCESS;
	}

IFX_Handler:
	IFX_MEM_FREE(arp_entries)
	IFX_MEM_FREE(lease_entries)
	return IFX_FAILURE;
}
#endif

int32 ifx_get_dhcp_conditional_entry(IFX_DHCP_COND_SERV_POOL * pp_dhcp_info,
				     uint32 flags)
{
	char8 sBuf[MAX_FILELINE_LEN], *sValue = NULL;
	int32 passed_index = -1, count = 0;
	// uint32 outflag = IFX_F_DEFAULT;
	int ret = IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR array_fvp[IFX_LAN_DHCP_COND_INFO_PARAM_COUNT + 1];

	/* Fill the section tag */
	sprintf(pp_dhcp_info->iid.cpeId.secName, "%s", TAG_LAN_DHCP_COND_INFO);

	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	/* get index from cpeid */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, pp_dhcp_info->iid.cpeId,
				 passed_index)
	    sprintf(sBuf, "%s_%d_", PREFIX_LAN_DHCP_COND_INFO, passed_index);
	if ((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_LAN_DHCP_COND_INFO,
				    sBuf, flags, &sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	memset(array_fvp, 0x00, sizeof(array_fvp));

	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);

	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	/* copy the pp_dhcp_info entries into the structure */
	ifx_fill_intValues_ArrayFvp(array_fvp, 0, 2,
				    (int32 *) & pp_dhcp_info->iid.cpeId.Id,
				    &pp_dhcp_info->iid.pcpeId.Id);

	ifx_fill_strValues_ArrayFvp(array_fvp, 2, 14, pp_dhcp_info->SourceInterface, &pp_dhcp_info->VendorClassID, &pp_dhcp_info->ClientID, &pp_dhcp_info->UserClassID, &pp_dhcp_info->Chaddr, &pp_dhcp_info->ChaddrMask, &pp_dhcp_info->MinAddress,	/* TODO */
				    &pp_dhcp_info->MaxAddress,	/* TODO */
				    &pp_dhcp_info->ReservedAddresses, &pp_dhcp_info->SubnetMask,	/* TODO */
				    &pp_dhcp_info->DNSServers,	/* TODO */
				    &pp_dhcp_info->DomainName, &pp_dhcp_info->IPRouters, &pp_dhcp_info->DHCPServerIPAddress);	/* TODO */

//              ifx_fill_uintValues_ArrayFvp(array_fvp, 16, 2,
//                                            &pp_dhcp_info->PoolOrder,
//                                            &pp_dhcp_info->DHCPLeaseTime);
	pp_dhcp_info->PoolOrder = atoi(array_fvp[16].value);
	pp_dhcp_info->DHCPLeaseTime = atoi(array_fvp[17].value);

	ifx_fill_boolValues_ArrayFvp(array_fvp, 18, 2,
				     &pp_dhcp_info->Enable,
				     &pp_dhcp_info->LocallyServed);

/* TODO 
                    char8    srcIP[18];
                    char8    srcIPMask[18];
                    char8    dstIP[18];
                    char8    dstIPMask[18];

                  inet_aton(srcIP,&(pp_dhcp_info->srcIP.ip));
                  inet_aton(srcIPMask,&(pp_dhcp_info->srcIP.mask));
                  inet_aton(dstIP,&(pp_dhcp_info->dstIP.ip));
                  inet_aton(dstIPMask,&(pp_dhcp_info->dstIP.mask));
                  */

	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);

      IFX_Handler:
	IFX_MEM_FREE(sValue);
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

int32 ifx_get_all_dhcp_conditional_entries(int32 * num_entries,
					   IFX_DHCP_COND_SERV_POOL **
					   pp_dhcp_info, uint32 flags)
{
	int32 nCount = 0, nIndex = 0;
	int32 ret = IFX_SUCCESS, dhcp_count = 0;
	char8 sCommand[MAX_FILELINE_LEN], sBuf[MAX_FILELINE_LEN];
	uint32 outFlag = IFX_F_DEFAULT;

	IFX_DHCP_COND_SERV_POOL *t_ptr = NULL;

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));

	/* first, get the number of conditional entries from rc.conf */
	MAKE_SECTION_COUNT_TAG(TAG_LAN_DHCP_COND_INFO, sCommand);

	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCP_COND_INFO,
				  sCommand, flags, &outFlag,
				  sBuf)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	nCount = atoi(sBuf);
	if (nCount < 1 || nCount > 32767) {
		*num_entries = 0;
		*pp_dhcp_info = NULL;
		goto IFX_Handler;
	}
	*pp_dhcp_info = NULL;
	t_ptr = (IFX_DHCP_COND_SERV_POOL *) IFX_MALLOC(nCount *
						       sizeof
						       (IFX_DHCP_COND_SERV_POOL));
	if (t_ptr == NULL) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	*pp_dhcp_info = t_ptr;

	for (nIndex = 0; nIndex < nCount; nIndex++) {

		NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
		sprintf(sCommand, "%s_%d_cpeId", PREFIX_LAN_DHCP_COND_INFO,
			nIndex);
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCP_COND_INFO,
				    sCommand, flags, &outFlag,
				    sBuf)) != IFX_SUCCESS) {
			goto IFX_Handler;
		}

		(*pp_dhcp_info + dhcp_count)->iid.cpeId.Id = atoi(sBuf);

		if ((ret =
		     ifx_get_dhcp_conditional_entry((*pp_dhcp_info +
						     dhcp_count),
						    flags) != IFX_SUCCESS)) {
			goto IFX_Handler;
		}

		dhcp_count++;
	}

	*num_entries = dhcp_count;

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*pp_dhcp_info)
		    * num_entries = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/*manohar:mapi for supporting webredirector*/
int32 ltq_mapi_get_all_lan_ip_host(uint32 * numHost, LTQ_MAPI_LAN_IP_Host ** ipHost, uint32 flags)
{
#ifdef CONFIG_FEATURE_WEB_REDIRECTOR
	FILE *fp = NULL;
	int b, i = 0,enable = 0;
	*numHost = 0;

	system("/etc/rc.d/arp-scan");
	fp = fopen("/tmp/host_list", "rb");
	if (fp == NULL) {
		IFX_API_LOG("[%s] : Failed to open the file /tmp/host_list!",
				__FUNCTION__);
		return IFX_FAILURE;
	}
	while ((b = fgetc(fp)) != EOF)
		*numHost += (b == 10) ? 1 : 0;
	fseek(fp, 0, SEEK_SET);
	fclose(fp);

	LTQ_MAPI_LAN_IP_Host *t_ptr = NULL;
	t_ptr = (LTQ_MAPI_LAN_IP_Host *) IFX_MALLOC(sizeof(LTQ_MAPI_LAN_IP_Host) **numHost);
	if (ipHost != NULL)
		*ipHost = t_ptr;
	else {
		if (t_ptr != NULL)
			IFX_MEM_FREE(t_ptr);
		return IFX_FAILURE;
	}
	fp = fopen("/tmp/host_list", "r");
	if (fp != NULL ){
		if( *ipHost != NULL){
			while (fscanf(fp, "%s %s %d\n", (*ipHost + i)->ip4Addr,(*ipHost + i)->macAddr,&enable) == 3) 
			{
				(*ipHost + i)->webSrvr = enable;
				(*ipHost + i)->iid.cpeId.Id = i + 1;
				i++;
			}
		}
		fclose( fp );
	} else {
		IFX_API_LOG("[%s] : Failed to open the file /tmp/host_list!",__FUNCTION__);
		IFX_MEM_FREE(*ipHost);
		return IFX_FAILURE;
	}
#endif
	return IFX_SUCCESS;
}
/*manohar end */
