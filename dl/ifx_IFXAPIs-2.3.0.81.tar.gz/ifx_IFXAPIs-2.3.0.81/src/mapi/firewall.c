#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#include <arpa/inet.h>
#include <time.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"
#include <linux/if.h>
#include "ifx_api_ipt_common.h"
#include <ifx_api_ipt_common_private.h>

char8 *firewall_param_names[] =
    { "cpeId", "pcpeId", "enable", "protoType", "srcType",
	"srcIp", "srcMask", "sPortRange", "iif", "dstType",
	"dstIp", "dstMask", "dPortRange", "oif", "sMacAddr"
};

char8 *url_filt_params[] =
    { "cpeId", "pcpeId", "URLName"};

#ifdef CONFIG_FEATURE_NAPT
extern int netmask2bits(u_int32_t netmask);
#endif

/* SET APIs */
/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_set_firewall_status(...)
*		entry		==> 	firewall status
*    	flags		==>   	flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
/////////////////////////////////////////////////////////////////////////////*/
int32 ifx_mapi_set_firewall_status(IFX_MAPI_Firewall * xFW, uint32 flags)
{
	int32 ret = IFX_SUCCESS;
	char8 buf[MAX_FILELINE_LEN * 3];
	IFX_NAME_VALUE_PAIR array_fvp[4], *array_changed_fvp = NULL;
	uint32 changed_count = 0, count = 5;
	char8 aclEnable[MAX_DATA_LEN];
        time_t lc_time;
        uint32 lc_ts = 0;

        NULL_TERMINATE(buf, 0, sizeof(buf));
        memset(array_fvp, 0, sizeof(array_fvp));

        flags |= IFX_F_MODIFY;

        lc_time = time(NULL);
        lc_ts = lc_time;

	/************* Validation Block ************/
	/* Do simple validation of flags sucha as less than 0 */

	if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		if ((IFX_INT_ADD_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		IFX_VALIDATE_FLAGS(flags);
	}

	/************* Name Value Formation as per RC.CONF *************/
	xFW->iid.cpeId.Id = 1;
	xFW->iid.pcpeId.Id = 1;
	strcpy(xFW->iid.cpeId.secName, TAG_FIREWALL_MAIN);
	strcpy(xFW->iid.pcpeId.secName, TAG_IGD);
	sprintf(array_fvp[0].fieldname, "%s", "firewall_main_cpeId");
	sprintf(array_fvp[0].value, "%d", xFW->iid.cpeId.Id);
	sprintf(array_fvp[1].fieldname, "%s", "firewall_main_pcpeId");
	sprintf(array_fvp[1].value, "%d", xFW->iid.pcpeId.Id);
	sprintf(array_fvp[2].fieldname, "%s", "firewall_main_enable");
	sprintf(array_fvp[2].value, "%d", xFW->enable);
        sprintf(array_fvp[3].fieldname, "%s", "firewall_main_version");
        sprintf(array_fvp[3].value, "%s", xFW->version);
        sprintf(array_fvp[4].fieldname, "%s", "firewall_main_lastchange");
        sprintf(array_fvp[4].value, "%u", lc_ts);


	/********* System Config File Update Block  **********/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */

	form_cfgdb_buf(buf, count, array_fvp);

	CHECK_ACL_RET(xFW->iid, count, array_fvp,
		      changed_count, array_changed_fvp, flags, IFX_Handler)
	    /* Backup rc.conf before proceeding with configuration */
	    ret =
	    ifx_SetObjData(FILE_RC_CONF, TAG_FIREWALL_MAIN, flags, 1, buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */

	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/**************** Device Configuration Block ******************/

	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
		NULL_TERMINATE(buf, 0x00, sizeof(buf));
		if (xFW->enable) {
/*manohar : to check for ACL*/
		if (ifx_GetCfgData(FILE_RC_CONF, TAG_SERVERS_ACL, "SERVERS_ACL_ENABLE",aclEnable) != IFX_SUCCESS) {
		}
		system("naptcfg --ServicesACLinit");
		if (!strcmp(aclEnable, "1"))
			system("naptcfg --ServicesACL 1");
		else
			system("naptcfg --ServicesACL 0");
/*manohar end*/
			sprintf(buf, "/usr/sbin/naptcfg --FW 1\n");
			if (system(buf))
				ret = IFX_SUCCESS;
#ifdef CONFIG_FEATURE_URL_FILTERING
                        sprintf(buf, "/etc/rc.d/url_filter start \n");
                        if (system(buf))
                                ret = IFX_SUCCESS;
#endif

		} else {
/*manohar start*/
			system("naptcfg --ServicesACLinit");
			system("naptcfg --ServicesACL 0");
/*manohar end*/
			sprintf(buf, "/usr/sbin/naptcfg --FW 0\n");
			if (system(buf))
				ret = IFX_SUCCESS;
#ifdef CONFIG_FEATURE_URL_FILTERING
			sprintf(buf, "/etc/rc.d/url_filter stop \n");
			if (system(buf))
				ret = IFX_SUCCESS;
#endif
		}
	}			// IFX_DONT_ACTIVATE_F_NOT_SET

	/**************** Notification Block ******************/

	/* Notify the Internal TR69 Stack in case of MODIFY */
	if (IFX_MODIFY_F_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION((xFW->iid), changed_count,
					  array_changed_fvp, flags, IFX_Handler)
	}

	/***************** Epilog Block **********************/

	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* Update status in syslog */
	if (xFW->enable) {
		IFX_DBG("Firewall is now enabled in the device.");
	} else {
		IFX_DBG("Firewall is now disabled in the device.");
	}

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_set_firewall_pfstatus(...)
*		entry		==> 	firewall status
*    	flags		==>   	flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
/////////////////////////////////////////////////////////////////////////////*/
int32 ifx_mapi_set_firewall_pfstatus(IFX_MAPI_Firewall_PF * xFW, uint32 flags)
{
	int32 ret = IFX_SUCCESS;
	char8 buf[MAX_FILELINE_LEN * 4];
	IFX_NAME_VALUE_PAIR array_fvp[5], *array_changed_fvp = NULL;
	uint32 changed_count = 0, count = 4;

	NULL_TERMINATE(buf, 0, sizeof(buf));
	memset(array_fvp, 0, sizeof(array_fvp));

	flags |= IFX_F_MODIFY;

	/************* Validation Block ************/
	/* Do simple validation of flags sucha as less than 0 */

	if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		if ((IFX_INT_ADD_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		IFX_VALIDATE_FLAGS(flags)
	}

	/************* Name Value Formation as per RC.CONF *************/
	xFW->iid.cpeId.Id = 1;
	xFW->iid.pcpeId.Id = 1;
	strcpy(xFW->iid.cpeId.secName, TAG_FIREWALL_PACKETFILTER_STATUS);
	strcpy(xFW->iid.pcpeId.secName, TAG_FIREWALL_MAIN);
	sprintf(array_fvp[0].fieldname, "%s",
		"firewall_packetfilter_status_cpeId");
	sprintf(array_fvp[0].value, "%d", xFW->iid.cpeId.Id);
	sprintf(array_fvp[1].fieldname, "%s",
		"firewall_packetfilter_status_pcpeId");
	sprintf(array_fvp[1].value, "%d", xFW->iid.pcpeId.Id);
	strcpy(array_fvp[2].fieldname, "firewall_packetfilter_status_enable");
	sprintf(array_fvp[2].value, "%d", xFW->enable);
	strcpy(array_fvp[3].fieldname,
	       "firewall_packetfilter_status_num_entries");
	sprintf(array_fvp[3].value, "%d", xFW->ruleNoOfEntries);

	/********* System Config File Update Block  **********/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */

	form_cfgdb_buf(buf, count, array_fvp);

	CHECK_ACL_RET(xFW->iid, count, array_fvp,
		      changed_count, array_changed_fvp, flags, IFX_Handler)
	    /* Backup rc.conf before proceeding with configuration */
	    ret =
	    ifx_SetObjData(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER_STATUS,
			   flags, 1, buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */

	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/**************** Device Configuration Block ******************/

	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
		NULL_TERMINATE(buf, 0x00, sizeof(buf));
		if (xFW->enable) {
			sprintf(buf, "/usr/sbin/naptcfg --PacketFilter 1\n");
			if (system(buf))
				ret = IFX_SUCCESS;
		} else {
			sprintf(buf, "/usr/sbin/naptcfg --PacketFilter 0\n");
			if (system(buf))
				ret = IFX_SUCCESS;
		}
	}			// IFX_DONT_ACTIVATE_F_NOT_SET

	/**************** Notification Block ******************/

	/* Notify the Internal TR69 Stack in case of MODIFY */
	if (IFX_MODIFY_F_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION((xFW->iid), changed_count,
					  array_changed_fvp, flags, IFX_Handler)
	}

	/***************** Epilog Block **********************/

	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_set_firewall_pfrule(...)
*		operation	==> 	specifies the operation to be done for the ipaddree - interface
*							combination passed such as ADD, DELETE
*		entry		==>		pointer to VIRTUAL_SERVER which will store the virtual server information to be configured
*    	flags		==>		flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
/////////////////////////////////////////////////////////////////////////////*/
int32 ifx_mapi_set_firewall_pfrule(int32 operation,
				   IFX_MAPI_Firewall_PFRule * entry,
				   uint32 flags)
{
#ifdef CONFIG_FEATURE_NAPT
	char8 conf_buf[MAX_DATA_LEN];
	char8 src_ip[MAX_IP_ADDR_LEN];
	int32 count = 0, changed_count = 0, passed_index = -1, ret =
	    IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR array_fvp[16], *array_changed_fvp = NULL;
	char8 *retStr = NULL, *tmp;
	int num_entries = 0, entry_size = 0, i = 0, rule_exists = 0, j;
	IFX_MAPI_Firewall_PFRule *firewallRules = NULL;
	char ifName[IFNAMSIZE];
	IFX_IPT_RULE old_query_rule, new_query_rule;

	memset(&old_query_rule, 0x00, sizeof(IFX_IPT_RULE));
	memset(&new_query_rule, 0x00, sizeof(IFX_IPT_RULE));

	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
	NULL_TERMINATE(ifName, 0x00, sizeof(ifName));
	memset(array_fvp, 0x00, sizeof(array_fvp));

	/*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY)
	 * append the flag with internal flags */

	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

	/**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */

	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(entry)
		    /* Do simple validation of flags such as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)

	}
	strcpy(entry->iid.cpeId.secName, TAG_FIREWALL_PACKETFILTER);
	strcpy(entry->iid.pcpeId.secName, TAG_FIREWALL_PACKETFILTER_STATUS);
	entry->iid.pcpeId.Id = 1;

	/**************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_ADD_F_SET(flags)) {
		entry->iid.cpeId.Id = 0;
		/* Allocate the IID for this route instance
		 * Set the parent SectionName and parent IID values
		 * to NULL as there is no parent for Route Entity
		 */
		if (ifx_get_IID(&entry->iid, "enable") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	/**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given structure for ADD/MODIFY
	 * Operations
	 */
	if (IFX_DELETE_F_NOT_SET(flags)) {

		for (i = 0; i < 15; i++) {
			sprintf(array_fvp[i].fieldname, "%s",
				firewall_param_names[i]);
		}

		sprintf(array_fvp[count++].value, "%d", entry->iid.cpeId.Id);
		sprintf(array_fvp[count++].value, "%d", entry->iid.pcpeId.Id);

		sprintf(array_fvp[count++].value, "%d",
			(entry->enable) ? entry->enable : 0);
		sprintf(array_fvp[count++].value, "%d", entry->protoType);

		sprintf(array_fvp[count++].value, "%d", entry->srcType);
		strcpy(array_fvp[count++].value, inet_ntoa(entry->srcIP.ip));
		strcpy(array_fvp[count++].value, inet_ntoa(entry->srcIP.mask));

		sprintf(array_fvp[count].value, "%d",
			(entry->sPortRange.start_port));
		if (entry->sPortRange.end_port) {
			LTQ_STRNCAT(array_fvp[count].value, ":", MAX_TAG_VALUE_LEN);
			bzero(src_ip, MAX_IP_ADDR_LEN);
			sprintf(src_ip, "%d", entry->sPortRange.end_port);
			LTQ_STRNCAT(array_fvp[count++].value, src_ip,
				MAX_TAG_VALUE_LEN);
		} else
			count++;

		strcpy(array_fvp[count++].value, entry->iif);

		sprintf(array_fvp[count++].value, "%d", entry->dstType);
		strcpy(array_fvp[count++].value, inet_ntoa(entry->dstIP.ip));
		strcpy(array_fvp[count++].value, inet_ntoa(entry->dstIP.mask));

		sprintf(array_fvp[count].value, "%d",
			entry->dPortRange.start_port);
		if (entry->dPortRange.end_port) {
			LTQ_STRNCAT(array_fvp[count].value, ":", MAX_TAG_VALUE_LEN);
			bzero(src_ip, MAX_IP_ADDR_LEN);
			sprintf(src_ip, "%d", entry->dPortRange.end_port);
			LTQ_STRNCAT(array_fvp[count++].value, src_ip,
				MAX_TAG_VALUE_LEN);
		} else
			count++;

		strcpy(array_fvp[count++].value, entry->oif);

		strcpy(array_fvp[count++].value, entry->sMacAddr);
		passed_index = -1;
	}
	count = 15;

	/* Get Config Index in case of modify/delete operations from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, entry->iid.cpeId,
					 passed_index)

		    /* Now inoder to modify or delete the entry, we should be deleting
		     * the firewall entry from the PF Chains */
		    num_entries = 0;
		if (ifx_mapi_get_firewall_pfrules
		    (&num_entries, &firewallRules,
		     IFX_F_GET_ANY) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		} else {
			/* Match the cpeId with the firewall entries and fill in the
			 * corresponding matched values for the Rule to be Modified/Deleted */
			if (num_entries > 0) {
				for (i = 0; i < num_entries; i++) {
					if ((firewallRules + i)->iid.cpeId.Id ==
					    entry->iid.cpeId.Id) {
						/* This is the intended firewall entry
						 * Now populate the IPTABLE RULE structure */
						/* Set the rule_exists flag depending on the
						 * enable field in the firewall entry structure
						 * This will signify whether the entry existed in the
						 * system (enable = 1) or not (enable = 0) */

						rule_exists =
						    (firewallRules + i)->enable;

						old_query_rule.protocol =
						    (firewallRules +
						     i)->protoType;

						if ((firewallRules +
						     i)->srcIP.ip.s_addr) {
							old_query_rule.srcip =
							    (firewallRules +
							     i)->srcIP.ip.
							    s_addr;
							if ((firewallRules +
							     i)->srcIP.mask.
							    s_addr) {
								old_query_rule.
								    srcip &=
								    (firewallRules
								     +
								     i)->srcIP.
								    mask.s_addr;
								old_query_rule.
								    srcip_mask =
								    netmask2bits
								    ((firewallRules + i)->srcIP.mask.s_addr);
								if (old_query_rule.srcip_mask == 32)
									old_query_rule.
									    srcip_mask
									    = 0;
							}
						} else {
							old_query_rule.srcip =
							    0;
							old_query_rule.
							    srcip_mask = 0;
						}

						if ((firewallRules +
						     i)->sPortRange.start_port)
							old_query_rule.
							    srcport_start =
							    (firewallRules +
							     i)->sPortRange.
							    start_port;
						if ((firewallRules +
						     i)->sPortRange.end_port)
							old_query_rule.
							    srcport_end =
							    (firewallRules +
							     i)->sPortRange.
							    end_port;
						if (strlen
						    ((firewallRules + i)->iif) >
						    0)
							strncpy(old_query_rule.
								inif,
								(firewallRules +
								 i)->iif,
								IFNAMSIZ);

						if ((firewallRules +
						     i)->dstIP.ip.s_addr) {
							old_query_rule.dstip =
							    (firewallRules +
							     i)->dstIP.ip.
							    s_addr;
							if ((firewallRules +
							     i)->dstIP.mask.
							    s_addr) {
								old_query_rule.
								    dstip &=
								    (firewallRules
								     +
								     i)->dstIP.
								    mask.s_addr;
								old_query_rule.
								    dstip_mask =
								    netmask2bits
								    ((firewallRules + i)->dstIP.mask.s_addr);
								if (old_query_rule.dstip_mask == 32)
									old_query_rule.
									    dstip_mask
									    = 0;
							}
						} else {
							old_query_rule.dstip =
							    0;
							old_query_rule.
							    dstip_mask = 0;
						}

						if ((firewallRules +
						     i)->dPortRange.start_port)
							old_query_rule.
							    dstport_start =
							    (firewallRules +
							     i)->dPortRange.
							    start_port;
						if ((firewallRules +
						     i)->dPortRange.end_port)
							old_query_rule.
							    dstport_end =
							    (firewallRules +
							     i)->dPortRange.
							    end_port;
						strncpy(old_query_rule.outif,
							(firewallRules +
							 i)->oif, IFNAMSIZ);
						if (strlen
						    ((firewallRules +
						      i)->sMacAddr) > 0) {
							tmp =
							    strtok((firewallRules + i)->sMacAddr, ":");
							j = 0;
							while (1) {
								if (tmp == NULL)
									break;
								old_query_rule.
								    MAC[j] =
								    (unsigned
								     char)
								    strtol(tmp,
									   NULL,
									   16);

								if (j < 5)
									j++;
								else
									break;

								tmp =
								    strtok(NULL,
									   ":");

							}
						}
						entry_size = 1;

#ifdef IFX_LOG_DEBUG
						IFX_DBG("[%s:%d]", __FUNCTION__,
							__LINE__);
#endif
						break;
					}	// Entry Matched

				}	// End For
			}	// num_entries > 0
			else {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			}
		}
	}

	/* Determine the configuration index - for Add, Delete, Modify operations
	 * Name is partial since index is not known
	 * Fill array_fvp[] */
	if (ifx_get_conf_index_and_nv_pairs
	    (&entry->iid, passed_index, TAG_FIREWALL_PACKETFILTER, count,
	     array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	if (IFX_ADD_F_NOT_SET(flags)) {
		CHECK_ACL_RET(entry->iid, count, array_fvp,
			      changed_count, array_changed_fvp, flags,
			      IFX_Handler)
	}

	/************** System Config File Update Block ****************/

	/* Backup rc.conf before proceeding with configuration */
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);

	/* In case of Delete/Modify Operation, first Delete the entry */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
		if (IFX_INT_ADD_F_NOT_SET(flags)) {
			/* Don't unnecessarily call the DELETE function if the entry was not there in
			 * the IPTABLES itself. It is possible to perform MODIFY operation on a disabled
			 * entry */
			if (rule_exists) {
				if (IFX_IPT_SET_RULES
				    (FIREWALL, DELETE, "IFX_FW_PACKET_FILTER",
				     &old_query_rule, &entry_size,
				     DROP) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d]", __FUNCTION__,
						__LINE__);
#endif
				}
			}
		}
	}

	/* RC.CONF Configuration block */
	ret =
	    ifx_SetObjData(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, flags, 1,
			   conf_buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] for conf_buf [%s] ret [%d]", __FUNCTION__,
			__LINE__, conf_buf, ret);
#endif
		goto IFX_Handler;
	}

	/* This will Compact the section and also update the count for both ADD and DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags)) {
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER,
				      flags);
	}

	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* System call to Add/Delete/Modify firewall Entry */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {

		/* In case of ADD/MODIFY operations just ADD the new firewall entry */
		if (IFX_DELETE_F_NOT_SET(flags)) {

			/* Populate the Rule for firewall Table /
			 * Now populate the IPTABLE RULE structure */

			new_query_rule.protocol = entry->protoType;

			if (entry->srcIP.ip.s_addr) {
				new_query_rule.srcip = entry->srcIP.ip.s_addr;
				if (entry->srcIP.mask.s_addr)
					new_query_rule.srcip_mask =
					    netmask2bits(entry->srcIP.mask.
							 s_addr);
			} else {
				new_query_rule.srcip = 0;
				new_query_rule.srcip_mask = 0;
			}

			if (entry->sPortRange.start_port)
				new_query_rule.srcport_start =
				    entry->sPortRange.start_port;
			if (entry->sPortRange.end_port)
				new_query_rule.srcport_end =
				    entry->sPortRange.end_port;
			LTQ_STRNCPY(new_query_rule.inif, entry->iif, IFNAMSIZ);

			if (entry->dstIP.ip.s_addr) {
				new_query_rule.dstip = entry->dstIP.ip.s_addr;
				if (entry->dstIP.mask.s_addr)
					new_query_rule.dstip_mask =
					    netmask2bits(entry->dstIP.mask.
							 s_addr);
			} else {
				new_query_rule.dstip = 0;
				new_query_rule.dstip_mask = 0;
			}

			if (entry->dPortRange.start_port)
				new_query_rule.dstport_start =
				    entry->dPortRange.start_port;
			if (entry->dPortRange.end_port)
				new_query_rule.dstport_end =
				    entry->dPortRange.end_port;
			LTQ_STRNCPY(new_query_rule.outif, entry->oif, IFNAMSIZ);
			if (strlen(entry->sMacAddr) > 0) {
				tmp = strtok(entry->sMacAddr, ":");
				j = 0;
				while (1) {
					if (tmp == NULL)
						break;
					new_query_rule.MAC[j] =
					    (unsigned char)strtol(tmp, NULL,
								  16);

					if (j < 5)
						j++;
					else
						break;

					tmp = strtok(NULL, ":");
				}

			}
			entry_size = 1;

			/* Add the entry back to system only if it is ENABLED */
			if (entry->enable) {
				if (IFX_IPT_SET_RULES
				    (FIREWALL, ADD, "IFX_FW_PACKET_FILTER",
				     &new_query_rule, &entry_size,
				     DROP) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d]", __FUNCTION__,
						__LINE__);
#endif
				}
			}
		}

		/* checks if ret is not IFX_SUCCESS then restores the rc.conf with CHKPOINT_FILE */
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

	}			// IFX_DONT_ACTIVATE_F_NOT_SET

	/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if (IFX_MODIFY_F_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION(entry->iid, changed_count,
					  array_changed_fvp, flags, IFX_Handler)
	} else if (IFX_INT_ADD_F_SET(flags)) {
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */
		UPDATE_ID_MAP_N_ATTRIBUTES(&entry->iid, count, array_fvp, flags,
					   IFX_Handler)

		    CHECK_N_SEND_NOTIFICATION(entry->iid, count, array_fvp,
					      flags, IFX_Handler)

		    /* Manipulate nextCpeId only for ADD operations */
		    ifx_increment_next_cpeId(FILE_RC_CONF,
					     TAG_FIREWALL_PACKETFILTER);
	} else if (IFX_DELETE_F_SET(flags)) {
		/* In case of DELETE operation, first send the notificatioupdate the ID Mappings
		 * and then send the Notification for the attributes
		 */
		/*********** Epilog Block **************/
		CHECK_N_SEND_NOTIFICATION(entry->iid, count, array_fvp, flags,
					  IFX_Handler)

		    UPDATE_ID_MAP_N_ATTRIBUTES(&entry->iid, count, array_fvp,
					       flags, IFX_Handler)
	}

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(retStr)
	    IFX_MEM_FREE(firewallRules)
	    IFX_MEM_FREE(array_changed_fvp)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
#else
	return IFX_SUCCESS;
#endif
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_set_firewall_dmz(...)
*		status		==>		Flag value which tells if the Global Nat status has to be set or reset
*    	entry		==> 	The dmz entry IP and status
*		flags		==>		flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
  					The api sets or resets the DMZ Status based on the input ststua value.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_mapi_set_firewall_dmz(IFX_MAPI_Firewall_DMZ * entry, uint32 flags)
{
	int32 ret = IFX_SUCCESS;
	char8 buf[MAX_FILELINE_LEN * 4];
	IFX_NAME_VALUE_PAIR array_fvp[5], *array_changed_fvp = NULL;
	uint32 changed_count = 0, count = 4;

	NULL_TERMINATE(buf, 0, sizeof(buf));
	memset(array_fvp, 0, sizeof(array_fvp));

	flags |= IFX_F_MODIFY;

	/************* Validation Block ************/
	/* Do simple validation of flags sucha as less than 0 */
	if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		if ((IFX_INT_ADD_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		IFX_VALIDATE_FLAGS(flags)
	}

	/************* Name Value Formation as per RC.CONF *************/
	entry->iid.cpeId.Id = 1;
	entry->iid.pcpeId.Id = 1;
	strcpy(entry->iid.cpeId.secName, TAG_FIREWALL_DMZ);
	strcpy(entry->iid.pcpeId.secName, TAG_FIREWALL_MAIN);
	sprintf(array_fvp[0].fieldname, "%s", "firewall_dmz_cpeId");
	sprintf(array_fvp[0].value, "%d", entry->iid.cpeId.Id);
	sprintf(array_fvp[1].fieldname, "%s", "firewall_dmz_pcpeId");
	sprintf(array_fvp[1].value, "%d", entry->iid.pcpeId.Id);
	strcpy(array_fvp[2].fieldname, "firewall_dmz_enable");
	sprintf(array_fvp[2].value, "%d", entry->feature_enable);
	strcpy(array_fvp[3].fieldname, "firewall_dmz_ipAddr");
	strcpy(array_fvp[3].value, inet_ntoa(entry->ip));

	/********* System Config File Update Block  **********/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(buf, count, array_fvp);

	CHECK_ACL_RET(entry->iid, count, array_fvp,
		      changed_count, array_changed_fvp, flags, IFX_Handler)

	    /* Backup rc.conf before proceeding with configuration */
	    ret = ifx_SetObjData(FILE_RC_CONF, TAG_FIREWALL_DMZ, flags, 1, buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/**************** Device Configuration Block ******************/
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
		NULL_TERMINATE(buf, 0x00, sizeof(buf));
		if (entry->ip.s_addr) {
			sprintf(buf, "/usr/sbin/naptcfg --DMZinit\n");
			if (system(buf))
				ret = IFX_SUCCESS;
		}
		if (entry->feature_enable) {
			sprintf(buf, "/usr/sbin/naptcfg --DMZ 1\n");
			if (system(buf))
				ret = IFX_SUCCESS;
		} else {
			sprintf(buf, "/usr/sbin/naptcfg --DMZ 0\n");
			if (system(buf))
				ret = IFX_SUCCESS;
		}
	}			// IFX_DONT_ACTIVATE_F_NOT_SET

	/**************** Notification Block ******************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if (IFX_MODIFY_F_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION((entry->iid), changed_count,
					  array_changed_fvp, flags, IFX_Handler)
	}

	/***************** Epilog Block **********************/
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/* GET APIs */

/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_get_firewall_pfstatus(...)
*	 xFW		==>
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
  		Description:
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_mapi_get_firewall_pfstatus(IFX_MAPI_Firewall_PF * xFW, uint32 flags)
{
	int32 iRet = IFX_SUCCESS;
	/* sVal buffer should be large enough to accomodate
	   the biggest string in the obj */
	char8 sVal[MAX_IF_NAME];
	uint32 ulInFlag = IFX_F_DEFAULT, ulOutFlag;

	memset(xFW, '\0', sizeof(IFX_MAPI_Firewall_PF));
	memset(sVal, '\0', sizeof(sVal));
	if ((iRet =
	     ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER_STATUS,
			    TAG_FIREWALL_PACKETFILTER_STATUS "_enable",
			    ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;

	xFW->enable = atoi(sVal);
	memset(sVal, '\0', sizeof(sVal));
	if ((iRet =
	     ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER_STATUS,
			    TAG_FIREWALL_PACKETFILTER_STATUS "_num_entries",
			    ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;

	xFW->ruleNoOfEntries = atoi(sVal);

      IFX_Handler:
	return (iRet);

}

/*///////////////////////////////////////////////////////////////////////////////////////
//function  : ifx_mapi_get_firewall_pfrule
//arguments : IFX_MAPI_Firewall_PFRule pfRule that is output pointer to virtual server
//return    : IFX_SUCCESS if successful
//	      IFX_FAIL otherwise
///////////////////////////////////////////////////////////////////////////////////////*/
int32 ifx_mapi_get_firewall_pfrule(IFX_MAPI_Firewall_PFRule * pfRule)
{
	char8 buf[MAX_FILELINE_LEN];
	char8 sValue[MAX_FILELINE_LEN];
	int32 ret = IFX_SUCCESS;
	int32 i = 0,/* firewall_pf_enable = 0,*/ outFlag = IFX_F_DEFAULT;
	uint32 flags = IFX_F_GET_ANY;
	int32 ruleIndex = -1;
	IFX_ID iid;
	char *temp = NULL;

	iid.cpeId.Id = pfRule->iid.cpeId.Id;

	// get the enable status of Firewall, if enabled get the enable status of packetfilter
	// if set then read rulle from rc.conf and return in the output array
	memset(sValue, '\0', sizeof(sValue));
	if (ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_MAIN,
			   TAG_FIREWALL_MAIN "_enable", IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outFlag,
			   sValue) == IFX_SUCCESS) {
		if (!strcmp(sValue, "1")) {
			memset(sValue, '\0', sizeof(sValue));
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER_STATUS,
			     TAG_FIREWALL_PACKETFILTER_STATUS "_enable", flags,
			     (IFX_OUT uint32 *) & outFlag,
			     sValue) == IFX_SUCCESS) {
				/*if (!strcmp(sValue, "1")) {
					firewall_pf_enable = 1;
				}*/
			}
		}
	}

	sprintf(iid.cpeId.secName, "%s", TAG_FIREWALL_PACKETFILTER);
	sprintf(pfRule->iid.cpeId.secName, "%s", TAG_FIREWALL_PACKETFILTER);
	if (ifx_get_index_from_cpe_id(FILE_RC_CONF, &iid.cpeId, &ruleIndex) !=
	    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		printf("ifx_get_index_from_cpe_id failed in nat.c\n");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	i = ruleIndex;

	/* initialize the cache for this instance */
	sprintf(buf, "%s_%d_", TAG_FIREWALL_PACKETFILTER, ruleIndex);
	if (ifx_GetObjDataOpt
	    (FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf,
	     IFX_F_INT_CACHE_INIT | IFX_F_GET_ANY, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance",
			__FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	//get the cpeid for this pf rule index i
	sprintf(buf, "%s_%d_cpeId", TAG_FIREWALL_PACKETFILTER, i);
	memset(sValue, '\0', sizeof(sValue));
	if ((ifx_GetObjDataOpt
	     (FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf, flags,
	      (IFX_OUT uint32 *) & outFlag, sValue)) != IFX_SUCCESS) {
	} else {
		pfRule->iid.cpeId.Id = atoi(sValue);
	}

	sprintf(buf, "%s_%d_pcpeId", TAG_FIREWALL_PACKETFILTER, i);
	memset(sValue, '\0', sizeof(sValue));
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf,
			       flags, (IFX_OUT uint32 *) & outFlag,
			       sValue)) == IFX_SUCCESS) {
		pfRule->iid.pcpeId.Id = atoi(sValue);
	}

	sprintf(buf, "%s_%d_enable", TAG_FIREWALL_PACKETFILTER, i);
	memset(sValue, '\0', sizeof(sValue));
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf,
			       flags, (IFX_OUT uint32 *) & outFlag,
			       sValue)) == IFX_SUCCESS) {
		pfRule->enable = atoi(sValue);
	}

	sprintf(buf, "%s_%d_protoType", TAG_FIREWALL_PACKETFILTER, i);
	memset(sValue, '\0', sizeof(sValue));
	if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf,
			      flags, (IFX_OUT uint32 *) & outFlag,
			      sValue) == IFX_SUCCESS) {
		pfRule->protoType = atoi(sValue);
	}

	sprintf(buf, "%s_%d_srcType", TAG_FIREWALL_PACKETFILTER, i);
	memset(sValue, '\0', sizeof(sValue));
	if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf,
			      flags, (IFX_OUT uint32 *) & outFlag,
			      sValue) == IFX_SUCCESS) {
		pfRule->srcType = atoi(sValue);
	}

	sprintf(buf, "%s_%d_srcIp", TAG_FIREWALL_PACKETFILTER, i);
	memset(sValue, '\0', sizeof(sValue));
	if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf,
			      flags, (IFX_OUT uint32 *) & outFlag,
			      sValue) == IFX_SUCCESS) {
		if (strlen(sValue) && strcmp(sValue, "*"))
			inet_aton(sValue, &(pfRule->srcIP.ip));
		else
			pfRule->srcIP.ip.s_addr = 0;

	}

	sprintf(buf, "%s_%d_srcMask", TAG_FIREWALL_PACKETFILTER, i);
	memset(sValue, '\0', sizeof(sValue));
	if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf,
			      flags, (IFX_OUT uint32 *) & outFlag,
			      sValue) == IFX_SUCCESS) {
		if (strlen(sValue))
			inet_aton(sValue, &(pfRule->srcIP.mask));
		else
			pfRule->srcIP.mask.s_addr = 0;
	}

	sprintf(buf, "%s_%d_sPortRange", TAG_FIREWALL_PACKETFILTER, i);
	memset(sValue, '\0', sizeof(sValue));
	if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf,
			      flags, (IFX_OUT uint32 *) & outFlag,
			      sValue) == IFX_SUCCESS) {
		if (strlen(sValue)) {
			temp = strchr(sValue, ':');
			if (temp != NULL) {
				pfRule->sPortRange.end_port = atoi(temp + 1);
				*temp = '\0';
			}
			pfRule->sPortRange.start_port = atoi(sValue);
		}
	}

	sprintf(buf, "%s_%d_iif", TAG_FIREWALL_PACKETFILTER, i);
	memset(sValue, '\0', sizeof(sValue));
	if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf,
			      flags, (IFX_OUT uint32 *) & outFlag,
			      sValue) == IFX_SUCCESS) {
		if (strlen(sValue))
			strncpy(pfRule->iif, sValue, MAX_IF_NAME_LEN);
	}

	sprintf(buf, "%s_%d_dstType", TAG_FIREWALL_PACKETFILTER, i);
	memset(sValue, '\0', sizeof(sValue));
	if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf,
			      flags, (IFX_OUT uint32 *) & outFlag,
			      sValue) == IFX_SUCCESS) {
		pfRule->dstType = atoi(sValue);
	}

	sprintf(buf, "%s_%d_dstIp", TAG_FIREWALL_PACKETFILTER, i);
	memset(sValue, '\0', sizeof(sValue));
	if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf,
			      flags, (IFX_OUT uint32 *) & outFlag,
			      sValue) == IFX_SUCCESS) {
		if (strlen(sValue) && strcmp(sValue, "*"))
			inet_aton(sValue, &(pfRule->dstIP.ip));
		else
			pfRule->dstIP.ip.s_addr = 0;

	}

	sprintf(buf, "%s_%d_dstMask", TAG_FIREWALL_PACKETFILTER, i);
	memset(sValue, '\0', sizeof(sValue));
	if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf,
			      flags, (IFX_OUT uint32 *) & outFlag,
			      sValue) == IFX_SUCCESS) {
		if (strlen(sValue))
			inet_aton(sValue, &(pfRule->dstIP.mask));
		else
			pfRule->dstIP.mask.s_addr = 0;
	}

	temp = NULL;
	sprintf(buf, "%s_%d_dPortRange", TAG_FIREWALL_PACKETFILTER, i);
	memset(sValue, '\0', sizeof(sValue));
	if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf,
			      flags, (IFX_OUT uint32 *) & outFlag,
			      sValue) == IFX_SUCCESS) {
		if (strlen(sValue)) {
			temp = strchr(sValue, ':');
			if (temp != NULL) {
				pfRule->dPortRange.end_port = atoi(temp + 1);
				*temp = '\0';
			}
			pfRule->dPortRange.start_port = atoi(sValue);
		}
	}

	sprintf(buf, "%s_%d_oif", TAG_FIREWALL_PACKETFILTER, i);
	memset(sValue, '\0', sizeof(sValue));
	if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf,
			      flags, (IFX_OUT uint32 *) & outFlag,
			      sValue) == IFX_SUCCESS) {
		if (strlen(sValue))
			strncpy(pfRule->oif, sValue, MAX_IF_NAME_LEN);
	}

	sprintf(buf, "%s_%d_sMacAddr", TAG_FIREWALL_PACKETFILTER, i);
	memset(sValue, '\0', sizeof(sValue));
	if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf,
			      flags, (IFX_OUT uint32 *) & outFlag,
			      sValue) == IFX_SUCCESS) {
		if (strlen(sValue))
			strncpy(pfRule->sMacAddr, sValue, MAX_MAC_ADDR_LEN);
	}

      IFX_Handler:
	/* destroy the cache for this instance */
	sprintf(buf, "%s_%d_", TAG_FIREWALL_PACKETFILTER, i);
	if (ifx_GetObjDataOpt
	    (FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf,
	     IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to destroy cache for this instance",
			__FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_get_firewall_pf_rules(...)
*	num_entries	==>	output number of virtual server entries in rc.conf
*	pfRules	==>	output pointer to array of IFX_MAPI_Firewall_PFRule
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
Description:
  
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_mapi_get_firewall_pfrules(int32 * num_entries,
				    IFX_MAPI_Firewall_PFRule ** pfRules,
				    uint32 flags)
{
#ifdef CONFIG_FEATURE_NAPT
	char8 buf[MAX_FILELINE_LEN];
	char8 sValue[MAX_FILELINE_LEN];
	int32 ret = IFX_SUCCESS, iVsCount = 0;
	int32 i = 0, /*firewall_pf_enable = 0,*/ outFlag =
	    IFX_F_DEFAULT, t_num_entries = 0;
	char *temp = NULL;

	*num_entries = 0;
	// get the enable status of Firewall, if enabled get the enable status of packetfilter
	// if set then read rulle from rc.conf and return in the output array
	memset(sValue, '\0', sizeof(sValue));

	if (ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_MAIN,
			   TAG_FIREWALL_MAIN "_enable", IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outFlag,
			   sValue) == IFX_SUCCESS) {
		if (!strcmp(sValue, "1")) {
			memset(sValue, '\0', sizeof(sValue));
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER_STATUS,
			     TAG_FIREWALL_PACKETFILTER_STATUS "_enable", flags,
			     (IFX_OUT uint32 *) & outFlag,
			     sValue) == IFX_SUCCESS) {
				/*if (!strcmp(sValue, "1")) {
					firewall_pf_enable = 1;
				}*/
			}
		}
	}

	/* get the number of firewall pf_rule entries */
	memset(sValue, '\0', sizeof(sValue));
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER,
				  TAG_FIREWALL_PACKETFILTER "_Count",
				  flags, (IFX_OUT uint32 *) & outFlag,
				  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;
	}
	iVsCount = atoi(sValue);
	if (iVsCount < 1 || iVsCount > 200) {	//MAX_NO_INSTANCES
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_SUCCESS;
	}

	/* allocate memory for iVsCount */
	*pfRules = NULL;
	IFX_MEM_ALLOC((*pfRules), IFX_MAPI_Firewall_PFRule *, iVsCount,
		      sizeof(IFX_MAPI_Firewall_PFRule))

	    /* for each pf rule entry read the values from rc.conf and store
	     * them as an array element in pfRules */
	    for (i = 0; i < iVsCount; i++) {	/* ???? index i - 1 to i */
		//get the cpeid for this pf rule index i
		sprintf(buf, "%s_%d_cpeId", TAG_FIREWALL_PACKETFILTER, i);
		memset(sValue, '\0', sizeof(sValue));
		if ((ifx_GetObjDataOpt
		     (FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf, flags,
		      (IFX_OUT uint32 *) & outFlag, sValue)) != IFX_SUCCESS) {
		} else {
			(*pfRules + t_num_entries)->iid.cpeId.Id = atoi(sValue);
		}

		sprintf(buf, "%s_%d_pcpeId", TAG_FIREWALL_PACKETFILTER, i);
		memset(sValue, '\0', sizeof(sValue));
		if ((ifx_GetObjDataOpt
		     (FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf, flags,
		      (IFX_OUT uint32 *) & outFlag, sValue)) == IFX_SUCCESS) {
			(*pfRules + t_num_entries)->iid.pcpeId.Id =
			    atoi(sValue);
		}

		sprintf(buf, "%s_%d_enable", TAG_FIREWALL_PACKETFILTER, i);
		memset(sValue, '\0', sizeof(sValue));
		if ((ifx_GetObjDataOpt
		     (FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf, flags,
		      (IFX_OUT uint32 *) & outFlag, sValue)) == IFX_SUCCESS) {
			(*pfRules + t_num_entries)->enable = atoi(sValue);
		}

		sprintf(buf, "%s_%d_protoType", TAG_FIREWALL_PACKETFILTER, i);
		memset(sValue, '\0', sizeof(sValue));
		if (ifx_GetObjDataOpt
		    (FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, sValue) == IFX_SUCCESS) {
			(*pfRules + t_num_entries)->protoType = atoi(sValue);
		}

		sprintf(buf, "%s_%d_srcType", TAG_FIREWALL_PACKETFILTER, i);
		memset(sValue, '\0', sizeof(sValue));
		if (ifx_GetObjDataOpt
		    (FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, sValue) == IFX_SUCCESS) {
			(*pfRules + t_num_entries)->srcType = atoi(sValue);
		}

		sprintf(buf, "%s_%d_srcIp", TAG_FIREWALL_PACKETFILTER, i);
		memset(sValue, '\0', sizeof(sValue));
		if (ifx_GetObjDataOpt
		    (FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, sValue) == IFX_SUCCESS) {
			if (strlen(sValue) && strcmp(sValue, "*"))
				inet_aton(sValue,
					  &((*pfRules +
					     t_num_entries)->srcIP.ip));
			else
				(*pfRules + t_num_entries)->srcIP.ip.s_addr = 0;

		}

		sprintf(buf, "%s_%d_srcMask", TAG_FIREWALL_PACKETFILTER, i);
		memset(sValue, '\0', sizeof(sValue));
		if (ifx_GetObjDataOpt
		    (FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, sValue) == IFX_SUCCESS) {
			if (strlen(sValue))
				inet_aton(sValue,
					  &((*pfRules +
					     t_num_entries)->srcIP.mask));
			else
				(*pfRules + t_num_entries)->srcIP.mask.s_addr =
				    0;
		}

		sprintf(buf, "%s_%d_sPortRange", TAG_FIREWALL_PACKETFILTER, i);
		memset(sValue, '\0', sizeof(sValue));
		if (ifx_GetObjDataOpt
		    (FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, sValue) == IFX_SUCCESS) {
			if (strlen(sValue)) {
				temp = strchr(sValue, ':');
				if (temp != NULL) {
					(*pfRules +
					 t_num_entries)->sPortRange.end_port =
				 atoi(temp + 1);
					*temp = '\0';
				}
				(*pfRules +
				 t_num_entries)->sPortRange.start_port =
			 atoi(sValue);
			}
		}

		sprintf(buf, "%s_%d_iif", TAG_FIREWALL_PACKETFILTER, i);
		memset(sValue, '\0', sizeof(sValue));
		if (ifx_GetObjDataOpt
		    (FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, sValue) == IFX_SUCCESS) {
			if (strlen(sValue))
				strncpy((*pfRules + t_num_entries)->iif, sValue,
					MAX_IF_NAME_LEN);
		}

		sprintf(buf, "%s_%d_dstType", TAG_FIREWALL_PACKETFILTER, i);
		memset(sValue, '\0', sizeof(sValue));
		if (ifx_GetObjDataOpt
		    (FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, sValue) == IFX_SUCCESS) {
			(*pfRules + t_num_entries)->dstType = atoi(sValue);
		}

		sprintf(buf, "%s_%d_dstIp", TAG_FIREWALL_PACKETFILTER, i);
		memset(sValue, '\0', sizeof(sValue));
		if (ifx_GetObjDataOpt
		    (FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, sValue) == IFX_SUCCESS) {
			if (strlen(sValue) && strcmp(sValue, "*"))
				inet_aton(sValue,
					  &((*pfRules +
					     t_num_entries)->dstIP.ip));
			else
				(*pfRules + t_num_entries)->dstIP.ip.s_addr = 0;

		}

		sprintf(buf, "%s_%d_dstMask", TAG_FIREWALL_PACKETFILTER, i);
		memset(sValue, '\0', sizeof(sValue));
		if (ifx_GetObjDataOpt
		    (FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, sValue) == IFX_SUCCESS) {
			if (strlen(sValue))
				inet_aton(sValue,
					  &((*pfRules +
					     t_num_entries)->dstIP.mask));
			else
				(*pfRules + t_num_entries)->dstIP.mask.s_addr =
				    0;
		}

		temp = NULL;
		sprintf(buf, "%s_%d_dPortRange", TAG_FIREWALL_PACKETFILTER, i);
		memset(sValue, '\0', sizeof(sValue));
		if (ifx_GetObjDataOpt
		    (FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, sValue) == IFX_SUCCESS) {
			if (strlen(sValue)) {
				temp = strchr(sValue, ':');
				if (temp != NULL) {
					(*pfRules +
					 t_num_entries)->dPortRange.end_port =
				 atoi(temp + 1);
					*temp = '\0';
				}
				(*pfRules +
				 t_num_entries)->dPortRange.start_port =
			 atoi(sValue);
			}
		}

		sprintf(buf, "%s_%d_oif", TAG_FIREWALL_PACKETFILTER, i);
		memset(sValue, '\0', sizeof(sValue));
		if (ifx_GetObjDataOpt
		    (FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, sValue) == IFX_SUCCESS) {
			if (strlen(sValue))
				strncpy((*pfRules + t_num_entries)->oif, sValue,
					MAX_IF_NAME_LEN);
		}

		sprintf(buf, "%s_%d_sMacAddr", TAG_FIREWALL_PACKETFILTER, i);
		memset(sValue, '\0', sizeof(sValue));
		if (ifx_GetObjDataOpt
		    (FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, sValue) == IFX_SUCCESS) {
			if (strlen(sValue))
				strncpy((*pfRules + t_num_entries)->sMacAddr,
					sValue, MAX_MAC_ADDR_LEN);
		}

		t_num_entries++;
	}
	*num_entries = t_num_entries;

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
#else
	IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
	return IFX_FAILURE;
#endif
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_get_firewall_dmz(...)
*	xDmz	==>
*	flags	==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
Description:
//////////////////////////////////////////////////////////////////////////////*/
int32 ifx_mapi_get_firewall_dmz(IFX_MAPI_Firewall_DMZ * xDmz, uint32 flags)
{
	int32 iRet = IFX_SUCCESS;
	char8 sVal[MAX_IF_NAME];
	uint32 ulInFlag = IFX_F_DEFAULT, ulOutFlag;

	memset(xDmz, '\0', sizeof(IFX_MAPI_Firewall_DMZ));

	if ((iRet = ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_DMZ,
				   TAG_FIREWALL_DMZ "_enable",
				   ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;

	xDmz->feature_enable = atoi(sVal);

	if ((iRet = ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_DMZ,
				   TAG_FIREWALL_DMZ "_ipAddr",
				   ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;

	if (strlen(sVal) > 0)
		inet_aton(sVal, &(xDmz->ip));
	else
		xDmz->ip.s_addr = 0;

      IFX_Handler:
	return (iRet);
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_get_firewall_status(...)
 *  xFw ==>
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
Description:
  This function returns the global firewall status.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_mapi_get_firewall_status(IFX_MAPI_Firewall * xFw, uint32 flags)
{
	int32 iRet = IFX_SUCCESS;
	char8 sVal[MAX_IF_NAME];
	uint32 ulInFlag = IFX_F_DEFAULT, ulOutFlag;

	memset(xFw, '\0', sizeof(IFX_MAPI_Firewall));

	if ((iRet = ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_MAIN,
				   TAG_FIREWALL_MAIN "_enable",
				   ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
		goto IFX_Handler;

	xFw->enable = atoi(sVal);
       if ((iRet = ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_MAIN,
                                  TAG_FIREWALL_MAIN "_version",
                                  ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
               goto IFX_Handler;

       strcpy(xFw->version,sVal);

       if ((iRet = ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_MAIN,
                                  TAG_FIREWALL_MAIN "_lastchange",
                                  ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
               goto IFX_Handler;

       xFw->lastchange_time = atoi(sVal);

      IFX_Handler:
	return (iRet);
}

#ifdef CONFIG_FEATURE_URL_FILTERING
int32 mapi_set_url_entry(int32 operation, url_filter_cfg_t *entry, uint32 flags)
{
			char8 conf_buf[MAX_DATA_LEN];
			int32 count = 0, passed_index = -1, ret = IFX_SUCCESS;
			IFX_NAME_VALUE_PAIR array_fvp[6];

			NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));
			memset(array_fvp, 0, sizeof(array_fvp));

			/*************** Prolog Block *********************/
			/* Based on operation (ADD or DELETE or MODIFY) 
			 * append the flag with internal flags */
			if (operation == IFX_OP_DEL)
				flags |= IFX_F_DELETE;
			else if (operation == IFX_OP_ADD) {
				if ((IFX_MODIFY_F_NOT_SET(flags)))
					flags |= IFX_F_INT_ADD;
			} else {
				flags |= IFX_F_MODIFY;
			}
			IFX_DBG("[%s:%d] mapi_set_vlan_ch_entry called ",
				__FUNCTION__, __LINE__);

			/**************** Validation Block *****************/
			if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
				/* Do simple validation of pointer such as NULL */
				IFX_VALIDATE_PTR(entry)
				/* Do simple validation of flags such as less than 0 */
				IFX_VALIDATE_FLAGS(flags)
			}
			sprintf(entry->iid.cpeId.secName, "%s",
				TAG_URL_FILT_CFG);

			/**************** ID Allocation Block - Only for ADD Operation **************/
			if (IFX_ADD_F_SET(flags)) {
				/* Allocate the IID for this vcc */
				if (ifx_get_IID_Without_TR69(&entry->iid, "URLName") !=
				    IFX_SUCCESS) {
					//  #ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] Could not allocate IID",
					     __FUNCTION__, __LINE__);
					// #endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}
			}
			/**************** Name Value Formation as per RC.CONF ********************/

			count = 0;
			if (IFX_DELETE_F_NOT_SET(flags)) {

				IFX_DBG
				    ("[%s:%d] mapi_set_vlan_ch_entry called ",
				     __FUNCTION__, __LINE__);
				ifx_fill_ArrayFvp_FName(array_fvp, 0, 3,
							url_filt_params);

				ifx_fill_ArrayFvp_intValues(array_fvp, 0, 2,
							    (int32 *) & entry->
							    iid.cpeId.Id,
							    &entry->iid.pcpeId.
							    Id);
				sprintf(array_fvp[2].value, "%s",
					entry->URLName);

				passed_index = -1;
			}
			count = 3;

			/* Get Config Index in case of modify/delete operations from CPEID */
			if ((IFX_MODIFY_F_SET(flags))
			    || (IFX_DELETE_F_SET(flags))) {
				IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF,
							 entry->iid.cpeId,
							 passed_index)
				    IFX_DBG
				    ("[%s:%d] MODIFY DELETE CASE ENTEREd",
				     __FUNCTION__, __LINE__);
			}

			/* Determine the configuration index - for Add, Delete, Modify operations 
			 * Name is partial since index is not known 
			 * Fill array_fvp[] */
			if (ifx_get_conf_index_and_nv_pairs
			    (&entry->iid, passed_index, PREFIX_URL_FILT_CFG,
			     count, array_fvp, flags) != IFX_SUCCESS) {
				IFX_DBG
				    ("[%s:%d] Could not determine config index",
				     __FUNCTION__, __LINE__);
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}


			/*********** Device Configuration Block ****************/
			if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)
			    && IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) {

				if (IFX_DELETE_F_SET(flags)) {
					sprintf(conf_buf, "%s delete %d",
						SERVICE_URL_FILT,
						passed_index);
					ret = system(conf_buf);
				}
			}

			/************** System Config File Update Block ****************/
			/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
			form_cfgdb_buf(conf_buf, count, array_fvp);

			/* RC.CONF Configuration block */
			ret =
			    ifx_SetObjData(FILE_RC_CONF, TAG_URL_FILT_CFG,
					   flags, 1, conf_buf);

			if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("[%s:%d] ifx_SetObjData() FAIL! conf_buf[%s]",
				     __FUNCTION__, __LINE__, conf_buf);
#endif
				goto IFX_Handler;
			}

			/*********** Device Configuration Block ****************/
			/* Device config thru Scripts/Utilities or Functions */
			if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)
			    && IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) {

				if (IFX_INT_ADD_F_SET(flags)) {
					IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF,
								 entry->iid.
								 cpeId,
								 passed_index)
					sprintf(conf_buf, "%s add %d", SERVICE_URL_FILT, passed_index);
					ret = system(conf_buf);
				}
			}

			/* this will Compact the section and also update the count for both ADD and DELETE */
			if (IFX_MODIFY_F_NOT_SET(flags))
				ifx_CompactCfgSection(FILE_RC_CONF,
						      TAG_URL_FILT_CFG, flags);

    /*********** Notification Block *************/
			/* Notify the Internal TR69 Stack in case of MODIFY */

			/*********** Epilog Block **************/
			/* Update the IID mappings in the mappings section for ADD/DELETE */
			if (IFX_MODIFY_F_NOT_SET(flags)) {
				    /* Manipulate nextCpeId only for ADD operations */
				    ifx_increment_next_cpeId(FILE_RC_CONF,
							     TAG_URL_FILT_CFG);
			}

			/* Updating Persistent Storage */
			ret = ifx_config_write(FILE_RC_CONF, flags);
			if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("[%s:%d] Updating Persistent Storage FAIL",
				     __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}

		      IFX_Handler:
			if (ret != IFX_SUCCESS) {
				IFX_API_LOG("[%s] : returned failure!",
					    __FUNCTION__);
				return ret;
			} else
				return IFX_SUCCESS;
}

int32 mapi_get_all_url_entries(int32 *num_entries, url_filter_cfg_t **url_filcfg, uint32 flags)
{
		uint32 outFlag = IFX_F_DEFAULT;
		char8 buf[MAX_FILELINE_LEN], sIndexes[MAX_FILELINE_LEN];
		int32 ret = IFX_SUCCESS, idx_count = 0, i = 0;
		char8 secName[MAX_TAG_LEN], SECTION_PREFIX[MAX_TAG_LEN];
		url_filter_cfg_t *t_ptr = NULL, url_filt;

		NULL_TERMINATE(buf, 0x00, sizeof(buf));
		NULL_TERMINATE(sIndexes, 0x00, sizeof(sIndexes));

		sprintf(secName, "%s", TAG_URL_FILT_CFG);
		sprintf(SECTION_PREFIX, "%s", PREFIX_URL_FILT_CFG);

		MAKE_SECTION_COUNT_TAG(secName, buf);
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, secName, buf, flags, &outFlag,
				    sIndexes)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		idx_count = atoi(sIndexes);
		IFX_MEM_ALLOC(t_ptr, url_filter_cfg_t *, idx_count,
			      sizeof(url_filter_cfg_t))
		    if (t_ptr == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}

	//	*url_filcfg = t_ptr;
                if (url_filcfg == NULL || t_ptr == NULL ) {
		//if (url_filcfg == NULL || *url_filcfg == NULL) {
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		*url_filcfg = t_ptr;

		for (i = 0; i < idx_count; i++) {
			memset(&url_filt, 0x00, sizeof(url_filt));
			*num_entries += 1;
			if ((ret =
			     mapi_get_url_entry(i, &url_filt,
						    flags)) != IFX_SUCCESS) {
				goto IFX_Handler;
			}
			memcpy((*url_filcfg + i), &url_filt, sizeof(url_filt));
		}

	      IFX_Handler:
		if (ret != IFX_SUCCESS) {
			IFX_MEM_FREE(*url_filcfg)
			    * num_entries = 0;
			IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
			return ret;
		} else
			return IFX_SUCCESS;
}

int32 mapi_get_url_entry(int32 urlFiltIdx, url_filter_cfg_t * url_filt_cfg,
				     uint32 flags)
{

		IFX_ID iid;
		int32 dist_urlfilt_idx = -1;
		char8 buf[MAX_FILELINE_LEN], retVal[MAX_FILELINE_LEN];
		int32 ret = IFX_SUCCESS, outFlag = IFX_F_DEFAULT;
		url_filter_cfg_t url_filt;
		char8 SECTION_TAG[MAX_TAG_LEN];
		char8 SECTION_PREFIX[MAX_TAG_LEN];
		memset(SECTION_PREFIX, 0x00, MAX_TAG_LEN);
		memset(SECTION_TAG, 0x00, MAX_TAG_LEN);

		sprintf(iid.cpeId.secName, "%s", TAG_URL_FILT_CFG);
		sprintf(SECTION_TAG, "%s", TAG_URL_FILT_CFG);
		sprintf(SECTION_PREFIX, "%s", PREFIX_URL_FILT_CFG);

		if (urlFiltIdx < 0) {
			/*check if cpe Id is passed */
			if (url_filt.iid.cpeId.Id < 1) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] cpeId invalid", __FUNCTION__,
					__LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			iid.cpeId.Id = url_filt.iid.cpeId.Id;

			if (ifx_get_index_from_cpe_id
			    (FILE_RC_CONF, &iid.cpeId,
			     &dist_urlfilt_idx) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("[%s:%d] Unable to retrieve wan index from cpeId",
				     __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		} else {
			dist_urlfilt_idx = urlFiltIdx;
		}

		sprintf(buf, "%s_%d_cpeId", SECTION_PREFIX, dist_urlfilt_idx);
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, SECTION_TAG, buf, flags,
				    (IFX_OUT uint32 *) & outFlag,
				    retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve cpe Id",
				__FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		url_filt.iid.cpeId.Id = atoi(retVal);

		sprintf(buf, "%s_%d_pcpeId", SECTION_PREFIX, dist_urlfilt_idx);
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, SECTION_TAG, buf, flags,
				    (IFX_OUT uint32 *) & outFlag,
				    retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve  parent cpe Id",
				__FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		url_filt.iid.pcpeId.Id = atoi(retVal);

		sprintf(buf, "%s_%d_URLName", SECTION_PREFIX, dist_urlfilt_idx);
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, SECTION_TAG, buf, flags,
				    (IFX_OUT uint32 *) & outFlag,
				    retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve enable status",
				__FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		snprintf(url_filt.URLName, MAX_NAME_LEN,"%s", retVal);

		memcpy(url_filt_cfg, &url_filt, sizeof(url_filt));
	      IFX_Handler:
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s] : returned failure!", __FUNCTION__);
#endif
			return ret;
		} else {
			return IFX_SUCCESS;
		}
}
#endif
