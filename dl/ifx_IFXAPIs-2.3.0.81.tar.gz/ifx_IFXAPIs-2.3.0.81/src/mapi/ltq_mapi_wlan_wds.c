/******************************************************************************

                               Copyright (c) 2008
                            Infineon Technologies AG
                     Am Campeon 1-12; 81726 Munich, Germany

  THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED NON-EXCLUSIVE,
  WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE AND SUBLICENSE THIS
  SOFTWARE IS FREE OF CHARGE.

  THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY DISCLAIMS
  ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR IMPLIED, INCLUDING
  WITHOUT LIMITATION, WARRANTIES OR REPRESENTATIONS OF WORKMANSHIP,
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, DURABILITY, THAT THE
  OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR FREE OR FREE OF ANY THIRD
  PARTY CLAIMS, INCLUDING WITHOUT LIMITATION CLAIMS OF THIRD PARTY INTELLECTUAL
  PROPERTY INFRINGEMENT.

  EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND EXCEPT
  FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE FOR ANY CLAIM
  OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
  ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
  DEALINGS IN THE SOFTWARE.

******************************************************************************/

/**
   \file ltq_mapi_wlan_wds.c
*/

#if defined (CONFIG_FEATURE_IFX_WIRELESS)

/* ========================================================================== */
/*                                 Includes                                   */
/* ========================================================================== */
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"

/* included for definition of bool */
#include "ifx_api_ipt_common.h"

/* ========================================================================== */
/*                             Macro definitions                              */
/* ========================================================================== */
#define WLAN_WDS_PARAM_COUNT	6
#define WLAN_WDS_PEER_MAC_PARAM_COUNT 3

/* ========================================================================== */
/*                             Type definitions                               */
/* ========================================================================== */

/* ========================================================================== */
/*                             Global variables                               */
/* ========================================================================== */
char8 *wlan_wds_params[] =
    { "cpeId", "pcpeId", "enable", "encrType", "peerAPKeyIdx", "numPeerAPs"
};

char8 *wlan_wds_mac_params[] = { "cpeId", "pcpeId", "peerAP" };

extern IFX_MAPI_WLAN_MainCfg	g_wlMain[];
extern IFX_MAPI_WLAN_PhyCfg		g_wlPhy[];

LTQ_MAPI_WLAN_WDS_Cfg	g_wlWdsCfg[LTQ_MAX_NUM_VAP];
int						g_flagWdsConfig = 0;
extern int				g_nVap;

/* ========================================================================== */
/*                           Function prototypes                              */
/* ========================================================================== */

/* ========================================================================== */
/*                         Function implementation                            */
/* ========================================================================== */

/**
   This api reads wlan wps parameters from rc.conf and returns them in wlWdsCfg

   \param   wlWdsCfg - pointer to LTQ_MAPI_WLAN_WDS_Cfg structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ltq_mapi_get_wlan_wds_config(LTQ_MAPI_WLAN_WDS_Cfg * wlWdsCfg, uint32 flags)
{
	int32					passed_index = -1, ret = IFX_SUCCESS;
	LTQ_MAPI_WLAN_WDS_Cfg	*wlWdsCfgAll = NULL;
	uint32					nWdsEntries = 0;
	/* to synchronize between web and devm at the mapi level */
	FILE *fptr = NULL;
	char mapi_flg=0;

	LTQ_LOG_TIMESTAMP("Begin");

	sprintf(wlWdsCfg->iid.cpeId.secName, "%s", TAG_WLAN_WDS);

	/* get index from cpeid: example wlwds_0_cpeId="2" => passed_index = 2 */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlWdsCfg->iid.cpeId, passed_index)
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_wds_config", "passed_index: %d",
		passed_index);

	// to synchronize between web and tr069 ot UPnP at the mapi level
	fptr = fopen("/tmp/web_Wdsflg","r+");
	if(fptr) {
		mapi_flg=fgetc(fptr);
		fclose(fptr);
	}

	if (wlWdsCfg->iid.config_owner == IFX_WEB) {
		if ((mapi_flg == '0') || (mapi_flg == '2'))
			g_flagWdsConfig = 0;
	}
	else {
		if ((mapi_flg == '0') || (mapi_flg == '1'))
			g_flagWdsConfig = 0;
	}

	/* if configuration is already available, take it from there (g_wlWdsCfg) */
	if (!g_flagWdsConfig) {
		if ((ret = ltq_mapi_get_all_wlan_wds_config(&nWdsEntries, &wlWdsCfgAll,
			IFX_F_DEFAULT)) != IFX_SUCCESS) {
				goto IFX_Handler;
		}
		g_nVap = nWdsEntries;
	}
	memcpy(wlWdsCfg, &g_wlWdsCfg[passed_index], sizeof(LTQ_MAPI_WLAN_WDS_Cfg));

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_wds_config", "ret: %d", ret);
	IFX_MEM_FREE(wlWdsCfgAll);
	LTQ_LOG_TIMESTAMP("Done");
	return ret;
}

/**
   This api reads the count, gets the complete wlan_wds object and saves
   the configuration to wlWdsCfg

   \param   numEntries  -

   \param   wlWdsCfg    - pointer to LTQ_MAPI_WLAN_WDS_Cfg structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ltq_mapi_get_all_wlan_wds_config(	uint32 * numEntries,
										LTQ_MAPI_WLAN_WDS_Cfg ** wlWdsCfg,
										uint32 flags)
{
	int32	ret = IFX_SUCCESS, nCount = 0, i = 0, nParamCount = 0;
	char8	sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN], *sWlanWdsObject = NULL;
	IFX_NAME_VALUE_PAIR	array_fvp[LTQ_MAX_NUM_VAP*WLAN_WDS_PARAM_COUNT];
	// to synchronize between web and devm layer at the mapi level
	FILE *fptr = NULL;
	char mapi_flg=0;
	uint32 outFlag = IFX_F_DEFAULT;

	LTQ_LOG_TIMESTAMP("Begin");

	MAKE_SECTION_COUNT_TAG(TAG_WLAN_WDS, buf);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_WDS, buf, flags, &outFlag,
		sValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wds_config", "");
		goto IFX_Handler;
	}

	nCount = atoi(sValue);
	if (nCount <= 0) {
		*numEntries = 0;
		*wlWdsCfg = NULL;
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wds_config", "");
		goto IFX_Handler;
	}

	*wlWdsCfg = NULL;
	if (nCount <= LTQ_MAX_NUM_VAP) {
		IFX_MEM_ALLOC((*wlWdsCfg), LTQ_MAPI_WLAN_WDS_Cfg *, nCount,
			      sizeof(LTQ_MAPI_WLAN_WDS_Cfg))
	} else {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wds_config", "");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	// to synchronize between web and devm at the mapi level
	fptr = fopen("/tmp/web_Wdsflg","r+");
	if(fptr) {
		mapi_flg=fgetc(fptr);
		fclose(fptr);
	}

	if (IFX_RESET_WEB_CFG_F_SET(flags)) {
		if ((mapi_flg == '0') || (mapi_flg == '2'))
			g_flagWdsConfig = 0;
	}
	else {
		if ((mapi_flg == '0') || (mapi_flg == '1'))
			g_flagWdsConfig = 0;
	}

	/* if configuration is already available, return immediately */
	if (g_flagWdsConfig) {
		memcpy(*wlWdsCfg, g_wlWdsCfg, sizeof(LTQ_MAPI_WLAN_WDS_Cfg) * nCount);
		*numEntries = g_nVap;
		goto IFX_Handler;
	}

	sprintf(buf, "%s_", PREFIX_WLAN_WDS);
	if ((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_WDS, buf, IFX_F_DEFAULT,
		&sWlanWdsObject)) != IFX_SUCCESS)
		goto IFX_Handler;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wds_config",
		"buf: %s, sValue: %s", buf, sWlanWdsObject);

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sWlanWdsObject, &nParamCount, array_fvp);

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wds_config", "");
	for (i = 0; i < nCount; i++) {
		sprintf((*wlWdsCfg + i)->iid.cpeId.secName, "%s", TAG_WLAN_WDS);
		sprintf((*wlWdsCfg + i)->iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
		(*wlWdsCfg + i)->iid.cpeId.Id 	= atoi(array_fvp[i * WLAN_WDS_PARAM_COUNT].value);
		(*wlWdsCfg + i)->iid.pcpeId.Id 	= atoi(array_fvp[i * WLAN_WDS_PARAM_COUNT + 1].value);
		(*wlWdsCfg + i)->enable 	= atoi(array_fvp[i * WLAN_WDS_PARAM_COUNT + 2].value);
		(*wlWdsCfg + i)->secMode 	= atoi(array_fvp[i * WLAN_WDS_PARAM_COUNT + 3].value);
		(*wlWdsCfg + i)->peerAPKeyIdx 	= atoi(array_fvp[i * WLAN_WDS_PARAM_COUNT + 4].value);
		(*wlWdsCfg + i)->nPeerAPs 	= atoi(array_fvp[i * WLAN_WDS_PARAM_COUNT + 5].value);
	}
	*numEntries = nCount;
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wds_config", "*numEntries: %d", *numEntries);

	/* store in global variables for later usage */
	memcpy(g_wlWdsCfg, *wlWdsCfg, sizeof(LTQ_MAPI_WLAN_WDS_Cfg) * nCount);
	g_nVap = *numEntries;
	/* flag to indicate that WDS configuration is available in global variable */
	g_flagWdsConfig = 1;
	if (IFX_RESET_WEB_CFG_F_SET(flags)) {
		if (mapi_flg == '0')
			system("echo 1 > /tmp/web_Wdsflg &");
		else if (mapi_flg == '2')
			system("echo 3 > /tmp/web_Wdsflg &");
		else
			system("echo 1 > /tmp/web_Wdsflg &");
	}
	else {
		if (mapi_flg == '0')
			system("echo 2 > /tmp/web_Wdsflg &");
		else if (mapi_flg == '1')
			system("echo 3 > /tmp/web_Wdsflg &");
		else
			system("echo 2 > /tmp/web_Wdsflg &");
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wds_config", "ret: %d", ret);
	IFX_MEM_FREE(sWlanWdsObject);
	/* free memory in case of error, otherwise it gets freed in calling
	   function */
	if (ret != IFX_SUCCESS)
		IFX_MEM_FREE(*wlWdsCfg)
	LTQ_LOG_TIMESTAMP("Done");
	return ret;
}

/**
   \param   mnCpeId  -

   \param   numEntries  -

   \param   wlWdsPeerMac - pointer to IFX_MAPI_WLAN_MAC_Control config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ltq_mapi_get_all_wlan_wds_peer_mac(uint32 mnCpeId, uint32 * numEntries,
	IFX_MAPI_WLAN_MAC_Control ** wlWdsPeerMac, uint32 flags)
{
	int32 ret = IFX_SUCCESS, nAllWdsPeerMacs = 0, i = 0, nMacEntries = 0;
	int32 count = 0;
	char8 sWdsPeerMacCountVal[MAX_DATA_LEN], buf[MAX_FILELINE_LEN];
	char8 *sValue2 = NULL;
	uint32 outFlag = IFX_F_DEFAULT, pcpeId;
	/* size of array: max. number of VAP * max.number of entries * number of params */
	IFX_NAME_VALUE_PAIR array_fvp[LTQ_MAX_NUM_VAP*WLAN_WDS_PEER_MAC_PARAM_COUNT*LTQ_MAX_NUM_MAC_FILTER_ENTRIES];
	IFX_MAPI_WLAN_Capability wlCaps;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wds_peer_mac", "mainCPeId: %d", mnCpeId);

	MAKE_SECTION_COUNT_TAG(TAG_WLAN_WDS_PEER_MAC, buf);
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_WDS_PEER_MAC, buf, flags,
			    &outFlag, sWdsPeerMacCountVal)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}

	nAllWdsPeerMacs = atoi(sWdsPeerMacCountVal);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wds_peer_mac",
		"nAllWdsPeerMacs: %d", nAllWdsPeerMacs);
	if (nAllWdsPeerMacs == 0) {
		*numEntries = 0;
		*wlWdsPeerMac = NULL;
		goto IFX_Handler;
	}

	if (ifx_mapi_get_wlan_capability(&wlCaps, IFX_F_DEFAULT) !=
		IFX_SUCCESS) {
		goto IFX_Handler;
	}

	*wlWdsPeerMac = NULL;
	/* 32 per VAP * max number of VAP = 32 * 16 */
	if (nAllWdsPeerMacs <= LTQ_MAX_NUM_VAP * wlCaps.numMacCntrlEntries) {
		IFX_MEM_ALLOC((*wlWdsPeerMac), IFX_MAPI_WLAN_MAC_Control *,
			nAllWdsPeerMacs, sizeof(IFX_MAPI_WLAN_MAC_Control))
	} else {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wds_peer_mac",
			"max number of entries reached");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wds_peer_mac",
		"wlWdsPeerMac: %p, size: %d", *wlWdsPeerMac, sizeof(IFX_MAPI_WLAN_MAC_Control) * nAllWdsPeerMacs);

	sprintf(buf, "%s_", PREFIX_WLAN_WDS_PEER_MAC);
	if ((ret =
	     ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_WDS_PEER_MAC, buf, IFX_F_DEFAULT,
			      &sValue2)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wds_peer_mac",
			       "buf: %s", buf);
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wds_peer_mac",
		       "buf: %s, sValue2: %s", buf, sValue2);

	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sValue2, &count, array_fvp);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wds_peer_mac", "count: %d", count);

	nMacEntries = 0;
	for (i = 0; i < nAllWdsPeerMacs; i++) {
		pcpeId = atoi(array_fvp[3 * i + 1].value);
		if (pcpeId == mnCpeId) {
			/* we are overwriting limit of allocated memory */
			if (nMacEntries >= nAllWdsPeerMacs) {
				IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wds_peer_mac",
					"Too many MACs: %d", nMacEntries);
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			(*wlWdsPeerMac + nMacEntries)->iid.cpeId.Id =
			    atoi(array_fvp[3 * i].value);
			(*wlWdsPeerMac + nMacEntries)->iid.pcpeId.Id = pcpeId;
			snprintf((*wlWdsPeerMac + nMacEntries)->iid.cpeId.secName,
				MAX_TAG_NAME_LEN, "%s", TAG_WLAN_WDS_PEER_MAC);
			snprintf((*wlWdsPeerMac + nMacEntries)->iid.pcpeId.secName,
				MAX_TAG_NAME_LEN, "%s", TAG_WLAN_MAIN);
			snprintf((*wlWdsPeerMac + nMacEntries)->macAddr,
				 IFX_MAPI_MAC_ADDR_LEN, "%s",
				 array_fvp[3 * i + 2].value);
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wds_peer_mac",
				"macAddr: %s", (*wlWdsPeerMac + nMacEntries)->macAddr);
			nMacEntries++;
		}
	}
	*numEntries = nMacEntries;
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wds_peer_mac",
		"numEntries: %d", *numEntries);

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_all_wlan_wds_peer_mac", "ret: %d", ret);
	IFX_MEM_FREE(sValue2)
	/*
	   in case of error free allocated memory here, otherwise it must be
	   freed in calling function */
	if (ret != IFX_SUCCESS)
		IFX_MEM_FREE(*wlWdsPeerMac)

	return ret;
}

/**
   This API configures the WLAN WDS peer MAC list

   \param   oper  - type of operation (ADD, MODIFY, DELETE)

   \param   wlWdsPeerMac - pointer to IFX_MAPI_WLAN_MAC_Control structure

   \param   flags - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ltq_mapi_set_wlan_wds_peer_mac(uint32 oper,
			IFX_MAPI_WLAN_MAC_Control * wlWdsPeerMac,
			uint32 flags)
{
	int32				ret = IFX_SUCCESS, passed_index = -1, count = 0, i = 0;
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_WDS_PEER_MAC_PARAM_COUNT];
	char8				conf_buf[MAX_SECTION_DATA_LEN];
	IFX_ID 				parent_iid;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_peer_mac", "");

	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
	memset(array_fvp, 0x00, sizeof(array_fvp));
	memset(&parent_iid, 0, sizeof(parent_iid));

	/*************** Prolog Block *********************/
	/*
	 * Based on operation (ADD or DELETE or MODIFY) append the flag with
	 * internal flags
	*/
	if (oper == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (oper == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	}
	else
		flags |= IFX_F_MODIFY;

	/**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(wlWdsPeerMac)
	    /* do simple validation of flags sucha as less than 0 */
	    IFX_VALIDATE_FLAGS(flags)
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_peer_mac", "");

	sprintf(wlWdsPeerMac->iid.cpeId.secName, "%s", TAG_WLAN_WDS_PEER_MAC);
	/* since this object is not in tr69-model */
	sprintf(wlWdsPeerMac->iid.pcpeId.secName, "%s", TAG_WLAN_WDS);

	parent_iid.cpeId.Id = wlWdsPeerMac->iid.pcpeId.Id;
	sprintf(parent_iid.cpeId.secName, "%s",
			wlWdsPeerMac->iid.pcpeId.secName);

	if (IFX_ADD_F_SET(flags)) {
		/* Allocate the IID for this mac-control instance Set the parent
		   SectionName and parent IID values to NULL as there is no parent for
		   Route Entity */
		if (ifx_get_iid(TAG_WLAN_WDS_PEER_MAC, TAG_WLAN_WDS, &parent_iid,
				&wlWdsPeerMac->iid) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_peer_mac", "");
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_peer_mac", "");

	/*********************** Name Value Formation as per RC.CONF **********************/
	if (IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, 0, WLAN_WDS_PEER_MAC_PARAM_COUNT,
			wlan_wds_mac_params);

		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 2,
				(int32 *) & wlWdsPeerMac->iid.cpeId.Id,
				&wlWdsPeerMac->iid.pcpeId.Id);
		sprintf(array_fvp[2].value, "%s", wlWdsPeerMac->macAddr);
		passed_index = -1;
	}
	count = WLAN_WDS_PEER_MAC_PARAM_COUNT;
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_peer_mac", "count: %d", count);

	/* Get Config Index in case of modify/delete operations from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlWdsPeerMac->iid.cpeId,
					 passed_index)
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_peer_mac", "passed_index: %d", passed_index);

	if (ifx_get_conf_index_and_nv_pairs(&wlWdsPeerMac->iid, passed_index,
			PREFIX_WLAN_WDS_PEER_MAC, count, array_fvp, flags) != IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_peer_mac", "passed_index: %d", passed_index);
	for (i = 0; i < WLAN_WDS_PEER_MAC_PARAM_COUNT; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_peer_mac",
			"name: %s, value: %s", array_fvp[i].fieldname, array_fvp[i].value);

	/* Convert the name value pair in array_fvp into string format expected by
	   rc.conf file */
	memset(conf_buf, 0x00, sizeof(conf_buf));
	if ((ret = form_cfgdb_buf(conf_buf, count, array_fvp)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_peer_mac", "");
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_peer_mac", "conf_buf: %s",
		       conf_buf);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_WDS_PEER_MAC, flags, 1, conf_buf);
	if (ret != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_peer_mac", "");

	/*********** Device Configuration Block ****************/
	/* empty for WDS Peer MAC */

	/*********** Epilog Block **************/
	/*
	 * this will Compact the section and also update the count for both ADD and
	 * DELETE
	 */
	if (IFX_MODIFY_F_NOT_SET(flags)) {
			ifx_CompactCfgSection(FILE_RC_CONF, TAG_WLAN_WDS_PEER_MAC, flags);
	}

	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_INT_ADD_F_SET(flags)) {
		/* since this object is not in tr-98 model no need to call update_map
		   and notification here */
		/* Manipulate nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WLAN_WDS_PEER_MAC);
	}
	else if (IFX_DELETE_F_SET(flags)) {
			/* since this object is not in tr-98 model no need to call update_map
			   and notification here */
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_peer_mac", "");

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_peer_mac", "");
	
IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_peer_mac", "ret: %d", ret);
	return ret;
}

/*   This api sets wlan wps parameters available in wlWdsCfg

   \param oper

   \param   wlWdsCfg - pointer to LTQ_MAPI_WLAN_WDS_Cfg structure

   \param flags

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int32
ltq_mapi_set_wlan_wds_config(uint32 operation,
	LTQ_MAPI_WLAN_WDS_Cfg * wlWdsCfg, uint32 flags)
{
	IFX_MAPI_WLAN_PhyCfg 	wlPhy;
	bool 					f_PhyCfgChanged = FALSE;
	uint32	outFlag = IFX_F_DEFAULT, radioCpeId = 0;
	CPE_ID parentCpeId;
	int32 ret = IFX_SUCCESS, count = 0, changed_count = 0, apIdx = -1, i = 0;
	char8 conf_buf[MAX_SECTION_DATA_LEN], buf[MAX_FILELINE_LEN];
	char8 sValue[MAX_FILELINE_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_WDS_PARAM_COUNT];
	IFX_NAME_VALUE_PAIR *array_changed_fvp = NULL;
	LTQ_MAPI_WLAN_Feature	features = LTQ_MAPI_WLAN_FEATURE_NONE;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "wlwdsCfg: %p", wlWdsCfg);
	/*
	   initalize buffer conf_buf which is used for two purposes: - holding the
	   configuration for wlWdsCfg to be written to rc.conf - holding the commands
	   for system calls */
	memset(conf_buf, 0x00, sizeof(conf_buf));
	/*
	   initalize buffer array_fvp which is used for storing the new
	   configuration of wlWdsCfg in field-value format */
	memset(array_fvp, 0x00, sizeof(array_fvp));

	/*************** Validation Block *****************/
	/*
	   for operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer (such as is NULL) */
		IFX_VALIDATE_PTR(wlWdsCfg)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "flags: 0x%x", flags);
		/* Do simple validation of flags such as less than 0 */
		IFX_VALIDATE_FLAGS(flags)
	}

   /*************** Prolog Block *********************/
	/*
	   based on the operation (ADD or DELETE or MODIFY), the flags variable is
	   appended with internal flags */

	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if ((IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	} else
		flags |= IFX_F_MODIFY;

	/* section name of this object is TAG_WLAN_WDS */
	sprintf(wlWdsCfg->iid.cpeId.secName, "%s", TAG_WLAN_WDS);
	/* section name of parent object is TAG_WLAN_MAIN */
	sprintf(wlWdsCfg->iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);

	/* Get Config Index in case of modify/delete operations from CPEID */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		/* use the parent cpeid to get index of the parent instance */
		parentCpeId.Id = wlWdsCfg->iid.pcpeId.Id;
		sprintf(parentCpeId.secName, "%s", TAG_WLAN_MAIN);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config",
			"Id: %d, section: %s", parentCpeId.Id, parentCpeId.secName);
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, parentCpeId, apIdx)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "apIdx: %d", apIdx);
	}

	if (IFX_MODIFY_F_SET(flags)) {
		if (wlWdsCfg->enable == TRUE) {
			/*
				check if initial channel selection or 20/40 coexistance feature are
				enabled and disable these if appropriate
			*/
			sprintf(buf, "%s_%d_radioCpeId", PREFIX_WLAN_MAIN, apIdx);
			if ((ret =
				ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAIN, buf, IFX_F_DEFAULT,
			    &outFlag, sValue)) != IFX_SUCCESS) {
				IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "");
				goto IFX_Handler;
			}
			radioCpeId = atoi(sValue);
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config",
				"radioCpeId: %d", radioCpeId);

			/* get the phy configuration */
			memset(&wlPhy, 0, sizeof(IFX_MAPI_WLAN_PhyCfg));
			sprintf(wlPhy.iid.cpeId.secName, "%s", TAG_WLAN_PHY);
			sprintf(wlPhy.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
			wlPhy.iid.cpeId.Id = radioCpeId;
			if ((ret = ifx_mapi_get_wlan_phy_config(&wlPhy, IFX_F_GET_ANY)) !=
				IFX_SUCCESS) {
				IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "");
				goto IFX_Handler;
			}
			if (wlPhy.autoChannelEna == TRUE) {
				f_PhyCfgChanged = TRUE;
				wlPhy.autoChannelEna = FALSE;
				/* for non-N modes the channel bandwidth must be set to 20MHz */
				if (wlPhy.standard < IFX_MAPI_WLAN_STD_802_11N) {
					wlPhy.phy11N.chanBW = IFX_MAPI_WLAN_BW_20MHZ;
				} else {
					if (wlPhy.phy11N.chanBW > IFX_MAPI_WLAN_BW_20MHZ)
						wlPhy.phy11N.chanBW = IFX_MAPI_WLAN_BW_40MHZ;
				}

				if (wlPhy.freqBand == IFX_MAPI_WLAN_2_4_GHz_Freq) {
					wlPhy.channelNo = 6;
				}
				else {
					/* in 5GHz always use extension channel position below */
					wlPhy.phy11N.extChPos = IFX_MAPI_WLAN_EXT_ABV_CC;
					wlPhy.channelNo = 36;
				}
			}
			if (wlPhy.phy11N.twentyFourtyCoex == TRUE) {
				f_PhyCfgChanged = TRUE;
				wlPhy.phy11N.twentyFourtyCoex = FALSE;
			}
			wlPhy.iid.config_owner = wlWdsCfg->iid.config_owner;
			if (f_PhyCfgChanged) {
				if ((ret = ifx_mapi_set_wlan_phy_config(IFX_OP_MOD, &wlPhy,
					IFX_F_MODIFY | IFX_F_DONT_WRITE_TO_FLASH | IFX_F_INT_DONT_CONFIGURE))
					!= IFX_SUCCESS) {
					IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "");
					goto IFX_Handler;
				}
			}
		}
	}

	/*************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_ADD_F_SET(flags)) {
		/*
		   get the next cpe id for the section wlWdsCfg from the next_cpe_id
		   section in rc.conf and store it as cpeId; the distinct parameter
		   enable is provided for TR69 */
		if (ifx_get_IID(&wlWdsCfg->iid, "enable") != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "");
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "tr69Id: %s",
			wlWdsCfg->iid.tr69Id);
	}

   /**************** Name Value Formation as per RC.CONF ********************/
	/*
	   form the field-value pairs(FVP) from the given structure for ADD/MODIFY
	   Operations */
	count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		/*
		   the buffer array_fvp is filled in a first step with the field names
		   of wlan_sta_wmm object */
		ifx_fill_ArrayFvp_FName(array_fvp, count, WLAN_WDS_PARAM_COUNT, wlan_wds_params);

		sprintf(array_fvp[0].value, "%d", wlWdsCfg->iid.cpeId.Id);
		sprintf(array_fvp[1].value, "%d", wlWdsCfg->iid.pcpeId.Id);
		sprintf(array_fvp[2].value, "%d", wlWdsCfg->enable);
		sprintf(array_fvp[3].value, "%d", wlWdsCfg->secMode);
		sprintf(array_fvp[4].value, "%d", wlWdsCfg->peerAPKeyIdx);
		sprintf(array_fvp[5].value, "%d", wlWdsCfg->nPeerAPs);
	}

	/* store number of parameters for wlan_sta_wmm object in count */
	count = WLAN_WDS_PARAM_COUNT;

	if (ifx_get_conf_index_and_nv_pairs(&wlWdsCfg->iid, apIdx, PREFIX_WLAN_WDS,
		count, array_fvp, flags) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "");
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "count: %d", count);

   /********* ACL Checking block - MUST for MODIFY/DELETE operations **********/
	if(IFX_ADD_F_NOT_SET(flags) && IFX_INT_DONT_CHECK_ACL_F_NOT_SET(flags)) {
		/*
		   for modify operations only an array for changed parameters is saved
		   in array_changed_fvp; for modify and delete operation also a TR69
		   plugin is called for access control check */
		CHECK_ACL_RET(wlWdsCfg->iid, count, array_fvp, changed_count,
			array_changed_fvp, flags, IFX_Handler)
	}

	for (i = 0; i < WLAN_WDS_PARAM_COUNT; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "name: %s, value: %s",
		array_fvp[i].fieldname, array_fvp[i].value);

	/*
		before updating the config file: stop the AP/VAP in case of delete
		operation only
	*/
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags) && IFX_DELETE_F_SET(flags)) {
		sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, apIdx);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "conf_buf: %s",
			conf_buf);
		system(conf_buf);
	}

	/*************** System Config File Update Block ****************/
	/*
	   convert the name value pair in array_fvp into string format expected by
	   rc.conf file */
	if ((ret = form_cfgdb_buf(conf_buf, count, array_fvp)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "");
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "conf_buf: %s",
		conf_buf);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_WDS, flags, 1, conf_buf);
	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "");
		goto IFX_Handler;
	}

	/**************** Device Configuration Block *********************/
	/*
	   Device config thru Scripts/Utilities or Functions after config file
	   update, for modify operation start script for applying the changes */
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags)) {
		if (operation == IFX_OP_MOD) {
			if (g_wlPhy[g_wlMain[apIdx].radioCpeId - 1].radioEnable) {
				if (!f_PhyCfgChanged) {
					if (g_wlMain[apIdx].apEnable) {
						sprintf(conf_buf, "%s %d", SERVICE_WLAN_WDS_CONFIG, apIdx);
						IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "conf_buf: %s",
							conf_buf);
						system(conf_buf);
					}
				} else {
					features = ltq_mapi_get_wlan_supported_features(
						g_wlMain[apIdx].radioCpeId, IFX_F_DEFAULT);
					if (features & LTQ_MAPI_WLAN_FEATURE_OPT_SCRIPTS) {
					/*
						the PHY configuration had to be updated, therefore
						it is mandatory to call the radio modify script now
					*/
						sprintf(conf_buf, "%s %d 1", SERVICE_WLAN_RADIO_MODIFY,
							g_wlMain[apIdx].radioCpeId - 1);
						IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config",
							"conf_buf: %s",	conf_buf);
						system(conf_buf);
						/* now call wds modify script also */
						if (g_wlMain[apIdx].apEnable) {
							sprintf(conf_buf, "%s %d", SERVICE_WLAN_WDS_CONFIG, apIdx);
							IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "conf_buf: %s",
								conf_buf);
							system(conf_buf);
						}
					} else {
						/*
							the PHY configuration had to be updated, therefore
							it is mandatory to restart the AP now
						*/
						sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, apIdx);
						IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "conf_buf: %s",
							conf_buf);
						system(conf_buf);
						sprintf(conf_buf, "%s %d", SERVICE_WLAN_START, apIdx);
						IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "conf_buf: %s",
							conf_buf);
						system(conf_buf);
					}
				}
			}
		}
	}

	if (IFX_MODIFY_F_NOT_SET(flags)) {
		ret = ifx_UpdateCountInSection(FILE_RC_CONF, TAG_WLAN_WDS, flags);
		if (ret != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "ret: %d", ret);
			goto IFX_Handler;
		}
	}

   /*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

   /*********** Epilog Block **************/
	/*
	 * this will Compact the section and also update the count for both ADD and
	 * DELETE
	 */
	if (IFX_MODIFY_F_NOT_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "");
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_WLAN_WDS, flags);
	}

	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_MODIFY_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "");
		CHECK_N_SEND_NOTIFICATION(wlWdsCfg->iid, changed_count,
			array_changed_fvp, flags, IFX_Handler)
	} else if (IFX_INT_ADD_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "");
		/*
			in case of ADD operation update the ID Mappings, then send
			notification
		*/
		/*********** Epilog Block **************/
#if 0
		UPDATE_ID_MAP_N_ATTRIBUTES(&wlWdsCfg->iid, count, array_fvp, flags, IFX_Handler)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "flags:0x%x", flags);
		if (IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(flags)) {
			CHECK_N_SEND_NOTIFICATION(wlWdsCfg->iid, count, array_fvp, flags, IFX_Handler)
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "");
#endif

		/* Manipulate nextCpeId only for ADD operations */
		ret = ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WLAN_WDS);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "");
		if (ret != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config",
				"ret: %d", ret);
			goto IFX_Handler;
		}
	} else if (IFX_DELETE_F_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "");
#if 0
		/*
		   in case of DELETE operation send notification, then update the ID
		   Mappings */
		if (IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(flags)) {
			CHECK_N_SEND_NOTIFICATION(wlWdsCfg->iid, count, array_fvp, flags, IFX_Handler)
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "");
		/*
			The TR69 mapping section is updated. Also the TR69 parameter
			Attribute section is updated. This is required to keep the TR69
			specific sections up-to-date. */
		UPDATE_ID_MAP_N_ATTRIBUTES(&wlWdsCfg->iid, count, array_fvp, flags, IFX_Handler)
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "");
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "");

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "ret: %d", ret);
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "apIdx: %d", apIdx);

	if (IFX_ADD_F_SET(flags)) {
		/* reset flags to reload configuration */
		g_flagWdsConfig = 0;
	} else {
		/* update cpeId and pcpeID and save to global storage */
		wlWdsCfg->iid.cpeId.Id 	= atoi(array_fvp[0].value);
		wlWdsCfg->iid.pcpeId.Id = atoi(array_fvp[1].value);
		memcpy(&g_wlWdsCfg[apIdx], wlWdsCfg, sizeof(LTQ_MAPI_WLAN_WDS_Cfg));
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_wds_config", "ret: %d", ret);
	IFX_MEM_FREE(array_changed_fvp);
	return ret;
}
#endif	/* #if defined (CONFIG_FEATURE_IFX_WIRELESS) */
