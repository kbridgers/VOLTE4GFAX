
#include <stdio.h>
#include <ctype.h>
#include <fcntl.h>
#include <string.h>
#include <syslog.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <sys/sysinfo.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"

#ifdef CONFIG_FEATURE_IPv6
int get_wan_dslite_parameter(char *name, char *retVal7, int size)
{
	uint32 flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT;
	char8 buf[MAX_FILELINE_LEN];
	if (!strcmp(name, "DSLITEREMOTEIPv6")) {
		//strncpy(buf, "wan_dsliteremoteipv6", size);
                snprintf(buf, sizeof(buf), "wan_dsliteremoteipv6"); 
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_IPV6, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, retVal7) != IFX_SUCCESS) {
			strncpy(retVal7, "0", size);
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__);
#endif
			return IFX_FAILURE;
		}
		return 0;
	} else if (!strcmp(name, "DSLITETUNIP")) {
		//strncpy(buf, "wan_dslitetunip", size);
                snprintf(buf, sizeof(buf), "wan_dslitetunip");
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_IPV6, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, retVal7) != IFX_SUCCESS) {
			strncpy(retVal7, "192.0.0.2", size);
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__);
#endif
			return IFX_FAILURE;
		}
		return 0;
	} else if (!strcmp(name, "DSLITEMASK")) {
		//strncpy(buf, "wan_dslitemask", size);
                snprintf(buf, sizeof(buf), "wan_dslitemask");
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_IPV6, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, retVal7) != IFX_SUCCESS) {
			strncpy(retVal7, "255.255.255.248", size);
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__);
#endif
			return IFX_FAILURE;
		}
		return 0;
	} else if (!strcmp(name, "WANDSLITEMODE")) {
		//strncpy(buf, "wan_dslite_mode", size);
                snprintf(buf, sizeof(buf), "wan_dslite_mode");
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_IPV6, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, retVal7) != IFX_SUCCESS) {
			strncpy(retVal7, "0", size);
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__);
#endif
			return IFX_FAILURE;
		}
		return 0;
	} else if (!strcmp(name, "MTU_DSLITE")) {
		snprintf(buf, sizeof(buf), "wan_dslite_mtu");
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_IPV6, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, retVal7) != IFX_SUCCESS) {
			strncpy(retVal7, "", size);
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__);
#endif
			return IFX_FAILURE;
		}
		if (!strcmp(retVal7, "0")) {
			/*ifx_httpdWrite(wp, T("")); */
			strncpy(retVal7, "", size);
		}
		return 0;
	} else if (!strcmp(name, "PORTRANGE")) {
                //strncpy(buf, "wan_portrange", size);
                snprintf(buf, sizeof(buf), "wan_portrange"); 
                if (ifx_GetObjData
                    (FILE_RC_CONF, TAG_IPV6, buf, flags,
                     (IFX_OUT uint32 *) & outFlag, retVal7) != IFX_SUCCESS) {
                        strncpy(retVal7, "", size);
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
                                __FUNCTION__, __LINE__);
#endif
                        return IFX_FAILURE;
                }
                return 0;
        }

	return 0;
}

int address_validation(char *dslite_remoteipv6, char *dslite_tunip,
		       char *dslite_mask)
{
	struct in_addr ipv4_dst_str, netmask_str;
	struct in6_addr ipv6_dst_addr;
	int ret;
	int ret_ipv4, ret_netmask;
	ret_ipv4 = inet_pton(AF_INET, dslite_tunip, &ipv4_dst_str);
	if (ret_ipv4 <= 0) {
		return 11;
	}
	ret_netmask = inet_pton(AF_INET, dslite_mask, &netmask_str);
	if (ret_netmask <= 0) {
		return 12;
	}
	ret = inet_pton(AF_INET6, dslite_remoteipv6, &ipv6_dst_addr);
	if (ret <= 0)
		return 10;
	return 0;
}

int set_dslite_static_parameters(char *dslite_remoteipv6, char *dslite_tunip,
				 char *dslite_mask, uint32 wan_dslitewanidx,
				 uint32 wan_mtu_dslite, char *wan_name, 
				 uint32 wan_dslite_mode, char *wan_type, char *dslite_portrange)
{
	int ret_validation_check = 1, ret_val;
	int32 flags = IFX_F_MODIFY;
	char8 buf[MAX_FILELINE_LEN];
	char8 wan_dsliteremoteipv6[64], wan_dslitetunip[MAX_IP_ADDR_LEN],
	    wan_dslitemask[MAX_FILELINE_LEN], wan_portrange[MAX_FILELINE_LEN];
	if (dslite_remoteipv6 == NULL)
		return 7;
	snprintf(wan_dsliteremoteipv6, sizeof(wan_dsliteremoteipv6),
		 dslite_remoteipv6);
	if (dslite_tunip == NULL) {
		return 8;
	}
	snprintf(wan_dslitetunip, sizeof(wan_dslitetunip), dslite_tunip);
	if (dslite_mask == NULL) {
		return 9;
	}
	snprintf(wan_dslitemask, sizeof(wan_dslitemask), dslite_mask);
	snprintf(wan_portrange, sizeof(wan_portrange), dslite_portrange);
        
	snprintf(buf, sizeof(buf), "wan_dsliteremoteipv6=\"%s\"\n",
		 wan_dsliteremoteipv6);
	if (ifx_SetObjData(FILE_RC_CONF, TAG_IPV6, flags, 1, buf) !=
	    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__,
			__LINE__);
#endif
		return 1;
	}
	snprintf(buf, sizeof(buf), "wan_dslitetunip=\"%s\"\n", wan_dslitetunip);
	if (ifx_SetObjData(FILE_RC_CONF, TAG_IPV6, flags, 1, buf) !=
	    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__,
			__LINE__);
#endif
		return 1;
	}
	snprintf(buf, sizeof(buf), "wan_dslitemask=\"%s\"\n", wan_dslitemask);
	if (ifx_SetObjData(FILE_RC_CONF, TAG_IPV6, flags, 1, buf) !=
	    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__,
			__LINE__);
#endif
		return 1;
	}

        snprintf(buf, sizeof(buf), "wan_portrange=\"%s\"\n", wan_portrange);
        if (ifx_SetObjData(FILE_RC_CONF, TAG_IPV6, flags, 1, buf) !=
            IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__,
                        __LINE__);
#endif
                return 1;
        }

	ret_validation_check =
	    address_validation(dslite_remoteipv6, dslite_tunip, dslite_mask);

	 if (ret_validation_check != 0) {
		if(ret_validation_check == 10 && (wan_dslite_mode == 1 || wan_dslite_mode == 3)) {
			IFX_DBG ( "[%s:%d] Validation of AFTR not required in dynamic mode",
                                   __FUNCTION__, __LINE__);
		} else {
			return ret_validation_check;
		}
	}

	switch(wan_dslite_mode) {
	case 0: 	/* static configuration */
		if (wan_mtu_dslite == 0) {
			snprintf(buf, sizeof(buf),
				 "/etc/rc.d/ds-lite.sh -o start -i %s -r %s -a %s -p %s",
				 wan_name, wan_dsliteremoteipv6,
				 wan_dslitetunip, wan_dslitemask);
			ret_val = system(buf);
			if (ret_val != 0)
				return ret_val;
		} else {
			snprintf(buf, sizeof(buf),
				 "/etc/rc.d/ds-lite.sh -o start -i %s -r %s -a %s -p %s -m %d",
				 wan_name, wan_dsliteremoteipv6,
				 wan_dslitetunip, wan_dslitemask, wan_mtu_dslite);
			ret_val = system(buf);
			if (ret_val != 0)
				return ret_val;
		}
		break;
	case 1: 	/* Dynamic Ds-lite configuration */
	/*	snprintf(buf, sizeof(buf),
				"/etc/rc.d/ds-lite.sh dhcp6c_restart %s %d %s",
				wan_name, wan_dslitewanidx, wan_type); 
		system(buf); */
		break;
        case 2:         /* Stateless static configuration */
                if (wan_mtu_dslite == 0) {
                        snprintf(buf, sizeof(buf),
                                 "/etc/rc.d/ds-lite.sh -o start -i %s -r %s -a %s -p %s",
                                 wan_name, wan_dsliteremoteipv6,
                                 wan_dslitetunip, wan_dslitemask);
                        ret_val = system(buf);
                        if (ret_val != 0)
                                return ret_val;
                      //  snprintf(buf, sizeof(buf),
                        //         "/etc/rc.d/stateless_dslite.sh");
                       // system(buf);                       
                } else {
                        snprintf(buf, sizeof(buf),
                                 "/etc/rc.d/ds-lite.sh -o start -i %s -r %s -a %s -p %s -m %d",
                                 wan_name, wan_dsliteremoteipv6,
                                 wan_dslitetunip, wan_dslitemask, wan_mtu_dslite);
                        ret_val = system(buf);
                        if (ret_val != 0)
                                return ret_val;
                       // snprintf(buf, sizeof(buf),
                         //        "/etc/rc.d/stateless_dslite.sh");
                       // system(buf);
                }
                break;
          case 3:
                    //    snprintf(buf, sizeof(buf),
                      //           "/etc/rc.d/stateless_dslite.sh %s", wan_portrange);
                      //  system(buf);
                break;    
	}

	return 0;
}

int delete_dslite_tunnel(uint32 wan_dslitewanidx, char * wan_name, int wantype)
{
	int ret_value_delete = 1;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	int32 flags = IFX_F_MODIFY, outFlag = IFX_SUCCESS;
	char *wt[2] = {"ppp", "ip"};
	char *wantag = (wantype?TAG_WAN_IP:TAG_WAN_PPP);
	sValue[0] = '\0';
	
	syslog(0, "%s is called with args %d %s %d\n",__func__, wan_dslitewanidx, wan_name, wantype);
	snprintf(buf, sizeof(buf), "wan%s_%d_tunnel", wt[wantype], wan_dslitewanidx);
	if (ifx_GetObjData
	    (FILE_RC_CONF, wantag, buf, flags,
	     (IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__,
			__LINE__);
#endif
		return 1;
	}
	
	syslog(0, "%s wantunnel=%s\n",__func__, sValue);
	if ((!strcmp(sValue, "2")) || (!strcmp(sValue, "3"))) {
		if (!strcmp(sValue, "2"))
			snprintf(buf, sizeof(buf), "wan%s_%d_tunnel=\"0\"\n",
				 wt[wantype], wan_dslitewanidx);
		else if (!strcmp(sValue, "3"))
			snprintf(buf, sizeof(buf), "wan%s_%d_tunnel=\"1\"\n",
				 wt[wantype], wan_dslitewanidx);
		syslog(0, "%s buf=%s\n",__func__, buf);
		if (ifx_SetObjData(FILE_RC_CONF, wantag, flags, 1, buf) !=
		    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__);
#endif
			return 1;
		}
	}
	sValue[0] = '\0';
	strncpy(buf, "wan_dslitewanidx", sizeof(buf));
	if (ifx_GetObjData
	    (FILE_RC_CONF, TAG_IPV6, buf, flags, (IFX_OUT uint32 *) & outFlag,
	     sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__,
			__LINE__);
#endif
		return 1;
	}
	syslog(0, "%s wan_dslitewanidx=%s\n",__func__, sValue);
	if (!strcmp(sValue, wan_name)) {
		strncpy(buf, "wan_dslitewanidx=\"0\"\n", sizeof(buf));
		if (ifx_SetObjData(FILE_RC_CONF, TAG_IPV6, flags, 1, buf) !=
		    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__);
#endif
			return 1;
		}
		snprintf(buf, sizeof(buf), "/etc/rc.d/ds-lite.sh -o stop -i %s",
			 wan_name);
		ret_value_delete = system(buf);
		if (ret_value_delete != 0)
			return ret_value_delete;
		snprintf(buf, sizeof(buf), "wan_dslite_mtu=\"0\"\n");
		if (ifx_SetObjData(FILE_RC_CONF, TAG_IPV6, flags, 1, buf) !=
		    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__);
#endif
			return 1;
		}
	}
	return 0;
}

int set_dslite_parameters(uint32 wan_dslitewanidx, char *pCheck_dslite,
			  char *dslitemode, char *dslite_remoteipv6,
			  char *dslite_tunip, char *dslite_mask,
			  char *wandslite_mtu, int wantype,
			  char *wan_name, char *dslite_portrange)
{
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	int ret_set_static_parametes = 1, ret_val_delete = 1;
	int32 outFlag = IFX_SUCCESS;
	int32 flags = IFX_F_MODIFY, wanMode = 0, phy_mode = 0;
	uint32 wan_dslite = 0, prev_wan_dslitewanidx = 0, wan_dslite_mode =
	    0, pwan_ipv6_status = 0, dslite_tunnel_value = 0;
	uint32 wan_mtu_dslite = 0;
	int prev_wantype;
	char *wt[2]= {"ppp", "ip"};
	char *wantag = (wantype?TAG_WAN_IP:TAG_WAN_PPP);
	char wan_basename[16]={0};
	sValue[0] = '\0';
	if(wantype != 0 && wantype != 1) {
		return 1;
	}
	
	if (wan_dslitewanidx != -1) {
		snprintf(buf, sizeof(buf), "wan%s_%d_wanMode", wt[wantype], wan_dslitewanidx);
		if (ifx_GetObjData(FILE_RC_CONF, wantag, buf, flags, 
				(IFX_OUT uint32 *)&outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__);
#endif
			return 1;
		}
		if (sValue[0] == '\0')
			return 2;
		wanMode = atoi(sValue);
		sValue[0] = '\0';
		strncpy(buf, "wanphy_phymode", sizeof(buf));
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_WAN_PHY_CFG, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__);
#endif
			return 1;
		}
		if (sValue[0] == '\0')
			return 3;
		phy_mode = atoi(sValue);
		if ((wanMode == WAN_MODE_ETH0
		     && phy_mode != WAN_PHY_MODE_ETH_MII0)
		    || (wanMode == WAN_MODE_ETH1
			&& phy_mode != WAN_PHY_MODE_ETH_MII1)
		    || ((wanMode == WAN_MODE_ATM || wanMode == WAN_MODE_PTM)
			&& phy_mode != WAN_PHY_MODE_ADSL2)
		    || (wanMode == WAN_MODE_VDSL_PTM
			&& phy_mode != WAN_PHY_MODE_VDSL2)) {

			return 4;
		}
		sValue[0] = '\0';
		snprintf(buf, sizeof(buf), "wan%s_%d_ipv6", 
				wt[wantype], wan_dslitewanidx);
		if (ifx_GetObjData(FILE_RC_CONF, wantag, buf, 
				flags, (IFX_OUT uint32 *)&outFlag, 
				sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__);
#endif
			return 1;
		}
		pwan_ipv6_status = atoi(sValue);
		if (pwan_ipv6_status != 2) {
			return 5;
		}
		if (pCheck_dslite == NULL) {
			return 1;
		}
		wan_dslite = atoi(pCheck_dslite);
		if (wan_dslite == 1) {
			sValue[0] = '\0';
			strncpy(buf, "wan_dslitewanidx", sizeof(buf));
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_IPV6, buf, flags,
			     (IFX_OUT uint32 *) & outFlag,
			     sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
					__FUNCTION__, __LINE__);
#endif
				return 1;
			}
			if(strstr(sValue, "PPP")) {
				prev_wantype = 0;
				prev_wan_dslitewanidx = atoi(&sValue[6]);
			} else if (strstr(sValue, "IP")) {
				prev_wantype = 1;
				prev_wan_dslitewanidx = atoi(&sValue[5]);
			}else 
				prev_wantype = -1;
			strncpy(wan_basename, sValue, sizeof(wan_basename));
				
			/* prev_wan_dslitewanidx=atoi(sValue); */
			if(prev_wantype != -1) {
				sValue[0] = '\0';
				snprintf(buf, sizeof(buf), "wan%s_%d_tunnel",
					 wt[prev_wantype], prev_wan_dslitewanidx);
				if (ifx_GetObjData
				    (FILE_RC_CONF, wantag, buf, flags,
				     (IFX_OUT uint32 *) & outFlag,
				     sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] Form Name=Value buffer Fail",
					     __FUNCTION__, __LINE__);
#endif
				}
				if ((!strcmp(sValue, "2"))
				    || (!strcmp(sValue, "3"))) {
					snprintf(buf, sizeof(buf),
						 "/etc/rc.d/ds-lite.sh -o stop -i %s",
						 wan_basename);
					system(buf);
					if (!strcmp(sValue, "2"))
						snprintf(buf, sizeof(buf),
							 "wan%s_%d_tunnel=\"0\"\n",
							 wt[wantype], prev_wan_dslitewanidx);
					else if (!strcmp(sValue, "3"))
						snprintf(buf, sizeof(buf),
							 "wan%s_%d_tunnel=\"1\"\n",
							 wt[wantype], prev_wan_dslitewanidx);
					if (ifx_SetObjData
					    (FILE_RC_CONF, wantag, flags,
					     1, buf) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
						IFX_DBG
						    ("[%s:%d] Form Name=Value buffer Fail",
						     __FUNCTION__, __LINE__);
#endif
						return 1;
					}
				}
			}
			snprintf(buf, sizeof(buf), "wan_dslitewanidx=\"%s\"\n",
				 wan_name);
			if (ifx_SetObjData
			    (FILE_RC_CONF, TAG_IPV6, flags, 1,
			     buf) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
					__FUNCTION__, __LINE__);
#endif
				return 1;
			}
			if (dslitemode == NULL) {
				return 6;
			}
			wan_dslite_mode = atoi(dslitemode);
			snprintf(buf, sizeof(buf), "wan_dslite_mode=\"%d\"\n",
				 wan_dslite_mode);
			if (ifx_SetObjData
			    (FILE_RC_CONF, TAG_IPV6, flags, 1,
			     buf) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
					__FUNCTION__, __LINE__);
#endif
				return 1;
			}
			if (!strcmp(wandslite_mtu, ""))
				wan_mtu_dslite = 0;
			else
				wan_mtu_dslite = atoi(wandslite_mtu);
			snprintf(buf, sizeof(buf), "wan_dslite_mtu=\"%d\"\n",
				 wan_mtu_dslite);
			if (ifx_SetObjData
			    (FILE_RC_CONF, TAG_IPV6, flags, 1,
			     buf) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
					__FUNCTION__, __LINE__);
#endif
				return 1;
			}
			sValue[0] = '\0';
			snprintf(buf, sizeof(buf), "wan%s_%d_tunnel",
				 wt[wantype], wan_dslitewanidx);
			if (ifx_GetObjData
			    (FILE_RC_CONF, wantag, buf, flags,
			     (IFX_OUT uint32 *) & outFlag,
			     sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
					__FUNCTION__, __LINE__);
#endif
				return 1;
			}
			if (!strcmp(sValue, "0"))
				dslite_tunnel_value = 2;
			else if (!strcmp(sValue, "1"))
				dslite_tunnel_value = 3;
			else if (!strcmp(sValue, "2"))
				dslite_tunnel_value = 2;
			else if (!strcmp(sValue, "3"))
				dslite_tunnel_value = 3;
			snprintf(buf, sizeof(buf), "wan%s_%d_tunnel=\"%d\"\n",
				 wt[wantype], wan_dslitewanidx, dslite_tunnel_value);
			syslog(0, "setting wan%s_%d_tunnel=\"%d\"\n", wt[wantype], wan_dslitewanidx, dslite_tunnel_value);
			if (ifx_SetObjData
			    (FILE_RC_CONF, wantag, flags, 1,
			     buf) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
					__FUNCTION__, __LINE__);
#endif
				return 1;
			}
			/* if (wan_dslite_mode == 0) */ {
				ret_set_static_parametes =
				    set_dslite_static_parameters((char *)
								 dslite_remoteipv6,
								 (char *)
								 dslite_tunip,
								 (char *)
								 dslite_mask,
								 wan_dslitewanidx,
								 wan_mtu_dslite,wan_name, wan_dslite_mode,
								 wt[wantype],
                                                                 (char *)
                                                                 dslite_portrange);
				if (ret_set_static_parametes != 0) {
					if(ret_set_static_parametes == 10 && (wan_dslite_mode == 1 || wan_dslite_mode == 3)) {
						IFX_DBG (
						"[%s:%d] Validation of AFTR not required in dynamic mode",
                                             	__FUNCTION__, __LINE__);
					} else {
						return ret_set_static_parametes;
					}
				}

			}
		} else {
			ret_val_delete = delete_dslite_tunnel(wan_dslitewanidx, wan_name, wantype);
			if (ret_val_delete != 0)
				return ret_val_delete;

			snprintf(buf, sizeof(buf), "wan%s_%d_tunnel",
				 wt[wantype], wan_dslitewanidx);
			if (ifx_GetObjData
				    (FILE_RC_CONF, wantag, buf, flags,
				     (IFX_OUT uint32 *) & outFlag,
				     sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] Form Name=Value buffer Fail",
					     __FUNCTION__, __LINE__);
#endif
				}
				if ((!strcmp(sValue, "2"))
				    || (!strcmp(sValue, "3"))) {
					if (!strcmp(sValue, "2"))
						snprintf(buf, sizeof(buf),
							 "wan%s_%d_tunnel=\"0\"\n",
							 wt[wantype], wan_dslitewanidx);
					else if (!strcmp(sValue, "3"))
						snprintf(buf, sizeof(buf),
							 "wan%s_%d_tunnel=\"1\"\n",
							 wt[wantype], wan_dslitewanidx);
					if (ifx_SetObjData
					    (FILE_RC_CONF, wantag, flags,
					     1, buf) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
						IFX_DBG
						    ("[%s:%d] Form Name=Value buffer Fail",
						     __FUNCTION__, __LINE__);
#endif
						return 1;
					}
				}

		}
	}
	return 0;
}

int get_wan_dslite_allstatus(char *name, char *retVal6, char *retVal8,
			     char *retVal12, char *retVal9, int size,
			     int nWAN_IDX, char *wantype, char *wantag,
			     char *wan_basename)
{
	uint32 flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT;
	int32 wanMode = 0, phy_mode = 0;
	char8 buf[MAX_FILELINE_LEN];
	char8 sValue[MAX_FILELINE_LEN];
	FILE *fp;
	sValue[0] = '\0';
	{
		if (!strcmp(name, "ALLSTATUS")) {
			snprintf(buf, sizeof(buf), "wan%s_%d_tunnel", wantype, nWAN_IDX);
			if (ifx_GetObjData
			    (FILE_RC_CONF, wantag, buf, flags,
			     (IFX_OUT uint32 *) & outFlag,
			     sValue) != IFX_SUCCESS) {
				strncpy(retVal6, "", size);
				strncpy(retVal8, "", size);
				strncpy(retVal12, "", size);
				strncpy(retVal9, "", size);
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
					__FUNCTION__, __LINE__);
				IFX_DBG("[%s:%d] wan%s_%d_tunnel, wantag=%s\n",
					__FUNCTION__, __LINE__,wantype, nWAN_IDX, wantag);
#endif
				return IFX_FAILURE;
			}
			if ((!strcmp(sValue, "2")) || (!strcmp(sValue, "3"))) {
				snprintf(buf, sizeof(buf), "wan%s_%d_wanMode",
					 wantype, nWAN_IDX);
				if (ifx_GetObjData
				    (FILE_RC_CONF, wantag, buf, flags,
				     (IFX_OUT uint32 *) & outFlag,
				     sValue) != IFX_SUCCESS) {
					strncpy(retVal6, "", size);
					strncpy(retVal8, "", size);
					strncpy(retVal12, "", size);
					strncpy(retVal9, "", size);
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] Form Name=Value buffer Fail",
					     __FUNCTION__, __LINE__);
#endif
					return -1;
				}
				if (sValue[0] == '\0') {
					strncpy(retVal6, "", size);
					strncpy(retVal8, "", size);
					strncpy(retVal12, "", size);
					strncpy(retVal9, "", size);
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] Form Name=Value buffer Fail",
					     __FUNCTION__, __LINE__);
#endif
					return -1;
				}
				wanMode = atoi(sValue);
				sValue[0] = '\0';
				strncpy(buf, "wanphy_phymode", sizeof(buf));
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_WAN_PHY_CFG, buf, flags,
				     (IFX_OUT uint32 *) & outFlag,
				     sValue) != IFX_SUCCESS) {
					strncpy(retVal6, "", size);
					strncpy(retVal8, "", size);
					strncpy(retVal12, "", size);
					strncpy(retVal9, "", size);
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] Form Name=Value buffer Fail",
					     __FUNCTION__, __LINE__);
#endif
					return -1;
				}
				if (sValue[0] == '\0') {
					strncpy(retVal6, "", size);
					strncpy(retVal8, "", size);
					strncpy(retVal12, "", size);
					strncpy(retVal9, "", size);
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] Form Name=Value buffer Fail",
					     __FUNCTION__, __LINE__);
#endif
					return -1;
				}
				phy_mode = atoi(sValue);
				if ((wanMode == WAN_MODE_ETH0
				     && phy_mode != WAN_PHY_MODE_ETH_MII0)
				    || (wanMode == WAN_MODE_ETH1
					&& phy_mode != WAN_PHY_MODE_ETH_MII1)
				    ||
				    ((wanMode == WAN_MODE_ATM
				      || wanMode == WAN_MODE_PTM)
				     && phy_mode != WAN_PHY_MODE_ADSL2)
				    || (wanMode == WAN_MODE_VDSL_PTM
					&& phy_mode != WAN_PHY_MODE_VDSL2)) {

					strncpy(retVal6, "Not_Connected", size);
					strncpy(retVal8, "Undefined", size);
					strncpy(retVal12, "Undefined", size);
					strncpy(retVal9, "Undefined", size);
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] Form Name=Value buffer Fail",
					     __FUNCTION__, __LINE__);
#endif
					return -1;
				}
				snprintf(buf, sizeof(buf),
					 "/tmp/dslite_tun%s_status", wan_basename);
				fp = fopen((const char *)buf, "r");
				if (fp == NULL) {
					strncpy(retVal6, "Not_Connected", size);
					strncpy(retVal8, "Undefined", size);
					strncpy(retVal12, "Undefined", size);
					strncpy(retVal9, "Undefined", size);
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] failed ro read the dslite status file from /tmp/",
					     __FUNCTION__, __LINE__);
#endif
					return -1;
				} else {
					if (fscanf
					    (fp, "%[^ ] %[^ ] %[^ ] %[^\n]\n", retVal6,
					     retVal8, retVal12, retVal9) < 4) {
						strncpy(retVal6,
							"Not_Connected", size);
						strncpy(retVal8, "Undefined",
							size);
						strncpy(retVal12, "Undefined",
							size);
						strncpy(retVal9, "Undefined",
							size);
#ifdef IFX_LOG_DEBUG
						IFX_DBG
						    ("[%s:%d] failed ro read the file",
						     __FUNCTION__, __LINE__);
#endif
						return -1;
					}
					return 0;
				}
				fclose(fp);
			} else {
				strncpy(retVal6, "", size);
				strncpy(retVal8, "", size);
				strncpy(retVal12, "", size);
				strncpy(retVal9, "", size);
				return -1;
			}
		}
	}
	return 0;
}
#endif
