#if defined (CONFIG_FEATURE_IFX_WIRELESS) && (defined (CONFIG_FEATURE_LTQ_WIRELESS_VB) || defined (CONFIG_FEATURE_LTQ_WIRELESS_STA_SUPPORT))
/* ========================================================================== */
/*                                 Includes                                   */
/* ========================================================================== */
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <sys/sysinfo.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"

/* included for definition of bool */
//#include "ifx_api_ipt_common.h"
/* ========================================================================== */
/*                             Macro definitions                              */
/* ========================================================================== */
#include <sys/time.h>

#define WLAN_GEN_VB_PARAM_COUNT             6
#define WLAN_VB_LAN_PARAM_COUNT             4
#define VB_ETH_PHY_PARAM_COUNT             	8
#define WLAN_VB_WLAN_PARAM_COUNT            19
#define WLAN_VB_WLAN_PROFILE_COUNT          17
#define WLAN_VB_WLAN_SCAN_COUNT           	1
#define WLAN_VB_WMM_PARAM_COUNT				20
/* ========================================================================== */
/*                             Type definitions                               */
/* ========================================================================== */

/* ========================================================================== */
/*                             Global variables                               */
/* ========================================================================== */
char8 *wlan_vb_gbd_params[] =
    { "gbc_name", "gbc_mode", "gbc_mgmtIP", "gbc_mgmtNetMask",
	"gbc_dhcpClntEna", "gbc_wlanMgmt"
};

char8 *wlan_vb_lbd_params[] = { "lbc_masterNetMode", "lbc_endPtNetMode",
	"lbc_endPtLBEna", "lbc_endPtClonedMAC"
};

char8 *vb_eth_phy_params[] = { "cpeId", "ena", "flowCntrl", "duplxMode",
	"speed", "ifName", "pVID", "swPort"
};

char8 *wlan_vb_wlan_params[] = {
	"wlstacfg_radioEna", "wlstacfg_standard", "wlstacfg_country",
	"wlstacfg_freqBand", "wlstacfg_ctsProtctMode", "wlstacfg_rtsThrsld",
	"wlstacfg_powerLvl", "wlstacfg_txRate", "wlstacfg_nChanWidth",
	"wlstacfg_nGuardIntvl", "wlstacfg_preamble", "wlstacfg_nSTBCrx",
	"wlstacfg_wpsEna", "wlstacfg_wmmEna", "wlstacfg_nLDPCen",
	"wlstacfg_beamFrmType", "wlstacfg_boostMode", "nCoexScanExemptReq",
	"nObssScanInt"
};

char8 *wlan_vb_wlan_profile[] =
    { "wlprof_ssid", "wlprof_bssid", "wlprof_beaconType", "wlprof_authType",
    "wlprof_encrType", "wlprof_actWepKey", "wlprof_wepKeyType",
    "wlprof_wepEncrLvl", "wlprof_wepKey0", "wlprof_wepKey1", "wlprof_wepKey2",
	"wlprof_wepKey3", "wlprof_passPhrase", "wlprof_userName", "wlprof_freqBand",
	"wlprof_nChanWidth", "wlprof_standard"
};

char8 *wlan_vb_wlan_scan[] = { "wlscan_ssidWildcard" };

char8 *wlan_vb_wmm_params[] = { "wlsstawmm_0_ECWmin", "wlsstawmm_0_ECWmax",
	"wlsstawmm_0_AIFSN", "wlsstawmm_0_TXOP", "wlsstawmm_0_AckPolicy",
	"wlsstawmm_1_ECWmin", "wlsstawmm_1_ECWmax",
	"wlsstawmm_1_AIFSN", "wlsstawmm_1_TXOP", "wlsstawmm_1_AckPolicy",
	"wlsstawmm_2_ECWmin", "wlsstawmm_2_ECWmax",
	"wlsstawmm_2_AIFSN", "wlsstawmm_2_TXOP", "wlsstawmm_2_AckPolicy",
	"wlsstawmm_3_ECWmin", "wlsstawmm_3_ECWmax",
	"wlsstawmm_3_AIFSN", "wlsstawmm_3_TXOP", "wlsstawmm_3_AckPolicy"
};

/* ========================================================================== */
/*                           Function prototypes                              */
/* ========================================================================== */

/* ========================================================================== */
/*                         Function implementation                            */
/* ========================================================================== */

/**
   \param   wlVbGenCfg - pointer to LTQ_MAPI_WLAN_VB_GEN_Cfg structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ltq_mapi_get_vb_gbd_config(LTQ_MAPI_WLAN_VB_GEN_BD_Cfg * wlVbGenCfg,
			   uint32 flags)
{
	int32    			ret = IFX_SUCCESS, count = 0, i;
	char8   			buf[MAX_DATA_LEN], *sValue = NULL;
	char8				sValue2[MAX_FILELINE_LEN], sCommand[MAX_FILELINE_LEN];
	IFX_NAME_VALUE_PAIR	array_fvp[WLAN_GEN_VB_PARAM_COUNT];
	uint32				outFlag = IFX_F_DEFAULT;
	IFX_MAPI_WLAN_DevType	devType = IFX_MAPI_WLAN_DEV_TYPE_STA;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_gbd_config", "");

	/* get gen_vb object from rc.conf */
	sprintf(buf, "%s_", PREFIX_WLAN_GEN_VB);
	if((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_GEN_VB, buf, IFX_F_DEFAULT,
		&sValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_gbd_config", "buf: %s", buf);
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_gbd_config", "buf: %s, sValue: %s",
		buf, sValue);

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_gbd_config", "count: %d", count);
	for (i = 0; i < count; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_gbd_config", "%s:%s",
			array_fvp[i].fieldname, array_fvp[i].value);

	sprintf(wlVbGenCfg->name, "%s",  array_fvp[0].value);
	wlVbGenCfg->mode		= atoi(array_fvp[1].value);
	if (wlVbGenCfg->mode == LTQ_MAPI_WLAN_VB_AUTO) {
		/*
			gbc_mode is still set to auto, therefore we get the AP type
			from wlmn_0_apType parameter
		*/
		sprintf(buf, "wlmn_0_apType");
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAIN,
			buf, IFX_F_GET_ANY, &outFlag, sValue2)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_gbd_config", "");
			goto LTQ_Handler;
		}
		devType = atoi(sValue2);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_gbd_config",
			"devType: %d", devType);
		switch (devType) {
			case IFX_MAPI_WLAN_DEV_TYPE_AP:
				wlVbGenCfg->currentMode = LTQ_MAPI_WLAN_VB_AP;
				break;
			case IFX_MAPI_WLAN_DEV_TYPE_STA:
				wlVbGenCfg->currentMode = LTQ_MAPI_WLAN_VB_STA;
				break;
			default:
				wlVbGenCfg->currentMode = LTQ_MAPI_WLAN_VB_AUTO;
				IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_gbd_config", "");
				break;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_gbd_config",
			"currentMode: %d", wlVbGenCfg->currentMode);
	} else {
		wlVbGenCfg->currentMode = wlVbGenCfg->mode;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_gbd_config",
		"mode: %d, currentMode: %d", wlVbGenCfg->mode, wlVbGenCfg->currentMode);

	wlVbGenCfg->dhcpClntEna = atoi(array_fvp[4].value);

	if (wlVbGenCfg->dhcpClntEna) {
		/* get the ip address for this lan device entry */
		sprintf(sCommand, "Lan0_IF_Info");
		if (ifx_GetObjData(FILE_SYSTEM_STATUS, sCommand, "IP",
				   IFX_F_DEFAULT, &outFlag,
				   sValue2) != IFX_SUCCESS) {
			sprintf(sValue2, "%s", ("0.0.0.0"));
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_gbd_config",
			       "sValue: %s", sValue2);
		if (!(inet_aton(sValue2, &wlVbGenCfg->mgmtIP))) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_gbd_config",
				       "inet_aton error");
			goto LTQ_Handler;
		}

		/* get the ip mask for this lan device entry */
		sprintf(sCommand, "Lan0_IF_Info");
		if (ifx_GetObjData(FILE_SYSTEM_STATUS, sCommand, "MASK",
				   IFX_F_DEFAULT, &outFlag,
				   sValue2) != IFX_SUCCESS) {
			sprintf(sValue2, "%s", ("0.0.0.0"));
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_gbd_config",
			       "sValue: %s", sValue2);
		if (!(inet_aton(sValue2, &wlVbGenCfg->mgmtNetMask))) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_gbd_config",
				       "inet_aton error");
			goto LTQ_Handler;
		}
	} else {
		if (!(inet_aton(array_fvp[2].value, &wlVbGenCfg->mgmtIP))) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_gbd_config",
				       "inet_aton error");
			goto LTQ_Handler;
		}
		if (!(inet_aton(array_fvp[3].value, &wlVbGenCfg->mgmtNetMask))) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_gbd_config",
				       "inet_aton error");
			goto LTQ_Handler;
		}
	}

	wlVbGenCfg->wlanMgmt = atoi(array_fvp[5].value);

      LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_gbd_config", "ret: %d", ret);
	/* free buffer allocated in ifx_GetCfgObject */
	IFX_MEM_FREE(sValue);
	return ret;
}

/**
   \param   wlVbGenCfg - pointer to LTQ_MAPI_WLAN_VB_GEN_Cfg structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ltq_mapi_get_vb_wlan_config(LTQ_MAPI_VB_WLAN_Cfg * wlVbWlanCfg, uint32 flags)
{
	int32 ret = IFX_SUCCESS, count = 0, i;
	char8 buf[MAX_DATA_LEN], *sValue = NULL;
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_VB_WLAN_PARAM_COUNT + 1];
	struct timeval tv;

	gettimeofday(&tv, NULL);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_config", "%d:%d",
		       (int32) tv.tv_sec, (int32) tv.tv_usec);

	/* get wlan_sta_cfg object from rc.conf */
	sprintf(buf, "%s_", PREFIX_VB_WLAN_CFG);
	if ((ret =
	     ifx_GetCfgObject(FILE_RC_CONF, TAG_VB_WLAN_CFG, buf, IFX_F_DEFAULT,
			      &sValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_config",
			       "buf: %s", buf);
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_config",
		       "buf: %s, sValue: %s", buf, sValue);

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_config", "count: %d",
		       count);
	for (i = 0; i < count; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_config", "%s:%s",
			       array_fvp[i].fieldname, array_fvp[i].value);

	wlVbWlanCfg->radioEna = atoi(array_fvp[0].value);
	wlVbWlanCfg->standard = atoi(array_fvp[1].value);
	sprintf(wlVbWlanCfg->country, "%s", array_fvp[2].value);
	wlVbWlanCfg->freqBand = atoi(array_fvp[3].value);
	wlVbWlanCfg->ctsProtctMode = atoi(array_fvp[4].value);
	wlVbWlanCfg->rts = atoi(array_fvp[5].value);
	wlVbWlanCfg->powerLvl = atoi(array_fvp[6].value);
	wlVbWlanCfg->txRate = atoi(array_fvp[7].value);
	wlVbWlanCfg->nChanWidth = atoi(array_fvp[8].value);
	wlVbWlanCfg->nGuardIntvl = atoi(array_fvp[9].value);
	wlVbWlanCfg->preamble = atoi(array_fvp[10].value);
	wlVbWlanCfg->nSTBCrx = atoi(array_fvp[11].value);
	wlVbWlanCfg->wpsEna = atoi(array_fvp[12].value);
	wlVbWlanCfg->wmmEna = atoi(array_fvp[13].value);
	wlVbWlanCfg->ldpcEna = atoi(array_fvp[14].value);
	wlVbWlanCfg->beamForm = atoi(array_fvp[15].value);
	wlVbWlanCfg->boostMode = atoi(array_fvp[16].value);

      LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_config", "ret: %d", ret);
	/* free buffer allocated in ifx_GetCfgObject */
	IFX_MEM_FREE(sValue);
	gettimeofday(&tv, NULL);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_config", "%d:%d",
		       (int32) tv.tv_sec, (int32) tv.tv_usec);
	return ret;
}

/**
   \param   wlVbGenCfg - pointer to LTQ_MAPI_WLAN_VB_GEN_Cfg structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ltq_mapi_get_wlan_vb_lan_config(LTQ_MAPI_WLAN_VB_LAN_BD_Cfg * wlVbLanCfg,
				uint32 flags)
{
	int32 ret = IFX_SUCCESS, count = 0;
	char8 buf[MAX_DATA_LEN], *sValue = NULL;
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_VB_LAN_PARAM_COUNT + 1];
	struct timeval tv;

	gettimeofday(&tv, NULL);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_vb_lan_config", "%d:%d",
		       (int32) tv.tv_sec, (int32) tv.tv_usec);

	/* get lan_bd_cfg object from rc.conf */
	sprintf(buf, "%s_", PREFIX_WLAN_VB_LAN);
	if ((ret =
	     ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_VB_LAN, buf, IFX_F_DEFAULT,
			      &sValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_vb_lan_config",
			       "buf: %s", buf);
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_vb_lan_config",
		       "buf: %s, sValue: %s", buf, sValue);

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);

	wlVbLanCfg->masterNetMode = atoi(array_fvp[0].value);
	wlVbLanCfg->endPtNetMode = atoi(array_fvp[1].value);
	wlVbLanCfg->endPtLbEna = atoi(array_fvp[2].value);
	sprintf(wlVbLanCfg->endPtClonedMacAddr, "%s", array_fvp[3].value);

      LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_vb_lan_config", "ret: %d",
		       ret);
	/* free buffer allocated in ifx_GetCfgObject */
	IFX_MEM_FREE(sValue);
	gettimeofday(&tv, NULL);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_vb_lan_config", "%d:%d",
		       (int32) tv.tv_sec, (int32) tv.tv_usec);
	return ret;
}

/*//////////////////////////////////////////////////////////////////////////////
* ltq_mapi_get_vb_mode(...)
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads the vb mode from gen_vb section
                                      			in rc.conf and returns the enumeration for the mode read.
*/// ///////////////////////////////////////////////////////////////////////////
int32 ltq_mapi_get_vb_mode(uint32 flags)
{
	LTQ_MAPI_WLAN_VB_GEN_BD_Cfg wlVbGenCfg;
	int32 ret = IFX_SUCCESS;
	IFX_MAPI_WLAN_DevType	apType;
	char8	buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	uint32	outFlag = IFX_F_DEFAULT;

	ret = ltq_mapi_get_vb_gbd_config(&wlVbGenCfg, flags);
	if (ret != IFX_FAILURE) {
		if (wlVbGenCfg.mode == LTQ_MAPI_WLAN_VB_AUTO) {
			/*
				gbc_mode is still set to auto, therefore we get the AP type
				from wlmn_0_apType parameter
			*/
			sprintf(buf, "wlmn_0_apType");
			if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAIN,
				buf, IFX_F_GET_ANY, &outFlag, sValue)) != IFX_SUCCESS) {
				IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_mode", "");
				return IFX_FAILURE;
	         }
			apType = atoi(sValue);
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_mode",
				"apType: %d", apType);
			if (apType == IFX_MAPI_WLAN_DEV_TYPE_STA)
				return LTQ_MAPI_WLAN_VB_STA;
			else
				return LTQ_MAPI_WLAN_VB_AP;
		} else {
			return wlVbGenCfg.mode;
		}
	} else
		return IFX_FAILURE;
}

int32 ltq_vb_get_param_from_file(const char8 * param, char8 * result)
{
	int32 ret = IFX_SUCCESS, len = 0;
	char8 *pTmpStr = NULL, *pTmpStr2 = NULL, line[MAX_FILELINE_LEN];
	FILE *fp = NULL;

	result[0] = '\0';
	len = strlen(param);
	if ((fp = fopen("/tmp/scan_res1", "r"))) {
		while ((fgets(line, MAX_FILELINE_LEN, fp) != NULL)) {
			if (!(strncmp(line, param, len))) {
				IFX_MAPI_DEBUG(fd,
					       "/tmp/ltq_vb_get_param_from_file",
					       "%s: %s", param, line);
				if ((pTmpStr = strstr(line, "\"\"")) != NULL) {
					IFX_MAPI_DEBUG(fd,
						       "/tmp/ltq_vb_get_param_from_file",
						       "%s: %s", param, line);
					result[0] = '\0';
					goto LTQ_Handler;
				}
				if ((pTmpStr = strstr(line, param)) != NULL) {
					pTmpStr2 = strtok(pTmpStr, "\"");
					if (pTmpStr2 == NULL) {
						ret = IFX_FAILURE;
						goto LTQ_Handler;
					}
					pTmpStr2 = strtok(NULL, "\"");
					if (pTmpStr2 == NULL) {
						ret = IFX_FAILURE;
						goto LTQ_Handler;
					}
					strcpy(result, pTmpStr2);
					IFX_MAPI_DEBUG(fd,
						       "/tmp/ltq_vb_get_param_from_file",
						       "%s: %s", param, result);
				}
			}
		}
	} else {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_vb_get_param_from_file",
			       "scan result file could not be opened");
		ret = IFX_FAILURE;
		return ret;
	}

      LTQ_Handler:
	fclose(fp);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_vb_get_param_from_file", "ret=%d", ret);
	return ret;
}

/**
   \param   numEntries  -

   \param   wlVbScanRes - pointer to LTQ_MAPI_VB_WLAN_Scan config structure

   \param   fDisconnectAp - flag to indicate if STA disconcets from AP before scanning

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ltq_mapi_get_wlan_scan(uint32 * numEntries,
		       LTQ_MAPI_VB_WLAN_Scan ** wlVbScanRes,
		       uint32 fDisconnectAp)
{
	int32 ret = IFX_SUCCESS, i = 0;
	uint32 nVbWlScanRes = 0;
	char8 buf[MAX_FILELINE_LEN];
	char8 sParam[MAX_FILELINE_LEN], sParamValue[MAX_FILELINE_LEN];

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_scan", "fDisconnectAp: %d",
		       fDisconnectAp);

	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	sprintf(buf, "%s %d", SERVICE_VB_GET_WLAN_SCAN, fDisconnectAp);
	system(buf);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_scan", "buf: %s", buf);

	/* get AP count */
	if ((ret =
	     ltq_vb_get_param_from_file("AP_count=",
					sParamValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_scan",
			       "AP count not available");
		goto LTQ_Handler;
	}
	nVbWlScanRes = atoi(sParamValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_scan",
		       "number of scanned AP: %d", nVbWlScanRes);

	*wlVbScanRes = NULL;
	IFX_MEM_ALLOC((*wlVbScanRes), LTQ_MAPI_VB_WLAN_Scan *, nVbWlScanRes,
		      sizeof(LTQ_MAPI_VB_WLAN_Scan))
	    for (i = 0; i < nVbWlScanRes; i++) {
		/* get BSSID */
		sprintf(sParam, "BSSID_%d=", i);
		if ((ret =
		     ltq_vb_get_param_from_file(sParam,
						sParamValue)) == IFX_SUCCESS) {
			strcpy((*wlVbScanRes + i)->bssid, sParamValue);
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_scan",
				       "BSSID_%d: %s", i,
				       (*wlVbScanRes + i)->bssid);
		} else {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_scan",
				       "ltq_vb_get_param_from_file returned with error");
			goto LTQ_Handler;
		}

		/* get SSID */
		sprintf(sParam, "SSID_%d=", i);
		if ((ret =
		     ltq_vb_get_param_from_file(sParam,
						sParamValue)) == IFX_SUCCESS) {
			strcpy((*wlVbScanRes + i)->ssid, sParamValue);
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_scan",
				       "SSID_%d: %s", i,
				       (*wlVbScanRes + i)->ssid);
		} else {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_scan",
				       "ltq_vb_get_param_from_file returned with error");
			goto LTQ_Handler;
		}

		/* get standard */
		sprintf(sParam, "std_%d=", i);
		ret = ltq_vb_get_param_from_file(sParam, sParamValue);
		strcpy((*wlVbScanRes + i)->standard, sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_scan",
			       "standard%d: %s", i,
			       (*wlVbScanRes + i)->standard);

		/* get freqency band */
		sprintf(sParam, "band_%d=", i);
		ret = ltq_vb_get_param_from_file(sParam, sParamValue);
		strcpy((*wlVbScanRes + i)->freqBand, sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_scan",
			       "freqBand_%d: %s", i,
			       (*wlVbScanRes + i)->freqBand);

		/* get bandwidth */
		sprintf(sParam, "chanWidth_%d=", i);
		ret = ltq_vb_get_param_from_file(sParam, sParamValue);
		(*wlVbScanRes + i)->chanBW = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_scan",
			       "bandwidth_%d: %d", i,
			       (*wlVbScanRes + i)->chanBW);

		/* get beacon type */
		sprintf(sParam, "beaconType_%d=", i);
		ret = ltq_vb_get_param_from_file(sParam, sParamValue);
		(*wlVbScanRes + i)->beaconType = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_scan",
			       "beaconType_%d: %d", i,
			       (*wlVbScanRes + i)->beaconType);

		/* get authentication type */
		sprintf(sParam, "auth_%d=", i);
		ret = ltq_vb_get_param_from_file(sParam, sParamValue);
		(*wlVbScanRes + i)->authType = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_scan",
			       "authType_%d: %d", i,
			       (*wlVbScanRes + i)->authType);

		/* get encryption type */
		sprintf(sParam, "encr_%d=", i);
		ret = ltq_vb_get_param_from_file(sParam, sParamValue);
		(*wlVbScanRes + i)->encrType = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_scan",
			       "beaconType_%d: %d", i,
			       (*wlVbScanRes + i)->encrType);

		/* get wps enable info */
		sprintf(sParam, "WPS_%d=", i);
		ret = ltq_vb_get_param_from_file(sParam, sParamValue);
		(*wlVbScanRes + i)->wpsEna = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_scan",
			       "wpsEna_%d: %d", i, (*wlVbScanRes + i)->wpsEna);

		/* get RSSI */
		sprintf(sParam, "RSSI_%d=", i);
		ret = ltq_vb_get_param_from_file(sParam, sParamValue);
		strcpy((*wlVbScanRes + i)->rssi, sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_scan", "RSSI_%d: %s",
			       i, (*wlVbScanRes + i)->rssi);
	}
	*numEntries = nVbWlScanRes;

      IFX_Handler:
      LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_wlan_scan", "ret: %d", ret);
	return ret;
}

/* global string array to hold the buffer returned from varous scripts */
extern char8 sResultFromScript[MAX_DATA_LEN];

extern int32 ltq_get_param(const char8 * param, char8 * result);
#if 0
{
	int32 ret = IFX_SUCCESS;
	char8 sValue[MAX_DATA_LEN];
	char8 *pTmpStr = NULL, *pTmpStr2 = NULL;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_param", "param: %s", param);
	/* restore sValue buffer from global variable */
	strcpy(sValue, sResultFromScript);
	if ((pTmpStr = strstr(sValue, param)) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto LTQ_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto LTQ_Handler;
		}
	} else {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_param",
			       "sResultFromScript: %s", sResultFromScript);
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	}
	strcpy(result, pTmpStr2);

      LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_param", "ret=%d", ret);
	return ret;
}
#endif
/**
   \param   numEntries  -

   \param   wlVbScanRes - pointer to LTQ_MAPI_VB_WLAN_LinkStatus config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ltq_mapi_get_vb_wlan_link_status(LTQ_MAPI_VB_WLAN_LinkStatus * wlVbLinkStatus,
				 uint32 flags)
{
	int32 ret = IFX_SUCCESS;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_DATA_LEN];
	char8 sParamValue[MAX_FILELINE_LEN];
	char8 *pTmpStr = NULL, *pTmpStr2 = NULL, sValueTmp[MAX_DATA_LEN];

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_link_status", "");

	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	memset(sValue, 0x00, sizeof(sValue));
	sprintf(buf, "%s 0", SERVICE_VB_GET_WLAN_LINK_STATUS);

	if (ifx_GetCfgData((char8 *) buf, NULL, "-1", sValue) == 0) {
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_link_status",
		       "sValue: %s", sValue);
	/* save buffer in sValueTmp */
	strcpy(sValueTmp, sValue);

	/* get TX rate in Mb/s */
	if ((pTmpStr = strstr(sValue, "txRate")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto LTQ_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto LTQ_Handler;
		}
		wlVbLinkStatus->txRate = (float)strtod(pTmpStr2, (char **)NULL);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_link_status",
			       "TX Rate: %.1f", wlVbLinkStatus->txRate);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_link_status",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get link quality */
	if ((pTmpStr = strstr(sValue, "quality")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto LTQ_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto LTQ_Handler;
		}
		strcpy(wlVbLinkStatus->quality, pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_link_status",
			       "quality: %s", wlVbLinkStatus->quality);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_link_status",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get connection status */
	if ((pTmpStr = strstr(sValue, "connected")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto LTQ_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto LTQ_Handler;
		}
		if (atoi(pTmpStr2) == 0) {
			strcpy(wlVbLinkStatus->status, "Not Connected");
		} else {
			strcpy(wlVbLinkStatus->status, "Connected");
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_link_status",
			       "connection?: %s", wlVbLinkStatus->status);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_link_status",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* get signal strength */
	if ((pTmpStr = strstr(sValue, "signalStrength")) != NULL) {
		pTmpStr2 = strtok(pTmpStr, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto LTQ_Handler;
		}
		pTmpStr2 = strtok(NULL, "\"");
		if (pTmpStr2 == NULL) {
			ret = IFX_FAILURE;
			goto LTQ_Handler;
		}
		wlVbLinkStatus->signalStrength = atoi(pTmpStr2);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_link_status",
			       "Signal strength in percentile: %d",
			       wlVbLinkStatus->signalStrength);
	} else
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_link_status",
			       "sValue: %s", sValue);

	/* restore sValue buffer from sValueTmp */
	strcpy(sValue, sValueTmp);
	/* save buffer in sResultFromScript */
	strcpy(sResultFromScript, sValue);

	/* get channel */
	if ((ret = ltq_get_param("channel=", sParamValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_link_status",
			       "channel not available");
		goto LTQ_Handler;
	}
	wlVbLinkStatus->channel = atoi(sParamValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_link_status",
		       "channel: %d", wlVbLinkStatus->channel);

	/* get frequency band */
	if ((ret = ltq_get_param("band=", sParamValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_link_status",
			       "frequency band not available");
		goto LTQ_Handler;
	}
	if (!(strcmp(sParamValue, "2.4")))
		wlVbLinkStatus->freqBand = IFX_MAPI_WLAN_2_4_GHz_Freq;
	else
		wlVbLinkStatus->freqBand = IFX_MAPI_WLAN_5_GHz_Freq;
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_link_status",
		       "freqBand: %d", wlVbLinkStatus->freqBand);

	/* get bandwidth (20/40) */
	if ((ret = ltq_get_param("bw=", sParamValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_link_status",
			       "bandwidth not available");
		goto LTQ_Handler;
	}
	if (!(strcmp(sParamValue, "20")))
		wlVbLinkStatus->chanBW = IFX_MAPI_WLAN_BW_20MHZ;
	else
		wlVbLinkStatus->chanBW = IFX_MAPI_WLAN_BW_40MHZ;
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_link_status",
		       "chanBW: %d", wlVbLinkStatus->chanBW);

    /* get country */
    if((ret = ltq_get_param("Country=", sParamValue)) != IFX_SUCCESS) {
        IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_link_status",
                       "country not available");
    	strncpy(sParamValue, "??", 3);
    	ret = IFX_SUCCESS;
//        goto LTQ_Handler;
    }
    if(!(strcmp(sParamValue, "??")))
    	strncpy(wlVbLinkStatus->country, "n/a", 4);
    else
    	strncpy(wlVbLinkStatus->country, sParamValue, 3);

    IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_link_status", "country: %s",
    		wlVbLinkStatus->country);

    LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_link_status", "ret: %d", ret);
	return ret;
}

/**
   This api gets the parameters for all four access categories of one AP/VAP and
   returns the information in wlStaWmm.

   \param   mainCpeId

   \param   numEntries

   \param   wlStaWmm - pointer to IFX_MAPI_WLAN_STA_WMM_Cfg structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE

   \todo check if numEntries can be removed
*/
int32
ltq_mapi_get_vb_wmm_sta_config(IFX_MAPI_WLAN_STA_WMM_Cfg * wlVbStaWmm,
			       uint32 flags)
{
	int32 ret = IFX_SUCCESS, count = 0, i;
	char8 buf[MAX_DATA_LEN], *sValue = NULL;
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_VB_WMM_PARAM_COUNT + 1];

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wmm_sta_config", "");

	/* get wlan_sta_cfg object from rc.conf */
	sprintf(buf, "%s_", PREFIX_VB_WMM_STA_CFG);
	if ((ret =
	     ifx_GetCfgObject(FILE_RC_CONF, TAG_VB_WLAN_WMM, buf, IFX_F_DEFAULT,
			      &sValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wmm_sta_config",
			       "buf: %s", buf);
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wmm_sta_config",
		       "buf: %s, sValue: %s", buf, sValue);

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wmm_sta_config", "count: %d",
		       count);
	for (i = 0; i < count; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wmm_sta_config",
			       "%s:%s", array_fvp[i].fieldname,
			       array_fvp[i].value);

	/* four entries are present (four access categories) */
	count = IFX_MAPI_WLAN_WMM_NUM_AC;

	for (i = 0; i < count; i++) {
		(wlVbStaWmm + i)->ac = i;
		(wlVbStaWmm + i)->ECWmin = atoi(array_fvp[(i * 5)].value);
		(wlVbStaWmm + i)->ECWmax = atoi(array_fvp[(i * 5) + 1].value);
		(wlVbStaWmm + i)->AIFSN = atoi(array_fvp[(i * 5) + 2].value);
		(wlVbStaWmm + i)->TXOP = atoi(array_fvp[(i * 5) + 3].value);
		(wlVbStaWmm + i)->ackPolicyEna =
		    atoi(array_fvp[(i * 5) + 4].value);
	}
      LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wmm_sta_config", "ret: %d",
		       ret);
	/* free buffer allocated in ifx_GetCfgObject */
	IFX_MEM_FREE(sValue);
	return ret;
}

/**
   \param   wlVbGenCfg - pointer to LTQ_MAPI_WLAN_VB_GEN_Cfg structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ltq_mapi_get_vb_wlan_profile(LTQ_MAPI_VB_WLAN_Profile * wlVbWlnProf,
			     uint32 flags)
{
	int32 ret = IFX_SUCCESS, count = 0, i;
	char8 buf[MAX_DATA_LEN], *sValue = NULL;
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_VB_WLAN_PROFILE_COUNT + 1];

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_profile", "");

	/* get gen_vb object from rc.conf */
	sprintf(buf, "%s_", PREFIX_VB_WLAN_PROFILE);
	if ((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_VB_WLAN_PROF,
				    buf, IFX_F_DEFAULT, &sValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_profile",
			       "buf: %s", buf);
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_profile",
		       "buf: %s, sValue: %s", buf, sValue);

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_profile", "count: %d",
		       count);
	for (i = 0; i < count; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_profile", "%s:%s",
			       array_fvp[i].fieldname, array_fvp[i].value);

	sprintf(wlVbWlnProf->ssid, "%s", array_fvp[0].value);
	sprintf(wlVbWlnProf->bssid, "%s", array_fvp[1].value);
	wlVbWlnProf->beaconType = atoi(array_fvp[2].value);
	wlVbWlnProf->authType = atoi(array_fvp[3].value);
	wlVbWlnProf->encrType = atoi(array_fvp[4].value);
	wlVbWlnProf->wepKeyIndex = atoi(array_fvp[5].value);
	wlVbWlnProf->wepKeyType = atoi(array_fvp[6].value);
	wlVbWlnProf->wepEncrLevel = atoi(array_fvp[7].value);
	sprintf(wlVbWlnProf->wepKey1, "%s", array_fvp[8].value);
	sprintf(wlVbWlnProf->wepKey2, "%s", array_fvp[9].value);
	sprintf(wlVbWlnProf->wepKey3, "%s", array_fvp[10].value);
	sprintf(wlVbWlnProf->wepKey4, "%s", array_fvp[11].value);
	sprintf(wlVbWlnProf->passPhrase, "%s", array_fvp[12].value);
	sprintf(wlVbWlnProf->userName, "%s", array_fvp[13].value);
	wlVbWlnProf->freqBand = atoi(array_fvp[14].value);
	wlVbWlnProf->chanBW = atoi(array_fvp[15].value);
	sprintf(wlVbWlnProf->standard, "%s", array_fvp[16].value);

      LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_wlan_profile", "ret: %d", ret);
	/* free buffer allocated in ifx_GetCfgObject */
	IFX_MEM_FREE(sValue);
	return ret;
}

/**
   \param   vbEthPhyCfg - pointer to LTQ_MAPI_VB_ETH_PHY_Cfg structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32
ltq_mapi_get_vb_eth_phy_config(LTQ_MAPI_VB_ETH_PHY_Cfg * vbEthPhyCfg,
			       uint32 flags)
{
	int32 ret = IFX_SUCCESS, count = 0, i, passed_index = -1;
	char8 buf[MAX_DATA_LEN], *sValue = NULL;
	IFX_NAME_VALUE_PAIR array_fvp[VB_ETH_PHY_PARAM_COUNT + 1];

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_eth_phy_config", "");

	/*
	 * get index from cpeid: example wlmn_1_cpeId="3" => passed_index = 1
	 */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, vbEthPhyCfg->iid.cpeId,
				 passed_index)
	    IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_eth_phy_config",
			   "passed_index: %d", passed_index);

	/* get gen_vb object from rc.conf */
	sprintf(buf, "%s_%d_", PREFIX_VB_ETH_PHY, passed_index);
	if ((ret =
	     ifx_GetCfgObject(FILE_RC_CONF, TAG_VB_ETH_PHY, buf, IFX_F_DEFAULT,
			      &sValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_eth_phy_config",
			       "buf: %s", buf);
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_eth_phy_config",
		       "buf: %s, sValue: %s", buf, sValue);

	/* form an array of field value pairs for easier access to parameters */
	memset(array_fvp, 0x00, sizeof(array_fvp));
	form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_eth_phy_config", "count: %d",
		       count);
	for (i = 0; i < count; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_eth_phy_config",
			       "%s:%s", array_fvp[i].fieldname,
			       array_fvp[i].value);

//              vbEthPhyCfg->iid.cpeId.Id       = atoi(array_fvp[0].value);
	vbEthPhyCfg->ephyEna = atoi(array_fvp[1].value);
	vbEthPhyCfg->ephyFlowControlEna = atoi(array_fvp[2].value);
	vbEthPhyCfg->ephyDuplxMode = atoi(array_fvp[3].value);
	vbEthPhyCfg->ephySpeed = atoi(array_fvp[4].value);
	sprintf(vbEthPhyCfg->ephyName, "%s", array_fvp[5].value);
	vbEthPhyCfg->ephyVlanId = atoi(array_fvp[6].value);
	vbEthPhyCfg->ephySwitchPort = atoi(array_fvp[7].value);

      IFX_Handler:
      LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_eth_phy_config", "ret: %d",
		       ret);
	/* free buffer allocated in ifx_GetCfgObject */
	IFX_MEM_FREE(sValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_get_vb_eth_phy_config", "");
	return ret;
}

/**
   \param oper

   \param   wlVbGenCfg - pointer to LTQ_MAPI_WLAN_VB_GEN_Cfg structure

   \param flags

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int32
ltq_mapi_set_wlan_vb_config(uint32 operation,
			    LTQ_MAPI_WLAN_VB_GEN_BD_Cfg * wlVbGenCfg,
			    uint32 flags)
{
	int32 ret = IFX_SUCCESS, count = 0, i;
	struct timeval tv;
	char8 conf_buf[MAX_DATA_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_GEN_VB_PARAM_COUNT];

	gettimeofday(&tv, NULL);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_config", "%d:%d",
		       (int32) tv.tv_sec, (int32) tv.tv_usec);

	/*
	   initalize buffer conf_buf which is used for two purposes: - holding the
	   configuration for wlVbGenCfg to be written to rc.conf - holding the
	   commands for system calls */
	memset(conf_buf, 0x00, sizeof(conf_buf));

	/*
	   initalize buffer array_fvp which is used for storing the new
	   configuration of wlVbGenCfg in field-value format */
	memset(array_fvp, 0x00, sizeof(array_fvp));

		/*************** Prolog Block *********************/
	/*
	   only modify operation is allowed => flags variable is appended with
	   internal flags */
	if ((operation == IFX_OP_DEL) || (operation == IFX_OP_ADD)) {
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	} else
		flags |= IFX_F_MODIFY;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_config", "flags: 0x%x",
		       flags);

		/*************** Validation Block *****************/
	/*
	   for operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_config",
			       "wlVbGenCfg: %p", wlVbGenCfg);
		/* Do simple validation of pointer (such as is NULL) */
		IFX_VALIDATE_PTR(wlVbGenCfg)
		    /* Do simple validation of flags such as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

		/*************** ID Allocation Block - Only for ADD Operation **************/
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_config", "");

		/**************** Name Value Formation as per RC.CONF ********************/
	/*
	   form the field-value pairs(FVP) from the given structure for ADD/MODIFY
	   Operations */
	count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		/*
		   the buffer array_fvp is filled in a first step with the field names
		   of gen_vb object */
		ifx_fill_ArrayFvp_FName(array_fvp, count,
					WLAN_GEN_VB_PARAM_COUNT,
					wlan_vb_gbd_params);

		sprintf(array_fvp[0].value, "%s", wlVbGenCfg->name);
		sprintf(array_fvp[1].value, "%d", wlVbGenCfg->mode);
		sprintf(array_fvp[2].value, "%s",
			inet_ntoa(wlVbGenCfg->mgmtIP));
		sprintf(array_fvp[3].value, "%s",
			inet_ntoa(wlVbGenCfg->mgmtNetMask));
		sprintf(array_fvp[4].value, "%d", wlVbGenCfg->dhcpClntEna);
		sprintf(array_fvp[5].value, "%d", wlVbGenCfg->wlanMgmt);
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_config", "");
	/* store number of parameters for gen_vb object in count */
	count = WLAN_GEN_VB_PARAM_COUNT;

	for (i = 0; i < WLAN_GEN_VB_PARAM_COUNT; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_config",
			       "name: %s, value: %s", array_fvp[i].fieldname,
			       array_fvp[i].value);

		/********* ACL Checking block - MUST for MODIFY/DELETE operations **********/


		/*************** System Config File Update Block ****************/
	/*
	   convert the name value pair in array_fvp into string format expected by
	   rc.conf file */
	if ((ret = form_cfgdb_buf(conf_buf, count, array_fvp)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_config", "");
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_config", "conf_buf: %s",
		       conf_buf);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_GEN_VB, flags, 1, conf_buf);
	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_config", "");
		goto LTQ_Handler;
	}

		/**************** Device Configuration Block *********************/
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags)) {
		sprintf(conf_buf, "%s", SERVICE_LAN_RESTART);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_config",
			       "conf_buf: %s", conf_buf);
		system(conf_buf);
		sprintf(conf_buf, "%s %d", SERVICE_WLAN_START, 0);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_config",
			       "conf_buf: %s", conf_buf);
		system(conf_buf);
	}

		/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

		/*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_config",
			       "ret: %d", ret);
		goto LTQ_Handler;
	}
      LTQ_Handler:
	gettimeofday(&tv, NULL);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_config", "%d:%d\nret: %d",
		       (int32) tv.tv_sec, (int32) tv.tv_usec, ret);
	return ret;
}

/**
   \param oper

   \param   wlVbLanCfg - pointer to LTQ_MAPI_WLAN_VB_LAN_Cfg structure

   \param flags

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int32
ltq_mapi_set_wlan_vb_lan_config(uint32 operation,
				LTQ_MAPI_WLAN_VB_LAN_BD_Cfg * wlVbLanCfg,
				uint32 flags)
{
	int32 ret = IFX_SUCCESS, count = 0, i;
	struct timeval tv;
	char8 conf_buf[MAX_DATA_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_VB_LAN_PARAM_COUNT + 1];

	gettimeofday(&tv, NULL);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_lan_config", "%d:%d",
		       (int32) tv.tv_sec, (int32) tv.tv_usec);

	/*
	   initalize buffer conf_buf which is used for two purposes: - holding the
	   configuration for wlVbGenCfg to be written to rc.conf - holding the
	   commands for system calls */
	memset(conf_buf, 0x00, sizeof(conf_buf));

	/*
	   initalize buffer array_fvp which is used for storing the new
	   configuration of wlVbGenCfg in field-value format */
	memset(array_fvp, 0x00, sizeof(array_fvp));

		/*************** Prolog Block *********************/
	/*
	   only modify operation is allowed => flags variable is appended with
	   internal flags */
	if ((operation == IFX_OP_DEL) || (operation == IFX_OP_ADD)) {
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	} else
		flags |= IFX_F_MODIFY;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_lan_config",
		       "flags: 0x%x", flags);

		/*************** Validation Block *****************/
	/*
	   for operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_lan_config",
			       "wlVbGenCfg: %p", wlVbLanCfg);
		/* Do simple validation of pointer (such as is NULL) */
		IFX_VALIDATE_PTR(wlVbLanCfg)
		    /* Do simple validation of flags such as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

		/*************** ID Allocation Block - Only for ADD Operation **************/
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_lan_config", "");

		/**************** Name Value Formation as per RC.CONF ********************/
	/*
	   form the field-value pairs(FVP) from the given structure for ADD/MODIFY
	   Operations */
	count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		/*
		   the buffer array_fvp is filled in a first step with the field names
		   of gen_vb object */
		ifx_fill_ArrayFvp_FName(array_fvp, count,
					WLAN_VB_LAN_PARAM_COUNT,
					wlan_vb_lbd_params);

		sprintf(array_fvp[0].value, "%d", wlVbLanCfg->masterNetMode);
		sprintf(array_fvp[1].value, "%d", wlVbLanCfg->endPtNetMode);
		sprintf(array_fvp[2].value, "%d", wlVbLanCfg->endPtLbEna);
		sprintf(array_fvp[3].value, "%s",
			wlVbLanCfg->endPtClonedMacAddr);
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_lan_config", "");
	/* store number of parameters for lan_vb object in count */
	count = WLAN_VB_LAN_PARAM_COUNT;

	for (i = 0; i < WLAN_VB_LAN_PARAM_COUNT; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_lan_config",
			       "name: %s, value: %s", array_fvp[i].fieldname,
			       array_fvp[i].value);

		/********* ACL Checking block - MUST for MODIFY/DELETE operations **********/

		/*************** System Config File Update Block ****************/
	/*
	   convert the name value pair in array_fvp into string format expected by
	   rc.conf file */
	if ((ret = form_cfgdb_buf(conf_buf, count, array_fvp)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_lan_config", "");
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_lan_config",
		       "conf_buf: %s", conf_buf);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_VB_LAN, flags, 1, conf_buf);
	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_lan_config", "");
		goto LTQ_Handler;
	}

		/**************** Device Configuration Block *********************/
	/*
	   \todo check which scripts needs to be called */
	sprintf(conf_buf, "%s", SERVICE_VB_CONFIG);
	system(conf_buf);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_lan_config", "");

		/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

		/*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_lan_config",
			       "ret: %d", ret);
		goto LTQ_Handler;
	}

      LTQ_Handler:
	gettimeofday(&tv, NULL);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_lan_config",
		       "%d:%d\nret: %d", (int32) tv.tv_sec, (int32) tv.tv_usec,
		       ret);
	return ret;
}

/**
   \param oper

   \param   wlVbGenCfg - pointer to LTQ_MAPI_WLAN_VB_GEN_Cfg structure

   \param flags

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int32
ltq_mapi_set_vb_eth_phy_config(uint32 operation,
			       LTQ_MAPI_VB_ETH_PHY_Cfg * vbEthPhyCfg,
			       uint32 flags)
{
	int32 ret = IFX_SUCCESS, count = 0, i, passed_index = -1;
	char8 conf_buf[MAX_DATA_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[VB_ETH_PHY_PARAM_COUNT + 1];

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_eth_phy_config", "");

	/*
	   initalize buffer conf_buf which is used for two purposes: - holding the
	   configuration for vbEthPhyCfg to be written to rc.conf - holding the
	   commands for system calls */
	memset(conf_buf, 0x00, sizeof(conf_buf));

	/*
	   initalize buffer array_fvp which is used for storing the new
	   configuration of vbEthPhyCfg in field-value format */
	memset(array_fvp, 0x00, sizeof(array_fvp));

		/*************** Prolog Block *********************/
	/*
	   only modify operation is allowed => flags variable is appended with
	   internal flags */
	if ((operation == IFX_OP_DEL) || (operation == IFX_OP_ADD)) {
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	} else
		flags |= IFX_F_MODIFY;

	sprintf(vbEthPhyCfg->iid.cpeId.secName, "%s", TAG_VB_ETH_PHY);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_eth_phy_config", "flags: 0x%x",
		       flags);

		/*************** Validation Block *****************/
	/*
	   for operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer (such as is NULL) */
		IFX_VALIDATE_PTR(vbEthPhyCfg)
		    /* Do simple validation of flags such as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

		/*************** ID Allocation Block - Only for ADD Operation **************/
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_eth_phy_config", "");

		/**************** Name Value Formation as per RC.CONF ********************/
	/*
	   form the field-value pairs(FVP) from the given structure for ADD/MODIFY
	   Operations */
	count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		/*
		   the buffer array_fvp is filled in a first step with the field names
		   of gen_vb object */
		ifx_fill_ArrayFvp_FName(array_fvp, count,
					VB_ETH_PHY_PARAM_COUNT,
					vb_eth_phy_params);

		sprintf(array_fvp[0].value, "%d", vbEthPhyCfg->iid.cpeId.Id);
		sprintf(array_fvp[1].value, "%d", vbEthPhyCfg->ephyEna);
		sprintf(array_fvp[2].value, "%d",
			vbEthPhyCfg->ephyFlowControlEna);
		sprintf(array_fvp[3].value, "%d", vbEthPhyCfg->ephyDuplxMode);
		sprintf(array_fvp[4].value, "%d", vbEthPhyCfg->ephySpeed);
		sprintf(array_fvp[5].value, "%s", vbEthPhyCfg->ephyName);
		sprintf(array_fvp[6].value, "%d", vbEthPhyCfg->ephyVlanId);
		sprintf(array_fvp[7].value, "%d", vbEthPhyCfg->ephySwitchPort);
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_eth_phy_config", "");

	/* store number of parameters for gen_vb object in count */
	count = VB_ETH_PHY_PARAM_COUNT;

	for (i = 0; i < VB_ETH_PHY_PARAM_COUNT; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_eth_phy_config",
			       "name: %s, value: %s", array_fvp[i].fieldname,
			       array_fvp[i].value);

	/*
	 * Get Config Index in case of modify/delete operations from CPEID
	 */
	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, vbEthPhyCfg->iid.cpeId,
					 passed_index)
	}

	/*
	 * Determine the configuration index - for Add, Delete,
	 * Modify operations. Name is partial since index is not known
	 */
	if (ifx_get_conf_index_and_nv_pairs
	    (&vbEthPhyCfg->iid, passed_index, PREFIX_VB_ETH_PHY, count,
	     array_fvp, flags) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_eth_phy_config", "");
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	}

		/********* ACL Checking block - MUST for MODIFY/DELETE operations **********/


		/*************** System Config File Update Block ****************/
	/*
	   convert the name value pair in array_fvp into string format expected by
	   rc.conf file */
	if ((ret = form_cfgdb_buf(conf_buf, count, array_fvp)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_eth_phy_config", "");
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_eth_phy_config",
		       "conf_buf: %s", conf_buf);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_VB_ETH_PHY, flags, 1, conf_buf);
	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_eth_phy_config", "");
		goto LTQ_Handler;
	}

		/**************** Device Configuration Block *********************/
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags)) {
		sprintf(conf_buf, "%s", SERVICE_LAN_RESTART);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_eth_phy_config",
			       "conf_buf: %s", conf_buf);
		system(conf_buf);
		sprintf(conf_buf, "%s %d", SERVICE_WLAN_START, 0);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_eth_phy_config",
			       "conf_buf: %s", conf_buf);
		system(conf_buf);
	}

		/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

		/*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_eth_phy_config",
			       "ret: %d", ret);
		goto LTQ_Handler;
	}

      IFX_Handler:
      LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_config", "ret: %d", ret);
	return ret;
}

/**
   \param oper

   \param   wlVbWlnCfg - pointer to LTQ_MAPI_VB_WLAN_Cfg structure

   \param flags

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int32
ltq_mapi_set_wlan_vb_wlan_config(uint32 operation,
				 LTQ_MAPI_VB_WLAN_Cfg * wlVbWlanCfg,
				 uint32 flags)
{
	int32 ret = IFX_SUCCESS, count = 0, i;
	struct timeval tv;
	char8 conf_buf[MAX_DATA_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_VB_WLAN_PARAM_COUNT + 1];

	gettimeofday(&tv, NULL);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_wlan_config", "%d:%d",
		       (int32) tv.tv_sec, (int32) tv.tv_usec);

	/*
	   initalize buffer conf_buf which is used for two purposes: - holding the
	   configuration for wlVbWlnCfg to be written to rc.conf - holding the
	   commands for system calls */
	memset(conf_buf, 0x00, sizeof(conf_buf));

	/*
	   initalize buffer array_fvp which is used for storing the new
	   configuration of wlVbWlnCfg in field-value format */
	memset(array_fvp, 0x00, sizeof(array_fvp));

		/*************** Prolog Block *********************/
	/*
	   only modify operation is allowed => flags variable is appended with
	   internal flags */
	if ((operation == IFX_OP_DEL) || (operation == IFX_OP_ADD)) {
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	} else
		flags |= IFX_F_MODIFY;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_wlan_config",
		       "flags: 0x%x", flags);

		/*************** Validation Block *****************/
	/*
	   for operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer (such as is NULL) */
		IFX_VALIDATE_PTR(wlVbWlanCfg)
		    /* Do simple validation of flags such as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

		/*************** ID Allocation Block - Only for ADD Operation **************/
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_wlan_config", "");

		/**************** Name Value Formation as per RC.CONF ********************/
	/*
	   form the field-value pairs(FVP) from the given structure for ADD/MODIFY
	   Operations */
	count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		/*
		   the buffer array_fvp is filled in a first step with the field names
		   of gen_vb object */
		ifx_fill_ArrayFvp_FName(array_fvp, count,
					WLAN_VB_WLAN_PARAM_COUNT,
					wlan_vb_wlan_params);

		sprintf(array_fvp[0].value, "%d", wlVbWlanCfg->radioEna);
		sprintf(array_fvp[1].value, "%d", wlVbWlanCfg->standard);
		sprintf(array_fvp[2].value, "%s", wlVbWlanCfg->country);
		sprintf(array_fvp[3].value, "%d", wlVbWlanCfg->freqBand);
		sprintf(array_fvp[4].value, "%d", wlVbWlanCfg->ctsProtctMode);
		sprintf(array_fvp[5].value, "%d", wlVbWlanCfg->rts);
		sprintf(array_fvp[6].value, "%d", wlVbWlanCfg->powerLvl);
		sprintf(array_fvp[7].value, "%f", wlVbWlanCfg->txRate);
		sprintf(array_fvp[8].value, "%d", wlVbWlanCfg->nChanWidth);
		sprintf(array_fvp[9].value, "%d", wlVbWlanCfg->nGuardIntvl);
		sprintf(array_fvp[10].value, "%d", wlVbWlanCfg->preamble);
		sprintf(array_fvp[11].value, "%d", wlVbWlanCfg->nSTBCrx);
		sprintf(array_fvp[12].value, "%d", wlVbWlanCfg->wpsEna);
		sprintf(array_fvp[13].value, "%d", wlVbWlanCfg->wmmEna);
		sprintf(array_fvp[14].value, "%d", wlVbWlanCfg->ldpcEna);
		sprintf(array_fvp[15].value, "%d", wlVbWlanCfg->beamForm);
		sprintf(array_fvp[16].value, "%d", wlVbWlanCfg->boostMode);
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_wlan_config", "");
	/* store number of parameters for lan_vb object in count */
	count = WLAN_VB_WLAN_PARAM_COUNT;

	for (i = 0; i < WLAN_VB_WLAN_PARAM_COUNT; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_wlan_config",
			       "name: %s, value: %s", array_fvp[i].fieldname,
			       array_fvp[i].value);

		/********* ACL Checking block - MUST for MODIFY/DELETE operations **********/

		/*************** System Config File Update Block ****************/
	/*
	   convert the name value pair in array_fvp into string format expected by
	   rc.conf file */
	if ((ret = form_cfgdb_buf(conf_buf, count, array_fvp)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_wlan_config", "");
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_wlan_config",
		       "conf_buf: %s", conf_buf);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_VB_WLAN_CFG, flags, 1, conf_buf);
	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_wlan_config", "");
		goto LTQ_Handler;
	}

		/**************** Device Configuration Block *********************/
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
	    IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
	    IFX_DEACTIVATE_F_NOT_SET(flags)) {
		sprintf(conf_buf, "%s", SERVICE_VB_CONFIG);
		system(conf_buf);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_wlan_config",
			       "conf_buf: %s", conf_buf);
	}

		/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

		/*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_wlan_config",
			       "ret: %d", ret);
		goto LTQ_Handler;
	}

      LTQ_Handler:
	gettimeofday(&tv, NULL);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_wlan_config",
		       "%d:%d\nret: %d", (int32) tv.tv_sec, (int32) tv.tv_usec,
		       ret);
	return ret;
}

/**
   \param oper

   \param   wlVbWlnProf - pointer to LTQ_MAPI_VB_WLAN_Profile structure

   \param flags

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int32
ltq_mapi_set_vb_wlan_profile(uint32 operation,
			     LTQ_MAPI_VB_WLAN_Profile * wlVbWlnProf,
			     uint32 flags)
{
	int32 ret = IFX_SUCCESS, count = 0, i;
	char8 conf_buf[MAX_DATA_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_VB_WLAN_PROFILE_COUNT + 1];

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_wlan_profile", "");

	/*
	   initalize buffer conf_buf which is used for two purposes: - holding the
	   configuration for wlVbWlnCfg to be written to rc.conf - holding the
	   commands for system calls */
	memset(conf_buf, 0x00, sizeof(conf_buf));

	/*
	   initalize buffer array_fvp which is used for storing the new
	   configuration of wlVbWlnCfg in field-value format */
	memset(array_fvp, 0x00, sizeof(array_fvp));

	/*************** Prolog Block *********************/
	/*
	   only modify operation is allowed => flags variable is appended with
	   internal flags */
	if ((operation == IFX_OP_DEL) || (operation == IFX_OP_ADD)) {
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	} else
		flags |= IFX_F_MODIFY;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_wlan_profile", "flags: 0x%x",
		       flags);

	/*************** Validation Block *****************/
	/*
	   for operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_wlan_profile",
			       "wlVbWlnProf: %p", wlVbWlnProf);
		/* Do simple validation of pointer (such as is NULL) */
		IFX_VALIDATE_PTR(wlVbWlnProf)
		    /* Do simple validation of flags such as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

	/*************** ID Allocation Block - Only for ADD Operation **************/
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_wlan_profile", "");

	/**************** Name Value Formation as per RC.CONF ********************/
	/*
	   form the field-value pairs(FVP) from the given structure for ADD/MODIFY
	   Operations */
	count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		/*
		   the buffer array_fvp is filled in a first step with the field names
		   of gen_vb object */
		ifx_fill_ArrayFvp_FName(array_fvp, count,
					WLAN_VB_WLAN_PROFILE_COUNT,
					wlan_vb_wlan_profile);

		sprintf(array_fvp[0].value, "%s", wlVbWlnProf->ssid);
		sprintf(array_fvp[1].value, "%s", wlVbWlnProf->bssid);
		sprintf(array_fvp[2].value, "%d", wlVbWlnProf->beaconType);
		sprintf(array_fvp[3].value, "%d", wlVbWlnProf->authType);
		sprintf(array_fvp[4].value, "%d", wlVbWlnProf->encrType);
		sprintf(array_fvp[5].value, "%d", wlVbWlnProf->wepKeyIndex);
		sprintf(array_fvp[6].value, "%d", wlVbWlnProf->wepKeyType);
		sprintf(array_fvp[7].value, "%d", wlVbWlnProf->wepEncrLevel);
		sprintf(array_fvp[8].value, "%s", wlVbWlnProf->wepKey1);
		sprintf(array_fvp[9].value, "%s", wlVbWlnProf->wepKey2);
		sprintf(array_fvp[10].value, "%s", wlVbWlnProf->wepKey3);
		sprintf(array_fvp[11].value, "%s", wlVbWlnProf->wepKey4);
		sprintf(array_fvp[12].value, "%s", wlVbWlnProf->passPhrase);
		sprintf(array_fvp[13].value, "%s", wlVbWlnProf->userName);
		sprintf(array_fvp[14].value, "%d", wlVbWlnProf->freqBand);
		sprintf(array_fvp[15].value, "%d", wlVbWlnProf->chanBW);
		snprintf(array_fvp[16].value, 10, "%s", wlVbWlnProf->standard);
	}

	/* store number of parameters for lan_vb object in count */
	count = WLAN_VB_WLAN_PROFILE_COUNT;

	for (i = 0; i < WLAN_VB_WLAN_PROFILE_COUNT; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_wlan_profile",
			       "name: %s, value: %s", array_fvp[i].fieldname,
			       array_fvp[i].value);

	/********* ACL Checking block - MUST for MODIFY/DELETE operations **********/

	/*************** System Config File Update Block ****************/
	/*
	   convert the name value pair in array_fvp into string format expected by
	   rc.conf file */
	if ((ret = form_cfgdb_buf(conf_buf, count, array_fvp)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_wlan_profile", "");
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_wlan_profile", "conf_buf: %s",
		       conf_buf);

	/* RC.CONF Configuration block */
	ret =
	    ifx_SetObjData(FILE_RC_CONF, TAG_VB_WLAN_PROF, flags, 1, conf_buf);
	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_wlan_profile", "");
		goto LTQ_Handler;
	}

	/**************** Device Configuration Block *********************/
	/*
	   \todo check which scripts needs to be called */
//              sprintf(conf_buf, "%s", SERVICE_WLAN_VB_CONFIG);
//              system(conf_buf);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_wlan_profile", "");

	/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

	/*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_wlan_profile",
			       "ret: %d", ret);
		goto LTQ_Handler;
	}

LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_vb_wlan_profile", "ret: %d", ret);
	return ret;
}

/**
   This api triggers the VB to connect to the AP stored in wlan_profile

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int32 ltq_mapi_trigger_vb_connect()
{
	char8 conf_buf[MAX_DATA_LEN];

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_trigger_vb_connect", "");

	/*
	 * initalize buffer conf_buf which is used for holding the commands for
	 * system calls
	 */
	memset(conf_buf, 0x00, sizeof(conf_buf));

	/* call system script to initiate connection to AP */
	sprintf(conf_buf, "%s &", SERVICE_WLAN_VB_CONNECT);
	system(conf_buf);

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_trigger_vb_connect", "conf_buf: %s",
		       conf_buf);
	return IFX_SUCCESS;
}

/**
   	   \param oper

   	   \param   wlVbScan - pointer to LTQ_MAPI_VB_WLAN_Scan structure

   	   \param flags

   	   \return
   	   - IFX_SUCCESS
   	   - IFX_FAILURE
*/
int32
ltq_mapi_set_wlan_vb_scan_config(uint32 operation,
				 LTQ_MAPI_VB_WLAN_Scan * wlVbScan, uint32 flags)
{
	int32 ret = IFX_SUCCESS, count = 0, i;
	char8 conf_buf[MAX_DATA_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_VB_WLAN_SCAN_COUNT + 1];

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_scan_config", "");

	/*
	 * initalize buffer conf_buf which is used for two purposes:
	 * - holding the configuration for wlVbWlnCfg to be written to rc.conf
	 * - holding the commands for system calls
	 */
	memset(conf_buf, 0x00, sizeof(conf_buf));

	/*
	 * initalize buffer array_fvp which is used for storing the new configuration
	 * of wlVbWlnCfg in field-value format
	 */
	memset(array_fvp, 0x00, sizeof(array_fvp));

		/*************** Prolog Block *********************/
	/*
	 * only modify operation is allowed => flags variable is appended with internal flags
	 */
	if ((operation == IFX_OP_DEL) || (operation == IFX_OP_ADD)) {
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	} else
		flags |= IFX_F_MODIFY;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_scan_config",
		       "flags: 0x%x", flags);

		/*************** Validation Block *****************/
	/*
	 * for operations other than DELETE do the verification of input params
	 */
	/* Do simple validation of pointer (such as is NULL) */
	IFX_VALIDATE_PTR(wlVbScan)
	    /* Do simple validation of flags such as less than 0 */
	    IFX_VALIDATE_FLAGS(flags)

		/*************** ID Allocation Block - Only for ADD Operation **************/
		/**************** Name Value Formation as per RC.CONF ********************/
	    /*
	     * form the field-value pairs(FVP) from the given structure for ADD/MODIFY Operations
	     */
	    count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		/*
		 * the buffer array_fvp is filled in a first step with the field names
		 * of gen_vb object
		 */
		ifx_fill_ArrayFvp_FName(array_fvp, count,
					WLAN_VB_WLAN_SCAN_COUNT,
					wlan_vb_wlan_scan);

		sprintf(array_fvp[0].value, "%s", wlVbScan->ssid_wildcard);
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_scan_config", "");

	/* store number of parameters for lan_vb object in count */
	count = WLAN_VB_WLAN_SCAN_COUNT;

	for (i = 0; i < count; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_scan_config",
			       "name: %s, value: %s",
			       array_fvp[i].fieldname, array_fvp[i].value);

		/********* ACL Checking block - MUST for MODIFY/DELETE operations **********/

		/*************** System Config File Update Block ****************/
	/*
	 * convert the name value pair in array_fvp into string format expected by
	 * rc.conf file
	 */
	if ((ret = form_cfgdb_buf(conf_buf, count, array_fvp)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_scan_config", "");
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_scan_config",
		       "conf_buf: %s", conf_buf);

	/* RC.CONF Configuration block */
	ret =
	    ifx_SetObjData(FILE_RC_CONF, TAG_VB_WLAN_SCAN, flags, 1, conf_buf);
	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_scan_config", "");
		goto LTQ_Handler;
	}

		/**************** Device Configuration Block *********************/
	/*
	 * no script to be called
	 */
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_scan_config", "");

		/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

		/*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_scan_config",
			       "ret: %d", ret);
		goto LTQ_Handler;
	}

LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_scan_config", "ret: %d", ret);
	return ret;
}

/**
   This API configures the VB300 STA WMM parameters.

   \param oper

   \param wlVbWmm

   \param flags

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int32
ltq_mapi_set_wlan_vb_wmm_config(uint32 operation,
				IFX_MAPI_WLAN_STA_WMM_Cfg * wlVbWmm,
				uint32 flags)
{
	int32 ret = IFX_SUCCESS, count = 0, passed_index = 1, i;
	char8 conf_buf[MAX_DATA_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[WLAN_VB_WMM_PARAM_COUNT + 1];
	IFX_NAME_VALUE_PAIR *array_changed_fvp = NULL;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_wmm_config", "");

	/*
	   initalize buffer conf_buf which is used for two purposes: - holding the
	   configuration for wlan_ap_wmm to be written to rc.conf - holding the
	   commands for system calls */
	memset(conf_buf, 0x00, sizeof(conf_buf));
	/*
	   initalize buffer array_fvp which is used for storing the new
	   configuration of wlan_ap_wmm in field-value format */
	memset(array_fvp, 0x00, sizeof(array_fvp));

	   /*************** Prolog Block *********************/
	/*
	   based on the operation (ADD or DELETE or MODIFY), the flags variable is
	   appended with internal flags */
	if (operation == IFX_OP_MOD) {
		flags |= IFX_F_MODIFY;
	} else {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_wmm_config", "");
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	}

	   /*************** Validation Block *****************/
	/* Do simple validation of pointer (such as is NULL) */
	IFX_VALIDATE_PTR(wlVbWmm)
	    /* Do simple validation of flags such as less than 0 */
	    IFX_VALIDATE_FLAGS(flags)

	   /*************** ID Allocation Block - Only for ADD Operation **************/
	   /**************** Name Value Formation as per RC.CONF ********************/
	    /*
	       form the field-value pairs(FVP) from the given structure for
	       ADD/MODIFY Operations */
	    count = 0;

	/*
	   the buffer array_fvp is filled in a first step with the field names of
	   wlan_sta_wmm object */
	ifx_fill_ArrayFvp_FName(array_fvp, count, WLAN_VB_WMM_PARAM_COUNT,
				wlan_vb_wmm_params);

	for (i = 0; i < IFX_MAPI_WLAN_WMM_NUM_AC; i++) {
		sprintf(array_fvp[5 * i].value, "%d", (wlVbWmm + i)->ECWmin);
		sprintf(array_fvp[(5 * i) + 1].value, "%d",
			(wlVbWmm + i)->ECWmax);
		sprintf(array_fvp[(5 * i) + 2].value, "%d",
			(wlVbWmm + i)->AIFSN);
		sprintf(array_fvp[(5 * i) + 3].value, "%d",
			(wlVbWmm + i)->TXOP);
		sprintf(array_fvp[(5 * i) + 4].value, "%d",
			(wlVbWmm + i)->ackPolicyEna);
	}

	/* store number of parameters for wlan_sta_wmm object in count */
	count = WLAN_VB_WMM_PARAM_COUNT;

	for (i = 0; i < WLAN_VB_WMM_PARAM_COUNT; i++)
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_wmm_config",
			       "name: %s, value: %s",
			       array_fvp[i].fieldname, array_fvp[i].value);

	   /*************** System Config File Update Block ****************/
	/*
	   convert the name value pair in array_fvp into string format expected by
	   rc.conf file */
	if ((ret = form_cfgdb_buf(conf_buf, count, array_fvp)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_wmm_config", "");
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_wmm_config",
		       "conf_buf: %s", conf_buf);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_VB_WLAN_WMM, flags, 1, conf_buf);
	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_wmm_config", "");
		goto LTQ_Handler;
	}

	   /**************** Device Configuration Block *********************/
	/*
	   Device config thru Scripts/Utilities or Functions after config file
	   update, for modify operation start script for applying the changes */
	passed_index = 0;
	sprintf(conf_buf, "%s %d", SERVICE_VB_WMM_CONFIG, passed_index);
	system(conf_buf);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_wmm_config",
		       "conf_buf: %s", conf_buf);

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_wmm_config",
			       "ret: %d", ret);
		goto LTQ_Handler;
	}

      LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_mapi_set_wlan_vb_wmm_config", "ret: %d",
		       ret);
	IFX_MEM_FREE(array_changed_fvp);
	return ret;
}
#endif				/* #if defined (CONFIG_FEATURE_IFX_WIRELESS) && defined
				   (CONFIG_FEATURE_LTQ_WIRELESS_VB) */
