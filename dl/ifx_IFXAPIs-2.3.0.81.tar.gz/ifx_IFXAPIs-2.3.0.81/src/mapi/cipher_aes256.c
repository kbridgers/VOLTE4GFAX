/*
 * MAPI to encrypt / decrypt a file with aes256 with b64 encoding.
 * Uses Openssl library.
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "ifx_common.h"
#include "ifx_config.h"

#ifdef CONFIG_PACKAGE_LIBOPENSSL

#include <openssl/evp.h>
#include <openssl/aes.h>

#define FPCLOSE(fp) if (fp != NULL) { fclose (fp); fp = NULL; }

static const char cb64[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

static const char cd64[]="|$$$}rstuvwxyz{$$$$$$$>?@ABCDEFGHIJKLMNOPQRSTUVW$$$$$$XYZ[\\]^_`abcdefghijklmnopq";

static void b64_encodeblock( unsigned char *in, unsigned char *out, int len )
{
	out[0] = (unsigned char) cb64[ (int)(in[0] >> 2) ];
	out[1] = (unsigned char) cb64[ (int)(((in[0] & 0x03) << 4) | ((in[1] & 0xf0) >> 4)) ];
	out[2] = (unsigned char) (len > 1 ? cb64[ (int)(((in[1] & 0x0f) << 2) | ((in[2] & 0xc0) >> 6)) ] : '=');
	out[3] = (unsigned char) (len > 2 ? cb64[ (int)(in[2] & 0x3f) ] : '=');
}

static void b64_decodeblock( unsigned char *in, unsigned char *out )
{
	out[0] = (unsigned char ) (in[0] << 2 | in[1] >> 4);
	out[1] = (unsigned char ) (in[1] << 4 | in[2] >> 2);
	out[2] = (unsigned char ) (((in[2] << 6) & 0xc0) | in[3]);
}

static int b64_encode (unsigned char *buf, size_t len, FILE *outfile)
{
	unsigned char in[3];
	unsigned char out[4];
	int i, t;
	size_t j;
	int retcode = 0;

	*in = (unsigned char) 0;
	*out = (unsigned char) 0;

	for (j = 0; j < len; j++) {
		t = 0;
		for( i = 0; i < 3; i++ ) {
			if (j >= len) {
				in[i] = (unsigned char) 0;
			} else {
				in[i] = buf[j];
				t++;
			}
			j++;
		}
		j--;
		b64_encodeblock( in, out, t );
		for( i = 0; i < 4; i++ ) {
			if( putc( (int)(out[i]), outfile ) == 0 ){
				if( ferror( outfile ) != 0 ) {
					fprintf(stderr, "File I/O error\n");
					retcode = 3;
				}
				break;
			}
		}
	}
	return (retcode);
}

static int b64_decode ( FILE *infile, unsigned char *buf, int *outlen )
{
	unsigned char in[4];
	unsigned char out[3];
	int v;
	int i, len;

	*in = (unsigned char) 0;
	*out = (unsigned char) 0;

	*outlen = 0;

	while( feof( infile ) == 0 ) {
		for( len = 0, i = 0; i < 4 && feof( infile ) == 0; i++ ) {
			v = 0;
			while( feof( infile ) == 0 && v == 0 ) {
				v = getc( infile );
				if( v != EOF ) {
					v = ((v < 43 || v > 122) ? 0 : (int) cd64[ v - 43 ]);
					if( v != 0 ) {
						v = ((v == (int)'$') ? 0 : v - 61);
					}
				}
			}
			if( feof( infile ) == 0 ) {
				len++;
				if( v != 0 ) {
					in[ i ] = (unsigned char) (v - 1);
				}
			}
			else {
				in[i] = (unsigned char) 0;
			}
		}
		if( len > 0 ) {
			b64_decodeblock( in, out );
			for( i = 0; i < len - 1; i++ ) {
				*buf++ = out[i];
				*outlen+=1;
			}
		}
	}
	return (0);
}

static int aes_init(unsigned char *key_data, int key_data_len, unsigned char *salt, EVP_CIPHER_CTX *e_ctx, EVP_CIPHER_CTX *d_ctx)
{
	int i, nrounds = 5;
	unsigned char key[32], iv[32];

	i = EVP_BytesToKey(EVP_aes_256_cbc(), EVP_sha1(), salt, key_data, key_data_len, nrounds, key, iv);
	if (i != 32) {
		fprintf(stderr, "Key size is %d bits - should be 256 bits\n", i);
		return -1;
	}

	if (e_ctx != NULL) {
		EVP_CIPHER_CTX_init(e_ctx);
		EVP_EncryptInit_ex(e_ctx, EVP_aes_256_cbc(), NULL, key, iv);
	}

	if (d_ctx !=  NULL) {
		EVP_CIPHER_CTX_init(d_ctx);
		EVP_DecryptInit_ex(d_ctx, EVP_aes_256_cbc(), NULL, key, iv);
	}

	return 0;
}

static int aes_encrypt(unsigned char **ciphertext, EVP_CIPHER_CTX *e, unsigned char *plaintext, int *len)
{
	int c_len = *len + AES_BLOCK_SIZE, f_len = 0, ret = 0;

	IFX_MEM_ALLOC (*ciphertext, unsigned char *, 1, c_len);

	MEMSET (*ciphertext, c_len);

	ret = EVP_EncryptInit_ex(e, NULL, NULL, NULL, NULL);
	if (ret) ret = EVP_EncryptUpdate(e, *ciphertext, &c_len, plaintext, *len);
	if (ret) ret = EVP_EncryptFinal_ex(e, *ciphertext + c_len, &f_len);
	if (ret) *len = c_len + f_len;

IFX_Handler:
	return (ret);
}

static int aes_decrypt(unsigned char **plaintext, EVP_CIPHER_CTX *e, unsigned char *ciphertext, int *len)
{
	int p_len = *len, f_len = 0, ret = 0;

	IFX_MEM_ALLOC (*plaintext, unsigned char *, 1, p_len + AES_BLOCK_SIZE);

	MEMSET (*plaintext, p_len + AES_BLOCK_SIZE);

	ret = EVP_DecryptInit_ex(e, NULL, NULL, NULL, NULL);
	if (ret) ret = EVP_DecryptUpdate(e, *plaintext, &p_len, ciphertext, *len);
	if (ret) ret = EVP_DecryptFinal_ex(e, *plaintext + p_len, &f_len);
	if (ret) *len = p_len + f_len;

IFX_Handler:
	return (ret);
}

/*
 * Function: ltq_file_encrypt_aes256
 * Description: This function encrypts an input file and copy in output file using AES256 crypto and base64 encoding
 *              with a Key. If Key is provided NULL, then it just does base64 encoding alone.
 * Arguments: Key (string), Input file to read (string) and Output file to write (string).
 */
int ltq_file_encrypt_aes256 (char *key, char *inp_file, char *out_file)
{
	FILE *inpfp = NULL, *outfp = NULL;
	unsigned char *ciphertext = NULL, *key_data = NULL, *buf = NULL, cipher_init = 0;
	int fsize = 0, res = 0, key_data_len = 0, ret = IFX_SUCCESS;
	unsigned int salt[] = {12345, 54321};

	EVP_CIPHER_CTX en;

	inpfp = fopen (inp_file, "rb");
	if (inpfp == NULL) {
		IFX_DBG ("ltq_file_encrypt_aes256: Unable to open file %s for reading\n", inp_file);
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	outfp = fopen (out_file, "wb");
	if (outfp == NULL) {
		IFX_DBG ("ltq_file_encrypt_aes256: Unable to open file %s for writing\n", out_file);
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	fseek (inpfp, 0 , SEEK_END);
	fsize = ftell (inpfp);
	rewind (inpfp);

	IFX_MEM_ALLOC (buf, unsigned char *, 1, sizeof(unsigned char) * fsize);

	MEMSET (buf, fsize);
	res = fread ((char *)buf, sizeof(unsigned char), fsize, inpfp);
	if (res != fsize) {
		IFX_DBG ("ltq_file_encrypt_aes256: Unable to read from file %s\n", inp_file);
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	FPCLOSE (inpfp);

	if(key != NULL) {
		key_data = (unsigned char *)key;
		key_data_len = strlen(key);

		if (aes_init(key_data, key_data_len, (unsigned char *)&salt, &en, NULL)) {
			IFX_DBG ("ltq_file_encrypt_aes256: Couldn't initialize AES cipher\n");
			ret = IFX_FAILURE;
			goto IFX_Handler;
		} else cipher_init = 1;

		if (aes_encrypt(&ciphertext, &en, buf, &fsize) != 1) {
			IFX_DBG ("ltq_file_encrypt_aes256: Unable to encrypt the file: %s\n", inp_file);
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	} else {
		/* We donot use aes256 crypt if key is NULL */
		ciphertext = buf;
	}
	
	b64_encode (ciphertext, (unsigned int)fsize, outfp);

IFX_Handler:
	FPCLOSE (inpfp);
	FPCLOSE (outfp);

	IFX_MEM_FREE (buf);

	if(key != NULL) {
		IFX_MEM_FREE (ciphertext);
		if (cipher_init) EVP_CIPHER_CTX_cleanup(&en);
	}

	if (ret != IFX_SUCCESS)
		unlink (out_file);

	return (ret);
}

/*
 * Function: ltq_file_decrypt_aes256
 * Description: This function decrypts an input file which is encrypted with AES256 crypto and base64 encoding
 *              with a Key. If Key is provided NULL, then it just does base64 decoding alone.
 * Arguments: Key (string), Input file to read (string) and Output file to write (string).
 */
int ltq_file_decrypt_aes256 (char *key, char *inp_file, char *out_file)
{
	FILE *inpfp = NULL, *outfp = NULL;
	unsigned char *key_data = NULL, *plaintext = NULL, *buf = NULL, cipher_init = 0;
	int fsize = 0, res = 0, key_data_len = 0, ret = IFX_SUCCESS;
	unsigned int salt[] = {12345, 54321};

	EVP_CIPHER_CTX de;

	inpfp = fopen (inp_file, "rb");
	if (inpfp == NULL) {
		IFX_DBG ("ltq_file_decrypt_aes256: Unable to open file %s for reading\n", inp_file);
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	outfp = fopen (out_file, "wb");
	if (outfp == NULL) {
		IFX_DBG ("ltq_file_decrypt_aes256: Unable to open file %s for writing\n", out_file);
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	fseek (inpfp, 0 , SEEK_END);
	fsize = ftell (inpfp);
	rewind (inpfp);

	IFX_MEM_ALLOC (buf, unsigned char *, 1, (sizeof(unsigned char) * fsize));

	MEMSET (buf, fsize);

	b64_decode (inpfp, buf, &fsize);

	FPCLOSE (inpfp);

	buf[fsize]='\0';

	if (key != NULL) {
		key_data = (unsigned char *)key;
		key_data_len = strlen(key);

		if (aes_init(key_data, key_data_len, (unsigned char *)&salt, NULL, &de)) {
			IFX_DBG ("ltq_file_decrypt_aes256: Couldn't initialize AES cipher\n");
			ret = IFX_FAILURE;
			goto IFX_Handler;
		} else cipher_init = 1;

		if (aes_decrypt(&plaintext, &de, (unsigned char *)buf, &fsize) != 1) {
			IFX_DBG ("ltq_file_decrypt_aes256: Unable to decrypt the file: %s. Encrypted file is corrupt?\n", inp_file);
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	} else {
		/* We donot use aes256 crypt if key is NULL */
		plaintext = buf;
	}

	res = 0;
	res = fwrite(plaintext, sizeof(unsigned char), fsize, outfp);
	if (res != fsize) {
		IFX_DBG ("ltq_file_decrypt_aes256: Unable to write to file %s\n", out_file);
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}


IFX_Handler:
	FPCLOSE (inpfp);
	FPCLOSE (outfp);

	IFX_MEM_FREE (buf);

	if (key != NULL) {
		IFX_MEM_FREE (plaintext);
		if (cipher_init) EVP_CIPHER_CTX_cleanup(&de);
	}

	if (ret != IFX_SUCCESS)
		unlink (out_file);

	return (ret);
}

#endif /* CONFIG_PACKAGE_LIBOPENSSL */

/*
 * EXAMPLES:-
 * ltq_file_encrypt_aes256 ("1234", "rc.conf.gz", "rc.conf.gz.enc");
 * ltq_file_decrypt_aes256 ("1234", "rc.conf.gz.enc", "rc.conf.dec.gz");
 *
 */

