
#include <stdio.h>
#include <string.h>
#include <syslog.h>
#include <stdlib.h>
#include <sys/time.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"

typedef struct {
	int32 idx;
	int32 timeOffset;
} TIME_OFFSET_MAP;

TIME_OFFSET_MAP TimeOffset_Map[] = {
	{0, -720},
	{1, -660},
	{2, -600},
	{3, -540},
	{4, -480},
	{5, -420},
	{6, -420},
	{7, -360},
	{8, -360},
	{9, -360},
	{10, -360},
	{11, -300},
	{12, -300},
	{13, -300},
	{14, -240},
	{15, -240},
	{16, -240},
	{17, -210},
	{18, -180},
	{19, -180},
	{20, -180},
	{21, -120},
	{22, -60},
	{23, -60},
	{24, -0},
	{25, -0},
	{26, 60},
	{27, 60},
	{28, 60},
	{29, 60},
	{30, 60},
	{31, 120},
	{32, 120},
	{33, 120},
	{34, 120},
	{35, 120},
	{36, 120},
	{37, 180},
	{38, 180},
	{39, 180},
	{40, 180},
	{41, 210},
	{42, 240},
	{43, 240},
	{44, 270},
	{45, 300},
	{46, 300},
	{47, 330},
	{48, 345},
	{49, 360},
	{50, 360},
	{51, 360},
	{52, 390},
	{53, 420},
	{54, 420},
	{55, 480},
	{56, 480},
	{57, 480},
	{58, 480},
	{59, 480},
	{60, 540},
	{61, 540},
	{62, 540},
	{63, 570},
	{64, 540},
	{65, 600},
	{66, 600},
	{67, 600},
	{68, 600},
	{69, 600},
	{70, 660},
	{71, 720},
	{72, 720},
	{73, 780}
};

int32 ifx_set_ntp_client_cfg(int32 operation, NTP_CLIENT_CFG * ntpC,
			     uint32 flags)
{
	int32 count = 0, ret = IFX_SUCCESS, nIndex = 0;
	uint32 changed_fcount = 0;
	char8 buf[MAX_DATA_LEN];
	IFX_ID iid;
	IFX_NAME_VALUE_PAIR array_fvp[MAX_FIELD_RANGE], *array_changed_fvp =
	    NULL;

	memset(buf, 0, sizeof(buf));
	memset(&iid, 0, sizeof(iid));
	memset(array_fvp, 0, sizeof(array_fvp));

    /***  PROLOG BLOCK  ***/

	/* Append internal flags */
	if (operation == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_MOD)
		flags |= IFX_F_MODIFY;
	else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
		flags |= IFX_F_INT_ADD;

    /********  VALIDATION BLOCK  ***********/
	/* For ops other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags)) {
	/*** Validation Checking Block ***/
		if (IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
			/* Do simple validation of pointer such as NULL */
			IFX_VALIDATE_PTR(ntpC)
			    /* Do simple validation of flags such as less than 0 */
			    IFX_VALIDATE_FLAGS(flags)
		}
	}

    /*******  VALIDATION BLOCK END *********/

	/* Read the iid structure from rc.conf */
	iid = ntpC->iid;
	if (ifx_get_iid_from_conf(&iid, FILE_RC_CONF, TAG_TIME_SECTION) !=
	    IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	sprintf(iid.cpeId.secName, "%s", TAG_TIME_SECTION);
	sprintf(iid.pcpeId.secName, "%s", TAG_TIME_SECTION);

    /*********** Name Value Formation As Per RC.CONF ****************/
	/* Build the API Specific name value pair */
	sprintf(array_fvp[0].fieldname, "%s_%s", TAG_TIME_SECTION, "cpeId");
	sprintf(array_fvp[0].value, "%d", iid.cpeId.Id);
	sprintf(array_fvp[1].fieldname, "%s_%s", TAG_TIME_SECTION, "pcpeId");
	sprintf(array_fvp[1].value, "%d", iid.pcpeId.Id);
	sprintf(array_fvp[2].fieldname, "%s_%s", TAG_TIME_SECTION,
		IFX_TIME_NTPENABLE);
	sprintf(array_fvp[2].value, "%d", ntpC->f_enable);
	sprintf(array_fvp[3].fieldname, "%s_%s", TAG_TIME_SECTION,
		IFX_TIME_NTPSERVER1);
	sprintf(array_fvp[3].value, "%s", ntpC->ntpServer1);
	sprintf(array_fvp[4].fieldname, "%s_%s", TAG_TIME_SECTION,
		IFX_TIME_NTPSERVER2);
	sprintf(array_fvp[4].value, "%s", ntpC->ntpServer2);
	sprintf(array_fvp[5].fieldname, "%s_%s", TAG_TIME_SECTION,
		IFX_TIME_NTPSERVER3);
	sprintf(array_fvp[5].value, "%s", ntpC->ntpServer3);
	sprintf(array_fvp[6].fieldname, "%s_%s", TAG_TIME_SECTION,
		IFX_TIME_NTPSERVER4);
	sprintf(array_fvp[6].value, "%s", ntpC->ntpServer4);
	sprintf(array_fvp[7].fieldname, "%s_%s", TAG_TIME_SECTION,
		IFX_TIME_NTPSERVER5);
	sprintf(array_fvp[7].value, "%s", ntpC->ntpServer5);

	sprintf(array_fvp[8].fieldname, "%s_%s", TAG_TIME_SECTION,
		IFX_TIME_LOCALTIMEZONE);
	sprintf(array_fvp[8].value, "%d", ntpC->timeMinutesOffset);
	sprintf(array_fvp[9].fieldname, "%s_%s", TAG_TIME_SECTION,
		IFX_TIME_LOCALTIMEZONENAME);
	sprintf(array_fvp[9].value, "%s", ntpC->tzName);
	/* if ntpC->timeZoneIdx is 0 then get the index from offset
	   offsets may not be unique, still get the first match to index */
	sprintf(array_fvp[10].fieldname, "%s_%s", TAG_TIME_SECTION,
		IFX_TIME_LOCALTIMEZONEINDEX);
	if (ntpC->timeZoneIdx != 0) {
		sprintf(array_fvp[10].value, "%d", ntpC->timeZoneIdx);
	} else {
		for (nIndex = 0;
		     nIndex < sizeof(TimeOffset_Map) / sizeof(TIME_OFFSET_MAP);
		     nIndex++) {
			if (TimeOffset_Map[nIndex].timeOffset ==
			    ntpC->timeMinutesOffset) {
				sprintf(array_fvp[10].value, "%d",
					TimeOffset_Map[nIndex].idx);
				break;
			}
		}
	}
	sprintf(array_fvp[11].fieldname, "%s_%s", TAG_TIME_SECTION,"status");
        sprintf(array_fvp[11].value, "%s", "0");
	
	count = 12;

    /***  PROLOG BLOCK END  ***/

    /**************** ACL CHECK BLOCK *****************/

	CHECK_ACL_RET(iid, count, array_fvp,
		      changed_fcount, array_changed_fvp, flags, IFX_Handler)

    /**************** ACL CHECK BLOCK END *****************/
    /********* SYSTEM CONFIG FILE UPDATE BLOCK  **********/
	    /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	    if (IFX_MODIFY_F_SET(flags)) {
		//form_cfgdb_buf(buf, changed_fcount, array_changed_fvp);
		form_cfgdb_buf(buf, count, array_fvp);
	} else {
		form_cfgdb_buf(buf, count, array_fvp);
	}

	/* Backup rc.conf before proceeding with configuration */
	CHECKPOINT_RET(flags, FILE_RC_CONF, CHKPOINT_FILE, IFX_Handler)

	    /* Update rc.conf */
	    ret = ifx_SetObjData(FILE_RC_CONF, TAG_TIME_SECTION, flags, 1, buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
	if (ret != IFX_SUCCESS) {
		ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE,
				    flags | IFX_F_INT_DONT_RESTART_SERVICES,
				    IFX_Handler)
	}

    /********* SYSTEM CONFIG FILE UPDATE BLOCK END **********/

    /************ DEVICE CONFIGURATION BLOCK ***********/
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
		system("/etc/rc.d/init.d/ntpc restart");
	}
    /************ DEVICE CONFIGURATION BLOCK END ***********/

    /**************** NOTIFICATION BLOCK ******************/

	/* Notify the Internal TR69 Stack */
	CHECK_N_SEND_NOTIFICATION(iid, changed_fcount, array_changed_fvp, flags,
				  IFX_Handler)

    /**************** NOTIFICATION BLOCK ******************/
    /***************** EPILOG BLOCK **********************/
	    ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
		ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE,
				    flags | IFX_F_INT_DONT_RESTART_SERVICES,
				    IFX_Handler)
	}
    /***************** EPILOG BLOCK END **********************/

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

int32 ifx_get_ntp_client_cfg(NTP_CLIENT_CFG * ntpC, uint32 flags)
{
	int32 iRtn = IFX_SUCCESS;
	char8 sVal[MAX_FILELINE_LEN];
	uint32 ulOutFlag;
	NTP_CLIENT_CFG xNTPC;
	struct timeval tv;
	memset(&tv, 0, sizeof(tv));
	memset(&xNTPC, 0, sizeof(NTP_CLIENT_CFG));

	memset(sVal, 0x00, sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, TAG_TIME_SECTION,
				   TAG_TIME_SECTION "_" IFX_TIME_NTPENABLE,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get NTPServer1 !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}
	xNTPC.f_enable = atoi(sVal);

	memset(sVal, 0x00, sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, TAG_TIME_SECTION,
				   TAG_TIME_SECTION "_" IFX_TIME_NTPSERVER1,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get NTPServer1 !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_NTP_SERVER_LEN) {
		iRtn = IFX_FAILURE;
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> NTPServer1 len not fitting in buffer!!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xNTPC.ntpServer1, sVal, MAX_NTP_SERVER_LEN);

	memset(sVal, 0x00, sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, TAG_TIME_SECTION,
				   TAG_TIME_SECTION "_" IFX_TIME_NTPSERVER2,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get NTPServer2 !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_NTP_SERVER_LEN) {
		iRtn = IFX_FAILURE;
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> NTPServer2 len not fitting in buffer!!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xNTPC.ntpServer2, sVal, MAX_NTP_SERVER_LEN);
	
		memset(sVal, 0x00, sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, TAG_TIME_SECTION,
				   TAG_TIME_SECTION "_" IFX_TIME_NTPSERVER3,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get NTPServer3 !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_NTP_SERVER_LEN) {
		iRtn = IFX_FAILURE;
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> NTPServer3 len not fitting in buffer!!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xNTPC.ntpServer3, sVal, MAX_NTP_SERVER_LEN);

	memset(sVal, 0x00, sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, TAG_TIME_SECTION,
				   TAG_TIME_SECTION "_" IFX_TIME_NTPSERVER4,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get NTPServer4 !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_NTP_SERVER_LEN) {
		iRtn = IFX_FAILURE;
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> NTPServer4 len not fitting in buffer!!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xNTPC.ntpServer4, sVal, MAX_NTP_SERVER_LEN);

	memset(sVal, 0x00, sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, TAG_TIME_SECTION,
				   TAG_TIME_SECTION "_" IFX_TIME_NTPSERVER5,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get NTPServer5 !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_NTP_SERVER_LEN) {
		iRtn = IFX_FAILURE;
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> NTPServer5 len not fitting in buffer!!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xNTPC.ntpServer5, sVal, MAX_NTP_SERVER_LEN);

	gettimeofday(&tv, NULL);
	xNTPC.currentLocalTime = (time_t) tv.tv_sec;

	memset(sVal, 0x00, sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, TAG_TIME_SECTION,
				   TAG_TIME_SECTION "_" IFX_TIME_LOCALTIMEZONE,
				   flags, &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get LocalTimeZone !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}
	xNTPC.timeMinutesOffset = atoi(sVal);

	memset(sVal, 0x00, sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, TAG_TIME_SECTION,
				   TAG_TIME_SECTION "_"
				   IFX_TIME_LOCALTIMEZONENAME, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get LocalTimeZoneName !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_TIME_ZONE_NAME_LEN) {
		iRtn = IFX_FAILURE;
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> LocalTimeZoneName len not fitting in buffer!!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}
	LTQ_STRNCPY(xNTPC.tzName, sVal, MAX_TIME_ZONE_NAME_LEN);

	memset(sVal, 0x00, sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, TAG_TIME_SECTION,
				   TAG_TIME_SECTION "_"
				   IFX_TIME_LOCALTIMEZONEINDEX, flags,
				   &ulOutFlag, sVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get NTPServer1 !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}
	xNTPC.timeZoneIdx = atoi(sVal);

 	memset(sVal, 0x00, sizeof(sVal));
	if((ifx_GetObjDataOpt(FILE_SYSTEM_STATUS, "ntp_status", "STATUS", flags, (IFX_OUT uint32 *) &ulOutFlag, sVal)) != IFX_SUCCESS) {
                #ifdef IFX_LOG_DEBUG
                        IFX_DBG("\nIn Function [%s] : ntp_status not found !!\n",__FUNCTION__);
                #endif
                }
	xNTPC.status = atoi(sVal);

	/* Fill the structure to be returned to the user */
	ntpC->f_enable = xNTPC.f_enable;
	LTQ_STRNCPY(ntpC->ntpServer1, xNTPC.ntpServer1, MAX_NTP_SERVER_LEN);
	LTQ_STRNCPY(ntpC->ntpServer2, xNTPC.ntpServer2, MAX_NTP_SERVER_LEN);
	LTQ_STRNCPY(ntpC->ntpServer3, xNTPC.ntpServer3, MAX_NTP_SERVER_LEN);
	LTQ_STRNCPY(ntpC->ntpServer4, xNTPC.ntpServer4, MAX_NTP_SERVER_LEN);
	LTQ_STRNCPY(ntpC->ntpServer5, xNTPC.ntpServer5, MAX_NTP_SERVER_LEN);
	
	ntpC->currentLocalTime = xNTPC.currentLocalTime;
	ntpC->timeMinutesOffset = xNTPC.timeMinutesOffset;
	LTQ_STRNCPY(ntpC->tzName, xNTPC.tzName, MAX_TIME_ZONE_NAME_LEN);
	ntpC->timeZoneIdx = xNTPC.timeZoneIdx;
	ntpC->status = xNTPC.status;

      IFX_Handler:
	if (iRtn != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return (iRtn);
	} else
		return IFX_SUCCESS;
}
