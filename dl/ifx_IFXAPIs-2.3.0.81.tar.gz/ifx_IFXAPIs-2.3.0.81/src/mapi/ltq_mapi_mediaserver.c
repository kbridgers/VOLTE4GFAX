/* Copyright (c) 2010, Lantiq Communications
 *
 *  Management API's for Media Server
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <syslog.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"

#ifdef CONFIG_FEATURE_MEDIA_SERVER

char8 *media_loc_param_names[] = { "cpeId", "pcpeId", "type", "path" };

#define LTQ_MEDIALIST_PARAM_COUNT	4

int32 ltq_mediaserver_start()
{
	system(SERVICE_MEDIASERVER_START);
	return 0;
}

int32 ltq_mediaserver_stop()
{
	system(SERVICE_MEDIASERVER_STOP);
	return 0;
}

int32 ltq_mediaserver_restart()
{
	return (system(SERVICE_MEDIASERVER_RESTART));
}

int32 ltq_get_mediaserver(LTQ_MAPI_MediaServer * medSrvr, uint32 flags)
{
	int32 ret = IFX_SUCCESS;
	char8 sValue[MAX_NAME_SIZE], buf[MAX_FILELINE_LEN];
	int32 outflag = IFX_F_DEFAULT;

	/* Get the Media Server Details from rc.conf */
	sprintf(buf, "ms_0_name");
	if (ifx_GetObjData(FILE_RC_CONF, TAG_MEDIA_SERVER, buf, IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	strcpy(medSrvr->mediaServerName, sValue);

	sprintf(buf, "ms_0_ena");
	if (ifx_GetObjData(FILE_RC_CONF, TAG_MEDIA_SERVER, buf, IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	medSrvr->msEna = atoi(sValue);

	sprintf(buf, "ms_0_extDb");
	if (ifx_GetObjData(FILE_RC_CONF, TAG_MEDIA_SERVER, buf, IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	medSrvr->extDBloc = atoi(sValue);

	sprintf(buf, "ms_0_extDbPath");
	if (ifx_GetObjData(FILE_RC_CONF, TAG_MEDIA_SERVER, buf, IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	strcpy(medSrvr->extDBpath, sValue);

	sprintf(buf, "ms_0_scanStart");
	if (ifx_GetObjData(FILE_RC_CONF, TAG_MEDIA_SERVER, buf, IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outflag,
			   sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	medSrvr->scanAtStart = atoi(sValue);

      IFX_Handler:
	if (ret != IFX_SUCCESS)
		IFX_API_LOG("g6 [%s] returned failure!", __FUNCTION__);

	return ret;
}

int32 ltq_set_mediaserver(uint32 oper, LTQ_MAPI_MediaServer * medSrvr,
			  uint32 flags)
{
	int32 ret = IFX_SUCCESS;
	char8 buf[MAX_FILELINE_LEN * 3];
	IFX_NAME_VALUE_PAIR array_fvp[LTQ_MEDIASERVER_PARAM_COUNT],
	    *array_changed_fvp = NULL;
	uint32 count = LTQ_MEDIASERVER_PARAM_COUNT;
	LTQ_MAPI_MediaServer t_medSrvr;

	NULL_TERMINATE(buf, 0, sizeof(buf));
	memset(array_fvp, 0, sizeof(array_fvp));

	/* Based on operation (ADD or DELETE or MODIFY)
	 * append the flag with internal flags */
	if ((oper == IFX_OP_DEL) || (oper == IFX_OP_ADD)) {
		flags |= IFX_F_MODIFY;
	} else
		flags |= IFX_F_MODIFY;

	medSrvr->iid.cpeId.Id = 1;
	medSrvr->iid.pcpeId.Id = 1;
	strcpy(medSrvr->iid.cpeId.secName, TAG_MEDIA_SERVER);
	strcpy(medSrvr->iid.pcpeId.secName, TAG_IGD);

	if ((!medSrvr->msEna) || (!medSrvr->extDBloc)) {
		ret = ltq_get_mediaserver(&t_medSrvr, IFX_F_GET_ANY);
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	sprintf(array_fvp[0].fieldname, "ms_0_cpeId");
	sprintf(array_fvp[0].value, "1");
	sprintf(array_fvp[1].fieldname, "ms_0_pcpeId");
	sprintf(array_fvp[1].value, "1");
	if (medSrvr->msEna) {
		sprintf(array_fvp[2].fieldname, "ms_0_name");
		sprintf(array_fvp[2].value, "%s", medSrvr->mediaServerName);
		sprintf(array_fvp[3].fieldname, "ms_0_ena");
		sprintf(array_fvp[3].value, "%d", medSrvr->msEna);
		if (medSrvr->extDBloc) {
			sprintf(array_fvp[4].fieldname, "ms_0_extDb");
			sprintf(array_fvp[4].value, "%d", medSrvr->extDBloc);
			sprintf(array_fvp[5].fieldname, "ms_0_extDbPath");
			sprintf(array_fvp[5].value, "%s", medSrvr->extDBpath);
		} else {
			sprintf(array_fvp[4].fieldname, "ms_0_extDb");
			sprintf(array_fvp[4].value, "%d", 0);
			sprintf(array_fvp[5].fieldname, "ms_0_extDbPath");
			sprintf(array_fvp[5].value, "%s", t_medSrvr.extDBpath);
		}
		sprintf(array_fvp[6].fieldname, "ms_0_scanStart");
		sprintf(array_fvp[6].value, "%d", medSrvr->scanAtStart);
	} else {
		sprintf(array_fvp[2].fieldname, "ms_0_name");
		sprintf(array_fvp[2].value, "%s", t_medSrvr.mediaServerName);
		sprintf(array_fvp[3].fieldname, "ms_0_ena");
		sprintf(array_fvp[3].value, "%d", 0);
		sprintf(array_fvp[4].fieldname, "ms_0_extDb");
		sprintf(array_fvp[4].value, "%d", t_medSrvr.extDBloc);
		sprintf(array_fvp[5].fieldname, "ms_0_extDbPath");
		sprintf(array_fvp[5].value, "%s", t_medSrvr.extDBpath);
		sprintf(array_fvp[6].fieldname, "ms_0_scanStart");
		sprintf(array_fvp[6].value, "%d", t_medSrvr.scanAtStart);
	}

	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(buf, count, array_fvp);

	/********* System Config File Update Block  **********/
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_MEDIA_SERVER, flags, 1, buf);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	//ltq_mediaserver_stop();
	ltq_mediaserver_restart();

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	    if (ret != IFX_SUCCESS)
		IFX_API_LOG("s3 [%s] returned failure!", __FUNCTION__);

	return ret;
}

int32 ltq_get_all_media_location_entries(uint32 * numMeds,
					 LTQ_MAPI_Media_Location **
					 medLocEntries, uint32 flags)
{
	int32 ret = IFX_SUCCESS, nCount = 0, i = 0;
	char8 sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN];
	uint32 outFlag = IFX_F_DEFAULT;

	/* get the count first */
	MAKE_SECTION_COUNT_TAG(TAG_MEDIA_LOCATIONS, buf);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_MEDIA_LOCATIONS,
				  buf, flags, &outFlag,
				  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	nCount = atoi(sValue);
	if (nCount == 0) {
		*numMeds = 0;
		*medLocEntries = NULL;
		goto IFX_Handler;
	}

	*medLocEntries = NULL;
	IFX_MEM_ALLOC((*medLocEntries), LTQ_MAPI_Media_Location *, nCount,
		      sizeof(LTQ_MAPI_Media_Location))

	    for (i = 0; i < nCount; i++) {
		/*  Get each instance from the rc.conf file */
		sprintf(buf, "%s_%d_cpeId", PREFIX_MEDIA_LOCATIONS, i);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_MEDIA_LOCATIONS,
					  buf, IFX_F_GET_ANY, &outFlag,
					  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		(*medLocEntries + i)->iid.cpeId.Id = atoi(sValue);
		sprintf((*medLocEntries + i)->iid.cpeId.secName, "%s",
			TAG_MEDIA_LOCATIONS);

		sprintf(buf, "%s_%d_pcpeId", PREFIX_MEDIA_LOCATIONS, i);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_MEDIA_LOCATIONS,
					  buf, IFX_F_GET_ANY, &outFlag,
					  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		(*medLocEntries + i)->iid.pcpeId.Id = atoi(sValue);
		sprintf((*medLocEntries + i)->iid.pcpeId.secName, "%s",
			TAG_MEDIA_LOCATIONS);

		sprintf(buf, "%s_%d_type", PREFIX_MEDIA_LOCATIONS, i);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_MEDIA_LOCATIONS,
					  buf, IFX_F_GET_ANY, &outFlag,
					  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		(*medLocEntries + i)->mediaType = atoi(sValue);

		sprintf(buf, "%s_%d_path", PREFIX_MEDIA_LOCATIONS, i);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_MEDIA_LOCATIONS,
					  buf, IFX_F_GET_ANY, &outFlag,
					  sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		sprintf((*medLocEntries + i)->mediaPath, "%s", sValue);
	}
	*numMeds = nCount;

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("ga6 [%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

int32 ltq_set_media_location(uint32 oper, LTQ_MAPI_Media_Location * medLoc,
			     uint32 flags)
{
	char8 conf_buf[MAX_DATA_LEN];
	int32 ret = IFX_SUCCESS;
	char8 buf[MAX_FILELINE_LEN * 3];
	IFX_NAME_VALUE_PAIR array_fvp[LTQ_MEDIALIST_PARAM_COUNT],
	    *array_changed_fvp = NULL;
	uint32 count = LTQ_MEDIALIST_PARAM_COUNT;
	uint32 outflag = IFX_F_DEFAULT;
	char8 sValue[MAX_FILELINE_LEN];
	int32 passed_index = -1;

	NULL_TERMINATE(buf, 0, sizeof(buf));
	memset(array_fvp, 0, sizeof(array_fvp));
	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));

	/* Based on operation (ADD or DELETE or MODIFY) append the flag with internal flags */
	if (oper == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if ((oper == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
		flags |= IFX_F_INT_ADD;
	else
		flags |= IFX_F_MODIFY;

	/* For Operations other than DELETE do the verification of input params */
	if (IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(medLoc)
		    /* Do simple validation of flags such as less than 0 */
		    IFX_VALIDATE_FLAGS(flags)
	}

	medLoc->iid.pcpeId.Id = 1;
	sprintf(medLoc->iid.cpeId.secName, "%s", TAG_MEDIA_LOCATIONS);
	sprintf(medLoc->iid.pcpeId.secName, "%s", TAG_IGD);

	/**************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_ADD_F_SET(flags)) {
		/* Allocate the IID for this route instance
		 * Set the parent SectionName and parent IID values
		 * to NULL as there is no parent for Route Entity
		 */
		if (ifx_get_IID_Without_TR69(&medLoc->iid, "path") !=
		    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	if (IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, 0, 4, media_loc_param_names);
		sprintf(array_fvp[0].value, "%d", medLoc->iid.cpeId.Id);
		sprintf(array_fvp[1].value, "%d", medLoc->iid.pcpeId.Id);
		sprintf(array_fvp[2].value, "%d", medLoc->mediaType);
		sprintf(array_fvp[3].value, "%s", medLoc->mediaPath);
		passed_index = -1;
	}
	count = LTQ_MEDIALIST_PARAM_COUNT;

	if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, medLoc->iid.cpeId,
					 passed_index)
		    sprintf(buf, "ml_%d_type", passed_index);
		if ((ifx_GetObjData
		     (FILE_RC_CONF, TAG_MEDIA_LOCATIONS, buf, IFX_F_GET_ANY,
		      &outflag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	if (ifx_get_conf_index_and_nv_pairs
	    (&medLoc->iid, passed_index, PREFIX_MEDIA_LOCATIONS, count,
	     array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	form_cfgdb_buf(conf_buf, count, array_fvp);

	ret =
	    ifx_SetObjData(FILE_RC_CONF, TAG_MEDIA_LOCATIONS, flags, 1,
			   conf_buf);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d] for conf_buf [%s] ret [%d]", __FUNCTION__,
			    __LINE__, conf_buf, ret);
#endif
		goto IFX_Handler;
	}

	/* This will Compact the section and also update the count for both ADD and DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_MEDIA_LOCATIONS, flags);

	/* Manipulate nextCpeId only for ADD operations */
	if (IFX_INT_ADD_F_SET(flags)) {
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_MEDIA_LOCATIONS);
	}

	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_API_LOG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	//ltq_mediaserver_stop();
	ltq_mediaserver_restart();

      IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	    if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

#endif				/* CONFIG_FEATURE_MEDIA_SERVER */
