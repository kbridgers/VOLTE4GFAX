/* 
** =============================================================================
**   FILE NAME        : ifx_api_dsl_diag.c
**   PROJECT          : AMAZON MAPI
**   DATE             : 11-May-2007
**   AUTHOR           : Amazon API Team
**   DESCRIPTION      : This file contains the GET/SET functions supported by the MAPI
			framework 

**   REFERENCES       : 
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/

#include <stdio.h>
#include <stdlib.h>
#include <ifx_common.h>
#include <arpa/inet.h>
#include <ifx_emf.h>


#include <fcntl.h>
#include <errno.h>
#include <sys/socket.h>
#include <resolv.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/ip_icmp.h>
#include<strings.h>
#include "ifx_api_util.h"

#include <resolv.h>
#include "ifx_amazon_cfg.h"

#ifdef CONFIG_FEATURE_IFX_WIRELESS
extern IFX_MAPI_WLAN_PhyCfg g_wlPhy[];
#endif

#define PACKETSIZE  64
struct packet
{
    struct icmphdr hdr;
    char msg[PACKETSIZE-sizeof(struct icmphdr)];
};

int pid=-1;
struct protoent *proto=NULL;
int cnt=1;

#define LTQ_CHECK_LANSATUS             0x1
#define LTQ_CHECK_WANSTATUS            0x2
#define LTQ_CHECK_WLANSTATUS           0X4
#define LTQ_CHECK_DSLSTATUS            0x8
#define LTQ_CHECK_LANPING              0x10
#define LTQ_CHECK_WANPING              0x20
#define LTQ_CHECK_DNSPING1             0x40
#define LTQ_CHECK_OAM                  0x80
#define LTQ_CHECK_ALL                  0x100


#define IFX_SELFTEST_DIAG_SECTION                 "selftest_diag"
#define IFX_SELFTEST_DIAG_DIAGSTATE               "diagstate"
#define IFX_SELFTEST_DIAG_WAN                     "wan_status"
#define IFX_SELFTEST_DIAG_LANPING		  "lanping"
#define IFX_SELFTEST_DIAG_LAN0                    "lan0"
#define IFX_SELFTEST_DIAG_LAN1                    "lan1"
#define IFX_SELFTEST_DIAG_LAN2                    "lan2"
#define IFX_SELFTEST_DIAG_LAN3                    "lan3"
#define IFX_SELFTEST_DIAG_GATEWAY_PING            "gatewayping"
#define IFX_SELFTEST_DIAG_PRIMARYDNS              "dns1"
#define IFX_SELFTEST_DIAG_SECONDARYDNS            "dns2"
#define IFX_SELFTEST_DIAG_ENCAPSULATION           "encapsulationtype"
#define IFX_SELFTEST_DIAG_DSLLINKSTATUS		  "dsllink"
#define IFX_SELFTEST_DIAG_WLAN0                   "wlan0"
#define IFX_SELFTEST_DIAG_WLAN1                   "wlan1"
#define IFX_SELFTEST_DIAG_RESULT		  "result"

char8 * selftest_parms[] = {
         "diagstate",
         "wan_status",
         "dsllink",
         "lanping",
         "lan0",
         "lan1",
         "lan2",
         "lan3",
         "gatewayping",
         "dns1",
         "dns2",
         "encapsulationtype",
         "wlan0",
         "wlan1",
         "result"
};

//#define IFX_LOG_DEBUG

#ifdef PLATFORM_VR9
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
#define DSL_CPE_DEVICE_NAME "/dev/dsl_cpe_api"
#else
#define DSL_CPE_DEVICE_NAME "/dev/dsl_cpe_api/0"
#endif
#else
#define DSL_CPE_DEVICE_NAME "/dev/dsl_cpe_api"
#endif


#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
#include <stdarg.h>
#include <time.h>
#include <string.h>
#include <fcntl.h>
#include <sys/sysinfo.h>
#include <sys/ioctl.h>
#include <ifx_config.h>
#include "ifx_snmpdefs.h"
#include "ifx_api_include.h"
#include <drv_dsl_cpe_api.h>
#include <drv_dsl_cpe_api_ioctl.h>
#include <drv_dsl_cpe_api_g997.h>

//#include "ifx_api_dsl_include.h"

#define WRITE_DSL_DIAG_TO_FILE(conf_buf, flags, _ret, _handler) { \
		_ret = ifx_SetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, flags, 1, conf_buf); \
		/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */ \
		if(_ret != IFX_SUCCESS) { \
			sprintf(conf_buf, "%s_diagnosticState=\"%d\"\n", PREFIX_DSL_DIAG, WAN_DIAG_ERROR_EXT); \
			if(ifx_SetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, flags, 1, conf_buf) != IFX_SUCCESS) { \
				_ret = IFX_FAILURE; \
				goto _handler; \
			} \
		} \
	}

#define BRINGDOWN_SERVICES(owner) { \
		if(owner == IFX_TR69) { \
			system("/etc/rc.d/free_memory.sh diag"); \
		} \
		system("/etc/rc.d/rc.bringup_wan stop"); \
		system("/etc/rc.d/killproc inetd"); \
		system("killall -9 oamd syslogd"); \
	}

#ifdef CONFIG_FEATURE_CLIP
#define	CLIP_SERVICE	{ \
		if(CONFIG_FEATURE_CLIP) \
		{ \
				system("/usr/sbin/atmarpd -b -l /dev/null 2> /dev/null"); \
		} \
	}
#else
#define CLIP_SERVICE {}
#endif

#define BRINGUP_SERVICES { \
		/* oam will be restarted when the link comes up, so no need to start manually */ \
		/* system("/etc/rc.d/syslogd start"); start syslogd \ */ \
		system("/sbin/syslogd -s 25 -b 2"); /* since syslogd script is not present */ \
		system("/sbin/klogd &"); \
		system("/etc/rc.d/rc.bringup_lan restart"); /* to start udhcpd or udhcpr */ \
		CLIP_SERVICE; \
		system("/etc/rc.d/init.d/dns_relay start"); \
		system("/etc/rc.d/rc.bringup_services start"); \
		system("/etc/rc.d/rc.bringup_wan start &"); \
	}

int32 ifx_cpe_api_set_dsl_diagnostics(int32 operation,
				      WAN_DSL_DIAGNOSTICS * Wan_Dsl_Diag,
				      uint32 flags)
{
	// char8 buf[MAX_FILELINE_LEN];
	char8 conf_buf[2 * MAX_DATA_LEN];
	int32 count = 0, ret = IFX_SUCCESS, cmd = 0;
	IFX_NAME_VALUE_PAIR array_fvp[20];

	memset(array_fvp, 0x00, sizeof(array_fvp));

	/*************** Prolog Block ****************/
	/* Based on operation (ADD or DEL or MOD) 
	 * append the flag with internal flags. For other ops, 
	 * the flag denotes the action */
	if (operation == IFX_OP_MOD)
		flags |= IFX_F_MODIFY;

	// Check if f_enable is set to enabled
	// and diagnostic_state is WAN_DSL_START_DIAGNOSING
	if ((Wan_Dsl_Diag->f_enable == IFX_ENABLED) &&
	    (Wan_Dsl_Diag->diagnostic_state == WAN_DIAG_START_DIAGNOSING)) {

		// Test Modes 
		DSL_G997_LineActivate_t lineActivateData;
		DSL_AutobootControl_t autobootControl;
		DSL_LineState_t lineState;
		DSL_G997_DeltFreeResources_t DeltFreeResources;
/*
		// DSL Event Status
		DSL_EventStatus_t eventStatus;

		//ACTATP - Actual Aggregrate Transmitted Power 
		DSL_uint32_t DownStreamACTATP;
		DSL_uint32_t UpStreamACTATP;

		//ACTPSD - Actual Power Spectral Density 
		DSL_uint32_t DownStreamACTPS;
		DSL_uint32_t UpStreamACTPS;

		//HLINSC - Linear Representation Scale
		DSL_uint16_t DownStreamDeltHlinScaleData;

		//HLINps - Linear Channel Characteristics
		DSL_G997_ComplexNumber_t DownStreamHLINCmplxData[DSL_MAX_NSC];

		//QLNps - Quiet Line Noise per SubCarrier
		DSL_uint8_t DownStreamQLNNSCData[DSL_MAX_NSC];

		//SNRps - Signal-to-Noise Ratio per SubCarrier
		DSL_uint8_t DownStreamSNRNSCData[DSL_MAX_NSC];

		//BITSps - BIT Allocation per SubCarrier
		DSL_uint8_t DownStreamBITNSCData[DSL_MAX_NSC];

		//GAINSps - GAIN Allocation per SubCarrier
		DSL_uint16_t DownStreamGAINNSCData[DSL_MAX_NSC];
*/

		/*  before starting the diagnostics, kill all the services to free up some space
		   because adsl link going down and dsl diagnostics need contiguous memory space
		   and once the diagnostics is complete restore the system state by restarting all
		   the services that were stopped at the beginning */
		BRINGDOWN_SERVICES(Wan_Dsl_Diag->iid.config_owner)

		    /*  using ioctl  reset the dsl parameter values in dsl_api data structure before
		       starting the diagnostics */
		    // STEP 0: Free the DELT Resources if it is already allocated
		    memset(&DeltFreeResources, 0x00,
			   sizeof(DSL_G997_DeltFreeResources_t));
		cmd = DSL_FIO_G997_DELT_FREE_RESOURCES;
		ret =
		    ifx_cpe_api_device_set_operation(cmd,
						     (void *)&DeltFreeResources,
						     flags);
		if (ret < 0) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n",
				__FUNCTION__, __LINE__);
#endif
			Wan_Dsl_Diag->diagnostic_state = WAN_DIAG_ERROR_EXT;
			goto IFX_Handler;
		} else {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("\n\n In %s: ioctl  passed at line:%d!\n",
				__FUNCTION__, __LINE__);
#endif
		}

		// STEP 1: Configure Line State to Loop-Diagnostic Mode
		memset(&lineActivateData, 0x00,
		       sizeof(DSL_G997_LineActivate_t));
		cmd = DSL_FIO_G997_LINE_ACTIVATE_CONFIG_SET;
		lineActivateData.data.nLDSF = DSL_G997_AUTO_LDSF;
		ret =
		    ifx_cpe_api_device_set_operation(cmd,
						     (void *)&lineActivateData,
						     flags);
		if (ret < 0) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n",
				__FUNCTION__, __LINE__);
#endif
			Wan_Dsl_Diag->diagnostic_state = WAN_DIAG_ERROR_EXT;
			goto IFX_Handler;
		} else {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("\n\n In %s: ioctl  passed at line:%d!\n",
				__FUNCTION__, __LINE__);
#endif
		}

		// STEP 2: Restart Auto-boot daemon thread
		memset(&autobootControl, 0x00, sizeof(DSL_AutobootControl_t));
		cmd = DSL_FIO_AUTOBOOT_CONTROL_SET;
		autobootControl.data.nCommand = DSL_AUTOBOOT_CTRL_RESTART;
		ret =
		    ifx_cpe_api_device_set_operation(cmd,
						     (void *)&autobootControl,
						     flags);
		if (ret < 0) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n",
				__FUNCTION__, __LINE__);
#endif
			Wan_Dsl_Diag->diagnostic_state = WAN_DIAG_ERROR_EXT;
			goto IFX_Handler;
		} else {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("\n\n In %s: ioctl  passed at line:%d!\n",
				__FUNCTION__, __LINE__);
#endif
		}

		/* wait for some time till autoboot daemon restarts */
		sleep(3);

		// STEP 3: Check for the Event DSL_LOOP_DIAGNOSTIC_COMPLETE
		memset(&lineState, 0x00, sizeof(DSL_LineState_t));
		cmd = DSL_FIO_LINE_STATE_GET;
		ret =
		    ifx_cpe_api_device_get_operation(cmd, (void *)&lineState,
						     flags);
		if (ret < 0) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n",
				__FUNCTION__, __LINE__);
#endif
			Wan_Dsl_Diag->diagnostic_state = WAN_DIAG_ERROR_EXT;
			//goto IFX_Handler;
		} else {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("\n\n In %s: ioctl  passed at line:%d!\n",
				__FUNCTION__, __LINE__);
#endif
		}

		/* Loop till the Event Type is LINE_STATE & Status is DSL_LINESTATE_LOOPDIAGNOSTIC_COMPLETE */
		while (1) {
			if ((lineState.data.nLineState ==
			     DSL_LINESTATE_LOOPDIAGNOSTIC_COMPLETE)
			    || (lineState.data.nLineState ==
				DSL_LINESTATE_SHOWTIME_TC_SYNC)) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				break;
			}

			/* - check if line state is exception then update the state to error
			   - dsl api should return an error it does not delt measurement in a specific mode
			   eg : g.dmt

			   - dsl api should return exception if link goes down while the diagnostics test is running
			   - if dslam is not supporting loopback or running an old firmware, then diagnostics
			   wont succeed and cpe will come back to showtime. then also dsl api should return exception
			 */
//                      if((count == 32766) || 

			/* Subramani -  This error state is not clear 
			   we break this loop after 250 secs 
			   TRAIN = 60, DIAG=120, TRAIN=60       
			 */

			if (count < 250) {
				sleep(1);
			} else {
				break;
			}

			/*
			   if((lineState.data.nLineState == DSL_LINESTATE_EXCEPTION) ||
			   (lineState.data.nLineState == DSL_LINESTATE_SHOWTIME_TC_SYNC)) {
			   sprintf(conf_buf, "%s_diagnosticState=\"%d\"\n", PREFIX_DSL_DIAG, WAN_DIAG_ERROR_EXT);
			   Wan_Dsl_Diag->diagnostic_state = WAN_DIAG_ERROR_EXT;
			   WRITE_DSL_DIAG_TO_FILE(conf_buf, flags, ret, IFX_Handler)
			   ret = IFX_FAILURE;
			   goto IFX_Handler;
			   } */

			memset(&lineState, 0x00, sizeof(DSL_LineState_t));
			cmd = DSL_FIO_LINE_STATE_GET;
			ret =
			    ifx_cpe_api_device_get_operation(cmd,
							     (void *)&lineState,
							     flags);
			if (ret < 0) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("\n\n In %s: ioctl  failed at line:%d!\n",
				     __FUNCTION__, __LINE__);
#endif
				Wan_Dsl_Diag->diagnostic_state =
				    WAN_DIAG_ERROR_EXT;
				//goto IFX_Handler;
			} else {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("\n\n In %s: ioctl  passed at line:%d!\n",
				     __FUNCTION__, __LINE__);
#endif
			}

			count++;
		}

		/* STEP 4: Read the Required Diagnostic Data from the driver
		 *                 ACTPSDds, ACTPSDus, ACTATPds, ACTATPus, HLINSCdse,
		 *                 HLINpsds, QLNpsds, SNRpsds, BITSpsds, GAINSpsds
		 */

		count = 0;
		Wan_Dsl_Diag->diagnostic_state = WAN_DIAG_COMEPLETE;
		sprintf(Wan_Dsl_Diag->iid.cpeId.secName, "%s", TAG_DSL_DIAG);
		sprintf(Wan_Dsl_Diag->iid.cpeId.secName, "%s", TAG_WAN_DEVICE);

		/* Fill fieldname and values into array_fvp */
		sprintf(array_fvp[count++].fieldname, "%s_cpeId",
			PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].fieldname, "%s_pcpeId",
			PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].fieldname, "%s_fEnable",
			PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].fieldname, "%s_diagnosticState",
			PREFIX_DSL_DIAG);
		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 4,
					    (int32 *) & Wan_Dsl_Diag->iid.cpeId.
					    Id, &Wan_Dsl_Diag->iid.pcpeId.Id,
					    &Wan_Dsl_Diag->f_enable,
					    &Wan_Dsl_Diag->diagnostic_state);

		count = 4;
		//ACTATPds - DownStream Actual Aggregrate Transmitted Power 
		//ACTPSDds - DownStream Actual Power Spectral Density 
		/* [ start */
		memset(&Wan_Dsl_Diag->dsLineStatus, 0x00,
		       sizeof(DSL_G997_LineStatus_t));
		Wan_Dsl_Diag->dsLineStatus.nDirection = DSL_DOWNSTREAM;
		cmd = DSL_FIO_G997_LINE_STATUS_GET;
		ret =
		    ifx_cpe_api_device_get_operation(cmd,
						     (void *)&(Wan_Dsl_Diag->
							       dsLineStatus),
						     flags);
		if (ret < 0) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n",
				__FUNCTION__, __LINE__);
#endif
			//goto IFX_Handler;
		} else {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("\n\n In %s: ioctl  passed at line:%d!\n",
				__FUNCTION__, __LINE__);
#endif
		}

		//DownStreamACTATP = Wan_Dsl_Diag->dsLineStatus.data.ACTATP;                            
		sprintf(array_fvp[count].fieldname, "%s_ACTATPds",
			PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].value, "%d",
			Wan_Dsl_Diag->dsLineStatus.data.ACTATP);

		//DownStreamACTPS = Wan_Dsl_Diag->dsLineStatus.data.ACTPS;                            
		sprintf(array_fvp[count].fieldname, "%s_ACTPSDds",
			PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].value, "%d",
			Wan_Dsl_Diag->dsLineStatus.data.ACTPS);

		memset(&Wan_Dsl_Diag->usLineStatus, 0x00,
		       sizeof(DSL_G997_LineStatus_t));
		Wan_Dsl_Diag->usLineStatus.nDirection = DSL_UPSTREAM;
		cmd = DSL_FIO_G997_LINE_STATUS_GET;
		ret =
		    ifx_cpe_api_device_get_operation(cmd,
						     (void *)&(Wan_Dsl_Diag->
							       usLineStatus),
						     flags);
		if (ret < 0) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n",
				__FUNCTION__, __LINE__);
#endif
			//goto IFX_Handler;
		} else {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("\n\n In %s: ioctl  passed at line:%d!\n",
				__FUNCTION__, __LINE__);
#endif
		}

		//ACTATPus - UpStream Actual Aggregrate Transmitted Power 
		//ACTPSDus - UpStream Actual Power Spectral Density 
		//UpStreamACTATP = Wan_Dsl_Diag->usLineStatus.data.ACTATP;
		sprintf(array_fvp[count].fieldname, "%s_ACTATPus",
			PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].value, "%d",
			Wan_Dsl_Diag->usLineStatus.data.ACTATP);

		//UpStreamACTPS = Wan_Dsl_Diag->usLineStatus.data.ACTPS;
		sprintf(array_fvp[count].fieldname, "%s_ACTPSDus",
			PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].value, "%d",
			Wan_Dsl_Diag->dsLineStatus.data.ACTPS);
		/* end ] */

		//HLINSCds - DownStream Linear Representation Scale
		memset(&Wan_Dsl_Diag->hlinScale, 0x00,
		       sizeof(DSL_G997_DeltHlinScale_t));
		Wan_Dsl_Diag->hlinScale.nDirection = DSL_DOWNSTREAM;
		cmd = DSL_FIO_G997_DELT_HLIN_SCALE_GET;
		ret =
		    ifx_cpe_api_device_get_operation(cmd,
						     (void *)&(Wan_Dsl_Diag->
							       hlinScale),
						     flags);
		if (ret < 0) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n",
				__FUNCTION__, __LINE__);
#endif
			//goto IFX_Handler;
		} else {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("\n\n In %s: ioctl  passed at line:%d!\n",
				__FUNCTION__, __LINE__);
#endif
		}
		//DownStreamDeltHlinScaleData = Wan_Dsl_Diag->hlinScale.data.nDeltHlinScale;
		sprintf(array_fvp[count].fieldname, "%s_HLINSCds",
			PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].value, "%d",
			Wan_Dsl_Diag->hlinScale.data.nDeltHlinScale);

		// STEP 5: Update the above parameters to a DSL Statics file
		/********* System Config File Update Block  **********/
		/* Convert the name value pair in array_fvp into string format expected by rc.conf file */

		memset(conf_buf, 0x00, sizeof(conf_buf));
		form_cfgdb_buf(conf_buf, count, array_fvp);

		WRITE_DSL_DIAG_TO_FILE(conf_buf, flags, ret, IFX_Handler)
	} else {
		sprintf(Wan_Dsl_Diag->iid.cpeId.secName, "%s", TAG_DSL_DIAG);
		sprintf(Wan_Dsl_Diag->iid.cpeId.secName, "%s", TAG_WAN_DEVICE);

		count = 0;
		memset(array_fvp, 0x00, sizeof(array_fvp));

		/* Fill fieldname and values into array_fvp */
		sprintf(array_fvp[count++].fieldname, "%s_cpeId",
			PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].fieldname, "%s_pcpeId",
			PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].fieldname, "%s_fEnable",
			PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].fieldname, "%s_diagnosticState",
			PREFIX_DSL_DIAG);
		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 4,
					    (int32 *) & Wan_Dsl_Diag->iid.cpeId.
					    Id, &Wan_Dsl_Diag->iid.pcpeId.Id,
					    &Wan_Dsl_Diag->f_enable,
					    &Wan_Dsl_Diag->diagnostic_state);

		count = 4;

		/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
		memset(conf_buf, 0x00, sizeof(conf_buf));
		form_cfgdb_buf(conf_buf, count, array_fvp);

		WRITE_DSL_DIAG_TO_FILE(conf_buf, flags, ret, IFX_Handler)
	}

      IFX_Handler:
	if ((Wan_Dsl_Diag->f_enable == IFX_ENABLED) &&
	    (Wan_Dsl_Diag->diagnostic_state == WAN_DIAG_COMEPLETE ||
	     Wan_Dsl_Diag->diagnostic_state == WAN_DIAG_ERROR_EXT)) {
	BRINGUP_SERVICES}

	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	} else
		return IFX_SUCCESS;
}

/* This function is to intialize the sections required by the dynamic objects in a /tmp/xxxx file
   Otherwise a get on a dynamic object which does not exist may result in failure */
int32 ifx_dynamic_object_init(IFX_ID * iid)
{
	int32 ret = IFX_SUCCESS, flags = IFX_F_INT_ADD;

	/* Initialize dsl diagnostics object in FILE_DYN_INFO */
	if (!strcmp(iid->cpeId.secName, TAG_DSL_DIAG)) {
		char8 conf_buf[2 * MAX_DATA_LEN];
		int32 i = 0, count = 0;
		IFX_NAME_VALUE_PAIR array_fvp[20];

		memset(array_fvp, 0x00, sizeof(array_fvp));

		/* Fill fieldname and values into array_fvp */
		sprintf(array_fvp[count].fieldname, "%s_cpeId",
			PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].value, "%d", 1);
		sprintf(array_fvp[count].fieldname, "%s_pcpeId",
			PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].value, "%d", 1);
		sprintf(array_fvp[count].fieldname, "%s_fEnable",
			PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].value, "%d", 1);
		sprintf(array_fvp[count].fieldname, "%s_diagnosticState",
			PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].value, "%d", 0);

		sprintf(array_fvp[count++].fieldname, "%s_ACTATPds",
			PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].fieldname, "%s_ACTATPus",
			PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].fieldname, "%s_ACTPSDds",
			PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].fieldname, "%s_ACTPSDus",
			PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].fieldname, "%s_HLINSCds",
			PREFIX_DSL_DIAG);

		/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
		memset(conf_buf, 0x00, sizeof(conf_buf));
		form_cfgdb_buf(conf_buf, count, array_fvp);

		WRITE_DSL_DIAG_TO_FILE(conf_buf, flags, ret, IFX_Handler)

		    count = 0;
		memset(array_fvp, 0x00, sizeof(array_fvp));

		for (i = 0; i < 16; i++) {	/* 16 = 512 (DSL_MAX_NSC) / 32 (comma seperated list of data) */
			sprintf(array_fvp[count++].fieldname, "%s_HLINpsds_%d",
				PREFIX_DSL_DIAG, i);
		}

		/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
		memset(conf_buf, 0x00, sizeof(conf_buf));
		form_cfgdb_buf(conf_buf, count, array_fvp);

		WRITE_DSL_DIAG_TO_FILE(conf_buf, flags, ret, IFX_Handler)
#if 0
		    count = 0;
		memset(array_fvp, 0x00, sizeof(array_fvp));

		for (i = 0; i < 16; i++) {	/* 16 = 512 (DSL_MAX_NSC) / 32 (comma seperated list of data) */
			sprintf(array_fvp[count++].fieldname, "%s_QLNpsds_%d",
				PREFIX_DSL_DIAG, i);
		}

		/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
		memset(conf_buf, 0x00, sizeof(conf_buf));
		form_cfgdb_buf(conf_buf, count, array_fvp);

		WRITE_DSL_DIAG_TO_FILE(conf_buf, flags, ret, IFX_Handler)

		    count = 0;
		memset(array_fvp, 0x00, sizeof(array_fvp));

		for (i = 0; i < 16; i++) {	/* 16 = 512 (DSL_MAX_NSC) / 32 (comma seperated list of data) */
			sprintf(array_fvp[count++].fieldname, "%s_SNRpsds_%d",
				PREFIX_DSL_DIAG, i);
		}

		/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
		memset(conf_buf, 0x00, sizeof(conf_buf));
		form_cfgdb_buf(conf_buf, count, array_fvp);

		WRITE_DSL_DIAG_TO_FILE(conf_buf, flags, ret, IFX_Handler)

		    count = 0;
		memset(array_fvp, 0x00, sizeof(array_fvp));

		for (i = 0; i < 16; i++) {	/* 16 = 512 (DSL_MAX_NSC) / 32 (comma seperated list of data) */
			sprintf(array_fvp[count++].fieldname, "%s_BITSpsds_%d",
				PREFIX_DSL_DIAG, i);
		}

		/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
		memset(conf_buf, 0x00, sizeof(conf_buf));
		form_cfgdb_buf(conf_buf, count, array_fvp);

		WRITE_DSL_DIAG_TO_FILE(conf_buf, flags, ret, IFX_Handler)

		    count = 0;
		memset(array_fvp, 0x00, sizeof(array_fvp));

		for (i = 0; i < 16; i++) {	/* 16 = 512 (DSL_MAX_NSC) / 32 (comma seperated list of data) */
			sprintf(array_fvp[count++].fieldname, "%s_GAINSpsds_%d",
				PREFIX_DSL_DIAG, i);
		}

		/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
		memset(conf_buf, 0x00, sizeof(conf_buf));
		form_cfgdb_buf(conf_buf, count, array_fvp);

		WRITE_DSL_DIAG_TO_FILE(conf_buf, flags, ret, IFX_Handler)
#endif
	}

      IFX_Handler:
	if (ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}

int32 ifx_cpe_api_get_dsl_diagnostics(WAN_DSL_DIAGNOSTICS * Wan_Dsl_Diag,
				      uint32 flags)
{
	int32 cmd = 0, ret = IFX_SUCCESS;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_DATA_LEN];

	sprintf(buf, "%s_cpeId", PREFIX_DSL_DIAG);
	if ((ret =
	     ifx_GetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, buf, flags, &outFlag,
			    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->iid.cpeId.Id = atoi(sValue);

	sprintf(buf, "%s_pcpeId", PREFIX_DSL_DIAG);
	if ((ret =
	     ifx_GetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, buf, flags, &outFlag,
			    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->iid.pcpeId.Id = atoi(sValue);

	sprintf(Wan_Dsl_Diag->iid.cpeId.secName, "%s", TAG_DSL_DIAG);
	sprintf(Wan_Dsl_Diag->iid.cpeId.secName, "%s", TAG_WAN_DEVICE);

	sprintf(buf, "%s_fEnable", PREFIX_DSL_DIAG);
	if ((ret =
	     ifx_GetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, buf, flags, &outFlag,
			    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->f_enable = atoi(sValue);

	sprintf(buf, "%s_diagnosticState", PREFIX_DSL_DIAG);
	if ((ret =
	     ifx_GetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, buf, flags, &outFlag,
			    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->diagnostic_state = atoi(sValue);

	sprintf(buf, "%s_ACTATPds", PREFIX_DSL_DIAG);
	if ((ret =
	     ifx_GetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, buf, flags, &outFlag,
			    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->dsLineStatus.data.ACTATP = atoi(sValue);	// ACTATP should be filled with ACTATPds or ACTATPus

	sprintf(buf, "%s_ACTATPus", PREFIX_DSL_DIAG);
	if ((ret =
	     ifx_GetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, buf, flags, &outFlag,
			    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->usLineStatus.data.ACTATP = atoi(sValue);	// ACTATP should be filled with ACTATPds or ACTATPus

	sprintf(buf, "%s_ACTPSDds", PREFIX_DSL_DIAG);
	if ((ret =
	     ifx_GetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, buf, flags, &outFlag,
			    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->dsLineStatus.data.ACTPS = atoi(sValue);	// ACTPS should be filled with ACTPSDds or ACTPSDus

	sprintf(buf, "%s_ACTPSDus", PREFIX_DSL_DIAG);
	if ((ret =
	     ifx_GetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, buf, flags, &outFlag,
			    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->usLineStatus.data.ACTPS = atoi(sValue);	// ACTPS should be filled with ACTPSDds or ACTPSDus

	//HLINSCds
	sprintf(buf, "%s_HLINSCds", PREFIX_DSL_DIAG);
	if ((ret =
	     ifx_GetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, buf, flags, &outFlag,
			    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->hlinScale.data.nDeltHlinScale = atoi(sValue);

	//HLINSCus
	memset(&Wan_Dsl_Diag->hlinScaleus, 0x00,
	       sizeof(DSL_G997_DeltHlinScale_t));
	Wan_Dsl_Diag->hlinScaleus.nDirection = DSL_UPSTREAM;
	Wan_Dsl_Diag->hlinScaleus.nDeltDataType = DSL_DELT_DATA_DIAGNOSTICS;
	cmd = DSL_FIO_G997_DELT_HLIN_SCALE_GET;
	ret =
	    ifx_cpe_api_device_get_operation(cmd,
					     (void *)&(Wan_Dsl_Diag->
						       hlinScaleus), flags);

	//HLINpsds - DownStream Linear Channel Characteristics
	Wan_Dsl_Diag->hlin.nDirection = DSL_DOWNSTREAM;
	Wan_Dsl_Diag->hlin.nDeltDataType = DSL_DELT_DATA_DIAGNOSTICS;
	cmd = DSL_FIO_G997_DELT_HLIN_GET;
	ret =
	    ifx_cpe_api_device_get_operation(cmd, (void *)&(Wan_Dsl_Diag->hlin),
					     flags);
	if (ret < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
	}
	//HLINpsus - UpStream Linear Channel Characteristics
	Wan_Dsl_Diag->hlinus.nDirection = DSL_UPSTREAM;
	Wan_Dsl_Diag->hlinus.nDeltDataType = DSL_DELT_DATA_DIAGNOSTICS;
	cmd = DSL_FIO_G997_DELT_HLIN_GET;
	ret =
	    ifx_cpe_api_device_get_operation(cmd,
					     (void *)&(Wan_Dsl_Diag->hlinus),
					     flags);
	if (ret < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
	}
	//HLOG - Upstream
	Wan_Dsl_Diag->hlogus.nDirection = DSL_UPSTREAM;
	Wan_Dsl_Diag->hlogus.nDeltDataType = DSL_DELT_DATA_DIAGNOSTICS;
	cmd = DSL_FIO_G997_DELT_HLOG_GET;
	ret =
	    ifx_cpe_api_device_get_operation(cmd,
					     (void *)&(Wan_Dsl_Diag->hlogus),
					     flags);
	if (ret < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
	}
	//HLOG - Downstream
	Wan_Dsl_Diag->hlogds.nDirection = DSL_DOWNSTREAM;
	Wan_Dsl_Diag->hlogds.nDeltDataType = DSL_DELT_DATA_DIAGNOSTICS;
	cmd = DSL_FIO_G997_DELT_HLOG_GET;
	ret =
	    ifx_cpe_api_device_get_operation(cmd,
					     (void *)&(Wan_Dsl_Diag->hlogds),
					     flags);
	if (ret < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
	}
	//QLN - DownStream
	Wan_Dsl_Diag->qln.nDirection = DSL_DOWNSTREAM;
	Wan_Dsl_Diag->qln.nDeltDataType = DSL_DELT_DATA_DIAGNOSTICS;
	cmd = DSL_FIO_G997_DELT_QLN_GET;
	ret =
	    ifx_cpe_api_device_get_operation(cmd, (void *)&(Wan_Dsl_Diag->qln),
					     flags);
	if (ret < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
	}
	//QLN - UpStream
	Wan_Dsl_Diag->qlnus.nDirection = DSL_UPSTREAM;
	Wan_Dsl_Diag->qlnus.nDeltDataType = DSL_DELT_DATA_DIAGNOSTICS;
	cmd = DSL_FIO_G997_DELT_QLN_GET;
	ret =
	    ifx_cpe_api_device_get_operation(cmd,
					     (void *)&(Wan_Dsl_Diag->qlnus),
					     flags);
	if (ret < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
	}
	//SNR - DownStream Signal-to-Noise
	Wan_Dsl_Diag->snrds.nDirection = DSL_DOWNSTREAM;
	Wan_Dsl_Diag->snrds.nDeltDataType = DSL_DELT_DATA_DIAGNOSTICS;
	cmd = DSL_FIO_G997_DELT_SNR_GET;
	ret =
	    ifx_cpe_api_device_get_operation(cmd,
					     (void *)&(Wan_Dsl_Diag->snrds),
					     flags);
	if (ret < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
	}
	//SNR - UpStream Signal-to-Noise
	Wan_Dsl_Diag->snrus.nDirection = DSL_UPSTREAM;
	Wan_Dsl_Diag->snrus.nDeltDataType = DSL_DELT_DATA_DIAGNOSTICS;
	cmd = DSL_FIO_G997_DELT_SNR_GET;
	ret =
	    ifx_cpe_api_device_get_operation(cmd,
					     (void *)&(Wan_Dsl_Diag->snrus),
					     flags);
	if (ret < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
	}
	//SNRpsds - DownStream Signal-to-Noise Ratio per SubCarrier
	Wan_Dsl_Diag->snr.nDirection = DSL_DOWNSTREAM;
	cmd = DSL_FIO_G997_DELT_SNR_GET;
	ret =
	    ifx_cpe_api_device_get_operation(cmd, (void *)&(Wan_Dsl_Diag->snr),
					     flags);
	if (ret < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
	} else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In %s: ioctl  passed at line:%d!\n", __FUNCTION__,
			__LINE__);
#endif
	}

      IFX_Handler:
	return IFX_SUCCESS;
}

int32 ifx_cpe_api_device_get_operation(int32 cmd, void *data, uint32 flags)
{
	int32 fd = 0;
	int32 ret = IFX_SUCCESS;

	if ((fd = open(DSL_DEVICE, O_RDWR)) < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n [%s] : Open DSL device (%s) failed!!\n",
			__FUNCTION__, DSL_DEVICE);
#endif
		return fd;

	}

	if ((ret = ioctl(fd, cmd, data)) < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n [%s] : Ioctl operation failed!\n", __FUNCTION__);
#endif
	}
	close(fd);
	return ret;

}

int32 ifx_cpe_api_get_line_activate(IFX_ID * iid,
				    DSL_G997_LineActivate_t * lineActivate,
				    uint32 flags)
{
	int32 cmd, ret = IFX_SUCCESS;

	cmd = DSL_FIO_G997_LINE_ACTIVATE_CONFIG_GET;
	if ((ifx_cpe_api_device_get_operation
	     (cmd, (void *)&(lineActivate), flags)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n [%s] : failed!\n", __FUNCTION__);
#endif
		ret = IFX_FAILURE;
	}
	return ret;
}

int32 ifx_cpe_api_device_set_operation(int32 cmd, void *data, uint32 flags)
{
	int32 fd = 0;
	int32 ret = IFX_SUCCESS;

	if ((fd = open(DSL_DEVICE, O_RDWR)) < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n [%s] : Open DSL device (%s) failed!!\n",
			__FUNCTION__, DSL_DEVICE);
#endif
		ret = IFX_ERR_FILE_OPEN;
		return ret;

	}

	if (ioctl(fd, cmd, data) < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n [%s] : Ioctl failed!\n", __FUNCTION__);
#endif
		ret = IFX_ERR_IOCTL;
	}
	close(fd);
	return ret;

}

#if 0
int32 ifx_cpe_api_set_line_activate(IFX_ID * iid,
				    DSL_G997_LineActivate_t * lineActivate,
				    uint32 flags)
{
	time_t currTs = 0;
	int32 cmd, ret = IFX_SUCCESS;
	char8 acl_buf[10] = "owner";
	char8 buf[MAX_FILELINE_LEN];

	/* proceed only if ACL permits */
	if ((IFX_CHECK_ACL(iid, 1, &acl_buf[0], flags, IFX_Handler)) !=
	    IFX_SUCCESS) {
		IFX_DBG("\n [%s] : ACL failed!\n", __FUNCTION__);
		goto IFX_Handler;
	}

	cmd = DSL_FIO_G997_LINE_ACTIVATE_CONFIG_SET;
	if ((ifx_cpe_api_device_set_operation
	     (cmd, (void *)&(lineActivate), flags)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n [%s] : Ioctl failed \n\n", __FUNCTION__);
#endif
		goto IFX_Handler;
	}

	(void)time(&currTs);

	sprintf(buf, "owner=\"%d\"\nstate=\"%s\"\ntimestamp=\"%ld\"\n",
		iid->config_owner, IFX_DSL_STATE_DIAG,
		(unsigned long int)currTs);
	if ((ret =
	     ifx_SetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, IFX_F_DEFAULT, 1,
			    buf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n [%s] : DSL info update failed !! \n", __FUNCTION__);
#endif
		goto IFX_Handler;
	}

      IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_DBG("\n [%s] : returned failure!\n", __FUNCTION__);
		return IFX_FAILURE;
	} else
		return IFX_SUCCESS;
}
#endif

#endif				// CONFIG_PACKAGE_IFX_DSL_CPE_API
/* 705031:Santosh: new dsl diagnostics api */




int32 ltq_mapi_get_diagnostics_status(DIAGNOSTICS_TEST_SUITE * diag_test_suite, uint32 flags)
{
        int32 iRet = IFX_SUCCESS;
        /* sVal buffer should be large enough to accomodate
           the biggest string in the obj */
        char8 sVal[MAX_DATA_LEN];
        uint32 ulOutFlag;

        if (ifx_GetObjDataOpt(IFX_DIAG_FILE, IFX_SELFTEST_DIAG_SECTION, IFX_SELFTEST_DIAG_SECTION, IFX_F_INT_CACHE_INIT | flags, NULL, NULL) != IFX_SUCCESS)
        {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] Failed to initialize cache", __FUNCTION__, __LINE__);
#endif
                iRet = IFX_FAILURE;
                goto IFX_Handler;
        }


        if ((iRet = ifx_GetObjDataOpt(IFX_DIAG_FILE, IFX_SELFTEST_DIAG_SECTION, IFX_SELFTEST_DIAG_DIAGSTATE,
                                      IFX_F_GET_ANY, &ulOutFlag, sVal)) != IFX_SUCCESS)
        {
                IFX_DBG("\n [%s:%d] : returned failure!\n", __FUNCTION__,__LINE__);
                goto IFX_Handler;
        }

        if ((strlen(sVal) + 1) > MAX_DIAGSTATE_LEN) {
                fprintf(stderr, "DiagState Value len exceeded=%d\n",
                        strlen(sVal));
                iRet = IFX_FAILURE;
                IFX_DBG("\n [%s:%d] : returned failure!\n", __FUNCTION__,__LINE__);
                goto IFX_Handler;
        }
        strcpy(diag_test_suite->diag_state, sVal);

        if ((iRet = ifx_GetObjDataOpt(IFX_DIAG_FILE,IFX_SELFTEST_DIAG_SECTION, IFX_SELFTEST_DIAG_WAN,
                                      IFX_F_GET_ANY, &ulOutFlag, sVal)) != IFX_SUCCESS)
        {
                IFX_DBG("\n [%s:%d] : returned failure!\n", __FUNCTION__,__LINE__);
                goto IFX_Handler;
        }
        diag_test_suite->wan_conn_status = atoi(sVal);

        if ((iRet = ifx_GetObjDataOpt(IFX_DIAG_FILE,IFX_SELFTEST_DIAG_SECTION, IFX_SELFTEST_DIAG_DSLLINKSTATUS,
                                   IFX_F_GET_ANY, &ulOutFlag, sVal)) != IFX_SUCCESS)
        {
                IFX_DBG("\n [%s:%d] : returned failure!\n", __FUNCTION__,__LINE__);
                goto IFX_Handler;
        }
        else 
        {
                if (!strcmp(sVal, "CONNECTING"))
                      diag_test_suite->link_status = DSL_LINK_STATUS_INITIALIZE;
                else if (!strcmp(sVal, "CONNECTED"))
                      diag_test_suite->link_status = DSL_LINK_STATUS_UP;
                else
                      diag_test_suite->link_status = DSL_LINK_STATUS_DOWN;
        }

        if ((iRet = ifx_GetObjDataOpt(IFX_DIAG_FILE,IFX_SELFTEST_DIAG_SECTION, IFX_SELFTEST_DIAG_LAN0,
                                   IFX_F_GET_ANY, &ulOutFlag, sVal)) != IFX_SUCCESS)
        {
                IFX_DBG("\n [%s:%d] : returned failure!\n", __FUNCTION__,__LINE__);
                goto IFX_Handler;
        }
        diag_test_suite->enet_lan0_status = atoi(sVal);

        if ((iRet = ifx_GetObjDataOpt(IFX_DIAG_FILE,IFX_SELFTEST_DIAG_SECTION, IFX_SELFTEST_DIAG_LAN1,
                                   IFX_F_GET_ANY, &ulOutFlag, sVal)) != IFX_SUCCESS)
        {
                IFX_DBG("\n [%s:%d] : returned failure!\n", __FUNCTION__,__LINE__);
                goto IFX_Handler;
        }
        diag_test_suite->enet_lan1_status = atoi(sVal);

        if ((iRet = ifx_GetObjDataOpt(IFX_DIAG_FILE,IFX_SELFTEST_DIAG_SECTION, IFX_SELFTEST_DIAG_LAN2,
                                   IFX_F_GET_ANY, &ulOutFlag, sVal)) != IFX_SUCCESS)
        {
                IFX_DBG("\n [%s:%d] : returned failure!\n", __FUNCTION__,__LINE__);
                goto IFX_Handler;
        }
        diag_test_suite->enet_lan2_status = atoi(sVal);
   
        if ((iRet = ifx_GetObjDataOpt(IFX_DIAG_FILE,IFX_SELFTEST_DIAG_SECTION, IFX_SELFTEST_DIAG_LAN3,
                                   IFX_F_GET_ANY, &ulOutFlag, sVal)) != IFX_SUCCESS)
        {
                IFX_DBG("\n [%s:%d] : returned failure!\n", __FUNCTION__,__LINE__);
                goto IFX_Handler;
        }
        diag_test_suite->enet_lan3_status = atoi(sVal);

        if ((iRet = ifx_GetObjDataOpt(IFX_DIAG_FILE,IFX_SELFTEST_DIAG_SECTION, IFX_SELFTEST_DIAG_GATEWAY_PING,
                                   IFX_F_GET_ANY, &ulOutFlag, sVal)) != IFX_SUCCESS)
        {
                IFX_DBG("\n [%s:%d] : returned failure!\n", __FUNCTION__,__LINE__);
                goto IFX_Handler;
        }
        diag_test_suite->wan_gw = atoi(sVal);

        if ((iRet = ifx_GetObjDataOpt(IFX_DIAG_FILE,IFX_SELFTEST_DIAG_SECTION, IFX_SELFTEST_DIAG_PRIMARYDNS,
                                   IFX_F_GET_ANY, &ulOutFlag, sVal)) != IFX_SUCCESS)
        {
                IFX_DBG("\n [%s:%d] : returned failure!\n", __FUNCTION__,__LINE__);
                goto IFX_Handler;
        }
        diag_test_suite->dns1 = atoi(sVal);

        if ((iRet = ifx_GetObjDataOpt(IFX_DIAG_FILE,IFX_SELFTEST_DIAG_SECTION, IFX_SELFTEST_DIAG_SECONDARYDNS,
                                   IFX_F_GET_ANY, &ulOutFlag, sVal)) != IFX_SUCCESS)
        {
                IFX_DBG("\n [%s:%d] : returned failure!\n", __FUNCTION__,__LINE__);
                goto IFX_Handler;
        }
        diag_test_suite->dns2 = atoi(sVal);

        if ((iRet = ifx_GetObjDataOpt(IFX_DIAG_FILE,IFX_SELFTEST_DIAG_SECTION, IFX_SELFTEST_DIAG_ENCAPSULATION,
                                   IFX_F_GET_ANY, &ulOutFlag, sVal)) != IFX_SUCCESS)
        {
                IFX_DBG("\n [%s:%d] : returned failure!\n", __FUNCTION__,__LINE__);
                goto IFX_Handler;
        }
         else 
         {
                if (!strcmp(sVal, "ATM"))
                            diag_test_suite->encap = WAN_TC_ATM;
                else if (!strcmp(sVal, "PTM"))
                            diag_test_suite->encap = WAN_TC_PTM;
                else if(!strcmp(sVal, "PTM"))
                            diag_test_suite->encap = WAN_TC_UNCONFIGURED;
        }

       if ((iRet = ifx_GetObjDataOpt(IFX_DIAG_FILE,IFX_SELFTEST_DIAG_SECTION, IFX_SELFTEST_DIAG_WLAN0,
                                   IFX_F_GET_ANY, &ulOutFlag, sVal)) != IFX_SUCCESS)
       {
               IFX_DBG("\n [%s:%d] : returned failure!\n", __FUNCTION__,__LINE__);
               goto IFX_Handler;
       }
       diag_test_suite->wlan0 = atoi(sVal);


#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
        if ((iRet = ifx_GetObjDataOpt(IFX_DIAG_FILE,IFX_SELFTEST_DIAG_SECTION, IFX_SELFTEST_DIAG_WLAN1,
                                   IFX_F_GET_ANY, &ulOutFlag, sVal)) != IFX_SUCCESS)
        {
                IFX_DBG("\n [%s:%d] : returned failure!\n", __FUNCTION__,__LINE__);
                goto IFX_Handler;
        }
        diag_test_suite->wlan1 = atoi(sVal);
#endif

        if ((iRet = ifx_GetObjDataOpt(IFX_DIAG_FILE, IFX_SELFTEST_DIAG_SECTION, IFX_SELFTEST_DIAG_RESULT,
                                   IFX_F_GET_ANY, &ulOutFlag, sVal)) != IFX_SUCCESS)
        {
                IFX_DBG("\n [%s:%d] : returned failure!\n", __FUNCTION__,__LINE__);
                goto IFX_Handler;
        }

        if ((strlen(sVal) + 1) > MAX_DATA_LEN) {
                fprintf(stderr, "DiagState Value len exceeded=%d\n",
                        strlen(sVal));
                iRet = IFX_FAILURE;        
                IFX_DBG("\n [%s:%d] : returned failure!\n", __FUNCTION__,__LINE__);
                goto IFX_Handler;
        }
        strcpy(diag_test_suite->caResult, sVal);

        if (ifx_GetObjDataOpt(IFX_DIAG_FILE, IFX_SELFTEST_DIAG_SECTION, IFX_SELFTEST_DIAG_SECTION, IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS)
        {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] Failed to destroy cache for this instance",__FUNCTION__, __LINE__);
#endif
                iRet = IFX_FAILURE;
                goto IFX_Handler;
        }


      IFX_Handler:
        if (iRet != IFX_SUCCESS) 
        {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s] : returned failure!", __FUNCTION__);
#endif
                return iRet;
        } 
        else 
        {
                return IFX_SUCCESS;
        }

}


int32 ltq_mapi_set_diagnostics_status(DIAGNOSTICS_TEST_SUITE * diag_test_suite, uint32 flags)
{
        char8 *sVal = NULL;
        int32 ret = IFX_SUCCESS;
        IFX_NAME_VALUE_PAIR selftest_array_fvp[15];

        memset(&selftest_array_fvp, 0, sizeof(selftest_array_fvp));

        IFX_MEM_ALLOC(sVal, char8 *, 1, MAX_DATA_LEN  * sizeof(char8));

        if (sVal == NULL) {
                IFX_DBG("%s:%d Error--> Failed to Malloc !!\n", __FUNCTION__, __LINE__);
                goto IFX_Handler;
        }
        /* TBD: flags are not considered. Also iid struct in SELFTEST_DIAG is not
           considered */

        ifx_fill_ArrayFvp_FName(selftest_array_fvp, 0, 15, selftest_parms);
        sprintf(selftest_array_fvp[0].value, "%s", diag_test_suite->diag_state);
	sprintf(selftest_array_fvp[1].value, "%d", diag_test_suite->wan_conn_status);
        sprintf(selftest_array_fvp[2].value, "%d", diag_test_suite->link_status);
        sprintf(selftest_array_fvp[3].value, "%d", diag_test_suite->lan_conn_status);
        sprintf(selftest_array_fvp[4].value, "%d", diag_test_suite->enet_lan0_status);
        sprintf(selftest_array_fvp[5].value, "%d", diag_test_suite->enet_lan1_status);
        sprintf(selftest_array_fvp[6].value, "%d", diag_test_suite->enet_lan2_status);
        sprintf(selftest_array_fvp[7].value, "%d", diag_test_suite->enet_lan3_status);
        sprintf(selftest_array_fvp[8].value, "%d", diag_test_suite->wan_gw);
        sprintf(selftest_array_fvp[9].value, "%d", diag_test_suite->dns1);
        sprintf(selftest_array_fvp[10].value, "%d", diag_test_suite->dns2);
        sprintf(selftest_array_fvp[11].value, "%d", diag_test_suite->encap);
        sprintf(selftest_array_fvp[12].value, "%d", diag_test_suite->wlan0);
        sprintf(selftest_array_fvp[13].value, "%d", diag_test_suite->wlan1);
        sprintf(selftest_array_fvp[14].value, "%s", diag_test_suite->caResult);

        form_cfgdb_buf(sVal, 15, selftest_array_fvp);


        if ((ret = ifx_SetObjData(IFX_DIAG_FILE, IFX_SELFTEST_DIAG_SECTION,
                                   flags, 1, sVal)) != IFX_SUCCESS)

        if (ret != IFX_SUCCESS) 
        {
#ifdef IFX_LOG_DEBUG
               IFX_DBG("\n [%s:%d] : IFX_SetObjData returned failure!\n", __FUNCTION__,__LINE__);
#endif
                goto IFX_Handler;
        }

      IFX_Handler:
        IFX_MEM_FREE(sVal);
        
    return ret;
}

#if 0
int32 ltq_diag_oam_ping()
{
        unsigned int cells_tx, cells_rx, min_resp, max_resp, avg_resp,
            ping_timeout;
        int32 vpi = 0, vci = 0, ret, vcc_ping_return = 0;;
        char8 sValue[MAX_FILELINE_LEN], sWAN_VCC[MAX_NAME_SIZE];
        uint32 flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT;
        IFX_ID iid;
        char_t *temp = NULL;
        memset(sValue, 0x00, sizeof(sValue));
        memset(sWAN_VCC, 0x00, sizeof(sWAN_VCC));
        memset(&iid, 0x00, sizeof(iid));
        max_resp = min_resp = avg_resp = cells_rx = 0;

        ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, sValue, flags, &outFlag,
                       sWAN_VCC);
        cells_tx = 5;
        temp = strtok(sWAN_VCC, "/");
        if (temp)
                vpi = atoi(temp);
        temp = strtok(NULL, "/");
        if (temp)
                vci = atoi(temp);
        ping_timeout = 600;
        ret =
            ifx_oam_f5_ping(vpi, vci, 4, ping_timeout, cells_tx,
                            (int *)&cells_rx, (int *)&min_resp,
                            (int *)&max_resp, (int *)&avg_resp);
        if (ret == 0)
                vcc_ping_return = 1; //pass
        else
                vcc_ping_return = 2; //fail

        return vcc_ping_return;
}
#endif

int32 ltq_api_diag_perform_lan_ping(DIAGNOSTICS_TEST_SUITE * pxDiagTest)
{
        uint32 usecs = 300000;
        char_t buffer1[30] = { 0 }, buffer2[30] = { 0 };
        int32 ping_ret = 0, no_ping = 4;
        FILE *fp;

        memset(buffer1, 0x00, sizeof(buffer1));
        memset(buffer2, 0x00, sizeof(buffer2));

        //ifx_diag_oam_ping();

        system("cat /proc/net/arp > /tmp/diag_temp1");
        system("cut -d \" \" -f1 /tmp/diag_temp1 > /tmp/diag_temp2");
        system("cut -d \"I\" -f1 /tmp/diag_temp2 > /tmp/diag_temp3");
        fp = fopen("/tmp/diag_temp3", "r");
        if (fp) 
        {
             if (fscanf(fp, "%29s", buffer1) != EOF)
                  fscanf(fp, "%29s", buffer2);
                  fclose(fp);
        }
        system("rm -rf diag_temp*");
        ping_ret = ping_ipaddress(buffer1, usecs, no_ping);
        if (ping_ret == 0)
             pxDiagTest->lan_conn_status = 1;
        else
             pxDiagTest->lan_conn_status = 0;

        return 0;
}

int32 ltq_api_diag_perform_wan_ping(DIAGNOSTICS_TEST_SUITE * pxDiagTest)
{
        uint32 usecs = 300000;
        char_t sGateway[MAX_IP_ADDR_LEN] = { 0 };
        int32 ping_ret = 0, iRet = 0, no_ping = 4;

        memset(sGateway, 0x00, sizeof(sGateway));

        iRet = ifx_get_runtime_gw(sGateway);
        if(iRet != IFX_SUCCESS)
        {
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("\n\n Failed to get Gateway IP\n");
#endif
        return iRet;
        }
                  ping_ret = ping_ipaddress(sGateway, usecs, no_ping);
                if (ping_ret == 0)
                        pxDiagTest->wan_gw = 1; //pass
                else
                        pxDiagTest->wan_gw = 0; //fail

        return iRet;
}

int32 ltq_api_diag_perform_dnsping(DIAGNOSTICS_TEST_SUITE * pxDiagTest, char_t * sLine)
{
        uint32 usecs = 300000;
        int ping_ret = 1, iRet = 0, no_ping = 4;
        char buf1[128] = { 0 }, buf2[128] = { 0 };

        iRet = ltq_api_get_dns_ip(buf1,buf2);
        
        if(iRet == 1)
        {
        ping_ret = ping_ipaddress(buf1, usecs, no_ping);
            if (ping_ret == 0)
                  pxDiagTest->dns1 = 1; //pass
            else
                  pxDiagTest->dns1 = 0; //fail

            ping_ret = ping_ipaddress(buf2, usecs, no_ping);
            if (ping_ret == 0)
                  pxDiagTest->dns2 = 1; //pass
            else
                  pxDiagTest->dns2 = 0; //fail

            return iRet;
        }
        else
            return iRet;
}


int32 ltq_api_get_dns_ip(char * dns1, char *dns2)
{
     int iRet = 0;

        if(res_init() == -1)
        {
             fprintf(stderr,"res_init() failed\n");
             iRet = 0;
             goto errorHandler;
        }

        if (_res.nscount <= 0)
        {
            fprintf(stderr,"nscount = %d\n",_res.nscount);
            iRet = 0;
            goto errorHandler;
        }
        else
        {
            inet_ntop(AF_INET, &_res.nsaddr_list[0].sin_addr, dns1, (socklen_t)127);
            inet_ntop(AF_INET, &_res.nsaddr_list[1].sin_addr, dns2, (socklen_t)127);
            iRet = 1;
            goto errorHandler;
        }

errorHandler:
        return iRet;
}

int32 ltq_diag_get_status(DIAGNOSTICS_TEST_SUITE * pxDiagTest, int id)
{
        char_t sValue[MAX_FILELINE_LEN];
        struct ifx_phyport_info stat;
        memset(sValue, 0x00, sizeof(sValue));
        memset(&stat, 0x00, sizeof(stat));
#if defined(PLATFORM_VR9) || defined(PLATFORM_VB300) || defined(CONFIG_FEATURE_LTQ_HNX_CONFIG) || defined(PLATFORM_AR10)
        if (ifx_get_phyport_info(id, &stat, 0) < 0) {
#else
        if (ifx_get_phyport_info(id, &stat, 1) < 0) {
#endif
#ifdef IFX_LOG_DEBUG
                IFX_DBG("\n\n lan get status fail\n");
#endif
        } else {
                if (stat.link != 0)
                        strcat(sValue, "Up");
                else
                        strcat(sValue, "Down");
        }
        if(id == 0)
        {
                if(strcmp(sValue, "Up"))
                        pxDiagTest->enet_lan0_status=0;
                else
                        pxDiagTest->enet_lan0_status=1;
        }
        if(id == 1)
        {
                if(strcmp(sValue, "Up"))
                        pxDiagTest->enet_lan1_status=0;
                else
                        pxDiagTest->enet_lan1_status=1;
        }
        if(id == 2)
        {
                if(strcmp(sValue, "Up"))
                        pxDiagTest->enet_lan2_status=0;
                else
                        pxDiagTest->enet_lan2_status=1;
        }
        if(id == 4)
        {
                if(strcmp(sValue, "Up"))
                        pxDiagTest->enet_lan3_status=0;
                else
                        pxDiagTest->enet_lan3_status=1;
        }
        return 0;
}

int32 ltq_api_diag_get_lan_status(DIAGNOSTICS_TEST_SUITE * pxDiagTest)
{
        char_t sValue[MAX_FILELINE_LEN];
       
        memset(sValue, 0x00, sizeof(sValue));

#ifdef CONFIG_FEATURE_LTQ_HNX_CONFIG
        ltq_diag_get_status(pxDiagTest,1);
#elif defined(CONFIG_PACKAGE_KMOD_LTQCPE_AR10_F2_SUPPORT)
		int index;
		for (index = 2; index <=5; index++)
			ltq_diag_get_status(pxDiagTest,index);
#else
#ifndef PLATFORM_VB300
        ltq_diag_get_status(pxDiagTest,0);
#ifndef CONFIG_FEATURE_IFX_SINGLE_PORT
        ltq_diag_get_status(pxDiagTest,1);
        ltq_diag_get_status(pxDiagTest,2);
#if defined(PLATFORM_VR9) 
        ltq_diag_get_status(pxDiagTest,4);
#elif defined(PLATFORM_AR9) && !defined(PLATFORM_AR10)
        char_t phy_mode[8] = { 0 };
        uint32 outFlag = IFX_F_DEFAULT;
        ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, "wanphy_phymode",
                       IFX_F_DEFAULT, &outFlag, phy_mode);
        if (strcmp(phy_mode, "1")) {
                ltq_diag_get_status(pxDiagTest,4);
        }
#else
        ltq_diag_get_status(pxDiagTest,3);
#endif
#endif
#else
        ltq_diag_get_status(pxDiagTest,1);
#endif
#endif
        return 0;
}

#if defined(CONFIG_PACKAGE_IFX_DSL_CPE_API)
int32 ltq_api_diag_get_adsl_status(char_t * dsl_status)
{
DSL_G997_LineInventory_t lineInventoryGet;
DSL_uint8_t FarEndSystemVendorID[DSL_G997_LI_MAXLEN_VENDOR_ID];
DSL_uint8_t FarEndVersionNumber[DSL_G997_LI_MAXLEN_VERSION];
DSL_uint8_t FarEndSerialNumber[DSL_G997_LI_MAXLEN_SERIAL];
DSL_LineState_t lineState;
DSL_G997_XTUSystemEnabling_t xtuSystemEnabling;
#ifdef PLATFORM_VR9
DSL_BandPlanStatus_t xtuBandPlanStatus;
#endif
DSL_G997_PowerManagementStatus_t pwrMngStatus;
DSL_G997_PowerManagement_t PowerManagementStatus;
DSL_LineFeature_t lineFeatureConfig;
DSL_G997_FramingParameterStatus_t g997FramingParamStatusGet;
DSL_G997_ChannelStatus_t channelStatus;
DSL_uint32_t ActualInterleaveDelay;
DSL_uint32_t DownStreamActualDataRate;
DSL_uint32_t UpStreamActualDataRate;
DSL_G997_LineStatus_t lineStatus;
DSL_uint32_t DownStreamATTNDR;
DSL_uint32_t UpStreamATTNDR;
//DSL_uint32_t DownStreamINTLVDEPTH;
DSL_uint16_t DownStreamINTLVDEPTH;
//DSL_uint32_t UpStreamINTLVDEPTH;
DSL_uint16_t UpStreamINTLVDEPTH;
//DSL_uint32_t DownStreamLATN;
DSL_int16_t DownStreamLATN;
//DSL_uint32_t UpStreamLATN;
DSL_int16_t UpStreamLATN;
//DSL_uint32_t DownStreamSATN;
DSL_int16_t DownStreamSATN;
//DSL_uint32_t UpStreamSATN;
DSL_int16_t UpStreamSATN;
//DSL_uint32_t DownStreamSNR;
DSL_int16_t DownStreamSNR;
//DSL_uint32_t UpStreamSNR;
DSL_int16_t UpStreamSNR;
//DSL_uint32_t DownStreamACTATP;
DSL_int16_t DownStreamACTATP;
//DSL_uint32_t UpStreamACTATP;
DSL_int16_t UpStreamACTATP;
DSL_G997_LineFailures_t lineFailuresStatusGet;
DSL_G997_BF_LineFailures_t NearEndLOSFailure;
DSL_G997_BF_LineFailures_t FarEndLOSFailure;
DSL_G997_BF_LineFailures_t NearEndLOFFailure;
DSL_G997_BF_LineFailures_t FarEndLOFFailure;
//DSL_G997_BF_LineFailures_t NearEndLPRFailure;
DSL_G997_BF_LineFailures_t FarEndLPRFailure;
DSL_G997_DataPathFailures_t dataPathFailuresStatusGet;
DSL_G997_BF_DataPathFailures_t NearEndNCDFailure;
DSL_G997_BF_DataPathFailures_t FarEndNCDFailure;
DSL_G997_BF_DataPathFailures_t NearEndLCDFailure;
DSL_G997_BF_DataPathFailures_t FarEndLCDFailure;
//DSL_PM_ChannelCountersTotal_t pmChannelCountersTotal;
DSL_PM_ChannelCounters_t pmChannelCounters;     //Eros add for use SHOWTIME counter
DSL_PM_DataPathCounters_t pmDataPathCounters;   //Eros add for use SHOWTIME counter
DSL_uint32_t NearEndCRCFailure;
DSL_uint32_t FarEndCRCFailure;
DSL_uint32_t NearEndRSCorrectionFailure;
DSL_uint32_t FarEndRSCorrectionFailure;
DSL_uint32_t NearEndFECS;
DSL_uint32_t FarEndFECS;
DSL_PM_LineSecCountersTotal_t pmLineSecCountersTotal;
DSL_uint32_t NearEndES;
DSL_uint32_t FarEndES;
DSL_uint32_t NearEndSES;
DSL_uint32_t FarEndSES;
DSL_uint32_t NearEndLOSS;
DSL_uint32_t FarEndLOSS;
DSL_uint32_t NearEndUAS;
DSL_uint32_t FarEndUAS;
//DSL_PM_DataPathCountersTotal_t pmDataPathCountersTotal;
DSL_uint32_t NearEndHEC;
DSL_uint32_t FarEndHEC;

DSL_IN DSL_DeltDataType_t gDeltDataType = DSL_DELT_DATA_SHOWTIME;

        char buf[100];
        int fd = 0;
        int i;
#ifdef PLATFORM_VR9
        int iRet;
#endif
        char dev_name[64];
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
        int dsl_line = 0;
        char_t *dsl_line_str = NULL;

        dsl_line = atoi(dsl_line_str);
        if ((dsl_line != 0) && (dsl_line != 1)) {
                IFX_DBG(" Error !! Invalid DSL Line Number [%d] Passed in [%s]!!\n", dsl_line, __FUNCTION__);
                dsl_line = 0;
        }
        sprintf(dev_name, DSL_CPE_DEVICE_NAME"/%d", dsl_line);
#else
        sprintf(dev_name, DSL_CPE_DEVICE_NAME);
#endif
        // DSL_Open
        fd = open(dev_name, O_RDWR);
        if (fd < 0) {
                IFX_DBG("cannot open device %s\n", dev_name);
        }
        // Vendor ID
        memset(&lineInventoryGet, 0x00, sizeof(DSL_G997_LineInventory_t));
        lineInventoryGet.nDirection = DSL_FAR_END;
        ioctl(fd, DSL_FIO_G997_LINE_INVENTORY_GET, &lineInventoryGet);
        for (i = 0; i < DSL_G997_LI_MAXLEN_VENDOR_ID; i++) {
                FarEndSystemVendorID[i] =
                    lineInventoryGet.data.SystemVendorID[i];
        }
        // Version Number
        for (i = 0; i < DSL_G997_LI_MAXLEN_VERSION; i++) {
                FarEndVersionNumber[i] = lineInventoryGet.data.VersionNumber[i];
        }
        // Serial Number
        for (i = 0; i < DSL_G997_LI_MAXLEN_SERIAL; i++) {
                FarEndSerialNumber[i] = lineInventoryGet.data.SerialNumber[i];
        }

        // Modem Status
        memset(&lineState, 0x00, sizeof(DSL_LineState_t));
        ioctl(fd, DSL_FIO_LINE_STATE_GET, &lineState);

        // modem selected
        memset(&xtuSystemEnabling, 0x00, sizeof(DSL_G997_XTUSystemEnabling_t));
        ioctl(fd, DSL_FIO_G997_XTU_SYSTEM_ENABLING_STATUS_GET,
                    &xtuSystemEnabling);

#ifdef PLATFORM_VR9
        memset(&xtuBandPlanStatus, 0x00, sizeof(DSL_BandPlanStatus_t));
        iRet = ioctl(fd, DSL_FIO_BAND_PLAN_STATUS_GET, &xtuBandPlanStatus);
        if (iRet == 0) {
                if (xtuBandPlanStatus.accessCtl.nReturn != 0) {
                        xtuBandPlanStatus.data.nProfile = -1;
                }
        } else {
                if (xtuBandPlanStatus.accessCtl.nReturn != 0) {
                        xtuBandPlanStatus.data.nProfile = -1;
                }
        }
#endif

        // power management mode
        memset(&pwrMngStatus, 0x00, sizeof(DSL_G997_PowerManagementStatus_t));

            ioctl(fd, DSL_FIO_G997_POWER_MANAGEMENT_STATUS_GET, &pwrMngStatus);
        PowerManagementStatus = pwrMngStatus.data.nPowerManagementStatus;

        // trellis-coded modulation
        memset(&lineFeatureConfig, 0x00, sizeof(DSL_LineFeature_t));
        ioctl(fd, DSL_FIO_LINE_FEATURE_STATUS_GET, &lineFeatureConfig);

        // latency type 
        memset(&channelStatus, 0x00, sizeof(DSL_G997_ChannelStatus_t));
        ioctl(fd, DSL_FIO_G997_CHANNEL_STATUS_GET, &channelStatus);
        ActualInterleaveDelay = channelStatus.data.ActualInterleaveDelay;

        // Data Rate
        memset(&channelStatus, 0x00, sizeof(DSL_G997_ChannelStatus_t));
        channelStatus.nDirection = DSL_DOWNSTREAM;
        ioctl(fd, DSL_FIO_G997_CHANNEL_STATUS_GET, &channelStatus);
        DownStreamActualDataRate = channelStatus.data.ActualDataRate;

        memset(&channelStatus, 0x00, sizeof(DSL_G997_ChannelStatus_t));
        channelStatus.nDirection = DSL_UPSTREAM;
        ioctl(fd, DSL_FIO_G997_CHANNEL_STATUS_GET, &channelStatus);
        UpStreamActualDataRate = channelStatus.data.ActualDataRate;

        // Update G997LineStatus values for downstream
        memset(&lineStatus, 0x00, sizeof(DSL_G997_LineStatus_t));
        lineStatus.nDirection = DSL_DOWNSTREAM;
        lineStatus.nDeltDataType = gDeltDataType;
        ioctl(fd, DSL_FIO_G997_LINE_STATUS_GET, &lineStatus);
        // SNRds
        DownStreamSNR = lineStatus.data.SNR;

        // LATNds
        DownStreamLATN = lineStatus.data.LATN;

        // SATNds
        DownStreamSATN = lineStatus.data.SATN;

        // ACTATPds
        DownStreamACTATP = lineStatus.data.ACTATP;

        // ATTNDRds
        DownStreamATTNDR = lineStatus.data.ATTNDR;

        // Update G997LineStatus values for upstream
        memset(&lineStatus, 0x00, sizeof(DSL_G997_LineStatus_t));
        lineStatus.nDirection = DSL_UPSTREAM;
        lineStatus.nDeltDataType = gDeltDataType;
        ioctl(fd, DSL_FIO_G997_LINE_STATUS_GET, &lineStatus);
        // SNRus
        UpStreamSNR = lineStatus.data.SNR;

        // LATNus
        UpStreamLATN = lineStatus.data.LATN;

        // SATNus
        UpStreamSATN = lineStatus.data.SATN;

        // ACTATPus
        UpStreamACTATP = lineStatus.data.ACTATP;

        // ATTNDRus
        UpStreamATTNDR = lineStatus.data.ATTNDR;

        // DownStream (FarEnd) Interleaver Depth
        memset(&g997FramingParamStatusGet, 0x00,
               sizeof(DSL_G997_FramingParameterStatus_t));
        g997FramingParamStatusGet.nDirection = DSL_DOWNSTREAM;
        ioctl(fd, DSL_FIO_G997_FRAMING_PARAMETER_STATUS_GET,
                    &g997FramingParamStatusGet);
        DownStreamINTLVDEPTH = g997FramingParamStatusGet.data.nINTLVDEPTH;

        // RS Correction 
        FarEndRSCorrectionFailure = g997FramingParamStatusGet.data.nNFEC;

        // UpStream (NearEnd) Interleaver Depth
        memset(&g997FramingParamStatusGet, 0x00,
               sizeof(DSL_G997_FramingParameterStatus_t));
        g997FramingParamStatusGet.nDirection = DSL_UPSTREAM;
        ioctl(fd, DSL_FIO_G997_FRAMING_PARAMETER_STATUS_GET,
                    &g997FramingParamStatusGet);
        UpStreamINTLVDEPTH = g997FramingParamStatusGet.data.nINTLVDEPTH;

        // RS Correction 
        NearEndRSCorrectionFailure = g997FramingParamStatusGet.data.nNFEC;

        /* NearEnd G997LineFailures Status */
        // LOS
        memset(&lineFailuresStatusGet, 0x00, sizeof(DSL_G997_LineFailures_t));
        lineFailuresStatusGet.nDirection = DSL_NEAR_END;

            ioctl(fd, DSL_FIO_G997_LINE_FAILURES_STATUS_GET,
                  &lineFailuresStatusGet);
        NearEndLOSFailure = lineFailuresStatusGet.data.nLineFailures;

        // LOF
        NearEndLOFFailure = lineFailuresStatusGet.data.nLineFailures;

        // LPR
        FarEndLPRFailure = lineFailuresStatusGet.data.nLineFailures;

        /* FarEnd G997LineFailures Status */
        // LOS
        memset(&lineFailuresStatusGet, 0x00, sizeof(DSL_G997_LineFailures_t));
        lineFailuresStatusGet.nDirection = DSL_FAR_END;

            ioctl(fd, DSL_FIO_G997_LINE_FAILURES_STATUS_GET,
                  &lineFailuresStatusGet);
        FarEndLOSFailure = lineFailuresStatusGet.data.nLineFailures;

        // LOF
        FarEndLOFFailure = lineFailuresStatusGet.data.nLineFailures;

        // LPR
        FarEndLPRFailure = lineFailuresStatusGet.data.nLineFailures;

        /* NearEnd G997DathPathFailures Status */
        // NCD
        memset(&dataPathFailuresStatusGet, 0x00,
               sizeof(DSL_G997_DataPathFailures_t));
        dataPathFailuresStatusGet.nDirection = DSL_NEAR_END;
        ioctl(fd, DSL_FIO_G997_DATA_PATH_FAILURES_STATUS_GET,
                    &dataPathFailuresStatusGet);
        NearEndNCDFailure = dataPathFailuresStatusGet.data.nDataPathFailures;

        // LCD
        NearEndLCDFailure = dataPathFailuresStatusGet.data.nDataPathFailures;

        /* FarEnd G997DathPathFailures Status */
        // NCD
        memset(&dataPathFailuresStatusGet, 0x00,
               sizeof(DSL_G997_DataPathFailures_t));
        dataPathFailuresStatusGet.nDirection = DSL_FAR_END;
        ioctl(fd, DSL_FIO_G997_DATA_PATH_FAILURES_STATUS_GET,
                    &dataPathFailuresStatusGet);
        FarEndNCDFailure = dataPathFailuresStatusGet.data.nDataPathFailures;

        // LCD
        FarEndLCDFailure = dataPathFailuresStatusGet.data.nDataPathFailures;

        /* NearEnd PMChannelCounters */
        // CRC --Eros change to showtime counter only
        memset(&pmChannelCounters, 0x00, sizeof(DSL_PM_ChannelCounters_t));
        pmChannelCounters.nDirection = DSL_NEAR_END;
        ioctl(fd, DSL_FIO_PM_CHANNEL_COUNTERS_SHOWTIME_GET,
                  &pmChannelCounters);
        NearEndCRCFailure = pmChannelCounters.data.nCodeViolations;

        // FECS  ---- Eros change to showtime get only 
        NearEndFECS = pmChannelCounters.data.nFEC;

        /* FarEnd PMChannelCounters */
        //CRC
        memset(&pmChannelCounters, 0x00, sizeof(DSL_PM_ChannelCounters_t));
        pmChannelCounters.nDirection = DSL_FAR_END;

            ioctl(fd, DSL_FIO_PM_CHANNEL_COUNTERS_SHOWTIME_GET,
                  &pmChannelCounters);
        FarEndCRCFailure = pmChannelCounters.data.nCodeViolations;

        // FECS
        FarEndFECS = pmChannelCounters.data.nFEC;

        /* NearEnd PMLineSecCounters */
        // Errored Second
        memset(&pmLineSecCountersTotal, 0x00,
               sizeof(DSL_PM_LineSecCountersTotal_t));
        pmLineSecCountersTotal.nDirection = DSL_NEAR_END;
        ioctl(fd, DSL_FIO_PM_LINE_SEC_COUNTERS_TOTAL_GET,
                    &pmLineSecCountersTotal);
        NearEndES = pmLineSecCountersTotal.data.nES;;

        // Serverely Errored Second
        NearEndSES = pmLineSecCountersTotal.data.nSES;;

        // Loss of Signal Seconds 
        NearEndLOSS = pmLineSecCountersTotal.data.nLOSS;;

        // Unavailable Second
        NearEndUAS = pmLineSecCountersTotal.data.nUAS;;

        /* FarEnd PMLineSecCounters */
        // Errored Second
        memset(&pmLineSecCountersTotal, 0x00,
               sizeof(DSL_PM_LineSecCountersTotal_t));
        pmLineSecCountersTotal.nDirection = DSL_FAR_END;
        ioctl(fd, DSL_FIO_PM_LINE_SEC_COUNTERS_TOTAL_GET,
                    &pmLineSecCountersTotal);
        FarEndES = pmLineSecCountersTotal.data.nES;;

        // Serverely Errored Second
        FarEndSES = pmLineSecCountersTotal.data.nSES;;

        // Loss of Signal Seconds 
        FarEndLOSS = pmLineSecCountersTotal.data.nLOSS;;

        // Unavailable Second
        FarEndUAS = pmLineSecCountersTotal.data.nUAS;;

        /* SHOWTIME PMDataPathCounters */
        // HEC Error  ---- Eros change to showtime get only 
        memset(&pmDataPathCounters, 0x00, sizeof(DSL_PM_DataPathCounters_t));
        pmDataPathCounters.nDirection = DSL_NEAR_END;
        ioctl(fd, DSL_FIO_PM_DATA_PATH_COUNTERS_SHOWTIME_GET,
                    &pmDataPathCounters);
        NearEndHEC = pmDataPathCounters.data.nHEC;;

        memset(&pmDataPathCounters, 0x00, sizeof(DSL_PM_DataPathCounters_t));
        pmDataPathCounters.nDirection = DSL_FAR_END;
        ioctl(fd, DSL_FIO_PM_DATA_PATH_COUNTERS_SHOWTIME_GET,
                    &pmDataPathCounters);
        FarEndHEC = pmDataPathCounters.data.nHEC;;

        // close device
        close(fd);
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
        sprintf(buf, "echo 'linestate [%d]' > /tmp/dsl_log%d",
                lineState.data.nLineState, dsl_line);
#else
        sprintf(buf, "echo 'linestate [%d]' > /tmp/dsl_log",
                lineState.data.nLineState);
#endif
        system(buf);

switch (lineState.data.nLineState) {
        case DSL_LINESTATE_NOT_INITIALIZED:
                LTQ_STRNCPY(dsl_status, "NOT INITIALIZED", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_EXCEPTION:
                LTQ_STRNCPY(dsl_status, "EXCEPTION", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_IDLE_REQUEST:
                LTQ_STRNCPY(dsl_status, "IDLE_REQUEST", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_IDLE:
                LTQ_STRNCPY(dsl_status, "IDLE", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_SILENT_REQUEST:
               LTQ_STRNCPY(dsl_status, "SILENT_REQUEST", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_SILENT:
                LTQ_STRNCPY(dsl_status, "SILENT", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_HANDSHAKE:
                LTQ_STRNCPY(dsl_status, "HANDSHAKE", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_FULL_INIT:
                LTQ_STRNCPY(dsl_status, "FULL_INIT", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_DISCOVERY:
                LTQ_STRNCPY(dsl_status,"DISCOVERY", MAX_PARAMETER_KEY_LEN); 
                break;
        case DSL_LINESTATE_TRAINING:
                LTQ_STRNCPY(dsl_status, "TRAINING", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_ANALYSIS:
                LTQ_STRNCPY(dsl_status, "ANALYSIS", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_EXCHANGE:
                LTQ_STRNCPY(dsl_status, "EXCHANGE", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_SHOWTIME_NO_SYNC:
                LTQ_STRNCPY(dsl_status, "SHOWTIME, NO SYNC", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_SHOWTIME_TC_SYNC:
                LTQ_STRNCPY(dsl_status, "SHOWTIME, SYNC", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_FASTRETRAIN:
                LTQ_STRNCPY(dsl_status, "FASTRETRAIN", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_LOWPOWER_L2:
                LTQ_STRNCPY(dsl_status, "LOWPOWER_L2", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_LOOPDIAGNOSTIC_ACTIVE:
                LTQ_STRNCPY(dsl_status, "DIAGNOSTIC ACTIVE", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_LOOPDIAGNOSTIC_DATA_EXCHANGE:
                LTQ_STRNCPY(dsl_status, "DIAGNOSTIC_DATA_EXCHANGE", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_LOOPDIAGNOSTIC_DATA_REQUEST:
                LTQ_STRNCPY(dsl_status, "DIAGNOSTIC_DATA_REQUEST", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_LOOPDIAGNOSTIC_COMPLETE:
                LTQ_STRNCPY(dsl_status, "DIAGNOSTIC COMPLETE", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_RESYNC:
                LTQ_STRNCPY(dsl_status, "RESYNC", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_TEST:
                LTQ_STRNCPY(dsl_status, "TEST", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_TEST_LOOP:
                LTQ_STRNCPY(dsl_status, "TEST_LOOP", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_TEST_REVERB:
                LTQ_STRNCPY(dsl_status, "TEST_REVERB", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_TEST_MEDLEY:
                LTQ_STRNCPY(dsl_status, "TEST_MEDLEY", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_TEST_SHOWTIME_LOCK:
                LTQ_STRNCPY(dsl_status, "TEST_SHOWTIME_LOCK", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_TEST_QUIET:
                LTQ_STRNCPY(dsl_status, "TEST_QUITE", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_LOWPOWER_L3:
                LTQ_STRNCPY(dsl_status, "LOWPOWER_L3", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_UNKNOWN:
                LTQ_STRNCPY(dsl_status, "UNKNOWN", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_NOT_UPDATED:
                LTQ_STRNCPY(dsl_status, "NOT_UPDATED", MAX_PARAMETER_KEY_LEN);
                break;
        case DSL_LINESTATE_SHORT_INIT_ENTRY:
                LTQ_STRNCPY(dsl_status, "NOT_UPDATED", MAX_PARAMETER_KEY_LEN);
                break;
        default:
                break;
        }                       // switch     
        return 0;
}
#endif


int32 ltq_api_diag_get_default_RuntimeWanIPMask(WanIPMask * xIPMask, char *sMode)
{
        char_t  sTAG_NAME[MAX_NAME_SIZE],sValue[MAX_NAME_SIZE];
        char_t sCFG_NAME[MAX_NAME_SIZE], sNM[MAX_IP_ADDR_LEN];
        //IP_TYPE nWanType;
        uint32 outFlag = IFX_F_DEFAULT;
        //char *secName = NULL, sAtmProto[MAX_FILELINE_LEN], link_name[MAX_FILELINE_LEN];
       // int nWanMode = IP_BOOT_UNKNOWN;
        int j =0;
        char *def = "UNDEFINED";
        WAN_CONN_CFG wan_cfg;
        char wanConnName[MAX_CONN_NAME_LEN];
        WAN_PHY_CFG pstWanPhy;
        /* code for getting default wan index */
        IFX_ID iid;
        int32 nWAN_IDX = 0;

        /* Get current global wan mode */
        ifx_get_wan_phy_cfg(&pstWanPhy);

        xIPMask->wan_tc = pstWanPhy.wan_tc;

        memset(&iid, 0x00, sizeof(iid));
        if (ifx_get_default_wan_if(&iid, &nWAN_IDX, wanConnName, IFX_F_DEFAULT) != IFX_SUCCESS)
        {
                IFX_DBG("[%s:%d] [Failed to bring default wan index]",__FUNCTION__, __LINE__);
                return -1;
        }
        /*end */

        memset(&wan_cfg, 0x00, sizeof(wan_cfg));
        if (!strcmp(sMode, "IP")) 
        {
                sNM[0] = '\0';
                if (strstr(wanConnName, "WANIP")) 
                {
                        sprintf(sCFG_NAME, "WanIP%d_IF_Info", nWAN_IDX);
                        if (ifx_GetObjData(FILE_SYSTEM_STATUS, sCFG_NAME, sMode, IFX_F_GET_ENA,(IFX_OUT uint32 *) & outFlag,sNM) != IFX_SUCCESS)
                                strcpy(xIPMask->wan_ip, def);
                        else 
                                strcpy(xIPMask->wan_ip, sNM);

                } else if (strstr(wanConnName, "WANPPP")) {
                        sprintf(sCFG_NAME, "WanPPP%d_IF_Info", nWAN_IDX);
                        if (ifx_GetObjData(FILE_SYSTEM_STATUS, sCFG_NAME, sMode, IFX_F_GET_ENA,(IFX_OUT uint32 *) & outFlag,sNM) != IFX_SUCCESS)
                                strcpy(xIPMask->wan_ip, def);
                        else 
                                strcpy(xIPMask->wan_ip, sNM);
                }
        }
        else if (!strcmp(sMode, "STATUS"))
        {
                sValue[0] = '\0';
                if (strstr(wanConnName, "WANIP")) {
                        sprintf(sTAG_NAME, "WanIP%d_IF_Info", nWAN_IDX);
                        if (ifx_GetObjData(FILE_SYSTEM_STATUS, sTAG_NAME,sMode,IFX_F_GET_ENA,(IFX_OUT uint32 *) & outFlag,sValue) != IFX_SUCCESS)
                        {
                                for (j = 1; sValue[j] != '\0'; j++)
                                {
                                        if (sValue[j] >= 65 && sValue[j] <= 91)
                                                sValue[j] = sValue[j] + 32;
                                        }
                                strcpy(xIPMask->wan_status, def);
                        }
                        else
                                strcpy(xIPMask->wan_status, sValue);
                }
                if (strstr(wanConnName, "WANPPP"))
                {
                        snprintf(sTAG_NAME, sizeof(sTAG_NAME),"WanPPP%d_IF_Info", nWAN_IDX);
                        if (ifx_GetObjData(FILE_SYSTEM_STATUS, sTAG_NAME,sMode,IFX_F_GET_ENA,(IFX_OUT uint32 *) & outFlag,sValue) != IFX_SUCCESS)
                        {
                                for (j = 1; sValue[j] != '\0'; j++)
                                {
                                        if (sValue[j] >= 65 && sValue[j] <= 91)
                                                sValue[j] = sValue[j] + 32;
                                        }
                                strcpy(xIPMask->wan_status, def);
                        }
                        else
                                strcpy(xIPMask->wan_status, sValue);
                }

      } 
#if 0
               else if (!strcmp(sMode, "Mode")) {
                link_name[0] = '\0';
                sAtmProto[0] = '\0';
                if (strstr(wanConnName, "WANIP"))
                {
                        wan_cfg.type = WAN_TYPE_IP;
                        secName = TAG_WAN_IP;
                        sprintf(sTAG_NAME, "wanip_%d_linkType", nWAN_IDX);
                } else if (strstr(wanConnName, "WANPPP"))
                {
                        wan_cfg.type = WAN_TYPE_PPP;
                        secName = TAG_WAN_PPP;
                        sprintf(sTAG_NAME, "wanppp_%d_linkType", nWAN_IDX);
                }
                if (ifx_GetObjData(FILE_RC_CONF, secName, sTAG_NAME, IFX_F_DEFAULT,(IFX_OUT uint32 *) & outFlag, sAtmProto) != IFX_SUCCESS)
                {
                        strcpy(xIPMask->atm_proto, "");
                        IFX_DBG("[%s:%d] [Failed to bring default wan atmproto]",__FUNCTION__, __LINE__);
                }
                else
                {
                        get_atm_proto_name_by_id(link_name, atoi(sAtmProto));
                        strcpy(xIPMask->atm_proto, link_name);
                }

                if ( pstWanPhy.phy_mode == WAN_PHY_MODE_CELL_WAN && nWAN_IDX == 0)
                {
                        nWanMode = IP_BOOT_WWAN;
                        xIPMask->wan_type= nWanMode;
                }
                else
                {
                       if ((nWanMode = getWanMode(nWAN_IDX, wan_cfg.type)) == IFX_FAILURE)
                        {
                                IFX_DBG("[%s:%d] [Failed to get wan mode of default wan]", __FUNCTION__, __LINE__);
                        }
                        else
                        {
                                if (nWanMode == IP_BOOT_ETH || nWanMode == IP_BOOT_PTM)
                                {
                                        if (ifx_get_wanip_conn_type(&nWanType,nWAN_IDX) == IFX_SUCCESS)
                                        {
                                                switch (nWanType)
                                                {
                                                                case IP_TYPE_DHCP:
                                                                        nWanMode = IP_BOOT_DHCPC;
                                                                break;
                                                                case IP_TYPE_STATIC:
                                                                        nWanMode = IP_BOOT_FIXED;
                                                                break;
                                                                case IP_TYPE_AUTO:
                                                                        nWanMode = IP_BOOT_BRIDGE;
                                                                break;
                                                }
                                        }
                                }
                        xIPMask->wan_type = nWanMode;
                        }
                }
        } 
#endif
        return 0;
}


int32 ltq_api_diag_get_wlan_enable(DIAGNOSTICS_TEST_SUITE * pxDiagTest)
{
#ifdef CONFIG_FEATURE_IFX_WIRELESS
        IFX_MAPI_WLAN_PhyCfg wlan_phy;
        int32 iI = 0, ret = IFX_SUCCESS;
        uint32 flags = IFX_F_DEFAULT;

        IFX_MAPI_DEBUG(fd, "/tmp/ifx_diag_get_wlan_enable","");
        memset(&wlan_phy, 0, sizeof(IFX_MAPI_WLAN_PhyCfg));
    
        for (iI = 1; iI <= 2; iI++)
        {
          sprintf(wlan_phy.iid.cpeId.secName, "%s", TAG_WLAN_PHY);
          sprintf(wlan_phy.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
          wlan_phy.iid.cpeId.Id = iI;
          if ((ret =
               ifx_mapi_get_wlan_phy_config(&wlan_phy, flags)) != IFX_SUCCESS) {
                  IFX_DBG("Failed to get wlan radio configuration[%s : %d]\n", __func__,__LINE__);
                  return IFX_FAILURE;
          } else {
                  memcpy(&g_wlPhy[0], &wlan_phy, sizeof(IFX_MAPI_WLAN_PhyCfg));
          }
          IFX_MAPI_DEBUG(fd, "/tmp/ifx_diag_get_wlan_enable",
                         "radioEnable: %d", wlan_phy.radioEnable);

          /* now get the dynamical information */
          if ((ret = ifx_mapi_get_wlan_dyn_phy_config(&wlan_phy, IFX_F_DEFAULT)
                          != IFX_SUCCESS)) {
                              IFX_DBG("Failed to get dynamic wlan radio configuration [%s : %d]\n", __func__,__LINE__);
                  return IFX_FAILURE;
          }
          IFX_MAPI_DEBUG(fd, "/tmp/ifx_diag_get_wlan_enable",
                         "status: %d", wlan_phy.status);
          if(wlan_phy.iid.cpeId.Id == 1)
          {
              if (wlan_phy.radioEnable && wlan_phy.status)
                     pxDiagTest->wlan0 = 1;
              else
                     pxDiagTest->wlan0 = 0;
          }
          else if(wlan_phy.iid.cpeId.Id == 2)
          {
              if (wlan_phy.radioEnable && wlan_phy.status)
                     pxDiagTest->wlan1 = 1;
              else
                     pxDiagTest->wlan1 = 0;
          }
       }
#endif

     return 0;
}

int32 ltq_mapi_performtest(DIAGNOSTICS_TEST_SUITE * pxDiagTestQuery)
{
     char8  sValue[16] = { 0 };
#if defined(CONFIG_PACKAGE_IFX_DSL_CPE_API)
     char_t status[64] = { 0 };
#endif
     WanIPMask xIPMask;

     memset(&pxDiagTestQuery->caResult, 0x00, sizeof(pxDiagTestQuery));
     memset(&xIPMask, 0x00, sizeof(WanIPMask));

     if ((pxDiagTestQuery->diag_test_cnt & LTQ_CHECK_ALL) || (pxDiagTestQuery->diag_test_cnt & LTQ_CHECK_LANSATUS))
     {
	     ltq_api_diag_get_lan_status(pxDiagTestQuery);

             if(pxDiagTestQuery->enet_lan0_status == 1)
                     strcat(pxDiagTestQuery->caResult, "LAN0_status - UP;");
             else
                     strcat(pxDiagTestQuery->caResult, "LAN0_status - DOWN;");

             if(pxDiagTestQuery->enet_lan1_status == 1)
                     strcat(pxDiagTestQuery->caResult, " LAN1_status - UP;");
             else
                     strcat(pxDiagTestQuery->caResult, " LAN1_status - DOWN;");

             if(pxDiagTestQuery->enet_lan2_status == 1)
                     strcat(pxDiagTestQuery->caResult, " LAN2_status - UP;");
             else
                     strcat(pxDiagTestQuery->caResult, " LAN2_status - DOWN;");

             if(pxDiagTestQuery->enet_lan3_status == 1)
                    strcat(pxDiagTestQuery->caResult, " LAN3_status - UP;");
             else
                    strcat(pxDiagTestQuery->caResult, " LAN3_status - DOWN;");
     }

     if ((pxDiagTestQuery->diag_test_cnt & LTQ_CHECK_ALL) || (pxDiagTestQuery->diag_test_cnt & LTQ_CHECK_WANSTATUS))
     {
             strcpy(sValue, "STATUS");
	     ltq_api_diag_get_default_RuntimeWanIPMask(&xIPMask, sValue); //WAN STATUS &ATM or PTM

                    pxDiagTestQuery->encap = xIPMask.wan_tc;
                    if(pxDiagTestQuery->encap == WAN_TC_ATM)
                         strcat(pxDiagTestQuery->caResult, " Encapsulation Type - ATM;");
                    else if(pxDiagTestQuery->encap == WAN_TC_PTM)
                         strcat(pxDiagTestQuery->caResult, " Encapsulation Type - PTM;");

                    if(strcmp(xIPMask.wan_status," CONNECTED"))
                    {
                         pxDiagTestQuery->wan_conn_status = 1;
                         strcat(pxDiagTestQuery->caResult, " WAN - CONNECTED;");
                    }
                    else
                    {
                         pxDiagTestQuery->wan_conn_status = 0; 
                         strcat(pxDiagTestQuery->caResult, " WAN - DISCONNECTED;");
                    }
// Note : Not needed from TR69 point of view
/*
             strcpy(sValue, "Mode");             
	     ltq_api_diag_get_default_RuntimeWanIPMask(&xIPMask, sValue); //WAN MODE
*/
     }

     if ((pxDiagTestQuery->diag_test_cnt & LTQ_CHECK_ALL) || (pxDiagTestQuery->diag_test_cnt & LTQ_CHECK_WLANSTATUS))
     {
	     ltq_api_diag_get_wlan_enable(pxDiagTestQuery);

                    if(pxDiagTestQuery->wlan0 == 1)
                         strcat(pxDiagTestQuery->caResult, " WLAN0 - UP;");
                    else
                         strcat(pxDiagTestQuery->caResult, " WLAN0 - DOWN;");

#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
                    if(pxDiagTestQuery->wlan1 == 1)
                         strcat(pxDiagTestQuery->caResult, " WLAN1 - UP;");
                    else
                         strcat(pxDiagTestQuery->caResult, " WLAN1 - DOWN;");
#else
                         strcat(pxDiagTestQuery->caResult, " WLAN1 - Not Supported;");
#endif
     }

#if defined(CONFIG_PACKAGE_IFX_DSL_CPE_API)
     if ((pxDiagTestQuery->diag_test_cnt & LTQ_CHECK_ALL) || (pxDiagTestQuery->diag_test_cnt & LTQ_CHECK_DSLSTATUS))
     {
	     ltq_api_diag_get_adsl_status(status);

                    if(!strcmp(status , "SHOWTIME, SYNC"))
                         strcat(pxDiagTestQuery->caResult, " xDSL - PASS;");
                    else
                         strcat(pxDiagTestQuery->caResult, " xDSL - FAIL;");
     }
#endif

     if ((pxDiagTestQuery->diag_test_cnt & LTQ_CHECK_ALL) || (pxDiagTestQuery->diag_test_cnt & LTQ_CHECK_LANPING))
     {
	     ltq_api_diag_perform_lan_ping(pxDiagTestQuery);
     
	     if(pxDiagTestQuery->lan_conn_status == 1)
                         strcat(pxDiagTestQuery->caResult, " LAN PING - PASS;");
	     else
                         strcat(pxDiagTestQuery->caResult, " LAN PING - FAIL;");
     }

     if ((pxDiagTestQuery->diag_test_cnt & LTQ_CHECK_ALL) || (pxDiagTestQuery->diag_test_cnt & LTQ_CHECK_WANPING))
     {
	     ltq_api_diag_perform_wan_ping(pxDiagTestQuery);

             if(pxDiagTestQuery->wan_gw == 1)
                         strcat(pxDiagTestQuery->caResult, " WAN GateWay Ping - PASS;");
             else
                         strcat(pxDiagTestQuery->caResult, " WAN GateWay Ping - FAIL;");
     }

     if ((pxDiagTestQuery->diag_test_cnt & LTQ_CHECK_ALL) || (pxDiagTestQuery->diag_test_cnt & LTQ_CHECK_DNSPING1))
     {
	     strcpy(sValue, "1");
	     ltq_api_diag_perform_dnsping(pxDiagTestQuery,sValue);

             if(pxDiagTestQuery->dns1 == 1)
                         strcat(pxDiagTestQuery->caResult, " DNS1 Ping - PASS;");
             else
                         strcat(pxDiagTestQuery->caResult, " DNS1 Ping - FAIL;");

             if(pxDiagTestQuery->dns2 == 1)
                         strcat(pxDiagTestQuery->caResult, " DNS2 Ping - PASS;");
             else
                         strcat(pxDiagTestQuery->caResult, " DNS2 Ping - FAIL;");
     }

#if 0
     if (pxDiagTestQuery->diag_test_cnt & LTQ_CHECK_OAM)
     {
	     ltq_diag_oam_ping();

     }
#endif

     return 0;
}


/*--------------------------------------------------------------------*/
/*--- checksum - standard 1s complement checksum                   ---*/
/*--------------------------------------------------------------------*/
unsigned short checksum(void *b, int len)
{
    unsigned short *buf = b;
    unsigned int sum=0;
    unsigned short result;

    for ( sum = 0; len > 1; len -= 2 )
        sum += *buf++;
    if ( len == 1 )
        sum += *(unsigned char*)buf;
    sum = (sum >> 16) + (sum & 0xFFFF);
    sum += (sum >> 16);
    result = ~sum;
    return result;
}


/*--------------------------------------------------------------------*/
/*--- ping - Create message and send it.                           ---*/
/*    return 0 is ping Ok, return 1 is ping not OK.                ---*/
/*--------------------------------------------------------------------*/
int ping_ipaddress(char *address, uint32 timeout, int num_ping)
{
    const int val=255;
    int i, sd, ret = 0;
    struct packet pckt;
    struct sockaddr_in r_addr;
    int loop;
    struct hostent *hname;
    struct sockaddr_in addr_ping,*addr;

    pid = getpid();
    proto = getprotobyname("ICMP");
    hname = gethostbyname(address);
    bzero(&addr_ping, sizeof(addr_ping));
    addr_ping.sin_family = hname->h_addrtype;
    addr_ping.sin_port = 0;
    addr_ping.sin_addr.s_addr = *(long*)hname->h_addr;

    addr = &addr_ping;

    sd = socket(PF_INET, SOCK_RAW, proto->p_proto);
    if ( sd < 0 )
    {
        perror("socket");
        ret = 1;
        goto errorHandler;
    }
    if ( setsockopt(sd, SOL_IP, IP_TTL, &val, sizeof(val)) != 0)
    {
        perror("Set TTL option");
        ret = 1;
        goto errorHandler;
    }
    if ( fcntl(sd, F_SETFL, O_NONBLOCK) != 0 )
    {
        perror("Request nonblocking I/O");
        ret = 1;
        goto errorHandler;
    }

    for (loop=0;loop < num_ping; loop++)
    {
        socklen_t len=sizeof(r_addr);

        if ( recvfrom(sd, &pckt, sizeof(pckt), 0, (struct sockaddr*)&r_addr, &len) > 0 )
        {
            close(sd);
            ret = 0;
            goto errorHandler;
        }

        bzero(&pckt, sizeof(pckt));
        pckt.hdr.type = ICMP_ECHO;
        pckt.hdr.un.echo.id = pid;
        for ( i = 0; i < sizeof(pckt.msg)-1; i++ )
            pckt.msg[i] = i+'0';
        pckt.msg[i] = 0;
        pckt.hdr.un.echo.sequence = cnt++;
        pckt.hdr.checksum = checksum(&pckt, sizeof(pckt));

        if ( sendto(sd, &pckt, sizeof(pckt), 0, (struct sockaddr*)addr, sizeof(*addr)) <= 0 )
        {
            perror("sendto");
            ret = 1;
            goto errorHandler;
        }
        usleep(timeout);
    }
    ret = 1;
    goto errorHandler;

errorHandler:
    if (sd > 0)
       close(sd);

    return ret;
}
