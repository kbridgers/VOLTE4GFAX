#include <stdio.h>
#include <stdlib.h>
#include "ifx_amazon_cfg.h"
#include "ifx_config.h"
#include "ifx_common.h"
#include "ifx_api_util.h"
#include "ifx_emf.h"
#include <string.h>
#include <sys/time.h>
#include <signal.h>

#define MAX_LIST_LIMIT 50
#define MAX_FIELD_LEN   128
#define MAX_MAC_ADDR	50
#define TAG_AD_STATUS "autodetect_status"
#define TAG_VCC_POOL  "vcc_pool"
#ifdef IFX_DBG
#undef IFX_DBG
#define IFX_DBG printf
#endif
#define SYS_CMD(x) system(x)

#define BRINGUP_WAN_SERVICES { \
		char command[MAX_FILELINE_LEN]; \
		sprintf(command, "/etc/rc.d/rc.bringup_l2if start"); \
		system(command); \
		sprintf(command, "/etc/rc.d/rc.bringup_wan start"); \
		system(command); \
}

#define BRINGDOWN_WAN_SERVICES { \
		char command[MAX_FILELINE_LEN]; \
		sprintf(command, "/etc/rc.d/rc.bringup_wan stop"); \
		system(command); \
		sprintf(command, "/etc/rc.d/rc.bringup_l2if stop"); \
		system(command); \
}

#define STOP_ATM_L2_SERVICE { \
		system("br2684ctl -k 0;killall -9 br2684ctld;rm -f /var/run/br2684ctld.pid"); \
}

#define STOP_VLAN_SERVICE(vlan_list) { \
	char8 *ptr_t = NULL, *vlan_IDX = NULL, vlan_pool[MAX_DATA_LEN], cmd_buf[MAX_FILELINE_LEN]; \
	memset(vlan_pool, 0, sizeof(vlan_pool)); \
	LTQ_STRNCPY(vlan_pool, vlan_list, strlen(vlan_list)+1); \
	vlan_IDX = strtok_r(vlan_pool, ",", &ptr_t); \
	while(vlan_IDX != NULL) { \
		if(strcmp(vlan_IDX, "-1")) { \
			if(wanMode == WAN_MODE_PTM || wanMode == WAN_MODE_VDSL_PTM) \
				sprintf(cmd_buf,"/etc/rc.d/delete_ptm_if %s %s", "ptm0", vlan_IDX); \
			else if(wanMode == WAN_MODE_ETH1) \
				sprintf(cmd_buf,"/etc/rc.d/delete_eth_if %s %s", "eth1", vlan_IDX); \
			else if(wanMode == WAN_MODE_ETH0) \
				sprintf(cmd_buf,"/etc/rc.d/delete_eth_if %s %s", "eth0", vlan_IDX); \
			system(cmd_buf); \
		} \
		vlan_IDX = strtok_r(NULL, ",", &ptr_t); \
	} \
}

#define STOP_SERVICES { \
	if(wanMode == WAN_MODE_ATM) \
		STOP_ATM_L2_SERVICE \
	else { \
		char8 vlan_list[MAX_POOL_LIMIT]; \
		if(wanMode == WAN_MODE_PTM) \
			LTQ_STRNCPY(vlan_list, auto_dt.auto_detect_ADSL_PTM_VlanId, MAX_POOL_LIMIT); \
		else if(wanMode == WAN_MODE_VDSL_PTM) \
			LTQ_STRNCPY(vlan_list, auto_dt.auto_detect_VDSL_PTM_VlanId, MAX_POOL_LIMIT); \
		else if(wanMode == WAN_MODE_ETH1) \
			LTQ_STRNCPY(vlan_list, auto_dt.auto_detect_ETH1_VlanId, MAX_POOL_LIMIT); \
		else if(wanMode == WAN_MODE_ETH0) \
			LTQ_STRNCPY(vlan_list, auto_dt.auto_detect_ETH0_VlanId, MAX_POOL_LIMIT); \
		STOP_VLAN_SERVICE(vlan_list) \
	} \
	system("killall udhcpc pppd"); \
}

extern int ltq_mapi_get_autodetect_config(auto_detect_cfg_t *config);

auto_detect_cfg_t		auto_dt;
WAN_MODE						wanMode = WAN_MODE_ATM;
int									status_atm_l2 = 0;
int									oamArr_idx = 0;
int									status_ad = -1;
char								MAC_ADDR[MAX_MAC_ADDR];
char								WAN_CONN[MAX_POOL_LIMIT];
char								VCC_VALUE[MAX_POOL_LIMIT] = "vcc";
char								PROBE_VLAN[MAX_POOL_COUNT] = "vlan";
struct oam_result {
	char8 vc[10];
	int8 result;
} oamArr[10];

static void auto_detect_terminate()
{
	FILE *fp = NULL;
	char	strpid[MAX_FILELINE_LEN];

	printf("WAN auto-detect : Terminate Signal Caught.. Exiting\n");
	if(status_ad == 0) {
		/* auto-detect has completed probing and is in configuration stage */
		/* 1. if back-up rc.conf exists, restore it
		 * 2. if auto-detect is running, stop
		 * 3. remove status from system_status
		 */
		fp = popen("ps | grep -e 'ifx_event_util AUTODETECT COMPLETE' | awk '{print $1}'", "r");
		if(fp != NULL) {
			fread(strpid, sizeof(strpid), 1, fp);
			kill(atoi(strpid), SIGTERM);
			kill(atoi(strpid), SIGKILL);
		}

		/* Restore back-up file to /flash/rc.conf and flash partition */
		rename(FILE_AUTO_DETECT_BACKUP, FILE_AUTO_DETECT);

		/* Bring-down L2 and L3 configuration */
		BRINGDOWN_WAN_SERVICES

		ifx_config_write(FILE_AUTO_DETECT, IFX_F_MODIFY);
	}
	else {
		/* auto-detect is in probing stage */
		STOP_SERVICES
	}

	/* Restore system_status file */
	rename("/tmp/auto_detect_status", "/tmp/system_status");

	remove(FILE_AUTO_DETECT_PID);

	exit(0);
}

int do_vc_oam_ping(char vc[])
{
				char vpi[MAX_POOL_COUNT], vci[MAX_POOL_COUNT], sBuf1[MAX_FILELINE_LEN], sBuf2[MAX_FILELINE_LEN];
				unsigned int cells_tx, cells_rx, min_resp, max_resp, avg_resp, ping_timeout;
				int ret = IFX_SUCCESS, i = 0;

				memset(vpi, 0x00, sizeof(vpi)); 
				memset(vci, 0x00, sizeof(vci));

				for(i=0; i<oamArr_idx; i++) {
								if(!strcmp(oamArr[i].vc, vc)) {
												return oamArr[i].result;
								}
				}

				/* fill values needed for ifx_oam_f5_ping function */
				ping_timeout = 500;
				cells_tx = 2;
				cells_rx = min_resp = max_resp = avg_resp = 0;

				STOP_ATM_L2_SERVICE
				sscanf(vc, "%[^/]/%s", vpi, vci);
				sprintf(sBuf1,"%s.%s",vpi,vci);
				sprintf(sBuf2, "/usr/sbin/br2684ctl -b -p 1 -c 0 -e 0 -q 1 -a %s -s 65536", sBuf1);
				printf("command [%s]\n", sBuf2);
				SYS_CMD(sBuf2);
				sprintf(sBuf1,"sleep 1;ifconfig nas0 hw ether %s;ifconfig nas0 up",MAC_ADDR);
				SYS_CMD(sBuf1);
				/* OAMF5 ping start */
				IFX_DBG("OAM F5 ping start for  vpi[%s] vci[%s]\n",vpi,vci);
				ret = ifx_oam_f5_ping(atoi(vpi), atoi(vci), 4, ping_timeout, cells_tx,(int *)&cells_rx, (int *)&min_resp,(int *)&max_resp, (int *)&avg_resp);
				if(ret != IFX_SUCCESS)
				{}
				sprintf(oamArr[oamArr_idx].vc, "%s", vc);
				if(cells_rx != 0) {
								oamArr[oamArr_idx++].result = 0;
								return IFX_SUCCESS;
				}
				else {
								oamArr[oamArr_idx++].result = 1;
								return IFX_FAILURE;
				}
}

/* possible return values are,
	atoi(sValue) - 0 : WAN test unsuccessful
							 - 1 : WAN test successful
	IFX_FAILURE			 : Failure
 */
int do_wan_connect_test(char *wantype, char *ptm_vlan)
{
				char sBuf1[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
				int ret_val = IFX_FAILURE;

				if(!strcmp(wantype, "pppoe")) {
								IFX_DBG("[%s:%d] PPPoE probing start\n", __FUNCTION__, __LINE__);
								sleep(1);
								if(wanMode == WAN_MODE_ATM) {
												sprintf(sBuf1, "/usr/sbin/pppoe-discovery -I nas0 2>/dev/null >/dev/null");
								}
								else if(wanMode == WAN_MODE_PTM || wanMode == WAN_MODE_VDSL_PTM){
												/* PTM mode, vlan is -1 means untagged mode probing */
												if(!strcmp(ptm_vlan, "-1")) {
																sprintf(sBuf1, "/usr/sbin/pppoe-discovery -I ptm0 2>/dev/null >/dev/null");
												}
												else {
																sprintf(sBuf1, "/usr/sbin/pppoe-discovery -I ptm0.%s 2>/dev/null >/dev/null",ptm_vlan);
												}
								}
								else if(wanMode == WAN_MODE_ETH1){
												/* ETH1 mode, vlan is -1 means untagged mode probing */
												if(!strcmp(ptm_vlan, "-1")) {
																sprintf(sBuf1, "/usr/sbin/pppoe-discovery -I eth1 2>/dev/null >/dev/null");
												}
												else {
																sprintf(sBuf1, "/usr/sbin/pppoe-discovery -I eth1.%s 2>/dev/null >/dev/null",ptm_vlan);
												}
								}
								else if(wanMode == WAN_MODE_ETH0){
												if(!strcmp(ptm_vlan, "8")) {
#if 0
																sprintf(sBuf1, "/usr/sbin/pppd linkname pppoe lcp-echo-interval 30 lcp-echo-failure 4 unit 3 maxfail 1 usepeerdns noipdefault user %s password %s mtu 1492 mru 1492 holdoff 4 persist plugin /usr/lib/pppd/*/rp-pppoe.so updetach eth0 2>/dev/null >/dev/null", auto_dt.auto_detect_ppp_user, auto_dt.auto_detect_ppp_pass);
#endif
												}
												else {
																sprintf(sBuf1, "/usr/sbin/pppoe-discovery -I eth0.%s 2>/dev/null >/dev/null",ptm_vlan);
												}
								}
								ret_val = SYS_CMD(sBuf1);
								/*manohar : pppoe_status need to be removed in future*/
								if(ret_val == 0){
									sprintf(sValue, "pppoe_status=\"%d\"\n",1);
									ifx_SetObjData(FILE_SYSTEM_STATUS, TAG_AD_STATUS, IFX_F_MODIFY, 1, sValue);
								}

								sleep(2);
								ifx_GetCfgData(FILE_SYSTEM_STATUS, "autodetect_status", "pppoe_status", sValue);
								if(atoi(sValue) == 1) {
										if(wanMode == WAN_MODE_ATM)
												IFX_DBG("[%s:%d] PPPoE probing succeess VCC_VALUE [%s]\n", __FUNCTION__, __LINE__,VCC_VALUE);
										else
												IFX_DBG("[%s:%d] PPPoE probing succeess VLAN [%s]\n", __FUNCTION__, __LINE__,ptm_vlan);
								}
								else {
										if(wanMode == WAN_MODE_ATM)
												IFX_DBG("[%s:%d] PPPoE probing failed VCC_VALUE [%s]\n", __FUNCTION__, __LINE__,VCC_VALUE);
										else
												IFX_DBG("[%s:%d] PPPoE probing failed VLAN [%s]\n", __FUNCTION__, __LINE__,ptm_vlan);
								}
								return (atoi(sValue));
				}
				else if(!strcmp(wantype, "dhcp")) {
								usleep(1500000);
								if(wanMode == WAN_MODE_ATM) {
												SYS_CMD("/sbin/udhcpc -n -i nas0 -p /var/run/udhcpc.pid -s /etc/rc.d/udhcpc_ad");
								}
								else if(wanMode == WAN_MODE_PTM || wanMode == WAN_MODE_VDSL_PTM){
												/* PTM mode, vlan is -1 means untagged mode probing */
												if(!strcmp(ptm_vlan, "-1")) {
																sprintf(sBuf1, "%s", "/sbin/udhcpc -n -i ptm0 -p /var/run/udhcpc.pid -s /etc/rc.d/udhcpc_ad");
												}
												else {
																sprintf(sBuf1, "/sbin/udhcpc -n -i ptm0.%s -p /var/run/udhcpc.pid -s /etc/rc.d/udhcpc_ad", ptm_vlan);
												}
												SYS_CMD(sBuf1);
								}
								else if(wanMode == WAN_MODE_ETH1){
												/* ETH mode, vlan is -1 means untagged mode probing */
												if(!strcmp(ptm_vlan, "-1")) {
																sprintf(sBuf1, "%s", "/sbin/udhcpc -n -i eth1 -p /var/run/udhcpc.pid -s /etc/rc.d/udhcpc_ad");
												}
												else {
																sprintf(sBuf1, "/sbin/udhcpc -n -i eth1.%s -p /var/run/udhcpc.pid -s /etc/rc.d/udhcpc_ad", ptm_vlan);
												}
												SYS_CMD(sBuf1);
								}
								else if(wanMode == WAN_MODE_ETH0){
												/* ETH0 mode, vlan is 8 means untagged mode probing */
												if(!strcmp(ptm_vlan, "8")) {
#if 0
																sprintf(sBuf1, "%s", "/sbin/udhcpc -n -i eth0 -p /var/run/udhcpc.pid -s /etc/rc.d/udhcpc_ad");
#endif
												}
												else {
																sprintf(sBuf1, "/sbin/udhcpc -n -i eth0.%s -p /var/run/udhcpc.pid -s /etc/rc.d/udhcpc_ad", ptm_vlan);
												}
												SYS_CMD(sBuf1);
								}
								ifx_GetCfgData(FILE_SYSTEM_STATUS, "autodetect_status", "dhcp_status", sValue);
								if(atoi(sValue) == 1) {
										if(wanMode == WAN_MODE_ATM)
												IFX_DBG("[%s:%d] DHCP probing succeess VCC_VALUE [%s]\n", __FUNCTION__, __LINE__,VCC_VALUE);
										else
												IFX_DBG("[%s:%d] DHCP probing succeess VLAN [%s]\n", __FUNCTION__, __LINE__,ptm_vlan);
								}
								else {
										if(wanMode == WAN_MODE_ATM)
												IFX_DBG("[%s:%d] DHCP probing failed VCC_VALUE [%s]\n", __FUNCTION__, __LINE__,VCC_VALUE);
										else
												IFX_DBG("[%s:%d] DHCP probing failed VLAN [%s]\n", __FUNCTION__, __LINE__,ptm_vlan);
								}
								return (atoi(sValue));
				}

				return IFX_FAILURE;
}

int probe_wantype(char *wantype, char *ptm_vlan)
{
				int ret = 1;
				char sBuf1[MAX_FILELINE_LEN];

				if(wanMode == WAN_MODE_PTM || wanMode == WAN_MODE_VDSL_PTM) {
								sprintf(sBuf1,"/sbin/vconfig add ptm0 %s;/sbin/ifconfig ptm0.%s up", ptm_vlan, ptm_vlan);
								SYS_CMD(sBuf1);
				}

				if(wanMode == WAN_MODE_ETH1) {
								sprintf(sBuf1,"/sbin/vconfig add eth1 %s;/sbin/ifconfig eth1.%s up", ptm_vlan, ptm_vlan);
								SYS_CMD(sBuf1);
				}

				if(wanMode == WAN_MODE_ETH0) {
								sprintf(sBuf1,"/sbin/vconfig add eth0 %s;/sbin/ifconfig eth0.%s up", ptm_vlan, ptm_vlan);
								SYS_CMD(sBuf1);
				}

				ret = do_wan_connect_test(wantype, ptm_vlan);
				if(ret == 1) {
								sprintf(WAN_CONN, wantype);
								ret = IFX_SUCCESS;
				}
				else {
								ret = IFX_FAILURE;
				}

				return ret;
}

/* this function is called only when L3 auto-detect is enabled */
int probe_wan_conn()
{
				char vlan_ad[MAX_DATA_LEN];
				char vpi[MAX_POOL_COUNT], vci[MAX_POOL_COUNT], *vlan_IDX = NULL;
				char ptm_vlan[MAX_POOL_LIMIT];
				char *vlan[MAX_DATA_LEN], *tptr = NULL;
				int ret = 1, vlan_count = 0, i=0, idx_count =0, status = 1;
				char sBuf1[MAX_FILELINE_LEN], sBuf2[MAX_FILELINE_LEN];
				unsigned int flags = IFX_F_DEFAULT;
				FILE *fp;
				vlan_ch_cfg_t *vlan_chcfg = NULL;

				memset(vpi, 0x00, sizeof(vpi));
				memset(vci, 0x00, sizeof(vci));

				if(wanMode == WAN_MODE_ATM) {
								/* probe previously detected WAN mode, if fails return so that normal probing (both L2 & L3) can be re-started */
								if(strlen(WAN_CONN)) {
												ret = do_wan_connect_test(WAN_CONN, "-1");
												if(ret == 1) {
																ret = IFX_SUCCESS;
												}
												else {
																ret = IFX_FAILURE;
												}
												if(auto_dt.auto_detect_L2 == 1)
													return ret;
												
								}
								if(ret == IFX_FAILURE || !strlen(auto_dt.auto_detect_prev_val)){
												/* probe for PPPoE first, if it fails then try DHCP */
												ret = do_wan_connect_test("pppoe", "-1");
												if(ret == 1) {
																sprintf(WAN_CONN, "pppoe");
																ret = IFX_SUCCESS;
												}
												else {
																ret = do_wan_connect_test("dhcp", "-1");
																if(ret == 1) {
																				sprintf(WAN_CONN, "dhcp");
																				ret = IFX_SUCCESS;
																}
																else {
																				sprintf(WAN_CONN, "pppoe");
																				ret = IFX_SUCCESS; 
																}
												}
								}
				}

				else if(wanMode == WAN_MODE_PTM || wanMode == WAN_MODE_VDSL_PTM) {
								fp = popen("ifconfig eth0 | sed -n 's,^.*HWaddr,,;1p' | /usr/sbin/next_macaddr 2","r");
								if(fp != NULL)
								{
								fscanf(fp, "%s", MAC_ADDR);
								pclose(fp);	
								}
								sprintf(sBuf1, "/sbin/ifconfig ptm0 hw ether %s;/sbin/ifconfig ptm0 up", MAC_ADDR);
								SYS_CMD(sBuf1);

								if(strlen(PROBE_VLAN) && strcmp(PROBE_VLAN, "-1") && strcmp(PROBE_VLAN, "vlan")) {
												sprintf(sBuf1,"/etc/rc.d/create_ptm_if %s %s.%s",PROBE_VLAN,"ptm0",PROBE_VLAN);
												SYS_CMD(sBuf1);
								}
								if(strlen(PROBE_VLAN) && strcmp(PROBE_VLAN, "vlan"))
								{
									if((auto_dt.auto_detect_adsl_ptm_L3 == 1 && wanMode == WAN_MODE_PTM) || (auto_dt.auto_detect_vdsl_ptm_L3 == 1 && wanMode == WAN_MODE_VDSL_PTM))
									{
										ret = do_wan_connect_test(WAN_CONN, PROBE_VLAN);
										if(ret == 1)
											ret = IFX_SUCCESS;
										else
											ret = IFX_FAILURE;
									}
									else
									{
										ret = do_wan_connect_test("pppoe",PROBE_VLAN);
										if(ret == 1){
											sprintf(WAN_CONN, "pppoe");
											ret = IFX_SUCCESS;
										}else{
											ret = do_wan_connect_test("dhcp",PROBE_VLAN);
											if(ret == 1){
												sprintf(WAN_CONN, "dhcp");
												ret = IFX_SUCCESS;
											}else{
												ret = IFX_FAILURE;
											}
										}
									}
								}
								if(strlen(PROBE_VLAN) && strcmp(PROBE_VLAN, "-1") && strcmp(PROBE_VLAN, "vlan")) {
												sprintf(sBuf1,"/etc/rc.d/delete_ptm_if %s %s","ptm0",PROBE_VLAN);
												SYS_CMD(sBuf1);
								}
								if(ret == IFX_SUCCESS) {
									return IFX_SUCCESS;
								}

								if(auto_dt.auto_detect_Vlan_ADSL_PTM == 1 && wanMode == WAN_MODE_PTM)
									sprintf(ptm_vlan, "%s", auto_dt.auto_detect_ADSL_PTM_VlanId);
								else if(auto_dt.auto_detect_Vlan_VDSL_PTM == 1 && wanMode == WAN_MODE_VDSL_PTM)
									sprintf(ptm_vlan, "%s", auto_dt.auto_detect_VDSL_PTM_VlanId);
								else {
												if (mapi_get_all_vlan_ch_entries(&idx_count, &vlan_chcfg, flags) != IFX_SUCCESS) {
																IFX_MEM_FREE(vlan_chcfg);
																exit(-1);
												}
												for(i=0; i<idx_count; i++)
												{
																if((vlan_chcfg+i)->defaultentry == 1)
																{
																				if(!strcmp((vlan_chcfg+i)->iid.pcpeId.secName,"ptm_channel")) {
																								sprintf(ptm_vlan,"%d", (vlan_chcfg+i)->vlanId);
																								LTQ_STRNCPY(PROBE_VLAN,ptm_vlan,MAX_POOL_COUNT-1);
																								status = IFX_SUCCESS;

																				}
																}

												}
												/*If L2 is disable and L3 is enable and there is no instance of vlan configured from the gui then configure wan on untag*/
												if(status == 1) {
													LTQ_STRNCPY(PROBE_VLAN,"-1",MAX_POOL_COUNT-1);
													LTQ_STRNCPY(ptm_vlan,"-1",MAX_POOL_LIMIT-1);
												} 
												/*If L2 is disable and L3 is enable then configure  prev wan first, if fail then try for other wan*/
												if(strlen(PROBE_VLAN) && strcmp(PROBE_VLAN,"vlan"))
												{
																if(strlen(WAN_CONN)){
																				if(strcmp(PROBE_VLAN,"-1"))
																				{
																								sprintf(sBuf1,"/etc/rc.d/create_ptm_if %s %s.%s",PROBE_VLAN,"ptm0",PROBE_VLAN);
																								SYS_CMD(sBuf1);
																				}else{
																								sprintf(sBuf2, "/sbin/ifconfig ptm0 up");
																								SYS_CMD(sBuf2);
																				}
																				ret = do_wan_connect_test(WAN_CONN,PROBE_VLAN);
																				if(strcmp(PROBE_VLAN,"-1"))
																				{
																								sprintf(sBuf1,"/etc/rc.d/delete_ptm_if %s %s","ptm0",PROBE_VLAN);
																								SYS_CMD(sBuf1);
																				}
																				if(ret == 1)
																					return IFX_SUCCESS;
																}
												}
								}
								strcpy(vlan_ad, ptm_vlan);
								vlan_IDX = strtok_r(vlan_ad,",", &tptr);
								while(vlan_IDX != NULL) {
												vlan[vlan_count] = vlan_IDX;
												vlan_count++;
												vlan_IDX = strtok_r(NULL, ",", &tptr);
								}
								for(i=0;i<vlan_count;i++)
								{
												if(strcmp(vlan[i],"-1"))
												{
																sprintf(sBuf1,"/etc/rc.d/create_ptm_if %s %s.%s",vlan[i],"ptm0",vlan[i]);
																SYS_CMD(sBuf1);
												}
												/* probe for PPPoE first, if it fails then try DHCP */
												ret = do_wan_connect_test("pppoe", vlan[i]);
												if(ret == 1) {
																sprintf(WAN_CONN, "pppoe");
																strcpy(PROBE_VLAN,vlan[i]);
																if(strcmp(vlan[i],"-1"))
																{
																				sprintf(sBuf1,"/etc/rc.d/delete_ptm_if %s %s","ptm0",vlan[i]);
																				SYS_CMD(sBuf1);
																}
																return IFX_SUCCESS;
												}
												else {
																ret = do_wan_connect_test("dhcp", vlan[i]);
																if(ret == 1) {
																				sprintf(WAN_CONN, "dhcp");
																				strcpy(PROBE_VLAN,vlan[i]);
																				if(strcmp(vlan[i],"-1"))
																				{
																								sprintf(sBuf1,"/etc/rc.d/delete_ptm_if %s %s","ptm0",vlan[i]);
																								SYS_CMD(sBuf1);
																				}
																				return IFX_SUCCESS;
																}
												}
												if(strcmp(vlan[i],"-1"))
												{
																sprintf(sBuf1,"/etc/rc.d/delete_ptm_if %s %s","ptm0",vlan[i]);
																SYS_CMD(sBuf1);
												}

								}

								if(i == vlan_count && ((auto_dt.auto_detect_Vlan_ADSL_PTM == 1 && wanMode == WAN_MODE_PTM) || (auto_dt.auto_detect_Vlan_VDSL_PTM == 1 && wanMode == WAN_MODE_VDSL_PTM)))
								{
												sprintf(sBuf2, "/sbin/ifconfig ptm0 up");
												SYS_CMD(sBuf2);
												/* probe for PPPoE first, if it fails then try DHCP */
												ret = do_wan_connect_test("pppoe", "-1");
												if(ret == 1) {
																sprintf(WAN_CONN, "pppoe");
																strcpy(PROBE_VLAN, "-1");
																return IFX_SUCCESS;
												}
												else {
																ret = do_wan_connect_test("dhcp", "-1");
																if(ret == 1) {
																				sprintf(WAN_CONN, "dhcp");
																				strcpy(PROBE_VLAN, "-1");
																				return IFX_SUCCESS;
																}
																else {
																				sprintf(sBuf2, "/sbin/ifconfig ptm0 down");
																				SYS_CMD(sBuf2);
																				if((auto_dt.auto_detect_adsl_ptm_L3 == 1 && wanMode == WAN_MODE_PTM) || (auto_dt.auto_detect_vdsl_ptm_L3 == 1 && wanMode == WAN_MODE_VDSL_PTM))					
																								sprintf(WAN_CONN, "pppoe");
																				strcpy(PROBE_VLAN, vlan[0]);
																				return IFX_SUCCESS;
																}
												}
								}
								if(((auto_dt.auto_detect_Vlan_ADSL_PTM == 0) || (auto_dt.auto_detect_Vlan_VDSL_PTM == 0)) && status == 0)
								{
												sprintf(WAN_CONN,"pppoe");
												return IFX_SUCCESS;
								}
				}
				else if(wanMode == WAN_MODE_ETH1) {
								fp = popen("ifconfig eth0 | sed -n 's,^.*HWaddr,,;1p' | /usr/sbin/next_macaddr 2","r");
								fscanf(fp, "%s", MAC_ADDR);
								pclose(fp);	

								sprintf(sBuf1, "/sbin/ifconfig eth1 hw ether %s;/sbin/ifconfig eth1 up", MAC_ADDR);
								SYS_CMD(sBuf1);
								if(strlen(PROBE_VLAN) && strcmp(PROBE_VLAN, "-1") && strcmp(PROBE_VLAN, "vlan")) {
												sprintf(sBuf1,"/etc/rc.d/create_eth_if %s %s.%s",PROBE_VLAN,"eth1",PROBE_VLAN);
												SYS_CMD(sBuf1);
								}
								if(strlen(PROBE_VLAN) && strcmp(PROBE_VLAN, "vlan"))
								{
									if(auto_dt.auto_detect_mii1_L3 == 1)
									{
										ret = do_wan_connect_test(WAN_CONN, PROBE_VLAN);
										if(ret == 1)
											ret = IFX_SUCCESS;
										else
											ret = IFX_FAILURE;
									}
									else
									{
										ret = do_wan_connect_test("pppoe",PROBE_VLAN);
										if(ret == 1){
											sprintf(WAN_CONN, "pppoe");
											ret = IFX_SUCCESS;
										}else{
											ret = do_wan_connect_test("dhcp",PROBE_VLAN);
											if(ret == 1){
												sprintf(WAN_CONN, "dhcp");
												ret = IFX_SUCCESS;
											}else{
												ret = IFX_FAILURE;
											}
										}
									}
								}
								if(strlen(PROBE_VLAN) && strcmp(PROBE_VLAN, "-1") && strcmp(PROBE_VLAN, "vlan")) {
												sprintf(sBuf1,"/etc/rc.d/delete_eth_if %s %s","eth1",PROBE_VLAN);
												SYS_CMD(sBuf1);
								}
								if(ret == IFX_SUCCESS) {
									return IFX_SUCCESS;
								}

								if(auto_dt.auto_detect_Vlan_ETH1 == 1 && wanMode == WAN_MODE_ETH1 ) {
												sprintf(ptm_vlan, "%s", auto_dt.auto_detect_ETH1_VlanId);
								}
								else {
												if (mapi_get_all_vlan_ch_entries(&idx_count, &vlan_chcfg, flags) != IFX_SUCCESS) {
																IFX_MEM_FREE(vlan_chcfg);
																exit(-1);
												}
												for(i=0; i<idx_count; i++)
												{
																if((vlan_chcfg+i)->defaultentry == 1)
																{
																				if(!strcmp((vlan_chcfg+i)->iid.pcpeId.secName,"eth_channel")) {
																								sprintf(ptm_vlan,"%d", (vlan_chcfg+i)->vlanId);
																								strcpy(PROBE_VLAN,ptm_vlan);
																								status = IFX_SUCCESS;
																				}
																}
												}

												/*If L2 is disable and L3 is enable and there is no instance of vlan configured from the gui then configure wan on untag*/
												if(status == 1) {
													LTQ_STRNCPY(PROBE_VLAN,"-1",MAX_POOL_COUNT-1);
													LTQ_STRNCPY(ptm_vlan,"-1",MAX_POOL_LIMIT-1);
												}
 
												/*If L2 is disable and L3 is enable then configure  prev wan first, if fail then try for other wan*/
												if(strlen(PROBE_VLAN) && strcmp(PROBE_VLAN,"vlan"))
												{
																if(strlen(WAN_CONN)){
																				if(strcmp(PROBE_VLAN,"-1"))
																				{
																								sprintf(sBuf1,"/etc/rc.d/create_eth_if %s %s.%s",PROBE_VLAN,"eth1",PROBE_VLAN);
																								SYS_CMD(sBuf1);
																				}else{
																								sprintf(sBuf2, "/sbin/ifconfig eth1 up");
																								SYS_CMD(sBuf2);
																				}
																				ret = do_wan_connect_test(WAN_CONN,PROBE_VLAN);
																				if(strcmp(PROBE_VLAN,"-1"))
																				{
																								sprintf(sBuf1,"/etc/rc.d/delete_eth_if %s %s","eth1",PROBE_VLAN);
																								SYS_CMD(sBuf1);
																				}
																				if(ret == 1)
																					return IFX_SUCCESS;
																}
												}
								}
								strcpy(vlan_ad, ptm_vlan);
								vlan_IDX = strtok_r(vlan_ad,",", &tptr);
								while(vlan_IDX != NULL) {
												vlan[vlan_count] = vlan_IDX;
												vlan_count++;
												vlan_IDX = strtok_r(NULL, ",", &tptr);
								}
								for(i=0;i<vlan_count;i++)
								{
												if(strcmp(vlan[i],"-1"))
												{
																sprintf(sBuf1,"/etc/rc.d/create_eth_if %s %s.%s",vlan[i],"eth1",vlan[i]);
																SYS_CMD(sBuf1);
												}
												/* probe for PPPoE first, if it fails then try DHCP */
												ret = do_wan_connect_test("pppoe", vlan[i]);
												if(ret == 1) {
																sprintf(WAN_CONN, "pppoe");
																strcpy(PROBE_VLAN,vlan[i]);
																if(strcmp(vlan[i],"-1"))
																{
																				sprintf(sBuf1,"/etc/rc.d/delete_eth_if %s %s","eth1",vlan[i]);
																				SYS_CMD(sBuf1);
																}
																return IFX_SUCCESS;
												}
												else {
																ret = do_wan_connect_test("dhcp", vlan[i]);
																if(ret == 1) {
																				sprintf(WAN_CONN, "dhcp");
																				strcpy(PROBE_VLAN,vlan[i]);
																				if(strcmp(vlan[i],"-1"))
																				{
																								sprintf(sBuf1,"/etc/rc.d/delete_eth_if %s %s","eth1",vlan[i]);
																								SYS_CMD(sBuf1);
																				}
																				return IFX_SUCCESS;
																}
												}
												if(strcmp(vlan[i],"-1"))
												{
																sprintf(sBuf1,"/etc/rc.d/delete_eth_if %s %s","eth1",vlan[i]);
																SYS_CMD(sBuf1);
												}
								}

								if(i == vlan_count && ((auto_dt.auto_detect_Vlan_ETH1 == 1)))
								{
												sprintf(sBuf2, "/sbin/ifconfig eth1 up");
												SYS_CMD(sBuf2);
												/* probe for PPPoE first, if it fails then try DHCP */
												ret = do_wan_connect_test("pppoe", "-1");
												if(ret == 1) {
																sprintf(WAN_CONN, "pppoe");
																strcpy(PROBE_VLAN, "-1");
																return IFX_SUCCESS;
												}
												else {
																ret = do_wan_connect_test("dhcp", "-1");
																if(ret == 1) {
																				sprintf(WAN_CONN, "dhcp");
																				strcpy(PROBE_VLAN, "-1");
																				return IFX_SUCCESS;
																}
																else {
																				sprintf(sBuf2, "/sbin/ifconfig eth1 down");
																				SYS_CMD(sBuf2);
																				if(auto_dt.auto_detect_mii1_L3 == 1)					
																								sprintf(WAN_CONN, "pppoe");
																				strcpy(PROBE_VLAN, vlan[0]);
																				return IFX_SUCCESS;
																}
												}
								}
								if((auto_dt.auto_detect_Vlan_ETH1 == 0) && status == 0)
								{
												sprintf(WAN_CONN,"pppoe");
												return IFX_SUCCESS;
								}

				}
				else if(wanMode == WAN_MODE_ETH0) {
								sprintf(sBuf1, "/sbin/ifconfig eth0 up");
								SYS_CMD(sBuf1);
								if(strlen(PROBE_VLAN) && strcmp(PROBE_VLAN, "8") && strcmp(PROBE_VLAN, "vlan")) {
												sprintf(sBuf1,"/etc/rc.d/create_eth_if %s %s.%s",PROBE_VLAN,"eth0",PROBE_VLAN);
												SYS_CMD(sBuf1);
								}
								if(strlen(PROBE_VLAN) && strcmp(PROBE_VLAN, "vlan"))
								{
									if(auto_dt.auto_detect_mii0_L3 == 1)
									{
										ret = do_wan_connect_test(WAN_CONN, PROBE_VLAN);
										if(ret == 1)
											ret = IFX_SUCCESS;
										else
											ret = IFX_FAILURE;
									}
									else
									{
										ret = do_wan_connect_test("pppoe",PROBE_VLAN);
										if(ret == 1){
											sprintf(WAN_CONN, "pppoe");
											ret = IFX_SUCCESS;
										}else{
											ret = do_wan_connect_test("dhcp",PROBE_VLAN);
											if(ret == 1){
												sprintf(WAN_CONN, "dhcp");
												ret = IFX_SUCCESS;
											}else{
												ret = IFX_FAILURE;
											}
										}
									}
								}
								if(strlen(PROBE_VLAN) && strcmp(PROBE_VLAN, "8") && strcmp(PROBE_VLAN, "vlan")) {
												sprintf(sBuf1,"/etc/rc.d/delete_eth_if %s %s","eth0",PROBE_VLAN);
												SYS_CMD(sBuf1);
								}
								if(ret == IFX_SUCCESS) {
												return IFX_SUCCESS;
								}

								if((auto_dt.auto_detect_Vlan_ETH0 == 1) && wanMode == WAN_MODE_ETH0 ) {
												sprintf(ptm_vlan, "%s", auto_dt.auto_detect_ETH0_VlanId);
								}
								else {
												if (mapi_get_all_vlan_ch_entries(&idx_count, &vlan_chcfg, flags) != IFX_SUCCESS) {
																IFX_MEM_FREE(vlan_chcfg);
																exit(-1);
												}
												for(i=0; i<idx_count; i++)
												{
																if((vlan_chcfg+i)->defaultentry == 1)
																{
																				if(!strcmp((vlan_chcfg+i)->iid.pcpeId.secName,"eth_channel") && strstr((vlan_chcfg+i)->l2ifName,"eth0")) {
																								sprintf(ptm_vlan,"%d", (vlan_chcfg+i)->vlanId);
																								LTQ_STRNCPY(PROBE_VLAN,ptm_vlan,MAX_POOL_COUNT-1);
																								status = IFX_SUCCESS;
																				}
																}
												}
												if(status == 1) {
																exit(-1);
												} 
												/*If L2 is disable and L3 is enable then configure  prev wan first, if fail then try for other wan*/
												if(strlen(PROBE_VLAN) && strcmp(PROBE_VLAN,"vlan"))
												{
																if(strlen(WAN_CONN)){
																				if(strcmp(PROBE_VLAN,"8"))
																				{
																								sprintf(sBuf1,"/etc/rc.d/create_eth_if %s %s.%s",PROBE_VLAN,"eth0",PROBE_VLAN);
																								SYS_CMD(sBuf1);
																				}
																				ret = do_wan_connect_test(WAN_CONN,PROBE_VLAN);
																				if(strcmp(PROBE_VLAN,"8"))
																				{
																								sprintf(sBuf1,"/etc/rc.d/delete_eth_if %s %s","eth0",PROBE_VLAN);
																								SYS_CMD(sBuf1);
																				}
																				if(ret == 1)
																					return IFX_SUCCESS;
																}
												}
								}
								strcpy(vlan_ad, ptm_vlan);
								vlan_IDX = strtok_r(vlan_ad,",", &tptr);
								while(vlan_IDX != NULL) {
												vlan[vlan_count] = vlan_IDX;
												vlan_count++;
												vlan_IDX = strtok_r(NULL, ",", &tptr);
								}
								for(i=0;i<vlan_count;i++)
								{
												if(strcmp(vlan[i],"8"))
												{
																sprintf(sBuf1,"/etc/rc.d/create_eth_if %s %s.%s",vlan[i],"eth0",vlan[i]);
																SYS_CMD(sBuf1);
												}
												/* probe for PPPoE first, if it fails then try DHCP */
												ret = do_wan_connect_test("pppoe", vlan[i]);
												if(ret == 1) {
																sprintf(WAN_CONN, "pppoe");
																strcpy(PROBE_VLAN,vlan[i]);
																if(strcmp(vlan[i],"8"))
																{
																				sprintf(sBuf1,"/etc/rc.d/delete_eth_if %s %s","eth0",vlan[i]);
																				SYS_CMD(sBuf1);
																}
																return IFX_SUCCESS;
												}
												else {
																ret = do_wan_connect_test("dhcp", vlan[i]);
																if(ret == 1) {
																				sprintf(WAN_CONN, "dhcp");
																				strcpy(PROBE_VLAN,vlan[i]);
																				if(strcmp(vlan[i],"8"))
																				{
																								sprintf(sBuf1,"/etc/rc.d/delete_eth_if %s %s","eth0",vlan[i]);
																								SYS_CMD(sBuf1);
																				}
																				return IFX_SUCCESS;
																}
												}
												if(strcmp(vlan[i],"8"))
												{
																sprintf(sBuf1,"/etc/rc.d/delete_eth_if %s %s","eth0",vlan[i]);
																SYS_CMD(sBuf1);
												}
								}


								if(i == vlan_count && ((auto_dt.auto_detect_Vlan_ETH0 == 1)))
								{
												sprintf(sBuf2, "/sbin/ifconfig eth0 up");
												SYS_CMD(sBuf2);
												/* probe for PPPoE first, if it fails then try DHCP */
												ret = do_wan_connect_test("pppoe", "8");
												if(ret == 1) {
																sprintf(WAN_CONN, "pppoe");
																strcpy(PROBE_VLAN, "8");
																return IFX_SUCCESS;
												}
												else {
																ret = do_wan_connect_test("dhcp", "8");
																if(ret == 1) {
																				sprintf(WAN_CONN, "dhcp");
																				strcpy(PROBE_VLAN, "8");
																				return IFX_SUCCESS;
																}
																else {
																				if(auto_dt.auto_detect_mii0_L3 == 1)					
																								sprintf(WAN_CONN, "pppoe");
																				strcpy(PROBE_VLAN, vlan[0]);
																				return IFX_SUCCESS;
																}
												}
								}
								if((auto_dt.auto_detect_Vlan_ETH0 == 0) && status == 0)
								{
												sprintf(WAN_CONN,"pppoe");
												return IFX_SUCCESS;
								}
				}
				return ret;

}

int probe_l2_l3()
{
				int ret = 1, i = 0, cnt = 0;
				char	l2l3_ad[MAX_FILELINE_LEN], tptr[MAX_FILELINE_LEN], sBuf1[MAX_FILELINE_LEN];
				char	*ptr_1, *ptr_2, *ptr_1_1, *ptr_1_2, *ptr_2_1;
				l2l3_ad_pool_t	l2l3_arr[20];

				ptr_1 = ptr_2 = ptr_1_1 = ptr_2_1 = ptr_1_2 = NULL;

				if(wanMode == WAN_MODE_ATM) {
								/* first try previously detected vc, if present */
								if(strlen(VCC_VALUE) && strcmp(VCC_VALUE, "vcc")) { /* previous VC is present and not 'vcc' */
												if(do_vc_oam_ping(VCC_VALUE) == IFX_SUCCESS) {
																IFX_DBG("OAM F5 ping successful for vcc[%s]\n", VCC_VALUE);
																ret = probe_wan_conn();
																if(ret == IFX_SUCCESS)
																				return IFX_SUCCESS;
																else {
																				STOP_SERVICES
																				strcpy(VCC_VALUE, "vcc");
																				memset(WAN_CONN, 0x00, sizeof(WAN_CONN));
																				goto normal_vc_probe_2;
																}
												}
												else {
																STOP_ATM_L2_SERVICE
																strcpy(VCC_VALUE, "vcc");
																memset(WAN_CONN, 0x00, sizeof(WAN_CONN));
																goto normal_vc_probe_2;
												}
								}
								else {
normal_vc_probe_2:
												ret = IFX_SUCCESS;
												sprintf(l2l3_ad, "%s", auto_dt.auto_detect_atm_wan_pool);
								}
				}
				else {
								ret = IFX_SUCCESS;
				}

				if(ret == IFX_SUCCESS) {
								ptr_1 = strtok_r(l2l3_ad, ",", &ptr_1_1);
								while(ptr_1 != NULL) {
												strcpy(tptr, ptr_1);
												ptr_2 = strtok_r(tptr, ":", &ptr_2_1);
												if(ptr_2 != NULL) {
																sprintf(l2l3_arr[cnt].l2_attr, "%s", ptr_2);
																ptr_2 = strtok_r(NULL, ":", &ptr_2_1);
																sprintf(l2l3_arr[cnt++].wan_type, "%s", ptr_2);
												}
												ptr_1 = strtok_r(NULL, ",", &ptr_1_1);
								}

								if(wanMode == WAN_MODE_PTM || wanMode == WAN_MODE_VDSL_PTM) {
												sprintf(sBuf1, "/sbin/ifconfig ptm0 hw ether %s;/sbin/ifconfig ptm0 up", MAC_ADDR);
												SYS_CMD(sBuf1);
								}

								if(wanMode == WAN_MODE_ETH1) {
												sprintf(sBuf1, "/sbin/ifconfig eth1 hw ether %s;/sbin/ifconfig eth1 up", MAC_ADDR);
												SYS_CMD(sBuf1);
								}

								if(wanMode == WAN_MODE_ETH0) {
												sprintf(sBuf1, "/sbin/ifconfig eth0 hw ether %s;/sbin/ifconfig eth0 up", MAC_ADDR);
												SYS_CMD(sBuf1);
								}

								for(i=0; i<cnt; i++) {
												ret = IFX_SUCCESS;
												if(wanMode == WAN_MODE_ATM) {
																ret = do_vc_oam_ping(l2l3_arr[i].l2_attr);
												}
												if(ret == IFX_SUCCESS)
												{
																if(wanMode == WAN_MODE_ATM) {
																				sprintf(VCC_VALUE, "%s", l2l3_arr[i].l2_attr);
																}
																else {
																				sprintf(PROBE_VLAN, "%s", l2l3_arr[i].l2_attr);
																}

																ret = probe_wantype(l2l3_arr[i].wan_type, l2l3_arr[i].l2_attr);
																strcpy(WAN_CONN, l2l3_arr[i].wan_type);

																if(ret == IFX_SUCCESS) {
																				break;
																}

																strcpy(VCC_VALUE, "vcc");
																strcpy(PROBE_VLAN, "vlan");
																memset(PROBE_VLAN, 0x00, sizeof(PROBE_VLAN));
																memset(WAN_CONN, 0x00, sizeof(WAN_CONN));
																SYS_CMD("killall udhcpc pppd");
												}
												if(wanMode == WAN_MODE_PTM || wanMode == WAN_MODE_VDSL_PTM) {
																sprintf(sBuf1,"/sbin/vconfig rem ptm0.%s", l2l3_arr[i].l2_attr);
																SYS_CMD(sBuf1);
												}
												if(wanMode == WAN_MODE_ETH1) {
																sprintf(sBuf1,"/sbin/vconfig rem eth1.%s", l2l3_arr[i].l2_attr);
																SYS_CMD(sBuf1);
												}
												if(wanMode == WAN_MODE_ETH0) {
																sprintf(sBuf1,"/sbin/vconfig rem eth0.%s", l2l3_arr[i].l2_attr);
																SYS_CMD(sBuf1);
												}
								}

								if(wanMode == WAN_MODE_PTM || wanMode == WAN_MODE_VDSL_PTM) {
												SYS_CMD("/sbin/ifconfig ptm0 down");
								}
								/*
									 if(wanMode == WAN_MODE_ETH1) {
									 SYS_CMD("/sbin/ifconfig eth1 0.0.0.0");
									 }
									 if(wanMode == WAN_MODE_ETH0) {
									 SYS_CMD("/sbin/ifconfig eth0 0.0.0.0");
									 }
								 */

								if(i == cnt) {
												if(wanMode == WAN_MODE_ATM) {
																sprintf(VCC_VALUE, "%s", l2l3_arr[0].l2_attr);
																strcpy(WAN_CONN, l2l3_arr[0].wan_type);
																ret = IFX_SUCCESS;
												}
												else if(wanMode == WAN_MODE_PTM || wanMode == WAN_MODE_VDSL_PTM || wanMode == WAN_MODE_ETH1 || wanMode == WAN_MODE_ETH0){
																sprintf(PROBE_VLAN, "%s", l2l3_arr[0].l2_attr);
																strcpy(WAN_CONN, l2l3_arr[0].wan_type);
																ret = IFX_SUCCESS;
												}
								}
				}

				STOP_SERVICES
				return ret;
}

int probe_autodetect_l3()
{
				int ret_l3 = 1;
				if(((auto_dt.auto_detect_L3 == 1 && wanMode == WAN_MODE_ATM) || (auto_dt.auto_detect_adsl_ptm_L3 == 1 && wanMode == WAN_MODE_PTM) || (auto_dt.auto_detect_vdsl_ptm_L3 == 1 && wanMode == WAN_MODE_VDSL_PTM) || (auto_dt.auto_detect_mii1_L3 == 1 && wanMode == WAN_MODE_ETH1) || (auto_dt.auto_detect_mii0_L3 == 1 && wanMode == WAN_MODE_ETH0)) || ((wanMode == WAN_MODE_PTM && auto_dt.auto_detect_Vlan_ADSL_PTM == 1) || (wanMode == WAN_MODE_VDSL_PTM && auto_dt.auto_detect_Vlan_VDSL_PTM == 1) || (wanMode == WAN_MODE_ETH1 && auto_dt.auto_detect_Vlan_ETH1 == 1) || (wanMode == WAN_MODE_ETH0 && auto_dt.auto_detect_Vlan_ETH0 == 1))) {
								ret_l3 = probe_wan_conn();
				}
				return ret_l3;
}

/* Function will probe for vpi vci from the given pool using OAM f5 ping. */
int probe_vcc()
{
				char vcc_ad[MAX_POOL_LIMIT];
				char *vcc_IDX = NULL, *tptr = NULL;;
				char vpi[MAX_POOL_COUNT], vci[MAX_POOL_COUNT];
				memset(vpi, 0x00, sizeof(vpi)); 
				memset(vci, 0x00, sizeof(vci));
				char *vcc_tmp[MAX_DATA_LEN];
				int ret = 1, vcc_count = 0, loop_count = 0;
				char sBuf1[MAX_FILELINE_LEN], sBuf2[MAX_FILELINE_LEN];

				/* first try previously detected vc, if present */
				if(strlen(VCC_VALUE) && strcmp(VCC_VALUE, "vcc")) { /* previous VC is present and not 'vcc' */
								if(do_vc_oam_ping(VCC_VALUE) == IFX_SUCCESS) {
												IFX_DBG("OAM F5 ping successful for vcc[%s]\n", VCC_VALUE);
												return IFX_SUCCESS;
								}
								else {
												STOP_ATM_L2_SERVICE
												strcpy(VCC_VALUE, "vcc");
												goto normal_vc_probe_1;
								}
				}
				else {
normal_vc_probe_1:
								strcpy(vcc_ad, auto_dt.auto_detect_Vcc);
								vcc_IDX = strtok_r(vcc_ad,",", &tptr);
								while(vcc_IDX != NULL) {
												vcc_tmp[vcc_count] = vcc_IDX;
												vcc_count++;
												vcc_IDX = strtok_r(NULL, ",", &tptr);
								}
								for(loop_count=0;loop_count < vcc_count;loop_count++) {
												if(do_vc_oam_ping(vcc_tmp[loop_count]) == IFX_SUCCESS) {
																strcpy(VCC_VALUE, vcc_tmp[loop_count]);
																IFX_DBG("OAM F5 ping successful for vcc[%s]\n", VCC_VALUE);
																if(auto_dt.auto_detect_L3 == 1) {
																				ret = probe_wan_conn();
																				if(ret == IFX_SUCCESS) {
																								return IFX_SUCCESS;
																				}
																				else {
																								STOP_ATM_L2_SERVICE
																				}
																}
																else {
																				return IFX_SUCCESS;
																}
												}
												else {
																STOP_ATM_L2_SERVICE
												}
								}
								if(loop_count == vcc_count)
								{
												sprintf(VCC_VALUE, "%s", vcc_tmp[0]);
												sscanf(VCC_VALUE, "%[^/]/%s", vpi, vci);
												sprintf(sBuf1, "%s.%s", vpi,vci);
												if(auto_dt.auto_detect_L3 == 1) {
																sprintf(sBuf2, "/usr/sbin/br2684ctl -b -p 1 -c 0 -e 0 -q 1 -a %s -s 65536", sBuf1);
																SYS_CMD(sBuf2);
																sprintf(sBuf1,"sleep 1;ifconfig nas0 hw ether %s;ifconfig nas0 up",MAC_ADDR);
																SYS_CMD(sBuf1);
																status_atm_l2 = 1;
												}
												return IFX_SUCCESS;	
								}
				}
				return IFX_SUCCESS;
}

int probe_autodetect_l2()
{
				int vcc_status = 1, ret = IFX_SUCCESS;;
				char *retVal = NULL;
				FILE *fp;
				char vpi[MAX_POOL_COUNT], vci[MAX_POOL_COUNT];
				memset(vpi, 0x00, sizeof(vpi));
				memset(vci, 0x00, sizeof(vci));
				char sBuf1[MAX_FILELINE_LEN], sBuf2[MAX_FILELINE_LEN];
				fp = popen("ifconfig eth0 | sed -n 's,^.*HWaddr,,;1p' | /usr/sbin/next_macaddr 1","r");
				if(fp != NULL)
				{
				fscanf(fp, "%s", MAC_ADDR);
				pclose(fp);	
				}
				if(wanMode == WAN_MODE_ATM) {
								if(auto_dt.auto_detect_L2 == 1) {
												vcc_status = probe_vcc();
												if(vcc_status == IFX_SUCCESS) {
																return IFX_SUCCESS;
												}
												else {
																return IFX_FAILURE;
												}
								}
								else {
												if ((ret = ifx_ret_substr_from_distfield(FILE_AUTO_DETECT, TAG_ADSL_VCCHANNEL, "defaultentry", "1", &retVal)) != IFX_SUCCESS) {
																exit(-1);
												}
												sprintf(sBuf1, "%s_vcc", retVal);
												//printf("VCC in adsl %s\n",sBuf1);	
												if (ifx_GetObjData(FILE_AUTO_DETECT, TAG_ADSL_VCCHANNEL, sBuf1, IFX_F_GET_ANY, NULL, VCC_VALUE) == IFX_SUCCESS) {
																if(auto_dt.auto_detect_L3 == 1) {
																				sscanf(VCC_VALUE, "%[^/]/%s", vpi, vci);
																				sprintf(sBuf1,"%s.%s",vpi,vci);
																				sprintf(sBuf2, "/usr/sbin/br2684ctl -b -p 1 -c 0 -e 0 -q 1 -a %s -s 65536", sBuf1);
																				//printf("sBuf2---> %s\n",sBuf2);
																				status_atm_l2 = 1;   
																				SYS_CMD(sBuf2);
																				sprintf(sBuf1,"sleep 1;ifconfig nas0 hw ether %s;ifconfig nas0 up",MAC_ADDR);
																				SYS_CMD(sBuf1);
																}
												}	
												IFX_MEM_FREE(retVal)
								}
				}
				return IFX_SUCCESS;
}

/* Main function will check auto detect levels and probe accordingly: */
int main()
{
				char mode[5];
				char sBuf[MAX_FILELINE_LEN];
				int ret = IFX_SUCCESS;
				char status[MAX_DATA_LEN], *ptr_1 = NULL, *ptr_1_1 = NULL;
				WAN_PHY_CFG pstWanPhy;
				struct timeval tv_before, tv_after;
				FILE *fp = NULL;

				ret =ltq_mapi_get_autodetect_config(&auto_dt);
				if (ret != IFX_SUCCESS)
				{
								printf("******ltq_mapi_get_autodetect_config  Failed***************\n");
				}
				ifx_get_wan_phy_cfg(&pstWanPhy);

				wanMode = compute_wan_mode(pstWanPhy.phy_mode, pstWanPhy.wan_tc);

				if(wanMode != WAN_MODE_ATM && wanMode != WAN_MODE_ETH0 && wanMode != WAN_MODE_ETH1 &&
					wanMode != WAN_MODE_PTM && wanMode != WAN_MODE_VDSL_PTM) {
					/* One of non-supported WAN modes */
					IFX_DBG("WAN auto-detect is not supported for WAN mode [%d]", wanMode);
					return IFX_FAILURE;
				}

				/*CASE 1: Check if auto detect is enable or not 
					if auto detect disable return zero//
					else check for each and every level*/
				if((auto_dt.auto_detect_L2 == 0) && (auto_dt.auto_detect_Vlan_ATM == 0) && (wanMode == WAN_MODE_ATM) && (auto_dt.auto_detect_L3 == 0))
					return IFX_FAILURE;
				if((auto_dt.auto_detect_vdsl_atm_L2 == 0) && (wanMode == WAN_MODE_VDSL_ATM) && (auto_dt.auto_detect_vdsl_atm_L3 == 0))
					return IFX_FAILURE;
				else if((auto_dt.auto_detect_Vlan_ADSL_PTM == 0) && (wanMode == WAN_MODE_PTM) && (auto_dt.auto_detect_adsl_ptm_L3 == 0))
					return IFX_FAILURE;
				else if((auto_dt.auto_detect_Vlan_VDSL_PTM == 0) && (wanMode == WAN_MODE_VDSL_PTM) && (auto_dt.auto_detect_vdsl_ptm_L3 == 0))
					return IFX_FAILURE;
				else if((auto_dt.auto_detect_Vlan_ETH1 == 0) && (wanMode == WAN_MODE_ETH1) && (auto_dt.auto_detect_mii1_L3 == 0))
					return IFX_FAILURE;
				else if((auto_dt.auto_detect_Vlan_ETH0 == 0) && (wanMode == WAN_MODE_ETH0) && (auto_dt.auto_detect_mii0_L3 == 0))
					return IFX_FAILURE;

				printf("WAN Auto-detect configuration\n"
							"###################################################\n");
				printf("auto_detect l2 [%d]\n", auto_dt.auto_detect_L2);
				printf("auto_detect l3 [%d]\n", auto_dt.auto_detect_L3);
				printf("auto_detect adsl ptm l3 [%d]\n", auto_dt.auto_detect_adsl_ptm_L3);
				printf("auto_detect vdsl ptm l3 [%d]\n", auto_dt.auto_detect_vdsl_ptm_L3);
				printf("auto_detect mii1 l3 [%d]\n", auto_dt.auto_detect_mii1_L3);
				printf("auto_detect mii0 l3 [%d]\n", auto_dt.auto_detect_mii0_L3);
				printf("auto_detect adsl ptm [%d]\n", auto_dt.auto_detect_Vlan_ADSL_PTM);
				printf("auto_detect vdsl ptm [%d]\n", auto_dt.auto_detect_Vlan_VDSL_PTM);
				printf("auto_detect eth1 [%d]\n", auto_dt.auto_detect_Vlan_ETH1);
				printf("auto_detect eth0 [%d]\n", auto_dt.auto_detect_Vlan_ETH0);
				printf("auto_detect vcc [%s]\n", auto_dt.auto_detect_Vcc);
				printf("auto_detect adsl ptm pool [%s]\n", auto_dt.auto_detect_ADSL_PTM_VlanId);
				printf("auto_detect vdsl ptm pool [%s]\n", auto_dt.auto_detect_VDSL_PTM_VlanId);
				printf("auto_detect eth1 pool [%s]\n", auto_dt.auto_detect_ETH1_VlanId);
				printf("auto_detect eth0 pool [%s]\n", auto_dt.auto_detect_ETH0_VlanId);
				printf("auto_detect prev val [%s]\n", auto_dt.auto_detect_prev_val);
				printf("auto_detect ppp user [%s]\n", auto_dt.auto_detect_ppp_user);
	//			printf("auto_detect ppp passwd [%s]\n", auto_dt.auto_detect_ppp_pass);
				printf("auto_detect atm wan pool [%s]\n", auto_dt.auto_detect_atm_wan_pool);
				printf("auto_detect ptm wan pool [%s]\n", auto_dt.auto_detect_ptm_wan_pool);

				/* Store my pid */
				fp = fopen(FILE_AUTO_DETECT_PID, "w");
				if(fp == NULL) {
#ifdef IFX_LOG_DEBUG
#endif
					return IFX_FAILURE;
				}
				sprintf(sBuf, "%d", getpid());
				fwrite(sBuf, sizeof(sBuf), 1, fp);
				if(fp)
					fclose(fp);

				/* catch the signal kill and stop the process */
				signal(SIGTERM, auto_detect_terminate);
				signal(SIGINT, auto_detect_terminate);

				/* Back-up system_status file */
				system("/bin/cp /tmp/system_status /tmp/auto_detect_status");

				gettimeofday(&tv_before, NULL);

				/*Case 2: Find wan mode 
					wan mode is adsl atm if wanMode = 0
					wan mode is adsl ptm if wanMode = 1*/
				printf("**************************** >> auto-detect cfg\n");

				/* Start blinking LEDs to indicate auto-detect has started */

				status_ad = 1; // auto-detect started
				sprintf(status, "status_ad=\"%d\"\npppoe_status=\"%d\"\ndhcp_status=\"%d\"\n", status_ad, 0, 0);
				ifx_SetObjData(FILE_SYSTEM_STATUS, TAG_AD_STATUS, IFX_F_DEFAULT, 1, status);

				sprintf(sBuf, "%s", auto_dt.auto_detect_prev_val);

				if(strlen(sBuf)) {
								ptr_1 = strtok_r(sBuf, ":", &ptr_1_1);
								/* consider previous detected values based on current auto-detect status */
								if(auto_dt.auto_detect_L2 == 1 && ptr_1 != NULL)
												strcpy(VCC_VALUE, ptr_1);
								ptr_1 = strtok_r(NULL, ":", &ptr_1_1);
								if(((auto_dt.auto_detect_Vlan_ADSL_PTM == 1 && wanMode == WAN_MODE_PTM) || (auto_dt.auto_detect_Vlan_VDSL_PTM == 1 && wanMode == WAN_MODE_VDSL_PTM) || (auto_dt.auto_detect_Vlan_ETH1 == 1 && wanMode == WAN_MODE_ETH1) || (auto_dt.auto_detect_Vlan_ETH0 == 1 && wanMode == WAN_MODE_ETH0) || (auto_dt.auto_detect_Vlan_ATM == 1 && wanMode == WAN_MODE_ATM)) && ptr_1 != NULL)
												strcpy(PROBE_VLAN, ptr_1);
								ptr_1 = strtok_r(NULL, ":", &ptr_1_1);
								if(((wanMode == WAN_MODE_ATM) || (auto_dt.auto_detect_adsl_ptm_L3 == 1 && wanMode == WAN_MODE_PTM) || (auto_dt.auto_detect_vdsl_ptm_L3 == 1 && wanMode == WAN_MODE_VDSL_PTM) || (auto_dt.auto_detect_mii1_L3 == 1 && wanMode == WAN_MODE_ETH1) || (auto_dt.auto_detect_mii0_L3 == 1 && wanMode == WAN_MODE_ETH0)) && ptr_1 != NULL)
												strcpy(WAN_CONN, ptr_1);

								memset(sBuf, 0x00, sizeof(sBuf));
				}

				/* read previous auto-detect combination based on wanMode */
				if(wanMode == WAN_MODE_ATM)
								strcpy(mode,"ATM");
				else if(wanMode == WAN_MODE_PTM)
								strcpy(mode,"PTM");
				else if(wanMode == WAN_MODE_VDSL_PTM)
								strcpy(mode,"VDSL-PTM");
				else if(wanMode == WAN_MODE_ETH1)
								strcpy(mode,"ETH1");
				else if(wanMode == WAN_MODE_ETH0)
								strcpy(mode,"ETH0");

				printf("####### Autodetect process started #######\n");

				/* Case 3: probe for vcc , vlan and wan connection type:
				   3a: if both auto_dt.auto_detect_L2 and auto_dt.auto_detect_L3 are 1, then use customized probe order -> only for ATM */

				if((wanMode == WAN_MODE_ATM && auto_dt.auto_detect_L3 == 1 && (auto_dt.auto_detect_L2 == 1 || auto_dt.auto_detect_Vlan_ATM == 1))) {
								if(probe_l2_l3() != IFX_SUCCESS) {
												printf("[%s:%d] Auto detect failed in atm mode !!!", __FUNCTION__, __LINE__);
												ret = IFX_FAILURE;
												goto cleanup_n_finish;
								}
								status_ad = 2; // auto-detect incomplete
								sprintf(status, "status_ad=\"%d\"\n", status_ad);
								ifx_SetObjData(FILE_SYSTEM_STATUS, TAG_AD_STATUS, IFX_F_MODIFY, 1, status);
								printf("####### Autodetect process Incomplete #######\n");
								goto cleanup_n_finish;
				}

				/* 3b: if any of auto_dt.auto_detect_L2 or auto_dt.auto_detect_L3 are 0, then use standard probe order
						make sure this probe order doesn't have to handle case of auto_dt.auto_detect_L2 and auto_dt.auto_detect_L3 as 1 */

				/* if mode is ATM and L2 is enabled, then probe for L2 */
				if(wanMode == WAN_MODE_ATM)
				{
								ret = probe_autodetect_l2();
				}

				/* if (mode is PTM) or (mode is ATM and L2 is found) then probe L3 */
				if(wanMode == WAN_MODE_PTM || wanMode == WAN_MODE_VDSL_PTM || wanMode == WAN_MODE_ETH1 || wanMode == WAN_MODE_ETH0 || status_atm_l2 == 1)
								ret = probe_autodetect_l3();

				if(ret == IFX_SUCCESS)
				{
								status_ad = 2; // auto-detect incomplete
								sprintf(status, "status_ad=\"%d\"\n", status_ad);
								ifx_SetObjData(FILE_SYSTEM_STATUS, TAG_AD_STATUS, IFX_F_MODIFY, 1, status);
								printf("####### Autodetect process Incomplete #######\n");
				}

cleanup_n_finish:
				/* kill udhcpd and pppd & bring down the interfaces */
				if(wanMode == WAN_MODE_ATM) 
					STOP_ATM_L2_SERVICE 

#if 0
				if(wanMode == WAN_MODE_PTM || wanMode == WAN_MODE_VDSL_PTM) {
								if(strcmp(PROBE_VLAN, "-1")) {
												sprintf(sBuf,"/sbin/vconfig rem ptm0.%s",PROBE_VLAN);
												SYS_CMD(sBuf);
								}
								SYS_CMD("ifconfig ptm0 down");
				}
				if(wanMode == WAN_MODE_ETH1) {
								if(strcmp(PROBE_VLAN, "-1")) {
												sprintf(sBuf,"/sbin/vconfig rem eth1.%s",PROBE_VLAN);
												SYS_CMD(sBuf);
								}
								SYS_CMD("ifconfig eth1 down");
				}
				if(wanMode == WAN_MODE_ETH0) {
								if(strcmp(PROBE_VLAN, "-1")) {
												sprintf(sBuf,"/sbin/vconfig rem eth0.%s",PROBE_VLAN);
												SYS_CMD(sBuf);
								}
								sprintf(sBuf,"ifconfig eth0.%s down",PROBE_VLAN);
								SYS_CMD(sBuf);
				}
#endif

				if(ret != IFX_SUCCESS) {
								/* Update Auto-WAN detect status in system_status */
								status_ad = 0; // auto-detect incomplete
								sprintf(status, "status_ad=\"%d\"\n", status_ad);
								ifx_SetObjData(FILE_SYSTEM_STATUS, TAG_AD_STATUS, IFX_F_MODIFY, 1, status);

								printf("\n############# AUTO DETECT FAILED #############\n");
								return ret;
				}

				/* Take back-up of current rc.conf */
				sprintf(sBuf, "/bin/cp %s %s", FILE_AUTO_DETECT, FILE_AUTO_DETECT_BACKUP);
				system(sBuf);

				/* Case 4: generate an event with vcc, vlan, wan connection type(PPPoE/DHCP): */

				if((wanMode == WAN_MODE_PTM && auto_dt.auto_detect_adsl_ptm_L3 == 0 && auto_dt.auto_detect_Vlan_ADSL_PTM == 1) || (wanMode == WAN_MODE_VDSL_PTM && auto_dt.auto_detect_vdsl_ptm_L3 == 0 && auto_dt.auto_detect_Vlan_VDSL_PTM == 1) || (wanMode == WAN_MODE_ETH1 && auto_dt.auto_detect_mii1_L3 == 0 && auto_dt.auto_detect_Vlan_ETH1 == 1) || (wanMode == WAN_MODE_ETH0 && auto_dt.auto_detect_mii0_L3 == 0 && auto_dt.auto_detect_Vlan_ETH0 == 1)) {	
								sprintf(sBuf,"/usr/sbin/ifx_event_util AUTODETECT COMPLETE %s %s %s",mode, VCC_VALUE, PROBE_VLAN);
				} 
				else {
								sprintf(sBuf,"/usr/sbin/ifx_event_util AUTODETECT COMPLETE %s %s %s %s",mode, VCC_VALUE, (strlen(PROBE_VLAN) && strcmp(PROBE_VLAN, "vlan"))?PROBE_VLAN:"-1", WAN_CONN);
				}

				/* Update Auto-WAN detect status in system_status */
				status_ad = 0; // auto-detect incomplete
				sprintf(status, "status_ad=\"%d\"\n", status_ad);
				ifx_SetObjData(FILE_SYSTEM_STATUS, TAG_AD_STATUS, IFX_F_MODIFY, 1, status);

				/* Inform status to user and trigger event */
				SYS_CMD(sBuf);

				/* Store the auto-detect combination for later use */
				sprintf(sBuf, "auto_detect_prev_val=\"%s:%s:%s\"\n", VCC_VALUE, (strlen(PROBE_VLAN) && strcmp(PROBE_VLAN, "vlan"))?PROBE_VLAN:"-1", WAN_CONN);
				ifx_SetObjData(FILE_AUTO_DETECT, TAG_AUTO_DETECT_CFG, IFX_F_MODIFY, 1, sBuf);

				BRINGUP_WAN_SERVICES

				/* Save auto-detect configuration to flash */
				ifx_config_write(FILE_AUTO_DETECT, IFX_F_MODIFY);

				/* Update Auto-WAN detect status in system_status */
				status_ad = 0; // auto-detect incomplete
				sprintf(status, "status_ad=\"%d\"\n", status_ad);
				ifx_SetObjData(FILE_SYSTEM_STATUS, TAG_AD_STATUS, IFX_F_MODIFY, 1, status);

				gettimeofday(&tv_after, NULL);

				printf("\n############# AUTO DETECT INFORMATION #############\n");
				printf("-> WAN MODE		: %s \n",mode);
				if(wanMode == WAN_MODE_ATM)
								printf("-> WAN VCC	: %s \n",VCC_VALUE);
				else
								printf("-> VLAN		: %s \n",PROBE_VLAN);
				if((auto_dt.auto_detect_L3 == 1 && wanMode == WAN_MODE_ATM) || (auto_dt.auto_detect_adsl_ptm_L3 == 1 && wanMode == WAN_MODE_PTM) || (auto_dt.auto_detect_vdsl_ptm_L3 == 1 && wanMode == WAN_MODE_VDSL_PTM) || (auto_dt.auto_detect_mii1_L3 == 1 && wanMode == WAN_MODE_ETH1) || (auto_dt.auto_detect_mii0_L3 == 1 && wanMode == WAN_MODE_ETH0))
				printf("-> WAN CONN		: %s \n",WAN_CONN);
				printf("-> Time taken		: %ld seconds \n", tv_after.tv_sec - tv_before.tv_sec);
				printf("###################################################\n");

				/* remove backed-up rc.conf */
				remove(FILE_AUTO_DETECT_BACKUP);
				remove(FILE_AUTO_DETECT_PID);
				remove("/tmp/auto_detect_status");

				return IFX_SUCCESS;
}


