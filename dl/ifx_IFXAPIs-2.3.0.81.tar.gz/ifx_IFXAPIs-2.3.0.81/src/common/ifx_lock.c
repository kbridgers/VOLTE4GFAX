/* 
** =============================================================================
**   FILE NAME        : ifx_lock.c
**   PROJECT          : AMAZON MAPI
**   DATE             : 
**   AUTHOR           : 
**   DESCRIPTION      : This file contains the functions related to Amazon
			Database(rc.conf) Management

**   REFERENCES       : 
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/file.h>
#include <time.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include "ifx_lock.h"

#define _IFX_LOCK_TYPE 1
#define _IFX_UNLOCK_TYPE 2

extern int errno;

int ifx_init_lock(const char *pLockFile)
{
	FILE *fd = NULL;
	time_t currTS = 0;
	char *temp = NULL;
	char buf[IFX_LOCK_FILE_SIZE];

	buf[0] = '\0';

	if ((fd = fopen(pLockFile, "r+t")) == NULL) {
		printf("%s:%d Could not open Lock File %s. errno=%d\n",
		       __func__, __LINE__, pLockFile, errno);
		return -1;
	}

	time(&currTS);

	/* Check the TimeStamp for initialization */
	if ((temp = strstr(buf, "timestamp")) != NULL) {
		temp = strchr(temp, '=');
		temp++;
		if ((currTS - atol(temp)) >= IFX_LOCK_TIMEOUT_SEC) {
			// printf("%s:%d Lock File has aged.. Reset it\n", __func__, __LINE__);
			rewind(fd);
			fprintf(fd,
				"                                                                    \n");
			rewind(fd);
			fprintf(fd,
				"owner=-1\nprocess=0\ncount=0\ntimestamp=%ld\n",
				currTS);
		}
	}
	fclose(fd);
	return 0;
}

/**************************************************************
Return 0 if the process exists
Return 1 if the process does not exists
Retrun -1 if pid of the process in lockfile is less than 1
**************************************************************/
static int ifx_check_process_exist(char *psBuf)
{
	char *psTemp = NULL, sFPath[32] = { 0 };
	int iPID = -1, iRet = -1;
	FILE *pxFPtr = NULL;

	/* If the process in Non-existant then release the lock */
	psTemp = strstr(psBuf, "process");
	if (psTemp) {
		psTemp = strchr(psTemp, '=');
		psTemp++;
		iPID = atoi(psTemp);
		if (iPID > 1) {
			sprintf(sFPath, "/proc/%d/cmdline", iPID);
			pxFPtr = fopen(sFPath, "r");
			if (pxFPtr) {
				iRet = 0;
				fclose(pxFPtr);
			} else
				iRet = 1;
		}
	}
	return iRet;
}

static int ifx_verify_lock(const char *pLockFile, int owner, int op)
{
	FILE *fd = NULL;
	char buf[IFX_LOCK_FILE_SIZE];
	char *temp = NULL;
	time_t currTS = 0;
	int ret = -1;
	int num_bytes = 0;

	buf[0] = '\0';
	if ((fd = fopen(pLockFile, "r")) == NULL) {
		printf("%s:%d Could not open Lock File %s. errno=%d\n",
		       __func__, __LINE__, pLockFile, errno);
		return -1;
	}

	/* First get shared lock and check the owner and numLocks */
	if (flock(fileno(fd), LOCK_SH) < 0) {
		printf("%s:%d Unable to get shared lock. errno=%d\n",
		       __func__, __LINE__, errno);
		goto Close;
	}

	num_bytes = fread(buf, sizeof(char), IFX_LOCK_FILE_SIZE, fd);
	buf[num_bytes] = '\0';

	/* check for owner and count */
	if ((temp = strstr(buf, "owner")) != NULL) {
		temp = strchr(temp, '=');
		temp++;
		if (op == _IFX_UNLOCK_TYPE) {
			if (atoi(temp) == owner)
				ret = 0;
			goto Unlock;
		} else {	/* LOCK Case */
			if ((atoi(temp) == -1) || (atoi(temp) == owner)) {
				ret = 0;
				if (ifx_check_process_exist(buf) == 1)
					ret = 1;
			} else {	/* Check timestamp for ageing */
				time(&currTS);
				if ((temp = strstr(buf, "timestamp")) != NULL) {
					temp = strchr(temp, '=');
					temp++;
					if ((currTS - atol(temp)) >=
					    IFX_LOCK_TIMEOUT_SEC) {
						/* printf("%s:%d Lock File has aged.. Reset it\n",
						   __func__, __LINE__); */
						ret = 1;
					}
					if (ifx_check_process_exist(buf) == 1)
						ret = 1;
				}
			}
			goto Unlock;
		}
	}

      Unlock:
	if (flock(fileno(fd), LOCK_UN) < 0) {
		printf("%s:%d Unable to release lock. errno=%d\n",
		       __func__, __LINE__, errno);
	}

      Close:
	fclose(fd);

	return ret;
}

int ifx_acquire_lock_timed(const char *pLockFile, int owner, int mSecs)
{
	int timeout = mSecs;
	int verRet = 0;
	int count = 1;
	FILE *fd = NULL, *dbg_fp = NULL;
	char buf[IFX_LOCK_FILE_SIZE];
	char *temp = NULL;
	time_t timestamp = 0;
	unsigned long microSec = 0;
	int num_bytes = 0;

	buf[0] = '\0';

	verRet = ifx_verify_lock(pLockFile, owner, _IFX_LOCK_TYPE);

	if (verRet == -1) {
		if (!timeout)
			return -1;
		else {
			do {
				microSec = (IFX_TIMED_LOCK_FREQ * 1000);
				usleep(microSec);
				if ((verRet =
				     ifx_verify_lock(pLockFile, owner,
						     _IFX_LOCK_TYPE)) != -1)
					break;	/* Come out of the loop */
				timeout -= IFX_TIMED_LOCK_FREQ;
			} while (timeout > 0);
			if (verRet == -1)
				return -1;
		}
	}

	if ((fd = fopen(pLockFile, "r+t")) == NULL) {
		printf("%s:%d Could not open Lock File %s. errno=%d\n",
		       __func__, __LINE__, pLockFile, errno);
		return -1;
	}

	/* Get exclusive lock for write */
	if ((flock(fileno(fd), LOCK_EX)) < 0) {
		printf("%s:%d Unable to get exclusive lock. errno=%d\n",
		       __func__, __LINE__, errno);
		fclose(fd);
		return -1;
	}
	num_bytes = fread(buf, sizeof(char), IFX_LOCK_FILE_SIZE, fd);
	buf[num_bytes] = '\0';
	time(&timestamp);
	temp = strstr(buf, "count=");
	if (temp != NULL) {
		temp = strchr(temp, '=');
		temp++;
		if (verRet == 1) {
			// printf("Lock has to be resetted as it has timed out\n");
			count = 1;
		} else
			count = atoi(temp) + 1;
	}

	rewind(fd);
	fprintf(fd,
		"                                                                    \n");
	rewind(fd);
	fprintf(fd, "owner=%d\nprocess=%d\ncount=%d\ntimestamp=%ld\n", owner,
		getpid(), count, timestamp);

	dbg_fp = fopen("/var/log/lock_api_dbg", "a+");
	if(dbg_fp != NULL) {
		fprintf(dbg_fp, "Lock DBG: Lock taken by process with PID:%d and owner:%d at time:%ld\n",
			getpid(), owner, timestamp);
		fclose(dbg_fp);
	}

	if (flock(fileno(fd), LOCK_UN) < 0) {
		printf("%s:%d Unable to release lock. errno=%d\n",
		       __func__, __LINE__, errno);
	}
	fclose(fd);
	return 0;
}

int ifx_try_lock(const char *pLockFile, int owner)
{
	FILE *fd = NULL, *dbg_fp = NULL;
	char buf[IFX_LOCK_FILE_SIZE];
	char *temp = NULL;
	time_t ts = 0;

	buf[0] = '\0';

	if (ifx_verify_lock(pLockFile, owner, _IFX_LOCK_TYPE) != 0) {
		// printf("Lock not available as of now\n");
		return -1;
	}

	if ((fd = fopen(pLockFile, "r+t")) == NULL) {
		printf("%s:%d Could not open Lock File %s. errno=%d\n",
		       __func__, __LINE__, pLockFile, errno);
		return -1;
	}

	/* Get exclusive lock for write */
	if ((flock(fileno(fd), LOCK_EX)) < 0) {
		printf("%s:%d Unable to get exclusive lock. errno=%d\n",
		       __func__, __LINE__, errno);
		fclose(fd);
		return -1;
	}

	time(&ts);
	memset(buf, 0, sizeof(buf));
	fread(buf, sizeof(char), IFX_LOCK_FILE_SIZE - 1, fd);
	temp = strstr(buf, "count=");
	if (temp != NULL) {
		temp = strchr(temp, '=');
		temp++;
		rewind(fd);
		fprintf(fd,
			"                                                                    \n");
		rewind(fd);
		fprintf(fd, "owner=%d\nprocess=%d\ncount=%d\ntimestamp=%ld",
			owner, getpid(), atoi(temp) + 1, ts);

		dbg_fp = fopen("/var/log/lock_api_dbg", "a+");
		if(dbg_fp != NULL) {
			fprintf(dbg_fp, "Lock DBG: Lock taken by process with PID:%d and owner:%d at time:%ld\n",
				getpid(), owner, ts);
			fclose(dbg_fp);
		}

	}

	if (flock(fileno(fd), LOCK_UN) < 0) {
		printf("%s:%d Unable to release lock. errno=%d\n",
		       __func__, __LINE__, errno);
	}
	fclose(fd);
	return 0;
}

int ifx_release_lock(const char *pLockFile, int owner)
{
	int tmpPid, ownerTemp;
	FILE *fd = NULL, *dbg_fp = NULL;
	char buf[IFX_LOCK_FILE_SIZE];
	char *temp = NULL;
	time_t ts = 0;

	tmpPid = getpid();
	ownerTemp = owner;

	if (ifx_verify_lock(pLockFile, owner, _IFX_UNLOCK_TYPE) != 0) {
		// printf("No matching owner \n");
		return -1;
	}

	if ((fd = fopen(pLockFile, "r+t")) == NULL) {
		printf("%s:%d Could not open Lock File %s. errno=%d\n",
		       __func__, __LINE__, pLockFile, errno);
		return -1;
	}

	/* Get exclusive lock for write */
	if ((flock(fileno(fd), LOCK_EX)) < 0) {
		printf("%s:%d Unable to get exclusive lock. errno=%d\n",
		       __func__, __LINE__, errno);
		fclose(fd);
		return -1;
	}
	memset(buf, 0, sizeof(buf));
	fread(buf, sizeof(char), IFX_LOCK_FILE_SIZE - 1, fd);
	temp = strstr(buf, "count=");
	if (temp != NULL) {
		temp = strchr(temp, '=');
		temp++;
		if ((atoi(temp) - 1) == 0) {
			ownerTemp = -1;
			tmpPid = 0;
		}

		time(&ts);
		rewind(fd);
		fprintf(fd,
			"                                                                    \n");
		rewind(fd);
		fprintf(fd, "owner=%d\nprocess=%d\ncount=%d\ntimestamp=%ld\n",
			ownerTemp, tmpPid, atoi(temp) - 1, ts);

		dbg_fp = fopen("/var/log/lock_api_dbg", "a+");
		if(dbg_fp != NULL) {
			fprintf(dbg_fp, "Lock DBG: Lock released by process with PID:%d and owner:%d at time:%ld\n",
				getpid(), owner, ts);
			fclose(dbg_fp);
		}

	}
	if (flock(fileno(fd), LOCK_UN) < 0) {
		printf("%s:%d Unable to release lock. errno=%d\n",
		       __func__, __LINE__, errno);
	}
	fclose(fd);
	return 0;
}
