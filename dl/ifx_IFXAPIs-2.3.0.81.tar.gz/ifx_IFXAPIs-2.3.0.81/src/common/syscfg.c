/* 
** =============================================================================
**   FILE NAME        : ifx_common.c
**   PROJECT          : MAPI Infrastructure Syscfg Functions.
**   DATE             : 19-Jun-2006
**   AUTHOR           : M-API Team
**   DESCRIPTION      : This file contains the functions related to Sys
			Database(rc.conf) Management

**   REFERENCES       : 
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/
#define _GNU_SOURCE
#include <stdio.h>
#include <syslog.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
//#include <sys/wait.h>
#include <sys/time.h>
#include <sys/file.h>
#include <sys/stat.h>
#include "ifx_common.h"

#define SEMAPHORE_KEY 1234
#include <errno.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#define MAX_RETRIES 3
#define MICRO_SEC_INTERVAL 20000
//#define DBG_ENABLED
#if 0
#if defined(IFX_SMALL_FOOTPRINT) && defined(IFX_DLOAD_LIBCRYPT)
//6090602:hsumc change default libcrypt-0.9.26.so to libcrypt.so
#define LIBCRYPT	"libcrypt.so"
#include <dlfcn.h>
#else
#include "crypt.h"
#endif
#endif

#include <fcntl.h>

#ifndef DONT_USE_IFX_BASIC_TYPES_H
#include <sys/types.h>
#endif				//DONT_USE_IFX_BASIC_TYPES_H

#define IO_BUF_LEN              50
#define IFX_MAX_PID_FILENAME	100
#define IFX_PID_FILE_PATH		"/var/run"

#define CONFIG_START_TAG "#<< ConfigID"
#define CONFIG_END_TAG "#>> ConfigID"

#define BEGIN_TAG_PATTERN "#<< "
#define END_TAG_PATTERN "#>> "

#define DB_UNLOCK_CLOSE_N_RET(_ifx_db_fd, _ifx_retCode)  \
        {  flock(fileno(_ifx_db_fd), LOCK_UN);       \
           fclose(_ifx_db_fd);               \
	   return _ifx_retCode; }

#define _SEC_LINE_COUNT      1
#define _SEC_INST_COUNT      2
#define _SEC_INST_LINE_COUNT 3

uint32 g_ifx_version = 0;	/* Config Version in rc.conf */
int32 isLkSet = 0;

#ifdef CONFIG_RC_CONF_RW_OPTIMISATION
static char io_buf[IO_BUF_LEN];
#endif 
struct st_versionnode *configheadNode = NULL;

static char8 g_ifx_pidfile_prefix[IFX_MAX_PID_FILENAME];

char *gCache = NULL, gCache_secName[MAX_SEC_SIZE], gCache_inst[MAX_TAG_LEN];

int gCache_use_count = 0;

int32 delete_config_node(struct st_versionnode *, struct st_versionnode *);

int32 ifx_FormatAddition(char8 * inBuf, uint32 flag, char8 * outBuf);

/*Need to add these functions to a common location so that we can access throughout the program
*			  One thing we need to take care here is semkey, If two different applications uses same key 
			  then conflict occurs. Need to document a unique key according to the  application. 
*/

/*semaphore support functions START */

//Should change from global var to local
int32 semid;

union semun {
	int val;
	struct semid_ds *buf;
	ushort *array;
};

int init_sem(key_t key)
{
	int semid, i;
	struct sembuf sem_buf;
	struct semid_ds sem_id_ds;
	union semun sem_union;

#ifdef LOG_DBG
	IFX_DBG("\n[PARENT] Process [%d] is inside init_sem() \n", getpid());
#endif
	semid = semget(key, 1, IPC_CREAT | IPC_EXCL | 0666);
	if (semid >= 0) {	// Our process is first in the race
		sem_buf.sem_num = 0;
		sem_buf.sem_op = 1;	//Clear semaphore variable (or) initialize
		sem_buf.sem_flg = 0;	//Set default flag
#ifdef LOG_DBG
		IFX_DBG("\n[PARENT] Process [%d] created the semaphore\n",
			getpid());
#endif

		if (semop(semid, &sem_buf, 1) == -1) {
			IFX_DBG
			    ("\nERROR:[PARENT] Process [%d] failed to initialize semaphore\n",
			     getpid());
			return -1;
		}
	} else if (errno == EEXIST) {	// Not the parent process, Need to wait until parent initialize semaphore
		int sem_initialized = 0;
		semid = semget(key, 1, 0);
		if (semid < 0) {
#ifdef LOG_DBG
			IFX_DBG
			    ("\n[Child] Child process unable to get semid\n");
#endif
			return semid;
		} else {
			sem_union.buf = &sem_id_ds;

			for (i = 0; i < MAX_RETRIES && !sem_initialized; i++) {
				/*Check whether Parent process has initialized semaphore */
				semctl(semid, 0, IPC_STAT, sem_union);
				if (sem_union.buf->sem_otime > 0) {	// Last sem_op time is set
#ifdef LOG_DBG
					IFX_DBG
					    ("\n[CHILD] Parent process initialized semaphore successfully\n");
#endif
					sem_initialized = 1;
				} else {
					usleep(MICRO_SEC_INTERVAL);
				}
			}

			if (!sem_initialized) {
				errno = ETIME;
				return -1;
			}
		}
	} else {
		return semid;	// This is also an error condition 
	}

	return semid;
}

int enter_critical_section(int semid)
{
	int lock_status;
	struct sembuf sem_buf;
	int retry = 0;

	sem_buf.sem_num = 0;
	sem_buf.sem_op = -1;	/*By default set to -1 before entering critic sec */
	/*if sem_op = 1 [UNLOCKED] this will decrement to sem_op = 0 stating locked */
	sem_buf.sem_flg = SEM_UNDO;

	while (1) {
		lock_status = semop(semid, &sem_buf, 1);
		if (lock_status == 0) {
			goto success;
		} else {
			usleep(MICRO_SEC_INTERVAL);
			if (retry >= MAX_RETRIES) {
				//#ifdef DBG_ENABLED
				IFX_DBG
				    ("\nERROR: Lock failed at process [%d]\n",
				     getpid());
				//#endif
				goto failure;
			}
		}
		retry++;
		continue;
	}

      success:
#ifdef LOG_DBG
	IFX_DBG("\n[SUCCESS] Process [%d] enter_critical_section()\n",
		getpid());
#endif
	return 0;
      failure:
#ifdef LOG_DBG
	IFX_DBG("\n[FAILURE] Process [%d] enter_critical_section()\n",
		getpid());
#endif
	return -1;
}

int exit_critical_section(int semid)
{
	int lock_status;
	struct sembuf sem_buf;

	sem_buf.sem_num = 0;
	sem_buf.sem_op = 1;	/*By default set to -1 before entering critic sec */
	/*if sem_op = 0 [UNLOCKED] this will increment to sem_op = 1 stating unlocked */
	sem_buf.sem_flg = SEM_UNDO;

	lock_status = semop(semid, &sem_buf, 1);

	if (lock_status == -1) {
#ifdef LOG_DBG
		IFX_DBG("\nERROR: UnLock failed at process [%d]\n", getpid());
#endif
		return -1;
	}
#ifdef LOG_DBG
	IFX_DBG("\n[SUCCESS] Process [%d] exit_critical_section()\n", getpid());
#endif
	return 0;
}

int del_sem(int semid)
{
	int status;
	union semun sem_union;

	status = semctl(semid, 0, IPC_RMID, sem_union);

	if (status == -1) {
		IFX_DBG("\nERROR: Unable to destroy semaphore\n");
		exit(1);
	}

	return 0;
}

/*semaphore support functions END */

/*ToDo: Need to remove ifx_set_sys_lock() and ifx_release_sys_lock()*/
int ifx_set_sys_lock()
{
	FILE *fptr = NULL;
	char sValue[MAX_NAME_SIZE];
	fptr = fopen("/tmp/s_lock", "r+");
	if (fptr == NULL)
		return -1;
	fseek(fptr, 0, SEEK_SET);
	fscanf(fptr, "LOCK=%20s", sValue);
	if (atoi(sValue) != 0) {
		sleep(6);
		fscanf(fptr, "LOCK=%20s", sValue);
		if (atoi(sValue) != 0) {
			fclose(fptr);
			return -1;
		}
	}
	fseek(fptr, 0, SEEK_SET);
//#if 0
	if (flock(fileno(fptr), LOCK_EX) < 0) {
		fclose(fptr);
		return -1;
	}
//#endif
	fprintf(fptr, "%20s", "LOCK=1");
//#if 0
	flock(fileno(fptr), LOCK_UN);
//#endif
	fclose(fptr);
	return 0;
}

int ifx_get_lock_st()
{
	char sValue[MAX_NAME_SIZE] = { '\0' };
	FILE *fptr = NULL;
	fptr = fopen("/tmp/s_lock", "r");
	if (fptr == NULL)
		return -1;
	fseek(fptr, 0, SEEK_SET);
	fscanf(fptr, "LOCK=%20s", sValue);
	fclose(fptr);
	return atoi(sValue);
}

int ifx_release_sys_lock()
{
	FILE *fptr = NULL;
	char sValue[MAX_NAME_SIZE];
	sprintf(sValue, "LOCK=0");
	fptr = fopen("/tmp/s_lock", "w");
	if (fptr == NULL)
		return -1;
//#if 0
	if (flock(fileno(fptr), LOCK_EX) < 0) {
		fclose(fptr);
		return -1;
	}
//#endif
	fprintf(fptr, "%20s", sValue);
//#if 0
	flock(fileno(fptr), LOCK_UN);
//#endif
	fclose(fptr);
	return 0;
}

int32 get_config_version(const char8 * configFile, char8 * version)
{
	char8 pTag[] = "ConfigID";
	uint32 stateFlag = 0;
	return (ifx_GetObjData
		(configFile, pTag, "config_version", IFX_F_GET_ANY, &stateFlag,
		 version));

}

int32 set_config_version(const char8 * configFile, int32 version)
{
	char8 pTag[20] = "ConfigID";
	char8 pversion[32];

	pversion[0] = '\0';
	pTag[0] = '\0';
// sprintf(pversion, ("config_version=\"%4d\"\n"), version);
	sprintf(pversion, "%s=%4d\n", "config_version", version);
//    sprintf(pTag, "%s","ConfigID");
#ifdef LOG_DBG
	IFX_DBG("Tag : %s, Field :  %s \n\n", pTag, pversion);
#endif
	return (ifx_SetCfgData(configFile, pTag, 1, pversion));

}

struct st_versionnode *delete_node(struct st_versionnode *prev,
				   struct st_versionnode *p)
{

	if (p == prev) {
		/* Head node */
		prev = p->next;
		configheadNode = prev;
	} else
		prev->next = p->next;
	free(p);
	return (prev);
}

struct st_versionnode *search_config_node(struct st_versionnode
					  **configheadNode, pid_t configPID)
{
	struct timeval tv;
	struct st_versionnode *matchNode = *configheadNode, *prevnode =
	    *configheadNode;
	memset(&tv, 0, sizeof(tv));
	gettimeofday(&tv, NULL);

	for (; matchNode != NULL;) {
		if (matchNode->UI_pid == configPID) {
			/* Reset the Timer */
			matchNode->timeval = tv.tv_sec;
			return matchNode;
		}

		/* Delete the Entries which have aged out */
		if ((tv.tv_sec - matchNode->timeval) >= NODE_AGE_TIME) {
			prevnode = delete_node(prevnode, matchNode);
			if (prevnode == *configheadNode)
				matchNode = prevnode;
			else
				matchNode = prevnode->next;
			continue;
		}

		prevnode = matchNode;
		matchNode = matchNode->next;
	}

	if (matchNode == NULL) {
#ifdef LOG_DBG
		IFX_DBG("No matching node for the specified PID:%d\n",
			configPID);
#endif
	}
	return NULL;

}

int32 add_config_node(struct st_versionnode ** configheadNode, pid_t newPID)
{
	struct st_versionnode *tempnode = *configheadNode, *newnode;
	char8 str_version[5] = { '\0' };
	struct timeval tv;
	memset(&tv, 0, sizeof(tv));
	if (search_config_node(configheadNode, newPID) == NULL) {
		newnode = calloc(1, sizeof(struct st_versionnode));
		if (newnode == NULL) {
#ifdef LOG_DBG
			IFX_ERR
			    ("Not enough memory to malloc for Config Node\n");
#endif
			return FALSE;
		}
		newnode->UI_pid = newPID;
		if (get_config_version(FILE_RC_CONF, str_version) != 0)
			newnode->config_version = atoi(str_version);
		else {
#ifdef LOG_DBG
			IFX_ERR("Unable to read Version from rc.conf\n");
#endif
			free(newnode);
			return FALSE;
		}
		gettimeofday(&tv, NULL);
		newnode->timeval = tv.tv_sec;
		newnode->next = NULL;

		if (*configheadNode == NULL)
			*configheadNode = newnode;
		else {
			while (tempnode->next != NULL)
				tempnode = tempnode->next;
			/* Add the newly created node at the end */
			tempnode->next = newnode;
		}
		return TRUE;
	} else
#ifdef LOG_DBG
		IFX_DBG("Add node already exists\n");
#endif
	return FALSE;
}

int32 match_config_version(struct st_versionnode ** configheadNode,
			   pid_t configPID)
{
	char8 str_rc_conf_version[15] = { '\0' };
	struct st_versionnode *configNode = NULL;

	/* Get the node based on the PID */
	configNode = search_config_node(configheadNode, configPID);
	if (configNode == NULL)
		return FALSE;
	get_config_version(FILE_RC_CONF, str_rc_conf_version);
	if (configNode->config_version == atoi(str_rc_conf_version))
		return TRUE;
	else
		return FALSE;
}

int32 ifx_create_pid_file(char8 * file_prefix)
{
	int32 process_id = 0;
	FILE *fp;
	char8 file_name[IFX_MAX_PID_FILENAME];

	process_id = getpid();

	sprintf(file_name, "%s/%s.pid", IFX_PID_FILE_PATH, file_prefix);
	fp = fopen(file_name, "w");
	if (fp == NULL) {
		syslog(LOG_INFO,
		       "Error : Couldn't open file [%s] in write mode!",
		       file_name);
		return -1;
	} else {
		fprintf(fp, "%d", process_id);
		fclose(fp);
	}
	strcpy(g_ifx_pidfile_prefix, file_prefix);
	atexit(ifx_rm_pid_file_atexit);
	return 0;
}

int32 ifx_get_process_pid(char8 * file_prefix)
{
	int32 process_id = -1;
	char8 file_name[IFX_MAX_PID_FILENAME];
	FILE *fp = NULL;

	sprintf(file_name, "%s/%s.pid", IFX_PID_FILE_PATH, file_prefix);
	fp = fopen(file_name, "r");
	if (fp == NULL) {
		syslog(LOG_INFO,
		       "Error : Couldn't open file [%s] in read mode!",
		       file_name);
		return (process_id);
	} else {
		if (fscanf(fp, "%d", &process_id) < 0) {
			process_id = -1;	/* Error */
		}
		fclose(fp);
	}

	return process_id;
}

/* Enhanced strstr function - It will find the sub-string whole words only */
char8 *ifx_strstr(const char8 * origin, const char8 * substr)
{
	char8 c;
	char8 *ptr = (char8 *) origin;
	int32 length = strlen(substr);

	while ((ptr = strstr(ptr, substr))) {
		c = ptr[length];
		if (!((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') ||
		      (c >= 'a' && c <= 'z') || c == '_')) {
			if (ptr > origin) {
				c = ptr[-1];
				if (!
				    ((c >= '0' && c <= '9')
				     || (c >= 'A' && c <= 'Z') || (c >= 'a'
								   && c <= 'z')
				     || c == '_'))
					return ptr;
			} else {
				return ptr;
			}
		}
		ptr += length;
	}			//while
	return NULL;
}

int32 ifx_rm_pid_file(char8 * file_prefix)
{
	char8 file_name[IFX_MAX_PID_FILENAME];

	sprintf(file_name, "%s/%s.pid", IFX_PID_FILE_PATH, file_prefix);

	return (unlink(file_name));
}

void ifx_rm_pid_file_atexit(void)
{
	ifx_rm_pid_file(g_ifx_pidfile_prefix);
}

/* Check if this pid is indeed the process that we wanted. We do this
 * by opening the process' command line in /proc. It is not an exact
 * match, in that one may want to call this fn multiple times with different
 * parameters to match. For eg., first with <progname> as cmd_arg, then 
 * <arg1> as cmd_arg, and so on ...
 */
int32 ifx_validate_pid(pid_t pid, char8 * cmd_arg)
{
	FILE *fp = NULL;
	char8 file_name[IFX_MAX_PID_FILENAME];
	char8 *cmd_buff = NULL;
	int32 len = 0, ret = -1;

	sprintf(file_name, "/proc/%d/cmdline", pid);
#ifdef LOG_DBG
	IFX_DBG("Trying to open file %s ...\n", file_name);
#endif

	fp = fopen(file_name, "r");
	if (fp == NULL) {
#ifdef LOG_DBG
		IFX_ERR("Could Not open File %s", file_name);
#endif
		goto lbl_end0;
	}

	ret = getline(&cmd_buff, (size_t *) & len, fp);
	if ((ret < 0) || (cmd_buff == NULL)) {
#ifdef LOG_DBG
		IFX_ERR("getline() function fail ret[%d], len[%d]\n", ret, len);
#endif
		ret = -1;
		goto lbl_end1;
	}
#ifdef LOG_DBG
	IFX_DBG("Command in file is %s", cmd_buff);
#endif

	if (strstr(cmd_buff, cmd_arg) == NULL) {
#ifdef LOG_DBG
		IFX_ERR("[%s] Not found in cmd line for pid[%d] \n", cmd_arg,
			pid);
#endif
		ret = -1;
		goto lbl_end2;
	} else {
#ifdef LOG_DBG
		IFX_DBG("[%s] found in cmd line for pid[%d]!\n", cmd_arg, pid);
#endif
		ret = 0;
	}

      lbl_end2:
	if (cmd_buff)
		free(cmd_buff);
      lbl_end1:
	fclose(fp);

      lbl_end0:
	return (ret);
}

//ifx_VerifyGetFlagCombination(...)
int32 ifx_VerifyGetFlagCombination(uint32 * flagOp, uint32 state)
{
	if (flagOp == NULL) {
		if (state == IFX_F_GET_INCOMP)
			return IFX_FAILURE;
		else
			return IFX_SUCCESS;
	}

	if (IFX_GET_ENA_F_SET(*flagOp)) {
		if (state != IFX_F_GET_ENA)
			return IFX_FAILURE;
	} else if (IFX_GET_DIS_F_SET(*flagOp)) {
		if (state != IFX_F_GET_DIS)
			return IFX_FAILURE;
	} else if (IFX_GET_INCOMP_F_SET(*flagOp)) {
		if (state != IFX_F_GET_INCOMP)
			return IFX_SUCCESS;
	} else if (IFX_GET_ANY_F_SET(*flagOp)) {
		return IFX_SUCCESS;
	} else			//Default behaviour
	{
		if (state == IFX_F_GET_INCOMP)
			return IFX_FAILURE;
	}

	return IFX_SUCCESS;
}

/////////////////////////////////////////////////////////////////////////////////
//ifx_GetCfgDatafromString(...)
//      DESCRIPTION:    find the data in the string pString
//      pString :
//      pSymbol : Search Name
//      Return Value :  a pointer to the beginning of the Data which found,
//                      or NULL if the pSymbol is not found
/////////////////////////////////////////////////////////////////////////////////
int32 ifx_GetCfgDatafromString(char8 * pString, char8 * pSymbol,
			       uint32 * stateFlag, char8 * pRet)
{
	char8 *pString1, *dataBgn, *dataEnd, *temp;
	uint32 actualState;

	pString1 = dataBgn = dataEnd = temp = NULL;

	if ((pString1 = ifx_strstr(pString, pSymbol)) == NULL) {
		return IFX_E_PARAM_NOT_FOUND;
	}
	//Check the actual state of entry in database.
	actualState = IFX_F_GET_ENA;

	if (pString1 > pString) {	//Pattern somewhere down in buffer.
		temp = pString1 - 1;
		if (*temp == '#')
			actualState = IFX_F_GET_DIS;
		else if (*temp == '$')
			actualState = IFX_F_GET_INCOMP;
	}

	if (ifx_VerifyGetFlagCombination(stateFlag, actualState) != IFX_SUCCESS) {
#ifdef LOG_DBG
		IFX_DBG("State Conditions do not find a valid combination\n");
#endif
		if (stateFlag != NULL)
			*stateFlag = actualState;
		return IFX_E_UNMATCHED_INPUT;
	}
	if ((dataEnd = strchr(pString1, '\n')) == NULL) {
		return IFX_E_INT_ERROR;
	}

	if ((dataBgn = strchr(pString1, '=')) == NULL) {
		return IFX_E_INT_ERROR;
	}

	if (stateFlag != NULL)
		*stateFlag = actualState;

	do {
		dataBgn++;
		if (dataBgn >= dataEnd) {
			*pRet = '\0';
			return IFX_SUCCESS;
		}
	}
	while ((*dataBgn == '\t') || (*dataBgn == '\"'));

	strncpy(pRet, dataBgn, (dataEnd - dataBgn) - 1);	//Without trailing ".
	pRet[dataEnd - dataBgn - 1] = '\0';
	return IFX_SUCCESS;
}

void ifx_parse_cmd(char8 * cmd_buff)
{
	char8 *temp, *cmd_ptr;
	char8 current_cmd[1024], cmd_added[100];
	int32 file_input = 0, file_output = 1;
	uint8 pipe_found_flag = 0;
	uint16 size;

	cmd_ptr = cmd_buff;
	while ((temp = strchr(cmd_ptr, '|')) != NULL) {
		current_cmd[0] = '\0';
		size = temp - cmd_ptr;
		if (size >= 1024)
			return;
		strncpy(current_cmd, cmd_ptr, size);
		current_cmd[size] = '\0';

		// If first command of pipe so input file is not require 
		if (pipe_found_flag == 0) {
			sprintf(cmd_added, " > /tmp/ifx_f%d", file_output);
		} else {
#if 0
			if (strstr(current_cmd, "grep")) {
				sprintf(cmd_added,
					" -F /tmp/ifx_f%d > /tmp/ifx_f%d",
					file_input, file_output);
			} else
#endif
			{
				if (strstr(current_cmd, "tr")) {
					sprintf(cmd_added,
						" < /tmp/ifx_f%d > /tmp/ifx_f%d",
						file_input, file_output);
				} else {
					sprintf(cmd_added,
						" /tmp/ifx_f%d > /tmp/ifx_f%d",
						file_input, file_output);

				}
			}

		}

		strcat(current_cmd, cmd_added);
#ifdef LOG_DBG
		//IFX_DBG("\n COMMAND ( %s ) \n",current_cmd);
#endif
		system(current_cmd);

		cmd_ptr = temp + 1;
		file_input = file_output;
		file_output = file_output ? 0 : 1;
		pipe_found_flag = 1;
	}			// End of while Loop

	if (pipe_found_flag != 0) {
		temp = strchr(cmd_ptr, '\0');
		current_cmd[0] = '\0';
		size = temp - cmd_ptr;
		LTQ_STRNCPY(current_cmd, cmd_ptr, size);
		if (strstr(current_cmd, "grep")) {
			sprintf(cmd_added, " -F /tmp/ifx_f%d", file_input);
		} else if (strstr(current_cmd, "tr")) {
			sprintf(cmd_added, " < /tmp/ifx_f%d ", file_input);
		} else {
			sprintf(cmd_added, " /tmp/ifx_f%d ", file_input);
		}
		strcat(current_cmd, cmd_added);
		strcpy(cmd_buff, current_cmd);
		//system(current_cmd);
#ifdef LOG_DBG
		//IFX_DBG("Now cmd_buff (%s)",cmd_buff);
#endif
	} else {
#ifdef LOG_DBG
		//IFX_DBG("\nPipe not found \n");
#endif
	}

	return;
}

void ifx_web_convert_string(char8 * p)
{
	char *desbuf = (char8 *) malloc(128);
	int32 i, j;

	if (desbuf == NULL)
		return;

	memset(desbuf, 0x00, 128);
	for (i = 0, j = 0; i < 127 && j < 127; i++, j++) {
		if (p[i] == '\0') {
			desbuf[j] = p[i];
			break;
		} else if (p[i] == '%') {
			desbuf[j] = p[i];
			desbuf[j + 1] = p[i];
			j++;
		} else {
			desbuf[j] = p[i];
		}
	}
	strcpy(p, desbuf);
	free(desbuf);
}

int32 ifx_PipeOperation(const char8 * pFileName, char8 * pData, char8 * pRetVal)
{
	FILE *pd = NULL;	/* Pipe File Descriptor */
	char8 sValue[1024];
	int32 nLine = 0;
	int32 nIndex = 1;

	//ifx_parse_cmd(pFileName); //This fn handles pipe command sequentially
#ifdef LOG_DBG
	//IFX_DBG("\n pFileName cmd (%s)\n",pFileName);
#endif

	memset(sValue, '\0', sizeof(sValue));

	nLine = atoi(pData);

	if ((pd = popen(pFileName, "r")) == NULL) {
		remove("/tmp/ifx_f0");
		remove("/tmp/ifx_f1");
#ifdef LOG_DBG
		IFX_DBG("Fn [%s]:[%d] Error --> Unable to popen file [%s] !!\n",
			__FUNCTION__, __LINE__, pFileName);
#endif
		return IFX_FAILURE;
	}

	/* Get a Shared Read Lock on Pipe */
	if (flock(fileno(pd), LOCK_SH) < 0) {
#ifdef LOG_DBG
		IFX_ERR("Unable to Lock pipe: %s\n", pFileName);
#endif
#ifdef LOG_DBG
		IFX_DBG("Function [%s]:[%d] Error --> Unable to Lock pipe !!\n",
			__FUNCTION__, __LINE__);
#endif
		pclose(pd);
		return IFX_FAILURE;
	}
	while (fgets(sValue, 1024, pd)) {
		if (nIndex == nLine) {
			sValue[strlen(sValue) - 1] = IFX_SUCCESS;	//Keep string without NL
			LTQ_STRNCPY(pRetVal, sValue, MAX_FILELINE_LEN);
			remove("/tmp/ifx_f0");
			remove("/tmp/ifx_f1");
			/* Release the Read Lock on Pipe */
			flock(fileno(pd), LOCK_UN);
			pclose(pd);
			return IFX_SUCCESS;
		} else if (nLine == -1) {
			LTQ_STRNCAT(pRetVal, sValue, sizeof(sValue));
		}
		/* Pramod - if the line no. is a special number such as -1 every line read
		   can be appended to the return buffer. this can help when the caller
		   does not know how many lines of output will be there for this command */
		nIndex++;
	}
	/* Release the Read Lock on Pipe */
	flock(fileno(pd), LOCK_UN);
	pclose(pd);
	remove("/tmp/ifx_f0");
	remove("/tmp/ifx_f1");

	return IFX_SUCCESS;
}


//
//  extractString
//     function to extract the tag string from the line
//
int8 *extractString(int8 *dst, const char8 *src)
{
  int8 *p,*q;
  int8 str_tmp[MAX_LENGTH];

  for ( p = dst; *p != ' ' && *p != '\t'; p++);
  skip_space(p,p);

  for(q=str_tmp; *p != ' ' && *p != '\t' && *p != '\n' &&
                                            *p != '\0'; ){
      *q++ = *p++;
  }

  *q = '\0';

  if (!strcmp(str_tmp,src) )
     return dst;

  else 
     return NULL;
}

//
//  getSection
//    function to extract the section info from the line 
//
int32 getSection( char8 *str_buf,const char8 *sec,uint32 *offset)
{
  char8 *p = str_buf;
  int32 found = 0;


  p = strstr(str_buf,"##");
  if (p == NULL){
    return -1;
  }

  p += 2;
  *offset = atoi(p);

  p = extractString(str_buf,sec);
  if (!p){
     return found;
  }
  else {
     found = 1;
  }

  *offset -= (strlen(sec) + 4 + 1) ;  // <End Tag> + <String> +2<nl>
  return found;
}


/**************************************************************************
 *    ifx_GetSectionType - Returns Section type 
 *    Input Args :
 *        line   : line Buffer containing the configuration file header
 *    Return :
 *        1  : In case file is seek point type 
 *        0  : In case file is not seek point type 
 * ***********************************************************************/
inline int32 ifx_GetSectionType( char *line )
{
  char *p = line ;

#if 0
  skip_space(line,p);
  skip_data(p,p);
  skip_space(p,p);
  skip_data(p,p);
  skip_space(p,p);
  if (*p == '\n' ) return 0;
#endif
  if (strstr(p,"##") == NULL ){
      return 0;
  }

  return 1; 
}


#ifdef LTQ_NO_BUFFERING
 #define ltq_fgets(buf,len,fp)        LTQ_fgets(buf,len,fp)
 #define ltq_freed(ptr,size,nmem,fp)  LTQ_fread(ptr,size,nmem,fp)
 #define ltq_fseek(fp, offset,whence) LTQ_fseek(fp, offset,whence)
 #define ltq_ftell(fp)                LTQ_ftell(fp)
#else
 #define ltq_fgets(buf,len,fp)        fgets(buf,len,fp)
 #define ltq_freed(ptr,size,nmem,fp)  fread(ptr,size,nmem,fp)
 #define ltq_fseek(fp, offset,whence) fseek(fp, offset,whence)
 #define ltq_ftell(fp)                ftell(fp)
#endif

#ifdef LTQ_NO_BUFFERING
//
// ltq_fseek
//   fseek function with out buffering 
//
int LTQ_fseek( FILE * fp , long offset,int whence)
{
   int fd;

   fd  = fileno( fp );
   return lseek( fd ,(off_t)offset,whence);
}

//
//  ltq_fgets
//     function for fgets
//
char * LTQ_fgets( char * line, int len , FILE *fp )
{
   int fd;
   char *p  = line;
   int idx, eof = 0;

   fd = fileno( fp );
   for ( idx = 0; idx < len ; idx++, p++){
     if ( read( fd,p,sizeof(char) ) != sizeof(char) ){
       eof = 1;
       break;
     }
     
     if ( *p == '\n'){
       p++;
       break;
     }
   }

   *p = '\0';
   if ( idx == 0 && eof == 1 ) return NULL;
   return line;
}

//
//  ltq_freed
//     fread function 
//
size_t LTQ_fread(void *ptr, size_t size, size_t nmem, FILE *fp )
{
  int fd = fileno( fp );
  int ret;

  ret = read( fd, ptr, size * nmem );
  return (ret / size );
}

//
// ltq_ftell
//   funnction for ftell
//
long LTQ_ftell( FILE * fp )
{
  int fd = fileno(fp);

  return (long)lseek(fd,0, SEEK_CUR );
}

//
// ltq_fgets_seek
//   function to seek with buffering .
//
char * LTQ_fgets_seek( char * line, int len , FILE *fp )
{
   char *p = line;   
   int idx, eof = 0;

   for ( idx = 0; idx < len ; idx ++, p++){
      if( fread( p,sizeof(char),1, fp ) != sizeof(char) ){
         eof = 1;
         break;
      }
      if ( *p == '\n' ) {
         p++;
         break;
      }
   }

   *p = '\0';
   if( idx == 0 && eof == 1 ) return NULL;
   return line;
}
#endif


#define BUF_LENGTH   512
int get_sectionOffset( const char8 *sec, char * fname,int *offset , int * size, uint32 *pos,uint32 *secLen )
{
    FILE *fp ;
    int ret = IFX_FAILURE;
    char buf[BUF_LENGTH];
    char buf_sec[BUF_LENGTH];

    fp = fopen( fname,"r");
    if (!fp) return ret;

    *offset = *size = 0;
    while( fgets( buf, BUF_LENGTH, fp ) ){
       sscanf( buf,"%s %d", buf_sec, size);
       if (strncmp( buf_sec, sec, strlen( sec))){
          *offset += (*size + strlen(buf) + 6 ) ; // <beg Tag> + <sp> + <offset index>  XXX:in rc.conf (not) in rc.conf_seek
          continue;                               //    3 + 1 + 2   == 6/
       }
       else {
         *secLen = strlen(buf) + 6 ;
         *pos = *offset ;
         *offset += (strlen(buf) + 6 );
         *size -= ( strlen(sec) + 5 );
         ret = IFX_SUCCESS;
         break;
       }
   }

   fclose( fp );
   return ret;
}

/**************************************************************************
 *    ifx_GetSectionSeekPt - Returns Section contents between begin and endTag
 *    Input Args :
 *        ifp       : File Name where to search Section
 *        pTag      : Section or Tag Name
 *    Output Args :
 *        pRetSec : Return Pointer holding Section buffer
 *        secPosition : Section Position Offset. 
 *    Return :
 *        IFX_SUCCESS : In case operation is successful.
 *        IFX_FAILURE, IFX_E_<Errors> : In case operation failed.
 * ***********************************************************************/
int32 ifx_GetSectionSeekPt( FILE * ifp, const char8 *pTag,
                       char8 ** pRetSec, uint32 *secPosition, uint32 *secLen)
{

   int found = 0;
   uint32 ret = IFX_E_SEC_NOT_FOUND;
   char line[MAX_LENGTH],*p;
   char8 *secBuf = NULL;
   uint32 pos=0;

   while( ltq_fgets( line, MAX_LENGTH, ifp)){
      skip_space( line, p );
      if (!strstr(line,BEGIN_TAG_PATTERN))
        continue;
      found = getSection( p,pTag, secPosition);
      if ( found < 0 ) break;
      if ( found == 0 ){
        ltq_fseek( ifp , *secPosition,SEEK_CUR);
        continue;
      } else {
        secBuf = (char*) malloc(*secPosition);
        if (!secBuf ){
          ret = -2;
          goto exit_section;
        }
        *secLen = strlen(line);
                      
        pos = ltq_ftell(ifp) - strlen(line);
        if (ltq_freed(secBuf,1,*secPosition,ifp) != *secPosition){
          free( secBuf );
          ret = IFX_FAILURE;
          IFX_DBG("Section size not found \n");
          goto exit_section;
        }
 
       secBuf[*secPosition-1] = '\0';
       //*secPosition = (ftell(ifp) - *secPosition - strlen(line));
       *secPosition = pos;
       *pRetSec = secBuf;
       ret = IFX_SUCCESS;
       break;
     }
   }

   if ( found <= 0)
     goto exit_section;
                   
            
   if (secPosition)
     *secPosition = *secPosition;
   //*secPosition = fileSecPos;
    
//   return ret;
  
exit_section:
   //exit_critical_section(semid);
   DB_UNLOCK_CLOSE_N_RET(ifp, ret )
}

/**************************************************************************
 *    ifx_GetSection - Returns Section contents between begin and endTag
 *    Input Args :
 *        pFileName : File Name where to search Section
 *        pTag      : Section or Tag Name
 *    Output Args :
 *        pRetSec : Return Pointer holding Section buffer
 *        secPosition : Section Poisition Offset. 
 *    Return :
 *        IFX_SUCCESS : In case operation is successful.
 *        IFX_FAILURE, IFX_E_<Errors> : In case operation failed.
 * ***********************************************************************/

int32 ifx_GetSection(const char8 * pFileName, const char8 * pTag,
		     char8 ** pRetSec, uint32 * secPosition)
{
	FILE *fptr;
	char8 *secBuf, *pBgnString, *pEndString, *pTemp;
	char8 buffer[2048];	/* 2 KB buffer chunk size */
	char8 beginTag[MAX_TAG_LEN], endTag[MAX_TAG_LEN];
	uint8 bgnTagFound, endTagFound;
	uint32 sz, secSz, fileSecPos;
#ifdef CONFIG_RC_CONF_RW_OPTIMISATION
        uint32 secLen; char *p;
#endif

	/* Intialization of local variables */

	bgnTagFound = endTagFound = FALSE;
	sz = secSz = fileSecPos = 0;
	secBuf = pBgnString = pEndString = pTemp = NULL;
	buffer[0] = '\0';

	sprintf(beginTag, "%s%s", BEGIN_TAG_PATTERN, pTag);
	sprintf(endTag, "%s%s", END_TAG_PATTERN, pTag);

	if (!(pFileName && pTag)) {
#ifdef LOG_DBG
		IFX_ERR("GetSection:Invalid File or Section Name\n");
#endif
		return IFX_FAILURE;
	}

	if (!isLkSet) {
		if ((fptr = fopen(pFileName, "r")) == NULL) {
#ifdef LOG_DBG
			IFX_ERR("GetSection:Read type of file:%s open failed\n",
				pFileName);
#endif
			return IFX_FAILURE;
		}


#ifdef CONFIG_RC_CONF_RW_OPTIMISATION
		setvbuf( fptr,io_buf,_IOFBF, IO_BUF_LEN );
#endif
		if (flock(fileno(fptr), LOCK_SH) < 0) {
#ifdef LOG_DBG
			IFX_ERR("GetSection:Unable to get SharedLock on:%s\n",
				pFileName);
#endif
			fclose(fptr);
			return IFX_FAILURE;
		}

#ifdef CONFIG_RC_CONF_RW_OPTIMISATION
                while( ltq_fgets(buffer,MAX_LENGTH,fptr)){
                   skip_space(buffer,p);
                   if (strncmp(p,BEGIN_TAG_PATTERN,4))
                     continue;
                   else break;
                }
               
                ltq_fseek( fptr,0-strlen(buffer),SEEK_CUR);
                if (ifx_GetSectionType(buffer)){
                   return ifx_GetSectionSeekPt(fptr, pTag, pRetSec, secPosition, &secLen);
                }
#endif

		/* Read in chunks of memory units */
		while ((sz =
			fread(buffer, sizeof(char), sizeof(buffer) - 1,
			      fptr)) != 0) {
			buffer[sz] = '\0';
			if ((pTemp = strrchr(buffer, '\n')) != NULL) {
				fseek(fptr, 1 - strlen(pTemp), SEEK_CUR);	//After NL
				pTemp[1] = '\0';
				sz = strlen(buffer);
			}

			if (!bgnTagFound) {
				if ((pBgnString =
				     ifx_strstr(buffer, beginTag)) == NULL) {
					fileSecPos += sz;
					continue;	/* Iterate next in while loop */
				} else {	/* Begin Tag Found */
					fileSecPos += (pBgnString - buffer);
					bgnTagFound = TRUE;

					/* Look for End Tag also now in this buffer */
					if ((pEndString =
					     ifx_strstr(buffer,
							endTag)) != NULL) {
						endTagFound = TRUE;
						secSz =
						    pEndString - pBgnString -
						    strlen(beginTag) + 1;
						secBuf =
						    (char8 *) malloc(secSz);
						if (secBuf == NULL) {
#ifdef LOG_DBG
							IFX_ERR
							    ("Fn [%s]:[%d] MemAlloc for [%ld] bytes Failed!! \n",
							     __FUNCTION__,
							     __LINE__,
							     (long int)secSz);
#endif
#ifdef LOG_DBG
							IFX_ERR
							    ("Fn [%s]:[%d] asked to find [%s] in [%s]!! \n",
							     __FUNCTION__,
							     __LINE__, pTag,
							     pFileName);
#endif
#ifdef LOG_DBG
							IFX_ERR
							    ("[%s:%d] found [%s] in [%s] !!\n",
							     __FUNCTION__,
							     __LINE__, endTag,
							     buffer);
#endif
#ifdef LOG_DBG
							IFX_ERR
							    ("[%s:%d] for [%s] start is [%s] and end is [%s] !!\n",
							     __FUNCTION__,
							     __LINE__, pTag,
							     pBgnString,
							     pEndString);
#endif
#ifdef LOG_DBG
							IFX_ERR
							    ("[%s:%d] beginTag is [%s] !!\n",
							     __FUNCTION__,
							     __LINE__,
							     beginTag);
#endif
							DB_UNLOCK_CLOSE_N_RET
							    (fptr,
							     IFX_E_INT_ERROR)
						}

						strncpy(secBuf,
							pBgnString +
							strlen(beginTag) + 1,
							secSz - 2);
						secBuf[secSz - 2] = '\0';
						break;	/* Come out of while loop */
					}

					/* endTag */
					/* begin Tag is present but endTag is not here */
					secSz =
					    strlen(pBgnString) -
					    strlen(beginTag);
					secBuf = (char8 *) malloc(secSz + 2);	//For termination
					if (secBuf == NULL) {
#ifdef LOG_DBG
						IFX_ERR
						    ("Fn [%s]:[%d] MemAlloc for [%ld] bytes Failed!! \n",
						     __FUNCTION__, __LINE__,
						     (long int)secSz);
#endif
#ifdef LOG_DBG
						IFX_ERR
						    ("Fn [%s]:[%d] asked to find [%s] in [%s]!! \n",
						     __FUNCTION__, __LINE__,
						     pTag, pFileName);
#endif
#ifdef LOG_DBG
						IFX_ERR
						    ("[%s:%d] found [%s] in [%s] !!\n",
						     __FUNCTION__, __LINE__,
						     endTag, buffer);
#endif
#ifdef LOG_DBG
						IFX_ERR
						    ("[%s:%d] for [%s] start is [%s] and end is [%s] !!\n",
						     __FUNCTION__, __LINE__,
						     pTag, pBgnString,
						     pEndString);
#endif
#ifdef LOG_DBG
						IFX_ERR
						    ("[%s:%d] beginTag is [%s] !!\n",
						     __FUNCTION__, __LINE__,
						     beginTag);
#endif
						DB_UNLOCK_CLOSE_N_RET(fptr,
								      IFX_E_INT_ERROR)
					}

					strncpy(secBuf,
						pBgnString + strlen(beginTag) +
						1, secSz);
					secBuf[secSz + 1] = '\0';
					continue;	/* Advance in loop for endTag search */
				}	/* bgnTag */
			}
			/* !bgnTagFound */
			if (bgnTagFound && !endTagFound) {
				if ((pEndString =
				     ifx_strstr(buffer, endTag)) != NULL) {
					endTagFound = TRUE;
					if ((secBuf =
					     (char8 *) realloc(secBuf,
							       secSz +
							       sizeof(buffer) +
							       2)) != NULL) {
						strncat(secBuf, buffer, pEndString - buffer);	//With NL
						secSz += (pEndString - buffer);
						secBuf[secSz] = '\0';
						break;	/* Break the while loop */
					}
				} else {	/* Intermediate chunk between begin and end Tag */
					if ((secBuf =
					     (char8 *) realloc(secBuf,
							       secSz +
							       sizeof(buffer) +
							       2)) != NULL) {
						secSz += sizeof(buffer) + 1;	//For End of String
						strncat(secBuf, buffer, sizeof(buffer));	//With NL
						secBuf[secSz] = '\0';
					}
				}
			}
		}		/* while (sz ..... != 0) */

		if (!(bgnTagFound && endTagFound)) {
#ifdef LOG_DBG
			IFX_DBG
			    ("Fn [%s]:[%d] DB Section [%s] not found or misformed!!\n",
			     __FUNCTION__, __LINE__, pTag);
#endif
			if (secBuf)
				free(secBuf);
			DB_UNLOCK_CLOSE_N_RET(fptr, IFX_E_SEC_NOT_FOUND)
		}

		if (secPosition)
			*secPosition = fileSecPos;

		/* Is Section Empty ?? */
		if (secBuf != NULL) {
			if ((strchr(secBuf, '\n')) == NULL) {
				free(secBuf);
				DB_UNLOCK_CLOSE_N_RET(fptr, IFX_E_SEC_EMPTY)
			}
			*pRetSec = secBuf;
		}

		//exit_critical_section(semid);
		DB_UNLOCK_CLOSE_N_RET(fptr, IFX_SUCCESS)
	} else
		return IFX_FAILURE;
}

int32 ifx_GetSection_t1(const char8 * pFileName, const char8 * pTag,
			char8 ** pRetSec, uint32 * secPosition, uint32 *secLen)
{
	FILE *fptr;
	char8 *secBuf,*pBgnString, *pEndString, *pTemp;
#ifdef CONFIG_RC_CONF_RW_OPTIMISATION
        char8 *p;
#endif 
	char8 buffer[2048];	/* 2 KB buffer chunk size */
	char8 beginTag[MAX_TAG_LEN], endTag[MAX_TAG_LEN];
	uint8 bgnTagFound, endTagFound;
	uint32 sz, secSz, fileSecPos;

	/* Intialization of local variables */

	bgnTagFound = endTagFound = FALSE;
	sz = secSz = fileSecPos = 0;
	secBuf = pBgnString = pEndString = pTemp = NULL;
	buffer[0] = '\0';

	sprintf(beginTag, "%s%s", BEGIN_TAG_PATTERN, pTag);
	sprintf(endTag, "%s%s", END_TAG_PATTERN, pTag);

	if (!(pFileName && pTag)) {
#ifdef LOG_DBG
		IFX_ERR("GetSection:Invalid File or Section Name\n");
#endif
		return IFX_FAILURE;
	}

	if ((fptr = fopen(pFileName, "r")) == NULL) {
#ifdef LOG_DBG
		IFX_ERR("GetSection:Read type of file:%s open failed\n",
			pFileName);
#endif
		return IFX_FAILURE;
	}

#ifdef CONFIG_RC_CONF_RW_OPTIMISATION
        setvbuf( fptr, io_buf, _IOFBF,IO_BUF_LEN);    
#endif 

#ifdef CONFIG_RC_CONF_RW_OPTIMISATION
        while( fgets(buffer,MAX_LENGTH,fptr)){
           skip_space(buffer,p);
           if (strncmp(p,"#<<",3))
              continue;
           else break;
        }
            
        if (ifx_GetSectionType(buffer)){
           fseek( fptr,0-strlen(buffer),SEEK_CUR);
           return ifx_GetSectionSeekPt(fptr, pTag,pRetSec, secPosition,secLen);
        } 

        fseek( fptr,0,SEEK_SET);
#endif 
	/* Read in chunks of memory units */
	while ((sz =
		fread(buffer, sizeof(char), sizeof(buffer) - 1, fptr)) != 0) {
		buffer[sz] = '\0';
		if ((pTemp = strrchr(buffer, '\n')) != NULL) {
			fseek(fptr, 1 - strlen(pTemp), SEEK_CUR);	//After NL
			pTemp[1] = '\0';
			sz = strlen(buffer);
		}

		if (!bgnTagFound) {
			if ((pBgnString = ifx_strstr(buffer, beginTag)) == NULL) {
				fileSecPos += sz;
				continue;	/* Iterate next in while loop */
			} else {	/* Begin Tag Found */
				fileSecPos += (pBgnString - buffer);
				bgnTagFound = TRUE;

				/* Look for End Tag also now in this buffer */
				if ((pEndString =
				     ifx_strstr(buffer, endTag)) != NULL) {
					endTagFound = TRUE;
					secSz =
					    pEndString - pBgnString -
					    strlen(beginTag) + 1;
					secBuf = (char8 *) malloc(secSz);
					if (secBuf == NULL) {
#ifdef LOG_DBG
						IFX_ERR
						    ("Fn [%s]:[%d] MemAlloc for [%ld] bytes Failed!! \n",
						     __FUNCTION__, __LINE__,
						     (long int)secSz);
#endif
#ifdef LOG_DBG
						IFX_ERR
						    ("Fn [%s]:[%d] asked to find [%s] in [%s]!! \n",
						     __FUNCTION__, __LINE__,
						     pTag, pFileName);
#endif
#ifdef LOG_DBG
						IFX_ERR
						    ("[%s:%d] found [%s] in [%s] !!\n",
						     __FUNCTION__, __LINE__,
						     endTag, buffer);
#endif
#ifdef LOG_DBG
						IFX_ERR
						    ("[%s:%d] for [%s] start is [%s] and end is [%s] !!\n",
						     __FUNCTION__, __LINE__,
						     pTag, pBgnString,
						     pEndString);
#endif
#ifdef LOG_DBG
						IFX_ERR
						    ("[%s:%d] beginTag is [%s] !!\n",
						     __FUNCTION__, __LINE__,
						     beginTag);
#endif
						DB_UNLOCK_CLOSE_N_RET(fptr,
								      IFX_E_INT_ERROR)
					}

					strncpy(secBuf,
						pBgnString + strlen(beginTag) +
						1, secSz - 2);
					secBuf[secSz - 2] = '\0';
					break;	/* Come out of while loop */
				}

				/* endTag */
				/* begin Tag is present but endTag is not here */
				secSz = strlen(pBgnString) - strlen(beginTag);
				secBuf = (char8 *) malloc(secSz + 2);	//For termination
				if (secBuf == NULL) {
#ifdef LOG_DBG
					IFX_ERR
					    ("Fn [%s]:[%d] MemAlloc for [%ld] bytes Failed!! \n",
					     __FUNCTION__, __LINE__,
					     (long int)secSz);
#endif
#ifdef LOG_DBG
					IFX_ERR
					    ("Fn [%s]:[%d] asked to find [%s] in [%s]!! \n",
					     __FUNCTION__, __LINE__, pTag,
					     pFileName);
#endif
#ifdef LOG_DBG
					IFX_ERR
					    ("[%s:%d] found [%s] in [%s] !!\n",
					     __FUNCTION__, __LINE__, endTag,
					     buffer);
#endif
#ifdef LOG_DBG
					IFX_ERR
					    ("[%s:%d] for [%s] start is [%s] and end is [%s] !!\n",
					     __FUNCTION__, __LINE__, pTag,
					     pBgnString, pEndString);
#endif
#ifdef LOG_DBG
					IFX_ERR("[%s:%d] beginTag is [%s] !!\n",
						__FUNCTION__, __LINE__,
						beginTag);
#endif
					DB_UNLOCK_CLOSE_N_RET(fptr,
							      IFX_E_INT_ERROR)
				}

				strncpy(secBuf,
					pBgnString + strlen(beginTag) + 1,
					secSz);
				secBuf[secSz + 1] = '\0';
				continue;	/* Advance in loop for endTag search */
			}	/* bgnTag */
		}
		/* !bgnTagFound */
		if (bgnTagFound && !endTagFound) {
			if ((pEndString = ifx_strstr(buffer, endTag)) != NULL) {
				endTagFound = TRUE;
				if ((secBuf =
				     (char8 *) realloc(secBuf,
						       secSz + sizeof(buffer) +
						       2)) != NULL) {
					strncat(secBuf, buffer, pEndString - buffer);	//With NL
					secSz += (pEndString - buffer);
					secBuf[secSz] = '\0';
					break;	/* Break the while loop */
				}
			} else {	/* Intermediate chunk between begin and end Tag */
				if ((secBuf =
				     (char8 *) realloc(secBuf,
						       secSz + sizeof(buffer) +
						       2)) != NULL) {
					secSz += sizeof(buffer) + 1;	//For End of String
					strncat(secBuf, buffer, sizeof(buffer));	//With NL
					secBuf[secSz] = '\0';
				}
			}
		}
	}			/* while (sz ..... != 0) */

	if (!(bgnTagFound && endTagFound)) {
#ifdef LOG_DBG
		IFX_DBG
		    ("Fn [%s]:[%d] DB Section [%s] not found or misformed!!\n",
		     __FUNCTION__, __LINE__, pTag);
#endif
		if (secBuf)
			free(secBuf);
		DB_UNLOCK_CLOSE_N_RET(fptr, IFX_E_SEC_NOT_FOUND)
	}

	if (secPosition)
		*secPosition = fileSecPos;

	/* Is Section Empty ?? */
	if (secBuf != NULL) {
		if ((strchr(secBuf, '\n')) == NULL) {
			free(secBuf);
			DB_UNLOCK_CLOSE_N_RET(fptr, IFX_E_SEC_EMPTY)
		}
	}
	*pRetSec = secBuf;
	fclose(fptr);
	return IFX_SUCCESS;
}

int32 ifx_ReadObject(char8 * secBuf, char8 * pattern, uint32 stateFlag,
		     char8 ** pRetVal)
{
	char8 *pString, *pString1, *temp, *pRet, *temp_pRet;
	uint8 matchFlag, formString;
	uint32 /*totalSize,*/ filledSize, size;

	matchFlag = formString = FALSE;

//	totalSize = filledSize = size = 0;
	filledSize = size = 0;

	pString1 = temp = pRet = *pRetVal = temp_pRet = NULL;

	pString = secBuf;

	if (!strlen(secBuf)) {	//Section is empty. 
#ifdef LOG_DBG
		IFX_DBG("Fn [%s]:[%d] Error --> Section is Empty!!\n",
			__FUNCTION__, __LINE__);
#endif
		return IFX_E_SEC_EMPTY;
	}

	if (pattern == NULL)	//Pattern not inputted.
	{
		if (stateFlag == IFX_F_GET_ANY) {
			pRet = (char8 *) malloc((strlen(secBuf) + 1));
			if (pRet == NULL) {
#ifdef LOG_DBG
				IFX_DBG
				    ("Fn [%s]:[%d] Error --> MemAlloc failed!!\n",
				     __FUNCTION__, __LINE__);
#endif
				return IFX_E_INT_ERROR;
			}
			strcpy(pRet, secBuf);
			*pRetVal = pRet;
			return IFX_SUCCESS;
		} else {
			while ((pString1 = strchr(pString, '\n')) != NULL) {
				if (pString[0] != '#') {	//Non-hashed - Enabled entry.
					if ((stateFlag == IFX_F_GET_ENA)
					    || (stateFlag == IFX_F_DEFAULT)) {
						size = pString1 - pString + 1;
						temp = pString;
						matchFlag = formString = TRUE;
					}
				} else {	//Hashed - Disabled or Incomplete entry.
					if (pString[1] == '$') {	//Incomplete entry
						if (stateFlag ==
						    IFX_F_GET_INCOMP) {
							size =
							    pString1 - pString -
							    1;
							temp = &pString[2];
							matchFlag = formString =
							    TRUE;
						}
					} else {	//Disabled Entry
						if ((stateFlag == IFX_F_GET_DIS)
						    || (stateFlag ==
							IFX_F_DEFAULT)) {
							size =
							    pString1 - pString;
							temp = &pString[1];
							matchFlag = formString =
							    TRUE;
						}
					}
				}
				if (matchFlag) {	//Realloc size+string-termination(1)
					if ((temp_pRet =
					     (char8 *) realloc(pRet,
							       filledSize +
							       size + 1)) !=
					    NULL) {
						pRet = temp_pRet;
						memcpy((pRet + filledSize), temp, size);	//With NL
						filledSize += size;
						matchFlag = FALSE;
					}
				}
				pString += (pString1 - pString) + 1;
			}	//while
		}		//else !ANY
	} else {
		//Partial Pattern given .. do wild carding
		if ((pString = strstr(secBuf, pattern)) == NULL) {
#ifdef LOG_DBG
			IFX_DBG
			    ("Fn [%s]:[%d] Error --> Substring pattern match failed!!\n",
			     __FUNCTION__, __LINE__);
#endif
			return IFX_FAILURE;
		}

		while (pString != NULL) {
			if ((pString1 = strchr(pString, '\n')) != NULL) {
				size = pString1 - pString + 1;
				if (*(pString - 1) == '$') {
					if ((stateFlag == IFX_F_GET_INCOMP)
					    || (stateFlag == IFX_F_GET_ANY))
						matchFlag = formString = TRUE;

				} else {
					if (*(pString - 1) == '#') {
						if ((stateFlag == IFX_F_GET_DIS)
						    || (stateFlag ==
							IFX_F_GET_ANY)
						    || (stateFlag ==
							IFX_F_DEFAULT))
							matchFlag = formString =
							    TRUE;
					} else {
						if ((stateFlag == IFX_F_GET_ENA)
						    || (stateFlag ==
							IFX_F_GET_ANY)
						    || (stateFlag ==
							IFX_F_DEFAULT))
							matchFlag = formString =
							    TRUE;
					}
				}
				if (matchFlag) {
					if ((temp_pRet =
					     (char8 *) realloc(pRet,
							       filledSize +
							       size + 1)) !=
					    NULL) {
						pRet = temp_pRet;
						memcpy(pRet + filledSize, pString, size);	//With NL
						filledSize += size;
						matchFlag = FALSE;
					}
				}
				pString += size;
				pString = strstr(pString, pattern);
			} else {
#ifdef LOG_DBG
	IFX_DBG("Fn [%s]:[%d] Error --> Invalid section buffer !!\n",
		__FUNCTION__, __LINE__);
#endif
				return IFX_E_INVALID_INPUT;
			}
		}
	}
	if (formString) {
		if (pRet) {
			*(pRet + filledSize) = '\0';
			*pRetVal = pRet;
			return IFX_SUCCESS;
		}
	}
#ifdef LOG_DBG
	IFX_DBG("Fn [%s]:[%d] Error --> No match for Substring pattern !!\n",
		__FUNCTION__, __LINE__);
#endif

	return IFX_E_UNMATCHED_INPUT;
}

/////////////////////////////////////////////////////////////////////////////////
//ifx_GetCfgData(...)
//      Variable Name   ==>     File Name               ;       Pipe Command
//-------------------------------------------------------------------------------
//      pFileName               ==>     Open File Name  ;       Open pipe command
//      pTag                    ==>     TAG_xxx                 ;       NULL
//      pData                   ==>     Search Name             ;       which Line obtained
//      pRetValue               ==>     Return string.  ;       Return string.
//
//      Return Value :  0 is FALSE. 1 is TRUE
//
//      ex1. File Name ==>      if ( ifx_GetCfgData(FILE_RC_CONF, TAG_DHCP_BINPOND, "Server", sValue) == 1)
//      ex2. Pipe          ==>  if ( ifx_GetCfgData(&command, NULL, "1", sValue) == 1 )
///////////////////////////////////////////////////////////////////////////////////

int32 ifx_GetCfgData(IFX_IN const char8 * pFileName,
		     IFX_IN const char8 * pTag,
		     IFX_IN char8 * pData, IFX_OUT char8 * pRetValue)
{
	int32 retVal;
	retVal = ifx_GetObjData(pFileName, pTag, pData, 0, NULL, pRetValue);

	return (retVal < 0) ? 0 : 1;
}

/////////////////////////////////////////////////////////////////////////////////
//ifx_GetObjData(...)
//      Variable Name   ==>     File Name               ;       Pipe Command
//-------------------------------------------------------------------------------
//      pFileName               ==>     Open File Name  ; Open pipe command
//      pTag                    ==>     TAG_xxx         ;       NULL
//      pData                   ==>     Search Name     ; Which Line obtained
//      inFlag                  ==>     State filter inputted by user;
//      pOutFlag                ==>     Output actual State given back;
//      pRetValue               ==>     Return string.  ;       Return string.
//
//      Return Value :  IFX_SUCCESS - Suceess, Error Code - Failure.
//
//      ex1. File Name ==>      if ( ifx_GetObjData(FILE_RC_CONF, TAG_DHCP_BINPOND, "Server", sValue) == 1)
//      ex2. Pipe          ==>  if ( ifx_GetObjData(&command, NULL, "1", sValue) == 1 )
///////////////////////////////////////////////////////////////////////////////////
int32 ifx_GetObjData(IFX_IN const char8 * pFileName,
		     IFX_IN const char8 * pTag,
		     IFX_IN char8 * pData,
		     IFX_IN uint32 inFlag,
		     IFX_OUT uint32 * outFlag, IFX_OUT char8 * pRetValue)
{
	int32 ret = IFX_SUCCESS;
	char8 *pSecBuf = NULL;
	uint32 secOffset = 0;

	if (outFlag)
		*outFlag = inFlag;

	if (!(pFileName && pData)) {
#ifdef LOG_DBG
		IFX_ERR("GET:Null File (or Pipe) and (or)  Parameter Name\n");
#endif
		return IFX_FAILURE;
	}

	if (pTag) {		/* File Operation */
		if ((ret =
		     ifx_GetSection(pFileName, pTag, &pSecBuf,
				    &secOffset)) == IFX_SUCCESS) {
			ret =
			    ifx_GetCfgDatafromString(pSecBuf, pData, outFlag,
						     pRetValue);
			free(pSecBuf);
		}
		return ret;
	} else {		/* Pipe Operation */
		return ifx_PipeOperation(pFileName, pData, pRetValue);
	}
	return IFX_SUCCESS;
}

int32 ifx_GetObjDataOpt(IFX_IN const char8 * pFileName,
			IFX_IN const char8 * pTag,
			IFX_IN char8 * pData,
			IFX_IN uint32 inFlag,
			IFX_OUT uint32 * outFlag, IFX_OUT char8 * pRetValue)
{
	int32 ret = IFX_SUCCESS;
	char8 *pSecBuf = NULL;
	uint32 secOffset = 0;

	if (outFlag)
		*outFlag = inFlag;

	if (!(pFileName && pData)) {
#ifdef LOG_DBG
		IFX_ERR("GET:Null File (or Pipe) and (or)  Parameter Name\n");
#endif
		return IFX_FAILURE;
	}

	if (IFX_INT_CACHE_INIT_F_SET(inFlag)) {
		if (!strlen(gCache_secName) && !strlen(gCache_inst)) {
			strcpy(gCache_secName, pTag);
			strcpy(gCache_inst, pData);
		}

		/* check if secname and prefix match */
		if (!strcmp(gCache_secName, pTag)
		    && !strcmp(gCache_inst, pData)) {
			if (!gCache_use_count) {
				if ((ret =
				     ifx_GetSection(pFileName, pTag, &pSecBuf,
						    &secOffset)) ==
				    IFX_SUCCESS) {
					inFlag &= ~IFX_F_INT_CACHE_INIT;
					ret =
					    ifx_ReadObject(pSecBuf, pData,
							   inFlag, &gCache);

					free(pSecBuf);
				}
				if (ret != IFX_SUCCESS) {
					gCache_use_count++;
					goto destroy_lbl;
				}
			}
			gCache_use_count++;
		}

		return ret;
	} else if (IFX_INT_CACHE_DESTROY_F_SET(inFlag)) {
	      destroy_lbl:
		/* check if secname and prefix match */
		if (!strcmp(gCache_secName, pTag)
		    && !strcmp(gCache_inst, pData)) {
			if (gCache_use_count == 1) {
				if (gCache)
					free(gCache);
				memset(gCache_secName, 0x00,
				       sizeof(gCache_secName));
				memset(gCache_inst, 0x00, sizeof(gCache_inst));
			}
			if (gCache_use_count)
				gCache_use_count--;
		}

		return IFX_SUCCESS;
	} else {
		if (pTag) {	/* File Operation */
			if (gCache_use_count) {
				if (!strcmp(gCache_secName, pTag)
				    && strstr(pData, gCache_inst)) {
					ret =
					    ifx_GetCfgDatafromString(gCache,
								     pData,
								     outFlag,
								     pRetValue);
					if (ret != IFX_SUCCESS)
						ret =
						    ifx_GetObjData(pFileName,
								   pTag, pData,
								   inFlag,
								   outFlag,
								   pRetValue);
				} else
					ret =
					    ifx_GetObjData(pFileName, pTag,
							   pData, inFlag,
							   outFlag, pRetValue);
			} else
				ret =
				    ifx_GetObjData(pFileName, pTag, pData,
						   inFlag, outFlag, pRetValue);
			return ret;
		}
	}
	return IFX_SUCCESS;
}

/////////////////////////////////////////////////////////////////////////////////
//ifx_GetCfgObject(...)
//      Variable Name   ==>     File Name               ;       Pipe Command
//-------------------------------------------------------------------------------
//      pFileName       ==>     Open File Name  ;       Open pipe command
//      pTag            ==>     TAG_xxx         ;       NULL
//      pData           ==>     Search Name     ;       which Line obtained
//      stateFlag       ==>     State Flag Filter;      0
//      pRetValue       ==>     Return string Ptr. ;    Return string.
//
//      Return Value : IFX_SUCCESS - Successful, Error Code - Failure. 
//
///////////////////////////////////////////////////////////////////////////////////

int32 ifx_GetCfgObject(const char8 * pFileName, const char8 * pTag,
		       char8 * pData, uint32 stateFlag, char8 ** pRetValue)
{
	int32 ret = IFX_SUCCESS;
	char8 *pSecBuf = NULL;
	uint32 secOffset = 0;

	if ((ret =
	     ifx_GetSection(pFileName, pTag, &pSecBuf,
			    &secOffset)) == IFX_SUCCESS) {
		ret = ifx_ReadObject(pSecBuf, pData, stateFlag, pRetValue);
		free(pSecBuf);
	}

	return ret;
}

/*********************************************************************
 *     get_num_info_in_section: Function to return no. of lines in section.
 *     Returns : Number of Lines.
 *********************************************************************/
static int32 get_num_info_in_section(char8 * secBuf, uint8 type)
{
	char8 *temp = secBuf;
	char8 *temp1, *temp2;
	int32 numLine = 0;

	temp1 = temp2 = NULL;

	/* Returns number of NL separated lines in given buffer */
	if (type == _SEC_LINE_COUNT) {
		while ((temp = strchr(temp, '\n')) != NULL) {
			temp++;
			numLine++;
		}
	}

	/* Returns number of object instances in given buffer based on _cpeId */
	if (type == _SEC_INST_COUNT) {
		while ((temp = strstr(temp, "_cpeId")) != NULL) {
			temp += strlen("_cpeId");
			numLine++;
		}
	}

	/* Returns number of  lines in one instance of object */
	if (type == _SEC_INST_LINE_COUNT) {
		if ((temp1 = strstr(temp, "_cpeId")) != NULL) {
			temp1 += strlen("_cpeId");
			temp2 = strstr(temp1, "_cpeId");
			while ((temp1 = strchr(temp1, '\n')) != NULL) {
				temp1++;
				numLine++;
				if ((temp2 != NULL) && (temp1 >= temp2)) {
					numLine--;
					break;	/* Hit next instance in section */
				}
			}
		}
	}

	return numLine;
}

void ifx_FormSectionLineWithInput(char8 * secLine, char8 * buf, uint32 flag,
				  char8 * outLine)
{
	char8 *pString, *pString1, *pString2, *temp;
	char8 tBuf[MAX_FILELINE_LEN];
	char8 pattern[MAX_FILELINE_LEN];

	pString = pString1 = pString2 = temp = NULL;

	tBuf[0] = pattern[0] = '\0';

	strcpy(outLine, secLine);

	if (IFX_DELETE_F_SET(flag)) {	/* Wild Card Deletion Supported */
		pString = (char8 *) malloc(strlen(buf) + 1);
		if (pString == NULL) {
			return;
		}
		pString[0] = '\0';

		strcpy(pString, buf);

		pString1 = pString;
  	while ((pString2 = strchr(pString1, '\n')) != NULL) {
			strncpy(pattern, pString1, pString2 - pString1 + 1);
			pattern[pString2 - pString1 + 1] = '\0';

			if ((temp = strchr(pattern, '=')) == NULL) {
				//if (strtok(pattern, "=") == NULL) {
				free(pString);
				return;
			} else {
				pattern[temp - pattern + 1] = '\0';
				//printf("pattern = %s\n",pattern);
				if (strstr(secLine, pattern) != NULL) {
					free(pString);
					outLine[0] = '\0';
					return;
				}
			}
			pString1 = pString2 + 1;
		}		//while
		free(pString);
		return;
	}

	/* if DELETE */
	/* For other cases - Remove "#" and "#$" chars for formating line. */
	if (secLine[0] == '#') {
		if (secLine[1] == '$')
			strcpy(tBuf, &secLine[2]);
		else
			strcpy(tBuf, &secLine[1]);
	} else
		strcpy(tBuf, secLine);

	//Check with parameter name pattern search in input buffer. 
	strcpy(pattern, tBuf);

	if (strtok(pattern, "=") == NULL)
		return;

	pString = buf;

	if ((pString = ifx_strstr(pString, pattern)) == NULL)
		return;

	if (IFX_DELETE_F_SET(flag))
		return;

	if (IFX_MODIFY_F_SET(flag)) {
		pString1 = strchr(pString, '\n');
		memcpy(tBuf, pString, (pString1 - pString + 1));	//With NL
		tBuf[pString1 - pString + 1] = '\0';
		strcpy(outLine, tBuf);
	}

	if (IFX_DONT_ACTIVATE_F_SET(flag) || IFX_DEACTIVATE_F_SET(flag)) {
		outLine[0] = '#';
		strcpy(&outLine[1], tBuf);
	}

	if (IFX_INCOMPLETE_F_SET(flag)) {
		outLine[0] = '#';
		outLine[1] = '$';
		strcpy(&outLine[2], tBuf);
	}

	return;
}

int32 ifx_FormNewSection(char8 * oldSecBuf, char8 * input, uint32 flag,
			 char8 ** newSec)
{
	char8 *pString, *pString1;
	char8 fileLine[MAX_FILELINE_LEN];
	char8 tempLine[MAX_FILELINE_LEN];
	char8 *newBuf, *newBufStart, *temp1Line;
	uint8 linesAffected = 0;

	pString1 = newBuf = temp1Line = NULL;
	pString = input;

	fileLine[0] = tempLine[0] = '\0';

	/* Is it plain OVERWRITE case ?? */
	if (!flag) {
		newBuf = (char8 *) malloc(strlen(input) + 1);
		if (newBuf == NULL) {
#ifdef LOG_DBG
			IFX_ERR("Fn [%s]:[%d] - Memory Allocation failed !!!\n",
				__FUNCTION__, __LINE__);
#endif
			return IFX_E_INT_ERROR;
		}
		newBuf[0] = '\0';
		strcpy(newBuf, input);
		*newSec = newBuf;
		return IFX_SUCCESS;
	}

	/* EMPTY SECTION HANDLING */
	/* If Old Section is Empty then oldSecBuf comes as NULL */
	/* Only valid case is ADD operation in empty section */
	if (oldSecBuf == NULL) {
		if (IFX_INT_ADD_F_SET(flag)) {
			linesAffected =
			    get_num_info_in_section(input, _SEC_LINE_COUNT);
			newBuf =
			    (char8 *) malloc(strlen(input) + 2 * linesAffected +
					     1);
			if (newBuf == NULL) {
#ifdef LOG_DBG
				IFX_ERR("Fn [%s]:[%d] - Malloc Failed!!\n",
					__FUNCTION__, __LINE__);
#endif
				return IFX_E_INT_ERROR;
			}
			newBuf[0] = '\0';
			ifx_FormatAddition(input, flag, newBuf);
			*newSec = newBuf;
			return IFX_SUCCESS;
		} else {
#ifdef LOG_DBG
			IFX_ERR("Fn [%s]:[%d] - Old Section is Empty !!!\n",
				__FUNCTION__, __LINE__);
#endif
			return IFX_E_INT_ERROR;
		}
	}

	/* EMPTY SECTION HANDLING END */
	/* First verify the existence and non-existence of input patterns in
	 * Section Contents and verify against input flag */
	/* Take line by line from input buffer & compare to oldSecBuf contents */
	linesAffected = 0;
	while ((pString1 = strchr(pString, '\n')) != NULL) {
		strncpy(fileLine, pString, (pString1 - pString) + 1);	//Without NL
		fileLine[(pString1 - pString) + 1] = '\0';
		//strcpy(tempLine, fileLine);
		//strtok(tempLine, "=");

		if ((temp1Line = strchr(fileLine, '=')) != NULL) {
			strncpy(tempLine, fileLine, (temp1Line - fileLine) + 2);	//Including = i.e. name=
			tempLine[(temp1Line - fileLine) + 1] = '\0';
		}
		// printf("tempLine = %s\n",tempLine);

		if (strstr(oldSecBuf, tempLine) != NULL) {
			linesAffected++;
			//printf("Lines Affected = %d\n",linesAffected);
			if (IFX_INT_ADD_F_SET(flag)
			    || IFX_INT_MOD_ADD_F_SET(flag)) {
#ifdef LOG_DBG
				IFX_ERR
				    ("Addition of Duplicate Parameter [%s] Not Allowed\n",
				     tempLine);
#endif
				return IFX_E_INT_ERROR;
			}
		} else {	/* Pattern not found */
			linesAffected++;
			if (IFX_DELETE_F_SET(flag) || IFX_MODIFY_F_SET(flag)) {
#ifdef LOG_DBG
				IFX_ERR
				    ("Pattern Non-existent..Cant proceed with Mod or Del!!\n");
#endif
				return IFX_E_PARAM_NOT_FOUND;
			}
		}
		pString = pString1 + 1;
	}			/* while */

#ifdef LOG_DBG
	IFX_DBG("Effect in %ld number of Lines in Section\n",
		(long int)linesAffected);
#endif

	/* Initial Validation is through.. so now form the new Section */

	/* Worst Case Allocation */
	newBuf = malloc(strlen(oldSecBuf) + MAX_FILELINE_LEN * linesAffected);

	if (newBuf == NULL) {
#ifdef LOG_DBG
		IFX_ERR("Fn [%s]:[%d] - Malloc Failed!!\n", __FUNCTION__,
			__LINE__);
#endif
		return IFX_E_INT_ERROR;
	}
	newBuf[0] = '\0';

	if (IFX_INT_ADD_F_SET(flag) || IFX_INT_MOD_ADD_F_SET(flag)) {
		strcpy(newBuf, oldSecBuf);
		ifx_FormatAddition(input, flag, newBuf + strlen(oldSecBuf));
		*newSec = newBuf;
		return IFX_SUCCESS;
	}

	/* For rest of cases  iterate through Section Lines */
	newBufStart = newBuf;
	pString = oldSecBuf;
	fileLine[0] = newBuf[0] = tempLine[0] = '\0';

	while ((pString1 = strchr(pString, '\n')) != NULL) {
		memcpy(fileLine, pString, pString1 - pString + 1);	/* With NL */
		fileLine[pString1 - pString + 1] = '\0';

		tempLine[0] = '\0';
		ifx_FormSectionLineWithInput(fileLine, input, flag, tempLine);

		if (strlen(tempLine))	/* Ignore Empty Lines */
			strcat(newBuf, tempLine);

		pString = pString1 + 1;
	}			/* while */

	*newSec = newBufStart;

	return IFX_SUCCESS;
}

int32 ifx_FormatAddition(char8 * inBuf, uint32 flag, char8 * outBuf)
{
	char8 splPrep[3];
	char8 *pString = NULL;
	char8 *destString = outBuf;
	char8 *inString = inBuf;

	memset(splPrep, '\0', 3);

	if (IFX_DEACTIVATE_F_SET(flag) || IFX_DONT_ACTIVATE_F_SET(flag))
		splPrep[0] = '#';
	else if (IFX_INCOMPLETE_F_SET(flag)) {
		splPrep[0] = '#';
		splPrep[1] = '$';
	}

	while ((pString = strchr(inString, '\n')) != NULL) {
		memcpy(destString, splPrep, strlen(splPrep));
		memcpy(destString + strlen(splPrep), inString,
		       (pString - inString) + 1);
		destString += strlen(splPrep) + (pString - inString) + 1;
		inString = inString + (pString - inString) + 1;
	}
	destString[0] = '\0';

	return IFX_SUCCESS;
}

////////////////////////////////////////////////////////////////////////////////
//ifx_SetCfgData(...)
//    Variable Name    ==>    File Name
//------------------------------------------------------------------------------
//    pFileName        ==>    Open File Name
//    pTag            ==>    TAG_xxx
//    nDataCount        ==>    Data number for setting.
//    pData            ==>    Data content for setting.
//
//    Return Value :    0 is FALSE. 1 is TRUE
//

int32 ifx_SetCfgData(IFX_IN const char8 * pFileName,
		     IFX_IN const char8 * pTag,
		     IFX_IN int32 nDataCount,
		     IFX_IN const char8 * pData, IFX_IN ...)
{
	va_list args;
	int32 ret = IFX_E_INT_ERROR;
	char8 *buf = NULL;

	if (!nDataCount)
		return 0;

	// Extract data from var list and store into buffer
	if (nDataCount == 1) {
		va_start(args, pData);
		buf = (char8 *) malloc(strlen(pData) + 1);
		if (buf == NULL) {
#ifdef LOG_DBG
			IFX_ERR("Fn [%s:%d] : Malloc Failed !!\n", __FUNCTION__,
				__LINE__);
#endif
			return ret;
		}
		buf[0] = '\0';
		strcpy(buf, pData);
		va_end(args);
	} else {
		buf = (char8 *) malloc(BUF_SIZE_50K);
		if (buf == NULL) {
#ifdef LOG_DBG
			IFX_ERR("Fn [%s:%d]: Malloc Failed !!\n", __FUNCTION__,
				__LINE__);
#endif
			return ret;
		}
		va_start(args, pData);
		strcpy(buf, pData);

		while (--nDataCount) {
			pData = va_arg(args, char8 *);
			strcat(buf, pData);
		}
		va_end(args);
	}

	ret = ifx_SetObjData(pFileName, pTag, 0, 1, buf);

	free(buf);

	return (ret < 0) ? 0 : 1;	/* For backward compatibility */
}

/*********************************************************************
 *         update_file_access_version : Function to increment or decrement
 *                                      the file'c config version value.
 *         decrFlag : TRUE : Increment, FALSE : decrement
 *         Returns :
 *              1 : Success, 0 : Failure.
 *********************************************************************/

static int32 update_file_access_version(FILE * fptr, uint8 decrFlag)
{
	char8 fileLine[MAX_FILELINE_LEN];

	fileLine[0] = '\0';

	if (decrFlag)
		g_ifx_version++;
	else
		g_ifx_version--;

	fseek(fptr, 0L, SEEK_SET);

	while (fgets(fileLine, sizeof(fileLine), fptr)) {
		if ((strstr(fileLine, "config_version")) != NULL) {
			fseek(fptr, 0 - strlen(fileLine), SEEK_CUR);
			fprintf(fptr, ("config_version=\"%8x\"\n"),
				g_ifx_version);
			return 1;
		}
		fileLine[0] = '\0';
	}

	return 0;
}

////////////////////////////////////////////////////////////////////////////////
//ifx_SetObjData(...)
//   This is the main function for performing write operation in database. 
//------------------------------------------------------------------------------
//    pFileName        ==>    Open File Name
//    pTag             ==>    TAG_xxx
//    operFlag         ==>    Operation Bit Flag.
//    nDataCount       ==>    Data number for setting.
//    pData            ==>    Data content for setting.
//
//    Return Value :    0 is SUCCESS. -ve Values for Error. 
//

int32 ifx_getFtype( FILE *ifp, char *begTag)
{
  char line[MAX_LENGTH];
  char *p;
  int32 stype = 0;


  while (fgets(line,MAX_LENGTH, ifp) != NULL){
     skip_space( line,p);
    if( strncmp(p,begTag, strlen(begTag))){
     continue;
    } else {
      stype = ifx_GetSectionType( p );
      break;
    }
  }

  return stype;
}

int32 ifx_SetObjData(IFX_IN const char *pFileName,
		     IFX_IN const char *pTag,
		     IFX_IN uint32 operFlag,
		     IFX_IN int32 nDataCount,
		     IFX_IN const char *pData, IFX_IN ...)
{
	FILE *fptr = NULL, *fptr1 = NULL;
	char8 *buffer, *outBuf, *secBuf, *newSecBuf, *chunkBuf;
	char8 beginTag[MAX_TAG_LEN], endTag[MAX_TAG_LEN];	//, t_buf[MAX_FILELINE_LEN];
        uint32  secLen = 0 ;
	va_list args;
#ifdef CONFIG_RC_CONF_RW_OPTIMISATION
        uint32 ftype;
        uint32 sec_len = 0;
#endif
	uint32 rdOffset, wrOffset, chunkSize, secSz, sz, fileSz, secPos;
	int32 ret = IFX_FAILURE;

	rdOffset = wrOffset = chunkSize = secSz = sz = fileSz = secPos = 0;
	buffer = outBuf = secBuf = newSecBuf = chunkBuf = NULL;

	beginTag[0] = endTag[0] = '\0';

	//Initialize semaphore 
	semid = init_sem(SEMAPHORE_KEY);

	if (!(pFileName && pTag && pData)) {
#ifdef LOG_DBG
		IFX_ERR("SET:Invalid File or Section Name or Data\n");
#endif
		return ret;
	}

	if ((fptr = fopen(pFileName, "r+")) == NULL) {
#ifdef LOG_DBG
		IFX_ERR
		    ("Function [%s]:[%d] Error--> DB file [%s] open failed!!\n",
		     __FUNCTION__, __LINE__, pFileName);
#endif
//        free(buffer);
//        free(secBuf);
		return ret;
	}
#if 0
	if ((fptr1 = fopen("/tmp/syscfg_log", "r+")) == NULL) {
		IFX_DBG("failed to open debug file");
		DB_UNLOCK_CLOSE_N_RET(fptr1, ret)
		    return ret;
	}
	IFX_DBG("[%s:%d] start", __FUNCTION__, __LINE__);
#endif
	/* Get an Exclusive Write Lock */

	if (enter_critical_section(semid) == 0) {
		if (flock(fileno(fptr), LOCK_EX) < 0) {
#ifdef LOG_DBG
			IFX_ERR("Unable to perform Exclusive Lock on: %s\n",
				pFileName);
#endif
			//    free(buffer);
			// free(secBuf);
			fclose(fptr);
			ret = IFX_E_INT_ERROR;
			isLkSet = 0;
			exit_critical_section(semid);
			goto syscfg_lbl;
		}
		isLkSet = 1;

		// First, extract data from var list and store into buffer
		if (nDataCount == 1) {
			va_start(args, pData);
			buffer = (char8 *) malloc(strlen(pData) + 1);
			if (buffer == NULL) {
#ifdef LOG_DBG
				IFX_ERR("Fn [%s:%d] : Malloc Failed !!\n",
					__FUNCTION__, __LINE__);
#endif
				ret = IFX_E_INT_ERROR;
				isLkSet = 0;
				exit_critical_section(semid);
				goto syscfg_lbl;
			}

			buffer[0] = '\0';
			strcpy(buffer, pData);
			va_end(args);
		} else {	/* More than 1 args passed */
			buffer = (char8 *) malloc(BUF_SIZE_50K);
			if (buffer == NULL) {
#ifdef LOG_DBG
				IFX_ERR("Fn [%s:%d] : Malloc Failed !!\n",
					__FUNCTION__, __LINE__);
#endif
				ret = IFX_E_INT_ERROR;
				isLkSet = 0;
				exit_critical_section(semid);
				goto syscfg_lbl;
			}
			va_start(args, pData);
			strcpy(buffer, pData);

			while (--nDataCount) {
				pData = va_arg(args, char8 *);
				strcat(buffer, pData);
			}
			va_end(args);
		}

		snprintf(beginTag, MAX_TAG_LEN, "%s%s", BEGIN_TAG_PATTERN,
			 pTag);
		snprintf(endTag, MAX_TAG_LEN, "%s%s", END_TAG_PATTERN, pTag);
#ifdef CONFIG_RC_CONF_RW_OPTIMISATION
	ftype = ifx_getFtype( fptr, BEGIN_TAG_PATTERN);
#endif 
	fseek( fptr,0,SEEK_SET);
	ret = ifx_GetSection_t1(pFileName, pTag, &secBuf, &secPos,&secLen);

		if (!
		    ((ret == IFX_E_SEC_NOT_FOUND) || (ret == IFX_E_SEC_EMPTY)
		     || (ret == IFX_SUCCESS))) {
#ifdef LOG_DBG
			IFX_ERR("SET:Error in reading Section\n");
#endif
			//free(buffer);
			isLkSet = 0;
			exit_critical_section(semid);
			goto syscfg_lbl;
		}

		/* For Non-existent or Empty Section ------
		   ----  Only valid operation is OVERWRITE or ADD */
		if ((ret == IFX_E_SEC_NOT_FOUND) || (ret == IFX_E_SEC_EMPTY)) {
			if (!((operFlag == IFX_F_DEFAULT) ||
			      IFX_INT_ADD_F_SET(operFlag)
			      || IFX_INT_MOD_ADD_F_SET(operFlag))) {
#ifdef LOG_DBG
				IFX_ERR
				    ("Section %s is non-existent or Empty \n",
				     pTag);
#endif
				isLkSet = 0;
				exit_critical_section(semid);
				goto syscfg_lbl;
			}
		}

		/* Is Section Not Present - Append at end of File */
		if (ret == IFX_E_SEC_NOT_FOUND) {
			/* Increment config_version, if present on db */
			update_file_access_version(fptr, TRUE);

			/* Go to end of file and append new section */
			fseek(fptr, 0L, SEEK_END);

			if (!operFlag) {	/* Overwrite the formatted input */
#ifdef CONFIG_RC_CONF_RW_OPTIMISATION
		    if (ftype){
			sec_len = strlen(buffer) + strlen(endTag) + 2;
			fprintf(fptr, "%s ##%d\n", beginTag,sec_len);
		    }else
#endif 
			fprintf(fptr, "%s\n", beginTag);

   	        	//fprintf(fptr, buffer);
			fwrite(buffer, strlen(buffer), 1, fptr);
			fprintf(fptr, "%s\n\n", endTag);
				ret = IFX_SUCCESS;
			} else {	/* Append after formatting input */
				sz = get_num_info_in_section(buffer,
							     _SEC_LINE_COUNT);
				outBuf =
				    (char8 *) malloc(strlen(buffer) + 1 +
						     sz * 2);
				if (outBuf == NULL) {
#ifdef LOG_DBG
					IFX_ERR
					    ("Fn [%s]:[%d] Err-> Malloc failed!!\n",
					     __FUNCTION__, __LINE__);
#endif
					update_file_access_version(fptr, FALSE);
					ret = IFX_E_INT_ERROR;
					isLkSet = 0;
					exit_critical_section(semid);
					goto syscfg_lbl;
				}
				outBuf[0] = '\0';
				ifx_FormatAddition(buffer, operFlag, outBuf);
#ifdef CONFIG_RC_CONF_RW_OPTIMISATION
         			if (ftype){
 			          sec_len = strlen(outBuf) + strlen(endTag) + 2;
			          fprintf(fptr, "%s ##%d\n", beginTag,sec_len);
			        } else 
#endif
			          fprintf(fptr, "%s\n", beginTag);

				if (strlen(outBuf))
					//fprintf(fptr, outBuf);
					fwrite(outBuf, strlen(outBuf), 1, fptr);
				fprintf(fptr, "%s\n\n", endTag);
				ret = IFX_SUCCESS;
			}
			isLkSet = 0;
			exit_critical_section(semid);
			goto syscfg_lbl;
		} else {	//Section Exists - Empty or Filled
			sz = 0;

			ret =
			    ifx_FormNewSection(secBuf, buffer, operFlag,
					       &newSecBuf);

			if (ret != IFX_SUCCESS) {
#ifdef LOG_DBG
				IFX_ERR
				    ("Fn [%s]:[%d] Section [%s] Formatting failed !! \n",
				     __FUNCTION__, __LINE__, pTag);
#endif
				update_file_access_version(fptr, FALSE);
				isLkSet = 0;
				exit_critical_section(semid);
				goto syscfg_lbl;
			}

			/* Increment config_version, if present on db */
			update_file_access_version(fptr, TRUE);

			if (secBuf)
				sz = strlen(secBuf);

#ifdef CONFIG_RC_CONF_RW_OPTIMISATION
		if (ftype )
		   secSz = sz + secLen + strlen(endTag) + 1;
		else 
#endif 
			secSz = sz + strlen(beginTag) + strlen(endTag) + 2;

			/* Read in chunks of Section Size */
			rdOffset = secPos + secSz + 1;

			/* Check whether it is end of file i.e. last section */
			fseek(fptr, 0L, SEEK_END);
			fileSz = ftell(fptr);

			if (fseek(fptr, rdOffset, SEEK_SET) != 0) {
				update_file_access_version(fptr, FALSE);
				ret = IFX_E_INT_ERROR;
				isLkSet = 0;
				exit_critical_section(semid);
				goto syscfg_lbl;
			}

			sz = ftell(fptr);	/* End of Old Section is read position */


			//Check for  Last Section.. directly update at section position 
			if (fileSz <= sz) {
				fseek(fptr, secPos, SEEK_SET);
#ifdef CONFIG_RC_CONF_RW_OPTIMISATION
			        if (ftype){
			           sec_len = strlen(newSecBuf) + strlen(endTag) + 2;
			           fprintf(fptr, "%s ##%d\n", beginTag,sec_len);
			        } else 
#endif
  			   fprintf(fptr, "%s\n", beginTag);

				//fprintf(fptr, newSecBuf);
				fwrite(newSecBuf, strlen(newSecBuf), 1, fptr);
				fprintf(fptr, "%s\n\n", endTag);
				sz = ftell(fptr);
				ftruncate(fileno(fptr), (off_t) sz);
			} else {	/* Not Last Section */

				chunkSize =
				    ((fileSz - sz) <
				     secSz) ? (fileSz - sz) : secSz;

				chunkBuf = (char8 *) malloc(chunkSize + 1);	//For End of String 

				if (chunkBuf == NULL) {
#ifdef LOG_DBG
					IFX_ERR
					    ("Fn [%s:%d] : Malloc Failed !!\n",
					     __FUNCTION__, __LINE__);
#endif
					update_file_access_version(fptr, FALSE);
					ret = IFX_E_INT_ERROR;
					isLkSet = 0;
					exit_critical_section(semid);
					goto syscfg_lbl;
				}

				/* Update file in small chunks.. read and write by adjusting Ptr */
				wrOffset = secPos;

				sz = 0;
				while ((sz =
					fread(chunkBuf, 1, chunkSize,
					      fptr)) != 0) {
					chunkBuf[sz] = '\0';
					rdOffset = ftell(fptr);
					fseek(fptr, wrOffset, SEEK_SET);
					// fprintf(fptr, chunkBuf);
					fwrite(chunkBuf, strlen(chunkBuf), 1, fptr);
					wrOffset = ftell(fptr);
					fseek(fptr, rdOffset, SEEK_SET);
				}

				/* Reached end of file through iterations..so now 
				 * Append the Section contents at Write Offset now */

				fseek(fptr, wrOffset, SEEK_SET);
#ifdef CONFIG_RC_CONF_RW_OPTIMISATION
                                if (ftype){
                                   sec_len = strlen(newSecBuf) + strlen(endTag) + 2;
				   fprintf(fptr, "%s ##%d\n", beginTag,sec_len);
                                } else 
#endif 
				   fprintf(fptr, "%s\n", beginTag);

				//fprintf(fptr, newSecBuf);
				fwrite(newSecBuf, strlen(newSecBuf), 1, fptr);
				fprintf(fptr, "%s\n\n", endTag);

				wrOffset = ftell(fptr);
				ftruncate(fileno(fptr), (off_t) wrOffset);
				ret = IFX_SUCCESS;
			}
		}
		isLkSet = 0;
		exit_critical_section(semid);
	}

syscfg_lbl:
	IFX_MEM_FREE(buffer);
	IFX_MEM_FREE(outBuf);
	IFX_MEM_FREE(secBuf);
	IFX_MEM_FREE(newSecBuf);
	IFX_MEM_FREE(chunkBuf);
	if (fptr1)
		fclose(fptr1);
	fflush(fptr);
	DB_UNLOCK_CLOSE_N_RET(fptr, ret)
}

////////////////////////////////////////////////////////////////////////////////
//ifx_CompactCfgSection(...)
//    It counts the indices of section and makes the indexing sequential.
//------------------------------------------------------------------------------
//    pFileName        ==>    Open File Name
//    pTag             ==>    TAG_xxx
//    flag             ==>    Type of Operation
//    Return Value :   IFX_SUCCESS - if operation is Successful
//                     Error Code - if Failed. 
//

int32 ifx_CompactCfgSection(IFX_IN const char *pFileName,
			    IFX_IN const char *pTag, IFX_IN uint32 flag)
{
	char8 *secBuf, *outBuf, *pStr, *pString, *pString1, *pString2, *temp;
	char8 lineBuf[MAX_FILELINE_LEN], nameBuf[MAX_FILELINE_LEN],
	    valBuf[MAX_FILELINE_LEN];
	int32 i, count, index, numLine, ret;

	/* Initialize Local Variables */
	secBuf = outBuf = pStr = pString = pString1 = pString2 = temp = NULL;
	i = count = numLine = index = 0;
	ret = IFX_FAILURE;

	if (!(pFileName && pTag)) {
#ifdef LOG_DBG
		IFX_ERR
		    ("CompactCfgSection : Null File or Section for Compaction\n");
#endif
		goto syscfg_lbl;
	}

	if (!
	    (IFX_DELETE_F_SET(flag) || IFX_INT_ADD_F_SET(flag)
	     || IFX_INT_MOD_ADD_F_SET(flag))) {
#ifdef LOG_DBG
		IFX_ERR("CompactCfgSection : Invalid Flag in Compaction \n");
#endif
		goto syscfg_lbl;
	}

	ret = ifx_GetSection(pFileName, pTag, &secBuf, (uint32 *) & count);

	if (ret != IFX_SUCCESS) {
#ifdef LOG_DBG
		IFX_ERR("Section Buffer Read Failed for [%s]\n", pTag);
#endif
		goto syscfg_lbl;
	}

	ret = IFX_FAILURE;

	/* Look for <prefix>_Count pattern before proceeding */
	sprintf(lineBuf, "%s_Count", pTag);
	if ((pStr = ifx_strstr(secBuf, lineBuf)) == NULL) {
#ifdef LOG_DBG
		IFX_DBG("Fn [%s] : Param [%s] not found in section [%s]!!\n",
			__FUNCTION__, lineBuf, pTag);
#endif
		goto syscfg_lbl;
	}

	if ((pString = strchr(pStr, '\n')) == NULL) {
#ifdef LOG_DBG
		IFX_DBG("Fn [%s]: No \\n found in sec [%s]!!\n", __FUNCTION__,
			pTag);
#endif
		goto syscfg_lbl;
	}

	pString++;		/* Advance after NL i.e. after Count */

	count = get_num_info_in_section(pString, _SEC_INST_COUNT);
	numLine = get_num_info_in_section(pString, _SEC_INST_LINE_COUNT);

	//Form the section and invoke SetCfgData with overwrite flag .
	outBuf = (char8 *) malloc(strlen(secBuf) + (numLine * count) + 1);	//malleck
	//outBuf = (char8 *) malloc(strlen(secBuf)+count+1);  //VALGRIND
	if (outBuf == NULL) {
#ifdef LOG_DBG
		IFX_ERR("Fn [%s] Memory Allocation failed \n", __FUNCTION__);
#endif
		ret = IFX_E_INT_ERROR;
		goto syscfg_lbl;
	}

	outBuf[0] = '\0';

	if (pStr > secBuf) {	//Non-instantiated contents present in section.
		strncpy(outBuf, secBuf, (pStr - secBuf));
		outBuf[pStr - secBuf] = '\0';
	}

	sprintf(nameBuf, "%s=\"%d\"\n", lineBuf, count);
	strcat(outBuf, nameBuf);
	temp = outBuf + strlen(outBuf);

	if ((count == 0) || (numLine == 0)) {
		/* Update Section Count to Zero */
#ifdef LOG_DBG
		IFX_DBG
		    ("Fn [%s]: No. of Instances [%d] with Lines [%d] in sec [%s]!!\n",
		     __FUNCTION__, count, numLine, pTag);
#endif
		ret = ifx_SetObjData(pFileName, pTag, IFX_F_DEFAULT, 1, outBuf);
		goto syscfg_lbl;
	}

	pString = strchr(pStr, '\n');
	pString++;		//Next Line after count in Section Buffer

	while (count != 0) {
		for (i = 0; i < numLine; i++) {
			if (pString == NULL)
				goto syscfg_lbl;
			if ((pString1 = strchr(pString, '\n')) == NULL)
				break;

			lineBuf[0] = nameBuf[0] = valBuf[0] = '\0';

			strncpy(lineBuf, pString, pString1 - pString + 1);
			lineBuf[pString1 - pString + 1] = '\0';

			if ((pString2 = strrchr(lineBuf, '=')) != NULL) {
				strncpy(nameBuf, lineBuf,
					pString2 - lineBuf + 1);
				nameBuf[pString2 - lineBuf + 1] = '\0';
				strncpy(valBuf, pString2 + 1,
					strlen(lineBuf) - (pString2 - lineBuf +
							   1));
				valBuf[strlen(lineBuf) -
				       (pString2 - lineBuf + 1)] = '\0';

				if ((pString1 = strrchr(nameBuf, '_')) != NULL) {
					pStr = pString1;
					while ((*(--pStr) != '_'))
						continue;

					memcpy(temp, nameBuf,
					       pStr - nameBuf + 1);
					temp += (pStr - nameBuf + 1);

					sprintf(temp, "%d", index);

					strcat(outBuf, pString1);
					strcat(outBuf, valBuf);	//Include NL
					temp = outBuf + strlen(outBuf);;

					if ((pString =
					     strchr(pString, '\n')) != NULL)
						pString++;
				}
			}
		}
		count--;
		index++;
	}			/* while (count.. */

	ret = ifx_SetObjData(pFileName, pTag, IFX_F_DEFAULT, 1, outBuf);
      syscfg_lbl:
	if (secBuf != NULL)
		free(secBuf);
	if (outBuf != NULL)
		free(outBuf);
	return ret;
}

////////////////////////////////////////////////////////////////////////////////
//    ifx_UpdateCountInSection(...)
//    Update the count param in section.
//------------------------------------------------------------------------------
//    pFileName        ==>    Open File Name
//    pTag             ==>    TAG_xxx
//    flag             ==>    Type of Operation
//    Return Value :   IFX_SUCCESS - if operation is Successful
//                     Error Code - if Failed. 
//

int32 ifx_UpdateCountInSection(IFX_IN const char *pFileName,
			       IFX_IN const char *pTag, IFX_IN uint32 flag)
{
	char8 *secBuf, *outBuf, *pStr, *pString;
	char8 lineBuf[MAX_FILELINE_LEN], nameBuf[MAX_FILELINE_LEN];
	int32  count, numLine, ret;

	/* Initialize Local Variables */
	secBuf = outBuf = pStr = pString = NULL;
	count = numLine = 0;
	ret = IFX_FAILURE;

	if (!(pFileName && pTag)) {
#ifdef LOG_DBG
		IFX_ERR
		    ("ifx_UpdateCountInSection : Null File or Section for Compaction\n");
#endif
		goto syscfg_lbl;
	}

	if (!
	    (IFX_DELETE_F_SET(flag) || IFX_INT_ADD_F_SET(flag)
	     || IFX_INT_MOD_ADD_F_SET(flag))) {
#ifdef LOG_DBG
		IFX_ERR
		    ("ifx_UpdateCountInSection : Invalid Flag in Compaction \n");
#endif
		goto syscfg_lbl;
	}

	ret = ifx_GetSection(pFileName, pTag, &secBuf, (uint32 *) & count);

	if (ret != IFX_SUCCESS) {
#ifdef LOG_DBG
		IFX_ERR("Section Buffer Read Failed for [%s]\n", pTag);
#endif
		goto syscfg_lbl;
	}

	ret = IFX_FAILURE;

	/* Look for <prefix>_Count pattern before proceeding */
	sprintf(lineBuf, "%s_Count", pTag);
	if ((pStr = ifx_strstr(secBuf, lineBuf)) == NULL) {
#ifdef LOG_DBG
		IFX_DBG("Fn [%s] : Param [%s] not found in section [%s]!!\n",
			__FUNCTION__, lineBuf, pTag);
#endif
		goto syscfg_lbl;
	}

	if ((pString = strchr(pStr, '\n')) == NULL) {
#ifdef LOG_DBG
		IFX_DBG("Fn [%s]: No \\n found in sec [%s]!!\n", __FUNCTION__,
			pTag);
#endif
		goto syscfg_lbl;
	}

	pString++;		/* Advance after NL i.e. after Count */

	count = get_num_info_in_section(pString, _SEC_INST_COUNT);
	numLine = get_num_info_in_section(pString, _SEC_INST_LINE_COUNT);

	//Form the section and invoke SetCfgData with overwrite flag .
	outBuf = (char8 *) malloc(strlen(secBuf) + 1);
	if (outBuf == NULL) {
#ifdef LOG_DBG
		IFX_ERR("Fn [%s] Memory Allocation failed \n", __FUNCTION__);
#endif
		ret = IFX_E_INT_ERROR;
		goto syscfg_lbl;
	}

	outBuf[0] = '\0';

	if (pStr > secBuf) {	//Non-instantiated contents present in section.
		strncpy(outBuf, secBuf, (pStr - secBuf));
		outBuf[pStr - secBuf] = '\0';
	}

	sprintf(nameBuf, "%s=\"%d\"\n", lineBuf, count);
	strcat(outBuf, nameBuf);

	if ((count == 0) || (numLine == 0)) {
		/* Update Section Count to Zero */
#ifdef LOG_DBG
		IFX_DBG
		    ("Fn [%s]: No. of Instances [%d] with Lines [%d] in sec [%s]!!\n",
		     __FUNCTION__, count, numLine, pTag);
#endif
		ret = ifx_SetObjData(pFileName, pTag, IFX_F_DEFAULT, 1, outBuf);
		goto syscfg_lbl;
	}

	pString = strchr(pStr, '\n');
	pString++;		//Next Line after count in Section Buffer

	strcat(outBuf, pString);

#if 0
	while (count != 0) {
		for (i = 0; i < numLine; i++) {
			if (pString == NULL)
				goto syscfg_lbl;
			strcat(outBuf, pString);

			if ((pString = strchr(pString, '\n')) != NULL)
				pString++;
		}
		count--;
	}			/* while (count.. */
#endif				/* #if 0 */

	ret = ifx_SetObjData(pFileName, pTag, IFX_F_DEFAULT, 1, outBuf);

      syscfg_lbl:
	if (secBuf != NULL)
		free(secBuf);
	if (outBuf != NULL)
		free(outBuf);
	return ret;
}
