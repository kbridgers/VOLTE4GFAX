/* ============================================================================
 * Copyright (C) 2004 - Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 * ============================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ============================================================================
 */

/* ===========================================================================
 *
 * File Name    : snmp_api.c
 * Author       : Subbi
 * Date         : 27-Jul-2004
 *
 * ===========================================================================
 *
 * Project      : Amazon
 * Block        : ADSL-MIBs
 *
 * ===========================================================================
 * Contents: This file contains functions for:
 *                 1) Reading the configuration from snmpd.conf file
 *                 2) Writing the configuration to snmpd.conf file
 *                 3) Adding/Deleting an SNMPv3 user
 *                 4) Getting the list of SNMPv3 users
 *                 5) Utility functions which aid in the implementation of
 *                    the above functions
 *
 * ===========================================================================
 * References: RFC 2662
 *
 */

/* ===========================================================================
 * Revision History:
 *
 * $Log$
 * ===========================================================================
 */

/*
 * ===========================================================================
 *                           INCLUDE FILES
 * ===========================================================================
 */
#include <ifx_common.h>
#include "ifx_config.h"
#include "ifx_snmp_api.h"
#include "../../include/ifx_amazon_cfg.h"

#include <unistd.h>
#include <stdlib.h>
#include <ctype.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>

//#define IFX_LOG_DEBUG

char v1_marker[] = "######  V1 Configuration  ######";
char v3_marker[] = "######  V3 Configuration  ######";
char *token_arr[] = { "rocommunity", "rwcommunity", "trapsink", "trapsink2",
	"rouser", "rwuser", "authtrapenable", "agentaddress", "sysname",
	"syslocation", "syscontact"
};

/* This function returns a line from the file
 * whose position is given by the file pointer */
void get_line(FILE * fptr, char *line)
{
	memset(line, '\0', MAX_LINE_LEN);
	fgets(line, MAX_LINE_LEN, fptr);
	return;
}

/* This function checks if it's a blank line
 * A line is considered as blank if the first 
 * character in the line matches the subset */
int is_blank_line(char *line)
{
	/* Always expects that first character in blank line is 
	 * a sub-set of {\n,\t,\f,\r,\v,""}
	 */
	if (isspace(line[0]))
		return 1;
	else
		return 0;
}

/* This function takes the given line and splits
 * into tokens. This function does not tokenize
 * the marker line */
int tokenize_line(char *line, char *tok, char *tokval)
{
	char *token = NULL, *token_value = NULL;

	/* Initialize the tokens */
	memset(tok, '\0', MAX_TOK_SIZE);
	memset(tokval, '\0', MAX_TOKVAL_SIZE);

	if ((is_blank_line(line)) ||
	    /* basically it's  a marker */
	    ((line[0] == '#') && (line[1] == '#')))
		return FAIL;

	else {
		token = strtok(line, delimiters);
		if (token != NULL) {
			strncpy(tok, token, strlen(token));
			tok[strlen(token)] = '\0';

			/* Get the token values */
			token_value = strtok(NULL, delimiters);
			if (token_value != NULL) {
				strncpy(tokval, token_value,
					strlen(token_value));
				tokval[strlen(token_value)] = '\0';
			}
		}
	}
	return SUCCESS;
}

/* This function is a special handler for trapsink lines
 * in the configuration file. This tokenizes a trapsink
 * line as : trapsink trapcommunity traport tokens */
void tokenize_trapsink_line(char *line, char *trapsink,
			    char *traphost, char *trapcomm,
			    unsigned long *trapport)
{

	char *token = NULL, *token_value = NULL;

	/* Initialize the trapsink parameters */
	memset(trapsink, '\0', MAX_TOK_SIZE);
	memset(traphost, '\0', MAX_TOKVAL_SIZE);
	memset(trapcomm, '\0', MAX_TOKVAL_SIZE);
	memset(trapport, 0, sizeof(unsigned long));

	/* Start tokenizing the line */
	token = strtok(line, delimiters);
	if (token == NULL)
		return;
	strncpy(trapsink, token, strlen(token));
	token_value = strtok(NULL, delimiters);
	if (token_value == NULL)
		return;
	strncpy(traphost, token_value, strlen(token_value));
	while ((token_value = strtok(NULL, delimiters)) != NULL) {
		/* Now get the optional trapsink params */
		if (isdigit(token_value[0])) {
			*trapport = strtoul(token_value, NULL, 10);
			break;
		} else {
			strncpy(trapcomm, token_value, strlen(token_value));
		}
	}
	return;
}

/* This function maps a character token to an integer
 * equivalent value. This is used to achieve the swicth 
 * case functionality where the case constant is a
 *  character token */
void map_chartok_to_inttok(char *chartok, int *inttok)
{
	int i;
	for (i = 0; i < 11; i++) {
		if (strcmp(chartok, token_arr[i]) == 0) {
			*inttok = i;
			return;
		}
	}
	*inttok = TOK_DEFTOK;
	return;
}

/* This function prepends a '#' to the
 * token. Used in commenting a line in
 * the configuration file */
void comment_token(char *tok)
{
	char commenttok[MAX_TOK_SIZE];

	if ((tok == NULL) || (strlen(tok) >= (MAX_TOK_SIZE - 1))) {
		return;
	}
	memset(commenttok, '\0', sizeof(commenttok));
	strncpy(commenttok, "#", 1);
	strncat(commenttok, tok, strlen(tok));
	commenttok[strlen(tok) + 1] = '\0';

	/* Copy the commented token back to token */
	memset(tok, '\0', MAX_TOK_SIZE);
	strncpy(tok, commenttok, strlen(commenttok));
	return;
}

/* This function removes a '#' from the
 * token. Used in enabling back a commented 
 * line in the configuration file */
int handle_commented_tokens(char *token)
{
	if ((token[0] == '#') && isalpha(token[1])) {
		/* remove the '#' character from token */
		LTQ_STRNCPY(token, &token[1], (strlen(token) - 1));
		token[strlen(token) - 1] = '\0';
		return SUCCESS;
	}
	return FAIL;

}

int IFX_adsl_ioctl(int fd, int cmd, void *structptr)
{
	//return (adsl_ioctl(fd, cmd, structptr));
	return (ioctl(fd, cmd, structptr));
}

int IFX_dev_open(const char *pathname, int flags)
{
	//return (dev_open(pathname, flags));
	return (open(pathname, flags));
}

int IFX_dev_close(int fd)
{
	//return (dev_close(fd));
	return (close(fd));
}

/*
 * ===========================================================================
 *                           EXPORTED FUNCTIONS
 * ===========================================================================
 */

bool IFX_SNMPd_Get_Conf_From_RcConf(char **ro_community, char **rw_community,
				    char **trap_host_ip, uint32 flags)
{
	int32 iRtn = IFX_SUCCESS;
	char8 sVal[MAX_TOKVAL_SIZE];
	uint32 ulOutFlag;

	memset(sVal, 0x00, sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, TAG_SNMP_AGENT,
				   "SNMProcommunity", flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get SNMProcommunity !!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_TOKVAL_SIZE) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> SNMProcommunity len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	strcpy(*ro_community, sVal);

	memset(sVal, 0x00, sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, TAG_SNMP_AGENT,
				   "SNMPrwcommunity", flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get SNMPrwcommunity!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_TOKVAL_SIZE) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> SNMPrwcommunity len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	strcpy(*rw_community, sVal);

	memset(sVal, 0x00, sizeof(sVal));
	if ((iRtn = ifx_GetObjData(FILE_RC_CONF, TAG_SNMP_AGENT,
				   "SNMPTrapIP", flags, &ulOutFlag,
				   sVal)) != IFX_SUCCESS) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get SNMPTrapIp!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	if ((strlen(sVal) + 1) > MAX_TOKVAL_SIZE) {
		iRtn = IFX_FAILURE;
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> SNMPTrapIp len not fitting in buffer!!\n\n",
		     __FUNCTION__);
		goto IFX_Handler;
	}
	strcpy(*trap_host_ip, sVal);

      IFX_Handler:
	return (iRtn);
}

/* This function is an exported API function which gets the basic configuration.
 * The Caller of this API function provides the necessary buffer place-holders
 * to return the configuration values from the Configuration file */
bool IFX_SNMPd_Get_Conf(char *ro_community, char *rw_community,
			bool * trap_enable, char *trap_host_ip,
			unsigned long *trap_port, char *trap_community)
{
	char line[MAX_LINE_LEN], tok[MAX_TOK_SIZE], tokval[MAX_TOKVAL_SIZE];
	char *dup_line = NULL;
	FILE *fptr;
	int inttok;

	fptr = fopen(SNMPD_CONF_FILE, "r");
	if (fptr == NULL) {
		printf("Unable to open config file - %s", SNMPD_CONF_FILE);
		return FALSE;
	}

	/* Initialize the request variables to NULL */
	memset(ro_community, '\0', MAX_TOKVAL_SIZE);
	memset(rw_community, '\0', MAX_TOKVAL_SIZE);
	memset(trap_host_ip, '\0', MAX_TOKVAL_SIZE);
	memset(trap_community, '\0', MAX_TOKVAL_SIZE);
	*trap_enable = 0;
	*trap_port = 0;

	while (!feof(fptr)) {
		get_line(fptr, line);
		if (!is_blank_line(line))
			dup_line = strdup(line);
		else
			continue;

		if (tokenize_line(line, tok, tokval) == SUCCESS) {
			map_chartok_to_inttok(tok, &inttok);

			switch (inttok) {

			case TOK_ROCOMMUNITY:
				strcpy(ro_community, tokval);
				break;

			case TOK_RWCOMMUNITY:
				strcpy(rw_community, tokval);
				break;

			case TOK_TRAPSINK:
			case TOK_TRAPSINK2:
				*trap_enable = 1;
				tokenize_trapsink_line(dup_line, tok,
						       trap_host_ip,
						       trap_community,
						       trap_port);
				break;

			case TOK_ROUSER:
			case TOK_RWUSER:
			case TOK_AUTHTRAPENABLE:
			case TOK_AGENTADDRESS:
			case TOK_SYSNAME:
			case TOK_SYSLOCATION:
			case TOK_SYSCONTACT:
				/* These values are read directly from persistent store
				 * by using ifx_GetCfgData()*/
				break;

			default:
				break;

			}
		}
		/* Could be a marker line/Commnet/Unrecognizzed token lines - 
		 * don't do anything. Skip this line and proceed to next line 
		 */
		if (dup_line != NULL)
			free(dup_line);
	}

	fclose(fptr);
	return TRUE;
}

/* This function is an exported API function which sets the basic configuration.
 * The Caller of this API function provides the necessary data to be set in buffers.
 * For those variables for which no value needs to be Set are passed with NULL. This
 * information is translated by this API and written to the Configuration file */
#if Subbi
bool IFX_SNMPd_Set_Conf(char *ro_community, char *rw_community,
			bool * trap_enable, char *trap_host_ip,
			unsigned long *trap_port, char *trap_community)
#else
bool IFX_SNMPd_Set_Conf(snmp_config_data * snmpdataSet)
#endif
{

	char line[MAX_LINE_LEN], newline[MAX_LINE_LEN], tok[MAX_TOK_SIZE],
	    tokval[MAX_TOKVAL_SIZE];
	char traphost[MAX_TOKVAL_SIZE], trapcomm[MAX_TOKVAL_SIZE];
	unsigned long trapport;
	char str_trapport[sizeof(unsigned long)];
	char *dup_line = NULL;
	FILE *fptr, *tmp_fptr;
	int inttok, snmpPID;

	char *ro_community, *rw_community, *trap_host_ip, *trap_community;
	char *SysName, *SysLocation, *SysContact;
	unsigned long trap_port, UDPPort, PVCVpi, PVCVci, EOCVpi, EOCVci;
	bool trap_enable, bUDPEnable, bPVCEnable, bEOCEnable;

	char udp_str[MAX_TOKVAL_SIZE], pvc_str[MAX_TOKVAL_SIZE],
	    eoc_str[MAX_TOKVAL_SIZE];
	char tp_str[MAX_LINE_LEN], agentaddress[MAX_TOKVAL_SIZE];
	bool bagentaddress_change = 0;

#ifdef PRINT_DEBUG
	printf("STRUCTURE DATA:\n bSNMPEnable:%d, sSysName:%s, sSysLocation:%s, sSysContact:%s, sSNMProcommunity:%s \
						sSNMPrwcommunity:%s, bTrapEnable:%d, sSNMPTrapIP:%s, TrapPort:%ld, sSNMPTrapCommunity:%s, \
						bUDPEnable:%d, UDPPort:%ld, bPVCEnable:%d, PVCVpi:%ld, PVCVci:%ld,  bEOCEnable:%d, EOCVpi:%ld \
						EOCVci:%ld",
	       snmpdataSet->bSNMPEnable, snmpdataSet->sSysName, snmpdataSet->sSysLocation, snmpdataSet->sSysContact, snmpdataSet->sSNMProcommunity, snmpdataSet->sSNMPrwcommunity, snmpdataSet->bTrapEnable, snmpdataSet->sSNMPTrapIP, snmpdataSet->TrapPort, snmpdataSet->sSNMPTrapCommunity, snmpdataSet->bUDPEnable, snmpdataSet->UDPPort,
	       snmpdataSet->bPVCEnable, snmpdataSet->PVCVpi, snmpdataSet->PVCVci, snmpdataSet->bEOCEnable, snmpdataSet->EOCVpi, snmpdataSet->EOCVci);
#endif

	fptr = fopen(SNMPD_CONF_FILE, "r");
	if (fptr == NULL) {
		printf("Unable to open config file - %s", SNMPD_CONF_FILE);
		return FALSE;
	}
	memset(udp_str, 0x00, sizeof(udp_str));
	memset(pvc_str, 0x00, sizeof(pvc_str));
	memset(eoc_str, 0x00, sizeof(eoc_str));
	memset(tp_str, 0x00, sizeof(tp_str));
	memset(agentaddress, 0x00, sizeof(agentaddress));

	/* Copy the data from structure to the above variables */
	SysName = snmpdataSet->sSysName;
	SysLocation = snmpdataSet->sSysLocation;
	SysContact = snmpdataSet->sSysContact;
	ro_community = snmpdataSet->sSNMProcommunity;
	rw_community = snmpdataSet->sSNMPrwcommunity;
	trap_enable = snmpdataSet->bTrapEnable;
	trap_host_ip = snmpdataSet->sSNMPTrapIP;
	trap_port = snmpdataSet->TrapPort;
	trap_community = snmpdataSet->sSNMPTrapCommunity;

	bUDPEnable = snmpdataSet->bUDPEnable;
	UDPPort = snmpdataSet->UDPPort;
	bPVCEnable = snmpdataSet->bPVCEnable;
	PVCVpi = snmpdataSet->PVCVpi;
	PVCVci = snmpdataSet->PVCVci;
	bEOCEnable = snmpdataSet->bEOCEnable;
	EOCVpi = snmpdataSet->EOCVpi;
	EOCVci = snmpdataSet->EOCVci;

	/* Open a temporary config file */
	tmp_fptr = fopen(TMP_CONF_FILE, "w");
	if (tmp_fptr == NULL) {
		printf("Unable to open config file - %s", TMP_CONF_FILE);
		fclose(fptr);
		return FALSE;
	}

	while (!feof(fptr)) {
		get_line(fptr, line);
		if (!is_blank_line(line))
			dup_line = strdup(line);
		else {
			// fputs(line, tmp_fptr);
			continue;
		}

		if (tokenize_line(line, tok, tokval) == SUCCESS) {
		      swtlbl:
			map_chartok_to_inttok(tok, &inttok);
			switch (inttok) {

			case TOK_ROCOMMUNITY:
				memset(tokval, '\0', sizeof(tokval));
				memset(newline, '\0', sizeof(newline));
				if (ro_community != NULL) {
					strcpy(tokval, ro_community);
				} else {
					//     comment the token 
					comment_token(tok);
				}
				/* Now form the line and write it to the Temp file */
				sprintf(newline, "%s\t%s\n", tok, tokval);
				fputs(newline, tmp_fptr);
				break;

			case TOK_RWCOMMUNITY:
				memset(tokval, '\0', sizeof(tokval));
				memset(newline, '\0', sizeof(newline));
				if (rw_community != NULL) {
					strcpy(tokval, rw_community);
				} else {
					/* comment the token */
					comment_token(tok);
				}
				/* Now form the line and write it to the Temp file */
				sprintf(newline, "%s\t%s\n", tok, tokval);
				fputs(newline, tmp_fptr);
				break;

			case TOK_TRAPSINK:
			case TOK_TRAPSINK2:
				memset(newline, '\0', sizeof(newline));
				if (trap_enable == 1) {
					if (trap_host_ip != NULL) {
						tokenize_trapsink_line(dup_line,
								       tok,
								       traphost,
								       trapcomm,
								       &trapport);
						if (tok[0] == '#')
							handle_commented_tokens
							    (tok);

						memset(traphost, '\0',
						       sizeof(traphost));
						strncpy(traphost, trap_host_ip,
							strlen(trap_host_ip));
						if (trap_community != NULL) {
							memset(trapcomm, '\0',
							       sizeof
							       (trapcomm));
							strncpy(trapcomm,
								trap_community,
								strlen
								(trap_community));
						} else
							memset(trapcomm, '\0',
							       sizeof
							       (trapcomm));

						if (trap_port != 0) {
							trapport = trap_port;
						} else
							trapport = 0;
					} else {
						printf
						    ("Trap Host not configured!\n\r Traps will be disabled!\n\r");
						/* If previous information on trap configuration is
						 * required then we handle it seperately. Here all previous
						 * trap information is destroyed
						 */
						tokenize_trapsink_line(dup_line,
								       tok,
								       traphost,
								       trapcomm,
								       &trapport);
						if (tok[0] == '#')
							handle_commented_tokens
							    (tok);

						comment_token(tok);
					}
				} else {
					/* If previous information on trap configuration is
					 * required then we handle it here. Here all previous
					 * trap information is maintained
					 */
					tokenize_trapsink_line(dup_line, tok,
							       traphost,
							       trapcomm,
							       &trapport);

					/* May be trap is previously disabled and again we
					 * try to disable it from Set Conf! Handle it here.
					 */
					if (tok[0] == '#')
						handle_commented_tokens(tok);

					comment_token(tok);
				}
				/* Now form the line and write it to the Temp file */
				memset(str_trapport, '\0',
				       sizeof(str_trapport));
				snprintf(str_trapport, sizeof(str_trapport),
					 "%lu", trapport);
				snprintf(newline, sizeof(newline),
					 "%s %s %s %s\n", tok, traphost,
					 trapcomm,
					 trapport ? str_trapport : "");
				fputs(newline, tmp_fptr);
				printf("Value of new Trapsink: %s\n\r",
				       newline);
				break;

			case TOK_ROUSER:
			case TOK_RWUSER:
			case TOK_AUTHTRAPENABLE:
				/* Write this line as is and proceed to next line */
				if (dup_line != NULL)
					fputs(dup_line, tmp_fptr);
				break;

			case TOK_AGENTADDRESS:
				/* This would require parsing the agentaddress string
				 * agentaddress udp:161,pvc:0.16,eoc:100.0.100 */
				bagentaddress_change = 0;
				if (tokval == NULL)
					break;
				snprintf(agentaddress, sizeof(agentaddress),
					 "%s\n", tokval);
				printf("AgentAddress is:(%s:strlen[%d])\n",
				       tokval, strlen(tokval));

				memset(tokval, '\0', sizeof(tokval));
				memset(newline, '\0', sizeof(newline));
				if (bUDPEnable) {
					sprintf(udp_str, "%s:%ld", "udp",
						UDPPort);
					sprintf(tp_str, "%s\n", udp_str);
				}
				if (bPVCEnable) {
					memset(tp_str, '\0', sizeof(tp_str));
					sprintf(pvc_str, "%s:%ld.%ld", "pvc",
						PVCVpi, PVCVci);
					sprintf(tp_str, "%s\n", pvc_str);
					if (bUDPEnable) {
						memset(tp_str, '\0',
						       sizeof(tp_str));
						sprintf(tp_str, "%s,%s\n",
							udp_str, pvc_str);
					}
				}
				if (bEOCEnable) {
					memset(tp_str, '\0', sizeof(tp_str));
					sprintf(eoc_str, "%s:100.%ld.%ld",
						"eoc", EOCVpi, EOCVci);
					if (bUDPEnable) {
						if (bPVCEnable)
							sprintf(tp_str,
								"%s,%s,%s\n",
								udp_str,
								pvc_str,
								eoc_str);
						else
							sprintf(tp_str,
								"%s,%s\n",
								udp_str,
								eoc_str);
					} else if (bPVCEnable)
						sprintf(tp_str, "%s,%s\n",
							pvc_str, eoc_str);
					else
						sprintf(tp_str, "%s\n",
							eoc_str);
				}

				/* When none of the transports are enabled
				 * it implies default UDP transport port 161
				 */
				if ((!bUDPEnable) && (!bPVCEnable)
				    && (!bEOCEnable)) {
					/* set the tok val to udp:161 */
					sprintf(tokval, "%s\n", "udp:161");

					/* There could be a change in agentaddress
					 * Set the agentaddress_change flag to indicate 
					 * the same */
					bagentaddress_change = 1;
					//comment_token(tok);
				} else {
					strcpy(tokval, tp_str);
				}
				/* Now form the line and write it to the Temp file */
				sprintf(newline, "%s\t%s\n", tok, tokval);
				printf("Tok val is:(%s:strlen[%d])\n", tokval,
				       strlen(tokval));
				if (strcmp(tokval, agentaddress))
					bagentaddress_change = 1;
				else
					/* If the transports are same 
					 * No need to restart SNMPD */
					bagentaddress_change = 0;
				fputs(newline, tmp_fptr);

				break;

			case TOK_SYSNAME:
				memset(tokval, '\0', sizeof(tokval));
				memset(newline, '\0', sizeof(newline));
				if (SysName != NULL) {
					strcpy(tokval, SysName);
				} else {
					/* comment the token */
					comment_token(tok);
				}
				/* Now form the line and write it to the Temp file */
				sprintf(newline, "%s\t%s\n", tok, tokval);
				fputs(newline, tmp_fptr);
				break;

			case TOK_SYSLOCATION:
				memset(tokval, '\0', sizeof(tokval));
				memset(newline, '\0', sizeof(newline));
				if (SysLocation != NULL) {
					strcpy(tokval, SysLocation);
				} else {
					/* comment the token */
					comment_token(tok);
				}
				/* Now form the line and write it to the Temp file */
				sprintf(newline, "%s\t%s\n", tok, tokval);
				fputs(newline, tmp_fptr);
				break;

			case TOK_SYSCONTACT:
				memset(tokval, '\0', sizeof(tokval));
				memset(newline, '\0', sizeof(newline));
				if (SysContact != NULL) {
					strcpy(tokval, SysContact);
				} else {
					/* comment the token */
					comment_token(tok);
				}
				/* Now form the line and write it to the Temp file */
				sprintf(newline, "%s\t%s\n", tok, tokval);
				fputs(newline, tmp_fptr);
				break;

			default:
				if (handle_commented_tokens(tok) == SUCCESS)
					goto swtlbl;
				break;
			}
		} else {
			/* Could be a marker line - don't do anything 
			 * Write this line as is and proceed to next line 
			 */
			if (dup_line != NULL)
				fputs(dup_line, tmp_fptr);
		}
		if (dup_line != NULL)
			free(dup_line);
	}
	fclose(fptr);
	fclose(tmp_fptr);

	/* Remove the config file and rename the temp config file */
	remove(SNMPD_CONF_FILE);
	rename(TMP_CONF_FILE, SNMPD_CONF_FILE);

	/* Send a SIGHUP signal to snmpprocess to re-read the new conf */
	snmpPID = ifx_get_process_pid(SNMP_PID_FILE_PREFIX);

	//Sumedh--ensure that SIGHUP is not sent to pid 0 (process group)
	//if ((snmpPID > 0) && (bagentaddress_change)) {
	if ((snmpPID > 0)) {
		if (bagentaddress_change) {
			/* We must restart the agent in order to initialize
			 * the new transports */
			kill(snmpPID, SIGTERM);
			sleep(3);
			IFX_SNMPd_Set_Enable(1);
			sleep(2);
		} else {
			kill(snmpPID, SIGHUP);
		}
	}
	return TRUE;
}

/*This function would be required to modify the MIB2 system data in the
 * snmpd.conf file whenever the MIB2 System data is modified thru' SNMP
 * Agent via snmpset command */
bool IFX_Set_MIB2_System_Conf(char *SysName, char *SysContact,
			      char *SysLocation)
{
	FILE *fptr, *tmp_fptr;
	char line[MAX_LINE_LEN], newline[MAX_LINE_LEN], tok[MAX_TOK_SIZE],
	    tokval[MAX_TOKVAL_SIZE];
	int inttok, snmpPID;
	char *dup_line = NULL;

	fptr = fopen(SNMPD_CONF_FILE, "r");
	if (fptr == NULL) {
		printf("Unable to open config file - %s", SNMPD_CONF_FILE);
		return FALSE;
	}

	/* Open a temporary config file */
	tmp_fptr = fopen(TMP_CONF_FILE, "w");
	if (tmp_fptr == NULL) {
		printf("Unable to open config file - %s", TMP_CONF_FILE);
		fclose(fptr);
		return FALSE;
	}

	while (!feof(fptr)) {
		get_line(fptr, line);
		if (!is_blank_line(line))
			dup_line = strdup(line);
		else
			continue;

		if (tokenize_line(line, tok, tokval) == SUCCESS) {
			map_chartok_to_inttok(tok, &inttok);
			switch (inttok) {
			case TOK_SYSNAME:
				memset(tokval, '\0', sizeof(tokval));
				memset(newline, '\0', sizeof(newline));
				if (SysName != NULL) {
					strcpy(tokval, SysName);
				}
				sprintf(newline, "%s\t%s\n", tok, tokval);
				fputs(newline, tmp_fptr);
				break;

			case TOK_SYSLOCATION:
				memset(tokval, '\0', sizeof(tokval));
				memset(newline, '\0', sizeof(newline));
				if (SysLocation != NULL) {
					strcpy(tokval, SysLocation);
				}
				sprintf(newline, "%s\t%s\n", tok, tokval);
				fputs(newline, tmp_fptr);
				break;

			case TOK_SYSCONTACT:
				memset(tokval, '\0', sizeof(tokval));
				memset(newline, '\0', sizeof(newline));
				if (SysContact != NULL) {
					strcpy(tokval, SysContact);
				}
				sprintf(newline, "%s\t%s\n", tok, tokval);
				fputs(newline, tmp_fptr);
				break;

			default:
				if (dup_line != NULL)
					fputs(dup_line, tmp_fptr);
				break;
			}
		} else {
			/* Could be a marker line - don't do anything
			 * Write this line as is and proceed to next line
			 */
			if (dup_line != NULL)
				fputs(dup_line, tmp_fptr);
		}
		if (dup_line != NULL)
			free(dup_line);
	}
	fclose(fptr);
	fclose(tmp_fptr);

	/* Remove the config file and rename the temp config file */
	remove(SNMPD_CONF_FILE);
	rename(TMP_CONF_FILE, SNMPD_CONF_FILE);

	/* Send a SIGHUP signal to snmpprocess to re-read the new conf */
	snmpPID = ifx_get_process_pid(SNMP_PID_FILE_PREFIX);
	if (snmpPID > 0)
		kill(snmpPID, SIGHUP);
	return TRUE;
}

/* This function moves the fptr to the marker position and
 * returns the file offset to the marker position */
long move_fptr_to_marker(FILE * fptr, char *marker)
{
	char buf[MAX_LINE_LEN];
	while (!feof(fptr)) {
		get_line(fptr, buf);
		if (is_blank_line(buf))
			continue;
		if (strncmp(buf, marker, strlen(marker)) == 0) {
			return ftell(fptr);
		}
	}

	if (feof(fptr))
		fseek(fptr, 1L, SEEK_END);
	return ftell(fptr);

}

/* This function copies bytes from the start of the file upto the given 
 * offset. To ensure the given functionality the from_fptr is set to the
 * begining of the file */
void copy_bytes_upto_file_offset(FILE * from_fptr, FILE * to_fptr, long offset)
{
	char buf[MAX_LINE_LEN];
	long curr_offset = 0L;
	fseek(from_fptr, curr_offset, SEEK_SET);
	while (!feof(from_fptr) && curr_offset <= offset) {
		memset(buf, '\0', sizeof(buf));
		fgets(buf, sizeof(buf), from_fptr);
		if ((curr_offset + strlen(buf)) > offset)
			return;
		fputs(buf, to_fptr);
		curr_offset = ftell(from_fptr);
	}
	return;
}

/* This function copies bytes from the given offset to the end of file. 
 * To ensure the given functionality the from_fptr is set to the
 * given offset in the file */
void copy_bytes_from_file_offset(FILE * from_fptr, FILE * to_fptr, long offset)
{
	char buf[MAX_LINE_LEN];
	fseek(from_fptr, offset, SEEK_SET);
	while (!feof(from_fptr)) {
		memset(buf, '\0', sizeof(buf));
		fgets(buf, sizeof(buf), from_fptr);
		fputs(buf, to_fptr);
	}
	return;
}

#ifdef CONFIG_FEATURE_SNMPV3
/* This function reads the SNMPv3 users from persistent store 
 * and creates the SNMPV3_USM_CMD_FILE which contains the list
 * of SNMPv3 users configured on the device
 * It also flushes all the SNMPv3 users in snmpd.conf 
 * file and creates them a fresh!!  
 */
bool IFX_create_usm_cmd_file_on_startup()
{
	FILE *usm_ptr = NULL;
	FILE *fptr = NULL, *tmp_fptr = NULL;
	long offset = 0;
	int i = 0, nSNMPv3UserDB_Size = 0;
	char sSNMPv3UserDB_Size[MAX_DATA_LEN];
	char buf[MAX_LINE_LEN], user[20], user_access[10], tmp_SecLevel[10];
	char tmp_authProto[5], tmp_authPassPhrase[20];
	char tmp_encrProto[5], tmp_encrPassPhrase[20];

	usm_ptr = fopen(SNMPV3_USM_CMD_FILE, "w");
	if (usm_ptr == NULL) {
		printf("Unable to open USM command file - %s",
		       SNMPV3_USM_CMD_FILE);
		return FALSE;
	}

	memset(sSNMPv3UserDB_Size, 0x00, sizeof(sSNMPv3UserDB_Size));
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_SNMPv3_USERDB, "SNMPv3User_Count",
			   sSNMPv3UserDB_Size) == 0) {
		printf("Unable to get snmpv3 users count\n");
		fclose(usm_ptr);
		return FALSE;
	}

	/* Open the snmpd.conf file and start adding
	 * the users to it under V3 marker */
	fptr = fopen(SNMPD_CONF_FILE, "r");
	if (fptr == NULL) {
		printf("Unable to open config file - %s", SNMPD_CONF_FILE);
		fclose(usm_ptr);
		return FALSE;
	}

	tmp_fptr = fopen(TMP_CONF_FILE, "w");
	if (tmp_fptr == NULL) {
		printf("Unable to open config file - %s", TMP_CONF_FILE);
		fclose(usm_ptr);
		fclose(fptr);
		return FALSE;
	}

	/* Move the file ptr to the marker and get the offset to the marker */
	offset = move_fptr_to_marker(fptr, v3_marker);
	copy_bytes_upto_file_offset(fptr, tmp_fptr, offset);
	fseek(fptr, offset, SEEK_SET);

	nSNMPv3UserDB_Size = atoi(sSNMPv3UserDB_Size);
	for (i = 0; i < nSNMPv3UserDB_Size && i < SNMPv3_USERS_NUM; i++) {

		memset(user, 0x00, sizeof(user));
		memset(user_access, 0x00, sizeof(user_access));
		memset(tmp_SecLevel, 0x00, sizeof(tmp_SecLevel));
		memset(tmp_authProto, 0x00, sizeof(tmp_authProto));
		memset(tmp_authPassPhrase, 0x00, sizeof(tmp_authPassPhrase));
		memset(tmp_encrProto, 0x00, sizeof(tmp_encrProto));
		memset(tmp_encrPassPhrase, 0x00, sizeof(tmp_encrPassPhrase));

		memset(buf, 0x00, sizeof(buf));
		sprintf(buf, "%s%s%d", PREFIX_SNMPv3_USER, "UserName", i);
		ifx_GetCfgData(FILE_RC_CONF, TAG_SNMPv3_USERDB, buf, user);

		memset(buf, 0x00, sizeof(buf));
		sprintf(buf, "%s%s%d", PREFIX_SNMPv3_USER, "UserAccess", i);
		ifx_GetCfgData(FILE_RC_CONF, TAG_SNMPv3_USERDB, buf,
			       user_access);

		memset(buf, 0x00, sizeof(buf));
		sprintf(buf, "%s%s%d", PREFIX_SNMPv3_USER, "SecLevel", i);
		ifx_GetCfgData(FILE_RC_CONF, TAG_SNMPv3_USERDB, buf,
			       tmp_SecLevel);

		memset(buf, 0x00, sizeof(buf));
		sprintf(buf, "%s%s%d", PREFIX_SNMPv3_USER, "AuthProto", i);
		ifx_GetCfgData(FILE_RC_CONF, TAG_SNMPv3_USERDB, buf,
			       tmp_authProto);

		memset(buf, 0x00, sizeof(buf));
		sprintf(buf, "%s%s%d", PREFIX_SNMPv3_USER, "AuthPasswd", i);
		ifx_GetCfgData(FILE_RC_CONF, TAG_SNMPv3_USERDB, buf,
			       tmp_authPassPhrase);

		memset(buf, 0x00, sizeof(buf));
		sprintf(buf, "%s%s%d", PREFIX_SNMPv3_USER, "PrivProto", i);
		ifx_GetCfgData(FILE_RC_CONF, TAG_SNMPv3_USERDB, buf,
			       tmp_encrProto);

		memset(buf, 0x00, sizeof(buf));
		sprintf(buf, "%s%s%d", PREFIX_SNMPv3_USER, "PrivPasswd", i);
		ifx_GetCfgData(FILE_RC_CONF, TAG_SNMPv3_USERDB, buf,
			       tmp_encrPassPhrase);

		fprintf(usm_ptr, "%s %s %s %s %s %s %s\n",
			SNMPV3_USM_CREATE_USER, user, user_access,
			tmp_authProto, tmp_authPassPhrase, tmp_encrProto,
			tmp_encrPassPhrase);

		fprintf(tmp_fptr, "%s\t%s %s\n", user_access, user,
			tmp_SecLevel);
	}

	fclose(usm_ptr);
	fclose(fptr);
	fclose(tmp_fptr);

	/* Remove the snmpd.conf file and rename temp config file to snmpd.conf */
	remove(SNMPD_CONF_FILE);
	rename(TMP_CONF_FILE, SNMPD_CONF_FILE);
	return TRUE;
}

/* This function checks for the existence of the given user in
 * the V3 configuration and if found returns the file offset where
 * this user exists. If not found the offset returned is 0 */
int find_snmpv3_user(FILE * fileptr, char *user, long *found_offset)
{
	char line[MAX_LINE_LEN], *dup_line = NULL;
	char *tok, *tokval;

	while (!feof(fileptr)) {
		get_line(fileptr, line);
		if (is_blank_line(line))
			continue;
		dup_line = strdup(line);
		tok = strtok(dup_line, delimiters);
		if (tok != NULL) {
			tokval = strtok(NULL, delimiters);
			if (strcmp(tokval, user) == 0) {
				printf("User (%s) found!\n", user);
				*found_offset = ftell(fileptr);
				return TRUE;
			}
		}
	}
	*found_offset = 0L;
	return FALSE;
}

/* This function validates the Authentication Protocol and checks
 * for any NULL pointers passed from the Caller program and also
 * validates that the Password string must be atleast 8 characters 
 * in length. Also if any buffers are passed for Authentication, 
 * instead of pointers these buffers must be initialized by the 
 * Caller program to '\0'otherwise Authentication fails! */
bool validate_authentication(char *authProto, char *authPassPhrase)
{
	/* AuthPassPhrase but no AuthProto */
	if ((authProto == NULL) && (authPassPhrase != NULL)
	    && (authPassPhrase[0] != '\0')) {
		printf("NULL Authentication Protocol\n");
		return FALSE;
	} else if (((authProto != NULL) && (authProto[0] == '\0'))
		   && ((authPassPhrase != NULL) && (authPassPhrase[0] != '\0'))) {
		printf("NULL Auth Protocol but non-NULL AuthPassPhrase\n");
		return 0;
	}
	/* AuthProto other than MD5|SHA */
	else if ((authProto != NULL) && (authProto[0] != '\0')
		 && (strcmp(authProto, "MD5"))
		 && (strcmp(authProto, "SHA"))) {
		printf("Invalid Authentication Protocol\n");
		return FALSE;
	}
	/* AuthProto but no AuthPassPhrase */
	else if ((authPassPhrase == NULL) && (authProto != NULL)
		 && (authProto[0] != '\0')) {

		printf("NULL Authentication Password\n");
		return FALSE;
	} else if (((authPassPhrase != NULL) && (authPassPhrase[0] == '\0'))
		   && ((authProto != NULL) && (authProto[0] != '\0'))) {
		printf
		    ("Auth Protocol is non-NULL - Need an Authentication Password\n");
		return 0;
	}
	/* Authentication Password too small < 8 */
	else if ((authPassPhrase != NULL) && (authPassPhrase[0] != '\0')
		 && (authProto[0] != '\0')
		 && (strlen(authPassPhrase) < 8)) {
		printf("Password must be atleast 8 characters\n");
		return FALSE;
	} else
		/* Valid Authentication */
		return TRUE;

}

/* This function is used to validate the Encryption process. For this
 * process the authentication must first be verified and only then we 
 * can have encryption. The encryption can be NULL if no encryption 
 * protocol is specified. If no encryption password is specified, then
 * it'll assume the password of Authentication. Also if any buffers are 
 * passed for Encryption, instead of pointers these buffers must be 
 * initialized by the Caller program to '\0'otherwise Encryption fails! */
bool validate_encryption(char *authProto, char *authPassPhrase,
			 char *encrProto, char *encrPassPhrase)
{

	if (validate_authentication(authProto, authPassPhrase)) {

		/* EncrPassPhrase but no EncrProto */
		if ((encrProto == NULL) && (encrPassPhrase != NULL)
		    && (encrPassPhrase[0] != '\0')) {
			printf("NULL Encryption Protocol\n");
			return FALSE;
		} else if (((encrProto != NULL) && (encrProto[0] == '\0'))
			   && ((encrPassPhrase != NULL)
			       && (encrPassPhrase[0] != '\0'))) {
			printf
			    ("NULL Encr Protocol but non-NULL EncrPassPhrase\n");
			return 0;
		}
		/* EncrProto other than DES|AES */
		else if ((encrProto != NULL) && (encrProto[0] != '\0')
			 && (strcmp(encrProto, "DES"))
			 && (strcmp(encrProto, "AES"))) {
			printf("Invalid Encryption Protocol\n");
			return FALSE;
		}
		/* Encryption Password too small < 8 */
		else if ((encrPassPhrase != NULL) && (encrPassPhrase[0] != '\0')
			 && (encrProto[0] != '\0')
			 && (strlen(encrPassPhrase) < 8)) {
			printf("Password must be atleast 8 characters\n");
			return FALSE;
		}
		/* NoAuth and NoPrivacy condition */
		else if (((authProto == NULL)
			  || ((authProto != NULL) && (authProto[0] == '\0')))
			 && (encrProto != NULL) && (encrProto[0] != '\0')) {
			printf
			    ("NULL Authentication - No Encryption without Authentication\n");
			return FALSE;
		} else
			/* Valid Encryption 
			 * - NULL Encryption
			 * - NULL EncrPassPhrase in which case
			 * it'll use the AuthPassPhrase
			 */
			return TRUE;
	}
	return FALSE;
}

/* This function is an exported API function which adds 
 * an SNMPv3 user to the configuration file and also to
 * the UserList in snmpd. Since the communication is between
 * two processes, we cannot directly inform the snmp daemon to
 * add the user. For this we write the required information into
 * a specifc file and send a HUP signal to snmpd to re-read the 
 * configuration file. While reading the configuration file we
 * also read this data file and the user is addedd to the 
 * usmUserList in snmpd and persistence store updated. */
bool IFX_add_snmpv3_user(char *user, char *user_access,
			 char *authProto, char *authPassPhrase,
			 char *encrProto, char *encrPassPhrase)
{
	FILE *fptr, *tmp_fptr, *usm_fptr;
	long offset = 0L, user_offset = 0L;
	char secLevel[10];
	char tmp_authProto[5], tmp_authPassPhrase[30], tmp_encrProto[5],
	    tmp_encrPassPhrase[30];
	int auth_flag = 0, encr_flag = 0;
	int snmpPID;

	memset(tmp_authProto, '\0', sizeof(tmp_authProto));
	memset(tmp_authPassPhrase, '\0', sizeof(tmp_authPassPhrase));
	memset(tmp_encrProto, '\0', sizeof(tmp_encrProto));
	memset(tmp_encrPassPhrase, '\0', sizeof(tmp_encrPassPhrase));

	fptr = fopen(SNMPD_CONF_FILE, "r");
	if (fptr == NULL) {
		printf("Unable to open config file - %s", SNMPD_CONF_FILE);
		return FALSE;
	}

	/* Open a temporary config file */
	tmp_fptr = fopen(TMP_CONF_FILE, "w");
	if (tmp_fptr == NULL) {
		printf("Unable to open config file - %s", TMP_CONF_FILE);
		return FALSE;
	}

	if ((user == NULL) || ((user != NULL) && (user[0] == '\0'))) {
		printf("No specific user to add!\n");
		goto lbl_exit;
	}

	/* Move the file ptr to the marker and get the offset to the marker */
	offset = move_fptr_to_marker(fptr, v3_marker);

	/* Check if the user already exists in the config file */
	if (find_snmpv3_user(fptr, user, &user_offset) != TRUE) {

		/* createUser username rouser|rwuser MD5|SHA AuthPasswd DES|AES... AESPasswd */
		if (strcmp(user_access, SNMP_ROUSER_STR)
		    && strcmp(user_access, SNMP_RWUSER_STR)) {
			printf("Invalid User Access\n");
			goto lbl_exit;
		}

		if (validate_authentication(authProto, authPassPhrase) != TRUE) {
			goto lbl_exit;
		} else {
			if (((authProto != NULL) && (authProto[0] == '\0'))
			    || (authProto == NULL)) {
				/* NULL Authentication */
				auth_flag = 0;
			} else
				auth_flag = 1;
		}

		if (validate_encryption
		    (authProto, authPassPhrase, encrProto,
		     encrPassPhrase) != TRUE) {
			goto lbl_exit;
		} else {
			if (((encrProto != NULL) && (encrProto[0] == '\0'))
			    || (encrProto == NULL)) {
				/* NULL Encryption */
				encr_flag = 0;
			} else
				encr_flag = 1;
		}

		memset(secLevel, '\0', sizeof(secLevel));
		if ((auth_flag) && (encr_flag)) {
			strncpy(secLevel, "priv", 4);
			secLevel[4] = '\0';
		} else if ((!auth_flag) && (!encr_flag)) {
			strncpy(secLevel, "noauth", 6);
			secLevel[6] = '\0';
		} else {
			/* Security level is set to default (" ") - AUTH 
			 * No handling is required as it's already set
			 * above to NULL
			 */
			strncpy(secLevel, "auth", 4);
			secLevel[4] = '\0';
		}

		copy_bytes_upto_file_offset(fptr, tmp_fptr, offset);
		fprintf(tmp_fptr, "\n");

		fprintf(tmp_fptr, "%s\t%s %s\n", user_access, user, secLevel);

		/* Copy the rest of the config lines into the TMP_CONF_FILE */
		copy_bytes_from_file_offset(fptr, tmp_fptr, offset);
	} else {
		printf("User already Exists!!\n");

	      lbl_exit:
		fclose(fptr);
		fclose(tmp_fptr);
		remove(TMP_CONF_FILE);
		return FALSE;
	}

	/* Write the data into the SNMPV3_USM_CMD_FILE */
	usm_fptr = fopen(SNMPV3_USM_CMD_FILE, "w");
	if (usm_fptr == NULL) {
		printf("Unable to open USM command file - %s",
		       SNMPV3_USM_CMD_FILE);
		goto lbl_exit;
	}

	if ((authProto != NULL) && (authProto[0] != '\0'))
		strncpy(tmp_authProto, authProto, strlen(authProto));
	if ((authPassPhrase != NULL) && (authPassPhrase[0] != '\0'))
		strncpy(tmp_authPassPhrase, authPassPhrase,
			strlen(authPassPhrase));
	if ((encrProto != NULL) && (encrProto[0] != '\0'))
		strncpy(tmp_encrProto, encrProto, strlen(encrProto));
	if ((encrPassPhrase != NULL) && (encrPassPhrase[0] != '\0'))
		strncpy(tmp_encrPassPhrase, encrPassPhrase,
			strlen(encrPassPhrase));

	fprintf(usm_fptr, "%s %s %s %s %s %s %s\n", SNMPV3_USM_CREATE_USER,
		user, user_access, tmp_authProto, tmp_authPassPhrase,
		tmp_encrProto, tmp_encrPassPhrase);
	fclose(usm_fptr);

	fclose(fptr);
	fclose(tmp_fptr);

	/* Remove the config file and rename the temp config file */
	remove(SNMPD_CONF_FILE);
	rename(TMP_CONF_FILE, SNMPD_CONF_FILE);

	/* Send a SIGHUP signal to snmpprocess to re-read the new conf */
	snmpPID = ifx_get_process_pid(SNMP_PID_FILE_PREFIX);
	if (snmpPID > 0)
		kill(snmpPID, SIGHUP);
	return TRUE;
}

/* This function is an exported API function which deletes 
 * an SNMPv3 user from the configuration file and also from
 * the UserList in snmpd. Since the communication is between
 * two processes, we cannot directly inform the snmp daemon to
 * delete the user. For this we write the required information into
 * a specifc file and send a HUP signal to snmpd to re-read the 
 * configuration file. While reading the configuration file we
 * also read this data file and the user is delted from the 
 * usmUserList in snmpd and persistence store updated. */
bool IFX_delete_snmpv3_user(char *user)
{
	FILE *from_fptr, *to_fptr, *usm_fptr;
	char *token, *token_val;
	char buf[MAX_LINE_LEN];
	char *line = NULL;
	long curr_offset = 0L, user_offset = 0L;
	int snmpPID;

	from_fptr = fopen(SNMPD_CONF_FILE, "r");
	if (from_fptr == NULL) {
		printf("Unable to open config file - %s", SNMPD_CONF_FILE);
		return FALSE;
	}

	/* Open a temporary config file */
	to_fptr = fopen(TMP_CONF_FILE, "w");
	if (to_fptr == NULL) {
		printf("Unable to open config file - %s", TMP_CONF_FILE);
		fclose(from_fptr);
		return FALSE;
	}

	if ((user == NULL) || ((user != NULL) && (user[0] == '\0'))) {
		printf("No specific user to delete!\n");
		goto lbl_exit;
	}

	/* Move the file ptr to the marker and get the offset to the marker */
	curr_offset = move_fptr_to_marker(from_fptr, v3_marker);

	/* Check if the user exists in the config file 
	 * User must exist! Otherwise it indicates an error condition
	 */
	if (find_snmpv3_user(from_fptr, user, &user_offset) == TRUE) {
		copy_bytes_upto_file_offset(from_fptr, to_fptr, curr_offset);

		/* Reposition back the from_ptr to the marker */
		fseek(from_fptr, curr_offset, SEEK_SET);

		while (!feof(from_fptr) && (curr_offset <= user_offset)) {
			get_line(from_fptr, buf);
			curr_offset = ftell(from_fptr);
			if (is_blank_line(buf)) {
				fputs(buf, to_fptr);
				continue;
			}

			line = strdup(buf);

			/* Tokenize the line */
			token = strtok(buf, delimiters);
			if (token != NULL) {
				token_val = strtok(NULL, delimiters);
				if (token_val != NULL) {
					if (strcmp(token_val, user) != 0) {
						fputs(line, to_fptr);
					} else {
						/* User matches so just stop here */
						break;
					}
				}
			}
		}

		if (!feof(from_fptr)) {
			copy_bytes_from_file_offset(from_fptr, to_fptr,
						    curr_offset);
		} else {
			fprintf(to_fptr, "\n");
		}

		/* Write the data into the SNMPV3_USM_CMD_FILE */
		usm_fptr = fopen(SNMPV3_USM_CMD_FILE, "w");
		if (usm_fptr == NULL) {
			printf("Unable to open USM command file - %s",
			       SNMPV3_USM_CMD_FILE);
			goto lbl_exit;
		}
		fprintf(usm_fptr, "%s %s\n", SNMPV3_USM_DELETE_USER, user);
		fclose(usm_fptr);

		fclose(from_fptr);
		fclose(to_fptr);

		/* Remove the config file and rename the temp config file */
		remove(SNMPD_CONF_FILE);
		rename(TMP_CONF_FILE, SNMPD_CONF_FILE);

		/* Send a SIGHUP signal to snmpprocess to re-read the new conf */
		snmpPID = ifx_get_process_pid(SNMP_PID_FILE_PREFIX);
		if (snmpPID > 0)
			kill(snmpPID, SIGHUP);
		return TRUE;
	}

	printf("User (%s) doesn't exist!\n", user);
      lbl_exit:
	fclose(from_fptr);
	fclose(to_fptr);
	remove(TMP_CONF_FILE);
	return FALSE;

}

/* This function is an exported API function which displays
 * all SNMPv3 users in the configuration file and in the
 * UserList */
int IFX_get_all_snmpv3_users(struct v3user **pv3user, int *num_users)
{
	FILE *fptr;
	long users_offset = 0L;
	char line[MAX_LINE_LEN];
	char *token, *token_val;
	int i = 0;
	struct v3user *tmpuser;

	tmpuser = *pv3user;
	tmpuser = NULL;

	fptr = fopen(SNMPD_CONF_FILE, "r");
	if (fptr == NULL) {
		printf("Unable to open config file - %s", SNMPD_CONF_FILE);
		return FAIL;
	}

	users_offset = move_fptr_to_marker(fptr, v3_marker);
	while (!feof(fptr)) {
		get_line(fptr, line);
		if (is_blank_line(line))
			continue;
		token = strtok(line, delimiters);
		if (token != NULL) {
			tmpuser =
			    (struct v3user *)realloc(tmpuser,
						     (i +
						      1) *
						     sizeof(struct v3user));
			if (strcmp(token, SNMP_RWUSER_STR) == 0)
				tmpuser[i].access = RWRITE;
			else
				tmpuser[i].access = RDONLY;
			token_val = strtok(NULL, delimiters);
			strncpy(tmpuser[i].username, token_val,
				strlen(token_val));
			tmpuser[i].username[strlen(token_val)] = '\0';
			i++;
		}
	}
	*pv3user = tmpuser;
	*num_users = i;
	fclose(fptr);
	return SUCCESS;
}
#endif

bool IFX_SNMPd_Set_Enable(bool bEnable)
{
	char *snmp_pid = SNMPD_PID_FILE_PATH;
	char snmp_command[128];
	int status = 0, ret = 0;
	int Pid;

	if (bEnable > 1 || bEnable < 0) {
		puts("Wrong IFX_SNMPd_Set_Enable parameter!");
		return 1;
	}

	Pid = ifx_get_process_pid(snmp_pid);

	if (bEnable) {
		if (Pid > 0) {
			kill(Pid, SIGKILL);
		}
		ifx_rm_pid_file(snmp_pid);
		system
		    ("test ! -f /tmp/mib_daemon_run && echo -n > /tmp/mib_daemon_run && /root/amazon_mib_daemon &");
		//sprintf(snmp_command,"snmpd -Cc %s -p /var/run/snmpd.pid",SNMPD_CONF_FILE); //commented by
		//Santosh
		sprintf(snmp_command,
			"/usr/sbin/snmpd -Cc %s -p /var/run/snmpd.pid &",
			SNMPD_CONF_FILE);
		status = system(snmp_command);
		if (status != -1) {
			waitpid(-1, &status, 0);
			if (WIFEXITED(status)) {
				ret = WEXITSTATUS(status);
				if (ret != 0)
					return 1;
			}
		} else {
			return 1;
		}
	} else {
		if (Pid > 0) {
			kill(Pid, SIGKILL);
			ifx_rm_pid_file(snmp_pid);
		}
	}
	return 0;
}

bool IFX_SNMPd_Get_Enable()
{
	int Pid;
	char *snmp_pid = SNMPD_PID_FILE_PATH;

	Pid = ifx_get_process_pid(snmp_pid);
	if (Pid > 0)
		return 1;
	return 0;
}
