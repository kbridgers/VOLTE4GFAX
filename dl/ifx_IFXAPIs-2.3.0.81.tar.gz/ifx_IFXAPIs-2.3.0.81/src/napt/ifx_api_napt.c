/* ============================================================================
 * Copyright (C) 2004 - Infineon Technologies.
 *
 * All rights reserved.
 * ============================================================================
 *
 * ============================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ============================================================================
 *
 * Revision History:
 *      - 2004/07/20, TC Chen
 *         init version
 *      - 2005/10/25, Sumedh ::[ 510251:sumedh Support for DoS Attacks, ALGs, QoS, Policy based Routing ]
 *	- 2006/06/25, Subbi :: [Modified IFX_SET_NAPT_DNAT_VIRTUALSERVER_Entry to support multiple chains
 *                               in DNAT Rules]
 *
 * ============================================================================
 */
/*
 506212:tc.chen 2005/06/21 fix rip can not receive packet from wan 
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <ifx_api_ipt_common_private.h>
#include <ifx_api_fw.h>
#include <ifx_api_napt.h>

bool IFX_CREATE_NAPT_CHAINS()
{
	//510251:sumedh (Create chains for ALGs)
	IFX_IPT_CREATE_SINGLE_CHAIN(NAPT, "IFX_NAT_ALGS");
	//IFX_IPT_CREATE_SINGLE_CHAIN(NAPT, "IFX_PREROUTING_NAT_ALGS");
	//IFX_IPT_CREATE_SINGLE_CHAIN(NAPT, "IFX_POSTROUTING_NAT_ALGS");
#ifdef IFX_DOS_ENABLE
	//510251:sumedh (Create chain for DoS attack)
	IFX_IPT_CREATE_SINGLE_CHAIN(MANGLE, "IFX_PREROUTING_MANGLE_DOS");
#endif

	//510251:sumedh (Create chain for Policy based Routed)
	IFX_IPT_CREATE_SINGLE_CHAIN(MANGLE, "IFX_MANGLE_POLICY_ROUTING");

	//510251:sumedh (Create chains for ALGs)
	/* Pramod - Not required already created above */
	//IFX_IPT_CREATE_SINGLE_CHAIN(NAPT, "IFX_NAT_ALGS");
	IFX_IPT_CREATE_SINGLE_CHAIN(NAPT, "IFX_NAPT_PREROUTING_LAN");
	IFX_IPT_CREATE_SINGLE_CHAIN(NAPT, "IFX_NAPT_PREROUTING_WAN");
	IFX_IPT_CREATE_SINGLE_CHAIN(NAPT, "IFX_NAPT_PREROUTING");
	IFX_IPT_CREATE_SINGLE_CHAIN(NAPT, "IFX_NAPT_POSTROUTING");
#ifdef CONFIG_FEATURE_IFX_IPSEC_TERMINATION
	IFX_IPT_CREATE_SINGLE_CHAIN(NAPT, "IFX_IPSEC_TERMINATION");
#endif
	IFX_IPT_CREATE_SINGLE_CHAIN(NAPT, "IFX_NAPT_WAN_SERVICES");
	IFX_IPT_CREATE_SINGLE_CHAIN(NAPT, "IFX_NAPT_DMZ");
	IFX_IPT_CREATE_SINGLE_CHAIN(NAPT, "IFX_NAPT_SNAT");
	IFX_IPT_CREATE_SINGLE_CHAIN(NAPT, "IFX_NAPT_SNAT_VS");
	IFX_IPT_CREATE_SINGLE_CHAIN(NAPT, "IFX_NAPT_SNAT_PM");
	IFX_IPT_CREATE_SINGLE_CHAIN(NAPT, "IFX_NAPT_SNAT_MASQ");
	IFX_IPT_CREATE_SINGLE_CHAIN(NAPT, "IFX_NAPT_DNAT_VS");

/* The following chains have been added to support PortMapping ADD/DEL/MODIFY */
	// Explicit Remote Host and Explicit External Port - Prio 1           
	IFX_IPT_CREATE_SINGLE_CHAIN(NAPT, "IFX_EXP_RH_EXP_EP");

	// Explicit Remote Host and WildCard External Port - Prio 2           
	IFX_IPT_CREATE_SINGLE_CHAIN(NAPT, "IFX_EXP_RH_WLD_EP");

	// WildCard Remote Host and Explicit External Port - Prio 3            
	IFX_IPT_CREATE_SINGLE_CHAIN(NAPT, "IFX_WLD_RH_EXP_EP");

	// WildCard Remote Host and WildCard External Port - Prio 4
	IFX_IPT_CREATE_SINGLE_CHAIN(NAPT, "IFX_WLD_RH_WLD_EP");

	/* Pramod - Not required already created above */
	// IFX_IPT_CREATE_SINGLE_CHAIN(NAPT, "IFX_NAPT_DNAT_VS");            
	IFX_IPT_CREATE_SINGLE_CHAIN(NAPT, "IFX_NAPT_DNAT_PM");

	return 0;
}

bool IFX_CLEAN_NAPT()
{
	char command[STR_COMMAND];

	IFX_IPT_FLUSH_CHAIN(NAPT, " ");
	IFX_IPT_FLUSH_CHAIN(MANGLE, " ");

#if 0				/* [ 23122006, Ritesh */
	sprintf(command, "/usr/sbin/iptables -t nat -X");
	ifx_run_command(command);
	sprintf(command, "/usr/sbin/iptables -t mangle -X");	//510251:sumedh
	ifx_run_command(command);
#else				/* ][ */
	sprintf(command, "%s %s %s", "/usr/sbin/iptables", "-t nat", "-X");
	ifx_run_command(command);
	sprintf(command, "%s %s %s", "/usr/sbin/iptables", "-t mangle", "-X");
	ifx_run_command(command);
#endif				/* ] */
	return 0;
}

bool IFX_INIT_POSTROUTING_CHAIN()
{

#if 0				/* [ 23122006, Ritesh */
	char command[STR_COMMAND];

	sprintf(command,
		"/usr/sbin/iptables -t nat -A IFX_NAPT_POSTROUTING -j IFX_NAPT_SNAT_VS");
	ifx_run_command(command);
	sprintf(command,
		"/usr/sbin/iptables -t nat -A IFX_NAPT_POSTROUTING -j IFX_NAPT_SNAT_PM");
	ifx_run_command(command);
#else				/* ][ */
	IFX_IPT_SET_RULE2(NAPT, ADD, "IFX_NAPT_POSTROUTING", "", "", "",
			  "IFX_NAPT_SNAT_VS");
	IFX_IPT_SET_RULE2(NAPT, ADD, "IFX_NAPT_POSTROUTING", "", "", "",
			  "IFX_NAPT_SNAT_PM");
#endif				/* ] */
#ifdef CONFIG_FEATURE_IFX_IPSEC_TERMINATION
	IFX_IPT_SET_RULE2(NAPT, ADD, "POSTROUTING", "", "", "",
			  "IFX_IPSEC_TERMINATION");
#endif

	return 0;
}

bool IFX_INIT_PREROUTING_CHAIN()
{
	char command[STR_COMMAND];

#if 0				/* [ 23122006, Ritesh */
	sprintf(command, "/usr/sbin/iptables -t nat -P PREROUTING DROP");
	ifx_run_command(command);

	sprintf(command,
		"/usr/sbin/iptables -t nat -A IFX_NAPT_PREROUTING -j IFX_NAPT_DNAT_VS");
	ifx_run_command(command);

	sprintf(command, "/usr/sbin/iptables -t nat -A IFX_NAPT_DNAT_VS -j IFX_EXP_RH_EXP_EP");	// Explicit Remote Host and Explicit External Port - Prio 1
	ifx_run_command(command);

	sprintf(command, "/usr/sbin/iptables -t nat -A IFX_NAPT_DNAT_VS -j IFX_EXP_RH_WLD_EP");	// Explicit Remote Host and WildCard External Port - Prio 2
	ifx_run_command(command);

	sprintf(command, "/usr/sbin/iptables -t nat -A IFX_NAPT_DNAT_VS -j IFX_WLD_RH_EXP_EP");	// WildCard Remote Host and Explicit External Port - Prio 3
	ifx_run_command(command);

	sprintf(command, "/usr/sbin/iptables -t nat -A IFX_NAPT_DNAT_VS -j IFX_WLD_RH_WLD_EP");	// WildCard Remote Host and WildCard External Port - Prio 4
	ifx_run_command(command);

	sprintf(command,
		"/usr/sbin/iptables -t nat -A IFX_NAPT_PREROUTING -j IFX_NAPT_DNAT_PM");
	ifx_run_command(command);

	sprintf(command,
		"/usr/sbin/iptables -t nat -A IFX_NAPT_PREROUTING -j IFX_NAPT_DMZ");
	ifx_run_command(command);

	sprintf(command,
		"/usr/sbin/iptables -t nat -A PREROUTING -j IFX_NAPT_PREROUTING_WAN ");
	ifx_run_command(command);

	// 506212:tc.chen start
	sprintf(command,
		"/usr/sbin/iptables -t nat -A IFX_NAPT_PREROUTING_WAN -p udp --dport 520 -d 224.0.0.9/32 -j ACCEPT");
	ifx_run_command(command);
	sprintf(command,
		"/usr/sbin/iptables -t nat -A IFX_NAPT_PREROUTING_WAN -p udp --dport 520 -d 255.255.255.255/32 -j ACCEPT");
	ifx_run_command(command);
	// 506212:tc.chen end

	//510251:sumedh start
	sprintf(command,
		"/usr/sbin/iptables -A PREROUTING -t nat -j IFX_NAT_ALGS");
	ifx_run_command(command);
	//510251:sumedh stop

	sprintf(command,
		"/usr/sbin/iptables -t nat -A PREROUTING -j IFX_NAPT_PREROUTING_LAN ");
	ifx_run_command(command);
#else				/* ][ */

	/* Pramod - for POLICY the command is not properly formed in IFX_IPT_SET_RULE2, it doesnt include table type
	   so commenting this line and using old one
	   IFX_IPT_SET_RULE2(NAPT, POLICY, "PREROUTING", "", "", "", "DROP"); */

#ifndef IPT_VER_1_4_6
	sprintf(command, "/usr/sbin/iptables -t nat -P PREROUTING DROP");
	ifx_run_command(command);
#endif				// IPT_VER_1_4_6

	IFX_IPT_SET_RULE2(NAPT, ADD, "IFX_NAPT_PREROUTING", "", "", "",
			  "IFX_NAPT_DNAT_VS");

	IFX_IPT_SET_RULE2(NAPT, ADD, "IFX_NAPT_DNAT_VS", "", "", "",
			  "IFX_EXP_RH_EXP_EP");

	IFX_IPT_SET_RULE2(NAPT, ADD, "IFX_NAPT_DNAT_VS", "", "", "",
			  "IFX_EXP_RH_WLD_EP");

	IFX_IPT_SET_RULE2(NAPT, ADD, "IFX_NAPT_DNAT_VS", "", "", "",
			  "IFX_WLD_RH_EXP_EP");

	IFX_IPT_SET_RULE2(NAPT, ADD, "IFX_NAPT_DNAT_VS", "", "", "",
			  "IFX_WLD_RH_WLD_EP");

	IFX_IPT_SET_RULE2(NAPT, ADD, "IFX_NAPT_PREROUTING", "", "", "",
			  "IFX_NAPT_DNAT_PM");

	IFX_IPT_SET_RULE2(NAPT, ADD, "IFX_NAPT_PREROUTING", "", "", "",
			  "IFX_NAPT_DMZ");

	IFX_IPT_SET_RULE2(NAPT, ADD, "PREROUTING", "", "", "",
			  "IFX_NAPT_PREROUTING_WAN");

	// 506212:tc.chen start
	sprintf(command, "%s %s %s", "--dport", "520", "-d 224.0.0.9/32");
	IFX_IPT_SET_RULE2(NAPT, ADD, "IFX_NAPT_PREROUTING_WAN", "udp", command,
			  "", "ACCEPT");
	//sprintf(command,"/usr/sbin/iptables -t nat -A IFX_NAPT_PREROUTING_WAN -p udp --dport 520 -d 255.255.255.255/32 -j ACCEPT");
	sprintf(command, "%s %s %s", "--dport", "520", "-d 255.255.255.255/32");
	IFX_IPT_SET_RULE2(NAPT, ADD, "IFX_NAPT_PREROUTING_WAN", "udp", command,
			  "", "ACCEPT");
	// 506212:tc.chen end

	//510251:sumedh start
	IFX_IPT_SET_RULE2(NAPT, ADD, "PREROUTING", "", "", "", "IFX_NAT_ALGS");
	//510251:sumedh stop

	IFX_IPT_SET_RULE2(NAPT, ADD, "PREROUTING", "", "", "",
			  "IFX_NAPT_PREROUTING_LAN");
#endif				/* ] */
	return 0;
}

bool IFXSetNAPTEnable(int operation, bool * pbIFX_SET_Enable)
{
	bool bEnable = 0;
	bool ret = 0;
#if 0
	char command[STR_COMMAND];
#endif

	switch (operation) {
	case GET:
		ret =
		    IFX_IPT_SET_CHAIN_ENABLE(NAPT, GET, "POSTROUTING",
					     &bEnable);

		if (ret == 0) {
			*pbIFX_SET_Enable = bEnable;
		}
		break;
	case SET:
		switch (*pbIFX_SET_Enable) {
		case FALSE:
			ret =
			    IFX_IPT_SET_CHAIN_ENABLE(NAPT, GET, "POSTROUTING",
						     &bEnable);
			if (ret == 0 && bEnable == TRUE) {
				bEnable = FALSE;
#if 0				/* [ 23122006, Ritesh */
				sprintf(command,
					"/usr/sbin/iptables -t nat -D PREROUTING -j IFX_NAPT_WAN_SERVICES");
				ifx_run_command(command);
#else				/* ][ */
				IFX_IPT_SET_RULE2(NAPT, DELETE, "PREROUTING",
						  "", "", "",
						  "IFX_NAPT_WAN_SERVICES");
#endif				/* ] */
				ret =
				    IFX_IPT_SET_CHAIN_ENABLE(NAPT, SET,
							     "PREROUTING",
							     &bEnable);
				ret =
				    IFX_IPT_SET_CHAIN_ENABLE(NAPT, SET,
							     "POSTROUTING",
							     &bEnable);
#if 0				/* [ 23122006, Ritesh */
				sprintf(command,
					"/usr/sbin/iptables -t nat -I PREROUTING -j IFX_NAPT_WAN_SERVICES");
				ifx_run_command(command);
#else				/* ][ */
				IFX_IPT_SET_RULE2(NAPT, INSERT, "PREROUTING",
						  "", "", "",
						  "IFX_NAPT_WAN_SERVICES");
#endif				/* ] */
			}
			break;
		case TRUE:
			ret =
			    IFX_IPT_SET_CHAIN_ENABLE(NAPT, GET, "POSTROUTING",
						     &bEnable);
			if (ret == 0 && bEnable == FALSE) {
				bEnable = TRUE;
				ret =
				    IFX_IPT_SET_CHAIN_ENABLE(NAPT, SET,
							     "PREROUTING",
							     &bEnable);
				ret =
				    IFX_IPT_SET_CHAIN_ENABLE(NAPT, SET,
							     "POSTROUTING",
							     &bEnable);
			}
			break;
		default:
			return 1;
		}
		break;
	}
	return 0;
}

bool IFX_NAPT_INIT()
{
	bool bEnable = FALSE;
#if 0
	char command[STR_COMMAND];
#endif

	IFX_CLEAN_NAPT();

	// Create Chains
	IFX_CREATE_NAPT_CHAINS();
	IFX_INIT_PREROUTING_CHAIN();
	IFX_INIT_POSTROUTING_CHAIN();

#if 0				/* [ 23122006, Ritesh */
	sprintf(command,
		"/usr/sbin/iptables -t nat -A PREROUTING -j IFX_NAPT_WAN_SERVICES");
	ifx_run_command(command);
	sprintf(command,
		"/usr/sbin/iptables -t nat -A POSTROUTING -j IFX_NAPT_POSTROUTING");
	ifx_run_command(command);
	sprintf(command,
		"/usr/sbin/iptables -t nat -A POSTROUTING -j IFX_NAPT_SNAT_MASQ");
	ifx_run_command(command);
#else				/* ][ */
	IFX_IPT_SET_RULE2(NAPT, ADD, "PREROUTING", "", "", "",
			  "IFX_NAPT_WAN_SERVICES");
	IFX_IPT_SET_RULE2(NAPT, ADD, "POSTROUTING", "", "", "",
			  "IFX_NAPT_POSTROUTING");
	IFX_IPT_SET_RULE2(NAPT, ADD, "POSTROUTING", "", "", "",
			  "IFX_NAPT_SNAT_MASQ");
#endif				/* ] */

	// disable all 
	IFXSetNAPTEnable(SET, &bEnable);
	IFX_SET_NAPT_DMZ_ENABLE(SET, &bEnable);
	IFX_SET_NAPT_DNAT_PORTMAPPING_ENABLE(SET, &bEnable);
	IFX_SET_NAPT_DNAT_VIRTUALSERVER_ENABLE(SET, &bEnable);

	//510251:sumedh start
#if 0				/* [ 23122006, Ritesh */
	sprintf(command,
		"/usr/sbin/iptables -I PREROUTING 1 -t mangle -j IFX_PREROUTING_MANGLE_DOS");
	ifx_run_command(command);
	sprintf(command,
		"/usr/sbin/iptables -A PREROUTING -t mangle -j IFX_MANGLE_POLICY_ROUTING");
	ifx_run_command(command);
	sprintf(command,
		"/usr/sbin/iptables -A POSTROUTING -t nat -j IFX_NAT_ALGS");
	ifx_run_command(command);
#else				/* ][ */
#ifdef IFX_DOS_ENABLE
	IFX_IPT_SET_RULE2(MANGLE, INSERT, "PREROUTING", "", "1", "",
			  "IFX_PREROUTING_MANGLE_DOS");
#endif
	IFX_IPT_SET_RULE2(MANGLE, ADD, "PREROUTING", "", "", "",
			  "IFX_MANGLE_POLICY_ROUTING");
	IFX_IPT_SET_RULE2(NAPT, ADD, "POSTROUTING", "", "", "", "IFX_NAT_ALGS");
#endif				/* ] */
	//510251:sumedh end

	// enable forward
	//fp = fopen("/proc/sys/net/ipv4/ip_forward","w");
	//fprintf(fp,"1");
	//fclose(fp);
	return 0;
}

bool IFX_NAPT_SET_WAN_IF(int operation, char *IFNAME)
{
#if 0				/* [ 23122006, Ritesh */
	char command[STR_COMMAND];
	switch (operation) {
	case ADD:
		sprintf(command,
			"/usr/sbin/iptables -t nat -A IFX_NAPT_SNAT_MASQ -o %s -j MASQUERADE",
			IFNAME);
		ifx_run_command(command);

		break;
	case DELETE:
		sprintf(command,
			"/usr/sbin/iptables -t nat -D IFX_NAPT_SNAT_MASQ -o %s -j MASQUERADE",
			IFNAME);
		ifx_run_command(command);

		break;
	}
#else				/* ][ */
	switch (operation) {
	case ADD:
		IFX_IPT_SET_RULE2(NAPT, ADD, "IFX_NAPT_SNAT_MASQ", "", "-o",
				  IFNAME, "MASQUERADE");

		break;
	case DELETE:
		IFX_IPT_SET_RULE2(NAPT, DELETE, "IFX_NAPT_SNAT_MASQ", "", "-o",
				  IFNAME, "MASQUERADE");

		break;
	}
#endif				/* ] */
	return 0;
}

bool IFX_NAPT_SET_WAN_IP(int operation, unsigned long int IPADDRESS)
{
#if 0				/* [ 23122006, Ritesh */
	char command[STR_COMMAND];
	struct in_addr addr_tmp;
	if (IPADDRESS == 0xFFFFFFFF || IPADDRESS == 0)
		return 1;
	addr_tmp.s_addr = IPADDRESS;
	switch (operation) {
	case ADD:
		sprintf(command,
			"/usr/sbin/iptables -t nat -A IFX_NAPT_PREROUTING_WAN -d %s -j IFX_NAPT_PREROUTING",
			inet_ntoa(addr_tmp));
		ifx_run_command(command);
		sprintf(command,
			"/usr/sbin/iptables -t nat -A IFX_NAPT_PREROUTING_WAN -d %s -j ACCEPT",
			inet_ntoa(addr_tmp));
		ifx_run_command(command);
		break;
	case DELETE:
		sprintf(command,
			"/usr/sbin/iptables -t nat -D IFX_NAPT_PREROUTING_WAN -d %s -j IFX_NAPT_PREROUTING",
			inet_ntoa(addr_tmp));
		ifx_run_command(command);
		sprintf(command,
			"/usr/sbin/iptables -t nat -D IFX_NAPT_PREROUTING_WAN -d %s -j ACCEPT",
			inet_ntoa(addr_tmp));
		ifx_run_command(command);
		break;
	}
#else				/* ][ */
	struct in_addr addr_tmp;
	if (IPADDRESS == 0xFFFFFFFF || IPADDRESS == 0)
		return 1;
	addr_tmp.s_addr = IPADDRESS;
	switch (operation) {
	case ADD:
		IFX_IPT_SET_RULE2(NAPT, ADD, "IFX_NAPT_PREROUTING_WAN", "",
				  "-d", inet_ntoa(addr_tmp),
				  "IFX_NAPT_PREROUTING");
		IFX_IPT_SET_RULE2(NAPT, ADD, "IFX_NAPT_PREROUTING_WAN", "",
				  "-d", inet_ntoa(addr_tmp), "ACCEPT");
		break;
	case DELETE:
		IFX_IPT_SET_RULE2(NAPT, DELETE, "IFX_NAPT_PREROUTING_WAN", "",
				  "-d", inet_ntoa(addr_tmp),
				  "IFX_NAPT_PREROUTING");
		IFX_IPT_SET_RULE2(NAPT, DELETE, "IFX_NAPT_PREROUTING_WAN", "",
				  "-d", inet_ntoa(addr_tmp), "ACCEPT");
		break;
	}
#endif				/* ] */
	return 0;
}

unsigned long int bits2netmask(int bits)
{
	u_int32_t netmask, bm;

	if (bits >= 32 || bits < 0)
		return (~0);
	for (netmask = 0, bm = 0x80000000; bits; bits--, bm >>= 1)
		netmask |= bm;
	return htonl(netmask);
}

int netmask2bits(u_int32_t netmask)
{
	u_int32_t bm;
	int bits;

	netmask = ntohl(netmask);
	for (bits = 0, bm = 0x80000000; netmask & bm; netmask <<= 1)
		bits++;
	if (netmask)
		return -1;	/* holes in netmask */
	return bits;
}

bool IFX_NAPT_SET_LAN(int operation, char *IFNAME, unsigned long int IPADDRESS,
		      unsigned long int NETMASK)
{
	char command[STR_COMMAND];
	char target[64];
	struct in_addr addr_tmp;
	int netmask_bit;

	if (IPADDRESS == 0xFFFFFFFF || IPADDRESS == 0)
		return 1;
	addr_tmp.s_addr = IPADDRESS;
	netmask_bit = netmask2bits(NETMASK);

	switch (operation) {
	case ADD:
#if 0				/* [ 23122006, Ritesh */
		sprintf(command,
			"/usr/sbin/iptables -t nat -A IFX_NAPT_SNAT -s %s/%d -o %s -j SNAT --to %s",
			inet_ntoa(addr_tmp), netmask_bit, IFNAME,
			inet_ntoa(addr_tmp));
		ifx_run_command(command);

		sprintf(command,
			"/usr/sbin/iptables -t nat -A IFX_NAPT_PREROUTING_LAN  -i %s -j ACCEPT",
			IFNAME);
		ifx_run_command(command);
#else				/* ][ */
		sprintf(command, "-s %s/%d -o %s", inet_ntoa(addr_tmp),
			netmask_bit, IFNAME);
		sprintf(target, "%s %s %s", "SNAT", "--to",
			inet_ntoa(addr_tmp));
		IFX_IPT_SET_RULE2(NAPT, ADD, "IFX_NAPT_SNAT", "", command, "",
				  target);
		IFX_IPT_SET_RULE2(NAPT, ADD, "IFX_NAPT_PREROUTING_LAN", "",
				  "-i", IFNAME, "ACCEPT");
#endif				/* ] */

		break;
	case DELETE:
#if 0				/* [ 23122006, Ritesh */
		sprintf(command,
			"/usr/sbin/iptables -t nat -D IFX_NAPT_SNAT -s %s/%d -o %s -j SNAT --to %s",
			inet_ntoa(addr_tmp), netmask_bit, IFNAME,
			inet_ntoa(addr_tmp));
		ifx_run_command(command);
		sprintf(command,
			"/usr/sbin/iptables -t nat -D IFX_NAPT_PREROUTING_LAN  -i %s -j ACCEPT",
			IFNAME);
		ifx_run_command(command);
#else				/* ][ */
		sprintf(command, "-s %s/%d -o %s", inet_ntoa(addr_tmp),
			netmask_bit, IFNAME);
		sprintf(target, "%s %s %s", "SNAT", "--to",
			inet_ntoa(addr_tmp));
		IFX_IPT_SET_RULE2(NAPT, DELETE, "IFX_NAPT_SNAT", "", command,
				  "", target);
		IFX_IPT_SET_RULE2(NAPT, DELETE, "IFX_NAPT_PREROUTING_LAN", "",
				  "-i", IFNAME, "ACCEPT");
#endif				/* ] */

		break;
	case DELETE_ALL:
		IFX_IPT_FLUSH_CHAIN(NAPT, "IFX_NAPT_SNAT");
		IFX_IPT_FLUSH_CHAIN(NAPT, "IFX_NAPT_PREROUTING_LAN");
		break;
	default:
		return 1;
		break;
	}
	return 0;
}

#if 0
bool IFX_NAPT_SET_LAN_IF(int operation, char *IFNAME,
			 unsigned long int IPADDRESS, unsigned long int NETMASK)
{
	char command[STR_COMMAND];
	struct in_addr addr_tmp;
	int netmask_bit;

	if (IPADDRESS == 0xFFFFFFFF || IPADDRESS == 0)
		return 1;
	addr_tmp.s_addr = IPADDRESS;
	netmask_bit = netmask2bits(NETMASK);

	switch (operation) {
	case ADD:
		sprintf(command,
			"/usr/sbin/iptables -t nat -A IFX_NAPT_SNAT -s %s/%d -o %s -j SNAT --to %s",
			inet_ntoa(addr_tmp), netmask_bit, IFNAME,
			inet_ntoa(addr_tmp));
		ifx_run_command(command);

		break;
	case DELETE:
		sprintf(command,
			"/usr/sbin/iptables -t nat -D IFX_NAPT_SNAT -s %s/%d -o %s -j SNAT --to %s",
			inet_ntoa(addr_tmp), netmask_bit, IFNAME,
			inet_ntoa(addr_tmp));
		ifx_run_command(command);

		break;
	case DELETE_ALL:
		IFX_IPT_FLUSH_CHAIN(NAPT, "IFX_NAPT_SNAT");
//      IFX_IPT_FLUSH_CHAIN(NAPT,"IFX_NAPT_POSTROUTING");
//      IFX_INIT_POSTROUTING_CHAIN(); 
		break;
	default:
		return 1;
		break;
	}
	return 0;
}
#endif

bool IFX_SET_NAPT_DMZ_ENABLE(int operation, bool * pbEnable)
{
	if (operation == SET) {
		IFX_SET_FIREWALL_DMZ_ENABLE(operation, pbEnable);
	}

	return IFX_IPT_SET_CHAIN_ENABLE(NAPT, operation, "IFX_NAPT_DMZ",
					pbEnable);
}

//bool IFX_SET_NAPT_DMZ(int operation, char *WAN_IFName, __u32 DMZ_IP)
bool IFX_SET_NAPT_DMZ(int operation, __u32 DMZ_IP)
{
	char command[STR_COMMAND];
	struct in_addr tmp_ip;
	bool bEnable;

	tmp_ip.s_addr = DMZ_IP;

	switch (operation) {
	case ADD:
#if 0				/* [ 23122006, Ritesh */
		//sprintf(command,"/usr/sbin/iptables -t nat -A IFX_NAPT_DMZ -i %s -j DNAT --to %s ",WAN_IFName, inet_ntoa(tmp_ip));
		sprintf(command,
			"/usr/sbin/iptables -t nat -A IFX_NAPT_DMZ -j DNAT --to %s ",
			inet_ntoa(tmp_ip));
		ifx_run_command(command);
#else				/* ][ */
		sprintf(command, "%s %s %s", "DNAT", "--to", inet_ntoa(tmp_ip));
		IFX_IPT_SET_RULE2(NAPT, ADD, "IFX_NAPT_DMZ", "", "", "",
				  command);
#endif				/* ] */

		IFX_SET_FIREWALL_DMZ(ADD, DMZ_IP);

		break;

	case DELETE:
#if 0				/* [ 23122006, Ritesh */
		//sprintf(command,"/usr/sbin/iptables -t nat -D IFX_NAPT_DMZ -i %s -j DNAT --to %s ",WAN_IFName, inet_ntoa(tmp_ip)); 
		sprintf(command,
			"/usr/sbin/iptables -t nat -D IFX_NAPT_DMZ -j DNAT --to %s ",
			inet_ntoa(tmp_ip));
		ifx_run_command(command);
#else				/* ][ */
		sprintf(command, "%s %s %s", "DNAT", "--to", inet_ntoa(tmp_ip));
		IFX_IPT_SET_RULE2(NAPT, DELETE, "IFX_NAPT_DMZ", "", "", "",
				  command);
#endif				/* ] */

		IFX_SET_FIREWALL_DMZ(DELETE, DMZ_IP);
		break;
		break;

	case DELETE_ALL:

		    IFX_IPT_SET_CHAIN_ENABLE(NAPT, GET, "IFX_NAPT_DMZ",
					     &bEnable);
		IFX_IPT_FLUSH_CHAIN(NAPT, "IFX_NAPT_DMZ");
		    IFX_IPT_SET_CHAIN_ENABLE(NAPT, SET, "IFX_NAPT_DMZ",
					     &bEnable);

		IFX_IPT_FLUSH_CHAIN(FIREWALL, "IFX_FW_DMZ");
		break;
		break;
	}
	return 0;
}

bool IFX_SET_NAPT_DNAT_PORTMAPPING_ENABLE(int operation, bool * pbEnable)
{
	bool ret;
	if (operation == SET) {
		IFX_SET_FIREWALL_DNAT_PORTMAPPING_ENABLE(SET, pbEnable);
	}
	ret =
	    IFX_IPT_SET_CHAIN_ENABLE(NAPT, operation, "IFX_NAPT_DNAT_PM",
				     pbEnable);
	if (ret != 0)
		return ret;
	return IFX_IPT_SET_CHAIN_ENABLE(NAPT, operation, "IFX_NAPT_SNAT_PM",
					pbEnable);

}

bool IFX_SET_NAPT_DNAT_PORTMAPPING_Entry(int operation, P_IFX_IPT_RULE pCfg,
					 int *piEnteriesSize)
{
	int ret = 0;
	int i = 0;
	P_IFX_IPT_RULE pFWCfg = NULL;

	ret =
	    IFX_IPT_SET_RULES(NAPT, operation, "IFX_NAPT_DNAT_PM", pCfg,
			      piEnteriesSize, DNAT);

	if (operation != DELETE_ALL) {
		pFWCfg =
		    (P_IFX_IPT_RULE) malloc(sizeof(IFX_IPT_RULE) *
					    (*piEnteriesSize));
		if (pFWCfg == NULL) {
			return 1;
		}
		memcpy(pFWCfg, pCfg, sizeof(IFX_IPT_RULE) * (*piEnteriesSize));
		for (i = 0; i < *piEnteriesSize; i++) {
			pFWCfg[i].targetip = 0;
			pFWCfg[i].targetport_start = 0;
			pFWCfg[i].targetport_end = 0;
		}
	}

	ret =
	    IFX_IPT_SET_RULES(NAPT, operation, "IFX_NAPT_SNAT_PM", pFWCfg,
			      piEnteriesSize, IFX_NAPT_SNAT);
	if (ret != 0) {
		if (pFWCfg)
			free(pFWCfg);
		return ret;
	}

	ret =
	    IFX_SET_FIREWALL_DNAT_PORTMAPPING_Entry(operation, pFWCfg,
						    piEnteriesSize);
	if (pFWCfg)
		free(pFWCfg);
	return ret;
}

bool IFX_GET_NAPT_DNAT_PORTMAPPING_Table(int iSize, char *pBuffer,
					 int *piReturnEntries)
{

	return IFX_IPT_GET_RULES(NAPT, "IFX_NAPT_DNAT_PM", pBuffer, iSize,
				 piReturnEntries, DNAT);

}

bool IFX_SET_NAPT_DNAT_VIRTUALSERVER_ENABLE(int operation, bool * pbEnable)
{
	int ret;
	if (operation == SET) {
		IFX_SET_FIREWALL_DNAT_VIRTUALSERVER_ENABLE(SET, pbEnable);
	}
	ret =
	    IFX_IPT_SET_CHAIN_ENABLE(NAPT, operation, "IFX_NAPT_DNAT_VS",
				     pbEnable);
	if (ret != 0)
		return ret;
	return IFX_IPT_SET_CHAIN_ENABLE(NAPT, operation, "IFX_NAPT_SNAT_VS",
					pbEnable);
}

#ifdef ORGCODE
bool IFX_SET_NAPT_DNAT_VIRTUALSERVER_Entry(int operation, P_IFX_IPT_RULE pCfg,
					   int *piEnteriesSize)
{
	int ret = 0;
	int i = 0;
	P_IFX_IPT_RULE pFWCfg = NULL;

	ret =
	    IFX_IPT_SET_RULES(NAPT, operation, "IFX_NAPT_DNAT_VS", pCfg,
			      piEnteriesSize, DNAT);
	if (ret != 0)
		return ret;

	if (operation != DELETE_ALL) {
		pFWCfg =
		    (P_IFX_IPT_RULE) malloc(sizeof(IFX_IPT_RULE) *
					    (*piEnteriesSize));
		if (pFWCfg == NULL) {
			return 1;
		}
		memcpy(pFWCfg, pCfg, sizeof(IFX_IPT_RULE) * (*piEnteriesSize));
		for (i = 0; i < *piEnteriesSize; i++) {
			pFWCfg[i].dstport_start = pFWCfg[i].targetport_start;
			pFWCfg[i].dstport_end = pFWCfg[i].targetport_end;
			pFWCfg[i].targetip = 0;
			pFWCfg[i].targetport_start = 0;
			pFWCfg[i].targetport_end = 0;
		}
	}

	ret =
	    IFX_IPT_SET_RULES(NAPT, operation, "IFX_NAPT_SNAT_VS", pFWCfg,
			      piEnteriesSize, IFX_NAPT_SNAT);
	if (ret != 0) {
		if (pFWCfg)
			free(pFWCfg);
		return ret;
	}
	ret =
	    IFX_SET_FIREWALL_DNAT_VIRTUALSERVER_Entry(operation, pFWCfg,
						      piEnteriesSize);
	if (pFWCfg)
		free(pFWCfg);
	return ret;

}

#else

bool IFX_SET_NAPT_DNAT_VIRTUALSERVER_Entry(int operation, P_IFX_IPT_RULE pCfg,
					   int piEnteriesSize)
{
	int ret = 0;
	int i = 0;
	P_IFX_IPT_RULE pFWCfg = NULL;

	if (pCfg) {
		// Explicit Remote Host and Explicit External Port - Prio 1           
		if ((pCfg->srcip != 0) && (pCfg->dstport_start != 0)) {
			ret =
			    IFX_IPT_SET_RULES(NAPT, operation,
					      "IFX_EXP_RH_EXP_EP", pCfg,
					      &piEnteriesSize, DNAT);
		}
		// Explicit Remote Host and WildCard External Port - Prio 2           
		else if ((pCfg->srcip != 0) && (pCfg->dstport_start == 0)) {
			ret =
			    IFX_IPT_SET_RULES(NAPT, operation,
					      "IFX_EXP_RH_WLD_EP", pCfg,
					      &piEnteriesSize, DNAT);
		}
		// WildCard Remote Host and Explicit External Port - Prio 3            
		else if ((pCfg->srcip == 0) && (pCfg->dstport_start != 0)) {
			ret =
			    IFX_IPT_SET_RULES(NAPT, operation,
					      "IFX_WLD_RH_EXP_EP", pCfg,
					      &piEnteriesSize, DNAT);
		} else {
			// WildCard Remote Host and WildCard External Port - Prio 4
			ret =
			    IFX_IPT_SET_RULES(NAPT, operation,
					      "IFX_WLD_RH_WLD_EP", pCfg,
					      &piEnteriesSize, DNAT);
		}
	}

	if (ret != 0)
		return ret;

	if (operation != DELETE_ALL) {
		pFWCfg =
		    (P_IFX_IPT_RULE) malloc(sizeof(IFX_IPT_RULE) *
					    (piEnteriesSize));
		if (pFWCfg == NULL) {
			return 1;
		}
		if (pCfg == NULL) {
			IFX_MEM_FREE(pFWCfg);
			return 1;
		}
		memcpy(pFWCfg, pCfg, sizeof(IFX_IPT_RULE) * (piEnteriesSize));
		for (i = 0; i < piEnteriesSize; i++) {
#if 0
			pFWCfg[i].targetport_start = pFWCfg[i].dstport_start;
			pFWCfg[i].targetport_end = pFWCfg[i].dstport_end;
			strncpy(pFWCfg[i].outif, pFWCfg[i].inif,
				strlen(pFWCfg[i].inif));
			pFWCfg[i].outif[strlen(pFWCfg[i].inif)] = '\0';
			memset(pFWCfg[i].inif, 0x00, sizeof(pFWCfg[i].inif));
			pFWCfg[i].srcip = 0;
			pFWCfg[i].srcport_start = 0;
			pFWCfg[i].srcport_end = 0;
			pFWCfg[i].targetip = 0;
			pFWCfg[i].dstport_start = 0;
			pFWCfg[i].dstport_end = 0;
			pFWCfg[i].protocol = pFWCfg[i].protocol;
#else				//Since we do not add SNAT, modify the structure for adding FW rule only!
			pFWCfg[i].dstport_start = pFWCfg[i].targetport_start;
			pFWCfg[i].dstport_end = pFWCfg[i].targetport_end;
			pFWCfg[i].targetport_start = 0;
			pFWCfg[i].targetport_end = 0;
			pFWCfg[i].dstip = pFWCfg[i].targetip;
			pFWCfg[i].targetip = 0;
#endif
		}
	}
#if 0				//Do not add SNAT rule. the conntrack or the default interface specific MASQUERADE rule will do the expected action!
	ret =
	    IFX_IPT_SET_RULES(NAPT, operation, "IFX_NAPT_SNAT_VS", pFWCfg,
			      piEnteriesSize, IFX_NAPT_SNAT);
	if (ret != 0) {
		if (pFWCfg)
			free(pFWCfg);
		return ret;
	}
#endif

	ret =
	    IFX_SET_FIREWALL_DNAT_VIRTUALSERVER_Entry(operation, pFWCfg,
						      &piEnteriesSize);
	if (pFWCfg)
		free(pFWCfg);
	return ret;

}

#endif

bool IFX_GET_NAPT_DNAT_VIRTUALSERVERG_Table(int iSize, char *pBuffer,
					    int *piReturnEntries)
{
	return IFX_IPT_GET_RULES(NAPT, "IFX_NAPT_DNAT_VS", pBuffer, iSize,
				 piReturnEntries, DNAT);
}

bool IFX_SET_NAPT_REDIRECT_SERVICES(int operation, __u16 original_port,
				    __u16 protocol, __u32 IPADDR,
				    __u16 new_port)
{
	int iEnteriesSize = 1;
	IFX_IPT_RULE FWCfg = { 0 };
	FWCfg.dstport_start = original_port;
	FWCfg.targetport_start = new_port;
	FWCfg.protocol = protocol;

	IFX_SET_FIREWALL_ACCEPT_WAN_SERVICES_TO_LAN(operation, new_port,
						    protocol);
	FWCfg.targetip = IPADDR;
	return IFX_IPT_SET_RULES(NAPT, operation, "IFX_NAPT_WAN_SERVICES",
				 &FWCfg, &iEnteriesSize, DNAT);
}
