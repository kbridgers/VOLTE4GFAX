/* ============================================================================
 * Copyright (C) 2004 - Infineon Technologies.
 *
 * All rights reserved.
 * ============================================================================
 *
 * ============================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ============================================================================
 *
 * Revision History:
 *      - 2004/07/20, TC Chen
 *         init version
 *      - 2005/10/25, Sumedh ::[ 510251:sumedh Support for DoS Attacks, ALGs, QoS, Policy based Routing ]
 *    	- 2006/04/18, Sumedh ::[ 604181: commented out (parental control--device should always be accessible) ]
 *         
 *
 * ============================================================================
 */
// 508182:tc.chen fix sip data reject by firewall.

#include <stdio.h>
#include <sys/socket.h>
//#include <netinet/in.h>
#include <arpa/inet.h>
//#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>

#include <ifx_api_ipt_common_private.h>
#include <ifx_api_fw.h>

bool IFX_SET_PACKET_FORWARD_ENABLE(int operation, bool * pbEnable)
{
	FILE *fp = NULL;

	switch (operation) {
	case GET:
		if ((fp = fopen("/proc/sys/net/ipv4/ip_forward", "r")) == NULL) {
			return 1;
		}
		fscanf(fp, "%d", (int *)pbEnable);
		break;
	case SET:
		if ((fp = fopen("/proc/sys/net/ipv4/ip_forward", "w")) == NULL) {
			return 1;
		}

		switch (*pbEnable) {
		case FALSE:
			fprintf(fp, "0");
			break;
		case TRUE:
			fprintf(fp, "1");
			break;
		default:
			fclose(fp);
			return 1;
		}
		break;
	}
	if (fp != NULL) {
		fclose(fp);
	}
	return 0;
}

bool IFX_CREATE_FW_CHAINS()
{
#if 0
	char command[STR_COMMAND];
#endif

	//510251:sumedh (Create additional chains for ALGs in the filter table) 
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_INPUT_ALGS");
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_OUTPUT_ALGS");

#ifdef IFX_DOS_ENABLE
	//510251:sumedh (Create additional chains for DoS Attacks in the filter table) 
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FWD_INPUT_DOS_SCANS");
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FWD_INPUT_DOS");
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FWD_INPUT_DOS_IP_HDR");
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FWD_INPUT_DOS_TCP");
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FWD_INPUT_DOS_TCP_HDR");
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FWD_INPUT_DOS_TCP_PAYLOAD");
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FWD_INPUT_DOS_UDP");
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FWD_INPUT_DOS_UDP_HDR");
#endif
#ifdef CONFIG_FEATURE_IFX_IPSEC_TERMINATION
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_IPSEC_TERMINATION");
#endif
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_APP_FILTER");

	//510251:sumedh (Create additional chains for ALGs in the filter table) 
//      IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_INPUT_ALGS");
//      IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_OUTPUT_ALGS");
	// IFX_FW_SERVICES used for Services
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_DENY_SERVICES");
	// IFX_FW_SERVICES used for Services
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_DENY_LAN_IF_INPUT");
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_DENY_WAN_IP_INPUT");
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_IF_INPUT");
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_LAN_IF_INPUT");

	// IFX_FW_DISABLE used for disable firewall
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_DISABLE");
	// MAC Filter
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_MAC_FILTER_DROP");
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_MAC_FILTER_PERMIT");
	// Client Filter
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_PACKET_FILTER");
	// ATTACK Chain
	//IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_TCP_ATTACK"); //510251:sumedh Commented out
	//IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_UDP_ATTACK"); //510251:sumedh Commented out

	// Drop some ICMP packet
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_ICMP");
#if 0
	sprintf(command,
		"/usr/sbin/iptables -A IFX_FW_ICMP -p ICMP --icmp-type 0 -j ACCEPT");
	ifx_run_command(command);
	sprintf(command,
		"/usr/sbin/iptables -A IFX_FW_ICMP -p ICMP --icmp-type 8 -j ACCEPT");
	ifx_run_command(command);
	sprintf(command,
		"/usr/sbin/iptables -A IFX_FW_ICMP -p ICMP --icmp-type 11 -j ACCEPT");
	ifx_run_command(command);
	sprintf(command, "/usr/sbin/iptables -A IFX_FW_ICMP -p ICMP -j DROP");
	ifx_run_command(command);
#else
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_ICMP", "ICMP", "--icmp-type",
			  "0", "ACCEPT");
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_ICMP", "ICMP", "--icmp-type",
			  "3", "ACCEPT");
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_ICMP", "ICMP", "--icmp-type",
			  "8", "ACCEPT");
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_ICMP", "ICMP", "--icmp-type",
			  "11", "ACCEPT");
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_ICMP", "ICMP", "", "", "DROP");
#endif

	// Drop some ICMP packet
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_ICMP_WAN_RESPONSE");
	// Drop some ICMP packet
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_ICMP_FORWARD");
	// used for Enable ALG packet forwarding
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_ALGS");
	// used for Enable Port Mapping packet forwarding
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_DNAT_PM");
	// used for Enable Virtual Server packet forwarding
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_DNAT_VS");
	// used for Enable DMZ packet forwarding
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_DMZ");
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_ACCEPT_LAN_IF_INPUT");
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_ACCEPT_LAN_IF_OUTPUT");
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_ACCEPT_WAN_IP_INPUT");
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_ACCEPT_WAN_IF_OUTPUT");
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_ACCEPT_SERVICES");
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_SERVICES_ACL");
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_APPS_TO_LAN_INPUT");
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_APPS_TO_LAN_OUTPUT");
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_ACCEPT_LAN_IP_INPUT");
	IFX_IPT_CREATE_SINGLE_CHAIN(FIREWALL, "IFX_FW_ACCEPT_LAN_IP_OUTPUT");

#if 0
	sprintf(command,
		"/usr/sbin/iptables -A IFX_FW_LAN_IF_INPUT -p ALL -j IFX_FW_MAC_FILTER_DROP");
	ifx_run_command(command);

	sprintf(command,
		"/usr/sbin/iptables -A IFX_FW_LAN_IF_INPUT -p ALL -j IFX_FW_MAC_FILTER_PERMIT");
	ifx_run_command(command);
#else
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_LAN_IF_INPUT", "ALL", "", "",
			  "IFX_FW_MAC_FILTER_DROP");
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_LAN_IF_INPUT", "ALL", "", "",
			  "IFX_FW_MAC_FILTER_PERMIT");
#endif

#if 0
	// 510251:sumedh Adding references to subchains for DoS attacks
	sprintf(command,
		"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS -j IFX_FWD_INPUT_DOS_IP_HDR");
	ifx_run_command(command);
	sprintf(command,
		"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS -p tcp -j IFX_FWD_INPUT_DOS_TCP");
	ifx_run_command(command);
	sprintf(command,
		"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS -p udp -j IFX_FWD_INPUT_DOS_UDP");
	ifx_run_command(command);
	sprintf(command,
		"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_TCP -j IFX_FWD_INPUT_DOS_TCP_HDR");
	ifx_run_command(command);
	sprintf(command,
		"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_TCP -j IFX_FWD_INPUT_DOS_TCP_PAYLOAD");
	ifx_run_command(command);
	sprintf(command,
		"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_UDP -j IFX_FWD_INPUT_DOS_UDP_HDR");
	ifx_run_command(command);
#else
#ifdef IFX_DOS_ENABLE
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FWD_INPUT_DOS", "", "", "",
			  "IFX_FWD_INPUT_DOS_IP_HDR");
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FWD_INPUT_DOS", "tcp", "", "",
			  "IFX_FWD_INPUT_DOS_TCP");
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FWD_INPUT_DOS", "udp", "", "",
			  "IFX_FWD_INPUT_DOS_UDP");
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FWD_INPUT_DOS_TCP", "", "", "",
			  "IFX_FWD_INPUT_DOS_TCP_HDR");
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FWD_INPUT_DOS_TCP", "", "", "",
			  "IFX_FWD_INPUT_DOS_TCP_PAYLOAD");
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FWD_INPUT_DOS_UDP", "", "", "",
			  "IFX_FWD_INPUT_DOS_UDP_HDR");
#endif
#endif
	return 0;
}

bool IFX_INIT_INPUT_CHAIN()
{
#if 0				/* 23122006, Ritesh */
	char command[STR_COMMAND];

	// 510251:sumedh : (DoS Scans)
	sprintf(command,
		"/usr/sbin/iptables -I INPUT 1 -j IFX_FWD_INPUT_DOS_SCANS");
	ifx_run_command(command);
	sprintf(command,
		"/usr/sbin/iptables -A INPUT -p ALL -j IFX_FW_DENY_SERVICES");
	ifx_run_command(command);

	sprintf(command,
		"/usr/sbin/iptables -A INPUT -p ALL -j IFX_FW_ACCEPT_SERVICES");
	ifx_run_command(command);

	sprintf(command,
		"/usr/sbin/iptables -A INPUT -p ALL -j IFX_FW_DISABLE");
	ifx_run_command(command);
	// 510251:sumedh : (DoS main subchain) 
	sprintf(command, "/usr/sbin/iptables -A INPUT -j IFX_FWD_INPUT_DOS");
	ifx_run_command(command);

	//604181:Sumedh - commented out (parental control--device should always be accessible)
	//sprintf(command,"/usr/sbin/iptables -A INPUT -p ALL -j IFX_FW_IF_INPUT");
	ifx_run_command(command);
#if 0
	sprintf(command,
		"/usr/sbin/iptables -A IFX_FW_LAN_IF_INPUT -p ALL -j IFX_FW_MAC_FILTER_DROP");
	ifx_run_command(command);

	sprintf(command,
		"/usr/sbin/iptables -A IFX_FW_LAN_IF_INPUT -p ALL -j IFX_FW_MAC_FILTER_PERMIT");
	ifx_run_command(command);
#endif

	sprintf(command,
		"/usr/sbin/iptables -A INPUT -p ALL -j IFX_FW_PACKET_FILTER");
	ifx_run_command(command);

	//sprintf(command,"/usr/sbin/iptables -A INPUT -p TCP -j IFX_FW_TCP_ATTACK");
	//ifx_run_command(command);

	//sprintf(command,"/usr/sbin/iptables -A INPUT -p UDP -j IFX_FW_UDP_ATTACK");
	//ifx_run_command(command);

	sprintf(command,
		"/usr/sbin/iptables -A INPUT -p ICMP -j IFX_FW_ICMP_WAN_RESPONSE");
	ifx_run_command(command);

	sprintf(command, "/usr/sbin/iptables -A INPUT -p ICMP -j IFX_FW_ICMP");
	ifx_run_command(command);

	// 510251:sumedh : (ALGs)
	sprintf(command,
		"/usr/sbin/iptables -A INPUT -p ALL -j IFX_INPUT_ALGS");
	ifx_run_command(command);

	//ACCPET all From LAN Interface 
	sprintf(command,
		"/usr/sbin/iptables -A INPUT -p ALL -j IFX_FW_ACCEPT_LAN_IF_INPUT");
	ifx_run_command(command);

	sprintf(command,
		"iptables -A INPUT -p ALL -m state --state ESTABLISHED,RELATED -j ACCEPT");
	ifx_run_command(command);

	sprintf(command,
		"/usr/sbin/iptables -A INPUT -p ALL -j IFX_FW_APPS_TO_LAN_INPUT");
	ifx_run_command(command);

	// Logging rule
	//$IPTABLES -A INPUT -m limit --limit 3/minute --limit-burst 3 -j LOG --log-level DEBUG --log-prefix "IPT INPUT packet died: "
#if 0
	sprintf(command,
		"iptables -A INPUT -m limit --limit 3/minute --limit-burst 3 -j LOG --log-level DEBUG --log-prefix \"IPT INPUT packet died: \"");
	ifx_run_command(command);
#endif

#else				/* ][ reduce footprint */
	// 510251:sumedh : (DoS Scans)
#ifdef IFX_DOS_ENABLE
	IFX_IPT_SET_RULE2(FIREWALL, INSERT, "INPUT", "", "1", "",
			  "IFX_FWD_INPUT_DOS_SCANS");
#endif
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "INPUT", "ALL", "", "",
			  "IFX_FW_DENY_SERVICES");

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "INPUT", "ALL", "", "",
			  "IFX_FW_ACCEPT_SERVICES");

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "INPUT", "ALL", "", "",
			  "IFX_FW_DISABLE");
#ifdef IFX_DOS_ENABLE
	// 510251:sumedh : (DoS main subchain) 
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "INPUT", "", "", "",
			  "IFX_FWD_INPUT_DOS");
#endif

	//604181:Sumedh - commented out (parental control--device should always be accessible)
#if 0
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "INPUT", "ALL", "", "",
			  "IFX_FW_IF_INPUT");
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_LAN_IF_INPUT", "ALL", "", "",
			  "IFX_FW_MAC_FILTER_DROP");

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_LAN_IF_INPUT", "ALL", "", "",
			  "IFX_FW_MAC_FILTER_PERMIT");
#endif

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "INPUT", "ALL", "", "",
			  "IFX_FW_PACKET_FILTER");

#if 0
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "INPUT", "tcp", "", "",
			  "IFX_FW_TCP_ATTACK");

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "INPUT", "udp", "", "",
			  "IFX_FW_UDP_ATTACK");
#endif

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "INPUT", "icmp", "", "",
			  "IFX_FW_ICMP_WAN_RESPONSE");

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "INPUT", "icmp", "", "",
			  "IFX_FW_ICMP");

	// 510251:sumedh : (ALGs)
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "INPUT", "ALL", "", "",
			  "IFX_INPUT_ALGS");

	//ACCPET all From LAN Interface 
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "INPUT", "ALL", "", "",
			  "IFX_FW_ACCEPT_LAN_IF_INPUT");

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "INPUT", "ALL", "-m state",
			  "--state ESTABLISHED,RELATED", "ACCEPT");

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "INPUT", "ALL", "", "",
			  "IFX_FW_APPS_TO_LAN_INPUT");

#ifdef CONFIG_FEATURE_IFX_IPSEC_TERMINATION
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "INPUT", "ALL", "", "",
			  "IFX_IPSEC_TERMINATION");
#endif

	IFX_IPT_SET_RULE2(FIREWALL, INSERT, "INPUT", "udp", "--dport 67", "",
			  "ACCEPT");
	// Logging rule
	//$IPTABLES -A INPUT -m limit --limit 3/minute --limit-burst 3 -j LOG --log-level DEBUG --log-prefix "IPT INPUT packet died: "
#if 0
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "INPUT", "",
			  "-m limit --limit 3/minute --limit-burst 3",
			  "--log-level DEBUG --log-prefix \"IPT INPUT packet died: \"",
			  "LOG");
#endif

#endif				/* ] */
	return 0;
}

bool IFX_INIT_FORWARD_CHAIN()
{
#if 0				/* 23122006, Ritesh */
	char command[STR_COMMAND];
	// 510251:sumedh : (DoS Scans)
	sprintf(command,
		"/usr/sbin/iptables -I FORWARD 1 -j IFX_FWD_INPUT_DOS_SCANS");
	ifx_run_command(command);

	// Set Default Policy to DROP packet

	sprintf(command,
		"/usr/sbin/iptables -A FORWARD -p ALL -j IFX_FW_DISABLE");
	ifx_run_command(command);
	// 510251:sumedh : (DoS main subchain)
	sprintf(command, "/usr/sbin/iptables -A FORWARD -j IFX_FWD_INPUT_DOS");
	ifx_run_command(command);

	sprintf(command,
		"/usr/sbin/iptables -A FORWARD -p ALL -j IFX_FW_IF_INPUT");
	ifx_run_command(command);
#if 0
	sprintf(command,
		"/usr/sbin/iptables -A FORWARD -p ALL -j IFX_FW_MAC_FILTER_DROP");
	ifx_run_command(command);

	sprintf(command,
		"/usr/sbin/iptables -A FORWARD -p ALL -j IFX_FW_MAC_FILTER_PERMIT");
	ifx_run_command(command);
#endif

	sprintf(command,
		"/usr/sbin/iptables -A FORWARD -j IFX_FW_PACKET_FILTER");
	ifx_run_command(command);

	//sprintf(command,"/usr/sbin/iptables -A FORWARD -p TCP -j IFX_FW_TCP_ATTACK");//510251:sumedh : commented out
//    ifx_run_command(command);

//    sprintf(command,"/usr/sbin/iptables -A FORWARD -p UDP -j IFX_FW_UDP_ATTACK");//510251: sumedh : commented out
//    ifx_run_command(command);

	sprintf(command,
		"/usr/sbin/iptables -A FORWARD -p ICMP -j IFX_FW_ICMP_FORWARD");
	ifx_run_command(command);

	sprintf(command,
		"/usr/sbin/iptables -A FORWARD -p ICMP -j IFX_FW_ICMP");
	ifx_run_command(command);

	// 510251:sumedh : (ALGs)
	sprintf(command, "/usr/sbin/iptables -A FORWARD -p ALL -j IFX_FW_ALGS");
	ifx_run_command(command);

	sprintf(command, "/usr/sbin/iptables -A FORWARD -j IFX_FW_DNAT_VS");
	ifx_run_command(command);

	sprintf(command, "/usr/sbin/iptables -A FORWARD -j IFX_FW_DNAT_PM");
	ifx_run_command(command);

	sprintf(command, "/usr/sbin/iptables -A FORWARD -j IFX_FW_DMZ");
	ifx_run_command(command);

	sprintf(command,
		"/usr/sbin/iptables -A FORWARD -p ALL -j IFX_FW_ACCEPT_LAN_IF_INPUT");
	ifx_run_command(command);

	sprintf(command,
		"/usr/sbin/iptables -A FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT");
	ifx_run_command(command);

#if 0
	//$IPTABLES -A FORWARD -m limit --limit 3/minute --limit-burst 3 -j LOG --log-level DEBUG --log-prefix "IPT FORWARD packet died: "    
	sprintf(command,
		"iptables -A FORWARD -m limit --limit 3/minute --limit-burst 3 -j LOG --log-level DEBUG --log-prefix \"IPT FORWARD packet died: \"");
	ifx_run_command(command);
#endif

#else				/* ][ reduce footprint */

#ifdef IFX_DOS_ENABLE
	// 510251:sumedh : (DoS Scans)
	IFX_IPT_SET_RULE2(FIREWALL, INSERT, "FORWARD", "1", "", "",
			  "IFX_FWD_INPUT_DOS_SCANS");
#endif

	// Set Default Policy to DROP packet
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "FORWARD", "ALL", "", "",
			  "IFX_FW_DISABLE");
#ifdef IFX_DOS_ENABLE
	// 510251:sumedh : (DoS main subchain)
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "FORWARD", "", "", "",
			  "IFX_FWD_INPUT_DOS");
#endif
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "FORWARD", "", "", "",
			  "IFX_FW_APP_FILTER");

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "FORWARD", "ALL", "", "",
			  "IFX_FW_IF_INPUT");
#if 0
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "FORWARD", "ALL", "", "",
			  "IFX_FW_MAC_FILTER_DROP");

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "FORWARD", "ALL", "", "",
			  "IFX_FW_MAC_FILTER_PERMIT");
#endif

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "FORWARD", "", "", "",
			  "IFX_FW_PACKET_FILTER");

#if 0				//510251:sumedh : commented out
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "FORWARD", "tcp", "", "",
			  "IFX_FW_TCP_ATTACK");

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "FORWARD", "udp", "", "",
			  "IFX_FW_UDP_ATTACK");
#endif

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "FORWARD", "icmp", "", "",
			  "IFX_FW_ICMP_FORWARD");

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "FORWARD", "icmp", "", "",
			  "IFX_FW_ICMP");

	// 510251:sumedh : (ALGs)
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "FORWARD", "ALL", "", "",
			  "IFX_FW_ALGS");

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "FORWARD", "ALL", "", "",
			  "IFX_FW_DNAT_VS");

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "FORWARD", "", "", "",
			  "IFX_FW_DNAT_PM");

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "FORWARD", "", "", "", "IFX_FW_DMZ");

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "FORWARD", "ALL", "", "",
			  "IFX_FW_ACCEPT_LAN_IF_INPUT");

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "FORWARD", "", "-m state",
			  "--state ESTABLISHED,RELATED", "ACCEPT");

#if 0
	//$IPTABLES -A FORWARD -m limit --limit 3/minute --limit-burst 3 -j LOG --log-level DEBUG --log-prefix "IPT FORWARD packet died: "    
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "FORWARD", "",
			  "-m limit --limit 3/minute --limit-burst 3",
			  "--log-level DEBUG --log-prefix \"IPT FORWARD packet died: \"",
			  "IFX_FW_DENY_SERVICES");
#endif

#endif				/* ] */
	return 0;
}

bool IFX_INIT_OUTPUT_CHAIN()
{
#if 0				/* [ 23122006, Ritesh */
	char command[STR_COMMAND];
	// Set Default Policy to DROP packet

	sprintf(command,
		"/usr/sbin/iptables -A OUTPUT -p ALL -j IFX_FW_DISABLE");
	ifx_run_command(command);

	sprintf(command,
		"/usr/sbin/iptables -A OUTPUT -p ALL -j IFX_FW_ACCEPT_LAN_IF_OUTPUT");
	ifx_run_command(command);

	sprintf(command,
		"/usr/sbin/iptables -A OUTPUT -p ALL -j IFX_FW_APPS_TO_LAN_OUTPUT");
	ifx_run_command(command);

	sprintf(command,
		"/usr/sbin/iptables -A OUTPUT -p ALL -j IFX_FW_ACCEPT_WAN_IF_OUTPUT");
	ifx_run_command(command);

	sprintf(command,
		"/usr/sbin/iptables -A OUTPUT -p ICMP -j IFX_FW_ICMP_WAN_RESPONSE");
	ifx_run_command(command);

	sprintf(command, "/usr/sbin/iptables -A OUTPUT -p ICMP -j IFX_FW_ICMP");
	ifx_run_command(command);

	// 510251:sumedh : (ALGs)
	sprintf(command,
		"/usr/sbin/iptables -A OUTPUT -p ALL -j IFX_OUTPUT_ALGS");
	ifx_run_command(command);

	// 510251:sumedh : (ALGs)
	sprintf(command,
		"/usr/sbin/iptables -A OUTPUT -p ALL -j IFX_OUTPUT_ALGS");
	ifx_run_command(command);

	// Logging rule 
	//$IPTABLES -A OUTPUT -m limit --limit 3/minute --limit-burst 3 -j LOG --log-level DEBUG --log-prefix "IPT OUTPUT packet died: "
#if 0
	sprintf(command,
		"iptables -A OUTPUT -m limit --limit 3/minute --limit-burst 3 -j LOG --log-level DEBUG --log-prefix \"IPT OUTPUT packet died: \"");
	ifx_run_command(command);
#endif
#else				/* ][ */
	// Set Default Policy to DROP packet
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "OUTPUT", "ALL", "", "",
			  "IFX_FW_DISABLE");

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "OUTPUT", "ALL", "", "",
			  "IFX_FW_ACCEPT_LAN_IF_OUTPUT");

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "OUTPUT", "ALL", "", "",
			  "IFX_FW_APPS_TO_LAN_OUTPUT");

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "OUTPUT", "ALL", "", "",
			  "IFX_FW_ACCEPT_WAN_IF_OUTPUT");

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "OUTPUT", "icmp", "", "",
			  "IFX_FW_ICMP_WAN_RESPONSE");

	IFX_IPT_SET_RULE2(FIREWALL, ADD, "OUTPUT", "icmp", "", "",
			  "IFX_FW_ICMP");

	// 510251:sumedh : (ALGs)
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "OUTPUT", "ALL", "", "",
			  "IFX_OUTPUT_ALGS");

	// 510251:sumedh : (ALGs)
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "OUTPUT", "ALL", "", "",
			  "IFX_OUTPUT_ALGS");

	// Logging rule 
#if 0
	//$IPTABLES -A OUTPUT -m limit --limit 3/minute --limit-burst 3 -j LOG --log-level DEBUG --log-prefix "IPT OUTPUT packet died: "
	IFX_IPT_SET_RULE2(FIREWALL, ADD, "OUTPUT", "",
			  "-m limit --limit 3/minute --limit-burst 3",
			  "--log-level DEBUG --log-prefix \"IPT OUTPUT packet died: \"",
			  "LOG");
#endif
#endif				/* ] */
	return 0;
}

bool IFX_FIREWALL_SET_LAN(int operation, char *IFNAME, __u32 IPADDR)
{
#if 0
	char command[STR_COMMAND];
#endif
	struct in_addr addr_tmp;
	addr_tmp.s_addr = IPADDR;

	if (IPADDR == 0xFFFFFFFF || IPADDR == 0)
		return 1;

	switch (operation) {
	case ADD:
#if 0				/* [ 23122006, Ritesh */
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FW_IF_INPUT -p ALL -i %s -j IFX_FW_LAN_IF_INPUT",
			IFNAME);
		ifx_run_command(command);

		sprintf(command,
			"/usr/sbin/iptables -A IFX_FW_ACCEPT_LAN_IF_INPUT -p ALL -i %s -j ACCEPT",
			IFNAME);
		ifx_run_command(command);
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FW_ACCEPT_LAN_IF_OUTPUT -p ALL -o %s -j ACCEPT",
			IFNAME);
		ifx_run_command(command);

		sprintf(command,
			"/usr/sbin/iptables -A IFX_FW_DENY_LAN_IF_INPUT -p ALL -i %s -j DROP",
			IFNAME);
		ifx_run_command(command);
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FW_ACCEPT_LAN_IP_INPUT -p ALL -d %s -j IFX_FW_SERVICES_ACL",
			inet_ntoa(addr_tmp));
		ifx_run_command(command);
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FW_ACCEPT_LAN_IP_OUTPUT -p ALL -s %s -j ACCEPT",
			inet_ntoa(addr_tmp));
		ifx_run_command(command);
#else				/* ][ */
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_IF_INPUT", "ALL", "-i",
				  IFNAME, "IFX_FW_LAN_IF_INPUT");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_ACCEPT_LAN_IF_INPUT", "ALL", "-i", IFNAME, "ACCEPT");	/* ? ? */
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_ACCEPT_LAN_IF_OUTPUT",
				  "ALL", "-o", IFNAME, "ACCEPT");

		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_DENY_LAN_IF_INPUT",
				  "ALL", "-i", IFNAME, "DROP");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_ACCEPT_LAN_IP_INPUT",
				  "ALL", "-d", inet_ntoa(addr_tmp),
				  "IFX_FW_SERVICES_ACL");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_ACCEPT_LAN_IP_OUTPUT",
				  "ALL", "-s", inet_ntoa(addr_tmp), "ACCEPT");
#endif				/* ] */
		break;
	case DELETE:
#if 0				/* [ 23122006, Ritesh */
		sprintf(command,
			"/usr/sbin/iptables -D IFX_FW_IF_INPUT -p ALL -i %s -j IFX_FW_LAN_IF_INPUT",
			IFNAME);
		ifx_run_command(command);
		sprintf(command,
			"/usr/sbin/iptables -D IFX_FW_ACCEPT_LAN_IF_INPUT -p ALL -i %s -j ACCEPT",
			IFNAME);
		ifx_run_command(command);
		sprintf(command,
			"/usr/sbin/iptables -D IFX_FW_ACCEPT_LAN_IF_OUTPUT -p ALL -o %s -j ACCEPT",
			IFNAME);
		ifx_run_command(command);
		sprintf(command,
			"/usr/sbin/iptables -D IFX_FW_DENY_LAN_IF_INPUT -p ALL -i %s -j DROP",
			IFNAME);
		ifx_run_command(command);
		sprintf(command,
			"/usr/sbin/iptables -D IFX_FW_ACCEPT_LAN_IP_INPUT -p ALL -d %s -j IFX_FW_SERVICES_ACL",
			inet_ntoa(addr_tmp));
		ifx_run_command(command);
		sprintf(command,
			"/usr/sbin/iptables -D IFX_FW_ACCEPT_LAN_IP_OUTPUT -p ALL -s %s -j ACCEPT",
			inet_ntoa(addr_tmp));
		ifx_run_command(command);
#else				/* ][ */
		IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_IF_INPUT", "ALL",
				  "-i", IFNAME, "IFX_FW_LAN_IF_INPUT");
		IFX_IPT_SET_RULE2(FIREWALL, DELETE,
				  "IFX_FW_ACCEPT_LAN_IF_INPUT", "ALL", "-i",
				  IFNAME, "ACCEPT");
		IFX_IPT_SET_RULE2(FIREWALL, DELETE,
				  "IFX_FW_ACCEPT_LAN_IF_OUTPUT", "ALL", "-o",
				  IFNAME, "ACCEPT");
		IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_DENY_LAN_IF_INPUT",
				  "ALL", "-i", IFNAME, "DROP");
		IFX_IPT_SET_RULE2(FIREWALL, DELETE,
				  "IFX_FW_ACCEPT_LAN_IP_INPUT", "ALL", "-d",
				  inet_ntoa(addr_tmp), "IFX_FW_SERVICES_ACL");
		IFX_IPT_SET_RULE2(FIREWALL, DELETE,
				  "IFX_FW_ACCEPT_LAN_IP_OUTPUT", "ALL", "-s",
				  inet_ntoa(addr_tmp), "ACCEPT");
#endif				/* ] */
		break;
	case DELETE_ALL:
		IFX_IPT_FLUSH_CHAIN(FIREWALL, "IFX_FW_ACCEPT_LAN_IF_INPUT");
		IFX_IPT_FLUSH_CHAIN(FIREWALL, "IFX_FW_ACCEPT_LAN_IF_OUTPUT");
		IFX_IPT_FLUSH_CHAIN(FIREWALL, "IFX_FW_DENY_LAN_IF_INPUT");
		IFX_IPT_FLUSH_CHAIN(FIREWALL, "IFX_FW_ACCEPT_LAN_IP_INPUT");
		IFX_IPT_FLUSH_CHAIN(FIREWALL, "IFX_FW_ACCEPT_LAN_IP_OUTPUT");
		break;
	default:
		return 1;
		break;
	}
	return 0;
}

bool IFX_FIREWALL_SET_WAN_IF(int operation, char *IFNAME)
{
#if 0
	char command[STR_COMMAND];
#endif
	switch (operation) {
#if 0				/* [ 23122006, Ritesh */
	case ADD:
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FW_ACCEPT_WAN_IF_OUTPUT -p ALL -o %s -j ACCEPT",
			IFNAME);
		ifx_run_command(command);
		break;
	case DELETE:
		sprintf(command,
			"/usr/sbin/iptables -D IFX_FW_ACCEPT_WAN_IF_OUTPUT -p ALL -o %s -j ACCEPT",
			IFNAME);
		ifx_run_command(command);
		break;
#else				/* ][ */
	case ADD:
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_ACCEPT_WAN_IF_OUTPUT",
				  "ALL", "-o", IFNAME, "ACCEPT");
		break;
	case DELETE:
		IFX_IPT_SET_RULE2(FIREWALL, DELETE,
				  "IFX_FW_ACCEPT_WAN_IF_OUTPUT", "ALL", "-o",
				  IFNAME, "ACCEPT");
		break;
#endif				/* ] */
	case DELETE_ALL:
		IFX_IPT_FLUSH_CHAIN(FIREWALL, "IFX_FW_ACCEPT_WAN_IF_OUTPUT");
		break;
	default:
		return 1;
		break;
	}
	return 0;
}

bool IFX_FIREWALL_SET_WAN_IP(int operation, __u32 IPADDR)
{
#if 0
	char command[STR_COMMAND];
#endif
	struct in_addr addr_tmp;
	if (IPADDR == 0xFFFFFFFF || IPADDR == 0)
		return 1;
	addr_tmp.s_addr = IPADDR;
	switch (operation) {
#if 0				/* [ 23122006, Ritesh */
	case ADD:
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FW_ACCEPT_WAN_IP_INPUT -p ALL -d %s -j ACCEPT",
			inet_ntoa(addr_tmp));
		ifx_run_command(command);
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FW_DENY_WAN_IP_INPUT -p ALL -d %s -j DROP",
			inet_ntoa(addr_tmp));
		ifx_run_command(command);
		break;
	case DELETE:
		sprintf(command,
			"/usr/sbin/iptables -D IFX_FW_ACCEPT_WAN_IP_INPUT -p ALL -d %s -j ACCEPT",
			inet_ntoa(addr_tmp));
		ifx_run_command(command);
		sprintf(command,
			"/usr/sbin/iptables -D IFX_FW_DENY_WAN_IP_INPUT -p ALL -d %s -j DROP",
			inet_ntoa(addr_tmp));
		ifx_run_command(command);
		break;
#else				/* ][ */
	case ADD:
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_ACCEPT_WAN_IP_INPUT",
				  "ALL", "-d", inet_ntoa(addr_tmp), "ACCEPT");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_DENY_WAN_IP_INPUT",
				  "ALL", "-d", inet_ntoa(addr_tmp), "DROP");
		break;
	case DELETE:
		IFX_IPT_SET_RULE2(FIREWALL, DELETE,
				  "IFX_FW_ACCEPT_WAN_IP_INPUT", "ALL", "-d",
				  inet_ntoa(addr_tmp), "ACCEPT");
		IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_DENY_WAN_IP_INPUT",
				  "ALL", "-d", inet_ntoa(addr_tmp), "DROP");
		break;

#endif				/* ] */
	case DELETE_ALL:
		IFX_IPT_FLUSH_CHAIN(FIREWALL, "IFX_FW_ACCEPT_WAN_IP_INPUT");
		IFX_IPT_FLUSH_CHAIN(FIREWALL, "IFX_FW_DENY_WAN_IP_INPUT");
		break;
	default:
		return 1;
		break;
	}
	return 0;
}

bool IFX_CLEAN_FIREWALL()
{
#if 0
	char command[STR_COMMAND];
#endif
	// Set Default Policy to DROP packet
	IFX_IPT_FLUSH_CHAIN(FIREWALL, "INPUT");

	IFX_IPT_FLUSH_CHAIN(FIREWALL, "OUTPUT");

	IFX_IPT_FLUSH_CHAIN(FIREWALL, "FORWARD");

	IFX_IPT_FLUSH_CHAIN(FIREWALL, " ");

#if 0				/* [ 23122006, Ritesh */
	sprintf(command, "%s -X", "/usr/sbin/iptables");
	ifx_run_command(command);
	sprintf(command, "/usr/sbin/iptables -P INPUT ACCEPT");
	ifx_run_command(command);
	sprintf(command, "/usr/sbin/iptables -P OUTPUT ACCEPT");
	ifx_run_command(command);
	sprintf(command, "/usr/sbin/iptables -P FORWARD ACCEPT");
	ifx_run_command(command);
#else				/* ][ */

	IFX_IPT_SET_RULE2(FIREWALL, POLICY, "INPUT", "", "", "", "ACCEPT");
	IFX_IPT_SET_RULE2(FIREWALL, POLICY, "OUTPUT", "", "", "", "ACCEPT");
	IFX_IPT_SET_RULE2(FIREWALL, POLICY, "FORWARD", "", "", "", "ACCEPT");
#endif				/* ] */
	return 0;
}

bool IFXSetFirewallEnable(int operation, bool * pbIFX_SET_Enable)
{
#if 0
	char command[STR_COMMAND];
#endif
	bool bEnable = 0;
	bool ret = 0;

	switch (operation) {
	case GET:
		ret =
		    IFX_IPT_GET_RULE_STATUS(FIREWALL, GET_CHAIN_STATUS,
					    "IFX_FW_DISABLE", &bEnable, NULL,
					    0);
		if (ret == 0) {
			if (bEnable == FALSE) {
				*pbIFX_SET_Enable = TRUE;
			} else {
				*pbIFX_SET_Enable = FALSE;
			}
		}
		break;
	case SET:
		switch (*pbIFX_SET_Enable) {
		case FALSE:
#if 0				/* [ 23122006, Ritesh */
			sprintf(command,
				"/usr/sbin/iptables -A IFX_FW_DISABLE -p ALL -j ACCEPT");
			ifx_run_command(command);
#else				/* ][ */
			IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_DISABLE",
					  "ALL", "", "", "ACCEPT");
#endif				/* ] */
			break;
		case TRUE:
			ret = IFXSetFirewallEnable(GET, &bEnable);
			if (ret == 0 && bEnable == FALSE) {
#if 0				/* [ 23122006, Ritesh */
				sprintf(command,
					"/usr/sbin/iptables -D IFX_FW_DISABLE -p ALL -j ACCEPT");
				ifx_run_command(command);
#else				/* ][ */
				IFX_IPT_SET_RULE2(FIREWALL, DELETE,
						  "IFX_FW_DISABLE", "ALL", "",
						  "", "ACCEPT");
#endif				/* ] */
			}
			break;
		default:
			return 1;
		}
		break;
	}

	return ret;
}

bool IFX_FIREWALL_INIT()
{
	bool bEnable = FALSE;
	int outFlag = 0;
	char sValue[64];
#if 0
	char command[STR_COMMAND];
#endif

	IFX_CLEAN_FIREWALL();

	// Create Chains
	IFX_CREATE_FW_CHAINS();

	// Init Chains
	IFX_INIT_INPUT_CHAIN();
	IFX_INIT_FORWARD_CHAIN();
	IFX_INIT_OUTPUT_CHAIN();

	// init FIREWALL
	memset(&sValue, 0, sizeof(sValue));
	if (ifx_GetObjData(FILE_RC_CONF, "firewall_main",
			   "firewall_main_enable",
			   IFX_F_GET_ANY, (IFX_OUT uint32 *) & outFlag,
			   sValue) != IFX_SUCCESS) {
		IFX_DBG
		    ("In function [%s]: Failed to get initialize Firewall Chain !!\n",
		     __FUNCTION__);
		return 1;
	}

	if (!atoi(sValue)) {
		IFXSetFirewallEnable(SET, &bEnable);
	}
	// Set Default Policy to DROP packet
#if 0				/* [ 23122006, Ritesh */
	sprintf(command, "/usr/sbin/iptables -P INPUT DROP");
	ifx_run_command(command);
	sprintf(command, "/usr/sbin/iptables -P OUTPUT DROP");
	ifx_run_command(command);
	sprintf(command, "/usr/sbin/iptables -P FORWARD DROP");
	ifx_run_command(command);
#else				/* ][ */
	IFX_IPT_SET_RULE2(FIREWALL, POLICY, "INPUT", "", "", "", "DROP");
	IFX_IPT_SET_RULE2(FIREWALL, POLICY, "OUTPUT", "", "", "", "DROP");
	IFX_IPT_SET_RULE2(FIREWALL, POLICY, "FORWARD", "", "", "", "DROP");
#endif				/* ] */

	IFXSetFirewallMacFilterEnable(SET, &bEnable);

	memset(&sValue, 0, sizeof(sValue));
	if (ifx_GetObjData(FILE_RC_CONF, "firewall_packetfilter_status",
			   "firewall_packetfilter_status_enable",
			   IFX_F_GET_ANY, (IFX_OUT uint32 *) & outFlag,
			   sValue) != IFX_SUCCESS) {
		IFX_DBG
		    ("In function [%s]: Failed to get initialize Firewall packetfilter Chain !!\n",
		     __FUNCTION__);
		return 1;
	}

	if (!atoi(sValue)) {
		IFXSetFirewallPacketFilterEnable(SET, &bEnable);
	}

	return 0;
}

bool IFXSetAppFilter(int bEnable)
{
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "", "", "",
			  "RETURN");
	if (bEnable == 0) {
		IFX_IPT_SET_RULE2(FIREWALL, INSERT, "IFX_FW_APP_FILTER", "", "",
				  "", "RETURN");
	}
	return 0;
}

bool IFXSetAppFilterMsn(int bEnable)
{
	//Block TCP: 1863, 6891-6901.   UDP: 1503, 3389, 6901
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp",
			  "--dport 1863", "", "REJECT --reject-with tcp-reset");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp",
			  "--dport 6891:6901", "",
			  "REJECT --reject-with tcp-reset");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "udp",
			  "--dport 6891:6901", "", "DROP");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp",
			  "-d 64.4.9.254", "",
			  "REJECT --reject-with tcp-reset");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp",
			  "-d 64.4.50.62", "",
			  "REJECT --reject-with tcp-reset");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp",
			  "-d 64.4.13.190", "",
			  "REJECT --reject-with tcp-reset");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp",
			  "-d 64.4.9.190", "",
			  "REJECT --reject-with tcp-reset");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp",
			  "-d messenger.hotmail.com", "",
			  "REJECT --reject-with tcp-reset");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp",
			  "-d gateway.messenger.hotmail.com", "",
			  "REJECT --reject-with tcp-reset");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp",
			  "-d gw.msnmessenger.akadns.net", "",
			  "REJECT --reject-with tcp-reset");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp",
			  "-d gateway.messenger.hotmail.geo.msnmessenger.msn.com.akadns.net",
			  "", "REJECT --reject-with tcp-reset");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp",
			  "-d messenger.hotmail.geo.msnmessenger.msn.com.akadns.net",
			  "", "REJECT --reject-with tcp-reset");
	if (bEnable) {
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "--dport 1863", "",
				  "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "--dport 6891:6901", "",
				  "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "udp",
				  "--dport 6891:6901", "", "DROP");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "-d 64.4.9.254", "",
				  "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "-d 64.4.50.62", "",
				  "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "-d 64.4.13.190", "",
				  "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "-d 64.4.9.190", "",
				  "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "-d messenger.hotmail.com", "",
				  "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "-d gateway.messenger.hotmail.com", "",
				  "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "-d gw.msnmessenger.akadns.net", "",
				  "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "-d gateway.messenger.hotmail.geo.msnmessenger.msn.com.akadns.net",
				  "", "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "-d messenger.hotmail.geo.msnmessenger.msn.com.akadns.net",
				  "", "REJECT --reject-with tcp-reset");
	}
	return 0;
}

bool IFXSetAppFilterYahoo(int bEnable)
{
	//Block TCP/UDP : 5050 (5150, 8000)
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp",
			  "--dport 5050", "", "REJECT --reject-with tcp-reset");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "udp",
			  "--dport 5050", "", "DROP");
	//IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp", "-d cs23.msg.dcn.yahoo.com", "", "REJECT --reject-with tcp-reset");
	//IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp", "-d cs49.msg.dcn.yahoo.com", "", "REJECT --reject-with tcp-reset");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp",
			  "-d scsd.msg.yahoo.com", "",
			  "REJECT --reject-with tcp-reset");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp",
			  "-d scse.msg.yahoo.com", "",
			  "REJECT --reject-with tcp-reset");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp",
			  "-d scsf.msg.yahoo.com", "",
			  "REJECT --reject-with tcp-reset");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp",
			  "-d scs.msg.yahoo.com", "",
			  "REJECT --reject-with tcp-reset");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp",
			  "-d 76.13.15.56", "",
			  "REJECT --reject-with tcp-reset");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp",
			  "-d 76.13.15.57", "",
			  "REJECT --reject-with tcp-reset");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp",
			  "-d 68.180.217.33", "",
			  "REJECT --reject-with tcp-reset");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp",
			  "-d 68.180.217.34", "",
			  "REJECT --reject-with tcp-reset");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp","-d 68.180.217.15", "","REJECT --reject-with tcp-reset");

	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp","-d 67.195.186.241", "","REJECT --reject-with tcp-reset");

	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp","-d 76.13.15.38", "","REJECT --reject-with tcp-reset");

	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FW_APP_FILTER", "tcp","-d 98.136.48.32", "","REJECT --reject-with tcp-reset");

	if (bEnable) {
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "--dport 5050", "",
				  "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "udp",
				  "--dport 5050", "", "DROP");
		//IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp", "-d cs23.msg.dcn.yahoo.com", "", "REJECT --reject-with tcp-reset");
		//IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp", "-d cs49.msg.dcn.yahoo.com", "", "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "-d scsd.msg.yahoo.com", "",
				  "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "-d scse.msg.yahoo.com", "",
				  "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "-d scsf.msg.yahoo.com", "",
				  "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "-d scs.msg.yahoo.com", "",
				  "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "-d 76.13.15.56", "",
				  "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "-d 76.13.15.57", "",
				  "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "-d 68.180.217.33", "",
				  "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "-d 68.180.217.34", "",
				  "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "-d 68.180.217.15", "",
				  "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "-d 67.195.186.241", "",
				  "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "-d 76.13.15.38", "",
				  "REJECT --reject-with tcp-reset");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_APP_FILTER", "tcp",
				  "-d 98.136.48.32", "",
				  "REJECT --reject-with tcp-reset");
	}
	return 0;
}

#ifdef IFX_DOS_ENABLE
//////////////////////////////
//510251:sumedh start 
//              DoS Enable/Disable
bool IFXSetDoSEnable(int pbEnable)
{
#if 0				/* [ 23122006, Ritesh */
	char command[STR_COMMAND];

	sprintf(command,
		"/usr/sbin/iptables -D IFX_FWD_INPUT_DOS -j RETURN 2> /dev/null");
	ifx_run_command(command);
	if (pbEnable == 0) {
		sprintf(command,
			"/usr/sbin/iptables -I IFX_FWD_INPUT_DOS 1 -j RETURN");
		ifx_run_command(command);
	}
#else				/* ][ */
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FWD_INPUT_DOS", "", "", "",
			  "RETURN 2> /dev/null");
	if (pbEnable == 0) {
		IFX_IPT_SET_RULE2(FIREWALL, INSERT, "IFX_FWD_INPUT_DOS", "1",
				  "", "", "RETURN");
	}
#endif				/* ] */
	return 0;
}

//              Winnuke DoS
bool IFXSetFirewallDoSWinnuke(char *old_ports, char *ports, bool * pbEnable)
{
#if 0				/* [ 23122006, Ritesh */
	char command[STR_COMMAND];

	//Delete rule
	sprintf(command,
		"/usr/sbin/iptables -D IFX_FWD_INPUT_DOS_TCP_HDR -p tcp --tcp-flags URG URG -m multiport --dports %s -j REJECT --reject-with tcp-reset 2> /dev/null",
		old_ports);
	ifx_run_command(command);

	//Add if required
	if ((*pbEnable) == TRUE) {
		// Winnuke set
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_TCP_HDR -p tcp --tcp-flags URG URG -m multiport --dports %s -j REJECT --reject-with tcp-reset",
			ports);
		ifx_run_command(command);
	}
#else				/* ][ */
	//Delete rule
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FWD_INPUT_DOS_TCP_HDR", "tcp",
			  "--tcp-flags URG URG -m multiport --dports",
			  old_ports,
			  "REJECT --reject-with tcp-reset 2> /dev/null");

	//Add if required
	if ((*pbEnable) == TRUE) {
		// Winnuke set
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FWD_INPUT_DOS_TCP_HDR",
				  "tcp",
				  "--tcp-flags URG URG -m multiport --dports",
				  old_ports, "REJECT --reject-with tcp-reset");
	}
#endif				/* ] */
	return 0;
}

//              TCP Synflood DoS
bool IFXSetFirewallDoSTcpsynflood(char *old_limit, char *old_burst, char *limit,
				  char *burst, bool * pbEnable)
{
	char command[STR_COMMAND];

#if 0				/* [ 23122006, Ritesh */
	//Delete rule
	sprintf(command,
		"/usr/sbin/iptables -D IFX_FWD_INPUT_DOS_SCANS -p tcp --tcp-flags ALL SYN -m limit ! --limit %s  --limit-burst %s -j DROP 2> /dev/null",
		old_limit, old_burst);
	ifx_run_command(command);
	//Add if required
	if ((*pbEnable) == TRUE) {
		// tcp synflood set
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_SCANS -p tcp --tcp-flags ALL SYN -m limit ! --limit %s  --limit-burst %s -j DROP",
			limit, burst);
		ifx_run_command(command);
	}
#else				/* ][ */
	//Delete rule
	sprintf(command, "%s ! %s %s %s %s", "-m limit", "--limit", old_limit,
		"--limit-burst", old_burst);
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FWD_INPUT_DOS_SCANS", "tcp",
			  "--tcp-flags ALL SYN", command, "DROP 2> /dev/null");
	//Add if required
	if ((*pbEnable) == TRUE) {
		// tcp synflood set
		sprintf(command, "%s ! %s %s %s %s", "-m limit", "--limit",
			limit, "--limit-burst", burst);
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FWD_INPUT_DOS_SCANS",
				  "tcp", "--tcp-flags ALL SYN", command,
				  "DROP 2> /dev/null");
	}
#endif				/* ] */
	return 0;
}

//              Xmas DoS
bool IFXSetFirewallDoSXmas(bool * pbEnable)
{
#if 0				/* [ 23122006, Ritesh */
	char command[STR_COMMAND];

	//delete rule
	sprintf(command,
		"/usr/sbin/iptables -D IFX_FWD_INPUT_DOS_TCP_HDR -p tcp --tcp-flags ALL ALL -j DROP 2> /dev/null");
	ifx_run_command(command);
	sprintf(command,
		"/usr/sbin/iptables -D IFX_FWD_INPUT_DOS_TCP_HDR -p tcp --tcp-flags ALL NONE -j DROP 2> /dev/null");
	ifx_run_command(command);

	//add if required
	if ((*pbEnable) == TRUE) {
		// xmas set
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_TCP_HDR -p tcp --tcp-flags ALL ALL -j DROP");
		ifx_run_command(command);
		//fprintf(stderr,"\nCOMMAND == %s\n",command);
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_TCP_HDR -p tcp --tcp-flags ALL NONE -j DROP");
		ifx_run_command(command);
		//fprintf(stderr,"\nCOMMAND == %s\n",command);
	}
#else				/* ][ */
	//delete rule
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FWD_INPUT_DOS_TCP_HDR", "tcp",
			  "--tcp-flags ALL", "ALL", "DROP 2> /dev/null");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FWD_INPUT_DOS_TCP_HDR", "tcp",
			  "--tcp-flags ALL", "NONE", "DROP 2> /dev/null");

	//add if required
	if ((*pbEnable) == TRUE) {
		// xmas set
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FWD_INPUT_DOS_TCP_HDR",
				  "tcp", "--tcp-flags ALL", "ALL", "DROP");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FWD_INPUT_DOS_TCP_HDR",
				  "tcp", "--tcp-flags ALL", "NONE", "DROP");
		//fprintf(stderr,"\nCOMMAND == %s\n",command);
	}
#endif				/* ] */
	return 0;
}

//              TCP Hijacking
bool IFXSetFirewallDoSHijacking(bool * pbEnable)
{
#if 0				/* [ 23122006, Ritesh */
	char command[STR_COMMAND];

	//delete rule
	sprintf(command,
		"/usr/sbin/iptables -D IFX_FWD_INPUT_DOS_IP_HDR -m ipv4options --ssrr -j DROP 2> /dev/null");
	ifx_run_command(command);
	sprintf(command,
		"/usr/sbin/iptables -D IFX_FWD_INPUT_DOS_IP_HDR -m ipv4options --lsrr -j DROP 2> /dev/null");
	ifx_run_command(command);

	//add if required
	if ((*pbEnable) == TRUE) {
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_IP_HDR -m ipv4options --ssrr -j DROP");
		ifx_run_command(command);
		//fprintf(stderr,"\nCOMMAND == %s\n",command);

		sprintf(command,
			"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_IP_HDR -m ipv4options --lsrr -j DROP");
		ifx_run_command(command);
		//fprintf(stderr,"\nCOMMAND == %s\n",command);

	}
#else				/* ][ */
	//delete rule
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FWD_INPUT_DOS_IP_HDR", "",
			  "-m ipv4options", "--ssrr", "DROP 2> /dev/null");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FWD_INPUT_DOS_IP_HDR", "",
			  "-m ipv4options", "--lsrr", "DROP 2> /dev/null");

	//add if required
	if ((*pbEnable) == TRUE) {
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FWD_INPUT_DOS_IP_HDR", "",
				  "-m ipv4options", "--ssrr", "DROP");
		//fprintf(stderr,"\nCOMMAND == %s\n",command);

		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FWD_INPUT_DOS_IP_HDR", "",
				  "-m ipv4options", "--lsrr", "DROP");
		//fprintf(stderr,"\nCOMMAND == %s\n",command);

	}
#endif				/* ] */
	return 0;
}

//              Yahoo Messenger DoS
bool IFXSetFirewallDoSYahoo(char *old_ports, char *ports, bool * pbEnable)
{
	char command[STR_COMMAND];

	//Delete rule
#if 0				/* [ 23122006, Ritesh */
	sprintf(command,
		"/usr/sbin/iptables -D IFX_FWD_INPUT_DOS_TCP_HDR -p tcp -m multiport --dports %s -j REJECT --reject-with icmp-port-unreachable 2> /dev/null",
		old_ports);
	ifx_run_command(command);
	//Add if required
	if ((*pbEnable) == TRUE) {
		// Yahoo DoS set
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_TCP_HDR -p tcp -m multiport --dports %s -j REJECT --reject-with icmp-port-unreachable",
			ports);
		ifx_run_command(command);
	}
#else				/* ][ */
	sprintf(command, "%s %s", "--dports", old_ports);
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FWD_INPUT_DOS_TCP_HDR", "tcp",
			  "-m multiport", command,
			  "REJECT --reject-with-icmp-port-unreachable 2> /dev/null");
	//Add if required
	if ((*pbEnable) == TRUE) {
		// Yahoo DoS set
		sprintf(command, "%s %s", "--dports", ports);
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FWD_INPUT_DOS_TCP_HDR",
				  "tcp", "-m multiport", command,
				  "REJECT --reject-with-icmp-port-unreachable");
	}
#endif				/* ] */
	return 0;
}

//              Hotsync Manager DoS     
bool IFXSetFirewallDoSHotsync(char *old_ports, char *ports, bool * pbEnable)
{
	char command[STR_COMMAND];

	//Delete rule
#if 0				/* [ 23122006, Ritesh */
	sprintf(command,
		"/usr/sbin/iptables -D IFX_FWD_INPUT_DOS_TCP_HDR -p tcp -m multiport --dports %s -j REJECT --reject-with icmp-port-unreachable 2> /dev/null",
		old_ports);
	ifx_run_command(command);
	//Add if required
	if ((*pbEnable) == TRUE) {
		// Hotsync set
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_TCP_HDR -p tcp -m multiport --dports %s -j REJECT --reject-with icmp-port-unreachable",
			ports);
		ifx_run_command(command);
	}
#else				/* ][ */
	sprintf(command,
		"/usr/sbin/iptables -D IFX_FWD_INPUT_DOS_TCP_HDR -p tcp -m multiport --dports %s -j REJECT --reject-with icmp-port-unreachable 2> /dev/null",
		old_ports);
	ifx_run_command(command);
	sprintf(command, "%s %s", "--dports", old_ports);
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FWD_INPUT_DOS_TCP_HDR", "tcp",
			  "-m multiport", command,
			  "REJECT --reject-with-icmp-port-unreachable 2> /dev/null");
	//Add if required
	if ((*pbEnable) == TRUE) {
		// Hotsync set
		sprintf(command, "%s %s", "--dports", ports);
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FWD_INPUT_DOS_TCP_HDR",
				  "tcp", "-m multiport", command,
				  "REJECT --reject-with-icmp-port-unreachable");
	}
#endif				/* ] */
	return 0;
}

//              Port Scan DoS   
bool IFXSetFirewallDoSPortscan(char *old_loport_weight, char *old_hiport_weight,
			       char *old_delay_threshold,
			       char *old_weight_threshold, char *loport_weight,
			       char *hiport_weight, char *delay_threshold,
			       char *weight_threshold, bool * pbEnable)
{
	char command[STR_COMMAND];

	//Delete rule
#if 0				/* [ 23122006, Ritesh */
	sprintf(command,
		"/usr/sbin/iptables -D IFX_FWD_INPUT_DOS_SCANS -m psd --psd-weight-threshold %s --psd-delay-threshold %s --psd-lo-ports-weight %s --psd-hi-ports-weight %s -j DROP 2> /dev/null",
		old_weight_threshold, old_delay_threshold, old_loport_weight,
		old_hiport_weight);
	ifx_run_command(command);
	//Add if required
	if ((*pbEnable) == TRUE) {
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_SCANS -m psd --psd-weight-threshold %s --psd-delay-threshold %s --psd-lo-ports-weight %s --psd-hi-ports-weight %s -j DROP",
			weight_threshold, delay_threshold, loport_weight,
			hiport_weight);
		ifx_run_command(command);
	}
#else				/* ][ */
	sprintf(command, "%s %s %s %s %s %s %s %s", "--psd-weight-threshold",
		old_weight_threshold, "--psd-delay-threshold",
		old_delay_threshold, "--psd-lo-ports-weight", old_loport_weight,
		"--psd-hi-ports-weight", old_hiport_weight);
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FWD_INPUT_DOS_SCANS", "",
			  command, "", "DROP 2> /dev/null");
	//Add if required
	if ((*pbEnable) == TRUE) {
		sprintf(command, "%s %s %s %s %s %s %s %s",
			"--psd-weight-threshold", weight_threshold,
			"--psd-delay-threshold", delay_threshold,
			"--psd-lo-ports-weight", loport_weight,
			"--psd-hi-ports-weight", hiport_weight);
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FWD_INPUT_DOS_SCANS", "",
				  command, "", "DROP");
	}
#endif				/* ] */
	return 0;
}

//              Malformed Mime  DoS     
bool IFXSetFirewallDoSMime(char *old_ports, char *ports, bool * pbEnable)
{
	char command[STR_COMMAND];

	//Delete rule
#if 0				/* [ 23122006, Ritesh */
	sprintf(command,
		"/usr/sbin/iptables -D IFX_FWD_INPUT_DOS_TCP_PAYLOAD -p tcp -m multiport --dports %s -m ifxattack --name malformed_mime -j REJECT --reject-with tcp-reset 2> /dev/null",
		old_ports);
	ifx_run_command(command);
	//Add if required
	if ((*pbEnable) == TRUE) {
		// Mime set
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_TCP_PAYLOAD -p tcp -m multiport --dports %s -m ifxattack --name malformed_mime -j REJECT --reject-with tcp-reset",
			ports);
		ifx_run_command(command);
	}
#else				/* ][ */
	sprintf(command, "%s %s %s %s %s", "--dports", old_ports,
		"-m ifxattack", "--name", "malformed_mime");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FWD_INPUT_DOS_TCP_PAYLOAD",
			  "tcp", "-m multiport", command,
			  "REJECT --reject-with tcp-reset 2> /dev/null");
	//Add if required
	if ((*pbEnable) == TRUE) {
		// Mime set
		sprintf(command, "%s %s %s %s %s", "--dports", ports,
			"-m ifxattack", "--name", "malformed_mime");
		IFX_IPT_SET_RULE2(FIREWALL, ADD,
				  "IFX_FWD_INPUT_DOS_TCP_PAYLOAD", "tcp",
				  "-m multiport", command,
				  "REJECT --reject-with tcp-reset");
	}
#endif				/* ] */
	return 0;
}

//              Code Red II DoS
bool IFXSetFirewallDoSCodered2(char *old_ports, char *ports, bool * pbEnable)
{
	char command[STR_COMMAND];

	//Delete rule
#if 0				/* [ 23122006, Ritesh */
	sprintf(command,
		"/usr/sbin/iptables -D IFX_FWD_INPUT_DOS_TCP_PAYLOAD -p tcp -m multiport --dports %s -m ifxattack --name code_redII -j REJECT --reject-with tcp-reset 2> /dev/null",
		old_ports);
	ifx_run_command(command);
	//Add if required
	if ((*pbEnable) == TRUE) {
		// Code Red II set
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_TCP_PAYLOAD -p tcp -m multiport --dports %s -m ifxattack --name code_redII -j REJECT --reject-with tcp-reset",
			ports);
		ifx_run_command(command);
	}
#else				/* ][ */
	sprintf(command, "%s %s %s %s %s", "--dports", old_ports,
		"-m ifxattack", "--name", "code_redII");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FWD_INPUT_DOS_TCP_PAYLOAD",
			  "tcp", "-m multiport", command,
			  "REJECT --reject-with tcp-reset 2> /dev/null");
	//Add if required
	if ((*pbEnable) == TRUE) {
		// Code Red II set
		sprintf(command, "%s %s %s %s %s", "--dports", ports,
			"-m ifxattack", "--name", "code_redII");
		IFX_IPT_SET_RULE2(FIREWALL, ADD,
				  "IFX_FWD_INPUT_DOS_TCP_PAYLOAD", "tcp",
				  "-m multiport", command,
				  "REJECT --reject-with tcp-reset");
	}
#endif				/* ] */
	return 0;
}

//              Code Red DoS
bool IFXSetFirewallDoSCodered(char *old_ports, char *ports, bool * pbEnable)
{
	char command[STR_COMMAND];

	//Delete rule
#if 0				/* [ 23122006, Ritesh */
	sprintf(command,
		"/usr/sbin/iptables -D IFX_FWD_INPUT_DOS_TCP_PAYLOAD -p tcp -m multiport --dports %s -m ifxattack --name code_redI -j REJECT --reject-with tcp-reset 2> /dev/null",
		old_ports);
	ifx_run_command(command);
	//Add if required
	if ((*pbEnable) == TRUE) {
		// Code Red set
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_TCP_PAYLOAD -p tcp -m multiport --dports %s -m ifxattack --name code_redI -j REJECT --reject-with tcp-reset",
			ports);
		ifx_run_command(command);
	}
#else				/* ][ */
	sprintf(command, "%s %s %s %s %s", "--dports", old_ports,
		"-m ifxattack", "--name", "code_redI");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FWD_INPUT_DOS_TCP_PAYLOAD",
			  "tcp", "-m multiport", command,
			  "REJECT --reject-with tcp-reset 2> /dev/null");
	//Add if required
	if ((*pbEnable) == TRUE) {
		// Code Red set
		sprintf(command, "%s %s %s %s %s", "--dports", ports,
			"-m ifxattack", "--name", "code_redI");
		IFX_IPT_SET_RULE2(FIREWALL, ADD,
				  "IFX_FWD_INPUT_DOS_TCP_PAYLOAD", "tcp",
				  "-m multiport", command,
				  "REJECT --reject-with tcp-reset");
	}
#endif				/* ] */
	return 0;
}

//              FTP Port Restricted DoS
bool IFXSetFirewallDoSFtpPR(bool * pbEnable)
{
	char command[STR_COMMAND];

	//Delete rule
#if 0				/* [ 23122006, Ritesh */
	sprintf(command,
		"/usr/sbin/iptables -D IFX_FWD_INPUT_DOS_TCP_PAYLOAD -p tcp --dport 21 -m ifxattack --name ftp_port -j REJECT --reject-with tcp-reset 2> /dev/null");
	ifx_run_command(command);
	//Add if required
	if ((*pbEnable) == TRUE) {
		// FTP Port Restricted set
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_TCP_PAYLOAD -p tcp --dport 21 -m ifxattack --name ftp_port -j REJECT --reject-with tcp-reset");
		ifx_run_command(command);
	}
#else				/* ][ */
	sprintf(command, "%s %s %s %s %s", "--dports", "21", "-m ifxattack",
		"--name", "ftp_port");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FWD_INPUT_DOS_TCP_PAYLOAD",
			  "tcp", "-m multiport", command,
			  "REJECT --reject-with tcp-reset 2> /dev/null");
	//Add if required
	if ((*pbEnable) == TRUE) {
		// FTP Port Restricted set
		sprintf(command, "%s %s %s %s %s", "--dports", "21",
			"-m ifxattack", "--name", "ftp_port");
		IFX_IPT_SET_RULE2(FIREWALL, ADD,
				  "IFX_FWD_INPUT_DOS_TCP_PAYLOAD", "tcp",
				  "-m multiport", command,
				  "REJECT --reject-with tcp-reset 2> /dev/null");
	}
#endif				/* ] */
	return 0;
}

//               Land DoS
bool IFXSetFirewallDoSLand(bool * pbEnable)
{
	char command[STR_COMMAND];

	//Delete rule
#if 0				/* [ 23122006, Ritesh */
	sprintf(command,
		"/usr/sbin/iptables -D PREROUTING -t nat -m ifxattack --name land_attack -j DROP 2> /dev/null");
	ifx_run_command(command);
	//Add if required
	if ((*pbEnable) == TRUE) {
		// Land set
		sprintf(command,
			"/usr/sbin/iptables -I PREROUTING 1 -t nat -m ifxattack --name land_attack -j DROP");
		ifx_run_command(command);
	}
#else				/* ][ */
	sprintf(command, "%s %s", "--name", "land_attack");
	IFX_IPT_SET_RULE2(NAPT, DELETE, "PREROUTING", "", "-m ifxattack",
			  command, "DROP 2> /dev/null");
	//Add if required
	if ((*pbEnable) == TRUE) {
		// Land set
		sprintf(command, "%s %s", "--name", "land_attack");
		IFX_IPT_SET_RULE2(NAPT, ADD, "PREROUTING", "1", "-m ifxattack",
				  command, "DROP");
	}
#endif				/* ] */
	return 0;
}

//               UDP Port Loopback DoS
bool IFXSetFirewallDoSLoopback(char *old_ports, char *ports, bool * pbEnable)
{
	char command[STR_COMMAND];

	//Delete rule
#if 0				/* [ 23122006, Ritesh */
	sprintf(command,
		"/usr/sbin/iptables -D IFX_PREROUTING_MANGLE_DOS -t mangle -p udp -m multiport --sports %s -j MARK --set-mark 7131719 2> /dev/null",
		old_ports);
	ifx_run_command(command);
	sprintf(command,
		"/usr/sbin/iptables -D IFX_FWD_INPUT_DOS_UDP_HDR -p udp -m multiport --dports %s -m mark --mark 7131719 -j DROP 2> /dev/null",
		old_ports);
	ifx_run_command(command);
	//Add if required
	if ((*pbEnable) == TRUE) {
		// UDP Port Loopback set
		sprintf(command,
			"/usr/sbin/iptables -A IFX_PREROUTING_MANGLE_DOS -t mangle -p udp -m multiport --sports %s -j MARK --set-mark 7131719",
			ports);
		ifx_run_command(command);
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_UDP_HDR -p udp -m multiport --dports %s -m mark --mark 7131719 -j DROP",
			ports);
		ifx_run_command(command);
	}
#else				/* ][ */
	sprintf(command, "%s %s", "--sports", old_ports);
	IFX_IPT_SET_RULE2(MANGLE, DELETE, "IFX_PREROUTING_MANGLE_DOS", "udp",
			  "-m multiport", command,
			  "MARK --set-mark 7131719 2> /dev/null");
	sprintf(command, "%s %s %s %s %s", "--dports", old_ports, "-m mark",
		"--mark", "7131719");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FWD_INPUT_DOS_UDP_HDR", "udp",
			  "-m multiport", command, "DROP 2> /dev/null");
	//Add if required
	if ((*pbEnable) == TRUE) {
		// UDP Port Loopback set
		sprintf(command, "%s %s", "--sports", ports);
		IFX_IPT_SET_RULE2(MANGLE, ADD, "IFX_PREROUTING_MANGLE_DOS",
				  "udp", "-m multiport", command,
				  "MARK --set-mark 7131719");
		sprintf(command, "%s %s %s %s %s", "--dports", ports, "-m mark",
			"--mark", "7131719");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FWD_INPUT_DOS_UDP_HDR",
				  "udp", "-m multiport", command, "DROP");
	}
#endif				/* ] */
	return 0;
}

//               Fraggle DoS
bool IFXSetFirewallDoSFraggle(char *old_ports, char *ports, char *old_rate,
			      char *rate, bool * pbEnable)
{
	char command[STR_COMMAND];

	//Delete rule
#if 0				/* [ 23122006, Ritesh */
	sprintf(command,
		"/usr/sbin/iptables -D IFX_FWD_INPUT_DOS_UDP_HDR -p udp -m multiport --dports %s -m addrtype --dst-type BROADCAST -j DROP 2> /dev/null",
		old_ports);
	ifx_run_command(command);
	sprintf(command,
		"/usr/sbin/iptables -D IFX_FWD_INPUT_DOS_UDP_HDR -p udp -m multiport --sports %s -m limit ! --limit %s/s --limit-burst %s -j DROP 2> /dev/null",
		old_ports, old_rate, old_rate);
	ifx_run_command(command);
	//Add if required
	if ((*pbEnable) == TRUE) {
		// Fraggle set
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_UDP_HDR -p udp -m multiport --dports %s -m addrtype --dst-type BROADCAST -j DROP",
			ports);
		ifx_run_command(command);
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_UDP_HDR -p udp -m multiport --sports %s -m limit ! --limit %s/s --limit-burst %s -j DROP",
			ports, rate, rate);
		ifx_run_command(command);
	}
#else				/* ][ */
	sprintf(command, "%s %s %s %s %s", "--dports", old_ports, "-m addrtype",
		"--dst-type", "BROADCAST");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FWD_INPUT_DOS_UDP_HDR", "udp",
			  "-m multiport", command, "DROP 2> /dev/null");
	sprintf(command, "%s %s %s ! %s/s %s %s %s", "--sports", old_ports,
		"-m limit", "--limit", old_rate, "--limit-burst", old_rate);
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FWD_INPUT_DOS_UDP_HDR", "udp",
			  "-m multiport", command, "DROP 2> /dev/null");
	//Add if required
	if ((*pbEnable) == TRUE) {
		// Fraggle set
		sprintf(command, "%s %s %s %s %s", "--dports", ports,
			"-m addrtype", "--dst-type", "BROADCAST");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FWD_INPUT_DOS_UDP_HDR",
				  "udp", "-m multiport", command, "DROP");
		sprintf(command, "%s %s %s ! %s/s %s %s %s", "--sports", ports,
			"-m limit", "--limit", rate, "--limit-burst", rate);
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FWD_INPUT_DOS_UDP_HDR",
				  "udp", "-m multiport", command, "DROP");
	}
#endif				/* ] */
	return 0;
}

//               UDP Bomb DoS
bool IFXSetFirewallDoSBomb(bool * pbEnable)
{
	char command[STR_COMMAND];

	//Delete rule
#if 0				/* [ 23122006, Ritesh */
	sprintf(command,
		"/usr/sbin/iptables -D IFX_FWD_INPUT_DOS_UDP_HDR -p udp -m ifxattack --name udp_bomb -j DROP 2> /dev/null");
	ifx_run_command(command);
	//Add if required
	if ((*pbEnable) == TRUE) {
		// UDP Bomb set
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_UDP_HDR -p udp -m ifxattack --name udp_bomb -j DROP");
		ifx_run_command(command);
	}
#else				/* ][ */
	//sprintf(command, "%s %s", "--name", "udp_bomb");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FWD_INPUT_DOS_UDP_HDR", "udp",
			  "-m ifxattack", command, "-j DROP 2> /dev/null");
	//Add if required
	if ((*pbEnable) == TRUE) {
		// UDP Bomb set
		//sprintf(command, "/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_UDP_HDR -p udp -m ifxattack --name udp_bomb -j DROP");
		//ifx_run_command(command);
		//sprintf(command, "%s %s", "--name", "udp_bomb");
		IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FWD_INPUT_DOS_UDP_HDR",
				  "udp", "-m ifxattack", command, "-j DROP");
	}
#endif				/* ] */
	return 0;
}

//               ICQ DoS
bool IFXSetFirewallDoSIcq(char *old_ports, char *ports, bool * pbEnable)
{
	char command[STR_COMMAND];

	//Delete rule
#if 0				/* [ 23122006, Ritesh */
	sprintf(command,
		"/usr/sbin/iptables -D IFX_FWD_INPUT_DOS_TCP_PAYLOAD -p tcp -m multiport --dports %s -m ifxattack --name icq_dos -j REJECT --reject-with tcp-reset 2> /dev/null",
		old_ports);
	ifx_run_command(command);
	//Add if required
	if ((*pbEnable) == TRUE) {
		// ICQ set
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_TCP_PAYLOAD -p tcp -m multiport --dports %s -m ifxattack --name icq_dos -j REJECT --reject-with tcp-reset",
			ports);
		ifx_run_command(command);
	}
#else				/* ][ */
	sprintf(command, "%s %s %s %s %s", "--dports", old_ports,
		"-m ifxattack", "--name", "icq_dos");
	IFX_IPT_SET_RULE2(FIREWALL, DELETE, "IFX_FWD_INPUT_DOS_TCP_PAYLOAD",
			  "tcp", "-m multiport", command,
			  "-j REJECT --reject-with tcp-reset 2> /dev/null");
	//Add if required
	if ((*pbEnable) == TRUE) {
		// ICQ set
		sprintf(command,
			"/usr/sbin/iptables -A IFX_FWD_INPUT_DOS_TCP_PAYLOAD -p tcp -m multiport --dports %s -m ifxattack --name icq_dos -j REJECT --reject-with tcp-reset",
			ports);
		ifx_run_command(command);
		sprintf(command, "%s %s %s %s %s", "--dports", ports,
			"-m ifxattack", "--name", "icq_dos");
		IFX_IPT_SET_RULE2(FIREWALL, ADD,
				  "IFX_FWD_INPUT_DOS_TCP_PAYLOAD", "tcp",
				  "-m multiport", command,
				  "-j REJECT --reject-with tcp-reset");
	}
#endif				/* ] */
	return 0;
}

//510251:sumedh end (DoS Attacks end)

bool IFXSetFirewallDosProtoectEnable(int operation, bool * pbEnable)
{
#if 0
	char command[STR_COMMAND];
#endif
	bool ret = 0;
	switch (operation) {
	case GET:
		ret =
		    IFX_IPT_GET_RULE_STATUS(FIREWALL, GET_CHAIN_STATUS,
					    "IFX_FW_TCP_ATTACK", pbEnable, NULL,
					    0);

		break;
	case SET:
		switch (*pbEnable) {
		case FALSE:
			IFX_IPT_FLUSH_CHAIN(FIREWALL, "IFX_FW_TCP_ATTACK");
			break;
		case TRUE:
#if 0				/* [ 23122006, Ritesh */
			/* NMAP FIN/URG/PUSH scan */
			sprintf(command,
				"/usr/sbin/iptables -A IFX_FW_TCP_ATTACK -p tcp --tcp-flags ALL FIN,URG,PSH -j DROP");
			ifx_run_command(command);

			/* Xmas Tree scan */
			sprintf(command,
				"/usr/sbin/iptables -A IFX_FW_TCP_ATTACK -p tcp --tcp-flags ALL ALL -j DROP");
			ifx_run_command(command);

			/* Another Xmas Tree scan */
			sprintf(command,
				"/usr/sbin/iptables -A IFX_FW_TCP_ATTACK -p tcp --tcp-flags ALL SYN,RST,ACK,FIN,URG -j DROP");
			ifx_run_command(command);

			/* Null Scan scan */
			sprintf(command,
				"/usr/sbin/iptables -A IFX_FW_TCP_ATTACK -p tcp --tcp-flags ALL NONE -j DROP");
			ifx_run_command(command);

			/* SYN/RST scan */
			sprintf(command,
				"/usr/sbin/iptables -A IFX_FW_TCP_ATTACK -p tcp --tcp-flags SYN,RST SYN,RST -j DROP");
			ifx_run_command(command);

			/* SYN/FIN scan */
			sprintf(command,
				"/usr/sbin/iptables -A IFX_FW_TCP_ATTACK -p tcp --tcp-flags SYN,FIN SYN,FIN -j DROP");
			ifx_run_command(command);

#if 0
			/* ACK scan */
			sprintf(command,
				"iptables -A IFX_FW_TCP_ATTACK -p tcp -m tcp --tcp-flags ALL ACK -j DROP");
			ifx_run_command(command);
#endif

			/* FIN scan */
			sprintf(command,
				"/usr/sbin/iptables -A IFX_FW_TCP_ATTACK -p tcp --tcp-flags ALL FIN -j DROP");
			ifx_run_command(command);

			/* make sure new tcp connections are SYN packets */
			sprintf(command,
				"/usr/sbin/iptables -A IFX_FW_TCP_ATTACK -p tcp ! --syn -m state --state NEW -j DROP");
			ifx_run_command(command);
#else				/* ][ */
			/* NMAP FIN/URG/PUSH scan */
			IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_TCP_ATTACK",
					  "tcp", "-tcp-flags ALL",
					  "FIN,URG,PSH", "DROP");

			/* Xmas Tree scan */
			IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_TCP_ATTACK",
					  "tcp", "-tcp-flags ALL", "ALL",
					  "DROP");

			/* Another Xmas Tree scan */
			IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_TCP_ATTACK",
					  "tcp", "-tcp-flags ALL",
					  "SYN,RST,ACK,FIN,URG", "DROP");

			/* Null Scan scan */
			IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_TCP_ATTACK",
					  "tcp", "-tcp-flags ALL", "NONE",
					  "DROP");

			/* SYN/RST scan */
			IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_TCP_ATTACK",
					  "tcp", "-tcp-flags",
					  "SYN,RST SYN,RST", "DROP");

			/* SYN/FIN scan */
			IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_TCP_ATTACK",
					  "tcp", "-tcp-flags",
					  "SYN,FIN SYN,FIN", "DROP");

#if 0
			/* ACK scan */
			IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_TCP_ATTACK",
					  "tcp", "-m tcp", "-tcp-flags ALL ACK",
					  "DROP");
#endif

			/* FIN scan */
			IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_TCP_ATTACK",
					  "tcp", "-tcp-flags ALL", "FIN",
					  "DROP");

			/* make sure new tcp connections are SYN packets */
			IFX_IPT_SET_RULE2(FIREWALL, ADD, "IFX_FW_TCP_ATTACK",
					  "tcp", "! --syn -m state",
					  "--state NEW", "DROP");
#endif				/* ] */

			break;
		default:
			return 1;
		}
		break;
	}

	return 0;
}
#endif

bool IFXSetFirewallPingResponse(int operation, int type, bool * pbEnable)
{
#if 0
	char command[STR_COMMAND];
#endif

	switch (operation) {
	case GET:
		switch (type) {
		case DISCARD_PING_WAN_RESPONSE:
		
			    IFX_IPT_GET_RULE_STATUS(FIREWALL, GET_CHAIN_STATUS,
						    "IFX_FW_ICMP_WAN_RESPONSE",
						    pbEnable, NULL, 0);
			break;
		case DISCARD_PING_FORWARD_RESONSE:
			
			    IFX_IPT_GET_RULE_STATUS(FIREWALL, GET_CHAIN_STATUS,
						    "IFX_FW_ICMP_FORWARD",
						    pbEnable, NULL, 0);
			break;
		}
		break;
	case SET:
		switch (*pbEnable) {
		case FALSE:
			switch (type) {
			case DISCARD_PING_WAN_RESPONSE:
				IFX_IPT_FLUSH_CHAIN(FIREWALL,
						    "IFX_FW_ICMP_WAN_RESPONSE");

				break;
			case DISCARD_PING_FORWARD_RESONSE:
				IFX_IPT_FLUSH_CHAIN(FIREWALL,
						    "IFX_FW_ICMP_FORWARD");
				break;
			}
			break;
		case TRUE:
			switch (type) {
			case DISCARD_PING_WAN_RESPONSE:
#if 0				/* [ 23122006, Ritesh */
				sprintf(command,
					"/usr/sbin/iptables -A IFX_FW_ICMP_WAN_RESPONSE -p icmp -j DROP");
				ifx_run_command(command);
#else				/* ][ */
				IFX_IPT_SET_RULE2(FIREWALL, ADD,
						  "IFX_FW_ICMP_WAN_RESPONSE",
						  "icmp", "", "", "DROP");
#endif				/* ] */
				break;
			case DISCARD_PING_FORWARD_RESONSE:
#if 0				/* [ 23122006, Ritesh */
				sprintf(command,
					"/usr/sbin/iptables -A IFX_FW_ICMP_FORWARD -p icmp -j DROP");
				ifx_run_command(command);
#else				/* ][ */
				IFX_IPT_SET_RULE2(FIREWALL, ADD,
						  "IFX_FW_ICMP_FORWARD", "icmp",
						  "", "", "DROP");
#endif				/* ] */
				break;
			}

			break;
		default:
			return 1;
		}
		break;
	}

	return 0;
}

bool IFXSetFirewallPacketFilterEnable(int operation, bool * pbEnable)
{
	return IFX_IPT_SET_CHAIN_ENABLE(FIREWALL, operation,
					"IFX_FW_PACKET_FILTER", pbEnable);
}

bool IFXSetFirewallPacketFilterEntry(int operation, P_IFX_IPT_RULE pCfg,
				     int *piEnteriesSize)
{
	return IFX_IPT_SET_RULES(FIREWALL, operation, "IFX_FW_PACKET_FILTER",
				 pCfg, piEnteriesSize, DROP);
}

bool IFXSetPolicyRouteEntry(int operation, P_IFX_IPT_RULE pCfg,
			    int *piEnteriesSize)
{
	return IFX_IPT_SET_RULES(MANGLE, operation, "IFX_MANGLE_POLICY_ROUTING",
				 pCfg, piEnteriesSize, NAPT_ROUTE);
}

bool IFXGetFirewallClientFilterTable(int iSize, char *pBuffer,
				     int *piReturnEntries)
{
	return IFX_IPT_GET_RULES(FIREWALL, "IFX_FW_PACKET_FILTER", pBuffer,
				 iSize, piReturnEntries, DROP);
}

bool IFXSetFirewallMacFilterEnable(int operation, bool * pbEnable)
{
	bool  bEnable = 0;
	IFX_IPT_RULE query_rule;
	memset(&query_rule, 0, sizeof(IFX_IPT_RULE));

	memset(&query_rule, 0, sizeof(IFX_IPT_RULE));
	query_rule.protocol = PROTO_ALL;
	switch (operation) {
	case GET:
		*pbEnable = MAC_DISABLE;
		IFX_IPT_SET_CHAIN_ENABLE(FIREWALL, operation,
					 "IFX_FW_MAC_FILTER_DROP", pbEnable);
		if (*pbEnable == 0)
			return 0;
	
		    IFX_IPT_GET_RULE_STATUS(FIREWALL, GET_SINGLE_RULE_STATUS,
					    "IFX_FW_MAC_FILTER_PERMIT",
					    &bEnable, &query_rule, DROP);

		if (bEnable)
			*pbEnable = MAC_DROP;
		else
			*pbEnable = MAC_PERMIT;
		break;
	case SET:
		IFXSetFirewallMacFilterEnable(GET, &bEnable);
		if (*pbEnable != bEnable) {
			switch (bEnable) {
			case MAC_DISABLE:
				bEnable = 1;
				IFX_IPT_SET_CHAIN_ENABLE(FIREWALL, operation,
							 "IFX_FW_MAC_FILTER_DROP",
							 &bEnable);
				IFX_IPT_SET_CHAIN_ENABLE(FIREWALL, operation,
							 "IFX_FW_MAC_FILTER_PERMIT",
							 &bEnable);
				break;
			case MAC_DROP:
				IFX_IPT_SET_SINGLE_RULE(FIREWALL, DELETE,
							"IFX_FW_MAC_FILTER_PERMIT",
							&query_rule, DROP);
				break;
			}
			switch (*pbEnable) {
			case MAC_DISABLE:
				bEnable = 0;
				IFX_IPT_SET_CHAIN_ENABLE(FIREWALL, operation,
							 "IFX_FW_MAC_FILTER_DROP",
							 &bEnable);
				IFX_IPT_SET_CHAIN_ENABLE(FIREWALL, operation,
							 "IFX_FW_MAC_FILTER_PERMIT",
							 &bEnable);
				break;
			case MAC_DROP:
				IFX_IPT_SET_SINGLE_RULE(FIREWALL, ADD,
							"IFX_FW_MAC_FILTER_PERMIT",
							&query_rule, DROP);
				break;
			}
		}
		return 0;
	default:
		return 1;
	}
	return 1;
}

bool IFXSetFirewallMacFilterDropEntry(int operation, P_IFX_IPT_RULE pCfg,
				      int *piEnteriesSize)
{
	return IFX_IPT_SET_RULES(FIREWALL, operation, "IFX_FW_MAC_FILTER_DROP",
				 pCfg, piEnteriesSize, DROP);
}

bool IFXGetFirewallMacFilterDropTable(int iSize, char *pBuffer,
				      int *piReturnEntries)
{
	return IFX_IPT_GET_RULES(FIREWALL, "IFX_FW_MAC_FILTER_DROP", pBuffer,
				 iSize, piReturnEntries, DROP);
}

bool IFXSetFirewallMacFilterPermitEntry(int operation, P_IFX_IPT_RULE pCfg,
					int *piEnteriesSize)
{
	return IFX_IPT_SET_RULES(FIREWALL, operation,
				 "IFX_FW_MAC_FILTER_PERMIT", pCfg,
				 piEnteriesSize, RETURN);
}

bool IFXGetFirewallMacFilterPermitTable(int iSize, char *pBuffer,
					int *piReturnEntries)
{
	return IFX_IPT_GET_RULES(FIREWALL, "IFX_FW_MAC_FILTER_PERMIT", pBuffer,
				 iSize, piReturnEntries, RETURN);
}

bool IFX_SET_FIREWALL_DNAT_PORTMAPPING_ENABLE(int operation, bool * pbEnable)
{
	return IFX_IPT_SET_CHAIN_ENABLE(FIREWALL, operation, "IFX_FW_DNAT_PM",
					pbEnable);

}

bool IFX_SET_FIREWALL_DNAT_PORTMAPPING_Entry(int operation, P_IFX_IPT_RULE pCfg,
					     int *piEnteriesSize)
{
	return IFX_IPT_SET_RULES(FIREWALL, operation, "IFX_FW_DNAT_PM", pCfg,
				 piEnteriesSize, ACCEPT);
}

bool IFX_GET_FIREWALL_DNAT_PORTMAPPING_Table(int iSize, char *pBuffer,
					     int *piReturnEntries)
{
	return IFX_IPT_GET_RULES(FIREWALL, "IFX_FW_DNAT_PM", pBuffer, iSize,
				 piReturnEntries, ACCEPT);
}

bool IFX_SET_FIREWALL_DNAT_VIRTUALSERVER_ENABLE(int operation, bool * pbEnable)
{
	return IFX_IPT_SET_CHAIN_ENABLE(FIREWALL, operation, "IFX_FW_DNAT_VS",
					pbEnable);
}

bool IFX_SET_FIREWALL_DNAT_VIRTUALSERVER_Entry(int operation,
					       P_IFX_IPT_RULE pCfg,
					       int *piEnteriesSize)
{
	return IFX_IPT_SET_RULES(FIREWALL, operation, "IFX_FW_DNAT_VS", pCfg,
				 piEnteriesSize, ACCEPT);
}

bool IFX_GET_FIREWALL_DNAT_VIRTUALSERVERG_Table(int iSize, char *pBuffer,
						int *piReturnEntries)
{
	return IFX_IPT_GET_RULES(FIREWALL, "IFX_FW_DNAT_VS", pBuffer, iSize,
				 piReturnEntries, ACCEPT);
}

bool IFX_SET_FIREWALL_DMZ_ENABLE(int operation, bool * pbEnable)
{
	return IFX_IPT_SET_CHAIN_ENABLE(FIREWALL, operation, "IFX_FW_DMZ",
					pbEnable);
}

bool IFX_SET_FIREWALL_DMZ(int operation, __u32 DMZ_IP)
{
	IFX_IPT_RULE dev_rule[2];
	int iEnteriesSize = 2;
	memset(&dev_rule[0], 0, sizeof(IFX_IPT_RULE) * 2);
	switch (operation) {
	case ADD:
	case DELETE:
		dev_rule[0].protocol = PROTO_ALL;
		dev_rule[1].protocol = PROTO_ALL;
		dev_rule[0].srcip = DMZ_IP;
		dev_rule[1].dstip = DMZ_IP;
		IFX_IPT_SET_RULES(FIREWALL, operation, "IFX_FW_DMZ",
				  &dev_rule[0], &iEnteriesSize, ACCEPT);
		break;
	case DELETE_ALL:
		IFX_IPT_SET_RULES(FIREWALL, operation, "IFX_FW_DMZ",
				  &dev_rule[0], &iEnteriesSize, ACCEPT);
		break;
	}
	return 0;
}

// Drop connection
bool IFX_SET_FIREWALL_DENY_SERVICES(int operation, int IFtype, __u16 port,
				    __u16 protocol)
{
	IFX_IPT_RULE dev_rule = { 0 };
	int iEnteriesSize = 1;
	dev_rule.protocol = protocol;
	dev_rule.dstport_start = port;
	switch (IFtype) {
	case IF_LAN:
		IFX_IPT_SET_RULES(FIREWALL, operation, "IFX_FW_DENY_SERVICES",
				  &dev_rule, &iEnteriesSize,
				  IFX_FW_DENY_LAN_IF_INPUT);
		break;
	case IF_WAN:
		IFX_IPT_SET_RULES(FIREWALL, operation, "IFX_FW_DENY_SERVICES",
				  &dev_rule, &iEnteriesSize,
				  IFX_FW_DENY_WAN_IP_INPUT);
		break;
	default:
		return 1;
	}
	return 0;
}

// Drop connection
bool IFX_SET_FIREWALL_ACCEPT_SERVICES(int operation, __u16 port, __u16 protocol,
				      bool acl)
{
	IFX_IPT_RULE dev_rule = { 0 };
	int iEnteriesSize = 1;
	dev_rule.protocol = protocol;
	dev_rule.dstport_start = port;
	if (acl)
		IFX_IPT_SET_RULES(FIREWALL, operation, "IFX_FW_ACCEPT_SERVICES",
				  &dev_rule, &iEnteriesSize,
				  IFX_FW_SERVICES_ACL);
	else {
		//IFX_IPT_SET_RULES(FIREWALL, operation,"IFX_FW_ACCEPT_SERVICES",&dev_rule,&iEnteriesSize,IFX_FW_ACCEPT_WAN_IP_INPUT);
		IFX_IPT_SET_RULES(FIREWALL, operation, "IFX_FW_ACCEPT_SERVICES",
				  &dev_rule, &iEnteriesSize, ACCEPT);
		// 508182:tc.chen
		if (operation != DELETE_ALL)
			IFX_IPT_SET_RULES(NAPT, operation, "IFX_NAPT_PREROUTING_WAN", &dev_rule, &iEnteriesSize, ACCEPT);	// 508182:tc.chen
	}
	return 0;
}

bool IFX_SET_FIREWALL_ACCEPT_WAN_SERVICES_TO_LAN(int operation, __u16 port,
						 __u16 protocol)
{
	IFX_IPT_RULE dev_rule = { 0 };
	int iEnteriesSize = 1;
	dev_rule.protocol = protocol;
	dev_rule.dstport_start = port;
	IFX_IPT_SET_RULES(FIREWALL, operation, "IFX_FW_APPS_TO_LAN_INPUT",
			  &dev_rule, &iEnteriesSize,
			  IFX_FW_ACCEPT_LAN_IP_INPUT);
	dev_rule.srcport_start = port;
	dev_rule.dstport_start = 0;
	IFX_IPT_SET_RULES(FIREWALL, operation, "IFX_FW_APPS_TO_LAN_OUTPUT",
			  &dev_rule, &iEnteriesSize,
			  IFX_FW_ACCEPT_LAN_IP_OUTPUT);
	return 0;
}

bool IFX_SET_FIREWALL_SERVICES_ACL_ENABLE(int operation, bool * pbEnable)
{
	return IFX_IPT_SET_CHAIN_ENABLE(FIREWALL, operation,
					"IFX_FW_SERVICES_ACL", pbEnable);
}

bool IFXSetFirewallServiceAclEntry(int operation, P_IFX_IPT_RULE pCfg,
				   int *piEnteriesSize)
{
	if (operation == ADD)
		operation = INSERT;
	
	    IFX_IPT_SET_RULES(FIREWALL, operation, "IFX_FW_SERVICES_ACL", pCfg,
			      piEnteriesSize, ACCEPT);
	if (operation == DELETE_ALL) {
		IFX_IPT_RULE dev_rule = { 0 };
		int iEnteriesSize = 1;
		    IFX_IPT_SET_RULES(FIREWALL, ADD, "IFX_FW_SERVICES_ACL",
				      &dev_rule, &iEnteriesSize, DROP);
	}
	return 0;
}
