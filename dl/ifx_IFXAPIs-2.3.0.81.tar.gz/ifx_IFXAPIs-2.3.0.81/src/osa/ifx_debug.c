/****************************************************************************
** FILE NAME     : ifx_debug.c
** PROJECT       : TR69 
** MODULES       : Debug Management module
** SRC VERSION   : V0.1
** DATE          : 01-10-2004
** AUTHOR        : Hari
** DESCRIPTION   : This file contains the code for Debug Management
** REFERENCE     : 
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author      $Comment
*****************************************************************************/
#ifdef DEBUG_ENABLED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdarg.h>
#ifdef DBG_TIMESTAMP
#include <sys/time.h>
#endif

#include "ifx_common_defs.h"
#include "ifx_debug.h"

#define IFX_DBG_DIR "/tmp/"

#define IFX_DBG_MAX_MODULE_NAME 16
#define IFX_DBG_MAX_MODULES 1
#define IFX_DBG_MAX_LOG_FILE_NAME 64

STATIC uchar8 ucGlobalDbgLvl = 0;
extern char8 vcOsModId;

char8 *vacMsgTbl[] = {
	[IFX_DBG_STR] = "%s\n",	/* Print Any String */
};

typedef struct {
	char8 cModuleName[IFX_DBG_MAX_MODULE_NAME];

#define IFX_DBG_REGISTERED_FALSE 0
#define IFX_DBG_REGISTERED_TRUE  1

	char8 cRegisterFlag;

	char8 ucDbgType;

	char8 ucDbgLvl;

	char8 cLogFileName[IFX_DBG_MAX_LOG_FILE_NAME];

} x_IFX_DBG_RegInfo;

x_IFX_DBG_RegInfo vaxRegInfo[IFX_DBG_MAX_MODULES];

/*
 ******************************************************************************
 *  Function Name   : IFX_DBG_Init
 *  Description     : Initialises the Debug for a particular module
 *
 *  Input Values    : Module Name, Debug Type, Debug Level 
 *  Output Values   : Module Debug Id, Return value
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAIL - On Failure
 *  Notes           :
 ******************************************************************************
*/
PUBLIC void
IFX_DBG_Init(IN char8 * pcModuleName,
	     IN char8 ucDbgType,
	     IN char8 ucDbgLvl, OUT uchar8 * pucModuleId, OUT char8 * pcRet)
{
	int16 nIdx = 0, nFd = 0;
	STATIC int16 nInit = 0;
	memset(vaxRegInfo, 0,
	       sizeof(x_IFX_DBG_RegInfo) * IFX_DBG_MAX_MODULES);
	if (!nInit) {
		nInit = 1;
#if defined(DBG_LVL_CUSTOMER)
		ucGlobalDbgLvl = IFX_DBG_LVL_LOW;
#elif defined(DBG_LVL_DEVELOPMENT)
		ucGlobalDbgLvl = IFX_DBG_LVL_HIGH;
#endif

	}
	while (nIdx < IFX_DBG_MAX_MODULES) {
		if (!vaxRegInfo[nIdx].cRegisterFlag) {
			strcpy(vaxRegInfo[nIdx].cModuleName, pcModuleName);
/*			vaxRegInfo[nIdx].ucDbgLvl =
			    ((ucGlobalDbgLvl <
			      ucDbgLvl) ? ucGlobalDbgLvl : ucDbgLvl);
*/
vaxRegInfo[nIdx].ucDbgLvl = ucDbgLvl;
			vaxRegInfo[nIdx].ucDbgType = ucDbgType;
			if (ucDbgType == IFX_DBG_TYPE_FILE) {
				sprintf(vaxRegInfo[nIdx].cLogFileName,
					"%sifx_%s_log", IFX_DBG_DIR,
					pcModuleName);
				if ((nFd =
				     open(vaxRegInfo[nIdx].cLogFileName,
					  O_WRONLY | O_CREAT | O_TRUNC,
					  0777)) < 0) {
					IFX_DBG_Log(vcOsModId,
						    IFX_DBG_LVL_ERROR,
						    "%s:%d [%d] "
						    "Error Registering Module for Debug\n",
						    __func__, __LINE__, nFd);
					*pcRet = IFX_FAIL;
					return;
				}
				close(nFd);
			}
			*pucModuleId = nIdx + 1;
			vaxRegInfo[nIdx].cRegisterFlag =
			    IFX_DBG_REGISTERED_TRUE;
			*pcRet = IFX_SUCCESS;
			return;
		}
		nIdx++;
	}
	if (nIdx >= IFX_DBG_MAX_MODULES) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] "
			    "Max Modules Registered\n", __func__, __LINE__,
			    nIdx);
		*pcRet = IFX_FAIL;
		return;
	}
	*pcRet = IFX_SUCCESS;
	return;
}

/*
 ******************************************************************************
 *  Function Name   : IFX_DBG_Set
 *  Description     : Modifies the Debug settings at run-time. This API
 *                    should be called only from registered modules
 *
 *  Input Values    : Module Id, Debug Type, Debug Level 
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAIL - On Failure
 *  Notes           :
 ******************************************************************************
*/
PUBLIC char8
IFX_DBG_Set(IN char8 * pcModuleName,
	    IN uchar8 cModuleId, IN char8 ucDbgType, IN char8 ucDbgLvl)
{
	int16 nFd = 0;

	if ((cModuleId == 0) || (cModuleId > IFX_DBG_MAX_MODULES)) {
		return IFX_FAIL;
	}

	if ((!(strcmp(vaxRegInfo[cModuleId - 1].cModuleName, pcModuleName))) &&
	    (vaxRegInfo[cModuleId - 1].cRegisterFlag ==
	     IFX_DBG_REGISTERED_TRUE)) {
		/* If Module Identification matches and the module is registered */
		vaxRegInfo[cModuleId - 1].ucDbgLvl =
		    ((ucGlobalDbgLvl < ucDbgLvl) ? ucGlobalDbgLvl : ucDbgLvl);

		if (vaxRegInfo[cModuleId - 1].ucDbgType != ucDbgType) {
			if (ucDbgType == IFX_DBG_TYPE_FILE) {
				sprintf(vaxRegInfo[cModuleId - 1].cLogFileName,
					"%sifx_%s_log", IFX_DBG_DIR,
					pcModuleName);
				if ((nFd =
				     open(vaxRegInfo[cModuleId - 1].
					  cLogFileName,
					  O_WRONLY | O_CREAT | O_TRUNC,
					  0777)) < 0) {
					IFX_DBG_Log(vcOsModId,
						    IFX_DBG_LVL_ERROR,
						    "%s:%d [%d] "
						    "Error opening Log file\n",
						    __func__, __LINE__, nFd);
					return IFX_FAIL;
				}
				close(nFd);
			}

			vaxRegInfo[cModuleId - 1].ucDbgType = ucDbgType;
		}
	} else {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d <DBG> "
			    "Fail returned %s is\n", __func__, __LINE__,
			    pcModuleName);
		return IFX_FAIL;
	}
	return IFX_SUCCESS;
}

/*
 ******************************************************************************
 *  Function Name   : IFX_DBG_Shut
 *  Description     : Cleans up the Debug Registration for a particular module
 *
 *  Input Values    : Module Debug Id 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAIL - On Failure
 *  Notes           :
 ******************************************************************************
*/
PUBLIC void IFX_DBG_Shut(IN uchar8 ucModuleId, OUT char8 * pcRet)
{
	if ((ucModuleId == 0) || (ucModuleId > IFX_DBG_MAX_MODULES)) {
		*pcRet = IFX_FAIL;
		return;
	}
	memset(&vaxRegInfo[ucModuleId - 1], 0, sizeof(x_IFX_DBG_RegInfo));
	*pcRet = IFX_SUCCESS;
	return;
}

/*
 ******************************************************************************
 *  Function Name   : IFX_DBG_Log
 *  Description     : Logs Debug messages
 *
 *  Input Values    : Module Id, Debug Level and Debug String
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAIL - On Failure
 *  Notes           :
 ******************************************************************************
*/
PUBLIC void
IFX_DBG_Log(IN uchar8 ucModuleId, IN uchar8 ucDbgLvl, IN char8 * pucStr, ...)
{
	va_list ArgList;
	char8 cAppendStr[512];
	char8 cLogStr[512];
	int16 nFd = 0;
#ifdef DBG_TIMESTAMP
	struct timeval TimeVal;
	ulong32 ulTime;
	gettimeofday(&TimeVal, NULL);
	ulTime = TimeVal.tv_sec * 1000 + TimeVal.tv_usec / 1000;
#endif

	if ((ucModuleId == 0) || (ucModuleId > IFX_DBG_MAX_MODULES)) {
		return;
	}
	if (vaxRegInfo[ucModuleId - 1].ucDbgLvl >= ucDbgLvl) {
		va_start(ArgList, pucStr);
#ifdef DBG_TIMESTAMP
		sprintf(cAppendStr, "<%lu> [%s] %s", ulTime,
			vaxRegInfo[ucModuleId - 1].cModuleName, pucStr);
#else
		sprintf(cAppendStr, "%s",
			/*vaxRegInfo[ucModuleId - 1].cModuleName, */ pucStr);
#endif
		if (vaxRegInfo[ucModuleId - 1].ucDbgType ==
		    IFX_DBG_TYPE_CONSOLE) {
			vprintf(cAppendStr, ArgList);
		} else if (vaxRegInfo[ucModuleId - 1].ucDbgType ==
			   IFX_DBG_TYPE_FILE) {
			vsprintf(cLogStr, cAppendStr, ArgList);
			if ((nFd = open(vaxRegInfo[ucModuleId - 1].cLogFileName,
					O_WRONLY | O_APPEND, 0777)) < 0) {
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					    "%s:%d [%d] "
					    "Error opening Log file\n",
					    __func__, __LINE__, nFd);
				return;
			}

			if (write(nFd, cLogStr, strlen(cLogStr)) < 0) {
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					    "%s:%d "
					    "Error writing to Log file\n",
					    __func__, __LINE__);
				close(nFd);
				return;
			}
			close(nFd);
		}
		va_end(ArgList);
		return;
	} else {
		return;
	}
	return;
}

#endif				/* DEBUG_ENABLED */
