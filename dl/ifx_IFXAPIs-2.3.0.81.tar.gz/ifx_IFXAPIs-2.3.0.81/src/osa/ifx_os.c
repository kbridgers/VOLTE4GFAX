/**************************************************************************
** FILE NAME     : ifx_os.c
** PROJECT       : TR69
** MODULES       : OS Interface for all IFX modules
** SRC VERSION   : V1.0
** DATE          : 2-11-2004
** AUTHOR        : TR69 Team
** DESCRIPTION   :
** REFERENCE     :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author      $Comment
***********************************************************************/
/* All Standard Header files included in ifx_os.h */

#include "ifx_common_defs.h"
#include "ifx_debug.h"
#include "ifx_os.h"

#define IFX_OS_FIFO_PERM 0666

#define IFX_OS_MX_BUFF 100
#define IFX_OS_IP_SIZE 20

extern char8 vcOsModId;
extern int32 viTR69RdFd;

/******************************************************************
 *  Function Name    : IFX_OS_Init
 *  Description      : This function Initialises the OS Interface
 *  Input Values     : None
 *  Output Values    : None
 *  Return Value     : None
 *  Notes            :
 ******************************************************************/
PUBLIC void IFX_OS_Init(char *sLogFileName)
{
	char8 *pcDbgExportStr;
	char8 *pcDbgTypeStr;
	uchar8 ucDbgLvl = IFX_DBG_LVL_NONE;
	uchar8 ucDbgType = IFX_DBG_TYPE_NONE;
	char8 cRet = -1;

	/*Init the Debug Libray */
	pcDbgExportStr = getenv("OS_IFX_DBG_LVL");

	if (pcDbgExportStr) {
		if (!strcmp(pcDbgExportStr, "IFX_DBG_LVL_HIGH")) {
			ucDbgLvl = IFX_DBG_LVL_HIGH;
		} else if (!strcmp(pcDbgExportStr, "IFX_DBG_LVL_NORMAL")) {
			ucDbgLvl = IFX_DBG_LVL_NORMAL;
		} else if (!strcmp(pcDbgExportStr, "IFX_DBG_LVL_LOW")) {
			ucDbgLvl = IFX_DBG_LVL_LOW;
		} else if (!strcmp(pcDbgExportStr, "IFX_DBG_LVL_ERROR")) {
			ucDbgLvl = IFX_DBG_LVL_ERROR;
		}
	}
	pcDbgTypeStr = getenv("OS_IFX_DBG_TYPE");
	if (pcDbgTypeStr) {
		if (!strcmp(pcDbgTypeStr, "CONSOLE")) {
			ucDbgType = IFX_DBG_TYPE_CONSOLE;
		}
		if (!strcmp(pcDbgTypeStr, "FILE")) {
			ucDbgType = IFX_DBG_TYPE_FILE;
		}
	}
#ifdef TEST
	ucDbgType = IFX_DBG_TYPE_CONSOLE;
	ucDbgLvl = IFX_DBG_LVL_HIGH;
#endif
	IFX_DBG_Init(sLogFileName, ucDbgType, ucDbgLvl, (uchar8 *) & vcOsModId,
		     &cRet);
	if (cRet != IFX_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
			    "Error Registering with IFX_DBG Libary, exiting\n",
			    __func__, __FILE__);
		return;
	}
}

/* Functions for FIFO Operations */

/* The OS library doesn't provide much of debug information.
 * The upper layer applications already have debugs in place
 * for error conditions.  It will increase the number of debugs
 * if they are put in both places.
 */

/******************************************************************
 *  Function Name    : IFX_OS_CreateFifo
 *  Description      : This function creates a FIFO with a given name
 *  Input Values     : Pointer to the name of the FIFO
 *  Output Values    : None
 *  Return Value     : Descriptor to the FIFO
 *  Notes            :
 ******************************************************************/
PUBLIC int32 IFX_OS_CreateFifo(IN uchar8 * pucName)
{
	int32 iRet = 0;
	/* Check for the existence of FIFO */
	if (access((char8 *) pucName, F_OK) == -1) {
		iRet = mkfifo((char8 *) pucName, IFX_OS_FIFO_PERM);
	}			/*end of if */
	return iRet;
}

/******************************************************************
 *  Function Name    : IFX_OS_OpenFifo
 *  Description      : This function opens a FIFO with a given name
 *                     If Fifo doesnt exist, it is created first
 *  Input Values     : Pointer to the name of the FIFO, Flags
 *  Output Values    : None
 *  Return Value     : Descriptor to the FIFO
 *  Notes            :
 ******************************************************************/
PUBLIC int32 IFX_OS_OpenFifo(IN uchar8 * pucName, IN int32 iFlags)
{
	int32 iRet = 0;
	/* Check for the existence of FIFO */
	if (access((char8 *) pucName, F_OK) == -1) {
		iRet = mkfifo((char8 *) pucName, IFX_OS_FIFO_PERM);
		if (iRet < 0) {
			return iRet;
		}
	}			/*end of if */
	iRet = open((char8 *) pucName, iFlags);
	return iRet;
}

/* C Library Functions for String Operations */

/******************************************************************************
 * Function Name: IFX_OS_Memcmp
 * Description  : Compare characters in two buffers
 * Input Values : pPtr1  - Pointer to first buffer
 *                pPtr2  - Pointer to second buffer
 *                uiSize - Number of characters to copy
 * Output Values:
 * Return Value : < 0 - buf1 less than buf2
 *                0   - buf1 identical to buf2
 *                > 0 - buf1 greater than buf2
 * Notes        :
 *****************************************************************************/
PUBLIC int32
IFX_OS_Memcmp(IN const void *pPtr1, IN const void *pPtr2, IN uint32 uiSize)
{
	if (!uiSize)
		return 0;
	while ((--uiSize != 0) && (*(char8 *) pPtr1 == *(char8 *) pPtr2)) {
		pPtr1 = (char8 *) pPtr1 + 1;
		pPtr2 = (char8 *) pPtr2 + 1;
	}
	return (*((uchar8 *) pPtr1) - *((uchar8 *) pPtr2));
}

/******************************************************************************
 * Function Name: IFX_OS_Strlen
 * Description  : Get the length of a string
 * Input Values : pcPtr  - Pointer to buffer to copy from
 * Output Values:
 * Return Value : The number of characters in string
 * Notes        : No return value is reserved to indicate an error
 *****************************************************************************/
PUBLIC int32 IFX_OS_Strlen(IN const char8 * pcPtr)
{
	int32 iRc = -1;
	do {
		iRc++;
	} while (*pcPtr++);
	return iRc;
}

/******************************************************************************
 * Macro Name   : IFX_OS_Strcpy
 * Description  : Copy a string
 * Input Values : pcSrc  - Pointer to string buffer to copy from
 * Output Values: pcDst  - Pointer to destination string buffer
 * Return Value : The number of characters in string
 * Notes        : Pointer to destination string buffer
 *****************************************************************************/
PUBLIC char8 *IFX_OS_Strcpy(IN char8 * pcDst, IN const char8 * pcSrc)
{
	char8 *cRc = pcDst;
	do {
		*pcDst = *pcSrc++;
	} while (*pcDst++);
	return cRc;
}

/* Network Routines */

/******************************************************************
 *  Function Name    : IFX_OS_CreateSocket
 *  Description      : This function Creates a TCP/UDP Socket
 *  Input Values     : Protocol Type (TCP/UDP)
 *                     Local Port
 *                     Remote Port
 *                     Remote IP Address
 *                     TCP Socket Type (Server / Client)
 *  Output Values    : None
 *  Return Value     : Socket Fd (on Success) or -1 (on Failure)
 *  Notes            :
*******************************************************************/
PUBLIC int32
IFX_OS_CreateSocket(IN uchar8 ucProtocol,
		    IN uint16 unLocalPort,
		    IN uint16 unRemotePort,
		    IN char8 * pacRemoteIpAddress, IN uchar8 ucTcpSocketType)
{
	int32 iSockFd = -1, iResult = 0;
	int32 iOn = 1;
	struct sockaddr_in xLocalAddr, xRemoteAddr;

	/* Create the Socket */
	if (ucProtocol == IFX_OS_PROTOCOL_TCP) {
		iSockFd = socket(AF_INET, SOCK_STREAM, 0);
	} else if (ucProtocol == IFX_OS_PROTOCOL_UDP) {
		iSockFd = socket(AF_INET, SOCK_DGRAM, 0);
	} else {
		return iSockFd;
	}
	if (iSockFd < 0) {
		IFX_DBGA(vcOsModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
			 "Error Creating Socket : Type %d", ucProtocol);
		goto Fail;
	}
	if (ucProtocol == IFX_OS_PROTOCOL_TCP) {
		setsockopt(iSockFd, SOL_SOCKET, SO_REUSEADDR, &iOn,
			   sizeof(iOn));
	}

	bzero(&xLocalAddr, sizeof(xLocalAddr));
	xLocalAddr.sin_family = AF_INET;
	xLocalAddr.sin_addr.s_addr = htonl(INADDR_ANY);
	xLocalAddr.sin_port = htons(unLocalPort);

	/* Bind the Socket to the local port */
	iResult =
	    bind(iSockFd, (struct sockaddr *)&xLocalAddr, sizeof(xLocalAddr));
	if (iResult < 0) {
		IFX_DBGA(vcOsModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
			 "Error Binding Socket : Type %d", ucProtocol);
		goto Fail;
	}

	/* If the protocol is TCP, we need to know the type of socket.
	 * Whether its a server socket or a client socket
	 */
	if (ucProtocol == IFX_OS_PROTOCOL_TCP) {
		if (ucTcpSocketType == IFX_OS_TCP_SOCKTYPE_CLIENT) {
			bzero(&xRemoteAddr, sizeof(xRemoteAddr));
			xRemoteAddr.sin_family = AF_INET;
			inet_pton(AF_INET, pacRemoteIpAddress,
				  &xRemoteAddr.sin_addr);
			xRemoteAddr.sin_port = htons(unRemotePort);

			iResult =
			    connect(iSockFd, (struct sockaddr *)&xRemoteAddr,
				    sizeof(xRemoteAddr));
			if (iResult < 0) {
				IFX_DBGA(vcOsModId, IFX_DBG_LVL_ERROR,
					 IFX_DBG_STR,
					 "Error Connecting to Remote Socket");
				goto Fail;
			}
		} else if (ucTcpSocketType == IFX_OS_TCP_SOCKTYPE_SERVER) {
			listen(iSockFd, 10);
		}
	}
	return iSockFd;

      Fail:
	return iSockFd;

}

/*
#ifndef FD_SETSIZE 
	#define FD_SETSIZE 256
#endif
*/
/*****************************************************************************
 *  Function Name :  IFX_OS_Select
 *  Description   :  Wrapper Function for the system call select
 *  Input Values  :  Read, Write and Exception file descriptors list
 *                :  Time to block in Millisecs
 *  Output Values :  None
 *  Return Value  :  Number of Fds set (Success) / -1 (Failure
 *  Notes         :
 *****************************************************************************/
PUBLIC int32
IFX_OS_Select(IN fd_set * pRdSelectFd,
	      IN fd_set * pWrSelectFd,
	      IN fd_set * pExSelectFd, IN int32 iTimeSec)
{
	int32 iNoFds = 0;
	struct timeval xTv;

	if (iTimeSec != (int32) NULL) {
		xTv.tv_sec = iTimeSec;
		xTv.tv_usec = 0;

		iNoFds =
		    select(FD_SETSIZE, pRdSelectFd, pWrSelectFd, pExSelectFd,
			   &xTv);
	} else {
		iNoFds =
		    select(FD_SETSIZE, pRdSelectFd, pWrSelectFd, pExSelectFd,
			   NULL);
	}
	return iNoFds;
}

/*****************************************************************************
 *  Function Name :  IFX_OS_GetHostIp
 *  Description   :  Function to get the local host IP Address 
 *  Input Values  :  Interface Name
 *  Output Values :  Pointer Host IP Address
 *  Return Value  : 
 *  Notes         : 
 *****************************************************************************/
PUBLIC char8 IFX_OS_GetHostIp(OUT char8 * pcHostIp)
{
	struct ifreq Interface;
	int iRetVal = 0, Fd;
	struct in_addr *pAddr;
	char8 *pcIfName = NULL;
#ifdef ATA
	(pcIfName = getenv("WAN")) ? pcIfName : "adm1";
#endif
#ifdef IIP
	(pcIfName = getenv("WAN")) ? pcIfName : "eth0";
#endif

	Fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (Fd < 0) {
		return -1;
	}
	memset(&Interface, 0, sizeof(struct ifreq));
	Interface.ifr_ifru.ifru_addr.sa_family = AF_INET;
	if (pcIfName) {
		strcpy(Interface.ifr_ifrn.ifrn_name, pcIfName);
	}

	iRetVal = ioctl(Fd, SIOCGIFADDR, &Interface);
	close(Fd);
	if (iRetVal < 0) {
		return -1;
	}
	Interface.ifr_ifru.ifru_addr.sa_family = AF_INET;
	pAddr = (struct in_addr *)&Interface.ifr_ifru.ifru_addr.sa_data[2];
	strcpy(pcHostIp, inet_ntoa(*pAddr));
	return iRetVal;
}

/*****************************************************************************
 *  Function Name :  IFX_OS_GetHostNetmask
 *  Description   :  Function to get the local host Netmask
 *  Input Values  :  Interface Name
 *  Output Values :  Pointer Host Network Mask
 *  Return Value  :
 *  Notes         :
 *****************************************************************************/
PUBLIC char8 IFX_OS_GetHostNetmask(OUT char8 * pcHostNetmask)
{
	struct ifreq Interface;
	int iRetVal = 0, Fd;
	struct in_addr *pAddr;
	char8 *pcIfName = NULL;
#ifdef ATA
	(pcIfName = getenv("WAN")) ? pcIfName : "adm1";
#endif
#ifdef IIP
	(pcIfName = getenv("WAN")) ? pcIfName : "eth0";
#endif

	Fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (Fd < 0) {
		return -1;
	}
	memset(&Interface, 0, sizeof(struct ifreq));
	Interface.ifr_ifru.ifru_addr.sa_family = AF_INET;

	if (pcIfName) {
		strcpy(Interface.ifr_ifrn.ifrn_name, pcIfName);
	}

	iRetVal = ioctl(Fd, SIOCGIFNETMASK, &Interface);
	close(Fd);
	if (iRetVal < 0) {
		return -1;
	}
	Interface.ifr_ifru.ifru_addr.sa_family = AF_INET;
	pAddr = (struct in_addr *)&Interface.ifr_ifru.ifru_addr.sa_data[2];
	strcpy(pcHostNetmask, inet_ntoa(*pAddr));
	return iRetVal;
}

/************************************************************************
 *  Function Name: IFX_OS_SetIp
 *  Description  : This function sets the IP address to a particular 
 *                 Interface 
 *  Input Values : Pointer to the IP address to be added
 *               : Interface Name
 *  Output Values: None
 *  Return Value : 0 or -1
 *  Notes		  :
 ************************************************************************/
PUBLIC int32 IFX_OS_SetIp(IN char8 * pcIpAdd)
{
	struct ifreq Interface;
	int32 iRetVal = -1;
	int32 Fd;
	char8 *pcIfName = NULL;
#ifdef ATA
	(pcIfName = getenv("WAN")) ? pcIfName : "adm1";
#endif
#ifdef IIP
	(pcIfName = getenv("WAN")) ? pcIfName : "eth0";
#endif

	if (pcIfName == NULL) {
		return iRetVal;
	}

	Fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (Fd < 0) {
		return -1;
	}
	Interface.ifr_ifru.ifru_addr.sa_family = AF_INET;
	inet_pton(AF_INET, pcIpAdd,
		  (struct in_addr *)&Interface.ifr_addr.sa_data[2]);
	strcpy(Interface.ifr_ifrn.ifrn_name, pcIfName);
	iRetVal = ioctl(Fd, SIOCSIFADDR, &Interface);
	close(Fd);
	return iRetVal;
}

/************************************************************************
 *  Function Name: IFX_OS_SetNetmask
 *  Description  : This function sets the Netmask to a particular
 *                 Interface 
 *  Input Values : Pointer to the Netmask to be added
 *               : Interface Name
 *  Output Values: None
 *  Return Value : 0 or -1
 *  Notes        :
 ************************************************************************/
PUBLIC int32 IFX_OS_SetNetmask(IN char8 * pcNetmask)
{
	struct ifreq Interface;
	int32 iRetVal = -1;
	int32 Fd;
	char8 *pcIfName = NULL;
#ifdef ATA
	(pcIfName = getenv("WAN")) ? pcIfName : "adm1";
#endif
#ifdef IIP
	(pcIfName = getenv("WAN")) ? pcIfName : "eth0";
#endif
	if (pcIfName == NULL) {
		return iRetVal;
	}

	Fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (Fd < 0) {
		return -1;
	}
	Interface.ifr_ifru.ifru_addr.sa_family = AF_INET;
	inet_pton(AF_INET, pcNetmask,
		  (struct in_addr *)&Interface.ifr_addr.sa_data[2]);
	strcpy(Interface.ifr_ifrn.ifrn_name, pcIfName);
	iRetVal = ioctl(Fd, SIOCSIFNETMASK, &Interface);
	close(Fd);
	return iRetVal;
}

/************** File Operations ****************/
