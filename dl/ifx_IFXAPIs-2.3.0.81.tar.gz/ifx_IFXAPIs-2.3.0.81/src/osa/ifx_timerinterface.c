/**************************************************************************
** FILE NAME     : IFX_TimerInterface.c
** PROJECT       : TR69
** MODULES       : Common Libs.
** SRC VERSION   : V2.0 
** DATE          : 15-12-2004
** AUTHOR        : TR69 Team
** DESCRIPTION   : Wrapper functions for timer library.
** REFERENCE     : Coding guide lines.
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author      $Comment
***********************************************************************/
#include <stdio.h>

#include <unistd.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>

#include "ifx_types.h"
#include "ifx_osa_common.h"
#include "ifx_tlib_import.h"
#include "ifx_debug.h"
#include "ifx_ipc.h"
#include "ifx_timerinterface.h"

#define IFIN_TR69_TIMER_FIFO_NAME  "TimerFifo"
#define IFIN_TR69_MAX_TIMERS      15
#define IFIN_TR69_TIMER_PERMS    0666

extern char8 vcOsModId;
extern int32 viTR69RdFd;

typedef int32 e_IFIN_TR69_Ecode;

e_IFIN_TR69_Return IFIN_TR69_DeleteTimerFromList(IN uint16);

STATIC e_IFIN_TR69_Return
IFIN_TR69_GetTimerFromList(OUT x_IFIN_TR69_TimerInfo ** pxTimerInfo);

x_IFIN_TR69_TimerInfo xTimerInfo[IFIN_TR69_MAX_TIMERS];

void IFIN_TR69_TimeOutHandler(x_IFIN_TR69_TimerInfo *);

EXTERN int32 IFIN_TR69_OpenFifo(char8 * szPathName,
				int32 iOFlag, int32 * piReadFd);

EXTERN int32 IFIN_TR69_CreateFifo(char8 * szPathName, int32 iMode);

/* globals */

int32 iTimerWriteFd;

/******************************************************************
*  Function Name  :  IFIN_TR69_TimerInit
*  Description      :  initializes the endpoint info
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  void
*  Notes      : 
*********************************************************************/
PUBLIC e_IFIN_TR69_Return IFIN_TR69_TimerInit()
{
	uchar8 iCount;

	if (IFIN_TLIB_TimersInit(IFIN_TR69_MAX_TIMERS) == IFIN_TLIB_FAIL) {
		return IFIN_TR69_FAILURE;
	}

	/* initialize the timer list */
	for (iCount = 0; iCount < IFIN_TR69_MAX_TIMERS; iCount++) {
		xTimerInfo[iCount].cIsFree = 'y';
	}
	return IFIN_TR69_SUCCESS;
}

/******************************************************************
*  Function Name  :  IFIN_TR69_StartTimer
*  Description    :  initializes the endpoint info
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  void
*  Notes          : 
*********************************************************************/
PUBLIC e_IFIN_TR69_Return IFIN_TR69_StartTimer(IN uint32 uiTimeOutValue,	/* milli seconds */
					       IN void
					       *pfn_IFIN_TR69_CallBackFn,
					       IN void *pCallBackFnParam,
					       OUT uint16 * punTimerId,
					       OUT uint32 * peEcode)
{
	uint16 unTempTimerId;
	x_IFIN_TR69_TimerInfo *pxTimerInfo;

	if (IFIN_TR69_GetTimerFromList(&pxTimerInfo) == IFIN_TR69_FAILURE) {
		IFX_DBGA(vcOsModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
			 "Timer List Exhausted");
		return IFIN_TR69_FAILURE;
	}

	/* construct the timer structure */
	pxTimerInfo->pfnCallBackFn = pfn_IFIN_TR69_CallBackFn;
	pxTimerInfo->pCallBackFnParam = pCallBackFnParam;

	/* start the timer for so many milli seconds */  
	if (IFIN_TLIB_StartTimer(&unTempTimerId, uiTimeOutValue,
				 IFIN_TLIB_ONE_TIME_TIMER,
				 (void *)IFIN_TR69_TimeOutHandler,
				 pxTimerInfo) == IFIN_TLIB_FAIL) {
		IFX_DBGA(vcOsModId, IFX_DBG_LVL_ERROR, IFX_DBG_TIMER_START_ERR,
			 "start Timer", uiTimeOutValue);
		return IFIN_TR69_FAILURE;
	}
	*punTimerId = unTempTimerId;
	/* store the timer id */
	pxTimerInfo->unTimerId = unTempTimerId;

	return IFIN_TR69_SUCCESS;
}

/******************************************************************
*  Function Name  :  IFIN_TR69_StopTimer
*  Description    :  initializes the endpoint info
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  void
*  Notes          : 
*********************************************************************/

PUBLIC e_IFIN_TR69_Return IFIN_TR69_StopTimer(IN uint16 unTimerId)
{
	if (unTimerId == 0) {
		IFX_DBGA(vcOsModId, IFX_DBG_LVL_LOW, IFX_DBG_STR,
			 "Stop Timer Timer id 0");
		return IFIN_TR69_FAILURE;
	}

	if (IFIN_TLIB_StopTimer(unTimerId) == IFIN_TLIB_FAIL) {
		IFX_DBGA(vcOsModId, IFX_DBG_LVL_ERROR, IFX_DBG_TIMER_ERR,
			 "Stop Timer Failed", unTimerId);
		return IFIN_TR69_FAILURE;
	}

	/* delete timer info structure from the list */
	if (IFIN_TR69_DeleteTimerFromList(unTimerId) == IFIN_TR69_FAILURE) {
		IFX_DBGA(vcOsModId, IFX_DBG_LVL_ERROR, IFX_DBG_TR69_ERR,
			 unTimerId, "no timer with this id");
	}

	return IFIN_TR69_SUCCESS;
}

/******************************************************************
*  Function Name  :  IFIN_TR69_TimeOutHandler
*  Description      :  initializes the endpoint info
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  void
*  Notes      : 
*********************************************************************/

PUBLIC void IFIN_TR69_TimeOutHandler(IN x_IFIN_TR69_TimerInfo * pxTimerInfo)
{
	IFX_DBGA(vcOsModId, IFX_DBG_LVL_HIGH, IFX_DBG_TR69_ERR,
		 pxTimerInfo->unTimerId, "TimerID");
	if (IFX_IPC_SendMsg
	    (viTR69RdFd, IFX_IPC_APP_ID_TR69, IFX_IPC_APP_ID_TR69,
	     sizeof(pxTimerInfo), IFIN_IPC_TR69_TIMER,
	     (char8 *) & pxTimerInfo) == IFX_IPC_FAIL) {
		IFX_DBGA(vcOsModId, IFX_DBG_LVL_ERROR, IFX_DBG_FIFO_WRITE_ERR,
			 IFX_IPC_FAIL);
	}
	return;
}

/******************************************************************
*  Function Name  :  IFIN_TR69_ProcessTimerMsg
*  Description      :  initializes the endpoint info
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  void
*  Notes      : 
*********************************************************************/

PUBLIC void IFIN_TR69_ProcessTimerMsg(x_IFIN_TR69_TimerInfo * pxTimerInfo)
{
	if (pxTimerInfo == NULL) {
		IFX_DBGA(vcOsModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "<TR69-TUTimerIface> In IFIN_TR69_ProcessTimerMsg pxTimerInfo is NULL");
		return;
	}

	IFX_DBGA(vcOsModId, IFX_DBG_LVL_HIGH, IFX_DBG_TR69_ERR,
		 pxTimerInfo->unTimerId, "Process TimerID");

	/* delete the timerinfo from the list */
	pxTimerInfo->cIsFree = 'y';
	pxTimerInfo->unTimerId = 0;

	/* call the function along with the parameters */
	if (pxTimerInfo->pfnCallBackFn == NULL) {
		IFX_DBGA(vcOsModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "<TR69-TUTimerIface> In IFIN_TR69_ProcessTimerMsg pfnCallBackFn is NULL");
		return;
	}
	if (pxTimerInfo->pCallBackFnParam == NULL) {
		IFX_DBGA(vcOsModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "<TR69-TUTimerIface> In ProcessTimerMsg pCallBackFnParam is NULL");
	}
	pxTimerInfo->pfnCallBackFn(pxTimerInfo->pCallBackFnParam);

	return;
}

/******************************************************************
*  Function Name  :  IFIN_TR69_DeleteTimerFromList
*  Description      :  initializes the endpoint info
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  void
*  Notes      : 
*********************************************************************/
e_IFIN_TR69_Return IFIN_TR69_DeleteTimerFromList(IN uint16 unTimerId)
{
	uchar8 iCount;

	for (iCount = 0; iCount < IFIN_TR69_MAX_TIMERS; iCount++) {
		if (xTimerInfo[iCount].unTimerId == unTimerId) {
			xTimerInfo[iCount].cIsFree = 'y';
			xTimerInfo[iCount].unTimerId = 0;
			return IFIN_TR69_SUCCESS;
		}
	}

	return IFIN_TR69_FAILURE;
}

/******************************************************************
*  Function Name  :  IFIN_TR69_GetTimerFromList
*  Description      :  initializes the endpoint info
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  void
*  Notes      : 
*********************************************************************/
STATIC e_IFIN_TR69_Return
IFIN_TR69_GetTimerFromList(OUT x_IFIN_TR69_TimerInfo ** pxTimerInfo)
{
	uchar8 iCount;

	for (iCount = 0; iCount < IFIN_TR69_MAX_TIMERS; iCount++) {
		if (xTimerInfo[iCount].cIsFree == 'y') {
			xTimerInfo[iCount].cIsFree = 'n';
			*pxTimerInfo = &xTimerInfo[iCount];
			return IFIN_TR69_SUCCESS;
		}
	}

	return IFIN_TR69_FAILURE;
}

PUBLIC e_IFIN_TR69_Return IFIN_TR69_StartDnsTimer(IN uint32 uiTimeOutValue,	/* milli seconds */
						  IN void
						  *pfn_IFIN_TR69_CallBackFn,
						  IN void *pCallBackFnParam,
						  OUT uint16 * punTimerId,
						  OUT uint32 * peEcode)
{
	uint16 unTempTimerId;
	x_IFIN_TR69_TimerInfo *pxTimerInfo;

	/* convert the timeout value from milliseconds to microseconds */
	uiTimeOutValue *= 1000;

	if (IFIN_TR69_GetTimerFromList(&pxTimerInfo) == IFIN_TR69_FAILURE) {
		IFX_DBGA(vcOsModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Timer List Exhausted");
		return IFIN_TR69_FAILURE;
	}

	/* construct the timer structure */
	pxTimerInfo->pfnCallBackFn = pfn_IFIN_TR69_CallBackFn;
	pxTimerInfo->pCallBackFnParam = pCallBackFnParam;

	/* start the timer for so many micro seconds */
	if (IFIN_TLIB_StartTimer(&unTempTimerId, uiTimeOutValue,
				 IFIN_TLIB_ONE_TIME_TIMER,
				 (void *)pfn_IFIN_TR69_CallBackFn,
				 pCallBackFnParam) < 0) {
		IFX_DBGA(vcOsModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Start Timer fail");
		return IFIN_TR69_FAILURE;
	}
	*punTimerId = unTempTimerId;
	/* store the timer id */
	pxTimerInfo->unTimerId = unTempTimerId;
	return IFIN_TR69_SUCCESS;
}
