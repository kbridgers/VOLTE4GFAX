/*****************************************************************************
** FILE NAME     : IFX_TR69__Common.h
** PROJECT       : TR69
** MODULES       : Common Libs
** SRC VERSION   : V1.0
** DATE          : 14-01-2004
** AUTHOR        : TR69 team
** DESCRIPTION   :
** REFERENCE     : Coding guide lines.
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author      $Comment
*****************************************************************************/
#ifndef		__IFIN_TR69_TYPES_H__
#define		__IFIN_TR69_TYPES_H__

#define		IN
#define		OUT
#define		IN_OUT

#define		PUBLIC
#define		EXTERN	extern
#define		STATIC	static

#define		IFIN_TR69_NULL	NULL

#define		PRINT		printf
// This macro should be in sync with the macro defined in osa/timer_driver/ifx_timer_driver.h
#ifndef IFX_TIMER_DRV_MAJOR
#define IFX_TIMER_DRV_MAJOR             230
#endif
typedef char char8;
typedef unsigned char uchar8;
typedef char int8;
typedef unsigned char uint8;
typedef short int int16;
typedef unsigned short int uint16;
typedef int int32;
typedef unsigned int uint32;
typedef long int64;
typedef unsigned long int uint64;
typedef float float32;
typedef double float64;
typedef void IFIN_TR69_Void;

#endif				/* __IFIN_TR69_TYPES_H__ */
