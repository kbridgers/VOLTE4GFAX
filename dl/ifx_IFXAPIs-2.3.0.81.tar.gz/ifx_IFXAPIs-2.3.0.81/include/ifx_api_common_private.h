/* ============================================================================
 * Copyright (C) 2004 - Infineon Technologies.
 *
 * All rights reserved.
 * ============================================================================
 *
 * ============================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ============================================================================
 *
 * Revision History:
 *      - 2004/07/20, TC Chen
 *         init version
 *      - 2005/10/25, Sumedh ::[ 510251:sumedh Support for DoS Attacks, ALGs, QoS, Policy based Routing ]
 *
 * ============================================================================
 */

/*
 * ===========================================================================
 *                           INCLUDE FILES
 * ===========================================================================
 */

/*! \file ifx_api_ipt_common_private.h 
    \brief This file defined function prototypes for iptables rule configuration
*/

#ifndef _IFX_API_IPT_COMMON_PRIVATE_H_
#define _IFX_API_IPT_COMMON_PRIVATE_H_

#ifndef __be16
#define __be16 short int
#endif

#include <linux/if_ether.h>
#include <netinet/in.h>
#include <linux/if.h>
#include <stdlib.h>

#include "ifx_common.h"
#include "ifx_api_ipt_common.h"

/*
 * ===========================================================================
 *                           GLOBAL DEFINITIONS
 * ===========================================================================
 */

/*! \def ACCEPT  
    \brief set value of ACCEPT  
*/
#define ACCEPT        			0	/*!< value is 0. */

/*! \def DROP
    \brief set value of DROP
*/
#define DROP          			1	/*!< value is 1. */

/*! \def RETURN        
    \brief set value of RETURN        
*/
#define RETURN        			2	/*!< value is 2. */

/*! \def SNAT          
    \brief set value of SNAT          
*/
#define SNAT          			3	/*!< value is 3. */

/*! \def DNAT          
    \brief set value of DNAT          
*/
#define DNAT          			4	/*!< value is 4. */

/*! \def MASQUERADE    
    \brief set value of MASQUERADE    
*/
#define MASQUERADE    			5	/*!< value is 5. */

/*! \def REDIRECT
    \brief set value of REDIRECT
*/
#define REDIRECT			6	/*!< value is 6. */

/*! \def IFX_NAPT_SNAT 
    \brief set value of IFX_NAPT_SNAT 
*/
#define IFX_NAPT_SNAT 			7	/*!< value is 7. */

/*! \def  IFX_FW_DENY_WAN_IP_INPUT     
    \brief set value of  IFX_FW_DENY_WAN_IP_INPUT     
*/
#define IFX_FW_DENY_WAN_IP_INPUT     	8	/*!< value is 8. */

/*! \def IFX_FW_DENY_LAN_IF_INPUT     
    \brief set value of IFX_FW_DENY_LAN_IF_INPUT     
*/
#define IFX_FW_DENY_LAN_IF_INPUT     	9	/*!< value is 9. */

/*! \def IFX_NAPT_TO_LAN
    \brief set value of IFX_NAPT_TO_LAN
*/
#define IFX_NAPT_TO_LAN			10	/*!< value is 10. */

/*! \def IFX_FW_ACCEPT_WAN_IP_INPUT  
    \brief set value of IFX_FW_ACCEPT_WAN_IP_INPUT  
*/
#define IFX_FW_ACCEPT_WAN_IP_INPUT  	11	/*!< value is 11. */

/*! \def  IFX_FW_ACCEPT_LAN_IP_INPUT  
    \brief set value of  IFX_FW_ACCEPT_LAN_IP_INPUT  
*/
#define IFX_FW_ACCEPT_LAN_IP_INPUT  	12	/*!< value is 12. */

/*! \def IFX_FW_ACCEPT_LAN_IP_OUTPUT  
    \brief set value of IFX_FW_ACCEPT_LAN_IP_OUTPUT  
*/
#define IFX_FW_ACCEPT_LAN_IP_OUTPUT  	13	/*!< value is 13. */

/*! \def IFX_FW_SERVICES_ACL
    \brief set value of IFX_FW_SERVICES_ACL
*/
#define IFX_FW_SERVICES_ACL		14	/*!< value is 14. */

/*! \def NAPT_ROUTE
    \brief set value of NAPT_ROUTE
*/
#define NAPT_ROUTE				15	/*!< value is 15. */
	//510251: sumedh (policy based routing)

/*! \def GET_CHAIN_STATUS         
    \brief set value of GET_CHAIN_STATUS         
*/
#define GET_CHAIN_STATUS         0	/*!< value is 0. */

/*! \def GET_SINGLE_RULE_STATUS   
    \brief set value of GET_SINGLE_RULE_STATUS   
*/
#define GET_SINGLE_RULE_STATUS   1	/*!< value is 1. */

/*! \def IPT_TMP_FILE 
    \brief set value of IPT_TMP_FILE 
*/
#define IPT_TMP_FILE "/tmp/ipt.tmp"	/*!< value is "/tmp/ipt.tmp" */

/*! \def FIREWALL_TMP_FILE 
    \brief set value of FIREWALL_TMP_FILE 
*/
#define FIREWALL_TMP_FILE "/tmp/fw.tmp"	/*!< value is "/tmp/fw.tmp"  */

/*
 * ============================================================================
 *                              STRUCTURES
 * ============================================================================
 */

/*
 * ===========================================================================
 *                           EXPORTED FUNCTIONS
 * ===========================================================================
 */

/*! 
     \brief  boolean function 
     \param[in] type TBD 
     \param[in]  *ChainName TBD
     \return TRUE / FALSE
*/
bool IFX_FLUSH_CHAIN(int type, char *ChainName);	/*!< this function set chain rules */

/*! 
     \brief  boolean function 
	\param[in] type TBD 
	\param[in]  *ChainName TBD
	\return TRUE / FALSE
*/
bool IFX_CREATE_SINGLE_CHAIN(int type, char *ChainName);	/*!< this function create single chain */

/*! 
     \brief  boolean function 
	\param[in] type TBD
	\param[in]  *ChainName TBD
	\return TRUE / FALSE
*/

bool IFX_IPT_CREATE_SINGLE_CHAIN(int type, char *ChainName);	/*!< this function set the rules for ipt single chain */

/*! 
     \brief  boolean function 
	\param[in] type 
	\param[in]  *ChainName
	\return TRUE / FALSE
*/

bool IFX_IPT_FLUSH_CHAIN(int type, char *ChainName);	/*!< this function set the rules for ipt flush chain rules */

/*! 
     \brief  boolean function 
	\param[in] operation TBD 
	\param[in] type TBD 
	\param[in] *pbEnable TBD
	\param[in]  *ChainName TBD
	\param[out] rule TBD
	\param[in] target TBD
	\return TRUE / FALSE
*/
bool IFX_IPT_GET_RULE_STATUS(int type, int operation, char *ChainName, bool * pbEnable, P_IFX_IPT_RULE rule, int target);	/*!< this function get ipt rule status */

/*! 
     \brief  boolean function
	\param[in] type  TBD
	\param[in] operation TBD
	\param[in]  *ChainName TBD
	\param[out] pCfg TBD
	\param[in] *piEnteriesSize TBD
	\param[in] target TBD
	\return TRUE / FALSE
*/

bool IFX_IPT_SET_RULES(int type, int operation, char *ChainName, P_IFX_IPT_RULE pCfg, int *piEnteriesSize, int target);	/*!< this function set the rules for ipt */

/*! 
     \brief  boolean function 
	\param[in] type  TBD 
	\param[in] operation  TBD
	\param[in]  *ChainName TBD
	\param[in] *pbEnable TBD
	\return TRUE / FALSE
*/

bool IFX_IPT_SET_CHAIN_ENABLE(int type, int operation, char *ChainName, bool * pbEnable);	/*!< this function set the rules for ipt */

/*! 
     \brief  boolean function 
	\param[in] type TBD 
	\param[in]  *ChainName TBD
	\param[in]  *pBuffer TBD
	\param[in] size TBD
	\param[in] *pRetSize TBD
	\param[in] target TBD
	\return TRUE / FALSE 
*/

bool IFX_IPT_GET_RULES(int type, char *ChainName, char *pBuffer, int size, int *pRetSize, int target);	/*!< this function get rules of ipt */

#endif				/* _IFX_API_IPT_COMMON_PRIVATE_H_ */
