
/* 
** =============================================================================
**   FILE NAME        : ifx_basic_types.h
**   PROJECT          : AMAZON MAPI
**   DATE             : 19-Jun-2006
**   AUTHOR           : Amazon API Team
**   DESCRIPTION      : This file contains the type definitions of the basic types used in 
			Management API Implementation.

**   REFERENCES       : 
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/

/*! \file ifx_basic_types.h
    \brief This file contains the type definitions of the basic types used in Management API Implementation.	
*/

#ifndef _IFX_BASIC_TYPES_H
#define _IFX_BASIC_TYPES_H
#include <ifx_config.h>

#ifndef __IFIN_TR69_TYPES_H__
#ifndef CONFIG_FEATURE_IFX_WIRELESS_TSC

/*! \brief int8
*/
typedef char int8;

/*! \brief int16
 */
typedef short int int16;

/*! \brief int32
*/
typedef int int32;

/*! \brief uint8
*/
typedef unsigned char uint8;

/*! \brief uint16
*/
typedef unsigned short uint16;

/*! \brief uint32
*/
typedef unsigned int uint32;

/*typedef unsigned long uint64;*/

/*! \brief char8 
*/
typedef char char8;

/*! \brief uchar8
*/
typedef unsigned char uchar8;
#else

/*! \brief int8
*/
#define int8 char

/*! \brief int16
*/
#define int16 short int

/*! \brief int32
*/
#define int32 int

/*! \brief uint8
*/
#define uint8 unsigned char

/*! \brief uint16
*/
#define uint16 unsigned short

/*! \brief uint32
*/
#define uint32 unsigned int

/*! \brief char8
*/
#define char8 char

/*! \brief uchar8
*/
#define uchar8 unsigned char

#endif				// CONFIG_FEATURE_IFX_WIRELESS_TSC
#endif				/* __IFIN_TR69_TYPES_H__ */

#define	PUBLIC

/*! \brief EXTERN
    \brief extern
*/
#define	EXTERN			extern
//#define       STATIC                  static
#define IN
#define OUT
#define IN_OUT

/*! \brief PRINT
    \brief printf
*/
#define	PRINT			printf

/* updated by shweta */
/*! \brief nullptr
    \brief Null pointer
*/
#define nullptr(Type)	(Type *)NULL

/* updated by radvajesh*/

#ifndef __IFIN_TR69_TYPES_H__
#ifndef CONFIG_FEATURE_IFX_WIRELESS_TSC

/*! \brief int64
*/
typedef long long int int64;

/*! \brief uint64
*/
typedef unsigned long long int uint64;

/*! \brief float32
*/
typedef float float32;

/*! \brief float64
*/
typedef double float64;

/*! \brief double32
*/
typedef float double32;

/*! \brief double64
*/
typedef double double64;

/*! \brief long32
*/
typedef long long32;

/*! \brief ulong32
*/
typedef unsigned long ulong32;
#else
/*! \brief int64
*/
#define int64 long long int
//#define uint64 unsigned long long int

/*! \brief float32
*/
#define float32 float

/*! \brief float64
*/
#define float64 double

/*! \brief double32
*/
#define double32 float

/*! \brief double64
*/
#define double64 double

/*! \brief long32
*/
#define long32 long

/*! \brief ulong32
*/
#define ulong32 unsigned long
#endif				// CONFIG_FEATURE_IFX_WIRELESS_TSC
#endif				/* __IFIN_TR69_TYPES_H__ */

#endif				/* ] _IFX_BASIC_TYPES_H */
