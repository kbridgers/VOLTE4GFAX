/*
** =============================================================================
**   FILE NAME        : ifx_api_structs.h
**   PROJECT          : AMAZON MAPI
**   DATE             : 19-Jun-2006
**   AUTHOR           : Amazon API Team
**   DESCRIPTION      : This file contains all the structure definitions required for the
			Management API Implementation.

**   REFERENCES       :
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          :
**   $Date            $
Author                         $Comment
**
** ============================================================================
*/

/*! \file ifx_api_structs.h
    \brief This file contains all the structure definitions required for the Management API Implementation.
*/

#ifndef _IFX_API_STRUCTS_H
#define _IFX_API_STRUCTS_H

#include <linux/types.h>
#include <netinet/in.h>
#include "atm.h"

#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
#include <drv_dsl_cpe_api.h>
//#include "drv_dsl_cpe_api_config.h"
//#include <dsl_cpe_control.h>
#include <drv_dsl_cpe_api_ioctl.h>
#include <drv_dsl_cpe_api_adslmib.h>
#include <drv_dsl_cpe_api_adslmib_ioctl.h>
#include <drv_dsl_cpe_api_g997.h>
#endif				// CONFIG_PACKAGE_IFX_DSL_CPE_API

/* included for definition of bool */
#ifndef bool
#define bool char
#endif

/*!
    \brief Structure describing the Name Value Pair.
*/
typedef struct {
	char fieldname[MAX_TAG_NAME_LEN];	/*!< Field Name */
	char value[MAX_TAG_VALUE_LEN];	/*!< Value */
} IFX_NAME_VALUE_PAIR;

/*!
    \brief This data structure is used for internal identifier for the internal object representation. This consists of the object name and instance id. The CPE_ID created for an object remains unique for lifetime of that object instance.
*/
typedef struct cpe_id {
	char8 secName[MAX_TAG_LEN];	/*!< Object or Section Name. */
	uint32 Id;		/*!< Internal Instance Number for the
				   Object/Section Name. */
} CPE_ID;

/*!
    \brief This is the data structure for complete identity of an object instance.
*/
typedef struct ifx_id {
	CPE_ID cpeId;		/*!< CPE Identifier (object name and instance
				   Id). */
	CPE_ID pcpeId;		/*!< Parent CPE Identifier (object name and
				   instance) */
	uint32 config_owner;	/*!< Configuration Owner: Possible values are
				   IFX_WEB, IFX_TR69, IFX_CLI and so on. */
	char tr69Id[MAX_TR69_ID_LEN];	/*!< Hierarchical TR-069 Identifier as
					   per TR-xxx data model tree. */
        uint32 owner;
} IFX_ID;

/*!
    \brief This is the data structure for Device Information. This is defined in IGD Data Model defined by DSL Forum as well.
*/
typedef struct device_info {
	IFX_ID iid;		/*!< Instance Id of Device Information Object.
				 */
	char8 manufacturer[MAX_MANUFACTURER_LEN];	/*!< Manufacturer Name of CPE
							   device. */
	char8 oui[MAX_OUI_LEN];	/*!< IEEE OUI of Vendor. */
	char8 model_name[MAX_MODEL_LEN];	/*!< Model name of CPE Device. */
	char8 description[MAX_DESCRIPTION_LEN];	/*!< Short description about
						   CPE device. */
	char8 friendly_name[MAX_DESCRIPTION_LEN];	/*!< Friendly Name of
						   CPE device. */
	char8 product_class[MAX_PROD_CLASS_LEN];	/*!< Product class of the
							   device. */
	char8 serial_number[MAX_SERIAL_NUM_LEN];	/*!< Serial Number of the
							   device. */
	char8 hw_ver[MAX_VER_LEN];	/*!< Hardware version of the CPE device. */
	char8 sw_ver[MAX_VER_LEN];	/*!< Software version of the CPE device. */
	char8 fw_ver[MAX_VER_LEN];	/*!< Firmware version of the CPE device. */
	char8 sysContact[MAX_SYS_CONTACT_LEN];	/*!< System Contact Name */
	char8 sysName[MAX_SYS_NAME_LEN];	/*!< System Name */
	char8 sysLocation[MAX_SYS_LOCATION_LEN];	/*!< System Location */
	char8 sysObjId[MAX_SYS_OBJID_LEN];	/*!< System Object Id */
	void *options;		/*!< Any other optional information about the
				   device. */
	char8 extra_hw_ver[MAX_VER_LEN];	/*!< Additional Hardware Sub versions
						   etc. */
	char8 extra_sw_ver[MAX_VER_LEN];	/*!< Additional Software version info
						   like patch numbers, sub-version etc.
						 */
	char8 igd_spec_ver[SPEC_VER_LEN];	/*!< IGD Specs Version No. as per DSL
						   Forum. */
	char8 provisioning_info[MAX_PROVISION_LEN];	/*!< Provisioning info of
							   device. */
	uint32 uptime;		/*!< Up time of device. */
	uint32 sysServices;	/*!< System Services. */
	time_t first_use_date;	/*!< First Usage Date of CPE Device. */
	char8 model_number[MAX_MODEL_NUM_LEN];	/*!< Model No. - For TR-064
						   Model */
	char8 tr64_url[MAX_TR64_URL_LEN];	/*!< TR-064 URL */
} DEVICE_INFO;

/*!
    \brief This is the data structure for the IP address and NetMask.
*/
typedef struct ip_mask {
	IFX_ID iid;		/*!< Instance ID of IP_MASK object. */
	struct in_addr ip;	/*!< IP address of IP_MASK object. */
	struct in_addr mask;	/*!< Subnet mask in IP_MASK object */
} IP_MASK;


typedef struct ip6_mask {
        IFX_ID iid;             /*!< Instance ID of IP_MASK object. */
        struct in6_addr ip6;      /*!< IP address of IP_MASK object. */
        int32 prefixlen;    
} IP6_MASK;

typedef struct ip6_addr_string {
	IFX_ID iid;		/*!< Instance ID of IP_MASK object. */
	struct in6_addr ip;	/*!< IP address of IP_MASK object. */
	int32 prefix_len;	/*!< Subnet mask in IP_MASK object */
} IP6_ADDR_STRING;

typedef struct lan_ipv6_sl_config {
	IFX_ID iid;		/*!< Instance ID of LAN_IPv6_SL_Config */
	IP6_ADDR_STRING ip6Addr;	/*!< IPv6 Prefix and Length */
	IP6_ADDR_STRING gw6addr;	/*!< Gateway Address. */
	IP6_ADDR_STRING dnsv6Addr;	/*!< Gateway Address. */
	IP6_ADDR_STRING dnsv6SecAddr;	/*!< Secondary DNSv6 Server */
	int32 f_enable;		/*!< Enable Flag */
} LAN_IPv6_SL_Config;

typedef struct lan_ipv6_dhcpv6_config {
	IFX_ID iid;		/*!< Instance ID of LAN_IPv6_SL_Config */
	IP6_ADDR_STRING saddr;	/*!< Address pool start addr */
	IP6_ADDR_STRING eaddr;	/*!< Address pool end addr */
	IP6_ADDR_STRING dnsv6Addr;	/*!< Primary DNSv6 Server */
	IP6_ADDR_STRING dnsv6SecAddr;	/*!< Secondary DNSv6 Server */
	char *domainName;	/*!< Domain Name */
	int32 f_enable;		/*!< Enable Flag */
} LAN_IPv6_DHCPv6_Config;

/*!
    \brief Structure describing the IP address in dotted form.
*/
typedef struct ip_mask_dotted {
	IFX_ID iid;		/*!< Instance Id of IP_MASK_DOTTED */
	char8 ip[MAX_IP_MASK_LEN];	/*!< IP Address */
	char8 mask[MAX_IP_MASK_LEN];	/*!< NetMask */
} IP_MASK_DOTTED;

/*!
    \brief This is the data structure for host machine info.
*/
typedef struct lan_host_info {
	struct in_addr ipAddr;	/*!< IP address of host machine. */
	LAN_HOST_TYPE ipAddrType;	/*!< Type of Host machine. */
	int32 leaseTimeRem;	/*!< Lease Time Remaining. */
	char8 macAddr[MAX_MAC_ADDR_LEN];	/*!< MAC Address */
	char8 hostName[MAX_HOST_LEN];	/*!< Host Name */
	PHY_IF_TYPE phyIfType;	/*!< Physical Interface Type */
	LAN_HOST_STATUS status;	/*!< Host Status */
} LAN_HOST_INFO;

/*!
    \brief This is the data structure for the port range. The valid port number should be bounded to 0-65535. A port value of 0 means any port or a value which would be replaced by default within a given API.
*/
typedef struct port_range {
	int start_port;		/*!< Start port of TCP or UDP port range.
				   Valid value: 0-65535. A value of 0 means any
				   port or in certain API functions may allow
				   substitution with default port by the API. */
	int end_port;		/*!< End port of TCP or UDP port range. Valid
				   value: 0-65535. A value of 0 means any port
				   or in certain API functions may allow
				   substitution with default port by the API. */
} PORT_RANGE;

/*!
    \brief This is the data structure for the policy routes configured in the system.
*/
typedef struct policy_route {
	IFX_ID iid;		/*!< Instance ID of Policy Route object. */
	IP_MASK ip_dst;		/*!< IP Destination Address Subnet
				   (Addr/subnetmask). */
	struct in_addr gw;	/*!< IP address of the Gateway. A value of 0
				   means none specified. */
	char8 route_if[IFNAMSIZE];	/*!< Name of the output interface. A null
					   string means no output interface specified. */
	ROUTE_STATUS status;	/*!< Route status. */
	ROUTE_TYPE type;	/*!< Type of Route. */
	int32 rt_protocol;	/*!< Routing Protocol. */
	int32 metric;		/*!< Metric of the route. */
	int32 f_enable;		/*!< Whether this policy route is activated or
				   enabled. Valid values are: IFX_ENABLED and
				   IFX_DISABLED. */
	IP_MASK ip_src;		/*!< IP Source Address Subnet (Addr/subnet
				   mask). */
	PORT_RANGE src_ports;	/*!< Source Ports (0-65535). A value of 0
				   means any port. */
	PORT_RANGE dst_ports;	/*!< Destination Ports (0-65535). A value of 0
				   means any port. */
	int32 ip_p;		/*!< IP Protocol like TCP (6), UDP (17) as per
				   RFC 791. */
	uint8 tos;		/*!< IP TOS byte value. */
	char8 in_if[IFNAMSIZE];	/*!< Name of the input interface. */
	int32 mtuSize;		/*!< MTU Size */
	bool static_route;	/*!< flag which says if the route is static */
} POLICY_ROUTE;

/*!
    \brief This is the data structure for all the route entries in the route table of the device.
*/
typedef struct route_entry {
	IFX_ID iid;		/*!< Instance ID of ROUTE_ENTRY object. */
	IP_MASK ip_dst;		/*!< Destination IP address and subnet mask. */
	struct in_addr gw;	/*!< Gateway Address. */
	char8 route_if[IFNAMSIZE];	/*!< Routing Interface Name */
	ROUTE_STATUS status;	/*!< Status of Route. */
	ROUTE_TYPE type;	/*!< Type of Route. */
	int32 rt_protocol;	/*!< Routing Protocol. */
	int32 metric;		/*!< Metric of the route. */
	int32 f_enable;		/*!< Enable Flag */
	bool static_route;	/*!< flag which says if the route is static */
} ROUTE_ENTRY;

/*!
 * \brief This is the data structure for all the ipv6 static route entries in the route table of the device.
*/
typedef struct route6_entry {
	IFX_ID iid;		/*!< Instance ID of ROUTE6_ENTRY object. */
	IP6_ADDR_STRING ip_dst;	/*!< Destination IP address and subnet mask. */
	struct in6_addr gw;	/*!< Gateway Address. */
	char8 route_if[IFNAMSIZE];	/*!< Routing Interface Name */
	ROUTE_STATUS status;	/*!< Status of Route. */
	ROUTE_TYPE type;	/*!< Type of Route. */
	int32 rt_protocol;	/*!< Routing Protocol. */
	int32 metric;		/*!< Metric of the route. */
	int32 f_enable;		/*!< Enable Flag */
} ROUTE6_ENTRY;

/*!
    \brief This is the data structure for static or policy type route.
*/
typedef struct any_route_entry {
	char8 f_policy_route;	/*!< Flag deciding policy route or normal
				   route. */
	union {
		ROUTE_ENTRY route;	/*!< Normal Route. */
		POLICY_ROUTE policy_route;	/*!< Policy Route. */
	} ROUTE;		/*!< Layer3 Route */
} ANY_ROUTE_ENTRY;

/*!
    \brief This is the data structure for the RIP configuration.
*/
typedef struct rip_cfg {
	IFX_ID iid;		/*!< Instance ID of RIP_CFG object.  */
	int f_enable;		/*!< Whether RIP is enabled on the device.
				   IFX_ENABLED IFX_DISABLED */
	int fv6_enable;		/*!< Whether RIPng is enabled on the device.
				   IFX_ENABLED IFX_DISABLED */
	enum rip_mode supply_mode;	/*!< Supply mode for RIP - None, RIPv1, RIPv2
					   or RIPv1 and RIPv2. */
	enum rip_mode listen_mode;	/*!< Listen mode for RIP - None, RIPv1, RIPv2,
					   or RIPv1 and RIPv2. */
} RIP_CFG;

/*!
    \brief This is the data structure for the DHCP server configuration information.
*/
typedef struct dhcp_server_info {
	IFX_ID iid;		/*!< Instance ID of DHCP Server Info object. */
	char8 iface[IFNAMSIZE];	/*!< Interface */
	struct in_addr netmask;	/*!< Subnet mask of LAN. */
	int32 dhcp_mode;	/*!< Mode of DHCP - possible values
				   IFX_DISABLED: Disabled IFX_DHCP_SERVER_MODE:
				   DHCP Server IFX_DHCP_RELAY_MODE: DHCP Relay */
	struct in_addr start_ip;	/*!< Start IP address in DHCP assignable pool.
					 */
	struct in_addr end_ip;	/*!< End IP address in DHCP assignable pool. */
	char8 dhcp_domain_name[MAX_DOMAIN_NAME_LEN];	/*!< Domain name to
							   return to the
							   client. */
	int32 leasetime;	/*!< Time for which DHCP lease is valid. The
				   lease must be renewed by the client before
				   this time, else the lease expires. */
	struct in_addr ip_gw;	/*!< IP Address of Gateway. */
	struct in_addr resv_ip[MAX_DHCP_RESV_POOL_ADDR];	/*!< Reserved IP Addr */
	struct in_addr dns_servers[MAX_DNS_SERVERS];	/*!< DNS Servers */
} DHCP_SERVER_INFO;

/*!
    \brief This is the data structure for the DHCP Static lease reservation information.
*/
typedef struct ifx_mapi_dhcps_static_lease {
	IFX_ID iid;		/*!< Instance ID */
	bool enable;		/*!< DHCP static lease enable */
	char8 ipAddr[MAX_IP_MASK_LEN];	/*!< IP Address */
	char8 macAddr[MAX_MAC_ADDR_LEN];	/*!< MAC Address */
	char8 host[MAX_HOST_NAME];	/*!< Host name */
} IFX_MAPI_DHCPS_STATIC_LEASE;

/*!
    \brief This is the data structure for the DHCP assigned IP Address lease information.
*/

typedef struct dhcp_lease_info {
	IFX_ID iid;		/*!< Instance ID of LAN object. */
	char8 cli_id[MAX_MAC_ADDR_LEN];	/*!< DHCP client identifier - usually
					   MAC address. */
	struct in_addr ip;	/*!< IP address assigned to the client. */
	int32 lease_time_left;	/*!< Time left for the lease to expire in
				   seconds. */
	char8 host_name[MAX_HOST_NAME];
} DHCP_LEASE_INFO;

/*!
    \brief This is the data structure for the DHCP relay server configuration.
*/
typedef struct dhcp_relay_server {
	IFX_ID iid;		/*!< Instance ID of DHCP Relay Server. */
	struct in_addr dhcp_relay_server;	/*!< DHCP server IP address. */
	char8 server_if[IFNAMSIZE];	/*!< Interface over which to contact the DHCP
					   server specified. */
} DHCP_RELAY_SERVER;

/*!
    \brief This is the data structure for the DHCP relay configuration information.
*/
typedef struct dhcp_relay_info {
	IFX_ID iid;		/*!< Instance ID of DHCP Relay Info object. */
	int32 num_dhcpr_ifs;	/*!< Number of interfaces to listen on. */
	char8 dhcpr_ifs[IFNAMSIZE];	/*!< Array of DHCP relay listen interfaces. */
	int32 num_dhcp_servers;	/*!< Number of DHCP servers configured. */
	DHCP_RELAY_SERVER *dhcpr_servers;	/*!< Used when operating in DHCP relay
						   mode, provides the array of
						   configured DHCP servers. */
} DHCP_RELAY_INFO;

/*!
    \brief Structure describing the DHCP option.
*/
typedef struct dhcp_option {
	IFX_ID iid;		/*!< DHCP Option Object Identifier */
	char8 enable;		/*!< Enable flag */
	char8 request;		/*!< DHCP option request */
	uint8 tag;		/*!< DHCP option tag */
	char8 value[MAX_DHCPOPTION_VALUE_LEN];	/*!< DHCP Option value string */
} DHCP_OPTION;

/*!
    \brief Structure describing the DHCP Conditional Serving Pool.
*/
typedef struct dhcp_cond_serv_pool {
	IFX_ID iid;		/*!< Instance Id of DHCP Cond Serving Pool
				   Object */
	uint8 Enable;		/*!< Enable Flag */
	uint32 PoolOrder;	/*!< Order of Pool among instances */
	char8 SourceInterface[IFX_MAX_DHCP_SRC_INTF_LEN];	/*!< Source Interface */
	char8 VendorClassID[IFX_MAX_DHCP_ID_LEN];	/*!< Vendor Class Identifier */
	char8 ClientID[IFX_MAX_DHCP_ID_LEN];	/*!< Client Identifier */
	char8 UserClassID[IFX_MAX_DHCP_ID_LEN];	/*!< User Class Identifier */
	char8 Chaddr[MAX_MAC_ADDR_LEN];	/*!< CH (MAC) Address */
	char8 ChaddrMask[MAX_MAC_ADDR_LEN];	/*!< CH (MAC) Address Mask */
	uint8 LocallyServed;	/*!< Locally Served or Relayed */
	char8 MinAddress[MAX_IP_ADDR_LEN];	/*!< Start Pool Address */
	char8 MaxAddress[MAX_IP_ADDR_LEN];	/*!< End Pool Address */
	char8 ReservedAddresses[IFX_MAX_RESERVED_ADDR * MAX_IP_ADDR_LEN];	/*!<
										   Reserved
										   Addresses
										 */
	char8 SubnetMask[MAX_IP_ADDR_LEN];	/*!< Subnet Mask */
	char8 DNSServers[MAX_IP_ADDR_LEN * MAX_DNS_SERVERS];	/*!< DNS
								   Server
								   Address */
	char8 DomainName[MAX_DOMAIN_NAME_LEN];	/*!< Domain Name */
	char8 IPRouters[64];	/*!< Gateway IP address */
	int32 DHCPLeaseTime;	/*!< DHCP Lease Time */
	char8 DHCPServerIPAddress[MAX_IP_ADDR_LEN];	/*!< If Relayed, DHCP Server
							   IP Address */
} IFX_DHCP_COND_SERV_POOL;

/*!
    \brief Structure describing the IPsec Tunnel
*/
typedef struct ipsec_tunnel {
	IFX_ID iid;		/*!< Instance Id of IPsec Tunnel Object */
	uchar8 f_enable;	/*!< Enable Flag */
	char8 TunnelName[30];	/*!< Tunnel Name */
	char8 ike_mode[30];	/*!< IKE Mode */
	char8 wan_conn_if[MAX_CONN_NAME_LEN];	/*!< Input interface of the
						   tunnel. */
	char8 LeftSubnet[20];	/*!< My Subnet */
	char8 RightIP[MAX_IP_ADDR_LEN];	/*!< Peer Address */
	char8 RightSubnet[20];	/*!< Peer Subnet */
	char8 psksecret[30];	/*!< shared key */
	char8 esp_cipher[30];	/*!< esp encryption */
	char8 esp_hash[30];	/*!< esp hash */
	char8 ike_cipher[30];	/*!< ike encryption */
	char8 ike_hash[30];	/*!< ike hash */
	char8 ike_dh[30];	/*!< ike dh */
	char8 kmpprfalg[30];	/*!< PRF Algorithm */
	uint32 lifetime;	/*!< Lifetime of tunnel */
	uint32 retry;		/*!< Retry count */
} IFX_IPSEC_TUNNEL;

/*!
    \brief This is the data structure for complete information about IP Address, Subnet, Type of IP Address and its status.
*/
typedef struct ip_mask_type {
	IFX_ID iid;		/*!< Instance Identifier. */
	IP_MASK ip_mask;	/*!< IP Mask object. */
	IP_TYPE ip_type;	/*!< Type of IP Address. */
	struct in_addr gw;	/*!< Gateway IP Address */
	struct in_addr dns_servers[2];	/*!< DNS Server IP Address */
	char8 domainname[MAX_DOMAIN_NAME_LEN];	/*!< Domain Name */
	char8 conn_name[MAX_NAME_LEN];  /*!< Connection Name */
	char8 iface[IFNAMSIZE];	 /*!< Interface Name */
	int32 vip_enable; /*!< Flag to enable secondary ip interface(LAN) */	
	int32 f_enable;		/*!< Enabled or Disabled. */
} IP_MASK_TYPE;

/*!
    \brief This is the data structure for the LAN Ethernet Interface Configuration.
*/
typedef struct ethernet_interface_config {
	int32 f_enable;		/*!< Flag for enable or disable. */
	ETHERNET_STATUS status;	/*!< Status of Ethernet Interface. */
	char8 mac_addr[MAX_MAC_ADDR_LEN];	/*!< MAC Address of Ethernet
						   Interface. */
	int32 f_mac_addr_control;	/*!< MAC Address Control Enable Flag. */
	ETH_MAX_BIT_RATE bit_rate;	/*!< Maximum bit rate supported on this
					   Ethernet interface. */
	ETH_DUPLEX_MODE mode;	/*!< Mode: Half Duplex or Full Duplex. */
} ETHERNET_INTERFACE_CONFIG;

/*!
    \brief This is the data structure for PVC configuration.
*/
typedef struct pvc {
	int16 vpi;		/*!< Virtual Path Identifier. */
	int32 vci;		/*!< Virtual Circuit Identifier. */
} PVC;

/*!
    \brief This is the data structure for SVC configuration.
*/
typedef struct svc {
	int32 conn_id;		/*!< Connection ID of a SVC. */
	char8 name[MAX_NAME_SIZE];	/*!< SVC name. */
} SVC;

/*!
    \brief This union is used for representing a VCC of either types Permanent or Switched Virtual Circuit Connections.
*/
typedef union vcc {
	PVC pvc;		/*!< Permanent Virtual Connection. */
	SVC svc;		/*!< Switched Virtual Connection. */
} VCC;

/*!
    \brief This data structure is defined in Linux header file /usr/include/linux/atm.h. It contains all the parameters related to ATM traffic attributes.
*/
typedef struct atm_trafprm ATM_TRAFF_PARAMS;	/*!< This data structure is defined in Linux header file /usr/include/linux/atm.h. It contains all the parameters related to ATM traffic attributes.. */

/*! \sturc VLAN_CFG
    \brief structre containing the Reserved VLAD id's
*/      
typedef struct reserved_vlan {
	char8   ATM_VlanId[MAX_POOL_LIMIT];  /* !< atm vlan id's */ 
	char8   PTM_VlanId[MAX_POOL_LIMIT];   /* !< ptm vlan id's */ 
	char8   Mii0_VlanId[MAX_POOL_LIMIT];   /* !< eth0 vlan id's */ 
	char8   Mii1_VlanId[MAX_POOL_LIMIT];    /* !< eth1 vlan id's */ 
	char8   Portsep_VlanId[MAX_POOL_LIMIT];  /* !< common port vlan id's */ 
} RESERVED_VLAN_CFG;


//added for ptm n eth support
typedef struct wan_mode_cfg {
	char8 iface[IFNAMSIZE]; /*!< Interface name. */
	WAN_MODE mode;
} WAN_MODE_CFG;

/*!
    \brief This is the data structure for the VCC configuration in the system.
*/
typedef struct atm_vcc_info {
	IFX_ID iid;		/*!< Instance ID of ATM VCC Info. */
	char8 vcc_ch_name[MAX_NAME_LEN];
	int32 f_enable;		/*!< IFX Id of ATM_VCC_INFO */
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
	int32 autodetect;	 /*!< flag which indicates that this vcc configured through autodetect */
	int32 defaultentry;	/*!< flag which indicates that this vcc configured is default  */
#endif
	LINK_TYPE type;		/*!< Link Type of WAN Connection configured on this VC. */
	AAL_TYPE aal;		/*!< ATM AAL type. AAL5 and AAL0 are currently supported. */
	int32 fcs_preserved;	/*!< In case of an EoATM interface configured over this VC, whether to keep the EoATM FCS sequence. Usually, this is IFX_DISABLED since AAL5 has its own CRC. */
	VCC vc;			/*!< ATM virtual circuit being configured. Only PVC is supported currently. */
	VC_ENCAP encap;		/*!< Encapsulation, LLC (=1) or VC Mux (=0). */
	ATM_TRAFF_PARAMS txtp;	/*!< ATM Traffic parameters for Transmit (upstream direction). */
	DSL_LINK_STATUS link_status;	/*!< Status of DSL Link. */
	int32 autoconfig;	/*!< Auto configuration option for link. */
	uint32 tx_cells;	/*!< Number of ATM Cells transmitted counter. */
	uint32 rx_cells;	/*!< Number of ATM Cells received counter. */
	uint32 crc_errors;	/*!< No. of ATM cells received with CRC error. */
	char8 l2ifname[MAX_IF_NAME_LEN];	/*!< L2 interfae name. */
} ATM_VCC_INFO;

/*!
		\brief This is the data structure for DNS configuration for each WAN connection.
*/
typedef struct wan_dns_cfg {
	IFX_ID iid;		/*!< Instance ID of WAN connection. */
	uint32 DNS_enabled;	/*!< Whether or not the device should attempt to query a DNS server across this connection. Valid values are IFX_ENABLED and IFX_DISABLED */
	uint32 DNS_override_allowed;	/*!< Whether or not a manually set, non-empty DNS server address can be overridden by a DNS entry received from the WAN. Valid values are IFX_ENABLED and IFX_DISABLED */
	struct in_addr dns_servers[MAX_DNS_SERVERS];	/*!< DNS servers */
} WAN_DNS_CFG;

/*!
    \brief This is the data structure for the wan configuration.
*/
typedef struct wan_common_cfg {
	IFX_ID iid;		/*!< Instance ID of WAN connection. */
	int32 f_enable;		/*!< Whether WAN connection is enabled. Valid values are: IFX_ENABLED and IFX_DISABLED. */
	char8 conn_name[MAX_CONN_NAME_LEN];	/*!< PPP connection name. */
	char8 conf_conn_name[MAX_CONN_NAME_LEN];	/*!< Configured Connection Name */
	uint32 auto_disconn_time;	/*!< The time in seconds since the establishment of the connection after which connection termination is automatically initiated by the CPE. This occurs irrespective of whether the connection is being used or not. A value of 0 (zero) indicates that the connection is not to be shut down automatically. Currently only a value of 0 is supported. */
	uint32 idle_disconn_time;	/*!< The time in seconds that if the connection remains idle, the CPE automatically terminates the connection. A value of 0 (zero) indicates that the connection is not to be shut down automatically. */
	uint32 NAT_enabled;	/*!< Indicates if Network Address Translation (NAT) is enabled for this connection. This parameter MUST be writable if NAT is supported by the CPE. Valid values are: IFX_ENABLED and IFX_DISABLED. */
	char8 mac_addr[MAX_MAC_ADDR_LEN];	/*!< MAC Addr of the EoATM interface. */
	uint32 mac_addr_override;	/*!< Override the default MAC address in the device. Valid values are: IFX_ENABLED and IFX_DISABLED. */
	ROUTE_PROTO_RX route_rx;	/*!< Defines the dynamic routing protocol to use for Rx of routes. */
	uint32 uptime;		/*!< Up Time of connection. */
	int32 max_mtu;		/* The maximum allowed MTU for ethernet frame on WAN IP devices */
	WAN_L3_PROTO l3_proto;
	WAN_IPV6_CFG_TYPE ipv6CfgType;
	uint32 mcProxyEna;
	char8 iface_name[MAX_IF_NAME];
	char8 l2iface_name[MAX_IF_NAME];
	WAN_MODE_CFG wan_mode;
	WAN_LINK_TYPE link_type;
	int32 wan_index;
	int32 ipflag;
	int32 ipv4;
	int32 ipv6;
	int32 dhcp_mode;
	int32 iana;
	int32 iapd;
	int32 slaid;
	int32 rapid;
	int32 tunnel;
	int32 duid_t;
	int32 def_wan;
	WAN_DNS_CFG wandns;	/*!< WAN DNS Configuration. */
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
	int32 autodetect; /*!< flag which indicates that this wan configured through autodetect */
#endif
} WAN_COMMON_CFG;

/*!
    \brief This is the data structure for WAN IP configuration.
*/
typedef struct wan_ip_config {
	WAN_COMMON_CFG wan_cfg;	/*!< Common configuration for a WAN PPP or WAN IP connection. */
	WAN_IP_CONN_TYPE conn_type;	/*!< WAN IP connection type. */
	WAN_IP_CONN_STATUS conn_status;	/*!< WAN IP connection status. */
	IP_TYPE addr_type;	/*!< The method of assigning address to the WAN interface for this conn */
	WAN_IP_CONN_TYPE possible_conn_types[3];	/*!< Type of IP Connection. */
	WANIP_LAST_CONN_ERROR last_conn_error;	/*!< Last IP Connection Error. */
} WAN_IP_CONFIG;

/*!
    \brief This is the data structure for WAN PPP configuration.
*/
typedef struct wan_ppp_config {
	WAN_COMMON_CFG wan_cfg;	/*!< Common configuration between WAN_PPP and WAN_IP connections. */
	CONN_TRIGGER trigger;
	WAN_PPP_CONN_TYPE conn_type;	/*!< PPP Connection Type. */
	WAN_PPP_CONN_STATUS conn_status;	/*!< PPP Connection Status */
	WAN_PPP_ENCR_PROTO encr_proto;	/*!< PPP Encryption Protocol. */
	WAN_PPP_COMPR_PROTO compr_proto;	/*!< PPP Compression Protocol. */
	WAN_PPP_AUTH_PROTO auth_proto;	/*!< PPP Authentication Protocol. */
	uint32 max_mru_size;	/*!< Maximum MRU size (1 - 1540). */
	uint32 current_mru;	/*!< Current configured MRU size. */
	struct in_addr local_addr;	/*!< IP address of PPP local end. */
	struct in_addr remote_addr;	/*!< IP address of PPP remote peer. */
	WAN_PPP_TRANSPORT_TYPE transport_type;	/*!< The maximum allowed MTU for Ethernet frame on WAN IP devices. */
	uint32 ppp_lcp_echo_period;	/*!< PPP LCP Echo period in seconds. */
	uint32 ppp_lcp_echo_retry;	/*!< Number of LCP Echo retries within an LCP echo period. */
	char8 pppoe_ac_name[MAX_CONN_NAME_LEN];	/*!< PPPoE Access Concentrator name. */
	char8 pppoe_service_name[MAX_CONN_NAME_LEN];	/*!< PPPoE Service Name. */
	char8 ppp_user_name[MAX_PPP_USER_NAME_PASSWD_LEN];	/*!< PPPoE USER Name. */
	char8 ppp_user_passwd[MAX_PPP_USER_NAME_PASSWD_LEN];	/*!< PPPoE user password. */
        uint32 sessionid; /*!< PPP session ID. */
	bool reset; /*!< Reset PPP connection. */
        struct in_addr defaultgw;       /*!< PPPoE connection default GW*/
	WAN_PPP_BRIDGE_ENABLE bridge_enable;	/*!< Bridge Enable */
	WAN_PPP_CONN_TYPE possible_conn_types[4];	/*!< Type of PPP Connection. */
	WANPPP_LAST_CONN_ERROR last_conn_error;	/*!< Last PPP Connection Error. */
} WAN_PPP_CONFIG;

/*!
    \brief This is the union housing PPP or IP WAN Configuration.
*/
typedef union wan_cfg {
	WAN_PPP_CONFIG ppp;	/*!< WAN PPP configuration information. */
	WAN_IP_CONFIG ip;	/*!< WAN IP configuration information. */
} WAN_CFG;

/*!
    \brief This is the structure housing Ethernet Chanenl Configuration.
*/
typedef struct eth_ch_cfg {
	IFX_ID iid;	/*!< Instance ID of Ethernet channel. */
	int32 f_enable; /*!< Whether configuration is enabled. Valid values are: IFX_ENABLED and IFX_DISABLED. */
	char8 eth_ch_name[MAX_NAME_LEN]; /*!< Eth channel name. */
	char8 mac_addr[MAX_MAC_ADDR_LEN];/*!< Mac address name. */
	char8 l2ifname[MAX_IF_NAME_LEN];/*!< Layer two Interface name. */
	bool macOverride;/*!< MacOverride Flag . */
	uint32 vlanId;/*!< VLanId value */
} ETH_CH_CFG;

/*!
    \brief This is the structure housing PTM Chanenl Configuration.
*/
typedef struct ptm_ch_cfg {
	IFX_ID iid; /*!< Instance ID of PTM channel. */
	int32 f_enable; /*!< Whether configuration is enabled. Valid values are: IFX_ENABLED and IFX_DISABLED. */
	char8 ptm_ch_name[MAX_NAME_LEN];/*!< PTM channel name. */
	char8 mac_addr[MAX_MAC_ADDR_LEN];/*!< Mac address name. */
	bool macOverride;/*!< MacOverride Flag to specify . */
	uint32 vlanId;/*!< VLanId value */
	bool preempt;		// for UGW-4.2 this field will be unused. always set to '0'
	char8 l2ifname[MAX_IF_NAME_LEN];/*!< Layer two Interface name. */
} PTM_CH_CFG;

typedef struct wan_ipv6_cfg {
	IFX_ID iid;		/*!< Instance ID of WAN connection. */
	IP6_MASK ip6_mask;	/*!< IPv6 addr and subnet mask of the WAN IP connection. For PPP this is ignored */
	struct in6_addr ip6_gw;	/*!< IPv6 address of the default gateway for this connection */
        char8 lan_prefix[64];
	struct in6_addr ip6_dns1;	/*!< IPv6 address of the default gateway for this connection */
	struct in6_addr ip6_dns2;	/*!< IPv6 address of the default gateway for this connection */
} WAN_IPV6_CFG;

/*!
    \brief This is the structure housing static wan information.
*/
typedef struct wan_ipv4_cfg {
	IFX_ID iid;		/*!< Instance ID of WAN connection. */
	IP_MASK ip_mask;	/*!< SIP addr and ubnet mask of the WAN IP connection. For PPP this is ignored */
	struct in_addr ip_gw;	/*!< IP address of the default gateway for this connection */
} WAN_IPV4_CFG;

//modified for supporting ptm and eth
/*!
    \brief This is the data structure for all the WAN connections configuration in the system.
*/
typedef struct wan_conn_cfg {
	WAN_TYPE type;		/*!< Type of WAN Connection. IP/PPP */
	WAN_CFG wancfg;		/*!< WAN Configuration. */
	WAN_IPV4_CFG wanv4;	/*!< WAN IPV4 Information. */
	WAN_IPV6_CFG wanv6;	/*!< WAN IPV6 Information. */

} WAN_CONN_CFG;

/*!
	\brief Data Structure to store the Physical WAN Mode Configuration in the system.
*/
typedef struct wan_phy_cfg {
	WAN_TC wan_tc; /*!< Type of TC PTM/ATM */
	WAN_PHY_MODE phy_mode; /*!< Type of WAN PHY MODE. PTM/ATM/MII0/MII1 */
	WAN_TC set_wan_tc; /*!< Type of TC PTM/ATM */
	WAN_PHY_MODE set_phy_mode; /*!< Type of WAN PHY MODE. PTM/ATM/MII0/MII1 */
#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
	int32 ptm_vlan_mode; /*!< PTM vlan mode variable Active/INactive */
#endif
#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
	int32 eth_vlan_mode; /*!< ETH  vlan mode variable Active/INactive */
	int32 eth_mii1_vlan_mode;/*!< ETH MII1 vlan mode variable Active/INactive */
#endif
	char8 tr69_encaprequested[MAX_FIELD_RANGE]; /*!< Encapsulation requested or not */
#if defined(CONFIG_FEATURE_ANY_WAN_SUPPORT)
	uint32 config_owner;	
#endif
} WAN_PHY_CFG;

#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
/*!
	\brief ADSL or VDSL Physical Link Parameter Configuration Information
*/
typedef struct xdsl_phy_cfg {
	char8 sAdsl_Mode[MAX_FILELINE_LEN];	/*!< ADSL AnnexA XTU bits separated by underscore */
	char8 sDsl_Api_Debug[MAX_FILELINE_LEN];	/*!< Status of API Debug, Enabled or Disabled */
	char8 sVdsl_Mode[MAX_FILELINE_LEN];	/*!< VDSL Profile Support Bits separated by underscore */
	char8 sXdsl_Mode[MAX_FILELINE_LEN];	/*!< Mode Information like - ADSL2+, ADSL2, MultiMode etc */
	int32 cntl_mode_ena;	/*!< Control Mode Status. Enabled or Disabled */
	int32 cntl_mode;	/*!< Control Mode Value */
	int32 pwr_mode_ena;	/*!< Power Mode Status. Enabled or Disabled */
	int32 pwr_mode;	/*!< Power Mode Value */
	int32 igmp_mode; /*!< unused */
} XDSL_PHY_CFG;
#endif

/*!
    \brief This is data structure getting Values of WAN and xDSL status.
*/
typedef struct xIPMask {
char8 wan_ip[MAX_IP_ADDR_LEN];	  /*!< Gets WAN IP address */
char8 wan_status[MAX_NAME_SIZE];  /*!< Status of WAN connection, Connected or Disconnected */	
char atm_proto[MAX_FILELINE_LEN]; /*!< WAN Link Type like - pppoatm, pppoe, rfc2684_eoa*/
int wan_type;			  /*!< Get IP boot type like - IP_BOOT_PTM, IP_BOOT_ETH */
WAN_TC wan_tc;    /*!< Type of TC PTM/ATM */
} WanIPMask;

#if defined(CONFIG_FEATURE_CELL_WAN_SUPPORT) || defined(CONFIG_FEATURE_WWAN_LTE_SUPPORT)
/*!
    \brief WWAN PPP Authentication type enumeration
*/
typedef enum {
	PAP = 0,
	CHAP = 1
} LTQ_MAPI_AUTH_TYPE;

/*!
    \brief This is data structure for 3G WWAN settings.
*/
typedef struct ltq_mapi_cell_wan {

	IFX_ID iid;			/*!< Id of WWAN details */
	bool ena;			/*!< flag to enable / disable active profile of 3G WWAN */
	char profName[MAX_NAME_LEN];	/*!< WWAN Profile name */
	char apn[MAX_NAME_LEN];		/*!< WWAN Access Point name */
	char user[MAX_NAME_LEN];	/*!< Username if any */
	char passwd[MAX_NAME_LEN];	/*!< Password if any */
	LTQ_MAPI_AUTH_TYPE authType;	/*!< Authentication type CHAP/PAP (enum) */
	bool usePIN;			/*!< Use SIM card PINCODE or not */
	int32 pin;			/*!< SIM card PINCODE number if any */
	char dialNum[MAX_NAME_LEN];	/*!< Dial-up number */
	bool idleDisc;			/*!< Enable/Disable ppp connection time out flag */
	int32 idleDiscTO;		/*!< ppp connection timeout value */
	char ifName[MAX_NAME_LEN];	/*!< Interface name (ppp) */
	char STATUS[MAX_NAME_LEN];	/*!< Connection status (bool) */
	char IP[MAX_NAME_LEN];		/*!< IP address received from ISP */
	char MASK[MAX_NAME_LEN];	/*!< Subnet mask */
} LTQ_MAPI_Cell_WAN;

/*!
    \brief WWAN mode selection enumeration
*/
typedef enum {
	LTQ_MAPI_CELL_WAN_3G = 0,
	LTQ_MAPI_CEL_WAN_4G = 1
} LTQ_MAPI_CELL_WAN_TYPE;

/*!
    \brief WWAN SIM registration status enumeration
*/
typedef enum {
	LTQ_MAPI_SIM_OK = 0,
	LTQ_MAPI_SIM_LOCKED = 1
} LTQ_MAPI_SIM_STATUS;

/*!
    \brief This is data structure for WWAN 3G modem and connection status.
*/
typedef struct ltq_mapi_modem_status {
	IFX_ID iid;				/*!< Id of WWAN modem status */
	LTQ_MAPI_CELL_WAN_TYPE cellWanType;	/*!< Connection mode */
	char modemManu[MAX_NAME_LEN];		/*!< WWAN Modem Manufacturer */
	char modemModel[MAX_NAME_LEN];		/*!< Modem Model */
	char cellOper[MAX_NAME_LEN];		/*!< Service provider */
	char esn_imei[MAX_NAME_LEN];		/*!< Device IMEI number */
	uint16 sigStrngthPct;			/*!< Signal Strength pct */
	uint16 sigStrngthDbm;			/*!< Signal Strength dBm */
	LTQ_MAPI_SIM_STATUS simSta;		/*!< SIM registration status */
	bool cellWanSta;			/*!< WWAN connection status */
} LTQ_MAPI_MODEM_STATUS;
#endif /* CONFIG_FEATURE_CELL_WAN_SUPPORT */

#if 1
/*!
    \brief This is the data structure for interface statistics of the interface name.
*/
typedef struct if_stats {
	unsigned long tx_pkts;	/*!< Number of transmitted packets/frames on
				   the interface. */
	unsigned long rx_pkts;	/*!< Number of received packets/frames on this
				   interface. */
	unsigned long tx_discard_pkts;	/*!< Number of packets/frames
					   discarded in transmit on the
					   interface. */
	unsigned long tx_error_pkts;	/*!< Number of transmit error
					   packets/frames on the interface. */
	unsigned long rx_discard_pkts;	/*!< Number of received packets/frames
					   discarded on this interface. */
	unsigned long rx_error_pkts;	/*!< Number of packets/frames with
					   errors received on the interface. */
	unsigned long tx_bytes;	/*!< Number of bytes transmitted through the
				   interface. */
	unsigned long rx_bytes;	/*!< Number of bytes received on the
				   interface. */
        unsigned long tx_unicast_pkts; /*!<The total number of packets requested for 
                                          transmission which were not addressed to a 
                                          multicast or broadcast address, including those that 
                                          were discarded or not sent. */
        unsigned long rx_unicast_pkts; /*!<The total number of received packets which were 
                                          not addressed to a multicast or broadcast address.*/
        unsigned long tx_multicast_pkts; /*!<The total number of packets requested for 
                                            transmission which were addressed to a multicast 
                                            address, including those that were discarded or not 
                                            sent. */
        unsigned long rx_multicast_pkts; /*!<The total number of received packets which were 
                                            addressed to a multicast address. */
        unsigned long tx_broadcast_pkts;  /*!<The total number of packets requested for 
                                             transmission which were addressed to a broadcast 
                                             address, including those that were discarded or not 
                                             sent. */
        unsigned long rx_broadcast_pkts;  /*!<The total number of received packets which were 
                                             addressed to a broadcast address. */
        unsigned long rx_unknownproto_pkts; /*!<The total number of packets received via the 
                                               interface which were discarded because of an 
                                               unknown or unsupported protocol. */

} IF_STATS;
#else
/*!
    \brief This is the data structure for interface statistics of the interface name.
*/
typedef struct if_stats {
	int32 tx_pkts;		/*!< Number of transmitted packets/frames on
				   the interface. */
	int32 rx_pkts;		/*!< Number of received packets/frames on this
				   interface. */
	int32 tx_discard_pkts;	/*!< Number of packets/frames discarded in
				   transmit on the interface. */
	int32 tx_error_pkts;	/*!< Number of transmit error packets/frames
				   on the interface. */
	int32 rx_discard_pkts;	/*!< Number of received packets/frames
				   discarded on this interface. */
	int32 rx_error_pkts;	/*!< Number of packets/frames with errors
				   received on the interface. */
	int32 tx_bytes;		/*!< Number of bytes transmitted through the
				   interface. */
	int32 rx_bytes;		/*!< Number of bytes received on the
				   interface. */
} IF_STATS;
#endif

/*!
    \brief Structure describing the Interface Statistics.
*/
typedef struct iface_stats {
	IFX_ID iid;		/*!< IFX Id of Interface Stats */
	char8 iface[MAX_NAME_SIZE];	/*!< Interface Name */
	int32 wan_index;	/*!< WAN Index */
	IF_STATS stats;		/*!< Interface Stats */
} IFACE_STATS;

/*!
    \brief This is the data structure for the QOS bandwidth priority configuration.
*/
typedef struct qos_bw_prio_cfg {
	int32 min_bw;		/*!< Reserved bandwidth in percentage. A value
				   of zero means no bandwidth reservation. */
	int32 max_bw;		/*!< Maximum upstream bandwidth allowed for
				   the Virtual server (ceiling). */
	int32 priority;		/*!< Priority level of the QoS flow. A
				   priority range of 0-7 is supported with 0
				   being the highest priority and 7 being the
				   lowest priority. */
	int32 qos_enabled;	/*!< Whether QoS is enabled for the specified
				   direction. */
} QOS_BW_PRIO_CFG;

/*!
    \brief This is the data structure for the virtual server configuration.
*/
typedef struct virtual_server {
	IFX_ID iid;		/*!< Instance ID of Virtual Server object. */
	int32 f_enable;		/*!< Whether Rule is enabled. Valid values
				   are: IFX_ENABLED and IFX_DISABLED. */
	struct in_addr private_ip;	/*!< Private IP address on the LAN. */
	struct in_addr remote_ip;	/*!< IP address of the remote host which is
					   connecting to the virtual server. */
	int32 private_sport;	/*!< Private UDP/TCP start port on the LAN. */
	int32 private_eport;	/*!< Private UDP/TCP end port on the LAN. */
	int32 protocol;		/*!< IP Protocol - UDP, TCP, ICMP. */
	int32 public_sport;	/*!< Public start port for NAT to use. */
	int32 public_eport;	/*!< Public end port for NAT to use. */
	QOS_BW_PRIO_CFG up_qos;	/*!< Upstream QoS configuration. */
	QOS_BW_PRIO_CFG dn_qos;	/*!< Downstream QoS configuration. */
	char8 wan_conn_if[MAX_CONN_NAME_LEN];	/*!< Input interface of
						   connection request. If this
						   is null string, then
						   requests are allowed on all
						   interfaces. */
	int32 lease_duration;	/*!< Lease Duration. */
	char8 vs_desc[MAX_VS_DESC_LEN];	/*!< Virtual Server Description. */
} VIRTUAL_SERVER;

//////////////////////////////////////////////////////////
/*!
    \brief This is the data structure for the port triggering entry information.
*/
typedef struct port_trigger {
	IFX_ID iid;		/*!< Instance ID */
	char8 Application_Name[MAX_UNAME_LEN];	/*!< Application Name */
	int32 f_enable;		/*!< Enable flag */
	int32 trigger_start_port;	/*!< Trigger Start Port */
	int32 trigger_end_port;	/*!< Trigger End Port */
	int32 protocol;		/*!< Trigger Protocol */
	int32 external_start_port;	/*!< External Start Port */
	int32 external_end_port;	/*!< External End Port */
	int32 open_protocol;	/*!< Open or external protocol */
} PORT_TRIGGER;

///////////////////////////////////////////////////////////

/*!
    \brief This is the data structure for the bridge configuration of the device.
*/
typedef struct bridge_config {
	IFX_ID iid;		/*!< Instance ID - Internal ID used for book
				   keeping. The default value of 0 should be
				   passed. */
	int32 stp_enable;	/*!< Whether Spanning Tree Protocol (STP) is
				   enabled on the bridge. Valid values are:
				   IFX_ENABLED and IFX_DISABLED. */
	char8 bridge_if[IFNAMSIZE];	/*!< Name of the bridge interface. For
					   example: br0. */
	int32 num_ifs;		/*!< The number of interfaces that are members
				   of the bridge. */
	char8 *bridge_member_ifs[IFNAMSIZE];	/*!< Allocated array of
						   interface names that are
						   members of the bridge. Each
						   array element is of size
						   IFNAMSIZ. The caller has to
						   free the memory pointed to
						   by bridge_member_ifs. */
	int32 f_enable;		/*!< Whether bridge configuration is enabled.
				   Valid values are: IFX_ENABLED and
				   IFX_DISABLED. */
} BRIDGE_CONFIG;

/*!
    \brief This is the data structure for Management Server information, as defined in IGD Data Model.
*/
typedef struct mgmt_server {
	IFX_ID iid;		/*!< Instance Id of Management Server object. */
	char8 url[MAX_URL_LEN];	/*!< HTTP/HTTPs URL of Auto-Configuration
				   Server (ACS). */
	char8 uname[MAX_UNAME_LEN];	/*!< Username for login to ACS. */
	char8 passwd[MAX_PASSWORD_LEN];	/*!< Password for login to ACS. */
	char8 period_inform_enable;	/*!< Flag to denote whether periodic inform is
	   enabled or not. *//* Verify this data type */
	uint32 period_inform_interval;	/*!< Periodic Inform Interval in
					   seconds. */
	uint32 period_abs_inform_time;	/*!< Next Periodic Inform Absolute
	   Time. *//* Verify this data type */
	char8 parameter_key[MAX_PARAMETER_KEY_LEN];	/*!< Parameter Key. */
	char8 conn_req_url[MAX_CONN_REQ_URL_LEN];	/*!< Connection Request URL. */
	char8 conn_req_uname[MAX_CONN_REQ_UNAME_LEN];	/*!< Connection
							   Request User Name. */
	char8 conn_req_passwd[MAX_CONN_REQ_PASSWD_LEN];	/*!< Connection
							   Request Password. */
	char8 upgrades_managed;	/*!< Upgrades Managed Flag. *//* Verify this data type */
	char8 kick_url[MAX_KICK_URL_LEN];	/*!< URL to Kick. */
	char8 dnld_progress_url[MAX_DNLD_PROGRESS_URL_LEN];	/*!< URL for Download
								   Progress. */
	char8 udp_conn_req_url[MAX_CONN_REQ_URL_LEN];	/*!< UDP Connection
							   Request URL */
	uint32 udp_conn_req_address_notification_limit;	/*!< UDP Connect Req
							   Address Notification
							   Limit */
	uint32 stun_enable;	/*!< Enable of STUN */
	struct in_addr stun_server_address;	/*!< STUN Server IP Address */
	uint32 stun_server_port;	/*!< STUN Server Port */
	char8 stun_server_uname[MAX_CONN_REQ_UNAME_LEN];	/*!< STUN Server
								   Username */
	char8 stun_passwd[MAX_CONN_REQ_PASSWD_LEN];	/*!< STUN Server Password */
	int32 stun_max_keep_alive_period;	/*!< STUN Maximum Keep Alive period */
	uint32 stun_min_keep_alive_period;	/*!< STUN Minimum Keep Alive Period */
	uint32 nat_detected;	/*!< Whether NAT Detected */
	uint32 mngdevnotifylimit;	/*!< Management Device Notification Limit */
	char8 enable_cwmp;	/*!< TR-069 Enabled Flag */

} MGMT_SERVER;

/*!
    \brief This is the data structure for the IP Layer Ping Diagnostics between ACS and CPE.
*/
typedef struct ipping_diagnostics {
	IFX_ID iid;		/*!< Instance Id of IP-Ping Diagnostics
				   Object. */
	char8 diag_state[MAX_DIAGSTATE_LEN];	/*!< Diagnostics state in
						   String Form. */
	char8 interface[MAX_IF_NAME];	/*!< WAN Interface Name in form of
					   String. */
	char8 host[MAX_HOST_NAME];	/*!< Hostname in form of string. */
	uint32 num_repeat;	/*!< Number of times the tests to be repeated.
				 */
	uint32 timeout;		/*!< Time-out value for tests to fail. */
	uint32 data_size;	/*!< Data Size for Ping Tests. */
	uint32 dscp;		/*!< Diffserv Code Point */
	uint32 success_cnt;	/*!< Counter for no. of times test were
				   successful. */
	uint32 failure_cnt;	/*!< Counter for no. of times test failed. */
	uint32 avg_resp_time;	/*!< Average response time for tests. */
	uint32 min_resp_time;	/*!< Minimum response time for tests. */
	uint32 max_resp_time;	/*!< Maximum response time for tests. */
} IPPING_DIAG;


/* for NSLookup diagnostics profile */
/*!
    \brief This is the data structure for the NSLookup Diagnostics.
*/

typedef struct nslookup_diagnostics {
        IFX_ID iid;             /*!<IFX Identifier of nslookup_diagnostics */
        char8 diag_state[MAX_DIAGSTATE_LEN];    /*!< Diagnostics State */
        char8 interface[MAX_IF_NAME];   /*!< Interface Name */
        char8 hostname[MAX_HOST_NAME];      /*!< Host Name */
        char8 dnsserver[MAX_HOST_NAME];    /*!< DNS Server Name or IP */
        uint32 num_repetitions;       /*!< Number of Repetitions */
        uint32 timeout;         /*!< Timeout Value */
        uint32 success_count;       /*!<  Number of successfully executed repetitions */
        uint32 result_num_entries;            /*!< Total number of Result entries */
} NSLOOKUP_DIAG;

/*!
    \brief This is the data structure for the Results of NSLookup Diagnostics.
*/
typedef struct result {
        IFX_ID iid;             /*!<IFX Identifier of Result */
        char8 status[VALUE_MAX_LEN];         /*!<Status of the Result */
        char8 anstype[VALUE_MAX_LEN];      /*!<   */
        char8 hostname_ret[MAX_HOST_NAME];   /*!< Host Name Returned*/
        char8 ipaddresses[256]; /*!<  Comma-separated list of IPAddressesHost Address */
        char8 dnsserver_ip[MAX_IP_ADDR_LEN]; /*!< actual DNS Server IP address */
        uint32 resp_time;    /*!< Response Time */
} RESULT;

/* for Traceroute diagnostics profile */
/*!
    \brief This is the data structure for the TraceRoute Diagnostics.
*/
typedef struct traceroute_diagnostics {
	IFX_ID iid;		/*!<IFX Identifier of traceroute_diagnostics */
	char8 diag_state[MAX_DIAGSTATE_LEN];	/*!< Diagnostics State */
	char8 interface[MAX_IF_NAME];	/*!< Interface Name */
	char8 host[MAX_HOST_NAME];	/*!< Host Name */
	uint32 num_tries;	/*!< Number of Tries */
	uint32 timeout;		/*!< Timeout Value */
	uint32 data_size;	/*!< Datagram Size */
	uint32 dscp;		/*!< DSCP Value */
	uint32 max_hop_count;	/*!< Maximum Number of HOPS */
	uint32 resp_time;	/*!< Response Time */
	uint32 root_hop_num_entries;	/*!< Number of RootHops */
} TRACEROUTE_DIAG;

/*!
    \brief This is the data structure for the Route hops of NSLookup Diagnostics.
*/
typedef struct route_hop {
	IFX_ID iid;		/*!<IFX Identifier of RouteHops */
	char8 hophost[MAX_HOST_NAME];	/*!< Host Name */
	char8 hophost_address[MAX_IP_ADDR_LEN];	/*!< Host Address */
	uint32 hop_err_code;	/*!< Hop Error Code */
	char8 hop_rtt_time[MAX_DATA_LEN];	/*!< Hop Round Trip Time */
} ROUTE_HOPS;

/*traceroute ends*/


/* for SelfTest diagnostics profile */
/*!
    \brief This is the data structure for the SelfTest Diagnostics.
*/

typedef struct diagnostics_test_suite {
        int32 diag_test_cnt;       /*!< Bitwise flag. Tests will be performed corresponding to Bits set. */
        char8 diag_state[MAX_DATA_LEN];    /*!< Diagnostics State */
        bool wan_conn_status;      /*!< Wan Status Flag . */
        bool lan_conn_status;      /*!< Lan Status Flag . */
        bool enet_lan0_status;          /*!< Lan PortO Status Flag . */
        bool enet_lan1_status;          /*!< Lan Port1 Status Flag . */
        bool enet_lan2_status;          /*!< Lan Port2 Status Flag . */
        bool enet_lan3_status;          /*!< Lan Port3 Status Flag . */
        bool wan_gw;               /*!< Wan GateWay Status Flag . */
        bool dns1;           /*!< Primary DNS Status Flag . */
        bool dns2;           /*!< Secondary DNS Status Flag . */
        bool wlan0;           /*!< WLAN0 Status Flag . */
        bool wlan1;           /*!< WLAN1 Status Flag . */
        WAN_TC encap;              /*!< Type of TC PTM/ATM */
        DSL_LINK_STATUS link_status;    /*!< Status of DSL Link. */
        char8 caResult[MAX_DATA_LEN];   /*!< Stores Results of self-test. */
} DIAGNOSTICS_TEST_SUITE;

/*SelfTest diagnostics ends*/


/* VendorConfigFile */

typedef struct vend_conf_file {
        IFX_ID iid;            /*!< IFX Identifier of VendorConfigFile */
        char8 name[64];        /*!< Name of the VendorConfigFile */
        char8 version[16];     /*!< Version of the VendorConfigFile */
        char8 date[24];        /*!< Date of download of the VendorConfigFile */
        char8 desc[256];       /*!< Dexcription of the VendorConfigFile */
} VEND_CONF_FILE;



/*!
    \brief This is the data structure for the Download Diagnostics.
*/
typedef struct download_diagnostics {
	IFX_ID iid;                             /*!< IFX Identifier of download_diagnostics */
	char8 diag_state[MAX_DIAGSTATE_LEN];    /*!< Diagnostics State */
	char8 interface[MAX_IF_NAME];           /*!< Interface Name */
	char8 download_url[MAX_URL_LEN];        /*!< Download URL */
	uint32 dscp;                            /*!< DSCP value */
	uint32 ethernet_priority;               /*!< Ethernet Priority Value */
	char8 ROMTime[64];                      /*!< Request time */
	char8 BOMTime[64];                      /*!< Begin of transmission time */
	char8 EOMTime[64];                      /*!< End of transmission time */
	uint32 rxTestBytes;                     /*!< Test traffic received in bytes */
	uint32 rxTotalBytes;                    /*!< Total number of bytes received */
	char8 tcpOpenRqstTime[64];              /*!< TCP socket open(SYN) time */
	char8 tcpOpenRespTime[64];              /*!< TCP ACK received time */
} DOWNLOAD_DIAG;

/*!
    \brief This is the data structure for the Upload Diagnostics.
*/
typedef struct upload_diagnostics { 
        IFX_ID iid;                             /*!< IFX Identifier of upload_diagnostics */
        char8 diag_state[MAX_DIAGSTATE_LEN];    /*!< Diagnostics State */
        char8 interface[MAX_IF_NAME];           /*!< Interface Name */
        char8 upload_url[MAX_URL_LEN];          /*!< Upload URL */
        uint32 dscp;                            /*!< DSCP value */
        uint32 ethernet_priority;               /*!< Ethernet Priority Value */
        char8 ROMTime[64];                      /*!< Request time */
        char8 BOMTime[64];                      /*!< Begin of transmission time */
        char8 EOMTime[64];                      /*!< End of transmission time */
        uint32 txTotalBytes;                    /*!< Total number of bytes sent */
        char8 tcpOpenRqstTime[64];              /*!< TCP socket open(SYN) time */
        char8 tcpOpenRespTime[64];              /*!< TCP ACK received time */
        uint32 test_file_len;                   /*!< Length of files to be uploaded */
} UPLOAD_DIAG;

/*!
    \brief This is the data structure for the IPProtocol Version in CPE.
*/
typedef struct x_ltq_ipprotocolversion {
	char8 mode[20];                         /*!< Mode  */
} X_LTQ_IPPROTOCOLVERSION;

// MEMORYSTATUS
/*!
    \brief This is the data structure for the Memory Status of the CPE.
*/
typedef struct memorystatus {
        unsigned long int total_mem;            /*!< Total Memory */
        unsigned long int free_mem;             /*!< Free Memory */
} MEMORYSTATUS;

// PROCESSSTATUS
/*!
    \brief This is the data structure for the Process Status of the CPE.
*/
typedef struct processstatus {
        uint32 cpu_usage ;                      /*!< CPU Usage */
        uint32 process_num_entries;             /*!< Number of processes running */
} PROCESSSTATUS;

/*!
    \brief This is the data structure for the Processes running in the CPE.
*/
typedef struct process {
        IFX_ID iid;                             /*!< IFX Identifier of process */
        uint32 pid;                             /*!< Process Id */
        char cmd[256];                          /*!< Command used to run the process */
        uint32 size;                            /*!< Size of the process */
        uint32 priority;                        /*!< Priority of the process */
        uint32 cputime;                         /*!< CPU Time used by the process */
        char state[50];                         /*!< Current state of the process */
} PROCESS;

/*!
    \brief This is the data structure for the Queued Download.
*/
typedef struct queued_download {
        char CommandKey[256];                   /*!< CommandKey for the download */
        char FileType[256];                     /*!< Type of the file to be downloaded */
        char FileName[256];                     /*!< Name of the file to be downloaded */
        char Username[256];                     /*!< Username to be used for download */
        char Password[256];                     /*!< Password to be used for download */
        char FileSize[256];                     /*!< Size of file to be downloaded */
        char DelaySeconds[256];                 /*!< Delay in seconds after which file is to be downloaded */
        char FutureTime[256];                   /*!< Time at which file will be downloaded */
        char Status[256];                       /*!< Status of the download */
        char StartTime[256];                    /*!< Starting time of the download */
        char EndTime[256];                      /*!< End Time of the Download */
} QUEUED_DOWNLOAD_STRUCT;

/*!
    \brief This is the data structure for the GetAllQueuedTransfers RPC.
*/
typedef struct TransferList {
        char CommandKey[32];                    /*!< CommandKey for the download/upload */
        int State;                              /*!< Status of the download/upload */
        bool IsDownload;                        /*!< Whether transfer is download or upload */
        char FileType[64];                      /*!< Type of the file to be downloaded/uploaded */
        unsigned int FileSize;                  /*!< Size of file to be downloaded/uploaded */
        char TargetFileName[256];               /*!< Name of the file to be downloaded/uploaded */
        int isComplete;                         /*!< Download/Upload complete or not */
} TRANSFER_LIST;

typedef struct schedule_download {
        char CommandKey[256];                   /*!< CommandKey for the download */
        char FileType[256];                     /*!< Type of the file to be downloaded */
        char FileName[256];                     /*!< Name of the file to be downloaded */
        char URL[256];
        char Username[256];                     /*!< Username to be used for download */
        char Password[256];                     /*!< Password to be used for download */
        char FileSize[256];                     /*!< Size of file to be downloaded */
        char DelaySeconds[32];                 /*!< Delay in seconds after which file is to be downloaded */
        char FutureTime[256];                   /*!< Time at which file will be downloaded */
        char Status[16];                       /*!< Status of the download */
        char StartTime[64];                    /*!< Starting time of the download */
        char EndTime[64];                      /*!< End Time of the Download */
        char Window1_Start[32];                /*!< Window 1 Start time */
        char Window1_End[32];                  /*!< Window 1 End time */
        char Window1_Mode[64];                 /*!< Window 1 Mode */
        char Window1_UserMsg[256];             /*!< Window 1 User message */
        char Window1_MaxRetries[32];           /*!< Window 1 MaxRetries */
        char Window2_Start[32];                /*!< Window 2 Start time */
        char Window2_End[32];                  /*!< Window 2 End time */
        char Window2_Mode[64];                 /*!< Window 2 Mode */
        char Window2_UserMsg[256];             /*!< Window 2 User message */
        char Window2_MaxRetries[32];           /*!< Window 2 MaxRetries */
} SCHEDULE_DOWNLOAD_STRUCT;
 

/*!
    \brief This is the data structure for WAN Connection Device.
*/
typedef struct wan_conn_dev {
	IFX_ID iid;		/*!< Instance Id of WAN Connection Device. */
	VCC vc;			/*!< VCC of which WAN Connection is part of. */
	char8 l2iface_name[MAX_IF_NAME];	/*!< base interface name of VCC */
} WAN_CONN_DEV;

/*!
    \brief This is the data structure for authentication information for TR-069.
*/
typedef struct tr69_auth {
	IFX_ID iid;		/*!< IFX Identifier */
	char8 realm[MAX_AUTH_PARAM_LONG_LEN];	/*!< Realm Information */
	char8 nonce[MAX_AUTH_PARAM_LONG_LEN];	/*!< Nonce information */
	char8 uri[MAX_AUTH_PARAM_LONG_LEN];	/*!< URI */
	char8 algo[MAX_AUTH_PARAM_SHORT_LEN];	/*!< Algoritham used */
	char8 cnonce[MAX_AUTH_PARAM_LONG_LEN];	/*!< Cnonce Value */
	char8 opaque[MAX_AUTH_PARAM_LONG_LEN];	/*!< Opaque value */
	char8 qop[MAX_AUTH_PARAM_LONG_LEN];	/*!< QOP */
	char8 nc[MAX_AUTH_PARAM_SHORT_LEN];	/*!< NC */
} TR69_AUTH;

/*!
    \brief This is the data structure for Download Authentication in TR-069.
*/
typedef struct dl_auth {
	IFX_ID iid;		/*!< IFX Identifier */
	char8 uname[MAX_UNAME_LEN];	/*!< User Name */
	char8 passwd[MAX_PASSWORD_LEN];	/*!< Password */
	char8 realm[MAX_AUTH_PARAM_LONG_LEN];	/*!< Realm */
	char8 nonce[MAX_AUTH_PARAM_LONG_LEN];	/*!< Nonce */
	char8 uri[MAX_AUTH_PARAM_LONG_LEN];	/*!< URI */
	char8 algo[MAX_AUTH_PARAM_SHORT_LEN];	/*!< Algorithm */
	char8 cnonce[MAX_AUTH_PARAM_LONG_LEN];	/*!< CNONCE value */
	char8 opaque[MAX_AUTH_PARAM_LONG_LEN];	/*!< Opaque value */
	char8 qop[MAX_AUTH_PARAM_LONG_LEN];	/*!< QOP */
	char8 nc[MAX_AUTH_PARAM_SHORT_LEN];	/*!< NONCE */
	char8 process_cookie;	/*!< Cookie handling */
	char8 file_type[MAX_AUTH_PARAM_LONG_LEN];	/*!< file Type */
	char8 file_name[MAX_FILE_NAME_LEN];	/*!< file name */
	char8 cmd_key[MAX_COMMAND_KEY_LEN];	/*!< Command key */
	int32 status;		/*!< Download auth status */
	uint32 abs_start_time;	/*!< Absolute Start time */
	uint32 abs_end_time;	/*!< Absolute End Time */
	uint32 abs_fut_time;	/*!< Absolute Future Time */
	int32 size;		/*!< Size */
} DL_AUTH;

/*!
    \brief This is the data structure for miscellaneous information of TR-069.
*/
typedef struct tr69_misc {
	IFX_ID iid;		/*!< IFX Identifier */
	char8 auth_acs;		/*!< Authentication for ACS. */
	char8 auth_type[MAX_AUTH_TYPE_LEN];	/*!< Authentication Type. */
	uint32 event;		/*!< Event */
	char8 cmd_key[MAX_COMMAND_KEY_LEN];	/*!< Command Key */
	char8 inc_xml;		/*!< XML included */
	char8 inc_soap_action;	/*!< SOAP action included */
	char8 acs_get_rpc;	/*!< GET RPC form ACS support */
	char8 bootstrap;	/*!< Bootstrap support */
	char8 tr64_enable;	/*!< TR-064 Enabled Flag */
	char8 upnp_enable;	/*!< UPnP Enabled Flag */
	uint32 tr64_port;	/*!< TR-064 port */
	uint32 upnp_port;	/*!< UPnP port */
	uint32 abs_prev_time;	/*!< Absolute Previous Time */
	uint32 url_status;	/*!< To get url_status */
} TR69_MISC;

/*!
    \brief This is the data structure for ATM F5 Loopback Diagnostics.
*/
typedef struct atmf5_loop_diagnostics {
	IFX_ID iid;		/*!< Instance Id of WAN ATM F5 Loopback
				   Diagnostics. */
	int32 f_enable;		/*!< Flag for enabling the object. */
	int16 vpi;		/*!< Number of packets/frames discarded in
				   transmit on the interface. */
	int32 vci;		/*!< Number of transmit error packets/frames
				   on the interface. */
	char8 scope;		/*!< Scope of tests. */
	DIAGNOSTIC_STATE diagnostic_state;	/*!< State of Diagnostics on object. */
	WAN_ATMF5_LOOPBACK_STATE loopback;	/*!< Loopback Diagnostic state. */
	WAN_ATMF5_CC_CHECK cc_check;	/*!< Continuity Check State. */
	WAN_ATMF5_CC_CHECK_OPT cc_check_opt;	/*!< Optional continuity Check
						   State. */
	uint32 ping_timeout;	/*!< Timeout for Ping Diagnostics. */
	uint32 oam_pings;	/*!< OAM Ping Information. *//* tx cells */
	uint32 success_count;	/*!< Result - Number of times the test has
	   passed. *//* rx cells */
	uint32 failure_count;	/*!< Result - Number of times test failed. *//* (tx - rx) cells */
	uint32 max_resp_time;	/*!< Result - Maximum Response Time during
				   tests. */
	uint32 min_resp_time;	/*!< Result - Minimum Response Time during
				   tests. */
	uint32 avg_resp_time;	/*!< Result - Average Response Time during
				   Diagnostics. */
} WAN_ATMF5_LOOP_DIAGNOSTICS;

/**************
 *Added for firewall object
 ***************************/

/*!
	\brief Enumeration for MAPI protocol type
*/
typedef enum ifx_mapi_protocol_type {
	IFX_MAPI_Protocol_ALL = 0,
	IFX_MAPI_Protocol_TCP = 6,
	IFX_MAPI_Protocol_UDP = 17,
	IFX_MAPI_Protocol_ICMP = 1,
	IFX_MAPI_Protocol_AH = 51,
	IFX_MAPI_Protocol_ESP = 50
} IFX_MAPI_Protocol_Type;

typedef enum ifx_mapi_ip_address_type {
	IFX_MAPI_IP_ALL = 0,
	IFX_MAPI_IP_Single = 1,
	IFX_MAPI_Subnet = 2,
} IFX_MAPI_IP_Address_Type;

typedef enum ltq_mapi_firewall_config_enum {
	LTQ_MAPI_CONFIG_OFF = 0,
	LTQ_MAPI_CONFIG_LOW = 1,
	LTQ_MAPI_CONFIG_MEDIUM = 2,
	LTQ_MAPI_CONFIG_HIGH = 3,
} LTQ_MAPI_FIREWALL_CFG;
/*!
    \brief Structure describing the Firewall object.
*/

typedef struct ifx_mapi_firewall {
	IFX_ID iid;		/*!< Identifier of firewall object */
	LTQ_MAPI_FIREWALL_CFG enable;		/*!< Enable flag of Firewall Object */
        char8 version[16];
        uint32 lastchange_time;
} IFX_MAPI_Firewall;

/*!
    \brief Structure describing the packet filter rules in Firewall.
*/
typedef struct ifx_mapi_firewall_pfrule {
	IFX_ID iid;		/*!< IFX Identifier of Packet Filter rule in
				   FW Object */
	char8 enable;		/*!< Enable of Packet filter Instance */
	char8 status;		/*!< Status of Packet filter Instance */
	IFX_MAPI_Protocol_Type protoType;	/*!< Protocol Type */
	IFX_MAPI_IP_Address_Type srcType;	/*!< Source IP Type */
	IP_MASK srcIP;		/*!< Source IP and Mask */
	PORT_RANGE sPortRange;	/*!< Source Port Range */
	char8 iif[MAX_IF_NAME_LEN];	/*!< Input Interface Name */
	IFX_MAPI_IP_Address_Type dstType;	/*!< Destination IP Type */
	IP_MASK dstIP;		/*!< Destination IP address */
	PORT_RANGE dPortRange;	/*!< Destination Port Range */
	char8 oif[MAX_IF_NAME_LEN];	/*!< Output Interface Name */
	char8 sMacAddr[MAX_MAC_ADDR_LEN];	/*!< Source MAC Address */
} IFX_MAPI_Firewall_PFRule;

/*!
    \brief Structure describing the Advanced Firewall rules.
    ref: http://www.broadband-forum.org/cwmp/tr-181-2-4-0.html
*/
typedef struct ltq_mapi_firewall_config {
	IFX_ID 	iid;		/*!< IFX Identifier of Packet Filter rule in
				   FW Object */
	char8	Enable;		/*!< Enables or disables the Firewall. */
	char8	Config;		/*!< High, Low, Advanced */
	int32	AdvancedLevel;	/*!< The value MUST be the path name of a row in the Firewall.Level  table */
	char8	Type[32];	/*!< stateful / stateless */
	char8	Version[16];	/*!< string identifying the firewall settings version currently used in the CPE */
	time_t	LastChange;
	uint32	LevelNumberOfEntries;	/*!< The number of entries in the Level  table. */
	uint32	ChainNumberOfEntries;	/*!< The number of entries in the Chain  table. */
} LTQ_MAPI_Firewall_Config;

/*!
    \brief Structure describing the  firewall levels.
    ref: http://www.broadband-forum.org/cwmp/tr-181-2-4-0.html
*/

typedef struct ltq_mapi_firewall_level {
	IFX_ID 	iid;		/*!< IFX Identifier of Packet Filter rule in
				   FW Object */
	char8	Enable;		/*!< Enables or disables this Chain  entry. */
	char8	Name[32];	/*!< Human-readable name associated with this Chain  entry. */
	char8	Description[256];	/*!< Human-readable description associated with this Level  entry. */
	int32	Chain;			/*!< The value MUST be the path name of a row in the Firewall.Chain  table */
	int32	PortMappingEnabled;	/*!< Indicates whether NAT port mapping is enabled or disabled when this is the active Level. */
	int32	DefaultPolicy;		/*!< Drop, Accept, Reject */
	int32 	DefaultLogPolicy;	/*!< Enable or disable logging, in a DeviceInfo.VendorLogFile, of packets not matching any of the level rules. */
} LTQ_MAPI_Firewall_Level;

/*!
    \brief Structure describing the  firewall chains.
    ref: http://www.broadband-forum.org/cwmp/tr-181-2-4-0.html
*/
typedef struct ltq_mapi_firewall_chain {
	IFX_ID 	iid;		/*!< IFX Identifier of Packet Filter rule in
				   FW Object */
	char8	Enable;		/*!< Enables or disables this Chain  entry. */
	char8	Name[32];	/*!< Human-readable name associated with this Chain  entry. */
	char8	Creator[32];	/*!< Defaults, PortMapping, WANIPv6FirewallControl, ACS, UserInterface, Other */
	uint32	RuleNumberOfEntries; /*!< The number of entries in the Rule  table. */
} LTQ_MAPI_Firewall_Chain;

/*!
    \brief Structure describing the  firewall packetfilter rules.
    ref: http://www.broadband-forum.org/cwmp/tr-181-2-4-0.html
*/
typedef struct ltq_mapi_firewall_rule {
	IFX_ID iid;		/*!< IFX Identifier of Packet Filter rule in
				   FW Object */
	char8 	Enable;		/*!< Enable of Packet filter Instance */
	char8 	Status;		/*!< Status of Packet filter Instance */

        /* Drop  (The firewall discards packets matching this rule)
         * Accept (The firewall forwards packets matching this rule)
         * Reject (The firewall discards packets matching this rule, and sends an ICMP message to the originating host, OPTIONAL)
         * Return (The firewall doesn't consider the remaining rules (if any) in the current chain, OPTIONAL)
         * TargetChain (The rules in the chain referenced by the TargetChain parameter are matched, OPTIONAL)  
         */

	char8	Target[32];	/*!< must be under 30 chars */
	int32	Log;		/*!< Enable or disable logging */
	char8	SourceInterface[32]; 
	int32	SourceInterfaceExclude;
	char8	DestInterface[32];
	int32	DestInterfaceExclude;
	int32	IPVersion;

	char8	DestIP[45];	/*!< An empty string indicates this criterion is not used for matching.(with prefix len) */
	int32	DestMask;
	int32	DestIPExclude;

	char8	SourceIP[45];	/*!< An empty string indicates this criterion is not used for matching.(with prefix len) */
	int32	SourceMask;
	int32	SourceIPExclude;

	char8	Protocol;	/*!< Protocol Type */
	int32	ProtocolExclude;

	int16	DestPort;	/*!< A value of -1 indicates this criterion is not used for matching. */
	int16	DestPortRangeMax;   /*!< 	If specified, indicates the Rule  criterion is to include the 
					port range from DestPort  through DestPortRangeMax (inclusive) */
	int32	DestPortExclude;


	uint16	SourcePort;	/*!< A value of -1 indicates this criterion is not used for matching. */
	uint16	SourcePortRangeMax; /*!< 	If specified, indicates the Rule  criterion is to include the 
					port range from SourcePort  through SourcePortRangeMax (inclusive) */
	int32	SourcePortExclude;


} LTQ_MAPI_Firewall_Rule;

/*!
    \brief Structure describing the Firewall Packet Filter Parent Object.
*/
typedef struct ifx_mapi_firewall_pf {
	IFX_ID iid;		/*!< Packet Filter Singleton Object Id */
	char8 enable;		/*!< Enable flag of object */
	uint32 ruleNoOfEntries;	/*!< No. of rule object entries */
} IFX_MAPI_Firewall_PF;

/*!
    \brief Structure describing the DMZ (De-militiarized LAN Host).
*/
typedef struct Dmz_struct {
	IFX_ID iid;		/*!< IFX Identifier of DMZ */
	char8 feature_enable;	/*!< Enable Flag */
	char8 status;		/*!< Status of DMZ */
	struct in_addr ip;	/*!< IP Address of DMZ Host */
} IFX_MAPI_Firewall_DMZ;

/*!
    \brief Structure describing the Firewall URL Filter.
*/
#ifdef CONFIG_FEATURE_URL_FILTERING
typedef struct url_filter_cfg {
	IFX_ID	iid;		/*!< Identifier of URL object */
	char8	URLName[MAX_NAME_LEN]; /*!< URL entry to block */
} url_filter_cfg_t;
#endif
/****************************
 *firewall object completed
 *****************************/
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
typedef struct {
	DSL_G997_LineStatus_t linestatus_us, linestatus_ds;
} DSL_TEST_PARAMS_LINE_STATUS;

typedef struct {
	DSL_G997_DeltHlog_t hlog_us, hlog_ds;
} DSL_TEST_PARAMS_HLOG;

typedef struct {
	DSL_G997_DeltQln_t qln_us, qln_ds;
} DSL_TEST_PARAMS_QLN;

typedef struct {
	DSL_G997_DeltSnr_t snr_us, snr_ds;
} DSL_TEST_PARAMS_SNR;

typedef struct {
	DSL_G997_SnrAllocationNsc_t snr_alloc_status_us, snr_alloc_status_ds;
} DSL_TEST_PARAMS_SNR_ALLOC_STATUS;

#endif

#ifndef CONFIG_PACKAGE_IFX_DSL_CPE_API
/*!
    \brief Structure describing the ADSL WAN Diagnostics.
*/
typedef struct wan_adsl_diagnostics {
	IFX_ID iid;		/*!< IFX Identifier */
	int32 f_enable;		/*!< Flag for enabling the object. Valid
				   values are: IFX_ENABLED and IFX_DISABLED. */
	DIAGNOSTIC_STATE diagnostic_state;	/*!< Diagnostics State */
	int32 ACTPSDds;		/*!< ACTPSDds diagnostic parameter */
	int32 ACTPSDus;		/*!< ACTPSDus diagnostic parameter */
	int32 ACTATPds;		/*!< ACTATPds diagnostic parameter */
	int32 ACTATPus;		/*!< ACTATPus diagnostic parameter */
	int16 HLINSCds;		/*!< HLINSCds diagnostic parameter */
	int16 HLINSCus;		/*!< HLINSCus diagnostic parameter */
	int16 HLINpsds[1024];	/*!< HLINpsds diagnostic parameter */
	int16 HLINpsus[1024];	/*!< HLINpsds diagnostic parameter */
	int16 HLOGpsds[1024];	/*!< HLOGpsds diagnostic parameter */
	int16 HLOGpsus[1024];	/*!< HLOGpsus diagnostic parameter */
	int16 HLOGMTus;		/*!< HLOGMTus diagnostic parameter */
	int16 HLOGMTds;		/*!< HLOGMTds diagnostic parameter */
	int16 HLOGGds;		/*!< HLOGGds diagnostic parameter */
	int32 HLOGGus;		/*!< HLOGGus diagnostic parameter */
	int16 QLNpsds[512];	/*!< QLNpsds diagnostic parameter */
	int16 QLNpsus[512];	/*!< QLNpsus diagnostic parameter */
	int16 QLNMTds;		/*!< QLNMTds diagnostic parameter */
	int16 QLNMTus;		/*!< QLNMTus diagnostic parameter */
	int16 QLNGds;		/*!< QLNGds diagnostic parameter */
	int16 QLNGus;		/*!< QLNGus diagnostic parameter */
	int16 SNRpsds[512];	/*!< SNRpsds diagnostic parameter */
	int16 SNRpsus[512];	/*!< SNRpsus diagnostic parameter */
	int16 SNRMTds;		/*!< SNRMTds diagnostic parameter */
	int16 SNRMTus;		/*!< SNRMTus diagnostic parameter */
	int16 SNRGds;		/*!< SNRGds diagnostic parameter */
	int16 SNRGus;		/*!< SNRGus diagnostic parameter */
	int16 BITSpsds[512];	/*!< BITSpsds diagnostic parameter */
	int16 GAINSpsds[512];	/*!< GAINSpsds diagnostic parameter */
} WAN_DSL_DIAGNOSTICS;

#else

/*!
    \brief This is the data structure for WAN DSL Diagnostics.
*/
typedef struct wan_adsl_diagnostics {
	IFX_ID iid;		/*!< Instance Id of WAN ATM F5 Loopback
				   Diagnostics. */
	int32 f_enable;		/*!< Flag for enabling the object. Valid
				   values are: IFX_ENABLED and IFX_DISABLED. */
	DIAGNOSTIC_STATE diagnostic_state;	/*!< State of Diagnostics on object. */
	DSL_G997_LineStatus_t usLineStatus;	/*!< Upstream Line Status */
	DSL_G997_LineStatus_t dsLineStatus;	/*!< Downstream Line Status */
	DSL_G997_DeltHlinScale_t hlinScale;	/*!< DELT HLIN Scale */
	DSL_G997_DeltHlinScale_t hlinScaleus;	/*!< DELT HLIN Scale */
	DSL_G997_DeltHlin_t hlin;	/*!< DElT HLIN */
	DSL_G997_DeltHlin_t hlinus;	/*!< DElT HLIN */
	DSL_G997_DeltHlog_t hlogds;	/*!< DElT HLOG */
	DSL_G997_DeltHlog_t hlogus;	/*!< DElT HLOG */
	DSL_G997_DeltQln_t qln;	/*!< DELT QLN */
	DSL_G997_DeltQln_t qlnus;	/*!< DELT QLN */
	DSL_G997_DeltSnr_t snrds;
	DSL_G997_DeltSnr_t snrus;
	DSL_G997_SnrAllocationNsc_t snr;	/*!< DELT SNR Allocation */
	DSL_G997_BitAllocationNsc_t bit;	/*!< DELT Bit Allocation */
	DSL_G997_GainAllocationNsc_t gain;	/*!< DELT Gain ALlocation */
} WAN_DSL_DIAGNOSTICS;
#endif				// CONFIG_PACKAGE_IFX_DSL_CPE_API

/** TR111 related stucts  **/
/*!
    \brief This is the data structure for gateway information. It is used in TR-106 supporting IGD.
*/
typedef struct gateway_info {
	IFX_ID iid;		/*!< IFX Identifier of Gateway (GW) */
	char8 oui[MAX_OUI_LEN];	/*!< IEEE OUI of manufacturer of GW. */
	char8 product_class[MAX_PROD_CLASS_LEN];	/*!< Product Class of GW. */
	char8 serial_number[MAX_SERIAL_NUM_LEN];	/*!< Serial Number of GW.  */
	struct in_addr ipaddr;	/*!< IP address of GW. */

} GATEWAY_INFO;

/*!
    \brief This is the data structure for manageable device for TR-106 devices.
*/
typedef struct manageabledevice_info {
	IFX_ID iid;		/*!< IFX Identifier */
	char8 oui[MAX_OUI_LEN];	/*!< IEEE OUI information of manufacturer of
				   End-Device. */
	char8 product_class[MAX_PROD_CLASS_LEN];	/*!< Product Class of
							   End-Device (ED) */
	char8 serial_number[MAX_SERIAL_NUM_LEN];	/*!< Serial Number of
							   End-Device (ED) */
	char8 ipaddr[MAX_IPADDR_LIST_LEN];	/*!< IP address of End Device (ED) */

} MANAGEABLE_DEVICE;

/*!
    \brief This is the data structure for NTP Client configuration.
*/
typedef struct _ntp_client_cfg {
	IFX_ID iid;		/*!< IFX Identifier */
	int32 f_enable;		/*!< Enable Flag */
	char8 ntpServer1[MAX_NTP_SERVER_LEN];	/*!< Primary NTP Server */
	char8 ntpServer2[MAX_NTP_SERVER_LEN];	/*!< Secondary NTP Server
						   (optional) */
	char8 ntpServer3[MAX_NTP_SERVER_LEN];	/*!< Third NTP Server
						   (optional) */
	char8 ntpServer4[MAX_NTP_SERVER_LEN];	/*!< Fourth NTP Server
						   (optional) */
	char8 ntpServer5[MAX_NTP_SERVER_LEN];	/*!< Fifth NTP Server
						   (optional) */
	uint32 currentLocalTime;	/*!< Current Local Time */
	int32 timeMinutesOffset;	/*!< Offset in Minutes from GMT. */
	char8 tzName[MAX_TIME_ZONE_NAME_LEN];	/*!< TimeZone Name */
	int32 timeZoneIdx;	/*!< Time Zone Index */
	char8 dlsFlag;		/*!< Day Light Savings Enabled Flag. */
	uint32 dlsStart;	/*!< Day Light Savings Start */
	uint32 dlsEnd;		/*!< Day Light Savings End */
	NTP_STATUS status;      /*!< Status of time support on the CPE */
} NTP_CLIENT_CFG;

/*!
    \brief This is the data structure for Syslog information.
*/
typedef struct syslog_info {
	SYSLOG_MODE mode;	/*!< Mode of SysLogging. */
	int32 port;		/*!< Port Number for remote logging. */
	struct in_addr remote_ip;	/*!< IP address for remote logging. */
	SYSLOG_DISP_LEVEL log_level;	/*!< Syslog display level */
	char8 *buf;		/*!< buffer carrying log text. */
} SYSLOG_INFO;

#ifdef CONFIG_FEATURE_IFX_WIRELESS
/*!
    \brief Structure describing the WLAN supported rates.
*/
typedef struct ifx_mapi_wlan_supported_rates {
	IFX_MAPI_WLAN_Standard std;	/*!< WLAN Standard */
	IFX_MAPI_WLAN_FreqBand freqBand;	/*!< WLAN Frequency Band */
	float dataRate[IFX_MAPI_WLAN_MAX_PHY_CHANNELS];	/*!< WLAN Data rates */
} IFX_MAPI_WLAN_SupportedRate;

/*!
    \brief Structure describing the WLAN channel list.
*/
typedef struct ifx_mapi_wlan_channel_list {
	IFX_MAPI_WLAN_Standard std;	/*!< WLAN Standard */
	IFX_MAPI_WLAN_FreqBand freqBand;	/*!< WLAN Frequency Band */
//      IFX_MAPI_WLAN_Country   country;                                     /*!< WLAN Country */ // Pramod - since tsc driver stores these per ap type this parameter is not supported
	char8 country[3];	// two letter country code
	uint32 length;		/*!< Length */
	uint32 chanNumList[IFX_MAPI_WLAN_MAX_PHY_CHANNELS];	/*!< Physical channels
								   list */
	uint32 chanFreqList[IFX_MAPI_WLAN_MAX_PHY_CHANNELS];	/*!< Channel
								   Frequency
								   List */
} IFX_MAPI_WLAN_ChannelList;

/** data structure representing a channel domain */
/*!
    \brief Structure describing the WLAN Regulator Domain Information.
*/
typedef struct ifx_mapi_wlan_reg_domain {
	uint32 length;		/*!< Length of Channel DOmain */
	uint32 channels[IFX_MAPI_WLAN_MAX_PHY_CHANNELS];	/*!< Channels
								   Information */
} IFX_MAPI_WLAN_RegDomain;

/**
   WLAN statistics on per VAP basis provide the following counters
*/
/*!
    \brief Structure describing the WLAN Statistics for per VAP/AP basis.
*/

typedef struct ifx_mapi_wlan_stats {
	IFX_ID iid;		/*!< IFX Identifier of WLAN Statistics */
	uint32 bytesTx;		/*!< Transmitted Bytes Count */
	uint32 bytesRx;		/*!< Received Bytes Count */
	uint32 pktsTx;		/*!< Transmitted Packets Count */
	uint32 pktsRx;		/*!< Received Packets Count */
	uint32 errorsTx;	/*!< Erroneous Transmitted Packets Count */
	uint32 errorsRx;	/*!< Erroneous Received Packets Count */
	uint32 ucPktsTx;	/*!< Unicast Transmitted Packets Count */
	uint32 ucPktsRx;	/*!< Unicast Received Packets Count */
	uint32 mcPktsTx;	/*!< Multicast Transmitted Packets Count */
	uint32 mcPktsRx;	/*!< Multicast Received Packets Count */
	uint32 bcPktsTx;	/*!< Broadcasted Transmitted Packets Count */
	uint32 bcPktsRx;	/*!< Broadcasted Received Packets Count */
	uint32 discardPktsTx;	/*!< Discarded Transmitted Packets Count */
	uint32 discardPktsRx;	/*!< Discarded Received Packets Count */
	uint32 bytesSent; /*!<	Number of bytes sent successfully */
	uint32 bytesReceived; /*!< Number of bytes received successfully */
	uint32 unicastPacketsSent; /*!< Number of directed packets sent */
	uint32 unicastPacketsReceived;		/*!<  Number of free TX MSDUs */
	uint32 multicastPacketsSent;	/*!< Number of directed packets received */
	uint32 multicastPacketsReceived;	/*!< Number of multicast packets sent */
	uint32 broadcastPacketsSent;	/*!< Number of multicast packets received */
	uint32 broadcastPacketsReceived; /*!< Number of broadcast packets sent */
	uint32 nACKedPacketsSent; /*!<	Number of TX packets not acknowledged by wireless peer */
	uint32 txPacketsDiscardedDrvNoPeers; /*!< Number of TX packets discarded by driver due to no peers were connected when they arrived */
	uint32 txPacketsDiscardedDrvACM; /*!< Number of TX packets discarded by driver's ACM facility */
	uint32 txPacketsDiscardedDrvEAPOLCloned;		/*!< Number of EAPOL packets arrived in MAC cloning mode dropped by driver */
	uint32 txPacketsDiscardedDrvUnknownDestinationDirected;	/*!< Number of directed TX packets with unknown destination field value dropped by driver */
	uint32 txPacketsDiscardedDrvUnknownDestinationMcast;	/*!< Number of multicast TX packets with unknown destination field value dropped by driver */
	uint32 txPacketsDiscardedDrvNoResources;	/*!< TX packets discarded by driver due to system resources exhausted */
	uint32 txPacketsDiscardedDrvSQOverflow; /*!< TX packets discarded by driver due to driver queues overflow */
	uint32 txPacketsDiscardedDrvEAPOLFilter; /*!<	TX packets discarded by driver's EAPOL filter */
	uint32 txPacketsDiscardedDrvDropAllFilter; /*!< TX packets discarded by driver's drop all filter */
	uint32 txPacketsDiscardedDrvTXQueueOverflow; /*!< TX packets discarded by driver due to HW TX queue overflow */
	uint32 rxPacketsDiscardedDrvForeign;		/*!<  Foreign RX packets dropped by driver */
	uint32 rxPacketsDiscardedDrvLoopback;	/*!< RX packets with source address of one of the devices behind the host dropped */
	uint32 rxPacketsDiscardedDrvTooOld;	/*!< Too old RX packets dropped by reordering mechanism */
	uint32 rxPacketsDiscardedDrvDuplicate;	/*!< Duplicate RX packets dropped by reordering mechanism */
	uint32 rxPacketsDiscardedDrvNoResources; /*!< Rx packets discarded by driver due to system resources exhausted */
	uint32 txPacketsDiscardedFw; /*!<	Number of TX packets discarded by FW */
	uint32 rxPacketsDiscardedFw; /*!< Number of RX packets discarded by FW */
	uint32 pairwiseMICFailurePackets; /*!< Packets with pairwise key MIC failure received */
	uint32 groupMICFailurePackets;		/*!<  Packets with group key MIC failure received */
	uint32 unicastReplayedPackets;	/*!< Directed packet replays detected */
	uint32 multicastReplayedPackets;	/*!< Multicast/Broadcast packet replays detected */
	uint32 retryCount;	/*!< Number of frames that were retried */
	uint32 multipleRetryCount; /*!< Number of frames that were retried multiple times */
	uint32 fwdRxPackets;	/*!< Number of packets received that should be forwarded to one or more STAs */
	uint32 fwdRxBytes;	/*!< Number of bytes received that should be forwarded to one or more STAs */
	uint32 barFramesCount; /*!< Number of BAR frames received */
	uint32 msudReceivedAC[4];	/*!< Number of MSDUs of each QoS priority received */
	uint32 msduTransmittedAC[4];	/*!< Number of MSDUs of each QoS priority transmitted */
	uint32 msduUsedAC[4]; /*!< Number of MSDUs of each QoS priority used */
	uint32 macStats;	/*!< Various FW statistics accessible via UM_DBG_GET_STATISTICS_REQ */
	uint32 sendQueueStats;	/*!< Various SendQueue statistics accessible via SendQueue proc entry */
	uint32 reorderingStats; /*!< Various reordering statistics accessible vi ReorderingStat proc entry */
} IFX_MAPI_WLAN_Stats;

/**
   WLAN statistics on per radio basis provide the following counters
*/
/*!
    \brief Structure describing the WLAN Statistics for per physical radio.
*/

typedef struct ifx_mapi_wlan_phy_stats {
	IFX_ID iid;		/*!< IFX Identifier of WLAN Statistics */
	uint32 fcsErrorCount; /*!<	Number of received frames containing frame check sequence (FCS) errors */
	uint32 rtsSuccessCount; /*!< Successful request to send (RTS) frames */
	uint32 rtsFailureCount; /*!< Failed request to send (RTS) frames */
	uint32 freeTxMSDUs;		/*!<  Number of free TX MSDUs */
	uint32 txMSDUsUsagePeak;	/*!<  TX MSDUs usage peak */
	uint32 bistCheckPassed;	/*!< Whether HW device passed BIST check */
	uint32 manMsgSent;	/*!< Number of management messages sent */
	uint32 manMsgConfirmed; /*!< Number of management messages confirmed */
	uint32 manMsgPeak;	/*!< Peak number of management messages sent simultaneously */
	uint32 dbgMsgSent; /*!< Number of debug messages sent */
	uint32 dbgMsgConfirmed;  /*!< Number of debug messages confirmed */
	uint32 dbgMsgPeak;  /*!< Peak number of debug messages sent simultaneously */
	uint32 fwLoggerPacketsProcessed;  /*!< FW logger packets processed */
	uint32 fwLoggerPacketsDropped;  /*!< FW logger packets dropped */
	uint32 datFramesReceived; /*!< Number of data frames received */
	uint32 ctlFramesReceived; /*!< Number of control frames received */
	uint32 manFramesReceived; /*!< Number of management frames received */
} IFX_MAPI_WLAN_PhyStats;

/**
   WPA/WPA2 Security Failures Count
*/
/*!
    \brief Structure describing the WPA/WPA2 Security Failures Count.
*/
typedef struct ifx_mapi_wlan_wpa_sec_counters {
	uint32 countPSKFailures;	/*!< PSK Faiures Count */
	uint32 countIntegrityFailures;	/*!< Integrity Check Failures Count */
} IFX_MAPI_WLAN_WPA_SecCounters;

/*!
    \brief Structure describing the WLAN Associated stations information.
*/
typedef struct ifx_mapi_wlan_assoc {
	char8 macAddress[IFX_MAPI_MAC_ADDR_LEN];	/*!< MAC address of station */
	struct in_addr ipAddress;	/*!< IP address of station */
	IFX_MAPI_WLAN_STA_AUTH_STATE staAuthenticated;	/*!< Station
							   Authentication State
							 */
	float lastDataTxRate;	/*!< Last Data Transmit Rate */
	char8 wpa2LastUCcipher[IFX_MAPI_WPA2_MAX_CIPHER_LEN];	/*!< WPA2 Last
								   Unicast
								   Cipher
								   Length */
	char8 wpa2LastMCcipher[IFX_MAPI_WPA2_MAX_CIPHER_LEN];	/*!< WPA2 Last
								   Multicast
								   Cipher
								   Length */
	char8 wpa2LastPMKId[IFX_MAPI_WPA2_MAX_CIPHER_LEN];	/*!< WPA2 Last PMK
								   Identifier */
} IFX_MAPI_WLAN_AssocInfo;

/*!
    \brief This is the data structure for WLAN MAC address control.
*/
typedef struct wlan_macaddr {
	IFX_ID iid;		/*!< IFX Identifier */
	MACADDR_CONTROL_INTF_TYPE InterfaceType;	/*!< Type of Interface */
	char8 macAddr[IFX_MAPI_MAC_ADDR_LEN];	/*!< MAC Address to be
						   controlled. */
} WLAN_MACADDR;

/*!
    \brief This is the data structure for WLAN MAC control.
*/
typedef struct wlan_mac_control {
	MACADDR_CONTROL_MODE global_mode;	/*!< MAC address Control Mode. */
	WLAN_MACADDR *macAddrList;	/*!< List of MAC addresses. */
} WLAN_MAC_CONTROL;

/**
   WLAN (AP-Name) specific MAC control
*/
/*!
    \brief Structure describing the WLAN MAC control feature.
*/
typedef struct ifx_mapi_wlan_mac_control {
	IFX_ID iid;		/*!< IFX Identifier of WLAN MAC Control */
	char8 macAddr[IFX_MAPI_MAC_ADDR_LEN];	/*!< MAC Address */
} IFX_MAPI_WLAN_MAC_Control;

/**

*/
/*!
    \brief Structure describing the global mac address control.
*/
typedef struct ifx_mapi_glbl_mac_control {
	IFX_ID iid;		/*!< IFX Identifier of Global MAC Control */
	char8 macAddr[IFX_MAPI_MAC_ADDR_LEN];	/*!< Station MAC Address */
	IFX_MAPI_MACADDR_ControlIntfType ifType;	/*!< Interface Type */
	IFX_MAPI_MACADDR_ControlMode cntrlMode;	/*!< Control Mode */
} IFX_MAPI_GlobalMacControl;

/**

*/
/*!
    \brief This is the data structure for WEP Keys of WLAN.
*/
typedef struct ifx_mapi_wlan_wep_key {
	IFX_ID iid;		/*!< IFX Identifier */
	char8 wepKey[IFX_MAPI_WEP_KEY_MAX_LEN];	/*!< WEP Key */
} IFX_MAPI_WLAN_WEP_Key;

/**

*/
/*!
    \brief Structure describing the WLAN WEP Keys Configuration.
*/
typedef struct ifx_mapi_wlan_wep_cfg {
	IFX_MAPI_WLAN_KeyType wepKeyType;	/*!< WEP Key Type */
	IFX_MAPI_WLAN_WEP_EncrLevel wepEncrLevel;	/*!< WLAN WEP Key Encryption
							   Level */
	IFX_MAPI_WLAN_WEP_KeyIndex wepKeyIndex;	/*!< WEP Key Index */
	IFX_MAPI_WLAN_WEP_Key wepKey[IFX_MAPI_NUM_WEP_KEYS];	/*!< Set of
								   four WEP
								   Keys */
} IFX_MAPI_WLAN_WEP_Cfg;

/**
   \remark  preSharedKey parameter will be read-only and we will return null for time-being
*/

/*!
    \brief Structure describing the PSK and Passphrase Settings.
*/
typedef struct ifx_map_wlan_psk {
	IFX_ID iid;		/*!< WLAN-PSK object identifier */
	char8 passPhrase[IFX_MAPI_PASSPHRASE_MAX_LEN];	/*!< Passprase String */
	char8 preSharedKey[IFX_MAPI_PSK_MAX_LEN];	/*!< PSK String */
} IFX_MAPI_WLAN_PSKey;

/**

*/
/*!
    \brief Structure describing the personal settings of WLAN.
*/
typedef struct ifx_mapi_wlan_personal {
	IFX_MAPI_WLAN_KeyType pskType;	/*!< WLAN PSK Type */
	IFX_MAPI_WLAN_PSKey psk;	/*!< PreSharedKey */
	bool groupKeyEna;	/*!< GroupKey Enable */
	uint32 groupKeyIntvl;	/*!< Group Key Interval */
	char8 assocDevMACAddr[IFX_MAPI_MAC_ADDR_LEN];	/*!< Associated device
							   MAC Address */
} IFX_MAPI_WLAN_PersonalCfg;

/*!
    \brief This is the data structure for 802.1x mode of Security in WLAN.
*/
typedef struct ifx_mapi_wlan_wpa_802_1x {
	IFX_ID iid;		/*!< IFX Identifier for 802.1X object */
	bool groupKeyEna;	/*!< Group Key Enable Flag */
	uint32 groupKeyIntvl;	/*!< Group Key Interval *//* group key interval */
	bool wpa2PreAuthEna;	/*!< WPA2 Pre-Authentication Enable */
	uint32 wpa2ReAuthIntvl;	/*!< WPA2 Re-Authentication Enable */
	struct in_addr radiusServerIP;	/*!< RADIUS IP Address */
	uint32 radiusPort;	/*!< RADIUS Port Number */
	char8 radiusServerSecret[IFX_MAPI_PASSPHRASE_MAX_LEN];	/*!< RADIUS
								   Secret
								   phrase. */
	char8 domainName[IFX_MAPI_RADIUS_AUTH_DOMAIN];	/*!< RADIUS Domain
							   Name */
	char8 userName[IFX_MAPI_RADIUS_AUTH_USER];	/*!< RADIUS User name */
	IFX_MAPI_WLAN_Dot_1X_AuthType authType;	/*!< Authentication Type */
	IFX_MAPI_WLAN_Dot_1X_AuthProtocol authProto;	/*!< Authentication
							   Protocol */
} IFX_MAPI_WLAN_802_1x;

/**

*/
/*!
    \brief Structure describing the aggregate of WLAN Security Parameters.
*/
typedef union ifx_mapi_wlan_security_params {
	IFX_MAPI_WLAN_WEP_Cfg wepCfg;	/*!< WEP Config */
	IFX_MAPI_WLAN_PersonalCfg personalCfg;	/*!< Personal i.e. PSK Config */
	IFX_MAPI_WLAN_802_1x wlRadius;	/*!< RADIUS or 802.1X Config */
} IFX_MAPI_WLAN_SecurityParams;

/**

*/
/*!
    \brief Structure describing the WLAN Security Configuration.
*/
typedef struct ifx_mapi_wlan_security_cfg {
	IFX_ID iid;		/*!< Identifier of WLAN Security Object */
	IFX_MAPI_WLAN_BeaconType beaconType;	/*!< WLAN Beacon Type */
	IFX_MAPI_WLAN_AuthType wlAuth;	/*!< WLAN Authentication Type */
	IFX_MAPI_WLAN_EncrType wlEncr;	/*!< WLAN Encryption Type */
	IFX_MAPI_WLAN_AuthType basicAuth;	/*!< Basic Auth Type - Redundant, but
						   required for TR-069 */
	IFX_MAPI_WLAN_AuthType wpaAuth;	/*!< WPA Auth Type - Redundant, but
					   required for TR-069 */
	IFX_MAPI_WLAN_AuthType wpa2Auth;	/*!< WPA2 Auth Type - Redundant, but
						   required for TR-069 */
	IFX_MAPI_WLAN_EncrType basicEncr;	/*!< Basic Encryption Type -
						   Redundant, but required for TR-069 */
	IFX_MAPI_WLAN_EncrType wpaEncr;	/*!< WPA Encryption Type - Redundant,
					   but required for TR-069 */
	IFX_MAPI_WLAN_EncrType wpa2Encr;	/*!< WPA2 Encryption Type - Redundant,
						   but required for TR-069 */
	IFX_MAPI_WLAN_SecurityParams secParams;	/*!< WLAN Security Parameters
						   Union */
	IFX_MAPI_MACADDR_ControlMode macAddrCntrlEna;	/*!< MAC Address
							   Control Mode */
} IFX_MAPI_WLAN_SecCfg;

/*!
    \brief Structure describing the WLAN WPS Configuration.
*/
typedef struct ifx_mapi_wlan_wps {
	IFX_ID iid;		/*!< IFX Identifier of WLAN WPS configuration */
	bool enable;		/*!< Enable flag of WPS instance */
	char8 apWpsName[IFX_MAPI_WPS_DEV_NAME_LEN];	/*!< Device Name */
	uint32 apWpsPin;	/*!< Device Password */
	bool enrolleeEna;	/*!< enrollee enable flag */
	bool proxyEna;		/*!< proxy enable flag */
	bool intRegEna;		/*!< internal register enable */
	char8 uuidAp[IFX_MAPI_WLAN_MAX_UUID_LEN];	/*!< UUID */
	IFX_MAPI_WPS_CfgMethods suppCfgMethods[IFX_MAPI_WPS_MAX_CFG_METHODS];	/*!< Supported WPS Config Methods */
	IFX_MAPI_WPS_CfgMethods enaCfgMethods[IFX_MAPI_WPS_MAX_CFG_METHODS];	/*!< Enabled WPS Config Methods */
	IFX_MAPI_WPS_LockedState setupLockedState;	/*!< Locked State */
	bool setupLock;		/*!< Setup Lock */
	IFX_MAPI_WPS_ConfigState cfgState;	/*!< Config State */
	IFX_MAPI_WPS_ConfigError lastConfigError;	/*!< Last Config Error */
	bool regsEstbld;	/*!< Registrar Established or not */
	bool *reserved;		/*!< Reserved - For future use */
	uint32 maxPinLockout; /*!< Time in seconds WPS pin is disabled after X consecutive failed WPS Pin attempts */
} IFX_MAPI_WLAN_WPS_Cfg;
#define WLAN_WPS_PARAM_COUNT              12

/*!
    \brief Structure describing the WLAN WPS Register.
*/
typedef struct ifx_mapi_wlan_wps_regs {
	IFX_ID iid;		/*!< Instance ID */
	bool enable;		/*!< Enable flag */
	char8 regsWpsName[IFX_MAPI_WPS_DEV_NAME_LEN];	/*!< WPS Device Name */
	char8 uuidRegs[IFX_MAPI_WLAN_MAX_UUID_LEN];	/*!< UUID Register */
	bool *reserved;		/*!< Reserved - For future use */
} IFX_MAPI_WLAN_WPS_Regs_Cfg;
#define WLAN_WPS_REGISTRAR_PARAM_COUNT    4

/*!
    \brief Structure describing the WLAN WPS EP MAC.
*/
typedef struct ltq_mapi_wlan_wps_ep_mac_cfg {
	IFX_ID iid;		/*!< IFX Identifier of WLAN WPS configuration */
	char8 macAddr[IFX_MAPI_MAC_ADDR_LEN];	/*!< Station MAC Address */
} LTQ_MAPI_WLAN_WPS_EP_MAC_Cfg;
#define WLAN_WPS_EPS_PARAM_COUNT	3

/*!
    \brief Structure describing the WLAN subsystem.
*/
typedef struct ltq_mapi_wlan_subsystem_cfg {
	IFX_ID iid;												/*!< Identifier */
	char8 vendor[IFX_MAPI_WLAN_MAX_VENDOR_NAME_LEN];		/*!< WLAN Vendor Name */
	char8 hwName[IFX_MAPI_WLAN_MAX_VENDOR_NAME_LEN];		/*!< WLAN HW Name */
	char8 prefixScript[IFX_MAPI_WLAN_MAX_VENDOR_NAME_LEN];	/*!< WLAN Script prefix */
	IFX_MAPI_WLAN_Standard standard[IFX_MAPI_WLAN_MAX_STD];	/*!< Supported WLAN Standards */
	IFX_MAPI_WLAN_FreqBand freq;							/*!< Supported Frequency Bands */
	uint8 powerLvl[IFX_MAPI_MAX_POWER_LEVELS];				/*!< Supported power levels */
	IFX_MAPI_WLAN_BeaconType security;						/*!< Supported Security Types */
	bool radius;											/*!< RADIUS Support - Present or not */
	bool wmm;												/*!< WMM capable or not */
	bool uapsd;												/*!< WMM-UAPS Capable or not */
	bool wps;												/*!< WPS Capable or not */
	/*!< Supported WPS Config Methods */
	IFX_MAPI_WPS_CfgMethods wpsCfgMthds[IFX_MAPI_WPS_MAX_CFG_METHODS];
	bool wds;												/*!< WDS Capable or not */
	uint32 wdsRep;											/*!< WDS Repeatition Count Support */
	uint8 maxVap;											/*!< Maximum no of VAPs supported */
	uint32 maxClientsPerVap;								/*!< Maximum no. of clients per VAP */
	bool macCntrlPerVap;									/*!< Is MAC control per VAP supported */
	uint32 nMacCntrlEntries;								/*!< Number of MAC control Entries */
	uint8 nRxAntenna;										/*!< number of RX antennas */
	uint8 nTxAntenna;										/*!< number of TX antennas */
	bool wideChanSupport;									/*!< wide channel (40MHz) support */
	uint8 mcsRange;											/*!< highest MCS supported */
	bool ampduSupport;										/*!< A-MPDU support */
	bool amsduSupport;										/*!< A-MSDU support */
} LTQ_MAPI_WLAN_SubsystemCfg;

/*!
    \brief Structure describing the WLAN Capability.
*/
typedef struct ifx_mapi_wlan_capability {
	IFX_ID iid;		/*!< Identifier of Capability */
	char8 vendor[IFX_MAPI_WLAN_MAX_VENDOR_NAME_LEN];	/*!< WLAN Vendor Name */
	IFX_MAPI_WLAN_Standard std[IFX_MAPI_WLAN_MAX_STD];	/*!< Supported WLAN
								   Standards */
	IFX_MAPI_WLAN_FreqBand freq;	/*!< Supported Frequency Bands */
	IFX_MAPI_WLAN_BeaconType secType;	/*!< Supported Security Type */
	uint8 powerLevelsSupported[IFX_MAPI_MAX_POWER_LEVELS];	/*!< Supported
								   power levels
								 */
	bool radiusSupport;	/*!< RADIUS Support - Present or not */
	bool WMMcapable;	/*!< WMM capable or not */
	bool UAPSDcapable;	/*!< WMM-UAPS Capable or not */
	bool WPScapable;	/*!< WPS Capable or not */
	IFX_MAPI_WPS_CfgMethods WPSMthdsArray[IFX_MAPI_WPS_MAX_CFG_METHODS];	/*!<
										   Supported
										   WPS
										   Config
										   Methods
										 */
	bool WDScapable;	/*!< WDS Capable or not */
	uint32 WDSRepsCount;	/*!< WDS Repeatition Count Support */
	uint8 maxVAPSupported;	/*!< Maximum no of VAPs supported */
	uint32 maxWlanClients;	/*!< Maximum no. of clients per radio */
	uint32 maxClientsPerVAP;	/*!< Maximum no. of clients per VAP */
	bool macCntrlPerVAP;	/*!< Is MAC control per VAP supported */
	uint32 numMacCntrlEntries;	/*!< Number of MAC control Entries */
	uint8 numRxAntns;	/*!< number of RX antennas */
	uint8 numTxAntns;	/*!< number of TX antennas */
	bool wideChanSupport;	/*!< wide channel (40MHz) support */
	uint8 mcsRange;		/*!< highest MCS supported */
	bool ampduSupport;	/*!< A-MPDU support */
	bool amsduSupport;	/*!< A-MSDU support */
	bool wlanCapValid;
} IFX_MAPI_WLAN_Capability;

/*!
    \brief This is the data structure for main configuration of WLAN.
*/
typedef struct ifx_mapi_wlan_main_cfg {
	IFX_ID iid;		/*!< IFX Identifier */
	uint32 radioCpeId;	/*!< Reference to Physical Radio Id */
	uint32 apEnable;	/*!< Enable Flag */
	uint32 status;		/*!< Status information */
	char8 apName[IFX_MAPI_WLAN_AP_NAME];	/*!< AP Name - unique
						   identifier other than cpeId */
	IFX_MAPI_WLAN_DevType devType;	/*!< WLAN Device Type */
	bool bssidOverride;	/*!< BSSID Override config */
	char8 bssid[IFX_MAPI_WLAN_BSSID_LEN];	/*!< BBSID of AP/VAP */
	char8 ssid[IFX_MAPI_WLAN_SSID_LEN];	/*!< SSID of AP/VAP instance */
	IFX_MAPI_WLAN_SSID_Mode ssidMode;	/*!< SSID Mode */
	float basicDataRates[IFX_MAPI_WLAN_MAX_DATA_RATES_NUM];	/*!< Basic
								   Data Rates */
	float operDataRates[IFX_MAPI_WLAN_MAX_DATA_RATES_NUM];	/*!<
								   Operational
								   Data Rates */
	float possblDataRates[IFX_MAPI_WLAN_MAX_DATA_RATES_NUM];	/*!< Possibel
									   Data Rates */
	float maxBitRate;	/*!< Maximum Bit Rate */
	char8 locationDescr[IFX_MAPI_WLAN_LOCATION_STR];	/*!< WLAN Location
								   Description */
	uint32 vlanId;		/*!< VLAN Identifier */
	bool apIsolationEna;	/*!< AP Isolation Enabled or not */
	uint8 repDistFromRoot;	/*!< Repeater distance from Root */
	char8 repPeerBSSID[IFX_MAPI_WLAN_BSSID_LEN];	/*!< Peer Repeater MAC
							   Address */
	bool WMMena;		/*!< WMM Enable Flag */
	bool UAPSDena;		/*!< WMM-UAPSD Enable Flag */
	bool WPSena;		/*!< WPS Enable Flag */
	bool WDSena;		/*!< WDS Enable Flag */
	uint8 maxStations;	/*!< max number of stations to associated */
	uint8 minResSta;	/*!< Minimum number of reserved clients */
	IFX_MAPI_WLAN_Standard networkMode;	/*!< Standard to be used */
} IFX_MAPI_WLAN_MainCfg;

/*!
    \brief This data structure includes all parameters required for configuring the aggregation feature.
*/

typedef struct {
	bool ampduEna;		/*!< Enable/disable of A-MPDU aggregation */
	IFX_MAPI_WLAN_Direction ampduDir;	/*!< Direction for which A-MPDU
						   aggregation is enabled */
	IFX_MAPI_WLAN_AMPDU_Length ampduLen;	/*!< Length of the A-MPDU
						   aggregation in Byte.
						   Possible values are: - 8191
						   - 16383 - 32767 - 65535 */
	uint8 ampduFrmsDensity;	/*!< Maximum number of frames to be agregated
				   in one A-MPDU. Possible values are from 1 to
				   64 frames. */
	bool amsduEna;		/*!< Enable/disable of A-MSDU aggregation */
	IFX_MAPI_WLAN_Direction amsduDir;	/*!<Direction for which A-MSDU
						   aggregation is enabledr */
	IFX_MAPI_WLAN_AMSDU_Length amsduLen;	/*!< Length of A-MSDU
						   aggregation in Byte.
						   Possible Values are: - 3839
						   - 7935. */
} IFX_MAPI_WLAN_Aggregation;

/*!
    \brief This data structure includes all parameters required for configuring the diversity feature.
*/

typedef struct {
	bool diversityEna;	/*!< Enable/disable the diversity feature */
	IFX_MAPI_WLAN_Direction diversityDir;	/*!< Direction for which
						   diversity is enabled */
	uint8 antenna;		/*!< Specify the number of antenna available
				   in system */
} IFX_MAPI_WLAN_Diversity;

/*!
    \brief This data structure includes all parameters related only to 11N features.
*/
typedef struct {
	IFX_MAPI_WLAN_ChannelBW chanBW;	/*!< Specify the channel bandwidth to
					   be used */
	IFX_MAPI_WLAN_Ext_ChannelPos extChPos;	/*!< WLAN External Channel Pos
						 */
	int8 mcs;		/*!< MCS */
	uint8 baWinSize;	/*!< Block Ack Window Size */
	IFX_MAPI_WLAN_Aggregation aggr;	/*!< Specify all settings to be used
					   for aggregation */
	IFX_MAPI_WLAN_GuardIntvl guardIntvl;	/*!< Configure usage of short
						   guard interval */
	IFX_MAPI_WLAN_Direction rxStbc;	/*!< RX STBC usage */
	IFX_MAPI_WLAN_Diversity diversity;	/*!< Diversity configuration */
	bool ldpcEna;		/*!< LDPC */
	bool 	twentyFourtyCoex;	/*!< 20/40MHz coexistence */
	bool 	fourtyMHzIntolerant;	/*!< 40MHz Intolerance */
	uint8 	transDelayFactor;	/*!< Transition delay factor */
	uint32	obssScan;	/*!< OBSS scan interval */
	bool	twentyFortyCoexForceApParams;
} IFX_MAPI_WLAN_PHY_11N;

/*!
    \brief Structure describing the WLAN Physical AutoCoc Config.
*/
typedef struct ltq_mapi_wlan_phy_auto_coc_cfg {
	IFX_ID iid;					/* !< Identifier of WLAN Physical AutoCoC Config Object */
	bool autoCocEnable;			/* !< Enable Flag */
	bool prevAutoCocEnable;		/* !< Save Auto CoC status on radio disable */
	uint8 nAntennas;			/* !< Number of Antennas */
	uint8 nPrevAntennas;		/* !< Save Number of Antennas on radio disable */
	uint32 timerIntval_1x1;		/* !< CoC Timer interval for 1x1 selection */
	uint32 timerIntval_2x2;		/* !< CoC Timer interval for 2x2 selection */
	uint32 timerIntval_3x3;		/* !< CoC Timer interval for 3x3 selection */
	uint32 highLim_1x1;			/* !< CoC Higher Limit for 1x1 selection */
	uint32 highLim_2x2;			/* !< CoC Higher Limit for 2x2 selection */
	uint32 lowLim_2x2;			/* !< CoC Lower Limit for 2x2 selection */
	uint32 lowLim_3x3;			/* !< CoC Lower Limit for 3x3 selection */
} LTQ_MAPI_WLAN_PhyAutoCocCfg;

/*!
    \brief Structure describing the WLAN WAVE Mulitcast Power Save.
*/
typedef struct ltq_mapi_wlan_vendor_wave_cfg {
	IFX_ID iid;					/* !< Identifier of WLAN Vendor WAVE Config Object */
	bool	logServerEna;
} LTQ_MAPI_WLAN_VendorWaveCfg;

/*!
    \brief Structure describing the WLAN Physical Config.
*/
typedef struct ifx_mapi_wlan_phy_cfg {
	IFX_ID iid;		/*!< Identifier of WLAN Physical Config Object
				 */
	bool radioEnable;	/*!< Enable Flag */
	uint32 status;		/*!< Status */
	IFX_MAPI_WLAN_Standard standard;	/*!< Standard to be used */
	IFX_MAPI_WLAN_FreqBand freqBand;	/*!< Frequency band to be used */
	char8 country[3];	/*!< //two letter country code */
	IFX_MAPI_WLAN_UsageEnv usageEnv;	/*!< Usage Environment */
	IFX_MAPI_WLAN_PreambleType preamble;	/*!< Preamble Type */
	uint8 channelsInUse[IFX_MAPI_WLAN_MAX_PHY_CHANNELS];	/*!< Channels
								   in use in
								   Air */
	uint8 possibleChans[IFX_MAPI_WLAN_MAX_PHY_CHANNELS];	/*!< Possibel
								   Channels */
	uint8 channelNo;	/*!< Channel Number */
	bool autoChannelEna;	/*!< Automatic Channel Selection Mode */
	bool beaconTxEna;	/*!< Beacon Transmit Enable */
	uint32 beaconIntvl;	/*!< Beacon Interval */
	uint8 dtimInt;		/*!< DTIM Interval */
	uint32 powerLvl;	/*!< Power Level */
	uint32 rts;		/*!< Request to Send */
	uint32 fts;		/*!< Frame to Send */
	bool insecOOBAccEna;	/*!< Insecure Out of Band Access Enable */
	bool autoRateFallBackEna;	/*!< Auto Rate Fallback Enable */
	float staticRate;	/*!< Static Rate in absence of
				   AutoRateFallBackEna */
	IFX_MAPI_WLAN_PHY_11N phy11N;	/*! Structure containing parameters related to 11n features */
	bool radarEna;		/*!< 802.11h Radar detection */
	LTQ_MAPI_WLAN_Beamform beamForm;	/*!< Beamforming */
	bool mc2ucEna;		/*!< Multicast to Unicast Conversion */
	LTQ_MAPI_WLAN_AckBoost boostMode;	/*!< Power Boost for acknowledgement */
	LTQ_MAPI_WLAN_PhyAutoCocCfg	phyAutoCoC;	/* !< Structure containing parameters for Auto CoC feature */
	LTQ_MAPI_WLAN_NetModeClass netModeClass;
	LTQ_MAPI_WLAN_VendorWaveCfg wlVendorWaveCfg;	/* !< Structure containing wave specific parameters */
} IFX_MAPI_WLAN_PhyCfg;

/*!
    \brief Structure describing the outoboud QoS in WLAN AP.
*/
typedef struct ifx_mapi_wlan_ap_wmm_cfg {
	IFX_ID iid;		/*!< IFX Identifier of WLAN AP WMM Config */
	IFX_MAPI_WLAN_WMM_AC ac;	/*!< WMM AP Access Category */
	uint32 AIFSN;		/*!< Arbitration Inter Frame Space Number */
	uint32 ECWmin;		/*!< Exponential Contention Window Minimum */
	uint32 ECWmax;		/*!< Exponential Contention Window Maximum */
	uint32 TXOP;		/*!< Transmit Opportunity Limit */
	bool ackPolicyEna;	/*!< Ack Policy - True: Ack, False: No Ack */
	uint32 admCntrl;	/*!< Admission Control */
	void *reserved;		/*!< Reserved - for future use */
} IFX_MAPI_WLAN_AP_WMM_Cfg;

/*!
    \brief Structure describing the inbound QoS in WLAN AP.
*/
typedef struct ifx_mapi_wlan_sta_wmm_cfg {
	IFX_ID iid;		/*!< IFX Identifier of WLAN ST WMM Config */
	IFX_MAPI_WLAN_WMM_AC ac;	/*!< WMM STA Access Category */
	uint32 AIFSN;		/*!< Arbitration Inter Frame Space Number */
	uint32 ECWmin;		/*!< Exponential Contention Window Minimum */
	uint32 ECWmax;		/*!< Exponential Contention Window Maximum */
	uint32 TXOP;		/*!< Transmit Opportunity Limit */
	bool ackPolicyEna;	/*!< Ack Policy - True: Ack, False: No Ack */
	void *reserved;		/*!< Reserved - for future use */
} IFX_MAPI_WLAN_STA_WMM_Cfg;

/*!
    \brief Structure describing the WLAN WPS Configuration.
*/
typedef struct ltq_mapi_wlan_wds {
	IFX_ID				iid;			/*!< IFX Identifier of WLAN WDS configuration */
	bool				enable;			/*!< Enable flag of WDS instance */
	LTQ_MAPI_WDS_SecCfg secMode;		/*!< security mode = Open/WEP */
	uint32				peerAPKeyIdx;	/*!< WEP key index used */
	uint32				nPeerAPs;		/*!< number of peer AP's */
} LTQ_MAPI_WLAN_WDS_Cfg;

/**

*/
/*!
    \brief Structure describing the aggregate of entire WLAN Config for an AP/VAP.
*/
typedef struct ifx_mapi_wlan_ap_cfg {
	IFX_ID iid;		/*!< WLAN-Main Identifier */
	IFX_MAPI_WLAN_PhyCfg phy;	/*!< WLAN Physical Object */
	IFX_MAPI_WLAN_MainCfg main;	/*!< WLAN Main Object */
	IFX_MAPI_WLAN_SecCfg sec;	/*!< WLAN Security Object */
	IFX_MAPI_WLAN_AP_WMM_Cfg apWmm[IFX_MAPI_WLAN_WMM_NUM_AC];	/*!< Outbound WMM Settings */
	IFX_MAPI_WLAN_STA_WMM_Cfg staWmm[IFX_MAPI_WLAN_WMM_NUM_AC];	/*!< Inbound WMM Settings */
	IFX_MAPI_WLAN_WPS_Cfg wps;	/*!< WPS Config */
	IFX_MAPI_WLAN_WPS_Regs_Cfg wpsRegs;	/* ! WPS Register */
	LTQ_MAPI_WLAN_WDS_Cfg wds;	/*!< WDS Config */
} IFX_MAPI_WLAN_AP_Cfg;

#if defined (CONFIG_FEATURE_LTQ_WIRELESS_VB) || defined (CONFIG_FEATURE_LTQ_WIRELESS_STA_SUPPORT)
/*!
    \brief Structure describing the global bridge device configuration.
*/
typedef struct ltq_mapi_wlan_vb_gen_bd_cfg {
	/*!< Bridge Device Name - user friendly device name */
	char8 name[IFX_MAPI_WLAN_AP_NAME];
	/*!< Operation mode in Video Bridge */
	LTQ_MAPI_WLAN_VB_mode mode;
	/*!< Operation mode in Video Bridge */
	LTQ_MAPI_WLAN_VB_mode	currentMode;
	/*!< IP Address of device used for management access */
	struct in_addr mgmtIP;
	/*!< Net Mask associated with device */
	struct in_addr mgmtNetMask;
	/*!< DHCP clien enable */
	bool dhcpClntEna;
	/*!< Allow webUI and telnet access via WLAN */
	bool wlanMgmt;
} LTQ_MAPI_WLAN_VB_GEN_BD_Cfg;

/*!
    \brief Structure describing configuration for the wired interface of bridge device
*/
typedef struct ltq_mapi_wlan_vb_lan_bd_cfg {
	/*!< Network mode for Video Bridge in AP mode */
	LTQ_MAPI_WLAN_VB_LAN_AP_mode masterNetMode;
	/*!< Network mode for Video Bridge in STA mode */
	LTQ_MAPI_WLAN_VB_LAN_STA_mode endPtNetMode;
	/*!< Loop Break Enable for Video Bridge in STA mode */
	bool endPtLbEna;
	/*!< Cloned MAC Address for Video Bridge in STA mode and network mode set
	   to cloning */
	char8 endPtClonedMacAddr[IFX_MAPI_MAC_ADDR_LEN];
} LTQ_MAPI_WLAN_VB_LAN_BD_Cfg;

/*!
    \brief Structure describing wlan configuration for the video bridge device
*/
typedef struct ltq_mapi_vb_wlan_cfg {
	/*!< WLAN function can be switch on/off through this. */
	bool radioEna;
	/*!< Standard to be used */
	IFX_MAPI_WLAN_Standard standard;
	/*!< two letter country code */
	char8 country[3];
	/*!< Frequency band to be used */
	IFX_MAPI_WLAN_FreqBand freqBand;
	/*!< CTS protections mode */
	LTQ_MAPI_VB_WLAN_CTS_ProtMode ctsProtctMode;
	/*!< RTS threshold */
	uint32 rts;
	/*!< Power Level */
	uint32 powerLvl;
	/*!< Static Transmit data rate */
	float txRate;
	/*!< Specify the channel bandwidth to be used */
	IFX_MAPI_WLAN_ChannelBW nChanWidth;
	/*!< Configure usage of short guard interval */
	IFX_MAPI_WLAN_GuardIntvl nGuardIntvl;
	/*!< Preamble Type */
	IFX_MAPI_WLAN_PreambleType preamble;
	/*!< nSTBCrx Type */
	uint32 nSTBCrx;
	/*!< Enable/Disable WPS */
	bool wpsEna;
	/*!< Enable/Disable WMM */
	bool wmmEna;
	/*!< Beamforming */
	LTQ_MAPI_WLAN_Beamform beamForm;
	/*!< Power Boost for acknowledgement */
	LTQ_MAPI_WLAN_AckBoost boostMode;
	/*!< LDPC */
	bool ldpcEna;
} LTQ_MAPI_VB_WLAN_Cfg;

/*!
    \brief Structure describing the WLAN scan results for video bridge.
*/
typedef struct ltq_mapi_vb_wlan_scan {
	/*!< SSID */
	char8 ssid[IFX_MAPI_WLAN_SSID_LEN];
	/*!< SSID wildcard */
	char8 ssid_wildcard[IFX_MAPI_WLAN_SSID_LEN];
	/*!< BSSID */
	char8 bssid[IFX_MAPI_WLAN_BSSID_LEN];
	/*!< WLAN Frequency Band */
	char8 freqBand[3];
	/*!< Specify the channel bandwidth to be used */
	IFX_MAPI_WLAN_ChannelBW chanBW;
	/*!< Standard to be used: HT or not-HT */
	char8 standard[10];
	/*!< Beacon type of AP */
	IFX_MAPI_WLAN_BeaconType beaconType;
	/*!< Authentication type of AP */
	IFX_MAPI_WLAN_AuthType authType;
	/*!< Encryption type of AP */
	IFX_MAPI_WLAN_EncrType encrType;
	/*!< Enable/Disable WPS */
	bool wpsEna;
	/*!< RSSI */
	char8 rssi[10];
} LTQ_MAPI_VB_WLAN_Scan;

/*!
    \brief Structure describing the WLAN scan results for video bridge.
*/
typedef struct ltq_mapi_vb_wlan_profile {
	/*!< AP Name - user friendly device name */
	char8 ssid[IFX_MAPI_WLAN_SSID_LEN];
	/*!< BBSID of AP/VAP */
	char8 bssid[IFX_MAPI_WLAN_BSSID_LEN];
	/*!< Beacon type of AP */
	IFX_MAPI_WLAN_BeaconType beaconType;
	/*!< Authentication type of AP */
	IFX_MAPI_WLAN_AuthType authType;
	/*!< Encryption type of AP */
	IFX_MAPI_WLAN_EncrType encrType;
	/*!< WEP Key Index */
	IFX_MAPI_WLAN_WEP_KeyIndex wepKeyIndex;
	/*!< WEP Key Type */
	IFX_MAPI_WLAN_KeyType wepKeyType;
	/*!< WEP Key Encryption Level */
	IFX_MAPI_WLAN_WEP_EncrLevel wepEncrLevel;
	/*!< Wep Key */
	char8 wepKey1[IFX_MAPI_WEP_KEY_MAX_LEN];
	/*!< Wep Key */
	char8 wepKey2[IFX_MAPI_WEP_KEY_MAX_LEN];
	/*!< Wep Key */
	char8 wepKey3[IFX_MAPI_WEP_KEY_MAX_LEN];
	/*!< Wep Key */
	char8 wepKey4[IFX_MAPI_WEP_KEY_MAX_LEN];
	/*!< Passphrase in case of WPA-PSK, WPS2-PSK, WPS/WPA2-PSK */
	char8 passPhrase[IFX_MAPI_PASSPHRASE_MAX_LEN];
	/*!< User name in case of enterprise security */
	char8 userName[IFX_MAPI_RADIUS_AUTH_USER];
	/*!< WLAN Frequency Band */
	IFX_MAPI_WLAN_FreqBand freqBand;
	/*!< Specify the channel bandwidth to be used */
	IFX_MAPI_WLAN_ChannelBW chanBW;
	/*!< Standard to be used: HT or not-HT */
	char8 standard[10];
} LTQ_MAPI_VB_WLAN_Profile;

/*!
    \brief Structure describing the WLAN link status for video bridge.
*/
typedef struct ltq_mapi_vb_wlan_link_status {
	/*!< Latest Transmit data rate in Mbit/s */
	float txRate;
	/*!< Signal strength in percentile */
	int32 signalStrength;
	/*!< Link quality */
	char8 quality[10];
	/*!< Connection Status */
	char8 status[14];
	/*!< channel number */
	uint8 channel;
	/*!< channel bandwidth used */
	IFX_MAPI_WLAN_ChannelBW chanBW;
	/*!< used WLAN Frequency Band (2.4/5) */
	IFX_MAPI_WLAN_FreqBand freqBand;
	/*!< country */
    char8 country[4];
} LTQ_MAPI_VB_WLAN_LinkStatus;

/*!
    \brief Structure describing the advanced ethernet phy configuration.
*/
typedef struct ltq_mapi_vb_eth_phy_cfg {
	/*!< IFX Identifier */
	IFX_ID iid;
	/*!< Enable/Disable PHY */
	bool ephyEna;
	/*!< Flow Control mode of ethernet PHY */
	bool ephyFlowControlEna;
	/*!< Duplex mode of ethernet PHY */
	LTQ_MAPI_VB_ETH_PHY_DUPLEX_MODE ephyDuplxMode;
	/*!< Maximum bit rate supported on ethernet PHY port */
	uint32 ephySpeed;
	/*!< Net Device Name */
	char8 ephyName[IFX_MAPI_WLAN_AP_NAME];
	/*!< Ethernet PHY port VLAN-ID */
	uint32 ephyVlanId;
	/*!< Switch Port Number */
	uint32 ephySwitchPort;
} LTQ_MAPI_VB_ETH_PHY_Cfg;
#endif				/* #ifdef CONFIG_FEATURE_LTQ_WIRELESS_VB */
#endif				/* #ifdef CONFIG_FEATURE_IFX_WIRELESS */
/* WLAN - end ] */

/*!
    \brief Structure describing the system constituent version information.
*/
struct ifx_version_info {
	char BOOTLoader[VALUE_MAX_LEN];	/*!< BootLoader Version */
	char CPU[VALUE_MAX_LEN];	/*!< CPU Name */
	char BSP[VALUE_MAX_LEN];	/*!< BSP Version */
	char Software[VALUE_MAX_LEN];	/*!< Software Version */
	char Tool_Chain[VALUE_MAX_LEN];	/*!< Toolchain Version */
	char Firmware[VALUE_MAX_LEN];	/*!< Firmware Version */
	char WAVE300_CV[VALUE_MAX_LEN];	/*!< WAVE300 Combined Version */
};

/*!
    \brief Structure describing the network interface.
*/
typedef struct netinterface {
	char ipaddr[20];	/*!< IP address */
	char netmask[20];	/*!< NetMask */
	char hwaddr[20];	/*!< Hardware Address */
	int admin;		/*!< Admin */
	int mtu;		/*!< MTU Size */
} NET_INTF_CFG;

/*IPQoS */
//#define IFX_MAPI_IF_NAME_LEN  MAX_IF_NAME
//#define IFX_MAPI_MAC_ADDR_LEN  MAX_MAC_ADDR_LEN

/*!
    \brief Structure describing the IP-QoS Capability.
*/
typedef struct ifx_mapi_qos_capability {
	IFX_ID iid;		/*!< Identifier of QoS Capability */
	IFX_MAPI_QoS_Sched schedAlgo[IFX_MAPI_QoS_MAX_ALGO];	/*!< Supported
								   Scheduling
								   Algorithm */
	uint32 schedAlgoCnt;	/*!< Scheduling Algorithms Count */
	IFX_MAPI_QoS_Drop dropAlgo[IFX_MAPI_QoS_MAX_ALGO];	/*!< Supported Drop
								   Algorithms */
	uint32 dropAlgoCnt;	/*!< Drop Algorithms Count */
	IFX_MAPI_QoS_Meter meterType[IFX_MAPI_QoS_MAX_ALGO];	/*!< Supported
								   Meter Type */
	uint32 meterTypeCnt;	/*!< Meter Type Count */
	uchar8 ingressShapingSupport;	/*!< Ingress Shaping Support */
	uint32 maxInputQs;	/*!< Maximum no. of supported Input Queues */
	uint32 maxOutputQs;	/*!< Maximum no. of supported Output Queues */
	uint32 maxClassifiers;	/*!< Maximum no. of supported Classifiers */
	uint32 maxApps;		/*!< Maximum no. of supported Applications */
	uint32 maxFlows;	/*!< Maximum no. of supported Flows */
	uint32 maxPolicers;	/*!< Maximum no. of supported policers */
	uint32 numID;		/*!< Number of Input Devices */
	uchar8 policerSupport;	/*!< Policer Support - Available or not */
} IFX_MAPI_QoS_Capability;

/*!
    \brief Structure describing the QoS Classifier.
*/
typedef struct ifx_mapi_qos_classifier {
	IFX_ID iid;		/*!< IFX Identifier of QoS Classifier */
	uchar8 enable;		/*!< Enable of QoS Classifier */
	char8 classifierName[MAX_NAME_LEN];	/*!< Classifier Name */
	uint32 status;		/*!< Status of Classifier instance */
	uint32 order;		/*!< Order of classifier instance */
	IFX_MAPI_QoS_Class_Type mfClass;	/*!< Is it Multi Field Classification?
						 */
	IFX_MAPI_QoS_Interface_Type classIf;	/*!< Classifier Interface for
						   classification */
	IFX_MAPI_QoS_Interface_Type IngIf;	/*!< Ingress Interface for
						   classification */
	char8 specIf[IFX_MAPI_IF_NAME_LEN];	/*!< Specific Interface for Input */
	uint32 fwPolicy;	/*!< Forwarding Policy - currenlty unused */
	int32 trafficClassId;	/*!< Traffic Class Identifier - currently
				   unused */
	int32 qId;		/*!< Queue Identifier */
	int32 policerId;	/*!< Policer Identifier */
#if 0
	IP_MASK dstIP;		/*!< TODO */
#else
	IP_MASK_DOTTED dstIP;	/*!< Destination IP address in dotted string
				   form */
#endif
	uchar8 dstIPExcl;	/*!< Destination IP Exclude Flag */
#if 0
	IP_MASK srcIP;		/*!< TODO */
#else
	IP_MASK_DOTTED srcIP;	/*!< Source IP address in dotted string form */
#endif
	uchar8 srcIPExcl;	/*!< Source IP Exclude Flag */
	int32 protoNum;		/*!< L4 Protocol Number */
	uchar8 protoExcl;	/*!< Exlcude L4 Protocol Flag */
	int32 L3protoNum;	/*!< L3 Protocol Number */
	uchar8 L3protoExcl;	/*!< Exlcude L3 Protocol Flag */
	PORT_RANGE srcPortRange;	/*!< Source Port Number Range */
	uchar8 srcPortExcl;	/*!< Source Port Exclude */
	PORT_RANGE dstPortRange;	/*!< Destination Port Number Range */
	uchar8 dstPortExcl;	/*!< Destination Port Exclude */
	char8 srcMac[IFX_MAPI_MAC_ADDR_LEN];	/*!< Source MAC Address */
	char8 srcMacMask[IFX_MAPI_MAC_ADDR_LEN];	/*!< Source MAC address Mask */
	uchar8 srcMacExcl;	/*!< Source MAC Address Exclude Flag */
	char8 dstMac[IFX_MAPI_MAC_ADDR_LEN];	/*!< Destination MAC Address */
	char8 dstMacMask[IFX_MAPI_MAC_ADDR_LEN];	/*!< Destination MAC address
							   Mask */
	uchar8 dstMacExcl;	/*!< Destination MAC address Exclude Flag */
	int32 dscpCheck;	/*!< Incoming DSCP Value for flow
				   identification */
	uchar8 dscpExcl;	/*!< Exclude of dscpCheck parameter */
	int32 pBitsCheck;	/*!< Incoming 802.1P bits for flow
				   identification */
	uchar8 pBitsExcl;	/*!< Exclude of pBitsCheck */
	int32 vlanCheck;	/*!< Incoming VLAN Id for flow identification */
	uchar8 vlanExcl;	/*!< Exclude of vlanCheck */
	int32 dscpMark;		/*!< Outgoing DSCP Marking */
	int32 pBitsMark;	/*!< Outgoing pBits-Marking */
	uchar8 rateCtrlEnbl;	/*!< Rate Control Enable */
	int32 rateLmt;		/*!< Rate limit for policing */
	uchar8 disableAccel;	/*!< Enable/ disable PPE acceleration for classified traffic */
} IFX_MAPI_QoS_Classifier;

/*!
    \brief Structure describing the Queue Management - singleton object of QoS.
*/
typedef struct ifx_mapi_qos_qm {
	IFX_ID iid;		/*!< Singleton Id of Queue Management object */
	uchar8 enable;		/*!< Enable or Disable of QoS */
	uchar8 USenable;	/*!< Enable or Disable of Upstream QoS */
	uchar8 DSenable;	/*!< Enable or Disable of Downstream QoS */
	uchar8 P8021enable;	/*!< Enable or Disable of Global 8021P Remarking */
	uchar8 portMappingQoSEnable;	/*!< PortMapping Qos Enable */
	uchar8 appQoSEnable;	/*!< Application based QoS Enable */
	uint32 status;		/*!< Status of QoS */
	uint32 defaultFwPolicy;	/*!< Default Forwarding Policy - currnetly
				   unused */
	int32 USdefaultQ;	/*!< CPE-Id of default Q instance for US */
	int32 DSdefaultQ;	/*!< CPE-Id of default Q instance for DS */
	int32 defaultQ;		/*!< CPE-Id of default Q instance */
	int32 defaultPolicer;	/*!< CPE-Id of default Policer instance */
	int32 USdefaultDSCP;	/*!< Default DSCP of non-classified QoS flows */
	int32 DSdefaultDSCP;	/*!< Default DSCP of non-classified QoS flows */
	int32 USdefaultPbits;	/*!< Default 802.1P bits of non-classified QoS
				   flows */
	int32 DSdefaultPbits;	/*!< Default 802.1P bits of non-classified QoS
				   flows */
	int32 defaultDSCP;	/*!< Default DSCP of non-classified QoS flows */
	int32 defaultPbits;	/*!< Default 802.1P bits of non-classified QoS
				   flows */

	int32 defaultTC;	/*!< Default Traffic Class of non-classified
				   QoS flows */
	char8 availableAppList[IFX_MAX_IPQOS_APP_LIST_LEN];	/*!< Available Apps
								   List */
	char8 qIf[IFX_MAPI_IF_NAME_LEN];	// TO BE REMOVED. CURRENTLY ONLY FOR
	// COMPILATION
	IFX_MAPI_QoS_ATM_Queue_Mode atmQMode;	/*!< PVC or Port Based in ATM
						   Mode */
	uchar8 portRateLimitEnable;	/*!< Enabled/Disabled for Wan Port Rate Limit */
	uchar8 DSportRateLimitEnable;	/*!< Enabled/Disabled for Lan Port Rate Limit */
	uint32 upstreamPortRateLimit;	/*!< Limit upstream wan port rate to
					   specified value (kbps) */
	uint32 downstreamPortRateLimit;	/*!< Limit downstream Lan port rate to
					   specified value (kbps) */
	uchar8 tcpackprio;	/*!< Enable/Disable bit for TCP Ack
				   Prioritization */
	uint32 queueStatsNumberOfEntries; /*!<number of stats entries for
					     queues */
	 uchar8 class_accel_mngr;        /*!< Enable/Disable bit for classifier
					    to  be added or removed from PPA Accelreation */

} IFX_MAPI_QoS_QM;

/*!
    \brief Structure describing the Policer object for QoS.
*/
typedef struct ifx_mapi_qos_policer {
	IFX_ID iid;		/*!< Identifier of Policer object */
	uchar8 enable;		/*!< Enable Flag */
	char8 pName[MAX_NAME_LEN];	/*!< Policer Name */
	uint32 status;		/*!< Status */
	uint32 cr;		/*!< Commited Rate */
	uint32 cbs;		/*!< Committed Burst Size */
	uint32 ebs;		/*!< Excess Burst Size */
	uint32 pr;		/*!< Peak Rate */
	uint32 pbs;		/*!< Peak Burst Size */
	IFX_MAPI_QoS_Meter mtrType;	/*!< Meter Type */
	IFX_MAPI_QoS_Policer_Action cfmAction;	/*!< Conforming Action */
	uint32 cfmDscpMark;	/*!< Conforming DSCP Marking */
	uint32 cfmPbitsMark;	/*!< Conforming P-bits Marking */
	IFX_MAPI_QoS_Policer_Action partCfmAction;	/*!< Partial-conforming Action
							 */
	uint32 partCfmDscpMark;	/*!< Partial-Conforming DSCP Marking */
	uint32 partCfmPbitsMark;	/*!< Partial-Conforming P-bits Marking */
	IFX_MAPI_QoS_Policer_Action nonCfmAction;	/*!< Non-conforming Action */
	uint32 nonCfmDscpMark;	/*!< Non-Conforming DSCP Marking */
	uint32 nonCfmPbitsMark;	/*!< Non-Conforming P-bits Marking */
} IFX_MAPI_QoS_Policer;

/*!
    \brief Structure describing the Queue object for QoS.
*/
typedef struct ifx_mapi_qos_queue {
	IFX_ID iid;		/*!< Identifier of Queue object */
	uchar8 enable;		/*!< Enable Flag */
	char8 qName[MAX_NAME_LEN];	/*!< Queue Object Name */
	uint32 status;		/*!< Status */
	char8 trafficClass[IFX_MAPI_TRAFFIC_CLASS_LEN];	/*!< Traffic Class */
	IFX_MAPI_QoS_Interface_Type qIfType;	/*!< Quueue Interface Type */
	char8 qIf[IFX_MAPI_IF_NAME_LEN];	/*!< Outgoing Interface of Queue */
	uint32 qLen;		/*!< Queue Length */
	uint32 qWt;		/*!< Queue Weight */
	uint32 qPrio;		/*!< Queue Priority */
	uint32 redTh;		/*!< RED Threshold */
	uint32 redPct;		/*!< RED Percentage */
	IFX_MAPI_QoS_Drop dropType;	/*!< Drop Algorithm Type */
	IFX_MAPI_QoS_Sched schedType;	/*!< Shceduling Algorithm Type */
	uchar8 weightEnable;	/*!< enable weight based */
	uchar8 shaperEnable;	/*!< enable rateshaping */
	uint32 peakRate;	/*!< Peak Shaping Rate */
	uint32 commitRate;	/*!< Committed shaping rate */
	int32 shapeRate;	/*!< Shaping Rate */
	uint32 sbs;		/*!< Shaping Burst Size */
	char8 egressPVC[IFX_MAPI_IF_NAME_LEN];	/*!< PVC on which Queue is
						   attached */
	uint32 uiRedTh;		/*!< minimum thresold in byte */
	float flRedProb;	/*!< Dropping Probability in range of 0-1 */
} IFX_MAPI_QoS_Queue;

/*!
    \brief Structure describing the Queue Stats object for QoS.
*/
typedef struct ifx_mapi_qos_queue_stats {
	IFX_ID iid;		/*!< Identifier of Queue Statistics object */
	uchar8 Enable;		/*!< Enable/Disable flag for Queue Statistics object */
	uchar8 Status;		/*!< Enable/Disable status */
	uint32 QueueInst;	/*!< Instance number of Queue table Entry */
	uint32 Interface;	/*!< Egress Interface for which Object contains statistics */
	uint32 OutPacks;	/*!< Number of packets output through the Queue */
	uint32 OutBytes;	/*!< Number of bytes output through the Queue */
	uint32 DropPacks;	/*!< Number of packets dropped by the Queue */
	uint32 DropBytes;	/*!< Number of bytes dropped by the Queue */
	uint32 QOccPacks;	/*!< Queue Occupancy by the packets */
	uint32 QOccPercent;	/*!< Queue Occupancy in bytes/Queue size in bytes */

} IFX_MAPI_QoS_QueueStats;
/*IPQoS */

/* 509202:linmars start */

/*!
    \brief Structure describing physical port information.
*/
struct ifx_phyport_info {
	int link;		/*!< link */
	int speed;		/*!< link speed */
	int duplex;		/*!< duplex transmission */
	int enable;		/*!< enable flag */
};

/*!
    \brief Structure describing arp scan information.
*/
typedef struct ltq_mapi_lan_ip_host {
	IFX_ID iid;
	char macAddr[MAX_MAC_ADDR_LEN]; /*!< Singleton ID*/
//char ip6Addr[MAX_IPV6_LEN];     /*!< ipv6 address*/
	char ip4Addr[MAX_IP_ADDR_LEN];  /*!< ipv4 address*/
	bool inactive;                  /*!< inactine mode*/
	bool webSrvr;		                /*!< Web Server hosted in End Device */
} LTQ_MAPI_LAN_IP_Host;

/*!
    \brief Structure describing physical port statistics information.
*/
struct ifx_phyportstats_info {
	uint32 rxPktCnt;	/*!< receive packet count */
	uint32 txPktCnt;	/*!< transmit packet count */
	uint32 rxByteCnt;	/*!< receive byte count */
	uint32 txByteCnt;	/*!< transmit byte count */
        uint32 txErrors;        /*!< outbound error packet count */
        uint32 rxErrors;        /*!< inbound error packet count */
        uint32 txDscrdPktCnt;   /*!< outbound discard packet count */
        uint32 rxDscrdPktCnt;   /*!< inbound discard packet count */
        uint32 txUnicastPktCnt;   /*!< outbound unicast packet count */
        uint32 rxUnicastPktCnt;   /*!< inbound unicast packet count */
        uint32 txMulticastPktCnt;  /*!< outbound multicast packet count */
        uint32 rxMulticastPktCnt;  /*!< inbound multicast packet count */
        uint32 txBroadcastPktCnt;  /*!< outbound broadcast packet count */
        uint32 rxBroadcastPktCnt;  /*!< inbound broadcast packet count */
        uint32 rxUnknownProtoPktCnt;  /*!< received packets with unknown protocol count */
};

#ifdef CONFIG_FEATURE_SAMBA	/* CONFIG_FEATURE_SAMBA_SERVER */
/*!
    \brief This is the data structure for the SAMBA server configuration information.
*/
typedef struct _samba_server_settings {
	IFX_ID iid;		/*!< Singleton ID for SAMBA Server. */
	char8 smbServerName[MAX_NAME_LEN];	/*!< e.g. LTQ SMB Server. */
	bool smbEna;		/*!< SAMBA Server Enable. */
	char8 smbName[MAX_NAME_LEN];	/*!< SAMBA Server Name. */
	char8 smbDescr[MAX_NAME_LEN];	/*!< SAMBA Server Description. */
	char8 wrkgrpName[MAX_NAME_LEN];	/*!< Workgroup Name. */
} LTQ_MAPI_SAMBA_Server;
/*!
    \brief This is the data structure for the File share configuration information.
*/
typedef struct _file_share {
	IFX_ID iid;		/*!< Singleton ID for File Share. */
	char8 shareName[MAX_NAME_LEN];	/*!< Share Name. */
	bool rwAccess;		/*!< R-W or R-O access. */
	char8 folderPath[MAX_NAME_LEN];	/*!< Absolute Path. */
	bool allUsers;
	char8 users[MAX_USERS][MAX_NAME_LEN];	/*!< User Name. */
} LTQ_MAPI_File_Share;
/*!
    \brief This is the data structure for the File user configuration information.
*/
typedef struct _file_user {
	IFX_ID iid;		/*!< Singleton ID for File Share. */
	char8 userName[MAX_NAME_LEN];	/*!< User Name. */
	char8 pwd[MAX_NAME_LEN];	/*!< Cryptic Passwd. */
	bool rwAccess;		/*!< R-W or R-O access. */
	char8 shares[MAX_SHARES][MAX_NAME_LEN];	/*!< Share Name, currently
						   unused. */
	bool userEna;		/*!< User Enable. */
} LTQ_MAPI_File_User;
#endif				/* CONFIG_FEATURE_SAMBA_SERVER */

#ifdef CONFIG_FEATURE_MEDIA_SERVER	/* CONFIG_FEATURE_MEDIA_SERVER */
/*!
    \brief This is the enumeration for media types such as ALL media, Image, Audio and Video.
*/
typedef enum _media_type {
	LTQ_MEDIA_ALL = 0,
	LTQ_MEDIA_IMAGE = 1,
	LTQ_MEDIA_AUDIO = 2,
	LTQ_MEDIA_VIDEO = 3
} LTQ_MAPI_Media_Type;

/*!
    \brief This is the data structure for the media server settings.
*/
typedef struct _mediaserver_settings {
	IFX_ID iid;		/*!< Singleton id for DLNA Server */
	char mediaServerName[MAX_NAME_LEN];	/*!< Media server name. eg. LTQ DLNA
						   Server */
	bool msEna;		/*!< Media Server Enable or Disable option */
	bool extDBloc;		/*!< External Database Storage Enable or
				   Disable */
	char extDBpath[MAX_FILE_NAME_LEN];	/*!< External Database Storage Path */
	bool scanAtStart;	/*!< Scan Media drives at start of DLNA Server
				 */
} LTQ_MAPI_MediaServer;
#define LTQ_MEDIASERVER_PARAM_COUNT	7

/*!
    \brief This is the data structure for the media location entries.
*/
typedef struct _media_location {
	IFX_ID iid;		/*!< Media Location Object Id */
	LTQ_MAPI_Media_Type mediaType;	/*!< Enum. All, Images, Audio, Video */
	char mediaPath[MAX_FILE_NAME_LEN];	/*!< Absolute Media Path */
} LTQ_MAPI_Media_Location;
#endif				/* CONFIG_FEATURE_MEDIA_SERVER */

typedef struct def_wan_cfg {
	IFX_ID iid;
	char8 conn_name[MAX_CONN_NAME_LEN];	/*!< WAN connection name. */
	char8 conf_conn_name[MAX_CONN_NAME_LEN];	/*!< Configured Connection Name */
	char8 iface[IFNAMSIZE];	/*!< Interface */
} def_wan_cfg_t;

/*!
    \brief This is the data structure for VLan configuration .
*/
typedef struct vlan_ch_cfg {
	IFX_ID iid;		/*!< Holds Id details (cpeId, pcpeId) of this instance. */
	int32 fEnable;		/*!< Enable status. */
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
	int32 autodetect;	/*!< flag which indicates that this vlan configured through autodetect */
	int32 defaultentry;	/*!< defaultentry */
#endif
	char8 chName[MAX_NAME_LEN];	/*!< Name of the channel. */
	int32 vlanId;		/*!< Vlan ID of the channel (can be 0-255). */
	int8 macAddrOvrd;	/*!< Flag to indicate if MAC address override is chosen or not. */
	char8 macAddr[MAX_MAC_ADDR_LEN];	/*!< MAC address of the channel if above parameter is chosen. */
	char8 baseIf[MAX_IF_NAME_LEN];	/*!< Layer-2 interface name mapped to this channel. */
	char8 l2ifName[MAX_IF_NAME_LEN];	/*!< Interface name for this channel (same as above parameter'iface' when 'vlanId' is '0'. */
} vlan_ch_cfg_t;

#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
/*!
    \brief This is the data structure for the Port Wan Binding WAN details.
*/ 
typedef struct pwb_wan_if {
      char8     conName[MAX_CONN_NAME_LEN]; /*! WAN connection name*/
      WAN_MODE  mode; /*! Physical WAN mode */
} pwb_wanif_t;

/*!
    \brief This is the data structure for the Port Wan Binding details.
*/ 
typedef struct port_to_wan_bind {
      IFX_ID  	iid; /*!< Holds Id details (cpeId, pcpeId) of this instance. */
      char8    	pwbName[MAX_NAME_LEN]; /*! Name of the rule for user */
      char8	pwbEnable;  /*! The entry is enabled or not. */
      uint32	bitMask; /*! Bit mask to be used in nfmark.*/
      uint32   	numLANIfs; /*! Total bound LAN Interfaces.*/
      char8    	lanifNames[MAX_LAN_IF][MAX_IF_NAME]; /*! LAN interface names. */
      pwb_wanif_t wanIf; /*! WAN interface details */
} pwb_cfg_t;

/*!
    \brief This is the data structure for the Port Wan Binding status in the system.
*/

typedef struct ltq_mapi_pwb_status {
        IFX_ID 		iid; /*!< Holds Id details (cpeId, pcpeId) of this instance. */	
	char8	 	enable;        /*!< Enable flag of object */
} pwb_status_t;

#endif

#if defined(CONFIG_FEATURE_LTQ_VLAN_SWITCH_PORT_ISOLATION) ||  defined(CONFIG_FEATURE_LTQ_SWITCH_PORT_ISOLATION) 
/*!
    \brief Structure describing the lan port separation.
*/

typedef struct ltq_mapi_lan_port_sep {
        IFX_ID iid;             /*!< Identifier of firewall object */
	char8 bridge[8];	/*!< Bridge name for Future */
	char8 interface[MAX_IF_NAME]; /*!< Physical interface name */
	char8 conName[MAX_NAME_SIZE]; /*!< LAN connection name */
} lan_port_sep_cfg_t;

typedef struct ltq_mapi_lan_port_sep_status {
	char8 enable;           /*!< Enable flag of Firewall Object */
        char8 drvEnable;        /*!< Driver based port separation*/
} lan_port_sep_status_t;

#endif // CONFIG_FEATURE_LTQ_VLAN_SWITCH_PORT_ISOLATION
 
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT

/*!
    \brief This is the data structure for the auto detect fetaure.
*/

typedef struct auto_detect_cfg {
	int32   auto_detect;	/*!< Flag to enable and disable auto detect */ 
	int32   auto_detect_L3; /*!< Flag to enable/disable L3 auto detect for adsl atm mode */
	int32   auto_detect_vdsl_atm_L3; /*!< Flag to enable/disable L3 auto detect for vdsl atm mode */
	int32   auto_detect_adsl_ptm_L3; /*!< Flag to enable/disable L3 auto detect for adsl ptm mode */
	int32   auto_detect_vdsl_ptm_L3; /*!< Flag to enable/disable L3 auto detect for vdsl ptm mode */
	int32   auto_detect_mii1_L3;	/*!< Flag to enable/disable L3 auto detect for MII-1 mode */
	int32   auto_detect_mii0_L3;	/*!< Flag to enable/disable L3 auto detect for MII-0 mode */
	int32   auto_detect_L2;	/*!< Flag to enable/disable L2 auto detect for adsl atm mode */
	int32   auto_detect_vdsl_atm_L2;	/*!< Flag to enable/disable L2 auto detect for vdsl atm mode */
	int32   auto_detect_Vlan_ATM;	/*!< Flag to enable/disable L2 vlan for adsl atm mode */
	int32   auto_detect_Vlan_ADSL_PTM;	/*!< Flag to enable/disable L2 for adsl ptm mode */
	int32	auto_detect_Vlan_VDSL_PTM;	/* !> Flag to enable/disable L2 for vdsl ptm mode */
	int32	auto_detect_Vlan_ETH1;	/*!< Flag to enable/disable L2 for MII-1 mode */
	int32	auto_detect_Vlan_ETH0;	/*!< Flag to enable/disable L2 for MII-0 mode */
	char8   auto_detect_Vcc[MAX_POOL_LIMIT];	/*!< Store vpi/vci pool for adsl atm mode */
	char8   auto_detect_ATM_VlanId[MAX_POOL_LIMIT];	/*!< Store vlan pool for adsl atm mode */
	char8   auto_detect_ADSL_PTM_VlanId[MAX_POOL_LIMIT];	/*!< Store vlan pool for adsl ptm mode */
	char8   auto_detect_VDSL_PTM_VlanId[MAX_POOL_LIMIT];	/*!< Store vlan pool for vdsl ptm mode */ 
	char8   auto_detect_ETH1_VlanId[MAX_POOL_LIMIT];	/*!< Store vlan pool for MII-1 mode */
	char8   auto_detect_ETH0_VlanId[MAX_POOL_LIMIT];	/*!< Store vlan pool for MII-0 mode */
	char8  	auto_detect_atm_wan_pool[MAX_POOL_LIMIT];	/*!< Store wan pool for adsl atm mode */
	char8  	auto_detect_ptm_wan_pool[MAX_POOL_LIMIT];	/*!< Store wan pool for adsl ptm mode */
	char8  	auto_detect_prev_val[MAX_POOL_LIMIT];	/*!< Store value detected in previous auto detect run */
	char8   auto_detect_ppp_user[MAX_PPP_USER_NAME_PASSWD_LEN];	/*!< Store username for the pppoe probing */
	char8  	auto_detect_ppp_pass[MAX_PPP_USER_NAME_PASSWD_LEN];	/*!< Store passwd used for the pppoe probing */
} auto_detect_cfg_t;

/*!
    \brief This is the data structure for the l2 and l3 auto detect pool.
*/

typedef struct l2l3_ad_pool {
	char8		l2_attr[15];	/*!< Store L2 parameter detected */
	char8		wan_type[15];	/*!< Store wan type or L3 parameter detected */
} l2l3_ad_pool_t;
#endif

/*!
    \brief Data structure for user object.
*/
typedef struct user_obj {
	IFX_ID	iid;										/*!< Instance ID of user object. */
	int8	f_enable;									/*!< Enable flag. */
	char8	username[MAX_NAME_SIZE];	/*!< Username for this instance. */
	char8	password[MAX_NAME_SIZE];	/*!< Password for this instance. */
	int8	webAccess;			/*!< Flag to indicate Web access to Local/Remote/Both access state. */
	int8	fileShareAccess;		/*!< Flag to indicate File Share access to FTP/SAMBA/Both access state. */
	int8	telnetAccess;			/*!< Bit Flag to indicate telnet access state. */
} user_obj_t;

/*!
    \brief Data structure for remote access configuration.
*/
typedef struct remote_access {
	IFX_ID	iid;														/*!< Instance ID of remote access object. */
	int8	f_enable;													/*!< Enable flag. */
	int32	port;															/*!< Port number for service defined by protocol. */
	char8	supportedProto[4][MAX_NAME_SIZE];	/*!< List of supported protocols */
	char8	proto[MAX_NAME_SIZE];							/*!< Protocol for this remote access instance - for now supported as HTTP/HTTPs only. */
} remote_access_t;

#endif				// _IFX_API_STRUCTS_H
