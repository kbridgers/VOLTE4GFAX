
/* ============================================================================
 * Copyright (C) 2004 - Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 * ============================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ============================================================================
 */

/* ===========================================================================
 *
 * File Name    : ifx_snmp_api.h
 * Author       : Subramani
 * Date         : 17-Jun-2004
 *
 * ===========================================================================
 *
 * Project      : Amazon
 * Block        : ADSL-MIBs
 *
 * ===========================================================================
 * Contents: This file contains function prototypes for:
 *                 1) Reading and writing data to the snmpd.conf file
 *
 *
 * ===========================================================================
 * References: RFC 2662
 *
 */
/*
 * ===========================================================================
 *                           INCLUDE FILES
 * ===========================================================================
 */

/*! \file ifx_snmp_api.h
    \brief This file contains functions prototypes for Reading and writing data to the snmpd.conf file
*/

#ifndef _SNMP_API_H
#define _SNMP_API_H

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <signal.h>
#include "ifx_common.h"
#include "ifx_snmp_api.h"
#include "ifx_snmpdefs.h"

/*
 * ===========================================================================
 *                           GLOBAL DEFINITIONS
 * ===========================================================================
 */
/*! \def TMP_CONF_FILE 
    \brief TMP config file location 
 */
#define TMP_CONF_FILE "/etc/snmp/tmpsnmpd.conf"

/*! \def SNMPD_PID_FILE_PATH 
    \brief SNMPD PID file path 
 */
#define SNMPD_PID_FILE_PATH "snmpd"
#if defined(CONFIG_FEATURE_SNMPV1) || defined(CONFIG_FEATURE_SNMPV3)
/*! \def SNMPD_CONF_FILE 
    \brief SNMPD config file location
 */
#define SNMPD_CONF_FILE "/etc/snmp/snmpd.conf"
#endif
#ifdef CONFIG_FEATURE_SMASH_SNMP
/*! \def SNMPD_CONF_FILE 
    \brief SNMPD config file location
 */
#define SNMPD_CONF_FILE "/usr/sbin/snmpd.conf"
#endif

/*! \def TRUE
    \brief True
 */
#define TRUE		1

/*! \def FALSE		
    \brief False
 */
#define FALSE		0

/*! \def SUCCESS
    \brief Success
 */
#define SUCCESS		TRUE

/*! \def FAIL
    \brief Fail
 */
#define FAIL		FALSE

/*! \def MAX_LINE_LEN
    \brief Max Line Length
 */
#define MAX_LINE_LEN	256

/*! \def MAX_TOK_SIZE
    \brief Maximum tokan size
 */
#define MAX_TOK_SIZE	64

/*! \def MAX_TOKVAL_SIZE 
    \brief Maximum Token value size
 */
#define MAX_TOKVAL_SIZE 128

/*! \def TOK_ROCOMMUNITY
    \brief Token Read Only community
*/
#define TOK_ROCOMMUNITY	0

/*! \def TOK_RWCOMMUNITY
    \brief Token Read Write community
 */
#define TOK_RWCOMMUNITY	1

/*! \def TOK_TRAPSINK
    \brief Token TRAP SINK
 */
#define TOK_TRAPSINK	2

/*! \def TOK_TRAPSINK2
    \brief Token TRAP SINK 2
 */
#define TOK_TRAPSINK2	3

/*! \def TOK_ROUSER
    \brief Token Read Only User
 */
#define TOK_ROUSER		4

/*! \def TOK_RWUSER
    \brief Token Read Write User
 */
#define TOK_RWUSER		5

/*! \def TOK_AUTHTRAPENABLE
    \brief Token Authentication Trap Enable
 */
#define TOK_AUTHTRAPENABLE	6

/*! \def TOK_AGENTADDRESS
    \brief Token Agent Address
 */
#define TOK_AGENTADDRESS	7

/*! \def TOK_SYSNAME		
    \brief Token System Name
 */
#define TOK_SYSNAME		8

/*! \def TOK_SYSLOCATION
    \brief Token System Location
 */
#define TOK_SYSLOCATION	9

/*! \def TOK_SYSCONTACT
    \brief Token system Contact
 */
#define TOK_SYSCONTACT	10

/*! \def TOK_DEFTOK
    \brief Token Define 
 */
#define TOK_DEFTOK		100

/*! \def RDONLY
    \brief Read Only
 */
#define RDONLY		0

/*! \def RWRITE
    \brief Read and Write
 */
#define RWRITE		1

//typedef  int bool;

/*! \brief This structure contains attributes of SNMP v3 user
 */
struct v3user {
	char username[MAX_TOKVAL_SIZE];	/*!< CHARACTER */
	int access;		/*!<INTEGER */
};

/*!  \brief This structure contains SNMP configuration data
 */
typedef struct {
	bool bSNMPEnable;	/*!< BOOLEAN */
	char sSysName[MAX_FILELINE_LEN];	/*!< CHARACTER */
	char sSysLocation[MAX_FILELINE_LEN];	/*!<  CHARACTER */
	char sSysContact[MAX_FILELINE_LEN];	/*!<  CHARACTER */
	char sSNMProcommunity[MAX_FILELINE_LEN];	/*!<  CHARACTER */
	char sSNMPrwcommunity[MAX_FILELINE_LEN];	/*!<  CHARACTER */
	bool bTrapEnable;	/*!<  BOOLEAN */
	char sSNMPTrapIP[MAX_FILELINE_LEN];	/*!< CHARACTER */
	unsigned long TrapPort;	/*!< UNSIGNED */
	char sSNMPTrapCommunity[MAX_FILELINE_LEN];	/*!<  CHARACTER */
	bool bUDPEnable;	/*!<  BOOLEAN */
	unsigned long UDPPort;	/*!< UNSIGNED */
	bool bPVCEnable;	/*!<  BOOLEAN */
	unsigned long PVCVpi;	/*!<   UNSIGNED */
	unsigned long PVCVci;	/*!<  UNSIGNED */
	bool bEOCEnable;	/*!< BOOLEAN */
	unsigned long EOCVpi;	/*!<  UNSIGNED */
	unsigned long EOCVci;	/*!<  UNSIGNED */
} snmp_config_data;

//int snmpPID;

/*! \brief EXTERN CHARACTER VARIABLE
 */
extern char v1_marker[];

/*! \brief EXTERN CHARACTER VARIABLE
 */
extern char v3_marker[];

/*!    \brief EXTERN CHARACTER VARIABLE
 */
extern char *token_arr[];

/*
 * ===========================================================================
 *                           EXPORTED FUNCTIONS
 * ===========================================================================
 */
/*! \fn bool IFX_SNMPd_Get_Conf(char * ro_community, char * rw_community, bool *trap_enable,
       	char * trap_host_ip, unsigned long *trap_port, char *trap_community);
    \brief function is an exported API function which gets the basic configuration.
     The Caller of this API function provides the necessary buffer place-holders
      to return the configuration values from the Configuration file 
    \param[in] *ro_community
    \param[in] *rw_community
    \param[in] *trap_enable
    \param[in] *trap_host_ip
    \param[in] *trap_port
    \param[in] *trap_community
    \return True/False
 */
bool IFX_SNMPd_Get_Conf(char *ro_community, char *rw_community,
			bool * trap_enable, char *trap_host_ip,
			unsigned long *trap_port, char *trap_community);

#if 0

/*! \fn bool IFX_SNMPd_Set_Conf(char * ro_community, char * rw_community, bool *trap_enable,
       	char * trap_host_ip, unsigned long *trap_port, char *trap_community)
    \brief TODO
    \param[in] *ro_community
    \param[in] * rw_community
    \param[in] *trap_enable
    \param[in] *trap_host_ip
    \param[in] *trap_port
    \param[in] *trap_community
    \return TRUE/FALSE
	
 */
bool IFX_SNMPd_Set_Conf(char *ro_community, char *rw_community,
			bool * trap_enable, char *trap_host_ip,
			unsigned long *trap_port, char *trap_community);
#else

/*! \fn bool IFX_SNMPd_Set_Conf(snmp_config_data *snmpdata)
    \brief function is an exported API function which sets the basic configuration.
    The Caller of this API function provides the necessary data to be set in buffers.
    For those variables for which no value needs to be Set are passed with NULL. This
    information is translated by this API and written to the Configuration file.    
    \param[in] *snmpdata
     \return TRUE/FALSE
 */
bool IFX_SNMPd_Set_Conf(snmp_config_data * snmpdata);
#endif

/*! \fn bool IFX_Set_MIB2_System_Conf(char *sysName, char *sysContact, char *sysLocation)
    \brief function would be required to modify the MIB2 system data in the
  snmpd.conf file whenever the MIB2 System data is modified thru' SNMP
  Agent via snmpset command.
    \param[in] *sysName
    \param[in] *sysContact
    \param[in] *sysLocation
     \return TRUE/FALSE
 */

bool IFX_Set_MIB2_System_Conf(char *sysName, char *sysContact,
			      char *sysLocation);

/*! \fn bool IFX_create_usm_cmd_file_on_startup()
    \brief function reads the SNMPv3 users from persistent store 
    and creates the SNMPV3_USM_CMD_FILE which contains the list 
    of SNMPv3 users configured on the device.
    It also flushes all the SNMPv3 users in snmpd.conf file and creates them a fresh!!
    \return TRUE/FALSE
 */

bool IFX_create_usm_cmd_file_on_startup();

/*! \fn bool IFX_add_snmpv3_user(char *user, char *user_access, char *authProto, char *authPassPhrase,char *encrProto, char *encrPassPhrase)
    \brief function is an exported API function which adds
  an SNMPv3 user to the configuration file and also to
  the UserList in snmpd. Since the communication is between
  two processes, we cannot directly inform the snmp daemon to
  add the user. For this we write the required information into
  a specifc file and send a HUP signal to snmpd to re-read the
  configuration file. While reading the configuration file we
  also read this data file and the user is addedd to the
  usmUserList in snmpd and persistence store updated.
    \param[in] *user
    \param[in] *user_access
    \param[in] *authProto
    \param[in] *authPassPhrase
    \param[in] *encrProto
    \param[in] *encrPassPhrase
     \return TRUE/FALSE
 */
bool IFX_add_snmpv3_user(char *user, char *user_access, char *authProto,
			 char *authPassPhrase, char *encrProto,
			 char *encrPassPhrase);

/*! \fn bool IFX_delete_snmpv3_user(char *user)
    \brief function is an exported API function which deletes
  an SNMPv3 user from the configuration file and also from
  the UserList in snmpd. Since the communication is between
  two processes, we cannot directly inform the snmp daemon to
  delete the user. For this we write the required information into
  a specifc file and send a HUP signal to snmpd to re-read the
  configuration file. While reading the configuration file we
  also read this data file and the user is delted from the
  usmUserList in snmpd and persistence store updated.
    \param[in] *user
    \return True/False
 */
bool IFX_delete_snmpv3_user(char *user);

/*! \fn int IFX_get_all_snmpv3_users (struct v3user **pv3user, int *num_users);
    \brief function is an exported API function which displays
  all SNMPv3 users in the configuration file and in the UserList 
    \param[in] **pv3user
    \param[in] *num_users
    \return SUCCESS/FAILURE
 */
int IFX_get_all_snmpv3_users(struct v3user **pv3user, int *num_users);

/*! \fn int IFX_adsl_ioctl(int fd, int cmd, void *structptr);
    \brief This function is same as an ioctl function call
    \param[in] fd
    \param[in] cmd
    \param[in] *structptr
    \return Returns zero on success
 */
int IFX_adsl_ioctl(int fd, int cmd, void *structptr);

/*! \fn int IFX_dev_open(const char *pathname, int flags);
    \brief This function is same as open function call 
    \param[in] *pathname
    \param[in] flags
    \return Returns file descriptor
 */
int IFX_dev_open(const char *pathname, int flags);

/*! \fn int IFX_dev_close(int fd);
    \brief This function is same as close function call
    \param[in] fd
    \return Returns zero on success
 */
int IFX_dev_close(int fd);

/*! \fn bool IFX_SNMPd_Set_Enable(bool bEnable);
    \brief This function starts or stops SNMP daemon 
    \param[in] bEnable
    \return Return zero on success
 */
bool IFX_SNMPd_Set_Enable(bool bEnable);

/*! \fn bool IFX_SNMPd_Get_Enable();
    \brief This function checks whether the SNMP daemon is currently running
    \return Returns 1 if pid > 0 ; else returns 0
 */
bool IFX_SNMPd_Get_Enable();

#endif				/* _SNMP_API_H */
