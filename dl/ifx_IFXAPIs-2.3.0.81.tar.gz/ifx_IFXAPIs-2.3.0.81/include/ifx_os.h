/**************************************************************************
** FILE NAME     : ifx_os.h
** PROJECT       : TR69
** MODULES       : Common OS layer for Infineon Modules
** SRC VERSION   : V1.0
** DATE          : 2-11-2004
** AUTHOR        : Hari
** DESCRIPTION   : This file contains common OS wrappers and C 
**                 library functions.
** REFERENCE     : Coding guide lines.
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author      $Comment
***********************************************************************/

/*! \file ifx_os.h
    \brief This file contains common OS wrappers and C library functions.
*/

#ifndef __IFX_OS_H__
#define __IFX_OS_H__

#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <string.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <ctype.h>
#include <features.h>
#include <ctype.h>
#include <netdb.h>

/*! \def IFX_OS_PROTOCOL_TCP 
    \brief OS protocal is of TCP
 */
#define IFX_OS_PROTOCOL_TCP 1

/*! \def IFX_OS_PROTOCOL_UDP 
    \brief OS protocal is of UDP
 */
#define IFX_OS_PROTOCOL_UDP 2

/*! \def IFX_OS_TCP_SOCKTYPE_CLIENT 
    \brief TCP socktype client
 */
#define IFX_OS_TCP_SOCKTYPE_CLIENT 1

/*! \def IFX_OS_TCP_SOCKTYPE_SERVER 
    \brief TCP socktype server
 */
#define IFX_OS_TCP_SOCKTYPE_SERVER 2

/********** Fifo Operations **********/

/*!\fn int32 IFX_OS_CreateFifo(IN uchar8 * pucName)       
   \brief extern integer type function creates a FIFO with a given name 
   \param[in] pucName Pointer to the name of the FIFO
   \return Descriptor to the FIFO
*/

EXTERN int32 IFX_OS_CreateFifo(IN uchar8 * pucName);

/*! \def IFX_OS_RemoveFifo 
    \brief close created FIFO
 */
#define IFX_OS_RemoveFifo(pucName, Fd) \
{ \
   close(Fd); \
   unlink(pucName); \
}

/*!\fn int32 IFX_OS_OpenFifo(IN uchar8 * pucName, IN int32 iFlags)       
   \brief extern integer type function opens a FIFO with a given name 
   \param[in] pucName Pointer to the name of the FIFO
   \param[in] iFlags Flags
   \return Descriptor to the FIFO
*/
EXTERN int32 IFX_OS_OpenFifo(IN uchar8 * pucName, IN int32 iFlags);

/*! \def IFX_OS_CloseFifo 
    \brief close created FIFO
 */
#define IFX_OS_CloseFifo(Fd) close(Fd)

/*! \def IFX_OS_ReadFifo 
    \brief read data from FIFO
 */
#define IFX_OS_ReadFifo(iFd, pcRead, iSize) read(iFd, pcRead, iSize)

/*! \def IFX_OS_WriteFifo 
    \brief write data to FIFO
 */
#define IFX_OS_WriteFifo(iFd, pcWrite, iSize) write(iFd, pcWrite, iSize)

/********** Socket Operations **********/

/*!\fn int32 IFX_OS_CreateSocket(IN uchar8 ucProtocol,
                    IN uint16 unLocalPort,
                    IN uint16 unRemotePort,
                    IN char8 * pacRemoteIpAddress,
                    IN uchar8 ucTcpSocketType)      
   \brief extern integer type function Creates a TCP/UDP Socket 
   \param[in] ucProtocol Protocol Type
   \param[in] unLocalPort Local Port
   \param[in] unRemotePort Remote Port
   \param[in] pacRemoteIpAddress Remote IP Address
   \param[in] ucTcpSocketType TCP Socket Type (Server / Client)
   \return Socket Fd (on Success) or -1 (on Failure)
*/

EXTERN int32
IFX_OS_CreateSocket(IN uchar8 ucProtocol,
		    IN uint16 unLocalPort,
		    IN uint16 unRemotePort,
		    IN char8 * pacRemoteIpAddress, IN uchar8 ucTcpSocketType);

/*! \def IFX_OS_FdZero 
    \brief This is a macro for FD_ZERO function call 
 */
#define IFX_OS_FdZero(pFdSet) FD_ZERO(pFdSet)

/*! \def IFX_OS_FdClear 
    \brief This is a macro for FD_CLR function call
 */
#define IFX_OS_FdClear(iFd, pFdSet) FD_CLR(iFd, pFdSet)

/*! \def IFX_OS_FdSet 
    \brief This is a macro for FD_SET function call
 */
#define IFX_OS_FdSet(iFd, pFdSet) FD_SET(iFd, pFdSet)

/*! \def IFX_OS_FdIsSet 
    \brief This is a macro for FD_ISSET function call
 */
#define IFX_OS_FdIsSet(iFd, pFdSet) FD_ISSET(iFd, pFdSet)

/*!\fn int32 IFX_OS_Select(IN fd_set * pRdSelectFd,
                           IN fd_set * pWrSelectFd, 
                           IN fd_set * pExSelectFd,
			   IN int32 iTimeSec)    
   \brief extern integer type Wrapper Function for the system call select 
   \param[in] pRdSelectFd Read file descriptors
   \param[in] pWrSelectFd Write file descriptors
   \param[in] pExSelectFd Exception file descriptors
   \param[in] iTimeSec Time to block 
   \return Number of Fds set (Success) / -1 (Failure)
*/
EXTERN int32 IFX_OS_Select(IN fd_set * pRdSelectFd, IN fd_set * pWrSelectFd,
			   IN fd_set * pExSelectFd, IN int32 iTimeSec);

/*! \def IFX_OS_Read 
    \brief Read file
 */
#define IFX_OS_Read(iFd, pcRead, iSize) read(iFd, pcRead, iSize)

/*! \def IFX_OS_Write 
    \brief Write to file
 */
#define IFX_OS_Write(iFd, pcWrite, iSize) write(iFd, pcWrite, iSize)

/*! \def IFX_OS_Close 
    \brief Close file
 */
#define IFX_OS_Close(Fd) close(Fd)

/********** Memory Operations **********/

/*! \def IFX_OS_Memset 
    \brief Memset
 */
#define IFX_OS_Memset(pvDst, iChar, uiSize) \
{ \
   uchar8 * pucPtr = (uchar8 *) pvDst; \
   while (uiSize--) \
   { \
      *pucPtr++ = (uchar8) iChar; \
   } \
}

/*! \def IFX_OS_Memcpy 
    \brief Memcpy
 */
#define IFX_OS_Memcpy(pvDst, pvSrc, uiSize) \
{ \
   uchar8 * pucDst1 = (uchar8 *) pvDst ; \
   uchar8 * pucSrc1 = (uchar8 *) pvSrc ; \
   while (uiSize--) \
   { \
      *pucDst1++ = *pucSrc1++; \
   } \
}

/*!\fn int32 IFX_OS_Memcmp(IN const void * pPtr1, 
                           IN const void * pPtr2,
                           IN uint32 uiSize)
   \brief extern integer type Function for Compare characters in two buffers 
   \param[in] pPtr1 Pointer to first buffer
   \param[in] pPtr2 Pointer to second buffer
   \param[in] uiSize Number of characters to copy
   \return < 0 - buf1 less than buf2
             0   - buf1 identical to buf2
           > 0 - buf1 greater than buf2
*/
EXTERN int32 IFX_OS_Memcmp(IN const void *pPtr1, IN const void *pPtr2,
			   IN uint32 uiSize);

/********** String Operations **********/

/*!\fn int32 IFX_OS_Strlen(IN const char8 * pcPtr)
   \brief extern integer type Function Get the length of a string
   \param[in] pcPtr Pointer to buffer to copy from
   \return The number of characters in string
*/
EXTERN int32 IFX_OS_Strlen(IN const char8 * pcPtr);

/*!\fn char8 * IFX_OS_Strcpy(IN char8 * pcDst,
                             IN const char8 * pcSrc)
   \brief extern integer type Function Copy a string
   \param[in] pcDst Pointer to destination string buffer
   \param[in] pcSrc Pointer to string buffer to copy from
   \return The number of characters in string
*/
EXTERN char8 *IFX_OS_Strcpy(IN char8 * pcDst, IN const char8 * pcSrc);

/********** Network Operations **********/

/*!\fn char8 IFX_OS_GetHostIp (OUT char8 * pcHostIp)
   \brief extern integer type Function to get the local host IP Address
   \param[out] pcHostIp Pointer Host IP Address
   \return This function returns local host IP Address
*/
EXTERN char8 IFX_OS_GetHostIp(OUT char8 * pcHostIp);

/*!\fn char8 IFX_OS_GetHostNetmask(OUT char8 * pcHostNetmask)
   \brief extern integer type Function to get the local host Netmask 
   \param[out] pcHostNetmask Pointer Host Network Mask
   \return This function returns local host Subnet Mask
*/
EXTERN char8 IFX_OS_GetHostNetmask(OUT char8 * pcHostNetmask);

/*!\fn int32 IFX_OS_SetIp(IN char8 * pcIpAdd)
   \brief extern integer type Function sets the IP address to a particular Interface
   \param[in] pcIpAdd Pointer to the IP address to be added Interface Name
   \return 0 or -1
*/

EXTERN int32 IFX_OS_SetIp(IN char8 * pcIpAdd);

/*!\fn int32 IFX_OS_SetNetmask(IN char8 * pcNetmask)
   \brief extern integer type Function sets the Netmask to a particular Interface
   \param[in] pcNetmask Pointer to the Netmask to be added Interface Name
   \return 0 or -1
*/

EXTERN int32 IFX_OS_SetNetmask(IN char8 * pcNetmask);

/************** File Operations ****************/

/*! \def IFX_OS_OpenFile 
    \brief open a file
 */
#define IFX_OS_OpenFile(pcFileName, iFlag) open(pcFileName, iFlag)

/*! \def IFX_OS_CloseFile 
    \brief close a file
 */
#define IFX_OS_CloseFile(Fd) close(Fd)

/*! \def IFX_OS_DeleteFile 
    \brief delete file 
 */
#define IFX_OS_DeleteFile(pcName, Fd) \
{ \
   close(Fd); \
   unlink(pcName); \
}

/*! \def IFX_OS_ReadFile 
    \brief read a file
 */
#define IFX_OS_ReadFile(iFd, pcRead, iSize) read(iFd, pcRead, iSize)

/*! \def IFX_OS_WriteFile 
    \brief write to a file
 */
#define IFX_OS_WriteFile(iFd, pcWrite, iSize) write(iFd, pcWrite, iSize)

/*! \def IFX_OS_Lseek 
    \brief Lseek
 */
#define IFX_OS_Lseek(Fd, OffSet, Whence) lseek(Fd, OffSet, Whence)

/*************** Memory Operations ***************/

/*! \def IFX_OS_Malloc 
    \brief Allocate memory
 */
#define IFX_OS_Malloc(iBytes) malloc(iBytes)

/*! \def IFX_OS_Free 
    \brief Free allocated memory
 */
#define IFX_OS_Free(pBuff) free(pBuff)

#ifdef COMPILE

#endif

#endif				/* __IFX_OS_H__ */
