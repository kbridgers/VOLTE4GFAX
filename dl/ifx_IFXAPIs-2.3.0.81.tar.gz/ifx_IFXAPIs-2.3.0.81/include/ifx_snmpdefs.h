#ifndef __IFX_SNMPDEFS_H
#define __IFX_SNMPDEFS_H

/*! \def delimiters
    \brief Delimiters
 */
#define delimiters " \t\n"

/*! \def TAG_SNMP_TRANSPORT
    \brief SNMP Transport Tag
 */
#define TAG_SNMP_TRANSPORT	"snmp_transport"

/*! \def TAG_MIB2_SYSTEM
    \brief MIB2 system Tag
 */
#define TAG_MIB2_SYSTEM		"mib2_system"

/*! \def SNMPV3_USM_CMD_FILE
    \brief SNMPv3 USM cmd file
 */
#define SNMPV3_USM_CMD_FILE	"/tmp/snmpv3usm.cmd"

/*! \def SNMPV3_USM_CREATE_USER
    \brief SNMPv3 USM create user
 */
#define SNMPV3_USM_CREATE_USER	"createUser"

/*! \def SNMPV3_USM_DELETE_USER
    \brief SNMPv3 USM delete user 
*/
#define SNMPV3_USM_DELETE_USER	"deleteUser"

/*! \def USM_CREATE_USER
    \brief USM create user
 */
#define USM_CREATE_USER		1

/*! \def USM_DELETE_USER
    \brief USM delete user
 */
#define USM_DELETE_USER		2

/*! \def SNMP_ROUSER_STR
    \brief SNMP Read only user str 
 */
#define SNMP_ROUSER_STR		"rouser"

/*! \def SNMP_RWUSER_STR
    \brief SNMP read write str 
 */
#define SNMP_RWUSER_STR		"rwuser"

/*! \def SNMP_PID_FILE_PREFIX
    \brief SNMP PID file prefix
 */
#define SNMP_PID_FILE_PREFIX	"snmpd"

/*! \def MAX_LINE_LEN
    \brief Max line length
*/
#define MAX_LINE_LEN		256

#endif
