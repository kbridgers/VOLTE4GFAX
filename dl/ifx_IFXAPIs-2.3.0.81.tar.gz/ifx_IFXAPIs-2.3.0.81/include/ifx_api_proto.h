/*
** =============================================================================
**   FILE NAME        : ifx_api_proto.h
**   PROJECT          : AMAZON MAPI
**   DATE             : 19-Jun-2006
**   AUTHOR           : Amazon API Team
**   DESCRIPTION      : This file contains the function prototypes of all the functions defined in
			Management API Implementation.

**   REFERENCES       :
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          :
**   $Date            $Author                         $Comment
**
** ============================================================================
*/

/*! \file ifx_api_proto.h
    \brief This file defines the fucntion prototypes of supported MAPI in IFX ADSL CPE.
*/

#ifndef _IFX_API_PROTO_H
#define _IFX_API_PROTO_H

#include <ctype.h>
/** \ingroup FUNC_DEV_MAPI
        \defgroup ROUTE_OBJ Routing
       \brief The Routing objects related MAPIs are described in this section.
*/
/* @{ */

/*! \brief  This MAPI does query operation on route device object. It returns all routes of specified state, which are added to
                    the device. This API reads all the routes from the rc.conf file and returns in the array route_entries. The number
                    of route entries read will be returned in num_routes.
        \param[out] num_routes Specifies the number of routes returned
                            by the function.
        \param[out] route_entries Returns an allocated array of all the routes in the system.
        \param[in] flags Filter flags to query only incomplete, Enabled, Disabled or any type of routes.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_all_route_entries(int32 * num_routes,
				ANY_ROUTE_ENTRY ** route_entries, uint32 flags);

/*! \brief  This MAPI does query operation on route_static device object. It returns all routes of specified state, which are
                    statically added to the device. This API reads all the static routes from the rc.conf file and returns in the array
                    static_route_entries. The number of static route entries read will be returned in num_static_routes.
        \param[out] num Specifies the number of static routes returned by the function.
        \param[out] route_entries Returns an allocated array of all statically added routes in the system.
        \param[in] flags Filter flags to query only incomplete, Enabled, Disabled or any type of routes.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_all_static_route_entries(int32 * num,
				       ROUTE_ENTRY ** route_entries,
				       uint32 flags);

/*! \brief  This MAPI perform GET operation on all the policy routes of specified state. This API is currently not available in
                    this release of software package.
        \param[out] num_routes Number of policy route entries in array.
        \param[out] route_entries Policy Route Entries Array.
        \param[in] flags Filter flag for getting a particular status of policy route.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_all_policy_route_entries(int32 * num_routes,
				       POLICY_ROUTE ** route_entries,
				       uint32 flags);

/*! \brief  The RIP functionality is available under compile time flag IFX_CONFIG_RIP. This MAPI provides query
                    functionality on route_dynamic device object. It returns the current status and configuration of dynamic routing
                    through RIP. This API reads the RIP related values from the rc.conf file and returns it in the RIP_CFG structure.
        \param[out] rip_cfg The RIP configuration is set in rip_cfg parameter by the function.
        \param[in] flags The flags specifies the filter for type of entry.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_rip_cfg(RIP_CFG * rip_cfg, uint32 flags);

/*! \brief  This function is used to set the WAN interface Rx Route Protocol
            based on the Global RIP Listen Status on the Router
            We assume that the Route Rx Protocol is set to RIPv2 if
            the Global Listen Mode is set to RIPv1 & RIPv2 Modes
     \param[in] wan_Idx index
     \param[in] wan_common_cfg configuration structure
     \return IFX_SUCCESS / IFX_FAILURE


*/
int32 ifx_set_wanif_route_proto(int wan_Idx, WAN_COMMON_CFG * wan_common_cfg);

/*! \brief  The MAPI allows the SET operation of Add, Delete and Modify type on route_static device object. This API takes
                    the route information as ROUTE_ENTRY structure and does the operation specified. In case of Add or Delete the
                    route entry will be added or deleted from the system and the rc.conf file respectively. Since static route modification
                    is not supported on the fly, the Modify operation is realized through Delete followed by Add with new values.
        \param[in] operation The operation to be performed for this
                            route entry, can be IFX_OP_ADD,
                            IFX_OP_DEL or IFX_OP_MOD
        \param[in] entry The ROUTE_ENTRY structure will have
                                    the values to be added or modified in case
                                    of add or delete respectively. For
                                    Addition, the cpeId comes back filled
                                    upon successful execution. For Delete
                                    operation, this will have only cpeId field filled.
        \param[in] flags Valid combination of atomic flags for SET API.
        \return IFX_SUCCESS / IFX_E_INT_ERROR
*/
int32 ifx_set_static_route(int32 operation, ROUTE_ENTRY * entry, uint32 flags);

/*! \brief  This MAPI performs a SET operation - Add, Delete or Modify the IP routes. This API can take either static or policy
                    type of route in system.
        \param[in] operation The operation to be performed for this
                                                route entry, can be IFX_OP_ADD,
                                                IFX_OP_DEL or IFX_OP_MOD
        \param[in] route Route Information.
        \param[in] flags Valid combination of SET flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_route(int32 operation, ANY_ROUTE_ENTRY * route, int32 flags);

/*! \brief  This MAPI perform SET operation on policy route. This API is currently not available in this release of software
                    package.
        \param[in] operation The operation to be performed for this
                            policy route entry, can be IFX_OP_ADD,
                            IFX_OP_DEL or IFX_OP_MOD
        \param[in] route Policy Route information.
        \param[in] flags Valid combination of SET type of flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_policy_route(int32 operation, POLICY_ROUTE * route, uint32 flags);

/*! \brief  This MAPI provides the SET operation on route_dynamic device object. This API takes the rip configuration in
                    structure RIP_CFG and modifies the existing values in conf file. This API supports only Modify operation as of now.
                    Once the rc.conf updation is done successfully, based on the supply mode the correct version of rip conf is copied
                    to /etc/ripd.conf. And if the status is set to enable then it calls for the service script ripd restart else calls for ripd
                    stop.
        \param[in] cfg This provides the RIP configuration parameters that are set by the function.
        \param[in] flags Valid combination of SET flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_rip(RIP_CFG * cfg, uint32 flags);

/*! \brief  This function is used to check if the route is a static route.
        \param[in] ip IP Address
        \param[in] nm Netmask
        \param[in] gw Gateway
        \param[in] route_entries Route Entries
        \param[in] num_routes Number of Routes
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_check_if_static_route(char8 * ip, char8 * nm, char8 * gw,
				ANY_ROUTE_ENTRY * route_entries,
				int32 num_routes);

	 /* @} *//*Route  */

/** \ingroup FUNC_DEV_MAPI
        \defgroup NAT_OBJ NAT
       \brief The NAT objects related MAPIs are described in this section.
*/
/* @{ */

/*! \brief  This API returns the NAT status on specified WAN interface inputted through WAN index. The function will return
                    IFX_ID structure and return value signifies whether NAT is enabled or not.
        \param[in] wan_index WAN Index
        \param[out] iid  IFX Identifier carrying cpe-Id of WAN
                                    connection inputted through wan_idx.
        \param[in] flags Unused as of now.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_get_nat_status_on_if(int32 wan_index, IFX_ID * iid, uint32 flags);

/*! \brief  This API returns all the virtual server configuration existing in nat_virtualser device object. It reads all the virtual
                    server entries (port mapping entries) from rc.conf and returns them in the output structure array. Also the count of
                    virtual servers read, will be returned in num_entries.
        \param[out] num_entries Output number of the virtual server entries read.
        \param[out] virtual_servers Allocated array of Virtual Server entries. Caller has to free the memory allocated.
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                        IFX_F_GET_INCOMP,
                                        IFX_F_GET_ENA or IFX_F_DEFAULT
                                        can be passed to this API
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_virtual_server_info(int32 * num_entries,
				  VIRTUAL_SERVER ** virtual_servers,
				  uint32 flags);


/*! \brief  This API returns the virtual server instance based on ID details.
        \param[out] virtual_servers Virtual server instance.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_one_virtual_server_info(VIRTUAL_SERVER * virtual_servers);

/*! \brief  This function is used to set the port trigger info entry in configuration file.
        \param[in] operation Type of operation
        \param[in] entry Structure containing port trigger configuration values
        \param[in] flags  Valid combination of SET flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_port_trigger_info(int32 operation, PORT_TRIGGER * entry,
				uint32 flags);

/*! \brief  This function is used to get the port trigger entry from configuration file.
        \param[out] port_trigger structure for fetching configuration values, flags
        \return IFX_SUCCESS / IFX_FAILURE

*/
int32 ifx_get_port_trigger_info(PORT_TRIGGER * port_trigger);

/*! \brief  This function is used to get all the port trigger entries from configuration file.
        \param[in] num_entries number of static lease entries, structure for fetching configuration values, flags
        \param[out] port_trigger structure containing configuration values
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_all_port_trigger_info(int32 * num_entries,
				    PORT_TRIGGER ** port_trigger, uint32 flags);

/*! \brief  This MAPI gets the status of Global NAT on the device.
        \param[in] flags  Unused currently.
        \return IFX_ENABLED - if Global NAT is enabled.
                       IFX_DISABLED - if Global NAT is disabled.
*/

int32 ifx_get_global_nat(uint32 flags);

/*! \brief  This API enables or disables NAT on the specified wan interface. The wan connection can be specified either by
                    giving the wan index or the cpeId. The API will either set or reset the NAT Enable based on the value of enable.
                    If the NAT Status is set to enable for this wan connection, then the wan interface associated with this wan
                    connection will be added to NAPT and Firewall.
        \param[in] wan_index The input wan index for which the NAT Status has to be returned
        \param[in] iid Pointer to IFX_ID structure which will
                                    have the cpeId and parent cpeId of the
                                    wan connection with index wan_index
        \param[in] enable Enable flag which tells if the NAT Status
                            needs to be set or reset for this wan connection
        \param[in] flags Any of the above mentioned flags can be passed
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_nat_status_on_if(int32 wan_index, IFX_ID * iid, int32 enable,
			       uint32 flags);

/*! \brief  This MAPI provides the SET operation for Addition, Deletion and Modification in nat_virtualser device object. It will
                    configure the virtual server entry based on the ip address and wan connection.The configuration agent could
                    specify either the WANConnName or the parent cpeId under which the portmap entry needs to be created. Source
                    address can be zero indicating a wild card which the API takes care of. API restricts from adding a virtual server
                    (port map) entry with an existing entry which has same values for Remote IP Address, Public Port and Protocol
                    set. Based on the enable field the virtual server (port map) entry will be added into the iptables. The API employs
                    a single chain add, delete mechanism.
        \param[in] operation Operation specifies addition (IFX_OP_ADD) or
                            deletion (IFX_OP_DEL) or modification
                            (IFX_OP_MOD).
        \param[in] entry Virtual Server configuration information
        \param[in] flags Valid combination of SET type of atomic flags for desired action.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_virtual_server_info(int32 operation, VIRTUAL_SERVER * entry,
				  uint32 flags);

/*! \brief  This MAPI is a variant of ifx_set_virtual_server_info that can be used when no DevM interaction is needed.
        \param[in] operation Operation specifies addition (IFX_OP_ADD) or
                            deletion (IFX_OP_DEL) or modification
                            (IFX_OP_MOD).
        \param[in] entry Virtual Server configuration information
        \param[in] flags Valid combination of SET type of atomic flags for desired action.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_virtual_server_info_Without_TR69(int32 operation,
					       VIRTUAL_SERVER * entry,
					       uint32 flags);

/*! \brief  This function is used to delete all virtual server entries.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_all_virtual_server_delete();

/*! \brief  This MAPI sets the global NAT in device. Through this API the global NAT can be enabled or disabled in the device.
        \param[in] status Status conveying whether to enable the
                                        Global NAT or disable it. Possible values
                                        are IFX_ENABLED and IFX_DISABLED
        \param[in] flags Unused currently.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_global_nat(int32 status, uint32 flags);

	 /* @} *//*NAT  */

//Firewall Related APIs
//
/** \ingroup FUNC_DEV_MAPI
        \defgroup FIREWALL_OBJ Firewall
       \brief The Firewall objects related MAPIs are described in this section.
*/
/* @{ */

/*! \brief  This function is used to set firewall object.
        \param[in] xFW Firewall object
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_firewall_status(IFX_MAPI_Firewall * xFW, uint32 flags);

/*! \brief  This function is used to set PacketFilter status.
        \param[in] xFW  PacketFilter Status
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_firewall_pfstatus(IFX_MAPI_Firewall_PF * xFW, uint32 flags);

/*! \brief  This function is used to configure Packet Filter rule.
        \param[in] operation Set Action Argument - Add, Modify or Delete.
        \param[in] entry Packetfilter Entry
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_firewall_pfrule(int32 operation,
				   IFX_MAPI_Firewall_PFRule * entry,
				   uint32 flags);

/*! \brief  This function is used to set Firewall DMZ.
        \param[in] entry DMZ
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_firewall_dmz(IFX_MAPI_Firewall_DMZ * entry, uint32 flags);

/*! \brief  This function is used to get Firewall Packet Filter status.
        \param[out] xFW Structure filled with packet filter status
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_firewall_pfstatus(IFX_MAPI_Firewall_PF * xFW, uint32 flags);

/*! \brief  This function is used to get Firwall Packet filter Rule.
        \param[out] pfRule Structure filled with packet filter rule values
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_firewall_pfrule(IFX_MAPI_Firewall_PFRule * pfRule);

/*! \brief  This function is used to get all Packet Filter rules.
        \param[out] num_entries Number of Packet Filter Rules.
        \param[out] pfRules Vector of Packet Filter rules.
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_firewall_pfrules(int32 * num_entries,
				    IFX_MAPI_Firewall_PFRule ** pfRules,
				    uint32 flags);

/*! \brief  This function is used to get DMZ information.
        \param[out] xDmz DMZ information
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_firewall_dmz(IFX_MAPI_Firewall_DMZ * xDmz, uint32 flags);

/*! \brief  This function is used to get firewall status.
        \param[out] xFw Structure filled with firewall status
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_firewall_status(IFX_MAPI_Firewall * xFw, uint32 flags);

#ifdef CONFIG_FEATURE_URL_FILTERING
/*! \brief  This API is used to set single url entry.
        \param[in] operation Type of operation
        \param[in] entry URL filter configuration to be configured
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 mapi_set_url_entry(int32 operation, url_filter_cfg_t *entry, uint32 flags);

/*! \brief  This API is used to get all the url entries from rc.conf.
        \param[out] count Number of url entries in rc.conf.
        \param[out] url_filcfg array Pointer to the allocated array of url
                            entries.
        \param[in] flags State flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 mapi_get_all_url_entries(int32 *count, url_filter_cfg_t **url_filcfg, uint32 flags);

/*! \brief This API returns an url entry configuration. It reads url configuration
                    from rc.conf and returns them in the output structure.
        \param[in] urlFiltIdx Index of URL filter entry requested
        \param[out] url_filt_cfg structure filled with URL filter configuration values requested
        \param[in]  flags
        \return IFX_SUCCESS / IFX_FAILURE

*/
int32 mapi_get_url_entry(int32 urlFiltIdx, url_filter_cfg_t * url_filt_cfg,
				     uint32 flags);
#endif
	 /* @} *//*Firewall */

/* IPsec */
/** \ingroup FUNC_DEV_MAPI
        \defgroup IPsec_OBJ IPsec
       \brief The IPsec objects related MAPIs are described in this section.
*/
/* @{ */

/*! \brief  This API sets an ipsec tunnel entry configuration. It writes tunnel configuration
                    into rc.conf by taking values from input structure array.
        \param[out] p_ipsec_tunnel_info written to rc.conf
        \param[in] flags Any of the flags IFX_F_MODIFY,
                                        IFX_F_DELETE,
                                        IFX_F_DEFAULT,
                                        IFX_F_DONT_ACTIVATE | IFX_F_DONT_VALIDATE,
                                        IFX_F_DEACTIVATE
                                        can be passed to this API
        \param[in] operation Any of the flags IFX_OP_ADD,
                                        IFX_OP_DEL,
                                        IFX_OP_MODIFY
                                        can be passed to this API
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_ipsec_tunnel_entry(int32 operation,
					IFX_IPSEC_TUNNEL * p_ipsec_tunnel_info,
					uint32 flags);

/*! \brief  This API returns all the ipsec tunnel configuration for all existing tunnel entries. It reads all the tunnel
                    from rc.conf and returns them in the output structure array. Also the count of
                    tunnel entries read, will be returned in num_entries.
        \param[out] num_entries Output number of the tunnel entries read.
        \param[out] pp_ipsec_tunnel_info Allocated array of Tunnel entries. Caller has to free the memory allocated.
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                        IFX_F_GET_INCOMP,
                                        IFX_F_GET_ENA or IFX_F_DEFAULT
                                        can be passed to this API
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_all_ipsec_tunnel_entries(int32 * num_entries,
					      IFX_IPSEC_TUNNEL **
					      pp_ipsec_tunnel_info,
					      uint32 flags);

/*! \brief  This API returns an ipsec tunnel entry configuration. It reads tunnel configuration
                    from rc.conf and returns them in the output structure array.
        \param[out] pp_ipsec_tunnel_info structure filled.
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                        IFX_F_GET_INCOMP,
                                        IFX_F_GET_ENA or IFX_F_DEFAULT
                                        can be passed to this API
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_ipsec_tunnel_entry(IFX_IPSEC_TUNNEL * pp_ipsec_tunnel_info,
					uint32 flags);
/*! \brief  This function is used to get Virtual Server information.
        \param[out] virtual_servers
        \return IFX_SUCCESS / IFX_FAILURE
*/

	 /* @} *//*IPsec  */

/** \ingroup FUNC_DEV_MAPI
        \defgroup ATM_OBJ ATM
       \brief This section describes the ATM configuration related functions.
*/
/* @{ */

/*! \brief  This MAPI provides SET operation on wan_conndev device object. It is used to add or delete WAN Connection
                    device instances in this object. Each instance of WAN Connection device will correspond to a single ATM VCC.
                    On deleting the VCC instance, the corresponding WAN Connection Device object is also deleted.
        \param[in] operation Operation specifies addition
                                            (IFX_OP_ADD) or deletion
                                            (IFX_OP_DEL).
        \param[in] wan_connDev WAN Connection Device parameters including IFX_ID part.
        \param[in] flags Valid combination of SET flags.
        \return IFX_SUCCESS / IFX_FAILURE
        \note The WAN object design constraints its management API to not to do compaction after addition or deletion of
                    instances. Unlike other SET type of MAPIs, this does not invoke ifx_CompactCfgSection inside body of this SET
                    MAPI.
*/

int32 ifx_set_wan_conn_dev(int32 operation, WAN_CONN_DEV * wan_connDev,
			   uint32 flags);

/*! \brief  This MAPI provides SET operation on wan_conndev device object. It is used to add or delete WAN Connection
                    device instances in this object. Each instance of WAN Connection device will correspond to a single ATM VCC.
                    On deleting the VCC instance, the corresponding WAN Connection Device object is also deleted.
        \param[in] operation Operation specifies addition
                                            (IFX_OP_ADD) or deletion
                                            (IFX_OP_DEL).
        \param[in] wan_connDev WAN Connection Device parameters including IFX_ID part.
        \param[in] flags Valid combination of SET flags.
        \return IFX_SUCCESS / IFX_FAILURE
        \note The WAN object design constraints its management API to not to do compaction after addition or deletion of
                    instances. Unlike other SET type of MAPIs, this does not invoke ifx_CompactCfgSection inside body of this SET
                    MAPI.
*/

int32 ifx_set_wan_conn_dev_Without_TR69(int32 operation,
					WAN_CONN_DEV * wan_connDev,
					uint32 flags);

/*! \brief  This function is used to get VCC information.
        \param[in] vcc Input VCC
        \param[in] num Number of VPI/VCI selected.
        \param[in] vpivci_selected VPI/VCI
	\param[in] name WAN Name
	\param[in] sValue Value
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_vcc(ATM_VCC_INFO * vcc, int32 num, char8 * vpivci_selected,
		  char8 * name, int32 * sValue);

/*! \brief  This function reads the wan connection configuration from rc.conf
						for the input wan index wanIdx and based on the ATM link type it
						reads the specific connection parameters from either the
			 			wan_ip or wan_ppp section from rc.conf
        \param[in] wanIdx Input index of the wan connection for
                                        which configuration has to be returned.
        \param[out] wan_conn_cfg Output pointer to wan connection
                                            structure which will have the configuration values.
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 mapi_get_wan_config(int32 wanIdx, WAN_CONN_CFG * wan_conn_cfg,
				 uint32 flags);

/*! \brief  This function reads the wan connection configuration from rc.conf
						for the input wan index wanIdx and wanMode match criteria. 
						Based on the ATM link type it reads the specific connection parameters
						from either the	wan_ip or wan_ppp section from rc.conf
        \param[in] wanIdx Input index of the wan connection for
                                        which configuration has to be returned.
        \param[out] wan_conn_cfg Output pointer to wan connection
                                            structure which will have the configuration values.
        \param[in] wanMode Mode of WAN (refer enum WAN_MODE)
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 mapi_get_wan_config_for_mode(int32 wanIdx, WAN_CONN_CFG * wan_conn_cfg, WAN_MODE wanMode,
				 uint32 flags);

/*! \brief

*/
int32 mapi_get_all_wan_config_for_wan_mode(WAN_MODE wanMode, int32 * num_entries,
				     WAN_CONN_CFG ** pp_wancfg, uint32 flags);

/*! \brief  This MAPI function retrieves the instances of adsl_vcchannel device object. This function returns the list of all ATM
                    VCCs configured in the system by reading through system configuration database. These VCCs constitute entries
                    that are in the enabled state (configured in the device) and entries that have been placed in the disabled state in
                    the persistent storage (rc.conf). This API allocates memory for all the VCC entries and returns the number of VCC
                    entries in num_entries to the caller. It is the responsibility of the caller function to release the memory after using
                    the information associated with the VCC entry.
        \param[out] num_entries Number of entries returned by the function.
        \param[out] vcc_array Pointer to the allocated array of VCC
                            entries. The caller must free the memory allocated.
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                            IFX_F_GET_INCOMP,
                                            IFX_F_GET_ENA or IFX_F_DEFAULT
                                            can be passed to this API
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_all_vcc_info(int *num_entries, ATM_VCC_INFO ** vcc_array,
			   uint32 flags);

/*! \brief  This function is used to retrieve an ATM VCC information.
        \param[in] vcc ATM VCC information
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_one_vcc_info(ATM_VCC_INFO * vcc);

/*! \brief  This MAPI gets all WAN Configurations by reading from wan_main and wan_ip or wan_ppp device objects based
                    on linkType information of instances in wan_main.
        \param[out] num_entries Number of entries in pp_wancfg vector.
        \param[out] pp_wancfg Vector of WAN Config entries
        \param[in] flags State flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_all_wan_atm_vcc_config(int32 * num_entries,
				     WAN_CONN_CFG ** pp_wancfg, uint32 flags);

/*! \brief  This MAPI perform SET operation of Addition and Deletion type in adsl_vcchannel device object. The API is used
                    to add or delete the specified ATM VCC configuration in the persistent storage. For every ATM VCC add or delete
                    corresponding wan connection device add or delete should also be done. There will be a one-to-one mapping
                    between the wan connection device object and VCC object.
        \param[in] operation Operation specifies addition
                            (IFX_OP_ADD) or deletion
                            (IFX_OP_DEL).
        \param[in] entry Creates an ATM VCC with desired
                            parameters or deletes the specified VCC entry.
        \param[in] flags Valid combination of SET type of flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_vcc_cfg(int32 operation, ATM_VCC_INFO * entry, uint32 flags);

#if 0
/*! \brief  This API sets a WAN Connection on the specified VPI/VCI. Each WAN connection is split wan_main and wan_ip
                    or wan_ppp device objects. The API figures out based on linkType to choose between wan_ip and wan_ppp
                    objects. For incomplete configurations where linkType is not specified at time of addition of instance it only adds
                    in wan_main and rest is done only after linkType is specified. The API supports ADD, MODIFY and DELETE
                    operations on these device objects. This API will configure the common parameters of the wan connection. And
                    the sub-apis will configure ip or ppp specific parameters. Both the wan main object and wan ip/ppp object will share
                    the same wan index, however for each wan connection add or modify the corresponding interface name will be
                    determined inside the API.
        \param[in] op IFX_OP_ADD: Add the WAN connection specified.
                                IFX_OP_DEL: Delete the WAN connection specified.
                                IFX_OP_MOD: Modify the WAN connection specified.
        \param[in] cfg Pointer to wan connection configuration
                                   to be associated with the specified vcc.
        \param[in] flags  Valid combination of SET flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_wan_atm_vcc_config(int32 op, WAN_CONN_CFG * cfg, uint32 flags);
#endif

	 /* @} *//*ATM */

/** \ingroup FUNC_DEV_MAPI
        \defgroup PTM_OBJ PTM
       \brief This section describes the PTM WAN functions.
*/
/* @{ */

/*! \brief  This function is used to get all the configured PTM channels.
        \param[out] num_entries Specifies number of PTM channels returned by the function.
        \param[out] ptm_array Array of PTM channels.
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_all_ptm_info(int32 * num_entries, PTM_CH_CFG ** ptm_array,
			   uint32 flags);

/*! \brief  This function is used to Add/Delete/Modify PTM channel.
        \param[in] operation Operation Action - Add, Modify or Delete.
        \param[in] entry pointer to PTM channel object to be created
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_ptm_ch_cfg(int32 operation, PTM_CH_CFG * entry, uint32 flags);

/*! \brief  This function is used to get a specific PTM channel entry.
        \param[in] ptm_entry pointer to PTM channel in which configuration will be returned.
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_ptm_ch_cfg(PTM_CH_CFG * ptm_entry, uint32 flags);

	 /* @} *//*PTM */

/** \ingroup FUNC_DEV_MAPI
        \defgroup EthWAN_OBJ Ethernet WAN
       \brief This section describes the Ethernet WAN functions.
*/
/* @{ */

/*! \brief  This MAPI perform SET operation of Addition and Deletion type in Ethernet Channel device object.
        \param[in] operation Operation Action - Add, Modify or Delete.
        \param[in] entry pointer to Ethernet Channel object
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_eth_ch_cfg(int32 operation, ETH_CH_CFG * entry, uint32 flags);

/*! \brief  This function is used to get details of a particular Ethernet channel identified by VLAN Id.
        \param[out] eth_entry Structure which will have VLAN Id filled as input and all the remaining information is returned.
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_eth_ch_cfg(ETH_CH_CFG * eth_entry, uint32 flags);

/*! \brief  This MAPI returns parameters of all configured Ethernet WAN Connections parameters.
        \param[out] num_entries Number of configured Ethernet WAN connections.
        \param[out] eth_array Output pointer to wan connection array
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_all_eth_info(int32 * num_entries, ETH_CH_CFG ** eth_array,
			   uint32 flags);

	 /* @} *//*EthWAN */

/** \ingroup FUNC_DEV_MAPI
        \defgroup EthLAN_OBJ Ethernet LAN
       \brief The Ethernet LAN objects related MAPIs are described in this section.
*/
/* @{ */

/*! \brief  This MAPI queries the current configuration of specified interface of lan_main object. It returns the IP address and
                    netmask of the LAN interface, whose name is specified. If multiple IP addresses are assigned to a LAN interface,
                    an array of IP address and netmask is returned with num_entries set to the number of IP addresses.\n
                    The API allocates the memory for ip_array and the caller is expected to free the memory allocated once done.

        \param[in] name Name of the LAN Interface whose IP/subnet mask is to be retrieved
        \param[out] num_entries Number of IP subnets attached to this interface
        \param[out] ip_array Pointer to array of IP Address/subnet pairs of the interface.
        \param[in] flags Any of the flags, IFX_F_GET_DIS,
                            IFX_F_GET_INCOMP, IFX_F_GET_ENA or
                            IFX_F_DEFAULT can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_get_lan_ip_mask(char8 * name, int32 * num_entries,
			  IP_MASK_TYPE ** ip_array, uint32 flags);

/*! \brief  This function is used to query ethernet config.
        \param[in] name Interface Name
        \param[out] eth_cfg Ethernet Interface Config.
        \param[in] flags Filter Flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_ethernet_config(char8 * name, ETHERNET_INTERFACE_CONFIG * eth_cfg,
			      uint32 flags);

/*! \brief  This API retrieves Hosts information on LAN side of CPE.
        \param[out] num_entries Number of Entries in host array
        \param[out] host Host array carrying IP and MAC address.
        \param[in] hType Host Type
        \param[in] lanIfName LAN Interface Name
        \param[in] flags Flags - unused as of now.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_lan_hosts(int32 * num_entries, LAN_HOST_INFO ** host,
			LAN_HOST_TYPE hType, char8 * lanIfName, uint32 flags);

/*! \brief  This MAPI sets the specified LAN interface on the LAN device. Since the system supports as of now only one LAN
        device, the MAPI is just taking interface name and setting it for that singleton LAN device through Modification
        operation.
        \param[in] iface Ethernet Interface Name.
        \param[in] flags Valid combination of SET flags for Modify.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_lan_interface(char8 * iface, uint32 flags);

/*! \brief  This MAPI does a SET operation on the specified interface of lan_main object. Since the system currently supports
                    only one LAN Interface, so the only operation supported is MODIFY. For modify operation the API first stops the
                    LAN services using the current configuration and then it updates the database with new configuration. Once the
                    new configuration is updated in rc.conf successfully, LAN services will be re-started.
        \param[in] op Operation specifies addition
                                (IFX_OP_ADD), deletion
                                (IFX_OP_DEL) or modification
                                (IFX_OP_MOD). As of now only
                                IFX_OP_MOD is supported for this API.
        \param[in] index Specifies the Lan device index for which
                                        configuration has to be done.
        \param[in] name Specifies the interface name of the LAN IP Interface.
        \param[in] ip_array Pointer to IP_MASK which will store the ip address and netmask.
        \param[in] flags Extra specifier flags to augment the action.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_lan_ip_mask(int32 op, int32 index, char8 * name,
			  IP_MASK_TYPE * ip_array, uint32 flags);

int32 ifx_set_lan_ula6(int32 operation, int32 lan_ipv6_mode, char8 * name,
		       IP6_ADDR_STRING * addrconf,
		       LAN_IPv6_SL_Config * radvd_conf,
		       LAN_IPv6_DHCPv6_Config * dhcpv6, uint32 flags);

/*! \brief  This MAPI gets the current bridge configuration on specified bridge interface.
        \param[in] bridge_if Name of bridge interface
        \param[out] bridge_cfg Bridge Configuration information.
        \param[in] flags Get type of flag.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_bridge_config(char8 * bridge_if, BRIDGE_CONFIG * bridge_cfg,
			    uint32 flags);

/*! \brief  This support API returns the number of Ethernet member interfaces for the given bridge interface.
        \param[in] bridge_if The input bridge interface name.
        \param[out] num_ifs Return value which will have the number
                                            of Ethernet interfaces configured under bridge_if.
        \param[in] flags Unused as of now.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_bridge_num_eth_ifs(char8 * bridge_if, int32 * num_ifs,
				 int32 flags);

/*! \brief  This function is used to set ethernet interface configuration.
        \param[in] name Interface Name
        \param[in] eth_cfg Ethernet Config
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_ethernet_config(char8 * name, ETHERNET_INTERFACE_CONFIG * eth_cfg,
			      uint32 flags);

#ifdef CONFIG_FEATURE_SAMBA	/* CONFIG_FEATURE_SAMBA_SERVER */
void ifx_convert_hex_to_ascii(char8 * hex_str, char8 * ascii_str);

/*!\fn int CAST5(int encrypt, unsigned char *obuf, size_t osize, const unsigned char *ibuf, size_t isize, void* iv, void *key, size_t key_len)
   \brief This function encrypt/decrypt system user password
   \param[in] encrypt
   \param[in,out] *obuf
   \param[in,out] osize
   \param[in] *ibuf
   \param[in] isize
   \param[in] *iv
   \param[in] *key
   \param[in] key_len
   \return IFX_SUCCESS/IFX_FAILURE
*/
int CAST5(int encrypt, unsigned char *obuf, size_t osize,
	  const unsigned char *ibuf, size_t isize,
	  void *iv, void *key, size_t key_len);

/*!\fn int ifx_set_system_username_password(char *name, char *pasword)
   \brief This function changes system user name and password
   \param[in] *name
   \param[in] *pasword
   \return IFX_SUCCESS/IFX_FAILURE
*/
int ifx_set_system_username_password(uint32 oper, uint32 id, char *name,
				     char *password);

/*! \brief  This MAPI returns the SAMBA Server related information. It must get CPE-Id to get specific instance information. It
                    reads the dhcp server information from rc.conf file and returns it as a pointer.
        \param[in,out] smbServer SAMBA Server configuration to be retrieved with id part filled in by caller.
        \param[in] flags Any of state flags for getting entries of specified state.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_samba_server(LTQ_MAPI_SAMBA_Server * smbServer, uint32 flags);

/*! \brief  This MAPI sets the SAMBA Server configuration parameters such as SAMBA Server name.
        \param[in,out] smbServer SAMBA Server configuration to be retrieved with id part filled in by caller.
        \param[in] flags Any of state flags for getting entries of specified state.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_samba_server(uint32 oper, LTQ_MAPI_SAMBA_Server * smbServer,
			   uint32 flags);

/*! \brief  This MAPI returns the File Share related information. It must get CPE-Id to get specific instance information. It
                    reads the dhcp server information from rc.conf file and returns it as a pointer.
        \param[in,out] fileShare File Share configuration to be retrieved with id part filled in by caller.
        \param[in] flags Any of state flags for getting entries of specified state.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_file_share(LTQ_MAPI_File_Share * fileShare, uint32 flags);

/*! \brief  This MAPI returns all the File Share related information.
	\param[out] numFS Number of entries in fsEntries vector.
	\param[out] fsEntries Vector of File Server entries
        \param[in] flags Any of state flags for getting entries of specified state.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_all_file_share_entries(uint32 * numFS,
				     LTQ_MAPI_File_Share ** fsEntries,
				     uint32 flags);

/*! \brief  This MAPI sets the File Share configuration parameters such as SAMBA Server name.
        \param[in] oper Type of operation
        \param[in,out] fileShare File Share configuration to be retrieved with id part filled in by caller.
        \param[in] flags Any of state flags for getting entries of specified state.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_file_share(uint32 oper, LTQ_MAPI_File_Share * fileShare,
			 uint32 flags);

/*! \brief  This function reads the file share configuration from the rc.conf file and returns it as in the pointer fileUser.
        \param[in,out] fileUser output pointer to LTQ_MAPI_File_Share which will store the file share configuration
        \param[in] flags Any of state flags for getting entries of specified state.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_fs_usr_act(LTQ_MAPI_File_User * fileUser, uint32 flags);

/*! \brief  This MAPI returns all the File Share User related information.
	\param[out] numFSUsr Number of entries in usrEntries vector.
	\param[out] usrEntries Vector of File Server entries
        \param[in] flags Any of state flags for getting entries of specified state.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_all_fs_usr_act_entries(uint32 * numFSUsr,
				     LTQ_MAPI_File_User ** usrEntries,
				     uint32 flags);

/*! \brief  This function sets the file share configuration in the rc.conf file.
        \param[in,out] fileUser output pointer to LTQ_MAPI_File_Share which will store the file share configuration
        \param[in] flags Any of state flags for getting entries of specified state.
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_fs_usr_act(uint32 oper, LTQ_MAPI_File_User * fileUser,
			 uint32 flags);
#endif				/* CONFIG_FEATURE_SAMBA_SERVER */

	 /* @} *//* EthLAN   */

/** \ingroup FUNC_DEV_MAPI
        \defgroup WLAN_OBJ WLAN
       \brief The WLAN objects related MAPIs are described in this section.
*/
/* @{ */

#ifdef CONFIG_FEATURE_IFX_WIRELESS
/*
   WLAN MAPI prototypes for get operation
*/
/* WLAN Capabilities Query */

/*! \brief  This function is used to query WLAN capability.
        \param[out] wlCaps WLAN Capability Information
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_capability(IFX_MAPI_WLAN_Capability * wlCaps,
				   uint32 flags);

#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS

/*
   WLAN MAPI prototypes for get operation
*/
/* WLAN Capabilities Query */

/*! \brief  This function is used to query Secondary WLAN capability
        \param[out] wlCaps WLAN Capability Information
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_sec_capability(IFX_MAPI_WLAN_Capability * wlCaps,
				       uint32 flags);

#endif				//CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS

/* WLAN AP Configuration */
/*! \brief  This function is used to retrieve all WLAN AP/VAP configured entries.
        \param[out] numEntries  Number of Entries
        \param[out] wlApCfg Vector of WLAN AP Configuration.
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_all_wlan_ap_config(uint32 * numEntries,
				      IFX_MAPI_WLAN_AP_Cfg ** wlApCfg,
				      uint32 flags);

/*! \brief  This function is used to get WLAN AP Configuration.
        \param[in,out] wlApCfg WLAN AP Configuration with id part filled-in.
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_ap_config(IFX_MAPI_WLAN_AP_Cfg * wlApCfg, uint32 flags);

/* WLAN PHY Configuration */

/* WLAN PHY Configuration */
/*! \brief  This function is used to get all WLAN Physical Configuration.
        \param[out] numEntries Number of Entries
        \param[out] wlPhyCfg Vector of Physical WLAN Configuration
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_all_wlan_phy_config(uint32 * numEntries,
				       IFX_MAPI_WLAN_PhyCfg ** wlPhyCfg,
				       uint32 flags);

/*! \brief  This function is used to get the complete WLAN physical configuration.
        \param[in,out] wlPhyCfg  WLAN Physical Configuration with Id part filled-in by caller.
        \param[in] flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_phy_config(IFX_MAPI_WLAN_PhyCfg * wlPhyCfg,
				   uint32 flags);

/*! \brief  This function is used to get the static WLAN physical configuration.
        \param[in,out] wlPhyCfg  WLAN Physical Configuration with Id part filled-in by caller.
        \param[in] flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_static_phy_config(IFX_MAPI_WLAN_PhyCfg * wlPhyCfg,
				   uint32 flags);

/*! \brief  This function is used to get dynamical WLAN physical configuration.
        \param[in,out] wlPhyCfg  WLAN Physical Configuration with Id part filled-in by caller.
        \param[in] flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_dyn_phy_config(IFX_MAPI_WLAN_PhyCfg * wlPhyCfg,
				       uint32 flags);

/* WLAN Main Configuration */

/*! \brief  This function is used to get all WLAN-Main obejcts configuration.
        \param[out] numEntries Number of Entries in wlMain Array
        \param[out] wlMain Vector of WLAN-Main configuration entries.
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_all_wlan_main_config(uint32 * numEntries,
					IFX_MAPI_WLAN_MainCfg ** wlMain,
					uint32 flags);

/*! \brief  This function is used to retrieve specified WLAN AP/VAP Config.
        \param[in,out] wlMain WLAN-Main Config with Id part inputted by caller.
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_main_config(IFX_MAPI_WLAN_MainCfg * wlMain,
				    uint32 flags);

/*! \brief  This function is used to retrieve dynamic WLAN AP/VAP Config.
        \param[in,out] wlMain WLAN-Main Config with Id part inputted by caller.
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_dyn_vap_info(IFX_MAPI_WLAN_MainCfg * wlMain,
				     uint32 flags);

/*
   required for Web UI - apName is input and mainCpeID and radioCpeId are output
*/

/*! \brief  This function is used to retrieve WLAN-MAins CPE-Id and Phy Id from specified AP Name.
        \param[in] apName AP/VAP Name
        \param[out] mainCpeId WLAN-Main Cpe Id
        \param[out] radioCpeId Radio Cpe Id
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_main_n_phy_cpeid(char8 * apName,
					 uint32 * mainCpeId,
					 uint32 * radioCpeId);

/* WLAN Security Configuration */

/* WLAN Security Configuration */
/*! \brief  This function is used to get specified AP/VAP WLAN Security Config.
        \param[in,out] wlSec WLAN Security Config with cpeId part filled-in.
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_security_config(IFX_MAPI_WLAN_SecCfg * wlSec,
					uint32 flags);

/*! \brief  This function is used to get all WLAN Security Configuration.
        \param[out] numEntries Number of Entries in vector.
        \param[out] wlSec Vector of WLAN-Security Configuration.
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_all_wlan_security_config(uint32 * numEntries,
					    IFX_MAPI_WLAN_SecCfg ** wlSec,
					    uint32 flags);

/*! \brief  This function is used to retrieve all WLAN WEP Config.
        \param[in] mainCpeId WLAN-Main instance Cpe-Id
        \param[out] wlWepCfg WLAN WEP Config
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_all_wlan_wep_keys(uint32 mainCpeId,
		IFX_MAPI_WLAN_WEP_Key * wlWepKey,
				       uint32 flags);

/*! \brief  This function is used to get specified WLAN WEP Config.
        \param[out] wlWepCfg WLAN WEP Config
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_wlan_wep_config(IFX_MAPI_WLAN_WEP_Cfg * wlWepCfg,
				   uint32 flags);
/*
   \todo move to wlan.c and make this a static function
*/

/*! \brief  This function is used to get WLAN WEP Keys.
        \param[in] keyIdx WEP Key Index
        \param[out] wlWepKey WLAN WEP Key.
        \param[in] flags Get Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_wep_key(int32 keyIdx,
				IFX_MAPI_WLAN_WEP_Key * wlWepKey, uint32 flags);

/*! \brief  This function is used to get WLAN-Personal Config.
        \param[in,out] wlPersonal WLAN-Personal Config with CPE-Id part input-ed by caller.
        \param[in] flags Filter Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_wlan_personal_config(IFX_MAPI_WLAN_PersonalCfg * wlPersonal,
					uint32 flags);
/*
   todo implementation
*/

/*! \brief  This function is used to retrieve all WLAN Personal Config.
        \param[in] mainCpeId WLAN-Main CPE-Id
        \param[out] wlPersonal WLAN-Personal Config
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_all_wlan_personal_config(uint32 mainCpeId,
					    IFX_MAPI_WLAN_PersonalCfg **
					    wlPersonal, uint32 flags);

/*! \brief  This function is used to retrieve WLAN 802.1X Config.
        \param[in,out] wlRadius WLAN RADIUS config with Id part filled-in by caller.
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_802_1x_config(IFX_MAPI_WLAN_802_1x * wlRadius,
				      uint32 flags);

/* WLAN MAC Address - Global */

/*! \brief  This function is used to get Global WLAN MAC Address Control.
        \param[out] numEntries Number of Entries in Vector
        \param[out] glblMacControl Global MAC Control Vector
        \param[in] flags Filter Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_all_global_mac_control_entries(uint32 * numEntries,
						  IFX_MAPI_GlobalMacControl **
						  glblMacControl, uint32 flags);
/*
   \todo move to wlan.c and make this a static function
*/
/*! \brief  This function is used to get Global MAC Control Entry.
        \param[out] glblMacControl Global MAC Control Entry
        \param[in] flags Filter Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_global_mac_control_entry(IFX_MAPI_GlobalMacControl *
					    glblMacControl, uint32 flags);

/* WLAN MAC Address - per AP/VAP */
/*
   \todo implementation
*/

/*! \brief  This function is used to get all WLAN MAC Control Entries.
        \param[in] mainCpeId WLAN-Main CPE-Id.
        \param[out] numEntries Number of Entries
        \param[out] wlMacControl Vector of MAC Control Entries
        \param[in] flags Filter Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_all_wlan_mac_control_entries(uint32 mainCpeId,
						uint32 * numEntries,
						IFX_MAPI_WLAN_MAC_Control **
						wlMacControl, uint32 flags);

/*! \brief  This function is used to get WLAN MAC Control Entry.
        \param[in,out] wlMacControl WLAN MAC Control Entry with CPe-Id part filled-in by caller.
        \param[in] flags Filter Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_mac_control_entry(IFX_MAPI_WLAN_MAC_Control *
					  wlMacControl, uint32 flags);

/* WLAN Device Association */
/*
   \todo
*/

/*! \brief  This function is used to get all associated stations information.
        \param[in] mainCpeId WLAN-MAin CPE Id
        \param[out] numEntries Number of Entries
        \param[out] wlAssocInfo WLAN Association Info Vector
	\param[in] flags Filter Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_all_wlan_assoc_devices(uint32 mainCpeId,
					  uint32 * numEntries,
					  IFX_MAPI_WLAN_AssocInfo **
					  wlAssocInfo, uint32 flags);

/* WLAN Statistics */
/*! \brief  This function is used to retrieve statistics of specified AP/VAP.
        \param[in, out] wlStats WLAN Statistics with CPE-ID part filled in.
        \param[in] flags Filter Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_stats(IFX_MAPI_WLAN_Stats * wlStats, uint32 flags);

/*! \brief  This function is used to retrieve statistics of specified radio.
        \param[in, out] wlPhyStats WLAN Statistics with CPE-ID part filled in.
        \param[in] flags Filter Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_phy_stats(IFX_MAPI_WLAN_PhyStats * wlPhyStats, uint32 flags);

/*
   \todo implementation
*/
/*! \brief  This function is used to retrieve WLAN WPA security counters.
        \param[out] wlWpaSecCntrs WLAN WPA Security Counters
        \param[in] flags Filter Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_wpa_counters(IFX_MAPI_WLAN_WPA_SecCounters *
				     wlWpaSecCntrs, uint32 flags);

/* WLAN Channel List */

/*! \brief  This function is used to get WLAN channels list.
        \param[in] phyCpeId WLAN-Phy object CPE-Id
        \param[out] wlChanList WLAN Channel List
        \param[in] flags Filter Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_channel_list(uint32 phyCpeId,
				     IFX_MAPI_WLAN_ChannelList * wlChanList,
				     uint32 flags);

/* WLAN Supported Data Rates */

/*! \brief  This function is used to get supported WLAN data rates.
        \param[in] phyCpeId Physical Cpe Id.
        \param[out] wlSuppRates WLAN Supported rates
        \param[in] flags Filter Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_supported_datarates(uint32 phyCpeId,
					    IFX_MAPI_WLAN_SupportedRate *
					    wlSuppRates, uint32 flags);

/* WLAN WepKey Index */

/*! \brief  This function is used to get WAN WEP key index.
        \param[out] key index value.
        \param[in] cpeid, wep key index
        \return IFX_SUCCESS / IFX_FAILURE

*/
int32 ifx_mapi_get_wlan_wepkeyindex(uint32 cpeid, uint32 * keyindex);

/* WLAN WMM Configuration */

/*! \brief  This function is used to get specified outbound WMM settings in AP.
        \param[out] wlApWmm WMM outbound settings in AP.
        \param[in] flags Filter Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_wmm_ap_config(IFX_MAPI_WLAN_AP_WMM_Cfg * wlApWmm,
				      uint32 flags);

/*! \brief  This function is used to get all outbound WMM settings in AP.
        \param[in] mainCpeId WLAN-Main CPE Id.
        \param[out] numEntries Number of Entries.
        \param[out] wlApWmm Vector of WMM Outbound QoS.
	\param[in] flags Filter Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_all_wlan_wmm_ap_config(uint32 mainCpeId,
					  uint32 * numEntries,
					  IFX_MAPI_WLAN_AP_WMM_Cfg ** wlApWmm,
					  uint32 flags);

/*! \brief  This function is used to query specified inbound WMM Settings.
        \param[in,out] wlStaWmm Inbound WMM Setting with CPE-Id part filled-in.
        \param[in] flags Filter Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_wmm_sta_config(IFX_MAPI_WLAN_STA_WMM_Cfg * wlStaWmm,
				       uint32 flags);

/*! \brief  This function is used to retrieve all inbound WMM Settings.
        \param[in] mainCpeId WLAN-Main CPE Id
        \param[out] numEntries Number of entries in vector
        \param[out] wlStaWmm WLAN Inbound WMM QoS
	\param[in] flags Filter Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_all_wlan_wmm_sta_config(uint32 mainCpeId,
					   uint32 * numEntries,
					   IFX_MAPI_WLAN_STA_WMM_Cfg **
					   wlStaWmm, uint32 flags);

/* WLAN WPS Configuration */

/*! \brief  This function is used to get wlan wps configuration parameters
        \param[in] wlWps
        \param[out] wlWps
        \param[in] flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_wps_config(IFX_MAPI_WLAN_WPS_Cfg * wlWps, uint32 flags);

/*! \brief  This function is used to get wlan wps registrar configuration parameters.
        \param[in] wlWpsRegs
        \param[out] wlWpsRegs
        \param[in] flags
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_wlan_wps_registrar_config(IFX_MAPI_WLAN_WPS_Regs_Cfg *
					     wlWpsRegs, uint32 flags);

/*! \brief  This function is used to all wlan wps registrar configuration parameters for all entries.
        \param[in] mainCpeId
        \param[in] numEntries
        \param[in] wlWpsRegs
        \param[out] wlWpsRegs
        \param[in] flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_all_wlan_wps_registrar_config(uint32 mainCpeId,
						 uint32 * numEntries,
						 IFX_MAPI_WLAN_WPS_Regs_Cfg **
						 wlWpsRegs, uint32 flags);

/*! \brief  This function returns the wps config state
        \param[in] mainCpeId WLAN-Main CPE-Id.
        \return Any of the following if success: IFX_MAPI_WPS_NOT_CONFIGURED or IFX_MAPI_WPS_CONFIGURED
                       IFX_FAILURE - if failure
*/
int32 ltq_mapi_get_wps_config_state(uint32 mainCpeId);

/*! \brief  This function is used to get all WLAN WPS EP MAC Entries.
        \param[in] mainCpeId WLAN-Main CPE-Id.
        \param[out] numEntries Number of Entries
        \param[out] wlMacControl Vector of MAC Control Entries
        \param[in] flags Filter Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_get_all_wlan_wps_endpoint_mac(uint32 mnCpeId,
						uint32 * numEntries,
						LTQ_MAPI_WLAN_WPS_EP_MAC_Cfg **wpsEpMac, uint32 flags);

/* WLAN WDS Configuration */

/*! \brief  This function is used to retrieve WDS configuration from all VAPs.
        \param[out] numEntries Number of Entries
        \param[out] wlWdsCfg Vector of WDS configuration
        \param[in] flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_get_all_wlan_wds_config(	uint32 * numEntries,
										LTQ_MAPI_WLAN_WDS_Cfg ** wlWdsCfg,
										uint32 flags);

/*! \brief  This function is used to retrieve WDS configuration.
        \param[in,out] wlWdsCfg
        \param[in] flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_get_wlan_wds_config(	LTQ_MAPI_WLAN_WDS_Cfg * wlWdsCfg,
									uint32 flags);

/*! \brief  This function is used to get all WLAN WDS peer MAC Entries.
        \param[in] mainCpeId WLAN-Main CPE-Id.
        \param[out] numEntries Number of Entries
        \param[out] wlWdsPeerMac Vector of MAC Control Entries
        \param[in] flags Filter Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_get_all_wlan_wds_peer_mac(uint32 mnCpeId,
						uint32 * numEntries,
						IFX_MAPI_WLAN_MAC_Control **wlWdsPeerMac, uint32 flags);

/*! \brief  This function is used to get all WLAN WAVE specifics.
        \param[out] wlVendorWaveCfg Vector of WAVE configuration
        \param[in] flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_get_wlan_vendor_wave_cfg(
	LTQ_MAPI_WLAN_VendorWaveCfg *wlVendorWaveCfg, uint32 flags);

/*! \brief  This function is used to get all WLAN WAVE specifics.
        \param[out] numEntries Number of Entries
        \param[out] wlVendorWaveCfg Vector of WAVE configuration
        \param[in] flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_get_all_wlan_vendor_wave_cfg(uint32 * numEntries,
	LTQ_MAPI_WLAN_VendorWaveCfg ** wlVendorWaveCfg, uint32 flags);

#if defined (CONFIG_FEATURE_LTQ_WIRELESS_VB) || defined (CONFIG_FEATURE_LTQ_WIRELESS_STA_SUPPORT)
/*! \brief  This function is used to get global bridge device configuration parameters
        \param[out] wlVbGenCfg
        \param[in] flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_get_vb_gbd_config(LTQ_MAPI_WLAN_VB_GEN_BD_Cfg * wlVbGenCfg,
				 uint32 flags);

/*! \brief  This function is used to get wlan vb general configuration parameters
        \param[out] wlVbGenCfg
        \param[in] flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_get_wlan_vb_lan_config(LTQ_MAPI_WLAN_VB_LAN_BD_Cfg * wlVbGenCfg,
				      uint32 flags);

/*! \brief  This function is used to get wlan settings for video bridge
        \param[out] wlVbGenCfg
        \param[in] flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_get_vb_wlan_config(LTQ_MAPI_VB_WLAN_Cfg * wlVbWlanCfg,
				  uint32 flags);

/*! \brief  This function returns the mode information of whether video bridge is operation as AP or as STA.
        \param[in] flags Not used currently.
        \return Any of the following if success: LTQ_MAPI_WLAN_VB_STA, LTQ_MAPI_WLAN_VB_AP or LTQ_MAPI_WLAN_VB_AUTO.
                       IFX_FAILURE - if failure
*/
int32 ltq_mapi_get_vb_mode(uint32 flags);

/*! \brief  This function is used to get VB Scan results.
        \param[out] numEntries Number of Entries
        \param[out] wlVbScanRes
        \param[in] flags indicating to disconnect from AP before scanning
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_get_wlan_scan(uint32 * numEntries,
			     LTQ_MAPI_VB_WLAN_Scan ** wlVbScanRes,
			     uint32 fDisconnectAp);

/*! \brief  This function is used to get VB link status results.
        \param[out] wlVbLinkStatus pointer to Link status structure
        \param[in] flags Filter Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_get_vb_wlan_link_status(LTQ_MAPI_VB_WLAN_LinkStatus *
				       wlVbLinkStatus, uint32 flags);

/*! \brief  This function is used to get wlan profile information
        \param[out] wlVbWlnProf
        \param[in] flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_get_vb_wlan_profile(LTQ_MAPI_VB_WLAN_Profile * wlVbWlnProf,
				   uint32 flags);

/*! \brief  This function is used to get ethernet phy port configuration parameters
        \param[out] wlVbGenCfg
        \param[in] flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_get_vb_eth_phy_config(LTQ_MAPI_VB_ETH_PHY_Cfg * vbEthPhyCfg,
				     uint32 flags);

/*! \brief  This function is used to retrieve all inbound WMM Settings.
        \param[in] mainCpeId WLAN-Main CPE Id
        \param[out] numEntries Number of entries in vector
        \param[out] wlStaWmm WLAN Inbound WMM QoS
	\param[in] flags Filter Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_get_vb_wmm_sta_config(IFX_MAPI_WLAN_STA_WMM_Cfg * wlVbStaWmm,
				     uint32 flags);
#endif				/* #if defined (CONFIG_FEATURE_LTQ_WIRELESS_VB) */

/*! \brief  This function is used to retrieve vendor information.
		\param[in] radioCpeId WLAN Radio CpeId
		\param[in] flags Filter Flags
        \return WAVE300, QCA
*/
int32 ltq_mapi_get_wlan_vendor(uint32 radioCpeId, uint32 flags);

/*! \brief  This function is used to get info about supported features of WLAN SS
		\param[in] radioCpeId WLAN Radio CpeId
		\param[in] flags Filter Flags
        \return bitmap of supported features (see LTQ_MAPI_WLAN_Feature)
*/
int32 ltq_mapi_get_wlan_supported_features(uint32 radioCpeId, uint32 flags);
#endif				/* #ifdef CONFIG_FEATURE_IFX_WIRELESS */

/*! \brief  This API returns the number of Wireless LAN member interfaces for the given bridge interface.
        \param[in] bridge_if The input bridge interface name.
        \param[out] num_ifs Return value which will have the number
                        of WLAN interfaces configured under bridge_if.
        \param[in] flags Unused as of now.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_bridge_num_wlan_ifs(char8 * bridge_if, int32 * num_ifs,
				  int32 flags);

#ifdef CONFIG_FEATURE_IFX_WIRELESS
/*
   WLAN MAPI prototypes for set operation
*/
/* WLAN AP Configuration */
/*! \brief  This function is used to set WLAN AP/VAP config.
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \param[in] wlApCfg WLAN AP config
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_wlan_ap_config(uint32 oper,
				  IFX_MAPI_WLAN_AP_Cfg * wlApCfg, uint32 flags);

/* WLAN PHY Configuration */
/*! \brief  This function is used to set WLAN Physical config.
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \param[in] wlPhyCfg WLAN Physical Config
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_wlan_phy_config(uint32 oper,
				   IFX_MAPI_WLAN_PhyCfg * wlPhyCfg,
				   uint32 flags);

/* WLAN Main Configuration */
/*! \brief  This function is used to set WLAN Main Config.
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \param[in] wlMain WLAN Main Config
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_wlan_main_config(uint32 oper,
				    IFX_MAPI_WLAN_MainCfg * wlMain,
				    uint32 flags);

/* WLAN Security Configuration */
/*! \brief  This function is used to configure WLAN Security objects.
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \param[in] wlSec WLAN Security config
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_wlan_security_config(uint32 oper,
					IFX_MAPI_WLAN_SecCfg * wlSec,
					uint32 flags);

/*! \brief  This function is used to set WLAN WEP Keys.
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \param[in] wepKeyIndex WEP Key index (Active)
        \param[in] wlWepKey Set of four WLAN WEP Keys
	\param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_wlan_wep_key(uint32 oper,
				int32 wepKeyIndex,
				IFX_MAPI_WLAN_WEP_Key * wlWepKey, uint32 flags);

#if 0
int32 ifx_mapi_set_wlan_passphrase(uint32 operation,
				   IFX_MAPI_WLAN_PSKey * wlPsk, uint32 flags);
#endif

/*! \brief  This function is used to configure WLAN WEP Config.
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \param[in] wlWepCfg WLAN WEP Config
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_wlan_wep_config(uint32 oper,
				   IFX_MAPI_WLAN_WEP_Cfg * wlWepCfg,
				   uint32 flags);

/*! \brief  This function is used to configure WLAN-PErsonal Security.
        \param[in] operation Set Action Argument - Add, Modify or Delete.
        \param[in] wlPsk WLAN Personal Security
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_wlan_passphrase_config(uint32 operation,
					  IFX_MAPI_WLAN_PSKey * wlPsk,
					  uint32 flags);

/*! \brief  This function is used to confgure RADIUS (802.1X) WLAN Security.
        \param[in] operation Set Action Argument - Add, Modify or Delete.
        \param[in] wlRadius WLAN RAIUD (802.1x) configuration
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_wlan_802_1x_config(uint32 operation,
				      IFX_MAPI_WLAN_802_1x * wlRadius,
				      uint32 flags);

#if 0
/* WLAN MAC Address - Global */
/*! \brief  This function is used to configure Global WLAN MAc Address Control.
        \param[in] operation Set Action Argument - Add, Modify or Delete.
        \param[in] glblMacControl Global MAC address Control
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_global_mac_control(uint32 operation,
				      IFX_MAPI_GlobalMacControl *
				      glblMacControl, uint32 flags);

/*! \brief  This function is used to set MAC Control Status.
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \param[in] glblMacControl Global MAC Control
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_global_mac_control_status(uint32 oper,
					     IFX_MAPI_GlobalMacControl *
					     glblMacControl, uint32 flags);
#endif /* #if 0 */

/* WLAN MAC Address - per AP/VAP */
/*! \brief  This function is used to configure WLAN MAC control.
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \param[in] wlMacControl WLAN MAC Control
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_wlan_mac_control(uint32 oper,
				    IFX_MAPI_WLAN_MAC_Control * wlMacControl,
				    uint32 flags);

/*! \brief  This function is used to set MAC control Status.
        \param[in] mainCpeId WLAN-MAIn object cpe-Id.
        \param[in] oper Operation - Add, Modify or Delete.
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_wlan_mac_control_status(uint32 mainCpeId,
					   uint32 oper, uint32 flags);

/* WLAN WMM Configuration */
/*! \brief  This function is used to configure outbound WMM Settings on AP.
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \param[in] wlApWmm Outbound WMM Settings
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_wlan_wmm_ap_config(uint32 oper,
				      IFX_MAPI_WLAN_AP_WMM_Cfg * wlApWmm,
				      uint32 flags);

/*! \brief  This function is used to configure inbound WMM Settings.
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \param[in] wlStaWmm Inbound WMM Settings on AP.
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_wlan_wmm_sta_config(uint32 oper,
				       IFX_MAPI_WLAN_STA_WMM_Cfg * wlStaWmm,
				       uint32 flags);

/* WLAN WPS Configuration */
/*! \brief  This function is used to.
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \param[in] wlWps
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_wlan_wps_config(uint32 oper,
				   IFX_MAPI_WLAN_WPS_Cfg * wlWps, uint32 flags);
/*! \brief  This function is used to.
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \param[in] wlWpsRegs
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_wlan_wps_registrar_config(uint32 oper,
					     IFX_MAPI_WLAN_WPS_Regs_Cfg *
					     wlWpsRegs, uint32 flags);

/*! \brief  This function is used to trigger the WPS push button method on the wlan.
        \param[in] wlMnCpeId mainCpeID of AP/VAP the WPS method shall be started for.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_trigger_wps_pbc(uint32 wlMnCpeId);

/*! \brief  This function is used to trigger the WPS PIN method on the wlan.
        \param[in] wlMnCpeId mainCpeID of AP/VAP the WPS PBC method shall be started for.
	\param[in] clientPIN - PIN entered on the Web page that must be given to wlan
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_trigger_wps_pin(uint32 wlMnCpeId,
		char8 * clientPIN,
		char8 * authEpMacAddr);

/*! \brief  This function is used to restores the default AP pin.
        \param[in] wlMnCpeId mainCpeID of AP/VAP the WPS PBC method shall be started for.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_restore_wps_pin(uint32 wlMnCpeId);

/*! \brief  This function restores the WPS pin to default
        \param[in] mainCpeID of AP/VAP
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_generate_wps_pin(uint32 wlMnCpeId);

int32 ifx_mapi_reset_wps(uint32 wlMnCpeId);

/* WLAN WPS EP MAC Address - per AP/VAP */
/*! \brief  This function is used to configure WLAN WPS EP MAC control.
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \param[in] wlMacControl WLAN MAC Control
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_set_wlan_wps_endpoint_mac(uint32 oper,
			LTQ_MAPI_WLAN_WPS_EP_MAC_Cfg * wlWpsEpMac,
			uint32 flags);

/*! \brief  This function is used to get VB WPS link connection status.
        \param[out] wlVbWpsConnectionStatus pointer to WPS connection status
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_get_wps_connection_status(
	LTQ_MAPI_WPS_ConnectionStatus *wpsConnectionStatus);

/* WLAN WDS peer MAC - per AP/VAP */
/*! \brief  This function is used to configure WLAN WPS EP MAC control.
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \param[in] wlWdsPeerMac IFX_MAPI_WLAN_MAC_Control
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_set_wlan_wds_peer_mac(uint32 oper,
			IFX_MAPI_WLAN_MAC_Control * wlWdsPeerMac,
			uint32 flags);

/* WLAN WDS Configuration */
/*! \brief  This function is used to.
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \param[in] wlWdsCfg
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_set_wlan_wds_config(uint32 oper,
	LTQ_MAPI_WLAN_WDS_Cfg * wlWdsCfg, uint32 flags);

/* WLAN WAVE Configuration */
/*! \brief  This function is used to.
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \param[in] wlVendorWaveCfg
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_set_wlan_vendor_wave_cfg(uint32 oper,
	LTQ_MAPI_WLAN_VendorWaveCfg *wlVendorWaveCfg, uint32 flags);

#if defined (CONFIG_FEATURE_LTQ_WIRELESS_VB) || defined (CONFIG_FEATURE_LTQ_WIRELESS_STA_SUPPORT)
/*! \brief  This function is used to set general video bridge configuration parameters.
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \param[in] wlVbGenCfg
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_set_wlan_vb_config(uint32 oper,
				  LTQ_MAPI_WLAN_VB_GEN_BD_Cfg * wlVbGenCfg,
				  uint32 flags);

/*! \brief  This function is used to set lan related video bridge configuration parameters.
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \param[in] wlVbLanCfg
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_set_wlan_vb_lan_config(uint32 oper,
				      LTQ_MAPI_WLAN_VB_LAN_BD_Cfg * wlVbLanCfg,
				      uint32 flags);

/*! \brief  This function is used to set video bridge eth phy port settings.
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \param[in] vbEthPhyCfg
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_set_vb_eth_phy_config(uint32 oper,
				     LTQ_MAPI_VB_ETH_PHY_Cfg * vbEthPhyCfg,
				     uint32 flags);

/*! \brief  This function is used to set video bridge wlan settings.
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \param[in] wlVbLanCfg
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_set_wlan_vb_wlan_config(uint32 oper,
				       LTQ_MAPI_VB_WLAN_Cfg * wlVbWlnCfg,
				       uint32 flags);

/*! \brief  This function is used to set video bridge wlan profile in rc.conf.
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \param[in] wlVbWlnProf
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_set_vb_wlan_profile(uint32 oper,
				   LTQ_MAPI_VB_WLAN_Profile * wlVbWlnProf,
				   uint32 flags);

/*! \brief  This function is used to trigger the VB to connect to an AP as stored in rc.conf
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_trigger_vb_connect();

/*! \brief  This function is used to set a wildcard for ESSID required by scan operation.
        \param[in] oper Set operation Argument - Modify.
        \param[in] wlVbGenCfg
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_set_wlan_vb_scan_config(uint32 oper,
				       LTQ_MAPI_VB_WLAN_Scan * wlVbScan,
				       uint32 flags);

/*! \brief  This function is used to configure VB300 STA WMM Settings.
        \param[in] oper Set operation Argument - Modify.
        \param[in] wlVbStaWmm Inbound WMM Settings on AP.
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_set_wlan_vb_wmm_config(uint32 oper,
				      IFX_MAPI_WLAN_STA_WMM_Cfg * wlVbStaWmm,
				      uint32 flags);
#endif				/* #if defined (CONFIG_FEATURE_LTQ_WIRELESS_VB) */
#endif				/* #ifdef CONFIG_FEATURE_IFX_WIRELESS */
	 /* @} *//*WLAN  */

/*IPQoS APIs */
/** \ingroup FUNC_DEV_MAPI
        \defgroup QOS_OBJ QoS
       \brief This section describes the MAPIs pertinent to QoS.
*/
/* @{ */

/*! \brief  This function is used to query QoS cpaability.
        \param[out] qos_capab QoS Capability
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_qos_capability(IFX_MAPI_QoS_Capability * qos_capab,
				  uint32 flags);

/*! \brief  This function is used to get QoS Queue Management Entries.
        \param[out] qm Queue Management
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_qos_qm(IFX_MAPI_QoS_QM * qm, uint32 flags);

/*! \brief  This function is used to get all QoS classifier entries.
        \param[out] numEntries Number of Classifier Entries
        \param[out] qos_classify Array of Classifier entries
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_all_qos_classifier(uint32 * numEntries,
				      IFX_MAPI_QoS_Classifier ** qos_classify,
				      uint32 flags);

/*! \brief  This function is used to get specific Upstream QoS Classifier.
        \param[out] qos_classify Classifier
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_qos_classifier(IFX_MAPI_QoS_Classifier * qos_classify,
				  uint32 flags);

/*! \brief  This function is used to get specific Downstream QoS Classifier.
        \param[out] qos_classify Classifier
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_qos_ds_classifier(IFX_MAPI_QoS_Classifier * qos_classify,
				  uint32 flags);
/*! \brief  This function is used to get specific QoS Queue.
        \param[out] qos_queue QoS Queue
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_qos_queue(IFX_MAPI_QoS_Queue * qos_queue, uint32 flags);


/*! \brief  This function is used to get specific QoS Queue's statistics.
        \param[out] qos_queuestats QoS QueueStats
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_qos_queue_stats(IFX_MAPI_QoS_QueueStats * qos_queuestats,
	       			uint32 flags);

/*! \brief  This function is used to get all Queue entries.
        \param[out] numEntries Number of Queue entries
        \param[out] qos_queue Queue array
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_all_qos_queue(uint32 * numEntries,
				 IFX_MAPI_QoS_Queue ** qos_queue, uint32 flags);

/*! \brief  This function is used to get policer entry.
        \param[out] qos_policer QoS Policer Entry
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_qos_policer(IFX_MAPI_QoS_Policer * qos_policer,
			       uint32 flags);

/*! \brief  This function is used to get wan interface specific upstream classifiers.
        \param[in] qIfType
        \param[out] numEntries Number of Classifier Entries
        \param[out] qos_classify
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_all_qos_classifier_if_specific(IFX_MAPI_QoS_Interface_Type
						  qIfType, uint32 * numEntries,
						  IFX_MAPI_QoS_Classifier **
						  qos_classify, uint32 flags);

/*! \brief  This function is used to get wan interface specific downstream classifiers.
        \param[in] qIfType
        \param[out] numEntries Number of Classifier Entries
        \param[out] qos_classify
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_all_qos_ds_classifier_if_specific(IFX_MAPI_QoS_Interface_Type
						  qIfType, uint32 * numEntries,
						  IFX_MAPI_QoS_Classifier **
						  qos_classify, uint32 flags);

/*! \brief  This function is used to get wan interface specific upstream classifier instances.
        \param[in] qIfType
        \param[out] numEntries Number of Classifier Entries
        \param[out] qos_classify
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_all_qos_classifier_class_if_specific(IFX_MAPI_QoS_Interface_Type
                                                  qIfType, uint32 * numEntries,
                                                  IFX_MAPI_QoS_Classifier **
                                                  qos_classify, uint32 flags);

/*! \brief  This function is used to get lan interface specific downstream classifier instances.
        \param[in] qIfType
        \param[out] numEntries Number of Classifier Entries
        \param[out] qos_classify
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_all_qos_ds_classifier_class_if_specific(IFX_MAPI_QoS_Interface_Type
                                                  qIfType, uint32 * numEntries,
                                                  IFX_MAPI_QoS_Classifier **
                                                  qos_classify, uint32 flags);

/*! \brief  This function is used to get wan interface specific Queues.
        \param[in] qIfType
        \param[out] numEntries Number of Queue Entries
        \param[out] qos_queue
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_all_qos_queue_if_specific(IFX_MAPI_QoS_Interface_Type
					     qIfType, uint32 * numEntries,
					     IFX_MAPI_QoS_Queue ** qos_queue,
					     uint32 flags);

/*! \brief  This function is used to get instances count from distinct field value pair for a class.
        \param[in] mode QoS Interface Type
        \param[in] secName Object Name
        \param[in] prefix Prefix Name
        \param[in] fName Field Name
	\param[in] fValue Field Value
	\param[in] flags Valid combination of Get bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_get_instance_count_from_dist_fvp_for_class(IFX_MAPI_QoS_Interface_Type
						     mode, char8 * secName,
						     char8 * prefix,
						     char8 * fName,
						     char8 * fValue,
						     uint32 flags);

/*! \brief  This function is used to get instances count from distinct field value pair for a class.
        \param[in] mode QoS Interface Type
        \param[in] secName Object Name
        \param[in] prefix Prefix Name
        \param[in] fName Field Name
	\param[in] fValue Field Value
	\param[in] flags Valid combination of Get bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_get_instance_count_from_dist_fvp_for_ds_class(IFX_MAPI_QoS_Interface_Type
						     mode, char8 * secName,
						     char8 * prefix,
						     char8 * fName,
						     char8 * fValue,
						     uint32 flags);

/*! \brief  This function is used to get instances count from distinct field value pair for a Qos.
        \param[in] mode QoS Interface Type
        \param[in] secName Object Name
        \param[in] prefix Prefix Name
        \param[in] fName Field Name
	\param[in] fValue Field value
	\param[in] flags Valid combination of Get bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_get_instance_count_from_dist_fvp_for_qos(IFX_MAPI_QoS_Interface_Type
						   mode, char8 * secName,
						   char8 * prefix,
						   char8 * fName,
						   char8 * fValue,
						   uint32 flags);

/*! \brief  This function is used to get unique field value pair for a QoS Intaerface.
        \param[in] mode  QoS Interface Type
        \param[in] fName Field Name
        \param[in] fValue Field value
        \param[out] fRetName Field Return Name
	\param[out] fRetValue Field Return Value
	\param[in] flags Valid combination of flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_check_unique_fvp_for_qos_iface(IFX_MAPI_QoS_Interface_Type mode,
					 char8 * fName, char8 * fValue,
					 char8 * fRetName, char8 * fRetValue,
					 uint32 flags);

/*! \brief  This function is used to get unique field value pair for a QoS Class.
        \param[in] mode QoS Interface Type
        \param[in] fName Field Name
        \param[in] fValue Field Value
        \param[out] fRetName Field Return Name
        \param[out] fRetValue Field Return Value
        \param[in] flags Valid combination of flags (bitwise-ORed)
	\return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_check_unique_fvp_for_qos_class(IFX_MAPI_QoS_Interface_Type mode,
					 char8 * fName, char8 * fValue,
					 char8 * fRetName, char8 * fRetValue,
					 uint32 flags);

/*! \brief  This function is used to get unique field value pair for a Downstream QoS Class.
        \param[in] mode QoS Interface Type
        \param[in] fName Field Name
        \param[in] fValue Field Value
        \param[out] fRetName Field Return Name
        \param[out] fRetValue Field Return Value
        \param[in] flags Valid combination of flags (bitwise-ORed)
	\return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_check_unique_fvp_for_qos_ds_class(IFX_MAPI_QoS_Interface_Type mode,
					 char8 * fName, char8 * fValue,
					 char8 * fRetName, char8 * fRetValue,
					 uint32 flags);

/*! \brief  This function is used to get Wan Interface specific Classifier count.
        \param[in] qIfType QoS Interface Type
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_classifier_count_for_wan_mode(IFX_MAPI_QoS_Interface_Type
						 qIfType);

/*! \brief  This function is used to get Wan Interface specific downstream Classifier count.
        \param[in] qIfType QoS Interface Type
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_ds_classifier_count_for_wan_mode(IFX_MAPI_QoS_Interface_Type
						 qIfType);

/*! \brief  This function is used to get Classifier count based on Classifier
 	IfType.
        \param[in] qIfType QoS Interface Type
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_classifier_count_for_class_If(IFX_MAPI_QoS_Interface_Type
						 qIfType);

/*! \brief  This function is used to get downstream Classifier count based on Classifier
 	IfType.
        \param[in] qIfType QoS Interface Type
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_ds_classifier_count_for_class_If(IFX_MAPI_QoS_Interface_Type
						 qIfType);

/*! \brief  This function is used to get Wan Interface specific mfc Classifier count.
        \param[in] qIfType QoS Interface Type
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_classifier_mfc_count_for_wan_mode(IFX_MAPI_QoS_Interface_Type
						     qIfType);

/*! \brief  This function is used to get Wan Interface specific downstream mfc Classifier count.
        \param[in] qIfType QoS Interface Type
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_ds_classifier_mfc_count_for_wan_mode(IFX_MAPI_QoS_Interface_Type
						     qIfType);
/*! \brief  This function is used to get Wan Interface specific Qos Queue count.
        \param[in] qIfType QoS Interface Type
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_queue_count_for_wan_mode(IFX_MAPI_QoS_Interface_Type
					    qIfType);

/*! \brief  This function is used to get wan connection count for a specified IfType
        \param[in] count 
        \param[in] qIfType QoS Interface Type
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_get_wan_conn_count_for_ifType(int32 * count,
					IFX_MAPI_QoS_Interface_Type qIfType);


/*! \brief  This function is used to get Wan Interface add check.
        \param[in] qIfType QoS Interface Type
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_queue_add_check(IFX_MAPI_QoS_Interface_Type qIfType);

/*! \brief  This function is used to get the Active QoS Interface.
	\return Active Qos Interface Type
*/

IFX_MAPI_QoS_Interface_Type ifx_mapi_get_active_qos_iface();

/*! \brief  This function is used to get CPEID of default queue.
        \param[in] mode QoS Interface Type
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_mapi_get_default_queue_cpeid(IFX_MAPI_QoS_Interface_Type mode);

/*! \brief  This function is used to get the Class Interface.
        \param[in] cpeid CPEID
        \return IFX_SUCCESS / IFX_FAILURE
*/

IFX_MAPI_QoS_Interface_Type ifx_mapi_get_class_iface(char8 * cpeid);

/*! \brief  This function is used to get the Class Interface.
        \param[in] cpeid CPEID
        \return IFX_SUCCESS / IFX_FAILURE
*/

IFX_MAPI_QoS_Interface_Type ifx_mapi_get_ds_class_iface(char8 * cpeid);

/*! \brief  This function is used to get field value pair for QoS Interface from another field value pairs.
        \param[in] mode QoS Interface Type
        \param[in] secName Object Name
        \param[in] prefix Prefix
        \param[in] fName1 Field Name-1
	\param[in] fValue1 Field Value-1
	\param[in] fName2 Field Name-2
	\param[in] fValue2 Field Value-2
	\param[in] fName3 Field Name-3
	\param[in] fValue3 Field Value-3
	\param[in] flags Valid combination of Get bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_get_fvp_from_another_fvps_for_qos(IFX_MAPI_QoS_Interface_Type mode,
					    char8 * secName, char8 * prefix,
					    char8 * fName1, char8 * fValue1,
					    char8 * fName2, char8 * fValue2,
					    char8 * fName3, char8 * fValue3,
					    uint32 flags);

/*! \brief  This function is used to get the Qos instance count from the distinct field value pairs.
        \param[in] mode QoS Interface Type
        \param[in] secName Object Name
        \param[in] prefix Prefix
        \param[in] fName1 Field Name-1
        \param[in] fValue1 Field Value-1
        \param[in] fName2 Field Name-2
        \param[in] fValue2 Field Value-2
        \param[in] flags Valid combination of Get bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE

*/

int32 ifx_get_instance_count_from_dist_fvps_for_qos(IFX_MAPI_QoS_Interface_Type
						    mode, char8 * secName,
						    char8 * prefix,
						    char8 * fName1,
						    char8 * fValue1,
						    char8 * fName2,
						    char8 * fValue2,
						    uint32 flags);

/*! \brief  This function is used to get the field count for queue.
        \param[in] field
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_get_field_count_queue(char8 * field);

/*! \brief  This function is used to calculate and update QoS Upstream Queue Rates/Weights.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ipqos_rate_update();


/*! \brief  This function is used to calculate and update QoS Downstream Queue Rates/Weights.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ipqos_rate_update_DS();


/*! \brief  This function is used to queue map.
        \param[in] qos_queue - queue to be operated.
        \param[in] flags - Valid combination of Set bit flags 
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 init_qspec_class_queue_map_file(IFX_MAPI_QoS_Queue * qos_queue,
				      unsigned int flags);

/*! \brief  This function is used to validate QoS Upstream Rates.
        \param[in] Oper - Add, Modify or Delete, 8 for other.
        \param[in] cpeId - cpeId or port rate if Oper is 8
        \param[in] qos_queue_passed - queue to be operated. NULL if Oper is 8
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ipqos_rate_validate(uint32 Oper, uint32 cpeId,
			  IFX_MAPI_QoS_Queue * qos_queue_passed);

/*! \brief  This function is used to validate QoS Downstream Rates.
        \param[in] Oper - Add, Modify or Delete, 8 for other.
        \param[in] cpeId - cpeId or port rate if Oper is 8
        \param[in] qos_queue_passed - queue to be operated. NULL if Oper is 8
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ipqos_rate_validate_DS(uint32 Oper, uint32 cpeId,
			  IFX_MAPI_QoS_Queue * qos_queue_passed);

/*! \brief  This function is used to set QoS QueueManagement Object.
        \param[in] Oper Operation - Modify Action only supported.
        \param[in] class  Queue management Object
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_qos_qm(uint32 Oper, IFX_MAPI_QoS_QM * class, uint32 flags);
/*! \brief  This function is used to configure Qos Upstream Classifier.
        \param[in] Oper Operation - Add, Modify or Delete Action
        \param[in] qos_classify Classifier Config
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_qos_classifier(uint32 Oper,
				  IFX_MAPI_QoS_Classifier * qos_classify,
				  uint32 flags);

/*! \brief  This function is used to configure Qos Downstream Classifier.
        \param[in] Oper Operation - Add, Modify or Delete Action
        \param[in] qos_classify Classifier Config
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_qos_ds_classifier(uint32 Oper,
				  IFX_MAPI_QoS_Classifier * qos_classify,
				  uint32 flags);

/*! \brief  This function is used to configure QoS Upstream/Downstream Queue entry.
        \param[in] Oper Operation - Add, Modify or Delete Action
        \param[in] qos_queue Queue Config
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_qos_queue(uint32 Oper, IFX_MAPI_QoS_Queue * qos_queue,
			     uint32 flags);


/*! \brief  This function is used to configure queue statistics entry.
        \param[in] Oper Operation - Add, Modify or Delete Action
        \param[in] qos_queuestats - Queue stats Config
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_qos_queue_stats(uint32 Oper, IFX_MAPI_QoS_QueueStats * qos_queuestats,
	       			uint32 flags);

/*! \brief  This function is used to configure QoS Policer entry.
        \param[in] Oper Operation - Add, Modify or Delete Action
        \param[in] qos_policer Policer Config
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_qos_policer(uint32 Oper, IFX_MAPI_QoS_Policer * qos_policer,
			       uint32 flags);
	 /* @} *//* QoS */

/** \ingroup FUNC_DEV_MAPI
        \defgroup WAN_OBJ WAN
       \brief The WAN objects related MAPIs are described in this section.
*/
/* @{ */

/*! \brief  The MAPI provides the information about the default WAN interface on device object default_wan_iface. Upon
                    successful execution it returns information such as the cpeId, parent cpeId and wan index of the default WAN
                    connection configured in the system.
        \param[out] iid The API will read the cpeId and parentcpeId
                                    of the default wan connection from
                                    default_wan_iface section and fill in this
                                    structure.
        \param[out] wan_index Index of the default WAN connection.
        \param[out] wan_connName Connection name of the default WAN connection. 
        \param[in] flags Currently unused in this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_get_default_wan_if(IFX_ID * iid, int *wan_index, char8 * wan_connName,
			     uint32 flags);

/*! \brief  This function is used to query possible IP connection types in WAN.
        \param[in] wan_index WAN index
        \param[in] iid IFX Identifier of WAN
        \param[out] num_wan_conn_types Number of WAN connection Types.
	\param[out] possible_conn_types Possibel Connection Types Array
	\param[in] flags Get Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_wan_ip_possible_conn_types(int32 wan_index, IFX_ID * iid,
					 uint32 * num_wan_conn_types,
					 WAN_IP_CONN_TYPE **
					 possible_conn_types, uint32 flags);

/*! \brief  This MAPI provides GET API on wan_ip device object. It returns WAN IP Connection parameters on the specified
                    wan index and the cpeId. If it is a Static IP connection, the values will be read from system configuration file and
                    and if it is a DHCP IP connection then values will be read from system. For a disabled IP connection default values
                    are returned.
        \param[in] wanIdx Input index of the wan connection for
                                        which configuration has to be returned.
        \param[out] wan_cfg Output pointer to wan connection
                                            structure which will have the configuration
                                            values. CPE-Id part should come filled if
                                            wan-index is not inputted.
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                                                    IFX_F_GET_INCOMP,
                                                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_wan_ip_config(int32 wanIdx, WAN_CONN_CFG * wan_cfg, uint32 flags);

/*! \brief  This MAPI provides GET operation on wan_ppp device object. The API returns WAN PPP Connection parameters
                    on the specified wan index and the cpeId. It will return the wan ppp connection specific parameter values through
                    reading from system configuration database. For a disabled ppp connection default values are returned.
        \param[in] wanIdx Input index of the wan connection for
                                            which configuration has to be returned.
        \param[out] wan_cfg Output pointer to wan connection
                                            structure which will have the configuration values. In case wan-index is not passed
                                            then cpeId must be provided.
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_wan_ppp_config(int32 wanIdx, WAN_CONN_CFG * wan_cfg,
			     uint32 flags);

/*! \brief  This is a support API for retrieving the number of activated WAN devices in system.
        \param[out] count Number of enabled WAN Devices in
                                            system returned upon successful execution.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_wan_conn_device_count(uint32 * count);

/*! \brief  This MAPI provides a SET operation on wan_ip DevObj. It configures the WAN IP Connection on the specified
                    VPI/VCI. The api supports ADD, MODIFY and DELETE operations on a wan ip connection. This API is called from
                    inside the wan atm vcc set API and is not exposed as of now. The wan atm vcc set API will fill in the required fields
                    inside the WAN_IP_CONFIG structure and pass it to this API. Wan index for this API will also be passed from the
                    wan atm vcc set API.
        \param[in] operation Operation specifies addition
                                            (IFX_OP_ADD) or deletion
                                            (IFX_OP_DEL) or modification
                                            (IFX_OP_MOD).
        \param[in] wan_index Input index of the wan connection for
                                               which configuration has to be returned.
        \param[in] wan_ip_cfg Pointer to wan ip connection configuration
                                                to be associated with the specified wan index
        \param[in] flags Valid combination of SET flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_wan_ip_config(int32 operation, int32 wan_index,
			    WAN_IP_CONFIG * wan_ip_cfg, uint32 flags);

/*! \brief  This MAPI provides SET operation on wan_ppp device object. The API configures the WAN PPP Connection on
                    the specified VPI/VCI. The api supports ADD, MODIFY and DELETE operations on a wan ppp connection. This
                    API will be called from inside the wan atm vcc set API and is not exposed. The wan atm vcc set API will fill in the
                    required fields inside the WAN_PPP_CONFIG structure and pass it to this API. Wan index for this API will also be
                    passed from the wan atm vcc set API.
        \param[in] operation It can be any of the following:
                                            IFX_OP_ADD
                                            IFX_OP_MOD
                                            IFX_OP_DEL
        \param[in] wan_index Input index of the wan connection for
                                                which configuration has to be returned.
        \param[in] wan_ppp_cfg Pointer to wan ppp connection
                                                configuration to be associated with the specified wan index
        \param[in] flags Valid combination of SET flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_wan_ppp_config(int32 operation, int32 wan_index,
			     WAN_PPP_CONFIG * wan_ppp_cfg, uint32 flags);

/*! \brief	This MAPI provides SET operation on default_wan_iface and
						default_wan_cfg_fused device objects. It updates the wan connection
						as the default wan connection for the callers WAN PHY MODE, in
						"default_wan_cfg_fused" section of rc.conf. If the callers WAN MODE
						and current WAN MODE of the device are same, the wan connection is
						set as default wan connection, in "default_wan_iface" section of
						rc.conf. It gets the wan connection name and interface information
						either from the input wan_index or cpeId in IFX_ID structure.

						Once "default_wan_iface" section of rc.conf is updated successfully,
						the API will add a default route for the interface of the wan
						connection specified.
        \param[in] iid CpeId information about WAN Interface.
        \param[in] wan_index Index of the default wan connection in wan section.
        \param[in] flags Valid combination of SET flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_default_wan_if(IFX_ID * iid, int wan_index, uint32 flags);

/*! \brief  This is a wrapper mapi called from adaptation. Based on the wan mode it calls
        the appropriate internal get function to get wan config info from rc.conf
        \param[in] wanIdx Index of WAN connection
        \param[out] wan_conn_cfg Pointer to wan connection configuration
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_get_wan_config(int32 wanIdx, WAN_CONN_CFG * wan_conn_cfg,
			      uint32 flags);

/*! \brief  This MAPI gets all WAN Configurations by reading from wan_main and wan_ip or wan_ppp device objects based
                    on linkType information of instances in wan_main.
        \param[in] mode Input WAN mode as one of GET_WAN_CONFIG_ATM, GET_WAN_CONFIG_ALL, GET_WAN_CONFIG_ETH or GET_WAN_CONFIG_PTM
        \param[out] num_entries Number of entries in pp_wancfg vector.
        \param[out] pp_wancfg Vector of WAN Config entries
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_all_wan_config(int32 * num_entries, uint32 mode,
			     WAN_CONN_CFG ** pp_wancfg, uint32 flags);

/*! \brief  This MAPI returns operational WAN mode settings in terms of PHY Mode and Transmission Convergence (TC) parameters.
        \param[out] pstWanPhy structure which will have PHY Mode and TC values
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_wan_phy_cfg(WAN_PHY_CFG * pstWanPhy);

/*! \brief  This function is used to set operational WAN mode.
        \param[out] pstWanPhy structure which will have PHY Mode and TC values
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_wan_phy_cfg(WAN_PHY_CFG * pstWanPhy);

/*! \brief  This API sets a WAN Connection on the specified ATM/Ethernet/PTM channel based on the Wan mode specified. It will call different internal APIs for each of the Wan modes.
        \param[in] operation IFX_OP_ADD: Add the WAN connection specified.
                                IFX_OP_DEL: Delete the WAN connection specified.
                                IFX_OP_MOD: Modify the WAN connection specified.
        \param[in] wan_conn_cfg Pointer to wan connection configuration
                                   to be associated with the specified vcc.
        \param[in] flags  Valid combination of SET flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mapi_set_wan_config(int32 operation, WAN_CONN_CFG * wan_conn_cfg,
			      uint32 flags);

/*! \brief  This function is used to get gateway information.
        \param[out] sGW Gateway IP address
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_runtime_gw(char8 * sGW);

/*! \brief  This function is used to get DNS IP addresses.
        \param[out] sDNS DNS Server IP address
        \param[out] nLine Number of DNS Servers.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_get_runtime_dns(char8 * sDNS, char8 * nLine);

/*! \brief  This MAPI returns the stats for interface of the wan connection specified. It operates on device objects wan_ipstats
                    and wan_pppstats. The API searches for a wan connection based on either the input cpeId or input wan_index.
                    One of these two has to be provided from which the function is capable of getting other.\n
                    Based on cpeId and wan_index the API finds out the physical interface name for this wan connection. Also the
                    interface stats for this iface will be returned in the output structure.
        \param[out] iid Pointer to IFX_ID structure
        \param[in] wan_index Index of the WAN connection.
        \param[out] iface Output interface name of the wan connection
        \param[out] if_stats The interface statistics are returned back in this.
        \param[in] flags Currently not used for this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_wan_if_stats(IFX_ID * iid, int32 wan_index, char8 * iface,
			   IF_STATS * if_stats, uint32 flags);

/*! \brief  This function is used to query WAN statistics.
        \param[in] wan_count Number of WAN
        \param[in] iface_stats Statistics Array
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_all_wan_if_stats(int32 * wan_count, IFACE_STATS ** iface_stats,
			       uint32 flags);

#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
/*! \brief  This function is used to configure DSL PHY parameters such as xDSL standard/profile, showtime lock.
        \param[in] pstXdslPhy Structure filled with DSL PHY parameter values
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_xdsl_phy_cfg(XDSL_PHY_CFG * pstXdslPhy);
#endif

/*! \brief  This function is used to set operational WAN mode in dual wan mode.
        \param[out] pstWanPhy structure which will have PHY Mode and TC values
        \param[in] flags  Valid combination of SET flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_wan_phy_cfg_new(WAN_PHY_CFG * pstWanPhy, uint32 flags);

#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
/*! \brief This function is used to get the dual wan configuration information.
		\param[out] dw_attr	Pointer to structure to get the Configured Dual WAN Values.
		\param[in] flags Flags passed
		\return IFX_SUCCESS / IFX_FAILURE
*/
int32 dw_mapi_cfg_get(dw_config_info_t * dw_attr, uint32 flags);

/*! \brief This function is used to set the dual wan configuration information.
		\param[in] oper Set operation Argument - Add, Modify or Delete.
		\param[out] dw_attr	Structure with Dual WAN Values to be set.
		\param[in] flags Flags passed
		\return IFX_SUCCESS / IFX_FAILURE
*/
int32 dw_mapi_cfg_set(uint32 oper, dw_config_info_t * dw_attr, uint32 flags);
#endif //CONFIG_FEATURE_DUAL_WAN_SUPPORT

/*! \brief  This API validates the wan connections before creating new connection.
	\param[in] operation Specifies the operation to be performed IFX_OP_ADD/ IFX_OP_MOD
        \param[in] old_wan_cfg has the values of existing configuration
	\param[in] new_wan_cfg has the new value to be ADDED/MODIFIED in WAN configuration
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 mapi_validate_wanconfig( int32 operation , WAN_CONN_CFG * old_wan_cfg, WAN_CONN_CFG * new_wan_cfg);

#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
/*! \brief  This function is used to set vcchannel detected during auto detect to rc.conf.
        \param[in] wan_mode selected wan mode.
        \param[in] vpivci vpi/vci detected during auto detect.
				\return IFX_SUCCESS / IFX_FAILURE
*/
int32 Update_vcchannel_config(int32 wan_mode,char8 * vpivci);

/*! \brief  This function is used to set vlan detected during auto detect to rc.conf.
        \param[in] wan_mode selected wan mode.
        \param[in] vlan detected vlan during auto detect.
				\return IFX_SUCCESS / IFX_FAILURE
*/
int32 Update_vlan_config(int32 wan_mode,char8 *vlan);

/*! \brief  This function is used to set wan type detected during auto detect to rc.conf.
        \param[in] wan_mode selected wan mode.
        \param[in] wantype detected wan type during auto detect.
				\return IFX_SUCCESS / IFX_FAILURE
*/
int32 Update_wan_config(int32 wan_mode, char8 *wantype);

/*! \brief  This function is used to disable L2 and L3 auto detect on the basis of wan mode provided.
        \param[in] wanMode selected wan mode.
				\return IFX_SUCCESS / IFX_FAILURE
*/
int32 mapi_autodetect_disable_for_wanmode(WAN_MODE wanMode);

/*! \brief  This function is used to notify if tr69 value changed.
        \param[in] iid
				\return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_tr69_value_change_notify(IFX_ID * iid);

/*! \brief  This function is used to get auto detect configuration from rc.conf.
        \param[in] config store auto detect configuration.
				\return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_get_autodetect_config(auto_detect_cfg_t *config);

/*! \brief  This function is used to set auto detect configuration for all wan mode to rc.conf .
        \param[in] config store auto detect configuration.
        \param[in] flags  Valid combination of SET flags.
				\return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_set_autodetect_config(auto_detect_cfg_t *config, uint32 flags);

/*! \brief This function is used to get runtime status of WAN auto-detect as enabled/disabled.
	\param[in] wanMode WAN mode for which status has to be retrieved.
	\return IFX_SUCCESS / IFX_FAILURE
*/
int32 is_auto_detect_enabled(WAN_MODE wanMode);
#endif

/*! \brief  This MAPI computes WAN MODE for WAN PHY and WAN TC Passed.
        \param[in] phy WAN PHY configured.
        \param[in] tc  WAN TC  configured.
        \return WAN MODE configured for passed "phy" an "tc".
*/
int32 compute_wan_mode(WAN_PHY_MODE phy, WAN_TC tc);

#if defined CONFIG_FEATURE_ADSL_WAN_SUPPORT || defined CONFIG_FEATURE_PTM_WAN_SUPPORT
/*! \brief  This API retrieves the L2 details of WAN specified by IID
        \param[in] iid	IID of L3 for which L2 details have to be retrieved.
        \param[out] vc				VC channel entry for specified WAN IID as applicable.
        \param[out] vlan_cfg	VLAN channel entry for specified WAN IID as applicable.
        \return IFX_SUCCESS or IFX_FAILURE
*/
int32 mapi_default_wan_l2_get(IFX_ID iid, ATM_VCC_INFO *vc, vlan_ch_cfg_t *vlan_cfg);
#endif

/*! \brief  This API retrieves the default WAN instance details of current WAN mode
        \param[out] wanCfg			pointer to default WAN instance of current WAN mode
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS or IFX_FAILURE
*/
int32 mapi_default_wan_details_get(WAN_CONN_CFG *wanCfg, uint32 flags);

/*! \brief  This API retrieves default WAN instance details for the passed WAN mode.
        \param[out] def_wan_cfg default WAN instance structure.
        \param[in] wan_phy WAN phy configuration - to derive WAN mode for which default WAN needs to be found.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 default_wan_cfg_get_for_wan_phymode(def_wan_cfg_t * def_wan_cfg,
					  WAN_PHY_CFG * wan_phy);

/*! \brief  This API retrieves current WAN mode.
        \param[in] flags Caller can specify any or set of flags defined for GET operations.
        \return WAN mode value on success / IFX_FAILURE
*/
int32 global_wan_mode_get(uint32 flags);

/*! \brief  This API retrieves WAN connection device instance details
						based on VLAN instance configured below it.
        \param[in] vlan_cpeid ID details of VLAN instance.
        \param[out] wcd_cpeid ID details of WAN connection device instance.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 mapi_get_wcd_from_vlan(int32 vlan_cpeid, int32 * wcd_cpeid);

/*! \brief  This API retrieves VC (VPI/VCI) value for given WAN connection configured on it.
        \param[in] iid ID details of WAN connection instance.
        \param[out] vc VC (VPI/VCI) value.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 vcc_get_from_wan_iid(IFX_ID *iid, char8 *vc);

/*! \brief  This API retrieves VLAN value of VLAN channel instance for given WAN connection configured on it.
        \param[in] iid ID details of WAN connection instance
        \param[out] vlanId VLAN value.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 vlan_get_from_wan_iid(IFX_ID *iid, int32 *vlanId);

/*! \brief  This API retrieves ATM link type value of VC channel for given WAN connection configured on it.
        \param[in] iid ID details of WAN connection instance.
        \param[out] linkType ATM link type value.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 link_type_get_from_wan_iid(IFX_ID *iid, int32 *linkType);

/*! \brief  This API retrieves ATM link type value of VC channel for given WAN connection configured on it.
        \param[in] wanIdx Index of WAN connection (> 0)
        \param[in] wanType WAN type (refer enum WAN_TYPE)
        \param[out] linkType ATM link type value
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 link_type_get_from_wan_index(int32 wanIdx, WAN_TYPE wanType, int32 *linkType);

/*! \brief  This API retrieves ATM encapsulation mode value of VC channel for given WAN connection configured on it
        \param[in] iid ID details of WAN connection instance.
        \param[out] encap ATM encapsulation mode value.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 encap_get_from_wan_iid(IFX_ID *iid, int32 *encap);

/*! \brief  This API retrieves all WAN connections into array pp_wancfg.
						Also the number of WAN connections read will be returned in num_entries.
        \param[out] num_entries Number of entries
        \param[out] pp_wancfg Array of WAN connections retrieved
        \param[in] flags Caller can specify any or set of flags defined for GET operations.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_all_wan(int32 * num_entries, WAN_CONN_CFG ** pp_wancfg, uint32 flags);

/*! \brief  This API retrieves ATM link type configured for given WAN interface
        \param[in] iface WAN interface
        \return ATM link type if success / IFX_FAILURE
*/
int32 get_link_type_based_on_l2if(char8 *iface);

/*! \brief  This API retrieves IP address, subnet mask, status values related of WAN connection
            identified by index and type given.
        \param[in] wanIdx Index of WAN connection ( > 0)
        \param[in] wanType WAN type (refer enum WAN_TYPE)
        \param[out] wanIp IP address of WAN connection matching to input given.
        \param[out] wanMask Subnet mask address of WAN connection matching to input given.
        \param[out] wanGW Gateway address of WAN connection matching to input given.
        \param[out] wanStatus Status of WAN connection matching to input given.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 wan_tuple_get(int32 wanIdx, WAN_TYPE wanType, char8 *wanIp, char8 *wanMask, char8 *wanGW, char8 *wanStatus);

	 /* @} *//*WAN   */

/** \ingroup FUNC_DEV_MAPI
        \defgroup VLAN_OBJ VLAN
       \brief The VLAN objects related MAPIs are described in this section.
*/
/* @{ */


/*! \brief  This API retrieves all vlan channel entries.
        \param[out] num_entries Number of entries
        \param[out] vlan_chcfg vlan channel entries.
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 mapi_get_all_vlan_ch_entries(int32 * num_entries,
				   vlan_ch_cfg_t ** vlan_chcfg, uint32 flags);

/*! \brief  This API retrieves vlan channel with respect to the index value passed.
        \param[in] vlanIdx of vlan channel config to be retrieved.
        \param[out] vlan_chcfg vlan channel entry.
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 mapi_get_vlan_ch_entry(int32 vlanIdx, vlan_ch_cfg_t * vlan_chcfg,
                                     uint32 flags);

/*! \brief  This API configures vlan channel section according to values passed.
        \param[in] operation flag .
        \param[in] entry vlan channel entry.
        \param[in] flags  Valid combination of SET flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int mapi_set_vlan_ch_entry(int32 operation, vlan_ch_cfg_t * entry,
			   uint32 flags);

/*! \brief  This API retrieves all vlan channel entries related to particular layer two channel.
        \param[out] num_entries Number of entries
        \param[out] vlan_chcfg vlan channel entries.
	\param[in] iid IID of object.
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 mapi_get_all_vlan_ch_entries_for_l2ch(int32 *num_entries,  vlan_ch_cfg_t **vlan_chcfg, IFX_ID *iid,uint32 flags);

/*! \brief  This API retrieves vcc on top of which the vlan channel is configures.
        \param[in] cpeId CPE Id of object.
        \param[out] vcc vcc value.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 get_vcc_for_vlan_ch(CPE_ID cpeId, char8 *vcc);

	/* @} *//*VLAN   */

/** \ingroup FUNC_DEV_MAPI
        \defgroup DHCP_OBJ DHCP
       \brief The LAN DHCP objects related MAPIs are described in this section.
*/
/* @{ */

/*! \brief  This function is used to set the DHCP Static IP Reservation entry in configuration file.
        \param[in] operation Type of operation
        \param[in] p_dhcp_info structure containing DHCP static lease configuration values
        \param[in] flags  Valid combination of SET flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_dhcps_static_lease(int32 operation,
				 IFX_MAPI_DHCPS_STATIC_LEASE * p_dhcp_info,
				 uint32 flags);

/*! \brief  This function is used to get the DHCP Static IP Reservation entry from configuration file.
        \param[out] pp_dhcp_info Structure for fetching particular DHCP static lease configuration values
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_dhcps_static_lease(IFX_MAPI_DHCPS_STATIC_LEASE * pp_dhcp_info,
				 uint32 flags);

/*! \brief  This function is used to get the DHCP Static IP Reservation Values for all entries from configuration file.
        \param[in] num_entries number of DHCP static lease entries
        \param[out] pp_dhcp_info Structure containing all DHCP statuc lease configuration entries
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE

*/
int32 ifx_get_all_dhcps_static_lease(int32 * num_entries,
				     IFX_MAPI_DHCPS_STATIC_LEASE **
				     pp_dhcp_info, uint32 flags);

/*! \brief  This MAPI sets the DHCP server configuration. This API takes the DHCP server information to be configured in
                    the DHCP_SERVER_INFO structure and performs as per the operation argument and SET flags.\n
                    Since the system has currently limitation to support only one LAN interface, the only operation supported is
                    MODIFY. For Modify operation, the API first stops the LAN services using the current configuration. Once the new
                    configuration is updated in rc.conf, LAN services will be re-started. The LAN service start script will call the service
                    script udhcpd_start which will start the dhcp server service based on the updated configuration. Also if
                    hostname is specified, which is optional, this will call the system call to set the new hostname.
        \param[in] op Operation specifies addition
                            (IFX_OP_ADD), deletion
                            (IFX_OP_DEL) or modification
                            (IFX_OP_MOD). The only supported
                            value as of now is IFX_OP_MOD.
        \param[in] dhcps_info This parameter provides the DHCP
                            server configuration information.
        \param[in] flags Valid set of possible SET flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_lan_dhcp_server_config(int32 op, DHCP_SERVER_INFO * dhcps_info,
				     uint32 flags);

/*! \brief  This API takes the DHCP relay information as DHCP_RELAY_SERVER structure and acts as per operation
                    argument. At present it is assumed to have only single Relay Server and hence this API supports Modify operation
                    only. The API first stops the LAN services using the current configuration. Once the new configuration is updated
                    in rc.conf, LAN services will be started. The LAN service start script will call the service script udhcpr which will
                    start the DHCP relay service based on the updated configuration. The API takes the wan interface name on which
                    dhcp relay should be run. If not specified the API will take the default wan interface to run the dhcp relay. Before
                    starting the relay service it also checks if the wan interface specified exists and up.
        \param[in] op IFX_OP_MOD only supported.
        \param[in] dhcps The dhcp relay information for modification.
        \param[in] flags SET operation flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_dhcpr_dhcp_server(int32 op, DHCP_RELAY_SERVER * dhcps,
				uint32 flags);

/*! \brief  This API sets the DHCP operation mode. It can be set as DHCP Server mode, DHCP Relay mode or Disabled.
        \param[in] mode Sets the DHCP operation mode.
                                    IFX_DISABLED: Disabled
                                    IFX_DHCP_SERVER_MODE: DHCP Server
                                    IFX_DHCP_RELAY_MODE: DHCP Relay
        \param[in] flags Unused argument.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_dhcp_server_mode(int32 mode, uint32 flags);

/*! \brief  This function is used to set DHCP option.
        \param[in] operation Set Action Argument - Add, Modify or Delete.
        \param[in] dhcp_option DHCP Option Object
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_dhcp_option(uint32 operation, DHCP_OPTION * dhcp_option,
			  uint32 flags);

/*! \brief  This MAPI returns the DHCP Server related information. It must get CPE-Id to get specific instance information. It
                    reads the dhcp server information from rc.conf file and returns it as a pointer.
        \param[in,out] dhcps_info DHCP Server configuration to be retrieved with id part filled in by caller.
        \param[in] flags Any of state flags for getting entries of specified state.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_lan_dhcp_server_config(DHCP_SERVER_INFO * dhcps_info,
				     uint32 flags);

/*! \brief  This function is used to.
        \param[in,out] dhcpr_info DHCP Relay configuration to be retrieved with id part filled-in by caller.
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API
        \return IFX_SUCCESS / IFX_FAILURE / IFX_E_INT_ERROR / IFX_E_SEC_NOT_FOUND
*/
int32 ifx_get_dhcp_relay_config(DHCP_RELAY_INFO * dhcpr_info, uint32 flags);

/*! \brief  This function returns the DHCP server lease information. It gets the information about each of the offered leases
        by executing the dumpleases command and stores them in the output array lease_entries.
        \param[out] num_leases This is set to the number of DHCP leases served by the DHCP server.
        \param[out] lease_entries Lease_entries is the allocated array of
                                DHCP_LEASE_INFO returned by the function. Caller must free the memory allocated after it has used it.
        \param[in] flags Unused.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_lan_dhcp_leases(int32 * num_leases,
			      DHCP_LEASE_INFO ** lease_entries, uint32 flags);

/*! \brief  This function returns the mode information of whether DHCP server or relay is enabled on LAN Interface. The
                    assumption made here is only one LAN IP Interface exists in system and hence the API returns the current dhcp
                    mode of the first LAN IP Interface.
        \param[in] flags Not used currently.
        \return Any of the following if success: IFX_DHCP_SERVER_MODE, IFX_DHCP_RELAY_MODE or IFX_DISABLED.
                       IFX_FAILURE - if failure
*/
int32 ifx_get_dhcp_server_mode(uint32 flags);

/*! \brief  This helper function queries whether DHCP Server is supported in system. This is based on compile time flag
                    IFX_CONFIG_DHCP_SEVER. If the build is made with this compilation flag, DHCP Server is supported in system.
        \param[in] flags Currently unused.
        \return IFX_SUPPORTED - if DHCP Server is supported in system through compile-time option.
                     IFX_NOT_SUPPORTED - if DHCP Server is not supported in system.
*/
int32 ifx_get_dhcp_server_module_support(uint32 flags);

/*! \brief  	This function executes the command to get number of DHCP clients and returns to the caller.
        \param[in] file Leases file for which number of DHCP leases to be found
        \param[out] clients Number of DHCP leases returned
*/
int32 ifx_read_dhcp_lease_file(const char *file, int *clients);

/*! \brief  This function gets the current number of DHCP clients active for the DHCP Server in system.
        \param[in] flags Currently unused.
        \return Number of DHCP Clients. (It is Zero or Positive Number) - For Successful operation / IFX_FAILURE
        \note Invokes command dumpleases to get information about all DHCP clients.
*/
int32 ifx_get_num_dhcp_clients(uint32 flags);

/*! \brief  This function is used to query all supported DHCP options.
        \param[out] numEntries Number of entries returned in MAPI.
        \param[out] dhcp_option pointer to array of DHCP options.
        \param[in] flags Filter GET flag.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_all_dhcp_option(int32 * numEntries, DHCP_OPTION ** dhcp_option,
			      uint32 flags);

/*! \brief  This function is used to query a specific DHCP option.
        \param[in,out] dhcp_option instance containing identifier of object.
        \param[in] flags Filter GET flag.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_dhcp_option(DHCP_OPTION * dhcp_option, uint32 flags);

/*! \brief  This function is used to query number of DHCP options configured.
        \param[out] count Number of DHCP options configured.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_dhcp_option_count(uint32 * count);

/*! \brief  This function is used to get all DHCP Conditional Sevring instances.
        \param[out] p_num_entries Number of DHCP Conditional Serving Entries
        \param[out] pp_dhcp_info DHCP Conditioonal Serving Pool Entries Vector
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_all_dhcp_conditional_entries(int32 * p_num_entries,
					   IFX_DHCP_COND_SERV_POOL **
					   pp_dhcp_info, uint32 flags);

/*! \brief  This function is used to set DHCP Conditional Serving Pool.
        \param[in] oper Type of action - Add, Modify or Delete.
        \param[in] p_dhcp_info DHCP Conditional Serving Pool Info
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_dhcp_conditional_entry(int32 oper,
				     IFX_DHCP_COND_SERV_POOL * p_dhcp_info,
				     uint32 flags);

	 /* @} *//* DHCP  */

/** \ingroup FUNC_DEV_MAPI
        \defgroup SYSTEM_OBJ System
       \brief The System objects related MAPIs are described in this section.
*/
/* @{ */

/*! \brief  This function is used to query all the lan host connected to the CPE.
        \param[out] numHost Number of DHCP Conditional Serving Entries
        \param[out] ipHost is the allocated array of LTQ_MAPI_LAN_IP_Host returned by the function.Caller must free the memory after it has used it.
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_get_all_lan_ip_host(uint32 * numHost,
				   LTQ_MAPI_LAN_IP_Host ** ipHost,
				   uint32 flags);

/*! \brief  This function is used to get remote access details.
        \param[out] rt_access Structure filled with remote access configuration
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 mapi_remote_access_details_get(remote_access_t *rt_access, uint32 flags);

/*! \brief  This function is used to set remote access details.
        \param[in] rt_access Contains the remote access configuration
        \param[in] flags  Valid combination of SET flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 mapi_remote_access_details_set(remote_access_t *rt_access, uint32 flags);

/*! \brief  This function is used to get user object details.
        \param[out] usrobj Structure filled with user object configuration requested
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 mapi_user_obj_details_get(user_obj_t *usrobj, uint32 flags);

/*! \brief  This function is used to set user object details.
        \param[in] operation Type of operation
        \param[in] usrobj Contains the user object configuration
        \param[in] flags  Valid combination of SET flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 mapi_user_obj_details_set(int32 operation, user_obj_t *usrobj, uint32 flags);

/*! \brief  This function is used to get all user object details.
        \param[out] user_count Number of users
        \param[out] user_obj Configuration of all users under user object
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 mapi_get_all_user_obj_details(int32 *user_count, user_obj_t **user_obj, uint32 flags);

/*! \brief  This function is used to get syslog message.
        \param[in] num_lines No. of lines of syslogged message
        \param[in] filename SysLog File Name
        \param[out] buf Buffer carrying log lines.
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_syslog_msg(int num_lines, char *filename, char8 ** buf,
			 uint32 flags);

/*! \brief  This API reads the syslogd settings in system.
        \param[out] sys_log SysLog Settings
        \param[in] flags  Valid combination of SET flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_syslog_info(SYSLOG_INFO * sys_log, uint32 flags);

/*! \brief  This API retrieves the logs in specified filter level.
        \param[in] log_level Logging Level
        \param[out] sys_log syslog settings
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_syslog_info_filter(SYSLOG_DISP_LEVEL log_level,
				 SYSLOG_INFO * sys_log, uint32 flags);

/*! \brief  This API sets the syslogd settings in system.
        \param[in] operation Only allowed operation is MODIFY.
        \param[in] syslog Syslog Settings
        \param[in] flags  Valid combination of SET flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_syslog_info(int32 operation, SYSLOG_INFO * syslog, uint32 flags);

/*! \brief  This function queries the NTP configured values.
        \param[in] ntpC NTP Client configuration
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_ntp_client_cfg(NTP_CLIENT_CFG * ntpC, uint32 flags);

/*! \brief  This API sets the NTP client configuration parameters such as NTP Server addresses (Primary and Secondary).
        \param[in] operation Type of SET operation
        \param[in] ntpC NTP Client configuration
        \param[in] flags  Valid combination of SET flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_ntp_client_cfg(int32 operation, NTP_CLIENT_CFG * ntpC,
			     uint32 flags);

	 /* @} *//*SYSTEM */

/** \ingroup FUNC_DEV_MAPI
        \defgroup TR69_OBJ TR-069
       \brief This section describes the MAPIs pertinent to TR-069 requirements of DevM. The names of such functions
 are
suffixed to _wrapper as the actual functions come from DevM package.
here.
*/
/* @{ */

/*! \brief  This function is used to get details of the parameters under Management Server object.
        \param[out] mgmt_server contains details of the parameters under Management Server object.
        \param[in] flags Flags 
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_get_mgmt_server(MGMT_SERVER * mgmt_server, uint32 flags);

/*! \brief  This function is used to get IP-Ping Diagnostics.
        \param[out] ipping_diag IP-Ping Diagnostics
        \param[in] flags  Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_ipping_diag_wrapper(IPPING_DIAG * ipping_diag, uint32 flags);

//IPv6
/*! \brief  This function is used to get IP Protocol version.
        \param[out] ver Version
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_ipprotver(char8 * ver);

/*! \brief  This function is used to set IP Protocol version.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_ipprotver();

/*! \brief  This function is used to set IP Protocol version mode.
        \param[out] ipprot_ver mode or IP Protocol 
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_x_ltq_ipprotocolversion_mode(X_LTQ_IPPROTOCOLVERSION * ipprot_ver,
                                           uint32 flags);

/*! \brief  This function is used to set IP Protocol version mode to IPv6.
        \param[in] status
        \param[in] ipprotver Version of IP Protocol
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_ipprot_ver_set_ipv6(int32 status, char8 * ipprotver);

/*! \brief  This function is used to get current configuration file in the CPE.
        \param[out] configfile Current configuration in encrypted form.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_configfile(char8 *configfile);

/*! \brief  This function is used to set current configuration file in the CPE.
        \param[in] configfile Current configuration in encrypted form.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_configfile(char8 *configfile);



/* VendorConfigFile */
/*! \brief  This function is used to set details of the vendor config file.
        \param[in] conf_file structure of type VEND_CONF_FILE.
        \param[in] operation Operation
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_vend_conf_file(int32 operation, VEND_CONF_FILE *conf_file, uint32 flags);

/*! \brief  This function is used to get details of the vendor config file.
        \param[in] conf_file structure of type VEND_CONF_FILE.
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_vend_conf_file(VEND_CONF_FILE *conf_file, uint32 flags);


// MEMORYSTATUS
/*! \brief  This function is used to get Memory Status.
        \param[out] memstat Status of system memory
        \param[in]  memstat blank structure
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_memorystatus(MEMORYSTATUS * memstat);


// PROCESSSTATUS
/*! \brief  This function is used to get Process Status.
        \param[out] procstat details of number of processes running
        \param[in] procstat blank structure
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_processstatus(PROCESSSTATUS * procstat);

/*! \brief  This function is used to get details of running Processes.
        \param[out] proc details of individual processes running 
        \param[in] proc blank structure
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_process(PROCESS * proc);

//NSLOOKUP
/*! \brief  This function is used to get NSLookUp Diagnostics.
        \param[out] nslookup_diag details of NSLookUp test
        \param[in] nslookup_diag blank structure
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_nslookup_diag(NSLOOKUP_DIAG * nslookup_diag);

/*! \brief  This function is used to set NSLookUp Diagnostics.
        \param[in] nslookup_diag details of NSLookUp test
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_nslookup_diag(NSLOOKUP_DIAG * nslookup_diag, uint32 flags);

/*! \brief  This function is used to get results NSLookUp Diagnostics test.
        \param[out] result details of the result of the nslookup diagnostics
        \param[in] result blank structure pointer
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_result(RESULT * result);

/*! \brief  This function is used to set results NSLookUp Diagnostics test.
        \param[in] result details of the result of the nslookup diagnostics
        \param[in] operation Set Operartion
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_result(int32 operation, RESULT * result, uint32 flags);
/*! \brief  This function is used to cleanup Result from tr69_maps sections.
            \return IFX_SUCCESS / IFX_FAILURE
    */

int32 ifx_cleanup_nslookup_tr69_maps(void);

/*! \brief  This function is used to cleanup Result from tr69_instances sections.
            \return IFX_SUCCESS / IFX_FAILURE
    */

int32 ifx_cleanup_nslookup_tr69_instances(void);

/*! \brief  This function is used to reset nslookup_result_nextCpeId
            \return IFX_SUCCESS / IFX_FAILURE
    */

int32 ifx_reset_nslookup_next_cpeid(void);

/*! \brief  This function cancels a queued download.
        \param[in] caCmdKey[32] CommandKey of the download to be cancelled.
        \param[out] xQD blank structure
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_cancel_downloads(char caCmdKey[32] , QUEUED_DOWNLOAD_STRUCT *QD);

/*! \brief  This function cancels a queued upload.
        \param[in] caCmdKey[32] CommandKey of the upload to be cancelled.
        \param[out] xQD blank structure
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_cancel_uploads(char caCmdKey[32] , QUEUED_DOWNLOAD_STRUCT *QD);


/*! \brief This mapi gets the ConfigFile version after a DownloadRPC.
*/

int32 ifx_get_cfgfile_version(char *version);

/*! \brief  This MAPI queries the current parameter values of mgmt_server device object.
        \param[out] mgmt_server Parameters info of Management Server
                        comes back filled, upon successful execution.
        \param[in] flags Get supported filter flag.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_mgmt_server_wrapper(MGMT_SERVER * mgmt_server, uint32 flags);

/*! \brief  This function is used to get the self diagnostics status of each test result
            \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ltq_mapi_get_diagnostics_status(DIAGNOSTICS_TEST_SUITE * diag_test_suite, uint32 flags);

/*! \brief  This function is used to set the self diagnostics result
            \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ltq_mapi_set_diagnostics_status(DIAGNOSTICS_TEST_SUITE * diag_test_suite, uint32 flags);

/*! \brief  This function is used to perform self diagnostics test
            \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ltq_mapi_performtest(DIAGNOSTICS_TEST_SUITE * pxDiagTestQuery);

/*! \brief  This API function is used to ping given IP address
        \param[in] IP_Address ping time out in microseconds and no.of ping tries
        \return IFX_SUCCESS / IFX_FAILURE
*/

int ping_ipaddress(char *address, uint32 timeout, int num_ping);

/*! \brief  This API function is used to get DNS IP address
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ltq_api_get_dns_ip(char * dns1, char *dns2);

/*! \brief  This function is used to Get TraceRoute Diagnostics details.
        \param[in] traceroute_diag blank structure
        \param[out] traceroute_diag details of the TraceRoute test
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_traceroute_diag(TRACEROUTE_DIAG * traceroute_diag);

/*! \brief  This MAPI queries the current parameter values of traceroute diagnostics routehops object.
            \param[out] route_hops Parameters of traceroute diagnostics routehops
                            comes back filled, upon successful execution.
            \return IFX_SUCCESS / IFX_FAILURE
    */

int32 ifx_get_routehops(ROUTE_HOPS * route_hops);

/*! \brief  This function is used to set Download Diagnostics details.
        \param[in] download_diag details of the DowloadDiagnostics test
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_download_diag(DOWNLOAD_DIAG * download_diag, uint32 flags);

/*! \brief  This function is used to get Download Diagnostics details.
        \param[out] download_diag will contain the details of the download test
        \param[in] download_diag blank structure
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_get_download_diag(DOWNLOAD_DIAG * download_diag);

/*! \brief  This function is used to set Upload Diagnostics details.
        \param[in] upload_diag details of Upload Diagnostics test
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_upload_diag(UPLOAD_DIAG * upload_diag, uint32 flags);

/*! \brief  This function is used to get Upload Diagnostics details.
        \param[in] upload_diag blank structure
        \param[out] upload_diag details of the UploadDiagnostics test
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_get_upload_diag(UPLOAD_DIAG * upload_diag);

/*! \brief  This function gets the details of the next pending download.
        \param[out] xQD contains details of next pending download
        \param[in] xQD blank structure
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_get_next_download(QUEUED_DOWNLOAD_STRUCT *xQD);

/*! \brief  This function resets to default the details of the current download
            in case of a failure.
        \param[in] iIdx Index of entry to be reset
        \param[in] iFlags Flags for the operations
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ltq_reset_download(int32 iIdx, int32 iFlags);

/*! \brief  This function sets the details of the queued download.
        \param[out] Time Future time of the next download
        \param[in] download_params details of the Download to be performed
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_download(char download_params[10][256] , int32 Time, int32 * curr_index);

/*! \brief  This function validates the parameters of the Download Request.
        \param[in] xTime Time of the Download request just received
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_validate_download(int xTime);

/*! \brief  This function updates the section for queued download.
        \param[in] status Status of the download
        \param[in] iStatusFlag flag
        \param[in] StartTime of the download
        \param[in] EndTime of the Download
        \param[in] iIsComplete whether download is complete or not
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_update_download(int status , char *StartTime, char *EndTime , int iIsComplete , int iStatusFlag);


// SCHEDULED_DOWNLOAD
/*! \brief  This function validates the parameters of the ScheduleDownload Request.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_validate_schedule_download();

/*! \brief  This function sets the details of the schedule download.
        \param[in] xTime Future time of the next download
        \param[in] download_params details of the Download to be performed
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_schedule_download(char download_params[17][256] ,int32 xTime);

/*! \brief  This function gets the details of the next pending schedule download.
        \param[out] xSD contains details of next pending download
        \param[in] xSD blank structure
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_next_schedule_download(SCHEDULE_DOWNLOAD_STRUCT *xSD);

/*! \brief  This function updates the section for schedule download.
        \param[in] status Status of the download
        \param[in] iStatusFlag flag
        \param[in] StartTime of the download
        \param[in] EndTime of the Download
        \param[in] iIsComplete whether download is complete or not
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_update_schedule_download(int status , char *StartTime, char *EndTime , int iIsComplete ,int iStatusFlag);

/*! \brief  This function cancels a schedule download.
        \param[in] caCmdKey[32] CommandKey of the download to be cancelled.
        \param[out] xSD blank structure
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_cancel_schedule_downloads(char caCmdKey[32] , SCHEDULE_DOWNLOAD_STRUCT *xSD);

/*! \brief  This function gets the details of the schedule download.
        \param[out] xSD contains details of next pending download
        \param[in] xSD blank structure
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_sdl_info(SCHEDULE_DOWNLOAD_STRUCT *xSD);

/*! \brief  This function saves the details of the schedule download post download.
        \param[in] sdl_params details of the Download just performed
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_sdl_info(char sdl_params[7][256]);

// QUEUED_UPLOAD

/*! \brief  This function gets the details of the next pending upload.
        \param[out] xQU contains details of next pending upload 
        \param[in] xQU blank structure
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_next_upload(QUEUED_DOWNLOAD_STRUCT *xQU);

/*! \brief  This function sets the details of the queued upload.
        \param[out] xTime Time of thenext upload
        \param[in] upload_params details of the Upload to be performed
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_upload(char upload_params[10][256] ,int32 xTime);

/*! \brief  This function validates the parameters of the Upload Request.
        \param[in] xTime time of the Upload Request just received
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_validate_upload(int xTime);

/*! \brief  This function updates the section for queued upload.
        \param[in] status
        \param[in]  iStatusFlag Status flag
        \param[in] StartTime of the Upload
        \param[in] EndTime of the Upload
        \param[in] iIsComplete whether upload is complete or not
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_update_upload(int status , char *StartTime, char *EndTime , int iIsComplete , int iStatusFlag );


// QUEUEDTRANSFER
/*! \brief  This function gets the values for queued transfers.
        \param[out] xaTL will contain the details of the queued transfers
        \param[in] xaTL blank structure
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 get_all_queued_transfers(TRANSFER_LIST *xaTL);


/*! \brief  This function is used to get Download Authentication details.
        \param[out] dl_auth Download Authentication
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_dl_auth(DL_AUTH * dl_auth, uint32 flags);

/*! \brief  This function is used to get TR-069 Authentication information.
        \param[out] tr69_auth TR-069 Authentication information
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_get_tr69_auth(TR69_AUTH * tr69_auth, uint32 flags);

/*! \brief  This function is used to get miscellaeneous information about TR-069.
        \param[out] tr69_misc TR-069 Miscellaneous information
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_tr69_misc(TR69_MISC * tr69_misc, uint32 flags);

/*! \brief  This function is used to get Download authentication information wrapper.
        \param[out] dl_auth Download authentication.
        \param[in] flags Get flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_dl_auth_wrapper(DL_AUTH * dl_auth, uint32 flags);

/*! \brief  This function is used to get TR-069 Authentication information wrapper..
        \param[out] tr69_auth TR-069 Authentication information
        \param[in] flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_tr69_auth_wrapper(TR69_AUTH * tr69_auth, uint32 flags);

/*! \brief  This function is used to get TR-069 Miscellaneous information wrapper.
        \param[out] tr69_misc TR-069 Miscellaneous Information
        \param[in] flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_tr69_misc_wrapper(TR69_MISC * tr69_misc, uint32 flags);

/*! \brief  This function is used to configure management server.
        \param[in] operation Set Operation - Add, Modify or Delete.
        \param[in] mgmt_server management server
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_mgmt_server(int32 operation, MGMT_SERVER * mgmt_server,
			  uint32 flags);

/*! \brief  This MAPI does a SET type of operation on device_info Object.
        \param[in] operation Type of Operation
        \param[in] dev_info Device_Info configuration parameters
        \param[in] flags Valid combination of SET type of flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_device_info(int32 operation, DEVICE_INFO * dev_info,
			  uint32 flags);

/*! \brief  This function is used to set IP-Ping Diagnostics.
        \param[in] operation Set Operation - Add, Modify or Delete.
        \param[in] ipping_diag IP-Ping Diagnostics
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_ipping_diag(int32 operation, IPPING_DIAG * ipping_diag,
			  uint32 flags);

/*! \brief  This MAPI does a SET type of operation on mgmt_server device object.
        \param[in] operation Type of Operation.
        \param[in] mgmt_server Management Server Id and Configuration information.
        \param[in] flags Valid combination of SET type of flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_mgmt_server_wrapper(int32 operation, MGMT_SERVER * mgmt_server,
				  uint32 flags);

/*! \brief  This function is used to configure device information.
        \param[in] operation Set Operation - Add, Modify or Delete.
        \param[in] dev_info Device information
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_device_info_wrapper(int32 operation, DEVICE_INFO * dev_info,
				  uint32 flags);

/*! \brief  This function is used to set IP-Ping Diagnostics.
        \param[in] operation Set Operation - Add, Modify or Delete.
        \param[in] ipping_diag IP-Ping Diagnostics
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_ipping_diag_wrapper(int32 operation, IPPING_DIAG * ipping_diag,
                                  uint32 flags);
/*! \brief  This function is used to set Traceroute Diagnostics.
          \param[in] traceroute_diag Traceroute Diagnostics parameters
          \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
          \return IFX_SUCCESS / IFX_FAILURE
  */

int32 ifx_set_traceroute_diag(TRACEROUTE_DIAG * traceroute_diag, uint32 flags);

/*! \brief  This function is used to set Traceroute Diagnostics RouteHops.
            \param[in] operation Set Operation - Add, Modify or Delete.
            \param[in] route_hops Traceroute Diagnostics Route Hops parameters
            \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
            \return IFX_SUCCESS / IFX_FAILURE
    */

int32 ifx_set_routehops(int32 operation, ROUTE_HOPS * route_hops, uint32 flags);

/*! \brief  This function is used to cleanup RouteHops from tr69_maps sections.
            \return IFX_SUCCESS / IFX_FAILURE
    */

int32 ifx_cleanup_traceroute_tr69_maps(void);

/*! \brief  This function is used to cleanup RouteHops from tr69_instances sections.
            \return IFX_SUCCESS / IFX_FAILURE
    */

int32 ifx_cleanup_traceroute_tr69_instances(void);

/*! \brief  This function is used to reset traceroute_routehops_nextCpeId
            \return IFX_SUCCESS / IFX_FAILURE
    */

int32 ifx_reset_traceroute_next_cpeid(void);

/*! \brief  This function is used to set Download Authentication.
        \param[in] operation Set Operation - Add, Modify or Delete.
        \param[in] dl_auth Download Authentication
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_dl_auth(int32 operation, DL_AUTH * dl_auth, uint32 flags);

/*! \brief  This function is used to set TR-069 Authentication.
        \param[in] operation Set Operation - Add, Modify or Delete.
        \param[in] tr69_auth TR-069 Authentication
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_tr69_auth(int32 operation, TR69_AUTH * tr69_auth, uint32 flags);

/*! \brief  This function is used to set TR-069 Miscellaneous information.
        \param[in] operation Set Action Argument - Add, Modify or Delete.
        \param[in] tr69_misc TR-069 Miscellaneous information
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_tr69_misc(int32 operation, TR69_MISC * tr69_misc, uint32 flags);

/*! \brief  This function is used to configure Download Authentication wrapper function.
        \param[in] operation Set Action Argument - Add, Modify or Delete.
        \param[in] dl_auth Downlaod Authentication information
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_dl_auth_wrapper(int32 operation, DL_AUTH * dl_auth, uint32 flags);

/*! \brief  This function is used to set TR-069 Authentication information wrapper.
        \param[in] operation Set Action Argument - Add, Modify or Delete.
        \param[in] tr69_auth TR-069 Authentication
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_tr69_auth_wrapper(int32 operation, TR69_AUTH * tr69_auth,
				uint32 flags);

/*! \brief  This functional API sets TR-069 miscellaneous parameters. This can be called from web as well.
        \param[in] operation Set operation type.
        \param[out] tr69_misc TR-069 miscellaneous information
        \param[in] flags SET flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_tr69_misc_wrapper(int32 operation, TR69_MISC * tr69_misc,
				uint32 flags);

/*! \brief  This function is used for handling events by TR-069 application.
        \param[in] evtType Event Type
        \param[in] evtState Event State
        \param[in] iid Ifx Identifier
	\param[in] count Number of Field-Value Pairs.
	\param[in] array_fvp Array of Field-Value Pairs.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_tr69_event_handler(int32 evtType, int32 evtState, IFX_ID * iid,
			     int32 count, IFX_NAME_VALUE_PAIR array_fvp[]);

/*! \brief  This function is used to check and send notification.
        \param[in] iid IFX Identifier for object.
        \param[in] count Number of field value pairs in array.
        \param[in] array_fvp Field Value Pair Array.
	\param[in] flags Flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_check_n_send_notification(IFX_ID * iid, uint32 count,
				    IFX_NAME_VALUE_PAIR * array_fvp,
				    uint32 flags);

/*! \brief  This function is used to check access control (ACL).
        \param[in] iid IFX Identifier.
        \param[in] count Number of Field-Value Pair entries in Array.
        \param[in] array_fvp Array of Field-Value Pair.
	\param[in] flags Flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_check_acl(IFX_IN IFX_ID * iid,
		    IFX_IN uint32 count,
		    IFX_IN IFX_NAME_VALUE_PAIR * array_fvp,
		    IFX_IN uint32 flags);

/*! \brief  This function is used to allocated TR-069 Identifier..
        \param[in] iid IFX Identifier.
        \param[in] distinctSec Distinct Specifier in object.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_alloc_tr69id(IFX_IN_OUT IFX_ID * iid, IFX_IN char8 * distinctSec);

/*! \brief  This function is used to update id mapping and attributes.
        \param[in] iid IFX identifier of object.
        \param[in] count Number of Field-Value Pair entries.
        \param[in] array_fvp Field-Value Pair Array.
	\param[in] flags Flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_update_map_n_attr(IFX_ID * iid, uint32 count,
			    IFX_NAME_VALUE_PAIR * array_fvp, uint32 flags);

/*! \brief  This function is used to free TR-069 Id allocated earlier.
        \param[in] id IFX Identifier
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_free_tr69id(IFX_IN IFX_ID * id);

//TR111 related APIs
/*! \brief  This function is used to set Gateway information for TR-111.
        \param[in] operation Set Action Argument - Add, Modify or Delete.
        \param[in] gateway_info Gateway information
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_gateway_info(int32 operation, GATEWAY_INFO * gateway_info,
			   uint32 flags);

/*! \brief  This function is used to set manageable device.
        \param[in] oper Operation Action - Add, Modify or Delete.
        \param[in] Manageable_device
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_manageable_device(int32 oper,
				MANAGEABLE_DEVICE * Manageable_device,
				uint32 flags);

	 /* @} *//*TR69   */

/** \ingroup FUNC_DEV_MAPI
        \defgroup STATS_OBJ Interface Statistics
       \brief The STATS objects related MAPIs are described in this section.
*/
/* @{ */

/*! \brief  This function gets the interface statistics for the given interface name and fills the output structure.
        \param[in] iface Name of the interface for which statistics to be queried.
        \param[out] if_stats The interface statistics are returned in this arg.
        \param[in] flags Currently unused.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_if_stats(char8 * iface, IF_STATS * if_stats, uint32 flags);

/*! \brief  This function is used to modify interface attributes.
        \param[in] name Interface name
        \param[in] oper Set operation Argument - Add, Modify or Delete.
        \param[in] params Interface configurtaion Parameters
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_mod_interface_attr(char8 * name, int32 oper, NET_INTF_CFG * params);

/*! \brief  This function fetches the physical port information.
        \param[in] num port id.
        \param[out] pstPortInfo port information structure.
        \param[in] node (0 or 1).
        \return IFX_SUCCESS / IFX_FAILURE

*/
int ifx_get_phyport_info(int num, struct ifx_phyport_info *pstPortInfo,
			 int node);

/*! \brief  This function is used to fetch port configuration statistics.
        \param[in] num port id.
        \param[out] pstPortStatsInfo port statistics information structure.
        \param[in] node (0 or 1).
        \return IFX_SUCCESS / IFX_FAILURE

*/
int ifx_get_phyportstats_info(int num,
			      struct ifx_phyportstats_info *pstPortStatsInfo,
			      int node);

/* Common Utility Functions */
/*! \brief  This function is used to set port configuration information.
        \param[in] num port id.
        \param[in] phyport_param port information structure.
        \param[in] value port value.
        \param[in] node (0 or 1).
        \return IFX_SUCCESS / IFX_FAILURE

*/
int ifx_set_phyport_info(int num, IFX_MAPI_PhyPort_Info_Param phyport_param,
			 char8 * value, int node);

	 /* @} *//*STATS  */

/* IGMP */
/** \ingroup FUNC_DEV_MAPI
        \defgroup IGMP_OBJ IGMP
       \brief The IGMP objects related MAPIs are described in this section.
*/
/* @{ */

/*! \brief  This function is used to set igmp snooping configuration.
        \param[in] command.
        \param[in] flag.
*/
int32 ifx_mapi_set_igmp_snoop_cfg(uint32 cmd, uint32 flags);

/*! \brief  This function is used to set igmp router port.
        \param[in] port number.
        \param[in] command.
        \param[in] flag.

*/
int32 ifx_mapi_set_igmp_router_port(uint32 port, uint32 cmd, uint32 flags);

	 /* @} *//*IGMP  */

/************ UTILITY FUNCTIONS ************/

/** \ingroup FUNC_DEV_MAPI
        \defgroup UTILITIES_OBJ Utility Functions
       \brief This section describes the miscellaneous utility functions.
*/
/* @{ */

/*! \brief  This function is used to write the config file.
        \param[in] file config file
        \param[in] flags flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_config_write(char8 * file, uint32 flags);

/*! \brief  This function is used to form teh config database formatted buffer.
        \param[out] buf buffer to contain formated string.
        \param[in] count  Number of Field-Value Pairs in array.
        \param[in] array_fvp[] Array of Field-Value Pair.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 form_cfgdb_buf(char8 * buf, int32 count, IFX_NAME_VALUE_PAIR array_fvp[]);

/*! \brief  This function is used to form Field-Value Pair Array from config database stored object buffer.
        \param[in] buf input buffer containing config database represented string.
        \param[out] filecount Number of Field Value Pairs to be returned.
	\param[out] file_array_fvp Array of Field-Value Pairs to be returned.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 form_array_fvp_from_cfgdb_buf(char8 * buf, int32 * filecount,
				    IFX_NAME_VALUE_PAIR * file_array_fvp);

/*! \brief  This function is used to get index from Section Count.
        \param[in] filename Config File name
        \param[in] sectionName Section Name
        \param[out] ret_index Index to be returned.
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_index_from_sec_count(char8 * filename, char8 * sectionName,
				   int32 * ret_index, uint32 flags);

/*! \brief  This function is used to get object index from CPE-Id of object.
        \param[in] filename Config File name
        \param[in] cpe_id CPE-Identifier of object
        \param[out] ret_index Object index to be returned.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_index_from_cpe_id(char8 * filename, CPE_ID * cpe_id,
				int32 * ret_index);

/*! \brief  This function is used to compare and return list of changed Field Value Pairs in Array.
        \param[in] secName Section name
        \param[in] fcount Field-Value Pair Count
        \param[in] old_array_fvp Input Array of all Field-Value-Pairs.
	\param[in] changed_fcount Output Count of changed field-value pairs.
	\param[in] changed_array_fvp Output Array of changed field-value pairs.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_cmp_and_return_changed_fvp(char8 * secName, int32 fcount,
				     IFX_NAME_VALUE_PAIR old_array_fvp[],
				     int32 * changed_fcount,
				     IFX_NAME_VALUE_PAIR ** changed_array_fvp);

/*! \brief  This function is used to define default rollback function.
        \param[in] rollback_reason Reason for Rollback action.
        \param[in] stop_conf Config file for stopping the services.
        \param[in] start_conf Config file for staring the services.
	\param[in] flags Additional flags for rollback.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 cfg_default_rollback_fn(char8 * rollback_reason, char8 * stop_conf,
			      char8 * start_conf, uint32 flags);

/*! \brief  This function is used to register rollback handler function .
        \param[in] fptr Rollback handler function
        \param[in] data Arguments
        \param[in] stop_conf Config database for stopping services
	\param[in] start_conf Config database for starting services
	\param[in] func Function Name
	\param[in] flags Additional flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 rollback_configuration(ROLLBACK_FN fptr, void *data, char8 * stop_conf,
			     char8 * start_conf, char8 * func, uint32 flags);

/*! \brief  This function is used to form teh config database formatted buffer.
        \param[out] buf buffer to contain formated string.
        \param[in] count  Number of Field-Value Pairs in array.
        \param[in] array_fvp[] Array of Field-Value Pair.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 form_cfgdb_buf(char8 * buf, int32 count, IFX_NAME_VALUE_PAIR array_fvp[]);

/*! \brief  This function is used to form Field-Value Pair Array from config database stored object buffer.
        \param[in] buf input buffer containing config database represented string.
        \param[out] filecount Number of Field Value Pairs to be returned.
	\param[out] file_array_fvp Array of Field-Value Pairs to be returned.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 form_array_fvp_from_cfgdb_buf(char8 * buf, int32 * filecount,
				    IFX_NAME_VALUE_PAIR * file_array_fvp);

/*! \brief  This function is used to compare and return list of changed Field Value Pairs in Array.
        \param[in] secName Section name
        \param[in] fcount Field-Value Pair Count
        \param[in] old_array_fvp Input Array of all Field-Value-Pairs.
	\param[in] changed_fcount Output Count of changed field-value pairs.
	\param[in] changed_array_fvp Output Array of changed field-value pairs.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_cmp_and_return_changed_fvp(char8 * secName, int32 fcount,
				     IFX_NAME_VALUE_PAIR old_array_fvp[],
				     int32 * changed_fcount,
				     IFX_NAME_VALUE_PAIR ** changed_array_fvp);

/*! \brief  This function is used to get the index from parent object cpeId.
        \param[in] filename Config File name
        \param[in] pcpe_id Parent Object CPE-Id
        \param[out] ret_index Return Index Number
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_index_from_pcpe_id(char8 * filename,
				 CPE_ID * pcpe_id, int32 * ret_index);

/*! \brief  This function is used to get the count of object instances.
        \param[in] pFileName Config Filename
        \param[in] pTag Objec Name
        \param[in] flag Flag
        \param[out] retNum Return Number
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_obj_instances_count(IFX_IN char8 * pFileName,
				  IFX_IN char8 * pTag,
				  IFX_IN uint32 flag, IFX_OUT int32 * retNum);

/*! \brief  This function is used to increment next cpe-id of object.
        \param[in] filename Filename
        \param[in] SectionName
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_increment_next_cpeId(char8 * filename, char8 * SectionName);

/*! \brief  This function is used to allocate a new IID.
        \param[in] mySectionName Object Name
        \param[in] pSectionName  Parent Object Name
        \param[in] parent_id     Parent CPE-Id
	\param[out] my_id         My Object IFX Id.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_iid(char8 * mySectionName, char8 * pSectionName,
		  IFX_ID * parent_id, IFX_ID * my_id);

/*! \brief  This function is used to get IID from config file..
        \param[in] iid  IID of object.
        \param[in] filename  Config File name.
        \param[in] SectionName  Section Name.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_iid_from_conf(IFX_ID * iid, char8 * filename,
			    char8 * SectionName);

/*! \brief  This function is used to check ACL and for changed Array.
        \param[in] iid IID of object.
        \param[in] numFvp  Number of Field Value Pairs.
        \param[in] array_fvp Array of Field Value Pairs.
        \param[out] changed_count  Changed Count of FVP.
        \param[out] array_changed_fvp Channged Array of FVP.
        \param[in] flags  Valid combination of SET flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_check_acl_n_form_chgd_array(IFX_IN IFX_ID * iid,
				      IFX_IN uint32 numFvp,
				      IFX_IN IFX_NAME_VALUE_PAIR array_fvp[],
				      IFX_OUT uint32 * changed_count,
				      IFX_OUT IFX_NAME_VALUE_PAIR **
				      array_changed_fvp, IFX_IN uint32 flags);

/*! \brief  This function is used to get index from Section Count.
        \param[in] filename Config File name
        \param[in] sectionName Section Name
        \param[out] ret_index Index to be returned.
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_index_from_sec_count(char8 * filename, char8 * sectionName,
				   int32 * ret_index, uint32 flags);

/*! \brief  This function is used to get config index and Name-Value Pairs.
        \param[in] iid  IID of object.
        \param[in] passed_index Index to be passed.
        \param[in] field_prefix Prefix name of object.
        \param[in] count  Number of Name-Value Pairs.
        \param[in] array_fvp Array of Name-Value Paires.
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_conf_index_and_nv_pairs(IFX_ID * iid, int32 passed_index,
				      char8 * field_prefix, int32 count,
				      IFX_NAME_VALUE_PAIR * array_fvp,
				      uint32 flags);

/*! \brief  This function is used to get WAN connection name from interface name.
        \param[out] wan_connName WAN Connection Name
        \param[in] wan_ifName WAN Interface Name
        \param[in] wan_type Type of WAN (refer enum WAN_TYPE)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_wan_connName_from_ifname(char8 * wan_connName, char8 * wan_ifName,
				       WAN_TYPE wan_type);

/*! \brief  This function is used to get WAN interface name form WAN connection Name.
        \param[in] wan_connName WAN Connection Name
        \param[out] wan_ifName WAN Interface Name
        \param[in] wan_type Type of WAN (refer enum WAN_TYPE)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_wan_ifname_from_connName(char8 * wan_connName, char8 * wan_ifName,
				       WAN_TYPE wan_type);

/*! \brief  This function is used to get user configured connection name from WAN configured connection name.
        \param[in] wan_connName WAN Connection Name
        \param[out] wan_confconnName 
        \param[in] wan_type Type of WAN (refer enum WAN_TYPE)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_wan_confconnName_from_connName (char8 * wan_connName, char8 * wan_confconnName,WAN_TYPE wan_type);

/*! \brief  This function is used to get WAN interface name from WAN configured connection name.
        \param[in] wan_connName WAN Connection Name
        \param[out] wan_ifName WAN Interface Name
        \param[in] wan_type Type of WAN (refer enum WAN_TYPE)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_wan_ifname_from_conf_connName(char8 * wan_connName,
					    char8 * wan_ifName,
					    WAN_TYPE wan_type);

/*! \brief  This function is used to manipulate WAN indices.
        \param[in] filename Config file Name
        \param[in] SectionTag Object Name
        \param[in] indexFieldName  index field name
        \param[in] indxVal index value
        \param[in] flags flags.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_manipulate_wan_indexs(char8 * filename, char8 * SectionTag,
				char8 * indexFieldName, uint32 indxVal,
				uint32 flags);

int32 ifx_manipulate_string_indexs(char8 * filename, char8 * SectionTag,
 				char8 * indexFieldName, char *indxVal,
				uint32 flags);

/*! \brief  This function is used to delete virtual server.
	\param[in] oldconnName 
	\param[in] function from which this utility is called.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 mapi_delete_old_virtualserver(char *oldconnName, char *function);

/*! \brief  This function is used to update virtual server.
	\param[in] newconnName 
	\param[in] function from which this utility is called.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 Update_virtual_server_config(char8 *newconnName,char8 *function);

/*! \brief  This function is used to run dependency check on WAN configuration.
        \param[in] wan_cfg WAN configuration information.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_check_wan_configuration_dependency(WAN_CONN_CFG * wan_cfg);

/*! \brief  This function is used to compare two IP addresses.
        \param[in] strIp1 IP address 1 in string form.
        \param[in] strIp2 IP address 2 in string form.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_compare_ip_addr(char8 * strIp1, char8 * strIp2);

/*! \brief  This function returns mode of WAN connection with specified WAN index.
        \param[in] nWAN_IDX WAN idex
        \return WAN mode if success / IFX_FAILURE
*/
int32 GetWanMode(int32 nWAN_IDX);

/*! \brief  This function returns mode of WAN connection with specified WAN index and type.
        \param[in] nWAN_IDX WAN idex
        \param[in] type WAN type (refer enum WAN_TYPE)
        \return WAN mode if success / IFX_FAILURE
*/
int32 getWanMode(int32 nWAN_IDX, WAN_TYPE type);

/*! \brief  This function returns mode of WAN connection with specified WAN index and type.
        \param[in] wanIdx WAN idex
        \param[in] wanType WAN type (refer enum WAN_TYPE)
        \return WAN mode if success / IFX_FAILURE
*/
int32 WanModeGet(int32 wanIdx, WAN_TYPE wanType);

/*! \brief  This function is used to get LAN interface from specified index.
        \param[in] index Index to be given as input.
        \param[out] name  Interface Name
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 GetLanIface(int32 index, char8 * name);

/*! \brief  This function is used to get WAN interface for WAN connection with specified WAN index and type.
        \param[in] nWAN_IDX WAN Index (> 0)
        \param[in] wan_type WAN type (refer enum WAN_TYPE)
        \param[out] IFName WAN Interface Name
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 GetWanIface(int32 nWAN_IDX, char8 * IFName, WAN_TYPE wan_type);

/*! \brief  This function is used to get WAN IP address for WAN connection with specified WAN index and type.
        \param[in] nWAN_IDX WAN Index (> 0)
        \param[in] wan_type WAN type (refer enum WAN_TYPE)
        \param[out] IP IP address
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 GetWanIp(int32 nWAN_IDX, char8 * IP, WAN_TYPE wan_type);

/*! \brief  This function is used to retrieve substring from distinct field.
        \param[in] filename Config file name
        \param[in] pSectionName Object Name
        \param[in] pDistField Distict Field name
        \param[in] distVal Distict Value
        \param[out] retString Retrun String
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_ret_substr_from_distfield(char8 * filename, char8 * pSectionName,
				    char8 * pDistField, char8 * distVal,
				    char8 ** retString);

/*! \brief  This function is used to retrieve substring from distinct field with state match.
        \param[in] filename Config file name
        \param[in] pSectionName Object Name
        \param[in] pDistField Distict Field name
        \param[in] distVal Distict Value
        \param[out] retString Retrun String
        \param[in] flags Indicate state of value (enabled/disabled/incomplete) to be matched
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_ret_substr_from_distfield_with_state(char8 * filename,
					       char8 * pSectionName,
					       char8 * pDistField,
					       char8 * distVal,
					       char8 ** retString,
					       uint32 flags);

/*! \brief  This function is used to get available distinct index.
        \param[in] filename config file name
        \param[in] pSectionName Object Name
        \param[in] pDistField distict field name
        \param[in] minIndx Minimum Index
        \param[in] maxIndx Maximum Index
        \param[out] dist_index Distict Index
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_available_distinct_index(char8 * filename, char8 * pSectionName,
				       char8 * pDistField, uint32 minIndx,
				       uint32 maxIndx, int32 * dist_index);

/*! \brief  This function is used to get gateway information.
        \param[out] sGW Gateway IP address
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_runtime_gw(char8 * sGW);

int32 ifx_get_runtime_dnsv6(char8 * sDNSv6, char8 * nLine);

/*! \brief  This function is used to retrive PCR value for specified VCC.
        \param[in] sVCC VCC in array form.
        \param[out] pcr_val PCR value.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 get_pcr_val_for_vcc(char8 sVCC[], int32 * pcr_val);

/*! \brief  This function is used to get QoS mode for ATM VCC.
        \param[in] sVCC ATM VCC information
        \param[out] qos_mode QoS Mode
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 get_qos_mode_for_vcc(char8 sVCC[], int32 * qos_mode);

/*! \brief  This function is used to get PCR value from WAN index.
        \param[in] wan_idx WAN index
        \param[out] pcr_val PCR value
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 get_pcr_val_for_wan_idx(int32 wan_idx, int32 * pcr_val);

/*! \brief  This function is used to check available bandwidth.
        \param[in] iid WAN object identifier
        \param[in] pcr_val PCR value
        \param[in] qos_mode QoS Mode
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_check_for_available_bandwidth(IFX_ID iid, int32 pcr_val,
					int32 qos_mode);

/*! \brief  This function is used to get the LAN inteface name configured for the given LAN connection name.
        \param[in] lan_connName Lan connection name
        \param[out] lan_ifName Lan interface name
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_lan_ifname_from_connName(char8 * lan_connName,
				       char8 * lan_ifName);

/*! \brief  This function is used to LAN connection name configured for the given LAN interface name.
        \param[in] lan_connName Connection name for LAN interface
        \param[out] lan_ifName LAN interface
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_lan_connName_from_ifname(char8 * lan_connName,
				       char8 * lan_ifName);

/*! \brief  This function is used to get LAN config Security.
        \param[in] confPassword Config Password
        \param[in] resetPassword Rset Password
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_lan_conf_security(char8 * confPassword, char8 * resetPassword);

/*! \brief  This MAPI queries the device_info object configuration. This object is singleton object with no instantiation support.
        \param[out] dev_info Contains both Device_Info Object configuration information and IFX_ID.
                                            The cpeId and owner fields must come filled from the caller.
        \param[in] flags Filter Flags to get object instance in particular state.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_device_info(DEVICE_INFO * dev_info, uint32 flags);

/*! \brief  This function is wrapper function to get device information.
        \param[in] dev_info Device Information with Id part filled-in.
        \param[in] flags Flasg
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_device_info_wrapper(DEVICE_INFO * dev_info, uint32 flags);

/*! \brief  This MAPI provides GET type of access to ipping_diag (IP-Ping Diagnostics) object. The ipping_diag is singleton
                    instance object and currently it does not address it through CPE-Id. This API reads the diagnostics result counters
                    from the previous invocation of SET operation.
        \param[out] ipping_diag The diagnostics result counters are output from the function.
        \param[in] flags Currently unused.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_get_ipping_diag(IPPING_DIAG * ipping_diag, uint32 flags);

/*! \brief  This API returns the number of USB member interfaces for the given bridge interface.
        \param[in] bridge_if The input bridge interface name.
        \param[out] num_ifs Return value which will have the number
                            of USB interfaces configured under bridge_if.
        \param[in] flags Unused as of now.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_bridge_num_usb_ifs(char8 * bridge_if, int32 * num_ifs,
				 int32 flags);

/*! \brief  This function is used to get number of WAN connection.
        \param[out] num_entries Number of WAN connections
        \param[in] flags Get Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_num_wan_connections(int *num_entries, uint32 flags);

/* @} *//*Utility Functions  */


#if 0
/* using the get dsl api prototype based on new dsl apis */
int32 ifx_get_wan_dsl_diagnostics(WAN_DSL_DIAGNOSTICS * wan_dsl_diags,
				  uint32 flags);
#endif				// 0

/** \ingroup FUNC_DEV_MAPI
        \defgroup DSL_OBJ DSL
       \brief DSL Diagnostics objects related MAPIs are described in this section.
*/
/* @{ */

#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API

/*! \brief  This MAPI gets the WAN DSL diagnostics results.This API reads the DSL diagnostics results stored in dynamic
                    storage file. The values in this file are kept after diagnostics operation were run.
        \param[out] Wan_Dsl_Diag The diagnostics test results counters and
                                                        other information comes back.
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_cpe_api_get_dsl_diagnostics(WAN_DSL_DIAGNOSTICS * Wan_Dsl_Diag,
				      uint32 flags);

/*! \brief  This API is interface to DSL CPE API IOCTL calls of GET type. This API opens the device invokes ioctl and closes
                    the device at end.
        \param[in] cmd IOCTL command value.
        \param[in] data Data from ioctl.
        \param[in] flags Unused as of now.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_cpe_api_device_get_operation(int32 cmd, void *data, uint32 flags);

/*! \brief  This function is used to get the line activate.
        \param[in] iid TBD
        \param[in] lineActivate TBD
        \param[in] flags TBD
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_cpe_api_get_line_activate(IFX_ID * iid,
				    DSL_G997_LineActivate_t * lineActivate,
				    uint32 flags);

/*! \brief  This API is interface to DSL CPE API IOCTL calls of SET type. This API opens the device invokes ioctl and closes
                    the device at end.
        \param[in] cmd IOCTL SET command value.
        \param[in] data Data for ioctl SET command.
        \param[in] flags Unused as of now.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_cpe_api_device_set_operation(int32 cmd, void *data, uint32 flags);

/*! \brief  This MAPI is SET type of API for DSL Diagnostics. This API in turn invokes DSL CPE API to initiate diagnostics.
                    For diagnostics operation to begin, f_enable parameter of WAN_DSL_DIAGNOSTICS structure should come set
                    to Enabled and diagnostic_state parameter set to WAN_DSL_START_DIAGNOSING.
        \param[in] operation Only allowed operation is modification (IFX_OP_MOD).
        \param[in] Wan_Dsl_Diag WAN DSL Diagnostics.
        \param[in] flags Valid combination of flags for SET API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_cpe_api_set_dsl_diagnostics(int32 operation,
				      WAN_DSL_DIAGNOSTICS * Wan_Dsl_Diag,
				      uint32 flags);

/*! \brief  his function is used to get the line activate.
        \param[in] iid TBD
        \param[in] lineActivate TBD
        \param[in] flags TBD
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_cpe_api_set_line_activate(IFX_ID * iid,
				    DSL_G997_LineActivate_t * lineActivate,
				    uint32 flags);

int32 ifx_mapi_get_dsl_test_params_line_status(DSL_TEST_PARAMS_LINE_STATUS *
					       pxDslTestParamsLINESTATUS,
					       uint32 flags);
int32 ifx_mapi_get_dsl_test_params_hlog(DSL_TEST_PARAMS_HLOG *
					pxDslTestParamsHLOG, uint32 flags);
int32 ifx_mapi_get_dsl_test_params_qln(DSL_TEST_PARAMS_QLN * pxDslTestParamsQLN,
				       uint32 flags);
int32 ifx_mapi_get_dsl_test_params_snr(DSL_TEST_PARAMS_SNR * pxDslTestParamsSNR,
				       uint32 flags);
int32
ifx_mapi_get_dsl_test_params_snr_alloc_status(DSL_TEST_PARAMS_SNR_ALLOC_STATUS *
					      pxDslTestParamsSNRALLOCSTATUS,
					      uint32 flags);
#endif				// CONFIG_PACKAGE_IFX_DSL_CPE_API

	 /* @} *//*DSL */

#ifdef CONFIG_PACKAGE_LIBOPENSSL
/* AES256 */
/** \ingroup FUNC_DEV_MAPI
        \defgroup CRYPT_OBJ AES256
       \brief The IGMP objects related MAPIs are described in this section.
*/
/* @{ */

/*! \brief  This function is used to encrypt a file with aes256 and output will be
	base64 encoded. If no key is provided, it does base64 encoding without encryption.
	\param[in] Key
	\param[in] Input file
	\param[in] Output file
	\return 0 - Success / non-zero Failure
*/
int ltq_file_encrypt_aes256 (char *key, char *inp_file, char *out_file);
/*! \brief  This function is used to decrypt a file with aes256 and base64 encoded.
	If no key is provided, it does only base64 decoding.
	\param[in] Key
	\param[in] Input file
	\param[in] Output file
	\return 0 - Success / non-zero Failure
*/
int ltq_file_decrypt_aes256 (char *key, char *inp_file, char *out_file);

/* @} *//*AES256 */
#endif /* CONFIG_PACKAGE_LIBOPENSSL */

//TR111 related APIs

/*! \brief  This function is used to get get gateway information for TR-111.
        \param[in] gateway_info Gateway Information
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_gateway_info(GATEWAY_INFO * gateway_info, uint32 flags);

/*! \brief  This function is used to get all manageable devices list.
        \param[in] num_entries No of entries
        \param[in] Manageable_device manageable devices array
        \param[in] flags Flags
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_all_manageable_devices(int32 * num_entries,
				     MANAGEABLE_DEVICE ** Manageable_device,
				     uint32 flags);

/*! \brief  This function is used to validate Rates.
        \param[in] Oper - Add, Modify or Delete, 8 for other.
        \param[in] cpeId - cpeId or port rate if Oper is 8
        \param[in] qos_queue_passed - queue to be operated. NULL if Oper is 8
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ipqos_rate_validate(uint32 Oper, uint32 cpeId,
			  IFX_MAPI_QoS_Queue * qos_queue_passed);
/************ SET APIs  ************/

/*! \brief  This function is used to Config LAN Security.
        \param[in] operation Set Operation - Add, Modify or Delete.
        \param[in] password
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_set_lan_conf_security(int32 operation, char8 * password,
				uint32 flags);

/** \ingroup FUNC_DEV_MAPI
        \defgroup OAM_OBJ OAM
       \brief The OAM related MAPIs provision OAM actions on WAN connection devices.
*/
/* @{ */
/*! \brief  This MAPI is SET type of API for device object adsl_oam_f5. This object is linked with WAN object and its API get
                    called along with WAN Set API.
        \param[in] operation Operation specifies addition
                                            (IFX_OP_ADD) or deletion
                                            (IFX_OP_DEL) or modification
                                            (IFX_OP_MOD).
        \param[in] atmf5_daigs WAN ATM F5 Loopback Diagnostics Object.
        \param[in] flags Valid combination of flags for SET API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_atmf5_loop_diagnostics(int32 operation,
				     WAN_ATMF5_LOOP_DIAGNOSTICS * atmf5_daigs,
				     uint32 flags);

/*! \brief  This API retrieves ATM F5 loop diagnostics for all ATM VCC.
        \param[out] num_entries Number of entries
        \param[out] atmf5_diagnostics ATM F5 Diagnostics
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                    IFX_F_GET_INCOMP,
                                    IFX_F_GET_ENA or IFX_F_DEFAULT
                                    can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_all_wan_atmf5_loop_diagnostics(int32 * num_entries,
					     WAN_ATMF5_LOOP_DIAGNOSTICS **
					     atmf5_diagnostics, uint32 flags);

/*! \brief  This MAPI retrieves the parameters of device object adsl_oam_f5. It includes WAN ATM F5 Loopback Diagnostics
                    counters result as well.
        \param[out] atmf5_diagnostics The identifier portion should be filled and
                                    the diagnostics test results counters and other information comes back.
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                        IFX_F_GET_INCOMP,
                                        IFX_F_GET_ENA or IFX_F_DEFAULT
                                        can be passed to this API.
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_get_atmf5_loop_diagnostics(WAN_ATMF5_LOOP_DIAGNOSTICS *
				     atmf5_diagnostics, uint32 flags);

/*! \brief  This function is used to start OAM F5 Ping.
        \param[in] vpi VPI info
        \param[in] vci VCI info
        \param[in] scope Scope of Diagnostics
        \param[out] ping_timeout Ping Timeout in seconds
        \param[out] num_cells_tx Number of Cells Transmitted
        \param[out] num_cells_rx Number of Cells Received
        \param[out] max_resp_time Maximum response Time
        \param[out] min_resp_time Minimum response Time
        \param[out] avg_resp_time Average response Time
        \return IFX_SUCCESS / IFX_FAILURE
*/
int ifx_oam_f5_ping(int vpi, int vci, char scope, int ping_timeout,
		    int num_cells_tx, int *num_cells_rx, int *max_resp_time,
		    int *min_resp_time, int *avg_resp_time);

	 /* @} *//*OAM  */

#if 0
/* using the get dsl api prototype based on new dsl apis */
int32 ifx_set_wan_dsl_diagnostics(int32 operation,
				  WAN_DSL_DIAGNOSTICS * Wan_Dsl_Diag,
				  uint32 flags);
#endif				// 0

/** \ingroup FUNC_DEV_MAPI
        \defgroup Misc_OBJ Miscellaneous Functions
       \brief This section describes the miscellaneous utility functions.
*/
/* @{ */

/*! \brief  This function is used to get the WAN indices.
        \param[in] wan_index WAN Index
        \param[out] count Vector idx_array size.
        \param[out] idx_array WAN Indices Array
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 get_wan_indices(char8 * wan_index, int32 * count, int32 ** idx_array);

/*! \brief  This function is used to get number of instances count in a given section name.
        \param[in] sec_name Section or Object Name
        \param[out] count Number of Instances
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_sec_instance_count(char8 * sec_name, uint32 * count);

/*! \brief  This function is used to get instances count from distict field.
        \param[in] secName Object Name
        \param[in] prefix Prefix Name
        \param[in] fName Field name
        \param[in] fValue Field Value
        \param[in] flags Valid combination of Get bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_instance_count_from_distfield(char8 * secName, char8 * prefix,
					    char8 * fName, char8 * fValue,
					    uint32 flags);

/*! \brief  This function is used to get another tag value from distinct field value pair.
        \param[in] secName Object Name
        \param[in] fName Field name
        \param[in] fValue Field Value
        \param[out] fRetName Field Return Name
        \param[out] fRetValue Field Return Value
        \param[in] flags Valid combination of Get bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_another_tag_value_from_dist_fvp(char8 * secName, char8 * fName,
					      char8 * fValue, char8 * fRetName,
					      char8 * fRetValue, uint32 flags);

/*! \brief  This function is used to get instances count from distinct field value pair.
        \param[in] secName Object Name
        \param[in] prefix Prefix Name
        \param[in] fName1 Field Name -1
        \param[in] fValue1 Field Value-1
        \param[in] fName2 Field name-2
        \param[in] fValue2 Field value-2
        \param[in] flags Valid combination of Get bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_instance_count_from_dist_fvps(char8 * secName, char8 * prefix,
					    char8 * fName1, char8 * fValue1,
					    char8 * fName2, char8 * fValue2,
					    uint32 flags);

/*! \brief  This function is used to get instances count from distinct field name-value pair information.
        \param[in] secName Object Name
        \param[in] prefix Prefix name
        \param[in] fName Field name
        \param[in] fValue Field Value
        \param[in] flags Valid combination of Get bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_instance_count_from_dist_fvp(char8 * secName, char8 * prefix,
					   char8 * fName, char8 * fValue,
					   uint32 flags);

/*! \brief This function, if Partial backup feature is enabled,
           will backup certain sections of the rc.conf file that are specified to be
           backedup. If this feature is not enabled, the function does a normal full
           rc.conf file backup. .
        \param[in] flags - for future use.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int ifx_mapi_backup_config(int flags);

/*! \brief This function, if Partial backup/restore feature is enabled,
           will restore all sections specified in web_ui_backup_list[], from the uploaded
           file(from user's PC) (which is copied into /tmp/sysconf by the caller function)
           into /flash/rc.conf If this feature is not enabled, the function does a normal full
           rc.conf file backup.
        \param[in] facUpdate for future use.
        \param[in] flags for future use.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int ifx_mapi_restore_config(int facUpdate, int flags);

int ltq_mapi_restore_config_verify(char *fname, char *model);

/*! \brief  This function is used to set VoIP interface on WAN.
        \param[in] wan_idx WAN index
        \param[in] wan_type WAN type (refer enum WAN_TYPE)
        \param[in] flags Valid combination of Set bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_set_voip_interface(int32 wan_idx, WAN_TYPE wan_type, uint32 flags);

/*! \brief  This function is used to initialize specified dynamic object.
        \param[in] iid Dynamic Object Name
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_dynamic_object_init(IFX_ID * iid);

/*! \brief  This function is used to get address type of IP connection specified by index wan_idx 
        \param[out] type Address type of WAN connection
        \param[in] wan_idx Index of WAN connection
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_wanip_conn_type(IP_TYPE * type, int32 wan_idx);

/*! \brief  This function is used to modify default WAN setting of upcoming WAN mode.
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_modify_default_wan_interface();

/*! \brief  This function returns next distinct number from array of integers field in file specified.
        \param[in] filename Name of configuration file
        \param[in] pSectionName Name of section name in configuration file
        \param[in] pDistField Field that stores index value
        \param[out] dist_index Next value from the distinct index field
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_next_distinct_index(char8 * filename, char8 * pSectionName,
				  char8 * pDistField, int32 * dist_index);

/*! \brief  This function retrieves number of instances in a particular section.
        \param[in] secName Name of the section
        \param[out] count Number of instances in the section mentioned
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_sec_count(char8 * secName, int32 * count);

/*! \brief  This function is used to increment value of integer field in file specified.
        \param[in] filename Name of configuration file
        \param[in] SectionName Name of section name in configuration file
        \param[in] sTag New index value
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_increment_idx_value(char8 * filename, char8 * SectionName,
			      char8 * sTag);

/*! \brief  This function is wrapper to ifx_GetObjData function.
        \param[in] file Configuration File Name from where to read the entry. (e.g. /flash/rc.conf)
        \param[in] sectionName Section, Tag or Object Name. (e.g. lan_main)
        \param[in] searchStr Parameter Name. (e.g. lan_main_0_ipAddr)
        \param[out] retVal Returned queried value for a given name
        \param[in] flags Filter for querying the name with particular status
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 GetObjData(char8 file[], char8 sectionName[], char8 searchStr[], char8 retVal[], uint32 flags);

/*! \brief  This function is wrapper to ifx_SetObjData function.
        \param[in] file File name, in which to write (add/modify/delete) the entry or entries
        \param[in] sectionName Section, Tag or Object Name.
        \param[in] flags Conveying the type of individual or set of actions to be taken
        \param[in] buf_count Number of Var Args to be updated
        \param[in] buf Variable Arguments
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 SetObjData(char8 file[], char8 sectionName[], uint32 flags, int32 buf_count, char8 buf[]);

/* port wan binding MAPIs */

#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)

int32 mapi_port_binding_cfg_set(int32 operation,
					pwb_cfg_t *entry,
					uint32 flags);
/*! \brief  This function is used to get instances count from distinct field value pair.
        \param[in] operation
        \param[in] Port binidng entry values
        \param[in] flags Valid combination of Get bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 mapi_port_binding_status_set(pwb_status_t *pwb,
			  	uint32 flags);
/*! \brief  This function is used to get instances count from distinct field value pair.
        \param[in] Port binidng status values
        \param[in] flags Valid combination of Get bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 mapi_port_binding_cfg_get_all(uint32 *num_entries,
						   pwb_cfg_t **pwb_array,
						   uint32 flags);
/*! \brief  This function is used to get instances count from distinct field value pair.
        \param[out] number of entries
        \param[out] Port binidng entry values
        \param[in] flags Valid combination of Get bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 mapi_port_binding_status_get(pwb_status_t *pwb,
				  uint32 flags);
/*! \brief  This function is used to get instances count from distinct field value pair.
        \param[out] port binding status value
        \param[in] flags Valid combination of Get bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 mapi_pwb_delentry_on_wanchange(char *wanName, pwb_cfg_t **pwb_entry);
/*! \brief  This function is used to delete a port binding entry when WAN connecting Modified
    \param[in] wanName name of the WAN connection getting modified
    \param[in] pointer to the buffer to store the deleted entry
*/

int32 mapi_pwb_modentry_on_wanchange(char *new_wanName, pwb_cfg_t *pwb_entry);
/*! \brief  This function is used to add port binding entry that was buffered before deletion 
    \with the modified wan connection details 
    \param[in] new_wanName name of the WAN connection getting modified
    \param[in] pointer to the buffer to store the deleted entry
*/


#endif //CONFIG_FEATURE_LTQ_PORT_WAN_BINDING

#if defined(CONFIG_FEATURE_LTQ_VLAN_SWITCH_PORT_ISOLATION) ||  defined(CONFIG_FEATURE_LTQ_SWITCH_PORT_ISOLATION) 

int32 mapi_lan_get_ifname_from_conname(char *ifname, char *conname);
/*! \brief  This function is used return the lan connection name when we pass the interface  name
	\param in interface name
	\param out connection name
	\return IFX_SUCCESS/IFX_FAILURE
*/

int32 lan_port_sep_enable_get();
/*! \brief  This function is used return the status of port separation.
        \return enabled / disabled
*/
int32 mapi_lan_port_sep_info_get(int32 *num_entries,lan_port_sep_cfg_t **lps, 
				 uint32 flags);
/*! \brief  This function is used return the laninterface info
        \param[in] lan side ports info
        \param[in] flags Valid combination of Get bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 mapi_lan_port_sep_status_set(lan_port_sep_status_t *lps,
			  	uint32 flags);
/*! \brief  This function is used to set the status of lan port separation.
        \param[in] Port separation status
        \param[in] flags Valid combination of Get bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/

int32 mapi_lan_port_sep_status_get(lan_port_sep_status_t *lps,
				  uint32 flags);
/*! \brief  This function is used to get instances count from distinct field value pair.
        \param[out] port separation status
        \param[in] flags Valid combination of Get bit flags (bitwise-ORed)
        \return IFX_SUCCESS / IFX_FAILURE
*/

#endif //CONFIG_FEATURE_LTQ_VLAN_SWITCH_PORT_ISOLATION

#if defined(CONFIG_FEATURE_MEDIA_SERVER)
/* MediaServer */
/** \ingroup FUNC_DEV_MAPI
        \defgroup MediaServer_OBJ MediaServer
       \brief The MediaServer objects related MAPIs are described in this section.
*/
/* @{ */

/*! \brief  This function is used to get Media Server configuration details.
        \param[out] Media server configuration details in a list LTQ_MAPI_MediaServer
	\param[in] flags Any of the flags IFX_F_GET_ANY or IFX_F_DEFAULT
			can be passed to this API
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_get_mediaserver(LTQ_MAPI_MediaServer * medSrvr, uint32 flags);

/*! \brief  This function is used to set Media Server configuration details.
        \param[out] Media Server configuration details from a list LTQ_MAPI_MediaServer
			written to rc.conf
        \param[in] flags Any of the flags IFX_F_MODIFY,
			IFX_F_DELETE,
			IFX_F_DEFAULT
			can be passed to this API
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_set_mediaserver(uint32 oper, LTQ_MAPI_MediaServer * medSrvr, uint32 flags);

/*! \brief  This function is used to get all instances of Media location and its classifications
        \param[out] All media location details and classifications filled in array of
			structure LTQ_MAPI_Media_Location
        \param[in] flags Any of the flags IFX_F_GET_ANY or IFX_F_DEFAULT
			can be passed to this API
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_get_all_media_location_entries(uint32 * numMeds,
			LTQ_MAPI_Media_Location ** medLocEntries, uint32 flags);

/*! \brief  This function is used to set all instances of Media location and its classifications
        \param[out] All media location details and classifications filled in array of
			structure LTQ_MAPI_Media_Location written to rc.conf
        \param[in] flags Any of the flags IFX_F_MODIFY,
			IFX_F_DELETE,
			IFX_F_DEFAULT
			can be passed to this API
	\param[in] operation Any of the flags IFX_OP_ADD,
			IFX_OP_DEL,
			IFX_OP_MODIFY
			can be passed to this API
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_set_media_location(uint32 oper, LTQ_MAPI_Media_Location * medLoc,
			uint32 flags);
/* @} *//*MediaServer  */
#endif //CONFIG_FEATURE_MEDIA_SERVER

#if defined(CONFIG_FEATURE_CELL_WAN_SUPPORT) || defined(CONFIG_FEATURE_WWAN_LTE_SUPPORT)
/* WWAN */
/** \ingroup FUNC_DEV_MAPI
        \defgroup WWAN_OBJ WWAN
       \brief The WWAN objects related MAPIs are described in this section.
*/
/* @{ */

/*! \brief  This function is used to get 3G WWAN configuration details.
        \param[out] cell_wan 3G WWAN configuration details in a list LTQ_MAPI_Cell_WAN
	\param[in] flags Any of the flags IFX_F_GET_ANY or IFX_F_DEFAULT
			can be passed to this API
	\param[in] index needs to be passed to fetch the details. default 0
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_get_cell_wan(LTQ_MAPI_Cell_WAN * cell_wan, uint32 index,
			    uint32 flags);

/*! \brief  This function is used to set 3G WWAN profile configuration
        \param[out] cellWANProf Profile configuration details filled in array of
			structure LTQ_MAPI_Cell_WAN written to rc.conf
        \param[in] flags IFX_F_MODIFY
			can be passed to this API
	\param[in] operation IFX_OP_MODIFY
			can be passed to this API
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_set_cell_wan(uint32 operation, LTQ_MAPI_Cell_WAN * cellWANProf,
			    uint32 flags);

/*! \brief  This function is used to get 3G WWAN connection status.
        \param[out] modem_status 3G WWAN connection status and its details filled in a
			list LTQ_MAPI_MODEM_STATUS
	\param[in] flags Any of the flags IFX_F_GET_ANY or IFX_F_DEFAULT
			can be passed to this API
        \return IFX_SUCCESS / IFX_FAILURE
*/
int32 ltq_mapi_get_cell_modem_status(LTQ_MAPI_MODEM_STATUS * modem_status,
				     uint32 flags);
/* @} *//*WWAN  */
#endif //CONFIG_FEATURE_CELL_WAN_SUPPORT

#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
/* IGMP */
/** \ingroup FUNC_DEV_MAPI
        \defgroup IGMP_OBJ IGMP
       \brief The IGMP objects related MAPIs are described in this section.
*/
/* @{ */

/*! \brief  This function is used to set igmp WAN string configuration to rc.conf.
        \param[in] igmpoldconnName.
        \param[in] igmpnewconnName.
        \param[in] delete.
*/
int32 Update_igmp_config(char8 *igmpoldconnName, char8 *igmpnewconnName, int delete);

/* IGMP */
/** \ingroup FUNC_DEV_MAPI
        \defgroup IGMP_OBJ IGMP
       \brief The IGMP objects related MAPIs are described in this section.
*/
/* @{ */

/*! \brief  This function is used to set igmp wan flag
        \param[in] operation.
        \param[in] mcast_wan_flag.
*/
int32 Update_mcast_wan_flag(int operation, int mcast_wan_flag);
#endif

int dhcpmin_maxadress(char *IP,char *Netmask, char *minaddress , char *maxaddress);

#ifdef CONFIG_FEATURE_LTQ_PARAMETER_ENCRYPTION
/* PARAM ENCRYPTION*/
/** \ingroup FUNC_DEV_MAPI
        \defgroup ENCRYPT_OBJ PARAM ENCRYPTION
       \brief The PARAM ENCRYPTION objects related MAPIs are described in this section.
*/
/* @{ */

/*! \brief  This function is used to encrypt parameter strings in rc.conf.
        \param[in] in_buf.
        \param[in] key.
        \param[in] len.
        \param[out] out_buf.
*/
int ltq_encrypt_par( char *out_buf, const char *in_buf, int len , void *key);

/*! \brief  This function is used to decrypt parameter strings in rc.conf.
        \param[in] in_buf.
        \param[in] key.
        \param[in] len.
        \param[out] out_buf.
*/
int ltq_decrypt_par( char *out_buf, const char *in_buf, int len , void *key);
#endif

#endif				// _IFX_API_PROTO_H
