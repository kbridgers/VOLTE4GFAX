#ifndef __IFIN_PROTO_API_H__
#define __IFIN_PROTO_API_H__

/* 
** =============================================================================
** FILE NAME     : IFIN_Proto_API.h
** PROJECT       : TR69
** MODULES       : Protocol API
** DATE          : 25-Apr-2006
** AUTHOR        : TR69 team
** DESCRIPTION   : This is the header file for Protocol API. It has all 
**                 defines, datatypes and function prototypes of Protocol API.
** REFERENCES    : DDD-TR69-ProtocolAPI.doc
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author      $Comment
** 25-Apr-2006 TR69 team    Initial Version
** ============================================================================
*/

/*! \file IFIN_Proto_API.h
    \brief This is the header file for Protocol API. It has all defines, datatypes and function prototypes of Protocol API
*/

/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#ifndef DONT_USE_IFX_BASIC_TYPES_H
#include <ifx_basic_types.h>
#endif

/*
** =============================================================================
**
**                                 <DEFINITIONS>
**
** =============================================================================
*/

#ifndef IN
/*! \def IN
    \brief In
 */
#define IN IFX_IN
#endif
#ifndef OUT

/*! \def OUT
    \brief Out
 */
#define OUT IFX_OUT
#endif
#ifndef INOUT
/*! \def INOUT
    \brief In-out 
 */
#define INOUT IFX_IN_OUT
#endif

#ifdef IFX_MAX_SECTION_TAG_LEN
#undef IFX_MAX_SECTION_TAG_LEN
#endif

/*! \def IFX_MAX_SECTION_TAG_LEN
    \brief Maximum section Tag Length 
 */
#define IFX_MAX_SECTION_TAG_LEN 64

#ifdef IFX_MAX_TR69_ID_LEN
#undef IFX_MAX_TR69_ID_LEN
#endif

/*! \def IFX_MAX_TR69_ID_LEN
    \brief Maximum TR69 ID length 
 */
#define IFX_MAX_TR69_ID_LEN 260

#ifdef IFX_MAX_NAME_LEN
#undef IFX_MAX_NAME_LEN
#endif

/*! \def IFX_MAX_NAME_LEN
    \brief Maximum name length 
 */
#define IFX_MAX_NAME_LEN  132

#ifdef IFX_MAX_VAL_LEN
#undef IFX_MAX_VAL_LEN
#endif

/*! \def IFX_MAX_VAL_LEN
    \brief Maximum value of length  
 */
#define IFX_MAX_VAL_LEN IFX_MAX_TR69_ID_LEN

/* Macros for setting or getting the state of Access Control. Used inside
   IFX_AttrInfo structure for ucACL
   variable. */

/*! \def IFX_ACL_NOT_ALLOWED
    \brief Access Control not allowed
 */
#define IFX_ACL_NOT_ALLOWED           1

/*! \def IFX_ACL_ALLOWED
    \brief Access Control allowed
 */
#define IFX_ACL_ALLOWED               2

/* Macros for setting or getting the state of Notification. Used inside
   IFX_AttrInfo structure for ucNotify variable. */

/*! \def IFX_NOTIFY_NOT
    \brief Do not Notify
 */
#define IFX_NOTIFY_NOT                1

/*! \def IFX_NOTIFY_ACTIVE
    \brief Notify active
 */
#define IFX_NOTIFY_ACTIVE             2

/*! \def IFX_NOTIFY_PASSIVE
    \brief Notify passive
 */
#define IFX_NOTIFY_PASSIVE            3

/* Macros for setting or getting the state of Change Flag. Used inside
   IFX_AttrInfo structure for ucChangeFlag variable. */

/*! \def IFX_CHANGE_FLAG_CLEAR
    \brief Change Flag clear
 */
#define IFX_CHANGE_FLAG_CLEAR 1

/*! \def IFX_CHANGE_FLAG_SET
    \brief Change Flag set
 */
#define IFX_CHANGE_FLAG_SET   2

/* Macros for setting or getting the state of Param Type. Used inside
   IFX_AttrInfo structure for ucParamType variable. */

/*! \def IFX_PARAM_TYPE_RW
    \brief Param type Read write
 */
#define IFX_PARAM_TYPE_RW 1

/*! \def IFX_PARAM_TYPE_RO
    \brief Param type read only
 */
#define IFX_PARAM_TYPE_RO 2

/* Macros for setting or getting the state of DevM Indicator. Used inside
   IFX_AttrInfo structure for ucDevMInd variable. */

/*! \def IFX_DEVM_INDICATOR_CLEAR
    \brief DevM Indicator clear 
 */
#define IFX_DEVM_INDICATOR_CLEAR 1

/*! \def IFX_DEVM_INDICATOR_SET
    \brief DevM Indicator set 
 */
#define IFX_DEVM_INDICATOR_SET   2

/* Macros used for uiFlags in IFX_UpdateAttrInfo. The flags
   IFX_ATTR_INFO_OPER_MODIFY_ACL and IFX_ATTR_INFO_OPER_MODIFY_NOTIFY
   can be ORed together. */

/*! \def IFX_ATTR_INFO_F_MODIFY_ACL
    \brief IFX_UpdateAttrInfo modify access control 
 */
#define IFX_ATTR_INFO_F_MODIFY_ACL             1

/*! \def IFX_ATTR_INFO_F_MODIFY_NOTIFY
    \brief IFX_UpdateAttrInfo modify notify 
 */
#define IFX_ATTR_INFO_F_MODIFY_NOTIFY          2

/*! \def IFX_ATTR_INFO_F_MODIFY_CHANGE_FLAG
    \brief IFX_UpdateAttrInfo modify change flag
 */
#define IFX_ATTR_INFO_F_MODIFY_CHANGE_FLAG     4

/*! \def IFX_ATTR_INFO_F_MODIFY_PARAM_VALUE
    \brief IFX_UpdateAttrInfo modify param value
 */
#define IFX_ATTR_INFO_F_MODIFY_PARAM_VALUE     8

/*! \def IFX_ATTR_INFO_F_DEL
    \brief IFX_UpdateAttrInfo delete
 */
#define IFX_ATTR_INFO_F_DEL                    16

/*! \def IFX_ATTR_INFO_F_MODIFY_DEVM_INDICATOR
    \brief IFX_UpdateAttrInfo modify Devm Indicator
 */
#define IFX_ATTR_INFO_F_MODIFY_DEVM_INDICATOR  32

/* Macros used for uiOper in IFX_UpdateTr69CpeIdMap. Only one needs to be
   passed. */

/*! \def IFX_TR69ID_MAP_TBL_OPER_ADD_ENTRY
    \brief IFX_UpdateTr69CpeIdMap add entry 
 */
#define IFX_TR69ID_MAP_TBL_OPER_ADD_ENTRY  1

/*! \def IFX_TR69ID_MAP_TBL_OPER_DEL_ENTRY
    \brief IFX_UpdateTr69CpeIdMap delete entry 
 */
#define IFX_TR69ID_MAP_TBL_OPER_DEL_ENTRY  2

/* Macros used for uiOper in IFX_SendNotify. Only one needs to be
   passed. */

/*! \def IFX_NOTIFY_OPER_ADD
    \brief IFX_SendNotify operator add 
 */
#define IFX_NOTIFY_OPER_ADD    1

/*! \def IFX_NOTIFY_OPER_DEL
    \brief IFX_SendNotify operator del
 */
#define IFX_NOTIFY_OPER_DEL    2

/*! \def IFX_NOTIFY_OPER_MODIFY
    \brief Notify operator modify 
 */
#define IFX_NOTIFY_OPER_MODIFY 3

/* Macro for controlling the timeout period for which the other tasks, after
   posting a message to TR69 task, should wait for receiving reply from TR69
   task */

/*! \def IFX_TR69_PROTO_API_TIMEOUT_IN_SEC
    \brief TR69 protocal API timeout in sec
 */
#define IFX_TR69_PROTO_API_TIMEOUT_IN_SEC     60

/*! \def IFX_MALLOC
    \brief Malloc
 */
#define IFX_MALLOC(x) ({calloc(1,x);})

/*! \def IFX_FREE
    \brief Free
 */
#define IFX_FREE(x) \
if(x) \
{ \
    free(x); \
    x = NULL; \
}

/*! \def IFX_IPC_PROTO_API_FIFO
    \brief FIFO to read messages from TR69 task 
 */
#define IFX_IPC_PROTO_API_FIFO "/tmp/protoapi"

/*! \def IFX_IPC_TR_FIFO
    \brief FIFO to send messages to TR69 task
 */
#define IFX_IPC_TR_FIFO        "/tmp/tr"

/*! \def DB_FILE
    \brief db file 
 */
#define DB_FILE FILE_RC_CONF

// FIFO parameters 

/*! \def IFX_IPC_APP_ID_PSEDUO_SERVER
    \brief IPC application ID - pseduo server
 */
#define  IFX_IPC_APP_ID_PSEDUO_SERVER    100

/*! \def IFX_IPC_APP_ID_NotifyEventTask
    \brief IPC application ID - notify event task
 */
#define  IFX_IPC_APP_ID_NotifyEventTask  200

/*! \def IFX_IPC_APP_ID_NotifyPassive
    \brief IPC application ID - notify passive
 */
#define  IFX_IPC_APP_ID_NotifyPassive    201
//#define  IFX_IPC_APP_ID_TR69              7

/*! \def IFX_IPC_APP_ID_MAP
    \brief IPC Application ID - MAP
 */
#define  IFX_IPC_APP_ID_MAP              202

/*! \def IFX_IPC_APP_ID_GET_TR69ID
    \brief IPC application ID - get TR69 ID
 */
#define  IFX_IPC_APP_ID_GET_TR69ID       203

/*! \def IFX_IPC_APP_ID_ADD_OBJ
    \brief IPC application ID - add object
 */
#define  IFX_IPC_APP_ID_ADD_OBJ          204

/*! \def IFX_IPC_APP_ID_DEL_OBJ
    \brief IPC Application ID - delete object
 */
#define  IFX_IPC_APP_ID_DEL_OBJ          205

/*! \def IFX_IPC_APP_ID_ACTIVE_NOTIFY
    \brief IPC Application ID - active notify
 */
#define  IFX_IPC_APP_ID_ACTIVE_NOTIFY    206

/*! \def IFX_IPC_APP_ID_PERIODIC_INFORM
    \brief IPC Application ID - periodic inform
 */
#define  IFX_IPC_APP_ID_PERIODIC_INFORM  207

/*! \def IFX_IPC_APP_DIAGNOSTIC
    \brief IPC Application - diagnostic
 */
#define  IFX_IPC_APP_DIAGNOSTIC          208

/*! \def IFX_IPC_APP_ID_DEL_NOTIFY
    \brief IPC Application ID - delete notify
 */
#define  IFX_IPC_APP_ID_DEL_NOTIFY       209

/*! \def IFX_IPC_APP_ID_STUN
    \brief IPC Application ID - stun 
 */
#define  IFX_IPC_APP_ID_STUN	         210

/*! \def IFX_IPC_APP_ID_DHCPC
    \brief IPC Application ID - DHCPC
 */
#define  IFX_IPC_APP_ID_DHCPD	         211
#define  IFX_IPC_APP_ID_DHCPC            212
/*! \def IFX_IPC_APP_ID_BOOTSTRAP
    \brief IPC Application ID - bootstrap
 */
#define  IFX_IPC_APP_ID_BOOTSTRAP        213

/*! \def IFX_IPC_APP_ID_EVENT
    \brief IPC Application ID - event 
 */
#define  IFX_IPC_APP_ID_EVENT	         214

/*! \def IFX_IPC_APP_ID_WATCHDOG
    \brief IPC Application ID - watch dog
 */
#define  IFX_IPC_APP_ID_WATCHDOG         218

/*! \def IFX_IPC_APP_ID_DEVM_INDICATOR
    \brief IPC Application ID - Devm Indicator
 */
#define  IFX_IPC_APP_ID_DEVM_INDICATOR   219

/*! \def IFX_IPC_APP_ID_NOTIFY_INDICATOR
    \brief IPC Application ID - notify indicator 
 */
#define  IFX_IPC_APP_ID_NOTIFY_INDICATOR 220

/*! \def LTQ_IPC_APP_ID_DHCP_LEASE_CHANGE
    \brief IPC Application ID - DHCP release / renew indicator
 */

#define LTQ_IPC_APP_ID_DHCP_LEASE_CHANGE 222

// Return Types

/*! \def ERR_MAPI_INVAL_INPUT_PARAM
    \brief Error MAPI inval input param
 */
#define ERR_MAPI_INVAL_INPUT_PARAM -20

/*! \def ERR_MAPI_INVAL_OPER
    \brief Error MAPI Inval operator
 */
#define ERR_MAPI_INVAL_OPER -21

/*! \def ERR_MAPI_FIFO_OPEN
    \brief Error MAPI FIFO open 
 */
#define ERR_MAPI_FIFO_OPEN -22

/*! \def ERR_MAPI_FIFO_WRITE
    \brief Error MAPI FIFO write 
 */
#define ERR_MAPI_FIFO_WRITE -23

/*! \def ERR_MAPI_TIMEOUT
    \brief Error MAPI timeout 
 */
#define ERR_MAPI_TIMEOUT    -24

/*! \def ERR_MAPI_FIFO_READ
    \brief Error MAPI FIFO read
 */
#define ERR_MAPI_FIFO_READ -25

/*! \def ERR_MAPI_FIFO_INVAL_MSG
    \brief Error MAPI FIFO invalid message
 */
#define ERR_MAPI_FIFO_INVAL_MSG -26

/*! \def ERR_MAPI_NOT_FOUND
    \brief Error MAPI not found
 */
#define ERR_MAPI_NOT_FOUND -27

/*! \def ERR_MAPI_OUT_OF_MEMORY
    \brief Error MAPI out of memory 
 */
#define ERR_MAPI_OUT_OF_MEMORY -28

/*
** =============================================================================
**
**                                    <TYPES>
**
** =============================================================================
*/

/*!
    \brief Structure describing the CPE ID.
*/
typedef struct {
	char8 sSectionTag[IFX_MAX_SECTION_TAG_LEN];	/*!< Section Tag */
	uint32 uiId;		/*!< ID */
} IFX_CpeId;

/*!
    \brief Structure describing the ID.
*/
typedef struct {
	IFX_CpeId xCpeId;	/*!< CPE ID  */
	IFX_CpeId xParentCpeId;	/*!< Parent CPE ID */
	uint32 uiConfigOwner;	/*!< Config ower */
	char8 sTr69Id[IFX_MAX_TR69_ID_LEN];	/*!< TR 69 ID */
} IFX_Id;

/*!
    \brief Structure describing the Name valve.
*/
typedef struct {
	char8 sName[IFX_MAX_NAME_LEN];	/*!< Name */
	char8 sVal[IFX_MAX_VAL_LEN];	/*!< Value */
} IFX_NameValue;

/*!
    \brief Structure describing the TR69 notification info.
*/
typedef struct {
	char8 sTr69Id[IFX_MAX_TR69_ID_LEN];	/*!< TR 69 ID */
	int32 iParamOid;	/*!< param ID */
} IFX_NotificationInfo;

/*!
    \brief Structure describing the Attribute Information Structure.
*/
typedef struct {
	uint32 uiFlags;		/*!< flags */
	char8 sParamTag[IFX_MAX_NAME_LEN];	/*!< Parameter Tag */
	uchar8 ucACL;		/*!< ACL flag */
	uchar8 ucNotify;	/*!< Notify flag */
	uchar8 ucChangeFlag;	/*!< Change flag */
	uchar8 ucParamType;	/*!< Paramter Type flag (Read only or Read/Write) */
	uchar8 ucDevMInd;	/*!< DevM Indicator flag */
	int32 iParamOid;	/*!< OID flag */
	char8 sParamVal[IFX_MAX_VAL_LEN];	/*!< Parameter Value */
} IFX_AttrInfo;

/*!
    \brief Structure describing the dynamic devm parameters.
*/
typedef struct {
	int32 iBoot;		/*!< Boot */
	int32 iReset;		/*!< Reset */
} DYN_DEVM;

/*!
    \brief Structure describing the Devm config.
*/
typedef struct {
	int32 iMaxGetParamVal;	/*!< Get Parameter value */
	int32 iMaxGetAttrVal;	/*!< Get Attribute Value */
	int32 iMaxGetParamNames;	/*!< Get Parameter Names */
	int32 iRPCSchedInform;	/*!<  RPC Schedule Inform flag */
	int32 iRPCAddObj;	/*!< RPC Add Object flag */
	int32 iRPCDelObj;	/*!< RPC Delete Object flag */
	int32 iRPCFactReset;	/*!< RPC Factory Reset flag */
	int32 iRPCUpload;	/*!< RPC Upload flag */
        int32 iRPCGetAllQueuedTransfers;      /*!< RPC Get All Queued Transfers */
        int32 iRPCCancelTransfer;      /*!< RPC Cancel Transfer */
        int32 iRPCScheduleDownload;    /*!< ScheduleDownload */
} DEVM_CONF;

/*
** =============================================================================
**
**                              <FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*! 
    \brief This function takes the CPE ID of the parent, section name of the child and subsection name of the child if
           available and returns the TR69 ID for the child. It relies on the TR69 task for giving the TR69 ID for the
           child object.
    \param[in] pxIfxId The xParentCpeId, sSectionTag of xCpeId and uiConfigOwner members of IFX_Id structure must be filled                                       by caller. sTr69Id member of IFX_Id will be filled by the function.
    \param[in] psChildSubSectionTag The child sub section tag, if present must be passed by the caller. If not present, it must be NULL.
    \return IFX_SUCCESS/IFX_FAILURE
 */
int32 IFX_AllocTr69Id(INOUT IFX_Id * pxIfxId, IN char8 * psChildSubSectionTag);

/*! 
    \brief This function takes the section name, CPE ID, TR69 ID and the operation to be performed i.e. add or delete.
           Based on the operation it either adds the entry into section or deletes the entry from section.
    \param[in] pxIfxId - The xCpeId and sTr69Id members of IFX_ID need to be filled by the caller
    \param[in] uiOper - The operation can be either ADD or DELETE
    \return IFX_SUCCESS/IFX_FAILURE
 */
int32 IFX_UpdateTr69CpeIdMap(IN IFX_Id * pxIfxId, IN uint32 uiOper);

/*! 
    \brief This function takes the CPE ID and returns TR69 ID
    \param[in] pxIfxId The xCpeId member need to be filled by caller.sTr69Id member will be filled by the function.
    \return IFX_SUCCESS/IFX_FAILURE
 */
int32 IFX_GetTr69IdFromCpeId(INOUT IFX_Id * pxIfxId);

/*! 
    \brief Since an object can be divided into multiple sections and CPE ID is unique across section, this function takes
           the TR69 ID and returns a list of CPE IDs.
    \param[in] sTr69Id - TR69 ID for which list of CPE IDs have to be fetched.
    \param[in] puiNumCpeId - Indicates the number of entries that correspond to the TR69 ID. This will be filled by the function.
    \param[in] ppxCpeIdArray - List of all the CPE IDs that correspond to the TR69 ID. Allocation will be done by the function
                               and has to be freed by the caller.
    \return IFX_SUCCESS/IFX_FAILURE
 */
int32 IFX_GetCpeIdFromTr69Id(IN char8 sTr69Id[IFX_MAX_TR69_ID_LEN],
			     OUT uint32 * puiNumCpeId,
			     OUT IFX_CpeId ** ppxCpeIdArray);

/*! 
    \brief This function takes the CPE ID and a list of parameters for which the state of access control attribute is to be
           checked whether it is allowed. If all the parameters have access control attribute set to allowed then this                               function returns success.
    \param[in] pxCpeId - Uniquely helps in identifying object instance.
    \param[in] uiNumNV - Count stating the number of parameters for which the state of access control is to be checked.
    \param[in] pxNVArray - List of all the parameters whose access control attribute is to be checked for allowed state.
    \return IFX_SUCCESS/IFX_FAILURE
 */
int32 IFX_ChkACL(IN IFX_CpeId * pxCpeId, IN uint32 uiNumNV,
		 IN IFX_NameValue * pxNVArray);

/*! 
    \brief This function takes the CPE ID of object instance and operation to be performed on that object instance. If
           operation is MODIFY, it also takes a list of parameters that are modified. If the operation is ADD or DELETE it
           notifies TR69 task about addition or deletion of object.If operation is MODIFY it checks the parameter attribute
	   section and finds out if any notification is enabled for those parameters. For all parameters that have active
           notification enabled it notifies the TR69 task about active notification to be sent and also sets the change
           flag attribute for those parameters. For all parameters that have passive notification enabled, it sets change
           flag attribute for those parameters.
    \param[in] pxIfxId - xCpeId and uiConfigOwner members of IFX_Id structure must be filled by caller. The CPE ID is that
                         of object instance that is added, deleted or parameters of which are modified.
    \param[in] uiNumNV - Number of parameters in the following list of parameters only if operation is MODIFY. If operation is
                         ADD or DELETE, this is 0 (actually dont care).
    \param[in] pxNVArray - List of parameters that are modified only if operation is MODIFY. Only sName member of each element
                           of array has to be filled by caller. If operation is ADD or DELETE, this is NULL (actually dont care).
    \param[in] uiOper - Operation to be carried out. The operation can be ADD, Modify or DELETE.
    \return IFX_SUCCESS/IFX_FAILURE
 */
int32 IFX_SendNotify(IN IFX_Id * pxIfxId, IN uint32 uiNumNV,
		     IN IFX_NameValue * pxNVArray, IN uint32 uiOper);

/*! 
    \brief This function takes the CPE ID of object instance to be deleted and checks for delete dependency. If the object
         instance to be deleted has got any static objects below it, then these objects are deleted if required. It
         relies on TR69 task for actually performing dependency check and deletion of static objects.
    \param[in] pxIfxId - The xCpeId and uiConfigOwner members of IFX_Id structure must be filled by caller. The CPE ID is of the
                      object instance to be deletedi for which dependency check is performed.

    \return IFX_SUCCESS/IFX_FAILURE
 */
int32 IFX_DeleteObj(IN IFX_Id * pxIfxId);

/*! 
    \brief This function takes the CPE ID and a list of parameters whose attributes are required and returns the attributes                          of those parameters. If parameter entry is not present in the section, its default attributes are returned.
    \param[in] pxCpeId - Uniquely helps in identifying object instance.
    \param[in] uiNumAttrInfo - Count stating the number of parameters whose attribute information is required.
    \param[in] pxAttrInfoArray - List of parameters whose attribute information is required. Only sParamTag member of each
                      element of the array has to be filled by caller. This function will fill the attribuites of parameters in this
                       array. uiFlags member of each element in array is not filled by the function.
    \return IFX_SUCCESS/IFX_FAILURE
 */
int32 IFX_GetAttrInfo(IN IFX_CpeId * pxCpeId, IN uint32 uiNumAttrInfo,
		      INOUT IFX_AttrInfo * pxAttrInfoArray);

/*! 
    \brief This function takes the CPE ID and a list of parameters whose attributes are to be updated and updates the
           attributes of those parameters. Based on flag set for individual element in the array, corresponding attribute
           is updated. Flag can be set for modifying access control attribute, notification attribute, change flag attribute,
           devm indicator or parameter value attribute of element in array. For any parameter access control and notification
           attributes can be modified at one go by ORing respective flags. There is also special delete flag for explicitly
           deleting the entry of the parameter from that section.
    \param[in] pxCpeId - Uniquely helps in identifying object instance.
    \param[in] uiNumAttrInfo - Count stating the number of parameters whose attribute information is to be updated.
    \param[in] pxAttrInfoArray - List of all the parameters whose attribute information is to be updated. The function 
                       will update the attribuite information of parameters in this array based on flag associated with that parameter

    \return IFX_SUCCESS/IFX_FAILURE
 */
int32 IFX_UpdateAttrInfo(IN IFX_CpeId * pxCpeId, IN uint32 uiNumAttrInfo,
			 IN IFX_AttrInfo * pxAttrInfoArray);

/*! 
    \brief This function takes the section name and gives the list of all parameters of all instances within that section
           for which notification attribute is enabled. In case the parameter is read write, it updates the list
           with parameter name only if the change flag attribute for that parameter is set. In case the parameter is
           read only, it simply updates list with parameter name.

    \param[in] psSectionTag - Section name from which parameters have to be identified whose notification attribute is enabled.
    \param[out] puiNumNotificationInfo - Count of number of parameters in list of notification info. This is filled by function.
    \param[out] ppxNotificationInfoArray - List of all parameters in the requested section for which notification attribute is
                set to passive or active  and either parameter is of type read write with change flag attribute set or parameter
                is of type read only. This list is allocated by the function and has to be freed by the caller.
    \return IFX_SUCCESS/IFX_FAILURE
 */
int32 IFX_GetNotificationInfo(IN char8 * psSectionTag,
			      OUT uint32 * puiNumNotificationInfo,
			      OUT IFX_NotificationInfo **
			      ppxNotificationInfoArray);

/*!
    \brief This function returns a buffer containing all the available instances of all the objects. The instances
           are separated by '/n'. The buffer is terminated by '/0'.
    \param[in] ppsBuff - The buffer containing all available instances of all objects. Allocation is done by the function
    \return IFX_SUCCESS/IFX_FAILURE
 */

int32 IFX_GetTr69Instances(OUT char8 ** ppsBuff);

/*! 
    \brief This function refreshes the list of instances in the instance section. It gets a buffer containing all the
         available instances of all the objects. The instances are separated by '/n'. The buffer is terminated by '/0'
    \param[in] psBuff - The buffer containing all available instances of all objects
    \return IFX_SUCCESS/IFX_FAILURE
 */
int32 IFX_SetTr69Instances(IN char8 * psBuff);

/*! 
    \brief This function combines the TR69 instance entries received in the backup buffer with the current TR69 instance
          section entries, rearranges the numerical sequence and adds back as the entire tr69_instances section    
    \param[in] psBkupBuff - The buffer containing partially backed-up tr69 instances
    \return IFX_SUCCESS/IFX_FAILURE
 */

int32 IFX_UpdateTr69Instances(IN char8 * psBkupBuff);

/*! 
    \brief This function takes the CPE ID and deletes entries from attribute section related to the section tag in CPE ID.
           Only those entries in that attribure section are deleted whose CPE ID matches with ID present in CPE ID structure
    \param[in] pxCpeId - The section tag and ID members of CPE ID structure MUST be filled by caller. Section tag helps in
                      identifying the attribute section. The ID helps in identifying the entry to be deleted.
     \return IFX_SUCCESS/IFX_FAILURE
 */
int32 IFX_DeleteAttrInfo(IN IFX_CpeId * pxCpeId);

/*! 
    \brief This function forms an IPC  message and posts it to TR69 task
    \param[in] pxIfxId
    \param[in] uiNumNV
    \param[in] pxNVArray
    \param[in] iType
    \param[in] iState
    \return IFX_SUCCESS/IFX_FAILURE
 */
int32 IFX_EventNotify(IN IFX_Id * pxIfxId, IN uint32 uiNumNV,
		      IN IFX_NameValue * pxNVArray, IN int32 iType,
		      IN int32 iState);

/*! 
    \brief This function flags as input and sets devm boot and reset paramters 
    \param[in] iOper
    \param[in] pxDevm
    \param[in] uiFlags
    \return IFX_SUCCESS/IFX_FAILURE
 */
int32 ifx_set_devm_dyn(IN int32 iOper, IN DYN_DEVM * pxDevm, IN uint32 uiFlags);

/*! 
    \brief This function receives flags as input and returns devm boot and reset paramters as output 
    \param[out] pxDevm
     \param[in] uiFlags
    \return IFX_SUCCESS/IFX_FAILURE
 */
int32 ifx_get_devm_dyn(OUT DYN_DEVM * pxDevm, IN uint32 uiFlags);

/*! 
    \brief This function receives flags as input and returns the devm configuration parameters as output 
    \param[out] pxDevm
    \param[in] uiFlags
    \return IFX_SUCCESS/IFX_FAILURE
 */

int32 ifx_get_devm_conf(OUT DEVM_CONF * pxDevm, IN uint32 uiFlags);

#endif				/* __IFIN_PROTO_API_H__ */
