
/* 
** =============================================================================
**   FILE NAME        : ifx_api_include.h
**   PROJECT          : AMAZON MAPI
**   DATE             : 19-Jun-2006
**   AUTHOR           : Amazon API Team
**   DESCRIPTION      : This file includes all the other Management API header files.

**   REFERENCES       : 
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/
/*! \file ifx_api_include.h 
	\brief This file includes all the other Management API header files
*/

#ifndef _IFX_API_INCLUDE_H
#define _IFX_API_INCLUDE_H

#include "ifx_api_defs.h"
#include "ifx_api_enums.h"
#include "ifx_api_structs.h"
#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
#include "dw_daemon.h"
#endif
#include "ifx_api_proto.h"

#endif				// _IFX_API_INCLUDE_H
