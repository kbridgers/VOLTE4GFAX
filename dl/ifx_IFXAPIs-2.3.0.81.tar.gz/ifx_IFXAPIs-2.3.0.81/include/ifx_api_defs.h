
/* 
** =============================================================================
**   FILE NAME        : ifx_api_defs.h
**   PROJECT          : AMAZON MAPI
**   DATE             : 19-Jun-2006
**   AUTHOR           : Amazon API Team
**   DESCRIPTION      : This file contains all the macro definitions required for the
			Management API Implementation.

**   REFERENCES       : 
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/
/*! \file ifx_api_defs.h
    \brief This file defines the constants and macros required in MAPI.	
*/

#ifndef _IFX_API_DEFS_H
#define _IFX_API_DEFS_H

#ifndef PORT_NUM
/*! \def PORT_NUM
    \brief Macro that defines the Port Number.
 */
#define PORT_NUM 15		/*!< Port Number */
#endif

#ifndef MAX_ALG_NAME_LENGTH
/*! \def MAX_ALG_NAME_LENGTH
    \brief Macro that defines the maximum length of ALG name.
*/
#define MAX_ALG_NAME_LENGTH 20	/*!< Maximum length of ALG Name. */
#endif

#ifndef IFNAMSIZE
/*! \def IFNAMSIZE
    \brief Macro that defines the maximum length of Interface Name.
*/
#define IFNAMSIZE 15		/*!<  Maximum length of Interface Name */
#endif

#ifndef MAX_NAME_LEN
/*! \def MAX_NAME_LEN
    \brief Macro that defines the Maximum name length (Used in Name-Value Pair struct)
*/
#define MAX_NAME_LEN 96		/*!<  Maximum name length (Used in Name-Value Pair struct) */
#endif

#ifndef MAX_SECLVL_LEN
/*! \def MAX_SECLVL_LEN
    \brief Macro that defines the maximum section length.
*/
#define MAX_SECLVL_LEN 10	/*!< Maximum Section Length */
#endif

#ifndef MAX_PROTO_LEN
/*! \def MAX_PROTO_LEN
    \brief Macro that defines the Maximum Protocol length.
*/
#define MAX_PROTO_LEN 5		/*!<  Maximum Protocol length. */
#endif

#ifndef MAX_NAME_SIZE
/*! \def MAX_NAME_SIZE
    \brief Macro that defines the  Maximum Name Size
*/
#define MAX_NAME_SIZE 20	/*!< Maximum Name Size */
#define MAX_PASSWORD_SIZE  256
#endif

#ifndef MAX_PASSWORD_SIZE 
/*! \def MAX_PASSWORD_SIZE
    \brief Macro that defines the MAX_PASSWORD_SIZE
*/
#define MAX_PASSWORD_SIZE  256
#endif

#ifndef MAX_FILTERENTRY
/*! \def MAX_FILTERENTRY
    \brief Macro that defines the Maximum no. of filters.
*/
#define MAX_FILTERENTRY 50	/*!< Maximum no. of filters.  */
#endif

#ifndef MAX_VCCENTRY
/*! \def MAX_FILTERENTRY
    \brief Macro that defines the Maximum number of VCC Entries.
*/
#define MAX_VCCENTRY 50		/*!< Maximum number of VCC Entries. */
#endif

#ifndef MAX_DATA_LEN
/*! \def MAX_DATA_LEN
    \brief Macro that defines the Maximum length of value filed in Name-Value Pair.
*/
#define MAX_DATA_LEN 2*1024	/*!< Maximum length of value filed in Name-Value Pair.  */
#endif

#ifndef MAX_SECTION_DATA_LEN
/*! \def MAX_SECTION_DATA_LEN
    \brief Macro that defines the Maximum size of Section in System Cfg DB.
*/
#define MAX_SECTION_DATA_LEN 30*1024	/*!< Maximum size of Section in System Cfg DB.  */
#endif

/* make sure to change MAX_FILELINE_LEN in ifx_common.h if its value is changed */
#ifndef MAX_FILELINE_LEN
/*! \def MAX_FILELINE_LEN
    \brief Macro that defines the Maximum File name length.
*/
#define MAX_FILELINE_LEN	(MAX_TAG_NAME_LEN + MAX_TAG_VALUE_LEN + 4)	/*!<  Maximum File name length. */
#endif

#ifndef MAX_TAG_NAME_LEN
/*! \def MAX_TAG_NAME_LEN
    \brief Macro that defines the maximum tag name length.
*/
#define MAX_TAG_NAME_LEN	68	/*!< Maximum tag name length. */
#endif

#ifndef MAX_TAG_VALUE_LEN
/*! \def MAX_TAG_VALUE_LEN
    \brief Macro that defines the tag value length.
*/
#define MAX_TAG_VALUE_LEN	260	/*!< Maximum tag value length. */
#endif

#ifndef MAX_SNMP_COMMUNITY_STR
/*! \def MAX_SNMP_COMMUNITY_STR
    \brief Macro that defines the Maximum name for SNMP Community in string format.
*/
#define MAX_SNMP_COMMUNITY_STR 50	/*!< Maximum name for SNMP Community in string format. */
#endif

#ifndef MAX_SSID_LEN
/*! \def MAX_SSID_LEN
    \brief Macro that defines the Maximum length of SSID for WLAN.
*/
#define MAX_SSID_LEN 50		/*!< Maximum length of SSID for WLAN. */
#endif

#ifndef MAX_ESSID_LEN
/*! \def MAX_ESSID_LEN
    \brief Macro that defines the Maximum ESSID length for WLAN.
*/
#define MAX_ESSID_LEN 50	/*!< Maximum ESSID length for WLAN. */
#endif

#ifndef MAX_AP_LEN
/*! \def MAX_AP_LEN
    \brief Macro that defines the max AP length.
*/
#define MAX_AP_LEN 50		/*!< Maximum AP length. */
#endif

#ifndef MAX_PREAMBLE_LEN
/*! \def MAX_PREAMBLE_LEN
    \brief Macro that defines the maximum preamble length.
*/
#define MAX_PREAMBLE_LEN 50	/*!< Maximum preamble length. */
#endif

#ifndef MAX_DOMAIN_NAME_LEN
/*! \def MAX_DOMAIN_NAME_LEN
    \brief Macro that defines the maximum domain name length.
*/
#define MAX_DOMAIN_NAME_LEN 50	/*!< Maximum domain name length. */
#endif

#ifndef MAX_HOST_LEN
/*! \def MAX_HOST_LEN
    \brief Macro that defines the Maximum Host name length.
*/
#define MAX_HOST_LEN 50		/*!< Maximum Host name length. */
#endif

#ifndef MAX_USER_LEN
/*! \def MAX_USER_LEN
    \brief Macro that defines Maximum Username length.
*/
#define MAX_USER_LEN 50		/*!< Maximum Username length. */
#endif

#ifndef MAX_PASSWD_LEN
/*! \def MAX_PASSWD_LEN
    \brief Macro that defines the maximum length of the password.
*/
#define MAX_PASSWD_LEN 50	/*!< Maximum length of the password. */
#endif

#ifndef MAX_IF_NAME_LEN
/*! \def MAX_IF_NAME_LEN
    \brief Macro that defines the Maximum Interface Name Length.
*/
#define MAX_IF_NAME_LEN 50	/*!< Maximum Interface Name Length. */
#endif

#ifndef MAX_KEY_LEN
/*! \def MAX_KEY_LEN
    \brief Macro that defines the Maximum Key length for security.
*/
#define MAX_KEY_LEN 50		/*!< Maximum Key length for security. */
#endif

#ifndef MAX_PSK_LEN
/*! \def MAX_PSK_LEN
    \brief Macro that defines the Maximum Public Service Key Length.
*/
#define MAX_PSK_LEN 50		/*!< Maximum Public Service Key Length. */
#endif

#ifndef MAX_RADIUS_SECRET
/*! \def MAX_RADIUS_SECRET
    \brief Macro that defines the Maximum RADIUS Secret length.
*/
#define MAX_RADIUS_SECRET 50	/*!< Maximum RADIUS Secret length. */
#endif

#ifndef MAX_NAS_ID_LEN
/*! \def MAX_NAS_ID_LEN
    \brief Macro that defines the Maximum NAS Id length.
*/
#define MAX_NAS_ID_LEN 50	/*!< Maximum NAS Id length. */
#endif

#ifndef MAX_DOMAIN_NAME
/*! \def MAX_DOMAIN_NAME
    \brief Macro that defines the maximum domain name.
*/
#define MAX_DOMAIN_NAME 50	/*!< Maximum domain name. */
#endif

#ifndef MAX_CLI_ID_LEN
/*! \def MAX_CLI_ID_LEN
    \brief Macro that defines the Maximum CLI Identifier Length.
*/
#define MAX_CLI_ID_LEN 50	/*!< Maximum CLI Identifier Length. */
#endif

#ifndef MAX_TR69_ID_LEN
/*! \def MAX_TR69_ID_LEN
    \brief Macro that defines the Maximum TR-069 Identifier Length.
*/
#define MAX_TR69_ID_LEN 256	/*!< Maximum TR-069 Identifier Length. */
#endif

#ifndef MAX_FIELD_RANGE
/*! \def MAX_FIELD_RANGE
    \brief Macro that defines the maximum field range.
*/
#define MAX_FIELD_RANGE 32	/*!< Maximum field range. */
#endif

#ifndef MAX_IP_ADDR_LEN
/*! \def MAX_IP_ADDR_LEN
    \brief Macro that defines the maximum IP address length.
*/
#define MAX_IP_ADDR_LEN	16	/*!< Maximum IP address length. */
#endif

#ifndef MAX_IP6_ADDR_LEN
/*! \def MAX_IP_ADDR_LEN
    \brief Macro that defines the maximum IP address length.
*/
#define MAX_IP6_ADDR_LEN 39		/*!< Maximum IP address length. */
#endif

#ifndef MAX_PPP_USER_NAME_PASSWD_LEN
/*! \def MAX_PPP_USER_NAME_PASSWD_LEN
    \brief Macro that defines the Maximum PPP User Name and Password for Authentication.
*/
#define MAX_PPP_USER_NAME_PASSWD_LEN 64	/*!< Maximum PPP User Name and Password for Authentication. */
#endif

#ifndef CHKPOINT_FILE
/*! \def CHKPOINT_FILE
    \brief Macro that defines the  checkpoint file name for rollback feature.
*/
#define CHKPOINT_FILE "/tmp/rc.conf.tmp"	/*!< CHKPOINT_FILE */
#endif

#define TMP_CHECKPOINT CHKPOINT_FILE	/*!< Temp Checkpoint file  */

#ifndef CHKPOINT_FILE2
/*! \def CHKPOINT_FILE2
    \brief Macro that defines the secondary checkpoint file
*/
#define CHKPOINT_FILE2 "/tmp/rc.conf.tmp2"	/*!<  Copy of rc.conf */
#endif
/*! \def TMP_CHECKPOINT2
    \brief Macro that defines the  temporary secondary checkpoint file.
*/
#define TMP_CHECKPOINT2 CHKPOINT_FILE2	/*!<  Temporary secondary checkpint file */

#ifndef TMP_STATIC_ROUTE
/*! \def TMP_STATIC_ROUTE
    \brief Macro that defines the temporary static route.
*/
#define TMP_STATIC_ROUTE "/tmp/staticRoute"	/*!<  Temporary Static Route */
#endif

#ifndef MAX_DNS_SERVERS
/*! \def MAX_DNS_SERVERS
    \brief Macro that defines the maximum number of supported DNS Servers.
*/
#define MAX_DNS_SERVERS 5	/*!<  Maximum number of DNS Servers */
#endif

#ifndef MAX_DHCP_RESV_POOL_ADDR
/*! \def MAX_DHCP_RESV_POOL_ADDR
    \brief Macro that defines the Maximum DHCP Reserved Pool of IP address.
*/
#define MAX_DHCP_RESV_POOL_ADDR 10	/*!<  Maximum DHCP Reserved Pool of IP address. */
#endif

#ifdef CONFIG_FEATURE_SAMBA	// SAMBA
#ifndef MAX_USERS
/*! \def MAX_USERS
    \brief Macro that defines the maximum number of users.
*/
#define MAX_USERS 8		/*!<  Maximum number of users */
#endif

#ifndef MAX_SHARES
/*! \def MAX_SHARES
    \brief Macro that defines the maximum number of shares.
*/
#define MAX_SHARES 16		/*!<  Maximum number of shares */
#endif
#endif

/*! \def IFX_WLAN_MAX_SUPPORTED_CHANNELS
    \brief Macro that defines maximum number of supported WLAN Channels. 
*/
#define IFX_WLAN_MAX_SUPPORTED_CHANNELS 25	/*!<  Max no of supported channels */

#ifndef IFX_MAPI_PSK_MAX_LEN
/*! \def IFX_MAPI_PSK_MAX_LEN
    \brief Macro that defines the maximum PSK length for WLAN Security.
*/
#define IFX_MAPI_PSK_MAX_LEN           65	/*!<  String length for pre-shared Key (64 hex digits) */
#endif				/* #ifndef IFX_MAPI_PSK_MAX_LEN */

#ifndef IFX_MAPI_PASSPHRASE_MAX_LEN
/*! \def IFX_MAPI_PASSPHRASE_MAX_LEN
    \brief Macro that defines the Passphrase secret for WLAN Security.
*/
#define IFX_MAPI_PASSPHRASE_MAX_LEN	   64	/*!<  Maximum string length of passphrase (8..63 characters) */
#endif				/* #ifndef IFX_MAPI_PASSPHRASE_MAX_LEN */

#ifndef IFX_MAPI_RADIUS_AUTH_DOMAIN
/*! \def IFX_MAPI_RADIUS_AUTH_DOMAIN
    \brief Macro that defines the RADIUS domain name length for WLAN.
*/
#define IFX_MAPI_RADIUS_AUTH_DOMAIN	   256	/*!<  RADIUS Athentication Domain Name */
#endif				/* #ifndef IFX_MAPI_RADIUS_AUTH_DOMAIN */

#ifndef IFX_MAPI_RADIUS_AUTH_USER
/*! \def IFX_MAPI_RADIUS_AUTH_USER
    \brief Macro that defines the  user name string length for RADIUS Authentication.
*/
#define IFX_MAPI_RADIUS_AUTH_USER	   64	/*!<  RADIUS Authentication User */
#endif				/* #ifndef IFX_MAPI_RADIUS_AUTH_USER */

#ifndef IFX_MAX_NUMBER_OF_CHANNELS
/*! \def IFX_MAX_NUMBER_OF_CHANNELS
    \brief Macro that defines the maximum number of channels.
*/
#define IFX_MAX_NUMBER_OF_CHANNELS 64	/*!<  Maximum number of channels */
#endif

/*! \def IFX_WEB
    \brief Macro that defines the WEB Management Entity used for owner information in IFX_ID.
*/
#define IFX_WEB					1	/*!<  WEB Management Entity used for owner information in IFX_ID. */

/*! \def IFX_TR69
    \brief Macro that defines the TR-069 Management Entity used for owner information in IFX_ID.
*/
#define IFX_TR69				2	/*!<  TR-069 Management Entity used for owner information in IFX_ID. */

/*! \def IFX_ROOT
    \brief Macro that defines the  system as owner in IFX_ID.
*/
#define IFX_ROOT				3	/*!<  System - Dynamic Management */

/*! \def IFX_TR64
    \brief Macro that defines the  TR-064 Management Entity used for owner information in IFX_ID.
*/
#define IFX_TR64				4	/*!<  TR-064 Management Entity */

/*! \def IFX_SNMP
    \brief Macro that defines the  SNMP Management Entity used for owner information in IFX_ID.
*/
#define IFX_SNMP				5	/*!<  SNMP Management Entity */

/*! \def IFX_VOIP
    \brief Macro that defines the  VoIP Management Entity used for owner information in IFX_ID.
*/
#define IFX_VOIP				6	/*!<  VoIP Management Entity */
#define IFX_UPNP				9	/*!<  UPnP Management Entity */

/*! \def LTQ_AUTO_DETECT
    \brief Macro that defines the WAN auto-detect Entity used for owner information in IFX_ID.
*/
#define LTQ_AUTO_DETECT                         10      /*!<  Auto detect Management Entity */

/*! \def MAX_AUTH_PARAM_LONG_LEN
    \brief Macro that defines the Maximum Authenticating Long Parameter Length.
*/
#define MAX_AUTH_PARAM_LONG_LEN 65	/*!<  Maximum Authenticating Long Parameter Length. */

/*! \def MAX_AUTH_PARAM_SHORT_LEN
    \brief Macro that defines the Maximum Authentication Short Parameter Length.
*/
#define MAX_AUTH_PARAM_SHORT_LEN 9	/*!<  Maximum Authentication Short Param Length. */

/*! \def MAX_COMMAND_KEY_LEN
    \brief Macro that defines the Maximum Command Key Length.
*/
#define MAX_COMMAND_KEY_LEN 33	/*!<  Maximum Command Key Length. */

/*! \def MAX_FILE_NAME_LEN
    \brief Macro that defines the Maximum File Name Length.
*/
#define MAX_FILE_NAME_LEN 257	/*!<  Maximum File Name Length. */

/*! \def MAX_EVENT_LEN
    \brief Macro that defines the Maximum Event Length.
*/
#define MAX_EVENT_LEN 17	/*!<  Maximum Event Length. */

/*! \def MAX_AUTH_TYPE_LEN
    \brief Macro that defines the Maximum Authentication Length.
*/
#define MAX_AUTH_TYPE_LEN 9	/*!<  Maximum Authentication Length. */

/*! \def MAX_MANUFACTURER_LEN
    \brief Macro that defines the Maximum Manufacture String name used in DeviceInfo object.
*/
#define	MAX_MANUFACTURER_LEN	65	/*!<  Maximum Manufacture String name used in DeviceInfo object. */

/*! \def MAX_OUI_LEN
    \brief Macro that defines the Maximum IEEE OUI Identifier length used in DeviceInfo object.
*/
#define	MAX_OUI_LEN 			33	/*!<  Maximum IEEE OUI Identifier length used in DeviceInfo object. */

/*! \def MAX_MODEL_LEN
    \brief Macro that defines the Maximum string length for Device Model Name.
*/
#define	MAX_MODEL_LEN 			65	/*!<  Maximum string length for Device Model Name. */

/*! \def MAX_DESCRIPTION_LEN
    \brief Macro that defines the Maximum string for description of Device.
*/
#define	MAX_DESCRIPTION_LEN 	257	/*!<  Maximum string for description of Device. */

/*! \def MAX_PROD_CLASS_LEN
    \brief Macro that defines the Maximum string for product class for Device Info.
*/
#define	MAX_PROD_CLASS_LEN 		65	/*!<  Maximum string for product class for Device Info. */

/*! \def MAX_SERIAL_NUM_LEN
    \brief Macro that defines the Maximum String Size for Serial Number of Product.
*/
#define	MAX_SERIAL_NUM_LEN 		65	/*!<  Maximum String Size for Serial Number of Product. */

/*! \def MAX_IPADDR_LIST_LEN
    \brief Macro that defines the 
*/
#define	MAX_IPADDR_LIST_LEN 		1024	/*!<  Maximum number of IP address list */

/*! \def MAX_VER_LEN
    \brief Macro that defines the Maximum string for version length.
*/
#define	MAX_VER_LEN 			65	/*!<  Maximum string for version length. */

/*! \def SPEC_VER_LEN
    \brief Macro that defines the Maximum string for specifications version length.
*/
#define	SPEC_VER_LEN 			17	/*!<  Maximum string for specifications version length. */

/*! \def MAX_PROVISION_LEN
    \brief Macro that defines the Maximum string for provision information.
*/
#define	MAX_PROVISION_LEN 		65	/*!<  Maximum string for provision information. */

/*! \def MAX_MAC_ADDR_LEN
    \brief Macro that defines the MAC Address size in terms of bytes.
*/
#define	MAX_MAC_ADDR_LEN 			18	/*!<  MAC Address size in terms of bytes. */

/*! \def MAX_VS_DESC_LEN
    \brief Macro that defines the Virtual Server (Port Mapping) Description Length.
*/
#define	MAX_VS_DESC_LEN 		257	/*!<  Virtual Server (Port Mapping) Description Length. */

/*! \def MAX_CONN_NAME_LEN
    \brief Macro that defines the Connection Name Size.
*/
#define MAX_CONN_NAME_LEN		257	/*!<  Connection Name Size. */

/*! \def MAX_MODEL_NUM_LEN
    \brief Macro that defines the maximum number of connections.
*/
#define MAX_MODEL_NUM_LEN               17 /*!<   */	// ORP: Added for TR-064 Model Number

/*! \def MAX_TR64_URL_LEN
    \brief Macro that defines the model name in TR-064 device info.
*/
#define MAX_TR64_URL_LEN                257 /*!<   */	// ORP: Added for TR-064 Generic URL

/*! \def MAX_DHCPOPTION_VALUE_LEN
    \brief Macro that defines the length of DHCP option value.
*/
#define MAX_DHCPOPTION_VALUE_LEN        65  /*!<   */	//ORP: Added for DHCPOption Value support

/*! \def MAX_SYS_CONTACT_LEN
    \brief Macro that defines the System Contact Length.
*/
#define MAX_SYS_CONTACT_LEN         255	/*!<  System Contact Max */

/*! \def MAX_SYS_LOCATION_LEN
    \brief Macro that defines the system location length.
*/
#define MAX_SYS_LOCATION_LEN        255	/*!<  System Location Max */

/*! \def MAX_SYS_NAME_LEN
    \brief Macro that defines the maximumlength of system name.
*/
#define MAX_SYS_NAME_LEN		    255	/*!<  Maximum System Name */

/*! \def MAX_SYS_OBJID_LEN
    \brief Macro that defines the maximum object id length. 
*/
#define MAX_SYS_OBJID_LEN			255	/*!<  Maximum Object Id Length */

/*! \def MAX_URL_LEN
    \brief Macro that defines the Maximum Size for URL
*/
#define MAX_URL_LEN                257	/*!<  Maximum Size for URL. */

/*! \def MAX_UNAME_LEN
    \brief Macro that defines the Maximum string size for UserName.
*/
#define MAX_UNAME_LEN              257	/*!<  Maximum string size for UserName. */

/*! \def MAX_PASSWORD_LEN
    \brief Macro that defines the maximum Password length.
*/
#define MAX_PASSWORD_LEN           257	/*!<  Maximum string size for Password. */

/*! \def MAX_PARAMETER_KEY_LEN
    \brief Macro that defines the Maximum string size for Password.
*/
#define MAX_PARAMETER_KEY_LEN      33	/*!<  Maximum Parameter Key Length. */

/*! \def MAX_CONN_REQ_URL_LEN
    \brief Macro that defines the Maximum Parameter Key Length.
*/
#define MAX_CONN_REQ_URL_LEN       257	/*!<  Maximum Connection Request URL Length. */

/*! \def MAX_CONN_REQ_UNAME_LEN
    \brief Macro that defines the Maximum Connection Request URL Length.
*/
#define MAX_CONN_REQ_UNAME_LEN     257	/*!<  Maximum Connection Request UserName Length. */

/*! \def MAX_CONN_REQ_PASSWD_LEN
    \brief Macro that defines the Maximum Connection Request UserName Length.
*/
#define MAX_CONN_REQ_PASSWD_LEN    257	/*!<  Maximum Connection Request Password Length. */

/*! \def MAX_KICK_URL_LEN
    \brief Macro that defines the Maximum Connection Request Password Length.
*/
#define MAX_KICK_URL_LEN           257	/*!<  Maximum Kick URL Length. */

/*! \def MAX_DNLD_PROGRESS_URL_LEN
    \brief Macro that defines the Maximum Kick URL Length.
*/
#define MAX_DNLD_PROGRESS_URL_LEN  257	/*!<  Maximum Download Progress URL Length. */

/*! \def IFX_OP_ADD
    \brief Macro that defines the Addition type of operation used in SET API.
*/
#define IFX_OP_ADD				1	/*!<  Addition type of operation used in SET API. */

/*! \def IFX_OP_DEL
    \brief Macro that defines the Deletion type of operation used in SET API.
*/
#define IFX_OP_DEL				2	/*!<  Deletion type of operation used in SET API. */

/*! \def IFX_OP_MOD
    \brief Macro that defines the Modification type of operation used in SET API.
*/
#define IFX_OP_MOD				3	/*!<  Modification type of operation used in SET API. */

/*! \def IFX_OP_DHCP_RELEASE
    \brief Macro that defines the DHCP Release Operation.
*/
#define IFX_OP_DHCP_RELEASE		4	/*!<  DHCP Release Operation */

/*! \def IFX_OP_DHCP_RENEW
    \brief Macro that defines the DHCP Renew Operation.
*/
#define IFX_OP_DHCP_RENEW		5	/*!<  DHCP Renew Operation */

/*! \def IFX_OP_APPLY
    \brief Macro that defines the Operation to denote Apply or Commit.
*/
#define IFX_OP_APPLY			3	/*!<  Operation to denote Apply or Commit. */

/*! \def DUPLICATE_ENTRY
    \brief Macro that defines the Duplicate Entry flag.
*/
#define DUPLICATE_ENTRY			-2	/*!<  Duplicate Entry flag. */

/*! \def IFX_DHCP_SERVER_MODE
    \brief Macro that defines the DHCP Server Mode.
*/
#define IFX_DHCP_SERVER_MODE	1	/*!<  DHCP Server Mode. */

/*! \def IFX_DHCP_RELAY_MODE
    \brief Macro that defines the DHCP Relay Mode.
*/
#define IFX_DHCP_RELAY_MODE		2	/*!<  DHCP Relay Mode. */

/*! \def IFX_SUPPORTED
    \brief Macro that defines the feature is Supported in System.
*/
#define IFX_SUPPORTED			1	/*!<  Supported in System. */

/*! \def IFX_NOT_SUPPORTED
    \brief Macro that defines the feature is  Not Supported in System.
*/
#define IFX_NOT_SUPPORTED		0	/*!<  Not Supported in System. */

/*! \def IFX_ENABLED
    \brief Macro that defines the Enabled specifier.
*/
#define IFX_ENABLED				1	/*!<  Enabled specifier. */

/*! \def IFX_DISABLED
    \brief Macro that defines the Disabled Specifier
*/
#define IFX_DISABLED			0	/*!<  Disabled Specifier */

/*! \def IFX_SUCCESS
    \brief Macro that defines the Success Return Code.
*/
#define IFX_SUCCESS				0	/*!<  Success Return Code. */

/*! \def IFX_FAIL
    \brief Macro that defines the Failure Return Code.
*/
#define IFX_FAIL				-1	/*!<  Failure Return Code. */

/*! \def IFX_FAILURE
    \brief Macro that defines the Failure Return Code.
*/
#define IFX_FAILURE				IFX_FAIL	/*!<  Failure Return Code. */

/*! \def IFX_DUPLICATE_ENTRY
    \brief Macro that defines the duplicate entry error code.
*/
#define IFX_DUPLICATE_ENTRY		-2	/*!<  Duplicate Entry Error Code */

/*! \def VS_FOUND_ON_WAN_CONN
    \brief Macro that defines the error code to indicate Virtual server entries exist on WAN connection.
*/
#define VS_FOUND_ON_WAN_CONN		-11	/*!<  Virtual server entries exist on WAN connection to be deleted */

/*! \def MCAST_FOUND_ON_WAN_CONN
    \brief Macro that defines the error code to indicate Multicast entries exist on WAN connection.
*/
#define MCAST_FOUND_ON_WAN_CONN		-12	/*!<  Multicast entries exist on WAN connection to be deleted */

/*! \def FW_PF_FOUND_ON_WAN_CONN
    \brief Macro that defines the error code to indiate Firewall packetfilter entries exist on WAN connection.
*/
#define FW_PF_FOUND_ON_WAN_CONN		-13	/*!<  Firewall packetfilter entries exist on WAN connection to be deleted - error code */

/*! \def IPSEC_FOUND_ON_WAN_CONN
    \brief Macro that defines the error code to indicate IPSec entries exist on WAN connection.
*/
#define IPSEC_FOUND_ON_WAN_CONN		-14	/*!<  IPSec entries found on WAN connection to be deleted - error code*/

/*! \def IFX_CT_CMDKEY_NOT_FOUND
    \brief Macro that defines command key not found for CancelTransferRPC
*/
#define IFX_CT_CMDKEY_NOT_FOUND                 1	/*!< Command Key not found to cancel transfer */

/*! \def IFX_CT_SCHEDULE_NEXT
    \brief Macro that defines transfer to be scheduled after cancelling pending transfer
*/
#define IFX_CT_SCHEDULE_NEXT                    2	/*!< Schedule transfer after cancelling present transfer */

/*! \def IFX_CT_ONLY
    \brief Macro that defines no transfer to be scheduled after cancelling present transfer
*/
#define IFX_CT_ONLY                             3	/*!< No transfer to be scheduled after cancelling present transfer */

/*! \def IFX_TRANSFER_ISCOMPLETE_COMPLETE
    \brief Macro that defines state of a transfer
*/
#define IFX_TRANSFER_ISCOMPLETE_COMPLETE    1   /*!< Transfer is complete fully */

/*! \def IFX_TRANSFER_ISCOMPLETE_INPROGRESS
    \brief Macro that defines state of a transfer
*/
#define IFX_TRANSFER_ISCOMPLETE_INPROGRESS        2  /*!< Transfer is in progress */

/*! \def IFX_TRANSFER_ISCOMPLETE_DEFAULT 
    \brief Macro that defines state of a transfer
*/
#define IFX_TRANSFER_ISCOMPLETE_DEFAULT        0  /*!< Transfer is incomplete */

/*! \def IFX_PCR_CHK_FAIL
    \brief Macro that defines the PCR Check has failed. 
*/
#define	IFX_PCR_CHK_FAIL		-4	/*!<  PCR Check Failer Error */

/*! \def MAX_IF_NAME
    \brief Macro that defines the Maximum Interface name.
*/
#define MAX_IF_NAME                257	/*!<  Maximum Interface name. */

/*! \def MAX_HOST_NAME
    \brief Macro that defines the Maximum Host Name.
*/
#define MAX_HOST_NAME              257	/*!<  Maximum Host Name. */

/*! \def MAX_DIAGSTATE_LEN
    \brief Macro that defines the Maximum Diagnostic State Length.
*/
#define MAX_DIAGSTATE_LEN          65	/*!<  Maximum Diagnostic State Length. */

/*! \def MAX_NTP_SERVER_LEN
    \brief Macro that defines the  maximum NTP Server string length.
*/
#define MAX_NTP_SERVER_LEN         65	/*!<  NTP Server Length */

/*! \def MAX_TIME_ZONE_NAME_LEN
    \brief Macro that defines the  Time Zone Name string length.
*/
#define MAX_TIME_ZONE_NAME_LEN     97	/*!<  Time Zone String Length */

#define MAX_SWITCH_PORTS           10

#define MAX_LAN_IF                 10

/*! \def IFX_TIME_NTPENABLE
    \brief Macro that defines the NTP feature is enabled.
*/
#define IFX_TIME_NTPENABLE							"fEnable"	/*!<  NTP Enable */

/*! \def IFX_TIME_NTPSERVER1
    \brief Macro that defines the Primary NTP Server.
*/
#define IFX_TIME_NTPSERVER1                       "NTPServer1"	/*!<  Primary NTP Server */

/*! \def IFX_TIME_NTPSERVER2
    \brief Macro that defines the Secondary NTP Server.
*/
#define IFX_TIME_NTPSERVER2                       "NTPServer2"	/*!<  Secondary NTP Server */

/*! \def IFX_TIME_NTPSERVER3
    \brief Macro that defines the Third NTP Server.
*/
#define IFX_TIME_NTPSERVER3                       "NTPServer3"	/*!<  Third NTP Server */

/*! \def IFX_TIME_NTPSERVER4
    \brief Macro that defines the Fourth NTP Server
*/
#define IFX_TIME_NTPSERVER4                       "NTPServer4"	/*!<  Fourth NTP Server */

/*! \def IFX_TIME_NTPSERVER5
    \brief Macro that defines the Fifth NTP Server
*/
#define IFX_TIME_NTPSERVER5                       "NTPServer5"	/*!<  Fifth NTP Server */

/*! \def IFX_TIME_CURRENTLOCALTIME
    \brief Macro that defines the Current Local Time. 
*/
#define IFX_TIME_CURRENTLOCALTIME                 "CurrentLocalTime"	/*!<   Current Local Time. */

/*! \def IFX_TIME_LOCALTIMEZONE
    \brief Macro that defines the Current Local Time Zone Offset. 
*/
#define IFX_TIME_LOCALTIMEZONE                    "TimeMinuteOffset"	/*!<   Current Local TIme Zone Offset */

/*! \def IFX_TIME_LOCALTIMEZONENAME
    \brief Macro that defines the name of current local time zone. 
*/
#define IFX_TIME_LOCALTIMEZONENAME                "TZname"	/*!<  Local TimeZone Name */

/*! \def IFX_TIME_LOCALTIMEZONEINDEX
    \brief Macro that defines the index of Local TimeZone.
*/
#define IFX_TIME_LOCALTIMEZONEINDEX					"timeZoneIdx"	/*!<  Local TimeZone Index */

/*! \def IFX_TIME_DAYLIGHTSAVINGSUSED
    \brief Macro that defines the DayLightSavings (DLS) used.
*/
#define IFX_TIME_DAYLIGHTSAVINGSUSED              "DLSused"	/*!<  Day Light Savings Used */

/*! \def IFX_TIME_DAYLIGHTSAVINGSSTART
    \brief Macro that defines the  DayLightSaving Start.
*/
#define IFX_TIME_DAYLIGHTSAVINGSSTART             "DLSstart"	/*!<  DLS Start */

/*! \def IFX_TIME_DAYLIGHTSAVINGSEND
    \brief Macro that defines the  Day Light Savings End.
*/
#define IFX_TIME_DAYLIGHTSAVINGSEND               "DLSend"	/*!<  DLS End */

/*! \def VALUE_MAX_LEN
    \brief Macro that defines the maximum value sttring length.
*/
#define VALUE_MAX_LEN								64	/*!<  Maximum value sttring length. */

/*! \def LINE_LEN
    \brief Macro that defines the  line length in rc.conf
*/
#define LINE_LEN									672	/*!<  Line Length in rc.conf */

/*! \def UDHCPD_LEASES_FILE
    \brief Macro that defines the Lease Time File of UDHCPD.
*/
#define	UDHCPD_LEASES_FILE							"/var/lib/misc/udhcpd.leases"	/*!<  UDHCPD Lease File */

/*! \def ADSL_DEV_PATH
    \brief Macro that defines the ADSL MEI device path.
*/
#define ADSL_DEV_PATH "/dev/amazon/mei" /*!< ADSL Device Path */

#if defined (CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
/*! \def MAX_LAN_IFS 
    \brief Macro that defines the maximum number of LAN side interfaces
*/ 
#define MAX_LAN_IFS                20 /*!< Max LAN side interfaces */
/* #ifndef MAX_LAN_IFS */


/*! \def MAX_IFACE_LEN 
    \brief Macro that defines the maximum length of interface name
*/ 
#define MAX_IFACE_LEN 	8 /*! maximum length of a interface name */

/*! \def NUM_WAN_MODES 
    \brief Macro that defines the number of WAN modes
*/
#define NUM_WAN_MODES		   8 /*! Number of WAN modes 0 = ADSL ATM 1 = MII0 2 = MII1 3 = ADSL PTM 4 = VDSL PTM 5 = VDSL ATM 7 = LTE */
/* #ifndef NUM_WAN_MODES */ 

#endif

#if defined (CONFIG_FEATURE_IFX_WIRELESS)

/******************************************************************************/
/*****                  Defines for IFX_MAPI_WLAN_xxx                     *****/
/******************************************************************************/
#ifndef IFX_MAPI_WLAN_AP_NAME
/*! \def IFX_MAPI_WLAN_AP_NAME
    \brief Macro that defines the  Length of WLAN AP Name.
*/
#define IFX_MAPI_WLAN_AP_NAME             33	/*!<  Length of AP Name */
#endif				/* #ifndef IFX_MAPI_WLAN_AP_NAME */

#ifndef IFX_MAPI_WLAN_MAX_PHY_CHANNELS
/*! \def IFX_MAPI_WLAN_MAX_PHY_CHANNELS
    \brief Macro that defines the maximum number of WLAN Physical Channels.
*/
#define IFX_MAPI_WLAN_MAX_PHY_CHANNELS    24	/*!<  WLAN Max Radio Channels */
#endif				/* #ifndef IFX_MAPI_WLAN_MAX_PHY_CHANNELS */

#ifndef IFX_MAPI_WLAN_MAX_UUID_LEN
/*! \def IFX_MAPI_WLAN_MAX_UUID_LEN
    \brief Macro that defines the UUID length for WLAN.
*/
#define IFX_MAPI_WLAN_MAX_UUID_LEN        36	/*!<  UUID length for WLAN */
#endif				/* #ifndef IFX_MAPI_WLAN_MAX_UUID_LEN */

#ifndef IFX_MAPI_WLAN_MAX_VENDOR_NAME_LEN
/*! \def IFX_MAPI_WLAN_MAX_VENDOR_NAME_LEN
    \brief Macro that defines string length of WLAN Vendor name. 
*/
#define IFX_MAPI_WLAN_MAX_VENDOR_NAME_LEN 33	/*!<  WLAN Vendor String Length */
#endif				/* #ifndef IFX_MAPI_WLAN_MAX_VENDOR_NAME_LEN */

#ifndef IFX_MAPI_WLAN_MAX_DATA_RATES_NUM
/*! \def IFX_MAPI_WLAN_MAX_DATA_RATES_NUM
    \brief Macro that defines the maximum number of data rates of WLAN.
*/
#define IFX_MAPI_WLAN_MAX_DATA_RATES_NUM  24 /* max. 24 different rates */	/*!<  Maximum different data rates in WLAN */
#endif				/* #ifndef IFX_MAPI_WLAN_MAX_DATA_RATES_NUM */

#ifndef IFX_MAPI_WLAN_MAX_STD
/*! \def IFX_MAPI_WLAN_MAX_STD
    \brief Macro that defines the maximum number of supported WLAN Statndard.
*/
#define IFX_MAPI_WLAN_MAX_STD 11	/*!<  Maximum WLAN Standards */
#endif				/* #ifndef IFX_MAPI_WLAN_MAX_STD */

#ifndef IFX_MAPI_WLAN_MAX_COUNTRY
/*! \def IFX_MAPI_WLAN_MAX_COUNTRY
    \brief Macro that defines the number of countries of varied WLAN standard.
*/
#define IFX_MAPI_WLAN_MAX_COUNTRY 248	/*!<  Number of Countries of different WLAN standard */
#endif				/* #ifndef IFX_MAPI_WLAN_MAX_COUNTRY */

#ifndef IFX_MAPI_WLAN_SSID_LEN
/*! \def IFX_MAPI_WLAN_SSID_LEN
    \brief Macro that defines the Maximum SSID length for WLAN.
*/
#define IFX_MAPI_WLAN_SSID_LEN 33	/*!<  SSID String Length */
#endif				/* #ifndef IFX_MAPI_WLAN_SSID_LEN */

#ifndef IFX_MAPI_WLAN_BSSID_LEN
/*! \def IFX_MAPI_WLAN_BSSID_LEN
    \brief Macro that defines the BSSID String length.
*/
#define IFX_MAPI_WLAN_BSSID_LEN IFX_MAPI_MAC_ADDR_LEN	/*!<  BSSID String length */
#endif				/* #ifndef IFX_MAPI_WLAN_BSSID_LEN */

#ifndef IFX_MAPI_WLAN_LOCATION_STR
/*! \def IFX_MAPI_WLAN_LOCATION_STR
    \brief Macro that defines the WLAN Location String.
*/
#define IFX_MAPI_WLAN_LOCATION_STR 64	/*!<  WLAN Location String */
#endif				/* #ifndef IFX_MAPI_WLAN_LOCATION_STR */

#ifndef IFX_MAPI_WEP_KEY_MAX_LEN
/*! \def IFX_MAPI_WEP_KEY_MAX_LEN
    \brief Macro that defines the WLAN WEP Key Length.
*/
#define IFX_MAPI_WEP_KEY_MAX_LEN 27	/*!<  Maximum WEP Key Length string of 26 characters + ending \0 */
#endif

#ifndef IFX_MAPI_NUM_WEP_KEYS
/*! \def IFX_MAPI_NUM_WEP_KEYS
    \brief Macro that defines the number of WEP Keys.
*/
#define IFX_MAPI_NUM_WEP_KEYS 4	/*!<  Four Number of WEP Keys */
#endif

#ifndef IFX_MAPI_WLAN_NUM_ENTRIES_ACL_TABLE
/*! \def IFX_MAPI_WLAN_NUM_ENTRIES_ACL_TABLE
    \brief Macro that defines the Number of ACL entries for WLAN.
*/
#define IFX_MAPI_WLAN_NUM_ENTRIES_ACL_TABLE 10	/*!<  Number of ACL entries for WLAN */
#endif

#ifndef IFX_MAX_WLAN_POWER_LEVELS
/*! \def IFX_MAX_WLAN_POWER_LEVELS
    \brief Macro that defines the  number of power levels for WLAN.
*/
#define IFX_MAX_WLAN_POWER_LEVELS 5	/*!<   Number of power levels for WLAND */
#endif				/* #ifndef IFX_MAX_WLAN_POWER_LEVELS */

#ifndef IFX_MAX_WLAN_BIT_RATE_TYPE
/*! \def IFX_MAX_WLAN_BIT_RATE_TYPE
    \brief Macro that defines the type of bit rates of WLAN.
*/
#define IFX_MAX_WLAN_BIT_RATE_TYPE 4	/*!<  Bit Rates of WLAN */
#endif

#ifndef IFX_MAX_WLAN_PREAMBLE_MODES
/*! \def IFX_MAX_WLAN_PREAMBLE_MODES
    \brief Macro that defines the  number of Preamble modes for WLAN.
*/
#define IFX_MAX_WLAN_PREAMBLE_MODES 3	/*!<   Number of Preamble modes for WLAN */
#endif

#ifndef IFX_MAPI_WLAN_NUM_BEACON_TYPE
/*! \def IFX_MAPI_WLAN_NUM_BEACON_TYPE
    \brief Macro that defines the type of Beacon.
*/
#define IFX_MAPI_WLAN_NUM_BEACON_TYPE 4	/*!<  Number of Beacon Types */
#endif				/* #ifndef IFX_MAPI_WLAN_NUM_BEACON_TYPE */

#ifndef IFX_MAX_WLAN_AUTH_TYPE
/*! \def IFX_MAX_WLAN_AUTH_TYPE
    \brief Macro that defines the number of authentication types.
*/
#define IFX_MAX_WLAN_AUTH_TYPE 4	/*!<   Number of authentication types */
#endif

#ifndef IFX_MAPI_WLAN_NUM_ENCR_TYPE
/*! \def IFX_MAPI_WLAN_NUM_ENCR_TYPE
    \brief Macro that defines the number of encryption types.
*/
#define IFX_MAPI_WLAN_NUM_ENCR_TYPE    5	/*!<  No. of encryption types */
#endif				/* #ifndef IFX_MAPI_WLAN_NUM_ENCR_TYPE */

#ifndef IFX_MAX_WLAN_KEY_INDEX
/*! \def IFX_MAX_WLAN_KEY_INDEX
    \brief Macro that defines the current WLAN Key Index.
*/
#define IFX_MAX_WLAN_KEY_INDEX 4	/*!<  WLAN Key Index */
#endif

#ifndef IFX_MAX_WLAN_ENCR_LVL
/*! \def IFX_MAX_WLAN_ENCR_LVL
    \brief Macro that defines the  number of WLAN encryption levels.
*/
#define IFX_MAX_WLAN_ENCR_LVL 2	/*!<  Number of WLAN Encryption Level */
#endif

#ifndef IFX_MAX_WLAN_KEY_TYPE
/*! \def IFX_MAX_WLAN_KEY_TYPE
    \brief Macro that defines the type of WLAN Keys - ASCII or Hex.
*/
#define IFX_MAX_WLAN_KEY_TYPE 2	/*!<  Type of WLAN Key */
#endif

#ifndef IFX_MAX_WLAN_PSK_KEY_TYPE
/*! \def IFX_MAX_WLAN_PSK_KEY_TYPE
    \brief Macro that defines the  PreSharedKey Type.
*/
#define IFX_MAX_WLAN_PSK_KEY_TYPE 1	/*!<  WLAN PreShared Key Type */
#endif

/*! \def IFX_MAPI_WLAN_AUTO_MAXBITRATE
    \brief Macro that defines the  Automatic settings of Maximum bit rate of WLAN.
*/
#define IFX_MAPI_WLAN_AUTO_MAXBITRATE -1.0	/*!<  Automatic Max bit Rate */

/*! \def IFX_MAPI_WPA2_MAX_CIPHER_LEN
    \brief Macro that defines the WPA2 cipher length.
*/
#define IFX_MAPI_WPA2_MAX_CIPHER_LEN   256	/*!<  Maximum WPA2 cipher length */

#ifndef IFX_MAPI_MAX_POWER_LEVELS
/*! \def IFX_MAPI_MAX_POWER_LEVELS
    \brief Macro that defines the Maximum Power Levels.
*/
#define IFX_MAPI_MAX_POWER_LEVELS      16	/*!< Maximum Power Levels   */
#endif

/********************************************************************/
/*****     Channel definition for 802.11B, G, N, GB, BGN        *****/
/********************************************************************/

/*! \def IFX_MAPI_WLAN_CHANNEL_1
    \brief Macro that defines the WLAN Channel-1 for 802.11B, G, N, BG, BGN.
*/
#define IFX_MAPI_WLAN_CHANNEL_1        1	/*!<  WLAN Channel-1 for BGN */

/*! \def IFX_MAPI_WLAN_CHANNEL_2
    \brief Macro that defines the WLAN Channel-2 for 802.11B, G, N, BG, BGN.
*/
#define IFX_MAPI_WLAN_CHANNEL_2        2	/*!<  WLAN Channel-2 for BGN */

/*! \def IFX_MAPI_WLAN_CHANNEL_3
    \brief Macro that defines the WLAN Channel-3 for 802.11B, G, N, BG, BGN.
*/
#define IFX_MAPI_WLAN_CHANNEL_3        3	/*!<  WLAN Channel-3 for BGN */

/*! \def IFX_MAPI_WLAN_CHANNEL_4
    \brief Macro that defines the WLAN Channel-4 for 802.11B, G, N, BG, BGN.
*/
#define IFX_MAPI_WLAN_CHANNEL_4        4	/*!<  WLAN Channel-4 for BGN */

/*! \def IFX_MAPI_WLAN_CHANNEL_5
    \brief Macro that defines the WLAN Channel-5 for 802.11B, G, N, BG, BGN.
*/
#define IFX_MAPI_WLAN_CHANNEL_5        5	/*!<  WLAN Channel-5 for BGN */

/*! \def IFX_MAPI_WLAN_CHANNEL_6
    \brief Macro that defines the WLAN Channel-6 for 802.11B, G, N, BG, BGN.
*/
#define IFX_MAPI_WLAN_CHANNEL_6        6	/*!<  WLAN Channel-6 for BGN */

/*! \def IFX_MAPI_WLAN_CHANNEL_7
    \brief Macro that defines the WLAN Channel-7 for 802.11B, G, N, BG, BGN.
*/
#define IFX_MAPI_WLAN_CHANNEL_7        7	/*!<  WLAN Channel-7 for BGN */

/*! \def IFX_MAPI_WLAN_CHANNEL_8
    \brief Macro that defines the WLAN Channel-8 for 802.11B, G, N, BG, BGN.
*/
#define IFX_MAPI_WLAN_CHANNEL_8        8	/*!<  WLAN Channel-8 for BGN */

/*! \def IFX_MAPI_WLAN_CHANNEL_9
    \brief Macro that defines the WLAN Channel-9 for 802.11B, G, N, BG, BGN.
*/
#define IFX_MAPI_WLAN_CHANNEL_9        9	/*!<  WLAN Channel-9 for BGN */

/*! \def IFX_MAPI_WLAN_CHANNEL_10
    \brief Macro that defines the WLAN Channel-10 for 802.11B, G, N, BG, BGN.
*/
#define IFX_MAPI_WLAN_CHANNEL_10       10	/*!<  WLAN Channel-10 for BGN */

/*! \def IFX_MAPI_WLAN_CHANNEL_11
    \brief Macro that defines the WLAN Channel-11 for 802.11B, G, N, BG, BGN.
*/
#define IFX_MAPI_WLAN_CHANNEL_11       11	/*!<  WLAN Channel-11 for BGN */

/*! \def IFX_MAPI_WLAN_CHANNEL_12
    \brief Macro that defines the WLAN Channel-12 for 802.11B, G, N, BG, BGN.
*/
#define IFX_MAPI_WLAN_CHANNEL_12       12	/*!<  WLAN Channel-12 for BGN */

/*! \def IFX_MAPI_WLAN_CHANNEL_13
    \brief Macro that defines the WLAN Channel-13 for 802.11B, G, N, BG, BGN.
*/
#define IFX_MAPI_WLAN_CHANNEL_13       13	/*!<  WLAN Channel-13 for BGN */

/*! \def IFX_MAPI_WLAN_CHANNEL_14
    \brief Macro that defines the WLAN Channel-14 for 802.11B, G, N, BG, BGN.
*/
#define IFX_MAPI_WLAN_CHANNEL_14       14	/*!<  WLAN Channel-14 for BGN */

/********************************************************************/
/*****           Channel definition for 802.11A, AN             *****/
/********************************************************************/

/*! \def IFX_MAPI_WLAN_CHANNEL_36
    \brief Macro that defines the WLAN Channel-36 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_36       36	/*!<  WLAN Channel-36 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_40
    \brief Macro that defines the WLAN Channel-40 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_40       40	/*!<  WLAN Channel-40 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_44
    \brief Macro that defines the WLAN Channel-44 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_44       44	/*!<  WLAN Channel-44 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_48
    \brief Macro that defines the WLAN Channel-48 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_48       48	/*!<  WLAN Channel-48 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_52
    \brief Macro that defines the WLAN Channel-52 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_52       52	/*!<  WLAN Channel-52 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_56
    \brief Macro that defines the WLAN Channel-56 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_56       56	/*!<  WLAN Channel-56 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_60
    \brief Macro that defines the WLAN Channel-60 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_60       60	/*!<  WLAN Channel-60 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_64
    \brief Macro that defines the WLAN Channel-64 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_64       64	/*!<  WLAN Channel-64 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_100
    \brief Macro that defines the WLAN Channel-100 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_100      100	/*!<  WLAN Channel-100 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_104
    \brief Macro that defines the WLAN Channel-104 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_104      104	/*!<  WLAN Channel-104 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_108
    \brief Macro that defines the WLAN Channel-108 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_108      108	/*!<  WLAN Channel-108 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_112
    \brief Macro that defines the WLAN Channel-112 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_112      112	/*!<  WLAN Channel-112 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_116
    \brief Macro that defines the WLAN Channel-116 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_116      116	/*!<  WLAN Channel-116 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_120
    \brief Macro that defines the WLAN Channel-120 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_120      120	/*!<  WLAN Channel-120 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_124
    \brief Macro that defines the WLAN Channel-124 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_124      124	/*!<  WLAN Channel-124 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_128
    \brief Macro that defines the WLAN Channel-128 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_128      128	/*!<  WLAN Channel-128 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_132
    \brief Macro that defines the WLAN Channel-132 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_132      132	/*!<  WLAN Channel-132 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_136
    \brief Macro that defines the WLAN Channel-136 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_136      136	/*!<  WLAN Channel-136 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_140
    \brief Macro that defines the WLAN Channel-140 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_140      140	/*!<  WLAN Channel-140 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_149
    \brief Macro that defines the WLAN Channel-149 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_149      149	/*!<  WLAN Channel-149 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_153
    \brief Macro that defines the WLAN Channel-153 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_153      153	/*!<  WLAN Channel-153 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_157
    \brief Macro that defines the WLAN Channel-157 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_157      157	/*!<  WLAN Channel-157 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_161
    \brief Macro that defines the WLAN Channel-161 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_161      161	/*!<  WLAN Channel-161 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_165
    \brief Macro that defines the WLAN Channel-165 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_165      165	/*!<  WLAN Channel-165 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_184
    \brief Macro that defines the WLAN Channel-184 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_184      184	/*!<  WLAN Channel-184 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_188
    \brief Macro that defines the WLAN Channel-188 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_188      188	/*!<  WLAN Channel-188 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_192
    \brief Macro that defines the WLAN Channel-192 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_192      192	/*!<  WLAN Channel-192 for AN */

/*! \def IFX_MAPI_WLAN_CHANNEL_196
    \brief Macro that defines the WLAN Channel-196 for 802.11A, AN.
*/
#define IFX_MAPI_WLAN_CHANNEL_196      196	/*!<  WLAN Channel-196 for AN */

/*! \def IFX_MAPI_WLAN_REGDOMAIN_WORLD_11A_LENGTH
    \brief Macro that defines the WLAN 802.11A World Regulator Domain Name Length.
*/
#define IFX_MAPI_WLAN_REGDOMAIN_WORLD_11A_LENGTH   24	/*!<  WLAN 802.11A World Regulator Domain Name Length */

/*! \def IFX_MAPI_WLAN_REGDOMAIN_EUROPE_11A_LENGTH
    \brief Macro that defines the WLAN 802.11A Europe Regulator Domain Name Length.
*/
#define IFX_MAPI_WLAN_REGDOMAIN_EUROPE_11A_LENGTH  19	/*!<  11A Europe Regulator String Length */

/*! \def IFX_MAPI_WLAN_REGDOMAIN_JAPAN_11A_LENGTH
    \brief Macro that defines the WLAN 802.11A Japan Regulator Domain Name Length.
*/
#define IFX_MAPI_WLAN_REGDOMAIN_JAPAN_11A_LENGTH   23	/*!<  WLAN 802.11A Japan Regulator Domain Name Length */

/*! \def IFX_MAPI_WLAN_REGDOMAIN_CHINA_11A_LENGTH
    \brief Macro that defines the WLAN 802.11A China Regulator Domain Name Length.
*/
#define IFX_MAPI_WLAN_REGDOMAIN_CHINA_11A_LENGTH   5	/*!<  WLAN 802.11A China Regulator Domain Name Length */

/*! \def IFX_MAPI_WLAN_REGDOMAIN_WORLD_11G_LENGTH
    \brief Macro that defines the WLAN 802.11G World Regulator Domain Name Length.
*/
#define IFX_MAPI_WLAN_REGDOMAIN_WORLD_11G_LENGTH   13	/*!<  11G World Regulator String Length */

/*! \def IFX_MAPI_WLAN_REGDOMAIN_USA_11G_LENGTH
    \brief Macro that defines the WLAN 802.11G USA Regulator Domain Name Length.
*/
#define IFX_MAPI_WLAN_REGDOMAIN_USA_11G_LENGTH     11	/*!<  11G USA Regulator String Length */

/*! \def IFX_MAPI_WLAN_REGDOMAIN_JAPAN_11G_LENGTH
    \brief Macro that defines the WLAN 802.11G Japan Regulator Domain Name Length.
*/
#define IFX_MAPI_WLAN_REGDOMAIN_JAPAN_11G_LENGTH   13	/*!<  11G Japan Regulator String Length */

/*! \def IFX_MAPI_WLAN_REGDOMAIN_JAPAN_11B_LENGTH
    \brief Macro that defines the WLAN 802.11B Japan Regulator Domain Name Length.
*/
#define IFX_MAPI_WLAN_REGDOMAIN_JAPAN_11B_LENGTH   14	/*!<  11B Japan Regulator String Length */

/********************************************************************/
/*****                        WMM                               *****/
/********************************************************************/
/*! \def IFX_MAPI_WLAN_WMM_NUM_AC
    \brief Macro that defines the number of Access Categories for WMM.
*/
#define IFX_MAPI_WLAN_WMM_NUM_AC    4	/*!<  Number of WMM Access Categories */
/* End of WMM section */

/*******************************************************************/
/*****                        WPS                              *****/
/*******************************************************************/
#ifndef IFX_MAPI_WPS_DEV_NAME_LEN
/*! \def IFX_MAPI_WPS_DEV_NAME_LEN
    \brief Macro that defines the WPS device name length.
*/
#define IFX_MAPI_WPS_DEV_NAME_LEN      32	/*!<  WPS device name length */
#endif				/* #ifndef IFX_MAPI_WPS_DEV_NAME_LEN */

#ifndef IFX_MAPI_WPS_MAX_CFG_METHODS
/*! \def IFX_MAPI_WPS_MAX_CFG_METHODS
    \brief Macro that defines the maximum number of Config methods through WPS.
*/
#define IFX_MAPI_WPS_MAX_CFG_METHODS 10	/*!<  Maximum WPS Config Methods */
#endif				/* #ifndef IFX_MAPI_WPS_MAX_CFG_METHODS */

/* End of WPS section */
/* End of WLAN section */

#endif				/* #if defined (CONFIG_FEATURE_IFX_WIRELESS) */
#ifndef IFX_MAPI_MAC_ADDR_LEN
/*! \def IFX_MAPI_MAC_ADDR_LEN
    \brief Macro that defines the MAC Address length for MAPI.
*/
#define IFX_MAPI_MAC_ADDR_LEN MAX_MAC_ADDR_LEN	/*!<  MAPI MAC Address Length */
#endif				/* #ifndef IFX_MAPI_MAC_ADDR_LEN */

#ifndef IFX_MAPI_MAX_IF_NAME_LEN
/*! \def IFX_MAPI_MAX_IF_NAME_LEN
    \brief Macro that defines the Interface Langth for MAPI.
*/
#define IFX_MAPI_MAX_IF_NAME_LEN          MAX_IF_NAME_LEN	/*!<  MAPI Interface Length */
#endif				/* #ifndef IFX_MAPI_MAX_IF_NAME_LEN */

/*! \def MAX_IP_MASK_LEN
    \brief Macro that defines the IP Mask length.
*/
#define	MAX_IP_MASK_LEN 		40	/*!<  IP Mask length */
/*! \def IFX_MAX_DHCP_SRC_INTF_LEN
    \brief Macro that defines the DHCP Source Interface Length.
*/
#define IFX_MAX_DHCP_SRC_INTF_LEN	1024	/*!<  DHCP Source Interface Length */
/*! \def IFX_MAX_DHCP_ID_LEN
    \brief Macro that defines the DHCP Identifier length.
*/
#define IFX_MAX_DHCP_ID_LEN		256	/*!<  DHCP Identifier Length */
/*! \def IFX_MAX_RESERVED_ADDR
    \brief Macro that defines the maximum no. of reserved addresses.
*/
#define IFX_MAX_RESERVED_ADDR		32	/*!<  Maximum no. of reserved addresses */
/*! \def MAX_DHCPPOOL_VALUE_LEN
    \brief Macro that defines the DHCP Pool Value length,
*/
#define MAX_DHCPPOOL_VALUE_LEN 		1024	/*!<  Maximum number of addresses in a DHCP Pool */

/* Type of message being sent IFX_IPC_SOURCE_REASON */
/*! \def IFX_IPC_WEB_CONFIGCHANGE
    \brief Macro that defines the reason for config change in web. 
*/
#define IFX_IPC_WEB_CONFIGCHANGE	10	/*!<  Config Change in Web */

/*! \def DEFAULT_MAX_MTU
    \brief Macro that defines the default MTU Size
*/
#define DEFAULT_MAX_MTU	    1500	/*!< Default MTU Size  */

/*******************************************************/
/* The following functions relate to WAN Configuration */
/*******************************************************/
/*! \def MIN_WAN_INDEX
    \brief Macro that defines the 
*/
#define MIN_WAN_INDEX		1	/*!<  Minimum WAN Index */
/*! \def MAX_WAN_INDEX
    \brief Macro that defines the 
*/
#define MAX_WAN_INDEX		50	/*!<  Maximum WAN Index */

#define MAX_POOL_COUNT 		10
#define MAX_POOL_LIMIT 		256


/***************************************************/
/**** Define the WAN_IP and WAN_PPP Connections ****/
/***************************************************/
/*! \def WAN_IP_CONN
    \brief Macro that defines the 
*/
#define WAN_IP_CONN                     wancfg.ip	/*!<  WAN IP Connections */

/*! \def WAN_IPv4_CFG
    \brief Macro that defines the IPv4 Conf
*/
#define WAN_IPv4_CFG			wanv4

/*! \def WAN_IPv6_CFG
    \brief Macro that defines the IPv6 Conf
*/
#define WAN_IPv6_CFG			wanv6
/*! \def WAN_PPP_CONN
    \brief Macro that defines the 
*/
#define WAN_PPP_CONN                    wancfg.ppp	/*!<  WAN PPP Connections */

/****************************************************/
/****** PREDEFINE the fields in WAN_COMMON_CFG ******/
/****************************************************/
/*! \def WAN_CONN
    \brief Macro that defines the WAN Connections.
*/
#define WAN_CONN	wan_cfg	/*!<  WAN Connections */

/*! \def WAN_CONN_IID
    \brief Macro that defines the WAN Connection IID.
*/
#define WAN_CONN_IID	iid	/*!<  WAN Connection IID */

/*! \def WAN_CONN_ENABLE
    \brief Macro that defines the WAN Connection Enable.
*/
#define WAN_CONN_ENABLE		f_enable	/*!<  WAN Connection Enable */

/*! \def WAN_CONN_IPADDR
    \brief Macro that defines the WAN Connection IP Address. 
*/
#define	WAN_CONN_IPADDR		ip_mask.ip	/*!<  WAN Connection IP Address */
#define	WAN_CONN_IPADDR6        ip6_mask.ip6	/*!<  WAN Connection IP Address */

/*! \def WAN_CONN_IPMASK
    \brief Macro that defines the WAN Connection IP Mask.
*/
#define WAN_CONN_IPMASK		ip_mask.mask	/*!<  WAN Connection IP Mask */
#define WAN_CONN_IPPREFIX6      ip6_mask.prefixlen /*!<  WAN Connection IP Mask */

/*! \def WAN_CONN_NAME
    \brief Macro that defines the  WAN Connection Name.
*/
#define WAN_CONN_NAME		conn_name	/*!<  WAN Connection Name */

/*! \def WAN_CONF_CONN_NAME
    \brief Macro that defines the WAN Config Connection Name.
*/
#define WAN_CONF_CONN_NAME	conf_conn_name	/*!<  WAN Config Connection Name */

/*! \def WAN_CONN_AUTO_DISCONNECT_TIME
    \brief Macro that defines the WAN Connection Auto Disconnect Time.
*/
#define WAN_CONN_AUTO_DISCONNECT_TIME	auto_disconn_time	/*!<  WAN Connection Auto Disconnect Time */

/*! \def WAN_CONN_IDLE_DISCONNECT_TIME
    \brief Macro that defines the  WAN Connection Idle Disconnect Time.
*/
#define WAN_CONN_IDLE_DISCONNECT_TIME	idle_disconn_time	/*!<  WAN Connection Idle Disconnect Time */

/*! \def WAN_CONN_WARN_DISCONNECT_TIME
    \brief Macro that defines the WAN Disconnect Delay.
*/
#define WAN_CONN_WARN_DISCONNECT_TIME	warn_disconn_delay	/*!<  WAN Disconnect Delay */

/*! \def WAN_CONN_RSIP_AVAILABLE
    \brief Macro that defines the RSIP is Availablity.
*/
#define WAN_CONN_RSIP_AVAILABLE		RSIP_avail	/*!<  RSIP is Available */

/*! \def WAN_CONN_NAT_ENABLED
    \brief Macro that defines the NAT enabled on WAN Connection.
*/
#define WAN_CONN_NAT_ENABLED		NAT_enabled	/*!<  NAT is enabled on WAN Connection */

/*! \def WAN_CONN_DNS_ENABLED
    \brief Macro that defines the DNS enabled on WAN Connection.
*/
#define WAN_CONN_DNS_ENABLED		DNS_enabled	/*!<  DNS is enabled on WAN Connection */

/*! \def WAN_CONN_DNS_OVERRIDE
    \brief Macro that defines the  DNS Override in WAN Connection.
*/
#define WAN_CONN_DNS_OVERRIDE		DNS_override_allowed	/*!<  DNS Override in WAN Connection */

/*! \def WAN_CONN_MAC_ADDR
    \brief Macro that defines the MAC Address of WAN Connection.
*/
#define WAN_CONN_MAC_ADDR	mac_addr	/*!<  MAC Address of WAN Connection */

/*! \def WAN_CONN_MAC_ADDR_OVERRIDE
    \brief Macro that defines the WAN Connection MAC Address Override.
*/
#define WAN_CONN_MAC_ADDR_OVERRIDE		mac_addr_override	/*!<  WAN Connection MAC Address Override */

/*! \def WAN_CONN_TRIGGER
    \brief Macro that defines the WAN Connection Trigger.
*/
#define WAN_CONN_TRIGGER	trigger	/*!<  WAN Connection Trigger */

/*! \def WAN_CONN_ROUTE_PROTO_RX
    \brief Macro that defines the WAN Connection Protocol Rx.
*/
#define WAN_CONN_ROUTE_PROTO_RX			route_rx	/*!<  WAN Connection Protocol Rx */

#define TAG_WAN_IPV6CFG         "wan_ipv6"
#define TAG_WAN_IPV4CFG         "wan_ipv4"
#define TAG_WAN_DNSCFG         "wan_dns"

/*! \def IFX_VALIDATE_PTR
    \brief This macro validates the pointer to be non-NULL.
*/
#define IFX_VALIDATE_PTR(ptr)	if(ptr == NULL) \
									return IFX_FAILURE;

/*! \def IFX_VALIDATE_FLAGS
    \brief This macro validates the flags to be positive number.
*/
#define IFX_VALIDATE_FLAGS(num)	if(num < 0) \
									return IFX_FAILURE;

/*! \def IFX_VALIDATE_VS_ENTRY
    \brief This macro does a validation for unique virtual server entry based on the set {remote ip, public port, protocol}
*/
#define IFX_VALIDATE_VS_ENTRY(entry, flags) { \
					/* compare the pair of remoteip, public-port and protocol in the passed structure
					 * with the pairs present in the rc.conf file */ \
					VIRTUAL_SERVER *virtual_servers = NULL; \
					char8	remote_ip[MAX_IP_ADDR_LEN]; \
					char8	inp_remote_ip[MAX_IP_ADDR_LEN]; \
					int32	i = 0, num_entries = 0, pub_sport = 0, pub_eport = 0, proto_type = 0; \
					if(ifx_get_virtual_server_info(&num_entries, &virtual_servers, IFX_F_GET_ENA) != IFX_SUCCESS) { \
						IFX_DBG("[%s:%d] : Validation failed", \
								__FUNCTION__, __LINE__); \
						return IFX_FAILURE; \
					} \
						memset(inp_remote_ip, 0x00, sizeof(inp_remote_ip)); \
						sprintf(inp_remote_ip, "%s", inet_ntoa(entry->remote_ip));\
					for(i=0; i<num_entries; i++) { \
						memset(remote_ip, 0x00, sizeof(remote_ip)); \
						sprintf(remote_ip, "%s", inet_ntoa((virtual_servers + i)->remote_ip));\
						pub_sport = ((virtual_servers + i)->public_sport); \
						pub_eport = ((virtual_servers + i)->public_eport); \
						proto_type = ((virtual_servers + i)->protocol);\
						if(!strcmp(inp_remote_ip, remote_ip) && (pub_sport == entry->public_sport) && \
							(pub_eport == entry->public_eport) &&	(proto_type == entry->protocol)) { \
								if (IFX_MODIFY_F_SET(flags) && \
									((virtual_servers + i)->iid.cpeId.Id == entry->iid.cpeId.Id)) { \
									/* DO Nothing - if it's the same entry being modified for other fields */ \
									break; \
								} \
								else { \
									IFX_DBG("[%s:%d]:Duplicate VS entry", __FUNCTION__, __LINE__); \
									IFX_MEM_FREE(virtual_servers) \
									return IFX_FAILURE; \
								} \
						} \
					} \
					IFX_MEM_FREE(virtual_servers) \
				}

/*! \def IFX_VALIDATE_OAM_F5_ENTRY
    \brief This macro validates the OAM F5 entry to have entries with unique cpeId.
*/
#define IFX_VALIDATE_OAM_F5_ENTRY(entry, oper) { \
					if(entry->iid.config_owner != IFX_TR69) { \
						if(oper == IFX_OP_MOD) { \
							char8 t_buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN]; \
							int32 t_passed_index = 0; \
							uint32 outFlag = IFX_F_DEFAULT; \
        					if(ifx_get_index_from_cpe_id(FILE_RC_CONF, &atmf5_daigs->iid.cpeId, \
												 &t_passed_index) != IFX_SUCCESS) { \
								ret = IFX_FAILURE; \
								goto IFX_Handler; \
							} \
							sprintf(t_buf, "%s_%d_cpeId", PREFIX_WAN_ATMF5, t_passed_index); \
							if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_ATMF5, t_buf, IFX_F_GET_ENA, &outFlag, \
											sValue) != IFX_SUCCESS) { \
								ret = IFX_FAILURE; \
								goto IFX_Handler; \
							} \
						} \
					} \
				}

/*! \def IFX_MEM_FREE
    \brief Macro that frees up the allocated pointer.
*/
#define IFX_MEM_FREE(ptr)		if(ptr != NULL) {\
									free(ptr); \
									ptr = NULL; \
								}

/*! \def MEMSET
    \brief Macro that sets the contents of the data structure to '0's.
*/
#define MEMSET(ptr, size)       memset(ptr, 0x00, size)

/*! \def IFX_MALLOC
    \brief Macro that allocates single byte of memory and sets the allocated memory contents to '0'.
*/
#define IFX_MALLOC(x) ({calloc(1,x);})

/*! \def IFX_MEM_ALLOC
    \brief Macro that allocates requested amount of memory and sets the allocated memory contents to '0's.
*/
#define	IFX_MEM_ALLOC(ptr, type, nmemb, size)	if (!(ptr = (type)calloc(nmemb, size))) \
													ret = IFX_FAILURE; \
												if (ret != IFX_SUCCESS) \
													goto IFX_Handler;

/*! \def IFX_MEM_REALLOC
    \brief Macro that re-allocates request amount of memory to already alloc'ed pointer.
*/
#define IFX_MEM_REALLOC(ptr, type, nmemb, size, _ret, _handler) { \
                                                    type t_ptr = NULL; \
                                                    t_ptr = (type)realloc(ptr, nmemb * size); \
                                                    if(t_ptr == NULL) { \
                                                        _ret = IFX_FAILURE; \
                                                        goto _handler; \
                                                    } \
                                                    ptr = t_ptr; \
													memset(ptr, 0x00, nmemb * size); \
                                                }

/*! \def nEATW
    \brief Macro that defines the TBD.
*/
#define nEATW(s)                            {while (gisspace(*s)) s++;}	// This MACRO is for eating white space.

typedef int32(*ROLLBACK_FN) (void *rollback_data, char8 * stop_conf,
			     char8 * start_conf, uint32 flags);

/*! \def MAKE_SECTION_COUNT_TAG
    \brief Macro that forms a rc.conf tag for section count.
*/
#define		MAKE_SECTION_COUNT_TAG(secName, buf)	sprintf(buf, "%s_Count", secName);

/*! \def MAKE_SECTION_ELEMENT_TAG
    \brief Macro that forms a rc.conf tag.
*/
#define		MAKE_SECTION_ELEMENT_TAG(tag_prefix, index, field, buf)		sprintf(buf, "%s_%d_%s", tag_prefix, index, field);

/*! \def FORM_CFG_TAG
    \brief Macro that generates the config buffer to write to rc.conf.
*/
#define		FORM_CFG_TAG(buf, tag_prefix, index, field)		MAKE_SECTION_ELEMENT_TAG(tag_prefix, index, field, buf)

#ifdef IFX_MAPI_ROLLBACK_SUPPORT
/*! \def CHECKPOINT_RET
    \brief Macro that defines the checkpoint operation.
*/
#define CHECKPOINT_RET(_ifx_flags, _SysConfFile, _TempSysConfFile, _fallback_lbl)
/*! \def ROLLBACK_CFG_DB_RET
    \brief Macro that defines the rollback operation.
*/
#define ROLLBACK_CFG_DB_RET(_SysConfFile, _CheckPoint_File, _flags, _fallback_lbl)
 /*! \def ROLLBACK_DEV_RST_RET
    \brief Macro that defines the rollback operation.
  */
#define ROLLBACK_DEV_RST_RET(_fPtr, _fData, _stopConf, _startConf, _fnName, _fallback_lbl)
#else

#define CHECKPOINT_RET(_ifx_flags, _SysConfFile, _TempSysConfFile, _fallback_lbl) { \
								if (!(_ifx_flags & IFX_F_DONT_CHECKPOINT)) { \
									if ((ret = (ifx_copy_file(_SysConfFile, _TempSysConfFile))) != IFX_SUCCESS) \
										goto _fallback_lbl; \
									 } \
								}

/*! \def ROLLBACK_CFG_DB_RET
    \brief Macro that defines the rollback operation.
*/
#define ROLLBACK_CFG_DB_RET(_SysConfFile, _CheckPoint_File, _flags, _fallback_lbl) { }
/*! \def ROLLBACK_DEV_RST_RET(
    \brief Macro that defines the rollback operation.
*/
#define ROLLBACK_DEV_RST_RET(_fPtr, _fData, _stopConf, _startConf, _fnName, _fallback_lbl) { }
#endif

#ifdef TR69_DEFINED
/*! \def IFX_ALLOC_TR69ID
    \brief Macro that defines the rollback opearation.
*/
#define IFX_ALLOC_TR69ID(_iid, _distinct_param, _fallback_lbl) { \
				    if(ifx_alloc_tr69id(&_iid, _distinct_param) != IFX_SUCCESS) { \
								char8 temp_dbg_str[MAX_FILELINE_LEN]; \
				        IFX_DBG("[%s:%d]:alloc tr69 id failed for [%s]", __FUNCTION__, __LINE__, _iid.cpeId.secName); \
				        sprintf(temp_dbg_str, "echo '[%s:%d]:alloc tr69 id failed for [%s]' >> /tmp/devm_al.log", __FUNCTION__, __LINE__, _iid.cpeId.secName); \
								system(temp_dbg_str); \
				        ret = IFX_FAILURE; \
				        goto _fallback_lbl; \
				    } \
				}
#else
#define IFX_ALLOC_TR69ID(_iid, _distinct_param, _fallback_lbl) { \
					ret = IFX_SUCCESS; \
				}
#endif				// TR69_DEFINED

#ifdef TR69_DEFINED
/*! \def IFX_CHECK_ACL
    \brief Macro that calls TR-069 adaptation layer function for ACL.
*/
#define IFX_CHECK_ACL(_iid, _numFvp, _array_fvp, _flags, _fallback_lbl) { \
					if(ifx_check_acl(_iid, _numFvp, _array_fvp, _flags) != IFX_SUCCESS) { \
							IFX_DBG("[%s:%d]:ACL CHeck failed", \
											__FUNCTION__, __LINE__); \
							ret = IFX_FAILURE; \
							goto _fallback_lbl; \
					} \
				}
#else
#define IFX_CHECK_ACL(_iid, _numFvp, _array_fvp, _flags, _fallback_lbl) { \
					ret = IFX_SUCCESS; \
				}
#endif				// TR69_DEFINED

#ifdef TR69_DEFINED
/*! \def CHECK_N_SEND_NOTIFICATION
    \brief Macro that calls TR-069 adaptation layer function for notification.
*/
#define CHECK_N_SEND_NOTIFICATION(_ifx_id, _ifx_count, _ifx_fvp, _ifx_flags, _fallback_lbl)  { \
					if ((_ifx_id.config_owner) != (IFX_TR69)) { \
						{ \
							if(_ifx_count > 0) { \
								if ((ifx_check_n_send_notification(&_ifx_id, _ifx_count, _ifx_fvp, _ifx_flags) != IFX_SUCCESS)) { \
									ret = IFX_FAILURE; \
									IFX_DBG("Notification protocol api failed"); \
									goto _fallback_lbl; \
								} \
							} \
						} \
					} \
				}
#else
#define CHECK_N_SEND_NOTIFICATION(_ifx_id, _ifx_count, _ifx_fvp, _ifx_flags, _fallback_lbl)  { \
					ret = IFX_SUCCESS; \
				}
#endif				// TR69_DEFINED

/*! \def CHECK_ACL_RET
    \brief Macro that generates the list of modified name-value pairs for a modify operation requested to a set MAPI.
*/
#define CHECK_ACL_RET(_ifx_id, _ifx_count, _ifx_fvp, _chg_count, _chg_fvp, _flags, _fallback_lbl) \
				{ \
					ret = IFX_SUCCESS; \
					if (ifx_check_acl_n_form_chgd_array(&_ifx_id, _ifx_count, _ifx_fvp, (IFX_OUT uint32 *)&_chg_count, &_chg_fvp, _flags )!= IFX_SUCCESS) \
						ret = IFX_ACL_CHECK_FAILED; \
					if (ret != IFX_SUCCESS) \
						goto _fallback_lbl; \
				}

#ifdef TR69_DEFINED
/*! \def UPDATE_ID_MAP_N_ATTRIBUTES
    \brief Macro that calls TR-069 adaptation layer function for updation of mapping section entries.
*/
#define UPDATE_ID_MAP_N_ATTRIBUTES(_ifx_id_ptr, _ifx_count, _ifx_arr_fvp, _ifx_flags, _fallback_lbl) { \
 					if ((ret = ifx_update_map_n_attr(_ifx_id_ptr, _ifx_count, _ifx_arr_fvp, _ifx_flags))!= IFX_SUCCESS) \
					    goto _fallback_lbl; \
					}
#else
#define UPDATE_ID_MAP_N_ATTRIBUTES(_ifx_id_ptr, _ifx_count, _ifx_arr_fvp, _ifx_flags, _fallback_lbl) { \
					ret = IFX_SUCCESS; \
					}
#endif				// TR69_DEFINED

/*! \def GET_WAN_CONN_NAME
    \brief Macro that defines the TBD.
*/
#define GET_WAN_CONN_NAME(p, index)		((p) + (MAX_NAME_LEN * (index)))

/*! \def IFX_GET_INDEX_FROM_CPEID
    \brief Macro that gives instance of the object based on its cpe id value.
*/
#define IFX_GET_INDEX_FROM_CPEID(file, cpe_id, index) { \
								if(ifx_get_index_from_cpe_id(file, &cpe_id, \
												(int32 *)&index) != IFX_SUCCESS) { \
									ret = IFX_FAILURE; \
									goto IFX_Handler; \
								} \
							}

/*! \def IFX_GET_INDEX_FROM_PCPEID
    \brief Macro that gives instance of the object based on its parent cpe id value.
*/
#define IFX_GET_INDEX_FROM_PCPEID(file, pcpe_id, index) { \
								if(ifx_get_index_from_pcpe_id(file, &pcpe_id, \
												&index) != IFX_SUCCESS) { \
									ret = IFX_FAILURE; \
									goto IFX_Handler; \
								} \
							}
// 705182:Pramod start
#ifdef TR69_DEFINED
/*! \def IFX_TR69_EVENT_HANDLER
    \brief Macro that calls event handler for any TR-069 notifications.
*/
#define IFX_TR69_EVENT_HANDLER(_evtType, _evtState, _iid, _array_fvp, _count, _handler) { \
				if(ifx_tr69_event_handler(_evtType, _evtState, &_iid, _count, _array_fvp) != IFX_SUCCESS) { \
						IFX_DBG("[%s:%d] tr69 event handler returned error", __FUNCTION__, __LINE__); \
						goto _handler; \
				} \
			}
#else
/*! \def IFX_TR69_EVENT_HANDLER
    \brief Macro that calls event handler for any TR-69 notifications.
*/
#define IFX_TR69_EVENT_HANDLER(_evtType, _evtState, _iid, _array_fvp, _count, _handler) { \
			IFX_DBG("[%s:%d] tr69 disabled", __FUNCTION__, __LINE__); \
				}
#endif				// TR69_DEFINED
// 705182:Pramod end

// Subramani- To modify interface parameters

/*! \def IFX_GET_INTF_ATTR
    \brief Macro that defines the Interface Get Attribute.
*/
#define IFX_GET_INTF_ATTR 0	/*!<  Interface Get Attribute */

/*! \def IFX_SET_INTF_ATTR
    \brief Macro that defines the Interface Set Attribute.
*/
#define IFX_SET_INTF_ATTR 1	/*!<  Interface Set Attribute */

/********************************************************************/
/*****                          IGMP                            *****/
/********************************************************************/

/*! \def IFX_IGMPv2_SNOOPING_ENABLE
    \brief Macro that defines the IGMPv2 Snooping Enable flag
*/
#define IFX_IGMPv2_SNOOPING_ENABLE 1	/*!<  IGMPv2 Snooping Enable */

/*! \def IFX_IGMPv2_SNOOPING_DISABLE
    \brief Macro that defines the IGMPv2 Snooping Disable flag
*/
#define IFX_IGMPv2_SNOOPING_DISABLE 2	/*!<  IGMPv2 Snooping Disable */

/*! \def 
    \brief Macro that defines the TBD.
*/
#define IFX_MCAST_ROUTER_PORT_ADD 	3

/*! \def 
    \brief Macro that defines the TBD.
*/
#define IFX_MCAST_ROUTER_PORT_REMOVE 	4

/********************************************************************/
/*****                         IPQoS                            *****/
/********************************************************************/

/*! \def IFX_MAPI_QoS_MAX_ALGO
    \brief Macro that defines the  QoS - Maximum Algorithms value.
*/
#define IFX_MAPI_QoS_MAX_ALGO 8	/*!<  QoS - Maximum Algorithms */

/*! \def IFX_MAX_IPQOS_APP_LIST_LEN
    \brief Macro that defines the IP-QoS Application List size.
*/
#define IFX_MAX_IPQOS_APP_LIST_LEN 1025	/*!<  IP-QoS Application List */

/*aliases */
/*! \def IFX_MAPI_IF_NAME_LEN
    \brief Macro that defines the Interface Length for MAPI.
*/
#define IFX_MAPI_IF_NAME_LEN  MAX_IF_NAME	/*!<  MAPI Interface Name */

/*! \def IFX_MAPI_MAC_ADDR_LEN
    \brief Macro that defines the MAC Address length for MAPI.
*/
#define IFX_MAPI_MAC_ADDR_LEN  MAX_MAC_ADDR_LEN	/*!< MAPI MAC Address Length */

/*! \def IFX_MAPI_TRAFFIC_CLASS_LEN
    \brief Macro that defines the Traffic Class Length.
*/
#define IFX_MAPI_TRAFFIC_CLASS_LEN 257	/*!<  Traffic Class Length */

/*IPQoS End */

/********************************************************************/
/*****                      BACKUP-RESTORE                      *****/
/********************************************************************/

#ifdef CONFIG_FEATURE_SELECTIVE_BACKUP_RESTORE

/*! \def DBFILE_PARTIAL_BKUP_RSTR
    \brief Macro that defines the Partial backup/restore database file
*/
#define DBFILE_PARTIAL_BKUP_RSTR "/etc/backup.db"	/*!<  Partial backup/restore database file */

/*! \def FILE_TEMP_RC_CONF
    \brief Macro that defines the temperory configuration file
*/
#define FILE_TEMP_RC_CONF "/tmp/rc.conf.tmp"	/*!<  temperory configuration file */

/*! \def NEXT_CPEID_SECTION
    \brief Macro that defines the next cpeid section 
*/
#define NEXT_CPEID_SECTION "next_cpeid"	/*!<  next cpeid section */

/*! \def NEXT_CPEID_SUFFIX
    \brief Macro that defines the next cpeid suffix
*/
#define NEXT_CPEID_SUFFIX "nextCpeId"	/*!< next cpeid suffix  */

#ifdef CONFIG_PACKAGE_IFX_DEVM

/*! \def IFX_ACTION_BACKUP
    \brief Macro that defines the back up action flag
*/
#define IFX_ACTION_BACKUP 1	/*!<  back up action flag */

/*! \def IFX_ACTION_RESTORE
    \brief Macro that defines the restore action flag
*/
#define IFX_ACTION_RESTORE 2	/*!<  restore action flag */

/*! \def IFX_ACTION_ADD
    \brief Macro that defines the add action flag
*/
#define IFX_ACTION_ADD 3	/*!< add action flag */

/*! \def IFX_ACTION_DELETE
    \brief Macro that defines the delete action flag
*/
#define IFX_ACTION_DELETE 4	/*!<  delete action flag */

#endif				/* CONFIG_PACKAGE_IFX_DEVM */

#endif				/* CONFIG_FEATURE_SELECTIVE_BACKUP_RESTORE */

/* BACKUP-RESTORE End */


#define MAX_WAN_MAC_ADDR 4

/*To specify wan connections to fetch(from wan_main section)*/
#define GET_WAN_CONFIG_ATM 0
#define GET_WAN_CONFIG_ETH 1
#define GET_WAN_CONFIG_PTM 2
#define GET_WAN_CONFIG_ALL 3

#define GET_WAN_PTR(pWan, wan_cfg) { \
		if(wan_cfg->type == WAN_LINK_TYPE_PPPOE || wan_cfg->type == WAN_LINK_TYPE_PPPOATM) { \
			pWan = wan_cfg->wancfg.ppp; \
		} \
		else { \
			pWan = wan_cfg->wancfg.ip; \
		} \
	}

#define GET_WAN_COMM_PTR(pWan, t_wan) { \
		if(t_wan->type == WAN_TYPE_PPP) \
			pWan = t_wan->wancfg.ppp.wan_cfg; \
		else \
			pWan = t_wan->wancfg.ip.wan_cfg; \
	}

#define GET_WAN_COMM_PTR_1(pWan, t_wan) { \
		if(t_wan.type == WAN_TYPE_PPP) \
			pWan = t_wan.wancfg.ppp.wan_cfg; \
		else \
			pWan = t_wan.wancfg.ip.wan_cfg; \
	}

#define GET_WAN_TYPE_N_SEC_FROM_CONN_NAME(connName, type, secName) { \
		if(strstr(connName, "WANIP")) { \
			type = WAN_TYPE_IP; \
			sprintf(secName, "%s", TAG_WAN_IP); \
		} \
		else { \
			type = WAN_TYPE_PPP; \
			sprintf(secName, "%s", TAG_WAN_PPP); \
		} \
	}

#define GET_WAN_TYPE_N_IDX_FROM_CONN_NAME(connName, type, index) { \
		if(strstr(connName, "WANIP")) { \
			type = WAN_TYPE_IP; \
			sscanf(connName, "WANIP%d", &index); \
		} \
		else { \
			type = WAN_TYPE_PPP; \
			sscanf(connName, "WANPPP%d", &index); \
		} \
	}

#define GET_WAN_IDX_FROM_CONN_NAME(connName, index) { \
		if(strstr(connName, "WANIP")) { \
			sscanf(connName, "WANIP%d", &index); \
		} \
		else { \
			sscanf(connName, "WANPPP%d", &index); \
		} \
	}

#define GET_WAN_DETAILS_FROM_CONN_NAME(connName, type, index, secName) { \
		if(strstr(connName, "WANIP")) { \
			type = WAN_TYPE_IP; \
			sscanf(connName, "WANIP%d", &index); \
			sprintf(secName, "%s", TAG_WAN_IP); \
		} \
		else { \
			type = WAN_TYPE_PPP; \
			sscanf(connName, "WANPPP%d", &index); \
			sprintf(secName, "%s", TAG_WAN_PPP); \
		} \
	}

#ifdef CONFIG_FEATURE_IFX_MAPI_DEBUG
#define IFX_MAPI_DEBUG(fd, file, text, args...)   \
do {  \
      FILE  *fd = NULL; \
      if((fd = fopen(file, "a")) == NULL) \
         system("echo \"debug file could not be opened in "file"!!\" >> /tmp/httpd_error");  \
      fprintf(fd, "[%s:%s:%d]: "text"\n\r", __FILE__, __FUNCTION__, __LINE__, ##args);   \
      fclose(fd); \
   } while (0)
#else
#define IFX_MAPI_DEBUG(fd, file, text, args...)
#endif				/* #if 1 */

#ifndef LTQ_MAX_NUM_RADIO
/*! \def LTQ_MAX_NUM_RADIO
    \brief Macro that defines the maximum number physical radios for WLAN.
*/
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
#define LTQ_MAX_NUM_RADIO 2	/*!<  Maximum number of physical radio */
#else
#define LTQ_MAX_NUM_RADIO 1	/*!<  Maximum number of physical radio */
#endif
#endif				/* #ifndef LTQ_MAX_NUM_RADIO */

#ifndef LTQ_MAX_NUM_VAP
/*! \def LTQ_MAX_NUM_VAP
    \brief Macro that defines the maximum number of VAPs.
*/
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
#define LTQ_MAX_NUM_VAP 16	/*!<  Maximum number of VAP */
#else
#define LTQ_MAX_NUM_VAP 8	/*!<  Maximum number of VAP */
#endif
#endif				/* #ifndef LTQ_MAX_NUM_VAP */

#ifndef LTQ_MAX_NUM_MAC_FILTER_ENTRIES
#define LTQ_MAX_NUM_MAC_FILTER_ENTRIES 64		/* Maximum number of entries for MAC filter table */
#endif /* #ifndef LTQ_MAX_NUM_MAC_FILTER_ENTRIES */

#ifdef CONFIG_LTQ_LOG_TIMESTAMP
#include <sys/time.h>
#endif

#ifdef CONFIG_LTQ_LOG_TIMESTAMP
#define LTQ_LOG_TIMESTAMP(args...)   \
	do {  \
		FILE  *fd = NULL; \
		struct timeval tv; \
		gettimeofday(&tv, NULL); \
		if((fd = fopen("/tmp/wlanprofiling.log", "a")) == NULL) \
			system("echo \"/tmp/wlanprofiling.log could not be opened in !!\""); \
			fprintf(fd, "[%s: %s: %d]: "args" %d,%d\n\r", __FILE__, __FUNCTION__, __LINE__, (int32)tv.tv_sec,(int32)tv.tv_usec);   \
		fclose(fd); \
		if((fd = fopen("/tmp/wlanprofiling.raw", "a")) == NULL) \
			system("echo \"/tmp/wlanprofiling.raw could not be opened in !!\""); \
			fprintf(fd, "%d,%06d\n\r", (int32)tv.tv_sec,(int32)tv.tv_usec);   \
		fclose(fd); \
	} while (0)
#else
	#define LTQ_LOG_TIMESTAMP(args...)
#endif				/* #ifdef CONFIG_LTQ_LOG_TIMESTAMP */


#if (defined(HOSTENV) || !defined(__UCLIBC__))
   #define LTQ_STRNCAT(dst,src,len)                strncat(dst,src,len)
   #define LTQ_STRNCPY(dst,src,len)                strncpy(dst,src,len)
#else
   #define LTQ_STRNCAT(dst,src,len)                strlcat(dst,src,len)
   #define LTQ_STRNCPY(dst,src,len)                strlcpy(dst,src,len)
#endif


/*! \def PASSWD_FILE
    \brief Macro for password file path
 */
#define PASSWD_FILE   "/ramdisk/flash/passwd"

/*! \def TAG_USER_OBJ
    \brief Macro that defines section in rc.conf to store user account details
 */
#define TAG_USER_OBJ		"user_obj"

/*! \def TAG_REMOTE_ACCESS
    \brief Macro that defines section in rc.conf to store remote access configuration
 */
#define TAG_REMOTE_ACCESS	"remote_access"

/*! \def FILE_WAN_CONFIG_PID
    \brief Macro that defines PID file for WAN configuration process
 */
#define FILE_WAN_CONFIG_PID				"/var/run/wan_config.pid"

#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
/*! \def FILE_AUTO_DETECT
    \brief Macro that defines WAN auto-detect configuration file
 */
#define FILE_AUTO_DETECT 						"/flash/rc.conf"

/*! \def FILE_AUTO_DETECT_BACKUP
    \brief Macro that defines backup file while WAN auto-detect process is running
 */
#define FILE_AUTO_DETECT_BACKUP 		"/tmp/auto_detect.conf"

/*! \def FILE_AUTO_DETECT_PID
    \brief Macro that defines PID file of WAN auto-detect process
 */
#define FILE_AUTO_DETECT_PID				"/var/run/wan_autodetect.pid"

/*! \def TAG_AUTO_DETECT_CFG
    \brief Macro for defining section that stores WAN auto-detect configuration in rc.conf
 */
#define TAG_AUTO_DETECT_CFG	  			"auto_detect_cfg" 

/*! \def ATM_VLAN_POOL_FIELD
    \brief Macro for field that stores VLANs in rc.conf for L2 probing in ADSL ATM WAN mode
 */
#define ATM_VLAN_POOL_FIELD					"auto_atm_vlan_pool"	

/*! \def ADSL_PTM_VLAN_POOL_FIELD
    \brief Macro for field that stores VLANs in rc.conf for L2 probing in ADSL PTM WAN mode
 */
#define ADSL_PTM_VLAN_POOL_FIELD		"auto_adsl_ptm_vlan_pool"	

/*! \def VDSL_PTM_VLAN_POOL_FIELD
    \brief Macro for field that stores VLANs in rc.conf for L2 probing in VDSL PTM WAN mode
 */
#define VDSL_PTM_VLAN_POOL_FIELD		"auto_vdsl_ptm_vlan_pool"	

/*! \def ETH1_VLAN_POOL_FIELD
    \brief Macro for field that stores VLANs in rc.conf for L2 probing in Ethernet in MII1 WAN mode
 */
#define ETH1_VLAN_POOL_FIELD				"auto_eth1_vlan_pool"	

/*! \def ETH0_VLAN_POOL_FIELD
    \brief Macro for field that stores VLANs in rc.conf for L2 probing in Ethernet in MII0 WAN mode
 */
#define ETH0_VLAN_POOL_FIELD				"auto_eth0_vlan_pool"	

/*! \def VCC_POOL_FIELD
    \brief Macro for field that stores ATM VCs in rc.conf for L2 probing in ADSL ATM WAN mode
 */
#define	VCC_POOL_FIELD							"auto_vcc_pool"

/*! \def ATM_WAN_POOL_FIELD
    \brief Macro for field that stores ATM VCs and WANs in rc.conf for L2 and L3 probing in ADSL ATM WAN mode
 */
#define ATM_WAN_POOL_FIELD					"auto_atm_wan_pool"	
#endif

#endif				// _IFX_API_DEFS_H
