/* 
** =============================================================================
**   FILE NAME        : dw_daemon.h
**   PROJECT          : AMAZON 
**   DATE             : 22-Sep-2011
**   AUTHOR           : Amazon Team
**   DESCRIPTION      : This file contains structure definitions for DUAL WAN

**   REFERENCES       : 
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/
/*! \file dw_daemon.h
    \brief This file contains structure definitions for DUAL WAN Daemon
*/
#ifndef _DW_DAEMON_H
#define _DW_DAEMON_H

/*! \def MAX_STR_LEN
	\brief Macro that defines the maximum string length.
*/
#define MAX_STR_LEN 128	/*!< Length of string that can me formed to pass to system command */

/*!	\def DW_PROBE_WAN_PRIMARY
	\brief Macro that defines the Mode to Probe for.
*/
#define DW_PROBE_WAN_PRIMARY    1	/*!< Probe the primary WAN Mode */

/*!	\def DW_PROBE_WAN_SECONDARY
	\brief Macro that defines the Mode to Probe for.
*/
#define DW_PROBE_WAN_SECONDARY  2	/*!< Probe the secondary WAN Mode */

/*!	\def DW_PROBE_WAN_BOTH
	\brief Macro that defines the Mode to Probe for.
*/
#define DW_PROBE_WAN_BOTH       3	/*!< Probe both primary and secondary WANs */

/*!
	\brief Failover Type Configured
*/
typedef enum dw_fo_type_info {
	FO_NONE,	/*!< Invalid Failover Type */
	FO_CSB,		/*!< Cold StandBy */
	FO_HSB		/*!< Hot StandBy */
} dw_fo_type_info_e;

/*!
	\brief Type of failover supported
*/
typedef enum dw_fo_info {
	FO_DISABLE,	/*!< Failover Support is disabled */
	FO_WO_LOADBAL,	/*!< Failover Supported without loadbalancing */
	FO_WITH_LOADBAL	/*!< Failover Supported with loadbalancing */
} dw_fo_info_e;


/*!
	\brief Current wan mode information
*/
typedef struct dw_wan_info {
	WAN_PHY_MODE phy_mode;	/*!< Phymode */
	WAN_TC wan_tc;	/*!< TC mode */
} dw_wan_info_t;


/*!
	\brief Structure defining the probing parameters
*/
typedef struct dw_probe_info {
	int32 probe_int;	/*!< Probing Interval */
	int32 probe_retry;	/*!< Probing Retries */
	char8 probe_ip_url[MAX_STR_LEN];	/*!< IP or URL on which Probing needs to be done */
} dw_probe_info_t;


/*!
	\brief Physical Link Status
*/
typedef enum dw_phy_link_info {
	PHY_LINK_DOWN,	/*!< Physical Link DOWN */
	PHY_LINK_UP	/*!< Physical Link UP */
} dw_phy_link_info_e;

/*!
	\brief WAN Link Status
*/
typedef enum dw_wan_link_info {
	WAN_LINK_DOWN,	/*!< WAN Link DOWN */
	WAN_LINK_UP	/*!< WAN Link UP */
} dw_wan_link_info_e;


/*!
	\brief Structure that describes the probing status of a connection
*/
typedef struct dw_status_info {
	dw_phy_link_info_e phy_status;	/*!< Physical Status */
	dw_wan_link_info_e wan_status;	/*!< WAN Status */
} dw_status_info_t;


/*!
	\brief Structure that describes the probing status for both
		primary and secondary WAN Connections
*/
typedef struct dw_wan_status_info {
	dw_status_info_t pri_wan_status;	/*!< Primary WAN Connection Status */
	dw_status_info_t sec_wan_status;	/*!< Secondary WAN Connection status */
} dw_wan_status_info_t;


/*!
	\brief Strucutre describes all required parameters for dual WAN
*/
typedef struct dw_config_info {
	dw_fo_info_e fo_state;	/*!< Failover Enabled or Disable Support */
	dw_fo_type_info_e fo_type;	/*!< Failover Type CSB or HSB */
	WAN_PHY_CFG pri_wan_cfg;	/*!< Primary WAN Configuration Parameters */
	WAN_PHY_CFG sec_wan_cfg;	/*!< Secondary WAN Configuration Parameters */
	dw_probe_info_t probe_info;	/*!< Probing parameters */
} dw_config_info_t;
#endif	//_DW_DAEMON_H
