/* 
** =============================================================================
**   FILE NAME        : ifx_lock.c
**   PROJECT          : AMAZON MAPI
**   DATE             : 
**   AUTHOR           : 
**   DESCRIPTION      : This file contains the functions related to Amazon
			Database(rc.conf) Management

**   REFERENCES       : 
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/

/*! \file ifx_lock.h 
    \brief This file contains the functions related to Amazon Database(rc.conf) Management
*/

#ifndef IFX_LOCK_H
#define IFX_LOCK_H

#ifdef __cplusplus
extern "C" {
#endif

#define IFX_LOCK_DEBUG

/*! \def LOCK_FILE_NAME
    \brief Lock file name
*/
#define LOCK_FILE_NAME "/flash/lock.txt"

//#define IFX_LOCK_TIMEOUT_SEC    600      /* 10 minutes */

/*! \def IFX_LOCK_TIMEOUT_SEC
    \brief lock timeout 2.5 min
*/
#define IFX_LOCK_TIMEOUT_SEC    150	/* 2.5 minutes */

/*! \def IFX_TIMED_LOCK_FREQ
    \brief timed lock frequency
*/
#define IFX_TIMED_LOCK_FREQ 100	/* 100 Milliseconds */

/*! \def IFX_LOCK_FILE_SIZE
    \brief lock file size 
*/
#define IFX_LOCK_FILE_SIZE  64	/* 64 bytes */

/*!\fn int ifx_init_lock(const char *pLockFile)
   \brief extern integer type function 
   \param[in] pLockFile
   \return This function initializes lock file
*/
	extern int ifx_init_lock(const char *pLockFile);

/*!\fn int ifx_try_lock(const char *pLockFile, int owner)
   \brief extern integer type function 
   \param[in] pLockFile
   \param[in] owner
   \return This function obtains exclusive lock on file
*/
	extern int ifx_try_lock(const char *pLockFile, int owner);

/*!\fn int ifx_acquire_lock_timed(const char *pLockFile, int owner, int milliSeconds)
   \brief extern integer type function 
   \param[in] pLockFile
   \param[in] owner
   \param[in] milliSeconds
   \return Boolean
*/
	extern int ifx_acquire_lock_timed(const char *pLockFile, int owner,
					  int milliSeconds);

/*!\fn int ifx_release_lock(const char *pLockFile, int owner)
   \brief extern integer type function 
   \param[in] pLockFile
   \param[in] owner
   \return Boolean
*/
	extern int ifx_release_lock(const char *pLockFile, int owner);

#ifdef IFX_LOCK_DEBUG

/*! \def IFX_INIT_LOCK
    \brief lock init 
*/
#define IFX_INIT_LOCK(_ifx_lock_file, _ret) \
		_ret = ifx_init_lock(_ifx_lock_file); \
		if (_ret == 0) { \
			/* printf("%s:%d Lock Init succeeded\n", __FUNCTION__, __LINE__); */ \
		} else \
			printf("%s:%d Lock Init failed\n", __FUNCTION__, __LINE__);

/*! \def IFX_TRY_LOCK
    \brief lock trial 
*/
#define IFX_TRY_LOCK(_ifx_lock_file, _ifx_owner, _ret) \
		_ret = ifx_try_lock(_ifx_lock_file, _ifx_owner); \
		if (_ret == 0) { \
			/* printf("%s:%d Lock(%s) succeeded for owner:%d \n",__FUNCTION__, __LINE__, _ifx_lock_file, _ifx_owner); */ \
		} else \
			printf("%s:%d Lock(%s) failed for owner:%d \n",__FUNCTION__, __LINE__, _ifx_lock_file, _ifx_owner);

/*! \def IFX_TIMED_LOCK
    \brief timed lock 
*/
#define IFX_TIMED_LOCK(_ifx_lock_file, _ifx_owner, _msec_timeout, _ret) \
		_ret = ifx_acquire_lock_timed(_ifx_lock_file, _ifx_owner, _msec_timeout); \
		if (_ret == 0) { \
			/* printf("%s:%d Timed Lock(%s) succeeded for owner:%d \n",__FUNCTION__, __LINE__, _ifx_lock_file, _ifx_owner); */ \
		} else \
			printf("%s:%d Timed Lock(%s) failed for owner:%d \n",__FUNCTION__, __LINE__, _ifx_lock_file, _ifx_owner);

/*! \def IFX_UNLOCK
    \brief unlock 
*/
#define IFX_UNLOCK(_ifx_lock_file, _ifx_owner, _ret) \
		_ret = ifx_release_lock(_ifx_lock_file, _ifx_owner); \
		if (_ret == 0 ) { \
			/* printf("%s:%d Unlock(%s) succeeded for owner:%d \n",__FUNCTION__, __LINE__, _ifx_lock_file, _ifx_owner); */ \
		} else \
			printf("%s:%d Unlock(%s) failed for owner:%d \n",__FUNCTION__, __LINE__, _ifx_lock_file, _ifx_owner);

#else

/*! \def IFX_INIT_LOCK
    \brief lock init 
*/
#define IFX_INIT_LOCK(_ifx_lock_file, _ret) \
		_ret = ifx_init_lock(_ifx_lock_file);

/*! \def IFX_TRY_LOCK
    \brief lock trial 
*/
#define IFX_TRY_LOCK(_ifx_lock_file, _ifx_owner, _ret) \
		_ret = ifx_try_lock(_ifx_lock_file, _ifx_owner);

/*! \def IFX_TIMED_LOCK
    \brief timed lock 
*/
#define IFX_TIMED_LOCK(_ifx_lock_file, _ifx_owner, _msec_timeout, _ret) \
		_ret = ifx_acquire_lock_timed(_ifx_lock_file, _ifx_owner, _msec_timeout);

/*! \def IFX_UNLOCK
    \brief unlock 
*/
#define IFX_UNLOCK(_ifx_lock_file, _ifx_owner, _ret) \
		_ret = ifx_release_lock(_ifx_lock_file, _ifx_owner);

#endif				/* LOCK_DEBUG */

#ifdef __cplusplus
}
#endif
#endif				// #ifndef IFX_LOCK_H
