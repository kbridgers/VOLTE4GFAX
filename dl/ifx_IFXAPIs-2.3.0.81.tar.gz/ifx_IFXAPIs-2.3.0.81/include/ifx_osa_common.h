/**************************************************************************
** FILE NAME     : IFX_Common.h
** PROJECT       : TR69
** MODULES       : Common Libs
** SRC VERSION   : V2.0 
** DATE          : 15-12-2004
** AUTHOR        : Narendra VP
** DESCRIPTION   : Common definitions. 
** REFERENCE     : Coding guide lines.
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author      $Comment
***********************************************************************/

/*! \file ifx_osa_common.h
    \brief This file contains Common definitions.
*/

#ifndef __IFIN_TR69_COMMON_H__
#define __IFIN_TR69_COMMON_H__

#define     IN
#define     OUT
#define     IN_OUT

#define     PUBLIC
#define     EXTERN  extern
#define     STATIC  static

/*! \def IFIN_TR69_NULL
    \brief NULL
*/
#define     IFIN_TR69_NULL   NULL

/*! \def IFIN_DEFAULT_CALLID
    \brief default call ID 
*/
#define   IFIN_DEFAULT_CALLID 0

/*! \def IFIN_TR69_MAX_IPV4
    \brief Maximum IPv4 address length
*/
#define IFIN_TR69_MAX_IPV4   16

/*! \def IFIN_TR69_MAX_MADDR
    \brief Maximum MAC Address length
*/
#define IFIN_TR69_MAX_MADDR  64

#ifdef IIP

/*! \def IFIN_TR69_MAX_ENDPOINTS
    \brief maxmuim end points
*/
#define IFIN_TR69_MAX_ENDPOINTS 1

/*! \def IFIN_TR69_RMID_1
    \brief  
*/
#define IFIN_TR69_RMID_1 1

/*! \def IFIN_TR69_RMID_2
    \brief TODO
*/
#define IFIN_TR69_RMID_2 2
#endif

#ifdef ATA

/*! \def IFIN_TR69_MAX_ENDPOINTS
    \brief maximuim end points
*/
#define IFIN_TR69_MAX_ENDPOINTS 2

/*! \def IFIN_TR69_RMID_1
    \brief TODO
*/
#define IFIN_TR69_RMID_1 2

/*! \def IFIN_TR69_RMID_2
    \brief TODO
*/
#define IFIN_TR69_RMID_2 4
#endif

/*! \def IFIN_TR69_MAX_TELCONFIGINFO
    \brief TODO
*/
#define IFIN_TR69_MAX_TELCONFIGINFO 10

/*! \def IFIN_TR69_DEFAULT_UDP_PORT
    \brief default UDP port
*/
#define IFIN_TR69_DEFAULT_UDP_PORT 5060

/*! \def IFIN_TR69_DEFAULT_TCP_PORT
    \brief default TCP port
*/
#define IFIN_TR69_DEFAULT_TCP_PORT 5060

/*! \def IFIN_TR69_DEFAULT_REG_PORT
    \brief TODO
*/
#define IFIN_TR69_DEFAULT_REG_PORT 59998

/*! \def IFIN_TR69_IPV4LEN
    \brief IPv4 length
*/
#define IFIN_TR69_IPV4LEN    16

/*! \def IFIN_TR69_IPV6LEN
    \brief IPv6 length
*/
#define IFIN_TR69_IPV6LEN    128

/*! \def IFIN_IPC_TR69_DNS
    \brief TR69 DNS
*/
#define IFIN_IPC_TR69_DNS   1

/*! \def IFIN_IPC_TR69_TIMER
    \brief TR69 timer
*/
#define IFIN_IPC_TR69_TIMER 2

/*! \def IFIN_IPC_TR69_STUN
    \brief TODO
*/
#define IFIN_IPC_TR69_STUN  3

/*! \def IFIN_TR69_OFF
    \brief TR69 off 
*/
#define IFIN_TR69_OFF 0

/*! \def IFIN_TR69_ON
    \brief TR69 on
*/
#define IFIN_TR69_ON  1

/*! \enum e_IFIN_TR69_Return
    \brief This enumeration is used for TR69 return type.
*/
typedef enum {
	IFIN_TR69_FAILURE = -1,
	IFIN_TR69_SUCCESS
} e_IFIN_TR69_Return;

/*! \enum e_IFIN_TR69_IpType
    \brief This enumeration is used for TR69 IP address type.
*/
typedef enum {
	IFIN_TR69_TR_IPV4,
	IFIN_TR69_TR_IPV6,
	IFIN_TR69_TR_MADDR
} e_IFIN_TR69_IpType;

/*! \enum e_IFIN_TR69_Protocol
    \brief This enumeration is used for TR69 protocal type.
*/
typedef enum {
	IFIN_TR69_PROTO_UDP = 1,
	IFIN_TR69_PROTO_TCP
} e_IFIN_TR69_Protocol;

/*!
    \brief Structure describing TR69 Transport info .
*/
typedef struct {
	e_IFIN_TR69_IpType eIpType;	/*!< This enumeration is used for TR69 IP address type */
	union {
		char8 szIpV4[IFIN_TR69_IPV4LEN];
		char8 szIpV6[IFIN_TR69_IPV6LEN];
		char8 szMaddr[IFIN_TR69_IPV4LEN];
	} uxDestIp;		/*!< Destination IP */

	int16 iPort;		/*!< Port Number */
} x_IFIN_TR69_TransportInfo;

/*!
    \brief Structure describing TR69 Host info .
*/
typedef struct {
	x_IFIN_TR69_TransportInfo xLocalInfo;
	x_IFIN_TR69_TransportInfo xRemoteInfo;

	e_IFIN_TR69_Protocol eProtocol;
	int32 iDnsId;
} x_IFIN_TR69_HostInfo;

#endif
