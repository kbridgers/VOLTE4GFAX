/*
** =============================================================================
**   FILE NAME        : ifx_api_enums.h
**   PROJECT          : AMAZON MAPI
**   DATE             : 19-Jun-2006
**   AUTHOR           : Amazon API Team
**   DESCRIPTION      : This file contains all the enumeration definitions required for the
			Management API Implementation.

**   REFERENCES       :
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          :
**   $Date            $Author                         $Comment
**
** ============================================================================
*/

/*! \file ifx_api_enums.h
    \brief This file defines the enumerations for IFX MAPI.
*/

#ifndef _IFX_API_ENUMS_H
#define _IFX_API_ENUMS_H
/*!
    \brief Enum containing the rip mode.
*/
enum rip_mode {
	None = 0,		/*!< None */
	RIP1 = 1,		/*!< RIP1 */
	RIP2 = 2,		/*!< RIP2 */
	RIP1_RIP2 = 3		/*!< RIP1 and RIP2 */
};

/*!
    \brief Enum containing the WAN mode.
*/
typedef enum wan_mode {
	WAN_MODE_ATM = 0,	/*!< ADSL ATM WAN mode. */
	WAN_MODE_ETH0 = 1,	/*!< Ethernet WAN mode in MII0. */
	WAN_MODE_ETH1 = 2,	/*!< Ethernet WAN mode in MII1. */
	WAN_MODE_PTM = 3,	/*!< ADSL PTM WAN mode. */
	WAN_MODE_VDSL_PTM = 4,	/*!< VDSL PTM WAN mode. */
	WAN_MODE_VDSL_ATM = 5,	/*!< VDSL ATM WAN mode. */
	WAN_MODE_3G = 6,	/*!< 3G WAN mode. */
	WAN_MODE_LTE = 7        /*!< LTE WAN MODE. */
} WAN_MODE;

/*!
    \brief Enum containing the WAN mode.
*/

typedef enum wan_tc {
	WAN_TC_ATM = 0,		/*!< ATM TC mode. */
	WAN_TC_PTM = 1,		/*!< PTM TC mode. */
	WAN_TC_UNCONFIGURED = -1	/*!< Unconfigured. */
} WAN_TC;

/*!
    \brief Enum containing the WAN mode.
*/
typedef enum wan_phy_mode {
	WAN_PHY_MODE_ADSL2 = 0,	/*!< WAN PHY mode is ADSL PHY. */
	WAN_PHY_MODE_ETH_MII0 = 1,	/*!< WAN PHY mode is Ethernet on MII0. */
	WAN_PHY_MODE_ETH_MII1 = 2,	/*!< WAN PHY mode is EThernet on MII1. */
	WAN_PHY_MODE_VDSL2 = 3,	/*!< WAN PHY mode is VDSL. */
	WAN_PHY_MODE_AUTO = 4,	/*!< WAN PHY mode is AUTO. */
	WAN_PHY_MODE_CELL_WAN = 5,	/*!< WAN PHY mode is CELL WAN. */
	WAN_PHY_MODE_LTE = 6,           /*!< WAN PHY mode is LTE WAN. */
	WAN_PHY_MODE_UNCONFIGURED = -1	/*!< WAN PHY mode is unconfigured. */
} WAN_PHY_MODE;

/*!
    \brief Enum containing route status.
*/
typedef enum route_status {
	ROUTE_STATUS_DISABLED = IFX_DISABLED,	/*!< ROUTE STATUS DISABLED. */
	ROUTE_STATUS_ENABLED = IFX_ENABLED,	/*!< Route status enabled. */
	ROUTE_STATUS_ERROR = 3	/*!< Route status error. */
} ROUTE_STATUS;

/*!
    \brief Enum containing route type.
*/
typedef enum route_type {
	ROUTE_TYPE_DEFAULT = 1,	/*!< Default route type. */
	ROUTE_TYPE_HOST = 2,	/*!< Route type host. */
	ROUTE_TYPE_NET = 3	/*!< Route type net. */
} ROUTE_TYPE;

/*!
    \brief Enum containing IP type.
*/
typedef enum ip_type {
	IP_TYPE_DHCP = 1,	/*!< IP type DHCP. */
	IP_TYPE_STATIC = 2,	/*!< IP type Static. */
	IP_TYPE_AUTO = 0	/*!< IP type Auto. */
} IP_TYPE;

/*!
    \brief Enum containing ethernet status.
*/
typedef enum ethernet_status {
	ETHERNET_STATUS_UP = 1,	/*!< Ethernet status. */
	ETHERNET_STATUS_NOLINK = 2,	/*!< Ethernet NOLINK. */
	ETHERNET_STATUS_ERROR = 3,	/*!< Ethernet error. */
	ETHERNET_STATUS_DISABLED = IFX_DISABLED	/*!< Ethernet disabled. */
} ETHERNET_STATUS;

/*!
    \brief Enum containing max bit rate.
*/
typedef enum eth_max_bit_rate {
	ETH_MAX_BIT_RATE_10 = 1,	/*!< Max bit rate 10 */
	ETH_MAX_BIT_RATE_100 = 2,	/*!< Max bit rate 100 */
	ETH_MAX_BIT_RATE_1000 = 3,	/*!< Max bit rate 1000 */
	ETH_MAX_BIT_RATE_AUTO = 4	/*!< Max bit rate auto */
} ETH_MAX_BIT_RATE;

/*!
    \brief Enum containing duplex mode.
*/
typedef enum eth_duplex_mode {
	ETH_DUPLEX_MODE_HALF = 1,	/*!< Duplex mode half */
	ETH_DUPLEX_MODE_FULL = 2,	/*!< Duplex mode full */
	ETH_DUPLEX_MODE_AUTO = 3	/*!< Duplex mode auto */
} ETH_DUPLEX_MODE;

/*!
    \brief Enum containing LAN host status.
*/
typedef enum lan_host_status {
	LAN_HOST_STATUS_INCATIVE = 0,	/*!< LAN host inactive */
	LAN_HOST_STATUS_ACTIVE = 1	/*!< LAN host active */
} LAN_HOST_STATUS;

/*!
    \brief Enum containing LAN host type.
*/
typedef enum lan_host_type {
	LAN_HOST_ALL_TYPE = 0,	/*!< LAN host all type */
	LAN_HOST_STATIC_TYPE = 1,	/*!< LAN host static type */
	LAN_HOST_DHCP_TYPE = 2,	/*!< LAN host DHCP type */
	LAN_HOST_AUTO_TYPE = 3	/*!< LAN host auto type */
} LAN_HOST_TYPE;

/*!
    \brief Enum definin the physical interface type..
*/
typedef enum phy_if_type {
	PHY_IF_ETHER_TYPE = 0,	/*!< Ether type */
	PHY_IF_USB_TYPE = 1,	/*!< USB type */
	PHY_IF_802_11_TYPE = 2,	/*!< 802.11 type */
	PHY_IF_HOME_PNA_TYPE = 3,	/*!< Home PNA type */
	PHY_IF_HOME_PLUG_TYPE = 4,	/*!< Home plug type */
	PHY_IF_OTHER_TYPE = 5	/*!< Other type */
} PHY_IF_TYPE;

/*!
    \brief This enumeration returns the link type information.
*/
typedef enum link_type {
	LINK_TYPE_UNCONFIGURED = 0,	/*!< Unconfigured. */
	LINK_TYPE_EOATM = 1,	/*!< Ethernet over ATM. */
	LINK_TYPE_IPOATM = 2,	/*!< IP over Ethernet. */
	LINK_TYPE_PPPOATM = 3,	/*!< PPP over ATM. */
	LINK_TYPE_PPPOE = 4,	/*!< PPP over Ethernet. */
	LINK_TYPE_CLIP = 5,	/*!< Classical IP. */
	LINK_TYPE_ETH = 7,
	LINK_TYPE_PTM = 8
} LINK_TYPE;

/*!
    \brief This enumeration returns the aal type information.
*/
typedef enum aal_type {
	AAL_TYPE_AAL0 = 0,	/*!< ATM Adaptation Layer-0. */
	AAL_TYPE_AAL1 = 1,	/*!< ATM Adaptation Layer-1. */
	AAL_TYPE_AAL2 = 2,	/*!< ATM Adaptation Layer-2. */
	AAL_TYPE_AAL3 = 3,	/*!< ATM Adaptation Layer-3. */
	AAL_TYPE_AAL4 = 4,	/*!< ATM Adaptation Layer-4. */
	AAL_TYPE_AAL5 = 5	/*!< ATM Adaptation Layer-5. */
} AAL_TYPE;

/*!
    \brief This enumeration returns the VC encapsulation information.
*/
typedef enum vc_encap {
	VC_ENCAP_LLC = 0,	/*!< LLC/SNAP encapsulation is enabled. */
	VC_ENCAP_VCMUX = 1	/*!< VC Mux encapsulation is enabled. */
} VC_ENCAP;

/*!
    \brief This enumeration returns the WAN link type information.
*/
typedef enum wan_link_type {
	WAN_LINK_TYPE_EOATM = 1,	/*!< Ethernet over ATM. */
	WAN_LINK_TYPE_IPOATM = 2,	/*!< IP over Ethernet. */
	WAN_LINK_TYPE_PPPOATM = 3,	/*!< PPP over ATM. */
	WAN_LINK_TYPE_PPPOE = 4,	/*!< PPP over Ethernet. */
	WAN_LINK_TYPE_CLIP = 5,	/*!< Classical IP. */
	WAN_LINK_TYPE_ETH = 7,
	WAN_LINK_TYPE_PTM = 8
} WAN_LINK_TYPE;

/*!
    \brief This enumeration returns the IP connection trigger configuration.
*/
typedef enum conn_trigger {
	CONN_TRIGGER_ALWAYS_ON = 0,	/*!< Connection is always on. */
	CONN_TRIGGER_ON_DEMAND = 1,	/*!< Dial on Demand support. */
	CONN_TRIGGER_MANUAL = 2	/*!< Connection is created manually. */
} CONN_TRIGGER;

typedef enum wan_l3_proto {
	L3PROTO_IPV4 = 1,
	L3PROTO_IPV6 = 2,
	L3PROTO_V4V6 = 3
} WAN_L3_PROTO;

typedef enum wan_ipv6_cfg_type {
	IPV6_CFGTYPE_AUTO = 0,
	IPV6_CFGTYPE_STATEFUL = 1
} WAN_IPV6_CFG_TYPE;

/*!
    \brief This enumeration returns the dynamic routing protocol for Rx of routes.
*/
typedef enum route_proto_rx {
	ROUTE_PROTO_RX_OFF = 0,	/*!< No routes to be received on this
				   interface. */
	ROUTE_PROTO_RX_RIP_V1 = 1,	/*!< RIP Version 1 Protocol. */
	ROUTE_PROTO_RX_RIP_V2 = 2,	/*!< RIP Version 2 Protocol. */
	ROUTE_PROTO_RX_OSPF = 3	/*!< OSPF - Not supported currently. */
} ROUTE_PROTO_RX;

/*!
    \brief This enumeration returns the wan IP connection type configuration.
*/
typedef enum wan_ip_conn_type {
	WAN_IP_CONN_TYPE_UNCONFIGURED = 0,	/*!< Connection Type is not
						   configured. */
	WAN_IP_CONN_TYPE_IP_ROUTED = 1,	/*!< Routing of IP packets. */
	WAN_IP_CONN_TYPE_IP_BRIDGED = 2	/*!< Bridging of IP in Ethernet
					   frames. */
} WAN_IP_CONN_TYPE;

/*!
    \brief This enumeration returns the WAN IP connection configuration status.
*/
typedef enum wan_ip_conn_status {
	WAN_IP_CONN_STATUS_UNCONFIGURED = 0,	/*!< IP Connection not
						   configured. */
	WAN_IP_CONN_STATUS_CONNECTING = 1,	/*!< IP Connection connecting state. */
	WAN_IP_CONN_STATUS_CONNECTED = 2,	/*!< IP Connection connected state. */
	WAN_IP_CONN_STATUS_PENDING_DISCONNECT = 3,	/*!< IP Connection Pending
							   disconnect. */
	WAN_IP_CONN_STATUS_DISCONNECTING = 4,	/*!< IP connection
						   disconnecting. */
	WAN_IP_CONN_STATUS_DISCONNECTED = 5	/*!< IP connection disconnected. */
} WAN_IP_CONN_STATUS;

/*!
    \brief This enumeration returns the wan PPP connection type configuration.
*/
typedef enum wan_ppp_conn_type {
	WAN_PPP_CONN_TYPE_UNCONFIGURED = 0,	/*!< Connection Type is not
						   configured. */
	WAN_PPP_CONN_TYPE_IP_ROUTED = 1,	/*!< IP Routing of IP packets over PPP
						   interface. */
	WAN_PPP_CONN_TYPE_DHCP_SPOOFED = 2,	/*!< DHCP Spoofed mode over PPP
						   interface - not supported. */
	WAN_PPP_CONN_TYPE_PPPOE_BRIDGED = 3,	/*!< Bridging of PPPoE in
						   Ethernet frames. */
	WAN_PPP_CONN_TYPE_PPPOE_RELAY = 4,	/*!< Relay of PPPoE frames from LAN to
						   WAN ethernet interfaces and
						   vice-versa. */
	WAN_PPP_CONN_TYPE_PPTP_RELAY = 5,	/*!< PPTP Relay from LAN to WAN
						   interfaces and vice-versa. Not
						   support yet. */
	WAN_PPP_CONN_TYPE_L2TP_RELAY = 6	/*!< PPTP Relay from LAN to WAN
						   interfaces and vice-versa. Not
						   support yet. */
} WAN_PPP_CONN_TYPE;

/*!
    \brief This enumeration returns the WAN IP connection configuration status.
*/
typedef enum wan_ppp_conn_status {
	WAN_PPP_CONN_STATUS_UNCONFIGURED = 0,	/*!< IP Connection not
						   configured. */
	WAN_PPP_CONN_STATUS_CONNECTING,	/*!< IP Connection connecting state. */
	WAN_PPP_CONN_STATUS_AUTHENTICATING,	/*!< IP Connection Authenticating
						   State */
	WAN_PPP_CONN_STATUS_CONNECTED,	/*!< IP Connection connected state. */
	WAN_PPP_CONN_STATUS_PENDING_DISCONNECT,	/*!< IP Connection Pending
						   disconnect. */
	WAN_PPP_CONN_STATUS_DISCONNECTING,	/*!< IP connection disconnecting. */
	WAN_PPP_CONN_STATUS_DISCONNECTED	/*!< IP connection disconnected. */
} WAN_PPP_CONN_STATUS;

/*!
    \brief This enumeration denotes Encryption protocol used over PPP.
*/
typedef enum wan_ppp_encr_proto {
	WAN_PPP_ENCR_PROTO_NONE = 0,	/*!< No Encryption. */
	WAN_PPP_ENCR_PROTO_MPPE = 1	/*!< MPPE protocol is used for encryption. */
} WAN_PPP_ENCR_PROTO;

/*!
    \brief This enumeration is used for compression protocol option for PPP packets.
*/
typedef enum wan_ppp_compr_proto {
	WAN_PPP_COMPR_PROTO_NONE = 0,	/*!< No Compression Protocol is used. */
	WAN_PPP_COMPR_PROTO_VANJACOBSON = 1,	/*!< Van-Jackobson algorithm
						   is used. */
	WAN_PPP_COMPR_PROTO_STACLZS = 2	/*!< STAC-LZS algorithm is used. */
} WAN_PPP_COMPR_PROTO;

/*!
    \brief This enumeration is used for type of authentication for PPP session establishment.
*/
typedef enum wan_ppp_auth_proto {
	WAN_PPP_AUTH_PROTO_CHAP = 0,	/*!< CHAP type of authentication
					   protocol. */
	WAN_PPP_AUTH_PROTO_MSCHAP = 1,	/*!< Micorsoft CHAP type of
					   authentication protocol. */
	WAN_PPP_AUTH_PROTO_PAP = 2	/*!< PAP type of authentication protocol. */
} WAN_PPP_AUTH_PROTO;

/*!
    \brief This enumeration returns the wan PPP transport type information.
*/
typedef enum wan_ppp_transport_type {
	WAN_PPP_TRANSPORT_TYPE_PPPOA = 1,	/*!< PPP over ATM support. */
	WAN_PPP_TRANSPORT_TYPE_PPPOE = 2,	/*!< PPP over Ethernet. */
	WAN_PPP_TRANSPORT_TYPE_L2TP = 3,	/*!< Layer-2 Tunneling Protocol
						   support - not available. */
	WAN_PPP_TRANSPORT_TYPE_PPTP = 4	/*!< Point-to-Point Tunneling Protocol
					   support - not available. */
} WAN_PPP_TRANSPORT_TYPE;

/*!
    \brief This enumeration is used for type of Network Address Translation.
*/
typedef enum nat_vs_protocol {
	NAT_VS_PROTOCOL_TCP = 1,	/*!< NAT on TCP Protocol. */
	NAT_VS_PROTOCOL_UDP = 2,	/*!< NAT on UDP Protocol. */
	NAT_VS_PROTOCOL_TCP_UDP = 3	/*!< NAT on TCP-UDP Protocol. */
} NAT_VS_PROTOCOL;

/*!
    \brief This enumeration is used for the state of diagnostics.
*/
typedef enum diagnostic_state {
	WAN_DIAG_NONE = 0,	/*!< No Diagnostics state is on currently. */
	WAN_DIAG_REQUESTED = 1,	/*!< Diagnostics operation was requested. */
	WAN_DIAG_START_DIAGNOSING = 2,	/*!< Diagnostics operation to be
					   started. */
	WAN_DIAG_STILL_DIAGNOSING = 3,	/*!< Diagnostics operation is going
					   on. */
	WAN_DIAG_COMEPLETE = 4,	/*!< Diagnostics operation is complete. */
	WAN_DIAG_ERROR_INT = 5,	/*!< Internal Error occurred during
				   diagnostics. */
	WAN_DIAG_ERROR_EXT = 6	/*!< External Error occurred during
				   diagnostics. */
} DIAGNOSTIC_STATE;

/*!
    \brief This enumeration is used for DSL link status.
*/
typedef enum dsl_link_status {
	DSL_LINK_STATUS_UNAVAILABLE = 0,	/*!< DSL Link is Unavailable. */
	DSL_LINK_STATUS_UP = 1,	/*!< DSL Link Status is UP. */
	DSL_LINK_STATUS_DOWN = 2,	/*!< DSL Link Status is DOWN. */
	DSL_LINK_STATUS_INITIALIZE = 3	/*!< DSL Link Status is Initializing. */
} DSL_LINK_STATUS;

/*!
    \brief This enumeration is used for last error on WAN IP Connection.
*/
typedef enum wanip_last_conn_error {
	WANIP_LAST_CONN_ERROR_NONE = 0,	/*!< No Error. */
	WANIP_LAST_CONN_ERROR_COMMAND_ABORTED = 1,	/*!< Command Aborted Error. */
	WANIP_LAST_CONN_ERROR_NOT_ENABLED_FOR_INTERNET = 2,	/*!< Not Enabled for
								   Internet Error.t */
	WANIP_LAST_CONN_ERROR_USER_DISCONNECT = 3,	/*!< User Disconnected Error. */
	WANIP_LAST_CONN_ERROR_ISP_DISCONNECT = 4,	/*!< ISP Disconnected Error. */
	WANIP_LAST_CONN_ERROR_IDLE_DISCONNECT = 5,	/*!< Idle Disconnected Error. */
	WANIP_LAST_CONN_ERROR_FORCED_DISCONNECT = 6,	/*!< Forced Disconnect
							   Error. */
	WANIP_LAST_CONN_ERROR_NO_CARRIER = 7,	/*!< No carrier error. */
	WANIP_LAST_CONN_ERROR_IP_CONFIGURATION = 8,	/*!< IP configuration error. */
	WANIP_LAST_CONN_ERROR_UNKNOWN = 9	/*!< Unknown Error */
} WANIP_LAST_CONN_ERROR;

/*!
    \brief This enumeration is used for last connection error on WAP PPP Connection.
*/
typedef enum wanppp_last_conn_error {
	WANPPP_LAST_CONN_ERROR_NONE = 0,	/*!< None */
	WANPPP_LAST_CONN_ERROR_ISP_TIME_OUT = 1,	/*!< ISP Time out */
	WANPPP_LAST_CONN_ERROR_COMMAND_ABORTED = 2,	/*!< Command aborted error. */
	WANPPP_LAST_CONN_ERROR_NOT_ENABLED_FOR_INTERNET = 3,	/*!< Not
								   enabled for
								   internet
								   error. */
	WANPPP_LAST_CONN_ERROR_BAD_PHONE_NUMBER = 4,	/*!< Bad phone number
							   error. */
	WANPPP_LAST_CONN_ERROR_USER_DISCONNECT = 5,	/*!< user disconnect error. */
	WANPPP_LAST_CONN_ERROR_ISP_DISCONNECT = 6,	/*!< ISP disconnection error. */
	WANPPP_LAST_CONN_ERROR_IDLE_DISCONNECT = 7,	/*!< Idle disconnection error.
							 */
	WANPPP_LAST_CONN_ERROR_FORCED_DISCONNECT = 8,	/*!< Forced
							   disconnection error.
							 */
	WANPPP_LAST_CONN_ERROR_SERVER_OUT_OF_RESOURCES = 9,	/*!< Error due to
								   Server went out of
								   resources. */
	WANPPP_LAST_CONN_ERROR_RESTRICTED_LOGON_HOURS = 10,	/*!< Error due to
								   restricted Login
								   Hours. */
	WANPPP_LAST_CONN_ERROR_ACCOUNT_DISABLED = 11,	/*!< Account disabled
							   error. */
	WANPPP_LAST_CONN_ERROR_ACCOUNT_EXPIRED = 12,	/*!< Account expired
							   error. */
	WANPPP_LAST_CONN_ERROR_PASSWORD_EXPIRED = 13,	/*!< Password expired
							   error. */
	WANPPP_LAST_CONN_ERROR_AUTHENTICATION_FAILURE = 14,	/*!< Authentication
								   failure error. */
	WANPPP_LAST_CONN_ERROR_NO_DIALTONE = 15,	/*!< No dialtone error. */
	WANPPP_LAST_CONN_ERROR_NO_CARRIER = 16,	/*!< No carrier error. */
	WANPPP_LAST_CONN_ERROR_NO_ANSWER = 17,	/*!< No answer error. */
	WANPPP_LAST_CONN_ERROR_LINE_BUSY = 18,	/*!< Line busy error. */
	WANPPP_LAST_CONN_ERROR_UNSUPPORTED_BPS = 19,	/*!< Unsupported Bits
							   per second error. */
	WANPPP_LAST_CONN_ERROR_TOO_MANY_LINE_ERRORS = 20,	/*!< Too many line
								   errors */
	WANPPP_LAST_CONN_ERROR_IP_CONFIGURATION = 21,	/*!< Erroneous IP
							   configuration */
	WANPPP_LAST_CONN_ERROR_UNKNOWN = 22	/*!< Unknown error. */
} WANPPP_LAST_CONN_ERROR;

/*!
    \brief This enumeration is used for F5 loopback state on ATM VCC.
*/
typedef enum wan_atmf5_loopback_state {
	LOOPBACK_DISABLED = 0,	/*!< Loopback is disabled. */
	LOOPBACK_ENABLED	/*!< Loopback is enabled. */
} WAN_ATMF5_LOOPBACK_STATE;

/*!
    \brief This enumeration is used for F5 Continuity Check on ATM VCC.
*/
typedef enum wan_atmf5_cc_check {
	CC_CHECK_DISABLED = 0,	/*!< CC check is disabled. */
	CC_CHECK_ENABLED	/*!< CC check is enabled. */
} WAN_ATMF5_CC_CHECK;

/*!
    \brief This enumeration is used for type of optional CC checks on ATM VCC.
*/
typedef enum wan_atmf5_cc_check_opt {
	CC_CHECK_OPT_SINK = 0,	/*!< Acting as Sink. */
	CC_CHECK_OPT_SOURCE,	/*!< Acting as Source. */
	CC_CHECK_OPT_BOTH	/*!< Acting as both Sink and Source. */
} WAN_ATMF5_CC_CHECK_OPT;

/*!
    \brief This enumeration is used for type of event communication.
*/
typedef enum ifx_event_type {
	EVT_TYPE_LAN_INTERFACE = 1,	/*!< LAN interface Event */
	EVT_TYPE_WAN_INTERFACE = 2,	/*!< WAN interface Event */
	EVT_TYPE_LAN_IPADDRESS = 3,	/*!< LAN IP Address Event */
	EVT_TYPE_WAN_IPADDRESS = 4,	/*!< WAN IP address Event */
	EVT_TYPE_ROUTE = 5,	/*!< Route Event */
	EVT_TYPE_WAN_PHY = 6,	/*!< WAN PHY Event */
	EVT_TYPE_LAN_PHY = 7,	/*!< LAN PHY Event */
	EVT_TYPE_ADSL_LINK_STATUS = 8,	/*!< ADSL link status Event */
	EVT_TYPE_WLAN_STATUS = 9,	/*!< WAN status Event */
	EVT_TYPE_DEFAULT_WAN = 10,	/*!< Default WAN Event */
	EVT_TYPE_GHN_DOMAINNAME = 11,      /*!< G.hn Domain Name Event*/
  EVT_TYPE_GHN_DOMAINSEC = 12,       /*!< G.hn Domain Security Status Event*/
  EVT_TYPE_GHN_DMSTATUS = 13,        /*!< G.hn DM Status Event*/
  EVT_TYPE_GHN_DEVICENAME = 14,      /*!< G.hn Device Name Event*/
  EVT_TYPE_GHN_DEVICELIST = 15,      /*!< G.hn Device List Event*/
  EVT_TYPE_GHN_L2UTILSHUTDOWN = 16,  /*!< G.hn L2 Utility Shutdown Event*/
  EVT_TYPE_DEFAULT_WAN_CHANGE = 17,	/*!<Default Wan Change event */
	EVT_TYPE_AUTODETECT = 18 ,/*!< Auto Detect Event */
	 EVT_TYPE_NTP_SYNC_STATUS_CHANGE=19, /*!< NTP SYNC STATUS CHANGE Event */
	EVT_TYPE_ETH_LINK_STATUS = 20, /*!< Ethernet link status event */
	EVT_TYPE_WAN = 21, /*!< WAN configuration trigger event */
	EVT_TYPE_TR69_SYS_INIT = 22 	/* !< SysInit event for devm */
} IFX_EVENT_TYPE;

/*!
    \brief Enum containing State of Event.
*/
typedef enum ifx_event_state {
	EVT_STATE_UP = 1,	/*!< State Up Event */
	EVT_STATE_DOWN = 2,	/*!< State Down Event */
	EVT_STATE_ERR = 3,	/*!< State Error Event */
	EVT_STATE_ADD = 4,	/*!< State Addition Event */
	EVT_STATE_DEL = 5,	/*!< State Deletion Event */
	EVT_STATE_MOD = 6,	/*!< State Modify Event */
	EVT_STATE_ENA = 7,	/*!< State Enable Event */
	EVT_STATE_DIS = 8,	/*!< State Disable Event */
	EVT_STATE_TEST_COMPLETE = 9,	/*!< State Test Complete Event */
	EVT_STATE_START = 10,	/*!< State Start Event */
	EVT_STATE_STOP = 11,	/*!< State Stop Event */
	EVT_STATE_COMPLETE = 12,	/*!< State Complete Event */
	EVT_STATE_STOP_ALL = 13,	/*!< State Stop all Event */
	EVT_STATE_START_ALL = 14	/*!< State Start all Event */
} IFX_EVENT_STATE;

/*!
    \brief Enum containing Syslog Filter Mode.
*/
typedef enum syslog_mode {
	SYSLOG_LOCAL = 0,	/*!< Syslog - Local Mode */
	SYSLOG_REMOTE,		/*!< Syslog - Remote Mode */
	SYSLOG_BOTH_LOCAL_REMOTE	/*!< Syslog - Both Local and Remote Mode */
} SYSLOG_MODE;

/*!
    \brief Enum containing display level of Syslog.
*/
typedef enum syslog_disp_level {
	SYSLOG_DISP_LEVEL_EMERG = 0,	/*!< Syslog Display level emergency */
	SYSLOG_DISP_LEVEL_ALERT,	/*!< Syslog Display Level alert */
	SYSLOG_DISP_LEVEL_CRIT,	/*!< Syslog Display level critical */
	SYSLOG_DISP_LEVEL_ERR,	/*!< Syslog display level error */
	SYSLOG_DISP_LEVEL_WARN,	/*!< Syslog display level warning */
	SYSLOG_DISP_LEVEL_NOTICE,	/*!< Syslog display level notice */
	SYSLOG_DISP_LEVEL_INFO,	/*!< Syslog display level information */
	SYSLOG_DISP_LEVEL_DEBUG,	/*!< Syslog display level debug */
	SYSLOG_DISP_LEVEL_DEFAULT	/*!< Syslog display level default */
} SYSLOG_DISP_LEVEL;

/*!
    \brief Enum containing state of WAN PPP bridge.
*/
typedef enum wan_ppp_bridge_enable {
	WAN_PPP_BRIDGE_ENABLE_OFF = 0,	/*!< Enable-Off of WAN PPP Bridge */
	WAN_PPP_BRIDGE_ENABLE_ON	/*!< Enable-On of WAN PPP Bridge */
} WAN_PPP_BRIDGE_ENABLE;

/*!
    \brief Enum containing class of product.
*/
typedef enum ifx_product_class {
	IFX_PRODUCT_CLASS_DEVICE = 0,	/*!< Device Product Class */
	IFX_PRODUCT_CLASS_IGD	/*!< IGD Product Class */
} DEVICE_MODE;

#if defined (CONFIG_FEATURE_IFX_WIRELESS)
/* WLAN -  start */

/*!
    \brief Enum containing WLAN Authentication state.
*/
typedef enum wlan_auth_state {
	IFX_MAPI_WLAN_STA_UNAUTHENTICATED = 0,	/*!< Unauthneticated State */
	IFX_MAPI_WLAN_STA_AUTHENTICATED = 1	/*!< Authenticated State */
} IFX_MAPI_WLAN_STA_AUTH_STATE;

/*!
    \brief This enumeration is used for mode of Station MAC address control feature in WLAN AP/VAP.
*/
typedef enum macaddr_control_mode {
	MACADDR_CONTROL_ALLOW = 0,	/*!< Allows specified STA MAC addr (s). */
	MACADDR_CONTROL_DENY,	/*!< Deny specified STA MAC addr (s). */
	MACADDR_CONTROL_DISABLE,	/*!< Disable MAC Address Control feature. */
	MACADDR_CONTROL_FLUSH	/*!< Flush existing STA MAC addr (s). */
} MACADDR_CONTROL_MODE;

/*!
    \brief This enumeration is used for type of interface for MAC Control.
*/
typedef enum macaddr_control_intf_type {
	MACADDR_CONTROL_INTF_TYPE_ALL = 0,	/*!< All Interfaces on LAN. */
	MACADDR_CONTROL_INTF_TYPE_USB,	/*!< USB type of Interface on LAN. */
	MACADDR_CONTROL_INTF_TYPE_ETH,	/*!< Ethernet type of Interfaces on
					   LAN. */
	MACADDR_CONTROL_INTF_TYPE_WLAN	/*!< WLAN type of Interfaces on LAN. */
} MACADDR_CONTROL_INTF_TYPE;

/* Enumaration of WLAN Device Types */

/*!
    \brief Enum containing WLAN device type.
*/
typedef enum ifx_mapi_wlan_devtype {
	IFX_MAPI_WLAN_DEV_TYPE_AP = 0,	/*!< AP type WLAN */
	IFX_MAPI_WLAN_DEV_TYPE_VAP = 1,	/*!< VAP type WLAN */
	IFX_MAPI_WLAN_DEV_TYPE_STA = 2,	/*!< Station type WLAN */
	IFX_MAPI_WLAN_DEV_TYPE_REP = 3,	/*!< Repeator Type WLAN */
	IFX_MAPI_WLAN_DEV_TYPE_BRIDGE = 4	/*!< Bridge Type WLAN */
} IFX_MAPI_WLAN_DevType;

/** Enumaration of WLAN standards */
/*!
    \brief Enum containing WLAN standards.
*/
typedef enum ifx_mapi_wlan_standard {
	IFX_MAPI_WLAN_STD_802_11BG = 0,		/*!< 802.11BG *//* default is 802.11b/g Mode */
	IFX_MAPI_WLAN_STD_802_11A = 1,		/*!< 802.11A */
	IFX_MAPI_WLAN_STD_802_11B = 2,		/*!< 802.11B */
	IFX_MAPI_WLAN_STD_802_11G = 3,		/*!< 802.11G */
	IFX_MAPI_WLAN_STD_802_11N = 4,		/*!< 802.11N */
	IFX_MAPI_WLAN_STD_802_11BGN = 5,	/*!< 802.11BGN */
	IFX_MAPI_WLAN_STD_802_11GN = 6,		/*!< 802.11GN */
	IFX_MAPI_WLAN_STD_802_11AN = 7,		/*!< 802.11AN */
	IFX_MAPI_WLAN_STD_802_11AC = 8,		/*!< 802.11AN */
	IFX_MAPI_WLAN_STD_802_11ACN = 9,	/*!< 802.11AN */
	IFX_MAPI_WLAN_STD_802_11ACNA = 10,	/*!< 802.11AN */
	IFX_MAPI_WLAN_STD_802_11_ALL = 11	/*!< For VB300 STA SCAN */
} IFX_MAPI_WLAN_Standard;

/** Enumaration of possible network mode classes */
/*! \enum ltq_mapi_wlan_netModeClass
    \brief Enum containing WLAN network mode classes.
*/
typedef enum ltq_mapi_wlan_netModeClass {
	LTQ_MAPI_WLAN_NET_CLASS_B_N = 0,
	LTQ_MAPI_WLAN_NET_CLASS_G_BG_GN_BGN = 1,
	LTQ_MAPI_WLAN_NET_CLASS_A_N_AN = 2,
	LTQ_MAPI_WLAN_NET_CLASS_OFF = 3
} LTQ_MAPI_WLAN_NetModeClass;

/* Enumaration of Radio Freq Band � 2.4 GHz or 5 GHz */

/*!
    \brief Enum containing WLAN frequency band type.
*/
typedef enum ifx_mapi_wlan_freq_band {
	IFX_MAPI_WLAN_2_4_GHz_Freq = 0,	/*!< 2.4 GHz Frequenecy */
	IFX_MAPI_WLAN_5_GHz_Freq = 1,	/*!< 5.0 GHz Frequency */
	IFX_MAPI_WLAN_DUAL_BAND = 2,	/*!< DUAL Band WLAN */
	IFX_MAPI_WLAN_CONCUR_DUAL_BAND = 3	/*!< Concurrent Dual Band */
} IFX_MAPI_WLAN_FreqBand;

/** Enumaration of country list */
/*!
    \brief Enum containing WLAN Country List.
*/
typedef enum ifx_mapi_wlan_country_list {
	IFX_MAPI_WLAN_COUNTRY_INDIA = 0,	/*!< India *//* India */
	IFX_MAPI_WLAN_COUNTRY_US = 1,	/*!< USA *//* USA */
	IFX_MAPI_WLAN_COUNTRY_CHINA = 2,	/*!< China *//* China */
	IFX_MAPI_WLAN_COUNTRY_FRANCE = 3,	/*!< France *//* France */
	IFX_MAPI_WLAN_COUNTRY_GER = 4,	/*!< Germany *//* Germany */
	IFX_MAPI_WLAN_COUNTRY_IC = 5,	/*!< Canada *//* Canada */
	IFX_MAPI_WLAN_COUNTRY_ETSI = 6,	/*!< Europe *//* Europe */
	IFX_MAPI_WLAN_COUNTRY_JAPAN = 7,	/*!< Japan *//* Japan */
	IFX_MAPI_WLAN_COUNTRY_ESP = 8	/*!< Spain *//* Spain */
} IFX_MAPI_WLAN_Country;

/* Wi-Fi usage environment */
/*!
    \brief Enum containing Wi-Fi Usage Environment.
*/
typedef enum ifx_mapi_wlan_usage_env {
	IFX_MAPI_WLAN_ALL_ENV = 0,	/*!< All environment */
	IFX_MAPI_WLAN_INSIDE_ENV = 1,	/*!< Inside Environment */
	IFX_MAPI_WLAN_OUTSIDE_ENV = 2	/*!< Outside Environment */
} IFX_MAPI_WLAN_UsageEnv;

/** WLAN Preamble Type */
/*!
    \brief Enum containing WLAN Preamble Type.
*/
typedef enum ifx_mapi_wlan_preamble_type {
	IFX_MAPI_WLAN_PREAMBLE_NONE = 0,	/*!< No Preamble *//* default */
	IFX_MAPI_WLAN_PREAMBLE_SHORT = 1,	/*!< Short Preamble */
	IFX_MAPI_WLAN_PREAMBLE_LONG = 2,	/*!< Long Preamble */
	IFX_MAPI_WLAN_PREAMBLE_AUTO = 3	/*!< Auto Preamble */
} IFX_MAPI_WLAN_PreambleType;

/* WMM Access Category */
/*!
    \brief Enum containing WMM Access Categories.
*/
typedef enum ifx_mapi_wlan_wmm_ac {
	IFX_MAPI_WLAN_WMM_BE = 0,	/*!< Best Effort */
	IFX_MAPI_WLAN_WMM_BK = 1,	/*!< Background */
	IFX_MAPI_WLAN_WMM_VI = 2,	/*!< Video */
	IFX_MAPI_WLAN_WMM_VO = 3	/*!< Voice */
} IFX_MAPI_WLAN_WMM_AC;

/*!
    \brief Enum containing WLAN SSID mode.
*/
typedef enum ifx_mapi_wlan_ssid_mode {
	IFX_MAPI_WLAN_SSID_ADVERTISE = 0,	/*!< Advertise (default mode) */
	IFX_MAPI_WLAN_SSID_HIDDEN = 1	/*!< Hidden SSID Mode */
} IFX_MAPI_WLAN_SSID_Mode;

/**
   BEACON Type
*/
/*!
    \brief Enum containing WLAN Beacon type.
*/
typedef enum ifx_mapi_wlan_beacon_type {
	IFX_MAPI_WLAN_BEACON_BASIC 		= 0,	/*!< WLAN Beacon Basic Type */
	IFX_MAPI_WLAN_BEACON_WPA 		= 1,	/*!< WLAN Beacon WPA Type */
	IFX_MAPI_WLAN_BEACON_WPA2 		= 2,	/*!< WLAN Beacon WPA2 Type */
	IFX_MAPI_WLAN_BEACON_WPA_WPA2	= 3,	/*!< WLAN Beacon WPA/WPA2 Type */
	IFX_MAPI_WLAN_BEACON_WPA_WPA2_NON_COMPLIANT = 4,	/*!< WLAN Beacon WPA/WPA2 Type but not Wi-Fi compliant */
	IFX_MAPI_WLAN_BEACON_NONE					= 5		/*!< WLAN Beacon None (= Open, no security) */
} IFX_MAPI_WLAN_BeaconType;

/*
   AUTHENTICATION Type
*/
/*!
    \brief Enum containing WLAN Authentication Type.
*/
typedef enum ifx_mapi_wlan_auth_type {
	IFX_MAPI_WLAN_AUTH_OPEN = 0,	/*!< Open Authentication (default) */
	IFX_MAPI_WLAN_AUTH_SHARED = 1,	/*!< Shared Authentication */
	IFX_MAPI_WLAN_AUTH_RADIUS = 2,	/*!< RADIUS Authentication */
	IFX_MAPI_WLAN_AUTH_PERSONAL = 3,	/*!< Personal Authentication */
	IFX_MAPI_WLAN_AUTH_ENTERPRISE_PERSONAL = 4	/*!< VB300 STA mode:
							   Enterprise and Personal
							   Authentication */
} IFX_MAPI_WLAN_AuthType;

/*
   WLAN Key type - ASCII or HEX
*/
/*!
    \brief Enum containing WLAN Key Type.
*/
typedef enum ifx_mapi_wlan_key_type {
	IFX_MAPI_WLAN_ASCII_KEY = 0,	/*!< ASCII Key type (default) */
	IFX_MAPI_WLAN_HEX_KEY = 1	/*!< HEX Key type */
} IFX_MAPI_WLAN_KeyType;

/*
   ENCRYPTION Type
*/

/*!
    \brief Enum containing WLAN encryption type.
*/
typedef enum ifx_mapi_wlan_encr_type {
	IFX_MAPI_WLAN_ENCR_NONE = 0,	/*!< No encryption (default) */
	IFX_MAPI_WLAN_ENCR_WEP = 1,	/*!< WEP Encryption */
	IFX_MAPI_WLAN_ENCR_TKIP = 2,	/*!< TKIP Encryption */
	IFX_MAPI_WLAN_ENCR_CCMP = 3,	/*!< CCMP Encryption */
	IFX_MAPI_WLAN_ENCR_TKIP_CCMP = 4	/*!< TKIP/CCMP Encryption */
} IFX_MAPI_WLAN_EncrType;

/*
   Encryption Level
*/

/*!
    \brief Enum containing WEP Encryption level.
*/
typedef enum ifx_mapi_wlan_wep_encr_lvl {
	IFX_MAPI_WEP_ENCR_LVL_64BIT = 0,	/*!< 64-bit encryption (default) */
	IFX_MAPI_WEP_ENCR_LVL_128BIT = 1	/*!< 128-bit encryption */
} IFX_MAPI_WLAN_WEP_EncrLevel;

/*
   WEP Key Index
*/

/*!
    \brief Enum containing WEP key index.
*/
typedef enum ifx_mapi_wlan_wep_keyindx {
	IFX_MAPI_WEP_KEY_INDX_1 = 0,	/*!< WEP Key Index-1 */
	IFX_MAPI_WEP_KEY_INDX_2 = 1,	/*!< WEP Key Index-2 */
	IFX_MAPI_WEP_KEY_INDX_3 = 2,	/*!< WEP Key Index-3 */
	IFX_MAPI_WEP_KEY_INDX_4 = 3	/*!< WEP Key Index-4 */
} IFX_MAPI_WLAN_WEP_KeyIndex;

/*!
    \brief Enum containing 802.1X Authentication Type.
*/
typedef enum ifx_mapi_wlan_dot_1x_auth_type {
	IFX_MAPI_1X_AUTH_TYPE_LEAP = 0,	/*!< LEAP Auth (default) *//* default RADIUS protocol */
	IFX_MAPI_1X_AUTH_TYPE_PEAP = 1,	/*!< PEAP Auth */
	IFX_MAPI_1X_AUTH_TYPE_TLS = 2,	/*!< TLS Auth */
	IFX_MAPI_1X_AUTH_TYPE_TTLS = 3	/*!< TTLS Auth */
} IFX_MAPI_WLAN_Dot_1X_AuthType;

/*
   802.1X AUTH Protocol
*/

/*!
    \brief Enum containing 802.1X Authentication Protocol..
*/
typedef enum ifx_mapi_wlan_dot_1x_auth_proto {
	IFX_MAPI_1X_AUTH_PROTO_PAP = 0,	/*!< PAP */
	IFX_MAPI_1X_AUTH_PROTO_CHAP = 1	/*!< CHAP */
} IFX_MAPI_WLAN_Dot_1X_AuthProtocol;

/*
   WLAN MAC Address Control Filter Level
*/

/*!
    \brief Enum containing WLAN MAC Control Level.
*/
typedef enum ifx_mapi_wlan_mac_cntrl_level {	/* TODO :changed man->mac */
	IFX_MAPI_WLAN_GLOBLAL_MAC_CNTRL = 0,	/*!< Global MAC Control *//* default - global */
	IFX_MAPI_WLAN_SPECIFIC_MAC_CNTRL = 1	/*!< Specific MAC Control *//* per VAP list */
} IFX_MAPI_WLAN_MAC_CntrlLevel;

/*!
    \brief Enum containing MAC address Control Mode.
*/
typedef enum ifx_mapi_macaddr_control_mode {
	IFX_MAPI_MACADDR_CONTROL_ALLOW = 0,	/*!< Allow */
	IFX_MAPI_MACADDR_CONTROL_DENY,	/*!< Deny */
	IFX_MAPI_MACADDR_CONTROL_DISABLE,	/*!< Disable */
	IFX_MAPI_MACADDR_CONTROL_FLUSH	/*!< Flush */
} IFX_MAPI_MACADDR_ControlMode;

/*!
    \brief Enum containing MAC Address Control Interface Type.
*/
typedef enum ifx_mapi_macaddr_control_intf_type {
	IFX_MAPI_MACADDR_CONTROL_INTF_TYPE_ALL = 0,	/*!< All LAN Interfaces */
	IFX_MAPI_MACADDR_CONTROL_INTF_TYPE_USB,	/*!< USB Interface */
	IFX_MAPI_MACADDR_CONTROL_INTF_TYPE_ETH,	/*!< Ethernet Interface */
	IFX_MAPI_MACADDR_CONTROL_INTF_TYPE_WLAN	/*!< WLAN Interface */
} IFX_MAPI_MACADDR_ControlIntfType;

/*!
    \brief Enum containing WLAN vendor information
*/
typedef enum ltq_mapi_wlan_vendor {
	LTQ_MAPI_WLAN_VENDOR_NONE = 0,
	LTQ_MAPI_WLAN_VENDOR_WAVE300 = 1,
	LTQ_MAPI_WLAN_VENDOR_QCA = 2
} LTQ_MAPI_WLAN_Vendor;

/*!
    \brief Enum containing WLAN feature information
*/
typedef enum ltq_mapi_wlan_feature {
	LTQ_MAPI_WLAN_FEATURE_NONE = 0,
	LTQ_MAPI_WLAN_FEATURE_WPS = 1,
	LTQ_MAPI_WLAN_FEATURE_WPS_PROXY = 2,
	LTQ_MAPI_WLAN_FEATURE_WMM = 4,
	LTQ_MAPI_WLAN_FEATURE_WDS = 8,
	LTQ_MAPI_WLAN_FEATURE_AUTOCOC = 16,
	LTQ_MAPI_WLAN_FEATURE_NETMODE_PER_VAP = 32,
	LTQ_MAPI_WLAN_FEATURE_OPT_SCRIPTS = 64,
	LTQ_MAPI_WLAN_FEATURE_80211AC = 128
} LTQ_MAPI_WLAN_Feature;

/* WPS */
/* WPS locking state */

/*!
    \brief Enum containing WPS Locket State.
*/
typedef enum ifx_mapi_wps_locked_state {
	IFX_MAPI_WPS_STA_LOCKED = 0,	/*!< Locked */
	IFX_MAPI_WPS_STA_LOCKED_BY_LM = 1,	/*!< Locked by Local Management */
	IFX_MAPI_WPS_STA_LOCKED_BY_RM = 2,	/*!< Locked by Remote Management */
	IFX_MAPI_WPS_STA_PIN_RETRY_LIMIT_HIT = 3	/*!< PIN Retry Limit hit */
} IFX_MAPI_WPS_LockedState;

/* WPS configuration state */

/*!
    \brief Enum containing WPS Config state.
*/
typedef enum ifx_mapi_wps_config_state {
	IFX_MAPI_WPS_NOT_CONFIGURED = 1,	/*!< WPS is not configured */
	IFX_MAPI_WPS_CONFIGURED = 2	/*!< WPS is configured */
} IFX_MAPI_WPS_ConfigState;

/* WPS configuration error */

/*!
    \brief Enum containing WPS Config Error.
*/
typedef enum ifx_mapi_wps_config_error {
	IFX_MAPI_WPS_OOB_IF_READ_ERROR = 1,	/*!< Interface Read Error */
	IFX_MAPI_WPS_DECRYPT_CRC_FAILURE = 2	/*!< Decrypt CRC Failure */
} IFX_MAPI_WPS_ConfigError;

/*!
    \brief Enum containing WPS config Methods.
*/
typedef enum ifx_mapi_wps_config_methods {
	IFX_MAPI_WPS_USB_FLASH_DRIVE = 1,	/*!< USB Flash drive */
	IFX_MAPI_WPS_ETHERNET = 2,	/*!< Ethernet */
	IFX_MAPI_WPS_LABEL = 3,	/*!< Label based */
	IFX_MAPI_WPS_DISPLAY = 4,	/*!< Display */
	IFX_MAPI_WPS_EXTERNAL_NFC_TOKEN = 5,	/*!< External NFC Token */
	IFX_MAPI_WPS_INTEGRATED_NFC_TOKEN = 6,	/*!< Integrated NFC Token */
	IFX_MAPI_WPS_NFC_INTERFACE = 7,	/*!< NFC Interface */
	IFX_MAPI_WPS_PUSH_BUTTON = 8,	/*!< Push button */
	IFX_MAPI_WPS_KEY_PAD = 9	/*!< Key Pad */
} IFX_MAPI_WPS_CfgMethods;

/*!
    \brief Enum containing WLAN WPS connection status.
*/
typedef enum ltq_mapi_wps_connection_status {
	/*!< WPS Connection Status: Idle */
	LTQ_MAPI_WPS_CONNECTION_IDLE = 0,
	/*!< VB WPS Connection Status: In progress */
	LTQ_MAPI_WPS_CONNECTION_IN_PROGRESS = 1,
	/*!< VB WPS Connection Status: Timeout */
	LTQ_MAPI_WPS_CONNECTION_TIMEOUT = 2,
	/*!< VB WPS Connection Status: Overlap error */
	LTQ_MAPI_WPS_CONNECTION_OVERLAP_ERR = 3,
	/*!< VB WPS Connection Status: WPS completed successfully */
	LTQ_MAPI_WPS_CONNECTION_SUCCESS = 4,
	/*!< VB WPS Connection Status: Invalid state */
	LTQ_MAPI_WPS_CONNECTION_STATE_INVALID = -1
} LTQ_MAPI_WPS_ConnectionStatus;

/* WPS - end */

/* WDS */

/*! 
    \brief Enum containing WDS security modes.
*/
typedef enum ltq_mapi_wds_security_config {
	LTQ_MAPI_WDS_OPEN = 0,	/*!< No security for WDS */
	LTQ_MAPI_WDS_WEP = 1,	/*!< WEP security for WDS */
} LTQ_MAPI_WDS_SecCfg;

/* WDS - end */

#if 0
/** A type for handling boolean issues. */
typedef enum {
   /** False. */
	IFX_FALSE = 0,
   /** True. */
	IFX_TRUE = 1
} IFX_boolean_t;
#endif

/* When CONFIG_FEATURE_VDSL_VECTORING is enabled, the ifx_types.h gets included 
from staging_dir/include/ifxos path. And this file already has a definitions
for IFX_uint32_t. Hence, protecting the same to avoid redefinition issue */
/** This is the unsigned 32-bit datatype. */
#if !defined(USE_SWITCH_API_ENUM_H) && !defined(CONFIG_FEATURE_VDSL_VECTORING)
typedef unsigned int IFX_uint32_t;
#endif

/** This type has two three, 20MHZ and 40MHZ. */
/*!
    \brief Enum containing WLAN channel bandwidth.
*/
typedef enum ifx_mapi_wlan_channel_bandwdt {
	IFX_MAPI_WLAN_BW_20MHZ = 0,	/*!< WLAN bandwidth - 20 MHz */
	IFX_MAPI_WLAN_BW_AUTO = 1,	/*!< WLAN bandwidth - Auto (20/40) MHz */
	IFX_MAPI_WLAN_BW_40MHZ = 2,	/*!< WLAN bandwidth - 40 MHz */
	IFX_MAPI_WLAN_BW_80MHZ = 3,	/*!< WLAN bandwidth - 80 MHz */
	IFX_MAPI_WLAN_BW_160MHZ = 4	/*!< WLAN bandwidth - 160 MHz */
} IFX_MAPI_WLAN_ChannelBW;

/**  */
/*!
    \brief Enum containing WLAN extension channel position .
*/
typedef enum ifx_mapi_wlan_ext_channel_pos {
	IFX_MAPI_WLAN_EXT_ABV_CC = 0,	/*!< Extension - Above control channel
					 */
	IFX_MAPI_WLAN_EXT_BEL_CC = 1	/*!< Extension - Below control channel
					 */
} IFX_MAPI_WLAN_Ext_ChannelPos;

/** This type has three states, low (400 ns), high (800 ns) and auto. */
/*!
    \brief Enum containing WLAN guard intervals .
*/
typedef enum ifx_mapi_wlan_guard_intvl {
	IFX_MAPI_WLAN_GI_LOW = 0,	/*!< WLAN guard interval of 400ns */
	IFX_MAPI_WLAN_GI_HIGH = 1,	/*!< WLAN guard interval of 800ns */
	IFX_MAPI_WLAN_GI_AUTO = 2	/*!< WLAN guard interval - Auto */
} IFX_MAPI_WLAN_GuardIntvl;

/** This type has three states, RX, TX and Both. */
/*!
    \brief Enum containing WLAN direction .
*/
typedef enum ifx_mapi_wlan_direction {
	IFX_MAPI_WLAN_RX = 0,	/*!< WLAN direction - RX */
	IFX_MAPI_WLAN_TX = 1,	/*!< WLAN direction - TX */
	IFX_MAPI_WLAN_BOTH = 2	/*!< WLAN direction - Both RX,TX */
} IFX_MAPI_WLAN_Direction;

/** This type has four values, 8191, 16383, 32767, 65535. */
/*!
    \brief Enum containing AMPDU packet lengths.
*/
typedef enum ifx_mapi_wlan_ampdu_length {
	IFX_MAPI_WLAN_AMPDU_LEN1 = 8191,	/*!< AMPDU packet length */
	IFX_MAPI_WLAN_AMPDU_LEN2 = 16383,	/*!< AMPDU packet length */
	IFX_MAPI_WLAN_AMPDU_LEN3 = 32767,	/*!< AMPDU packet length */
	IFX_MAPI_WLAN_AMPDU_LEN4 = 65535	/*!< AMPDU packet length */
} IFX_MAPI_WLAN_AMPDU_Length;

/** This type has two values, 3839, 7935. */

/*!
    \brief Enum containing AMSDU packet lengths.
*/
typedef enum ifx_mapi_wlan_amsdu_length {
	IFX_MAPI_WLAN_AMSDU_LEN1 = 3839,	/*!< AMSDU packet length */
	IFX_MAPI_WLAN_AMSDU_LEN2 = 7935	/*!< AMSDU packet length */
} IFX_MAPI_WLAN_AMSDU_Length;

/** This type has two states, Disabled and Enabled */

/*!
    \brief Enum containing WLAN Enable/Disable action flags.
*/
typedef enum ifx_mapi_wlan_action {
	IFX_MAPI_WLAN_DISABLED = 0,	/*!< WLAN Disabled */
	IFX_MAPI_WLAN_ENABLED = 1	/*!< WLAN Enabled */
} IFX_MAPI_WLAN_Action;

/** This type has three states, Station mode, AP mode and AUTO (for future use) */

/*!
    \brief Enum containing WLAN beamforming mode selection.
*/
typedef enum ltq_mapi_wlan_beamform {
	LTQ_MAPI_WLAN_BEAMFORM_OFF = 0,	/*!< WLAN Beamforming off */
	LTQ_MAPI_WLAN_BEAMFORM_RES_1 = 1,	/*!< reserved */
	LTQ_MAPI_WLAN_BEAMFORM_RES_2 = 2,	/*!< reserved */
	LTQ_MAPI_WLAN_BEAMFORM_IMPLICIT = 3	/*!< WLAN Implicit Beamforming */
} LTQ_MAPI_WLAN_Beamform;

/*!
    \brief Enum containing WLAN beamforming mode selection.
*/
typedef enum ltq_mapi_wlan_ack_boost {
	LTQ_MAPI_WLAN_ACKBOOST_OFF = 0,	/*!< WLAN No ACK boost */
	LTQ_MAPI_WLAN_ACKBOOST_DATA_REG = 1,	/*!< WLAN Ack boost for data packets (under regulatory restrictions) */
	LTQ_MAPI_WLAN_ACKBOOST_ALL_REG = 2,	/*!< WLAN Ack boost for all packets (under regulatory restrictions) */
	LTQ_MAPI_WLAN_ACKBOOST_DATA_NONREG = 3,	/*!< WLAN Ack boost for data packets (exceeding regulatory restrictions) */
	LTQ_MAPI_WLAN_ACKBOOST_ALL_NONREG = 4	/*!< WLAN Ack boost for all packets (exceeding regulatory restrictions) */
} LTQ_MAPI_WLAN_AckBoost;

#if defined (CONFIG_FEATURE_LTQ_WIRELESS_VB) || defined (CONFIG_FEATURE_LTQ_WIRELESS_STA_SUPPORT)
/*!
    \brief Enum containing WLAN VB mode selection.
*/
typedef enum ltq_mapi_wlan_vb_mode {
	LTQ_MAPI_WLAN_VB_STA = 0,	/*!< WLAN VB station mode */
	LTQ_MAPI_WLAN_VB_AP = 1,	/*!< WLAN VB AP mode */
	LTQ_MAPI_WLAN_VB_AUTO = 2	/*!< WLAN VB auto select mode (future use) */
} LTQ_MAPI_WLAN_VB_mode;

/*!
    \brief Enum containing WLAN VB network mode selection for AP.
*/
typedef enum ltq_mapi_wlan_vb_lan_ap_mode {
	LTQ_MAPI_WLAN_VB_LAN_AP_MODE_BRIDGE = 0,	/*!< WLAN VB AP network mode
							   BRIDEGE */
	LTQ_MAPI_WLAN_VB_LAN_AP_MODE_4_ADDR = 1	/*!< WLAN VB AP network mode
						   Four-Address */
} LTQ_MAPI_WLAN_VB_LAN_AP_mode;

/*!
    \brief Enum containing WLAN VB network mode selection for STA.
*/
typedef enum ltq_mapi_wlan_vb_lan_sta_mode {
	LTQ_MAPI_WLAN_VB_LAN_STA_MODE_L2NAT = 0,	/*!< WLAN VB STA network mode
							   L2-NAT */
	LTQ_MAPI_WLAN_VB_LAN_STA_MODE_CLONING = 1,	/*!< WLAN VB STA network mode
							   MAC cloning */
	LTQ_MAPI_WLAN_VB_LAN_STA_MODE_4_ADDR = 2	/*!< WLAN VB STA network mode
							   Four-Address */
} LTQ_MAPI_WLAN_VB_LAN_STA_mode;

/*!
    \brief Enum containing WLAN VB network mode selection for STA.
*/
typedef enum ltq_mapi_vb_wlan_cts_prot_mode {
	/*!< VB WLAN CTS protection mode: None */
	LTQ_MAPI_VB_WLAN_CTS_PROT_NONE = 0,
	/*!< VB WLAN CTS protection mode: RTS/CTS */
	LTQ_MAPI_VB_WLAN_CTS_PROT_RTS_CTS = 2,
	/*!< VB WLAN CTS protection mode: CTS2Self */
	LTQ_MAPI_VB_WLAN_CTS_PROT_CTS_SELF = 3
} LTQ_MAPI_VB_WLAN_CTS_ProtMode;

/*!
    \brief Enum containing VB ETH PHY duplex mode selection.
*/
typedef enum ltq_mapi_vb_eth_phy_duplex_mode {
	/*!< VB ETH PHY duplex mode: AUTO */
	LTQ_MAPI_VB_ETH_PHY_DUPLEX_MODE_AUTO = 0,
	/*!< VB ETH PHY duplex mode: FULL */
	LTQ_MAPI_VB_ETH_PHY_DUPLEX_MODE_FULL = 1,
	/*!< VB ETH PHY duplex mode: FULL */
	LTQ_MAPI_VB_ETH_PHY_DUPLEX_MODE_HALF = 2
} LTQ_MAPI_VB_ETH_PHY_DUPLEX_MODE;

#endif				/* #ifdef CONFIG_FEATURE_LTQ_WIRELESS_VB */

/* WLAN - end ] */
#endif				/* #if defined (CONFIG_FEATURE_IFX_WIRELESS) */
/*IPQoS */
// IFX_MAPI_QoS_Interface_Type
/*!
    \brief Enum containing QoS Interface type.
*/
typedef enum ifx_mapi_qos_interface_type {
	IFX_MAPI_QoS_LAN_ALL = 0,	/*!< All interface in LAN side (TR-098 data
					   model) */
	IFX_MAPI_QoS_LAN_ETH = 1,	/*!< Ethernet LAN interface */
	IFX_MAPI_QoS_LAN_USB = 2,	/*!< USB LAN Interface */
	IFX_MAPI_QoS_LAN_WIFI = 3,	/*!< WIFI LAN Interface */
	IFX_MAPI_QoS_WAN_ALL = 4,	/*!< All Interface in WAN (TR-098 data model) */
	IFX_MAPI_QoS_WAN_IP = 5,	/*!< WAN IP */
	IFX_MAPI_QoS_WAN_PPP = 6,	/*!< WAN PPP */
	IFX_MAPI_QoS_LOCAL = 7,	/*!< Local Interface */
	IFX_MAPI_QoS_SPECIFIC = 8,	/*!< Specific Interface */
	IFX_MAPI_QoS_WAN_ATM = 9,	/*!< ATM wan interface */
	IFX_MAPI_QoS_WAN_PTM = 10,	/*!< PTM wan interface */
	IFX_MAPI_QoS_WAN_ETH_0 = 11,	/*!< Eth wan mii0 interface */
	IFX_MAPI_QoS_WAN_ETH_1 = 12,	/*!< Eth wan mii1 interface */
	IFX_MAPI_QoS_ALL = 13,	/*!< All Interface */
	IFX_MAPI_QoS_LAN_SPECIFIC = 14,	/*!< Specific LAN interface */
	IFX_MAPI_QoS_WAN = 15,	/*!<  Interface in WAN (TR-098 data model) */
	IFX_MAPI_QoS_LAN_ATM = 16,	/*!< LAN Enum with ATM wan interface */
	IFX_MAPI_QoS_LAN_PTM = 17,	/*!< LAN Enum with PTM wan interface */
	IFX_MAPI_QoS_LAN_ETH_0 = 18,	/*!< Lan Enum with Eth wan mii0 interface */
	IFX_MAPI_QoS_LAN_ETH_1 = 19	/*!< LAN Enum with Eth wan mii1 interface */
} IFX_MAPI_QoS_Interface_Type;

// IFX_MAPI_QoS_Class_Type
/*!
    \brief Enum containing QoS classifier Type.
*/
typedef enum ifx_mapi_qos_class_type {
	IFX_MAPI_QoS_Multi_Field = 0,	/*!< Multi Field Classification */
	IFX_MAPI_QoS_DSCP = 1,	/*!< DSCP based Classification */
	IFX_MAPI_QoS_P_Bits = 2	/*!< P-bits based Classification */
} IFX_MAPI_QoS_Class_Type;

// IFX_MAPI_QoS_ATM_Queue_Mode
/*!
    \brief Enum containing QoS ATM Queuing Mode.
*/
typedef enum ifx_mapi_qos_atm_queue_mode {
	IFX_MAPI_QoS_ATM_PVC_BASED = 0,	/*!< PVC Based Queuing */
	IFX_MAPI_QoS_ATM_PORT_BASED = 1,	/*!< Port based Queuing */
} IFX_MAPI_QoS_ATM_Queue_Mode;

// IFX_MAPI_QoS_Meter
/*!
    \brief Enum containing Meter type for QoS..
*/
typedef enum ifx_mapi_qos_meter {
	IFX_MAPI_QoS_Meter_STB = 0,	/*!< STB Meter */
	IFX_MAPI_QoS_Meter_SRTCM = 1,	/*!< SRTCM Meter */
	IFX_MAPI_QoS_Meter_TRTCM = 2	/*!< TRTCM Meter */
} IFX_MAPI_QoS_Meter;

// IFX_MAPI_QoS_Policer_Action
/*!
    \brief Enum containing QoS Policer action.
*/
typedef enum ifx_mapi_qos_policer_action {
	IFX_MAPI_QoS_Policer_NULL = 0,	/*!< No Policer */
	IFX_MAPI_QoS_Policer_Drop = 1,	/*!< Drop Policer Action */
	IFX_MAPI_QoS_Policer_DSCP_Mark = 2,	/*!< DSCP Mark Action */
	IFX_MAPI_QoS_Policer_P_Bits_Mark = 3,	/*!< 802.1P bits Marking
						   Action */
	IFX_MAPI_QoS_Policer_DSCP_P_Bits_Mark = 4	/*!< DSCP & P-Bits Marking
							   Action */
} IFX_MAPI_QoS_Policer_Action;

// IFX_MAPI_QoS_Drop
/*!
    \brief Enum containing QoS drop algorithm type.
*/
typedef enum ifx_mapi_qos_drop {
	IFX_MAPI_QoS_Drop_DT = 0,	/*!< Drop Tail Algorithm */
	IFX_MAPI_QoS_Drop_RED = 1,	/*!< RED Algorithm */
	IFX_MAPI_QoS_Drop_NONE = 2,	/*!< No Drop Algorithm */
	IFX_MAPI_QoS_Drop_WRED = 3,	/*!< WRED Algorithm */
	IFX_MAPI_QoS_Drop_BLUE = 4	/*!< BLUE Algorithm */
} IFX_MAPI_QoS_Drop;

// IFX_MAPI_QoS_Scheduler
/*!
    \brief Enum containing QoS scheduler.
*/
typedef enum ifx_mapi_qos_sched {
	IFX_MAPI_QoS_Sched_SP = 0,	/*!< Strict-Priority Scheduler */
	IFX_MAPI_QoS_Sched_WRR = 1,	/*!< WRR Scheduler */
	IFX_MAPI_QoS_Sched_WFQ = 2,	/*!< WFQ Scheduler */
	IFX_MAPI_QoS_Sched_HTB = 3	/*!< HTB Scheduler */
} IFX_MAPI_QoS_Sched;

//IFX_MAPI_QOS_STATUS
/*!
    \brief Enum containing IP QoS Status.
*/
typedef enum ifx_mapi_qos_status {
	IPQOS_STATUS_DISABLED = IFX_DISABLED,	/*!< Qos-Disabled */
	IPQOS_STATUS_ENABLED = IFX_ENABLED,	/*!< QoS-Enabled */
	IPQOS_STATUS_ERROR = 3	/*!< Qos-Status Error */
} IPQOS_STATUS;
/*IPQoS End */

/*Port statistics using switch utility*/

/*!
    \brief Enum containing Port statistics using switch utility.
*/
typedef enum ifx_mapi_phyport_info_param {
	IFX_MAPI_LANEIC_ENABLE = 1,	/*!< Enable flag */
	IFX_MAPI_LANEIC_SPEED = 2,	/*!< Speed flag */
	IFX_MAPI_LANEIC_DUPLEX = 3,	/*!< Duplex flag */
} IFX_MAPI_PhyPort_Info_Param;
/*Port statistics using switch utility*/

typedef enum wan_type {
	WAN_TYPE_IP = 0,
	WAN_TYPE_PPP = 1
} WAN_TYPE;

#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
typedef enum {
	auto_dis = 0,
	auto_en = 1
} auto_detect_status;
#endif

typedef enum ntp_status {
	DISABLED = 0,
	UNSYNCHRONIZED = 1,
	SYNCHRONIZED = 2,
	ERROR_FAILEDTOSYNCHRONIZE = 3,
	ERROR =4
} NTP_STATUS;

#endif				// _IFX_API_ENUMS_H

