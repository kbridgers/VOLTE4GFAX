#ifndef _IFX_IGMP_PROXY_H_
#define _IFX_IGMP_PROXY_H_

//#define               IPROXYD_MODULE                  "/lib/modules/2.4.20_mvl31-malta-mips_fp_be/kernel/net/ipv4/iproxyd/iproxyd.o"

/*!\def IPROXYD_MODULE
   \brief Iproxy module 
*/
#define		IPROXYD_MODULE			"iproxyd"

/*!\def IPROXYD_MODULE_NAME
   \brief Iproxy module name
*/
#define		IPROXYD_MODULE_NAME		"iproxyd"

/*!\fn int IFXEnableIgmpProxy ( int mode, char	*upstreamIf )
   \brief integer type function Enables IGMP proxy
   \param[in] mode
   \param[in] upstreamIf
   \return 0 or 1
*/
int IFXEnableIgmpProxy(int mode, char *upstreamIf);

/*!\fn int IFXDisableIgmpProxyOrSnooping ( void )	
   \brief integer type function disables IGMP Proxy or snooping
   \return 0 or 1
*/

int IFXDisableIgmpProxyOrSnooping(void
    );

/*!\fn int IFXEnableIgmpSnooping ( int mode)
   \brief integer type function enable IGMP snooping
   \param[in] mode
   \return 0 or 1
*/
int IFXEnableIgmpSnooping(int mode);

#endif /*_IFX_IGMP_PROXY_H_*/
