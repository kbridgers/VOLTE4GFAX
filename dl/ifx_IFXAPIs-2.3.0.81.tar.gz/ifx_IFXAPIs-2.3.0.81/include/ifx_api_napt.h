/* ============================================================================
 * Copyright (C) 2004 - Infineon Technologies.
 *
 * All rights reserved.
 * ============================================================================
 *
 * ============================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ============================================================================
 *
 * Revision History:
 *      - 2004/07/20, TC Chen
 *         init version
 *
 * ============================================================================
 */

/*! \file ifx_api_napt.h 
    \brief This function contains the NAPT API structures and function prototypes
*/

#ifndef _IFX_API_NAPT_H_
#define _IFX_API_NAPT_H_

/*! \fn bool IFX_NAT_INIT()
    \brief This function initializes NAT
    \return Boolean return value
 */

bool IFX_NAT_INIT();

/*!
    \brief Structure describing nat rules.
*/

typedef struct __ifx_nat_rule {
	__u32 srcip;		/*!< Source IP Address */
	__u32 dstip;		/*!< Destination IP Address */
	__u32 targetip;		/*!< Target IP Address */
	unsigned short srcport_start;	/*!< Start Source Port */
	unsigned short srcport_end;	/*!< End Source Port */
	unsigned short dstport_start;	/*!< Start Destination Port */
	unsigned short dstport_end;	/*!< End Destination Port */
	unsigned short targetport_start;	/*!< Start Target Port */
	unsigned short targetport_end;	/*!< End Target Port */
	unsigned short protocol;	/*!< Protocol */
} IFX_NAT_RULE, *P_IFX_NAT_RULE;

/*! \fn bool IFX_SET_NAPT_DNAT_VIRTUALSERVER_ENABLE(int operation, bool *pbEnable)
    \brief This function enables NAPT/DNAT virtual server 
    \param[in] operation Type of operation
    \param[in] *pbEnable Enable/disable the operation
     \return Boolean return value
 */

extern bool IFX_SET_NAPT_DNAT_VIRTUALSERVER_ENABLE(int operation,
						   bool * pbEnable);

/*! \fn  bool IFX_SET_NAPT_DNAT_PORTMAPPING_ENABLE(int operation, bool *pbEnable)
    \brief This function enables NAPT/DNAT port mapping
    \param[in] operation Type of operation
    \param[in] *pbEnable Enable/disable the operation
     \return Boolean return value
 */
extern bool IFX_SET_NAPT_DNAT_PORTMAPPING_ENABLE(int operation,
						 bool * pbEnable);

/*! \fn bool IFX_SET_NAPT_DMZ_ENABLE(int operation, bool *pbEnable)
    \brief This function enables NAPT DMZ
    \param[in] operation Type of operation
    \param[in] *pbEnable Enable/disable the operation
     \return Boolean return value
 */
extern bool IFX_SET_NAPT_DMZ_ENABLE(int operation, bool * pbEnable);

/*! \fn bool IFX_SET_NAPT_REDIRECT_SERVICES(int operation,__u16 service_port,__u16 protocol,__u32 IPADDR, __u16 target_port)
    \brief This function redirects NAPT services to new port
    \param[in] operation Type of operation
    \param[in] service_port Port number on which service is being listened
    \param[in] protocol Protocol served on the port
    \param[in] IPADDR IP address
    \param[in] target_port Target port on which service will be redirected
     \return Boolean return value
 */
extern bool IFX_SET_NAPT_REDIRECT_SERVICES(int operation, __u16 service_port,
					   __u16 protocol, __u32 IPADDR,
					   __u16 target_port);

/*! \fn bool IFX_NAPT_SET_LAN(int operation, char *IFNAME, unsigned long int IPADDRESS,unsigned long int NETMASK);
    \brief This function adds LAN interface to NAPT
    \param[in] operation Type of operation
    \param[in] *IFNAME LAN interface name on which NAT would be configured
    \param[in] IPADDRESS IP address of LAN interface
    \param[in] NETMASK Netmask of LAN interface
    \return Boolean return value
 */
extern bool IFX_NAPT_SET_LAN(int operation, char *IFNAME,
			     unsigned long int IPADDRESS,
			     unsigned long int NETMASK);

/*! \fn bool IFX_NAPT_SET_WAN_IF(int operation, char *IFNAME)
    \brief This function adds WAN interface to NAPT
    \param[in] operation Type of operation
    \param[in] *IFNAME WAN interface name on which NAT would be configured
    \return Boolean return value
 */
extern bool IFX_NAPT_SET_WAN_IF(int operation, char *IFNAME);

/*! \fn bool IFX_NAPT_SET_WAN_IP(int operation, unsigned long int IPADDRESS)
    \brief This function adds WAN IP to NAPT
    \param[in] operation Type of operation
    \param[in] IPADDRESS IP address of WAN interface on which NAT would be configured
     \return Boolean return value
 */
extern bool IFX_NAPT_SET_WAN_IP(int operation, unsigned long int IPADDRESS);

/*! \fn unsigned long int bits2netmask(int bits)
    \brief This function converts value to network byte order
    \param[in] bits
     \return Netmask value
 */
extern unsigned long int bits2netmask(int bits);

/*! \fn int netmask2bits(u_int32_t netmask)
    \brief This function converts value to host byte order and then to a value between 0-32
    \param[in] netmask
    \return Value between 0-32
 */
extern int netmask2bits(u_int32_t netmask);

#endif
