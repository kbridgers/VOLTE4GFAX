/* 
** =============================================================================
**   FILE NAME        : ifx_common.h
**   PROJECT          : AMAZON MAPI
**   DATE             : 19-Jun-2006
**   AUTHOR           : Amazon API Team
**   DESCRIPTION      : This file contains the common definitions used across
			the IFX User sources including the MAPI framework

**   REFERENCES       : 
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/
/*
000002:tc.chen 2005/06/10 add get_adsl_rate and ifx_makeCMV api
*/

/*! \file ifx_common.h 
    \brief This file contains the common definitions used across the IFX User sources including the MAPI framework.
*/

#ifndef __IFX_COMMON_H
#define __IFX_COMMON_H
/* 000002:Nirav: from 2.1.22 package*/

#ifndef DONT_USE_IFX_BASIC_TYPES_H
#include <ifx_basic_types.h>
#endif

#include <syslog.h>
#include <stdarg.h>

#include <ifx_config.h>
#ifdef HOSTENV
#define IH_TYPE_KERNEL		2	/* OS Kernel Image              */
#define IH_TYPE_FIRMWARE	5	/* Firmware Image               */
#define IH_MAGIC	0x27051956	/* Image Magic Number           */
#define IH_NMLEN		32	/* Image Name Length            */
/*
 * Legacy format image header,
 * all data in network byte order (aka natural aka bigendian).
 */
typedef struct image_header {
	uint32 ih_magic;	/* Image Header Magic Number    */
	uint32 ih_hcrc;		/* Image Header CRC Checksum    */
	uint32 ih_time;		/* Image Creation Timestamp     */
	uint32 ih_size;		/* Image Data Size              */
	uint32 ih_load;		/* Data  Load  Address          */
	uint32 ih_ep;		/* Entry Point Address          */
	uint32 ih_dcrc;		/* Image Data CRC Checksum      */
	uint8 ih_os;		/* Operating System             */
	uint8 ih_arch;		/* CPU architecture             */
	uint8 ih_type;		/* Image Type                   */
	uint8 ih_comp;		/* Compression Type             */
	uint8 ih_name[IH_NMLEN];	/* Image Name           */
} image_header_t;
#endif
/** \ingroup INTERFACES
*/
/* @{ */
/*!\def IFX_IN
   \brief This macro denotes input parameter to function
*/
#define IFX_IN

/*!\def IFX_OUT
   \brief This macro denotes output parameter of a function
*/
#define IFX_OUT

/*!\def IFX_IN_OUT
   \brief This macro denotes that the parameter is both input/output
*/
#define IFX_IN_OUT

/*!\def MAX_SEC_SIZE
   \brief This macro denotes maximum section size
*/
#define MAX_SEC_SIZE			256*80

/*!\def BUF_SIZE_50K
   \brief This macro denotes buffer size
*/
#define BUF_SIZE_50K                    32768	//604181: Sumedh - change size of buffer to account for increased size of rc.conf

/*!\def MAX_FILESIZE
   \brief This macro denotes maximum file size
*/
#define MAX_FILESIZE					256*1024

/*!\def BUF_SIZE_1K
   \brief Buffer size of 1k
*/
#define BUF_SIZE_1K                     1024

#ifndef MAX_DATA_LEN
//#define MAX_DATA_LEN                    128 /* 64 */
/*!\def MAX_DATA_LEN
   \brief This macro denotes maximum data length
*/
#define MAX_DATA_LEN                    2000
#endif

#ifndef MAX_FILELINE_LEN
/*!\def MAX_FILELINE_LEN 
   \brief This macro denotes maximum file line length
*/
#define MAX_FILELINE_LEN                332
#endif

/*!\def MAX_FILENAME_LEN
   \brief This macro denotes maximum file data length
*/
#define MAX_FILENAME_LEN                256

/*!\def MAX_TAG_LEN 
   \brief This macro denotes maximum tag length
*/
#define MAX_TAG_LEN                     64


/*!\def MAX_LENGTH
   \brief This macro denotes maximum buffer length
*/
#define MAX_LENGTH                      1024

/*!\def MAX_NAME_LEN  
   \brief This macro denotes maximum name length
*/
#define MAX_NAME_LEN                    96

/*!\def NODE_AGE_TIME
   \brief This macro denotes node age time
*/
#define NODE_AGE_TIME			4*60*60	/* 000001:Nirav4 hrs of Age Time in Secs */

/*!\def FALSE	
   \brief False
*/
#define	FALSE				0

/*!\def TRUE
   \brief True
*/
#define TRUE				1

/*!\def FILE_UPDATE_TMP
   \brief This macro denotes temperory update file
*/
#define FILE_UPDATE_TMP                    "/tmp/update.tmp"

#ifdef HOSTENV

#ifndef FILE_RC_CONF
/*!\def FILE_RC_CONF 
   \brief This macro denotes temperory core configuration file
*/
#define FILE_RC_CONF                    "/tmp/rc.conf"
#endif				// FILE_RC_CONF

#else

#ifndef FILE_RC_CONF
/*!\def FILE_RC_CONF 
   \brief This macro denotes core configuration file
*/
#define FILE_RC_CONF                    "/flash/rc.conf"

#endif				// FILE_RC_CONF

#endif				// HOSTENV

/*!\def FILE_RC_CONF_BACKUP
   \brief This macro denotes backup core configuration file
*/
#define FILE_RC_CONF_BACKUP             "/tmp/rc.conf.backup"

#ifndef FILE_SYSTEM_STATUS
/*!\def FILE_SYSTEM_STATUS
   \brief This macro denotes system status file
*/
#define FILE_SYSTEM_STATUS		"/tmp/system_status"
#endif				// FILE_SYSTEM_STATUS

/*!\def IFX_DIAG_FILE  
   \brief This macro denotes diagnostics file
*/
#define IFX_DIAG_FILE                   "/tmp/dyn_info"

/*! \def FILE_SYSCONF
    \brief Macro that defines the temperory system configuration file
*/
#define FILE_SYSCONF "/tmp/sysconf"	/*!<  temperory system configuration file */

#ifndef PROCF_AMZ_VC
/*!\def PROCF_AMZ_VC
   \brief This macro denotes amazon atm vcc file
*/
#define PROCF_AMZ_VC			"/proc/amazon_atm_vcc"
#endif				// PROCF_AMZ_VC

#ifndef PROCF_DNB_VC
/*!\def PROCF_DNB_VC
   \brief This macro denotes VC file
*/
#define PROCF_DNB_VC			"/proc/net/atm/vc"
#endif				// PROCF_AMZ_VC

#ifndef IFX_SYS_CONF
/*!\def IFX_SYS_CONF
   \brief This macro denotes system configuration file
*/
#define IFX_SYS_CONF			"/etc/sys.conf"
#endif				//IFX_SYS_CONF

/* 705031:Santosh: new dsl diagnostics api -start*/
#ifdef  CONFIG_PACKAGE_IFX_DSL_CPE_API

/*!\def FILE_DYN_INFO	
   \brief This macro denotes Diagnostics file
*/
#define FILE_DYN_INFO					"/tmp/dyn_info"

/*!\def DSL_DEVICE
   \brief This macro denotes DSL CPE API file
*/
#ifdef PLATFORM_VR9
#define DSL_DEVICE						"/dev/dsl_cpe_api/0"
#else
#define DSL_DEVICE						"/dev/dsl_cpe_api"
#endif

/*!\def IFX_DSL_DIAG_INFO_TIMEOUT
   \brief This macro denotes DSL Diagnostics information time out value 
*/
#define IFX_DSL_DIAG_INFO_TIMEOUT		300	/* 5 mins */

// DSL Diag state types

/*!\def IFX_DSL_STATE_DIAG
   \brief This macro denotes DSL State Diagnostics
*/
#define IFX_DSL_STATE_DIAG				"DIAG"

/*!\def IFX_DSL_STATE_COMPLETE
   \brief This macro denotes DSL Complete State
*/
#define IFX_DSL_STATE_COMPLETE			"COMPLETE"

/*!\def IFX_DSL_STATE_IDLE
   \brief This macro denotes DSL Idle State
*/
#define IFX_DSL_STATE_IDLE				"IDLE"

#endif				// CONFIG_PACKAGE_IFX_DSL_CPE_API

//SSL macros

/*!\def CERT_MAX_SIZE
   \brief This macro denotes Certificate maximum size
*/
#define CERT_MAX_SIZE 5*1024

/*!\def SSL_CERT_FILE_NAME 
   \brief This macro denotes Certificate file name
*/
#define SSL_CERT_FILE_NAME "/flash/Cert.pem"

// Error codes returned in 

/*!\def IFX_ERR_FILE_OPEN 
   \brief This macro denotes file open error
*/
#define IFX_ERR_FILE_OPEN             	-2

/*!\def IFX_ERR_IOCTL 
   \brief This macro denotes ioctl error
*/
#define IFX_ERR_IOCTL            		-3

//Error Codes returned in GetCfgData in outFlag.

/*!\def IFX_E_INT_ERROR 
   \brief This macro denotes internal error
*/
#define IFX_E_INT_ERROR                 -2

/*!\def IFX_E_SEC_NOT_FOUND  
   \brief This macro denotes section not found 
*/
#define IFX_E_SEC_NOT_FOUND             -3

/*!\def IFX_IN
   \brief This macro denotes parameter not found 
*/
#define IFX_E_PARAM_NOT_FOUND           -4

/*!\def IFX_E_UNMATCHED_INPUT 
   \brief This macro denotes unmatched input 
*/
#define IFX_E_UNMATCHED_INPUT           -5

/*!\def IFX_E_SEC_EMPTY  
   \brief This macro denotes section empty
*/
#define IFX_E_SEC_EMPTY                 -6

/*!\def IFX_E_INVALID_INPUT 
   \brief This macro denotes invalid input
*/
#define IFX_E_INVALID_INPUT             -7

/*!\def IFX_EMERG(fmt, args...)
   \brief This macro denotes emergency filter level of syslog
*/
#define IFX_EMERG(fmt, args...)	syslog(LOG_EMERG, fmt, ##args)

/*!\def IFX_ALERT(fmt, args...)
   \brief This macro denotes alert filter level of syslog
*/
#define IFX_ALERT(fmt, args...)	syslog(LOG_ALERT, fmt, ##args)

/*!\def IFX_CRIT(fmt, args...)
   \brief This macro denotes critical filter level of syslog
*/
#define IFX_CRIT(fmt, args...)	syslog(LOG_CRIT, fmt, ##args)

/*!\def IFX_ERROR(fmt, args...)
   \brief This macro denotes error filter level of syslog
*/
#define IFX_ERROR(fmt, args...)	syslog(LOG_ERR, fmt, ##args)

/*!\def IFX_WARN(fmt, args...)
   \brief This macro denotes warning filter level of syslog
*/
#define IFX_WARN(fmt, args...)	syslog(LOG_WARNING, fmt, ##args)

/*!\def IFX_NOTICE(fmt, args...)	
   \brief This macro denotes notice filter level of syslog
*/
#define IFX_NOTICE(fmt, args...)	syslog(LOG_NOTICE, fmt, ##args)

/*!\def IFX_INFO(fmt, args...)
   \brief This macro denotes info filter level of syslog
*/
#define IFX_INFO(fmt, args...)	syslog(LOG_INFO, fmt, ##args)

/*!\def IFX_DBG(fmt, args...)
   \brief This macro denotes debug filter level of syslog
*/
#define IFX_DBG(fmt, args...)	syslog(LOG_DEBUG, fmt, ##args)

/*!\def IFX_API_LOG(fmt, args...)
   \brief This macro denotes API syslog
*/

#define IFX_API_LOG(fmt, args...)	syslog(LOG_ERR, fmt, ##args)

#if 1

/*!\def IFX_ERR(fmt, args...)
   \brief This macro denotes error log
*/

#define IFX_ERR(fmt, args...)	printf("(%s)-Error:" fmt, __func__, ##args)
#else

/*!\def IFX_ERR(fmt, args...)
   \brief This macro denotes error log 
*/

#define IFX_ERR(fmt, args...)
#endif

/*!\def IFX_F_DEFAULT    
   \brief This macro denotes default value
*/
#define IFX_F_DEFAULT    0x0	//Backward compatibility..same old behav.

/*!\def IFX_ACL_CHECK_FAILED 
   \brief This macro denotes ACL check failure
*/
#define IFX_ACL_CHECK_FAILED -100

// SetCfg Flags
//EXTERNAL FLAGS

/*!\def IFX_F_DONT_ACTIVATE 
   \brief This macro denotes no activation of entry
*/

#define IFX_F_DONT_ACTIVATE       (0x01)	//Does not activate the entry.

/*!\def IFX_F_DEACTIVATE 
   \brief This macro denotes deactivation of entry
*/
#define IFX_F_DEACTIVATE          (0x01<<1)	//Deacte the entry prepend with #

/*!\def IFX_F_INCOMPLETE
   \brief This macro denotes incomplete entry
*/
#define IFX_F_INCOMPLETE          (0x01<<2)	//Mark entry incomp prepend with #$

/*!\def IFX_F_MODIFY 
   \brief This macro denotes modify entry
*/
#define IFX_F_MODIFY              (0x01<<3)	//Modify action

/*!\def IFX_F_DELETE  
   \brief This macro denotes delete entry
*/
#define IFX_F_DELETE              (0x01<<4)	//Delete Action

/*!\def IFX_F_DONT_VALIDATE 
   \brief This macro denotes not to validate
*/
#define IFX_F_DONT_VALIDATE       (0x01<<5)	// Dont Validate

/*!\def IFX_F_DONT_WRITE_TO_FLASH
   \brief This macro denotes dont write to flash
*/

#define IFX_F_DONT_WRITE_TO_FLASH (0x01<<6)	//Dont Write To Flash

/*!\def IFX_F_DONT_CHECKPOINT
   \brief This macro denotes dont checkpoint
*/
#define IFX_F_DONT_CHECKPOINT     (0x01<<7)	//Dont CheckPoint.

#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
	/*!\def IFX_PER_WAN_DEFAULT_WAN
	   \brief This macro denotes Per WAN Type Default WAN
	 */
#define IFX_PER_WAN_DEFAULT_WAN 	(0x01<<10)	//Per Wan Mode Default Wan Connection.
#endif

/*!\def IFX_F_RESET_WEB_CFG
   \brief This macro denotes reset the web flag after succesful get
*/
#define IFX_F_RESET_WEB_CFG     (0x01<<14)

//INTERNAL FLAGS

/*!\def IFX_F_INT_ADD 
   \brief This macro denotes internal add
*/
#define IFX_F_INT_ADD        (0x01<<31)	//Internal-Add to distinguish the overwrite case.

/*!\def IFX_F_INT_MOD_ADD
   \brief This macro denotes internal modify
*/
#define IFX_F_INT_MOD_ADD    (0x01<<30)	//Case of ADD in Modify op.

/*!\def IFX_F_INT_BACKUP  
   \brief This macro denotes internal backup
*/
#define IFX_F_INT_BACKUP     (0x01<<29)	//Backup File Action

/*!\def IFX_F_INT_RESTORE
   \brief This macro denotes internal restore file action
*/
#define IFX_F_INT_RESTORE    (0x01<<28)	//Restore File Action

/*!\def IFX_F_INT_RESTORE_FROM_FLASH   
   \brief This macro denotes internal restore from flash
*/
#define IFX_F_INT_RESTORE_FROM_FLASH   (0x01<<27)	//Restore File from Flash Action

/*!\def IFX_F_INT_DONT_RESTART_SERVICES  
   \brief This macro denotes dont restart services
*/
#define IFX_F_INT_DONT_RESTART_SERVICES  (0x01<<26)	//Dont Restart services

/*!\def IFX_F_INT_DONT_CONFIGURE
   \brief This macro denotes dont configure
*/
#define IFX_F_INT_DONT_CONFIGURE	(0x01<<25)	//Dont do device configuration - similar to the external flag IFX_F_DONT_ACTIVATE

/*!\def IFX_F_INT_CACHE_INIT
   \brief This macro denotes initialize cache
*/
#define IFX_F_INT_CACHE_INIT		(0x01<<24)	//Initialize cache in GetCfgData

/*!\def IFX_F_INT_CACHE_DESTROY
   \brief This macro denotes destroy cache
*/
#define IFX_F_INT_CACHE_DESTROY		(0x01<<23)	//Destory cache in GetCfgData

/*!\def IFX_F_INT_DONT_SEND_NOTIFICATION  
   \brief This macro denotes dont send notification
*/
#define IFX_F_INT_DONT_SEND_NOTIFICATION  (0x01<<22)	//Dont send a notification to TR69 stack

/*!\def IFX_F_INT_DONT_CHECK_ACL  
   \brief This macro denotes dont check ACL
*/
#define IFX_F_INT_DONT_CHECK_ACL  (0x01<<21)	//Dont check ACL

/*!\def IFX_F_INT_DONT_SEND_SET_NOTIFICATION
 \ brief This macro denotes dont send wlan set notification to devm
*/
#define IFX_F_INT_DONT_SEND_SET_NOTIFICATION (0x01<<20)    //Dont send a wlan set otification to devm

/*!\def IFX_F_INT_DONT_START_WLAN_IF_ON_SECURITY_CHANGE
 \ brief This macro denotes dont start wlan interface after security settings change
*/
#define IFX_F_INT_DONT_START_WLAN_IF_ON_SECURITY_CHANGE (0x01<<19)	//Keep WLAN interfaces down after security settings changed

/*!\def IFX_F_INT_DONT_START_SERVICES  
   \brief This macro denotes services must not be started
*/
#define IFX_F_INT_DONT_START_SERVICES  (0x01<<18)	//Dont Start services

/*!\def LTQ_F_INT_DONT_RECONF_SECURITY
 \ brief This macro denotes dont reconfigure security settings
*/
#define LTQ_F_INT_DONT_RECONFIG_SECURITY (0x01<<17)

/*!\def LTQ_F_INT_DONT_RECONFIG_MAIN
 \ brief This macro denotes dont reconfigure main settings
*/
#define LTQ_F_INT_DONT_RECONFIG_MAIN (0x01<<16)

//GetCfgData or GetCfgObj Flags

/*!\def IFX_F_GET_ANY        
   \brief This macro denotes no check on status
*/
#define IFX_F_GET_ANY        (0x01<<8)	//Flag used in GetCfg or Obj for no check on status.

/*!\def IFX_F_GET_ENA        
   \brief This macro denotes active check on status
*/
#define IFX_F_GET_ENA        IFX_F_MODIFY	//Flag used in GetCfg or Obj for Active check on status.

/*!\def IFX_F_GET_DIS        
   \brief This macro denotes deactivated check on status
*/
#define IFX_F_GET_DIS        IFX_F_DEACTIVATE	//Flag used in GetCfg or Obj for Deactivated check on status.

/*!\def IFX_F_GET_INCOMP     
   \brief This macro denotes incomplete check on status
*/
#define IFX_F_GET_INCOMP     IFX_F_INCOMPLETE	//Flag used in GetCfg for Incomp check on status.

/*!\def IFX_F_GETCFG_MASK
   \brief This macro denotes GETCFG function mask flag
*/
#define IFX_F_GETCFG_MASK  IFX_F_GET_ANY|IFX_F_GET_ENA|IFX_F_GET_DIS|IFX_F_GET_INCOMP

/*!\def IFX_F_SETCFG_MASK
   \brief This macro denotes SETCFG function mask flag
*/
#define IFX_F_SETCFG_MASK IFX_F_DONT_ACTIVATE|IFX_F_DEACTIVATE| \
                            IFX_F_INCOMPLETE|IFX_F_MODIFY|IFX_F_DELETE| \
                            IFX_F_DONT_VALIDATE|IFX_F_DONT_WRITE_TO_FLASH| \
                            IFX_F_DONT_CHECKPOINT|IFX_F_INT_ADD| \
                            IFX_F_INT_MOD_ADD|IFX_F_INT_BACKUP| \
                            IFX_F_INT_RESTORE|IFX_F_INT_RESTORE_FROM_FLASH| \
                            IFX_F_INT_DONT_RESTART_SERVICES

//Macros to check the flags set or not set.

/*!\def IFX_DONT_ACTIVATE_F_SET(__flag__)
   \brief This macro denotes dont activate flag set
*/
#define IFX_DONT_ACTIVATE_F_SET(__flag__) ((__flag__) & IFX_F_DONT_ACTIVATE)

/*!\def IFX_DONT_ACTIVATE_F_NOT_SET(__flag__) 
   \brief This macro denotes that flags are not set and are not activated
*/
#define IFX_DONT_ACTIVATE_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_DONT_ACTIVATE))

/*!\def IFX_DEACTIVATE_F_SET(__flag__)
   \brief This macro denotes deactivate flag set
*/

#define IFX_DEACTIVATE_F_SET(__flag__) ((__flag__) & IFX_F_DEACTIVATE)
/*!\def IFX_DEACTIVATE_F_NOT_SET(__flag__) 
   \brief This macro denotes deactivate flag and not set
*/
#define IFX_DEACTIVATE_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_DEACTIVATE))

/*!\def IFX_INCOMPLETE_F_SET(__flag__) 
   \brief This macro denotes incomplete flag set
*/

#define IFX_INCOMPLETE_F_SET(__flag__) ((__flag__) & IFX_F_INCOMPLETE)
#define IFX_INCOMPLETE_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_INCOMPLETE))

/*!\def IFX_INCOMPLETE_F_NOT_SET(__flag__) 
   \brief This macro denotes incomplete flag not set
*/
#define IFX_INCOMPLETE_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_INCOMPLETE))

/*!\def IFX_MODIFY_F_SET(__flag__) 
   \brief This macro denotes modify flags set
*/
#define IFX_MODIFY_F_SET(__flag__) ((__flag__) & IFX_F_MODIFY)

/*!\def IFX_MODIFY_F_NOT_SET(__flag__) 
   \brief This macro denotes modify flags not set
*/
#define IFX_MODIFY_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_MODIFY))

/*!\def IFX_DELETE_F_SET(__flag__) 
   \brief This macro denotes delete flags set
*/

#define IFX_DELETE_F_SET(__flag__) ((__flag__) & IFX_F_DELETE)

/*!\def IFX_DELETE_F_NOT_SET(__flag__) 
   \brief This macro denotes delete flags not set
*/
#define IFX_DELETE_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_DELETE))

/*!\def IFX_DONT_VALIDATE_F_SET(__flag__) 
   \brief This macro denotes dont validate flags set
*/
#define IFX_DONT_VALIDATE_F_SET(__flag__) ((__flag__) & IFX_F_DONT_VALIDATE)

/*!\def IFX_DONT_VALIDATE_F_NOT_SET(__flag__) 
   \brief This macro denotes dont validate flags not set
*/

#define IFX_DONT_VALIDATE_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_DONT_VALIDATE))

/*!\def IFX_DONT_WRITE_TO_FLASH_F_SET(__flag__) 
   \brief This macro denotes dont write to flash flags set
*/

#define IFX_DONT_WRITE_TO_FLASH_F_SET(__flag__) ((__flag__) & IFX_F_DONT_WRITE_TO_FLASH)

/*!\def  IFX_DONT_WRITE_TO_FLASH_F_NOT_SET(__flag__) 
   \brief This macro denotes dont write to flash flags not set
*/
#define IFX_DONT_WRITE_TO_FLASH_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_DONT_WRITE_TO_FLASH))

/*!\def IFX_DONT_CHECKPOINT_F_SET(__flag__) 
   \brief This macro denotes dont ckeckpoint flags set
*/
#define IFX_DONT_CHECKPOINT_F_SET(__flag__) ((__flag__) & IFX_F_DONT_CHECKPOINT)

/*!\def IFX_DONT_CHECKPOINT_F_NOT_SET(__flag__) 
   \brief This macro denotes dont ckeckpoint flags not set
*/
#define IFX_DONT_CHECKPOINT_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_DONT_CHECKPOINT))

/*!\def IFX_RESET_WEB_CFG_F_SET(__flag__)
   \brief This macro denotes reset web flag set
*/
#define IFX_RESET_WEB_CFG_F_SET(__flag__) ((__flag__) & IFX_F_RESET_WEB_CFG)

/*!\def IFX_RESET_WEB_CFG_F_NOT_SET(__flag__) 
   \brief This macro denotes that flags are not set and are not activated
*/
#define IFX_RESET_WEB_CFG_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_RESET_WEB_CFG))

/*!\def  IFX_ADD_F_SET(__flag__)
   \brief This macro denotes add flags set
*/
#define IFX_ADD_F_SET(__flag__) (!((__flag__) & (IFX_F_DELETE | IFX_F_MODIFY)))

/*!\def IFX_ADD_F_NOT_SET(__flag__) 
   \brief This macro denotes add flags not set
*/
#define IFX_ADD_F_NOT_SET(__flag__) ((__flag__) & (IFX_F_DELETE | IFX_F_MODIFY))

/*!\def IFX_INT_ADD_F_SET(__flag__) 
   \brief This macro denotes internal add flags set
*/

#define IFX_INT_ADD_F_SET(__flag__) ((__flag__) & IFX_F_INT_ADD)

/*!\def IFX_INT_ADD_F_NOT_SET(__flag__) 
   \brief This macro denotes internal add flags not set
*/
#define IFX_INT_ADD_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_INT_ADD))

/*!\def IFX_INT_MOD_ADD_F_SET(__flag__) 
   \brief This macro denotes internal modify add flags set
*/
#define IFX_INT_MOD_ADD_F_SET(__flag__) ((__flag__) & IFX_F_INT_MOD_ADD)

/*!\def IFX_INT_MOD_ADD_F_NOT_SET(__flag__) 
   \brief This macro denotes internal modify add flags not set
*/
#define IFX_INT_MOD_ADD_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_INT_MOD_ADD))

/*!\def IFX_INT_BACKUP_F_SET(__flag__) 
   \brief This macro denotes internal backup flags set
*/
#define IFX_INT_BACKUP_F_SET(__flag__) ((__flag__) & IFX_F_INT_BACKUP)

/*!\def IFX_INT_BACKUP_F_NOT_SET(__flag__) 
   \brief This macro denotes internal backup flags not set
*/
#define IFX_INT_BACKUP_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_INT_BACKUP))

/*!\def IFX_INT_RESTORE_F_SET(__flag__) 
   \brief This macro denotes internal restore flags set
*/
#define IFX_INT_RESTORE_F_SET(__flag__) ((__flag__) & IFX_F_INT_RESTORE)

/*!\def IFX_INT_RESTORE_F_NOT_SET(__flag__) 
   \brief This macro denotes internal restore flags not set
*/
#define IFX_INT_RESTORE_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_INT_RESTORE))
/*!\def IFX_INT_RESTORE_FROM_FLASH_F_SET(__flag__) 
   \brief This macro denotes internal restore from flash flags set
*/

#define IFX_INT_RESTORE_FROM_FLASH_F_SET(__flag__) ((__flag__) & IFX_F_INT_RESTORE_FROM_FLASH)

/*!\def IFX_INT_RESTORE_FROM_FLASH_F_NOT_SET(__flag__) 
   \brief This macro denotes internal restore from flash flags not set
*/
#define IFX_INT_RESTORE_FROM_FLASH_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_INT_RESTORE_FROM_FLASH))

/*!\def IFX_INT_DONT_RESTART_SERVICES_F_SET(__flag__) 
   \brief This macro denotes dont restart services flags set
*/
#define IFX_INT_DONT_RESTART_SERVICES_F_SET(__flag__) ((__flag__) & IFX_F_INT_DONT_RESTART_SERVICES)

/*!\def IFX_INT_DONT_RESTART_SERVICES_F_NOT_SET(__flag__) 
   \brief This macro denotes dont restart services flags not set  
*/
#define IFX_INT_DONT_RESTART_SERVICES_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_INT_DONT_RESTART_SERVICES))

/*!\def IFX_INT_DONT_START_SERVICES_F_SET(__flag__) 
   \brief This macro denotes dont start services flags set
*/
#define IFX_INT_DONT_START_SERVICES_F_SET(__flag__) ((__flag__) & IFX_F_INT_DONT_START_SERVICES)

/*!\def IFX_INT_DONT_START_SERVICES_F_NOT_SET(__flag__) 
   \brief This macro denotes dont start services flags not set  
*/
#define IFX_INT_DONT_START_SERVICES_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_INT_DONT_START_SERVICES))

/*!\def IFX_GET_ANY_F_SET(__flag__) 
   \brief This macro denotes no check on status of flag set 
*/
#define IFX_GET_ANY_F_SET(__flag__) ((__flag__) & IFX_F_GET_ANY)

/*!\def IFX_GET_ANY_F_NOT_SET(__flag__) 
   \brief This macro denotes no check on status of flag not set
*/
#define IFX_GET_ANY_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_GET_ANY))

/*!\def IFX_GET_ENA_F_SET(__flag__) 
   \brief This macro denotes active check on status of flag set
*/
#define IFX_GET_ENA_F_SET(__flag__) ((__flag__) & IFX_F_GET_ENA)

/*!\def IFX_GET_ENA_F_NOT_SET(__flag__) 
   \brief This macro denotes active check on status of flag not set
*/
#define IFX_GET_ENA_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_GET_ENA))

/*!\def IFX_GET_DIS_F_SET(__flag__) 
   \brief This macro denotes deactivated check on status of flag set 
*/
#define IFX_GET_DIS_F_SET(__flag__) ((__flag__) & IFX_F_GET_DIS)

/*!\def IFX_GET_DIS_F_NOT_SET(__flag__) 
   \brief This macro denotes deactivated check on status of flag not set 
*/
#define IFX_GET_DIS_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_GET_DIS))

/*!\def IFX_GET_INCOMP_F_SET(__flag__) 
   \brief This macro denotes incomplete check on status of flag set 
*/

#define IFX_GET_INCOMP_F_SET(__flag__) ((__flag__) & IFX_F_GET_INCOMP)

/*!\def IFX_GET_INCOMP_F_NOT_SET(__flag__) 
   \brief This macro denotes incomplete check on status of flag not set
*/

#define IFX_GET_INCOMP_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_GET_INCOMP))

/*!\def IFX_INT_DONT_CONFIGURE_F_SET(__flag__) 
   \brief This flag denotes dont do device configuration and flag is set 
*/

#define IFX_INT_DONT_CONFIGURE_F_SET(__flag__) ((__flag__) & IFX_F_INT_DONT_CONFIGURE)

/*!\def IFX_INT_DONT_CONFIGURE_F_NOT_SET(__flag__) 
   \brief This flag denotes dont do device configuration and flag is not set
*/
#define IFX_INT_DONT_CONFIGURE_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_INT_DONT_CONFIGURE))

   /*!\def IFX_INT_CACHE_INIT_F_SET(__flag__) 
      \brief This macro denotes initialize cache and flag is set 
    */

#define IFX_INT_CACHE_INIT_F_SET(__flag__) ((__flag__) & IFX_F_INT_CACHE_INIT)

/*!\def IFX_INT_CACHE_DESTROY_F_SET(__flag__) 
   \brief This macro denotes initialize cache and flag is not set
*/
#define IFX_INT_CACHE_DESTROY_F_SET(__flag__) (((__flag__) & IFX_F_INT_CACHE_DESTROY))

/*!\def IFX_INT_DONT_SEND_NOTIFICATION_F_SET(__flag__) 
   \brief This macro denotes dont send notiification and flag is set
*/

#define IFX_INT_DONT_SEND_NOTIFICATION_F_SET(__flag__) ((__flag__) & IFX_F_INT_DONT_SEND_NOTIFICATION)

/*!\def IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(__flag__) 
   \brief This macro denotes dont send notification and fag is not set
*/

#define IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_INT_DONT_SEND_NOTIFICATION))

/*!\def IFX_F_INT_DONT_SEND_SET_NOTIFICATION(__flag__)
 *    \brief This macro denotes dont send notiification and flag is set
 *    */

#define IFX_INT_DONT_SEND_SET_NOTIFICATION_F_SET(__flag__) ((__flag__) & IFX_F_INT_DONT_SEND_SET_NOTIFICATION)

/*!\def IFX_F_INT_DONT_SEND_SET_NOTIFICATION(__flag__)
 *    \brief This macro denotes dont send notification and fag is not set
 *    */

#define IFX_INT_DONT_SEND_SET_NOTIFICATION_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_INT_DONT_SEND_SET_NOTIFICATION))


/*!\def IFX_INT_DONT_CHECK_ACL_F_SET(__flag__) 
   \brief This macro denotes dont check ACL and flag is set
*/
#define IFX_INT_DONT_CHECK_ACL_F_SET(__flag__) ((__flag__) & IFX_F_INT_DONT_CHECK_ACL)

/*!\def IFX_INT_DONT_CHECK_ACL_F_NOT_SET(__flag__) 
   \brief This macro denotes dont check ACL and flag is not set
*/
#define IFX_INT_DONT_CHECK_ACL_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_INT_DONT_CHECK_ACL))

/*!\def IFX_F_INT_DONT_START_WLAN_IF_ON_SECURITY_CHANGE_F_SET(__flag__)
 *    \brief This macro denotes dont start wlan if flag is set
 *    */
#define IFX_F_INT_DONT_START_WLAN_IF_ON_SECURITY_CHANGE_F_SET(__flag__) ((__flag__) & IFX_F_INT_DONT_START_WLAN_IF_ON_SECURITY_CHANGE)

/*!\def IFX_F_INT_DONT_START_WLAN_IF_ON_SECURITY_CHANGE_F_NOT_SET(__flag__)
 *    \brief This macro denotes dont start wlan if flag is set
 *    */
#define IFX_F_INT_DONT_START_WLAN_IF_ON_SECURITY_CHANGE_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_INT_DONT_START_WLAN_IF_ON_SECURITY_CHANGE))

/*!\def LTQ_F_INT_DONT_RECONFIG_SECURITY_F_SET(__flag__)
 *    \brief This macro denotes dont reconfigure security if flag is set
 *    */
#define LTQ_F_INT_DONT_RECONFIG_SECURITY_F_SET(__flag__) ((__flag__) & LTQ_F_INT_DONT_RECONFIG_SECURITY)

/*!\def LTQ_F_INT_DONT_RECONFIG_SECURITY_F_NOT_SET(__flag__)
 *    \brief This macro denotes dont reconfigure security flag is not set
 *    */
#define LTQ_F_INT_DONT_RECONFIG_SECURITY_F_NOT_SET(__flag__) (!((__flag__) & LTQ_F_INT_DONT_RECONFIG_SECURITY))
	
/*!\def LTQ_F_INT_DONT_RECONFIG_MAIN_F_SET(__flag__)
 *    \brief This macro denotes dont reconfigure main if flag is set
 *    */
#define LTQ_F_INT_DONT_RECONFIG_MAIN_F_SET(__flag__) ((__flag__) & LTQ_F_INT_DONT_RECONFIG_MAIN)

/*!\def LTQ_F_INT_DONT_RECONFIG_MAIN_F_NOT_SET(__flag__)
 *    \brief This macro denotes dont reconfigure main flag is not set
 *    */
#define LTQ_F_INT_DONT_RECONFIG_MAIN_F_NOT_SET(__flag__) (!((__flag__) & LTQ_F_INT_DONT_RECONFIG_MAIN))
	
/*!\def IFX_SET_DONT_SEND_NOTIFICATION_FLAG(__flag__) 
   \brief This macro denotes dont send notification flag is set
*/
#define IFX_SET_DONT_SEND_NOTIFICATION_FLAG(__flag__) ((__flag__) | IFX_F_INT_DONT_SEND_NOTIFICATION)

/*!\def IFX_UNSET_DONT_SEND_NOTIFICATION_FLAG(__flag__) 
   \brief This macro denotes dont send notification flag is unset
*/
#define IFX_UNSET_DONT_SEND_NOTIFICATION_FLAG(__flag__) ((__flag__) & ~IFX_F_INT_DONT_SEND_NOTIFICATION)

/*!\def IFX_SET_DONT_CHECK_ACL_FLAG(__flag__) 
   \brief This macro denotes dont check ACL flag is set
*/

#define IFX_SET_DONT_CHECK_ACL_FLAG(__flag__) ((__flag__) | IFX_F_INT_DONT_CHECK_ACL)

/*!\def IFX_UNSET_DONT_CHECK_ACL_FLAG(__flag__) 
   \brief This macro denotes dont check ACL flag is unset
*/
#define IFX_UNSET_DONT_CHECK_ACL_FLAG(__flag__) ((__flag__) & ~IFX_F_INT_DONT_CHECK_ACL)

/*!\def IFX_CONFIG_OWNER_NOT_TR69(iid) 
   \brief This macro denotes object owner is not TR69
*/
#define IFX_CONFIG_OWNER_NOT_TR69(iid) (!((iid.config_owner) & (IFX_TR69)))

#if 1				/* [ 23122006, Ritesh */

/*!\def NULL_TERMINATE(p, val, n)
   \brief This macro terminates character array by null value
*/

#define NULL_TERMINATE(p, val, n)	do {	\
	 char *__q = (char *) (p); __q[0]='\0'; __q[n-1]='\0'; }while(0)

/*!\def STRNCPY(d, s, len)	
   \brief This macro denotes string copy
*/
#define STRNCPY(d, s, len)		\
	do { strncpy(d, s, len); d[len]='\0'; } while(0)

/*!\def FREAD(buf, m, n, fp)	
   \brief This macro denotes file read
*/
#define FREAD(buf, m, n, fp)			\
	({ int __n; buf[0]='\0'; __n = fread((buf), (m), (n), (fp));	\
	 if (__n > 0) (buf)[__n-1]='\0'; __n;  })

#endif				/* ] */

/*!\def skip_space(line, p)
   \brief This macro denotes skiping white space charecters
*/
#define skip_space( line, p)  for((p) = line; *(p) == ' ' || *(p) == '\t'; (p)++)

/*!\def skip_data(line,p)
   \brief This macro denotes finding next white space charecters
*/
#define skip_data( line, p)   for((p) = line; *(p) != ' ' && *(p) != '\t'; (p)++)

/* Now include all the API includes */
#ifndef IFX_SKIP_API_INCL
#include <ifx_api_include.h>
#endif /* #ifndef IFX_SKIP_API_INCL */

#ifdef ORGCODE

/*! \brief enumeration for ATM QoS
*/

enum {
	ATM_QOS_UBR = 0,
	ATM_QOS_CBR,
	ATM_QOS_NRT_VBR,
	ATM_QOS_RT_VBR,
	ATM_QOS_UBR_PLUS,	/* 507121:linmars */
};

#else
/* This is put for WEB/CLI/SNMP/TR69 to be in
 * synch with the ATM QoS values of the Kernel */

/*! \brief  This is put for WEB/CLI/SNMP/TR69 to be in
  synch with the ATM QoS values of the Kernel 
*/

enum {
	ATM_QOS_UBR = 1,
	ATM_QOS_CBR = 2,
	ATM_QOS_NRT_VBR = 3,
	ATM_QOS_RT_VBR = 6,
	ATM_QOS_UBR_PLUS = 7,
};
#endif				//ORGCODE

/* 000001:Nirav start */

/*!
    \brief Structure describing the version node.
*/
struct st_versionnode {
	pid_t UI_pid;		/*!< child process id */
	unsigned int config_version;	/*!< configuration version */
	long int timeval;	/*!< time value */
	struct st_versionnode *next;	/*!< next node pointer */
};
/* 000001:Nirav end */

/*!\fn int ifx_run_command(char *command)
   \brief extern integer type function. This functions executes a command
   \param[in] command	
   \return status of the command executed
*/
extern int ifx_run_command(char *command);

/*!\fn int ifx_create_pid_file(char *file_prefix)
   \brief extern integer type function. This function creates process id file for given file prefix
   \param[in] file_prefix
   \return IFX_SUCCESS/IFX_FAILURE
*/
extern int ifx_create_pid_file(char *file_prefix);

/*!\fn int ifx_get_process_pid(char *file_prefix)
   \brief extern integer type function. This function returns process id for the given file prefix
   \param[in] file_prefix
   \return Process ID
*/
extern int ifx_get_process_pid(char *file_prefix);

/*!\fn int ifx_rm_pid_file(char *file_prefix)
   \brief extern integer type function removes the process id file
   \param[in] file_prefix
   \return Zero is returned on success, else error number is set appropriately
*/
extern int ifx_rm_pid_file(char *file_prefix);

/*!\fn void ifx_rm_pid_file_atexit(void)
   \brief extern integer type function removes the process id file
   \return Zero is returned on success, else error number is set appropriately
   
*/
extern void ifx_rm_pid_file_atexit(void);

/*!\fn int ifx_validate_pid(pid_t pid, char *cmd_arg)
   \brief extern integer type function. This function validates whether the input pid is indeed the process that is required 
   \param[in] pid
   \param[in] cmd_arg
   \return IFX_SUCCESS/IFX_FAILURE
*/
extern int ifx_validate_pid(pid_t pid, char *cmd_arg);

/*!\fn void ifx_web_convert_string(char *p)
   \brief  
   \param[in] p
   \param[out] p
*/
extern void ifx_web_convert_string(char *p);

// extern int ifx_GetCfgData(char *pFileName, char *pTag, char *pData, char *pRetValue);

/*!\fn int32 ifx_GetCfgData( IFX_IN  const char8    *pFileName,
                    IFX_IN  const char8    *pTag,
                    IFX_IN  char8          *pData,
                    IFX_OUT char8          *pRetValue)
   \brief This API also returns the value part (i.e. RHS of '=' for 'Name=Value' pair) corresponding to input string name
          through reading in system configuration database in string form. This is a simplified wrapper of previous function
          ifx_GetObjData with no flags arguments in its prototype
   \param[in] *pFileName File Name from where to read the entry
   \param[in] *pTag Section, Tag or Object Name.
   \param[in] *pData Parameter Name.
   \param[in] *pRetValue  Returned queried value for a given name
   \return   IFX_SUCCESS /  IFX_FAILURE / IFX_E_INT_ERROR / IFX_E_SEC_NOT_FOUND / IFX_E_PARAM_NOT_FOUND / IFX_E_UNMATCHED_INPUT /  IFX_E_SEC_EMPTY
*/
extern int32 ifx_GetCfgData(IFX_IN const char8 * pFileName,
			    IFX_IN const char8 * pTag,
			    IFX_IN char8 * pData, IFX_OUT char8 * pRetValue);
// extern char *ifx_GetCfgDatafromString(char *pString, char *pSymbol);

/*!\fn int32 ifx_GetCfgDatafromString(char8 *pString, char8 *pSymbol, uint32 *stateFlag, char8 *pRet)
   \brief finds the data in the string pString
   \param[in] pString
   \param[in] pSymbol
   \param[in] stateFlag
   \param[in] pRet
   \return a pointer to the beginning of the Data which found,
//                      or NULL if the pSymbol is not found

*/
extern int32 ifx_GetCfgDatafromString(char8 * pString, char8 * pSymbol,
				      uint32 * stateFlag, char8 * pRet);

 // extern int ifx_SetCfgData(const char* pFileName, const char* pTag, int nDataCount, const char *pData, ... );

 /*!\fn int32 ifx_SetCfgData(IFX_IN  const char8*   pFileName,
    IFX_IN  const char8*   pTag,
    IFX_IN  int32           nDataCount,
    IFX_IN  const char8*   pData,
    IFX_IN  ... )
    \brief This API also performs the write operations to system config database. It is a simplified wrapper of ifx_SetObjData
    and does not take the flags in its prototype. This API always results overwrite to specified section with input buffer.
    \param[in] *pFileName File name, in which to overwrite section contents
    \param[in] *pTag Section, Tag or Object Name to be overwritten.
    \param[in] nDataCount Number of Var Args following after this
    \param[in] *pData  Variable Arguments Input to be overwritten in pTag section.
    \return IFX_SUCCESS /  IFX_FAILURE /  IFX_E_INT_ERROR / IFX_E_SEC_EMPTY
  */
extern int32 ifx_SetCfgData(IFX_IN const char8 * pFileName,
			    IFX_IN const char8 * pTag,
			    IFX_IN int32 nDataCount,
			    IFX_IN const char8 * pData, IFX_IN ...);

/*!\fn int32 ifx_GetObjData( IFX_IN  const char8    *pFileName,
                    IFX_IN  const char8    *pTag,
                    IFX_IN  char8          *pData,
                    IFX_IN  uint32         inFlag,
                    IFX_OUT uint32         *outFlag,
                    IFX_OUT char8          *pRetValue)
 \brief This API returns the value part (i.e. RHS of '=' for 'Name=Value' pair) corresponding to input string name through
         reading in system configuration database in string form.
 \param[in] *pFileName Configuration File Name from where to read the entry. (e.g. /flash/rc.conf)
 \param[in] *pTag  Section, Tag or Object Name. (e.g. lan_main)
 \param[in] *pData  Parameter Name. (e.g. lan_main_0_ipAddr)
 \param[in] inFlag  Filter for querying the name with particular status
 \param[in] *outFlag  Actual State of Parameter returned in case of failures
 \param[in] *pRetValue  Returned queried value for a given name
 \return  IFX_SUCCESS /  IFX_FAILURE /  IFX_E_INT_ERROR / IFX_E_SEC_NOT_FOUND /  IFX_E_PARAM_NOT_FOUND / IFX_E_UNMATCHED_INPUT / IFX_E_SEC_EMPTY
  
*/

extern int32 ifx_GetObjData(IFX_IN const char8 * pFileName,
			    IFX_IN const char8 * pTag,
			    IFX_IN char8 * pData,
			    IFX_IN uint32 inFlag,
			    IFX_OUT uint32 * outFlag,
			    IFX_OUT char8 * pRetValue);

/*!\fn int32 ifx_GetObjDataOpt( IFX_IN  const char8    *pFileName,
                      IFX_IN  const char8    *pTag,
                      IFX_IN  char8          *pData,
                      IFX_IN  uint32         inFlag,
                      IFX_OUT uint32         *outFlag,
                      IFX_OUT char8          *pRetValue)

 \brief This API is similar to ifx_GetObjData. Difference being that it first checks the tag requested in global cache. If found return value directly otherwise call ifx_GetObjData which will search for tag in system configuration database and return the value.
 \param[in] *pFileName Configuration File Name from where to read the entry. (e.g. /flash/rc.conf)
 \param[in] *pTag  Section, Tag or Object Name. (e.g. lan_main)
 \param[in] *pData  Parameter Name. (e.g. lan_main_0_ipAddr)
 \param[in] inFlag  Filter for querying the name with particular status
 \param[in] *outFlag  Actual State of Parameter returned in case of failures
 \param[in] *pRetValue  Returned queried value for a given name
 \return IFX_SUCCESS/IFX_FAILURE
  
*/
extern int32 ifx_GetObjDataOpt(IFX_IN const char8 * pFileName,
			       IFX_IN const char8 * pTag,
			       IFX_IN char8 * pData,
			       IFX_IN uint32 inFlag,
			       IFX_OUT uint32 * outFlag,
			       IFX_OUT char8 * pRetValue);

/*!\fn int ifx_GetCfgObject(IFX_IN const char *pFileName, 
                            IFX_IN const char *pTag, 
                            IFX_IN char *pData, 
                            IFX_OUT uint32 stateFlag, 
                            IFX_OUT char **pRetValue)
   \brief This API is an extension of ifx_GetObjData API and can do bulk query. It can return the whole section contents
          between BEGIN and END TAG. This can also do wild carding for given partial name and returns the matching
           name-value pairs. It also takes state as input flag for filtering and can return the entries belonging to 
	   that particular state only.
   \param[in] *pFileName  File name from where to read the entry
   \param[in] *pTag  Section, Tag or Object Name.
   \param[in] *pData Parameter Name (Either complete or partial Name)Could be NULL as well in that case whole section is returned
   \param[in] stateFlag  Filter for querying the name with particular status
   \param[in] **pRetValue Return Buffer holding the Name-Value Pairs.
               The buffer is allocated within the API so should be freed by caller
    \return   IFX_SUCCESS /  IFX_FAILURE /  IFX_E_INT_ERROR / IFX_E_SEC_NOT_FOUND /  IFX_E_PARAM_NOT_FOUND / IFX_E_UNMATCHED_INPUT / IFX_E_SEC_EMPTY
*/
extern int ifx_GetCfgObject(IFX_IN const char *pFileName,
			    IFX_IN const char *pTag,
			    IFX_IN char *pData,
			    IFX_OUT uint32 stateFlag, IFX_OUT char **pRetValue);

/*!\fn int32 ifx_SetObjData(IFX_IN  const char*   pFileName,
                   IFX_IN  const char*   pTag,
                   IFX_IN  uint32	 operFlag,
                   IFX_IN  int32           nDataCount,
                   IFX_IN  const char*   pData,
                   IFX_IN  ... )
   \brief This API is central entry point for doing the write operations to system config database. Depending upon the flag values passed in its argument, it does variety of tasks as mentioned in table below
   \param[in] *pFileName File name, in which to write (add/modify/delete) the entry or entries
\param[in] *pTag Section, Tag or Object Name.
\param[in] operFlag Conveying the type of individual or set of actions to be taken
\param[in] nDataCount nNVPcount Number of Var Args following this
\param[in] *pData Variable Arguments.
\return IFX_SUCCESS /  IFX_FAILURE /  IFX_E_INT_ERROR / IFX_E_SEC_EMPTY
*/
extern int32 ifx_SetObjData(IFX_IN const char *pFileName,
			    IFX_IN const char *pTag,
			    IFX_IN uint32 operFlag,
			    IFX_IN int32 nDataCount,
			    IFX_IN const char *pData, IFX_IN ...);

/*!\fn int ifx_CompactCfgSection( IFX_IN const char* pFileName,
                           IFX_IN const char* pTag,
                           IFX_IN uint32	flag)
   \brief The purpose of this API is to do re-alignment of indices of object instances to sequential and continuous order in
a given section of rc.conf file. Since the object instances are getting added and deleted dynamically, it would create
some holes in indices numbering in the affected DevObjs. It is expected that after one or multiple ADD or DELETE
type of operations in a section, the user should call this API for compacting the indices to sequential order.
   \param[in] *pFileName File Name in which to compact indices of entries
   \param[in] *pTag Applicable Section or Tag name.
   \param[in] flag Action Flag - The functionality gets executed only for IFX_F_INT_ADD or IFX_F_DELETE flag value.
    \return IFX_SUCCESS \  IFX_FAILURE
*/
extern int ifx_CompactCfgSection(IFX_IN const char *pFileName,
				 IFX_IN const char *pTag, IFX_IN uint32 flag);

/*!\fn int ifx_UpdateCountInSection( IFX_IN const char* pFileName,
                                IFX_IN const char* pTag,
                                IFX_IN uint32      flag);
   \brief Update the count param in section
   \param[in] *pFileName File Name in which to compact indices of entries
   \param[in] *pTag Applicable Section or Tag name.
   \param[in] flag Action Flag - The functionality gets executed only for IFX_F_INT_ADD or IFX_F_DELETE flag value
 \return IFX_SUCCESS / IFX_FAILURE
*/
extern int ifx_UpdateCountInSection(IFX_IN const char *pFileName,
				    IFX_IN const char *pTag,
				    IFX_IN uint32 flag);

/*!\fn int ifx_dhcp_renew(char * itf_name)
   \brief This function renews DHCP connection the given interface
   \param[in] *itf_name
	\return status of the DHCP renewal
*/
extern int ifx_dhcp_renew(char *itf_name);

/*!\fn int ifx_dhcp_release(char * itf_name)
   \brief This function releases DHCP connection the given interface
   \param[in] *itf_name
	\return status of the DHCP release
*/
extern int ifx_dhcp_release(char *itf_name);

/*!\fn  int ifx_flash_write(void)
   \brief save configuration data

*/
extern int ifx_flash_write(void);

/*!\fn char *ifx_get_atm_qos_name_by_id(int id)
   \brief This function return ATM QoS name from ATM QoS ID
   \param[in] id
   \return ATM QoS ID

*/
extern char *ifx_get_atm_qos_name_by_id(int id);

/*!\fn int ifx_change_system_username_password(char *name, char *pasword)
   \brief This function changes system user name and password
   \param[in] *name
   \param[in] *pasword
   \return IFX_SUCCESS/IFX_FAILURE
*/
extern int ifx_change_system_username_password(char *name, char *pasword);

/*!\fn char *ifx_strstr(const char *origin, const char *substr)
   \brief This function is an enhanced strstr function. It will find the sub-string whole words only
   \param[in] *origin
   \param[in] *substr
   \return substring pointer
*/
extern char *ifx_strstr(const char *origin, const char *substr);

/* 000002:Nirav start */

/*!\fn int ifx_chkImage(char *name,char *errorMsg,char *img_type,int *iExapndDir)
   \brief This function validates image using CRC check and image header 
   \param[in] *name
   \param[in] *errorMsg
   \param[in] *img_type
   \param[in] *iExpandDir
   \return IFX_SUCCESS/IFX_FAILURE
*/
extern int ifx_chkImage(char *name, char *errorMsg, char *img_type,
			int *iExpandDir);

/*!\fn int ifx_chkSysConf(char *psFileName)
   \brief Validates system configuration file
   \param[in] *psFileName
   \return IFX_SUCCESS/IFX_FAILURE
*/
extern int ifx_chkSysConf(char *psFileName);

/*!\fn int ifx_invokeUpgd(char *fName,char *img_type,int iExapndDir)
   \brief This function is used to call the image upgrade script 
   \param[in] *fName
   \param[in] *img_type
   \param[in] iExapndDir
   \return IFX_SUCCESS
*/
extern int ifx_invokeUpgd(char *fName, char *img_type, int iExapndDir);

/* 000002:Nirav end */
// 000002:tc.chen start

/*!\fn int ifx_makeCMV(unsigned char opcode, unsigned char group, unsigned short address, unsigned short index1, int size, unsigned short * data, unsigned short *Message, int msg_len);
   \brief 
   \param[in] opcode
   \param[in] group
\param[in] address
\param[in] index1
\param[in] size
\param[in] *data
\param[in] *Message
\param[in] msg_len
\return IFX_SUCCESS/IFX_FAILURE

*/
extern int ifx_makeCMV(unsigned char opcode, unsigned char group,
		       unsigned short address, unsigned short index1, int size,
		       unsigned short *data, unsigned short *Message,
		       int msg_len);

/*!\fn int adsl_get_rate(int type,unsigned long *rate,unsigned long *rate_remainder)
  \brief This function returns the data rate of the adsl channel
  \param[in] type
  \param[in] *rate
  \param[in] *rate_remainder
  \return ADSL Data Rate
*/
extern int adsl_get_rate(int type, unsigned long *rate,
			 unsigned long *rate_remainder);
// 000002:tc.chen end

/*!\fn int ifx_flash_write_voip_config(void)
   \brief 
   \return IFX_SUCCESS/IFX_FAILURE
*/
extern int ifx_flash_write_voip_config(void);	// 000020:jelly:7/29

#if 0
/* 509202:linmars start */

/*!\brief this structure is describing phyport information
*/
struct ifx_phyport_info {
	int link;		/*!< integer variable */
	int speed;		/*!< integer variable */
	int duplex;		/*!< integer variable */
	int enable;		/*!< integer variable */
};

/*!\fn int ifx_get_phyport_info(int num, struct ifx_phyport_info *buf)
   \brief This function returns the status of the physical port identified by port number input 'num'
   \param[in] num
   \param[in] *buf
   \return IFX_SUCCESS/IFX_FAILURE
*/

//extern int ifx_get_phyport_info(int num, struct ifx_phyport_info *buf);

/* 509202:linmars end */

/*!\brief this structure is describing phyport status information
*/
struct ifx_phyportstats_info {
	int rxPktCnt;		/*!< integer variable */
	int txPktCnt;		/*!< integer variable */
	int rxByteCnt;		/*!< integer variable */
	int txByteCnt;		/*!< integer variable */
};

/*!\fn int ifx_get_phyportstats_info(int num, struct ifx_phyportstats_info *buf)
   \brief This function returns the statistics (counters) of the physical port identified by port number input 'num'
   \param[in] num
   \param[in] *buf
  \return IFX_SUCCESS/IFX_FAILURE
*/

//extern int ifx_get_phyportstats_info(int num, struct ifx_phyportstats_info *buf);
#endif

/* 509203:linmars start */

/*!\fn void ADM6996_RWReg(int rwmode, int addr, int *value, int fd)
   \brief TODO
   \param[in] rwmode
   \param[in] addr
   \param[in] *value
   \param[in] fd
*/

void ADM6996_RWReg(int rwmode, int addr, int *value, int fd);

/*!\fn void ADM6996_RWSWReg(int rwmode, int addr, int *value, int fd)
   \brief This function performs read/write operation on ADM6996 registers
   \param[in] rwmode Read/write mode
   \param[in] addr Address
   \param[in] value Value
   \param[in] fd File descriptor
*/

void ADM6996_RWSWReg(int rwmode, int addr, int *value, int fd);
/* 509203:linmars end */
/* @{ */

#if defined (HOSTENV) || ! defined(__UCLIBC__)
#define strlcpy(a,b,c) strncpy(a,b,c)
#define strlcat(a,b,c) strncat(a,b,c)
#endif

/*!\macro CRYPT_KEY_LEN
   \brief defines buffer size  
*/
#define CRYPT_KEY_LEN    40
#endif				/* ] ! __IFX_COMMON_H */
