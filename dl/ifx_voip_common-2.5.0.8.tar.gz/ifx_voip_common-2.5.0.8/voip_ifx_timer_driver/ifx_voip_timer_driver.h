/******************************************************************************

                                Copyright (c) 2006
                             Infineon Technologies AG
                        Am Campeon 1-12, 85579 Neubiberg, Germany

        This program is free software; you can redistribute it and/or modify
        it under the terms of the GNU General Public License as published by
        the Free Software Foundation; either version 2 of the License, or
        (at your option) any later version.

*******************************************************************************/
#ifndef _IFX_VOIP_TIMER_DRIVER_H_
#define _IFX_VOIP_TIMER_DRIVER_H_

#define IFX_TIMER_DRV_MODE_CHANGE 0x02
#define IFX_TIMER_MAX_PROCESS 10
#define IFX_TIMER_DRV_MAJOR             229
#define IFX_TIMER_DRV_MINOR_0           0
#define IFX_TIMER_DRV_MINOR_1           1

#define IFX_TIMER_DEVICE_NAME "voip_timer_driver"

#define IFX_EXPIRE_TIME_DEVIDE  (1000/timer_interval)
#define IFX_EXPIRE_TIME_MULTY   (HZ*timer_interval/1000)

struct IFX_Timer_CntrlBlock{
   struct timer_list timer;
   struct task_struct *pxtask;
   wait_queue_head_t Timer_WakeupList;
   int Timer_excpFlag;
 }IFX_Timer_CntrlBlock;

#endif /* _IFX_VOIP_TIMER_DRIVER_H_ */

