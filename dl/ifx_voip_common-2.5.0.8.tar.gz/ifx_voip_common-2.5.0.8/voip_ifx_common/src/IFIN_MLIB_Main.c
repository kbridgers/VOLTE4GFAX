/****************************************************************************************
 **   SRC_FILE          : IFIN_MLIB_Main.c
 **   PROJECT           : Memory Library
 **   MODULES           : Memory Library
 **   SRC VERSION       : v2.0
 **   DATE              : 
 **   AUTHOR            : Kumar Swamy
 **   DESCRIPTION	: 
 **   FUNCTIONS         : 
 **   COMPILER          : 
 **   REFERENCE         : Coding guide lines for VSS v2.0,
						  DIS of MLIB.
 **   COPYRIGHT         : Infineon Technologies AG 2000-2001
 **  Version Control Section  **        
 **   $Author$    
 **   $Date$      
 **   $Revisions$ 
 **   $Log$       
*************************************************************************/                                                                                                    



/************************************************************************
*  Functon Name:
*  Description :
*  Input Values:
*  OutputValues:
*  Return Value:
*************************************************************************/

#include "IFIN_IAD_Common.h"
#include "IFIN_MLIB_Main.h"

#if IFIN_MLIB_FLOW_DEBUG
#define IFIN_MLIB_DBG1(x)  printf x 
#define IFIN_MLIB_DBG2(x)  /*printf x*/
#else
#define IFIN_MLIB_DBG1(x)  
#define IFIN_MLIB_DBG2(x)  
#endif

#if IFIN_MLIB_DEBUG
#define IFIN_MLIB_DBG(x)  printf x
#else
#define IFIN_MLIB_DBG(x)  
#endif



int16 IFIN_MLIB_Init(
                      IFIN_MLIB_Id         *pMlibId,
                      uint16               unKeyId,
                      uchar8                ucMlibType,
                      uchar8                *pucUserMemory,
                      x_IFIN_MLIB_SegInfo  *pxSegInfo,
                      uint32                uiSharedDataSize
                    ) 
{
  x_IFIN_MLIB_MgtInfo *pxMlibMgtInfo = NULL;
  x_IFIN_MLIB_SegGrpMgtInfo   *pxSegGrpMgtInfo;

  uint32       uiMlibSize = 0;
  uint32       uiMlibSegsSize = 0;
  uint32       uiMlibMgtSize = 0;
  uint16       unNumOfSegs = 0;
  uint16       unIndex = 0;
  uint16       unIndex1 = 0;
  uint32       uiSegMaxSize = 0;
  uint16       unSegNum;
  uint16       unTempSegListOffset;
  uint8        *pucTempSegAddr;
  uchar8       ucSegSizeGroups = 0;
  uchar8       *pucMlibAddr = IFIN_MLIB_NULL;
  uint16       unRetVal  = IFIN_MLIB_SUCCESS;
  int32        iSemId = 0;
  int32        iSharedDataSemId = 0;
  int32        iShmId = 0;

  do
  {

    /* Calculation of memory for all segments required by user */

    for(unIndex = 0;pxSegInfo[unIndex].unNumOfSegs != 0; unIndex++)
    {
      uiMlibSegsSize += pxSegInfo[unIndex].unNumOfSegs * 
                                pxSegInfo[unIndex].uiSegSize;

      unNumOfSegs   += pxSegInfo[unIndex].unNumOfSegs;

      #if IFIN_MLIB_PROTECT   

      if(uiSegMaxSize < pxSegInfo[unIndex].uiSegSize)
      {
         uiSegMaxSize = pxSegInfo[unIndex].uiSegSize;
      }

      #endif
    }

    if((uiMlibSegsSize ==0) && (uiSharedDataSize == 0))
    {
      unRetVal   = IFIN_MLIB_INSUFFICEINT_DATA;
      break;
    }

    ucSegSizeGroups  = unIndex;

    /* Add MLIB managemnt struct size
           each segment size group management size,
           circular buffer management size Each Segment size group   
           Segment Management size ( ACCORDING TO the secondary type)
    */

    /*In the following,"sizeof(unSegNum)" is used to identify the num of
       bytes required for storing Segment Number */

    uiMlibMgtSize = sizeof(x_IFIN_MLIB_MgtInfo)                          +
                   (sizeof(x_IFIN_MLIB_SegGrpMgtInfo) * ucSegSizeGroups) + 
                   (sizeof(unSegNum)  * unNumOfSegs)                       ;
               /* here "unSegNum" is used only for identifying num of
                    bytes required to store Segment Number */


    /* Segment Management size will depend on secondory type */
    switch((ucMlibType & 0XF0))
    { 
      case IFIN_MLIB_PTR_FEATURE:
      {
        uiMlibMgtSize += (sizeof(unSegNum)  * unNumOfSegs);

               /* here "unSegNum" is used only for identifying num of
                    bytes required to store Segment Number */
        break;
      }

      case IFIN_MLIB_PTR_OFFSET_FEATURE:
      {
        uiMlibMgtSize += (sizeof(x_IFIN_MLIB_SegMgtInfo)  * unNumOfSegs);
        break;
      }
      default :
      {
        break;
      }
    }

    #if IFIN_MLIB_PROTECT   /* seg status size -- per buffer  */

    uiMlibMgtSize += (sizeof(uchar8) * unNumOfSegs);      

    #endif

    #if IFIN_MLIB_DEBUG   /* Msg Sizes -- per buffer  */

    uiMlibMgtSize += (sizeof(uiSegMaxSize) * unNumOfSegs);
             /* here "uiSegMaxSize" is used only for identifying num of
                    bytes required to store segment size */

    #endif

    /* Total MLIB size is equal to Actual segments size +
       memory required for management + Shared data size  */

    uiMlibSize    = uiMlibSegsSize + uiMlibMgtSize + uiSharedDataSize;
 

    IFIN_MLIB_DBG1(("x_IFIN_MLIB_MgtInfo SIZE = %d \n",
                                         sizeof(x_IFIN_MLIB_MgtInfo)));
    IFIN_MLIB_DBG1(("x_IFIN_MLIB_SegGrpMgtInfo SIZE = %d \n",
                                         sizeof(x_IFIN_MLIB_SegGrpMgtInfo)));
    IFIN_MLIB_DBG1(("x_IFIN_MLIB_SegMgtInfo SIZE = %d \n",
                                         sizeof(x_IFIN_MLIB_SegMgtInfo)));
    IFIN_MLIB_DBG1(("uiMlibSegsSize SIZE = %d \n", uiMlibSegsSize));
    IFIN_MLIB_DBG1(("uiMlibSize SIZE = %d \n", uiMlibSize));
 

    /* create a semaphore  for buffer management*/

    iSemId = semget((key_t)unKeyId, 1,IPC_CREAT|IFIN_MLIB_PERMS);

    if(iSemId <0)
    {
      unRetVal  = IFIN_MLIB_OUT_OF_SEM_MEMORY;
      IFIN_MLIB_DBG1(("Error in Creating a buff Mgt semaphore= %s \n",
                                                          strerror(errno)));
      break;
    }                                                        
    semctl(iSemId,0,SETVAL,1);    /*set value 1 */

    IFIN_MLIB_DBG1(("iSemId= 0x%x \n", iSemId));




    /* create a semaphore  for data management*/

    if( uiSharedDataSize >0)
    {
      iSharedDataSemId = semget((key_t)(0XFFFF- unKeyId), 1,
                                        IPC_CREAT|IFIN_MLIB_PERMS);

      if(iSharedDataSemId <0)
      {
        /* deleting the semaphone which is already created.*/
        semctl(iSemId,0,IPC_RMID,0);    

        unRetVal  = IFIN_MLIB_OUT_OF_SEM_MEMORY;
        IFIN_MLIB_DBG1(("Error in Creating a semaphore data Mgt= %s \n",

                                                          strerror(errno)));
        break;
      }                                                        

      semctl(iSharedDataSemId,0,SETVAL,1);    /*set value 1 */
    } 
    IFIN_MLIB_DBG1(("iSharedDataSemId= 0x%x \n", iSharedDataSemId));


    IFIN_MLIB_DBG1((" MlibType                = 0x%x \n",ucMlibType));
    IFIN_MLIB_DBG1((" MlibType Primary Type   = 0x%x \n",(ucMlibType&0X0F)));
    IFIN_MLIB_DBG1((" MlibType Secondary Type = 0x%x \n",(ucMlibType&0XF0)));

    IFIN_MLIB_DBG1((" unKeyId    = %d \n",unKeyId));

    /* create the shared Memory */

    switch(ucMlibType&0x0f)
    {

      case IFIN_MLIB_USER_MEMORY :
      {
        pucMlibAddr  =  pucUserMemory;
        IFIN_MLIB_DBG1((" pucMlibAddr       = 0x%x \n",pucMlibAddr));
        break; 
      }  


      case IFIN_MLIB_DYNAMIC_MEMORY :
      {
        pucMlibAddr  = (uchar8 *)malloc((size_t)uiMlibSize);
        if( pucMlibAddr == NULL)
        {
          unRetVal   = IFIN_MLIB_OUT_OF_MEMORY;
        }
        IFIN_MLIB_DBG1((" pucMlibAddr       = 0x%x \n",pucMlibAddr));
        break; 
  
      }  


      case IFIN_MLIB_SHARED_MEMORY :
      {          
        iShmId = shmget((key_t)unKeyId,uiMlibSize,
                         IPC_CREAT|IFIN_MLIB_PERMS|IPC_EXCL); 

        if(iShmId < 0) /* memory segment */ 
        {
          IFIN_MLIB_DBG1(("MlibInit :Error in getting shared memory, %s",
                                                   strerror(errno)));
          IFIN_MLIB_DBG1(("MlibInit: Error in getting shared memory, %d",
                                                                      errno));
          if(errno == IFIN_MLIB_ERRORNO_KEY_EXISTS)
          {
            unRetVal   = IFIN_MLIB_KEY_ALREADY_EXISTS;
          }   
          else
          {
            unRetVal   = IFIN_MLIB_OUT_OF_SHM;
          }
          break;
        }
        IFIN_MLIB_DBG1((" iShmId        = 0x%x \n",iShmId));



        /*  attach it to the process*/

        pucMlibAddr = (uchar8 *)shmat(iShmId,0,0);  
        if(pucMlibAddr == IFIN_MLIB_NULL) 
        {
          shmctl(iShmId,IPC_RMID,0);    
          IFIN_MLIB_DBG1(("MlibInit: Error in attaching shared memory, %s",
                                                            strerror(errno)));
          unRetVal   = IFIN_MLIB_OUT_OF_SHM;
          break;
        }
        IFIN_MLIB_DBG1((" pucMlibAddr       = 0x%x \n",pucMlibAddr));
        break;
      }  
      default    :
      {
        unRetVal =    IFIN_MLIB_WRONG_DATA;
        break;
      } 
    }

    if(pucMlibAddr == IFIN_MLIB_NULL) 
    {
      /* deleting the semaphone and shared memory which is already created.*/
      semctl(iSemId,0,IPC_RMID,0);    
      semctl(iSharedDataSemId,0,IPC_RMID,0);    
      break;
    }


    *pMlibId                        = pucMlibAddr;

    /* Initialize the Memory chunk */

    pxMlibMgtInfo                   = (x_IFIN_MLIB_MgtInfo *)pucMlibAddr;

    pxMlibMgtInfo->ucMlibType       = ucMlibType;
    if( (ucMlibType&0X0F) == IFIN_MLIB_SHARED_MEMORY )
    {
      pxMlibMgtInfo->iShmId           = iShmId;
    }
    pxMlibMgtInfo->iSemId           = iSemId;
    pxMlibMgtInfo->iSharedDataSemId = iSharedDataSemId;
    pxMlibMgtInfo->uiSharedDataSize = uiSharedDataSize;

    #if IFIN_MLIB_PROTECT   

    pxMlibMgtInfo->unNumOfSegs      = unNumOfSegs;
    pxMlibMgtInfo->uiSegMaxSize     = uiSegMaxSize;

    #endif

    pxMlibMgtInfo->ucSegSizeGroups  = ucSegSizeGroups;




    /* Segments group management start location */

    pxMlibMgtInfo->unSegGrpMgtInfoOffset = sizeof(x_IFIN_MLIB_MgtInfo);



    /* Segments group Circular buffer management start location */ 
    unTempSegListOffset = pxMlibMgtInfo->unSegGrpMgtInfoOffset + 
                     (sizeof(x_IFIN_MLIB_SegGrpMgtInfo) * ucSegSizeGroups);


    #if IFIN_MLIB_PROTECT

      #if IFIN_MLIB_DEBUG

        /* Actual message sizes for Segments  information start location */
        pxMlibMgtInfo->unSegMsgSizesOffset = unTempSegListOffset +
                                             (sizeof(unSegNum)*unNumOfSegs);
                /* here "unSegNum" is used only for identifying num of
                    bytes required to store Segment Number */

        /* Segments Status(FREE OR NOT_FREE) information start location */ 
        pxMlibMgtInfo->unSegStatusOffset = pxMlibMgtInfo->unSegMsgSizesOffset +
                                             (sizeof(uiSegMaxSize)* unNumOfSegs);
                /* here "uiSegMaxSize" is used only for identifying num of
                    bytes required to store segment size */
      #else

        /* Segments Status(FREE OR NOT_FREE) information start location */ 
        pxMlibMgtInfo->unSegStatusOffset = unTempSegListOffset +
                                             (sizeof(unSegNum)*unNumOfSegs);
                /* here "unSegNum" is used only for identifying num of
                    bytes required to store Segment Number */

      #endif

      /* Actual Buffers location */ 
      pxMlibMgtInfo->unSegStartAddrOffset = 
                           (pxMlibMgtInfo->unSegStatusOffset + unNumOfSegs); 

    #else
      /* Actual Buffers location */ 
      pxMlibMgtInfo->unSegStartAddrOffset  = unTempSegListOffset + 
                                             (sizeof(unSegNum)*unNumOfSegs);
                /* here "unSegNum" is used only for identifying num of
                    bytes required to store Segment Number */
    #endif


    IFIN_MLIB_DBG1(("pxSegGrpMgtInfo= 0x%x\n",
                  (pucMlibAddr + pxMlibMgtInfo->unSegGrpMgtInfoOffset)));
    IFIN_MLIB_DBG1(("paunTempSegList= 0x%x\n",
                      (pucMlibAddr + unTempSegListOffset)));

    #if IFIN_MLIB_PROTECT
    IFIN_MLIB_DBG1(("paucSegStatus= 0x%x\n",
                  (pucMlibAddr + pxMlibMgtInfo->unSegStatusOffset)));
    #endif

    #if IFIN_MLIB_DEBUG
    IFIN_MLIB_DBG1(("paunSegMsgSizes= 0x%x\n",
                  (pucMlibAddr + pxMlibMgtInfo->unSegMsgSizesOffset)));
    #endif

    IFIN_MLIB_DBG1(("pucTempSegAddr= 0x%x\n",
                  (pucMlibAddr + pxMlibMgtInfo->unSegStartAddrOffset)));



    /*
     Initialization of Segments group Management structures,
                       Circular management data, 
                       Segment status data, 
                       individual segment management structures  
    */


    /* Initializing the Segments Status to IFIN_MLIB_FREE */ 

    
    #if IFIN_MLIB_PROTECT

    for( unIndex = 0; unIndex < unNumOfSegs; unIndex++)
    {
      (pucMlibAddr + pxMlibMgtInfo->unSegStatusOffset)[unIndex ] = 
                                                             IFIN_MLIB_FREE;
    }

    #endif


    pxSegGrpMgtInfo  = (x_IFIN_MLIB_SegGrpMgtInfo *)
                       (pucMlibAddr + pxMlibMgtInfo->unSegGrpMgtInfoOffset);

    pucTempSegAddr = (uint8 *)
                       (pucMlibAddr + pxMlibMgtInfo->unSegStartAddrOffset);

    for(unSegNum = 1,unIndex = 0;unIndex <ucSegSizeGroups ; unIndex++)
    {

      /* Segment Group management Strutures initialization */

      pxSegGrpMgtInfo[unIndex].uiSegSize   =
                                            pxSegInfo[unIndex].uiSegSize;

      unNumOfSegs                         = pxSegInfo[unIndex].unNumOfSegs;

      pxSegGrpMgtInfo[unIndex].unNumOfSegs    = unNumOfSegs;
 
      pxSegGrpMgtInfo[unIndex].unNumOfFreeSeg = unNumOfSegs;

      pxSegGrpMgtInfo[unIndex].unRdIndex   = 0;
      pxSegGrpMgtInfo[unIndex].unWrIndex   = 0;

      pxSegGrpMgtInfo[unIndex].unSegListOffset = unTempSegListOffset;

      #if IFIN_MLIB_DEBUG
      pxSegGrpMgtInfo[unIndex].unMaxSegsUtilized = 0;
      pxSegGrpMgtInfo[unIndex].unBF_CrossedTimes = 0;
      pxSegGrpMgtInfo[unIndex].uiMaxMsgSize = 0;
      pxSegGrpMgtInfo[unIndex].uiMinMsgSize = 0xFFFFFFFF;
 
      #endif 

      for( unIndex1 = 0; unIndex1 < unNumOfSegs; unIndex1++)
      {
        /* curcular buffer management initialisation */ 
        ((uint16 *)(pucMlibAddr + unTempSegListOffset))[unIndex1] = unSegNum;

        /* individual segment intialization */          
        switch((ucMlibType & 0XF0))
        { 
          case IFIN_MLIB_PTR_FEATURE:
          {
            *((uint16 *)pucTempSegAddr)  = unSegNum;

            pucTempSegAddr += (sizeof(unSegNum) + pxSegInfo[unIndex].uiSegSize);
                /* here "unSegNum" is used only for identifying num of
                    bytes required to store Segment Number */
            break;
          }

          case IFIN_MLIB_PTR_OFFSET_FEATURE:
          {
            ((x_IFIN_MLIB_SegMgtInfo *)pucTempSegAddr)->unSegNum = unSegNum;
            ((x_IFIN_MLIB_SegMgtInfo *)pucTempSegAddr)->ucDupCnt = 0;
            ((x_IFIN_MLIB_SegMgtInfo *)pucTempSegAddr)->uiHeadOffset = 0;
            ((x_IFIN_MLIB_SegMgtInfo *)pucTempSegAddr)->uiTailOffset = 0;

            pucTempSegAddr  += ( sizeof(x_IFIN_MLIB_SegMgtInfo) + 
                                         pxSegInfo[unIndex].uiSegSize   );
            break;
          }
          default :
          {
            break;
          }
        }

        #if IFIN_MLIB_DEBUG

        ((uint16 *)(pucMlibAddr + pxMlibMgtInfo->unSegMsgSizesOffset))
                                                            [unSegNum -1]=0;
      

        #endif  
        unSegNum++;
      }
      unTempSegListOffset += (sizeof(unSegNum) * unNumOfSegs);
                /* here "unSegNum" is used only for identifying num of
                    bytes required to store Segment Number */
    }

    /* Storing SharedData for data management start location */
    pxMlibMgtInfo->unSharedDataAddrOffset  = pucTempSegAddr - pucMlibAddr;
    IFIN_MLIB_DBG1(("pucSharedDataAddr= 0x%x\n",
                   ( pucMlibAddr +pxMlibMgtInfo->unSharedDataAddrOffset)));
   

  }while(0);

  #if IFIN_MLIB_FLOW_DEBUG

  if(pucMlibAddr == (uchar8 *)(&pxMlibMgtInfo->iShmId))
  {
    IFIN_MLIB_PrintMem(pucMlibAddr,uiMlibSize);
  }
  else 
  {
    IFIN_MLIB_PrintMem(pucMlibAddr,uiMlibSize);
    IFIN_MLIB_PrintMem((uchar8 *)&pxMlibMgtInfo->iShmId,uiMlibSize);
  }

  #endif

  return unRetVal;
}
    

/************************************************************************
*  Functon Name:
*  Description :
*  Input Values:
*  OutputValues:
*  Return Value:
*************************************************************************/


IFIN_MLIB_Id IFIN_MLIB_GetId( uint16 unKeyId)
{
  int32  iShmId = 0;
  uchar8 *pucMlibAddr;
  
  do
  {
    iShmId = shmget((key_t)unKeyId,0,IFIN_MLIB_PERMS); 

    if(iShmId < 0) /* memory segment */ 
    {
      IFIN_MLIB_DBG1(("GetMlibId :Error in getting shared memory, %s",
                                                           strerror(errno)));
      IFIN_MLIB_DBG1(("GetMlibId :Error in getting shared memory, %d",errno));
      pucMlibAddr   = (uchar8 *)IFIN_MLIB_NULL;
      break;
    }

    /*  attach it to the process*/
    pucMlibAddr = (uchar8 *)shmat(iShmId,0,0);  
    if(pucMlibAddr == IFIN_MLIB_NULL) 
    {
      printf("GetMlibId:Error in attaching shared memory, %s",strerror(errno));
      pucMlibAddr   = (uchar8 *)IFIN_MLIB_NULL;
      break;
    }
  }while(0);
  return pucMlibAddr;
}

/************************************************************************
*  Functon Name:
*  Description :
*  Input Values:
*  OutputValues:
*  Return Value:
*************************************************************************/


int16 IFIN_MLIB_GetSeg( IFIN_MLIB_Id MlibId, 
                         uint32 uiSegSize, uint16 *punSegNum)
{
  x_IFIN_MLIB_MgtInfo  *pxMlibMgtInfo;

  struct sembuf    sop;
  x_IFIN_MLIB_SegGrpMgtInfo  *pxSegGrpMgtInfo;
  x_IFIN_MLIB_SegGrpMgtInfo  *pxSegGrpMgtInfoStartAddr;

  uint8            ucIndex = 0;
  uint16           unRetVal = IFIN_MLIB_SUCCESS;

  #if IFIN_MLIB_DEBUG
  uint8            ucDbgIndex = 0;
  #endif   


  pxMlibMgtInfo             = (x_IFIN_MLIB_MgtInfo *)MlibId;

  sop.sem_num = 0;
  sop.sem_flg = SEM_UNDO;  //than or equal to 1 and

  do
  {

    #if IFIN_MLIB_PROTECT   
   
    if(uiSegSize ==0)
    {
      unRetVal    = IFIN_MLIB_ZERO_SEG_SIZE;
      *punSegNum  = 0;
      break;
    }
    if(uiSegSize > pxMlibMgtInfo->uiSegMaxSize)
    {
      unRetVal = IFIN_MLIB_CROSSED_MAX_SIZE;
      *punSegNum  = 0;
      break;
    }
 
    #endif
    pxSegGrpMgtInfoStartAddr = (x_IFIN_MLIB_SegGrpMgtInfo *)
                          (MlibId + pxMlibMgtInfo->unSegGrpMgtInfoOffset);

    for(ucIndex = 0; ucIndex < pxMlibMgtInfo->ucSegSizeGroups; ucIndex++)
    { 
      if(uiSegSize <= pxSegGrpMgtInfoStartAddr[ucIndex].uiSegSize)
      {
        break;
      }
    }        

                                
    /* Don't change the "ucIndex" value.
       the value will be continuing to further down  */ 

    /* Actual group pointer */
    pxSegGrpMgtInfo   = &pxSegGrpMgtInfoStartAddr[ucIndex];

    sop.sem_op  = -1;         //wait untill the value is greater 
    semop(pxMlibMgtInfo->iSemId,&sop,1);     //lock the semaphore
     
    #if IFIN_MLIB_DEBUG
       ucDbgIndex  = ucIndex;
    #endif   

    if(pxSegGrpMgtInfo->unNumOfFreeSeg == 0)
    {
      for(ucIndex += 1; ucIndex < pxMlibMgtInfo->ucSegSizeGroups; ucIndex++)
      {
        if(pxSegGrpMgtInfoStartAddr[ucIndex].unNumOfFreeSeg != 0)
        {
          break;
        }
      }
      if(ucIndex == pxMlibMgtInfo->ucSegSizeGroups)
      {
        unRetVal    = IFIN_MLIB_BUFFERS_EMPTY;
        *punSegNum  = 0;

        sop.sem_op  = 1;         //wait untill the value is greater
        semop(pxMlibMgtInfo->iSemId,&sop,1);     //lock the semaphore
        break;
      }
      pxSegGrpMgtInfo   = &pxSegGrpMgtInfoStartAddr[ucIndex];
    }

    pxSegGrpMgtInfo->unRdIndex = pxSegGrpMgtInfo->unRdIndex %
                                    pxSegGrpMgtInfo->unNumOfSegs;
  
    *punSegNum = ((uint16 *)(MlibId + pxSegGrpMgtInfo->unSegListOffset))
                                       [pxSegGrpMgtInfo->unRdIndex];

    IFIN_MLIB_DBG1(("pxSegGrpMgtInfo->unRdIndex = %d \n",
                                             pxSegGrpMgtInfo->unRdIndex));

    pxSegGrpMgtInfo->unRdIndex++;
    pxSegGrpMgtInfo->unNumOfFreeSeg--;


    #if IFIN_MLIB_PROTECT
     
    (MlibId + pxMlibMgtInfo->unSegStatusOffset)[*punSegNum-1] = 
                                                     IFIN_MLIB_NOT_FREE;

    #endif


    #if IFIN_MLIB_DEBUG
   
      IFIN_MLIB_GetSideUpdateDbgInfo(MlibId,ucDbgIndex,
                                     ucIndex, uiSegSize, *punSegNum);

    #endif   


    sop.sem_op  = 1;         //wait untill the value is greater 
    semop(pxMlibMgtInfo->iSemId,&sop,1);     //lock the semaphore

  }while(0);

  IFIN_MLIB_DBG1(("pxSegGrpMgtInfo->unRdIndex 2 = %d\n",
                                       pxSegGrpMgtInfo->unRdIndex));

  return unRetVal;
}

/************************************************************************
*  Functon Name:
*  Description :
*  Input Values:
*  OutputValues:
*  Return Value:
*************************************************************************/
#if IFIN_MLIB_DEBUG


void IFIN_MLIB_GetSideUpdateDbgInfo( IFIN_MLIB_Id  MlibId,
                                     uchar8        ucDbgIndex,
                                     uchar8        ucIndex,
                                     uint32        uiMsgSize,
                                     uint16        unSegNum
                                   )
{
  x_IFIN_MLIB_MgtInfo *pxMlibMgtInfo;
  x_IFIN_MLIB_SegGrpMgtInfo *pxSegGrpMgtInfo;
  x_IFIN_MLIB_SegGrpMgtInfo  *pxSegGrpMgtInfoStartAddr;

  pxMlibMgtInfo              = (x_IFIN_MLIB_MgtInfo *)MlibId;

  pxSegGrpMgtInfoStartAddr   = (x_IFIN_MLIB_SegGrpMgtInfo *)
                            (MlibId + pxMlibMgtInfo->unSegGrpMgtInfoOffset);

  pxSegGrpMgtInfo   = &pxSegGrpMgtInfoStartAddr[ucIndex];

  /* updating the buffer allocated group information */
  if(pxSegGrpMgtInfo->unMaxSegsUtilized <
         (pxSegGrpMgtInfo->unNumOfSegs - pxSegGrpMgtInfo->unNumOfFreeSeg))
  {
    pxSegGrpMgtInfo->unMaxSegsUtilized++;
  }

  /* updating the Actual buffer group information. 
    i.e. went into the other group because of non availability of bufferes*/
  if(ucDbgIndex != ucIndex)
  {      
    pxSegGrpMgtInfo   = &pxSegGrpMgtInfoStartAddr[ucDbgIndex];

    pxSegGrpMgtInfo->unBF_CrossedTimes++;

    IFIN_MLIB_DBG1((" Crossed times increased Group Number =%d\n",
                                                       ucDbgIndex));

    if(pxSegGrpMgtInfo->unMaxSegsUtilized <
       (pxSegGrpMgtInfo->unNumOfSegs + pxSegGrpMgtInfo->unBF_CrossedTimes))
    {
      IFIN_MLIB_DBG1((" MaxSU increased "));
      pxSegGrpMgtInfo->unMaxSegsUtilized++;
    }
  }

  /* Updating the Actual buffer Group information.
     pointer is updated above accordingly */

  if(pxSegGrpMgtInfo->uiMaxMsgSize < uiMsgSize )
  {
    pxSegGrpMgtInfo->uiMaxMsgSize = uiMsgSize;
  }

  if(pxSegGrpMgtInfo->uiMinMsgSize > uiMsgSize )
  {
    pxSegGrpMgtInfo->uiMinMsgSize = uiMsgSize;
  }

  /* Updating the Message size information for Segment */
  ((uint16 *)(MlibId + pxMlibMgtInfo->unSegMsgSizesOffset))[unSegNum -1] =
                                                                  uiMsgSize;
}

#endif   


/************************************************************************
*  Functon Name:
*  Description :
*  Input Values:
*  OutputValues:
*  Return Value:
*************************************************************************/


uchar8* IFIN_MLIB_GetSegAddr (IFIN_MLIB_Id MlibId, uint16 unSegNum)
{
  x_IFIN_MLIB_MgtInfo *pxMlibMgtInfo;
  x_IFIN_MLIB_SegGrpMgtInfo  *pxSegGrpMgtInfo;
  uint8               ucIndex = 0;
  uint32              uiSegMgtSize = 0;
  uchar8*             pucRetVal = IFIN_MLIB_NULL;

  pxMlibMgtInfo             = (x_IFIN_MLIB_MgtInfo *)MlibId;

  do
  {
    #if IFIN_MLIB_PROTECT

    if((unSegNum > pxMlibMgtInfo->unNumOfSegs) || (unSegNum ==0))
    {
      IFIN_MLIB_DBG1(("Wrong Segment Number  %d \n", unSegNum));
      break;
    }

    #endif

    pucRetVal = MlibId + pxMlibMgtInfo->unSegStartAddrOffset;

    switch((pxMlibMgtInfo->ucMlibType & 0XF0))
    { 
      case IFIN_MLIB_PTR_FEATURE:
      {
        uiSegMgtSize = sizeof(unSegNum);
                /* here "unSegNum" is used only for identifying num of
                    bytes required to store Segment Number */
        break;
      }
      case IFIN_MLIB_PTR_OFFSET_FEATURE:
      {
        uiSegMgtSize = sizeof(x_IFIN_MLIB_SegMgtInfo);
        break;
      }
      default :
      {
        break;
      }
    }

    pxSegGrpMgtInfo   = (x_IFIN_MLIB_SegGrpMgtInfo *)
                            (MlibId + pxMlibMgtInfo->unSegGrpMgtInfoOffset);
    for(ucIndex = 0;
         unSegNum > pxSegGrpMgtInfo[ucIndex].unNumOfSegs; ucIndex++)
    {
      pucRetVal += (pxSegGrpMgtInfo[ucIndex].unNumOfSegs *
                   (pxSegGrpMgtInfo[ucIndex].uiSegSize + uiSegMgtSize));

      unSegNum  -= pxSegGrpMgtInfo[ucIndex].unNumOfSegs;
    }

    pucRetVal   += (((unSegNum -1) * 
                     (pxSegGrpMgtInfo[ucIndex].uiSegSize +uiSegMgtSize))+
                                                          uiSegMgtSize  );
  }
  while(0);

  return pucRetVal;
}

/************************************************************************
*  Functon Name:
*  Description :
*  Input Values:
*  OutputValues:
*  Return Value:
*************************************************************************/


uint32 IFIN_MLIB_GetSegSize(IFIN_MLIB_Id MlibId, uint16 unSegNum)
{
  x_IFIN_MLIB_MgtInfo *pxMlibMgtInfo;
  x_IFIN_MLIB_SegGrpMgtInfo  *pxSegGrpMgtInfo;
  uint32       uiSegSize = 0;
  uint8         ucIndex = 0;

  pxMlibMgtInfo             = (x_IFIN_MLIB_MgtInfo *)MlibId;

  do
  {
    #if IFIN_MLIB_PROTECT

    if((unSegNum > pxMlibMgtInfo->unNumOfSegs) || (unSegNum ==0))
    {
      IFIN_MLIB_DBG1(("Wrong Segment Number  %d \n", unSegNum));
      break;
    }

    #endif

    pxSegGrpMgtInfo   = (x_IFIN_MLIB_SegGrpMgtInfo *)
                            (MlibId + pxMlibMgtInfo->unSegGrpMgtInfoOffset);
    for(ucIndex = 0;
         unSegNum > pxSegGrpMgtInfo[ucIndex].unNumOfSegs; ucIndex++)
    {
        unSegNum  -= pxSegGrpMgtInfo[ucIndex].unNumOfSegs;
    }

    uiSegSize    =  pxSegGrpMgtInfo[ucIndex].uiSegSize;

  } while(0);

  return uiSegSize;
}


/************************************************************************
*  Functon Name:
*  Description :
*  Input Values:
*  OutputValues:
*  Return Value:
*************************************************************************/

int16 IFIN_MLIB_SetSegOffset(IFIN_MLIB_Id MlibId, uint16 unSegNum, 
                              uint8 ucOffsetType,  uint32 uiOffsetValue)
{
  uchar8* pucSegAddr;  
  pucSegAddr = IFIN_MLIB_GetSegAddr(MlibId,unSegNum);

  #if IFIN_MLIB_PROTECT

  if(pucSegAddr == IFIN_MLIB_NULL)
  {
    return IFIN_MLIB_FAILURE;
  }
  #endif
  return IFIN_MLIB_SetMemOffset(MlibId,pucSegAddr,ucOffsetType,uiOffsetValue);
     
}


/************************************************************************
*  Functon Name:
*  Description :
*  Input Values:
*  OutputValues:
*  Return Value:
*************************************************************************/
int16 IFIN_MLIB_GetSegOffset(IFIN_MLIB_Id MlibId, uint16 unSegNum, 
                             uint8 ucOffsetType,  uint32* puiOffsetValue)
{
  uchar8* pucSegAddr;  
   
  pucSegAddr = IFIN_MLIB_GetSegAddr(MlibId,unSegNum);
  #if IFIN_MLIB_PROTECT

  if(pucSegAddr == IFIN_MLIB_NULL)
  {
    return IFIN_MLIB_FAILURE;
  }
  #endif

  return IFIN_MLIB_GetMemOffset(MlibId, pucSegAddr,
                                            ucOffsetType, puiOffsetValue);


}

/************************************************************************
*  Functon Name:
*  Description :
*  Input Values:
*  OutputValues:
*  Return Value:
*************************************************************************/
int16 IFIN_MLIB_DupSeg(IFIN_MLIB_Id MlibId, uint16 unSegNum)

{
  uchar8* pucSegAddr;  
   
  pucSegAddr = IFIN_MLIB_GetSegAddr(MlibId,unSegNum);

  #if IFIN_MLIB_PROTECT

  if(pucSegAddr == IFIN_MLIB_NULL)
  {
    return IFIN_MLIB_FAILURE;
  }
  #endif

  return IFIN_MLIB_DupMem(MlibId,pucSegAddr);

}



/************************************************************************
*  Functon Name:
*  Description :
*  Input Values:
*  OutputValues:
*  Return Value:
*************************************************************************/

int16 IFIN_MLIB_FreeSeg(IFIN_MLIB_Id MlibId, uint16 unSegNum)
{
  uint16              unTempSegNum;
  uint16              unRetVal = IFIN_MLIB_SUCCESS;
  uint32              uiSegMgtSize = 0;
  uint8               ucIndex = 0;
  uint8               *pucSegMgtAddr= 0;
  struct              sembuf sop;
  x_IFIN_MLIB_MgtInfo *pxMlibMgtInfo;
  x_IFIN_MLIB_SegGrpMgtInfo  *pxSegGrpMgtInfo;

  pxMlibMgtInfo             = (x_IFIN_MLIB_MgtInfo *)MlibId;


  do
  {
     
    #if IFIN_MLIB_PROTECT

    if((unSegNum > pxMlibMgtInfo->unNumOfSegs) || (unSegNum ==0))
    {
      IFIN_MLIB_DBG1(("Wrong Segment Number  %d \n", unSegNum));
      unRetVal = IFIN_MLIB_WRONG_SEG_NUMBER; 
      break;
    }
    #endif

    unTempSegNum = unSegNum;  

    switch((pxMlibMgtInfo->ucMlibType & 0XF0))
    { 
      case IFIN_MLIB_PTR_FEATURE:
      {
        uiSegMgtSize = sizeof(unSegNum);
                /* here "unSegNum" is used only for identifying num of
                    bytes required to store Segment Number */
        break;
      }
      case IFIN_MLIB_PTR_OFFSET_FEATURE:
      {
        uiSegMgtSize = sizeof(x_IFIN_MLIB_SegMgtInfo);
        break;
      }
      default :
      {
        break;
      }
    }

    pucSegMgtAddr  = MlibId + pxMlibMgtInfo->unSegStartAddrOffset;

    pxSegGrpMgtInfo   = (x_IFIN_MLIB_SegGrpMgtInfo *)
                            (MlibId + pxMlibMgtInfo->unSegGrpMgtInfoOffset);

    for(ucIndex = 0;
         unTempSegNum > pxSegGrpMgtInfo[ucIndex].unNumOfSegs; ucIndex++)
    {
      pucSegMgtAddr += ( pxSegGrpMgtInfo[ucIndex].unNumOfSegs *
                       ( pxSegGrpMgtInfo[ucIndex].uiSegSize + uiSegMgtSize));

      unTempSegNum  -= pxSegGrpMgtInfo[ucIndex].unNumOfSegs;

    }
    pxSegGrpMgtInfo   = &pxSegGrpMgtInfo[ucIndex];

    pucSegMgtAddr   += ((unTempSegNum -1) * 
                        (pxSegGrpMgtInfo->uiSegSize +uiSegMgtSize));

    sop.sem_num = 0;
    sop.sem_op = -1;         /* wait untill the value is greater */
    sop.sem_flg = SEM_UNDO;  /* than or equal to 1 and  */
    semop(pxMlibMgtInfo->iSemId,&sop,1);     /* lock the semaphore*/

    if((pxMlibMgtInfo->ucMlibType & 0XF0) == IFIN_MLIB_PTR_OFFSET_FEATURE)
    {
      if(((x_IFIN_MLIB_SegMgtInfo *)pucSegMgtAddr)->ucDupCnt != 0)
      {
        ((x_IFIN_MLIB_SegMgtInfo *)pucSegMgtAddr)->ucDupCnt--;
        IFIN_MLIB_DBG1(("Segment Dup count Decresed by 1 \n"));

        sop.sem_op = 1;         
        semop(pxMlibMgtInfo->iSemId,&sop,1);     /* Unlock the semaphore*/
        break;
      }
    }

    #if IFIN_MLIB_PROTECT
    if((MlibId + pxMlibMgtInfo->unSegStatusOffset)[unSegNum-1] == 
                                                          IFIN_MLIB_FREE)
    {
      IFIN_MLIB_DBG1(("Segment is already freed  %d \n", unSegNum));
      unRetVal = IFIN_MLIB_SEG_IS_ALREADY_FREED; 
      sop.sem_op = 1;         
      semop(pxMlibMgtInfo->iSemId,&sop,1);     /* Unlock the semaphore*/
      break;
    }

    (MlibId + pxMlibMgtInfo->unSegStatusOffset)[unSegNum-1] = IFIN_MLIB_FREE;

    #endif

    pxSegGrpMgtInfo->unWrIndex  = pxSegGrpMgtInfo->unWrIndex  %
                                      pxSegGrpMgtInfo->unNumOfSegs;
    
    ((uint16 *)(MlibId + pxSegGrpMgtInfo->unSegListOffset))
                                 [pxSegGrpMgtInfo->unWrIndex] = unSegNum;    

    IFIN_MLIB_DBG1(("pxSegGrpMgtInfo->unWrIndex = %d \n",
                                           pxSegGrpMgtInfo->unWrIndex));

    pxSegGrpMgtInfo->unWrIndex++;
    pxSegGrpMgtInfo->unNumOfFreeSeg++;

    #if IFIN_MLIB_DEBUG

    IFIN_MLIB_FreeSideUpdateDbgInfo(MlibId,ucIndex, unSegNum);

    #endif

    sop.sem_op  = 1;         
    semop(pxMlibMgtInfo->iSemId,&sop,1);     /* unlock the semaphore */

  }while(0);

    IFIN_MLIB_DBG1(("pxSegGrpMgtInfo->unWrIndex = %d \n",
                                           pxSegGrpMgtInfo->unWrIndex));

  return unRetVal;
}

#if IFIN_MLIB_DEBUG
/************************************************************************
*  Functon Name:
*  Description :
*  Input Values:
*  OutputValues:
*  Return Value:
*************************************************************************/


void IFIN_MLIB_FreeSideUpdateDbgInfo( IFIN_MLIB_Id       MlibId,
                                     uint8               ucGrpNum,
                                     uint16              unSegNum
                                   )
{
  uint8    ucTempGrpNum = 0;
  uint32   *pauiSegMsgSizes;
  x_IFIN_MLIB_SegGrpMgtInfo  *pxSegGrpMgtInfo;
  x_IFIN_MLIB_MgtInfo *pxMlibMgtInfo;

  pxMlibMgtInfo             = (x_IFIN_MLIB_MgtInfo *)MlibId;

  IFIN_MLIB_DBG1(("IFIN_MLIB_FreeSideUpdateDbgInfo Entered  \n"));
 
  pxSegGrpMgtInfo   = (x_IFIN_MLIB_SegGrpMgtInfo *)
                            (MlibId + pxMlibMgtInfo->unSegGrpMgtInfoOffset);

  pauiSegMsgSizes = (uint32 *)(MlibId + pxMlibMgtInfo->unSegMsgSizesOffset);

  for(ucTempGrpNum = ucGrpNum; ucTempGrpNum > 0; ucTempGrpNum--)
  {
    if(pauiSegMsgSizes[unSegNum-1]>(pxSegGrpMgtInfo[ucTempGrpNum-1].uiSegSize))
    {
      break;
    }
  }
  if(ucTempGrpNum != ucGrpNum)
  { 
    IFIN_MLIB_DBG1(("Crossed times decreased Group Number =%d, MsgSize = %d\n",
                  ucTempGrpNum,pauiSegMsgSizes[unSegNum]));
    pxSegGrpMgtInfo[ucTempGrpNum].unBF_CrossedTimes--;
  }
  return;
}



#endif


/************************************************************************
*  Functon Name:
*  Description :
*  Input Values:
*  OutputValues:
*  Return Value:
*************************************************************************/


uchar8* IFIN_MLIB_AllocMem( IFIN_MLIB_Id MlibId,uint32 uiSegSize )
{
  uint16     unSegNum;
  uchar8*    pucRetVal = IFIN_MLIB_NULL;

  switch((((x_IFIN_MLIB_MgtInfo *)MlibId)->ucMlibType & 0XF0))
  { 
    case IFIN_MLIB_PTR_FEATURE:
    case IFIN_MLIB_PTR_OFFSET_FEATURE:
    {
      if(IFIN_MLIB_GetSeg(MlibId,uiSegSize,&unSegNum) == IFIN_MLIB_SUCCESS)
      {
        IFIN_MLIB_DBG1(("IFIN_MLIB_AllocMem : unSegNum = %d\n",unSegNum));
        IFIN_MLIB_DBG1(("IFIN_MLIB_AllocMem : Calling GetSegAddr \n"));
        pucRetVal = IFIN_MLIB_GetSegAddr(MlibId,unSegNum);

        break;
      }
    }
    default :
    {
      break;
    }
  }
  return pucRetVal; 
}


/************************************************************************
*  Functon Name:
*  Description :
*  Input Values:
*  OutputValues:
*  Return Value:
*************************************************************************/


int16 IFIN_MLIB_GetSegNumOfAddr(IFIN_MLIB_Id MlibId,uchar8 *pucSegAddr)
{
  uint16 unSegNum = 0;

  do
  {

    #if IFIN_MLIB_PROTECT

    if(pucSegAddr == IFIN_MLIB_NULL)
    {
      break;
    }
      
    #endif

    switch((((x_IFIN_MLIB_MgtInfo *)MlibId)->ucMlibType & 0XF0))
    {
      case IFIN_MLIB_PTR_FEATURE:
      {

        unSegNum =  *((uint16 *)(pucSegAddr- sizeof(unSegNum)));
                /* here "unSegNum" is used only for identifying num of
                    bytes required to store Segment Number */
         break;
      }
      case IFIN_MLIB_PTR_OFFSET_FEATURE:
      {
        unSegNum = ((x_IFIN_MLIB_SegMgtInfo *)
                   (pucSegAddr- sizeof(x_IFIN_MLIB_SegMgtInfo)))->unSegNum;
         break;
      }
      default :
      {
         break;
      }
    }
  }while(0);
  return unSegNum;
}

/************************************************************************
*  Functon Name:
*  Description :
*  Input Values:
*  OutputValues:
*  Return Value:
*************************************************************************/
uint32 IFIN_MLIB_GetMemSize(IFIN_MLIB_Id MlibId, uchar8 *pucSegAddr)
{
  uint16 unSegNum = 0;
  #if IFIN_MLIB_PROTECT

  if(pucSegAddr == IFIN_MLIB_NULL)
  {
    return 0;
  }
      
  #endif

  unSegNum  = IFIN_MLIB_GetSegNumOfAddr(MlibId,pucSegAddr);
  if(unSegNum != 0)
  { 
    return IFIN_MLIB_GetSegSize(MlibId,unSegNum);
  }
  else
  {
    return 0;
  }
}

/************************************************************************
*  Functon Name:
*  Description :
*  Input Values:
*  OutputValues:
*  Return Value:
*************************************************************************/
int16 IFIN_MLIB_SetMemOffset(IFIN_MLIB_Id MlibId, uchar8* pucSegAddr, 
                              uint8 ucOffsetType,  uint32 uiOffsetValue)
{

  #if IFIN_MLIB_PROTECT

  if(pucSegAddr == IFIN_MLIB_NULL)
  {
    return IFIN_MLIB_FAILURE;
  }

  #endif


  if((((x_IFIN_MLIB_MgtInfo *)MlibId)->ucMlibType & 0XF0) 
                                   == IFIN_MLIB_PTR_OFFSET_FEATURE)
  { 
    if(ucOffsetType == IFIN_MLIB_HEAD_OFFSET )
    {
      ((x_IFIN_MLIB_SegMgtInfo *)
      (pucSegAddr- sizeof(x_IFIN_MLIB_SegMgtInfo)))->uiHeadOffset
                                                      = uiOffsetValue;
    }
    else

    {
      ((x_IFIN_MLIB_SegMgtInfo *)
      (pucSegAddr- sizeof(x_IFIN_MLIB_SegMgtInfo)))->uiTailOffset
                                                      = uiOffsetValue;
    }
    return IFIN_MLIB_SUCCESS;
  }
  return IFIN_MLIB_INVALID;
}

/************************************************************************
*  Functon Name:
*  Description :
*  Input Values:
*  OutputValues:
*  Return Value:
*************************************************************************/

int16 IFIN_MLIB_GetMemOffset(IFIN_MLIB_Id MlibId, uchar8* pucSegAddr,
                              uint8 ucOffsetType,  uint32* puiOffsetValue)
{

  #if IFIN_MLIB_PROTECT

  if(pucSegAddr == IFIN_MLIB_NULL)
  {
    return IFIN_MLIB_FAILURE;
  }

  #endif

  if((((x_IFIN_MLIB_MgtInfo *)MlibId)->ucMlibType & 0XF0) 
                                   == IFIN_MLIB_PTR_OFFSET_FEATURE)
  { 
    if(ucOffsetType == IFIN_MLIB_HEAD_OFFSET )
    {
      *puiOffsetValue  = ((x_IFIN_MLIB_SegMgtInfo *)
                 (pucSegAddr- sizeof(x_IFIN_MLIB_SegMgtInfo)))->uiHeadOffset ;
    }
    else
    {
      *puiOffsetValue  = ((x_IFIN_MLIB_SegMgtInfo *)
                 (pucSegAddr- sizeof(x_IFIN_MLIB_SegMgtInfo)))->uiTailOffset ;
    }
    return IFIN_MLIB_SUCCESS;
  }
  return IFIN_MLIB_INVALID;
}

/************************************************************************
*  Functon Name:
*  Description :
*  Input Values:
*  OutputValues:
*  Return Value:
*************************************************************************/
int16 IFIN_MLIB_DupMem(IFIN_MLIB_Id MlibId, uchar8* pucSegAddr)

{
  #if IFIN_MLIB_PROTECT

  if(pucSegAddr == IFIN_MLIB_NULL)
  {
    return IFIN_MLIB_FAILURE;
  }

  #endif

  if((((x_IFIN_MLIB_MgtInfo *)MlibId)->ucMlibType & 0XF0) 
                                   == IFIN_MLIB_PTR_OFFSET_FEATURE)
  { 
    ((x_IFIN_MLIB_SegMgtInfo *)
      (pucSegAddr- sizeof(x_IFIN_MLIB_SegMgtInfo)))->ucDupCnt += 1;

    return IFIN_MLIB_SUCCESS;
  }
  return IFIN_MLIB_INVALID;
}


/************************************************************************
*  Functon Name:
*  Description :
*  Input Values:
*  OutputValues:
*  Return Value:
*************************************************************************/


int16 IFIN_MLIB_FreeMem(IFIN_MLIB_Id MlibId,uchar8 *pucSegAddr)
{
  uint16     unSegNum;

  #if IFIN_MLIB_PROTECT

  if(pucSegAddr == IFIN_MLIB_NULL)
  {
    return IFIN_MLIB_FAILURE;
  }

  #endif

  switch((((x_IFIN_MLIB_MgtInfo *)MlibId)->ucMlibType & 0XF0))
  { 
    case IFIN_MLIB_PTR_FEATURE:
    case IFIN_MLIB_PTR_OFFSET_FEATURE:
    {
      unSegNum = IFIN_MLIB_GetSegNumOfAddr(MlibId,pucSegAddr);
      if(unSegNum != 0)
      { 
        return IFIN_MLIB_FreeSeg(MlibId,unSegNum);
      }
      else
      {
        return IFIN_MLIB_FAILURE;
      }
    }
    default :
    {
      break;
    }
  }
  return IFIN_MLIB_INVALID;
}


/************************************************************************
*  Functon Name:
*  Description :
*  Input Values:
*  OutputValues:
*  Return Value:
*************************************************************************/

uchar8* IFIN_MLIB_LockShm(IFIN_MLIB_Id MlibId, uint16 unWaitNum)
{
  struct       sembuf sop;

  sop.sem_num = 0;
  sop.sem_op = -1;         /* wait untill the value is greater */
                             /* than or equal to 1 and  */   

  switch(unWaitNum)
  {
    case IFIN_MLIB_NO_WAIT:
    {
      sop.sem_flg = IPC_NOWAIT;
      break;
    }
    case IFIN_MLIB_WAIT_FOREVER:
    {
      sop.sem_flg = SEM_UNDO;
      break;
    }
    default :
    {
      sop.sem_flg = SEM_UNDO; // it doesn't provide feature of waiting for
                              // Given milli seconds    
      break;
    }
  }

  semop(((x_IFIN_MLIB_MgtInfo *)MlibId)->iSharedDataSemId,&sop,1); 
                                             /* lock the semaphore*/

  return (MlibId +((x_IFIN_MLIB_MgtInfo *)MlibId)->unSharedDataAddrOffset);
}
 


/************************************************************************
*  Functon Name:
*  Description :
*  Input Values:
*  OutputValues:
*  Return Value:
*************************************************************************/

int16 IFIN_MLIB_UnlockShm(IFIN_MLIB_Id MlibId)
{
  struct       sembuf sop;

  sop.sem_num = 0;
  sop.sem_op =  1;         
  sop.sem_flg = SEM_UNDO;  
  semop(((x_IFIN_MLIB_MgtInfo *)MlibId)->iSharedDataSemId,&sop,1); 
                                              /* unlock the semaphore*/
  return IFIN_MLIB_SUCCESS;
}
 


/************************************************************************
*  Functon Name:
*  Description : This function is not protected. So, user shall take care
                 It shall be used only once.
*  Input Values:
*  OutputValues:
*  Return Value:
*************************************************************************/


int16 IFIN_MLIB_Free(IFIN_MLIB_Id MlibId)
{
  uint16 unRetVal = IFIN_MLIB_SUCCESS;
  printf(" IFIN_MLIB_Free Entered\n");

  do
  {
    unRetVal = semctl(((x_IFIN_MLIB_MgtInfo *)MlibId)->iSemId,0,IPC_RMID,0);    
    if(unRetVal != 0)
    {
      break;
    }                                                        

    if(((x_IFIN_MLIB_MgtInfo *)MlibId)->uiSharedDataSize !=0 )
    {
      unRetVal = semctl(((x_IFIN_MLIB_MgtInfo *)MlibId)->iSharedDataSemId,
                                                               0,IPC_RMID,0);
      if(unRetVal != 0)
      {
        break;
      }                                                        
    }

    switch(((x_IFIN_MLIB_MgtInfo *)MlibId)->ucMlibType & 0x0f)
    {
      case IFIN_MLIB_USER_MEMORY :
      {
        break;
      }  

      case IFIN_MLIB_DYNAMIC_MEMORY :
      {
        free((void *)MlibId);
        break;
      }  
 
      case IFIN_MLIB_SHARED_MEMORY :
      {          
        unRetVal = shmctl(((x_IFIN_MLIB_MgtInfo *)MlibId)->iShmId,IPC_RMID,0);    
        break;
      }  
      default    :
      {
        unRetVal =    IFIN_MLIB_WRONG_DATA;
        break;
      } 
    }

  }while(0);
  return unRetVal;
}


#if IFIN_MLIB_DEBUG

void IFIN_MLIB_DbgInfo(IFIN_MLIB_Id MlibId)
{

  x_IFIN_MLIB_MgtInfo *pxMlibMgtInfo;
  uint16            unIndex = 0;
  uint32            uiPrintVal= 0;
  x_IFIN_MLIB_SegGrpMgtInfo  *pxSegGrpMgtInfo;


  pxMlibMgtInfo             = (x_IFIN_MLIB_MgtInfo *)MlibId;

 
  IFIN_MLIB_DBG(("\n"));

  IFIN_MLIB_DBG(("******************************************************\n"));
  IFIN_MLIB_DBG(("***          Debug Information Starts here         ***\n"));
  IFIN_MLIB_DBG(("******************************************************\n"));

  IFIN_MLIB_DBG(("\n"));
  IFIN_MLIB_DBG(("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n"));
  IFIN_MLIB_DBG((" Memory Chunk Type is :\t"));

  switch((pxMlibMgtInfo->ucMlibType & 0X0F))
  {
    case IFIN_MLIB_USER_MEMORY:
    {
      IFIN_MLIB_DBG(("IFIN_MLIB_USER_MEMORY & \n"));
      break;  
    }
       
    case IFIN_MLIB_SHARED_MEMORY:
    {
      IFIN_MLIB_DBG((" IFIN_MLIB_SHARED_MEMORY & \n"));
      break;  
    }

    case IFIN_MLIB_DYNAMIC_MEMORY:
    {
      IFIN_MLIB_DBG((" IFIN_MLIB_DYNAMIC_MEMORY & \n"));
      break;  
    }
    default:
    {
      break;
    }
  }
  IFIN_MLIB_DBG(("                       \t"));
  switch((pxMlibMgtInfo->ucMlibType & 0XF0))
  { 
    case IFIN_MLIB_PTR_FEATURE:
    {
      IFIN_MLIB_DBG(("IFIN_MLIB_PTR_FEATURE \n"));
      break;  
    }
    case IFIN_MLIB_PTR_OFFSET_FEATURE:
    {
      IFIN_MLIB_DBG(("IFIN_MLIB_PTR_OFFSET_FEATURE \n"));
      break;  
    }
    default :
    {
      break;
    }
  }
  IFIN_MLIB_DBG(("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"));

  IFIN_MLIB_DBG(("\n"));

  IFIN_MLIB_DBG(("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n "));
  IFIN_MLIB_DBG(("SS     = Segment Size\n "));
  IFIN_MLIB_DBG(("NB     = Number Of Buffers allocated\n "));
  IFIN_MLIB_DBG(("FreeB  = Number Of Free Buffers Now\n "));
  IFIN_MLIB_DBG(("MaxBU  = Maximum Number Of Bufferss Utilized\n "));
  IFIN_MLIB_DBG(("MaxES  = Maximum Number Of Extra Segments used \n "));
  IFIN_MLIB_DBG(("MiNMS  = Minimum message size used in this group\n "));
  IFIN_MLIB_DBG(("MaxMS  = Maximum message size used in this group\n "));
  IFIN_MLIB_DBG(("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"));


  IFIN_MLIB_DBG(("-------------------------------------------------------"));
  IFIN_MLIB_DBG(("-----\n"));
  IFIN_MLIB_DBG(("    SS    |  NB  | FreeB| MaxBU|"));
  IFIN_MLIB_DBG((" MaxES|  MinMS   |  MaxMS   |\n"));
  IFIN_MLIB_DBG(("-------------------------------------------------------"));
  IFIN_MLIB_DBG(("-----\n"));
  IFIN_MLIB_DBG(("\n"));

  pxSegGrpMgtInfo   = (x_IFIN_MLIB_SegGrpMgtInfo *)
                            (MlibId + pxMlibMgtInfo->unSegGrpMgtInfoOffset);


  for(unIndex = 0;unIndex <pxMlibMgtInfo->ucSegSizeGroups ; unIndex++)
  {
    uiPrintVal  = pxSegGrpMgtInfo[unIndex].uiSegSize;
    IFIN_MLIB_DBG(("%10u| ",uiPrintVal));

    uiPrintVal  = pxSegGrpMgtInfo[unIndex].unNumOfSegs;
    IFIN_MLIB_DBG(("%5u| ",uiPrintVal));

    uiPrintVal  = pxSegGrpMgtInfo[unIndex].unNumOfFreeSeg;
    IFIN_MLIB_DBG(("%5u| ",uiPrintVal));

    if(pxSegGrpMgtInfo[unIndex].unMaxSegsUtilized <
                   pxSegGrpMgtInfo[unIndex].unNumOfSegs )
    {
      uiPrintVal  = pxSegGrpMgtInfo[unIndex].unMaxSegsUtilized;
      IFIN_MLIB_DBG(("%5u| ",uiPrintVal));

      uiPrintVal  = 0;
      IFIN_MLIB_DBG(("%5u|",uiPrintVal));
    }
    else
    {
      uiPrintVal  = pxSegGrpMgtInfo[unIndex].unNumOfSegs;
      IFIN_MLIB_DBG(("%5u| ",uiPrintVal));

      uiPrintVal  = pxSegGrpMgtInfo[unIndex].unMaxSegsUtilized
                    -  pxSegGrpMgtInfo[unIndex].unNumOfSegs;
      IFIN_MLIB_DBG(("%5u|",uiPrintVal));
    }

    uiPrintVal  = pxSegGrpMgtInfo[unIndex].uiMinMsgSize;
    IFIN_MLIB_DBG(("%10u|",uiPrintVal));

    uiPrintVal  = pxSegGrpMgtInfo[unIndex].uiMaxMsgSize;
    IFIN_MLIB_DBG(("%10u|",uiPrintVal));

    IFIN_MLIB_DBG(("\n"));
  }

  IFIN_MLIB_DBG(("\n"));
  IFIN_MLIB_DBG(("\n"));
  IFIN_MLIB_DBG(("\n"));
  IFIN_MLIB_DBG(("******************************************************\n"));
  IFIN_MLIB_DBG(("***          Debug Information Ends here         ***\n"));
  IFIN_MLIB_DBG(("******************************************************\n"));
}    


#endif   

#if IFIN_MLIB_FLOW_DEBUG

void IFIN_MLIB_PrintMem(uchar8 *pucAddr, uint32 uiSize)
{
  uint32 uiIndex;

  if((((uint32)pucAddr)%16) != 0)
  {
    IFIN_MLIB_DBG2(("\n 0x%x  : ",(pucAddr - ((uint32)pucAddr)%16)));
    for(uiIndex = ((uint32)pucAddr)%16; uiIndex >0 ; uiIndex --)  
    {
      IFIN_MLIB_DBG2(("      "));
    }
  }

  for(;uiSize > 0; uiSize--,pucAddr++)
  {
    if((((uint32)pucAddr) % 16) == 0)
    {
      IFIN_MLIB_DBG2(("\n 0x%x  : ",pucAddr));
    }
    if(*pucAddr >0xf)
    {
      IFIN_MLIB_DBG2((" 0x%x ",*pucAddr));
    }
    else
    {
      IFIN_MLIB_DBG2((" 0x0%x ",*pucAddr));
    }
  }
  IFIN_MLIB_DBG2(("\n "));
  return; 
}  


#endif   
