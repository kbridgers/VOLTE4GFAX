#ifndef IFX_DEBUG_H
#define IFX_DEBUG_H

/*
	Debug Levels:
	0:	No debugging messages
	1:	Only critical errors: could be used on customer systems
	2:	Critical and recoverable errors and warnings
	3:	Errors and data flow information
	4:	Errors, data and control flow
*/

#ifndef DEBUG_LEVEL
#define DEBUG_LEVEL	1
#endif

/*
	You must define IFX_MI : for Module Initials to be prepended to
	the debug messages before including this file
	Eg:	#define IFX_MI	"CM"
*/

#ifndef IFX_MI
#error IFX_MI - Module Initials - must be defined
#endif

#ifndef g_IFX_DBG1_Messages
#error g_IFX_DBG1_Messages must be defined to the modules message list
#endif

/*
	Note: Use without the A suffix to pass only a format string
	Use with A suffix to pass varargs in addition to format string */
/*	Do not append newlines. This allows flexibility for future use */
/* define DBG_X in makefile while compiling a file to enable only
	for that file. If DBG_X is already defined, these macros won't
	change it */

/*
	Level 1 is a special case: it should be left on customer systems to aid
	debugging of critical errors.
	Multi-lingual support is possible for these messages.
	Module initials are not used for level 1 messages, since they might be
	customer visible.
*/

#if (DEBUG_LEVEL >= 1 && !defined (DBG_1))
#define DBG_1(a)		{printf (g_IFX_DBG1_Messages[a]);}
#define DBG_1A(a, ...)	{printf (g_IFX_DBG1_Messages[a], __VA_ARGS__);}
#endif

#if (DEBUG_LEVEL >= 2 && !defined (DBG_2))
#define DBG_2(a)		{printf (IFX_MI ":" a "\n");}
#define DBG_2A(a, ...)	{printf (IFX_MI ":" a "\n", __VA_ARGS__);}
#endif

#if (DEBUG_LEVEL >= 3 && !defined (DBG_3))
#define DBG_3(a)		{printf (IFX_MI ":" a "\n");}
#define DBG_3A(a, ...)	{printf (IFX_MI ":" a "\n", __VA_ARGS__);}
#endif

#if (DEBUG_LEVEL >= 4 && !defined (DBG_4))
#define DBG_4(a)		{printf (IFX_MI ":" a "\n");}
#define DBG_4A(a, ...)	{printf (IFX_MI ":" a "\n", __VA_ARGS__);}
#endif

#if (!defined DBG_1)
#define DBG_1(a)
#define DBG_1A(a, ...)
#endif

#if (!defined DBG_2)
#define DBG_2(a)
#define DBG_2A(a, ...)
#endif

#if (!defined DBG_3)
#define DBG_3(a)
#define DBG_3A(a, ...)
#endif

#if (!defined DBG_4)
#define DBG_4(a)
#define DBG_4A(a, ...)
#endif

#endif /* ! IFX_DEBUG_H */
