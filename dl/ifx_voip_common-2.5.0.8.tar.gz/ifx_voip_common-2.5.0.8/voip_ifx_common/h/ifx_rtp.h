/**************************************************************************
 **   FILE NAME       : ifx_rtp.h
 **   PROJECT         : RTP/RTCP
 **   MODULES         : Common module for RTP/RTCP
 **   SRC VERSION     : V0.1
 **   DATE            : 09-02-2004
 **   AUTHOR          : Hari
 **   DESCRIPTION     :
 **   FUNCTIONS       :
 **   COMPILER         : MIPS 4KC cross compiler
 **   REFERENCE        :
 **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_RTP_H__
#define __IFX_RTP_H__


#define	IFX_RTP_FAIL       -1
#define	IFX_RTP_SUCCESS    0

#ifdef IIP
#define IFX_RTP_MAX_SESSIONS 2
#define IFX_RTP_MAX_CONNS   2
#endif
#if defined(ATA) || defined(AMAZON)
#define IFX_RTP_MAX_SESSIONS 4
#define IFX_RTP_MAX_CONNS   4
#endif


#ifdef IPV4
   #define 	IFX_RTP_IP_ADDR_LEN  	16
#endif /* IPV4 */

#ifdef IPV6
   #define 	IFX_RTP_IP_ADDR_LEN    256
#endif /* IPV6 */


/* Maximum Text length for SDES */
#define IFX_RTCP_SDES_TEXT_LEN      255

/* Enum Constants */

/* Message req from UA/internal RTCP info */
typedef enum
{
   IFX_RTP_OPEN_CONN_REQ,
   IFX_RTP_MODIFY_CONN_REQ,
   IFX_RTP_CLOSE_CONN_REQ,
   IFX_RTP_ENABLE_CONF_REQ,
   IFX_RTP_DISABLE_CONF_REQ,
   IFX_RTP_SHUT_DOWN_REQ
} e_IFX_RTP_SsMsg;

/* Message response or error or optionally RTCP pkt to the UA */
typedef enum
{
   IFX_RTP_OPEN_CONN_RES,
   IFX_RTP_OPEN_CONN_ERR_RES,
   IFX_RTP_MODIFY_CONN_RES,
   IFX_RTP_MODIFY_CONN_ERR_RES,
   IFX_RTP_CLOSE_CONN_RES,
   IFX_RTP_CLOSE_CONN_IND,
   IFX_RTP_CLOSE_CONN_ERR_RES,
   IFX_RTP_RTCP_PKT,
   IFX_RTP_ENABLE_CONF_RES,
   IFX_RTP_ENABLE_CONF_ERR_RES,
   IFX_RTP_DISABLE_CONF_RES,
   IFX_RTP_DISABLE_CONF_ERR_RES
} e_IFX_RTP_RtpMsg;

/* Error types */
typedef enum
{
   IFX_RTP_NO_ERR = 0,
   IFX_RTP_SOCK_ERR,
   IFX_RTCP_SOCK_ERR,
   IFX_RTP_SOCK_CLOSE_ERR,
   IFX_RTP_NW_SEND_ERR,
   IFX_RTP_RX_FIFO_ERR,
   IFX_RTP_FIFO_READ_ERR,
   IFX_RTP_TX_FIFO_ERR,
   IFX_RTP_SELECT_ERR ,

   IFX_RTP_RX_NO_PKT = 9,
   IFX_RTCP_RX_NO_PKT,
   IFX_RTP_DEVICE_WRT_FAIL,
   IFX_RTP_DEVICE_READ_FAIL,
   IFX_RTP_INVALID_DSP_PKT,
   IFX_RTP_NO_FD_SET,
   IFX_RTP_INVALID_PKT,
   IFX_RTCP_INVALID_PKT = 16,
   IFX_RTP_INVALID_SESS_ID,
   IFX_RTP_SESS_DB_FAIL,
   IFX_RTP_INVALID_CHANNEL,
   IFX_RTP_CHANNEL_BUSY,
   IFX_RTP_INVALID_CONN_ID,
   IFX_RTP_CONN_DUP = 22,
   IFX_RTP_OPEN_CONN_DB_FAIL,
   IFX_RTP_PT_DB_FAIL,
   IFX_RTP_SDES_DB_FAIL,
   IFX_RTP_REG_REP_DB_FAIL,
   IFX_RTP_MALLOC_ERR = 27,
   IFX_RTP_FREE_ERR,
   IFX_RTP_INVALID_REQ,
   IFX_RTP_INV_VER ,
   IFX_RTP_INV_PAD ,
   IFX_RTP_INV_PKT_TYPE = 32,
   IFX_RTP_INV_PKT_LEN,
   IFX_RTP_INV_CUM_PKT_LEN,
   IFX_RTP_INV_PKT,
   IFX_RTP_INV_SEC_PKT_LEN,
   IFX_RTP_ENC_ERROR = 37,
   IFX_RTP_ALLOC_CODER_FAIL,
   IFX_RTP_DEALLOC_CODER_FAIL,
   IFX_RTP_MODIFY_CODER_FAIL,
   IFX_RTP_ZERO_TX,
   IFX_RTP_REDUNDANT_REQ = 42,
   IFX_RTP_IPC_ERR,
   IFX_RTP_CONF_BUSY,
   IFX_RTP_INVALID_PARAMS,
   IFX_RTP_PLI_START_FAIL,
   IFX_RTP_PLI_MODIFY_FAIL,
   IFX_RTP_PLI_CLOSE_FAIL,
   IFX_RTP_PLI_EN_MIXING_FAIL,
	IFX_RTP_OPEN_DEVICE_FAIL,
	IFX_RTP_START_SRTP_SESS_FAIL,
	IFX_RTP_INIT_KEY_TRANSFER_FAIL

} e_IFX_RTP_ErrType;

#if 0
/*	Data Structures */
/*	Sender Source Description */

typedef struct
{
   /* Canonical Name */
   /* Better to use static allocations for each of these variables */
   char8        acCanName[IFX_RTCP_SDES_TEXT_LEN];
   /* Name */
   char8        acName[IFX_RTCP_SDES_TEXT_LEN];
   /* Email */
   char8        acEmail[IFX_RTCP_SDES_TEXT_LEN];
   /* Phone */
   char8        acPhone[IFX_RTCP_SDES_TEXT_LEN];
   /* Location */
   char8        acLoc[IFX_RTCP_SDES_TEXT_LEN];
   /* Application Tool Name */
   char8        acAppTool[IFX_RTCP_SDES_TEXT_LEN];
   /* Note */
   char8        acNote[IFX_RTCP_SDES_TEXT_LEN];
   /* Note */
   char8        acPriv[IFX_RTCP_SDES_TEXT_LEN];

} x_IFX_RTCP_SessionDescItems;
#endif

typedef struct
{
   /* This shall be any value between 0 and 16 */
   char8   ucScalingFactor;

   uint16  unInitialSize;
   uint16  unMaxSize;
   uint16  unMinSize;

} x_IFX_RTP_JbConfig;

/* Codec Info */
#define IFX_RTP_MAX_CODECS              IFX_MAX_CODECS 
#define IFX_RTP_PAYLOAD_TYPE_G711U      0
#define IFX_RTP_PAYLOAD_TYPE_G711A      8
#define IFX_RTP_PAYLOAD_TYPE_G722_64    9
#define IFX_RTP_PAYLOAD_TYPE_G727       4
#define IFX_RTP_PAYLOAD_TYPE_G729_8     18

/* Dynamic Payload Type for Tx DTMF Events */

#define IFX_RTP_PAYLOAD_TYPE_DTMF       96

typedef struct
{
   uchar8 ucNoOfCodecs;
   /* aucLocalCodec will contain the local identification for the codec
    * Local identification is how the codec is identified by the DSP
    * E.g., for G.723, LocalCodec Value will be one of G.723_53 or G.723_63
    * IanaCodec Value will be 4
    */
   uint32 auiLocalCodec[IFX_RTP_MAX_CODECS];
   uchar8 aucIanaCodec[IFX_RTP_MAX_CODECS];
} x_IFX_RTP_CodecList;


/* x_IFX_RTP_OpenConnMsg is used to create a session and open a 
 * connection for the session.
 */
typedef struct
{
   /* Options for Configuring various parameters with Open Conn Msg */
   uint16 unOptions;

   #define IFX_RTP_OPT_CONN_MODE    0x0001
   #define IFX_RTP_OPT_TX_PAYLOAD   0x0002
   #define IFX_RTP_OPT_RX_PAYLOAD   0x0004
   #define IFX_RTP_OPT_PKT_INTRVL   0x0008
   #define IFX_RTP_OPT_SIL_SUPP     0x0010
   #define IFX_RTP_OPT_CNG          0x0020
   #define IFX_RTP_OPT_ENCRPT       0x0040
   #define IFX_RTP_OPT_JB           0x0080
   #define IFX_RTP_OPT_RTP          0x0100
   #define IFX_RTP_OPT_INBAND       0x0200
   #define IFX_RTP_OPT_ECHO_SUPP    0x0400
   #define IFX_RTP_OPT_REMOTE_RTCP_IP    0x0800
   #define IFX_RTP_OPT_STRICT_SRTP    0x1000

   #define IFX_RTP_MODE_SEND_ONLY    1
   #define IFX_RTP_MODE_RECV_ONLY    2
   #define IFX_RTP_MODE_SEND_RECV    3
   #define IFX_RTP_MODE_INACTIVE     4   
   #define IFX_RTP_MODE_CLOSE	5


   /* Session Id is used to indicate to which session this 
    * connection should belong to.  
    * If Session Id is sent as 0, a new session and connection
    * will be created.  If a connection has to be added to an 
    * existing session, the corresponding session id has to be
    * sent
    */
   uint8 ucSessionId; 

   /* Connection mode indicates the mode of the connection.
    * The connection can be in the following modes
    * IFX_RTP_MODE_SEND_ONLY
    * IFX_RTP_MODE_RECV_ONLY
    * IFX_RTP_MODE_SEND_RECV
    * IFX_RTP_MODE_INACTIVE
    */
   int32 iProfileId;
   uint8 ucConnMode;

   uint16 unLocalPort;           /* Local RTP Port */

   char8  acRemoteIP[IFX_RTP_IP_ADDR_LEN]; /* Remort IP Address */

   uint16 unRemotePort;          /* Remote RTP Port */
   char8  acRemoteRtcpIP[IFX_RTP_IP_ADDR_LEN]; /* Remort RTCP IP Address */

   uint16 unRemoteRtcpPort;          /* Remote RTCP Port */

   uint32 uiTxLocalPT;   /* Local Sender Payload Type */

   uchar8 ucTxIanaPT;   /* IANA Sender Payload Type */

   #define  IFX_RTP_OUT_OF_BAND          0X01
   #define  IFX_RTP_INBAND_VOICE         0X02
   #define  IFX_RTP_INBAND_EVENT         0X03
   #define  IFX_RTP_INBAND_VOICE_EVENT   0X04
		  
	
   uchar8 ucEventTransFlag;  /* Event Transmission Flag */

   uchar8 ucTxDtmfPT;   /* Sender DTMF dynamic Payload Type */

   uchar8 ucRxDtmfPT;   /* Receiver DTMF dynamic Payload Type */

   /* Receive Payload Type is an indicator to what payload this
    * connection will receive from the remote.  RTP will not make
    * use of this.  It is passed JB for RTP Header validation
    */
   x_IFX_RTP_CodecList xRxCodecList;

   uint16 unPktInterval;      /* Packetization Period - Frame length */

   uchar8 ucSilenceSuppressionFlag; /* Silence Suppression Flag */

   uchar8 ucComfortNoiseFlag;    /* Comfort Noise Generation Flag */

   uchar8 ucEchoSuppressionFlag; /* Echo Suppression Flag */
   
} x_IFX_RTP_OpenConnMsg;

/* x_IFX_RTP_ModifyConnMsg message is used to modify 
 * the attributes of a connection.
 * The modifyable attributes of a connection are
 *    Connection Mode
 *    Sender Payload Type
 *    Framelength
 */
typedef struct
{
   uint16 unOptions;

   /* Session Id and Connection Id for the connection */
   uint8 ucSessionId;
   uint8 ucConnId;
   uint32 iProfileId;

   /* Connection Mode, 0 - indicates no change in mode */
   uint8 ucConnMode;
   char8  acRemoteIP[IFX_RTP_IP_ADDR_LEN]; /* Remort IP Address */
   uint16 unRemotePort;          /* Remote RTP Port */
   char8  acRemoteRtcpIP[IFX_RTP_IP_ADDR_LEN]; /* Remort RTCP IP Address */

   uint16 unRemoteRtcpPort;          /* Remote RTCP Port */

   /* Sender Payload Type, 0 - indicates no change in Payload Type */
   uint32 uiTxLocalPT;   /* Local Sender Payload Type */

   uchar8 ucTxIanaPT;   /* IANA Sender Payload Type */

   /*#define IFX_RTP_EVENT_TRANS_NONE  0
   #define IFX_RTP_EVENT_TRANS_VOICE 1
   #define IFX_RTP_EVENT_TRANS_2833  2*/

   uchar8 ucEventTransFlag;  /* Event Transmission Flag */

   uchar8 ucTxDtmfPT;   /* Sender DTMF dynamic Payload Type */

   uchar8 ucRxDtmfPT;   /* Receiver DTMF dynamic Payload Type */

   /* Receive Payload Type is an indicator to what payload this
    * connection will receive from the remote.  RTP will not make
    * use of this.  It is passed JB for RTP Header validation
    */
   x_IFX_RTP_CodecList xRxCodecList;

   uint16 unPktInterval;  /* Packetization Period - Framelength */

   uchar8 ucSilenceSuppressionFlag; /* Silence Suppression Flag */
   uchar8 ucComfortNoiseFlag;    /* Comfort Noise Generation Flag */
   
} x_IFX_RTP_ModifyConnMsg;

/* x_IFX_RTP_CloseConnMsgis used to close a RTP connection.  If this is the
 * last connection for a session, the session is also closed
 */
typedef struct
{
   uint8 ucSessionId;
   uint8  ucConnId;
   uchar8 ucCallId;
} x_IFX_RTP_CloseConnMsg;


/* Enable conference message to RTP */
typedef struct
{

   uint8 ucSessionId;
   uint8 ucConnId;
   uint8 ucConnMode;
   char8  acRemoteIP[IFX_RTP_IP_ADDR_LEN]; /* Remort IP Address */
   uint16 unRemotePort;          /* Remote RTP Port */
   char8  acRemoteRtcpIP[IFX_RTP_IP_ADDR_LEN]; /* Remort RTCP IP Address */

   uint16 unRemoteRtcpPort;          /* Remote RTCP Port */
}x_IFX_RTP_EnConfSessInfo;

typedef struct
{
   uint8 ucNoOfSessions;
   int32 iContextId1;
   x_IFX_RTP_EnConfSessInfo xConfSessInfo[IFX_RTP_MAX_SESSIONS];
} x_IFX_RTP_EnConfMsg;

/* Disable conference message to RTP */
typedef struct
{
	uint8 ucConnId;
	uint8 ucConnMode;
}x_IFX_RTP_DisConfConnInfo;


typedef struct
{
   uint8 ucSessionId;
   int32 iContextId1;
   uint8 ucNoOfConns;
   x_IFX_RTP_DisConfConnInfo xConfConnInfo[IFX_RTP_MAX_CONNS];
} x_IFX_RTP_DisConfMsg;


typedef union
{
   x_IFX_RTP_OpenConnMsg xOpenConnMsg;
   x_IFX_RTP_ModifyConnMsg xModifyConnMsg;
   x_IFX_RTP_CloseConnMsg xCloseConnMsg;
   x_IFX_RTP_EnConfMsg xEnConfMsg;
   x_IFX_RTP_DisConfMsg xDisConfMsg;
} ux_IFX_RTP_SsMsg;

/* RTP Rx (SS) Message */
typedef struct
{
   int32 iContextId;
   uchar8 ucMsgType;
   ux_IFX_RTP_SsMsg uxSsMsg;
} x_IFX_RTP_SsMsg;



/* Enable conference response from RTP */
typedef struct
{
   int32 iContextId1;
   uint8 ucNoOfConns;
   uint8 ConnIdList[IFX_RTP_MAX_CONNS];
} x_IFX_RTP_EnConfRes;

/*Disable conference response from RTP */
typedef struct
{
	uint8 ucSessionId;
	uint8 ucConnId;
}x_IFX_RTP_DisConfSessInfo;


typedef struct
{
     uint8 ucNoOfSessions;
     int32 iContextId1;
     x_IFX_RTP_DisConfSessInfo xConfSessInfo[IFX_RTP_MAX_SESSIONS];
} x_IFX_RTP_DisConfRes;


typedef   union uxRsp
   {
      x_IFX_RTP_EnConfRes xEnConfRes;
      x_IFX_RTP_DisConfRes xDisConfRes;
      uint8 ucErrType;
   } uxRtpRsp;

/* RTP Tx (RTP) Message */
typedef struct
{
   int32 iProfileId;
   int32 iContextId;
   uint8 ucSessionId;
   uint8 ucConnId;
   uint8 ucMsgType;	/* To indicate response, info or error */
   uxRtpRsp uxRspInfo; 

} x_IFX_RTP_RtpMsg;

int32 IFX_RTP_RtpInit(int32 argc, char8 *argv[]);
char8 IFX_RTP_RtpShut(void);

#endif /* __IFX_RTP_H__ */
