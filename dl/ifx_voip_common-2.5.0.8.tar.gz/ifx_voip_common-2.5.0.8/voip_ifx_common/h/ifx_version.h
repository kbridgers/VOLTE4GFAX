
/***********************************************************************
**   FILE NAME	: ifx_version.h
**   PROJECT	:
**   MODULES	: All
**   SRC VERSION: V1.0
**   DATE	    : 06-July-2005
**   AUTHOR	    : Radvajesh.M
**   DESCRIPTION: Version Control	
**   FUNCTIONS	:	
**   COMPILER	:
**   REFERENCE	:
**							
**   COPYRIGHT  :Copyright © 2004 
**               Infineon Technologies AG
**               St. Martin Strasse 53; 81669 München, Germany
**   DESCLAIMER :Any use of this Software is subject to the conclusion 
**               of a respective License Agreement.
**               Without such a License Agreement no rights to the 
**               Software are granted. 
***********************************************************************/
/*
* Versioning Scheme is as follows
* iip.<Phase Number>.<Major Release>.<Minor Release>.<Internal Release>
*/
#define IFX_CM_SW_VERSION  "$Id:2.2.0.1$"

#define IFX_RM_SW_VERSION "$Id:2.2.0.1 $"

#define IFX_SIP_SW_VERSION  "$Id:2.2.0.1 $"

#define IFX_APP_SW_VERSION   "$Id:2.2.0.1 $"

#define IFX_RTP_SW_VERSION "$Id:2.2.0.1 $"
#define IFX_FAX_SW_VERSION "$Id:2.2.0.1 $"
#define IFX_STANDARD_CHIP "$Id: INCA-IP Standard Chip 1.4 $"
#define IFX_COMPACT_CHIP  "$Id: INCA-IP Compact Chip 1.4 $"

#define IFX_HAPI_SW_VERSION "0.1.1.1 "
#define IFX_JB_SW_VERSION "2.1.1.1  " 
#define IFX_DRIVER_VERSION "DRIVER 1.1"
#define IFX_FW_VERSION "FW 1.1"

