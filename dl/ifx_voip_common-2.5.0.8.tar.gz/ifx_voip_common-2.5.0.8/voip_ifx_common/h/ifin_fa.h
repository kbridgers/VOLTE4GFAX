/**************************************************************************
 **   SRC_FILE          : ifin_fa.h
 **   PROJECT           : T.38 Fax Relay
 **   MODULES           :
 **   SRC VERSION       : v1.0
 **   DATE              :
 **   AUTHOR            : Haribalram. R
 **   DESCRIPTION       : T.38 Fax Agent
 **   FUNCTIONS         :
 **   COMPILER          :
 **   REFERENCE         : Coding guide lines for IFIN COM V2.0
 **   COPYRIGHT         : Infineon Technologies, 2003-2004
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
 **************************************************************************/
#ifndef __IFIN_FA_H__
#define __IFIN_FA_H__


#define IFIN_FA_SUCCESS  0
#define IFIN_FA_FAIL    -1

#define IFIN_FA_TRUE    1
#define IFIN_FA_FALSE   0


/* Fax Agent TCP Server Starting Port */
#define IFIN_FA_TCP_SERVER_PORT_START       7500

#define IFIN_FA_MAX_IP_ADDR_LEN             15

/* Message Type - From UA */
#define IFIN_UA_START_T38_SESSION_REQ       1
#define IFIN_UA_END_T38_SESSION_REQ         2    
#define IFIN_UA_SHUTDOWN_FA_REQ             3

/* Message Type - From FA */
#define IFIN_FA_START_FAX_CALL_REQ          4
#define IFIN_FA_END_FAX_CALL_REQ            5
#define IFIN_FA_START_T38_SESSION_RSP       6
#define IFIN_FA_START_T38_SESSION_ERR_RSP   7
#define IFIN_FA_END_T38_SESSION_RSP         8    
#define IFIN_FA_END_T38_SESSION_ERR_RSP     9    

/* Message Type - Timer Callback */
#define IFIN_FA_TIMEOUT_MSG                 10


/* Message Type - From APP */
#define IFIN_FA_APP_EVENT_MSG               11 
/* There wont be any message sent from FA to APP */


/* Fax Call Indication Tones */ 
/* This may not be required for the fax agent as tones are
 * being handled by the Application.
 * To indicate the direction of fax, in the StartT38SessReq,
 * SS would send the Call Direction parameter
 */ 
#define IFIN_FA_EVENT_CNG_TONE          1 
#define IFIN_FA_EVENT_CED_TONE          2
#define IFIN_FA_EVENT_DIS_PREAMBLE      3

/* Fax Data Pump Status Indications */
/* Following notifications should be sent from APP to FA
 * FA needs to pass these notifications to the T.38 stack
 */
#define IFIN_FA_FDP_FAX_ERROR           4
#define IFIN_FA_FDP_MIPS_OVERLOAD       5
#define IFIN_FA_FDP_READ_ERROR          6
#define IFIN_FA_FDP_WRITE_ERROR         7
#define IFIN_FA_FDP_SETUP_ERROR         8
#define IFIN_FA_FDP_NO_ERROR            9

/* Capability types */
typedef enum 
{
  IFIN_FA_CapType_TCP ,  /* TCP capabilities */
  IFIN_FA_CapType_UDP    /* UDP capabilities */
} e_IFIN_FA_CapType;

#define IFIN_FA_CAP_FL_TCF_LOCAL             0x01
#define IFIN_FA_CAP_FL_TCF_TRANSFERRED       0x02

#define IFIN_FA_CAP_FL_OPT_FILL_BIT_REMOVAL  0x0001
#define IFIN_FA_CAP_FL_OPT_TRANSCODING_MMR   0x0002
#define IFIN_FA_CAP_FL_OPT_TRANSCODING_JBIG  0x0004

#define IFIN_FA_CAP_FL_EC_REDUNDANCY         0x01
#define IFIN_FA_CAP_FL_EC_FEC                0x02

/* T38 capabilities */
typedef struct 
{
   /* Capability Type */
   uint32         uiTransportProtocol;
   uchar8         ucVersion;
   /* GetCapabilities: any combination of IFIN_FA_CAP_FL_TCF_XXX values *
    * SessionCapabilities: one of IFIN_FA_CAP_FL_TCF_XXX values         */
   uchar8         ucRateManagement;
   /* units 100 bit/s */
   uint16         unMaxBitRate;
   /* any combination of IFIN_FA_CAP_FL_OPT_XXX values */
   uint32         uiBitOptions;
   /* UDP options */
   uint16         unUDPMaxBufferSize;
   uint16         unUDPMaxDatagramSize;
   /* GetCapabilities: any combination of IFIN_FA_CAP_FL_EC_XXX values *
    * SessionCapabilities: one of IFIN_FA_CAP_FL_EC_XXX values         */
   uchar8         ucUDPErrCorrection;

} x_IFIN_FA_Profile;


typedef struct
{
   /* Protocol */
   uchar8            ucProtocol;

   /* Type of Connection - Relevant only of ucProtocol == TCP */

#define IFIN_FA_TCP_TOC_BIDIRECTIONAL       1
#define IFIN_FA_TCP_TOC_UNIDIRECTIONAL      2

   uchar8            ucTcpTOC;

   /* IP Address of Remote Gateway */
   char8             acRemoteIpAddr[IFIN_FA_MAX_IP_ADDR_LEN];

   /* Local TCP/UDP Port Number */
   uint16            unLocalPort;

   /* Remote TCP/UDP Port Number */
   uint16            unRemotePort;

   /* Profile agreed between Peers */
   x_IFIN_FA_Profile xProfile;

   /* Round Trip Delay Flag - TRUE/FALSE */
   char8             cRtDelayFlag;

   /* Call direction */
   char8             cCallDir;

#define IFIN_FA_CALL_DIR_INCOMING       0x1
#define IFIN_FA_CALL_DIR_OUTGOING       0x2

} x_IFIN_FA_StartT38SessReq;

typedef struct
{
   /* 
    * This message will be used by UA during an incoming 
    * call, when the call is initiated from the remote end
    * In this case, the FA wouldnt have created the UDP/TCP 
    * ports required for the session.
    * After the UA gives the profile, the FA creates the port
    * and sends the port number in the response.
    */

   /* Local TCP/UDP Port Number */
   uint16            unLocalPort;

} x_IFIN_FA_StartT38SessRsp;

typedef enum
{
   IFIN_FA_NO_ERROR = 0,
   IFIN_FA_GEN_ERROR,
   IFIN_FA_CHANNEL_NUMBER_ERROR,
   IFIN_FA_FAX_PROFILE_ERROR,
   IFIN_FA_SOCK_CREATE_ERROR,
   IFIN_FA_TCP_SERVER_SOCK_CREATE_ERROR,
   IFIN_FA_SOCK_SEND_ERROR,
   IFIN_FA_MAX_CONNS_EXCEED_ERROR = 7,
   IFIN_FA_START_T38_SESSION_ERROR,
   IFIN_FA_RM_INTERFACE_ERROR,
   IFIN_FA_RESOURCE_UNAVAILABLE_ERROR,
   IFIN_FA_T38_SESSION_ERROR
} e_IFIN_FA_Error;

typedef struct
{
   e_IFIN_FA_Error   eError;
} x_IFIN_FA_ErrorMsg;

typedef struct
{
   /* Profile - For a Protocol Type */
   x_IFIN_FA_Profile xTcpProfile;
   x_IFIN_FA_Profile xUdpProfile;
} x_IFIN_FA_FaxProfileRsp;


typedef struct
{
   uint16            unEvent;
} x_IFIN_FA_AppEvent;

typedef enum
{
   IFIN_FA_EndNormal = 0,
   IFIN_FA_EndOnHook
} e_IFIN_FA_EndT38Mode;

typedef struct
{
   e_IFIN_FA_EndT38Mode eMode;
} x_IFIN_FA_EndT38SessReq;

typedef union
{
   x_IFIN_FA_StartT38SessReq      xStartT38SessReq;
   x_IFIN_FA_StartT38SessRsp      xStartT38SessRsp;
   x_IFIN_FA_EndT38SessReq        xEndT38SessReq;
   x_IFIN_FA_AppEvent             xAppEvent;
   x_IFIN_FA_ErrorMsg             xErrorMsg;
} u_IFIN_FA_Msg;

typedef struct
{
   /* MsgType - Also determines the direction of the msg */
   uchar8               ucMsgType;

   /* Connection Identifier */
   int32 iConnId;

   /* Profile Identifier */
   int32 iProfileId;

   /* Sequence Number for matching request and response */
   uchar8 ucSeqNo;

   /* For a scenario in which, Fax is supported in only one
    * Channel, there may not be a problem in matching 
    * requests and responses.  ucSeqNo will not be used in 
    * such a scenario.  It is defined for future use
    */

  /* Message contents */
   u_IFIN_FA_Msg        uFaMsg;
   
} x_IFIN_FA_Msg;

/* Export Functions */

EXTERN int32 IFIN_FA_Init(int32 argc , char8 *argv[]);
EXTERN char8 IFIN_FA_Shut(void);

#endif /* __IFIN_FA_H_ */
