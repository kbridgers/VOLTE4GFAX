/**************************************************************************
 **   FILE NAME       : ifx_srtp.h
 **   PROJECT         : RTP/RTCP
 **   MODULES         : Key managment module for SRTP/SRTCP
 **   SRC VERSION     : V0.1
 **   DATE            : 30-08-2004
 **   AUTHOR          : Radvajesh.M
 **   DESCRIPTION     :
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS ,
 **
 **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_SRTP_H__
#define __IFX_SRTP_H__

/* SRTP return Values */
typedef enum
{
  IFX_SRTP_ON = 1,
  IFX_SRTP_OFF,
  IFX_SRTP_DISCARD_PKT ,
  IFX_SRTP_ONLY_OFF,
  IFX_SRTP_TRIGER_REKEY,
}e_IFX_SRTP_RespType;

#define IFX_SRTP_SUCCESS 0
#define IFX_SRTP_FAIL -1

/*SRTP Porcessing Pkt Type*/
#define IFX_SRTP_RTP_PKT 1
#define IFX_SRTP_RTCP_PKT 2

/*SRTP GET IV Direction type*/
#define IFX_SRTP_UP_STREAM 1
#define IFX_SRTP_DOWN_STREAM 2

/* Publish 8 SRTP related API */

/* To Init Srtp*/
PUBLIC int32 IFX_SRTP_Init();

/* To ShutDown Srtp*/
PUBLIC int32 IFX_SRTP_Shut();

/* Open Up stream session*/
PUBLIC int32 IFX_SRTP_InitUpStream(IN const uint32 uiStreamID,
                                   IN const uint32 uiSsrc,
                                   IN const char8 *pcLocalIP,
                                   IN const uint16 unLocalPort,
                                   IN const void *pCryptoCtx);

/* Open down stream session*/
PUBLIC int32 IFX_SRTP_InitDownStream(IN const uint32 uiStreamID,
		                     IN const uint32 uiSsrc,
		                     IN const char8 *pcRemoteIP,
				     IN const uint16 unRemotePort,
                                     IN const void *pCryptoCtx);

/* Close SRTP Session*/
PUBLIC int32 IFX_SRTP_CloseSession(IN const uint32 uiStreamID);

/* Process downstream RTP packets by decrypting payload
 *   and removing authentication tag*/
PUBLIC int32 IFX_SRTP_EncodePkt(IN const uint32 uiStreamID,
                                IN char8 *pcInPacket,
                                IN int16 *pnPktLen,
                                IN char8 cPktType);

/* Process Up Stream RTP packets by  encrypting and adding authenticating */
PUBLIC int32 IFX_SRTP_DecodePkt(IN const uint32 uiStreamID,
                                IN char8 *pcOutPacket,
                                IN int16 *pnPktLen,
                                IN char8 cPktType);

/* Returns IV for reading from device*/
PUBLIC void*  IFX_SRTP_GetIV(IN uint32 uiStreamID,
                             IN uint32 uiSsrc,
                             IN char8 cDir);

#endif /*__IFX_SRTP_H__*/



