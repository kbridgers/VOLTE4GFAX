/**************************************************************************
 **   FILE NAME       : ifx_cm.h
 **   PROJECT         : INCA IP Phone - Config Module
 **   MODULES         : Config Module
 **   SRC VERSION     : V0.1
 **   DATE            : 15-06-2004
 **   AUTHOR          : Radvajesh.M
 **   DESCRIPTION     : 
 **   DEPENDENCIES    : ifx_common_defs.h and ifx_voip_defs.h
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS ,
 **
 **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_CM_H__
#define __IFX_CM_H__

/* Files used by Configuration module */
#ifdef IIP
#define IFX_CM_VOIP_SYS_FILE "./tmp/IncaVoipSysCfg"
#define IFX_CM_VOIP_PROFILE_FILE "./tmp/IncaVoipProfileCfg"
#define IFX_CM_VOIP_LINE_FILE "./tmp/IncaVoipLineCfg"
#endif /* IIP */

#ifdef AMAZON
#define IFX_CM_VOIP_SYS_FILE "/flash/AtaVoipSysCfg"
#define IFX_CM_VOIP_PROFILE_FILE "/flash/AtaVoipProfileCfg"
#define IFX_CM_VOIP_LINE_FILE "/flash/AtaVoipLineCfg"
#endif

#ifdef ATA
#define IFX_CM_VOIP_SYS_FILE "/nv/AtaVoipSysCfg"
#define IFX_CM_VOIP_PROFILE_FILE "/nv/AtaVoipProfileCfg"
#define IFX_CM_VOIP_LINE_FILE "/nv/AtaVoipLineCfg"
#endif

/* Constants */

/*Max Error Codes*/
#define IFX_CM_MAX_ERROR_CODES 20


#ifdef IIP
/* Begin InfoTypes */
typedef enum
{
   /* Voip System Info type */
   IFX_CM_VER_CFG = 0,
   IFX_CM_DBG_CFG, 
   IFX_CM_SIP_CFG_RTPPORTRANGE, 
   IFX_CM_SIP_CFG_PARAM,
   IFX_CM_SIP_CFG_STUN,
   IFX_CM_APP_ETH_LED_CFG,
   IFX_CM_OUT_CALLBLOCK_CFG,
   IFX_CM_MAX_SYS_TYPES,/* 7 */
           
   /* Voip Profile type */
   IFX_CM_ADD_PROFILE,
   IFX_CM_DEL_PROFILE,
   IFX_CM_MODIFY_PROFILE,
   IFX_CM_VIEW_PROFILE,
   IFX_CM_SIP_CFG_PROXY, 
   IFX_CM_SIP_CFG_REGISTRAR, 
   IFX_CM_SIP_CFG_TELURI,
   IFX_CM_SIP_CFG_VOICEMAIL,
   IFX_CM_SIP_CFG_JITTERBUFF,  
   IFX_CM_MEDIA_CONFIG,
   IFX_CM_MAX_PROF_TYPES, /*18*/
   
   /* Line Messages*/
   IFX_CM_ADD_LINE,
   IFX_CM_DEL_LINE,
   IFX_CM_MOD_LINE,
   IFX_CM_VIEW_LINE,
   IFX_CM_SIP_CFG_USER, 
   IFX_CM_APP_ADDR_ENTRY, /*GET*/
   IFX_CM_APP_ADD_ADDR_ENTRY,
   IFX_CM_APP_MODIFY_ADDR_ENTRY, 
   IFX_CM_APP_DELETE_ADDR_ENTRY,
   IFX_CM_APP_VAD_CFG,
   IFX_CM_APP_ADD_MSG_ENTRY, 
   IFX_CM_APP_MODIFY_MSG_ENTRY,
   IFX_CM_APP_DELETE_MSG_ENTRY,
   IFX_CM_APP_GET_MSG_ENTRY,
   IFX_CM_APP_CR_MISSED_CALL,
   IFX_CM_APP_CR_DIALED_CALL,
   IFX_CM_APP_CR_RECEIVED_CALL,
   IFX_CM_APP_CALL_CFG,
   IFX_CM_APP_ACOUSTIC_CFG,
   IFX_CM_SRTP_KEY_CFG, 
   IFX_CM_SRTCP_KEY_CFG,
   IFX_CM_MAX_LINE_TYPES,/*40 */
           
   /* Rc.conf */
   IFX_CM_APP_ADMIN_PROF,
   IFX_CM_APP_USR_PROF,
   IFX_CM_APP_NETWORK,
   IFX_CM_MAX_RC_TYPES, /*44*/
   
   /* MIB Information */
   IFX_CM_RTP_MIB_CFG,
   IFX_CM_LINE_IDLE,
   IFX_CM_FWCODECS_CFG,

   IFX_CM_MAX_INFOTYPES /* 48*/
} e_IFX_CM_InfoType;
#else
typedef enum
{
   /* Voip System Info type */
   IFX_CM_GW_CFG = 0,
   IFX_CM_COUNTRY_TONE_CFG,
   IFX_CM_FW_CFG,
   IFX_CM_VER_CFG,
   IFX_CM_DBG_CFG, 
   IFX_CM_SIP_CFG_RTPPORTRANGE, 
   IFX_CM_SIP_CFG_PARAM,
   IFX_CM_SIP_CFG_STUN,
   IFX_CM_DIAL_PLAN,
   IFX_CM_FA_T38_CFG,
   IFX_CM_SIP_CFG_FAX_PORT,
   IFX_CM_OUT_CALLBLOCK_CFG,
   IFX_CM_MAX_SYS_TYPES,/* 10 */
           
   /* Voip Profile type */
   IFX_CM_ADD_PROFILE,
   IFX_CM_DEL_PROFILE,
   IFX_CM_MODIFY_PROFILE,
   IFX_CM_VIEW_PROFILE,
   IFX_CM_SIP_CFG_PROXY, 
   IFX_CM_SIP_CFG_REGISTRAR, 
   IFX_CM_SIP_CFG_TELURI,
   IFX_CM_SIP_CFG_VOICEMAIL,
   IFX_CM_SIP_CFG_JITTERBUFF,  
   IFX_CM_MEDIA_CONFIG,
   IFX_CM_RM_FAX_CFG,
   IFX_CM_MAX_PROF_TYPES, /*24*/
   
   /* Line Messages*/
   IFX_CM_ADD_LINE,
   IFX_CM_DEL_LINE,
   IFX_CM_MOD_LINE,
   IFX_CM_VIEW_LINE,
   IFX_CM_SIP_CFG_USER, 
   IFX_CM_APP_ADDR_ENTRY, /*GET*/
   IFX_CM_APP_ADD_ADDR_ENTRY,
   IFX_CM_APP_MODIFY_ADDR_ENTRY, 
   IFX_CM_APP_DELETE_ADDR_ENTRY,
   IFX_CM_APP_CR_MISSED_CALL,
   IFX_CM_APP_CR_DIALED_CALL,
   IFX_CM_APP_CR_RECEIVED_CALL,
   IFX_CM_APP_CALL_CFG,
   IFX_CM_APP_VERT_SERV_CFG,
   IFX_CM_MAX_LINE_TYPES,/*39 */
           
   /* Rc.conf */
   IFX_CM_APP_ADMIN_PROF,
   IFX_CM_APP_USR_PROF,
   IFX_CM_APP_NETWORK,
   IFX_CM_MAX_RC_TYPES, /*43*/
   
   /* MIB Information */
   IFX_CM_RTP_MIB_CFG,
   IFX_CM_LINE_IDLE,
   IFX_CM_FWCODECS_CFG,
   
   IFX_CM_MAX_INFOTYPES /* 47*/
} e_IFX_CM_InfoType;

#endif /*IIP*/


/* Begin - ErrorCodes -- to be completed yet*/
typedef enum
{
   IFX_CM_FAIL = -1,
   IFX_CM_SUCCESS = 0,
   IFX_CM_NOSP_HANDLING
} e_IFX_CM_RespType;


typedef enum
{
   IFX_CM_GET_REQ=0,
   IFX_CM_SET_REQ,
   IFX_CM_SET_RSP,
   IFX_CM_GET_RSP,
   IFX_CM_GET_ERR_RSP,
   IFX_CM_SET_ERR_RSP,
   IFX_CM_MAX_MSGTYPES
}e_IFX_CM_MsgType;


/* Error Code Structure */
typedef struct
{
   uchar8 ucNoOfErrors;
   /* Use enums in e_IFX_CM_ErrorCodes*/
   e_IFX_CM_RespType eErr[IFX_CM_MAX_ERROR_CODES];
         
} x_IFX_CM_ErrorInfo;

/* All Register Proccess shall get this structure for intimate on change*/
typedef struct
{
   /* Info type*/
   uchar8 ucInfoType;
   
   /* Flag or index in case of specfic points*/
   uchar8 ucFlag;
   
   /* ContextId */
   uchar8 ucContextId;

}x_IFX_CM_RegProcInfo;



/* Begin - CmMsg */
typedef union
{
   /* Following structures shall be used with
    * Set Req
    * Get Rsp
    * In case of a Get Req, the Req type and Info type are enuf
    * In case of a Set Rsp, the values are already with web server
    * In case of Get or Set Error Responses, use the xErrorMsg
    */
        
   /* System Cfg */
#ifndef IIP        
        
   /* Gateway Cfg */     
   x_IFX_GatewayCfg xGatewayCfg;
   
   /* Country Tone Cfg */
   x_IFX_CountryToneCfg xCountryToneCfg;
 
   /* Firmware Download Cfg */
   x_IFX_FirmwareCfg xFirmwareCfg;
   
#endif
   /* S/w Version information */
   x_IFX_VersionCfg xVerCfg;
    
   /* Debug Information */
   x_IFX_DbgCfg xDbgCfg;
 
   /* Rtp Port Configuration */ 
   x_IFX_SipRTPPortRangeCfg xRtpCfg;
   
   /* Sip Param Config */
   x_IFX_SipParamCfg xParamCfg;

   /* Stun Config */
   x_IFX_StunCfg xStunCfg;

#ifdef IIP
    /*Ethernet Led ON,OFF */
    x_IFX_EthLedCfg xEthLedCfg;

#else
    /* Dial Plan */
    x_IFX_DialPlanCfg xDialPlanCfg;

#endif    
    /* Out Going Call Block */
    x_IFX_OutCallBlockCfg xOutCallBlockCfg;

   /* Voip Profile Configuration */
   x_IFX_ProfileCfg xProfileCfg;
  
   /* Proxy Cfg */ 
   x_IFX_SipProxyCfg xProxyCfg; 
   
   /* Registrar Cfg*/
   x_IFX_SipRegistrarCfg xRegCfg; 
  
   /* Tel URI */
   x_IFX_SipTelUriCfg xTelUriCfg;
   
   /* Vms Cfg */
   x_IFX_VoiceMailCfg xVoiceMailCfg;
   
   /* JB Cfg*/
   x_IFX_JbConfig xJbConfig; 
   
   /* Media Cfg */
   x_IFX_RmMediaCfg xMediaCfg;
   
   /* Fax Cfg */   
#ifndef IIP

   x_IFX_RM_FaxCfg axFaxCfg;

   /* T38 Config */
   x_IFX_FA_T38Cfg xT38Cfg;
   x_IFX_SipFaxPortCfg xFaxPortCfg;
#endif 
   
   /* Line Config*/
   x_IFX_LineCfg xLineCfg;
   
   /* Sip User Cfg */
   x_IFX_SipUserCfg xSipUserCfg;

   /* Address book Cfg*/
   x_IFX_AddressBookEntry xAddrBookCfg;
   
   /* Mod Addr book Cfg*/
   x_IFX_ModAddrBookCfg xModAddrBookCfg;
   
 #ifdef IIP
    x_IFX_AcousticCfg xAcousticCfg;

    x_IFX_VadCfg xVadCfg; 
    
    x_IFX_MsgCfg xMsgCfg; 
    
#endif /*IIP*/
    
    /* Call Reg */
    x_IFX_CallRegCfg xCallRegCfg;
    
   /* Call Cfg*/
   x_IFX_CallCfg xCallCfg;
#ifndef IIP
   /* Vertical Service Cfg*/
   x_IFX_VerticalServCfg xVerticalServCfg;
#endif   
   
   x_IFX_UserCfg xAppUserCfg;

   x_IFX_NetAddrCfg xNetAddrCfg;

#ifdef SRTP    
    x_IFX_SrtpKeyCfg xSrtpKeyCfg;
#endif /* SRTP */   
   
    /* RTP Mib information*/
    x_IFX_RTP_MIB_Table xRtpMibCfg;

    /* Error Info */
    x_IFX_CM_ErrorInfo xErrorInfo;

} ux_IFX_CM_DataType;


typedef struct
{

  /* can hold any one of the value e_IFX_CM_MsgType */ 
  uchar8 ucMsgType;

  /*can hold any one of the value  e_IFX_CM_InfoType*/
  uchar8 ucInfoType;

  /* voice line id , audio-video source */
  uchar8 ucChannel; 
  
  /* Data part of the message*/
  ux_IFX_CM_DataType uxData; 
  
} x_IFX_CM_Msg;

/* PUBLIC Functions */

/* Following function should be used only by the Monitor Process */

PUBLIC char8 IFX_CM_Init();

PUBLIC char8 IFX_CM_Shut(void);

/* Following function should be called by all Process utilizing CM */

PUBLIC char8 IFX_CM_MgtInit(IN uchar8 ucModuleId);

PUBLIC char8 IFX_CM_MgtShut();

/* Function API , These are present for backward compatablity*/
PUBLIC char8 IFX_CM_RecvDataFromCM(IN_OUT x_IFX_CM_Msg * pxCmMsg);

/* Blocking Function API */
PUBLIC char8 IFX_CM_SendDataToCM(IN_OUT x_IFX_CM_Msg * pxCmMsg);

/* Inorder to get indvidual fields */
PUBLIC char8 IFX_CM_GetCfgData(IN uchar8 ucContextId,
                               IN uchar8 ucInfoType,
                               OUT void *pxData);

/* Inorder to set indvidual fields */
PUBLIC char8 IFX_CM_SetCfgData(IN uchar8 ucContextId,
                               IN uchar8 ucInfoType,
                               IN void *pxData);

/* This API shall Intimate the registored process when there
 * is change in infotype*/
PUBLIC char8 IFX_CM_IntimateOnChange(IN uchar8 ucModuleId,
                                     IN uchar8 ucInfoType);

PUBLIC char8 IFX_CM_SendMsgToRegProcess(IN uchar8 ucContextId,
                                        IN uchar8 ucInfoType);

/* Pointer based Manupilation */
PUBLIC char8 IFX_CM_GetCfgPtr(IN uchar8 ucContextId,
                              IN uchar8 ucInfoType,
                              OUT void **ppxDataPtr);

/* Lock on Configuration data*/
PUBLIC char8 IFX_CM_LockCfg(IN uchar8 ucModuleId);

/* Unlock on Configuration */
PUBLIC char8 IFX_CM_UnLockCfg(IN uchar8 ucModuleId);

/* Update the File with the configuration in shared memory*/
PUBLIC char8 IFX_CM_UpdateFile(IN uchar8 ucContextId,
                               IN uchar8 ucInfoType);
                               
#endif /* __IFX_CM_H__ */
