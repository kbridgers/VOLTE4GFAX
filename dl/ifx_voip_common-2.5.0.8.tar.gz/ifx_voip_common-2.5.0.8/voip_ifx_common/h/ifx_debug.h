/****************************************************************************
 **   FILE NAME       : ifx_debug.h
 **   PROJECT         : INCA IP 
 **   MODULES         : Debug Management module
 **   SRC VERSION     : V0.1
 **   DATE            : 01-10-2004
 **   AUTHOR          : Hari
 **   DESCRIPTION     : This file contains the code for Debug Management
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS, DIS of RM
 **   COPYRIGHT       : Infineon Technologies AG 2003 - 2004 

 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
*****************************************************************************/

#ifndef __IFX_DEBUG_H__
#define __IFX_DEBUG_H__
//#define IFX_SUCCESS 0
#define IFX_FAIL   -1

/* No debug */
#define IFX_DBG_LVL_NONE  0

/* Used only for all Error Handling Debugs */
#define IFX_DBG_LVL_ERROR  1
/* Guidelines 
 * File Open Error
 * Socket Open Error
 * Memory Initialisation Error
 * Fifo Creation Error
 * Process Creation Error
 */

/* Minimal Information to describe the control flow */
#define IFX_DBG_LVL_LOW    2
/* Guidelines 
 * Module Initialisation Success
 * Memory/Timer Initialisation Success
 */

/* More Information to describe the control flow */
#define IFX_DBG_LVL_NORMAL 3
/* Guidelines 
 * Interprocess Communication Messages
 * Important Function Calls
 * Minimal Info on Signalling Path
 * Minimal Info on Voice Path setup
 */

/* Used for Testing/Debugging - Should not be set during final builds */
#define IFX_DBG_LVL_HIGH 4
/* Guidelines
 * Used for anything else other than mentioned for other Debug Levels
 * Inside for Loops
 * Printing of Parameters
 * Full Control flow between modules with values of all parameters
 */


#define IFX_DBG_TYPE_NONE    0
#define IFX_DBG_TYPE_CONSOLE 1
#define IFX_DBG_TYPE_FILE    2

typedef enum
{
   /* Common Errors */
   IFX_DBG_FIFO_CREATION_ERR,
   IFX_DBG_FIFO_OPEN_ERR,
   IFX_DBG_FIFO_READ_ERR,
   IFX_DBG_FIFO_WRITE_ERR,
   IFX_DBG_PROCESS_CREATION_ERR,
   IFX_DBG_GENERAL_ERR,
   IFX_DBG_INVALID_MSG_ERR,
   IFX_DBG_MSG_PROCESS_ERR,
   IFX_DBG_FUNC_ERROR,
   IFX_DBG_MODULE_INIT_ERR,
   IFX_DBG_CONFIG_FAILURE,
   IFX_DBG_SOCK_CREATE_ERR,
   IFX_DBG_SOCK_RECV_ERR,
   IFX_DBG_SOCK_SEND_ERR, 
   IFX_DBG_READ_FAILURE,
   IFX_DBG_WRITE_FAILURE,
   
   /* Memory Errors */

   IFX_DBG_MEM_LIB_INIT_ERR,
   IFX_DBG_MEM_ALLOC_ERR,
   IFX_DBG_MEM_FREE_ERR,

   /* Timer Errors */ 

   IFX_DBG_TIMER_LIB_INIT,
   IFX_DBG_TIMER_START_ERR,
   IFX_DBG_TIMER_STOP_ERR,
	IFX_DBG_TIMER_ERR,
   
   /* Common Informative Debugs */

   IFX_DBG_STR,
   IFX_DBG_INT,
   IFX_DBG_PROCESS_STARTED,
   IFX_DBG_MODULE_INITIALIZED,  
   IFX_DBG_MSG_RECEIVED,
   IFX_DBG_FUNC_SUCCESS,
   IFX_DBG_CONFIG_SUCCESS,
   IFX_DBG_SELECT_UNBLOCK,

   /* CM Info Type */
   IFX_DBG_CM_REQ_TYPE,
   IFX_DBG_CM_INFO_TYPE,
 
   /* Module Specific Errors */

   /* SIP */
   
   IFX_DBG_SIP_CM_IF,
   IFX_DBG_SIP_RTP_IF,
   IFX_DBG_SIP_RM_IF,
   IFX_DBG_SIP_PA_IF,
   IFX_DBG_SIP_SEND_ERR,
   IFX_DBG_SIP_HANDLE_RSP_ERR,
   IFX_DBG_SIP_HANDLE_REQ_ERR,
   IFX_DBG_SIP_CHANNEL_ID_ERR,
   IFX_DBG_SIP_RTP_PORT_ERR,
   IFX_DBG_SIP_REPLACE_ERR,
   IFX_DBG_SIP_CONTACT_HDR_ERR,
   IFX_DBG_SIP_ENC_ERR,
   IFX_DBG_SIP_DEC_ERR,
   IFX_DBG_SIP_ERR,
   IFX_DBG_SIP_SEND_RSP_ERR,
   IFX_DBG_SIP_ADDR,

   /* PA */
	IFX_DBG_PA_FD_OPEN_ERR,
	IFX_DBG_PA_FD_CLOSE_ERR,
	IFX_DBG_PA_FILE_ERR,
	IFX_DBG_PA_TIMEOUT,
	IFX_DBG_PA_ADDR_TYPE,
   IFX_DBG_PA_ADDR_INFO, 
   IFX_DBG_PA_TEL_ADDR_INFO, 
   IFX_DBG_PA_IGNR_EVNT,
   IFX_DBG_PA_FSM, 
   IFX_DBG_PA_FCN_RET_ERR,
   IFX_DBG_PA_AUTH,
   IFX_DBG_PA_SET_FREE,
   IFX_DBG_PA_SET_USED,
   IFX_DBG_PA_CONF_STATE,    
   IFX_DBG_PA_FIRST_CALL_STATE,
   IFX_DBG_PA_SECOND_CALL_STATE,
   IFX_DBG_PA_CALL_REGISTER,
   IFX_DBG_PA_DEVICE_MODE,
   IFX_DBG_PA_CALL_PROCESSING,
   IFX_DBG_PA_CURSOR,
   IFX_DBG_PA_CALL_CONF,
   IFX_DBG_PA_INBOX_DBG,
	IFX_DBG_PA_COMPOSE_DBG, 
   IFX_DBG_PA_RING_MUTE,
   IFX_DBG_PA_VOICE_PARAM,
	IFX_DBG_PA_VAL,


   /* ATA */
  /* Error */
   IFX_DBG_ATA_GENERAL_ERR,
   IFX_DBG_ATA_SIGNAL_ERR,
   IFX_DBG_ATA_CHANNEL_ERR,
   IFX_DBG_ATA_TONE_ERR,
   IFX_DBG_ATA_INTERFACE_ERR,
   IFX_DBG_ATA_DTMF_AUTH_ERR,
   IFX_DBG_ATA_DTMF_FEATCODE_ERR,
   IFX_DBG_ATA_DTMF_FEATINFO_ERR,

   /* Informative */
	IFX_DBG_ATA_FUNC_ENTRY_INFO,
	IFX_DBG_ATA_FUNC_EXIT_INFO,
	IFX_DBG_ATA_STRING_INFO,
	IFX_DBG_ATA_INT_INFO,
	IFX_DBG_ATA_SIGNAL_NUMBER,
   IFX_DBG_ATA_SHUTDOWN,
   IFX_DBG_ATA_DIALED_DIGIT,
   IFX_DBG_ATA_CHANNEL_NO,
   IFX_DBG_ATA_CONNECTIONID,
   IFX_DBG_ATA_FIFO_INFO,
   IFX_DBG_ATA_TAPI_EXCEPT_BIT,
   IFX_DBG_ATA_TAPI_EVENT,
   IFX_DBG_ATA_TIMEOUT_VALUE,
   IFX_DBG_ATA_CID_INFO,
   IFX_DBG_ATA_STATE_EVENT_INFO,
   IFX_DBG_ATA_DTMF_TIMER_STATUS,
   IFX_DBG_ATA_USERNAMEORPASSWD,
   IFX_DBG_ATA_DTMF_EXTN_NO_INFO,
   IFX_DBG_ATA_DTMF_PASSWD_INFO,
   IFX_DBG_ATA_DTMF_FEATINFOSTR,
   IFX_DBG_ATA_DTMF_DHCP_INFO,
   IFX_DBG_ATA_DTMF_CM_EXTN_TEST,
   IFX_DBG_ATA_DTMF_CM_INT_TEST,
   IFX_DBG_ATA_DTMF_CM_STRING_TEST,
   IFX_DBG_ATA_DTMF_DELIM_CNT,
   IFX_DBG_ATA_SUCC_EXIT_INFO,
   IFX_DBG_ATA_FAIL_EXIT_INFO,
   /* RTP */

   IFX_DBG_RTP_STR_ERR,
   IFX_DBG_RTP_STR_PRINT,
   IFX_DBG_RTP_IOCTL_STR_PRINT,
   IFX_DBG_RTP_RTCP_STR_PRINT,
   IFX_DBG_RTP_SIP_IF,
   IFX_DBG_RTP_RM_IF,
   IFX_DBG_RTP_SRTP_IF,

   /* VMAPI */

   IFX_DBG_VMAPI_SEC_CPEID,
   IFX_DBG_VMAPI_NV_PAIRS,
   IFX_DBG_VMAPI_NO_NV_PAIRS,
   IFX_DBG_VMAPI_OBJ_PREFIX,
   IFX_DBG_VMAPI_GET_STRING,
   IFX_DBG_VMAPI_BUF_FROM_CFG_BUF,
   IFX_DBG_VMAPI_DEVICE_CONFIG,
   IFX_DBG_VMAPI_NAME_AND_INSTANCE,
   IFX_DBG_VMAPI_PARAM_PREFIX_LEN,
   IFX_DBG_VMAPI_PARAM_PREFIX,
   IFX_DBG_VMAPI_OBJECT_TYPE_LIST,
   IFX_DBG_VMAPI_OBJECT_TYPE,
   IFX_DBG_VMAPI_CPEID_VAL,
   IFX_DBG_VMAPI_PCPEID_VAL,
   IFX_DBG_VMAPI_OBJ_FROM_NV_MISMATCH,
   IFX_DBG_VMAPI_GET_PARAM_TBL,
   IFX_DBG_VMAPI_GENERAL,
	 IFX_DBG_VMAPI_OBJ_SIZE,
   IFX_DBG_RM_GET_BW_ERR,
   IFX_DBG_RM_SUPP_CODECS,
   IFX_DBG_RM_CONFIG_CODECS,
   IFX_DBG_RM_CODEC_CHANGE,
   IFX_DBG_RM_PREF_CODEC_CHANGE_ERR,
   IFX_DBG_RM_CODEC_CHANGE_SUCCESS,
   IFX_DBG_RM_CODEC_CHANGE_FAIL,
   IFX_DBG_RM_LINK_BW_ERR,
   IFX_DBG_RM_FRAME_SIZE,
   IFX_DBG_RM_FUNC_PARAMS,
   IFX_DBG_RM_ALLOC_CODER_SUCCESS,
   IFX_DBG_RM_CODEC_BANDWIDTH,
   IFX_DBG_RM_FUNC_START,
   IFX_DBG_RM_LINK_BW,
   IFX_DBG_RM_FRAMESIZE_CM,
   IFX_DBG_RM_ERR_COUNT,
   IFX_DBG_RM_ERR_CODE,
   IFX_DBG_RM_PREF_CODEC,
   IFX_DBG_RM_ALLOC_CODER,
   IFX_DBG_RM_DEALLOC_CODER,
   IFX_DBG_RM_MODIFY_CODER,
   IFX_DBG_RM_ALLOC_CODEC,
   IFX_DBG_RM_SESS_BW,
   IFX_DBG_RM_ERR_REASON,
   IFX_DBG_RM_LOCK_CODEC,
   IFX_DBG_RM_CODER_MSG,
   IFX_DBG_RM_LOCK_UNLOCK,
   IFX_DBG_RM_LESS_BW_ERR,
   IFX_DBG_RM_LOCK_CODEC_INFO,
   IFX_DBG_RM_UNLOCK_CODEC_INFO,
   IFX_DBG_RM_ALLOC_ANALOG,
   IFX_DBG_RM_DEALLOC_ANALOG,
   IFX_DBG_RM_CONV_INFO,
   IFX_DBG_RM_FW_INFO,
   IFX_DBG_RM_DEV_NAME,
   IFX_DBG_RM_DEV_ERR,


   /* CM */
   IFX_DBG_CM_REQ_TYPE_ERR,
   IFX_DBG_CM_INFO_TYPE_ERR,
   IFX_DBG_CM_CFG_FILE_ABSENT,
   IFX_DBG_CM_CFG_FILE_VER_ERR,
   IFX_DBG_CM_CFG_FILE_READ_ERR,
   IFX_DBG_CM_CFG_FILE_WRITE_ERR,
   IFX_DBG_CM_CFG_FILE_WRITE_SIZE,
   IFX_DBG_CM_CFG_FILE_WRITE_INFO,

   /* SRTP */

   IFX_DBG_SRTP_STREAM_ERR,
   IFX_DBG_SRTP_PKT_ROC,
   IFX_DBG_SRTP_FROM_TO_EXPIRY,
   IFX_DBG_SRTP_ENABLE_ENC_DEC_ERR,
   IFX_DBG_SRTP_ENC_DEC_ERR,
   IFX_DBG_SRTP_SSRC,
   IFX_DBG_SRTP_PKT_LEN,
   IFX_DBG_SRTP_AUTH_ERR,
   IFX_DBG_SRTP_AUTH_SUCCESS,
   IFX_DBG_SRTP_SEQ_NUM,
   IFX_DBG_SRTP_HIGH_SEQ_NUM,
   IFX_DBG_SRTP_REKEY,
   IFX_DBG_SRTP_SESS_KEY_REFRESH,
   IFX_DBG_SRTP_PKT_IDX,
   IFX_DBG_SRTP_REPLAY_LIST_UPDATE,
   IFX_DBG_SRTP_MKI_MISMATCH_ERR,

   /* Fax */

   IFX_DBG_FA_SEND_PKT_TO_NET,
   IFX_DBG_FA_END_OF_FAX,
   IFX_DBG_FA_GET_STATS_ERR,
   IFX_DBG_FA_SESS_START_ERR,
   IFX_DBG_FA_SESS_STOP_ERR,
   IFX_DBG_FA_GENERAL_ERR,
   IFX_DBG_FA_SEND_DATA_TO_DP,
   IFX_DBG_FA_FUNC_START,
   IFX_DBG_FA_DP_ERR,
   IFX_DBG_FA_FUNC_SUCCCESS,
   IFX_DBG_FA_FUNC_FAIL,
   IFX_DBG_FA_RX_MSG,
   IFX_DBG_FA_RX_ERR_MSG,
   IFX_DBG_FA_INIT_PARAM,
   IFX_DBG_FA_REMOTE_ADDR,
   IFX_DBG_FA_SESS_REQ,
   IFX_DBG_FA_T38_PARAM,
   IFX_DBG_FA_ERR_REASON,
   IFX_DBG_FA_DATA,
   IFX_DBG_FA_CHANNEL,
	IFX_DBG_FA_HEX_DISPLAY,
  IFX_DBG_GENERIC,
   
} x_IFX_DBG_Types;

#if defined(DEV_DEBUG) || defined(CUST_DEBUG)
EXTERN void IFX_DBG_Init(IN char8 * pcModuleName, IN char8 ucDbgType,
             IN char8 ucDbgLvl, OUT uchar8 * pucModuleId, OUT char8 * pcRet);

EXTERN char8 IFX_DBG_Set(IN char8 * pcModuleName, IN uchar8 cModuleId,
            IN char8 ucDbgType, IN char8 ucDbgLvl);

EXTERN void IFX_DBG_Shut(IN uchar8  ucModuleId, OUT char8 * pcRet);

EXTERN void IFX_DBG_Log(IN uchar8 ucModuleId, IN uchar8 ucDbgLvl, IN const char8 *pucFuncName,
             IN char8 * pucStr,  ...);

EXTERN char8 * vacMsgTbl[];

#else /* DEV_DEBUG */

#define IFX_DBG_Init(pcModuleName, ucDbgType, ucDbgLvl, pucModuleId, pcRet) \
{ \
   *pcRet = 0; \
}

#define IFX_DBG_Set(pcModuleName, cModuleId, ucDbgType, ucDbgLvl) 

#define IFX_DBG_Shut(ucModuleId, pcRet) \
{ \
   *pcRet = 0; \
}

#ifdef __LINUX__
#define IFX_DBG_Log(ucModuleId, ucDbgLvl, pucStr, ...)

#endif 
#endif /* DEV_DEBUG */

#ifdef __IMSENV__
#ifdef DEV_DEBUG
PUBLIC void
IFX_DBGA(IN uchar8 ucModuleId,IN uchar8 ucDbgLvl,IN uint16 unMsgId,...);

#define IFX_DBGC IFX_DBGA
#endif

#ifdef CUST_DEBUG
PUBLIC void
IFX_DBGA(IN uchar8 ucModuleId,IN uchar8 ucDbgLvl,IN uint16 unMsgId,...){};

PUBLIC void
IFX_DBGC(IN uchar8 ucModuleId,IN uchar8 ucDbgLvl,IN uint16 unMsgId,...);

#endif
#if 0
PUBLIC void
IFX_DBG(IN uchar8 ucModuleId,
		IN uchar8 ucDbgLvl,
		IN uint16 unMsgId);
#endif
#endif 
#ifdef __LINUX__
#ifdef DEV_DEBUG
#define IFX_DBGA(ucModuleId, ucDbgLvl, unMsgId, ...) \
{ \
   IFX_DBG_Log(ucModuleId, ucDbgLvl, __FUNCTION__ ,vacMsgTbl[unMsgId], __VA_ARGS__); \
}
#define IFX_DBGC IFX_DBGA
#endif

#ifdef CUST_DEBUG
#define IFX_DBGC(ucModuleId, ucDbgLvl, unMsgId, ...) \
{ \
   IFX_DBG_Log(ucModuleId, ucDbgLvl, __FUNCTION__ ,vacMsgTbl[unMsgId], __VA_ARGS__); \
}
#define IFX_DBGA(ucModuleId, ucDbgLvl, unMsgId, ...) 
#endif
#if 0
#define IFX_DBG(ucModuleId, ucDbgLvl, unMsgId) \
{ \
   IFX_DBG_Log(ucModuleId, ucDbgLvl, __FUNCTION__ ,vacMsgTbl[unMsgId]); \
}
#endif
#endif
#endif /* __IFX_DEBUG_H__ */
