/**************************************************************************
 **   FILE NAME		: ifx_os.h
 **   PROJECT		: OS Interface
 **   MODULES	      	: Common OS layer for Infineon Modules
 **   SRC VERSION	: V1.0
 **
 **   DATE				  	: 2-11-2004
 **   AUTHOR			  	: Hari
 **   DESCRIPTION			: This file contains common OS wrappers and C 
 **                       library functions.	
 **   FUNCTIONS			:	
 **   COMPILER				:
 **   REFERENCE			:
 **							
 **   COPYRIGHT			: Infineon Technologies AG 2003-2004

 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/

#ifndef __IFX_OS_H__
#define __IFX_OS_H__

#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <string.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <ctype.h>
#include <features.h>
#include <ctype.h>
#include <netdb.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define IFX_OS_PROTOCOL_TCP 1
#define IFX_OS_PROTOCOL_UDP 2
#define IFX_OS_TCP_SOCKTYPE_CLIENT 1
#define IFX_OS_TCP_SOCKTYPE_SERVER 2

/********** Fifo Operations **********/

EXTERN int32 IFX_OS_CreateFifo(IN uchar8 * pucName);

#define IFX_OS_RemoveFifo(pucName, Fd) \
{ \
   close(Fd); \
   unlink(pucName); \
}

EXTERN int32 IFX_OS_OpenFifo(IN uchar8 * pucName, IN int32 iFlags);

#define IFX_OS_CloseFifo(Fd) close(Fd)

#define IFX_OS_ReadFifo(iFd, pcRead, iSize) read(iFd, pcRead, iSize)

#define IFX_OS_WriteFifo(iFd, pcWrite, iSize) write(iFd, pcWrite, iSize)


/********** Socket Operations **********/

EXTERN int32
IFX_OS_CreateSocket(IN uchar8 ucProtocol,
                    IN uint16 unLocalPort,
                    IN uint16 unRemotePort,
                    IN char8 * pacRemoteIpAddress,
                    IN uchar8 ucTcpSocketType);

#define IFX_OS_FdZero(pFdSet) FD_ZERO(pFdSet)

#define IFX_OS_FdClear(iFd, pFdSet) FD_CLR(iFd, pFdSet)

#define IFX_OS_FdSet(iFd, pFdSet) FD_SET(iFd, pFdSet)

#define IFX_OS_FdIsSet(iFd, pFdSet) FD_ISSET(iFd, pFdSet)

EXTERN int32 IFX_OS_Select(IN fd_set * pRdSelectFd, IN fd_set * pWrSelectFd, 
              IN fd_set * pExSelectFd, IN int32 iTimeSec);

#define IFX_OS_Read(iFd, pcRead, iSize) read(iFd, pcRead, iSize)

#define IFX_OS_Write(iFd, pcWrite, iSize) write(iFd, pcWrite, iSize)

#define IFX_OS_Close(Fd) close(Fd)

#define IFX_OS_fd_set fd_set

/********** Memory Operations **********/

#define IFX_OS_Memset(pvDst, iChar, uiSize) \
{ \
   uchar8 * pucPtr = (uchar8 *) pvDst; \
   while (uiSize--) \
   { \
      *pucPtr++ = (uchar8) iChar; \
   } \
}

#define IFX_OS_Memcpy(pvDst, pvSrc, uiSize) \
{ \
   uchar8 * pucDst1 = (uchar8 *) pvDst ; \
   uchar8 * pucSrc1 = (uchar8 *) pvSrc ; \
   while (uiSize--) \
   { \
      *pucDst1++ = *pucSrc1++; \
   } \
}

EXTERN int32 IFX_OS_Memcmp(IN const void * pPtr1, IN const void * pPtr2,
              IN uint32 uiSize);

/********** String Operations **********/

EXTERN int32 IFX_OS_Strlen(IN const char8 * pcPtr);

EXTERN char8 * IFX_OS_Strcpy(IN char8 * pcDst, IN const char8 * pcSrc);

/********** Network Operations **********/

EXTERN char8 IFX_OS_GetHostIp(OUT char8 * pcHostIp);

EXTERN char8 IFX_OS_GetHostNetmask(OUT char8 * pcHostNetmask);

EXTERN int32 IFX_OS_SetIp(IN char8 * pcIpAdd);

EXTERN int32 IFX_OS_SetNetmask(IN char8 * pcNetmask);

char8 IFX_OS_GetHostMac(IN char8 * pcIntfaceName, OUT char8 * pcHostMac);
/************** File Operations ****************/
#ifndef IFX_OS_OpenFile
#define IFX_OS_OpenFile(pcFileName, iFlag) open(pcFileName, iFlag)
#endif

#define IFX_OS_CloseFile(Fd) close(Fd)

#define IFX_OS_DeleteFile(pcName, Fd) \
{ \
   close(Fd); \
   unlink(pcName); \
}

#define IFX_OS_ReadFile(iFd, pcRead, iSize) read(iFd, pcRead, iSize)

#define IFX_OS_WriteFile(iFd, pcWrite, iSize) write(iFd, pcWrite, iSize)

#define IFX_OS_Lseek(Fd, OffSet, Whence) lseek(Fd, OffSet, Whence)

/*************** Memory Operations ***************/
#if 0
#define IFX_OS_Malloc(iBytes) malloc(iBytes)
#define IFX_OS_Free(pBuff) free(pBuff)

#ifdef COMPILE

#endif
#endif

/**********************System V Shared Memory **************/

/* Create a shared memory*/
#define IFX_OS_ShmCreate(iKey,iSize,iFlag) shmget(iKey,iSize,iFlag)

/* Attach shared memory to the process*/
#define IFX_OS_ShmAttach(iShmId,pcShmAddr,iFlag) shmat(iShmId,pcShmAddr,iFlag)

/*Detach the shared memory form the process*/
#define IFX_OS_ShmDetach(pcShmAddr) shmdt(pcShmAddr)

/* Control operations on Shared memory*/
#define IFX_OS_ShmCtl(iShmId, iCommand, pxShmidDs) shmctl(iShmId, iCommand, pxShmidDs)
/**********************System V Semphore **********************/

/* Create a named Semaphore */
#define IFX_OS_SemCreate(iKey,iNSems,iFlag) semget(iKey,iNSems,iFlag)

/* Control semphore operations*/
#define IFX_OS_SemCtl(iSemId,iSemNum,iCmd,arg ) semctl(iSemId,iSemNum,iCmd,arg )

/* Remove semaphore */
#define IFX_OS_RemoveSem(iSemId,iSemNum) semctl(iSemId,iSemNum,IPC_RMID)

/* Sempaphore operations*/
#define IFX_OS_SemOp(iSemId,pxSemBuff,iNoSems) semop(iSemId,pxSemBuff,iNoSems)

/* Lock Semphore*/
EXTERN int32 IFX_OS_LOCK(IN int32 iSemId);

/*Unlock Semphore*/
EXTERN int32 IFX_OS_UNLOCK(IN int32 iSemId);

/* Sempahore argument passing union */
typedef union
{
   int32 val;
   struct semid_ds *buff;
   uint16 *array;
 } ux_IFX_OS_SEMUN;


/******************System V Utility Functions****************/

/* Function used in generating Keys from Path names */
#define IFX_OS_FTOK(pcName,iProjId) ftok(pcName,iProjId)

/* MD5 context */

typedef struct
{
  uint32 state[4];        /* state (ABCD) */
  uint32 count[2];        /* number of bits, modulo 2^64 (lsb first) */
  uchar8 buffer[64];      /* input buffer */
} MD_CT;

/* Macros */

#if PROTOTYPES
   #define PROTO_LIST(list) list
#else
   #define PROTO_LIST(list) ()
#endif


/* Constants for MD5Transform routine. */

#define S11 7
#define S12 12
#define S13 17
#define S14 22
#define S21 5
#define S22 9
#define S23 14
#define S24 20
#define S31 4
#define S32 11
#define S33 16
#define S34 23
#define S41 6
#define S42 10
#define S43 15
#define S44 21

/* F, G, H and I are basic MD5 functions.  */

#define F(x, y, z) (((x) & (y)) | ((~x) & (z)))
#define G(x, y, z) (((x) & (z)) | ((y) & (~z)))
#define H(x, y, z) ((x) ^ (y) ^ (z))
#define I(x, y, z) ((y) ^ ((x) | (~z)))

/* ROTATE_LEFT rotates x left n bits. */

#define ROTATE_LEFT(x, n) (((x) << (n)) | ((x) >> (32-(n))))


/*
 * FF, GG, HH, and II transformations for rounds 1, 2, 3, and 4.
 * Rotation is separate from addition to prevent recomputation.
 */

#define FF(a, b, c, d, x, s, ac) { (a) += F ((b), (c), (d)) + (x) + (uint32)(ac); \
(a) = ROTATE_LEFT ((a), (s)); (a) += (b); \
}

#define GG(a, b, c, d, x, s, ac) { (a) += G ((b), (c), (d)) + (x) + (uint32)(ac); \
(a) = ROTATE_LEFT ((a), (s));  (a) += (b); \
 }

#define HH(a, b, c, d, x, s, ac) { (a) += H ((b), (c), (d)) + (x) + (uint32)(ac); \
(a) = ROTATE_LEFT ((a), (s));  (a) += (b); \
 }

#define II(a, b, c, d, x, s, ac) { (a) += I ((b), (c), (d)) + (x) + (uint32)(ac); \
(a) = ROTATE_LEFT ((a), (s)); (a) += (b); \
}


typedef uchar8 *POINTER;

uint32  IFX_MD5_GetRandomValue( void );
/**********************************************
							 MEMORY OPERATIONS
 **********************************************/
#ifdef MEM_DBG
typedef struct x_IFX_OS_DbgMem
{
	void *vId;
	int32 iSize;
	char acFile[100];
	int32 iLine;
	struct x_IFX_OS_DbgMem *pxNext;
}x_IFX_OS_DbgMem;

/*void* IFX_OS_Malloc(int32 uiSize);
void* IFX_OS_Calloc(int32 uiNum,int32 uiSize);
int32 IFX_OS_Free(void *pcFree);*/
				
void
IFX_OS_MemInfo();

void*
IFX_OS_CallocDbg(int32 iNum,int32 iSize, char8 *pcFile, int32 iLine);

int32
IFX_OS_FreeDbg(void* pcFree, char8 *pcFile, int32 iLine);

#define IFX_OS_Calloc(iNum,iSize) IFX_OS_CallocDbg(iNum,iSize,__FILE__,__LINE__)

#define IFX_OS_Malloc(iSize)  IFX_OS_CallocDbg(1,iSize,__FILE__,__LINE__)

#define IFX_OS_Free(pcFree)  (IFX_OS_FreeDbg(pcFree,__FILE__,__LINE__))

#define IFX_OS_MLIBInit()    IFX_OS_SUCCESS

#else
void* IFX_OS_Malloc(uint32 iBytes); 
void* IFX_OS_Calloc(int32 uiNum,int32 iBytes); 
void IFX_OS_Free(void *pBuff);

#endif /*MEM_DBG*/
/*****************************************************
                  THREAD SAFE OPERATION
******************************************************/                  
#ifdef __LINUX__
typedef int32 x_IFX_OS_LockType;
/* Sempahore argument passing union */
typedef union
{
   int32 val;
   struct semid_ds *buff;
   uint16 *array;
 } ux_IFX_SIP_SEMUN;
int32 IFX_OS_LockAcquire(x_IFX_OS_LockType xLock);
int32 IFX_OS_LockRelease(x_IFX_OS_LockType xLock);
int32 IFX_OS_LockCreate(x_IFX_OS_LockType *pxLock);
int32 IFX_OS_LockDestroy(x_IFX_OS_LockType *pxLock);
#endif

uint32 IFX_OS_CreateThread( void * (*start_routine)(void *),void* pvParam);
#ifdef __LINUX__
#define IFX_OS_ThreadExit(pRet)  pthread_exit(pRet)
#define IFX_OS_ThreadSelf() pthread_self()
#define IFX_OS_ThreadCleanUpPush(Pfn,Id) pthread_cleanup_push(Pfn,Id)
#define IFX_OS_ThreadCleanUpPop(x) pthread_cleanup_pop(x)
#endif
#endif /* __IFX_OS_H__ */
