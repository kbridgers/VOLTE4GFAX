/******************************************************************************
 **   SRC_FILE			: IFIN_TLIB_Import.h
 **   PROJECT			: EasyPort/IAD, DC BANGALORE
 **   MODULES			:
 **   SRC VERSION		: Version 1.0
 **   DATE				: 11-02-2003
 **   AUTHOR			: Bharathraj Shetty
 **   DESCRIPTION		:
 **   FUNCTIONS			: None
 **   COMPILER			:
 **   REFERENCE			:
						Coding Guidelines (Easyport-VSS-COD-V1.0)
                    	Author: EasyPort Team
 **   COPYRIGHT			: Infineon Technologies AG 1999-2003
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
 *****************************************************************************/



#ifndef _IFIN_TLIB_IMPORT_H_
# define _IFIN_TLIB_IMPORT_H_

#define IFIN_TLIB_ONE_TIME_TIMER 0
#define IFIN_TLIB_PERIODIC_TIMER 1

#define IFIN_TLIB_FAIL 0
#define IFIN_TLIB_SUCCESS 1
#define IFIN_TLIB_INVALID_TIMER_ID 2

typedef void (* pfnVoidFunctPtr)(void *);

int8 IFIN_TLIB_TimersInit(uint16 unNumOfTimers);

int8 IFIN_TLIB_StartTimer(uint16 *punTimerId,uint32 uiTimerValue,
		uint8 ucTimerType, pfnVoidFunctPtr pfn_IFIN_TLIB_CallBackfn,
	  void *pCallBackFnParm);

int8 IFIN_TLIB_StopTimer(uint16 unTimerId);

int8 IFIN_TLIB_TimersDelete(void);

#endif
