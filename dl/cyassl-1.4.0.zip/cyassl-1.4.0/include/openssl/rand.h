/* rand.h for openSSL */

#include "ssl.h"


