/* ocsp.h for libcurl */
