#define _GNU_SOURCE
#include <stdio.h>
#include <signal.h>
#include <sys/select.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <time.h>
#include <sys/file.h>
#include <sys/queue.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <syslog.h>


#define MAX_BUF 1024
#define DWATCH_FIFO	"/tmp/dwatch_fifo"
#define PID_FILE        "/var/run/daemon_watch.pid"
#define DWATCH_SOCK_PATH "/tmp/dwatch_socket"
#define DWATCH_SIGCHILD_WT 3

typedef enum dcommand { DAEMON_START, DAEMON_STOP, DAEMON_STATUS, DAEMON_SHOW } dcommand;
typedef enum dstate { DSTATE_STOPPED, DSTATE_RUNNING, DSTATE_ERR, DSTATE_INIT, DSTATE_END } dstate;
typedef enum dmethod { DMETHOD_ADD, DMETHOD_DELETE, DMETHOD_NONE } dmethod;


typedef struct daemon_info {
	char *cmd[64];	/* command */
	pid_t pid;	/* current pid of command = -1 if not running */
	int	delay;	/* Delay before respawn */
	LIST_ENTRY(daemon_info) entries;     	/* List. */
	char key_name[32];
	char cmd_str[512];
	time_t touched;
	int respwn_cnt;
	dstate dstate;
} daemon_info_t;

typedef struct client_info {
	char *arg[32];
	char *action;
	int client;
} client_info_t;

LIST_HEAD(dlist_head, daemon_info) ;

LIST_HEAD(cmdlist_head, dwcmd_entry) ;

typedef struct dwatch {
	char	*argv0;
	int	argv0len;
	struct dlist_head head;
	struct dlist_head *headp;
	struct cmdlist_head cmdlist;
	int cmd_fifo;
	sigset_t os;
	int cmd_fg;
	client_info_t ci;
	daemon_info_t *di;
} dwatch_t;
struct dwcmd_entry;
typedef int (*dwcmdfun) (dwatch_t *dw, struct dwcmd_entry *ce);
typedef struct dwcmd_entry {
	LIST_ENTRY(dwcmd_entry) entries;     	/* List. */
	char *cmdstr;
	dwcmdfun fp;
	char *help;
} dwcmd_entry_t;


extern struct dlist_head * init_list(struct dlist_head *);
int cmd_fifo_read(int fifo);
int open_cmd_fifo();
int close_cmd_fifo(int fifo);


extern int list_add(struct dlist_head *, struct daemon_info *node);
extern int list_show(struct dlist_head *, struct client_info *ci);
extern int list_node_delete(struct dlist_head *, char *key_name);
extern int list_delete(struct dlist_head *);
struct daemon_info * list_find(struct dlist_head *, char *key_name);
extern init_dwctl_cmds(dwatch_t *dw);



extern int read_and_process_client(dwatch_t *,int client);
extern int process_client(dwatch_t *dw);
extern int process_cmd(dwatch_t *dw);
extern int start_process(dwatch_t *dw, struct daemon_info *entry);
extern int stop_process(dwatch_t *dw, struct daemon_info *entry);
extern sigset_t unmask_sigchld(dwatch_t *dw);


#define debug_print(fmt, args...)  syslog(LOG_INFO, fmt, ##args)
