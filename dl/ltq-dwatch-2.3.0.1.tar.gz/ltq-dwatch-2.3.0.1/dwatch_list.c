#include <stdio.h>
#include <sys/queue.h>
#include <string.h>
#include <stdlib.h>
#include "dwatch.h"

struct dlist_head * init_list(struct dlist_head *hd)
{
	memset(hd, '\0', sizeof(struct dlist_head));
	return hd;
}

int list_add(struct dlist_head *headp, struct daemon_info *node)
{
	if (node == NULL) {
		debug_print("Null node");
		return -1;
	}
	LIST_INSERT_HEAD(headp, node, entries);
	return 0;
}

struct daemon_info *list_find(struct dlist_head *headp, char *key_name)
{
	struct daemon_info *np;
	for (np = headp->lh_first; np != NULL; np = np->entries.le_next) {
		if (strcmp(np->key_name, key_name) == 0) {
			return np;
		}
	}
	return NULL;
}

int list_show(struct dlist_head *headp, struct client_info *ci)
{
	struct daemon_info *np;
	char local_buf[256];
	char local_cmdbuf[256];
	int client = -1;
	char *dstate[] = { "STOPPED", "RUNNING", "ERR", "INIT" };
	FILE *c;
	if (ci != NULL) {
		client = ci->client;
	}

	snprintf(local_buf, sizeof(local_buf), "%-15s %-8s %-12s %-5s %-7s\n", "KEYNAME",
		 "PID", "STATUS", "DELAY", "CRASHED");
	send(client, local_buf, strlen(local_buf), 0);
	for (np = headp->lh_first; np != NULL; np = np->entries.le_next) {
		int i = 0;
		char *p = local_cmdbuf;
		int written = 0;
		while (np->cmd[i] != NULL
		       && i < sizeof(np->cmd) / sizeof(np->cmd[0])) {
			int ret =
			    snprintf(p, sizeof(local_cmdbuf) - written, "%s ",
				     np->cmd[i]);
			if (ret < 0 || ret >= sizeof(local_cmdbuf) - written) {
				break;
			}
			written += ret;
			p += ret;
			i++;
		}

		snprintf(local_buf, sizeof(local_buf), "%-15s %-8d %-12s %-5d %-7d\n",
			 np->key_name, np->pid, 
			(np->dstate < DSTATE_END && np->dstate >= 0) ? dstate[np->dstate]:"INVALID", 
			np->delay, np->respwn_cnt);
		send(client, local_buf, strlen(local_buf), 0);
	}
	return 0;
}

int list_node_delete(struct dlist_head *headp, char *key_name)
{
	struct daemon_info *np;
	for (np = headp->lh_first; np != NULL; np = np->entries.le_next) {
		if (strcmp(np->key_name, key_name) == 0) {
			struct daemon_info *tmp = np;
			LIST_REMOVE(np, entries);
			free(tmp);
		}
	}
}

int list_delete(struct dlist_head *headp)
{
	while (headp->lh_first != NULL) {	/* Delete. */
		struct daemon_info *tmp = headp->lh_first;
		LIST_REMOVE(headp->lh_first, entries);
		free(tmp);
	}
}
