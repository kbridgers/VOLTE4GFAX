#include "dwatch.h"
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

#define sendinfo(sock, fmt, args...) \
({\
	char tbuf[128];\
	int i = snprintf(tbuf, sizeof(tbuf), fmt, ##args);\
	i = send(sock, tbuf, i, 0);\
})

	
char *get_cmd_value(char *varval, const char *var)
{
	int sl_valval=strlen(varval);
	int sl_var=strlen(var);
	if(sl_var < sl_valval && strncmp(var, varval, sl_var) == 0 ) {
		return varval+sl_var;
	}
	return NULL;
}

char *get_dwcmdval(dwatch_t *dw, const char *name)
{
	client_info_t *ci = &dw->ci;
	int i = 0;
	while(ci->arg[i] != NULL && i < sizeof(ci->arg)/sizeof(ci->arg[0])) {
		int r = strncmp(name, ci->arg[i], strlen(name));
		if(r == 0) {
			return get_cmd_value(ci->arg[i], name);
		}
		i++;
	}
	return NULL;
}
int register_dwctlcmd(struct cmdlist_head *hp, char *action, dwcmdfun fun, char *help)
{
	dwcmd_entry_t *dwcmd = malloc(sizeof(*dwcmd));
	if(dwcmd == NULL) {
		debug_print("Unable to allocate memory for command\n");
		return -1;
	}
	memset(dwcmd, '\0', sizeof(*dwcmd));
	dwcmd->cmdstr=action;
	dwcmd->fp=fun;
	dwcmd->help = help;
	LIST_INSERT_HEAD(hp, dwcmd, entries);
}
	
int dwexec_cmd(dwatch_t *dw, char *action)
{
	dwcmd_entry_t *np;
	struct cmdlist_head *headp = &dw->cmdlist;
	for (np = headp->lh_first; np != NULL; np = np->entries.le_next) {
		if (strcmp(np->cmdstr, action) == 0) {
			return (*np->fp)(dw, np);
		}
	}
	return -1;
}


	
int dwctlcmd_start(dwatch_t *dw, dwcmd_entry_t *ce)
{
	client_info_t *ci = &dw->ci;
	char 	*keyname=ci->arg[1];
	struct 	daemon_info *entry = NULL;
	char 	strbuf[128];
	int	i;
	if(keyname == NULL) {
		sendinfo(ci->client, ce->help);
		return -1;
	}
	entry = list_find(dw->headp, keyname);
        if(entry == NULL) {
		sendinfo(ci->client, "No entry found for %s\n", keyname);
		return -1;
	}
	start_process(dw, entry);
	sendinfo(ci->client, "successfully started  %s(pid%d)\n", keyname, entry->pid);
}
int dwctlcmd_stop(dwatch_t *dw, dwcmd_entry_t *ce)
{
	client_info_t *ci = &dw->ci;
        char    *keyname=ci->arg[1];
        struct  daemon_info *entry = NULL;
        char    strbuf[128];
        int     i;
        if(keyname == NULL) {
                sendinfo(ci->client, ce->help);
                return -1;
        }
        entry = list_find(dw->headp, keyname);
        if(entry == NULL) {
                sendinfo(ci->client, "No entry found for %s\n", keyname);
                return -1;
        }
	stop_process(dw, entry);
        sendinfo(ci->client, "killed  %s(pid%d)\n", keyname, entry->pid);
}
int dwctlcmd_add(dwatch_t *dw, dwcmd_entry_t *ce)
{
	char *cmd=get_dwcmdval(dw, "CMD=");
	char *keyname=get_dwcmdval(dw, "KEYNAME=");
	char *delay=get_dwcmdval(dw, "DELAY=");
	int d = 0;
        int i = 0;
        struct daemon_info *di;
	client_info_t *ci = &dw->ci;
	char *str;
	char *result = NULL;
	int dontfree=0;
	if(cmd == NULL || keyname == NULL) {
                sendinfo(ci->client, ce->help);
                return -1;
	}
	if(delay != NULL) {
		d = atoi(delay);
		if(d < 0 || d > 30) {
			sendinfo(ci->client, "please specify a valid delay bw 0 - 30 \n"); 
			return -1;
		}
	}


	di = malloc(sizeof(struct daemon_info));
        if (di == NULL) {
                debug_print("unable to allocate memory\n");
                sendinfo(ci->client, "unable to allocate memory\n");
                return -1;
        }

	snprintf(di->cmd_str, sizeof(di->cmd_str), "%s", cmd);
	snprintf(di->key_name, sizeof(di->key_name), "%s", keyname);
	di->delay = d;
	str = di->cmd_str;
	do {
		result = strtok(str, " ");
		di->cmd[i++] = result;
		str = NULL;
	} while (result != NULL
		 && i < sizeof(di->cmd) / sizeof(di->cmd[0]));
	di->cmd[i] = NULL;
	di->dstate = DSTATE_STOPPED;
	if (list_find(dw->headp, di->key_name) == NULL) {
        	list_add(dw->headp, di);
                dontfree = 1;
        } else {
                debug_print("Entry already exists\n");
                sendinfo(ci->client, "Entry %s already exists\n", keyname);
        }
	if(dontfree != 1) {
		free(di);
	}
	return 0;
}
int dwctlcmd_del(dwatch_t *dw, dwcmd_entry_t *ce)
{
	char *keyname=dw->ci.arg[1];
        struct daemon_info *entry = NULL;
	entry = list_find(dw->headp, keyname);
        if (entry != NULL) {
        	stop_process(dw, entry);
               list_node_delete(dw->headp, entry->key_name);
               sendinfo(dw->ci.client, "Entry %s deleted successfully\n", keyname);
		return 0;
        }
        sendinfo(dw->ci.client, "Entry %s does not exist\n", keyname);
	return -1;
}
int dwctlcmd_show(dwatch_t *dw, dwcmd_entry_t *ce)
{
	list_show(dw->headp, &dw->ci);
}

int dwctlcmd_help(dwatch_t *dw, dwcmd_entry_t *ce)
{
	dwcmd_entry_t *np;
        struct cmdlist_head *headp = &dw->cmdlist;
        for (np = headp->lh_first; np != NULL; np = np->entries.le_next) {
               	sendinfo(dw->ci.client, "***%s***\n%s\n", np->cmdstr, np->help);
        }
}


	
init_dwctl_cmds(dwatch_t *dw)
{
	memset(&dw->cmdlist, '\0', sizeof(dw->cmdlist));
	register_dwctlcmd(&dw->cmdlist, "start", dwctlcmd_start, "start daemon. \ne.g \"dwatchctl start mini_httpd\"\n");
	register_dwctlcmd(&dw->cmdlist, "stop", dwctlcmd_stop, "stop daemon. \ne.g \"dwatchctl stop mini_httpd\"\n");
	register_dwctlcmd(&dw->cmdlist, "add", dwctlcmd_add, "add daemon to watch list. \ne.g \"dwatchctl add CMD=\"mini_httpd -c /etc/mh.conf\" KEYNAME=\"mini_httpd\" DELAY=3\n");
	register_dwctlcmd(&dw->cmdlist, "del", dwctlcmd_del, "delete daemon from watch list \ne.g \"dwatchctl del mini_httpd\"\n");
	register_dwctlcmd(&dw->cmdlist, "show", dwctlcmd_show, "show daemon status \ne.g \"dwatchctl show\"\n");
	register_dwctlcmd(&dw->cmdlist, "help", dwctlcmd_help, "show dwatchctl help \ne.g \"dwatchctl help\"\n");
}

int process_cmd(dwatch_t *dw)
{
	struct daemon_info *di;
	char action_str[32] = { 0 };
	dcommand dcmd;
	char *result = NULL;
	struct daemon_info *entry = NULL;
	dmethod dmeth = DMETHOD_NONE;
	int dontfree = 0;
	int res = 0;
	int client = -1;
	int i=0;
	client_info_t *ci = &dw->ci;
	if (ci == NULL) {
		return -1;
	}
	dwexec_cmd(dw, ci->arg[0]);
}

