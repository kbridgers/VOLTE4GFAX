#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <sys/select.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <time.h>
#include <sys/file.h>
#include <fcntl.h>
#include <errno.h>
#include "dwatch.h"

/* pid file to keep running status of dwatch daemon */
sigset_t unmask_sigchld(dwatch_t *dw);

/* function: get_basename
 * strip directory name from path name */

static char *get_basename(char *path)
{
	static char basename[32];
	char *loccur = NULL;
	memset(basename, 0, sizeof(basename));
	loccur = strrchr(path, '/');
	if (loccur) {
		loccur++;
		strcpy(basename, loccur);
		return basename;
	}
	return path;

}

/* function: daemon_spawn
 * spawn daemon which will be child of dwatch daemon */
static int daemon_spawn(dwatch_t *dw, pid_t old_pid)
{
	char cmd[256];
	pid_t new_pid;
	int found = 0;
	struct dlist_head *headp = dw->headp;	
	struct daemon_info *np = NULL;
	int i = 0;
	
	for (np = headp->lh_first; np != NULL; np = np->entries.le_next) {
		if (old_pid == np->pid) {
			found = 1;
			debug_print("cmd=%s, delay=%d, pid=%d\n", np->cmd[0],
				    np->delay, np->pid);
			break;
		}
	}
	if (np == NULL) {
		debug_print("Unable to find daemon info for old pid %d\n",
			    old_pid);
		return -1;
	}
	while (np->cmd[i] != NULL && i >= sizeof(np->cmd) / sizeof(np->cmd[0])) {
		debug_print("cmd[%d]=%s\n", i, np->cmd[i]);
		i++;
	}

	if (np->dstate != DSTATE_RUNNING) {
		debug_print("cmd=%s's  state is not DSTATE_RUNNING \n",
			    np->cmd[0] ? : "NULL");
		return -1;
	}

	if (found == 0) {
		debug_print ("Error: died process (pid:%d) not found in linked list\n", 
			np->pid);
		return -1;
	}


	new_pid = fork();
	if (new_pid == 0) {
/*
		snprintf(cmd, sizeof(cmd), "killall -9 %s 2>/dev/null", 
			get_basename(np->cmd[0]));
		system(cmd);
*/

		unmask_sigchld(dw);
		strncpy(dw->argv0, np->cmd[0], dw->argv0len); 
		sleep(2+np->delay);
		if (execvp(np->cmd[0], &np->cmd[0]) == -1) {
			printf("Failed to start '%s' \n", np->cmd[0]);
			exit(EXIT_FAILURE);
		}
	} else {
		np->respwn_cnt++;
		np->pid = new_pid;
		printf("Process[%s]: %d\n", np->cmd[0], new_pid);
	}
	return;
}

/*
 * The SIGCHLD signal handler function -- only gets called when a SIGCHLD
 * is received, ie when a child terminates
 */
void sigchld(int signo)
{
	puts("SIGCHLD\n");
}

void common_sighandler(int iSigNum)
{
	int iRet = 0, iWrFd = 0;

	switch (iSigNum) {
	case SIGTERM:
		puts("SIGTERM\n");
		remove(PID_FILE);
		exit(SIGTERM);
		break;

	default:
		printf("%s:%d default case %d\n", __func__, __LINE__, iSigNum);
		break;
	}
	return;
}

/* 
 * block_sigchld()
 * block SIGCHLD ,so that pselect  can be interrupted by SIGCHLD
 */
sigset_t block_sigchld()
{
	sigset_t org_sig;
	sigset_t blocked_sig;
	struct sigaction sa;
	sigemptyset(&blocked_sig);
	sigaddset(&blocked_sig, SIGCHLD);
	if (sigprocmask(SIG_BLOCK, &blocked_sig, &org_sig) != 0) {
		perror("failed to block SIGCHLD\n");
		return org_sig;
	}

	memset(&sa, 0, sizeof(struct sigaction));
	sa.sa_mask = blocked_sig;
	sa.sa_handler = sigchld;
	if (sigaction(SIGCHLD, &sa, NULL) == -1) {
		perror("Could not set signal handler\n");
		return org_sig;
	}
	memset(&sa, 0, sizeof(struct sigaction));
	sa.sa_handler = common_sighandler;
	sigaction(SIGTERM, &sa, NULL);
	sigaction(SIGALRM, &sa, NULL);
	sigaction(SIGHUP, &sa, NULL);
	return org_sig;

}

sigset_t unmask_sigchld(dwatch_t *dw)
{
	sigprocmask(SIG_SETMASK, &dw->os, NULL);
	return dw->os;
}


int select_timo(dwatch_t * dw, int timeinsec)
{
	struct timespec tv;
	struct timespec *tvp;
	sigset_t org_sig;
	sigset_t blocked_sig;
	fd_set readfds;
	int maxfd = 0;
	int result;

	tv.tv_sec = timeinsec;
	tv.tv_nsec = 0;

	if (timeinsec == 0) {
		tvp = NULL;
	} else {
		tvp = &tv;
	}

	FD_ZERO(&readfds);
	if (dw->cmd_fifo >= 0) {
		FD_SET(dw->cmd_fifo, &readfds);
		if (dw->cmd_fifo > maxfd)
			maxfd = dw->cmd_fifo;
	}

	result = pselect(maxfd + 1, &readfds, NULL, NULL, tvp, &dw->os);
	if (result == -1) {
		if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR) {
			perror("pselect failed");
		}
	} else if (FD_ISSET(dw->cmd_fifo, &readfds)) {
		process_client(dw);
	}
	return 0;
}

int pid_file(dwatch_t * dw)
{
	pid_t new_pid, sid;
	FILE *pidf = NULL;
	int i = 0;
	pid_t oldpid = -1;
	char procpath[64];
	int fd;
	int foregrnd = dw->cmd_fg;

	pidf = fopen(PID_FILE, "r");
	if (pidf != NULL) {

		/* Check for duplicate instance.. */
		fscanf(pidf, "%d", &oldpid);
		snprintf(procpath, sizeof(procpath), "/proc/%d/cmdline", oldpid);
		fd = open(procpath, O_RDONLY);
		if (fd >= 0) {
			if (read(fd, procpath, sizeof(procpath)) > 0) {
				printf("(%s)%d is already running\n", procpath, oldpid);
				fclose(pidf);
				close(fd);
				exit(1);
			}
		}
		fclose(pidf);
		close(fd);

	}
	/* Fork off the parent process */
	if (foregrnd != 1) {
		new_pid = fork();
		if (new_pid < 0) {
			exit(EXIT_FAILURE);
		}
		/* If we got a good PID, then we can exit the parent process. */
		if (new_pid > 0) {
			exit(EXIT_SUCCESS);
		}

		/* Change the file mode mask */
		/* umask(0); */

		/* Open any logs here */
		/* Create a new SID for the child process */
		sid = setsid();
		if (sid < 0) {
			/* Log the failure */
			exit(EXIT_FAILURE);
		}
	}

	pidf = fopen(PID_FILE, "w");
	if (pidf == NULL) {
		printf("%s:%d Error %s\n", __func__, __LINE__, PID_FILE);
		exit(EXIT_FAILURE);
	}
	fprintf(pidf, "%d\n", getpid());
	fclose(pidf);
}

int main(int argc, char *argv[])
{
	int chld_status = -1, chld_ret = 0;
	struct sigaction sa;
	struct daemon_info *np;
	int option = 0;
	int foregrnd = 0;
	dwatch_t dw;

	memset(&dw, 0, sizeof(dw));
	while ((option = getopt(argc, argv, ":f")) != -1) {
		switch (option) {
		case 'f':
			dw.cmd_fg = 1;
			break;
		}
	}

	pid_file(&dw);
	dw.os = block_sigchld();
	dw.headp = init_list(&dw.head);
	init_dwctl_cmds(&dw);
	dw.cmd_fifo = open_cmd_interface();
	dw.argv0 = argv[0];
	dw.argv0len = strlen(dw.argv0);

	if (dw.cmd_fifo < 0) {
		debug_print("Unable to open cmd_fifo, exiting");
		exit(2);
	}

	/* start & watch daemons */
	while (1) {
		pid_t p = -1;
		select_timo(&dw, 0);
		do {
			p = waitpid(-1, &chld_status, WNOHANG);
			if (p > 0) {
				pid_t old_pid = p;
				debug_print ("Child exited with return value %d\n", chld_status);
				daemon_spawn(&dw, old_pid);
			}
		} while (p > 0);
	}
	return 0;
}
