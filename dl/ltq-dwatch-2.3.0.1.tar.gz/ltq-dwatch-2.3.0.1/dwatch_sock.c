#include "dwatch.h"
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

int set_sock_timeouts(int fd, int tout)
{

	struct timeval timeout;
	timeout.tv_sec = tout;
	timeout.tv_usec = 0;

	if (setsockopt
	    (fd, SOL_SOCKET, SO_RCVTIMEO, (char *)&timeout,
	     sizeof(timeout)) < 0)
		debug_print("setsockopt failed to set SO_RCVTIMEO\n");

	if (setsockopt
	    (fd, SOL_SOCKET, SO_SNDTIMEO, (char *)&timeout,
	     sizeof(timeout)) < 0)
		debug_print("setsockopt failed to set SO_SNDTIMEO\n");
}

int open_cmd_interface()
{
	int s, s2, t, len;
	struct sockaddr_un local, remote;
	int flags;

	if ((s = socket(AF_UNIX, SOCK_STREAM, 0)) == -1) {
		perror("socket");
		exit(1);
	}

	local.sun_family = AF_UNIX;
	strcpy(local.sun_path, DWATCH_SOCK_PATH);
	unlink(local.sun_path);
	len = strlen(local.sun_path) + sizeof(local.sun_family);
	if (bind(s, (struct sockaddr *)&local, len) == -1) {
		perror("bind");
		exit(1);
	}

	if (listen(s, 5) == -1) {
		perror("listen");
		exit(1);
	}
	if (-1 == (flags = fcntl(s, F_GETFL, 0))) {
		debug_print("Unable to get fd flags.. setting it to zero\n");
		flags = 0;
	}
	fcntl(s, F_SETFD, flags | FD_CLOEXEC | O_NONBLOCK);
	return s;
}

int stop_process(dwatch_t *dw, struct daemon_info *entry)
{
	if (entry != NULL) {
		char cmd[256];
		entry->dstate = DSTATE_STOPPED;
		if (entry->pid > 0) {
			snprintf(cmd, sizeof(cmd), "kill -9 %d", entry->pid);
			return system(cmd);
		}
	}
}

int start_process(dwatch_t *dw, struct daemon_info *entry)
{
	if (entry != NULL && entry->dstate != DSTATE_RUNNING) {
		entry->dstate = DSTATE_RUNNING;
		pid_t tPID;
		tPID = fork();
		if (tPID == 0) {
			//snprintf(cmd, sizeof(cmd), "killall -9 %s 2>/dev/null", get_basename(dinfo->entry[0]));
			//system(cmd);
			unmask_sigchld(dw);
			if (execvp(entry->cmd[0], entry->cmd) == -1) {
				debug_print("Failed to start '%s' \n",
				       entry->cmd[0]);
				exit(EXIT_FAILURE);
			}
		} else {
			entry->pid = tPID;
			printf("dwatch: process[%s]: %d\n", entry->cmd[0],
			       tPID);
		}
		return 1;
	}
}


int read_and_process_client(dwatch_t *dw, int client)
{
	char buf[MAX_BUF] = { 0 };
	int n;
	int ret;
	struct client_info *ci = &dw->ci;
	int i=0, j=0;

	memset(ci, '\0', sizeof(*ci));
	memset(buf, '\0', sizeof(buf));

	n = recv(client, buf, sizeof(buf), 0);
	if (n <= 0) {
		if (n < 0) {
			debug_print("recv failed on connected client: %s\n",
				    strerror(errno));
		}
		strcpy(buf, "help");
	}
	
	for(i=0,ci->arg[j]=&buf[i]; i<n && j< sizeof(ci->arg)/sizeof(ci->arg[0])-1; i++) {
		if(buf[i] == '\0' && i+1 < n) {
			i++;
			ci->arg[++j]=&buf[i];
			continue;
		}
	}
	ci->arg[++j]=NULL;
	ci->client = client;

	ret = process_cmd(dw);
	close(client);
	return ret;
}

int process_client(dwatch_t *dw)
{
	struct sockaddr_un remote;
	int done, n;
	int client, flags;
	int t = sizeof(remote);
	int s = dw->cmd_fifo;
	if ((client = accept(s, (struct sockaddr *)&remote, &t)) == -1) {
		perror("accept");
		return -1;
	}
	if (-1 == (flags = fcntl(client, F_GETFL, 0))) {
		debug_print("Unable to get fd flags.. setting it to zero\n");
		flags = 0;
	}
	fcntl(client, F_SETFD, flags | FD_CLOEXEC | O_NONBLOCK);
	set_sock_timeouts(client, 1);

	return read_and_process_client(dw, client);
}
