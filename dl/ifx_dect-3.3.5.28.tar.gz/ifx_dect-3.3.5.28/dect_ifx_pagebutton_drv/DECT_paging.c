/******************************************************************************
**
** FILE NAME    : danube_paging.c
** PROJECT      : Danube
** MODULES      : GPIO for paging
**
** DATE         : 17 MAY 2007
** AUTHOR       : Jeffrey Huang
** DESCRIPTION  : Paging Push Button Driver
** COPYRIGHT    :       Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**    This program is free software; you can redistribute it and/or modify
**    it under the terms of the GNU General Public License as published by
**    the Free Software Foundation; either version 2 of the License, or
**    (at your option) any later version.
**
** HISTORY
** $Date        $Author         $Comment
** 17 MAY 2007  Jeffrey.H        Initiate Version
*******************************************************************************/


#ifndef EXPORT_SYMTAB
#define EXPORT_SYMTAB
#endif
//#include <linux/config.h>
#include <linux/module.h>
#include <linux/errno.h>
#include <linux/signal.h>
#include <linux/sched.h>
#include <linux/timer.h>
#include <linux/interrupt.h>
#include <linux/major.h>
#include <linux/string.h>
#include <linux/fs.h>
#include <linux/proc_fs.h>
#include <linux/fcntl.h>
#include <linux/ptrace.h>
#include <linux/mm.h>
#include <linux/ioport.h>
#include <linux/init.h>
#include <linux/delay.h>
#include <linux/spinlock.h>
#include <linux/slab.h>
#include <asm/system.h>
#include <asm/io.h>
#include <asm/irq.h>
#include <asm/uaccess.h>
#include <asm/bitops.h>
#include <linux/types.h>
#include <linux/kernel.h>
#include <linux/version.h>
#include <linux/poll.h>
#include <linux/proc_fs.h>

#include <linux/version.h>
#ifdef CONFIG_VR9
#include <asm-mips/ifx/vr9/vr9.h>
#include <asm-mips/ifx/vr9/irq.h>
#include <asm-mips/ifx/ifx_gpio.h>
#elif defined(CONFIG_AMAZON_S)
#include <asm/amazon_s/amazon_s.h>
#include <asm/amazon_s/irq.h>
#include <asm/amazon_s/amazon_s_gptu.h>
#elif defined CONFIG_DANUBE
#include <asm-mips/ifx/danube/danube.h>
#include <asm-mips/ifx/danube/irq.h>
#include <asm-mips/ifx/ifx_gpio.h>
#elif defined CONFIG_AR9
#include <asm-mips/ifx/ar9/ar9.h>
#include <asm-mips/ifx/ar9/irq.h>
#include <asm-mips/ifx/ifx_gpio.h>
#elif defined CONFIG_AR10
#include <asm-mips/ifx/ar10/ar10.h>
#include <asm-mips/ifx/ar10/irq.h>
#include <asm-mips/ifx/ifx_gpio.h>
#endif
#if (defined(CONFIG_MODVERSIONS)&&(CONFIG_MODVERSIONS==1))
# include <linux/modversions.h>
#endif

#define GPIO_PAGE_VERSION "2.0.0.0"

#if 1
#define DEBUG(args...) do {;} while(0)
#else
#define DEBUG   printk
#endif


#define BIT6   (1<<6)
#define BIT7   (1<<7)
#define BIT11   (1<<11)
#define BIT12   (1<<12)
#define BIT13   (1<<13)
#if defined (CONFIG_VR9)
#ifdef DECT_USE_USIF
#define PAGE_PIN 39
#else
#define PAGE_PIN 11
#endif
#define PAGINGBIT 1
static const int page_gpio_module_id = IFX_GPIO_MODULE_PAGE;
#elif defined(CONFIG_AMAZON_S)
#define PAGINGBIT BIT6
#elif defined(CONFIG_DANUBE)
#define PAGE_PIN 22
#define PAGINGBIT 1
static const int page_gpio_module_id = IFX_GPIO_MODULE_PAGE;
#elif defined CONFIG_AR9
#define PAGE_PIN 38
#define PAGINGBIT 1
static const int page_gpio_module_id = IFX_GPIO_MODULE_PAGE;
#elif defined CONFIG_AR10
#define PAGE_PIN 1
#define PAGINGBIT 1
static const int page_gpio_module_id = IFX_GPIO_MODULE_PAGE;
#endif
#define POLLING_PERIOD HZ/10
#define FIFO_LEN 5
#if CONFIG_PROC_FS
static struct proc_dir_entry *dect_proc_dir;
int paging_drv_read_proc(char *page, char **start, off_t off,
                int count, int *eof, void *data);

int paging_drv_get_version_proc(char *buf);

#define PROC_PAGEBUTTON "pagemode"
static struct proc_dir_entry *Proc_File;
static unsigned long procfs_buffer_size = 0;
static unsigned char procfs_buffer[37]={0};


#endif /* CONFIG_PROC_FS */

struct timer_list gpio_timer;

static int open_dect_count = 0;
wait_queue_head_t page_readq;
//int push_button_enable = 0;
int maj = 150;
int g_time = 0;
int ready_output = 0;
int user_output = 0;
unsigned int global_index = 0;
unsigned int output_index = 0;
int output_time[FIFO_LEN] = {0};


void ifx_dect_page_GPIO_init(void)
{
    ifx_gpio_register(IFX_GPIO_MODULE_PAGE);
}

static void gpio_paging(unsigned long data)
{
    uint32_t gpio_p0_in=0;
    ifx_gpio_input_get(PAGE_PIN,page_gpio_module_id,&gpio_p0_in);

#if CONFIG_PROC_FS
 		if(user_output){
	    ready_output = 1;
			if(user_output == 1){
        output_time[global_index] = 100;
			}
		  else if(user_output == 3){ /* Added for initiaing Date and time notification */
        output_time[global_index] = 500;
			}	
		  else if(user_output == 4){ /* Added for initiaing DECT shutdown */
        output_time[global_index] = 700;
			}
			else if(user_output == 5){/*Added for dect start after DECT Shutdown*/
        output_time[global_index] = 900;
			}	
			else if(user_output == 6){/*Added for Email Notification*/
        output_time[global_index] = 60;
			}	
			else if(user_output == 7){/*Added for RSS Notification*/
        output_time[global_index] = 70;
			}	
			else if(user_output == 8){/*Added for Cvoip powerlevel testing */
        output_time[global_index] = 80;
			}	
			else if(user_output == 9){/*Added for Cvoip powerlevel testing*/
        output_time[global_index] = 90;
			}	
      else{
        output_time[global_index] = 10;
      }
			++global_index;
      global_index = (global_index) % FIFO_LEN;
      wake_up_interruptible(&page_readq);
			user_output=0;
		}
		else
#endif
   if (gpio_p0_in & PAGINGBIT)
    {	
    //    push_button_enable = 0;
        if (g_time > 0)
        {
	    ready_output = 1;
            output_time[global_index] = g_time;
            DEBUG("output_time is %i and global_index is % i\n",output_time[global_index],global_index);
			++global_index;
            global_index = (global_index) % FIFO_LEN;
            wake_up_interruptible(&page_readq);
            DEBUG("The output time is %i\n",output_time);
        }
        g_time = 0;
    }
    else
    {
     //   push_button_enable = 1;
        ready_output = 0;
	g_time ++;
    }

    mod_timer(&gpio_timer,jiffies + POLLING_PERIOD);
}

#if CONFIG_PROC_FS
int procfile_write(struct file *file, const char *buffer, unsigned long count,void *data)
{
	 procfs_buffer_size = count;
	 if(copy_from_user(procfs_buffer,buffer,procfs_buffer_size)<0){
		 return -1;
	 }
	 if(procfs_buffer[0] == '1'){
		 user_output = 1; 
	 }
	 else if(procfs_buffer[0] == '3'){/* Added for initiaing Date and time notification */
		 user_output = 3;
	 }
	 else if(procfs_buffer[0] == '4'){/* Added for initiaing DECT Shutdown*/
		 user_output = 4;
	 }
	 else if(procfs_buffer[0] == '5'){/* Added for restart DECT after Shutdown*/
		 user_output = 5;
	 }
	 else if(procfs_buffer[0] == '6'){/* Added for Sending notification of Email */
		 user_output = 6;
	 }
	 else if(procfs_buffer[0] == '7'){/* Added for Sending notificationf for RSS */
		 user_output = 7;
	 }
	 else if(procfs_buffer[0] == '8'){/* Added for Testing Cvoip */
		 user_output = 8;
	 }
	 else if(procfs_buffer[0] == '9'){/* Added for Testing Cvoip */
		 user_output = 9;
	 }
   else{
		 user_output = 2;
   }
	 return procfs_buffer_size;
}

#endif                                                                                
int danube_pagebutton_open(struct inode *inode, struct file * filp)
{
  if (open_dect_count)
	{
			printk("\nPage Button Drv already opened\n");
      return -1;
	}
	open_dect_count++;
  filp->f_pos=0;
  ifx_dect_page_GPIO_init();
	g_time=0;  
	DEBUG("danube_pagebutton_open is invoked\n");

#if CONFIG_PROC_FS
  dect_proc_dir = proc_mkdir("driver/page", NULL);

  if (dect_proc_dir != NULL)
  {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,30)
    dect_proc_dir->owner = THIS_MODULE;
#endif
    create_proc_read_entry("version", S_IFREG|S_IRUGO, dect_proc_dir,
                    paging_drv_read_proc, paging_drv_get_version_proc);
		/* create the /proc file */
		Proc_File = create_proc_entry(PROC_PAGEBUTTON, 0644, NULL);
		Proc_File->read_proc  = NULL;
		Proc_File->write_proc = procfile_write;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,30)
		Proc_File->owner = THIS_MODULE;
#endif
		Proc_File->mode = S_IFREG | S_IRUGO;
		Proc_File->parent = dect_proc_dir;
		Proc_File->uid = 0;
		Proc_File->gid = 0;


  }
#endif /* CONFIG_PROC_FS */
        return 0;
}
                                                                                
int danube_pagebutton_close(struct inode *inode, struct file *filp)
{
  if (open_dect_count)
	{
  ifx_gpio_deregister(IFX_GPIO_MODULE_PAGE);
#if CONFIG_PROC_FS
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,30)
		remove_proc_entry(PROC_PAGEBUTTON, &proc_root);
#else
		remove_proc_entry(PROC_PAGEBUTTON, NULL);
#endif
		remove_proc_entry("version", dect_proc_dir);
		remove_proc_entry("driver/page", NULL);
#endif /* CONFIG_PROC_FS */
	open_dect_count=0;
	}
    return 0;
}
int danube_pagebutton_ioctl(struct inode *inode, struct file *filp, unsigned int cmd, unsigned long data)
{
#if 1
	//if(cmd == PAGE_BUTTON_SHUTDOWN)
	{
		danube_pagebutton_close(inode,filp);
	}
#endif
	return 0;
}
                                                                                
static ssize_t danube_pagebutton_read(struct file *filp, char *ubuf, size_t len, loff_t *off)
{
    char buf[20];
    int ret;
    int i;
 
    DEBUG("danube_pagebutton_read is invoked\n");
    if (ready_output)
    {
           if (global_index > output_index)
           {
		if (global_index - output_index == 1)
                {
                   sprintf(buf,"%i",output_time[output_index]);
    					 DEBUG("danube_pagebutton_read  - 1\n");
                }else{
                   for (i=0; i<(global_index-output_index); i++)
                   {
                      sprintf(buf+2*i,"%i ",output_time[output_index+i]);
    					 	DEBUG("danube_pagebutton_read  - 2\n");
                   }
                }
           }else{
		if (global_index + FIFO_LEN - output_index == 1)
                {
                   sprintf(buf,"%i",output_time[output_index]);
    					 DEBUG("danube_pagebutton_read  - 3\n");
                }else{
                   for (i=0; i<(global_index+FIFO_LEN-output_index); i++)
                   {
                      sprintf(buf+2*i,"%i ",output_time[(output_index+i)%FIFO_LEN]);
    					 	 DEBUG("danube_pagebutton_read  - 4\n");
                   }
                }
           }
          output_index = global_index;        
               
	   ready_output = 0;
    }

    if (copy_to_user((void*)ubuf, buf, 20 ) != 0)
            ret = -EFAULT;
    return 1;//the length

}
static ssize_t danube_pagebutton_write(struct file *filp, const char *ubuf, size_t len, loff_t *off)
{
	char buf[256];
	
        memset(buf,0,256);	
	copy_from_user(buf, ubuf, len);
        DEBUG("danube_pagebutton_write is invoked and the buf is %s\n",buf);
	return 0;
}
unsigned int danube_pagebutton_poll(struct file *filp, poll_table *wait)
{
    unsigned int mask = 0;

//    DEBUG("danube_pagebutton_poll is invoked\n");

    poll_wait(filp, &page_readq, wait);

     if (ready_output)
        mask |= POLLIN | POLLRDNORM;                                                            
    return mask;
}

static struct file_operations danube_pagebutton_fops = {
        owner:          THIS_MODULE,
        read:           danube_pagebutton_read,    /* read */
        write:          danube_pagebutton_write,   /* write */
        ioctl:          danube_pagebutton_ioctl,   /* ioctl */
        open:           danube_pagebutton_open,    /* open */
        poll:           danube_pagebutton_poll,    /* poll */
        release:        danube_pagebutton_close,   /* release */
};



int __init ifx_dect_page_init(void)
{
    int ret;

    init_timer(&gpio_timer);
    gpio_timer.data = (long)NULL;
    gpio_timer.function = gpio_paging;
    gpio_timer.expires =  jiffies + POLLING_PERIOD;
    add_timer(&gpio_timer);

    init_waitqueue_head(&page_readq);
    if ((ret = register_chrdev(maj, "pagebutton", &danube_pagebutton_fops)) < 0){
                printk("Unable to register major %d for the Infineon Danube DECT\n", maj);
    }
  
    return 0;
}

void __exit ifx_dect_page_cleanup_module(void)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,32)
    int ret;
		if((ret = unregister_chrdev(maj,"pagebutton"))<0)
		{
     	printk("Unable to un-register major %d for the Infineon Danube DECT\n", maj);
		}
#else
		unregister_chrdev(maj,"pagebutton");
#endif
    del_timer(&gpio_timer);
}

#if CONFIG_PROC_FS
int paging_drv_read_proc(char *page, char **start, off_t off,
                int count, int *eof, void *data)
{
  int len;
  int (*fn)(char *buf);

  if (data != NULL)
  {
    fn = data;
    len = fn(page);
  }
  else
    return 0;

  if (len <= off+count)
    *eof = 1;

  *start = page + off;

  len -= off;

  if (len > count)
    len = count;

  if (len < 0)
    len = 0;

  return len;

}
int paging_drv_get_version_proc(char *buf)
{
  int len;
  unsigned char ucVersion[]=GPIO_PAGE_VERSION;
  len = sprintf(buf, "Page Driver Version:%s\n Built Time stamp: Date-%sTime-%s\n",ucVersion,__DATE__,__TIME__);
  return len;
}
#endif/*CONFIG_PROC_FS*/

module_exit(ifx_dect_page_cleanup_module);
module_init(ifx_dect_page_init);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Jeffrey Huang");
MODULE_DESCRIPTION("IFX DECT paging button driver");
