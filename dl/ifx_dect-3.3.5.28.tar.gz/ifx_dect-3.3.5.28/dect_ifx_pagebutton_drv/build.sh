#!/bin/sh
APPS_NAME="dect-GPIO-paging"

if [ -e ../sysconfig.sh ]; then
	. ../sysconfig.sh
	. ../config.sh
	. ../model_config.sh
else
        echo "Application "$APPS_NAME" not configured"
	exit 0
fi

display_info "----------------------------------------------------------------------"
display_info "--------------------- build ${APPS_NAME} modules ---------------------"
display_info "----------------------------------------------------------------------"

parse_args $@

if [ "$1" = "config_only" ] ;then
	exit 0
fi

if [ $BUILD_CLEAN -eq 1 ]; then
	make clean
	ifx_error_check $?
	[ ! $BUILD_CONFIGURE -eq 1 ] && exit 0
fi
if [ "$CONFIG_AMAZON_S" = "y" ]; then
make -C ${TOPDIR}/${KERNEL_SOURCE_DIR} M=$PWD modules CROSS=${COMPILER_PREFIX} KERNEL=${TOPDIR}/${KERNEL_SOURCE_DIR} TAPI_HEADER=${TAPI_HEADER} TAPI_KPI_HEADER=${TAPI_KPI_HEADER} 
ifx_error_check $?
else
make -C ${KERNEL_SOURCE_DIR} M=$PWD modules CROSS=${COMPILER_PREFIX} KERNEL=${KERNEL_SOURCE_DIR} TAPI_HEADER=${TAPI_HEADER} TAPI_KPI_HEADER=${TAPI_KPI_HEADER} 
ifx_error_check $?
fi
#rm -f ${BUILD_ROOTFS_DIR}lib/modules/paging.o
#cp paging.o ${BUILD_ROOTFS_DIR}lib/modules/
cp danube_paging.ko ${BUILD_ROOTFS_DIR}/usr/drivers/paging.ko
ifx_error_check $?
