#!/bin/sh
APPS_NAME="drv_dect"
if [ -e ../sysconfig.sh ]; then
	. ../sysconfig.sh
	. ../config.sh
	. ../model_config.sh
else
        echo "Application "$APPS_NAME" not configured"
	exit 0
fi

echo "----------------------------------------------------------------------"
echo "-----------------------  build Dect Driver modules  -----------------------"
echo "----------------------------------------------------------------------"

parse_args $@

if [ "$1" = "config_only" ] ;then
	exit 0
fi

if [ $BUILD_CLEAN -eq 1 ]; then
	make clean
fi

echo ${CROSS_COMPILER_PREFIX}	
echo "-----------------------------"
if [ "$CONFIG_AMAZON_S" = "y" ]; then
make -C ${TOPDIR}/${KERNEL_SOURCE_DIR} M=$PWD modules CROSS=${COMPILER_PREFIX} KERNEL=${TOPDIR}/${KERNEL_SOURCE_DIR}  
ifx_error_check $?
else
make -C ${KERNEL_SOURCE_DIR} M=$PWD modules CROSS=${COMPILER_PREFIX} KERNEL=${KERNEL_SOURCE_DIR}  
ifx_error_check $?
fi
chmod 755 ./drv_timer.ko -Rf

echo "    [Copy] DECT Timer Driver "
mkdir -p ${BUILD_ROOTFS_DIR}/usr/drivers/
cp -f ./drv_timer.ko ${BUILD_ROOTFS_DIR}/usr/drivers
echo

ifx_error_check $?

