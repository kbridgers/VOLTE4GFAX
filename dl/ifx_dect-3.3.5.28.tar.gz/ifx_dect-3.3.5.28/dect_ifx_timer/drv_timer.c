/******************************************************************************

                                Copyright (c) 2006
                             Infineon Technologies AG
                        Am Campeon 1-12, 85579 Neubiberg, Germany

        This program is free software; you can redistribute it and/or modify
        it under the terms of the GNU General Public License as published by
        the Free Software Foundation; either version 2 of the License, or
        (at your option) any later version.

*******************************************************************************/

//#include <linux/config.h>
#include <linux/module.h>

#include <linux/kernel.h>   /* printk() */
#include <linux/slab.h>
#include <linux/fs.h>       /* everything... */
#include <linux/errno.h>    /* error codes */
#include <linux/types.h>    /* size_t */
#include <linux/init.h>
#include <linux/proc_fs.h>
#include <linux/poll.h>
#include <linux/ioport.h>
#include <linux/vmalloc.h>
#include <linux/delay.h>
#include <linux/sched.h>
#include <linux/param.h>
#include <linux/timer.h>
#include <linux/interrupt.h>
#include <asm/uaccess.h>
#include <asm/io.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,26)
#include <asm/semaphore.h>
#else
#include <linux/semaphore.h>
#endif
#include <asm/irq.h>

#include <linux/version.h>
#include <drv_timer.h>        /* The definetion of the TIMER Driver interfaces. */

#define TIMER_DRV_MAJOR             212
#define TIMER_DRV_MINOR_0           0
#define TIMER_DRV_MINOR_1           1

#define TIMER_DEVICE_NAME "timer_drv"
#define TIMER_VERSION "2.0.0.0"
#if CONFIG_PROC_FS
static struct proc_dir_entry *dect_proc_dir;
int timer_drv_read_proc(char *page, char **start, off_t off,
                int count, int *eof, void *data);

int timer_drv_get_version_proc(char *buf);
#endif /* CONFIG_PROC_FS */

int initTimer_count = 0;
int Timer_excpFlag = 0;
int Timer_outenFlag = 0;

int Timer_Monitoring_TimeOutFlag = 0;


wait_queue_head_t Timer_WakeupList;
static struct timer_list timer_drv_timer;
int timer_drv_count = 0;
static int timer_drv_run = TIMER_DRV_IDLE;
static int timer_interval = 1000; //default 1000msec

int cosic_modem_monitoring_cnt = 0;
int cosic_modem_monitoring_ctrl = 1;

#define EXPIRE_TIME_DEVIDE   (1000/timer_interval)
#define EXPIRE_TIME_MULTY   (timer_interval/1000)

void TimerEvent_Func(unsigned long data)
{
//  timer_drv_count++;
  
  unsigned long ilockflags;

  if(!Timer_Monitoring_TimeOutFlag)
  {
  	Timer_excpFlag = 1;
  }
  else
  {
	  Timer_outenFlag = 1;
	  Timer_Monitoring_TimeOutFlag = 0;

  }
	wake_up_interruptible(&Timer_WakeupList);
  if (timer_drv_run == TIMER_DRV_RUNNING)
  {
    timer_drv_timer.function = TimerEvent_Func;
	  if (timer_interval <= 1000)
    	timer_drv_timer.expires = jiffies + (HZ/EXPIRE_TIME_DEVIDE);
    else
      timer_drv_timer.expires = jiffies + (HZ*EXPIRE_TIME_MULTY);
    add_timer(&timer_drv_timer);


		if(cosic_modem_monitoring_ctrl)
		{
			local_irq_save(ilockflags);
			cosic_modem_monitoring_cnt++;
			local_irq_restore(ilockflags);

			if(cosic_modem_monitoring_cnt > 250)		// 20ms * 250 = 5000ms(5second)
			{
				cosic_modem_monitoring_cnt = 0;
				Timer_Monitoring_TimeOutFlag = 1;
			}
		}

  }  

}

/*
 * Forwards for our methods.
 */
int timer_drv_open   (struct inode *inode, struct file *filp);
int timer_drv_release(struct inode *inode, struct file *filp);
int timer_drv_ioctl  (struct inode *inode, struct file *filp, unsigned int cmd, unsigned long arg);
int timer_drv_poll   (struct file *file, struct poll_table_struct *wait);
int timer_drv_write  (struct file *file_p, const char __user *buf, size_t count, loff_t *ppos);
int timer_drv_read   (struct file *file_p, char *buf, size_t count, loff_t *ppos);

/* 
 * The operations for device node handled.
 */
static struct file_operations timer_drv_fops =
{
    owner:
        THIS_MODULE,
    read:
        timer_drv_read,
    write:
        (void*)timer_drv_write,
    poll: 
        (void*)timer_drv_poll,
    ioctl:
        timer_drv_ioctl,
    open:
        timer_drv_open,
    release:
        timer_drv_release
};


/*******************************************************************************
Description:
Arguments:
Note:
*******************************************************************************/
int timer_drv_read(struct file *file_p, char *buf, size_t count, loff_t *ppos)
{
  put_user(timer_drv_count, (int *)buf);
  return 0;
}


/*******************************************************************************
Description:
Arguments:
Note:
*******************************************************************************/
int timer_drv_write(struct file *file_p, const char __user *buf, size_t count, loff_t *ppos)
{
  return 0;
}

/*******************************************************************************
Description:
   The function for the system call "select".
Arguments:
Note:
*******************************************************************************/
int timer_drv_poll(struct file *file_p, struct poll_table_struct *wait)
{
  int ret = 0;

  /* install the poll queues of events to poll on */
  poll_wait(file_p, &Timer_WakeupList, wait);
  
  if (Timer_excpFlag)
  {
    ret = POLLIN | POLLRDNORM;
    Timer_excpFlag = 0;
  }
  else if (Timer_outenFlag)
  {
	  ret = POLLOUT | POLLRDNORM;
	  Timer_outenFlag = 0;
  }
  return ret;
}

/*******************************************************************************
Description:
   Handle IOCTL commands.
Arguments:
Note:
*******************************************************************************/
int timer_drv_ioctl(struct inode *inode, struct file *filp, unsigned int cmd, unsigned long arg)
{
  //arg : msec     if arg equals zero, timer_interval dosen't change
  /* Handle Ioctl commands. */
	switch(cmd)
	{
    case TIMER_DRV_SHUT:
		{
			timer_drv_release(inode,filp);
			break;
		}
    case TIMER_DRV_IDLE:
      timer_drv_run = TIMER_DRV_IDLE;
      del_timer(&timer_drv_timer);

	  cosic_modem_monitoring_cnt = 0;
      break;
      	
    case TIMER_DRV_RUNNING:
      if (timer_drv_run == TIMER_DRV_IDLE)
      {
        if (arg)
          timer_interval = arg;
        
        timer_drv_count = 0;
		cosic_modem_monitoring_cnt = 0;
        timer_drv_timer.function = TimerEvent_Func;
      	if (timer_interval <= 1000)
        	timer_drv_timer.expires = jiffies + (HZ/EXPIRE_TIME_DEVIDE);
        else
          timer_drv_timer.expires = jiffies + (HZ*EXPIRE_TIME_MULTY);
        add_timer(&timer_drv_timer);
        timer_drv_run = TIMER_DRV_RUNNING;
      }

    	break;

    case TIMER_DRV_MODE_CHANGE:
      if (timer_drv_run == TIMER_DRV_RUNNING)
      {
        timer_drv_run = TIMER_DRV_IDLE;
        del_timer(&timer_drv_timer);       
        if (arg)
          timer_interval = arg;

        timer_drv_timer.function = TimerEvent_Func;
        if (timer_interval <= 1000)
        	timer_drv_timer.expires = jiffies + (HZ/EXPIRE_TIME_DEVIDE);
        else
          timer_drv_timer.expires = jiffies + (HZ*EXPIRE_TIME_MULTY);
        add_timer(&timer_drv_timer);
        timer_drv_run = TIMER_DRV_RUNNING;
      } else
      {
        if (arg)
          timer_interval = arg;
      }

      
    	break;

	  default:
		  break;	
	}
  return 0;
}


/*******************************************************************************
Description:
   Open the Timer driver.
Arguments:
Note:
*******************************************************************************/
int timer_drv_open(struct inode *inode, struct file *filp)
{
	
  unsigned int num;
  if (initTimer_count)
      return -1;


  num = MINOR(inode->i_rdev);
  if (num > TIMER_DRV_MINOR_1)
  {
    printk("Timer Driver: Minor number error!\n");
    return -1;
  }
  //printk(TIMER_DEVICE_NAME " : Device open (%d, %d)\n\n", MAJOR(inode->i_rdev), MINOR(inode->i_rdev));
  Timer_excpFlag = 0;
  Timer_outenFlag = 0;
  Timer_Monitoring_TimeOutFlag = 0;
  timer_drv_count = 0;
  timer_drv_run = TIMER_DRV_IDLE;
  timer_interval = 1000; //default 1000msec
  cosic_modem_monitoring_cnt = 0;
	cosic_modem_monitoring_ctrl = 1;
 
   init_timer(&timer_drv_timer);

  
  
  initTimer_count++;

/* Use filp->private_data to point to the device data. */
  filp->private_data = (void *)num;
  
  /* Initialize a wait_queue list for the system poll function. */ 
  init_waitqueue_head(&Timer_WakeupList);

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
  /* Increment module use counter */
  MOD_INC_USE_COUNT;
#endif
#if CONFIG_PROC_FS

  dect_proc_dir = proc_mkdir("driver/timer", NULL);

  if (dect_proc_dir != NULL)
  {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,30)
    dect_proc_dir->owner = THIS_MODULE;
#endif
    create_proc_read_entry("version", S_IFREG|S_IRUGO, dect_proc_dir,
                    timer_drv_read_proc, timer_drv_get_version_proc);
  }
#endif /* CONFIG_PROC_FS */

  return 0;
}


/*******************************************************************************
Description:
   Close the Timer driver.
Arguments:
Note:
*******************************************************************************/
int timer_drv_release(struct inode *inode, struct file *filp)
{
	/*printk(TIMER_DEVICE_NAME " : Device release (%d, %d)\n\n", MAJOR(inode->i_rdev), MINOR(inode->i_rdev));*/
	if (initTimer_count)
	{
		del_timer(&timer_drv_timer);
    timer_drv_run = TIMER_DRV_IDLE;
#if CONFIG_PROC_FS
  	remove_proc_entry("version",dect_proc_dir);
  	remove_proc_entry("driver/timer",NULL);
#endif /* CONFIG_PROC_FS */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)   
    MOD_DEC_USE_COUNT;
#endif
		initTimer_count =0;
    cosic_modem_monitoring_cnt = 0;
		cosic_modem_monitoring_ctrl = 1;
	}
  return 0;
}


/*******************************************************************************
Description:
   register Timer driver to kernel
Arguments:
Note:
*******************************************************************************/
int timer_drv_init(void)
{
  int result;

  result = register_chrdev(TIMER_DRV_MAJOR, TIMER_DEVICE_NAME, &timer_drv_fops);
  
  if (result < 0)
  {
    printk(KERN_INFO "TIMER Driver: Unable to get major %d\n", TIMER_DRV_MAJOR);
    return result;
  }
//  init_timer(&timer_drv_timer);
  
  return 0;
}


/*******************************************************************************
Description:
   clean up the TIMER driver.
Arguments:
Note:
*******************************************************************************/
void timer_drv_cleanup(void)
{
  unregister_chrdev(TIMER_DRV_MAJOR, TIMER_DEVICE_NAME);
}
#if CONFIG_PROC_FS
int timer_drv_read_proc(char *page, char **start, off_t off,
                int count, int *eof, void *data)
{
  int len;
  int (*fn)(char *buf);

  if (data != NULL)
  {
    fn = data;
    len = fn(page);
  }
  else
    return 0;

  if (len <= off+count)
    *eof = 1;

  *start = page + off;

  len -= off;

  if (len > count)
    len = count;

  if (len < 0)
    len = 0;

  return len;

}
int timer_drv_get_version_proc(char *buf)
{
  int len;
  unsigned char ucVersion[]=TIMER_VERSION;
  len = sprintf(buf, "Timer Driver Version:%s\n Built Time Stamp:Date-%sTime-%s\n",ucVersion,__DATE__,__TIME__);
  return len;
}
#endif /*CONFIG_PROC_FS*/

/* COSIC SPI DRIVER MONITORING TIMER OFF FUNCTION */
int Cosic_modem_monitoring_timer_ctrl(int iState)
{
	unsigned long ilockflags;

	local_irq_save(ilockflags);

	cosic_modem_monitoring_ctrl = iState;		// monitoring timer reset
	cosic_modem_monitoring_cnt = 0;		// monitoring timer reset

	local_irq_restore(ilockflags);
	return 0;
}
EXPORT_SYMBOL (Cosic_modem_monitoring_timer_ctrl);
module_init(timer_drv_init);
module_exit(timer_drv_cleanup);

MODULE_DESCRIPTION("TIMER driver");
MODULE_AUTHOR("Ralph Ryu");
MODULE_LICENSE          ("GPL");
