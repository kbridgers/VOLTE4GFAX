#ifndef _INC_DECT_AGENT_IF
#define _INC_DECT_AGENT_IF

#include "TYPEDEF.H"

#define IFX_IPC_DECT_MAX_MSG_SIZE 256

#define IFX_IPC_DECT_MAX_DATA_SIZE 250

typedef struct
{
	BYTE ucMsgId;
	BYTE ucInstance;
	BYTE ucPara1;
	BYTE ucPara2;
	BYTE ucPara3; //reserved
	BYTE ucPara4; //reserved
	BYTE acData[IFX_IPC_DECT_MAX_DATA_SIZE];	
}x_IFX_DECT_IPC_Msg;


void DectAgentIf_BufferInit(void);
int DectAgentIf_FifoInit(void);
int DectAgentIf_FifoRead(unsigned char *pcBuf,int iSize);
int DectAgentIf_FifoWrite(unsigned char *pcBuf,int iSize);
  
extern int s_ReadFromAgentFifoFd;
extern x_IFX_DECT_IPC_Msg from_agent_read_buf;
extern x_IFX_DECT_IPC_Msg to_agent_write_buf;

#include "uplane_if.h"

#endif    //_INC_DECT_AGENT_IF
