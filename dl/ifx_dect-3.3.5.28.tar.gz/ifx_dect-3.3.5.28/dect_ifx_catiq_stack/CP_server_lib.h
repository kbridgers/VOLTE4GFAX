
#ifndef CP_SERVER_LIB_H
#define CP_SERVER_LIB_H

#ifdef DECT_NG


IMPORT XDATA  uchar8 Primary_Codec;


IMPORT FPTR Get_Codec_List                   ( BYTE );
IMPORT FPTR Get_Designated_Codec_List        ( BYTE );
IMPORT FPTR Get_Progress_Indicator( void );
IMPORT BYTE	Evaluate_CODEC_LIST_IE( void );
IMPORT BYTE	Evaluate_Terminal_Capability_IE( void );
#endif


#endif	/* CP_SERVER_LIB_H */
