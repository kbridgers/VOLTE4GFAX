/**************************************************************************
**   FILE NAME     : IFX_DECT_CSU.h
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 26-09-2008
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Call Control
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software is granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_DECT_CSU.h
    \brief This file contains the Call Service Unit (CSU) Procedures.  
                The CSU is the main Call Service Unit section.  It provides a 
                set of procedures that allow the establishment, maintenance and release of
        circuit switched services. It also provides support for all call related signaling.   
*/

/** \ingroup DECT_TOOLKIT_MODULES
       \defgroup CSU_MODULE Call Service Unit
       \brief The Call Service Unit manages all the call control needs
       with respect to voice calls.  The CSU implements the capability
       information from the handsets and uses this information to set
       up narrowband or wideband calls.  The CSU is CAT iq 2.0 compliant.
       The CSU supports the supplementary call services
       as described in CAT iq 2.0.  The interface provided by the CSU is 
       listed in the chapter on Toolkit API.  The examples chapter
       provides source code examples illustrating the usage of the CSU
       interfaces.
*/
/* @{ */
/* @} */

#ifndef __IFX_DECT_CSU_H__
#define __IFX_DECT_CSU_H__

/** \ingroup DECT_TOOLKIT_API
    \defgroup CSU_API Call Service Unit
    \brief This group contains the Call Service Unit (CSU) functions 
            of the DECT Toolkit.  It provides a set of procedures that allow \n
     1> The establishment, maintenance and release of circuit switched services.\n
     2> It also provides support for all call related signaling.\n
           The private data specified in callback(s) and function(s) is the FT application 
             handle that will be maintained by the toolkit and provided in callbacks 
             for the FT application to match the request and responses.
   
*/
/* @{ */

/*! \def IFX_DECT_MAX_CLIP
    \brief Macro that specifies the maximum length of Calling Party Number in bytes.
 */
#define IFX_DECT_MAX_CLIP 128 /*!< Maximum CLIP size*/


/*! \def IFX_DECT_MAX_CNIP
    \brief Macro that specifies the maximum length of Calling Party Name in bytes.
 */
#define IFX_DECT_MAX_CNIP 128 /*!< Maximum CNIP size*/


/*! \def IFX_DECT_MAX_DIGITS
    \brief Macro that specifies the maximum length of Dialled Digits in bytes.
 */
#define IFX_DECT_MAX_DIGITS  25 /*!< Maximum Digits */

/*! \def IFX_DECT_FLAG_ACTIVE_CALL_REPLACE
    \brief Macro that specifies the flag for active call replacement.
 */
#define IFX_DECT_FLAG_ACTIVE_CALL_REPLACE 0x20  /*!< Active Call Replace Flag */

/*! \def IFX_CPT_CONTROL_BIT
    \brief Bit specifies whether the CPT is generated from the FT (set) or signal IE (reset) 
 */
#define IFX_CPT_CONTROL_BIT 0x10

/*! \enum e_IFX_DECT_CSU_InterceptStatus
    \brief Enum containing the failure cases or success case of Intercept.
*/
typedef enum
{
   IFX_DECT_CSU_INTERCEPT_NOCALL=0,/*!< No Calls ongoing in the System */ 
   IFX_DECT_CSU_INTERCEPT_TOOEARLY=1,/*!< only one call present but not in active stage*/ 
   IFX_DECT_CSU_INTERCEPT_NOTALLOWED=2,/*!< Intercept not allowed for the handset(on which the call is ongoing)*/ 
   IFX_DECT_CSU_INTERCEPT_SUCCESS=3/*!< Intercept Success*/
}e_IFX_DECT_CSU_InterceptStatus;

/*! \enum e_IFX_DECT_IE_CallReason
   \brief Enum containing the Call Reason
*/
typedef enum{
  IFX_DECT_CS_BUSY=0,/*!< system busy*/
  IFX_DECT_CS_INUSE,/*!< Line in Use*/
  IFX_DECT_CS_CODE_NS,/*!< control code not supported */
  IFX_DECT_CS_CODE_FAIL,/*!< control code failed */
  IFX_DECT_CS_USR_BUSY=0x10,/*!< User busy */
  IFX_DECT_CS_NUM_NA=0x11,/*!< number not avilable */  
}e_IFX_DECT_IE_CallReason;


/*! \enum e_IFX_DECT_CSU_CodecChangeType
    \brief Enum containing the codec change type action to be taken. The FP application 
                shall use the enum values for initiating/accepting and rejection of
                service change request.
*/
typedef enum
{
   IFX_DECT_CSU_SC_REQUEST=0, /*!< Request Codec Change*/
   IFX_DECT_CSU_SC_ACCEPT=1, /*!< Accept Codec Change*/
   IFX_DECT_CSU_SC_REJECT=2 /*!< Reject  Codec Change*/
}e_IFX_DECT_CSU_CodecChangeType;

/*! \enum e_IFX_DECT_CSU_VoiceEventType
    \brief Enum containing actions to indicate the CSU to Start/Stop Voice transmission. 
               The FT application shall use the enum values while initiating calls/changing 
               codec and many more cases that require management of the media path. 
*/
typedef enum{
   IFX_DECT_START_VOICE=1, /*!< Start Voice */
   IFX_DECT_STOP_VOICE=2 /*!< Stop Voice */
}e_IFX_DECT_CSU_VoiceEventType;

/*! \enum e_IFX_DECT_CSU_RelType
    \brief Enum containing the transfer type.
               The FT application shall use the enum values to denote which type of
			   transfer (Attended Transfer, Blind Transfer) during the call release. 
*/
typedef enum{
   IFX_DECT_REL_ATX=1, /*!< Attended Transfer */
   IFX_DECT_REL_BOTH=2 /*!< Attended and Blind Transfer */
}e_IFX_DECT_CSU_RelType;

 
/*! \enum e_IFX_DECT_CSU_Signal
    \brief Enum containing the signal value that shall be used to identify the actual signal in the signal IE
*/
 
typedef enum
{
   IFX_DECT_SIGNAL_DialTone=0x0, /*!< DialTone */
   IFX_DECT_SIGNAL_RingBackTone=0x1,/*!< Ringback Tone */
   IFX_DECT_SIGNAL_InterceptTone=0x2,/*!< Intercept Tone*/
   IFX_DECT_SIGNAL_NetCongTone=0x3,/*!< Network Congestion Tone*/
   IFX_DECT_SIGNAL_BusyTone=0x4,/*!<Busy Tone */
   IFX_DECT_SIGNAL_ConfirmTone=0x5,/*!< Confirmation Tone*/
   IFX_DECT_SIGNAL_AnswerTone=0x6,/*!<Answer Tone */
   IFX_DECT_SIGNAL_CallWaitTone=0x7,/*!< Call waiting */
   IFX_DECT_SIGNAL_OffHookWarn_Tone=0x8,/*!<Off Hook Warning Tone */
   IFX_DECT_SIGNAL_NegAckTone=0x9,/*!<Negative Ack Tone */
   IFX_DECT_SIGNAL_TonesOff=0x3f,/*!< Tone off */
   IFX_DECT_SIGNAL_AlertPattern0=0x40,/*!< Alerting On Pattern 0 */
   IFX_DECT_SIGNAL_AlertPattern1=0x41,/*!< Alerting On Pattern 1 */
   IFX_DECT_SIGNAL_AlertPattern2=0x42,/*!< Alerting On Pattern 2 */
   IFX_DECT_SIGNAL_AlertPattern3=0x43,/*!< Alerting On Pattern 3 */
   IFX_DECT_SIGNAL_AlertPattern4=0x44,/*!< Alerting On Pattern 4 */
   IFX_DECT_SIGNAL_AlertPattern5=0x45,/*!< Alerting On Pattern 5 */
   IFX_DECT_SIGNAL_AlertPattern6=0x46,/*!< Alerting On Pattern 6 */
   IFX_DECT_SIGNAL_AlertPattern7=0x47,/*!< Alerting On Pattern 7 */
   IFX_DECT_SIGNAL_AlertOnCont=0x48,/*!< Alerting On continuous */
   IFX_DECT_SIGNAL_AlertPauseOn=0x4E,/*!< Alerting On Pause on */
   IFX_DECT_SIGNAL_AlertOff=0x4F,/*!< Alerting OFF*/
   IFX_DECT_SIGNAL_KeyBeep=0x80,/*!< Key Beep */
   IFX_DECT_SIGNAL_ErrorBeep=0x81,/*!< Error Beep */ 
   IFX_DECT_SIGNAL_SuccessTone=0x82,/*!< Success Tone */
   IFX_DECT_SIGNAL_FailTone=0x83,/*!< Failure Tone */
   IFX_DECT_SIGNAL_OutOfRangeBeep=0x84,/*!< Out Of Range Beep */
   IFX_DECT_SIGNAL_NotificationTone=0x85,/*!< Notification Tone */
   IFX_DECT_SIGNAL_BackgroundTone=0x90,/*!< Background Tone */
} e_IFX_DECT_CSU_Signal;
 

/*! 
    \brief Structure containing the call parameters that are passed in all CSU related 
      functions and Callbacks. The FT Application has to carefully fill/interpret, 
      when sending/receiving them to/from the Dect toolkit. Not all fields are
      required by the CSU functions.  The individual CSU functions specify the 
      mandatory fields.
*/

typedef struct {
  /* Fields used by both during Calling CB and API*/
   uint32 uiIEHandler;      /*!< Information Element handler- refer IEParser.h */
   boolean bwideband;      /*!< 1 indicates wideband call and 0 narrowband call */
   char8 acCLIP[IFX_DECT_MAX_CLIP]; /*!< Calling Party Number*/
   char8 acCNIP[IFX_DECT_MAX_CNIP]; /*!< Calling party Name*/
   e_IFX_DECT_CallType eCallType; /*!< Call Type */
   uchar8  ucLineId;  /*!< Line identification */  
   uint32 uiFlag; /*!< General purpose flag */

   /* Fields filled by toolkit before calling Call back*/
   char8 acRecvDigits[IFX_DECT_MAX_DIGITS];   /*!< Dialled Digits*/
   boolean bHookFlash; /*!< Hook Flash Event from PT*/  
   boolean bIsAllCallsReleased; /*!< Is all Calls released*/

   /* Fields filled by the application before calling the TK API*/
   boolean bIsPresentation;/*!< CLIP Presentation Allowed=0, restricted=1*/
   uint32  uiSignal; /*!< Any of e_IFX_DECT_CSU_Signal or any supported signal number  */
   boolean bCipheringStatus; /*!< 1 indicates ciphering ON and 0 OFF */
   boolean bSingleCallLine; /*!< TRUE - Single call line, 
                                 FALSE - Multi call line */
   boolean isInternal; /*!< Whether it is a internal call[TRUE], external call [FALSE] */
   uchar8  ucPeerHandsetId; /*!< Contains peer Handset Id for Internal/Intercept/Intrude call*/
}x_IFX_DECT_CSU_CallParams;

/*! 
    \brief Structure containing the line information parameters that are passed in 
		CSU related functions and Callbacks. This structure defines a snap shot of a line.
*/
typedef struct {
	uchar8 ucLineId;/*!< Line Id*/
	boolean bMode;/*!< Line Mode - Single Call Mode=0 Multiple Call Mode=1*/
	boolean isCallPossible;/*!< Is call possible on line possible=1, not possible=0 */
	boolean bIntrude;/*!< Can intrude on this line allowed=1, not allowed=0*/
}x_IFX_DECT_CSU_LineInfo;

/*****************************************************************************
 * Functions 
 ******************************************************************************/


/*! \brief  This function is used initiate a call from FT to PT. The FT 
                    application shall call this function when it wants to initiate a Call.
                    Typically, the FT application invokes this function upon 
                    receiving an incoming call notification from a remote/local party.
                    For e.g., in the case of a VoIP Call, a SIP INVITE message is 
                    received on the line to which a DECT handset is attached.
                    This function helps to send a CC_SETUP message to the PT.
                    The FT application shall specify the call params. 
                    This function shall in turn return a Call handle to the FT 
                    application for subsequent operations on the same call.
                    The private data is the FT application handle that will be 
                    maintained by the toolkit and provided in callback(s) of 
                    the FT application to match the request and responses.
   \param[in] ucHandsetId Handset Identifier in the range 1-6.
   \param[in] pxCallParams Reference to Call parameters
   \param[in] uiPrivateData Reference to FT application's private data.
                              The address of the Private Data area may be used here.
   \param[out] puiCallHdl Call Handle of the call
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
   \note For this function the following fields in CallParams are mandatory bwideband, CLIP, CNIP
         isInternal,ucPeerHandsetId(only for internal call), ucLineId and bSingleCallLine (only for
		 external call).
*/
 e_IFX_Return IFX_DECT_CSU_CallInitiate (IN uchar8 ucHandsetId,
                               IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                               IN uint32 uiPrivateData,
                                OUT uint32 *puiCallHdl);

/*! \brief  This function is used to acknowledge a call deflection request to PT. The FT 
                    application shall call this function when it wants to acknowledge a 
                    deflection request and inform the result.  
 
   \param[in] uiCallHdl Call Handle of the call to be deflected
   \param[in] eStatus SUCCESS/FAILURE of the request
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
*/
 e_IFX_Return IFX_DECT_CSU_DeflectionAck(IN uint32 uiCallHdl, 
                                           IN e_IFX_Return eStatus);

/*! \brief This function is used to inform the PT that an outgoing call
           initiated by the PT has been accepted by the remote/local party.
           For e.g., in the case of a VoIP Call, a 180 response is received
           to an earlier SIP INVITE request sent out.
           This function helps to send a CC_ALERT message to the PT.
           The FT application shall fill the call parameters clearly specifying 
           the accepted codec (wideband/narrowband).
   \param[in] uiCallHdl Call Handle of the call
   \param[in] pxCallParams Reference to call parameters
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
   \note For this function, only the bwideband field in the CallParams is mandatory.
*/
e_IFX_Return IFX_DECT_CSU_CallAccept(IN uint32 uiCallHdl,
                                    IN x_IFX_DECT_CSU_CallParams *pxCallParams);  



/*! \brief This function is used to inform the PT that an outgoing call
           initiated by the PT has been answered by the remote/local party.
           For e.g., in the case of a VoIP Call, a 200 response is received
           to an earlier SIP INVITE request sent out.
           This function helps to send a CC_CONNECT message to the PT.
           The FT application shall fill the call parameters clearly specifying 
           the accepted codec (wideband/narrowband).
   \param[in] uiCallHdl Call Handle of the call
   \param[in] pxCallParams Reference to call parameters
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
   \note For this function, only the bwideband,ucLineId and bSingleCallLine 
         (line info only for external call)  field in the CallParams is mandatory.
*/
e_IFX_Return IFX_DECT_CSU_CallAnswer(IN uint32 uiCallHdl,
                                    IN x_IFX_DECT_CSU_CallParams *pxCallParams);


/*! \brief  This function is used to inform the PT that remote/local 
           party in the call has released the call at its end and terminate release
           the call with the PT.
           For e.g., in the case of a VoIP Call, a BYE is received.
           This function helps to send a CC_RELEASE message to the PT.
         The FT should shall specify the release type appropriately in the 
           eReltype field.  The Call handle of the call will be rendered invalid
           after the function returns.
   \param[in] uiCallHdl Call Handle of the call
          \param[in] pxCallParams Reference to call parameters
										 For CatIq 2.0 Hs Reason given in uiFlag will be encoded in
										call Information IE.This wiil be Encode only if the release 
										type is other than NORMAL.
   \param[in] eRelType Reason for the Call Release      
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
   \note For this function the none of the fields in CallParams are mandatory.
*/
e_IFX_Return IFX_DECT_CSU_CallRelease(IN uint32 uiCallHdl,
                                      IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                    IN e_IFX_DECT_RelType eRelType);

/*! \brief  This function is used to send call status disconnect with the reason filled in
            eReason.Valid Only for 2.0 Hs.
   \param[in] uiCallHdl Call Handle of the call
   \param[in] eReason Reason for the sending call state disconnect.      
   \return IFX_SUCCESS / IFX_FAILURE.
*/


e_IFX_Return IFX_DECT_CSU_CallDisconnect(IN uint32 uiCallHdl,
             									      		 IN e_IFX_DECT_IE_CallReason eReason);

/*! \brief  This function is used to inform the PT that the remote/local party
                   in the call wishes to initiate a service change procedure.  The 
                   service change procedure may deal with acceptance or rejection.
                   For CAT IQ 1.0, the service change procedure is invoked to change
                   the codec from WB to NB and vice versa.  
                   For e.g., in the case of a VoIP Call, a re-negotiation (re-INVITE)
                   is received with a modified codec list.
                   The FT application shall call this function when it wants to 
                   change the codec during the call. The permitted change is 
                   from wideband to narrowband or vice versa. The same function
                   is also used to accept/reject the codec change from PT.
           The FT application shall not change the media path configuration
                   before calling this function, as this will be done through a 
                   separate procedure involving pfn_IFX_DECT_CSU_VoiceModify.
   \param[in] uiCallHdl Call Handle of the call
           \param[in] pxCallParams Reference to call parameters
           \param[in] eType The Codec Change Type
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
   \note For this function, only the bwideband field in the CallParams is mandatory.
*/
e_IFX_Return IFX_DECT_CSU_ServiceChange(IN uint32 uiCallHdl,
                                        IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                               IN e_IFX_DECT_CSU_CodecChangeType eType);


/*! \brief  This function is used to inform the PT about the information
                   received from the remote/local party.  The information typically
                   relates to the dialled digits.
                   For e.g., in the case of a VoIP call, an INFO message or a DTMF
                   event packet is received containing the digits dialled by the
                   remote party. The FT application shall call this function to send the 
                  digits/events to PT.  
   \param[in] uiCallHdl Call Handle of the call
          \param[in] pxCallParams Reference to call parameters
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
   \note For this function, only bhook_flash and acRecvDigits fields in the CallParams are mandatory.
*/
e_IFX_Return IFX_DECT_CSU_InfoReceived(IN uint32 uiCallHdl,
                                            IN x_IFX_DECT_CSU_CallParams *pxCallParams);


/*! \brief This function is used to establish/release the media path with the PT.
                 This function shall be called after the call has been answered.  In
                 addition, the FT application shall call this function after it has 
                 enabled/disabled the media at the hardware level.
   \param[in] uiCallHdl Call Handle of the call
          \param[in] pxCallParams Reference to call parameters
   \param[in] eType Start/Stop action      
   \param[in] unHwVoiceChannel The TAPI KPI buffer channel reserved for this call      
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
   \note For this function, only bwideband field in the CallParams is mandatory.
*/
e_IFX_Return IFX_DECT_CSU_VoiceModify(IN uint32 uiCallHdl,
                                     IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                              IN e_IFX_DECT_CSU_VoiceEventType eType,
                             IN uint16 unHwVoiceChannel);



/*! \brief  This function is used acknowledge a transfer request to PT. The FT 
                    application shall call this function when it wants to acknowledge a 
                    transfer request and inform the result. Typically, for a VoIP, a
                    NOTIFY from network shall lead to invocation of this function. 
 
   \param[in] uiSrcCallHdl Source Call Handle of the call to be transfered
   \param[in] uiDstCallHdl Destination Call Handle of the call 
   \param[in] pxCallParams Reference to Call parameters
   \param[in] eStatus SUCCESS/FAILURE of the request
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
   \note For this function the none of the fields in CallParams are mandatory.
*/
 e_IFX_Return IFX_DECT_CSU_CallTransferAck(IN uint32 uiSrcCallHdl, 
                                           IN uint32 uiDstCallHdl,
                                           IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                           IN e_IFX_Return eStatus);
 
/*! \brief  This function is used acknowledge a Intercept req to PT. The FT 
                    application shall call this function when it wants to acknowledge a 
                    intercept request and inform the result.  
 
   \param[in] uiOwnCallHdl CallHdl of the Intercept requested PP
   \param[in] uiInterceptCallHdl Call Handle of the destination call/Call which we are intercepting 
   \param[in] eStatus IFX_SUCCESS if target Intercepted call is found else IFX_FAILURE
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
*/
 e_IFX_Return IFX_DECT_CSU_InterceptAck(IN uint32 uiOwnCallHdl, 
                                           IN uint32 uiInterceptCallHdl,
                                           IN e_IFX_DECT_CSU_InterceptStatus eStatus);
/*! \brief  This function is used acknowledge a Intrude request to both the PT's. The FT 
                    application shall call this function when it wants to acknowledge a 
                    intrude request and inform the result.  
 
   \param[in] uiOwnCallHdl CallHdl of the Intercept requested PP
   \param[in] uiIntrusionCallHdl Call Handle of the destination call/Call which we are intruding 
   \param[in] eStatus IFX_SUCCESS if target Intruded call is found else IFX_FAILURE
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
*/
 e_IFX_Return
IFX_DECT_CSU_CallIntrusionAck(IN uint32 uiOwnCallHdl,
                               IN uint32 uiIntrusionCallHdl,
                               IN e_IFX_Return eStatus);

/*! \brief  This function is used to send intercept req to PT in case of multiple calls in the system. The FT 
                    application shall call this function when it wants to send Intercept accept req to PT.  
 
   \param[in] uiCallHdl Call Handle of the call to which req has to be sent
   \param[in] ucSignal value of signal to be sent
   \param[in] pxCallParams fill in CLIP/CNIP to send the CLIP/CNIP to the PP
   \param[in] szString pointer to the string to be sent to PP.
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
*/
e_IFX_Return IFX_DECT_CSU_SendInterceptReqToPP(IN uint32 uiCallHdl,IN uchar8 ucSignal,
																								IN x_IFX_DECT_CSU_CallParams *pxCallParams,IN char8 *szString);

/*! \brief  This function is used acknowledge a hold request to PT. The FT 
                    application shall call this function when it wants to acknowledge a 
                    hold request and inform the result. Typically, for a VoIP, a
                    re-invite from network shall lead to invocation of this function.
   \param[in] uiCallHdl Call Handle of the call 
   \param[in] pxCallParams Reference to Call parameters
   \param[in] eStatus SUCCESS/FAILURE of the request 
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
   \note For this function the none of the fields in CallParams are mandatory.
*/
 e_IFX_Return IFX_DECT_CSU_CallHoldAck(IN uint32 uiCallHdl,
                                       IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                       IN e_IFX_Return eStatus);

/*! \brief  This function is used acknowledge a resume request to PT. The FT 
                    application shall call this function when it wants to acknowledge a 
                    resume request and inform the result. Typically, for a VoIP, a
                    Re-invite from network shall lead to invocation of this function.
   \param[in] uiCallHdl Call Handle of the call 
   \param[in] pxCallParams Reference to Call parameters
   \param[in] eStatus SUCCESS/FAILURE of the request 
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
   \note For this function the none of the fields in CallParams are mandatory.
*/
 e_IFX_Return IFX_DECT_CSU_CallResumeAck(IN uint32 uiCallHdl,
                                         IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                         IN e_IFX_Return eStatus);
 
/*! \brief  This function is used acknowledge a toggle request to PT. The FT 
                    application shall call this function when it wants to acknowledge a 
                    call toggle request and inform the result. Typically, for a VoIP, a
                    re-invite from network shall lead to invocation of this function.
   \param[in] uiSrcCallHdl Source Call Handle of the call to be toggled
   \param[in] uiDstCallHdl Destination Call Handle of the call to be toggled 
   \param[in] pxCallParams Reference to Call parameters
   \param[in] eStatus SUCCESS/FAILURE of the request 
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
   \note For this function the none of the fields in CallParams are mandatory.
*/
 e_IFX_Return IFX_DECT_CSU_CallToggleAck(IN uint32 uiSrcCallHdl,
                                         IN uint32 uiDstCallHdl,
                                         IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                         IN e_IFX_Return eStatus);

 
/*! \brief  This function is used acknowledge a conference request to PT. The FT 
                    application shall call this function when it wants to acknowledge a 
                    call conference request and inform the result. Typically, for a VoIP, a
                    re-invite from network shall lead to invocation of this function.
   \param[in] uiSrcCallHdl Source Call Handle of the call to be conferenced
   \param[in] uiDstCallHdl Destination Call Handle of the call that to be combined
   \param[in] pxCallParams Reference to Call parameters
   \param[in] eStatus SUCCESS/FAILURE of the request 
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
   \note For this function the none of the fields in CallParams are mandatory.
*/
 e_IFX_Return IFX_DECT_CSU_CallConferenceAck(IN uint32 uiSrcCallHdl,
                                              IN uint32 uiDstCallHdl,
                                             IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                             IN e_IFX_Return eStatus);

/*! \brief  This function is used to inform the Line Info from agent to Tool kit.
   		The FT application calls this function when pfnLineInfoCallBack is invoked.
    \param[in] ucHandsetId HandsetId of the PP
		\param[in] pxCallParams Pointer to call params. 
					The CallParams pointer received in pfnLineInfo Callback should be sent to this function.
		\param[in] pxLineInfo Pointer to Line Info structure
		\return IFX_SUCCESS or IFX_FAILURE
*/

e_IFX_Return
IFX_DECT_CSU_SetLineInfo(IN uchar8 ucHandsetId,
													IN x_IFX_DECT_CSU_CallParams *pxCallParams,
													IN x_IFX_DECT_CSU_LineInfo *pxLineInfo );


/* ****************************************************************************
 * Callback Functions
 * ****************************************************************************/
/*! \brief  This callback function is used to inform the FT application of
                   an outgoing call request from the PT.  This callback function
                   is invoked by the DECT TK when it receives a CC_SETUP request
                   from the DECT Protocol stack indicating an outgoing call request
                   from the PT. The call could be for first or second call. For 
                   second call pfn_IFX_DECT_CSU_InfoReceived shall not be called. 
                   CC_INFO shall be sent with the new call Id to the PP.
                   The DECT TK fills the CallParams with the codec type (wideband 
                   or narrowband) and the dialled digits (if any).  The CLIP and CNIP 
                   information would be empty fields. IE handler is also passed 
                   to handle IWU to IWU services.
   \param[in] uiCallHdl Call Handle of the call 
   \param[in] ucHandsetId Handset Identifier of source PT
           \param[in] pxCallParams Reference to call parameters
          \param[out] peStatus Status of the request 
   \param[out] puiPrivateData Reference to the private data area of the FT 
                                  application. CSU shall maintain this handle and 
                                  pass it to the FT Application in all callback(s).
                                  The FT application shall fill in the address of the Private
                                  Data area.
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
    
	\note The FT application shall try to respond synchronously if possible by returning 
    IFX_SUCCESS or IFX_FAILURE. If IFX_FAILURE is returned, all the internal structures 
	pertaining to the Call Handle shall be freed and PT would be intimated about failure 
	in setting up an outgoing call. No further requests shall be valid on the call handle. If 
	IFX_PENDING is returned, then the DECT TK assumes that FT Application is processing 
	the request and response is awaited. If IFX_SUCCESS is returned, then the DECT TK 
	assumes that request is successful. However no voice path will be established. FT 
	application needs to call IFX_DECT_CSU_CallAnswer to complete the call setup.  
	
	\note For this function the following fields in CallParams will be filled: bwideband, 
	CLIP, CNIP, ucLineId(only for external call, if handset provides it) and 
	acRecvDigits if any.

*/ 
typedef   e_IFX_Return (*pfn_IFX_DECT_CSU_CallInitiate)(IN uint32 uiCallHdl,
                                         IN uchar8 ucHandsetId,
                                         IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                         OUT e_IFX_DECT_ErrReason *peStatus,
                                         OUT uint32 *puiPrivateData);

 
/*! \brief  This callback function is used to inform the FT application that Line Info is required 
						before proceeding with the call.
     \param[in] ucHandsetId Handset Id of PP 
     \param[in] pxCallParams Reference to call parameters
*/
typedef   e_IFX_Return (*pfn_IFX_DECT_CSU_GetLineInfo)( IN uchar8 ucHandsetId,
                                         								IN x_IFX_DECT_CSU_CallParams *pxCallParams); 


/*! \brief  This callback function is used to inform the FT application that the
                   call is accepted at the PT and the PT is in the alerting state.  
                   This callback function is invoked by the DECT TK in response
                   to an earlier IFX_DECT_CSU_CallInitiate function call. The
                   DECT TK invokes this callback function when it receives a 
                   CC_ALERT message from the DECT Protocol Stack.  The DECT TK
                   may optionally fill the CallParam with the codec selected by the PT.
     \param[in] uiCallHdl Call Handle of the call 
     \param[in] pxCallParams Reference to call parameters
     \param[in] uiPrivateData Reference to the private data handle of the
      FT application.     
    \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
        
    \note FT application shall try to respond synchronously if possible by returning 
	IFX_SUCCESS or IFX_FAILURE. No action shall be taken if IFX_SUCCESS or 
	IFX_PENDING is returned. If IFX_FAILURE is returned, Call release is sent 
	to PT and all structures pertaining to the Call Handle are freed. No further 
	requests shall be valid on the call handle.
	
   \note For this function the following fields in CallParams will be filled bwideband.
    

*/ 
typedef   e_IFX_Return (*pfn_IFX_DECT_CSU_CallAccept)(IN uint32 uiCallHdl,
                                                    IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                       IN uint32 uiPrivateData); 
                            

/*! \brief  This callback function is used to inform the FT application that the
                   call is answered at the PT.  This callback function is invoked by the 
                   DECT TK in response to an earlier IFX_DECT_CSU_CallInitiate 
                   function call. The DECT TK invokes this callback function when it 
                   receives a CC_CONNECT message from the DECT Protocol Stack.  
                   The DECT TK fills the CallParam with the codec selected by the PT.
     \param[in] uiCallHdl Call Handle of the call 
      \param[in] pxCallParams Reference to call parameters
      \param[in] uiPrivateData Reference to the private data handle of the
      FT application.     
    \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
    \note The FT Application shall try to respond synchronously, if possible by returning 
    IFX_SUCCESS or IFX_FAILURE. If IFX_FAILURE is returned, Call release is sent to PT 
	and all structures pertaining to the Call Handle are freed. No further requests shall 
	be valid on the call handle.
    \note For this function the following fields in CallParams will be filled bwideband.
    
*/ 
typedef   e_IFX_Return (*pfn_IFX_DECT_CSU_CallAnswer)(IN uint32 uiCallHdl,
                                                    IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                       IN uint32 uiPrivateData );


/*! \brief  This callback function is used to inform the FT application that the
                   call has been released at the PT.  The PT may release an answered 
                   call or reject an incoming call.  The DECT TK invokes this callback 
                   function when it receives a CC_RELEASE message from the 
                   DECT Protocol Stack.
     \param[in] uiCallHdl Call Handle of the call 
            \param[in] pxCallParams Reference to call parameters
     \param[in] eReason Reason for release of the call. It may help FT application in
    send out an appropriate message to remote party.
   \param[in] uiPrivateData Reference to the private data handle of the
      FT application. 
    \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
    \note Irrespective of return value, all structures pertaining to this Call Handle shall be freed. 
    No further requests shall be valid on the call handle.
   \note For this function none of the fields in CallParams will be filled.
    
*/ 
typedef   e_IFX_Return (*pfn_IFX_DECT_CSU_CallRelease)(IN uint32 uiCallHdl,
                                                       IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                                       IN e_IFX_DECT_RelType eReason,
                                                       IN uint32 uiPrivateData);

/*! \brief  This callback function is used to inform the FT application about the 
                   call related information received from the PT.  The call related
                   information may be simply keypad events (DTMF digits) or 
                   proprietary IWU-IWU messages.  This information may come
                   at any point of time within a session.  The DECT TK invokes this 
                   callback function when it receives a CC_INFO message from the 
                   DECT Protocol Stack.  The DECT TK  module collects the received 
                   information and passes it to the FT application. The DECT TK
                  does not try to parse or understand received information.  The
                  DECT TK provides separate IE specific decoding functions that
                  can be used by the FT application to understand the message
                  content within CC_INFO.  The Call params structure is filled 
                  with the received information including the line information
                  ,if any. Even multi keypad info with 23 3u H where u being 
                  line Id shall be sent in the pxLine structure. If no line 
                  then NULL is passed in pxLine. 
     \param[in] uiCallHdl Call Handle of the call 
      \param[in] pxCallParams Reference to call parameters. 
   \param[in] uiPrivateData Reference to the private data handle of the
      FT application.     
    \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
    \note  Return value is ignored. No DECT Protocol message is sent out to PT.
    \note For this function the following fields in CallParams will be filled acRecvDigits and bhookflash.
*/ 
typedef   e_IFX_Return (*pfn_IFX_DECT_CSU_InfoReceived)(IN uint32 uiCallHdl,
                                                        IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                                        IN uint32 uiPrivateData);


/*! \brief  This callback function is used to inform the FT application about the
                   service change procedure invoked by the PT or a response to an 
                   earlier service change procedure invoked on the PT using the
                   IFX_DECT_CSU_ServiceChange function.  The DECT TK
                   invokes this callback function when it receives a CC_SERVICE_CHANGE,
                   or an IWU_INFO with the codec list IE.  
           If eCodecChangeType is set to IFX_DECT_SC_REQUEST, then it is implies 
                   that the PT has initiated codec change request on the established call. 
                   CallParam structure is filled with necessary codec information. 
                   If this callback returns a failure, then the call will continue to run on 
                   previously negotiated codec. PT is intimated about failure of service change
                   request.  
                   If the eCodecChangeType is set to IFX_DECT_SC_ACCEPT to indicate,
                   service change is accepted by PT, the FT application can initiate
                   procedures to switch the call to the new codec. Return value in this 
                   case is ignored.
                   If error occurs while handling remote service change request or
                   PT rejects the request, eCodecChangeType is  set to IFX_DECT_SC_REJECT
                   to indicate service change request has failed. The Call will not be 
                   released and it will continue to run on the previously negotiated
                   codec. Return value in this case is ignored.
      \param[in] uiCallHdl Call Handle of the call 
      \param[in] pxCallParams Reference to call parameters. 
      \param[in] eCodecChangeType Codec Change request or response.
    \param[in] uiPrivateData Reference to the private data handle of the
      FT application.     
    \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
    \note For this function the following fields in CallParams will be filled bwideband.
*/ 
typedef   e_IFX_Return (*pfn_IFX_DECT_CSU_ServiceChange)( IN uint32 uiCallHdl,
                                                     IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                          IN e_IFX_DECT_CSU_CodecChangeType eCodecChangeType,
                                          IN uint32 uiPrivateData   );
   
/*! \brief  This callback function is used to inform the FT application about the 
                   need to stop or start the voice path.  During a service change 
                   procedure, it is required that the voice path is stopped to
                   effect the codec change before it is restarted.  The DECT TK
                   invokes this callback function when it receives a CC_SERVICE_ACCEPT
                   or an IWU_INFO with the codec list IE.  Please refer to the flow
                   diagrams for the sequence involved.
                   If eVoiceType is set to IFX_DECT_START_VOICE, then it is implies 
                   that the voice path needs to be enabled by the FT application.  
                   The CallParams structure carries the codec information.
                   If the eVoiceType is set to IFX_DECT_STOP_VOICE to indicate,
                   service change is in progress at PT, the FT application can initiate
                   procedures to temporarily stop the voice path. 
      \param[in] uiCallHdl Call Handle of the call 
      \param[in] pxCallParams is reference to Call params. 
      \param[in] eVoiceType Start or Stop voice path.
    \param[in] uiPrivateData Reference to the private data handle of the
      FT application.  
    \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
    \note For this function the following fields in CallParams will be filled bwideband.
*/ 
typedef   e_IFX_Return (*pfn_IFX_DECT_CSU_VoiceModify)(IN uint32 uiCallHdl,
                                                IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                        IN e_IFX_DECT_CSU_VoiceEventType eVoiceType,
                                        IN uint32 uiPrivateData);
/*! \brief  This callback function is used to inform the FT application about the 
                   confirmation of the Cipher change request . The DECT TK  
                   invokes this callback function when it receives a FP_CIPHER_ON_CFM_MM
                   with the ciphering status.  Please refer to the flow
                   diagrams for the sequence involved.
      \param[in] uiCallHdl Call Handle of the call 
      \param[in] pxCallParams is reference to Call params. 
    \param[in] uiPrivateData Reference to the private data handle of the
      FT application.  
    \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
    \note For this function the following fields in CallParams will be filled bCipheringStatus.
*/ 
typedef   e_IFX_Return (*pfn_IFX_DECT_CSU_CipherCfm)(IN uint32 uiCallHdl,
                                              IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                                              IN uint32 uiPrivateData);



/*! \brief  This callback function is used to inform the FT application of
                   a call toggle request from the PT.  This callback function
                   is invoked by the DECT TK when it receives a CC_INFO request
                   from the DECT Protocol stack indicating a call toggle request
                   from the PT. 
                   The DECT TK fills the CallParams with the codec type (wideband 
                   or narrowband) and the dialled digits (if any).  The CLIP and CNIP 
                   information would be empty fields. 
   \param[in] uiSrcCallHdl Source Call Handle of the call to be toggled
   \param[in] uiDstCallHdl Destination Call Handle of the call to be toggled 
          \param[in] pxCallParams Reference to call parameters
          \param[out] peStatus Status of the request 
    \param[in] uiPrivateData Reference to the private data handle of the
      FT application.  
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
    \note The FT application shall try to respond synchronously if possible by returning 
    IFX_SUCCESS or IFX_FAILURE. If IFX_FAILURE is returned, all the internal structures 
	pertaining to the Call Handle shall be freed and PT would be intimated about failure 
	in setting up an outgoing call. No further requests shall be valid on the call handle. If 
	IFX_PENDING is returned, then the DECT TK assumes that FT Application is processing the 
	request and response is awaited. If IFX_SUCCESS is returned, then the DECT TK assumes 
	that request is successful. However no voice path will be established. FT application 
	needs to call IFX_DECT_CSU_CallAnswer to complete the call setup.
   \note For this function none of the fields in CallParams will be filled.

*/ 
typedef   e_IFX_Return (*pfn_IFX_DECT_CSU_CallToggle)(IN uint32 uiSrcCallHdl,
                                         IN uint32 uiDstCallHdl,
                                         IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                         OUT e_IFX_DECT_ErrReason *peStatus,
										 IN uint32 uiPrivateData); 

 
/*! \brief  This callback function is used to inform the FT application of
                   a call hold request from the PT.  This callback function
                   is invoked by the DECT TK when it receives a CC_INFO request
                   from the DECT Protocol stack indicating a call hold request
                   from the PT. 
                   The DECT TK fills the CallParams with the codec type (wideband 
                   or narrowband) and the dialled digits (if any).  The CLIP and CNIP 
                   information would be empty fields. 
   \param[in] uiCallHdl Call Handle of the call 
          \param[in] pxCallParams Reference to call parameters
          \param[out] peStatus Status of the request
    \param[in] uiPrivateData Reference to the private data handle of the
      FT application.  
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
    \note The FT application shall try to respond synchronously if possible by returning 
    IFX_SUCCESS or IFX_FAILURE. If IFX_FAILURE is returned, all the internal structures 
	pertaining to the Call Handle shall be freed and PT would be intimated about failure 
	in setting up an outgoing call. No further requests shall be valid on the call handle.
    If IFX_PENDING is returned, then the DECT TK assumes that FT Application is 
    processing the request and response is awaited.
   If IFX_SUCCESS is returned, then the DECT TK assumes that request is successful. 
   However no voice path will be established. 
   \note For this function none of the fields in CallParams will be filled.

*/ 
typedef   e_IFX_Return (*pfn_IFX_DECT_CSU_CallHold)(IN uint32 uiCallHdl,
                                         IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                         OUT e_IFX_DECT_ErrReason *peStatus,
										 IN uint32 uiPrivateData); 

 
/*! \brief  This callback function is used to inform the FT application of
                   a call resume request from the PT.  This callback function
                   is invoked by the DECT TK when it receives a CC_INFO request
                   from the DECT Protocol stack indicating a call resume request
                   from the PT. 
   \param[in] uiCallHdl Call Handle of the call 
          \param[in] pxCallParams Reference to call parameters
          \param[out] peStatus Status of the request
    \param[in] uiPrivateData Reference to the private data handle of the
      FT application.  
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
    \note The FT application shall try to respond synchronously if possible by returning 
    IFX_SUCCESS or IFX_FAILURE. 
    If IFX_FAILURE is returned, all the internal structures pertaining to the 
    Call Handle shall be freed and PT would be intimated about failure in setting 
    up an outgoing call. No further requests shall be valid on the call handle.
    If IFX_PENDING is returned, then the DECT TK assumes that FT Application is 
    processing the request and response is awaited.
   If IFX_SUCCESS is returned, then the DECT TK assumes that request is successful. 
   However no voice path will be established. 
   \note For this function none of the fields in CallParams will be filled.

*/ 
typedef   e_IFX_Return (*pfn_IFX_DECT_CSU_CallResume)(IN uint32 uiCallHdl,
                                         IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                         OUT e_IFX_DECT_ErrReason *peStatus,
										 IN uint32 uiPrivateData); 

/*! \brief  This callback function is used to inform the FT application of
                   a deflection request from the PT.  This callback function
                   is invoked by the DECT TK when it receives a CC_INFO request
                   from the DECT Protocol stack indicating a call deflection request
                   from the PT. 
   \param[in] uiCallHdl Call Handle of the call 
          \param[in] pxCallParams Reference to call parameters
          \param[out] peStatus Status of the request
    \param[in] uiPrivateData Reference to the private data handle of the
      FT application.  
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
    \note The FT application shall try to respond synchronously if possible by returning 
    IFX_SUCCESS or IFX_FAILURE. 
    
    If IFX_FAILURE is returned, NACK and Setup Ack will be sent to PT to resume the call.
    
   If IFX_SUCCESS is returned, then the DECT TK assumes that request is successful. 
   However no voice path will be established. 

*/
typedef   e_IFX_Return (*pfn_IFX_DECT_CSU_CallDeflect)(IN uint32 uiCallHdl,
                                         IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                         OUT e_IFX_DECT_ErrReason *peStatus,
										 IN uint32 uiPrivateData);
 
/*! \brief  This callback function is used to inform the FT application of
                   a call transfer request from the PT.  This callback function
                   is invoked by the DECT TK when it receives a CC_INFO request
                   from the DECT Protocol stack indicating a call Transfer request
                   from the PT. 
   \param[in] uiSrcCallHdl Source Call Handle of the call to be transfered
   \param[in] uiDstCallHdl Destination Call Handle of the call 
          \param[in] pxCallParams Reference to call parameters
          \param[out] peStatus  Status of the request
    \param[in] uiPrivateData Reference to the private data handle of the
      FT application.  
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
    \note The FT application shall try to respond synchronously if possible by returning 
    IFX_SUCCESS or IFX_FAILURE. 
    If IFX_FAILURE is returned, all the internal structures pertaining to the 
    Call Handle shall be freed and PT would be intimated about failure in setting 
    up an outgoing call. No further requests shall be valid on the call handle.
    If IFX_PENDING is returned, then the DECT TK assumes that FT Application is 
    processing the request and response is awaited.
   If IFX_SUCCESS is returned, then the DECT TK assumes that request is successful. 
   However no voice path will be established. 
   \note For this function none of the fields in CallParams will be filled.

*/ 
typedef   e_IFX_Return 
          (*pfn_IFX_DECT_CSU_CallTransfer)(IN uint32 uiSrcCallHdl,
                                           IN uint32 uiDstCallHdl,
                                           IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                           OUT e_IFX_DECT_ErrReason *peStatus,
										   IN uint32 uiPrivateData); 

  
/*! \brief  This callback function is used to inform the FT application of
                   a call conference request from the PT.  This callback function
                   is invoked by the DECT TK when it receives a CC_INFO request
                   from the DECT Protocol stack indicating a call conference request
                   from the PT. 
   \param[in] uiSrcCallHdl Source Call Handle of the call to be conferenced
   \param[in] uiDstCallHdl Destination Call Handle of the call that to be combined
          \param[in] pxCallParams Reference to call parameters
          \param[out] peStatus Status of the request              
    \param[in] uiPrivateData Reference to the private data handle of the
      FT application.  
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
    \note The FT application shall try to respond synchronously if possible by returning 
    IFX_SUCCESS or IFX_FAILURE. 
    If IFX_FAILURE is returned, all the internal structures pertaining to the 
    Call Handle shall be freed and PT would be intimated about failure in setting 
    up an outgoing call. No further requests shall be valid on the call handle.
    If IFX_PENDING is returned, then the DECT TK assumes that FT Application is 
    processing the request and response is awaited.
   If IFX_SUCCESS is returned, then the DECT TK assumes that request is successful. 
   However no voice path will be established. 
   \note For this function none of the fields in CallParams will be filled.

*/ 
typedef   e_IFX_Return (*pfn_IFX_DECT_CSU_CallConference)(IN uint32 uiSrcCallHdl,
                                         IN uint32 uiDstCallHdl,
                                         IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                         OUT e_IFX_DECT_ErrReason *peStatus,
										 IN uint32 uiPrivateData); 


/*! \brief  This callback function is used to notify the FT application that one of the PP among the PP's requested for
			Interception accepted the request.This is in case of multiple calls in the system.For a single call in the System
			Application has to treat that the only PP having the call is to be treated implicitly.Accept is not required for 
			a single call in the system.  
     \param[in] uiCallHdl Call Handle of the call 
      \param[in] pxCallParams Reference to call parameters. 
   \param[in] uiPrivateData Reference to the private data handle of the
      FT application.     
    \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
*/
typedef   e_IFX_Return (*pfn_IFX_DECT_CSU_InterceptAccept)(IN uint32 uiCallHdl,
                                                        IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                                        IN uint32 uiPrivateData);


/*! \brief  This callback function is used to notify the FT application that Info regarding the Intrusion is received
						if we didnt receive any Information during the Explicit Intrude request.  
     \param[in] uiCallHdl Call Handle of the call 
      \param[in] pxCallParams Reference to call parameters. 
   \param[in] uiPrivateData Reference to the private data handle of the
      FT application.     
    \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
*/
typedef   e_IFX_Return (*pfn_IFX_DECT_CSU_IntrudeInfoReceived)(IN uint32 uiCallHdl,
                                                        IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                                        IN uint32 uiPrivateData);
 
									 
 
/*!
    \brief Structure containing callback functions for CSU related procedures.
The callback functions listed in the structure need to be implemented within 
the FT application and registered with the DECT TK.
*/
typedef struct {
 pfn_IFX_DECT_CSU_CallInitiate pfnCallInitiate; /*!< Callback for notifying an Incoming call from PT*/
 pfn_IFX_DECT_CSU_GetLineInfo pfnLineInfo; /*!< Callback for fetching Line Info from agent*/
 pfn_IFX_DECT_CSU_CallAccept   pfnCallAccept;/*!< Callback for notifying the call being accepted by PT*/
 pfn_IFX_DECT_CSU_CallAnswer   pfnCallAnswer;/*!< Callback for notifying the call being answered by PT*/
 pfn_IFX_DECT_CSU_CallRelease  pfnCallRelease;/*!< Callback for notifying the call being released by PT*/
 pfn_IFX_DECT_CSU_InfoReceived pfnInfoReceived;/*!< Callback for notifying the Service info being received from PT*/
 pfn_IFX_DECT_CSU_ServiceChange pfnServiceChange; /*!< Callback for notifying the service change request/response from
 PT*/
 pfn_IFX_DECT_CSU_VoiceModify  pfnVoiceModify;/*!< Callback for notifying the FT application to start or stop media
 path */
 pfn_IFX_DECT_CSU_CipherCfm  pfnCipherCfm;/*!< Callback for notifying the FT application that Cipher change request is
 accepted */
 pfn_IFX_DECT_CSU_CallToggle pfnCallToggle;/*!< Callback for notifying the FT application for a call toggle from PT */
 pfn_IFX_DECT_CSU_CallHold pfnCallHold;/*!< Callback for notifying the FT application for a call hold from PT */
 pfn_IFX_DECT_CSU_CallResume pfnCallResume;/*!< Callback for notifying the FT application for a call Resume from PT */
 pfn_IFX_DECT_CSU_CallTransfer pfnCallTransfer;/*!< Callback for notifying the FT application for a call transfer from PT */
 pfn_IFX_DECT_CSU_CallConference pfnCallConference;/*!< Callback for notifying the FT application for a call conference from PT */
 pfn_IFX_DECT_CSU_CallDeflect pfnCallDeflect;/*!< Callback for notifying the FT application for a call Deflect from PT */
 pfn_IFX_DECT_CSU_IntrudeInfoReceived pfnIntrudeInfoRecv;/*!< Callback for Intrude Info being received from PT*/
 pfn_IFX_DECT_CSU_InterceptAccept pfnInterceptAccept;/*!< Callback for notifying the FT application for Intercept Accept from PT */
}x_IFX_DECT_CSU_CallBks;


/*! \brief  This function is used to register callback functions with the CSU for
             notifying call related events to the FT application.\n
   The FT application shall call this function during initialization.
    \param[in] pxCSUCallBks Structure containing the callback functions
    \return IFX_SUCCESS or IFX_FAILURE
*/

e_IFX_Return IFX_DECT_CSU_RegisterCallBks(IN x_IFX_DECT_CSU_CallBks *pxCSUCallBks);

/* @} */
#endif /* __IFX_DECT_CSU_H__*/
                      

