/**************************************************************************
**   FILE NAME     : IFX_DECT_Stack.h
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V2.0 
**   DATE          : 15-12-2004 
**   AUTHOR        : VOIP Team.
**   DESCRIPTION   : Function prototypes DECT Tool kit functions.
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_DECT_Stack.h
    \brief This file contains the DECT Toolkit Initialization and Configuration 
                functions and data structures. The initialization and configuration
                functions are responsible for initializing and configuring 
                the toolkit and the DECT Protocol Stack.
		   
*/

/** \ingroup DECT_TOOLKIT_MODULES
     \defgroup INIT_CONFIG_MODULE Init and Config Unit
	 \brief The Initialization and configuration Unit manages
     the initialization and configuration of the DECT Toolkit and the
     DECT stack.  The Init and Config Unit provides dual modes of
     initialization, viz., SYNC and ASYNC.  This gives the flexibility
     to the application developer to design the application independent
     of the architectural requirements of the DECT TK.  
     The interface provided by the Init and Config Unit is 
       listed in the chapter on Toolkit API.  The examples chapter
       provides source code examples illustrating the usage of the 
       Init and Config unit interfaces.
*/
/* @{ */
/* @} */


/** \ingroup DECT_TOOLKIT_API
     \defgroup INIT_CONFIG_API Init and Config Unit
	 \brief This group contains the initialization and configuration functions of the
                        DECT Toolkit.  The initialization and configuration 
                        functions are responsible for \n
                        1> Initialization of the Toolkit and the DECT Protocol Stack\n
                        2) Configuration of the Toolkit and the DECT Protocol Stack
*/
/* @{ */

#ifndef __IFX_DECT_STACK_H__
#define __IFX_DECT_STACK_H__

/*! \def IFX_DECT_TK_VERSION
    \brief Macro used to specify Toolkit Version x_y_z x_y = catiq compliance and z sub-feature*/
#define IFX_DECT_TK_VERSION "2_0_2"

/*! \def IFX_DECT_COSIC_MODEM_SW_VERSION
    \brief Macro used to specify cosic Modem software version hwchip_swver_year_mmday*/
#define IFX_DECT_COSIC_MODEM_SW_VERSION "CM20_V20_09_0720"


/*! \def IFX_DECT_READ_FDSET
    \brief Macro used to add or remove a particular fd from read fd list.
	       This macro is used only in sync mode operation of the DECT toolkit.
 */
#define IFX_DECT_READ_FDSET 0x1

/*! \def IFX_DECT_WRITE_FDSET
    \brief Macro used to add or remove a particular fd from write fd list.
	       This macro is used only in sync mode operation of the DECT toolkit.
 */
#define IFX_DECT_WRITE_FDSET 0x2

/*! \def IFX_DECT_EXCEP_FDSET
    \brief Macro used to add or remove a particular fd from exception fd list.
	       This macro is used only in sync mode operation of the DECT toolkit.
 */
#define IFX_DECT_EXCEP_FDSET 0x4

/*! \def IFX_DECT_SYNC_MODE
    \brief Macro used to specify the DECT Toolkit to operate in SYNC mode. In sync mode the DECT toolkit
	       would not spawn a thread/process, but will execute in the FT application context itself.
 */
#define IFX_DECT_SYNC_MODE 0x1

/*! \def IFX_DECT_ASYNC_MODE
    \brief Macro used to specify the DECT Toolkit to operate in ASYNC mode. In async mode the DECT toolkit
	       would spawn a thread, and execute in its own context for listening to incoming events from DECT stack.
		   The callbacks and functions are available to caller function, as the new thread shares the address space
		   with the FT application.
 */
#define IFX_DECT_ASYNC_MODE 0x2


/*! \def IFX_DECT_MAX_HS
    \brief Macro used to specify the Maximum handsets handled by the DECT toolkit*/
#define IFX_DECT_MAX_HS 6

/*! \def IFX_DECT_MAX_RFPI_LEN
    \brief Macro used to specify Maximum Radio Fixed Part ID Length*/
#define IFX_DECT_MAX_RFPI_LEN 5

/*! \def IFX_DECT_MAX_BASE_PIN_LEN
    \brief Macro used to specify Maximum Base pin length*/
#define IFX_DECT_MAX_BASE_PIN_LEN 15

/*! \def IFX_FW_DOWNLOAD_SUCCESS
    \brief Macro to indicate the Application that COSIC firmware has downloaded successfully*/
# define IFX_FW_DOWNLOAD_SUCCESS 99

/*! \def IFX_FW_DOWNLOAD_SUCCESS 
    \brief Macro to indicate the Application that COSIC firmware has shutdown successfully*/
# define IFX_DECT_SHUTDOWN_SUCCESS 98

#define LTQ_DECT_ENC_BITMAP 0x01
#define LTQ_DECT_NEMO_BITMAP 0x02
#define LTQ_DECT_RF_BITMAP 0x04

/*! \enum e_IFX_DECT_RelType
    \brief Enum defining various release types and reasons for a call. 
                The FT application needs to specify the release/type reason 
                while closing the connection with the handset. Similarly it may
	     receive these reasons for connections terminated from handset side.
*/
typedef enum {
	IFX_DECT_RELEASE_NORMAL=0, /*!< Normal release */
	IFX_DECT_MEDIA_NEG_FAILED=0x07, /*!< Media Negotiation Failed */
	IFX_DECT_RELEASE_PARTIAL=0x0E, /*!< Partial release */
	IFX_DECT_RELEASE_ABNORMAL=0x0F, /*!< Abnormal release */
  IFX_DECT_RELEASE_ENCR_ACT_FAIL=0x41,/*!< Encryption activation failed */
  IFX_DECT_RELEASE_LINE_INUSE=0x42  /*!< Call release for Line in use  */
}e_IFX_DECT_RelType;


/*! \enum e_IFX_DECT_CallType
    \brief Enum defining various Call types  for a call. 
                The FT application needs to specify the call type 
                while initiating the connection with the handset. Similarly it may
	     receive these call type for connections originated from the handset side.
*/
typedef enum{
IFX_DECT_DATA_CALL =0x89, /*!< Data Call DPRS call*/
IFX_DECT_EXTERNAL_CALL = 0x80,/*!< External narrow band call*/
IFX_DECT_INTERNAL_CALL = 0x90,/*!< Internal narrow band call*/
IFX_DECT_EMERGENCY_CALL =0xA0,/*!< Emergency narrow band call*/
IFX_DECT_SERVICE_CALL = 0xB0,/*!< Service call*/
IFX_DECT_WBS_EXTERNAL_CALL = 0x88,/*!< External wideband call*/
IFX_DECT_WBS_INTERNAL_CALL = 0x98,/*!< Internal wideband call*/
IFX_DECT_WBS_EMERGENCY_CALL = 0xA8,/*!< Emergency wideband call*/
IFX_DECT_WBS_SERVICE_CALL = 0xB8,/*!< Service Call with wideband speech attributes*/
IFX_DECT_WBS_LIA_CALL = 0x28,/*!< List Access Call with wideband speech attributes*/
IFX_DECT_CALL_INTERCEPT_REQ=0x29, /*!< Call Intercept Request */
IFX_DECT_CALL_INTRUSION_REQ=0x30 /*!< Call Intrusion Request */
}e_IFX_DECT_CallType;


/*! \enum e_IFX_DECT_ErrReason
    \brief Enum defining various error types and reasons for a call. 
                The FT application needs to specify the error reason 
                if any, while processing the request from handset.
*/
typedef enum {
    IFX_DECT_NORMAL = 0x00,  				/*!< Normal */
    IFX_DECT_UNEXPECTED_MESSAGE = 0x01, 	/*!< Unexpected Message */
    IFX_DECT_UNKNOWN_TRANSACTION_IDENTIFIER = 0x02, /*!< Unknown Transaction Identifier */
    IFX_DECT_MANDATORY_IE_MISSING = 0x03, 	/*!< Mandatory IE missing */
    IFX_DECT_INVALID_IE_CONTENTS = 0x04, 	/*!< Invalid Information Element contents */
    IFX_DECT_INCOMPATIBLE_SERVICE= 0x05, 	/*!< Incompatible Service */
    IFX_DECT_SERVICE_NOT_IMPLEMENTED = 0x06, /*!< Service not implemented */
    IFX_DECT_NEGOTIATION_NOT_SUPPORTED = 0x07, /*!< Negotiation not supported */
    IFX_DECT_INVALID_IDENTITY = 0x08, 		/*!< Invalid identity */
    IFX_DECT_AUTHENTICATION_FAILED = 0x09, 	/*!< Authentication failed */
    /* 0x0A - 0x0C Reserved */
    IFX_DECT_TIMER_EXPIRY = 0x0D, 			/*!< Timer Expiry */
    IFX_DECT_PARTIAL_RELEASE = 0x0E, 		/*!< Partial Release */
    IFX_DECT_UNKNOWN = 0x0F, 				/*!< Unknown */

    /* User Values                      */
    IFX_DECT_USER_DETACHED = 0x10, 			/*!< User detached */
    IFX_DECT_USER_NOT_IN_RANGE = 0x11, 		/*!< User not in range */
    IFX_DECT_USER_UNKNOWN = 0x12, 			/*!< User unknown */
    IFX_DECT_USER_ALREADY_ACTIVE = 0x13, 	/*!< User already active */
    IFX_DECT_USER_BUSY = 0x14, 				/*!< User Busy */
    IFX_DECT_USER_REJECTION = 0x15, 		/*!< User Rejection */
   
    /* External Handover Values         */ 
    IFX_DECT_EXT_HANDOVER_NOT_SUPPORTED = 0x21, /*!< External Handover Not Supported */
    IFX_DECT_NETWORK_PARAMETERS_MISSING = 0x22, /*!< Network Parameter Missing */
    IFX_DECT_EXT_HANDOVER_RELEASE = 0x23, 	/*!< External Handover Release */

    /* Temporary Overload Values        */
    IFX_DECT_OVERLOAD = 0x31, 				/*!< Overload */
    IFX_DECT_INSUFFICIENT_RESOURCES = 0x32, /*!< Insufficient Resources */
    IFX_DECT_INSUFFICIENT_BEARERS_AVAILABLE = 0x33, /*!< Insufficient Bearers Available */
    IFX_DECT_IWU_CONGESTION = 0x34, 		/*!< IWU Congestion */
}e_IFX_DECT_ErrReason;
/*!
   \brief This callback function is implemented by the FT application, hence application
   specific.  The application registers this function alongwith one or more FDs for 
   listening on, in the select system call.  Whenever there is some activity on 
   the FD, this callback would be invoked by the DECT Toolkit on the application.
   \param[in] pxRdFdSet Pointer to the FDSET array of Read File Descriptors
   \param[in] pxWrFdSet Pointer to the FDSET array of Write File Descriptors
   \param[in] pxExFdSet Pointer to the FDSET array of Exception File Descriptors
   \param[in,out] piNoOfFd is the number of FDs unblocked
 */

typedef void (*pfn_IFX_DECT_FdCallback)(IN fd_set *pxRdFdSet,
                                        IN fd_set *pxWrFdSet,
                                        IN fd_set *pxExFdSet,
                                        IN_OUT int32 *piNoOfFd);
                                        
/*!
           \brief Structure containing  function pointers for handling internal file descriptors.	  
  	\note  These Callbacks need to be registered only if the DECT toolkit is
           being initialized in sync mode.
 */
typedef struct
{
	void (*pfnAddFDToSelect)(IN int32 iFd,
                 IN int32 iTypeofFDSet,IN pfn_IFX_DECT_FdCallback);/*!< Invoked on addition of fd to fdset */	
	void (*pfnRemoveFDToSelect) (IN int32 iFd,
            IN int32 iTypeofFDSet);/*!< Invoked on removal of fd from fdset */	
}x_IFX_DECT_SyncCallBks;

/*!
        \brief  Structure containing all the Transmit Power Measurement register parameters. 
        These parameters are required to initialize the BMC firmware.
 */

typedef struct
{
	uchar8 ucTuneDigitalRef; /*!< Tune Digital Reference - Recommended value is 0x47. */
	uchar8 ucPABiasRef; /*!<  PA Bias Reference - Recommended value is 0x37. */
	uchar8 ucPowerOffset[5];/*!< Power Offset - Recommended values are \n
		ucPowerOffset[0]:(-5 dB) 0x17\n
		ucPowerOffset[1]:(10 dB) 0x0B\n
		ucPowerOffset[2]:(15 dB) 0x06\n
		ucPowerOffset[3]:(20 dB) 0x03\n
		ucPowerOffset[4]:(25 dB) 0x02\n
		*/
	uchar8 ucTD1; /*!< Tune Digital Sample 1 - Recommended value is 0x4C. */
	uchar8 ucTD2; /*!< Tune Digital Sample 2 - Recommended value is 0x47. */
	uchar8 ucTD3; /*!< Tune Digital Sample 3 - Recommended value is 0x42. */
	uchar8 ucPA1; /*!< Power Amplifier Sample 1 - Recommended value is 0x21. */
	uchar8 ucPA2; /*!< Power Amplifier Sample 1 - Recommended value is 0x37. */
	uchar8 ucPA3; /*!< Power Amplifier Sample 1 - Recommended value is 0x50. */
	
	/*! SW Power Mode  is one of the IFX_VMAPI_SW_POWERMODE_ values */
	
	uchar8 ucSWPowerMode; /*!<Tx power mode.  Default is Constant Power Mode, 0x00.*/
	
	/** Constant power mode for all channels*/
	#define IFX_DECT_SW_POWERMODE_CONSTANT 0x00
	/** Adaptive mode for all channels*/
	#define IFX_DECT_SW_POWERMODE_ADAPTIVE 0x01
	/** User mode for all channels*/
	#define IFX_DECT_SW_POWERMODE_USER 0x03
	
	
	/** Tx power mode for MCEI channel 0: Full Power Mode */
	#define IFX_DECT_MCEI_FULLPOWERMODE 0x00
	/**Tx power mode for MCEI channel 0:  5 dB Backoff Mode */
	#define IFX_DECT_MCEI_FIVEDB 0x01
	/** Tx power mode for MCEI channel 0:  10 dB Backoff Mode */
	#define IFX_DECT_MCEI_TENDB 0x02
	/** Tx power mode for MCEI channel 0:  15 dB Backoff Mode */
	#define IFX_DECT_MCEI_FIFTEENDB 0x03
	/**  Tx power mode for MCEI channel 0:  20 dB Backoff Mode */
	#define IFX_DECT_MCEI_TWENTYDB 0x04
	/**  Tx power mode for MCEI channel 0:  25 dB Backoff Mode */
	#define IFX_DECT_MCEI_TWENTYFIVEDB 0x05
	/** Tx power mode for MCEI channel 0:  25 dB Backoff Mode */
	#define IFX_DECT_MCEI_THIRTYDB 0x06
	/** Tx power mode for MCEI channel 0: Minimum Power Mode */
	#define IFX_DECT_MCEI_MIN_POWERMODE 0x0E
	/**  Tx power mode for MCEI channel 0: User Mode */
	#define IFX_DECT_MCEI_USERMODE 0x0F
   /** Tx power mode for MCEI channel 0 is one of the  IFX_VMAPI_MCEI_values  */
	uchar8 ucTXPOW_0; /*!<Tx power mode for MCEI channel 0. Default is FULL_POWER_MODE. */
	
	/** Tx power mode for MCEI channel 1 is one of the  IFX_VMAPI_MCEI_values  */
	uchar8 ucTXPOW_1; /*!<Tx power mode for MCEI channel 1. Default is FULL_POWER_MODE. */
	
	/** Tx power mode for MCEI channel 2 is one of the  IFX_VMAPI_MCEI_values  */	
	uchar8 ucTXPOW_2; /*!<Tx power mode for MCEI channel 2. Default is FULL_POWER_MODE. */
	
	/** Tx power mode for MCEI channel 3 is one of the  IFX_VMAPI_MCEI_values  */
	uchar8 ucTXPOW_3; /*!<Tx power mode for MCEI channel 3. Default is FULL_POWER_MODE. */

	 /** Tx power mode for MCEI channel 4 is one of the  IFX_VMAPI_MCEI_values  */
	uchar8 ucTXPOW_4; /*!<Tx power mode for MCEI channel 4. Default is FULL_POWER_MODE. */
	
	 /** Tx power mode for MCEI channel 5 is one of the  IFX_VMAPI_MCEI_values  */
	uchar8 ucTXPOW_5; /*!<Tx power mode for MCEI channel 5. Default is FULL_POWER_MODE. */
	
	/** Tx power mode for the dummy bearer is one of the  IFX_VMAPI_MCEI_values  */
	uchar8 ucDBPOW; /*!<Tx power mode for MCEI channel 5. Default is FULL_POWER_MODE. */

	uchar8 ucTuneDigital;/*!< Read only attribute.  BMC FW updates this value when a Tx channel 
		is active within the TxSyncWordTask */

	uchar8 ucTxBias;/*!< Used for Bias in any of the power modes. Default is 0xFF at Modem Init. */
} x_IFX_DECT_TransmitPowerParam;

/*!
        \brief  Structure containing all the Burst Mode Control register parameters. 
        These parameters are required to initialize the BMC firmware.  Some of the parameters
		defined in the structure are unused.  Hence the user need not set those values.  
		While reading the structure, the unused parameters need to be ignored.
 */

typedef struct
{
	uchar8 ucRSSIFreeLevel; /*!< RSSI Free level value, Range 0x00-0x1F. Recommended value is 0x07. */
	uchar8 ucRSSIBusyLevel; /*!< RSSI Busy level value, Range 0x00-0x1F. Recommended value is 0x0E. */
	uchar8 ucBearerChgLim; /*!< Bearer Change limit for RSSI,  Range 0x00-0x1F. Recommended value is 0x0F. 
	When the RSSI level of the DB channel is higher than this level, handover of the DB will be done. */

	uchar8 ucDefaultAntenna; /*!< Default Antenna Settings, 
		Recommended value is 0x81.  Means Antenna diversity is enabled and Antenna is 1. \n
		bit 7:Used for Dual scan. \n
        bit 6:Used for Antenna inhibit. \n
        bit 5:Enable/Disable CoC. Defined for future use. \n
        bit 4:Enable/Disable CLMS. Defined for future use. \n
		bit 3:Unused. \n
		bit 2:Unused. \n
		bit 1:Enable/Disable Korea DECT. \n
		bit 0:1 means antenna 1 is default, 0 means antenna 0 is default.\n
		When antenna diversity is enabled, the FP makes use of RSSI measurements 
		on a certain preamble sent by PP before the FP active traffic 
		bearer receive. The antenna with the higher receive level is then 
		choosen for receive and transmit until next update is made.  
	*/

	uchar8 ucWOPNSF; /*!< Windows open sync free mode, Recommended value is 0x20. */
	uchar8 ucWWSF; /*!< Window width sync-free mode, Recommended value is 0x08.*/
	uchar8 ucCNTUPCtrlReg; /*!< Control Register for DRON, Recommended value is 0x01. */
	uchar8 ucDelayReg; /*!< Delay Compensation Register, Recommended value is 0x13. \n
		bit 7:DECT6.0 Test. Defined for future use.\n
		bit 6:Long slot TBR6. Defined for future use.\n	
		bit 5:BMC_IOMCON 0x28 or 0x00. Defined for future use. \n
		bit 4:Enable/Disable Auto Mute. Should be enabled by default.\n
		*/
	uchar8 ucHandOverEvalper; /*!< Handover evaluation period,Recommended value is  0x04. \n
		Sets the number of DECT frames used for the comparative evaluation of the quality 
		of the actual traffic bearer and the handover bearer until deciding which bearer 
		is better.*/
	uchar8 ucSYNCMCtrlReg; /*!< General Sync Mode control register, Recommended value is 0xA4. \n
		bit 7:Enable/Disable SPI isolation. Enable if another device requires SPI.\n
		bit 6:Enable/Disable new voice header. Defined for future use.\n
	*/
	uchar8 ucReserved_0 ; /*!< Unused Parameter. Defined for future use. */
	uchar8 ucReserved_1; /*!< Unused Parameter. Defined for future use. */
	uchar8 ucReserved_2 ; /*!< Unused Parameter. Defined for future use. */
	uchar8 ucReserved_3; /*!< Unused Parameter. Defined for future use. */		

	uchar8 ucGENMUTCTRL0; /*!< Unused Parameter. General Mute control Register - first byte. */
	uchar8 ucGENMUTCTRL1; /*!< Unused Parameter. General Mute control Register - second byte. */
	uchar8 ucEXTMUTCTRL0; /*!< Unused Parameter. External Mute control Register. */
}x_IFX_DECT_BMCRegParams;


/*! \def IFX_DECT_CHECK_SUM_SIZE
    \brief  Check Sum Size.
 */
#define IFX_DECT_CHECK_SUM_SIZE 2

/*!
    \brief Structure containing the Oscillator Trimming values. 
 */
typedef struct
{
	uchar8 ucOscTrimValHI;  /*!< OSC Trim value - high byte, Recommended value is 0*/
	uchar8 ucOscTrimValLOW; /*!< OSC trim value - low byte, Recommended value is 47*/
	uchar8 aucCheckSum[IFX_DECT_CHECK_SUM_SIZE]; /*!< Checksum, Recommended value is "0" */

}x_IFX_DECT_OscTrimVal;

/*! \def IFX_DECT_IPUI_SIZE
      \brief Size of IPUI */
#define IFX_DECT_IPUI_SIZE 5
/*! \def IFX_DECT_TPUI_SIZE
      \brief Size of TPUI */
#define IFX_DECT_TPUI_SIZE 3
/*! \def IFX_DECT_AUTH_KEY_SIZE
      \brief Size of authentication key */
#define IFX_DECT_AUTH_KEY_SIZE 16
/*! \def IFX_DECT_CIPHER_KEY_SIZE
      \brief Size of cipher key */
#define IFX_DECT_CIPHER_KEY_SIZE 8

/*!
    \brief Structure containing previous Subscription/Registration Information.	  
 */
typedef struct
{
  uchar8  cstatus;              /*!< Handset registration  status */
  uchar8  acipui_array[IFX_DECT_IPUI_SIZE]; /*!< Handset IPUI number */ 
  uchar8  actpui_array[IFX_DECT_TPUI_SIZE]; /*!< Handset TPUI number */
  uchar8  acuak_array[IFX_DECT_AUTH_KEY_SIZE];    /*!< Handset authentication key*/
  uchar8  acdck_array[IFX_DECT_CIPHER_KEY_SIZE];/*!< Handset Cipher key */
  uchar8  cservice_class;/*!< Service class */
  uchar8  cmodel_id;/*!< Handset model ID */
  uint32  uiTermCap; /*!< Terminal Capabilities */
}x_IFX_DECT_SubscInfo;

/*! \def x_IFX_DECT_FTRegList
      \brief Alias for x_IFX_DECT_SubscInfo */
#define x_IFX_DECT_FTRegList x_IFX_DECT_SubscInfo
/*!
    \brief Structure containing FT Capability Information, 
	 that shall be brodcasted regularly as part of MAC layer broadcast services.
	 \note The FT App needs to fill from bit 8 to bit 47. For example to set the 8th,10th and
	 13th bit of FixedCap, user needs to set aucFixedPartCap[0]=0xA4. Refer to ETSI EN 300 175-5
	 V2.2.0 Annex F for more details.
 */
typedef struct
{
  uchar8 aucFixedPartCap[5];/*!< Higher Layer Capabilities */
  uchar8 aucExtendedFixedCap[5];/*!< Extended Higher Layer Capabilities*/
  uchar8 aucExtended2FixedCap[5];/*!< Extended Higher layer Capabilities*/
}x_IFX_DECT_FTCap;



/*!
    \brief Structure containing DECT Toolkit configuration parameters.	  
 */
typedef struct
{
  int8 iDbgType;/*!< Debug Type  */	
  int8 iDbgLvl;/*!< Debug Lvl */
  uchar8 aucRfpi[IFX_DECT_MAX_RFPI_LEN]; /*!< RFPI Identifier*/
  x_IFX_DECT_TransmitPowerParam xTPCPrams; /*!< TPC parameters*/ 
  x_IFX_DECT_BMCRegParams xBMCPrams; /*!< BMC parameters*/ 
  x_IFX_DECT_OscTrimVal xOscTrimVal; /*!< Osc Tim Values*/
  uint16 unGaussianVal; /*!< Gaussian Value,Recommended value is 175 */
  x_IFX_DECT_SubscInfo xRegList[IFX_DECT_MAX_HS]; /*!< Previously registered PT information*/
  uchar8 ucNoOfReg; /*!< Count of previously registered PT*/
  uchar8 ucCodec_Pri1; /*!< Codec Priority 1*/
  uchar8 ucCodec_Pri2;/*!< Codec Priority 2*/
  char8 ucMaxHandsets;/*!< Max Number of handsets that can attach to the base*/
#ifdef CAT_IQ2_0
  uint32 auiTermCap[IFX_DECT_MAX_HS]; /*!< Terminal Capability */
  uint32 uiNoOfFramesNeMo; /*!< Number of frames used for N210, used during NeMO mode */
#endif /*  CAT_IQ2_0 */
  char8 acBasePin[IFX_DECT_MAX_BASE_PIN_LEN]; /*!< Pin Code*/
  x_IFX_DECT_FTCap xFTCapabilities; /*!< FT capabilities*/
  boolean bEncryption;/*!< Encryption configuration */
  boolean bRfEnable; /*!< Rf Turn on/off*/
  int32 iDectfd;/*!Dect drv_fd*/
  int32 iTimerfd;/*!Timer Fd*/
}x_IFX_DECT_StackInitCfg;

/*!
    \brief Structure containing debug settings for the DECT toolkit.
  	\note  These are configuration parameters that can be changed runtime.
 */
typedef struct
{
  int8 iDbgType;/*!< Debug Type  */	
  int8 iDbgLvl;/*!< Debug Lvl */
  char8 acBasePin[IFX_DECT_MAX_BASE_PIN_LEN]; /*!< Pin Code*/
  x_IFX_DECT_FTCap xFTCapabilities; /*!< FT capabilities*/
  boolean bEncryption;/*!< Encryption configuration */
  boolean bRfEnable; /*!< Rf Turn on/off*/

}x_IFX_DECT_StackCfg;

/*! \enum e_IFX_DECT_CfgType
    \brief Enum describing the run time configuration parameters.
 */
typedef enum {
 IFX_DECT_CONFIG_DBG=0, /*!< Change in debug settings*/
 IFX_DECT_CONFIG_PIN=1, /*!< Change in System PIN */
 IFX_DECT_CONFIG_FTCAP=2, /*!< Change in FT Capabilities*/
 IFX_DECT_CONFIG_ENCRYPT=3, /*!< Change in Encryption option*/
 IFX_DECT_CONFIG_RF=4, /*!< Change in Rf on/off option*/
 IFX_DECT_CONFIG_ALL=5 /*!< Change in all configurable params*/
}e_IFX_DECT_CfgType;

/*! \brief Callback function  to indicate the initialization 
        status of the DECT toolkit when operating in async or sync modes.	  
  	\note  This call back should be provided by the FT application, so that the toolkit shall 
                        inform its initialization status. iStatus value shall be 
                        either IFX_SUCCESS or IFX_FAILURE.
 */
typedef void (*pfn_IFX_DECT_InitStatus)(int32 iStatus);

/*! \brief  This function is used to initialize the DECT toolkit in ASYNC Mode. 
                    The FT application should call this function if it wants to 
                    run the DECT Toolkit in ASYNC mode. The ASYNC and SYNC
                    modes are mutually exclusive.
                    This function creates a thread for listening on incoming
                    DECT events. The status of the initialization is reported 
                    back to the FT application using the pfnInitStatus callback.
                   
	\param[in] pxInitCfg DECT Stack Initialization and Configuration parameters
           \param[in] pfnInit Callback function that shall be called 
                                            to report success or failure of the initialization 
	\return IFX_SUCCESS or IFX_FAILURE											
    \note In ASYNC mode a new thread is spawned. The thread maintains its own
          FD list and acts accordingly. The functions end their execution after
          intimating the request to the thread and callbacks are called in 
          the thread context. The FT application developers need to ensure that
          the callback path is not overloaded.
           
*/
PUBLIC int32 IFX_DECT_Async_Init(IN x_IFX_DECT_StackInitCfg *pxInitCfg,
                                 IN pfn_IFX_DECT_InitStatus pfnInit);

/*! \brief  This function is used to initialize the DECT toolkit in SYNC Mode. 
                    The FT application should call this function if it wants to 
                    run the DECT Toolkit in SYNC mode.  The ASYNC and SYNC
                    modes are mutually exclusive.
                    The status of the initialization is reported 
                    back to the FT application through the pfnInitStatus callback.
	\param[in] pxInitCfg DECT Stack Initialization and Configuration parameters
	\param[in] pxSyncCallBks Structure that contains call back 
					     functions to add and remove internal socket fd
					     to and from Read Fd set.
    \return IFX_SUCCESS or IFX_FAILURE
	\note In SYNC mode, the toolkit hands over the FDs to the application and 
          provides a recv()  function to handle  the messages. No separate 
          thread/process is spawned. The functions and callbacks are executed in 
          the same context as the process.
    
*/
PUBLIC int32 IFX_DECT_Sync_Init(
		        IN  x_IFX_DECT_StackInitCfg *pxInitCfg,
                IN x_IFX_DECT_SyncCallBks *pxSyncCallBks);


/*! \brief   This function is used to configure the DECT toolkit. 
            This function is invoked by the FT application to change debug or 
            base PIN parameters during run time.
    \param[in] eCfgOption What Configuration parameters are being changed
    \param[in] pxDECTStackCfg DECT stack runtime configuration parameters.
    \return  IFX_SUCCESS or IFX_FAILURE
*/
PUBLIC int32 IFX_DECT_Configure(IN e_IFX_DECT_CfgType eCfgOption,
                                IN x_IFX_DECT_StackCfg *pxDECTStackCfg);


/*! \brief   This function is used to shutdown the DECT toolkit. The function is called by FT  application
              to free all resources and to shutdown DECT toolkit.
    \return  IFX_SUCCESS or IFX_FAILURE
*/
PUBLIC int32 IFX_DECT_Shut(void);

/* @} */
#endif /*__IFX_DECT_STACK_H__*/


