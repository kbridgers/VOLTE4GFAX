/**************************************************************************
**   FILE NAME     : IFX_DECT_ESU.h
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V2.0 
**   DATE          : 15-12-2004 
**   AUTHOR        : VOIP Team.
**   DESCRIPTION   : Function prototypes ESU functions.
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   Software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_DECT_ESU.h
    \brief This file contains the Extension Service Unit (ESU) Procedures.
	      The ESU provides a set of procedures that allow the direct 
                 and transparent interaction with the DECT Protocol stack. 
                 ESU allows FT application developers
                 to develop their own services when such services are not supported 
                 within the DECT TK. It should be noted that the services
                 developed on top of the ESU also remain transparent to
                 the ESU module of the DECT TK.
*/

/** \ingroup DECT_TOOLKIT_MODULES
    \defgroup ESU_MODULE Extension Service Unit
    \brief The Extension Service Unit is an optional module that
    gives the application developer freedom to develop service
    logic directly on top of the DECT protocol stack, in spite of the 
    presence of the DECT TK.  This ensures that the application 
    developer is not blocked because of absence of service logic
    within the toolkit.  For a CAT iq 2.0 system, the ESU is
    optional.  The CSU interfaces are fully equipped to manage 
    the needs of such a system.  The interface provided by the ESU is 
       listed in the chapter on Toolkit API.  The examples chapter
       provides source code examples illustrating the usage of the ESU
       interfaces.
    \note ESU APIs allows the application developer to enhance the functionality on top of existing S_FORMAT messages only 
*/    
/* @{ */
/* @} */

#ifndef __IFX_DECT_ESU_H__
#define __IFX_DECT_ESU_H__

/** \ingroup DECT_TOOLKIT_API
    \defgroup ESU_API Extension Service Unit
    \brief This group contains the Extension Service Unit (ESU) functions
                of the DECT toolkit.  It provides a set of procedures \n
                    1> That allow the establishment,  maintenance and release of circuit
		       switched services.\n
		   2>  That also provide a set of low-level functions for application user to
		      design his/her own services.  Within these low-level functions,
                           the DECT Toolkit does not attempt to parse/understand the received
                           information, but simply passes it transparently to the FT
                           application.  The DECT TK provides separate IE specific decoding
                           functions to parse the received information.  Typically, each 
                           low-level function signifies a DECT protocol primitive.
*/
/* @{ */

/* ****************************************************************************
 * Callback Functions
 * ****************************************************************************/
/*! \brief  This callback function is used to inform the FT application of
                   an outgoing call request from the PT.  This callback function
                   is invoked by the DECT TK when it receives a CC_SETUP request
                   from the DECT Protocol stack indicating an outgoing call request
                   from the PT. The IE buffer is filled with the received information. 
	\param[in] ucHandsetId Handset Identifier of source PT
          \param[in] uiIEHdl Reference to IE buffer.
	\param[out] puiPrivateData Reference to the private data handle of the FT 
                                  application. ESU shall maintain this handle and 
                                  pass it to the FT Application in all callback(s).
	\return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
    \note The FT application shall try to respond synchronously if possible by returning 
    IFX_SUCCESS or IFX_FAILURE. 
    
    If IFX_FAILURE is returned, all the internal structures pertaining to the 
    Call shall be freed and PT would be intimated about failure in setting 
    up an outgoing call. 
    
    If IFX_PENDING is returned, then the DECT TK assumes that FT Application is 
    processing the request and response is awaited.
    
   If IFX_SUCCESS is returned, then the DECT TK assumes that request is successful. 
   FT application needs to call IFX_DECT_ESU_Connect  to complete the call setup.

*/ 
typedef e_IFX_Return (*pfn_IFX_DECT_ESU_Setup)(IN uchar8 ucHandsetId,
			                                   IN uint32 uiIEHdl,
                                               OUT uint32 *puiPrivateData);
									 
/*! \brief  This callback function is used to inform the FT application that the
                   call is accepted at the PT and the PT is in the alerting state.  
                   This callback function is invoked by the DECT TK in response
                   to an earlier IFX_DECT_ESU_Setup function call. The
                   DECT TK invokes this callback function when it receives a 
                   CC_ALERT message from the DECT Protocol Stack.
	\param[in] ucHandsetId Handset Identifier of source PT
    \param[in] uiIEHdl Reference to IE buffer.
	\param[in] uiPrivateData Reference to the private data handle of the
		FT application.	  
	
    \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
    \note FT application shall try to respond synchronously if possible by returning 
    IFX_SUCCESS or IFX_FAILURE. 
    
    No action shall be taken if IFX_SUCCESS or IFX_PENDING is returned. 

    If IFX_FAILURE is returned, Call release is sent to PT and all structures 
    pertaining to the Call are freed.
*/ 
typedef e_IFX_Return (*pfn_IFX_DECT_ESU_Alert)(IN uchar8 ucHandsetId,
			                                   IN uint32 uiIEHdl,
                                               IN uint32 uiPrivateData);

/*! \brief  This callback function is used to inform the FT application that the
                   call is answered at the PT.  This callback function is invoked by the 
                   DECT TK in response to an earlier IFX_DECT_ESU_Setup
                   function call. The DECT TK invokes this callback function when it 
                   receives a CC_CONNECT message from the DECT Protocol Stack. 
	\param[in] ucHandsetId Handset Identifier of source PT
    \param[in] uiIEHdl Reference to IE buffer.
	\param[in] uiPrivateData Reference to the private data handle of the
		FT application.	  
    \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
    \note The FT Application shall try to respond synchronously, if possible by returning 
    IFX_SUCCESS or IFX_FAILURE. 
    If IFX_SUCCESS/ IFX_PENDING is returned, then preliminary steps would be taken to
    establish the voice path.
    If IFX_FAILURE is returned, Call release is sent to PT and all structures
    pertaining to the Call Handle are freed.
    
*/ 
typedef	e_IFX_Return (*pfn_IFX_DECT_ESU_Connect)(IN uchar8 ucHandsetId,
			                                     IN uint32 uiIEHdl,
                                                 IN uint32 uiPrivateData);


/*! \brief  This callback function is used to inform the FT application that the
                   call has been released at the PT. The PT may release answered 
                   call or reject an incoming call. The DECT TK invokes this callback 
                   function when it receives a CC_RELEASE message from the 
                   DECT Protocol Stack.
	\param[in] ucHandsetId Handset Identifier of source PT
    \param[in] uiIEHdl Reference to IE buffer.
    	\param[in] eReason Release reason.
	\param[in] uiPrivateData Reference to the private data handle of the
		FT application.	  
    \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
    \note Irrespective of return value, all structures pertaining to this Call shall be freed. 
    
*/ 
typedef	e_IFX_Return (*pfn_IFX_DECT_ESU_Release)(IN uchar8 ucHandsetId,
                                                 IN uint32 uiIEHdl,
                                                 IN e_IFX_DECT_RelType eReason,
                                                 IN uint32 uiPrivateData);

/*! \brief  This callback function is used to inform the FT application about the 
                   call related information received from the PT.  The call related
                   information may be simply keypad events (DTMF digits) or 
                   proprietary IWU-IWU messages.  This information may come
                   at any point of time within a session.  The DECT TK invokes this 
                   callback function when it receives a CC_INFO message from the 
                   DECT Protocol Stack.  The DECT TK  module collects the received 
                   information and passes it to the FT application. 
	\param[in] ucHandsetId Handset Identifier of source PT
    \param[in] uiIEHdl Reference to IE buffer.
	\param[in] uiPrivateData Reference to the private data handle of the
		FT application.	  
    \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
    \note  Return value is ignored. No DECT Protocol message is sent out to PT.
*/ 
typedef	e_IFX_Return(*pfn_IFX_DECT_ESU_CCInfo)(IN uchar8 ucHandsetId,
			                                   IN uint32 uiIEHdl,
                                               IN uint32 uiPrivateData);
												   
/*! \brief  This callback function is used to inform the FT application about the 
                   application related information received from the PT.The application
				   related information may be proprietary IWU-IWU messages. 
				   This information may come at any point of time within a session.
				   The DECT TK invokes this callback function when it receives a IWU_INFO 
				   message from the DECT Protocol Stack.  
	\param[in] ucHandsetId Handset Identifier of source PT
    \param[in] uiIEHdl Reference to IE buffer.
	\param[in] uiPrivateData Reference to the private data handle of the
		FT application.	  
    \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
    \note  Return value is ignored. No DECT Protocol message is sent out to PT.
*/ 
typedef	
	e_IFX_Return (*pfn_IFX_DECT_ESU_IWUInfo)(IN uchar8 ucHandsetId,
			                                 IN uint32 uiIEHdl,
                                             IN uint32 uiPrivateData);
	
/*! \brief  This callback function is used to inform the FT application about the 
                   Facility message being received from the PT.  The Facility related
                   message may be Time and Date Sync/ Event Notifications or 
                   proprietary IWU-IWU messages.  This information may come
                   at any point of time within a session.  The DECT TK invokes this 
                   callback function when it receives a FACILITY message from the 
                   DECT Protocol Stack.  
	\param[in] ucHandsetId Handset Identifier of source PT
    \param[in] uiIEHdl Reference to IE buffer.
    \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
    \note  Return value is ignored. No DECT Protocol message is sent out to PT.
*/ 
typedef	e_IFX_Return (*pfn_IFX_DECT_ESU_Facility)(IN uchar8 ucHandsetId,
                                                  IN uint32 uiIEHdl);
												  
/*! \brief  This callback function is used to inform the FT application about the 
                   link being existing with the PT.  The DECT TK invokes this 
                   callback function when the FT Application invokes IFX_DECT_ESU_SendSetup
                   API and the dect toolkit find's out that there is already a link existing.
				   The FT application than can skip the call setup procedure.
	\param[in] uiPrivateData Reference to the private data handle of the
		FT application.	  
    \return IFX_SUCCESS / IFX_FAILURE 
    \note  Return value is ignored. No DECT Protocol message is sent out to PT.
*/ 
typedef	e_IFX_Return (*pfn_IFX_DECT_ESU_LinkExists)(IN uint32 uiPrivateData);


/*! \brief  Structure containing callbacks for all DECT STACK SS Messages received from stack.
     The FT application should register these callbacks to act appropriately.
	 These callbacks are called when none of the service type offered by toolkit like
	 CSU/SMSU/DPSU match.
*/
typedef struct {
	pfn_IFX_DECT_ESU_Setup      pfn_ESU_Setup;  /*!< callback being called when CC_SETUP message arrives from PT*/
	pfn_IFX_DECT_ESU_Alert      pfn_ESU_Alert;  /*!< callback being called when CC_ALERT message arrives from PT*/
    pfn_IFX_DECT_ESU_Connect    pfn_ESU_Connect;/*!< callback being called when  CC_CONNECT message arrives from PT*/
	pfn_IFX_DECT_ESU_CCInfo     pfn_ESU_CCInfo; /*!< callback being called when CC_INFO message arrives from PT*/
	pfn_IFX_DECT_ESU_IWUInfo    pfn_ESU_IWUInfo;/*!< callback being called when IWU_INFO message arrives from PT*/
    pfn_IFX_DECT_ESU_Facility   pfn_ESU_Facility;/*!< callback being called when FACILITY message arrives from PT*/
	pfn_IFX_DECT_ESU_Release    pfn_ESU_Release;/*!< callback being called when CC_RELEASE message arrives from PT*/
	pfn_IFX_DECT_ESU_LinkExists pfn_ESU_LinkExists;/*!< callback being called when link
	exists with the PT and call setup procedure can be skipped*/
    int32 uiReserved; /*!< Reserved for future use*/
}x_IFX_DECT_ESU_CallBks;

/*! \brief  This function is used to register callback functions with the ESU.
                   The registration of the ESU callback functions is optional.  Registration
                    is required only when the FT application needs to use the direct 
                    DECT stack protocol interface.  If required, the callback functions
                    need to be registered during initialization.
	\param[in] pxCCCallBks Structure containing the callback functions
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ESU_CallBksRegister(x_IFX_DECT_ESU_CallBks *pxCCCallBks);

/*! \brief  This function is used to send a CC_SETUP message to the PT.
                   This function shall be called by the FT application in order
                   to setup a call with the PT.  For e.g an incoming call request.
                   The FT application shall construct the Information Elements
                   (both mandatory and optional) to be passed along with the message.  
            \param[in] ucHandsetId Handset Identifier of the destination PT.
	\param[in] uiIEHdl Reference to  Information Element buffer
    \param[out] uiPrivateData  The private data handle of the
		FT application. The DECT TK maintains this handle and passes
                     it in all callback functions.
	                    
	\return IFX_SUCCESS or IFX_FAILURE
    \note Fixed Part Identity and Portable Identity IE's are added by the DECT TK itself.
	      FT application should not add these IE's.
*/
e_IFX_Return IFX_DECT_ESU_Setup(IN uchar8 ucHandsetId,
	                            IN uint32 uiIEHdl,
                                IN uint32 uiPrivateData);


/*! \brief  This function is used to send a CC_SETUP_ACK message to the PT.
                   This function shall be called by the FT application in order
                   to acknowledge a call setup request received from the PT.  
                   For e.g a CC_SETUP call request was received from the PT.
                   The FT application shall construct the Information Elements
                   (both mandatory and optional) to be passed along with the message.
	\param[in] ucHandsetId Handset Identifier of destination PT 
	\param[in] uiIEHdl Reference to  Information Element buffer
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ESU_SetupAck(IN uchar8 ucHandsetId,
                                   IN uint32 uiIEHdl);
	
/*! \brief  This function is used to send a CC_ALERT message to the PT.
                   This function shall be called by the FT application in order
                   to inform the PT that the called party has accepted the call 
                   and the PT should alert the user.  For e.g a 180 response was
                   received from a remote VoIP party.  The FT application shall 
                   construct the Information Elements (both mandatory and 
                   optional) to be passed along with the message.
	\param[in] ucHandsetId Handset Identifier of destination PT
	\param[in] uiIEHdl Reference to  Information Element buffer
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ESU_Alert(IN uchar8 ucHandsetId,
		                        IN uint32 uiIEHdl);

/*! \brief  This function is used to send a CC_CONNECT message to the PT.
                   This function shall be called by the FT application in order
                   to inform the PT that the called party has answered the call 
                   and the PT should alert the user.  For e.g a 200 response was
                   received from a remote VoIP party.  The FT application shall 
                   construct the Information Elements (both mandatory and 
                   optional) to be passed along with the message.
	\param[in] ucHandsetId Handset Identifier of destination PT
	\param[in] uiIEHdl Reference to  Information Element buffer
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ESU_Connect(IN uchar8 ucHandsetId,
		                          IN uint32 uiIEHdl);


/*! \brief  This function is used to send a CC_CONNECT_ACK message to the PT.
                   This function shall be called by the FT application in order
                   to acknowledge a call connect request received from the PT.  
                   For e.g a CC_CONNECT request was received from the PT.
                   The FT application shall construct the Information Elements
                   (both mandatory and optional) to be passed along with the message.
	\param[in] ucHandsetId Handset Identifier of destination PT
	\param[in] uiIEHdl Reference to  Information Element buffer
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ESU_ConnectAck(IN uchar8 ucHandsetId,
		                             IN uint32 uiIEHdl);

/*! \brief  This function is used to send a CC_INFO message to the PT.
                   This function shall be called by the FT application in order
                   to inform the PT about any events during a call.  For e.g.,
                   the remote user dialled digits.  The FT application shall 
                   construct the Information Elements (both mandatory and 
                   optional) to be passed along with the message.
	\param[in] ucHandsetId Handset Identifier of destination PT
	\param[in] uiIEHdl Reference to  Information Element buffer
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ESU_CCInfo(IN uchar8 ucHandsetId,
		                         IN uint32 uiIEHdl);

/*! \brief  This function is used to send a CC_CALL_PROC message to the PT.
                   This function shall be called by the FT application in order
                   to indicate the PT that the call setup request issued by the PT
                   is being processed at the FT.  For e.g a CC_SETUP call request 
                   for a VoIP call was received from the PT.  The FT application
                   is attempting to establish the call with the remote VoIP party.
                   The FT application shall construct the Information Elements
                   (both mandatory and optional) to be passed along with the message.
	\param[in] ucHandsetId Handset Identifier of destination PT
	\param[in] uiIEHdl Reference to  Information Element buffer
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ESU_Proceed(IN uchar8 ucHandsetId,
		                          IN uint32 uiIEHdl);


/*! \brief  This function is used to send a CC_RELEASE message to the PT.
                   This function shall be called by the FT application in order
                   to inform the PT about the termination of the call at the
                   remote end.  For e.g., the remote VoIP party sent a SIP BYE.
                   The FT application shall construct the Information 
                   Elements (both mandatory and optional) to be passed along 
                   with the message.
	\param[in] ucHandsetId Handset Identifier of destination PT
	\param[in] uiIEHdl Reference to  Information Element buffer
            \param[in] eReason Release Reason.
	\return IFX_SUCCESS or IFX_FAILURE
	\note Release Reason IE  is added by the DECT Toolkit and FT application should not
	      add this IE.
*/
e_IFX_Return IFX_DECT_ESU_Release(IN uchar8 ucHandsetId,
	                              IN uint32 uiIEHdl,
                                  IN e_IFX_DECT_RelType eReason);

/*! \brief  This function is used to send a IWU_INFO message to the PT.
                   This function shall be called by the FT application in order
                   to send an IWU_INFO to the PT.  
                   The FT application shall construct the Information 
                   Elements (both mandatory and optional) to be passed along 
                   with the message.
	\param[in] ucHandsetId Handset Identifier of destination PT
	\param[in] uiIEHdl Reference to  Information Element buffer
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ESU_IWUInfo(IN uchar8 ucHandsetId,
		                          IN uint32 uiIEHdl);
 
/*! \brief  This function is used to send a FACILITY message to the PT.
                   This function shall be called by the FT application in order
                   to send a message to the PT when there is no link established
                   with the PT or to send a message over an aleady established link.
                   The FT application shall construct the Information 
                   Elements (both mandatory and optional) to be passed along 
                   with the message.
	\param[in] ucHandsetId Handset Identifier of destination PT
	\param[in] uiIEHdl Reference to  Information Element buffer
	\return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_ESU_Facility(IN uchar8 ucHandsetId,
		                           IN uint32 uiIEHdl);

/* @} */
#endif /* __IFX_DECT_ESU_H__*/
							 

