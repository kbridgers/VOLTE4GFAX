/**************************************************************************
**   FILE NAME     : IFX_DECT_SUOTA.h
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 26-07-2010
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT SUOTA Call
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software is granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/

/*! \file IFX_DECT_SUOTA.h
    \brief This file contains the Software Upgrade Over The Air (SUOTA)  procedures.
                DPSU contains procedures for providing a framework to plug-in a variety 
                of IP protocols to provide DECT packet radio service. 
*/

#ifndef __IFX_DECT_SUOTA_H__
#define __IFX_DECT_SUOTA_H__

/** \ingroup DECT_TOOLKIT_MODULES
    \defgroup SUOTA_MODULE Software Upgrade Over The Air Unit
    \brief The SUOTA unit group contains the functions needed for SUOTA feature of CAT iq 3.0. 
*/
/*@{*/
/*@}*/

/** \ingroup DECT_TOOLKIT_API
    \defgroup SUOTA_API Software Upgrade Over The Air Unit
    \brief This group contains the SUOTA Unit (SUOTA) functions 
            of the DECT Toolkit.  It provides a set of procedures:\n
     1> Exchanging version information and \n
     2> Receiving download URL information from management server\n
    */
/* @{ */

/*! \def IFX_DECT_SUOTA_MAX_URL_LEN
    \brief Macro that specifies the maximum length of Management server URL.
 */
#define IFX_DECT_SUOTA_MAX_URL_LEN 250 /*!< Maximum length of Management server URL*/

/*! \def IFX_DECTAPP_MAX_MGMT_URL_LENGTH
    \brief Macro that specifies the maximum length of each URL received from management server.
 */
#define  IFX_DECTAPP_MAX_MGMT_URL_LENGTH 250 /*!< Maximum length of URL received from management server*/

/*! \enum e_IFX_DECT_SUOTA_Reason
    \brief Enum containing the failure reasons for SUOTA.
*/
typedef enum{
  IFX_DECT_SUOTA_SUCCESS = 0x00, /*!< Success of SUOTA */
  IFX_DECT_SUOTA_DWLD_FAILED = 0x01,/*!< Download of file with indicated file number failed */
  IFX_DECT_SUOTA_APPL_FAILED = 0x02,/*!< Application of file with indicated fileNumber failed */
  IFX_DECT_SUOTA_NEW_DELAYMIN_REQ = 0x03,/*!< Unable to download in time - New DelayMinutes requested */  
}e_IFX_DECT_SUOTA_Reason;

/*! \enum e_IFX_DECT_SUOTA_UserInteraction
    \brief Enum containing the user interactions for SUOTA.
*/
typedef enum{
  IFX_DECT_SUOTA_USERINT_NOT_REQ = 0x00,/*!< No User Interaction Required*/
  IFX_DECT_SUOTA_USERINT_REQ = 0x01,/*!< User Interaction Required */
  IFX_DECT_SUOTA_USERINT_UNDEFINED = 0x02,/*!< User interaction undefined */  
}e_IFX_DECT_SUOTA_UserInteraction;

/*! \enum e_IFX_DECT_SUOTA_NACKReason
    \brief Enum containing the negative acknowledgement reasons for SUOTA.
*/

typedef enum{
  IFX_DECT_SUOTA_NACK_RETRY_CONN_REFUSED = 0x01,/*!< Retry Later - Connection Refused*/
  IFX_DECT_SUOTA_NACK_FP_RESOURCE_OVERFLOW= 0x02,/*!< Retry Later - FP Resources Overflow */
  IFX_DECT_SUOTA_NACK_FILE_NOT_EXIST = 0x03,/*!< File does not exist */
  IFX_DECT_SUOTA_NACK_INVALID_URL1 = 0x04,/*!< Invalid URL1 format */
  IFX_DECT_SUOTA_NACK_UNREACH_URL1 = 0x05,/*!< Unreachable URL1 */
  IFX_DECT_SUOTA_NACK_COM_FORMAT_ERR = 0x06,/*!< Command Format Error */ 
}e_IFX_DECT_SUOTA_NACKReason;

/*! 
    \brief Structure containing the Software Version information that are passed to 
      the SUOTA application. The individual SUOTA functions specify the mandatory fields.
*/
typedef struct {
  uint16 unEMC;  /*!< EMC*/                                   
  char8 acHwVerIden[20];/*!< Hardware Version ID*/  
  char8 acSwIdentifier[20];  /*!< Software Version Id*/
  char8 acSendUrl[IFX_DECT_SUOTA_MAX_URL_LEN];  /*!< URL1 */
  uchar8 ucFileNum; /*!< File Number*/
  char8 user_interaction;
  e_IFX_DECT_SUOTA_Reason eReason;  /*!< Reason*/
}x_IFX_DECT_SUOTA_VersionIndicationInfo;

/*! 
    \brief Structure containing the Software Version Available information that are  
      given to the stack by the SUOTA application. The individual SUOTA functions specify the 
      mandatory fields.
*/
typedef struct {   
  char8 acNewSwIdentifier[20+1];    /*!< Latest Sw Version Id*/
  char8 acUrl[IFX_DECTAPP_MAX_MGMT_URL_LENGTH+1];   /*!< FP_URL2*/
  char8 user_interaction;
  uint16 unDelayMin; /*!< Delay Minutes*/
  uint32 uiSwTotalSize;/*!< Software Total Size */
}x_IFX_DECT_SUOTA_VersionAvailableInfo;

/* ****************************************************************************
 * Callback Functions
 * ****************************************************************************/

/*! \brief This callback function is used to inform the FT application of a 
                  version indication request from the PT.  This callback function is 
                  invoked by the DECT TK when it receives a FACILITY message
                  from the DECT Protocol Stack indicating an SUOTA command
                  request from the PT.
                  The DECT TK decodes the message and send the version indication
                  info to the FT application.
           \param[in] ucHandsetId Handset Identifier of call initiating PT                 
	\param[in] pxVerInfo Pointer to the Version Indication Info object

    \return IFX_SUCCESS or IFX_FAILURE
 */

typedef e_IFX_Return (*pfn_IFX_DECT_SUOTA_VersionIndication)(IN uchar8 ucHandsetId,                                               
											IN x_IFX_DECT_SUOTA_VersionIndicationInfo *pxVerInfo);                                       
                                 
/*! \brief This callback function is used to inform the FT application of a 
                  negative acknowledgement from the PT.  This callback function is 
                  invoked by the DECT TK when it receives a FACILITY message
                  from the DECT Protocol Stack indicating a negative acknowledgement
                  from the PT.
                  The DECT TK decodes the message and sends the NACK
                  to the FT application.
           \param[in] ucHandsetId Handset Identifier of call initiating PT
	\param[in] eNack NACK reason

    \return IFX_SUCCESS or IFX_FAILURE
 */
 
typedef e_IFX_Return (*pfn_IFX_DECT_SUOTA_NACK)(IN uchar8 ucHandsetId,
                                              IN e_IFX_DECT_SUOTA_NACKReason eNack);


/*! \brief Structure containing pointers to the various callback functions to the FT application. 
                The callback functions listed in the structure need to be implemented within 
                the FT application and registered with the DECT TK.
*/
typedef struct
{
    pfn_IFX_DECT_SUOTA_VersionIndication    pfnVerIndication; /*!< Callback for notifying a Handset version Indication from the PT */
    pfn_IFX_DECT_SUOTA_NACK                 pfnNack;  /*!< Callback for notifying the negative acknowledgement from the PT */                                            
}x_IFX_DECT_SUOTA_CallBks;



/*! \brief The FT application responds to the Version Indication message issued
           by the PT by invoking this function.  This function helps to send 
           the (new) available version information to the PT.
    \param[in] ucHandsetId Handset Identifier of call initiating PT
	\param[in] pxVerAvailInfo Pointer to the Version Available object
    \return IFX_SUCCESS or IFX_FAILURE
*/    

e_IFX_Return IFX_DECT_SUOTA_VersionAvailable(IN uchar8 ucHandsetId,                                      
									  IN x_IFX_DECT_SUOTA_VersionAvailableInfo *pxVerAvailInfo);
									  
                                                
/*! \brief The FT application sends NACK using the FACILITY message
           to the PT by invoking this function.  This function helps to send 
           Negative Acknowledgement information to the PT.
    \param[in] ucHandsetId Handset Identifier of call initiating PT
	\param[in] eNack  NACK reason
    \return IFX_SUCCESS or IFX_FAILURE
		
*/ 
e_IFX_Return IFX_DECT_SUOTA_SendNACK(IN uchar8 ucHandsetId, 
                               IN e_IFX_DECT_SUOTA_NACKReason eNack);
                                             
                                           

                                                  
/*! \brief This function is used to register callback functions with the SUOTA for
             notifying SUOTA related events/messages to the FT application.\n
			The FT application shall call this function during initialization.
    \param[in] pxCallBks Call back function pointers
	\return IFX_SUCCESS or IFX_FAILURE
    \note Mandatory callback functions viz., pfn_IFX_DECT_SUOTA_VersionIndication, pfn_IFX_DECT_SUOTA_NACK, have to be registered.
*/

e_IFX_Return IFX_DECT_SUOTA_RegisterCallBks(IN x_IFX_DECT_SUOTA_CallBks *pxCallBks);
/* @} */
#endif /*__IFX_DECT_SUOTA_H__*/


