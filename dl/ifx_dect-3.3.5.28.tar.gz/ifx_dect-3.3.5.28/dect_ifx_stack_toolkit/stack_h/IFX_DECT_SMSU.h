/**************************************************************************
**   FILE NAME     : IFX_DECT_SMSU.h
**   PROJECT       : DECT TOOLKIT
**   MODULES       : Transaction User
**   SRC VERSION   : 
**   DATE          : 
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for the SMS module of the DECT Tkt
**   COMPILER      : 
**   REFERENCE     : Coding guide lines,IFX_SP_TUDIS.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_DECT_SMSU.h
    \brief This file contains the Short Message Service Unit (SMSU) procedures.
                The SMSU is the implementation of SMS Application.The SMSU provides a 
                set of procedures that support messaging between DECT and 
                VoIP network.
*/

/** \ingroup DECT_TOOLKIT_MODULES
	\defgroup SMSU_MODULE Short Message Service Unit
           \brief The Short Message Service Unit manages all the 
           messaging needs of the FP.  The SMSU implements the 
           logic to exchange messages over the Cs link.  The SMSU 
           implementation is Lantiq proprietary. The interface provided 
           by the SMSU is listed in the chapter on Toolkit API.  
           The examples chapter provides source code examples 
           illustrating the usage of the SMSU interfaces.
*/
/* @{ */
/* @} */
#ifdef MESSAGE_SUPPORT
#ifndef __IFX_DECT_SMSU_H__
#define __IFX_DECT_SMSU_H__
  
/** \ingroup DECT_TOOLKIT_API
	\defgroup SMSU_API Short Message Service Unit
           \brief This group contains the Short Message Service Unit functions
           of the DECT Toolkit.  It provides a set of procedures that allow\n
           1> The establishment and tear down of links for SMS exchange \n
           2> Query of Inbox and Sent items for headers and messages \n
           3> Proprietary protocol flow for SMS \n
           This section lists the function prototypes, callback function declarations,
	       enumerations, structures and macro definitions for the SMSU.   
*/
/* @{ */



/*! \def  IFX_DECT_SMSU_MAX_MESG_DATALEN
   \brief Macro that specifies maximum length of a SMS message.
*/
#define IFX_DECT_SMSU_MAX_MESG_DATALEN 160

/*! \def IFX_DECT_SMSU_MAX_MESG
   \brief Macro that specifies maximum number of messages that can be stored at a time in Inbox/Outbox
*/
#define IFX_DECT_SMSU_MAX_MESG 20

/*! \enum e_IFX_DECT_SMSU_MesgBox
   \brief Enum describing the SMS message box type
*/
typedef enum
{
    IFX_DECT_SMSU_INBOX = 1, /*!< Message Box is INBOX.*/
    IFX_DECT_SMSU_OUTBOX = 2 /*!< Message Box is OUTBOX.*/
}e_IFX_DECT_SMSU_MesgBox;

/*! \enum e_IFX_DECT_SMSU_DataType
   \brief Enum describing the SMS content data type
*/
typedef enum
{
    IFX_DECT_SMSU_HEADERS = 1,/*!< Data Type is Message Headers*/
    IFX_DECT_SMSU_MESG = 2    /*!< Data Type is Message Content*/
}e_IFX_DECT_SMSU_DataType;

/*! \enum e_IFX_DECT_SMSU_ReasonCode
   \brief Enum describing the reason code for failure of deletion or sending
*/
typedef enum
{
    IFX_DECT_SMSU_IO_ERROR = 0,      /*!< Error reading/writing to file that stores SMS*/
    IFX_DECT_SMSU_NETWORK_ERROR = 1, /*!< Network error*/
    IFX_DECT_SMSU_HOST_NOT_FOUND = 2,/*!< Wrong destination number*/
    IFX_DECT_PENDING = 3             /*!< In case the application takes long time to reply, ASYNC mode.*/
}e_IFX_DECT_SMSU_ReasonCode;

/*! \enum e_IFX_DECT_SMSU_MesgStatus
    \brief Enum describing the message status, whether it is READ or UNREAD.
*/
typedef enum
{
    IFX_DECT_SMSU_READ = 0,    /*!< SMS message is read.*/
    IFX_DECT_SMSU_UNREAD = 1   /*!< SMS message is not read.*/
}e_IFX_DECT_SMSU_MesgStatus;


/*!
    \brief Structure defining the SMS Message Header Block.
*/
typedef struct
{
    uchar8 ucMesgIndex;        /*!< Message Index.  It uniquely identifies a message.*/
    uchar8 ucToFromNumberSize; /*!< Size of destination/origination number.*/
    uchar8 aucToFromNumber[2]; /*!< Destination/Origination number.*/
    uchar8 ucMesgStatus;       /*!< Message Status:read or unread*/
    uchar8 aucMesgPreamble[16];/*!< Message Preamble.First 16 char of message.*/
    uchar8 aucExtnNumber[2];   /*!< Handset Internal Number.*/
}x_IFX_DECT_SMSU_HeaderBlock;

/*!
    \brief Structure defining the timestamp for the SMS message.
 */
typedef struct
{
    uchar8 ucYear;      /*!< Year.*/
    uchar8 ucMonth;     /*!< Month.*/
    uchar8 ucDay;       /*!< Day.*/
    uchar8 ucHour;      /*!< Hour(s).*/ 
    uchar8 ucMinute;    /*!< Minute(s).*/
    uchar8 ucSecond;    /*!< Second(s).*/
    uchar8 ucTimeZone;  /*!< Time Zone difference in quarters of an hour from GMT.*/
}x_IFX_DECT_SMSU_TimeStamp;

/*! 
    \brief Structure defining the format of a SMS message.
 */
typedef struct
{
    uchar8 ucToFromNumberSize;   /*!< Size of Destinastion/Origination number.*/
    uchar8 aucToFromNumber[2];   /*!< Destination/Origination number. */
    uchar8 ucMesgSize;           /*!< Message size.*/
    uchar8 aucMesgContents[160]; /*!< Contents of the message.*/
    x_IFX_DECT_SMSU_TimeStamp xMesgTimeStamp;/*!< Time Stamp for the message.*/
    uchar8 ucExtnNumber;         /*!< Handset Internal Number.*/
    uchar8 ucChecksum;           /*!< Checksum.*/
}x_IFX_DECT_SMSU_Mesg;

/* ****************************************************************************
 * Callback Functions
 * ****************************************************************************/

/*! \brief This callback function is used to inform the FT application that the
                  PT is ready to send an outgoing message.  The DECT TK invokes this 
                  callback function on the FT application when it receives the SMS
                  proprietary message from the DECT Protocol Stack.  The FT application
                  shall store the message in the outbox and return the message index to
                  the PT.  The FT application shall then initiate the SIP MESSAGE
                  method to send the method on the VoIP network.  The status of 
                  delivery of the SMS will be communicated separately through the
                  IFX_DECT_SMSU_MesgRspSend function.
	\param[in] ucHandSet Handset Number.
	\param[in] xMesg Message from PT.
	\param[out] pucMesgIndex Message Index of the message in Outbox.
	\param[out] peFailReason reason for send message failure.
	\return IFX_SUCCESS or IFX_FAILURE or IFX_PENDING.
           \note
           IFX_PENDING This indicates a delayed response from FT Application is
		               expected.Here notification is done through a separate API.
           IFX_FAILURE This implies failure of sending the message out to VoIP Network.
           IFX_SUCCESS Since sending message out to VoIP network is time consuming,
		               here also the response may be delayed.Hence send
					   notification is through a separate API.
*/
typedef e_IFX_Return (*pfn_IFX_DECT_SMSU_MesgSend)(IN uchar8 ucHandSet,
                                                   IN x_IFX_DECT_SMSU_Mesg xMesg,
                                                   OUT uchar8 *pucMesgIndex,
												   OUT e_IFX_DECT_SMSU_ReasonCode *peFailReason);
									

/*! \brief This callback function is used to inform the FT application that the PT
                   wants to read the contents of a particular message (from Inbox 
                   or Outbox).   The DECT TK invokes this callback function on the
                   FT application when it receives the SMS proprietary message 
                   from the DECT Protocol Stack.  The FT application shall retrieve
                   the message from the storage and return the message.  If the retrieval 
                   from the storage will take time, the FT application may 
                   return this function and send the message through the 
                   IFX_DECT_SMSU_MesgRspGet function.
	\param[in] ucHandSet Handset Number.
	\param[in] eMesgBox Type of message box:Inbox or Outbox.
	\param[in] ucMesgIndex Message Index.
	\param[out] pxMesg pointer to the requested message.
    \return IFX_SUCCESS or IFX_FAILURE or IFX_PENDING.
    \note
           IFX_PENDING This indicates a delayed response from FT Application is
		               expected.The retrieved message is sent later through a
					   separate API invocation by FT Application.
           IFX_FAILURE This indicates failure to retrieve SMS message.
           IFX_SUCCESS This implies the callback was successful and the retrieved
		               message is returned in pxMesg.
*/
typedef e_IFX_Return (*pfn_IFX_DECT_SMSU_MesgGet)(IN uchar8 ucHandSet,
                                                  IN e_IFX_DECT_SMSU_MesgBox eMesgBox,
                                                  IN uchar8 ucMesgIndex,
                                                  OUT x_IFX_DECT_SMSU_Mesg *pxMesg); 
                                        


/*! \brief This callback function is used to inform the FT application that the PT
                   wants to read the header list of a particular message box( Inbox 
                   or Outbox).   The DECT TK invokes this callback function on the
                   FT application when it receives the SMS proprietary message 
                   from the DECT Protocol Stack.  The FT application shall retrieve
                   the header list from the storage and return the list.  If the retrieval 
                   from the storage will take time, the FT application may 
                   return this function and send the list through the 
                   IFX_DECT_SMSU_HdrsRspGet function.
    \param[in] ucHandSet Handset Number.
	\param[in] eMesgBox Type of message box:Inbox or Outbox.
	\param[out] pxHeaders Pointer to the block of headers.
	\param[out] pucNoHeaders Number of headers in the block.
	\return IFX_SUCCESS or IFX_FAILURE or IFX_PENDING.
    \note
           IFX_PENDING This indicates a delayed response from FT Application is
		               expected.The retrieved header list is sent later through a
					   separate API invocation by FT Application.						  
           IFX_FAILURE This indicates failure to retrieve header list.
           IFX_SUCCESS This implies the callback was successful and the
		               header list is returned in pxHeaders and header count in
					   pucNoHeaders.
*/

typedef e_IFX_Return (*pfn_IFX_DECT_SMSU_HdrsGet)(IN uchar8 ucHandSet,
                                                  IN e_IFX_DECT_SMSU_MesgBox eMesgBox,
                                                  OUT x_IFX_DECT_SMSU_HeaderBlock *pxHeaders,
                                                  OUT uchar8 *pucNoHeaders); 



/*! \brief This callback function is used to inform the FT application that the PT
                   wants to delete a particular message (from Inbox or Outbox).   
                   The DECT TK invokes this callback function on the
                   FT application when it receives the SMS proprietary message 
                   from the DECT Protocol Stack.  The FT application shall delete
                   the message in the storage and return the status.  If the deletion 
                   from the storage will take time, the FT application may 
                   return this function and send the status through the 
                   IFX_DECT_SMSU_MesgRspDelete function.
           \param[in] ucHandSet Handset Number.
	\param[in] eMesgBox Type of message box:Inbox or Outbox.
	\param[out] peFailReason reason for delete failure.
	\return IFX_SUCCESS or IFX_FAILURE or IFX_PENDING.
    \note
           IFX_PENDING This indicates a delayed response from FT Application is
		               expected.The delete notification is sent later through a
					   separate API invocation by FT Application when message is
					   deleted. 
           IFX_FAILURE This indicates failure to delete message.
           IFX_SUCCESS This implies the callback was successful and the
		               requested message (or all messages) is deleted and peFailReason
					   is returned to indicate any failure reason.
*/
typedef e_IFX_Return (*pfn_IFX_DECT_SMSU_MesgDelete)(IN uchar8 ucHandSet,
                                                     IN e_IFX_DECT_SMSU_MesgBox eMesgBox,
                                                     IN uchar8 ucMesgIndex,
                                                     OUT e_IFX_DECT_SMSU_ReasonCode *peFailReason); 

/*! 
    \brief Structure containing callback functions for SMSU related procedures.
    This callback function functions listed in the structure need to be implemented within 
    the FT application and registered with the DECT TK.
 */
typedef struct
{
    pfn_IFX_DECT_SMSU_MesgSend    pfnMesgSend;    /*!< Callback for notifying an outgoing SMS from PT.*/
    pfn_IFX_DECT_SMSU_MesgGet     pfnMesgGet;     /*!< Callback for notifying a Get Message request from PT.*/
    pfn_IFX_DECT_SMSU_HdrsGet     pfnHdrsGet;     /*!< Callback for notifying a Get Header request from PT.*/
    pfn_IFX_DECT_SMSU_MesgDelete  pfnMesgDelete;  /*!< Callback for notifying a Delete Message request from PT.*/
}x_IFX_DECT_SMSU_AppCallBks;

/* ****************************************************************************
 * Functions
 * ****************************************************************************/
/*! \brief This function initializes the SMSU sub-module of the DECT TK. It initializes 
          the structures for Message and Header blocks thus preparing this module
		  for messaging operations between the PT and FT.
   \return  IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_SMSU_Init();


/*! \brief This function is used to inform the PT about the status of 
                   an outgoing message.  The PT would have requested the FT 
                   application to send an outgoing message (OGM) by
                   invoking the pfn_IFX_DECT_SMSU_MesgSend callback function.
                   Since the sending of a message and confirmation that it reached the 
                   destination properly takes time, the FT application returns the callback
                   and communicates the status later using this function.  The status
                   is sent when the FT application receives a 200 (or an equivalent)
                   response to a SIP MESSAGE request sent earlier. This is an 
                   ASYNC mode function.
    \param[in] ucHandSet HandSet Number
    \param[in] ucMesgIndex Message Index in the Outbox
    \param[in] eSendStatus Status of sending: Success or Failure
    \param[in] eReason Reason for failure
    \return  IFX_SUCCESS or IFX_FAILURE.
*/
e_IFX_Return IFX_DECT_SMSU_MesgRspSend(IN uchar8 ucHandSet,
                                       IN uchar8 ucMesgIndex,
									   IN e_IFX_Return eSendStatus,
									   IN e_IFX_DECT_SMSU_ReasonCode eReason);

/*! \brief This function is used to inform the PT about the status of 
                   a pending delete request.  The PT would have requested the FT 
                   application to delete a message by invoking the 
                   pfn_IFX_DECT_SMSU_MesgDelete callback function.
                   Since the delete operation could take time, the FT application 
                   may return the callback and communicate the status later 
                   using this function.  This is an ASYNC mode function.
    \param[in] ucHandSet HandSet Number.
    \param[in] eMesgBox Message box type:Inbox or Outbox.
    \param[in] ucMesgIndex Message index.
    \param[in] eDeleteStatus Status of deletion:Success or Failure.
    \param[in] eReason Reason for failure.
    \return  IFX_SUCCESS or IFX_FAILURE.
*/
e_IFX_Return IFX_DECT_SMSU_MesgRspDelete(IN uchar8 ucHandSet,
                                         IN e_IFX_DECT_SMSU_MesgBox eMesgBox,
										 IN uchar8 ucMesgIndex,
										 IN e_IFX_Return eDeleteStatus,
										 IN e_IFX_DECT_SMSU_ReasonCode eReason);



/*! \brief This function is used to inform the PT about the status of a pending 
                  get headers request.  The PT would have requested the FT application
                  to send the message headers (of Inbox / Outbox) by invoking the
                  pfn_IFX_DECT_SMSU_HdrsGet callback function.  If the response 
                  could be delayed, the FT application returns the callback and sends
                  the response using this function.
    \param[in] ucHandSet HandSet Number.  
    \param[in] eMesgBox Message Box:Inbox or Outbox.
    \param[in] pxHeaders Pointer to an array of Headers.
    \param[in] ucHeaderCount Number of headers.
    \return  IFX_SUCCESS or IFX_FAILURE.
*/
e_IFX_Return IFX_DECT_SMSU_HdrsRspGet(IN uchar8 ucHandSet,
                                      IN e_IFX_DECT_SMSU_MesgBox eMesgBox,
									  IN x_IFX_DECT_SMSU_HeaderBlock *pxHeaders,
                                      IN uchar8 ucHeaderCount);

/*! \brief This function is used to inform the PT about the status of a pending 
                  get message request.  The PT would have requested the FT application
                  to send a message (from Inbox / Outbox) by invoking the
                  pfn_IFX_DECT_SMSU_MesgGet callback function.  If the response 
                  could be delayed, the FT application returns the callback and sends
                  the response using this function.
    \param[in] ucHandSet HandSet Number.
    \param[in] eMesgBox Message box type:Inbox or Outbox.
    \param[in] ucMesgIndex Message Index.
    \param[in] pxMesg Pointer to the Message block.
    \return  IFX_SUCCESS or IFX_FAILURE.
*/
e_IFX_Return IFX_DECT_SMSU_MesgRspGet(IN uchar8 ucHandSet,
                                      IN e_IFX_DECT_SMSU_MesgBox eMesgBox,
								      IN uchar8 ucMesgIndex,
									  IN x_IFX_DECT_SMSU_Mesg * pxMesg);



/*! \brief This function is used to register callback functions with the SMSU for
            the SMS operations. The FT application shall call this function during initialization.
	 \param[in] pxCallBks Pointer to structure containing the callback functions.
	 \return IFX_SUCCESS or IFX_FAILURE.
*/
e_IFX_Return IFX_DECT_SMSU_CallBksRegister(x_IFX_DECT_SMSU_AppCallBks *pxCallBks);


/*! \brief This function is used to inform the PT about the Unread messages in 
                  the Inbox at the FT.   The FT application shall invoke this function when
                  a new messages arrives from the VoIP network or when a handset
                  attaches.  If a link is already established with the PT, the 
                  DECT TK uses this link to send the alert.  Ifno link exists, a new
                  link shall be created.
	\param[in] ucHandSet Handset Number.
    \param[in] ucUnread Number of unread messages. 
    \return IFX_SUCCESS or IFX_FAILURE.
*/
e_IFX_Return IFX_DECT_SMSU_AlertSend(IN uchar8 ucHandSet,IN uchar8 ucUnread);

/* @} */
#endif /*__IFX_DECT_SMSU_H__*/
#endif
