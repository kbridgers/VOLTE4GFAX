/**************************************************************************
**   FILE NAME     : IFX_DECT_MU_Fsm.h
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 26-09-2008
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Call Control
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_DECT_MU_FSM__
#define __IFX_DECT_MU_FSM__

#define IFX_DECT_MU_NEMO_IDLE_TIME 60000 /* in ms */
#define IFX_DECT_MU_RINGPAUSE_ON_DURATION		5000  /* in ms*/
#define IFX_DECT_MU_RINGPAUSE_OFF_DURATION		3000  /* in ms*/

#define  MAC_NOEMOM_IDLE                     0x00
#define  MAC_NOEMOM_STOP                     0x01
#define  MAC_NOEMOM_START                    0x02
#define  MAC_NOEMOM_PEND                     0x03
#define  MAC_NOEMOM_ACTIVE                   0x04
#define  MAC_NOEMOM_WAKEUP                   0x05
#define  MAC_NOEMOM_TBC_ACTIVE               0x06

/*! \brief This enum define DECT NEMO States */
typedef enum {
  IFX_DECT_MU_NONEMO, /*!< NO NEMO MODE*/
  IFX_DECT_MU_NEMO_IDLE,/*!< NEMO IDEL MODE*/
  IFX_DECT_MU_NEMO_PENDING,/*!< NEMO PENDING */
  IFX_DECT_MU_NEMO_ACTIVE,/*!< NEMO IN ACTIVE State*/
	IFX_DECT_MU_NEMO_OFF,/*!< NEMO OFF*/
}e_IFX_DECT_MU_NemoState;  
  
/*! \brief This enum defines DECT Endpoint FSM states */
typedef enum {
  IFX_DECT_MU_HS_IDLE,/*!< Idle*/
  IFX_DECT_MU_HS_REGISTERD,/*!< Registered */
  IFX_DECT_MU_HS_ATTACHED,/*!< Location update recived */
  IFX_DECT_MU_HS_IN_CALL,/*!< Incall but can recive one more call */
  IFX_DECT_MU_HS_BUSY,     /*!< Handset is busy and cannot recv any call */
}e_IFX_DECT_MU_States;

#define IFX_DECT_MU_IsCallWaitingTone(handset)\
((vxGlobalInfo.xMU.vxMUInfo[handset-1].uiTermCap&IFX_DECT_MU_HS_CALLWAITTONE) ? 1:0)

#define IFX_DECT_MU_IsFullSlot(handset)\
((vxGlobalInfo.xMU.vxMUInfo[handset-1].uiTermCap&IFX_DECT_MU_HS_FULLSLOT) ? 1:0)

#define IFX_DECT_MU_IsGap(handset)\
((vxGlobalInfo.xMU.vxMUInfo[handset-1].uiTermCap&IFX_DECT_MU_HS_GAP) ? 1:0)

#define IFX_DECT_MU_IsDPRS(handset)\
((vxGlobalInfo.xMU.vxMUInfo[handset-1].uiTermCap&IFX_DECT_MU_HS_DPRS) ? 1:0)

#define IFX_DECT_MU_IsNemo(handset)\
((vxGlobalInfo.xMU.vxMUInfo[handset-1].uiTermCap&IFX_DECT_MU_HS_NEMO) ? 1:0)

#define IFX_DECT_MU_IsWb(handset)\
((vxGlobalInfo.xMU.vxMUInfo[handset-1].uiTermCap&IFX_DECT_MU_HS_WB) ? 1:0)

#define IFX_DECT_MU_IsCAT2(handset)\
((vxGlobalInfo.xMU.vxMUInfo[handset-1].uiTermCap&IFX_DECT_MU_HS_CAT2) ? 1:0)

#define IFX_DECT_MU_IsHPP(handset)\
((vxGlobalInfo.xMU.vxMUInfo[handset-1].uiTermCap&IFX_DECT_MU_HS_HPP) ? 1:0)

#define IFX_DECT_MU_IsEchoSuppressCapable(handset)\
((vxGlobalInfo.xMU.vxMUInfo[handset-1].uiTermCap&IFX_DECT_MU_HS_ECHO_TCL_55) ? 1:0)

#define IFX_DECT_MU_IsCID(handset)\
((vxGlobalInfo.xMU.vxMUInfo[handset-1].uiTermCap&IFX_DECT_MU_HS_CID) ? 1:0)

#define IFX_DECT_MU_IsPCALL(handset)\
((vxGlobalInfo.xMU.vxMUInfo[handset-1].uiTermCap&IFX_DECT_MU_HS_PCALL) ? 1:0)

#define IFX_DECT_MU_IsMLINE(handset)\
((vxGlobalInfo.xMU.vxMUInfo[handset-1].uiTermCap&IFX_DECT_MU_HS_MLINE) ? 1:0)

#define IFX_DECT_MU_GetCipherStatus(handset)\
(vxGlobalInfo.xMU.vxMUInfo[handset-1].ucCipherStatus)

#define IFX_DECT_MU_SetCipherStatus(handset,status)\
(vxGlobalInfo.xMU.vxMUInfo[handset-1].ucCipherStatus=status)

#define IFX_DECT_MU_SetBasicService(handset,ucBasicServ)\
(vxGlobalInfo.xMU.vxMUInfo[handset-1].ucBasicService=ucBasicServ)


#define IFX_DECT_MU_GetBasicService(handset)\
(vxGlobalInfo.xMU.vxMUInfo[handset-1].ucBasicService)

#define IFX_DECT_MU_SetCodec(handset,Codec1)\
vxGlobalInfo.xMU.vxMUInfo[handset-1].aunCodec=Codec1

#define IFX_DECT_MU_GetCodec(handset)\
vxGlobalInfo.xMU.vxMUInfo[handset-1].aunCodec

#define IFX_DECT_MU_SetRunCodec(handset,Codec1)\
vxGlobalInfo.xMU.vxMUInfo[handset-1].aunRunCodec=Codec1


#define IFX_DECT_MU_GetRunCodec(handset)\
vxGlobalInfo.xMU.vxMUInfo[handset-1].aunRunCodec

/*! \def IFX_DECT_ENCRYPTION_MODE
    \brief Macro used to specify the DECT Encrytion configuration sent by the Agent in Init or configure APIs
 */
#define IFX_DECT_ENCRYPTION_MODE vxGlobalInfo.xStackCfg.bEncryption


typedef struct{
  x_IFX_DECT_SubscInfo xSubscInfo;/*!< Subscription Info*/
  uint32 uiTermCap; /*!< Terminal capability*/
  uchar8 ucDspLines;/*!< Number of Display Lines*/
  uchar8 ucCharPerLine; /*!< Number of Character per Line*/
  uint8 ucInstance; /*!< DECT Instance number 0~5*/
  uint8 bPPAttached; /*!< DECT Handset Attached or not 0/1*/
  e_IFX_DECT_MU_States eState; /*!< Current state of the endpoint */
  uchar8  bWidebandEnabled;/*!< Is wideband supported at the handset*/
/*! \brief CSU Module OWNER ID */
#define IFX_DECT_CSU_ID 0x1
  uchar8 ucCSURefCount;/* For 1st Call it shall be zero and for the 2nd call it shall be
  1 and so on*/
/*! \brief SMSU Module Owner ID */
#define IFX_DECT_SMSU_ID 0x2
/*! \brief  DPSU Module Owner ID */
#define IFX_DECT_DPSU_ID 0x4
/*! \brief  ESU Module Owner ID */
#define IFX_DECT_ESU_ID 0x8
/*! \brief MU Module OWNER ID */
#define IFX_DECT_MU_ID 0x10
#ifdef CAT_IQ2_0
/*! \brief LAU Module OWNER ID */
#define IFX_DECT_LAU_ID 0x20
#endif
#ifdef HCU
  /*! \brief HCU Module OWNER ID */
#define IFX_DECT_HCU_ID 0x40
#endif
  uint32 uiModuleOwner;/*!< Module Owner*/
  uchar8 ucCipherStatus;/*!< Cipher Status */
  uint16  aunCodec; /* codecs used during link setup*/
  uint16  aunRunCodec; /* codecs used during link setup*/
  uchar8  ucBasicService; /* Basic service set during link setup*/

}x_IFX_DECT_MUInfo;
 

/*! \brief Maximum calls supported at FT */
#define IFX_DECT_MAX_FT_CALLS 12

/*! \brief Maximum calls supported per handset */
#define IFX_DECT_MAX_CALLS_PER_HS 2

#define	IFX_DECT_STOP_REGISTRATION() { \
		if( vuiRegistrationTimerId )	{ \
			IFX_DECT_StopTimer(vuiRegistrationTimerId); \
		} \
	} 
#define IFX_DECT_MULTIPLE_BIT_SET(x) x>0?(x&(x-1)):0

#define IFX_DECT_ConstructProprietaryMsg(pData) \
{ \
	DATA_FRAME* pxDataFr = (DATA_FRAME*)(pData); \
	pxDataFr->dat[0] = 0x81;  /* EMC-Type */ \
	/* EMC-Code */ \
	pxDataFr->dat[1] = HIBYTE(First_EMC_Code);\
	pxDataFr->dat[2] = LOBYTE(First_EMC_Code);\
	pxDataFr->length = 3;\
}

/*! \brief Invlid DECT PP instance number */
#define IFX_DECT_INVALID_INSTANCE	  0xFF
struct Prop_Element
{
   uchar8   length;
   uchar8   data[ 100 ];
} Prop_Element ;

 /*! \brief  This API is used to Start Nemo Mode
	  \return IFX_SUCCESS / IFX_FAILURE 
     \note Starts nemo only when all handset supports nemo.
*/ 
e_IFX_Return IFX_DECT_MU_NemoStart();

 /*! \brief  This API is used to Stop Nemo Mode
	  \return IFX_SUCCESS / IFX_FAILURE 
*/ 
e_IFX_Return IFX_DECT_MU_NemoStop();

void IFX_DECT_MU_NemoIdleTimerFunc (IN uint32 uiTimerId,
                                     IN void* pvPrivateData);

 /*! \brief  This API is used to retrive the free Instance number
	  \return Instance number / IFX_FAILURE 
     \note once  instance retrived, need to free it after its use.
*/ 
e_IFX_Return IFX_DECT_MU_PageCallSetup(
                         IN uchar8 ucHandset,
	                      IN uchar8 ucPPInstance,
	                      IN uchar8 ucPPModelId,
						  IN uchar8 *pcCnip,
						  IN uchar8 *pcClip);

e_IFX_Return IFX_DECT_MU_UnregisterPP(
                        IN uchar8 ucInstance,
                        IN uchar8 ucHandset);

 /*! \brief  This API is used to retrive the free Instance number
	  \return Instance number / IFX_FAILURE 
     \note once  instance retrived, need to free it after its use.
*/ 
int8 IFX_DECT_GetMCEI(uchar8 ucHandsetNo);

/*! \brief  This API is used to block the incoming request Instance number
	  \return Instance number / IFX_FAILURE 
     \note once  instance blocked, need to free it after its use.
*/ 
int8 IFX_DECT_BlockMCEI(uchar8 ucHandset,uchar8 ucInstance);

/*! \brief  This API is used to Free the  instance number
	  \param[in] ucMCEI Instance Number
	  \return IFX_SUCCESS / IFX_FAILURE 
*/
e_IFX_Return IFX_DECT_FreeMCEI(uchar8 ucHandset,uchar8 ucMCEI);

/*! \brief  This API is used to retrive the call identifier
	  \param[out] pucCallId Pointer to Call Identifier
	  \return IFX_SUCCESS / IFX_FAILURE 
     \note once call identifer retrived, need to free it after its use.
*/
e_IFX_Return IFX_DECT_MU_GetCallID(IN uchar8 *pucCallId);

/*! \brief  This API is used to free the call identifier used previosly
	  \param[in] ucCallId  Call Identifier
	  \return Call Identifier / IFX_FAILURE 
*/
e_IFX_Return IFX_DECT_MU_FreeCallID(IN uchar8 ucCallId);

/*! \brief  This API is used to retrive the Line identifier
    \param[in] ucHandset Handset number
	  \param[out] pucLineId Pointer to Line Identifier
	  \return IFX_SUCCESS / IFX_FAILURE 
     \note shall be enchanced to return the voice line.
*/
e_IFX_Return IFX_DECT_MU_GetLineID(IN uchar8 ucHandset,OUT uint32 *puiLineId);

/*! \brief  This API is used to check if handset can take a call or not.
	  \param[in] ucHandsetId is Handset Identifier
	  \return IFX_SUCCESS / IFX_FAILURE 
*/
e_IFX_Return IFX_DECT_MU_IsHandSetBusy(IN uchar8 ucHandset);

/*! \brief  This API is used to check if handset has a call or
            not, return incarnation if present
	  \param[in] ucHandsetId is Handset Identifier.
	  \param[out] *pcInc is Incarnation number of the call.
	  \return IFX_SUCCESS / IFX_FAILURE 
*/
e_IFX_Return IFX_DECT_MU_IsCallExisting(IN uchar8 ucHandset, IN uchar8 *pcInc);

/*! \brief Add module owner*/
#define IFX_DECT_MU_ADD_OWNER 0x1

/*! \brief Remove module owner*/
#define IFX_DECT_MU_REMOVE_OWNER 0x2

/*! \brief  This API is used to update the MUinfo with module owner.
	  \param[in] ucHandsetId is Handset Identifier
	  \param[in] ucOperation Add owner or remove Owner
     \param[in] ucModuleOwner Module Owner
	  \return IFX_SUCCESS / IFX_FAILURE 
*/
e_IFX_Return IFX_DECT_MU_SetModuleOwner(IN uchar8 ucHandset,
                                        IN uchar8 ucOperation,
                                        IN uint32 uiModuleOwner);


/*! \brief  This API is used to get the Module owner for the specified ucInstance.
	  \param[in] ucInstance Incarnation number
	  \return ModuleOwner /IFX_FAILURE 
*/
uint32 IFX_DECT_MU_GetModuleOwner(IN uchar8 ucHandset);	
 
/*! \brief  This API is used to check if the module owner can release call
	  \param[in] ucHandsetId is Handset Identifier
	  \return IFX_SUCCESS / IFX_FAILURE 
*/
e_IFX_Return IFX_DECT_MU_CanCallBeReleased(IN uchar8 ucHandset); 
    
     
/*! \brief  This API is used to process Incoming IPC Message
	  \param[in] pxIPCMsg IPC Message
	  \return IFX_SUCCESS / IFX_FAILURE 
*/
e_IFX_Return IFX_DECT_MU_ProcessStackMsg(IN x_IFX_DECT_IPC_Msg *pxIPCMsg);

e_IFX_Return IFX_DECT_MU_ChangeBasePin(char8* pszPin);
#endif /*__IFX_DECT_MU_FSM__*/

