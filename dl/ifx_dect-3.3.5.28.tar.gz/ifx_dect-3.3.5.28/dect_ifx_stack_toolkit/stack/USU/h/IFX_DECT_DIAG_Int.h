/**************************************************************************
**   FILE NAME     : IFX_DECT_DIAG_Int.h
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 15-05-2009
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Call Control
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software is granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
#define TOOL_DBG
#if 0
typedef enum
{
   BMC_REGISTER_READ_REQ = 0x01,
   BMC_BEARER_READ_REQ,
   MEMORY_INFOMATION, 
   PATCH_RAM_INFORMATION,
   DEBUG_MSSAGE_INFORMATION,
         
} DEBUG_INFO_ID;
         
typedef enum
{           
   BMC_REGISTER = 0x10,
   OSC_TRIMMING_VAL, 
   GFSK_VALUE,       
   RF_TEST_MODE_SET, 
   SPI_SETUP_PACKET,
   DEBUG_MESSAGE_ONOFF
} BMC_REGISTER_PACKET_TYPE;
#endif
enum
{
TC_INIT,
TC_RESET,
TC_BMCSET,
TC_OSCSET,
TC_GFSKSET,
TC_RFPISET,
TC_BMC6GET,
TC_BMCETSIGET,
TC_OSCGET,
TC_GFSKGET,
TC_RFGET,
TC_TBR6,
TC_MEMGET,
TC_TPCSET,
TC_FREQGET
}test_case; 


#define FALSE 0
#define TRUE 1

/*Extern varibles imported from stack*/
extern FPTR Get_Rfpi_Ptr( void );
extern BMC_RSSI_STRUCT Bmc_Rssi_Settings;
extern uchar8 Osc_Trim_H;
extern uchar8 Osc_Trim_L;
extern uint16 GFSK_Value;


extern void TestAppInitMac(HMAC_QUEUES* data);
extern int TestAppSelect(void);
extern void TestAppWriteToHmac(BYTE procid, BYTE msgnr
                  ,BYTE param1, BYTE param2, BYTE param3, BYTE param4
                  ,BYTE param5, BYTE param6, FPTR pdata, BYTE inc);
extern void TestAppParamInit();

e_IFX_Return IFX_DECT_DIAG_TestAppSelectRead();
e_IFX_Return IFX_DECT_DIAG_TestAppSelectDebug();
e_IFX_Return HandleDrvMsg1();
e_IFX_Return HandleDectDbg();
void FlushOldPackets(void);
void SetFreqDef();
void SetBmcDef();
void SetOscDef();
void SetGfskDef();
void SetRFPIDef1();
e_IFX_Return TestAppPrcMsg(HMAC_QUEUES* data);
e_IFX_Return TestAppPrcDbgMsg(DECT_MODULE_DEBUG_INFO *data);
void TestAppWriteDebugInfo(BYTE info_id, BYTE rw_indicator, BYTE inc, FPTR pdata);
void TestAppWriteDebug(unsigned char ucDbgInfoId, unsigned char operation,
                        FPTR  G_PTR);
						
