/**************************************************************************
 **   FILE NAME     : IFX_DECT_SMSU.h
 **   PROJECT       : DECT TOOLKIT
 **   MODULES       : Transaction User
 **   SRC VERSION   : 
 **   DATE          : 
 **   AUTHOR        : 
 **   DESCRIPTION   : Function prototypes for the SMS module of the DECT Tkt
 **   COMPILER      : 
 **   REFERENCE     : Coding guide lines,IFX_SP_TUDIS.
 **   COPYRIGHT     : Copyright (c) 2004
 **                   Infineon Technologies AG, st. Martin Strasse 53;
 **                   81669 Munchen, Germany
 **
 **   Any use of this software is subject to the conclusion of a respective
 **   License agreement. Without such a License agreement no rights to the
 **   software are granted

 **  Version Control Section  **        
 **   $Author$    
 **   $Date$      
 **   $Revisions$ 
 **   $Log$       Revision history
 ***********************************************************************/
/*! \file IFX_DECT_SMSU_fsm.h
  \brief This File contains the data structures and the function(API-Internal,External Callback)
  prototypes for the SMS module
 */
/** \defgroup 
  \brief 
 */
/* @{ */
/* @} */ /*       */
/*---------- First Level Grouping ---------------------*/
/** \ingroup 
  \defgroup 
  \brief 
 */

/** \ingroup 
  \defgroup 
  \brief 
 */
/* @{ */
#ifdef MESSAGE_SUPPORT
#ifndef __IFX_DECT_SMSU_FSM_H__
#define __IFX_DECT_SMSU_FSM_H__

/*!\define IFX_DECT_SMSU_MAX_MESGLEN
  \brief Max length of a message
 */
#define IFX_DECT_SMSU_MAX_MESGLEN 160

/*!\define IFX_DECT_SMSU_MAX_MESG_SEGLEN
  \brief Max length of a segment
 */
#define IFX_DECT_SMSU_MAX_SEG_DATALEN 127

/*!\define IFX_DECT_SMSU_MAX_MESG
  \brief max no. of messages that can be stored
 */
#define IFX_DECT_SMSU_MAX_MESG 20


/*!\define IFX_DECT_SMSU_LOWER_NIBBLE_MASK 
  \brief mask to read the lower nibble of a byte
 */

#define IFX_DECT_SMSU_LOWER_NIBBLE_MASK 15

/*!\define IFX_DECT_SMSU_LOWER_TRIPLET_MASK
  \brief Mask to read the lowest 3 bits of a byte
 */
#define IFX_DECT_SMSU_LOWER_TRIPLET_MASK 7

/*! \struct x_IFX_DECT_SMSU_DataBlock_Upper
  \brief Holds the Upper Part or Header of a message.
 */

typedef struct
{
  uchar8 ucToFromNumberSize;   /*!<destinastion/origination number size.*/
  uchar8 aucToFromNumber[2];   /*!<destinastion/origination number. */
  uchar8 ucMesgSize;           /*!<message size.*/
}x_IFX_DECT_SMSU_DataBlock_Upper;

/*! \struct x_IFX_DECT_SMSU_DataBlock_Lower
  \brief Holds the Lower Part or Footer of a message.
 */
typedef struct 
{
  x_IFX_DECT_SMSU_TimeStamp xMesgTimeStamp;     /*!<time stamp*/
  uchar8 ucExtnNumber;                          /*!<extension no.*/
  uchar8 ucChecksum;                            /*!<checksum*/
}x_IFX_DECT_SMSU_DataBlock_Lower;

/*! \struct x_IFX_DECT_SMSU_HeaderGroup
  \brief Group of Headers of Messages stored
 */
typedef struct
{
  uchar8 ucHeaderCount;                       /*!<No of headers.*/
  x_IFX_DECT_SMSU_HeaderBlock axHeaders[20];  /*!<Array of Headers.*/
  uchar8 ucChecksum;                          /*!<Checksum.*/
}x_IFX_DECT_SMSU_HeaderGroup;


/*! \struct x_IFX_DECT_SMSU_SegmentPacket
  \brief structure of a SMS packet segment
 */


typedef struct
{
  uchar8 ucSeg_num : 5;       /*!<segment number.*/
  uchar8 ucSms_seg:3;         /*!<fixed value of 1.*/
  uchar8 ucSbit :1;           /*!<0 if its the last segment,1 is more segments to come.*/
  uchar8 ucSegmentSize :7;    /*!<size of this segment.*/
}x_IFX_DECT_SMSU_SegmentPacketHeader;

/*! \struct x_IFX_DECT_SMSU_Notify
  \brief To define separate type for SMS_NOTIFY
 */

typedef struct
{ 
  uchar8 ucNumUnreadMesg :4; /*!<Number of unread messages.*/
  uchar8 ucPrimitive :4;     /*!<Fixed value:7.*/
}x_IFX_DECT_SMSU_Notify;


/*! \struct x_IFX_DECT_SMSU_SendReqUpper
  \brief structure of a SMS_SEND_REQ primitive
 */

typedef struct
{
  uchar8 ucReserved :4;     /*!<reserved bits.*/
  uchar8 ucPrimitive:4;     /*!<fixed value of 3.*/
  uchar8 ucMesgSize;        /*!<size of the message being sent.*/
}x_IFX_DECT_SMSU_SendReqUpper;

/*! \struct x_IFX_DECT_SMSU_DataReq
  \brief structure of SMS_DATA_REQ and SMS_DELETE_REQ primitives
 */


typedef struct
{
  uchar8 ucReqType : 2;   /*!<Data Request-Headers:1, message:2,Delete Request-Single 1,All 2.*/
  uchar8 ucMesgBox : 2;   /*!<1:inbox , 2:outbox.*/
  uchar8 ucPrimitive :4;  /*!<DataReq:1,DeleteReq:5.*/
  uchar8 ucMesgIndex;     /*!<message index.*/
}x_IFX_DECT_SMSU_DataReq;


/*! \union ux_IFX_DECT_SMSU_DataRspUpper
  \brief structure of a SMS_DATA_RSP primitive
 */

typedef struct
{
  uchar8 ucReqType : 2;    /*!<headers 1,message 2.*/
  uchar8 ucMesgBox : 2;    /*!<inbox 1,outbox 2.*/
  uchar8 ucPrimitive :4;   /*!fixed value of 2.*/
  uchar8 ucMesgIndex;      /*!<message index.*/
  uchar8 ucMesgSize;       /*!<size of the message.*/
}x_IFX_DECT_SMSU_DataRspUpper;


/*! \struct x_IFX_DECT_SMSU _DeleteRsp
  \brief To define separate type for SMS_DELETE_RSP and SMS_SEND_RSP
 */

typedef struct
{
  uchar8 ucFailureReasonCode : 2;     /*!<Reason for failure.*/
  uchar8 ucDeleteDeliverStatus : 2;   /*!<Status of delivery/deletion.*/
  uchar8 ucPrimitive :4;              /*!<DeleteRsp:6,SendRsp:4.*/
}x_IFX_DECT_SMSU_DeleteRsp;


/*! \struct x_IFX_DECT_SMSU_SegAck
  \brief structure for SMS segment acknowledge packet.
 */

typedef struct
{
  uchar8 ucReqSegNo : 5;  /*!<Requested segment number.*/
  uchar8 ucSMS_Ack : 3;   /*!<fixed value 2.*/
  uchar8 ucAsmStatus : 4; /*!<assembly status partial:0 success:1 failure:2.*/
  uchar8 ucFailReason:4;  /*!<Failure reason Code.*/
}x_IFX_DECT_SMSU_SegAck;


/*! \enum e_IFX_DECT_SMSU_State
  \brief defines whether a call is established or not, 
         or is in the process of being established.
 */

typedef enum
{
  IFX_DECT_SMSU_IDLE=0,     /*!<No call Established. */
  IFX_DECT_SMSU_TRANSIENT,  /*!<In the process of making a call.*/
  IFX_DECT_SMSU_ACTIVE,     /*!<Call extablished.Offering Services.*/
}e_IFX_DECT_SMSU_State;


/*! \struct x_IFX_DECT_SMSU_MesgBlock
    \brief Structure for a message block.
*/
    
typedef struct{
  x_IFX_DECT_SMSU_DataBlock_Upper xMesgUpper;
  uchar8 aucMesgContents[IFX_DECT_SMSU_MAX_MESG_DATALEN];
  x_IFX_DECT_SMSU_DataBlock_Lower xMesgLower;
}x_IFX_DECT_SMSU_MesgBlock; 


/*State     */
typedef struct{
  
  e_IFX_DECT_SMSU_State eSMS_State;
  uchar8 ucInstance;
  uchar8 ucMesgIndex;
  uchar8 ucUnread;
  uchar8 ucBufLen;
  uchar8 acBuff[750];
  
  union{
   x_IFX_DECT_SMSU_HeaderGroup xHeaderGroup;
   x_IFX_DECT_SMSU_MesgBlock xMesgBlock;
  }uxSMS_Data;

}x_IFX_DECT_SMSU_Info;


/*! \enum e_IFX_DECT_SMSU_Primitive
  \brief types of message primitives
 */

typedef enum
{
  IFX_DECT_SMSU_NOTIFY=7,/*!<00000111*/
  IFX_DECT_SMSU_DATA_REQ=1,/*!<00000001*/
  IFX_DECT_SMSU_DATA_RSP=2,/*!<00000010*/
  IFX_DECT_SMSU_DELETE_REQ=5,/*!<00000101*/
  IFX_DECT_SMSU_DELETE_RSP=6,/*!<00000110*/
  IFX_DECT_SMSU_SEND_REQ=3,/*!<00000011*/
  IFX_DECT_SMSU_SEND_RSP=4/*!<00000100*/
}e_IFX_DECT_SMSU_Primitive; 

/*! \enum e_IFX_DECT_SMSU_SegPrimitive
  \brief types of segment primitive messages.
 */

typedef enum
{
  IFX_DECT_SMSU_SEG_ACK=2,/*!<00000010*/
  IFX_DECT_SMSU_SEGMENT=1/*!<00000001*/
}e_IFX_DECT_SMSU_SegPrimitive;

/*! \enum e_IFX_DECT_SMSU_DeleteReqType
  \brief To set Request type for IFX_DECT_SMSU_DELETE_REQ
 */
typedef enum
{
  IFX_DECT_SMSU_SINGLE=1,/*!<01000000*/
  IFX_DECT_SMSU_ALL=2/*!<10000000*/
}e_IFX_DECT_SMSU_DeleteReqType;


/*! \enum e_IFX_DECT_SMSU_S_Bit
  \brief To specify whether this is the last segment or not
 */

typedef enum
{
  IFX_DECT_SMSU_LAST_SEGMENT=0,/*!<00000000*/
  IFX_DECT_SMSU_MORE_SEGMENTS=1/*!<10000000*/
}e_IFX_DECT_SMSU_S_Bit;

/*! \enum e_IFX_DECT_SMSU_AssemblyStatus
  \brief Status of assembly of segments at the peer.
 */

typedef enum
{
  IFX_DECT_SMSU_PARTIAL=0,/*!<00000000*/
  IFX_DECT_SMSU_COMPLETE=1,/*!<00010000*/
  IFX_DECT_SMSU_FAIL=2/*!<00100000*/
}e_IFX_DECT_SMSU_AssemblyStatus;

/*! \enum e_IFX_DECT_SMSU_IWU_SendReject
  \brief Send/Reject bit in the IWU IWU message
 */

typedef enum
{
  IFX_DECT_SMSU_REJECT=0,/*!<00000000*/
  IFX_DECT_SMSU_SEND=1/*!<01000000*/
}e_IFX_DECT_SMSU_IWU_SendReject;


typedef x_IFX_DECT_SMSU_DeleteRsp x_IFX_DECT_SMSU_SendRsp;
typedef x_IFX_DECT_SMSU_DataReq x_IFX_DECT_SMSU_DeleteReq;

/*brief IFX_DECT_SMSU_ProcessStackMsg: API to the message router called when a new message arrives
  \note 
  \param[in] pxIpcMsg IPC message
  \return  IFX_SUCCESS or IFX_FAILURE
 */

e_IFX_Return IFX_DECT_SMSU_ProcessStackMsg(IN x_IFX_DECT_IPC_Msg* pxIpcMsg);

/*! \brief  Internal API to recieve CC_CONNECT
  \note
  \param[in] pxIpcMsg IPC message containing FP_CONNECT_IN_CC   
  \return  IFX_SUCCESS or IFX_FAILURE
 */

e_IFX_Return IFX_DECT_SMSU_ConnectArrived(IN x_IFX_DECT_IPC_Msg* pxIpcMsg);

/*! \brief  Internal API to recieve CC_SETUP
  \note 
  \param[in] pxIpcMsg IPC message containing FP_SETUP_IN_CC   
  \return  IFX_SUCCESS or IFX_FAILURE

 */

e_IFX_Return IFX_DECT_SMSU_SetupArrived(IN x_IFX_DECT_IPC_Msg* pxIpcMsg);

/*! \brief  Internal API called when CC_RELEASE arrives
  \note  
  \param[in] pxIpcMsg IPC message containing FP_RELEASE_IN_CC   
  \return  IFX_SUCCESS or IFX_FAILURE

 */

e_IFX_Return IFX_DECT_SMSU_ReleaseArrived(IN x_IFX_DECT_IPC_Msg* pxIpcMsg);

/*! \brief  Internal API called when a SMS_DATA_REQ/SEG ACK arrives in CC_INFO
  \note  
  \param[in] pcPrimitiveMesg The SMS primitive in character buffer 
  \param[in] iPrimitiveLen The length of this Primitive mesg
  \param[in] pxIpcMsg The IPC message which contained the primitive as FP_INFO_IN_CC
  \return  IFX_SUCCESS or IFX_FAILURE

 */

e_IFX_Return IFX_DECT_SMSU_FetchData(IN char8 *pcPrimitiveMesg, IN int32 iPrimitiveLen,
    IN x_IFX_DECT_IPC_Msg* pxIpcMsg);


/*! \brief  Internal API called when a SMS_DELETE_REQ arrives in CC_INFO
  \note  
  \param[in] pcPrimitiveMesg The SMS primitive in character buffer 
  \param[in] iPrimitiveLen The length of this Primitive mesg
  \param[in] pxIpcMsg The IPC message which contained the primitive as FP_INFO_IN_CC
  \return  IFX_SUCCESS or IFX_FAILURE

 */
e_IFX_Return IFX_DECT_SMSU_DeleteMessage(IN char8 *pcPrimitiveMesg, IN int32 iPrimitiveLen,IN x_IFX_DECT_IPC_Msg* pxIpcMsg);


/*! \brief  Internal API called when a SMS_SEND_REQ/SEGMENT arrives in CC_INFO
  \note  
  \param[in] pcPrimitiveMesg The SMS primitive in character buffer 
  \param[in] iPrimitiveLen The length of this Primitive mesg
  \param[in] pxIpcMsg The IPC message which contained the primitive as FP_INFO_IN_CC
  \return IFX_SUCCESS or IFX_FAILURE.
 */

e_IFX_Return IFX_DECT_SMSU_ComposeMessage(IN char8 *pcPrimitiveMesg,IN int32 iPrimitiveLen,IN x_IFX_DECT_IPC_Msg* pxIpcMsg);

/*! \brief  To send notify for all the unread messages
  \param[in] ucHandSet HandSet number.
  \param[in] ucUnread the number of unread messages for this handset.
  \return  IFX_SUCCESS or IFX_FAILURE

 */

e_IFX_Return IFX_DECT_SMSU_NotifyUnread(uchar8 ucHandSet,uchar8 ucUnread);

/*! \brief  To encode SMS primitives into IWU-IWU messages
  \note
  \param[in] pcIWU_Data the would be contents of the IWU message
  \param[in] iIWU_DataLen the length of this data buffer
  \param[out] pcIWU_String The resultant IWU message
  \return  IFX_SUCCESS or IFX_FAILURE

 */
e_IFX_Return EncodeIWU_SMS(char8 *pcIWU_Data,int32 iIWU_DataLen,char8 *pcIWU_String);

/*! \brief  To send setup to the Stack
  \note
  \param[in] ucHandSet the handset no
  \param[in] pcIE the IE of the FP_SETUP_IN_CC
  \param[in] iIELen the length of the IE
  \param[in] bWideband whether it's a wideband call or not
  \return  IFX_SUCCESS or IFX_FAILURE

 */

e_IFX_Return IFX_DECT_SMSU_SendSetup(IN uchar8 ucHandset,
                                     IN uint32 uiIEHdl,
                                     IN boolean bWideband);

/*! \brief  To send release to the stack.
  \note
  \param[in] ucHandSet the handset no
  \param[in] ucReason Reason for release
  \param[in] pcIE the IE of the FP_SETUP_IN_CC
  \param[in] iIELen the length of the IE
  \return  IFX_SUCCESS or IFX_FAILURE

 */
e_IFX_Return IFX_DECT_SMSU_SendRelease(IN uchar8 ucHandSetNo,
                                       IN uchar8 ucReason,
				       IN uint32 uiIEHdl);

/*! \brief  to concatenate 2 or more structures(all having elements as characters) into a string
  \note
  \param[in] no_src No of structures to concatenated
  \param[in] dest pointer to the destination
  \param[out] destlen length of resultant character array
  \param[in] src1 first structure
  \param[in] src1_len length 
  \param[in] src2 second structure
  \param[in] src2_len length
  \param[in] srcn nth structure
  \param[in] srcn_len length
  \return  IFX_SUCCESS or IFX_FAILURE

 */
e_IFX_Return IFX_DECT_SMSU_memcat(int32 no_src,void *dest,int32 *destlen,const void *src1,int32 src1_len,
    const void* src2, int32 src2_len,...);

/*! \brief To get the timezone in terms of quarters(15 min. units) west of GMT.
    \param[in] pcQuarterWest Quarters west of GMT.
    \return IFX_SUCCESS or IFX_FAILURE.

 */

e_IFX_Return IFX_DECT_SMSU_GetTimeStamp(OUT x_IFX_DECT_SMSU_TimeStamp *pxMesgTimeStamp);
#endif /*__IFX_DECT_SMSU_fsm_H__*/
#endif
