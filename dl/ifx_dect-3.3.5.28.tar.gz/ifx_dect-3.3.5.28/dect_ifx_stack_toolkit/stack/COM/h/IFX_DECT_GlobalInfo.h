/*
 * =====================================================================================
 *
 *       Filename:  IFX_DECT_GlobalInfo.h
 *
 *    Description:  Structure to hold all the global information
 *
 *        Version:  1.0
 *        Created:  Tuesday 14 October 2008 12:30:42  IST
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Voice Team
 *        Company:  IFIN
 *
 * =====================================================================================
 */
/*! \file IFX_DECT_GlobalInfo.h
    \brief This File includes all global data required by the dect toolkit.
*/
#ifndef __IFX_DECT_GLOBALINFO_H__
#define __IFX_DECT_GLOBALINFO_H__

#include "IFX_DECT_Platform.h"
/* callbacks*/
#include "IFX_DECT_IEParser.h"
#include "IFX_DECT_Stack.h"
#include "IFX_DECT_MU.h"
#include "IFX_DECT_CSU.h"
#include "IFX_DECT_SMSU.h"
#include "IFX_DECT_SUOTA.h"
#include "IFX_DECT_DPSU.h"
#include "IFX_DECT_ESU.h"
#include "IFX_DECT_USU.h"
#include "IFX_DECT_LAU.h"
/* FSM */
#include "IFX_DECT_MsgRouter.h"
#include "IFX_DECT_MsgEncoder.h"
#include "IFX_DECT_MU_Fsm.h"
#include "IFX_DECT_CCInfo.h"
#include "IFX_DECT_DataIwu.h"
#include "IFX_DECT_SMSU_fsm.h"
#include "IFX_DECT_USUFsm.h"
#include "IFX_DECT_ESU_Main.h"
#include "IFX_DECT_LAU_Info.h"

/*! \def IFX_DECT_DIAG_MODE
    \brief Macro used to specify the DECT Toolkit to operate in Diagnostic mode. In Diagnostic mode the DECT toolkit
	       would spawn a thread, and execute in its own context for listening to incoming events from the applications.
		   The callbacks and functions are available to caller function, as the new thread shares the address space
		   with the FT application. a very limited set of operations are allowed in this mode.
 */
#define IFX_DECT_DIAG_MODE 0x4


/**  Structure to hold global information of the toolkit
*/
typedef struct
{
  uint32 uiStatus; /*!< To hold the status of the DECT Stack*/

  void (*vpfnInitStatus)(int32 iStatus);/*!< vpfnInitStatus to store the init function call*/

  x_IFX_DECT_SyncCallBks vxDECTSyncCallBks;/*!< Dect Sync Callbacks*/

  uint32 viDECTStackMode;/*!< Dect stack mode sunc/async*/

  x_IFX_OS_LockType xCCApiLock,xSockDescLock,xSMSApiLock,xDPSApiLock,
                      xESUApiLock, xMUApiLock,xDIAGApiLock; /*!< DECT mutually exclusive locks*/

  x_IFX_DECT_StackInitCfg xStackCfg;/*!< Stack Configuration*/
  
  int32 iRegTime;/*!< Registration Time*/
 
  int32 uiStackHdl; /*!< Stack Handle*/
  uint32 uiRingTimeOut;/*!< Ring Time Out */
  char8 bRingPauseOn;/*!< Ring pause On/Off */
  
  struct{
    x_IFX_DECT_CSU_CallBks vxCSUCallBks;
    x_IFX_DECT_CC_Info avxCCInfo[IFX_DECT_MAX_HS][IFX_DECT_MAX_CALLS_PER_HS];
	  x_IFX_DECT_CC_Info  *paxActCallHdl[IFX_DECT_MAX_HS];
	  uchar8 ucConfReqId;
  }xCSU;
#ifdef MESSAGE_SUPPORT
  struct{
    x_IFX_DECT_SMSU_Info vxSMSInfo[IFX_DECT_MAX_HS];/*!< SMSU State Info*/
	x_IFX_DECT_SMSU_AppCallBks xAppCallBks;/*!< SMSU Callbacks*/
  }xSMSU;	
#endif

  struct{
    char8 acHandsetMap[IFX_DECT_MAX_DATACON];
    x_IFX_DECT_DPSU_DataSessionType vxSessionList[IFX_DECT_MAX_DATASESS];
	                                            /*!< DPSU State Info and callbacks*/
  }xDPSU;
  struct {
    x_IFX_DECT_MU_CallBks vxMUCallBks; /*!< MU Callbacks*/
    x_IFX_DECT_MUInfo vxMUInfo[IFX_DECT_MAX_HS];/*!< MU State Info*/
	uint32 vuiRegistrationTimerId;/*!< Registration Timer ID*/
    uchar8 vacMCEI[IFX_DECT_MAX_HS];/*!< MCEI Holding array */ 
		uint16 vauiEMC[IFX_DECT_MAX_HS];/*!< EMC Holding array */
    uchar8 vacCallId[IFX_DECT_MAX_FT_CALLS];/*!< CallId Holding array*/
    e_IFX_DECT_MU_NemoState veNemoState; /*!< Nemo State*/
	uint32 vuiNemoTimer; /*!< Nemo Idle Timer*/
	uchar8 ucRegMode;/*!< in Registration Mode*/
	uchar8 ucRegInstance;/*!< instance of HS that is registering*/
	uchar8 vacPropInfo[IFX_IPC_DECT_MAX_DATA_SIZE]; /*!< Prop Info stored for temp purpose*/
  }xMU;

  struct {
    x_IFX_DECT_ESU_CallBks vxESUCallBks; /*!< ESU CallBacks */
	x_IFX_DECT_ESU_Info vxESUInfo[IFX_DECT_MAX_HS];/*!< ESU State info */
  }xESU;

  struct{
     x_IFX_DECT_USU_CallBks vxUSUCallBks; /*<USU CallBacks */
      uchar8 ucRFState; /*1- On or 
	                      0- Off.*/
 	  uchar8 vucLoaderMode,vucBank;/* Loader mode and Bank*/
      uint16 vunLoaderAddr; /*Loader Address*/
#ifdef SUPERTASK	  
	  uchar8 *vpucBmcFilePtr,*vpucCosicSwFilePtr;
	  uint32 vuiBmcLen, vuiCosicSwLen;
#else
      char8 aucBMCFileName[255];
      char8 aucUserAppFileName[255];
	  int32 iBmcFileFd,iUserSwFileFd;
#endif
	  uint32 vuiFwTimer;
	  x_IFX_DECT_LoaderFrame vxFramebackup;
	  uchar8 vucRetryCount;
 }xUSU;
 
  struct{
 
      uint32 uiTC; /*! Test Case type */
	  volatile int32 viDiagMode; /*! Diagnostic mode ON/OFF*/
	  char isDiagOnGoing; /*! Flag indicating diagnostics reguestes are completed or not*/
	  

 }xDIAG;

  /* Global Information pertianing to LAU */ 
  struct{
    x_IFX_DECT_LAU_Info axLauInfo[IFX_DECT_MAX_HS][IFX_DECT_LAU_MAX_SESS_PER_HS];/*! Per session Information maintained by LAU */
    x_IFX_DECT_LAU_CallBks vxLauCallBks;/*! LAU CallBacks */
    int32 iListSupported;/*! Lists supported by the application */
    uint32 uiEMCVal;/*! EMC Value for proprietary lists */
    uint16 aunSupportedFieldMap[IFX_DECT_LAU_MAX_SUPPORTED_LISTS];/*! Fields supported for a given list*/
	#ifdef LTQ_DT_SUPPORT
  	/*Global Information related to Propritry List*/
		uint32 iPropListCount;
		x_IFX_DECT_PROP_LAU_Info axPropListInfo[5];
	#endif
  }xLAU;
 
}x_IFX_DECT_GlobalInfo;

extern x_IFX_DECT_GlobalInfo vxGlobalInfo;
extern uchar8 vcDECTTKModId;
#endif /*__IFX_DECT_GLOBALINFO_H__*/
