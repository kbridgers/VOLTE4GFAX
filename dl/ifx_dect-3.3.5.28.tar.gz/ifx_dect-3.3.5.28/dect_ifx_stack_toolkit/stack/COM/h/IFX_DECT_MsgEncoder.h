/**************************************************************************
**   FILE NAME     : IFX_DECT_MsgEncoder.h
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 26-09-2008
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Call Control
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_DECT_MsgEncoder.h
    \brief This File contains the Encode functions for the toolkit.
*/
 #ifndef __IFX_DECT_MSG_ENCODER__
 #define __IFX_DECT_MSG_ENCODER__


/*! \enum e_IFX_DECT_QT_MESSAGE_ID
    \brief Descibes the QT Message type.
 */
typedef enum{
 IFX_DECT_Q0_MESSAGE =0, /*!<System Info*/
 IFX_DECT_Q3_MESSAGE,/*!< FT Cap*/
 IFX_DECT_Q6_MESSAGE,/*!< MultiFram number*/
 IFX_DECT_Q4_MESSAGE,/*!< Extended Cap*/
 IFX_DECT_QC_MESSAGE,/*!< Extended Cap part 2*/
}e_IFX_DECT_QT_MESSAGE_ID;



/*! \enum e_IFX_DECT_IE_EventType
   \brief Enum containing the Event Type
*/
typedef enum{
  IFX_DECT_EVT_TYPE_MW=0,/*!< Message Waiting*/
  IFX_DECT_EVT_TYPE_MC=1,/*!< Missed Call*/
  IFX_DECT_EVT_TYPE_WC=2,/*!< Web content*/
  IFX_DECT_EVT_TYPE_LCI=3/*!< List Cahnge Indication*/
}e_IFX_DECT_IE_EventType;

/*! \enum e_IFX_DECT_IE_MwEvtSubType
   \brief Enum containing the Message Waiting Event Sub Type
*/
typedef enum{
  IFX_DECT_MW_EVT_STYPE_UK=0,/*!< Unknown*/
  IFX_DECT_MW_EVT_STYPE_VM=1,/*!< Voice Mail*/
  IFX_DECT_MW_EVT_STYPE_SMS=2,/*!< SMS*/
  IFX_DECT_MW_EVT_STYPE_EMAIL=3,/*!< E mail*/
}e_IFX_DECT_IE_MwEvtSubType;

/*! \enum e_IFX_DECT_IE_McEvtSubType
   \brief Enum containing the Missed Call Event Sub Type
*/
typedef enum{
  IFX_DECT_MC_EVT_STYPE_UK=0,/*!< Unknown*/
  IFX_DECT_MC_EVT_STYPE_VM=1,/*!< Voice Call*/
}e_IFX_DECT_IE_McEvtSubType;



/*! \enum e_IFX_DECT_IE_CallInfoType
   \brief Enum containing the Call Information Type
*/
typedef enum{
  IFX_DECT_TYPE_LINE_ID=0,/*!< Line Identifier*/
  IFX_DECT_TYPE_CALL_ID=1,/*!< Call Identifier*/
  IFX_DECT_TYPE_CALL_STATUS=2,/*!< Call Status*/
}e_IFX_DECT_IE_CallInfoType;

/*! \enum e_IFX_DECT_IE_LineIdSubType
   \brief Enum containing the Line Identifier Sub Type
*/
typedef enum{
  IFX_DECT_STYPE_LINE_ID_EXT=0,/*!< Line Identifier for external call*/
  IFX_DECT_STYPE_SRCLINE_ID_INT=1,/*!< Source Line Identifier for Internal Call*/
  IFX_DECT_STYPE_TGTLINE_ID_INT=2,/*!< Target Line Identifer for Internal Call*/
  IFX_DECT_STYPE_RELATING_TO=3,/*!< Relating to Line Identifier*/
  IFX_DECT_STYPE_ALL =4, /*!< All Lines*/
  IFX_DECT_STYPE_LINE_TYPE=5 /* !< Linr type information subtype */
}e_IFX_DECT_IE_LineIdSubType;

/*! \enum e_IFX_DECT_IE_LineIdSubType
   \brief Enum containing the Line Identifier Sub Type
*/
typedef enum{
  IFX_DECT_STYPE_CALL_ID=0,/*!< call Identifier*/
  IFX_DECT_STYPE_UTDCALL_ID=1,/*!< updated call Identifier*/
}e_IFX_DECT_IE_CallIdSubType;

/*! \enum e_IFX_DECT_IE_CallStatusSubType
   \brief Enum containing the Call Status Sub Type
*/
typedef enum{
  IFX_DECT_STYPE_CALL_STATUS=1,/*!< Call Status*/
  IFX_DECT_STYPE_CALL_STATUS_REASON=2,/*!< Call Status Reason */
}e_IFX_DECT_IE_CallStatusSubType;

/*! \enum e_IFX_DECT_IE_CallStatus
   \brief Enum containing the Call Status Values
*/
typedef enum{
  IFX_DECT_CS_IDLE=0,/*!< Call Status*/
  IFX_DECT_CS_SETUP,/*!< Call Status Reason */
  IFX_DECT_CS_SETUP_ACK,/*!< Call Status Reason */
  IFX_DECT_CS_PROC,/*!< Call Status Reason */
  IFX_DECT_CS_ALERT,/*!< Call Status Reason */
  IFX_DECT_CS_CONNECT,/*!< Call Status Reason */
  IFX_DECT_CS_DISCONNECT,/*!< Call Status Reason */
  IFX_DECT_CS_HOLD=0x09,/*!< Call Status Reason */
  IFX_DECT_CS_INTERCEPTED,/*!< Call intercepted*/
  IFX_DECT_CS_CONF_CONNECT,/*!< Call Status Reason */
  IFX_DECT_CS_UNDER_TRANSFER, /*!< Call under transfer*/
  IFX_DECT_CS_REMOTE_HOLD,/*!< Call Status Reason */
  IFX_DECT_CC_MEDIA_NEG,/*!< Media Neg State*/
  IFX_DECT_CC_UPLANE,/*!< UPLANE Exists*/
  IFX_DECT_CC_NOUPLANE,/*!< Uplane does not exist*/
}e_IFX_DECT_IE_CallStatus;


/* Definitions for DECT NG */
#define IFX_DECTNG_CODEC_G726_32	  0x02
#define IFX_DECTNG_CODEC_G722_64	  0x03
#define IFX_DECTNG_CODEC_G711_A	    0x04
#define IFX_DECTNG_CODEC_G711_U	    0x05
#define IFX_DECTNG_CODEC_G729_32	  0x06


/*---------------------- define ESCAPE-TO-PROPRIETARY ---------------------------*/

                                       /* For PRODECT V2.0 !               */
                                       /* -------------------------------- */
#define MODEL_ID_PRODECT_V20	0x20
// Sub-Model Identifier for Loewe Telecom DECT Telephone Series
#define IFX_DECT_MODEL_ID		0x40

#define CALL_TYPE				0x03


                                       /* reserved 0x01                       */
                                       /* -------------------------------- */
                                       /* reserved 0x02                       */
                                       /* -------------------------------- */
                                       /* CALL TYPE                        */
                                       /* -------------------------------- */
                                       /* Call type coding according to    */
                                       /* << BASIC SERVICE >> IE !         */
                                       /* see 'CC_LIB.H'                   */
/*
#define EXTERNAL_CALL			0x80
#define INTERNAL_CALL			0x90
#define EMERGENCY_CALL			0xA0
#define SERVICE_CALL				0xB0
*/
                                       /* USER ACTION                      */
                                       /* -------------------------------- */
#define USER_ACTION				0x04
#define AUTO_ACCEPT			0
#define AUTO_RELEASE			1

                                       /* reserved 0x05                    */
                                       /* -------------------------------- */
                                       /* RR Number         */
                                       /* -------------------------------- */
#define RR_NUMBER		               0x06
                                       /* The internal portable number is  */
                                       /* appended !      */           

                                       /* reserved 0x07 ~ 0x0f             */
                                       /* -------------------------------- */

// New Escape-to-Proprietary Code for Memory Process accessing
/* Memory process action */
#define MEM_ACTION					0x10
//Handset --> Base
#define DATE_TIME_STATE			0
#define DEREGISTER_STATE			1
#define MASTER_PIN_STATE			2

// Base --> Handset


                                       /* CID ACTION                           */
                                       /* -------------------------------- */
/* Memory process action */
#define CID_ACTION					0x11
#define CID_RECEPTION_OK			0
#define CID_RECEPTION_ERROR		1


#define DATE_TIME					0x12
#define MODEL_NAME					0x13

                                       /* RECEIVED_CLIP                       */
                                       /* -------------------------------- */
/* CID Number and CID name */
#define CID_CLIP						0x14

                                       /* CALL MANAGE ACTION                           */
                                       /* -------------------------------- */
/* Memory process action */
#define CALL_MANAGE_ACTION		0x15
#define MAKE_CONF					0 // make conference [handset->Base]
#define MAKE_CONF_OK				1 // make conference ok [Base->handset]
#define MAKE_CONF_ERROR			2 // make conference error [Base->handset]
#define CALL_HOLD					3 // make call hold [handset->Base]
#define CALL_HOLD_OK				4 // make call hold ok [Base->handset]
#define CALL_HOLD_ERROR			5 // make call hold error [Base->handset]
#define CALL_RESUME					6 // make call resume [handset->Base]
#define CALL_RESUME_OK				7 // make resume ok  [Base->handset]
#define CALL_RESUME_ERROR			8 // make resume error  [Base->handset]
#define CALL_FOWARD				9 // make call forward [handset->Base]
#define CALL_FOWARD_OK				10 // make forward ok  [Base->handset]
#define CALL_FOWARD_ERROR			11 // make forward error  [Base->handset]
#define CALL_TRANSFER				12 // make call transfer [handset->Base]
#define CALL_TRANSFER_OK			13 // make transfer ok  [Base->handset]
#define CALL_TRANSFER_ERROR		14 // make transfer error  [Base->handset]
#define ACTIVE_CCBS					15 // make activate CCBS [handset->Base]
#define ACTIVE_CCBS_OK				16 // make call activate CCBS ok  [Base->handset]
#define ACTIVE_CCBS_ERROR			17 // make call activate CCBS error  [Base->handset]
#define DEACTIVE_CCBS				18 // make call deactivate CCBS [handset->Base]
#define DEACTIVE_CCBS_OK			19 // make call deactivate CCBS ok  [Base->handset]
#define DEACTIVE_CCBS_ERROR		20 // make call deactivate CCBS error  [Base->handset]
#define CALL_WAIT					21 // call wait status  [Base->handset]


                                       /* 3byte : EMC type + EMC Code      */
                                       /* Every proprietary code consists  */
                                       /* of 2 bytes !                     */
                                       /* added EP_KEY_ICON                */
#define MAX_PROPRIETARY_CODE_LENGTH    (3 + 57) 

#define MAX_IWU_PROPRIETARY_CODE_LENGTH      210

/*---------------------- End : define ESCAPE-TO-PROPRIETARY -----------------------*/


/* Following routines encode messages and send them to DECT stack */

/*! \brief Construct CC Setup Message 
  	\param[in] ucHandset handset number
    \param[in] ucPPInstance instance number
    \param[in] bWidebandCall Is Wideband Call
    \param[in] bDataCall is Data Call
    \param[out] pxIpcMsg Ipc Message
    \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_EncodeSetup(IN uchar8 ucHandset,
                          IN uchar8 ucPPInstance,
                          IN char8 bWidebandCall,
                          IN e_IFX_DECT_CallType eCallType,
													IN uchar8 ucSignal,
                          OUT x_IFX_DECT_IPC_Msg *pxIpcMsg);

/*! \brief  Constructs CC-SETUP-ACK Message
  	\param[in] ucHandset handset number
    \param[in] ucPPInstance instance number
    \param[out] pxIpcMsg Ipc Message
   \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_EncodeSetupAck(IN uchar8 ucHandset,
	                                   IN uchar8 ucPPInstance,
                                     OUT x_IFX_DECT_IPC_Msg *pxIpcMsg);

/*! \brief  Constructs CC-REJECT Message
  	\param[in] ucHandset handset number
    \param[in] ucPPInstance instance number
	  \param[in] ucReason Reason for Rejection
    \param[out] pxIpcMsg Ipc Message
    \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_EncodeReject(IN uchar8 ucHandset,
	                                 IN uchar8 ucPPInstance,
                                   IN uchar8 ucReason,
                                   OUT x_IFX_DECT_IPC_Msg *pxIpcMsg);

/*! \brief  Constructs CC-Alert Message
  	\param[in] ucHandset handset number
    \param[in] ucPPInstance instance number
    \param[out] pxIpcMsg Ipc Message
    \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_EncodeAlert(IN uchar8 ucHandset,
	                                IN uchar8 ucPPInstance,
                                  OUT x_IFX_DECT_IPC_Msg *pxIpcMsg);


/*! \brief  Constructs CC-Proc Message
  	\param[in] ucHandset handset number
    \param[in] ucPPInstance instance number
    \param[out] pxIpcMsg Ipc Message
    \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_EncodeCallProc(IN uchar8 ucHandset,
	                                   IN uchar8 ucPPInstance,
                                     OUT x_IFX_DECT_IPC_Msg *pxIpcMsg);

/*! \brief  Constructs CC-Connect Message
  	\param[in] ucHandset handset number
    \param[in] ucPPInstance instance number
	  \param[in] bWidebandCall if 1 Wideband call else narrowband
    \param[out] pxIpcMsg Ipc Message 
    \return IFX_SUCCESS or IFX_FAILURE
*/

e_IFX_Return IFX_DECT_EncodeConnect(IN uchar8 ucHandset,
	                                  IN uchar8 ucPPInstance,
								                    IN boolean bWidebandCall,
                                    OUT x_IFX_DECT_IPC_Msg *pxIpcMsg);

/*! \brief Construct  CC-ConnectAck Message
  	\param[in] ucHandset handset number
    \param[in] ucPPInstance instance number
    \param[out] pxIpcMsg Ipc Message 
   \return IFX_SUCCESS or IFX_FAILURE
*/

e_IFX_Return IFX_DECT_EncodeConnectAck(IN uchar8 ucHandset,
	                                     IN uchar8 ucPPInstance,
                                       OUT x_IFX_DECT_IPC_Msg *pxIpcMsg);

/*! \brief Construct  CC-Info Message
  	\param[in] ucHandset handset number
    \param[in] ucPPInstance instance number
    \param[in] ucSignal Signal number.
    \param[out] pxIpcMsg Ipc Message 
   \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_EncodeCCInfo(IN uchar8 ucHandset,
	                                 IN uchar8 ucPPInstance,
	                                 IN uchar8 ucSignal,
                                   OUT x_IFX_DECT_IPC_Msg *pxIpcMsg);

/*! \brief  Construct CC-Release Message
  	\param[in] ucHandset handset number
    \param[in] ucPPInstance instance number
	  \param[in] ucReason Reason for Call Release
    \param[out] pxIpcMsg Ipc Message 
   \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_EncodeRelease(IN uchar8 ucHandset,
                                    IN uchar8 ucPPInstance,
				      						          IN uchar8 ucReason,
                                    OUT x_IFX_DECT_IPC_Msg *pxIpcMsg);

/*! \brief Constructs IWI Info Message 
  	\param[in] ucHandset handset number
    \param[in] ucPPInstance instance number
    \param[out] pxIpcMsg Ipc Message 
    \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_EncodeIWUInfo(
                        IN uchar8 ucHandset,
 	                      IN uchar8 ucPPInstance,
                        OUT x_IFX_DECT_IPC_Msg *pxIpcMsg);

/*! \brief  Construct Service Change Request Message
    \param[in] ucPPInstance instance number
  	\param[in] ucHandset handset number
	  \param[in] bChangeToWideband if 1 Change to Wideband codec else narrow band
    \param[out] pxIpcMsg Ipc Message 
    \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_EncodeServiceChangeRq(
	                      IN uchar8 ucPPInstance,
                        IN uchar8 ucHandset,
	                      IN boolean bChangeToWideband,
                        OUT x_IFX_DECT_IPC_Msg *pxIpcMsg);

/*! \brief  Construct Service Change Accept
  	\param[in] ucHandset handset number
    \param[in] ucPPInstance instance number
    \param[out] pxIpcMsg Ipc Message 
    \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_EncodeServiceChangeAccept(
                         IN uchar8 ucHandset,
	                       IN uchar8 ucPPInstance,
                         IN x_IFX_DECT_IPC_Msg *pxIpcMsg);

/*! \brief  Construct Service Change Request
  	\param[in] ucHandset handset number
    \param[in] ucPPInstance instance number
    \param[out] pxIpcMsg Ipc Message 
    \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_EncodeServiceChangeReject(
                        IN uchar8 ucHandset,
	                      IN uchar8 ucPPInstance,
                        IN x_IFX_DECT_IPC_Msg *pxIpcMsg);

/*! \brief  Construct Slot modification Request
  	\param[in] ucHandset handset number
    \param[in] ucPPInstance instance number
    \param[in] bLongSlot if 1  change to Long Slot else full slot.
    \param[out] pxIpcMsg Ipc Message 
    \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_EncodeSlotModReq(IN uchar8 ucHandset,
                                            IN uchar8 ucPPInstance,
												                    IN boolean bLongSlot,
                                            IN x_IFX_DECT_IPC_Msg *pxIpcMsg);

/*! \brief Encode Enable Voice 
  	\param[in] ucHandset handset number
    \param[in] ucPPInstance instance number
    \param[in] iChannelNo Channel number.
    \param[out] pxIpcMsg Ipc Message 
   \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_EncodeEnableVoice(IN uchar8 ucHandset,
           	                      IN uchar8 ucPPInstance,
			                            IN int32 iChannelNo,
                                  OUT x_IFX_DECT_IPC_Msg *pxIpcMsg);

/*! \brief  Encode Disable Voice
  	\param[in] ucHandset handset number
    \param[in] ucPPInstance instance number
    \param[in] iChannelNo Channel number.
    \param[out] pxIpcMsg Ipc Message 
   \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_EncodeDisableVoice(IN uchar8 ucHandset,
	                      IN uchar8 ucPPInstance,
	                      IN int32 iChannelNo,
                        OUT x_IFX_DECT_IPC_Msg *pxIpcMsg);

/*! \brief Enable/Disable Cipher 
  	\param[in] ucHandset handset number
    \param[in] ucPPInstance instance number
    \param[in] bCipherOn if 1 enables cipher else disables
    \param[out] pxIpcMsg Ipc Message 
   \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_EncodeEnableCipher(IN uchar8 ucHandset,
                                   IN uchar8 ucPPInstance, 
	                                 IN boolean bCipherOn ,
                                   IN x_IFX_DECT_IPC_Msg *pxIpcMsg);

/*! \brief Construct Uplane Message 
  	\param[in] iLen Data Length
    \param[in] ucPPInstance instance number
    \param[out] pxIpcMsg Uplane Ipc Message 
   \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_EncodeDataToStack(IN int32 iLen,
                                        IN uchar8 ucPPInstance,
                                        IN x_IFX_DECT_IPC_Msg_u *pxUPlaneIpcMsg);

/*! \brief Encode Enable Data 
  	\param[in] ucHandset handset number
    \param[in] ucPPInstance instance number
    \param[out] pxIpcMsg Ipc Message 
   \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_EncodeEnableData(IN uchar8 ucPPInstance,
                                       IN uchar8 ucHandsetId,
                                       OUT x_IFX_DECT_IPC_Msg *pxIpcMsg);
/*----------------------------- Decode routines ------------------------------*/
/*! \brief  
	\param[in] 
   \param[in]  
   \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return  IFX_DECT_KeypadEvents(
	                      IN char8* pMsgBuf,
	                      OUT char8* pszDigits,
	                      boolean* pbHookFlash);
						  
/*! \brief This function is used to fetch the current IE by skiping the HLI_Header.
    \param[out] IPC Message
    \return    IEHandler
*/
uint32 IFX_DECT_IE_GetIEHandler(IN x_IFX_DECT_IPC_Msg *pxIPCMsg);


/*! \brief This function is used to encode Slot modification IWU.
    \param[in] ucHandset handset number
	\param[in] ucPPInstance instance number
	\param[in] bwideband 1 if wideband 0 if narowband
	\param[out] pxIpcMsg IPC Message
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_EncodeSlotIWUInfo(IN uchar8 ucHandset,
                                        IN uchar8 ucPPInstance,
                                        IN boolean bWidebandCall,
                                        OUT x_IFX_DECT_IPC_Msg *pxIpcMsg);

e_IFX_Return IFX_DECT_EncodeFacility(IN uchar8 ucHandset,
                                     IN uchar8 ucPPInstance,
									 OUT x_IFX_DECT_IPC_Msg	*pxIpcMsg);
																		  
e_IFX_Return IFX_DECT_EncodeQTMsg(IN e_IFX_DECT_QT_MESSAGE_ID eQtId,
                                  IN uchar8 *pcBuff,
								  IN x_IFX_DECT_IPC_Msg *pxIpcMsg);

e_IFX_Return IFX_DECT_IE_Remove(uint32 uiIEHdl,e_IFX_DECT_IE eIEType);

e_IFX_Return IFX_DECT_EncodeAuthPTReq(IN uchar8 ucHandset,
                                      IN uchar8 ucPPInstance,
                                          IN x_IFX_DECT_IPC_Msg *pxIpcMsg); 
#endif /*__IFX_DECT_MSG_ENCODER__*/


