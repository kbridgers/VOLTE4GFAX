/**************************************************************************
**   FILE NAME     : IFX_DECT_StackIf.h
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 26-09-2008
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Call Control
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_DECT_StackIf.h
    \brief This File includes all reference of the DECT stack needed by the toolkit.
*/
#ifndef __IFX_DECT_STACKIF_H__
#define __IFX_DECT_STACKIF_H__

#include "DEFINE.H"
#include "SYSDEF.H"
#include "TYPEDEF.H"
#include "CONF_DEF.H"
#include "ERROR.H"
#include "FGLOBAL.H"
#include "MM_LIB.H"
#include "MESSAGE_DEF.H"
#include "PCT_DEF.H"
#include "CC_DEF.H"

#include "drv_dect.h"
/*Extern varibles imported from stack*/
extern BMC_RSSI_STRUCT Bmc_Rssi_Settings;

#ifdef DECT_NG
extern XDATA  uchar8 Primary_Codec;//=CODEC_G722;
#endif

#ifdef __PIN_CODE__
void IFX_DECT_ST_SetPinCode(char* pszPinCode);
#endif
#ifdef CATIQ_UPLANE

EXPORT int16 
LU10SduTxGetPtr (uint8 Lln,FPTR *NextSduDataP );

EXPORT int16 
LU10SduTx (uint8 Lln, uint16 Bytes2Send, FPTR *NextSduDataP );
#endif

#endif /* __IFX_DECT_STACKIF_H__*/


