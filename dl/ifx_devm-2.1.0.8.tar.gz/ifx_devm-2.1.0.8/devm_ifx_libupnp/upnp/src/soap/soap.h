#ifndef CWMP_SOAP_H
#define CWMP_SOAP_H

#ifdef __cplusplus
extern "C" {
#endif

typedef int (*func)(IXML_Node *node);

typedef struct {
    char *rpcName;
    func funcptr;
}callbackTbl_t;

void ifx_soap_init();
void ifx_soap_resetConnection();

int ifx_soap_send_inform(Inform *inform, int authReq);
int ifx_soap_GetParameterNamesResponse_send(ParameterInfoStruct *paramInfo, int max);
int ifx_soap_GetParameterValuesResponse_send(ParameterValueStruct *pvs, int max);
int ifx_soap_GetRPCMethodsResponse_send(RPCMethods *rpcMethods);
int ifx_soap_GetParameterAttributesResponse_send(ParameterAttributesStruct *pas, int max);
int ifx_soap_SetParameterAttributesResponse_send();
int ifx_soap_SetParameterValuesResponse_send(int status);
int ifx_soap_AddObjectResponse_send(int instance, int status);
int ifx_soap_DeleteObjectResponse_send(int status);
int ifx_soap_register_callback(char *rpcName, func funcptr);
int ifx_soap_send_faultResponse(int err_code, struct paramFault *pf, int num);
int ifx_soap_send_ack();
int ifx_soap_DownloadResponse_send(char *download_resp);

#ifdef __cplusplus
}
#endif

#endif //#ifndef CWMP_SOAP_H
