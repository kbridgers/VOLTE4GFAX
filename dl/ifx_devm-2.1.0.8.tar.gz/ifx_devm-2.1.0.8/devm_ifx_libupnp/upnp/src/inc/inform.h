const char *msg =
"POST / HTTP/1.1"
"Content-Length:1094"
"Host: 192.168.1.2:9995"
"<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:cwmp=\"urn:dslforum-org:cwmp-1-0\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
	"<SOAP-ENV:Header>"
		"<cwmp:ID SOAP-ENV:mustUnderstand=\"1\">12</cwmp:ID>"
	"</SOAP-ENV:Header>"
	"<SOAP-ENV:Body>"
		"<cwmp:Inform>"
			"<DeviceId>"
			        "<Manufacturer xsi:type=\"xsd:string\">Cisco</Manufacturer>"
				"<OUI xsi:type=\"xsd:string\">FE23C0</OUI>"
				"<ProductClass xsi:type=\"xsd:string\">class 1</ProductClass>"
				"<SerialNumber xsi:type=\"xsd:string\">00000001</SerialNumber>"
			"</DeviceId>"
			"<Event SOAP-ENC:arrayType=\"cwmp:EventStruct[1]\">"
			"<EventStruct>"
				"<EventCode>0 BOOTSTRAP</EventCode>"
			"</EventStruct>"
			"</Event>"
			"<MaxEnvelopes>1</MaxEnvelopes>"
			"<CurrentTime>2005-04-11T21:42:23+05:00</CurrentTime>"
			"<RetryCount>0</RetryCount>"
			"<ParameterList SOAP-ENC:arrayType=\"cwmp:ParameterValueStruct[1]\">"
				"<ParameterValueStruct>"
					"<Name>InternetGatewayDevice.DeviceInfo.SpecVersion</Name>"
					"<Value>1</Value>"
				"</ParameterValueStruct>"
			"</ParameterList>"
		"</cwmp:Inform>"
	"</SOAP-ENV:Body>"
"</SOAP-ENV:Envelope>";
/* 
"POST / HTTP/1.1\n"
"Content-Length:1138\n"
"Host: 192.168.1.2:9995\n"
"<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:cwmp=\"urn:dslforum-org:cwmp-1-0\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n"
	"<SOAP-ENV:Header>\n"
		"<cwmp:ID SOAP-ENV:mustUnderstand=\"1\">12</cwmp:ID>\n"
	"</SOAP-ENV:Header>\n"
	"<SOAP-ENV:Body>\n"
		"<cwmp:Inform>\n"
			"<DeviceId>\n"
			        "<Manufacturer xsi:type=\"xsd:string\">Cisco</Manufacturer>\n"
				"<OUI xsi:type=\"xsd:string\">FE23C0</OUI>\n"
				"<ProductClass xsi:type=\"xsd:string\">class 1</ProductClass>\n"
				"<SerialNumber xsi:type=\"xsd:string\">00000001</SerialNumber>\n"
			"</DeviceId>\n"
			"<Event SOAP-ENC:arrayType=\"cwmp:EventStruct[1]\">\n"
			"<EventStruct>\n"
				"<EventCode>0 BOOTSTRAP</EventCode>\n"
			"</EventStruct>\n"
			"</Event>\n"
			"<MaxEnvelopes>1</MaxEnvelopes>\n"
			"<CurrentTime>2005-04-11T21:42:23+05:00</CurrentTime>\n"
			"<RetryCount>0</RetryCount>\n"
			"<ParameterList SOAP-ENC:arrayType=\"cwmp:ParameterValueStruct[1]\">\n"
				"<ParameterValueStruct>\n"
					"<Name>InternetGatewayDevice.DeviceInfo.SpecVersion</Name>\n"
					"<Value>1</Value>\n"
				"</ParameterValueStruct>\n"
//				"<ParameterValueStruct>\n"
//					"<Name>InternetGatewayDevice.DeviceInfo.HardwareVersion</Name>\n"
//					"<Value xsi:type=\"xsd:string\">x.y</Value>\n"
//				"</ParameterValueStruct>\n"
//				"<ParameterValueStruct>\n"
//					"<Name>InternetGatewayDevice.DeviceInfo.SoftwareVersion</Name>\n"
//					"<Value xsi:type=\"xsd:string\">3.0</Value>\n"
//				"</ParameterValueStruct>\n"
//				"<ParameterValueStruct>\n"
//					"<Name>InternetGatewayDevice.ManagementServer.ConnectionRequestURL</Name>\n"
//					"<Value xsi:type=\"xsd:string\">http://192.168.10.106:30005/</Value>\n"
//				"</ParameterValueStruct>\n"
//				"<ParameterValueStruct>\n"
//					"<Name>InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.1.ExternalIPAddress</Name>\n"
//					"<Value xsi:type=\"xsd:string\">192.169.10.106</Value>\n"
//				"</ParameterValueStruct>\n"
			"</ParameterList>\n"
		"</cwmp:Inform>\n"
	"</SOAP-ENV:Body>\n"
"</SOAP-ENV:Envelope>\n";*/

//#include "uri.h"

void sendInformMsg()
{
    uri_type dest, fix;
    int sockfd, num_bytes;
    SOCKINFO info;
    int timeout = 5, ret = 0;
    http_parser_t response;

    memset(&dest, 0, sizeof(dest));
    dest.scheme.buff = "http";
    dest.scheme.size = 8;
    dest.hostport.text.size = 1;
    dest.hostport.IPv4address.sin_family = AF_INET;
    dest.hostport.IPv4address.sin_addr.s_addr = inet_addr("192.168.1.2");
    dest.hostport.IPv4address.sin_port = htons(9995);
    sockfd = http_Connect(&dest, &fix);
    if(sockfd < 0) {
	printf("error in http_Connect %d\n", sockfd);
    	ret = http_RequestAndResponse(&dest, msg, strlen(msg), HTTPMETHOD_POST, timeout, &response);
    	printf("ret=%d\n",ret);
	//return ;
    } else {
    	info.socket = sockfd;
    	info.foreign_ip_addr.s_addr = inet_addr("192.168.1.2");
    	info.foreign_ip_port = htons(9995);
    	num_bytes += sock_write(&info, msg, strlen(msg), &timeout);
    	printf("num_bytes written = %d\n",num_bytes);
    }
}

