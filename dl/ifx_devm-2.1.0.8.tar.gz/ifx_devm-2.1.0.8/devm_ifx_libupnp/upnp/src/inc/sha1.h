#ifndef _SHA1_H
#define _SHA1_H

#ifndef _STD_TYPES
#define _STD_TYPES

#define uchar   unsigned char
#define uint    unsigned int
#define ulong   unsigned long int

#endif

typedef struct
{
    ulong total[2];
    ulong state[5];
    uchar buffer[64];
}
sha1_context;

/*
 * Core SHA-1 functions
 */
void sha1_starts( sha1_context *ctx );
void sha1_update( sha1_context *ctx, uchar *input, uint length );
void sha1_finish( sha1_context *ctx, uchar digest[20] );

/*
 * Output HMAC-SHA-1(key,buf)
 */
void sha1_hmac( uchar *key, uint keylen, uchar *buf, uint buflen,
                uchar digest[20] );

#endif /* sha1.h */

