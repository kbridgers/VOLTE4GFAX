#ifndef __IFX_DEVM_TR064UPNP_H__
#define __IFX_DEVM_TR064UPNP_H__

/*
** =============================================================================
** FILE NAME     : IFX_DEVM_TR064UPnP.h
** PROJECT       : TR64
** MODULES       : TR64
** DATE          : 10-Apr-2007
** AUTHOR        : TR69 team
** DESCRIPTION   : This is the header file for TR64. It has all
**                 defines, datatypes and function prototypes of TR64
** REFERENCES    : DDD-TR69-ProtocolAPI.doc
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author      $Comment
** 25-Apr-2006 TR69 team    Initial Version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_Global.h"
#include "IFX_DEVM_Platform.h"

/*
** =============================================================================
**
**                                 <DEFINITIONS>
**
** =============================================================================
*/
#define IFX_TR64_MAX_PARAM_NAME_LEN   128
#define IFX_TR64_MAX_PARAM_VALUE_LEN  128
#define IFX_TR64_MAX_ACTION_LEN       64
#define IFX_TR64_MAX_OBJ_LEN          64
#define IFX_TR64_MAX_SERVICEID_LEN    64
#define IFX_TR64_MAX_KEY_ELEMENTS     6
#define IFX_TR64_MAX_OUTPUT_PARAMS    40
#define IFX_TR64_MAX_INPUT_PARAMS     15
#define IFX_TR64_MAX_SESSIONID_LEN     40
#define IFX_TR64_MAX_ARGUMENTS         10
#define IFX_TR64_MAX_ALLOWED_VALUES    10
#define IFX_TR64_MAX_TR69_DATATYPE_LEN 10
#define IFX_TR64_MAX_DATATYPE_LEN      10
#define IFX_TR64_MAX_OBJ_LEAFS         40

#ifdef IFX_TR69_WIFILAN
#define IFX_TR64_MAX_STATE_ARG_MAP_ELEM       31
#else
#define IFX_TR64_MAX_STATE_ARG_MAP_ELEM       29
#endif

#define IFX_TR64_MAX_NAME_LEN		64
#define IFX_TR64_MAX_CPEID_CHARS	10

#ifndef MIPSTARGET
#define FILE_TR64_DB   "tr64_upnp_db.txt"
#else
#define FILE_TR64_DB   "/etc/tr69/tr64_upnp_db.txt"
#endif

/* Operations in the IFX_TR64_Request Structure. */
#define IFX_TR64_OPER_GET             1
#define IFX_TR64_OPER_SET             2
#define IFX_TR64_OPER_ADD             3
#define IFX_TR64_OPER_DEL             4
#define IFX_TR64_OPER_REQ_CONN        5
#define IFX_TR64_OPER_REQ_TERM        6
#define IFX_TR64_OPER_FOR_TERM        7
#define IFX_TR64_OPER_REBOOT          8
#define IFX_TR64_OPER_FACTORY_RESET   9
#define IFX_TR64_OPER_CONF_START      10
#define IFX_TR64_OPER_CONF_FINISH     11


#define IFX_TR64_MAX_SESSION_ID_LEN       40
//#define IFX_TR64_SESSION_TIMEOUT_SECS     (30*1000)
#define IFX_TR64_SESSION_TIMEOUT_ID       10
#define IFX_TR64_SESSION_TIMEOUT_SECS     (40*1000)
#define IFX_TR64_MAX_VALUE_LEN            64
#define IFX_TR64_MAX_COLUMN_VALUE_LEN     512
#define IFX_TR64_DB_MAX_NO_COLUMN         5
#define IFX_TR64_MAX_ERROR_STRING_LEN     36
#define IFX_TR64_MAX_SYS_TR64_MAP         12
#define IFX_TR64_MAX_ERR_STRING_MAP       13
#define IFX_TR64_ERR_WRITEACESS_DISABLED  898
#define IFX_TR64_ERR_SESS_ID_EXPIRED	  899
#define IFX_TR64_MAX_ERROR_STRING_LEN     36
#define IFX_TR64_MAX_UUID_LEN		  68
#define IFX_TR64_DB_LINE_LEN		  256
#define IFX_TR64_CHANGE_FLAG_SET	1
#define IFX_TR64_CHANGE_FLAG_RESET	0

/* SDD Related */
#define IFX_TR64_DIRECTION_IN  0
#define IFX_TR64_DIRECTION_OUT 1

/* DDD Related */
#define IFX_TR64_DEVICE_FRINEDLYNAME     "FRIENDLYNAME"
#define IFX_TR64_DEVICE_MANUFACTURER     "MANUFACTURER"
#define IFX_TR64_DEVICE_MANUFACTURERURL  "MANUFACTURERURL"
#define IFX_TR64_DEVICE_MODELDESCRIPTION "MODELDESCRIPTION"
#define IFX_TR64_DEVICE_MODELNAME        "MODELNAME"
#define IFX_TR64_DEVICE_MODELNUMBER      "MODELNUMBER"
#define IFX_TR64_DEVICE_MODELURL         "MODELURL"
#define IFX_TR64_DEVICE_SERIALNUMBER     "SERIALNUMBER"
#define IFX_TR64_DEVICE_UDN_PREFIX       "uuid:"
#define IFX_TR64_DEVICE_UUID             "12345678-0000-0000-0000-00000000abcd"
#define IFX_TR64_DEVICE_UPC              "UPC"
#define IFX_TR64_DDD_NODEFAULT           "$$$"
#define IFX_TR64_MAX_DOC_ALLOC_LEN       2048
#define IFX_TR64_BUFF_LEN                20480
#define IFX_TR64_DEVICECONFIG_SERVICEID               "device_config-1"
#define IFX_TR64_WANDSLCONNECTIONMANAGEMENT_SERVICEID "conn_mgmt-1"


#define IFX_TR64_AUTH_POS		  5
#define IFX_TR64_CHLD_OID_POS		  1
#define IFX_TR64_OUT_PARAM_POS		  4
#define IFX_TR64_IN_PARAM_POS		  3
#define IFX_TR64_KEY_POS                  2

#define IFX_TR64_REBOOT_REQ		  1
#define IFX_TR64_CHANGES_APPLIED	  0
#define IFX_TR64_TR69OID_SEP		  "."



#define IFX_TR64_MAX_UUID_URN_LEN         256
#define IFX_TR64_MAX_UUID_STR_LEN         45
#define IFX_TR69_MAX_OID_STR_LEN          64

//TR64 Err Codes
#define IFX_TR64_ERR_INVALID_ACTION       401
#define IFX_TR64_ERR_INVALID_ARGS         402
#define IFX_TR64_ERR_ACTION_FAILED        501
#define IFX_TR64_ERR_INVAL_PARAM_VAL      600
#define IFX_TR64_ERR_OUT_OF_MEMORY        603
#define IFX_TR64_ERR_ACTION_NOTAUTHORIZED 606
#define IFX_TR64_ERR_WRITEACESS_DISABLED 898
#define IFX_TR64_ERR_SESS_ID_EXPIRED	899
#define IFX_TR64_ERR_DUP_ENTRY	          718
#define IFX_TR64_ERR_VAL_SPECIFIED_INVAL  702 //If Key not present in Delete & Set - Translation Layer
#define IFX_TR64_ERR_ARR_INDX_INVAL       713
#define IFX_TR64_ERR_NO_ENTRY_INARR       714
#define IFX_TR64_ERR_INVAL_SERVICEID      721

#define IFX_TR64_SERVICEID_NOT_REQUIRED     0
#define IFX_TR64_SERVICEID_REQUIRED         1

#define IFX_TR64_ARG_FWD_MAP			0
#define IFX_TR64_ARG_REV_MAP			1

/*
** =============================================================================
**
**                                    <TYPES>
**
** =============================================================================
*/

typedef enum tr64_session_state {
    TR64_SESSION_INDIVIDUAL_RPC = 1,
    TR64_SESSION_STATE_ACTIVE = 2,
    TR64_SESSION_STATE_INACTIVE = 3
} TR64_STATE;
typedef struct
{
    char8  sName[IFX_TR64_MAX_PARAM_NAME_LEN];
    char8  *psValue;
} IFX_TR64_NameValue;
typedef struct
{
    int32    iSysErrCode;
    int32    iTr64ErrCode;
}IFX_SYS_TO_TR64_ERRORMAP;


typedef struct
{

    int32  iTr64ErrCode;
    //char8  sTR64ErrString[IFX_TR64_MAX_ERROR_STRING_LEN];
    char8  *sTR64ErrString;

}IFX_TR64_ERRCODE_MAPTO_ERRSTRING;

typedef struct
{
    char8 *sActionName;
    char8 *sStateVarName;
    char8 *sArgName;

}IFX_TR64_StateArgMap;

/* If string not present in soap msg, then fill null string
If index not present fill -1
If keys/outparams not present fill 0 */

typedef struct
{
    uchar8             ucOper; //TML
    char8              sAction[IFX_TR64_MAX_ACTION_LEN]; //SOAP
    char8              sServiceObj[IFX_TR64_MAX_OBJ_LEN]; //SOAP
    char8              sServiceId[IFX_TR64_MAX_SERVICEID_LEN]; //SOAP
    int32              iChildOID; //TML
    int32              iIndex; //TML
    int32              iaOIDKeyElem[IFX_TR64_MAX_KEY_ELEMENTS]; //TML Fills after referring tr64_db.txt
    int32              iaOIDOutParam[IFX_TR64_MAX_OUTPUT_PARAMS]; //TML (for Get Only)
    char8              sSessionID[IFX_TR64_MAX_SESSIONID_LEN];  //SOAP
    uint32             uiNumNameValue; //SOAP
    IFX_TR64_NameValue *pxNameValue; //SOAP in Set, Add, Del or GetSpecific
    uchar8             ucServiceIdState;
} IFX_TR64_Request;

typedef struct
{
    int32              iStatus;
    char8              sErrorString[IFX_TR64_MAX_ERROR_STRING_LEN];
    uint32             uiNumNameValue;
    IFX_TR64_NameValue *pxNameValue;
} IFX_TR64_Response;

/********** Following structs are used for DDD/SDD Generation ***********/
typedef struct
{
    char8  sName[IFX_TR64_MAX_PARAM_NAME_LEN];
    uchar8 ucDirection;
    char8 sStateVarName[IFX_TR64_MAX_PARAM_NAME_LEN];
} IFX_TR64_Argument;

typedef struct
{
    char8             sName[IFX_TR64_MAX_ACTION_LEN];
    IFX_TR64_Argument *pxArgument;
    uint32            uiNumArgument;
} IFX_TR64_Action;

typedef struct
{
    char8 sAllowedValue[IFX_TR64_MAX_PARAM_VALUE_LEN];
} IFX_TR64_AllowedValues;

typedef struct
{
    char8                  sName[IFX_TR64_MAX_PARAM_NAME_LEN];
    char8                  sType[IFX_TR64_MAX_TR69_DATATYPE_LEN];  //SDD Generator will perform DataType Mapping
    char8                  sDefaultValue[IFX_TR64_MAX_PARAM_VALUE_LEN];
    IFX_TR64_AllowedValues *pxAllowedValue;
    uint32                 uiNumAllowedValue;
} IFX_TR64_StateVariable;

typedef struct
{
    char8                  sName[IFX_TR64_MAX_OBJ_LEN];
    IFX_TR64_Action        *pxAction;
    IFX_TR64_StateVariable *pxStateVariable;
} IFX_TR64_ServiceDesc;

typedef struct
{
    char8 *psName;
} IFX_TR64_Service;

typedef struct ifx_tr64_device
{
    char8                  *psName;
    IFX_TR64_Service       *pxService;
    struct ifx_tr64_device *pxDevice;
} IFX_TR64_Device;

typedef struct
{
    char8  *psName;
    uchar8 ucDirection;
    char8  *psStateVarName;
} IFX_TR64_ArgumentS;

typedef struct
{
    char8              *psName;
    IFX_TR64_ArgumentS *pxArgument;
} IFX_TR64_ActionS;

typedef struct
{
    char8 *psName;
    char8 *psType;  //SDD Generator will perform DataType Mapping
    char8 *psDefaultValue;
    char8 *psaAllowedValue[IFX_TR64_MAX_ALLOWED_VALUES];
} IFX_TR64_StateVariableS;

typedef struct
{
    char8                   *psName;
    char8                   *psServiceId;
    IFX_TR64_ActionS        *pxAction;
    IFX_TR64_StateVariableS *pxStateVariable;
} IFX_TR64_ServiceDescS;



/*
** =============================================================================
**
**                              <FUNCTION PROTOTYPES>
**
** =============================================================================
*/

int32 IFX_TR64_SOAP_Parse(IN char8 * psSOAPBuf, IN char8 * psServiceId,IN char8 * psAction);


int32 IFX_TR64_TALRequestHandler(IN IFX_TR64_Request *pxReq,
                                 OUT IFX_TR64_Response *pxRes);
#ifdef IFX_TR69_WIFILAN
/* kamal for handling the WLAN Security keys Get and Set */								 
int32 IFX_TR64_SecurityKeysRequestHandler(IN IFX_TR64_Request *pxReq,
                                          OUT IFX_TR64_Response *pxRes);
#endif
int32 IFX_TR64_TALStateVariableListGet(IN int32 iaOID[OID_LENGTH],
                                       IN int32 iChildOID,
                                       OUT IFX_TR64_StateVariable **ppxStateVariable,
                                       OUT uint32 *puiNumStateVariable);

int32 IFX_TR64_MapStateArgName(IN char8 *psAction, INOUT char8 *psStateVar, INOUT char8 *psArgName);

int32 IFX_TR64_TMLRequestHandler(IN IFX_TR64_Request *pxReq,OUT IFX_TR64_Response *pxRes);

int32 IFX_TR64_TMLActionListGet(IN char8 sServiceObj[IFX_TR64_MAX_OBJ_LEN],
                                IN int32 iaOID[OID_LENGTH],
                                OUT IFX_TR64_Action **ppxAction,
                                OUT uint32 *puiNumAction,
                                OUT int32 *piOID);

int32
IFX_CheckIfPasswordProtectAction(IN char8 *sServiceId,IN char8 *sAction,OUT int32 *iAuth);

int32 IFX_TR64_GenUUID(IN uint32 uiCpied, IN char8 *psName,OUT char8 *psUUID);

int32 IFX_TR64_GetCpeidFromUUID(IN char8 *psUUID, OUT uint32 *puiCPEId,OUT char8 *psName);

int32 IFX_TR64_SDDGenerate(IN char8 *psURL, OUT char8 **ppcSDD, OUT uint32 *puiCount);

int32 IFX_TR64_DDDGenerate(OUT char8 **ppcDDD, OUT uint32 *puiCount);

int32 IFX_TR64_SOAP_URLToServiceId(IN char8 *psURL,
                                   OUT char8 sServiceId[IFX_TR64_MAX_SERVICEID_LEN]);

int32 IFX_TR64_SOAP_FormResp(IN IFX_TR64_Request * xpTR64Request,
                       IN IFX_TR64_Response * xpTR64Response);

int32 IFX_TR64_GenDevList(INOUT char8 *DeviceList[],INOUT uint32 *iCount,IN uint32 port);

int32 IFX_TR64_DefaultWEPKeyIndexHandler(IN IFX_TR64_Request *pxReq,
                                          OUT IFX_TR64_Response *pxRes);

void IFX_TR64_FreeDevList(IN char8 *DeviceList[]);
#endif /* __IFX_DEVM_TR064UPNP_H__ */
