#include "IFX_DEVM_AutoGenTR064UPnPDB.h"
#include <errno.h>



/* main function */
int main ( int 		argc,
		   char 	*argv[] ) {

   FILE                                    *fp , *outFp;
   unsigned short int 		        i = 0, j, len = 0, l=0;; //removed Oid
   char					OidStr[MAXLINE], dupString[MAXLINE], FinalOidStr[MAXLINE] = {0};
   char	 				EndTag[TAGSIZE], SectName[STRSIZE], LineBuf[MAXLINE];
   char 					*pSubString[PTRSIZE], *pOid[PTRSIZE];// *pLine[PTRSIZE], *index[PTRSIZE];
   char 					*catmp =NULL;

   //  Verification of number of command line arguments
   if ( argc < 3 ) {
   	printf ("\n[%s]Usage Error : <a.out> <tr69_db.txt.IGD> <TR064_UPNP_DB.txt>\n", __func__);
   	exit(1);
   }

   // Open <TR064_UPNP_DB.txt> file to read
   if ( (fp = fopen(argv[2], "r")) == NULL ) {
   	printf ("\n[%s]Couldn't open %s file\n", __func__, argv[2]);
   	exit(1);
   }

   // Open <tr64_upnp_db.txt> file to write :
   if ( (outFp = fopen("tr64_upnp_db.txt", "w")) == NULL ) {
   	printf ("\n[%s]Couldn't open tr64_upnp_db.txt file\n", __func__);
   	exit(1);
   }
   while ( fgets(LineBuf, MAXLINE, fp) != NULL )
   {
       if((strstr(LineBuf, "//") == NULL) && (strstr(LineBuf, "#<< ") != NULL) )
       {
           // Form End Tag
           sscanf (LineBuf, "#<< %83s", SectName);
           sprintf (EndTag, "#>> %s\n", SectName);
           if(strstr(SectName, "DSL") != NULL)
           {
#ifndef IFX_TR69_ADSLWAN
               while(fgets(LineBuf, MAXLINE, fp) != NULL)
               {
                   if((strstr(LineBuf, EndTag) != NULL))
                       break; 
                   else
                       continue;
               }
               continue;
#endif 
           }
           if (strstr(SectName, "WLAN") != NULL )
           {
#ifndef IFX_TR69_WIFILAN
               while(fgets(LineBuf, MAXLINE, fp) != NULL)
               {
                   if((strstr(LineBuf, EndTag) != NULL))
                       break;
       	           else
                       continue;
               }
       	       continue;
#endif 
           }
           fputs(LineBuf, outFp);	
           while(fgets(LineBuf, MAXLINE, fp) != NULL)
           {
               if(strstr(LineBuf, "//") != NULL)
                    continue;

               if ( strcmp(LineBuf, "\n") == 0 )
               {
                   fputs(LineBuf, outFp);
               }
               else if( LineBuf[0] != '#' )
               {
                   i = 0;
                   pSubString[i] = strtok(LineBuf, "=");
                   strcpy(FinalOidStr, pSubString[i]);
                   for ( i = 1; (catmp=strtok(NULL, "~")) != NULL ; i++)
                   {
                       pSubString[i] = catmp; /*To store the value of each field in array after Action Name with "=" */
                   }
                   len = i;
                   strcat(FinalOidStr, "=");
                   for (i = 1, j = 0; i <= len-2; i++, j++)
                   {
                       if ( i == 1 )
                       {
                           #ifdef UPNP_IGD_VERSION_2
                           if((strcmp(pSubString[i], "2") == 0 ) || ( strcmp(pSubString[i], "0") == 0) )
                           {
                               continue;             
                           }
                           else
                           {
                               strcpy(FinalOidStr, "\0");
                               break;
                           }
                           #endif                                                              
                           #ifdef UPNP_IGD_VERSION_1
                           if ((strcmp(pSubString[i], "1") == 0) || ( strcmp(pSubString[i], "0") == 0))
                           {  
                               continue;                           
                           }    
                           else
                           { 
                               strcpy(FinalOidStr, "\0");
                               break;
                           }
                           #endif
                       } 
                       if ( i == 2 )
                       {
                           if(strcmp(pSubString[i], " ") != 0)
                           {
                               sprintf (dupString, ".%s.", pSubString[i]);
                           }
                           else
                           {
                               strcpy(dupString, pSubString[i]);
                           }
                       }
                       else
                       {
                           strcpy(dupString, pSubString[i]);
                       }

                       if ( i != 6 )
                       {
                           pOid[j] = Param2OidConvertion(OidStr, dupString, argv[1], SectName);
                           strcat(FinalOidStr,  pOid[j]);
                           strcat(FinalOidStr, "~");
                       }
                   }
                   strcat(FinalOidStr, "\n");
                   l = strlen(FinalOidStr);  /*To remove blank line which caused by removing the undefined IGD version action names */
                   if( l > 2 )
                       fputs(FinalOidStr, outFp);
                   else
                       continue;
               }
               else if(strstr(LineBuf, EndTag) != NULL)
               {
                   fputs(EndTag, outFp);
                   memset(FinalOidStr, '\0', MAXLINE);
                   memset(LineBuf, '\0', MAXLINE);
                   break;
               }
               else
               {
                   //fputs(LineBuf, outFp);
               }
           } // End of inner while loop
       }
       else
       {
           if(strstr(LineBuf, "//") == NULL)
               fputs(LineBuf, outFp);
       }
   } // End of outer while loop

   fclose(fp);
   fclose(outFp);
   printf ("\nThe Auto Generation tr64/upnp db file is : tr64_upnp_db.txt\n\n");
   return 0;
} // End of main()




/**************************************************************************************

                                 Functions

***************************************************************************************/

unsigned short int GetOid ( char 	*Object,
							char	*Parameter,
			 				char	*dbfilename )
{

	FILE 				*fp;
	char 				LineBuf[MAXLINE]={0},tmpLineBuf[MAXLINE]={0}; //removed SerchStr[STRSIZE] = { 0 };
	char 				*pLine,*tmp, *index,*ParamName;
	unsigned int 			Oid = 0;


	if ( (fp = fopen(dbfilename, "r")) == NULL ) {
		printf ("\n[%s] Couldn't open %s file [%d]\n", __func__, dbfilename, errno);
		exit(1);
	}

	while ( fgets(LineBuf, MAXLINE, fp) != NULL ) {

		if( ((pLine=strstr(LineBuf, Parameter)) != NULL) && (strstr(LineBuf, "//") == NULL)) {

			if ( LineBuf[0] != '#' ) {
				//Use strtok_r to match the params exactly
				//sprintf (SerchStr, "%s~", Parameter);
				strcpy(tmpLineBuf,LineBuf);
				ParamName = strtok_r(tmpLineBuf,"~-",&tmp);
				if(ParamName!=NULL){
				 	if(strcmp(Parameter,ParamName) != 0 )
					        continue;
				}
			}
			if ( (index = strchr(LineBuf,'-')) != NULL ) {
				sscanf(index,"-%u~",&Oid);
				if ( strcmp(Object, "DeviceInfo") == 0 ) {
					if ( Oid >= 1003 && Oid <= 1021 )
						break;
				} else if ( strcmp(Object, "ManagementServer") == 0 ) {
					if ( (Oid >= 1030 && Oid <= 1043) || (Oid >= 3001 && Oid <= 3012) )
						break;
				} else if ( strcmp(Object, "Layer3Forwarding") == 0 ) {
					if ( Oid >= 1077 && Oid <= 1091 )
						break;
				} else if ( strcmp(Object, "LANConfigSecurity") == 0 ) {
					if ( Oid >= 1092 && Oid <= 1093 )
						break;
				} else if ( strcmp(Object, "Time") == 0 ) {
					if ( Oid >= 1044 && Oid <= 1055 )
						break;
				} else if ( strcmp(Object, "Hosts") == 0 ) {
					if ( Oid >= 1214 && Oid <= 1223 )
						break;
				} else if ( strcmp(Object, "LANHostConfigManagement") == 0 ) {
					if ( Oid >= 1111 && Oid <= 1133 )
						break;
				} else if ( strcmp(Object, "LANEthernetInterfaceConfig") == 0 ) {
					if ( Oid >= 1134 && Oid <= 1145 )
						break;
				} else if ( strcmp(Object, "LANUSBInterfaceConfig") == 0 ) {
					if ( Oid >= 1146 && Oid <= 1159 )
						break;
				} else if ( strcmp(Object, "WANCommonInterfaceConfig") == 0 ) {
					if ( Oid >= 1226 && Oid <= 1241 )
						break;
				} else if ( strcmp(Object, "WANDSLConnectionManagement") == 0 ) {
					if ( Oid >= 1364 && Oid <= 1372 )
						break;
				} else if ( strcmp(Object, "WANDSLDiagnostics") == 0 ) {
					if ( Oid >= 1373 && Oid <= 1384 )
						break;
				} else if ( strcmp(Object, "WANDSLLinkConfig") == 0 ) {
					if ( Oid >= 1388 && Oid <= 1407 )
						break;
				} else if ( strcmp(Object, "WANDSLInterfaceConfig") == 0 ) {
					if ( Oid >= 1242 && Oid <= 1272 )
						break;
				} else if ( strcmp(Object, "WANEthernetLinkConfig") == 0 ) {
					if ( Oid >= 1417 && Oid <= 1418 )
						break;
				} else if ( strcmp(Object, "WANIPConnection") == 0 ) {
					if ( Oid >= 1432 && Oid <= 1466 )
						break;
				} else if ( strcmp(Object, "WANPPPConnection") == 0 ) {
					if ( (Oid >= 1472 && Oid <= 1508) || (Oid >= 1459 && Oid <= 1466) )
						break;
				}
				else if ( strcmp(Object, "WLANConfiguration") == 0 ) {
					if (Oid >= 4000 && Oid <= 4096)
						break;
            			}
            			else {
               Oid = 0;
					continue;
				}

               Oid = 0;
			} // End of inner if()
               Oid = 0;
		} // End of outer if()
	} // End of while loop
   fclose(fp);
	return Oid;
} // End of GetOid()


char *Param2OidConvertion ( char	*FinalOidStr,
							char	*Parameters,
							char	*dbfilename,
							char	*Object )
{


	char 				*pSubString[PTRSIZE1], OidStr[STRSIZE] ;
	unsigned short int	i = 0, oid = 0 ;


	if ( strcasecmp(Parameters, " ") == 0 || strcasecmp(Parameters, "1") == 0 || strcasecmp(Parameters, "0") == 0) {
		return Parameters;
	}

	pSubString[i] = strtok(Parameters, ",");
	if ( strstr(pSubString[i], "(" ) != NULL ) {
		strcpy(FinalOidStr, pSubString[i]);
	} else {
		oid = GetOid(Object, pSubString[i], dbfilename) ;
		if (oid) { sprintf (OidStr, "-%d", oid); }
		else { sprintf (OidStr, " "); 
		}
		strcpy(FinalOidStr, OidStr);
	}
	for ( i = 1; (pSubString[i]=strtok(NULL, ",")) != NULL ; i++ ) {
		if ( strstr(pSubString[i], "(" ) != NULL ) {
			if (oid) { strcat(FinalOidStr, ","); }
			strcat(FinalOidStr, pSubString[i]);
		} else {
			oid = GetOid(Object, pSubString[i], dbfilename) ;
			//sprintf (OidStr, ",-%d", GetOid(Object, pSubString[i], dbfilename));
			if (oid) { sprintf (OidStr, ",-%d", oid); 
}
			else { 
			//	sprintf (OidStr, ""); 
			OidStr[0] ='\0'; 
			}
			
			strcat(FinalOidStr, OidStr);
		}
    }

	return FinalOidStr;


} // End of Param2OidConvertion()
