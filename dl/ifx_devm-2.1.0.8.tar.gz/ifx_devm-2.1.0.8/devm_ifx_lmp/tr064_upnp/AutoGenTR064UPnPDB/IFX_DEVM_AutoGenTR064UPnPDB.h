#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXLINE 	1028
#define PTRSIZE 	10
#define PTRSIZE1 	50
#define STRSIZE 	84
#define TAGSIZE         90


/*  Function Declarations */
unsigned short int GetOid ( char 	*Object, char	*Parameter, char	*dbfilename );
char *Param2OidConvertion ( char	*FinalOidStr, char	*Parameters, char	*dbfilename, char    *Object );

