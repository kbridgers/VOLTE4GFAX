
/*
** =============================================================================
** FILE NAME     : IFX_TR64_Mgmt.c
** PROJECT       : TR64
** MODULES       : TR64 Management Layer
** DATE          : 10-Apr-2007
** AUTHOR        : TR69 team
** DESCRIPTION   : This implements the TR64 Management Layer. It interfaces with
**                 the TR64 database to handle requests made by TR64 SOAP layer.
**                 It forwards the requests to TR64 Adaptation layer.
** REFERENCES    : DDD-TR64.doc
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author      $Comment
** 10-Apr-2007 TR69 team    Initial Version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/

/** For type compatibility in uuid.h ***/
//#define unsigned32 uint32
//#define unsigned16 uint16
//#define unsigned8  uchar8
//#define byte       uchar8

//#include <sys/types.h>
#include "sysdep.h"
#include "IFX_DEVM_TR064UPnP.h"
  /* Required for Debug API */
#include "IFX_DEVM_Error.h"
#include "uuid.h"
#include "IFX_DEVM_Platform.h"
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_AdaptCommon.h"
 
 
#include "IFX_DEVM_StackUtil.h"
#include "IFX_DEVM_DS.h"

#ifndef MIPSTARGET
#ifdef LOCK_FILE_NAME
#undef LOCK_FILE_NAME
#endif
#define LOCK_FILE_NAME "lock.txt"
#endif

extern char uuidvalue[];
extern int32 IFX_ContSetActivate();

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;
static uint16 guiTimeOutId=0;
static uint32 suiSessionState=TR64_SESSION_STATE_INACTIVE;
static char8 sTMLSessionID[IFX_TR64_MAX_SESSION_ID_LEN];
static uint32 suiRetStatus=0;
static uint32 guiChangeFlag=0;
/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS>
**
** =============================================================================
*/

static IFX_SYS_TO_TR64_ERRORMAP axSysToTr64ErrMap[IFX_TR64_MAX_SYS_TR64_MAP]={
				{ERR_CWMP_OBJ_NOT_SUPPORTED, IFX_TR64_ERR_INVALID_ACTION},
				{ERR_INVAL_OBJ,IFX_TR64_ERR_INVALID_ACTION },
				{ERR_CWMP_METHOD_NOT_SUPPORTED,IFX_TR64_ERR_INVALID_ACTION},
				{ERR_CWMP_INVAL_ARGS,IFX_TR64_ERR_INVALID_ARGS},
				{ERR_CWMP_INVAL_INPUT_PARAM,IFX_TR64_ERR_INVALID_ARGS},
				{ERR_CWMP_PARAM_NOT_SUPPORTED,IFX_TR64_ERR_INVALID_ARGS},
				{ERR_CWMP_INVAL_PARAM_NAME,IFX_TR64_ERR_INVALID_ARGS},
				{ERR_CWMP_INVAL_OPER,IFX_TR64_ERR_ACTION_FAILED},
				{ERR_CWMP_INTERNAL,IFX_TR64_ERR_ACTION_FAILED},
				{ERR_CWMP_INVAL_PARAM_VAL,IFX_TR64_ERR_INVAL_PARAM_VAL},
				{ERR_OUT_OF_MEMORY,IFX_TR64_ERR_OUT_OF_MEMORY},
				{ERR_RESOURCE_EXCEEDED,IFX_TR64_ERR_OUT_OF_MEMORY}
				};

static IFX_TR64_ERRCODE_MAPTO_ERRSTRING axTr64ErrMapToString[IFX_TR64_MAX_ERR_STRING_MAP]={
				{IFX_TR64_ERR_INVALID_ACTION,"Invalid Action"},
				{IFX_TR64_ERR_INVALID_ARGS,"Invalid Args"},
				{IFX_TR64_ERR_ACTION_FAILED,"Action Failed"},
				{IFX_TR64_ERR_INVAL_PARAM_VAL,"Argument Value Invalid"},
				{IFX_TR64_ERR_OUT_OF_MEMORY,"Out of Memory"},
				{IFX_TR64_ERR_ACTION_NOTAUTHORIZED,"Action Not Authorized"},
				{IFX_TR64_ERR_WRITEACESS_DISABLED,"WriteAccessDisabled"},
				{IFX_TR64_ERR_SESS_ID_EXPIRED,"SessionIDExpired"},
				{IFX_TR64_ERR_DUP_ENTRY,"ConflictInMappingEntry"},
				{IFX_TR64_ERR_VAL_SPECIFIED_INVAL,"ValueSpecifiedIsInvalid"},
				{IFX_TR64_ERR_ARR_INDX_INVAL,"SpecifiedArrayIndexInvalid"},
				{IFX_TR64_ERR_NO_ENTRY_INARR,"NoSuchEntryInArray"},
				{IFX_TR64_ERR_INVAL_SERVICEID,"InvalidServiceID"}
				};


static IFX_TR64_StateArgMap axStateArgMap[IFX_TR64_MAX_STATE_ARG_MAP_ELEM]={
{"GetGenericPortMappingEntry","PortMappingNumberOfEntries","PortMappingIndex"},
{"GetGenericPortMappingEntry","PortMappingEnabled","Enabled"},
{"GetGenericPortMappingEntry","PortMappingProtocol","Protocol"},
{"GetGenericPortMappingEntry","PortMappingLeaseDuration","LeaseDuration"},
{"GetSpecificPortMappingEntry","PortMappingProtocol","Protocol"},
{"GetSpecificPortMappingEntry","PortMappingEnabled","Enabled"},
{"GetSpecificPortMappingEntry","PortMappingLeaseDuration","LeaseDuration"},
{"AddPortMapping","PortMappingProtocol","Protocol"},
{"AddPortMapping","PortMappingEnabled","Enabled"},
{"AddPortMapping","PortMappingLeaseDuration","LeaseDuration"},
{"DeletePortMapping","PortMappingProtocol","Protocol"},
{"SetConfigPassword","ConfigPassword","Password"},
{"GetGenericForwardingEntry","ForwardNumberOfEntries","ForwardingIndex"},
{"SetIPInterface","IPInterfaceIPAddress","IPAddress"},
{"SetIPInterface","IPInterfaceSubnetMask","SubnetMask"},
{"SetIPInterface","IPInterfaceAddressingType","IPAddressingType"},
{"AddIPInterface","IPInterfaceIPAddress","IPAddress"},
{"AddIPInterface","IPInterfaceSubnetMask","SubnetMask"},
{"AddIPInterface","IPInterfaceAddressingType","IPAddressingType"},
{"GetIPInterfaceSpecificEntry","IPInterfaceIPAddress","IPAddress"},
{"GetIPInterfaceSpecificEntry","IPInterfaceSubnetMask","SubnetMask"},
{"GetIPInterfaceSpecificEntry","IPInterfaceAddressingType","IPAddressingType"},
{"GetIPInterfaceGenericEntry","IPInterfaceIPAddress","IPAddress"},
{"GetIPInterfaceGenericEntry","IPInterfaceSubnetMask","SubnetMask"},
{"GetIPInterfaceGenericEntry","IPInterfaceAddressingType","IPAddressingType"},
{"GetIPInterfaceGenericEntry","IPInterfaceNumberOfEntries","IPInterfaceIndex"},
{"DeleteIPinterface","IPInterfaceIPAddress","IPAddress"},

#ifdef IFX_TR69_WIFILAN
{"SetDefaultWEPKeyIndex","WEPKeyIndex","DefaultWEPKeyIndex"},
{"GetDefaultWEPKeyIndex","WEPKeyIndex","DefaultWEPKeyIndex"},
#endif

{"DeleteIPinterface","IPInterfaceSubnetMask","SubnetMask"},
{"SetUserName","Username","UserName"}
};

#ifdef IFX_TR69_WIFILAN
static int ishexdigit(char c)
{
if (isdigit(c)||(c>='A'&& c<='F')||(c>='a'&& c<='f'))
return 1;
else
return 0;
}
#endif

static int32
IFX_TR64_ErrorMap(IFX_TR64_Response *pxRes)
{
  //Error Map takes tr69 error codes as input
  //Maps tr69 error code to tr64 error code
  //Copies the corresponding error string

   uint32 i=0;

   for(i=0;i<IFX_TR64_MAX_SYS_TR64_MAP;i++)
   {

   	if(pxRes->iStatus == axSysToTr64ErrMap[i].iSysErrCode)
	{
	  pxRes->iStatus = axSysToTr64ErrMap[i].iTr64ErrCode;
	  break;

	}
   }

  for(i=0;i<IFX_TR64_MAX_ERR_STRING_MAP;i++)
     {

          if(pxRes->iStatus == axTr64ErrMapToString[i].iTr64ErrCode)
          {
            strcpy(pxRes->sErrorString,axTr64ErrMapToString[i].sTR64ErrString);
	    break;

          }
     }


   return IFX_CWMP_SUCCESS;

}

	static int32
IFX_GetServiceIDFromUuidUrnTuple(char8 *sUuidUrn, char8 *sServiceId)
{
	// Grep the ServiceId from the UuidUrn
	// Copy to the sServiceId

	char8 *sTmp=NULL;
	//char8 sTmpUuidUrn[IFX_TR64_MAX_UUID_URN_LEN]={0};

	//strcpy(sTmpUuidUrn,sUuidUrn);

        //sTmp = strtok(sTmpUuidUrn,"serviceId:");
	//sTmp = strtok(NULL,"\n");
	sTmp = strrchr(sUuidUrn,':');
	if(sTmp == NULL)
		return IFX_CWMP_FAILURE;
	sTmp++;

	if(sTmp != NULL) {
	   strcpy(sServiceId,sTmp);
	} else {
	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Invalid UuidUrn = %s\n",
			 __func__, __LINE__,sUuidUrn);
          	return IFX_TR64_ERR_INVAL_SERVICEID;
	}

	return IFX_CWMP_SUCCESS;

}

static int32
IFX_FormUuidUrnTuple(char8 *sUuid, char8 *sDeviceType, char8 *sServiceId, char8 *sUuuidUrnTuple)
{

	//Create a New UUID
	//Create a URN with the ServiceID
	//Strcat UUID and URN and Copy to the SBuf

      /*uuid_upnp xUid;
	char sUuidStr[IFX_TR64_MAX_UUID_STR_LEN];
	char sBuf[IFX_TR64_MAX_UUID_STR_LEN];
	int32 iRet=IFX_CWMP_SUCCESS;
	*/

	/* iRet = uuid_create(&xUid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto ErrorHandler;
	uuid_unpack(&xUid,sUuidStr);
	sprintf(sBuf,"%s:%s","uuid:",sUuidStr);
	*/

	if((sUuid ==NULL) || (sDeviceType == NULL) || (sServiceId == NULL))
	return IFX_CWMP_FAILURE;
	else
	sprintf(sUuuidUrnTuple,"%s:%s:1,urn:upnporg:serviceId:%s",sUuid,sDeviceType,sServiceId);

	return IFX_CWMP_SUCCESS;

	/*ErrorHandler:
		return IFX_CWMP_FAILURE;
	*/
}

static int32
IFX_GetTR69IdFromServiceId(char8 *sServiceID,int32 *aiTR69_OID)
{
	//Get the tr69Id dotted form from ServiceId
	//Convert the TR69Id from dotted form into int array form
	IFX_Id xIfxId;
	char8 *psTok=NULL;
	char8 *psTmp=NULL;
	uint32 iJ=0;
	char8 sTmpServiceId[IFX_TR64_MAX_SERVICEID_LEN]={0};
	int32 iRet=IFX_CWMP_SUCCESS;

	    strcpy(sTmpServiceId,sServiceID);
	    memset(&xIfxId,'\0',sizeof(xIfxId));


            psTmp = strtok(sTmpServiceId,"-");
	    if(psTmp != NULL)  {
	    	strcpy(xIfxId.xCpeId.sSectionTag,psTmp);
	    } else {
	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	" Invalid Service Id = %s\n",
			 __func__, __LINE__,sServiceID);
	       goto ErrorHandler;
	    }
	    psTmp = strtok(NULL,"\n");
	    if(psTmp != NULL){
	    	xIfxId.xCpeId.uiId = atoi(psTmp);
	    } else {
	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	" Invalid Service Id = %s\n",
			 __func__, __LINE__,sServiceID);
		goto ErrorHandler;
	    }
            /* get the TR69 ID */
            iRet = IFX_GetTr69IdFromCpeId(&xIfxId);
	    if(iRet != IFX_CWMP_SUCCESS) {
	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	" Invalid Service Id = %s\n",
			 __func__, __LINE__,sServiceID);
		goto ErrorHandler;
	    }

	    psTok = strtok(xIfxId.sTr69Id, IFX_TR64_TR69OID_SEP);
	    if(psTok != NULL)
            	aiTR69_OID[0] = atoi(psTok);

            for(iJ = 1; iJ < OID_LENGTH; iJ++) {
                if((psTok = strtok(NULL,IFX_TR64_TR69OID_SEP)) == NULL)
                    break;
                aiTR69_OID[iJ] = atoi(psTok);
            }
	return IFX_CWMP_SUCCESS;

	ErrorHandler:
	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	" Getting TR69 id failed \n",
			 __func__, __LINE__);
		return IFX_CWMP_FAILURE;

}

static int32
IFX_GetServiceIdFromTR69Id(int32 *aiTR69_OID,char8 *sServiceId)
{
	//Convert the int array form into dotted form
	//Get the serviceId from the tr69id
	int32 iRet=IFX_CWMP_SUCCESS;
	char8 psOid_str[IFX_TR69_MAX_OID_STR_LEN]={0};
	uint32 puiNumCpeId=0;
	int32 *aiTmpOID=NULL;
 	IFX_CpeId *pxCpeIdArray=NULL;

        aiTmpOID=aiTR69_OID;
	    while(*aiTmpOID !=0)
	        aiTmpOID++;
#ifdef IFX_TR69_ADSLWAN
       *aiTmpOID = OID_IGD_WAND_WANCD_WANDSLLC;
#endif

	iRet = IFX_ConvertOidDottedForm(aiTR69_OID,psOid_str);
	if(iRet != IFX_CWMP_SUCCESS) {
	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Invalid TR69 ID\n",
			 __func__, __LINE__);
		goto ErrorHandler;
	}

       *aiTmpOID = 0;

	iRet = IFX_GetCpeIdFromTr69Id(psOid_str,&puiNumCpeId, &pxCpeIdArray);
	if(iRet != IFX_CWMP_SUCCESS) {
	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	" Invalid TR69 ID =%s \n",
			 __func__, __LINE__,psOid_str);
		goto ErrorHandler;
	}
	if(puiNumCpeId > 0 ) {
		sprintf(sServiceId,"%s-%d",pxCpeIdArray[0].sSectionTag,pxCpeIdArray[0].uiId);
	} else {
	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	" No Cpeid available for TR69 ID =%s \n",
			 __func__, __LINE__,psOid_str);
		iRet = IFX_CWMP_FAILURE;
		goto ErrorHandler;
	}

	IFIN_CWMP_FREE(pxCpeIdArray);
	return IFX_CWMP_SUCCESS;

	ErrorHandler:
	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Getting Service Id failed\n",
			 __func__, __LINE__);
		IFIN_CWMP_FREE(pxCpeIdArray);
		return IFX_CWMP_FAILURE;
}


/*
** =============================================================================
**   Function Name    :
**
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**
**   Notes            :
**
** ============================================================================
*/
static int32
IFX_TR64_ParseDB(IN char8 *ServiceObj, IN char8 *sActionName,IN uint32 uiParamPos,
						IN uint32 uiNoElements,OUT int32 *paiElementIDs)
{

	uint32 uiflags=IFX_F_GET_ANY;
	uint32 uiOutFlag=0;
	char8 sVal[IFX_TR64_MAX_COLUMN_VALUE_LEN]={ 0 };
	char8 sColumnValue[IFX_TR64_MAX_COLUMN_VALUE_LEN]={ 0 };
	char8 *sTempColVal=NULL;
	char8 *sElemId=NULL;
	uint32 i=0;
	uint32 iRet=IFX_CWMP_SUCCESS;
	char8 *psColTmp=NULL;
	char8 *psElemTmp=NULL;

	//Using GetCfgData get the value
	 memset(sVal, 0x00, sizeof(sVal));
	    if ((iRet = ifx_GetObjData(FILE_TR64_DB, ServiceObj, sActionName,
	        			uiflags, &uiOutFlag, sVal)) != IFX_SUCCESS)
	    {
	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	" Failed to get line related to ServiceObj =%s Action=%s from tr64_db\n",
			 __func__, __LINE__,ServiceObj,sActionName);
		iRet = IFX_CWMP_FAILURE;
	        goto ErrHandler;
	    }

//	memset(sColumnValue,'\0',IFX_TR64_MAX_COLUMN_VALUE_LEN);
	sTempColVal = strtok_r(sVal, "~\n",&psColTmp);

	//With uiParamPos get the exact position of column
	for(i=0;i<IFX_TR64_DB_MAX_NO_COLUMN;i++) {

		if( (i+1) == uiParamPos) {
			if(sTempColVal != NULL) {
				strcpy(sColumnValue,sTempColVal);
				break;
			}

		} else {
				sTempColVal = strtok_r(NULL, "~\n",&psColTmp);
			}
	}

	if(strcmp(sColumnValue," ") != 0) {

		sElemId = strtok_r(sColumnValue, ",\n",&psElemTmp);

		for(i=0;i<uiNoElements;i++) {

			if(sElemId != NULL) {
		 		paiElementIDs[i] = atoi(sElemId);
				sElemId = strtok_r(NULL, ",\n",&psElemTmp);
			} else {
				break;
			}

		}
	}

	return IFX_CWMP_SUCCESS;


	ErrHandler:
	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	" Failed to get line from tr64_db \n",
			 __func__, __LINE__);

		return iRet;


}

int32
IFX_CheckIfPasswordProtectAction(IN char8 *sServiceId,IN char8 *sAction,OUT int32 *uiAuth)
{
	//Grep the Password column
	//If it contains 1 then return SUCCESS else failure
	int32 iRet=IFX_CWMP_SUCCESS;
	int32 aiOID[OID_LENGTH]={0};
	char8 sTR69Name[IFX_TR64_MAX_PARAM_NAME_LEN]={0};
	char8 sServiceObj[IFX_TR64_MAX_OBJ_LEN]={0};
	char8 *psTmp=NULL;
	uint32 iI=0;

//	memset(aiOID,'\0',sizeof(int32)*OID_LENGTH);

	if((strcmp(sServiceId,IFX_TR64_DEVICECONFIG_SERVICEID) != 0) &&
	  (strcmp(sServiceId,IFX_TR64_WANDSLCONNECTIONMANAGEMENT_SERVICEID) != 0)) {

		//From ServiceId get the TR69OID
		iRet = IFX_GetTR69IdFromServiceId(sServiceId,aiOID);
   		if(iRet != IFX_CWMP_SUCCESS) {

		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d ServiceId=%s"
                        "Invalid ServiceId\n",
                        __func__, __LINE__,sServiceId);
		goto ErrorHandler;
	 	}

		while(aiOID[iI] != 0)
    		{
        		iI++;
    		}

    		if (aiOID[iI-1] > 0)
    		{
        		aiOID[iI-1] = 0;
    		}

		//From TR69OID get the TR69 Name
		iRet = IFX_GlobalNameOidConversion(sTR69Name, aiOID);
   		if(iRet != IFX_CWMP_SUCCESS) {

		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d"
                        "Invalid TR69Id\n",
                        __func__, __LINE__);
		goto ErrorHandler;
		}
		//From TR69 Name get the sServiceObj
	    	sTR69Name[strlen(sTR69Name)-1] = '\0';
    		psTmp = strrchr(sTR69Name,'.');
	    	strcpy(sServiceObj, psTmp+1);
	} else {

		if(strcmp(sServiceId,IFX_TR64_DEVICECONFIG_SERVICEID) != 0) {
	 		strcpy(sServiceObj,"WANDSLConnectionManagement");
 		} else {
			strcpy(sServiceObj,"DeviceConfig");
		}
	}
	iRet = IFX_TR64_ParseDB(sServiceObj, sAction, IFX_TR64_AUTH_POS,1, uiAuth);
   	if(iRet != IFX_CWMP_SUCCESS){

		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d ServiceObj=%s ActionName=%s "
                        "Invalid ServiceObj/ActionName pair - Not Present in tr64_db\n",
                        __func__, __LINE__,sServiceObj,sAction);
		goto ErrorHandler;
	}

	return IFX_CWMP_SUCCESS;

	ErrorHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d"
                        "Get Auth info failed\n",
                        __func__, __LINE__);
		return iRet;

}


/*
** =============================================================================
**   Function Name    :
**
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**
**   Notes            :
**
** ============================================================================
*/

void
IFX_TR64_TimerCB(int32 iReason)
{
    //uint32 uiFlags=0;

    switch (iReason) {
        case IFX_TR64_SESSION_TIMEOUT_ID:
            guiTimeOutId = 0;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s:%d [%d] "
                        "Closing connection Timer\n",
                        __func__, __LINE__, guiTimeOutId);

		memset(sTMLSessionID,'\0',IFX_TR64_MAX_SESSION_ID_LEN);
		suiSessionState = TR64_SESSION_STATE_INACTIVE;

		if(guiChangeFlag == IFX_TR64_CHANGE_FLAG_SET) {
		/*
		 iRet = IFX_Config_Save();
	  	 if(iRet != IFX_CWMP_SUCCESS) {
			        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Failed to "
			                    "write rc.conf to flash \n", __func__, __LINE__, iRet);
		 }
		*/

		 }
		  guiChangeFlag = IFX_TR64_CHANGE_FLAG_RESET;
            break;
        default:
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:default case. TimerId=%d\n", __func__, iReason);
            break;
    }
}

/*
** =============================================================================
**   Function Name    :
**
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**
**   Notes            :
**
** ============================================================================
*/

static void
IFX_TR64_StartTimer(int32 iSecs, int32 iID)
{
    uint32 uiErr;
    if(guiTimeOutId != 0) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "Error !! Timer Id=%d already running\n", iID);
        // exit(EXIT_FAILURE);
    }

    if(iID == IFX_TR64_SESSION_TIMEOUT_ID) {
        if(IFIN_TR69_StartTimer(iSecs, (void *)IFX_TR64_TimerCB,
                                (void *)iID, &guiTimeOutId, &uiErr) != 0) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "Error starting msg timeout timer\n");
        } else {
    	    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "Started Msg Timer Id=%d\n",
                guiTimeOutId);
	}
    }
}

/*
** =============================================================================
**   Function Name    :
**
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**
**   Notes            :
**
** ============================================================================
*/

void
IFX_TR64_CancelTimer(int32 iID)
{
    if(guiTimeOutId == 0) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d Error: No timer running\n", __func__, __LINE__);
        // exit(EXIT_FAILURE);
    }

    if(iID == IFX_TR64_SESSION_TIMEOUT_ID) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "Cancelling Timer %d\n",
                    guiTimeOutId);
        if(guiTimeOutId && (IFIN_TR69_StopTimer(guiTimeOutId) != 0))
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "Error stopping msg timeout timer=%d\n", guiTimeOutId);
    } else {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:Unknown timerId=%d\n",
                    __func__, iID);
    }
    guiTimeOutId = 0;
}




int32 IFX_TR64_GenUUID(IN uint32 uiCpied, IN char8 *psName,OUT char8 *psUUID)
{

	char8 sTmp[IFX_TR64_MAX_CPEID_CHARS+1]={0};
	char8 *psUuidPos=NULL;
	uint32 uiUuidLen=0;
	int uiCpeid_len = 0;
	char8 *new = NULL;
	char8 sDevName[30] = {0};

//	memset(sTmp,'\0',IFX_TR64_MAX_CPEID_CHARS);
	sprintf(sTmp,"%d",uiCpied);
	if(psUUID == NULL)
	  return IFX_CWMP_FAILURE;

	// put device name
	psUuidPos = psUUID + 5;
	strncpy(sDevName, psName, sizeof(sDevName) -1);
	new = strchr(sDevName,'-');
	if(new != NULL){
		*new = '\0';
	}

	if((!strcmp(sDevName,"wan_device")) || (!strcmp(sDevName,"WANDevice")))
		strcpy(sDevName,"ddd");
	else if((!strcmp(sDevName,"wan_conndev"))||(!strcmp(sDevName,"WANConnectionDevice")))
		strcpy(sDevName,"ccc");
	else if((!strcmp(sDevName,"land"))||(!strcmp(sDevName,"LANDevice")))
		strcpy(sDevName,"bbb");
	else if((!strcmp(sDevName,"igd")) || (!strcmp(sDevName,"InternetGatewayDevice")))
		strcpy(sDevName,"aaa");


	new = sDevName;
	while( *new != '\0'){
		*psUuidPos = *new;
		psUuidPos++;
                new++;
	}

	// put cp3eid
	uiUuidLen = strlen(psUUID);
	if(uiUuidLen <= IFX_TR64_MAX_CPEID_CHARS)
		return IFX_CWMP_FAILURE;

	psUuidPos = psUUID;
	//memset(psUuidPos,'0', 8);
	uiCpeid_len = strlen(sTmp);

	psUuidPos = (psUUID + 13) - (uiCpeid_len);
	new = sTmp;
	while( *new != '\0'){
		*psUuidPos = *new;
		psUuidPos++;
		new++;
	}
	return IFX_CWMP_SUCCESS;
}

int32 IFX_TR64_GetCpeidFromUUID(IN char8 *psUUID, OUT uint32 *puiCPEId,OUT char8 *psName)
{

	char8 *psUuidPos=NULL;
	if((psUUID == NULL) || (strlen(psUUID) <= IFX_TR64_MAX_CPEID_CHARS))
		return IFX_CWMP_FAILURE;
	psUuidPos = psUUID + 10;
	*puiCPEId = atoi(psUuidPos);

	return IFX_CWMP_SUCCESS;

}


int32 IFX_TR64_FwdRevMapArg(IN uint32 uiDir,IN char8 *psAction,INOUT IFX_TR64_NameValue *pxNameVal,
										IN uint32 uiNoElems)
{

	char8 sTmpBuff[IFX_TR64_MAX_PARAM_NAME_LEN]={0};
	uint32 i=0;
	int32 iRet = IFX_CWMP_SUCCESS;

	if(psAction ==NULL){
		iRet = IFX_CWMP_FAILURE;
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Forward/Reverse mapping args failed\n",
                        __func__, __LINE__);
		goto ErrorHandler;
	}
	if(pxNameVal ==NULL)
		return IFX_CWMP_SUCCESS;

	for(i=0; i < uiNoElems; i++) {

	memset(sTmpBuff,'\0',IFX_TR64_MAX_PARAM_NAME_LEN);

	if(uiDir == IFX_TR64_ARG_FWD_MAP) {
		iRet = IFX_TR64_MapStateArgName(psAction,sTmpBuff,pxNameVal[i].sName);
	} else {
		iRet = IFX_TR64_MapStateArgName(psAction,pxNameVal[i].sName,sTmpBuff);
	}
	if(iRet != IFX_CWMP_SUCCESS)
	 	goto ErrorHandler;

	strcpy(pxNameVal[i].sName, sTmpBuff);
	}

	return IFX_CWMP_SUCCESS;

	ErrorHandler:
		if(uiDir == IFX_TR64_ARG_FWD_MAP) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d ArgName=%s ActionName=%s "
                        "Forward mapping args failed\n",
                        __func__, __LINE__,pxNameVal[i].sName,psAction);
		} else {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d StateVarName=%s ActionName=%s "
                        "Reverse mapping StateVar failed\n",
                        __func__, __LINE__,pxNameVal[i].sName,psAction);

		}
		return iRet;


}


int32 IFX_TR64_MapStateArgName(IN char8 *psAction, INOUT char8 *psStateVar, INOUT char8 *psArgName)
{
	//axStateArgMap
	uint32 i=0;
	uint32 uiGotVal=0;

	if(strcmp(psStateVar,"")==0) {

	   for(i=0; i < IFX_TR64_MAX_STATE_ARG_MAP_ELEM;i++) {
		if((strcmp(axStateArgMap[i].sActionName,psAction) == 0) &&
		  (strcmp(axStateArgMap[i].sArgName,psArgName)==0)) {
		     strcpy(psStateVar,axStateArgMap[i].sStateVarName);
		     uiGotVal=1;
		     break;
		  }

	   }

	} else {

	   for(i=0; i < IFX_TR64_MAX_STATE_ARG_MAP_ELEM;i++) {
		if((strcmp(axStateArgMap[i].sActionName,psAction) == 0) &&
		  (strcmp(axStateArgMap[i].sStateVarName,psStateVar)==0)) {
		     strcpy(psArgName,axStateArgMap[i].sArgName);
		     uiGotVal=1;
		     break;
		  }

	   }


	}

	if((uiGotVal==0)&&(strcmp(psArgName,"")==0)) {
		strcpy(psArgName,psStateVar);
 	} else if ((uiGotVal==0)&&(strcmp(psStateVar,"")==0)) {
		strcpy(psStateVar,psArgName);
	}

	return IFX_CWMP_SUCCESS;

}


int32 IFX_TR64_TMLActionListGet(IN char8 sServiceObj[IFX_TR64_MAX_OBJ_LEN],
                                IN int32 iaOID[OID_LENGTH],
                                OUT IFX_TR64_Action **ppxAction,
                                OUT uint32 *puiNumAction,
                                OUT int32 *piOID)
{

	char8 *psObjBuff=NULL;
	uint32 uiStateFlag=IFX_F_GET_ANY;
	char8 *psTmpBuf=NULL;
	char8 sTmpbuff[IFX_TR64_DB_LINE_LEN]={0};
	char8 *psLineBuf=NULL;
	int32 iaOIDOutParam[IFX_TR64_MAX_OUTPUT_PARAMS]={0};
	int32 iaOIDInParam[IFX_TR64_MAX_INPUT_PARAMS]={0};
	char8 *psParamName=NULL;
	int32 iRet = IFX_CWMP_SUCCESS;
	IFX_PARAMNAME_OID_PAIR *paxParamOidArr=NULL;
	IFX_PARAMNAME_OID_PAIR *paxSubParamOidArr=NULL;
	int32 uiNoParams=0;
	int32 uiNoSubParams=0;
	int32  iChildOID=0;
	int32 iParamPos=0;
	uint32 uiGotChildObj=0;
	int32 uiNoofInElems=0;
	int32 uiNoofOutElems=0;
	uint32 Ii=0,j=0,k=0,m=0,n=0;
	char8  *psName=NULL;
	IFX_TR64_Action *pxTmpAction=NULL;
	int32 *pTmpOIDInParam=NULL;
        char fmt_str[20] = {0};

	//Based on ServiceObj Get the Action List
	//Based on ServiceObj and Action get the IN & OUT ParamOIDs
	//Get All parameters for the Object from DS
	//Compare the OIDs from tr64db with the list from DS
		//If it matches fill parameter Name in arguments and StateVariable.
	//For Failed OIDs
		// attach the child Obj OID
		// Get All parameters for the Object from DS
		// Get the Exact Parameter Name of Failed OIDs
		// Fill in both Argument and RelatedStateVariable
		// Parse the tr64_Var_map array and fill the tr64 arguments


	//Get the ActionList from DB
	iRet = ifx_GetCfgObject(FILE_TR64_DB,sServiceObj, NULL,
                            uiStateFlag, &psObjBuff);
	if(iRet != IFX_SUCCESS){
	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	" Getting ActionList from DB failed ServiceObj =%s \n",
			 __func__, __LINE__,sServiceObj);
		goto ErrorHandler;
	 }

	//Get the Prameters in that obj from the DS
	iRet = ifx_ds_get_objparameter(psParamName,iaOID,&uiNoParams,&paxParamOidArr);
	if(iRet != IFX_CWMP_SUCCESS) {

	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Getting Parameters from DS for this TR69_OID has failed \n",
			 __func__, __LINE__);
		IFX_PrintOID(iaOID);
		goto ErrorHandler;
	}
	//Get each action and corresponding IN & OUT params
	psTmpBuf = strtok_r(psObjBuff,"\n",&psLineBuf);

	while(psTmpBuf != NULL) {

	if(Ii == 0) {
	 pxTmpAction = IFIN_CWMP_MALLOC(sizeof(IFX_TR64_Action));
	} else {
	 pxTmpAction = IFIN_CWMP_REALLOC(*ppxAction,(Ii+1)*sizeof(IFX_TR64_Action));
	}

	if (pxTmpAction != NULL) {
		*ppxAction = pxTmpAction;
	} else {
	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	" MALLOC/REALLOC has failed \n",
			 __func__, __LINE__);
	    iRet = IFX_CWMP_FAILURE;
	    goto ErrorHandler;
	}
        sprintf(fmt_str, "%%%d[^=]%%s",(IFX_TR64_MAX_ACTION_LEN-1));
	//sscanf(psTmpBuf,"%[^=]%s",(*ppxAction +Ii)->sName,sTmpbuff);
	sscanf(psTmpBuf, fmt_str, (*ppxAction +Ii)->sName,sTmpbuff);

#ifdef IFX_TR69_WIFILAN
/* kamal: hack for Get and Set SecurityKeys */
    if(!strcmp(sServiceObj,"WLANConfiguration"))
    {
		if(!strcmp((*ppxAction +Ii)->sName,"GetSecurityKeys"))
		{
		    /*  Malloc pxArguments to 6 * sizeof IFX_TR64_Argument,
			 *  assign uiNumArgument = 6,
			 *  copy the argument names to ppxAction +Ii)->pxArgument[n].sStateVarName and 
			 *  (*ppxAction +Ii)->pxArgument[n].sName, 
			 *  copy (*ppxAction +Ii)->pxArgument[n].ucDirection = IFX_TR64_DIRECTION_OUT 
			 */  
	//	        IFX_API_LOG("sServiceObj:%s sName:%s\n",sServiceObj,(*ppxAction +Ii)->sName);	
          		
			(*ppxAction +Ii)->uiNumArgument = 6;
			(*ppxAction +Ii)->pxArgument = IFX_CWMP_MALLOC( 7 * sizeof(IFX_TR64_Argument));
			
			strcpy((*ppxAction +Ii)->pxArgument[0].sStateVarName,"WEPKey");
			strcpy((*ppxAction +Ii)->pxArgument[0].sName,"WEPKey0");
			(*ppxAction +Ii)->pxArgument[0].ucDirection = IFX_TR64_DIRECTION_OUT;

			strcpy((*ppxAction +Ii)->pxArgument[1].sStateVarName,"WEPKey");
			strcpy((*ppxAction +Ii)->pxArgument[1].sName,"WEPKey1");
			(*ppxAction +Ii)->pxArgument[1].ucDirection = IFX_TR64_DIRECTION_OUT;

			strcpy((*ppxAction +Ii)->pxArgument[2].sStateVarName,"WEPKey");
			strcpy((*ppxAction +Ii)->pxArgument[2].sName,"WEPKey2");
			(*ppxAction +Ii)->pxArgument[2].ucDirection = IFX_TR64_DIRECTION_OUT;

			strcpy((*ppxAction +Ii)->pxArgument[3].sStateVarName,"WEPKey");
			strcpy((*ppxAction +Ii)->pxArgument[3].sName,"WEPKey3");
			(*ppxAction +Ii)->pxArgument[3].ucDirection = IFX_TR64_DIRECTION_OUT;

			strcpy((*ppxAction +Ii)->pxArgument[4].sStateVarName,"PreSharedKey");
			strcpy((*ppxAction +Ii)->pxArgument[4].sName,"PreSharedKey");
			(*ppxAction +Ii)->pxArgument[4].ucDirection = IFX_TR64_DIRECTION_OUT;

			strcpy((*ppxAction +Ii)->pxArgument[5].sStateVarName,"KeyPassphrase");
			strcpy((*ppxAction +Ii)->pxArgument[5].sName,"KeyPassphrase");
			(*ppxAction +Ii)->pxArgument[5].ucDirection = IFX_TR64_DIRECTION_OUT;

			goto finish;
		}
		if(!strcmp((*ppxAction +Ii)->sName,"SetSecurityKeys"))
		{
          	(*ppxAction +Ii)->uiNumArgument = 6;
			(*ppxAction +Ii)->pxArgument = IFX_CWMP_MALLOC( 7 * sizeof(IFX_TR64_Argument));
			
			strcpy((*ppxAction +Ii)->pxArgument[0].sStateVarName,"WEPKey");
			strcpy((*ppxAction +Ii)->pxArgument[0].sName,"WEPKey0");
			(*ppxAction +Ii)->pxArgument[0].ucDirection = IFX_TR64_DIRECTION_IN;

			strcpy((*ppxAction +Ii)->pxArgument[1].sStateVarName,"WEPKey");
			strcpy((*ppxAction +Ii)->pxArgument[1].sName,"WEPKey1");
			(*ppxAction +Ii)->pxArgument[1].ucDirection = IFX_TR64_DIRECTION_IN;

			strcpy((*ppxAction +Ii)->pxArgument[2].sStateVarName,"WEPKey");
			strcpy((*ppxAction +Ii)->pxArgument[2].sName,"WEPKey2");
			(*ppxAction +Ii)->pxArgument[2].ucDirection = IFX_TR64_DIRECTION_IN;

			strcpy((*ppxAction +Ii)->pxArgument[3].sStateVarName,"WEPKey");
			strcpy((*ppxAction +Ii)->pxArgument[3].sName,"WEPKey3");
			(*ppxAction +Ii)->pxArgument[3].ucDirection = IFX_TR64_DIRECTION_IN;

			strcpy((*ppxAction +Ii)->pxArgument[4].sStateVarName,"PreSharedKey");
			strcpy((*ppxAction +Ii)->pxArgument[4].sName,"PreSharedKey");
			(*ppxAction +Ii)->pxArgument[4].ucDirection = IFX_TR64_DIRECTION_IN;

			strcpy((*ppxAction +Ii)->pxArgument[5].sStateVarName,"KeyPassphrase");
			strcpy((*ppxAction +Ii)->pxArgument[5].sName,"KeyPassphrase");
			(*ppxAction +Ii)->pxArgument[5].ucDirection = IFX_TR64_DIRECTION_IN;

			goto finish;
		}
    }
/* kamal end of hack */
#endif

	memset(iaOIDOutParam,'\0',IFX_TR64_MAX_OUTPUT_PARAMS*sizeof(int32));
	//Get the Input and Param OIDs from tr64_db
	iRet = IFX_TR64_ParseDB(sServiceObj,(*ppxAction +Ii)->sName, IFX_TR64_OUT_PARAM_POS,
						IFX_TR64_MAX_OUTPUT_PARAMS, iaOIDOutParam);
	if(iRet != IFX_CWMP_SUCCESS) {
	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	" Getting OUT params from DB failed for ServiceObj = %s Action = %s \n",
			 __func__, __LINE__,sServiceObj,(*ppxAction +Ii)->sName);
		goto ErrorHandler;
	}
	memset(iaOIDInParam,'\0',IFX_TR64_MAX_INPUT_PARAMS*sizeof(int32));
	iRet = IFX_TR64_ParseDB(sServiceObj, (*ppxAction +Ii)->sName, IFX_TR64_KEY_POS,
						IFX_TR64_MAX_INPUT_PARAMS, iaOIDInParam);
	if(iRet != IFX_CWMP_SUCCESS) {
	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	" Getting KEY params from DB failed for ServiceObj = %s Action = %s \n",
			 __func__, __LINE__,sServiceObj,(*ppxAction +Ii)->sName);
		goto ErrorHandler;
	}
	pTmpOIDInParam = iaOIDInParam + IFX_GetParamIdPos(iaOIDInParam)+1;
	iRet = IFX_TR64_ParseDB(sServiceObj, (*ppxAction +Ii)->sName, IFX_TR64_IN_PARAM_POS,
						IFX_TR64_MAX_INPUT_PARAMS, pTmpOIDInParam);
	if(iRet != IFX_CWMP_SUCCESS) {
	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	" Getting IN params from DB failed for ServiceObj = %s Action = %s \n",
			 __func__, __LINE__,sServiceObj,(*ppxAction +Ii)->sName);
		goto ErrorHandler;
	}

	//Get the ChildOID from tr64_db
	iRet = IFX_TR64_ParseDB(sServiceObj,(*ppxAction +Ii)->sName, IFX_TR64_CHLD_OID_POS,
									1, &iChildOID);
	if(iRet != IFX_CWMP_SUCCESS) {
	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	" Getting CHILD OID from DB failed for ServiceObj = %s Action = %s \n",
			 __func__, __LINE__,sServiceObj,(*ppxAction +Ii)->sName);
		goto ErrorHandler;
	}
	//Get the parameters of the Child Obj from the DS if ChildOID is present
	if((iChildOID < 0) && (uiGotChildObj == 0)) {
		iParamPos = IFX_GetParamIdPos(iaOID);
		if(iParamPos < 0 || iParamPos>=13) {
	       		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Invalid Param position \n", __func__, __LINE__);
			goto ErrorHandler;
		}
		iaOID[iParamPos+1] = iChildOID;
		iRet = ifx_ds_get_objparameter(psName,iaOID,&uiNoSubParams, &paxSubParamOidArr);
		if(iRet != IFX_CWMP_SUCCESS) {
	       		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Getting Parameters from DS for Child TR69_OID has failed \n",
			 __func__, __LINE__);
			IFX_PrintOID(iaOID);
			goto ErrorHandler;
		}
		uiGotChildObj = 1;
		iaOID[iParamPos+1] =0;
		*piOID=iChildOID;
	}


	//Find the no of ParamOIDs in IN & OUT and Allocate for argument struct
	if((uiNoofInElems = IFX_GetParamIdPos(iaOIDInParam))!= -1)
		uiNoofInElems++;
	else
		uiNoofInElems=0;

	if((uiNoofOutElems =  IFX_GetParamIdPos(iaOIDOutParam))!= -1)
		uiNoofOutElems++;
	else
		uiNoofOutElems=0;


	(*ppxAction +Ii)->uiNumArgument = uiNoofInElems + uiNoofOutElems;
	if ((uiNoofInElems + uiNoofOutElems) > 0) {
	(*ppxAction +Ii)->pxArgument = IFX_CWMP_MALLOC(((uiNoofInElems + uiNoofOutElems) * sizeof(IFX_TR64_Argument)));
	} else {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s:%d] No IN/OUT elem.\n", __func__, __LINE__);
		(*ppxAction +Ii)->pxArgument = NULL;
	}

	if(((uiNoofInElems + uiNoofOutElems) > 0) && ((*ppxAction +Ii)->pxArgument == NULL)) {

	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	" MALLOC has failed \n",
			 __func__, __LINE__);
			iRet = IFX_CWMP_FAILURE;
			goto ErrorHandler;
	}

	if ((uiNoofInElems + uiNoofOutElems) > 0)
        memset((*ppxAction +Ii)->pxArgument, '\0', ((uiNoofInElems + uiNoofOutElems) * sizeof(IFX_TR64_Argument)));
	//Compare IN&OUT param OIDs with the ParentObj Parameters got From DS if ChildObj OID is not present

	for(m=0; m < uiNoParams; m++) {

		for(k=0; k < uiNoofInElems; k++){

			if(paxParamOidArr[m].iOID == iaOIDInParam[k]) {
			 strncpy((*ppxAction +Ii)->pxArgument[n].sStateVarName,paxParamOidArr[m].sParamName, (sizeof((*ppxAction +Ii)->pxArgument[n].sStateVarName) - 1));
			 (*ppxAction +Ii)->pxArgument[n].ucDirection = IFX_TR64_DIRECTION_IN;
			 memset((*ppxAction +Ii)->pxArgument[n].sName,'\0',IFX_TR64_MAX_PARAM_NAME_LEN);
			 iRet =  IFX_TR64_MapStateArgName((*ppxAction +Ii)->sName,
							paxParamOidArr[m].sParamName,
							(*ppxAction +Ii)->pxArgument[n].sName);
			if(iRet != IFX_CWMP_SUCCESS)
				goto ErrorHandler;
			 n++;
			 break;
		 	}
		}
		for(j=0; j < uiNoofOutElems; j++){

			if(paxParamOidArr[m].iOID == iaOIDOutParam[j]) {
			 strncpy((*ppxAction +Ii)->pxArgument[n].sStateVarName,paxParamOidArr[m].sParamName,IFX_TR64_MAX_PARAM_NAME_LEN-1);
			 (*ppxAction +Ii)->pxArgument[n].ucDirection = IFX_TR64_DIRECTION_OUT;
			 memset((*ppxAction +Ii)->pxArgument[n].sName,'\0',IFX_TR64_MAX_PARAM_NAME_LEN);
			 iRet =  IFX_TR64_MapStateArgName((*ppxAction +Ii)->sName,
							paxParamOidArr[m].sParamName,
							(*ppxAction +Ii)->pxArgument[n].sName);

			if(iRet != IFX_CWMP_SUCCESS)
				goto ErrorHandler;
			 n++;
			 break;
		 	}

		}
			if(n >=  (uiNoofInElems + uiNoofOutElems))
			 break;
	}
	//Compare IN&OUT param OIDs with the ChildObj Parameters got From DS if ChildObj OID is present
	if (iChildOID < 0) {
	for(m=0; m < uiNoSubParams; m++) {

		for(k=0; k < uiNoofInElems; k++){

			if(paxSubParamOidArr[m].iOID == iaOIDInParam[k]) {
			 strncpy((*ppxAction +Ii)->pxArgument[n].sStateVarName,paxSubParamOidArr[m].sParamName, IFX_TR64_MAX_PARAM_NAME_LEN-1);
			 (*ppxAction +Ii)->pxArgument[n].ucDirection = IFX_TR64_DIRECTION_IN;
			 memset((*ppxAction +Ii)->pxArgument[n].sName,'\0',IFX_TR64_MAX_PARAM_NAME_LEN);
			 iRet =  IFX_TR64_MapStateArgName((*ppxAction +Ii)->sName,
							paxSubParamOidArr[m].sParamName,
							(*ppxAction +Ii)->pxArgument[n].sName);
			if(iRet != IFX_CWMP_SUCCESS)
				goto ErrorHandler;
			 n++;
			 break;
		 	}
		}
		for(j=0; j < uiNoofOutElems; j++){

			if(paxSubParamOidArr[m].iOID == iaOIDOutParam[j]) {
			 strncpy((*ppxAction +Ii)->pxArgument[n].sStateVarName,paxSubParamOidArr[m].sParamName, IFX_TR64_MAX_PARAM_NAME_LEN-1);
			 (*ppxAction +Ii)->pxArgument[n].ucDirection = IFX_TR64_DIRECTION_OUT;
			 memset((*ppxAction +Ii)->pxArgument[n].sName,'\0',IFX_TR64_MAX_PARAM_NAME_LEN);
			 iRet =  IFX_TR64_MapStateArgName((*ppxAction +Ii)->sName,
							paxSubParamOidArr[m].sParamName,
							(*ppxAction +Ii)->pxArgument[n].sName);
			if(iRet != IFX_CWMP_SUCCESS)
				goto ErrorHandler;
			 n++;
			 break;
		 	}

		}
			if(n >=  (uiNoofInElems + uiNoofOutElems))
			 break;

	 }
	 }

#ifdef IFX_TR69_WIFILAN
	 finish:
#endif

	 psTmpBuf = strtok_r(NULL,"\n",&psLineBuf);
	 Ii++;
	 n=0;

	} // End of Action list loop

	*puiNumAction = Ii;
	 IFX_CWMP_FREE(paxParamOidArr);
	 IFX_CWMP_FREE(paxSubParamOidArr);
	 IFX_CWMP_FREE(psObjBuff);
	return IFX_CWMP_SUCCESS;


	ErrorHandler:
	 IFX_CWMP_FREE(paxParamOidArr);
	 IFX_CWMP_FREE(paxSubParamOidArr);
	 IFX_CWMP_FREE(psObjBuff);
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	" Forming action list with args has failed \n",
			 __func__, __LINE__);
	 //return iRet;
	 return IFX_CWMP_FAILURE;

}

static int32
IFX_TR64_Close(IN IFX_TR64_Request *pxTR64Req,IN IFX_TR64_Response *pxTR64Resp)
{

	//Handle the Activate state
	if(suiRetStatus == IFX_CWMP_NEED_ACTIVATE)
	IFX_ContSetActivate();

	//Factory Reset RPC
    	if (pxTR64Req->ucOper == IFX_TR64_OPER_FACTORY_RESET)
    	{
        	IFX_Config_FactoryReset();
    	}

	//Reboot RPC
	//Reboot Required because of some Changes
    if ((pxTR64Req->ucOper == IFX_TR64_OPER_REBOOT) ||
	(suiRetStatus == IFX_CWMP_NEED_REBOOT))
    {
	IFX_Config_Save();
	IFX_Config_RebootSystem();
    }

	suiRetStatus = 0;
   	return IFX_CWMP_SUCCESS;

}



/*
** =============================================================================
**
**                             <GLOBAL VARIABLES>
**
** =============================================================================
*/

IFX_TR64_ActionS xaDCAction[] =
{
    {"FactoryReset", 0},
    {"Reboot", 0},
    {0, 0}
};

#ifdef IFX_TR69_IGD
IFX_TR64_StateVariableS xaWANDSLCMStateVariable[] =
{
    {"WANConnectionDevice", "s256", 0, {0}},
    {"WANConnectionService", "s256", 0, {0}},
    {"DestinationAddress", "s256",  0, {0}},
    {"LinkType", "s032", 0, {0}},
    {"ConnectionType", "s032", 0, {0}},
    {"Name",  "s032", 0, {0}},
    {"WANConnectionServiceNumberOfEntries", "uint", 0, {0}},
    {0, 0, 0, {0}},
};

IFX_TR64_ArgumentS xaAddConnectionDeviceAndServiceArgument[] =
{
    {"DestinationAddress", IFX_TR64_DIRECTION_IN, "DestinationAddress"},
    {"LinkType", IFX_TR64_DIRECTION_IN, "LinkType"},
    {"ConnectionType", IFX_TR64_DIRECTION_IN, "ConnectionType"},
    {"Name", IFX_TR64_DIRECTION_IN, "Name"},
    {"WANConnectionDevice", IFX_TR64_DIRECTION_OUT, "WANConnectionDevice"},
    {"WANConnectionService", IFX_TR64_DIRECTION_OUT, "WANConnectionService"},
    {0, 0, 0}
};

IFX_TR64_ArgumentS xaAddConnectionServiceArgument[] =
{
    {"WANConnectionDevice", IFX_TR64_DIRECTION_IN, "WANConnectionDevice"},
    {"ConnectionType", IFX_TR64_DIRECTION_IN, "ConnectionType"},
    {"Name", IFX_TR64_DIRECTION_IN, "Name"},
    {"WANConnectionService", IFX_TR64_DIRECTION_OUT, "WANConnectionService"},
    {0, 0, 0}
};


IFX_TR64_ArgumentS xaDeleteConnectionServiceArgument[] =
{
    {"WANConnectionService", IFX_TR64_DIRECTION_IN, "WANConnectionService"},
    {0, 0, 0}
};

IFX_TR64_ActionS xaWANDSLCMAction[] =
{
    {"AddConnectionDeviceAndService", xaAddConnectionDeviceAndServiceArgument},
    {"AddConnectionService", xaAddConnectionServiceArgument},
    {"DeleteConnectionService", xaDeleteConnectionServiceArgument},
    {0, 0}
};



IFX_TR64_Service xaIGDService[] =
{
    {"Layer3Forwarding"},
    {"DeviceInfo"},
#ifdef IFX_TR69_TIME
    {"Time"},
#endif
    {"DeviceConfig"},
    {"LANConfigSecurity"},
    {"ManagementServer"},
    {0} 
};

IFX_TR64_Service xaLDService[] =
{
    {"LANHostConfigManagement"},
#ifdef IFX_TR69_ETHERNETLAN
    {"LANEthernetInterfaceConfig"},
#endif
    {"Hosts"},
   
#ifdef IFX_TR69_WIFILAN
	{"WLANConfiguration"},
#endif
    {0}
};

IFX_TR64_Service xaWDService[] =
{
    {"WANCommonInterfaceConfig"},
#ifdef IFX_TR69_ADSLWAN 
    {"WANDSLConnectionManagement"}, 
    {"WANDSLInterfaceConfig"}, 
#endif
    {0} 
};


IFX_TR64_Service xaWCDService[] =
{
#ifdef IFX_TR69_ADSLWAN 
    {"WANDSLLinkConfig"},
#endif
#ifdef IFX_TR69_ETHERNETWAN 
    {"WANEthernetLinkConfig"},
#endif
    {"WANIPConnection"},
    {"WANPPPConnection"},
    {0} 
};

IFX_TR64_Device xaWDDevice[] =
{
    {"WANConnectionDevice", xaWCDService, 0},
    {0, 0, 0}
};

IFX_TR64_Device xaIGDDevice[] =
{
    {"LANDevice", xaLDService, 0},
    {"WANDevice", xaWDService,  xaWDDevice},
    {0, 0, 0} 
};

IFX_TR64_Device xaRootDevice[] =
{
    {"InternetGatewayDevice", xaIGDService, xaIGDDevice},
    {0, 0, 0}
};

#else
IFX_TR64_Service xaDevService[] =
{
    {"DeviceInfo"},
#ifdef IFX_TR69_TIME
    {"Time"},
#endif
    {"ManagementServer"},
    {0} 
};

IFX_TR64_Service xaLDService[] =
{
#ifdef IFX_TR69_WIFILAN
	{"WLANConfiguration"},
#endif
    {0}
};

IFX_TR64_Device xaDevDevice[] =
{
    {"LAN", xaLDService, 0},
    {0, 0, 0} 
};

IFX_TR64_Device xaRootDevice[] =
{
    {"Device", xaDevService, xaDevDevice},
    {0, 0, 0}
};
#endif

IFX_TR64_ServiceDescS xaServiceDesc[] =
{
    {"DeviceConfig", IFX_TR64_DEVICECONFIG_SERVICEID,  xaDCAction, 0},
#ifdef IFX_TR69_ADSLWAN 
    {"WANDSLConnectionManagement", IFX_TR64_WANDSLCONNECTIONMANAGEMENT_SERVICEID,  xaWANDSLCMAction, xaWANDSLCMStateVariable},
#endif
    {0, 0}
};



/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS>
**
** =============================================================================
*/


/*
** =============================================================================
**   Function Name    : IFX_TR64_TMLRequestHandler
**
**   Description         : This function handles the session handling.Mapping the device and service to
					the respective objects in TR69.Indentification of keys and index.
**
**   Parameters        : <par_type> <par_data_type>  <par_name>   <description of par>

	  				IN 		   IFX_TR64_Request    *pxReq
	  				OUT 	   IFX_TR64_Response  *pxRes
**
**   Return Value      :
**
**   Notes                :
**
** ============================================================================
*/

/*

HTTP:
1)	Password protected actions - API  (TR64_DB)

DDD:
1)    UUID Generation
2)    ServiceID generation
3)    Get the Actions and corresponding Parameters - API  (TR64_DB)
4)    Get the State Variables of service object -  API (TR69_DB)

1)	Session Management
2)	WANConnectionMgmt Handling
3)	DB Mgmt - Figure out the Action, Keys, Index, ServiceId, Params, SericeObj, ChildObj
4)	Error Mapping

*/

/*

typedef struct
{
    uchar8           ucOper; //TML
    char8             sAction[IFX_TR64_MAX_ACTION_LEN]; //SOAP
    char8             sServiceObj[IFX_TR64_MAX_OBJ_LEN]; //SOAP
    char8             sServiceId[IFX_TR64_MAX_SERVICEID_LEN]; //SOAP
    int32              iChildOID; //TML
    int32              iIndex; //SOAP
    int32              iaOIDKeyElem[IFX_TR64_MAX_KEY_ELEMENTS]; //TML Fills after referring tr64_db.txt
    int32              iaOIDOutParam[IFX_TR64_MAX_OUTPUT_PARAMS]; //TML (for Get Only)
    char8            sSessioID[40];  //SOAP
    uint32            uiNumNameValue; //SOAP
    IFX_TR64_NameValue *pxNameValue; //SOAP in Set, Add, Del or GetSpecific
} IFX_TR64_Request;

*/

int32 IFX_TR64_TMLRequestHandler(IFX_TR64_Request *pxReq, IFX_TR64_Response *pxRes)
{
   IFX_TR64_NameValue *pTmpNameVal=NULL;
   uint32 uiTmpNoElements=0;
   int32 aiTR69_OID[OID_LENGTH]={0};
   //int32 aiTmpTR69_OID[OID_LENGTH]={0};
   IFX_TR64_NameValue aWANParams[2]={{{0},NULL},{{0},NULL}};
   //char8  sLinkType[PARAMVALUE_LEN]={0};
   char8  *psName=NULL;
   char8  sWANConService_uuid_urn_tuple[IFX_TR64_MAX_UUID_URN_LEN]={0};
   //char8  sWANDevice_Name[]="WANDevice";
   char8  sWANConDevice_Name[]="WANConnectionDevice";
   int32  iRet = IFX_CWMP_SUCCESS;
   //uint32 uiFlags=0;
   uint32 uiCpeid=0;
   uint32 i=0;
   char8 sServiceId[IFX_TR64_MAX_SERVICEID_LEN]={0};
   char8 sCDServiceId[IFX_TR64_MAX_SERVICEID_LEN]={0};
  // char8 sTmpWANCD_UUID[IFX_TR64_MAX_UUID_LEN]={0};
   uint32 uiPos=0;
   int32 iParameter = -1;
   char * pTempValue = NULL;
   char ** ppTempValue = NULL;
   char8 sUUID[IFX_TR64_MAX_UUID_LEN]={0};
#ifdef IFX_TR69_IGD
   char psLinkValue[8]={0};
   int32 iRetStatus=0;
   char8 *psWcd_UUID=NULL;
   int32  *aiTmpOID=NULL;
   char8  sWANConDevUuidUrn[IFX_TR64_MAX_UUID_URN_LEN]={0};
   char8  sWANConDev_uuid_urn_tuple[IFX_TR64_MAX_UUID_URN_LEN]={0};
   char8  sWANConDevServiceId[IFX_TR64_MAX_SERVICEID_LEN]={0};
   char8 sWANCD_UUID[IFX_TR64_MAX_UUID_LEN]={0};
#endif
    int32 a=0;
    IFX_TR64_NameValue *pTmpResNameVal=NULL;
    int32 iNumNameVal = 0;
    int32 ValSize = 0;
    int32  iaOID[OID_LENGTH] = {0};
    char8 upstream_rate[16] = {0};
    char8 downstream_rate[16] = {0};
   //int32  iaInstanceList[MAX_NO_INSTANCES] = {0};

    //Session Management
    //Complex Action Sequence
        //Take the lock
        //Maintain the session state based on Session ID
        //Stop earlier timer if we get ConfigurationFinished Action or new RPC
        //Start the timer after we send the respone for each RPC
        //Timeout if we don't get ConfigurationFinished Action
        //release the lock
        //reset the session state
        // reset the SessionID
    //If get ConfigurationFinished Action
    	// release the lock
    	// reset the session state
    	// reset the SessionID
    //Individual RPCs
    	//Take the lock
    	//Maintain the session state
    	//Release the lock and reset session state while returning the status
    //Initialize the data variables
    memset(aWANParams,'\0',sizeof(aWANParams));


    //Fill the ucOper  - ADD,DEL,GET,SET,ROBOOT & FACTORYRESET
    if(strstr(pxReq->sAction, "Get") != NULL)
	pxReq->ucOper = IFX_TR64_OPER_GET;
    else if (strstr(pxReq->sAction, "Set") != NULL)
	pxReq->ucOper = IFX_TR64_OPER_SET;
    else if (strstr(pxReq->sAction, "Add") != NULL)
    	pxReq->ucOper = IFX_TR64_OPER_ADD;
    else if (strstr(pxReq->sAction, "Del") != NULL)
	pxReq->ucOper = IFX_TR64_OPER_DEL;
    else if (strcmp(pxReq->sAction, "ConfigurationStarted") == 0)
	pxReq->ucOper = IFX_TR64_OPER_CONF_START;
    else if (strcmp(pxReq->sAction, "ConfigurationFinished") == 0)
	pxReq->ucOper = IFX_TR64_OPER_CONF_FINISH;

    if((strcmp(pxReq->sAction, "AddPortMapping") == 0) || 
      (strcmp(pxReq->sAction, "DeletePortMapping") == 0))
    {
    }
    else if((pxReq->ucOper == IFX_TR64_OPER_SET) ||
    (pxReq->ucOper == IFX_TR64_OPER_ADD) ||
    (pxReq->ucOper == IFX_TR64_OPER_DEL))
    {
	guiChangeFlag = IFX_TR64_CHANGE_FLAG_SET;
    }

    if(strcmp(pxReq->sAction,"ConfigurationStarted") == 0)
    {
		if(suiSessionState == TR64_SESSION_STATE_INACTIVE) {

			if(strcmp(pxReq->sSessionID,"")==0) {
				pxRes->iStatus = IFX_TR64_ERR_ACTION_FAILED;
				goto ErrorHandler;
			 }
			strcpy(sTMLSessionID, pxReq->sSessionID);
			suiSessionState = TR64_SESSION_STATE_ACTIVE;

			if(guiChangeFlag == IFX_TR64_CHANGE_FLAG_SET) {
			 }
			 IFX_TR64_StartTimer(IFX_TR64_SESSION_TIMEOUT_SECS, IFX_TR64_SESSION_TIMEOUT_ID);

			 // Return proper status value
			 pxRes->iStatus = IFX_CWMP_SUCCESS;

			IFX_TR64_SOAP_FormResp(pxReq, pxRes);
			 return IFX_CWMP_SUCCESS;


		} else {
				//Return an error
			// TODO: check if it is the legitimate control poit
			strcpy(sTMLSessionID, pxReq->sSessionID);
			IFX_TR64_CancelTimer(IFX_TR64_SESSION_TIMEOUT_ID);
			IFX_TR64_StartTimer(400000, IFX_TR64_SESSION_TIMEOUT_ID);
			suiSessionState = TR64_SESSION_STATE_ACTIVE;
			pxRes->iStatus = IFX_CWMP_SUCCESS;
			IFX_TR64_SOAP_FormResp(pxReq, pxRes);
			return IFX_CWMP_SUCCESS;
			}
    }
    else if (strcmp(pxReq->sAction,"ConfigurationFinished") == 0)
    {
		if(suiSessionState == TR64_SESSION_STATE_ACTIVE) {
		  if(strcmp(pxReq->sSessionID,sTMLSessionID) ==0) {

			memset(sTMLSessionID,'\0',IFX_TR64_MAX_SESSION_ID_LEN);
			suiSessionState = TR64_SESSION_STATE_INACTIVE;

 			IFX_TR64_CancelTimer(IFX_TR64_SESSION_TIMEOUT_ID);


			if((suiRetStatus == IFX_CWMP_NEED_ACTIVATE) ||
			   (suiRetStatus == IFX_CWMP_SUCCESS)) {
				strcpy(pxRes->sErrorString,"ChangesApplied");
			} else if(suiRetStatus == IFX_CWMP_NEED_REBOOT) {
	   			strcpy(pxRes->sErrorString,"RebootRequired");
			}
		  	pxRes->iStatus = IFX_CWMP_SUCCESS;
			pxRes->uiNumNameValue = 1;
			pxRes->pxNameValue = IFIN_CWMP_MALLOC(1 * sizeof(IFX_TR64_NameValue));
			if (pxRes->pxNameValue == NULL) {
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d] Out-Of-Memory\n", __func__, __LINE__);
			} else {
				pxRes->pxNameValue[0].psValue = IFIN_CWMP_MALLOC(strlen(pxRes->sErrorString) +
				1);
				if (pxRes->pxNameValue[0].psValue == NULL) {
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d] Out-Of-Memory\n", __func__, __LINE__);
				} else {
					strcpy(pxRes->pxNameValue[0].sName, "Status");
					strcpy(pxRes->pxNameValue[0].psValue, pxRes->sErrorString); 
				}
			}
				 // suiRetStatus = 0;


			//Sending the SOAP Response back to Control Point
        		IFX_TR64_SOAP_FormResp(pxReq, pxRes);

			//Calling the tr64 Close where we want to handle the actions after closing
			//the session
			IFX_TR64_Close(pxReq, pxRes);

			//Persistence Storage handling
			if(guiChangeFlag == IFX_TR64_CHANGE_FLAG_SET) {

		 	iRet = IFX_Config_Save();
			if(iRet != IFX_CWMP_SUCCESS) {
			        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Failed to "
			                    "write rc.conf to flash\n", __func__, __LINE__, iRet);
				}

			// Return proper status value
			 //pxRes->iStatus = IFX_TR64_VALUE_CHANGE_APPLIED;


			}
				guiChangeFlag = IFX_TR64_CHANGE_FLAG_RESET;


				return IFX_CWMP_SUCCESS;
		    } else {
				//Return an error
				pxRes->iStatus = IFX_TR64_ERR_SESS_ID_EXPIRED;
				iRet = IFX_CWMP_FAILURE;
				goto ErrorHandler;
		    }

		} else {
				//Return an error
				pxRes->iStatus = IFX_TR64_ERR_SESS_ID_EXPIRED;
				iRet = IFX_CWMP_FAILURE;
				goto ErrorHandler;

		}
    }
    else
    {
	// Other than ConfigurationStarted and ConfigurationFinished RPCs
	// Check if the Session is Active
       // Compare the SessionId if it is matching restart timers
       // If does not return error

       	// Check if the Session is InActive
        // Check if the SessionId is empty
       	// Do the necessary steps to maintain session for individual RPC
        // if it is not empty return error

       	// Inidvidual RPCs will come serially since we getting the Req thru Select

       	if(suiSessionState == TR64_SESSION_STATE_ACTIVE)
        {
       		if (pxReq->ucOper == IFX_TR64_OPER_GET && !strcmp(pxReq->sSessionID, ""))
                {
       		}
                else if(strcmp(pxReq->sSessionID,sTMLSessionID) !=0)
                {
       			//Return an error
       			pxRes->iStatus = IFX_TR64_ERR_SESS_ID_EXPIRED;
       			strcpy(pxRes->sErrorString, "SessionIDExpired");
       			IFX_TR64_SOAP_FormResp(pxReq, pxRes);
       			iRet = IFX_CWMP_FAILURE;
       			goto ErrorHandler;
       		}
                else
                {
   			IFX_TR64_CancelTimer(IFX_TR64_SESSION_TIMEOUT_ID);
   			IFX_TR64_StartTimer(IFX_TR64_SESSION_TIMEOUT_SECS, IFX_TR64_SESSION_TIMEOUT_ID);
   		}
   	}
        else if(suiSessionState == TR64_SESSION_STATE_INACTIVE)
        {
   		suiSessionState = TR64_SESSION_INDIVIDUAL_RPC;
   		memset(sTMLSessionID,'\0',IFX_TR64_MAX_SESSION_ID_LEN);
   	}
    }

   /* Hack for Hosts::GetGenericHostEntry instance id */
   if (!strcmp(pxReq->sAction, "GetGenericHostEntry")) {
       int32 iIdx = 0;
       for (iIdx = 0; iIdx < pxReq->uiNumNameValue; iIdx++)
       {
           if (strstr(pxReq->pxNameValue[iIdx].sName, "Index")) {
               if (atoi(pxReq->pxNameValue[iIdx].psValue) <= 0) {
                   pxRes->iStatus = IFX_TR64_ERR_INVAL_PARAM_VAL;
                   goto ErrorHandler;
               }
               sprintf(pxReq->pxNameValue[iIdx].psValue, "%d", atoi(pxReq->pxNameValue[iIdx].psValue) - 1);
               break;
           }
       }
   }

#ifdef IFX_TR69_WIFILAN
   /*kamal handling the Get and set for WLAN Security*/
   if(!strcmp(pxReq->sAction,"GetSecurityKeys") || !strcmp(pxReq->sAction,"SetSecurityKeys"))
   {
       iRet = IFX_TR64_SecurityKeysRequestHandler(pxReq, pxRes);
       if(iRet != IFX_CWMP_SUCCESS) {
  	    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
	 	"Call to  IFX_TR64_SecurityKeysRequestHandler failed Action=%s,ServiceId=%s,ServiceObj=%s,Status=%d \n",
		 	__func__, __LINE__,pxReq->sAction,pxReq->sServiceId,pxReq->sServiceObj,pxRes->iStatus);
               goto ErrorHandler;
       }
       goto finish;
   }
   /* Hack for {Get|Set}DefaultWEPKeyIndex */
   if (!strcmp(pxReq->sAction,"GetDefaultWEPKeyIndex") ||
		   !strcmp(pxReq->sAction,"SetDefaultWEPKeyIndex")) {
       iRet = IFX_TR64_DefaultWEPKeyIndexHandler(pxReq, pxRes);
       if(iRet != IFX_CWMP_SUCCESS) {
  	    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
	 	"Call to  IFX_TR64_DefaultWEPKeyIndexHandler failed Action=%s,ServiceId=%s,ServiceObj=%s,Status=%d \n",
		 	__func__, __LINE__,pxReq->sAction,pxReq->sServiceId,pxReq->sServiceObj,pxRes->iStatus);
               goto ErrorHandler;
       }
       goto finish;
   }
/* end of hack */
#endif

// DB Mgmt
   	//Parse Function
   	//Get the Child Oid,Keys and OutPrams and fill it.

	iRet = IFX_TR64_ParseDB(pxReq->sServiceObj, pxReq->sAction, IFX_TR64_CHLD_OID_POS,
									1, &pxReq->iChildOID);
	if(iRet != IFX_CWMP_SUCCESS) {
			pxRes->iStatus = IFX_TR64_ERR_INVALID_ACTION;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Getting CHILD OID from DB failed for ServiceObj = %s Action = %s  \n",
			 __func__, __LINE__,pxReq->sServiceObj,pxReq->sAction);
		goto ErrorHandler;
	}
	iRet = IFX_TR64_ParseDB(pxReq->sServiceObj, pxReq->sAction, IFX_TR64_KEY_POS,
						IFX_TR64_MAX_KEY_ELEMENTS, pxReq->iaOIDKeyElem);
	if(iRet != IFX_CWMP_SUCCESS) {
			pxRes->iStatus = IFX_TR64_ERR_INVALID_ACTION;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Getting KEY PARAMS from DB failed for ServiceObj = %s Action = %s  \n",
			 __func__, __LINE__,pxReq->sServiceObj,pxReq->sAction);
		goto ErrorHandler;
	}
	iRet = IFX_TR64_ParseDB(pxReq->sServiceObj, pxReq->sAction, IFX_TR64_OUT_PARAM_POS,
						IFX_TR64_MAX_OUTPUT_PARAMS, pxReq->iaOIDOutParam);
	if(iRet != IFX_CWMP_SUCCESS) {
			pxRes->iStatus = IFX_TR64_ERR_INVALID_ACTION;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Getting OUT params from DB failed for ServiceObj = %s Action = %s  \n",
			 __func__, __LINE__,pxReq->sServiceObj,pxReq->sAction);
		goto ErrorHandler;
	}
	if(strstr(pxReq->sAction,"Generic") != NULL)
		pxReq->iIndex = atoi(pxReq->pxNameValue->psValue);
	else
		pxReq->iIndex = -1;


	//Map the Arguments to StateVariable Names
	iRet = IFX_TR64_FwdRevMapArg(IFX_TR64_ARG_FWD_MAP,pxReq->sAction,pxReq->pxNameValue,pxReq->uiNumNameValue);
	if(iRet != IFX_CWMP_SUCCESS) {
			pxRes->iStatus = IFX_TR64_ERR_INVALID_ARGS;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Forward Mapping of Args failed \n",
			 __func__, __LINE__);
                goto ErrorHandler;
	}


	/*If index not present fill -1
	If keys/outparams not present fill 0 */

    //WANConnectionMgmt Handling
    //DeviceConfig Handling
    //Layer3Forwarding

	// How to handle AddConnectionDeviceAndService
	//1.	/*****  Addition of WanConnectionDevice ******************/
		//  ChildOID is WanConnectionDevice
		//  ServiceObj=WanDevice
		//  Soap will fill the ServiceId from controlURL
		//  Keys are not present
		//  No OutParams
		//  No Parameters in ParamVal List
		//  Return WANConnectionDevice ServiceID
	//2.	/******  Modify WANDSLinkConfig ***********/
		// ChildOID - NULL
		// ServiceObj=WANDSLinkConfig
		// Convert WANConnectionDevice ServiceID to Tr69id
		// Append the WANDSlLinkConfig oid to TR69id
		// Get the WANDSLLinkConfig ServiceID from tr69id
		// Copy the WANDSLinkConfig ServiceID to ServiceID
		// Copy the Input Parameters LinkType & Destination Address into ParamVal List
#ifdef IFX_TR69_IGD
	if(strcmp(pxReq->sAction,"AddConnectionDeviceAndService")==0)
		{
		    pxReq->iChildOID = OID_IGD_WAND_WANCD;
		    pxReq->ucServiceIdState = IFX_TR64_SERVICEID_REQUIRED;
		    //Validation of Parameters
	            for(i=0;i<pxReq->uiNumNameValue;++i) {
			if(strcmp(pxReq->pxNameValue[i].psValue,"")==0) {
			pxRes->iStatus = IFX_TR64_ERR_INVAL_PARAM_VAL;
			iRet = IFX_TR64_ERR_INVAL_PARAM_VAL;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Invalid Param Val Param =%s \n",
			 __func__, __LINE__,pxReq->pxNameValue[i].sName);
	                 goto ErrorHandler;

			}
		    }
		    pTmpNameVal=pxReq->pxNameValue;
		    uiTmpNoElements=pxReq->uiNumNameValue;
		    pxReq->pxNameValue=NULL;
	    	    pxReq->uiNumNameValue=0;
	  	    //OutParams and Indx should be reset
		    pxReq->iIndex = -1;
		    memset(pxReq->iaOIDKeyElem,0,IFX_TR64_MAX_KEY_ELEMENTS);
		    memset(pxReq->iaOIDOutParam,0,IFX_TR64_MAX_OUTPUT_PARAMS);
		    strcpy(pxReq->sServiceId,"wan_device-1");

		     iRet = IFX_TR64_TALRequestHandler(pxReq, pxRes);
		     if(iRet != IFX_CWMP_SUCCESS) {
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	" Addition of WanConnDevice Failed  =%d \n",
			 __func__, __LINE__,iRet);
	                 goto ErrorHandler;
		     }

		   //Form the UUID with the WANConDevice Cpeid
		   //Form the ServiceID with the WANConDevice SecName and Cpeid
		     uiCpeid =  atoi(strrchr(pxRes->pxNameValue->psValue,'-')+1);
		     strcpy(sUUID,uuidvalue);
		    // strcpy(sTmpWANCD_UUID,pxRes->pxNameValue->psValue);
		     iRet = IFX_TR64_GenUUID(uiCpeid,sWANConDevice_Name,sUUID);
		     if(iRet != IFX_CWMP_SUCCESS){
			pxRes->iStatus = IFX_TR64_ERR_ACTION_FAILED;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Generation of UUID failed UUID =%s Cpeid =%d\n",
			 __func__, __LINE__,sUUID,uiCpeid);
	                 goto ErrorHandler;
			}

		     iRet = IFX_FormUuidUrnTuple(sUUID,sWANConDevice_Name,pxRes->pxNameValue->psValue,
									sWANConDev_uuid_urn_tuple);
		     if(iRet != IFX_CWMP_SUCCESS){
			pxRes->iStatus = IFX_TR64_ERR_ACTION_FAILED;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Generation of UuidUrn failed uuid =%s devName=%s ServiceId=%d \n",
			 __func__, __LINE__,sUUID,sWANConDevice_Name,pxRes->pxNameValue->psValue);
	                 goto ErrorHandler;
			}


		 //Modification of LinkType and DestinationAddress in WANDSLLinkConfig
		    pxReq->iChildOID = 0;
          	    pxReq->ucOper = IFX_TR64_OPER_SET;
		    pxReq->ucServiceIdState = IFX_TR64_SERVICEID_NOT_REQUIRED;

		    iRet = IFX_GetTR69IdFromServiceId(pxRes->pxNameValue->psValue,aiTR69_OID);
		    if(iRet != IFX_CWMP_SUCCESS) {
			pxRes->iStatus = IFX_TR64_ERR_ACTION_FAILED;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Getting TR69 ID failed from ServiceID = %s \n",
			 __func__, __LINE__,pxRes->pxNameValue->psValue);
               		goto ErrorHandler;
		    }

		    strcpy(sWANConDevServiceId,pxRes->pxNameValue->psValue);
		    aiTmpOID=aiTR69_OID;
		    while(*aiTmpOID !=0)
		        aiTmpOID++;
#ifdef IFX_TR69_ADSLWAN
		    *aiTmpOID = OID_IGD_WAND_WANCD_WANDSLLC;
#endif

		    iRet = IFX_GetServiceIdFromTR69Id(aiTR69_OID,pxReq->sServiceId);
		    if(iRet != IFX_CWMP_SUCCESS) {
			pxRes->iStatus = IFX_TR64_ERR_ACTION_FAILED;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Getting ServiceID from TR69_Id fail\n",
			 __func__, __LINE__);
			IFX_PrintOID(aiTR69_OID);
               		goto ErrorHandler;
		    }
		    //After copying the ServiceID we need to free the NameValue ptr
		    IFX_CWMP_FREE(pxRes->pxNameValue->psValue);
		    IFX_CWMP_FREE(pxRes->pxNameValue);
		    pxRes->uiNumNameValue=0;

		    for(i=0;i<uiTmpNoElements;i++)
                    {
			if(strcmp(pTmpNameVal[i].sName,"LinkType")==0)
			{
			    strcpy(aWANParams[0].sName,pTmpNameVal[i].sName);
                            strncpy(psLinkValue,pTmpNameVal[i].psValue,7);
	        	    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] psLinkValue[%s] \n",
			         __func__, __LINE__, psLinkValue);
                            /*Allow PPPoE/A to be configured from UPnP*/ 
                            if(strcmp(pTmpNameVal[i].psValue,"PPPoE") == 0)
                            {
	        	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] Set to EoA \n", __func__, __LINE__);
			        aWANParams[0].psValue = pTmpNameVal[i].psValue;
                                sprintf(aWANParams[0].psValue,"EoA");
                            }
                            else
                            {
			        aWANParams[0].psValue = pTmpNameVal[i].psValue;
                            }
 			}

			if(strcmp(pTmpNameVal[i].sName,"DestinationAddress")==0)
                        {
                            strcpy(aWANParams[1].sName,pTmpNameVal[i].sName);
			    aWANParams[1].psValue = pTmpNameVal[i].psValue;
                        }

                     }
		     pxReq->uiNumNameValue=2;
		     pxReq->pxNameValue = aWANParams;
 		     iRet = IFX_TR64_TALRequestHandler(pxReq, pxRes);
                       if(iRet != IFX_CWMP_SUCCESS) {
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Modification of WanDslLinkConfig failed status = %d \n",
			 __func__, __LINE__,pxRes->iStatus);
			//Delete the WanCondevice
			iRetStatus = pxRes->iStatus;
			strcpy(pxReq->sServiceId,sWANConDevServiceId);
			pxReq->ucOper = IFX_TR64_OPER_DEL;
			IFX_TR64_TALRequestHandler(pxReq, pxRes);
			pxRes->iStatus = iRetStatus;
                           goto ErrorHandler;
		     }

		}
	//3. 	/********** ADD WANIPConnection / WANPPPConnection ***********/
		//  ChildOID is WANIPConnection/WANPPPConnection based on LinkType
		//  ServiceObj=WanConnectionDevice
		//  Copy the WANConnectionDevice ServiceID
		//  Keys are not present
                //  Pass the Parameters ConnectionType & Name in the ParamVal List
		//  Return WANIPConnection/WANPPPConnection ServiceID


	// How to handle AddConnectionService
	//1.	//Refer to Step 3 of handling AddConnectionDeviceAndService
		// Only change is extracting service id. It should be from WANConnectionDevice param
	if ((strcmp(pxReq->sAction,"AddConnectionDeviceAndService")==0) ||
	  	(strcmp(pxReq->sAction,"AddConnectionService")==0))
	   {
		    //Validation of Parameters
	            for(i=0;i<pxReq->uiNumNameValue;++i) {
			if(strcmp(pxReq->pxNameValue[i].psValue,"")==0) {
			pxRes->iStatus = IFX_TR64_ERR_INVAL_PARAM_VAL;
			iRet = IFX_TR64_ERR_INVAL_PARAM_VAL;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Invalid Param Val Param =%s \n",
			 __func__, __LINE__,pxReq->pxNameValue[i].sName);
	                 goto ErrorHandler;

			}
		    }

     	        //OutParams and Indx should be reset
	         pxReq->iIndex = -1;
	         memset(pxReq->iaOIDKeyElem,0,IFX_TR64_MAX_KEY_ELEMENTS);
	         memset(pxReq->iaOIDOutParam,0,IFX_TR64_MAX_OUTPUT_PARAMS);

		pxReq->ucServiceIdState = IFX_TR64_SERVICEID_REQUIRED;
		pxReq->ucOper = IFX_TR64_OPER_ADD;
		   if(pTmpNameVal == NULL) {
		    pTmpNameVal=pxReq->pxNameValue;
		    uiTmpNoElements=pxReq->uiNumNameValue;
		   }

		if(strcmp(pxReq->sAction,"AddConnectionDeviceAndService")==0)
		{
		 strcpy(pxReq->sServiceId,sWANConDevServiceId);

		} else {
		 	for(i=0;i< pxReq->uiNumNameValue;i++)
			{
                	 if(strcmp(pxReq->pxNameValue[i].sName,"WANConnectionDevice")==0)
			//Get Cpeid from WANConDevice UUID
			//Form the ServiceID with WanConDevice SecName and Cpeid
		        //iRet = IFX_GetServiceIDFromUuidUrnTuple(pxReq->pxNameValue[i].psValue,pxReq->sServiceId);
			strcpy(sWANConDevUuidUrn,pxReq->pxNameValue[i].psValue);

			psWcd_UUID = strtok(sWANConDevUuidUrn,":");
			if(psWcd_UUID!=NULL)
			{
			//strcpy(sWANCD_UUID,psWcd_UUID);
			psWcd_UUID=NULL;
			} else {
			break;
			}

			psWcd_UUID = strtok(NULL,":");
			if(psWcd_UUID!=NULL)
                        {
			strcpy(sWANCD_UUID,psWcd_UUID);
			psWcd_UUID=NULL;
			} else {
			break;
			}

			iRet = IFX_TR64_GetCpeidFromUUID(sWANCD_UUID,&uiCpeid,psName);
			if(iRet != IFX_CWMP_SUCCESS) {
	        	  IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	  "Getting Cpeid from UUID failed UUID= %s \n",
			  __func__, __LINE__,sWANCD_UUID);

			if(strcmp(pxReq->sAction,"AddConnectionDeviceAndService")==0)
			  pxRes->iStatus = IFX_TR64_ERR_ACTION_FAILED;
			else
			  pxRes->iStatus = IFX_TR64_ERR_INVAL_PARAM_VAL;
               			goto ErrorHandler;
			}

			sprintf(pxReq->sServiceId,"%s-%d","wan_conndev",uiCpeid);
		 	strcpy(sWANConDevServiceId,pxReq->sServiceId);
			break;
			}

		}
		memset(aiTR69_OID,'\0',OID_LENGTH*sizeof(int32));
		iRet = IFX_GetTR69IdFromServiceId(pxReq->sServiceId,aiTR69_OID);
		if(iRet != IFX_CWMP_SUCCESS) {
			pxRes->iStatus = IFX_TR64_ERR_ACTION_FAILED;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Getting TR69 ID failed from ServiceID = %s \n",
			 __func__, __LINE__,pxReq->sServiceId);
               		goto ErrorHandler;
		}

		 aiTmpOID=aiTR69_OID;
		 while(*aiTmpOID !=0)
		      aiTmpOID++;
#ifdef IFX_TR69_ADSLWAN
		 *aiTmpOID = OID_IGD_WAND_WANCD_WANDSLLC;
		 *(aiTmpOID+1)= OID_IGD_WAND_WANCD_WANDSLLC_LINKTYPE;
#endif
#if 0
		 iRet = ifx_config_get_val_fromOID(aiTR69_OID,sLinkType);
		 if(iRet != IFX_CWMP_SUCCESS) {
			pxRes->iStatus = IFX_TR64_ERR_ACTION_FAILED;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Getting LinkType failed \n",
			 __func__, __LINE__);
               		goto ErrorHandler;
		 }
#endif

		 /*if((strcmp(sLinkType,"PPPoE")==0)||
		    (strcmp(sLinkType,"PPPoA")==0))*/
                    if((strcmp(psLinkValue,"PPPoE") == 0) || (strcmp(psLinkValue,"PPPoA") == 0))
		    {
	                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] Set childOID PPP \n", __func__, __LINE__);
			pxReq->iChildOID = OID_IGD_WAND_WANCD_WANPPPC;
		    }
                    else
                    {
	                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] Set childOID IP \n", __func__, __LINE__);
			pxReq->iChildOID = OID_IGD_WAND_WANCD_WANIPC;
		    }
			for(i=0;i<uiTmpNoElements;i++) {
    	                     if(strcmp(pTmpNameVal[i].sName,"ConnectionType")==0)
                             {
                               strcpy(aWANParams[0].sName,pTmpNameVal[i].sName);
			    	aWANParams[0].psValue = pTmpNameVal[i].psValue;
                             }

                             if(strcmp(pTmpNameVal[i].sName,"Name")==0)
                                  {
                                    strcpy(aWANParams[1].sName,pTmpNameVal[i].sName);
			    	    aWANParams[1].psValue = pTmpNameVal[i].psValue;
                                  }

                          }
		  pxReq->uiNumNameValue=2;
		  pxReq->pxNameValue = aWANParams;
                  iRet = IFX_TR64_TALRequestHandler(pxReq, pxRes);
                     if(iRet != IFX_CWMP_SUCCESS) {
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Addition of WanIP/WanPPP connection failed\n",
			 __func__, __LINE__);
			iRetStatus = pxRes->iStatus;
			strcpy(pxReq->sServiceId,sWANConDevServiceId);
			pxReq->iChildOID =0;
			pxReq->ucOper = IFX_TR64_OPER_DEL;
			IFX_TR64_TALRequestHandler(pxReq, pxRes);
			pxRes->iStatus = iRetStatus;
                         goto ErrorHandler;
		     }

		//Copy the UUID from WANConDevice if it is "AddConnectionService"
 	       if (strcmp(pxReq->sAction,"AddConnectionService")==0) {
			psWcd_UUID = sWANCD_UUID;
 		} else {
			psWcd_UUID = sUUID;
		}
                iRet = IFX_FormUuidUrnTuple(psWcd_UUID,sWANConDevice_Name,pxRes->pxNameValue->psValue,
									sWANConService_uuid_urn_tuple);
		if(iRet != IFX_CWMP_SUCCESS) {
			 pxRes->iStatus = IFX_TR64_ERR_ACTION_FAILED;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Formation of UUID_URN failed, UUID = %s,ConDevname=%s ServiceId=%s \n",
			 __func__, __LINE__,psWcd_UUID,sWANConDevice_Name,pxRes->pxNameValue->psValue);
               		goto ErrorHandler;
		}

		 //After copying the ServiceID we need to free the NameValue ptr
		    IFX_CWMP_FREE(pxRes->pxNameValue->psValue);
		    IFX_CWMP_FREE(pxRes->pxNameValue);
		    pxRes->uiNumNameValue=0;

		//Form the Prameters WanConnectionDevice and WanConnectionService
		if (strcmp(pxReq->sAction,"AddConnectionService")==0) {
		pxRes->pxNameValue = IFIN_CWMP_MALLOC(sizeof(IFX_TR64_NameValue));
		if(pxRes->pxNameValue == NULL)
                {
			pxRes->iStatus = IFX_TR64_ERR_OUT_OF_MEMORY;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"MALLOC Failed \n", __func__, __LINE__);
               		goto ErrorHandler;
		}
		pxRes->pxNameValue->psValue = IFIN_CWMP_MALLOC(sizeof(sWANConService_uuid_urn_tuple));
		if(pxRes->pxNameValue->psValue == NULL) {
			pxRes->iStatus = IFX_TR64_ERR_OUT_OF_MEMORY;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"MALLOC Failed \n", __func__, __LINE__);
               		goto ErrorHandler;
		}
		strcpy(pxRes->pxNameValue->sName,"WANConnectioniService");
		strcpy(pxRes->pxNameValue->psValue,sWANConService_uuid_urn_tuple);
		pxRes->uiNumNameValue=1;
		}

		if(strcmp(pxReq->sAction,"AddConnectionDeviceAndService")==0) {

		pxRes->pxNameValue = IFIN_CWMP_MALLOC(sizeof(IFX_TR64_NameValue)*2);
		if(pxRes->pxNameValue == NULL)
                {
			pxRes->iStatus = IFX_TR64_ERR_OUT_OF_MEMORY;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"MALLOC Failed \n", __func__, __LINE__);
               		goto ErrorHandler;
		}
		pxRes->pxNameValue[0].psValue = IFIN_CWMP_MALLOC(sizeof(sWANConDev_uuid_urn_tuple));
		pxRes->pxNameValue[1].psValue = IFIN_CWMP_MALLOC(sizeof(sWANConService_uuid_urn_tuple));
		if((pxRes->pxNameValue[0].psValue == NULL) || (pxRes->pxNameValue[1].psValue == NULL))
		{
			pxRes->iStatus = IFX_TR64_ERR_OUT_OF_MEMORY;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"MALLOC Failed \n", __func__, __LINE__);
               		goto ErrorHandler;
		}

		strcpy(pxRes->pxNameValue[0].sName,"WANConnectionDevice");
		strcpy(pxRes->pxNameValue[0].psValue,sWANConDev_uuid_urn_tuple);
		strcpy(pxRes->pxNameValue[1].sName,"WANConnectionService");
		strcpy(pxRes->pxNameValue[1].psValue,sWANConService_uuid_urn_tuple);
		pxRes->uiNumNameValue=2;

                }


		   // pxReq->pxNameValue = pTmpNameVal;
		   // pxReq->uiNumNameValue = uiTmpNoElements;

       		pxRes->iStatus = IFX_CWMP_SUCCESS;
               // return IFX_CWMP_SUCCESS;
              /* To close this RPC smoothly jumping to ErrorHandler */
                        goto ErrorHandler;



	   }

	// How to handle DeleteConnectionService
		//  Extact WANIPConnection / WANPPPConnection ServiceID from WANConnectionService param
		//  No Parameters in ParamVal List
	if(strcmp(pxReq->sAction,"DeleteConnectionService")==0)
	    {
		//Grep the ServiceId from ConnectionService Parameter Value
		//Delete the ConnectionService Prameter from the Param List
     	        //OutParams and Indx should be reset
	         pxReq->iIndex = -1;
	         memset(pxReq->iaOIDKeyElem,0,IFX_TR64_MAX_KEY_ELEMENTS);
	         memset(pxReq->iaOIDOutParam,0,IFX_TR64_MAX_OUTPUT_PARAMS);
		iRet = IFX_GetServiceIDFromUuidUrnTuple(pxReq->pxNameValue->psValue,pxReq->sServiceId);
		if(iRet != IFX_CWMP_SUCCESS) {
			pxRes->iStatus = IFX_TR64_ERR_INVAL_PARAM_VAL;
			iRet = IFX_TR64_ERR_INVAL_PARAM_VAL;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Getting ServiceID failed from UuidUrn = %s \n",
			 __func__, __LINE__,pxReq->pxNameValue->psValue);
               		goto ErrorHandler;
		}

		iRet = IFX_GetTR69IdFromServiceId(pxReq->sServiceId ,aiTR69_OID);
		if(iRet != IFX_CWMP_SUCCESS) {
			pxRes->iStatus = IFX_TR64_ERR_ACTION_FAILED;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Getting TR69_Id failed from ServiceId = %s \n",
			 __func__, __LINE__,sServiceId);
               		goto ErrorHandler;
		}

		iRet = IFX_TR64_TALRequestHandler(pxReq, pxRes);
                     if(iRet != IFX_CWMP_SUCCESS) {
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Deletion of WanIP/WanPPP connection failed\n",
			 __func__, __LINE__);
                         goto ErrorHandler;
		     }

		    aiTmpOID=aiTR69_OID;
		    while(*aiTmpOID !=0)
		        aiTmpOID++;

		--aiTmpOID;
                *aiTmpOID=0;

	/*
		// memcpy(aiTmpTR69_OID,aiTR69_OID,OID_LENGTH*sizeof(int32));
		//If the no of instance under wancondev is 1 then proceed to delete WanCondev

        	iRet = ifx_ds_get_instancelist(aiTR69_OID, NULL, iaInstanceList);
		if(iRet != IFX_CWMP_SUCCESS) {
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Getting instanceList for WanCondev OID failed \n",
			 __func__, __LINE__);
			IFX_PrintOID(aiTR69_OID);
               	//	goto ErrorHandler;
		}

	*/
		  for(i=0;i<1;i++) {
		        --aiTmpOID;
			*aiTmpOID=0;
		  }

	       // if (iRet != IFX_CWMP_SUCCESS)
                {
		 	iRet = IFX_GetServiceIdFromTR69Id(aiTR69_OID,pxReq->sServiceId);
		    	if(iRet != IFX_CWMP_SUCCESS) {
			pxRes->iStatus = IFX_TR64_ERR_ACTION_FAILED;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Getting ServiceID from TR69_Id fail\n",
			 __func__, __LINE__);
			IFX_PrintOID(aiTR69_OID);
               		goto ErrorHandler;
		    	}

		 	iRet = IFX_TR64_TALRequestHandler(pxReq, pxRes);
                     	if(iRet != IFX_CWMP_SUCCESS) {
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Deletion of WanConnectionDevice failed\n",
			 __func__, __LINE__);
                         goto ErrorHandler;
		     	}


                }
		// Go to Errorhandler even for success case
			goto ErrorHandler;
	    }
#endif
	// How to handle SetDefaultConnectionService
		// ServiceObj Soap will the content
		// Extract the ServiceID from the DefaultConnectionService param put in the Praram Value and
		//	ServiceID field
		// DefaultWANConnectionService Param Present in the ParamVal List
	if((strcmp(pxReq->sAction,"SetDefaultConnectionService")==0) || (strcmp(pxReq->sAction,"AddForwardingEntry")==0) )
            {
		//Get the ServiceId from the DefaultConnectionService Param Value
		//From ServiceId get the TR69_OID
		//From TR69_OID get the full tr69 name
		//Copy the tr69 name into DefaultConnectionService Value

		    if(strcmp(pxReq->sAction,"SetDefaultConnectionService")==0){
			    pTempValue = pxReq->pxNameValue->psValue;
		    }else if(strcmp(pxReq->sAction,"AddForwardingEntry")==0) {
			    // search the parameter
			    iParameter = -1;
			    for(i=0;i<pxReq->uiNumNameValue;++i) {
				    if(strcmp(pxReq->pxNameValue[i].sName,"Interface")==0){

					   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d] '%s' \n", __func__ , __LINE__, pxReq->pxNameValue[i].psValue);
					    if(strcmp(pxReq->pxNameValue[i].psValue,"")){
						    pTempValue = pxReq->pxNameValue[i].psValue ;
						    iParameter = i;
					    }
					    break;
				    }
			    }
			    if(iParameter < 0) // 0 or more can be the index of interface in array
			         goto no_interface; // interface not there in input continue without conversion
		    }

		    iRet = IFX_GetServiceIDFromUuidUrnTuple(pTempValue,sServiceId);
		    if(iRet != IFX_CWMP_SUCCESS) {
			    pxRes->iStatus = IFX_TR64_ERR_INVAL_PARAM_VAL;
			    iRet = IFX_TR64_ERR_INVAL_PARAM_VAL;
			    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
					    "Getting ServiceID failed from UuidUrn = %s \n",
					    __func__, __LINE__,pxReq->pxNameValue->psValue);
			    goto ErrorHandler;
		    }

		iRet = IFX_GetTR69IdFromServiceId(sServiceId ,aiTR69_OID);
		if(iRet != IFX_CWMP_SUCCESS) {
			pxRes->iStatus = IFX_TR64_ERR_ACTION_FAILED;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Getting TR69_Id failed from ServiceId = %s \n",
			 __func__, __LINE__,sServiceId);
               		goto ErrorHandler;
		}

		psName = IFIN_CWMP_MALLOC(PARAMNAME_LEN);
		if(psName == NULL) {
			pxRes->iStatus = IFX_TR64_ERR_OUT_OF_MEMORY;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"MALLOC Failed \n", __func__, __LINE__);
               		goto ErrorHandler;
		}

		iRet = IFX_GlobalNameOidConversion(psName,aiTR69_OID);
		if(iRet != IFX_CWMP_SUCCESS) {
			pxRes->iStatus = IFX_TR64_ERR_ACTION_FAILED;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Getting tr69 Name from OID failed \n",
			 __func__, __LINE__);
			IFX_PrintOID(aiTR69_OID);
               		goto ErrorHandler;
		}

		//copy back the modified values in structure
		if(strcmp(pxReq->sAction,"SetDefaultConnectionService")==0){
			//strcpy(pxReq->pxNameValue->psValue, psName);
			IFIN_CWMP_FREE(pxReq->pxNameValue->psValue);
			pxReq->pxNameValue->psValue = psName;
		}else if(strcmp(pxReq->sAction,"AddForwardingEntry")==0) {
			IFIN_CWMP_FREE( pxReq->pxNameValue[iParameter].psValue );
			pxReq->pxNameValue[iParameter].psValue = psName;
		}

	    }
no_interface :

	//Handle SetIPInteraceInfo hack here
	if(strcmp(pxReq->sAction,"SetIPInterfaceInfo")==0) {
		    pTmpNameVal=pxReq->pxNameValue;
		    uiTmpNoElements=pxReq->uiNumNameValue;
	    for(i=0;i<uiTmpNoElements;i++) {
		if(strcmp(pTmpNameVal[i].sName,"AddressingType")==0)	{
			if(strcmp(pTmpNameVal[i].psValue,"DHCP")==0) {
			  strcpy(aWANParams[0].sName,pTmpNameVal[i].sName);
			  aWANParams[0].psValue = pTmpNameVal[i].psValue;
			   pxReq->uiNumNameValue=1;
		  	   pxReq->pxNameValue = aWANParams;
			}
 			}

	    }
	}

      if(strcmp(pxReq->sServiceObj,"WANDSLLinkConfig")==0)
      {
          if(strcmp(pxReq->sAction,"SetDSLLinkType")==0)
          {
		if(strcmp(pxReq->pxNameValue->psValue,"PPPoE") == 0)
                {
		    sprintf(pxReq->pxNameValue->psValue, "EoA");
                }
          }
      }
	//How to handle RequestConnection, RequestTermination & ForceTermination

	if((strcmp(pxReq->sAction,"RequestConnection")==0) ||
	  (strcmp(pxReq->sAction,"RequestTermination")==0) ||
	  (strcmp(pxReq->sAction,"ForceTermination")==0))   {

		pxReq->ucOper = IFX_TR64_OPER_SET;
		pxReq->uiNumNameValue=1;
		pxReq->pxNameValue = IFIN_CWMP_MALLOC(sizeof(IFX_TR64_NameValue));
                if(pxReq->pxNameValue)
		    pxReq->pxNameValue->psValue=IFIN_CWMP_MALLOC(10);
		if((pxReq->pxNameValue == NULL) || 
                   (pxReq->pxNameValue->psValue == NULL)) {
			pxRes->iStatus = IFX_TR64_ERR_OUT_OF_MEMORY;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"MALLOC Failed \n", __func__, __LINE__);
               		goto ErrorHandler;
		}
		strcpy(pxReq->pxNameValue->sName,"Enable");

		if(strcmp(pxReq->sAction,"RequestConnection")==0) {
		strcpy(pxReq->pxNameValue->psValue,"True");
		}
		if((strcmp(pxReq->sAction,"RequestTermination")==0) ||
	  	(strcmp(pxReq->sAction,"ForceTermination")==0)) {
		strcpy(pxReq->pxNameValue->psValue,"False");
		}

	}

	if(strcmp(pxReq->sAction,"ConfigureConnection")==0)
        {
	    pxReq->ucOper = IFX_TR64_OPER_SET;
	    pxRes->iStatus = IFX_CWMP_SUCCESS;
        }
	if(strcmp(pxReq->sAction,"Reboot")==0)
        {
	    pxReq->ucOper = IFX_TR64_OPER_REBOOT;
	    pxRes->iStatus = IFX_CWMP_SUCCESS;
        }
	else if(strcmp(pxReq->sAction,"FactoryReset")==0)
        {
	      pxReq->ucOper = IFX_TR64_OPER_FACTORY_RESET;
	      pxRes->iStatus = IFX_CWMP_SUCCESS;
	} 
        else
        {
		//Call the TAL handler
		iRet = IFX_TR64_TALRequestHandler(pxReq, pxRes);

		if(iRet != IFX_CWMP_SUCCESS) {
        		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
	 		"Call to IFX_TR64_TALRequestHandler failed Action=%s,ServiceId=%s,ServiceObj=%s,Status=%d \n",
		 	__func__, __LINE__,pxReq->sAction,pxReq->sServiceId,pxReq->sServiceObj,pxRes->iStatus);
               goto ErrorHandler;
		}
	 }



	if(pxRes->iStatus > IFX_CWMP_SUCCESS)
		suiRetStatus = pxRes->iStatus;
/*
	//Set the pointers back in SetIPInterfaceInfo
	if(strcmp(pxReq->sAction,"SetIPInterfaceInfo")==0) {
		if(pTmpNameVal != NULL) {
			pxReq->pxNameValue = pTmpNameVal;
		    	pxReq->uiNumNameValue = uiTmpNoElements;
		}

	}
*/
	//How to handle GetDefaultConnectionSrvice
		// ChildOid - NULL
		// ServiceObj Soap will fill
		// ServiceID Soap will fill
		// Keys are not present
		// ParamVal list will be NULL
		// Return the Default WANConnection Service ID
	if(     (strcmp(pxReq->sAction,"GetDefaultConnectionService") == 0) ||
		(strcmp(pxReq->sAction,"GetGenericForwardingEntry") == 0) ||
		(strcmp(pxReq->sAction,"GetSpecificForwardingEntry")  ==0) )
	  {

		if((strcmp(pxReq->sAction,"GetGenericForwardingEntry") == 0) ||
                (strcmp(pxReq->sAction,"GetSpecificForwardingEntry")  ==0) )
		{
			// search for interface parameter
			for(i=0;i<pxRes->uiNumNameValue;++i) {
				iParameter = -1;
				if(strcmp(pxRes->pxNameValue[i].sName,"Interface")==0){
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d] %s = '%s' \n", __func__ , __LINE__, pxRes->pxNameValue[i].sName, pxRes->pxNameValue[i].psValue);
					if(strcmp(pxRes->pxNameValue[i].psValue,"")){
						ppTempValue = &(pxRes->pxNameValue[i].psValue) ;
						iParameter = i;
					}
					break;
				}
			}
			if(iParameter < 0) // 0 or more can be the index of interface in array
				goto interface_end; // interface not there in input continue without conversion


		}else if(strcmp(pxReq->sAction,"GetDefaultConnectionService") == 0){
			ppTempValue = &(pxRes->pxNameValue->psValue);
		}

		if(ppTempValue == NULL) {
			pxRes->iStatus = IFX_TR64_ERR_ACTION_FAILED;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"psValue NULL \n", __func__, __LINE__);
			goto ErrorHandler;
		}

		// Get TR69_OID from tr69 name (DefaultConnectionService Value)
		// Get the ServiceId from tr69_OID
		// Create the UUID,URN tuple with this ServiceId
		if(ppTempValue!=NULL){
        	    iRet = IFX_GlobalNameOidConversion(*ppTempValue, aiTR69_OID);	
		}
		if(iRet != IFX_CWMP_SUCCESS) {
			pxRes->iStatus = IFX_TR64_ERR_ACTION_FAILED;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Getting tr69 OID from Name failed \n",
			 __func__, __LINE__,pxRes->pxNameValue->psValue);
			goto ErrorHandler;
		}
		iRet = IFX_GetServiceIdFromTR69Id(aiTR69_OID,sServiceId);
		if(iRet != IFX_CWMP_SUCCESS) {
			pxRes->iStatus = IFX_TR64_ERR_ACTION_FAILED;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Getting ServiceId from tr69 OID failed \n",
			 __func__, __LINE__);
			IFX_PrintOID(aiTR69_OID);
			goto ErrorHandler;
		}
		//Reset the instance and WAN**Connection OID to get WANConnectionDevice OID
		//Get the WANConnectionDevice ServiceID
		uiPos  = IFX_GetParamIdPos(aiTR69_OID);
		aiTR69_OID[uiPos]=0;
		aiTR69_OID[uiPos-1]=0;

		iRet = IFX_GetServiceIdFromTR69Id(aiTR69_OID,sCDServiceId);
		if(iRet != IFX_CWMP_SUCCESS) {
			pxRes->iStatus = IFX_TR64_ERR_ACTION_FAILED;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Getting ServiceID from tr69 OID failed \n",
			 __func__, __LINE__);
			IFX_PrintOID(aiTR69_OID);
			goto ErrorHandler;
		}
		//Change the device UUID with the WANConnectionDevice Cpeid
		//Form the uuid_urn_tuple
		uiCpeid =  atoi(strrchr(sCDServiceId,'-')+1);
		strcpy(sUUID,uuidvalue);
		iRet = IFX_TR64_GenUUID(uiCpeid,sWANConDevice_Name,sUUID);
		if(iRet != IFX_CWMP_SUCCESS) {
			pxRes->iStatus = IFX_TR64_ERR_ACTION_FAILED;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Generation of UUID failed Cpeid=%d,UUID=%s \n",
			 __func__, __LINE__,uiCpeid,sUUID);
	              goto ErrorHandler;
		}
	     	iRet =IFX_FormUuidUrnTuple(sUUID,sWANConDevice_Name,sServiceId,sWANConService_uuid_urn_tuple);
		if(iRet != IFX_CWMP_SUCCESS) {
			pxRes->iStatus = IFX_TR64_ERR_ACTION_FAILED;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"Formation of UUID_URN failed UUID=%s,ConDevName=%s,ServiceId=%s \n",
			 __func__, __LINE__,sUUID,sWANConDevice_Name,sServiceId);
			goto ErrorHandler;
		}
		//Copy the tuple into ParamVal List
		IFX_CWMP_FREE(*ppTempValue);
		*ppTempValue = IFIN_CWMP_MALLOC(sizeof(sWANConService_uuid_urn_tuple));
		if(*ppTempValue == NULL) {
			pxRes->iStatus = IFX_TR64_ERR_OUT_OF_MEMORY;
	        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
		 	"MALLOC Failed \n", __func__, __LINE__);
               		goto ErrorHandler;
		}

		strcpy(*ppTempValue,sWANConService_uuid_urn_tuple);
	  }
interface_end :

      if(strcmp(pxReq->sServiceObj,"WANDSLLinkConfig")==0)
      {
          if(strcmp(pxReq->sAction,"GetInfo")==0)
          {
                for (a=0; a<pxRes->uiNumNameValue; a++)
                {
		   if(strcmp(pxRes->pxNameValue[a].sName,"LinkType")==0)
                   {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s:%d] %s = '%s' \n", _FUNCL_, pxRes->pxNameValue[a].sName, pxRes->pxNameValue[a].psValue);
			if(strcmp(pxRes->pxNameValue[a].psValue,"EoA") == 0)
                        {
				sprintf(pxRes->pxNameValue[a].psValue, "PPPoE");
                        }
                        break;
                    }
                }
          }
      }
      if(strcmp(pxReq->sServiceObj,"WANPPPConnection")==0)
      {
          if(strcmp(pxReq->sAction,"GetInfo")==0)
          {
              iRet = IFX_CWMP_SUCCESS;
              iNumNameVal = pxRes->uiNumNameValue;

              pTmpResNameVal = IFX_CWMP_MALLOC((iNumNameVal+2) * sizeof(IFX_TR64_NameValue));
              if (pTmpResNameVal == NULL)
              {
                  IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] Out-Of-Memory\n", __func__, __LINE__);
                  pxRes->iStatus = IFX_TR64_ERR_OUT_OF_MEMORY;
                  goto ErrorHandler;
              }
              for(a=0; a<iNumNameVal; a++)
              {
                  strncpy(pTmpResNameVal[a].sName, pxRes->pxNameValue[a].sName, IFX_TR64_MAX_PARAM_NAME_LEN);
                   if(pxRes->pxNameValue[a].psValue != NULL)
                   {
                      ValSize = strlen(pxRes->pxNameValue[a].psValue);
                      if(ValSize != 0)
                      {
                          pTmpResNameVal[a].psValue = (char *)IFIN_CWMP_MALLOC(ValSize +1);
                          if (pTmpResNameVal[a].psValue == NULL)
                          {
                                 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] Out-Of-Memory\n", __func__, __LINE__);
                                 pxRes->iStatus = IFX_TR64_ERR_OUT_OF_MEMORY;
                                 iRet = IFX_CWMP_FAILURE;
                                 goto mem_handler;
                          }
                          else
                          {
                               strncpy(pTmpResNameVal[a].psValue, pxRes->pxNameValue[a].psValue, ValSize);
                          }
                      }
                   }
              } 

              /* Get TR69Id from ServiceId */
              iRet = IFX_GetTR69IdFromServiceId(pxReq->sServiceId, iaOID);
              if(iRet != IFX_CWMP_SUCCESS)
              {
                    pxRes->iStatus = IFX_TR64_ERR_ACTION_FAILED;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
			 	"Generation of TR69Id failed  \n", __func__, __LINE__);
                    iRet = IFX_CWMP_FAILURE;
                    goto mem_handler;
		}

              if(iaOID[2] == 1)
              {
                  ifx_config_get_value(FORMNAME("WANDevice.1.WANDSLInterfaceConfig.UpstreamMaxRate"), upstream_rate);
                  ifx_config_get_value(FORMNAME("WANDevice.1.WANDSLInterfaceConfig.DownstreamMaxRate"), downstream_rate);
              }
              else
              {
                  ifx_config_get_value(FORMNAME("WANDevice.2.WANEthernetInterfaceConfig.MaxBitRate"), upstream_rate);
                  strncpy(downstream_rate, upstream_rate, 16);
              }

              /*Copy UpstreamRate*/
              strncpy(pTmpResNameVal[a].sName, "UpstreamMaxBitRate", strlen("UpstreamMaxBitRate"));
              pTmpResNameVal[a].psValue = IFIN_CWMP_MALLOC(32);
              if (pTmpResNameVal[a].psValue == NULL)
              {
                  IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] Out-Of-Memory\n", __func__, __LINE__);
                  pxRes->iStatus = IFX_TR64_ERR_OUT_OF_MEMORY;
                  iRet = IFX_CWMP_FAILURE;
                  goto mem_handler;
              }
              else
              {
                  strncpy(pTmpResNameVal[a].psValue, upstream_rate, 16);
              }
              /*Copy DownstreamRate*/
              strncpy(pTmpResNameVal[a+1].sName, "DownstreamMaxBitRate", strlen("DownstreamMaxBitRate"));
              pTmpResNameVal[a+1].psValue = IFIN_CWMP_MALLOC(32);
              if (pTmpResNameVal[a+1].psValue == NULL)
              {
                  IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] Out-Of-Memory\n", __func__, __LINE__);
                  pxRes->iStatus = IFX_TR64_ERR_OUT_OF_MEMORY;
                  iRet = IFX_CWMP_FAILURE;
                  goto mem_handler;
              }
              else
              {
                  strncpy(pTmpResNameVal[a+1].psValue, downstream_rate, 16);
              }
              for(a=0; a<iNumNameVal; a++)
              {
                  IFX_CWMP_FREE(pxRes->pxNameValue[a].psValue);
              }
              IFX_CWMP_FREE(pxRes->pxNameValue);
              pxRes->pxNameValue = pTmpResNameVal;
              pxRes->uiNumNameValue += 2;
          }
      }
mem_handler:
      if((iRet == IFX_CWMP_FAILURE) && (pTmpResNameVal != NULL))
      {
          for(a=0; a<iNumNameVal+2; a++)
          {
              IFX_CWMP_FREE(pTmpResNameVal[a].psValue);
          }
          IFX_CWMP_FREE(pTmpResNameVal);
          goto ErrorHandler;
      }
      
      if((strcmp(pxReq->sAction,"RequestConnection")==0) ||
	(strcmp(pxReq->sAction,"RequestTermination")==0) ||
          (strcmp(pxReq->sAction,"ForceTermination")==0))
	{
	  IFIN_CWMP_FREE(pxReq->pxNameValue->psValue);
	  IFIN_CWMP_FREE(pxReq->pxNameValue);

	}

	if(pxReq->ucOper == IFX_TR64_OPER_GET) {
	//Map the StateVariable to Argument Names
	iRet = IFX_TR64_FwdRevMapArg(IFX_TR64_ARG_REV_MAP,pxReq->sAction,pxRes->pxNameValue,pxRes->uiNumNameValue);
	if(iRet != IFX_CWMP_SUCCESS) {
	       	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] :"
	 	"Reverse Mapping of State Variables failed \n",
		 __func__, __LINE__);
                goto ErrorHandler;
	}
	}
	//**** Error Mapping **********
	ErrorHandler:
		{
		IFX_TR64_ErrorMap(pxRes);
			if((strcmp(pxReq->sAction,"AddConnectionDeviceAndService")==0) ||
 	          	(strcmp(pxReq->sAction,"AddConnectionService")==0) ||
			(strcmp(pxReq->sAction,"SetIPInterfaceInfo")==0)) {
				if(pTmpNameVal != NULL) {
		    		pxReq->pxNameValue = pTmpNameVal;
		    		pxReq->uiNumNameValue = uiTmpNoElements;
				}
			}
		}

#ifdef IFX_TR69_WIFILAN
       finish:
#endif

       /***** SessionState = TR64_SESSION_INDIVIDUAL_RPC ************/
       // Persistence storage handling
       // Release the Lock
       // Reset the SessionState and SessionID
	if(suiSessionState == TR64_SESSION_INDIVIDUAL_RPC)
	{

	 suiSessionState = TR64_SESSION_STATE_INACTIVE;
	 memset(sTMLSessionID,'\0',IFX_TR64_MAX_SESSION_ID_LEN);

	//Sending the SOAP Response back to Control Point
        IFX_TR64_SOAP_FormResp(pxReq, pxRes);

	//Calling the tr64 Close where we want to handle the actions after closing
	//the session
	IFX_TR64_Close(pxReq, pxRes);

	if(guiChangeFlag == IFX_TR64_CHANGE_FLAG_SET) {
	if(pxRes->iStatus >= IFX_CWMP_SUCCESS) {
	 iRet = IFX_Config_Save();
		if(iRet != IFX_CWMP_SUCCESS) {
			        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Failed to "
			                    "write rc.conf to flash \n", __func__, __LINE__, iRet);
		}
	}
		/*
		   if(suiRetStatus != IFX_TR64_REBOOT_REQ) {
		      pxRes->iStatus = IFX_TR64_CHANGES_APPLIED;
	      	      strcpy(pxRes->sErrorString,"ChangesApplied");
	  	   } else {
	     		pxRes->iStatus = IFX_TR64_REBOOT_REQ;
   	     		strcpy(pxRes->sErrorString,"RebootRequired");
	     		suiRetStatus = 0;
	  	   }
		*/
	    }
		guiChangeFlag =IFX_TR64_CHANGE_FLAG_RESET;
	}
	else if (suiSessionState == TR64_SESSION_STATE_ACTIVE) {
        IFX_TR64_SOAP_FormResp(pxReq, pxRes);

		if(guiChangeFlag == IFX_TR64_CHANGE_FLAG_SET) {
			if(pxRes->iStatus >= IFX_CWMP_SUCCESS) {
	 			iRet = IFX_Config_Save();
				if(iRet != IFX_CWMP_SUCCESS) {
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Failed to "
					           "write rc.conf to flash \n", __func__, __LINE__, iRet);
				}
			}
			if(suiRetStatus != IFX_TR64_REBOOT_REQ) {
				pxRes->iStatus = IFX_TR64_CHANGES_APPLIED;
				strcpy(pxRes->sErrorString,"ChangesApplied");
			} else {
				IFX_TR64_Request dReq;
				IFX_TR64_Response dRes;

				pxRes->iStatus = IFX_TR64_REBOOT_REQ;
				strcpy(pxRes->sErrorString,"RebootRequired");
				suiRetStatus = 0;

				memset(&dReq, 0, sizeof(IFX_TR64_Request));
				memset(&dRes, 0, sizeof(IFX_TR64_Response));
				strcpy(dReq.sAction, "ConfigurationFinished");
				dReq.ucOper = IFX_TR64_OPER_CONF_FINISH;
				strcpy(dReq.sServiceObj, pxReq->sServiceObj);

				dRes.iStatus = IFX_CWMP_SUCCESS;
				strcpy(dRes.sErrorString, pxRes->sErrorString);
				dRes.uiNumNameValue = 1;
				dRes.pxNameValue = IFX_CWMP_MALLOC(1 * sizeof(IFX_TR64_NameValue));
				if (dRes.pxNameValue == NULL) {
				} else {
					dRes.pxNameValue[0].psValue = IFX_CWMP_MALLOC(strlen(pxRes->sErrorString) + 1);
					if (dRes.pxNameValue[0].psValue == NULL) {
					} else {
						strcpy(dRes.pxNameValue[0].psValue, pxRes->sErrorString);
						strcpy(dRes.pxNameValue[0].sName, "Status");
					}
				}
				IFX_TR64_SOAP_FormResp(&dReq, &dRes);
				IFX_CWMP_FREE(dRes.pxNameValue[0].psValue);
				IFX_CWMP_FREE(dRes.pxNameValue);
			}
		}
	}
	IFX_CWMP_FREE(psName);
	return iRet;

}


#ifdef IFX_TR69_WIFILAN
/* kamal for handling the WLAN Security keys Get and Set */								 
int32 IFX_TR64_SecurityKeysRequestHandler(IN IFX_TR64_Request *pxReq,
                                          OUT IFX_TR64_Response *pxRes)
{
    int32  iRet = IFX_CWMP_SUCCESS;
    uint32 i, j, k, index=0, iFlags, flagwep=0, flagpsk=0;
    int32 keylen = 0, asciikey = 0;
    int32 cpeid =1;

    char8 *ptr=NULL;

    IFX_MAPI_WLAN_WEP_Cfg xWlan_wep;
    IFX_MAPI_WLAN_PersonalCfg xWlan_psk;
    IFX_MAPI_WLAN_SecCfg wlSec;

    memset(&xWlan_psk, 0x00, sizeof(IFX_MAPI_WLAN_PersonalCfg));
    memset(&xWlan_wep, 0x00, sizeof(IFX_MAPI_WLAN_WEP_Cfg));
    memset(&wlSec, 0x00, sizeof(IFX_MAPI_WLAN_SecCfg));
	
    iFlags = IFX_F_MODIFY;

    cpeid = (pxReq->sServiceId[strlen(pxReq->sServiceId)-1]) - 0x30; // ASCII to hex

    if(!strcmp(pxReq->sAction,"GetSecurityKeys"))
    {

        IFX_API_LOG("inside GetSecurityKeys");

	wlSec.iid.cpeId.Id = cpeid;
	wlSec.iid.pcpeId.Id = 1;

	iRet = ifx_mapi_get_wlan_security_config(&wlSec,IFX_F_GET_ANY);
        if (iRet != IFX_CWMP_SUCCESS)
            goto errorHandler;

	pxRes->pxNameValue = IFIN_CWMP_MALLOC( 6 * sizeof(IFX_TR64_NameValue));
	if(pxRes->pxNameValue == NULL)
	{
		iRet = IFIN_CWMP_FAILURE;
		goto errorHandler;
	}
        pxRes->uiNumNameValue = 6;

	if(wlSec.beaconType == IFX_MAPI_WLAN_BEACON_BASIC) {
	    for (i = 0; i < IFX_MAPI_NUM_WEP_KEYS; i++)
            {
		if(pxRes->pxNameValue!=NULL){
                	pxRes->pxNameValue[i].psValue = IFIN_CWMP_MALLOC(IFX_MAPI_WEP_KEY_MAX_LEN+1);
		}
	        sprintf(pxRes->pxNameValue[i].sName, "WEPKey%d",i);

	        strncpy( pxRes->pxNameValue[i].psValue, wlSec.secParams.wepCfg.wepKey[i].wepKey, IFX_MAPI_WEP_KEY_MAX_LEN);
            }

	} else {
	    pxRes->pxNameValue[4].psValue = IFIN_CWMP_MALLOC(IFX_MAPI_PSK_MAX_LEN+1);
	    strcpy(pxRes->pxNameValue[4].sName, "PreSharedKey");
            pxRes->pxNameValue[5].psValue = IFIN_CWMP_MALLOC(IFX_MAPI_PASSPHRASE_MAX_LEN+1);
            strcpy(pxRes->pxNameValue[5].sName, "KeyPassphrase");

            if(wlSec.secParams.personalCfg.pskType == IFX_MAPI_WLAN_HEX_KEY) 
	        strncpy( pxRes->pxNameValue[4].psValue, wlSec.secParams.personalCfg.psk.preSharedKey,IFX_MAPI_PSK_MAX_LEN);
            else
	        strncpy( pxRes->pxNameValue[5].psValue, wlSec.secParams.personalCfg.psk.passPhrase, IFX_MAPI_PASSPHRASE_MAX_LEN);

	}		
    } 
    else if (!strcmp(pxReq->sAction,"SetSecurityKeys"))
    {

	IFX_API_LOG("inside SetSecurityKeys");

       	for (j = 0; j < IFX_MAPI_NUM_WEP_KEYS; j++)
	{
	    xWlan_wep.wepKey[j].iid.pcpeId.Id = cpeid;
        }
  
        iRet = ifx_mapi_get_wlan_wep_config(&xWlan_wep, IFX_F_GET_ANY);
        if (iRet != IFX_CWMP_SUCCESS)
            goto errorHandler;

        xWlan_psk.psk.iid.cpeId.Id = 1;
        xWlan_psk.psk.iid.pcpeId.Id = cpeid;

        iRet=ifx_mapi_get_wlan_personal_config(&xWlan_psk, IFX_F_GET_ANY);
        if (iRet != IFX_CWMP_SUCCESS)
            goto errorHandler;
	
	for(i=0;i<pxReq->uiNumNameValue;i++)
	{
            if(strlen(pxReq->pxNameValue[i].psValue) == 0)
                continue;

	    if((ptr=strstr(pxReq->pxNameValue[i].sName,"WEPKey")))
	    {
                ptr += strlen("WEPKey");
                index = atoi(ptr);
                keylen = strlen(pxReq->pxNameValue[i].psValue);

                if(keylen > 0) {
                    asciikey = 0;
                    for(k=0; k< strlen(pxReq->pxNameValue[i].psValue);k++)
                    {
                        if(!ishexdigit(pxReq->pxNameValue[i].psValue[k]))
                            asciikey = 1;
                    }
                    if (asciikey) {
                        xWlan_wep.wepKeyType = IFX_MAPI_WLAN_ASCII_KEY;
                        if (keylen == 5) {
                            xWlan_wep.wepEncrLevel = IFX_MAPI_WEP_ENCR_LVL_64BIT;
                        } else if (keylen == 13) {
                            xWlan_wep.wepEncrLevel = IFX_MAPI_WEP_ENCR_LVL_128BIT;
                        } else {
                            iRet = ERR_CWMP_INVAL_PARAM_VAL;
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, 
                               "[%s::%d] Invalid WEP key\n", __func__, __LINE__);
                            goto errorHandler;
                        }
                    } else {
                        xWlan_wep.wepKeyType = IFX_MAPI_WLAN_HEX_KEY;
			if (keylen == 10) {
                            xWlan_wep.wepEncrLevel = IFX_MAPI_WEP_ENCR_LVL_64BIT;
                        } else if (keylen == 26) {
                            xWlan_wep.wepEncrLevel = IFX_MAPI_WEP_ENCR_LVL_128BIT;
                        } else {
                            iRet = ERR_CWMP_INVAL_PARAM_VAL;
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, 
                               "[%s::%d] Invalid WEP key\n", __func__, __LINE__);
                            goto errorHandler;
                        }
                    }
                    xWlan_wep.wepKey[index].iid.config_owner = IFX_TR64;
                    strncpy(xWlan_wep.wepKey[index].wepKey,pxReq->pxNameValue[i].psValue, IFX_MAPI_WEP_KEY_MAX_LEN);
                    flagwep = 1;
                }
	    }
            else if (!strcmp(pxReq->pxNameValue[i].sName,"KeyPassphrase") &&
                    strlen(pxReq->pxNameValue[i].psValue) > 0)
            {
                keylen = strlen(pxReq->pxNameValue[i].psValue);
                if (keylen > 7 && keylen < IFX_MAPI_PASSPHRASE_MAX_LEN) {
                    strncpy(xWlan_psk.psk.passPhrase, pxReq->pxNameValue[i].psValue, IFX_MAPI_PASSPHRASE_MAX_LEN);
		    strcpy(xWlan_psk.psk.preSharedKey,"");
                }
		xWlan_psk.pskType = IFX_MAPI_WLAN_ASCII_KEY; 
#ifdef IFX_TR69_AEI_CUST
		system("echo 0 > /tmp/pskset");
#endif
                flagpsk = 1;
            }
            else if (!strcmp(pxReq->pxNameValue[i].sName,"PreSharedKey") &&
                    strlen(pxReq->pxNameValue[i].psValue) > 0)
            {
                xWlan_psk.pskType = IFX_MAPI_WLAN_HEX_KEY; 
		keylen = strlen(pxReq->pxNameValue[i].psValue);
                if (keylen < 8 || keylen > IFX_MAPI_PASSPHRASE_MAX_LEN) {
                    iRet = ERR_CWMP_INVAL_PARAM_VAL;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, 
                         "[%s::%d] Invalid key\n", __func__, __LINE__);
                    goto errorHandler;
                }
                for(k = 0; k < keylen; k++) {
                    if(!ishexdigit(pxReq->pxNameValue[i].psValue[k])) {
#ifndef IFX_TR69_AEI_CUST
                        iRet = ERR_CWMP_INVAL_PARAM_VAL;
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, 
                           "[%s::%d] Invalid key\n", __func__, __LINE__);
                        goto errorHandler;
#else
                        asciikey = 1;
			break;
#endif
                    }
                }
                strncpy(xWlan_psk.psk.preSharedKey,pxReq->pxNameValue[i].psValue,IFX_MAPI_PSK_MAX_LEN);
		strcpy(xWlan_psk.psk.passPhrase,"");

#ifdef IFX_TR69_AEI_CUST
		if(asciikey) {		 
			keylen = strlen(pxReq->pxNameValue[i].psValue);
			xWlan_psk.pskType = IFX_MAPI_WLAN_ASCII_KEY; 
		
        	        if (keylen > 7 && keylen < IFX_MAPI_PASSPHRASE_MAX_LEN) {
                	    strncpy(xWlan_psk.psk.passPhrase, pxReq->pxNameValue[i].psValue, IFX_MAPI_PASSPHRASE_MAX_LEN);
			    strcpy(xWlan_psk.psk.preSharedKey,"");
                	}
			system("echo 1 > /tmp/pskset");
		} else {
			system("echo 0 > /tmp/pskset");
		}
#endif	
                flagpsk = 1;
            }
	}

	if(flagwep) {
       		iRet = ifx_mapi_set_wlan_wep_config(IFX_OP_MOD, &xWlan_wep, iFlags);
        	if(iRet != IFX_SUCCESS) {
 	      		iRet = ERR_CWMP_INVAL_PARAM_VAL;
              		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
        	      		"ifx_set_wlan_wep_config -Modify Mgmt API returned error\n");

                          IFX_API_LOG("ifx_mapi_set_wlan_wep_config error");// kamal

              		goto errorHandler;
        	}
	}

	if(flagpsk) {
      		iRet = ifx_mapi_set_wlan_passphrase_config(IFX_OP_MOD, &(xWlan_psk.psk), iFlags);
        	if(iRet != IFX_SUCCESS) {
              		iRet = ERR_CWMP_INVAL_PARAM_VAL;
              		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                       		"%s:%d ifx_set_wlan_passphrase_config failed\n",_FUNCL_);

                          IFX_API_LOG("ifx_mapi_set_wlan_passphrase_config error");// kamal


              	goto errorHandler;
        	}
	}

    }

    errorHandler:
    if (iRet < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Error in processing Request\n",
                    __func__, __LINE__, iRet);

                          IFX_API_LOG("errorHandler");// kamal


        goto cleanup;
    }

    cleanup:
    /* Fill the status in response structure */
    pxRes->iStatus = iRet;
    return (iRet);				
}


int32 IFX_TR64_DefaultWEPKeyIndexHandler(IN IFX_TR64_Request *pxReq,
                                          OUT IFX_TR64_Response *pxRes)
{
    IFX_MAPI_WLAN_WEP_Cfg xWlan_wep;
    int32  iFlags, i, iRet = IFX_CWMP_SUCCESS;
    int32 cpeid =1;

    iFlags = IFX_F_MODIFY;

    memset(&xWlan_wep, 0x00, sizeof(IFX_MAPI_WLAN_WEP_Cfg));

    cpeid = (pxReq->sServiceId[strlen(pxReq->sServiceId)-1]) - 0x30; // ASCII to hex
    for (i = 0; i < IFX_MAPI_NUM_WEP_KEYS; i++)
    {
	xWlan_wep.wepKey[i].iid.pcpeId.Id = cpeid;
    }

    iRet = ifx_mapi_get_wlan_wep_config(&xWlan_wep, IFX_F_GET_ANY);
    if (iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s:%d\n", __func__,
	    __LINE__);
        goto errorHandler;
    }

    if (!strcmp(pxReq->sAction, "GetDefaultWEPKeyIndex")) {
        pxRes->uiNumNameValue = 1;
        pxRes->pxNameValue = IFIN_CWMP_MALLOC( 1 * sizeof(IFX_TR64_NameValue));
        pxRes->pxNameValue[0].psValue =
		IFIN_CWMP_MALLOC(12);
        sprintf(pxRes->pxNameValue[0].psValue, "%d",
			xWlan_wep.wepKeyIndex);
        strcpy(pxRes->pxNameValue[0].sName, "DefaultWEPKeyIndex");
    } else if (!strcmp(pxReq->sAction, "SetDefaultWEPKeyIndex")) {
        for (i = 0; i < pxReq->uiNumNameValue; i++) {
            if (!strcmp(pxReq->pxNameValue[i].sName, "DefaultWEPKeyIndex"))
                break;
	}
	xWlan_wep.wepKeyIndex = atoi(pxReq->pxNameValue[i].psValue);
        iRet = ifx_mapi_set_wlan_wep_config(IFX_OP_MOD, &xWlan_wep, iFlags);
        if (iRet != IFX_CWMP_SUCCESS) {
            iRet = ERR_CWMP_INVAL_PARAM_VAL;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d] Failed to set "
			    "WEP settings.\n", _FUNCL_);
	}
    }

errorHandler:
    pxRes->iStatus = iRet;
    return iRet;
}
#endif
/* end of hack */


