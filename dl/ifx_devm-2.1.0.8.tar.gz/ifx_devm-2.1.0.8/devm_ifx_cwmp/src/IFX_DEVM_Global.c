/*
** =============================================================================
** FILE NAME     : IFX_DEVM_Global.c 
** PROJECT       : TR69
** MODULES       : CWMP
** DATE          : 26-12-2011
** AUTHOR        : TR69 Team
** DESCRIPTION   : 
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted

** HISTORY       :
** $Date   $Author    $Comment
**
** ============================================================================
*/

#include "IFX_DEVM_Global.h"
#include "IFX_DEVM_Controller.h"
#include "IFX_DEVM_DS.h"
#include "IFX_DEVM_StackUtil.h"
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_OID.h"
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/types.h>
#include <signal.h>
#include <ctype.h>
#include <fcntl.h>

#ifndef CONFIG_PACKAGE_LIBOPENSSL
#define CONFIG_PACKAGE_LIBOPENSSL
#endif
 
#ifndef LTQ_CRYPT_AES_PASSWD
#define LTQ_CRYPT_AES_PASSWD
#endif
extern int get_modelKey( char *model_buf); 
const int BACKOFFCOUNT=5;

/*******************************************************************************
* Function: IFX_GBL_FormName 
* Desc: To form Name structure If DEVICE_SUPPORT then Device. will be selected otherwise InternetGatewayDevice.  
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS if FormName succeeds. -ve err
                code otherwise
*******************************************************************************/

int32 IFX_GBL_FormName(char * psParam_name, char *psObj_name)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    if(psObj_name == NULL)
    {
        iRet = IFX_CWMP_FAILURE;
        goto end;
    }
#ifdef DEVICE_SUPPORT
    sprintf(psObj_name,"Device.%s",psParam_name);
#else
    sprintf(psObj_name,"InternetGatewayDevice.%s",psParam_name);
#endif
end:
    return iRet;
}




/*******************************************************************************
* Function: IFX_GBL_FormLANName 
* Desc: To form Name structure If DEVICE_SUPPORT then Device.LAN. will be selected otherwise InternetGatewayDevice.LANDevice.1 
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS if FormLANName succeeds. -ve err
                code otherwise
*******************************************************************************/
int32 IFX_GBL_FormLANName(char * psParam_name, char *psObj_name)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    if(psObj_name == NULL)
    {
        iRet = IFX_CWMP_FAILURE;
        goto end;
    }
#ifdef DEVICE_SUPPORT
    sprintf(psObj_name,"Device.LAN.%s",psParam_name);
#else
    sprintf(psObj_name,"InternetGatewayDevice.LANDevice.1.%s",psParam_name);
#endif
end:
    return iRet;
}




/*******************************************************************************
* Function: IFX_GBL_GetDataModelRoot 
* Desc:  
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS if GetDataModelRoot succeeds. -ve err
                code otherwise
*******************************************************************************/
int32 IFX_GBL_GetDataModelRoot(char *psRoot_name)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    if(psRoot_name == NULL)
    {
        iRet = IFX_CWMP_FAILURE;
        goto end;
    }
#ifdef DEVICE_SUPPORT
    sprintf(psRoot_name,"Device");
#else
    sprintf(psRoot_name,"InternetGatewayDevice");
#endif
end:
    return iRet;
}




/*******************************************************************************
* Function: IFX_GBL_GetDeviceSupport 
* Desc:  
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS if GetDeviceSupport succeeds. -ve err
                code otherwise
*******************************************************************************/
int32 IFX_GBL_GetDeviceSupport(int *iDevice)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    if(iDevice == NULL)
    {
        iRet = IFX_CWMP_FAILURE;
        goto end;
    }
#ifdef DEVICE_SUPPORT
    *iDevice = 1;
#else
    *iDevice = 0;
#endif
end:
    return iRet;
}
/*******************************************************************************
* Function: ifx_encrypt_file 
* Desc: Encrypt the configuration file to be uploaded
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS or IFX_CWMP_FAILURE
*******************************************************************************/
int32 ifx_encrypt_file(char8 * caFileName)
{
    /*File to be uploaded is present in path specified by caFileName.(example: caFileName = "/tmp/rc.conf.gz")
      After encrypting it, the encrypted file should be put back in the same location with the
      same name */
#ifdef CONFIG_PACKAGE_LIBOPENSSL
	int32 RetValue = IFX_CWMP_FAILURE;
        char modelKey[50];
        if( get_modelKey(modelKey) < 0 ){
            RetValue = -1;
	    return RetValue;
        }
        if (ltq_file_encrypt_aes256 (modelKey, caFileName, "/tmp/rc.conf.gz") == 0)
           return IFX_CWMP_SUCCESS;
        else
           return IFX_CWMP_FAILURE;

#else
return IFX_CWMP_SUCCESS;
#endif 
}

/*******************************************************************************
* Function: ifx_decrypt_file 
* Desc: Decrypt the downloaded configuration file 
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS or IFX_CWMP_FAILURE
*******************************************************************************/
int32 ifx_decrypt_file(char8 * caFileName)
{
    /*Downloaded file is present in path specified by caFileName.(example: caFileName = "/tmp/rc.conf.gz")
      After decrypting it, the decrypted file should be put back in the same location with the
      same name */
    char8 caBuf[192] = { 0 };
#ifdef CONFIG_PACKAGE_LIBOPENSSL
        char modelKey[50];
#endif
	int32 RetValue = IFX_CWMP_FAILURE;
#ifdef CONFIG_PACKAGE_LIBOPENSSL
        rename("/tmp/sysconf.gz", "/tmp/upgd_rcconf.gz");
        if( get_modelKey(modelKey) < 0 ){
            RetValue = -1;
            goto LTQ_Handler;
        }
	if (ltq_file_decrypt_aes256 (modelKey, caFileName, "/tmp/sysconf1.gz") != 0) {
                if ( !unlink("/tmp/sysconf1.gz")){
			printf("failed to remove the file\n");
			return IFX_CWMP_FAILURE;
		}
        }
        if (access("/tmp/sysconf1.gz",F_OK) == -1 ){
            RetValue = -2;
            goto LTQ_Handler;
        }
    sprintf(caBuf, "mv /tmp/sysconf1.gz %s", caFileName);
    system(caBuf);
    return IFX_CWMP_SUCCESS;
#else
    return IFX_CWMP_SUCCESS;
#endif
LTQ_Handler:
	return RetValue;
}



/*******************************************************************************
* Function: IFX_GBL_GetDeviceLANSupport 
* Desc: 
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS if GetDeviceLANSupport succeeds. -ve err
                code otherwise
*******************************************************************************/
int32 IFX_GBL_GetDeviceLANSupport(int *iDeviceLAN)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    if(iDeviceLAN == NULL)
    {
        iRet = IFX_CWMP_FAILURE;
        goto end;
    }
#ifdef IFX_TR69_DEVICE_LAN 
    *iDeviceLAN = 1;
#else
    *iDeviceLAN = 0;
#endif
end:
    return iRet;
}

/*******************************************************************************
* Function: IFX_GBL_GetWLANSupport
* Desc:
* Parameters:
* Return Value: IFX_CWMP_SUCCESS if GetDeviceLANSupport succeeds. -ve err
                code otherwise
*******************************************************************************/
int32 IFX_GBL_GetWLANSupport(int *iWLAN)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    if(iWLAN == NULL)
    {
        iRet = IFX_CWMP_FAILURE;
        goto end;
    }
#ifdef IFX_TR69_WIFILAN
    *iWLAN = 1;
#else
    *iWLAN = 0;
#endif
end:
    return iRet;
}



/*******************************************************************************
* Function: IFX_GBL_GetRootOID 
* Desc: 
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS if GetRootOID succeeds. -ve err
                code otherwise
*******************************************************************************/
int32 IFX_GBL_GetRootOID(int *iOID)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    if(iOID == NULL)
    {
	iRet = IFX_CWMP_FAILURE;
	goto end;
    }
#ifdef DEVICE_SUPPORT
    *iOID = OID_IGD;
#else
    *iOID = OID_IGD;
#endif
end:
    return iRet;
}
