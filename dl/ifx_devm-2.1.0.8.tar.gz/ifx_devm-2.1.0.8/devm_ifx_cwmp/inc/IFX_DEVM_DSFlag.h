/*
** =============================================================================
** FILE NAME     : IFX_Flag.c
** PROJECT       : TR69
** MODULES       : 
** DATE          : 12-01-2006
** AUTHOR        : TR69 Team
** DESCRIPTION   : 
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date   $Author    $Comment
**
** ============================================================================
*/

#ifndef CWMP_FLAG_H
#define CWMP_FLAG_H

#ifdef __cplusplus
extern "C" {
#endif

#ifdef DEBUG_ENABLED
        void print_byte(int *byte);
#endif
        int set_field(unsigned int *pFlag, int start_bit, int end_bit, unsigned int value);
        unsigned int get_field(unsigned int Flag, int start_bit, int end_bit);


	int get_parent_instance_no(TR_069_INSTANCE *pInstance);
	int get_instance_no(TR_069_INSTANCE *pInstance);
	int set_instance_no(TR_069_INSTANCE *pInstance, unsigned int value);

	int set_instance_flag(TR_069_INSTANCE *pInstance, unsigned int level, ...);
	int clear_instance_flag(TR_069_INSTANCE *pInstance);

	int set_flag_level(TR_069_INSTANCE *pInstance, int level);
	
	int compare_flag(unsigned int (*flag1)[], unsigned int (*flag2)[]);

	int is_ancestor(TR_069_INSTANCE *pAncestor, TR_069_INSTANCE *pInstance);

	int itoa(int number, char number_string[5]);



#ifdef __cplusplus
}
#endif

#endif //#ifndef CWMP_FLAG_H
