/*
** =============================================================================
** FILE NAME     : IFX_HTTP.h
** PROJECT       : TR69
** MODULES       : HTTP
** DATE          : 26-10-2005
** AUTHOR        : TR69 Team
** DESCRIPTION   : 
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date   $Author    $Comment
**
** ============================================================================
*/

#ifndef CWMP_HTTP_H
#define CWMP_HTTP_H

#ifndef DEVM_OVER_IPv6
#include "httpcookie.h"
#else
#include "IFX_DEVM_httpcookie.h"
#endif

#ifdef DEVM_OVER_IPv6
#include "IFX_DEVM_HttpParser.h"
#include "IFX_DEVM_URI.h"
#else
#include "sock.h"
#include "httpparser.h"
#endif


#ifdef __cplusplus
extern "C" {
#endif

// Start  ACSInfo 

#define HOST_NAME_SIZE 100
#define PORT_NAME_SIZE 100
#define URLSTR_LEN 256
typedef struct //ACS_Info_t
{
#ifdef DEVM_OVER_IPv6
	DEVM_SOCKINFO sock_info ; //ACS socket
	devm_http_parser_t  parser ;//pointer to parser
#else
	SOCKINFO sock_info ; //ACS socket
	http_parser_t  parser ;//pointer to parser
#endif
	char url_str [URLSTR_LEN];
	char tmp_url_str[URLSTR_LEN];		// stores url after redirection
	xboolean is_redirected;		// 1 if redirected 0 if not redirected
#ifdef DEVM_OVER_IPv6
	devm_uri_type url ;
#else
	uri_type url ;
#endif
	char host [HOST_NAME_SIZE] ;
	char port [PORT_NAME_SIZE] ;
	xboolean is_persistant ;
	xboolean is_connection_active ;
	xboolean authorization ;
	COOKIE_JAR *cookies;
}ACS_Info_t;

// End ACSInfo

#define MAX_DOWNLOAD_PARAMS             10

typedef struct  {
        char *name;
        char *val;
}download_params_type;

//ifx_cwmp_http_MakeMessage strings inputs

// max no of consecutive unauthorized messages to accept before closing
#define UNAUTHORIZED_CNT	2

#define MAX_DOWNLOAD_PENDING            2

#define MAX_AUTH_PARAM                  257

#define IFX_IPC_APP_ID_TransferComplete 202

#ifdef ALL_CAP_ON


#define HTTP_MAKE_MSG_DATE              "DATE: "
#define HTTP_MAKE_MSG_CONNECTION        "CONNECTION: close\r\n"
#define HTTP_MAKE_MSG_CONLEN            "CONTENT-LENGTH: "
#define HTTP_MAKE_MSG_SERVER            "SERVER: "
#define HTTP_MAKE_MSG_UA                "USER-AGENT: "
#define HTTP_MAKE_MSG_CONTYP            "CONTENT-TYPE: "
#define HTTP_MAKE_MSG_AUTH_DIGEST       "AUTHORIZATION: Digest "		
#define HTTP_MAKE_MSG_TENC              "TRANSFER-ENCODING: chunked\r\n"
#define HTTP_MAKE_MSG_HOST              "HOST: "

#else

#define HTTP_MAKE_MSG_DATE              "Date: "
#define HTTP_MAKE_MSG_CONNECTION        "Connection: Close\r\n"
#define HTTP_MAKE_MSG_CONLEN            "Content-Length: "
#define HTTP_MAKE_MSG_SERVER            "Server: "
#define HTTP_MAKE_MSG_UA                "User-Agent: "
#define HTTP_MAKE_MSG_CONTYP            "Content-Type: "
#define HTTP_MAKE_MSG_AUTH_DIGEST       "Authorization: Digest "
#define HTTP_MAKE_MSG_AUTH_BASIC        "Authorization: Basic "
#define HTTP_MAKE_MSG_TENC              "Transfer-Encoding: Chunked\r\n"
#define HTTP_MAKE_MSG_HOST              "Host: "

#endif


typedef struct{
	char cmdK[COMMANDKEY_LEN];
	char filetype[65];
	char url[257];
	char filename[257];
	int to;
	unsigned int maxsize;
	char *doc;
	int doc_len;
	char con_typ[50];
	int status;
	char StartTime[CURRENTTIME_LEN];
	char CompleteTime[CURRENTTIME_LEN] ;
	int faultCode;
	int MaxRetries;
        int WindowEnd;
} http_download_params_type ;

typedef struct{
    char caCmdKey[COMMANDKEY_LEN];
    char caFiletype[65];
    char caURL[257];
    char caUsername[257];
    char caPassword[257];
    int iDelaySecs;
    int iStatus;
    char caStartTime[CURRENTTIME_LEN];
    char caCompleteTime[CURRENTTIME_LEN] ;
} tUploadParam;

typedef struct{
    char caCmdKey[COMMANDKEY_LEN];
    char caFiletype[65];
    char caURL[257];
    char caUsername[257];
    char caPassword[257];
    int iDelaySecs;
    int iStatus;
    char caStartTime[CURRENTTIME_LEN];
    char caCompleteTime[CURRENTTIME_LEN] ;
} tScheduleDownloadParam;


int ltq_http_handle_inform(IN int iReason);
#ifndef DEVM_OVER_IPv6
xboolean ifx_http_is_socket_open (SOCKINFO *sock, int * timeout ) ;

int ifx_http_handle_msg(IN OUT ACS_Info_t *ACS_Info,
                         IN OUT http_parser_t * parser,
                         IN int timeout);
int ifx_http_open_connect (IN  char *url_str,
                                IN OUT ACS_Info_t *ACS_Info);

int ifx_http_dispatch_request(IN SOCKINFO * info,
                               http_parser_t * parser );

int ifx_http_analyze_parse_status (ACS_Info_t *ACS_Info, http_parser_t* parser );

int ifx_http_close_connection (ACS_Info_t * ACS_Info) ;

int ifx_http_close_session (ACS_Info_t * ACS_Info) ;

int ifx_http_close(int reason);

void ifx_http_remove_persistent (ACS_Info_t *ACS_Info);

void ifx_http_make_persistent (ACS_Info_t *ACS_Info);

int  ifx_http_MakeMessage( INOUT membuffer * buf,   IN int http_major_version,   IN int http_minor_version, IN const char *fmt,   ... );

int ifx_http_SendMessage( IN SOCKINFO * info,  IN OUT int *TimeOut,    IN const char *fmt,    ... );

xboolean ifx_http_is_parse_complete (http_parser_t *parser);

int ifx_http_download (download_params_type *download_params, IN int32 iStartTimer , int isSDFlag);

int ifx_http_auth_init();

int ifx_http_download_init();

int ifx_http_get_ACS_url(char *url_str);

int ifx_http_init();

//int ifx_http_Download( IN const char *url_str,     IN int timeout_secs,  IN unsigned int maxsize,    OUT char **document,     OUT int *doc_length,      OUT char *content_type );

//int ifx_http_Download(http_download_params_type *http_download_params );
int ifx_http_start_download();

int ifx_http_start_upload();

void ifx_http_download_status (int ret_code, int *faultCode);

void ifx_http_store_download_info();

void ifx_http_store_schedule_download_info();

void ifx_http_download_param_init();

ACS_Info_t * ifx_http_get_acs_info ();

int formatbuffer(char *pbuf, int sizebuf);

#else

xboolean ifx_http_is_socket_open (DEVM_SOCKINFO *sock, int * timeout ) ;

int ifx_http_handle_msg(IN OUT ACS_Info_t *ACS_Info,
                         IN OUT devm_http_parser_t * parser,
                         IN int timeout);
int ifx_http_open_connect (IN  char *url_str,
                                IN OUT ACS_Info_t *ACS_Info);

int ifx_http_dispatch_request(IN DEVM_SOCKINFO * info,
                               devm_http_parser_t * parser );

int ifx_http_analyze_parse_status (ACS_Info_t *ACS_Info, devm_http_parser_t* parser );

int ifx_http_close_connection (ACS_Info_t * ACS_Info) ;

int ifx_http_close_session (ACS_Info_t * ACS_Info) ;

int ifx_http_close(int reason);

void ifx_http_remove_persistent (ACS_Info_t *ACS_Info);

void ifx_http_make_persistent (ACS_Info_t *ACS_Info);

int  ifx_http_MakeMessage( INOUT membuffer * buf,   IN int http_major_version,   IN int http_minor_version, IN const char *fmt,   ... );

int ifx_http_SendMessage( IN DEVM_SOCKINFO * info,  IN OUT int *TimeOut,    IN const char *fmt,    ... );

xboolean ifx_http_is_parse_complete (devm_http_parser_t *parser);

int ifx_http_download (download_params_type *download_params, IN int32 iStartTimer , int isSDFlag);

int ifx_http_auth_init();

int ifx_http_download_init();

int ifx_http_get_ACS_url(char *url_str);

int ifx_http_init();

int ifx_http_start_download();

int ifx_http_start_upload();

void ifx_http_download_status (int ret_code, int *faultCode);

void ifx_http_store_download_info();

void ifx_http_store_schedule_download_info();

void ifx_http_download_param_init();

ACS_Info_t * ifx_http_get_acs_info ();

int formatbuffer(char *pbuf, int sizebuf);

#endif



#ifdef __cplusplus
}
#endif

#endif //#ifndef CWMP_HTTP_H
