/*
** =============================================================================
** FILE NAME     : IFX_CWMP_Error.h
** PROJECT       : TR69
** MODULES       : 
** DATE          : 15-06-2006
** AUTHOR        : TR69 Team
** DESCRIPTION   : 
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date   $Author    $Comment
**
** ============================================================================
*/
#ifndef __IFX_CWMP_ERROR_H__
#define __IFX_CWMP_ERROR_H__

#define CWMP_SUCCESS                    0
#define CWMP_FAILURE                    -1

//Generic CWMP Error Codes
#define IFIN_CWMP_SUCCESS               0
#define IFIN_CWMP_FAILURE               -1
#define IFX_CWMP_SUCCESS                0
#define IFX_CWMP_FAILURE                -1
#define IFX_CWMP_NEED_ACTIVATE		1
#define IFX_CWMP_NEED_REBOOT		2
#define IFX_CWMP_NEED_REBOOT_DONT_SAVE	3
#define IFX_CWMP_NO_REBOOT_SAVE	        4

// Error values
#define ERR_NOT_FOUND                   -2
#define ERR_FILE_CORRUPT                -3
#define ERR_NOT_SUPPORTED               -4
#define ERR_FILE_NOT_OPEN               -5
#define ERR_FSEEK_ERROR                 -6
#define ERR_RESOURCE_EXCEEDED           -7
#define CWMP_E_SOCK_ERROR               -8
#define ERR_OUT_OF_MEMORY               -9
#define ERR_VAL_NULL                    -10
#define ERR_INVAL_OBJ                   -11
#define ERR_NON_WRITABLE                -12
#define ERR_CWMP_INVAL_PARAM_NAME       -13
#define ERR_CWMP_INVAL_PARAM_VAL        -14
#define ERR_CWMP_INTERNAL               -15
#define ERR_CWMP_INVAL_ARGS             -16
#define ERR_CWMP_OBJ_NOT_SUPPORTED      -17
#define ERR_CWMP_FIFO_OPEN              -18
#define ERR_CWMP_FIFO_WRITE             -19
#define ERR_CWMP_FIFO_READ              -20
#define ERR_CWMP_FIFO_INVAL_MSG         -21
#define ERR_CWMP_INVAL_INPUT_PARAM      -22
#define ERR_CWMP_INVAL_OPER             -23
#define ERR_CWMP_BUFFER_OVERFLOW        -24
#define ERR_CWMP_PARAM_NOT_SUPPORTED    -25
#define ERR_CWMP_TIMEOUT                -26
#define ERR_CWMP_FILE_OPEN              -27
#define ERR_CWMP_METHOD_NOT_SUPPORTED   -28
#define ERR_CWMP_REQUEST_DENIED         -29 
#define ERR_CWMP_INVAL_PARAMETER_TYPE   -30 // associated with SetParameterValues only
#define ERR_CWMP_NOTIFICATION_REQ_REJ   -31 // associated with SetParameterAttributes method only
#define ERR_CWMP_DOWNLOAD_FAILURE       -32 // associated with Download or TransferComplete methods only
#define ERR_CWMP_UPLOAD_FAILURE         -33 // associated with Upload or TransferComplete methods only
#define ERR_CWMP_SERVER_AUTHEN_FAIL     -34 // File transfer server authentication failure 
                                            // associated with Upload, Download, or TransferComplete methods

#define ERR_CWMP_PARAMVAL_INVALID       -35
#endif /* __IFX_CWMP_ERROR_H__ */
