/*
** =============================================================================
** FILE NAME     : IFX_SOAP.c
** PROJECT       : TR69
** MODULES       : SOAP
** DATE          : 26-10-2005
** AUTHOR        : TR69 Team
** DESCRIPTION   : 
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date   $Author    $Comment
**
** ============================================================================
*/
#ifndef CWMP_SOAP_H
#define CWMP_SOAP_H

#ifdef DEVM_OVER_IPv6
#include "IFX_DEVM_SOCK.h"
#include "IFX_DEVM_URI.h"
#include "IFX_DEVM_HttpParser.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef int32 (*func)(IXML_Node *node);

typedef struct {
    char8 *rpcName;
    func funcptr;
}callbackTbl_t;

void IFX_SOAP_Init();
void IFX_SOAP_ResetConn();
//void IFX_SOAP_CloseConn();
void IFX_SOAP_TimerCB(int32 reason);
//void IFX_SOAP_StartTimer(int32 secs, int32 id);
void IFX_SOAP_CancelTimer(int32 id);

int32 IFX_SOAP_SendInform(Inform *inform, int32 authReq);
int32 IFX_SOAP_SendInformWAuth();
int32 IFX_SOAP_GetParamNamesRespSend(ParameterInfoStruct *paramInfo, int32 max);
int32 IFX_SOAP_GetParamValRespSend(ParameterValueStruct *pvs, int32 max);
int32 IFX_SOAP_GetRPCMethodsRespSend();
int32 IFX_SOAP_ACSRPCMethodSend();
int32 IFX_SOAP_GetParamAttrRespSend(ParameterAttributesStruct *pas, int32 max);
int32 IFX_SOAP_SetParamAttrRespSend();
int32 IFX_SOAP_SetParamValRespSend(int32 status);
int32 IFX_SOAP_AddObjRespSend(int32 instance, int32 status);
int32 IFX_SOAP_DelObjRespSend(int32 status);
int32 IFX_SOAP_RegisterCB(char8 *rpcName, func funcptr);
int32 IFX_SOAP_SendFaultResp(int32 err_code, struct paramFault (*pf)[], int32 num);
int32 IFX_SOAP_SendAck();
int32 IFX_SOAP_DownloadRespSend(char8 *download_resp);
int32 IFX_SOAP_UploadRespSend(char8 * psUploadResp);
int32 IFX_SOAP_GetAllQueuedTransfersRespSend(char8 * caTransferResp);
int32 IFX_SOAP_CancelTransferRespSend(char8 * caTransferResp);
int32 IFX_SOAP_ScheduleDownloadRespSend(char8 * caTransferResp);
int32 IFX_SOAP_RebootRespSend();
int32 IFX_SOAP_TransferCompleteSend();
int32 IFX_SOAP_ScheduleInformRespSend();
int32 IFX_SOAP_FactoryResetRespSend();
int32 IFX_SOAP_SendLastMsg();
#ifndef DEVM_OVER_IPv6
void IFX_SOAP_Callback(http_parser_t * parser, http_message_t * request, SOCKINFO * info );
#else
void IFX_SOAP_Callback(devm_http_parser_t * parser, devm_http_message_t * request, DEVM_SOCKINFO * info );
#endif
#ifdef IFX_TR69_CHUNKED_RESP
extern int32
IFX_SOAP_GPVSend_Chunked(ParameterValueStruct * xpPVS, int32 iMax, int32 iFirst,
		int32 iLast);
#endif

#ifdef __cplusplus
}
#endif

#endif //#ifndef CWMP_SOAP_H
