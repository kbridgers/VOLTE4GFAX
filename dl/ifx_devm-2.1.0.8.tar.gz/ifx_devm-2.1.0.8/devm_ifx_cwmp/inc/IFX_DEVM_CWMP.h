/*
** =============================================================================
** FILE NAME     : IFX_CWMP.h
** PROJECT       : TR69
** MODULES       : CWMP
** DATE          : 26-10-2005
** AUTHOR        : TR69 Team
** DESCRIPTION   : 
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date   $Author    $Comment
**
** ============================================================================
*/
#ifndef CWMP_CWMP_H
#define CWMP_CWMP_H

#include "IFX_DEVM_OSA.h"

#ifdef __cplusplus
extern "C" {
#endif

int32 giDelayedBackoff=0;
int32 IFX_CWMP_AppInit();
void IFX_CWMP_StartTimer(IN int32 secs, IN int32 id);
void IFX_CWMP_TimerCB(int32 iReason);
int32 IFX_CWMP_SendInform(int32 iReason);
int32 IFX_CWMP_GetRPCMethodsCB(IXML_Node *node);
int32 IFX_CWMP_GetRPCMethodsRespCB(IXML_Node *node);
int32 IFX_CWMP_InformRespCB(IXML_Node *node);
int32 IFX_CWMP_GetParamValCB(IXML_Node *node);
int32 IFX_CWMP_SetParamValCB(IXML_Node *node);
int32 IFX_CWMP_GetParamNamesCB(IXML_Node *node);
int32 IFX_CWMP_GetParamAttrCB(IXML_Node *node);
int32 IFX_CWMP_SetParamAttrCB(IXML_Node *node);
int32 IFX_CWMP_ScheduleInformCB(IXML_Node *node);
int32 IFX_CWMP_AddObjCB(IXML_Node *node);
int32 IFX_CWMP_DelObjCB(IXML_Node *node);
int32 IFX_CWMP_RebootCB(IXML_Node *node);
int32 IFX_CWMP_DownloadCB(IXML_Node *node);
int32 IFX_CWMP_UploadCB(IXML_Node *node);
int32 IFX_CWMP_CloseCB(IXML_Node *node);
int32 IFX_CWMP_FaultCB(IXML_Node *node);
int32 IFX_CWMP_FactoryResetCB(IXML_Node *node);
int32 IFX_CWMP_TransferCompleteRespCB(IXML_Node *node);
int32 IFX_CWMP_Close(int32 iReason);
int32 IFX_CWMP_DevMIndicate(int32 iTo, char8 *pcMsg, int32 iLen, int32 iReserved);
int32 IFX_CWMP_Notify(int32 iEvent, int32 iTo, char8 *notify, int32 length,
                      int32 iReserved);
int32 IFX_CWMP_UpdateFirmwareVersion();
int32 IFX_CWMP_ProcessEvent(int32 iType, char8 * pcMsg, int32 iLen, int32 iState);
int32 IFX_CWMP_GetAllQueuedTransfersCB();
int32 IFX_CWMP_CancelTransferCB(IXML_Node *node);
int32 IFX_CWMP_ScheduleDownloadCB(IXML_Node *node);

#ifdef __cplusplus
}
#endif

#endif //#ifndef CWMP_CWMP_H
