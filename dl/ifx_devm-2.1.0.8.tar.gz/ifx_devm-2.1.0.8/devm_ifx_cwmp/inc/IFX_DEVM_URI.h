/*******************************************************************************
 *
 * Copyright (c) 2000-2003 Intel Corporation 
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met: 
 *
 * - Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer. 
 * - Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution. 
 * - Neither name of Intel Corporation nor the names of its contributors 
 * may be used to endorse or promote products derived from this software 
 * without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL INTEL OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 ******************************************************************************/

#ifndef IFX_DEVM_URI_H
#define IFX_DEVM_URI_H

/*!
 * \file
 */

#if !defined(WIN32)
	#include <sys/param.h>
#endif

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>

#ifdef WIN32
	#include "inet_pton.h"
#else
	#include <netdb.h>      /* for struct addrinfo */
#endif
#include "upnp.h"

#ifdef WIN32
	#define strncasecmp strnicmp
#else
	/* Other systems have strncasecmp */
#endif

#ifdef __cplusplus
extern "C" {
#endif

/*! length for HTTP DATE: "DATE: Sun, 01 Jul 2000 08:15:23 GMT<cr><lf>" */
#define DEVM_HTTP_DATE_LENGTH 37

#define DEVM_SEPARATORS "()<>@,;:\\\"/[]?={} \t"
#define DEVM_MARK "-_.!~*'()"

/*! added {} for compatibility */
#define DEVM_RESERVED ";/?:@&=+$,{}"

#define DEVM_HTTP_SUCCESS 1
#define DEVM_FALSE 0
#define DEVM_TAB 9
#define DEVM_CR 13
#define DEVM_LF 10
#define DEVM_SOCKET_BUFFER_SIZE 5000

enum devm_hostType {
	DEVM_HOSTNAME,
	DEVM_IPv4address
};

enum devm_pathType {
	DEVM_ABS_PATH,
	DEVM_REL_PATH,
	DEVM_OPAQUE_PART
};

#ifdef WIN32
	/* there is a conflict in windows with other symbols. */
	enum devm_uriType  {
		devm_absolute,
		devm_relative
	};
#else
	enum devm_uriType  {
		DEVM_ABSOLUTE,
		DEVM_RELATIVE
	};
#endif

/*! 
 * \brief Buffer used in parsinghttp messages, urls, etc. generally this simply
 * holds a pointer into a larger array.
 */
typedef struct DEVM_TOKEN {
	char *buff;
	size_t size;
} devm_token;

/*!
 * \brief Represents a host port: e.g. "127.127.0.1:80" text is a token
 * pointing to the full string representation.
 */
typedef struct DEVM_HOSTPORT {
	/*! Full host port. */
	devm_token text;
	/* Network Byte Order */
	struct sockaddr_storage IPaddress;
} devm_hostport_type;

/*!
 * \brief Represents a URI used in devm_parse_uri and elsewhere
 */
typedef struct DEVM_URI{
	enum devm_uriType type;
	devm_token scheme;
	enum devm_pathType path_type;
	devm_token pathquery;
	devm_token fragment;
	devm_hostport_type hostport;
} devm_uri_type;

/*!
 * \brief Represents a list of URLs as in the "callback" header of SUBSCRIBE
 * message in GENA. "char *" URLs holds dynamic memory.
 */
typedef struct DEVM_URL_LIST {
	/*! */
	size_t size;
	/*! All the urls, delimited by <> */
	char *URLs;
	/*! */
	devm_uri_type *parsedURLs;
} DEVM_URL_list;

/*!
 * \brief Replaces an escaped sequence with its unescaped version as in
 * http://www.ietf.org/rfc/rfc2396.txt  (RFC explaining URIs)
 *
 * Size of array is NOT checked (MUST be checked by caller)
 *
 * \note This function modifies the string. If the sequence is an escaped
 * sequence it is replaced, the other characters in the string are shifted
 * over, and NULL characters are placed at the end of the string.
 *
 * \return 
 */
int devm_replace_escaped(
	/*! [in,out] String of characters. */
	char *in,
	/*! [in] Index at which to start checking the characters. */
	size_t index,
	/*! [out] . */
	size_t *max);

/*!
 * \brief Copies one URL_list into another.
 *
 * This includes dynamically allocating the out->URLs field (the full string),
 * and the structures used to hold the parsedURLs. This memory MUST be freed
 * by the caller through: free_URL_list(&out).
 *
 * \return
 * 	\li DEVM_HTTP_SUCCESS - On Success.
 * 	\li UPNP_E_OUTOF_MEMORY - On Failure to allocate memory.
 */
int devm_copy_URL_list(
	/*! [in] Source URL list. */
	DEVM_URL_list *in,
	/*! [out] Destination URL list. */
	DEVM_URL_list *out);

/*!
 * \brief Frees the memory associated with a URL_list.
 *
 * Frees the dynamically allocated members of of list. Does NOT free the
 * pointer to the list itself ( i.e. does NOT free(list)).
 */
void devm_free_URL_list(
	/*! [in] URL list object. */
	DEVM_URL_list *list);

/*!
 * \brief Function useful in debugging for printing a parsed uri.
 */
#ifdef DEBUG
void devm_print_uri(
	/*! [in] URI object to print. */
	devm_uri_type *in);
#else
static inline void devm_print_uri(devm_uri_type *in)
{
	return;
	in = in;
}
#endif

/*!
 * \brief Function useful in debugging for printing a token.
 */
#ifdef DEBUG
void devm_print_token(
	/*! [in] Token object to print. */
	devm_token *in);
#else
static inline void devm_print_token(
	/*! [in] Token object to print. */
	devm_token *in)
{
	return;
	in = in;
}
#endif

/*!
 * \brief Compares buffer in the token object with the buffer in in2.
 *
 * \return 
 * 	\li < 0, if string1 is less than string2.
 * 	\li == 0, if string1 is identical to string2 .
 * 	\li > 0, if string1 is greater than string2.
 */
int devm_token_string_casecmp(
	/*! [in] Token object whose buffer is to be compared. */
	devm_token *in1,
	/*! [in] String of characters to compare with. */
	const char *in2);

/*!
 * \brief Compares a null terminated string to a token (exact).
 *
 * \return 
 * 	\li < 0, if string1 is less than string2.
 * 	\li == 0, if string1 is identical to string2 .
 * 	\li > 0, if string1 is greater than string2.
 */
int devm_token_string_cmp(
	/*! [in] Token object whose buffer is to be compared. */
	devm_token *in1,
	/*! [in] String of characters to compare with. */
	char *in2);

/*!
 * \brief Compares two tokens.
 *
 * \return 
 * 	\li < 0, if string1 is less than string2.
 * 	\li == 0, if string1 is identical to string2 .
 * 	\li > 0, if string1 is greater than string2.
 */
int devm_token_cmp(
	/*! [in] First token object whose buffer is to be compared. */
	devm_token *in1,
	/*! [in] Second token object used for the comparison. */
	devm_token *in2);

/*!
 * \brief Parses a string representing a host and port (e.g. "127.127.0.1:80"
 * or "localhost") and fills out a devm_hostport_type struct with internet address
 * and a token representing the full host and port.
 *
 * Uses gethostbyname.
 */
int devm_parse_hostport(
	/*! [in] String of characters representing host and port. */
	char *in,
	/*! [in] Sets a maximum limit. */
	size_t max,
	/*! [out] Output parameter where the host and port are represented as
	 * an internet address. */
	devm_hostport_type *out);

/*!
 * \brief Removes http escaped characters such as: "%20" and replaces them with
 * their character representation. i.e. "hello%20foo" -> "hello foo".
 *
 * The input IS MODIFIED in place (shortened). Extra characters are replaced
 * with \b NULL.
 *
 * \return UPNP_E_SUCCESS.
 */
int devm_remove_escaped_chars(
	/*! [in,out] String of characters to be modified. */
	char *in,
	/*! [in,out] Size limit for the number of characters. */
	size_t *size);

/*!
 * \brief Removes ".", and ".." from a path.
 *
 * If a ".." can not be resolved (i.e. the .. would go past the root of the
 * path) an error is returned.
 *
 * The input IS modified in place.)
 *
 * \note Examples
 * 	char path[30]="/../hello";
 * 	devm_remove_dots(path, strlen(path)) -> UPNP_E_INVALID_URL
 * 	char path[30]="/./hello";
 * 	devm_remove_dots(path, strlen(path)) -> UPNP_E_SUCCESS, 
 * 	in = "/hello"
 * 	char path[30]="/./hello/foo/../goodbye" -> 
 * 	UPNP_E_SUCCESS, in = "/hello/goodbye"
 *
 * \return 
 * 	\li UPNP_E_SUCCESS - On Success.
 * 	\li UPNP_E_OUTOF_MEMORY - On failure to allocate memory.
 * 	\li UPNP_E_INVALID_URL - Failure to resolve URL.
 */
int devm_remove_dots(
	/*! [in] String of characters from which "dots" have to be removed. */
	char *in,
	/*! [in] Size limit for the number of characters. */
	size_t size);

/*!
 * \brief resolves a relative url with a base url returning a NEW (dynamically
 * allocated with malloc) full url.
 *
 * If the base_url is \b NULL, then a copy of the  rel_url is passed back if
 * the rel_url is absolute then a copy of the rel_url is passed back if neither
 * the base nor the rel_url are Absolute then NULL is returned. Otherwise it
 * tries and resolves the relative url with the base as described in
 * http://www.ietf.org/rfc/rfc2396.txt (RFCs explaining URIs).
 *
 * The resolution of '..' is NOT implemented, but '.' is resolved.
 *
 * \return 
 */
char *devm_resolve_rel_url(
	/*! [in] Base URL. */
	char *base_url,
	/*! [in] Relative URL. */
	char *rel_url);

/*!
 * \brief Parses a uri as defined in http://www.ietf.org/rfc/rfc2396.txt
 * (RFC explaining URIs).
 *
 * Handles absolute, relative, and opaque uris. Parses into the following
 * pieces: scheme, hostport, pathquery, fragment (path and query are treated
 * as one token)
 *
 * Caller should check for the pieces they require.
 *
 * \return
 */
int devm_parse_uri(
	/*! [in] Character string containing uri information to be parsed. */
	char *in,
	/*! [in] Maximum limit on the number of characters. */
	size_t max,
	/*! [out] Output parameter which will have the parsed uri information. */
	devm_uri_type *out);

/*!
 * \brief Same as devm_parse_uri(), except that all strings are unescaped
 * (%XX replaced by chars).
 *
 * \note This modifies 'pathquery' and 'fragment' parts of the input.
 *
 * \return 
 */
int devm_parse_uri_and_unescape(
	/*! [in] Character string containing uri information to be parsed. */
	char *in,
	/*! [in] Maximum limit on the number of characters. */
	size_t max,
	/*! [out] Output parameter which will have the parsed uri information. */
	devm_uri_type *out);

/*!
 * \brief 
 *
 * \return 
 */
int devm_parse_token(
	/*! [in] . */
	char *in,
	/*! [out] . */
	devm_token *out,
	/*! [in] . */
	int max_size);

#ifdef __cplusplus
}
#endif

int
DEVM_http_FixStrUrl( IN char *urlstr,
                IN int urlstrlen,
				                                OUT devm_uri_type * fixed_url );

int
DEVM_http_FixUrl( IN devm_uri_type * url,
             OUT devm_uri_type * fixed_url );

int DEVM_token_string_casecmp( devm_token * in1,
                           char *in2 );

#endif /* IFX_DEVM_URI_H */


