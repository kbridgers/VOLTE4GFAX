/*
** =============================================================================
** FILE NAME     : IFX_Global.h
** PROJECT       : TR69
** MODULES       : 
** DATE          : 26-10-2005
** AUTHOR        : TR69 Team
** DESCRIPTION   : 
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date   $Author    $Comment
**
** ============================================================================
*/

#ifndef CWMP_GLOBAL_H
#define CWMP_GLOBAL_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
 
#include "IFX_DEVM_Error.h"
#include "IFX_DEVM_OSA.h"
#include <syslog.h>

#ifdef TR69SYSLOG
#define IFX_DBG_LVL_ERROR             LOG_ERR
#define IFX_DBG_LVL_LOW               LOG_ERR
#define IFX_DBG_LVL_NORMAL            LOG_ERR
#define IFX_DBG_LVL_HIGH              LOG_DEBUG
#define IFX_DBG_LVL_NONE              LOG_DEBUG

#define IFX_DBG_Log(x,y,z,args...)    syslog( y, z,##args)
#endif

#ifdef STUNNEL_SSL
#ifdef MIPSTARGET
#define IFX_CWMP_SSL_CONF_FILENAME    "/etc/tr69/stunnel.conf" 
#define IFX_CWMP_SSL_EXE              "/usr/bin/stunnel" 
#define IFX_CWMP_SSL_PID_FILE         "/var/run/ssl.pid"
#else
#define IFX_CWMP_SSL_CONF_FILENAME    "./stunnel.conf" 
#define IFX_CWMP_SSL_EXE              "/usr/sbin/stunnel" 
#define IFX_CWMP_SSL_PID_FILE         "/tmp/ssl.pid"
#endif
#endif

#define  TR69_ENV_FILE  "/mnt/data/devm_env.sh"


#ifdef MATRIX_SSL
#ifdef MIPSTARGET
#define IFX_CWMP_SSL_EXE              "/bin/tunnel" 
#define IFX_CWMP_SSL_PID_FILE         "/var/run/ssl.pid"
#else
#define IFX_CWMP_SSL_EXE              "/usr/sbin/tunnel" 
#define IFX_CWMP_SSL_PID_FILE         "/tmp/ssl.pid"
#endif
#endif


#define SSL_PORT                      "8001"
#define SSL_IP                        "127.0.0.1"
#define SSL_URL                       "http://" SSL_IP ":" SSL_PORT 

#ifdef DEVICE_SUPPORT
#define TR69_DATAMODEL_ROOT          "Device"
#else
#define TR69_DATAMODEL_ROOT          "InternetGatewayDevice"
#endif

#ifdef DEVICE_SUPPORT
#define TR69_DATA_MODEL_LAN          "Device.LAN"
#else
#define TR69_DATA_MODEL_LAN          "InternetGatewayDevice.LANDevice.1"
#endif

#define FORMLANNAME(param) TR69_DATA_MODEL_LAN "." param

//#define FORMNAME(p) ({char tmp[400]; sprintf(tmp,"%s%s",TR69_DATA_MODEL_ROOT,p2);tmp;})
#define FORMNAME(param) TR69_DATAMODEL_ROOT "." param

#ifdef STUN_SUPPORT
#define IFX_STUN_TIMOUT               10*60*1000     //10 mins
#endif

#define IFIN_CWMP_MALLOC(x) ({calloc(1,x);})
#define IFX_CWMP_MALLOC(x) ({calloc(1,x);})

#define IFIN_CWMP_CALLOC(x,y) ({calloc(x,y);})
#define IFX_CWMP_CALLOC(x,y) ({calloc(x,y);})

#define IFIN_CWMP_REALLOC(x,y) ({realloc(x,y);})
#define IFX_CWMP_REALLOC(x,y) ({realloc(x,y);})

#define IFIN_CWMP_FREE(x) \
if(x) \
{ \
    free(x); \
    x = NULL; \
}

#define IFX_CWMP_FREE(x) \
if(x) \
{ \
    free(x); \
    x = NULL; \
}

#ifdef DEBUG1
#define DEBUG1(x) x
#else
#define DEBUG1(x)
#endif


#ifdef DEBUG2
#define DEBUG2(x) x
#else
#define DEBUG2(x)
#endif

#ifdef DEBUG3
#define DEBUG3(x) x
#else
#define DEBUG3(x)
#endif

/* TBD: the IPC ucFrom parameter should be less than 256 since it is uchar8 */
#define  IFX_IPC_APP_ID_PSEDUO_SERVER    100
#define  IFX_IPC_APP_ID_NotifyEventTask  200
#define  IFX_IPC_APP_ID_NotifyPassive    201
#define  IFX_IPC_APP_ID_MAP              202
#define  IFX_IPC_APP_ID_GET_TR69ID       203
#define  IFX_IPC_APP_ID_ADD_OBJ          204
#define  IFX_IPC_APP_ID_DEL_OBJ          205
#define  IFX_IPC_APP_ID_ACTIVE_NOTIFY    206
#define  IFX_IPC_APP_ID_PERIODIC_INFORM  207
#define  IFX_IPC_APP_DIAGNOSTIC          208
#define  IFX_IPC_APP_ID_DEL_NOTIFY       209
#define  IFX_IPC_APP_ID_STUN             210
#define  IFX_IPC_APP_ID_DHCPD            211
#define  IFX_IPC_APP_ID_DHCPC            212
#define  IFX_IPC_APP_ID_BOOTSTRAP        213
#define  IFX_IPC_APP_ID_EVENT            214
#define  IFX_IPC_APP_ID_WATCHDOG         218
#define  IFX_IPC_APP_ID_DEVM_INDICATOR   219
#define  IFX_IPC_APP_ID_NOTIFY_INDICATOR 220
#define  IFX_IPC_APP_ID_UPLOAD           221
#define LTQ_IPC_APP_ID_DHCP_LEASE_CHANGE 222


/*  used in DevM Indicator */
#define IFX_DEVM_INDICATE_DIRTY          1
#define IFX_DEVM_INDICATE_BOOTSTRAP      2

#define TRUE                            1
#define FALSE                           0

#ifdef IFX_IPC_SS_FIFO
#undef IFX_IPC_SS_FIFO
#endif

#define IFX_IPC_TR_FIFO                 "/tmp/tr"
#define IFX_RCTAG_SEP                   "^"
#define TR69OID_SEP                     ".\0"

/* FIFO for Watchdog communication channel */
#define IFX_IPC_WD_FIFO                 "/tmp/wd"

/* FIFO for Debug enable/disable */
#define IFX_IPC_DBG_FIFO                 "/tmp/tr69_dbg"

#define IFX_IPC_WD_RESET(ppid)		do { \
					kill((ppid), SIGHUP); \
					} while (0)

#define IFX_ADD_IPTABLE_RULE            1
#define IFX_DEL_IPTABLE_RULE            2

#define IFX_CWMP_IPQOS_MGMT_STOP        1
#define IFX_CWMP_IPQOS_MGMT_START       2

/* FIFO used by Protocol API to receive messages from TR69 stack. */
#define IFX_IPC_PROTO_API_FIFO          "/tmp/protoapi"

#define MSGBUF_SIZE                     8192

/*Error flag defines*/
#define DL_SCHEDULE_NO_CHANGE 1
#define DL_NEXT_NO_DELAY 2
#define DL_NEXT_WITH_DELAY 3
#define DL_NEXT_ERROR 4

//String length for 
#define MANUFACTURER_LEN                64      // Should be 65 for '\0'
#define OUI_LEN                         33
#define PRODUCTCLASS_LEN                64
#define SERIALNUMBER_LEN                64
#define EVENTCODE_LEN                   32      // TR69 specifies 64.
#define COMMANDKEY_LEN                  33
#define CURRENTTIME_LEN                 30      // 2005-02-18T10:02:00-05:00
#define PARAMNAME_LEN                   144     // PARAMNAME is 256
#define PARAMVALUE_LEN                  65
#define MAX_NUM_EVENT_STRUCT            16      // TR69 specifies 16.
#define HEADER_ID_LEN                   65

#define PEND_EV_BOOTSTRAP               0x1
#define PEND_EV_BOOT                    0x2
#define PEND_EV_PERIODIC                0x4
#define PEND_EV_SCHEDULED               0x8
#define PEND_EV_VALUE_CHANGE            0x10
#define PEND_EV_CONN_REQ                0x20
#define PEND_EV_MDOWNLOAD               0x40
#define PEND_EV_DIAGNOSTIC              0x80
#define PEND_EV_MREBOOT                 0x100
#define PEND_EV_AUTH_REQ                0x200
#define PEND_EV_REQ_DOWNLOAD            0x400
#define PEND_EV_MUPLOAD                 0x800
#define PEND_EV_MSCHEDULE_DOWNLOAD     0x1000

// Pending tasks
#define PEND_TASK_FACTORYRESET          0x1
#define PEND_TASK_DOWNLOAD              0x2
#define PEND_TASK_REBOOT                0x4
#define PEND_TASK_SETACTIVATE           0x8
#define PEND_TASK_UPLOAD                0x10
#define PEND_TASK_REBOOT_NOSAVE         0x20
#define PEND_TASK_DELACTIVATE           0x40
#define PEND_TASK_DHCPD                 0x80
#define PEND_TASK_UPDATE_HTTPDL_TIMER   0x100
#define PEND_TASK_DHCPC                 0x200
#define PEND_TASK_UPDATE_HTTPUL_TIMER   0x400
#define PEND_TASK_UPDATE_HTTPSDL_TIMER  0x800
#define PEND_TASK_SCHEDULE_DOWNLOAD    0x1000

//HTTP_CLOSE REASON
#define HTTP_EMPTY_CLOSE                1
#define HTTP_CLOSE_10                   2
#define HTTP_CLOSE_11                   3
#define SOAP_EMPTY_CLOSE                4
#define SOAP_NOMORE_REQUEST             5
#define HTTP_RETURN_302                 6
#define HTTP_RETURN_204                 7
#define HTTP_RETURN_UNAUTHORIZED        8

//Close session reasons
#define SESSION_CLOSE                   1       // close the connection and end session
#define EMPTY_RESPONSE                  2       // Content-Length: 0
#define REDIRECT_RESPONSE               3       // 301, 302, 307 HTTP Response
#define CONNECTION_CLOSE                4       // close connection but not session


// Error values sent in SOAP messages
#define ERR_METHOD_NOT_SUPPORTED        9000
#define ERR_REQUEST_DENIED              9001
#define ERR_INTERNAL_ERROR              9002
#define ERR_INVALID_ARGUMENTS           9003
#define ERR_RESOURCES_EXCEEDED          9004
#define ERR_INVAL_PARAMETER_NAME        9005
#define ERR_INVAL_PARAMETER_TYPE        9006
#define ERR_INVAL_PARAMETER_VAL         9007
#define ERR_NON_WRITABLE_PARAM          9008
#define ERR_NOTIFICATION_REQ_REJ        9009
#define ERR_DOWNLOAD_FAILURE            9010
#define ERR_UPLOAD_FAILURE              9011
#define ERR_SERVER_AUTHEN_FAIL          9012
#define ERR_UNSUPPORTED_PROTOCOL        9013
#define ERR_CANCEL_TRANSFER_NOT_PERMITTED 9021

#define SOAP_TIMEOUT             0

//#define SREQ_HDR_NOT_FOUND            -1
//#define SREQ_BAD_HDR_FORMAT           -2

#define SOAP_INVALID_ACTION             401
#define SOAP_INVALID_ARGS               402
#define SOAP_OUT_OF_SYNC                403
#define SOAP_INVALID_VAR                404
#define SOAP_ACTION_FAILED              501

/* Maximum number of parameters within an object */
#define MAX_OBJ_PARAMS			50
// let this 3 #defines be same for the time being 
#define QUERY_LIST_SIZE                 30
/* Used for SetParamValues. Limit the max set elements in an envelope */
#define MAX_NO_OF_RESPONSES             50
//Average length of GetParmVal RPC is 320 bytes
//#define MAX_GET_PARAM_VAL               ((MSGBUF_SIZE * 6)/325) //403
#define MAX_ADD_SUBTREE                 150
//Average length of GetAttrValResp RPC is 400 bytes
//#define MAX_GET_ATTR_VAL                ((MSGBUF_SIZE * 6)/280)
/* At a max only one object is allowed at time */
#define MAX_SET_ATTR_VAL                350
/* Avg size per elem in GPN is 160 Bytes */
//#define MAX_GET_PARAM_NAMES             ((MSGBUF_SIZE * 4)/162) //809
#define MAX_ELEMENTS                    35
//"UDPConnectionRequestAddressNotificationLimit" is 44 characters
#define MAX_LEAF_LEN                    52    
//InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANIPConnection.1.PortMapping.1.
#define CWMP_OBJ_NOLEAF_LEN             128
#define CWMP_MAX_OBJ_LEN                CWMP_OBJ_NOLEAF_LEN + MAX_LEAF_LEN
#define MAX_SET_PARAM_ATTR_VAL          256
/* Number of times the stack should try to send an Inform before FactoryReset
   is performed */
#define MAX_NUM_RETRY                   12

#define PERINFENA_CHANGE 1
#define PERINFINT_CHANGE 2

//TIMER Constants
#define TM_PERIODIC_TIMER_ID            1800
/* Soap Msg Timeout is 30 secs */
#define TM_MSG_TIMEOUT_SECS             (1000 * 30)
#define TM_MSG_TIMEOUT_ID               30
#define TM_SCHEDULE_TIMER_ID            60
#define TM_SESSRETRY_TIMER_ID           65
#define TM_HTTPDL_TIMER_ID              70
#define TM_HTTPUL_TIMER_ID              71
#define TM_HTTPSDL_TIMER_ID             72
#define TM_SYSINIT_TIMER_ID             76

#define TM_PORTMAPPINGLEASE_TIMER_ID    77
#define FIRMWARE_VERSION_FILE           "/proc/mei/version"

#define OP_GETVAL                       1
#define OP_SETVAL                       2
#define OP_UPDATE_CHILDINFO             3

#define OP_SETVAL_VALIDATE              1
#define OP_SETVAL_ADD                   2
#define OP_SETVAL_MODIFY                3
#define OP_SETVAL_COMMIT                4
#define OP_SETVAL_UNDO                  5
#define OP_SETVAL_DELETE                6
#define OP_SETVAL_FREE                  7
#define OP_GETVAL_NORMAL                8
#define OP_GETVAL_NOTIFICATION          9
#define OP_SETVAL_CHK_MODIFY_DEP        10
#define OP_SETVAL_CHK_DEL_DEP           11
#define OP_SETVAL_CHK_DEL_ALLOWED       12
#define OP_UPDATE_CHILDINFO_ADD         13
#define OP_UPDATE_CHILDINFO_DEL         14
#define OP_SETVAL_ATTRINFO              15
#define OP_SETVAL_ACTIVATE              16
#define OP_GETVAL_INSTANCES             17
#define OP_PARAM_VALIDATE               18

#define NO_OF_FLAG                      6 //2
#define DEPTH_FIELD_START               1
#define DEPTH_FIELD_END                 1 //2 
#define INSTANCE_BIT_LENGTH             31 //10
#define OID_LENGTH                      (((((32 - (DEPTH_FIELD_END - DEPTH_FIELD_START + 1))/(INSTANCE_BIT_LENGTH)) * NO_OF_FLAG) *2) + 1)
#define MAGIC_NUMBER                    999999999
#define MAX_ENTRIES                     50
#define NO_OF_PARAMS_CHECKPOINT         200

#define IN
#define OUT
#define INOUT
#define PUBLIC
#define EXTERN extern

//Exit codes defined
#define EXIT_FUNC_NOT_REGISTERED        101
#define EXIT_DEFAULT_CASE               102
#define EXIT_VALIDATE_RO_PARAM          103
#define EXIT_UNSUPPORTED_PARAM          104
#define EXIT_PSEUDOSERVER_FAIL          105

//Owner's
#define ACC_WEB                         1   // WEB is Modifying it
#define ACC_TR69                        2   // ACS is Modifying it
#define ACC_ROOT                        3   // Protocol Stack Modifying it
#define ACC_TR64                        4   // TR64 is Modifying it
#define ACC_DHCP                        5   // DHCP is Modifying it
#define ACC_HTTPDL                      6   // HTTP Download in progress
#define ACC_HTTPUL                      7   // HTTP Upload in progress
#define ACC_UPNP						9   // UPnP is modifying it
#define ACC_END                         10   // Track max number of owners possible


#define TYPE_BOOL                       1
#define TYPE_UINT                       2
#define TYPE_INT                        3
#define TYPE_DATE                       4
#define TYPE_BASE64                     5
#define TYPE_STR                        6

#define FT_FIRMWARE                     1
#define FT_SYSCONF                      2

#define WANETH_VPI_VAL                  256
#define WANETH_VCI_VAL                  0
#define WANATM_VLAN_VAL                 4096

#define DB_FILE                         FILE_RC_CONF
#define _FUNCL_                         __func__, __LINE__

enum state_mc { NO_SESSION, SENT_INFORM, IN_SESSION
};

typedef int32 (*gblfunc) (int32 reason);

typedef struct {
    char8 *Name;
    gblfunc funcptr;
} gCallback;

typedef struct {
    int32 iFaultCode;
    char8 *psFaultDesc;
    char8 *psType;
} FaultTbl;

struct paramFault               // parameter for SetParameterResponse
{
    int32 faultCode;
    char8 *paramName;
    char8 *faultStr;
};

typedef struct {
    char8 *Name;
    char8 *Value;
    int32 Status;           /* In GetParamVal, returns the type of Value to soap
                               In SetParamVal, returns if the reboot is required to set any param */
    uint ValType;           /* The 'type' of the parameter as sent by ACS in the SPV RPC*/
} ParameterValueStruct;

typedef struct {
    char8 *Name;
    char8 *Value;
    char8 Support[3];            // T or F
    char8 Permissions[3];        // RO, RW, WO
    int32 Notif;                  // 0, 1 or 2
    char8 AccessList[12];        // NULL or Subscriber
    char8 Visibility[3];         // X, C, N
    int32 Exist;                  // 1 if object exists
} ParameterInfo;

typedef struct {
    struct {
        char8 caManufacturer[MANUFACTURER_LEN];
        char8 caOUI[OUI_LEN];
        char8 caProductClass[PRODUCTCLASS_LEN];
        char8 caSerialNumber[SERIALNUMBER_LEN];
    } xDeviceId;
    uint32 uiEV;        // Number of EventStruct
    struct {
        char8 caEvCode[EVENTCODE_LEN];
        char8 caCmdKey[COMMANDKEY_LEN];
    } xEvent[MAX_NUM_EVENT_STRUCT];
    uint32 uiMaxEnv;
    char8 caCurrTime[CURRENTTIME_LEN];  // Format 2005-02-18T10:02:00-05:00
    uint32 uiRetryCount;
    uint32 uiNumPVS;
    ParameterValueStruct *xpPVS;
} Inform;

typedef struct {
    uint32 numMethodList;
    char8 **MethodList;
} RPCMethods;

typedef struct {
    char8 *ParameterPath;
    uint32 NextLevel;
} ParameterNames;

/*Writable should be int. But when extracted from database it is string.
  and while composing message it goes as sting. So we keep it string*/
typedef struct {
    char8 *Name;
    char8 Writable[2];
} ParameterInfoStruct;

typedef struct {
    char8 *Name;
    int32 Notification;
    char8 *AccessList;
} ParameterAttributesStruct;

typedef struct {
    char8 *Name;
    int32 NotificationChange;
    char8 *Notification;
    int32 AccessListChange;
    char8 *AccessList;
} SetParameterAttributesStruct;

typedef struct {
    char8 *Interface;
    char8 *Host;
    int32 NumberOfRepetitions;
    int32 Timeout;
    int32 DataBlockSize;
    int32 DSCP;
} ipPing;

typedef struct {
    int32 SuccessCount;
    int32 AverageResponseTime;
    int32 MinimumResponseTime;
    int32 MaximumResponseTime;
} pingResp;

typedef struct {
    char8 *in_interface;         // Interface from which pkt to be received
    int32 ExternalPort;           // port on wan side
    int32 InternalPort;           // port on lan side
    char8 *PortMapProtocol;      // TCP or UDP
    char8 *InternalClient;       // ip address or host name 
} PortMapInfo;


typedef struct {
    int32 iaOID[OID_LENGTH];
    char8 *psRCTag;
} MetaData;

struct static_metadata {
    char8 access[3];
    char8 *validation_info;
    char8 *rc_tag;
    char8 value_type[6];
    int32 NotiStatus;
};

typedef struct {
    char8 *oid;
    char8 *accessList;
    char8 *notif;
} MapInfo;


typedef struct {
    char8 *Name;
    void *Value;
    void *pReserved;
    char8 *psRCTag;
    int32 iaOID[OID_LENGTH];
    int32 iAccessType;          //RO, RW
    int32 iFaultCode;
    char8 *psFaultStr;
} ParamVal;

struct default_value {
    char8 value[150];
    char8 value_type[6];
};



typedef struct operInfo {
    int32 iOper;
    int32 iSubOper;
    int32 iCaller;
} OperInfo;

typedef enum expectedState
{
    EXP_STATE_ENABLE,
    EXP_STATE_DISABLE,
    EXP_STATE_DONT_CARE
}ExpectedState;

struct InterfaceInfo {
    char8 caEther[6];
    int32 iLocalAddress;
};

typedef enum e_acsdiscoverystate { 
   ACS_DISCOVERY_DEFAULT_STATE=-1,
   ACS_DISCOVERY_NA=-2,
   ACS_DISCOVERY_DHCP_URL=1,
   ACS_DISCOVERY_DHCP_URL_SUCCESS=2,
   ACS_DISCOVERY_OTHER_URL=3,
   ACS_DISCOVERY_OTHER_URL_SUCCESS=4,
   ACS_DISCOVERY_FEATURE_DISABLE=-3
}e_ACSDISCOVERYSTATE;

typedef enum e_wan_def_con_name {
   DHCP=1,
   OTHER=2,
   DEFAULT=-1,
}e_WAN_DEF_CON_NAME;

int32 IFX_CWMP_IntDhcpInform_Main(IN struct InterfaceInfo **xInterface,char *psACS_URL);
int32 IFX_CWMP_SendDHCPInform (int32 iLocalsock, struct InterfaceInfo **xInterface,char *psACS_URL);
int ifx_ds_get_partial_oid( char *obj_copy, int oid[OID_LENGTH], struct static_metadata *pResponse);
void IntArrayToOIDString(IN int32 iaOID[OID_LENGTH], OUT char8 * psOID);

e_ACSDISCOVERYSTATE giAcsDiscoveryState;
e_WAN_DEF_CON_NAME giWanType;

extern int giRetryCount;

typedef struct horDep
{
    int32         iOID;
    ExpectedState eState;
}HorDep;

typedef struct objDep
{
    ExpectedState eParentState;
    ExpectedState eChildState;
    int32  iNumHorDep;
    HorDep *pxHorDepList;
} ObjDep;

typedef int32 (*modFunc) (IN OperInfo * ptxOI, INOUT void *pParamStruct,
                          IN int32 iNumElem, OUT void **ppRet,
                          OUT int32 * piNumRetElem);

typedef struct
{
    char8 sParamName[PARAMNAME_LEN];
    int32  iOID;
} IFX_PARAMNAME_OID_PAIR;

enum WanDevNum
{
    WAN_DEVICE_ATM = 1,
    WAN_DEVICE_MII0,
    WAN_DEVICE_MII1
};


 

int32 IFX_GBL_FormName(char * param_name, char *obj_name);
int32 IFX_GBL_FormLANName(char * param_name, char *obj_name);
int32 IFX_GBL_GetDataModelRoot(char *root_name);
int32 ifx_decrypt_file(char8 * caFileName);
int32 ifx_encrypt_file(char8 * caFileName);
int32 IFX_GBL_GetDeviceSupport(int *iDevice);
int32 IFX_GBL_GetDeviceLANSupport(int *iDeviceLAN);
int32 IFX_GBL_GetWLANSupport(int *iWLANSupport);
int32 IFX_GBL_GetRootOID(int *iOID);
#endif // #ifndef CWMP_GLOBAL_H
