/*
** =============================================================================
** FILE NAME     : IFX_Config.h
** PROJECT       : TR69
** MODULES       : 
** DATE          : 26-10-2005
** AUTHOR        : TR69 Team
** DESCRIPTION   : 
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date   $Author    $Comment
**
** ============================================================================
*/

#ifndef CWMP_CONFIG_H
#define CWMP_CONFIG_H


#ifdef __cplusplus
extern "C" {
#endif

#ifdef STUNNEL_SSL
        int ifx_stunnel_config_set_value(char *key, char *val);
#endif
        int startSSL(char *url, int operation);
        int stopSSL(int operation);

        //GLOBAL FUNCTIONS
        int IFX_GlobalGetVal(IN ParamVal *paxGetParam, OUT ParamVal **paxGetParamVal, OUT uint32 *iElemOut);
        int IFX_GlobalNameOidConversion(char *obj, int oid[OID_LENGTH]);
        int IFX_GlobalSetVal(IN ParamVal *paxSetParam);

        int ifx_config_get_value(char *key, char *out);
        int ifx_config_set_value(char *key, char *val);
        int ifx_config_get_val_fromOID(int32  *key, char *out);
        int ifx_config_set_val_withOID(int32  *key, char *out);
        int ifx_config_add_obj(char *psObj);
        int ifx_config_del_obj(char *psObj);


        int32 IFX_Config_Save();
        int32 IFX_Config_RebootSystem();
        int32 IFX_Config_InitLock();
        int32 IFX_Config_AcquireLock(int32 owner);
        int32 IFX_Config_ReleaseLock(int32 owner);
        int32 IFX_GetRand(int32 iLowerLim, int32 iUpperLim);
        int32 IFX_Config_FactoryReset(void);
        int32 IFX_Config_GetLanConfPassword(char8 *psConfigPassword,char8 *psResetPassword);
        int32 IFX_Checksum(OUT uint16 * puiCSum, IN char8 * psVal);
        void IFX_Config_PseudoFWHole(IN int32 iPort, IN int32 iOper);
        void IFX_Config_SSLFWHole(IN int32 iPort, IN int32 iOper);
        int32 randomstr( INOUT char *buf, IN size_t len);
        void IFX_MOD_CleanUp();
        int32 IFX_AscToIntOID(IN char8 * psOID, OUT int32 * piaOID);

#ifdef IFX_TR69_IPQOS
        void IFX_Config_IPQosMgmt(IN int32 iOper);
        int IFX_Config_IPQosInitStatus(void);
#endif /* IFX_TR69_IPQOS */

#ifdef __cplusplus
}
#endif

#endif //#ifndef CWMP_CONFIG_H
