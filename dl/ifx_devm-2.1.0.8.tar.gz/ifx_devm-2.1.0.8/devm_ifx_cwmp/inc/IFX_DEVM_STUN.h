/*
** =============================================================================
** FILE NAME     : IFX_TR69Stun.h
** PROJECT       : TR69
** MODULES       : CWMP
** DATE          : 07-12-2005
** AUTHOR        : TR69 Team
** DESCRIPTION   : 
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted

** HISTORY       :
** $Date   $Author    $Comment
**
** ============================================================================
*/
#ifdef STUN_SUPPORT

#ifndef __IFX_TR69_STUN_H__
#define __IFX_TR69_STUN_H__

#define IFX_TR69_MAX_PORTS 4

#define IFX_TR69_MAX_URL 255

#define IFX_TR69_NAT_NOT_DETECTED 0xFF
#define IFX_TR69_MAX_IPV4  50

typedef struct{
  uchar8  ucChannelId;
  int32   iNATType;
  int32   iSTUNId;
  uchar8  uacLocalIPAddr[IFX_TR69_MAX_IPV4];
  uchar8  uacSTUNServerAddr[IFX_TR69_MAX_URL];
  /* Giving the port number of Stun Server */
  uint16  unStunServPort;
  uchar8  ucNumofPorts;
  uint16  unLocalPort[IFX_TR69_MAX_PORTS];
}x_IFX_TR69_STUNInfo;


typedef struct{
 int32  iNATType;
 int32  iSTUNId;
 uchar8 ucNumofPorts;
 uchar8 ucStunStatus;
 uchar8 uacMappedIPAddr[IFX_TR69_MAX_IPV4];
 uint16 unMappedPorts[IFX_TR69_MAX_PORTS][3];
}x_IFX_TR69_STUN_FifoStr;

int IFX_TR69_STUNStart();
void IFX_TR69_GetMappedAddr(x_IFX_TR69_STUNInfo *pxSTUNInfo);
int IFX_TR69_STUNCrtProcess(IN x_IFX_TR69_STUNInfo *pxstuninfo);
int IFX_TR69_NATSignalTimeout(void);


#endif /* __IFX_TR69_STUN_H__ */

#endif /* STUN_SUPPORT */

