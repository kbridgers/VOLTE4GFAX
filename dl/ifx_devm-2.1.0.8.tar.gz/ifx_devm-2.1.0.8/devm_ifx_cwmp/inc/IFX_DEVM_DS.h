/*
** =============================================================================
** FILE NAME     : IFX_DS.h
** PROJECT       : TR69
** MODULES       : DS
** DATE          : 12-01-2006
** AUTHOR        : TR69 Team
** DESCRIPTION   : 
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date   $Author    $Comment
**
** ============================================================================
*/

#ifndef DS_DS_H
#define DS_DS_H

//GLOBAL SECTION LIST
	#define NO_OF_SEC_NAME	128
	#define SEC_NAME_LENGTH	32




	// defines related to instance flag
/* moved to global.h
	#define NO_OF_FLAG 2
        #define DEPTH_FIELD_START 1
        #define DEPTH_FIELD_END 2
        #define INSTANCE_BIT_LENGTH 10

	# define OID_LENGTH 8
*/

#ifdef MIPSTARGET
	#define DATABASE_FILE   "/etc/tr69/tr69_db.txt"
#else
	#define DATABASE_FILE   "tr69_db.txt"
#endif
#define INSTANCE_FILE   "tr69_instance.txt"


#define MAX_NO_INSTANCES		200
#define MAX_INSTANCE_VALUE_FOR_ACS	200
#define MIN_INSTANCE_VALUE_FOR_CPE	201
#define MAX_INSTANCE_VALUE_FOR_CPE	230


#define VAL_TO_INT(x)	({  	int _x = x;  \
							_x = _x<<(DEPTH_FIELD_END - DEPTH_FIELD_START + 1); \
							_x = _x>>(DEPTH_FIELD_END - DEPTH_FIELD_START + 1);    })


#ifdef __cplusplus
extern "C" {
#endif

	# define RESPONSE_SIZE 300

/* moved to global.h
	struct static_metadata{
		char access[2];
		char *validation_info;
		char *rc_tag;
		char value_type[6];
		int NotiStatus;
	};

	struct default_value{
		char value[30];
		char value_type[4];
	};
	
*/



        /*************************************************************************
        **
	**	DATA STRUCTURES USED
        **
        *************************************************************************/
	
	typedef struct tr69_instance TR_069_INSTANCE;
	typedef struct tr69_node TR_069_NODE;
	typedef struct tr69_leaf TR_069_LEAF;

// moved to global.h	typedef int (*modFunc)(int oper, void *pParamStruct, int maxElements);



	struct tr69_instance{
		unsigned int flag[NO_OF_FLAG];			// flag for first 3 ancestors
		TR_069_INSTANCE * nextInstance;
	};



	struct tr69_node{
		int  oid;	//changed from char [4]		//object oid or parameter oid
		char  name[50];			//object name or parameter name
		char has_instance;		// 0 if this node cannot have instance, 1 if can have instances

		TR_069_INSTANCE * instance;
		TR_069_LEAF * parameter;	// pointer to leaf node
		TR_069_NODE * subObject;	// pointer to non-leaf sub nodes
		TR_069_NODE * nextObject;	// pointer to next node at the same level
//		int (*functionPtr)(int operation, struct ParamValue (*pParamStruct), int num_elements) ;	// function pointer
		modFunc functionPtr;
		// added later
		 char access[3];                 //access right of read/write to this object
		 unsigned int last_instance_created_acs;	// the instance number of the last instance created, valid only if has_instance == 1
		 unsigned int last_instance_created_cpe; // the instance no. last created by cpe
	};


	struct tr69_leaf{
		int oid; 	//char  oid[4];			//object oid or parameter oid
		char  name[50];			//object name or parameter name
	//change this to int later on
		char access[3];			//access right of read/write to this object
		char *validation_info; 		//stores the validation info
		char *rc_tag;			// required for 1-1 mapping from tr-69 to rc.conf

		TR_069_LEAF * nextLeaf;		// pointer to next node at the same level
	//currently set value_type as char array, later change it to int and conversion is done in code
		char value_type[6];			// type of the value
		int NotiStatus;			// 0 (common situation), 1 (setting of active notification would be deny), 
						// 2 (no matter what the value of notification is, the active notification is always on , such as 
						// InternetGateway.DeviceInfo.SoftwareVersion)
	};




        /*************************************************************************
        **
        **	API's EXPOSED
        **
        *************************************************************************/


	// DATA MODIFICATION INTERFACE
	int ifx_ds_add_object( int oid[OID_LENGTH], char *obj);
	int ifx_ds_delete_object( int oid[OID_LENGTH], char *obj);

	int ifx_ds_register_function( char *obj, modFunc pifx_module_func);

	int ifx_ds_get_func(char *obj, int oid[OID_LENGTH], modFunc *pifx_module_func);

	// DATA QUERY INTERFACE
	int ifx_ds_get_oid( char *obj, int oid[OID_LENGTH], struct static_metadata *pResponse );
	int ifx_ds_get_partial_oid( char *obj, int oid[OID_LENGTH], struct static_metadata *pResponse );
	int ifx_ds_get_name( int oid[OID_LENGTH], char *obj, struct static_metadata (*pMetaData));
	int ifx_ds_get_exact_name( int oid[OID_LENGTH], char *obj, struct static_metadata *pResponse);

	// DATA MODEL QUERY INTERFACE
	int ifx_ds_get_obj_params( char *obj, int oid[OID_LENGTH], struct static_metadata *pResponse);
	int ifx_ds_get_subobjs( char *obj, int oid[OID_LENGTH], int response_size, char *responselist[response_size + 1]);
	int ifx_ds_get_subtree(char *obj, int oid[OID_LENGTH], int response_size, char *responselist[response_size +1]);
	int ifx_recursive_get_subtree(char *obj, int oid[OID_LENGTH], int response_size, char *responselist[response_size + 1]);
	int ifx_ds_get_leaf(char *obj, int oid[OID_LENGTH], int response_size, char *responselist[response_size + 1]);

	// for controllers use
	int ifx_ds_controller_get_leaf(char *obj, int oid[OID_LENGTH], int response_size, char *responselist[response_size + 1]);

	int ifx_ds_get_defaultval(char *obj, int oid[OID_LENGTH], struct default_value *pResponseStruct);

	// to get the access permission of a node
	int ifx_ds_get_node_access(char *obj, int oid[OID_LENGTH], char *access);

	// to get next instance no. available for addition
	int ifx_ds_get_instance_no( int oid[OID_LENGTH], char *obj);
	int tree_check_instance_no(TR_069_NODE *refNode);

	//to insert the value of the last instance created
	int ifx_ds_add_last_instance_created(int oid[OID_LENGTH], char *obj, unsigned int last_instance_created);

	//support function
	int ifx_find_parent_node(char *obj, char *name_node, char *path_parent_node );
	int ifx_ds_delete_object_subtree(TR_069_NODE *refNode, TR_069_INSTANCE *newInstance);

	int ifx_ds_get_all_paths(int oid[OID_LENGTH], int OidArray[][OID_LENGTH], int iMaxEntries);

	int ifx_ds_rctag_to_oid( INOUT int oid[OID_LENGTH], IN char * sSecName, IN char* sDistId);

	//FUNCTION FOR GLOBAL SEC NAME LIST CREATION
	int ifx_ds_create_section_name_list( TR_069_NODE *ptree_node);

	// function for TR64
	int ifx_ds_get_instancelist(int oid[OID_LENGTH], char *obj, int list[MAX_NO_INSTANCES]);
        int ifx_ds_get_objparameter(char *obj, int oid[OID_LENGTH], int *response_counter, IFX_PARAMNAME_OID_PAIR **ppaxParamOidArr);
        int ifx_ds_get_leaf_metadata(char *obj, int oid[OID_LENGTH], char *pParamName, struct static_metadata *pResponse);


	/*************************************************************************
	**
	**	INTERNAL FUNCTIONS
	**
	*************************************************************************/


	TR_069_NODE *tree_init();		// creates the first node .. the IGD node
	int tree_clean(TR_069_NODE *node);		// frees the IGD node

	int tree_add_node(TR_069_NODE *refNode, TR_069_NODE *newNode);
	int tree_delete_node(TR_069_NODE *Node);

	int tree_add_instance(TR_069_NODE *refNode, TR_069_INSTANCE *newInstance);
	int tree_delete_instance(TR_069_NODE *Instance, unsigned int (*instance_flag)[]);

	int tree_add_leaf(TR_069_NODE *refNode, TR_069_LEAF *newLeaf);
	int tree_delete_leaf(TR_069_NODE *Leaf, char name[]);


	// support functions
	int leaf_list_clean(TR_069_LEAF *leaf);
	int instance_list_clean(TR_069_INSTANCE *instance);


	//print function
	int tree_print(TR_069_NODE *root_node);
	int leaf_list_print(TR_069_LEAF *leaf);
	int instance_list_print(TR_069_INSTANCE *instance);



        /*************************************************************************
        **
        **      TREE INIT FUNCTIONS
        **
        *************************************************************************/

	TR_069_NODE *search_node_wrapper(char *name, TR_069_NODE *pNode);
	TR_069_NODE *search_node(char *name, TR_069_NODE *pNode, TR_069_INSTANCE *dummy );
	void ifx_db_init();
	void ifx_db_clean();

	int ifx_ds_init();
	void ifx_ds_instance_init();
	void ifx_ds_instance_save();
	int ifx_ds_clean();

	void instance_save(TR_069_NODE *refNode, char *parent_path);
	int create_instance_string(char *instance_string, char *obj, unsigned int (*flag)[]);

	//static void ifx_db_fptr_reset(); //not used
	int fill_instance_flag(TR_069_INSTANCE *pInstance, char *path_node);






#ifdef __cplusplus
}
#endif

#endif //#ifndef DS_DS_H

