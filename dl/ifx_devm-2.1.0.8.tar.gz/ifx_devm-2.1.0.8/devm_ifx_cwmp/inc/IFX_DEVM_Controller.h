/*
** =============================================================================
** FILE NAME     : IFX_Controllr.h
** PROJECT       : TR69
** MODULES       : Controller
** DATE          : 13-01-2006
** AUTHOR        : TR69 Team
** DESCRIPTION   : 
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date   $Author    $Comment
**
** ============================================================================
*/

#ifndef CWMP_CONTROLLER_H
#define CWMP_CONTROLLER_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    modFunc pfnMod;
    int32 iNumObjs;
    ParamVal *pxaPV;
    int32 iDepth; // IGD.IPPingDiagnostics.Interface has Depth = 3
} ObjBundle;


int32 IFX_ContInit();
int32 IFX_ContGetParamNames(int32 iCaller, char8 *psObj, int32 iLevel, 
                            ParameterInfoStruct *pxPIS, int32 iSize);
int32 IFX_ContGetParamValues(int32 iCaller, char8 *psaPNames[], 
                             ParameterValueStruct *pxPVS, int32 iMax);
int32 IFX_ContSetParamValues(int32 iCaller, ParameterValueStruct *pxPVS, 
                             int32 iNumElem, struct paramFault *pxPF);
int32 IFX_ContGetParamAttrs(int32 iCaller, char8 *psaQL[], ParameterAttributesStruct *pxPAS, 
                            int32 iMaxElem);
int32 IFX_ContSetParamAttrs(int32 iCaller, SetParameterAttributesStruct *pxSPAS, 
                            int32 iNumElem);
int32 IFX_ContAddObj(IN int32 iCaller, IN char8 *psObj);
int32 IFX_ContDelObj(IN int32 iCaller, IN char8 *psObj, IN int32 iSession);
int32 IFX_ContTagToName(char8 *psaRCTag[], char8 *psObj[]);
int32 IFX_ContSectChangeNotify(char8 *psRCTag, int32 iOper);
int32 IFX_ContRegFunc(char8 *psObj, modFunc pfnModFunc);
int32 IFX_ContNotify(IN char8 * psNotify, IN int32 iMsgSize, IN int32 iCause,
                     IN int32 iTo, IN int32 iReserved);
int32 IFX_ContGetNotification(ParameterValueStruct *pxPVS, int32 iMax);
int32 IFX_GetNameFromOID(IN int32 * iaOID, OUT char8 ** psName);
int32 IFX_ContSetActivate();
int32 IFX_ContDelActivate();
int32 IFX_ContGetExternalIPAddress(IN char8 * sExtIPAddr,
                                   OUT ParameterValueStruct *pxPVS);
int32 IFX_ContResetChangeFlag();
int32 LQX_IsLastFieldInteger(IN const char8*);

#ifdef __cplusplus
}
#endif

#endif //#ifndef CWMP_CONTROLLER_H
