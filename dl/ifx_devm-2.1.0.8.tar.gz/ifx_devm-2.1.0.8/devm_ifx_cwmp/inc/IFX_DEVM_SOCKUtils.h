#ifndef IFX_DEVM_SOCKUTILS_H
#define IFX_DEVM_SOCKUTILS_H

#include "IFX_DEVM_HttpParser.h"
#include "IFX_DEVM_SOCK.h"


#ifdef DEVM_OVER_IPv6

void
devm_get_sdk_info( OUT char *info );

int
DEVM_http_SendStatusResponse( IN DEVM_SOCKINFO * info,
                         IN int http_status_code,
                         IN int request_major_version,
                         IN int request_minor_version );


void
DEVM_http_CalcResponseVersion( IN int request_major_vers,
                          IN int request_minor_vers,
                          OUT int *response_major_vers,
                          OUT int *response_minor_vers );


int
DEVM_http_SendMessage( IN DEVM_SOCKINFO * info,
                  IN OUT int *TimeOut,
                  IN const char *fmt,
                  ... );


int
DEVM_sock_destroy( INOUT DEVM_SOCKINFO * info,
              int ShutdownMethod );


int
DEVM_sock_init( OUT DEVM_SOCKINFO * info,
           IN int sockfd );



int
DEVM_sock_write( IN DEVM_SOCKINFO * info,
            IN char *buffer,
            IN size_t bufsize,
            INOUT int *timeoutSecs );


int
DEVM_sock_read_write( IN DEVM_SOCKINFO * info,
                 OUT char *buffer,
                 IN size_t bufsize,
                 IN int *timeoutSecs,
                 IN xboolean bRead );




int
DEVM_http_RecvMessage( IN DEVM_SOCKINFO * info,
                  OUT devm_http_parser_t * parser,
			      IN devm_http_method_t request_method,
			      IN OUT int *timeout_secs,
			      OUT int *http_error_code );


int
DEVM_sock_read( IN DEVM_SOCKINFO * info,
           OUT char *buffer,
		   IN size_t bufsize,
		   INOUT int *timeoutSecs); 


#endif
#endif /* IFX_DEVM_SOCK_H */

