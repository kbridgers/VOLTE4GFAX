
#include "IFX_DEVM_HttpParser.h"


#ifndef IFX_DEVM_SOCK_H
#define IFX_DEVM_SOCK_H

#ifdef DEVM_OVER_IPv6
typedef struct
{
    int socket;         // handle/descriptor to a socket
    struct sockaddr_storage foreign_ip_addr;
    unsigned short foreign_ip_port;
} DEVM_SOCKINFO;
#endif


#endif /* IFX_DEVM_SOCK_H */

