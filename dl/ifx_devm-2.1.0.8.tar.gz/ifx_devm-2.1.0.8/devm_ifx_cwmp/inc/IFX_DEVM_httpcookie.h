/* Support for cookies.
*/

#ifndef COOKIES_H
#define COOKIES_H

//#include "httphash.h"
#include "LinkedList.h"

#define PARAMS(args) args

#define alloca_array(type, size) ((type *) malloc ((size) * sizeof (type)))

# undef xmalloc
# undef xrealloc
# undef xfree
# define xmalloc malloc
# define xrealloc realloc
# define xfree free

# undef ISSPACE
# undef ISDIGIT
# undef ISXDIGIT
# undef ISALPHA
# undef ISALNUM
# undef TOLOWER
# undef TOUPPER

# define ISSPACE(x) isspace (x)
# define ISDIGIT(x) isdigit (x)
# define ISXDIGIT(x) isxdigit (x)
# define ISALPHA(x) isalpha (x)
# define ISALNUM(x) isalnum (x)
# define TOLOWER(x) tolower (x)
# define TOUPPER(x) toupper (x)


#define BOUNDED_EQUAL(beg, end, string_literal)                         \
  ((end) - (beg) == sizeof (string_literal) - 1                         \
   && !memcmp (beg, string_literal, sizeof (string_literal) - 1))

/* The same as above, except the comparison is case-insensitive. */
#define BOUNDED_EQUAL_NO_CASE(beg, end, string_literal)                 \
  ((end) - (beg) == sizeof (string_literal) - 1                         \
   && !strncasecmp (beg, string_literal, sizeof (string_literal) - 1))


#define BOUNDED_TO_ALLOCA(beg, end, place) do { \
  const char *BTA_beg = (beg);                  \
  int BTA_len = (end) - BTA_beg;                \
  char **BTA_dest = &(place);                   \
  *BTA_dest = alloca (BTA_len + 1);             \
  memcpy (*BTA_dest, BTA_beg, BTA_len);         \
  (*BTA_dest)[BTA_len] = '\0';                  \
} while (0)


#define countof(array) (sizeof (array) / sizeof ((array)[0]))


# define xnew(x) xmalloc (sizeof (x))
# define xnew_array(type, x) xmalloc (sizeof (type) * (x))
# define xmalloc malloc         /* or something that exits
                                   if not enough memory */
# define xfree free


#define alloca_array(type, size) ((type *) malloc ((size) * sizeof (type)))

/* Declarations of `struct cookie' and the most basic functions. */

/* Cookie jar serves as cookie storage and a means of retrieving
   cookies efficiently.  All cookies with the same host IP are stored
   in a linked list called "chain". */

struct cookie_jar {
  LinkedList chains;
  int cookie_count;             /* number of cookies in the jar. */
};

typedef struct cookie_jar COOKIE_JAR ;

struct cookie {
  membuffer domain;                 /* domain of the cookie */
  int port;                     /* port number */
  membuffer host;
  membuffer path;                   /* path prefix of the cookie */

  int secure;                   /* whether cookie should be
                                   transmitted over non-https
                                   connections. */
  int domain_exact;             /* whether DOMAIN must match as a
                                   whole. */

  int permanent;                /* whether the cookie should outlive
                                   the session. */
  time_t expiry_time;           /* time when the cookie expires, 0
                                   means undetermined. */

  int discard_requested;        /* whether cookie was created to
                                   request discarding another
                                   cookie. */

  membuffer attr;                   /* cookie attribute name */
  membuffer value;                  /* cookie attribute value */

};



struct cookie_jar *http_cookie_jar_new  (void);
void http_cookie_jar_delete  (struct cookie_jar *);

void http_cookie_handle_set_cookie (struct cookie_jar *, const char *,
				       int, const char *, const char *);
char *http_cookie_header (struct cookie_jar *,
			     const char *, int, const char *, int);
void http_delete_cookie (struct cookie *cookie);

void http_set_cookie_header (char *hdr_val, struct cookie_jar *jar, const char
*urlstr);

char * http_get_cookie_header (struct cookie_jar *jar, const char *urlstr);


#endif /* COOKIES_H */

