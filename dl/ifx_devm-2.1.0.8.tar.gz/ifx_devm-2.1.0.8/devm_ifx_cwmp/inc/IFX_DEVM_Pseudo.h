/*
** =============================================================================
** FILE NAME     : tr69_pseudo.h
** PROJECT       : TR69
** MODULES       : pseudo server
** DATE          : 13-01-2006
** AUTHOR        : TR69 Team
** DESCRIPTION   : 
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date   $Author    $Comment
**
** ============================================================================
*/

#ifndef CWMP_PSEUDO_H
#define CWMP_PSEUDO_H

#ifdef __cplusplus
extern "C" {
#endif

#define  CR_TCP_PORT 8000
#define  CR_UDP_PORT 8080

int IFX_Pseudo_ServerSocketStop(int socket_type);
int IFX_Pseudo_ServerSocketInit(int socket_type);
int IFX_Pseudo_RecvSendMsg();
int IFX_Pseudo_RecvUDPMsg();
void IFX_Pseudo_Config_Init();

#ifdef __cplusplus
}
#endif

#endif //#ifndef CWMP_PSEUDO_H
