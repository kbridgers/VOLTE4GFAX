/* $Id: upnpglobalvars.h,v 1.8 2007/02/26 15:45:38 nanard Exp $ */
/* MiniUPnP project
 * http://miniupnp.free.fr/ or http://miniupnp.tuxfamily.org/
 * (c) 2006 Thomas Bernard 
 * This software is subject to the conditions detailed
 * in the LICENCE file provided within the distribution */

#ifndef __UPNPGLOBALVARS_H__
#define __UPNPGLOBALVARS_H__

#include <time.h>
#include "upnppermissions.h"
#include "upnphttp.h"

extern char vcOsModId;
extern int giDbg;
/* */
#ifdef DEBUG_ENABLED 
#define SYSLOG(x,y,args...) \
if(giDbg) \
{ \
        printf(y"\n",##args); \
} 
#else
#define SYSLOG(x,y,args...)	 
#endif


#define IFX_CWMP_MALLOC(x) ({calloc(1,x);})

#define IFX_CWMP_CALLOC(x,y) ({calloc(x,y);})

#define IFX_CWMP_REALLOC(x,y) ({realloc(x,y);})

#define IFX_CWMP_FREE(x) \
if(x) \
{ \
    free(x); \
    x = NULL; \
}


/* name of the network interface used to acces internet */
extern const char *ext_if_name;

/* forced ip address to use for this interface
 * when NULL, getifaddr() is used */
extern const char *use_ext_ip_addr;

/* LAN address */
extern char *listen_addr;

/* parameters to return to upnp client when asked */
extern unsigned long downstream_bitrate;
extern unsigned long upstream_bitrate;

/* log packets flag */
extern int logpackets;

/* statup time */
extern time_t startup_time;

/* use system uptime */
extern int sysuptime;

extern const char *pidfilename;

extern char uuidvalue[];

#define SERIALNUMBER_MAX_LEN (65)
extern char serialnumber[];

#define MODELNUMBER_MAX_LEN (17)
extern char modelnumber[];

#define PRESENTATIONURL_MAX_LEN (64)
extern char presentationurl[];

#define MANUFACTURER_MAX_LEN (65)
extern char manufacturer[];

#define DESCRIPTION_MAX_LEN (257)
extern char description[];

extern char friendlyname[];

#define MODELNAME_MAX_LEN (65)
extern char modelname[];

#define GENERICURL_MAX_LEN (257)
extern char genericurl[];

#define MACADDR_MAX_LEN (20)
extern char sMac[];

/* UPnP permission rules : */
extern struct upnpperm *upnppermlist;
extern unsigned int num_upnpperm;

extern int iTR64_HttpAuthEnable;
extern int sudp;
#ifdef TR64_OVER_IPV6
extern int sudp6;
#endif
extern int shttpl_upnp;
extern int shttp_upnpcl;
extern int shttpl_tr64;
extern int shttp_tr64cl;
extern int snotify;
extern struct upnphttp *e;
extern struct upnphttp *next;
extern struct timeval timeout, timeofday, lasttimeofday;
extern int tr64_port;
extern int upnp_port;
extern int notify_interval;
LIST_HEAD(httplisthead, upnphttp);
extern struct httplisthead upnphttphead;
extern int giUPnPCaller;
extern int debug_flag;

void IFX_TR64GlobalVars_Init();
void IFX_TR64_LANIPInit();
#endif
