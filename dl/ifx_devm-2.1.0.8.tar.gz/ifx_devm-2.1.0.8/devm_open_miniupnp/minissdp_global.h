/* $Id: upnpglobalvars.h,v 1.34 2012/09/27 15:47:15 nanard Exp $ */
/* MiniUPnP project
 * http://miniupnp.free.fr/ or http://miniupnp.tuxfamily.org/
 * (c) 2006-2012 Thomas Bernard
 * This software is subject to the conditions detailed
 * in the LICENCE file provided within the distribution */

#ifndef UPNPGLOBALVARS_H_INCLUDED
#define UPNPGLOBALVARS_H_INCLUDED

#include <time.h>
#include "miniupnpdtypes.h"
#include "upnppermissions.h"
#include "config.h"
#include "upnphttp_open.h"
/* name of the network interface used to acces internet */
extern const char * ext_if_name;

#define DEFAULT_LAN_IF  "br0"

/* file to store all leases */
#ifdef ENABLE_LEASEFILE
extern const char * lease_file;
#endif

/* forced ip address to use for this interface
 * when NULL, getifaddr() is used */
extern const char * use_ext_ip_addr;
extern int  sysuptime;
extern int sudp;
#ifdef TR64_OVER_IPV6
extern int sudp6;
#endif

extern struct httplisthead upnphttphead;
/* parameters to return to upnp client when asked */
extern unsigned long downstream_bitrate;
extern unsigned long upstream_bitrate;

/* statup time */
extern time_t startup_time;

/* runtime boolean flags */
extern int runtime_flags;
#define LOGPACKETSMASK		0x0001
#define SYSUPTIMEMASK		0x0002
#ifdef ENABLE_NATPMP
#define ENABLENATPMPMASK	0x0004
#endif
#define CHECKCLIENTIPMASK	0x0008
#define SECUREMODEMASK		0x0010

#define ENABLEUPNPMASK		0x0020

#ifdef PF_ENABLE_FILTER_RULES
#define PFNOQUICKRULESMASK	0x0040
#endif

#define SETFLAG(mask)	runtime_flags |= mask
#define GETFLAG(mask)	(runtime_flags & mask)
#define CLEARFLAG(mask)	runtime_flags &= ~mask

extern const char * pidfilename;
extern const char * pidfilename1;

extern  int
parselanaddr(struct lan_addr_s * lan_addr, char * str);

extern char uuidvalue[];

#define SERIALNUMBER_MAX_LEN (10)
extern char serialnumber[];

#define MODELNUMBER_MAX_LEN (48)
extern char modelnumber[];

#define PRESENTATIONURL_MAX_LEN (64)
extern char presentationurl[];

#define FRIENDLY_NAME_MAX_LEN (64)
extern char friendly_name[];

#define MANUFACTURER_MAX_LEN (65)
extern char manufacturer[];

#define DESCRIPTION_MAX_LEN (257)
extern char description[];

#define MODELNAME_MAX_LEN (65)
extern char modelname[];

#define GENERICURL_MAX_LEN (257)
extern char genericurl[];

/* UPnP permission rules : */
extern struct upnpperm * upnppermlist;
extern unsigned int num_upnpperm;


#ifdef ENABLE_NATPMP
/* NAT-PMP */
#if 0
extern unsigned int nextnatpmptoclean_timestamp;
extern unsigned short nextnatpmptoclean_eport;
extern unsigned short nextnatpmptoclean_proto;
#endif
#endif

/* For automatic removal of expired rules (with LeaseDuration) */
extern unsigned int nextruletoclean_timestamp;

#ifdef USE_PF
extern const char * anchor_name;
/* queue and tag for PF rules */
extern const char * queue;
extern const char * tag;
#endif

#ifdef USE_NETFILTER
extern const char * miniupnpd_nat_chain;
extern const char * miniupnpd_forward_chain;
#ifdef ENABLE_6FC_SERVICE
extern const char * miniupnpd_v6_filter_chain;
#endif
#endif

#ifdef ENABLE_NFQUEUE
extern int nfqueue;
extern int n_nfqix;
extern unsigned nfqix[];
#endif

/* lan addresses to listen to SSDP traffic */
extern struct lan_addr_list lan_addrs;

/* LAN address */
extern char *listen_addr;

#ifdef ENABLE_IPV6
/* ipv6 address used for HTTP */
extern char ipv6_addr_for_http_with_brackets[64];
#endif

extern const char * minissdpdsocketpath;

/* BOOTID.UPNP.ORG and CONFIGID.UPNP.ORG */
extern unsigned int upnp_bootid;
extern unsigned int upnp_configid;

#define IFX_UPNP_MALLOC(x) ({calloc(1,x);})

#ifdef ENABLE_6FC_SERVICE
extern int ipv6fc_firewall_enabled;
extern int ipv6fc_inbound_pinhole_allowed;
#endif

void IFX_TR64_LANIPInit();
void IFX_TR64_Init();

extern int SSDPUPnPPort;
extern int SSDPTR64Port;
extern int SSDPUPnPStatus;
extern int SSDPTR64Status;

extern int shttpl_upnp;
extern int shttp_upnpcl;
extern int shttpl_tr64;
extern int shttp_tr64cl;
extern int snotify;
extern struct upnphttp *e;
extern struct upnphttp *next;
extern struct timeval timeout, timeofday, lasttimeofday;
extern int notify_interval;
LIST_HEAD(httplisthead, upnphttp);
extern struct httplisthead upnphttphead;
extern int giUPnPCaller;
extern int debug_flag;


#endif

