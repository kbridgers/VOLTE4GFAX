void CountTR64HTTPConn();
void ProcessTR64HTTPActiveConn();
void DeleteTR64HTTPCloseConn();
#ifdef TR64_OVER_IPV6
void ProcessTR64HTTPRequest(int shttpl, int port);
#else
void ProcessTR64HTTPRequest(int shttpl);
#endif
void IFX_TR64_SendNotify();
int IFX_TR64_Init(int iTR64Status, int iUPnPStatus);
int IFX_TR64_ReInit(int iTR64Status, int iUPnPStatus);
int IFX_TR64_Close_UPnPSockets(int iTR64Status, int iUPnPStatus);
