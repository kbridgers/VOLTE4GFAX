#ifndef __IFIN_WLAN_ASSOC_DEV_H__
#define __IFIN_WLAN_ASSOC_DEV_H__

/* 
** =============================================================================
**   FILE NAME        : IFX_WlanAssocDevice.h
**   PROJECT          : TR69
**   MODULES          : WlanAssocDevice
**   DATE             : 21-06-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This is interface provided by WlanAssocDevice Module.
**                      It is required by the controller module of TR69 stack
**                      to GET/SET WlanAssocDevice specific information.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_Global.h"
#include "IFX_DEVM_AdaptCommon.h"
 


/*
** =============================================================================
**
**                                 <DEFINITIONS>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                                    <TYPES>
**
** =============================================================================
*/



/*
** =============================================================================
**
**                              <FUNCTION PROTOTYPES>
**
** =============================================================================
*/
int32
IFX_WlanAssocDevice_Init(void);
int32
IFX_WlanAssocDevice(IN OperInfo *pxOI, INOUT void *pParamList,
			IN int32 iNumElem, OUT void **ppRet, OUT int32 *piNumRetElem);

#endif /*__IFIN_WLAN_ASSOC_DEV_H__ */
