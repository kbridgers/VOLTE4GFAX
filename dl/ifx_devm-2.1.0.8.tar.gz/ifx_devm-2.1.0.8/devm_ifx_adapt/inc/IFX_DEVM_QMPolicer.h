#ifndef __IFX_QUEUEMGMTPOLICER_H__
#define __IFX_QUEUEMGMTPOLICER_H__

/* 
** =============================================================================
**   FILE NAME        : IFX_QMPolicer.h
**   PROJECT          : TR69
**   MODULES          : QueueManagement.Policer
**   DATE             : 07-02-2008
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This is the interface provided by the Policer
**                      Module. It is required by controller module of TR69 stack
**                      to GET/SET/ADD/DELETE Policer specific information.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany      
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_Global.h"
#include "IFX_DEVM_AdaptCommon.h"


/*
** =============================================================================
**
**                                 <DEFINITIONS>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                                    <TYPES>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                              <FUNCTION PROTOTYPES>
**
** =============================================================================
*/
int32
IFX_QMPolicer_Init(void);
int32
IFX_QMPolicer(IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
               OUT void **ppRet, OUT int32 *piNumRetElem);

#endif /* __IFX_QUEUEMGMTPOLICER_H__ */
