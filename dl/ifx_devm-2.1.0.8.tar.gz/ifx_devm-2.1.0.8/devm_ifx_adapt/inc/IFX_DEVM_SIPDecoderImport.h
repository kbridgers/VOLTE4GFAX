/**************************************************************************
 **   FILE NAME       : IFX_SIP_Decoder_Import.h
 **   PROJECT         : SIP signaling
 **   MODULES         : SIP DECODER
 **   SRC VERSION     : V2.0
 **   DATE            : 15-12-2004
 **   AUTHOR          : Murali
 **   DESCRIPTION     : Import file to other modules using this module
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines
 **   COPYRIGHT       : Copyright (c) 2004
 **                     Infineon Technologies AG, st. Martin Strasse 53;
 **                     81669 Munchen, Germany
 **
 **   Any use of this software is subject to the conclusion of a respective
 **   License agreement. Without such a License agreement no rights to the
 **   software are granted

 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/

#ifndef __IFX_SIP_DECODE_IMPORTS_H__
#define __IFX_SIP_DECODE_IMPORTS_H__

#include "IFX_DEVM_SIPTypes.h"
#include "IFX_DEVM_SIPStack.h"
#include "IFX_SIP_Common.h"
#include "IFX_DEVM_SIPErrors.h"
#include "IFX_DEVM_SIPHeaders.h"
#include "IFX_SIP_Decode.h"

PUBLIC e_IFX_SIP_Return 
IFX_SIP_DecodeMessage(IN char8* pBuffer,
                       OUT x_IFX_SIP_SipMessage* pSipMessage,
                       OUT x_IFX_SIP_Error* pSipError,
                       OUT char8** pcRemString);

e_IFX_SIP_Return
IFX_SIP_ValidateIPv4Addr(char8* pszBuff);

int32 IFX_SIP_strcasecmp(const char* a,
                          const char* b);

#endif /*__IFX_SIP_DECODE_IMPORTS_H__*/

