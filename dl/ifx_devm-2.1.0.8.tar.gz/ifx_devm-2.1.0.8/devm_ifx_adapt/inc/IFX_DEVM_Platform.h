/*
** =============================================================================
** FILE NAME     : IFX_DEVM_Platform.h
** PROJECT       : TR69
** MODULES       : 
** DATE          : 25-04-2006
** AUTHOR        : TR69 Team
** DESCRIPTION   : 
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date   $Author    $Comment
**
** ============================================================================
*/
#ifndef __IFX_DEVM_PLATFORM_H__
#define __IFX_DEVM_PLATFORM_H__


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#define DONT_USE_IFX_BASIC_TYPES_H
#include <ifx_common.h>
#include <ifx_api_include.h>

#include <IFIN_Proto_API.h>

#include "IFX_DEVM_Stub.h"
#include <ifx_lock.h>

#endif /* __IFX_DEVM_PLATFORM_H__ */
