#ifndef __IFIN_MOD_COMMON_H__
#define __IFIN_MOD_COMMON_H__
/* 
** =============================================================================
** FILE NAME     : IFX_MOD_Common.h
** PROJECT       : TR69
** MODULES       : Common Functions
** DATE          : 15-06-2006
** AUTHOR        : TR69 team
** DESCRIPTION   : This module has common uitlity functions which might 
**                 be used by various other modules in the system.
**
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author        $Comment
** 28-04-2006  TR69 team      Intial version 
** ============================================================================
*/

#include "IFX_DEVM_Global.h"
#include "IFX_DEVM_Platform.h"
#include <arpa/inet.h>

#ifdef __cplusplus
extern "C" {
#endif

#define TAG_DELIMITER                   "^\0"
#define IPADDR_LEN               16  // 111.222.333.444 will take max 16 chars

#define IFX_TR104_TRUE 1
#define IFX_TR104_FALSE 0

#define CWMP_REVERSE_MAP 1
#define CWMP_FORWARD_MAP 2

#define WAN_CON_DEV_DEPTH 4
#define IP_CON_TYPE 1
#define PPP_CON_TYPE 2

#define IFX_CHK_VALUE_BASED			1
#define IFX_CHK_CHANGE_FLAG_BASED	2

#define SYS_DATATYPE_INT 1
#define SYS_DATATYPE_CHAR 2
#define SYS_DATATYPE_UCHAR 3


#define MAX_IP_ADDRRESS_LEN	16
#define MAX_MAC_ADDRESS_LEN 	18

#define OID_CHAR_LENGTH (OID_LENGTH * 10)
#define MAX_VAL_LENGTH 36

#define MAX_RCTAG  96
#define MAX_SECTIONTAG 48
#define MAX_PARAMTAG 36
#define MAX_NO_SECTIONS 50

#define IFX_MAX_CONF_WAN_CONN 16
#define IFX_GET_OLD_ENB_VAL   1
#define IFX_SET_OLD_ENB_VAL   2
#define IFX_RESET_OLD_ENB_VAL 3

#define MAX_FW_DL_LIMIT  1
#define MIN_FW_DL_LIMIT  2
#define MAX_SYSCONF_DL_LIMIT  3
#define MIN_SYSCONF_DL_LIMIT  4


typedef struct GrpParamVal_SecTag
{
	ParamVal *paxHeadParamValSubArr;
	uint32 uiNoElements;
}Grp_ParamVal_SecTag;


typedef struct map_value
{
	//char8 sTR69_Value[MAX_VAL_LENGTH];
	char8 *sTR69_Value;
	uint32  uiSys_DataType;

	union system_value
	{
		//char8 sSys_Value[MAX_VAL_LENGTH];
		char8 *sSys_Value;
		uint32  uiSys_Value;
		uchar8 ucSys_Value;
	}uxSys_Val;
}Map_Value;


typedef struct enable_old_value
{
	uint32 uiOldEnable;
	uint32 uiCpeid;
} Old_Enable_Val;


int32 devmrand(void);

int32 IFX_PrintOID(int32 * paiArr_Oid);

int32 IFX_GetWanConType(uint32 LinkType);

int32 IFX_GetParamIdPos(IN int32 * paiOID);

int32 IFX_GetSectionParamTag(IN char8 * psRCTag, OUT char8 * psParamTag,
                             OUT char8 * psSectionTag);

int32 IFX_FwdMappingValues(IN Map_Value * axMap_arr, IN uint32 iNoElements,
                           IN void * psElement, OUT void * pValue);

int32 IFX_RevMappingValues(IN Map_Value * axMap_arr, IN uint32 iNoElements,
                           IN void * psElement, OUT void * pValue);

int32 IFX_ConvertObjOidDottedForm(int32 * paiArr_Oid, char8 * psOid_str);

int32 IFX_ConvertOidDottedForm(int32 * paiArr_Oid, char8 * psOid_str);

int32 IFX_GetObjCpeId(IN int32 * aiOID, OUT uint32 * iCpeid);

int32 IFX_GetCpeId(IN int32 * aiOID, OUT uint32 * iCpeid);

int32 IFX_GetParentObjCpeId(IN int32 * aiOID, OUT uint32 * iCpeid);

int32 IFX_FreeParamvalArr(IN ParamVal ** paxtParamVal, IN uint32 iElemInt);

extern int32 IFX_GlobalGetVal(IN ParamVal * paxGetParam,
                              OUT ParamVal ** paxGetParamVal,
                              OUT uint32 * iElemOut);

extern int32 ifx_ds_register_function(char8 * obj, modFunc pifx_module_func);

int32 IFX_CheckValueGotChanged(IN OperInfo * OprInfo,
                               IN ParamVal * pxNewParamVal, IN uint32 uiMode);

int32 IFX_SetAttributesInfo(IN OperInfo * pxOperInfo, IN ParamVal * paxParamArr,
                            IN uint32 uiElements);

int32 IFX_MOD_TimeIntToStr(IN time_t * ptTime, OUT char8 * psTime);

int32 IFX_MOD_TimeStrToInt(IN char8 * psTime, OUT time_t * ptTime);

int32 IFX_ConvertDNSServersStringToArr(struct in_addr *arrHead,char8 *DNSstring);

int32 IFX_ConvertDNSServersArrToString(struct in_addr *arrHead,char8 *DNSstring,uint32 NoElements);

void ifx_download_pre();

void ifx_download_post();

int ifx_download_check_image(char8 *caFileName, int32 iFileType);

void ifx_download_upgrade_image(int iRet_chkImage, char8 *caFileNamem, int32 iFileType);

int ifx_mod_get_lan_mac(char8 *psMac);

int32 IFX_GetSetOldEnableVal(uint32 Cpeid,Old_Enable_Val *axOldState,uint32 *OldEnable,uint32 Oper);

int ifx_get_filesize(int option);

int32 IFX_SetVCCWanConDevice(int32 *iaOIDDSL,int32 iCaller, int16 Vpi, int32 Vci, char8 * l2iface_name);
//int32 IFX_SetVCCWanConDevice(int32 *iaOIDDSL,int32 iCaller, int16 Vpi, int32 Vci);

#ifdef IFX_TR104
int32 IFX_GetObjectOID(IN int32 *paiOID);

int32 IFX_GetParamOID(IN int32 *paiOID);

int32 IFX_ValidateIPv4Addr(char8* pszBuff);

int32 IFX_ValidatePhoneDigit(char8* pszBuff);

int32 IFX_GetObjectDepth(IN int32 *paiOID);

int32 IFX_GetProfileId(IN int32 *paiOID);

int32 IFX_GetLineId(IN int32 *paiOID);

int32
IFX_GetOIDArrayTillLastInst(IN int32 *paiOID, INOUT char8* sOidString);

int32
IFX_SearchString(IN char8* inString, IN char8* searchString);

int32
IFX_ValidateEmail(char8* pszBuff);

int32
IFX_ValidateURL(char8* pszBuff);
#endif

#ifdef __cplusplus
}
#endif

#endif                          /* __IFIN_MOD_COMMON_H__ */
