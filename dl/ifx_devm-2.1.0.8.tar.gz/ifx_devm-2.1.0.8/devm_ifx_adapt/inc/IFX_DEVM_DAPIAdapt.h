/*
** =============================================================================
** FILE NAME     : IFX_Module.h
** PROJECT       : TR69
** MODULES       : 
** DATE          : 13-01-2006
** AUTHOR        : TR69 Team
** DESCRIPTION   : 
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date   $Author    $Comment
**
** ============================================================================
*/

#ifndef CWMP_MODULE_H
#define CWMP_MODULE_H

#ifdef __cplusplus
extern "C" {
#endif

int ifx_mod_init();
int ifx_mod_reg_objs();
int ifx_mod_dapi_route(IN OperInfo *ptxOI, INOUT void *pParamStruct,
                        IN int32 iNumElem, OUT void **ppRet,
                        OUT int32 *piNumRetElem);

#ifdef __cplusplus
}
#endif

#endif //#ifndef CWMP_MODULE_H

