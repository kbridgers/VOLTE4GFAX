

#ifndef  __IFX_DEVM_OSA__
#define  __IFX_DEVM_OSA__

#include "ifx_types.h"
#include "ifx_osa_common.h"
#include "ifx_debug.h"
#include "ifx_os.h"
#include "ifx_ipc.h"
#include "ifx_timerinterface.h"
#include "ifx_error.h"

#endif //__IFX_DEVM_OSA__
