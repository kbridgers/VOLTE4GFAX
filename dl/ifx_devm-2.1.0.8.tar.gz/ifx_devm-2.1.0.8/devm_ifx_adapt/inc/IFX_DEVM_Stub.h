/*
** =============================================================================
** FILE NAME     : IFX_DEVM_Stub.h
** PROJECT       : TR69
** MODULES       : Stub
** DATE          : 26-04-2006
** AUTHOR        : TR69 Team
** DESCRIPTION   : 
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date   $Author    $Comment
**
** ============================================================================
*/
#ifndef __IFX_DEVM_STUB_H__
#define __IFX_DEVM_STUB_H__


#include <netinet/in.h>

//Wan related stubs - some funcs are used to display the values

#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
// 

int32 ifx_get_all_wan_atm_vcc_config_stub(int32 *num_entries, WAN_CONN_CFG **pp_wancfg, uint32 flags);
int32  ifx_get_virtual_server_info_stub(int32 * num_entries, VIRTUAL_SERVER * * virtual_servers, uint32 flags);
int32 ifx_get_all_vcc_info_stub(int *num_entries, ATM_VCC_INFO **vcc_array, uint32 flags);
int32 ifx_get_wan_dsl_diagnostics(WAN_DSL_DIAGNOSTICS *pxWan_Dsl_Diag,uint32 uiFlags);	
int32 ifx_get_atmf5_loop_diagnostics(WAN_ATMF5_LOOP_DIAGNOSTICS * atmf5_diagnostics, uint32 flags);


//int32 ifx_get_wan_if_stats(int32 wan_index, IFX_ID *iid,  IF_STATS 
//*IF_STATS,char8 *if_name, uint32 flags);
//int32 IFX_GetCpeIdFromTr69Id_stub(char8 * Tr69Id,uint32 *puiNumCpeId,IFX_CpeId **ppxCpeIdArray);

#endif

#ifdef PROTOCOL_API_COMPILATION
#else /* !PROTOCOL_API_COMPILATION */


#endif /* !PROTOCOL_API_COMPILATION */ 
#endif /* __IFX_DEVM_STUB_H__ */
