#ifndef __IFIN_WAN_DSL_DIAGNOSTICS_H__
#define __IFIN_WAN_DSL_DIAGNOSTICS_H__

/* 
** =============================================================================
**   FILE NAME        : IFX_WanDslDiagnostics.h
**   PROJECT          : TR69
**   MODULES          : WanDslDiagnostics
**   DATE             : 04-09-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This is the interface provided by WanDslDiagnostics
**                      Module. It is required by the controller module of TR69
**                      stack to GET/SET WanDslDiagnostics specific information.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_Global.h"
#include "IFX_DEVM_AdaptCommon.h"
 


/*
** =============================================================================
**
**                                 <DEFINITIONS>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                                    <TYPES>
**
** =============================================================================
*/



/*
** =============================================================================
**
**                              <FUNCTION PROTOTYPES>
**
** =============================================================================
*/
typedef enum data_type
{
   IFX_UCHAR_DATA_TYPE=0,
   IFX_UINT16_DATA_TYPE

}IFX_ARR_DATA_TYPE;

int32
IFX_WanDslDiagnostics_Init(void);
int32
IFX_WanDslDiagnostics(IN OperInfo *pxOI, INOUT void *pParamList,
			IN int32 iNumElem, OUT void **ppRet, OUT int32 *piNumRetElem);
int32
IFX_ConvertArrtoString(IN uint32 uiNoElems, INOUT char8 *sBuf, IN void *aArr, IN uint32 uiDataType);

#endif /* __IFIN_WAN_DSL_DIAGNOSTICS_H__ */
