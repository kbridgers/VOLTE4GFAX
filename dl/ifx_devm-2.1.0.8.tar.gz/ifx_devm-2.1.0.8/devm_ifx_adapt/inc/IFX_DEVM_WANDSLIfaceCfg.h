#ifndef __IFIN_WAN_DSL_INTERFACE_CONFIG_H__
#define __IFIN_WAN_DSL_INTERFACE_CONFIG_H__

/* 
** =============================================================================
**   FILE NAME        : IFX_WanDslInterfaceConfig.h
**   PROJECT          : TR69
**   MODULES          : WanDslInterfaceConfig
**   DATE             : 12-07-2007
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This is the interface provided by WanDslInterfaceConfig
**                      Module. It is required by the controller module of TR69
**                      stack to GET/SET WanDslInterfaceConfig specific information.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_Global.h"
#include "IFX_DEVM_AdaptCommon.h"
 


/*
** =============================================================================
**
**                                 <DEFINITIONS>
**
** =============================================================================
*/
#define IFX_DSL_MOD_TYPE_LEN 16
#define IFX_DSL_STAN_USED_LEN 20
#define IFX_DSL_LINE_ENCODE_LEN 10
#define IFX_DSL_DATA_PATH_LEN 16
#define IFX_DSL_VENDOR_ID_LEN 42
#define IFX_DSL_COUNRY_CODE_LEN 12
#define IFX_DSL_COMMON_STR_LEN 32
#define IFX_DSL_LONG_STR_LEN 128
#define IFX_DSL_STANDARDS_SUPPORTED_LEN 512
#define CURR_PROFILE_LEN 4
/*
** =============================================================================
**
**                                    <TYPES>
**
** =============================================================================
*/

typedef struct dsl_line_phy_properties
{
	 uint32 Enable;
	 uint32 LineStatus;
	 char8  DslModType[IFX_DSL_MOD_TYPE_LEN];
	 char8  DslStandardUsed[IFX_DSL_STAN_USED_LEN];
         char8  DslStandardsSupported[IFX_DSL_STANDARDS_SUPPORTED_LEN];
	 char8  DslLinkEncapUsed[IFX_DSL_COMMON_STR_LEN];
	 char8  DslLinkEncapSupported[IFX_DSL_LONG_STR_LEN];
         char8  DslLinkEncapRequested[IFX_DSL_COMMON_STR_LEN];
	 char8  DataPath[IFX_DSL_DATA_PATH_LEN]; 
	 char8  LineEncoding[IFX_DSL_LINE_ENCODE_LEN];
	 uint16 InterleaveDepth;
	 int32  LineNo;
	 uint32 usCurrRate;
	 uint32 dsCurrRate;
	 uint32 usMaxRate;
	 uint32 dsMaxRate;
	 uint32 ActInterleavingDelay;
	 int32 ActImpNoiseProtection;
	 int32	usNoiseMgr;
	 int32 	dsNoiseMgr;
	 int32	usAttn;
	 int32	dsAttn;
	 int32  usPower;
	 int32  dsPower;
	 char8  ATUCCountry[IFX_DSL_COUNRY_CODE_LEN];
	 char8  ATURCountry[IFX_DSL_COUNRY_CODE_LEN];
         char8  ATUCVendor[IFX_DSL_VENDOR_ID_LEN];
	 char8  ATURVendor[IFX_DSL_VENDOR_ID_LEN]; 
         uint32 TotalStart;
	 uint32 ShowtimeStart;
         uint32 ATURANSIStd;
         uint32 ATURANSIRev;
         uint32 ATUCANSIStd;
         uint32 ATUCANSIRev;
         char8 AllowedProfiles[IFX_DSL_COMMON_STR_LEN];
         char8 CurrentProfile[CURR_PROFILE_LEN];
         int32 TRELLISus;
         int32 TRELLISds;
         int32 ACTSNRMODEus;
         int32 ACTSNRMODEds;
         char8 SNRMpbus[IFX_DSL_COMMON_STR_LEN];
         char8 SNRMpbds[IFX_DSL_COMMON_STR_LEN];
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
	 DSL_G997_PowerManagement_t g997PMState;
#endif
#ifdef CONFIG_FEATURE_IFX_TR69_WANDSLOBJS_FULL
         uint32 CurrentDayStart;
         uint32 LastShowtimeStart;
         uint32 QuarterHourStart;
#endif
}DSL_LINE_PHY_PROPERTIES;		


/*
** =============================================================================
**
**                              <FUNCTION PROTOTYPES>
**
** =============================================================================
*/

int32 
ifx_get_dsl_phy_properties(DSL_LINE_PHY_PROPERTIES *dslphyparams);
int32
IFX_WanDslInterfaceConfig_Init(void);
int32
IFX_WanDslInterfaceConfig(IN OperInfo *pxOI, INOUT void *pParamList,
			IN int32 iNumElem, OUT void **ppRet, OUT int32 *piNumRetElem);

#endif /* __IFIN_WAN_DSL_INTERFACE_CONFIG_H__ */
