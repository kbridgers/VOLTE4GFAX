
#define IFX_SIP_MAX(a,b) (a)>(b)?(a):(b)

#define IFX_SIP_TOKEN_NOTFOUND (char)-3
/*! \def IFX_SIP_URI
    \brief A macro defining max SIP URI.
*/
#define IFX_SIP_URI                      6

/*! \enum e_IFX_SIP_HostType
    \brief An Enumeration defining the Host address types.
*/
typedef enum{
  IFX_SIP_HOSTNAME = 1,/*!< Address is a host name */
  IFX_SIP_IPV4ADDR,/*!< IPv4 Address */
  IFX_SIP_IPV6REF,/*!< IPv6 Address */
  IFX_SIP_HOSTINVALID/*!< Invalid Host */
} e_IFX_SIP_HostType;

typedef struct
{
    e_IFX_SIP_Ecode eDecodeErr;
    char8 szErrorDesc[100];
}x_IFX_SIP_Error;

typedef enum{
  IFX_SIP_TRANSP_PARAM = 1,/*!< Tranport parameter */
  IFX_SIP_USER_PARAM,/*!< User Parameter */
  IFX_SIP_METHOD_PARAM,/*!< Method parameter */
  IFX_SIP_TTL_PARAM,/*!< TTL parameter */
  IFX_SIP_MADDR_PARAM,/*!< multicast address parameter */
#ifdef RFC_3486
  IFX_SIP_COMP_PARAM,
#endif /*RFC_3486*/
  IFX_SIP_LR_PARAM,/*!< loose route parameter */
  IFX_SIP_OTHER_PARAM/*!< Other non-standard parameters */
} e_IFX_SIP_UriParamType;

/*! \struct x_IFX_SIP_UserInfo
    \brief A structure defining the User Information.
*/
typedef struct
{
  char8 *pcUserInfo;
  char8 *pcPassword;
} x_IFX_SIP_UserInfo;

/*! \struct x_IFX_SIP_HostPort
    \brief A structure defining the Host Port.
*/
typedef struct
{
   char8 *pcHostInfo;
   uint16 unPort;    
} x_IFX_SIP_HostPort;


/*! \struct x_IFX_SIP_Header
    \brief A structure defining Headers of sip/sips uri.
*/
typedef struct
{
  char8 *pcToken;/*!< Token */
  char8 *pcValue;/* Generic Value, Null string in absence */  
} x_IFX_SIP_Header;

/*! \struct x_IFX_SIP_UriParam
    \brief A structure defining the URI parameters.
*/
typedef struct
{
   e_IFX_SIP_UriParamType eUriParamType;/*!< URI parameter type */
   union
   {     
   char8 *pcUriParam;
   uchar8 ucTTL;
   } uxUriParamType;
} x_IFX_SIP_UriParam;

typedef struct
{
    x_IFX_SIP_UserInfo    xUserInfo;   /*!< User Information */
    x_IFX_SIP_HostPort    xHostPort;   /*!< Host Information */
    x_IFX_SIP_UriParam    *pxUriParam; /*!< URI parameters */
    x_IFX_SIP_Header      *pxHeaders;  /*!< Headers */
} x_IFX_SIP_SipUri; 


e_IFX_SIP_Return
IFX_SIP_DecodeSipUri(IN  char8* pcStartIndex,
                      IN  char8* pcEndIndex,
                      OUT x_IFX_SIP_SipUri* pxSipUri,
                      OUT x_IFX_SIP_Error* pxSipError);
