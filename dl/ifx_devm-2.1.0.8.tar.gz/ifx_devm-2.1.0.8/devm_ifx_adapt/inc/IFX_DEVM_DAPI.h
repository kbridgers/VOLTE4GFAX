/*
** =============================================================================
** FILE NAME     : IFX_DAPI.h
** PROJECT       : TR69
** MODULES       : DAPI
** DATE          : 26-10-2005
** AUTHOR        : TR69 Team
** DESCRIPTION   : 
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date   $Author    $Comment
**
** ============================================================================
*/

#ifndef CWMP_DAPI_H
#define CWMP_DAPI_H

#ifdef __cplusplus
extern "C" {
#endif

void ifx_dapi_init();
void ifx_dapi_clean();
int ifx_dapi_get_val(char *obj, char **val);
int ifx_dapi_get_values(ParameterValueStruct *pvs, int num);
int ifx_dapi_get_paramnames(char *obj, int level, ParameterInfoStruct *paramInfo, int max);
int ifx_dapi_set_paramvalues( ParameterValueStruct (*p_paramvalues)[]);
int ifx_dapi_get_paramvalues(char *querylist[QUERY_LIST_SIZE], ParameterValueStruct (*p_paramvalues)[]);
int ifx_dapi_get_paramattributes(char *querylist[QUERY_LIST_SIZE], ParameterAttributesStruct (*p_paramattribs)[]);
int ifx_dapi_set_paramattributes(SetParameterAttributesStruct (*p_paramattribs)[]);
int ifx_dapi_addobject(char *obj);
int ifx_dapi_deleteobject(char *obj);
int ifx_dapi_get_parameterinfo(ParameterInfo (*paraminfo)[]);
int checkvisibility(const char *string);
int fileop(FILE *fp, fpos_t *start_edit, int removesize, char *insertstring);

#ifdef __cplusplus
}
#endif

#endif //#ifndef CWMP_DAPI_H
