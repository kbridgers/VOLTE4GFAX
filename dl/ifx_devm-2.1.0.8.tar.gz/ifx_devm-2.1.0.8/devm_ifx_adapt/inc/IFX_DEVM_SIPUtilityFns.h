/**************************************************************************
**   FILE NAME     : IFX_SIP_UtilityFns.h
**   PROJECT       : SIP
**   MODULES       : For all SIP modules
**   SRC VERSION   : V2.0 
**   DATE          : 15-12-2004 
**   AUTHOR        : Murali
**   DESCRIPTION   : Function prototypes of utility functions. 
**   COMPILER      : gcc 
**   REFERENCE     : Coding guide lines, DIS of Transaction User.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_SIP_UTILITYFNS_H__
#define __IFX_SIP_UTILITYFNS_H__

uint32
IFX_SIP_RandomNumber();

void
IFX_SIP_DbgInit();

#define atoi atoi

#define IFX_SIP_RemoveLeadingWhiteSpace(pcStart, pcEnd, pxSipError) \
{                                                                   \
  while((pcStart) < (pcEnd) &&                                      \
        ((*(pcStart) == ' ') || (*(pcStart) == '\t')))              \
  {                                                                 \
    (pcStart)++;                                                    \
  }                                                                 \
  if((pcStart) >= (pcEnd))                                          \
  {                                                                 \
    (pxSipError)->eDecodeErr = IFX_SIP_INVALID_FMT;                 \
    strcpy((pxSipError)->szErrorDesc,"Invalid Msg Format");         \
  }                                                                 \
}

#define IFX_SIP_RemoveTrailingWhiteSpace(pcStart, pcEnd, pxSipError) \
{                                                                    \
  pcEnd--;                                                           \
  while((pcStart) <= (pcEnd) &&                                      \
        ((*(pcEnd) == ' ') || (*(pcEnd) == '\t')))                   \
  {                                                                  \
    (pcEnd)--;                                                       \
  }                                                                  \
  if((pcStart) > (pcEnd))                                            \
  {                                                                  \
    (pxSipError)->eDecodeErr = IFX_SIP_INVALID_FMT;                  \
    strcpy((pxSipError)->szErrorDesc,"Invalid Msg Format");          \
  }                                                                  \
  pcEnd++;                                                           \
}


#endif /*__IFX_SIP_UTILITYFNS_H__*/
