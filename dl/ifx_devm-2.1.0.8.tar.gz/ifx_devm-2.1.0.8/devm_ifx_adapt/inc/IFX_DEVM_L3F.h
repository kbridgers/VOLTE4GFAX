#ifndef __IFIN_LAYER3FORWARDING_H__
#define __IFIN_LAYER3FORWARDING_H__

/* 
** =============================================================================
**   FILE NAME        : IFIN_Layer3Forwarding.h
**   PROJECT          : TR69
**   MODULES          : Layer3Forwarding
**   DATE             : 14-05-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This is the interface provided by the Layer3Forwarding
**                      Module. It is required by the controller module of TR69
**                      stack to GET/SET Device specific information.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_Global.h"
 
#include "IFX_DEVM_AdaptCommon.h"


/*
** =============================================================================
**
**                                 <DEFINITIONS>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                                    <TYPES>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                              <FUNCTION PROTOTYPES>
**
** =============================================================================
*/
int32 IFIN_Layer3Forwarding_GetVal(IN int32 iCaller, INOUT ParamVal * pxGetParamVal, IN int32 iElements);
int32 IFIN_Layer3Forwarding_AddDel(IN int32 iCaller, IN ParamVal *pxSetParamVal, IN int32 iNumElem, IN int32 operation);

int32
IFIN_Layer3Forwarding_Init(void);
int32
IFIN_Layer3Forwarding(IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
             OUT void **ppRet, OUT int32 *piNumRetElem);

#endif /* __IFIN_LAYER3FORWARDING_H__ */
