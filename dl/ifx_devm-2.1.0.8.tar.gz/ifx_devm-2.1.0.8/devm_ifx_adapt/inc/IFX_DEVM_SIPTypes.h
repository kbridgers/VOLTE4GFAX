/**************************************************************************
**   FILE NAME       : IFX_SIP_Types.h
**   PROJECT         : SIP
**   MODULES         : For All SIP Modules. 
**   SRC VERSION     : V2.0
**   DATE            : 15-12-2004
**   AUTHOR          : Narendra.V.P
**   DESCRIPTION     : Type definitions for data types.
**   COMPILER        : gcc
**   REFERENCE       : Coding guide lines
**   COPYRIGHT       : Copyright (c) 2004
**                     Infineon Technologies AG, st. Martin Strasse 53;
**                     81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
***********************************************************************/
#ifndef   __IFX_SIP_TYPES_H__
#define   __IFX_SIP_TYPES_H__


typedef void IFX_SIP_Void;

#define   IFX_SIP_NULL NULL
#define   PRINT   printf
#include "IFX_DEVM_CommonDefs.h"
#include "IFX_DEVM_SIPStack.h"
#include "IFX_DEVM_SIPErrors.h"
#include "IFX_SIP_Port.h"

#endif    /* __IFX_SIP_TYPES_H__ */
