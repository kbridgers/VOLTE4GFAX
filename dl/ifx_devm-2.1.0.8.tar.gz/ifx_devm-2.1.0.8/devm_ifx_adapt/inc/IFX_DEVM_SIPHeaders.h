/**************************************************************************
 **   FILE NAME       : IFX_SIP_Headers.h
 **   PROJECT         : SIP signaling
 **   MODULES         : Decoder
 **   SRC VERSION     : V2.0
 **   DATE            : 15-12-2004
 **   AUTHOR          : Narendra V P
 **   DESCRIPTION     : C equivalent of ABNF datastructs
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines
 **   COPYRIGHT       : Copyright (c) 2004
 **                     Infineon Technologies AG, st. Martin Strasse 53;
 **                     81669 Munchen, Germany
 **
 **   Any use of this software is subject to the conclusion of a respective
 **   License agreement. Without such a License agreement no rights to the
 **   software are granted

 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
/*! \file IFX_SIP_Headers.h
    \brief File containing the Headers related to a SIP message.

    Contains structure of headers like From, To, CallId, CSeq etc.
*/

#ifndef __IFX_SIP_HEADERS_H__
#define __IFX_SIP_HEADERS_H__


/* These are some of the Configurable parameters */
/*! \def IFX_SIP_MAX_USER_INFO
    \brief A macro defining maximum user length.
*/
#define IFX_SIP_MAX_USER_INFO           64
/*! \def IFX_SIP_MAX_HOST_PORT
    \brief A macro defining maximum length of Host.
*/
#define IFX_SIP_MAX_HOST_PORT           64
/*! \def IFX_SIP_MAX_HEADER_VAL
    \brief A macro defining maximum length of a header value.
*/
#define IFX_SIP_MAX_HEADER_VAL          64
/*! \def IFX_SIP_MAX_QUOTED_STR
    \brief A macro defining maximum length of a quoted string.
*/
#define IFX_SIP_MAX_QUOTED_STR          64
/*! \def IFX_SIP_MAX_WARNING_VALUE
    \brief A macro defining maximum length of warning value.
*/
#define IFX_SIP_MAX_WARNING_VALUE       16
/*! \def IFX_SIP_MAX_HOST
    \brief A macro defining maximum length of a host.
*/
#define IFX_SIP_MAX_HOST                64
/*! \def IFX_SIP_MAX_IPV6
    \brief A macro defining maximum length of IPV6 address.
*/
#define IFX_SIP_MAX_IPV6               128
/*! \def IFX_SIP_MAX_TOKEN
    \brief A macro defining maximum length for a token.
*/
#define IFX_SIP_MAX_TOKEN               64
/*! \def IFX_SIP_MAX_VIA_PARM
    \brief A macro defining maximum number of VIA parameters.
*/
#define IFX_SIP_MAX_VIA_PARM            16
/*! \def IFX_SIP_MAX_SERVER_VAL
    \brief A macro defining maximum length of server.
*/
#define IFX_SIP_MAX_SERVER_VAL          16
/*! \def IFX_SIP_MAX_RRPARAM
    \brief A macro defining maximum number of record route parameters.
*/
#define IFX_SIP_MAX_RRPARAM              6
/*! \def IFX_SIP_MAX_ROUTE_PARAM
    \brief A macro defining maximum number of Route parameters.
*/
#define IFX_SIP_MAX_ROUTE_PARAM         70
/*! \def IFX_SIP_MAX_RETRY_PARAM
    \brief A macro defining maximum retry parameters.
*/
#define IFX_SIP_MAX_RETRY_PARAM          5
/*! \def IFX_SIP_MAX_OPT_TAG
    \brief A macro defining maximum number of optional tags.
*/
#define IFX_SIP_MAX_OPT_TAG              4
/*! \def IFX_SIP_MAX_RPLYTOPARAM
    \brief A macro defining maximum Reply To parameters.
*/
#define IFX_SIP_MAX_RPLYTOPARAM          4
/*! \def IFX_SIP_MAX_REC_ROUTE
    \brief A macro defining maximum number of record route Headers.
*/
#define IFX_SIP_MAX_REC_ROUTE           70
/*! \def IFX_SIP_MAX_QOP_VALUE
    \brief A macro defining maximum lenght Quality of protection value.
*/
#define IFX_SIP_MAX_QOP_VALUE            4
/*! \def IFX_SIP_MAX_URI
    \brief A macro defining maximum URI parameters.
*/
#define IFX_SIP_MAX_URI                  4
/*! \def IFX_SIP_URI
    \brief A macro defining max SIP URI.
*/
#define IFX_SIP_URI                      6
/*! \def IFX_SIP_MAX_DIGEST_CLN
    \brief A macro defining maximum digest challanges.
*/
#define IFX_SIP_MAX_DIGEST_CLN           8
/*! \def IFX_SIP_MAX_CALL_ID
    \brief A macro defining maximum call identifier.
*/
#define IFX_SIP_MAX_CALL_ID              2
/*! \def IFX_SIP_MAX_FROM_PARAM
    \brief A macro defining maximum from parameters.
*/
#define IFX_SIP_MAX_FROM_PARAM           4
/*! \def IFX_SIP_MAX_GEN_PARAM
    \brief A macro defining maximum number of generic parameters.
*/
#define IFX_SIP_MAX_GEN_PARAM            4
/*! \def IFX_SIP_MAX_ERROR_URI
    \brief A macro defining maximum number of errors URI's in error info header.
*/
#define IFX_SIP_MAX_ERROR_URI            2
/*! \def IFX_SIP_MAX_PRIM_TAG
    \brief A macro defining maximum number of primary tag in the content-language header.
*/
#define IFX_SIP_MAX_PRIM_TAG             8
/*! \def IFX_SIP_MAX_SUB_TAG
    \brief A macro defining maximum number of secondary tags in the language header.
*/
#define IFX_SIP_MAX_SUB_TAG              8
/*! \def IFX_SIP_MAX_LANG_TAG
    \brief A macro defining mMaximum number of languages in the Content-Language header.
*/
#define IFX_SIP_MAX_LANG_TAG             4
/*! \def IFX_SIP_MAX_DISP_PARAM
    \brief A macro defining mMaximum number of disposition parameters.
*/
#define IFX_SIP_MAX_DISP_PARAM           2
/*! \def IFX_SIP_MAX_CONT_PARAMS
    \brief A macro defining maximum number of contact parameters in a contact header.
*/
#define IFX_SIP_MAX_CONT_PARAMS          2
/*! \def IFX_SIP_MAX_CONTACT_PARAM
    \brief A macro defining maximum number of contact headers present.
*/
#define IFX_SIP_MAX_CONTACT_PARAM        4
/*! \def IFX_SIP_MAX_INFO_PARAM
    \brief A macro defining maximum number of Info parameters.
*/
#define IFX_SIP_MAX_INFO_PARAM           2
/*! \def IFX_SIP_MAX_INFO
    \brief A macro defining maximum number of Information Headers.
*/
#define IFX_SIP_MAX_INFO                 4
/*! \def IFX_SIP_MAX_WORD_SIZE
    \brief A macro defining maximum size of a word. Used in may headers.
*/
#define IFX_SIP_MAX_WORD_SIZE          256
/*! \def IFX_SIP_MAX_AINFO
    \brief A macro defining maximum number of authentication information headers.
*/
#define IFX_SIP_MAX_AINFO                2
/*! \def IFX_SIP_MAX_AUTH_PARAM
    \brief A macro defining maximum number of authentication parameters.
*/
#define IFX_SIP_MAX_AUTH_PARAM           2
/*! \def IFX_SIP_MAX_DIG_RESP
    \brief A macro defining maximum number of digest response parameters.
*/
#define IFX_SIP_MAX_DIG_RESP            11
/*! \def IFX_SIP_MAX_METHOD
    \brief A macro defining maximum number of methods.
*/
#define IFX_SIP_MAX_METHOD              14        
/*! \def IFX_SIP_MAX_ALERT_PARAM
    \brief A macro defining maximum number of Alert parameters.
*/
#define IFX_SIP_MAX_ALERT_PARAM          2
/*! \def IFX_SIP_MAX_ACCEPT_PARAM
    \brief A macro defining maximum number of accept parameters.
*/
#define IFX_SIP_MAX_ACCEPT_PARAM         2
/*! \def IFX_SIP_MAX_LANGUAGE
    \brief A macro defining maximum number of languages.
*/
#define IFX_SIP_MAX_LANGUAGE             2
/*! \def IFX_SIP_MAX_ENCODING
    \brief A macro defining maximum number of content encodings.
*/
#define IFX_SIP_MAX_ENCODING             2
/*! \def IFX_SIP_MAX_MPARAM
    \brief A macro defining maximum number of M-Parameters.
*/
#define IFX_SIP_MAX_MPARAM               4
/*! \def IFX_SIP_MAX_ACCEPT_RANGE
    \brief A macro defining maximum number of Accept range parameters.
*/
#define IFX_SIP_MAX_ACCEPT_RANGE         3
/*! \def IFX_SIP_MAX_EXPIRES
    \brief A macro defining maximum number of expire.
*/
#define IFX_SIP_MAX_EXPIRES             32
/*! \def IFX_SIP_MAX_MIME_VER
    \brief A macro defining maximum number of MIME version.
*/
#define IFX_SIP_MAX_MIME_VER            10
/*! \def IFX_SIP_MAX_PROT
    \brief A macro defining maximum length of protocol used in media description header.
*/
#define IFX_SIP_MAX_PROT                 4 
/*! \def IFX_SIP_MAX_IPV4_ADDR
    \brief A macro defining maximum IPV4 supported address.
*/
#define IFX_SIP_MAX_IPV4_ADDR           16
/*! \def IFX_SIP_MAX_IPV6_ADDR
    \brief A macro defining maximum IPV6 supported address.
*/
#define IFX_SIP_MAX_IPV6_ADDR          128
/*! \def IFX_SIP_MAX_SEGMENT
    \brief A macro defining maximum number of segments.
*/
#define IFX_SIP_MAX_SEGMENT              5
/*! \def IFX_SIP_MAX_OTHER_HDR
    \brief A macro defining maximum number of optional headers.
*/
#define IFX_SIP_MAX_OTHER_HDR           64
/*! \def IFX_SIP_MAX_HEADER
    \brief A macro defining maximum number of headers.
*/
#define IFX_SIP_MAX_HEADER               4
/*! \def IFX_SIP_MAX_WKDAY
    \brief A macro defining maximum number of characters a weekday field can take.
*/
#define IFX_SIP_MAX_WKDAY                8
/*! \def IFX_SIP_MAX_MONTH
    \brief A macro defining maximum number of characters a month field could take.
*/
#define IFX_SIP_MAX_MONTH                8
/*! \def IFX_SIP_MAX_VIA_PARAMS
    \brief A macro defining maximum number of Via parameters.
*/
#define IFX_SIP_MAX_VIA_PARAMS           4
/*! \def IFX_SIP_VERSION
    \brief A macro defining maximum number of characters a SIP version can take.
*/
#define IFX_SIP_VERSION                  8
/*! \def IFX_SIP_MAX_DIGITS
    \brief A macro defining maximum number of digits in ISDN subaddress and postdial fields.
*/
#define IFX_SIP_MAX_DIGITS              10
/*! \def IFX_SIP_MAX_PHONEDIGIT
    \brief A macro defining maximum number of digits.
*/
#define IFX_SIP_MAX_PHONEDIGIT          20
/*! \def IFX_SIP_MAX_DRESPONSE
    \brief A macro defining maximum length of Response.
*/
#define IFX_SIP_MAX_DRESPONSE           33

/*! \def IFX_SIP_MAX_QUERY
    \brief A macro defining maximum length of Query.
*/
#define IFX_SIP_MAX_QUERY               16
/*! \def IFX_SIP_MAX_SCHEME
    \brief A macro defining maximum length of the scheme.
*/
#define IFX_SIP_MAX_SCHEME              16 
/*! \def IFX_SIP_MAX_CHAL
    \brief A macro defining maximum number of challenges.
*/
#define IFX_SIP_MAX_CHAL                 2 
/*! \def IFX_SIP_MAX_CREDENTIALS
    \brief A macro defining maximum number of credentials.
*/
#define IFX_SIP_MAX_CREDENTIALS          2
/*! \def IFX_SIP_MAX_HEADERVALUE
    \brief A macro defining maximum number of headers.
*/
#define IFX_SIP_MAX_HEADERVALUE        256

/* Added for 3265 */
/*! \def IFX_SIP_MAX_EVENT_PARAM
    \brief A macro defining maximum event parameters that can come in Event header.
*/
#define  IFX_SIP_MAX_EVENT_PARAM        20
/*! \def IFX_SIP_MAX_ALLOW_EVENTS
    \brief A macro defining maximum event types in Allow-Events header.
*/
#define  IFX_SIP_MAX_ALLOW_EVENTS       20
/*! \def IFX_SIP_MAX_EVNTTEMPLATE
    \brief A macro defining maximum event templates that can be present.
*/
#define  IFX_SIP_MAX_EVNTTEMPLATE       20
/*! \def IFX_SIP_MAX_TOKEN_NODOT
    \brief A macro defining maximum number of characters an event template value can take.
*/
#define  IFX_SIP_MAX_TOKEN_NODOT        20
/*! \def IFX_SIP_MAX_SUBSTATE
    \brief A macro defining maximum length of extension subscription-state values.
*/
#define  IFX_SIP_MAX_SUBSTATE           32
/*! \def IFX_SIP_MAX_SUBEXPPARAMS
    \brief A macro defining maximum subscription expression parameters.
*/
#define  IFX_SIP_MAX_SUBEXPPARAMS       10
/*! \def IFX_SIP_MAX_EVNTRSNEXTN
    \brief A macro defining maximum length for extension event reasons.
*/
#define  IFX_SIP_MAX_EVNTRSNEXTN        20
/* Added for draft-ietf-sip-replaces-02.txt */
/*! \def IFX_SIP_MAX_REPLACE_PARAMS
    \brief A macro defining maximum replaces parameters.
*/
#define  IFX_SIP_MAX_REPLACE_PARAMS      5

/* Added for both RFC 3325 and 3327 */

#ifdef RFC_3325
#define IFX_SIP_MAX_PRIVACY_TOKENS	10
/* Added for RFC 3325*/
#define IFX_SIP_MAX_IDENTITY_PARAM	5
#endif /*RFC_3325*/

#ifdef RFC_3327
#define IFX_SIP_MAX_PATH_PARAM  	5
/* Added for RFC 3327*/
#define IFX_SIP_MAX_DIGEST_VERIFY	33
#define IFX_SIP_MAX_SECURITY_MECH_PARAM	 5
#define IFX_SIP_MAX_SECURITY_MECHANISM	 5
#define IFX_SIP_MAX_SECURITYMECH_PARAM	 5
#endif /*RFC_3327*/



/* ENUMERATIONS */
/*! \enum e_IFX_UserParamType
    \brief An Enumeration defining the User types.
*/
typedef enum{
  IFX_SIP_PHONE = 1,/*!< User Type is phone */
  IFX_SIP_IP,/*!< Normal IP Phone User */
  IFX_SIP_OTHER_USER /*!< Not a predefined user type */
} e_IFX_UserParamType;

/*! \enum e_IFX_SIP_TransType
    \brief An Enumeration defining the Tranport types.
*/
typedef enum{
  IFX_SIP_UDP = 1,/*!< UDP Transport Type */
  IFX_SIP_TCP,/*!< TCP Transport Type */
  IFX_SIP_TLS,/*!< TLS Transport Type */
  IFX_SIP_SCTP,/*!< SCTP Transport Type */
  IFX_SIP_OTHER/*!< Other than Predefined transport types */
} e_IFX_SIP_TransType;

/*! \enum e_IFX_SIP_ServerValtype
    \brief An Enumeration defining the Server value types.
*/
typedef enum{
  IFX_SIP_PRODUCT = 1,/*!< Server value type specified is a product */
  IFX_SIP_COMMENT/*!< Server Value type specified is a comment */
} e_IFX_SIP_ServerValtype;

/*! \enum e_IFX_SIP_RetryParamType
    \brief An Enumeration defining the Retry parameter types.
*/
typedef enum{
  IFX_SIP_DURATION = 1,/*!< Retry param is duration */
  IFX_SIP_GEN_PARAM/*!< Retry param is a generic param */
} e_IFX_SIP_RetryParamType;

/*! \enum e_IFX_SIP_QopValType
    \brief An Enumeration defining the QOP value types.
*/
typedef enum{
  IFX_SIP_AUTH = 1,/*!< Quality of Protection is of type Auth */
  IFX_SIP_AUTH_INT,/*!< Quality of protection is auth integrated */
  IFX_SIP_OTHER_QOPVAL/*!< Quality of protection is not a predefined type */
} e_IFX_SIP_QopValType;

/*! \enum e_IFX_SIP_AlgType
    \brief An Enumeration defining the Algorithm types.
*/
typedef enum{
  IFX_SIP_MD5 = 1,/*!< Authentication mechanism for computing the response */
  IFX_SIP_MD5_SESS,/*!< MD5-Sess is auth mechanism for computing response */
  IFX_SIP_OTHER_ALG/*!< Not a predefined algorithm */
} e_IFX_SIP_AlgType;


/*! \enum e_IFX_SIP_DigestClnType
    \brief An Enumeration defining the Digest Challenge types.
*/
typedef enum{
  IFX_SIP_REALM_D = 1,/*!< Digest challenge parameter is realm */
  IFX_SIP_DOMAIN,/*!< Digest challenge parameter is domain */
  IFX_SIP_NONCE_D,/*!< Digest challenge parameter is nonce */
  IFX_SIP_OPAQUE,/*!< Digest challenge parameter is opaque */
  IFX_SIP_STALE,/*!< Digest challenge parameter is stale */
  IFX_SIP_ALGORITHM_D,/*!< Digest challenge parameter is algoritm */
  IFX_SIP_QOP_OPTIONS,/*!< Digest challenge parameter is options */
  IFX_SIP_AUTH_PARAM/*!< Not a predefined diget challenge parameter */
} e_IFX_SIP_DigestClnType;

/*! \enum e_IFX_SIP_ChalType
    \brief An Enumeration defining the Challenge types.
*/
typedef enum{
  IFX_SIP_DIGEST = 1,/*!< Digest challenge */
  IFX_SIP_OTHER_CHAL/*!< Not a predefined diget challenge Type */
}e_IFX_SIP_ChalType;

/*! \enum e_IFX_SIP_PriValue
    \brief An Enumeration defining the Priority values.
*/
typedef enum{
  IFX_SIP_EMERGENCY = 1,/*!< priority value is emergency */
  IFX_SIP_URGENT,/*!< priority value is urgent */
  IFX_SIP_NORMAL,/*!< priority value is normal */
  IFX_SIP_NONURGENT,/*!< priority value is non-urgent */
  IFX_SIP_OTHER_PRI/*!< Not a predefined priority value */
}e_IFX_SIP_PriValue;


/*! \enum e_IFX_SIP_ParamType
    \brief An Enumeration defining the parameter types.
*/
typedef enum{
  IFX_SIP_TAG_PARAM = 1,/*!< Tag parameter */
  IFX_SIP_GENERIC_PARAM_F/*!< Generic parameter */
} e_IFX_SIP_ParamType;

/*! \enum e_IFX_SIP_AddrType
    \brief An Enumeration defining the Address types.
*/
typedef enum{
  IFX_SIP_NAMEADDR = 1,/*!< Named address */
  IFX_SIP_ADDRSPEC/*!< Address without display name */
} e_IFX_SIP_AddrType;

/*! \enum e_IFX_SIP_CompositeType
    \brief An Enumeration defining the Composite types.
*/
typedef enum{
  IFX_SIP_MESSAGE = 1,/*!< Message */
  IFX_SIP_MULTIPART,/*!< Multipart body */
  IFX_SIP_EXT_COMP/*!< Not a predefined composite type */
} e_IFX_SIP_CompositeType;

/*! \enum e_IFX_SIP_DiscreteType
    \brief An Enumeration defining the Discrete types.
*/
typedef enum{
  IFX_SIP_TEXT = 1,/*!< Text */
  IFX_SIP_IMAGE,/*!< Image */
  IFX_SIP_AUDIO,/*!< Audio */
  IFX_SIP_VIDE0,/*!< Video */
  IFX_SIP_APPLICATION,/*!< Application */
  IFX_SIP_EXT_DISCR/*!< Extension discrete type */
} e_IFX_SIP_DiscreteType;


/*! \enum e_IFX_SIP_DispParamType
    \brief An Enumeration defining the Disposition param types.
*/
typedef enum{
  IFX_SIP_HANDLING_PARAM = 1,/*!< Describes how UAS should react if it receives a message bosy whose content type or disposition type it does not understand. Handling param has defined values of optional and required. If handling param is missing the value required is assumed. */
  IFX_SIP_GENERIC_PARAM/*!< Other non-standard/Extension type */
} e_IFX_SIP_DispParamType;

/*! \enum e_IFX_SIP_AinfoType
    \brief An Enumeration defining the A-Info types.
*/
typedef enum{
  IFX_SIP_NEXTNONCE = 1,/*!< Next nonce */
  IFX_SIP_MESG_QOP,/*!< Message QOP */
  IFX_SIP_RESP_AUTH,/*!< Response Auth */
  IFX_SIP_CNONCE_AI,/*!< C Nonce */
  IFX_SIP_NONCE_COUNT/*!< Nonce count */
} e_IFX_SIP_AinfoType;

/*! \enum e_IFX_SIP_DigRespType
    \brief An Enumeration defining the Digest response types.
*/
typedef enum{
  IFX_SIP_USERNAME = 1,/*!< User Name */
  IFX_SIP_REALM,/*!< Realm */
  IFX_SIP_NONCE,/*!< Nonce */
  IFX_SIP_DIGESTURI,/*!< Digest URI */
  IFX_SIP_DRESPONSE,/*!< Response */
  IFX_SIP_ALGORITHM,/*!< Algorithm */
  IFX_SIP_CNONCE,/*!< CNonce */
  IFX_SIP_OPAQUE_D,/*!< Opaque */
  IFX_SIP_MESSAGE_QOP,/*!< Message QOP */
  IFX_SIP_NONCE_CNT,/*!< Nonce count */
  IFX_SIP_AUTH_PARAM_NAME/*!< Auth param name */
} e_IFX_SIP_DigRespType;


/*! \enum e_IFX_SIP_RespType
    \brief An Enumeration defining the Authentication response types.
*/
typedef enum{
  IFX_SIP_DIGEST_RESPONSE = 1,/*!< Digest Authentication is used */
  IFX_SIP_OTHER_RESPONSE/*!< Other authentication scheme is used */
} e_IFX_SIP_RespType;

/*! \enum e_IFX_SIP_UriParamType
    \brief An Enumeration defining the URI parameters.
*/
typedef enum{
  IFX_SIP_TRANSP_PARAM = 1,/*!< Tranport parameter */
  IFX_SIP_USER_PARAM,/*!< User Parameter */
  IFX_SIP_METHOD_PARAM,/*!< Method parameter */
  IFX_SIP_TTL_PARAM,/*!< TTL parameter */
  IFX_SIP_MADDR_PARAM,/*!< multicast address parameter */
#ifdef RFC_3486
  IFX_SIP_COMP_PARAM,
#endif /*RFC_3486*/
  IFX_SIP_LR_PARAM,/*!< loose route parameter */
  IFX_SIP_OTHER_PARAM/*!< Other non-standard parameters */
} e_IFX_SIP_UriParamType;



/*! \enum e_IFX_SIP_UserType
    \brief An Enumeration defining the User types.
*/
typedef enum{
  IFX_SIP_USER = 1,/*!< Normal User */
  IFX_SIP_TEL_SUB/*!< User is Telephone subscriber */
} e_IFX_SIP_UserType;

/*! \enum e_IFX_SIP_HostType
    \brief An Enumeration defining the Host address types.
*/
typedef enum{
  IFX_SIP_HOSTNAME = 1,/*!< Address is a host name */
  IFX_SIP_IPV4ADDR,/*!< IPv4 Address */
  IFX_SIP_IPV6REF,/*!< IPv6 Address */
  IFX_SIP_HOSTINVALID/*!< Invalid Host */
} e_IFX_SIP_HostType;

/*! \enum e_IFX_SIP_AuthType
    \brief An Enumeration defining the Auth types.
*/
typedef enum{
  IFX_SIP_SRVR = 1,/*!< Server */
  IFX_SIP_REG/*!< Regname */
} e_IFX_SIP_AuthType;


/*! \enum e_IFX_SIP_PathType
    \brief An Enumeration defining the Path types.
*/
typedef enum{
  IFX_SIP_NETPATH = 1,/*!< Net Path */
  IFX_SIP_ABSPATH/*!< Absolute path */
} e_IFX_SIP_PathType;


/*! \enum e_IFX_SIP_PartType
    \brief An Enumeration defining the Host part types.
*/
typedef enum{
  IFX_SIP_HIER_PART = 1,/*!< Hier Part */
  IFX_SIP_OPAQUE_PART/*!< Opaque part */
} e_IFX_SIP_PartType;


/*! \enum e_IFX_SIP_SdpType
    \brief An Enumeration defining the Message body types.
*/
typedef enum{
  IFX_SIP_SDP_TEXT = 1,/*!< Message bosy is text */
  IFX_SIP_SDP_NON_TEXT,/*!< Message body is non-text */
  IFX_SIP_SDP_ABSENT,/*!< Message body is absent */
  IFX_SIP_SDP_MSGFRAG,/*!< Message body is sip message fragment */
  IFX_SIP_SDP_PLAINTEXT,/*!< Message body is plain text */
  IFX_SIP_SDP_HOOK_FLASH/*!< Message body is hook flash */
} e_IFX_SIP_SdpType;


/*! \enum e_IFX_SIP_MType
    \brief An Enumeration defining the M-Types.
*/
typedef enum{
  IFX_SIP_DISC_TYPE = 1,/*!< Content type is discrete */
  IFX_SIP_COMP_TYPE/*!< Content type is composite */
}e_IFX_SIP_MType;

/*! \enum e_IFX_SIP_ViaType
    \brief An Enumeration defining the Via Parameter types.
*/
typedef enum{
  IFX_SIP_VIA_TTL = 1,/*!< TTL parameter */
  IFX_SIP_VIA_MADDR,/*!< Multicast address parameter */
  IFX_SIP_VIA_RECEIVED,/*!< Received parameter */
  IFX_SIP_VIA_BRANCH,/*!< Branch parameter */
  IFX_SIP_VIA_RESPPORT,/*!< Response port parameter */
#ifdef RFC_3486
  IFX_SIP_VIA_COMP,
#endif /*RFC_3486*/
  IFX_SIP_VIA_EXTENSION/*!< Extension parameter */
} e_IFX_SIP_ViaType;


/* Added for draft-ietf-sip-replaces-02.txt */

/*! \enum e_IFX_SIP_RepParamType
    \brief An Enumeration defining Replaces parameter type.
*/
typedef enum{
  IFX_SIP_RP_FROMTAG = 1,/*!< From Tag parameter */
  IFX_SIP_RP_TOTAG,/*!< To tag parameter */
  IFX_SIP_RP_GENPARAM/*!< Generic parameter */
}e_IFX_SIP_RepParamType;

/* Added for 3265 */
/*! \enum e_IFX_SIP_EVNTRSN
    \brief An Enumeration defining the Event response reasons.
*/
typedef enum{
  IFX_SIP_EVNTRSN_DEACTIVATED,/*!< Deactivated */
  IFX_SIP_EVNTRSN_PROBATION,/*!< Probation */
  IFX_SIP_EVNTRSN_REJECTED,/*!< Rejected */
  IFX_SIP_EVNTRSN_TIMEOUT,/*!< Timeout */
  IFX_SIP_EVNTRSN_GIVEUP,/*!< Giveup */
  IFX_SIP_EVNTRSN_NORESOURSE,/*!< No resource */
  IFX_SIP_EVNTRSN_EXT/*!< Extension type */
}e_IFX_SIP_EVNTRSN;

/*! \enum e_IFX_SIP_SUBSTATE
    \brief An Enumeration defining the Subscription state.
*/
typedef enum{
  IFX_SIP_SUBSTATE_ACTIVE,/*!< Active state */
  IFX_SIP_SUBSTATE_PENDING,/*!< Pending state */
  IFX_SIP_SUBSTATE_TERMINATED,/*!< Terminated state */
  IFX_SIP_SUBSTATE_EXTN/*!< Not a pre-defined Subscription state */
}e_IFX_SIP_SUBSTATE;

/*! \enum e_IFX_SIP_EventParamType
    \brief An Enumeration defining the Event parameters.
*/
typedef enum{
  IFX_SIP_EPT_GENPARAM = 0,/*!< Generic event parameter */
  IFX_SIP_EPT_ID/*!< ID parameter */
}e_IFX_SIP_EventParamType;

/*! \enum e_IFX_SIP_SubExpParams
    \brief An Enumeration defining the Subscription expiry parameters.
*/
typedef enum{
  IFX_SIP_SUBEXP_REASON,/*!< Reason */
  IFX_SIP_SUBEXP_EXPIRES,/*!< Expires */
  IFX_SIP_SUBEXP_RETRYAFTER,/*!< Retry After */
  IFX_SIP_SUBEXP_GENPARAM/*!< Generic parameter */
}e_IFX_SIP_SubExpParams;
/*! \var typedef char ac_SIPVersion[IFX_SIP_VERSION]
    \brief Character buffer containing the SIP Version
*/
typedef char ac_SIPVersion[IFX_SIP_VERSION]; 
/*! \struct x_IFX_SIP_StatusCode
    \brief A structure defining the status type and code.
*/
typedef struct
{
    e_IFX_SIP_StatusType eStatusType;/*!< Status type */
    int16 nStatCode;/*!< Status code */
} x_IFX_SIP_StatusCode;


/********************************************************************/
/* Telephone subsriber as specified in the RFC 2806 */

/*! \def IFX_SIP_MAX_PHONE_NUMBER 
    \brief A macro defining maximum length of Phone number.
*/
#define IFX_SIP_MAX_PHONE_NUMBER  16
/*! \def IFX_SIP_MAX_AREA_SPEC
    \brief A macro defining maximum Area specifiers.
*/
#define IFX_SIP_MAX_AREA_SPEC      4
/*! \def IFX_SIP_MAX_DOMAIN
    \brief A macro defining maximum length of a domain.
*/
#define IFX_SIP_MAX_DOMAIN       256
/*! \def IFX_SIP_MAX_SERV_PROV
    \brief A macro defining maximum serv prov.
*/
#define IFX_SIP_MAX_SERV_PROV      2
/*! \def IFX_SIP_MAX_FUT_EXT
    \brief A macro defining maximum future extensions.
*/
#define IFX_SIP_MAX_FUT_EXT        1

/*! \enum e_IFX_SIP_NwPrefixType
    \brief An Enumeration defining the Network prefix.
*/
typedef enum{
  IFX_SIP_GLOBAL_NW_PREFIX = 0,/*!< Global network prefix */
  IFX_SIP_LOCAL_NW_PREFIX/*!< Local network prefix */
} e_IFX_SIP_NwPrefixType;

/*! \struct x_IFX_SIP_NwPrefix
    \brief A structure defining the Network prefix.
*/
typedef struct
{
    e_IFX_SIP_NwPrefixType eNwPrefixType;/*!< Type of network prefix */
    char8 szNwPrefix[IFX_SIP_MAX_PHONE_NUMBER];/*!< Information pertaining to the network prefix */
} x_IFX_SIP_NwPrefix;

/*! \enum e_IFX_SIP_PrefixType
    \brief An Enumeration defining the prefix Type.
*/
typedef enum{
  IFX_SIP_NW_PREFIX = 0,/*!< Network prefix */
  IFX_SIP_PRIVATE_PREFIX/*!< Private prefix */
} e_IFX_SIP_PrefixType;

/*! \struct x_IFX_SIP_PhContextIdent
    \brief A structure defining the Phone context Identifier.
*/
typedef struct
{
    e_IFX_SIP_PrefixType ePrefixType;/*!< Prefix Type */
    union
    {
        x_IFX_SIP_NwPrefix xNwPrefix;/*!< Network prefix */
        char8 szPrivatePrefix[IFX_SIP_MAX_TOKEN];/*!< Private prefix */
    }uxPrefixType;/*!< Union of possible prefix's */
} x_IFX_SIP_PhContextIdent;


/*! \enum e_IFX_SIP_TelSubType
    \brief An Enumeration defining the Telephone subscriber Type.
*/
typedef enum{
  IFX_SIP_GLOBAL_PHONE_NUMBER = 0,/*!< Global phone number */
  IFX_SIP_LOCAL_PHONE_NUMBER/*!< Local Phone number */
}e_IFX_SIP_TelSubType;

/*! \struct x_IFX_SIP_TelSub
    \brief A structure defining the Telephone subscriber.
*/
typedef struct
{
    e_IFX_SIP_TelSubType eTelSubType;/*!< Type of telephone subscriber */
    char8 szPhoneNo[IFX_SIP_MAX_PHONE_NUMBER];/*!< Phone number */
    uchar8 szIsdnSubAddr[IFX_SIP_MAX_PHONEDIGIT];/*!< ISDN sub address */
    uchar8 szPostDial[IFX_SIP_MAX_PHONEDIGIT];/*!< Post dial information */
    uchar8 ucNoOfAreaSpec;/*!< Number of Area speciffiers */
    x_IFX_SIP_PhContextIdent axPhContextIdent[IFX_SIP_MAX_AREA_SPEC];/*!< Phone Context Id Information */
    uchar8 ucNoOfServProv;/*!< Number of Server Province */
    char8 aszSerProv[IFX_SIP_MAX_SERV_PROV][IFX_SIP_MAX_DOMAIN];/*!< Information on server province */
    uchar8 ucNoOfExt;/*!< Number of extensions */

    char8 aszFutExt[IFX_SIP_MAX_FUT_EXT][IFX_SIP_MAX_TOKEN];/*!< Extension details */
} x_IFX_SIP_TelSub;

/***************************************************************************/

/*! \struct x_IFX_SIP_UserInfo
    \brief A structure defining the User Information.
*/
typedef struct
{
    e_IFX_SIP_UserType eUserType;/*!< User Type */
    union
    {
        char8 szUser[IFX_SIP_MAX_TOKEN];/*!< User */
        x_IFX_SIP_TelSub xTelSub;/*!< Telephone Subscriber */
    }uxUserType;/*!< Union of possible users */
    char8 szPasswd[16];/*!< Password */
} x_IFX_SIP_UserInfo;


/*! \var typedef char ac_IFX_SIP_HostName[IFX_SIP_MAX_TOKEN] 
    \brief Character buffer containing the Host Name
*/
typedef char ac_IFX_SIP_HostName[IFX_SIP_MAX_TOKEN];

/*! \struct x_IFX_SIP_Host
    \brief A structure defining the Host Information.
*/
typedef struct
{
    e_IFX_SIP_HostType eHostType;/*!< Host Information Type */
    char8 szHostInfo[IFX_SIP_MAX_TOKEN];/*!< Host Information */
} x_IFX_SIP_Host;

/*! \struct x_IFX_SIP_HostPort
    \brief A structure defining the Host Port.
*/
typedef struct
{
    x_IFX_SIP_Host xHost;/*!< Host Information */
    uint16 uiPort;/*!< uiPort = 0 => port value not set */
} x_IFX_SIP_HostPort;

/*! \struct x_IFX_SIP_Segment
    \brief A structure defining the Segment.
*/
typedef struct
{
    char8 szPchar[IFX_SIP_MAX_TOKEN];/*!< Segment text */
    uchar8 ucNoOfParam;/*!< Number of segment parameters */
    char8 aszParam[IFX_SIP_MAX_MPARAM][16];/*!< segment Parameter Information */
}x_IFX_SIP_Segment;

/*! \struct x_IFX_SIP_Method
    \brief A structure defining the Method type.
*/
typedef struct
{
    e_IFX_SIP_BasicMethod eBasicMethod;/*!< Predefined method */
    char8 szExtMethod[IFX_SIP_MAX_TOKEN];/*!< Details of extension method */
}x_IFX_SIP_Method;

/*! \struct x_IFX_SIP_DiscreteType
    \brief A structure defining the Discrete Types.
*/
typedef struct
{
    e_IFX_SIP_DiscreteType eDiscrType;/*!< Predefined discrete types */
    char8 szDiscStr[IFX_SIP_MAX_TOKEN];/*!< Extension discrete Information */
} x_IFX_SIP_DiscreteType;

/*! \struct x_IFX_SIP_CompositeType
    \brief A structure defining the Composite types.
*/
typedef struct
{
    e_IFX_SIP_CompositeType eCompositeType;/*!< Predefined composite types */
    char8 szCompStr[IFX_SIP_MAX_TOKEN];/*!< Extension composite types */
} x_IFX_SIP_CompositeType;

/**********************************************************************/

/*! \var typedef x_IFX_SIP_Host x_IFX_SIP_MaddrParam 
    \brief Multicast address parameter
*/
typedef x_IFX_SIP_Host x_IFX_SIP_MaddrParam;

/*! \var typedef x_IFX_SIP_Method x_IFX_SIP_MethodParam 
    \brief Method Parameter
*/
typedef x_IFX_SIP_Method x_IFX_SIP_MethodParam;

/*! \struct x_IFX_SIP_UserParam
    \brief A structure defining the User parameter types.
*/
typedef struct
{
    e_IFX_UserParamType eUserParamType;/*!< User Parameter types */
    char8 szOtherUser[IFX_SIP_MAX_TOKEN];/*!< Extension User parameter types */
} x_IFX_SIP_UserParam;


/*! \struct x_IFX_SIP_TranspParam
    \brief A structure defining the Transport parameter.
*/
typedef struct
{
    e_IFX_SIP_TransType eTransType;/*!< Predefined Transport parameter */
    char8 szOtherTrans[IFX_SIP_MAX_TOKEN];/*!< Other parameters */
} x_IFX_SIP_TranspParam;

/*! \struct x_IFX_SIP_UriParam
    \brief A structure defining the URI parameters.
*/
typedef struct
{
    e_IFX_SIP_UriParamType eUriParamType;/*!< URI parameter type */
    union
    {
        x_IFX_SIP_TranspParam xTranspParam;/*!< Transport types */
        x_IFX_SIP_UserParam xUserParam;/*!< User Parameters */
        x_IFX_SIP_MethodParam xMethodParam;/*!< Method parameter */
        uchar8 iTtlParam;/*!< TTL parameter */
        x_IFX_SIP_MaddrParam xMaddrParam;/*!< Multicast address parameter */
      #ifdef RFC_3486
        char8 szCompressionParam[IFX_SIP_MAX_TOKEN];
      #endif /*RFC_3486*/
        char8 szOtherParam[IFX_SIP_MAX_TOKEN];/*!< Other parameter */
    }uxUriParamType;/*!< Union of possible URI parameters */
} x_IFX_SIP_UriParam;

/*! \struct x_IFX_SIP_UriParams
    \brief A structure defining the URI parameters.
*/
typedef struct
{
    uchar8 ucNoOfUriParam;/*!< Number of URI parameters */
    x_IFX_SIP_UriParam axUriParam[IFX_SIP_MAX_URI];/*!< Details of URI parameters */
} x_IFX_SIP_UriParams;

/*! \struct x_IFX_SIP_Header
    \brief A structure defining a header.
*/
typedef struct
{
    char8 szHeaderName[IFX_SIP_MAX_TOKEN];/*!< Header Name */
    char8 szHeaderVal[IFX_SIP_MAX_TOKEN];/*!< Header Value */
} x_IFX_SIP_Header;

/*! \var typedef x_IFX_SIP_Header x_IFX_SIP_ExtHeader 
    \brief Extension Header
*/
typedef x_IFX_SIP_Header x_IFX_SIP_ExtHeader;

/*! \struct x_IFX_SIP_Headers
    \brief A structure defining the Header.
*/
typedef struct
{
    uchar8 ucNoOfHeader;/*!< Number of headers */
    x_IFX_SIP_Header axHeader[IFX_SIP_MAX_HEADER];/*!< Header Information */
}x_IFX_SIP_Headers;

/*! \struct x_IFX_SIP_PathSegments
    \brief A structure defining the path segments.
*/
typedef struct
{
    uchar8 ucNoOfSegment;/*!< Number of segments */
    x_IFX_SIP_Segment axSegment[IFX_SIP_MAX_SEGMENT];/*!< Segment Information */
} x_IFX_SIP_PathSegments;


/*! \var typedef x_IFX_SIP_PathSegments x_IFX_SIP_AbsPath 
    \brief Absolute path
*/
typedef x_IFX_SIP_PathSegments x_IFX_SIP_AbsPath;

/*! \struct x_IFX_SIP_Authority
    \brief A structure defining the Authority.
*/
typedef struct
{
    char8 szAuthority[IFX_SIP_MAX_TOKEN];/*!< Authority */
}x_IFX_SIP_Authority;



/*! \struct x_IFX_SIP_NetPath
    \brief A structure defining the Net path.
*/
typedef struct
{
/*! \def ABS_PATH 
    \brief A macro defining maximum user length.
*/
#define ABS_PATH  0x01 /* ABS_PATH is an option */

    uchar8 ucOptions;/*!<  To check the presence /absence of xAbsPath */
    x_IFX_SIP_Authority xAuthority;/*!< Authority */
    x_IFX_SIP_AbsPath xAbsPath;/*!< Absolute path */
}x_IFX_SIP_NetPath;


/*! \struct x_IFX_SIP_HierPart
    \brief A structure defining the Hier part.
*/
typedef struct
{
    e_IFX_SIP_PathType ePathType;/*!< Path type */
    union
    {
        x_IFX_SIP_NetPath xNetPath;/*!< Net path */
        x_IFX_SIP_AbsPath xAbsPath;/*!< Absolute path */
    } uxPathType;/*!< Union of possible paths */

    char8 szQuery[IFX_SIP_MAX_QUERY];/*!< Query */
} x_IFX_SIP_HierPart;


/*
* scheme should be filled according to the grammar 
*
*/

/*! \struct x_IFX_SIP_AbsoluteURI
    \brief A structure defining the Absolute URI.
*/
typedef struct
{
    uchar8 ucScheme[IFX_SIP_MAX_SCHEME];/*!< Scheme */
    e_IFX_SIP_PartType ePartType;/*!< Part Type */
    union
    {
        x_IFX_SIP_HierPart xHierPart;/*!< Hier Part */
        char8 szOpaquePart[IFX_SIP_MAX_TOKEN];/*!< Opaque Part */
    } uxHierOpaquePart;/*!< Possible Parts */
} x_IFX_SIP_AbsoluteURI;

/*! \struct x_IFX_SIP_SipUri
    \brief A structure defining the SIP URI.
*/
typedef struct
{
    x_IFX_SIP_UserInfo xUserInfo;/*!< User Information */
    x_IFX_SIP_HostPort xHostPort;/*!< Host Information */
    x_IFX_SIP_UriParams xUriParams;/*!< URI parameters */
    x_IFX_SIP_Headers xHeaders;/*!< Headers */
} x_IFX_SIP_SipUri;

/*! \var typedef x_IFX_SIP_SipUri x_IFX_SIP_SipsUri 
    \brief SIPS URI
*/
typedef x_IFX_SIP_SipUri x_IFX_SIP_SipsUri;

/*! \struct x_IFX_SIP_AddrSpec
    \brief A structure defining the Address Spec.
*/
typedef struct
{
    e_IFX_SIP_UriType eUriType;/*!< URI type */
    union
    {
        x_IFX_SIP_SipUri xSipURI;/*!< SIP URI */
        x_IFX_SIP_SipsUri xSipsURI;/*!< SIPS URI */
        x_IFX_SIP_AbsoluteURI xAbsoluteURI;/*!< Absolute URI */
    }uxUriType;
} x_IFX_SIP_AddrSpec, x_IFX_SIP_RquestUri, x_IFX_SIP_ReqURI;


/*! \struct x_IFX_SIP_NameAddr
    \brief A structure defining the Name Addr.
*/
typedef struct
{
    char8 szDisplayName[IFX_SIP_MAX_TOKEN];/*!< Display Name */
    x_IFX_SIP_AddrSpec xAddrSpec;/*!< Address Spec */
} x_IFX_SIP_NameAddr;


/*! \struct x_IFX_SIP_GenericParam
    \brief A structure defining the Generic parameter.
*/
typedef struct
{
    char8 szToken[IFX_SIP_MAX_TOKEN];/*!< Token */
    char8 szGenValue[IFX_SIP_MAX_TOKEN];/* Generic Value, Null string in absence */
}x_IFX_SIP_GenericParam;

/*! \var typedef x_IFX_SIP_GenericParam x_IFX_SIP_RRParam 
    \brief Record-Route parameters
*/
typedef x_IFX_SIP_GenericParam x_IFX_SIP_RRParam;

/*! \struct x_IFX_SIP_MType
    \brief A structure defining MType.
*/
typedef struct
{
    e_IFX_SIP_MType eMType;/*!< Content Type */
    union
    {
        x_IFX_SIP_DiscreteType xDiscreteType;/*!< Discrete type */
        x_IFX_SIP_CompositeType xCompositeType;/*!< Composite type */
    }uxMType;/*!< Possible M Types */
}x_IFX_SIP_MType;

/*! \struct x_IFX_SIP_MParam
    \brief A structure defining Content type parameters.
*/
typedef struct
{
    char8 szMAttr[IFX_SIP_MAX_TOKEN];/*!< Media attribute */
    char8 szMVal[IFX_SIP_MAX_TOKEN];/*!< Value */
} x_IFX_SIP_MParam;

/*! \struct x_IFX_SIP_ServerVal
    \brief A structure defining the server value.
*/
typedef struct
{
    e_IFX_SIP_ServerValtype eServerValType;/*!< Predefined Server Values */
    char8 szPrStr[IFX_SIP_MAX_TOKEN];/*!< Server Info */
} x_IFX_SIP_ServerVal;

/*! \struct x_IFX_SIP_WarningValue
    \brief A structure defining the warning header.
*/
typedef struct
{
    int16 nWarnCode;/*!< Warning code */
    char8 szWarnAgent[IFX_SIP_MAX_TOKEN];/*!< Agent generating warning */
    char8 szWarnText[IFX_SIP_MAX_QUOTED_STR];/*!< Warning Text */
} x_IFX_SIP_WarningValue;


/*! \struct x_IFX_SIP_AcceptParam
    \brief A structure defining the Accept parameters.
*/
typedef struct
{
/*! \def IFX_SIP_QVALUE
    \brief A macro defining QOP value.
*/
#define IFX_SIP_QVALUE       0x01
/*! \def IFX_SIP_GENERIC_PARAM 
    \brief A macro defining Generic param.
*/
#define IFX_SIP_GENERIC_PARAM      0x02

    uchar8 ucChoiceOnUnion;/*!< Type of accept parameter */
    union
    {
        float32 fQvalue;/*!< Q Value */
        x_IFX_SIP_GenericParam xGenericParam;/*!< Generic Parameter */
    }uxAparam;/*!< Union containing possible parameters */
}x_IFX_SIP_AcceptParam;

/*! \struct x_IFX_SIP_QopValue
    \brief A structure defining the QOP Value.
*/
typedef struct
{
    e_IFX_SIP_QopValType eQopValType;/*!< Quality of protection value */
    char8 szQopVal[IFX_SIP_MAX_TOKEN];/*!< QOP extension details */
} x_IFX_SIP_QopValue;

/*! \struct x_IFX_SIP_AuthParam
    \brief A structure defining the Authentication parameters.
*/
typedef struct
{
    char8 szAuthParamName[IFX_SIP_MAX_TOKEN];/*!< Authentication parameter */
    char8 szValue[IFX_SIP_MAX_TOKEN];/*!< Value can be token or quoted string */
} x_IFX_SIP_AuthParam;

/*! \struct x_IFX_SIP_Algorithm
    \brief A structure defining the Algorithm.
*/
typedef struct
{
    e_IFX_SIP_AlgType eAlgType;/*!< Algorithm types */
    char8 szOtherAlg[IFX_SIP_MAX_TOKEN];/*!< Algorithm details if not a predefined type */
} x_IFX_SIP_Algorithm;

/*! \struct x_IFX_SIP_Uri
    \brief A structure defining the SIP URI.
*/
typedef struct
{
    e_IFX_SIP_SipUriType eSipUriType;/*!< URI type */
    union
    {
        x_IFX_SIP_AbsoluteURI xAbsoluteUri;/*!< Absolute URI */
        x_IFX_SIP_AbsPath xAbsPath;/*!< Absolute path */
    }uxUriType;/*!< Possible URI types */
} x_IFX_SIP_Uri;

/*! \var typedef x_IFX_SIP_QopValue x_IFX_SIP_MsgQop 
    \brief Quality of protection of a message
*/
typedef x_IFX_SIP_QopValue x_IFX_SIP_MsgQop;


/*! \var typedef x_IFX_SIP_RquestUri x_IFX_SIP_DigestUriValue, x_IFX_SIP_DigestUri 
    \brief Digest URI
*/
typedef x_IFX_SIP_RquestUri x_IFX_SIP_DigestUriValue, x_IFX_SIP_DigestUri;

/*! \struct x_IFX_SIP_QopOptions
    \brief A structure defining the QOP options.
*/
typedef struct
{
    uchar8 ucNoOfQopValue;/*!< Number of QOP Values */
    x_IFX_SIP_QopValue axQopValue[IFX_SIP_MAX_QOP_VALUE];/*!< Info on each QOP value */
} x_IFX_SIP_QopOptions;

/*! \struct x_IFX_SIP_Domain
    \brief A structure defining a doamin.
*/
typedef struct
{
    uchar8 ucNoOfUri;/*!< Number of URIs */
    x_IFX_SIP_Uri axUri[IFX_SIP_MAX_URI];/*!< Information of each URI */
} x_IFX_SIP_Domain;

/*! \struct x_IFX_SIP_DigResp
    \brief A structure defining the digest response.
*/
typedef struct
{
    e_IFX_SIP_DigRespType eDigRespType;/*!< Digest response type */
    union
    {
        char8 szUserName[IFX_SIP_MAX_TOKEN];/*!< User Name */
        char8 szRealm[IFX_SIP_MAX_QUOTED_STR];/*!< Realm */
        char8 szNonce[IFX_SIP_MAX_QUOTED_STR];/*!< Nonce */
        x_IFX_SIP_DigestUri xDigestUri;/*!< Digest URI */
        char8 szDresponse[IFX_SIP_MAX_DRESPONSE];/*!< Response */
        x_IFX_SIP_Algorithm xAlgorithm;/*!< Algorithm */
        char8 szCnonce[IFX_SIP_MAX_QUOTED_STR];/*!< Cnonce */
        char8 szOpaque[IFX_SIP_MAX_QUOTED_STR];/*!< Opaque */
        x_IFX_SIP_MsgQop xMsgQop;/*!< Message QOP */
        char8 szNonceCount[IFX_SIP_MAX_QUOTED_STR];/*!< Nonce count */
        x_IFX_SIP_AuthParam xAuthParam;/*!< Authentication parameters */
    }uxDigRespType;/*!< Union of possible Authentication parameters */
} x_IFX_SIP_DigResp;



/*! \struct x_IFX_SIP_DigestCln
    \brief A structure defining the Digest Challenge.
*/
typedef struct
{
    e_IFX_SIP_DigestClnType eDigestClnType;/*!< Digest challenge type */
    union
    {
        char8 szRealm[IFX_SIP_MAX_QUOTED_STR];/*!< Realm */
        x_IFX_SIP_Domain xDomain;/*!< Domain */
        char8 szNonce[IFX_SIP_MAX_QUOTED_STR];/*!< Nonce */
        char8 szOpaque[IFX_SIP_MAX_QUOTED_STR];/*!< Opaque */
        e_IFX_SIP_Boolean eStale;/*!< Stale */
        x_IFX_SIP_Algorithm xAlgorithm;/*!< Algorithm */
        x_IFX_SIP_QopOptions xQopOptions;/*!< QOP options */
        x_IFX_SIP_AuthParam xAuthParam;/*!< Authentication parameters */
    }uxDigestClnType;/*!< Union of digest challenge types */
} x_IFX_SIP_DigestCln;

/*! \struct x_IFX_SIP_HandlingParam
    \brief A structure defining the Handling parameters.
*/
typedef struct
{
/*! \def IFX_SIP_OPTIONAL
    \brief A macro defining Optional
*/
#define IFX_SIP_OPTIONAL       0x01
/*! \def IFX_SIP_REQUIRED
    \brief A macro defining Required.
*/
#define IFX_SIP_REQUIRED       0x02
/*! \def IFX_SIP_OTHER_HANDLING
    \brief A macro defining Other handling.
*/
#define IFX_SIP_OTHER_HANDLING 0X04

    uchar8 ucHandlingParamType;/*!< Handling Parameter type */
    char8 szOtherHandling[IFX_SIP_MAX_TOKEN];/*!< Details of handling parameter */
} x_IFX_SIP_HandlingParam;

/*! \struct x_IFX_SIP_ContParams
    \brief A structure defining the Contact parameters.
*/
typedef struct
{
/*! \def IFX_SIP_C_P_Q 
    \brief A macro defining Q Value.
*/
#define IFX_SIP_C_P_Q        0x01
/*! \def IFX_SIP_C_P_EXPIRES
    \brief A macro defining Expires.
*/
#define IFX_SIP_C_P_EXPIRES  0x02
/*! \def IFX_SIP_CONT_EXT
    \brief A macro defining Extension.
*/
#define IFX_SIP_CONT_EXT     0x04

    uchar8 ucContParamsType;/*!< Content parameter Type */
    union
    {
        float32 fCpq; /*!< Q Value */
        uint32 uiCpExpires; /*!< delta-seconds */
        x_IFX_SIP_GenericParam xGenericParam; /*!< cont-ext */
    }uxContParamsType;/*!< Union of possible contact parameters */
} x_IFX_SIP_ContParams;

/*! \struct x_IFX_SIP_InfoParam
    \brief A structure defining the Info parameters.
*/
typedef struct
{
/*! \def IFX_SIP_PURPOSE 
    \brief A macro defining Purpose.
*/
#define IFX_SIP_PURPOSE              0x01
/*! \def IFX_SIP_GENERIC_PARAM_INFO
    \brief A macro defining Generic parameter Info.
*/
#define IFX_SIP_GENERIC_PARAM_INFO   0X02

    uchar8 ucChoiceOnUnion;/*!< Type of Info parameter */
    union
    {
        struct
        {
/*! \def IFX_SIP_ICON
    \brief A macro defining ICON.
*/
#define IFX_SIP_ICON   0X01
/*! \def IFX_SIP_INFO
    \brief A macro defining INFO.
*/
#define IFX_SIP_INFO   0X02
/*! \def IFX_SIP_CARD
    \brief A macro defining CARD.
*/
#define IFX_SIP_CARD   0x04
/*! \def IFX_SIP_TOKEN
    \brief A macro defining Token.
*/
#define IFX_SIP_TOKEN  0x08

            uchar8 ucPurposeType;/*!< Purpose type */
            char8 szToken[IFX_SIP_MAX_TOKEN];/*!< Details in case purpose is token */
        }xPurposeType;/*!< Purpose type */
        x_IFX_SIP_GenericParam xGenericParam;/*!< Generic parameters */
    }uxInfoParamType;/*!< Union of Info parameters */
}x_IFX_SIP_InfoParam;

/*! \struct x_IFX_SIP_OtherResp
    \brief A structure used for non-standard authentication schemes.
*/
typedef struct
{
    char8 szAuthScheme[IFX_SIP_MAX_TOKEN];/*!< Authentication scheme */
    uchar8 ucNoOfAuthParam; /*!< Number of authentication params should be atleast 1 */
    x_IFX_SIP_AuthParam axAuthParam[IFX_SIP_MAX_AUTH_PARAM];/*!< Details of each authentication parameters */
} x_IFX_SIP_OtherResp;

/*! \struct x_IFX_SIP_DigestResp
    \brief A structure defining the Digest response.
*/
typedef struct
{
    uchar8 ucNoOfDigResp;/*!< Number of digest responses */
    x_IFX_SIP_DigResp axDigResp[IFX_SIP_MAX_DIG_RESP];/*!< Details of digest responses */
} x_IFX_SIP_DigestResp;


/*! \struct x_IFX_SIP_Codings
    \brief A structure defining the Content Encodings.
*/
typedef struct
{
    uchar8 ucContEncFlag;/*!< If 0 - for content coding, others- * */
    char8 szContentEncoding[IFX_SIP_MAX_TOKEN];/*!< Content Encoding */
} x_IFX_SIP_Codings;


/*! \struct x_IFX_SIP_MediaRange
    \brief A structure defining the Media range.
*/
typedef struct
{
/*! \def IFX_SIP_MR_WILD_CHAR
    \brief A macro defining maximum user length.
*/
#define IFX_SIP_MR_WILD_CHAR         0x01
/*! \def IFX_SIP_MTYPE_WITH_WILDCHAR
    \brief A macro defining maximum user length.
*/
#define IFX_SIP_MTYPE_WITH_WILDCHAR  0X02
/*! \def IFX_SIP_MTYPE_WITH_MSUBTYPE
    \brief A macro defining maximum user length.
*/
#define IFX_SIP_MTYPE_WITH_MSUBTYPE  0x04

    uchar8 ucChoiceOnUnion;/*!< Choice on union within 3 values */
	/*! \union x_IFX_SIP_MediaRange
    \brief A union defining media type containing all possible parameters.
*/
    union
    {
        /*char8         szMrWildChar[IFX_SIP_MAX_TOKEN];*/
        /* use "* / *" constant when type is IFX_SIP_MR_WILD_CHAR */
        x_IFX_SIP_MType xMtypeWithWildChar;/*!<Used when the choice on Union is IFX_SIP_MTYPE_WITH_WILDCHAR */
/*! \struct xMtypeWithMSubType
    \brief A structure defining Media type with media subtype.
*/
        struct
        {
            x_IFX_SIP_MType xMtype;/*!< Indicates the Mtype */
            char8 szMSubType[IFX_SIP_MAX_TOKEN];/*!<Indicates the media sub types that can be accepted */
        } xMtypeWithMSubType;
    } uxMediaType;

    uchar8 ucNoOfMparam;/*!< Number of media parameters*/
    x_IFX_SIP_MParam axMparam[IFX_SIP_MAX_MPARAM];/*!<Description of Media Param */
} x_IFX_SIP_MediaRange;

/*! \struct x_IFX_SIP_RouteParam
    \brief A structure defining Route and record Route headers..
*/
typedef struct
{
    x_IFX_SIP_NameAddr xNameAddr;/*!<Proxy Address */
    uchar8 ucNoOfRRParam;/*!< Number of Record route parameters*/
    x_IFX_SIP_RRParam axRRParam[IFX_SIP_MAX_RRPARAM];/*!< Record route parameters.*/
} x_IFX_SIP_RouteParam;

/*! \struct x_IFX_SIP_RetryParam
    \brief A structure defining Retry-After header.
*/
typedef struct
{
    e_IFX_SIP_RetryParamType eRetryParamType;/*!< Retry parameter type*/
/*! \struct uxRetryParamType
    \brief Union containing detailed information about the selected retry parameter.
*/
    union
    {
        int32 iDeltaSec;/*!< Duration for which the service is available starting from the time specified in the retry-header*/
        x_IFX_SIP_GenericParam xGenericParam;/*!< Other extension/non-standard parameters*/
    }uxRetryParamType;
} x_IFX_SIP_RetryParam;

/*! \var typedef x_IFX_SIP_GenericParam x_IFX_SIP_RplyToParam 
    \brief Reply To parameter
*/
typedef x_IFX_SIP_GenericParam x_IFX_SIP_RplyToParam;
/*! \var typedef x_IFX_SIP_RouteParam x_IFX_SIP_RecRoute 
    \brief Record Route
*/

typedef x_IFX_SIP_RouteParam x_IFX_SIP_RecRoute;

/*! \struct x_IFX_SIP_OtherChal
    \brief A structure defining parameters of non standard authentication.
*/
typedef struct
{
    char8 szAuthScheme[IFX_SIP_MAX_TOKEN];/*!<Authentication scheme */
    uchar8 ucNoOfAuthParam;/*!< Number of authentication parameters*/
    x_IFX_SIP_AuthParam axAuthParam[IFX_SIP_MAX_TOKEN];/*!< Authentication parameters*/
} x_IFX_SIP_OtherChal;

/*! \struct x_IFX_SIP_DigestChal
    \brief A structure defining the digest authentication parameters.
*/
typedef struct
{
    uchar8 ucNoOfDigestCln;/*!<Number of digest challenges */
    x_IFX_SIP_DigestCln axDigestCln[IFX_SIP_MAX_DIGEST_CLN];/*!<Array containing the information on the digest parameters */
} x_IFX_SIP_DigestChal;

/*! \struct x_IFX_SIP_ErrorUri
    \brief A structure defining the error info header fields.
*/
typedef struct
{
    x_IFX_SIP_AbsoluteURI xAbsUri;/*!<Absolute URI */
    uchar8 ucNoOfGenParam;/*!<Number of parameters */
    x_IFX_SIP_GenericParam axGenericParam[IFX_SIP_MAX_GEN_PARAM];/*!<Extension/non-standard parameters */
} x_IFX_SIP_ErrorUri;


/*! \struct x_IFX_SIP_LangTag
    \brief A structure defining language tag fields of content-language header.
*/
typedef struct
{
    char8 szPrimaryTag[IFX_SIP_MAX_PRIM_TAG];/*!<Primary tag in the language */
    uchar8 ucNoOfSubTag;/*!<Number of sub tags */
    char8 aszSubTag[IFX_SIP_MAX_SUB_TAG][IFX_SIP_MAX_TOKEN];/*!< Each subtag Information*/
} x_IFX_SIP_LangTag;


/*! \struct x_IFX_SIP_DispParam
    \brief A structure defining the parameters of content disposition.
*/
typedef struct
{
    e_IFX_SIP_DispParamType eDispParamType;/*!< Disposition parameters*/
/*! \union uxDParam
    \brief An union containing possible parameters.
*/
    union
    {
        x_IFX_SIP_HandlingParam xHandlingParam;/*!< Handling parameters*/
        x_IFX_SIP_GenericParam xGenericParam;/*!< Extension/non-standard parameters*/
    }uxDParam;
} x_IFX_SIP_DispParam;


/*! \struct x_IFX_SIP_DispType
    \brief A structure defining the disposition type of content disposition header.
*/
typedef struct
{
/*! \def IFX_SIP_RENDER
    \brief A macro defining information rendered to the user.
*/
#define IFX_SIP_RENDER   0x01
/*! \def IFX_SIP_SESSION
    \brief A macro defining description of session.
*/
#define IFX_SIP_SESSION  0x02
/*! \def IFX_SIP_ICON_D
    \brief A macro defining image icon.
*/
#define IFX_SIP_ICON_D   0x04
/*! \def IFX_SIP_ALERT
    \brief A macro defining alert.
*/
#define IFX_SIP_ALERT    0X08
/*! \def IFX_SIP_DISP_EXT
    \brief A macro defining extension disposition type.
*/
#define IFX_SIP_DISP_EXT 0X10

    uchar8 ucDType;/*!< Disposition type*/
    char8 szDispExt[IFX_SIP_MAX_TOKEN];/*!< Information when the disposition type is IFX_SIP_DISP_EXT*/
} x_IFX_SIP_DispType;


/*! \struct x_IFX_SIP_AddressType
    \brief A structure defining nameaddr and addrspec.
*/
typedef struct
{
    e_IFX_SIP_AddrType eAddrType;/*!< Address Type*/
/*! \union uxAddrType
    \brief An uinon containing possible addresses.
*/
    union
    {
        x_IFX_SIP_NameAddr xNameAddr;/*!< Name-Addr*/
        x_IFX_SIP_AddrSpec xAddrSpec;/*!< Addr-Spec*/
    }uxAddrType;
}x_IFX_SIP_AddressType;

/*! \struct x_IFX_SIP_ContactParam
    \brief A structure defining the contact header value.
*/
typedef struct
{
    x_IFX_SIP_AddressType xAddrType;/*!< Contact address*/

    uchar8 ucNoOfContParams;/*!< Number of contact parameters*/
    x_IFX_SIP_ContParams axContParams[IFX_SIP_MAX_CONT_PARAMS];/*!<Array of contact parameters */
} x_IFX_SIP_ContactParam;

/*! \struct x_IFX_SIP_Info
    \brief A structure defining info parameters.
*/
typedef struct
{
    x_IFX_SIP_AbsoluteURI xAbsUri;/*!< URI Information*/
    uchar8 ucNoOfInfoParam;/*!<Number of Info parameters */
    x_IFX_SIP_InfoParam axInfoParam[IFX_SIP_MAX_INFO_PARAM];/*!<Array containing Information parameters */
} x_IFX_SIP_Info;

/*! \struct x_IFX_SIP_Credential
    \brief A structure defining credential information for authentication.
*/
typedef struct
{
    e_IFX_SIP_RespType eRespType;/*!<Response type being used */
/*! \union uxRespType
    \brief An uinon containing possible response types.
*/
    union
    {
        x_IFX_SIP_DigestResp xDigestResp;/*!<Digest response */
        x_IFX_SIP_OtherResp xOtherResp;/*!< Authentication other than digest*/
    }uxRespType;
} x_IFX_SIP_Credential;

/*! \struct x_IFX_SIP_Credentials
    \brief A structure defining the proxy authentication credentials.
*/
typedef struct
{
    uchar8 ucNoOfCred;/*!< Number of credentials*/
    x_IFX_SIP_Credential* apxCredential[IFX_SIP_MAX_CREDENTIALS];/*!< Credential information*/
} x_IFX_SIP_Credentials;/*!< */

/*! \struct x_IFX_SIP_AInfo
    \brief A structure defining the alert info for authentication.
*/
typedef struct
{
/*! \def IFX_SIP_MAX_NC
    \brief A macro defining maximum number of nonce.
*/
#define IFX_SIP_MAX_NC 0x09
    e_IFX_SIP_AinfoType eAinfoType;/*!< Type of authentication Info parameter*/
/*! \union uxAinfoType
    \brief An uinon containing all possible authentication Information parameters.
*/
    union
    {
        char8 szNextNonce[IFX_SIP_MAX_QUOTED_STR];/*!<Next Nonce */
        x_IFX_SIP_QopValue xMesgQop;/*!< Quality of protection*/
        char8 szRespAuth[IFX_SIP_MAX_TOKEN];/*!< Response authentication*/
        char8 szCnonce[IFX_SIP_MAX_TOKEN];/*!<Cnonce */
        char8 szNonceCount[IFX_SIP_MAX_NC];/*!<Nonce count */
    }uxAinfoType;
} x_IFX_SIP_AInfo;



/*! \struct x_IFX_SIP_AlertParam
    \brief A structure defining the alert parameters.
*/
typedef struct
{
    x_IFX_SIP_AbsoluteURI xAbsoluteUri;/*!< Absolute URI*/
    uchar8 ucNoOfGenParam;/*!<Number of Generic parameters */
    x_IFX_SIP_GenericParam axGenericParam[IFX_SIP_MAX_GEN_PARAM];/*!<Array containing the details of generic parameters */
} x_IFX_SIP_AlertParam;

/*! \struct x_IFX_SIP_Language
    \brief A structure defining the language of accept language header.
*/
typedef struct
{
    char8 bLangFlag;/*!< Language flag*/
    char8 szLangRange[IFX_SIP_MAX_TOKEN];/*!<Language range */
    uchar8 ucNoOfAcceptParam;/*!<Number of accept parameters */
    x_IFX_SIP_AcceptParam axAcceptParam[IFX_SIP_MAX_ACCEPT_PARAM];/*!< Array of accept parameters*/
}x_IFX_SIP_Language;

/*! \struct x_IFX_SIP_Encoding
    \brief A structure defining the encoding scheme of accept encoding header.
*/
typedef struct
{
    x_IFX_SIP_Codings xCodings;/*!< Codings that are acceptable*/
    uchar8 ucNoOfAcceptParam;/*!< Number of accept parameters*/
    x_IFX_SIP_AcceptParam axAcceptParam[IFX_SIP_MAX_ACCEPT_PARAM];/*!< Array of accept parameters*/
} x_IFX_SIP_Encoding;

/*! \struct x_IFX_SIP_AcceptRange
    \brief A structure defining the media range and the accept parameters.
*/
typedef struct
{
    x_IFX_SIP_MediaRange xMediaRange;/*!< Media Range*/
    uchar8 ucNoOfAcceptParam;/*!<Number of accept parameters */
    x_IFX_SIP_AcceptParam axAcceptParam[IFX_SIP_MAX_ACCEPT_PARAM];/*!< Array of accept parameters*/
}x_IFX_SIP_AcceptRange;

/*! \enum e_IFX_SIP_RcvdAddrType
    \brief An Enumeration defining the IP version.
*/
typedef enum{
  IFX_SIP_RCVD_IPV4 = 1,/*!< IP Version 4*/
  IFX_SIP_RCVD_IPV6 /*!< IP Version 6*/
} e_IFX_SIP_RcvdAddrType;


/*! \struct x_IFX_SIP_RcvdAddr
    \brief A structure defining the recieve address.
*/
typedef struct
{
    e_IFX_SIP_RcvdAddrType eRcvdAddrType;/*!< Address type*/
    char8 szIpAddr[IFX_SIP_MAX_IPV6];/*!< Address over which the request has been received*/
} x_IFX_SIP_RcvdAddr;


/*! \struct x_IFX_SIP_ViaParams
    \brief A structure defining the via parameters.
*/
typedef struct
{
    e_IFX_SIP_ViaType eViaType;/*!< Via parameter in the Union*/
/*! \union uxViaType
    \brief An uinon containing possible via parameters.
*/
    union
    {
        uchar8 iTtl;/*!< Time to live*/
        char8 szViaMaddr[IFX_SIP_MAX_HOST];/*!< UAC when sending a message to a multicast address*/
        x_IFX_SIP_RcvdAddr xRcvdAddr;/*!< Address from which the message has been received*/
        char8 szToken[IFX_SIP_MAX_TOKEN];/*!<Branch parameter */
        uint16 unRespPort;/*!<Responce port number */
       #ifdef RFC_3486
        char8 szCompressionParam[IFX_SIP_MAX_TOKEN];
      #endif /*RFC_3486*/
        x_IFX_SIP_GenericParam xViaExt;/*!<Extension/non-standard via parameters */
    }uxViaType;
} x_IFX_SIP_ViaParams;

/*! \typedef x_IFX_SIP_HostPort x_IFX_SIP_SentBy
    \brief A structure defining the host port.
*/
typedef x_IFX_SIP_HostPort x_IFX_SIP_SentBy;

/*! \struct x_IFX_SIP_SentProto
    \brief A structure defining the protocol being used for transport.
*/
typedef struct
{
    char8 szprotocol[IFX_SIP_MAX_TOKEN];/*!< Protocol being used.*/
    char8 szTransport[IFX_SIP_MAX_TOKEN];/*!< Transport type being used for communication.*/
} x_IFX_SIP_SentProto;

/*! \struct x_IFX_SIP_Warning
    \brief A structure defining the warning header.
*/
typedef struct
{
    uchar8 ucNoOfWarningValue;/*!<Number of warning headers */
    x_IFX_SIP_WarningValue axWarningValue[IFX_SIP_MAX_WARNING_VALUE];/*!<Warming Information */
} x_IFX_SIP_Warning;

/*! \struct x_IFX_SIP_TimeStamp
    \brief A structure defining the time stamp header.
*/
typedef struct
{
/*! \def IFX_SIP_DIGIT2
    \brief A macro defining digit2.
*/
#define IFX_SIP_DIGIT2 0x01
/*! \def IFX_SIP_DIGIT4
    \brief A macro defining digit4.
*/
#define IFX_SIP_DIGIT4 0x02
/*! \def IFX_SIP_DELAY
    \brief A macro defining delay.
*/
#define IFX_SIP_DELAY  0x04

    uchar8 ucOptions;/*!<To indicate presence of digits and delay parameters */

	float32 fTimeStamp;
	float32 fDelay;
#if 1 
    int32 iDigit1;/*!<Digit 1 */
    int32 iDigit2;/*!<Digit 2 */
    int32 iDigit3;/*!< Digit 1of dealy*/
    int32 iDigit4;/*!< Digit 2of dealy*/
#endif
} x_IFX_SIP_TimeStamp;

/*! \struct x_IFX_SIP_Server
    \brief A structure defining the UAS sip server.
*/
typedef struct
{
    uchar8 ucNoOfServerVal;/*!< Number of description fields added*/
    x_IFX_SIP_ServerVal axServerVal[IFX_SIP_MAX_SERVER_VAL];/*!<Useragent/server description Information */
} x_IFX_SIP_Server;

/*! \typedef x_IFX_SIP_Server x_IFX_SIP_UserAgent
    \brief A structure defining the UA.
*/
typedef x_IFX_SIP_Server x_IFX_SIP_UserAgent;

/*! \struct x_IFX_SIP_Route
    \brief A structure defining the force routing.
*/
typedef struct
{
    uchar8 ucNoOfRouteParam;/*!< Number of route headers being added*/
    x_IFX_SIP_RouteParam* apxRouteParam[IFX_SIP_MAX_ROUTE_PARAM];/*!<Details of the proxies through which request have to traverse */
} x_IFX_SIP_Route;

/*! \struct x_IFX_SIP_RetryAfter
    \brief A structure defining the retry after header.
*/
typedef struct
{
    int32 iDeltaSec;/*!< Time after which the service would be available*/

    /* a '\0' in first location indicates absence */
    char8 szComment[IFX_SIP_MAX_TOKEN];/*!< Reason for non-availability*/

    uchar8 ucNoOfRetryParam;/*!< Number of retry parameters*/
    x_IFX_SIP_RetryParam axRetryParam[IFX_SIP_MAX_RETRY_PARAM];/*!<Retry parameter details */
} x_IFX_SIP_RetryAfter;

/*! \struct x_IFX_SIP_Require
    \brief A structure defining the require header field.
*/
typedef struct
{
    uchar8 ucNoOfOptTag;/*!< Number of option tags present*/
    char8 aszOptTag[IFX_SIP_MAX_OPT_TAG][IFX_SIP_MAX_TOKEN];/*!< Details of the optional tags*/
} x_IFX_SIP_Require, x_IFX_SIP_ProxyReq;


/*! \typedef x_IFX_SIP_Require x_IFX_SIP_Supported
    \brief A structure defining the header supported by proxy .
*/
typedef x_IFX_SIP_Require x_IFX_SIP_Supported;

/*! \typedef x_IFX_SIP_Require x_IFX_SIP_UnSupported
    \brief A structure defining the header not supported by proxy.
*/
typedef x_IFX_SIP_Require x_IFX_SIP_UnSupported;

/*! \struct x_IFX_SIP_ReplyTo
    \brief A structure defining the reply to header field.
*/
typedef struct
{
    x_IFX_SIP_AddressType xAddrType;/*!< The URI being referred*/
    uchar8 ucNoOfRplyToParam;/*!< Number of parameters present*/
    x_IFX_SIP_RplyToParam axRplyToParam[IFX_SIP_MAX_RPLYTOPARAM];/*!< Description of each of the parameters*/
} x_IFX_SIP_ReplyTo;

/*! \struct x_IFX_SIP_RecordRoute
    \brief A structure defining record route header field.
*/
typedef struct
{
    uchar8 ucNoOfRecRoute;/*!< Number of record route headers present*/
    x_IFX_SIP_RecRoute* apxRecRoute[IFX_SIP_MAX_REC_ROUTE];/*!< Proxy address details*/
} x_IFX_SIP_RecordRoute;

/*! \typedef x_IFX_SIP_Credentials x_IFX_SIP_ProxyAuthr
    \brief A structure defining proxy authentication.
*/
typedef x_IFX_SIP_Credentials x_IFX_SIP_ProxyAuthr;

/*! \struct x_IFX_SIP_ChallengeParam
    \brief A structure defining the challange parameters.
*/
typedef struct
{
    e_IFX_SIP_ChalType eChalType;/*!< Challenge type*/
/*! \union uxChalType
    \brief An union containing possible challenge types.
*/
    union
    {
        x_IFX_SIP_DigestChal xDigestChal;/*!< Digest authentication*/
        x_IFX_SIP_OtherChal xOtherChal;/*!< Any other authentication scheme other than digest*/
    }uxChalType;
} x_IFX_SIP_ChallengeParam;

/*! \struct x_IFX_SIP_Challenge
    \brief A structure defining  authentication challenge.
*/
typedef struct
{
    uchar8 ucNoOfChal;/*!<Number of challenge parameters */
    x_IFX_SIP_ChallengeParam* apxChalParam[IFX_SIP_MAX_CHAL];/*!< Challenge parameter description*/
}x_IFX_SIP_Challenge;


/*! \typedef x_IFX_SIP_Challenge x_IFX_SIP_WWWAuthen
    \brief A structure defining  WWW authentication header.
*/
typedef x_IFX_SIP_Challenge x_IFX_SIP_WWWAuthen;


/*! \struct x_IFX_SIP_Priority
    \brief A structure defining the priority header fields.
*/
typedef struct
{
    e_IFX_SIP_PriValue ePriValue;/*!< Represents the standard priority values*/
    char szOtherPri[IFX_SIP_MAX_TOKEN];/*!< Priority description when non-standard value is being used*/
} x_IFX_SIP_Priority;


/*! \struct x_IFX_SIP_InReplyTo
    \brief A structure defining in reply to header fields.
*/
typedef struct
{
    uchar8 ucNoOfCallId;/* should be atleast 1 *//*!< Number of Call IDs being referenced*/
    char8 aszCallId[IFX_SIP_MAX_CALL_ID][IFX_SIP_MAX_WORD_SIZE];/*!< Call ID being referenced*/
} x_IFX_SIP_InReplyTo;


/*! \struct x_IFX_SIP_ErrorInfo
    \brief A structure defining the error info header field.
*/
typedef struct
{
    uchar8 ucNoOfErrorUri;/*!< Number of error URI�s present*/
    x_IFX_SIP_ErrorUri axErrorUri[IFX_SIP_MAX_ERROR_URI];/*!< List of error URIs*/
} x_IFX_SIP_ErrorInfo;

/*! \struct x_IFX_SIP_Date
    \brief A structure defining date header field.
*/
typedef struct
{
    char8 szwkday[IFX_SIP_MAX_WKDAY];/*!< Day of the week*/
/*! \struct xDate1
    \brief A structure defining date .
*/
    struct
    {
        uchar8 ucDay;/*!< Day of the month*/
        char8 szMonth[IFX_SIP_MAX_MONTH];/*!< Month*/
        int16 iYear;/*!< Year*/
    }xDate1;  /* day month year */
/*! \struct xTime
    \brief A structure defining time.
*/
    struct
    {
        uchar8 ucDigit1;/*!< Hours*/
        uchar8 ucDigit2;/*!< Minutes*/
        uchar8 ucDigit3;/*!< Seconds*/
    } xTime; /* 00:00:00 - 23:59:59 */
} x_IFX_SIP_Date;

/*! \struct x_IFX_SIP_MediaType
    \brief A structure defining the media parameters.
*/
typedef struct
{
    x_IFX_SIP_MType xMType;/*!<Media type */
    char8 szMSubType[IFX_SIP_MAX_TOKEN];/*!< Media subtype*/
    uchar8 ucNoOfMParam;/*!< Number of media parameters*/
    x_IFX_SIP_MParam axMParam[IFX_SIP_MAX_MPARAM];/*!< Media parameter information*/
} x_IFX_SIP_MediaType;


/*! \typedef x_IFX_SIP_MediaType x_IFX_SIP_ContType
    \brief A structure defining the content type.
*/
typedef x_IFX_SIP_MediaType x_IFX_SIP_ContType;

/*! \struct x_IFX_SIP_ContLang
    \brief A structure defining the language of message body.
*/
typedef struct
{
    uchar8 ucNoOfLangTag;/*!< Number of languages specified*/
    char8 aszLangTag[IFX_SIP_MAX_LANG_TAG][IFX_SIP_MAX_TOKEN];/*!< Language description*/
} x_IFX_SIP_ContLang;


/*! \struct x_IFX_SIP_ContEnc
    \brief A structure defining the Content-encoding header field.
*/
typedef struct
{
    uchar8 ucNoOfContCoding;/*!< Number of content codings being specified*/
    char8 aszContCoding[IFX_SIP_MAX_ENCODING][IFX_SIP_MAX_TOKEN];/*!< Content-coding information*/
} x_IFX_SIP_ContEnc;


/*! \struct x_IFX_SIP_ContDisp
    \brief A structure defining the Content-disposition header field.
*/
typedef struct
{
    x_IFX_SIP_DispType xDispType;/*!< Disposition type*/
    uchar8 ucNoOfDispParams;/*!< Number of disposition parameters*/
    x_IFX_SIP_DispParam axDispParam[IFX_SIP_MAX_DISP_PARAM];/*!< Disposition parameters*/
} x_IFX_SIP_ContDisp;

/*! \struct x_IFX_SIP_Contact
    \brief A structure defining the contact parameter list.
*/
typedef struct
{
    uchar8 ucNoOfContactParam;/*!< Number of contact addresses given*/
    x_IFX_SIP_ContactParam axContactParam[IFX_SIP_MAX_CONTACT_PARAM];/*!< Contact details*/
} x_IFX_SIP_Contact;

/*! \struct x_IFX_SIP_CallInfo
    \brief A structure defining the Call information header field.
*/
typedef struct
{
    uchar8 ucNoOfInfo;/*!<Number of information fields */
    x_IFX_SIP_Info axInfo[IFX_SIP_MAX_INFO];/*!< Actual information fields*/
} x_IFX_SIP_CallInfo;


/*! \typedef x_IFX_SIP_Credentials x_IFX_SIP_Authorizn
    \brief A structure defining the authorization.
*/
typedef x_IFX_SIP_Credentials x_IFX_SIP_Authorizn;

/*! \struct x_IFX_SIP_AuthenInfo
    \brief A structure defining the Authentication-Info header field.
*/
typedef struct
{
    uchar8 ucNoOfAInfo;/*!< Number of authentication information parameters*/
    x_IFX_SIP_AInfo axAInfo[IFX_SIP_MAX_AINFO];/*!< Authentication Information parameter values*/
} x_IFX_SIP_AuthenInfo;


/*! \struct x_IFX_SIP_Allow
    \brief A structure defining the Allow header field.
*/
typedef struct
{
    uchar8 ucNoOfMethod;/* should be atleast 1 *//*!< Number of Methods*/
    x_IFX_SIP_Method axMethod[IFX_SIP_MAX_METHOD];/*!< Method details*/
} x_IFX_SIP_Allow;

/*! \struct x_IFX_SIP_AlertInfo
    \brief A structure defining the Alert-Info header field.
*/
typedef struct
{
    uchar8 ucNoOfAlertParam;/* should be atleast 1 *//*!< Number of alert parameters*/
    x_IFX_SIP_AlertParam axAlertParam[IFX_SIP_MAX_ALERT_PARAM];/*!< Alert parameter Information*/
} x_IFX_SIP_AlertInfo;


/*! \struct x_IFX_SIP_AcceptLang
    \brief A structure defining the Accept-Language header field.
*/
typedef struct
{
    uchar8 ucNoOfLanguage;/* should be atleast 1 *//*!< Number of languages*/
    x_IFX_SIP_Language axLanguage[IFX_SIP_MAX_LANGUAGE];/*!< Language information*/
} x_IFX_SIP_AcceptLang;



/*! \struct x_IFX_SIP_AcceptEnc
    \brief A structure defining the sAccept-Encoding header field.
*/
typedef struct
{
    uchar8 ucNoOfEncs;/*!<Number of encodings present */
    x_IFX_SIP_Encoding axEncoding[IFX_SIP_MAX_ENCODING];/*!<Encoding format information */
} x_IFX_SIP_AcceptEnc;

/*! \struct x_IFX_SIP_Accept
    \brief A structure defining the Accept header field.
*/
typedef struct
{
    uchar8 ucNoOfAcceptRange;/*!< Number of accept range parameters*/
    x_IFX_SIP_AcceptRange axAcceptRange[IFX_SIP_MAX_ACCEPT_RANGE];/*!< Accept range Parameters*/
} x_IFX_SIP_Accept;

/*! \struct x_IFX_SIP_ViaParm
    \brief A structure defining the parameters that are present in the Via header.
*/
typedef struct
{
    x_IFX_SIP_SentProto xSentProto;/*!< sent protocol*/
    x_IFX_SIP_SentBy xSentBy;/*!< sent by field*/
    uchar8 ucNoOfViaParams;/*!< Number of via parameters*/
    x_IFX_SIP_ViaParams axViaParams[IFX_SIP_MAX_VIA_PARAMS];/*!< list of via parameters*/
} x_IFX_SIP_ViaParm;



/*! \struct x_IFX_SIP_FromParam
    \brief A structure defining the from parameter.
*/
typedef struct
{
    e_IFX_SIP_ParamType eParamType;/*!< Type indicator*/
/*! \union uxParamType
    \brief An union containing the possible parameters.
*/
    union
    {
        char8 szTagParam[IFX_SIP_MAX_TOKEN];/*!< Tag parameter*/
        x_IFX_SIP_GenericParam xGenericParam;/*!<user defined or extension parameters */
    }uxParamType;
} x_IFX_SIP_FromParam;

/*! \struct x_IFX_SIP_Via
    \brief A structure defining the Via header field.
*/
typedef struct
{
    uchar8 ucNoOfViaParm;/*!< Number of via parameters present*/
    x_IFX_SIP_ViaParm axViaParm[IFX_SIP_MAX_VIA_PARM];/*!< Via Information*/
} x_IFX_SIP_Via;

/*! \struct x_IFX_SIP_CSeq
    \brief A structure defining the CSeq header field.
*/
typedef struct
{
    int32 iCseqVal;/*!< Sequence number*/
    x_IFX_SIP_Method xMethod;/*!< Method name*/
} x_IFX_SIP_CSeq;


/*! \struct x_IFX_SIP_From
    \brief A structure defining the From header field.
*/
typedef struct
{
    x_IFX_SIP_AddressType xAddrType;/*!<Address type */

    uchar8 ucNoOfParam;/* Change to ucNoOfParam *//*!<Number of from parameters that are present */
    x_IFX_SIP_FromParam axParam[IFX_SIP_MAX_FROM_PARAM];/* Change to xParam *//*!< Various from and to parameters.*/
} x_IFX_SIP_From;

/*! \typedef x_IFX_SIP_From x_IFX_SIP_To
    \brief A structure defining the To header field.
*/
typedef x_IFX_SIP_From x_IFX_SIP_To;

/* Added for RFC 3515 */    
/*! \typedef x_IFX_SIP_ReplyTo x_IFX_SIP_ReferTo
    \brief A structure defining the refer-to header field.
*/
typedef x_IFX_SIP_ReplyTo x_IFX_SIP_ReferTo;
/*! \typedef x_IFX_SIP_ReplyTo x_IFX_SIP_ReferBy
    \brief A structure defining the refer-by header field.
*/
typedef x_IFX_SIP_ReplyTo x_IFX_SIP_ReferBy;

/* Added for RFC 3265 */    
/*! \struct x_IFX_SIP_EventParam
    \brief A structure defining the Event parameter.
*/
typedef struct
{
    e_IFX_SIP_EventParamType eEventParamType;/*!< Event parameter type*/
/*! \union uxEventParamType
    \brief A union containing possible Event parameters.
*/
    union
    {
        x_IFX_SIP_GenericParam xGenericParam;/*!< Non-standard, User defined parameters*/
        char8 cID[IFX_SIP_MAX_TOKEN];/*!< Event ID*/
    }uxEventParamType;
}x_IFX_SIP_EventParam;

/*! \struct x_IFX_SIP_EventTypes
    \brief A structure defining the description of event types.
*/
typedef struct
{
    char8 acEventPackage[IFX_SIP_MAX_TOKEN_NODOT];/*!< Event package*/
    int32 iNumEventTemplate;/*!< Number of event templates*/
    char8 acEventTemplate[IFX_SIP_MAX_EVNTTEMPLATE][IFX_SIP_MAX_TOKEN_NODOT];/*!< Event template description*/
}x_IFX_SIP_EventTypes;


/*! \struct x_IFX_SIP_SubStateVal
    \brief A structure defining the subscription state header.
*/
typedef struct
{
    e_IFX_SIP_SUBSTATE eSubState;/*!< Subsription state*/
    char8 cSubStateExtn[IFX_SIP_MAX_SUBSTATE];/*!< contain the details of extension type*/
}x_IFX_SIP_SubStateVal;

/*! \struct x_IFX_SIP_EvntRsn
    \brief A structure defining the Subexp parameters.
*/
typedef struct
{
    e_IFX_SIP_EVNTRSN eEvntRsn;/*!< enumeration of event reason values*/
    char8 cEventReasonExtn[IFX_SIP_MAX_EVNTRSNEXTN];/*!< Details of contents if extension type*/
}x_IFX_SIP_EvntRsn;

/*! \struct x_IFX_SIP_SubExpParams
    \brief A structure defining the Subscription parameters.
*/
typedef struct
{
    e_IFX_SIP_SubExpParams eSubExpParams;/*!< Type of the parameter being represented*/
/*! \union ux_SubParams
    \brief An union containing possible subexp params.
*/
    union
    {
        x_IFX_SIP_EvntRsn xEvntRsn;/*!< Event reason*/
        int32 iexpires;/*!< Expires*/
        int32 iRetryAfter;/*!< Retry-After*/
        x_IFX_SIP_GenericParam xGenParamas;/*!< Other non-standard parameters*/
    }ux_SubParams;
}x_IFX_SIP_SubExpParams;

/*! \struct x_IFX_SIP_SubState
    \brief A structure defining the subscription state header.
*/
typedef struct
{
    x_IFX_SIP_SubStateVal xSubStateVal;/*!<Subscription state value */
    int32 iNumSubExp;/*!< Number of subscription parameters*/
    x_IFX_SIP_SubExpParams axSubExpParams[IFX_SIP_MAX_SUBEXPPARAMS];/*!< Details of subexp parameters*/
}x_IFX_SIP_SubState;

/*! \struct x_IFX_SIP_AllowEvents
    \brief A structure defining the Allow-Events header.
*/
typedef struct
{
    int32 iNumEventTypes;/*!< Number of event types*/
    x_IFX_SIP_EventTypes xSIPEvent[IFX_SIP_MAX_ALLOW_EVENTS];/*!<Event description */
}x_IFX_SIP_AllowEvents;



/*! \struct x_IFX_SIP_EventHdr
    \brief A structure defining the event package handler.
*/
typedef struct
{
    x_IFX_SIP_EventTypes xEventTypes;/*!< Event type*/
    int32 iNumEventParam;/*!< Number of event parameters*/
    x_IFX_SIP_EventParam axEventParam[IFX_SIP_MAX_EVENT_PARAM];/*!< Description of event parameters*/
}x_IFX_SIP_EventHdr;

/* Added for draft-ietf-sip-replaces-02.txt */

/*! \struct x_IFX_SIP_ReplaceParams
    \brief A structure defining the tag parameters in the replaces header.
*/
typedef struct
{
    e_IFX_SIP_RepParamType eParamType;/*!< Type of the replaces parameter*/
/*! \union uxRepParamType
    \brief An union containing the possible parameters.
*/
    union
    {
        char8 szTagParam[IFX_SIP_MAX_TOKEN];/*!< To-Tag or a from-tag information*/
        x_IFX_SIP_GenericParam xGenericParam;/*!< non-standard values*/
    }uxRepParamType;
}x_IFX_SIP_ReplaceParams;

/*! \struct x_IFX_SIP_Replaces
    \brief A structure defining the replace dialog header .
*/
typedef struct
{
    char8 szCallId[IFX_SIP_MAX_WORD_SIZE];/*!< Call ID*/
    int32 iNumReplaceParams;/*!< Number of replaces parameters*/
    x_IFX_SIP_ReplaceParams axReplaceParams[IFX_SIP_MAX_REPLACE_PARAMS];/*!< Replaces parameters*/
}x_IFX_SIP_Replaces;

/* Added for draft-levy-sip-diversion-08.txt */
/*! \def IFX_SIP_MAX_DIV_PARAMS
    \brief A macro defining maximum diversion parameters.
*/
#define IFX_SIP_MAX_DIV_PARAMS 5


/*! \enum e_IFX_SIP_DivType
    \brief An Enumeration defining the diversion Type.
*/
typedef enum{
  IFX_SIP_DIV_REASON,/*!< diversion reason*/
  IFX_SIP_DIV_COUNTER,/*!< diversion counter*/
  IFX_SIP_DIV_LIMIT,/*!< diversion limit*/
  IFX_SIP_DIV_PRIVACY,/*!< diversion privacy*/
  IFX_SIP_DIV_SCREEN,/*!< diversion screen*/
  IFX_SIP_DIV_EXTN,/*!< diversion extension*/
}e_IFX_SIP_DivType;
/*! \enum e_IFX_SIP_DivReason
    \brief An Enumeration defining the resion for diversion.
*/
typedef enum{
  IFX_SIP_DIV_UNKNOWN,/*!< unknown*/
  IFX_SIP_DIV_USERBUSY,/*!< user busy*/
  IFX_SIP_DIV_NOANS,/*!< no ans*/
  IFX_SIP_DIV_UNAVAILABLE,/*!< unavailable*/
  IFX_SIP_DIV_UNCONDITIONAL,/*!< unconditional*/
  IFX_SIP_DIV_TIMEOFDAY,/*!< time of day*/
  IFX_SIP_DIV_DND,/*!< do not disturb*/
  IFX_SIP_DIV_DEFLECTION,/*!< deflection*/
  IFX_SIP_DIV_FOLLOWME,/*!< follow me*/
  IFX_SIP_DIV_OUTOFSERVICE,/*!< out of service*/
  IFX_SIP_DIV_AWAY,/*!< away*/
  IFX_SIP_DIV_TOKEN,/*!< token*/
  IFX_SIP_DIV_QUOTEDSTR,/*!< any quoted string*/
}e_IFX_SIP_DivReason;
/*! \enum e_IFX_SIP_DivPriv
    \brief An Enumeration defining the diversion private type.
*/
typedef enum{
  IFX_SIP_DIV_FULL,/*!< full*/
  IFX_SIP_DIV_NAME,/*!< name*/
  IFX_SIP_DIV_URI,/*!< uri*/
  IFX_SIP_DIV_OFF,/*!< off*/
  IFX_SIP_DIV_PRIVTOKEN,/*!< private token*/
  IFX_SIP_DIV_PRIVQUOTEDSTR,/*!< private quoted string*/
}e_IFX_SIP_DivPriv;
/*! \enum e_IFX_SIP_DivScreen
    \brief An Enumeration defining diversion screen type.
*/
typedef enum{
  IFX_SIP_DIV_YES,/*!< Yes*/
  IFX_SIP_DIV_NO,/*!< No*/
  IFX_SIP_DIV_SCRNTOKEN,/*!< Screen token*/
  IFX_SIP_DIV_SCRNQUOTEDSTR,/*!< Screen quoted string*/
}e_IFX_SIP_DivScreen;

/*! \struct x_IFX_SIP_DivReason
    \brief A structure defining the reason of diversion.
*/
typedef struct{
  e_IFX_SIP_DivReason eDivRsn;/*!< Reason type*/
  char8 szDivRsn[IFX_SIP_MAX_TOKEN];  /*!< reason*/
}x_IFX_SIP_DivReason;

/*! \struct x_IFX_SIP_DivPrivacy
    \brief A structure defining the diversion priv.
*/
typedef struct{
  e_IFX_SIP_DivPriv eDivPriv;/*!< priv type*/
  char8 szDivPriv[IFX_SIP_MAX_TOKEN];  /*!< div priv value*/
}x_IFX_SIP_DivPrivacy;

/*! \struct x_IFX_SIP_DivScreen
    \brief A structure defining the diversion screen.
*/
typedef struct{
  e_IFX_SIP_DivScreen eDivScreen;/*!< screen type*/
  char8 szDivScreen[IFX_SIP_MAX_TOKEN];  /*!< div screen value*/
}x_IFX_SIP_DivScreen;

/*! \struct x_IFX_SIP_DivExtn
    \brief A structure defining the extension of diversion.
*/
typedef struct{
  char8 szDivExtnName[IFX_SIP_MAX_TOKEN];  /*!<Extention name */
  char8 szDivExtnValue[IFX_SIP_MAX_TOKEN];  /*!< Extension value*/
}x_IFX_SIP_DivExtn;

/*! \struct x_IFX_SIP_DivParam
    \brief A structure defining the parameters of diversion header.
*/
typedef struct{
 e_IFX_SIP_DivType eDivType;/*!< type of diversion*/
/*! \union x_IFX_SIP_DivParam
    \brief An union defining the types of diversion.
*/
  union{
    x_IFX_SIP_DivReason xDivReason;/*!< Reason*/
    x_IFX_SIP_DivPrivacy xDivPrivacy;/*!< Privacy*/
    x_IFX_SIP_DivScreen xDivScreen;/*!< Screen*/
    x_IFX_SIP_DivExtn xDivExtn;/*!< Extension*/
    int32 iDivCount;/*!< Count*/
    int32 iDivLimit;    /*!< Limit*/
  }uxDivType;
}x_IFX_SIP_DivParam;

/*! \struct x_IFX_SIP_DivParams
    \brief A structure defining the diversion parameters.
*/
typedef struct{
  int32 iNumDivParams;/*!< Number of diversion parameters*/
  x_IFX_SIP_DivParam axDivParam[IFX_SIP_MAX_DIV_PARAMS];/*!< Diversion parameters*/
}x_IFX_SIP_DivParams;

/*! \struct x_IFX_SIP_Diversion
    \brief A structure defining the diversion.
*/
typedef struct{
  x_IFX_SIP_NameAddr xNameAddr;/*!< Name Address*/
  x_IFX_SIP_DivParams xDivParams;   /*!< Diversion parameters*/
}x_IFX_SIP_Diversion;

/*
typedef struct
{
e_IFX_SIP_TypeOfHdr  eTypeOfHdr;
ux_IFX_SIP_MsgHdr    uxMsgHdr;
} x_IFX_SIP_OtherHdrs;*/

/*! \struct x_IFX_SIP_GenHdr
    \brief A structure defining all the mandatory SIP headers.
*/

#ifdef RFC_3262 /*PRACK*/
typedef struct
{  

   int32 iResponseVal;
   int32 iCSeqVal;
   x_IFX_SIP_Method xMethod;
}x_IFX_SIP_RACK;

typedef struct
{
   int32 iResponseVal;
}x_IFX_SIP_RSeq;
#endif /*RFC_3262 */


#ifdef RFC_4028
typedef struct
{
   e_IFX_SIP_RefresherType eRefresher;
   char8 szOtherRefresher[IFX_SIP_MAX_TOKEN];
}x_IFX_SIP_RefresherParam;
typedef enum
{
        IFX_SIP_SE_REFRESHER_PARAM =1,
    IFX_SIP_SE_GENERIC_PARAM
}e_IFX_SE_ParamType;
typedef struct
{
        e_IFX_SE_ParamType eSEParamType;
        union
        {
                x_IFX_SIP_GenericParam xGenericParam;
                x_IFX_SIP_RefresherParam xRefresherParam;
        }uxSEParam;
}x_IFX_SE_Param;
typedef struct
{
   int32 iDeltaSeconds;
   int32 iNoOfSEParams;
   x_IFX_SE_Param xSEParams[IFX_SIP_MAX_GEN_PARAM];
}x_IFX_SIP_SessionExpiresParam;
typedef struct
{
   int32 iDeltaSeconds;
   int32 iNoOfGenericParams;
   x_IFX_SIP_GenericParam axGenericParam[IFX_SIP_MAX_GEN_PARAM];
}x_IFX_SIP_MIN_SE_Param;
#endif /* RFC_4028 */

#ifdef RFC_3325
/* For both RFC 3325 and 3327*/
typedef struct
{
    char8 privValue[IFX_SIP_MAX_TOKEN];
}x_IFX_SIP_PrivacyValue;

typedef struct 
{
#define 	IFX_SIP_PRIV_HEADER		0x00000001
#define		IFX_SIP_PRIV_SESSION		0x00000002
#define 	IFX_SIP_PRIV_USER			0x00000004
#define 	IFX_SIP_PRIV_NONE	  		0x00000008
#define		IFX_SIP_PRIV_CRITICAL		0x00000010
#define		IFX_SIP_PRIV_ID      		0x00000020
#define 	IFX_SIP_PRIV_TOKEN  		0x00000040
    int32 ePrivValue;
    uchar8 ucNumOtherToken;
    x_IFX_SIP_PrivacyValue axOtherToken[IFX_SIP_MAX_PRIVACY_TOKENS];
}x_IFX_SIP_PrivacyHdr;

/* Added for RFC 3325. Common for PAssertedID and PPreferredID headers */
typedef struct
{
    x_IFX_SIP_AddressType xAddrType;
} x_IFX_SIP_IdentityParam;

typedef struct
{
    uchar8 ucNumIdentityValues;
    x_IFX_SIP_IdentityParam axIdentityValue[IFX_SIP_MAX_IDENTITY_PARAM];
}x_IFX_SIP_IdentityHdr;
#endif /*RFC_3325 */
#ifdef RFC_3327
typedef struct
{
    uchar8 ucNoOfPathParam;
    x_IFX_SIP_RouteParam* apxPathParam[IFX_SIP_MAX_PATH_PARAM];
}x_IFX_SIP_PathHdr;

/* Added for RFC 3329 */
typedef struct
{
#define	IFX_SIP_SECMECHPARAM_PREF			0x01
#define IFX_SIP_SECMECHPARAM_DIGEST_ALGO	0x02
#define IFX_SIP_SECMECHPARAM_DIGEST_QOP	0x04
#define	IFX_SIP_SECMECHPARAM_DIGEST_VER	0x08
#define	IFX_SIP_SECMECHPARAM_EXT			0x10
    uchar8 ucSecMechParamType;
    union {
       float32 preference; /* qvalue */
	   char8   digestAlgo[IFX_SIP_MAX_TOKEN]; /* digest-algorithm */
	   char8   digestQop[IFX_SIP_MAX_TOKEN]; /* digest-qop */
	   char8   digestVer[IFX_SIP_MAX_DIGEST_VERIFY]; /* digest-verify */
	   x_IFX_SIP_GenericParam xGenericParam;
    };
}x_IFX_SIP_SecMechParam;

typedef struct
{
    char8 secMechName[IFX_SIP_MAX_TOKEN];
    int32 iNumSecMechParam;
    x_IFX_SIP_SecMechParam axSecMechParam[IFX_SIP_MAX_SECURITY_MECH_PARAM];
}x_IFX_SIP_SecurityMechanism;

typedef struct
{
    uchar8 ucNumSecurityMechanism;
    x_IFX_SIP_SecurityMechanism axSecurityMechanism[IFX_SIP_MAX_SECURITY_MECHANISM];
}x_IFX_SIP_SecurityHdr;
#endif /*RFC_3327*/

#ifdef RFC_3455
/*! \struct x_IFX_SIP_AiParam
    \brief A structure defining the ai-param.
*/
typedef struct
{
    x_IFX_SIP_GenericParam xGenericParam;
} x_IFX_SIP_AiParam;

/*! \struct x_IFX_SIP_Aso_Uri_Spec
    \brief A structure defining the P-Associated-URI header.
*/

typedef struct
{
    x_IFX_SIP_NameAddr xNameAddr;
    x_IFX_SIP_AiParam* pxAiParam;
} x_IFX_SIP_Aso_Uri_Spec;

/*! \struct x_IFX_SIP_CpidParam
    \brief A structure defining the cpid-param.
*/

typedef struct
{
    x_IFX_SIP_GenericParam xGenericParam;
} x_IFX_SIP_CpidParam;

/*! \struct x_IFX_SIP_Called_Pty_Id_Spec
    \brief A structure defining the P-Called-Party-ID header.
*/

typedef struct
{
    x_IFX_SIP_NameAddr xNameAddr;
    x_IFX_SIP_CpidParam* pxCpidParam;
}x_IFX_SIP_Called_Pty_Id_Spec;

/*! \struct x_IFX_SIP_VNetworkParam
    \brief A structure defining the vnetwork-param.
*/
typedef struct
{
    x_IFX_SIP_GenericParam xGenericParam;
} x_IFX_SIP_VNetworkParam;

/*! \struct x_IFX_SIP_VNetwork_Spec
    \brief A structure defining the P-Visited-Network-ID header.
*/
typedef struct
{
    char8 szValue[IFX_SIP_MAX_TOKEN];/*!< Value can be token or quoted string */
    x_IFX_SIP_VNetworkParam* pxVNetworkParam;
}x_IFX_SIP_VNetwork_Spec;

/*! \struct x_IFX_SIP_Access_Info
    \brief A structure defining the access-info.
*/

typedef struct
{
#define	IFX_SIP_ACCESSINFO_CGI_3GPP			0x01
#define IFX_SIP_ACCESSINFO_UTRAN_CELL_ID_3GPP		0x02
#define IFX_SIP_ACCESSINFO_EXT_ACCESS_INFO		0x04
    uchar8 ucAccessInfoParamType;
    union {
	   char8   acCgi3gpp[IFX_SIP_MAX_TOKEN]; /* cgi-3gpp */
	   char8   acUtranCellId3gpp[IFX_SIP_MAX_TOKEN]; /*utran-cell-id-3gpp */
	   char8   acExtAccessInfo[IFX_SIP_MAX_TOKEN]; /*extension-access-info*/
    };
}x_IFX_SIP_Access_Info;

/*! \struct x_IFX_SIP_Access_Net_Spec
    \brief A structure defining the P-Access-Network-Info header.
*/

typedef struct
{
    char8 szAccessType[IFX_SIP_MAX_TOKEN];
    x_IFX_SIP_Access_Info* pxAccessInfo;
}x_IFX_SIP_Access_Net_Spec;

/*! \struct x_IFX_SIP_Charge_Addr_Params
    \brief A structure defining the P-Charging-Function-Addresses header.
*/

typedef struct
{
#define	IFX_SIP_CHARGEADDRPARAMS_CCF				0x01
#define IFX_SIP_CHARGEADDRPARAMS_ECF				0x02
#define IFX_SIP_CHARGEADDRPARAMS_GEN				0x04
    uchar8 ucChargeAddrParams;
    union {
	   char8   acCcf[IFX_SIP_MAX_TOKEN]; /* ccf */
	   char8   acEcf[IFX_SIP_MAX_TOKEN]; /* ecf */
	   x_IFX_SIP_GenericParam xGenericParam;
    };
}x_IFX_SIP_Charge_Addr_Params;

/*! \struct x_IFX_SIP_Charge_Params
    \brief A structure defining the charge-params.
*/

typedef struct
{
#define	IFX_SIP_CHARGEPARAM_ICID_GENADDR		0x01
#define IFX_SIP_CHARGEPARAM_ORIG_IOI			0x02
#define IFX_SIP_CHARGEPARAM_TERM_IOI			0x04
#define	IFX_SIP_CHARGEPARAM_GENERIC_PARAM		0x08
    uchar8 ucChargeParams;
    union {
	   char8   szIcidGenAddr[IFX_SIP_MAX_TOKEN]; /* icid-gen-addr */
	   char8   szOrigIoi[IFX_SIP_MAX_TOKEN]; /* orig-ioi */
	   char8   szTermIoi[IFX_SIP_MAX_TOKEN]; /* term-ioi */
	   x_IFX_SIP_GenericParam xGenericParam;
    };
}x_IFX_SIP_Charge_Params;

/*! \struct x_IFX_SIP_Charging_Vector
    \brief A structure defining the P-Charging-Vector header.
*/

typedef struct
{
    char8 szIcidValue[IFX_SIP_MAX_TOKEN];
    x_IFX_SIP_Charge_Params* pxChargeParams;
}x_IFX_SIP_Charging_Vector;

#endif /*RFC_3455*/

typedef struct
{
/*! \def IFX_SIP_TOPRES
    \brief A macro defining a bit which indicate presence of To header.
*/
#define IFX_SIP_TOPRES     0x01
/*! \def IFX_SIP_FROMPRES
    \brief A macro defining a bit which indicate presence of To header.
*/
#define IFX_SIP_FROMPRES   0x02
/*! \def IFX_SIP_CSEQPRES
    \brief A macro defining a bit which indicate presence of From header.
*/
#define IFX_SIP_CSEQPRES   0x04
/*! \def IFX_SIP_CALLIDPRES
    \brief A macro defining a bit which indicate presence of CSeq header.
*/
#define IFX_SIP_CALLIDPRES 0x08
/*! \def IFX_SIP_VIAPRES
    \brief A macro defining a bit which indicate presence of CallId header.
*/
#define IFX_SIP_VIAPRES    0x10
/*! \def IFX_SIP_MAXFORPRES
    \brief A macro defining a bit which indicate presence of Max Forward header.
*/
#define IFX_SIP_MAXFORPRES 0x20
/*! \def IFX_SIP_CONTLEN
    \brief A macro defining a bit which indicate presence of Content Length .
*/
#define IFX_SIP_CONTLEN    0x40


    int8 cHdrPresence;/*!< Indicates the presence or absence of each of the headers.*/
    x_IFX_SIP_To xTo;/*!< To header*/
    x_IFX_SIP_From xFrom;/*!< From header*/
    x_IFX_SIP_CSeq xCSeq;/*!< CSeq header*/
    char8 szCallId[IFX_SIP_MAX_WORD_SIZE];/*!< Call ID header*/
    int16 iMaxForw;/*!<Max Forward header */
    x_IFX_SIP_Via xVia;/*!< Via header*/
    int32 iContLen;/*!< Length of the message body following the SIP headers.*/
} x_IFX_SIP_GenHdr;


/*
* ReasonPhrase should be filled according to the grammar
*
*/
/*! \struct x_IFX_SIP_StatusLine
    \brief A structure defining first line of sip messages.
*/
typedef struct
{
    ac_SIPVersion szSipVersion;/*!< Sip version string*/
    x_IFX_SIP_StatusCode xStatusCode;/*!< Status code*/
    char8 szReasonPhrase[IFX_SIP_MAX_TOKEN];/*!< Reason phrase*/
} x_IFX_SIP_StatusLine;

/*! \typedef x_IFX_SIP_StatusLine x_IFX_SIP_Response
    \brief A structure defining first line for all the response messages.
*/
typedef x_IFX_SIP_StatusLine x_IFX_SIP_Response;

/*! \struct x_IFX_SIP_MsgHdrsBody
    \brief A structure represents the header information..
*/
typedef struct
{
    /* There is a direct mapping between #defined and enum e_IFX_SIP_TypeOfHdr
      * so assure changes if any are in synch */
/*! \def IFX_SIP_CSACCEPT
    \brief Indicates the presence of Accept Header.
*/
#define IFX_SIP_CSACCEPT                   0x00000001
/*! \def IFX_SIP_CSACCEPT_ENCODING
    \brief Indicates the presence of Accept-Encoding Header.
*/
#define IFX_SIP_CSACCEPT_ENCODING          0x00000002
/*! \def IFX_SIP_CSACCEPT_LANGUAGE
    \brief Indicates the presence of Accept-Language Header.
*/
#define IFX_SIP_CSACCEPT_LANGUAGE          0x00000004
/*! \def IFX_SIP_CSALERT_INFO
    \brief Indicates the presence of Alert-Info Header.
*/
#define IFX_SIP_CSALERT_INFO               0x00000008
/*! \def IFX_SIP_CSALLOW
    \brief Indicates the presence of Allow Header.
*/
#define IFX_SIP_CSALLOW                    0x00000010
/*! \def IFX_SIP_CSAUTHENTICATION_INFO
    \brief Indicates the presence of Authentication-Info header.
*/
#define IFX_SIP_CSAUTHENTICATION_INFO      0x00000020
/*! \def IFX_SIP_CSAUTHORIZATION 
    \brief Indicates the presence of Authentication-Info header.
*/
#define IFX_SIP_CSAUTHORIZATION            0x00000040
/*! \def IFX_SIP_CSCALL_INFO
    \brief A macro defining presence of Call-Info header.
*/
#define IFX_SIP_CSCALL_INFO                0x00000080
/*! \def IFX_SIP_CSCONTACT
    \brief A macro defining presence of Contact header.
*/
#define IFX_SIP_CSCONTACT                  0x00000100
/*! \def IFX_SIP_CSCONTENT_DISPOSTION
    \brief A macro defining presence of Content-Disposition header.
*/
#define IFX_SIP_CSCONTENT_DISPOSTION       0x00000200
/*! \def IFX_SIP_CSCONTENT_CODING
    \brief A macro defining presence of  Content header.
*/
#define IFX_SIP_CSCONTENT_CODING           0x00000400
/*! \def IFX_SIP_CSCONTENT_LANGUAGE
    \brief A macro defining presence of  Content-Language header.
*/
#define IFX_SIP_CSCONTENT_LANGUAGE         0x00000800
/*! \def IFX_SIP_CSCONTENT_TYPE
    \brief A macro defining presence of  Content-Type header.
*/
#define IFX_SIP_CSCONTENT_TYPE             0x00001000
/*! \def IFX_SIP_CSDATE
    \brief A macro defining presence of  Date header.
*/
#define IFX_SIP_CSDATE                     0x00002000
/*! \def IFX_SIP_CSERROR_INFO
    \brief A macro defining presence of  Error-Info header.
*/
#define IFX_SIP_CSERROR_INFO               0x00004000       
/*! \def IFX_SIP_CSEXPIRES
    \brief A macro defining presence of  Expire header.
*/
#define IFX_SIP_CSEXPIRES                  0x00008000
/*! \def IFX_SIP_CSINREPLYTO
    \brief A macro defining presence of Reply-To header.
*/
#define IFX_SIP_CSINREPLYTO                0x00010000    
/*! \def IFX_SIP_CSMIME_VERSION
    \brief A macro defining presence of Version header.
*/
#define IFX_SIP_CSMIME_VERSION             0x00020000
/*! \def IFX_SIP_CSMIN_EXPIRES
    \brief A macro defining presence of  Minimum-Expire header.
*/
#define IFX_SIP_CSMIN_EXPIRES              0x00040000
/*! \def IFX_SIP_CSORGANIZATION
    \brief A macro defining presence of  Organization header.
*/
#define IFX_SIP_CSORGANIZATION             0x00080000
/*! \def IFX_SIP_CSPRIORITY
    \brief A macro defining presence of  Priority header.
*/
#define IFX_SIP_CSPRIORITY                 0x00100000
/*! \def IFX_SIP_CSPROXY_AUTHENTICATE
    \brief A macro defining presence of  Proxy-Authenticate header.
*/
#define IFX_SIP_CSPROXY_AUTHENTICATE       0x00200000
/*! \def IFX_SIP_CSPROXY_AUTHORIZATION
    \brief A macro defining presence of  Proxy-Authorization header.
*/
#define IFX_SIP_CSPROXY_AUTHORIZATION      0x00400000
/*! \def IFX_SIP_CSPROXY_REQUIRE
    \brief A macro defining presence of  Proxy-Require header.
*/
#define IFX_SIP_CSPROXY_REQUIRE            0x00800000
/*! \def IFX_SIP_CSRECORD_ROUTE
    \brief A macro defining presence of  Record-Route header.
*/
#define IFX_SIP_CSRECORD_ROUTE             0x01000000
/*! \def IFX_SIP_CSREPLY_TO
    \brief A macro defining presence of  Reply-To header.
*/
#define IFX_SIP_CSREPLY_TO                 0x02000000
/*! \def IFX_SIP_CSREQUIRE
    \brief A macro defining presence of  Require header.
*/
#define IFX_SIP_CSREQUIRE                  0x04000000
/*! \def IFX_SIP_CSRETRY_AFTER
    \brief A macro defining presence of  Retry-After header.
*/
#define IFX_SIP_CSRETRY_AFTER              0x08000000
/*! \def IFX_SIP_CSROUTE
    \brief A macro defining presence of  Route header.
*/
#define IFX_SIP_CSROUTE                    0x10000000
/*! \def IFX_SIP_CSSERVER
    \brief A macro defining presence of  Server header.
*/
#define IFX_SIP_CSSERVER                   0x20000000
/*! \def IFX_SIP_CSSUBJECT
    \brief A macro defining presence of  Subject header.
*/
#define IFX_SIP_CSSUBJECT                  0x40000000
/*! \def IFX_SIP_CSSUPPORTED
    \brief A macro defining presence of  Supported header.
*/
#define IFX_SIP_CSSUPPORTED                0x80000000


/*! \def IFX_SIP_CSTIMESTAMP
    \brief A macro defining presence of  Timestamp header.
*/
#define IFX_SIP_CSTIMESTAMP                0x00000001
/*! \def IFX_SIP_CSUNSUPPORTED
    \brief A macro defining presence of  Unsupported header.
*/
#define IFX_SIP_CSUNSUPPORTED              0x00000002
/*! \def IFX_SIP_CSUSER_AGENT
    \brief A macro defining presence of  User-Agent header.
*/
#define IFX_SIP_CSUSER_AGENT               0x00000004
/*! \def IFX_SIP_CSWARNING
    \brief A macro defining presence of  Warning header.
*/
#define IFX_SIP_CSWARNING                  0x00000008
/*! \def IFX_SIP_CSWWW_AUTHENTICATE
    \brief A macro defining presence of  WWW-Authentication header.
*/
#define IFX_SIP_CSWWW_AUTHENTICATE         0x00000010
    /* Added for RFC 3515 */
/*! \def IFX_SIP_CSREFER_TO
    \brief A macro defining presence of  Refer-To header.
*/
#define IFX_SIP_CSREFER_TO                 0x00000020
/*! \def IFX_SIP_CSREFER_BY
    \brief A macro defining presence of  Refer-By header.
*/
#define IFX_SIP_CSREFER_BY                 0x00000040
    /* Added for RFC 3265 */
/*! \def IFX_SIP_CSEVENT
    \brief A macro defining presence of  Event header.
*/
#define IFX_SIP_CSEVENT                    0x00000080
/*! \def IFX_SIP_CSALLOW_EVENTS
    \brief A macro defining presence of  Allow-Events header.
*/
#define IFX_SIP_CSALLOW_EVENTS             0x00000100
/*! \def IFX_SIP_CSSUBSCRIPTION_STATE
    \brief A macro defining presence of  Subscription-State header.
*/
#define IFX_SIP_CSSUBSCRIPTION_STATE       0x00000200  
    /* Added for draft-ietf-sip-replaces-02.txt */
/*! \def IFX_SIP_CSREPLACES
    \brief A macro defining presence of  Replace header.
*/
#define IFX_SIP_CSREPLACES                 0x00000400 
    /* Added for draft-levy-sip-diversion-08.txt */
/*! \def IFX_SIP_CSDIVERSION
    \brief A macro defining presence of  Diversion header.
*/
#define IFX_SIP_CSDIVERSION       			0x00000800 

#ifdef RFC_3262
/*! \def IFX_SIP_CSRACK
    \brief A macro defining presence of  RACK header.
*/
#define IFX_SIP_CSRACK                                  0x00001000
/*! \def IFX_SIP_CSRSEQ
    \brief A macro defining presence of  RSEQ header.
*/
#define IFX_SIP_CSRSEQ                                  0x00002000
#endif /*RFC_3262 */

#ifdef RFC_3325
#define IFX_SIP_CSPRIVACY				0x00004000
  /* Added for RFC 3325 */
#define IFX_SIP_CSPASSERTED_ID				0x00008000
#define IFX_SIP_CSPPREFERRED_ID				0x00010000
#endif /*RFC_3325 */

#ifdef RFC_3327
#define IFX_SIP_CSPATH					0x00020000
  /* Added for RFC 3329 */
#define IFX_SIP_CSSECURITY_CLIENT			0x00040000
#define IFX_SIP_CSSECURITY_SERVER			0x00080000
#define IFX_SIP_CSSECURITY_VERIFY			0x00100000
#endif /*RFC_3327 */

#ifdef RFC_3455
#define IFX_SIP_CSPASSOCIATED_URI			0x00200000
#define IFX_SIP_CSPCALLED_PARTY_ID			0x00400000
#define IFX_SIP_CSPVISITED_NETWORK_ID			0x00800000
#define IFX_SIP_CSPACCESS_NETWORK_INFO			0x01000000
#define IFX_SIP_CSPCHARGING_FUNCTION_ADDRESSES		0x02000000
#define IFX_SIP_CSPCHARGING_VECTOR			0x04000000
#endif /*RFC_3455 */
#ifdef RFC_4028
#define  IFX_SIP_CSSE					0x08000000
#define  IFX_SIP_CSMIN_SE				0x10000000
#endif /* RFC_4028 */
#ifdef RFC_3903
/*! \def IFX_SIP_CSETAG
    \brief A macro defining presence of  SIP-ETag header.
*/
#define IFX_SIP_CSETAG                                  0x20000000
/*! \def IFX_SIP_CSIFMATCH
    \brief A macro defining presence of  SIP-If-Match header.
*/
#define IFX_SIP_CSIFMATCH                               0x40000000
#endif /*RFC_3903 */

    /* This should be the last Header */ 
/*! \def IFX_SIP_CSEXTENSION_HEADER
    \brief A macro defining presence of  Extension header.
*/
#define IFX_SIP_CSEXTENSION_HEADER         0x80000000


    int32 iHeaderPresence1;/*!< Presence or absence of certain headers(First 32 bits).*/
    int32 iHeaderPresence2;/*!< Presence or absence of certain headers(After first 32 bits).*/
    x_IFX_SIP_GenHdr xGenHdr;/*!< All the mandatory/common headers*/
    uchar8 ucNoOfOtherHdrs;/*!< Number of optional headers*/
    void* apvdOtherHdr[IFX_SIP_MAX_OTHER_HDR];/*!< Location of optional headers*/
} x_IFX_SIP_MsgHdrsBody;

/*! \struct x_IFX_SIP_ReqLine
    \brief A structure defining the request line parameters.
*/
typedef struct
{
    x_IFX_SIP_Method xMethod;/*!< SIP method*/
    x_IFX_SIP_ReqURI xReqURI;/*!< SIP request URI*/
    ac_SIPVersion szSipVersion;/*!< SIP version*/
} x_IFX_SIP_ReqLine;

/*! \typedef x_IFX_SIP_ReqLine x_IFX_SIP_Request
    \brief A structure defining the SIP request .
*/
typedef x_IFX_SIP_ReqLine x_IFX_SIP_Request;


/*! \struct x_IFX_SIP_SipMessage 
    \brief A structure defining the SIP Message.
*/
typedef struct x_IFX_SIP_SipMessage
{
    int32 iUseCompactHdrs;/*!< Indicates if encoding is required using compact headers.*/
/*! \union uxReqResp 
    \brief An union defining containing request and response.
*/
    e_IFX_SIP_MsgType eMsgType;/*!< Indicates if the message is a request or a response.*/
    union
    {
        x_IFX_SIP_Request xRequest;/*!< Request line information*/
        x_IFX_SIP_Response xResponse;/*!< Status line information*/
    } uxReqResp;
    x_IFX_SIP_MsgHdrsBody xMsgHdrsBody;/*!< Headers pertaining to SIP message.*/
    e_IFX_SIP_SdpType eSdpType;/*!< Indicates the type of body present.*/
/*! \union uxSdpType 
    \brief An union defining message body types.
*/
    union
    {
        void* pxSdp;/*!< Pointer to SDP message body*/
        struct x_IFX_SIP_SipMessage* pxSIPMsg; /*!< Pointer to Sip message structure*/
        char8* pszSdpNonText; /* malloc with size indicated in the
                                 content header *//*!< Non text SDP information*/
        char8* pszMsgFrag;/*!< Message Fragmentation*/
        /* For Messaging */
        char8* pszPlainText;/*!< Plain Text*/
        char8* pszHookFlash;/*!< Hook Flash*/
    } uxSdpType;
}x_IFX_SIP_SipMessage;



#endif /* __IFX_SIP_HEADERS_H__ */


/* End of IFX_Sip_headers.h*/
