/**************************************************************************
**   FILE NAME     : IFX_SIP_Stack.h
**   PROJECT       : SIP
**   MODULES       : Transaction User
**   SRC VERSION   : V2.0 
**   DATE          : 15-12-2004 
**   AUTHOR        : SIP Team.
**   DESCRIPTION   : Function prototypes TU Client functions.
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines,IFX_SP_TUDIS.
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_SIP_Stack.h
    \brief This File contains the Stack Init and Configuration Functions, with
           few enums used within all SIP API's.
*/

#ifndef __IFX_SIP_STACK_H__
#define __IFX_SIP_STACK_H__

/*!\define IFX_SIP_DEFAULT_T1
   \brief Default value of T1
*/
#define IFX_SIP_DEFAULT_T1 500
/*!\define IFX_SIP_DEFAULT_PORT
   \brief Default SIP server port
*/
#define IFX_SIP_DEFAULT_PORT 5060
/*!\define IFX_SIP_DEFAULT_TLS_PORT
   \brief Default TLS port
*/
#define IFX_SIP_DEFAULT_TLS_PORT 5061

/*! \enum e_IFX_SIP_TransErrorCode
    \brief error codes returned by the Timeout or Error Callback.
*/
typedef enum
{
  IFX_SIP_DNS_ERR, /*!< Destination or Dns Address resolve failed */
  IFX_SIP_SERVER_ERR, /*!< Creating Server transaction Error */
  IFX_SIP_DECODE_ERR, /*!< Decode Error */
  IFX_SIP_TIMEOUT_ERR,/*!< Transaction Timeout Error */
  IFX_SIP_ERR_CLEANUP,/*!< Error at clean UP */
  IFX_SIP_2XXACK_TIMEOUT,/*!< 2xx Ack Timeout */
  IFX_SIP_SESSREFRESH_TIMEOUT,/*!< Session Refresh Timeout */
  IFX_SIP_TRANS_ERR,
  IFX_SIP_SUBSCRIBER_TIMEOUT,
  IFX_SIP_NOTIFIER_TIMEOUT,
} e_IFX_SIP_TransErrorCode;

/*! \enum e_IFX_SIP_Return
    \brief An Enumeration defining Return type of all stack API's
*/
typedef enum{
  IFX_SIP_FAILURE = -1, /*!< On Failure */
  IFX_SIP_SUCCESS /*!< On Success */
} e_IFX_SIP_Return;

/*! \enum e_IFX_SIP_IpType
    \brief An Enumeration defining IP Address Type
*/
typedef enum{
  IFX_SIP_TR_IPV4,/*!< IP V4 Address*/
  IFX_SIP_TR_IPV6,/*!< IP V6 Address*/
  IFX_SIP_TR_MADDR /*!< Mac Address*/
} e_IFX_SIP_IpType;


/*! \enum e_IFX_SIP_Protocol
    \brief An Enumeration defining the Transport Protocol

    Used in API's to set next Hop address
*/
typedef enum{
  IFX_SIP_PROTO_UDP = 1,/*!< UDP Transport Protocol */
  IFX_SIP_PROTO_TCP,/*!< TCP Transport Protocol */
  IFX_SIP_PROTO_TLS/*!< TLS Transport Protocol */
} e_IFX_SIP_Protocol;

/*! \enum e_IFX_SIP_BasicMethod
    \brief An Enumeration defining the Basic methods.
*/
typedef enum{
  IFX_SIP_INVITE = 1,/*!< INVITE method */
  IFX_SIP_ACK,/*!< ACK method */
  IFX_SIP_BYE,/*!< BYE method */
  IFX_SIP_CANCEL,/*!< CANCEL method */
#ifdef RFC_3262
  IFX_SIP_PRACK,/*!< PRACK method */
#endif /* RFC_3262 */
#ifdef RFC_3311
  IFX_SIP_UPDATE,/*!< UPDATE  method */
#endif
  IFX_SIP_INFO_METHOD,/*!< INFO method */
  IFX_SIP_OPTIONS,/*!< OPTIONS method */
  IFX_SIP_REFER,/*!< REFER method */
  IFX_SIP_SUBSCRIBE,/*!< SUBSCRIBE method */
  IFX_SIP_NOTIFY,/*!< NOTIFY method */
  IFX_SIP_MESSAGE_METHOD,/*!< MESSAGE method */
#ifdef RFC_3903
  IFX_SIP_PUBLISH,/*!< PUBLISH method */
#endif
  IFX_SIP_REGISTER,/*!< REGISTER method */
#if 0
  IFX_SIP_PRACK,/*!< PRACK method */
  IFX_SIP_PUBLISH,/*!< PUBLISH method */
  IFX_SIP_UPDATE,/*!< UPDATE method */
#endif
  IFX_SIP_EXT_METHOD/*!< Extension method */
}e_IFX_SIP_BasicMethod;

/*! \enum e_IFX_SIP_Boolean
    \brief An Enumeration defining Boolean.
*/
typedef enum{
  IFX_SIP_FALSE,/*!< False */
  IFX_SIP_TRUE/*!< True */
} e_IFX_SIP_Boolean;


/*! \enum e_IFX_SIP_StatusType
    \brief An Enumeration defining the status types of SIP responses.
*/
typedef enum{
  IFX_SIP_INFORMATIONAL = 1,/*!< Provisional response status code between 100 and 199 */
  IFX_SIP_STATUSSUCCESS,/*!< Success response, 2xx class status code */
  IFX_SIP_REDIRECTION,/*!< Redirection, Status code between 300 and 399 */
  IFX_SIP_CLIENT_ERROR,/*!< Client eror, 400 class response */
  IFX_SIP_SERVER_ERROR,/*!< Server error, 500 class response */
  IFX_SIP_GLOBAL_FAILURE,/*!< Global failure, 600 class response */
  IFX_SIP_EXTENSION_CODE/*!< Other extensions */
} e_IFX_SIP_StatusType;

/*! \enum e_IFX_SIP_MsgType
    \brief An Enumeration defining the Message type.
*/
typedef enum{
  IFX_SIP_REQUEST = 1,/*!< Message body is Request */
  IFX_SIP_RESPONSE/*!< Message body is Response */
} e_IFX_SIP_MsgType;

#ifdef RFC_4028
/*! \enum e_IFX_SIP_RefresherType
    \brief An Enumeration defining the Refresher types.
*/
typedef enum
{
   IFX_SIP_UAC = 1,/*!< UAC */
   IFX_SIP_UAS,/*!< UAS */
   IFX_SIP_OTHER_REFRESHER/*!< OTHERS */
}e_IFX_SIP_RefresherType;
#endif /*RFC_4028*/


/*! \enum e_IFX_SIP_SipUriType
    \brief An Enumeration defining the SIP URI types.
*/
typedef enum{
  IFX_SIP_ABSOLUTE_SIP_URI = 1,/*!< URI type is absolute URI */
  IFX_SIP_ABS_PATH/*!< URI is an absolute path */
} e_IFX_SIP_SipUriType;

/*! \enum e_IFX_SIP_UriType
    \brief An Enumeration defining the User types.
*/
typedef enum{
  IFX_SIP_SIP_URI = 1,/*!< SIP URI */
  IFX_SIP_SIPS_URI,/*!< SIPS URI */
  IFX_SIP_ABSOLUTE_URI/*!< Absolute URI */
} e_IFX_SIP_UriType;

/*! \enum e_IFX_SIP_TypeOfHdr
    \brief An Enumeration defining the User types.

    Note change in the order of the messages will lead to change in
    #defines at Msg Hdr structure. So, Pls, ensure that before changing
*/
typedef enum{
  IFX_SIP_ACCEPT = 0,/*!< Accpet Header */
  IFX_SIP_ACCEPT_ENCODING,/*!< Acceptt Encoding header */
  IFX_SIP_ACCEPT_LANGUAGE,/*!< Accept language header */
  IFX_SIP_ALERT_INFO,/*!< Alert Info header */
  IFX_SIP_ALLOW,/*!< Allow Header */
  IFX_SIP_AUTHENTICATION_INFO,/*!< Authentication Info header */
  IFX_SIP_AUTHORIZATION,/*!< Authorization header */
  IFX_SIP_CALL_INFO,/*!< Call-Info header */
  IFX_SIP_CONTACT,/*!< Contact header */
  IFX_SIP_CONTENT_DISPOSTION,/*!< Content-Disposition header */
  IFX_SIP_CONTENT_ENCODING = 10,/*!< Content-Encoding header */
  IFX_SIP_CONTENT_LANGUAGE,/*!< Content-Language header */
  IFX_SIP_CONTENT_TYPE,/*!< Content-Type header */
  IFX_SIP_DATE,/*!< Date header */
  IFX_SIP_ERRORINFO,/*!< Error-Info header */
  IFX_SIP_EXPIRES,/*!< Expires header */
  IFX_SIP_INREPLYTO,/*!< In-Reply-To header */
  IFX_SIP_MIME_VERSION,/*!< MIME-Version header */
  IFX_SIP_MIN_EXPIRES,/*!< Min-Exp header */
  IFX_SIP_ORGANIZATION,/*!< Organization header */
  IFX_SIP_PRIORITY = 20,/*!< Priority header */
  IFX_SIP_PROXY_AUTHENTICATE,/*!< Proxy-Authenticate Info header */
  IFX_SIP_PROXY_AUTHORIZATION,/*!< Proxy-Authorization header */
  IFX_SIP_PROXY_REQUIRE,/*!< Proxy-Require header */
  IFX_SIP_RECORD_ROUTE,/*!< Record-Route header */
  IFX_SIP_REPLY_TO,/*!< Reply-To header */
  IFX_SIP_REQUIRE,/*!< Require header */
  IFX_SIP_RETRY_AFTER,/*!< Retry-After header */
  IFX_SIP_ROUTE,/*!< Route header */
  IFX_SIP_SERVER,/*!< Server header */
  IFX_SIP_SUBJECT = 30,/*!< Subject header */
  IFX_SIP_SUPPORTED,/*!< Supported header */
  IFX_SIP_TIMESTAMP = 32,/*!< Timestamp header */
  IFX_SIP_UNSUPPORTED,/*!< Unsupported header */
  IFX_SIP_USER_AGENT,/*!< User Agent header */
  IFX_SIP_WARNING,/*!< Warning header */
  IFX_SIP_WWW_AUTHENTICATE,/*!< WWW-Authenticate header */
  /* RFC 3515 headers */
  IFX_SIP_REFER_TO,/*!< Refer-To header */
  IFX_SIP_REFER_BY,/*!< Refer-By header */
  /* RFC 3265 headers */
  IFX_SIP_EVENT,/*!< Event header */
  IFX_SIP_ALLOW_EVENTS,/*!< Allow-Events header */
  IFX_SIP_SUBSCRIPTION_STATE,/*!< Subscription-state header */
  /*Added for draft-ietf-sip-replaces-02.txt*/
  IFX_SIP_REPLACES,/*!< Replaces header */
  /*Added for draft-levy-sip-diversion-08.txt*/
  IFX_SIP_DIVERSION,/*!< Diversion header */
#ifdef RFC_3262
  /* Added for PRACK support, RFC 3262*/
  IFX_SIP_RACK,/*!< RAck Header*/
  IFX_SIP_RSEQ,/*!< RSeq Header*/
#endif /*RFC_3262 */
#ifdef RFC_4028
  IFX_SIP_SE,/*!< Session-Expires Header*/
  IFX_SIP_MIN_SE,/*!< Min-SE Header*/
#endif /* RFC_4028 */
#ifdef RFC_3325
  IFX_SIP_PRIVACY,/*!< Privacy Header*/
  /* Added for RFC 3325 */
  IFX_SIP_PASSERTED_ID,/*!< P-Assested-Identity Header*/
  IFX_SIP_PPREFERRED_ID,/*!< P-Preferred-Identity Header*/
#endif /* RFC_3325 */
#ifdef RFC_3327
  IFX_SIP_PATH,/*!< Path Header*/
  IFX_SIP_SECURITY_CLIENT,/*!< Security-Client Header*/
  IFX_SIP_SECURITY_SERVER,/*!< Security-Server Header*/
  IFX_SIP_SECURITY_VERIFY,/*!< Security-Verify Header*/
#endif /* RFC_3327 */
#ifdef RFC_3455
  IFX_SIP_PASSOCIATED_URI,/*!< P-Associated-URI Header*/
  IFX_SIP_PCALLED_PARTY_ID,/*!< P-Called-Party-ID Header*/
  IFX_SIP_PVISITED_NETWORK_ID,/*!< P-Visited-Network-ID Header*/
  IFX_SIP_PACCESS_NETWORK_INFO,/*!< P-Access-Network-Info Header*/
  IFX_SIP_PCHARGING_FUNCTION_ADDRESSES,/*!< P-Charging-Function-Addresses Header*/
  IFX_SIP_PCHARGING_VECTOR,/*!< P-Charging-Vector Header*/
#endif /*RFC_3455*/
#ifdef RFC_3903
  IFX_SIP_ETAG,/*!< SIP-ETag Header*/
  IFX_SIP_IFMATCH,/*!< SIP-If-Match Header*/
#endif /* RFC_3903 */
  IFX_SIP_EXTENSION_HEADER,/*!< Extension header */
  /* Mandatory Headers */
  IFX_SIP_CALL_ID,/*!< Call-Id header */
  IFX_SIP_CONTENT_LEN,/*!< Content-Lenght header */
  IFX_SIP_CSEQ,/*!< CSeq header */
  IFX_SIP_FROM,/*!< From header */
  IFX_SIP_MAX_FORWARDS,/*!< Max-Forward header */
  IFX_SIP_TO,/*!< To header */
  IFX_SIP_VIA,/*!< Via header */

}e_IFX_SIP_TypeOfHdr;

/*! \def IFX_SIP_CFG_DEBUG
    \brief Change in Debug Level's or Type
    The ucOptions in IFX_SIP_StackCfg need to be OR with these define
    to indicate the change in configuration
*/    
#define IFX_SIP_CFG_DEBUG      0x01

/*! \def IFX_SIP_CFG_TIMERS
    \brief Change in Timer T1 and Tmax
    The ucOptions in IFX_SIP_StackCfg need to be OR with these define
    to indicate the change in configuration
*/
#define IFX_SIP_CFG_TIMERS     0x02

/*! \def IFX_SIP_CFG_DNSTIMER
    \brief Change in DNS Timer Value
    The ucOptions in IFX_SIP_StackCfg need to be OR with these define
    to indicate the change in configuration
*/
#define IFX_SIP_CFG_DNSTIMER   0x04

/*! \def IFX_SIP_CFG_DSCPMARK
    \brief The DSCP mark options
    The ucOptions in IFX_SIP_StackCfg need to be OR with these define
    to indicate the change in configuration
*/
#define IFX_SIP_CFG_DSCPMARK   0x08

/*! \def IFX_SIP_CFG_COMPACTHDR
    \brief Change in Compact header options
    The ucOptions in IFX_SIP_StackCfg need to be OR with these define
    to indicate the change in configuration
*/
#define IFX_SIP_CFG_COMPACTHDR 0x10

/*! \def IFX_SIP_CFG_SERVERPORT
    \brief Change in Server Port 
    The ucOptions in IFX_SIP_StackCfg need to be OR with these define
    to indicate the change in configuration
*/
#define IFX_SIP_CFG_SERVERPORT 0x20

/*! \method IFX_SIP_Init
    \brief  Initilzes SIP stack
            Creates a Thread and initlizes SIP stack.
    \param[in] pfnInitStatus a callback function that shall be
               called after successfull initilization  
    \return IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return IFX_SIP_Init(void (*pfnInitStatus)(e_IFX_SIP_Return eStatus));

/*! \method IFX_SIP_StackCfg
    \brief  Api to Configure SIP stack
    \note This API should be called before IFX_SIP_Init() is called.
    \param[in] ucOptions Options to indicate the change in config 
    \param[in] ucDbgLvl Debug Level 
    \param[in] ucDbgType Debug type
    \param[in] unServerPort Sip Server Port
    \param[in] unTlsPort TLS Port
    \param[in] unT1 SIP Timer T1
    \param[in] unTmax SIP Timer TMax
    \param[in] unDnsQueryTimeOut Dns Query TimeOut
    \param[in] ucDSCPMark Diff serve Code point
    \param[in] ucUseCompactHdrs Compact Header ON/OFF
    \return  IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return IFX_SIP_StackCfg(uchar8 ucOptions,
                                         uchar8 ucDbgLvl,
                                         uchar8 ucDbgType,
                                         uint16 unServerPort,
                                         uint16 unTlsPort,
                                         uint16 unT1,
                                         uint16 unTmax,
                                         uint16 unDnsQueryTimeOut,
                                         uchar8 ucDSCPMark,
                                         uchar8 ucUseCompactHdrs);

/*! \method  IFX_SIP_Shut
    \brief   Api to ShutDown the Stack
    \return  IFX_SIP_SUCCESS or IFX_SIP_FAILURE
*/
PUBLIC e_IFX_SIP_Return IFX_SIP_Shut(void);
#endif /*__IFX_SIP_STACK_H__*/
