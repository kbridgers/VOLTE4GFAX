/*
** =============================================================================
** FILE NAME     : IFX_AutoGenConf.c
** PROJECT       : TR69
** MODULES       : Micellaneous
** DATE          : 07-Mar-2007
** AUTHOR        : TR69 Team
** DESCRIPTION   : Create rc.conf file on the fly. It reads tr69.conf file and
**                 then appends relevant section into the rc.conf file. The 
**                 target rc.conf to which the relevant sections needs to be
**                 appended is mentioned on command line. For e.g. 
**                 ./AutoGenConf ../../cwmp/bin/rc.conf IGD VOIP
**                 The above command appends IGD and VOIP sections in 
**                 ../../cwmp/bin/rc.conf file.
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date   $Author    $Comment
**
** ============================================================================
*/
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include "IFX_DEVM_AutoGenCfgSupport.h"
#include <string.h>
#include <libgen.h>

#define IGD               "IGD"
#define VOIP              "VOIP"
#define DEVICE            "DEVICE"
#define FILENAME          "tr69.conf"
#define MAX_LINE          126
#define MAX_TAG_LINE      62
#define NEXT_CPEID_TAG    "#>> next_cpeid\n"

int instance=1; /* Mandatory */

int
write_NextCpeid2Rcconf(int argc, char *argv[])
{
    FILE *xpInFP, *xpOutFP;
    char caLineBuf[MAX_LINE], caTag[MAX_TAG_LINE], *caSecBuf = NULL;
    int i;

    if((xpInFP = fopen(argv[1], "r")) == NULL) {
        fprintf(stderr, "%s:%d couldn't open file %s\n", __func__,
                __LINE__, argv[1]);
        exit(1);
    }
    if((xpOutFP = fopen("temp.conf", "w")) == NULL) {
        fprintf(stderr, "%s:%d couldn't open file %s\n", __func__,
                __LINE__, "temp.conf");
        exit(2);
    }

    sprintf(caTag, "COMMON_NEXTCPEID");

    while(fgets(caLineBuf, MAX_LINE, xpInFP)) {

        if(strcasecmp(caLineBuf, NEXT_CPEID_TAG) == 0) {
            if(!
               (ifx_GetCfgObject
                ((char *)FILENAME, (char *)caTag, NULL, IFX_F_GET_ANY,
                 &caSecBuf))) {
                // printf ("%s\n", caSecBuf);
                fputs(caSecBuf, xpOutFP);
            }

            for(i = 2; i < argc; i++) {
                if(strcasecmp(argv[i], IGD) == 0) {
                    sprintf(caTag, "TR69_NEXTCPEID");
                }
                if(strcasecmp(argv[i], VOIP) == 0) {
                    sprintf(caTag, "TR104_NEXTCPEID");
                }
                if(strcasecmp(argv[i], DEVICE) == 0) {
                    sprintf(caTag, "DEVICE_NEXTCPEID");
                }
                if(!
                   (ifx_GetCfgObject
                    ((char *)FILENAME, (char *)caTag, NULL, IFX_F_GET_ANY,
                     &caSecBuf))) {
                    // printf ("%s\n", caSecBuf);
                    fputs(caSecBuf, xpOutFP);
                }
            }                   // End of for loop
        }                       // if(strcasecmp(caLineBuf, NEXT_CPEID_TAG))
        fputs(caLineBuf, xpOutFP);
    }                           // End of while loop

    fclose(xpInFP);
    fclose(xpOutFP);

    /* Over write all the temp.conf file contents to rc.conf file & remove
       temp.conf file */
    if((xpOutFP = fopen(argv[1], "w")) == NULL) {
        fprintf(stderr, "%s:%d couldn't open file %s\n", __func__,
                __LINE__, argv[1]);
        exit(1);
    }
    if((xpInFP = fopen("temp.conf", "r")) == NULL) {
        fprintf(stderr, "%s:%d couldn't open file %s\n", __func__,
                __LINE__, "temp.conf");
        exit(2);
    }
    while(fgets(caLineBuf, MAX_LINE, xpInFP)) {
        fputs(caLineBuf, xpOutFP);
    }
    fputs("\n", xpOutFP);
    fclose(xpInFP);
    fclose(xpOutFP);

    remove("temp.conf");

    return 0;
}                               // End of write_NextCpeid2Rcconf()


int
write_Sect2Rcconf(FILE * xpAppFP, int argc, char *argv[], char *Sect)
{
    char caTag[MAX_TAG_LINE], *caSecBuf = NULL;
    int i;

    /* Put the beginning Sections for MAP, INSTANCES & ATTRIBUTES in rc.conf
       file */
    if(strcasecmp(Sect, "MAP") == 0) {
        fputs("\n#<< tr69_map\n", xpAppFP);
    }
    if(strcasecmp(Sect, "INSTANCES") == 0) {
        fputs("\n#<< tr69_instances\n", xpAppFP);
    }

    sprintf(caTag, "COMMON_%s", Sect);

    if(!
       (ifx_GetCfgObject
        ((char *)FILENAME, (char *)caTag, NULL, IFX_F_GET_ANY, &caSecBuf))) {

        fputs(caSecBuf, xpAppFP);
    }


    for(i = 2; i < argc; i++) {
        if(strcasecmp(argv[i], IGD) == 0) {
            sprintf(caTag, "TR69_%s", Sect);
        }
        if(strcasecmp(argv[i], VOIP) == 0) {
            sprintf(caTag, "TR104_%s", Sect);
        }
        if(strcasecmp(argv[i], DEVICE) == 0) {
            sprintf(caTag, "DEVICE_%s", Sect);
        }
        if(!
           (ifx_GetCfgObject
            ((char *)FILENAME, (char *)caTag, NULL, IFX_F_GET_ANY,
             &caSecBuf))) {

            if (!strcmp(Sect,"INSTANCES"))
            {
                char cBuff[500];
                char *ptr1=NULL;
                char *ptr2=NULL;
                ptr1=caSecBuf;
                while(*ptr1 != '\0')
                {
                    ptr2=strchr(ptr1,'\"');
                    if (ptr2)
                    {
                        sprintf(cBuff,"#%d=",instance++);
                        fputs(cBuff, xpAppFP);
                        ptr1=ptr2;
                        ptr2=strchr(ptr1,'\n');
                        *ptr2='\0';
                        sprintf(cBuff,"%s\n",ptr1);
                        *ptr2='\n';
                        fputs(cBuff, xpAppFP);
                        ptr1=ptr2+1;
                    }
                }
            }
            else
            {
                fputs(caSecBuf, xpAppFP);
            }

        }
    }                           // End of for loop

    /* Put the ending Sections for MAP, INSTANCES & ATTRIBUTES in rc.conf file */
    if(strcasecmp(Sect, "MAP") == 0) {
        fputs("#>> tr69_map", xpAppFP);
    }
    if(strcasecmp(Sect, "INSTANCES") == 0) {
        fputs("#>> tr69_instances\n", xpAppFP);
    }

    fputs("\n", xpAppFP);

    return 0;
}                               // End of write_Sect2Rcconf()


/* main() : It generates the rc.conf file based on the inputs */
int
main(int argc, char *argv[])
{
    FILE *xpAppFP;

    if(argc < 3) {
        fprintf(stderr, "Usage : %s <rc.conf> <IGD> <VOIP> <DEVICE>\n",
                basename(argv[0]));
        exit(1);
    }
    /* Write all Next_cpeid Sections to rc.conf file at appropriate position */
    write_NextCpeid2Rcconf(argc, argv);

    /* Open rc.conf file with append mode */
    if((xpAppFP = fopen(argv[1], "a")) == NULL) {
        fprintf(stderr, "%s:%d couldn't open file %s\n", __func__,
                __LINE__, argv[1]);
        exit(2);
    }

    /* Write all VALUES Sections to rc.conf file at appropriate position */
    write_Sect2Rcconf(xpAppFP, argc, argv, "VALUES");

    /* Write beg. of tr69_section to rc.conf file at appropriate position */
    //fputs("\n#<< tr69_section\n", xpAppFP);


    /* Write all MAP, INSTANCES & ATTRIBUTES Sections to rc.conf file at
       appropriate position */
    write_Sect2Rcconf(xpAppFP, argc, argv, "MAP");
    write_Sect2Rcconf(xpAppFP, argc, argv, "INSTANCES");
    write_Sect2Rcconf(xpAppFP, argc, argv, "ATTRSECTION");

    /* Write end tr69_section to rc.conf file at the end */
    //fputs("\n#>> tr69_section\n", xpAppFP);
    fclose(xpAppFP);

    return 0;
}                               // End of main()
