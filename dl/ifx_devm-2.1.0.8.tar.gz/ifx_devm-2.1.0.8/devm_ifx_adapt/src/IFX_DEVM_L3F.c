/* 
** =============================================================================
**   FILE NAME        : IFIN_Layer3Forwarding.c
**   PROJECT          : TR69
**   MODULES          : Layer3Forwarding
**   DATE             : 28-04-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This module handles ADD/DEL/GET/SET RPCs of
**                      Layer3Forwarding. When controller calls this module it
**                      respective Platform/Object APIs to handle the GET/SET 
**                      of Layer3Forwarding specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date               $Author                         $Comment
**   28-04-06            TR69 team                       Intial version
** ============================================================================
*/




/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_L3F.h"
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
//#include "IFIN_Obj_API.h"
 
#include "IFX_DEVM_AdaptCommon.h"
#include "IFX_DEVM_StackUtil.h"

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

extern char8 vcOsModId;

#define TR69OID_SEP      ".\0"
extern Old_Enable_Val axOldRouteState[IFX_MAX_CONF_WAN_CONN];
//#define L3F_GET_DEFAULT_WAN_HACK


/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/

# define IFIN_LAYER3FORWARDING_OBJ "InternetGatewayDevice.Layer3Forwarding."
# define IFIN_FORWARDING_OBJ "InternetGatewayDevice.Layer3Forwarding.Forwarding."


/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/

typedef struct {
    IFX_ID iid;
    char8 *psDefaultConnectionService;
    char8 *psForwardNumberOfEntries;
}Layer3Forwarding;

typedef struct {
	IFX_ID iid;
	char8 *psEnable;
	char8 *psStatus;
	char8 *psType;
	char8 *psDestIPAddress;
	char8 *psDestSubnetMask;
	char8 *psSourceIPAddress;
	char8 *psSourceSubnetMask;
	char8 *psGatewayIPAddress;
	char8 *psInterface;
	char8 *psForwardingMetric;
	char8 *psMTU;
        char8 *psStaticRoute;
}Forwarding;
	



/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/



/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

STATIC void
IFIN_L3F_FreeMembers(INOUT Layer3Forwarding *pxL3F);
STATIC void
IFIN_L3F_F_FreeMembers(INOUT Forwarding *pxF);
STATIC void
IFIN_L3F_FreeRouteEntries(IN ANY_ROUTE_ENTRY **ppxAnyRouteEntry, int32 iNumRoutes );

//STATIC int32 IFIN_Module_GetObjectDepth(IN int32 *paiOID);
//STATIC int32 IFIN_Module_GetObjectInstance(IN int32 *paiOID);
//STATIC int32 IFIN_Module_GetPartialOID(IN int32 *paiOID);

STATIC int32
IFIN_Layer3Forwarding_Validate(INOUT ParamVal * pxSetParamVal, IN int32 iElements);
 int32
IFIN_Layer3Forwarding_Modify(IN OperInfo *pxOI, INOUT ParamVal * pxSetParamVal,
                    IN int32 iElements);
 int32
IFIN_Layer3Forwarding_AddDel(IN int32 iCaller, INOUT ParamVal * pxSetParamVal,
                    IN int32 iElements, IN int32 operation);
//STATIC int32
//GetNotify(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);

STATIC int32 
IFIN_Layer3Forwarding_UpdateChildInfo(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,IN int32 iElements);

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/



/* 
** =============================================================================
**   Function Name    : IFIN_L3F_FreeMembers
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

STATIC void
IFIN_L3F_FreeMembers(INOUT Layer3Forwarding *pxL3F)
{
    IFX_CWMP_FREE(pxL3F->psDefaultConnectionService);
    IFX_CWMP_FREE(pxL3F->psForwardNumberOfEntries);
    /* TBD: Free members of iid structure */
    return;
}


STATIC void
IFIN_L3F_F_FreeMembers(INOUT Forwarding *pxF)
{
    IFX_CWMP_FREE(pxF->psEnable);
    IFX_CWMP_FREE(pxF->psStatus);
    IFX_CWMP_FREE(pxF->psType);
    IFX_CWMP_FREE(pxF->psDestIPAddress);
    IFX_CWMP_FREE(pxF->psDestSubnetMask);
    IFX_CWMP_FREE(pxF->psSourceIPAddress);
    IFX_CWMP_FREE(pxF->psSourceSubnetMask);
    IFX_CWMP_FREE(pxF->psGatewayIPAddress);
    IFX_CWMP_FREE(pxF->psInterface);
    IFX_CWMP_FREE(pxF->psForwardingMetric);
    IFX_CWMP_FREE(pxF->psMTU);
    IFX_CWMP_FREE(pxF->psStaticRoute);
    /* TBD: Free members of iid structure */
    return;
}


STATIC void
IFIN_L3F_FreeRouteEntries(IN ANY_ROUTE_ENTRY **ppxAnyRouteEntry, int32 iNumRoutes )
{

	int iCnt;
	ANY_ROUTE_ENTRY *pxTmpAnyRouteEntry = NULL;	// pointer to traverse the routing entries

	for(iCnt=0; iCnt<iNumRoutes; iCnt++){
		pxTmpAnyRouteEntry = *ppxAnyRouteEntry;
		free(pxTmpAnyRouteEntry+iCnt);
	}

	*ppxAnyRouteEntry = NULL;
}


/* 
** =============================================================================
**   Function Name    : IFIN_Module_GetInstanceNo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
IFIN_L3F_GetInstanceNo( IN char *tr69Id, IN  int32 iOffset)
{
	char sTmpTr69Id[MAX_TR69_ID_LEN] = { 0 };
	int iCnt=0;
	char *sTmp = NULL;
	int iInstanceNo = 0;

	strncpy(sTmpTr69Id, tr69Id, MAX_TR69_ID_LEN-1);
	sTmpTr69Id[MAX_TR69_ID_LEN-1]='\0';

	strtok(sTmpTr69Id,".,\0");
	iCnt++;

	while(iCnt < iOffset){
		sTmp = strtok(NULL,".,\0");
		iCnt++;

		if(sTmp == NULL)
			return IFX_CWMP_FAILURE;

	}

	if(sTmp) 
		iInstanceNo = atoi(sTmp);

	return iInstanceNo;
}



/* 
** =============================================================================
**   Function Name    : IFIN_Layer3Forwarding_Validate
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
IFIN_Layer3Forwarding_Validate(INOUT ParamVal * pxSetParamVal, IN int32 iElements)
{
	return IFX_CWMP_SUCCESS;

}


/* 
** =============================================================================
**   Function Name    : GetNotify
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

STATIC int32
GetNotify(IN OperInfo *pxOI, INOUT ParamVal * pxGetParamVal, IN int32 iElements)
{

	int iCaller;
	int32   iRet = IFX_CWMP_SUCCESS;
	int32   iCnt = 0;
	Layer3Forwarding xL3F;
	Forwarding xF;
	int32   iParamOffset;
	int32 iNumRoutes = 0;
	ANY_ROUTE_ENTRY *pxAnyRouteEntry = NULL;
	ROUTE_ENTRY *pxStaticRouteEntry = NULL;
	int32 iInstanceNo=0;
	int32 iNumStaticRoutes = 0;
	int32 iWanIndex = 0;
	IFX_ID xIfxId;
	char8 wan_connName[MAX_FILELINE_LEN];

	ParamVal xGetParam;
	ParamVal *paxGetParamVal = NULL; 
	int32 iElemOut=0;
	int32 i,j,i_save=0;
	char *obj = NULL;
	int oid[OID_LENGTH] = { 0 };
	char sIfName[150] = { 0 };
        int32 wan_type = 0;

	// assign the caller to iCaller to be used in the func
	iCaller = pxOI->iCaller;

	memset(&xL3F, 0, sizeof(Layer3Forwarding));
	memset(&xF, 0, sizeof(Forwarding));	
	memset(&xGetParam, 0x00, sizeof(ParamVal));
	memset(wan_connName, 0x00, sizeof(wan_connName));

	/* Get all the Layer3Forwarding parameters using Protocol API */

	iRet = ifx_get_all_route_entries( &iNumRoutes, &pxAnyRouteEntry, IFX_F_GET_ANY);
	if(iRet != IFX_CWMP_SUCCESS){
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] [Error] ifx_get_all_route_entries failed\n",  __func__, __LINE__);
		iRet = ERR_CWMP_INTERNAL;
		goto cleanup;
	}	

	// fill the data optained from platform API's into the response struct
	xL3F.psDefaultConnectionService = NULL;


	//*test
	memset(&xIfxId, 0x00, sizeof(xIfxId));
	iRet = ifx_get_default_wan_if( &xIfxId, &iWanIndex, wan_connName, IFX_F_GET_ANY);
#ifdef L3F_GET_DEFAULT_WAN_HACK
	strcpy(xIfxId.cpeId.secName,"wan_main");
	xIfxId.cpeId.Id = 1;
	strcpy(xIfxId.pcpeId.secName,"wan_conndev");
	xIfxId.pcpeId.Id = 1;
#endif
	xIfxId.config_owner = iCaller;


	if(iRet != IFX_CWMP_SUCCESS){
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] [Error] ifx_get_default_wan_if failed\n", __func__, __LINE__);
		iRet = ERR_CWMP_INTERNAL;
		goto cleanup;
	}	

	//		strcpy(xIfxId.cpeId.secName, generic_function_to_extract_sectionfield(pxGetParamVal->psRCTag));
	iRet = IFX_GetTr69IdFromCpeId( (IFX_Id *)&xIfxId); 
	if(iRet != IFX_CWMP_SUCCESS){
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] [Error] IFX_GetTr69IdFromCpeId failed\n", __func__, __LINE__);
		goto cleanup;
	}	


	// convert the tr69 id obtained in char to int
	memset(oid, 0x00, sizeof(oid));
	iRet = IFX_AscToIntOID(xIfxId.tr69Id, oid);

	obj = (char *)IFX_CWMP_MALLOC(150);
	if(obj == NULL){
		iRet = IFX_CWMP_FAILURE;
		goto cleanup;
	}
	// VIVEK : now convert this tr69 id to tr69 name using the global api and then copy it in the return structure.
	iRet = IFX_GlobalNameOidConversion(obj, oid);
	if(iRet != IFX_CWMP_SUCCESS){
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] [Error] IFX_GlobalNameOidConversion failed\n", __func__, __LINE__);
		goto cleanup;
	}	


	xL3F.psDefaultConnectionService = obj;
    	if(pxOI->iCaller != ACC_TR64 && pxOI->iCaller != ACC_UPNP){
	//ORP: Here the DefaultConnectionService will always be terminated with a dot. So removing the dot as per spec
		xL3F.psDefaultConnectionService[strlen(xL3F.psDefaultConnectionService)-1]='\0';
	}
	//end test*/		

	xL3F.psForwardNumberOfEntries = (char8 *)IFX_CWMP_MALLOC(11);	//assuming the sum fits in a int32 
	if(xL3F.psForwardNumberOfEntries == NULL){
		iRet = IFX_CWMP_FAILURE;
		goto cleanup;
	}

	//GET THE NUMBER OF STATIC ROUTES
	iRet = ifx_get_all_static_route_entries( &iNumStaticRoutes, &pxStaticRouteEntry, IFX_F_GET_ANY);
	if(iRet != IFX_CWMP_SUCCESS){
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] [Error] ifx_get_all_static_route_entries failed\n",  __func__, __LINE__);
		iRet = ERR_CWMP_INTERNAL;
		goto cleanup;
	}
	IFX_CWMP_FREE(pxStaticRouteEntry);

	snprintf( xL3F.psForwardNumberOfEntries,10,"%d", iNumStaticRoutes);


	// Fill the forwarding structure
	iParamOffset = IFX_GetParamIdPos(pxGetParamVal->iaOID);
        if ((iParamOffset <= 0) || (iParamOffset > OID_LENGTH))
        {
            iRet = ERR_CWMP_INTERNAL;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
            goto cleanup;
        }

	for( iCnt = 0; iCnt<  iNumRoutes; iCnt++){
		// if cpe id is 0 then its a dynamic route and therfore ignore it
		if(pxAnyRouteEntry[iCnt].ROUTE.policy_route.iid.cpeId.Id == 0){
			continue;
		}

		iRet = IFX_GetTr69IdFromCpeId((IFX_Id *)&(pxAnyRouteEntry[iCnt].ROUTE.policy_route.iid));
		if(iRet != IFX_CWMP_SUCCESS){
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s] [%d] IFX_GetTr69IdFromCpeId failed \n", __func__ , __LINE__);
			goto  cleanup;
		}

		iInstanceNo = IFIN_L3F_GetInstanceNo(pxAnyRouteEntry[iCnt].ROUTE.policy_route.iid.tr69Id, iParamOffset);

		if( iInstanceNo == pxGetParamVal->iaOID[iParamOffset - 1]){
			// struct found

			// fill the xF struct with the values

			//parameter Enable
			xF.psEnable = (char8 *)IFX_CWMP_MALLOC(3);
			if(xF.psEnable == NULL){
				iRet = IFX_CWMP_FAILURE;
				goto cleanup;
			}

			snprintf(xF.psEnable, 3, "%d", pxAnyRouteEntry[iCnt].ROUTE.policy_route.f_enable);

			// parameter Status
			xF.psStatus = (char8 *)IFX_CWMP_MALLOC(9);
			if( xF.psStatus == NULL){
				iRet = IFX_CWMP_FAILURE;
				goto cleanup;
			}

			if(pxAnyRouteEntry[iCnt].ROUTE.policy_route.status==  ROUTE_STATUS_ENABLED)
				strncpy(xF.psStatus, "Enabled",8);
			else if(pxAnyRouteEntry[iCnt].ROUTE.policy_route.status== ROUTE_STATUS_DISABLED)
				strncpy(xF.psStatus, "Disabled",8);
			else if(pxAnyRouteEntry[iCnt].ROUTE.policy_route.status == ROUTE_STATUS_ERROR)
				strncpy(xF.psStatus, "Error",8);
                        // parameter StaticRoute
                        xF.psStaticRoute = (char8 *)IFX_CWMP_MALLOC(3);
                        if(xF.psStaticRoute == NULL){
                                iRet = IFX_CWMP_FAILURE;
                                goto cleanup;
                        }

                        sprintf(xF.psStaticRoute, "%d", pxAnyRouteEntry[iCnt].ROUTE.route.static_route);

			// parameter Type
			xF.psType= (char8 *)IFX_CWMP_MALLOC(9);
			if(xF.psType == NULL){
				iRet = IFX_CWMP_FAILURE;
				goto cleanup;
			}

			if(pxAnyRouteEntry[iCnt].ROUTE.policy_route.type == ROUTE_TYPE_DEFAULT)
				strncpy(xF.psType, "Default",8);
			else if(pxAnyRouteEntry[iCnt].ROUTE.policy_route.type == ROUTE_TYPE_NET)
				strncpy(xF.psType, "Network",8);
			else if(pxAnyRouteEntry[iCnt].ROUTE.policy_route.type == ROUTE_TYPE_HOST)
				strncpy(xF.psType, "Host",8);				

			// parameter DestIPAddress
			xF.psDestIPAddress = (char8 *)IFX_CWMP_MALLOC(17);
			if(xF.psDestIPAddress == NULL){
				iRet = IFX_CWMP_FAILURE;
				goto cleanup;
			}

			strncpy(xF.psDestIPAddress, inet_ntoa(pxAnyRouteEntry[iCnt].ROUTE.policy_route.ip_dst.ip), 16);

			//To handle wildcard as value
			if(strcmp(xF.psDestIPAddress,"0.0.0.0")==0)
				strcpy(xF.psDestIPAddress,"");


			// parameter DestSubnetMask
			xF.psDestSubnetMask= (char8 *)IFX_CWMP_MALLOC(17);
			if(xF.psDestSubnetMask == NULL){
				iRet = IFX_CWMP_FAILURE;
				goto cleanup;
			}

			strncpy(xF.psDestSubnetMask, inet_ntoa(pxAnyRouteEntry[iCnt].ROUTE.policy_route.ip_dst.mask),16);

			//To handle wildcard as value
			if(strcmp(xF.psDestSubnetMask,"0.0.0.0")==0)
				strcpy(xF.psDestSubnetMask,"");


			// parameter GatewayIPAddress
			xF.psGatewayIPAddress= (char8 *)IFX_CWMP_MALLOC(17);
			if(xF.psGatewayIPAddress == NULL){
				iRet = IFX_CWMP_FAILURE;
				goto cleanup;
			}

			strncpy(xF.psGatewayIPAddress, inet_ntoa(pxAnyRouteEntry[iCnt].ROUTE.policy_route.gw), 16);

			// parameter Interface
			xF.psInterface = (char8 *)IFX_CWMP_MALLOC(150);
			if(xF.psInterface == NULL){
				iRet = IFX_CWMP_FAILURE;
				goto cleanup;
			}

			if(strlen(pxAnyRouteEntry[iCnt].ROUTE.policy_route.route_if)>0) {
			    if(!strcmp(pxAnyRouteEntry[iCnt].ROUTE.policy_route.route_if,"br0")){
			    	if(pxOI->iCaller != ACC_TR64 && pxOI->iCaller != ACC_UPNP){
					//ORP:Interface name is not terminated by dot. So removing the dot
					strcpy(xF.psInterface,"InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.IPInterface.1");
				}
				else {
					strcpy(xF.psInterface,"InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.IPInterface.1.");
				}
				i_save = 1; //set flag when found
			    }else{

				for(j=0; j<=1; j++){ // counter to run through wanip and wanppp
					memset(&xGetParam,0x00,sizeof(xGetParam));

					// copy the oid of IGD.WANDevice.MN.WANConnectoinDevice.MN.WANIPConnection.MN.Name
					xGetParam.iaOID[0] = -1000;
					xGetParam.iaOID[1] = -1224;				
					xGetParam.iaOID[2] =  MAGIC_NUMBER;
					xGetParam.iaOID[3] =  -1385;
					xGetParam.iaOID[4] = MAGIC_NUMBER;
					xGetParam.iaOID[5] =  (j) ? -1432 : -1472;
					xGetParam.iaOID[6] = MAGIC_NUMBER;
					xGetParam.iaOID[7] = (j) ? -1437 : -1477;
					xGetParam.iaOID[8] = 0;
					xGetParam.iaOID[9] = 0;				
					xGetParam.iaOID[10] = 0;				

					iRet = IFX_GlobalGetVal( &xGetParam, &paxGetParamVal, (uint32 *)&iElemOut);
					if(iRet != IFX_CWMP_SUCCESS){
						IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d] IFX_GlobalGetVal failed \n", __func__ , __LINE__);
						IFX_CWMP_FREE(xGetParam.Name);
						for(i=0; i<iElemOut; i++){
							if(paxGetParamVal != NULL){
								//free the irrelevant dataifx_
								IFX_CWMP_FREE(paxGetParamVal[i].Name);
								IFX_CWMP_FREE(paxGetParamVal[i].Value);
							}
						}
						IFX_CWMP_FREE(paxGetParamVal);
						if(j == 1)
							goto interface_end;
						else
							continue;
					}

					for(i=0; i<iElemOut; i++){
                                                wan_type = (j) ? WAN_TYPE_IP : WAN_TYPE_PPP;
						// convert the connection name to interface name
						iRet = ifx_get_wan_ifname_from_conf_connName(paxGetParamVal[i].Value, sIfName, wan_type);
						if(iRet != IFX_CWMP_SUCCESS){
							IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d]  ifx_get_wan_ifname_from_conf_connName failed \n", __func__ , __LINE__);

							IFX_CWMP_FREE(xGetParam.Name);
							for(i=0; i<iElemOut; i++){
								//free the irrelevant dataifx_
								IFX_CWMP_FREE(paxGetParamVal[i].Name);
								IFX_CWMP_FREE(paxGetParamVal[i].Value);
							}
							IFX_CWMP_FREE(paxGetParamVal);
							iRet = ERR_CWMP_INTERNAL;
							goto cleanup;
						}

						// if the interface value matches, copy the name as the final response
						if(!strcmp(pxAnyRouteEntry[iCnt].ROUTE.policy_route.route_if, sIfName)){
							// copy the path just before till name
    							if(pxOI->iCaller != ACC_TR64 && pxOI->iCaller != ACC_UPNP){
								//ORP: Get operation will give the interface name that is not terminated by dot. So substracting 5 instead of 4
								strncpy(xF.psInterface, paxGetParamVal[i].Name, strlen(paxGetParamVal[i].Name)-5);
							}
							else {
								strncpy(xF.psInterface, paxGetParamVal[i].Name, strlen(paxGetParamVal[i].Name)-4);
							}
							i_save = 1; //set flag when found
							break;
						}// end if

					} // end for

					IFX_CWMP_FREE(xGetParam.Name);

					for(i=0; i<iElemOut; i++){
						//free the irrelevant dataifx_
						IFX_CWMP_FREE(paxGetParamVal[i].Name);
						IFX_CWMP_FREE(paxGetParamVal[i].Value);
					}
					IFX_CWMP_FREE(paxGetParamVal);

					if(i_save == 1)		// no need to check for different type of conn if already found
						break;

				}// end for
			    }// end if-else

interface_end :
			    if(i_save==0){ // end of for loop reached without finding the reuqired values
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s called, No value found for interface\n", __func__);
			    }
			
			    iRet = IFX_CWMP_SUCCESS; // set it to success in all cases 
                        }

			// paramter ForwardingMetric 
			xF.psForwardingMetric = IFX_CWMP_MALLOC(15);
			if(xF.psForwardingMetric == NULL){
				iRet = IFX_CWMP_FAILURE;
				goto cleanup;
			}

			snprintf(xF.psForwardingMetric,14,"%d", pxAnyRouteEntry[iCnt].ROUTE.policy_route.metric);


			// parameter source ipaddr
			xF.psSourceIPAddress= (char8 *)IFX_CWMP_MALLOC(17);
			if(xF.psSourceIPAddress  == NULL){
				iRet = IFX_CWMP_FAILURE;
				goto cleanup;
			}

			strncpy(xF.psSourceIPAddress, inet_ntoa(pxAnyRouteEntry[iCnt].ROUTE.policy_route.ip_src.ip), 16);	
			//To handle wildcard as value
			if(strcmp(xF.psSourceIPAddress,"0.0.0.0")==0)
				strcpy(xF.psSourceIPAddress,"");


			// parameter source subnetmask
			xF.psSourceSubnetMask= (char8 *)IFX_CWMP_MALLOC(17);
			if(xF.psSourceSubnetMask == NULL){
				iRet = IFX_CWMP_FAILURE;
				goto cleanup;
			}

			strncpy(xF.psSourceSubnetMask, inet_ntoa(pxAnyRouteEntry[iCnt].ROUTE.policy_route.ip_src.mask), 16);	
			//To handle wildcard as value
			if(strcmp(xF.psSourceSubnetMask,"0.0.0.0")==0)
				strcpy(xF.psSourceSubnetMask,"");


			// parameter MTU
			xF.psMTU = (char *)IFX_CWMP_MALLOC(11);
			if(xF.psMTU == NULL){
				iRet = IFX_CWMP_FAILURE;
				goto cleanup;
			}

			sprintf(xF.psMTU, "%d",pxAnyRouteEntry[iCnt].ROUTE.policy_route.mtuSize);




			// since the instance is found and processed, break out of for loop
			break;
		}
	}



	/* Iterate and fill the requested parameters */
	for (iCnt = 0; iCnt < iElements; iCnt++)
	{

		/* Get the offset of the parameter */
		iParamOffset = IFX_GetParamIdPos(pxGetParamVal[iCnt].iaOID);

		/* Process based on the requested parameter */
		switch ((pxGetParamVal[iCnt]).iaOID[iParamOffset])
		{

			case OID_IGD_L3F_DEFAULTCONNECTIONSERVICE:
				(pxGetParamVal[iCnt]).Value = xL3F.psDefaultConnectionService;
				xL3F.psDefaultConnectionService = NULL;

				break;  


			case OID_IGD_L3F_FORWARDNUMBEROFENTRIES:
				(pxGetParamVal[iCnt]).Value = xL3F.psForwardNumberOfEntries;
				xL3F.psForwardNumberOfEntries = NULL;

				iRet = IFX_CheckValueGotChanged(pxOI,  pxGetParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
				if (iRet != IFX_CWMP_SUCCESS)
					goto cleanup;

				break;  

			case OID_IGD_L3F_F_ENABLE:
				(pxGetParamVal[iCnt]).Value = xF.psEnable;
				xF.psEnable = NULL;
				break;  

			case OID_IGD_L3F_F_STATUS:
				(pxGetParamVal[iCnt]).Value = xF.psStatus;
				xF.psStatus = NULL;


				iRet = IFX_CheckValueGotChanged(pxOI,  pxGetParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
				if (iRet != IFX_CWMP_SUCCESS)
					goto cleanup;

				break;  
                        case OID_IGD_L3F_F_STATICROUTE:
                                (pxGetParamVal[iCnt]).Value = xF.psStaticRoute;
                                xF.psStaticRoute = NULL;
                                break;

			case OID_IGD_L3F_F_TYPE:
				(pxGetParamVal[iCnt]).Value = xF.psType;
				xF.psType= NULL;
				break;  

			case OID_IGD_L3F_F_DESTIPADDRESS:
				(pxGetParamVal[iCnt]).Value = xF.psDestIPAddress;
				xF.psDestIPAddress= NULL;
				break;  

			case OID_IGD_L3F_F_DESTSUBNETMASK:
				(pxGetParamVal[iCnt]).Value = xF.psDestSubnetMask;
				xF.psDestSubnetMask= NULL;
				break;  

			case OID_IGD_L3F_F_SOURCEIPADDRESS:
				(pxGetParamVal[iCnt]).Value = xF.psSourceIPAddress;
				xF.psSourceIPAddress= NULL;
				break;  

			case OID_IGD_L3F_F_SOURCESUBNETMASK:
				(pxGetParamVal[iCnt]).Value = xF.psSourceSubnetMask;
				xF.psSourceSubnetMask= NULL;
				break;  

			case OID_IGD_L3F_F_GATEWAYIPADDRESS:
				(pxGetParamVal[iCnt]).Value = xF.psGatewayIPAddress;
				xF.psGatewayIPAddress= NULL;
				break;  

			case OID_IGD_L3F_F_INTERFACE:
				(pxGetParamVal[iCnt]).Value = xF.psInterface;
				xF.psInterface= NULL;
				break;  

			case OID_IGD_L3F_F_FORWARDINGMETRIC:
				(pxGetParamVal[iCnt]).Value = xF.psForwardingMetric;
				xF.psForwardingMetric= NULL;
				break;  

			case OID_IGD_L3F_F_MTU:
				(pxGetParamVal[iCnt]).Value = xF.psMTU;
				xF.psMTU = NULL;
				break;  


			default:
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
						"[%s:%d] [Error] Unknown requested parameter\n",
						__func__, __LINE__);
				/* If we have to return a failure over here, this loop has to be
				   processed twice. Initially to find if any faulty parameter is
				   requested and then for actual assignment.
				//iRet = IFX_CWMP_FAILURE; */

				// could not find this parameter - set the fault code
				pxGetParamVal[iCnt].iFaultCode = ERR_INVAL_PARAMETER_NAME;

				goto cleanup;
		}
	}


cleanup:

	/* Perform Cleanup of unnecessary DevInfo members */
        IFX_CWMP_FREE(xL3F.psForwardNumberOfEntries);
	IFIN_L3F_FreeMembers(&xL3F);
	IFIN_L3F_F_FreeMembers(&xF);
	IFIN_L3F_FreeRouteEntries(&pxAnyRouteEntry, 1  /*iNumRoutes*/);

	if(iRet != IFX_CWMP_SUCCESS)
		iRet = ERR_CWMP_INTERNAL;				// set the function return value tp ERR_CWMP_INVALID_ARGS

	return (iRet);

}







/* 
** =============================================================================
**   Function Name    : SetAttrInfo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
	int32 iRet = IFX_CWMP_SUCCESS;
	int32 iCnt;
	int iParamOffset = 0;
	int iNumStaticRoutes =0;
	ROUTE_ENTRY *pxStaticRouteEntry = NULL;

	char *sNumRoutes = NULL;
	sNumRoutes = (char *)IFX_CWMP_MALLOC(13);
	if(sNumRoutes == NULL){
		iRet = IFX_CWMP_FAILURE;
		goto cleanup;
	}


    /* Set the fault code to Success and value to NULL pointer for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
	// set value for all to NULL
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
        (pxParamVal[iCnt]).Value = NULL;


	    /* Get the offset of the parameter */
	    iParamOffset = IFX_GetParamIdPos(pxParamVal[iCnt].iaOID);
            if ((iParamOffset <= 0) || (iParamOffset > OID_LENGTH))
            {
                iRet = ERR_CWMP_INTERNAL;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
                goto cleanup;
            }


	// if it is L3F.ForwardNumberOfEntries the do this
	if(pxParamVal[iCnt].iaOID[iParamOffset] == OID_IGD_L3F_FORWARDNUMBEROFENTRIES){

		//GET THE NUMBER OF STATIC ROUTES
		iRet = ifx_get_all_static_route_entries( &iNumStaticRoutes, &pxStaticRouteEntry, IFX_F_GET_ANY);
			if(iRet != IFX_CWMP_SUCCESS){
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] [Error] ifx_get_all_static_route_entries failed\n",  __func__, __LINE__);
				iRet = ERR_CWMP_INTERNAL;
				goto cleanup;
			}
		IFX_CWMP_FREE(pxStaticRouteEntry);


		snprintf(sNumRoutes,12,"%d",iNumStaticRoutes);
		(pxParamVal[iCnt]).Value = (void *)sNumRoutes;
		
	}


    } // end for

    /* Update Attribute Information */
    iRet = IFX_SetAttributesInfo(NULL, pxParamVal, iElements);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Updating Param Attribute Info failed\n",
                    __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    IFX_CWMP_FREE(sNumRoutes);
    
    return (iRet);
}


/* 
** =============================================================================
**   Function Name    : IFIN_Layer3Forwarding_Add
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : Only static routes can be set and policy routes cannot be set
**
** ============================================================================
*/
int32
IFIN_Layer3Forwarding_AddDel(IN int32 iCaller, IN ParamVal *pxSetParamVal, IN int32 iNumElem, IN int32 operation)
{
 
	int32   iRet = IFX_CWMP_SUCCESS;
	int32   iCnt = 0;
	char sOidString[IFX_MAX_TR69_ID_LEN] = { 0 };
	char sTmp[15] = { 0 };
	int32   iParamOffset;
	IFX_CpeId *pxCpeIdArray = NULL;
	unsigned int uiNumCpeId = 0;
	ParamVal xGetParam;
	ParamVal *paxGetParamVal = NULL;
	int32 iElemOut = 0;
	int iCount = 0;
	POLICY_ROUTE xNewPRouteEntry;
	int iFlag = 0;
	char sIfName[150] = { 0 };
	ANY_ROUTE_ENTRY xAnyRoute;
        int32 wan_type = 0;
	
	memset(&xNewPRouteEntry,0x00,sizeof(xNewPRouteEntry));
	memset(&xAnyRoute,0x00,sizeof(xAnyRoute));
	memset(&xGetParam, 0x00, sizeof(ParamVal));
	
	//fill the owner in the xNewRouteEntry
	xNewPRouteEntry.iid.config_owner = iCaller;

	if((operation != OP_SETVAL_ADD)&&(operation != OP_SETVAL_DELETE)){ // if neither delete operation nor add operation
	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] Invalid operation\n",
                   __func__, __LINE__);
		return ERR_CWMP_INTERNAL;
	}		

	if(operation == OP_SETVAL_DELETE){ // if delete operation
		// get cpeid, pass to delete function
		// here the input iaOID will be igd.l3f.f.2.

		iCnt = 0;
		while(pxSetParamVal[0].iaOID[iCnt+1]!= 0){		// ignode the last value as it will be a parameter and we need only till the last instance
			snprintf(sTmp,15,"%d",pxSetParamVal[0].iaOID[iCnt]);
			strcat(sOidString,sTmp);
			strcat(sOidString,".");
			iCnt++;
		}

		strcpy(xNewPRouteEntry.iid.tr69Id,sOidString);

		iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId, OUT &pxCpeIdArray);
		if(iRet != IFX_CWMP_SUCCESS){
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					"[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
					__func__, __LINE__);

			return ERR_CWMP_INTERNAL;
		}



		if(!strcmp(pxCpeIdArray->sSectionTag,"routing")){ //static route and policy route are same for delete
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,"[%s:%d] Deleting a route\n", __func__, __LINE__);
			xNewPRouteEntry.iid.cpeId.Id = pxCpeIdArray->uiId;
			memset(xNewPRouteEntry.iid.tr69Id,0x00,MAX_TR69_ID_LEN);

			if(strlen(pxCpeIdArray->sSectionTag) < MAX_TAG_LEN){
				strncpy(xNewPRouteEntry.iid.cpeId.secName,pxCpeIdArray->sSectionTag, MAX_TAG_LEN-1);
				IFX_CWMP_FREE(pxCpeIdArray);
			}else{
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
						"[%s:%d] [Error] strcpy : mismatch in size in buffer copy\n",
						__func__, __LINE__);
				IFX_CWMP_FREE(pxCpeIdArray);
				return ERR_CWMP_INTERNAL;
			}


	
			memcpy( &(xAnyRoute.ROUTE.policy_route), &xNewPRouteEntry, sizeof(xNewPRouteEntry));
			// assign this before calling the function	xNewRouteEntry.iid.cpeId
			iRet = ifx_set_route( IFX_OP_DEL, &xAnyRoute, IFX_F_DELETE | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH); 
			if(iRet != IFX_CWMP_SUCCESS){
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
						"[%s:%d] [Error] ifx_set_route failed\n",
						__func__, __LINE__);
//ORP: Never reboot after deletion
				IFX_CWMP_FREE(pxCpeIdArray);
				return iRet/*IFX_CWMP_NEED_REBOOT_DONT_SAVE*/;
			}
			
			return iRet/*IFX_CWMP_NEED_REBOOT*/;
		}
		IFX_CWMP_FREE(pxCpeIdArray);
		return iRet;

	}// end of delete operation


	// ADD operation


	// here the input iaOID will be igd.l3f.f.2.
	iCount=0;
	memset(sOidString,0x00,IFX_MAX_TR69_ID_LEN);
	iParamOffset = IFX_GetParamIdPos(pxSetParamVal->iaOID);
        if ((iParamOffset <= 0) || (iParamOffset > OID_LENGTH))
        {
            iRet = ERR_CWMP_INTERNAL;
	    IFX_CWMP_FREE(pxCpeIdArray);
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
            goto cleanup;
        }

	while((pxSetParamVal[0].iaOID[iCount]!= 0)&&(iCount < iParamOffset)){
		snprintf(sTmp,15,"%d",pxSetParamVal[0].iaOID[iCount]);
		strcat(sOidString,sTmp);
		strcat(sOidString,".");
		iCount++;
	}


	strcpy(xNewPRouteEntry.iid.tr69Id,sOidString);

	// fill the given parameters of this structure with the new values provided
	for( iCnt = 0; iCnt < iNumElem; iCnt++){
		/* Process based on the requested parameter */
		switch (pxSetParamVal[iCnt].iaOID[iParamOffset])
		{
			case OID_IGD_L3F_F_ENABLE:
				if (atoi(pxSetParamVal[iCnt].Value) == 1){
					xNewPRouteEntry.f_enable = 1;
					//iFlag = IFX_F_DEFAULT;
				}else if (atoi(pxSetParamVal[iCnt].Value) == 0){
					xNewPRouteEntry.f_enable = 0;
					//iFlag = IFX_F_DONT_ACTIVATE | IFX_F_DONT_VALIDATE | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH;
				}

				break;  

			case OID_IGD_L3F_F_STATUS:
				if(!strncasecmp(pxSetParamVal[iCnt].Value,"Enabled",7)){
				//	xNewPRouteEntry.status= ROUTE_STATUS_ENABLED;
				//	iFlag = IFX_F_DEFAULT;
				}else if(!strncasecmp(pxSetParamVal[iCnt].Value,"Disabled",8)){
				//	xNewPRouteEntry.status= ROUTE_STATUS_DISABLED;
				//	iFlag = IFX_F_DONT_ACTIVATE | IFX_F_DONT_VALIDATE | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH;
				}

				break;  
			case OID_IGD_L3F_F_STATICROUTE:
				if(!strncasecmp(pxSetParamVal[iCnt].Value,"True",4)){
					xNewPRouteEntry.static_route= TRUE;
				}else if(!strncasecmp(pxSetParamVal[iCnt].Value,"False",5)){
					xNewPRouteEntry.static_route= FALSE;
				}
				break;
			case OID_IGD_L3F_F_TYPE:
				if(!strncasecmp(pxSetParamVal[iCnt].Value,"Default",7))
					xNewPRouteEntry.type = ROUTE_TYPE_DEFAULT;
				else if(!strncmp(pxSetParamVal[iCnt].Value,"Network",7))
					xNewPRouteEntry.type = ROUTE_TYPE_NET;
				else if(!strncasecmp(pxSetParamVal[iCnt].Value,"Host",4))
					xNewPRouteEntry.type = ROUTE_TYPE_HOST;
				break;  

			case OID_IGD_L3F_F_DESTIPADDRESS:
				inet_aton(pxSetParamVal[iCnt].Value, &(xNewPRouteEntry.ip_dst.ip));
				break;  

			case OID_IGD_L3F_F_DESTSUBNETMASK:
				inet_aton(pxSetParamVal[iCnt].Value, &(xNewPRouteEntry.ip_dst.mask));
				break;  

			case OID_IGD_L3F_F_SOURCEIPADDRESS:
				inet_aton(pxSetParamVal[iCnt].Value, &(xNewPRouteEntry.ip_src.ip));
				break;  

			case OID_IGD_L3F_F_SOURCESUBNETMASK:
				inet_aton(pxSetParamVal[iCnt].Value, &(xNewPRouteEntry.ip_src.mask));
				break;  

			case OID_IGD_L3F_F_GATEWAYIPADDRESS:
				inet_aton(pxSetParamVal[iCnt].Value, &(xNewPRouteEntry.gw));
				break;  

			case OID_IGD_L3F_F_INTERFACE:
				// first check if default interface is given or not
				if((pxSetParamVal[iCnt].Value == NULL) || (!strcmp(pxSetParamVal[iCnt].Value,"")))
					break;

				// convert the given interface to correct value and add to struct
				memset(&xGetParam,0x00,sizeof(xGetParam));
				xGetParam.Name = (char *)IFX_CWMP_MALLOC(strlen(pxSetParamVal[iCnt].Value) + 8);
				if(xGetParam.Name == NULL){
					iRet = IFX_CWMP_FAILURE;
					goto cleanup;
				}

				strcpy(xGetParam.Name , pxSetParamVal[iCnt].Value);
				strcat(xGetParam.Name,"Name");		// this creates the entire path with name leaf
				IFX_CWMP_FREE(pxSetParamVal[iCnt].Value); //free the string passed

				iRet = IFX_GlobalGetVal( &xGetParam, &paxGetParamVal, (uint32 *)&iElemOut);
				if((iRet != IFX_CWMP_SUCCESS) || (paxGetParamVal == NULL)) {
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] [Error] IFX_GlobalGetVal failed\n", __func__, __LINE__);
					IFX_CWMP_FREE(xGetParam.Name);
					if(paxGetParamVal != NULL){
						IFX_CWMP_FREE(paxGetParamVal->Name);
						IFX_CWMP_FREE(paxGetParamVal->Value);
					}
					IFX_CWMP_FREE(paxGetParamVal);

					goto cleanup;
				}

                                if(strstr(pxSetParamVal[iCnt].Value,"WANPPPConnection") != NULL)
                                {
                                    wan_type = WAN_TYPE_PPP;
                                } 
                                else
                                {
                                    wan_type = WAN_TYPE_IP;
                                } 
				iRet = ifx_get_wan_ifname_from_conf_connName(paxGetParamVal->Value, sIfName, wan_type);
				if(iRet != IFX_CWMP_SUCCESS){
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] [Error] ifx_get_wan_ifname_from_conf_connName failed\n", __func__, __LINE__);
					IFX_CWMP_FREE(xGetParam.Name);
					IFX_CWMP_FREE(paxGetParamVal->Name);
					IFX_CWMP_FREE(paxGetParamVal->Value);
					IFX_CWMP_FREE(paxGetParamVal);

					iRet = ERR_CWMP_INTERNAL;
					goto cleanup;
				}

				// copy only if IFX_GlobalGetVal passed		
				strncpy(xNewPRouteEntry.route_if,sIfName,15);
				IFX_CWMP_FREE(xGetParam.Name);
				IFX_CWMP_FREE(paxGetParamVal->Name);
				IFX_CWMP_FREE(paxGetParamVal->Value);
				IFX_CWMP_FREE(paxGetParamVal);

				break;  

			case OID_IGD_L3F_F_FORWARDINGMETRIC:
				xNewPRouteEntry.metric = atoi((char *)pxSetParamVal[iCnt].Value) ;

				break;  

			case OID_IGD_L3F_F_MTU:
				xNewPRouteEntry.mtuSize = atoi((char *)pxSetParamVal[iCnt].Value) ;
				break;  


			default:
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
						"[%s:%d] [Error] Unknown requested parameter\n",
						__func__, __LINE__);

				// parameter not found
				pxSetParamVal[iCnt].iFaultCode = ERR_INVAL_PARAMETER_NAME;

				goto cleanup;
		}
	} // nd for

	iFlag =(	IFX_F_DONT_ACTIVATE|IFX_F_DONT_CHECKPOINT|
			IFX_F_DONT_VALIDATE|IFX_F_DONT_WRITE_TO_FLASH);

	// call the API to modify
	if(operation == OP_SETVAL_ADD){	// if ADD
		memcpy( &(xAnyRoute.ROUTE.policy_route), &xNewPRouteEntry, sizeof(xNewPRouteEntry));
		iRet = ifx_set_route( IFX_OP_ADD, &xAnyRoute, iFlag); // IFX_F_DEFAULT for add
		if(iRet != IFX_CWMP_SUCCESS){
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] [Error] ifx_set_route failed !!\n", __func__, __LINE__);
			iRet = ERR_CWMP_INTERNAL;
			goto cleanup;
		}
	}



cleanup:

    /* Perform Cleanup of unnecessary DevInfo members */

    return (iRet);


}





/* 
** =============================================================================
**   Function Name    : IFIN_Layer3Forwarding_Modify
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : Only static routes can be set and policy routes cannot be set
**
** ============================================================================
*/
 int32
IFIN_Layer3Forwarding_Modify(IN OperInfo *pxOI, IN ParamVal *pxSetParamVal, IN int32 iNumElem)
{


    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iCnt = 0, iCntRoute=0; //iCntErr=0;
    Layer3Forwarding xL3F;
    Forwarding xF;
    int32   iParamOffset;
    int32 iNumRoutes;
    int32 iEntryFound=0;    
    POLICY_ROUTE xNewPRouteEntry;
    ANY_ROUTE_ENTRY *pxAnyRouteEntry =NULL;
    int iInstanceNo = 0;
    int32 iFlags = 0;
    ParamVal xGetParam;
    ParamVal *paxGetParamVal = NULL; 
    int32 iElemOut = 0;
    char8 sTr69Id[MAX_TR69_ID_LEN]={0};
    uint32 uiNumCpeId = 0;
    IFX_CpeId *pxCpeIdArray = NULL;
    int iCounter = 0;
    char sTmpOid[20]={0};
    int oid[OID_LENGTH]={0};
    IFX_ID wan_iid;
    char sIfName[150]={0};
    ANY_ROUTE_ENTRY xAnyRoute;
    int32 iCaller = -1;
    uint32 iOldState = -1, iNewState = -1; //track enable and disable states
    int iSuccessReturn = IFX_CWMP_SUCCESS; 
    int iFailureReturn = IFX_CWMP_FAILURE; 
    iCaller = pxOI->iCaller;
    int32 iWanIndex = 0;
    int32 iDefaultConnServFound = 0;
    char8 caInterface[CWMP_MAX_OBJ_LEN] = { 0 };
    char8 wan_connName[MAX_FILELINE_LEN];
    int32 wan_type = 0;	

    memset(&xAnyRoute,0x00,sizeof(xAnyRoute));
    memset(&xL3F, 0x00, sizeof(Layer3Forwarding));
    memset(&xF, 0x00, sizeof(Forwarding));	
    memset(&xGetParam, 0x00, sizeof(ParamVal));
    memset(wan_connName, 0x00, sizeof(wan_connName));



    /* Get all the Layer3Forwarding parameters using Protocol API */

    iRet = ifx_get_all_route_entries( &iNumRoutes, &pxAnyRouteEntry, IFX_F_GET_ANY);

    if(iRet != IFX_CWMP_SUCCESS){
	    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			    "[%s:%d] [Error] ifx_get_all_route_entries failed\n",
			    __func__, __LINE__);

	    goto cleanup;
    }		


    // Fill the forwarding structure
    iParamOffset = IFX_GetParamIdPos(pxSetParamVal->iaOID);
    if ((iParamOffset <= 0) || (iParamOffset > OID_LENGTH))
    {
            iRet = ERR_CWMP_INTERNAL;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
            goto cleanup;
    }
    iDefaultConnServFound = 0;

    // go through the input and if there is set default connection service, do it
    for( iCnt = 0; iCnt < iNumElem; iCnt++)
    {
	    /* Process based on the requested parameter */
	    switch (pxSetParamVal[iCnt].iaOID[iParamOffset])
	    {
		    case OID_IGD_L3F_DEFAULTCONNECTIONSERVICE :
			
			    iDefaultConnServFound = 1; 
			    //check if the value is null or not
			    // if null and operation is activate, then get the value from rc.conf else take from input
			    if(pxOI->iSubOper == OP_SETVAL_ACTIVATE)
			    { 
				    iRet = ifx_get_default_wan_if(&wan_iid, &iWanIndex, wan_connName, IFX_F_GET_ANY);
				    if(iRet != IFX_CWMP_SUCCESS)
				    {
					    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d]  ifx_get_default_wan_if failed\n", __func__ , __LINE__);
					    iRet = IFX_CWMP_NEED_REBOOT_DONT_SAVE;
					    goto cleanup;
				    } 
                                    if(strcmp(wan_iid.cpeId.secName, "wan_ppp") == 0)
					wan_type = WAN_TYPE_PPP;
                                    else if(strcmp(wan_iid.cpeId.secName, "wan_ip") == 0)
					wan_type = WAN_TYPE_IP;
                                    else
				    {
					    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d] Section[%s] ifx_get_default_wan_if failed\n", __func__ , __LINE__, wan_iid.cpeId.secName);
					    iRet = IFX_CWMP_FAILURE;
					    goto cleanup;
				    } 

				    break;  // go and process this
			    }
                            else if(pxSetParamVal[iCnt].Value != NULL)
                            {
				    // take value of default connection service from input
				    memset(oid,0x00,sizeof(oid));
					memset(caInterface,0,sizeof(caInterface));
				    strcpy(caInterface,pxSetParamVal[iCnt].Value);
					if (caInterface[strlen(caInterface) -1]!='.')
					{
       					strcat(caInterface, ".");
					}
				    iRet = IFX_GlobalNameOidConversion( caInterface, oid); // replace this with global API
				    if(iRet != IFX_CWMP_SUCCESS){
					    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d]  IFX_GlobalNameOidConversion failed\n", __func__ , __LINE__);
					    pxSetParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
					    goto cleanup;
				    }

				    memset(sTmpOid, 0x00, sizeof(sTmpOid));
				    while(oid[iCounter] != 0){
					    sprintf(sTmpOid,"%d.",oid[iCounter]);	// print with a dot
                                            if(iCounter == 5)
                                            {
                                                if(oid[iCounter] == OID_IGD_WAND_WANCD_WANIPC)
                                                    wan_type = WAN_TYPE_IP; 
                                                else if(oid[iCounter] == OID_IGD_WAND_WANCD_WANPPPC)
                                                    wan_type = WAN_TYPE_PPP; 
                                            }
					    strcat(sTr69Id,sTmpOid);			
					    iCounter++;
				    } // end while

				    iRet = IFX_GetCpeIdFromTr69Id(sTr69Id, &uiNumCpeId, &pxCpeIdArray);
				    if(iRet != IFX_CWMP_SUCCESS){
					    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d]  IFX_GetCpeIdFromTr69Id failed\n", __func__ , __LINE__);
					    pxSetParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
					    goto cleanup;
				    }

				    wan_iid.cpeId.Id = pxCpeIdArray[0].uiId ;
			    }
			    break;

	    }	//end switch to find the wan iid from input from acs
    }	//end for 

    if(iDefaultConnServFound == 1)
    {
	    // process default connection service parameter
	    if(iCaller == ACC_TR64 || iCaller == ACC_UPNP)
            {
		    if(pxOI->iSubOper == OP_SETVAL_MODIFY)
                    { // activate the values stored previously

			    iRet = ifx_set_default_wan_if( &wan_iid, wan_type, (IFX_F_MODIFY | IFX_F_DONT_WRITE_TO_FLASH));

			    if(iRet != IFX_CWMP_SUCCESS)
                            {
				    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d]  ifx_set_default_wan_if failed\n", __func__ , __LINE__);
				    iRet = ERR_CWMP_INTERNAL;
				    pxSetParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
				    goto cleanup;
			    }								
			    //goto end of function	    
			    goto cleanup;
		    }
	    }else{

		    if(pxOI->iSubOper == OP_SETVAL_MODIFY){   // only store valued in config file

			    iRet = ifx_set_default_wan_if( &wan_iid, wan_type, (IFX_F_MODIFY | IFX_F_DONT_ACTIVATE | IFX_F_DONT_WRITE_TO_FLASH));

			    if(iRet == IFX_CWMP_SUCCESS){
				    iRet = IFX_CWMP_NEED_ACTIVATE;
			    }else{
				    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d]  ifx_set_default_wan_if failed\n", __func__ , __LINE__);
				    iRet = ERR_CWMP_INTERNAL;
				    goto cleanup;
			    }								
		    }else if(pxOI->iSubOper == OP_SETVAL_ACTIVATE){ // activate the values stored previously
			    iRet = ifx_set_default_wan_if( &wan_iid, wan_type, (IFX_F_MODIFY | IFX_F_DONT_WRITE_TO_FLASH));
			    if(iRet != IFX_CWMP_SUCCESS){
				    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d]  ifx_set_default_wan_if failed\n", __func__ , __LINE__);
				    iRet = IFX_CWMP_NEED_REBOOT_DONT_SAVE;
				    goto cleanup;
			    }		

			    //no reboot needed iRet = IFX_CWMP_NEED_REBOOT;
		    }

		    //goto end of function	    
		    goto cleanup;
	    } //end if-else
    } //end if


    for( iCntRoute = 0; iCntRoute<  iNumRoutes; iCntRoute++)
    {
	    // if cpe id is 0 then its a dynamic route and therfore ignore it
            if(pxAnyRouteEntry[iCntRoute].ROUTE.policy_route.iid.cpeId.Id == 0){
                  continue;
	    }
	    iRet = IFX_GetTr69IdFromCpeId((IFX_Id *)&(pxAnyRouteEntry[iCntRoute].ROUTE.policy_route.iid));
	    if(iRet != IFX_CWMP_SUCCESS){
		    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s] [%d] IFX_GetTr69IdFromCpeId failed \n", __func__ , __LINE__);
		    goto  cleanup;
	    }
	    iInstanceNo = IFIN_L3F_GetInstanceNo(pxAnyRouteEntry[iCntRoute].ROUTE.policy_route.iid.tr69Id, iParamOffset);

	    if( iInstanceNo == pxSetParamVal->iaOID[iParamOffset - 1]){
		    // struct found
		    iEntryFound = 1;

		    // fill the new struct with the values
		    xNewPRouteEntry = pxAnyRouteEntry[iCntRoute].ROUTE.policy_route;

		    xNewPRouteEntry.iid.config_owner = iCaller;

		//ORP: If SubOper is OP_SETVAL_CHK_DEL_ALLOWED then if the entry is enabled, then set activate state	
		    if(pxOI->iSubOper == OP_SETVAL_CHK_DEL_ALLOWED){
					if (xNewPRouteEntry.f_enable == ROUTE_STATUS_ENABLED)
					{
					    iRet = IFX_CWMP_NEED_ACTIVATE;
					}
					else
					{
					    iRet = IFX_CWMP_SUCCESS;
					}

					goto cleanup;
				}

		    //GET THE OLD ENABLE STATE
		     if(pxOI->iSubOper == OP_SETVAL_MODIFY){
			     iOldState =  xNewPRouteEntry.f_enable;
			     IFX_GetSetOldEnableVal( iInstanceNo, axOldRouteState, NULL,IFX_RESET_OLD_ENB_VAL); //reset
			     IFX_GetSetOldEnableVal( iInstanceNo, axOldRouteState, &iOldState,IFX_SET_OLD_ENB_VAL); //set 
			     iNewState = xNewPRouteEntry.f_enable; //take old val by default if ACS did not speficy it
			     //override iNewState below when analyzing parameters given in SetVal
		     }else if(pxOI->iSubOper == OP_SETVAL_ACTIVATE){
			     IFX_GetSetOldEnableVal( iInstanceNo, axOldRouteState, &iOldState,IFX_GET_OLD_ENB_VAL);  
			     iNewState = xNewPRouteEntry.f_enable; // read from rc.conf
		     }



		    // fill the given parameters of this structure with the new values provided
		    for( iCnt = 0; iCnt < iNumElem; iCnt++){

			    if(pxSetParamVal[iCnt].Value == NULL) //ignore the param if its value is null
				continue;

			    /* Process based on the requested parameter */
			    switch (pxSetParamVal[iCnt].iaOID[iParamOffset])
			    {

				    case OID_IGD_L3F_F_ENABLE:
					    if (atoi(pxSetParamVal[iCnt].Value) == 1) 
						    xNewPRouteEntry.f_enable = ROUTE_STATUS_ENABLED;
					    else if (atoi(pxSetParamVal[iCnt].Value) == 0) 
						    xNewPRouteEntry.f_enable = ROUTE_STATUS_DISABLED;

					    iNewState = xNewPRouteEntry.f_enable;

					    break;  

				    case OID_IGD_L3F_F_STATUS:
					    break;  

				    case OID_IGD_L3F_F_TYPE:
					    if(!strncasecmp(pxSetParamVal[iCnt].Value,"Default",7)){
						//    xNewPRouteEntry.type = ROUTE_TYPE_DEFAULT;
						IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s] [%d]Type=Default is invalid!! \n", __func__ , __LINE__);
						iRet = ERR_CWMP_INTERNAL;
						pxSetParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                                                goto cleanup;
					    }else if(!strncasecmp(pxSetParamVal[iCnt].Value,"Network",7)){
						    xNewPRouteEntry.type = ROUTE_TYPE_NET;
					    }else if(!strncasecmp(pxSetParamVal[iCnt].Value,"Host",4)){
						    xNewPRouteEntry.type = ROUTE_TYPE_HOST;
					    }
					    break;  

				    case OID_IGD_L3F_F_DESTIPADDRESS:
					    inet_aton(pxSetParamVal[iCnt].Value, &(xNewPRouteEntry.ip_dst.ip));
					    break;  

				    case OID_IGD_L3F_F_DESTSUBNETMASK:
					    inet_aton(pxSetParamVal[iCnt].Value, &(xNewPRouteEntry.ip_dst.mask));
					    break;  

				    case OID_IGD_L3F_F_SOURCEIPADDRESS:
					    inet_aton(pxSetParamVal[iCnt].Value, &(xNewPRouteEntry.ip_src.ip));
					    break;  

				    case OID_IGD_L3F_F_SOURCESUBNETMASK:
					    inet_aton(pxSetParamVal[iCnt].Value, &(xNewPRouteEntry.ip_src.mask));
					    break;  

				    case OID_IGD_L3F_F_GATEWAYIPADDRESS:
					    if(!strcmp(pxSetParamVal[iCnt].Value,""))
						break;

					    inet_aton(pxSetParamVal[iCnt].Value, &(xNewPRouteEntry.gw));
					    break;  

				    case OID_IGD_L3F_F_INTERFACE:
					    if(!strcmp(pxSetParamVal[iCnt].Value,""))
						break;

					    // convert the given interface to correct value and add to struct
					    memset(&xGetParam,0x00,sizeof(xGetParam));
//ORP: Instead of 7 chars, adding 8 chars more, since the interface value may not be terminated by dot. Will terminate with dot as per the requirement of the below code.
					    xGetParam.Name = IFX_CWMP_MALLOC(strlen(pxSetParamVal[iCnt].Value)+8); // obj + name + dots
					    if(xGetParam.Name == NULL){
						    iRet = IFX_CWMP_FAILURE;
						    goto cleanup;
					    }

						memset(caInterface,0,sizeof(caInterface));
					    strcpy(caInterface,pxSetParamVal[iCnt].Value);
					    if (caInterface[strlen(caInterface) -1]!='.')
					    {
            					strcat(caInterface, ".");
					    }

					    sprintf(xGetParam.Name,"%s%s",(char *)caInterface,"Name");

					    iRet = IFX_GlobalGetVal( &xGetParam, &paxGetParamVal, (uint32 *)&iElemOut);
					    if((iRet != IFX_CWMP_SUCCESS) || (paxGetParamVal == NULL)) {
						    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d]  IFX_GlobalGetVal failed\n", __func__ , __LINE__);
						    IFX_CWMP_FREE(xGetParam.Name);
						    if(paxGetParamVal != NULL){
							    IFX_CWMP_FREE(paxGetParamVal->Value);
							    IFX_CWMP_FREE(paxGetParamVal->Name);
						    }
						    IFX_CWMP_FREE(paxGetParamVal);
						    pxSetParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
						    goto cleanup;
					    }
                                            if(strstr(pxSetParamVal[iCnt].Value,"WANPPPConnection") != NULL)
                                            {
                                                wan_type = WAN_TYPE_PPP;
                                            } 
                                            else
                                            {
                                                wan_type = WAN_TYPE_IP;
                                            } 
					    iRet = ifx_get_wan_ifname_from_conf_connName(paxGetParamVal->Value, sIfName, wan_type );
					    if(iRet != IFX_CWMP_SUCCESS){
						    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d]  ifx_get_wan_ifname_from_conf_connName failed\n", __func__ , __LINE__);
						    IFX_CWMP_FREE(xGetParam.Name);
						    IFX_CWMP_FREE(paxGetParamVal->Value);
						    IFX_CWMP_FREE(paxGetParamVal->Name);
						    IFX_CWMP_FREE(paxGetParamVal);

						    iRet = ERR_CWMP_INTERNAL;
						    pxSetParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
						    goto cleanup;
					    }

					    strncpy(xNewPRouteEntry.route_if,sIfName,15);
					    IFX_CWMP_FREE(xGetParam.Name);
					    IFX_CWMP_FREE(paxGetParamVal->Value);
					    IFX_CWMP_FREE(paxGetParamVal->Name);
					    IFX_CWMP_FREE(paxGetParamVal);

					    break;  

				    case OID_IGD_L3F_F_FORWARDINGMETRIC:
					    xNewPRouteEntry.metric = atoi((char *)pxSetParamVal[iCnt].Value);
					    break;  

				    case OID_IGD_L3F_F_MTU:
					    xNewPRouteEntry.mtuSize = atoi((char *)pxSetParamVal[iCnt].Value);
					    break;  


				    default:
					    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
							    "[%s:%d] [Error] Unknown requested parameter\n",
							    __func__, __LINE__);
					    /* If we have to return a failure over here, this loop has to be
					       processed twice. Initially to find if any faulty parameter is
					       requested and then for actual assignment.
					    //iRet = IFX_CWMP_FAILURE; */

					    // parameter not found
					    pxSetParamVal[iCnt].iFaultCode = ERR_INVAL_PARAMETER_NAME;

					    goto cleanup;
			    }
		    } // nd for
	    } // end if 

	    if(iEntryFound == 1){
		    // call the API to modify
		    memcpy( &(xAnyRoute.ROUTE.policy_route), &xNewPRouteEntry, sizeof(xNewPRouteEntry));

		    if(iCaller == ACC_TR64 || iCaller == ACC_UPNP){

			    if(pxOI->iSubOper == OP_SETVAL_MODIFY){ // activate the values stored previously
//ORP: Setting flags properly

			    iFlags = IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH;
				    if((iOldState ==  ROUTE_STATUS_ENABLED)&&(iNewState == ROUTE_STATUS_DISABLED)){
					    iFlags = iFlags | IFX_F_DEACTIVATE;
				    }else if((iOldState ==  ROUTE_STATUS_ENABLED)&&(iNewState == ROUTE_STATUS_ENABLED)){
					    iFlags = iFlags;
				    }else if((iOldState == ROUTE_STATUS_DISABLED)&&(iNewState == ROUTE_STATUS_DISABLED)){
					    iFlags = iFlags | IFX_F_DONT_ACTIVATE | IFX_F_DONT_VALIDATE;
				    }else if((iOldState == ROUTE_STATUS_DISABLED)&&(iNewState == ROUTE_STATUS_ENABLED)){
					    iFlags = iFlags;
				    }

					    iSuccessReturn = IFX_CWMP_SUCCESS;
					    iFailureReturn = ERR_CWMP_INTERNAL;
			    iRet = ifx_set_route( IFX_OP_MOD, &xAnyRoute, iFlags);
			    if(iRet == IFX_CWMP_SUCCESS){
				    iRet = iSuccessReturn;
			    }else{
				    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] [Error] ifx_set_route failed\n",  __func__, __LINE__);
				    iRet = iFailureReturn;
				    goto cleanup;
			    }								

			    }
		    }else{

			    //Define the basic flag used by all
			    iFlags = IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH;
			
			    if(pxOI->iSubOper == OP_SETVAL_MODIFY){   // only store valued in config file

				    if(iOldState ==  ROUTE_STATUS_ENABLED){
					    iFlags = iFlags | IFX_F_DONT_ACTIVATE;
					    iSuccessReturn = IFX_CWMP_NEED_ACTIVATE;
					    iFailureReturn = ERR_CWMP_INTERNAL;
				    }else if((iOldState == ROUTE_STATUS_DISABLED)&&(iNewState == ROUTE_STATUS_DISABLED)){
					    iFlags = iFlags | IFX_F_DONT_ACTIVATE | IFX_F_DONT_VALIDATE;
					    iSuccessReturn = IFX_CWMP_SUCCESS;
					    iFailureReturn = ERR_CWMP_INTERNAL;
				    }else if((iOldState == ROUTE_STATUS_DISABLED)&&(iNewState == ROUTE_STATUS_ENABLED)){
					    iFlags = iFlags | IFX_F_DONT_ACTIVATE;
					    iSuccessReturn = IFX_CWMP_NEED_ACTIVATE;
					    iFailureReturn = ERR_CWMP_INTERNAL;
				    }

			    }else if(pxOI->iSubOper == OP_SETVAL_ACTIVATE){ // activate the values stored previously

				    if((iOldState ==  ROUTE_STATUS_ENABLED)&&(iNewState == ROUTE_STATUS_DISABLED)){
					    iFlags = iFlags | IFX_F_DEACTIVATE;
					    iSuccessReturn = IFX_CWMP_NEED_REBOOT;
					    iFailureReturn = IFX_CWMP_NEED_REBOOT_DONT_SAVE;
				    }else if((iOldState ==  ROUTE_STATUS_ENABLED)&&(iNewState == ROUTE_STATUS_ENABLED)){
					    iFlags = iFlags;
					    iSuccessReturn = IFX_CWMP_NEED_REBOOT;
					    iFailureReturn = IFX_CWMP_NEED_REBOOT_DONT_SAVE;
				    }else if((iOldState == ROUTE_STATUS_DISABLED)&&(iNewState == ROUTE_STATUS_DISABLED)){
					//This state is not possible
					    //iFlags = ;
					    iSuccessReturn = ERR_CWMP_INTERNAL;
					    iFailureReturn = ERR_CWMP_INTERNAL;
				    }else if((iOldState == ROUTE_STATUS_DISABLED)&&(iNewState == ROUTE_STATUS_ENABLED)){
					    iFlags = iFlags;
					    iSuccessReturn = IFX_CWMP_SUCCESS;
					    iFailureReturn = ERR_CWMP_INTERNAL;
				    }
			    }

			    iRet = ifx_set_route( IFX_OP_MOD, &xAnyRoute, iFlags);
			    if(iRet == IFX_CWMP_SUCCESS){
				    iRet = iSuccessReturn;
			    }else{
				    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] [Error] ifx_set_route failed\n",  __func__, __LINE__);
				    iRet = iFailureReturn;
				    goto cleanup;
			    }								
		    }

		    break;
	    }

    }

cleanup:

    /* Perform Cleanup of unnecessary DevInfo members */
//    IFIN_L3F_FreePrEntries(&pxPrEntries, iNumPolicyRoutes);
    IFIN_L3F_FreeRouteEntries(&pxAnyRouteEntry, 1); 	// the entire buffer is one, so freeing the first entry frees the entire buffer
    IFX_CWMP_FREE(pxCpeIdArray);
	if(iRet != IFX_CWMP_SUCCESS){
		// set the function return value tp ERR_CWMP_INVALID_ARGS
		if(iRet == ERR_CWMP_INTERNAL) // if iRet is still the default error 
			iRet = ERR_CWMP_INVAL_ARGS;
		// set the fault code for all the parameters
		//CHANGED BASED ON NIRINT's REQUEST
		//for(iCntErr = 0; iCntErr < iNumElem; iCntErr++){
		//	pxSetParamVal[iCntErr].iFaultCode = ERR_CWMP_INTERNAL;
		//}
	}

	return (iRet);

}



/* 
** =============================================================================
**   Function Name    : IFIN_Layer3Forwarding_UpdateChildInfo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

static int32 IFIN_Layer3Forwarding_UpdateChildInfo(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{
	uint32 i,iRet;
	char8 sSecTag[IFX_MAX_SECTION_TAG_LEN] = { 0 };
	char8 sParamTag[IFX_MAX_NAME_LEN] = { 0 };
	uint32 uiParamPos,uiChildObjId;
	uint32 uiCpeid;
	int32 *iaOID=NULL;
	uint32 uiNumNV=1;
	//IFX_CpeId pxCpeId;
	IFX_Id xIfx_Id;
	IFX_NameValue pxNVArray;
	uint32 uiOper=IFX_NOTIFY_OPER_MODIFY;
	ParamVal *pxTempParamVal=pxParamVal;

	memset(&pxNVArray, '\0', sizeof(IFX_NameValue));
	
		//Get Cpeid
		iRet = IFX_GetCpeId(pxTempParamVal->iaOID, &uiCpeid);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;

		//Get the child object Oid
		uiChildObjId = IFX_GetParamIdPos((int32 *)pxTempParamVal->pReserved);
		iaOID = (int32 *)pxTempParamVal->pReserved;

		for(i=0; i < iElements; i++)

		{
			//Get the Param Oid of this object
			uiParamPos= IFX_GetParamIdPos(pxTempParamVal->iaOID);
			
			if(pxTempParamVal->iaOID[uiParamPos] == OID_IGD_L3F_FORWARDNUMBEROFENTRIES)
				 {
					if(iaOID[uiChildObjId-1] ==	OID_IGD_L3F_F)
					{
						//Get the section and Paramtag
						iRet=IFX_GetSectionParamTag(pxTempParamVal->psRCTag, sParamTag, sSecTag);
						if(iRet != IFX_CWMP_SUCCESS)
							goto errorHandler;
						
						xIfx_Id.uiConfigOwner= pxOpInfo->iCaller;
						xIfx_Id.xCpeId.uiId= uiCpeid;
						strncpy(xIfx_Id.xCpeId.sSectionTag,sSecTag, IFX_MAX_SECTION_TAG_LEN-1);
						xIfx_Id.xCpeId.sSectionTag[IFX_MAX_SECTION_TAG_LEN-1]='\0';
						strncpy(pxNVArray.sName,sParamTag, IFX_MAX_NAME_LEN-1);
						pxNVArray.sName[IFX_MAX_NAME_LEN-1]='\0';
												
						iRet=IFX_SendNotify(&xIfx_Id, uiNumNV, 
												&pxNVArray, uiOper);
						if(iRet != IFX_CWMP_SUCCESS)
						{
							IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 			"%s:%d IFX_SendNotify failed!\n", __func__, __LINE__);
							
							goto errorHandler;
						}
					}
				}

			pxTempParamVal++;
			
		}
					
		return IFX_CWMP_SUCCESS;

		errorHandler:
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
			
			return IFX_CWMP_FAILURE;
			
}






/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/



/* 
** =============================================================================
**   Function Name    : IFIN_Layer3Forwarding_Init
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFIN_Layer3Forwawrding_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* TBD: Perform any LAYER3FORWARDING Module related initializations here */

    /* Register the LAYER3FORWARDING module function pointer in the object model */
    iRet += ifx_ds_register_function(IFIN_LAYER3FORWARDING_OBJ, IFIN_Layer3Forwarding);
    iRet += ifx_ds_register_function(IFIN_FORWARDING_OBJ, IFIN_Layer3Forwarding);


    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [Error] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, IFIN_LAYER3FORWARDING_OBJ);
        goto cleanup;
    }

cleanup:

	
    return iRet;
}


/*********************************************************************************
*  Function Name	:  IFIN_Layer3Forwarding   
      *  Description	:  This function handles all the sub-states inside
      	 		   a GET/SET operation.If it is a GET it allocates the 
			   array(Name,Value pairs) and retruns the values.
			   If it is a SET controller allocates the array and
			   passes the values to this function.It calls 
			   respective internal functions which in turn calls 
			   respective Platform APIs.
                                                                                                 
*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
							     Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has 
					  	             Name,Value,etc
                    IN          int32	       iElements;    No. of Elements
		    OUT	        void *	       ppParamRet;   same as ParamStruc
		    OUT         int32 *        piNumRetElem; No. of elements 		                                
*  Return Value        : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes               :
***********************************************************************************/
int32
IFIN_Layer3Forwarding(IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
             OUT void **ppRet, OUT int32 *piNumRetElem)
{
    int32       iRet           = IFX_CWMP_SUCCESS;
    ParamVal *pxGetParamVal = (ParamVal *)pParamList;
    ParamVal    *pxSetParamVal = (ParamVal *)pParamList;
    ParamVal *pxParamVal = (ParamVal *)pParamList;

    /* Process based on type of Operation */
	switch (pxOI->iOper)
	{
		case OP_GETVAL:
		{
        	/* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:
                    /* Set attribute values for all the requested parameters */
                    iRet = GetNotify(pxOI, pxGetParamVal, iNumElem);
		     
                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }
					break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [Error] Requested SubOperation not "
                                "permitted on Objects handled by DeviceInfo "
                                "Module\n", __func__, __LINE__);
                    iRet = IFX_CWMP_FAILURE;
                    goto cleanup;
            }
            break;
        }
        case OP_SETVAL:
        {
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:

                    /* Validate values of all the requested parameters */
                    iRet = IFIN_Layer3Forwarding_Validate(pxSetParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }
                    break;

				case OP_SETVAL_CHK_DEL_DEP:
					*ppRet = (ParamVal *)IFX_CWMP_MALLOC(sizeof(ParamVal));
					if(*ppRet == NULL)
                    {
						iRet = IFX_CWMP_FAILURE;
						goto cleanup;
					}

					memcpy(*ppRet, pParamList, sizeof(ParamVal));
					*piNumRetElem = 1;
					break;
			   
                case OP_SETVAL_MODIFY:
				case OP_SETVAL_ACTIVATE:

                    /* Set values of all the requested parameters */
                    iRet = IFIN_Layer3Forwarding_Modify(pxOI, pxSetParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }
                    break;

				  case OP_SETVAL_ADD:
					// 1 = add 0=del
					iRet = IFIN_Layer3Forwarding_AddDel(pxOI->iCaller, pxSetParamVal, iNumElem, OP_SETVAL_ADD);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }
				  	break;

        	        case OP_SETVAL_CHK_MODIFY_DEP:
						// return list of objects dependent on this module
						iRet = IFX_CWMP_SUCCESS;
						break;

				  case OP_SETVAL_CHK_DEL_ALLOWED :
					// chk dependency , defaults (as in default entry) and accesscontrol.
					// nothing to be done in dependency and defaults
					// accesscontrol : if owner is web then get cpeid and section tag from tr69 id
					// from the rctag, extract param tags and then form an array of param tags and 
					// pass on to CHKACL protocol api.
					// if allowed then return success otherwise failure.
					if(pxOI->iCaller == ACC_TR69)
					{
						//ORP: Setting IFX_CWMP_NEED_ACTIVATE only in case of enabled route
	          			return IFIN_Layer3Forwarding_Modify(pxOI, pxSetParamVal, iNumElem);
					}
					else if(pxOI->iCaller == ACC_WEB)
					{
					}
					break;
				case OP_SETVAL_DELETE:
					iRet = IFIN_Layer3Forwarding_AddDel(pxOI->iCaller, pxSetParamVal, iNumElem, OP_SETVAL_DELETE);
					// 0 = delete
					break;
                case OP_SETVAL_ATTRINFO:

                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
				case OP_SETVAL_FREE :
					iRet = IFX_CWMP_SUCCESS;
					break;
			
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [Error] Requested SubOperation not"
                                " permitted on Objects handled by DeviceInfo"
                                "Module\n", __func__, __LINE__);
                    iRet = IFX_CWMP_FAILURE;
                    goto cleanup;
            }
            break;
		}

		case OP_UPDATE_CHILDINFO:
		{
			//Updation of child related info is handled by the case
			switch(pxOI->iSubOper)
			{
				case OP_UPDATE_CHILDINFO_ADD:
				case OP_UPDATE_CHILDINFO_DEL:
                {
					if((iRet =IFIN_Layer3Forwarding_UpdateChildInfo(pxOI,pxParamVal,iNumElem)) != IFX_CWMP_SUCCESS)
					{
						switch(pxOI->iSubOper)
						{	
							case OP_UPDATE_CHILDINFO_ADD:
								IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
										"%s:%d OP_UPDATE_CHILDINFO_ADD failed!\n", __func__, __LINE__);
								goto cleanup;

							case OP_UPDATE_CHILDINFO_DEL:
								IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
										"%s:%d OP_UPDATE_CHILDINFO_DEL failed!\n", __func__, __LINE__);
								goto cleanup;

						}
                    }
                    break;
					}
			}
			break;
		}
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [Error] Operation not permitted on Objects "
                        "handled by DeviceInfo Module\n", __func__, __LINE__);
            iRet = IFX_CWMP_FAILURE;
            goto cleanup;
        }
    }

cleanup:
    return iRet;
}




