/* 
** =============================================================================
**   FILE NAME        : IFX_DHCPCondServ.c
**   PROJECT          : TR69
**   MODULES          : DHCPCondServ Profile
**   DATE             : 05-02-2009
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This is the DHCP Conditional serving Module. 
**						It is required by the controller module of TR69 
**						stack to GET/SET/ADD/DELETE DHCPCondServ obj specific info.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2009
**                      Infineon Technologies AG
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author                         $Comment
**   05-02-2009       TR69 team                       Initial Version
**
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_DHCPCondServ.h"
  // Required for STATIC
 
#include "IFX_DEVM_OID.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_DS.h"

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFX_DHCPCONDSERV_OBJ    FORMNAME("LANDevice.1.LANHostConfigManagement.DHCPConditionalServingPool.")
#define IFX_DHCP_COND_SERV_POOL_NO_OF_DEP_OIDS  0

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/
STATIC int32
GetVal(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
       IN int32 iElements);
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
AddObj(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32 
IFX_ConvertArrToDHCPPoolStruct(IN uint32 iElements, IN ParamVal *paxParamVal, OUT IFX_DHCP_COND_SERV_POOL *pxDHCPCondSrvPool);
/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/


/* This function searches from the list of pool for a specific pool with iCpeid
 *as the CPE id. Therefore, you need to input the pool list as well as the 
 * CPE id of the pool you want to get as a return value.
 **/ 

int32 
GetDHCPPoolInst(INOUT IFX_DHCP_COND_SERV_POOL **ppxDHCPCondSrvPool, IN uint32 iCpeid, OUT int32 *iNumEntries)
{

    IFX_DHCP_COND_SERV_POOL *paxDHCPPool = NULL;
    IFX_DHCP_COND_SERV_POOL *pxMatchDHCPPool = NULL;
    IFX_DHCP_COND_SERV_POOL *pxTmpDHCPPool = NULL;
    int32 uiNumOfEntries = 0;
    uint32 iFlags, iI = 0;
    uint32 iGotValue = 0;
    int32 iRet = 0;

    pxMatchDHCPPool=IFX_CWMP_MALLOC(sizeof(IFX_DHCP_COND_SERV_POOL));
    if(pxMatchDHCPPool == NULL){
        iRet = ERR_OUT_OF_MEMORY; 
        goto errorHandler;
    }
    iFlags = IFX_F_GET_ANY;


    iRet=ifx_get_all_dhcp_conditional_entries(&uiNumOfEntries, &paxDHCPPool, iFlags);

    *iNumEntries = uiNumOfEntries;

    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_get_all_dhcp_conditional_entries returned failure\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto errorHandler;
    }
    pxTmpDHCPPool = paxDHCPPool;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "NoOfEntries=%d !\n",uiNumOfEntries);

    for(iI = 0; iI < uiNumOfEntries; iI++)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "API_Cpeid=%d !\n",pxTmpDHCPPool->iid.cpeId.Id);
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "Module_Cpeid=%d !\n",iCpeid);

        if(pxTmpDHCPPool != NULL)
        {
            if(pxTmpDHCPPool->iid.cpeId.Id== iCpeid)
            {
                //Memcopy the struct
                iGotValue = 1;
                memcpy(pxMatchDHCPPool, pxTmpDHCPPool, sizeof(IFX_DHCP_COND_SERV_POOL));
                *ppxDHCPCondSrvPool = pxMatchDHCPPool;
                break;
            }
            pxTmpDHCPPool += 1;
        }

    }

    if(iGotValue == 1)
    {

        IFX_CWMP_FREE(paxDHCPPool);
        return IFX_CWMP_SUCCESS;
    } 

    errorHandler:

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%s:%d] failed!\n",__FILE__, __func__, __LINE__);

    IFX_CWMP_FREE(paxDHCPPool);
    IFX_CWMP_FREE(pxMatchDHCPPool);

    return IFX_CWMP_FAILURE;
}



/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetVal(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
       IN int32 iElements)
{
    int32   iRet  = IFX_CWMP_SUCCESS;
    uint32 iCpeid = 0;
    int32   iCnt  = 0;
    IFX_DHCP_COND_SERV_POOL *pxDHCPCondSrvPool=NULL;
    int32   iParamOffset;
    int32 iNumEntries = 0;

    // Get Cpeid from object ID
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
        goto cleanup;

    // Get match object from system using Platform API
    iRet= GetDHCPPoolInst(&pxDHCPCondSrvPool, iCpeid, &iNumEntries);
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get %s instance with CPEID %d\n",
                    __FILE__,  __func__, __LINE__, iRet, IFX_DHCPCONDSERV_OBJ, iCpeid);
        goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamIdPos(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(MAX_DHCPPOOL_VALUE_LEN);

        /* Check for error */
        if (!((pxParamVal[iCnt]).Value))
        {
            iRet = ERR_OUT_OF_MEMORY;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Allocation Failure\n",
                         __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_LAND_LANHCM_DHCPCSP_ENABLE:

                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", pxDHCPCondSrvPool->Enable);
                break;  
            case OID_IGD_LAND_LANHCM_DHCPCSP_POOLORDER:

                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", pxDHCPCondSrvPool->PoolOrder);
                break;  
            case OID_IGD_LAND_LANHCM_DHCPCSP_SOURCEINTERFACE:

                /* Copy the value to allocated area */
                if(!strcmp( pxDHCPCondSrvPool->SourceInterface, "eth0")){
                    if((pxOI->iCaller != ACC_TR64) && (pxOI->iCaller != ACC_UPNP))
                        strcpy(pxParamVal[iCnt].Value,"InternetGatewayDevice.LANDevice.1.LANEthernetInterfaceConfig.1");
                    else 
                        strcpy(pxParamVal[iCnt].Value,"InternetGatewayDevice.LANDevice.1.LANEthernetInterfaceConfig.1.");

                }else if(!strcmp( pxDHCPCondSrvPool->SourceInterface, "usb0")){
                    if((pxOI->iCaller != ACC_TR64) && (pxOI->iCaller != ACC_UPNP))
                        strcpy(pxParamVal[iCnt].Value,"InternetGatewayDevice.LANDevice.1.LANUSBInterfaceConfig.1");
                    else 
                        strcpy(pxParamVal[iCnt].Value,"InternetGatewayDevice.LANDevice.1.LANUSBInterfaceConfig.1.");

                }else if(!strcmp( pxDHCPCondSrvPool->SourceInterface, "wlan0")){
                    if((pxOI->iCaller != ACC_TR64) && (pxOI->iCaller != ACC_UPNP))
                        strcpy(pxParamVal[iCnt].Value,"InternetGatewayDevice.LANDevice.1.WLANConfiguration.1");
                    else 
                        strcpy(pxParamVal[iCnt].Value,"InternetGatewayDevice.LANDevice.1.WLANConfiguration.1.");
                }


                break;
  
            case OID_IGD_LAND_LANHCM_DHCPCSP_VENDORCLASSID:

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, pxDHCPCondSrvPool->VendorClassID); 
                break;  

            case OID_IGD_LAND_LANHCM_DHCPCSP_CLIENTID:

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, pxDHCPCondSrvPool->ClientID); 
                break;  

           case OID_IGD_LAND_LANHCM_DHCPCSP_USERCLASSID:

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, pxDHCPCondSrvPool->UserClassID); 
                break;  

            case OID_IGD_LAND_LANHCM_DHCPCSP_CHADDR:

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, pxDHCPCondSrvPool->Chaddr); 
                break;  


            case OID_IGD_LAND_LANHCM_DHCPCSP_CHADDRMASK:

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, pxDHCPCondSrvPool->ChaddrMask); 
                break;  

            case OID_IGD_LAND_LANHCM_DHCPCSP_LOCALLYSERVED:

                /* Copy the value to allocated area */
                sprintf((pxParamVal[iCnt]).Value, "%d", pxDHCPCondSrvPool->LocallyServed); 
                break;  

            case OID_IGD_LAND_LANHCM_DHCPCSP_MINADDRESS:

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, pxDHCPCondSrvPool->MinAddress); 
                break;  


            case OID_IGD_LAND_LANHCM_DHCPCSP_MAXADDRESS:

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, pxDHCPCondSrvPool->MaxAddress); 
                break;  

            case OID_IGD_LAND_LANHCM_DHCPCSP_RESERVEDADDRESSES:

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, pxDHCPCondSrvPool->ReservedAddresses); 
                break;  

            case OID_IGD_LAND_LANHCM_DHCPCSP_SUBNETMASK:

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, pxDHCPCondSrvPool->SubnetMask); 
                break;  


            case OID_IGD_LAND_LANHCM_DHCPCSP_DNSSERVERS:

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, pxDHCPCondSrvPool->DNSServers); 
                break;  

            case OID_IGD_LAND_LANHCM_DHCPCSP_DOMAINNAME:

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, pxDHCPCondSrvPool->DomainName); 
                break;  

            case OID_IGD_LAND_LANHCM_DHCPCSP_IPROUTERS:

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, pxDHCPCondSrvPool->IPRouters); 
                break;  


            case OID_IGD_LAND_LANHCM_DHCPCSP_DHCPLEASETIME:

                /* Copy the value to allocated area */
                sprintf((pxParamVal[iCnt]).Value, "%d", pxDHCPCondSrvPool->DHCPLeaseTime); 
                break;  

            case OID_IGD_LAND_LANHCM_DHCPCSP_DHCPSERVERIPADDRESS:

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, pxDHCPCondSrvPool->DHCPServerIPAddress); 
                break;  


            default:
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
                goto cleanup;
        }
    }

cleanup:
    IFX_CWMP_FREE(pxDHCPCondSrvPool);
    return (iRet);
}


/* 
** =============================================================================
**   Function Name    : Modify
**
**   Description      : This function modifies the values of parameters in 
**                      DHCPConditionalServingPool object. It calls Management API  
**                      for the same. It performs modification only if parameter 
**                      has Write permission. In certain cases it also performs 
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32       iRet       = IFX_CWMP_SUCCESS;
    int32       iRtn       = IFX_SUCCESS;
    uint32      iCpeid     = 0;
    int32       iCnt       = 0;
    IFX_DHCP_COND_SERV_POOL *pxDHCPCondSrvPool = NULL; /* Mandatory */
    int32       iParamOffset;
    char8       *psTmpVal = NULL;
    uint32      uiFlags;
    int32 iNumEntries = 0;

    // Get Cpeid from object ID
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
        goto cleanup;

    // Get match object from system using Platform API
    iRet= GetDHCPPoolInst(&pxDHCPCondSrvPool, iCpeid, &iNumEntries);
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get %s instance with CPEID %d\n",
                    __FILE__,  __func__, __LINE__, iRet, IFX_DHCPCONDSERV_OBJ, iCpeid);
        goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamIdPos(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_LAND_LANHCM_DHCPCSP_ENABLE:

                if (!strcmp(psTmpVal, "1"))
                    pxDHCPCondSrvPool->Enable = 1;
                else
                    pxDHCPCondSrvPool->Enable = 0;
                
                break;

            case OID_IGD_LAND_LANHCM_DHCPCSP_POOLORDER:

                if(atoi(psTmpVal) > iNumEntries )
                    pxDHCPCondSrvPool->PoolOrder = iNumEntries;
                else
                    pxDHCPCondSrvPool->PoolOrder = atoi(psTmpVal);
                break;  

            case OID_IGD_LAND_LANHCM_DHCPCSP_SOURCEINTERFACE:

		if( !strcmp(psTmpVal, "InternetGatewayDevice.LANDevice.1.LANEthernetInterfaceConfig.1"))
		{
			strcpy(pxDHCPCondSrvPool->SourceInterface, "eth0");
		}else if( !strcmp(psTmpVal, "InternetGatewayDevice.LANDevice.1.LANUSBInterfaceConfig.1"))
		{
			strcpy(pxDHCPCondSrvPool->SourceInterface, "usb0");
		}else if( !strcmp(psTmpVal, "InternetGatewayDevice.LANDevice.1.WLANConfiguration.1"))
		{
			strcpy(pxDHCPCondSrvPool->SourceInterface, "wlan0");

		}else{
			(pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
			iRet = ERR_CWMP_INVAL_ARGS;
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					"[%s:%s:%d] Unrecognized or unsupported source interface "
					"source interface",__FILE__, __func__, __LINE__);
			goto cleanup;
		}
		break;  


            case OID_IGD_LAND_LANHCM_DHCPCSP_VENDORCLASSID:

                /* Check if the string fits in the buffer */
                if ((strlen(psTmpVal) + 1) > IFX_MAX_DHCP_ID_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }
                /* Copy the string */
                strcpy(pxDHCPCondSrvPool->VendorClassID, psTmpVal);

                break;  

            case OID_IGD_LAND_LANHCM_DHCPCSP_CLIENTID:

                /* Check if the string fits in the buffer */
                if ((strlen(psTmpVal) + 1) > IFX_MAX_DHCP_ID_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }
                /* Copy the string */
                strcpy(pxDHCPCondSrvPool->ClientID, psTmpVal);

                break;  

            case OID_IGD_LAND_LANHCM_DHCPCSP_USERCLASSID:

                /* Check if the string fits in the buffer */
                if ((strlen(psTmpVal) + 1) > IFX_MAX_DHCP_ID_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }
                /* Copy the string */
                strcpy(pxDHCPCondSrvPool->UserClassID, psTmpVal);

                break;  

            case OID_IGD_LAND_LANHCM_DHCPCSP_CHADDR:

                /* Check if the string fits in the buffer */
                if ((strlen(psTmpVal) + 1) > MAX_MAC_ADDR_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }
                /* Copy the string */
                strcpy(pxDHCPCondSrvPool->Chaddr, psTmpVal);

                break;  


            case OID_IGD_LAND_LANHCM_DHCPCSP_CHADDRMASK:

                /* Check if the string fits in the buffer */
                if ((strlen(psTmpVal) + 1) > MAX_MAC_ADDR_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }
                /* Copy the string */
                strcpy(pxDHCPCondSrvPool->ChaddrMask,psTmpVal);

                break;  

            case OID_IGD_LAND_LANHCM_DHCPCSP_LOCALLYSERVED:

                if (!strcmp(psTmpVal, "1"))
                    pxDHCPCondSrvPool->LocallyServed = 1;
                else
                    pxDHCPCondSrvPool->LocallyServed = 0;
                
                break;

            case OID_IGD_LAND_LANHCM_DHCPCSP_MINADDRESS:

                /* Check if the string fits in the buffer */
                if ((strlen(psTmpVal) + 1) > MAX_IP_ADDR_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }
                /* Copy the string */
                strcpy(pxDHCPCondSrvPool->MinAddress, psTmpVal);

                break;  


            case OID_IGD_LAND_LANHCM_DHCPCSP_MAXADDRESS:

                /* Check if the string fits in the buffer */
                if ((strlen(psTmpVal) + 1) > MAX_IP_ADDR_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }
                /* Copy the string */
                strcpy(pxDHCPCondSrvPool->MaxAddress, psTmpVal);

                break;  


            case OID_IGD_LAND_LANHCM_DHCPCSP_RESERVEDADDRESSES:

                /* Check if the string fits in the buffer */
                if ((strlen(psTmpVal) + 1) > (IFX_MAX_RESERVED_ADDR * MAX_IP_ADDR_LEN))
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }
                /* Copy the string */
                strcpy(pxDHCPCondSrvPool->ReservedAddresses, psTmpVal);

                break;  

            case OID_IGD_LAND_LANHCM_DHCPCSP_SUBNETMASK:

                /* Check if the string fits in the buffer */
                if ((strlen(psTmpVal) + 1) > MAX_IP_ADDR_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }
                /* Copy the string */
                strcpy(pxDHCPCondSrvPool->SubnetMask, psTmpVal);

                break;  

            case OID_IGD_LAND_LANHCM_DHCPCSP_DNSSERVERS:

                /* Check if the string fits in the buffer */
                if ((strlen(psTmpVal) + 1) > (MAX_IP_ADDR_LEN *  MAX_DNS_SERVERS))
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }
                /* Copy the string */
                strcpy(pxDHCPCondSrvPool->DNSServers, psTmpVal);

                break;  

            case OID_IGD_LAND_LANHCM_DHCPCSP_DOMAINNAME:

                /* Check if the string fits in the buffer */
                if ((strlen(psTmpVal) + 1) > MAX_DOMAIN_NAME_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }
                /* Copy the string */
                strcpy(pxDHCPCondSrvPool->DomainName, psTmpVal);

                break;  

            case OID_IGD_LAND_LANHCM_DHCPCSP_IPROUTERS:

                /* Check if the string fits in the buffer */
                if ((strlen(psTmpVal) + 1) > 64)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }
                /* Copy the string */
                strcpy(pxDHCPCondSrvPool->IPRouters, psTmpVal);

                break;  


            case OID_IGD_LAND_LANHCM_DHCPCSP_DHCPLEASETIME:

                pxDHCPCondSrvPool->DHCPLeaseTime = atoi(psTmpVal);
                break;  

            case OID_IGD_LAND_LANHCM_DHCPCSP_DHCPSERVERIPADDRESS:

                /* Check if the string fits in the buffer */
                if ((strlen(psTmpVal) + 1) > MAX_IP_ADDR_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }
                /* Copy the string */
                strcpy(pxDHCPCondSrvPool->DHCPServerIPAddress, psTmpVal);

                break;  


            default:

                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

    /* Fill the iid structure in the pool struct */
    pxDHCPCondSrvPool->iid.config_owner = iCaller;

    /* Set all the IFX_DHCP_COND_SERV_POOL parameters using Object API */
    uiFlags = IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH;
    if (pxDHCPCondSrvPool->Enable == 0)
    uiFlags |= IFX_F_DONT_ACTIVATE | IFX_F_DONT_VALIDATE; 
    iRtn = ifx_set_dhcp_conditional_entry(IFX_OP_MOD, pxDHCPCondSrvPool, uiFlags);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to set values of all "
                    "parameters\n", __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    IFX_CWMP_FREE(pxDHCPCondSrvPool);
    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : Validate
**
**   Description      : This function validates the values of parameters in
**                      DeviceInfo object.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      validated.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When validation of all parameters is
**                      successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in validating at least one parameter.
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iCnt, iTmp;
    int32   iParamOffset;
    char8   *psTmpVal = NULL;

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamIdPos(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        goto cleanup;
    }

    /* Iterate and validate the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Return a failure if the value is NULL pointer */
        if (!psTmpVal)
        {
            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
            iRet = ERR_CWMP_INVAL_ARGS;
            goto cleanup;
        }
 
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_LAND_LANHCM_DHCPCSP_ENABLE:
            case OID_IGD_LAND_LANHCM_DHCPCSP_LOCALLYSERVED:

                    if(!(!strcmp(psTmpVal, "1") || !strcmp(psTmpVal, "0")))
                    {
                        (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        iRet = ERR_CWMP_INVAL_ARGS;
                    }
                    break;

            case OID_IGD_LAND_LANHCM_DHCPCSP_POOLORDER:
                
                    /* This is temporary validation that works assuming the value being passed is integer */
                    iTmp = atoi(psTmpVal);
                    if (iTmp < 1)
                    {
                        (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        iRet = ERR_CWMP_INVAL_ARGS;
                    }
                    break; 
                
            case OID_IGD_LAND_LANHCM_DHCPCSP_DHCPLEASETIME:

                    /* This is temporary validation that works assuming the value being passed is integer */
                    iTmp = atoi(psTmpVal);
                    if (iTmp < -1)
                    {
                        (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        iRet = ERR_CWMP_INVAL_ARGS;
                    }
                    break;


            case OID_IGD_LAND_LANHCM_DHCPCSP_SOURCEINTERFACE:
            case OID_IGD_LAND_LANHCM_DHCPCSP_VENDORCLASSID:
            case OID_IGD_LAND_LANHCM_DHCPCSP_CLIENTID:
            case OID_IGD_LAND_LANHCM_DHCPCSP_USERCLASSID:
            case OID_IGD_LAND_LANHCM_DHCPCSP_CHADDR:
            case OID_IGD_LAND_LANHCM_DHCPCSP_CHADDRMASK:
            case OID_IGD_LAND_LANHCM_DHCPCSP_MINADDRESS:
            case OID_IGD_LAND_LANHCM_DHCPCSP_MAXADDRESS:
            case OID_IGD_LAND_LANHCM_DHCPCSP_RESERVEDADDRESSES:
            case OID_IGD_LAND_LANHCM_DHCPCSP_SUBNETMASK:
            case OID_IGD_LAND_LANHCM_DHCPCSP_DNSSERVERS:
            case OID_IGD_LAND_LANHCM_DHCPCSP_DOMAINNAME:
            case OID_IGD_LAND_LANHCM_DHCPCSP_IPROUTERS:
            case OID_IGD_LAND_LANHCM_DHCPCSP_DHCPSERVERIPADDRESS:
 
                break;

            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

cleanup:
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Validating requested parameter failed\n",
                    __FILE__, __func__, __LINE__, iRet);
    }
    return (iRet);
}


STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iCnt;

    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Update Attribute Information */
    iRet = IFX_SetAttributesInfo(NULL, pxParamVal, iElements);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Updating Param Attribute Info failed\n",
                    __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    return (iRet);
}

STATIC int32
AddObj(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal, IN int32 iElements)
{
	/* This API calls a Platform API which adds the object
	** in ADD_DISABLE state.
	** Pass necessary flags to the API
	** Controller should get the next instance id from DS 
   	** module and pass the full OID to this module.
	*/
	uint32 iFlags=0;
	int32 iRet=0;
	uint32 iOper;
	uint32 uiOutElem=0;
	uint32 uiPcpeId=0;
	IFX_DHCP_COND_SERV_POOL xDHCPPool;
	//ParamVal xWan_IpCon;
	ParamVal *paxOutParamArr=NULL;
	memset(&xDHCPPool, 0, sizeof(xDHCPPool));

	//If owner is WEB don't add the object just return success.

	iRet = IFX_GetParentObjCpeId(pxParamVal->iaOID,&uiPcpeId);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	iRet = IFX_ConvertArrToDHCPPoolStruct(iElements, pxParamVal, &xDHCPPool);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	//Flags should be filled
	//Fills the Cpeid,ParentCepid,TR69Id,Owner
	//Fill the operation

	iOper = IFX_OP_ADD;
	iFlags =(	IFX_F_DONT_ACTIVATE|IFX_F_DONT_CHECKPOINT|
			IFX_F_DONT_VALIDATE|IFX_F_DONT_WRITE_TO_FLASH);

	xDHCPPool.iid.config_owner=pxOpInfo->iCaller;
	xDHCPPool.iid.cpeId.Id=0;
	xDHCPPool.iid.pcpeId.Id=uiPcpeId;
	xDHCPPool.Enable = IFX_DISABLED;

	//Convert array into dotted form and then strcpy

	iRet = IFX_ConvertOidDottedForm(pxParamVal->iaOID, xDHCPPool.iid.tr69Id);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	iRet = ifx_set_dhcp_conditional_entry(iOper, &xDHCPPool, iFlags);

	if(iRet != IFX_SUCCESS)
	{
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"ifx_set_dhcp_conditional_entry AddObj Mgmt API"					                          " returned error\n");
		goto errorHandler;
		
	}	
	iRet = IFX_FreeParamvalArr(&paxOutParamArr,uiOutElem);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	return IFIN_CWMP_SUCCESS;

	errorHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d failed!\n", __func__, __LINE__);
		
		iRet = IFX_FreeParamvalArr(&paxOutParamArr,uiOutElem);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;
		return IFIN_CWMP_FAILURE;

}

STATIC int32 
IFX_ConvertArrToDHCPPoolStruct(IN uint32 iElements, IN ParamVal *paxParamVal, OUT IFX_DHCP_COND_SERV_POOL *pxDHCPCondSrvPool)
{
	uint32 i=0;
	//uchar8 usDestAddr[MAX_NAME_LEN];
	uint32 uiParamPos=0;
    	int32 uiNumOfEntries = 0;
    	uint32 iFlags= 0;
	int32 iRet = 0;
    	IFX_DHCP_COND_SERV_POOL *paxDHCPPool = NULL;

    	iFlags = IFX_F_GET_ANY;
    	iRet=ifx_get_all_dhcp_conditional_entries(&uiNumOfEntries, &paxDHCPPool, iFlags);

	if(iRet != IFX_SUCCESS)
	{
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
				"[%s:%s:%d] [%d] ifx_get_all_dhcp_conditional_entries returned failure\n",
				__FILE__,  __func__, __LINE__, iRet);
		goto errorHandler;
	}


	uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);

	for (i=0; i < iElements; i++) 
	{

		switch(paxParamVal->iaOID[uiParamPos])
		{

			case OID_IGD_LAND_LANHCM_DHCPCSP_ENABLE:
				pxDHCPCondSrvPool->Enable = 0;
				break;

			case OID_IGD_LAND_LANHCM_DHCPCSP_POOLORDER:
				pxDHCPCondSrvPool->PoolOrder = uiNumOfEntries + 1;
				break;

			case OID_IGD_LAND_LANHCM_DHCPCSP_LOCALLYSERVED:
				pxDHCPCondSrvPool->LocallyServed = 1;
				break;

			case OID_IGD_LAND_LANHCM_DHCPCSP_DHCPLEASETIME:
				pxDHCPCondSrvPool->DHCPLeaseTime = -1; //indefinite lease
				break;

			default:
				break;
		}
		++paxParamVal;
	}


errorHandler:
        IFX_CWMP_FREE(paxDHCPPool);


	if(iRet != IFIN_CWMP_SUCCESS)
		return IFIN_CWMP_FAILURE;
	else
		return IFIN_CWMP_SUCCESS;

}


STATIC int32
SetDelete(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
          IN int32 iElements, OUT void **ppxParamStructRet,
          OUT int32 * piNumRetElem)
{

    uint32 uiCpeid=0;
    IFX_DHCP_COND_SERV_POOL *pxMatch_DHCPPool=NULL;
    int32 iRet=0;
    uint32 iOper=0,iFlags=0;
    int32 iNumEntries = 0;

    // handle CHK_DELETE_DEP
    if(pxOpInfo->iSubOper == OP_SETVAL_CHK_DEL_DEP)
    {
        return IFIN_CWMP_SUCCESS;
    }

    if(pxOpInfo->iSubOper == OP_SETVAL_CHK_DEL_ALLOWED)
    {
        return IFIN_CWMP_SUCCESS;
    }

    //Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(paxParamVal->iaOID,&uiCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Get match object from system using Platform API
    iRet= GetDHCPPoolInst(&pxMatch_DHCPPool, uiCpeid, &iNumEntries);  
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get %s instance with CPEID %d\n",
                    __FILE__,  __func__, __LINE__, iRet, IFX_DHCPCONDSERV_OBJ, uiCpeid);
        goto errorHandler;
    }

    switch(pxOpInfo->iSubOper)
    {
        case OP_SETVAL_DELETE:
            //handle DELETE operation
            //Call Platform API to delete the obj in the system
            //If del is called by web we need to pass special owner for which API 
            //will not post a message.
            
            pxMatch_DHCPPool->iid.config_owner=pxOpInfo->iCaller;
            pxMatch_DHCPPool->iid.cpeId.Id=uiCpeid;
            //pxMatch_DHCPPool.iid.pcpeID=
            //pxMatch_DHCPPool.iid.tr69ID=
            memset(pxMatch_DHCPPool->iid.tr69Id,0x00,MAX_TR69_ID_LEN);
            iOper = IFX_OP_DEL;
            iFlags = (IFX_F_DELETE|IFX_F_DONT_VALIDATE| IFX_F_DONT_CHECKPOINT|IFX_F_DONT_WRITE_TO_FLASH);
            
            iRet = ifx_set_dhcp_conditional_entry(iOper, pxMatch_DHCPPool, iFlags);   
            if(iRet != IFX_SUCCESS)
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "ifx_set_dhcp_conditional_entry -delete Mgmt API returned error\n");
                goto errorHandler;
            }
            break;
            
        default:
            break;
    }
    IFX_CWMP_FREE(pxMatch_DHCPPool);

    return IFIN_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                 "%s:%d failed!\n", __func__, __LINE__);

    IFX_CWMP_FREE(pxMatch_DHCPPool);
    return IFIN_CWMP_FAILURE;
}




/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : IFX_DHCPCondServ_Init
**
**   Description      : This function is called by the controller. It registers
**                      the function responsible for handling DHCPConditionalServ
**						object with data structure. It also performs initializations
**                      specific to DHCPConditionalServing object.
**
**   Parameters       : No Parameters. 
**
**   Return Value     : IFX_CWMP_SUCCESS - When DHCPCondServ object is initialized
**                      successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in initializing DHCPOCondServ object.
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_DHCPCondServ_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the DHCPOption module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_DHCPCONDSERV_OBJ, IFX_DHCPCondServ);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_DHCPCONDSERV_OBJ);
        goto cleanup;
    }

cleanup:
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_DHCPCondServ
**
**   Description      : This function is called by the controller. It handles
**                      the DHCPCondServPool object and performs  based on requested
**                      operations/suboperations by invoking internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_DHCPCondServ(IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
             OUT void **ppRet, OUT int32 *piNumRetElem)
{
    int32       iRet           = IFX_CWMP_SUCCESS;
    ParamVal    *pxParamVal    = (ParamVal *)pParamList;

    /* Process based on type of Operation */
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:

                    /* Get values of all the requested parameters */
                    iRet = GetVal(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_SETVAL:
        {
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:

                    /* Validate values of all the requested parameters */
                    iRet = Validate(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:

                    /* Check modify dependency of all requested parameters */
                    iRet = IFX_CWMP_SUCCESS;
                    break;
                case OP_SETVAL_MODIFY:

                    /* Set values of all the requested parameters */
                    iRet = Modify(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ATTRINFO:

                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ADD:

                    iRet = AddObj(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_FREE:
                   break;
                case OP_SETVAL_CHK_DEL_DEP:

                   *ppRet = (ParamVal *)IFX_CWMP_MALLOC(sizeof(ParamVal));
                   if(*ppRet == NULL)
                       return ERR_OUT_OF_MEMORY ;

                   memcpy(*ppRet, pParamList, sizeof(ParamVal));
                   *piNumRetElem = 1;
                   break;


                case OP_SETVAL_CHK_DEL_ALLOWED:
                case OP_SETVAL_DELETE:
                    if((iRet= SetDelete(pxOI, pxParamVal,
                        iNumElem, ppRet, piNumRetElem))!= IFX_CWMP_SUCCESS)
                    {

                        switch(pxOI->iSubOper)
                        {
                            case OP_SETVAL_CHK_DEL_DEP:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
                                goto cleanup;
                            case OP_SETVAL_CHK_DEL_ALLOWED:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
                                goto cleanup;
                            case OP_SETVAL_DELETE:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
                                goto cleanup;
                        }
                    }
                    break;

                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD: 
                case OP_UPDATE_CHILDINFO_DEL: 
                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
        {
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid Operation\n",
                         __func__, __LINE__, iRet);
            goto cleanup;
        }
    }

cleanup:
    return (iRet);
}


