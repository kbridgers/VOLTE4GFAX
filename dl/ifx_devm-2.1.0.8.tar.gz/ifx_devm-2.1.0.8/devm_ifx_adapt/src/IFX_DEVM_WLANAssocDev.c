/* 
** =============================================================================
**   FILE NAME     : IFX_WlanAssocDevice.c
**   PROJECT       : TR69
**   MODULES       : WlanAssocDevice
**   DATE          : 27-09-2007
**   AUTHOR        : TR69 team
**   DESCRIPTION   : This module handles GET RPC of 
**                   hosts/hosts.host. When controller calls this module it
**                   calls respective Platform/Object APIs of the sytem.
**
**   REFERENCES    : < List of design docs covering this file >
**   COPYRIGHT     : Copyright (c) 2006
**                   Infineon Technologies AG
**                   Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY       : 
**   $Date         $Author               $Comment
**   28-03-07      TR69 Team             Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "IFX_DEVM_WLANAssocDev.h"
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_StackUtil.h"
#include "IFX_DEVM_Controller.h"
// 

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;

#ifdef IFX_TR69_DEVICE
	#define OID_IGD_LAND_WLANC_AD_ASSOCIATEDDEVICEIPADDRESS		OID_IGD_LAN_WLANC_AD_ASSOCIATEDDEVICEIPADDRESS
	#define OID_IGD_LAND_WLANC_AD_ASSOCIATEDDEVICEAUTHENTICATIONSTATE	OID_IGD_LAN_WLANC_AD_ASSOCIATEDDEVICEAUTHENTICATIONSTATE
	#define OID_IGD_LAND_WLANC_AD_ASSOCIATEDDEVICEMACADDRESS	OID_IGD_LAN_WLANC_AD_ASSOCIATEDDEVICEMACADDRESS
#endif

#define IFX_WLAN_ASSOCDEVICE_OBJ FORMLANNAME("WLANConfiguration.1.AssociatedDevice.1.")

#define MAKE_SECTION_COUNT_TAG(secName, buf) sprintf(buf, "%s_Count", secName);
#define TAG_WLAN_MAIN "wlan_main"

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/




/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/

#define MAX_AP_INFO 4 // XXX
#define MAX_ASSOC_DEV 33 // XXX
IFX_MAPI_WLAN_AssocInfo *gaAPAssocInfo[MAX_AP_INFO];
int32 gaAssocDevCnt[MAX_AP_INFO];
int32 gaTR69AssocDevInstanceMap[MAX_AP_INFO][MAX_ASSOC_DEV];


extern Map_Value gaxEnable[];

/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/

static void IFX_DEVM_WLANCleanupAssocList(void);


/*
** =============================================================================
**   Function Name    : IFX_WlanAssocDeviceGetValue
**   Description        :
**
**   Parameters       :
**
**   Return Value     :
**   Notes                :
**
** ============================================================================
*/
static int32
IFX_WlanAssocDeviceGetValue(IN OperInfo * pxOperInfo,
                            INOUT ParamVal * pxGetParamVal, IN uint32 iElements,
                            OUT int32 * puiNoInstances)
{
    uint32 i = 0, idx;
    uint32 uiParamPos = 0;
    int32 iRet = 0;

    IFX_MAPI_WLAN_AssocInfo *assoDev;

    uiParamPos = IFX_GetParamIdPos(pxGetParamVal->iaOID);
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
					"uiParamPos = %d pxGetParamVal[i].iaOID[uiParamPos-1] = %d"
					"pxGetParamVal[i].iaOID[uiParamPos-3] = %d\n",
					uiParamPos, pxGetParamVal[i].iaOID[uiParamPos-1],
					pxGetParamVal[i].iaOID[uiParamPos-3]);

	assoDev = gaAPAssocInfo[pxGetParamVal[i].iaOID[uiParamPos-3] - 1];
	if (assoDev == NULL) {
		iRet = IFX_CWMP_FAILURE;
		goto errorHandler;
	}

    if(pxOperInfo->iSubOper == OP_GETVAL_INSTANCES) {
	    *puiNoInstances = gaAssocDevCnt[pxGetParamVal[i].iaOID[uiParamPos-3] - 1];
        goto Handler;
    }

    for (i = 0; i < iElements; i++)
    {
        pxGetParamVal[i].Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
	((char *)pxGetParamVal[i].Value)[0] = '\0';
        idx = gaTR69AssocDevInstanceMap[pxGetParamVal[i].iaOID[uiParamPos-3]-1][pxGetParamVal[i].iaOID[uiParamPos-1]];
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s:%d] idx = %d\n",
						_FUNCL_, idx);
        switch (pxGetParamVal[i].iaOID[uiParamPos])
        {
        case OID_IGD_LAND_WLANC_AD_ASSOCIATEDDEVICEIPADDRESS:
            strncpy((char8 *) pxGetParamVal[i].Value,
                    inet_ntoa(assoDev[idx-1].ipAddress),
                    (MAX_IP_ADDRRESS_LEN - 1));
            break;
        case OID_IGD_LAND_WLANC_AD_ASSOCIATEDDEVICEMACADDRESS:
            strncpy(pxGetParamVal[i].Value,
                    assoDev[idx-1].macAddress, (MAX_MAC_ADDRESS_LEN - 1));

            break;
        case OID_IGD_LAND_WLANC_AD_ASSOCIATEDDEVICEAUTHENTICATIONSTATE:
            sprintf(pxGetParamVal[i].Value, "%d", assoDev[idx-1].staAuthenticated);
            break;
        default:
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d Invalid param id %d!\n", _FUNCL_, pxGetParamVal[i].iaOID[uiParamPos]);
            pxGetParamVal->iFaultCode = ERR_INVAL_PARAMETER_VAL;
            break;
        }
    }
Handler:
    return IFX_CWMP_SUCCESS;

errorHandler:
    return IFIN_CWMP_FAILURE;
}


/*
** =============================================================================
**   Function Name    : IFX_WlanAssocDevice_Init
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/
int32
IFX_WlanAssocDevice_Init(void)
{
    int32 i, j, iRet = IFX_CWMP_SUCCESS;

    iRet =
        ifx_ds_register_function(IFX_WLAN_ASSOCDEVICE_OBJ, IFX_WlanAssocDevice);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "Unable to Register %s with Object Model\n",
                    IFX_WLAN_ASSOCDEVICE_OBJ);
        goto errorHandler;
    }

	IFX_DEVM_WLANCleanupAssocList();

	for (i = 0; i < MAX_AP_INFO; i++) {
		gaAPAssocInfo[i] = NULL;
		gaAssocDevCnt[i] = 0;
		for (j = 0; j < MAX_ASSOC_DEV; j++)
			gaTR69AssocDevInstanceMap[i][j] = 0;
	}

errorHandler:
    return iRet;
}


/*********************************************************************************
*  Function Name  :  IFX_WlanAssocDevice

*  Description      :  This function handles all the sub-states inside
                    a GET/SET operation.If it is a GET it allocates the
             array(Name,Value pairs) and retruns the values.
             If it is a SET controller allocates the array and
             passes the values to this function.It calls
             respective internal functions which in turn calls
             respective Platform APIs.

*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
                                 Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has
                                       Name,Value,etc
                    IN          int32           iElements;    No. of Elements
            OUT            void *           ppParamRet;   same as ParamStruc
            OUT         int32 *        piNumRetElem; No. of elements
*  Return Value  : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes         :
***********************************************************************************/
int32
IFX_WlanAssocDevice(IN OperInfo * pxOperInfo, INOUT void *paxParamArr,
                  IN int32 iElements, OUT void **ppaxParamArrRet,
                  OUT int32 * piNumRetElem)
{
	int32 iRet = IFX_CWMP_SUCCESS;
	ParamVal *pxParamVal = (ParamVal *) paxParamArr;
	ParamVal    *pxVal;
	uint32 uiParamPos=0;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "Entered %s [%d :: %d]\n", 
	                    __func__, pxOperInfo->iOper, pxOperInfo->iSubOper);

	switch (pxOperInfo->iOper)
	{
		case OP_GETVAL:
		{
			iRet = IFX_WlanAssocDeviceGetValue(pxOperInfo, paxParamArr, 
			                   iElements, piNumRetElem);
			if (iRet != IFX_CWMP_SUCCESS)
				goto errorHandler;
			break;
		}
		case OP_SETVAL:
		{
			/* Process based on type of SubOperation */
			switch (pxOperInfo->iSubOper)
			{
				case OP_SETVAL_VALIDATE:
				case OP_SETVAL_MODIFY:
				case OP_SETVAL_ACTIVATE:
				case OP_SETVAL_ADD:
				case OP_SETVAL_CHK_MODIFY_DEP:
				case OP_SETVAL_CHK_DEL_ALLOWED :
				case OP_SETVAL_DELETE:
				case OP_SETVAL_ATTRINFO:
				case OP_SETVAL_FREE :
					break;
				case OP_SETVAL_CHK_DEL_DEP:
					pxVal= (void *)IFX_CWMP_MALLOC (sizeof(ParamVal));
					uiParamPos = IFX_GetParamIdPos(pxParamVal->iaOID);
					memcpy(pxVal->iaOID,pxParamVal->iaOID,(sizeof(int32)*(uiParamPos+1)));
					*ppaxParamArrRet = (void*) pxVal;
					*piNumRetElem = 1;
					break;
				default:
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                                "[%s:%d] [Error] Requested SubOperation not"
                		                " permitted on Object\n", __func__, __LINE__);
					iRet = IFX_CWMP_FAILURE;
					goto errorHandler;
			}
			break;
		}
		case OP_PARAM_VALIDATE:
			break;
		default:
		{
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			            "%s:%d [%d] Error! Default case.\n", _FUNCL_, pxOperInfo->iOper);
			break;
		}
	}

errorHandler:
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s returning %d\n", __func__, iRet);
	return iRet;

}

#if 1 /* TODO: Move these APIs to MAPI */
static int32 IFX_GetWLANAPCnt(int32 *iNumVAPs)
{
	int32 ret = IFX_SUCCESS;
	char8 sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN];
	uint32 outFlag = IFX_F_DEFAULT;

	MAKE_SECTION_COUNT_TAG(TAG_WLAN_MAIN, buf);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAIN, buf, IFX_F_GET_ANY, &outFlag,
									sValue)) != IFX_SUCCESS) {
		return IFX_CWMP_FAILURE;
	}

	*iNumVAPs = atoi(sValue);

	return IFX_CWMP_SUCCESS;
}

extern int32 ifx_GetSection(const char8 * pFileName, const char8 * pTag,
                   char8 ** pRetSec, uint32 * secPosition);

static void IFX_DEVM_WLANCleanupAssocList(void)
{
#if 0
	int32 iRet = 0;
	char8 psPartialObj[CWMP_OBJ_NOLEAF_LEN] = { 0 };
	int32 i, j;
	int32 iNumVAPs = 0;

	iRet = IFX_GetWLANAPCnt(&iNumVAPs);
	if (iRet != IFX_CWMP_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[DEVM_ASSOC_DEV_OBJ %s:%d]"
				" Failed to get VAP entries.\n", __func__, __LINE__);
		return;
	}
	for (j = 0; j < iNumVAPs; j++) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[DEVM_ASSOC_DEV_OBJ %s:%d(%d)] Deleting"
				" old entries.\n", __func__, __LINE__, j + 1);
		for (i = 0; ; i++) {
			sprintf(psPartialObj, FORMLANNAME("WLANConfiguration.%d.AssociatedDevice.%d."), 
			                      (j + 1), (i + 1));
			if(ifx_config_del_obj(psPartialObj) != IFX_CWMP_SUCCESS) {
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d(%d) DS delete fail "
					 "%s\n", _FUNCL_, j + 1, psPartialObj);
				break;
			} else {
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d(%d) DS deleted "
					 "%s\n", _FUNCL_, j + 1, psPartialObj);
			}
		}
	}
#else
	char8 *sVal = NULL;
	uint32 secOffset1 = 0;
	uint32 flags = 0;
	char *buff = NULL, line[100], tmp[100], nxt_str[10];
	char *str;
	int nxt = 1, len, index, i;

	if (ifx_GetSection(FILE_RC_CONF, "tr69_instances", &sVal, &secOffset1)
	    != IFX_SUCCESS) {
		IFX_DBG("[%s:%d]\n", __func__, __LINE__);
		return;
	}

	str = sVal;
	len = strlen(sVal);
	buff = (char *)malloc(len + 1);
	if (buff == NULL) {
		IFX_DBG("[%s:%d] Failed to allocate %d bytes\n", __func__,
			__LINE__, len + 1);
                IFX_CWMP_FREE(sVal);
		return;
	}
	memset(buff, '\0', len + 1);

	do {
		if (*str == '#') {
			memset(line, '\0', 100);
			i = 0;
			do {
				line[i++] = *str;
				str++;
				if (*(str) == '\n')
					break;
			} while (1);

			memset(tmp, '\0', 100);
			sscanf(line, "#%d=%s", &index, tmp);
			if (strstr(line, "-4040") == NULL) {
				memset(nxt_str, '\0', 10);
				sprintf(nxt_str, "%d", nxt);
				strcat(buff, "#");
				strcat(buff, nxt_str);
				strcat(buff, "=");
				strcat(buff, tmp);
				strcat(buff, "\n");
				nxt++;
			}

		} else
			str++;

		if (str >= sVal + len)
			break;

	} while (1);

	if (ifx_SetObjData(FILE_RC_CONF, "tr69_instances", flags, 1, buff) !=
	    IFX_SUCCESS) {
		IFX_DBG("[%s:%d]\n", __func__, __LINE__);
		goto errorHandler; 
	}
errorHandler:
	IFX_CWMP_FREE(sVal);
	IFX_CWMP_FREE(buff);
	return;
#endif
}
#endif

int32 IFX_BuildAssocDevList(void)
{
	int32 i, j;
	int32 iRet = 0;
	char8 psPartialObj[CWMP_OBJ_NOLEAF_LEN] = { 0 };
	int32 iNumVAPs = 0, iNumAssocs = 0;

	for (i = 0; i < MAX_AP_INFO; i++)
	{
		IFIN_CWMP_FREE(gaAPAssocInfo[i]);
		gaAPAssocInfo[i] = NULL;
		gaAssocDevCnt[i] = 0;
	}

	iRet = IFX_GetWLANAPCnt(&iNumVAPs);
	if (iRet != IFX_CWMP_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[DEVM_ASSOC_DEV_OBJ %s:%d]"
				" Failed to get VAP entries.\n", __func__, __LINE__);
		goto errorHandler;
	}
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[DEVM_ASSOC_DEV_OBJ %s:%d]"
					" iNumVAPs = %d\n", _FUNCL_, iNumVAPs);

	for (j = 0; j < iNumVAPs; j++) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[DEVM_ASSOC_DEV_OBJ %s:%d(%d)] Deleting"
				" old entries.\n", __func__, __LINE__, j + 1);
		for (i = 0; i < MAX_ASSOC_DEV; i++) {
			if (gaTR69AssocDevInstanceMap[j][i] == 0)
				continue;
			gaTR69AssocDevInstanceMap[j][i] = 0;
			sprintf(psPartialObj, FORMLANNAME("WLANConfiguration.%d.AssociatedDevice.%d."), 
			                      (j + 1), i);
			if(ifx_config_del_obj(psPartialObj) != IFX_CWMP_SUCCESS) {
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d(%d) DS delete fail "
					 "%s\n", _FUNCL_, j + 1, psPartialObj);
				break;
			} else {
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d(%d) DS deleted "
					 "%s\n", _FUNCL_, j + 1, psPartialObj);
			}
		}
	}

	for (j = 0; j < iNumVAPs; j++) {
    	IFX_MAPI_WLAN_AssocInfo *assoDev = NULL;
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[DEVM_ASSOC_DEV_OBJ %s:%d(%d)] Getting"
			   " entries.\n", __func__, __LINE__, j + 1);

		iRet = ifx_mapi_get_all_wlan_assoc_devices(j+1, (uint32 *)&iNumAssocs,
		           &assoDev, IFX_F_DEFAULT);
		if (iRet != IFX_CWMP_SUCCESS) {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[DEVM_ASSOC_DEV_OBJ"
							" %s:%d(%d)] Failed to get assoc info\n", _FUNCL_,
							j+1);
			goto errorHandler;
		}

		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[DEVM_ASSOC_DEV_OBJ %s:%d(%d)] "
						"Adding %d entries.\n", __func__, __LINE__, j + 1, iNumAssocs);
		for (i = 0; i < iNumAssocs; i++) {
			sprintf(psPartialObj,
			    FORMLANNAME("WLANConfiguration.%d.AssociatedDevice."), 
				(j + 1));
			if((iRet = IFX_ContAddObj(ACC_ROOT, psPartialObj)) <= 0) {
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d(%d) Add Obj to DS fail "
					 "%s\n", _FUNCL_, j + 1, psPartialObj);
				IFX_CWMP_FREE(assoDev);
				goto errorHandler;
			} else {
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d(%d) Instance added"
								" successfully.\n", __func__, __LINE__, j + 1);
				gaTR69AssocDevInstanceMap[j][iRet] = i + 1;
				iRet = IFX_CWMP_SUCCESS;
			}
		}
		gaAssocDevCnt[j] = iNumAssocs;
		gaAPAssocInfo[j] = assoDev;
	}
	iRet = IFX_CWMP_SUCCESS;
errorHandler:
	return iRet;
}

