/* 
** =============================================================================
**   FILE NAME        : IFX_ProfileServiceProviderInfo
**   PROJECT          : TR104
**   MODULES          : IFX_ProfileServiceProviderInfo
**   DATE             : 03-11-2006
**   AUTHOR           : TR104 team
**   DESCRIPTION   :

**   REFERENCES      : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2004
**                   	      Infineon Technologies AG, st. Martin Strasse 53;
**                   	      81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/


/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "ifx_vmapi_common.h"
#include "IFX_DEVM_VoiceLine.h"
  // Required for STATIC
 
#include "IFX_DEVM_OID.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
 
#include "IFX_DEVM_AdaptCommon.h"
#include "IFX_DEVM_DS.h"

//#include "ifx_voip_defs.h"
//#include "ifx_cm.h"
//#include "ifx_vmapi1.h"
//#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

int32
IFX_ProfileServiceProviderInfo(IN OperInfo * pxOI, INOUT void *pParamList,
                     IN int32 iNumElem, OUT void **ppRet,
                     OUT int32 * piNumRetElem);

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFX_PROFILESERVICEPROVIDER_OBJ "InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.1.ServiceProviderInfo."


/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/
STATIC int32
GetVal(IN int32 iCaller, INOUT ParamVal *pxParamVal,
                    IN int32 iElements);
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
GetModifyDep(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
GetNotify(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
                 IN int32 iElements);
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);
/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetVal(IN int32 iCaller, INOUT ParamVal *pxParamVal,
                    IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iRtn = IFX_SUCCESS;
    int32   iCnt = 0;
    int32   iTmpCnt = -1; /* Mandatory */
    int32   iParamOffset;
    int32   iOID;
    int32   iMemErrorFlag = 0; /* Mandatory */
    x_IFX_VMAPI_ProfileServiceProviderInfo xProfServProvInfo;
    uint32 uiPCpeId;

    /* NOTE: For all parameters fault code is set to success by default. If error in
       validating first parameter, fault code is set to the error type and other
       parameters are not validated. */
    /* NOTE: For all parameters value is set to NULL by default. */

    /* Set the fault code to Success and value to NULL pointer for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);

    memset(&xProfServProvInfo, 0, 
             sizeof(x_IFX_VMAPI_ProfileServiceProviderInfo));
    
    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_SPI:{

            char8 sOidString[100] = {0};
            IFX_CpeId *pxCpeIdArray = NULL;
            unsigned int uiNumCpeId;

            /* Get the Parent CPE Id */
            IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT &uiPCpeId);
            xProfServProvInfo.iid.pcpeId.Id = uiPCpeId;

            /*ignore the last value as it will be a parameter and we need 
              only till the last instance*/
            iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );

            strcpy(xProfServProvInfo.iid.tr69Id,sOidString);

            /*Get the CPE Id from the corresponding tr69 Id */
            iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId,
                               OUT &pxCpeIdArray);
            if(iRet != IFX_CWMP_SUCCESS){
                   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                   __func__, __LINE__);

              return ERR_CWMP_INTERNAL;
            }
            //printf("CPEID is %d\n",pxCpeIdArray->uiId);   

            /* Fill the CPE ID of the object instance */
            xProfServProvInfo.iid.cpeId.Id = pxCpeIdArray->uiId;
            xProfServProvInfo.iid.config_owner = IFX_TR69;

           /* Get all the Profile ServiceProviderInfo parameters using VMAPI */
            iRtn = ifx_get_ProfileServiceProviderInfo(&xProfServProvInfo, 
                                            IFX_F_DEFAULT);

            IFX_CWMP_FREE(pxCpeIdArray);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to get values of all "
                            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto cleanup;
            }
            }
            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_S_VS_VP_SPI_NAME:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                sizeof(xProfServProvInfo.acName));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              strcpy((pxParamVal[iCnt]).Value,
                                    xProfServProvInfo.acName);
              
            break; 
          case OID_IGD_S_VS_VP_SPI_URL:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                sizeof(xProfServProvInfo.acUrl));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              strcpy((pxParamVal[iCnt]).Value,
                                    xProfServProvInfo.acUrl);
              
            break;
          case OID_IGD_S_VS_VP_SPI_CONTACTPHONENUMBER:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                sizeof(xProfServProvInfo.acPhone));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              strcpy((pxParamVal[iCnt]).Value,
                                    xProfServProvInfo.acPhone);
              
            break;
          case OID_IGD_S_VS_VP_SPI_EMAILADDRESS:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                sizeof(xProfServProvInfo.acEmail));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              strcpy((pxParamVal[iCnt]).Value,
                                    xProfServProvInfo.acEmail);
              
            break; 
          default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                iTmpCnt = iCnt;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
            goto cleanup;
        }
    }

cleanup:

    if (iMemErrorFlag)
    {
        (pxParamVal[iCnt]).iFaultCode = ERR_OUT_OF_MEMORY;
        iRet = ERR_OUT_OF_MEMORY;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Allocation Failure\n",
                     __FILE__, __func__, __LINE__, iRet);
    }

    if (iRet != IFX_CWMP_SUCCESS)
    {

        /* Free the allocation for value, if any. Also set the fault code. */
        for (iCnt = 0; iCnt < iElements; iCnt++)
        {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
            if (iTmpCnt != iCnt) 
            {
                (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
            }
        }
    }

    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : Modify
**
**   Description      : This function modifies the values of parameters in 
**                      ServiceProviderInfo object. It calls respective VMAPI  
**                      for the same. It performs modification only if parameter 
**                      has Write permission. In certain cases it also performs 
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet         = IFX_CWMP_SUCCESS;
    int32   iRtn         = IFX_SUCCESS;
    int32   iCnt         = 0;
    int32   iParamOffset;
    int32   iOID;
    x_IFX_VMAPI_ProfileServiceProviderInfo xProfServProvInfo;
    uint32 uiPCpeId;

    /* NOTE: For all parameters fault code is set to success by default. If error in
       validating first parameter, fault code is set to the error type and other
       parameters are not validated. */

    /* Set the fault code to Success for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
    }

    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);

    memset(&xProfServProvInfo, 0, 
                sizeof(x_IFX_VMAPI_ProfileServiceProviderInfo));

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_SPI:{

            char8 sOidString[100] = {0};
            IFX_CpeId *pxCpeIdArray = NULL;
            unsigned int uiNumCpeId;

            /* Get the Parent CPE Id */
            IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT &uiPCpeId);
            xProfServProvInfo.iid.pcpeId.Id = uiPCpeId;

            /*ignore the last value as it will be a parameter and we need 
              only till the last instance*/
            iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );

            strcpy(xProfServProvInfo.iid.tr69Id,sOidString);

            /*Get the CPE Id from the corresponding tr69 Id */
            iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId,
                               OUT &pxCpeIdArray);
            if(iRet != IFX_CWMP_SUCCESS){
                   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                   __func__, __LINE__);

              return ERR_CWMP_INTERNAL;
            }
            //printf("CPEID is %d\n",pxCpeIdArray->uiId);   

            /* Fill the CPE ID of the object instance */
            xProfServProvInfo.iid.cpeId.Id = pxCpeIdArray->uiId;
            xProfServProvInfo.iid.config_owner = IFX_TR69;

           /* Get all the Profile ServiceProviderInfo parameters using VMAPI */
            iRtn = ifx_get_ProfileServiceProviderInfo(&xProfServProvInfo, 
                                            IFX_F_DEFAULT);

            IFX_CWMP_FREE(pxCpeIdArray);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to get values of all "
                            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto cleanup;
            }
            }
            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_S_VS_VP_SPI_NAME:
              strncpy(xProfServProvInfo.acName , pxParamVal[iCnt].Value, (IFX_VMAPI_MAX_USER_NAME_LEN-1)); 
              break;
            case OID_IGD_S_VS_VP_SPI_URL:
              strncpy(xProfServProvInfo.acUrl , pxParamVal[iCnt].Value, (IFX_VMAPI_MAX_USER_NAME_LEN-1) ); 
              break;
            case OID_IGD_S_VS_VP_SPI_CONTACTPHONENUMBER:
              strncpy(xProfServProvInfo.acPhone , pxParamVal[iCnt].Value, (IFX_VMAPI_MAX_PHONE_NO_LEN-1)); 
              break;
            case OID_IGD_S_VS_VP_SPI_EMAILADDRESS:
              strncpy(xProfServProvInfo.acEmail , pxParamVal[iCnt].Value, (IFX_VMAPI_MAX_USER_NAME_LEN-1)); 
              break;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_SPI:

            /* Fill the iid structure in SERVICE_PROVIDER */
            xProfServProvInfo.iid.config_owner = IFX_TR69;

            /* Set all the VOICE_LINE  parameters using Object API */
            iRtn = ifx_set_ProfileServiceProviderInfo(IFX_OP_MOD, &xProfServProvInfo, IFX_F_DEFAULT);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to set values of all "
                            "parameters\n", __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
            }

            break;
        default:
            /* Will never come here since already checked above */
            break;
    }

cleanup:
    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : Validate
**
**   Description      : This function validates the values of parameters in
**                      ServiceProviderInfo object.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      validated.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When validation of all parameters is
**                      successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in validating at least one parameter.
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet         = IFX_CWMP_SUCCESS;
    int32   iRtn         = IFX_SUCCESS;
    int32   iCnt;
    int32   iParamOffset;
    char8   *psTmpVal;

    /* NOTE: For all parameters fault code is set to success by default. If error in
       validating first parameter, fault code is set to the error type and other
       parameters are not validated. */

    /* NOTE: Currently validation is performed only for parameters that have write permission.
       Other parameters are simply ignored. I think this should be fine since those
       validations are performed by the controller */ 

    /* Set the fault code to Success for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and validate the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);
        //printf("psTmpVal is %s\n",psTmpVal);

        /* Return a failure if the value is NULL pointer */
        if (!psTmpVal)
        {
            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
            iRet = ERR_CWMP_INVAL_PARAM_VAL;
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_S_VS_VP_SPI_URL:
                iRtn =  IFX_ValidateURL(psTmpVal);
                /* Check for error */
                if (iRtn != IFX_CWMP_SUCCESS)
                {
                  /* Set the fault code to Failure for all parameters */
                  for (iCnt = 0; iCnt < iElements; iCnt++)
                  {
                      (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                  }

                  (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                  iRet = ERR_CWMP_INVAL_PARAM_VAL;
                  IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to set values of URL "
                            "parameter\n", __FILE__, __func__, __LINE__, iRet);
                  goto cleanup;
                }
                
                break;
            case OID_IGD_S_VS_VP_SPI_CONTACTPHONENUMBER:
                iRtn =  IFX_ValidatePhoneDigit(psTmpVal);
                /* Check for error */
                if (iRtn != IFX_CWMP_SUCCESS)
                {
                  /* Set the fault code to Failure for all parameters */
                  for (iCnt = 0; iCnt < iElements; iCnt++)
                  {
                      (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                  }

                  (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                  iRet = ERR_CWMP_INVAL_PARAM_VAL;
                  IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to set values of contact "
                            "phone number\n", __FILE__, __func__, __LINE__, iRet);
                  goto cleanup;
                }
                
                break;
          
            case OID_IGD_S_VS_VP_SPI_EMAILADDRESS:
                //printf("psTmpVal for e-mail is %s\n",psTmpVal);
                iRtn =  IFX_ValidateEmail(psTmpVal);
                /* Check for error */
                if (iRtn != IFX_CWMP_SUCCESS)
                {
                  (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                  iRet = ERR_CWMP_INVAL_PARAM_VAL;
                  IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to set values of e-mail "
                            "address\n", __FILE__, __func__, __LINE__, iRet);
                  goto cleanup;
                }
                
                break;


            case OID_IGD_S_VS_VP_SPI_NAME:
                /* Not validating. just returtning success */
                break;
            
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

cleanup:
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Validating requested parameter failed\n",
                    __FILE__, __func__, __LINE__, iRet);
    }
    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : GetModifyDep
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
GetModifyDep(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    return (IFX_CWMP_SUCCESS);
}

/* 
** =============================================================================
**   Function Name    : IFX_ProfileServiceProvider_AddDel
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_ProfileServiceProvider_AddDel(IN int32 iCaller, IN ParamVal *pxParamVal, 
               IN int32 iNumElem, IN int32 operation)
{
    int32   iRet = IFIN_CWMP_SUCCESS;
#if 1
 
    int32   iCnt = 0;
    char sOidString[IFX_MAX_TR69_ID_LEN];
    int32   iParamOffset;
    IFX_CpeId *pxCpeIdArray = NULL;
    unsigned int uiNumCpeId;
    unsigned int uiPCpeId;
    x_IFX_VMAPI_ProfileServiceProviderInfo xProfServProvInfo;
  
    /* if neither delete nor add operation */ 
    if((operation != OP_SETVAL_ADD)&&(operation != OP_SETVAL_DELETE)){ 
          IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] Invalid operation\n",
                   __func__, __LINE__);
      return ERR_CWMP_INTERNAL;
    }

    memset(sOidString,0x00,IFX_MAX_TR69_ID_LEN);
    memset(&xProfServProvInfo,0,sizeof(xProfServProvInfo));

    /* Get the Parent CPE Id */
    IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT &uiPCpeId);
    xProfServProvInfo.iid.pcpeId.Id = uiPCpeId;

      
   
    /* if delete operation */
    if(operation == OP_SETVAL_DELETE){ 
      // get cpeid, pass to delete function
      // here the input iaOID will be igd.l3f.f.2.
      
      /*ignore the last value as it will be a parameter and we need 
               only till the last instance*/
      iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );

      iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId, OUT &pxCpeIdArray);
      if(iRet != IFX_CWMP_SUCCESS){
              IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                      "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                      __func__, __LINE__);

        return ERR_CWMP_INTERNAL;
      }
      
      /* Get the Cpe Id*/  
      xProfServProvInfo.iid.cpeId.Id = pxCpeIdArray->uiId;

      memset(xProfServProvInfo.iid.tr69Id,0x00,MAX_TR69_ID_LEN);
      if(strlen(pxCpeIdArray->sSectionTag) < MAX_TAG_LEN){
        strncpy(xProfServProvInfo.iid.cpeId.secName,pxCpeIdArray->sSectionTag, MAX_TAG_LEN-1);
        IFX_CWMP_FREE(pxCpeIdArray);
      }else{
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] strcpy : mismatch in size in buffer copy\n",
                    __func__, __LINE__);
        IFX_CWMP_FREE(pxCpeIdArray);
        return ERR_CWMP_INTERNAL;
      }
      /* Get the Profile Id*/    
      xProfServProvInfo.ucProfileId = IFX_GetProfileId(pxParamVal->iaOID);  

      /* Fill the iid structure in VOICE_LINE */
      xProfServProvInfo.iid.config_owner = IFX_TR69;

      strncpy(xProfServProvInfo.iid.tr69Id,sOidString, MAX_TR69_ID_LEN-1);
      xProfServProvInfo.iid.tr69Id[MAX_TR69_ID_LEN-1] = '\0';

      /* call the respective VMAPI */
      iRet = ifx_set_ProfileServiceProviderInfo( IFX_OP_DEL, &xProfServProvInfo, IFX_F_DEFAULT); 
      if(iRet != IFX_CWMP_SUCCESS){
             IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [Error] ifx_set_ProfileServiceProviderInfo failed\n",
                    __func__, __LINE__);
        return ERR_CWMP_INTERNAL;
      }

      return iRet;

    }// end of delete operation

    if(operation == OP_SETVAL_ADD){  // if ADD
      // ADD operation
      // here the input iaOID will be igd.l3f.f.2.
    
      /*ignore the last value as it will be a parameter and we need 
                only till the last instance*/
      iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );
      strncpy(xProfServProvInfo.iid.tr69Id,sOidString, MAX_TR69_ID_LEN-1);
      xProfServProvInfo.iid.tr69Id[MAX_TR69_ID_LEN-1] = '\0';

      IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                  "[%s:%d] sOidString =%s\n", __func__, __LINE__, sOidString);


      /* Get the Profile Id*/    
      xProfServProvInfo.ucProfileId = IFX_GetProfileId(pxParamVal->iaOID);  
      
      /* Get the offset of the parameter */
      iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
      if (iParamOffset < 0)
      {
            iRet = ERR_CWMP_INTERNAL;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
            goto cleanup;
      }

      // fill the given parameters of this structure with the new values provided
      for( iCnt = 0; iCnt < iNumElem; iCnt++){

          /* Process based on the requested parameter */
          switch (pxParamVal[iCnt].iaOID[iParamOffset])
          {
            case OID_IGD_S_VS_VP_SPI_NAME:
            case OID_IGD_S_VS_VP_SPI_URL: 
            case OID_IGD_S_VS_VP_SPI_CONTACTPHONENUMBER:
            case OID_IGD_S_VS_VP_SPI_EMAILADDRESS: 
              break;
            default:
               IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           "[%s:%d] Unknown requested parameter %d\n",
                           __func__, __LINE__, pxParamVal[iCnt].iaOID[iParamOffset]);
             // parameter not found
             pxParamVal[iCnt].iFaultCode = ERR_INVAL_PARAMETER_NAME;

             goto cleanup;
          }
    } 

    /* Fill the iid structure in VOICE PROFILE */
    xProfServProvInfo.iid.config_owner = IFX_TR69;

    // call the VMAPI to modify
      iRet = ifx_set_ProfileServiceProviderInfo( IFX_OP_ADD, &xProfServProvInfo, IFX_F_DEFAULT); 
      if(iRet != IFX_CWMP_SUCCESS){
             IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] ifx_set_ProfileServiceProviderInfo adding failed\n", 
                     __func__, __LINE__);
        iRet = ERR_CWMP_INTERNAL;
        goto cleanup;
      }
      return iRet;

    }//end of add operation

cleanup:

    /* Perform Cleanup of unnecessary VoiceProfile members */

#endif
    return (iRet);

}




/* 
** =============================================================================
**   Function Name    : GetNotify
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
GetNotify(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
                 IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : SetAttrInfo
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
  int32 iRet,i;
  iRet = IFX_SetAttributesInfo(pxOI, pxParamVal, iElements);
    if(iRet != IFX_CWMP_SUCCESS)
      goto errorHandler;

  for(i=0; i < iElements; i++)
    IFX_CWMP_FREE(pxParamVal->Value);

  return IFX_CWMP_SUCCESS;

  errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d failed!\n", __func__, __LINE__);
    return iRet;
}

/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : IFX_ProfileServiceProviderInfo_Init
**
**   Description      : This function is called by the controller. It registers
**                      the function responsible for handling ServiceProviderInfo object
**                      with data structure. It also performs initializations
**                      specific to Service Provider Info object.
**
**   Parameters       : No Parameters. 
**
**   Return Value     : IFX_CWMP_SUCCESS - When ServiceProviderInfo object is initialized
**                      successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in initializing Service Provider Info object.
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_ProfileServiceProviderInfo_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the Service Provider Info module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_PROFILESERVICEPROVIDER_OBJ, 
                      IFX_ProfileServiceProviderInfo);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_PROFILESERVICEPROVIDER_OBJ);
        goto cleanup;
    }

cleanup:
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_ProfileServiceProviderInfo
**
**   Description      : This function is called by the controller. It handles
**                      the Service Provider Info object and performs  based on requested
**                      operations/suboperations by invoking internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_ProfileServiceProviderInfo(IN OperInfo *pxOI, 
                     INOUT void *pParamList, IN int32 iNumElem,
                      OUT void **ppRet, OUT int32 *piNumRetElem)
{
    int32       iRet           = IFX_CWMP_SUCCESS;
    ParamVal    *pxParamVal    = (ParamVal *)pParamList;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                "[%s:%d] \n", __func__, __LINE__);

    /* Process based on type of Operation */
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:

                    /* Get values of all the requested parameters */
                    iRet = GetVal(pxOI->iCaller, pxParamVal,
                                               iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_GETVAL_NOTIFICATION:

                    /* Set attribute values for all the requested parameters */
                    iRet = GetNotify(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_SETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:

                    /* Validate values of all the requested parameters */
                    iRet = Validate(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:

                   /* Check modify dependency of all requested parameters */
                    iRet = GetModifyDep(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_MODIFY:

                    /* Set values of all the requested parameters */
                    iRet = Modify(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ATTRINFO:

                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_ADD:
                    iRet = IFX_ProfileServiceProvider_AddDel(pxOI->iCaller,pxParamVal, 
                              iNumElem, OP_SETVAL_ADD); // 1 = add 0=del

                    /* Check for error */
                    if (iRet != IFIN_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }
                   break;
                case OP_SETVAL_CHK_DEL_DEP:
                    *ppRet = (ParamVal *)IFX_CWMP_MALLOC(sizeof(ParamVal));
		    if(ppRet!=NULL){
                    	memcpy(*ppRet, pParamList, sizeof(ParamVal));
                    	*piNumRetElem = 1;
		    	iRet=IFX_CWMP_SUCCESS;
		    	goto cleanup;
		    }
		    else{
		    	iRet=IFX_CWMP_FAILURE;
		    	goto cleanup;
		    }
                   break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    return IFX_CWMP_SUCCESS;

                   break;
                case OP_SETVAL_DELETE:
                    iRet = IFX_ProfileServiceProvider_AddDel(pxOI->iCaller,pxParamVal, 
                              iNumElem, OP_SETVAL_DELETE); // 1 = add 0=del

                    /* Check for error */
                    if (iRet != IFIN_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }
                break;
                case OP_SETVAL_FREE:
                    return IFX_CWMP_SUCCESS;

                break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_UPDATE_CHILDINFO:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD: 
                case OP_UPDATE_CHILDINFO_DEL: 
                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid Operation\n",
                         __func__, __LINE__, iRet);
            goto cleanup;
    }

cleanup:
    return (iRet);
}
