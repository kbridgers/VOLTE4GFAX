/* 
** =============================================================================
**   FILE NAME        : IFX_WanDslInterfaceConfig.c
**   PROJECT          : TR69
**   MODULES         : WanDslInterfaceConfig
**   DATE               : 21-06-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION   : This module handles ADD/DEL/GET/SET RPCs of 
**                      WanDslInterfaceConfig. When controller calls this module it
**                      calls respective Platform/Object APIs to handle GET/SET 
**                      of WanDslInterfaceConfig specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author        $Comment
**   28-04-06         TR69 team      Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
//#include <sys/socket.h>
//#include <netinet/in.h>
//#include <arpa/inet.h>

#include "IFX_DEVM_WANDSLIfaceCfg.h"
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
 
#include <fcntl.h>
#include <unistd.h>
#include "IFX_DEVM_StackUtil.h"

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;
#define IFX_DSL_INTF_CONFIG_OBJ "InternetGatewayDevice.WANDevice.1.WANDSLInterfaceConfig."
uint32 uiEnableInternet=1;
extern Map_Value gaxEnable[];
/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/




/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/
/*
#define IFX_DSL_MOD_TYPE_LEN 16
#define IFX_DSL_LINE_ENCODE_LEN 10
#define IFX_DSL_DATA_PATH_LEN 16
#define IFX_DSL_VENDOR_ID_LEN 42
#define IFX_DSL_COUNRY_CODE_LEN 12
*/
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
Map_Value saxDslLinkStatus[] ={
                                {"Up",SYS_DATATYPE_INT,{.uiSys_Value =DSL_LINESTATE_SHOWTIME_TC_SYNC}},
                                {"Up",SYS_DATATYPE_INT,{.uiSys_Value =DSL_LINESTATE_SHOWTIME_NO_SYNC}},
                                {"Initializing",SYS_DATATYPE_INT,{.uiSys_Value =DSL_LINESTATE_HANDSHAKE}},
                                {"Initializing",SYS_DATATYPE_INT,{.uiSys_Value =DSL_LINESTATE_FULL_INIT}},
                                {"Initializing",SYS_DATATYPE_INT,{.uiSys_Value =DSL_LINESTATE_DISCOVERY}},
                                {"EstablishingLink",SYS_DATATYPE_INT,{.uiSys_Value =DSL_LINESTATE_TRAINING}},
                                {"EstablishingLink",SYS_DATATYPE_INT,{.uiSys_Value =DSL_LINESTATE_ANALYSIS}},
                                {"EstablishingLink",SYS_DATATYPE_INT,{.uiSys_Value =DSL_LINESTATE_EXCHANGE}},
                                {"NoSignal",SYS_DATATYPE_INT,{.uiSys_Value =DSL_LINESTATE_SILENT_REQUEST}},
                                {"NoSignal",SYS_DATATYPE_INT,{.uiSys_Value =DSL_LINESTATE_SILENT}},
                                {"NoSignal",SYS_DATATYPE_INT,{.uiSys_Value =DSL_LINESTATE_IDLE_REQUEST}},
                                {"NoSignal",SYS_DATATYPE_INT,{.uiSys_Value =DSL_LINESTATE_IDLE}},
                                {"Error",SYS_DATATYPE_INT,{.uiSys_Value =DSL_LINESTATE_EXCEPTION}},
                                {"Disabled",SYS_DATATYPE_INT,{.uiSys_Value =DSL_LINESTATE_NOT_INITIALIZED}},
                                {"Disabled",SYS_DATATYPE_INT,{.uiSys_Value =DSL_LINESTATE_NOT_UPDATED}}
                                };

#endif
/*
typedef struct dsl_line_phy_properties
{
     uint32 Enable;
     uint32 LineStatus;
     char8  DslModType[IFX_DSL_MOD_TYPE_LEN];
     char8  LineEncoding[IFX_DSL_LINE_ENCODE_LEN];
     char8  DataPath[IFX_DSL_DATA_PATH_LEN]; 
     uint16 InterleaveDepth;
     int32  LineNo;
     uint32 usCurrRate;
     uint32 dsCurrRate;
     uint32 usMaxRate;
     uint32 dsMaxRate;
     int32    usNoiseMgr;
     int32     dsNoiseMgr;
     int32    usAttn;
     int32    dsAttn;
     int32  usPower;
     int32  dsPower;
     char8  ATURVendor[IFX_DSL_VENDOR_ID_LEN]; 
     char8  ATURCountry[IFX_DSL_COUNRY_CODE_LEN];
         char8  ATUCVendor[IFX_DSL_VENDOR_ID_LEN];
     char8  ATUCCountry[IFX_DSL_COUNRY_CODE_LEN];
         uint32 TotalStart;
     uint32 ShowtimeStart;
}DSL_LINE_PHY_PROPERTIES;        
*/

typedef enum datapath
{
     IFX_DSL_DATAPATH_FAST=0,
     IFX_DSL_DATAPATH_INTERLEAVE
}DATAPATH;

#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API

int32 ifx_get_standard_used(char8 *psStandardUsed,DSL_G997_XTUSystemEnabling_t *pxSystemEnabling)
{
// XTSE[1]
  if (pxSystemEnabling->data.XTSE[0] & 0x01)
  {
    strcpy(psStandardUsed, "T1.413");
  }

  if (pxSystemEnabling->data.XTSE[0] & 0x02)
  {
    strcpy(psStandardUsed, "G.992.1_Annex_C");
  }

  if (pxSystemEnabling->data.XTSE[0] & 0x04)
  {
    strcpy(psStandardUsed, "G.992.1_Annex_A");
  }
  if (pxSystemEnabling->data.XTSE[0] & 0x10)
  {
    strcpy(psStandardUsed, "G.992.1_Annex_B");
  }
  // XTSE[2]
  if (pxSystemEnabling->data.XTSE[1] & 0x01)
  {
    strcpy(psStandardUsed, "G.992.2");
  }
// XTSE[3]
  if (pxSystemEnabling->data.XTSE[2] & 0x04)
  {
    strcpy(psStandardUsed, "G.992.3_Annex_A");
  }

  if (pxSystemEnabling->data.XTSE[2] & 0x10)
  {
    strcpy(psStandardUsed, "G.992.3_Annex_B");
  }
  // XTSE[4]
  if (pxSystemEnabling->data.XTSE[3] & 0x01)
  {
    strcpy(psStandardUsed, "G.992.4");
  }

  if (pxSystemEnabling->data.XTSE[3] & 0x10)
  {
    strcpy(psStandardUsed, "G.992.3_Annex_I");
  }

  if (pxSystemEnabling->data.XTSE[3] & 0x40)
  {
    strcpy(psStandardUsed, "G.992.3_Annex_J");
  }
// XTSE[5]
  if (pxSystemEnabling->data.XTSE[4] & 0x04)
  {
    strcpy(psStandardUsed, "G.992.3_Annex_L");
  }

  if (pxSystemEnabling->data.XTSE[4] & 0x08)
  {
    strcpy(psStandardUsed, "G.992.3_Annex_L");
  }

  if (pxSystemEnabling->data.XTSE[4] & 0x40)
  {
    strcpy(psStandardUsed, "G.992.3_Annex_M");
  }
  // XTSE[6]
  if (pxSystemEnabling->data.XTSE[5] & 0x01)
  {
    strcpy(psStandardUsed, "G.992.5_Annex_A");
  }

  if (pxSystemEnabling->data.XTSE[5] & 0x04)
  {
    strcpy(psStandardUsed, "G.992.5_Annex_B");
  }

  if (pxSystemEnabling->data.XTSE[5] & 0x40)
  {
    strcpy(psStandardUsed, "G.992.5_Annex_I");
  }
// XTSE[7]
  if (pxSystemEnabling->data.XTSE[6] & 0x01)
  {
    strcpy(psStandardUsed, "G.992.5_Annex_J");
  }

  if (pxSystemEnabling->data.XTSE[6] & 0x04)
  {
    strcpy(psStandardUsed, "G.992.5_Annex_M");
  }
  // XTSE[8]
  if (pxSystemEnabling->data.XTSE[7] & 0x01)
  {
    strcpy(psStandardUsed, "G.993.2_Annex_A");
  }

  if (pxSystemEnabling->data.XTSE[7] & 0x02)
  {
    strcpy(psStandardUsed, "G.993.2_Annex_B");
  }

  if (pxSystemEnabling->data.XTSE[7] & 0x04)
  {
    strcpy(psStandardUsed, "G.993.2_Annex_C");
  }

  return 0;

}

int32 ifx_get_standards_supported(char8 *psStandardsSupported,DSL_G997_XTUSystemEnabling_t *pxSystemEnabling)
{
    memset(psStandardsSupported, 0x00, sizeof(psStandardsSupported));

    // XTSE1
    if(pxSystemEnabling->data.XTSE[0] & 0x01)
    {
        strcpy(psStandardsSupported, "T1.413,");
    }
    if(pxSystemEnabling->data.XTSE[0] & 0x02)
    {
        sprintf(psStandardsSupported, "%sG.992.1_Annex_C,", psStandardsSupported);
    }
    if(pxSystemEnabling->data.XTSE[0] & 0x04)
    {
        sprintf(psStandardsSupported, "%sG.992.1_Annex_A,", psStandardsSupported);
    }
    if(pxSystemEnabling->data.XTSE[0] & 0x10)
    {
        sprintf(psStandardsSupported, "%sG.992.1_Annex_B,", psStandardsSupported);
    }

    // XTSE2
    if(pxSystemEnabling->data.XTSE[1] & 0x01)
    {
        sprintf(psStandardsSupported, "%sG.992.2,", psStandardsSupported);
    }

    // XTSE3
    if(pxSystemEnabling->data.XTSE[2] & 0x04)
    {
        sprintf(psStandardsSupported, "%sG.992.3_Annex_A,", psStandardsSupported);
    }
    if(pxSystemEnabling->data.XTSE[2] & 0x10)
    {
        sprintf(psStandardsSupported, "%sG.992.3_Annex_B,", psStandardsSupported);
    }

    // XTSE4
    if(pxSystemEnabling->data.XTSE[3] & 0x10)
    {
        sprintf(psStandardsSupported, "%sG.992.3_Annex_I,", psStandardsSupported);
    }
    if(pxSystemEnabling->data.XTSE[3] & 0x40)
    {
        sprintf(psStandardsSupported, "%sG.992.3_Annex_J,", psStandardsSupported);
    }

    // XTSE[5]
    if((pxSystemEnabling->data.XTSE[4] & 0x04) || (pxSystemEnabling->data.XTSE[4] & 0x08))
    {
        sprintf(psStandardsSupported, "%sG.992.3_Annex_L,", psStandardsSupported);
    }
    if(pxSystemEnabling->data.XTSE[4] & 0x40)
    {
        sprintf(psStandardsSupported, "%sG.992.3_Annex_M,", psStandardsSupported);
    }

    // XTSE[6]
    if(pxSystemEnabling->data.XTSE[5] & 0x01)
    {
        sprintf(psStandardsSupported, "%sG.992.5_Annex_A,", psStandardsSupported);
    }
    if(pxSystemEnabling->data.XTSE[5] & 0x04)
    {
        sprintf(psStandardsSupported, "%sG.992.5_Annex_B,", psStandardsSupported);
    }
    if(pxSystemEnabling->data.XTSE[5] & 0x40)
    {
        sprintf(psStandardsSupported, "%sG.992.5_Annex_I,", psStandardsSupported);
    }

    // XTSE7
    if(pxSystemEnabling->data.XTSE[6] & 0x01)
    {
        sprintf(psStandardsSupported, "%sG.992.5_Annex_J,", psStandardsSupported);
    }
    if(pxSystemEnabling->data.XTSE[6] & 0x04)
    {
        sprintf(psStandardsSupported, "%sG.992.5_Annex_M,", psStandardsSupported);
    }

    // XTSE8
    if(pxSystemEnabling->data.XTSE[7] & 0x01)
    {
        sprintf(psStandardsSupported, "%sG.993.2_Annex_A,", psStandardsSupported);
    }
    if(pxSystemEnabling->data.XTSE[7] & 0x02)
    {
        sprintf(psStandardsSupported, "%sG.993.2_Annex_B,", psStandardsSupported);
    }
    if(pxSystemEnabling->data.XTSE[7] & 0x04)
    {
        sprintf(psStandardsSupported, "%sG.993.2_Annex_C", psStandardsSupported);
    }
    return 0;
}

int32 ifx_get_modulation_type(char8 *psModType,DSL_G997_XTUSystemEnabling_t *pxSystemEnabling)
{
    if(pxSystemEnabling->data.XTSE[0] & 0x01)
        strcpy(psModType, "ADSL_ANSI_T1.413");

    if((pxSystemEnabling->data.XTSE[0] & 0x04) ||
       (pxSystemEnabling->data.XTSE[0] & 0x10))
        strcpy(psModType, "ADSL_G.dmt");
 
    if(pxSystemEnabling->data.XTSE[1] & 0x01)
        strcpy(psModType,"ADSL_G.lite");
 
    if((pxSystemEnabling->data.XTSE[2] & 0x04)||
       (pxSystemEnabling->data.XTSE[2] & 0x10)||
       (pxSystemEnabling->data.XTSE[3] & 0x01)||
       (pxSystemEnabling->data.XTSE[3] & 0x10)||
       (pxSystemEnabling->data.XTSE[3] & 0x40))
        strcpy(psModType,"ADSL_G.dmt.bis");

  
    if((pxSystemEnabling->data.XTSE[4] & 0x04)||
       (pxSystemEnabling->data.XTSE[4] & 0x08))
        strcpy(psModType,"ADSL_re-adsl");

    if((pxSystemEnabling->data.XTSE[5] & 0x01)||
       (pxSystemEnabling->data.XTSE[5] & 0x04)||
       (pxSystemEnabling->data.XTSE[5] & 0x40)||
       (pxSystemEnabling->data.XTSE[6] & 0x01)||
       (pxSystemEnabling->data.XTSE[6] & 0x04))
        strcpy(psModType,"ADSL_2plus");

    if((pxSystemEnabling->data.XTSE[7] & 0x01)||
       (pxSystemEnabling->data.XTSE[7] & 0x02)||
       (pxSystemEnabling->data.XTSE[7] & 0x04))
        strcpy(psModType,"VDSL");

    return IFX_CWMP_SUCCESS;
}


int32 ifx_get_linkencap_supported(char8 *psEncapSupported, DSL_G997_XTUSystemEnabling_t *pxSystemEnabling, uint32 iTCLayer)
{
    memset(psEncapSupported, 0x00, sizeof(psEncapSupported));

    if(iTCLayer == DSL_TC_AUTO)
    {
        strcpy(psEncapSupported,"G.994.1");
    }
    else if((pxSystemEnabling->data.XTSE[2] & 0x04) || (pxSystemEnabling->data.XTSE[2] & 0x10) ||
       (pxSystemEnabling->data.XTSE[3] & 0x10)|| (pxSystemEnabling->data.XTSE[3] & 0x40) ||
       (pxSystemEnabling->data.XTSE[4] & 0x40)|| (pxSystemEnabling->data.XTSE[4] & 0x08) ||
       (pxSystemEnabling->data.XTSE[4] & 0x04))
    {
        if(iTCLayer == DSL_TC_ATM)
        {
            sprintf(psEncapSupported,"G.992.3_ANNEX_K_ATM");
        }
        else if((iTCLayer == DSL_TC_EFM) || (iTCLayer == DSL_TC_EFM_FORCED) || (iTCLayer == DSL_TC_HDLC))
        {
            sprintf(psEncapSupported,"G.992.3_ANNEX_K_PTM");
        }
    }
    if((pxSystemEnabling->data.XTSE[7] & 0x01) || (pxSystemEnabling->data.XTSE[7] & 0x02) ||
            (pxSystemEnabling->data.XTSE[7] & 0x04))
    {
        if(iTCLayer == DSL_TC_ATM)
        {
            sprintf(psEncapSupported,"%s,G.993.2_ANNEX_K_ATM", psEncapSupported);
        }
        else if((iTCLayer == DSL_TC_EFM) || (iTCLayer == DSL_TC_EFM_FORCED) || (iTCLayer == DSL_TC_HDLC))
        {
            sprintf(psEncapSupported,"%s,G.993.2_ANNEX_K_PTM", psEncapSupported);
        }
    }

    return IFX_CWMP_SUCCESS;
}


typedef enum
 {
  /*
   * Format as hey values
   */
   DSL_ARRAY_FORMAT_HEX,
  /*
   * Format as string
   */
   DSL_ARRAY_FORMAT_STRING
  } DSL_CPE_ArrayPrintFormat_t;


DSL_void_t DSL_CPE_ArraySPrintF(DSL_char_t * pDst,
                                DSL_void_t * pSrc,
                                DSL_uint16_t nSrcSize,
                                DSL_uint16_t nSrcElementSize,
                                DSL_CPE_ArrayPrintFormat_t nFormat)
{
  DSL_uint16_t i = 0, j = 0, elements = 0;
  DSL_uint32_t nVal = 0;
  DSL_char_t c;
  DSL_int_t ret = 0;

  elements = nSrcSize / nSrcElementSize;

/*
  if (nFormat == DSL_ARRAY_FORMAT_HEX)
  {
    ret = sprintf(pDst, "(");
    pDst++;
  }
*/
  for (i = 0; i < elements; i++)
  {
/*
    if ((i != 0) && (nFormat == DSL_ARRAY_FORMAT_HEX))
    {
      ret = sprintf(pDst, ",");
      pDst++;
    }
    
    if (nFormat == DSL_ARRAY_FORMAT_HEX)
    {
            ret = sprintf(pDst, "0x");
          pDst += ret;
    }
*/
    if (nFormat == DSL_ARRAY_FORMAT_HEX)
    {
      switch (nSrcElementSize)
      {
        case 1:
          ret = sprintf(pDst, "%02X", ((DSL_uint8_t *) pSrc)[i]);
          break;
        case 2:
          ret = sprintf(pDst, "%04X", ((DSL_uint16_t *) pSrc)[i]);
          break;
        case 4:
          ret = sprintf(pDst, "%08X", ((uint32 *) pSrc)[i]);
          break;
        default:
          ret = sprintf(pDst, "xx");
          break;
      }
  if (ret > 0)
      {
        pDst += ret;
      }
    }
    else
    {
      switch (nSrcElementSize)
      {
        case 1:
          nVal = (DSL_uint32_t) (((DSL_uint8_t *) pSrc)[i]);
          break;
        case 2:
          nVal = (DSL_uint32_t) (((DSL_uint16_t *) pSrc)[i]);
          break;
        case 4:
          nVal = (DSL_uint32_t) (((DSL_uint32_t *) pSrc)[i]);
          break;
        default:
          nVal = 0;
          break;
      }

      for (j = 0; j < nSrcElementSize; j++)
      {
        c = (DSL_uint8_t) (nVal >> j);
        if (isprint(c) != 0)
        {
          ret = sprintf(pDst, "%c", c);
          pDst += ret;
        }
      }
    }
  }
}


int32 ifx_get_dsl_phy_properties(DSL_LINE_PHY_PROPERTIES *dslphyparams)
{
    uint32 flags=0,cmd=0,i=0;
    int32 ret=0;
    DSL_LineState_t lineState;
    DSL_G997_XTUSystemEnabling_t xtuSystemEnabling;
    DSL_G997_ChannelStatus_t channelStatus;
    DSL_G997_FramingParameterStatus_t g997FramingParamStatusGet;
    DSL_G997_LineStatus_t lineStatus;
    DSL_G997_LineInventory_t lineInventoryGet;
    DSL_PM_LineSecCountersTotal_t pmLineSecCountersTotal;
    DSL_SystemInterfaceConfig_t stSystemInterfaceConfig;
    DSL_PM_LineSecCounters_t pmLineSecCountersShowTime;
#ifdef CONFIG_FEATURE_IFX_TR69_WANDSLOBJS_FULL
    DSL_PM_LineSecCounters_t pmLineSecCounters;
#endif
    DSL_G997_XTUSystemEnabling_t xtuSystemEnablingGet;
    DSL_G997_PowerManagementStatus_t g997PowerManagementStatus;

    uint32 iTCLayer=0;
#ifdef IFX_TR69_VDSL2WAN                                   
    DSL_BandPlanSupport_t stBandPlanSupport;
    DSL_BandPlanStatus_t stBandPlanStatus;
    char * xstrProfiles[] = {"8a","8b","8c","8d","12a","12b","17a","17b","30a",""};
    DSL_LineFeature_t stLineFeature;
    DSL_G997_LineStatusPerBand_t stLineStatusPerBand;
    int32 CurrBandPlan = 0;
#endif

    //DSL_uint8_t SystemVendorID[DSL_G997_LI_MAXLEN_VENDOR_ID];
    DSL_uint8_t G994VendorID[DSL_G997_LI_MAXLEN_VENDOR_ID];
    DSL_IN DSL_DeltDataType_t gDeltDataType = DSL_DELT_DATA_SHOWTIME;
   
    //Enable
    dslphyparams->Enable = uiEnableInternet;

    //Modem Status
    memset(&lineState, 0x00, sizeof(DSL_LineState_t));
    cmd = DSL_FIO_LINE_STATE_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &lineState, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    dslphyparams->LineStatus = lineState.data.nLineState;
    
    //ModulationType
    memset(&xtuSystemEnabling, 0x00, sizeof(DSL_G997_XTUSystemEnabling_t));
    cmd = DSL_FIO_G997_XTU_SYSTEM_ENABLING_STATUS_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &xtuSystemEnabling, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    ifx_get_modulation_type(dslphyparams->DslModType,&xtuSystemEnabling);
  
    //StandardUsed
    ifx_get_standard_used(dslphyparams->DslStandardUsed,&xtuSystemEnabling);

    //LinkEncapsulationSupported
    memset(&xtuSystemEnabling, 0x00, sizeof(DSL_G997_XTUSystemEnabling_t));
    cmd = DSL_FIO_G997_XTU_SYSTEM_ENABLING_CONFIG_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &xtuSystemEnabling, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }

    memset(&stSystemInterfaceConfig, 0x00, sizeof(DSL_SystemInterfaceConfig_t));
    cmd = DSL_FIO_SYSTEM_INTERFACE_CONFIG_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &stSystemInterfaceConfig, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    iTCLayer = stSystemInterfaceConfig.data.nTcLayer;
    ifx_get_linkencap_supported(dslphyparams->DslLinkEncapSupported, &xtuSystemEnabling, iTCLayer);
    ifx_get_standards_supported(dslphyparams->DslStandardsSupported, &xtuSystemEnabling);

    //LineEncoding - ALWAYS Set to "DMT"
    strcpy(dslphyparams->LineEncoding,"DMT");

    //Actual Interleaving Delay, DataPath, Actual Impulse Noise Protection
    memset(&channelStatus, 0x00, sizeof(DSL_G997_ChannelStatus_t));
    channelStatus.nDirection = DSL_DOWNSTREAM;
    cmd = DSL_FIO_G997_CHANNEL_STATUS_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &channelStatus, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    dslphyparams->ActInterleavingDelay = channelStatus.data.ActualInterleaveDelay;
    if(channelStatus.data.ActualInterleaveDelay > 100)
    {
        strcpy(dslphyparams->DataPath,"Interleaved");
    }
    else
    {
        strcpy(dslphyparams->DataPath,"Fast");
    }
    dslphyparams->ActImpNoiseProtection = (int32)channelStatus.data.ActualImpulseNoiseProtection;

    // Power Management State
    memset(&g997PowerManagementStatus, 0x00, sizeof(DSL_G997_PowerManagementStatus_t));
    cmd = DSL_FIO_G997_POWER_MANAGEMENT_STATUS_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &g997PowerManagementStatus, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    dslphyparams->g997PMState = g997PowerManagementStatus.data.nPowerManagementStatus;

    //Interleaver depth
    memset(&g997FramingParamStatusGet, 0x00, sizeof(DSL_G997_FramingParameterStatus_t));
    g997FramingParamStatusGet.nDirection = DSL_DOWNSTREAM;
    cmd = DSL_FIO_G997_FRAMING_PARAMETER_STATUS_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &g997FramingParamStatusGet, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    dslphyparams->InterleaveDepth = g997FramingParamStatusGet.data.nINTLVDEPTH;

    //LineNo.
    dslphyparams->LineNo =1;  

    // Current Data Rate
    memset(&channelStatus, 0x00, sizeof(DSL_G997_ChannelStatus_t));
    channelStatus.nDirection = DSL_DOWNSTREAM;
    cmd = DSL_FIO_G997_CHANNEL_STATUS_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &channelStatus, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    dslphyparams->dsCurrRate = channelStatus.data.ActualDataRate;

    memset(&channelStatus, 0x00, sizeof(DSL_G997_ChannelStatus_t));
    channelStatus.nDirection = DSL_UPSTREAM;
    cmd = DSL_FIO_G997_CHANNEL_STATUS_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &channelStatus, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    dslphyparams->usCurrRate = channelStatus.data.ActualDataRate;

    //upstream Max Data Rate
    //upstream NoiseMargin
    //upstream Signal Attenuation
    //upstream Tx Power
    memset(&lineStatus, 0x00, sizeof(DSL_G997_LineStatus_t));
    cmd = DSL_FIO_G997_LINE_STATUS_GET;
    lineStatus.nDirection = DSL_UPSTREAM;
    lineStatus.nDeltDataType = gDeltDataType;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &lineStatus, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
 
    dslphyparams->usMaxRate = lineStatus.data.ATTNDR;
    dslphyparams->usNoiseMgr = lineStatus.data.SNR;
    dslphyparams->usAttn = lineStatus.data.SATN;
    dslphyparams->usPower = lineStatus.data.ACTATP;  

    //downstream Max Data Rate
    //downstream NoiseMargin
    //downstream Signal Attenuation
    //downstream Tx Power
    memset(&lineStatus, 0x00, sizeof(DSL_G997_LineStatus_t));
    cmd = DSL_FIO_G997_LINE_STATUS_GET;
    lineStatus.nDirection = DSL_DOWNSTREAM;
    lineStatus.nDeltDataType = gDeltDataType;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &lineStatus, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
 
    dslphyparams->dsMaxRate = lineStatus.data.ATTNDR;
    dslphyparams->dsNoiseMgr = lineStatus.data.SNR;
    dslphyparams->dsAttn = lineStatus.data.SATN;
    dslphyparams->dsPower = lineStatus.data.ACTATP;  


    //ATURVendor,ATURCountry
    memset(&lineInventoryGet, 0x00, sizeof(DSL_G997_LineInventory_t));
    lineInventoryGet.nDirection = DSL_NEAR_END;
    cmd = DSL_FIO_G997_LINE_INVENTORY_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &lineInventoryGet, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    for (i = 0; i < DSL_G997_LI_MAXLEN_VENDOR_ID; i++)
    {
        G994VendorID[i] = lineInventoryGet.data.G994VendorID[i];
    }

    //Call DSL_CPE_ArraySPrintF to convert ther array into string
    DSL_CPE_ArraySPrintF(dslphyparams->ATURVendor,(DSL_void_t *)(G994VendorID + 2),(uint16)4,
                (uint16)sizeof(G994VendorID[0]),DSL_ARRAY_FORMAT_HEX);
    DSL_CPE_ArraySPrintF(dslphyparams->ATURCountry,(void *)(G994VendorID),(uint16) 2,
            (uint16)sizeof(G994VendorID[0]),DSL_ARRAY_FORMAT_HEX);


    //ATUCVendor,ATUCCountry
    memset(&lineInventoryGet, 0x00, sizeof(DSL_G997_LineInventory_t));
    lineInventoryGet.nDirection = DSL_FAR_END;
    cmd = DSL_FIO_G997_LINE_INVENTORY_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &lineInventoryGet, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    for (i = 0; i < DSL_G997_LI_MAXLEN_VENDOR_ID; i++)
    {
        G994VendorID[i] = lineInventoryGet.data.G994VendorID[i];
    }

    //Call DSL_CPE_ArraySPrintF to convert ther array into string
    DSL_CPE_ArraySPrintF(dslphyparams->ATUCVendor,(void *)(G994VendorID + 2),(uint16)4,
            (uint16)sizeof(G994VendorID[0]),DSL_ARRAY_FORMAT_HEX);
    DSL_CPE_ArraySPrintF(dslphyparams->ATUCCountry,(void *)(G994VendorID),(uint16)2,
                (uint16)sizeof(G994VendorID[0]),DSL_ARRAY_FORMAT_HEX);

    // TotalStart 
    memset(&pmLineSecCountersTotal, 0x00, sizeof(DSL_PM_LineSecCountersTotal_t));
    pmLineSecCountersTotal.nDirection = DSL_NEAR_END;
    cmd = DSL_FIO_PM_LINE_SEC_COUNTERS_TOTAL_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &pmLineSecCountersTotal, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    dslphyparams->TotalStart = pmLineSecCountersTotal.total.nElapsedTime;

    // Showtimestart 
    memset(&pmLineSecCountersShowTime, 0x00, sizeof(DSL_PM_LineSecCounters_t));
    pmLineSecCountersShowTime.nDirection = DSL_NEAR_END;
    pmLineSecCountersShowTime.nHistoryInterval = 0; /* Most recent ShowTime */
    cmd = DSL_FIO_PM_LINE_SEC_COUNTERS_SHOWTIME_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &pmLineSecCountersShowTime, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    dslphyparams->ShowtimeStart = pmLineSecCountersShowTime.interval.nElapsedTime;

#ifdef CONFIG_FEATURE_IFX_TR69_WANDSLOBJS_FULL
    // CurrentDayStart
    memset(&pmLineSecCounters, 0x00 , sizeof(DSL_PM_LineSecCounters_t));
    pmLineSecCounters.nDirection = DSL_NEAR_END;  
    cmd = DSL_FIO_PM_LINE_SEC_COUNTERS_1DAY_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &pmLineSecCounters, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    dslphyparams->CurrentDayStart = pmLineSecCounters.interval.nElapsedTime;

    // QuarterHourStart
    memset(&pmLineSecCounters, 0x00 , sizeof(DSL_PM_LineSecCounters_t));
    pmLineSecCounters.nDirection = DSL_NEAR_END;
    cmd = DSL_FIO_PM_LINE_SEC_COUNTERS_15MIN_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &pmLineSecCounters, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    dslphyparams->QuarterHourStart = pmLineSecCounters.interval.nElapsedTime;
    // LastShowtime
    memset(&pmLineSecCountersShowTime, 0x00, sizeof(DSL_PM_LineSecCounters_t));
    pmLineSecCountersShowTime.nDirection = DSL_NEAR_END;
    pmLineSecCountersShowTime.nHistoryInterval = 1; /* Second most recent ShowTime */
    cmd = DSL_FIO_PM_LINE_SEC_COUNTERS_SHOWTIME_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &pmLineSecCountersShowTime, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
        dslphyparams->LastShowtimeStart = dslphyparams->ShowtimeStart;
    }
    else
        dslphyparams->LastShowtimeStart = pmLineSecCountersShowTime.interval.nElapsedTime;
#endif
    //ATURANSIStd
    memset(&xtuSystemEnablingGet, 0x00 , sizeof(DSL_G997_XTUSystemEnabling_t));
    cmd = DSL_FIO_G997_XTU_SYSTEM_ENABLING_CONFIG_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &xtuSystemEnablingGet, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    dslphyparams->ATURANSIStd = xtuSystemEnablingGet.data.XTSE[0];   // Further clarifications required

    //ATURANSIRev
    memset(&xtuSystemEnablingGet, 0x00 , sizeof(DSL_G997_XTUSystemEnabling_t));
    cmd = DSL_FIO_G997_XTU_SYSTEM_ENABLING_STATUS_GET; 
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &xtuSystemEnablingGet, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    dslphyparams->ATURANSIRev = xtuSystemEnablingGet.data.XTSE[0];   // Further clarifications required

    //ATUCANSIStd
    memset(&lineInventoryGet, 0x00 , sizeof(DSL_G997_LineInventory_t));
    lineInventoryGet.nDirection = DSL_FAR_END;
    cmd = DSL_FIO_G997_LINE_INVENTORY_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &lineInventoryGet, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    dslphyparams->ATUCANSIStd = lineInventoryGet.data.XTSECapabilities[0];    // Further clarifications required
 
    //ATUCANSIRev
    memset(&xtuSystemEnablingGet, 0x00 , sizeof(DSL_G997_XTUSystemEnabling_t));
    cmd = DSL_FIO_G997_XTU_SYSTEM_ENABLING_STATUS_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &xtuSystemEnablingGet, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    dslphyparams->ATUCANSIRev = xtuSystemEnablingGet.data.XTSE[0];    // Further clarifications required

#ifdef IFX_TR69_VDSL2WAN                                   
    //band plan,profile info
    memset(&stBandPlanStatus, 0x00, sizeof(DSL_BandPlanStatus_t));
    cmd = DSL_FIO_BAND_PLAN_STATUS_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &stBandPlanStatus, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    CurrBandPlan = stBandPlanStatus.data.nBandPlan;
    strcpy(dslphyparams->CurrentProfile, xstrProfiles[stBandPlanStatus.data.nProfile]);

    //Allowed Profiles
    memset(&stBandPlanSupport, 0x00, sizeof(DSL_BandPlanSupport_t));
    cmd = DSL_FIO_BAND_PLAN_SUPPORT_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &stBandPlanSupport, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    memset(dslphyparams->AllowedProfiles, 0x00, sizeof(dslphyparams->AllowedProfiles));
    if(CurrBandPlan != DSL_BANDPLAN_NA && CurrBandPlan != DSL_BANDPLAN_LAST)
    {
        for(i=0; i<DSL_PROFILE_LAST; i++)
        {
            if(stBandPlanSupport.data.bSupported[CurrBandPlan][i] == 1)
            {
                if ((strlen(dslphyparams->AllowedProfiles) + strlen(xstrProfiles[i]) + 1) < sizeof(dslphyparams->AllowedProfiles))
                strcat(dslphyparams->AllowedProfiles,xstrProfiles[i]);
            }
        }
    }
    /*TRELLIS - Downstream*/
    memset(&stLineFeature,0x00,sizeof(DSL_LineFeature_t));
    stLineFeature.nDirection = DSL_DOWNSTREAM;
    cmd = DSL_FIO_LINE_FEATURE_STATUS_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &stLineFeature, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    dslphyparams->TRELLISds = stLineFeature.data.bTrellisEnable;
    dslphyparams->ACTSNRMODEds = stLineFeature.data.bVirtualNoiseSupport;
    /*Upstream*/
    memset(&stLineFeature,0x00,sizeof(DSL_LineFeature_t));
    stLineFeature.nDirection = DSL_UPSTREAM;
    cmd = DSL_FIO_LINE_FEATURE_STATUS_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &stLineFeature, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    dslphyparams->TRELLISus = stLineFeature.data.bTrellisEnable;
    dslphyparams->ACTSNRMODEus = stLineFeature.data.bVirtualNoiseSupport;
 
    /*SNR Info - Downstream*/    
    memset(&stLineStatusPerBand, 0x00, sizeof(DSL_G997_LineStatusPerBand_t));
    stLineStatusPerBand.nDirection = DSL_DOWNSTREAM;
    cmd = DSL_FIO_G997_LINE_STATUS_PER_BAND_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &stLineStatusPerBand, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    dslphyparams->SNRMpbds[0] = '\0';
    snprintf(dslphyparams->SNRMpbds,IFX_DSL_COMMON_STR_LEN-1,"%d",stLineStatusPerBand.data.SNR[0]);
    dslphyparams->SNRMpbds[IFX_DSL_COMMON_STR_LEN-1] = '\0';
    for(i=1; i<DSL_G997_MAX_NUMBER_OF_BANDS; i++)
    {
        snprintf(dslphyparams->SNRMpbds,IFX_DSL_COMMON_STR_LEN-1,"%s,%d",dslphyparams->SNRMpbds,stLineStatusPerBand.data.SNR[i]);
        dslphyparams->SNRMpbds[IFX_DSL_COMMON_STR_LEN-1] = '\0';
    }

    /*SNR Info - Upstream*/    
    memset(&stLineStatusPerBand, 0x00, sizeof(DSL_G997_LineStatusPerBand_t));
    stLineStatusPerBand.nDirection = DSL_UPSTREAM;
    cmd = DSL_FIO_G997_LINE_STATUS_PER_BAND_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *) &stLineStatusPerBand, flags);
    if(ret < IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "IOCTL Failed [%s,%d] %d!\n",__FUNCTION__,__LINE__, ret);
    }
    dslphyparams->SNRMpbus[0] = '\0';
    snprintf(dslphyparams->SNRMpbus,IFX_DSL_COMMON_STR_LEN-1,"%d",stLineStatusPerBand.data.SNR[0]);
    dslphyparams->SNRMpbus[IFX_DSL_COMMON_STR_LEN-1] = '\0';
    for(i=1; i<DSL_G997_MAX_NUMBER_OF_BANDS; i++)
    {
        snprintf(dslphyparams->SNRMpbus,IFX_DSL_COMMON_STR_LEN-1,"%s,%d",dslphyparams->SNRMpbus,stLineStatusPerBand.data.SNR[i]);
        dslphyparams->SNRMpbus[IFX_DSL_COMMON_STR_LEN-1] = '\0';
    }

#endif 
    return IFX_CWMP_SUCCESS;
   
}

#endif

/* 
** =============================================================================
**   Function Name    : IFX_WanDslInterfaceConfigGetValue
**   Description        : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes                : 
**
** ============================================================================
*/
static int32 
IFX_WanDslInterfaceConfigGetValue(IN OperInfo *pxOperInfo,INOUT ParamVal *pxGetParamVal,
                                IN uint32 iElements)
{
    /*GET PARAMETER VALUES
    **Get Object OID(skip parameter ID) from the first 
    **element in the array.Get Cpeid for this Object OID

    **Get the object from the system using a Platform API
    **with cpeid 
    
    **Do reverse mapping to convert system values into TR69
    **Values.After conversion stores the values in temp storage

    **While assigning the values as per request store the 
    **values in heap and assign the ptr to the struct
    **Return all the values 
    */
    
    uint32 i=0;
    int32 iParamId=0;
    uint32 uiParamPos=0;
    int32 iRet=0/*, outFlag=IFX_F_DEFAULT*/;
    uint32 uiMode=IFX_CHK_VALUE_BASED;
    char8 sTmpBuff[PARAMVALUE_LEN]={0};
    DSL_LINE_PHY_PROPERTIES xDslphys;
    //char8 encap_request[32]={0};
    WAN_PHY_CFG xWanPhy;

    memset(&xWanPhy, 0x00, sizeof(xWanPhy)); 
    memset(&xDslphys, 0x00, sizeof(xDslphys));    
    //Fill the parameters and pass it back
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
    iRet = ifx_get_dsl_phy_properties(&xDslphys);
    if(iRet != IFX_SUCCESS)
        goto errorHandler;
    
#endif
    //Get the WanIpConParamPos 
    uiParamPos = IFX_GetParamIdPos(pxGetParamVal->iaOID);
            
    for(i=0;i < iElements; i++)
    {
    
        iParamId = pxGetParamVal->iaOID[uiParamPos];
    
        // Malloc and assign the pointer to the Value attr of struct 
        pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
        if(pxGetParamVal->Value == NULL)
        {
            iRet = ERR_OUT_OF_MEMORY; 
            goto errorHandler;
        }
        memset(sTmpBuff,0x00,sizeof(sTmpBuff));

        switch(iParamId)
        {

            // Convert the value - reverse mapping
            // Assign the correct value to the Value attr    
            case OID_IGD_WAND_WANDSLIC_ENABLE:
                sprintf(sTmpBuff,"%d",xDslphys.Enable);
                strcpy(pxGetParamVal->Value,sTmpBuff);                
                break;     

            case OID_IGD_WAND_WANDSLIC_STATUS:
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
                if(IFX_RevMappingValues(saxDslLinkStatus,10,
                    (void *)&(xDslphys.LineStatus),
                    (void *)(pxGetParamVal->Value)) !=IFIN_CWMP_SUCCESS)
                {
                    strcpy(pxGetParamVal->Value, "Error");
                }
#endif
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_LINKENCAPSULATIONSUPPORTED:
                strncpy(pxGetParamVal->Value,xDslphys.DslLinkEncapSupported,PARAMVALUE_LEN-1);
                ((char *)(pxGetParamVal->Value))[PARAMVALUE_LEN-1] = '\0';
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_LINKENCAPSULATIONREQUESTED:
                memset(&xWanPhy, 0x00, sizeof(WAN_PHY_CFG)); 
                ((char8 *)pxGetParamVal->Value)[0] = '\0'; 

                if((ifx_get_wan_phy_cfg(&xWanPhy)) == IFX_SUCCESS)
                {
                    strcpy(pxGetParamVal->Value, xWanPhy.tr69_encaprequested);
                }

                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_LINKENCAPSULATIONUSED:
                //Get current running mode from rc.conf
                if((ifx_get_wan_phy_cfg(&xWanPhy)) == IFX_SUCCESS)
                {
                    if((xWanPhy.phy_mode != WAN_PHY_MODE_ADSL2) && (xWanPhy.phy_mode != WAN_PHY_MODE_VDSL2))
                    {
                        ((char8 *)pxGetParamVal->Value)[0] = '\0';
                    }
                    else
                    {
                        /*Set the Phy Mode*/
                        if(xWanPhy.phy_mode == WAN_PHY_MODE_ADSL2)
                        {
                            sprintf(sTmpBuff,"G.992.3");
                        }
                        else if(xWanPhy.phy_mode == WAN_PHY_MODE_VDSL2)
                        {
                            sprintf(sTmpBuff,"G.993.2");
                        }
                        /*Set the TC*/
                        if(xWanPhy.wan_tc == WAN_TC_ATM)
                        {
                            sprintf(sTmpBuff, "%s_Annex_K_ATM",sTmpBuff);
                        }
                        else if(xWanPhy.wan_tc == WAN_TC_PTM)
                        {
                            sprintf(sTmpBuff, "%s_Annex_K_PTM",sTmpBuff);
                        }
                        strcpy(pxGetParamVal->Value,sTmpBuff);
                        IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                    }
                }
                else
                {
                    ((char8 *)pxGetParamVal->Value)[0] = '\0';
                }
                break;

            case OID_IGD_WAND_WANDSLIC_STANDARDSSUPPORTED:
                IFX_CWMP_FREE(pxGetParamVal->Value);
                pxGetParamVal->Value = IFIN_CWMP_MALLOC(IFX_DSL_STANDARDS_SUPPORTED_LEN);
                if(pxGetParamVal->Value == NULL)
                {
                    iRet = ERR_OUT_OF_MEMORY;
                    goto errorHandler;
                }

                strcpy(pxGetParamVal->Value,xDslphys.DslStandardsSupported);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_MODULATIONTYPE:
                strcpy(pxGetParamVal->Value,xDslphys.DslModType);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_STANDARDUSED:
                strcpy(pxGetParamVal->Value,xDslphys.DslStandardUsed);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_LINEENCODING:
                strcpy(pxGetParamVal->Value,xDslphys.LineEncoding);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;
#ifdef IFX_TR69_VDSL2WAN                                   
            case OID_IGD_WAND_WANDSLIC_ALLOWEDPROFILES:
                strcpy(pxGetParamVal->Value, xDslphys.AllowedProfiles);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_CURRENTPROFILE:
                strcpy(pxGetParamVal->Value, xDslphys.CurrentProfile);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_UPBOKLE:
                strcpy(pxGetParamVal->Value, "0");
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                break;
#endif
            case OID_IGD_WAND_WANDSLIC_DATAPATH:
                strcpy(pxGetParamVal->Value,xDslphys.DataPath);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;
                
            case OID_IGD_WAND_WANDSLIC_INTERLEAVEDEPTH:
                sprintf(sTmpBuff,"%d",xDslphys.InterleaveDepth);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;
                
#ifdef IFX_TR69_VDSL2WAN                                   
            case OID_IGD_WAND_WANDSLIC_TRELLISDS:
                sprintf(sTmpBuff,"%d",xDslphys.TRELLISds);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_TRELLISUS:
                sprintf(sTmpBuff,"%d",xDslphys.TRELLISus);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_ACTSNRMODEDS:
                 /* ACTSNRMODEds is boolean, 0-False, 1-true
                  TR98 - 1 indicates the virtual noise mechanism is not in use,
                  2 indicates the virtual noise mechanism is in use*/
                sprintf(sTmpBuff,"%d",xDslphys.ACTSNRMODEds+1);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_ACTSNRMODEUS:
                 /* ACTSNRMODEus is boolean, 0-False, 1-true
                  TR98 - 1 indicates the virtual noise mechanism is not in use,
                  2 indicates the virtual noise mechanism is in use*/
                sprintf(sTmpBuff,"%d",xDslphys.ACTSNRMODEus+1);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_ACTUALCE:
                sprintf(sTmpBuff, "5");
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_SNRMPBDS:
                sprintf(sTmpBuff, "%s",xDslphys.SNRMpbds);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_SNRMPBUS:
                sprintf(sTmpBuff, "%s",xDslphys.SNRMpbus);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;
#endif
            case OID_IGD_WAND_WANDSLIC_LINENUMBER:
                sprintf(sTmpBuff,"%d",xDslphys.LineNo);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_UPSTREAMCURRRATE:
                sprintf(sTmpBuff,"%d",xDslphys.usCurrRate);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_DOWNSTREAMCURRRATE:
                sprintf(sTmpBuff,"%d",xDslphys.dsCurrRate);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_UPSTREAMMAXRATE:
                sprintf(sTmpBuff,"%d",xDslphys.usMaxRate);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_DOWNSTREAMMAXRATE:
                sprintf(sTmpBuff,"%d",xDslphys.dsMaxRate);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_UPSTREAMNOISEMARGIN:
                sprintf(sTmpBuff,"%d",xDslphys.usNoiseMgr);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_DOWNSTREAMNOISEMARGIN:
                sprintf(sTmpBuff,"%d",xDslphys.dsNoiseMgr);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_UPSTREAMATTENUATION:
                sprintf(sTmpBuff,"%d",xDslphys.usAttn);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

           case OID_IGD_WAND_WANDSLIC_DOWNSTREAMATTENUATION:
                sprintf(sTmpBuff,"%d",xDslphys.dsAttn);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_UPSTREAMPOWER:
                sprintf(sTmpBuff,"%d",xDslphys.usPower);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_DOWNSTREAMPOWER:
                sprintf(sTmpBuff,"%d",xDslphys.dsPower);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_ATURVENDOR:
                strcpy(pxGetParamVal->Value,xDslphys.ATURVendor);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_ATURCOUNTRY:
                strcpy(pxGetParamVal->Value,xDslphys.ATURCountry);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_ATUCVENDOR:
                strcpy(pxGetParamVal->Value,xDslphys.ATUCVendor);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_ATUCCOUNTRY:
                strcpy(pxGetParamVal->Value,xDslphys.ATUCCountry);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_TOTALSTART:
                sprintf(sTmpBuff,"%d",xDslphys.TotalStart);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_SHOWTIMESTART:
                sprintf(sTmpBuff,"%d",xDslphys.ShowtimeStart);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;
#ifdef CONFIG_FEATURE_IFX_TR69_WANDSLOBJS_FULL
            case OID_IGD_WAND_WANDSLIC_CURRENTDAYSTART:
                sprintf(pxGetParamVal->Value,"%u",xDslphys.CurrentDayStart);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;  
            case OID_IGD_WAND_WANDSLIC_LASTSHOWTIMESTART:
                sprintf(pxGetParamVal->Value,"%u",xDslphys.LastShowtimeStart);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;   
            case OID_IGD_WAND_WANDSLIC_QUARTERHOURSTART:
                sprintf(pxGetParamVal->Value,"%u",xDslphys.QuarterHourStart);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;
#endif
            case OID_IGD_WAND_WANDSLIC_ATURANSISTD:
                sprintf(pxGetParamVal->Value,"%u",xDslphys.ATURANSIStd);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_ATURANSIREV:
                sprintf(pxGetParamVal->Value,"%u",xDslphys.ATURANSIRev);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_ATUCANSISTD:
                sprintf(pxGetParamVal->Value,"%u",xDslphys.ATUCANSIStd);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANDSLIC_ATUCANSIREV:
                sprintf(pxGetParamVal->Value,"%u",xDslphys.ATUCANSIRev);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;
            case OID_IGD_WAND_WANDSLIC_ACTUALINTERLEAVINGDELAY:
                sprintf(pxGetParamVal->Value,"%u",xDslphys.ActInterleavingDelay);
                break;
            case OID_IGD_WAND_WANDSLIC_ACTINP:
                sprintf(pxGetParamVal->Value,"%d",xDslphys.ActImpNoiseProtection);
                break;
            case OID_IGD_WAND_WANDSLIC_POWERMANAGEMENTSTATE:
                sprintf(pxGetParamVal->Value,"L%d",xDslphys.g997PMState);
                break;
            default:
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "Invalid param id %d!\n", iParamId);
            pxGetParamVal->iFaultCode=ERR_INVAL_PARAMETER_NAME;
            break;
        }

                            
            ++pxGetParamVal;
    }

    return IFX_CWMP_SUCCESS;
        
errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed ParamId=%d!\n", __func__, __LINE__,iParamId);
    return iRet;

}


/* 
** =============================================================================
**   Function Name    : IFX_WanDslInterfaceConfigSetValue
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

static int32
IFX_WanDslInterfaceConfigSetValue(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
                            IN int32 iElements)
{

    int32 iRet=IFX_CWMP_SUCCESS;
    uint32 i=0;
    uint32 uiParamPos=0;
    ParamVal *pxTmpPramVal=NULL;
    WAN_PHY_CFG xWanPhy;
    //char8 pSecBuf[64] = {0};

    memset(&xWanPhy, 0x00, sizeof(xWanPhy));

    uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);
    pxTmpPramVal = paxParamVal;
    for (i=0; i < iElements; i++) 
    {
        switch(pxTmpPramVal->iaOID[uiParamPos])
        {
            
            case OID_IGD_WAND_WANDSLIC_ENABLE:
                /* Check if the string fits in the buffer */
                /* TBI:: Call a MAPI which will disable the internet
                   Connection */   
                if(IFX_FwdMappingValues(gaxEnable,4,
        	            (void *)(pxTmpPramVal->Value),
	                    (void *)&(uiEnableInternet)) !=IFIN_CWMP_SUCCESS)
                {
                    iRet=ERR_CWMP_INVAL_PARAM_VAL;
                    goto errorHandler;
                }
                break;

            case OID_IGD_WAND_WANDSLIC_LINKENCAPSULATIONREQUESTED:
                //Get current running mode
                memset(&xWanPhy, 0x00, sizeof(WAN_PHY_CFG)); 
                if((ifx_get_wan_phy_cfg(&xWanPhy)) == IFX_SUCCESS)
                {
                    /*CHECK: Is it ADSL/VDSL mode*/
                    if((xWanPhy.phy_mode == WAN_PHY_MODE_ADSL2) || (xWanPhy.phy_mode == WAN_PHY_MODE_VDSL2))
                    {
                        /*set wanphy_mode, wanphy_tc.
                          set_wanphy_mode() --> takes care of set default connection, reboot.*/
                        if(strcmp(paxParamVal->Value, "G.992.3_Annex_K_ATM") == 0)
                        {
                            xWanPhy.set_phy_mode = WAN_PHY_MODE_ADSL2;
                            xWanPhy.set_wan_tc = WAN_TC_ATM;
                        }
                        else if(strcmp(paxParamVal->Value, "G.992.3_Annex_K_PTM") == 0)
                        {
                            xWanPhy.set_phy_mode = WAN_PHY_MODE_ADSL2;
                            xWanPhy.set_wan_tc = WAN_TC_PTM;
                        }
                        else if(strcmp(paxParamVal->Value, "G.993.2_Annex_K_ATM") == 0)
                        {
                            xWanPhy.set_phy_mode = WAN_PHY_MODE_VDSL2;
                            xWanPhy.set_wan_tc = WAN_TC_ATM;
                        }
                        else if(strcmp(paxParamVal->Value, "G.993.2_Annex_K_PTM") == 0)
                        {
                            xWanPhy.set_phy_mode = WAN_PHY_MODE_VDSL2;
                            xWanPhy.set_wan_tc = WAN_TC_PTM;
                        }
                        else if(strcmp(paxParamVal->Value, "G.994.1") == 0)
                        {
                            xWanPhy.set_phy_mode = WAN_PHY_MODE_AUTO;
                            xWanPhy.set_wan_tc = WAN_TC_UNCONFIGURED;
                        }
                    }
                    strcpy(xWanPhy.tr69_encaprequested, (char8 *)pxTmpPramVal->Value);
                    ifx_set_wan_phy_cfg(&xWanPhy);
                }
                break;

            default:
                (pxTmpPramVal[i]).iFaultCode = ERR_INVAL_PARAMETER_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
                goto errorHandler;
        }
        pxTmpPramVal++;
    }

    return IFX_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
               "[%s:%s:%d] [%d] WanDslInterfaceConfig SetParamValues failed "
                                   ,__FILE__, __func__, __LINE__, iRet);
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslInterfaceConfigAddObj
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanDslInterfaceConfigAddObj(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
                            IN int32 iElements)
{

return IFX_CWMP_FAILURE;

}


/* 
** =============================================================================
**   Function Name    : IFX_WanDslInterfaceConfigSetCommit
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanDslInterfaceConfigSetCommit()
{
    return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslInterfaceConfigSetUndo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanDslInterfaceConfigSetUndo()
{
    return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslInterfaceConfigSetDelete
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanDslInterfaceConfigSetDelete(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
                            IN int32 iElements, OUT void **ppxParamStructRet,
                                                   OUT int32 * piNumRetElem)
{
    return IFX_CWMP_FAILURE;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslInterfaceConfigSetFree
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanDslInterfaceConfigSetFree()
{
    return IFX_CWMP_SUCCESS;
}


/* 
** =============================================================================
**   Function Name    : IFX_WanDslInterfaceConfigSetAttr
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

static int32
IFX_WanDslInterfaceConfigSetAttr(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
                            IN int32 iElements)
{
    uint32 iRet=IFX_CWMP_SUCCESS,i=0;
    OperInfo xOpInfo;
    
    xOpInfo.iCaller = pxOpInfo->iCaller;
    xOpInfo.iOper= OP_GETVAL;
    xOpInfo.iSubOper= OP_GETVAL_NORMAL;
    
    iRet = IFX_WanDslInterfaceConfigGetValue(&xOpInfo,pxParamVal, iElements);
        if(iRet != IFX_CWMP_SUCCESS)
            goto errorFreeHandler;
    
    iRet = IFX_SetAttributesInfo(pxOpInfo,pxParamVal, iElements);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorFreeHandler;

    errorFreeHandler:
        for(i=0; i < iElements; i++)
        IFX_CWMP_FREE(pxParamVal[i].Value);
        
                if (iRet)
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed!\n", __func__, __LINE__);
        return iRet;
}



/* 
** =============================================================================
**   Function Name    : IFX_WanDslInterfaceConfig_Init
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_WanDslInterfaceConfig_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    
    /* Register the WanDslInterfaceConfig module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_DSL_INTF_CONFIG_OBJ, IFX_WanDslInterfaceConfig);
    
    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "Unable to Register %s with Object Model\n",
                     IFX_DSL_INTF_CONFIG_OBJ);
        goto errorHandler;
    }


    errorHandler:
            return iRet;
}

/*********************************************************************************
*  Function Name    :  IFX_WanDslInterfaceConfig   
      *  Description    :  This function handles all the sub-states inside
                      a GET/SET operation.If it is a GET it allocates the 
               array(Name,Value pairs) and retruns the values.
               If it is a SET controller allocates the array and
               passes the values to this function.It calls 
               respective internal functions which in turn calls 
               respective Platform APIs.
                                                                                                 
*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
                                 Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has 
                                       Name,Value,etc
                    IN          int32           iElements;    No. of Elements
            OUT            void *           ppParamRet;   same as ParamStruc
            OUT         int32 *        piNumRetElem; No. of elements                                         
*  Return Value        : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes               :
***********************************************************************************/
int32
IFX_WanDslInterfaceConfig(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                IN int32 iElements, OUT void **ppaxParamArrRet, OUT int32 *piNumRetElem)
{
     
   //It calls the respective internal functions which handles resp. sub-operation
   
   //Set-Operation  
   //controller should pass the entire array during all the SET-sub_operations
   //It should handles only single get/set of instance at any point of time
   //It does not handle partial path
   //It won't handle multiple instances of the same object/module
   //at any point of time.

    
    int32 iRet = 0;
    ParamVal *paxParamArr = (ParamVal *)paxParameterArr;
    int32 iCnt = 0;

    switch (pxOperInfo->iOper) 
    {
        //Get the object values
           case OP_GETVAL:
                if((iRet = IFX_WanDslInterfaceConfigGetValue(pxOperInfo, paxParamArr,
                                        iElements)) != IFX_CWMP_SUCCESS) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
              goto errorHandler;
                }
                break;
            case OP_SETVAL:
            {

                //Set the obj values
                switch (pxOperInfo->iSubOper) 
                {
                               
                    case OP_SETVAL_ADD:
                        if((iRet= IFX_WanDslInterfaceConfigAddObj(pxOperInfo,paxParamArr,
			                                      iElements))!=IFX_CWMP_SUCCESS)
                        {
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d OP_SETVAL_ADD failed!\n", __func__, __LINE__);
                            goto errorHandler;
                        }
                        break;
                      
                    case OP_SETVAL_VALIDATE:
                    case OP_SETVAL_CHK_MODIFY_DEP:
                        break;
                      
                    case OP_SETVAL_MODIFY:
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d]\n", __FILE__, __func__, __LINE__);
                        if((iRet = IFX_WanDslInterfaceConfigSetValue(pxOperInfo,paxParamArr,
                    			                    iElements)) != IFX_CWMP_SUCCESS)
                        {
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_VALUE failed!\n", __func__, __LINE__);
                            goto errorHandler;
                        }
                        break;
                            
                    case OP_SETVAL_COMMIT:
                        if((iRet = IFX_WanDslInterfaceConfigSetCommit(pxOperInfo,paxParamArr,
                    				                    iElements)) != IFX_CWMP_SUCCESS)
                        {
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_COMMIT failed!\n", __func__, __LINE__);
                            goto errorHandler;
                        }
                        break;
                    case OP_SETVAL_UNDO:
                        if((iRet =IFX_WanDslInterfaceConfigSetUndo(pxOperInfo, paxParamArr,
                    			                    iElements)) != IFX_CWMP_SUCCESS)
                        {
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_UNDO failed!\n", __func__, __LINE__);
                            goto errorHandler;
                        }
                        break;
                    case OP_SETVAL_CHK_DEL_DEP:
                    case OP_SETVAL_CHK_DEL_ALLOWED:
                    case OP_SETVAL_DELETE:
                        if((iRet= IFX_WanDslInterfaceConfigSetDelete(pxOperInfo, paxParamArr,
                                        iElements, ppaxParamArrRet,
                                        piNumRetElem))!= IFX_CWMP_SUCCESS) 
                        {
                            switch(pxOperInfo->iSubOper)
                            {    
                                case OP_SETVAL_CHK_DEL_DEP:
                                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
                                    goto errorHandler;
                                case OP_SETVAL_CHK_DEL_ALLOWED:
                                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
                                    goto errorHandler;
                                case OP_SETVAL_DELETE:
                                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
                                    goto errorHandler;
                            }
                        }
                        break;
                    case OP_SETVAL_FREE:
                        IFX_WanDslInterfaceConfigSetFree(pxOperInfo);
                        break;

                    case OP_SETVAL_ATTRINFO:
                        if((iRet =IFX_WanDslInterfaceConfigSetAttr(pxOperInfo, paxParamArr,
                        			                iElements)) != IFX_CWMP_SUCCESS)
                        {
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d OP_SETVAL_ATTRINFO failed!\n", __func__, __LINE__);
                            goto errorHandler;
                        }
                        break;
                            
                    default:
                        break;
                }
                break;
            }
            case OP_PARAM_VALIDATE:
            {
                //IGD.WD.2. or IGD.WD.3.
                if(((paxParamArr->iaOID[2]) == WAN_DEVICE_MII0) || ((paxParamArr->iaOID[2]) == WAN_DEVICE_MII1))
                {
                    /* Set the fault code to Error */
                    for(iCnt = 0; iCnt < iElements; iCnt++)
                    {
                        paxParamArr[iCnt].iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
                    }
                }
                break; 
            }
            default:
            {
                break;
            }
    }
    return IFX_CWMP_SUCCESS;

errorHandler:
    return IFX_CWMP_FAILURE;
            
}
