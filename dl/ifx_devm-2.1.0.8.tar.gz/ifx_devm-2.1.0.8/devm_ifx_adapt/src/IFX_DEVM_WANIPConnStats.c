/* 
** =============================================================================
**   FILE NAME        : IFX_WanIpConnStats.c
**   PROJECT          : TR69
**   MODULES          : WanIpConnStats
**   DATE             : 21-06-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This module handles ADD/DEL/GET/SET RPCs of 
**                      WanIpConnStats. When controller calls this module it
**                      calls respective Platform/Object APIs to handle GET/SET 
**                      of WanIpConnStats specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author        $Comment
**   28-04-06         TR69 team      Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
//#include <sys/socket.h>
//#include <netinet/in.h>
//#include <arpa/inet.h>

#include "IFX_DEVM_WANIPConnStats.h"
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
 

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;
#define IFX_WAN_IP_STATS_OBJ "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANIPConnection.1.Stats."
#define IFX_WAN_PPP_STATS_OBJ "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.1.Stats."

/*
#define WAN_IP_NO_DEP_OIDS 2
#define WAN_IP_PORT_MAP_TCP 1
#define WAN_IP_PORT_MAP_UDP 2
#define NO_WAN_CON_DEVICE 16
*/

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/




/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/

extern int32 IFX_GetWanObj(WAN_CONN_CFG *ppxWanConn, uint32 iCpeid);
extern Map_Value gaxEnable[]; 

//static uint32 uiNoOf_PPPConnections=0;
//static uint32 uiNoOf_IPConnections=0;

/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/





/* 
** =============================================================================
**   Function Name    : IFX_WanIpConnStatsGetValue
**   Description        : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes                : 
**
** ============================================================================
*/
static int32 
IFX_WanIpConnStatsGetValue(IN OperInfo *pxOperInfo,INOUT ParamVal *pxGetParamVal,
								IN uint32 iElements)
{
	/*GET PARAMETER VALUES
	**Get Object OID(skip parameter ID) from the first 
	**element in the array.Get Cpeid for this Object OID

	**Get the object from the system using a Platform API
	**with cpeid 
	
	**Do reverse mapping to convert system values into TR69
	**Values.After conversion stores the values in temp storage

	**While assigning the values as per request store the 
	**values in heap and assign the ptr to the struct
	**Return all the values 
	*/
	
	//uint32 iCpeid=0,
	uint32 i=0;
	int32 iParamId=0;
	uint32 uiParamPos=0;
	int32 iRet=0;
	uint32 uiCpeid;
	uint32 uiMode=IFX_CHK_VALUE_BASED;
	IFX_ID iid;
#ifdef MIPSTARGET 
	int32 wan_index=-1;
	char8 *iface=NULL;
	uint32 flags=IFX_F_GET_ANY;
#endif
	IF_STATS if_stats;
	WAN_CONN_CFG xWanConn;
	uint32 iConType=0;

	//Memset the structs
	memset(&iid,0x00,sizeof(IFX_ID));
	memset(&if_stats,0x00,sizeof(IF_STATS));
	memset(&xWanConn,0x00, sizeof(xWanConn));

	WAN_CONN_CFG *pxWanConn=&xWanConn;

	//Get the Cpeid 
	iRet = IFX_GetCpeId(pxGetParamVal->iaOID,&uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;


        if(pxGetParamVal->iaOID[5] == OID_IGD_WAND_WANCD_WANPPPC)
	{
		pxWanConn->type = WAN_TYPE_PPP;

		strcpy(iid.cpeId.secName, "wan_ppp");
		iConType = PPP_CON_TYPE;

	}
	else
	{
		pxWanConn->type = WAN_TYPE_IP;

		strcpy(iid.cpeId.secName, "wan_ip");
		iConType = IP_CON_TYPE;
	}
	//Get the WanObject to know the status
	iRet = IFX_GetWanObj(pxWanConn, uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

 	iid.cpeId.Id = uiCpeid;

#ifdef MIPSTARGET 

	if(iConType == IP_CON_TYPE)
	{
		//If it is disabled skip getting from system.
		if(pxWanConn->wancfg.ip.wan_cfg.f_enable == IFX_ENABLED)
		{	
			//Call the MAPI to get the stats
		
			iRet =  ifx_get_wan_if_stats( &iid, wan_index, iface, &if_stats, flags);
			if(iRet != IFX_SUCCESS)
			{
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d ifx_get_wan_if_stats failed!\n", __func__, __LINE__);
			goto errorHandler;
			}
		}
	} else if (iConType == PPP_CON_TYPE)
	{
		//If it is disabled skip getting from system.
		if(pxWanConn->wancfg.ppp.wan_cfg.f_enable == IFX_ENABLED)
		{	
			//Call the MAPI to get the stats
			
			iRet =  ifx_get_wan_if_stats( &iid, wan_index, iface, &if_stats, flags);
			if(iRet != IFX_SUCCESS)
			{
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d ifx_get_wan_if_stats failed!\n", __func__, __LINE__);
			goto errorHandler;
			}
		}
	}	
#endif

	//Fill the parameters and pass it back
	
	//Get the WanIpConParamPos 
	uiParamPos = IFX_GetParamIdPos(pxGetParamVal->iaOID);

			
	for(i=0;i < iElements; i++)
	{
	
		iParamId = pxGetParamVal->iaOID[uiParamPos];
	
		// Malloc and assign the pointer to the Value attr of struct 
		pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);

               if(pxGetParamVal->Value==NULL)
               {
	 	goto errorHandler;
		}
		switch(iParamId)
		{

			// Convert the value - reverse mapping
			// Assign the correct value to the Value attr	
	    		case OID_IGD_WAND_WANCD_WANIPC_S_ETHERNETBYTESRECEIVED:

				sprintf(pxGetParamVal->Value,"%lu",
					if_stats.rx_bytes);
				
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				
				break;	 
					
	    		case OID_IGD_WAND_WANCD_WANIPC_S_ETHERNETBYTESSENT:
				sprintf(pxGetParamVal->Value,"%lu",
					if_stats.tx_bytes);

				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				
				break;
			case OID_IGD_WAND_WANCD_WANIPC_S_ETHERNETPACKETSRECEIVED:
				sprintf(pxGetParamVal->Value,"%lu",
					if_stats.rx_pkts);

				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				
				break;
			case OID_IGD_WAND_WANCD_WANIPC_S_ETHERNETPACKETSSENT:
				sprintf(pxGetParamVal->Value,"%lu",
					if_stats.tx_pkts);

				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				
				break;
			case OID_IGD_WAND_WANCD_WANIPC_S_ETHERNETERRORSSENT:
				sprintf(pxGetParamVal->Value,"%lu",
					if_stats.tx_error_pkts);
			
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                               
                                break;
			case OID_IGD_WAND_WANCD_WANIPC_S_ETHERNETERRORSRECEIVED:
				sprintf(pxGetParamVal->Value,"%lu",
					if_stats.rx_error_pkts);

                                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);

                                break;
			case OID_IGD_WAND_WANCD_WANIPC_S_ETHERNETDISCARDPACKETSSENT:
				sprintf(pxGetParamVal->Value,"%lu",
					if_stats.tx_discard_pkts);

                                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);

                                break;
			case OID_IGD_WAND_WANCD_WANIPC_S_ETHERNETDISCARDPACKETSRECEIVED:
				sprintf(pxGetParamVal->Value,"%lu",
					if_stats.rx_discard_pkts);
                                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);

                                break;
			case OID_IGD_WAND_WANCD_WANIPC_S_ETHERNETUNICASTPACKETSSENT:
				sprintf(pxGetParamVal->Value,"%lu",
					if_stats.tx_unicast_pkts);

				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);

				break;
			case OID_IGD_WAND_WANCD_WANIPC_S_ETHERNETUNICASTPACKETSRECEIVED:
				sprintf(pxGetParamVal->Value,"%lu",
					if_stats.rx_unicast_pkts);

				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);

				break;
			case OID_IGD_WAND_WANCD_WANIPC_S_ETHERNETMULTICASTPACKETSSENT:
				sprintf(pxGetParamVal->Value,"%lu",
					if_stats.tx_multicast_pkts);

				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);

				break;
			case OID_IGD_WAND_WANCD_WANIPC_S_ETHERNETMULTICASTPACKETSRECEIVED:
				sprintf(pxGetParamVal->Value,"%lu",
					if_stats.rx_multicast_pkts);

				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);

				break;
			case OID_IGD_WAND_WANCD_WANIPC_S_ETHERNETBROADCASTPACKETSSENT:
				sprintf(pxGetParamVal->Value,"%lu",
					if_stats.tx_broadcast_pkts);

				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);

				break;
			case OID_IGD_WAND_WANCD_WANIPC_S_ETHERNETBROADCASTPACKETSRECEIVED:
				sprintf(pxGetParamVal->Value,"%lu",
					if_stats.rx_broadcast_pkts);

				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);

				break;
			case OID_IGD_WAND_WANCD_WANIPC_S_ETHERNETUNKNOWNPROTOPACKETSRECEIVED:
				sprintf(pxGetParamVal->Value,"%lu",
					if_stats.rx_unknownproto_pkts);

				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);

				break;

			default:
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "Invalid param id %d!\n", iParamId);
			pxGetParamVal->iFaultCode=ERR_INVAL_PARAMETER_VAL;
			break;
		}

							
			++pxGetParamVal;
	}

//		IFX_CWMP_FREE(pxWanConn);
		return IFX_CWMP_SUCCESS;
		
		errorHandler:
//			IFX_CWMP_FREE(pxWanConn);
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d failed!\n", __func__, __LINE__);
			return IFIN_CWMP_FAILURE;
			

}


/* 
** =============================================================================
**   Function Name    : IFX_WanIpConnStatsAddObj
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanIpConnStatsAddObj(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{

	/* This API calls a Platform API which adds the object
	** in ADD_DISABLE state.
	** Pass necessary flags to the API
	** Controller should get the next instance id from DS 
    	** module and pass the full OID to this module.
	*/
		
	/* If Cisco proposal comes, this API should handle 
	**  a) Validation of values
	**  b) Forward mapping of TR69 values to system values 
	**  c) addition of object into the system
	*/
	
	int32 iRet = 0;
	uint32 uiOper = 0;
	uint32 uiParamPos = 0;
	int32 iaOID[OID_LENGTH] = { 0 };
	char8 Tr69_str[MAX_NAME_LEN] = { 0 };
	char8 usSecTag[IFX_MAX_SECTION_TAG_LEN] = { 0 };
	char8 usParamTag[IFX_MAX_NAME_LEN] = { 0 };
	uint32 uiCpeid = 0;
	IFX_Id pxIfxId;

	//Get the Position of the Param Id
	uiParamPos = IFX_GetParamIdPos(pxParamVal->iaOID);
	memset(iaOID,0x00,(sizeof(int32)*OID_LENGTH));
	memcpy(iaOID,pxParamVal->iaOID,(sizeof(int32)* (uiParamPos-1)));
	
	//Get the Parent Obj Cpeid
	iRet = IFX_GetObjCpeId(iaOID,&uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	//Get the SectionName 
	iRet=IFX_GetSectionParamTag(pxParamVal->psRCTag, usParamTag, usSecTag);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
		
	//Convert Tr69_id into dotted form
	iRet = IFX_ConvertOidDottedForm(pxParamVal->iaOID, Tr69_str);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	//Call Protocol API to update the Mapping
	uiOper = IFX_TR69ID_MAP_TBL_OPER_ADD_ENTRY;
	pxIfxId.xCpeId.uiId = uiCpeid;
	strncpy(pxIfxId.xCpeId.sSectionTag,usSecTag, IFX_MAX_SECTION_TAG_LEN-1);
	pxIfxId.xCpeId.sSectionTag[IFX_MAX_SECTION_TAG_LEN-1] = '\0';
	strcpy(pxIfxId.sTr69Id,Tr69_str);
	
	iRet = IFX_UpdateTr69CpeIdMap(&pxIfxId, uiOper);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	return IFIN_CWMP_SUCCESS;

	errorHandler:
		 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d failed!\n", __func__, __LINE__);
		return IFIN_CWMP_FAILURE;

}


/* 
** =============================================================================
**   Function Name    : IFX_WanIpConnStatsSetCommit
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanIpConnStatsSetCommit()
{
	return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanIpConnStatsSetUndo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanIpConnStatsSetUndo()
{
	return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanIpConnStatsSetDelete
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanIpConnStatsSetDelete(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
							IN int32 iElements, OUT void **ppxParamStructRet,
												   OUT int32 * piNumRetElem)
{

	
	int32 iRet=0;
	uint32 uiOper;
	uint32 uiParamPos;
	int32 iaOID[OID_LENGTH];
	char8 Tr69_str[MAX_NAME_LEN];
	char8 usSecTag[IFX_MAX_SECTION_TAG_LEN];
	char8 usParamTag[IFX_MAX_NAME_LEN];
	uint32 uiCpeid;
	IFX_Id pxIfxId;

	memset(iaOID, 0x00, (sizeof(int32)*OID_LENGTH));
	
	if(pxOpInfo->iSubOper == OP_SETVAL_DELETE)
	{
		//Get the Position of the Param Id
		uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);
		memcpy(iaOID,paxParamVal->iaOID,(sizeof(int32)* (uiParamPos)));
		
		//Get the Parent Obj Cpeid
		iRet = IFX_GetCpeId(iaOID,&uiCpeid);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;
		
		//Get the SectionName 
		iRet=IFX_GetSectionParamTag(paxParamVal->psRCTag, usParamTag, usSecTag);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;
			
		//Convert Tr69_id into dotted form
		iRet = IFX_ConvertOidDottedForm(paxParamVal->iaOID, Tr69_str);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;
		
		//Call Protocol API to update the Mapping
		uiOper = IFX_TR69ID_MAP_TBL_OPER_DEL_ENTRY;
		pxIfxId.xCpeId.uiId = uiCpeid;
		strncpy(pxIfxId.xCpeId.sSectionTag,usSecTag, IFX_MAX_SECTION_TAG_LEN-1);
		pxIfxId.xCpeId.sSectionTag[IFX_MAX_SECTION_TAG_LEN-1] = '\0';
		strcpy(pxIfxId.sTr69Id,Tr69_str);
		
		iRet = IFX_UpdateTr69CpeIdMap(&pxIfxId, uiOper);

                /* This is a hack. Currently this is invoked twice from web, due to which it fails for
                   second time. We are neglecting the return type. */
                iRet = IFX_CWMP_SUCCESS;

	}
	return IFIN_CWMP_SUCCESS;

	errorHandler:
		 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d failed!\n", __func__, __LINE__);
		return IFIN_CWMP_FAILURE;


}

/* 
** =============================================================================
**   Function Name    : IFX_WanIpConnStatsSetFree
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanIpConnStatsSetFree()
{
	return IFX_CWMP_SUCCESS;
}


/* 
** =============================================================================
**   Function Name    : IFX_WanIpConnStatsSetAttr
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

static int32
IFX_WanIpConnStatsSetAttr(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{
	uint32 iRet=IFX_CWMP_SUCCESS,i;
	OperInfo xOpInfo;
	
	xOpInfo.iCaller = pxOpInfo->iCaller;
	xOpInfo.iOper= OP_GETVAL;
	xOpInfo.iSubOper= OP_GETVAL_NORMAL;
	
	iRet = IFX_WanIpConnStatsGetValue(&xOpInfo,pxParamVal, iElements);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorFreeHandler;
	
	iRet = IFX_SetAttributesInfo(pxOpInfo,pxParamVal, iElements);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorFreeHandler;

	errorFreeHandler:
		for(i=0; i < iElements; i++)
		IFX_CWMP_FREE(pxParamVal[i].Value);
		
                if (iRet)
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
		return iRet;
}



/* 
** =============================================================================
**   Function Name    : IFX_WanIpConnStats_Init
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_WanIpConnStats_Init(void)
{
	int32 iRet = IFX_CWMP_SUCCESS;

    
	/* Register the WanIpConnStats module function pointer in the object model */
	iRet = ifx_ds_register_function(IFX_WAN_IP_STATS_OBJ, IFX_WanIpConnStats);
	
	/* Check for error */
	if (iRet != IFX_CWMP_SUCCESS)
	{
	    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                "Unable to Register %s with Object Model\n",
	                 IFX_WAN_IP_STATS_OBJ);
	    goto errorHandler;
	}


	/* Register the WanPPPConnStats module function pointer in the object model */
	iRet = ifx_ds_register_function(IFX_WAN_PPP_STATS_OBJ, IFX_WanIpConnStats);
	
	/* Check for error */
	if (iRet != IFX_CWMP_SUCCESS)
	{
	    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                "Unable to Register %s with Object Model\n",
	                 IFX_WAN_PPP_STATS_OBJ);
	    goto errorHandler;
	}

	errorHandler:
			return iRet;
}

/*********************************************************************************
*  Function Name	:  IFX_WanIpConnStats   
      *  Description	:  This function handles all the sub-states inside
      	 		   a GET/SET operation.If it is a GET it allocates the 
			   array(Name,Value pairs) and retruns the values.
			   If it is a SET controller allocates the array and
			   passes the values to this function.It calls 
			   respective internal functions which in turn calls 
			   respective Platform APIs.
                                                                                                 
*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
							     Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has 
					  	             Name,Value,etc
                    IN          int32	       iElements;    No. of Elements
		    OUT	        void *	       ppParamRet;   same as ParamStruc
		    OUT         int32 *        piNumRetElem; No. of elements 		                                
*  Return Value        : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes               :
***********************************************************************************/
int32
IFX_WanIpConnStats(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                IN int32 iElements, OUT void **ppaxParamArrRet, OUT int32 *piNumRetElem)
{
     
   //It calls the respective internal functions which handles resp. sub-operation
   
   //Set-Operation  
   //controller should pass the entire array during all the SET-sub_operations
   //It should handles only single get/set of instance at any point of time
   //It does not handle partial path
   //It won't handle multiple instances of the same object/module
   //at any point of time.

    
    int32 iRet = 0;
   ParamVal *paxParamArr = (ParamVal *)paxParameterArr;

	switch (pxOperInfo->iOper) 
	{
		//Get the object values
	   	case OP_GETVAL:
	            if((iRet = IFX_WanIpConnStatsGetValue(pxOperInfo, paxParamArr,
		    							iElements)) != IFX_CWMP_SUCCESS) {
	                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
			  goto errorHandler;
	            }
	            break;
	        case OP_SETVAL:
		{

	    		//Set the obj values
			switch (pxOperInfo->iSubOper) 
			{
		               case OP_SETVAL_VALIDATE:
		                  		                 
		                    break;
		                case OP_SETVAL_ADD:
		                    
		                    if((iRet= IFX_WanIpConnStatsAddObj(pxOperInfo,paxParamArr,
				    					iElements))!=IFX_CWMP_SUCCESS)
		                    	{
			                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d OP_SETVAL_ADD failed!\n", __func__, __LINE__);
			                    	 goto errorHandler;
		                    	}
		                    break;
		              case OP_SETVAL_CHK_MODIFY_DEP:
				case OP_SETVAL_MODIFY:
		                    
		                    break;
		                case OP_SETVAL_COMMIT:
		                    if((iRet = IFX_WanIpConnStatsSetCommit(pxOperInfo,paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
		                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_COMMIT failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;
		                case OP_SETVAL_UNDO:
		                    if((iRet =IFX_WanIpConnStatsSetUndo(pxOperInfo, paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
		                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_UNDO failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;
				case OP_SETVAL_CHK_DEL_DEP:
			   	    *ppaxParamArrRet = (ParamVal *)IFX_CWMP_MALLOC(sizeof(ParamVal));
				    if(ppaxParamArrRet!=NULL) {
                                        memcpy(*ppaxParamArrRet, paxParameterArr, sizeof(ParamVal));
                                        *piNumRetElem = 1;
				    }
				    else {
					goto errorHandler;
				    }
                                    break;
				case OP_SETVAL_CHK_DEL_ALLOWED:
		              case OP_SETVAL_DELETE:
		                    if((iRet= IFX_WanIpConnStatsSetDelete(pxOperInfo, paxParamArr,
				    					iElements, ppaxParamArrRet,
				    					piNumRetElem))!= IFX_CWMP_SUCCESS) 
				    	{
		                    
			                    switch(pxOperInfo->iSubOper)
							{	
						  		case OP_SETVAL_CHK_DEL_DEP:
							    	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
					                        goto errorHandler;
								case OP_SETVAL_CHK_DEL_ALLOWED:
									IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
					                        goto errorHandler;
								case OP_SETVAL_DELETE:
									IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
					                        goto errorHandler;
							}
				     }
		                    break;
		                case OP_SETVAL_FREE:
		                    IFX_WanIpConnStatsSetFree(pxOperInfo);
					break;

				 case OP_SETVAL_ATTRINFO:
				 	if((iRet =IFX_WanIpConnStatsSetAttr(pxOperInfo, paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
		                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            	"%s:%d OP_SETVAL_ATTRINFO failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;
							
		                default:
		                    break;
			}
			break;
	        }
                case OP_PARAM_VALIDATE:
                {
                    break; 
                }
	        default:
	            break;
	}
	return IFX_CWMP_SUCCESS;

	errorHandler:
		return IFX_CWMP_FAILURE;
			
}
 
