
/* 
** =============================================================================
**   FILE NAME        : IFX_LANEthernetIfCfg
**   PROJECT          : TR69
**   MODULES          : LANEthernetInterfaceConfig
**   DATE             : 27-07-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION      :
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_Global.h"
#include "IFX_DEVM_AdaptCommon.h"
          // Required for STATIC

#include "IFX_DEVM_OID.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_DS.h"
#include <fcntl.h>
#include <unistd.h>

#ifdef MIPSTARGET
#define QUERY_INTERFACE         "br0"
#else
#define QUERY_INTERFACE         "eth0"
#endif

int32
IFX_LANEthernetIfCfg(IN OperInfo * pxOI, INOUT void *pParamList,
                     IN int32 iNumElem, OUT void **ppRet,
                     OUT int32 * piNumRetElem);

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFX_LEIC_OBJ "InternetGatewayDevice.LANDevice.1.LANEthernetInterfaceConfig."

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/
STATIC int32
GetVal(IN int32 iCaller, INOUT ParamVal * pxParamVal, IN int32 iElements);
STATIC int32 Validate(INOUT ParamVal * pxParamVal, IN int32 iElements);
STATIC int32 GetModifyDep(INOUT ParamVal * pxParamVal, IN int32 iElements);
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal * pxParamVal, IN int32 iElements);
STATIC int32
GetNotify(IN OperInfo * pxOI, INOUT ParamVal * pxParamVal, IN int32 iElements);
STATIC int32
SetAttrInfo(IN OperInfo * pxOI, INOUT ParamVal * pxParamVal,
            IN int32 iElements);
/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/

/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetVal(IN int32 iCaller, INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iLen = 0;
    int32 iCnt = 0;
    int32 iParamOffset = 0;
    int32 iFd = -1;
    char8 caBuff[100] = { 0 }, *psTmp = NULL;
    int32 iInstancePos = 0;
    struct ifx_phyport_info xPort;

    /* Memset the port structure to zero */
    memset(&xPort, '\0', sizeof(xPort));

    for(iCnt = 0; iCnt < iElements; iCnt++) {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamIdPos(pxParamVal->iaOID);
    if ((iParamOffset <= 0) || (iParamOffset > OID_LENGTH))
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }


    /* Get the Instance Position */
    iInstancePos = (iParamOffset - 1);

#ifdef MIPSTARGET
    /* Get the values for the requested instance */
#if defined(PLATFORM_VR9) || defined(PLATFORM_AR10)
    ifx_get_phyport_info(((pxParamVal->iaOID[iInstancePos]) - 1), &xPort, 0);
#else
    ifx_get_phyport_info(((pxParamVal->iaOID[iInstancePos]) - 1), &xPort, 1);
#endif
#endif

    /* Iterate and fill the requested parameters */
    for(iCnt = 0; iCnt < iElements; iCnt++) {

        /* TBD: 20 is the maximum size of parameter */
        (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(20);

        /* Check for error */
        if(!((pxParamVal[iCnt]).Value)) {
            iRet = ERR_OUT_OF_MEMORY;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Allocation Failure\n",
                        __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset]) {
            case OID_IGD_LAND_LANEIC_ENABLE:

                /* Copy the value to allocated area */
		sprintf((pxParamVal[iCnt]).Value, "%d", xPort.enable);
                //strcpy((pxParamVal[iCnt]).Value, "1");
                break;
            case OID_IGD_LAND_LANEIC_STATUS:

                /* Copy the value to allocated area */
                if(xPort.link)
                    strcpy((pxParamVal[iCnt]).Value, "Up");
                else
                    strcpy((pxParamVal[iCnt]).Value, "NoLink");
                break;
            case OID_IGD_LAND_LANEIC_NAME:
                strcpy((pxParamVal[iCnt]).Value, "eth0");
                break;
            case OID_IGD_LAND_LANEIC_MACADDRESS:
                /* TBD: Remove br0 hardcoding for target */
                iRet = system("ifconfig " QUERY_INTERFACE
                           " | grep HWaddr > /tmp/ethaddr");
                if(iRet != IFX_CWMP_SUCCESS) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] "
                                "system() failed %s\n", _FUNCL_, iRet,
                                QUERY_INTERFACE);
                    iRet = ERR_CWMP_INTERNAL;
                    goto cleanup;
                }
                iFd = open("/tmp/ethaddr", O_RDONLY);
                iLen = read(iFd, caBuff, (sizeof(caBuff) - 1));
		caBuff[iLen] = '\0';
                psTmp = strstr(caBuff, "HWaddr ");
                memcpy((pxParamVal[iCnt]).Value, psTmp + strlen("HWaddr "), 17);
                close(iFd);
                system("rm -f /tmp/ethaddr");
                break;
            case OID_IGD_LAND_LANEIC_MACADDRESSCONTROLENABLED:

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, "0");
                break;
            case OID_IGD_LAND_LANEIC_MAXBITRATE:

                /* Copy the value to allocated area */
                if(xPort.speed == 0)
                    strcpy((pxParamVal[iCnt]).Value, "Auto");
                else
                    sprintf((pxParamVal[iCnt]).Value, "%d", xPort.speed);
                    //strcpy((pxParamVal[iCnt]).Value, "10");
                break;
            case OID_IGD_LAND_LANEIC_DUPLEXMODE:

                /* Copy the value to allocated area */
                if(xPort.duplex == 0)
                    strcpy((pxParamVal[iCnt]).Value, "Auto");
		else if(xPort.duplex == 1)
                    strcpy((pxParamVal[iCnt]).Value, "Full");
                else
                    strcpy((pxParamVal[iCnt]).Value, "Half");
                break;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
                goto cleanup;
        }
    }

  cleanup:
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : Modify
**
**   Description      : This function modifies the values of parameters in 
**                      DeviceInfo object. It calls respective Management API  
**                      for the same. It performs modification only if parameter 
**                      has Write permission. In certain cases it also performs 
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iCnt = 0, iParamOffset = 0, iInstancePos = 0;
    struct ifx_phyport_info xPort;

    /* Memset the port structure to zero */
    memset(&xPort, '\0', sizeof(xPort));

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamIdPos(pxParamVal->iaOID);
    if ((iParamOffset <= 0) || (iParamOffset > OID_LENGTH))
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
	return (iRet);
    }

    /* Get the Instance Position */
    iInstancePos = (iParamOffset - 1);

#ifdef MIPSTARGET
    /* Get the values for the requested instance */
#ifdef PLATFORM_VR9
    ifx_get_phyport_info(((pxParamVal->iaOID[iInstancePos]) - 1), &xPort, 0);
#else
    ifx_get_phyport_info(((pxParamVal->iaOID[iInstancePos]) - 1), &xPort, 1);
#endif
#endif

    /* Iterate and fill the requested parameters */
    for(iCnt = 0; iCnt < iElements; iCnt++)
    {
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
	{
            case OID_IGD_LAND_LANEIC_ENABLE:
	    {
		if((strcmp((pxParamVal[iCnt]).Value, "1") == 0) || (strcasecmp((pxParamVal[iCnt]).Value, "true") == 0))
		{
		    ifx_set_phyport_info(((pxParamVal->iaOID[iInstancePos]) - 1),IFX_MAPI_LANEIC_ENABLE , "1", 1);
		}
                else if((strcmp((pxParamVal[iCnt]).Value, "0") == 0) || (strcasecmp((pxParamVal[iCnt]).Value, "false") == 0))
		{
		    ifx_set_phyport_info(((pxParamVal->iaOID[iInstancePos]) - 1),IFX_MAPI_LANEIC_ENABLE , "0", 1);
                }
                else
		{
                    iRet = ERR_CWMP_INVAL_ARGS;
                    pxParamVal[iCnt].iFaultCode = ERR_INVAL_PARAMETER_VAL;
                }
	    }             
	    break;
            case OID_IGD_LAND_LANEIC_MACADDRESSCONTROLENABLED:
            {
                if(strcmp((pxParamVal[iCnt]).Value, "0") == 0)
                {
                }
                else
                {
		    iRet = ERR_CWMP_INVAL_ARGS;
                    pxParamVal[iCnt].iFaultCode = ERR_REQUEST_DENIED;
                }
                break;
	    }
            case OID_IGD_LAND_LANEIC_MAXBITRATE:
            {
		if(!(xPort.speed == atoi((pxParamVal[iCnt]).Value)))
		{
                        iRet = ERR_CWMP_INVAL_ARGS;
                        pxParamVal[iCnt].iFaultCode = ERR_REQUEST_DENIED;
                }
                break;
	    }
            case OID_IGD_LAND_LANEIC_DUPLEXMODE:
            {
		if(xPort.duplex)
		{
                    if((strcasecmp((pxParamVal[iCnt]).Value, "Full") == 0)
				|| (strcasecmp((pxParamVal[iCnt]).Value, "Auto") == 0))
		    {
                    }
                    else
		    {
                        iRet = ERR_CWMP_INVAL_ARGS;
                        pxParamVal[iCnt].iFaultCode = ERR_REQUEST_DENIED;
                    }
                }
                else
		{
                    if((strcasecmp((pxParamVal[iCnt]).Value, "Half") == 0)
				|| (strcasecmp((pxParamVal[iCnt]).Value, "Auto") == 0))
		    {
			printf("%s:%d\n", _FUNCL_);
                    }
                    else
		    {
			printf("%s:%d\n", _FUNCL_);
                        iRet = ERR_CWMP_INVAL_ARGS;
                        pxParamVal[iCnt].iFaultCode = ERR_REQUEST_DENIED;
                    }
                }
                break;
	    }
            default:
            {
		iRet = ERR_CWMP_INVAL_PARAM_NAME;
                (pxParamVal[iCnt]).iFaultCode = ERR_INVAL_PARAMETER_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%s:%d] [%d] "
                            "Unknown requested parameter\n", __FILE__, __func__,
                            __LINE__, (pxParamVal[iCnt]).iaOID[iParamOffset]);
                break;
	    }
        }
    }

    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : Validate
**
**   Description      : This function validates the values of parameters in
**                      DeviceInfo object.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      validated.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When validation of all parameters is
**                      successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in validating at least one parameter.
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
Validate(INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : GetModifyDep
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
GetModifyDep(INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    return (IFX_CWMP_SUCCESS);
}


STATIC int32
GetNotify(IN OperInfo * pxOI, INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iCnt = 0;

    for(iCnt = 0; iCnt < iElements; iCnt++) {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
        (pxParamVal[iCnt]).Value = NULL;
    }

    return (iRet);
}

STATIC int32
SetAttrInfo(IN OperInfo * pxOI, INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iCnt;

    /* Set the fault code to Success */
    for(iCnt = 0; iCnt < iElements; iCnt++) {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
    }

    /* Get the offset of the parameter */
    IFX_GetParamIdPos(pxParamVal->iaOID);

    for(iCnt = 0; iCnt < iElements; iCnt++) {
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Update Attribute Information */
    iRet = IFX_SetAttributesInfo(NULL, pxParamVal, iElements);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Updating Param Attribute Info failed\n",
                    __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

  cleanup:
    return (iRet);
}

/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/


int32
IFX_LANEthernetIfCfg_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    iRet = ifx_ds_register_function(IFX_LEIC_OBJ, IFX_LANEthernetIfCfg);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_LEIC_OBJ);
        goto cleanup;
    }

  cleanup:
    return iRet;
}

int32
IFX_LANEthernetIfCfg(IN OperInfo * pxOI, INOUT void *pParamList,
                     IN int32 iNumElem, OUT void **ppRet,
                     OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *pxParamVal = (ParamVal *) pParamList;

    /* Process based on type of Operation */
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            /* Process based on type of SubOperation */
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:

                    /* Get values of all the requested parameters */
                    iRet = GetVal(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS) {
                        goto cleanup;
                    }

                    break;
                case OP_GETVAL_NOTIFICATION:

                    /* Set attribute values for all the requested parameters */
                    iRet = GetNotify(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS) {
                        goto cleanup;
                    }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_SETVAL:
        {
            /* Process based on type of SubOperation */
            switch (pxOI->iSubOper) {
                case OP_SETVAL_VALIDATE:

                    /* Validate values of all the requested parameters */
                    iRet = Validate(pxParamVal, iNumElem);

                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS) {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:

                    /* Check modify dependency of all requested parameters */
                    iRet = GetModifyDep(pxParamVal, iNumElem);

                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS) {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_MODIFY:

                    /* Set values of all the requested parameters */
                    iRet = Modify(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS) {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ATTRINFO:

                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS) {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_FREE:
                case OP_SETVAL_ADD:
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
                case OP_SETVAL_DELETE:
                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            /* Process based on type of SubOperation */
            switch (pxOI->iSubOper) {
                case OP_UPDATE_CHILDINFO_ADD:
                case OP_UPDATE_CHILDINFO_DEL:
                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
        {
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid Operation\n",
                        __func__, __LINE__, iRet);
            goto cleanup;
        }
    }

  cleanup:
    return (iRet);
}
