/* 
** =============================================================================
**   FILE NAME        : IFX_WanDevice.c
**   PROJECT          : TR69
**   MODULES          : WanDevice
**   DATE             : 03-08-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This module handles ADD/DEL/GET/SET RPCs of WanDevice.
**                      When controller calls this module it calls the 
**                      respective Platform/Object APIs to handle the GET/SET 
**                      of WanDevice specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author        $Comment
**   28-04-06         TR69 team      Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
//#include <sys/socket.h>
//#include <netinet/in.h>
//#include <arpa/inet.h>

#include "IFX_DEVM_WANDev.h"
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
 

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;
#define IFX_WAN_DEV_OBJ "InternetGatewayDevice.WANDevice.1."

/*
#define WAN_IP_NO_DEP_OIDS 2
#define WAN_IP_PORT_MAP_TCP 1
#define WAN_IP_PORT_MAP_UDP 2
#define NO_WAN_CON_DEVICE 16
*/

#define TAG_WANCONNNOE "wan_conndev"
/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/




/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/


extern Map_Value gaxEnable[]; 


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/
//If we maintain in an array the following issues are there
	//After reboot we need to synchronize with the system
	//If the connection goes down we may not have the correct count
	//Extra ram storage



/* 
** =============================================================================
**   Function Name    : IFX_WanDeviceGetValue
**   Description        : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes                : 
**
** ============================================================================
*/
static int32 
IFX_WanDeviceGetValue(IN OperInfo *pxOperInfo,INOUT ParamVal *pxGetParamVal,
								IN uint32 iElements)
{
	/*GET PARAMETER VALUES
	**Get Object OID(skip parameter ID) from the first 
	**element in the array.Get Cpeid for this Object OID

	**Get the object from the system using a Platform API
	**with cpeid 
	
	**Do reverse mapping to convert system values into TR69
	**Values.After conversion stores the values in temp storage

	**While assigning the values as per request store the 
	**values in heap and assign the ptr to the struct
	**Return all the values 
	*/


	
	//uint32 iCpeid=0,
	uint32 i=0;
	int32 iParamId=0;
	uint32 uiParamPos=0;
	uint32 uiMode=IFX_CHK_CHANGE_FLAG_BASED;
	//int32 iConType=0;
	int32 iRet=0;
	uint32 uiNoOf_WanConDevices=0;	
	//nt32 uiNoOf_PPPConnections=0;
	//Get the WanIpConParamPos 
	uiParamPos = IFX_GetParamIdPos(pxGetParamVal->iaOID);
	
 #ifndef IFX_TR69_WAN_MODS_TEST_STUBS
	//Call the system API which gives No_Wan_ConnDev in this WanDevice
        iRet = ifx_get_sec_instance_count(TAG_WANCONNNOE, &uiNoOf_WanConDevices);
//	iRet = ifx_get_wan_conn_device_count(&uiNoOf_WanConDevices);
 #endif
 
	if(iRet != IFX_SUCCESS)
			goto errorHandler;
		
	for(i=0;i < iElements; i++)
	{
	
		iParamId = pxGetParamVal->iaOID[uiParamPos];
	
		// Malloc and assign the pointer to the Value attr of struct 
		pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
		if(pxGetParamVal->Value == NULL ){
			iRet = ERR_OUT_OF_MEMORY; 
			goto errorHandler;
		}
		switch(iParamId)
		{

			// Convert the value - reverse mapping
			// Assign the correct value to the Value attr	
	    		case OID_IGD_WAND_WANCONNECTIONNUMBEROFENTRIES:

				sprintf(pxGetParamVal->Value,"%d", uiNoOf_WanConDevices);
				
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				
				break;	 
					
	    		 
					
			default:
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "Invalid param id %d!\n", iParamId);
			pxGetParamVal->iFaultCode=ERR_INVAL_PARAMETER_VAL;
			break;
		}

							
			++pxGetParamVal;
	}

		return IFX_CWMP_SUCCESS;
		
		errorHandler:
			//ifx_set_wan_conn_dev_stub(iOper, &xWanConDev, iFlags);
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d failed!\n", __func__, __LINE__);
			return IFIN_CWMP_FAILURE;
			

}


/* 
** =============================================================================
**   Function Name    : IFX_WanDeviceAddObj
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanDeviceAddObj(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{



	return IFIN_CWMP_SUCCESS;

	 
}


/* 
** =============================================================================
**   Function Name    : IFX_WanIpDeviceSetCommit
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanDeviceSetCommit()
{

	return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDeviceSetUndo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanDeviceSetUndo()
{
	return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDeviceSetDelete
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanDeviceSetDelete(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
							IN int32 iElements, OUT void **ppxParamStructRet,
												   OUT int32 * piNumRetElem)
{

	 
		return IFIN_CWMP_SUCCESS;
	
	 
}

/* 
** =============================================================================
**   Function Name    : IFX_WanConnDeviceSetFree
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanDeviceSetFree()
{
	return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDeviceUpdateChildInfo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

static int32 IFX_WanDeviceUpdateChildInfo(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{

	//For both ADD & DEL 
	//Check whether WanIPC or WanPPPC
	//Send notification
	uint32 i=0,iRet=0;
	char8 usSecTag[IFX_MAX_SECTION_TAG_LEN]={0};
	char8 usParamTag[IFX_MAX_NAME_LEN]={0};
	uint32 uiParamPos=0,uiChildObjId=0;
	uint32 uiCpeid=0;
	int32 *iaOID=NULL;
	uint32 uiNumNV=1;
	//IFX_CpeId pxCpeId;
	IFX_Id xIfx_Id;
	IFX_NameValue pxNVArray;
	uint32 uiOper=IFX_NOTIFY_OPER_MODIFY;
	ParamVal *pxTempParamVal=pxParamVal;
	
		//memset the structs
		memset(&xIfx_Id,0x00,sizeof(xIfx_Id));
		memset(&pxNVArray,0x00,sizeof(pxNVArray));

		//Get Cpeid
		iRet = IFX_GetCpeId(pxTempParamVal->iaOID, &uiCpeid);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;

		//Get the child object Oid
		uiChildObjId = IFX_GetParamIdPos((int32 *)pxTempParamVal->pReserved);
		iaOID = (int32 *)pxTempParamVal->pReserved;


		for(i=0; i < iElements; i++)

		{
			//Get the Param Oid of this object
			uiParamPos= IFX_GetParamIdPos(pxTempParamVal->iaOID);
			
			switch(pxTempParamVal->iaOID[uiParamPos])
			{
				case OID_IGD_WAND_WANCONNECTIONNUMBEROFENTRIES:
					if(iaOID[uiChildObjId-1] ==	OID_IGD_WAND_WANCD)
					{
						//Get the section and Paramtag
						iRet=IFX_GetSectionParamTag(pxTempParamVal->psRCTag, usParamTag, 
															usSecTag);
						if(iRet != IFX_CWMP_SUCCESS)
							goto errorHandler;

						xIfx_Id.uiConfigOwner= pxOpInfo->iCaller;
						xIfx_Id.xCpeId.uiId= uiCpeid;
						strncpy(xIfx_Id.xCpeId.sSectionTag,usSecTag, IFX_MAX_SECTION_TAG_LEN-1);
						xIfx_Id.xCpeId.sSectionTag[IFX_MAX_SECTION_TAG_LEN-1] = '\0';
						strncpy(pxNVArray.sName,usParamTag, IFX_MAX_NAME_LEN-1);
						pxNVArray.sName[IFX_MAX_NAME_LEN-1] = '\0';

												
						iRet=IFX_SendNotify(&xIfx_Id, uiNumNV, 
												&pxNVArray, uiOper);
						if(iRet != IFX_CWMP_SUCCESS)
						{
						IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d UpdatechildInfo IFX_SendNotify failed!\n", __func__, __LINE__);
							goto errorHandler;
						}
					}
					break;
				
								
				default:
					break;
					
	
			}
			pxTempParamVal++;
			
		}

		return IFX_CWMP_SUCCESS;
		
	errorHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d failed!\n", __func__, __LINE__);
		return IFX_CWMP_FAILURE;
		
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDeviceSetAttr
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

int32
IFX_WanDeviceSetAttr(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{
	uint32 iRet=IFX_CWMP_SUCCESS,i=0;
	OperInfo xOpInfo;
	
	xOpInfo.iCaller = pxOpInfo->iCaller;
	xOpInfo.iOper= OP_GETVAL;
	xOpInfo.iSubOper= OP_GETVAL_NORMAL;
	
	iRet = IFX_WanDeviceGetValue(&xOpInfo,pxParamVal, iElements);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorFreeHandler;
	
	iRet = IFX_SetAttributesInfo(pxOpInfo,pxParamVal, iElements);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorFreeHandler;

	errorFreeHandler:
		for(i=0; i < iElements; i++)
		IFX_CWMP_FREE(pxParamVal[i].Value);
		
                if (iRet)
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
		return iRet;
}



/* 
** =============================================================================
**   Function Name    : IFX_WanDslLinkConfig_Init
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_WanDevice_Init(void)
{
	 int32 iRet = IFX_CWMP_SUCCESS;

    
    /* Register the DeviceInfo module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_WAN_DEV_OBJ, IFX_WanDevice);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "Unable to Register %s with Object Model\n",
                     IFX_WAN_DEV_OBJ);
        goto errorHandler;
    }

	errorHandler:
    		return iRet;

}

/*********************************************************************************
*  Function Name	:  IFX_WanDevice
      *  Description	:  This function handles all the sub-states inside
      	 		   a GET/SET operation.If it is a GET it allocates the 
			   array(Name,Value pairs) and retruns the values.
			   If it is a SET controller allocates the array and
			   passes the values to this function.It calls 
			   respective internal functions which in turn calls 
			   respective Platform APIs.
                                                                                                 
*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
							     Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has 
					  	             Name,Value,etc
                    IN          int32	       iElements;    No. of Elements
		    OUT	        void *	       ppParamRet;   same as ParamStruc
		    OUT         int32 *        piNumRetElem; No. of elements 		                                
*  Return Value        : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes               :
***********************************************************************************/
int32
IFX_WanDevice(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                IN int32 iElements, OUT void **ppaxParamArrRet, OUT int32 *piNumRetElem)
{
     
   //It calls the respective internal functions which handles resp. sub-operation
   
   //Set-Operation  
   //controller should pass the entire array during all the SET-sub_operations
   //It should handles only single get/set of instance at any point of time
   //It does not handle partial path
   //It won't handle multiple instances of the same object/module
   //at any point of time.

    
    int32 iRet = 0;
   ParamVal *paxParamArr = (ParamVal *)paxParameterArr;

	switch (pxOperInfo->iOper) 
	{
		//Get the object values
	   	case OP_GETVAL:
	            if((iRet = IFX_WanDeviceGetValue(pxOperInfo, paxParamArr,
		    							iElements)) != IFX_CWMP_SUCCESS) {
	                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
			  goto errorHandler;
	            }
	            break;
	        case OP_SETVAL:
		{

	    		//Set the obj values
			switch (pxOperInfo->iSubOper) 
			{
		               case OP_SETVAL_VALIDATE:
		                  		                 
		                    break;
		                case OP_SETVAL_ADD:
		                    
		                    if((iRet= IFX_WanDeviceAddObj(pxOperInfo,paxParamArr,
				    					iElements))!=IFX_CWMP_SUCCESS)
		                    	{
			                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d OP_SETVAL_ADD failed!\n", __func__, __LINE__);
			                    	 goto errorHandler;
		                    	}
		                    break;
		              case OP_SETVAL_CHK_MODIFY_DEP:
				case OP_SETVAL_MODIFY:
		                    
		                    break;
		                case OP_SETVAL_COMMIT:
		                    if((iRet = IFX_WanDeviceSetCommit(pxOperInfo,paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
		                         IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_COMMIT failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;
		                case OP_SETVAL_UNDO:
		                    if((iRet =IFX_WanDeviceSetUndo(pxOperInfo, paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
		                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_UNDO failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;
				case OP_SETVAL_CHK_DEL_DEP:
				case OP_SETVAL_CHK_DEL_ALLOWED:
		              case OP_SETVAL_DELETE:
		                    if((iRet= IFX_WanDeviceSetDelete(pxOperInfo, paxParamArr,
				    					iElements, ppaxParamArrRet,
				    					piNumRetElem))!= IFX_CWMP_SUCCESS) {
		                    
		                    		switch(pxOperInfo->iSubOper)
						{	
					  		case OP_SETVAL_CHK_DEL_DEP:
						    	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
				                        goto errorHandler;
							case OP_SETVAL_CHK_DEL_ALLOWED:
								IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
				                        goto errorHandler;
							case OP_SETVAL_DELETE:
								IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
				                        goto errorHandler;
						}
				    }
		                    break;
		                case OP_SETVAL_FREE:
		                    IFX_WanDeviceSetFree(pxOperInfo);
					break;

				 case OP_SETVAL_ATTRINFO:
				 	if((iRet =IFX_WanDeviceSetAttr(pxOperInfo, paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
		                          IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            		"%s:%d OP_SETVAL_ATTRINFO failed!\n", __func__, __LINE__);
		                       	 goto errorHandler;
		                    }	
		                    break;
							
		                default:
		                    break;
			}
			
			case OP_UPDATE_CHILDINFO:
			//Updation of child related info is handled by the case
				switch(pxOperInfo->iSubOper)
				{
					case OP_UPDATE_CHILDINFO_ADD:
					case OP_UPDATE_CHILDINFO_DEL:
						if((iRet =IFX_WanDeviceUpdateChildInfo(pxOperInfo, 
									paxParamArr,iElements)) != IFX_CWMP_SUCCESS)
						{
							switch(pxOperInfo->iSubOper)
							{	

								case OP_UPDATE_CHILDINFO_ADD:
								 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_UPDATE_CHILDINFO_ADD failed!\n", __func__, __LINE__);
								goto errorHandler;
								
								case OP_UPDATE_CHILDINFO_DEL:
								 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_UPDATE_CHILDINFO_DEL failed!\n", __func__, __LINE__);
								goto errorHandler;

							}

						}	
				}
			break;
			
	        }
                case OP_PARAM_VALIDATE:
                {
                    break; 
                }
	        default:
	            //printf(stderr, "%s:%d Error! In Default case\n", __func__,
	            //       __LINE__);
	            //exit(EXIT_FAILURE);
	            break;
	}
	return IFX_CWMP_SUCCESS;

	errorHandler:
		return iRet;
			
}
 
