/* 
** =============================================================================
**   FILE NAME        : IFX_DEVM_Vlan.c
**   PROJECT          : TR69
**   MODULES          : WanDevice
**   DATE             : 07-10-2011
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This module handles ADD/DEL/GET/SET RPCs of
**                      X_AC9A96_VLAN object. When controller calls this module it
**                      calls respective Platform/Object APIs to handle GET/SET 
**                      of vlan_ch_cfg specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Lantiq Communications
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author        $Comment
**   07-10-2011         TR69 team      Intial version
** ============================================================================
*/

/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
 
#include "IFX_DEVM_Global.h"
#include "IFX_DEVM_AdaptCommon.h"

#include "IFX_DEVM_OID.h"
//#include <ctype.h>
#include "IFX_DEVM_Platform.h"
//#include "IFX_DEVM_DS.h"
#include "IFX_DEVM_StackUtil.h"
/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/

#define IFX_WANPTMLINK_VLAN_OBJ "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPTMLinkConfig.X_AC9A96_Vlan.1."
#define IFX_WANDSLLINK_VLAN_OBJ "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANDSLLinkConfig.X_AC9A96_Vlan.1."
#define IFX_WANETHLINK_VLAN_OBJ "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANEthernetLinkConfig.X_AC9A96_Vlan.1."

extern char8 vcOsModId;
//extern IFX_SetVCCWanConDevice(int32 *iaOIDDSL,int32 iCaller, int16 Vpi, int32 Vci, char8 * l2iface_name);

int32 IFX_WanVlanCfg(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                IN int32 iElements, OUT void **ppaxParamArrRet, OUT int32 *piNumRetElem);

#define LOW_LIMIT_VLANID 2
#define UPP_LIMIT_VLANID 4094


/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/

#if 0
/*
** =============================================================================
**   Function Name    : ValidateMac
**   Description      : 
**   Parameters       : 
**   Return Value     : 
** ============================================================================
*/
static int32 ValidateMac(char8 * MacAddr)
{
#if 0
    int32 iRet = IFX_CWMP_SUCCESS;
    char8 *p1, *p2;
    int32 count = 0;

    if(MacAddr == NULL)
    {
        iRet = IFX_CWMP_FAILURE;
        goto end;
    }
    p1 = p2= MacAddr;

    while((p2 = strchr(p1, ':')) != NULL)
    {
        count++;
        if(((p2-p1) == 0) || ((p2-p1)>2))
        {
            iRet = IFX_CWMP_FAILURE;
            goto end;
        }
        while(p1 != p2)
        {
            if(((*p2 < '0') || (*p2 > '9')) && ((*p2 < 'a') || (*p2 > 'f')) && ((*p2 < 'A') || (*p2 > 'F')))
            {
                iRet = IFX_CWMP_FAILURE;
                goto end;
            }
            p1++;
        }
        p1++;
    }
    
    if(count != 5)
    {
        iRet = IFX_CWMP_FAILURE;
        goto end;
    }
    
end:
    return iRet;    
#endif
    return 0;
}
#endif

/* 
** =============================================================================
**   Function Name    : GetParamOffset
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

STATIC int32
GetParamOffset(IN int32 *paiOID)
{
    int32 iCnt;

    for (iCnt = 0; paiOID[iCnt] != 0; iCnt++);

    return (iCnt - 1);
}

/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 
GetVal(IN OperInfo *pxOperInfo,INOUT ParamVal *pxParamVal,
                                IN uint32 iElements)
{
    uint32 iCpeid = 0;
    uint32 iCnt = 0;
    int32 iRet= IFX_CWMP_SUCCESS;
    vlan_ch_cfg_t xVlanChCfg;
    uint32 flags = IFX_F_GET_ANY;
    int32   iParamOffset;

    memset(&xVlanChCfg, 0x00, sizeof(xVlanChCfg));

    /* Get Cpeid from object ID */
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [%d] \n",
                    __func__, __LINE__, iRet);
        IFX_PrintOID(pxParamVal->iaOID);
        goto end;
    }

    xVlanChCfg.iid.cpeId.Id = iCpeid;

    /* Get match object from system using MAPI */
    iRet= mapi_get_vlan_ch_entry(-1, &xVlanChCfg, flags);
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] mapi_get_vlan_ch_entry failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto end;
    }

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL; 
        goto end;
    }

    for( iCnt=0; iCnt<iElements; iCnt++)
    {
        // Malloc and assign the pointer to the Value attr of struct 
        (pxParamVal[iCnt]).Value = IFX_CWMP_MALLOC(20);
        if(pxParamVal[iCnt].Value == NULL)
        {
            iRet = ERR_OUT_OF_MEMORY; 
            goto end;
        }

        switch(pxParamVal[iCnt].iaOID[iParamOffset])
        {
#ifdef IFX_TR69_PTMWAN
            case OID_IGD_WAND_WANCD_WANPTMLC_XAC9A96V_X_AC9A96_VLANID:
#endif
#ifdef IFX_TR69_ETHERNETWAN
            case OID_IGD_WAND_WANCD_WANELC_XAC9A96V_X_AC9A96_VLANID:
#endif
#ifdef IFX_TR69_ADSLWAN
            case OID_IGD_WAND_WANCD_WANDSLLC_XAC9A96V_X_AC9A96_VLANID:
#endif
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xVlanChCfg.vlanId);
                break;     

            default:
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%d] [Error] Unknown requested parameter %d!\n",
                            _FUNCL_, pxParamVal[iCnt].iaOID[iParamOffset]);
                pxParamVal->iFaultCode=ERR_INVAL_PARAMETER_NAME;
                break;
        }
    }

end:
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : Validate
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
Validate(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
                            IN int32 iElements)
{
    return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : AddObj
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
AddObj(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
                            IN int32 iElements)
{
    vlan_ch_cfg_t xVlanCfg;
    uint32 iFlags=0;
    int32 iRet=0;
#ifdef IFX_TR69_ADSLWAN
    int32 WANDSLLC_EnableOID[OID_LENGTH] = {0,0,0,0,0,OID_IGD_WAND_WANCD_WANDSLLC,OID_IGD_WAND_WANCD_WANDSLLC_ENABLE};
#endif
#ifdef IFX_TR69_PTMWAN
    int32 WANPTMLC_EnableOID[OID_LENGTH] = {0,0,0,0,0,OID_IGD_WAND_WANCD_WANPTMLC,OID_IGD_WAND_WANCD_WANPTMLC_ENABLE};
#endif
#ifdef IFX_TR69_ETHERNETWAN
    int32 WANEthLC_EnableOID[OID_LENGTH] = {0,0,0,0,0,OID_IGD_WAND_WANCD_WANELC,OID_IGD_WAND_WANCD_WANELC_X_AC9A96_ENABLE};
#endif
    ParamVal xInParamVal;
    ParamVal *paxOutParamArr=NULL;
    ParamVal *paxTempParamVal=NULL;
    uint32 uiOutElem=0;
    uint32 uiPcpeid = 0;
    int32 iOper = 0;
    int32 iJ = 0;
    char8 * retStr = NULL;
    int32 parent_type = 0;//1:atm, 2:ptm, 3:eth
    char8 ParentSecName[MAX_TAG_LEN];
    
    char8 sCommand[MAX_FILELINE_LEN];
    char sValue[MAX_FILELINE_LEN];
    int32 outFlag = IFX_F_DEFAULT;

    memset(&xVlanCfg, 0x00, sizeof(xVlanCfg));
    memset(&xInParamVal, 0x00, sizeof(xInParamVal));

    //If owner is WEB don't add the object just return success.
    if(pxOpInfo->iCaller == ACC_WEB)
    {
        return IFX_CWMP_SUCCESS;
    }

    //Get the Parent Obj Cpeid
    iRet = IFX_GetParentObjCpeId(pxParamVal->iaOID,&uiPcpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    {
    	goto errorHandler;
    }
    iOper = IFX_OP_ADD;
    
    xVlanCfg.iid.config_owner=pxOpInfo->iCaller;
    xVlanCfg.iid.cpeId.Id=0;
    xVlanCfg.iid.pcpeId.Id=uiPcpeid;

    iRet = IFX_ConvertOidDottedForm(pxParamVal->iaOID, xVlanCfg.iid.tr69Id);
    if(iRet != IFX_CWMP_SUCCESS)
    {
        goto errorHandler;
    }
#ifdef IFX_TR69_ADSLWAN
        if(pxParamVal->iaOID[5] == OID_IGD_WAND_WANCD_WANDSLLC)
        {
            sprintf(ParentSecName, "adsl_vcchannel");//TBD. Look up parent section name
            parent_type = 1;
        }
#endif
#ifdef IFX_TR69_PTMWAN
        if(pxParamVal->iaOID[5] == OID_IGD_WAND_WANCD_WANPTMLC)
        {
            sprintf(ParentSecName, "ptm_channel");//TBD. Look up parent section name
            parent_type = 2;
        }
#endif
#ifdef IFX_TR69_ETHERNETWAN
        if(pxParamVal->iaOID[5] == OID_IGD_WAND_WANCD_WANELC)
        {
            sprintf(ParentSecName, "eth_channel");//TBD. Look up parent section name
            parent_type = 3;
        }
#endif


    if(pxOpInfo->iCaller == ACC_ROOT)
    {
        /*Set VLAN ID*/
        xVlanCfg.vlanId = -1;
        /*Set Enable value*/
        xVlanCfg.fEnable = IFX_DISABLED;
        iFlags =(IFX_F_DONT_ACTIVATE | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_VALIDATE  | IFX_F_DONT_WRITE_TO_FLASH);
    }
    else
    {
        /*Set VLAN ID*/
        xVlanCfg.vlanId = IFX_GetRand(LOW_LIMIT_VLANID, UPP_LIMIT_VLANID);

        /*Set Enable value*/
#ifdef IFX_TR69_ADSLWAN
        if(parent_type == 1)
        {
            memcpy(xInParamVal.iaOID, WANDSLLC_EnableOID, (sizeof(int32)*OID_LENGTH));
        }
#endif
#ifdef IFX_TR69_PTMWAN
        if(parent_type == 2)
        {
            memcpy(xInParamVal.iaOID, WANPTMLC_EnableOID, (sizeof(int32)*OID_LENGTH));
        }
#endif
#ifdef IFX_TR69_ETHERNETWAN
        if(parent_type == 3)
        {
            memcpy(xInParamVal.iaOID, WANEthLC_EnableOID, (sizeof(int32)*OID_LENGTH));
        }
#endif
        memcpy(xInParamVal.iaOID, pxParamVal->iaOID, (sizeof(int32)*(WAN_CON_DEV_DEPTH +1)));


        /*Get Value*/ 
        iRet=IFX_GlobalGetVal(&xInParamVal, &paxOutParamArr, &uiOutElem);
        if(iRet != IFX_CWMP_SUCCESS) 
        {
            IFX_PrintOID(xInParamVal.iaOID);
	    IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
            IFX_FreeParamvalArr(&paxOutParamArr, uiOutElem);
            goto errorHandler;
        }
        paxTempParamVal = paxOutParamArr;
        if(paxTempParamVal != NULL)
        {
            for(iJ=0; iJ < uiOutElem; iJ++) 
            {
                if((strcmp(paxTempParamVal->Value,"true") == 0) || (strcmp(paxTempParamVal->Value,"1")== 0))
                {
                    /*Set Enable value*/
                    xVlanCfg.fEnable = 1;
                    iFlags =(IFX_F_DONT_CHECKPOINT | IFX_F_DONT_VALIDATE  | IFX_F_DONT_WRITE_TO_FLASH);
                }
                else
                {
                    /*Set Enable value*/
                    xVlanCfg.fEnable = 0;
                    iFlags =(IFX_F_DONT_ACTIVATE | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_VALIDATE  | IFX_F_DONT_WRITE_TO_FLASH);
                }
            }
        }
        IFX_FreeParamvalArr(&paxOutParamArr, uiOutElem);
    }
    sprintf(sCommand, "%d", uiPcpeid);
    iRet = ifx_ret_substr_from_distfield(FILE_RC_CONF, ParentSecName, "cpeId", sCommand, &retStr);
    if(iRet != IFX_SUCCESS)
    {
	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	goto errorHandler;
    }

    /* Get the old link type */
    sprintf(sCommand, "%s_l2ifName", retStr);
    if((iRet = ifx_GetObjData(FILE_RC_CONF, ParentSecName, sCommand, IFX_F_GET_ANY, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS)
    {
	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	goto errorHandler;
    }
    IFX_MEM_FREE(retStr)

    strncpy(xVlanCfg.baseIf, sValue, MAX_IF_NAME_LEN-1);
    xVlanCfg.baseIf[MAX_IF_NAME_LEN-1] = '\0';
    strcpy(xVlanCfg.iid.pcpeId.secName, ParentSecName);

    iRet = mapi_set_vlan_ch_entry(iOper, &xVlanCfg, iFlags);
    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"mapi_set_vlan_ch_entry add Mgmt API returned error\n");
        goto errorHandler;
        
    }
    return IFIN_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d failed!\n", __func__, __LINE__);
    return IFIN_CWMP_FAILURE;
}

/* 
** =============================================================================
**   Function Name    : Modify
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 Modify(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
                			            IN int32 iElements)
{
    vlan_ch_cfg_t xVlanCfg;
    char8 * psTmpVal = NULL;
    uint32 uiCpeid = 0;
    int32 iRet = IFX_CWMP_SUCCESS;
    uint32 iFlags = IFX_F_DEFAULT;
    int32 iParamOffset = 0;
    int32 iCnt = 0; 


    //Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&uiCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [%d] \n",
                    __func__, __LINE__, iRet);
        goto end;
    }
    xVlanCfg.iid.cpeId.Id = uiCpeid;

    //Get the object from system
    iRet= mapi_get_vlan_ch_entry(-1, &xVlanCfg, IFX_F_GET_ANY);
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] mapi_get_vlan_ch_entry failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
         goto end;
    }
    
    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        goto end;
    }

    switch(pxOpInfo->iSubOper)
    {
        case OP_SETVAL_CHK_MODIFY_DEP:
            break;
        case OP_SETVAL_MODIFY:
        case OP_SETVAL_ACTIVATE:
            /* Iterate and fill the requested parameters */
            for (iCnt = 0; iCnt < iElements; iCnt++)
            {
                psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

                /* Process based on the requested parameter */
                switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
                {
#ifdef IFX_TR69_ADSLWAN
                    case OID_IGD_WAND_WANCD_WANDSLLC_XAC9A96V_X_AC9A96_VLANID:
#endif
#ifdef IFX_TR69_PTMWAN
                    case OID_IGD_WAND_WANCD_WANPTMLC_XAC9A96V_X_AC9A96_VLANID:
#endif
#ifdef IFX_TR69_ETHERNETWAN
                    case OID_IGD_WAND_WANCD_WANELC_XAC9A96V_X_AC9A96_VLANID:
#endif
                        xVlanCfg.vlanId = atoi(psTmpVal);
                        break;     

                    default:
                        iRet = ERR_CWMP_INVAL_PARAM_NAME;
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "Invalid param id %d!\n",
                                    (pxParamVal[iCnt]).iaOID[iParamOffset]);
                        pxParamVal->iFaultCode=ERR_INVAL_PARAMETER_NAME;
                        goto end;
                }
            }
            iFlags = (IFX_F_MODIFY | IFX_F_DONT_WRITE_TO_FLASH);

            if(xVlanCfg.fEnable == IFX_DISABLED)
            {
                /* Disable */
                iFlags = ( iFlags | IFX_F_DEACTIVATE | IFX_F_DONT_VALIDATE);
            }

            iRet = mapi_set_vlan_ch_entry(IFX_OP_MOD, &xVlanCfg, iFlags);
            if(iRet != IFX_CWMP_SUCCESS) 
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] mapi_set_vlan_ch_entry failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
                goto end;
            }

            break;
        }
end:
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
              "%s:%d failed!\n", __func__, __LINE__);
    }
    return iRet;
}

static int32
CheckDeleteDependency(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
                            IN int32 iElements, OUT void **ppxParamStructRet,
                                                   OUT int32 * piNumRetElem)
{
	*ppxParamStructRet = (ParamVal *)IFX_CWMP_MALLOC(sizeof(ParamVal));
	if(*ppxParamStructRet == NULL)
        {
	    return IFX_CWMP_FAILURE;
	}

	memcpy(*ppxParamStructRet, paxParamVal, sizeof(ParamVal));
	*piNumRetElem = 1;
        return IFX_CWMP_SUCCESS;
}
/* 
** =============================================================================
**   Function Name    : SetDelete
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
SetDelete(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
                            IN int32 iElements, OUT void **ppxParamStructRet,
                                                   OUT int32 * piNumRetElem)
{
    uint32 uiCpeId=0;
    vlan_ch_cfg_t xVlanChCfg;
    int32 iRet=0;
    uint32 iOper=0,iFlags=0;
    
    memset(&xVlanChCfg,0x00,sizeof(xVlanChCfg));

    //If owner is WEB don't delete the object just return success.
    if(pxOpInfo->iCaller == ACC_WEB)
        return IFX_CWMP_SUCCESS;

    //Get the Cpeid from Tr69 id

    IFX_PrintOID(paxParamVal->iaOID);
    iRet = IFX_GetCpeId(paxParamVal->iaOID,&uiCpeId);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;
        
    xVlanChCfg.iid.cpeId.Id = uiCpeId;
    iRet= mapi_get_vlan_ch_entry(-1, &xVlanChCfg, IFX_F_GET_ANY);
    if(iRet != IFX_CWMP_SUCCESS)
    {
        goto errorHandler;
    }
    switch(pxOpInfo->iSubOper)
    {
        case OP_SETVAL_CHK_DEL_ALLOWED:
            if(pxOpInfo->iCaller != ACC_ROOT)
            {
                if(xVlanChCfg.vlanId == 0) 
                {
		    iRet = IFX_CWMP_FAILURE;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "Not allowed to delete vlan channel with id=0\n");
		    goto errorHandler;
                }
           }
		break;

        case OP_SETVAL_DELETE:
            //Call Platform API to delete the obj in the system
            xVlanChCfg.iid.config_owner=pxOpInfo->iCaller;
            xVlanChCfg.iid.cpeId.Id = uiCpeId;

            iOper = IFX_OP_DEL;
            iFlags = (IFX_F_DELETE | IFX_F_DONT_VALIDATE |
                    IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH);

            iRet = mapi_set_vlan_ch_entry(iOper, &xVlanChCfg, iFlags);
            if(iRet != IFX_SUCCESS)
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "mapi_set_vlan_ch_entry -Delete Mgmt API returned error\n");
                goto errorHandler;
            }
            break;
            
        default:
            break;
    }
    return IFIN_CWMP_SUCCESS;
    
errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d failed!\n", __func__, __LINE__);
    return IFIN_CWMP_FAILURE;
}


/* 
** =============================================================================
**   Function Name    : SetAttr
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

static int32
SetAttr(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
                            IN int32 iElements)
{
    uint32 iRet=IFX_CWMP_SUCCESS,i=0;
    OperInfo xOpInfo;
    
    xOpInfo.iCaller = pxOpInfo->iCaller;
    xOpInfo.iOper= OP_GETVAL;
    xOpInfo.iSubOper= OP_GETVAL_NORMAL;
    
    iRet = GetVal(&xOpInfo,pxParamVal, iElements);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorFreeHandler;
    
    iRet = IFX_SetAttributesInfo(pxOpInfo,pxParamVal, iElements);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorFreeHandler;

errorFreeHandler:
    for(i=0; i < iElements; i++)
        IFX_CWMP_FREE(pxParamVal[i].Value);
        
    if (iRet)
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed!\n", __func__, __LINE__);
    return iRet;
}



/* 
** =============================================================================
**   Function Name    : IFX_WanVlanInit
**   Description      : 
**   Parameters       : 
**   Return Value     : 
**   Notes            : 
** ============================================================================
*/
int32 IFX_WANVlanInit(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    
#ifdef IFX_TR69_PTMWAN
    /* Register the WanVlan module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_WANPTMLINK_VLAN_OBJ, IFX_WanVlanCfg);
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "Unable to Register %s with Object Model\n",
                     IFX_WANPTMLINK_VLAN_OBJ);
        goto errorHandler;
    }
#endif
#ifdef IFX_TR69_ADSLWAN
    iRet = ifx_ds_register_function(IFX_WANDSLLINK_VLAN_OBJ, IFX_WanVlanCfg);
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "Unable to Register %s with Object Model\n",
                     IFX_WANDSLLINK_VLAN_OBJ);
        goto errorHandler;
    }
#endif
#ifdef IFX_TR69_ETHERNETWAN
    iRet = ifx_ds_register_function(IFX_WANETHLINK_VLAN_OBJ, IFX_WanVlanCfg);
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "Unable to Register %s with Object Model\n",
                     IFX_WANETHLINK_VLAN_OBJ);
        goto errorHandler;
    }
#endif


errorHandler:
            return iRet;
}

/*********************************************************************************
*  Function Name  :  IFX_WanVlanCfg
*  Description    :  This function handles all the sub-states inside
*                    a GET/SET operation.If it is a GET it allocates the 
*                    array(Name,Value pairs) and returns the values.
*                    If it is a SET controller allocates the array and
*                    passes the values to this function.It calls 
*                    respective internal functions which in turn calls 
*                    respective Platform APIs.
*  Parameters    :<par_type> <par_data_type>   <par_name>    <description of par>
*                    IN          OperInfo       pxOper;       Operation, Sub-operation,Owner
*                    INOUT       void *         pParamStruct; Struct which has Name,Value,etc
*                    IN          int32          iElements;    No. of Elements
*                    OUT         void *         ppParamRet;   same as ParamStruc
*                    OUT         int32 *        piNumRetElem; No. of elements                                         
*  Return Value : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes        :
***********************************************************************************/
int32 IFX_WanVlanCfg(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                IN int32 iElements, OUT void **ppaxParamArrRet, OUT int32 *piNumRetElem)
{
     
    /*It calls the respective internal functions which handles resp. sub-operation*/
   
    /*Set-Operation:  
    controller should pass the entire array during all the SET-sub_operations
    It should handle only single get/set of instance at any point of time
    It does not handle partial path
    It won't handle multiple instances of the same object/module at any point of time.*/
    
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *paxParamArr = (ParamVal *)paxParameterArr;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Oper[%d] [%d]\n", __func__, __LINE__, pxOperInfo->iOper, pxOperInfo->iSubOper);

    switch (pxOperInfo->iOper) 
    {
        /*Get the object values*/
        case OP_GETVAL:
        {
            if((iRet = GetVal(pxOperInfo, paxParamArr, iElements)) != IFX_CWMP_SUCCESS)
            {
                      IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
                      goto errorHandler;
            }
            break;
        }
        case OP_SETVAL:
        {
            /*Set the obj values*/
            switch (pxOperInfo->iSubOper) 
            {
                case OP_SETVAL_VALIDATE:
                    if((iRet = Validate(pxOperInfo,paxParamArr,
                                                       iElements)) != IFX_CWMP_SUCCESS)
                    { 
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                       "%s:%d OP_SETVAL_VALIDATE failed!\n", __func__, __LINE__);
                        goto errorHandler;
                    }
                    break;

                case OP_SETVAL_ADD:
                    if((iRet= AddObj(pxOperInfo,paxParamArr,
                                                   iElements))!=IFX_CWMP_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d OP_SETVAL_ADD failed!\n", __func__, __LINE__);
                        goto errorHandler;
                    }                
                    break;

                case OP_SETVAL_CHK_MODIFY_DEP:
                case OP_SETVAL_MODIFY:
                case OP_SETVAL_ACTIVATE:
                    if((iRet = Modify(pxOperInfo, paxParamArr, iElements))!= IFX_CWMP_SUCCESS)
                    {
                        switch(pxOperInfo->iSubOper)
                        {
                            case OP_SETVAL_CHK_MODIFY_DEP:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                           "%s:%d OP_SETVAL_CHK_MODIFY_DEP failed!\n", __func__, __LINE__);
                                goto errorHandler;

                            case OP_SETVAL_MODIFY:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                        "%s:%d OP_SETVAL_MODIFY failed!\n", __func__, __LINE__);
                                goto errorHandler;
                                
                            case OP_SETVAL_ACTIVATE:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                      "%s:%d OP_SETVAL_ACTIVATE failed!\n", __func__, __LINE__);
                                goto errorHandler;
                        }
                    }
                    break;

                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    break;

                case OP_SETVAL_CHK_DEL_DEP:
                    if((iRet= CheckDeleteDependency(pxOperInfo, paxParamArr,
                                    iElements, ppaxParamArrRet,
                                    piNumRetElem))!= IFX_CWMP_SUCCESS)
                    {
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
                                goto errorHandler;
                    }
                    break;
                case OP_SETVAL_DELETE:
                    if((iRet= SetDelete(pxOperInfo, paxParamArr,
                                    iElements, ppaxParamArrRet,
                                    piNumRetElem))!= IFX_CWMP_SUCCESS)
                    {
                        switch(pxOperInfo->iSubOper)
                        {    

                            case OP_SETVAL_CHK_DEL_ALLOWED:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
                                goto errorHandler;

                            case OP_SETVAL_DELETE:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
                                goto errorHandler;
                        }
                    }
                    break;

                case OP_SETVAL_FREE:
                    break;

                case OP_SETVAL_ATTRINFO:
                    if((iRet = SetAttr(pxOperInfo, paxParamArr,
                                              iElements)) != IFX_CWMP_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_SETVAL_ATTRINFO failed!\n", __func__, __LINE__);
                        goto errorHandler;
                    }
                    break;
                        
                default:
                    break;
            }
            break;
        }

        case OP_PARAM_VALIDATE:
        {
            break;
        }

        default:
            break;
    }

errorHandler:
    return iRet;
}
