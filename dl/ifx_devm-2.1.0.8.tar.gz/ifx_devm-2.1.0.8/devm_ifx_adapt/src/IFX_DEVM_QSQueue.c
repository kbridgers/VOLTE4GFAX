/* 
** =============================================================================
**   FILE NAME        : IFX_QSQueue.c
**   PROJECT          : TR69
**   MODULES          : QueueManagement.QueueStats
**   DATE             : 16-05-2012
**   AUTHOR           : QoS TR69 team
**   DESCRIPTION      : This is the Queue Statistics Module. It is required by the 
**                      controller module of TR69 stack to GET/SET/ADD/DELETE
**                      Queue statistics specific information.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author                         $Comment
**   16-05-2012       QoS TR69 team                       Initial Version
**
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_QSQueue.h"
  // Required for STATIC
 
#include "IFX_DEVM_OID.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_StackUtil.h" 
#include "IFX_DEVM_DS.h"

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFX_QUEUE_MGMT_QUEUESTATS_OBJ    FORMNAME("QueueManagement.QueueStats")
/* TBD: Temporary Placeholders, since we do not get this from Platform include
   header files */

/* IPQOS Tags */
#define TAG_IPQOS_QM                              "qos_queuemgmt"
#define TAG_IPQOS_QUEUESTATS                       "qos_queuestats"
#define PREFIX_IPQOS_QUEUESTATS                    "qs"

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

STATIC int32
GetParamOffset(IN int32 *paiOID);
STATIC int32
GetVal(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
       IN int32 iElements);
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
AddObj(IN OperInfo *pxOI,INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
SetDelete(IN OperInfo *pxOI,INOUT ParamVal *pxParamVal,
          IN int32 iElements, OUT void **ppxParamStructRet,
          OUT int32 * piNumRetElem);

STATIC int32 
ParamValidate(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : GetParamOffset
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

STATIC int32
GetParamOffset(IN int32 *paiOID)
{
    int32 iCnt;

    for (iCnt = 0; paiOID[iCnt] != 0; iCnt++);

    return (iCnt - 1);
}

/*
** =============================================================================
**   Function Name    : ParamValidate
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/
STATIC int32
ParamValidate(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
   int32   iRet  = IFX_CWMP_SUCCESS;
   uint32 iCpeid = 0;   
   IFX_MAPI_QoS_QueueStats xQMQS;

   iRet = IFX_GetCpeId(pxParamVal->iaOID,&iCpeid);
   if(iRet != IFX_CWMP_SUCCESS)
        goto cleanup;
   
   ifx_mapi_get_active_qos_iface();
   memset(&xQMQS, 0, sizeof(IFX_MAPI_QoS_QueueStats));
   /* Fill the cpeid in the structure to get the required instance */
   xQMQS.iid.cpeId.Id = iCpeid;   
      
   iRet = ifx_mapi_get_qos_queue_stats(&xQMQS, IFX_F_DEFAULT); 
   /* Check for error */
   if (iRet != IFX_SUCCESS)
   {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_queue_stats failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
   }
   
   cleanup:
    return (iRet);	
}

/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetVal(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
       IN int32 iElements)
{
    int32   iRet  = IFX_CWMP_SUCCESS;
    int32   iRtn  = IFX_SUCCESS;
    int32   iCnt  = 0;
    int32   flag = 0;
    IFX_MAPI_QoS_QueueStats xQMQS;
    int32   iParamOffset;
    uint32 iCpeid = 0;
    uint32 defvalue = 0;
    IFX_MAPI_QoS_Interface_Type qIfType;
    uint32 f1,f2,f3;
    FILE *fp2 = NULL;
    char8 qinst[256] = {0};
    char8 qprio[10] = {0};
    char sCommand[256];
    char device[50];
    uint32 tcchild = 0,upchild = 4,dwchild = 1;


    // Get Cpeid from object ID
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    	goto cleanup;

    memset(&xQMQS, 0, sizeof(IFX_MAPI_QoS_QueueStats));

    /* Fill the cpeid in the structure to get the required instance */
    xQMQS.iid.cpeId.Id = iCpeid;

    /* Get all the IFX_MAPI_QoS_Classifier parameters using Protocol API */
    iRtn = ifx_mapi_get_qos_queue_stats(&xQMQS, IFX_F_DEFAULT);

    sprintf(qinst, "InternetGatewayDevice.QueueManagement.Queue.%u.QueuePrecedence", xQMQS.QueueInst);

    ifx_config_get_value(qinst,qprio);

    sprintf(sCommand,"tc -ltqstat class ls dev imq0 classid 1:4%s",qprio);
    system(sCommand);

    

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_queue failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        goto cleanup; //To fix SCA error.
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* TBD: Currently keeping size as 257 bytes, since max param size is string(256) */
        (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(257);

        /* Check for error */
        if (!((pxParamVal[iCnt]).Value))
        {
            iRet = ERR_OUT_OF_MEMORY;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Allocation Failure\n",
                         __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
        }
    	qIfType = ifx_mapi_get_active_qos_iface();

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_QM_QS_ENABLE:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMQS.Enable);
                break;
            case OID_IGD_QM_QS_STATUS:
                /* Copy the value to allocated area */
                if (xQMQS.Status == IPQOS_STATUS_DISABLED)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Disabled");
                }
                else if (xQMQS.Status == IPQOS_STATUS_ENABLED)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Enabled");
                }
                else
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Error");
                }
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_VALUE_BASED);
                break;
		// Commenting this for the time being.
            case OID_IGD_QM_QS_INTERFACE:
                /* Copy the value to allocated area */
                if (xQMQS.Interface == qIfType)
		{
		    sprintf(device, "%s" , "imq0");
		    tcchild = upchild;
                    sprintf(pxParamVal[iCnt].Value, "%s", "WANDevice");
		}
		else if (xQMQS.Interface == IFX_MAPI_QoS_LAN_ETH)
		{
			sprintf(device, "%s" , "imq1");
			tcchild = dwchild;
			sprintf(pxParamVal[iCnt].Value, "%s", "LANDevice");
		}
                else
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Error");
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Invalid Interface, QoS supports only LAN and WAN interfaces\n",__FILE__, __func__, __LINE__);
                    goto cleanup;
		}
                break;
            case OID_IGD_QM_QS_QUEUE:
                // TBD: Do we support this since we do not support WFR and WRR? Currently Reading from struct
                sprintf(pxParamVal[iCnt].Value, "%u", xQMQS.QueueInst);
                break;
            case OID_IGD_QM_QS_OUTPUTPACKETS:
		if(xQMQS.Enable == 1)
		{
			if(flag != 1)
			{
    				sprintf(qinst, "InternetGatewayDevice.QueueManagement.Queue.%u.QueuePrecedence", xQMQS.QueueInst);
    				ifx_config_get_value(qinst,qprio);
    				sprintf(sCommand,"tc -ltqstat class ls dev %s classid 1:%u%s",device,tcchild,qprio);
    				system(sCommand);
			}
			if((fp2 = fopen("/tmp/qos_queue_stat", "r")) == NULL)
			{
				fprintf(stderr, "Unable to open the qos debug file");
				return -1;
			}
			fscanf(fp2,"%u %u %u",&f1,&f2,&f3);
			sprintf(pxParamVal[iCnt].Value, "%u",f2);	
			fclose(fp2);
			fflush(fp2);
			flag = 1;
		}
		else if(xQMQS.Enable == 0)
		{
			sprintf(pxParamVal[iCnt].Value, "%u", defvalue);
		}
                break;
            case OID_IGD_QM_QS_OUTPUTBYTES:
		if(xQMQS.Enable == 1)
		{
    			if(flag != 1)
			{
				sprintf(qinst, "InternetGatewayDevice.QueueManagement.Queue.%u.QueuePrecedence", xQMQS.QueueInst);
    				ifx_config_get_value(qinst,qprio);
    				sprintf(sCommand,"tc -ltqstat class ls dev %s classid 1:%u%s",device,tcchild,qprio);
    				system(sCommand);
			}
			if((fp2 = fopen("/tmp/qos_queue_stat", "r")) == NULL)
			{
				fprintf(stderr, "Unable to open the qos debug file");
				return -1;
			}
			fscanf(fp2,"%u %u %u",&f1,&f2,&f3);
			sprintf(pxParamVal[iCnt].Value, "%u", f1);	
			fclose(fp2);
			fflush(fp2);
			flag = 1;
		}
		else if(xQMQS.Enable == 0)
		{
			sprintf(pxParamVal[iCnt].Value, "%u", defvalue);
		}
                break;
            case OID_IGD_QM_QS_DROPPEDPACKETS:
		if(xQMQS.Enable == 1)
		{
    			if(flag != 1)
			{
				sprintf(qinst, "InternetGatewayDevice.QueueManagement.Queue.%u.QueuePrecedence", xQMQS.QueueInst);
    				ifx_config_get_value(qinst,qprio);
    				sprintf(sCommand,"tc -ltqstat class ls dev %s classid 1:%u%s",device,tcchild,qprio);
    				system(sCommand);
			}
			if((fp2 = fopen("/tmp/qos_queue_stat", "r")) == NULL)
			{
				fprintf(stderr, "Unable to open the qos debug file");
				return -1;
			}
			fscanf(fp2,"%u %u %u",&f1,&f2,&f3);
			sprintf(pxParamVal[iCnt].Value, "%u", f3);	
			fclose(fp2);
			fflush(fp2);
			flag = 1;
		}
		else if(xQMQS.Enable == 0)
		{
			sprintf(pxParamVal[iCnt].Value, "%u", defvalue);
		}
                break;
            case OID_IGD_QM_QS_DROPPEDBYTES:
		/* Dummy for Now: will return 0 */
                sprintf(pxParamVal[iCnt].Value, "%u", xQMQS.DropBytes);
                break;
            case OID_IGD_QM_QS_QUEUEOCCUPANCYPACKETS:
		/* Dummy for Now: will return 0 */
                sprintf(pxParamVal[iCnt].Value, "%u", xQMQS.QOccPacks);
                break;
            case OID_IGD_QM_QS_QUEUEOCCUPANCYPERCENTAGE:
		/* Dummy for Now: will return 0 */
                sprintf(pxParamVal[iCnt].Value, "%u", xQMQS.QOccPercent);
                break;
            default:
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
                goto cleanup;
        }
    }

cleanup:
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : Modify
**
**   Description      : This function modifies the values of parameters in 
**                      QueueStats object. It calls respective Management
**                      API for same. It performs modification only if parameter 
**                      has Write permission. In certain cases it also performs 
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
#define QUEUEMGMT_QUEUE_DEP_OIDS 1
#define STATS_DEPTH 5
    int32       iRet       = IFX_CWMP_SUCCESS;
    int32       iRtn       = IFX_SUCCESS;
    uint32      iCpeid     = 0;
    int32       iCnt       = 0;
    IFX_MAPI_QoS_QueueStats xQMQS;
    int32       iParamOffset;
    char8       *psTmpVal;
    uint32      uiFlags;
    IFX_MAPI_QoS_Interface_Type qIfType;


    int32 iParamOffset2;
    int32 Queue_Stats_Queue_Oid[6]={OID_IGD,OID_IGD_QM,OID_IGD_QM_QS,MAGIC_NUMBER,OID_IGD_QM_QS_QUEUE};
    ParamVal QSParamArr[QUEUEMGMT_QUEUE_DEP_OIDS];
    ParamVal *QSOutParamArr=NULL;
    ParamVal *QSTempParamArr=NULL;
    uint32 qsOutElem=0;
    char8 *qsval;
    int32 k = 0;
    /* Get all the IFX_MAPI_QoS_Capability parameters using Protocol API */

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_capability failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    memset(QSParamArr,0x00,(sizeof(ParamVal) *QUEUEMGMT_QUEUE_DEP_OIDS));
    
    memcpy(QSParamArr->iaOID,Queue_Stats_Queue_Oid,(sizeof(int32)*(STATS_DEPTH +1)));

    iRet=IFX_GlobalGetVal(QSParamArr,&QSOutParamArr, &qsOutElem);

    if(iRet != IFX_CWMP_SUCCESS) 
    {
    	IFX_PrintOID(QSParamArr->iaOID);
        IFX_FreeParamvalArr(&QSOutParamArr,qsOutElem);
        iRet = IFX_CWMP_SUCCESS;
    }
   
    QSTempParamArr = QSOutParamArr;

    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    iParamOffset = iParamOffset - 1;
    iParamOffset2 = GetParamOffset(QSTempParamArr->iaOID);
    iParamOffset2 = iParamOffset2 - 1;
    qsval = (char *)(QSTempParamArr->Value);
    
    // Get Cpeid from object ID
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    	goto cleanup;

    memset(&xQMQS, 0, sizeof(IFX_MAPI_QoS_QueueStats));

    /* Fill the cpeid in the structure to get the required instance */
    xQMQS.iid.cpeId.Id = iCpeid;

    /* Get all the IFX_MAPI_QoS_Classifier parameters using Protocol API */
    iRtn = ifx_mapi_get_qos_queue_stats(&xQMQS, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_queue failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Set the old enable state */

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    qIfType = ifx_mapi_get_active_qos_iface();

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_QM_QS_ENABLE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
		    if(xQMQS.Interface == qIfType) {
			xQMQS.Enable = TRUE;
			xQMQS.Status = IPQOS_STATUS_ENABLED;
		    } else {
			(pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    	iRet = ERR_CWMP_INVAL_ARGS;
                    	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] \n Queue is not attached to the active interface\n",__FILE__, __func__, __LINE__, iRet);
                  	goto cleanup;
		    }
                }
                else
                {
                    xQMQS.Enable = FALSE;
		    xQMQS.Status = IPQOS_STATUS_DISABLED;
                }
                break;
            case OID_IGD_QM_QS_INTERFACE:
		    if(strstr(psTmpVal,"WANDevice") != NULL) {
                        xQMQS.Interface = qIfType;
		    }
		    else if(strstr(psTmpVal,"LANDevice") != NULL) {
                        xQMQS.Interface = IFX_MAPI_QoS_LAN_ETH;
		    }
		    else {
			(pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        iRet = ERR_CWMP_INVAL_ARGS;
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] \n QoS is supported only for LAN and WAN interfaces\n",
                                __FILE__, __func__, __LINE__, iRet);
                        goto cleanup;
		    }
                break;
            case OID_IGD_QM_QS_QUEUE:
                xQMQS.QueueInst = atoi(psTmpVal);
                break;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

    for( k=0; k < qsOutElem; ++k)
    {
	    if(QSTempParamArr != NULL)
	    {
	    	qsval = (char *)(QSTempParamArr->Value);
	    
	    	if(atoi(qsval) == xQMQS.QueueInst)
	    	{
			iRet = ERR_CWMP_REQUEST_DENIED;
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%s:%d] Stats already exists for this Queue\n", __FILE__, __func__, __LINE__);
        		goto cleanup;
	 	}
	    }
	    QSTempParamArr++;
    }

    /* Fill the iid structure in IFX_MAPI_QoS_Queue*/
    xQMQS.iid.config_owner = iCaller;

    /* Set all the IFX_MAPI_QoS_Queue parameters using Object API */
    uiFlags = IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH;
    if ( xQMQS.Enable == FALSE)
    {
        uiFlags |= IFX_F_DONT_VALIDATE;
#if 0
        if (ucOldEnableState == TRUE)
            uiFlags |= IFX_F_DEACTIVATE;
        else
            uiFlags |= IFX_F_DONT_ACTIVATE;
#endif
    }
    iRtn = ifx_mapi_set_qos_queue_stats(IFX_OP_MOD, &xQMQS, uiFlags);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to set values of all "
                    "parameters\n", __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    return (iRet);

}

/* 
** =============================================================================
**   Function Name    : Validate
**
**   Description      : This function validates the values of parameters in
**                      QueueStats object.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      validated.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When validation of all parameters is
**                      successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in validating at least one parameter.
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iCnt;
    int32   iParamOffset;
    char8   *psTmpVal;

   /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Iterate and validate the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Return a failure if the value is NULL pointer */
        if (!psTmpVal)
        {
            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
            iRet = ERR_CWMP_INVAL_ARGS;
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_QM_QS:
            case OID_IGD_QM_QS_ENABLE:
            case OID_IGD_QM_QS_STATUS:
            case OID_IGD_QM_QS_QUEUE:
            case OID_IGD_QM_QS_INTERFACE:
            case OID_IGD_QM_QS_OUTPUTPACKETS:
            case OID_IGD_QM_QS_OUTPUTBYTES:
            case OID_IGD_QM_QS_DROPPEDPACKETS:
            case OID_IGD_QM_QS_DROPPEDBYTES:
            case OID_IGD_QM_QS_QUEUEOCCUPANCYPACKETS:
            case OID_IGD_QM_QS_QUEUEOCCUPANCYPERCENTAGE:
                /* TBD: Will be done later if required */
                break;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

cleanup:
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Validating requested parameter failed\n",
                    __FILE__, __func__, __LINE__, iRet);
    }
    return (iRet);

}

STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iCnt;
    int32 iParamOffset;
    int32 iValueFlag = 0; /* Mandatory */

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Set the fault code to Success and value to NULL pointer for all parameters
       other than uptime */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Mark that values have been malloced. Currently always doing it, since not possible
       to keep track in a loop, for which params its malloced */
    iValueFlag = 1;

    /* Update Attribute Information */
    iRet = IFX_SetAttributesInfo(NULL, pxParamVal, iElements);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Updating Param Attribute Info failed\n",
                    __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    /* Free the Value that has been allocated */
    if (iValueFlag)
    { 
        for (iCnt = 0; iCnt < iElements; iCnt++)
        {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
        }
    }

    return (iRet);

}

STATIC int32
AddObj(IN OperInfo *pxOI,INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32 iRet=IFX_CWMP_SUCCESS;
    int32       iRtn       = IFX_SUCCESS;
    uint32 iFlags=0;
    uint32 iOper;
    uint32 uiPcpeId=0;
    IFX_MAPI_QoS_QueueStats xQMQS;
    int32 iParamOffset;
    uint32 uiInstanceCount = 0;
    IFX_MAPI_QoS_Interface_Type qIfType;

//TBD: Need to put a check on the number of queues allowed in the system
    /* Get all the IFX_MAPI_QoS_Capability parameters using Protocol API */

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_capability failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

   qIfType = ifx_mapi_get_active_qos_iface();
 
   uiInstanceCount = 0;
   uiInstanceCount = ifx_mapi_get_queue_count_for_wan_mode(qIfType);
   if ( ( (uiInstanceCount >= 4) && (qIfType == IFX_MAPI_QoS_WAN_ETH_0)) || (uiInstanceCount >= 8) )
   {
        iRet = ERR_RESOURCE_EXCEEDED;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d] Cannot add more Queues\n",
                    __FILE__,  __func__, __LINE__);
        goto cleanup;
   }

    memset(&xQMQS, 0, sizeof(IFX_MAPI_QoS_QueueStats));

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

                xQMQS.Enable = FALSE;
                xQMQS.QueueInst = 0;
		xQMQS.Status = IPQOS_STATUS_DISABLED;
		xQMQS.OutPacks = 0;
		xQMQS.OutBytes = 0;
		xQMQS.DropPacks = 0;
		xQMQS.DropBytes = 0;
		xQMQS.QOccPacks = 0;
		xQMQS.QOccPercent = 0;
		xQMQS.Interface = qIfType;
        //TBD: Fill in the required params

	//Fill the operation
	iOper = IFX_OP_ADD;
	
	//Fills the Cpeid,ParentCepid,TR69Id,Owner
	iRet = IFX_GetParentObjCpeId(pxParamVal->iaOID,&uiPcpeId);
	if(iRet != IFX_CWMP_SUCCESS)
		goto cleanup;

	xQMQS.iid.config_owner=pxOI->iCaller;
	xQMQS.iid.cpeId.Id=0;
	xQMQS.iid.pcpeId.Id=uiPcpeId;
	//Convert array into dotted form and then strcpy
	
	iRet = IFX_ConvertOidDottedForm(pxParamVal->iaOID, xQMQS.iid.tr69Id);
	if(iRet != IFX_CWMP_SUCCESS)
		goto cleanup;

	//Flags should be filled
	iFlags =(	IFX_F_DONT_CHECKPOINT|
			IFX_F_DONT_VALIDATE|IFX_F_DONT_WRITE_TO_FLASH);
	iRtn = ifx_mapi_set_qos_queue_stats(iOper, &xQMQS, iFlags);

	if(iRtn != IFX_SUCCESS)
	{
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"ifx_mapi_set_qos_queue_stats AddObj Mgmt API"					                          " returned error\n");
        iRet = ERR_CWMP_INTERNAL;
		goto cleanup;
		
	}	

cleanup:
return iRet;

}

STATIC int32
SetDelete(IN OperInfo *pxOI,INOUT ParamVal *pxParamVal,
          IN int32 iElements, OUT void **ppxParamStructRet,
          OUT int32 * piNumRetElem)
{
#define QUEUEMGMT_QUEUESTATS_OPTION_NO_OF_DEP_OIDS 0
    int32 iRet=IFX_CWMP_SUCCESS;
    int32 iRtn=IFX_SUCCESS;
    uint32 uiCpeid=0;
    IFX_MAPI_QoS_QueueStats xQMQS;
    uint32 iOper=0,iFlags=0;
    int32  iParamPos=0;
    ParamVal *Param_DepOids=NULL;
    char8       sQID[20]; //Max size of int
    IFX_MAPI_QoS_Interface_Type qIfType;

    // handle CHK_DELETE_DEP
    if(pxOI->iSubOper == OP_SETVAL_CHK_DEL_DEP)
    {
        Param_DepOids = IFIN_CWMP_MALLOC((QUEUEMGMT_QUEUESTATS_OPTION_NO_OF_DEP_OIDS+1)* sizeof(ParamVal));
        if(Param_DepOids == NULL)
        {
           iRet = ERR_OUT_OF_MEMORY; 
           goto cleanup;
        }

        //Get the WanIpConParamPos 
        iParamPos = IFX_GetParamIdPos(pxParamVal->iaOID);
        if (iParamPos < 0){
	    IFX_CWMP_FREE(Param_DepOids);
            goto cleanup; //To fix SCA error
	}

        memcpy((Param_DepOids+0)->iaOID,pxParamVal->iaOID,
               (sizeof(int32)*(iParamPos+1)));

      *ppxParamStructRet = (void *)Param_DepOids;
      *piNumRetElem = QUEUEMGMT_QUEUESTATS_OPTION_NO_OF_DEP_OIDS+1;

        return IFIN_CWMP_SUCCESS;
    }

    if(pxOI->iSubOper == OP_SETVAL_CHK_DEL_ALLOWED)
    {
        return IFIN_CWMP_SUCCESS;
    }

    /* Get all the IFX_MAPI_QoS_QueueStats parameters using Protocol API */
    qIfType = ifx_mapi_get_active_qos_iface();
    // Get Cpeid from object ID
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&uiCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    	goto cleanup;

    /* Allow deleting the Queue, only if no  classifiers are attached to it */
    sprintf(sQID,"%d", uiCpeid);

    memset(&xQMQS, 0, sizeof(IFX_MAPI_QoS_QueueStats));

    /* Fill the cpeid in the structure to get the required instance */
    xQMQS.iid.cpeId.Id = uiCpeid;

    /* Get all the IFX_MAPI_QoS_Queue parameters using Protocol API */
    iRtn = ifx_mapi_get_qos_queue_stats(&xQMQS, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_queue failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* check whether the queue is attached to the active interface */
    if(qIfType != xQMQS.Interface) {
	iRet = ERR_CWMP_REQUEST_DENIED;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] Queue doesnot belong to the active interface\n",
                     __FILE__, __func__, __LINE__);
        goto cleanup;

    }

    xQMQS.iid.config_owner=pxOI->iCaller;
    xQMQS.iid.cpeId.Id=uiCpeid;
    memset(xQMQS.iid.tr69Id,0x00,MAX_TR69_ID_LEN);
    iOper = IFX_OP_DEL;
    iFlags = (IFX_F_DELETE|IFX_F_DONT_VALIDATE| IFX_F_DONT_CHECKPOINT|IFX_F_DONT_WRITE_TO_FLASH);
    iRtn = ifx_mapi_set_qos_queue_stats(iOper, &xQMQS, iFlags);
    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "ifx_mapi_set_qos_queue -delete Mgmt API returned error\n");
        iRet = ERR_CWMP_INTERNAL;
        goto cleanup;
    }

cleanup:
    return iRet;
}



/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : IFX_QMQueueStats_Init
**
**   Description      : This function is called by the controller. It registers
**                      the function responsible for handling Queue
**                      object with data structure. It also performs
**                      initializations specific to Queue object.
**
**   Parameters       : No Parameters. 
**
**   Return Value     : IFX_CWMP_SUCCESS - When Queue object is
**                      initialized successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in initializing Queue object.
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_QMQueueStats_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the Classification module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_QUEUE_MGMT_QUEUESTATS_OBJ, IFX_QMQueueStats);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_QUEUE_MGMT_QUEUESTATS_OBJ);
        goto cleanup;
    }

cleanup:
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_QMQueueStats
**
**   Description      : This function is called by the controller. It handles
**                      QueueStats object and performs  based on requested
**                      operations/suboperations by invoking internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_QMQueueStats(IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
             OUT void **ppRet, OUT int32 *piNumRetElem)
{
    int32       iRet           = IFX_CWMP_SUCCESS, iCnt=0;
    ParamVal    *pxParamVal    = (ParamVal *)pParamList;
    /* Process based on type of Operation */
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:

                    /* Get values of all the requested parameters */
                    iRet = GetVal(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_SETVAL:

            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:

                    /* Validate values of all the requested parameters */
                    iRet = Validate(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:

                    /* Check modify dependency of all requested parameters */
                    iRet = IFX_CWMP_SUCCESS;
                    break;
                case OP_SETVAL_MODIFY:

                    /* Set values of all the requested parameters */
                    iRet = Modify(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ATTRINFO:

                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ADD:
                    iRet = AddObj(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }
                    break;
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
                case OP_SETVAL_DELETE:
                    if((iRet= SetDelete(pxOI, pxParamVal,
                        iNumElem, ppRet, piNumRetElem))!= IFX_CWMP_SUCCESS)
                    {

                        switch(pxOI->iSubOper)
                        {
                            case OP_SETVAL_CHK_DEL_DEP:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
                                goto cleanup;
                            case OP_SETVAL_CHK_DEL_ALLOWED:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
                                goto cleanup;
                            case OP_SETVAL_DELETE:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
                                goto cleanup;
                        }
                    }
                    break;



                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_UPDATE_CHILDINFO:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD: 
                case OP_UPDATE_CHILDINFO_DEL: 
                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_PARAM_VALIDATE:
        {
            iRet = ParamValidate(pxOI, pxParamVal, iNumElem);
            /* Check for error */
            if (iRet != IFX_CWMP_SUCCESS)
            {
                for(iCnt = 0; iCnt < iNumElem; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
                }
		iRet = IFX_CWMP_SUCCESS;
		goto cleanup;
            }
	    break; 
        }
        default:
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid Operation\n",
                         __func__, __LINE__, iRet);
            goto cleanup;
    }

cleanup:
    return (iRet);
}
