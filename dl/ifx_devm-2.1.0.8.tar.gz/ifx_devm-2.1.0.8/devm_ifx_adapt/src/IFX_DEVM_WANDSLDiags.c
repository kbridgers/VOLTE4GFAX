/* 
** =============================================================================
**   FILE NAME        : IFX_WanDslDiagnostics.c
**   PROJECT          : TR69
**   MODULES          : WanDslDiagnostics
**   DATE             : 04-09-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This module handles ADD/DEL/GET/SET RPCs of 
**                      WanDslDiagnostics. When controller calls this module it
**                      calls respective Platform/Object APIs to handle GET/SET 
**                      of WanDslDiagnostics specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author        $Comment
**   04-09-06         TR69 team      Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/

//#include <sys/socket.h>
//#include <netinet/in.h>
//#include <arpa/inet.h>

#include "IFX_DEVM_WANDSLDiags.h"
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
 
 
 
#include "ifx_amazon_cfg.h"

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;

extern Map_Value gaxWanDiagnosticState[];

#define IFX_WAN_DSL_DIAG_OBJ "InternetGatewayDevice.WANDevice.1.WANDSLDiagnostics"
#define NO_CHAR_IN_INT 6
#define NO_ELEMS_COMPLEX_VAL 2
#define NO_SEPARATORS 1
/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/




//extern Map_Value gaxEnable[];
//extern Map_Value saxDslLnkType[];


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/

#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
int32 ifx_set_wan_dsl_diag_stub(int32 op, WAN_DSL_DIAGNOSTICS * pxWan_Dsl_Diag, uint32 flags)
 	{

		if(pxWan_Dsl_Diag == NULL)
		{
		   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Passed object has NULL Pointer !!! \n");
		   return IFX_SUCCESS;
		}
		
		if(op == IFX_OP_ADD)
		{
		 	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Add operation \n");
		}else if(op == IFX_OP_DEL)
		{
		 	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Del operation \n");
				
		 }else if (op == IFX_OP_MOD)
	 	{
	 		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Modify operation \n");
	 	}else 	
	 	{
	 	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: GET operation \n");
	 	}


		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_DSLDIAG_ENABLE=%d\n",flags);
		
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_DSLDIAG_CONFIG_OWNER=%d\n",pxWan_Dsl_Diag->iid.config_owner);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_DSLDIAG_CPEID=%d\n",pxWan_Dsl_Diag->iid.cpeId.Id);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_DSLDIAG_tr69id=%s\n",pxWan_Dsl_Diag->iid.tr69Id);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_DSLDIAG_DIAG_STATE=%d\n",pxWan_Dsl_Diag->diagnostic_state);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_DSLDIAG_ACTPSDds=%d\n",pxWan_Dsl_Diag->ACTPSDds);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_DSLDIAG_ACTPSDus=%d\n",pxWan_Dsl_Diag->ACTPSDus);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_DSLDIAG_ACTATPds=%d\n",pxWan_Dsl_Diag->ACTATPds);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_DSLDIAG_ACTATPus=%d\n",pxWan_Dsl_Diag->ACTATPus);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_DSLDIAG_HLINSCds=%d\n",pxWan_Dsl_Diag->HLINSCds);
		
		
	return IFX_SUCCESS;
	}

#endif

/*
typedef enum data_type
{
   IFX_UCHAR_DATA_TYPE=0,
   IFX_UINT16_DATA_TYPE

}IFX_ARR_DATA_TYPE;
*/

#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
int32
IFX_ConvertArrtoString(IN uint32 uiNoElems, INOUT char8 *sBuf, IN void *aArr, IN uint32 uiDataType)
{

	uint32 i=0;
	char8 sTemp[MAX_NAME_LEN]="";
	
	uchar8 *ucArr=NULL;
	uint16 *uiArr=NULL;

	if(sBuf == NULL)
		goto errorHandler;

	 if(uiDataType == IFX_UCHAR_DATA_TYPE) {
		ucArr = (uchar8 *)aArr;
		for(i=0;i < uiNoElems; ++i)
		{
			memset(sTemp,'\0', MAX_NAME_LEN);
			sprintf(sTemp,"%d,",ucArr[i]);		
			strcat(sBuf,sTemp);
		}

	 } else {
		uiArr = (uint16 *)aArr;
		for(i=0;i < uiNoElems; ++i)
		{
			memset(sTemp,'\0', MAX_NAME_LEN);
			sprintf(sTemp,"%d,",uiArr[i]);		
			strcat(sBuf,sTemp);
		}

	}

	

	return IFX_CWMP_SUCCESS;

	errorHandler:
		return IFX_CWMP_FAILURE;
		

}
#endif

static int32 
IFX_ConvertToWanDslDiagStruct(IN uint32 iElements, IN ParamVal *paxParamVal,
								OUT WAN_DSL_DIAGNOSTICS* pxDiag_State)
{
	uint32 i;
	int32 iRet;
	//uchar8 usDestAddr[MAX_NAME_LEN];
	uint32 uiParamPos=0;
	
	uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);
	
	for (i=0; i < iElements; i++) 
	{

	      	switch(paxParamVal->iaOID[uiParamPos])
		{

				case OID_IGD_WAND_WANDSLD_LOOPDIAGNOSTICSSTATE:
					if(IFX_FwdMappingValues(gaxWanDiagnosticState,2,
							(void *)(paxParamVal->Value),
							(void *)&(pxDiag_State->diagnostic_state)) !=IFIN_CWMP_SUCCESS)
					{
						iRet=ERR_CWMP_INVAL_PARAM_VAL;
						goto errorHandler;
					}
					break;
																	
									
				default:
					break;

		}


		++paxParamVal;
		
	}

	return IFIN_CWMP_SUCCESS;
	
	errorHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
		return iRet;
		
}



/* 
** =============================================================================
**   Function Name    : IFX_WanDslDiagGetValue
**   Description        : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes                : 
**
** ============================================================================
*/
static int32 
IFX_WanDslDiagGetValue(IN OperInfo *pxOperInfo,INOUT ParamVal *pxGetParamVal,
								IN uint32 iElements)
{
	/*GET PARAMETER VALUES
	**Get Object OID(skip parameter ID) from the first 
	**element in the array.Get Cpeid for this Object OID

	**Get the object from the system using a Platform API
	**with cpeid 
	
	**Do reverse mapping to convert system values into TR69
	**Values.After conversion stores the values in temp storage

	**While assigning the values as per request store the 
	**values in heap and assign the ptr to the struct
	**Return all the values 
	*/

	uint32 uiFlags=0;
	uint32 iCpeid=0,i=0;
	int32 iParamId=0;
	uint32 uiParamPos=0;
	int32 iRet=IFX_CWMP_SUCCESS;
	uint32 uiMode=IFX_CHK_CHANGE_FLAG_BASED;
	uint32 HLINpsds_ALLOC_SIZE=10;
	uint32 ALLOC_SIZE=10;
	WAN_DSL_DIAGNOSTICS xWan_Dsl_Diag;
	
	// Get Cpeid from object ID
	iRet = IFX_GetCpeId(pxGetParamVal->iaOID,&iCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	memset(&xWan_Dsl_Diag, '\0',sizeof(xWan_Dsl_Diag));
	xWan_Dsl_Diag.iid.cpeId.Id =iCpeid;
	uiFlags = IFX_F_GET_ANY;

#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
	// Get match object from system using Platform API
	iRet = ifx_cpe_api_get_dsl_diagnostics(&xWan_Dsl_Diag, uiFlags);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
#endif	
	
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
	HLINpsds_ALLOC_SIZE = (DSL_MAX_NSC * NO_CHAR_IN_INT * NO_ELEMS_COMPLEX_VAL) +
				 (DSL_MAX_NSC * NO_ELEMS_COMPLEX_VAL);
        ALLOC_SIZE = (DSL_MAX_NSC * NO_CHAR_IN_INT) + DSL_MAX_NSC; 
#endif	
	//Get the WanIpConParamPos 
	uiParamPos = IFX_GetParamIdPos(pxGetParamVal->iaOID);
		
	for(i=0;i < iElements; i++)
	{
		iParamId = pxGetParamVal->iaOID[uiParamPos];
	
		// Malloc and assign the pointer to the Value attr of struct 
		switch(iParamId)
		{

			// Convert the value - reverse mapping
			// Assign the correct value to the Value attr	
	    		case OID_IGD_WAND_WANDSLD_LOOPDIAGNOSTICSSTATE:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);

				if(IFX_RevMappingValues(gaxWanDiagnosticState,7,
						(void *)&(xWan_Dsl_Diag.diagnostic_state),
						(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
					goto errorHandler;
				break;	 
					
	    		case OID_IGD_WAND_WANDSLD_ACTATPDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
				if(pxGetParamVal->Value == NULL)
				{
					goto errorHandler;
				}
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
				sprintf(pxGetParamVal->Value,"%d",xWan_Dsl_Diag.dsLineStatus.data.ACTATP);
#endif	
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;	 

			case OID_IGD_WAND_WANDSLD_ACTATPUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
                                if(pxGetParamVal->Value == NULL)
                                {
                                       goto errorHandler;
                                }

#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
				sprintf(pxGetParamVal->Value,"%d", xWan_Dsl_Diag.usLineStatus.data.ACTATP);
#endif	
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
								
			case OID_IGD_WAND_WANDSLD_ACTPSDDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
                                if(pxGetParamVal->Value == NULL)
                                {
                                      goto errorHandler;
                                }
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
				sprintf(pxGetParamVal->Value,"%d",xWan_Dsl_Diag.dsLineStatus.data.ACTPS);
#endif	
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
		
				break;
			case OID_IGD_WAND_WANDSLD_ACTPSDUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
                                if(pxGetParamVal->Value == NULL)
                                {
                                     goto errorHandler;
                                }
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
				sprintf(pxGetParamVal->Value,"%d", xWan_Dsl_Diag.usLineStatus.data.ACTPS);
#endif	
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
					break;
					
			case OID_IGD_WAND_WANDSLD_HLINSCDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
                                if(pxGetParamVal->Value == NULL)
                                {
                                      goto errorHandler;
                                }
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
				sprintf(pxGetParamVal->Value,"%d",xWan_Dsl_Diag.hlinScale.data.nDeltHlinScale);
#endif	
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			case OID_IGD_WAND_WANDSLD_HLINSCUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
                                if(pxGetParamVal->Value == NULL)
                                {
                                       goto errorHandler;
                                }
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
				sprintf(pxGetParamVal->Value,"%d",xWan_Dsl_Diag.hlinScaleus.data.nDeltHlinScale);
#endif	
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

				
			case OID_IGD_WAND_WANDSLD_HLINPSDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(HLINpsds_ALLOC_SIZE);
				//Call the func to convert the array of integers into comma separated string
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
				iRet = IFX_ConvertArrtoString((2*DSL_MAX_NSC),pxGetParamVal->Value,
						&(xWan_Dsl_Diag.hlin.data.deltHlin.nNSCComplexData),
										IFX_UINT16_DATA_TYPE);
#endif	
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			case OID_IGD_WAND_WANDSLD_HLINPSUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(HLINpsds_ALLOC_SIZE);
				//Call the func to convert the array of integers into comma separated string
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
				iRet = IFX_ConvertArrtoString((2*DSL_MAX_NSC),pxGetParamVal->Value,
						&(xWan_Dsl_Diag.hlinus.data.deltHlin.nNSCComplexData),
										IFX_UINT16_DATA_TYPE);
#endif	
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

#ifdef IFX_TR69_VDSL2DSLDIAGNOSTICS                                   
			case OID_IGD_WAND_WANDSLD_HLINGDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
                                if(pxGetParamVal->Value == NULL)
                                {
                                        goto errorHandler;
                                }
				#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
				sprintf(pxGetParamVal->Value,"%u",xWan_Dsl_Diag.hlin.data.nGroupSize);
				#endif
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			case OID_IGD_WAND_WANDSLD_HLINGUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
                                if(pxGetParamVal->Value == NULL)
                                {
                                         goto errorHandler;
                                }
				#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
				sprintf(pxGetParamVal->Value,"%u",xWan_Dsl_Diag.hlinus.data.nGroupSize);
				#endif
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
#endif
			case OID_IGD_WAND_WANDSLD_LATNPBDS:
			case OID_IGD_WAND_WANDSLD_LATNPBUS:
			case OID_IGD_WAND_WANDSLD_SATNDS:
			case OID_IGD_WAND_WANDSLD_SATNUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
                                if(pxGetParamVal->Value == NULL)
                                {
                                        goto errorHandler;
                                }
				((char*)pxGetParamVal->Value)[0] = '\0';
				break;

#ifdef IFX_TR69_VDSL2DSLDIAGNOSTICS                                   
			case OID_IGD_WAND_WANDSLD_HLOGGDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
                                if(pxGetParamVal->Value == NULL)
                                {
                                        goto errorHandler;
                                }
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
				sprintf(pxGetParamVal->Value,"%u",xWan_Dsl_Diag.hlogds.data.nGroupSize);
#endif
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			case OID_IGD_WAND_WANDSLD_HLOGGUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
                                if(pxGetParamVal->Value == NULL)
                                {
                                         goto errorHandler;
                                }
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
				sprintf(pxGetParamVal->Value,"%u",xWan_Dsl_Diag.hlogus.data.nGroupSize);
#endif
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
#endif
			case OID_IGD_WAND_WANDSLD_HLOGPSDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(HLINpsds_ALLOC_SIZE);
				//Call the func to convert the array of integers into comma separated string
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
				iRet = IFX_ConvertArrtoString((2*DSL_MAX_NSC),pxGetParamVal->Value,
						&(xWan_Dsl_Diag.hlogds.data.deltHlog.nNSCData),
										IFX_UINT16_DATA_TYPE);
#endif	
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			case OID_IGD_WAND_WANDSLD_HLOGPSUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(HLINpsds_ALLOC_SIZE);
				//Call the func to convert the array of integers into comma separated string
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
				iRet = IFX_ConvertArrtoString((2*DSL_MAX_NSC),pxGetParamVal->Value,
						&(xWan_Dsl_Diag.hlogus.data.deltHlog.nNSCData),
										IFX_UINT16_DATA_TYPE);
#endif	
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			case OID_IGD_WAND_WANDSLD_HLOGMTDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
				sprintf(pxGetParamVal->Value,"%u",xWan_Dsl_Diag.hlogds.data.nMeasurementTime);
#endif
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			case OID_IGD_WAND_WANDSLD_HLOGMTUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
				sprintf(pxGetParamVal->Value,"%u",xWan_Dsl_Diag.hlogus.data.nMeasurementTime);
#endif
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			case OID_IGD_WAND_WANDSLD_QLNPSDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
				iRet = IFX_ConvertArrtoString(DSL_MAX_NSC,pxGetParamVal->Value,
							      (void *)&(xWan_Dsl_Diag.qln.data.deltQln.nNSCData),
 								IFX_UCHAR_DATA_TYPE);
#endif	
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			case OID_IGD_WAND_WANDSLD_QLNPSUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
				iRet = IFX_ConvertArrtoString(DSL_MAX_NSC,pxGetParamVal->Value,
							      (void *)&(xWan_Dsl_Diag.qlnus.data.deltQln.nNSCData),
 								IFX_UCHAR_DATA_TYPE);
#endif	
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

#ifdef IFX_TR69_VDSL2DSLDIAGNOSTICS                                   
			case OID_IGD_WAND_WANDSLD_QLNGDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
				#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
				sprintf(pxGetParamVal->Value,"%u",xWan_Dsl_Diag.qln.data.nGroupSize);	
				#endif
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			case OID_IGD_WAND_WANDSLD_QLNGUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
				#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
				sprintf(pxGetParamVal->Value,"%u",xWan_Dsl_Diag.qlnus.data.nGroupSize);	
				#endif
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
#endif
			case OID_IGD_WAND_WANDSLD_QLNMTDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
				#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
				sprintf(pxGetParamVal->Value,"%u",xWan_Dsl_Diag.qln.data.nMeasurementTime);	
				#endif
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			case OID_IGD_WAND_WANDSLD_QLNMTUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
				#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
				sprintf(pxGetParamVal->Value,"%u",xWan_Dsl_Diag.qlnus.data.nMeasurementTime);	
				#endif	
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			case OID_IGD_WAND_WANDSLD_SNRPSDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
				#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
				iRet = IFX_ConvertArrtoString(DSL_MAX_NSC,pxGetParamVal->Value,
							(void *)&(xWan_Dsl_Diag.snrds.data.deltSnr.nNSCData),
								IFX_UCHAR_DATA_TYPE);
				#endif	
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			case OID_IGD_WAND_WANDSLD_SNRPSUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
				#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
				iRet = IFX_ConvertArrtoString(DSL_MAX_NSC,pxGetParamVal->Value,
							(void *)&(xWan_Dsl_Diag.snrus.data.deltSnr.nNSCData),
								IFX_UCHAR_DATA_TYPE);
				#endif
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			case OID_IGD_WAND_WANDSLD_SNRMTDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
				#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
				sprintf(pxGetParamVal->Value,"%u",xWan_Dsl_Diag.snrds.data.nMeasurementTime);	
				#endif	
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			case OID_IGD_WAND_WANDSLD_SNRMTUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
				#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
				sprintf(pxGetParamVal->Value,"%u",xWan_Dsl_Diag.snrus.data.nMeasurementTime);	
				#endif
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

#ifdef IFX_TR69_VDSL2DSLDIAGNOSTICS                                   
			case OID_IGD_WAND_WANDSLD_SNRGDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
				#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
				sprintf(pxGetParamVal->Value,"%u",xWan_Dsl_Diag.snrds.data.nGroupSize);	
				#endif
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			case OID_IGD_WAND_WANDSLD_SNRGUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
				#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
				sprintf(pxGetParamVal->Value,"%u",xWan_Dsl_Diag.snrus.data.nGroupSize);	
				#endif
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
#endif

			case OID_IGD_WAND_WANDSLD_BITSPSDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
				#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
				iRet = IFX_ConvertArrtoString(DSL_MAX_NSC,pxGetParamVal->Value,
							(void *)&(xWan_Dsl_Diag.bit.data.bitAllocationNsc.nNSCData),
								IFX_UCHAR_DATA_TYPE);
				#endif
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			case OID_IGD_WAND_WANDSLD_GAINSPSDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
				#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
				iRet = IFX_ConvertArrtoString(DSL_MAX_NSC,pxGetParamVal->Value,
						(void *)&(xWan_Dsl_Diag.gain.data.gainAllocationNsc.nNSCData),
									IFX_UINT16_DATA_TYPE);
				#endif	
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
				
			default:
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "Invalid param id %d!\n", iParamId);
			pxGetParamVal->iFaultCode=ERR_INVAL_PARAMETER_VAL;
			break;
		}
		++pxGetParamVal;
	}	
	return IFX_CWMP_SUCCESS;
		
errorHandler:
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
	ifx_set_wan_dsl_diag_stub(pxOperInfo->iOper, &xWan_Dsl_Diag, uiFlags);
#endif
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
       		 "%s:%d ParamId = %d failed!\n", __func__, __LINE__,iParamId);
			
	return IFIN_CWMP_FAILURE;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslDiagSetValidate
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanDslDiagSetValidate(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
							IN int32 iElements)
{
	
	
	return IFIN_CWMP_SUCCESS;

}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslDiagAddObj
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanDslDiagAddObj(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{

		
	return IFIN_CWMP_SUCCESS;

	
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslDiagSetValue
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanDslDiagSetValue(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
							IN int32 iElements)
{

	//It can support only one state change in a SET operation.
	//Enabled to Disabled, Disabled to Enabled 
	
	//Get the Cpeid
	//Get the object from the system
	//Get the state(Enable/Disbale) of the object

	//Handle CHECK_MODIFY_DEP
	//Check if the state change is allowed or not

	//Handle MODIFY	
	//Get the old state
	//Forward mapping of values

	//Modify Enabled object
	//Modify Disabled object
	//Modify the disabled object and enable that object.
	//Diable the object and modify it.


	//uint32 i;
	uint32 uiCpeid=0;
	//uint32 uiOld_EnableVal=0;
	WAN_DSL_DIAGNOSTICS xWan_Dsl_Diag;
	int32 iRet=IFX_CWMP_SUCCESS;
	uint32 iOper=0,iFlags=0;
//	uint32 uiOutElem=0;
	uint32 uiFlags;
	int32 iFIFOFd;
	
        if(paxParamVal[0].iaOID[2] != WAN_DEVICE_ATM)
        {
            iRet = IFX_CWMP_SUCCESS;
            goto errorHandler;
        }
	
	//Get the Cpeid from Tr69 id
	iRet = IFX_GetCpeId(paxParamVal->iaOID,&uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	
	memset(&xWan_Dsl_Diag, '\0',sizeof(xWan_Dsl_Diag));
	
	xWan_Dsl_Diag.iid.cpeId.Id =uiCpeid;
	uiFlags = IFX_F_GET_ANY;
	
	// Get match object from system using Platform API
	//iRet = ifx_get_wan_dsl_diagnostics(&xWan_Dsl_Diag, uiFlags);	
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
	  iRet = ifx_cpe_api_get_dsl_diagnostics(&xWan_Dsl_Diag, uiFlags);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

#endif	
	//Get the WanIpConParamPos 
        IFX_GetParamIdPos(paxParamVal->iaOID);
		
	
	//Modify on top of old values.
	if(pxOpInfo->iSubOper != OP_SETVAL_ACTIVATE)
	iRet=IFX_ConvertToWanDslDiagStruct(iElements, paxParamVal, &xWan_Dsl_Diag);          
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	switch(pxOpInfo->iSubOper)
		{
			
			case OP_SETVAL_CHK_MODIFY_DEP:
						
				break;
					
			case OP_SETVAL_MODIFY:
				

				//Pass the flags based on f_enable flag
								
				
				//Call the API with Modify flags
				iFlags= (IFX_F_MODIFY|
					IFX_F_DONT_CHECKPOINT|
					IFX_F_DONT_WRITE_TO_FLASH);
					
				xWan_Dsl_Diag.f_enable = IFX_ENABLED;
												
				//Fills the Cpeid,ParentCepid,TR69Id,Owner
				xWan_Dsl_Diag.iid.cpeId.Id=uiCpeid;
				xWan_Dsl_Diag.iid.config_owner=pxOpInfo->iCaller;
				//pxWan_Atm_Diag.scope=
				iOper = IFX_OP_MOD;
				

#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
		ifx_set_wan_dsl_diag_stub(iOper, &xWan_Dsl_Diag, iFlags);

#else

#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
		iRet = ifx_cpe_api_set_dsl_diagnostics(iOper, &xWan_Dsl_Diag, iFlags);
#endif	
#endif


			if(iRet != IFX_SUCCESS)
			{
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					"ifx_cpe_api_set_dsl_diagnostics -Modify Mgmt API returned error\n");
				goto errorHandler;
				
			}	

				 //Check if Diagnostic_state is set to Requested then
				//Change the ret values to NEED_ACTIVATE 
				if(xWan_Dsl_Diag.diagnostic_state ==WAN_DIAG_REQUESTED)
				{
					iRet = IFX_CWMP_NEED_ACTIVATE;
				}

				
				break;

			case OP_SETVAL_ACTIVATE:

				//Check if requested then start the atm_f5_loop_diagnostics
				//Enable the object
				//Call the API
				xWan_Dsl_Diag.diagnostic_state=WAN_DIAG_START_DIAGNOSING;
				xWan_Dsl_Diag.f_enable = IFX_ENABLED;
				xWan_Dsl_Diag.iid.cpeId.Id=uiCpeid;
				xWan_Dsl_Diag.iid.config_owner=ACC_TR69;
				iOper = IFX_OP_MOD;
				iFlags= (IFX_F_MODIFY|
							IFX_F_DONT_CHECKPOINT|
							IFX_F_DONT_WRITE_TO_FLASH);
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
				ifx_set_wan_dsl_diag_stub(iOper, &xWan_Dsl_Diag, iFlags);

#else

#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API	
				iRet = ifx_cpe_api_set_dsl_diagnostics(iOper, &xWan_Dsl_Diag, iFlags);
#endif	
#endif
				if(iRet != IFX_SUCCESS)
				{
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
						"ifx_cpe_api_set_dsl_diagnostics -Modify Mgmt API returned error\n");
				//	goto errorHandler;
					
				}	
					
				//We need to post a msg that diagnosis is complete.
				
				/* Send msg to FIFO */
			    iFIFOFd = IFX_OS_OpenFifo((uchar8 *)IFX_IPC_TR_FIFO, O_RDWR);
			    if(iFIFOFd < 0) {
			        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s:%d Error opening FIFO\n",
			                    __func__, __LINE__);
			        iRet = ERR_CWMP_FIFO_OPEN;
			        goto errorHandler;
			    }

			    if(IFX_IPC_SendMsg(iFIFOFd, (uchar8) IFX_IPC_APP_DIAGNOSTIC, 0, 0, 0, NULL)
			       != IFX_IPC_SUCCESS) {
			        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Error sending msg to "
			                    "FIFO\n", __func__, __LINE__);
			    }
			    IFX_OS_CloseFifo(iFIFOFd);


			default:
				break;
					
		}
	
	return iRet;
	
	errorHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
		return iRet;

}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslDiagSetCommit
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanDslDiagSetCommit()
{
	return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslDiagSetUndo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanDslDiagSetUndo()
{
	return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslDiagSetDelete
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanDslDiagSetDelete(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
							IN int32 iElements, OUT void **ppxParamStructRet,
												   OUT int32 * piNumRetElem)
{
	
		return IFIN_CWMP_SUCCESS;
	
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslDiagSetFree
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanDslDiagSetFree()
{
	return IFX_CWMP_SUCCESS;
}


/* 
** =============================================================================
**   Function Name    : IFX_WanDslDiagSetAttr
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

int32
IFX_WanDslDiagSetAttr(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{
	int32 iRet=IFX_CWMP_SUCCESS,i;
	OperInfo xOpInfo;
	
	xOpInfo.iCaller = pxOpInfo->iCaller;
	xOpInfo.iOper= OP_GETVAL;
	xOpInfo.iSubOper= OP_GETVAL_NORMAL;
	
	iRet = IFX_WanDslDiagGetValue(&xOpInfo,pxParamVal, iElements);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorFreeHandler;
	
	iRet = IFX_SetAttributesInfo(pxOpInfo,pxParamVal, iElements);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorFreeHandler;

	errorFreeHandler:
		for(i=0; i < iElements; i++)
		IFX_CWMP_FREE(pxParamVal[i].Value);
		
                if (iRet)
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
		return iRet;
}




/* 
** =============================================================================
**   Function Name    : IFX_WanDslDiagnostics_Init
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_WanDslDiagnostics_Init(void)
{
	int32 iRet = IFX_CWMP_SUCCESS;
	IFX_ID iid;
 
        memset(&iid,0x00,sizeof(iid));
	strcpy(iid.cpeId.secName,TAG_DSL_DIAG);
    
	/* Register the WanDslLinkConfig module function pointer in the object model */
	iRet = ifx_ds_register_function(IFX_WAN_DSL_DIAG_OBJ, IFX_WanDslDiagnostics);

	/* Check for error */
	if (iRet != IFX_CWMP_SUCCESS)
	{
	    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                "Unable to Register %s with Object Model\n",
	                 IFX_WAN_DSL_DIAG_OBJ);
	    goto errorHandler;
	} else {

#if defined(MIPSTARGET) && defined(CONFIG_PACKAGE_IFX_DSL_CPE_API)
	  ifx_dynamic_object_init(&iid);
#endif

	}

	errorHandler:
			return iRet;
}

/*********************************************************************************
*  Function Name	:  IFX_WanDslDiagnostics
      *  Description	:  This function handles all the sub-states inside
      	 		   a GET/SET operation.If it is a GET it allocates the 
			   array(Name,Value pairs) and retruns the values.
			   If it is a SET controller allocates the array and
			   passes the values to this function.It calls 
			   respective internal functions which in turn calls 
			   respective Platform APIs.
                                                                                                 
*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
							     Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has 
					  	             Name,Value,etc
                    IN          int32	       iElements;    No. of Elements
		    OUT	        void *	       ppParamRet;   same as ParamStruc
		    OUT         int32 *        piNumRetElem; No. of elements 		                                
*  Return Value        : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes               :
***********************************************************************************/
int32
IFX_WanDslDiagnostics(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                IN int32 iElements, OUT void **ppaxParamArrRet, OUT int32 *piNumRetElem)
{
     
   //It calls the respective internal functions which handles resp. sub-operation
   
   //Set-Operation  
   //controller should pass the entire array during all the SET-sub_operations
   //It should handles only single get/set of instance at any point of time
   //It does not handle partial path
   //It won't handle multiple instances of the same object/module
   //at any point of time.

    
    int32 iRet = 0, iCnt = 0;
    ParamVal *paxParamArr = (ParamVal *)paxParameterArr;

	switch (pxOperInfo->iOper) 
	{
		//Get the object values
	   	case OP_GETVAL:
		
	            if((iRet = IFX_WanDslDiagGetValue(pxOperInfo, paxParamArr,
		    							iElements)) != IFX_CWMP_SUCCESS) {
	                
					
			  IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
			  goto errorHandler;
	            }
	            break;
	        case OP_SETVAL:
		{

	    		//Set the obj values
			switch (pxOperInfo->iSubOper) 
			{
		               case OP_SETVAL_VALIDATE:
		                    if((iRet = IFX_WanDslDiagSetValidate(pxOperInfo,paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {     
		                        
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d OP_SET_VALIDATE failed!\n", __func__, __LINE__);
					goto errorHandler;
		                    }
		                 
		                    break;
		                case OP_SETVAL_ADD:
		                    
		                    if((iRet= IFX_WanDslDiagAddObj(pxOperInfo,paxParamArr,
				    					iElements))!=IFX_CWMP_SUCCESS)
		                    	{
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            	"%s:%d OP_SETVAL_ADD failed!\n", __func__, __LINE__);
		                    	 goto errorHandler;
		                    	}
		                    break;
		              case OP_SETVAL_CHK_MODIFY_DEP:
				case OP_SETVAL_MODIFY:
				case OP_SETVAL_ACTIVATE:
		                    if((iRet = IFX_WanDslDiagSetValue(pxOperInfo,paxParamArr,
				    					iElements))!= IFX_CWMP_SUCCESS) 
		    			{									
					  	switch(pxOperInfo->iSubOper)
					  	{
						  	 case OP_SETVAL_CHK_MODIFY_DEP:
							IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_CHK_MODIFY_DEP failed!\n", __func__, __LINE__);
				                        goto errorHandler;
										
							case OP_SETVAL_MODIFY:
							IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_MODIFY failed!\n", __func__, __LINE__);
				                        goto errorHandler;
					  	}
				    	 }
							
		                   
		                    break;
		                case OP_SETVAL_COMMIT:
		                    if((iRet = IFX_WanDslDiagSetCommit(pxOperInfo,paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
				    	   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_COMMIT failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;
		                case OP_SETVAL_UNDO:
		                    if((iRet =IFX_WanDslDiagSetUndo(pxOperInfo, paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
				    	   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_UNDO failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;
				case OP_SETVAL_CHK_DEL_DEP:
				case OP_SETVAL_CHK_DEL_ALLOWED:
		              case OP_SETVAL_DELETE:
		                    if((iRet= IFX_WanDslDiagSetDelete(pxOperInfo, paxParamArr,
				    					iElements, ppaxParamArrRet,
				    					piNumRetElem))!= IFX_CWMP_SUCCESS) {
				    		switch(pxOperInfo->iSubOper)
						{	
					  		case OP_SETVAL_CHK_DEL_DEP:
						    	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
				                        goto errorHandler;
							case OP_SETVAL_CHK_DEL_ALLOWED:
								IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
				                        goto errorHandler;
							case OP_SETVAL_DELETE:
								IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
				                        goto errorHandler;
						}
								
		                    goto errorHandler;
				    }
		                    break;
		                case OP_SETVAL_FREE:
		                    IFX_WanDslDiagSetFree(pxOperInfo);
		                    break;

				 case OP_SETVAL_ATTRINFO:
				 	if((iRet =IFX_WanDslDiagSetAttr(pxOperInfo, paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
				    	  IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            	"%s:%d OP_SETVAL_ATTRINFO failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;	
		                default:
		                    break;
			}
                        break;			
			
	        }
                case OP_UPDATE_CHILDINFO:
                    break;
                case OP_PARAM_VALIDATE:
                {
                    //IGD.WD.2. or IGD.WD.3.
                    if(((paxParamArr->iaOID[2]) == WAN_DEVICE_MII0) || ((paxParamArr->iaOID[2]) == WAN_DEVICE_MII1))
                    {
                        /* Set the fault code to Error */
                        for(iCnt = 0; iCnt < iElements; iCnt++)
                        {
                            paxParamArr[iCnt].iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
                        }
                    }
                    break; 
                }
	        default:
                {
	            break;
                }
	}
	return IFX_CWMP_SUCCESS;

	errorHandler:
		
		return iRet;
			
}
//This helps to synch
 
