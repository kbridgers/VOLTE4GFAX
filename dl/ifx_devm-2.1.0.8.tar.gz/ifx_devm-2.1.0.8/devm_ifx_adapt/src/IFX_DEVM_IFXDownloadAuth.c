/*
** =============================================================================
** FILE NAME   : IFX_DownlaodAuth.c
** PROJECT     : TR69
** MODULES     : (InternetGateway) Device.X_AC9A96_LTQ.DownloadAuth.
** DATE        : 19-Jun-2006
** AUTHOR      : TR69 team
** DESCRIPTION : This object is RO. SetParameterValues or AddObject cannot be
**               performed on this object.
** REFERENCES  :  
** COPYRIGHT   : Copyright (c) 2006
**               Infineon Technologies AG
**               Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY     : 
** $Date        $Author          $Comment
** 30-Aug-2006  TR69 team        Creation         
** =============================================================================
*/
#include "IFX_DEVM_Global.h"
 
#include "IFX_DEVM_AdaptCommon.h"
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"

extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char *obj, modFunc pifx_module_func);

#define IFXDOWNLOADAUTH_OBJ       FORMNAME("X_AC9A96_LTQ.DownloadAuth.")
#define IFXDOWNLOADAUTH_DEPTH     4

/*******************************************************************************
* Function: IFX_DownloadAuthSetAttrInfo
* Desc: 
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: 
*******************************************************************************/
static int32
IFX_DownloadAuthSetAttrInfo(IN int32 iCaller, INOUT ParamVal * pxPV,
                            IN int32 iElements)
{
    int32 iRet = ERR_CWMP_REQUEST_DENIED;
    return iRet;
}

/*******************************************************************************
* Function: IFX_DownloadAuthGetNotifyValue
* Desc: 
* Parameters: IN OperInfo *pxOI, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: 
*******************************************************************************/
static int32
IFX_DownloadAuthGetNotifyValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                               IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    return iRet;
}

/*******************************************************************************
* Function: IFX_DownloadAuthGetValue
* Desc: 
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_DownloadAuthGetValue(IN int32 iCaller, INOUT ParamVal * pxPV,
                         IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    DL_AUTH xDLAuth;
    void *vsTmp = NULL;

    memset(&xDLAuth, 0, sizeof(xDLAuth));
    iRet = ifx_get_dl_auth(&xDLAuth, 0);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] "
                    "ifx_get_dl_auth() failed\n", __func__, __LINE__, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
    for(iI = 0; iI < iElements; iI++) {

        pxPV[iI].Value = IFX_CWMP_MALLOC(PARAMVALUE_LEN + 1);
        if(pxPV[iI].Value == NULL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", __func__, __LINE__);
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (pxPV[iI].iaOID[IFXDOWNLOADAUTH_DEPTH - 1]) {
            case OID_IGD_XAC9A96LTQ_DA_USERNAME:
                vsTmp =
                    IFX_CWMP_REALLOC(pxPV[iI].Value, strlen(xDLAuth.uname) + 1);
                if(vsTmp == NULL) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                                "Malloc failed\n", __func__, __LINE__);
                    iRet = ERR_OUT_OF_MEMORY;
                    goto errorHandler;
                }
                pxPV[iI].Value = vsTmp;
                strcpy(pxPV[iI].Value, xDLAuth.uname);
                break;
            case OID_IGD_XAC9A96LTQ_DA_PASSWORD:
                vsTmp = IFX_CWMP_REALLOC(pxPV[iI].Value,
                                         strlen(xDLAuth.passwd) + 1);
                if(vsTmp == NULL) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                                "Malloc failed\n", __func__, __LINE__);
                    iRet = ERR_OUT_OF_MEMORY;
                    goto errorHandler;
                }
                pxPV[iI].Value = vsTmp;
                strcpy(pxPV[iI].Value, xDLAuth.passwd);
                break;
            case OID_IGD_XAC9A96LTQ_DA_REALM:
                strcpy(pxPV[iI].Value, xDLAuth.realm);
                break;
            case OID_IGD_XAC9A96LTQ_DA_NONCE:
                strcpy(pxPV[iI].Value, xDLAuth.nonce);
                break;
            case OID_IGD_XAC9A96LTQ_DA_URI:
                strcpy(pxPV[iI].Value, xDLAuth.uri);
                break;
            case OID_IGD_XAC9A96LTQ_DA_ALGO:
                strcpy(pxPV[iI].Value, xDLAuth.algo);
                break;
            case OID_IGD_XAC9A96LTQ_DA_CNONCE:
                strcpy(pxPV[iI].Value, xDLAuth.cnonce);
                break;
            case OID_IGD_XAC9A96LTQ_DA_OPAQUE:
                strcpy(pxPV[iI].Value, xDLAuth.opaque);
                break;
            case OID_IGD_XAC9A96LTQ_DA_QOP:
                strcpy(pxPV[iI].Value, xDLAuth.qop);
                break;
            case OID_IGD_XAC9A96LTQ_DA_NC:
                strcpy(pxPV[iI].Value, xDLAuth.nc);
                break;
            case OID_IGD_XAC9A96LTQ_DA_PROCESSCOOKIE:
                sprintf(pxPV[iI].Value, "%d", xDLAuth.process_cookie);
                break;
            case OID_IGD_XAC9A96LTQ_DA_FILETYPE:
                strcpy(pxPV[iI].Value, xDLAuth.file_type);
                break;
            case OID_IGD_XAC9A96LTQ_DA_FILENAME:
                vsTmp = IFX_CWMP_REALLOC(pxPV[iI].Value,
                                         strlen(xDLAuth.file_name) + 1);
                if(vsTmp == NULL) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                                "Malloc failed\n", __func__, __LINE__);
                    iRet = ERR_OUT_OF_MEMORY;
                    goto errorHandler;
                }
                pxPV[iI].Value = vsTmp;
                strcpy(pxPV[iI].Value, xDLAuth.file_name);
                break;
            case OID_IGD_XAC9A96LTQ_DA_COMMANDKEY:
                strcpy(pxPV[iI].Value, xDLAuth.cmd_key);
                break;
            case OID_IGD_XAC9A96LTQ_DA_STATUS:
                sprintf(pxPV[iI].Value, "%d", xDLAuth.status);
                break;
            case OID_IGD_XAC9A96LTQ_DA_STARTTIME:
                IFX_MOD_TimeIntToStr((time_t *) & xDLAuth.abs_start_time,
                                     (char8 *) pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_DA_ENDTIME:
                IFX_MOD_TimeIntToStr((time_t *) & xDLAuth.abs_end_time,
                                     pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_DA_FUTURETIME:
                sprintf(pxPV[iI].Value, "%d", xDLAuth.abs_fut_time);
                break;
            case OID_IGD_XAC9A96LTQ_DA_FILESIZE:
                sprintf(pxPV[iI].Value, "%d", xDLAuth.size);
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                            "Default case\n", __func__, __LINE__,
                            pxPV[iI].iaOID[IFXDOWNLOADAUTH_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_DownloadAuthValidate
* Desc:
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_DownloadAuthValidate(IN int32 iCaller, INOUT ParamVal * pxPV,
                         IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;

    if(iCaller != ACC_ROOT) {
        iRet = ERR_CWMP_INVAL_ARGS;
        pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
    }
    return iRet;
}

/*******************************************************************************
* Function: IFX_DownloadAuthModify
* Desc:
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_DownloadAuthModify(IN int32 iCaller, INOUT ParamVal * pxPV,
                       IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    DL_AUTH xDLAuth;
    time_t tTime = 0;

    memset(&xDLAuth, 0, sizeof(xDLAuth));
    iRet = ifx_get_dl_auth(&xDLAuth, 0);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] "
                    "ifx_get_dl_auth() failed\n", __func__, __LINE__, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[IFXDOWNLOADAUTH_DEPTH - 1]) {
            case OID_IGD_XAC9A96LTQ_DA_USERNAME:
                if(pxPV[iI].Value)
                    strcpy(xDLAuth.uname, pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_DA_PASSWORD:
                if(pxPV[iI].Value)
                    strcpy(xDLAuth.passwd, pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_DA_REALM:
                strcpy(xDLAuth.realm, pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_DA_NONCE:
                strcpy(xDLAuth.nonce, pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_DA_URI:
                strcpy(xDLAuth.uri, pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_DA_ALGO:
                strcpy(xDLAuth.algo, pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_DA_CNONCE:
                strcpy(xDLAuth.cnonce, pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_DA_OPAQUE:
                strcpy(xDLAuth.opaque, pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_DA_QOP:
                strcpy(xDLAuth.qop, pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_DA_NC:
                strcpy(xDLAuth.nc, pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_DA_PROCESSCOOKIE:
                xDLAuth.process_cookie = (char8) atoi(pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_DA_FILETYPE:
                if(pxPV[iI].Value)
                    strcpy(xDLAuth.file_type, pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_DA_FILENAME:
                if(pxPV[iI].Value)
                    strcpy(xDLAuth.file_name, pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_DA_COMMANDKEY:
                if(pxPV[iI].Value)
                    strcpy(xDLAuth.cmd_key, pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_DA_STATUS:
                xDLAuth.status = atoi(pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_DA_STARTTIME:
                iRet = IFX_MOD_TimeStrToInt((char8 *) pxPV[iI].Value, &tTime);
                if(iRet == IFX_CWMP_SUCCESS)
                    xDLAuth.abs_start_time = (uint32) tTime;
                else {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Set "
                                "startime failed\n", __func__, __LINE__, iRet);
                    goto errorHandler;
                }
                break;
            case OID_IGD_XAC9A96LTQ_DA_ENDTIME:
                iRet = IFX_MOD_TimeStrToInt((char8 *) pxPV[iI].Value, &tTime);
                if(iRet == IFX_CWMP_SUCCESS)
                    xDLAuth.abs_end_time = (uint32) tTime;
                else {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Set "
                                "startime failed\n", __func__, __LINE__, iRet);
                    goto errorHandler;
                }
                break;
            case OID_IGD_XAC9A96LTQ_DA_FUTURETIME:
                xDLAuth.abs_fut_time = atoi(pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_DA_FILESIZE:
                xDLAuth.size = atoi(pxPV[iI].Value);
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                            "Default case\n", __func__, __LINE__,
                            pxPV[iI].iaOID[IFXDOWNLOADAUTH_DEPTH - 1]);
                break;
        }
    }

    xDLAuth.iid.config_owner = IFX_TR69;

    iRet = ifx_set_dl_auth(IFX_OP_MOD, &xDLAuth,
                           IFX_F_MODIFY | IFX_F_DONT_WRITE_TO_FLASH |
                           IFX_F_DONT_CHECKPOINT);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] "
                    "ifx_set_dl_auth() failed\n", __func__, __LINE__, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_DownloadAuth
* Desc: 
* Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
*             OUT void **ppRet, OUT int32 * piNumRetElem
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_DownloadAuth(IN OperInfo * pxOI, INOUT void *pParamStruct,
                 IN int32 iElements, OUT void **ppRet, OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;
    uint32 iCnt = 0;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "%s: %s oper=%d maxElement=%d\n",
                __func__, xpParamVal[0].Name, pxOI->iSubOper, iElements);

    switch(pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                    iRet = IFX_DownloadAuthGetValue(pxOI->iCaller, xpParamVal,
                                                    iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_GETVAL_NOTIFICATION:
                    iRet =
                        IFX_DownloadAuthGetNotifyValue(pxOI, xpParamVal,
                                                       iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                    iRet = IFX_DownloadAuthValidate(pxOI->iCaller, xpParamVal,
                                                    iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_SETVAL_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:
                    break;
                case OP_SETVAL_MODIFY:
                    iRet = IFX_DownloadAuthModify(pxOI->iCaller, xpParamVal,
                                                  iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_SETVAL_COMMIT:
                    break;
                case OP_SETVAL_UNDO:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_DELETE:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_ACTIVATE:
                    break;
                case OP_SETVAL_ATTRINFO:
                    IFX_DownloadAuthSetAttrInfo(pxOI->iCaller, pParamStruct,
                                                iElements);
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_UPDATE_CHILDINFO_DEL:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
            }
            break;
        }  
        case OP_PARAM_VALIDATE:
        {
            /*Vendor specific parameters should not be reported to ACS. It 
              should be available for internal updation */
            if(pxOI->iCaller == ACC_TR69)
            {
                /* Set the fault code to Error */
                for(iCnt = 0; iCnt < iElements; iCnt++)
                {
                    xpParamVal[iCnt].iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
                }
            }
            break; 
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                        "Default case\n", __func__, __LINE__, pxOI->iOper);
            break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_DownloadAuthInit
* Desc: Will initialize some of its data structures, register itself with DS
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_DownloadAuthInit()
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* TBD: Perform any DownloadAuthInit related initializations here */

    /* Register the IFX_DownloadAuthInit func ptr in the object model */
    iRet = ifx_ds_register_function(IFXDOWNLOADAUTH_OBJ, IFX_DownloadAuth);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFXDOWNLOADAUTH_OBJ);
        goto errorHandler;
    }

  errorHandler:
    return iRet;
}
