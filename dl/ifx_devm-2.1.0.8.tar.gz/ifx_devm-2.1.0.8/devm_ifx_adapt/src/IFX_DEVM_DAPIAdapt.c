/*
** =============================================================================
** FILE NAME     : IFX_Module.c
** PROJECT       : TR69
** MODULES       : Module
** DATE          : 13-01-2006
** AUTHOR        : TR69 Team
** DESCRIPTION   : 
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date   $Author    $Comment
**
** ============================================================================
*/
#include "IFX_DEVM_Global.h"
#include "IFX_DEVM_DAPIAdapt.h"
#include "IFX_DEVM_DS.h"
#include "IFX_DEVM_DAPI.h"
 
 
 

extern char8 vcOsModId;
extern int32 IFX_DevInfo_Init();
extern int32 IFX_MgmtServer_Init();
extern int32 IFIN_Layer3Forwawrding_Init();
extern int32 IFX_MgmtServer_Init();
extern int32 IFX_LANDeviceInit();
extern int32 IFX_LHCMIPInterfaceInit();
extern int32 IFX_LANEthernetIfCfg_Init();
extern int32 IFX_LANEthernetIfCfgStatsInit();
extern int32 IFX_LANHostCfgMgmtInit();
extern int32 IFX_IPPingDiagInit();
extern int32 IFX_WanDslLinkConfig_Init(void);
extern int32 IFX_WanDevice_Init(void);
extern int32 IFX_WanConnDevice_Init(void);
extern int32 IFX_WanIpConnection_Init(void);
extern int32 IFX_WanIpPortMapping_Init(void);
extern int32 IFX_WanIpConnStats_Init(void);
extern int32 IFX_WanPPPConnection_Init(void);
extern int32 IFX_WanATMF5LoopbackDiagnostics_Init(void);
extern int32 IFX_WanDslDiagnostics_Init(void);
extern int32 IFX_AuthInit();
extern int32 IFX_DownloadAuthInit();
extern int32 IFX_IFXInit();
extern int32 IFX_IGD_Init();
extern int32 IFX_Dmz_Init(void);
extern int32 IFIN_Firewall_Init(void);
extern int32 IFX_DHCPCondServ_Init(void);
extern int32 IFX_DHCPStaticAddr_Init(void);
extern int32 IFX_WanDslTestParams_Init(void);
/*

int
ifx_mod_init()
{
#ifdef STUB_CONTROLLER
    ifx_mod_reg_objs();
    return 0;
#endif

    // All the modules should call their init()'s here 
    IFX_IGD_Init();
    IFX_DevInfo_Init();
    // WAN should be initialized after DeviceInfo but before other 
    IFX_WanDevice_Init();
    IFX_WanConnDevice_Init();
    IFX_WanDslLinkConfig_Init();
    IFX_WanIpConnection_Init();
    IFX_WanPPPConnection_Init();
    IFX_WanATMF5LoopbackDiagnostics_Init();
    IFX_WanDslDiagnostics_Init();
    IFX_WanIpPortMapping_Init();
    IFX_WanIpConnStats_Init();

    IFX_MgmtServer_Init();
    IFIN_Layer3Forwawrding_Init();
    IFX_LHCMIPInterfaceInit();
    IFX_LANEthernetIfCfg_Init();
    IFX_LANEthernetIfCfgStatsInit();
    IFX_LANHostCfgMgmtInit();
    IFX_LANDeviceInit();
    IFX_IPPingDiagInit();
    IFX_AuthInit();
    IFX_DownloadAuthInit();
    IFX_IFXInit();
    return 0;
}

*/
#ifdef STUB_CONTROLLER
int
ifx_mod_reg_objs()
{
    int err = 0;
    if((err = ifx_ds_register_function("InternetGatewayDevice.",
                                       ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err = ifx_ds_register_function("InternetGatewayDevice.DeviceInfo.",
                                       ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err =
        ifx_ds_register_function("InternetGatewayDevice.ManagementServer.",
                                 ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err =
        ifx_ds_register_function("InternetGatewayDevice.Layer3Forwarding.",
                                 ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err =
        ifx_ds_register_function
        ("InternetGatewayDevice.Layer3Forwarding.Forwarding.",
         ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err =
        ifx_ds_register_function("InternetGatewayDevice.LANConfigSecurity.",
                                 ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err =
        ifx_ds_register_function("InternetGatewayDevice.IPPingDiagnostics.",
                                 ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err = ifx_ds_register_function("InternetGatewayDevice.LANDevice.",
                                       ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err =
        ifx_ds_register_function
        ("InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.",
         ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err =
        ifx_ds_register_function
        ("InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.IPInterface.",
         ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err =
        ifx_ds_register_function
        ("InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.DHCPStaticAddress.",
         ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err =
        ifx_ds_register_function
        ("InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.DHCPConditionalServingPool.",
         ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err =
        ifx_ds_register_function
        ("InternetGatewayDevice.LANDevice.1.LANEthernetInterfaceConfig.",
         ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err = ifx_ds_register_function("InternetGatewayDevice.LANDevice.1.LANEthernetInterfaceConfig.1.Stats.", ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
/*    if((err =
        ifx_ds_register_function
        ("InternetGatewayDevice.LANDevice.1.WLANConfiguration.",
         ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err =
        ifx_ds_register_function
        ("InternetGatewayDevice.LANDevice.1.WLANConfiguration.1.AssociatedDevice.",
         ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err =
        ifx_ds_register_function
        ("InternetGatewayDevice.LANDevice.1.WLANConfiguration.1.WEPKey.",
         ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err =
        ifx_ds_register_function
        ("InternetGatewayDevice.LANDevice.1.WLANConfiguration.1.PreSharedKey.",
         ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err =
        ifx_ds_register_function("InternetGatewayDevice.LANDevice.1.Hosts.",
                                 ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err =
        ifx_ds_register_function
        ("InternetGatewayDevice.LANDevice.1.Hosts.Host.",
         ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);*/
    if((err =
        ifx_ds_register_function("InternetGatewayDevice.WANDevice.",
                                 ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
/*    if((err =
        ifx_ds_register_function
        ("InternetGatewayDevice.WANDevice.1.WANCommonInterfaceConfig.",
         ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err = ifx_ds_register_function("InternetGatewayDevice.WANDevice.1.WANCommonInterfaceConfig.Connection.", ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err = ifx_ds_register_function("InternetGatewayDevice.WANDevice.1.WANDSLInterfaceConfig.", ifx_mod_dapi_route)) != 0) 
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err = ifx_ds_register_function("InternetGatewayDevice.WANDevice.1.WANEthernetInterfaceConfig.", ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err = ifx_ds_register_function("InternetGatewayDevice.WANDevice.1.WANEthernetInterfaceConfig.Stats.", ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err =
        ifx_ds_register_function
        ("InternetGatewayDevice.WANDevice.1.WANDSLConnectionManagement.",
         ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err =
        ifx_ds_register_function
        ("InternetGatewayDevice.WANDevice.1.WANDSLConnectionManagement.ConnectionService.",
         ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err = ifx_ds_register_function("InternetGatewayDevice.WANDevice.1.WANDSLDiagnostics.", ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);*/
    if((err =
        ifx_ds_register_function
        ("InternetGatewayDevice.WANDevice.1.WANDSLInterfaceConfig.TestParams.",
         ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err =
        ifx_ds_register_function
        ("InternetGatewayDevice.WANDevice.1.WANConnectionDevice.",
         ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err =
        ifx_ds_register_function
        ("InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANDSLLinkConfig.",
         ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err =
        ifx_ds_register_function
        ("InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANIPConnection.1.",
         ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err =
        ifx_ds_register_function
        ("InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANIPConnection.1.PortMapping.",
         ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err = ifx_ds_register_function("InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANIPConnection.1.Stats.", ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err); 
/*    if((err =
        ifx_ds_register_function
        ("InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.",
         ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);
    if((err = ifx_ds_register_function("InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.1.PortMapping.", ifx_mod_dapi_route)) != 0)
        printf("%s:%d, Err=%d\n", __func__, __LINE__, err);*/
    return 0;
}


int32
ifx_mod_dapi_route(IN OperInfo * ptxOI, INOUT void *pParamStruct,
                   IN int32 iNumElem, OUT void **ppRet,
                   OUT int32 * piNumRetElem)
{
    int ret = 0, i = 0, iJ = 0;
    ParamVal *pv = (ParamVal *) pParamStruct;
    char *queryList[(iNumElem + 1)], sAddObj[CWMP_OBJ_NOLEAF_LEN];
    SetParameterAttributesStruct xSPAS[2];
    ParameterValueStruct pvs[(iNumElem + 1)];


    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s %s oper=%d maxElement=%d\n",
                __func__, pv[0].Name, ptxOI->iOper, iNumElem);
    memset(queryList, '\0', sizeof(queryList));
    memset(&pvs, '\0', sizeof(pvs));
    memset(pvs, '\0', sizeof(pvs));
    memset(&xSPAS, '\0', sizeof(xSPAS));
    memset(sAddObj, '\0', sizeof(sAddObj));

    switch (ptxOI->iOper) {
        case OP_GETVAL:
            switch (ptxOI->iSubOper) {
                case OP_GETVAL_NORMAL:
                    for(i = 0; i < iNumElem; i++) {
                        queryList[i] = pv[i].Name;
                    }
                    ret = ifx_dapi_get_paramvalues(queryList, &pvs);
                    for(i = 0; i < iNumElem; i++) {
                        pv[i].Name = pvs[i].Name;
                        pv[i].Value = pvs[i].Value;
                    }
                    break;
                case OP_GETVAL_PASSIVE_NOTIFY:
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d Reached default case\n", __func__,
                                __LINE__);
                    break;
            }
            break;
        case OP_SETVAL:
            switch (ptxOI->iSubOper) {
                case OP_SETVAL_VALIDATE:
                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:
                    break;
                case OP_SETVAL_MODIFY:
                    for(i = 0; i < iNumElem; i++) {
                        pvs[i].Name = pv[i].Name;
                        pvs[i].Value = pv[i].Value;
                    }
                    ret = ifx_dapi_set_paramvalues(&pvs);
                    break;
                case OP_SETVAL_FREE:
                    break;

                case OP_SETVAL_ADD:
                    for(i = (strlen(pv[0].Name) - 1), iJ = 0; iJ < 2; i--) {
                        if(pv[0].Name[i] == '.')
                            iJ++;
                    }
                    strncpy(sAddObj, pv[0].Name, (i + 2));
                    printf("%s AddObj=%s i = %d\n", __func__, sAddObj, i);
                    ret = ifx_dapi_addobject(sAddObj);
                    break;

                case OP_SETVAL_CHK_DEL_DEP:
                    break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    break;
                case OP_SETVAL_DELETE:
                    ret = ifx_dapi_deleteobject(pv[0].Name);
                    break;

                case OP_SETVAL_ATTRINFO:
                    memcpy(&xSPAS[0], pv[0].Value, sizeof(xSPAS[0]));
                    ret = ifx_dapi_set_paramattributes(&xSPAS);
                    break;

                    /* Following should not get called */
                case OP_SETVAL_COMMIT:
                    break;
                case OP_SETVAL_UNDO:
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d Reached default case\n", __func__,
                                __LINE__);
                    break;
            }
            break;

        case OP_UPDATE_CHILDINFO:
            switch (ptxOI->iSubOper) {
                case OP_UPDATE_CHILDINFO_ADD:
                    break;
                case OP_UPDATE_CHILDINFO_DEL:
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d Reached default case\n", __func__,
                                __LINE__);
                    break;
            }
            break;

        default:
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d, Unknown case %d\n", __func__, __LINE__,
                        ptxOI->iOper);
            break;
    }
    return ret;
}
#endif
