/* 
** =============================================================================
**   FILE NAME        : IFX_Time.c
**   PROJECT          : TR69
**   MODULES          : Time
**   DATE             : 29-05-2007
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This is the Time Module. It is required by the 
**                      controller module of TR69 stack to GET/SET Time
**                      specific information.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author                         $Comment
**   29-05-2007       TR69 team                       Initial Version
**
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_Time.h"
  // Required for STATIC
 
#include "IFX_DEVM_OID.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_DS.h"
#include <sys/time.h>
#include <time.h>

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFX_TIME_OBJ       FORMNAME("Time.")
#define IFX_UTC_TIME_LEN   65
#define IFX_TIME_ZONE_LEN  7

#define KWALALEIN         -720
#define SAMOA             -660
#define HAWAII            -600
#define ALASKA            -540
#define PACIFICTIME       -480
#define MOUNTAINTIME      -420
#define CENTRALTIME       -360
#define EASTERNTIME       -300
#define CARACAS           -270
#define ATLANTICTIME      -240
#define NEWFOUNDLAND      -210
#define BRASILIA          -180
#define MIDATLANTIC       -120
#define AZORES            -60
#define GMT               0
#define BERLIN            +60
#define ISTANBUL          +120
#define MOSCOW            +180
#define TEHRAN            +210
#define ABUDHABI          +240
#define KABUL             +270
#define KARACHI           +300
#define CALCUTTA          +330
#define KATHMANDU         +345
#define DHAKA             +360
#define RANGOON           +390
#define BANGKOK           +420
#define SINGAPORE         +480
#define TOKYO             +540
#define ADELAIDE          +570
#define SYDNEY            +600
#define SOLOMON           +660
#define AUCKLAND          +720
#define NUKUALOFA         +780

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/
STATIC int32
GetCurrentLocalTime(time_t uiTime, char8 *psBuff);
STATIC int32
GetACSLocalTimeZone(int32 iTime, char8 *psBuff);
STATIC int32
GetSystemLocalTimeZone(int32 *piTime, char8 *psBuff);
STATIC int32
ValidateLocalTimeZone(char8 *psBuff);
STATIC int32
GetVal(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
       IN int32 iElements);
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);
/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/


STATIC int32
GetCurrentLocalTime(time_t uiTime, char8 *psBuff)
{
    struct tm xTime;

    localtime_r(&uiTime, &xTime);

    strftime(psBuff, IFX_UTC_TIME_LEN,"%Y-%m-%dT%H:%M:%S", &xTime);
    return IFX_CWMP_SUCCESS;
}

STATIC int32
GetACSLocalTimeZone(int32 iTime, char8 *psBuff)
{
    sprintf(psBuff,"%s%02d:%02d",(iTime>0?"+":"-"), abs(iTime)/60, abs(iTime)%60);
    return IFX_CWMP_SUCCESS;
}

STATIC int32
GetSystemLocalTimeZone(int32 *piTime, char8 *psBuff)
{
    int iHr = 0, iRet = IFX_CWMP_SUCCESS;
    int iMin = 0;
    int iSign = 0;

    psBuff[3]='\0';
    iHr = abs(atoi(psBuff));
    iMin = atoi(psBuff+4);
    iSign = (psBuff[0]=='+'?1:-1);
    *piTime = iSign*((iHr*60)+iMin);
    psBuff[3]=':';

    switch(*piTime)
    {
        case KWALALEIN:      //-720
        case SAMOA:          //-660
        case HAWAII:         //-600
        case ALASKA:         //-540
        case PACIFICTIME:    //-480
        case MOUNTAINTIME:   //-420
        case CENTRALTIME:    //-360
        case EASTERNTIME:    //-300
        case CARACAS:        //-270
        case ATLANTICTIME:   //-240
        case NEWFOUNDLAND:   //-210
        case BRASILIA:       //-180
        case MIDATLANTIC:    //-120
        case AZORES:         //-60
        case GMT:            //0
        case BERLIN:         //+60
        case ISTANBUL:       //+120
        case MOSCOW:         //+180
        case TEHRAN:         //+210
        case ABUDHABI:       //+240
        case KABUL:          //+270
        case KARACHI:        //+300
        case CALCUTTA:       //+330
        case KATHMANDU:      //+345
        case DHAKA:          //+360
        case RANGOON:        //+390
        case BANGKOK:        //+420
        case SINGAPORE:      //+480
        case TOKYO:          //+540
        case ADELAIDE:       //+570
        case SYDNEY:         //+600
        case SOLOMON:        //+660
        case AUCKLAND:       //+720
        case NUKUALOFA:      //+780
            break;
        default:
            iRet = IFX_CWMP_FAILURE;
    }
    return iRet;
}

STATIC int32
ValidateLocalTimeZone(char8 *psBuff)
{
    if ((strlen(psBuff)==6)
        && ((psBuff[0]=='+') || (psBuff[0]=='-'))
        && (isdigit(psBuff[1])) && (isdigit(psBuff[2]))
        && (psBuff[3]==':')
        && (isdigit(psBuff[4])) && (isdigit(psBuff[5])))
    {
        return IFX_CWMP_SUCCESS;
    }
    else
    {
        return IFX_CWMP_FAILURE;
    }
}
/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetVal(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
       IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iRtn = IFX_SUCCESS;
    int32   iCnt = 0;
    NTP_CLIENT_CFG xNTPC;
    int32   iParamOffset = 0;
    char8   sTmpTime[IFX_UTC_TIME_LEN] = { 0 };
    char8   sTmpTimeZone[IFX_TIME_ZONE_LEN] = { 0 };
    char8 status[5][30] = {{"Disabled"},{"Unsynchronized"},{"Synchronized"},{"Error_FailedToSynchronize"},{"Error"}};

    memset(&xNTPC, 0, sizeof(NTP_CLIENT_CFG));

    /* Get all the NTP Client parameters using Protocol API */
    iRtn = ifx_get_ntp_client_cfg(&xNTPC, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get values of all "
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamIdPos(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(MAX_TIME_ZONE_NAME_LEN);

        /* Check for error */
        if (!((pxParamVal[iCnt]).Value))
        {
            iRet = ERR_OUT_OF_MEMORY;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Allocation Failure\n",
                         __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_T_ENABLE:
                sprintf((pxParamVal[iCnt]).Value, "%d" ,xNTPC.f_enable);
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break; 
            case OID_IGD_T_STATUS:
                sprintf((pxParamVal[iCnt]).Value, "%s" ,status[xNTPC.status] );
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break; 
            case OID_IGD_T_NTPSERVER1:

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xNTPC.ntpServer1); 
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;  
            case OID_IGD_T_NTPSERVER2:  

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xNTPC.ntpServer2); 
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;  
            case OID_IGD_T_NTPSERVER3:

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xNTPC.ntpServer3);
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;
            case OID_IGD_T_NTPSERVER4:

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xNTPC.ntpServer4);
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;
            case OID_IGD_T_NTPSERVER5:

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xNTPC.ntpServer5);
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;  
            case OID_IGD_T_CURRENTLOCALTIME:  

                /* Get the time in format required by ACS */
                GetCurrentLocalTime((time_t)(xNTPC.currentLocalTime), sTmpTime);

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, sTmpTime); 

                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_VALUE_BASED);
                break;  
            case OID_IGD_T_LOCALTIMEZONE:  

                /* Get the time in format required by ACS */
                GetACSLocalTimeZone(xNTPC.timeMinutesOffset, sTmpTimeZone);

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, sTmpTimeZone); 

                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;  
#ifndef DEVICE_SUPPORT
            case OID_IGD_T_LOCALTIMEZONENAME:  

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xNTPC.tzName); 
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;  
            case OID_IGD_T_DAYLIGHTSAVINGSUSED:
                /* Hardcoding it to 0 i.e false */
                sprintf((pxParamVal[iCnt]).Value, "%d", 0); 
                break;  
            case OID_IGD_T_DAYLIGHTSAVINGSSTART:
                strcpy((pxParamVal[iCnt]).Value, "0001-01-01T00:00:00");
                break;  
            case OID_IGD_T_DAYLIGHTSAVINGSEND:
                strcpy((pxParamVal[iCnt]).Value, "0001-01-01T00:00:00");
                break;  
#endif
            default:
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
                goto cleanup;
        }
    }

cleanup:
    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : Modify
**
**   Description      : This function modifies the values of parameters in 
**                      Time object. It calls respective Management API  
**                      for the same. It performs modification only if parameter 
**                      has Write permission.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet         = IFX_CWMP_SUCCESS;
    int32   iRtn         = IFX_SUCCESS;
    int32   iCnt         = 0;
    NTP_CLIENT_CFG xNTPC;
    int32   iParamOffset = 0;

    memset(&xNTPC, 0, sizeof(NTP_CLIENT_CFG));

    /* Get all the NTP Client parameters using Object API */
    iRtn = ifx_get_ntp_client_cfg(&xNTPC, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_CWMP_SUCCESS)
    {

       iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get values of all "
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamIdPos(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_T_ENABLE:
                xNTPC.f_enable = atoi((pxParamVal[iCnt]).Value);
                break;            
            case OID_IGD_T_NTPSERVER1:

                /* Check if the string fits in the buffer */
                if ((strlen((pxParamVal[iCnt]).Value) + 1) > MAX_NTP_SERVER_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }

                /* Copy the string */
                strcpy(xNTPC.ntpServer1,(pxParamVal[iCnt]).Value);
                break;
            case OID_IGD_T_NTPSERVER2:

                /* Check if the string fits in the buffer */
                if ((strlen((pxParamVal[iCnt]).Value) + 1) > MAX_NTP_SERVER_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }

                /* Copy the string */
                strcpy(xNTPC.ntpServer2,(pxParamVal[iCnt]).Value);
                break;
            case OID_IGD_T_NTPSERVER3:

                /* Check if the string fits in the buffer */
                if ((strlen((pxParamVal[iCnt]).Value) + 1) > MAX_NTP_SERVER_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }

                /* Copy the string */
                strcpy(xNTPC.ntpServer3,(pxParamVal[iCnt]).Value);
                break;
            case OID_IGD_T_NTPSERVER4:

                /* Check if the string fits in the buffer */
                if ((strlen((pxParamVal[iCnt]).Value) + 1) > MAX_NTP_SERVER_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }

                /* Copy the string */
                strcpy(xNTPC.ntpServer4,(pxParamVal[iCnt]).Value);
                break;
            case OID_IGD_T_NTPSERVER5:

                /* Check if the string fits in the buffer */
                if ((strlen((pxParamVal[iCnt]).Value) + 1) > MAX_NTP_SERVER_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }

                /* Copy the string */
                strcpy(xNTPC.ntpServer5,(pxParamVal[iCnt]).Value);
                break;
            case OID_IGD_T_LOCALTIMEZONE:

                /* Get the time in system format */
                if(GetSystemLocalTimeZone(&(xNTPC.timeMinutesOffset),
                                       (pxParamVal[iCnt]).Value) != IFX_CWMP_SUCCESS) {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    iRet = ERR_CWMP_INVAL_ARGS;
                }
                break;
#ifndef DEVICE_SUPPORT
            case OID_IGD_T_LOCALTIMEZONENAME:
                /* Check if the string fits in the buffer */
                if ((strlen((pxParamVal[iCnt]).Value) + 1) > MAX_TIME_ZONE_NAME_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }

                /* Copy the string */
                strcpy(xNTPC.tzName,(pxParamVal[iCnt]).Value);
                break;
            case OID_IGD_T_DAYLIGHTSAVINGSUSED:
            case OID_IGD_T_DAYLIGHTSAVINGSSTART:
            case OID_IGD_T_DAYLIGHTSAVINGSEND:
            case OID_IGD_T_STATUS:
                (pxParamVal[iCnt]).iFaultCode = ERR_NON_WRITABLE;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Write not supported"
                            ,__FILE__, __func__, __LINE__, iRet);
                goto cleanup;
#endif


            case OID_IGD_T_CURRENTLOCALTIME:
                (pxParamVal[iCnt]).iFaultCode = ERR_NON_WRITABLE;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Cannot modify the parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

    /* Enable the NTP Client object if it is already disabled */
    xNTPC.f_enable = 1;

    /* Fill the iid structure in NTP_CLIENT_CFG */
    xNTPC.iid.config_owner = IFX_TR69;

    /* Set all the DEVICE_INFO parameters using Object API */
    iRtn = ifx_set_ntp_client_cfg(IFX_OP_MOD, &xNTPC, IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to set values of all "
                    "parameters\n", __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : Validate
**
**   Description      : This function validates the values of parameters in
**                      Time object.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      validated.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When validation of all parameters is
**                      successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in validating at least one parameter.
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iCnt;
    int32   iParamOffset;
    char8   *psTmpVal = NULL;

   /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamIdPos(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }
 /* Iterate and validate the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Return a failure if the value is NULL pointer */
        if (!psTmpVal)
        {
            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
            iRet = ERR_CWMP_INVAL_ARGS;
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_T_NTPSERVER1:
            case OID_IGD_T_NTPSERVER2:
            case OID_IGD_T_NTPSERVER3:
            case OID_IGD_T_NTPSERVER4:
            case OID_IGD_T_NTPSERVER5:
#ifndef DEVICE_SUPPORT
            case OID_IGD_T_LOCALTIMEZONENAME:
            case OID_IGD_T_DAYLIGHTSAVINGSUSED:
            case OID_IGD_T_DAYLIGHTSAVINGSSTART:
            case OID_IGD_T_DAYLIGHTSAVINGSEND:
            case OID_IGD_T_ENABLE:
#endif
                /* No specific validation required */
                break;
            case OID_IGD_T_LOCALTIMEZONE:
                iRet = ValidateLocalTimeZone(psTmpVal);

                /* Check for error */
                if(iRet != IFX_CWMP_SUCCESS)
                {
                    (pxParamVal[iCnt]).iFaultCode = iRet;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto cleanup;
                }

                break;

            case OID_IGD_T_CURRENTLOCALTIME:
                /* RO params - Not validating. just returtning success */
                break;
           case OID_IGD_T_STATUS:
               (pxParamVal[iCnt]).iFaultCode = ERR_NON_WRITABLE;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Parameter is Not Writable\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;  
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

cleanup:
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Validating requested parameter failed\n",
                    __FILE__, __func__, __LINE__, iRet);
    }
    return (iRet);
}


STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32   iRtn = IFX_SUCCESS;
    int32 iCnt;
    NTP_CLIENT_CFG xNTPC;
    int32 iParamOffset;
    int32 iValueFlag = 0; /* Mandatory */
    char8   sTmpTime[IFX_UTC_TIME_LEN] = { 0 };

    memset(&xNTPC, 0, sizeof(NTP_CLIENT_CFG));

    /* Get all the NTP CLIENT parameters using Protocol API */
    iRtn = ifx_get_ntp_client_cfg(&xNTPC, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get values of all "
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamIdPos(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Set the fault code to Success and value to NULL pointer for all parameters
       other than uptime */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        if (((pxParamVal[iCnt]).iaOID[iParamOffset]) == OID_IGD_T_CURRENTLOCALTIME)
        {

            /* Get the time in string format */
            sprintf(sTmpTime,"%u",xNTPC.currentLocalTime);
            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(strlen(sTmpTime) + 1);

            /* Check for error */
            if (!((pxParamVal[iCnt]).Value))
            {
                (pxParamVal[iCnt]).iFaultCode = ERR_OUT_OF_MEMORY;
                iRet = ERR_OUT_OF_MEMORY;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Allocation Failure\n",
                             __FILE__, __func__, __LINE__, iRet);
                    goto cleanup;
            }

            /* Copy the value to allocated area */
            strcpy((pxParamVal[iCnt]).Value, sTmpTime); 
        }
        else
        {
            (pxParamVal[iCnt]).Value = NULL;
        }
    }

    /* Mark that values have been malloced */
    iValueFlag = 1;

    /* Update Attribute Information */
    iRet = IFX_SetAttributesInfo(NULL, pxParamVal, iElements);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Updating Param Attribute Info failed\n",
                    __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    /* Free the Value that has been allocated */
    if (iValueFlag)
    { 
        for (iCnt = 0; iCnt < iElements; iCnt++)
        {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
        }
    }

    return (iRet);
}

/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : IFX_Time_Init
**
**   Description      : This function is called by the controller. It registers
**                      the function responsible for handling Time object
**                      with data structure. It also performs initializations
**                      specific to Time object.
**
**   Parameters       : No Parameters. 
**
**   Return Value     : IFX_CWMP_SUCCESS - When DeviceInfo object is initialized
**                      successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in initializing DeviceInfo object.
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_Time_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the Time module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_TIME_OBJ, IFX_Time);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_TIME_OBJ);
        goto cleanup;
    }

cleanup:
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_Time
**
**   Description      : This function is called by the controller. It handles
**                      the Time object and performs  based on requested
**                      operations/suboperations by invoking internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_Time(IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
             OUT void **ppRet, OUT int32 *piNumRetElem)
{
    int32       iRet           = IFX_CWMP_SUCCESS;
    ParamVal    *pxParamVal    = (ParamVal *)pParamList;

    /* Process based on type of Operation */
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:

                    /* Get values of all the requested parameters */
                    iRet = GetVal(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_SETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:

                    /* Validate values of all the requested parameters */
                    iRet = Validate(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:

                    /* Check modify dependency of all requested parameters */
                    iRet = IFX_CWMP_SUCCESS;
                    break;
                case OP_SETVAL_MODIFY:

                    /* Set values of all the requested parameters */
                    iRet = Modify(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ATTRINFO:

                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_FREE:
                case OP_SETVAL_ADD:
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
                case OP_SETVAL_DELETE:
                break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_UPDATE_CHILDINFO:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD: 
                case OP_UPDATE_CHILDINFO_DEL: 
                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid Operation\n",
                         __func__, __LINE__, iRet);
            goto cleanup;
    }

cleanup:
    return (iRet);
}
