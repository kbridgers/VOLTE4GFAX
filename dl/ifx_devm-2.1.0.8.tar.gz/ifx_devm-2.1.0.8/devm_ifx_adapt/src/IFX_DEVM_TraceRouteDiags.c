
/*
** =============================================================================
** FILE NAME   : IFX_DEVM_TraceRouteDiags.c
** PROJECT     : TR69
** MODULES     : (InternetGateway) Device.TraceRouteDiagnostics.
** DATE        :
** AUTHOR      : TR69 team
** DESCRIPTION : AddObject / DeleteObject cannot be performed on this object.
**
** REFERENCES  :
** COPYRIGHT   : Copyright (c) 2006
**               Infineon Technologies AG
**               Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY     :
** $Date       $Author        $Comment
**             TR69 team      Creation
** =============================================================================
*/

#include "IFX_DEVM_Global.h"

#include "IFX_DEVM_AdaptCommon.h"


#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_StackUtil.h"
#include <resolv.h>
#include <pthread.h>


extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char *obj, modFunc pifx_module_func);
extern int32 IFX_ContAddObj(IN int32 iCaller, IN char8 *psObj);
extern int32 IFX_ContDelObj(IN int32 iCaller, IN char8 * psObj, IN int32 iSession);

#ifndef DEVICE_SUPPORT
#define TRACEROUTEDIAG_OBJ                      FORMNAME("TraceRouteDiagnostics.")
#define ROUTEHOPS_OBJ                           FORMNAME("TraceRouteDiagnostics.RouteHops.")
#define TRACEROUTEDIAG_DEPTH                    3
#else
#define TRACEROUTEDIAG_OBJ                      FORMNAME("LAN.TraceRouteDiagnostics.")
#define ROUTEHOPS_OBJ				FORMNAME("LAN.TraceRouteDiagnostics.RouteHops.")
#define TRACEROUTEDIAG_DEPTH                    4
#endif // DEVICE_SUPPORT

#define MAX_NUM_LEN          12
#define LINESIZE             256

#ifdef DEVICE_SUPPORT
        #define OID_IGD_TRD_DIAGNOSTICSSTATE    OID_IGD_LAN_TRD_DIAGNOSTICSSTATE
        #define OID_IGD_TRD_HOST        OID_IGD_LAN_TRD_HOST
        #define OID_IGD_TRD_TIMEOUT     OID_IGD_LAN_TRD_TIMEOUT
        #define OID_IGD_TRD_DATABLOCKSIZE       OID_IGD_LAN_TRD_DATABLOCKSIZE
        #define OID_IGD_TRD_MAXHOPCOUNT OID_IGD_LAN_TRD_MAXHOPCOUNT
        #define OID_IGD_TRD_DSCP        OID_IGD_LAN_TRD_DSCP
        #define OID_IGD_TRD_RESPONSETIME        OID_IGD_LAN_TRD_RESPONSETIME
        #define OID_IGD_TRD_ROUTEHOPSNUMBEROFENTRIES    OID_IGD_LAN_TRD_NUMBEROFROUTEHOPS
        #define OID_IGD_TRD_RH_HOPHOST  OID_IGD_LAN_TRD_RH_HOPHOST
#endif // DEVICE_SUPPORT
	

typedef struct {
	char8 caDiagState[MAX_DIAGSTATE_LEN];
	int32 iResponseTime;
	int32 iRouteHopsNumberOfEntries;
	ROUTE_HOPS *pxRouteHops;
} TraceRouteResp;

pthread_mutex_t msg_mutex = PTHREAD_MUTEX_INITIALIZER;

/*******************************************************************************
* Function: IFX_TraceRouteDiagSetAttrInfo
* Desc: Sets attribute information in the respective tr69 sections
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_TraceRouteDiagSetAttrInfo(IN int32 iCaller, INOUT ParamVal * pxPV,
                              IN int32 iElements)
{
	int32 iRet = IFX_CWMP_SUCCESS;
	iRet = IFX_SetAttributesInfo(NULL, pxPV, iElements);

	if (iRet != IFX_CWMP_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		            "%s:%d [%d] Updating Param Attribute Info failed\n",
		            _FUNCL_, iRet);
		goto errorHandler;
	}
errorHandler:
	return iRet;
}

/*******************************************************************************
* Function: IFX_TraceRouteDiagGetNotifyValue
* Desc: gets valure from the config file and returns
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_TraceRouteDiagGetNotifyValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                                 IN int32 iElements)
{
	int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
	TRACEROUTE_DIAG xTraceroute;
	char8 caTmp[64] = { 0 };

	memset(&xTraceroute, '\0', sizeof(xTraceroute));
	iRet = ifx_get_traceroute_diag(&xTraceroute);
IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d]max_hop_count = %d\n", _FUNCL_, xTraceroute.max_hop_count);

	if (iRet != IFX_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		            "%s:%d [%d] ifx_get_Traceroute_diag() failed\n", _FUNCL_, iRet);
		iRet = ERR_CWMP_INTERNAL;
		goto errorHandler;
	}
//IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d]max_hop_count = %d\n", _FUNCL_, xTraceroute.max_hop_count);
	for (iI = 0; iI < iElements; iI++) {
		pxPV[iI].Value = IFX_CWMP_MALLOC(257);
		if (pxPV[iI].Value == NULL) {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
			            "Malloc failed\n", _FUNCL_);
			iRet = ERR_OUT_OF_MEMORY;
			goto errorHandler;
		}

		switch (pxPV[iI].iaOID[TRACEROUTEDIAG_DEPTH - 1]) {
		case OID_IGD_TRD_DIAGNOSTICSSTATE:
			strcpy(pxPV[iI].Value, xTraceroute.diag_state);
			break;
#ifndef DEVICE_SUPPORT
		case OID_IGD_TRD_INTERFACE:
			strcpy(pxPV[iI].Value, xTraceroute.interface);
			break;
#endif // DEVICE_SUPPORT
		case OID_IGD_TRD_HOST:
			strcpy(pxPV[iI].Value, xTraceroute.host);
			break;
#ifndef DEVICE_SUPPORT
		case OID_IGD_TRD_NUMBEROFTRIES:
			sprintf(caTmp, "%d", xTraceroute.num_tries);
			strcpy(pxPV[iI].Value, caTmp);
			break;
#endif // DEVICE_SUPPORT
		case OID_IGD_TRD_TIMEOUT:
			sprintf(caTmp, "%d", xTraceroute.timeout);
			strcpy(pxPV[iI].Value, caTmp);
			break;
		case OID_IGD_TRD_DATABLOCKSIZE:
			sprintf(caTmp, "%d", xTraceroute.data_size);
			strcpy(pxPV[iI].Value, caTmp);
			break;
		case OID_IGD_TRD_DSCP:
			sprintf(caTmp, "%d", xTraceroute.dscp);
			strcpy(pxPV[iI].Value, caTmp);
			break;
		case OID_IGD_TRD_MAXHOPCOUNT:
			sprintf(caTmp, "%d", xTraceroute.max_hop_count);
			strcpy(pxPV[iI].Value, caTmp);
			break;
		case OID_IGD_TRD_RESPONSETIME:
			sprintf(caTmp, "%d", xTraceroute.resp_time);
			strcpy(pxPV[iI].Value, caTmp);
			IFX_CheckValueGotChanged(pxOI, pxPV + iI,
			                         IFX_CHK_CHANGE_FLAG_BASED);
			break;
		case OID_IGD_TRD_ROUTEHOPSNUMBEROFENTRIES:
			sprintf(caTmp, "%d", xTraceroute.root_hop_num_entries);
			strcpy(pxPV[iI].Value, caTmp);
			IFX_CheckValueGotChanged(pxOI, pxPV + iI,
			                         IFX_CHK_CHANGE_FLAG_BASED);
			break;
		default:
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			            "%s:%d [%d] Error! Default case\n", _FUNCL_,
			            pxPV[iI].iaOID[TRACEROUTEDIAG_DEPTH - 1]);
			break;
		}
	}
errorHandler:
	return iRet;
}

/*******************************************************************************
* Function: IFX_TraceRouteValidateInterface
* Desc: Validates the psInterface parameter passed. Is Successful, psIPAddr
*       will contain the IPAddress of the interface (Depending on being a
*       WANDevice or LANDevice). psIPAddr should be allocated by the caller of
*       this function.
* Parameters: IN char8 * psInterface, OUT char8 * psIPAddr
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_TraceRouteValidateInterface(IN char8 * psInterface, OUT char8 * psIPAddr)
{
	int32 iRet = IFX_CWMP_SUCCESS;


/*	if(psInterface == NULL)
	{
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d NULL interface name\n", _FUNCL_);
		goto errorHandler;
	}

	if (strstr(psInterface, "WANDevice"))
	{
	}
	else if (strstr(psInterface, "LANDevice"))
	{
	}
	else
	{
		iRet = IFX_CWMP_FAILURE;
		goto errorHandler;
	}

errorHandler:*/
	return iRet;
}

/*******************************************************************************
* Function: IFX_TraceRouteDiagValidate
* Desc:
*
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_TraceRouteDiagValidate(INOUT ParamVal * pxPV, IN int32 iElements)
{
	int32 iRet = IFX_CWMP_SUCCESS, iI = 0, iTmp = 0;
#ifndef DEVICE_SUPPORT
	char8 sIPAddr[64] = { 0 };
#endif

	for (iI = 0; iI < iElements; iI++)
	{
		switch (pxPV[iI].iaOID[TRACEROUTEDIAG_DEPTH- 1])
		{
#ifndef DEVICE_SUPPORT
		case OID_IGD_TRD_INTERFACE:
                       
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"Entered case OID_IGD_TRD_INTERFACE:\n");

			iTmp = strlen(pxPV[iI].Value);
			if (iTmp > MAX_IF_NAME) {
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
				            "%s:%d Interface len %d > %d (max)\n", _FUNCL_,
				            iTmp, MAX_IF_NAME);
				iRet = ERR_CWMP_INVAL_PARAM_VAL;
				goto errorHandler;
			}
			if (iTmp == 0) {
				/* A NULL interface value is a valid value, use the routing
				   table */
			}
			else
			{       
                                
				iRet = IFX_TraceRouteValidateInterface(pxPV[iI].Value, sIPAddr);
				if (iRet != IFX_CWMP_SUCCESS)
				{

					iRet = ERR_CWMP_INVAL_ARGS;
					pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
				        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"IFX_TraceRouteValidateInterface FAILED\n");
                                	goto errorHandler;
				}
			}
			break;
#endif

		case OID_IGD_TRD_HOST:

                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"Entered case OID_IGD_TRD_HOST:\n");

			iTmp = strlen(pxPV[iI].Value);
			if ((iTmp > MAX_HOST_NAME) || (iTmp < 3))
			{
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
				            "%s:%d Host len: %d \n", _FUNCL_, iTmp);
				iRet = ERR_CWMP_INVAL_ARGS;
				pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
				goto errorHandler;
			}
			break;
		default:
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			            "%s:%d [%d] Error! Default case\n", _FUNCL_,
			            pxPV[iI].iaOID[TRACEROUTEDIAG_DEPTH - 1]);
			goto errorHandler;
		}
	}
errorHandler:
	return iRet;
}

/*******************************************************************************
* Function: IFX_TraceRouteDiagSetValue
* Desc:
*
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_TraceRouteDiagSetValue(INOUT ParamVal * pxPV, IN int32 iElements)
{
	int32 iRet = IFX_CWMP_SUCCESS, iI = 0, iActivate = 0;
	TRACEROUTE_DIAG xTraceroute;
#ifndef DEVICE_SUPPORT
	ParamVal xGetParam;
	ParamVal *paxGetParamVal = NULL;
	char8 caInterface[CWMP_MAX_OBJ_LEN] = { 0 };
	char sIfName[150]={0};
	uint32 iElemOut;
        int32 wan_type = 0;
#endif

	memset(&xTraceroute, '\0', sizeof(xTraceroute));
	iRet = ifx_get_traceroute_diag(&xTraceroute);
	if (iRet != IFX_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		            "%s:%d [%d] ifx_get_traceroute_diag() failed\n", _FUNCL_, iRet);
		iRet = ERR_CWMP_INTERNAL;
		goto errorHandler;
	}
IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d]max_hop_count = %d\n", _FUNCL_, xTraceroute.max_hop_count);

	for (iI = 0; iI < iElements; iI++) {
		switch (pxPV[iI].iaOID[TRACEROUTEDIAG_DEPTH - 1]) {

		case OID_IGD_TRD_DIAGNOSTICSSTATE:
			strncpy(xTraceroute.diag_state, pxPV[iI].Value, MAX_DIAGSTATE_LEN);
			if (strcmp(pxPV[iI].Value, "Requested") == 0)
				iActivate = IFX_CWMP_NEED_ACTIVATE;
			break;
#ifndef DEVICE_SUPPORT
		case OID_IGD_TRD_INTERFACE:
#if 0
			strncpy(xTraceroute.interface, pxPV[iI].Value, MAX_IF_NAME);
#else
			if (!strcmp(pxPV[iI].Value,"")) {
				xTraceroute.interface[0] = '\0';
			} else if (!strcmp(pxPV[iI].Value, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.IPInterface.1")) {
				strcpy(xTraceroute.interface, "br0");
			} else {
				memset(&xGetParam, 0x00, sizeof(xGetParam));
				xGetParam.Name = IFX_CWMP_MALLOC(strlen(pxPV[iI].Value)+8);
				if (xGetParam.Name == NULL) {
					iRet = IFX_CWMP_FAILURE;
					goto errorHandler;
				}

				memset(caInterface, 0, sizeof(caInterface));
				strcpy(caInterface, pxPV[iI].Value);
				if (caInterface[strlen(caInterface) -1] != '.')
				{
					strcat(caInterface, ".");
				}

				sprintf(xGetParam.Name, "%s%s", (char *)caInterface, "Name");

				iRet = IFX_GlobalGetVal( &xGetParam, &paxGetParamVal, (uint32 *)&iElemOut);
				if (iRet != IFX_CWMP_SUCCESS)
				{
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d]  IFX_GlobalGetVal failed\n", __func__ , __LINE__);
					IFX_CWMP_FREE(xGetParam.Name);
					if (paxGetParamVal != NULL)
					{
						IFX_CWMP_FREE(paxGetParamVal->Value);
						IFX_CWMP_FREE(paxGetParamVal->Name);
					}
					IFX_CWMP_FREE(paxGetParamVal);
					pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
					goto errorHandler;
				}
                                if(strstr(paxGetParamVal->Value,"WANPPP") != NULL)
                                {
                                    wan_type = WAN_TYPE_PPP;
                                } 
                                else
                                {
                                    wan_type = WAN_TYPE_IP;
                                } 
				iRet = ifx_get_wan_ifname_from_connName(paxGetParamVal->Value, sIfName, wan_type);
				if (iRet != IFX_CWMP_SUCCESS) {
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d]  ifx_get_wan_ifname_from_conf_connName failed. Connname: %s\n", __func__ , __LINE__, paxGetParamVal->Value);
					IFX_CWMP_FREE(xGetParam.Name);
					IFX_CWMP_FREE(paxGetParamVal->Value);
					IFX_CWMP_FREE(paxGetParamVal->Name);
					IFX_CWMP_FREE(paxGetParamVal);
					iRet = ERR_CWMP_INTERNAL;
					pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
					goto errorHandler;
				}
				strncpy(xTraceroute.interface, sIfName, 15);

				IFX_CWMP_FREE(xGetParam.Name);
				IFX_CWMP_FREE(paxGetParamVal->Value);
				IFX_CWMP_FREE(paxGetParamVal->Name);;
				IFX_CWMP_FREE(paxGetParamVal);
			}
#endif
			break;
#endif // DEVICE_SUPPORT
		case OID_IGD_TRD_HOST:
			strncpy(xTraceroute.host, pxPV[iI].Value, MAX_HOST_NAME);
			break;
#ifndef DEVICE_SUPPORT
		case OID_IGD_TRD_NUMBEROFTRIES:
			xTraceroute.num_tries = atoi(pxPV[iI].Value);
			break;
#endif
		case OID_IGD_TRD_TIMEOUT:
			xTraceroute.timeout = atoi(pxPV[iI].Value);
			if(xTraceroute.timeout<2000)
			{
			    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                       		"%s:%d [%d] Invalid timeout value\n", _FUNCL_, iRet);
			    iRet = ERR_CWMP_INVAL_ARGS;
		            goto errorHandler;
			}
			break;
		case OID_IGD_TRD_DATABLOCKSIZE:
			xTraceroute.data_size = atoi(pxPV[iI].Value);
			break;
		case OID_IGD_TRD_DSCP:
			xTraceroute.dscp = atoi(pxPV[iI].Value);
			break;
		case OID_IGD_TRD_MAXHOPCOUNT:
			xTraceroute.max_hop_count = atoi(pxPV[iI].Value);
			break;
		case OID_IGD_TRD_RESPONSETIME:
		case OID_IGD_TRD_ROUTEHOPSNUMBEROFENTRIES:
                	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d] [Error] Non-Writable parameter %d!\n",
									_FUNCL_, pxPV[iI].iaOID[TRACEROUTEDIAG_DEPTH - 1]);
                	iRet = ERR_NON_WRITABLE;
			pxPV[iI].iFaultCode = ERR_NON_WRITABLE_PARAM;
			goto errorHandler;
		default:
                	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d] [Error] Unknown requested parameter %d!\n",
                        						 _FUNCL_, pxPV[iI].iaOID[TRACEROUTEDIAG_DEPTH - 1]);
                	iRet = ERR_CWMP_INVAL_PARAM_NAME;
			pxPV[iI].iFaultCode=ERR_INVAL_PARAMETER_NAME;
			goto errorHandler;
		}
	}

	/* Modifying any of the parameters in this obj except DiagnosticState MUST
	   result in the value of DiagnosticState parameter being set to "None" */
	if (iActivate != IFX_CWMP_NEED_ACTIVATE)
		strcpy(xTraceroute.diag_state, "None");

IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d]max_hop_count = %d\n", _FUNCL_, xTraceroute.max_hop_count);
	iRet = ifx_set_traceroute_diag(&xTraceroute, IFX_F_MODIFY);
	if (iRet != IFX_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		            "%s:%d [%d] ifx_set_traceroute_diag() failed\n", _FUNCL_, iRet);
		iRet = ERR_CWMP_INTERNAL;
		goto errorHandler;
	}

errorHandler:
	if ((iActivate == IFX_CWMP_NEED_ACTIVATE) && (iRet == IFX_CWMP_SUCCESS))
		iRet = IFX_CWMP_NEED_ACTIVATE;

	return iRet;
}

#if 0 // TODO
/* 
** =============================================================================
**   Function Name    : IFX_RouteHopsAddObj 
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_RouteHopsAddObj(IN OperInfo * pxOpInfo, INOUT ParamVal *pxParamVal,IN int32 iNumElem)
{
// FIXME: pxParamVal.iaOID[3] --> cpeId
	return IFX_SUCCESS;
}
#endif

/*******************************************************************************
* Function: IFX_RouteHopsGetValue
* Desc:
*
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_RouteHopsGetValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                      IN int32 iElements)
{
	int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
	ROUTE_HOPS xRoutehop;
	uint32 uiCpeid, uiPcpeid;
	uint32 uiParamPos=0;

	memset(&xRoutehop, '\0', sizeof(xRoutehop));
	
	iRet = IFX_GetCpeId(pxPV->iaOID, &uiCpeid);
	if (iRet != IFX_CWMP_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		            "%s:%d [%d] IFX_GetCpeId() failed\n", _FUNCL_, iRet);
		goto errorHandler;
	}

	iRet = IFX_GetParentObjCpeId(pxPV->iaOID, &uiPcpeid);
	if (iRet != IFX_CWMP_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		            "%s:%d [%d] IFX_GetParentObjCpeId() failed\n", _FUNCL_, iRet);
		goto errorHandler;
	}

	xRoutehop.iid.cpeId.Id = uiCpeid;
	xRoutehop.iid.config_owner = pxOI->iCaller;
	xRoutehop.iid.pcpeId.Id = uiPcpeid;

	iRet = ifx_get_routehops(&xRoutehop);

	if (iRet != IFX_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		            "%s:%d [%d] ifx_get_routehops() failed\n", _FUNCL_, iRet);
		iRet = ERR_CWMP_INTERNAL;
		goto errorHandler;
	}

	uiParamPos = IFX_GetParamIdPos(pxPV->iaOID);

	for (iI = 0; iI < iElements; iI++) {
		pxPV[iI].Value = IFX_CWMP_MALLOC(257);
		if (pxPV[iI].Value == NULL) {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
			            "Malloc failed\n", _FUNCL_);
			iRet = ERR_OUT_OF_MEMORY;
			goto errorHandler;
		}

		switch (pxPV[iI].iaOID[uiParamPos]) {
		case OID_IGD_TRD_RH_HOPHOST:
			strncpy(pxPV[iI].Value, xRoutehop.hophost, MAX_HOST_NAME);
			break;
#ifndef DEVICE_SUPPORT
		case OID_IGD_TRD_RH_HOPHOSTADDRESS:
			strncpy(pxPV[iI].Value, xRoutehop.hophost_address, MAX_IP_ADDR_LEN);
			break;
		case OID_IGD_TRD_RH_HOPERRORCODE:
			sprintf(pxPV[iI].Value, "%d", xRoutehop.hop_err_code);
			break;
		case OID_IGD_TRD_RH_HOPRTTIMES:
			strncpy(pxPV[iI].Value, xRoutehop.hop_rtt_time, 16);
			break;
#endif
		default:
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			            "%s:%d [%d] Error! Default case\n", _FUNCL_,
			            pxPV[iI].iaOID[TRACEROUTEDIAG_DEPTH - 1]);
			break;
		}
	}

errorHandler:
	return iRet;
}

/*******************************************************************************
* Function: IFX_TraceRouteTest
* Desc:
*
* Parameters: TRACEROUTE_DIAG * pxTraceRouteQuery, TraceRouteResp * pxTraceRouteResp
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int
IFX_TraceRouteTest(INOUT TRACEROUTE_DIAG * pxTraceRouteQuery,
                   OUT TraceRouteResp * pxTraceRouteResp)
{
	FILE *fp1 = NULL;
	int32 iRet = IFX_CWMP_FAILURE;
	char8 caTmp[CWMP_MAX_OBJ_LEN] = { 0 }, caCommand[256] = { 0 };
	int32 iTmp = 0;
	ROUTE_HOPS *pxRoutehops = NULL;
	struct hostent *pxHE = NULL;
	
	int32 i,j,slno=0,deb_flg=0;
	char8 c;
	char8 buf[LINESIZE], tmp[LINESIZE];
	char8 hostname[LINESIZE], ipaddr[64], rtt[64];
	static int state=0;

	iTmp = pxTraceRouteQuery->max_hop_count > 0 ? pxTraceRouteQuery->max_hop_count : 30;

	pxRoutehops = (ROUTE_HOPS *) IFX_CWMP_MALLOC( (iTmp * sizeof(ROUTE_HOPS)));
        if(pxRoutehops == NULL)
            goto errorHandler;

	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, " max_hop_count:'%d'\n", pxTraceRouteQuery->max_hop_count);

	strcpy(caCommand, "traceroute");
	/* About to execute the commands. Put Error_Internal now. Overwrite it if
	   traceroute test succeeds */

	if (strlen(pxTraceRouteQuery->interface) > 0) {
		iRet = IFX_TraceRouteValidateInterface(pxTraceRouteQuery->interface, caTmp);
		if (iRet == IFX_CWMP_SUCCESS) {
			/* append the interface switch */
			strcat(caCommand, " -i ");
			/* append interface not IP Address for this interface */
			snprintf(caTmp, CWMP_MAX_OBJ_LEN-1, "%s", pxTraceRouteQuery->interface);
			caTmp[CWMP_MAX_OBJ_LEN-1] = '\0';
                         
                        strcat(caCommand, caTmp);
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"INTERFACE: %s \n\n",caTmp);

		} else {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			            "%s:%d Get %s fail\n", _FUNCL_, pxTraceRouteQuery->interface);
			goto errorHandler;
		}
	}

	/* append the number of tries switch. Default is 3 */
	if (pxTraceRouteQuery->num_tries > 0) {
		sprintf(caTmp, "%u", pxTraceRouteQuery->num_tries);
		strcat(caCommand, " -q ");
		strcat(caCommand, caTmp);
	}

	/* append the timeout(in milliseconds) switch. Default is 5 sec */
	if (pxTraceRouteQuery->timeout > 0) {
		sprintf(caTmp, "%u", (pxTraceRouteQuery->timeout/1000));
		strcat(caCommand, " -w ");
		strcat(caCommand, caTmp);
	}



	/* append the qos(dscp) switch. Default dscp = 0 */
	if (pxTraceRouteQuery->dscp > 0) {
		sprintf(caTmp, "%u", pxTraceRouteQuery->dscp);
		strcat(caCommand, " -t ");
		strcat(caCommand, caTmp);
	}

	/* append the max number of hops switch. Default is 30 */
	if (pxTraceRouteQuery->max_hop_count > 0) {
		sprintf(caTmp, "%u ", (*pxTraceRouteQuery).max_hop_count);
		strcat(caCommand, " -m ");
		strcat(caCommand, caTmp);
	}

	/* append the host */
	if ((iRet = inet_pton(AF_INET, pxTraceRouteQuery->host, &iTmp)) <= 0) {
		/* The the host must be Domain Name */
		res_init();
		pxHE = gethostbyname(pxTraceRouteQuery->host);
		if (pxHE == NULL) {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Invalid host %s\n",
			            _FUNCL_, pxTraceRouteQuery->host);
			strcpy(pxTraceRouteResp->caDiagState, "Error_CannotResolveHostName");
			iRet = IFX_CWMP_FAILURE;
			IFX_CWMP_FREE(pxRoutehops);
			goto testComplete;
		}
	}
	strcat(caCommand, pxTraceRouteQuery->host);

	/* append the data block size switch at the end. */
	if (pxTraceRouteQuery->data_size > 0) {
		sprintf(caTmp, "%u", pxTraceRouteQuery->data_size);
		strcat(caCommand, " ");
		strcat(caCommand, caTmp);
	}

	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "TRACEROUTECMD: '%s'\n", caCommand);


	if ((fp1 = popen(caCommand, "r")) == NULL) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d popen failed for %s\n",
		            _FUNCL_, caCommand);
		iRet = IFX_CWMP_FAILURE;
		goto errorHandler;
	}

	iTmp=0;

	while(fgets(buf, LINESIZE, fp1) != NULL)
	{
	
              IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d\n [BUF]: %s\n",
                            _FUNCL_, buf);
                 

        	memset(&hostname,0,LINESIZE);
		memset(&ipaddr,0,64);
		memset(&rtt,0,64);
		for(i=0,j=0,state=0;i<=strlen(buf);i++)
		{
			c=buf[i];
                        

                       if(buf[0]=='t'){
                         deb_flg=1;
                         break; 
                        }

			if(c==' '|| c=='\n')
			{
				if(state==2 && tmp[j-1]!=')')
				{
					tmp[j++]=' ';
					continue;
				}
				tmp[j]='\0';
				j=0;
				if(strlen(tmp)>0)
				{
					switch(state)
					{
						case 0:
							slno=atoi(tmp);
							state=1;
							break;
						case 1:
							if(tmp[0]=='!')
							{
							    	state=-1;
								break;
							}
							else if(tmp[0]=='*')
							{
								state=-2;
       	                         				break;
							}
							else
							{
								strncpy(hostname,tmp, LINESIZE-1);
								hostname[LINESIZE-1] = '\0';
								memset(&tmp,0,LINESIZE);
								state=2;
							} 	
							break;
						case 2:
							tmp[strlen(tmp)-1]='\0';
							strncpy(ipaddr,tmp+1, 63);
							ipaddr[63] = '\0';
							memset(&tmp,0,LINESIZE);
							state=3;
							break;
						case 3:
			   				if(tmp[0]=='*'){
								state=3;
							}
							else
							{
								strcat(rtt,",");
								strcat(rtt,tmp);
								memset(&tmp,0,LINESIZE);
								state=4;
							}
							break;
						case 4:
							state=3;
							break;
					}//switch
				}
			}
			else
			{
				tmp[j++]=c;
			}
		}

                 if(deb_flg==0){

		if(state == -2)
		{
			printf("Host Unreachable\n");
			pxRoutehops[iTmp].hop_err_code=3;
		}
		else if(state == -1)
		{
			printf("Time Exceeded\n");
			pxRoutehops[iTmp].hop_err_code=11;
		}
		else
		{
			printf("%d %s %s %s\n", slno, hostname, ipaddr, rtt+1);
		 	strcpy(pxRoutehops[iTmp].hophost, hostname);
			strncpy(pxRoutehops[iTmp].hophost_address, ipaddr, MAX_IP_ADDR_LEN-1);
			pxRoutehops[iTmp].hophost_address[MAX_IP_ADDR_LEN-1] = '\0';
			strcpy(pxRoutehops[iTmp].hop_rtt_time, rtt+1);
			pxTraceRouteResp->iResponseTime = atof(tmp);
		}
		pxTraceRouteResp->iRouteHopsNumberOfEntries = slno;
		iTmp++; 

          }

         deb_flg=0;

	}

	pxTraceRouteResp->pxRouteHops = pxRoutehops;

	iRet = IFX_CWMP_SUCCESS;
	strcpy(pxTraceRouteResp->caDiagState, "Complete");

	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "TraceRouteDiagnostics Complete\n");
	/* close the file */
	pclose(fp1);
testComplete:
	return IFX_CWMP_SUCCESS;

errorHandler:
	strcpy(pxTraceRouteResp->caDiagState, "Error_Internal");
	IFX_CWMP_FREE(pxRoutehops);
	return iRet;

}
/*******************************************************************************
* Function: IFX_Set_TraceRoute_RouteHops
* Desc: Set the value. Calls ifx_set_routehops. Set the required value.
* Return Value: IFX_CWMP_SUCCESS
*******************************************************************************/
static
int32 IFX_Set_TraceRoute_RouteHops(int32 numroutehops, ROUTE_HOPS * routehops)
{
	int32       ret = IFX_SUCCESS;
	uint32 iI, flags;
	char sOidStringList[IFX_MAX_TR69_ID_LEN];

	flags = IFX_F_INT_ADD;

	for (iI=0; iI<numroutehops; iI++) {
		memset(sOidStringList, '\0', IFX_MAX_TR69_ID_LEN);
#ifdef DEVICE_SUPPORT
		sprintf(sOidStringList, "Device.LAN.TraceRouteDiagnostics.RouteHops.");
#else
		sprintf(sOidStringList, "InternetGatewayDevice.TraceRouteDiagnostics.RouteHops.");
#endif
		ret = IFX_ContAddObj(ACC_ROOT, sOidStringList);
		if (ret <= 0) {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s:%d] IFX_ContAddObj() failed.\n", _FUNCL_);
			continue;
		} else {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s:%d] IFX_ContAddObj() succeded with instance id: %d.\n", _FUNCL_, ret);
		}

		routehops[iI].iid.cpeId.Id = iI + 1;
		routehops[iI].iid.config_owner = IFX_TR69;
		memset(routehops[iI].iid.tr69Id, '\0', sizeof(routehops[iI].iid.tr69Id));
#ifdef DEVICE_SUPPORT
                sprintf(routehops[iI].iid.tr69Id, "%d.%d.%d.%d.%d.", OID_IGD, OID_IGD_LAN,OID_IGD_LAN_TRD,OID_IGD_LAN_TRD_RH,iI + 1);
#else
		sprintf(routehops[iI].iid.tr69Id, "%d.%d.%d.%d.",OID_IGD,OID_IGD_TRD,OID_IGD_TRD_RH, iI + 1);
#endif
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s:%d] Adding routehops for cpeId %d.\n", _FUNCL_, routehops[iI].iid.cpeId.Id);
		ret = ifx_set_routehops(IFX_OP_ADD, &routehops[iI], flags);
		if (ret != IFX_SUCCESS) {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d] Adding routehops for cpeId %d failed !!!.\n", _FUNCL_, routehops[iI].iid.cpeId.Id);
			goto IFX_Handler;
		}
	}

IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] ifx_set_routehops failed\n", _FUNCL_, ret);
		return ret;
	} else
		return IFX_SUCCESS;
}


/*******************************************************************************
* Function: IFX_TraceRouteDiagPerformTest
* Desc: Gets the value. Calls IFX_TraceRouteTest. Set the required value. Posts the
*       message to the Stacks FIFO about the completion of Traaceroute Diag Test
* Parameters:
* Return Value: IFX_CWMP_SUCCESS
*******************************************************************************/
void *
IFX_TraceRouteDiagPerformTest(void * params) 
{
	int32 iRet = IFX_CWMP_SUCCESS, iFIFOFd = 0, i, iLastCpeId = -1;
	TRACEROUTE_DIAG xTraceroute;
	TraceRouteResp xTracerouteResp;
	ROUTE_HOPS xRoutehop;
	uint32 uiflags, outFlag;
	char8 sValue[MAX_FILELINE_LEN];
	char sOidStringList[IFX_MAX_TR69_ID_LEN];


	memset(&xTraceroute, '\0', sizeof(xTraceroute));
	memset(&xTracerouteResp, '\0', sizeof(xTracerouteResp));

	iRet = ifx_get_traceroute_diag(&xTraceroute);
	if (iRet != IFX_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		            "%s:%d [%d] ifx_get_traceroute_diag() failed\n", _FUNCL_, iRet);
		goto errorHandler;
	}

	memset(sValue,'\0',sizeof(sValue));
	if ((iRet = ifx_GetObjData(FILE_RC_CONF, "next_cpeid", "traceroute_routehops_nextCpeId", 
	                   IFX_F_DEFAULT, &outFlag, sValue)) != IFX_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		            "%s:%d [%d] ifx_GetObjData() failed\n", _FUNCL_, iRet);
		goto errorHandler;
	} else {
		iLastCpeId = atoi(sValue);
	}
/*xTraceroute.root_hop_num_entries is the max number of hops/TTL to be used in the outgoing packet while performing
trace route. Actual number of route hop entries is in  xTracerouteResp. We need to store this somewhere to retrieve while deleting. Either put it into the traceroute_diag(info) section itself as current no of routehop entries*/


	for(i=iLastCpeId; i > 2; i--) {
		memset(sOidStringList, '\0', IFX_MAX_TR69_ID_LEN);

		/* Object ID = cpeId - 1 = i - 2 */
#ifdef DEVICE_SUPPORT
		sprintf(sOidStringList, "Device.LAN.TraceRouteDiagnostics.RouteHops.%d.", i - 2);
#else
		sprintf(sOidStringList, "InternetGatewayDevice.TraceRouteDiagnostics.RouteHops.%d.", i - 2);
#endif
		iRet = IFX_ContDelObj(ACC_ROOT, sOidStringList, NO_SESSION);
		if (iRet != IFX_SUCCESS) {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] IFX_ContDelObj() failed\n", _FUNCL_, iRet);
			iRet = ERR_CWMP_INTERNAL;
			goto errorHandler;
		}

		xRoutehop.iid.cpeId.Id = i - 1;
		xRoutehop.iid.config_owner = IFX_TR69;
		xRoutehop.iid.pcpeId.Id = 1;

		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "Getting routehops for cpeid %d.\n", xRoutehop.iid.cpeId.Id);
		iRet = ifx_get_routehops(&xRoutehop);
		if (iRet != IFX_SUCCESS) {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			            "%s:%d [%d] ifx_get_routehops() failed\n", _FUNCL_, iRet);
			iRet = ERR_CWMP_INTERNAL;
			goto errorHandler;
		}

		uiflags = IFX_F_DELETE | IFX_F_DONT_CHECKPOINT;

		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "Deleting routehops for cpeid %d.\n", xRoutehop.iid.cpeId.Id);
		iRet = ifx_set_routehops(IFX_OP_DEL, &xRoutehop, uiflags);
		if (iRet != IFX_CWMP_SUCCESS) {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			            "[%s:%s:%d] [%d] RouteHops Delete Object failed "
			            ,__FILE__, __func__, __LINE__, iRet);
			iRet = ERR_CWMP_INTERNAL;
			goto errorHandler;
		}
	}

	memset(sValue, '\0', sizeof(sValue));
	// sprintf(sValue, "%s_nextCpeId=\"2\"", "traceroute_routehops");
	strcpy(sValue, "traceroute_routehops_nextCpeId=\"2\"\n");
	if ((iRet = ifx_SetObjData(FILE_RC_CONF, "next_cpeid", IFX_F_MODIFY, 1, sValue)) != IFX_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		            "%s:%d [%d] ifx_SetObjData() failed\n", _FUNCL_, iRet);
		goto errorHandler;
	}

	iRet = IFX_TraceRouteTest(&xTraceroute, &xTracerouteResp);
	if (iRet == IFX_CWMP_SUCCESS) {
		xTraceroute.resp_time = xTracerouteResp.iResponseTime;
		xTraceroute.root_hop_num_entries = xTracerouteResp.iRouteHopsNumberOfEntries;
	}
	strcpy(xTraceroute.diag_state, xTracerouteResp.caDiagState);

	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s:%d: IFX_TraceRouteTest returned\n", _FUNCL_);

       	iRet = ifx_set_traceroute_diag(&xTraceroute, IFX_F_MODIFY);
	if (iRet != IFX_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		            "%s:%d [%d] ifx_set_traceroute_diag() failed\n", _FUNCL_, iRet);
		iRet = ERR_CWMP_INTERNAL;
		goto errorHandler;
	}

	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "saved the xTraceroute\n");
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s:%d [*] saving RouteHops. Count = %d\n", _FUNCL_, xTracerouteResp.iRouteHopsNumberOfEntries);
        if(xTracerouteResp.pxRouteHops == NULL){
            IFX_DBG_Log(vcOsModId,
                    IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] No RouteHops instances \n",
                    _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
        }	
	iRet = IFX_Set_TraceRoute_RouteHops(xTracerouteResp.iRouteHopsNumberOfEntries,
	                                    xTracerouteResp.pxRouteHops);
	if (iRet != IFX_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		            "%s:%d [%d] ifx_set_traceroute_routehops() failed\n", _FUNCL_, iRet);
		iRet = ERR_CWMP_INTERNAL;
		goto errorHandler;
	}
	/* APARNA - To ADD to DS*/

	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "kamal: saved the pxRouteHops\n");
	sleep(2);
#if 0
	/*Free xTracerouteResp.pxRouteHops array*/
	IFX_CWMP_FREE(xTracerouteResp.pxRouteHops);
#endif	
	/* Send msg to FIFO */
	iFIFOFd = IFX_OS_OpenFifo((uchar8 *) IFX_IPC_TR_FIFO, O_RDWR);
	if (iFIFOFd < 0) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s:%d Error opening FIFO\n",
		            _FUNCL_);
		iRet = ERR_CWMP_FIFO_OPEN;
		goto errorHandler;
	}

	if (IFX_IPC_SendMsg(iFIFOFd, (uchar8) IFX_IPC_APP_DIAGNOSTIC, 0, 0, 0, NULL)
	        != IFX_IPC_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Error sending msg to "
		            "FIFO\n", _FUNCL_);
	}
        else
	    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "kamal: message sent\n");
	
	IFX_OS_CloseFifo(iFIFOFd);
	

errorHandler:
	/* Always return SUCCESS */
        /*Free xTracerouteResp.pxRouteHops array*/
        IFX_CWMP_FREE(xTracerouteResp.pxRouteHops);

	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "kamal: thread returns\n");
	pthread_mutex_unlock(&msg_mutex);
	sleep(2);
	pthread_exit(0);
}



/*******************************************************************************
* Function: IFX_TraceRouteDiagnostics
* Desc:
*
* Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
*             OUT void **ppRet, OUT int32 * piNumRetElem
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_TraceRouteDiagnostics(IN OperInfo * pxOI,
                          INOUT void *pParamStruct,
                          IN int32 iElements, OUT void **ppRet,
                          OUT int32 * piNumRetElem)
{
	int32 iRet = IFX_CWMP_SUCCESS;
	ParamVal *xpParamVal = (ParamVal *) pParamStruct;
	pthread_t traceroutetest;

	switch (pxOI->iOper) {
	case OP_GETVAL:
		switch(pxOI->iSubOper)
		{
			case OP_GETVAL_NORMAL:
			case OP_GETVAL_NOTIFICATION:
				iRet = IFX_TraceRouteDiagGetNotifyValue(pxOI, xpParamVal,
			                                        iElements);
				if (iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				break;
			default:
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			            "%s:%d [%d] Error! Default case.\n", _FUNCL_,
			            pxOI->iSubOper);
				break;
		}
		break;
	case OP_SETVAL:
		switch (pxOI->iSubOper)
		{
			case OP_SETVAL_VALIDATE:
				iRet = IFX_TraceRouteDiagValidate(xpParamVal, iElements);
				if (iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				break;
			case OP_SETVAL_ADD:
				iRet = ERR_CWMP_INVAL_ARGS;
				goto errorHandler;
				break;
			case OP_SETVAL_CHK_MODIFY_DEP:
				break;
			case OP_SETVAL_MODIFY:
				iRet = IFX_TraceRouteDiagSetValue(xpParamVal, iElements);
				if((iRet != IFX_SUCCESS) && (iRet != IFX_CWMP_NEED_ACTIVATE))
				{
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, 
						"%s:%d, IFX_TraceRouteDiagSetValue() failed! \n", _FUNCL_);
					goto errorHandler;
				}
				break;
			case OP_SETVAL_ACTIVATE:
				pthread_mutex_lock(&msg_mutex);
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "Creating thread\n");
				iRet = pthread_create(&traceroutetest, NULL, IFX_TraceRouteDiagPerformTest, NULL);
		    		if (iRet != IFX_SUCCESS)
					goto errorHandler;
			case OP_SETVAL_COMMIT:
				break;
			case OP_SETVAL_UNDO:
				iRet = ERR_CWMP_INVAL_ARGS;
				goto errorHandler;
				break;
			case OP_SETVAL_CHK_DEL_DEP:
				iRet = ERR_CWMP_INVAL_ARGS;
				goto errorHandler;
				break;
			case OP_SETVAL_CHK_DEL_ALLOWED:
				iRet = ERR_CWMP_INVAL_ARGS;
				goto errorHandler;
				break;
			case OP_SETVAL_DELETE:
				iRet = ERR_CWMP_INVAL_ARGS;
				goto errorHandler;
				break;
			case OP_SETVAL_FREE:
				break;
			case OP_SETVAL_ATTRINFO:
				iRet = IFX_TraceRouteDiagSetAttrInfo(pxOI->iCaller, pParamStruct,
				      				                            iElements);
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				break;
			default:
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
				            "%s:%d [%d] Error! Default case.\n", _FUNCL_,
			        	    pxOI->iSubOper);
				break;
		}
		break;
	case OP_UPDATE_CHILDINFO:
		switch (pxOI->iSubOper)
		{
			case OP_UPDATE_CHILDINFO_ADD:
			case OP_UPDATE_CHILDINFO_DEL:
				break;
		}
		break;
	case OP_PARAM_VALIDATE:
		break;
	default:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		            "%s:%d [%d] Error! Default case.\n", _FUNCL_,
		            pxOI->iOper);
		break;
	}
errorHandler:
	return iRet;
}

/*******************************************************************************
* Function: IFX_RouteHops
* Desc:
*
* Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
*             OUT void **ppRet, OUT int32 * piNumRetElem
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_RouteHops(IN OperInfo * pxOI,
              INOUT void *pParamStruct,
              IN int32 iElements, OUT void **ppRet,
              OUT int32 * piNumRetElem)
{
	int32 iRet = IFX_CWMP_SUCCESS;
	ParamVal *pxParamVal = (ParamVal *) pParamStruct;
	ParamVal    *pxVal;
	uint32 uiParamPos=0;

        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "Entered IFX_RouteHops [%d :: %d]\n", pxOI->iOper, pxOI->iSubOper);

	switch (pxOI->iOper)
	{
		case OP_GETVAL:
		{
                      IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "Entered OP_GETVAL\n");
			switch (pxOI->iSubOper)
			{
				case OP_GETVAL_NORMAL:
                                     IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "Entered OP_GETVAL_NORMAL\n");
				case OP_GETVAL_NOTIFICATION:
                                      IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "Entered OP_GETVAL_NOTIFICATION\n");
					iRet = IFX_RouteHopsGetValue(pxOI, pxParamVal, iElements);
					if (iRet != IFX_CWMP_SUCCESS){
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "IFX_RouteHopsGetValue FAILED\n");	
                                           goto errorHandler;
                                            }
					break;
				default:
					goto errorHandler;
					break;
			}
			break;
		}
		case OP_SETVAL:
		{
			/* Process based on type of SubOperation */
			switch (pxOI->iSubOper)
			{
				case OP_SETVAL_VALIDATE:
				case OP_SETVAL_MODIFY:
				case OP_SETVAL_ACTIVATE:
				case OP_SETVAL_ADD:
				case OP_SETVAL_CHK_MODIFY_DEP:
				case OP_SETVAL_CHK_DEL_ALLOWED :
				case OP_SETVAL_DELETE:
				case OP_SETVAL_ATTRINFO:
				case OP_SETVAL_FREE :
					break;
				case OP_SETVAL_CHK_DEL_DEP:
					pxVal= (void *)IFX_CWMP_MALLOC (sizeof(ParamVal));
					uiParamPos = IFX_GetParamIdPos(pxParamVal->iaOID);
					memcpy(pxVal->iaOID,pxParamVal->iaOID,(sizeof(int32)*(uiParamPos+1)));
					*ppRet = (void*) pxVal;
					*piNumRetElem = 1;
					break;
				default:
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                                "[%s:%d] [Error] Requested SubOperation not"
                		                " permitted on Object\n", __func__, __LINE__);
					iRet = IFX_CWMP_FAILURE;
					goto errorHandler;
			}
			break;
		}
		case OP_PARAM_VALIDATE:
			break;
		default:
		{
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			            "%s:%d [%d] Error! Default case.\n", _FUNCL_, pxOI->iOper);
			break;
		}
	}

errorHandler:
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "IFX_RouteHops returning %d\n", iRet);
	return iRet;
}
/*******************************************************************************
* Function: IFX_TraceRouteDiagInit

* Parameters:
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_TraceRouteDiagInit()
{
	int32 iRet = IFX_CWMP_SUCCESS;
	TRACEROUTE_DIAG xTraceroute;

	memset(&xTraceroute, '\0', sizeof(xTraceroute));


	strcpy(xTraceroute.diag_state, "None");
	strcpy(xTraceroute.host, "0.0.0.0");
	strcpy(xTraceroute.interface, "");
	xTraceroute.num_tries=3;
        xTraceroute.timeout=5000;
        xTraceroute.data_size=38;
        xTraceroute.dscp=0;
        xTraceroute.max_hop_count=30;

	/* Register the IFX_TraceRouteDiagInit func ptr in the object model */
	iRet = ifx_ds_register_function(TRACEROUTEDIAG_OBJ, IFX_TraceRouteDiagnostics);
	if (iRet != IFX_CWMP_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		            "%s:%d [%d] Unable to Register %s with Object Model\n",
		            _FUNCL_, iRet, TRACEROUTEDIAG_OBJ);
		goto errorHandler;
	}

	iRet = ifx_ds_register_function(ROUTEHOPS_OBJ, IFX_RouteHops);
	if (iRet != IFX_CWMP_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		            "%s:%d [%d] Unable to Register %s with Object Model\n",
		            _FUNCL_, iRet, ROUTEHOPS_OBJ);
		goto errorHandler;
	}
        
	//iRet = ifx_set_traceroute_diag(0, &xTraceroute, IFX_F_INT_ADD | IFX_F_MODIFY);
IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d]max_hop_count = %d\n", _FUNCL_, xTraceroute.max_hop_count);
	iRet = ifx_set_traceroute_diag(&xTraceroute, IFX_F_INT_ADD);
	if (iRet != IFX_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Writing default "
		            "traceroute_diag section failed in %s\n", _FUNCL_, iRet,
		            IFX_DIAG_FILE);
	}

	/* Cleanup tr69_maps and tr69_instances and reset traceroute_routehops_nextCpeId */
	ifx_cleanup_traceroute_tr69_maps();
	ifx_cleanup_traceroute_tr69_instances();
    ifx_reset_traceroute_next_cpeid();

errorHandler:
	return iRet;
}

