/* 
** =============================================================================
**   FILE NAME     : IFX_DEVM_WLANStats
**   PROJECT       : TR69
**   MODULES       : WLANStats
**   DATE          : 27-09-2007
**   AUTHOR        : TR69 team
**   DESCRIPTION   : This module handles GET RPC of 
**                   hosts/hosts.host. When controller calls this module it
**                   calls respective Platform/Object APIs of the sytem.
**
**   REFERENCES    : < List of design docs covering this file >
**   COPYRIGHT     : Copyright (c) 2006
**                   Infineon Technologies AG
**                   Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY       : 
**   $Date         $Author               $Comment
**   28-03-07      TR69 Team             Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "IFX_DEVM_WLANStats.h"
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
 

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;

#ifdef IFX_TR69_DEVICE
	#define OID_IGD_LAND_WLANC_S_ERRORSSENT		OID_IGD_LAN_WLANC_S_ERRORSSENT
	#define OID_IGD_LAND_WLANC_S_ERRORSRECEIVED	   OID_IGD_LAN_WLANC_S_ERRORSRECEIVED
	#define OID_IGD_LAND_WLANC_S_UNICASTPACKETSSENT		OID_IGD_LAN_WLANC_S_UNICASTPACKETSSENT
	#define OID_IGD_LAND_WLANC_S_UNICASTPACKETSRECEIVED	OID_IGD_LAN_WLANC_S_UNICASTPACKETSRECEIVED
	#define OID_IGD_LAND_WLANC_S_DISCARDPACKETSSENT		OID_IGD_LAN_WLANC_S_DISCARDPACKETSSENT
	#define OID_IGD_LAND_WLANC_S_DISCARDPACKETSRECEIVED	OID_IGD_LAN_WLANC_S_DISCARDPACKETSRECEIVED
	#define OID_IGD_LAND_WLANC_S_MULTICASTPACKETSSENT	OID_IGD_LAN_WLANC_S_MULTICASTPACKETSSENT
	#define OID_IGD_LAND_WLANC_S_MULTICASTPACKETSRECEIVED	OID_IGD_LAN_WLANC_S_MULTICASTPACKETSRECEIVED
	#define OID_IGD_LAND_WLANC_S_BROADCASTPACKETSSENT	OID_IGD_LAN_WLANC_S_BROADCASTPACKETSSENT
	#define OID_IGD_LAND_WLANC_S_BROADCASTPACKETSRECEIVED	OID_IGD_LAN_WLANC_S_BROADCASTPACKETSRECEIVED
	#define OID_IGD_LAND_WLANC_S_UNKNOWNPROTOPACKETSRECEIVED	OID_IGD_LAN_WLANC_S_UNKNOWNPROTOPACKETSRECEIVED
#endif

#define IFX_WLAN_ASSOCDEVICE_OBJ FORMLANNAME("WLANConfiguration.1.Stats.")

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/




/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/


extern Map_Value gaxEnable[];

/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/



/*
** =============================================================================
**   Function Name    : IFX_WlanStatsGetValue
**   Description        :
**
**   Parameters       :
**
**   Return Value     :
**   Notes                :
**
** ============================================================================
*/
static int32
IFX_WlanStatsGetValue(IN OperInfo * pxOperInfo,
                            INOUT ParamVal * pxGetParamVal, IN uint32 iElements,
                            OUT int32 * puiNoInstances)
{
	uint32 iCpeid = 0, i = 0;
	uint32 uiParamPos = 0;
	int32 iRet = 0;

	IFX_MAPI_WLAN_Stats wlStats;
	
	// Get Cpeid from object ID
	iRet = IFX_GetCpeId(pxGetParamVal->iaOID, &iCpeid);
	if (iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	uiParamPos = IFX_GetParamIdPos(pxGetParamVal->iaOID);
	
	wlStats.iid.cpeId.Id = iCpeid;
	iRet = ifx_mapi_get_wlan_stats(&wlStats,IFX_F_GET_ANY);
	if (iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	for (i = 0; i < iElements; i++)
	{
		pxGetParamVal[i].Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
		switch (pxGetParamVal[i].iaOID[uiParamPos])
		{
		case OID_IGD_LAND_WLANC_S_ERRORSSENT:
			sprintf(pxGetParamVal[i].Value, "%u", wlStats.errorsTx); 
			break;
		case OID_IGD_LAND_WLANC_S_ERRORSRECEIVED:
			sprintf(pxGetParamVal[i].Value, "%u", wlStats.errorsRx); 
			break;
		case OID_IGD_LAND_WLANC_S_UNICASTPACKETSSENT:
			sprintf(pxGetParamVal[i].Value, "%u", wlStats.ucPktsTx); 
			break;
		case OID_IGD_LAND_WLANC_S_UNICASTPACKETSRECEIVED:
			sprintf(pxGetParamVal[i].Value, "%u", wlStats.ucPktsRx); 
			break;
		case OID_IGD_LAND_WLANC_S_DISCARDPACKETSSENT:
			sprintf(pxGetParamVal[i].Value, "%u", wlStats.discardPktsTx); 
			break;
		case OID_IGD_LAND_WLANC_S_DISCARDPACKETSRECEIVED:
			sprintf(pxGetParamVal[i].Value, "%u", wlStats.discardPktsRx); 
			break;
		case OID_IGD_LAND_WLANC_S_MULTICASTPACKETSSENT:
			sprintf(pxGetParamVal[i].Value, "%u", wlStats.mcPktsTx); 
			break;
		case OID_IGD_LAND_WLANC_S_MULTICASTPACKETSRECEIVED:
			sprintf(pxGetParamVal[i].Value, "%u", wlStats.mcPktsRx ); 
			break;
		case OID_IGD_LAND_WLANC_S_BROADCASTPACKETSSENT:
			sprintf(pxGetParamVal[i].Value, "%u", wlStats.bcPktsTx); 
			break;
		case OID_IGD_LAND_WLANC_S_BROADCASTPACKETSRECEIVED:
			sprintf(pxGetParamVal[i].Value, "%u", wlStats.bcPktsRx); 
			break;
		case OID_IGD_LAND_WLANC_S_UNKNOWNPROTOPACKETSRECEIVED:
			sprintf(pxGetParamVal[i].Value, "%u", 0);        // Not supported
			break;		
		default:
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			            "%s:%d Invalid param id %d!\n", _FUNCL_, pxGetParamVal[i].iaOID[uiParamPos]);
			pxGetParamVal->iFaultCode = ERR_INVAL_PARAMETER_VAL;
			break;
		}
	}

	return IFX_CWMP_SUCCESS;

errorHandler:
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	            "%s:%d failed iParamId = %d !\n", _FUNCL_, pxGetParamVal[i].iaOID[uiParamPos]);
	return IFIN_CWMP_FAILURE;
}


/** =============================================================================
**   Function Name    : IFX_WlanStatsSetAttr
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

int32
IFX_WlanStatsSetAttr(IN OperInfo * pxOpInfo, INOUT ParamVal * pxParamVal,
                           IN int32 iElements)
{
    uint32 iRet = IFX_CWMP_SUCCESS, iI;
	iRet = IFX_SetAttributesInfo(pxOpInfo, pxParamVal, iElements);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d failed!\n", _FUNCL_);
        goto errorHandler;
    }

  errorHandler:
    for(iI = 0; iI < iElements; iI++)
        IFX_CWMP_FREE(pxParamVal[iI].Value);
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_WlanStatsAddObj
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WlanStatsAddObj(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{

	int32 iRet = 0;
	uint32 uiOper = 0;
	uint32 uiParamPos = 0;
	int32 iaOID[OID_LENGTH] = { 0 };
	char8 Tr69_str[MAX_NAME_LEN] = { 0 };
	char8 usSecTag[IFX_MAX_SECTION_TAG_LEN] = { 0 };
	char8 usParamTag[IFX_MAX_NAME_LEN] = { 0 };
	uint32 uiCpeid = 0;
	IFX_Id pxIfxId;

	//Get the Position of the Param Id
	uiParamPos = IFX_GetParamIdPos(pxParamVal->iaOID);
	memset(iaOID,0x00,(sizeof(int32)*OID_LENGTH));
	memcpy(iaOID,pxParamVal->iaOID,(sizeof(int32)* (uiParamPos-1)));
	
	//Get the Parent Obj Cpeid
	iRet = IFX_GetObjCpeId(iaOID,&uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	iRet = IFX_GetCpeId(iaOID,&uiCpeid);
	if(iRet == IFX_CWMP_SUCCESS)
	        return iRet;	

	//Get the SectionName 
	iRet=IFX_GetSectionParamTag(pxParamVal->psRCTag, usParamTag, 
														usSecTag);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
		
	//Convert Tr69_id into dotted form
	iRet = IFX_ConvertOidDottedForm(pxParamVal->iaOID, Tr69_str);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	//Call Protocol API to update the Mapping
	uiOper = IFX_TR69ID_MAP_TBL_OPER_ADD_ENTRY;
	pxIfxId.xCpeId.uiId = uiCpeid;
	strcpy(pxIfxId.xCpeId.sSectionTag,usSecTag);
	strcpy(pxIfxId.sTr69Id,Tr69_str);
	
	iRet = IFX_UpdateTr69CpeIdMap(&pxIfxId, uiOper);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	return IFIN_CWMP_SUCCESS;

	errorHandler:
		 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d failed!\n", __func__, __LINE__);
		return IFIN_CWMP_FAILURE;

}


static int32
IFX_WlanStatsDelete(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
				IN int32 iElements, OUT void **ppxParamStructRet,
						   OUT int32 * piNumRetElem)
{
	
	int32 iRet=0;
	uint32 uiOper;
	uint32 uiParamPos;
	int32 iaOID[OID_LENGTH];
	char8 Tr69_str[MAX_NAME_LEN];
	char8 usSecTag[IFX_MAX_SECTION_TAG_LEN];
	char8 usParamTag[IFX_MAX_NAME_LEN];
	uint32 uiCpeid;
	IFX_Id pxIfxId;

	memset(iaOID, 0x00, (sizeof(int32)*OID_LENGTH));
	
	if(pxOpInfo->iSubOper == OP_SETVAL_DELETE)
	{
		//Get the Position of the Param Id
		uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);
		memcpy(iaOID,paxParamVal->iaOID,(sizeof(int32)* (uiParamPos)));
		
		//Get the Parent Obj Cpeid
		iRet = IFX_GetCpeId(iaOID,&uiCpeid);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;

		//Get the SectionName 
		iRet=IFX_GetSectionParamTag(paxParamVal->psRCTag, usParamTag,													usSecTag);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;
			
		//Convert Tr69_id into dotted form
		iRet = IFX_ConvertOidDottedForm(paxParamVal->iaOID, Tr69_str);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;
		
		//Call Protocol API to update the Mapping
		uiOper = IFX_TR69ID_MAP_TBL_OPER_DEL_ENTRY;
		pxIfxId.xCpeId.uiId = uiCpeid;
		strcpy(pxIfxId.xCpeId.sSectionTag,usSecTag);
		strcpy(pxIfxId.sTr69Id,Tr69_str);
		
		iRet = IFX_UpdateTr69CpeIdMap(&pxIfxId, uiOper);
		
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,"RETURN!!!");

                /* This is a hack. Currently this is invoked twice from web, due to which it fails for
                   second time. We are neglecting the return type. */
                iRet = IFX_CWMP_SUCCESS;

	}
	return IFIN_CWMP_SUCCESS;

	errorHandler:
		 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d failed!\n", __func__, __LINE__);
	return IFIN_CWMP_FAILURE;
}


/*
** =============================================================================
**   Function Name    : IFX_WlanStats_Init
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/
int32
IFX_WlanStats_Init(void)
{
	int32 iRet = IFX_CWMP_SUCCESS;

	iRet =
	    ifx_ds_register_function(IFX_WLAN_ASSOCDEVICE_OBJ, IFX_WlanStats);

	/* Check for error */
	if (iRet != IFX_CWMP_SUCCESS)
	{
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		            "Unable to Register %s with Object Model\n",
		            IFX_WLAN_ASSOCDEVICE_OBJ);
		goto errorHandler;
	}
errorHandler:
	return iRet;
}


/*********************************************************************************
*  Function Name  :  IFX_WlanStats

*  Description	  :  This function handles all the sub-states inside
      	 	     a GET/SET operation.If it is a GET it allocates the
		     array(Name,Value pairs) and retruns the values.
		     If it is a SET controller allocates the array and
		     passes the values to this function.It calls
		     respective internal functions which in turn calls
		     respective Platform APIs.

*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
							     Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has
					  	             Name,Value,etc
                    IN          int32	       iElements;    No. of Elements
		    OUT	        void *	       ppParamRet;   same as ParamStruc
		    OUT         int32 *        piNumRetElem; No. of elements
*  Return Value  : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes         :
***********************************************************************************/
int32
IFX_WlanStats(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                    IN int32 iElements, OUT void **ppaxParamArrRet,
                    OUT int32 * piNumRetElem)
{

	int32 iRet = 0;
	ParamVal *paxParamArr = (ParamVal *) paxParameterArr;

	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d SubOper=%d '%s' Elem=%d\n",
	            _FUNCL_, pxOperInfo->iSubOper, (char8 *) paxParamArr[0].Name,
	            iElements);
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
			            "%s:%d ########## WlanStats called!\n", _FUNCL_);

	switch (pxOperInfo->iOper)
	{
	case OP_GETVAL:
	case OP_GETVAL_NORMAL:
		if ((iRet = IFX_WlanStatsGetValue(pxOperInfo, paxParamArr,
		                                        iElements, piNumRetElem)) !=
		        IFX_CWMP_SUCCESS)
		{
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			            "%s:%d OP_GETVAL failed!\n", _FUNCL_);
			goto errorHandler;
		}
		break;
	case OP_SETVAL:
		// Set the obj values
		switch (pxOperInfo->iSubOper)
		{
		case OP_SETVAL_VALIDATE:
		case OP_SETVAL_CHK_MODIFY_DEP:
		case OP_SETVAL_MODIFY:
			iRet = ERR_CWMP_INVAL_OPER;
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			            "[%s:%d] [%d] Invalid SubOperation\n",
			            _FUNCL_, iRet);
			goto errorHandler;
			break;
		case OP_SETVAL_COMMIT:
		case OP_SETVAL_UNDO:
		case OP_SETVAL_CHK_DEL_DEP:
			*ppaxParamArrRet = (ParamVal *)IFX_CWMP_MALLOC(sizeof(ParamVal));
			if(ppaxParamArrRet!=NULL)
			{	
                        	memcpy(*ppaxParamArrRet, paxParameterArr, sizeof(ParamVal));
                        	*piNumRetElem = 1;
			}
			else
			{
				goto errorHandler;
			}
                	break;
		case OP_SETVAL_CHK_DEL_ALLOWED:
		case OP_SETVAL_DELETE:
		         if((iRet= IFX_WlanStatsDelete(pxOperInfo, paxParamArr,
		    					iElements, ppaxParamArrRet,
		    					piNumRetElem))!= IFX_CWMP_SUCCESS) 
		    	{
		                
			        switch(pxOperInfo->iSubOper)
				{	
					case OP_SETVAL_CHK_DEL_DEP:
						IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                        	"%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
					            goto errorHandler;
					case OP_SETVAL_CHK_DEL_ALLOWED:
							IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
					            goto errorHandler;
					case OP_SETVAL_DELETE:
						IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                           	"%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
					          goto errorHandler;
				}
			}                
			break;
		case OP_SETVAL_ADD:
                        if ((iRet =IFX_WlanStatsAddObj( pxOperInfo, paxParamArr,
                                                        iElements)) != IFX_CWMP_SUCCESS)
                        {
                               IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d OP_SETVAL_ADD failed!\n", _FUNCL_);
                                goto errorHandler;
                        }
			break;
		case OP_SETVAL_FREE:
			iRet = IFIN_CWMP_SUCCESS;
			break;
		case OP_SETVAL_ATTRINFO:
			if ((iRet =
			            IFX_WlanStatsSetAttr(pxOperInfo, paxParamArr,
			                                       iElements)) !=
			        IFX_CWMP_SUCCESS)
			{
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
				            "%s:%d OP_SETVAL_ATTRINFO failed!\n",
				            _FUNCL_);
				goto errorHandler;
			}
			break;
		default:
			break;
		}
                break;

	case OP_UPDATE_CHILDINFO:
		break;
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
	default:
		break;
	}
	return IFX_CWMP_SUCCESS;

errorHandler:
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s:%d iRet[%d]\n", _FUNCL_, iRet);
	return iRet;

}
