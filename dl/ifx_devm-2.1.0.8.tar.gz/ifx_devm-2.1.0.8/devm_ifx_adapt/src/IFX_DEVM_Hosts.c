/* 
** =============================================================================
**   FILE NAME        : IFX_Hosts.c
**   PROJECT          : TR69
**   MODULES         : Hosts
**   DATE               : 28-03-2007
**   AUTHOR           : TR69 team
**   DESCRIPTION   : This module handles GET RPC of 
**                     	     hosts/hosts.host. When controller calls this module it
**                      	     calls respective Platform/Object APIs of the sytem.
**
**   REFERENCES     : 	< List of design docs covering this file >
**   COPYRIGHT       : 	Copyright (c) 2006
**                      		Infineon Technologies AG
**                      		Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author               $Comment
**   28-03-07         TR69 Team             Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "IFX_DEVM_Global.h"
#include "IFX_DEVM_AdaptCommon.h"
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_StackUtil.h"
 
#include "IFX_DEVM_DS.h"
#include "IFX_DEVM_Hosts.h"
 

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;

#define IFX_HOSTS_OBJ "InternetGatewayDevice.LANDevice.1.Hosts."
#define IFX_HOSTS_HOST_OBJ "InternetGatewayDevice.LANDevice.1.Hosts.Host.1."

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/

#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
extern int ifx_get_lan_hosts_stub(int32 *uiNumOfEntries,LAN_HOST_INFO ** pxLanHosts,
                                                 LAN_HOST_TYPE hType , char8 *IfName, uint32 uiFlags);
#endif



/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/


static Map_Value saxEnable[] = {
    {"1", SYS_DATATYPE_INT, {.uiSys_Value =IFX_ENABLED}},
    {"0", SYS_DATATYPE_INT, {.uiSys_Value =IFX_DISABLED}}
};
static Map_Value saxLanHostAddrType[]={
{"DHCP",SYS_DATATYPE_INT,{.uiSys_Value=LAN_HOST_DHCP_TYPE}},
{"Static",SYS_DATATYPE_INT,{.uiSys_Value=LAN_HOST_STATIC_TYPE}},
{"AutoIP",SYS_DATATYPE_INT,{.uiSys_Value=LAN_HOST_AUTO_TYPE}} 
 };

static Map_Value saxLanHostInterfaceType[]={
{"Ethernet",SYS_DATATYPE_INT,{.uiSys_Value=PHY_IF_ETHER_TYPE}},
{"USB",SYS_DATATYPE_INT,{.uiSys_Value= PHY_IF_USB_TYPE}},
{"802.11",SYS_DATATYPE_INT,{.uiSys_Value=PHY_IF_802_11_TYPE}},
{"HomePNA",SYS_DATATYPE_INT,{.uiSys_Value=PHY_IF_HOME_PNA_TYPE}},
{"HomePlug",SYS_DATATYPE_INT,{.uiSys_Value=PHY_IF_HOME_PLUG_TYPE}},
{"Other",SYS_DATATYPE_INT,{.uiSys_Value=PHY_IF_OTHER_TYPE}},
 };

/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/
//If we maintain in an array the following issues are there
        // After reboot we need to synchronize with the system
        // If the connection goes down we may not have the correct count
        // Extra ram storage

static int32
IFX_GetHostNoEntries(IN uint32 uiInstanceId, OUT LAN_HOST_INFO * pxLanHostObj,
                     OUT uint32 *uiNumberOfEntries )
{

    LAN_HOST_INFO *pxLanHosts = NULL;
    LAN_HOST_TYPE hType=LAN_HOST_ALL_TYPE;
    int32 uiNumOfEntries = 0;
    uint32 uiFlags;
    uint32 iRet = 0;
    char8 ucInterfaceName[MAX_IF_NAME_LEN] = { 0 };

    uiFlags = IFX_F_GET_ANY;
 
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
    iRet =
        ifx_get_lan_hosts_stub(&uiNumOfEntries, &pxLanHosts, hType, ucInterfaceName,uiFlags);
#else
    iRet =
        ifx_get_lan_hosts(&uiNumOfEntries, &pxLanHosts, hType, ucInterfaceName, uiFlags);
#endif

    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d ifx_get_lan_hosts failed!\n", __func__,
                    __LINE__);
        goto errorHandler;
    }

    *uiNumberOfEntries = uiNumOfEntries;
    if(uiNumOfEntries == 0)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d No host entries !!!\n", __func__, __LINE__);
    iRet=0;
    goto errorHandler;
    }

    if(uiInstanceId <= uiNumOfEntries) 
    {
        memcpy(pxLanHostObj, (pxLanHosts+ (uiInstanceId-1)),sizeof(LAN_HOST_INFO));
    }
    else 
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d Instance not Found in list of hosts !!!\n", __func__,
                    __LINE__);
	iRet = IFIN_CWMP_FAILURE;
        goto errorHandler;

    }

    if(pxLanHosts != NULL)
        IFIN_CWMP_FREE(pxLanHosts);

    return IFIN_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed!\n", __func__, __LINE__);
    if(pxLanHosts != NULL)
        IFIN_CWMP_FREE(pxLanHosts);
    *uiNumberOfEntries = 0;

    return iRet;

}


/* 
** =============================================================================
**   Function Name    : IFX_HostsGetValue
**   Description        : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes                : 
**
** ============================================================================
*/
static int32
IFX_HostGetValue(IN OperInfo * pxOperInfo, INOUT ParamVal * pxGetParamVal,
                  IN uint32 iElements, OUT int32 *puiNoInstances)
{
    uint32 i = 0;
    uint32 uiNoEntries=0;
    int32 iParamId = 0;
    uint32 uiParamPos = 0;
    LAN_HOST_INFO xLanHostObj;
    int32 iRet = 0;


    uiParamPos = IFX_GetParamIdPos(pxGetParamVal->iaOID);
    iParamId = pxGetParamVal->iaOID[uiParamPos];

    memset(&xLanHostObj,0x00, sizeof(LAN_HOST_INFO)); 
    uiNoEntries = 0;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s:%d] iParamId = %d pxGetParamVal->iaOID[uiParamPos-1] = %d.\n", __func__, __LINE__, iParamId, pxGetParamVal->iaOID[uiParamPos-1]);
    iRet = IFX_GetHostNoEntries( pxGetParamVal->iaOID[uiParamPos-1],
                            &xLanHostObj, &uiNoEntries);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, 
            "[%s:%d] IFX_GetHostNoEntries failes.\n", __func__, __LINE__);
        goto errorHandler;
    }

    for(i = 0; i < iElements; i++) {

        iParamId = pxGetParamVal->iaOID[uiParamPos];
        pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);

        if(pxGetParamVal->Value == NULL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", _FUNCL_);
            goto errorHandler;
        }
        switch (iParamId) {

            // Convert the value - reverse mapping
            // Assign the correct value to the Value attr 
            case OID_IGD_LAND_H_H_IPADDRESS:
                strncpy((char8 *)pxGetParamVal->Value,
                        inet_ntoa(xLanHostObj.ipAddr), (MAX_IP_ADDRRESS_LEN-1));
                break;

            case OID_IGD_LAND_H_H_ADDRESSSOURCE:
                if(IFX_RevMappingValues(saxLanHostAddrType, 3,
                                        (void *)&(xLanHostObj.ipAddrType),
                                        (void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
                    goto errorHandler;
                break;
            case OID_IGD_LAND_H_H_LEASETIMEREMAINING:
                sprintf(pxGetParamVal->Value,"%d", xLanHostObj.leaseTimeRem);
                break;
            case OID_IGD_LAND_H_H_MACADDRESS:
                strncpy(pxGetParamVal->Value, xLanHostObj.macAddr,
                        (MAX_MAC_ADDRESS_LEN-1));
                break;
             case OID_IGD_LAND_H_H_HOSTNAME:
                 strncpy(pxGetParamVal->Value, xLanHostObj.hostName,
                         (PARAMVALUE_LEN-1));
                break;
             case OID_IGD_LAND_H_H_INTERFACETYPE:
                 if(IFX_RevMappingValues(saxLanHostInterfaceType, 6,
                                         (void *)&(xLanHostObj.phyIfType),
                                         (void *)(pxGetParamVal->Value)) != IFX_CWMP_SUCCESS)
                    goto errorHandler;
                break;
            case OID_IGD_LAND_H_H_ACTIVE:
                if(IFX_RevMappingValues(saxEnable, 2,
                                        (void *)&(xLanHostObj.status),
                                        (void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
                    goto errorHandler;
                break;

            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "Invalid param id %d!\n", iParamId);
                pxGetParamVal->iFaultCode = ERR_INVAL_PARAMETER_VAL;
                break;
        }


        ++pxGetParamVal;
    }

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d %s!\n", __func__, __LINE__, iRet == IFX_CWMP_SUCCESS ?
		"passed" : "failed");
    return iRet;
}


static int32
IFX_HostsGetValue(IN OperInfo * pxOperInfo, INOUT ParamVal * pxGetParamVal,
                  IN uint32 iElements, OUT int32 *puiNoInstances)
{
    uint32 uiNoEntries=0;
    int32 iParamId = 0;
    uint32 uiParamPos = 0;
    LAN_HOST_INFO xLanHostObj;
    int32 iRet = IFX_CWMP_SUCCESS;

    memset(&xLanHostObj, 0x00, sizeof(LAN_HOST_INFO)); 
    uiNoEntries = 0;

    iRet = IFX_GetHostNoEntries(1, &xLanHostObj, &uiNoEntries);
    if (iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, 
            "[%s:%d] IFX_GetHostNoEntries failes.\n", __func__, __LINE__);
        return iRet;
    }

    // Get the dynamic instances
    uiParamPos = IFX_GetParamIdPos(pxGetParamVal->iaOID);
    iParamId = pxGetParamVal->iaOID[uiParamPos];

    switch (pxOperInfo->iSubOper) {
        case OP_GETVAL_INSTANCES:
            *puiNoInstances = uiNoEntries;
            break;
        case OP_GETVAL_NORMAL:
        case OP_GETVAL_NOTIFICATION:
            switch (iParamId) {
                case OID_IGD_LAND_H_HOSTNUMBEROFENTRIES:
                    pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
                    if(pxGetParamVal->Value == NULL) {
                        iRet = IFX_CWMP_FAILURE;
                        break;
                    }
                    sprintf(pxGetParamVal->Value,"%d", uiNoEntries);
                    IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, 
                                             IFX_CHK_CHANGE_FLAG_BASED);
                    break;
                default:
                    iRet = IFX_CWMP_FAILURE;
                    break;
            }
            break;
        default:
            iRet = IFX_CWMP_FAILURE;
            break;
    }

    return iRet;
}


/* 
** =============================================================================
**   Function Name    : IFX_HostsSetAttr
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

int32
IFX_HostsSetAttr(IN OperInfo * pxOpInfo, INOUT ParamVal * pxParamVal,
                 IN int32 iElements)
{
    uint32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    int32 iInst = 0;
    OperInfo xOpInfo;

    xOpInfo.iCaller = pxOpInfo->iCaller;
    xOpInfo.iOper= OP_GETVAL;
    xOpInfo.iSubOper= OP_GETVAL_NORMAL;

    iRet = IFX_HostsGetValue(&xOpInfo, pxParamVal, iElements, &iInst);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d failed!\n", __func__, __LINE__);
        goto errorHandler;
    }

    iRet = IFX_SetAttributesInfo(pxOpInfo, pxParamVal, iElements);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d failed!\n", __func__, __LINE__);
        goto errorHandler;
    }

  errorHandler:
    for(iI = 0; iI < iElements; iI++)
        IFX_CWMP_FREE(pxParamVal[iI].Value);
    return iRet;
}




int32
IFX_Hosts(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                  IN int32 iElements, OUT void **ppaxParamArrRet,
                  OUT int32 * piNumRetElem)
{
	int32 iRet = IFX_CWMP_SUCCESS;
	ParamVal *xpParamVal = (ParamVal *) paxParameterArr;

	switch (pxOperInfo->iOper) {
	case OP_GETVAL:
		iRet = IFX_HostsGetValue(pxOperInfo, 
	          xpParamVal, iElements, piNumRetElem);
		if (iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;
		break;
	case OP_SETVAL:
		switch (pxOperInfo->iSubOper)
		{
			case OP_SETVAL_VALIDATE:
			case OP_SETVAL_ADD:
			case OP_SETVAL_CHK_MODIFY_DEP:
			case OP_SETVAL_MODIFY:
			case OP_SETVAL_COMMIT:
			case OP_SETVAL_UNDO:
			case OP_SETVAL_CHK_DEL_DEP:
			case OP_SETVAL_CHK_DEL_ALLOWED:
			case OP_SETVAL_DELETE:
			case OP_SETVAL_FREE:
				iRet = ERR_CWMP_INVAL_OPER;
				goto errorHandler;
				break;
			case OP_SETVAL_ATTRINFO:
				iRet = IFX_HostsSetAttr(pxOperInfo, xpParamVal, iElements);
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				break;
			default:
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
				            "%s:%d [%d] Error! Default case.\n", _FUNCL_,
			        	    pxOperInfo->iSubOper);
				break;
		}
		break;
	case OP_UPDATE_CHILDINFO:
		break;
	case OP_PARAM_VALIDATE:
		break;
	default:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		            "%s:%d [%d] Error! Default case.\n", _FUNCL_,
		            pxOperInfo->iOper);
		break;
	}
errorHandler:
	return iRet;
}


int32
IFX_Host(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                  IN int32 iElements, OUT void **ppaxParamArrRet,
                  OUT int32 * piNumRetElem)
{
	int32 iRet = IFX_CWMP_SUCCESS;
	ParamVal *pxParamVal = (ParamVal *) paxParameterArr;
	ParamVal    *pxVal;
	uint32 uiParamPos=0;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "Entered IFX_Host [%d :: %d]\n", pxOperInfo->iOper, pxOperInfo->iSubOper);

	switch (pxOperInfo->iOper)
	{
		case OP_GETVAL:
		{
			iRet = IFX_HostGetValue(pxOperInfo, 
			          pxParamVal, iElements, piNumRetElem);
			if (iRet != IFX_CWMP_SUCCESS)
				goto errorHandler;
			break;
		}
		case OP_SETVAL:
		{
			/* Process based on type of SubOperation */
			switch (pxOperInfo->iSubOper)
			{
				case OP_SETVAL_VALIDATE:
				case OP_SETVAL_MODIFY:
				case OP_SETVAL_ACTIVATE:
				case OP_SETVAL_ADD:
				case OP_SETVAL_CHK_MODIFY_DEP:
				case OP_SETVAL_CHK_DEL_ALLOWED :
				case OP_SETVAL_DELETE:
				case OP_SETVAL_ATTRINFO:
				case OP_SETVAL_FREE :
					break;
				case OP_SETVAL_CHK_DEL_DEP:
					pxVal= (void *)IFX_CWMP_MALLOC (sizeof(ParamVal));
					uiParamPos = IFX_GetParamIdPos(pxParamVal->iaOID);
					memcpy(pxVal->iaOID,pxParamVal->iaOID,(sizeof(int32)*(uiParamPos+1)));
					*ppaxParamArrRet = (void*) pxVal;
					*piNumRetElem = 1;
					break;
				default:
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                                "[%s:%d] [Error] Requested SubOperation not"
                		                " permitted on Object\n", __func__, __LINE__);
					iRet = IFX_CWMP_FAILURE;
					goto errorHandler;
			}
			break;
		}
		case OP_PARAM_VALIDATE:
			break;
		default:
		{
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			            "%s:%d [%d] Error! Default case.\n", _FUNCL_, pxOperInfo->iOper);
			break;
		}
	}

errorHandler:
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "IFX_Host returning %d\n", iRet);
	return iRet;

}

static void IFX_HostDeleteAllInstances(void)
{
    char psPartialObj[CWMP_OBJ_NOLEAF_LEN] = { 0 };
    int i = 0;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[DEVM_HOST_OBJ %s:%d] Deleting old entries.\n", __func__, __LINE__);
    for (i = 0; ; i++) {
        sprintf(psPartialObj, "%s%d.",
           "InternetGatewayDevice.LANDevice.1.Hosts.Host.", (i + 1));
        if(ifx_config_del_obj(psPartialObj) != IFX_CWMP_SUCCESS) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d DS delete fail "
                       "%s\n", _FUNCL_, psPartialObj);
	    break;
        }
    }
}

/* 
** =============================================================================
**   Function Name    : IFX_Hosts_Init
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_Hosts_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;


    /* Register the DeviceInfo module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_HOSTS_OBJ, IFX_Hosts);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "Unable to Register %s with Object Model\n",
                    IFX_HOSTS_OBJ);
        goto errorHandler;
    }

   iRet = ifx_ds_register_function(IFX_HOSTS_HOST_OBJ, IFX_Host);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "Unable to Register %s with Object Model\n",
                    IFX_HOSTS_HOST_OBJ);
        goto errorHandler;
    }

    /* Delete all existing instances */
    IFX_HostDeleteAllInstances();

  errorHandler:
    return iRet;
}


int32 IFX_HostHandleDHCPLeaseChange(void)
{
    LAN_HOST_INFO *pxLanHosts = NULL;
    static int32 uiNumOfHostEntries = 0;
    int32 i;
    uint32 uiFlags = IFX_F_GET_ANY;
    int32 iRet = 0;
    char8 ucInterfaceName[MAX_IF_NAME_LEN] = { 0 },
          psPartialObj[CWMP_OBJ_NOLEAF_LEN] = { 0 };
    LAN_HOST_TYPE hType=LAN_HOST_ALL_TYPE;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[DEVM_HOST_OBJ %s:%d] Deleting old entries.\n", __func__, __LINE__);
    for (i = 0; ; i++) {
        sprintf(psPartialObj, "%s%d.",
           "InternetGatewayDevice.LANDevice.1.Hosts.Host.", (i + 1));
        if(ifx_config_del_obj(psPartialObj) != IFX_CWMP_SUCCESS) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d DS delete fail "
                       "%s\n", _FUNCL_, psPartialObj);
            break;
        } else {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d DS deleted "
                       "%s\n", _FUNCL_, psPartialObj);
        }
    }

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[DEVM_HOST_OBJ %s:%d] Getting entries.\n", __func__, __LINE__);
    iRet = ifx_get_lan_hosts(&uiNumOfHostEntries, &pxLanHosts, hType,
            ucInterfaceName, uiFlags);
    if(iRet != IFX_SUCCESS) {
        uiNumOfHostEntries = 0;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
            "%s:%d ifx_get_lan_hosts failed!\n", __func__, __LINE__);
        goto errorHandler;
    }

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[DEVM_HOST_OBJ %s:%d] Adding %d entries.\n", __func__, __LINE__, uiNumOfHostEntries);
    for (i = 0; i < uiNumOfHostEntries; i++) {
        sprintf(psPartialObj, "%s",
           "InternetGatewayDevice.LANDevice.1.Hosts.Host.");
        if((iRet = ifx_config_add_obj(psPartialObj)) != IFX_CWMP_SUCCESS) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Add obj "
                     "to DS fail %s\n", _FUNCL_, iRet, psPartialObj);
            goto errorHandler;
        } else {
	    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Instance added successfully.\n", __func__, __LINE__);
	}
    }
    iRet = IFX_CWMP_SUCCESS;

errorHandler:
    if(pxLanHosts != NULL)
        IFIN_CWMP_FREE(pxLanHosts);
    return iRet;
}


