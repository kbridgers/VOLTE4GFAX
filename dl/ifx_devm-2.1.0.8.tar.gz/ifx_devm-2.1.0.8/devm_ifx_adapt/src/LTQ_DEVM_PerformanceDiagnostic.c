/*
** =============================================================================
** FILE NAME   : LTQ_DEVM_PerformanceDiagnostic.c
** PROJECT     : TR69
** MODULES     : InternetGatewayDevice.Capabilities.PerformanceDiagnostic. 
** DATE        : 02-APR-2013
** AUTHOR      : TR69 team
** DESCRIPTION : AddObject / DeleteObject cannot be performed on this object.
**                   
** REFERENCES  :  
** COPYRIGHT   : Copyright (c) 2006
**               Infineon Technologies AG
**               Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY     : 
** $Date       $Author        $Comment
** 04-Jan-2012 TR69 team      Creation         
** =============================================================================
*/

#include "IFX_DEVM_Global.h"
#include "IFX_DEVM_AdaptCommon.h"
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_StackUtil.h"


extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char *obj, modFunc pifx_module_func);

#define PERFORMDIAG_OBJ                      FORMNAME("Capabilities.PerformanceDiagnostic.")
#define PERFORMDIAG_DEPTH                    4


/*******************************************************************************
* Function: LTQ_PerformDiagSetAttrInfo
* Description: Sets attribute information in the respective tr69 sections
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
LTQ_PerformDiagSetAttrInfo(IN int32 iCaller, INOUT ParamVal * pxPV,
                         IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    iRet = IFX_SetAttributesInfo(NULL, pxPV, iElements);

    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Updating Param Attribute Info failed\n",
                    __func__, __LINE__, iRet);
        goto errorHandler;
    }
  errorHandler:
    return iRet;
}



/*******************************************************************************
 * * Function: LTQ_PerformDiagGetNotifyValue
 * * Desc: 
 * *              
 * * Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
static int32
LTQ_PerformDiagGetNotifyValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                             IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;


    for(iI = 0; iI < iElements; iI++) 
    {
        pxPV[iI].Value = IFX_CWMP_MALLOC(257);
        if(pxPV[iI].Value == NULL) 
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", _FUNCL_);
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (pxPV[iI].iaOID[PERFORMDIAG_DEPTH - 1]) 
        {
            case OID_IGD_C_PD_DOWNLOADTRANSPORTS:
                strcpy(pxPV[iI].Value , "HTTP");
                break;
            case OID_IGD_C_PD_UPLOADTRANSPORTS:
                strcpy(pxPV[iI].Value , "HTTP");
                break;

                iRet = IFX_CheckValueGotChanged(pxOI, pxPV + iI,
                                                IFX_CHK_VALUE_BASED);
                if(iRet != IFX_CWMP_SUCCESS) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Get "
                                "Passive failed\n", __func__, __LINE__, iRet);
                    goto errorHandler;
                }
                break;

            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", _FUNCL_,
                            pxPV[iI].iaOID[PERFORMDIAG_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}


/*******************************************************************************
* Function: IFX_LANDeviceValidate
* Description:
*              
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
LTQ_PerformDiagValidate(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[PERFORMDIAG_DEPTH - 1]) {
            case OID_IGD_C_PD:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            case OID_IGD_C_PD_DOWNLOADTRANSPORTS:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            case OID_IGD_C_PD_UPLOADTRANSPORTS:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", __func__,
                            __LINE__, pxPV[iI].iaOID[PERFORMDIAG_DEPTH - 1]);
                break;
        }
    }
    return iRet;
}




 /*******************************************************************************
 * * Function: LTQ_PerformanceDiagnostic
 * * Desc: 
 * *              
 * * Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
 * *             OUT void **ppRet, OUT int32 * piNumRetElem
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
int32
LTQ_PerformanceDiagnostic(IN OperInfo * pxOI,
                      INOUT void *pParamStruct,
                      IN int32 iElements, OUT void **ppRet,
                      OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;

    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "Entered OP_GETVAL\n");

            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:
                     IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                                    "Entered OP_GETVAL_NOTIFICATION\n");
                    iRet = LTQ_PerformDiagGetNotifyValue(pxOI, xpParamVal,iElements);
                    if(iRet != IFX_CWMP_SUCCESS) 
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d LTQ_PerformDiagGetNotifyValue failed.\n", _FUNCL_);
                        goto errorHandler;
                    }
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                                pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                    if((iRet = LTQ_PerformDiagValidate(xpParamVal, iElements)) != 0)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d LTQ_PerformDiagValidate failed.\n", _FUNCL_);
                        goto errorHandler;
                    }

                break;
                case OP_SETVAL_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                case OP_SETVAL_CHK_MODIFY_DEP:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                break;
                case OP_SETVAL_MODIFY:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                break;
                case OP_SETVAL_ACTIVATE:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                break;
                case OP_SETVAL_COMMIT:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                break;
                case OP_SETVAL_UNDO:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                break;
                case OP_SETVAL_CHK_DEL_DEP:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                break;
                case OP_SETVAL_DELETE:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                break;
                case OP_SETVAL_FREE:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                break;
                case OP_SETVAL_ATTRINFO:
                    iRet = LTQ_PerformDiagSetAttrInfo(pxOI->iCaller, pParamStruct,iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d LTQ_PerformDiagSetAttrInfo failed.\n", _FUNCL_);
                        goto errorHandler;
                    }

                    goto errorHandler;
                break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                                pxOI->iSubOper);
                    break;
            }
            break;
        }

        case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_UPDATE_CHILDINFO_DEL:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break;
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                        pxOI->iOper);
            break;
        }
    }
  errorHandler:
        if (iRet != IFX_CWMP_SUCCESS)
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d %s failed.\n", _FUNCL_, __func__);
    return iRet;
}

/*******************************************************************************
 * * Function: IFX_MemoryStatusInit                                  
 * * Desc: Will register itself with DS.
 * * Parameters:  
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
int32
LTQ_PerformanceDiagnosticInit()
{
    int32 iRet = IFX_CWMP_SUCCESS;

    iRet = ifx_ds_register_function(PERFORMDIAG_OBJ, LTQ_PerformanceDiagnostic);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Unable to Register %s with Object Model\n",
                    _FUNCL_, iRet, PERFORMDIAG_OBJ);
    }

        return iRet;
}
