/*
 * ** =============================================================================
 * ** FILE NAME   : IFX_DEVM_ProcessStatus.c
 * ** PROJECT     : TR157
 * ** MODULES     : (InternetGateway) Device.DeviceInfo.ProcessStatus.
 * ** DATE        :
 * ** AUTHOR      : TR157 team
 * ** DESCRIPTION : AddObject / DeleteObject cannot be performed on this object.
 * **
 * ** REFERENCES  :
 * ** COPYRIGHT   : Copyright (c) 2006
 * **               Infineon Technologies AG
 * **               Am Campeon 1-12, 85579 Neubiberg, Germany
 * **
 * ** Any use of this software is subject to the conclusion of a respective
 * ** License agreement. Without such a License agreement no rights to the
 * ** software are granted
 * **
 * ** HISTORY     :
 * ** $Date       $Author        $Comment
 * **             TR157 team      Creation
 * ** =============================================================================
 * */


#include "IFX_DEVM_Global.h"

#include "IFX_DEVM_AdaptCommon.h"


#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_StackUtil.h"
#include <resolv.h>

extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char *obj, modFunc pifx_module_func);

#define PROCESSSTATUS_OBJ                      FORMNAME("DeviceInfo.ProcessStatus.")
#define PROCESSSTATUS_DEPTH                    4

#define PROCESS_OBJ		               FORMNAME("DeviceInfo.ProcessStatus.Process.1.")




/*
** =============================================================================
**   Function Name    : GetParamOffset
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/

STATIC int32
GetParamOffset(IN int32 *paiOID)
{
    int32 iCnt;

    for (iCnt = 0; paiOID[iCnt] != 0; iCnt++);

    return (iCnt - 1);
}




/*******************************************************************************
 * * Function: IFX_ProcessGetNotifyValue
 * * Desc: 
 * *              
 * * Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
static int32
IFX_ProcessGetNotifyValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                             IN int32 iElements)
{
    uint32 iCpeid = 0 , iCnt;
    PROCESS xProc;
    int32 iRet = IFX_SUCCESS , iParamOffset;

    memset(&xProc, 0x00, sizeof(xProc));
	
    iRet = IFX_GetCpeId(pxPV->iaOID,&iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    {
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d IFX_GetCpeId failed.\n", _FUNCL_);
        goto end;
    }

    xProc.iid.cpeId.Id = iCpeid;

    if((ifx_get_process(&xProc)) != IFX_SUCCESS) 
    {
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d ifx_get_process failed.\n", _FUNCL_);
	iRet = IFX_FAILURE;
	goto end;
    }

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxPV->iaOID);
    if (iParamOffset < 0)
    {
    	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s:%d GetParamOffset returned < 0.\n", _FUNCL_);
        iRet = ERR_CWMP_INTERNAL;
        goto end;
    }
	

    for( iCnt=0; iCnt<iElements; iCnt++)
    {
        // Malloc and assign the pointer to the Value attr of struct
        (pxPV[iCnt]).Value = IFX_CWMP_MALLOC(20);
        if(pxPV[iCnt].Value == NULL)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d MALLOC FAILED.\n", _FUNCL_);
            iRet = ERR_OUT_OF_MEMORY;
            goto end;
        }
        switch(pxPV[iCnt].iaOID[iParamOffset])
        {
		case OID_IGD_DI_PS_P_PID:
			sprintf(pxPV[iCnt].Value , "%u" , xProc.pid);
			break;
		case OID_IGD_DI_PS_P_COMMAND:
        	        IFX_CWMP_FREE((pxPV[iCnt]).Value);
                	(pxPV[iCnt]).Value = IFX_CWMP_MALLOC(128);
                	strcpy(pxPV[iCnt].Value ,  xProc.cmd);
                	break;
		case OID_IGD_DI_PS_P_SIZE:
                	sprintf(pxPV[iCnt].Value , "%u" , xProc.size);
                	break;
		case OID_IGD_DI_PS_P_PRIORITY:
                	sprintf(pxPV[iCnt].Value , "%u" , xProc.priority);
                	break;
		case OID_IGD_DI_PS_P_CPUTIME:
                	sprintf(pxPV[iCnt].Value , "%u" , xProc.cputime);
                	break;
		case OID_IGD_DI_PS_P_STATE:
                	strcpy(pxPV[iCnt].Value , xProc.state);
                	break;
	}
    }

end:
	return iRet;

}



 /*******************************************************************************
 * * Function: IFX_Process
 * * Desc: 
 * *              
 * * Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
 * *             OUT void **ppRet, OUT int32 * piNumRetElem
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
int32
IFX_Process(IN OperInfo * pxOI,
                      INOUT void *pParamStruct,
                      IN int32 iElements, OUT void **ppRet,
                      OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;

    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:

                    iRet = IFX_ProcessGetNotifyValue(pxOI, xpParamVal,
                                                        iElements);
                    if(iRet != IFX_CWMP_SUCCESS) {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d IFX_ProcessStatusGetNotifyValue failed.\n", _FUNCL_);
                        goto errorHandler;
		    }
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                                pxOI->iSubOper);
                    break;
            }
            break;
        }
	case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                case OP_SETVAL_ADD:
                case OP_SETVAL_CHK_MODIFY_DEP:
                case OP_SETVAL_MODIFY:
                case OP_SETVAL_ACTIVATE:
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
	        case OP_SETVAL_DELETE:
                case OP_SETVAL_FREE:
                case OP_SETVAL_ATTRINFO:
	            iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                                pxOI->iSubOper);
                    break;
            }
            break;
        }
	case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                case OP_UPDATE_CHILDINFO_DEL:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break;
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                        pxOI->iOper);
            break;
        }
    }
  errorHandler:
	if (iRet != IFX_CWMP_SUCCESS)
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d %s failed.\n", _FUNCL_, __func__);
    return iRet;
}





     





/*******************************************************************************
 * * Function: IFX_ProcessStatusGetNotifyValue
 * * Desc: 
 * *              
 * * Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
static int32
IFX_ProcessStatusGetNotifyValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                             IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    PROCESSSTATUS xProcStat;

    memset(&xProcStat, '\0', sizeof(xProcStat));

    iRet = ifx_get_processstatus(&xProcStat);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_processstatus() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
    for(iI = 0; iI < iElements; iI++) {
        pxPV[iI].Value = IFX_CWMP_MALLOC(257);
        if(pxPV[iI].Value == NULL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", _FUNCL_);
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (pxPV[iI].iaOID[PROCESSSTATUS_DEPTH - 1]) {
            case OID_IGD_DI_PS_CPUUSAGE:
                sprintf(pxPV[iI].Value , "%u" , xProcStat.cpu_usage);
                break;
            case OID_IGD_DI_PS_PROCESSNUMBEROFENTRIES:
                sprintf(pxPV[iI].Value , "%u" , xProcStat.process_num_entries);
                break;
	    default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", _FUNCL_,
                            pxPV[iI].iaOID[PROCESSSTATUS_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}



 /*******************************************************************************
 * * Function: IFX_ProcessStatus
 * * Desc: 
 * *              
 * * Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
 * *             OUT void **ppRet, OUT int32 * piNumRetElem
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
int32
IFX_ProcessStatus(IN OperInfo * pxOI,
                      INOUT void *pParamStruct,
                      IN int32 iElements, OUT void **ppRet,
                      OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;

    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:

                    iRet = IFX_ProcessStatusGetNotifyValue(pxOI, xpParamVal,
                                                        iElements);
                    if(iRet != IFX_CWMP_SUCCESS) {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d IFX_ProcessStatusGetNotifyValue failed.\n", _FUNCL_);
                        goto errorHandler;
                    }
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                                pxOI->iSubOper);
                    break;
            }
            break;
        }
	case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                case OP_SETVAL_ADD:
                case OP_SETVAL_CHK_MODIFY_DEP:
                case OP_SETVAL_MODIFY:
                case OP_SETVAL_ACTIVATE:
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
		case OP_SETVAL_DELETE:
                case OP_SETVAL_FREE:
                case OP_SETVAL_ATTRINFO:
		    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                                pxOI->iSubOper);
                    break;
            }
            break;
        }
	case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                case OP_UPDATE_CHILDINFO_DEL:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break;
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                        pxOI->iOper);
            break;
        }
    }
  errorHandler:
	if (iRet != IFX_CWMP_SUCCESS)
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d %s failed.\n", _FUNCL_, __func__);
    return iRet;
}


/*******************************************************************************
 * * Function: IFX_ProcessStatusInit                                  
 * * Desc: Will register itself with DS.
 * * Parameters:  
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
int32
IFX_ProcessStatusInit()
{
    int32 iRet = IFX_CWMP_SUCCESS;

    
    iRet = ifx_ds_register_function(PROCESSSTATUS_OBJ, IFX_ProcessStatus);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Unable to Register %s with Object Model\n",
                    _FUNCL_, iRet, PROCESSSTATUS_OBJ);
	goto errorHandler;
    }   

    iRet = ifx_ds_register_function(PROCESS_OBJ, IFX_Process);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Unable to Register %s with Object Model\n",
                    _FUNCL_, iRet, PROCESS_OBJ);
    }


errorHandler:
        
    return iRet;
}







