
#include "IFX_DEVM_CommonDefs.h"
#include "IFX_DEVM_SIPErrors.h"
 
#include "IFX_DEVM_List.h"
#include "IFX_DEVM_SIPMemInterface.h"
#include "IFX_DEVM_SIPUtilityFns.h"
#include "IFX_DEVM_SIPUri.h"
#include "ctype.h"
#include <string.h>

/***********************************************************
******************* LIST APIs ****************************
***********************************************************/
#ifndef __IFX_LIST_H__
#define __IFX_LIST_H__
typedef struct x_ifx_list
{ 
   struct x_ifx_list *pxNext;
   struct x_ifx_list *pxPrev;
}x_ifx_list;


/* Initlize the header */
static inline void __ifx_list_init(
                x_ifx_list *pxHeadptr)
{
    (pxHeadptr)->pxNext = NULL; 
    (pxHeadptr)->pxPrev = NULL;
}
/* Insert a new entry between 2 nodes*/
static inline void __ifx_list_add(
                        x_ifx_list *pxNewNode,
                        x_ifx_list *pxPrevNode,
                        x_ifx_list  *pxNextNode)
{
   pxNewNode->pxPrev = pxPrevNode;
   pxNewNode->pxNext = pxPrevNode->pxNext;
   pxPrevNode->pxNext = pxNewNode;
   if ( pxNextNode != NULL)
   pxNextNode->pxPrev = pxNewNode;
}


/* Insert the node at the front */
static inline void __ifx_list_add_front(
                void **ppxHeadptr,
                void **ppxNodeptr,
                int32 iSize,
                int32 *puiErrorCode)
{ 
  *puiErrorCode = -1;
 *ppxNodeptr = IFX_SIP_Malloc(sizeof(x_ifx_list) + iSize); 
  if (*ppxNodeptr == NULL)
  {
    *puiErrorCode = -1;
  }
  else
  {
    if ( *ppxHeadptr == NULL)
    {
       *ppxHeadptr =(x_ifx_list *)*ppxNodeptr;
       __ifx_list_init(*ppxHeadptr);
       *ppxHeadptr += sizeof(x_ifx_list);
    }
    else
    {
       x_ifx_list *pxHeadptr = (x_ifx_list *)(*ppxHeadptr-sizeof(x_ifx_list));
       __ifx_list_add((x_ifx_list *)*ppxNodeptr,pxHeadptr,(pxHeadptr)->pxNext);
     }
     *ppxNodeptr += sizeof(x_ifx_list);
     *puiErrorCode = 0;
  }
}
/* Insert the node at the end */
static inline void __ifx_list_add_to_tail(
                void **ppxHeadptr,
                void **ppxNodeptr,
                int32 iSize,
                int32 *puiErrorCode)
{ 
  *puiErrorCode = -1;
  *ppxNodeptr = IFX_SIP_Malloc(sizeof(x_ifx_list) + iSize); 
  if (*ppxNodeptr == NULL)
  {
    *puiErrorCode = -1;
  }
  else
  {
    if ( *ppxHeadptr == NULL)
    {
       *ppxHeadptr =(x_ifx_list *)*ppxNodeptr;
       __ifx_list_init(*ppxHeadptr);
       /* Making it circular*/
       ((x_ifx_list *)*ppxHeadptr)->pxPrev = *ppxHeadptr;
       *ppxHeadptr += sizeof(x_ifx_list);
    }
    else
    {
       x_ifx_list *pxHeadptr = (x_ifx_list *)(*ppxHeadptr-sizeof(x_ifx_list));
       __ifx_list_add((x_ifx_list *)*ppxNodeptr,pxHeadptr->pxPrev,(pxHeadptr->pxPrev)->pxNext);
       pxHeadptr->pxPrev = *ppxNodeptr;
     }
     *ppxNodeptr += sizeof(x_ifx_list);
     *puiErrorCode = 0;
  }
}
/* Get Next node */
static inline void __ifx_list_GetNext(void **ppxNodeptr)
{
   x_ifx_list *pxNode = (*ppxNodeptr - sizeof(x_ifx_list));
   pxNode = pxNode->pxNext;
   if ( pxNode != NULL)
   {
     *ppxNodeptr = ((void *)pxNode + sizeof(x_ifx_list));
   }
   else
   {
      *ppxNodeptr = NULL;
   }
}

/* Get Prev node */
static inline void __ifx_list_GetPrev(void **ppxNodeptr)
{
   x_ifx_list *pxNode = (*ppxNodeptr - sizeof(x_ifx_list));
   pxNode = pxNode->pxPrev;
   if ( pxNode != NULL)
   {
     *ppxNodeptr = ((void *)pxNode + sizeof(x_ifx_list));
   }
   else
   {
      *ppxNodeptr = NULL;
   }
}


/* Delete Node */
static inline void  __ifx_list_del(void **ppxHeadptr,void *pxNodeptr)
{
  x_ifx_list *pxNode = (x_ifx_list *)(pxNodeptr - sizeof(x_ifx_list));
  x_ifx_list *pxTemp1 = (x_ifx_list *)(*ppxHeadptr - sizeof(x_ifx_list));
  x_ifx_list *pxTemp2 = NULL;
  if (*ppxHeadptr == pxNodeptr)
  {
    if ( pxNode->pxNext == NULL)
    {
       *ppxHeadptr = NULL;  
    }
    else
    {    
       *ppxHeadptr = ((void *)(pxNode->pxNext))+ sizeof(x_ifx_list);
       pxTemp2 = (x_ifx_list *)(*ppxHeadptr - sizeof(x_ifx_list));
       pxTemp2->pxPrev = pxTemp1->pxPrev;
    }
  }else {
  if (pxNode->pxNext != NULL)
  {
    (pxNode->pxNext)->pxPrev = pxNode->pxPrev;
  }
  else{
    pxTemp1->pxPrev = pxNode->pxPrev;
  }
  
  if (pxNode->pxPrev != NULL)
  {
    (pxNode->pxPrev)->pxNext = pxNode->pxNext;
}  }
  IFX_SIP_Free(pxNode);
}
static inline void  __ifx_list_move_front_updateTail(void **ppxHeadptr,void *pxNodeptr)
{
  x_ifx_list *pxNode = (x_ifx_list *)(pxNodeptr - sizeof(x_ifx_list));
  x_ifx_list *pxFirstNode = (x_ifx_list *)(*ppxHeadptr - sizeof(x_ifx_list));
  if (*ppxHeadptr == pxNodeptr)
  {
     pxNode->pxPrev = pxNode;
     return;
  }
  else
  {
     if(pxNode->pxNext != NULL){
       (pxNode->pxNext)->pxPrev = pxFirstNode;
       pxFirstNode->pxNext = pxNode->pxNext;
     }
     pxNode->pxPrev =pxFirstNode->pxPrev;
     pxFirstNode->pxPrev = pxNode;
     *ppxHeadptr = ((void *)(pxNode))+ sizeof(x_ifx_list);
  }
}
static inline void __ifx_list_del_tail(void **ppxHeadptr)
{
  x_ifx_list *pxFirstNode = (x_ifx_list *)(*ppxHeadptr - sizeof(x_ifx_list));
  __ifx_list_del(ppxHeadptr,((void *)(pxFirstNode->pxPrev))+ sizeof(x_ifx_list));      
}
#endif
/***********************************************************
******************* LIST APIs ****************************
***********************************************************/
char8 vtblszUriParams[IFX_SIP_URI][15] =
{
  "transport=", "user=", "method=", "ttl=", "maddr=", "comp="
};

/******************************************************************
*  Function Name:  IFX_SIP_strchr
*  Description  :  checks for a delimiter and returns ptr to first occurance
*  Input Values :  Two strings and the number of bytes to compare
*  Output Values:  None
*  Return Value :  0 on success
*  Notes        :  
*********************************************************************/

char8*
IFX_SIP_strchr(IN  char8* pcStartIndex,
                IN  char8* pcEndIndex,
                IN  int32 ifind)
{
  char8 cTemp, * pcCurrPos;
  cTemp = *pcEndIndex;
  *pcEndIndex = '\0';
  pcCurrPos = strchr(pcStartIndex,ifind);
  *pcEndIndex = cTemp;
  return pcCurrPos;
}
/******************************************************************
*  Function Name:  IFX_SIP_strtok
*  Description  :  Checks for occurance of any of the tokens in the 
*                  token list, and returns the same on finding. 
*  Input Values :  Start and end indices, tokens to check out for
*  Output Values:  Matched location
*  Return Value :  Matched Token/IFX_SIP_TOKEN_NOTFOUND
*  Notes        :  This function checks for the presence of the tokens
*                  on matching returns the token matched 
*********************************************************************/

char8
IFX_SIP_strtok(IN  char8* pcStartIndex,
                IN  char8* pcEndIndex,
                OUT char8** pcMatchedLoc,
                IN  const char* tok)
{
  uint32 i;
  char8* pcCurrPos; 
  pcCurrPos = pcStartIndex;
  while(pcCurrPos < pcEndIndex)
  {
    for(i = 0; i < strlen(tok); i++)
    {
      if(*pcCurrPos == tok[i])
      {
        *pcMatchedLoc = pcCurrPos;
        return tok[i];
      }
    }
    pcCurrPos++;
  }
  return IFX_SIP_TOKEN_NOTFOUND;
}
/******************************************************************
*  Function Name:  IFX_SIP_ValidateHeaderName
*  Description  :  Checks if it is a valid Header Name
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateHeaderName(char8* pszBuff)
{
  uint32 i;
  for(i = 0; i < strlen(pszBuff); i++){
    if(pszBuff[i] == '/' ||
       pszBuff[i] == '[' ||
       pszBuff[i] == ']' ||
       pszBuff[i] == '?' ||
       pszBuff[i] == ':' ||
       pszBuff[i] == '+' ||
       pszBuff[i] == '$' ||
       isalnum(pszBuff[i]) ||
       pszBuff[i] == '-' ||
       pszBuff[i] == '.' ||
       pszBuff[i] == '_' ||
       pszBuff[i] == '!' ||
       pszBuff[i] == '~' ||
       pszBuff[i] == '*' ||
       pszBuff[i] == '`' ||
       pszBuff[i] == '(' ||
       pszBuff[i] == ')' ||
       pszBuff[i] == '%'){
      continue;
    }
  }
  if(i != strlen(pszBuff)){
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_ValidateParamChar
*  Description  :  Checks if it is a valid Param char
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateParamChar(char8* pszBuff)
{
  uint32 i = 0;
  while(i < strlen(pszBuff)){
    if((isalnum(pszBuff[i])) ||
       (pszBuff[i] == ']') ||
       (pszBuff[i] == '/') ||
       (pszBuff[i] == '?') ||
       (pszBuff[i] == ':') ||
       (pszBuff[i] == '+') ||
       (pszBuff[i] == '$') ||
       (pszBuff[i] == '[') ||
       (pszBuff[i] == '-') ||
       (pszBuff[i] == '_') ||
       (pszBuff[i] == '.') ||
       (pszBuff[i] == '!') ||
       (pszBuff[i] == '~') ||
       (pszBuff[i] == '*') ||
       (pszBuff[i] == '\'') ||
       (pszBuff[i] == '(') ||
       (pszBuff[i] == ')') ||
       (pszBuff[i] == '%')){
      if(pszBuff[i] == '%'){
        if(((i + 3) < strlen(pszBuff)) &&
           ((isdigit(pszBuff[i + 1])) ||
            (pszBuff[i + 1] >= 0x61 && pszBuff[i + 1] <= 0x66) ||
            (pszBuff[i + 1] >= 0x41 && pszBuff[i + 1] <= 0x46)) &&
           ((isdigit(pszBuff[i + 2])) ||
            (pszBuff[i + 2] > 0x61 && pszBuff[i + 2] < 0x66) ||
            (pszBuff[i + 2] >= 0x41 && pszBuff[i + 2] <= 0x46))){
          i += 3;
          continue;
        }
        else{
          break;
        }
      }
      i++;
      continue;
    }
    else{
      break;
    }
  }
  if(i != strlen(pszBuff)){
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_ValidateToken
*  Description  :  Checks if it is a valid token
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateToken(char8* pszBuff)
{
  uint32 i;
  for(i = 0; i < strlen(pszBuff); i++)
  {
    if(isalnum(pszBuff[i]) ||
       pszBuff[i] == '-' ||
       pszBuff[i] == '.' ||
       pszBuff[i] == '!' ||
       pszBuff[i] == '%' ||
       pszBuff[i] == '*' ||
       pszBuff[i] == '_' ||
       pszBuff[i] == '+' ||
       pszBuff[i] == '\'' ||
       pszBuff[i] == '`' ||
       pszBuff[i] == '~'){
      continue;
    }
    else
    {
      break;
    }
  }
  if(i != strlen(pszBuff))
  {
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_ValidateIPv4Addr
*  Description  :  Validate Ipv4 address
*  Input Values :  character string
*  Output Values:  -
*  Return Value :  Success or failure of validation
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateIPv4Addr(char8* pszBuff)
{
  uint32 iCount = 0, iDotCount = 0;
  char8 acTemp[4];
  while(*pszBuff != '\0'){
    if(*pszBuff == '.'){
      iDotCount++;
      acTemp[iCount] = '\0';
      if((iCount > 0) && (atoi(acTemp) < 256)){
        memset(acTemp,'\0',4);
        iCount = 0;
        pszBuff++;
      }
      else{
        return IFX_SIP_FAILURE;
      }
    }
    else{
      if(!isdigit(*pszBuff)){
        return IFX_SIP_FAILURE;
      }
      acTemp[iCount++] = *pszBuff;
      pszBuff++;
      if(iCount > 3){
        return IFX_SIP_FAILURE;
      }
    }
  }
  if(iCount<1 || atoi(acTemp)> 256 || iDotCount > 3){
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_ValidateIPv6Addr
*  Description  :  Validate Ipv6 address
*  Input Values :  character string
*  Output Values:  -
*  Return Value :  Success or failure of validation
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateIPv6Addr(char8* pszBuff)
{
  /*TBF: Code to be added */
  int32 iDoubleColonFlag = 0, iHexCount=0, iTemp;
  uint32 i = 1;
  if((pszBuff[0] != '[') || (pszBuff[strlen(pszBuff) - 1] != ']')){
    return IFX_SIP_FAILURE;
  }
  pszBuff[strlen(pszBuff) - 1] = '\0';

  while(i < strlen(pszBuff)){
    if(isdigit(pszBuff[i]) ||
       (pszBuff[i] >= 0x41 && pszBuff[i] <= 0x46) ||
       (pszBuff[i] >= 0x61 && pszBuff[i] <= 0x66)){
      i++;
      iHexCount++;
      if(iHexCount > 4){
        return IFX_SIP_FAILURE;
      }
      continue;
    }
    else if(pszBuff[i] == ':'){
      if((i + 1) < strlen(pszBuff) && pszBuff[i + 1] == ':'){
        iDoubleColonFlag++;
        if(iDoubleColonFlag > 1){
          return IFX_SIP_FAILURE;
        }
        iHexCount = 0;
        i += 2;
        continue;
      }
      iHexCount = 0;
      i++;
      continue;
    }
    else if(pszBuff[i] == '.'){
      while(pszBuff[i - 1] != ':'){
        i--;
      }
      if(IFX_SIP_ValidateIPv4Addr(&pszBuff[i]) == IFX_SIP_SUCCESS){
        iTemp = strlen(pszBuff);
        pszBuff[iTemp] = ']';
        pszBuff[iTemp + 1] = '\0';
        return IFX_SIP_SUCCESS;
      }
      else{
        return IFX_SIP_FAILURE;
      }
    }
    else{
      break;
    }
  }
  if(i != strlen(pszBuff)){
    return IFX_SIP_FAILURE;
  }

  iTemp = strlen(pszBuff);
  pszBuff[iTemp] = ']';
  pszBuff[iTemp + 1] = '\0';

  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_ValidateHostName
*  Description  :  Identifies the hostname
*  Input Values :  char buffer
*  Output Values:  None
*  Return Value :  Success or failure of validation
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateHostName(char8* pszBuff)
{
  char8* pcTempStart, * pcTempEnd, * pLastdot = NULL;
  pcTempStart = pszBuff;
  pcTempEnd = pszBuff + strlen(pszBuff);
  if(isalnum(*pcTempStart)){
    pcTempStart++;
    do{
      if(isalnum(*pcTempStart) || (*pcTempStart == '-')){
        pcTempStart++;
        continue;
      }
      else if(*pcTempStart == '.'){
        pLastdot = pcTempStart;
        if(!isalnum(*(pcTempStart - 1))){
          return IFX_SIP_FAILURE;
        }
        pcTempStart++;
        if(pcTempStart > pcTempEnd){
          return IFX_SIP_FAILURE;
        }
        if(!isalnum(*pcTempStart)){
          return IFX_SIP_FAILURE;
        }
        pcTempStart++;
      }
      else{
        return IFX_SIP_FAILURE;
      }
    }
    while(pcTempStart < pcTempEnd);
    if((pLastdot != NULL) && (!(isalpha(*(pLastdot + 1))))){
      return IFX_SIP_FAILURE;
    }
  }
  else{
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_IdentifyType
*  Description  :  Identifies the host type
*  Input Values :  char buffer
*  Output Values:  None
*  Return Value :  Host Type
*  Notes        : 
*********************************************************************/
e_IFX_SIP_HostType
IFX_SIP_IdentifyType(char8* pszBuff)
{
  uint32 i;
  e_IFX_SIP_HostType e_Type = IFX_SIP_HOSTINVALID; 
  for(i = 0; i < strlen(pszBuff); i++){
    if((pszBuff[i] > 47 && pszBuff[i] < 58) || (pszBuff[i] == '.')){
      continue;
    }
    else{
      break;
    }
  }
  if(i == strlen(pszBuff)){
    e_Type = IFX_SIP_IPV4ADDR;
    if(IFX_SIP_ValidateIPv4Addr(pszBuff) == IFX_SIP_FAILURE){
      e_Type = IFX_SIP_HOSTINVALID;
    }
  }
  else{
    e_Type = IFX_SIP_HOSTNAME;
  }
  if(strchr(pszBuff,'[') != NULL){
    e_Type = IFX_SIP_IPV6REF;
    /* Validate IPv6 address */
    if(IFX_SIP_ValidateIPv6Addr(pszBuff) == IFX_SIP_FAILURE){
      e_Type = IFX_SIP_HOSTINVALID;
    }
  }
  if(e_Type == IFX_SIP_HOSTNAME){
    if(IFX_SIP_ValidateHostName(pszBuff) == IFX_SIP_FAILURE){
      e_Type = IFX_SIP_HOSTINVALID;
    }
  }
  return e_Type;
}
/******************************************************************
*  Function Name:  IFX_SIP_ValidatePassword
*  Description  :  Checks if it is a valid Password
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidatePassword(char8* pszBuff)
{
  uint32 i = 0;
  while(i < strlen(pszBuff)){
    if((isalnum(pszBuff[i])) ||
       (pszBuff[i] == '-') ||
       (pszBuff[i] == '_') ||
       (pszBuff[i] == '.') ||
       (pszBuff[i] == '!') ||
       (pszBuff[i] == '~') ||
       (pszBuff[i] == '*') ||
       (pszBuff[i] == '\'') ||
       (pszBuff[i] == '(') ||
       (pszBuff[i] == ')') ||
       (pszBuff[i] == '%') ||
       (pszBuff[i] == '&') ||
       (pszBuff[i] == '=') ||
       (pszBuff[i] == '+') ||
       (pszBuff[i] == '$') ||
       (pszBuff[i] == ',')){
      if(pszBuff[i] == '%'){
        if(((i + 3) < strlen(pszBuff)) &&
           ((isdigit(pszBuff[i + 1])) ||
            (pszBuff[i + 1] >= 0x61 && pszBuff[i + 1] <= 0x66) ||
            (pszBuff[i + 1] >= 0x41 && pszBuff[i + 1] <= 0x46)) &&
           ((isdigit(pszBuff[i + 2])) ||
            (pszBuff[i + 2] > 0x61 && pszBuff[i + 2] < 0x66) ||
            (pszBuff[i + 2] >= 0x41 && pszBuff[i + 2] <= 0x46))){
          i += 3;
          continue;
        }
        else{
          break;
        }
      }
      i++;
      continue;
    }
    else{
      break;
    }
  }
  if(i != strlen(pszBuff)){
    return IFX_SIP_FAILURE;
  }

  return IFX_SIP_SUCCESS;
}


/******************************************************************
*  Function Name:  IFX_SIP_DecodeHeaders
*  Description  :  Decodes the Headers information in URI
*  Input Values :  Start and End indices to Headers
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeHeaders(IN  char8* pcStartIndex,
                      IN  char8* pcEndIndex,
                      OUT x_IFX_SIP_Header** ppxHeadPtr,
                      OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcCurrPos, * pcTempStart, cRet;
  int32 bHeadersPresent = 1, iErrCode;
  x_IFX_SIP_Header  *pxHdr=NULL;

    pcTempStart = pcStartIndex;

  /* No Spaces allowed after ? so dont remove white spaces */

  do{
      __ifx_list_add_to_tail((void*)ppxHeadPtr, (void*) &pxHdr,
                             sizeof(x_IFX_SIP_Header), &iErrCode);
      if(iErrCode < 0)
        {
         pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
         strcpy(pxSipError->szErrorDesc,"OutOfMem");
         return IFX_SIP_FAILURE;
       } 
      /* Check for the delimiters */
    cRet = IFX_SIP_strtok(pcTempStart,pcEndIndex,&pcCurrPos,"&=");
    if(cRet == '&')
    {
      /* Only header name present and no header value */
      if( (pcCurrPos - pcTempStart) <= 0 )
      {
         pxSipError->eDecodeErr = IFX_SIP_HEADERINFO_INVALID;
         strcpy(pxSipError->szErrorDesc,"InvalidHeaderInfo");
         bHeadersPresent = 0;
         return IFX_SIP_FAILURE;
      }
      /*Copy Header Value Name the structure */
      pxHdr->pcToken = (char8*)IFX_SIP_Malloc(pcCurrPos -pcTempStart+1);
      if(pxHdr->pcToken == NULL)
      {
       pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
       strcpy(pxSipError->szErrorDesc,"OutOfMem");
       return IFX_SIP_FAILURE;
      }      
      strncpy(pxHdr->pcToken,pcTempStart,(pcCurrPos - pcTempStart));
      pxHdr->pcToken[(pcCurrPos - pcTempStart)] = '\0';
      
      if(IFX_SIP_ValidateHeaderName(pxHdr->pcToken) == IFX_SIP_FAILURE)
      {
        pxSipError->eDecodeErr = IFX_SIP_HEADERINFO_INVALID;
        strcpy(pxSipError->szErrorDesc,"Header name invalid");
        return IFX_SIP_FAILURE;
      }
      pcTempStart = pcCurrPos + 1;/* As it points to & */
    }
    else if(cRet == '=')
    {
      if((pcCurrPos - pcTempStart) <= 0)
      {
        pxSipError->eDecodeErr = IFX_SIP_HEADERINFO_INVALID;
        strcpy(pxSipError->szErrorDesc,"HeaderInfoInvalid");
        return IFX_SIP_FAILURE;
      }
      /*Copy Header Name into the structure*/
      pxHdr->pcToken =(char8*) IFX_SIP_Malloc((pcCurrPos -pcTempStart+1));      
      if(pxHdr->pcToken == NULL)
      {
       pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
       strcpy(pxSipError->szErrorDesc,"OutOfMem");
       return IFX_SIP_FAILURE;
      }
      strncpy(pxHdr->pcToken, pcTempStart, (pcCurrPos - pcTempStart));
      pxHdr->pcToken[(pcCurrPos - pcTempStart)] = '\0';
      
      if(IFX_SIP_ValidateHeaderName(pxHdr->pcToken) == IFX_SIP_FAILURE)
      {
        pxSipError->eDecodeErr = IFX_SIP_HEADERINFO_INVALID;
        strcpy(pxSipError->szErrorDesc,"Header name invalid");
        return IFX_SIP_FAILURE;
      }
      pcTempStart = pcCurrPos + 1; /* As it is pointing to = */     
      pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'&');
      
      if(pcCurrPos == NULL)
      {
        /* Last header info in the list */
        if( (pcEndIndex - pcTempStart) <= 0 )
        {
          pxSipError->eDecodeErr = IFX_SIP_HDR_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Header name in SIP URI exceeded");
          return IFX_SIP_FAILURE;
        }
       
        pxHdr->pcValue = (char8*)IFX_SIP_Malloc((pcEndIndex -pcTempStart+1));      
        if(pxHdr->pcValue == NULL)
        {
          pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
          strcpy(pxSipError->szErrorDesc,"OutOfMem");
          return IFX_SIP_FAILURE;
        }      
        strncpy(pxHdr->pcValue, pcTempStart,(pcEndIndex - pcTempStart));
        pxHdr->pcValue[(pcEndIndex - pcTempStart)] = '\0';
      
        if(IFX_SIP_ValidateHeaderName(pxHdr->pcValue) == IFX_SIP_FAILURE)
        {
          pxSipError->eDecodeErr = IFX_SIP_HEADERINFO_INVALID;
          strcpy(pxSipError->szErrorDesc,"Header name invalid");
          return IFX_SIP_FAILURE;
        }
        bHeadersPresent = 0;
      }
      else
      {
        if((pcCurrPos - pcTempStart) <= 0)
        {
          pxSipError->eDecodeErr = IFX_SIP_HDR_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Header name in SIP URI exceeded");
          return IFX_SIP_FAILURE;
        }
        pxHdr->pcValue = (char8*)IFX_SIP_Malloc((pcCurrPos -pcTempStart+1));      
        if(pxHdr->pcValue == NULL)
        {
         pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
         strcpy(pxSipError->szErrorDesc,"OutOfMem");
         return IFX_SIP_FAILURE;
        }      
        strncpy(pxHdr->pcValue, pcTempStart,(pcCurrPos- pcTempStart));
        pxHdr->pcValue[(pcCurrPos - pcTempStart)] = '\0';
      
        if(IFX_SIP_ValidateHeaderName(pxHdr->pcValue) == IFX_SIP_FAILURE)
        {
          pxSipError->eDecodeErr = IFX_SIP_HEADERINFO_INVALID;
          strcpy(pxSipError->szErrorDesc,"Header name invalid");
          return IFX_SIP_FAILURE;
       }
        
       pcTempStart = pcCurrPos + 1;/* As it is pointing to & */
      }
    }
    else if(cRet == IFX_SIP_TOKEN_NOTFOUND)
    {
      /* Only the Header name is present */
      if((pcEndIndex - pcTempStart) >= 0)
       {
        pxSipError->eDecodeErr = IFX_SIP_HDR_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Header name in SIP URI exceeded");
        return IFX_SIP_FAILURE;
       }

      pxHdr->pcToken = (char8*)IFX_SIP_Malloc((pcEndIndex -pcTempStart+1));      
      if(pxHdr->pcToken == NULL)
      {
       pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
       strcpy(pxSipError->szErrorDesc,"OutOfMem");
       return IFX_SIP_FAILURE;
      }
      strncpy(pxHdr->pcToken, pcTempStart, (pcEndIndex - pcTempStart));
      pxHdr->pcToken[(pcEndIndex - pcTempStart)] = '\0';
      
      if(IFX_SIP_ValidateHeaderName(pxHdr->pcToken) == IFX_SIP_FAILURE)
      {
        pxSipError->eDecodeErr = IFX_SIP_HEADERINFO_INVALID;
        strcpy(pxSipError->szErrorDesc,"Header name invalid");
        IFX_SIP_Free(pxHdr->pcToken);
        return IFX_SIP_FAILURE;
      }
      bHeadersPresent = 0;
    }
  }
  while(bHeadersPresent);
  IFX_SIP_Free(pxHdr->pcToken); 
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeURIParams
*  Description  :  Decodes the URI parameters
*  Input Values :  Start and End indices of To parameters
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/

e_IFX_SIP_Return
IFX_SIP_DecodeURIParams(IN  char8* pcStartIndex,
                        IN  char8* pcEndIndex,
                        OUT x_IFX_SIP_SipUri* pxSipUri,                         
                        OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcCurrPos, * pcTempStart, cRet, *pcTempEnd;
  int32 i, flag = 1,iErrCode;
  x_IFX_SIP_UriParam **ppxHeadPtr= &pxSipUri->pxUriParam, *pxUri=NULL;
  pcTempStart = pcCurrPos = pcStartIndex; 
  /* No leading spaces allowed after ; */ 
  do{
      __ifx_list_add_to_tail((void*)ppxHeadPtr, (void*) &pxUri,
                             sizeof(x_IFX_SIP_UriParam), &iErrCode);
      if(iErrCode < 0)
        {
         pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
         strcpy(pxSipError->szErrorDesc,"OutOfMem");
         return IFX_SIP_FAILURE;
       } 
    cRet = IFX_SIP_strtok(pcTempStart,pcEndIndex,&pcCurrPos,"=;");
    switch(cRet){
      case '=':
        for(i = 0; i < IFX_SIP_URI; i++){
          if(strncmp(pcTempStart,
                     vtblszUriParams[i],
                     IFX_SIP_MAX(strlen(vtblszUriParams[i]),
                                  (uint32) (pcCurrPos - pcTempStart))) ==
             0){
            break;
          }
        }
        if(i == IFX_SIP_URI)
        {
          pxUri->eUriParamType = IFX_SIP_OTHER_PARAM;
          if((pcCurrPos - pcTempStart) <= 0)
          {
            pxSipError->eDecodeErr = IFX_SIP_OTHERPARM_EXCEEDED;
            strcpy(pxSipError->szErrorDesc,
                   "URI other parameter exceeded the limit");
            return IFX_SIP_FAILURE;
          }         
          /*Malloc for OtherParam*/
          pxUri->uxUriParamType.pcUriParam = (char8*)IFX_SIP_Malloc((pcCurrPos-pcTempStart+1));
          if(pxUri->uxUriParamType.pcUriParam == NULL)
          {
            pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
            strcpy(pxSipError->szErrorDesc,"OutOfMem");
            return IFX_SIP_FAILURE;
          }      

          strncpy(pxUri->uxUriParamType.pcUriParam, pcTempStart,
                  (pcCurrPos - pcTempStart));
          pxUri->uxUriParamType.pcUriParam[(pcCurrPos - pcTempStart)] = '\0';
          
          if(IFX_SIP_ValidateParamChar(pxUri->uxUriParamType.pcUriParam) == IFX_SIP_FAILURE)
          {
            pxSipError->eDecodeErr = IFX_SIP_INVALID_PARAMCHAR;
            strcpy(pxSipError->szErrorDesc,"Invalid Param Char");
            IFX_SIP_Free(pxUri->uxUriParamType.pcUriParam);
            return IFX_SIP_FAILURE;
          }
        }
        pcTempStart = pcCurrPos + 1;/* As it is pointing to = */
        pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
        if(pcCurrPos == NULL){
          flag = 0;
          pcTempEnd = pcEndIndex;
        }
        else{
          pcTempEnd = pcCurrPos;/*pcEndIndex-1;*/
        }
        /* No white spaces allowed after ; */
        switch(i + 1){
          case IFX_SIP_TRANSP_PARAM:
            {
              pxUri->eUriParamType = IFX_SIP_TRANSP_PARAM;
              if((pcTempEnd - pcTempStart) <= 0 )
              {
                pxSipError->eDecodeErr = IFX_SIP_OTHERPARM_EXCEEDED;
                strcpy(pxSipError->szErrorDesc,"Invaild Transport param");
                return IFX_SIP_FAILURE;
              }              
              /*Malloc for the UriParam*/
              pxUri->uxUriParamType.pcUriParam=(char8*)IFX_SIP_Malloc(pcTempEnd-pcTempStart+1);               
              if(pxUri->uxUriParamType.pcUriParam == NULL)
              {
                pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
                strcpy(pxSipError->szErrorDesc,"OutOfMem");
                return IFX_SIP_FAILURE;
               }
              strncpy( pxUri->uxUriParamType.pcUriParam,
                       pcTempStart,
                       pcTempEnd-pcTempStart);              
               pxUri->uxUriParamType.pcUriParam[pcTempEnd-pcTempStart]='\0';                      
               /* Validating the Token */
               if(IFX_SIP_ValidateToken(pxUri->uxUriParamType.pcUriParam)
                                        == IFX_SIP_FAILURE)
               {
                  pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
                  strcpy(pxSipError->szErrorDesc,
                         "Invalid Token other Transport");
                  IFX_SIP_Free(pxUri->uxUriParamType.pcUriParam);
                  return IFX_SIP_FAILURE;
               }
              
            }
            break;

          case IFX_SIP_USER_PARAM:
            {
              pxUri->eUriParamType = IFX_SIP_USER_PARAM;              
              if((pcTempEnd - pcTempStart) <= 0)
              {
                pxSipError->eDecodeErr = IFX_SIP_OTHERPARM_EXCEEDED;
                strcpy(pxSipError->szErrorDesc,
                       "Invalid User Param");
                return IFX_SIP_FAILURE;
              }              
              /*Malloc for the UriParam*/
              pxUri->uxUriParamType.pcUriParam = (char8*)IFX_SIP_Malloc
                                                 (pcTempEnd-pcTempStart+1);                                                                 
              if(pxUri->uxUriParamType.pcUriParam == NULL)
              {
               pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
               strcpy(pxSipError->szErrorDesc,"OutOfMem");
               return IFX_SIP_FAILURE;
              }

              strncpy(pxUri->uxUriParamType.pcUriParam,
                     pcTempStart,
                     pcTempEnd - pcTempStart);
              pxUri->uxUriParamType.pcUriParam[pcTempEnd - pcTempStart]='\0';                            
     
       /*Changes required to copy tele name in SipUri--->UserInfo-->UserName;*/         
           
             if(IFX_SIP_ValidateToken(pxUri->uxUriParamType.pcUriParam) == IFX_SIP_FAILURE)
             {
              pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
              strcpy(pxSipError->szErrorDesc,"Invalid Token Other User");
              IFX_SIP_Free(pxUri->uxUriParamType.pcUriParam);
              return IFX_SIP_FAILURE;
             }
             
            }
            break;
            
          
          case IFX_SIP_METHOD_PARAM:            
           { 
            int32 iCount=0;
            iCount = pcTempEnd - pcStartIndex;
            pxUri->eUriParamType = IFX_SIP_METHOD_PARAM;                       
            
            if((pcTempEnd - pcTempStart) <= 0 )
            {
             pxSipError->eDecodeErr = IFX_SIP_METHOD_EXCEEDED;
             strcpy(pxSipError->szErrorDesc,"Extension Method Invalid");
             return IFX_SIP_FAILURE;
            }

            pxUri->uxUriParamType.pcUriParam = 
                   (char8*)IFX_SIP_Malloc((pcTempEnd-pcTempStart+1));
            if(pxUri->uxUriParamType.pcUriParam == NULL)
            {
             pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
             strcpy(pxSipError->szErrorDesc,"OutOfMem");
             return IFX_SIP_FAILURE;
            }       
            strncpy(pxUri->uxUriParamType.pcUriParam, 
                    pcTempStart,(pcTempEnd-pcTempStart));
            pxUri->uxUriParamType.pcUriParam[pcTempEnd-pcTempStart] = '\0'; 
            
                   /* Validate if extension method */
            
            if(IFX_SIP_ValidateToken(pxUri->uxUriParamType.pcUriParam) == IFX_SIP_FAILURE)
            {
             pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
             strcpy(pxSipError->szErrorDesc,"Invalid extension Method");
             IFX_SIP_Free(pxUri->uxUriParamType.pcUriParam);
             return IFX_SIP_FAILURE;        
            }
          }
            break;
            
          case IFX_SIP_TTL_PARAM:
           {
            char8 acTemp[4];
            pxUri->eUriParamType=IFX_SIP_TTL_PARAM;
            for(i = 0; (pcTempStart + i) < pcTempEnd; i++)
            {
              if(*(pcTempStart + i) == ' ' || *(pcTempStart + i) == '\t')
              {
                break;
              }
            }
            
            if((i > 3) || (i <= 0))
            {
              pxSipError->eDecodeErr = IFX_SIP_TTLPARM_EXCEEDED;
              strcpy(pxSipError->szErrorDesc,
                     "TTL parameter exceeded the limit");
              return IFX_SIP_FAILURE;
            }
            strncpy(acTemp,pcTempStart,i);
            acTemp[i] = '\0';
            pxUri->uxUriParamType.ucTTL = atoi(acTemp);            
          }
          break;
            
          case IFX_SIP_MADDR_PARAM:
            pxUri->eUriParamType = IFX_SIP_MADDR_PARAM;
            
            if((pcTempEnd - pcTempStart) <= 0)
            {
              pxSipError->eDecodeErr = IFX_SIP_HOSTNAME_EXCEEDED;
              strcpy(pxSipError->szErrorDesc,"Host name exceeded the limit");
              return IFX_SIP_FAILURE;
            }
            
            pxUri->uxUriParamType.pcUriParam =(char8*)IFX_SIP_Malloc(
                                              (pcTempEnd-pcTempStart+1));
            if(pxUri->uxUriParamType.pcUriParam == NULL)
            {
             pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
             strcpy(pxSipError->szErrorDesc,"OutOfMem");
             return IFX_SIP_FAILURE;
            }
            
            strncpy(pxUri->uxUriParamType.pcUriParam, pcTempStart, 
                    (pcTempEnd - pcTempStart));
            pxUri->uxUriParamType.pcUriParam[(pcTempEnd - pcTempStart)] = '\0';
            
            if(IFX_SIP_IdentifyType(pxUri->uxUriParamType.pcUriParam) 
                                    == IFX_SIP_HOSTINVALID)
            {
              pxSipError->eDecodeErr = IFX_SIP_INVALID_HOSTINFO;
              strcpy(pxSipError->szErrorDesc,"Invalid Host Info");
              IFX_SIP_Free(pxUri->uxUriParamType.pcUriParam);
              return IFX_SIP_FAILURE;
            }
            break;
           
           #ifdef RFC_3486
           case IFX_SIP_COMP_PARAM:
           {           
             pxUri->eUriParamType = IFX_SIP_COMP_PARAM;

            if((pcTempEnd - pcTempStart) <= 0) 
             {
              pxSipError->eDecodeErr = IFX_SIP_HOSTNAME_EXCEEDED;
              strcpy(pxSipError->szErrorDesc,"Compression Parameter exceeded the limit");
              return IFX_SIP_FAILURE;
             }
            
            pxUri->uxUriParamType.pcUriParam =IFX_SIP_Malloc(
                                              (pcTempEnd-pcTempStart+1));
            if(pxUri->uxUriParam.pcUriParam == NULL)
            {
             pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
             strcpy(pxSipError->szErrorDesc,"OutOfMem");
             return IFX_SIP_FAILURE;
            }
            strncpy(pxUri->uxUriParamType.pcCompression,pcTempStart,
                    (pcTempEnd - pcTempStart));

            pxUri->uxUriParamType.pcUriParam[(pcTempEnd - pcTempStart)]= '\0';
            
           }
           break;
           #endif /*RFC_3486*/
          default:
            {
              char8 *pcTemp;
              
              if(pcTempEnd-pcTempStart <= 0)
              {
                pxSipError->eDecodeErr = IFX_SIP_OTHERPARM_EXCEEDED;
                strcpy(pxSipError->szErrorDesc,"Erro in Other Param");
                IFX_SIP_Free(pxUri->uxUriParamType.pcUriParam);               
                return IFX_SIP_FAILURE;
              }
              
              pcTemp = (char8*)IFX_SIP_Malloc(
                       IFX_SIP_MAX(strlen(pxUri->uxUriParamType.pcUriParam)+2,
                                   pcTempEnd-pcTempStart+1));
              if(pcTemp==NULL)                      
              {
               pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
               strcpy(pxSipError->szErrorDesc,"OutOfMem");
               IFX_SIP_Free(pxUri->uxUriParamType.pcUriParam);
               return IFX_SIP_FAILURE;
              }
              
              strcpy(pcTemp,pxUri->uxUriParamType.pcUriParam);              
              strcat(pcTemp,"=");              
              IFX_SIP_Free(pxUri->uxUriParamType.pcUriParam);                            
              
              pxUri->uxUriParamType.pcUriParam= (char8*)IFX_SIP_Malloc(pcTempEnd-
                                                pcTempStart+1 +strlen(pcTemp));              
              if(pxUri->uxUriParamType.pcUriParam == NULL)
              {
               pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
               strcpy(pxSipError->szErrorDesc,"OutOfMem");
               IFX_SIP_Free(pcTemp);
               return IFX_SIP_FAILURE;
              }
              
             strcpy (pxUri->uxUriParamType.pcUriParam,pcTemp); 
             
             /*Validate other param's value*/
             strncpy(pcTemp, pcTempStart, pcTempEnd-pcTempStart);
             pcTemp[pcTempEnd-pcTempStart]='\0';
             if(IFX_SIP_ValidateParamChar(pcTemp)==IFX_SIP_FAILURE)
             {
               pxSipError->eDecodeErr = IFX_SIP_INVALID_PARAMCHAR;
               strcpy(pxSipError->szErrorDesc,"Invalid Param Char");
               IFX_SIP_Free(pcTemp);
               IFX_SIP_Free(pxUri->uxUriParamType.pcUriParam);
               return IFX_SIP_FAILURE;
             } 
             strcat(pxUri->uxUriParamType.pcUriParam,pcTemp); 
             IFX_SIP_Free(pcTemp);          
              
            }
            break;
        }
        if(flag != 0){
          pcTempStart = pcCurrPos + 1;
        }
        break;
      
      case ';':
      case IFX_SIP_TOKEN_NOTFOUND:
        if(cRet == IFX_SIP_TOKEN_NOTFOUND)
        {
          pcCurrPos = pcEndIndex;
        }
        if(strncmp(pcTempStart,"lr",strlen("lr")) == 0)
        {
          pxUri->eUriParamType = IFX_SIP_LR_PARAM;
        }
        else
        {
          /* other parameter with pname only*/
          pxUri->eUriParamType = IFX_SIP_OTHER_PARAM;
          if((pcCurrPos - pcTempStart) <= 0)
          {
           pxSipError->eDecodeErr = IFX_SIP_OTHERPARM_EXCEEDED;
           strcpy(pxSipError->szErrorDesc,
                   "Other param below/beyond the limit");
           return IFX_SIP_FAILURE;
          }
          pxUri->uxUriParamType.pcUriParam=  
             (char8*)IFX_SIP_Malloc((pcCurrPos-pcTempStart+1));                            
              if(pxUri->uxUriParamType.pcUriParam == NULL)
              {
               pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
               strcpy(pxSipError->szErrorDesc,"OutOfMem");
               return IFX_SIP_FAILURE;
              }
          
          strncpy(pxUri->uxUriParamType.pcUriParam, pcTempStart,
                  (pcCurrPos - pcTempStart) );          
          pxUri->uxUriParamType.pcUriParam[(pcCurrPos - pcTempStart)] = '\0';
          
          if(IFX_SIP_ValidateParamChar(pxUri->uxUriParamType.pcUriParam) 
                                      == IFX_SIP_FAILURE)
          {
            pxSipError->eDecodeErr = IFX_SIP_INVALID_PARAMCHAR;
            strcpy(pxSipError->szErrorDesc,"Invalid Param Char");
            IFX_SIP_Free(pxUri->uxUriParamType.pcUriParam);
            return IFX_SIP_FAILURE;
          }
        }
        if(cRet == IFX_SIP_TOKEN_NOTFOUND)
        {
          flag = 0;
        }
        else
        {
          pcTempStart = pcCurrPos + 1;
        }
      break;
    }
    
  }
  while(flag);
  IFX_SIP_Free(pxUri->uxUriParamType.pcUriParam);
  return IFX_SIP_SUCCESS;


}
/******************************************************************
*  Function Name:  IFX_SIP_DecodeHostPort
*  Description  :  Decodes the HostPort information
*  Input Values :  Start and End indices to Host Port
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeHostPort(IN  char8* pcStartIndex,
                       IN  char8* pcEndIndex,
                       OUT x_IFX_SIP_HostPort* pxHostPort,
                       OUT x_IFX_SIP_Error* pxSipError)
{
  char* pcTempStart, * pcTempEnd, * pcCurrPos, * pcTemp = NULL;
  char cRet;
  uint32 i, iflag = 0;

  /* copy pcStartIndex and pcEndIndex into temporary pointers */
  pcTempStart = pcStartIndex;
  pcTempEnd = pcEndIndex;
  pcCurrPos = pcTempStart;

  do{
    cRet = IFX_SIP_strtok(pcTempStart,pcEndIndex,&pcCurrPos,"[:");
    if(cRet == '['){
      if(iflag != 1){
        pcTemp = pcTempStart;
      }
      pcTempStart = pcCurrPos + 1;
      pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,']'); 
      if(pcCurrPos == NULL){
        return IFX_SIP_FAILURE;
      }
      else{
        pcTempStart = pcCurrPos + 1;
      }
      iflag = 1;
    }
    else if(cRet == ':'){
      pcTempEnd = pcCurrPos;
      break;
    }
    else{
      pcTempEnd = pcEndIndex;
      pcCurrPos = NULL;
      break;
    }
  }
  while(1);
  if(iflag == 1){
    pcTempStart = pcTemp;
    iflag = 0;
  }

  /* Copy the host information */
  if((pcTempEnd - pcTempStart) <= 0 )
  {
    pxSipError->eDecodeErr = IFX_SIP_HOSTNAME_EXCEEDED;
    strcpy(pxSipError->szErrorDesc,"Host name exceeded the limit");
    return IFX_SIP_FAILURE;
  }
  
  pxHostPort->pcHostInfo =  (char8*)IFX_SIP_Malloc((pcTempEnd-pcTempStart+1));
  if(pxHostPort->pcHostInfo == NULL)
    {
     pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
     strcpy(pxSipError->szErrorDesc,"OutOfMemeory");
     return IFX_SIP_FAILURE;
    }
  
  strncpy(pxHostPort->pcHostInfo,pcTempStart,(pcTempEnd - pcTempStart));
  pxHostPort->pcHostInfo[(pcTempEnd - pcTempStart)] = '\0';

  /* Validation of Host Info */
  if( IFX_SIP_IdentifyType(pxHostPort->pcHostInfo) == IFX_SIP_HOSTINVALID)
   {
    pxSipError->eDecodeErr = IFX_SIP_INVALID_HOSTINFO;
    strcpy(pxSipError->szErrorDesc,"Invalid Host Info");
    return IFX_SIP_FAILURE;
   }


  if(pcCurrPos != NULL)
  {
    /* port is present */
    char8 szPort[6];

    /* Handling the port information */
    pcCurrPos++;/* As it is pointing to : */
    if(((pcEndIndex - pcCurrPos) > 5 /*max is int 16bit*/) ||
       ((pcEndIndex - pcCurrPos) <= 0))
    {
      pxSipError->eDecodeErr = IFX_SIP_HOSTPORT_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Host port exceeded the num digits");
      return IFX_SIP_FAILURE;
    }
    
    strncpy(szPort,pcCurrPos,(pcEndIndex - pcCurrPos));
    szPort[(pcEndIndex - pcCurrPos)] = '\0';

    for(i = 0; i < strlen(szPort); i++)
    {
      if(!isdigit(szPort[i]))
      {
        pxSipError->eDecodeErr = IFX_SIP_INVALID_DIGIT;
        strcpy(pxSipError->szErrorDesc,"Port Info Invalid");
        return IFX_SIP_FAILURE;
      }
    }

    pxHostPort->unPort = atoi(szPort);
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeSipUri
*  Description  :  Decodes the SIP URI
*  Input Values :  Start and End indices to SIP URI
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeSipUri(IN  char8* pcStartIndex,
                      IN  char8* pcEndIndex,
                      OUT x_IFX_SIP_SipUri* pxSipUri,
                      OUT x_IFX_SIP_Error* pxSipError)
{
  char* pcTempStart, * pcTempEnd, * pcCurrPos, * pcTemp;
  char cRet;
  /* copy pcStartIndex and pcEndIndex into temporary pointers */
  pcTempStart = pcStartIndex;
  pcTempEnd = pcEndIndex;
  pcCurrPos = pcTempStart;
  cRet = IFX_SIP_strtok(pcTempStart,pcTempEnd,&pcCurrPos,":@");
  switch(cRet){
    case ':':
      /* Either port or password are present in the URI */
      pcTemp = pcTempStart;
      pcTempStart = pcCurrPos;
      cRet = IFX_SIP_strtok(pcTempStart,pcTempEnd,&pcCurrPos,"@;?");
      if(cRet == '@')
      {
        /* Presence of Password */
        /* Copy the User */
        if( (pcTempStart - pcTemp) <= 0)
        {
          pxSipError->eDecodeErr = IFX_SIP_USERINFO_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"User Info exceeded the limit");
          return IFX_SIP_FAILURE;
        }
        
        pxSipUri->xUserInfo.pcUserInfo = (char8*)IFX_SIP_Malloc(
                                         (pcTempStart-pcTemp+1));
        if(pxSipUri->xUserInfo.pcUserInfo==NULL)
          {
           pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
           strcpy(pxSipError->szErrorDesc,"OutOfMemory");
           return IFX_SIP_FAILURE;      
          }
         
        strncpy(pxSipUri->xUserInfo.pcUserInfo, pcTemp, (pcTempStart - pcTemp));
         pxSipUri->xUserInfo.pcUserInfo[(pcTempStart - pcTemp)] = '\0';
        /* Copying the password */
         
        if( (pcTempStart - pcTemp) <= 0)
        {
          pxSipError->eDecodeErr = IFX_SIP_USERINFO_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"User Info exceeded the limit");
          return IFX_SIP_FAILURE;
        }
        
        pxSipUri->xUserInfo.pcPassword = (char8*)IFX_SIP_Malloc(
                                         (pcCurrPos - pcTempStart + 2));
        if(pxSipUri->xUserInfo.pcPassword==NULL)
          {
           return IFX_SIP_FAILURE;      

          }

        strncpy(pxSipUri->xUserInfo.pcPassword, pcTempStart + 1,
                (pcCurrPos - (pcTempStart + 1)));
        pxSipUri->xUserInfo.pcPassword[(pcCurrPos - (pcTempStart + 1))] = '\0';
        /* TBF: Validate Password */
        if(IFX_SIP_ValidatePassword(pxSipUri->xUserInfo.pcPassword) == IFX_SIP_FAILURE)
        {
          pxSipError->eDecodeErr = IFX_SIP_INVALID_PASSWD;
          strcpy(pxSipError->szErrorDesc,"Invalid Password");
          return IFX_SIP_FAILURE;
        }
        
        pcCurrPos++;/* As it is pointing to @ */        
        pcTempStart = pcCurrPos;
        
        /* Copying the Host and port information */ 
        
        cRet = IFX_SIP_strtok(pcTempStart,pcTempEnd,&pcCurrPos,";?");
        if(cRet == '?')
        {
          if(IFX_SIP_DecodeHostPort(pcTempStart,pcCurrPos,&pxSipUri->
          xHostPort,pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
          pcTempStart = pcCurrPos + 1;
          if(IFX_SIP_DecodeHeaders(pcTempStart,pcTempEnd,&pxSipUri->
          pxHeaders,pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
        }
        else if(cRet == ';')
        {
          if(IFX_SIP_DecodeHostPort(pcTempStart,pcCurrPos,&pxSipUri->
          xHostPort,pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
          pcTempStart = pcCurrPos + 1;
          pcCurrPos = IFX_SIP_strchr(pcTempStart,pcTempEnd,'?');
          if(pcCurrPos == NULL){
            /* only some URI parameters are present */
            if(IFX_SIP_DecodeURIParams(pcTempStart,
                                        pcTempEnd,
                                        pxSipUri,
                                        pxSipError) == IFX_SIP_FAILURE){
              return IFX_SIP_FAILURE;
            }
          }
          else{
            /* Both URI and Header parameters present */
            if(IFX_SIP_DecodeURIParams(pcTempStart,
                                        pcCurrPos,
                                        pxSipUri,
                                        pxSipError) == IFX_SIP_FAILURE){
              return IFX_SIP_FAILURE;
            }
            if(IFX_SIP_DecodeHeaders((pcCurrPos + 1),pcTempEnd,&pxSipUri
            ->pxHeaders,pxSipError) == IFX_SIP_FAILURE){
              return IFX_SIP_FAILURE;
            }
          }
        }
        else if(cRet == IFX_SIP_TOKEN_NOTFOUND){
          /* Only host port info present */
          if(IFX_SIP_DecodeHostPort(pcTempStart,pcTempEnd,&pxSipUri->
          xHostPort,pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
        }
      }
      else if(cRet == '?'){
        /* Presence of port,No URI parameters present, Headers are present */
        IFX_SIP_DecodeHostPort(pcTemp,
                                pcCurrPos,
                                &pxSipUri->xHostPort,
                                pxSipError);
        pcTempStart = pcCurrPos + 1; /* As it is pointing to ? */
        /* call decoder of headers */
        if(IFX_SIP_DecodeHeaders(pcTempStart,pcTempEnd,&pxSipUri->
        pxHeaders,pxSipError) == IFX_SIP_FAILURE){
          return IFX_SIP_FAILURE;
        }
      }
      else if(cRet == ';'){
        /* Presence of port, URI parameters present */
        IFX_SIP_DecodeHostPort(pcTemp,
                                pcCurrPos,
                                &pxSipUri->xHostPort,
                                pxSipError);
        pcTempStart = pcCurrPos + 1; /* As it is pointing to ; */
        /* Check for the presence of ? */
        pcCurrPos = IFX_SIP_strchr(pcTempStart,pcTempEnd,'?');
        if(pcCurrPos == NULL){
          /* only some URI parameters are present */
          if(IFX_SIP_DecodeURIParams(pcTempStart,
                                      pcTempEnd,
                                      pxSipUri,
                                      pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
        }
        else{
          /* Both URI and Header parameters present */
          if(IFX_SIP_DecodeURIParams(pcTempStart,
                                      pcCurrPos,
                                      pxSipUri,
                                      pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
          if(IFX_SIP_DecodeHeaders((pcCurrPos + 1),pcTempEnd,&pxSipUri->
          pxHeaders,pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
        }
      }
      else
      {
        char8 acPort[5];
        /* Presence of port along with host info */
        if((pcTempStart - pcTemp) <= 0)
        {
          pxSipError->eDecodeErr = IFX_SIP_HOSTNAME_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Host info exceeded the limit");
          return IFX_SIP_FAILURE;
        }
        
        pxSipUri->xHostPort.pcHostInfo = 
        (char8*)IFX_SIP_Malloc((pcTempStart-pcTemp+1));
        
        if(pxSipUri->xHostPort.pcHostInfo == NULL)
        {
         pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
         strcpy(pxSipError->szErrorDesc,"OutOfMem");
         return IFX_SIP_FAILURE;
        } 
        
        strncpy(pxSipUri->xHostPort.pcHostInfo, pcTemp,
                (pcTempStart - pcTemp)); 
        pxSipUri->xHostPort.pcHostInfo[(pcTempStart - pcTemp)] = '\0';
        
        /* Validation of Host Info */
        if (IFX_SIP_IdentifyType (pxSipUri->xHostPort.pcHostInfo) 
                                 == IFX_SIP_HOSTINVALID)
        {
          pxSipError->eDecodeErr = IFX_SIP_INVALID_HOSTINFO;
          strcpy(pxSipError->szErrorDesc,"Invalid Host Info");
          return IFX_SIP_FAILURE;
        }
        pcTempStart++; /* As it is pointing to : */
        if(((pcTempEnd - pcTempStart) > 5 /*max is int 16*/) ||
           ((pcTempEnd - pcTempStart) <= 0))
        {
          pxSipError->eDecodeErr = IFX_SIP_HOSTPORT_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Host port exceeded the num digits");
          return IFX_SIP_FAILURE;
        }
        strncpy(acPort,pcTempStart,(pcTempEnd - pcTempStart)); 
        acPort[(pcTempEnd - pcTempStart)] = '\0';
        pxSipUri->xHostPort.unPort = atoi(acPort);
      }   
      break;
    case '@':
            /* presence of user part*/
      if((pcCurrPos - pcTempStart) < 0 ){
        pxSipError->eDecodeErr = IFX_SIP_USERINFO_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"User Info exceeded the limit");
        return IFX_SIP_FAILURE;
      }
      else if((pcCurrPos - pcTempStart) == 0){
        pxSipError->eDecodeErr = IFX_SIP_USERINFO_ABSENT;
        strcpy(pxSipError->szErrorDesc,"User Info Absent");
        return IFX_SIP_FAILURE;
      }

      pxSipUri->xUserInfo.pcUserInfo=(char8*)IFX_SIP_Malloc((pcCurrPos-pcTempStart+1));                                                    
      if(pxSipUri->xUserInfo.pcUserInfo==NULL)
      {
       pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
       strcpy(pxSipError->szErrorDesc,"OutOfMemory");
       return IFX_SIP_FAILURE;      
      }
 
      strncpy(pxSipUri->xUserInfo.pcUserInfo, pcTempStart,
              (pcCurrPos - pcTempStart));
      pxSipUri->xUserInfo.pcUserInfo[(pcCurrPos - pcTempStart)] = '\0';
      pcCurrPos++;/* As it is pointing to @ */
      pcTempStart = pcCurrPos;
      cRet = IFX_SIP_strtok(pcTempStart,pcTempEnd,&pcCurrPos,";?");
      if(cRet == '?'){
        if(IFX_SIP_DecodeHostPort(pcTempStart,
                                   pcCurrPos,
                                   &pxSipUri->xHostPort,
                                   pxSipError) == IFX_SIP_FAILURE){
          return IFX_SIP_FAILURE;
        }
        pcTempStart = pcCurrPos + 1;
        if(IFX_SIP_DecodeHeaders(pcTempStart,
                                  pcTempEnd,
                                  &pxSipUri->pxHeaders,
                                  pxSipError) == IFX_SIP_FAILURE){
          return IFX_SIP_FAILURE;
        }
      }
      else if(cRet == ';'){
        if(IFX_SIP_DecodeHostPort(pcTempStart,
                                   pcCurrPos,
                                   &pxSipUri->xHostPort,
                                   pxSipError) == IFX_SIP_FAILURE){
          return IFX_SIP_FAILURE;
        }
        pcTempStart = pcCurrPos + 1;
        pcCurrPos = IFX_SIP_strchr(pcTempStart,pcTempEnd,'?');
        if(pcCurrPos == NULL){
          /* only some URI parameters are present */
          if(IFX_SIP_DecodeURIParams(pcTempStart,
                                      pcTempEnd,
                                      pxSipUri,
                                      pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
        }
        else{
          /* Both URI and Header parameters present */
          if(IFX_SIP_DecodeURIParams(pcTempStart,
                                      pcCurrPos,
                                      pxSipUri,
                                      pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
          if(IFX_SIP_DecodeHeaders((pcCurrPos + 1),
                                    pcTempEnd,
                                    &pxSipUri->pxHeaders,
                                    pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
        }
      }
      else if(cRet == IFX_SIP_TOKEN_NOTFOUND){
        /* Only host port info present */
        if(IFX_SIP_DecodeHostPort(pcTempStart,
                                   pcTempEnd,
                                   &pxSipUri->xHostPort,
                                   pxSipError) == IFX_SIP_FAILURE){
          return IFX_SIP_FAILURE;
        }
      }
      break;
    case IFX_SIP_TOKEN_NOTFOUND:
      /* No user part and only the host part is present */
      /* Uri Params and Headers could be present */
      pxSipUri->xHostPort.unPort = 0;
      cRet = IFX_SIP_strtok(pcTempStart,pcTempEnd,&pcCurrPos,";?");
      if(cRet == '?')
      {
        if((pcCurrPos - pcTempStart) <= 0)
        {
          pxSipError->eDecodeErr = IFX_SIP_HOSTNAME_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Host Name exceeded the limit");
          return IFX_SIP_FAILURE;
        }
       
        pxSipUri->xHostPort.pcHostInfo = 
        (char8*)IFX_SIP_Malloc((pcCurrPos-pcTempStart+1));
        
        if(pxSipUri->xHostPort.pcHostInfo == NULL)
        {
         pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
         strcpy(pxSipError->szErrorDesc,"OutOfMem");
         return IFX_SIP_FAILURE;
        }
        
        strncpy(pxSipUri->xHostPort.pcHostInfo, pcTempStart,
                (pcCurrPos - pcTempStart));
        
        pxSipUri->xHostPort.pcHostInfo[(pcCurrPos - pcTempStart)] = '\0';
        /* Validate Host Info */
        if(IFX_SIP_IdentifyType(pxSipUri->xHostPort.pcHostInfo) 
                               == IFX_SIP_HOSTINVALID)
        {
          pxSipError->eDecodeErr = IFX_SIP_INVALID_HOSTINFO;
          strcpy(pxSipError->szErrorDesc,"Invalid Host Info");
          return IFX_SIP_FAILURE;
        }

        pcTempStart = pcCurrPos + 1;
        if(IFX_SIP_DecodeHeaders(pcTempStart,
                                  pcTempEnd,
                                  &pxSipUri->pxHeaders,
                                  pxSipError) == IFX_SIP_FAILURE){
          strcpy(pxSipError->szErrorDesc,"Decode headers failed");
          return IFX_SIP_FAILURE;
        }
      }
      else if(cRet == ';'){
        if((pcCurrPos - pcTempStart) <= 0)
        {
          pxSipError->eDecodeErr = IFX_SIP_HOSTNAME_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Host Name exceeded the limit");
          return IFX_SIP_FAILURE;
        }
        
        pxSipUri->xHostPort.pcHostInfo = 
        (char8*)IFX_SIP_Malloc((pcCurrPos-pcTempStart+1));
        
        if(pxSipUri->xHostPort.pcHostInfo == NULL)
        {
         pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
         strcpy(pxSipError->szErrorDesc,"OutOfMem");
         return IFX_SIP_FAILURE;
        }
        
        strncpy(pxSipUri->xHostPort.pcHostInfo, pcTempStart,
                (pcCurrPos - pcTempStart));
        
        pxSipUri->xHostPort.pcHostInfo[(pcCurrPos - pcTempStart)] = '\0';
        /* Validate Host Info */
        if(IFX_SIP_IdentifyType(pxSipUri->xHostPort.pcHostInfo) 
                               == IFX_SIP_HOSTINVALID)
        {
          pxSipError->eDecodeErr = IFX_SIP_INVALID_HOSTINFO;
          strcpy(pxSipError->szErrorDesc,"Invalid Host Info");
          return IFX_SIP_FAILURE;
        }

        pcTempStart = pcCurrPos + 1;
        pcCurrPos = IFX_SIP_strchr(pcTempStart,pcTempEnd,'?');
        if(pcCurrPos == NULL){
          /* only some URI parameters are present */
          if(IFX_SIP_DecodeURIParams(pcTempStart,
                                      pcTempEnd,
                                      pxSipUri,
                                      pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
        }
        else{
          /* Both URI and Header parameters present */
          if(IFX_SIP_DecodeURIParams(pcTempStart,
                                      pcCurrPos,
                                      pxSipUri,
                                      pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
          if(IFX_SIP_DecodeHeaders((pcCurrPos + 1),
                                    pcTempEnd,
                                    &pxSipUri->pxHeaders,
                                    pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
        }
      }
      else if(cRet == IFX_SIP_TOKEN_NOTFOUND){
        if((pcTempEnd - pcTempStart) <= 0)
        {
          pxSipError->eDecodeErr = IFX_SIP_HOSTNAME_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Host Name exceeded the limit");
          return IFX_SIP_FAILURE;
        }
        
        pxSipUri->xHostPort.pcHostInfo = 
        (char8*)IFX_SIP_Malloc( (pcTempEnd - pcTempStart+1));
        
        if(pxSipUri->xHostPort.pcHostInfo == NULL)
        {
         pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
         strcpy(pxSipError->szErrorDesc,"OutOfMem");
         return IFX_SIP_FAILURE;
        }
        
        strncpy(pxSipUri->xHostPort.pcHostInfo, pcTempStart,
                (pcTempEnd - pcTempStart));
        
        pxSipUri->xHostPort.pcHostInfo[(pcTempEnd - pcTempStart)] = '\0';
        /* Validate Host Info */
        if(IFX_SIP_IdentifyType(pxSipUri->xHostPort.pcHostInfo) 
                               == IFX_SIP_HOSTINVALID)
        {
          pxSipError->eDecodeErr = IFX_SIP_INVALID_HOSTINFO;
          strcpy(pxSipError->szErrorDesc,"Invalid Host Info");
          return IFX_SIP_FAILURE;
        }
      }
      break;
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name  :  IFX_SIP_FreeSipUri
*  Description    :  this function frees all the allocated memory
*                    withing the sip data structure
*  Input Values   :  void
*  Output Values  :  void
*  Return Value   :  void
*  Notes      : 
*********************************************************************/
void 
IFX_SIP_FreeSipUri(IN uint32 uiSipUri)
{
 x_IFX_SIP_SipUri *pxSipUri = (x_IFX_SIP_SipUri *) uiSipUri;
 
 if(pxSipUri==NULL)
    return;
 if(pxSipUri->xUserInfo.pcUserInfo != NULL) 
 {
  IFX_SIP_Free(pxSipUri->xUserInfo.pcUserInfo);
  pxSipUri->xUserInfo.pcUserInfo = NULL;
 }
 
 if(pxSipUri->xUserInfo.pcPassword != NULL) 
 {
  IFX_SIP_Free(pxSipUri->xUserInfo.pcPassword);
  pxSipUri->xUserInfo.pcPassword = NULL;
 }
 
 if(pxSipUri->xHostPort.pcHostInfo != NULL) 
 {
  IFX_SIP_Free(pxSipUri->xHostPort.pcHostInfo);
  pxSipUri->xHostPort.pcHostInfo = NULL;
 }  
 pxSipUri->xHostPort.unPort = 0;
 
 while(pxSipUri->pxUriParam!=NULL)
 {
  switch(pxSipUri->pxUriParam->eUriParamType)
  {
   case IFX_SIP_TRANSP_PARAM:
   case IFX_SIP_USER_PARAM:
   case IFX_SIP_METHOD_PARAM:
#ifdef RFC_3486
   case IFX_SIP_COMP_PARAM:
#endif /*RFC_3486*/     
   case IFX_SIP_OTHER_PARAM:
   case IFX_SIP_MADDR_PARAM:
        if(pxSipUri->pxUriParam->uxUriParamType.pcUriParam !=NULL)
        {
         IFX_SIP_Free(pxSipUri->pxUriParam->uxUriParamType.pcUriParam);
         pxSipUri->pxUriParam->uxUriParamType.pcUriParam =NULL;
        }
        break;  
   default:
        break;
  }
  
  __ifx_list_del((void*)&pxSipUri->pxUriParam,
                 (void*) pxSipUri->pxUriParam); 
 }

 while(pxSipUri->pxHeaders!=NULL)
 {
  if(pxSipUri->pxHeaders->pcToken !=NULL)
  {
    IFX_SIP_Free(pxSipUri->pxHeaders->pcToken);
    pxSipUri->pxHeaders->pcToken =NULL;
  }
  if(pxSipUri->pxHeaders->pcValue !=NULL)
  {
    IFX_SIP_Free(pxSipUri->pxHeaders->pcValue);
    pxSipUri->pxHeaders->pcValue =NULL;
  }
  __ifx_list_del((void*)&pxSipUri->pxHeaders,
                 (void*) pxSipUri->pxHeaders);
 } 
 memset(pxSipUri,0,sizeof(x_IFX_SIP_SipUri));        

}
  
int
IFX_SipUri_GetHostName(IN char8* pcString, OUT char8* pcHostName)
{
  x_IFX_SIP_SipUri xSipUri;
  x_IFX_SIP_Error xError;
  e_IFX_SIP_Return eRet;
  memset(&xSipUri,0,sizeof(x_IFX_SIP_SipUri));
  eRet=IFX_SIP_DecodeSipUri(pcString,pcString+strlen(pcString),&xSipUri, &xError);
  if(xSipUri.xHostPort.pcHostInfo!=NULL){
  	strcpy(pcHostName,xSipUri.xHostPort.pcHostInfo);
	}
  IFX_SIP_FreeSipUri((uint32)&xSipUri);
  return eRet;
}
#if 0
main()
{
 char8 pcString[500]= /*"redhat123@sipgate.de:5060";*/
"redhat123@172.20.22.88:22;transport=tcp;maddr=172.255.255.0;method=PRACK;hi=bye;ttl=100;user=ip;true=false?download=alive&yes=no";
  char8 acHostName[100]="";
  IFX_SipUri_GetHostName(pcString,acHostName);
  printf("Hi Host Name = %s\n",acHostName);
}
#endif
