/* 
** =============================================================================
**   FILE NAME        : IFX_DHCPOption.c
**   PROJECT          : TR69
**   MODULES          : DHCPOption
**   DATE             : 01-09-2008
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This is the DHCPOption Module. It is required by the 
**                      controller module of TR69 stack to GET/SET/ADD/DELETE 
**                      DHCPOption specific information.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author                         $Comment
**   01-09-2008       TR69 team                       Initial Version
**
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_DHCPOption.h"
  // Required for STATIC
 
#include "IFX_DEVM_OID.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_DS.h"

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFX_DHCPOPTION_OBJ    FORMNAME("LAN.DHCPOption.")
#define DHCP_OPTION_NO_OF_DEP_OIDS  0

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/
#if 0
STATIC int32
GetParamOffset(IN int32 *paiOID);
#endif
STATIC int32
GetVal(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
       IN int32 iElements);
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
AddObj(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32 
IFX_ConvertArrToDHCPOptionStruct(IN uint32 iElements, IN ParamVal *paxParamVal, OUT DHCP_OPTION * pxDHCPOption);
/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : GetParamOffset
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetParamOffset(IN int32 *paiOID)
{
    int32 iCnt;

    for (iCnt = 0; paiOID[iCnt] != 0; iCnt++);

    return (iCnt - 1);
}

int32 
GetDHCPOptInst(DHCP_OPTION **ppxDHCPOpt, uint32 iCpeid)
{

    DHCP_OPTION *paxDHCPOpt = NULL;
    DHCP_OPTION *pxMatchDHCPOpt = NULL;
    DHCP_OPTION *pxTmpDHCPOpt = NULL;
    int32 uiNumOfEntries = 0;
    uint32 iFlags, iI = 0;
    uint32 iGotValue = 0;
    int32 iRet = 0;
	
    pxMatchDHCPOpt=IFX_CWMP_MALLOC(sizeof(DHCP_OPTION));
    if(pxMatchDHCPOpt == NULL){
        iRet = ERR_OUT_OF_MEMORY; 
        goto errorHandler;
    }
    iFlags = IFX_F_GET_ANY;


    iRet=ifx_get_all_dhcp_option(&uiNumOfEntries, &paxDHCPOpt, iFlags);

    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_get_all_dhcp_option returned failure\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto errorHandler;
    }
    pxTmpDHCPOpt = paxDHCPOpt;
	
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "NoOfEntries=%d !\n",uiNumOfEntries);

    for(iI = 0; iI < uiNumOfEntries; iI++)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "API_Cpeid=%d !\n",pxTmpDHCPOpt->iid.cpeId.Id);
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "Module_Cpeid=%d !\n",iCpeid);

        if(pxTmpDHCPOpt != NULL)
        {
            if(pxTmpDHCPOpt->iid.cpeId.Id== iCpeid)
            {	
                //Memcopy the struct
                iGotValue = 1;
                memcpy(pxMatchDHCPOpt, pxTmpDHCPOpt, sizeof(DHCP_OPTION));
                *ppxDHCPOpt = pxMatchDHCPOpt;
                break;
            }
            pxTmpDHCPOpt += 1;
        }

    }

    if(iGotValue == 1)
    {	
		
        IFX_CWMP_FREE(paxDHCPOpt);
        return IFX_CWMP_SUCCESS;
    } 

    errorHandler:

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%s:%d] failed!\n",__FILE__, __func__, __LINE__);
			
    IFX_CWMP_FREE(paxDHCPOpt);
    IFX_CWMP_FREE(pxMatchDHCPOpt);	

    return IFX_CWMP_FAILURE;
}



/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetVal(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
       IN int32 iElements)
{
    int32   iRet  = IFX_CWMP_SUCCESS;
    uint32 iCpeid = 0;

    int32   iCnt  = 0;
    DHCP_OPTION *pxDHCPOpt=NULL;
    int32   iParamOffset;

    // Get Cpeid from object ID
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    	goto cleanup;

    // Get match object from system using Platform API
    iRet= GetDHCPOptInst(&pxDHCPOpt, iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get %s instance with CPEID %d\n",
                    __FILE__,  __func__, __LINE__, iRet, IFX_DHCPOPTION_OBJ, iCpeid);
    	goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(MAX_DHCPOPTION_VALUE_LEN);

        /* Check for error */
        if (!((pxParamVal[iCnt]).Value))
        {
            iRet = ERR_OUT_OF_MEMORY;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Allocation Failure\n",
                         __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_LAN_DHCPO_X_AC9A96_ENABLE:

                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", pxDHCPOpt->enable);
                break;  
            case OID_IGD_LAN_DHCPO_REQUEST:

                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", pxDHCPOpt->request);
                break;  
            case OID_IGD_LAN_DHCPO_TAG:

                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", pxDHCPOpt->tag);
                break;  
            case OID_IGD_LAN_DHCPO_VALUE:

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, pxDHCPOpt->value); 
                break;  
            default:
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
                goto cleanup;
        }
    }

cleanup:
    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : Modify
**
**   Description      : This function modifies the values of parameters in 
**                      DHCPOption object. It calls respective Management API  
**                      for the same. It performs modification only if parameter 
**                      has Write permission. In certain cases it also performs 
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32       iRet       = IFX_CWMP_SUCCESS;
    int32       iRtn       = IFX_SUCCESS;
    uint32      iCpeid     = 0;
    int32       iCnt       = 0;
    DHCP_OPTION *pxDHCPOpt = NULL; /* Mandatory */
    int32       iParamOffset;
    char8       *psTmpVal;
    uint32      uiFlags;

    // Get Cpeid from object ID
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    	goto cleanup;

    // Get match object from system using Platform API
    iRet= GetDHCPOptInst(&pxDHCPOpt, iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get %s instance with CPEID %d\n",
                    __FILE__,  __func__, __LINE__, iRet, IFX_DHCPOPTION_OBJ, iCpeid);
    	goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_LAN_DHCPO_X_AC9A96_ENABLE:

                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    pxDHCPOpt->enable = TRUE;
                }
                else
                {
                    pxDHCPOpt->enable = FALSE;
                }

                break;

            case OID_IGD_LAN_DHCPO_REQUEST:

                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    pxDHCPOpt->request = TRUE;
                }
                else
                {
                    pxDHCPOpt->request = FALSE;
                }

                break;

            case OID_IGD_LAN_DHCPO_TAG:

                pxDHCPOpt->tag =  atoi(psTmpVal);
                break;

            case OID_IGD_LAN_DHCPO_VALUE:

                /* Check if the string fits in the buffer */
                if ((strlen(psTmpVal) + 1) > MAX_DHCPOPTION_VALUE_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }
                /* Copy the string */
                strcpy(pxDHCPOpt->value,psTmpVal);
                break;

            default:

                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

    /* Fill the iid structure in DEVICE_INFO */
    pxDHCPOpt->iid.config_owner = iCaller;

    /* Set all the DHCP_OPTION parameters using Object API */
    uiFlags = IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH;
    if (pxDHCPOpt->enable == FALSE)
    uiFlags |= IFX_F_DONT_ACTIVATE | IFX_F_DONT_VALIDATE; 
    iRtn = ifx_set_dhcp_option(IFX_OP_MOD, pxDHCPOpt, uiFlags);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to set values of all "
                    "parameters\n", __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    IFX_CWMP_FREE(pxDHCPOpt);
    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : Validate
**
**   Description      : This function validates the values of parameters in
**                      DeviceInfo object.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      validated.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When validation of all parameters is
**                      successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in validating at least one parameter.
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iCnt;
    int32   iParamOffset;
    char8   *psTmpVal;

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);

    /* Iterate and validate the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Return a failure if the value is NULL pointer */
        if (!psTmpVal)
        {
            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
            iRet = ERR_CWMP_INVAL_ARGS;
            goto cleanup;
        }
 
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_LAN_DHCPO_X_AC9A96_ENABLE:
            case OID_IGD_LAN_DHCPO_REQUEST:
                if(!(!strcmp(psTmpVal, "true") ||
                   !strcmp(psTmpVal, "false") ||
                   !strcmp(psTmpVal, "1") ||
                   !strcmp(psTmpVal, "0")))
 
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto cleanup;
                }
                break;
            case OID_IGD_LAN_DHCPO_TAG:
                {
                    /* This is temporary validation that works assuming the value being passed is integer */
                    int32 iTmp = atoi(psTmpVal);
                    if (((uint32)iTmp > 254) || ((uint32)iTmp < 1))
                    {
                        (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    }
                    break; 
                }
            case OID_IGD_LAN_DHCPO_VALUE:
                break;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

cleanup:
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Validating requested parameter failed\n",
                    __FILE__, __func__, __LINE__, iRet);
    }
    return (iRet);
}


STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iCnt;

    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Update Attribute Information */
    iRet = IFX_SetAttributesInfo(NULL, pxParamVal, iElements);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Updating Param Attribute Info failed\n",
                    __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    return (iRet);
}

STATIC int32
AddObj(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal, IN int32 iElements)
{

	/* This API calls a Platform API which adds the object
	** in ADD_DISABLE state.
	** Pass necessary flags to the API
	** Controller should get the next instance id from DS 
    	** module and pass the full OID to this module.
	*/
		
	/* If Cisco proposal comes, this API should handle 
	**  a) Validation of values
	**  b) Forward mapping of TR69 values to system values 
	**  c) addition of object into the system
	*/
	
	// Fill	the ATM_VCC_INFO struct and call the respective
	// ifx_add_atm_vcc api to add the entry in disabled state
	// Forward mapping is required if it has some valid values
	
	uint32 iFlags=0;
	int32 iRet=0;
	uint32 iOper;
	uint32 uiOutElem=0;
	uint32 uiPcpeId=0;
	//uint32 uiParamIdPos;
	//uchar8 usInterfaceName[MAX_NAME_LEN];
	//int32 Wan_IpConName_OID[OID_LENGTH]= {0,0,0,0,0,OID_IGD_WAND_WANCD_WANIPC,
	//								MAGIC_NUMBER,OID_IGD_WAND_WANCD_WANIPC_NAME};
	//int32 iaOID[OID_LENGTH];
	DHCP_OPTION xDHCPOption;
	//ParamVal xWan_IpCon;
	ParamVal *paxOutParamArr=NULL;
	memset(&xDHCPOption, 0, sizeof(xDHCPOption));

	//If owner is WEB don't add the object just return success.

	iRet = IFX_GetParentObjCpeId(pxParamVal->iaOID,&uiPcpeId);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	iRet = IFX_ConvertArrToDHCPOptionStruct(iElements, pxParamVal, &xDHCPOption);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	//Flags should be filled
	//Fills the Cpeid,ParentCepid,TR69Id,Owner
	//Fill the operation

	iOper = IFX_OP_ADD;
	iFlags =(	IFX_F_DONT_ACTIVATE|IFX_F_DONT_CHECKPOINT|
			IFX_F_DONT_VALIDATE|IFX_F_DONT_WRITE_TO_FLASH);
	
	xDHCPOption.iid.config_owner=pxOpInfo->iCaller;
	xDHCPOption.iid.cpeId.Id=0;
	xDHCPOption.iid.pcpeId.Id=uiPcpeId;
	xDHCPOption.enable = IFX_DISABLED;
	
	//Convert array into dotted form and then strcpy
	
	iRet = IFX_ConvertOidDottedForm(pxParamVal->iaOID, xDHCPOption.iid.tr69Id);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	iRet = ifx_set_dhcp_option(iOper, &xDHCPOption, iFlags);

	if(iRet != IFX_SUCCESS)
	{
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"ifx_set_dhcp_option AddObj Mgmt API"					                          " returned error\n");
		goto errorHandler;
		
	}	
	iRet = IFX_FreeParamvalArr(&paxOutParamArr,uiOutElem);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	return IFIN_CWMP_SUCCESS;

	errorHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d failed!\n", __func__, __LINE__);
		
		iRet = IFX_FreeParamvalArr(&paxOutParamArr,uiOutElem);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;
		return IFIN_CWMP_FAILURE;

}

STATIC int32 
IFX_ConvertArrToDHCPOptionStruct(IN uint32 iElements, IN ParamVal *paxParamVal, OUT DHCP_OPTION * pxDHCPOption)
{
	uint32 i=0;
	//uchar8 usDestAddr[MAX_NAME_LEN];
	uint32 uiParamPos=0;
	
	uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);
	
	for (i=0; i < iElements; i++) 
	{

	      	switch(paxParamVal->iaOID[uiParamPos])
		{

            			case OID_IGD_LAN_DHCPO_X_AC9A96_ENABLE:
					//pxDHCPOption->enable = atoi(paxParamVal->Value);
					pxDHCPOption->enable = 0;
					break;

            			case OID_IGD_LAN_DHCPO_REQUEST:
					//pxDHCPOption->request = atoi(paxParamVal->Value);
					pxDHCPOption->request = 0;
					break;
					
            			case OID_IGD_LAN_DHCPO_TAG:
					//pxDHCPOption->tag = atoi(paxParamVal->Value);
					pxDHCPOption->tag = 0;
					break;

            			case OID_IGD_LAN_DHCPO_VALUE:
					//strcpy(pxDHCPOption->value,paxParamVal->Value);
					strcpy(pxDHCPOption->value,"@");
					break;
				
				default:
					break;
				

		}


		++paxParamVal;
		
	}

	return IFIN_CWMP_SUCCESS;
		
}

STATIC int32
SetDelete(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
          IN int32 iElements, OUT void **ppxParamStructRet,
          OUT int32 * piNumRetElem)
{

    uint32 uiCpeid=0;
// uint32 uiOld_EnableVal=0;
    DHCP_OPTION *pxMatch_DHCPOpt=NULL;
    int32 iRet=0;
    uint32 iOper=0,iFlags=0;
    uint32 uiParamPos=0;
    ParamVal *Param_DepOids=NULL;


    // handle CHK_DELETE_DEP
    if(pxOpInfo->iSubOper == OP_SETVAL_CHK_DEL_DEP)
    {
        Param_DepOids = IFIN_CWMP_MALLOC((DHCP_OPTION_NO_OF_DEP_OIDS+1)* sizeof(ParamVal));
        if(Param_DepOids == NULL)
        {
           iRet = ERR_OUT_OF_MEMORY; 
           goto errorHandler;
        }

        //Get the WanIpConParamPos 
        uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);

        memcpy((Param_DepOids+0)->iaOID,paxParamVal->iaOID,
               (sizeof(int32)*(uiParamPos+1)));

      *ppxParamStructRet = (void *)Param_DepOids;
      *piNumRetElem = DHCP_OPTION_NO_OF_DEP_OIDS+1;

        return IFIN_CWMP_SUCCESS;
    }

    if(pxOpInfo->iSubOper == OP_SETVAL_CHK_DEL_ALLOWED)
    {
        return IFIN_CWMP_SUCCESS;
    }
    //Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(paxParamVal->iaOID,&uiCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Get match object from system using Platform API
    iRet= GetDHCPOptInst(&pxMatch_DHCPOpt, uiCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get %s instance with CPEID %d\n",
                    __FILE__,  __func__, __LINE__, iRet, IFX_DHCPOPTION_OBJ, uiCpeid);
    	goto errorHandler;
    }

    switch(pxOpInfo->iSubOper)
    {
        case OP_SETVAL_DELETE:
            //handle DELETE operation
            //Call Platform API to delete the obj in the system
            //If del is called by web we need to pass special owner for which API 
            //will not post a message.
            
            pxMatch_DHCPOpt->iid.config_owner=pxOpInfo->iCaller;
            pxMatch_DHCPOpt->iid.cpeId.Id=uiCpeid;
            //pxMatch_DHCPOpt.iid.pcpeID=
            //pxMatch_DHCPOpt.iid.tr69ID=
            memset(pxMatch_DHCPOpt->iid.tr69Id,0x00,MAX_TR69_ID_LEN);
            iOper = IFX_OP_DEL;
            iFlags = (IFX_F_DELETE|IFX_F_DONT_VALIDATE| IFX_F_DONT_CHECKPOINT|IFX_F_DONT_WRITE_TO_FLASH);
            iRet = ifx_set_dhcp_option(iOper, pxMatch_DHCPOpt, iFlags);
            if(iRet != IFX_SUCCESS)
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "ifx_set_dhcp_option -delete Mgmt API returned error\n");
                goto errorHandler;
            }
            break;
            
        default:
            break;
    }
    IFX_CWMP_FREE(pxMatch_DHCPOpt);

    return IFIN_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                 "%s:%d failed!\n", __func__, __LINE__);

    IFX_CWMP_FREE(pxMatch_DHCPOpt);
    return IFIN_CWMP_FAILURE;
}




/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : IFX_DHCPOption_Init
**
**   Description      : This function is called by the controller. It registers
**                      the function responsible for handling DHCPOption object
**                      with data structure. It also performs initializations
**                      specific to DHCPOption object.
**
**   Parameters       : No Parameters. 
**
**   Return Value     : IFX_CWMP_SUCCESS - When DHCPOption object is initialized
**                      successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in initializing DHCPOption object.
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_DHCPOption_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the DHCPOption module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_DHCPOPTION_OBJ, IFX_DHCPOption);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_DHCPOPTION_OBJ);
        goto cleanup;
    }

cleanup:
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_DHCPOption
**
**   Description      : This function is called by the controller. It handles
**                      the DHCPOption object and performs  based on requested
**                      operations/suboperations by invoking internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_DHCPOption(IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
             OUT void **ppRet, OUT int32 *piNumRetElem)
{
    int32       iRet           = IFX_CWMP_SUCCESS;
    ParamVal    *pxParamVal    = (ParamVal *)pParamList;

    /* Process based on type of Operation */
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:

                    /* Get values of all the requested parameters */
                    iRet = GetVal(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_SETVAL:
        {
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:

                    /* Validate values of all the requested parameters */
                    iRet = Validate(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:

                    /* Check modify dependency of all requested parameters */
                    iRet = IFX_CWMP_SUCCESS;
                    break;
                case OP_SETVAL_MODIFY:

                    /* Set values of all the requested parameters */
                    iRet = Modify(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ATTRINFO:

                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ADD:

                    iRet = AddObj(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_FREE:
                   break;
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
                case OP_SETVAL_DELETE:
                    if((iRet= SetDelete(pxOI, pxParamVal,
                        iNumElem, ppRet, piNumRetElem))!= IFX_CWMP_SUCCESS)
                    {

                        switch(pxOI->iSubOper)
                        {
                            case OP_SETVAL_CHK_DEL_DEP:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
                                goto cleanup;
                            case OP_SETVAL_CHK_DEL_ALLOWED:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
                                goto cleanup;
                            case OP_SETVAL_DELETE:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
                                goto cleanup;
                        }
                    }
                    break;

                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD: 
                case OP_UPDATE_CHILDINFO_DEL: 
                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
        {
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid Operation\n",
                         __func__, __LINE__, iRet);
            goto cleanup;
        }
    }

cleanup:
    return (iRet);
}
