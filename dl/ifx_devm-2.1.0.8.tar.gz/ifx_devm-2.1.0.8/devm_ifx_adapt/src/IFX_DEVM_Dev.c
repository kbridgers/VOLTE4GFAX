/*
** =============================================================================
** FILE NAME   : IFX_Device.c
** PROJECT     : TR111
** MODULES     : Device.
** DATE        : 09-Jan-2007
** AUTHOR      : TR111 team
** DESCRIPTION : This object is RO. SetParameterValues or AddObject cannot be
**               performed on this object.
** REFERENCES  :  
** COPYRIGHT   : Copyright (c) 2006
**               Infineon Technologies AG
**               Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY     : 
** $Date       $Author       $Comment
** 09-Jan-2007 TR111 team    Creation         
** =============================================================================
*/
#include "IFX_DEVM_Global.h"
 
#include "IFX_DEVM_AdaptCommon.h"
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"

extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char *obj, modFunc pifx_module_func);

#define DEVICE_OBJ           TR69_DATAMODEL_ROOT "."
#define DEVICE_DEPTH         2

/*******************************************************************************
* Function: IFX_Device_SetAttrInfo
* Description: Sets attribute information in the respective tr69 sections
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_Device_SetAttrInfo(IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    iRet = IFX_SetAttributesInfo(NULL, pxPV, iElements);

    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Updating Param Attribute Info failed\n",
                    __func__, __LINE__, iRet);
        goto errorHandler;
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_Device_GetNotifValue
* Description: 
*              
* Parameters: IN OperInfo *pxOI, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_Device_GetNotifValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                        IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[DEVICE_DEPTH - 1]) {
            case OID_IGD_DEVICESUMMARY:
                pxPV[iI].Value = IFX_CWMP_MALLOC(256);
                if(pxPV[iI].Value == NULL) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                                "Malloc failed\n", __func__, __LINE__);
                    iRet = ERR_OUT_OF_MEMORY;
                    goto errorHandler;
                }

#ifdef STUN_SUPPORT
                strcpy(pxPV[iI].Value, "Device:1.1[](Baseline:1");
#else
                strcpy(pxPV[iI].Value, "Device:1.0[](Baseline:1");
#endif
#ifdef DEVICE_ASSO_SUPPORT
                strcat(pxPV[iI].Value, ", GatewayInfo:1");
#endif
#ifdef IFX_TR69_DEVICE_LAN
                strcat(pxPV[iI].Value, ", LAN:1");
#endif
#ifdef IFX_TR69_TIME
                strcat(pxPV[iI].Value, ", Time:1");
#endif
#ifdef IFX_TR69_IPPING
                strcat(pxPV[iI].Value, ", IPPing:1");
#endif
#ifdef IFX_TR69_TRACEROUTE
				strcat(pxPV[iI].Value, ", TraceRoute:1");
#endif
#ifdef STUN_SUPPORT
                strcat(pxPV[iI].Value, ", UDPConnReq:1");
#endif
                strcat(pxPV[iI].Value, ")");
 
                iRet = IFX_CheckValueGotChanged(pxOI, pxPV + iI,
                                                IFX_CHK_VALUE_BASED);
                if(iRet != IFX_CWMP_SUCCESS) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Get "
                                "Passive failed\n", __func__, __LINE__, iRet);
                    goto errorHandler;
                }
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                            "Default case\n", __func__, __LINE__,
                            pxPV[iI].iaOID[DEVICE_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_Device_GetValue
* Description: Hard coding it to br0 interface. An enhancement on this can be 
*              performed. 
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************
static int32
IFX_Device_GetValue(IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    char8 *psDevSum = DEVICE_SUMMARY;

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[DEVICE_DEPTH - 1]) {
            case OID_IGD_DEVICESUMMARY:
                pxPV[iI].Value = IFX_CWMP_MALLOC(strlen(psDevSum) + 1);
                if(pxPV[iI].Value == NULL) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                                "Malloc failed\n", __func__, __LINE__);
                    iRet = ERR_OUT_OF_MEMORY;
                    goto errorHandler;
                }
                strcpy(pxPV[iI].Value, psDevSum);
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                            "Default case\n", __func__, __LINE__,
                            pxPV[iI].iaOID[DEVICE_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}*/

/*******************************************************************************
* Function: IFX_Device_Validate
* Description:
*              
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_Device_Validate(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[DEVICE_DEPTH - 1]) {
            case OID_IGD_DEVICESUMMARY:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                            "Default case\n", __func__, __LINE__,
                            pxPV[iI].iaOID[DEVICE_DEPTH - 1]);
                break;
        }
    }
    return iRet;
}

/*******************************************************************************
* Function: IFX_Device
* Description: 
*              
* Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
*             OUT void **ppRet, OUT int32 * piNumRetElem
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_Device(IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
           OUT void **ppRet, OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s: %s oper=%d maxElement=%d\n",
                __func__, xpParamVal[0].Name, pxOI->iSubOper, iElements);

    switch(pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                    iRet = IFX_Device_GetNotifValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_GETVAL_NOTIFICATION:
                    iRet = IFX_Device_GetNotifValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error"
                                "! Default case.\n", __func__, __LINE__,
                                pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                    if((iRet = IFX_Device_Validate(xpParamVal, iElements)) != 0) {
                        goto errorHandler;
                    }
                    break;
                case OP_SETVAL_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:
                    break;
                case OP_SETVAL_MODIFY:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_COMMIT:
                    break;
                case OP_SETVAL_UNDO:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_DELETE:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_ATTRINFO:
                    IFX_Device_SetAttrInfo(pxOI->iCaller, pParamStruct, iElements);
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_UPDATE_CHILDINFO_DEL:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                        "Default case.\n", __func__, __LINE__, pxOI->iOper);
            break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_Device_Init
* Description: Will initialize some of its data structures, register itself with 
*              DS.
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_Device_Init()
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Perform any other Device related initializations here */

    /* Register the IFX_Device func ptr in the object model */
    iRet = ifx_ds_register_function(DEVICE_OBJ, IFX_Device);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Unable to "
                    "Register %s with Object Model\n", __func__, __LINE__, iRet,
                    DEVICE_OBJ);
        goto errorHandler;
    }

  errorHandler:
    return iRet;
}
