/* 
** =============================================================================
**   FILE NAME        : IFX_VoiceLine
**   PROJECT          : TR104
**   MODULES          : IFX_VoiceLine
**   DATE             : 21-11-2006
**   AUTHOR           : TR104 team
**   DESCRIPTION   :

**   REFERENCES      : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2004
**                   	      Infineon Technologies AG, st. Martin Strasse 53;
**                   	      81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/


/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "ifx_vmapi_common.h"
#include "IFX_DEVM_VoiceLine.h"
  // Required for STATIC
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
//#include "IFIN_Obj_API.h"
 
#include "IFX_DEVM_AdaptCommon.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_DS.h"

//#include "ifx_voip_defs.h"
//#include "ifx_cm.h"
//#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

#define VOICE_PHY_DEV_DEPTH 3
#define LINE_NO_DEP_OIDS 6


int32
IFX_VoiceLineCfg(IN OperInfo * pxOI, INOUT void *pParamList,
                     IN int32 iNumElem, OUT void **ppRet,
                     OUT int32 * piNumRetElem);

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFX_VOICELINE_OBJ "InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.1.Line.1."


/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;
extern int32 g_Supported_Codecs;


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/
STATIC int32
GetVal(IN int32 iCaller, INOUT ParamVal *pxParamVal,
                    IN int32 iElements);
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
GetModifyDep(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
GetNotify(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
                 IN int32 iElements);
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);
/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/
#if 1
/*******************************************************************************
 *  Function Name : ifx_ParseString 
 *  Description   : This function parses the comma seperated string.
 *  Invoked Fns   :
 *  Input Values  :ucSrc
 *  Output Values :ucDestList- parsed string
 *                 iLength- number of elements in the list
 *  Return Value  : void
 *  Note          :
 * ******************************************************************************/
int
ifx_ParseString1 (uchar8 * ucSrc, uchar8 * ucDestList, uchar8 * iLength) 
{
  int index = 0, i = 0, j = 0;
  while (ucSrc[index] != '\0')
    
  {
    if (ucSrc[index] != ',')
      
    {
      *(ucDestList + (i * 5) + j) = ucSrc[index];
      j++;
    }
    
    else
      
    {
      *(ucDestList + (i * 5) + j) = '\0';
      i++;
      j = 0;
    }
    index++;
  }
  *iLength = i + 1;
  return 0;
}
#endif

/******************************************************************************
*  Function Name  : ifx_ParseString 
*  Description    : Utility function used for parsing
*  Input Values   : ucSrc - string needed to be parsed
*  Output Values  : uiDestList - list after parsing 
*  									iLength - number of elements in the string
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_ParseString (uchar8 * ucSrc, uchar8 * ucDestList,
                              uchar8 * iLength) 
{
  int idx = 0, j = 0;
  *iLength =0;
  while (ucSrc[idx] != '\0')
    
  {
    if (ucSrc[idx] != ',')
      
    {
      *(ucDestList + j) = ucSrc[idx];
      j++;
      ++*iLength;
    }
      
    idx++;
  }
  return IFX_VMAPI_SUCCESS;
}


#ifdef DECT_SUPPORT1
/*****************************************************************************
 *  Function Name   : ifx_AssociateDectEndpts
 *  Description     : This function is called in 
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : 
 ****************************************************************************/ 
int32
ifx_AssociateDectEndpts (x_IFX_VMAPI_VoiceLine *pxVL, uchar8 * ucSrc) 
{
  uchar8 pucPhyendptsList1[200]; 
  uchar8 pucPhyendptsList[200]; 
  uchar8 ucNoofPhyendpts =0;
  int32 iRet;
  int32 flag1=0,count1=0,p=0,q=0,x=0;
  int32 index = 0;
  uchar8 DisAssoc_array[30]={0};
  uchar8 Temp_array[10]={0};
  x_IFX_VMAPI_DectHandset xDectHand;
  int32 dect_flag = 0;

  /* Parsing the string set from web */
  memset (&pucPhyendptsList, 0, sizeof (pucPhyendptsList));
  memset (&pucPhyendptsList1, 0, sizeof (pucPhyendptsList1));
    
  /* Parse the comma seperated Endpoint List string into an array*/
  if ( ucSrc != NULL)
  {
    ifx_ParseString ( ucSrc, pucPhyendptsList1,
                                   &ucNoofPhyendpts);
	}

  /* Conversion of logical name of the Endpoint to Interface Id */	
  for (p = 0; p < ucNoofPhyendpts; p++)
  {
	  pucPhyendptsList[p] = pucPhyendptsList1[p] - '0';		
		printf("<Dect>pucPhyendptsList[%d] = %d\n",p,pucPhyendptsList[p]);
	}

	/* No change in the Associated Endpoints List. Just return. */
	if( 0 == memcmp(pxVL->ucAssocVoiceInterface,
			pucPhyendptsList,IFX_VMAPI_MAX_VOICE_INTERFACES) )
	{
		return IFX_VMAPI_SUCCESS;/*TODO*/
	}
	
	p=0;
  memset (&(DisAssoc_array), 0, sizeof (DisAssoc_array));
  /* Comparing parsed array with AssocInterface in VoiceLine to get 
		 the Endpoints which have been disassociated*/
  while(pxVL->ucAssocVoiceInterface[x] != 0)
  {
		if(pxVL->ucAssocVoiceInterface[x] <3)
		{
			Temp_array[index] = pxVL->ucAssocVoiceInterface[x];
			index++;			
		}
		/* All the endpoints are disassociated */
	  if(ucNoofPhyendpts == 0)
		{
			memcpy(&(DisAssoc_array),&(pxVL->ucAssocVoiceInterface),
											sizeof(pxVL->ucAssocVoiceInterface));
			break;
		}
		/* Some Endpoints are disassociated. Endpoints which are there in
		   the VoiceLine AssociatedInterface list but not in the parsed array 
		   list, are disassociated.*/
		else
		{
			for (p = 0; p < ucNoofPhyendpts; p++)
      {
        if( pxVL->ucAssocVoiceInterface[x] != pucPhyendptsList[p])
        {
					count1++;
        }
      }
			if(count1 == ucNoofPhyendpts)
			{
  			if(pxVL->ucAssocVoiceInterface[x] >3){
        	DisAssoc_array[q] = pxVL->ucAssocVoiceInterface[x];
				}
				q++;
			}
			count1=0;
		}
    x++;
  }

	count1=0;
  q=0;
  p=0;
  x=0;
	index=0;

  /*Assigning the associated Endpoints to the AssocVoiceInterface of Line */ 
  memset (&(pxVL->ucAssocVoiceInterface), 0, 
									sizeof (pxVL->ucAssocVoiceInterface));
	
  for (index = 0; index < ucNoofPhyendpts; index++)
  {
    pxVL->ucAssocVoiceInterface[index] = (pucPhyendptsList[index]);
  } 
	while(Temp_array[q] !=0)
	{
		pxVL->ucAssocVoiceInterface[index] = Temp_array[q];
		index++;
		q++;
	}
	index=0;
	q=0;
			
  /* Updating the parameters of DisAssociating Endpoints. For each disassociated
	   Endpoint the VoiceLineIdList and default VoiceLineId needs to be updated. */
  while(DisAssoc_array[q] != 0)
  {
    if(DisAssoc_array[q] >3) {
			/* For DECT Handset */
			memset(&xDectHand,0,sizeof(xDectHand));
      xDectHand.xVoiceServPhyIf.ucInterfaceId = DisAssoc_array[q];
	    iRet = ifx_get_DectHandset(&xDectHand,0);
      if (iRet != IFX_VMAPI_SUCCESS)
      {
        //ifx_httpdError (wp, 200, "Fail to GET the Dect Handset !!");
        return IFX_VMAPI_FAIL;/*TODO*/
      }

			/* If the default VoiceLineId is same as the Line then delete that 
			   and set it to the next available VoiceLine else 0 */
			x=0;
			if(xDectHand.ucVoiceLineId == pxVL->ucLineId)
			{
				while(xDectHand.aucVoiceLineIdList[x] != 0)
				{
					if(xDectHand.aucVoiceLineIdList[x] != pxVL->ucLineId)
					{
					  xDectHand.ucVoiceLineId = xDectHand.aucVoiceLineIdList[x];
					}
					else
					{
						xDectHand.ucVoiceLineId = 0;
					}
					x++;
				}
			}

			x=0;
			
			/* Remove the LineId from the VoiceLineId List */
  	  while (xDectHand.aucVoiceLineIdList[p] != 0)
	    {
        /* Check if the corresponding line is already there */
		    if (xDectHand.aucVoiceLineIdList[p] == pxVL->ucLineId)
		    {
		      x=p;
          while(xDectHand.aucVoiceLineIdList[x] != 0)
          {
            xDectHand.aucVoiceLineIdList[x] = xDectHand.aucVoiceLineIdList[x+1];
            x++; 
          }
        }
        p++;
      }
			
			/* SET the object */
 	    if(IFX_VMAPI_SUCCESS != ifx_set_DectHandset(IFX_OP_MOD,&xDectHand,
															IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
      et ts=2

        return IFX_VMAPI_FAIL;
      }  
		}

		q++;
    p=0;
    x=0;
  }/* while loop */

  q=0;
  p=0;
  x=0;

  /* Updating the parameters of the Endpoints which are getting associated with 
	   this line. */
  while( (pucPhyendptsList[x]) != 0)
  {
    count1=0;
    if(pucPhyendptsList[x] >3){
      memset(&xDectHand,0,sizeof(xDectHand));
      xDectHand.xVoiceServPhyIf.ucInterfaceId = (pucPhyendptsList[x]);
	    iRet = ifx_get_DectHandset(&xDectHand,0);
      if (iRet != IFX_VMAPI_SUCCESS)
      {
        return IFX_VMAPI_FAIL;
      }

      while(xDectHand.aucVoiceLineIdList[p] != 0)
      {
        /* Set the flag if this VoiceLine is already associated*/
        if(xDectHand.aucVoiceLineIdList[p] == pxVL->ucLineId)
        {
          dect_flag = 1;
        }
        count1++;
        p++;
      }
      /*If the flag is not set then assign this VoiceLine Id to the VoiceLineIdList 
				of the Endpoint. Set the default VoiceLine parameter also if the Endpoint was
			  not associated with any VoiceLine before. */
      if ( dect_flag == 0 )
      {
			  if(xDectHand.ucVoiceLineId == 0)
				{
          xDectHand.ucVoiceLineId = pxVL->ucLineId;
				}
        xDectHand.aucVoiceLineIdList[count1] = pxVL->ucLineId;
        if(IFX_VMAPI_SUCCESS != ifx_set_DectHandset(IFX_OP_MOD,&xDectHand,
																IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
        {
          return IFX_VMAPI_FAIL;
        }
      }
		}
		p=0;
    count1=0;
    flag1=0;
    x++;
  } /* while loop */
			
   
  return IFX_VMAPI_SUCCESS; /*TODO*/
 
}
#endif


/*****************************************************************************
 *  Function Name   : ifx_AssociateEndpts 
 *  Description     : This function is called in 
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : 
 ****************************************************************************/ 
int32
ifx_AssociateEndpts (x_IFX_VMAPI_VoiceLine *pxVL, uchar8 * ucSrc) 
{
  uchar8 pucPhyendptsList1[200]; 
  uchar8 pucPhyendptsList[200]; 
  uchar8 ucNoofPhyendpts =0;
  int32 iRet;
  int32 flag1=0,count1=0,p=0,q=0,x=0;
  int32 index = 0;
  uchar8 DisAssoc_array[30]={0};
  uchar8 Temp_array[10]={0};
  x_IFX_VMAPI_FxsPhyIf xFXS;

  /* Parsing the string set from web */
  memset (&pucPhyendptsList, 0, sizeof (pucPhyendptsList));
  memset (&pucPhyendptsList1, 0, sizeof (pucPhyendptsList1));
    
  /* Parse the comma seperated Endpoint List string into an array*/
  if ( ucSrc != NULL)
  {
    ifx_ParseString ( ucSrc, pucPhyendptsList1,
                                   &ucNoofPhyendpts);
	}

  /* Conversion of logical name of the Endpoint to Interface Id */	
  for (p = 0; p < ucNoofPhyendpts; p++)
  {
	  pucPhyendptsList[p] = pucPhyendptsList1[p] - '0';		
		//printf("pucPhyendptsList[%d] = %d\n",p,pucPhyendptsList[p]);
	}

	/* No change in the Associated Endpoints List. Just return. */
	if( 0 == memcmp(pxVL->ucAssocVoiceInterface,
			pucPhyendptsList,IFX_VMAPI_MAX_VOICE_INTERFACES) )
	{
		return IFX_VMAPI_SUCCESS;/*TODO*/
	}
	
	p=0;
  memset (&(DisAssoc_array), 0, sizeof (DisAssoc_array));
  /* Comparing parsed array with AssocInterface in VoiceLine to get 
		 the Endpoints which have been disassociated*/
  while(pxVL->ucAssocVoiceInterface[x] != 0)
  {
		if(pxVL->ucAssocVoiceInterface[x] >3)
		{
			Temp_array[index] = pxVL->ucAssocVoiceInterface[x];
			index++;			
		}
		/* All the endpoints are disassociated */
	  if(ucNoofPhyendpts == 0)
		{
			memcpy(&(DisAssoc_array),&(pxVL->ucAssocVoiceInterface),
											sizeof(pxVL->ucAssocVoiceInterface));
			break;
		}
		/* Some Endpoints are disassociated. Endpoints which are there in
		   the VoiceLine AssociatedInterface list but not in the parsed array 
		   list, are disassociated.*/
		else
		{
			for (p = 0; p < ucNoofPhyendpts; p++)
      {
        if( pxVL->ucAssocVoiceInterface[x] != pucPhyendptsList[p])
        {
					count1++;
        }
      }
			if(count1 == ucNoofPhyendpts)
			{
  			if(pxVL->ucAssocVoiceInterface[x] <3){
        	DisAssoc_array[q] = pxVL->ucAssocVoiceInterface[x];
					printf("DisAssoc_array[%d]=%d\n",q,DisAssoc_array[q] );
				}
				q++;
			}
			count1=0;
		}
    x++;
  }

	count1=0;
  q=0;
  p=0;
  x=0;
	index=0;

  /*Assigning the associated Endpoints to the AssocVoiceInterface of Line */ 
  memset (&(pxVL->ucAssocVoiceInterface), 0, 
									sizeof (pxVL->ucAssocVoiceInterface));
	
  for (index = 0; index < ucNoofPhyendpts; index++)
  {
    pxVL->ucAssocVoiceInterface[index] = (pucPhyendptsList[index]);
  }

	while(Temp_array[q] !=0)
	{
		pxVL->ucAssocVoiceInterface[index] = Temp_array[q];
		index++;
		q++;
	}
	index=0;
	q=0;
			
  /* Updating the parameters of DisAssociating Endpoints. For each disassociated
	   Endpoint the VoiceLineIdList and default VoiceLineId needs to be updated. */
  while(DisAssoc_array[q] != 0)
  {
		/* For FXS Endpoints */
	  if(DisAssoc_array[q] <3) {
			memset(&xFXS,0,sizeof(xFXS));
      xFXS.xVoiceServPhyIf.ucInterfaceId = DisAssoc_array[q];
	    iRet = ifx_get_FxsPhyInterface(&xFXS,0);
      if (iRet != IFX_VMAPI_SUCCESS)
      {
        //ifx_httpdError (wp, 200, "Fail to GET the FXS !!");
        return IFX_VMAPI_FAIL;/*TODO*/
      }

			x=0;
			
			/* If the default VoiceLineId is same as the LineId then delete that 
			   and set it to the next available VoiceLine else set it to 0 */
			if(xFXS.ucVoiceLineId == pxVL->ucLineId)
			{
				while(xFXS.ucVoiceLineIdList[x] != 0)
				{
					if(xFXS.ucVoiceLineIdList[x] != pxVL->ucLineId)
					{
					  xFXS.ucVoiceLineId = xFXS.ucVoiceLineIdList[x];
					}
					else
					{
						xFXS.ucVoiceLineId = 0;
					}
					x++;
				}
			}

			x=0;
			
			/* Remove the Line from the VoiceLineId List of that FXS endpoint*/
  	  while (xFXS.ucVoiceLineIdList[p] != 0)
	    {
        /* Check if the corresponding line is already there */
		    if (xFXS.ucVoiceLineIdList[p] == pxVL->ucLineId)
		    {
		      x=p;
          while(xFXS.ucVoiceLineIdList[x] != 0)
          {
            xFXS.ucVoiceLineIdList[x] = xFXS.ucVoiceLineIdList[x+1];
            x++; 
          }
        }
        p++;
      }

			/* SET the object */
 	    if(IFX_VMAPI_SUCCESS != ifx_set_FxsPhyInterface(IFX_OP_MOD,&xFXS,
															IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
      {
        return IFX_VMAPI_FAIL;
      }  
		}
		q++;
    p=0;
    x=0;
  }/* while loop */

  q=0;
  p=0;
  x=0;

  /* Updating the parameters of the Endpoints which are getting associated with 
	   this line. */
  while( (pucPhyendptsList[x]) != 0)
  {
	  if(pucPhyendptsList[x] <3){
      memset(&xFXS,0,sizeof(xFXS));
      xFXS.xVoiceServPhyIf.ucInterfaceId = (pucPhyendptsList[x]);
	    iRet = ifx_get_FxsPhyInterface(&xFXS,0);
      if (iRet != IFX_VMAPI_SUCCESS)
      {
        //ifx_httpdError (wp, 200, "Fail to GET the FXS !!!");
        return IFX_VMAPI_FAIL;/*TODO*/
      }

      while(xFXS.ucVoiceLineIdList[p] != 0)
      {
        /* Set the flag if this VoiceLine is already associated*/
        if(xFXS.ucVoiceLineIdList[p] == pxVL->ucLineId)
        {
          flag1 = 1;
        }
        count1++;
        p++;
      }
      /*If the flag is not set then assign this VoiceLine Id to the VoiceLineIdList 
				of the Endpoint. Set the default VoiceLine parameter also if the Endpoint was
			  not associated with any VoiceLine before. */
      if ( flag1 == 0 )
      {
				if(xFXS.ucVoiceLineId == 0)
				{
          xFXS.ucVoiceLineId = pxVL->ucLineId;
				}
        xFXS.ucVoiceLineIdList[count1] = pxVL->ucLineId;
        if(IFX_VMAPI_SUCCESS != ifx_set_FxsPhyInterface(IFX_OP_MOD,&xFXS,
																IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
        {
          return IFX_VMAPI_FAIL;
        }
      }
		}
		p=0;
    count1=0;
    flag1=0;
    x++;
  } /* while loop */
			
  return IFX_VMAPI_SUCCESS;/*TODO*/
}


#if 0
/*****************************************************************************
 *  Function Name   : ifx_AssocProfile
 *  Description     : This function is called in 
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : 
 ****************************************************************************/ 
void
ifx_AssocProfile (uchar8 * pProfNum) 
{

  int32 flag1=0,count1=0,x=0;
	uchar8 ucPrevProf =0;
  x_IFX_VMAPI_VoiceProfile xVoiceProf;
  x_IFX_VMAPI_VoiceLine xVoiceLine;
	a_assert (wp);

  memset(&xVoiceLine,0,sizeof(xVoiceLine));
  xVoiceLine.ucLineId = g_LINE_ID_IS;
  xVoiceLine.iid.config_owner = IFX_WEB;
	if(IFX_VMAPI_SUCCESS != ifx_get_VoiceLine(&xVoiceLine,0))
  {
    return ;
  }

	/* There is no change in Profile Association. Just return */
	if(xVoiceLine.ucProfileId == atoi(pProfNum)){
		return;
	}
	
	/* Line is already associated with the other Profile. So LineId
	   has to be deleted from the AssoLineIds of that Profile */
	ucPrevProf = xVoiceLine.ucProfileId;


	if(ucPrevProf != 0)
	{
		memset(&xVoiceProf,0,sizeof(xVoiceProf));
    xVoiceProf.ucProfileId = ucPrevProf ;
    xVoiceProf.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_get_VoiceProfile(&xVoiceProf,0))
    {
      return;
    }
    /* Checking if Line is already associated*/
    while(xVoiceProf.aucAssoLineIds[x] != 0)
    {
      if(xVoiceProf.aucAssoLineIds[x] == xVoiceLine.ucLineId)
      {
        count1=x;
        xVoiceProf.ucNoOfLines-=1;
        while(xVoiceProf.aucAssoLineIds[count1] != 0)
        {
          xVoiceProf.aucAssoLineIds[count1] = xVoiceProf.aucAssoLineIds[count1+1];
          count1++; 
        }
      }
      x++;
    } 
    if(IFX_VMAPI_SUCCESS != ifx_set_VoiceProfile(IFX_OP_MOD,&xVoiceProf,
														IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
      return;
    }
	}

	/* Association with the Profile means, the pCpeId of Line needs to be 
     set with the associated profile*/
	xVoiceLine.ucProfileId = atoi(pProfNum);
 	xVoiceLine.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_set_VoiceLine(IFX_OP_MOD,&xVoiceLine,0))
  {
	  not_flag =0;
    return;
  }
	else
	{
	  not_flag =1;
	}

  /* Profile Association*/
  /*If no profile,give error */
  if(atoi(pProfNum) == 0)
  {
    return;
  }

  /* If no error,Assigning Line Id to the AssoLineIds of profile */
  memset(&xVoiceProf,0,sizeof(xVoiceProf));
  xVoiceProf.ucProfileId = atoi(pProfNum);
  xVoiceProf.iid.config_owner = IFX_WEB;
  if(IFX_VMAPI_SUCCESS != ifx_get_VoiceProfile(&xVoiceProf,0))
  {
    return;
  }

	count1=0;
	x=0;
  /* Checking if Line is already associated in the VoiceProfile*/
  while(xVoiceProf.aucAssoLineIds[x] != 0)
  { 
    if(xVoiceProf.aucAssoLineIds[x] == xVoiceLine.ucLineId)
    {
      flag1 = 1;
			return ; /* No need to set the VoiceProfile */
    } 
		count1++;
    x++;
  } 

  /* If not associated then assign it to the AssoLineIds of the profile */
  if(flag1 == 0)
  {
    xVoiceProf.aucAssoLineIds[count1] = xVoiceLine.ucLineId;
    xVoiceProf.ucNoOfLines+=1;
    if(IFX_VMAPI_SUCCESS != ifx_set_VoiceProfile(IFX_OP_MOD,&xVoiceProf,
														IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
      return;
    }
  } 

}

#endif

#ifdef DECT_SUPPORT1
/*****************************************************************************
 *  Function Name   : ifx_AssociateEndpts 
 *  Description     : This function is called in 
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : 
 ****************************************************************************/ 
int32
ifx_GetDectEndPtIdFromIPEI (char8 * pcIpei , uchar8 *pucId) 
{
  x_IFX_VMAPI_DectHandset xDectHandset;
	int32 i=0;

	for(i=0;i<IFX_VMAPI_MAX_DECT_ENDPTS;i++)
	{
		memset(&xDectHandset,0,sizeof(xDectHandset));
  	xDectHandset.xVoiceServPhyIf.ucInterfaceId = i + 4;
  	xDectHandset.iid.config_owner = IFX_WEB;
  	if(IFX_VMAPI_SUCCESS != ifx_get_DectHandset(&xDectHandset,0))
  	{
    	return IFX_VMAPI_FAIL;
  	}
		else
		{
			if(strcmp(pcIpei, xDectHandset.acIPEI) == 0)
			{
				*pucId = xDectHandset.xVoiceServPhyIf.ucInterfaceId;
				return IFX_VMAPI_SUCCESS;
			}
		}
	}
	return IFX_VMAPI_SUCCESS;
}
#endif

/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetVal(IN int32 iCaller, INOUT ParamVal *pxParamVal,
                    IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iRtn = IFX_SUCCESS;
    int32   iCnt = 0;
    int32   iTmpCnt = -1; /* Mandatory */
    int32   iParamOffset;
    int32   iOID;
    int32   iMemErrorFlag = 0; /* Mandatory */
    x_IFX_VMAPI_VoiceLine xVoiceLine;
		uint32 uiPCpeId;

    /* NOTE: For all parameters fault code is set to success by default. If error in
       validating first parameter, fault code is set to the error type and other
       parameters are not validated. */
    /* NOTE: For all parameters value is set to NULL by default. */

    /* Set the fault code to Success and value to NULL pointer for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);

    memset(&xVoiceLine, 0, sizeof(x_IFX_VMAPI_VoiceLine));

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_L:{

            char8 sOidString[100] = {0};
            IFX_CpeId *pxCpeIdArray = NULL;
            unsigned int uiNumCpeId;

    				/* Get the Parent CPE Id */
    				IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT &uiPCpeId);
    				xVoiceLine.iid.pcpeId.Id = uiPCpeId;

            /*ignore the last value as it will be a parameter and we need 
              only till the last instance*/
            iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );

            strcpy(xVoiceLine.iid.tr69Id,sOidString);

            /*Get the CPE Id from the corresponding tr69 Id */
            iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId,
                               OUT &pxCpeIdArray);
            if(iRet != IFX_CWMP_SUCCESS){
                   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                   __func__, __LINE__);

              return ERR_CWMP_INTERNAL;
            }
            //printf("CPEID is %d\n",pxCpeIdArray->uiId);   

            /* Fill the CPE ID of the object instance */
            xVoiceLine.iid.cpeId.Id = pxCpeIdArray->uiId;
            xVoiceLine.iid.config_owner = IFX_TR69;

            /* Get all the Voice Line parameters using VMAPI */
            iRtn = ifx_get_VoiceLine(&xVoiceLine, IFX_F_DEFAULT);

            IFX_CWMP_FREE(pxCpeIdArray);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to get values of all "
                            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto cleanup;
            }
            }
            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
	  case OID_IGD_S_VS_VP_L_ENABLE:

						//printf("LineState is %d\n",xVoiceLine.ucState);
            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(10);

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }


               /* Copy the value to allocated area */
               //if(xVoiceLine.ucState ==  IFX_VMAPI_VL_STATE_DISABLED)
               if(xVoiceLine.ucState ==  0) //IFX_VMAPI_VL_STATE_DISABLED is defined as 2 in vmapi
                 strcpy((pxParamVal[iCnt]).Value, "Disabled");
               else if(xVoiceLine.ucState == IFX_VMAPI_VL_STATE_QUIESCENT)
                 strcpy((pxParamVal[iCnt]).Value, "Quiscent");
               else if(xVoiceLine.ucState == IFX_VMAPI_VL_STATE_ENABLED)
                 strcpy((pxParamVal[iCnt]).Value, "Enabled");
 
            break;  
          case OID_IGD_S_VS_VP_L_DIRECTORYNUMBER:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(xVoiceLine.acDirName));

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                strcpy((pxParamVal[iCnt]).Value,xVoiceLine.acDirName);
            break;
          case OID_IGD_S_VS_VP_L_STATUS:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(14);
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }


              /* Copy the value to allocated area */
              if(xVoiceLine.ucLineStatus == 
                           IFX_VMAPI_VL_STATUS_DISABLED)
                strcpy((pxParamVal[iCnt]).Value, "Disabled");
              else if(xVoiceLine.ucLineStatus == 
                           IFX_VMAPI_VL_STATUS_INITIALISING)
                strcpy((pxParamVal[iCnt]).Value, "Initialising");
              else if(xVoiceLine.ucLineStatus == 
                           IFX_VMAPI_VL_STATUS_REGISTERING)
                strcpy((pxParamVal[iCnt]).Value, "Registering");
              else if(xVoiceLine.ucLineStatus == 
                           IFX_VMAPI_VL_STATUS_UNREGISTERING)
                strcpy((pxParamVal[iCnt]).Value, "Unregistering");
              else if(xVoiceLine.ucLineStatus == 
                           IFX_VMAPI_VL_STATUS_ERROR)
                strcpy((pxParamVal[iCnt]).Value, "Error");
              else if(xVoiceLine.ucLineStatus == 
                           IFX_VMAPI_VL_STATUS_TESTING)
                strcpy((pxParamVal[iCnt]).Value, "Testing");
              else if(xVoiceLine.ucLineStatus == 
                           IFX_VMAPI_VL_STATUS_QUIESCENT)
                strcpy((pxParamVal[iCnt]).Value, "Quiescent");
              else if(xVoiceLine.ucLineStatus == 
                           IFX_VMAPI_VL_STATUS_UP)
                strcpy((pxParamVal[iCnt]).Value, "Up");

            break;  
          case OID_IGD_S_VS_VP_L_CALLSTATE:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(14);

              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

               /* Copy the value to allocated area */
              if(xVoiceLine.ucCallStatus == 
                              IFX_VMAPI_CALL_STATUS_IDLE)
                strcpy((pxParamVal[iCnt]).Value, "Idle");
              else if(xVoiceLine.ucCallStatus == 
                              IFX_VMAPI_CALL_STATUS_CALLING)
                strcpy((pxParamVal[iCnt]).Value, "Calling");
              else if(xVoiceLine.ucCallStatus == 
                              IFX_VMAPI_CALL_STATUS_RINGING)
                strcpy((pxParamVal[iCnt]).Value, "Ringing");
              else if(xVoiceLine.ucCallStatus == 
                              IFX_VMAPI_CALL_STATUS_CONNECTING)
                strcpy((pxParamVal[iCnt]).Value, "Connecting");
              else if(xVoiceLine.ucCallStatus == 
                              IFX_VMAPI_CALL_STATUS_INCALL)
                strcpy((pxParamVal[iCnt]).Value, "Incall");
              else if(xVoiceLine.ucCallStatus == 
                              IFX_VMAPI_CALL_STATUS_HOLD)
                strcpy((pxParamVal[iCnt]).Value, "Hold");
              else if(xVoiceLine.ucCallStatus == 
                              IFX_VMAPI_CALL_STATUS_DISCONNECTING)
                strcpy((pxParamVal[iCnt]).Value, "Disconnecting");

            break;  
          case OID_IGD_S_VS_VP_L_PHYREFERENCELIST:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                 sizeof(xVoiceLine.ucAssocVoiceInterface));

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
		/* Already parsed by the VMAPI. So we need to parse back again to 
		 comma seperated string format. */
		{
     			int32 i=0,j=0;
     			char8 XArray[2*IFX_VMAPI_MAX_VOICE_INTERFACES+1]={'\0'};
                        memset(XArray, '\0', sizeof(XArray));
     			while(xVoiceLine.ucAssocVoiceInterface[i] != 0)
   			{
				//if(xVoiceLine.ucAssocVoiceInterface[i] <3)
				if((xVoiceLine.ucAssocVoiceInterface[i] <3) && j<(2*IFX_VMAPI_MAX_VOICE_INTERFACES-1))
				{
       					sprintf(&XArray[j],"%d",xVoiceLine.ucAssocVoiceInterface[i]);
       					strcat(XArray,",");
       					j = strlen(XArray);
				}
       				i++;
     			}
                        if (strlen(XArray) > 0) {
       	       		/* Copy the value to allocated area */
			XArray[strlen(XArray)-1] = '\0';
	                strcpy((pxParamVal[iCnt]).Value, XArray);
                        }
  		}

            break; 
#ifdef DECT_SUPPORT1
		case OID_IGD_S_VS_VP_L_DECTHANDSETREFERENCELIST:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                 sizeof(xVoiceLine.ucAssocVoiceInterface));

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
								/* Already parsed by the VMAPI. So we need to parse back again in 
									 string format. */
								{
     							int32 i=0,j=0;
     							uchar8 XArray[100]={'\0'};
									x_IFX_VMAPI_DectHandset xDectHandset;
									
     							while(xVoiceLine.ucAssocVoiceInterface[i] != 0)
     							{
										if(xVoiceLine.ucAssocVoiceInterface[i] >3)
										{
											memset(&xDectHandset,0,sizeof(xDectHandset));
  										xDectHandset.xVoiceServPhyIf.ucInterfaceId = xVoiceLine.ucAssocVoiceInterface[i];
  										xDectHandset.iid.config_owner = IFX_WEB;
  										if(IFX_VMAPI_SUCCESS != ifx_get_DectHandset(&xDectHandset,0))
  										{
    										return -1;
  										}
       								sprintf(&XArray[j],"%s",xDectHandset.acIPEI);
       								strcat(XArray,",");
       								j = strlen(XArray);
										}
       							i++;
     							}
                	/* Copy the value to allocated area */
                  strcpy((pxParamVal[iCnt]).Value, XArray);
  							}


            break; 
#endif
#ifdef IIP 
	  case OID_IGD_S_VS_VP_L_RINGMUTESTATUS:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                /* Copy the value to allocated area */
                if(xVoiceLine.bEnableRingMute ==  
                                  IFX_VMAPI_VL_STATE_DISABLED)
                  strcpy((pxParamVal[iCnt]).Value, "false");
                else if(xVoiceLine.bEnableRingMute == 
                                  IFX_VMAPI_VL_STATE_ENABLED)
                  strcpy((pxParamVal[iCnt]).Value, "true");

            break;  
          case OID_IGD_S_VS_VP_L_RINGVOLUMESTATUS:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uchar8));

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                /* Copy the value to allocated area */
                sprintf((pxParamVal[iCnt]).Value, "%d", 
                                       xVoiceLine.ucRingVolume);

            break; 
#endif
          default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                iTmpCnt = iCnt;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
            goto cleanup;
        }
    }

cleanup:

    if (iMemErrorFlag)
    {
        (pxParamVal[iCnt]).iFaultCode = ERR_OUT_OF_MEMORY;
        iRet = ERR_OUT_OF_MEMORY;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Allocation Failure\n",
                     __FILE__, __func__, __LINE__, iRet);
    }

    if (iRet != IFX_CWMP_SUCCESS)
    {

        /* Free the allocation for value, if any. Also set the fault code. */
        for (iCnt = 0; iCnt < iElements; iCnt++)
        {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
            if (iTmpCnt != iCnt) 
            {
                (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
            }
        }
    }

    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : Modify
**
**   Description      : This function modifies the values of parameters in 
**                      VoiceLine object. It calls respective VMAPI for  
**                      the same. It performs modification only if parameter 
**                      has Write permission. In certain cases it also performs 
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet         = IFX_CWMP_SUCCESS;
    int32   iRtn         = IFX_SUCCESS;
    int32   iCnt         = 0;
    int32   iParamOffset;
    int32   iOID;
    x_IFX_VMAPI_VoiceLine xVoiceLine;
		x_IFX_VMAPI_LineSignaling xLineSign;
		uint32 uiPCpeId;

    /* NOTE: For all parameters fault code is set to success by default. 
       If error in validating first parameter, fault code is set to the 
       error type and other parameters are not validated. */

    /* Set the fault code to Success for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
    }

    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);

    memset(&xVoiceLine, 0, sizeof(x_IFX_VMAPI_VoiceLine));
		memset(&xLineSign,0,sizeof(xLineSign)); 

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_L:{

            char8 sOidString[100] = {0};
            IFX_CpeId *pxCpeIdArray = NULL;
            unsigned int uiNumCpeId;

    				/* Get the Parent CPE Id */
    				IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT &uiPCpeId);
    				xVoiceLine.iid.pcpeId.Id = uiPCpeId;
    				xLineSign.iid.pcpeId.Id = uiPCpeId;

            /*ignore the last value as it will be a parameter and we need 
              only till the last instance*/
            iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );

            strcpy(xVoiceLine.iid.tr69Id,sOidString);

            /*Get the CPE Id from the corresponding tr69 Id */
            iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId,
                               OUT &pxCpeIdArray);
            if(iRet != IFX_CWMP_SUCCESS){
                   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                   __func__, __LINE__);

              return ERR_CWMP_INTERNAL;
            }

            /* Fill the CPE ID of the object instance */
            xVoiceLine.iid.cpeId.Id = pxCpeIdArray->uiId;
            xVoiceLine.iid.config_owner = IFX_TR69;

            xLineSign.iid.cpeId.Id = pxCpeIdArray->uiId;
            xLineSign.iid.config_owner = IFX_TR69;
						
            /* Get all the Voice Line parameters using VMAPI */
            iRtn = ifx_get_VoiceLine(&xVoiceLine, IFX_F_DEFAULT);

            IFX_CWMP_FREE(pxCpeIdArray);

            /* Check for error */
            if (iRtn != IFX_CWMP_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to get values of all "
                            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto cleanup;
            }
            }
            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_S_VS_VP_L_ENABLE:
              if(!strncasecmp(pxParamVal[iCnt].Value,"Disabled",8))
								xVoiceLine.ucState = IFX_VMAPI_VL_STATE_DISABLED; 
              else if(!strncasecmp(pxParamVal[iCnt].Value,"Quiescent",9))
								xVoiceLine.ucState = IFX_VMAPI_VL_STATE_QUIESCENT; 
              else if(!strncasecmp(pxParamVal[iCnt].Value,"Enabled",7))
								xVoiceLine.ucState = IFX_VMAPI_VL_STATE_ENABLED; 
              
              break;
            case OID_IGD_S_VS_VP_L_DIRECTORYNUMBER:
                strncpy(xVoiceLine.acDirName, pxParamVal[iCnt].Value,(IFX_VMAPI_MAX_USER_NAME_LEN-1));
		xVoiceLine.acDirName[IFX_VMAPI_MAX_USER_NAME_LEN-1] = '\0';
		{
			printf("VoiceLine.acDirName = %s\n",xVoiceLine.acDirName);
  			if(IFX_VMAPI_SUCCESS != ifx_get_LineSignaling(&xLineSign,IFX_F_DEFAULT))
			{
                		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to get values of all "
                            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
			}
			else {
				if(strcmp(xLineSign.acSipUserName , xVoiceLine.acDirName) != 0)
				{
					strcpy(xLineSign.acSipUserName , xVoiceLine.acDirName);
					if(IFX_VMAPI_SUCCESS != ifx_set_LineSignaling(IFX_OP_MOD, &xLineSign,IFX_F_DEFAULT))
					{
                				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                                  "[%s:%s:%d] [%d] Unable to set values of all "
                        			  	  "parameters\n",__FILE__,  __func__, __LINE__, iRet);
					}
				}
			}
			ifx_vmapi_freeObjectList(&xLineSign,IFX_VMAPI_VL_SIGNALING);
		}
	        break;

            case OID_IGD_S_VS_VP_L_PHYREFERENCELIST:
								ifx_AssociateEndpts(&xVoiceLine,pxParamVal[iCnt].Value);
              break;
#ifdef DECT_SUPPORT1
						case OID_IGD_S_VS_VP_L_DECTHANDSETREFERENCELIST:
							printf("RefereceList is %s\n",pxParamVal[iCnt].Value);
							{
								char8 *pcTemp,*pcCurr;         
								uchar8 ucId;
								int32 j=0;
     						uchar8 XArray[2*IFX_VMAPI_MAX_VOICE_INTERFACES+1]={'\0'};
     							
	 							pcCurr = pxParamVal[iCnt].Value;
								while (pcCurr !=NULL) {                              
									char8 acIpei[36]= {'\0'}; 
									pcTemp = strchr(pcCurr,',');
									if(pcTemp != NULL){
										strncpy(acIpei,pcCurr,(pcTemp-pcCurr));
										if(IFX_VMAPI_SUCCESS == ifx_GetDectEndPtIdFromIPEI(acIpei,&ucId))
										{
       								sprintf(&XArray[j],"%d",ucId);
       								strcat(XArray,",");
       								j = strlen(XArray);
										}
										//printf("acIpei =%s Id=%d\n",acIpei,ucId);
		      					pcCurr= pcTemp+1;
									}
		    					else{
										strcpy(acIpei,pcCurr);
										if(IFX_VMAPI_SUCCESS == ifx_GetDectEndPtIdFromIPEI(acIpei,&ucId))
										{
       								sprintf(&XArray[j],"%d",ucId);
										}
										//printf("acIpei =%s Id=%d\n",acIpei,ucId);
										break;
									}		
								}/*while */
								//printf("XArray =%s\n",XArray);
#ifdef DECT_SUPPORT1
								ifx_AssociateDectEndpts(&xVoiceLine,XArray);
#endif
							}
							break;
#endif
            case OID_IGD_S_VS_VP_L_STATUS:
            case OID_IGD_S_VS_VP_L_CALLSTATE:
#ifdef IIP
            case OID_IGD_S_VS_VP_L_RINGMUTESTATUS:
#endif
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_PARAM_NOT_SUPPORTED;
                iRet = ERR_CWMP_PARAM_NOT_SUPPORTED;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Parameter Not Supported\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;  
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_L:

            /* Fill the iid structure in VOICE_LINE */
            xVoiceLine.iid.config_owner = IFX_TR69;
						
            /* Set all the VOICE_LINE  parameters using VMAPI */
            iRtn = ifx_set_VoiceLine(IFX_OP_MOD, &xVoiceLine, IFX_F_DEFAULT);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to set values of all "
                            "parameters\n", __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
            }

            break;
        default:
            /* Will never come here since already checked above */
            break;
    }

cleanup:
    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : Validate
**
**   Description      : This function validates the values of parameters in
**                      VoiceLine object.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      validated.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When validation of all parameters is
**                      successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in validating at least one parameter.
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : GetModifyDep
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
GetModifyDep(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iCnt;
    int32   iRet         = IFX_CWMP_SUCCESS;
    //int32   iRtn         = IFX_SUCCESS;
    int32   iParamOffset;
    //int32   iLength;
    char8   *psTmpVal;
    //uint32 uiOutElem=0;

    /* NOTE: For all parameters fault code is set to success by default. If error in
       validating first parameter, fault code is set to the error type and other
       parameters are not validated. */

    /* NOTE: Currently validation is performed only for parameters that have write permission.
       Other parameters are simply ignored. I think this should be fine since those
       validations are performed by the controller */ 

    /* Set the fault code to Success for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and validate the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Return a failure if the value is NULL pointer */
        if (!psTmpVal)
        {
            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
            iRet = ERR_CWMP_INVAL_PARAM_VAL;
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_S_VS_VP_L_PHYREFERENCELIST:
                break;
            case OID_IGD_S_VS_VP_L_ENABLE:
            case OID_IGD_S_VS_VP_L_DIRECTORYNUMBER:
#ifdef DECT_SUPPORT1
	    case OID_IGD_S_VS_VP_L_DECTHANDSETREFERENCELIST:
                /* Not validating. just returtning success */
#endif
                break;
            case OID_IGD_S_VS_VP_L_STATUS:
            case OID_IGD_S_VS_VP_L_CALLSTATE:
#ifdef IIP
            case OID_IGD_S_VS_VP_L_RINGMUTESTATUS:
            case OID_IGD_S_VS_VP_L_RINGVOLUMESTATUS:
#endif
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_PARAM_NOT_SUPPORTED;
                iRet = ERR_CWMP_PARAM_NOT_SUPPORTED;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Parameter Not Supported\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;  
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

cleanup:
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Validating dependency requested parameter failed\n",
                    __FILE__, __func__, __LINE__, iRet);
    }

    return (iRet);

}

/* 
** =============================================================================
**   Function Name    : IFX_VoiceLine_ChkDelDep
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_VoiceLine_ChkDelDep(IN int32 iCaller, IN ParamVal *pxParamVal,
							IN int32 iNumElem, OUT void **ppxParamStructRet,
												   OUT int32 * piNumRetElem)
{

	uint32 i=0;
	int32 iRet=0, j=0;
	uint32 uiParamPos=0;
	ParamVal *Param_DepOids=NULL;
	x_IFX_VMAPI_VoiceService xVoiceServ1;


	/*Code added so that acs can not delete line if minimum number of lines are present*/
		memset(&xVoiceServ1, 0, sizeof(xVoiceServ1));
        /* Fill the iid structure in VOICE_LINE */
        xVoiceServ1.iid.config_owner = IFX_TR69;

        iRet = ifx_get_VoiceService(&xVoiceServ1, IFX_F_DEFAULT);
        if(iRet != IFX_CWMP_SUCCESS) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [Error] ifx_get_VoiceService failed\n",
                        __func__, __LINE__);
            return ERR_CWMP_INTERNAL;
        }
          /* Get the position of the last created LineId from the LineIdList */
        while(xVoiceServ1.ucLineIdList[j] != 0)
        {
         j++;
        }
          /* Min number of lines reached. Throw an error.*/
       if( j == IFX_VMAPI_MIN_VOICE_LINES){
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [Error] MIN Voice Lines reached\n",
                        __func__, __LINE__);
			return ERR_CWMP_INTERNAL;
        }


	int32 line_event_OID[OID_LENGTH] = {0,0,0,0,0,0,0,0,
					OID_IGD_S_VS_VP_L_SIP,OID_IGD_S_VS_VP_L_SIP_ES,MAGIC_NUMBER};
	int32 line_sip_OID[OID_LENGTH] ={0,0,0,0,0,0,0,0,OID_IGD_S_VS_VP_L_SIP};
	int32 line_callfeat_OID[OID_LENGTH] ={0,0,0,0,0,0,0,0,OID_IGD_S_VS_VP_L_CF};
	int32 line_codeclist_OID[OID_LENGTH] ={0,0,0,0,0,0,0,0,
					OID_IGD_S_VS_VP_L_C,OID_IGD_S_VS_VP_L_C_L,MAGIC_NUMBER};
	int32 line_codec_OID[OID_LENGTH] ={0,0,0,0,0,0,0,0,OID_IGD_S_VS_VP_L_C};
	int32 line_vp_OID[OID_LENGTH] ={0,0,0,0,0,0,0,0,OID_IGD_S_VS_VP_L_VP};

	Param_DepOids = IFIN_CWMP_MALLOC((LINE_NO_DEP_OIDS+1)* sizeof(ParamVal));
	if(Param_DepOids == NULL){	
	  iRet = ERR_OUT_OF_MEMORY; 
		goto errorHandler;
	}

	uiParamPos = IFX_GetParamIdPos(pxParamVal->iaOID);
	memcpy((Param_DepOids+0)->iaOID,line_event_OID,(sizeof(int32)*OID_LENGTH));
	memcpy((Param_DepOids+1)->iaOID,line_sip_OID,(sizeof(int32)*OID_LENGTH));
	memcpy((Param_DepOids+2)->iaOID,line_callfeat_OID,(sizeof(int32)*OID_LENGTH));
	memcpy((Param_DepOids+3)->iaOID,line_codeclist_OID,(sizeof(int32)*OID_LENGTH));
	memcpy((Param_DepOids+4)->iaOID,line_codec_OID,(sizeof(int32)*OID_LENGTH));
	memcpy((Param_DepOids+5)->iaOID,line_vp_OID,(sizeof(int32)*OID_LENGTH));
	memcpy((Param_DepOids+6)->iaOID,pxParamVal->iaOID,
								(sizeof(int32)*(uiParamPos+1)));

	for(i=0; i <LINE_NO_DEP_OIDS; ++i)
		memcpy((Param_DepOids+i)->iaOID,pxParamVal->iaOID,
						(sizeof(int32)*(uiParamPos+1)));
		*ppxParamStructRet = (void *)Param_DepOids;
  	*piNumRetElem = LINE_NO_DEP_OIDS+1;
		return IFIN_CWMP_SUCCESS;
	
  errorHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
		
		return IFIN_CWMP_FAILURE;
		

}

/* 
** =============================================================================
**   Function Name    : IFX_VoiceLine_AddDel
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_VoiceLine_AddDel(IN int32 iCaller, IN ParamVal *pxParamVal, 
               IN int32 iNumElem, IN int32 operation)
{
  int32   iRet = IFIN_CWMP_SUCCESS;
	int32   iCnt = 0, j = 0;
	//int32 count1 = 0,x = 0;
	char sOidString[IFX_MAX_TR69_ID_LEN];
	int32   iParamOffset;
	IFX_CpeId *pxCpeIdArray = NULL;
	unsigned int uiNumCpeId;
	unsigned int uiPCpeId;
  x_IFX_VMAPI_VoiceLine xVoiceLine;
  x_IFX_VMAPI_LineCodecList xLineCodecList;
	x_IFX_VMAPI_LineSubscription xLineSubs;
  x_IFX_VMAPI_MissCallRegister xMissCallReg;
  x_IFX_VMAPI_MissCallRegEntry *xMissCallEntry;
  x_IFX_VMAPI_MissCallRegEntry *xTempMissCallEntry;
  x_IFX_VMAPI_DialCallRegister xDialCallReg;
  x_IFX_VMAPI_DialCallRegEntry *xDialCallEntry;
  x_IFX_VMAPI_DialCallRegEntry *xTempDialCallEntry;
  x_IFX_VMAPI_RecvCallRegister xRecvCallReg;
  x_IFX_VMAPI_RecvCallRegEntry *xRecvCallEntry;
  x_IFX_VMAPI_RecvCallRegEntry *xTempRecvCallEntry;
  x_IFX_VMAPI_ContactList xContactList;
  x_IFX_VMAPI_ContactListEntry *xContactListEntry;
  x_IFX_VMAPI_ContactListEntry *xTempContactListEntry;
	x_IFX_VMAPI_VoiceCodecCapabilities xVoiceCodec;
	x_IFX_VMAPI_VoiceService xVoiceServ;
    //x_IFX_VMAPI_FxsPhyIf xFXS;


  IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
              "[%s:%d] \n", __func__, __LINE__);

	memset(sOidString,0x00,IFX_MAX_TR69_ID_LEN);
	memset(&xVoiceLine,0,sizeof(xVoiceLine));

  /* Get the Parent CPE Id */
  IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT &uiPCpeId);
  xVoiceLine.iid.pcpeId.Id = uiPCpeId;

  /* if neither delete nor add operation */ 
	if((operation != OP_SETVAL_ADD)&&(operation != OP_SETVAL_DELETE)){ 
	      IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                 "[%s:%d] [Error] Invalid operation\n",
                 __func__, __LINE__);
		  return ERR_CWMP_INTERNAL;
	}		
   
  /* if delete operation */
	if(operation == OP_SETVAL_DELETE){ 
		// here the input iaOID will be igd.s.vs.1.vp.1.l.2.
    /*ignore the last value as it will be a parameter and we need 
             only till the last instance*/
    iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );

		iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId, OUT &pxCpeIdArray);
		if(iRet != IFX_CWMP_SUCCESS){
		        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                  "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                  __func__, __LINE__);

		  return ERR_CWMP_INTERNAL;
		}
		
		xVoiceLine.iid.cpeId.Id = pxCpeIdArray->uiId;
		memset(xVoiceLine.iid.tr69Id,0x00,MAX_TR69_ID_LEN);
		if(strlen(pxCpeIdArray->sSectionTag) < MAX_TAG_LEN){
		   strncpy(xVoiceLine.iid.cpeId.secName,pxCpeIdArray->sSectionTag, MAX_TAG_LEN-1);
		   IFX_CWMP_FREE(pxCpeIdArray);
		}else{
			  IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                 "[%s:%d] [Error] strcpy : mismatch in size in buffer copy\n",
                  __func__, __LINE__);
		  IFX_CWMP_FREE(pxCpeIdArray);
		  return ERR_CWMP_INTERNAL;
		}
		
    /* Fill the iid structure in VOICE_LINE */
    xVoiceLine.iid.config_owner = IFX_TR69;
		strncpy(xVoiceLine.iid.tr69Id,sOidString, MAX_TR69_ID_LEN-1);
		xVoiceLine.iid.tr69Id[MAX_TR69_ID_LEN-1] = '\0';

/* Delete the instance of MissCallRegister */
    memset(&xMissCallReg,0,sizeof(xMissCallReg));
    xMissCallReg.iid.pcpeId.Id = xVoiceLine.iid.cpeId.Id;
    xMissCallReg.iid.cpeId.Id = xVoiceLine.iid.cpeId.Id;
 	  xMissCallReg.iid.config_owner = IFX_TR69;
    iRet = ifx_get_MissCallReg(&xMissCallReg,IFX_F_DEFAULT);
    if(iRet != IFX_VMAPI_SUCCESS)
    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
            "[%s:%d] [Error] ifx_get_MissCallReg failed\n", 
              __func__, __LINE__);
			iRet = ERR_CWMP_INTERNAL;
			goto cleanup;
    }
    xMissCallEntry = xMissCallReg.pxCallRegEntries;
    xTempMissCallEntry = xMissCallReg.pxCallRegEntries;
    while(xMissCallEntry !=NULL){
       __ifx_list_GetNext((void *)&xTempMissCallEntry);
       xMissCallEntry->ucIndex=1;
       xMissCallEntry->iid.config_owner = IFX_TR69;
       if(xTempMissCallEntry == NULL){
          if(ifx_set_MissCallRegEntry(IFX_OP_DEL,xMissCallEntry,0)!= IFX_VMAPI_SUCCESS){
             IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] ifx_set_MissCallRegEntry deleting failed\n",
                    __func__, __LINE__);
             iRet = ERR_CWMP_INTERNAL;
             goto cleanup;
          }
       }else{
          if(ifx_set_MissCallRegEntry(IFX_OP_DEL,xMissCallEntry,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)
                                      != IFX_VMAPI_SUCCESS){
             IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] ifx_set_MissCallRegEntry deleting failed\n",
                    __func__, __LINE__);
             iRet = ERR_CWMP_INTERNAL;
             goto cleanup;
          }
      }
      xMissCallEntry=xTempMissCallEntry;
      }
    iRet = ifx_set_MissCallReg(IFX_OP_DEL,&xMissCallReg,
										IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
    if(iRet != IFX_VMAPI_SUCCESS)
    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
            "[%s:%d] [Error] ifx_set_MissCallReg deleting failed\n", 
              __func__, __LINE__);
			iRet = ERR_CWMP_INTERNAL;
			goto cleanup;
    }
    ifx_vmapi_freeObjectList(&xMissCallReg,IFX_VMAPI_VS_MISSCALL_REGISTER);

/* Delete the instance of DialCallRegister */
    memset(&xDialCallReg,0,sizeof(xDialCallReg));
    xDialCallReg.iid.pcpeId.Id = xVoiceLine.iid.cpeId.Id;
    xDialCallReg.iid.cpeId.Id = xVoiceLine.iid.cpeId.Id;
 	  xDialCallReg.iid.config_owner = IFX_TR69;
    iRet = ifx_get_DialCallReg(&xDialCallReg,IFX_F_DEFAULT);
    if(iRet != IFX_VMAPI_SUCCESS)
    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
            "[%s:%d] [Error] ifx_get_DialCallReg failed\n", 
              __func__, __LINE__);
			iRet = ERR_CWMP_INTERNAL;
			goto cleanup;
    }
    xDialCallEntry = xDialCallReg.pxCallRegEntries;
    xTempDialCallEntry = xDialCallReg.pxCallRegEntries;
    while(xDialCallEntry !=NULL){
       __ifx_list_GetNext((void *)&xTempDialCallEntry);
       xDialCallEntry->ucIndex=1;
       xDialCallEntry->iid.config_owner = IFX_TR69;
       if(xTempDialCallEntry == NULL){
          if(ifx_set_DialCallRegEntry(IFX_OP_DEL,xDialCallEntry,0)!= IFX_VMAPI_SUCCESS){
             IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] ifx_set_DialCallRegEntry deleting failed\n",
                    __func__, __LINE__);
             iRet = ERR_CWMP_INTERNAL;
             goto cleanup;
          }
       }else{
          if(ifx_set_DialCallRegEntry(IFX_OP_DEL,xDialCallEntry,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)
                                      != IFX_VMAPI_SUCCESS){
             IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] ifx_set_DialCallRegEntry deleting failed\n",
                    __func__, __LINE__);
             iRet = ERR_CWMP_INTERNAL;
             goto cleanup;
          }
      }
      xDialCallEntry=xTempDialCallEntry;
      }
    iRet = ifx_set_DialCallReg(IFX_OP_DEL,&xDialCallReg,
										IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
    if(iRet != IFX_VMAPI_SUCCESS)
    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
            "[%s:%d] [Error] ifx_set_DialCallReg deleting failed\n", 
              __func__, __LINE__);
			iRet = ERR_CWMP_INTERNAL;
			goto cleanup;
    }
    ifx_vmapi_freeObjectList(&xDialCallReg,IFX_VMAPI_VS_DIALCALL_REGISTER);

/* Delete the instance of RecvCallRegister */
    memset(&xRecvCallReg,0,sizeof(xRecvCallReg));
    xRecvCallReg.iid.pcpeId.Id = xVoiceLine.iid.cpeId.Id;
    xRecvCallReg.iid.cpeId.Id = xVoiceLine.iid.cpeId.Id;
 	  xRecvCallReg.iid.config_owner = IFX_TR69;
    iRet = ifx_get_RecvCallReg(&xRecvCallReg,IFX_F_DEFAULT);
    if(iRet != IFX_VMAPI_SUCCESS)
    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
            "[%s:%d] [Error] ifx_get_RecvCallReg failed\n", 
              __func__, __LINE__);
			iRet = ERR_CWMP_INTERNAL;
			goto cleanup;
    }
    xRecvCallEntry = xRecvCallReg.pxCallRegEntries;
    xTempRecvCallEntry = xRecvCallReg.pxCallRegEntries;
    while(xRecvCallEntry !=NULL){
       __ifx_list_GetNext((void *)&xTempRecvCallEntry);
       xRecvCallEntry->ucIndex=1;
       xRecvCallEntry->iid.config_owner = IFX_TR69;
       if(xTempRecvCallEntry == NULL){
          if(ifx_set_RecvCallRegEntry(IFX_OP_DEL,xRecvCallEntry,0)!= IFX_VMAPI_SUCCESS){
             IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] ifx_set_RecvCallRegEntry deleting failed\n",
                    __func__, __LINE__);
             iRet = ERR_CWMP_INTERNAL;
             goto cleanup;
          }
       }else{
          if(ifx_set_RecvCallRegEntry(IFX_OP_DEL,xRecvCallEntry,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)
                                      != IFX_VMAPI_SUCCESS){
             IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] ifx_set_RecvCallRegEntry deleting failed\n",
                    __func__, __LINE__);
             iRet = ERR_CWMP_INTERNAL;
             goto cleanup;
          }
      }
      xRecvCallEntry=xTempRecvCallEntry;
      }
    iRet = ifx_set_RecvCallReg(IFX_OP_DEL,&xRecvCallReg,
										IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
    if(iRet != IFX_VMAPI_SUCCESS)
    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
            "[%s:%d] [Error] ifx_set_RecvCallReg deleting failed\n", 
              __func__, __LINE__);
			iRet = ERR_CWMP_INTERNAL;
			goto cleanup;
    }
    ifx_vmapi_freeObjectList(&xRecvCallReg,IFX_VMAPI_VS_RECVCALL_REGISTER);

/* Delete the instance of ContactListister */
    memset(&xContactList,0,sizeof(xContactList));
    xContactList.iid.pcpeId.Id = xVoiceLine.iid.cpeId.Id;
    xContactList.iid.cpeId.Id = xVoiceLine.iid.cpeId.Id;
 	  xContactList.iid.config_owner = IFX_TR69;
    iRet=ifx_get_ContactList(&xContactList,0);
    if(iRet != IFX_VMAPI_SUCCESS)
    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
            "[%s:%d] [Error] ifx_get_ContactList deleting failed\n", 
              __func__, __LINE__);
			iRet = ERR_CWMP_INTERNAL;
			goto cleanup;
    }
    xContactListEntry = xContactList.pxContactEntries;
    xTempContactListEntry = xContactList.pxContactEntries;
    while(xContactListEntry !=NULL)
      {
       __ifx_list_GetNext((void *)&xTempContactListEntry);
       xContactListEntry->ucIndex=1;
       xContactListEntry->iid.config_owner = IFX_WEB;
       if(xTempContactListEntry == NULL){
         iRet=ifx_set_ContactListEntry(IFX_OP_DEL,xContactListEntry,0);
       	if(iRet != IFX_VMAPI_SUCCESS)
    			 {
						IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
            	"[%s:%d] [Error] ifx_set_ContactList deleting last entry failed\n", 
              	__func__, __LINE__);
						iRet = ERR_CWMP_INTERNAL;
						goto cleanup;
    				}
       }else{
        iRet=ifx_set_ContactListEntry(IFX_OP_DEL,xContactListEntry,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
    			if(iRet != IFX_VMAPI_SUCCESS)
    				{
							IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
           		 "[%s:%d] [Error] ifx_set_ContactList deleting Initial entries failed\n", 
              	__func__, __LINE__);
							iRet = ERR_CWMP_INTERNAL;
							goto cleanup;
    				}

       }
				xContactListEntry=xTempContactListEntry;
      }
    iRet = ifx_set_ContactList(IFX_OP_DEL,&xContactList,
										IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
    if(iRet != IFX_VMAPI_SUCCESS)
    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
            "[%s:%d] [Error] ifx_set_ContactList deleting failed\n", 
              __func__, __LINE__);
			iRet = ERR_CWMP_INTERNAL;
			goto cleanup;
    }
    ifx_vmapi_freeObjectList(&xContactList,IFX_VMAPI_VS_CONTACT_LIST);

		/* LineCodecList is not a TR104 object but this holds the number
		  of CodecList and the list of all the codecs. So we need to del this 
		  section also in the config file. */

	  /* Create the new instance of LineCodecList */
    memset(&xLineCodecList,0,sizeof(xLineCodecList));
    xLineCodecList.iid.cpeId.Id = xVoiceLine.iid.cpeId.Id;
    xLineCodecList.iid.pcpeId.Id = xVoiceLine.iid.cpeId.Id;
    xLineCodecList.iid.config_owner = IFX_TR69;
 	    
    iRet = ifx_set_LineCodecList(IFX_OP_DEL, &xLineCodecList,
						IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);  
    if(iRet != IFX_VMAPI_SUCCESS)
    {
	    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
            "[%s:%d] [Error] ifx_set_LineCodecList delete failed\n", 
             __func__, __LINE__);
  	  iRet = ERR_CWMP_INTERNAL;
		  goto cleanup;
    } 

		
		/* LineSubscription is not a TR104 object but this holds the number
		 * of EventSubscription number and the list of all the events. So we 
		 * need to del this section also in the config file. */

	  /* Create the new instance of LineSubscription */
    memset(&xLineSubs,0,sizeof(xLineSubs));
    xLineSubs.iid.cpeId.Id = xVoiceLine.iid.cpeId.Id;
    xLineSubs.iid.pcpeId.Id = xVoiceLine.iid.cpeId.Id;
 	  xLineSubs.iid.config_owner = IFX_TR69;
    iRet = ifx_set_LineSubscription(IFX_OP_DEL,&xLineSubs,
										IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
    if(iRet != IFX_VMAPI_SUCCESS)
    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
            "[%s:%d] [Error] ifx_set_LineSubscription delete failed\n", 
              __func__, __LINE__);
			iRet = ERR_CWMP_INTERNAL;
			goto cleanup;
    }
		
		/* call the respective VMAPI */
		iRet = ifx_set_VoiceLine( IFX_OP_DEL, &xVoiceLine, IFX_F_DEFAULT); 
		if(iRet != IFX_CWMP_SUCCESS){
		       IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                  "[%s:%d] [Error] ifx_set_VoiceLine failed\n",
                  __func__, __LINE__);
		  return ERR_CWMP_INTERNAL;
		}


		return iRet;

	}// end of delete operation

	if(operation == OP_SETVAL_ADD){	// if ADD
	  // here the input iaOID will be igd.s.vs.1.vp.1.l.2.
	  

    /*ignore the last value as it will be a parameter and we need 
              only till the last instance*/
			  memset(&xVoiceServ, 0, sizeof(xVoiceServ));
        /* Fill the iid structure in VOICE_LINE */
        xVoiceServ.iid.config_owner = IFX_TR69;

        iRet = ifx_get_VoiceService(&xVoiceServ, IFX_F_DEFAULT);
        if(iRet != IFX_CWMP_SUCCESS) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [Error] ifx_get_VoiceService failed\n",
                        __func__, __LINE__);
            iRet = ERR_CWMP_INTERNAL;
            goto cleanup;
        }
          /* Get the position of the last created LineId from the LineIdList */
        while(xVoiceServ.ucLineIdList[j] != 0)
        {
         j++;
        }
          /* Max number of lines reached. Throw an error.*/
       if( j == IFX_VMAPI_MAX_VOICE_LINES){

            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [Error] MAX Voice Lines reached\n",
                        __func__, __LINE__);
            iRet = ERR_CWMP_INTERNAL;
            goto cleanup;
        }
    iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID,sOidString);
	  strncpy(xVoiceLine.iid.tr69Id,sOidString, MAX_TR69_ID_LEN-1);
	  xVoiceLine.iid.tr69Id[MAX_TR69_ID_LEN-1] = '\0';

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

	  // fill the given parameters of this structure with the new values provided
	  for( iCnt = 0; iCnt < iNumElem; iCnt++){

	    /* Process based on the requested parameter */
	    switch (pxParamVal[iCnt].iaOID[iParamOffset])
	    {
      	case OID_IGD_S_VS_VP_L_ENABLE:
	      case OID_IGD_S_VS_VP_L_DIRECTORYNUMBER:
        case OID_IGD_S_VS_VP_L_STATUS:
        case OID_IGD_S_VS_VP_L_CALLSTATE:
#ifdef IIP
        case OID_IGD_S_VS_VP_L_RINGMUTESTATUS:
        case OID_IGD_S_VS_VP_L_RINGVOLUMESTATUS:
#endif
        case OID_IGD_S_VS_VP_L_PHYREFERENCELIST:
#ifdef DECT_SUPPORT1
				case OID_IGD_S_VS_VP_L_DECTHANDSETREFERENCELIST:
#endif
	        break;  
	      default:
             IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                       "[%s:%d] [Error] Unknown requested parameter\n",
	                       __func__, __LINE__);
				     // parameter not found
				     pxParamVal[iCnt].iFaultCode = ERR_INVAL_PARAMETER_NAME;
		         goto cleanup;
	    }
	  } 

    /* Fill the iid structure in VOICE_LINE */
    xVoiceLine.iid.config_owner = IFX_TR69;

	 	// call the VMAPI to ADD
		iRet = ifx_set_VoiceLine( IFX_OP_ADD, &xVoiceLine, IFX_F_DEFAULT); 
		if(iRet != IFX_CWMP_SUCCESS){
	      IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "[%s:%d] [Error] ifx_set_VoiceLine adding failed\n", 
                __func__, __LINE__);
			  iRet = ERR_CWMP_INTERNAL;
				goto cleanup;
		}

		/* Get the Firmware supported Voice Codec capabilities list. The same
		   would be populated for Line also */
		memset(&xVoiceCodec,0,sizeof(xVoiceCodec));
		xVoiceCodec.iid.config_owner = IFX_TR69;
		if(IFX_VMAPI_SUCCESS != ifx_get_VoiceCodecCaps(&xVoiceCodec, 0))
		{
	    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
            "[%s:%d] [Error] ifx_get_VoiceCodecCaps failed\n", 
             __func__, __LINE__);
    	return IFX_VMAPI_FAIL;/*TODO*/
		}
		ifx_vmapi_freeObjectList(&xVoiceCodec,IFX_VMAPI_CODEC_CAPABS);
		
		/* LineCodecList is not a TR104 object but this holds the number
		  of CodecList and the list of all the codecs. So we need to add this 
		  section also in the config file. */

	  /* Create the new instance of LineCodecList */
    memset(&xLineCodecList,0,sizeof(xLineCodecList));
    xLineCodecList.iid.pcpeId.Id = xVoiceLine.iid.cpeId.Id;
    xLineCodecList.iid.config_owner = IFX_TR69;
		
    xLineCodecList.uiNumCodecs = xVoiceCodec.uiNumCodecs;
    iRet = ifx_set_LineCodecList(IFX_OP_ADD, &xLineCodecList,
						IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);  
    if(iRet != IFX_VMAPI_SUCCESS)
    {
	    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
            "[%s:%d] [Error] ifx_set_LineCodecList adding failed\n", 
             __func__, __LINE__);
  	  iRet = ERR_CWMP_INTERNAL;
		  goto cleanup;
    } 

		
		/* LineSubscription is not a TR104 object but this holds the number
		 * of EventSubscription number and the list of all the events. So we 
		 * need to add this section also in the config file. */

	  /* Create the new instance of LineSubscription */
    memset(&xLineSubs,0,sizeof(xLineSubs));
    xLineSubs.iid.pcpeId.Id = xVoiceLine.iid.cpeId.Id;
 	  xLineSubs.iid.config_owner = IFX_TR69;
		xLineSubs.ucNoOfLineEvents = 0;
    iRet = ifx_set_LineSubscription(IFX_OP_ADD,&xLineSubs,
										IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
    if(iRet != IFX_VMAPI_SUCCESS)
    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
            "[%s:%d] [Error] ifx_set_LineSubscription adding failed\n", 
              __func__, __LINE__);
			iRet = ERR_CWMP_INTERNAL;
			goto cleanup;
    } 

/* Create the new instance of MissCallRegister */
    memset(&xMissCallReg,0,sizeof(xMissCallReg));
    xMissCallReg.iid.pcpeId.Id = xVoiceLine.iid.cpeId.Id;
 	  xMissCallReg.iid.config_owner = IFX_TR69;
    iRet = ifx_set_MissCallReg(IFX_OP_ADD,&xMissCallReg,
										IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
    if(iRet != IFX_VMAPI_SUCCESS)
    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
            "[%s:%d] [Error] ifx_set_MissCallReg adding failed\n", 
              __func__, __LINE__);
			iRet = ERR_CWMP_INTERNAL;
			goto cleanup;
    }
    ifx_vmapi_freeObjectList(&xMissCallReg,IFX_VMAPI_VS_MISSCALL_REGISTER);

/* Create the new instance of DialCallRegister */
    memset(&xDialCallReg,0,sizeof(xDialCallReg));
    xDialCallReg.iid.pcpeId.Id = xVoiceLine.iid.cpeId.Id;
 	  xDialCallReg.iid.config_owner = IFX_TR69;
    iRet = ifx_set_DialCallReg(IFX_OP_ADD,&xDialCallReg,
										IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
    if(iRet != IFX_VMAPI_SUCCESS)
    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
            "[%s:%d] [Error] ifx_set_DialCallReg adding failed\n", 
              __func__, __LINE__);
			iRet = ERR_CWMP_INTERNAL;
			goto cleanup;
    }
    ifx_vmapi_freeObjectList(&xDialCallReg,IFX_VMAPI_VS_DIALCALL_REGISTER);

/* Create the new instance of RecvCallRegister */
    memset(&xRecvCallReg,0,sizeof(xRecvCallReg));
    xRecvCallReg.iid.pcpeId.Id = xVoiceLine.iid.cpeId.Id;
 	  xRecvCallReg.iid.config_owner = IFX_TR69;
    iRet = ifx_set_RecvCallReg(IFX_OP_ADD,&xRecvCallReg,
										IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
    if(iRet != IFX_VMAPI_SUCCESS)
    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
            "[%s:%d] [Error] ifx_set_RecvCallReg adding failed\n", 
              __func__, __LINE__);
			iRet = ERR_CWMP_INTERNAL;
			goto cleanup;
    }
    ifx_vmapi_freeObjectList(&xRecvCallReg,IFX_VMAPI_VS_RECVCALL_REGISTER);

/* Create the new instance of ContactList */
    memset(&xContactList,0,sizeof(xContactList));
    xContactList.iid.pcpeId.Id = xVoiceLine.iid.cpeId.Id;
 	  xContactList.iid.config_owner = IFX_TR69;
    iRet = ifx_set_ContactList(IFX_OP_ADD,&xContactList,
										IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
    if(iRet != IFX_VMAPI_SUCCESS)
    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
            "[%s:%d] [Error] ifx_set_ContactList adding failed\n", 
              __func__, __LINE__);
			iRet = ERR_CWMP_INTERNAL;
			goto cleanup;
    }
    ifx_vmapi_freeObjectList(&xContactList,IFX_VMAPI_VS_CONTACT_LIST);
#ifdef LOW_END_IAD
       memset(&xVoiceServ, 0, sizeof(xVoiceServ));
        /* Fill the iid structure in VOICE_LINE */
        xVoiceServ.iid.config_owner = IFX_TR69;

        iRet = ifx_get_VoiceService(&xVoiceServ, IFX_F_DEFAULT);
        if(iRet != IFX_CWMP_SUCCESS) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [Error] ifx_get_VoiceService failed\n",
                        __func__, __LINE__);
            iRet = ERR_CWMP_INTERNAL;
            goto cleanup;
        }
          /* Get the position of the last created LineId from the LineIdList */
        while(xVoiceServ.ucLineIdList[j] != 0)
        {
         j++;
        }

    memset(&xFXS,0,sizeof(xFXS));
    xFXS.xVoiceServPhyIf.ucInterfaceId = 1;
    xFXS.iid.config_owner = IFX_TR69;
    if(IFX_VMAPI_SUCCESS != ifx_get_FxsPhyInterface(&xFXS,0))
    {
        return IFX_VMAPI_FAIL;/*TODO*/
    }

    while(xFXS.ucVoiceLineIdList[x] != 0)
    {
      count1++;
      x++;
    }
    xFXS.ucVoiceLineIdList[count1] = xVoiceServ.ucLineIdList[j-1];
    if(IFX_VMAPI_SUCCESS != ifx_set_FxsPhyInterface(IFX_OP_MOD,&xFXS,
			IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
    {
        return IFX_VMAPI_FAIL;/*TODO*/
    }
#endif

    return iRet;
  }

cleanup:
  /* Perform Cleanup of unnecessary VoiceLine members */
  return (iRet);


}

/* 
** =============================================================================
**   Function Name    : IFX_VoiceLine_UpdateChildInfo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32 
IFX_VoiceLine_UpdateChildInfo(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements,IN int32 operation)
{
    int32   iRtn         = IFX_SUCCESS;
		return iRtn;
}

/* 
** =============================================================================
**   Function Name    : GetNotify
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
GetNotify(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
                 IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iRtn = IFX_SUCCESS;
    int32   iCnt = 0;
    int32   iTmpCnt = -1; /* Mandatory */
    int32   iParamOffset;
    int32   iOID;
    int32   iMemErrorFlag = 0; /* Mandatory */
    x_IFX_VMAPI_VoiceLine xVoiceLine;
		uint32 uiPCpeId;

    /* NOTE: For all parameters fault code is set to success by default. If error in
       validating first parameter, fault code is set to the error type and other
       parameters are not validated. */
    /* NOTE: For all parameters value is set to NULL by default. */

    /* Set the fault code to Success and value to NULL pointer for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
        (pxParamVal[iCnt]).Value = NULL;
    }

    //printf("Depth is %d\n",IFX_GetObjectDepth(pxParamVal->iaOID));

    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);

    memset(&xVoiceLine, 0, sizeof(x_IFX_VMAPI_VoiceLine));

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_L:{

            char8 sOidString[100] = {0};
            IFX_CpeId *pxCpeIdArray = NULL;
            unsigned int uiNumCpeId;

    				/* Get the Parent CPE Id */
    				IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT &uiPCpeId);
    				xVoiceLine.iid.pcpeId.Id = uiPCpeId;

            /*ignore the last value as it will be a parameter and we need 
              only till the last instance*/
            iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );

            strcpy(xVoiceLine.iid.tr69Id,sOidString);

            /*Get the CPE Id from the corresponding tr69 Id */
            iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId,
                               OUT &pxCpeIdArray);
            if(iRet != IFX_CWMP_SUCCESS){
                   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                   __func__, __LINE__);

              return ERR_CWMP_INTERNAL;
            }
            //printf("CPEID is %d\n",pxCpeIdArray->uiId);   

            /* Fill the CPE ID of the object instance */
            xVoiceLine.iid.cpeId.Id = pxCpeIdArray->uiId;
            xVoiceLine.iid.config_owner = IFX_TR69;

            /* Get all the Voice Line parameters using VMAPI */
            iRtn = ifx_get_VoiceLine(&xVoiceLine, IFX_F_DEFAULT);

            IFX_CWMP_FREE(pxCpeIdArray);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to get values of all "
                            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto cleanup;
            }
            }
            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
	  case OID_IGD_S_VS_VP_L_ENABLE:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(10);

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }


               /* Copy the value to allocated area */
               if(xVoiceLine.ucState ==  IFX_VMAPI_VL_STATE_DISABLED)
                 strcpy((pxParamVal[iCnt]).Value, "Disabled");
               else if(xVoiceLine.ucState == IFX_VMAPI_VL_STATE_QUIESCENT)
                 strcpy((pxParamVal[iCnt]).Value, "Quiscent");
               else if(xVoiceLine.ucState == IFX_VMAPI_VL_STATE_ENABLED)
                 strcpy((pxParamVal[iCnt]).Value, "Enabled");
 
            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
							break;  
          case OID_IGD_S_VS_VP_L_DIRECTORYNUMBER:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(xVoiceLine.acDirName));

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                strcpy((pxParamVal[iCnt]).Value,xVoiceLine.acDirName);
            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
							break;
          case OID_IGD_S_VS_VP_L_STATUS:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(14);
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }


              /* Copy the value to allocated area */
              if(xVoiceLine.ucLineStatus == 
                           IFX_VMAPI_VL_STATUS_DISABLED)
                strcpy((pxParamVal[iCnt]).Value, "Disabled");
              else if(xVoiceLine.ucLineStatus == 
                           IFX_VMAPI_VL_STATUS_INITIALISING)
                strcpy((pxParamVal[iCnt]).Value, "Initialising");
              else if(xVoiceLine.ucLineStatus == 
                           IFX_VMAPI_VL_STATUS_REGISTERING)
                strcpy((pxParamVal[iCnt]).Value, "Registering");
              else if(xVoiceLine.ucLineStatus == 
                           IFX_VMAPI_VL_STATUS_UNREGISTERING)
                strcpy((pxParamVal[iCnt]).Value, "Unregistering");
              else if(xVoiceLine.ucLineStatus == 
                           IFX_VMAPI_VL_STATUS_ERROR)
                strcpy((pxParamVal[iCnt]).Value, "Error");
              else if(xVoiceLine.ucLineStatus == 
                           IFX_VMAPI_VL_STATUS_TESTING)
                strcpy((pxParamVal[iCnt]).Value, "Testing");
              else if(xVoiceLine.ucLineStatus == 
                           IFX_VMAPI_VL_STATUS_QUIESCENT)
                strcpy((pxParamVal[iCnt]).Value, "Quiescent");
              else if(xVoiceLine.ucLineStatus == 
                           IFX_VMAPI_VL_STATUS_UP)
                strcpy((pxParamVal[iCnt]).Value, "Up");

            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
							break;  
          case OID_IGD_S_VS_VP_L_CALLSTATE:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(14);

              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

               /* Copy the value to allocated area */
              if(xVoiceLine.ucCallStatus == 
                              IFX_VMAPI_CALL_STATUS_IDLE)
                strcpy((pxParamVal[iCnt]).Value, "Idle");
              else if(xVoiceLine.ucCallStatus == 
                              IFX_VMAPI_CALL_STATUS_CALLING)
                strcpy((pxParamVal[iCnt]).Value, "Calling");
              else if(xVoiceLine.ucCallStatus == 
                              IFX_VMAPI_CALL_STATUS_RINGING)
                strcpy((pxParamVal[iCnt]).Value, "Ringing");
              else if(xVoiceLine.ucCallStatus == 
                              IFX_VMAPI_CALL_STATUS_CONNECTING)
                strcpy((pxParamVal[iCnt]).Value, "Connecting");
              else if(xVoiceLine.ucCallStatus == 
                              IFX_VMAPI_CALL_STATUS_INCALL)
                strcpy((pxParamVal[iCnt]).Value, "Incall");
              else if(xVoiceLine.ucCallStatus == 
                              IFX_VMAPI_CALL_STATUS_HOLD)
                strcpy((pxParamVal[iCnt]).Value, "Hold");
              else if(xVoiceLine.ucCallStatus == 
                              IFX_VMAPI_CALL_STATUS_DISCONNECTING)
                strcpy((pxParamVal[iCnt]).Value, "Disconnecting");

            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
							break;  
          case OID_IGD_S_VS_VP_L_PHYREFERENCELIST:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                 sizeof(xVoiceLine.ucAssocVoiceInterface));

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                /* Copy the value to allocated area */
                  //strcpy((pxParamVal[iCnt]).Value, 
                    //                 xVoiceLine.ucAssocVoiceInterface);
                  sprintf((pxParamVal[iCnt]).Value, "%d", 
                                     xVoiceLine.ucAssocVoiceInterface[0]);

            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
							break; 
#ifdef IIP 
	  case OID_IGD_S_VS_VP_L_RINGMUTESTATUS:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                /* Copy the value to allocated area */
                if(xVoiceLine.bEnableRingMute ==  
                                  IFX_VMAPI_VL_STATE_DISABLED)
                  strcpy((pxParamVal[iCnt]).Value, "false");
                else if(xVoiceLine.bEnableRingMute == 
                                  IFX_VMAPI_VL_STATE_ENABLED)
                  strcpy((pxParamVal[iCnt]).Value, "true");

            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
							break;  
          case OID_IGD_S_VS_VP_L_RINGVOLUMESTATUS:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uchar8));

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                /* Copy the value to allocated area */
                sprintf((pxParamVal[iCnt]).Value, "%d", 
                                       xVoiceLine.ucRingVolume);

            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
							break; 
#endif
          default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                iTmpCnt = iCnt;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
            goto cleanup;
        }
    }

cleanup:

    if (iMemErrorFlag)
    {
        (pxParamVal[iCnt]).iFaultCode = ERR_OUT_OF_MEMORY;
        iRet = ERR_OUT_OF_MEMORY;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Allocation Failure\n",
                     __FILE__, __func__, __LINE__, iRet);
    }

    if (iRet != IFX_CWMP_SUCCESS)
    {

        /* Free the allocation for value, if any. Also set the fault code. */
        for (iCnt = 0; iCnt < iElements; iCnt++)
        {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
            if (iTmpCnt != iCnt) 
            {
                (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
            }
        }
    }

    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : SetAttrInfo
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
  int32 iRet,i;
	iRet = IFX_SetAttributesInfo(pxOI, pxParamVal, iElements);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;

	for(i=0; i < iElements; i++)
		IFX_CWMP_FREE(pxParamVal->Value);

	return IFX_CWMP_SUCCESS;

	errorHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
		return iRet;
}

/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : IFX_VoiceLine_Init
**
**   Description      : This function is called by the controller. It registers
**                      the function responsible for handling VoiceLine object
**                      with data structure. It also performs initializations
**                      specific to VoiceLine object.
**
**   Parameters       : No Parameters. 
**
**   Return Value     : IFX_CWMP_SUCCESS - When VoiceLine object is initialized
**                      successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in initializing VoiceLine object.
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_VoiceLine_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the VoiceLine module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_VOICELINE_OBJ, IFX_VoiceLineCfg);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_VOICELINE_OBJ);
        goto cleanup;
    }

cleanup:
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_VoiceLineCfg
**
**   Description      : This function is called by the controller. It handles
**                      the VoiceLine object and performs  based on requested
**                      operations/suboperations by invoking internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_VoiceLineCfg(IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
             OUT void **ppRet, OUT int32 *piNumRetElem)
{
    int32       iRet           = IFX_CWMP_SUCCESS;
    ParamVal    *pxParamVal    = (ParamVal *)pParamList;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                "[%s:%d] \n", __func__, __LINE__);
    /* Process based on type of Operation */
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:

                    /* Get values of all the requested parameters */
                    iRet = GetVal(pxOI->iCaller, pxParamVal,
                                               iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_GETVAL_NOTIFICATION:

                    /* Set attribute values for all the requested parameters */
                    iRet = GetNotify(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_SETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:

                    /* Validate values of all the requested parameters */
                    iRet = Validate(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:

                   /* Check modify dependency of all requested parameters */
                    iRet = GetModifyDep(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_MODIFY:

                    /* Set values of all the requested parameters */
                    iRet = Modify(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ATTRINFO:

                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_ADD:
                    iRet = IFX_VoiceLine_AddDel(pxOI->iCaller,pxParamVal, 
                              iNumElem, OP_SETVAL_ADD); // 1 = add 0=del

                    /* Check for error */
                    if (iRet != IFIN_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }


                   break;
                case OP_SETVAL_CHK_DEL_DEP:
									 iRet = IFX_VoiceLine_ChkDelDep(pxOI->iCaller, pxParamVal,
							                iNumElem, ppRet, piNumRetElem);

									 /* Check for error */
                    if (iRet != IFIN_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }


                    //*ppRet = (ParamVal *)IFX_CWMP_MALLOC(sizeof(ParamVal));
			              //memcpy(*ppRet, pParamList, sizeof(ParamVal));
			              //*piNumRetElem = 1;
                    //return IFX_CWMP_SUCCESS;

                   break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                
                    return IFX_CWMP_SUCCESS;
                   break;
                case OP_SETVAL_DELETE:
                    iRet = IFX_VoiceLine_AddDel(pxOI->iCaller,pxParamVal, 
                              iNumElem, OP_SETVAL_DELETE); // 1 = add 0=del

                    /* Check for error */
                    if (iRet != IFIN_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }


                   break;

                case OP_SETVAL_FREE:
                    return IFX_CWMP_SUCCESS;

                   break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_UPDATE_CHILDINFO:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
										case OP_UPDATE_CHILDINFO_ADD: 
                    if((iRet =IFX_VoiceLine_UpdateChildInfo(pxOI,pxParamVal,
                                       iNumElem,OP_SETVAL_ADD)) != IFX_CWMP_SUCCESS)
				 	          {
							         IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                          	"%s:%d OP_UPDATE_CHILDINFO_ADD failed!\n", __func__, __LINE__);
							          goto cleanup;
								
					          }
                  break;
                case OP_UPDATE_CHILDINFO_DEL:
                    if((iRet =IFX_VoiceLine_UpdateChildInfo(pxOI,pxParamVal,
                                   iNumElem,OP_SETVAL_DELETE)) != IFX_CWMP_SUCCESS)
				 	          {
							          IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                         "%s:%d OP_UPDATE_CHILDINFO_DEL failed!\n", __func__, __LINE__);
							          goto cleanup;

					          }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid Operation\n",
                         __func__, __LINE__, iRet);
            goto cleanup;
    }

cleanup:
    return (iRet);
}
