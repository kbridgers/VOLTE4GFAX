/**************************************************************************
 **   FILE NAME       : IFX_SIP_SecondLevelDecoder.c
 **   PROJECT         : SIP signaling
 **   MODULES         : SIP DECODER
 **   SRC VERSION     : V2.1 
 **   DATE            : 15-12-2004
 **   AUTHOR          : Murali
 **   DESCRIPTION     : This file contains all the functions of Second 
 **                     level decoding
 **                     For classification refer design document
 **   COMPILER        : gcc 
 **   REFERENCE       : Coding guide lines
 **   COPYRIGHT       : Copyright (c) 2004
 **                     Infineon Technologies AG, st. Martin Strasse 53;
 **                     81669 Munchen, Germany
 **
 **   Any use of this software is subject to the conclusion of a respective
 **   License agreement. Without such a License agreement no rights to the
 **   software are granted

 **  Version Control Section  **        
 **   $Author$    
 **   $Date$      
 **   $Revisions$ 
 **   $Log$       Revision history
***********************************************************************/ 
#include "IFX_DEVM_SIPTypes.h"
#include "IFX_DEVM_SIPDecoderImport.h"
#include "IFX_SIP_SecondLevelDecoder.h"
#include "IFX_DEVM_List.h"

#define IFX_SIP_TEMP_MAX 256

char8 vtblszUriParams[IFX_SIP_URI][15] =
{
  "transport=", "user=", "method=", "ttl=", "maddr=", "comp="
};

char8 vtblszDivParams[IFX_SIP_DIV_EXTN][15] =
{
  "reason=", "counter=", "limit=", "privacy=", "screen="
};

char8 vtblszDivReason[IFX_SIP_DIV_TOKEN][15] =
{
  "unknown", "user-busy", "no-answer", "unavailable", "unconditional", 
  "time-of-day", "do-not-disturb", "deflection", "follow-me", 
  "out-of-service", "away"
};

char8 vtblszDivPrivacy[IFX_SIP_DIV_PRIVTOKEN][15] =
{
  "full", "name", "uri", "off"
};


char8 vtblszMethod[][10] =
{
  "INVITE",
  "ACK",
  "BYE",
  "CANCEL",
#ifdef RFC_3262
  "PRACK",
#endif /* RFC_3262 */
#ifdef RFC_3311
  "UPDATE",
#endif
  "INFO",
  "OPTIONS",
  "REFER",
  "SUBSCRIBE",
  "NOTIFY",
  "MESSAGE",
#ifdef RFC_3903
  "PUBLISH",
#endif/*RFC_3903*/
  "REGISTER"  
};

/******************************************************************
*  Function Name:  IFX_SIP_strncasecmp
*  Description  :  Compares two strings ignoring the case
*  Input Values :  Two strings and the number of bytes to compare
*  Output Values:  None
*  Return Value :  0 on success
*  Notes        :  
*********************************************************************/

int32
IFX_SIP_strncasecmp(const char* pszString1,
                     const char* pszString2,
                     int32 iSize)
{
  return strncasecmp(pszString1,pszString2,iSize);
}

/******************************************************************
*  Function Name:  IFX_SIP_strcasecmp
*  Description  :  Compares two strings ignoring the case
*  Input Values :  Two strings and the number of bytes to compare
*  Output Values:  None
*  Return Value :  0 on success
*  Notes        :  
*********************************************************************/

int32
IFX_SIP_strcasecmp(const char* pszString1,
                    const char* pszString2)
{
  return strcasecmp(pszString1,pszString2);
}

/******************************************************************
*  Function Name:  IFX_SIP_strchr
*  Description  :  checks for a delimiter and returns ptr to first occurance
*  Input Values :  Two strings and the number of bytes to compare
*  Output Values:  None
*  Return Value :  0 on success
*  Notes        :  
*********************************************************************/

char8*
IFX_SIP_strchr(IN  char8* pcStartIndex,
                IN  char8* pcEndIndex,
                IN  int32 ifind)
{
  char8 cTemp, * pcCurrPos;
  cTemp = *pcEndIndex;
  *pcEndIndex = '\0';
  pcCurrPos = strchr(pcStartIndex,ifind);
  *pcEndIndex = cTemp;
  return pcCurrPos;
}
/******************************************************************
*  Function Name:  IFX_SIP_strtok
*  Description  :  Checks for occurance of any of the tokens in the 
*                  token list, and returns the same on finding. 
*  Input Values :  Start and end indices, tokens to check out for
*  Output Values:  Matched location
*  Return Value :  Matched Token/IFX_SIP_TOKEN_NOTFOUND
*  Notes        :  This function checks for the presence of the tokens
*                  on matching returns the token matched 
*********************************************************************/

char8
IFX_SIP_strtok(IN  char8* pcStartIndex,
                IN  char8* pcEndIndex,
                OUT char8** pcMatchedLoc,
                IN  const char* tok)
{
  uint32 i;
  char8* pcCurrPos; 
  pcCurrPos = pcStartIndex;
  while(pcCurrPos < pcEndIndex){
    for(i = 0; i < strlen(tok); i++){
      if(*pcCurrPos == tok[i]){
        *pcMatchedLoc = pcCurrPos;
        return tok[i];
      }
    }
    pcCurrPos++;
  }
  return IFX_SIP_TOKEN_NOTFOUND;
}

/******************************************************************
*  Function Name:  IFX_SIP_FindNonEscapedQuote
*  Description  :  in quoted-string, many characters can be escaped
*          This function finds the first non-escaped Quote  
*  Input Values :  Beginning and end of the string to be searched
*  Output Values:  Pointer to non-escaped Quote
*  Return Value :  ptr to " on success else NULL
*  Notes        :  
*********************************************************************/
char8*
IFX_SIP_FindNonEscapedQuote(IN  char8* pcStartIndex,
                             IN  char8* pcEndIndex)
{
  char8* pcTempStart, * pcCurrPos;
  int32 i = 1;

  pcTempStart = pcStartIndex;

  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'\"');
  /* Check if the first one matches */
  if(pcCurrPos == pcTempStart){
    return pcTempStart;
  }
  /* If there is no Quote */
  if(pcCurrPos == NULL){
    return NULL;
  }

  /* count the number of preceeding '\' */
  while(1){
    if(strncmp((pcCurrPos - i),"\\",1) == 0){
      i++;
    }
    else{
      /* the '"' was not escaped */
      if(i % 2 == 1){
        return pcCurrPos;
      }
      /* else continue with the next '"' */
      pcCurrPos = IFX_SIP_strchr(pcCurrPos + 1,pcEndIndex,'\"');
      if(pcCurrPos == NULL){
        return NULL;
      }
      i = 1;
    }

    if((pcCurrPos - i) == (pcTempStart - 1)){
      if(*pcTempStart == '\\'){
        i++;
      }
      if(i % 2 == 0){
        return pcCurrPos;
      }
      else{
        pcTempStart = pcCurrPos + 1; 
        pcCurrPos = IFX_SIP_strchr(pcCurrPos + 1,pcEndIndex,'\"');
        if(pcCurrPos == NULL){
          return NULL;
        }
        i = 1;
      }
    }
  }
  return NULL;
}

/******************************************************************
*  Function Name:  IFX_SIP_FindDelimWhenQuotesRPresent
*  Description  :  Find the delimiters when Quotes are present  
*  Input Values :  Beginning and end of the string to be searched
*  Output Values:  Pointer to the delimeter if present, 
*          ptr after removing spaces
*  Return Value :  Success or failure
*  Notes        :  
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_FindDelimWhenQuotesRPresent(IN  char8* pcStartIndex,
                                     IN  char8* pcEndIndex,
                                     IN  char8 cDelim,
                                     OUT char8** pcCurrPos,
                                     OUT char8** pcTempEnd,
                                     OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, cRet, acDelim[3];
  pcTempStart = pcStartIndex;
  acDelim[0] = cDelim;
  acDelim[1] = '\"';
  acDelim[2] = '\0';
  /*For Handling Delimiters within the quotes */
  do{
    cRet = IFX_SIP_strtok(pcTempStart,pcEndIndex,pcCurrPos,acDelim);
    if(cRet == '\"'){
      pcTempStart = *pcCurrPos + 1;
      *pcCurrPos = IFX_SIP_FindNonEscapedQuote(pcTempStart,pcEndIndex); 
      if(*pcCurrPos == NULL){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
        strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
        return IFX_SIP_FAILURE;
      }
      pcTempStart = *pcCurrPos + 1;
    }
    else if(cRet == cDelim){
      *pcTempEnd = *pcCurrPos;
      /* Remove any Trailing Spaces */
      while((*(*pcTempEnd - 1) == ' ') || (*(*pcTempEnd - 1) == '\t')){
        (*pcTempEnd)--;
        if(*pcTempEnd < pcTempStart){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
          return IFX_SIP_FAILURE;
        }
      }
      break;
    }
    else{
      *pcTempEnd = pcEndIndex;
      *pcCurrPos = NULL;
      break;
    }
  }
  while(1); 
  return IFX_SIP_SUCCESS;
}
#ifdef RFC_3325
/******************************************************************
*  Function Name:  IFX_SIP_DecodeIdentityParam
*  Description  :  Decodes the  P-Asserted and P-Preferred ID
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeIdentityParam(IN  char8* pcStartIndex,
                            IN  char8* pcEndIndex,
                            OUT x_IFX_SIP_IdentityParam* pxIdentityParam,
                            OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcCurrPos, * pcTempStart, * pcTempEnd;
  int32 iRet;

  pcTempStart = pcStartIndex;

  if(*pcTempStart == '\"'){
    pcCurrPos = IFX_SIP_FindNonEscapedQuote((pcTempStart + 1),pcEndIndex);
    if(pcCurrPos == NULL){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid message format");
      return IFX_SIP_FAILURE;
    }
    pcTempEnd = pcCurrPos + 1;
    pcCurrPos = IFX_SIP_strchr(pcTempEnd,pcEndIndex,'<');
  }
  else{
    pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'<');
  }

  if(pcCurrPos != NULL){
    pxIdentityParam->xAddrType.eAddrType = IFX_SIP_NAMEADDR;
    pcTempEnd = pcCurrPos;

    /* Remove any Trailing Spaces */
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd < pcTempStart){
        /* Display name absent */
        break;
      }
    }

    if((pcTempEnd - pcTempStart) > 0){
      if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN)){
        pxSipError->eDecodeErr = IFX_SIP_DISPLAYNAME_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Display Name exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxIdentityParam->xAddrType.uxAddrType.xNameAddr.szDisplayName,
              pcTempStart,
              (pcTempEnd - pcTempStart));
      pxIdentityParam->xAddrType.uxAddrType.xNameAddr.
                           szDisplayName[(pcTempEnd - pcTempStart)] = '\0';

      /* Validate Display Name */
      if(IFX_SIP_ValidateDisplayName(pxIdentityParam->xAddrType.uxAddrType.
        xNameAddr.szDisplayName) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_DISPLAYNAME;
        strcpy(pxSipError->szErrorDesc,"Invalid Display Name");
        return IFX_SIP_FAILURE;
      }
    }

    pcCurrPos++;
    pcTempStart = pcCurrPos;
    pcTempEnd = IFX_SIP_strchr(pcTempStart,pcEndIndex,'>');
    iRet = IFX_SIP_DecodeURI(pcTempStart,pcTempEnd,&pxIdentityParam->
      xAddrType.uxAddrType.xNameAddr.xAddrSpec,pxSipError);
    if(iRet != IFX_SIP_SUCCESS){
      return iRet;
    }
    pcTempEnd++; /* as it points to > */
    /* Check if only spaces are present after > */
    while(pcTempEnd < pcEndIndex){
      if((*pcTempEnd == ' ') || (*pcTempEnd == '\t')){
        pcTempEnd++;
        continue;
      }
      else{
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid message format");
        return IFX_SIP_FAILURE;
      }
    }
  }
  else{
    pxIdentityParam->xAddrType.eAddrType = IFX_SIP_ADDRSPEC;
    pcTempEnd = pcEndIndex;
    iRet = IFX_SIP_DecodeURI(pcTempStart,pcTempEnd,&pxIdentityParam->
      xAddrType.uxAddrType.xAddrSpec,pxSipError);
    if(iRet != IFX_SIP_SUCCESS){
      return iRet;
    }
  }
  return IFX_SIP_SUCCESS;
}
#endif /*RFC_3325*/
#ifdef RFC_3327
/******************************************************************
*  Function Name:  IFX_SIP_DecodeSecurityMechanism
*  Description  :  Decodes the  Security mechanism
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeSecurityMechanism(IN  char8* pcStartIndex,
                            IN  char8* pcEndIndex,
                            OUT x_IFX_SIP_SecurityMechanism* pxSecMech,
                            OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcCurrPos, * pcTempEnd;
  int32 iSecMechCount;
  char8 acTemp[IFX_SIP_MAX_TOKEN];
  char8 cSechName = 0;

  /* Remove any Leading White Spaces */
  pcTempStart = pcStartIndex;
  while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
    pcTempStart++;
    if(pcTempStart > pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
      return IFX_SIP_FAILURE;
    }
  }

  /* Handle multiple instances of Security-Mechanism-Params */
  do {
    /* Remove any Leading white spaces */
    while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
      pcTempStart++;
      if(pcTempStart > pcEndIndex){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
        return IFX_SIP_FAILURE;
      }
    }
  
    iSecMechCount = pxSecMech->iNumSecMechParam;
  
    /* Check if the number of instances are within limit */
    if(iSecMechCount >= IFX_SIP_MAX_SECURITYMECH_PARAM){
      pxSipError->eDecodeErr = IFX_SIP_MAXSECMECHPARAM_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Max Security param Exceeded");
      return IFX_SIP_FAILURE;
    }
  
    /* Handling of ; within quotes for */
    if(IFX_SIP_FindDelimWhenQuotesRPresent(pcTempStart,
                                            pcEndIndex,
                                            ';',
                                            &pcCurrPos,
                                            &pcTempEnd,
                                            pxSipError) == IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }

    /* Get the mechanism name */	
    if (cSechName == 0) {
      if (pcCurrPos == NULL) {
        strncpy(acTemp, pcTempStart, (pcEndIndex - pcTempStart));
        acTemp[(pcEndIndex - pcTempStart)] = '\0';
        strcpy(pxSecMech->secMechName, acTemp);
      }
      else {
        strncpy(acTemp, pcTempStart, (pcTempEnd - pcTempStart));
        acTemp[(pcTempEnd - pcTempStart)] = '\0';
        strcpy(pxSecMech->secMechName, acTemp);
      }
      cSechName = 1;
    }
    else {
      /* Decode the Security-Mechanism parameters */
      if(IFX_SIP_DecodeSecurityMechParam(pcTempStart,pcTempEnd,&pxSecMech->
        axSecMechParam[iSecMechCount],pxSipError) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
     
      /* Increment the number of Security-Mechanism parameters */
      pxSecMech->iNumSecMechParam++;
    }
	
    if(pcCurrPos == NULL){
      /* Quit as there are no more instances */
      break;
    }
    else{
      /* Re-initialize pcTempStart */
      pcTempStart = pcCurrPos + 1;
    }
  }
  while (1);
  
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeDigestVerify
*  Description  :  Decodes the Digest Verify Security Mechanism Parameter
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeDigestVerify(IN  char8* pcStartIndex,
                            IN  char8* pcEndIndex,
                            OUT char8* pcDigestVerify,
                            OUT x_IFX_SIP_Error* pxSipError)
{
  char8 *pcTempStart, *pcCurrPos, *pcTempEnd;
  char8 acTemp[IFX_SIP_MAX_DIGEST_VERIFY] = { 0 };
  uchar8 ucTempCount;
  
  /* Remove any Leading White Spaces */
  pcTempStart = pcStartIndex;
  while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
    pcTempStart++;
    if(pcTempStart > pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
      return IFX_SIP_FAILURE;
    }
  }

  /* Remove any trailing white spaces */
  while((*(pcEndIndex - 1) == ' ') || (*(pcEndIndex - 1) == '\t')){
    pcEndIndex--;
    if(pcTempStart > pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
      return IFX_SIP_FAILURE;
    }
  }

  if(*pcTempStart != '\"'){
    pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
    strcpy(pxSipError->szErrorDesc,"Invalid message format");
    return IFX_SIP_FAILURE;
  }

  pcTempStart++;
  
  pcCurrPos = IFX_SIP_FindNonEscapedQuote((pcTempStart + 1),pcEndIndex);
  if(pcCurrPos == NULL){
    pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
    strcpy(pxSipError->szErrorDesc,"Invalid message format");
    return IFX_SIP_FAILURE;
  }

  pcTempEnd = pcCurrPos - 1;
  if ((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_DIGEST_VERIFY) {
    pxSipError->eDecodeErr = IFX_SIP_MAXDIGVERIFY_EXCEEDED;
    strcpy(pxSipError->szErrorDesc,"Digest Verify Token exceeded");
    return IFX_SIP_FAILURE;
  }

  ucTempCount = 0;
  while (pcTempStart <= pcTempEnd) {
    if (isdigit(*pcTempStart) || (*pcTempStart >= 0x61 && *pcTempStart <= 0x66)) {
      acTemp[ucTempCount] = *pcTempStart;
      pcTempStart++, ucTempCount++;
    }
    else {
	return IFX_SIP_FAILURE;
    }
  }
  acTemp[ucTempCount] = '\0';
  strcpy(pcDigestVerify, acTemp);

  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeSecurityMechParam
*  Description  :  Decodes the  Security mechanism parameters
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeSecurityMechParam(IN  char8* pcStartIndex,
                            IN  char8* pcEndIndex,
                            OUT x_IFX_SIP_SecMechParam* pxSecMech,
                            OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcCurrPos, * pcTempEnd;
  char8 acTemp[IFX_SIP_MAX_TOKEN];
  
  /* Remove any Leading White Spaces */
  pcTempStart = pcStartIndex;
  while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
    pcTempStart++;
    if(pcTempStart > pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
      return IFX_SIP_FAILURE;
    }
  }

  /* Handling of , within quotes for genvalue in generic params */
  if(IFX_SIP_FindDelimWhenQuotesRPresent(pcTempStart,
                                          pcEndIndex,
                                          '=',
                                          &pcCurrPos,
                                          &pcTempEnd,
                                          pxSipError) == IFX_SIP_FAILURE) {
    return IFX_SIP_FAILURE;
  }

  if (pcCurrPos == NULL) {
    pxSecMech->ucSecMechParamType = IFX_SIP_SECMECHPARAM_EXT;
    if (IFX_SIP_DecodeGenericParams(pcTempStart,pcEndIndex,
	          &pxSecMech->xGenericParam,pxSipError) == IFX_SIP_FAILURE) {
      return IFX_SIP_FAILURE;	
    }
  }
  else {
    strncpy(acTemp, pcTempStart, (pcTempEnd - pcTempStart) + 0);
    acTemp[(pcTempEnd - pcTempStart) + 0] = '\0';
    if (IFX_SIP_strcasecmp(acTemp, "q") == 0) { /* preference */
   	  pcTempStart = pcCurrPos + 1;
	    pxSecMech->ucSecMechParamType = IFX_SIP_SECMECHPARAM_PREF;
	    if (IFX_SIP_DecodeQValue(pcTempStart, pcEndIndex, 
		               &pxSecMech->preference, pxSipError) == IFX_SIP_FAILURE) {
	      return IFX_SIP_FAILURE;
      }
    }
    else if (IFX_SIP_strcasecmp(acTemp, "d-alg") == 0) { /* d-alg header */
	    pcTempStart = pcCurrPos + 1;
	    pxSecMech->ucSecMechParamType = IFX_SIP_SECMECHPARAM_DIGEST_ALGO;
	    if (IFX_SIP_DecodeToken(pcTempStart, pcEndIndex, 
		    pxSecMech->digestAlgo, pxSipError) == IFX_SIP_FAILURE) {
	      return IFX_SIP_FAILURE;
      }	
    }
    else if (IFX_SIP_strcasecmp(acTemp, "d-qop") == 0) { /* d-qop header */
      pcTempStart = pcCurrPos + 1;
	    pxSecMech->ucSecMechParamType = IFX_SIP_SECMECHPARAM_DIGEST_QOP;
	    if (IFX_SIP_DecodeToken(pcTempStart, pcEndIndex, 
		    pxSecMech->digestQop, pxSipError) == IFX_SIP_FAILURE) {
	      return IFX_SIP_FAILURE;
      }	
    }
    else if (IFX_SIP_strcasecmp(acTemp, "d-ver") == 0) { /* d-ver header */
	    pcTempStart = pcCurrPos + 1;
	    pxSecMech->ucSecMechParamType = IFX_SIP_SECMECHPARAM_DIGEST_VER;
	    if (IFX_SIP_DecodeDigestVerify(pcTempStart, pcEndIndex, 
		    pxSecMech->digestVer, pxSipError) == IFX_SIP_FAILURE) {
	      return IFX_SIP_FAILURE;
      }	
    }
    else { /* generic param, but decode right from the start, i.e., go backwards of "=" but just after spaces removed */ 
      pxSecMech->ucSecMechParamType = IFX_SIP_SECMECHPARAM_EXT;
      if (IFX_SIP_DecodeGenericParams(pcTempStart,pcEndIndex,
   		  &pxSecMech->xGenericParam,pxSipError) == IFX_SIP_FAILURE) {
        return IFX_SIP_FAILURE;	
      }
    }
  }
  return IFX_SIP_SUCCESS;  
}


#endif /*RFC_3327*/
/******************************************************************
*  Function Name:  IFX_SIP_DecodeToken
*  Description  :  Decodes and Validates the Token
*  Input Values :  Start and End indices 
*  Output Values:  token is decoded and stored in the string. 
*                  error info in case of failure
*  
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeToken(IN  char8* pcStartIndex,
                            IN  char8* pcEndIndex,
                            OUT char* pxToken,
                            OUT x_IFX_SIP_Error* pxSipError)
{
  char8 *pcTempStart;
  /* Remove any Leading White Spaces */
  pcTempStart = pcStartIndex;
  while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
    pcTempStart++;
    if(pcTempStart > pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
      return IFX_SIP_FAILURE;
    }
  }

  /* Remove any trailing white spaces, point to the last space if present */
  while((*(pcEndIndex - 1)== ' ') || (*(pcEndIndex - 1) == '\t')){
    pcEndIndex--;
    if(pcTempStart > pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
      return IFX_SIP_FAILURE;
    }
  }
  strncpy(pxToken, pcTempStart, (pcEndIndex - pcTempStart));
  pxToken[(pcEndIndex - pcTempStart)] = '\0';

  if (IFX_SIP_ValidateToken(pxToken) == IFX_SIP_FAILURE) {
    *pxToken = '\0';
    pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
    strcpy(pxSipError->szErrorDesc,"Invalid Gen Param Token");
    return IFX_SIP_FAILURE;	
  }
  return IFX_SIP_SUCCESS;
}


#ifdef RFC_3455
/******************************************************************
*  Function Name:  IFX_SIP_DecodeAso_Uri_Spec
*  Description  :  Decodes the  Associated URI Spec parameter
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeAso_Uri_Spec(IN  char8* pcStartIndex,
                            IN  char8* pcEndIndex,
                            OUT x_IFX_SIP_Aso_Uri_Spec* pxAsoUriSpec,
                            OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcTempEnd, *pcCurrPos;
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  x_IFX_SIP_AiParam* pxAiParam;
  x_IFX_SIP_NameAddr* pxNameAddr;
  uint32 uiErrCode;

  pcTempStart = pcStartIndex;
  pcTempEnd = pcEndIndex;

  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'>');

  if(pcCurrPos != NULL){
    if(IFX_SIP_DecodeNameAddr(pcTempStart,(pcCurrPos + 1),
           &(pxAsoUriSpec->xNameAddr),pxSipError) == IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
#if 1
    pcTempStart = pcCurrPos + 1; /* As it is pointing to > */
    pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
    if(pcCurrPos == NULL){
      while(pcTempStart < pcEndIndex){
        if(*pcTempStart == ' ' || *pcTempStart == '\t'){
          pcTempStart++;
          continue;
        }
        else{
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid message format");
          return IFX_SIP_FAILURE;
        }
      }
      return IFX_SIP_SUCCESS;
    }
    else{
      char8* pcTemp;
      pcTemp = pcTempStart; /* As it points to > */

      /* Check for spaces after > */
      while((*pcTemp == ' ') || (*pcTemp == '\t')){
        pcTemp++;
        if(pcTemp > pcCurrPos){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid message format");
          return IFX_SIP_FAILURE;
        }
      }

      /* To check if there are only spaces between > and ; */
      if(*pcTemp != ';'){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid message format");
        return IFX_SIP_FAILURE;
      }
      pcTempStart = pcCurrPos + 1; /* As it points to ; */
    }
#endif
   }
  
#if 1
  do{
    /* Remove any leading spaces */
    while((pcTempStart < pcEndIndex) &&
          (*pcTempStart == ' ' || *pcTempStart == '\t')){
      pcTempStart++;
    }
    if(pcTempStart >= pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
      IFX_SIP_Free(pxAiParam);
      return IFX_SIP_FAILURE;
    }
    pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
    if(pcCurrPos == NULL){
      pcTempEnd = pcEndIndex;
    }
    else{
      pcTempEnd = pcCurrPos;
      /* Remove any Trailing Spaces */
      while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
        pcTempEnd--;
        if(pcTempEnd < pcTempStart){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
          IFX_SIP_Free(pxAiParam);
          return IFX_SIP_FAILURE;
        }
      }
    }
  /* Allocate for ai-param*/
  __ifx_list_add_front((void *)&pxAsoUriSpec->pxAiParam,
                        (void *)&pxAiParam,
                          sizeof(x_IFX_SIP_AiParam),&uiErrCode);
  if(uiErrCode < 0){
    pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
    strcpy(pxSipError->szErrorDesc,"Out of Memory");
    strcpy(pxSipError->szErrorDesc,"Creating Associated-URI Spec failed");
    return IFX_SIP_FAILURE;
  }
    /* Decode ai-param */
    /*eRetVal = IFX_SIP_DecodeAi_Param(pcTempStart,pcTempEnd,
                &(pxAsoUriSpec->xAiParam),
                pxSipError);*/

    eRetVal = IFX_SIP_DecodeAi_Param(pcTempStart,pcTempEnd,
                (pxAiParam),
                pxSipError);
   
    if(eRetVal == IFX_SIP_FAILURE){
      IFX_SIP_Free(pxAiParam);
      return IFX_SIP_FAILURE;
    }
    if(pcCurrPos == NULL){
      break;
    }
    else{
      pcTempStart = pcCurrPos + 1;
    }
  } while(1);
#endif
  return IFX_SIP_SUCCESS;  
}
/******************************************************************
*  Function Name:  IFX_SIP_DecodeAi_Param
*  Description  :  Decodes the  ai-param
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeAi_Param(IN  char8* pcStartIndex,
                       IN  char8* pcEndIndex,
                       OUT x_IFX_SIP_AiParam* pxAiParam,
                       OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcTempEnd;
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  uint32 uiErrCode;

  pcTempStart = pcStartIndex;
  pcTempEnd = pcEndIndex;

  /* Decode ai-param*/
  pcTempStart = pcStartIndex;
  if(IFX_SIP_DecodeGenericParams(pcTempStart,pcTempEnd,&pxAiParam->
         xGenericParam,pxSipError)==IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      } 
  return IFX_SIP_SUCCESS;  
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeCpid_Param
*  Description  :  Decodes the  cpid-param
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeCpid_Param(IN  char8* pcStartIndex,
                       IN  char8* pcEndIndex,
                       OUT x_IFX_SIP_CpidParam* pxCpidParam,
                       OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcTempEnd;
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  uint32 uiErrCode;

  pcTempStart = pcStartIndex;
  pcTempEnd = pcEndIndex;

  /* Decode cpid-param*/
 
  pcTempStart = pcStartIndex;
  if(IFX_SIP_DecodeGenericParams(pcTempStart,pcTempEnd,&pxCpidParam->
         xGenericParam,pxSipError)==IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      } 
  return IFX_SIP_SUCCESS;  
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeVNetwork_Spec
*  Description  :  Decodes the  VNetwork Spec parameter
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeVNetwork_Spec(IN  char8* pcStartIndex,
                            IN  char8* pcEndIndex,
                            OUT x_IFX_SIP_VNetwork_Spec* pxVNetworkSpec,
                            OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcTempEnd , *pcCurrPos;
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  uint32 uiErrCode;
  char8 acTemp[IFX_SIP_MAX_TOKEN];
  x_IFX_SIP_VNetworkParam* pxVNetworkParam;
  int32 iCount = 0;
  
  /* Remove any Leading White Spaces */
  pcTempStart = pcStartIndex;
  pcTempEnd = pcEndIndex;

  while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
    pcTempStart++;
    if(pcTempStart > pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
      return IFX_SIP_FAILURE;
    }
  }

  /* Handling of , within quotes for genvalue in generic params */
  if(IFX_SIP_FindDelimWhenQuotesRPresent(pcTempStart,
                                          pcEndIndex,
                                          ';',
                                          &pcCurrPos,
                                          &pcTempEnd,
                                          pxSipError) == IFX_SIP_FAILURE) {
    return IFX_SIP_FAILURE;
  }

  if (pcCurrPos != NULL) {
    
    strncpy(acTemp, pcTempStart, (pcTempEnd - pcTempStart) + 0);
    acTemp[(pcTempEnd - pcTempStart) + 0] = '\0';
    eRetVal = IFX_SIP_DecodeValidateToken(acTemp);
    if(eRetVal == IFX_SIP_SUCCESS){
     strcpy(pxVNetworkSpec->szValue,acTemp);
    }
    else{
      return(IFX_SIP_FAILURE);
    }
  }
  else
  {
    strncpy(acTemp, pcTempStart, (pcEndIndex - pcTempStart) + 0);
    acTemp[(pcEndIndex - pcTempStart) + 0] = '\0';
    eRetVal = IFX_SIP_DecodeValidateToken(acTemp);
    if(eRetVal == IFX_SIP_SUCCESS){
     strcpy(pxVNetworkSpec->szValue,acTemp);
    }
    else{
      return(IFX_SIP_FAILURE);
    }
  } 
#if 0
  char8* pcTempStart, * pcTempEnd, *pcCurrPos;
  char8 acTemp[IFX_SIP_MAX_TOKEN];
  int32 iCount = 0;
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  x_IFX_SIP_VNetworkParam* pxVNetworkParam;
  uint32 uiErrCode;

  pcTempStart = pcStartIndex;
  pcCurrPos = pcStartIndex;
  pcTempEnd = pcEndIndex;

  while(*pcCurrPos != '\n' && *pcCurrPos != ';'){
    acTemp[iCount++] = *pcCurrPos;
    pcCurrPos++;
    if(iCount >= IFX_SIP_MAX_TOKEN){
      return(IFX_SIP_FAILURE);
    }
  }
  acTemp[iCount] = '\0';
  eRetVal = IFX_SIP_DecodeValidateToken(acTemp);
  if(eRetVal == IFX_SIP_SUCCESS){
    strcpy(pxVNetworkSpec->szValue,acTemp);
  }
  else{
    return(IFX_SIP_FAILURE);
  }

#endif
    if(pcCurrPos != NULL)
      pcTempStart = pcCurrPos ; /* As it is pointing to ; */
    else
      pcTempStart = pcEndIndex;
    //pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
    
    if(pcCurrPos == NULL){
      while(pcTempStart < pcEndIndex){
        if(*pcTempStart == ' ' || *pcTempStart == '\t'){
          pcTempStart++;
          continue;
        }
        else{
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid message format");
          return IFX_SIP_FAILURE;
        }
      }
      return IFX_SIP_SUCCESS;
    }
    else{
      char8* pcTemp;
      pcTemp = pcTempStart; /* As it points to > */

      /* Check for spaces after > */
      while((*pcTemp == ' ') || (*pcTemp == '\t')){
        pcTemp++;
        if(pcTemp > pcCurrPos){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid message format");
          return IFX_SIP_FAILURE;
        }
      }

      /* To check if there are only spaces between > and ; */
      if(*pcTemp != ';'){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid message format");
        return IFX_SIP_FAILURE;
      }
      pcTempStart = pcCurrPos + 1; /* As it points to ; */
    }
  do{
    /* Remove any leading spaces */
    while((pcTempStart < pcEndIndex) &&
          (*pcTempStart == ' ' || *pcTempStart == '\t')){
      pcTempStart++;
    }
    if(pcTempStart >= pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
      IFX_SIP_Free(pxVNetworkParam);
      return IFX_SIP_FAILURE;
    }
    //pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
    if(IFX_SIP_FindDelimWhenQuotesRPresent(pcTempStart,
                                          pcEndIndex,
                                          ';',
                                          &pcCurrPos,
                                          &pcTempEnd,
                                          pxSipError) == IFX_SIP_FAILURE) {
    return IFX_SIP_FAILURE;
  }
    if(pcCurrPos == NULL){
      pcTempEnd = pcEndIndex;
    }
    else{
      pcTempEnd = pcCurrPos;
      /* Remove any Trailing Spaces */
      while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
        pcTempEnd--;
        if(pcTempEnd < pcTempStart){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
          IFX_SIP_Free(pxVNetworkParam);
          return IFX_SIP_FAILURE;
        }
      }
    }
  /* Allocate for vnetwork-param*/
  __ifx_list_add_front((void *)&pxVNetworkSpec->pxVNetworkParam,
                        (void *)&pxVNetworkParam,
                          sizeof(x_IFX_SIP_VNetworkParam),&uiErrCode);
  if(uiErrCode < 0){
    pxSipError->eDecodeErr = IFX_SIP_OUTOFMEM;
    strcpy(pxSipError->szErrorDesc,"Out of Memory");
    strcpy(pxSipError->szErrorDesc,"Creating Associated-URI Spec failed");
    return IFX_SIP_FAILURE;
  }
    /* Decode vnetwork-param */
    eRetVal = IFX_SIP_DecodeVNetwork_Param(pcTempStart,pcTempEnd,
                pxVNetworkParam, pxSipError);
   
    if(eRetVal == IFX_SIP_FAILURE){
      IFX_SIP_Free(pxVNetworkParam);
      return IFX_SIP_FAILURE;
    }
    if(pcCurrPos == NULL){
      break;
    }
    else{
      pcTempStart = pcCurrPos + 1;
    }
  } while(1);
  return IFX_SIP_SUCCESS;  
}
/******************************************************************
*  Function Name:  IFX_SIP_DecodeVNetwork_Param
*  Description  :  Decodes the  vnetwork-param
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeVNetwork_Param(IN  char8* pcStartIndex,
                       IN  char8* pcEndIndex,
                       OUT x_IFX_SIP_VNetworkParam* pxVnetworkParam,
                       OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcTempEnd;
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  uint32 uiErrCode;

  pcTempStart = pcStartIndex;
  pcTempEnd = pcEndIndex;

  /* Decode cpid-param*/
 
  pcTempStart = pcStartIndex;
  if(IFX_SIP_DecodeGenericParams(pcTempStart,pcTempEnd,&pxVnetworkParam->
         xGenericParam,pxSipError)==IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      } 
  return IFX_SIP_SUCCESS;  
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeAccess_Info
*  Description  :  Decodes the access-info
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeAccess_Info(IN  char8* pcStartIndex,
                       IN  char8* pcEndIndex,
                       OUT x_IFX_SIP_Access_Info* pxAccessInfo,
                       OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcTempEnd , *pcCurrPos;
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  uint32 uiErrCode;
  char8 acTemp[IFX_SIP_MAX_TOKEN];
  
  /* Remove any Leading White Spaces */
  pcTempStart = pcStartIndex;
  pcTempEnd = pcEndIndex;

  while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
    pcTempStart++;
    if(pcTempStart > pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
      return IFX_SIP_FAILURE;
    }
  }

  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'=');
  if(pcCurrPos == NULL){
    pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
    strcpy(pxSipError->szErrorDesc,"Invalid Msg Format ");
    return IFX_SIP_FAILURE;
  }
  else{
    pcTempEnd = pcCurrPos;
    /* Remove any Trailing Spaces */
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd < pcTempStart){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
        IFX_SIP_Free(pxAccessInfo);
        return IFX_SIP_FAILURE;
      }
    }
  }
  strncpy(acTemp, pcTempStart, (pcTempEnd - pcTempStart));
  acTemp[(pcTempEnd - pcTempStart)] = '\0';
    
    if(IFX_SIP_strcasecmp(acTemp, "cgi-3gpp") == 0) { /* cgi-3gpp header */
      pcTempStart = pcCurrPos + 1;
      pxAccessInfo->ucAccessInfoParamType = IFX_SIP_ACCESSINFO_CGI_3GPP;
      strncpy(pxAccessInfo->acCgi3gpp,pcTempStart,(pcEndIndex - pcTempStart));
      pxAccessInfo->acCgi3gpp[(pcEndIndex - pcTempStart)] = '\0';
      /* Validate access-info */
      if(pxAccessInfo->acCgi3gpp[0] == 0x22){
        if(IFX_SIP_ValidateQuotedString(pxAccessInfo->acCgi3gpp) == IFX_SIP_FAILURE){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_QUOTEDSTRING;
          strcpy(pxSipError->szErrorDesc,"Invalid access-info value");
          return IFX_SIP_FAILURE;
        }
      }
      else{
        if(IFX_SIP_ValidateToken(pxAccessInfo->acCgi3gpp) == IFX_SIP_FAILURE){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
          strcpy(pxSipError->szErrorDesc,"Invalid access-info-value");
          return IFX_SIP_FAILURE;
        }
      }
    }
    else if (IFX_SIP_strcasecmp(acTemp, "utran-cell-id-3gpp") == 0) { /* utran-cell-id-3gpp header */
      pcTempStart = pcCurrPos + 1;
      pxAccessInfo->ucAccessInfoParamType = IFX_SIP_ACCESSINFO_UTRAN_CELL_ID_3GPP;

      strncpy(pxAccessInfo->acUtranCellId3gpp,pcTempStart,(pcEndIndex - pcTempStart));
      pxAccessInfo->acUtranCellId3gpp[(pcEndIndex - pcTempStart)] = '\0';
      /* Validate access-info */
      if(pxAccessInfo->acUtranCellId3gpp[0] == 0x22){
        if(IFX_SIP_ValidateQuotedString(pxAccessInfo->acUtranCellId3gpp) == IFX_SIP_FAILURE){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_QUOTEDSTRING;
          strcpy(pxSipError->szErrorDesc,"Invalid access-info value");
          return IFX_SIP_FAILURE;
        }
      }
      else{
        if(IFX_SIP_ValidateToken(pxAccessInfo->acUtranCellId3gpp) == IFX_SIP_FAILURE){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
          strcpy(pxSipError->szErrorDesc,"Invalid access-info-value");
          return IFX_SIP_FAILURE;
        }
      }
    }
    else if (IFX_SIP_strcasecmp(acTemp, "extension-access-info") == 0) { /* extension-access-info */
      pcTempStart = pcCurrPos + 1;
      pxAccessInfo->ucAccessInfoParamType = IFX_SIP_ACCESSINFO_EXT_ACCESS_INFO;
      strncpy(pxAccessInfo->acExtAccessInfo,
                 pcTempStart,(pcEndIndex - pcTempStart));
      pxAccessInfo->acExtAccessInfo[(pcEndIndex - pcTempStart)] = '\0'; 
      /* Validate Gen Param Value */
      if(IFX_SIP_ValidateGenValue(pxAccessInfo->acExtAccessInfo) == 
             IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_GENVALUE;
        strcpy(pxSipError->szErrorDesc,"Invalid Gen Value ");
        return IFX_SIP_FAILURE;
      }
    }
  return IFX_SIP_SUCCESS;  
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeCharge_Addr_Params
*  Description  :  Decodes the charge-addr-params
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeCharge_Addr_Params(IN  char8* pcStartIndex,
                       IN  char8* pcEndIndex,
                       OUT x_IFX_SIP_Charge_Addr_Params* pxChargeAddrParams,
                       OUT x_IFX_SIP_Error* pxSipError)
{
#if 1
  char8* pcTempStart, * pcTempEnd , *pcCurrPos;
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  uint32 uiErrCode;
  char8 acTemp[IFX_SIP_MAX_TOKEN];
  
  /* Remove any Leading White Spaces */
  pcTempStart = pcStartIndex;
  pcTempEnd = pcEndIndex;

  while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
    pcTempStart++;
    if(pcTempStart > pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
      return IFX_SIP_FAILURE;
    }
  }
  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'=');
  if(pcCurrPos == NULL){
    pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
    strcpy(pxSipError->szErrorDesc,"Invalid Msg Format ");
    return IFX_SIP_FAILURE;
  }
  else{
    pcTempEnd = pcCurrPos;
    /* Remove any Trailing Spaces */
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd < pcTempStart){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
        IFX_SIP_Free(pxChargeAddrParams);
        return IFX_SIP_FAILURE;
      }
    }
  }
  strncpy(acTemp, pcTempStart, (pcTempEnd - pcTempStart) + 0);
  acTemp[(pcTempEnd - pcTempStart) + 0] = '\0';
    
    if(IFX_SIP_strcasecmp(acTemp, "ccf") == 0) { /* ccf header */
      pcTempStart = pcCurrPos + 1;
      pxChargeAddrParams->ucChargeAddrParams = IFX_SIP_CHARGEADDRPARAMS_CCF;
    strncpy(pxChargeAddrParams->acCcf,pcTempStart,(pcEndIndex - pcTempStart));
    pxChargeAddrParams->acCcf[(pcEndIndex - pcTempStart)] = '\0';
    /* Validate ccf */
    if(pxChargeAddrParams->acCcf[0] == 0x22){
      if(IFX_SIP_ValidateQuotedString(pxChargeAddrParams->acCcf) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_QUOTEDSTRING;
        strcpy(pxSipError->szErrorDesc,"Invalid ccf value");
        return IFX_SIP_FAILURE;
      }
    }
    else{
      if(IFX_SIP_ValidateToken(pxChargeAddrParams->acCcf) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
        strcpy(pxSipError->szErrorDesc,"Invalid ccf value");
        return IFX_SIP_FAILURE;
      }
    }
    }
    else if (IFX_SIP_strcasecmp(acTemp, "ecf") == 0) { /* ecf header */
      pcTempStart = pcCurrPos + 1;
      pxChargeAddrParams->ucChargeAddrParams = IFX_SIP_CHARGEADDRPARAMS_ECF;

    strncpy(pxChargeAddrParams->acEcf,pcTempStart,(pcEndIndex - pcTempStart));
    pxChargeAddrParams->acEcf[(pcEndIndex - pcTempStart)] = '\0';
    /* Validate ecf */
    if(pxChargeAddrParams->acEcf[0] == 0x22){
      if(IFX_SIP_ValidateQuotedString(pxChargeAddrParams->acEcf) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_QUOTEDSTRING;
        strcpy(pxSipError->szErrorDesc,"Invalid ecf value");
        return IFX_SIP_FAILURE;
      }
    }
    else{
      if(IFX_SIP_ValidateToken(pxChargeAddrParams->acEcf) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
        strcpy(pxSipError->szErrorDesc,"Invalid ecf value");
        return IFX_SIP_FAILURE;
      }
    }
    }
    else { /* generic param, but decode right from the start, i.e., go backwards of "=" but just after spaces removed */ 
      pxChargeAddrParams->ucChargeAddrParams = IFX_SIP_CHARGEADDRPARAMS_GEN;
      if (IFX_SIP_DecodeGenericParams(pcTempStart,pcEndIndex,
   		  &pxChargeAddrParams->xGenericParam,pxSipError) == IFX_SIP_FAILURE) {
        return IFX_SIP_FAILURE;	
      }
    }
    
#endif 
  return IFX_SIP_SUCCESS;  
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeCharging_Param
*  Description  :  Decodes the charging-params
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeCharging_Param(IN  char8* pcStartIndex,
                       IN  char8* pcEndIndex,
                       OUT x_IFX_SIP_Charge_Params* pxChargeParams,
                       OUT x_IFX_SIP_Error* pxSipError)
{
#if 1
  char8* pcTempStart, * pcTempEnd , *pcCurrPos;
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  uint32 uiErrCode;
  char8 acTemp[IFX_SIP_MAX_TOKEN];
  
  /* Remove any Leading White Spaces */
  pcTempStart = pcStartIndex;
  pcTempEnd = pcEndIndex;

  while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
    pcTempStart++;
    if(pcTempStart > pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
      return IFX_SIP_FAILURE;
    }
  }
  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'=');
  if(pcCurrPos == NULL){
    pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
    strcpy(pxSipError->szErrorDesc,"Invalid Msg Format ");
    return IFX_SIP_FAILURE;
  }
  else{
    pcTempEnd = pcCurrPos;
    /* Remove any Trailing Spaces */
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd < pcTempStart){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
        IFX_SIP_Free(pxChargeParams);
        return IFX_SIP_FAILURE;
      }
    }
  }
    strncpy(acTemp, pcTempStart, (pcTempEnd - pcTempStart));
    acTemp[(pcTempEnd - pcTempStart)] = '\0';
    
    if(IFX_SIP_strcasecmp(acTemp, "icid-generated-at") == 0) { /* icid-gen-addr header */
    pcTempStart = pcCurrPos + 1;
    pxChargeParams->ucChargeParams = IFX_SIP_CHARGEPARAM_ICID_GENADDR;
    if (IFX_SIP_DecodeToken(pcTempStart, pcEndIndex, 
	      pxChargeParams->szIcidGenAddr, pxSipError) == IFX_SIP_FAILURE) {
	        return IFX_SIP_FAILURE;
            }	
      /* Validate Gen Param Value */
      if(IFX_SIP_IdentifyType(pxChargeParams->szIcidGenAddr) == 
             IFX_SIP_HOSTINVALID){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_HOSTINFO;
        strcpy(pxSipError->szErrorDesc,"Invalid Host Name ");
        return IFX_SIP_FAILURE;
      }
    }
    else if (IFX_SIP_strcasecmp(acTemp, "orig-ioi") == 0) { /*orig-ioi header */
      pcTempStart = pcCurrPos + 1;
      pxChargeParams->ucChargeParams = IFX_SIP_CHARGEPARAM_ORIG_IOI;
      strncpy(pxChargeParams->szOrigIoi,
                 pcTempStart,(pcEndIndex - pcTempStart));
      pxChargeParams->szOrigIoi[(pcEndIndex - pcTempStart)] = '\0'; 
      /* Validate Gen Param Value */
      if(IFX_SIP_ValidateGenValue(pxChargeParams->szOrigIoi) == 
             IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_GENVALUE;
        strcpy(pxSipError->szErrorDesc,"Invalid Gen Value ");
        return IFX_SIP_FAILURE;
      }
    }
    else if (IFX_SIP_strcasecmp(acTemp, "term-ioi") == 0) { /*term-ioi header */
      pcTempStart = pcCurrPos + 1;
      pxChargeParams->ucChargeParams = IFX_SIP_CHARGEPARAM_TERM_IOI;
      strncpy(pxChargeParams->szTermIoi,
                 pcTempStart,(pcEndIndex - pcTempStart));
      pxChargeParams->szTermIoi[(pcEndIndex - pcTempStart)] = '\0'; 
      /* Validate Gen Param Value */
      if(IFX_SIP_ValidateGenValue(pxChargeParams->szTermIoi) == 
             IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_GENVALUE;
        strcpy(pxSipError->szErrorDesc,"Invalid Gen Value ");
        return IFX_SIP_FAILURE;
      }
    }
    else { /* generic param, but decode right from the start, i.e., go backwards of "=" but just after spaces removed */ 
      pxChargeParams->ucChargeParams = IFX_SIP_CHARGEPARAM_GENERIC_PARAM;
      if (IFX_SIP_DecodeGenericParams(pcTempStart,pcEndIndex,
   		  &pxChargeParams->xGenericParam,pxSipError) == IFX_SIP_FAILURE) {
        return IFX_SIP_FAILURE;	
      }
    }
    
#endif 
  return IFX_SIP_SUCCESS;  
}
#endif /*RFC_3455 */

/******************* Validating Functions *************************/
/******************************************************************
*  Function Name:  IFX_SIP_DecodeValidateToken
*  Description  :  Validates the token
*  Input Values :  Pointer to a string
*  Output Values:  if string is valid
*  Return Value :  Success/Failure of checking
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeValidateToken(char8* pcString)
{
  int32 iCount = 0;
  for(iCount = 0; pcString[iCount] != '\0'; iCount++){
    if((pcString[iCount] < 48 /* 0*/) &&
       (pcString[iCount] > 57 /* 9*/) &&
       (pcString[iCount] < 65 /* A*/) &&
       (pcString[iCount] > 90) &&
       (pcString[iCount] < 97 /* a*/) &&
       (pcString[iCount] > 122) &&
       (pcString[iCount] != '-') &&
       (pcString[iCount] != '.') &&
       (pcString[iCount] != '!') &&
       (pcString[iCount] != '%') &&
       (pcString[iCount] != '_') &&
       (pcString[iCount] != '*') &&
       (pcString[iCount] != '+') &&
       (pcString[iCount] != '~') &&
       (pcString[iCount] != '`') &&
       (pcString[iCount] != '\'')){
      return(IFX_SIP_FAILURE);
    }
  }
  return(IFX_SIP_SUCCESS);
}

/******************************************************************
*  Function Name:  IFX_SIP_ValidatePassword
*  Description  :  Checks if it is a valid Password
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidatePassword(char8* pszBuff)
{
  uint32 i = 0;
  while(i < strlen(pszBuff)){
    if((isalnum(pszBuff[i])) ||
       (pszBuff[i] == '-') ||
       (pszBuff[i] == '_') ||
       (pszBuff[i] == '.') ||
       (pszBuff[i] == '!') ||
       (pszBuff[i] == '~') ||
       (pszBuff[i] == '*') ||
       (pszBuff[i] == '\'') ||
       (pszBuff[i] == '(') ||
       (pszBuff[i] == ')') ||
       (pszBuff[i] == '%') ||
       (pszBuff[i] == '&') ||
       (pszBuff[i] == '=') ||
       (pszBuff[i] == '+') ||
       (pszBuff[i] == '$') ||
       (pszBuff[i] == ',')){
      if(pszBuff[i] == '%'){
        if(((i + 3) < strlen(pszBuff)) &&
           ((isdigit(pszBuff[i + 1])) ||
            (pszBuff[i + 1] >= 0x61 && pszBuff[i + 1] <= 0x66) ||
            (pszBuff[i + 1] >= 0x41 && pszBuff[i + 1] <= 0x46)) &&
           ((isdigit(pszBuff[i + 2])) ||
            (pszBuff[i + 2] > 0x61 && pszBuff[i + 2] < 0x66) ||
            (pszBuff[i + 2] >= 0x41 && pszBuff[i + 2] <= 0x46))){
          i += 3;
          continue;
        }
        else{
          break;
        }
      }
      i++;
      continue;
    }
    else{
      break;
    }
  }
  if(i != strlen(pszBuff)){
    return IFX_SIP_FAILURE;
  }

  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_ValidateReasonPhrase
*  Description  :  Checks if it is a valid Reason Phrase
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateReasonPhrase(uchar8* pszBuff)
{
  uint32 i = 0;
  while(i < strlen(pszBuff)){
    if(isalnum(pszBuff[i]) ||
       (pszBuff[i] == ';') ||
       (pszBuff[i] == '/') ||
       (pszBuff[i] == '?') ||
       (pszBuff[i] == ':') ||
       (pszBuff[i] == '@') ||
       (pszBuff[i] == '&') ||
       (pszBuff[i] == '=') ||
       (pszBuff[i] == '+') ||
       (pszBuff[i] == '$') ||
       (pszBuff[i] == ',') ||
       (pszBuff[i] == '-') ||
       (pszBuff[i] == '_') ||
       (pszBuff[i] == '.') ||
       (pszBuff[i] == '!') ||
       (pszBuff[i] == '~') ||
       (pszBuff[i] == '*') ||
       (pszBuff[i] == '\'') ||
       (pszBuff[i] == '(') ||
       (pszBuff[i] == ')') ||
       (pszBuff[i] == '%') ||
       (pszBuff[i] == ' ') ||
       (pszBuff[i] == '\t') ||
       ((pszBuff[i] >= 0x80) && (pszBuff[i] <= 0xBF))){
      if(pszBuff[i] == '%'){
        if(((i + 3) < strlen(pszBuff)) &&
           ((isdigit(pszBuff[i + 1])) ||
            (pszBuff[i + 1] >= 0x61 && pszBuff[i + 1] <= 0x66) ||
            (pszBuff[i + 1] >= 0x41 && pszBuff[i + 1] <= 0x46)) &&
           ((isdigit(pszBuff[i + 2])) ||
            (pszBuff[i + 2] > 0x61 && pszBuff[i + 2] < 0x66) ||
            (pszBuff[i + 2] >= 0x41 && pszBuff[i + 2] <= 0x46))){
          i += 3;
          continue;
        }
        else{
          break;
        }
      }
      i++;
      continue;
    }
    else if(pszBuff[i] >= 0xc0 && pszBuff[i] <= 0xdf){
      if(((i + 1) < strlen(pszBuff)) &&
         (pszBuff[i + 1] >= 0x80 && pszBuff[i + 1] <= 0xbf)){
        i += 2;
        continue;
      }
      break;
    }
    else if(pszBuff[i] >= 0xe0 && pszBuff[i] <= 0xef){
      if(((i + 1) < strlen(pszBuff)) &&
         (pszBuff[i + 1] >= 0x80 && pszBuff[i + 1] <= 0xbf) &&
         (pszBuff[i + 2] >= 0x80 && pszBuff[i + 2] <= 0xbf)){
        i += 3;
        continue;
      }
      break;
    }
    else if(pszBuff[i] >= 0xf0 && pszBuff[i] <= 0xf7){
      if(((i + 1) < strlen(pszBuff)) &&
         (pszBuff[i + 1] >= 0x80 && pszBuff[i + 1] <= 0xbf) &&
         (pszBuff[i + 2] >= 0x80 && pszBuff[i + 2] <= 0xbf) &&
         (pszBuff[i + 3] >= 0x80 && pszBuff[i + 3] <= 0xbf)){
        i += 4;
        continue;
      }
      break;
    }
    else if(pszBuff[i] >= 0xf8 && pszBuff[i] <= 0xfb){
      if(((i + 1) < strlen(pszBuff)) &&
         (pszBuff[i + 1] >= 0x80 && pszBuff[i + 1] <= 0xbf) &&
         (pszBuff[i + 2] >= 0x80 && pszBuff[i + 2] <= 0xbf) &&
         (pszBuff[i + 3] >= 0x80 && pszBuff[i + 3] <= 0xbf) &&
         (pszBuff[i + 4] >= 0x80 && pszBuff[i + 4] <= 0xbf)){
        i += 5;
        continue;
      }
      break;
    }
    else if(pszBuff[i] >= 0xfc && pszBuff[i] <= 0xfd){
      if(((i + 5) < strlen(pszBuff)) &&
         (pszBuff[i + 1] >= 0x80 && pszBuff[i + 1] <= 0xbf) &&
         (pszBuff[i + 2] >= 0x80 && pszBuff[i + 2] <= 0xbf) &&
         (pszBuff[i + 3] >= 0x80 && pszBuff[i + 3] <= 0xbf) &&
         (pszBuff[i + 4] >= 0x80 && pszBuff[i + 4] <= 0xbf) &&
         (pszBuff[i + 5] >= 0x80 && pszBuff[i + 5] <= 0xbf)){
        i += 6;
        continue;
      }
      break;
    }
    else{
      break;
    }
  }
  if(i != strlen(pszBuff)){
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_ValidateHeaderValue
*  Description  :  Checks if it is a valid Header
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateHeaderValue(uchar8* pszBuff)
{
  uint32 i = 0;
  while(i < strlen(pszBuff)){
    if((isalnum(pszBuff[i])) ||
       (pszBuff[i] == ';') ||
       (pszBuff[i] == '/') ||
       (pszBuff[i] == '?') ||
       (pszBuff[i] == ':') ||
       (pszBuff[i] == '@') ||
       (pszBuff[i] == ']') ||
       (pszBuff[i] == '/') ||
       (pszBuff[i] == '?') ||
       (pszBuff[i] == '&') ||
       (pszBuff[i] == '=') ||
       (pszBuff[i] == '+') ||
       (pszBuff[i] == '$') ||
       (pszBuff[i] == ',') ||
       (pszBuff[i] == '-') ||
       (pszBuff[i] == '_') ||
       (pszBuff[i] == '.') ||
       (pszBuff[i] == '!') ||
       (pszBuff[i] == '~') ||
       (pszBuff[i] == '*') ||
       (pszBuff[i] == '\'') ||
       (pszBuff[i] == '(') ||
       (pszBuff[i] == ')') ||
       (pszBuff[i] == '%') ||
       (pszBuff[i] == ' ') ||
       (pszBuff[i] == '\t') ||
       ((pszBuff[i] >= 0x80) && (pszBuff[i] <= 0xBF))){
      if(pszBuff[i] == '%'){
        if(((i + 3) < strlen(pszBuff)) &&
           ((isdigit(pszBuff[i + 1])) ||
            (pszBuff[i + 1] >= 0x61 && pszBuff[i + 1] <= 0x66) ||
            (pszBuff[i + 1] >= 0x41 && pszBuff[i + 1] <= 0x46)) &&
           ((isdigit(pszBuff[i + 2])) ||
            (pszBuff[i + 2] > 0x61 && pszBuff[i + 2] < 0x66) ||
            (pszBuff[i + 2] >= 0x41 && pszBuff[i + 2] <= 0x46))){
          i += 3;
          continue;
        }
        else{
          break;
        }
      }
      i++;
      continue;
    }
    else if(pszBuff[i] >= 0xc0 && pszBuff[i] <= 0xdf){
      if(((i + 1) < strlen(pszBuff)) &&
         (pszBuff[i + 1] >= 0x80 && pszBuff[i + 1] <= 0xbf)){
        i += 2;
        continue;
      }
      break;
    }
    else if(pszBuff[i] >= 0xe0 && pszBuff[i] <= 0xef){
      if(((i + 1) < strlen(pszBuff)) &&
         (pszBuff[i + 1] >= 0x80 && pszBuff[i + 1] <= 0xbf) &&
         (pszBuff[i + 2] >= 0x80 && pszBuff[i + 2] <= 0xbf)){
        i += 3;
        continue;
      }
      break;
    }
    else if(pszBuff[i] >= 0xf0 && pszBuff[i] <= 0xf7){
      if(((i + 1) < strlen(pszBuff)) &&
         (pszBuff[i + 1] >= 0x80 && pszBuff[i + 1] <= 0xbf) &&
         (pszBuff[i + 2] >= 0x80 && pszBuff[i + 2] <= 0xbf) &&
         (pszBuff[i + 3] >= 0x80 && pszBuff[i + 3] <= 0xbf)){
        i += 4;
        continue;
      }
      break;
    }
    else if(pszBuff[i] >= 0xf8 && pszBuff[i] <= 0xfb){
      if(((i + 1) < strlen(pszBuff)) &&
         (pszBuff[i + 1] >= 0x80 && pszBuff[i + 1] <= 0xbf) &&
         (pszBuff[i + 2] >= 0x80 && pszBuff[i + 2] <= 0xbf) &&
         (pszBuff[i + 3] >= 0x80 && pszBuff[i + 3] <= 0xbf) &&
         (pszBuff[i + 4] >= 0x80 && pszBuff[i + 4] <= 0xbf)){
        i += 5;
        continue;
      }
      break;
    }
    else if(pszBuff[i] >= 0xfc && pszBuff[i] <= 0xfd){
      if(((i + 5) < strlen(pszBuff)) &&
         (pszBuff[i + 1] >= 0x80 && pszBuff[i + 1] <= 0xbf) &&
         (pszBuff[i + 2] >= 0x80 && pszBuff[i + 2] <= 0xbf) &&
         (pszBuff[i + 3] >= 0x80 && pszBuff[i + 3] <= 0xbf) &&
         (pszBuff[i + 4] >= 0x80 && pszBuff[i + 4] <= 0xbf) &&
         (pszBuff[i + 5] >= 0x80 && pszBuff[i + 5] <= 0xbf)){
        i += 6;
        continue;
      }
      break;
    }
    else{
      break;
    }
  }
  if(i != strlen(pszBuff)){
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_ValidateToken
*  Description  :  Checks if it is a valid token
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateToken(char8* pszBuff)
{
  uint32 i;
  for(i = 0; i < strlen(pszBuff); i++){
    if(isalnum(pszBuff[i]) ||
       pszBuff[i] == '-' ||
       pszBuff[i] == '.' ||
       pszBuff[i] == '!' ||
       pszBuff[i] == '%' ||
       pszBuff[i] == '*' ||
       pszBuff[i] == '_' ||
       pszBuff[i] == '+' ||
       pszBuff[i] == '\'' ||
       pszBuff[i] == '`' ||
       pszBuff[i] == '~'){
      continue;
    }
    else{
      break;
    }
  }
  if(i != strlen(pszBuff)){
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_ValidateDisplayToken
*  Description  :  Checks if it is a valid token
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateDisplayToken(char8* pszBuff)
{
  uint32 i;
  for(i = 0; i < strlen(pszBuff); i++){
    if(isalnum(pszBuff[i]) ||
       pszBuff[i] == '-' ||
       pszBuff[i] == '.' ||
       pszBuff[i] == '!' ||
       pszBuff[i] == '%' ||
       pszBuff[i] == '*' ||
       pszBuff[i] == '_' ||
       pszBuff[i] == '+' ||
       pszBuff[i] == '\'' ||
       pszBuff[i] == '`' ||
       pszBuff[i] == '~' ||
       pszBuff[i] == ' '){
      continue;
    }
    else{
      break;
    }
  }
  if(i != strlen(pszBuff)){
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_ValidateWord
*  Description  :  Checks if it is a valid Word
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateWord(char8* pszBuff)
{
  uint32 i;
  for(i = 0; i < strlen(pszBuff); i++){
    if(isalnum(pszBuff[i]) ||
       pszBuff[i] == '-' ||
       pszBuff[i] == '.' ||
       pszBuff[i] == '!' ||
       pszBuff[i] == '%' ||
       pszBuff[i] == '*' ||
       pszBuff[i] == '_' ||
       pszBuff[i] == '+' ||
       pszBuff[i] == '\'' ||
       pszBuff[i] == '`' ||
       pszBuff[i] == '~' ||
       pszBuff[i] == '(' ||
       pszBuff[i] == ')' ||
       pszBuff[i] == '<' ||
       pszBuff[i] == '>' ||
       pszBuff[i] == ':' ||
       pszBuff[i] == '\\' ||
       pszBuff[i] == '\"' ||
       pszBuff[i] == '/' ||
       pszBuff[i] == '[' ||
       pszBuff[i] == ']' ||
       pszBuff[i] == '?' ||
       pszBuff[i] == '{' ||
       pszBuff[i] == '}'){
      continue;
    }
    else{
      break;
    }
  }
  if(i != strlen(pszBuff)){
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_ValidateWord
*  Description  :  Checks if it is a valid Word
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateCallId(char8* pszBuff)
{
  char8* pcTemp, acTemp[IFX_SIP_MAX_WORD_SIZE];
  pcTemp = strchr(pszBuff,'@');
  if(pcTemp == NULL){
    if(IFX_SIP_ValidateWord(pszBuff) == IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
  }
  else{
    if((pcTemp - pszBuff) <= 0){
      return IFX_SIP_FAILURE;
    }
    strncpy(acTemp,pszBuff,(pcTemp - pszBuff));
    acTemp[(pcTemp - pszBuff)] = '\0';
    if(IFX_SIP_ValidateWord(acTemp) == IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
    if(((pszBuff + strlen(pszBuff)) - (pcTemp + 1)) <= 0){
      return IFX_SIP_FAILURE;
    }
    strncpy(acTemp,(pcTemp + 1),((pszBuff + strlen(pszBuff)) - (pcTemp + 1)));
    acTemp[((pszBuff + strlen(pszBuff)) - (pcTemp + 1))] = '\0';
    if(IFX_SIP_ValidateWord(acTemp) == IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_ValidateHeaderName
*  Description  :  Checks if it is a valid Header Name
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateHeaderName(char8* pszBuff)
{
  uint32 i;
  for(i = 0; i < strlen(pszBuff); i++){
    if(pszBuff[i] == '/' ||
       pszBuff[i] == '[' ||
       pszBuff[i] == ']' ||
       pszBuff[i] == '?' ||
       pszBuff[i] == ':' ||
       pszBuff[i] == '+' ||
       pszBuff[i] == '$' ||
       isalnum(pszBuff[i]) ||
       pszBuff[i] == '-' ||
       pszBuff[i] == '.' ||
       pszBuff[i] == '_' ||
       pszBuff[i] == '!' ||
       pszBuff[i] == '~' ||
       pszBuff[i] == '*' ||
       pszBuff[i] == '`' ||
       pszBuff[i] == '(' ||
       pszBuff[i] == ')' ||
       pszBuff[i] == '%'){
      continue;
    }
  }
  if(i != strlen(pszBuff)){
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_ValidateParamChar
*  Description  :  Checks if it is a valid Param char
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateParamChar(uchar8* pszBuff)
{
  uint32 i = 0;
  while(i < strlen(pszBuff)){
    if((isalnum(pszBuff[i])) ||
       (pszBuff[i] == ']') ||
       (pszBuff[i] == '/') ||
       (pszBuff[i] == '?') ||
       (pszBuff[i] == ':') ||
       (pszBuff[i] == '+') ||
       (pszBuff[i] == '$') ||
       (pszBuff[i] == '[') ||
       (pszBuff[i] == '-') ||
       (pszBuff[i] == '_') ||
       (pszBuff[i] == '.') ||
       (pszBuff[i] == '!') ||
       (pszBuff[i] == '~') ||
       (pszBuff[i] == '*') ||
       (pszBuff[i] == '\'') ||
       (pszBuff[i] == '(') ||
       (pszBuff[i] == ')') ||
       (pszBuff[i] == '%')){
      if(pszBuff[i] == '%'){
        if(((i + 3) < strlen(pszBuff)) &&
           ((isdigit(pszBuff[i + 1])) ||
            (pszBuff[i + 1] >= 0x61 && pszBuff[i + 1] <= 0x66) ||
            (pszBuff[i + 1] >= 0x41 && pszBuff[i + 1] <= 0x46)) &&
           ((isdigit(pszBuff[i + 2])) ||
            (pszBuff[i + 2] > 0x61 && pszBuff[i + 2] < 0x66) ||
            (pszBuff[i + 2] >= 0x41 && pszBuff[i + 2] <= 0x46))){
          i += 3;
          continue;
        }
        else{
          break;
        }
      }
      i++;
      continue;
    }
    else{
      break;
    }
  }
  if(i != strlen(pszBuff)){
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_ValidateTextUTF8Trim
*  Description  :  Checks if it is a valid Text UTF8 Trim
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateTextUTF8Trim(uchar8* pszBuff)
{
  uint32 i = 0;
  while(i < strlen(pszBuff)){
    if((pszBuff[i] >= 0x20 && pszBuff[i] <= 0x7e)){
      i++;
      continue;
    }
    else if(pszBuff[i] >= 0xc0 && pszBuff[i] <= 0xdf){
      if(((i + 1) < strlen(pszBuff)) &&
         (pszBuff[i + 1] >= 0x80 && pszBuff[i + 1] <= 0xbf)){
        i += 2;
        continue;
      }
      break;
    }
    else if(pszBuff[i] >= 0xe0 && pszBuff[i] <= 0xef){
      if(((i + 1) < strlen(pszBuff)) &&
         (pszBuff[i + 1] >= 0x80 && pszBuff[i + 1] <= 0xbf) &&
         (pszBuff[i + 2] >= 0x80 && pszBuff[i + 2] <= 0xbf)){
        i += 3;
        continue;
      }
      break;
    }
    else if(pszBuff[i] >= 0xf0 && pszBuff[i] <= 0xf7){
      if(((i + 1) < strlen(pszBuff)) &&
         (pszBuff[i + 1] >= 0x80 && pszBuff[i + 1] <= 0xbf) &&
         (pszBuff[i + 2] >= 0x80 && pszBuff[i + 2] <= 0xbf) &&
         (pszBuff[i + 3] >= 0x80 && pszBuff[i + 3] <= 0xbf)){
        i += 4;
        continue;
      }
      break;
    }
    else if(pszBuff[i] >= 0xf8 && pszBuff[i] <= 0xfb){
      if(((i + 1) < strlen(pszBuff)) &&
         (pszBuff[i + 1] >= 0x80 && pszBuff[i + 1] <= 0xbf) &&
         (pszBuff[i + 2] >= 0x80 && pszBuff[i + 2] <= 0xbf) &&
         (pszBuff[i + 3] >= 0x80 && pszBuff[i + 3] <= 0xbf) &&
         (pszBuff[i + 4] >= 0x80 && pszBuff[i + 4] <= 0xbf)){
        i += 5;
        continue;
      }
      break;
    }
    else if(pszBuff[i] >= 0xfc && pszBuff[i] <= 0xfd){
      if(((i + 5) < strlen(pszBuff)) &&
         (pszBuff[i + 1] >= 0x80 && pszBuff[i + 1] <= 0xbf) &&
         (pszBuff[i + 2] >= 0x80 && pszBuff[i + 2] <= 0xbf) &&
         (pszBuff[i + 3] >= 0x80 && pszBuff[i + 3] <= 0xbf) &&
         (pszBuff[i + 4] >= 0x80 && pszBuff[i + 4] <= 0xbf) &&
         (pszBuff[i + 5] >= 0x80 && pszBuff[i + 5] <= 0xbf)){
        i += 6;
        continue;
      }
      break;
    }
    else{
      break;
    }
  }
  if(i != strlen(pszBuff)){
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_ValidateUric
*  Description  :  Checks if it is a valid URIC
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateUric(char8* pszBuff)
{
  uint32 i = 0;
  while(i < strlen(pszBuff)){
    if((isalnum(pszBuff[i])) ||
       (pszBuff[i] == ';') ||
       (pszBuff[i] == '/') ||
       (pszBuff[i] == '?') ||
       (pszBuff[i] == ':') ||
       (pszBuff[i] == '@') ||
       (pszBuff[i] == '&') ||
       (pszBuff[i] == '=') ||
       (pszBuff[i] == '+') ||
       (pszBuff[i] == '$') ||
       (pszBuff[i] == ',') ||
       (pszBuff[i] == '-') ||
       (pszBuff[i] == '_') ||
       (pszBuff[i] == '.') ||
       (pszBuff[i] == '!') ||
       (pszBuff[i] == '~') ||
       (pszBuff[i] == '*') ||
       (pszBuff[i] == '\'') ||
       (pszBuff[i] == '(') ||
       (pszBuff[i] == ')') ||
       (pszBuff[i] == '%')){
      if(pszBuff[i] == '%'){
        if(((i + 3) < strlen(pszBuff)) &&
           ((isdigit(pszBuff[i + 1])) ||
            (pszBuff[i + 1] >= 0x61 && pszBuff[i + 1] <= 0x66) ||
            (pszBuff[i + 1] >= 0x41 && pszBuff[i + 1] <= 0x46)) &&
           ((isdigit(pszBuff[i + 2])) ||
            (pszBuff[i + 2] > 0x61 && pszBuff[i + 2] < 0x66) ||
            (pszBuff[i + 2] >= 0x41 && pszBuff[i + 2] <= 0x46))){
          i += 3;
          continue;
        }
        else{
          break;
        }
      }
      i++;
      continue;
    }
    else{
      break;
    }
  }
  if(i != strlen(pszBuff)){
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_ValidatePChar
*  Description  :  Checks if it is a valid pchar
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidatePChar(char8* pszBuff)
{
  uint32 i = 0;
  while(i < strlen(pszBuff)){
    if((isalnum(pszBuff[i])) ||
       (pszBuff[i] == ':') ||
       (pszBuff[i] == '@') ||
       (pszBuff[i] == '&') ||
       (pszBuff[i] == '=') ||
       (pszBuff[i] == '+') ||
       (pszBuff[i] == '$') ||
       (pszBuff[i] == ',') ||
       (pszBuff[i] == '-') ||
       (pszBuff[i] == '_') ||
       (pszBuff[i] == '.') ||
       (pszBuff[i] == '!') ||
       (pszBuff[i] == '~') ||
       (pszBuff[i] == '*') ||
       (pszBuff[i] == '\'') ||
       (pszBuff[i] == '(') ||
       (pszBuff[i] == ')') ||
       (pszBuff[i] == '%')){
      if(pszBuff[i] == '%'){
        if(((i + 3) < strlen(pszBuff)) &&
           ((isdigit(pszBuff[i + 1])) ||
            (pszBuff[i + 1] >= 0x61 && pszBuff[i + 1] <= 0x66) ||
            (pszBuff[i + 1] >= 0x41 && pszBuff[i + 1] <= 0x46)) &&
           ((isdigit(pszBuff[i + 2])) ||
            (pszBuff[i + 2] > 0x61 && pszBuff[i + 2] < 0x66) ||
            (pszBuff[i + 2] >= 0x41 && pszBuff[i + 2] <= 0x46))){
          i += 3;
          continue;
        }
        else{
          break;
        }
      }
      i++;
      continue;
    }
    else{
      break;
    }
  }
  if(i != strlen(pszBuff)){
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_ValidateRegName
*  Description  :  Checks if it is a valid Reg Name
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateRegName(char8* pszBuff)
{
  uint32 i = 0;
  while(i < strlen(pszBuff)){
    if((isalnum(pszBuff[i])) ||
       (pszBuff[i] == ':') ||
       (pszBuff[i] == '@') ||
       (pszBuff[i] == '&') ||
       (pszBuff[i] == '=') ||
       (pszBuff[i] == '+') ||
       (pszBuff[i] == '$') ||
       (pszBuff[i] == ',') ||
       (pszBuff[i] == '-') ||
       (pszBuff[i] == '_') ||
       (pszBuff[i] == '.') ||
       (pszBuff[i] == '!') ||
       (pszBuff[i] == '~') ||
       (pszBuff[i] == '*') ||
       (pszBuff[i] == '\'') ||
       (pszBuff[i] == '(') ||
       (pszBuff[i] == ')') ||
       (pszBuff[i] == '%') ||
       (pszBuff[i] == ';')){
      if(pszBuff[i] == '%'){
        if(((i + 3) < strlen(pszBuff)) &&
           ((isdigit(pszBuff[i + 1])) ||
            (pszBuff[i + 1] >= 0x61 && pszBuff[i + 1] <= 0x66) ||
            (pszBuff[i + 1] >= 0x41 && pszBuff[i + 1] <= 0x46)) &&
           ((isdigit(pszBuff[i + 2])) ||
            (pszBuff[i + 2] > 0x61 && pszBuff[i + 2] < 0x66) ||
            (pszBuff[i + 2] >= 0x41 && pszBuff[i + 2] <= 0x46))){
          i += 3;
          continue;
        }
        else{
          break;
        }
      }
      i++;
      continue;
    }
    else{
      break;
    }
  }
  if(i != strlen(pszBuff)){
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_ValidateScheme
*  Description  :  Checks if it is a valid Scheme
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateScheme(char8* pszBuff)
{
  uint32 i = 0;
  if(isalpha(pszBuff[i])){
    i++;
    while(i < strlen(pszBuff)){
      if(isalnum(pszBuff[i]) ||
         (pszBuff[i] == '+') ||
         (pszBuff[i] == '-') ||
         (pszBuff[i] == '.')){
        i++;
        continue;
      }
      else{
        break;
      }
    }
    if(i != strlen(pszBuff)){
      return IFX_SIP_FAILURE;
    }
  }
  else{
    return IFX_SIP_FAILURE;
  } 
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_ValidateLanguage
*  Description  :  Checks if it is a valid Language
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateLanguage(char8* pszBuff)
{
  uint32 i = 0, iCount = 0;
  while(i < strlen(pszBuff)){
    if(isalpha(pszBuff[i])){
      i++;
      iCount++;
      if(iCount > 8){
        return IFX_SIP_FAILURE;
      }
      continue;
    }
    else if(pszBuff[i] == '-'){
      i++;
      iCount = 0;
      continue;
    }
    else{
      break;
    }
  }
  if((i != strlen(pszBuff)) || (iCount == 0)){
    return IFX_SIP_FAILURE;
  }

  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_ValidateResponseDigest
*  Description  :  Checks if it is a valid Response Digest
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateResponseDigest(char8* pszBuff)
{
  uint32 i = 0;
  if(pszBuff[i] == 0x22){
    i++;
    while(i < (strlen(pszBuff) - 1)){
      if(isdigit(pszBuff[i]) || ((pszBuff[i] > 0x60) && (pszBuff[i] < 0x67))){
        i++;
        continue;
      }
      else{
        break;
      }
    }
    if(pszBuff[i] == 0x22){
      i++;
    }
    if(i != strlen(pszBuff)){
      return IFX_SIP_FAILURE;
    }
  }
  else{
    return IFX_SIP_FAILURE;
  } 
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_ValidateIPv4Addr
*  Description  :  Validate Ipv4 address
*  Input Values :  character string
*  Output Values:  -
*  Return Value :  Success or failure of validation
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateIPv4Addr(char8* pszBuff)
{
  uint32 iCount = 0, iDotCount = 0;
  char8 acTemp[4];
  while(*pszBuff != '\0'){
    if(*pszBuff == '.'){
      iDotCount++;
      acTemp[iCount] = '\0';
      if((iCount > 0) && (atoi(acTemp) < 256)){
        memset(acTemp,'\0',4);
        iCount = 0;
        pszBuff++;
      }
      else{
        return IFX_SIP_FAILURE;
      }
    }
    else{
      if(!isdigit(*pszBuff)){
        return IFX_SIP_FAILURE;
      }
      acTemp[iCount++] = *pszBuff;
      pszBuff++;
      if(iCount > 3){
        return IFX_SIP_FAILURE;
      }
    }
  }
  if(iCount<1 || atoi(acTemp)> 256 || iDotCount > 3){
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_ValidateIPv6Addr
*  Description  :  Validate Ipv6 address
*  Input Values :  character string
*  Output Values:  -
*  Return Value :  Success or failure of validation
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateIPv6Addr(char8* pszBuff)
{
  /*TBF: Code to be added */
  int32 iDoubleColonFlag = 0, iHexCount=0, iTemp;
  uint32 i = 1;
  if((pszBuff[0] != '[') || (pszBuff[strlen(pszBuff) - 1] != ']')){
    return IFX_SIP_FAILURE;
  }
  pszBuff[strlen(pszBuff) - 1] = '\0';

  while(i < strlen(pszBuff)){
    if(isdigit(pszBuff[i]) ||
       (pszBuff[i] >= 0x41 && pszBuff[i] <= 0x46) ||
       (pszBuff[i] >= 0x61 && pszBuff[i] <= 0x66)){
      i++;
      iHexCount++;
      if(iHexCount > 4){
        return IFX_SIP_FAILURE;
      }
      continue;
    }
    else if(pszBuff[i] == ':'){
      if((i + 1) < strlen(pszBuff) && pszBuff[i + 1] == ':'){
        iDoubleColonFlag++;
        if(iDoubleColonFlag > 1){
          return IFX_SIP_FAILURE;
        }
        iHexCount = 0;
        i += 2;
        continue;
      }
      iHexCount = 0;
      i++;
      continue;
    }
    else if(pszBuff[i] == '.'){
      while(pszBuff[i - 1] != ':'){
        i--;
      }
      if(IFX_SIP_ValidateIPv4Addr(&pszBuff[i]) == IFX_SIP_SUCCESS){
        iTemp = strlen(pszBuff);
        pszBuff[iTemp] = ']';
        pszBuff[iTemp + 1] = '\0';
        return IFX_SIP_SUCCESS;
      }
      else{
        return IFX_SIP_FAILURE;
      }
    }
    else{
      break;
    }
  }
  if(i != strlen(pszBuff)){
    return IFX_SIP_FAILURE;
  }

  iTemp = strlen(pszBuff);
  pszBuff[iTemp] = ']';
  pszBuff[iTemp + 1] = '\0';

  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_ValidateQuotedString
*  Description  :  Checks if it is a valid Quoted String
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateQuotedString(uchar8* pszBuff)
{
  int32 i = 0;
  if(pszBuff[0] != 0x22 || pszBuff[strlen(pszBuff) - 1] != 0x22){
    return IFX_SIP_FAILURE;
  }
  i = 1;
  while(i < (strlen(pszBuff) - 1)){
    if((pszBuff[i] == 0x21) ||
       ((pszBuff[i] >= 0x23) && (pszBuff[i] <= 0x5b)) ||
       ((pszBuff[i] >= 0x5d) && (pszBuff[i] <= 0x7e)) ||
       (pszBuff[i] == 0x5c) ||
       (pszBuff[i] == '\t') ||
       (pszBuff[i] == ' ')){
      if(pszBuff[i] == 0x5c){
        if(((i + 1) < strlen(pszBuff)) &&
           (((pszBuff[i + 1] <= 0x09)) ||
            ((pszBuff[i + 1] >= 0x0b) && (pszBuff[i + 1] <= 0x0c)) ||
            ((pszBuff[i + 1] >= 0x0e) && (pszBuff[i + 1] <= 0x7f)))){
          i += 2;
          continue;
        }
        else{
          break;
        }
      }
      i++;
      continue;
    }
    else if(pszBuff[i] >= 0xc0 && pszBuff[i] <= 0xdf){
      if(((i + 1) < strlen(pszBuff)) &&
         (pszBuff[i + 1] >= 0x80 && pszBuff[i + 1] <= 0xbf)){
        i += 2;
        continue;
      }
      break;
    }
    else if(pszBuff[i] >= 0xe0 && pszBuff[i] <= 0xef){
      if(((i + 1) < strlen(pszBuff)) &&
         (pszBuff[i + 1] >= 0x80 && pszBuff[i + 1] <= 0xbf) &&
         (pszBuff[i + 2] >= 0x80 && pszBuff[i + 2] <= 0xbf)){
        i += 3;
        continue;
      }
      break;
    }
    else if(pszBuff[i] >= 0xf0 && pszBuff[i] <= 0xf7){
      if(((i + 1) < strlen(pszBuff)) &&
         (pszBuff[i + 1] >= 0x80 && pszBuff[i + 1] <= 0xbf) &&
         (pszBuff[i + 2] >= 0x80 && pszBuff[i + 2] <= 0xbf) &&
         (pszBuff[i + 3] >= 0x80 && pszBuff[i + 3] <= 0xbf)){
        i += 4;
        continue;
      }
      break;
    }
    else if(pszBuff[i] >= 0xf8 && pszBuff[i] <= 0xfb){
      if(((i + 1) < strlen(pszBuff)) &&
         (pszBuff[i + 1] >= 0x80 && pszBuff[i + 1] <= 0xbf) &&
         (pszBuff[i + 2] >= 0x80 && pszBuff[i + 2] <= 0xbf) &&
         (pszBuff[i + 3] >= 0x80 && pszBuff[i + 3] <= 0xbf) &&
         (pszBuff[i + 4] >= 0x80 && pszBuff[i + 4] <= 0xbf)){
        i += 5;
        continue;
      }
      break;
    }
    else if(pszBuff[i] >= 0xfc && pszBuff[i] <= 0xfd){
      if(((i + 5) < strlen(pszBuff)) &&
         (pszBuff[i + 1] >= 0x80 && pszBuff[i + 1] <= 0xbf) &&
         (pszBuff[i + 2] >= 0x80 && pszBuff[i + 2] <= 0xbf) &&
         (pszBuff[i + 3] >= 0x80 && pszBuff[i + 3] <= 0xbf) &&
         (pszBuff[i + 4] >= 0x80 && pszBuff[i + 4] <= 0xbf) &&
         (pszBuff[i + 5] >= 0x80 && pszBuff[i + 5] <= 0xbf)){
        i += 6;
        continue;
      }
      break;
    }
    else{
      break;
    }
  }
  if(i != (strlen(pszBuff) - 1)){
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_ValidateDisplayName
*  Description  :  Checks if it is a valid Display Name
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : *(token LWS)/ quoted-string
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateDisplayName(char8* pszBuff)
{
  if(pszBuff[0] == '\"'){
    return IFX_SIP_ValidateQuotedString(pszBuff);
  }
  else{
    /* Not checking for \r\n as they are removed in the 1st level */
    return IFX_SIP_ValidateDisplayToken(pszBuff);
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_ValidateHostName
*  Description  :  Identifies the hostname
*  Input Values :  char buffer
*  Output Values:  None
*  Return Value :  Success or failure of validation
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateHostName(char8* pszBuff)
{
  char8* pcTempStart, * pcTempEnd, * pLastdot = NULL;
  pcTempStart = pszBuff;
  pcTempEnd = pszBuff + strlen(pszBuff);
  if(isalnum(*pcTempStart)){
    pcTempStart++;
    do{
      if(isalnum(*pcTempStart) || (*pcTempStart == '-')){
        pcTempStart++;
        continue;
      }
      else if(*pcTempStart == '.'){
        pLastdot = pcTempStart;
        if(!isalnum(*(pcTempStart - 1))){
          return IFX_SIP_FAILURE;
        }
        pcTempStart++;
        if(pcTempStart > pcTempEnd){
          return IFX_SIP_FAILURE;
        }
        if(!isalnum(*pcTempStart)){
          return IFX_SIP_FAILURE;
        }
        pcTempStart++;
      }
      else{
        return IFX_SIP_FAILURE;
      }
    }
    while(pcTempStart < pcTempEnd);
    if((pLastdot != NULL) && (!(isalpha(*(pLastdot + 1))))){
      return IFX_SIP_FAILURE;
    }
  }
  else{
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_IdentifyType
*  Description  :  Identifies the host type
*  Input Values :  char buffer
*  Output Values:  None
*  Return Value :  Host Type
*  Notes        : 
*********************************************************************/
e_IFX_SIP_HostType
IFX_SIP_IdentifyType(char8* pszBuff)
{
  uint32 i;
  e_IFX_SIP_HostType e_Type = IFX_SIP_HOSTINVALID; 
  for(i = 0; i < strlen(pszBuff); i++){
    if((pszBuff[i] > 47 && pszBuff[i] < 58) || (pszBuff[i] == '.')){
      continue;
    }
    else{
      break;
    }
  }
  if(i == strlen(pszBuff)){
    e_Type = IFX_SIP_IPV4ADDR;
    if(IFX_SIP_ValidateIPv4Addr(pszBuff) == IFX_SIP_FAILURE){
      e_Type = IFX_SIP_HOSTINVALID;
    }
  }
  else{
    e_Type = IFX_SIP_HOSTNAME;
  }
  if(strchr(pszBuff,'[') != NULL){
    e_Type = IFX_SIP_IPV6REF;
    /* Validate IPv6 address */
    if(IFX_SIP_ValidateIPv6Addr(pszBuff) == IFX_SIP_FAILURE){
      e_Type = IFX_SIP_HOSTINVALID;
    }
  }
  if(e_Type == IFX_SIP_HOSTNAME){
    if(IFX_SIP_ValidateHostName(pszBuff) == IFX_SIP_FAILURE){
      e_Type = IFX_SIP_HOSTINVALID;
    }
  }
  return e_Type;
}

/******************************************************************
*  Function Name:  IFX_SIP_ValidateGenValue
*  Description  :  Checks if it is a valid Gen Value
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : host/token/ quoted-string
*                 First Check if it is a quoted string, and validate
*                 else validate token and if it fails validate Host
*         Information
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateGenValue(char8* pszBuff)
{
  if(pszBuff[0] == '\"'){
    return IFX_SIP_ValidateQuotedString(pszBuff);
  }
  else{
    if(IFX_SIP_ValidateToken(pszBuff) == IFX_SIP_FAILURE){
      if(IFX_SIP_IdentifyType(pszBuff) == IFX_SIP_HOSTINVALID){
        return IFX_SIP_FAILURE;
      }
    }
  }     
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_ValidatePhoneDigit
*  Description  :  Checks if it is a valid Phone digit
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidatePhoneDigit(char8* pszBuff)
{
  uint32 i = 0;
  while(i < strlen(pszBuff)){
    if(isdigit(pszBuff[i]) ||
       (pszBuff[i] == '-') ||
       (pszBuff[i] == '(') ||
       (pszBuff[i] == ')') ||
       (pszBuff[i] == '(')){
      i++;
      continue;
    }
    else{
      break;
    }
  }
  if(i != strlen(pszBuff)){
    return IFX_SIP_FAILURE;
  } 
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_ValidateLocalPhoneNum
*  Description  :  Checks if it is a valid Local Phone number
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateLocalPhoneNum(char8* pszBuff)
{
  uint32 i = 0;
  while(i < strlen(pszBuff)){
    if(isdigit(pszBuff[i]) ||
       (pszBuff[i] == '-') ||
       (pszBuff[i] == '(') ||
       (pszBuff[i] == ')') ||
       (pszBuff[i] == '(') ||
       (pszBuff[i] == 'p') ||
       (pszBuff[i] == 'w') ||
       (pszBuff[i] == '*') ||
       (pszBuff[i] == '#') ||
       (pszBuff[i] == 'A') ||
       (pszBuff[i] == 'B') ||
       (pszBuff[i] == 'C') ||
       (pszBuff[i] == 'D')){
      i++;
      continue;
    }
    else{
      break;
    }
  }
  if(i != strlen(pszBuff)){
    return IFX_SIP_FAILURE;
  } 
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_ValidateAndSetRecvAddrType
*  Description  :  Identifies and sets the type of IP address
*  Input Values :  x_IFX_SIP_RcvdAddr
*  Output Values:  x_IFX_SIP_RcvdAddr
*  Return Value :  Success or failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateAndSetRecvAddrType(IN  x_IFX_SIP_RcvdAddr* pxRecvAddr,
                                    OUT x_IFX_SIP_Error* pxSipError)
{
  uint32 i;
  for(i = 0; i < strlen(pxRecvAddr->szIpAddr); i++){
    if((pxRecvAddr->szIpAddr[i] > 47 && pxRecvAddr->szIpAddr[i] < 58) ||
       (pxRecvAddr->szIpAddr[i] == '.')){
      continue;
    }
    else{
      break;
    }
  }
  if(i == strlen(pxRecvAddr->szIpAddr)){
    pxRecvAddr->eRcvdAddrType = IFX_SIP_RCVD_IPV4;
    /* Validate IPV4 Address */
    if(IFX_SIP_ValidateIPv4Addr(pxRecvAddr->szIpAddr) == IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_ADDR;
      strcpy(pxSipError->szErrorDesc,"Invalid IPv4 address");
      return IFX_SIP_FAILURE;
    }
  }
  else{
    pxRecvAddr->eRcvdAddrType = IFX_SIP_RCVD_IPV6;
    /* Validate IPV6 Address */
    if(IFX_SIP_ValidateIPv6Addr(pxRecvAddr->szIpAddr) == IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_ADDR;
      strcpy(pxSipError->szErrorDesc,"Invalid IPv6 address");
      return IFX_SIP_FAILURE;
    }
  } 
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_DecPhoneContextIdent
*  Description  :  Decodes the Phone COntest Identity
*  Input Values :  start and end indices of msg
*  Output Values:  Fills the data structure for Phone context identity
*  Return Value :  Success or failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecPhoneContextIdent(IN  char8* pcStartIndex,
                              IN  char8* pcEndIndex,
                              OUT x_IFX_SIP_PhContextIdent* pxPhConId,
                              OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart;
  pcTempStart = pcStartIndex;
  if(*pcTempStart == '+'){
    pxPhConId->ePrefixType = IFX_SIP_NW_PREFIX;
    pxPhConId->uxPrefixType.xNwPrefix.eNwPrefixType = IFX_SIP_GLOBAL_NW_PREFIX;
    /* Boundary Checks */
    if(((pcEndIndex - (pcTempStart + 1)) >= IFX_SIP_MAX_PHONE_NUMBER) ||
       ((pcEndIndex - (pcTempStart + 1)) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_MAXPHONDIG_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Max Global N/w Prefix exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxPhConId->uxPrefixType.xNwPrefix.szNwPrefix,
            (pcTempStart + 1),
            (pcEndIndex - (pcTempStart + 1)));
    pxPhConId->uxPrefixType.xNwPrefix.
                  szNwPrefix[(pcEndIndex - (pcTempStart + 1))] = '\0';
    /* Validation */
    if(IFX_SIP_ValidatePhoneDigit(pxPhConId->uxPrefixType.xNwPrefix.
      szNwPrefix) == IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_PHONEDIG;
      strcpy(pxSipError->szErrorDesc,"Invalid Global N/W Prefix");
      return IFX_SIP_FAILURE;
    }
  }
  else if(*pcTempStart == '#'){
    /* Assuming numbers starting with # are private n/w */
    pxPhConId->ePrefixType = IFX_SIP_PRIVATE_PREFIX;
    /* Boundary Checks */
    if(((pcEndIndex - (pcTempStart + 1)) >= IFX_SIP_MAX_TOKEN) ||
       ((pcEndIndex - (pcTempStart + 1)) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_MAXTOKEN_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Max private Prefix exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxPhConId->uxPrefixType.szPrivatePrefix,
            (pcTempStart + 1),
            (pcEndIndex - (pcTempStart + 1)));
    pxPhConId->uxPrefixType.
               szPrivatePrefix[(pcEndIndex - (pcTempStart + 1))] = '\0';
    /* TBF: Validation */
  }
  else{
    pxPhConId->ePrefixType = IFX_SIP_NW_PREFIX;
    pxPhConId->uxPrefixType.xNwPrefix.eNwPrefixType = IFX_SIP_LOCAL_NW_PREFIX;
    /* Boundary Checks */
    if(((pcEndIndex - pcTempStart) >= IFX_SIP_MAX_PHONE_NUMBER) ||
       ((pcEndIndex - pcTempStart) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_MAXPHONDIG_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Max Local N/w Prefix exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxPhConId->uxPrefixType.xNwPrefix.szNwPrefix,
            pcTempStart,
            (pcEndIndex - pcTempStart));
    pxPhConId->uxPrefixType.xNwPrefix.
                               szNwPrefix[(pcEndIndex - pcTempStart)] = '\0';
    /* Validation */
    if(IFX_SIP_ValidateLocalPhoneNum(pxPhConId->uxPrefixType.xNwPrefix.
      szNwPrefix) == IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_PHONEDIG;
      strcpy(pxSipError->szErrorDesc,"Invalid Local N/W Prefix");
      return IFX_SIP_FAILURE;
    }
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_DecGlobalTelInfo
*  Description  :  Decodes the global info
*  Input Values :  start and end indices of msg
*  Output Values:  Fills the data structure for Tel URI
*  Return Value :  Success or failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecGlobalTelInfoParam(IN  char8* pcStartIndex,
                               IN  char8* pcEndIndex,
                               OUT x_IFX_SIP_TelSub* pxTelUri,
                               OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcCurrPos, acTemp[IFX_SIP_MAX_TOKEN];
  pcTempStart = pcStartIndex;
  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'=');
  if(pcCurrPos == NULL){
    pcCurrPos = pcEndIndex;
  }
  else{
    if(((pcCurrPos - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
       ((pcCurrPos - pcTempStart) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_MAXTOKEN_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Tag Type Exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(acTemp,pcTempStart,(pcCurrPos - pcTempStart));
    acTemp[(pcCurrPos - pcTempStart)] = '\0';
    pcCurrPos++;
  }
  if(IFX_SIP_strcasecmp(acTemp,"isub") == 0){
    if(((pcEndIndex - pcCurrPos) >= IFX_SIP_MAX_PHONEDIGIT) ||
       ((pcEndIndex - pcCurrPos) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_MAXPHONDIG_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"ISDN subaddr Exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxTelUri->szIsdnSubAddr,pcCurrPos,(pcEndIndex - pcCurrPos));
    pxTelUri->szIsdnSubAddr[(pcEndIndex - pcCurrPos)] = '\0';
    /* Validation */
    if(IFX_SIP_ValidatePhoneDigit(pxTelUri->szIsdnSubAddr) ==
       IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_PHONEDIG;
      strcpy(pxSipError->szErrorDesc,"Invalid isub");
      return IFX_SIP_FAILURE;
    }
  }
  else if(IFX_SIP_strcasecmp(acTemp,"postd") == 0){
    if(((pcEndIndex - pcCurrPos) >= IFX_SIP_MAX_PHONEDIGIT) ||
       ((pcEndIndex - pcCurrPos) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_MAXPHONDIG_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Postd Exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxTelUri->szPostDial,pcCurrPos,(pcEndIndex - pcCurrPos));
    pxTelUri->szPostDial[(pcEndIndex - pcCurrPos)] = '\0';
    /* Validation */
    if(IFX_SIP_ValidateLocalPhoneNum(pxTelUri->szPostDial) ==
       IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_PHONEDIG;
      strcpy(pxSipError->szErrorDesc,"Invalid Post Dail");
      return IFX_SIP_FAILURE;
    }
  }
  else if(IFX_SIP_strcasecmp(acTemp,"phone-context") == 0){
    /* Phone context decoding */
    if(pxTelUri->ucNoOfAreaSpec >= IFX_SIP_MAX_AREA_SPEC){
      pxSipError->eDecodeErr = IFX_SIP_MAXAREASPEC_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Max Area Spec Exceeded");
      return IFX_SIP_FAILURE;
    }
    if(IFX_SIP_DecPhoneContextIdent(pcCurrPos,pcEndIndex,&pxTelUri->
      axPhContextIdent[pxTelUri->ucNoOfAreaSpec],pxSipError) ==
       IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
    pxTelUri->ucNoOfAreaSpec++;
  }
  else if(IFX_SIP_strcasecmp(acTemp,"tsp") == 0){
    uint32 i;
    i = pxTelUri->ucNoOfServProv;
    if(i > IFX_SIP_MAX_SERV_PROV){
      pxSipError->eDecodeErr = IFX_SIP_MAXSERV_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Max Serv Provider Exceeded");
      return IFX_SIP_FAILURE;
    }
    if(((pcEndIndex - pcCurrPos) >= IFX_SIP_MAX_DOMAIN) ||
       ((pcEndIndex - pcCurrPos) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_MAXDOMAIN_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"SerProv Exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxTelUri->aszSerProv[i],pcCurrPos,(pcEndIndex - pcCurrPos));
    pxTelUri->aszSerProv[i][(pcEndIndex - pcCurrPos)] = '\0';
    /* TBF: Validation */
    pxTelUri->ucNoOfServProv++;
  }
  else{
    uint32 i;
    i = pxTelUri->ucNoOfExt;
    if(i >= IFX_SIP_MAX_FUT_EXT){
      pxSipError->eDecodeErr = IFX_SIP_MAXFUTEXT_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Max Future Extn Exceeded");
      return IFX_SIP_FAILURE;
    }
    if(((pcEndIndex - pcCurrPos) >= IFX_SIP_MAX_TOKEN) ||
       ((pcEndIndex - pcCurrPos) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_MAXDOMAIN_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Future Extn Exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxTelUri->aszFutExt[i],pcTempStart,(pcEndIndex - pcTempStart));
    pxTelUri->aszFutExt[i][(pcEndIndex - pcTempStart)] = '\0';
    /* TBF: Validation */
    pxTelUri->ucNoOfExt++;
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_DecGlobalTelInfo
*  Description  :  Decodes the global info
*  Input Values :  start and end indices of msg
*  Output Values:  Fills the data structure for Tel URI
*  Return Value :  Success or failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecGlobalTelInfo(IN  char8* pcStartIndex,
                          IN  char8* pcEndIndex,
                          OUT x_IFX_SIP_TelSub* pxTelUri,
                          OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcCurrPos;
  pcTempStart = pcStartIndex;
  do{
    pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
    if(pcCurrPos == NULL){
      if(IFX_SIP_DecGlobalTelInfoParam(pcTempStart,
                                        pcEndIndex,
                                        pxTelUri,
                                        pxSipError) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
      break;
    }
    else{
      if(IFX_SIP_DecGlobalTelInfoParam(pcTempStart,
                                        pcCurrPos,
                                        pxTelUri,
                                        pxSipError) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
      pcTempStart = pcCurrPos + 1;
    }
  }
  while(1);
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_DecLocalTelInfoParam
*  Description  :  Decodes the Local Tel info
*  Input Values :  start and end indices of msg
*  Output Values:  Fills the data structure for Tel URI
*  Return Value :  Success or failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecLocalTelInfoParam(IN  char8* pcStartIndex,
                              IN  char8* pcEndIndex,
                              OUT x_IFX_SIP_TelSub* pxTelUri,
                              OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcCurrPos, acTemp[IFX_SIP_MAX_TOKEN];
  pcTempStart = pcStartIndex;
  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'=');
  if(pcCurrPos == NULL){
    pcCurrPos = pcEndIndex;
  }
  else{
    if(((pcCurrPos - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
       ((pcCurrPos - pcTempStart) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_MAXTOKEN_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Tag Type Exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(acTemp,pcTempStart,(pcCurrPos - pcTempStart));
    acTemp[(pcCurrPos - pcTempStart)] = '\0';
    pcCurrPos++;/* As it points to '=' */
  }
  if(IFX_SIP_strcasecmp(acTemp,"isub") == 0){
    if(((pcEndIndex - pcCurrPos) >= IFX_SIP_MAX_PHONEDIGIT) ||
       ((pcEndIndex - pcCurrPos) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_MAXPHONDIG_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"ISDN subaddr Exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxTelUri->szIsdnSubAddr,pcCurrPos,(pcEndIndex - pcCurrPos));
    pxTelUri->szIsdnSubAddr[(pcEndIndex - pcCurrPos)] = '\0';
    /* Validation */
    if(IFX_SIP_ValidatePhoneDigit(pxTelUri->szIsdnSubAddr) ==
       IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_PHONEDIG;
      strcpy(pxSipError->szErrorDesc,"Invalid isub");
      return IFX_SIP_FAILURE;
    }
  }
  else if(IFX_SIP_strcasecmp(acTemp,"postd") == 0){
    if(((pcEndIndex - pcCurrPos) >= IFX_SIP_MAX_PHONEDIGIT) ||
       ((pcEndIndex - pcCurrPos) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_MAXPHONDIG_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Postd Exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxTelUri->szPostDial,pcCurrPos,(pcEndIndex - pcCurrPos));
    pxTelUri->szPostDial[(pcEndIndex - pcCurrPos)] = '\0';
    /* Validation */
    if(IFX_SIP_ValidateLocalPhoneNum(pxTelUri->szPostDial) ==
       IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_PHONEDIG;
      strcpy(pxSipError->szErrorDesc,"Invalid post dail");
      return IFX_SIP_FAILURE;
    }
  }
  else if(IFX_SIP_strcasecmp(acTemp,"phone-context") == 0){
    /* Phone context decoding */
    if(pxTelUri->ucNoOfAreaSpec >= IFX_SIP_MAX_AREA_SPEC){
      pxSipError->eDecodeErr = IFX_SIP_MAXAREASPEC_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Max Area Spec Exceeded");
      return IFX_SIP_FAILURE;
    }
    if(IFX_SIP_DecPhoneContextIdent(pcCurrPos,pcEndIndex,&pxTelUri->
      axPhContextIdent[pxTelUri->ucNoOfAreaSpec],pxSipError) ==
       IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
    pxTelUri->ucNoOfAreaSpec++;
  }
  else if(IFX_SIP_strcasecmp(acTemp,"tsp") == 0){
    uint32 i;
    i = pxTelUri->ucNoOfServProv;
    if(i >= IFX_SIP_MAX_SERV_PROV){
      pxSipError->eDecodeErr = IFX_SIP_MAXSERV_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Max Serv Provider Exceeded");
      return IFX_SIP_FAILURE;
    }
    if(((pcEndIndex - pcCurrPos) >= IFX_SIP_MAX_DOMAIN) ||
       ((pcEndIndex - pcCurrPos) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_MAXDOMAIN_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"SerProv Exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxTelUri->aszSerProv[i],pcCurrPos,(pcEndIndex - pcCurrPos));
    pxTelUri->aszSerProv[i][(pcEndIndex - pcCurrPos)] = '\0';
    /* TBF: Validation */
    pxTelUri->ucNoOfServProv++;
  }
  else{
    uint32 i;
    i = pxTelUri->ucNoOfExt;
    if(i >= IFX_SIP_MAX_FUT_EXT){
      pxSipError->eDecodeErr = IFX_SIP_MAXFUTEXT_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Max Future Extn Exceeded");
      return IFX_SIP_FAILURE;
    }
    if(((pcEndIndex - pcCurrPos) >= IFX_SIP_MAX_TOKEN) ||
       ((pcEndIndex - pcCurrPos) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_MAXDOMAIN_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Future Extn Exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxTelUri->aszFutExt[i],pcTempStart,(pcEndIndex - pcTempStart));
    pxTelUri->aszFutExt[i][(pcEndIndex - pcTempStart)] = '\0';
    /* TBF: Validation */
    pxTelUri->ucNoOfExt++;
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_DecLocalTelInfo
*  Description  :  Decodes the global info
*  Input Values :  start and end indices of msg
*  Output Values:  Fills the data structure for Tel URI
*  Return Value :  Success or failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecLocalTelInfo(IN  char8* pcStartIndex,
                         IN  char8* pcEndIndex,
                         OUT x_IFX_SIP_TelSub* pxTelUri,
                         OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcCurrPos;
  pcTempStart = pcStartIndex;
  do{
    pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
    if(pcCurrPos == NULL){
      if(IFX_SIP_DecLocalTelInfoParam(pcTempStart,
                                       pcEndIndex,
                                       pxTelUri,
                                       pxSipError) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
      break;
    }
    else{
      if(IFX_SIP_DecLocalTelInfoParam(pcTempStart,
                                       pcCurrPos,
                                       pxTelUri,
                                       pxSipError) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
      pcTempStart = pcCurrPos + 1;
    }
  }
  while(1);
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_DecTelSubscriber
*  Description  :  Decodes the telephone subscriber
*  Input Values :  a character string
*  Output Values:  Fills the data structure for Tel URI
*  Return Value :  Success or failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecTelSubscriber(IN  char8* pUser,
                          OUT x_IFX_SIP_TelSub* pxTelUri,
                          OUT x_IFX_SIP_Error* pxSipError)
{
  char8 szUser[IFX_SIP_MAX_TOKEN];
  char8* pcCurrPos, * pcTempStart, * pcEndIndex;
  strcpy(szUser,pUser);
  memset(pxTelUri,0,sizeof(x_IFX_SIP_TelSub));
  pcEndIndex = szUser + strlen(szUser);
  if(szUser[0] == '+'){
    /* Global Phone Number */
    pxTelUri->eTelSubType = IFX_SIP_GLOBAL_PHONE_NUMBER;
    pcTempStart = szUser + 1;   
    pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
    if(pcCurrPos == NULL){
      /* Only Base phone Number is Present */
      if(((pcEndIndex - pcTempStart) >= IFX_SIP_MAX_PHONEDIGIT) ||
         ((pcEndIndex - pcTempStart) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_MAXPHONDIG_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Base phone number exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxTelUri->szPhoneNo,pcTempStart,(pcEndIndex - pcTempStart));
      pxTelUri->szPhoneNo[(pcEndIndex - pcTempStart)] = '\0';
      /* Validate */
      if(IFX_SIP_ValidatePhoneDigit(pxTelUri->szPhoneNo) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_PHONEDIG;
        strcpy(pxSipError->szErrorDesc,"Invalid Base Phone Number");
        return IFX_SIP_FAILURE;
      }
    }
    else{
      if(((pcCurrPos - pcTempStart) >= IFX_SIP_MAX_PHONEDIGIT) ||
         ((pcCurrPos - pcTempStart) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_MAXPHONDIG_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Base phone number exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxTelUri->szPhoneNo,pcTempStart,(pcCurrPos - pcTempStart));
      pxTelUri->szPhoneNo[(pcCurrPos - pcTempStart)] = '\0';
      /* Validate */
      if(IFX_SIP_ValidatePhoneDigit(pxTelUri->szPhoneNo) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_PHONEDIG;
        strcpy(pxSipError->szErrorDesc,"Invalid Base Phone Number");
        return IFX_SIP_FAILURE;
      }
      pcTempStart = pcCurrPos + 1; /* As it is poining to ; */
      /* Decode other info */
      if(IFX_SIP_DecGlobalTelInfo(pcTempStart,pcEndIndex,pxTelUri,
         pxSipError) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
    }
  }
  else{
    pcTempStart = szUser + 1;
    /* Local Phone Number*/
    pxTelUri->eTelSubType = IFX_SIP_LOCAL_PHONE_NUMBER;
    pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
    if(pcCurrPos == NULL){
      /* Invalid msg format return Error */
      pxSipError->eDecodeErr = IFX_SIP_INVALID_LOCALPHONENOFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Phone number format");
      return IFX_SIP_FAILURE;
    }
    else{
      if(((pcCurrPos - pcTempStart) >= IFX_SIP_MAX_PHONEDIGIT) ||
         ((pcCurrPos - pcTempStart) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_MAXPHONDIG_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Local phone number exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxTelUri->szPhoneNo,pcTempStart,(pcCurrPos - pcTempStart));
      pxTelUri->szPhoneNo[(pcCurrPos - pcTempStart)] = '\0';
      /* Validate */      
      if(IFX_SIP_ValidateLocalPhoneNum(pxTelUri->szPhoneNo) ==
         IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_PHONEDIG;
        strcpy(pxSipError->szErrorDesc,"Invalid Local Phone Number");
        return IFX_SIP_FAILURE;
      }
      pcTempStart = pcCurrPos + 1; /* As it is poining to ; */
      /* Decode other info */
      if(IFX_SIP_DecLocalTelInfo(pcCurrPos,pcEndIndex,pxTelUri,pxSipError) ==
         IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
    }
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeMethod
*  Description  :  Decodes the Method
*  Input Values :  Start and End indices to Method
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeMethod(IN  char8* pcStartIndex,
                      IN  char8* pcEndIndex,
                      OUT x_IFX_SIP_Method* pxMethod,
                      OUT x_IFX_SIP_Error* pxSipError)
{
  uint32 i, iCount = 0;

  iCount = pcEndIndex - pcStartIndex;

  /* Match them against the known set of methods */
  for(i = 0; i < (IFX_SIP_EXT_METHOD); i++){
    if(strncmp(pcStartIndex,
               vtblszMethod[i],
               IFX_SIP_MAX(strlen(vtblszMethod[i]),iCount)) == 0){
      pxMethod->eBasicMethod = i + 1;
      strncpy(pxMethod->szExtMethod,pcStartIndex,(pcEndIndex - pcStartIndex));
      pxMethod->szExtMethod[(pcEndIndex - pcStartIndex)] = '\0';
      return IFX_SIP_SUCCESS;
    }
  }

  /* Set the type and copy the extension method */
  pxMethod->eBasicMethod = IFX_SIP_EXT_METHOD;
  if(((pcEndIndex - pcStartIndex) >= IFX_SIP_MAX_TOKEN) ||
     ((pcEndIndex - pcStartIndex) <= 0)){
    pxSipError->eDecodeErr = IFX_SIP_METHOD_EXCEEDED;
    strcpy(pxSipError->szErrorDesc,"Extension method name exceeded");
    return IFX_SIP_FAILURE;
  }
  strncpy(pxMethod->szExtMethod,pcStartIndex,(pcEndIndex - pcStartIndex));
  pxMethod->szExtMethod[(pcEndIndex - pcStartIndex)] = '\0';

  /* Validate if extension method */
  if(IFX_SIP_ValidateToken(pxMethod->szExtMethod) == IFX_SIP_FAILURE){
    pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
    strcpy(pxSipError->szErrorDesc,"Invalid extension Method");
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_DecodeHostPort
*  Description  :  Decodes the HostPort information
*  Input Values :  Start and End indices to Host Port
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeHostPort(IN  char8* pcStartIndex,
                        IN  char8* pcEndIndex,
                        OUT x_IFX_SIP_HostPort* pxHostPort,
                        OUT x_IFX_SIP_Error* pxSipError)
{
  char* pcTempStart, * pcTempEnd, * pcCurrPos, * pcTemp = NULL;
  char cRet;
  uint32 i, iflag = 0;

  /* copy pcStartIndex and pcEndIndex into temporary pointers */
  pcTempStart = pcStartIndex;
  pcTempEnd = pcEndIndex;
  pcCurrPos = pcTempStart;

  do{
    cRet = IFX_SIP_strtok(pcTempStart,pcEndIndex,&pcCurrPos,"[:");
    if(cRet == '['){
      if(iflag != 1){
        pcTemp = pcTempStart;
      }
      pcTempStart = pcCurrPos + 1;
      pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,']'); 
      if(pcCurrPos == NULL){
        return IFX_SIP_FAILURE;
      }
      else{
        pcTempStart = pcCurrPos + 1;
      }
      iflag = 1;
    }
    else if(cRet == ':'){
      pcTempEnd = pcCurrPos;
      break;
    }
    else{
      pcTempEnd = pcEndIndex;
      pcCurrPos = NULL;
      break;
    }
  }
  while(1);
  if(iflag == 1){
    pcTempStart = pcTemp;
    iflag = 0;
  }

  /* Copy the host information */
  if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
     ((pcTempEnd - pcTempStart) <= 0)){
    pxSipError->eDecodeErr = IFX_SIP_HOSTNAME_EXCEEDED;
    strcpy(pxSipError->szErrorDesc,"Host name exceeded the limit");
    return IFX_SIP_FAILURE;
  }
  strncpy(pxHostPort->xHost.szHostInfo,pcTempStart,(pcTempEnd - pcTempStart));
  pxHostPort->xHost.szHostInfo[(pcTempEnd - pcTempStart)] = '\0';

  /* Validation of Host Info */
  pxHostPort->xHost.eHostType = IFX_SIP_IdentifyType(pxHostPort->xHost.
    szHostInfo);
  if(pxHostPort->xHost.eHostType == IFX_SIP_HOSTINVALID){
    pxSipError->eDecodeErr = IFX_SIP_INVALID_HOSTINFO;
    strcpy(pxSipError->szErrorDesc,"Invalid Host Info");
    return IFX_SIP_FAILURE;
  }


  if(pcCurrPos != NULL){
    /* port is present */
    char8 szPort[10];

    /* Handling the port information */
    pcCurrPos++;/* As it is pointing to : */
    if(((pcEndIndex - pcCurrPos) > 10 /*max is int 32*/) ||
       ((pcEndIndex - pcCurrPos) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_HOSTPORT_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Host port exceeded the num digits");
      return IFX_SIP_FAILURE;
    }
    strncpy(szPort,pcCurrPos,(pcEndIndex - pcCurrPos));
    szPort[(pcEndIndex - pcCurrPos)] = '\0';

    for(i = 0; i < strlen(szPort); i++){
      if(!isdigit(szPort[i])){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_DIGIT;
        strcpy(pxSipError->szErrorDesc,"Port Info Invalid");
        return IFX_SIP_FAILURE;
      }
    }

    pxHostPort->uiPort = atoi(szPort);
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_DecodeHeaders
*  Description  :  Decodes the Headers information in URI
*  Input Values :  Start and End indices to Headers
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeHeaders(IN  char8* pcStartIndex,
                       IN  char8* pcEndIndex,
                       OUT x_IFX_SIP_Headers* pxHdrs,
                       OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcCurrPos, * pcTempStart, cRet;
  int32 bHeadersPresent = 1;

  pxHdrs->ucNoOfHeader = 0;
  pcTempStart = pcStartIndex;

  /* No Spaces allowed after ? so dont remove white spaces */

  do{
    if((pxHdrs->ucNoOfHeader) >= IFX_SIP_MAX_HEADER){
      pxSipError->eDecodeErr = IFX_SIP_HDR_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Header Value array exceeded");
      bHeadersPresent = 0;
      return IFX_SIP_FAILURE;
    }

    /* Check for the delimiters */
    cRet = IFX_SIP_strtok(pcTempStart,pcEndIndex,&pcCurrPos,"&=");
    if(cRet == '&'){
      /* Only header name present and no header value */
      if(((pcCurrPos - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
         ((pcCurrPos - pcTempStart) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_HDR_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Header name in SIP URI exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxHdrs->axHeader[pxHdrs->ucNoOfHeader].szHeaderName,
              pcTempStart,
              (pcCurrPos - pcTempStart));
      pxHdrs->axHeader[pxHdrs->ucNoOfHeader].
                            szHeaderName[(pcCurrPos - pcTempStart)] = '\0';
      if(IFX_SIP_ValidateHeaderName(pxHdrs->
         axHeader[pxHdrs->ucNoOfHeader].szHeaderName) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_HEADERINFO_INVALID;
        strcpy(pxSipError->szErrorDesc,"Header name invalid");
        return IFX_SIP_FAILURE;
      }
      pcTempStart = pcCurrPos + 1;/* As it points to & */
    }
    else if(cRet == '='){
      if(((pcCurrPos - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
         ((pcCurrPos - pcTempStart) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_HDR_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"HeaderName in SIP URI exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxHdrs->axHeader[pxHdrs->ucNoOfHeader].szHeaderName,
              pcTempStart,
              (pcCurrPos - pcTempStart));
      pxHdrs->axHeader[pxHdrs->ucNoOfHeader].
                      szHeaderName[(pcCurrPos - pcTempStart)] = '\0';
      if(IFX_SIP_ValidateHeaderName(pxHdrs->
         axHeader[pxHdrs->ucNoOfHeader].szHeaderName) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_HEADERINFO_INVALID;
        strcpy(pxSipError->szErrorDesc,"Header name invalid");
        return IFX_SIP_FAILURE;
      }
      pcTempStart = pcCurrPos + 1; /* As it is pointing to = */     
      pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'&');
      if(pcCurrPos == NULL){
        /* Last header info in the list */
        if(((pcEndIndex - pcTempStart) >= IFX_SIP_MAX_HEADERVALUE) ||
           ((pcEndIndex - pcTempStart) <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_HDR_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Header name in SIP URI exceeded");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxHdrs->axHeader[pxHdrs->ucNoOfHeader].szHeaderVal,
                pcTempStart,
                (pcEndIndex - pcTempStart));
        pxHdrs->axHeader[pxHdrs->ucNoOfHeader].
                  szHeaderVal[(pcEndIndex - pcTempStart)] = '\0';
        if(IFX_SIP_ValidateHeaderName(pxHdrs->axHeader[pxHdrs->
          ucNoOfHeader].szHeaderVal) == IFX_SIP_FAILURE){
          pxSipError->eDecodeErr = IFX_SIP_HEADERINFO_INVALID;
          strcpy(pxSipError->szErrorDesc,"Header name invalid");
          return IFX_SIP_FAILURE;
        }
        bHeadersPresent = 0;
      }
      else{
        if(((pcCurrPos - pcTempStart) >= IFX_SIP_MAX_HEADERVALUE) ||
           ((pcCurrPos - pcTempStart) <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_HDR_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Header name in SIP URI exceeded");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxHdrs->axHeader[pxHdrs->ucNoOfHeader].szHeaderVal,
                pcTempStart,
                (pcCurrPos - pcTempStart));
        pxHdrs->axHeader[pxHdrs->ucNoOfHeader].
                               szHeaderVal[(pcCurrPos - pcTempStart)] = '\0';
        if(IFX_SIP_ValidateHeaderName(pxHdrs->axHeader[pxHdrs->
          ucNoOfHeader].szHeaderVal) == IFX_SIP_FAILURE){
          pxSipError->eDecodeErr = IFX_SIP_HEADERINFO_INVALID;
          strcpy(pxSipError->szErrorDesc,"Header name invalid");
          return IFX_SIP_FAILURE;
        }
        pcTempStart = pcCurrPos + 1;/* As it is pointing to & */
      }
    }
    else if(cRet == IFX_SIP_TOKEN_NOTFOUND){
      /* Only the Header name is present */
      if(((pcEndIndex - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
         ((pcEndIndex - pcTempStart) <= IFX_SIP_MAX_TOKEN)){
        pxSipError->eDecodeErr = IFX_SIP_HDR_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Header name in SIP URI exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxHdrs->axHeader[pxHdrs->ucNoOfHeader].szHeaderName,
              pcTempStart,
              (pcEndIndex - pcTempStart));
      pxHdrs->axHeader[pxHdrs->ucNoOfHeader].
                         szHeaderName[(pcEndIndex - pcTempStart)] = '\0';
      if(IFX_SIP_ValidateHeaderName(pxHdrs->axHeader[pxHdrs->
        ucNoOfHeader].szHeaderName) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_HEADERINFO_INVALID;
        strcpy(pxSipError->szErrorDesc,"Header name invalid");
        return IFX_SIP_FAILURE;
      }
      bHeadersPresent = 0;
    }
    pxHdrs->ucNoOfHeader++;
  }
  while(bHeadersPresent);
  return IFX_SIP_SUCCESS;
}


/******************************************************************
*  Function Name:  IFX_SIP_DecodeURIParams
*  Description  :  Decodes the URI parameters
*  Input Values :  Start and End indices of To parameters
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/

e_IFX_SIP_Return
IFX_SIP_DecodeURIParams(IN  char8* pcStartIndex,
                         IN  char8* pcEndIndex,
                         OUT x_IFX_SIP_SipUri* pxSipUri,
                         /*OUT x_IFX_SIP_UriParams *pxUri,*/
                 OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcCurrPos, * pcTempStart, cRet, *pcTempEnd,acTemp[IFX_SIP_MAX_TOKEN];
  int32 i, flag = 1;
  x_IFX_SIP_UriParams* pxUri = &pxSipUri->xUriParams;
  pcTempStart = pcCurrPos = pcStartIndex; 
  pxUri->ucNoOfUriParam = 0;   
  /* No leading spaces allowed after ; */ 
  do{
    pxUri->ucNoOfUriParam++;
    if(pxUri->ucNoOfUriParam > IFX_SIP_MAX_URI){
      pxSipError->eDecodeErr = IFX_SIP_MAXURI_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Max URI exceeded");
      pxUri->ucNoOfUriParam--;
      return IFX_SIP_FAILURE;
    }
    cRet = IFX_SIP_strtok(pcTempStart,pcEndIndex,&pcCurrPos,"=;");
    switch(cRet){
      case '=':
        for(i = 0; i < IFX_SIP_URI; i++){
          if(strncmp(pcTempStart,
                     vtblszUriParams[i],
                     IFX_SIP_MAX(strlen(vtblszUriParams[i]),
                                  (uint32) (pcCurrPos - pcTempStart))) ==
             0){
            break;
          }
        }
        if(i == IFX_SIP_URI){
          pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
                                      eUriParamType = IFX_SIP_OTHER_PARAM;
          if(((pcCurrPos - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
             ((pcCurrPos - pcTempStart) <= 0)){
            pxSipError->eDecodeErr = IFX_SIP_OTHERPARM_EXCEEDED;
            strcpy(pxSipError->szErrorDesc,
                   "URI other parameter exceeded the limit");
            return IFX_SIP_FAILURE;
          }
          strncpy(pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
          uxUriParamType.szOtherParam,pcTempStart,(pcCurrPos - pcTempStart));
          pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].uxUriParamType.
          szOtherParam[(pcCurrPos - pcTempStart)] = '\0';
          if(IFX_SIP_ValidateParamChar(pxUri->axUriParam[pxUri->
          ucNoOfUriParam - 1].uxUriParamType.szOtherParam) == IFX_SIP_FAILURE){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_PARAMCHAR;
            strcpy(pxSipError->szErrorDesc,"Invalid Param Char");
            return IFX_SIP_FAILURE;
          }
        }
        pcTempStart = pcCurrPos + 1;/* As it is pointing to = */
        pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
        if(pcCurrPos == NULL){
          flag = 0;
          pcTempEnd = pcEndIndex;
        }
        else{
          pcTempEnd = pcCurrPos;/*pcEndIndex-1;*/
        }
        /* No white spaces allowed after ; */
        switch(i + 1){
          case IFX_SIP_TRANSP_PARAM:
            {
              char8 acTemp[IFX_SIP_MAX_TOKEN];             
              pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
                                  eUriParamType = IFX_SIP_TRANSP_PARAM;
              if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
                 ((pcTempEnd - pcTempStart) <= 0)){
                pxSipError->eDecodeErr = IFX_SIP_OTHERPARM_EXCEEDED;
                strcpy(pxSipError->szErrorDesc,
                       "URI other parameter exceeded the limit");
                return IFX_SIP_FAILURE;
              }
              strncpy(acTemp,pcTempStart,pcTempEnd - pcTempStart);
              acTemp[pcTempEnd - pcTempStart] = '\0';
              if(IFX_SIP_strcasecmp(acTemp,"udp") == 0){
                pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].uxUriParamType
                .xTranspParam.eTransType = IFX_SIP_UDP;
                strcpy(pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
                       uxUriParamType.xTranspParam.szOtherTrans,"UDP");
              }
              else if(IFX_SIP_strcasecmp(acTemp,"tcp") == 0){
                pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].uxUriParamType
                .xTranspParam.eTransType = IFX_SIP_TCP;
                strcpy(pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
                       uxUriParamType.xTranspParam.szOtherTrans,"tcp");
              }
              else if(IFX_SIP_strcasecmp(acTemp,"sctp") == 0){
                pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].uxUriParamType.
                xTranspParam.eTransType = IFX_SIP_SCTP;
                strcpy(pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
                       uxUriParamType.xTranspParam.szOtherTrans,"sctp");
              }
              else if(IFX_SIP_strcasecmp(acTemp,"tls") == 0){
                pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].uxUriParamType
                .xTranspParam.eTransType = IFX_SIP_TLS;
                strcpy(pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
                       uxUriParamType.xTranspParam.szOtherTrans,"tls");
 
              }
              else{
                     pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
                     uxUriParamType.xTranspParam.eTransType = IFX_SIP_OTHER;
                     strcpy(pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
              uxUriParamType.xTranspParam.szOtherTrans,acTemp);
                     /* Validating the Token */
                if(IFX_SIP_ValidateToken(pxUri->axUriParam[pxUri->
              ucNoOfUriParam - 1].uxUriParamType.xTranspParam.
              szOtherTrans) == IFX_SIP_FAILURE){
                  pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
                  strcpy(pxSipError->szErrorDesc,
                         "Invalid Token other Transport");
                  return IFX_SIP_FAILURE;
                }
              }
            }
            break;

          case IFX_SIP_USER_PARAM:
            {
              char8 acTemp[IFX_SIP_MAX_TOKEN];
              pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
                                    eUriParamType = IFX_SIP_USER_PARAM;
              if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
                 ((pcTempEnd - pcTempStart) <= 0)){
                pxSipError->eDecodeErr = IFX_SIP_OTHERPARM_EXCEEDED;
                strcpy(pxSipError->szErrorDesc,
                       "URI other parameter exceeded the limit");
                return IFX_SIP_FAILURE;
              }
              strncpy(acTemp,pcTempStart,(pcTempEnd - pcTempStart));
              acTemp[(pcTempEnd - pcTempStart)] = '\0';
              if(IFX_SIP_strcasecmp(acTemp,"phone") == 0){
                uchar8 aucUserName[IFX_SIP_MAX_TOKEN];
                strcpy(aucUserName,pxSipUri->xUserInfo.                                               uxUserType.szUser);   
                pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
                uxUriParamType.xUserParam.eUserParamType = IFX_SIP_PHONE;
                /* The contents of User are assumed to be Tel Sub*/ 
                pxSipUri->xUserInfo.eUserType = IFX_SIP_TEL_SUB;
                if(IFX_SIP_DecTelSubscriber(pxSipUri->xUserInfo.
                   uxUserType.szUser,&pxSipUri->xUserInfo.uxUserType.xTelSub,
                   pxSipError) == IFX_SIP_FAILURE){
                  /*return IFX_SIP_FAILURE;*/
                  /*In case of failure keep the same */
                  strcpy(pxSipUri->xUserInfo.uxUserType.szUser,aucUserName);          
                  pxSipUri->xUserInfo.eUserType = IFX_SIP_USER;
                }
              }
              else if(IFX_SIP_strcasecmp(acTemp,"ip") == 0){
                pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
                uxUriParamType.xUserParam.eUserParamType = IFX_SIP_IP;
                strcpy(pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
                uxUriParamType.xUserParam.szOtherUser,"ip");
              }
              else{
                pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
                 uxUriParamType.xUserParam.eUserParamType = IFX_SIP_OTHER_USER;
                strcpy(pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
              uxUriParamType.xUserParam.szOtherUser,acTemp);
                /* Validating the Token */
                if(IFX_SIP_ValidateToken(pxUri->axUriParam[pxUri->
              ucNoOfUriParam - 1].uxUriParamType.xUserParam.
              szOtherUser) == IFX_SIP_FAILURE){
                  pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
                  strcpy(pxSipError->szErrorDesc,"Invalid Token Other User");
                  return IFX_SIP_FAILURE;
                }
              }
            }
            break;
          case IFX_SIP_METHOD_PARAM:
            pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
                                         eUriParamType = IFX_SIP_METHOD_PARAM;
            if(IFX_SIP_DecodeMethod(pcTempStart,pcTempEnd,
               &pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].uxUriParamType.
               xMethodParam,pxSipError) == IFX_SIP_FAILURE){
              return IFX_SIP_FAILURE;
            }
            break;
          case IFX_SIP_TTL_PARAM:
            pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
                                            eUriParamType = IFX_SIP_TTL_PARAM;
            for(i = 0; (pcTempStart + i) <= pcTempEnd; i++){
              if(*(pcTempStart + i) == ' ' || *(pcTempStart + i) == '\t'){
                break;
              }
            }
            if((i > 3) || (i <= 0)){
              pxSipError->eDecodeErr = IFX_SIP_TTLPARM_EXCEEDED;
              strcpy(pxSipError->szErrorDesc,
                     "TTL parameter exceeded the limit");
              return IFX_SIP_FAILURE;
            }
            strncpy(acTemp,pcTempStart,i);
            acTemp[i] = '\0';
            pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].uxUriParamType.
            iTtlParam = atoi(acTemp);
            /*if(pxUri->axUriParam[pxUri->ucNoOfUriParam-1].uxUriParamType.
                iTtlParam>255){
                pxSipError->eDecodeErr = IFX_SIP_TTLPARM_EXCEEDED;
                strcpy(pxSipError->szErrorDesc,
                  "Invalid TTL parameter in uri params");
                return IFX_SIP_FAILURE;
              }*/
            break;
          case IFX_SIP_MADDR_PARAM:
            pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
                                      eUriParamType = IFX_SIP_MADDR_PARAM;
            if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
               ((pcTempEnd - pcTempStart) <= 0)){
              pxSipError->eDecodeErr = IFX_SIP_HOSTNAME_EXCEEDED;
              strcpy(pxSipError->szErrorDesc,"Host name exceeded the limit");
              return IFX_SIP_FAILURE;
            }
            strncpy(pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
          uxUriParamType.xMaddrParam.szHostInfo,
                    pcTempStart,
                    (pcTempEnd - pcTempStart));

            pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].uxUriParamType.
            xMaddrParam.szHostInfo[(pcTempEnd - pcTempStart)] = '\0';

            pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].uxUriParamType.
            xMaddrParam.eHostType = IFX_SIP_IdentifyType(pxUri->
               axUriParam[pxUri->ucNoOfUriParam - 1].uxUriParamType.
               xMaddrParam.szHostInfo);

            if(pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].uxUriParamType.
               xMaddrParam.eHostType == IFX_SIP_HOSTINVALID){
              pxSipError->eDecodeErr = IFX_SIP_INVALID_HOSTINFO;
              strcpy(pxSipError->szErrorDesc,"Invalid Host Info");
              return IFX_SIP_FAILURE;
            }
            break;
           #ifdef RFC_3486
           case IFX_SIP_COMP_PARAM:
           {           
             pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
                                      eUriParamType = IFX_SIP_COMP_PARAM;

            if( ( (pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
                ( (pcTempEnd - pcTempStart) <= 0) )
             {
              pxSipError->eDecodeErr = IFX_SIP_HOSTNAME_EXCEEDED;
              strcpy(pxSipError->szErrorDesc,"Compression Parameter exceeded the limit");
              return IFX_SIP_FAILURE;
             }
            strncpy(pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
            uxUriParamType.szCompressionParam,
                    pcTempStart,
                    (pcTempEnd - pcTempStart));

            pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].uxUriParamType.
            szCompressionParam[(pcTempEnd - pcTempStart)]= '\0';
            
           }
           break;
           #endif /*RFC_3486*/
          default:
            {
              char8 acTemp[IFX_SIP_MAX_TOKEN];
              strcat(pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
                    uxUriParamType.szOtherParam,"=");
              if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
                 ((pcTempEnd - pcTempStart) <= 0)){
                pxSipError->eDecodeErr = IFX_SIP_OTHERPARM_EXCEEDED;
                strcpy(pxSipError->szErrorDesc,
                       "Other param exceeded the limit");
                pxUri->ucNoOfUriParam--;
                return IFX_SIP_FAILURE;
              }
              strncat(pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
            uxUriParamType.szOtherParam,pcTempStart,(pcTempEnd - pcTempStart));
              strncpy(acTemp,pcTempStart,(pcTempEnd - pcTempStart));
              acTemp[(pcTempEnd - pcTempStart)] = '\0';
              if(IFX_SIP_ValidateParamChar(acTemp) == IFX_SIP_FAILURE){
                pxSipError->eDecodeErr = IFX_SIP_INVALID_PARAMCHAR;
                strcpy(pxSipError->szErrorDesc,"Invalid Param Char");
                return IFX_SIP_FAILURE;
              }
            }
            break;
        }
        if(flag != 0){
          pcTempStart = pcCurrPos + 1;
        }
        break;
      case ';':
      case IFX_SIP_TOKEN_NOTFOUND:
        if(cRet == IFX_SIP_TOKEN_NOTFOUND){
          pcCurrPos = pcEndIndex;
        }
        if(strncmp(pcTempStart,"lr",strlen("lr")) == 0){
          pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
                                    eUriParamType = IFX_SIP_LR_PARAM;
        }
        else{
          /* other parameter with pname only*/
          pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].eUriParamType = 
                                                    IFX_SIP_OTHER_PARAM;
          if(((pcCurrPos - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
             ((pcCurrPos - pcTempStart) <= 0)){
            pxSipError->eDecodeErr = IFX_SIP_OTHERPARM_EXCEEDED;
            strcpy(pxSipError->szErrorDesc,
                   "Other param below/beyond the limit");
            return IFX_SIP_FAILURE;
          }
          strncpy(pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].
          uxUriParamType.szOtherParam,pcTempStart,(pcCurrPos - pcTempStart));
          pxUri->axUriParam[pxUri->ucNoOfUriParam - 1].uxUriParamType.
          szOtherParam[(pcCurrPos - pcTempStart)] = '\0';
          if(IFX_SIP_ValidateParamChar(pxUri->axUriParam[pxUri->
          ucNoOfUriParam - 1].uxUriParamType.szOtherParam) == IFX_SIP_FAILURE){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_PARAMCHAR;
            strcpy(pxSipError->szErrorDesc,"Invalid Param Char");
            return IFX_SIP_FAILURE;
          }
        }
        if(cRet == IFX_SIP_TOKEN_NOTFOUND){
          flag = 0;
        }
        else{
          pcTempStart = pcCurrPos + 1;
        }
    }
  }
  while(flag);
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeSipUri
*  Description  :  Decodes the SIP URI
*  Input Values :  Start and End indices to SIP URI
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeSipUri(IN  char8* pcStartIndex,
                      IN  char8* pcEndIndex,
                      OUT x_IFX_SIP_SipUri* pxSipUri,
                      OUT x_IFX_SIP_Error* pxSipError)
{
  char* pcTempStart, * pcTempEnd, * pcCurrPos, * pcTemp;
  char cRet;
  /* copy pcStartIndex and pcEndIndex into temporary pointers */
  pcTempStart = pcStartIndex;
  pcTempEnd = pcEndIndex;
  pcCurrPos = pcTempStart;
  cRet = IFX_SIP_strtok(pcTempStart,pcTempEnd,&pcCurrPos,":@");
  switch(cRet){
    case ':':
      /* Either port or password are present in the URI */
      pcTemp = pcTempStart;
      pcTempStart = pcCurrPos;
      cRet = IFX_SIP_strtok(pcTempStart,pcTempEnd,&pcCurrPos,"@;?");
      if(cRet == '@'){
        /* Presence of Password */
        /* Copy the User */
        pxSipUri->xUserInfo.eUserType = IFX_SIP_USER;
        if(((pcTempStart - pcTemp) >= IFX_SIP_MAX_USER_INFO) ||
           ((pcTempStart - pcTemp) <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_USERINFO_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"User Info exceeded the limit");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxSipUri->xUserInfo.uxUserType.szUser,
                pcTemp,
                (pcTempStart - pcTemp));
        pxSipUri->xUserInfo.uxUserType.szUser[(pcTempStart - pcTemp)] = '\0';
        /* Copying the password */
        if(((pcTempStart - pcTemp) >= IFX_SIP_MAX_USER_INFO) ||
           ((pcTempStart - pcTemp) <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_USERINFO_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"User Info exceeded the limit");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxSipUri->xUserInfo.szPasswd,
                pcTempStart + 1,
                (pcCurrPos - (pcTempStart + 1)));
        pxSipUri->xUserInfo.szPasswd[(pcCurrPos - (pcTempStart + 1))] = '\0';
        /* TBF: Validate Password */
        if(IFX_SIP_ValidatePassword(pxSipUri->xUserInfo.szPasswd) ==
           IFX_SIP_FAILURE){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_PASSWD;
          strcpy(pxSipError->szErrorDesc,"Invalid Password");
          return IFX_SIP_FAILURE;
        }
        pcCurrPos++;/* As it is pointing to @ */
        pcTempStart = pcCurrPos;
        /* Copying the Host and port information */ 
        cRet = IFX_SIP_strtok(pcTempStart,pcTempEnd,&pcCurrPos,";?");
        if(cRet == '?'){
          if(IFX_SIP_DecodeHostPort(pcTempStart,pcCurrPos,&pxSipUri->
          xHostPort,pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
          pcTempStart = pcCurrPos + 1;
          if(IFX_SIP_DecodeHeaders(pcTempStart,pcTempEnd,&pxSipUri->
          xHeaders,pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
        }
        else if(cRet == ';'){
          if(IFX_SIP_DecodeHostPort(pcTempStart,pcCurrPos,&pxSipUri->
          xHostPort,pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
          pcTempStart = pcCurrPos + 1;
          pcCurrPos = IFX_SIP_strchr(pcTempStart,pcTempEnd,'?');
          if(pcCurrPos == NULL){
            /* only some URI parameters are present */
            if(IFX_SIP_DecodeURIParams(pcTempStart,
                                        pcTempEnd,
                                        pxSipUri,
                                        pxSipError) == IFX_SIP_FAILURE){
              return IFX_SIP_FAILURE;
            }
          }
          else{
            /* Both URI and Header parameters present */
            if(IFX_SIP_DecodeURIParams(pcTempStart,
                                        pcCurrPos,
                                        pxSipUri,
                                        pxSipError) == IFX_SIP_FAILURE){
              return IFX_SIP_FAILURE;
            }
            if(IFX_SIP_DecodeHeaders((pcCurrPos + 1),pcTempEnd,&pxSipUri
            ->xHeaders,pxSipError) == IFX_SIP_FAILURE){
              return IFX_SIP_FAILURE;
            }
          }
        }
        else if(cRet == IFX_SIP_TOKEN_NOTFOUND){
          /* Only host port info present */
          if(IFX_SIP_DecodeHostPort(pcTempStart,pcTempEnd,&pxSipUri->
          xHostPort,pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
        }
      }
      else if(cRet == '?'){
        /* Presence of port,No URI parameters present, Headers are present */
        IFX_SIP_DecodeHostPort(pcTemp,
                                pcCurrPos,
                                &pxSipUri->xHostPort,
                                pxSipError);
        pcTempStart = pcCurrPos + 1; /* As it is pointing to ? */
        /* call decoder of headers */
        if(IFX_SIP_DecodeHeaders(pcTempStart,pcTempEnd,&pxSipUri->
        xHeaders,pxSipError) == IFX_SIP_FAILURE){
          return IFX_SIP_FAILURE;
        }
      }
      else if(cRet == ';'){
        /* Presence of port, URI parameters present */
        IFX_SIP_DecodeHostPort(pcTemp,
                                pcCurrPos,
                                &pxSipUri->xHostPort,
                                pxSipError);
        pcTempStart = pcCurrPos + 1; /* As it is pointing to ; */
        /* Check for the presence of ? */
        pcCurrPos = IFX_SIP_strchr(pcTempStart,pcTempEnd,'?');
        if(pcCurrPos == NULL){
          /* only some URI parameters are present */
          if(IFX_SIP_DecodeURIParams(pcTempStart,
                                      pcTempEnd,
                                      pxSipUri,
                                      pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
        }
        else{
          /* Both URI and Header parameters present */
          if(IFX_SIP_DecodeURIParams(pcTempStart,
                                      pcCurrPos,
                                      pxSipUri,
                                      pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
          if(IFX_SIP_DecodeHeaders((pcCurrPos + 1),pcTempEnd,&pxSipUri->
          xHeaders,pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
        }
      }
      else{
        char8 acPort[10];
        /* Presence of port along with host info */
        if(((pcTempStart - pcTemp) >= IFX_SIP_MAX_TOKEN) ||
           ((pcTempStart - pcTemp) <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_HOSTNAME_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Host info exceeded the limit");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxSipUri->xHostPort.xHost.szHostInfo,
                pcTemp,
                (pcTempStart - pcTemp)); 
        pxSipUri->xHostPort.xHost.szHostInfo[(pcTempStart - pcTemp)] = '\0';
        /* Validation of Host Info */
        pxSipUri->xHostPort.xHost.eHostType = IFX_SIP_IdentifyType(
                  pxSipUri->xHostPort.xHost.szHostInfo);
        if(pxSipUri->xHostPort.xHost.eHostType == IFX_SIP_HOSTINVALID){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_HOSTINFO;
          strcpy(pxSipError->szErrorDesc,"Invalid Host Info");
          return IFX_SIP_FAILURE;
        }
        pcTempStart++; /* As it is pointing to : */
        if(((pcTempEnd - pcTempStart) > 10 /*max is int 32*/) ||
           ((pcTempEnd - pcTempStart) <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_HOSTPORT_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Host port exceeded the num digits");
          return IFX_SIP_FAILURE;
        }
        strncpy(acPort,pcTempStart,(pcTempEnd - pcTempStart)); 
        acPort[(pcTempEnd - pcTempStart)] = '\0';
        pxSipUri->xHostPort.uiPort = atoi(acPort);
      }   
      break;
    case '@':
      pxSipUri->xUserInfo.eUserType = IFX_SIP_USER;
      /* presence of user part*/
      if((pcCurrPos - pcTempStart) >= IFX_SIP_MAX_USER_INFO){
        pxSipError->eDecodeErr = IFX_SIP_USERINFO_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"User Info exceeded the limit");
        return IFX_SIP_FAILURE;
      }
      else if((pcCurrPos - pcTempStart) == 0){
        pxSipError->eDecodeErr = IFX_SIP_USERINFO_ABSENT;
        strcpy(pxSipError->szErrorDesc,"User Info Absent");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxSipUri->xUserInfo.uxUserType.szUser,
              pcTempStart,
              (pcCurrPos - pcTempStart));
      pxSipUri->xUserInfo.uxUserType.szUser[(pcCurrPos - pcTempStart)] = '\0';
      pcCurrPos++;/* As it is pointing to @ */
      pcTempStart = pcCurrPos;
      cRet = IFX_SIP_strtok(pcTempStart,pcTempEnd,&pcCurrPos,";?");
      if(cRet == '?'){
        if(IFX_SIP_DecodeHostPort(pcTempStart,
                                   pcCurrPos,
                                   &pxSipUri->xHostPort,
                                   pxSipError) == IFX_SIP_FAILURE){
          return IFX_SIP_FAILURE;
        }
        pcTempStart = pcCurrPos + 1;
        if(IFX_SIP_DecodeHeaders(pcTempStart,
                                  pcTempEnd,
                                  &pxSipUri->xHeaders,
                                  pxSipError) == IFX_SIP_FAILURE){
          return IFX_SIP_FAILURE;
        }
      }
      else if(cRet == ';'){
        if(IFX_SIP_DecodeHostPort(pcTempStart,
                                   pcCurrPos,
                                   &pxSipUri->xHostPort,
                                   pxSipError) == IFX_SIP_FAILURE){
          return IFX_SIP_FAILURE;
        }
        pcTempStart = pcCurrPos + 1;
        pcCurrPos = IFX_SIP_strchr(pcTempStart,pcTempEnd,'?');
        if(pcCurrPos == NULL){
          /* only some URI parameters are present */
          if(IFX_SIP_DecodeURIParams(pcTempStart,
                                      pcTempEnd,
                                      pxSipUri,
                                      pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
        }
        else{
          /* Both URI and Header parameters present */
          if(IFX_SIP_DecodeURIParams(pcTempStart,
                                      pcCurrPos,
                                      pxSipUri,
                                      pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
          if(IFX_SIP_DecodeHeaders((pcCurrPos + 1),
                                    pcTempEnd,
                                    &pxSipUri->xHeaders,
                                    pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
        }
      }
      else if(cRet == IFX_SIP_TOKEN_NOTFOUND){
        /* Only host port info present */
        if(IFX_SIP_DecodeHostPort(pcTempStart,
                                   pcTempEnd,
                                   &pxSipUri->xHostPort,
                                   pxSipError) == IFX_SIP_FAILURE){
          return IFX_SIP_FAILURE;
        }
      }
      break;
    case IFX_SIP_TOKEN_NOTFOUND:
      /* No user part and only the host part is present */
      /* Uri Params and Headers could be present */
      pxSipUri->xHostPort.uiPort = 0;
      cRet = IFX_SIP_strtok(pcTempStart,pcTempEnd,&pcCurrPos,";?");
      if(cRet == '?'){
        if(((pcCurrPos - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
           ((pcCurrPos - pcTempStart) <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_HOSTNAME_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Host Name exceeded the limit");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxSipUri->xHostPort.xHost.szHostInfo,
                pcTempStart,
                (pcCurrPos - pcTempStart));
        pxSipUri->xHostPort.xHost.szHostInfo[(pcCurrPos - pcTempStart)] = '\0';
        /* Validate Host Info */
        pxSipUri->xHostPort.xHost.eHostType = IFX_SIP_IdentifyType(pxSipUri->
                                                xHostPort.xHost.szHostInfo);      
        if(pxSipUri->xHostPort.xHost.eHostType == IFX_SIP_HOSTINVALID){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_HOSTINFO;
          strcpy(pxSipError->szErrorDesc,"Invalid Host Info");
          return IFX_SIP_FAILURE;
        }

        pcTempStart = pcCurrPos + 1;
        if(IFX_SIP_DecodeHeaders(pcTempStart,
                                  pcTempEnd,
                                  &pxSipUri->xHeaders,
                                  pxSipError) == IFX_SIP_FAILURE){
          strcpy(pxSipError->szErrorDesc,"Decode headers failed");
          return IFX_SIP_FAILURE;
        }
      }
      else if(cRet == ';'){
        if(((pcCurrPos - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
           ((pcCurrPos - pcTempStart) <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_HOSTNAME_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Host Name exceeded the limit");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxSipUri->xHostPort.xHost.szHostInfo,
                pcTempStart,
                (pcCurrPos - pcTempStart));
        pxSipUri->xHostPort.xHost.szHostInfo[(pcCurrPos - pcTempStart)] = '\0';
        /* Validate Host Info */
        pxSipUri->xHostPort.xHost.eHostType = IFX_SIP_IdentifyType(pxSipUri->
                                              xHostPort.xHost.szHostInfo);      
        if(pxSipUri->xHostPort.xHost.eHostType == IFX_SIP_HOSTINVALID){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_HOSTINFO;
          strcpy(pxSipError->szErrorDesc,"Invalid Host Info");
          return IFX_SIP_FAILURE;
        }

        pcTempStart = pcCurrPos + 1;
        pcCurrPos = IFX_SIP_strchr(pcTempStart,pcTempEnd,'?');
        if(pcCurrPos == NULL){
          /* only some URI parameters are present */
          if(IFX_SIP_DecodeURIParams(pcTempStart,
                                      pcTempEnd,
                                      pxSipUri,
                                      pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
        }
        else{
          /* Both URI and Header parameters present */
          if(IFX_SIP_DecodeURIParams(pcTempStart,
                                      pcCurrPos,
                                      pxSipUri,
                                      pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
          if(IFX_SIP_DecodeHeaders((pcCurrPos + 1),
                                    pcTempEnd,
                                    &pxSipUri->xHeaders,
                                    pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
        }
      }
      else if(cRet == IFX_SIP_TOKEN_NOTFOUND){
        if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
           ((pcTempEnd - pcTempStart) <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_HOSTNAME_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Host Name exceeded the limit");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxSipUri->xHostPort.xHost.szHostInfo,
                pcTempStart,
                (pcTempEnd - pcTempStart));
        pxSipUri->xHostPort.xHost.szHostInfo[(pcTempEnd - pcTempStart)] = '\0';
        /* Validate Host Info */
        pxSipUri->xHostPort.xHost.eHostType = IFX_SIP_IdentifyType(
                                   pxSipUri->xHostPort.xHost.szHostInfo);      
        if(pxSipUri->xHostPort.xHost.eHostType == IFX_SIP_HOSTINVALID){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_HOSTINFO;
          strcpy(pxSipError->szErrorDesc,"Invalid Host Info");
          return IFX_SIP_FAILURE;
        }
      }
      break;
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeParams
*  Description  :  Decodes the From parameters
*  Input Values :  Start and End indices of To parameters
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/

e_IFX_SIP_Return
IFX_SIP_DecodeParams(IN  char8* pcStartIndex,
                      IN  char8* pcEndIndex,
                      OUT x_IFX_SIP_FromParam* pxFrom,
                      OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcCurrPos, * pcTempEnd;

  pcTempStart = pcStartIndex;

  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'=');
  if(pcCurrPos != NULL){
    pcTempEnd = pcCurrPos;

    /* Remove any Trailing Spaces */
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd < pcTempStart){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid message format");
        return IFX_SIP_FAILURE;
      }
    }

    if(strncmp(pcTempStart,"tag",IFX_SIP_MAX((uint32)(pcTempEnd - pcTempStart)
            ,strlen("tag"))) == 0){
      pxFrom->eParamType = IFX_SIP_TAG_PARAM;
      pcTempStart = pcCurrPos + 1;/* As it points to = */

      /* Remove any leading spaces after  = */
      while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
        pcTempStart++;
        if(pcTempStart > pcEndIndex){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
          strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
          return IFX_SIP_FAILURE;
        }
      }

      if(((pcEndIndex - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
         ((pcEndIndex - pcTempStart) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_TAGPARM_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Tag Param token exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxFrom->uxParamType.szTagParam,
              pcTempStart,
              (pcEndIndex - pcTempStart));
      pxFrom->uxParamType.szTagParam[(pcEndIndex - pcTempStart)] = '\0';
      /* Validate Tag Param */
      if(IFX_SIP_ValidateToken(pxFrom->uxParamType.szTagParam) ==
         IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_TAGPARAM;
        strcpy(pxSipError->szErrorDesc,"Invalid Tag Param");
        return IFX_SIP_FAILURE;
      }
    }
    else{
      pxFrom->eParamType = IFX_SIP_GENERIC_PARAM_F;
      if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
         ((pcTempEnd - pcTempStart) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Gen Param token exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxFrom->uxParamType.xGenericParam.szToken,
              pcTempStart,
              (pcTempEnd - pcTempStart));
      pxFrom->uxParamType.xGenericParam.
                        szToken[(pcTempEnd - pcTempStart)] = '\0';

      /* Validate Generic Param Token */
      if(IFX_SIP_ValidateToken(pxFrom->uxParamType.xGenericParam.
        szToken) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
        strcpy(pxSipError->szErrorDesc,"Invalid Generic Param");
        return IFX_SIP_FAILURE;
      }
      pcTempStart = pcCurrPos + 1;

      /* Remove any spaces after = */
      while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
        pcTempStart++;
        if(pcTempStart > pcEndIndex){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
          strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
          return IFX_SIP_FAILURE;
        }
      }

      if(((pcEndIndex - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
         ((pcEndIndex - pcTempStart) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Gen value in genparam exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxFrom->uxParamType.xGenericParam.szGenValue,
              pcTempStart,
              (pcEndIndex - pcTempStart));
      pxFrom->uxParamType.xGenericParam.
                           szGenValue[(pcEndIndex - pcTempStart)] = '\0';

      /* Validate Gen Param genvalue */
      if(IFX_SIP_ValidateGenValue(pxFrom->uxParamType.xGenericParam.
        szGenValue) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_GENVALUE;
        strcpy(pxSipError->szErrorDesc,"Invalid Gen Value in GenParam");
        return IFX_SIP_FAILURE;
      }
    }
  }
  else{
    pxFrom->eParamType = IFX_SIP_GENERIC_PARAM_F;

    if(((pcEndIndex - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
       ((pcEndIndex - pcTempStart) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Gen Param token exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxFrom->uxParamType.xGenericParam.szToken,
            pcTempStart,
            (pcEndIndex - pcTempStart));
    pxFrom->uxParamType.xGenericParam.
                              szToken[(pcEndIndex - pcTempStart)] = '\0';
    /* Validate Gen Param Token */
    if(IFX_SIP_ValidateToken(pxFrom->uxParamType.xGenericParam.szToken) ==
       IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
      strcpy(pxSipError->szErrorDesc,"Invalid Generic Param");
      return IFX_SIP_FAILURE;
    }
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeViaParams
*  Description  :  Decodes the Via parameters
*  Input Values :  Start and End indices of Via parameters
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeViaParams(IN  char8* pcStartIndex,
                         IN  char8* pcEndIndex,
                         OUT x_IFX_SIP_ViaParm* pxvia,
                         OUT x_IFX_SIP_Error* pxSipError)
{
  uint32 i=0, bFlag = 1;
  char8 cRet, * pcCurrPos, * pcTempStart, * pcTempEnd;

  pcTempStart = pcCurrPos = pcStartIndex;

  do{
    while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
      pcTempStart++;
      if(pcTempStart > pcEndIndex){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
        strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
        return IFX_SIP_FAILURE;
      }
    }

    if(pxvia->ucNoOfViaParams >= IFX_SIP_MAX_VIA_PARAMS){
      pxSipError->eDecodeErr = IFX_SIP_MAXVIAPARAM_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Max Via params exceeded");
      return IFX_SIP_FAILURE;
    }

    cRet = IFX_SIP_strtok(pcTempStart,pcEndIndex,&pcCurrPos,";=");
    if(cRet == ';'){
      /* only token in generic param is present */
      pcTempEnd = pcCurrPos;

      /* Remove any Trailing Spaces */
      while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
        pcTempEnd--;
        if(pcTempEnd < pcTempStart){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid message format");
          return IFX_SIP_FAILURE;
        }
      }
      
      if(strncmp(pcTempStart,"rport",IFX_SIP_MAX(i,strlen("rport"))) == 0){
        pxvia->axViaParams[pxvia->ucNoOfViaParams].eViaType = 
                                                IFX_SIP_VIA_RESPPORT;
        pxvia->axViaParams[pxvia->ucNoOfViaParams].uxViaType.unRespPort = 0;        
      }
      else{
        pxvia->axViaParams[pxvia->ucNoOfViaParams].eViaType = 
                                                IFX_SIP_VIA_EXTENSION;
        if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
           ((pcTempEnd - pcTempStart) <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_OTHERPARM_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,
               "Extension exceeds the max limit(in via)");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxvia->axViaParams[pxvia->ucNoOfViaParams].uxViaType.
          xViaExt.szToken,pcTempStart,(pcTempEnd - pcTempStart));
        pxvia->axViaParams[pxvia->ucNoOfViaParams].uxViaType.xViaExt.
          szToken[(pcTempEnd - pcTempStart)] = '\0';

        /* Validate Via Ext Token */
        if(IFX_SIP_ValidateToken(pxvia->axViaParams[pxvia->ucNoOfViaParams]
          .uxViaType.xViaExt.szToken) == IFX_SIP_FAILURE){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
          strcpy(pxSipError->szErrorDesc,"Invalid Token");
          return IFX_SIP_FAILURE;
        }
      }
      pcTempStart = pcCurrPos + 1; /* As it is pointing to ; */
    }
    else if(cRet == '='){
      /*Any of the via params is present */
      pcTempEnd = pcCurrPos;

      /* Remove any Trailing Spaces */
      while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
        pcTempEnd--;
        if(pcTempEnd < pcTempStart){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid message format");
          return IFX_SIP_FAILURE;
        }
      }

      i = pcTempEnd - pcTempStart;

      if(strncmp(pcTempStart,"ttl",IFX_SIP_MAX(i,strlen("ttl"))) == 0){
        char8 acTemp[10];
        pxvia->axViaParams[pxvia->ucNoOfViaParams].eViaType = IFX_SIP_VIA_TTL;

        /* Removing leading spaces */
        pcCurrPos++; /* As it is pointing to = */
        while((*pcCurrPos == ' ') || (*pcCurrPos == '\t')){
          pcCurrPos++;
          if(pcCurrPos > pcEndIndex){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
            strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
            return IFX_SIP_FAILURE;
          }
        }

        pcTempStart = pcCurrPos;
        pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');

        if(pcCurrPos == NULL){
          pcTempEnd = pcEndIndex;
        }
        else{
          pcTempEnd = pcCurrPos;
          /* Remove any Trailing Spaces */
          while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
            pcTempEnd--;
            if(pcTempEnd < pcTempStart){
              pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
              strcpy(pxSipError->szErrorDesc,"Invalid message format");
              return IFX_SIP_FAILURE;
            }
          }
        }

        i = pcTempEnd - pcTempStart;

        if((i > 3) || (i <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_TTLPARM_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"TTL exceeds the max limit(in via)");
          return IFX_SIP_FAILURE;
        }
        strncpy(acTemp,pcTempStart,i);
        acTemp[i] = '\0';

        pxvia->axViaParams[pxvia->ucNoOfViaParams].uxViaType.iTtl = 
                                                           atoi(acTemp);

        /* Validate the TTL */
        if((atoi(acTemp) < 0) || (atoi(acTemp) > 255)){
          pxSipError->eDecodeErr = IFX_SIP_TTLPARM_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Invalid TTL param");
          return IFX_SIP_FAILURE;
        }

        if(pcCurrPos == NULL){
          bFlag = 0;
        }
        else{
          pcTempStart = pcCurrPos + 1;/* As it is pointing to ; */
        }
      }
      else if(strncmp(pcTempStart,"maddr",IFX_SIP_MAX(i,strlen("maddr"))) ==
              0){
        pxvia->axViaParams[pxvia->ucNoOfViaParams].eViaType = 
                                                         IFX_SIP_VIA_MADDR;
        /* Removing leading spaces */
        pcCurrPos++; /* As it is pointing to = */
        while((*pcCurrPos == ' ') || (*pcCurrPos == '\t')){
          pcCurrPos++;
          if(pcCurrPos > pcEndIndex){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
            strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
            return IFX_SIP_FAILURE;
          }
        }
        pcTempStart = pcCurrPos;
        pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');

        if(pcCurrPos == NULL){
          pcTempEnd = pcEndIndex;
        }
        else{
          pcTempEnd = pcCurrPos;
          /* Remove any Trailing Spaces */
          while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
            pcTempEnd--;
            if(pcTempEnd < pcTempStart){
              pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
              strcpy(pxSipError->szErrorDesc,"Invalid message format");
              return IFX_SIP_FAILURE;
            }
          }
        }

        i = pcTempEnd - pcTempStart;

        if((i >= IFX_SIP_MAX_TOKEN) || (i <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_MADDRPARM_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,
                 "MADDR below/beyond the limit(in via)");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxvia->axViaParams[pxvia->ucNoOfViaParams].uxViaType.
          szViaMaddr,pcTempStart,i);
        pxvia->axViaParams[pxvia->ucNoOfViaParams].uxViaType.
        szViaMaddr[i] = '\0';

        /* Validate Via Maddr */
        if(IFX_SIP_IdentifyType(pxvia->axViaParams[pxvia->ucNoOfViaParams].
                         uxViaType.szViaMaddr) ==
           IFX_SIP_HOSTINVALID){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MADDR;
          strcpy(pxSipError->szErrorDesc,"Invalid maddr");
          return IFX_SIP_FAILURE;
        }

        if(pcCurrPos == NULL){
          bFlag = 0;
        }
        else{
          pcTempStart = pcCurrPos + 1;/* As it is pointing to ; */
        }
      }
      #ifdef RFC_3486
      else if(strncmp(pcTempStart,"comp",IFX_SIP_MAX(i,strlen("comp"))) ==
              0){
        pxvia->axViaParams[pxvia->ucNoOfViaParams].eViaType = 
                                                         IFX_SIP_VIA_COMP;
        /* Removing leading spaces */
        pcCurrPos++; /* As it is pointing to = */
        while((*pcCurrPos == ' ') || (*pcCurrPos == '\t')){
          pcCurrPos++;
          if(pcCurrPos > pcEndIndex){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
            strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
            return IFX_SIP_FAILURE;
          }
        }
        pcTempStart = pcCurrPos;
        pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');

        if(pcCurrPos == NULL){
          pcTempEnd = pcEndIndex;
        }
        else{
            pcTempEnd = pcCurrPos;
            /* Remove any Trailing Spaces */
            while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t'))
            {
            pcTempEnd--;
            if(pcTempEnd < pcTempStart){
              pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
              strcpy(pxSipError->szErrorDesc,"Invalid message format");
              return IFX_SIP_FAILURE;
            }
          }
        }

        i = pcTempEnd - pcTempStart;

        if((i >= IFX_SIP_MAX_TOKEN) || (i <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_MADDRPARM_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,
                 "comp is  below/beyond the limit(in via)");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxvia->axViaParams[pxvia->ucNoOfViaParams].uxViaType.
                szCompressionParam, pcTempStart,i);
        pxvia->axViaParams[pxvia->ucNoOfViaParams].uxViaType.
        szCompressionParam[i] = '\0';
        if(pcCurrPos == NULL)
        {
          bFlag = 0;
        }
        else
        {
          pcTempStart = pcCurrPos + 1;/* As it is pointing to ; */
        }
      }
      #endif /*RFC_3486*/
      else if(strncmp(pcTempStart,
                      "received",
                      IFX_SIP_MAX(i,strlen("received"))) == 0){
        pxvia->axViaParams[pxvia->ucNoOfViaParams].eViaType = 
                                               IFX_SIP_VIA_RECEIVED;
        /* Removing leading spaces */
        pcCurrPos++; /* As it is pointing to = */
        while((*pcCurrPos == ' ') || (*pcCurrPos == '\t')){
          pcCurrPos++;
          if(pcCurrPos > pcEndIndex){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
            strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
            return IFX_SIP_FAILURE;
          }
        }
        pcTempStart = pcCurrPos;
        pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');

        if(pcCurrPos == NULL){
          pcTempEnd = pcEndIndex;
        }
        else{
          pcTempEnd = pcCurrPos;
          /* Remove any Trailing Spaces */
          while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
            pcTempEnd--;
            if(pcTempEnd < pcTempStart){
              pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
              strcpy(pxSipError->szErrorDesc,"Invalid message format");
              return IFX_SIP_FAILURE;
            }
          }
        }

        i = pcTempEnd - pcTempStart;

        if((i >= IFX_SIP_MAX_TOKEN) || (i <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_MADDRPARM_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"MADDR exceeds the max limit(in via)");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxvia->axViaParams[pxvia->ucNoOfViaParams].uxViaType.
          xRcvdAddr.szIpAddr,pcTempStart,i);
        pxvia->axViaParams[pxvia->ucNoOfViaParams].uxViaType.xRcvdAddr.
        szIpAddr[i] = '\0';

        if(IFX_SIP_ValidateAndSetRecvAddrType(&pxvia->
           axViaParams[pxvia->ucNoOfViaParams].uxViaType.xRcvdAddr,pxSipError) 
           == IFX_SIP_FAILURE){
          return IFX_SIP_FAILURE;
        }
        if(pcCurrPos == NULL){
          bFlag = 0;
        }
        else{
          pcTempStart = pcCurrPos + 1;/* As it is pointing to ; */
        }
      }
      else if(strncmp(pcTempStart,"branch",IFX_SIP_MAX(i,strlen("branch"))) 
              == 0){
        pxvia->axViaParams[pxvia->ucNoOfViaParams].eViaType = 
                                                         IFX_SIP_VIA_BRANCH;
        /* Removing leading spaces */
        pcCurrPos++; /* As it is pointing to = */
        while((*pcCurrPos == ' ') || (*pcCurrPos == '\t')){
          pcCurrPos++;
          if(pcCurrPos > pcEndIndex){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
            strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
            return IFX_SIP_FAILURE;
          }
        }
        pcTempStart = pcCurrPos;
        pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
        if(pcCurrPos == NULL){
          pcTempEnd = pcEndIndex;
        }
        else{
          pcTempEnd = pcCurrPos;
          /* Remove any Trailing Spaces */
          while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
            pcTempEnd--;
            if(pcTempEnd < pcTempStart){
              pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
              strcpy(pxSipError->szErrorDesc,"Invalid message format");
              return IFX_SIP_FAILURE;
            }
          }
        }

        i = pcTempEnd - pcTempStart;

        if((i > IFX_SIP_MAX_TOKEN) || (i <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_BRANCHPARM_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Branch below/beyond limit(in via)");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxvia->axViaParams[pxvia->ucNoOfViaParams].uxViaType.
          szToken,pcTempStart,i);
        pxvia->axViaParams[pxvia->ucNoOfViaParams].uxViaType.szToken[i] = '\0';

        /* Validate Via Type */
        if(IFX_SIP_ValidateToken(pxvia->axViaParams[pxvia->ucNoOfViaParams]
          .uxViaType.szToken) == IFX_SIP_FAILURE){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
          strcpy(pxSipError->szErrorDesc,"Invalid Branch parameter");
          return IFX_SIP_FAILURE;
        }
        if(pcCurrPos == NULL){
          bFlag = 0;
        }
        else{
          pcTempStart = pcCurrPos + 1;/* As it is pointing to ; */
        }
      }
      else if(strncmp(pcTempStart,"rport",IFX_SIP_MAX(i,strlen("rport")))==0){
        char8 acTemp[10];
        pxvia->axViaParams[pxvia->ucNoOfViaParams].eViaType = 
                                              IFX_SIP_VIA_RESPPORT;

        /* Removing leading spaces */
        pcCurrPos++; /* As it is pointing to = */
        while((*pcCurrPos == ' ') || (*pcCurrPos == '\t')){
          pcCurrPos++;
          if(pcCurrPos > pcEndIndex){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
            strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
            return IFX_SIP_FAILURE;
          }
        }

        pcTempStart = pcCurrPos;
        pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');

        if(pcCurrPos == NULL){
          pcTempEnd = pcEndIndex;
        }
        else{
          pcTempEnd = pcCurrPos;
          /* Remove any Trailing Spaces */
          while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
            pcTempEnd--;
            if(pcTempEnd < pcTempStart){
              pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
              strcpy(pxSipError->szErrorDesc,"Invalid message format");
              return IFX_SIP_FAILURE;
            }
          }
        }

        i = pcTempEnd - pcTempStart;

        if((i > 5) || (i <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_RPORT_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Response port more than exceeded");
          return IFX_SIP_FAILURE;
        }
        strncpy(acTemp,pcTempStart,i);
        acTemp[i] = '\0';

        pxvia->axViaParams[pxvia->ucNoOfViaParams].uxViaType.unRespPort = 
                                                           atoi(acTemp);

        /* Validate the Response port */
        if((atoi(acTemp) < 0) || (atoi(acTemp) > 65536)){
          pxSipError->eDecodeErr = IFX_SIP_RPORT_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Invalid Response port param");
          return IFX_SIP_FAILURE;
        }

        if(pcCurrPos == NULL){
          bFlag = 0;
        }
        else{
          pcTempStart = pcCurrPos + 1;/* As it is pointing to ; */
        }
      }
      else{
        pxvia->axViaParams[pxvia->ucNoOfViaParams].eViaType = 
                                                IFX_SIP_VIA_EXTENSION;
        if(((pcCurrPos - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
           ((pcCurrPos - pcTempStart) <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_OTHERPARM_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,
                 "Extension exceeds the max limit(in via)");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxvia->axViaParams[pxvia->ucNoOfViaParams].uxViaType.
          xViaExt.szToken,pcTempStart,(pcCurrPos - pcTempStart));
        pxvia->axViaParams[pxvia->ucNoOfViaParams].uxViaType.xViaExt.
        szToken[(pcCurrPos - pcTempStart)] = '\0';
        /* TBF: Validate Via Ext */
        if(IFX_SIP_ValidateToken(pxvia->axViaParams[pxvia->ucNoOfViaParams].
           uxViaType.xViaExt.szToken) == IFX_SIP_FAILURE){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
          strcpy(pxSipError->szErrorDesc,"Invalid Ext prarm");
          return IFX_SIP_FAILURE;
        }
        /* Removing leading spaces */
        pcCurrPos++; /* As it is pointing to = */
        while((*pcCurrPos == ' ') || (*pcCurrPos == '\t')){
          pcCurrPos++;
          if(pcCurrPos > pcEndIndex){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
            strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
            return IFX_SIP_FAILURE;
          }
        }
        pcTempStart = pcCurrPos;

        /* Check for the delimiters */
        if(IFX_SIP_FindDelimWhenQuotesRPresent(pcTempStart,
                                                pcEndIndex,
                                                ';',
                                                &pcCurrPos,
                                                &pcTempEnd,
                                                pxSipError) ==
           IFX_SIP_FAILURE){
          return IFX_SIP_FAILURE;
        }

        if(pcCurrPos == NULL){
          pcTempEnd = pcEndIndex;
        }
        else{
          pcTempEnd = pcCurrPos;
        }

        i = pcTempEnd - pcTempStart;

        if((i >= IFX_SIP_MAX_TOKEN) || (i <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_OTHERPARM_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,
                 "Extension exceeds the max limit(in via)");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxvia->axViaParams[pxvia->ucNoOfViaParams].uxViaType.
          xViaExt.szGenValue,pcTempStart,i);
        pxvia->axViaParams[pxvia->ucNoOfViaParams].uxViaType.xViaExt.
        szGenValue[i] = '\0';

        /* Validate Via ext */
        if(IFX_SIP_ValidateGenValue(pxvia->axViaParams[pxvia->
          ucNoOfViaParams].uxViaType.xViaExt.szGenValue) == IFX_SIP_FAILURE){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_GENVALUE;
          strcpy(pxSipError->szErrorDesc,"Invalid Gen Value in GenParam");
          return IFX_SIP_FAILURE;
        }

        if(pcCurrPos == NULL){
          bFlag = 0;
        }
        else{
          pcTempStart = pcCurrPos + 1;/* As it is pointing to ; */
        }
      }
    }
    else{
      /* only 1 param, generic param without gen value present */
      pxvia->axViaParams[pxvia->ucNoOfViaParams].eViaType = 
                                           IFX_SIP_VIA_EXTENSION;
      if(((pcEndIndex - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
         ((pcEndIndex - pcTempStart) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_OTHERPARM_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,
               "Extension exceeds the max limit(in via)");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxvia->axViaParams[pxvia->ucNoOfViaParams].uxViaType.
        xViaExt.szToken,pcTempStart,(pcEndIndex - pcTempStart));
      pxvia->axViaParams[pxvia->ucNoOfViaParams].uxViaType.xViaExt.
      szToken[(pcEndIndex - pcTempStart)] = '\0';
      /* Validate Via Ext */
      if(IFX_SIP_ValidateToken(pxvia->axViaParams[pxvia->
        ucNoOfViaParams].uxViaType.xViaExt.szToken) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
        strcpy(pxSipError->szErrorDesc,"Invalid via Ext");
        return IFX_SIP_FAILURE;
      }
      bFlag = 0;
    }
    pxvia->ucNoOfViaParams++;
  }
  while(bFlag);
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeViaParam
*  Description  :  Decodes the Via param
*  Input Values :  Start and End indices of Via param
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeViaParam(IN  char8* pcStartIndex,
                        IN  char8* pcEndIndex,
                        OUT x_IFX_SIP_ViaParm* pxvia,
                        OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcCurrPos, * pcTempEnd;

  pcTempStart = pcStartIndex;

  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'/');
  if(pcCurrPos == NULL){
    /* Return Error */    
    pxSipError->eDecodeErr = IFX_SIP_VIAPARAM_FORMAT_ERR;
    strcpy(pxSipError->szErrorDesc,"Missing / (in via)");
    return IFX_SIP_FAILURE;
  }
  else{
    /* Copy he protocol name */
    pcTempEnd = pcCurrPos;
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd < pcTempStart){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid Msg format");
        return IFX_SIP_FAILURE;
      }
    }
    if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
       ((pcTempEnd - pcTempStart) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_PROTO_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Protocol Name exceeded in via");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxvia->xSentProto.szprotocol,pcTempStart,(pcTempEnd - pcTempStart));
    pxvia->xSentProto.szprotocol[(pcTempEnd - pcTempStart)] = '\0';
    /* Validate Sent Protocol */
    if(IFX_SIP_ValidateToken(pxvia->xSentProto.szprotocol) ==
       IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
      strcpy(pxSipError->szErrorDesc,"Invalid Protocol");
      return IFX_SIP_FAILURE;
    }
  } 
  pcTempStart = pcCurrPos + 1;/* As it is pointing to / */
  /* Remove any Leading White spaces */
  while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
    pcTempStart++;
    if(pcTempStart > pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
      return IFX_SIP_FAILURE;
    }
  }
  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'/');
  if(pcCurrPos == NULL){
    /* Return Error */    
    pxSipError->eDecodeErr = IFX_SIP_VIAPARAM_FORMAT_ERR;
    strcpy(pxSipError->szErrorDesc,"Missing / (in via)");
    return IFX_SIP_FAILURE;
  }
  else{
    /* Copy the protocol Version */
    int32 iLen;
    pcTempEnd = pcCurrPos;
    /* Remove any Trailing Spaces */
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd < pcTempStart){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
        strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
        return IFX_SIP_FAILURE;
      }
    }
    iLen = strlen(pxvia->xSentProto.szprotocol);
    if((((pcTempEnd - pcTempStart) + iLen) >= IFX_SIP_MAX_TOKEN) ||
       ((pcTempEnd - pcTempStart) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_PROTO_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,
             "Protocol Name and Version exceeded in via");
      return IFX_SIP_FAILURE;
    }
    strcat(pxvia->xSentProto.szprotocol,"/");
    iLen = strlen(pxvia->xSentProto.szprotocol);
    strncat(pxvia->xSentProto.szprotocol,pcTempStart,(pcTempEnd - pcTempStart));
    pxvia->xSentProto.szprotocol[iLen + (pcTempEnd - pcTempStart)] = '\0';
    if(IFX_SIP_ValidateToken((pxvia->xSentProto.szprotocol + iLen + 1)) ==
       IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
      strcpy(pxSipError->szErrorDesc,"Invalid Protocol Version");
      return IFX_SIP_FAILURE;
    }
  }
  pcTempStart = pcCurrPos + 1;/* As it is pointing to / */
  /*Remove any Leading White Spaces */
  while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
    pcTempStart++;
    if(pcTempStart > pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
      return IFX_SIP_FAILURE;
    }
  }
  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,' ');
  if(pcCurrPos == NULL){
    /* Return Error */    
    pxSipError->eDecodeErr = IFX_SIP_VIAPARAM_FORMAT_ERR;
    strcpy(pxSipError->szErrorDesc,"SentBy Missing(in via)");
    return IFX_SIP_FAILURE;
  }
  else{
    if(((pcCurrPos - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
       ((pcCurrPos - pcTempStart) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_VIATRANSP_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Transport below/beyond limit-via");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxvia->xSentProto.szTransport,
            pcTempStart,
            (pcCurrPos - pcTempStart));
    pxvia->xSentProto.szTransport[(pcCurrPos - pcTempStart)] = '\0';

    /* Validate Transport */
    if(IFX_SIP_ValidateToken(pxvia->xSentProto.szTransport) ==
       IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
      strcpy(pxSipError->szErrorDesc,"Invalid Transport");
      return IFX_SIP_FAILURE;
    }
    pcTempStart = pcCurrPos + 1;/* As it is pointing to space */
    /*Remove any Leading White Spaces */
    while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
      pcTempStart++;
      if(pcTempStart > pcEndIndex){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
        strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
        return IFX_SIP_FAILURE;
      }
    }
    pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
    if(pcCurrPos == NULL){
      /* No via params present */
      if(IFX_SIP_DecodeHostPort(pcTempStart,
                                 pcEndIndex,
                                 &pxvia->xSentBy,
                                 pxSipError) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
    }
    else{
      pcTempEnd = pcCurrPos;
      while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
        pcTempEnd--;
        if(pcTempEnd < pcTempStart){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
          strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
          return IFX_SIP_FAILURE;
        }
      }
      /* presence of via parameters */
      if(IFX_SIP_DecodeHostPort(pcTempStart,
                                 pcTempEnd,
                                 &pxvia->xSentBy,
                                 pxSipError) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
      pcTempStart = pcCurrPos + 1;/* As it is pointing to ; */
      if(IFX_SIP_DecodeViaParams(pcTempStart,pcEndIndex,pxvia,pxSipError) ==
         IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
    }
  }
  return IFX_SIP_SUCCESS;
}


/******************************************************************
*  Function Name:  IFX_SIP_DecodeDisplayType
*  Description  :  Decodes the Display type
*  Input Values :  Start and End indices of Display type
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/

e_IFX_SIP_Return
IFX_SIP_DecodeDisplayType(IN  char8* pcStartIndex,
                           IN  char8* pcEndIndex,
                           OUT x_IFX_SIP_DispType* pxDispType,
                           OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart;
  uint32 i;
  pcTempStart = pcStartIndex;

  i = pcEndIndex - pcTempStart;
  if(strncmp(pcTempStart,"render",IFX_SIP_MAX(i,strlen("render"))) == 0){
    pxDispType->ucDType = IFX_SIP_RENDER;
  }
  else if(strncmp(pcTempStart,"session",IFX_SIP_MAX(i,strlen("session"))) ==
          0){
    pxDispType->ucDType = IFX_SIP_SESSION;
  }
  else if(strncmp(pcTempStart,"icon",IFX_SIP_MAX(i,strlen("icon"))) == 0){
    pxDispType->ucDType = IFX_SIP_ICON_D;
  }
  else if(strncmp(pcTempStart,"alert",IFX_SIP_MAX(i,strlen("alert"))) == 0){
    pxDispType->ucDType = IFX_SIP_ALERT;
  }
  else{
    pxDispType->ucDType = IFX_SIP_DISP_EXT;
    if((i > IFX_SIP_MAX_TOKEN) || (i <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_OTHERPARM_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Display Type Exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxDispType->szDispExt,pcTempStart,i);
    pxDispType->szDispExt[i] = '\0';

    /* Validate Other Display type */
    if(IFX_SIP_ValidateToken(pxDispType->szDispExt) == IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
      strcpy(pxSipError->szErrorDesc,"Invalid Display Type token");
      return IFX_SIP_FAILURE;
    }
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeDispParams
*  Description  :  Decodes the Content Dispostion disp-params
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/

e_IFX_SIP_Return
IFX_SIP_DecodeDispParams(IN  char8* pcStartIndex,
                          IN  char8* pcEndIndex,
                          OUT x_IFX_SIP_ContDisp* pxContDisp,
                          OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcCurrPos, * pcTempStart, * pcTempEnd;
  uint32 i;

  pcTempStart = pcStartIndex;
  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'=');
  if(pcCurrPos == NULL){
    /* Generic param with out gen-value */
    pxContDisp->axDispParam[pxContDisp->ucNoOfDispParams].eDispParamType = IFX_SIP_GENERIC_PARAM;
    if(((pcEndIndex - pcTempStart) > IFX_SIP_MAX_TOKEN) ||
       ((pcEndIndex - pcTempStart) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,
             "Generic param excedded(Token) in Cont-Disp");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxContDisp->axDispParam[pxContDisp->ucNoOfDispParams].uxDParam.
      xGenericParam.szToken,pcTempStart,(pcEndIndex - pcTempStart));
    pxContDisp->axDispParam[pxContDisp->ucNoOfDispParams].uxDParam.
    xGenericParam.szToken[(pcEndIndex - pcTempStart)] = '\0';   
    /* Validate Gen Param */
    if(IFX_SIP_ValidateToken(pxContDisp->axDispParam[pxContDisp->
      ucNoOfDispParams].uxDParam.xGenericParam.szToken) == IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
      strcpy(pxSipError->szErrorDesc,"Invalid Display param token");
      return IFX_SIP_FAILURE;
    }
  }
  else{
    pcTempEnd = pcCurrPos;
    /* Remove any Trailing Spaces */
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd < pcTempStart){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid message format");
        return IFX_SIP_FAILURE;
      }
    }

    i = pcTempEnd - pcTempStart;

    if(strncmp(pcTempStart,"handling",IFX_SIP_MAX(i,strlen("handling"))) == 0){
      /* Handling parameters present */
      pxContDisp->axDispParam[pxContDisp->ucNoOfDispParams].
      eDispParamType = IFX_SIP_HANDLING_PARAM;
      pcTempStart = pcCurrPos + 1; /* As it is pointing to = */
      /* Remove any Leading Spaces */
      while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
        pcTempStart++;
        if(pcTempStart > pcEndIndex){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
          strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
          return IFX_SIP_FAILURE;
        }
      }

      pcTempEnd = pcEndIndex;

      while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
        pcTempEnd--;
        if(pcTempEnd < pcTempStart){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid message format");
          return IFX_SIP_FAILURE;
        }
      }

      i = pcTempEnd - pcTempStart;

      if(strncmp(pcTempStart,"optional",IFX_SIP_MAX(i,strlen("optional"))) ==
         0){
        pxContDisp->axDispParam[pxContDisp->ucNoOfDispParams].uxDParam.
        xHandlingParam.ucHandlingParamType = IFX_SIP_OPTIONAL;
        strcpy(pxContDisp->axDispParam[pxContDisp->ucNoOfDispParams].uxDParam.
               xHandlingParam.szOtherHandling,"optional");
      }
      else if(strncmp(pcTempStart,
                      "required",
                      IFX_SIP_MAX(i,strlen("required"))) == 0){
        pxContDisp->axDispParam[pxContDisp->ucNoOfDispParams].uxDParam.
        xHandlingParam.ucHandlingParamType = IFX_SIP_REQUIRED;
        strcpy(pxContDisp->axDispParam[pxContDisp->ucNoOfDispParams].uxDParam.
               xHandlingParam.szOtherHandling,"required");
      }
      else{
        pxContDisp->axDispParam[pxContDisp->ucNoOfDispParams].uxDParam.
        xHandlingParam.ucHandlingParamType = IFX_SIP_OTHER_HANDLING;
        if((i >= IFX_SIP_MAX_TOKEN) || (i <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_OTHERPARM_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,
                 "Handling param exceeded in content disp");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxContDisp->axDispParam[pxContDisp->ucNoOfDispParams].
          uxDParam.xHandlingParam.szOtherHandling,pcTempStart,i);
        pxContDisp->axDispParam[pxContDisp->ucNoOfDispParams].uxDParam.
        xHandlingParam.szOtherHandling[i] = '\0';
        /* Validate Other Handling */
        if(IFX_SIP_ValidateToken(pxContDisp->axDispParam[pxContDisp
          ->ucNoOfDispParams].uxDParam.xHandlingParam.
          szOtherHandling) == IFX_SIP_FAILURE){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
          strcpy(pxSipError->szErrorDesc,"Invalid Display Type token");
          return IFX_SIP_FAILURE;
        }
      }
    }
    else{
      /*Generic parameters with token an gen value */
      pxContDisp->axDispParam[pxContDisp->ucNoOfDispParams].
      eDispParamType = IFX_SIP_GENERIC_PARAM;
      if((i >= IFX_SIP_MAX_TOKEN) || (i <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,
               "Generic param excedded(Token) in Cont-Disp");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxContDisp->axDispParam[pxContDisp->ucNoOfDispParams].
        uxDParam.xGenericParam.szToken,pcTempStart,i);
      pxContDisp->axDispParam[pxContDisp->ucNoOfDispParams].uxDParam.
      xGenericParam.szToken[i] = '\0';

      /* Validate Gen Param */
      if(IFX_SIP_ValidateToken(pxContDisp->axDispParam[pxContDisp->
        ucNoOfDispParams].uxDParam.xGenericParam.szToken) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
        strcpy(pxSipError->szErrorDesc,"Invalid Display param token");
        return IFX_SIP_FAILURE;
      }

      pcTempStart = pcCurrPos + 1; /* As it is pointing to = */
      /* Remove any Leading Spaces */
      while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
        pcTempStart++;
        if(pcTempStart > pcEndIndex){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
          strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
          return IFX_SIP_FAILURE;
        }
      }

      if(((pcEndIndex - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
         ((pcEndIndex - pcTempStart) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,
               "Generic param excedded(GenValue) in Cont-Disp");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxContDisp->axDispParam[pxContDisp->ucNoOfDispParams].
        uxDParam.xGenericParam.szGenValue,
              pcTempStart,
              (pcEndIndex - pcTempStart));
      pxContDisp->axDispParam[pxContDisp->ucNoOfDispParams].uxDParam.
      xGenericParam.szGenValue[(pcEndIndex - pcTempStart)] = '\0';

      /* Validate Gen Param */
      if(IFX_SIP_ValidateGenValue(pxContDisp->axDispParam[pxContDisp->
        ucNoOfDispParams].uxDParam.xGenericParam.szGenValue) ==
         IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_GENVALUE;
        strcpy(pxSipError->szErrorDesc,"Invalid Gen Value in GenParam");
        return IFX_SIP_FAILURE;
      }
    }
  }
  pxContDisp->ucNoOfDispParams++;
  return IFX_SIP_SUCCESS;
}


/******************************************************************
*  Function Name:  IFX_SIP_DecodeGenericParams
*  Description  :  Decodes the generic params
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/

e_IFX_SIP_Return
IFX_SIP_DecodeGenericParams(IN  char8* pcStartIndex,
                             IN  char8* pcEndIndex,
                             OUT x_IFX_SIP_GenericParam* pxGenParam,
                             OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcCurrPos, * pcTempStart, * pcTempEnd;
  int32 i;
  pcCurrPos = pcStartIndex;
  /* Remove leading white spaces */
  while((*pcCurrPos == ' ') || (*pcCurrPos == '\t')){
    pcCurrPos++;
    if(pcCurrPos > pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
      return IFX_SIP_FAILURE;
    }
  }
  pcTempStart = pcCurrPos;
  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'=');
  if(pcCurrPos == NULL){
    /* Remove any Trailing Spaces */
    pcTempEnd = pcEndIndex;
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd <= pcTempStart){
        return IFX_SIP_FAILURE;
      }
    }
    /* Generic param without gen-value */
    if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
       ((pcTempEnd - pcTempStart) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Generic param excedded(Token)");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxGenParam->szToken,pcTempStart,(pcTempEnd - pcTempStart));
    pxGenParam->szToken[(pcTempEnd - pcTempStart)] = '\0';  
    pxGenParam->szGenValue[0] = '\0'; 
    /* Validate Gen Param Token */
    if(IFX_SIP_ValidateToken(pxGenParam->szToken) == IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
      strcpy(pxSipError->szErrorDesc,"Invalid Gen Param Token");
      return IFX_SIP_FAILURE;
    }
  }
  else{
    for(i = 0; (pcTempStart + i) < pcCurrPos; i++){
      if((*(pcTempStart + i) == ' ') || (*(pcTempStart + i) == '\t')){
        break;
      }
    }   
    /*Generic parameters with token and gen value */
    if((i >= IFX_SIP_MAX_TOKEN) || (i <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Generic param excedded(Token)");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxGenParam->szToken,pcTempStart,i);
    pxGenParam->szToken[i] = '\0';
    /* Validate Gen Param */
    if(IFX_SIP_ValidateToken(pxGenParam->szToken) == IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
      strcpy(pxSipError->szErrorDesc,"Invalid Gen Param Token");
      return IFX_SIP_FAILURE;
    }
    pcTempStart = pcCurrPos + 1; /* As it is pointing to = */
    /* Remove any Leading White Spaces */
    while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
      pcTempStart++;
      if(pcTempStart > pcEndIndex){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
        strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
        return IFX_SIP_FAILURE;
      }
    }
    /* Remove any Trailing White spaces */
    pcTempEnd = pcEndIndex;
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd <= pcTempStart){
        return IFX_SIP_FAILURE;
      }
    }
    if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
       ((pcTempEnd - pcTempStart) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Generic param excedded(GenValue)");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxGenParam->szGenValue,pcTempStart,(pcTempEnd - pcTempStart));
    pxGenParam->szGenValue[(pcTempEnd - pcTempStart)] = '\0'; 
    /* Validate Gen Param Value */
    if(IFX_SIP_ValidateGenValue(pxGenParam->szGenValue) == IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_GENVALUE;
      strcpy(pxSipError->szErrorDesc,"Invalid Gen Value in GenParam");
      return IFX_SIP_FAILURE;
    }
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeNameAddr
*  Description  :  Decodes the Name Addr
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        :  name-addr      =  [ display-name ] LAQUOT addr-spec RAQUOT
           addr-spec      =  SIP-URI / SIPS-URI / absoluteURI 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeNameAddr(IN  char8* pcStartIndex,
                        IN  char8* pcEndIndex,
                        OUT x_IFX_SIP_NameAddr* pxNameAddr,
                        OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcCurrPos, * pcTempStart, * pcTempEnd;
  pcTempStart = pcStartIndex;

  /* Handling < within quotes */
  if(*pcTempStart == '\"'){
    char8* pcTemp;
    pcTemp = pcTempStart + 1;

    pcCurrPos = IFX_SIP_strchr(pcTemp,pcEndIndex,'\"'); 
    if(pcCurrPos == NULL){
      return IFX_SIP_FAILURE;
    }
    else{
      /* Check if it is a quote within quotes */
      while((*(pcCurrPos - 1) == '\\')){
        pcTemp = pcCurrPos + 1;
        pcCurrPos = IFX_SIP_strchr(pcTemp,pcEndIndex,'\"');
      }
      pcTemp = pcCurrPos + 1;
      pcCurrPos = IFX_SIP_strchr(pcTemp,pcEndIndex,'<');
    }
  }
  else{
    pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'<');
  }

  if(pcCurrPos == NULL){
    /* Return error as < is not found */
    pxSipError->eDecodeErr = IFX_SIP_INVALID_NAMEADDR_FORMAT;
    strcpy(pxSipError->szErrorDesc,"Error in NameAddr Spec format");
    return IFX_SIP_FAILURE;
  }
  else{
    pcTempEnd = pcCurrPos;
    /* Remove any Trailing Spaces */
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd < pcTempStart){
        /* Display Name absent */
        break;
      }
    }

    if((pcTempEnd - pcTempStart) > 0){
      if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN)){
        pxSipError->eDecodeErr = IFX_SIP_DISPLAYNAME_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Display Name exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxNameAddr->szDisplayName,pcTempStart,(pcTempEnd - pcTempStart));
      pxNameAddr->szDisplayName[(pcTempEnd - pcTempStart)] = '\0';
      /* Validate Display Name */
      if(IFX_SIP_ValidateDisplayName(pxNameAddr->szDisplayName) ==
         IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_DISPLAYNAME;
        strcpy(pxSipError->szErrorDesc,"Invalid Display Name");
        return IFX_SIP_FAILURE;
      }
    }
    else{
      /* Display Name absent */
      pxNameAddr->szDisplayName[0] = '\0';
    }

    pcTempStart = pcCurrPos + 1;/* As it is poining to > */
    pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'>');
    if(pcCurrPos != NULL){
      if(IFX_SIP_DecodeURI(pcTempStart,
                            pcCurrPos,
                            &pxNameAddr->xAddrSpec,
                            pxSipError) != IFX_SIP_SUCCESS){
        return IFX_SIP_FAILURE;
      }
    }
  }   
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeRouteParam
*  Description  :  Decodes the route params
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : nameaddr *(SEMI rr-Param)        
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeRouteParam(IN  char8* pcStartIndex,
                          IN  char8* pcEndIndex,
                          OUT x_IFX_SIP_RouteParam* pxRouteParam,
                          OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcCurrPos, * pcTempStart, * pcTempEnd;

  pcTempStart = pcStartIndex;

  if(*pcTempStart == '\"'){
    pcCurrPos = IFX_SIP_FindNonEscapedQuote((pcTempStart + 1),pcEndIndex);
    if(pcCurrPos == NULL){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid message format");
      return IFX_SIP_FAILURE;
    }
    pcTempEnd = pcCurrPos + 1;
    pcCurrPos = IFX_SIP_strchr(pcTempEnd,pcEndIndex,'>');
  }
  else{
    pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'>');
  }

  if(pcCurrPos != NULL){
    if(IFX_SIP_DecodeNameAddr(pcTempStart,(pcCurrPos + 1),&pxRouteParam->
      xNameAddr,pxSipError) == IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
    pcTempStart = pcCurrPos + 1; /* As it is pointing to > */
    pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
    if(pcCurrPos == NULL){
      while(pcTempStart < pcEndIndex){
        if(*pcTempStart == ' ' || *pcTempStart == '\t'){
          pcTempStart++;
          continue;
        }
        else{
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid message format");
          return IFX_SIP_FAILURE;
        }
      }
      return IFX_SIP_SUCCESS;
    }
    else{
      char8* pcTemp;
      pcTemp = pcTempStart; /* As it points to > */

      /* Check for spaces after > */
      while((*pcTemp == ' ') || (*pcTemp == '\t')){
        pcTemp++;
        if(pcTemp > pcCurrPos){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid message format");
          return IFX_SIP_FAILURE;
        }
      }

      /* To check if there are only spaces between > and ; */
      if(*pcTemp != ';'){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid message format");
        return IFX_SIP_FAILURE;
      }
      pcTempStart = pcCurrPos + 1; /* As it points to ; */
    }
    do{
      /* Remove any leading white spaces */
      while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
        pcTempStart++;
        if(pcTempStart > pcEndIndex){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
          strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
          return IFX_SIP_FAILURE;
        }
      }

      if(pxRouteParam->ucNoOfRRParam >= IFX_SIP_MAX_RRPARAM){
        pxSipError->eDecodeErr = IFX_SIP_MAXRRPARAM_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Max RR param Exceeded");
        return IFX_SIP_FAILURE;
      }

      /* Check for the delimiters */
      if(IFX_SIP_FindDelimWhenQuotesRPresent(pcTempStart,
                                              pcEndIndex,
                                              ';',
                                              &pcCurrPos,
                                              &pcTempEnd,
                                              pxSipError) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }

      if(IFX_SIP_DecodeGenericParams(pcTempStart,pcTempEnd,&pxRouteParam->
         axRRParam[pxRouteParam->ucNoOfRRParam],pxSipError)==IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
      pxRouteParam->ucNoOfRRParam++;
      if(pcCurrPos == NULL){
        /* Last RR parameter */       
        break;
      }
      else{
        pcTempStart = pcCurrPos + 1;/* As it is pointing to ; */
      }
    }
    while(1);
  }
  else{
    /* Not Closed with > return Error */
    pxSipError->eDecodeErr = IFX_SIP_INVALID_NAMEADDR_FORMAT;
    strcpy(pxSipError->szErrorDesc,"Name addr Format Invalid");
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_DecodeQValue
*  Description  :  Decodes the Q value
*  Input Values :  Start and End indices 
*  Output Values:  Fills the float passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        :  qvalue =("0"[ "." 0*3DIGIT ])/("1"["."0*3("0")] )
  
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeQValue(IN  char8* pcStartIndex,
                      IN  char8* pcEndIndex,
                      OUT float32* fQVal,
                      OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcCurrPos, * pcTempEnd, acTemp[10];
  int32 i, dec = 1;
  pcTempStart = pcStartIndex;
  pcTempEnd = pcEndIndex;
  *fQVal = 0.0;

  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcTempEnd,'.');
  if(pcCurrPos == NULL){
    /* Only decimal part is present */
    if((pcTempEnd - pcTempStart) != 1){
      /* Return Error */
      pxSipError->eDecodeErr = IFX_SIP_QVALFORMAT_INVALID;
      strcpy(pxSipError->szErrorDesc,"Error in QVal format");
      return IFX_SIP_FAILURE;
    }
    else{
      if((*pcTempStart != 48) && (*pcTempStart != 49)){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_DIGIT;
        strcpy(pxSipError->szErrorDesc,"Invalid Q value");
        return IFX_SIP_FAILURE;
      }
      strncpy(acTemp,pcTempStart,(pcTempEnd - pcTempStart));
      *fQVal += atoi(acTemp);
    }
  }
  else{
    /* Copy the Decimal Part*/
    if((pcCurrPos - pcTempStart) != 1){
      /* Return Error */
      pxSipError->eDecodeErr = IFX_SIP_QVALFORMAT_INVALID;
      strcpy(pxSipError->szErrorDesc,"Error in QVal format");
      return IFX_SIP_FAILURE;
    }
    else{
      strncpy(acTemp,pcTempStart,(pcCurrPos - pcTempStart));
      *fQVal += atoi(acTemp);
    }
    /*fraction part present*/
    pcTempStart = pcCurrPos + 1;
    for(i = 0; i < 3; i++){
      if((pcTempStart + i) > pcTempEnd){
        break;
      }
      dec *= 10;
      if(!isdigit(*(pcTempStart + i))){
        break;
        /*pxSipError->eDecodeErr = IFX_SIP_INVALID_DIGIT;
          strcpy(pxSipError->szErrorDesc,"Invalid Q value");
          return IFX_SIP_FAILURE;*/
      }
      else{
        (*fQVal) += (*(pcTempStart + i) - '0') / (float32) dec;
      }
    }
  }
  if((*fQVal < 0.0) || (*fQVal > 1.0)){
    pxSipError->eDecodeErr = IFX_SIP_QVALFORMAT_INVALID;
    strcpy(pxSipError->szErrorDesc,"Out of Range");
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeContactParams
*  Description  :  Decodes the contact params
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeContactParams(IN  char8* pcStartIndex,
                             IN  char8* pcEndIndex,
                             OUT x_IFX_SIP_ContParams* pxContactParam,
                             OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcCurrPos, * pcTempStart, cRet, acTemp[10], * pcTempEnd;
  uint32 i;
  pcTempStart = pcStartIndex;
  do{
    cRet = IFX_SIP_strtok(pcTempStart,pcEndIndex,&pcCurrPos,";=");
    if(cRet == ';'){
      pcTempEnd = pcCurrPos;
      /* Remove any Trailing Spaces */
      while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
        pcTempEnd--;
        if(pcTempEnd < pcTempStart){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid message format");
          return IFX_SIP_FAILURE;
        }
      }

      /* Presence of extension param without Gen Value */
      pxContactParam->ucContParamsType = IFX_SIP_CONT_EXT;
      if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
         ((pcCurrPos - pcTempStart) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Token parameter exceeded the limit");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxContactParam->uxContParamsType.xGenericParam.szToken,
              pcTempStart,
              (pcTempEnd - pcTempStart));
      pxContactParam->uxContParamsType.xGenericParam.
                               szToken[(pcTempEnd - pcTempStart)] = '\0';
      if(IFX_SIP_ValidateToken(pxContactParam->uxContParamsType.
        xGenericParam.szToken) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
        strcpy(pxSipError->szErrorDesc,"Invalid Token");
        return IFX_SIP_FAILURE;
      }
      pcTempStart = pcCurrPos + 1;/* As it is pointing to ; */
    }
    else if(cRet == '='){
      /* Presence of some of the params */
      pcTempEnd = pcCurrPos;
      /* Remove any Trailing Spaces */
      while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
        pcTempEnd--;
        if(pcTempEnd < pcTempStart){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid message format");
          return IFX_SIP_FAILURE;
        }
      }

      i = pcTempEnd - pcTempStart;

      if(strncmp(pcTempStart,"q",IFX_SIP_MAX(i,strlen("q"))) == 0){
        pxContactParam->ucContParamsType = IFX_SIP_C_P_Q;
        pcTempStart = pcCurrPos + 1;/* As it is pointing to = */

        /* Remove any leading white spaces */
        while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
          pcTempStart++;
          if(pcTempStart > pcEndIndex){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
            strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
            return IFX_SIP_FAILURE;
          }
        }

        pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
        if(pcCurrPos != NULL){
          pcTempEnd = pcCurrPos;

          /* Remove any Trailing Spaces */
          while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
            pcTempEnd--;
            if(pcTempEnd < pcTempStart){
              pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
              strcpy(pxSipError->szErrorDesc,"Invalid message format");
              return IFX_SIP_FAILURE;
            }
          }

          if(IFX_SIP_DecodeQValue(pcTempStart,
                                   pcTempEnd,
                                   &pxContactParam->uxContParamsType.fCpq,
                                   pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
          pcTempStart = pcCurrPos + 1;
        }
        else{
          if(IFX_SIP_DecodeQValue(pcTempStart,
                                   pcEndIndex,
                                   &pxContactParam->uxContParamsType.fCpq,
                                   pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
          break;
        }
      }
      else if(IFX_SIP_strncasecmp(pcTempStart,"expires",
                   IFX_SIP_MAX(i,strlen("expires"))) == 0){
        pxContactParam->ucContParamsType = IFX_SIP_C_P_EXPIRES;
        pcTempStart = pcCurrPos + 1;/* As it is pointing to = */

        /* Remove any leading white spaces */
        while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
          pcTempStart++;
          if(pcTempStart > pcEndIndex){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
            strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
            return IFX_SIP_FAILURE;
          }
        }


        pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
        if(pcCurrPos != NULL){
          pcTempEnd = pcCurrPos;

          /* Remove any Trailing Spaces */
          while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
            pcTempEnd--;
            if(pcTempEnd < pcTempStart){
              pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
              strcpy(pxSipError->szErrorDesc,"Invalid message format");
              return IFX_SIP_FAILURE;
            }
          }

          i = pcTempEnd - pcTempStart;

          if((i > 10) || (i <= 0)/*Greater than 10 digits*/){
            pxSipError->eDecodeErr = IFX_SIP_EXPIRES_EXCEEDED;
            strcpy(pxSipError->szErrorDesc,"Expires param exceeded the limit");
            return IFX_SIP_FAILURE;
          }
          strncpy(acTemp,pcTempStart,i);
          acTemp[i] = '\0';
          pxContactParam->uxContParamsType.uiCpExpires = (uint32)
                                                         atoi(acTemp);
          pcTempStart = pcCurrPos + 1;/* As it is pointing to ; */
        }
        else{
          for(i = 0; (pcTempStart + i) < pcEndIndex; i++){
            if(*(pcTempStart + i) == ' ' || *(pcTempStart + i) == '\t'){
              break;
            }
            if(!isdigit(*(pcTempStart + i))){
              pxSipError->eDecodeErr = IFX_SIP_INVALID_DIGIT;
              strcpy(pxSipError->szErrorDesc,"Invalid Expires value");
              return IFX_SIP_FAILURE;
            }
          }
          if((i > 10) || (i <= 0)/*Greater than 10 digits*/){
            pxSipError->eDecodeErr = IFX_SIP_EXPIRES_EXCEEDED;
            strcpy(pxSipError->szErrorDesc,"Expires param exceeded the limit");
            return IFX_SIP_FAILURE;
          }
          strncpy(acTemp,pcTempStart,i);
          acTemp[i] = '\0';
          pxContactParam->uxContParamsType.uiCpExpires = (uint32)
                                                         atoi(acTemp);
          break;
        }
      }
      else{
        pxContactParam->ucContParamsType = IFX_SIP_CONT_EXT;
        /* Copy the Token */
        if((i >= IFX_SIP_MAX_TOKEN) || (i <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Token parameter exceeded the limit");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxContactParam->uxContParamsType.xGenericParam.szToken,
                pcTempStart,
                i);
        pxContactParam->uxContParamsType.xGenericParam.szToken[i] = '\0';
        if(IFX_SIP_ValidateToken(pxContactParam->uxContParamsType.
          xGenericParam.szToken) == IFX_SIP_FAILURE){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
          strcpy(pxSipError->szErrorDesc,"Invalid Token");
          return IFX_SIP_FAILURE;
        }
        pcTempStart = pcCurrPos + 1;/* As it is pointing to = */

        /* Remove any leading white spaces */
        while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
          pcTempStart++;
          if(pcTempStart > pcEndIndex){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
            strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
            return IFX_SIP_FAILURE;
          }
        }

        pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
        if(pcCurrPos != NULL){
          pcTempEnd = pcCurrPos;

          /* Remove any Trailing Spaces */
          while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
            pcTempEnd--;
            if(pcTempEnd < pcTempStart){
              pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
              strcpy(pxSipError->szErrorDesc,"Invalid message format");
              return IFX_SIP_FAILURE;
            }
          }

          if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
             ((pcTempEnd - pcTempStart) <= 0)){
            pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
            strcpy(pxSipError->szErrorDesc,
                   "GenValue parameter exceeded the limit");
            return IFX_SIP_FAILURE;
          }
          strncpy(pxContactParam->uxContParamsType.xGenericParam.
            szGenValue,pcTempStart,(pcTempEnd - pcTempStart));
          pxContactParam->uxContParamsType.xGenericParam.
                           szGenValue[(pcTempEnd - pcTempStart)] = '\0';

          /* To be validated */
          if(IFX_SIP_ValidateGenValue(pxContactParam->
            uxContParamsType.xGenericParam.szGenValue) == IFX_SIP_FAILURE){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_GENVALUE;
            strcpy(pxSipError->szErrorDesc,"Invalid Gen Value in GenParam");
            return IFX_SIP_FAILURE;
          }

          pcTempStart = pcCurrPos + 1;/* As it is pointing to ; */
        }
        else{
          if(((pcEndIndex - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
             ((pcEndIndex - pcTempStart) <= 0)){
            pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
            strcpy(pxSipError->szErrorDesc,
                   "GenValue parameter exceeded the limit");
            return IFX_SIP_FAILURE;
          }
          strncpy(pxContactParam->uxContParamsType.xGenericParam.
            szGenValue,pcTempStart,(pcEndIndex - pcTempStart));
          pxContactParam->uxContParamsType.xGenericParam.
                       szGenValue[(pcEndIndex - pcTempStart)] = '\0';

          /* validation */
          if(IFX_SIP_ValidateGenValue(pxContactParam->
            uxContParamsType.xGenericParam.szGenValue) == IFX_SIP_FAILURE){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_GENVALUE;
            strcpy(pxSipError->szErrorDesc,"Invalid Gen Value in GenParam");
            return IFX_SIP_FAILURE;
          }
          break;
        }
      }
    }
    else{
      /* No token found so only the contact ext with token present*/
      pxContactParam->ucContParamsType = IFX_SIP_CONT_EXT;
      if(((pcEndIndex - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
         ((pcEndIndex - pcTempStart) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Token parameter exceeded the limit");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxContactParam->uxContParamsType.xGenericParam.szToken,
              pcTempStart,
              (pcEndIndex - pcTempStart));
      pxContactParam->uxContParamsType.xGenericParam.
                           szToken[(pcEndIndex - pcTempStart)] = '\0';
      if(IFX_SIP_ValidateToken(pxContactParam->uxContParamsType.
        xGenericParam.szToken) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
        strcpy(pxSipError->szErrorDesc,"Invalid Token");
        return IFX_SIP_FAILURE;
      }
      break;
    }
  }
  while(1);
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeContactParam
*  Description  :  Decodes the contact param
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeContactParam(IN  char8* pcStartIndex,
                            IN  char8* pcEndIndex,
                            OUT x_IFX_SIP_ContactParam* pxContactParam,
                            OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcCurrPos, * pcTempStart, * pcTempEnd;
  int32 iRet, iCount;

  pcTempStart = pcStartIndex;

  if(*pcTempStart == '\"'){
    pcCurrPos = IFX_SIP_FindNonEscapedQuote((pcTempStart + 1),pcEndIndex);
    if(pcCurrPos == NULL){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid message format");
      return IFX_SIP_FAILURE;
    }
    pcTempEnd = pcCurrPos + 1;
    pcCurrPos = IFX_SIP_strchr(pcTempEnd,pcEndIndex,'<');
  }
  else{
    pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'<');
  }

  if(pcCurrPos != NULL){
    pxContactParam->xAddrType.eAddrType = IFX_SIP_NAMEADDR;
    pcTempEnd = pcCurrPos;

    /* Remove any Trailing Spaces */
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd < pcTempStart){
        /* Display name absent */
        break;
      }
    }

    if((pcTempEnd - pcTempStart) > 0){
      if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN)){
        pxSipError->eDecodeErr = IFX_SIP_DISPLAYNAME_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Display Name exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxContactParam->xAddrType.uxAddrType.xNameAddr.szDisplayName,
              pcTempStart,
              (pcTempEnd - pcTempStart));
      pxContactParam->xAddrType.uxAddrType.xNameAddr.
                           szDisplayName[(pcTempEnd - pcTempStart)] = '\0';

      /* Validate Display Name */
      if(IFX_SIP_ValidateDisplayName(pxContactParam->xAddrType.uxAddrType.
        xNameAddr.szDisplayName) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_DISPLAYNAME;
        strcpy(pxSipError->szErrorDesc,"Invalid Display Name");
        return IFX_SIP_FAILURE;
      }
    }

    pcCurrPos++;
    pcTempStart = pcCurrPos;
    pcTempEnd = IFX_SIP_strchr(pcTempStart,pcEndIndex,'>');
    iRet = IFX_SIP_DecodeURI(pcTempStart,pcTempEnd,&pxContactParam->
      xAddrType.uxAddrType.xNameAddr.xAddrSpec,pxSipError);
    if(iRet != IFX_SIP_SUCCESS){
      return iRet;
    }
    pcCurrPos = IFX_SIP_strchr(pcTempEnd,pcEndIndex,';');
    if(pcCurrPos == NULL){
      pcTempEnd++; /* as it points to > */
      /* Check if only spaces are present after > */
      while(pcTempEnd < pcEndIndex){
        if((*pcTempEnd == ' ') || (*pcTempEnd == '\t')){
          pcTempEnd++;
          continue;
        }
        else{
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid message format");
          return IFX_SIP_FAILURE;
        }
      }
      pcTempEnd = pcEndIndex;
    }
    else{
      char8* pcTemp;
      pcTemp = pcTempEnd + 1; /* As it points to > */

      while((*pcTemp == ' ') || (*pcTemp == '\t')){
        pcTemp++;
        if(pcTemp > pcCurrPos){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid message format");
          return IFX_SIP_FAILURE;
        }
      }
      /* To check if there are only spaces between > and ; */
      if(*pcTemp != ';'){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid message format");
        return IFX_SIP_FAILURE;
      }

      pcTempEnd = pcCurrPos + 1;
    }
    pcTempStart = pcTempEnd;
  }
  else{
    pxContactParam->xAddrType.eAddrType = IFX_SIP_ADDRSPEC;
    pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
    if(pcCurrPos != NULL){
      pcTempEnd = pcCurrPos;
    }
    else{
      pcTempEnd = pcEndIndex;
    }
    iRet = IFX_SIP_DecodeURI(pcTempStart,pcTempEnd,&pxContactParam->
      xAddrType.uxAddrType.xAddrSpec,pxSipError);
    if(iRet != IFX_SIP_SUCCESS){
      return iRet;
    }
    pcTempStart = pcTempEnd + 1;
  }
  if(pcTempEnd == pcEndIndex){
    return IFX_SIP_SUCCESS;
  }
  /* Presence of Contact parameters */
  do{
    /* Remove any leading white spaces */
    while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
      pcTempStart++;
      if(pcTempStart > pcEndIndex){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
        strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
        return IFX_SIP_FAILURE;
      }
    }

    iCount = pxContactParam->ucNoOfContParams;
    if(iCount >= IFX_SIP_MAX_CONT_PARAMS){
      pxSipError->eDecodeErr = IFX_SIP_MAXCONTACTPARAM_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Max Contact Param Exceeded");
      return IFX_SIP_FAILURE;
    }

    if(IFX_SIP_FindDelimWhenQuotesRPresent(pcTempStart,
                                            pcEndIndex,
                                            ';',
                                            &pcCurrPos,
                                            &pcTempEnd,
                                            pxSipError) == IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }

    iRet = IFX_SIP_DecodeContactParams(pcTempStart,
                                        pcTempEnd,
                                        &pxContactParam->axContParams[iCount],
                                        pxSipError);
    if(iRet != IFX_SIP_SUCCESS){
      return iRet;
    }
    pxContactParam->ucNoOfContParams++;
    if(pcCurrPos == NULL){
      break;
    }
    else{
      pcTempStart = pcCurrPos + 1;
    }
  }
  while(1); 
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_DecodeAcceptParam
*  Description  :  Decodes the Accept parameters
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        :   
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeAcceptParam(IN  char8* pcStartIndex,
                           IN  char8* pcEndIndex,
                           OUT x_IFX_SIP_AcceptParam* pxAcceptParam,
                           OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcCurrPos, * pcTempEnd;
  uint32 i;
  pcTempStart = pcStartIndex;

  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'=');
  if(pcCurrPos == NULL){
    pxAcceptParam->ucChoiceOnUnion = IFX_SIP_GENERIC_PARAM;
    if(IFX_SIP_DecodeGenericParams(pcTempStart,pcEndIndex,&pxAcceptParam->
      uxAparam.xGenericParam,pxSipError) == IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
  }
  else{
    pcTempEnd = pcCurrPos;
    /* Remove any Trailing Spaces */
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd < pcTempStart){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid message format");
        return IFX_SIP_FAILURE;
      }
    } 
    i = pcTempEnd - pcTempStart;

    if(strncmp(pcTempStart,"q",IFX_SIP_MAX(i,strlen("q"))) == 0){
      pxAcceptParam->ucChoiceOnUnion = IFX_SIP_QVALUE;
      pcTempStart = pcCurrPos + 1;/* As it is pointing to = */

      /* Remove any Leading Spaces */
      while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
        pcTempStart++;
        if(pcTempStart > pcEndIndex){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
          strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
          return IFX_SIP_FAILURE;
        }
      }

      if(IFX_SIP_DecodeQValue(pcTempStart,pcEndIndex,&pxAcceptParam->
        uxAparam.fQvalue,pxSipError) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
      pcTempStart = pcCurrPos + 1;
    }
    else{
      pxAcceptParam->ucChoiceOnUnion = IFX_SIP_GENERIC_PARAM;
      if(IFX_SIP_DecodeGenericParams(pcTempStart,
                                      pcEndIndex,
                                      &pxAcceptParam->uxAparam.xGenericParam,
                                      pxSipError) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
    }
  }
  return IFX_SIP_SUCCESS;
}


/******************************************************************
*  Function Name:  IFX_SIP_DecodeEncodingParam
*  Description  :  Decodes the Encoding parameters
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        :   
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeEncodingParam(IN  char8* pcStartIndex,
                             IN  char8* pcEndIndex,
                             OUT x_IFX_SIP_Encoding* pxEnc,
                             OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcCurrPos, * pcTempEnd;
  pcTempStart = pcStartIndex;
  while((pcTempStart < pcEndIndex) &&
        ((*pcTempStart == ' ') || (*pcTempStart == '\t'))){
    pcTempStart++;
  }
  if(pcTempStart >= pcEndIndex){
    /* Need not return failure as encoding is optional */
    return IFX_SIP_SUCCESS;
  }
  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
  if(pcCurrPos == NULL){
    pcTempEnd = pcEndIndex;
  }
  else{
    pcTempEnd = pcCurrPos;
    /* Remove any Trailing Spaces */
    while((pcTempEnd >= pcTempStart) &&
          ((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t'))){
      pcTempEnd--;
    }

    if(pcTempEnd < pcTempStart){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Accept encoding fmt");
      return IFX_SIP_FAILURE;
    }
  }

  if(strncmp(pcTempStart,"*",IFX_SIP_MAX(1,(pcTempEnd - pcTempStart))) == 0){
    pxEnc->xCodings.ucContEncFlag = 1;
  }
  else{
    pxEnc->xCodings.ucContEncFlag = 0;
    if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
       ((pcTempEnd - pcTempStart) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_TOKEN_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Token below/beyond limits");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxEnc->xCodings.szContentEncoding,
            pcTempStart,
            (pcTempEnd - pcTempStart));
    pxEnc->xCodings.szContentEncoding[(pcTempEnd - pcTempStart)] = '\0';
    if(IFX_SIP_ValidateToken(pxEnc->xCodings.szContentEncoding) ==
       IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
      strcpy(pxSipError->szErrorDesc,"Invalid Token");
      return IFX_SIP_FAILURE;
    }
  } 
  if(pcCurrPos != NULL){
    pcTempStart = pcCurrPos + 1;
    do{
      /* Remove any Leading white spaces */
      while((pcTempStart < pcEndIndex) &&
            ((*pcTempStart == ' ') || (*pcTempStart == '\t'))){
        pcTempStart++;
      }
      if(pcTempStart >= pcEndIndex){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid Accept encoding fmt");
        return IFX_SIP_FAILURE;
      }

      if(pxEnc->ucNoOfAcceptParam >= IFX_SIP_MAX_ACCEPT_PARAM){
        pxSipError->eDecodeErr = IFX_SIP_MAX_ACCEPTPARAM_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Max Accept param exceeded");
        return IFX_SIP_FAILURE;
      }

      if(IFX_SIP_FindDelimWhenQuotesRPresent(pcTempStart,
                                              pcEndIndex,
                                              ';',
                                              &pcCurrPos,
                                              &pcTempEnd,
                                              pxSipError) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid Accept encoding fmt");
        return IFX_SIP_FAILURE;
      }

      if(IFX_SIP_DecodeAcceptParam(pcTempStart,pcTempEnd,&pxEnc->
        axAcceptParam[pxEnc->ucNoOfAcceptParam],pxSipError) ==
         IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
      pxEnc->ucNoOfAcceptParam++;

      if(pcCurrPos == NULL){
        break;
      }
      else{
        pcTempStart = pcCurrPos + 1;
      }
    }
    while(1);
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeLanguageRange
*  Description  :  Decodes the Language Range 
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        :   
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeLanguageRange(IN  char8* pcStartIndex,
                             IN  char8* pcEndIndex,
                             OUT x_IFX_SIP_Language* pxLang,
                             OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcCurrPos, * pcTempEnd;
  pcTempStart = pcStartIndex;
  while((pcTempStart < pcEndIndex) &&
        ((*pcTempStart == ' ') || (*pcTempStart == '\t'))){
    pcTempStart++;
  }
  if(pcTempStart >= pcEndIndex){
    /* Need not return failure as Language is optional */
    return IFX_SIP_SUCCESS;
  }
  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
  if(pcCurrPos == NULL){
    pcTempEnd = pcEndIndex;
  }
  else{
    pcTempEnd = pcCurrPos;
    /* Remove any Trailing Spaces */
    while((pcTempEnd >= pcTempStart) &&
          ((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t'))){
      pcTempEnd--;
    }
    if(pcTempEnd < pcTempStart){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Accept encoding fmt");
      return IFX_SIP_FAILURE;
    }
  }

  if(strncmp(pcTempStart,"*",IFX_SIP_MAX(1,(pcTempEnd - pcTempStart))) == 0){
    pxLang->bLangFlag = 1;
  }
  else{
    pxLang->bLangFlag = 0;
    if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
       ((pcTempEnd - pcTempStart) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_TOKEN_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Token below/beyond limits");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxLang->szLangRange,pcTempStart,(pcTempEnd - pcTempStart));
    pxLang->szLangRange[(pcTempEnd - pcTempStart)] = '\0';
    if(IFX_SIP_ValidateLanguage(pxLang->szLangRange) == IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_LANGUAGE;
      strcpy(pxSipError->szErrorDesc,"Invalid Language");
      return IFX_SIP_FAILURE;
    }
  } 
  if(pcCurrPos != NULL){
    pcTempStart = pcCurrPos + 1;
    do{
      /* Remove any Leading white spaces */
      while((pcTempStart < pcEndIndex) &&
            ((*pcTempStart == ' ') || (*pcTempStart == '\t'))){
        pcTempStart++;
      }
      if(pcTempStart >= pcEndIndex){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid Accept encoding fmt");
        return IFX_SIP_FAILURE;
      }

      if(pxLang->ucNoOfAcceptParam >= IFX_SIP_MAX_ACCEPT_PARAM){
        pxSipError->eDecodeErr = IFX_SIP_MAX_ACCEPTPARAM_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Max Accept param exceeded");
        return IFX_SIP_FAILURE;
      }

      if(IFX_SIP_FindDelimWhenQuotesRPresent(pcTempStart,
                                              pcEndIndex,
                                              ';',
                                              &pcCurrPos,
                                              &pcTempEnd,
                                              pxSipError) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid Accept encoding fmt");
        return IFX_SIP_FAILURE;
      }

      if(IFX_SIP_DecodeAcceptParam(pcTempStart,pcTempEnd,&pxLang->
        axAcceptParam[pxLang->ucNoOfAcceptParam],pxSipError) ==
         IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
      pxLang->ucNoOfAcceptParam++;

      if(pcCurrPos == NULL){
        break;
      }
      else{
        pcTempStart = pcCurrPos + 1;
      }
    }
    while(1);
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_DecodeMParameter
*  Description  :  Decodes the M parameters
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/

e_IFX_SIP_Return
IFX_SIP_DecodeMParameter(IN  char8* pcStartIndex,
                          IN  char8* pcEndIndex,
                          OUT x_IFX_SIP_MParam* pxMParam,
                          OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcCurrPos, * pcTempStart, * pcTempEnd;
  int32 i;
  pcCurrPos = pcStartIndex;
  /* Remove leading white spaces */
  while((*pcCurrPos == ' ') || (*pcCurrPos == '\t')){
    pcCurrPos++;
    if(pcCurrPos > pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
      return IFX_SIP_FAILURE;
    }
  }
  pcTempStart = pcCurrPos;
  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'=');
  if(pcCurrPos == NULL){
    pxSipError->eDecodeErr = IFX_SIP_MPARAMFMT_INVALID;
    strcpy(pxSipError->szErrorDesc,"M param without Mvalue");
  }
  else{
    pcTempEnd = pcCurrPos;
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd < pcTempStart){
        return IFX_SIP_FAILURE;
      }
    }
    for(i = 0; (pcTempStart + i) < pcTempEnd; i++){
      if((*(pcTempStart + i) == ' ') || (*(pcTempStart + i) == '\t')){
        break;
      }
      if(isalnum(*(pcTempStart + i)) ||
         *(pcTempStart + i) == '-' ||
         *(pcTempStart + i) == '.' ||
         *(pcTempStart + i) == '!' ||
         *(pcTempStart + i) == '%' ||
         *(pcTempStart + i) == '*' ||
         *(pcTempStart + i) == '_' ||
         *(pcTempStart + i) == '+' ||
         *(pcTempStart + i) == '\'' ||
         *(pcTempStart + i) == '`' ||
         *(pcTempStart + i) == '~'){
        continue;
      }
      else{
        pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
        strcpy(pxSipError->szErrorDesc,"Invalid Token Present");
        return IFX_SIP_FAILURE;
      }
    }   
    /*Generic parameters with token and gen value */
    if((i >= IFX_SIP_MAX_TOKEN) || (i <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_MPARAM_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"M param excedded(m-attribute)");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxMParam->szMAttr,pcTempStart,i);
    pxMParam->szMAttr[i] = '\0';
    pcTempStart = pcCurrPos + 1; /* As it is pointing to = */
    /* Remove any Leading Spaces */
    while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
      pcTempStart++;
      if(pcTempStart > pcEndIndex){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
        strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
        return IFX_SIP_FAILURE;
      }
    }
    /* Remove any Trailing Spaces */
    pcTempEnd = pcEndIndex;
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd < pcTempStart){
        return IFX_SIP_FAILURE;
      }
    }
    if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
       ((pcTempEnd - pcTempStart) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_MPARAM_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"M param excedded(mvalue)");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxMParam->szMVal,pcTempStart,(pcTempEnd - pcTempStart));
    pxMParam->szMVal[(pcTempEnd - pcTempStart)] = '\0';
    /* Validate M value */
    if(pxMParam->szMVal[0] == 0x22){
      if(IFX_SIP_ValidateQuotedString(pxMParam->szMVal) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_QUOTEDSTRING;
        strcpy(pxSipError->szErrorDesc,"Invalid M-value in m parameter");
        return IFX_SIP_FAILURE;
      }
    }
    else{
      if(IFX_SIP_ValidateToken(pxMParam->szMVal) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
        strcpy(pxSipError->szErrorDesc,"Invalid M-value in m parameter");
        return IFX_SIP_FAILURE;
      }
    }
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeMType
*  Description  :  Decodes the M Type
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/

e_IFX_SIP_Return
IFX_SIP_DecodeMType(IN  char8* pcStartIndex,
                     IN  char8* pcEndIndex,
                     OUT x_IFX_SIP_MType* pxMType,
                     OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcCurrPos;
  uint32 i;
  pcCurrPos = pcStartIndex;

  i = pcEndIndex - pcStartIndex;

  if(strncmp(pcStartIndex,"text",IFX_SIP_MAX(i,strlen("text"))) == 0){
    pxMType->eMType = IFX_SIP_DISC_TYPE;
    pxMType->uxMType.xDiscreteType.eDiscrType = IFX_SIP_TEXT;
  }
  else if(strncmp(pcStartIndex,"image",IFX_SIP_MAX(i,strlen("image"))) == 0){
    pxMType->eMType = IFX_SIP_DISC_TYPE;
    pxMType->uxMType.xDiscreteType.eDiscrType = IFX_SIP_IMAGE;
  }
  else if(strncmp(pcStartIndex,"audio",IFX_SIP_MAX(i,strlen("audio"))) == 0){
    pxMType->eMType = IFX_SIP_DISC_TYPE;
    pxMType->uxMType.xDiscreteType.eDiscrType = IFX_SIP_AUDIO;
  }
  else if(strncmp(pcStartIndex,"video",IFX_SIP_MAX(i,strlen("video"))) == 0){
    pxMType->eMType = IFX_SIP_DISC_TYPE;
    pxMType->uxMType.xDiscreteType.eDiscrType = IFX_SIP_VIDE0;
  }
  else if(strncmp(pcStartIndex,
                  "application",
                  IFX_SIP_MAX(i,strlen("application"))) == 0){
         pxMType->eMType = IFX_SIP_DISC_TYPE;
         pxMType->uxMType.xDiscreteType.eDiscrType = IFX_SIP_APPLICATION;
  }
  else if(strncmp(pcStartIndex,"message",IFX_SIP_MAX(i,strlen("message"))) ==
          0){
         pxMType->eMType = IFX_SIP_COMP_TYPE;
         pxMType->uxMType.xCompositeType.eCompositeType = IFX_SIP_MESSAGE;
  }
  else if(strncmp(pcStartIndex,"multipart",IFX_SIP_MAX(i,strlen("multipart"))) ==
          0){
         pxMType->eMType = IFX_SIP_COMP_TYPE;
         pxMType->uxMType.xCompositeType.eCompositeType = IFX_SIP_MULTIPART;
  }
  else{
         /* Default extension token is being put in discrete type */
         pxMType->eMType = IFX_SIP_DISC_TYPE;
         pxMType->uxMType.xDiscreteType.eDiscrType = IFX_SIP_EXT_DISCR;
    if((i >= IFX_SIP_MAX_TOKEN) || (i <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_DISCEXT_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Discrete type Exceeded");
      return IFX_SIP_FAILURE;
    }
         strncpy(pxMType->uxMType.xDiscreteType.szDiscStr,pcStartIndex,i);
         pxMType->uxMType.xDiscreteType.szDiscStr[i] = '\0'; 

    if(IFX_SIP_ValidateToken(pxMType->uxMType.xDiscreteType.szDiscStr) ==
       IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
      strcpy(pxSipError->szErrorDesc,"Invalid MType");
      return IFX_SIP_FAILURE;
    }
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  x_IFX_SIP_MediaType
*  Description  :  Decodes the Media Type
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeMediaType(IN  char8* pcStartIndex,
                         IN  char8* pcEndIndex,
                         OUT x_IFX_SIP_MediaType* pxMedType,
                         OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcCurrPos, * pcTempStart, * pcTempEnd;
  pcTempStart = pcStartIndex;
  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'/');
  if(pcCurrPos == NULL){
    pxSipError->eDecodeErr = IFX_SIP_MEDIATYPEFMT_INVALID;
    strcpy(pxSipError->szErrorDesc,"Media Type Format Invalid");
    return IFX_SIP_FAILURE;
  }
  else{
    /* Remove any Trailing spaces */
    pcTempEnd = pcCurrPos;
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd < pcTempStart){
        return IFX_SIP_FAILURE;
      }
    }
    if(IFX_SIP_DecodeMType(pcTempStart,
                            pcTempEnd,
                            &pxMedType->xMType,
                            pxSipError) == IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
    pcTempStart = pcCurrPos + 1;/* As it points to / */
    /* Remove any Spaces after / */
    while(*pcTempStart == ' ' || *pcTempStart == '\t'){
      pcTempStart++;
      if(pcTempStart > pcEndIndex){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid message format");
        return IFX_SIP_FAILURE;
      }
    }
    pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
    if(pcCurrPos == NULL){
      pcTempEnd = pcEndIndex;
    }
    else{
      pcTempEnd = pcCurrPos;
    }
    /* Remove any Trailing Spaces */
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd < pcTempStart){
        return IFX_SIP_FAILURE;
      }
    }
    if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
       ((pcTempEnd - pcTempStart) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_MEDIASUBTYPE_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Media sub Type exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxMedType->szMSubType,pcTempStart,(pcTempEnd - pcTempStart));
    pxMedType->szMSubType[(pcTempEnd - pcTempStart)] = '\0';
    /* Validate MSubType */
    if(IFX_SIP_ValidateToken(pxMedType->szMSubType) == IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
      strcpy(pxSipError->szErrorDesc,"Invalid M-SubType");
      return IFX_SIP_FAILURE;
    }
    if(pcCurrPos != NULL){
      pcTempStart = pcCurrPos + 1;
      do{
        /* Remove any Leading white Spaces */
        while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
          pcTempStart++;

          if(pcTempStart > pcEndIndex){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
            strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
            return IFX_SIP_FAILURE;
          }
        }
        if(pxMedType->ucNoOfMParam >= IFX_SIP_MAX_MPARAM){
          pxSipError->eDecodeErr = IFX_SIP_MAXMPARAM_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Max Mparam exceeded");
          return IFX_SIP_FAILURE;
        }
        /* To take care of delimiters within quotes */
        /* Check for the delimiter */
        if(IFX_SIP_FindDelimWhenQuotesRPresent(pcTempStart,
                                                pcEndIndex,
                                                ';',
                                                &pcCurrPos,
                                                &pcTempEnd,
                                                pxSipError) ==
           IFX_SIP_FAILURE){
          return IFX_SIP_FAILURE;
        }

        if(IFX_SIP_DecodeMParameter(pcTempStart,pcTempEnd,&pxMedType->
           axMParam[pxMedType->ucNoOfMParam], pxSipError) == IFX_SIP_FAILURE){
          return IFX_SIP_FAILURE;
        }
        pxMedType->ucNoOfMParam++;
        if(pcCurrPos == NULL){
          break;
        }
        else{
          pcTempStart = pcCurrPos + 1;
        }
      }
      while(1);
    }
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_DecodeComment
*  Description  :  Decodes Comment
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/

e_IFX_SIP_Return
IFX_SIP_DecodeComment(IN  char8** pcStartIndex,
                       IN  char8* pcEndIndex,
                       OUT char8* pszComment,
                       OUT x_IFX_SIP_Error* pxSipError)
{
  uchar8* pcCurrPos;
  int32 iCount = 1;
  pcCurrPos = (uchar8 *) (*pcStartIndex + 1);
  while((pcCurrPos < (uchar8 *) pcEndIndex)){
    if((*pcCurrPos >= 0x21 && *pcCurrPos <= 0x27) ||
       (*pcCurrPos >= 0x2a && *pcCurrPos <= 0x5b) ||
       (*pcCurrPos >= 0x5d && *pcCurrPos <= 0x7e) ||
       (*pcCurrPos >= 0xc0 && *pcCurrPos <= 0xdf) ||
       (*pcCurrPos >= 0xe0 && *pcCurrPos <= 0xef) ||
       (*pcCurrPos >= 0xf0 && *pcCurrPos <= 0xfd) ||
       (*pcCurrPos == '\"') ||
       (*pcCurrPos == 0x21) ||
       (*pcCurrPos == ' ') ||
       (*pcCurrPos == '\t') ||
       (*pcCurrPos >= 0x5d && *pcCurrPos <= 0x7e)){
      pcCurrPos++;
      continue;
    }
    else if(*pcCurrPos == '('){
      iCount++;
      pcCurrPos++;
    }
    else if(*pcCurrPos == ')'){
      iCount--;
      pcCurrPos++;
      if(iCount == 0){
        break;
      }
    }
    else{
      pxSipError->eDecodeErr = IFX_SIP_INVALID_COMMENT;
      strcpy(pxSipError->szErrorDesc,"Error in comment grammer");
      return IFX_SIP_FAILURE;
    }
  }
  pcCurrPos--;
  if(((pcCurrPos - (uchar8 *) (*pcStartIndex + 1)) >= IFX_SIP_MAX_TOKEN) ||
     ((pcCurrPos - (uchar8 *) (*pcStartIndex - 1)) <= 0)){
    pxSipError->eDecodeErr = IFX_SIP_COMMENT_EXCEEDED;
    strcpy(pxSipError->szErrorDesc,"comment Buffer Exceeded");
    return IFX_SIP_FAILURE;
  }
  strncpy(pszComment,
          (*pcStartIndex + 1),
          (pcCurrPos - (uchar8 *) (*pcStartIndex + 1)));
  pszComment[(pcCurrPos - (uchar8 *) (*pcStartIndex + 1))] = '\0';
  *pcStartIndex = pcCurrPos + 1;
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeMediaRangeType
*  Description  :  Decodes M-Type in Media Range
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding 
*  Notes        : 
*********************************************************************/

e_IFX_SIP_Return
IFX_SIP_DecodeMediaRangeType(IN  char8* pcStartIndex,
                              IN  char8* pcEndIndex,
                              OUT x_IFX_SIP_MediaRange* pxMediaRange,
                              OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcCurrPos, * pcTempStart, * pcTempEnd;
  pcTempStart = pcStartIndex;

  if(((pcEndIndex - pcTempStart) == 3) &&
     (*pcTempStart == '*') &&
     (*(pcTempStart + 1) == '/') &&
     (*(pcTempStart + 2) == '*')){
    pxMediaRange->ucChoiceOnUnion = IFX_SIP_MR_WILD_CHAR;
  }
  else{
    pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'/');
    if(pcCurrPos != NULL){
      pcTempEnd = pcCurrPos;

      /* Remove any Trailing Spaces */
      while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
        pcTempEnd--;
        if(pcTempEnd < pcTempStart){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid message format");
          return IFX_SIP_FAILURE;
        }
      }

      pcCurrPos++; /* As it points to / */

      /* Remove any Leading white spaces */
      while((*pcCurrPos == ' ') || (*pcCurrPos == '\t')){
        pcCurrPos++;
        if(pcCurrPos > pcEndIndex){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid Accept msg Fmt");
          return IFX_SIP_FAILURE;
        }
      }

      /* Check if it is star and if its only char present */
      if((*pcCurrPos == '*') && ((pcEndIndex - pcCurrPos) == 1)){
        pxMediaRange->ucChoiceOnUnion = IFX_SIP_MTYPE_WITH_WILDCHAR;
        if(IFX_SIP_DecodeMType(pcTempStart,
                                pcTempEnd,
                                &pxMediaRange->uxMediaType.xMtypeWithWildChar,
                                pxSipError) == IFX_SIP_FAILURE){
          return IFX_SIP_FAILURE;
        }
      }
      else{
        pxMediaRange->ucChoiceOnUnion = IFX_SIP_MTYPE_WITH_MSUBTYPE;
        if(IFX_SIP_DecodeMType(pcTempStart, pcTempEnd, &pxMediaRange->
           uxMediaType.xMtypeWithMSubType.xMtype, pxSipError) ==
           IFX_SIP_FAILURE){
          return IFX_SIP_FAILURE;
        }

        if(((pcEndIndex - pcCurrPos) >= IFX_SIP_MAX_TOKEN) ||
           ((pcEndIndex - pcCurrPos) <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_MEDIASUBTYPE_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Media sub Type exceeded");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxMediaRange->uxMediaType.xMtypeWithMSubType.
          szMSubType,pcCurrPos,(pcEndIndex - pcCurrPos));
        pxMediaRange->uxMediaType.xMtypeWithMSubType.
                          szMSubType[(pcEndIndex - pcCurrPos)] = '\0';

        /* Validate MSubType */
        if(IFX_SIP_ValidateToken(pxMediaRange->uxMediaType.
          xMtypeWithMSubType.szMSubType) == IFX_SIP_FAILURE){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
          strcpy(pxSipError->szErrorDesc,"Invalid M-SubType");
          return IFX_SIP_FAILURE;
        }
      }
    }
    else{
      pxSipError->eDecodeErr = IFX_SIP_MEDIARANGEFMT_INVALID;
      strcpy(pxSipError->szErrorDesc,"Media Range format invalid");
      return IFX_SIP_FAILURE;
    }
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeMediaRange
*  Description  :  Decodes Media Range
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding 
*  Notes        : 
*********************************************************************/

e_IFX_SIP_Return
IFX_SIP_DecodeMediaRange(IN  char8* pcStartIndex,
                          IN  char8* pcEndIndex,
                          OUT x_IFX_SIP_MediaRange* pxMediaRange,
                          OUT x_IFX_SIP_Error* pxSipError)
{
  char* pcTempStart, * pcCurrPos;
  int32 iCount;
  pcTempStart = pcStartIndex;
  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
  if(pcCurrPos == NULL){
    if(IFX_SIP_DecodeMediaRangeType(pcTempStart,
                                     pcEndIndex,
                                     pxMediaRange,
                                     pxSipError) == IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
  }
  else{
    if(IFX_SIP_DecodeMediaRangeType(pcTempStart,
                                     pcCurrPos,
                                     pxMediaRange,
                                     pxSipError) == IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
    pcTempStart = pcCurrPos + 1;/* As it is pointing to ; */
    do{
      if(pxMediaRange->ucNoOfMparam >= IFX_SIP_MAX_MPARAM){
        pxSipError->eDecodeErr = IFX_SIP_MAXMPARAM_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Max Mparam exceeded");
        return IFX_SIP_FAILURE;
      }
      iCount = pxMediaRange->ucNoOfMparam;
      pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
      if(pcCurrPos == NULL){
        if(IFX_SIP_DecodeMParameter(pcTempStart,
                                     pcEndIndex,
                                     &pxMediaRange->axMparam[iCount],
                                     pxSipError) == IFX_SIP_FAILURE){
          return IFX_SIP_FAILURE;
        }
        pxMediaRange->ucNoOfMparam++; 
        break;
      }
      else{
        if(IFX_SIP_DecodeMParameter(pcTempStart,
                                     pcCurrPos,
                                     &pxMediaRange->axMparam[iCount],
                                     pxSipError) == IFX_SIP_FAILURE){
          return IFX_SIP_FAILURE;
        }
        pxMediaRange->ucNoOfMparam++; 
        pcTempStart = pcCurrPos + 1;
      }
    }
    while(1);
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeAcceptRange
*  Description  :  Decodes Accept Range
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding 
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeAcceptRange(IN  char8* pcStartIndex,
                           IN  char8* pcEndIndex,
                           OUT x_IFX_SIP_AcceptRange* pxAcceptRange,
                           OUT x_IFX_SIP_Error* pxSipError)
{
  char* pcTempStart, * pcCurrPos, * pcTempEnd;
  int32 iCount;
  pcTempStart = pcStartIndex;

  /* Search for the delimiters */
  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
  if(pcCurrPos == NULL){
    if(IFX_SIP_DecodeMediaRange(pcTempStart,pcEndIndex,&pxAcceptRange->
      xMediaRange,pxSipError) == IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
  }
  else{
    pcTempEnd = pcCurrPos;

    /* Remove any Trailing Spaces */
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd < pcTempStart){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid message format");
        return IFX_SIP_FAILURE;
      }
    }

    if(IFX_SIP_DecodeMediaRangeType(pcTempStart,pcTempEnd,&pxAcceptRange->
      xMediaRange,pxSipError) == IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
    pcTempStart = pcCurrPos + 1;/* As it is pointing to ; */

    do{
      /* Remove Leading white Spaces */
      while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
        pcTempStart++;
        if(pcTempStart > pcEndIndex){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
          strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
          return IFX_SIP_FAILURE;
        }
      }

      if(pxAcceptRange->ucNoOfAcceptParam >= IFX_SIP_MAX_ACCEPT_PARAM){
        pxSipError->eDecodeErr = IFX_SIP_MAX_ACCEPTPARAM_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Max Accept param exceeded");
        return IFX_SIP_FAILURE;
      }
      iCount = pxAcceptRange->ucNoOfAcceptParam;

      /* Check for the delimiters */
      if(IFX_SIP_FindDelimWhenQuotesRPresent(pcTempStart,
                                              pcEndIndex,
                                              ';',
                                              &pcCurrPos,
                                              &pcTempEnd,
                                              pxSipError) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }

      if(IFX_SIP_DecodeAcceptParam(pcTempStart,
                                    pcTempEnd,
                                    &pxAcceptRange->axAcceptParam[iCount],
                                    pxSipError) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
      pxAcceptRange->ucNoOfAcceptParam++;


      if(pcCurrPos == NULL){
        break;
      }
      else{
        pcTempStart = pcCurrPos + 1;
      }
    }
    while(1);
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_DecodeSegment
*  Description  :  Decodes Segment
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding 
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeSegment(IN  char8* pcStartIndex,
                       IN  char8* pcEndIndex,
                       OUT x_IFX_SIP_Segment* pxSeg,
                       OUT x_IFX_SIP_Error* pxSipError)
{
  char* pcTempStart, * pcCurrPos;
  int32 iCount;
  pcTempStart = pcStartIndex;
  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
  if(pcCurrPos == NULL){
    if(((pcEndIndex - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
       ((pcEndIndex - pcTempStart) < 0)){
      pxSipError->eDecodeErr = IFX_SIP_SEGMENT_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"pchar in Segment exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxSeg->szPchar,pcTempStart,(pcEndIndex - pcTempStart));
    pxSeg->szPchar[(pcEndIndex - pcTempStart)] = '\0';  
    if(IFX_SIP_ValidatePChar(pxSeg->szPchar) == IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_PCHAR;
      strcpy(pxSipError->szErrorDesc,"Invalid Pchar");
      return IFX_SIP_FAILURE;
    }
  }
  else{
    if(((pcCurrPos - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
       ((pcCurrPos - pcTempStart) < 0)){
      pxSipError->eDecodeErr = IFX_SIP_SEGMENT_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"pchar in Segment exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxSeg->szPchar,pcTempStart,(pcCurrPos - pcTempStart));
    pxSeg->szPchar[(pcCurrPos - pcTempStart)] = '\0';
    /* TBF: Validate PChar */
    if(IFX_SIP_ValidatePChar(pxSeg->szPchar) == IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_PCHAR;
      strcpy(pxSipError->szErrorDesc,"Invalid Pchar");
      return IFX_SIP_FAILURE;
    }
    pcTempStart = pcCurrPos + 1;/* As it is pointing to ; */
    do{
      if(pxSeg->ucNoOfParam >= IFX_SIP_MAX_MPARAM){
        pxSipError->eDecodeErr = IFX_SIP_MAXSEG_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Max Segments exceeded");
        return IFX_SIP_FAILURE;
      }
      iCount = pxSeg->ucNoOfParam;
      pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
      if(pcCurrPos == NULL){
        if(((pcEndIndex - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
           ((pcEndIndex - pcTempStart) <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_SEGMENT_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"param in Segment exceeded");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxSeg->aszParam[iCount],pcTempStart,(pcEndIndex - pcTempStart));
        pxSeg->aszParam[iCount][(pcEndIndex - pcTempStart)] = '\0';
        if(IFX_SIP_ValidatePChar(pxSeg->aszParam[iCount]) == IFX_SIP_FAILURE){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_PCHAR;
          strcpy(pxSipError->szErrorDesc,"Invalid Pchar");
          return IFX_SIP_FAILURE;
        }
        pxSeg->ucNoOfParam++;
        break;
      }
      else{
        if(((pcCurrPos - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
           ((pcCurrPos - pcTempStart) <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_SEGMENT_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"param in Segment exceeded");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxSeg->aszParam[iCount],pcTempStart,(pcCurrPos - pcTempStart));
        pxSeg->aszParam[iCount][(pcCurrPos - pcTempStart)] = '\0';
        if(IFX_SIP_ValidatePChar(pxSeg->aszParam[iCount]) == IFX_SIP_FAILURE){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_PCHAR;
          strcpy(pxSipError->szErrorDesc,"Invalid Pchar");
          return IFX_SIP_FAILURE;
        }
        pxSeg->ucNoOfParam++;
        pcTempStart = pcCurrPos + 1;
      }
    }
    while(1);
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodePathSegment
*  Description  :  Decodes Path Segments
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding 
*  Notes        : 
*********************************************************************/

e_IFX_SIP_Return
IFX_SIP_DecodePathSegment(IN  char8* pcStartIndex,
                           IN  char8* pcEndIndex,
                           OUT x_IFX_SIP_PathSegments* pxPathSeg,
                           OUT x_IFX_SIP_Error* pxSipError)
{
  char* pcTempStart, * pcCurrPos;
  int32 iCount;
  pcTempStart = pcStartIndex;
  do{
    if(pxPathSeg->ucNoOfSegment >= IFX_SIP_MAX_SEGMENT){
      pxSipError->eDecodeErr = IFX_SIP_MAXSEG_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Max Segments exceeded");
      return IFX_SIP_FAILURE;
    }
    iCount = pxPathSeg->ucNoOfSegment;
    pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'/');
    if(pcCurrPos == NULL){
      if(IFX_SIP_DecodeSegment(pcTempStart,
                                pcEndIndex,
                                &pxPathSeg->axSegment[iCount],
                                pxSipError) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
      pxPathSeg->ucNoOfSegment++; 
      break;
    }
    else{
      if(IFX_SIP_DecodeSegment(pcTempStart,
                                pcCurrPos,
                                &pxPathSeg->axSegment[iCount],
                                pxSipError) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
      pxPathSeg->ucNoOfSegment++;
      pcTempStart = pcCurrPos + 1;
    }
  }
  while(1);
  return IFX_SIP_SUCCESS;
}


/******************************************************************
*  Function Name:  IFX_SIP_DecodeAbsoluteURI
*  Description  :  Decodes Absolute URI
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding 
*  Notes        : 
*********************************************************************/

e_IFX_SIP_Return
IFX_SIP_DecodeAbsoluteURI(IN  char8* pcStartIndex,
                           IN  char8* pcEndIndex,
                           OUT x_IFX_SIP_AbsoluteURI* pxAbsUri,
                           OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcCurrPos, * pcTempEnd;
  pcTempStart = pcStartIndex;
  /* Remove any Leading Spaces */
  while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
    pcTempStart++;
    if(pcTempStart > pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Sip message format");
      return IFX_SIP_FAILURE;
    }
  }
  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,':');
  if(pcCurrPos != NULL){
    if(((pcCurrPos - pcTempStart) >= IFX_SIP_MAX_SCHEME) ||
       ((pcCurrPos - pcTempStart) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_ABSURISCHEME_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Scheme in Absolute URI exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxAbsUri->ucScheme,pcTempStart,(pcCurrPos - pcTempStart));
    pxAbsUri->ucScheme[(pcCurrPos - pcTempStart)] = '\0';
    if(IFX_SIP_ValidateScheme(pxAbsUri->ucScheme) == IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_SCHEME;
      strcpy(pxSipError->szErrorDesc,"Invalid ABS URI scheme");
      return IFX_SIP_FAILURE;
    }
    pcTempStart = pcCurrPos + 1;
    if(*pcTempStart == '/'){
      /* Heir-Part present */
      pcTempEnd = IFX_SIP_strchr(pcTempStart,pcEndIndex,'?');
      if(pcTempEnd == NULL){
        pxAbsUri->uxHierOpaquePart.xHierPart.szQuery[0] = '\0';
        pcTempEnd = pcEndIndex;
      }
      pxAbsUri->ePartType = IFX_SIP_HIER_PART;
      if(*(pcTempStart + 1) == '/'){
        char8* pcTemp;
        /* Presence of NetPath */
        pcTempStart += 2;/*As it is pointing to / */
        pxAbsUri->uxHierOpaquePart.xHierPart.ePathType = IFX_SIP_NETPATH;
        pcTemp = IFX_SIP_strchr(pcTempStart,pcTempEnd,'/');
        if(pcTemp != NULL){
          if(((pcTemp - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
             ((pcTemp - pcTempStart) <= 0)){
            pxSipError->eDecodeErr = IFX_SIP_ABSURIAUTH_EXCEEDED;
            strcpy(pxSipError->szErrorDesc,
                   "Authority in Absolute URI exceeded");
            return IFX_SIP_FAILURE;
          }
          strncpy(pxAbsUri->uxHierOpaquePart.xHierPart.uxPathType.
            xNetPath.xAuthority.szAuthority,pcTempStart,(pcTemp - pcTempStart));
          pxAbsUri->uxHierOpaquePart.xHierPart.uxPathType.xNetPath.
          xAuthority.szAuthority[(pcTemp - pcTempStart)] = '\0';
          /* Validate Authority */
          if(IFX_SIP_ValidateRegName(pxAbsUri->uxHierOpaquePart.
            xHierPart.uxPathType.xNetPath.xAuthority.szAuthority) ==
             IFX_SIP_FAILURE){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_REGNAME;
            strcpy(pxSipError->szErrorDesc,"Invalid Authority");
            return IFX_SIP_FAILURE;
          }
          /* Presence of absolute path */
          pxAbsUri->uxHierOpaquePart.xHierPart.uxPathType.xNetPath.
          ucOptions = ABS_PATH;
          if(IFX_SIP_DecodePathSegment((pcTemp + 1),pcTempEnd,&pxAbsUri->
             uxHierOpaquePart.xHierPart.uxPathType.xNetPath.xAbsPath,
             pxSipError) == IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
        }
        else{
          if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
             ((pcTempEnd - pcTempStart) <= 0)){
            pxSipError->eDecodeErr = IFX_SIP_ABSURIAUTH_EXCEEDED;
            strcpy(pxSipError->szErrorDesc,
                   "Authority in Absolute URI exceeded");
            return IFX_SIP_FAILURE;
          }
          strncpy(pxAbsUri->uxHierOpaquePart.xHierPart.uxPathType.
            xNetPath.xAuthority.szAuthority,
                  pcTempStart,
                  (pcTempEnd - pcTempStart));
          pxAbsUri->uxHierOpaquePart.xHierPart.uxPathType.xNetPath.
          xAuthority.szAuthority[(pcTempEnd - pcTempStart)] = '\0';         
          /* Validate Authority */
          if(IFX_SIP_ValidateRegName(pxAbsUri->uxHierOpaquePart.
            xHierPart.uxPathType.xNetPath.xAuthority.szAuthority) ==
             IFX_SIP_FAILURE){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_REGNAME;
            strcpy(pxSipError->szErrorDesc,"Invalid Authority");
            return IFX_SIP_FAILURE;
          }
        }
      }
      else{
        /* Presence of absPath */
        pxAbsUri->uxHierOpaquePart.xHierPart.ePathType = IFX_SIP_ABSPATH;  
        if(IFX_SIP_DecodePathSegment((pcTempStart + 1),pcTempEnd,&pxAbsUri->
           uxHierOpaquePart.xHierPart.uxPathType.xAbsPath, pxSipError) ==
           IFX_SIP_FAILURE){
          return IFX_SIP_FAILURE;
        }
      }
      if(pcTempEnd != pcEndIndex){
        /* Presence of Query */
        if(((pcEndIndex - (pcTempEnd + 1)) >= IFX_SIP_MAX_QUERY) ||
           ((pcEndIndex - (pcTempEnd + 1)) <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_ABSURIQUERY_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Query in Absolute URI exceeded");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxAbsUri->uxHierOpaquePart.xHierPart.szQuery,
                (pcTempEnd + 1),
                (pcEndIndex - (pcTempEnd + 1)));
        pxAbsUri->uxHierOpaquePart.xHierPart.
                           szQuery[(pcEndIndex - (pcTempEnd + 1))] = '\0';
        if(IFX_SIP_ValidateUric(pxAbsUri->uxHierOpaquePart.xHierPart.
          szQuery) == IFX_SIP_FAILURE){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_URIC;
          strcpy(pxSipError->szErrorDesc,"Invalid Query");
          return IFX_SIP_FAILURE;
        }
      }
    }
    else{
      /* opaque Part is Present */

      pxAbsUri->ePartType = IFX_SIP_OPAQUE_PART;
      if(((pcEndIndex - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
         ((pcEndIndex - pcTempStart) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_OPAQUE_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Opaque Part in Absolute URI exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxAbsUri->uxHierOpaquePart.szOpaquePart, pcTempStart,
              (pcEndIndex - pcTempStart));
      pxAbsUri->uxHierOpaquePart.
                         szOpaquePart[(pcEndIndex - pcTempStart)] = '\0';
      if(IFX_SIP_ValidateUric(pxAbsUri->uxHierOpaquePart.szOpaquePart) ==
         IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_URIC;
        strcpy(pxSipError->szErrorDesc,"Invalid URIC");
        return IFX_SIP_FAILURE;
      }
    }
  }
  else{
    /* Invalid URI Format */
    pxSipError->eDecodeErr = IFX_SIP_ABSURIFMT_INVALID;
    strcpy(pxSipError->szErrorDesc,"Invalid Absolute URI Format");
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeAlertParam
*  Description  :  Decodes the Alert parameters
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        :   
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeAlertParam(IN  char8* pcStartIndex,
                          IN  char8* pcEndIndex,
                          OUT x_IFX_SIP_AlertParam* pxAlert,
                          OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcCurrPos, * pcTempEnd;
  pcTempStart = pcStartIndex;
  if((*pcTempStart != '<')){
    pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
    strcpy(pxSipError->szErrorDesc,"Invalid Message format- Alert Param");
    return IFX_SIP_FAILURE;
  }
  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'>');
  if(pcCurrPos == NULL){
    pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
    strcpy(pxSipError->szErrorDesc,"Invalid Message format- Alert Param");
    return IFX_SIP_FAILURE;
  }
  else{
    pcTempEnd = pcCurrPos;
    /* Call Absolute URI decode Function */
    if(IFX_SIP_DecodeAbsoluteURI((pcTempStart + 1),pcTempEnd,&pxAlert->
      xAbsoluteUri,pxSipError) == IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
  }

  pcTempStart = pcCurrPos + 1;
  /* Remove any Leading white spaces */
  while(*pcTempStart == ' ' || *pcTempStart == '\t'){
    pcTempStart++;
    if(pcTempStart > pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Message format- Alert Param");
      return IFX_SIP_FAILURE;
    }
  }

  /* As spaces are allowed afer raquout */
  if(pcTempStart == pcEndIndex){
    return IFX_SIP_SUCCESS;
  }

  if(*pcTempStart != ';'){
    pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
    strcpy(pxSipError->szErrorDesc,"Invalid Message format- Alert Param");
    return IFX_SIP_FAILURE;
  }
  else{
    pcTempStart++;/* As it is pointing to ; */
    do{
      /* Remove any leading white spaces */
      while((pcTempStart < pcEndIndex) &&
            (*pcTempStart == ' ' || *pcTempStart == '\t')){
        pcTempStart++;
      }
      if(pcTempStart >= pcEndIndex){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid Msg fmt- Call Info");
        return IFX_SIP_FAILURE;
      }

      if(pxAlert->ucNoOfGenParam >= IFX_SIP_MAX_INFO_PARAM){
        pxSipError->eDecodeErr = IFX_SIP_MAXGENPARAM_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Max Gen param Param exceeded");
        return IFX_SIP_FAILURE;
      }

      /* Handling delimiters within quotes */
      if(IFX_SIP_FindDelimWhenQuotesRPresent(pcTempStart,
                                              pcEndIndex,
                                              ';',
                                              &pcCurrPos,
                                              &pcTempEnd,
                                              pxSipError) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }

      if(IFX_SIP_DecodeGenericParams(pcTempStart,pcTempEnd,&pxAlert->
      axGenericParam[pxAlert->ucNoOfGenParam],pxSipError) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }

      pxAlert->ucNoOfGenParam++;  

      if(pcCurrPos == NULL){
        break;
      }
      else{
        pcTempStart = pcCurrPos + 1;
      }
    }
    while(1);
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeURI
*  Description  :  Decodes the Request URI value
*  Input Values :  Start and end indices to Request URI
*  Output Values:  Fills the structure passed, error info filled in case
*                  of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/

e_IFX_SIP_Return
IFX_SIP_DecodeURI(IN char8* pcStartIndex,
                   IN char8* pcEndIndex,
                   OUT x_IFX_SIP_ReqURI* pxReqUri,
                   OUT x_IFX_SIP_Error* pxSipError)
{
  char* pcTempStart, * pcTempEnd, * pcCurrPos;

  /* copy pcStartIndex and pcEndIndex into temporary pointers */
  pcTempStart = pcStartIndex;
  pcTempEnd = pcEndIndex;
  pcCurrPos = pcStartIndex; 

  /* Remove any Trailing Spaces- for handling spces in addrspec */
  while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
    pcTempEnd--;
    if(pcTempEnd < pcTempStart){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
      return IFX_SIP_FAILURE;
    }
  }

  if(IFX_SIP_strncasecmp(pcTempStart,"sip:",strlen("sip:")) == 0){
    pxReqUri->eUriType = IFX_SIP_SIP_URI;
    pcCurrPos += 4;
    pcTempStart = pcCurrPos;
    if(IFX_SIP_DecodeSipUri(pcTempStart,
                             pcTempEnd,
                             &(pxReqUri->uxUriType.xSipURI),
                             pxSipError) == IFX_SIP_FAILURE){
      /* Raise Decode Error */
      return IFX_SIP_FAILURE;
    }
  }
  else if(IFX_SIP_strncasecmp(pcTempStart,"sips:",strlen("sips:")) == 0){
    pxReqUri->eUriType = IFX_SIP_SIPS_URI;
    pcTempStart = pcCurrPos = pcCurrPos + 5;
    if(IFX_SIP_DecodeSipUri(pcTempStart,
                             pcTempEnd,
                             &(pxReqUri->uxUriType.xSipsURI),
                             pxSipError) == IFX_SIP_FAILURE){
      /* Raise Decode Error */
      return IFX_SIP_FAILURE;
    }
  }
  else{
    pxReqUri->eUriType = IFX_SIP_ABSOLUTE_URI;
    if(IFX_SIP_DecodeAbsoluteURI(pcTempStart,pcTempEnd,&pxReqUri->
      uxUriType.xAbsoluteURI,pxSipError) == IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeInfoParam
*  Description  :  Decodes the Info Params of call Info
*  Input Values :  Start and end indices 
*  Output Values:  Fills the structure passed, error info filled in
*                  case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/

e_IFX_SIP_Return
IFX_SIP_DecodeInfoParam(IN char8* pcStartIndex,
                         IN char8* pcEndIndex,
                         OUT x_IFX_SIP_InfoParam* pxInfo,
                         OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcCurrPos, * pcTempEnd;
  uint32 i;
  pcTempStart = pcStartIndex;

  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'=');
  if(pcCurrPos == NULL){
    pcTempEnd = pcEndIndex;
  }
  else{
    pcTempEnd = pcCurrPos;
  }

  /* Remove any Trailing Spaces */
  while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
    pcTempEnd--;
    if(pcTempEnd < pcTempStart){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid message format");
      return IFX_SIP_FAILURE;
    }
  }
  i = pcTempEnd - pcTempStart;

  if(strncmp(pcTempStart,"purpose",IFX_SIP_MAX(i,strlen("purpose"))) == 0){
    pxInfo->ucChoiceOnUnion = IFX_SIP_PURPOSE;
    pcTempStart = pcCurrPos + 1;

    /* Remove any Leading white spaces */
    while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
      pcTempStart++;
      if(pcTempStart > pcEndIndex){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid message format");
        return IFX_SIP_FAILURE;
      }
    }

    i = pcEndIndex - pcTempStart;

    if(strncmp(pcTempStart,"icon",IFX_SIP_MAX(i,strlen("icon"))) == 0){
      pxInfo->uxInfoParamType.xPurposeType.ucPurposeType = IFX_SIP_ICON;
      strcpy(pxInfo->uxInfoParamType.xPurposeType.szToken,"icon");
    }
    else if(strncmp(pcTempStart,"info",IFX_SIP_MAX(i,strlen("info"))) == 0){
      pxInfo->uxInfoParamType.xPurposeType.ucPurposeType = IFX_SIP_INFO;
      strcpy(pxInfo->uxInfoParamType.xPurposeType.szToken,"info");
    }
    else if(strncmp(pcTempStart,"card",IFX_SIP_MAX(i,strlen("card"))) == 0){
      pxInfo->uxInfoParamType.xPurposeType.ucPurposeType = IFX_SIP_CARD;
      strcpy(pxInfo->uxInfoParamType.xPurposeType.szToken,"card");
    }
    else{
      pxInfo->uxInfoParamType.xPurposeType.ucPurposeType = IFX_SIP_TOKEN;
      if((i >= IFX_SIP_MAX_TOKEN) || (i <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_PURPOSETOKEN_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Purpose token exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxInfo->uxInfoParamType.xPurposeType.szToken,pcTempStart,i);
      pxInfo->uxInfoParamType.xPurposeType.szToken[i] = '\0';
      /* Validate Token */
      if(IFX_SIP_ValidateToken(pxInfo->uxInfoParamType.xPurposeType.
        szToken) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
        strcpy(pxSipError->szErrorDesc,"Invalid Purpose Token");
        return IFX_SIP_FAILURE;
      }
    }
  }
  else{
    pxInfo->ucChoiceOnUnion = IFX_SIP_GENERIC_PARAM_INFO;
    if(IFX_SIP_DecodeGenericParams(pcTempStart,pcEndIndex,&pxInfo->
      uxInfoParamType.xGenericParam,pxSipError) == IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeInfo
*  Description  :  Decodes the Info
*  Input Values :  Start and End indices 

*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        :   
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeInfo(IN  char8* pcStartIndex,
                    IN  char8* pcEndIndex,
                    OUT x_IFX_SIP_Info* pxInfo,
                    OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcCurrPos, * pcTempEnd;
  pcTempStart = pcStartIndex;
  if((*pcTempStart != '<')){
    pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
    strcpy(pxSipError->szErrorDesc,"Invalid Message format- Call Info");
    return IFX_SIP_FAILURE;
  }
  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'>');
  if(pcCurrPos == NULL){
    pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
    strcpy(pxSipError->szErrorDesc,"Invalid Message format- Call Info");
    return IFX_SIP_FAILURE;
  }
  else{
    pcTempEnd = pcCurrPos;
    /* Call Absolute URI decode Function */
    if(IFX_SIP_DecodeAbsoluteURI((pcTempStart + 1),pcTempEnd,&pxInfo->
      xAbsUri,pxSipError) == IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
  }

  if((pcTempEnd + 1) == pcEndIndex){
    return IFX_SIP_SUCCESS;
  }

  pcTempStart = pcCurrPos + 1;
  /* Remove any Leading white spaces */
  while(*pcTempStart == ' ' || *pcTempStart == '\t'){
    pcTempStart++;
    if(pcTempStart > pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Message format- Call Info");
      return IFX_SIP_FAILURE;
    }
  }

  if(pcTempStart == pcEndIndex){
    return IFX_SIP_SUCCESS;
  }

  if(*pcTempStart != ';'){
    pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
    strcpy(pxSipError->szErrorDesc,"Invalid Message format- Call Info");
    return IFX_SIP_FAILURE;
  }
  else{
    pcTempStart++;/* As it is pointing to ; */
    do{
      /* Remove any leading white spaces */
      while(*pcTempStart == ' ' || *pcTempStart == '\t'){
        pcTempStart++;
        if(pcTempStart > pcEndIndex){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid Message format- Call Info");
          return IFX_SIP_FAILURE;
        }
      }

      if(pxInfo->ucNoOfInfoParam >= IFX_SIP_MAX_INFO_PARAM){
        pxSipError->eDecodeErr = IFX_SIP_MAXINFOPARAM_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Max Info Param exceeded");
        return IFX_SIP_FAILURE;
      }

      /* Handling of , within quotes for genvalue in generic params */
      if(IFX_SIP_FindDelimWhenQuotesRPresent(pcTempStart,
                                              pcEndIndex,
                                              ';',
                                              &pcCurrPos,
                                              &pcTempEnd,
                                              pxSipError) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }

      if(IFX_SIP_DecodeInfoParam(pcTempStart,pcTempEnd,&pxInfo->
        axInfoParam[pxInfo->ucNoOfInfoParam],pxSipError) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
      pxInfo->ucNoOfInfoParam++;
      if(pcCurrPos == NULL){
        break;
      }
      else{
        pcTempStart = pcCurrPos + 1;
      }
    }
    while(1);
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeErrorURI
*  Description  :  Decodes the Error URI parameters
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        :   
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeErrorURI(IN  char8* pcStartIndex,
                        IN  char8* pcEndIndex,
                        OUT x_IFX_SIP_ErrorUri* pxErr,
                        OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcCurrPos, * pcTempEnd;
  pcTempStart = pcStartIndex;
  while((*pcTempStart != '<')){
    pcTempStart++;
    if(pcTempStart > pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_ERRURIFMT;
      strcpy(pxSipError->szErrorDesc,"Error in Error-Info format");
      return IFX_SIP_FAILURE;
    }
  }
  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'>');
  if(pcCurrPos == NULL){
    /* Invalid Error URI Format */
    pxSipError->eDecodeErr = IFX_SIP_INVALID_ERRURIFMT;
    strcpy(pxSipError->szErrorDesc,"Error in URI format");
    return IFX_SIP_FAILURE;
  }
  /* Call Absolute URI decode Function */
  if(IFX_SIP_DecodeAbsoluteURI((pcTempStart + 1),
                                pcCurrPos,
                                &pxErr->xAbsUri,
                                pxSipError) == IFX_SIP_FAILURE){
    return IFX_SIP_FAILURE;
  }
  pcTempStart = pcCurrPos;
  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,';');
  if(pcCurrPos != NULL){
    pcTempStart++; /* as it is pointing to > */

    /* Check if there are only spaces between > and ; */
    while(pcTempStart < pcCurrPos){
      if((*pcTempStart == ' ') || (*pcTempStart == '\t')){
        pcTempStart++;
        continue;
      }
      else{
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid message format");
        return IFX_SIP_FAILURE;
      }
    }

    pcTempStart = pcCurrPos + 1;
    do{
      if(pxErr->ucNoOfGenParam >= IFX_SIP_MAX_GEN_PARAM){
        pxSipError->eDecodeErr = IFX_SIP_MAXGENPARAM_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Max GenParam Exceeded");
        return IFX_SIP_FAILURE;
      }

      /* Check for the delimiter */
      if(IFX_SIP_FindDelimWhenQuotesRPresent(pcTempStart,
                                              pcEndIndex,
                                              ';',
                                              &pcCurrPos,
                                              &pcTempEnd,
                                              pxSipError) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }

      if(IFX_SIP_DecodeGenericParams(pcTempStart,pcTempEnd,&pxErr->
        axGenericParam[pxErr->ucNoOfGenParam],pxSipError) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
      pxErr->ucNoOfGenParam++;
      if(pcCurrPos == NULL){
        break;
      }
      else{
        pcTempStart = pcCurrPos + 1;
      }
    }
    while(1);
  }
  else{
    pcTempStart++; /* As it is pointing to > */
    /* No Generic parameters after Error URI */
    /* Check if only spaces are present after > */
    while(pcTempStart < pcEndIndex){
      if((*pcTempStart == ' ') || (*pcTempStart == '\t')){
        pcTempStart++;
        continue;
      }
      else{
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid message format");
        return IFX_SIP_FAILURE;
      }
    }
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_DecodeAInfo
*  Description  :  Decodes the ainfo for Authentication Info
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        :   
*********************************************************************/

e_IFX_SIP_Return
IFX_SIP_DecodeAInfo(IN  char8* pcStartIndex,
                     IN  char8* pcEndIndex,
                     OUT x_IFX_SIP_AInfo* pxAInfo,
                     OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcCurrPos, * pcTempEnd;
  uint32 i;
  pcTempStart = pcStartIndex;

  while((pcTempStart < pcEndIndex) &&
        ((*pcTempStart == ' ') || (*pcTempStart == '\t'))){
    pcTempStart++;
  }
  if(pcTempStart >= pcEndIndex){
    pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
    strcpy(pxSipError->szErrorDesc,"Invalid Message fmt-Authen Info");
    return IFX_SIP_FAILURE;
  }

  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'=');

  if(pcCurrPos == NULL){
    pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
    strcpy(pxSipError->szErrorDesc,"Invalid Message fmt-Authen Info");
    return IFX_SIP_FAILURE;
  }
  else{
    pcTempEnd = pcCurrPos;
    while((pcTempEnd > pcTempStart) &&
          (*(pcTempEnd - 1) == ' ' || *(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
    }
    if(pcTempEnd <= pcTempStart){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Message fmt-Authen Info");
      return IFX_SIP_FAILURE;
    }
    i = pcTempEnd - pcTempStart;
  }

  if(strncmp(pcTempStart,"nextnonce",IFX_SIP_MAX(i,strlen("nextnonce"))) == 0){
    pxAInfo->eAinfoType = IFX_SIP_NEXTNONCE;
    pcTempStart = pcCurrPos + 1;
    /* Remove any leading spaces */
    while((pcTempStart < pcEndIndex) &&
          ((*pcTempStart == ' ') || (*pcTempStart == '\t'))){
      pcTempStart++;
    }
    if(pcTempStart >= pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Message fmt-Authen Info");
      return IFX_SIP_FAILURE;
    }

    if(((pcEndIndex - pcTempStart) > IFX_SIP_MAX_TOKEN) ||
       ((pcEndIndex - pcTempStart) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_TOKEN_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"next nonce exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxAInfo->uxAinfoType.szNextNonce,
            pcTempStart,
            (pcEndIndex - pcTempStart));
    pxAInfo->uxAinfoType.szNextNonce[(pcEndIndex - pcTempStart)] = '\0';
    /* Validate Next Nonce */
    if(IFX_SIP_ValidateQuotedString(pxAInfo->uxAinfoType.szNextNonce) ==
       IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_QUOTEDSTRING;
      strcpy(pxSipError->szErrorDesc,"Invalid CNonce Value");
      return IFX_SIP_FAILURE;
    }
  }
  else if(strncmp(pcTempStart,"rspauth",IFX_SIP_MAX(i,strlen("rspauth"))) ==
          0){
    pxAInfo->eAinfoType = IFX_SIP_RESP_AUTH;
    pcTempStart = pcCurrPos + 1;
    /* Remove any leading spaces */
    while((pcTempStart < pcEndIndex) &&
          ((*pcTempStart == ' ') || (*pcTempStart == '\t'))){
      pcTempStart++;
    }
    if(pcTempStart >= pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Message fmt-Authen Info");
      return IFX_SIP_FAILURE;
    }

    if(((pcEndIndex - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
       ((pcEndIndex - pcTempStart) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_TOKEN_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"rsp auth exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxAInfo->uxAinfoType.szRespAuth,
            pcTempStart,
            (pcEndIndex - pcTempStart));
    pxAInfo->uxAinfoType.szRespAuth[(pcEndIndex - pcTempStart)] = '\0';
    /* Validate RespAuth */
    if(IFX_SIP_ValidateResponseDigest(pxAInfo->uxAinfoType.szRespAuth) ==
       IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_RESPDIGEST;
      strcpy(pxSipError->szErrorDesc,"Invalid Resp Auth Value");
      return IFX_SIP_FAILURE;
    }
  }
  else if(strncmp(pcTempStart,"cnonce",IFX_SIP_MAX(i,strlen("cnonce"))) == 0){
    pxAInfo->eAinfoType = IFX_SIP_CNONCE_AI;
    pcTempStart = pcCurrPos + 1;
    /* Remove any leading spaces */
    while((pcTempStart < pcEndIndex) &&
          ((*pcTempStart == ' ') || (*pcTempStart == '\t'))){
      pcTempStart++;
    }
    if(pcTempStart >= pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Message fmt-Authen Info");
      return IFX_SIP_FAILURE;
    }

    if(((pcEndIndex - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
       ((pcEndIndex - pcTempStart) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_TOKEN_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"cnonce exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxAInfo->uxAinfoType.szCnonce,
            pcTempStart,
            (pcEndIndex - pcTempStart));
    pxAInfo->uxAinfoType.szCnonce[(pcEndIndex - pcTempStart)] = '\0';
    /* Validate Cnonce */
    if(IFX_SIP_ValidateQuotedString(pxAInfo->uxAinfoType.szCnonce) ==
       IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_QUOTEDSTRING;
      strcpy(pxSipError->szErrorDesc,"Invalid CNonce Value");
      return IFX_SIP_FAILURE;
    }
  }
  else if(strncmp(pcTempStart,"nc",IFX_SIP_MAX(i,strlen("nc"))) == 0){
    int32 i;
    pxAInfo->eAinfoType = IFX_SIP_NONCE_COUNT;
    pcTempStart = pcCurrPos + 1;
    /* Remove any leading spaces */
    while((pcTempStart < pcEndIndex) &&
          ((*pcTempStart == ' ') || (*pcTempStart == '\t'))){
      pcTempStart++;
    }
    if(pcTempStart >= pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Message fmt-Authen Info");
      return IFX_SIP_FAILURE;
    }

    if(((pcEndIndex - pcTempStart) > 8) || ((pcEndIndex - pcTempStart) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_NONCECOUNT_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Nonce Count Exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxAInfo->uxAinfoType.szNonceCount,
            pcTempStart,
            (pcEndIndex - pcTempStart));
    pxAInfo->uxAinfoType.szNonceCount[(pcEndIndex - pcTempStart)] = '\0';
    if((pcEndIndex - pcTempStart) != (IFX_SIP_MAX_NC - 1)){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Message fmt-Authen Info");
      return IFX_SIP_FAILURE;
    }
    for(i = 0; i < (pcEndIndex - pcTempStart); i++){
      if(isdigit(pxAInfo->uxAinfoType.szNonceCount[i]) ||
         (pxAInfo->uxAinfoType.szNonceCount[i] >= 0x61 &&
          pxAInfo->uxAinfoType.szNonceCount[i] <= 0x66)){
        continue;
      }
      else{
        pxSipError->eDecodeErr = IFX_SIP_INVALID_NC;
        strcpy(pxSipError->szErrorDesc,"Invalid Nonce-Count");
        return IFX_SIP_FAILURE;
      }
    }
  }
  else if(strncmp(pcTempStart,"qop",IFX_SIP_MAX(i,strlen("qop"))) == 0){
    pxAInfo->eAinfoType = IFX_SIP_MESG_QOP;
    pcTempStart = pcCurrPos + 1;
    /* Remove any leading spaces */
    while((pcTempStart < pcEndIndex) &&
          ((*pcTempStart == ' ') || (*pcTempStart == '\t'))){
      pcTempStart++;
    }
    if(pcTempStart >= pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Message fmt-Authen Info");
      return IFX_SIP_FAILURE;
    }

    for(i = 0; (pcTempStart + i) < pcEndIndex; i++){
      if((*(pcTempStart + i) == ' ') || (*(pcTempStart + i) == '\t')){
        break;
      }
    }
    if(strncmp(pcTempStart,"auth",IFX_SIP_MAX(i,strlen("auth"))) == 0){
      pxAInfo->uxAinfoType.xMesgQop.eQopValType = IFX_SIP_AUTH;
    }
    else if(strncmp(pcTempStart,"auth-int",
            IFX_SIP_MAX(i,strlen("auth-int"))) == 0){
      pxAInfo->uxAinfoType.xMesgQop.eQopValType = IFX_SIP_AUTH_INT;
    }
    else{
      pxAInfo->uxAinfoType.xMesgQop.eQopValType = IFX_SIP_OTHER_QOPVAL;
      if((i >= IFX_SIP_MAX_TOKEN) || (i <= 10)){
        pxSipError->eDecodeErr = IFX_SIP_TOKEN_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"QOP token exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxAInfo->uxAinfoType.xMesgQop.szQopVal,pcTempStart,i);
      pxAInfo->uxAinfoType.xMesgQop.szQopVal[i] = '\0';
      /* Validate QOP value */
      if(IFX_SIP_ValidateToken(pxAInfo->uxAinfoType.xMesgQop.
        szQopVal) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
        strcpy(pxSipError->szErrorDesc,"Invalid Qop Value");
        return IFX_SIP_FAILURE;
      }
    }
  }
  else{
    pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
    strcpy(pxSipError->szErrorDesc,"Invalid Message fmt-Authen Info");
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeDigestClnUri
*  Description  :  Decodes the Digest Cln
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        :   
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeDigestClnUri(IN  char8* pcStartIndex,
                            IN  char8* pcEndIndex,
                            OUT x_IFX_SIP_Uri* pxUri,
                            OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart;
  pcTempStart = pcStartIndex;
  while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
    pcTempStart++;
  }
  if(*pcTempStart == '\\'){
    /* abs Path */
    pxUri->eSipUriType = IFX_SIP_ABS_PATH; 
    if(IFX_SIP_DecodePathSegment(pcTempStart,pcEndIndex,&pxUri->uxUriType.
      xAbsPath,pxSipError) == IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
  }
  else{
    /* abs Uri */
    pxUri->eSipUriType = IFX_SIP_ABSOLUTE_SIP_URI; 
    if(IFX_SIP_DecodeAbsoluteURI(pcTempStart,pcEndIndex,&pxUri->uxUriType.
      xAbsoluteUri,pxSipError) == IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_DecodeDigestCln
*  Description  :  Decodes the Digest Cln
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        :   
*********************************************************************/

e_IFX_SIP_Return
IFX_SIP_DecodeDigCln(IN  char8* pcStartIndex,
                      IN  char8* pcEndIndex,
                      OUT x_IFX_SIP_DigestCln* pxDigCln,
                      OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcCurrPos, * pcTempEnd, acTemp[IFX_SIP_MAX_TOKEN];
  int32 iCount;
  pcTempStart = pcStartIndex;
  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'=');
  if(pcCurrPos != NULL){
    pcTempEnd = pcCurrPos;
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd < pcTempStart){
        return IFX_SIP_FAILURE;
      }
    }
    if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
       ((pcTempEnd - pcTempStart) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_MAX_CHAL_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"DigCln Exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(acTemp,pcTempStart,(pcTempEnd - pcTempStart));
    acTemp[(pcTempEnd - pcTempStart)] = '\0';
    if(IFX_SIP_strcasecmp(acTemp,"realm") == 0){
      pxDigCln->eDigestClnType = IFX_SIP_REALM_D;
      pcCurrPos++;
      while((*pcCurrPos == ' ') || (*pcCurrPos == '\t')){
        pcCurrPos++;
      }
      if(((pcEndIndex - pcCurrPos) >= IFX_SIP_MAX_TOKEN) ||
         ((pcEndIndex - pcCurrPos) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_MAX_CHAL_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"realm Exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxDigCln->uxDigestClnType.szRealm,
              pcCurrPos,
              (pcEndIndex - pcCurrPos));
      pxDigCln->uxDigestClnType.szRealm[(pcEndIndex - pcCurrPos)] = '\0';
      /* Validate Quoted String */
    }
    else if(IFX_SIP_strcasecmp(acTemp,"domain") == 0){
      pxDigCln->eDigestClnType = IFX_SIP_DOMAIN;
      pcTempStart = pcCurrPos + 1;
      while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
        pcTempStart++;
      } 
      if((*pcTempStart != '\"') && (*pcEndIndex != '\"')){
        pxSipError->eDecodeErr = IFX_SIP_DIGCLNFMT_INVALID;
        strcpy(pxSipError->szErrorDesc,"Invalid domain");
        return IFX_SIP_FAILURE;
      }
      pcTempStart++;
      /* Decode Domain */
      do{
        iCount = pxDigCln->uxDigestClnType.xDomain.ucNoOfUri;
        while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
          pcTempStart++;
        } 
        pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,' ');
        if(pcCurrPos == NULL){
          if(IFX_SIP_DecodeDigestClnUri(pcTempStart, pcEndIndex - 1,
             &pxDigCln->uxDigestClnType.xDomain.axUri[iCount], pxSipError) ==
             IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
          pxDigCln->uxDigestClnType.xDomain.ucNoOfUri++;
          break;
        }
        else{
          if(IFX_SIP_DecodeDigestClnUri(pcTempStart, pcCurrPos, &pxDigCln->
             uxDigestClnType.xDomain.axUri[iCount], pxSipError) ==
             IFX_SIP_FAILURE){
            return IFX_SIP_FAILURE;
          }
          pxDigCln->uxDigestClnType.xDomain.ucNoOfUri++;
          pcTempStart = pcCurrPos + 1;
        }
      }
      while(1);
    }
    else if(IFX_SIP_strcasecmp(acTemp,"nonce") == 0){
      pxDigCln->eDigestClnType = IFX_SIP_NONCE_D;
      pcCurrPos++;
      while((*pcCurrPos == ' ') || (*pcCurrPos == '\t')){
        pcCurrPos++;
      }
      if(((pcEndIndex - pcCurrPos) >= IFX_SIP_MAX_TOKEN) ||
         ((pcEndIndex - pcCurrPos) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_MAX_CHAL_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Nonce Exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxDigCln->uxDigestClnType.szNonce,
              pcCurrPos,
              (pcEndIndex - pcCurrPos));
      pxDigCln->uxDigestClnType.szNonce[(pcEndIndex - pcCurrPos)] = '\0';
      /* Validate Quoted String */
    }
    else if(IFX_SIP_strcasecmp(acTemp,"opaque") == 0){
      pxDigCln->eDigestClnType = IFX_SIP_OPAQUE;
      pcCurrPos++;
      while((*pcCurrPos == ' ') || (*pcCurrPos == '\t')){
        pcCurrPos++;
      }
      if(((pcEndIndex - pcCurrPos) >= IFX_SIP_MAX_TOKEN) ||
         ((pcEndIndex - pcCurrPos) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_MAX_CHAL_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Nonce Exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxDigCln->uxDigestClnType.szOpaque,
              pcCurrPos,
              (pcEndIndex - pcCurrPos));
      pxDigCln->uxDigestClnType.szOpaque[(pcEndIndex - pcCurrPos)] = '\0';
      /* Validate Quoted String */
    }
    else if(IFX_SIP_strcasecmp(acTemp,"stale") == 0){
      pxDigCln->eDigestClnType = IFX_SIP_STALE;
      pcCurrPos++;
      while((*pcCurrPos == ' ') || (*pcCurrPos == '\t')){
        pcCurrPos++;
      }
      if(((pcEndIndex - pcCurrPos) >= IFX_SIP_MAX_TOKEN) ||
         ((pcEndIndex - pcCurrPos) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_MAX_CHAL_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Nonce Exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(acTemp,pcCurrPos,(pcEndIndex - pcCurrPos));
      acTemp[(pcEndIndex - pcCurrPos)] = '\0';
      if(IFX_SIP_strcasecmp(acTemp,"true") == 0){
        pxDigCln->uxDigestClnType.eStale = IFX_SIP_TRUE;
      }
      else if(IFX_SIP_strcasecmp(acTemp,"false") == 0){
        pxDigCln->uxDigestClnType.eStale = IFX_SIP_FALSE;
      }
      else{
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid Stale");
        return IFX_SIP_FAILURE;
      }
    }
    else if(IFX_SIP_strcasecmp(acTemp,"algorithm") == 0){
      pxDigCln->eDigestClnType = IFX_SIP_ALGORITHM_D;
      pcCurrPos++;
      while((*pcCurrPos == ' ') || (*pcCurrPos == '\t')){
        pcCurrPos++;
      }
      if(((pcEndIndex - pcCurrPos) >= IFX_SIP_MAX_TOKEN) ||
         ((pcEndIndex - pcCurrPos) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_MAX_CHAL_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Nonce Exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(acTemp,pcCurrPos,(pcEndIndex - pcCurrPos));
      acTemp[(pcEndIndex - pcCurrPos)] = '\0';
      if(IFX_SIP_strcasecmp(acTemp,"MD5") == 0){
        pxDigCln->uxDigestClnType.xAlgorithm.eAlgType = IFX_SIP_MD5;
        strcpy(pxDigCln->uxDigestClnType.xAlgorithm.szOtherAlg,"MD5");
      }
      else if(IFX_SIP_strcasecmp(acTemp,"MD5-sess") == 0){
        pxDigCln->uxDigestClnType.xAlgorithm.eAlgType = IFX_SIP_MD5_SESS;
        strcpy(pxDigCln->uxDigestClnType.xAlgorithm.szOtherAlg,"MD5-sess");
      }
      else{
        pxDigCln->uxDigestClnType.xAlgorithm.eAlgType = IFX_SIP_OTHER_ALG;
        strcpy(pxDigCln->uxDigestClnType.xAlgorithm.szOtherAlg,acTemp);
        if(IFX_SIP_ValidateToken(pxDigCln->uxDigestClnType.xAlgorithm.
          szOtherAlg) == IFX_SIP_FAILURE){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
          strcpy(pxSipError->szErrorDesc,"Invalid Other Algorithm");
          return IFX_SIP_FAILURE;
        }
      }
    }
    else if(IFX_SIP_strcasecmp(acTemp,"qop") == 0){
      pxDigCln->eDigestClnType = IFX_SIP_QOP_OPTIONS;
      /* Qop Value */
      pcCurrPos++;
      while((*pcCurrPos == ' ') || (*pcCurrPos == '\t')){
        pcCurrPos++;
      }
      if(*pcCurrPos == '\"'){
        pcTempStart = pcCurrPos + 1;
        do{
          iCount = pxDigCln->uxDigestClnType.xQopOptions.
          ucNoOfQopValue;
          pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'\"');
          if(pcCurrPos == NULL){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_DIGCLNFMT;
            strcpy(pxSipError->szErrorDesc,"Invalid Dig cln format");
            return IFX_SIP_FAILURE;
          }
          else{
            char8* pcTemp;
            pcTempEnd = pcCurrPos;
            pcCurrPos = IFX_SIP_strchr(pcTempStart,pcTempEnd,',');
            if(pcCurrPos == NULL){
              pcTemp = pcTempEnd;
            }
            else{
              pcTemp = pcCurrPos;
            }
            if(((pcTemp - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
               ((pcTemp - pcTempStart) <= 0)){
              pxSipError->eDecodeErr = IFX_SIP_MAX_QOP_EXCEEDED;
              strcpy(pxSipError->szErrorDesc,"Qop Exceeded");
              return IFX_SIP_FAILURE;
            }
            strncpy(acTemp,pcTempStart,(pcTemp - pcTempStart));
            acTemp[(pcTemp - pcTempStart)] = '\0';
            if(IFX_SIP_strcasecmp(acTemp,"auth") == 0){
              pxDigCln->uxDigestClnType.xQopOptions.axQopValue[iCount].
                                                 eQopValType = IFX_SIP_AUTH;
              strcpy(pxDigCln->uxDigestClnType.xQopOptions.
                axQopValue[iCount].szQopVal,"auth");
            }
            else if(IFX_SIP_strcasecmp(acTemp,"auth-int") == 0){
              pxDigCln->uxDigestClnType.xQopOptions.axQopValue[iCount].
                                              eQopValType = IFX_SIP_AUTH_INT;
              strcpy(pxDigCln->uxDigestClnType.xQopOptions.
                axQopValue[iCount].szQopVal,"auth-int");
            }
            else{
              pxDigCln->uxDigestClnType.xQopOptions.axQopValue[iCount].
                                           eQopValType = IFX_SIP_OTHER_QOPVAL;
              if(strlen(acTemp) >= IFX_SIP_MAX_TOKEN){
                return IFX_SIP_FAILURE;
              }
              strcpy(pxDigCln->uxDigestClnType.xQopOptions.
                axQopValue[iCount].szQopVal,acTemp);
              if(IFX_SIP_ValidateToken(pxDigCln->
                uxDigestClnType.xQopOptions.axQopValue[iCount].
                szQopVal) == IFX_SIP_FAILURE){
                return IFX_SIP_FAILURE;
              }
            }
          }
          pxDigCln->uxDigestClnType.xQopOptions.ucNoOfQopValue++;
          if(pcCurrPos == NULL){
            break;
          }
          else{
            pcTempStart = pcCurrPos + 1;
            while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
              pcTempStart++;
            }
          }
        }
        while(1);
      }
    }
    else{
      pxDigCln->eDigestClnType = IFX_SIP_AUTH_PARAM;
      /* Auth Param */
      strcpy(pxDigCln->uxDigestClnType.xAuthParam.szAuthParamName,acTemp);
      pcCurrPos++;
      while((*pcCurrPos == ' ') || (*pcCurrPos == '\t')){
        pcCurrPos++;
      }
      if(((pcEndIndex - pcCurrPos) >= IFX_SIP_MAX_TOKEN) ||
         ((pcEndIndex - pcCurrPos) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_MAX_CHAL_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Nonce Exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxDigCln->uxDigestClnType.xAuthParam.szValue, pcCurrPos,
              (pcEndIndex - pcCurrPos));
      pxDigCln->uxDigestClnType.xAuthParam.
                              szValue[(pcEndIndex - pcCurrPos)] = '\0';
    }
  }
  else{
    pxSipError->eDecodeErr = IFX_SIP_DIGCLNFMT_INVALID;
    strcpy(pxSipError->szErrorDesc,"Error in Digest Cln Format");
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_SIP_DecodeAuthParam
*  Description  :  Decodes the AuthParam
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeAuthParam(x_IFX_SIP_AuthParam* pxAuthParam,
                         char8* pcCurrPos,
                         char8* pcEndIndex)
{
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  char8 acTemp[IFX_SIP_MAX_TOKEN];
  int32 iCount = 0;
  while(*pcCurrPos != ' ' && *pcCurrPos != '='){
    acTemp[iCount++] = *pcCurrPos;
    pcCurrPos++;
    if(iCount >= IFX_SIP_MAX_TOKEN){
      return(IFX_SIP_FAILURE);
    }
  }
  acTemp[iCount] = '\0';
  eRetVal = IFX_SIP_DecodeValidateToken(acTemp);
  if(eRetVal == IFX_SIP_SUCCESS){
    strcpy(pxAuthParam->szAuthParamName,acTemp);
  }
  else{
    return(IFX_SIP_FAILURE);
  }
  /* skip the equal */
  while(*pcCurrPos == ' '){
    pcCurrPos++;
  }
  if(*pcCurrPos != '='){
    return(IFX_SIP_FAILURE);
  }
  pcCurrPos++;
  while(*pcCurrPos == ' '){
    pcCurrPos++;
  }

  iCount = 0;
  memset(acTemp,0,IFX_SIP_MAX_TOKEN);
  while(pcCurrPos < pcEndIndex){
    acTemp[iCount++] = *pcCurrPos;
    pcCurrPos++;
    if(iCount >= IFX_SIP_MAX_TOKEN){
      return(IFX_SIP_FAILURE);
    }
  }
  acTemp[iCount] = '\0';
  strcpy(pxAuthParam->szValue,acTemp);
  return(IFX_SIP_SUCCESS);
}

/******************************************************************
*  Function Name:  IFX_SIP_Decode_Digest_Resp
*  Description  :  Decodes the Digest Response
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_Decode_Digest_Resp(x_IFX_SIP_DigResp* pxDigest,
                            char8* pString)
{
  char8 cTempString[IFX_SIP_TEMP_MAX] =
  {
    '\0'
  };
  int32 iTempCount = 0;
  e_IFX_SIP_Return eRetVal;

  if(*pString == '\0'){
    return IFX_SIP_FAILURE;
  }

  while((*pString != ' ') && (*pString != '=')){
    cTempString[iTempCount++] = *pString;
    /* no need to check the value of iTempCount because pString will have
    max of IFX_SIP_TEMP_MAX characters */
    pString++;
  }
  /* now skip the equal and spaces after equal */
  while(*pString == ' '){
    pString++;
  }
  if(*pString != '='){
    return(IFX_SIP_FAILURE);
  }
  else{
    pString++;
  }
  while(*pString == ' '){
    pString++;
  }

  if(IFX_SIP_strcasecmp(cTempString,"username") == 0){
    pxDigest->eDigRespType = IFX_SIP_USERNAME;
    /* reset the local tempstring */
    memset(cTempString,'\0',IFX_SIP_TEMP_MAX);
    iTempCount = 0;
    while(*pString != '\0'){
      cTempString[iTempCount++] = *pString;
      /* no need to check the value of iTempCount because pString 
        will have max of IFX_SIP_TEMP_MAX characters */
      pString++;
    }
    cTempString[iTempCount] = '\0';
    if(iTempCount == 0){
      return IFX_SIP_FAILURE;
    }
    strcpy(pxDigest->uxDigRespType.szUserName,cTempString);
    if(IFX_SIP_ValidateQuotedString(pxDigest->uxDigRespType.szUserName) ==
       IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
  }
  else if(IFX_SIP_strcasecmp(cTempString,"realm") == 0){
    pxDigest->eDigRespType = IFX_SIP_REALM;
    /* reset the local tempstring */
    memset(cTempString,'\0',IFX_SIP_TEMP_MAX);
    iTempCount = 0;
    while(*pString != '\0'){
      cTempString[iTempCount++] = *pString;
      /* no need to check the value of iTempCount because pString will
        have max of IFX_SIP_TEMP_MAX characters */
      pString++;
    }
    cTempString[iTempCount] = '\0';
    if(iTempCount == 0){
      return IFX_SIP_FAILURE;
    }
    strcpy(pxDigest->uxDigRespType.szRealm,cTempString);
    if(IFX_SIP_ValidateQuotedString(pxDigest->uxDigRespType.szRealm) ==
       IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
  }
  else if(IFX_SIP_strcasecmp(cTempString,"nonce") == 0){
    pxDigest->eDigRespType = IFX_SIP_NONCE;
    /* reset the local tempstring */
    memset(cTempString,'\0',IFX_SIP_TEMP_MAX);
    iTempCount = 0;
    while(*pString != '\0'){
      cTempString[iTempCount++] = *pString;
      /* no need to check the value of iTempCount because pString
        will have max of IFX_SIP_TEMP_MAX characters */
      pString++;
    }
    cTempString[iTempCount] = '\0';
    if(iTempCount == 0){
      return IFX_SIP_FAILURE;
    }
    strcpy(pxDigest->uxDigRespType.szNonce,cTempString);
    if(IFX_SIP_ValidateQuotedString(pxDigest->uxDigRespType.szNonce) ==
       IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
  }
  else if(IFX_SIP_strcasecmp(cTempString,"uri") == 0){
    x_IFX_SIP_Error pxSipError;
    pxDigest->eDigRespType = IFX_SIP_DIGESTURI;
    /* reset the local tempstring */
    memset(cTempString,'\0',IFX_SIP_TEMP_MAX);
    iTempCount = 0;
    if(*pString == '\"'){
      pString++;
      while(*pString == ' '){
        pString++;
      }
    }
    else{
      return IFX_SIP_FAILURE;
    }
    while((*pString != '\"') && (*pString != ' ')){
      cTempString[iTempCount++] = *pString;
      /* no need to check the value of iTempCount because pString will
        have max of IFX_SIP_TEMP_MAX characters */
      pString++;
    }
    cTempString[iTempCount] = '\0';
    if(iTempCount == 0){
      return IFX_SIP_FAILURE;
    }
    if(IFX_SIP_DecodeURI(cTempString,
                          (cTempString + iTempCount),
                          &pxDigest->uxDigRespType.xDigestUri,
                          &pxSipError) == IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
  }
  else if(IFX_SIP_strcasecmp(cTempString,"response") == 0){
    pxDigest->eDigRespType = IFX_SIP_DRESPONSE;
    /* reset the local tempstring */
    memset(cTempString,'\0',IFX_SIP_TEMP_MAX);
    iTempCount = 0;
    if(*pString == '\"'){
      pString++;
      while(*pString == ' '){
        pString++;
      }
    }
    else{
      return IFX_SIP_FAILURE;
    }
    while((*pString != '\"') && (*pString != ' ')){
      if(isdigit(*pString) || ((*pString >= 0x61) && (*pString <= 0x66))){
        cTempString[iTempCount++] = *pString;
        /* no need to check the value of iTempCount because 
          pString will have max of IFX_SIP_TEMP_MAX characters */
        pString++;
      }
      else{
        return IFX_SIP_FAILURE;
      }
    }
    cTempString[iTempCount] = '\0';
    if(iTempCount == 0){
      return IFX_SIP_FAILURE;
    }
    strcpy(pxDigest->uxDigRespType.szDresponse,cTempString);
  }
  else if(IFX_SIP_strcasecmp(cTempString,"algorithm") == 0){
    pxDigest->eDigRespType = IFX_SIP_ALGORITHM;
    iTempCount = 0;
    memset(cTempString,'\0',IFX_SIP_TEMP_MAX);
    while(*pString != '\0' && *pString != ' '){
      cTempString[iTempCount++] = *pString;
      /* no need to check the value of iTempCount because pString will 
        have max of IFX_SIP_TEMP_MAX characters */
      pString++;
    }
    cTempString[iTempCount] = '\0';
    if(iTempCount == 0){
      return IFX_SIP_FAILURE;
    }
    if(IFX_SIP_strcasecmp(cTempString,"MD5") == 0){
      pxDigest->uxDigRespType.xAlgorithm.eAlgType = IFX_SIP_MD5;
      strcpy(pxDigest->uxDigRespType.xAlgorithm.szOtherAlg,cTempString);
    }
    else if(IFX_SIP_strcasecmp(cTempString,"MD5-sess") == 0){
      pxDigest->uxDigRespType.xAlgorithm.eAlgType = IFX_SIP_MD5_SESS;
      strcpy(pxDigest->uxDigRespType.xAlgorithm.szOtherAlg,cTempString);
    }
    else{
      pxDigest->uxDigRespType.xAlgorithm.eAlgType = IFX_SIP_OTHER_ALG;
      strcpy(pxDigest->uxDigRespType.xAlgorithm.szOtherAlg,cTempString);
      if(IFX_SIP_ValidateToken(pxDigest->uxDigRespType.xAlgorithm.
        szOtherAlg) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
    }
  }
  else if(IFX_SIP_strcasecmp(cTempString,"cnonce") == 0){
         pxDigest->eDigRespType = IFX_SIP_CNONCE;
         /* reset the local tempstring */
         memset(cTempString,'\0',IFX_SIP_TEMP_MAX);
         iTempCount = 0;
    while(*pString != '\0'){
      cTempString[iTempCount++] = *pString;
      /* no need to check the value of iTempCount because pString 
        will have max of IFX_SIP_TEMP_MAX characters */
      pString++;
    }
         cTempString[iTempCount] = '\0';
    if(iTempCount == 0){
      return IFX_SIP_FAILURE;
    }
         strcpy(pxDigest->uxDigRespType.szCnonce,cTempString);
    if(IFX_SIP_ValidateQuotedString(pxDigest->uxDigRespType.szCnonce) ==
       IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
  }
  else if(IFX_SIP_strcasecmp(cTempString,"opaque") == 0){
         pxDigest->eDigRespType = IFX_SIP_OPAQUE_D;
         /* reset the local tempstring */
         memset(cTempString,'\0',IFX_SIP_TEMP_MAX);
         iTempCount = 0;
    while(*pString != '\0'){
      cTempString[iTempCount++] = *pString;
      /* no need to check the value of iTempCount because pString will
         * have max of IFX_SIP_TEMP_MAX characters */
      pString++;
    }
         cTempString[iTempCount] = '\0';
    if(iTempCount == 0){
      return IFX_SIP_FAILURE;
    }
         strcpy(pxDigest->uxDigRespType.szOpaque,cTempString);
    if(IFX_SIP_ValidateQuotedString(pxDigest->uxDigRespType.szOpaque) ==
       IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
  }
  else if(IFX_SIP_strcasecmp(cTempString,"qop") == 0){
         pxDigest->eDigRespType = IFX_SIP_MESSAGE_QOP;
         iTempCount = 0;
         memset(cTempString,'\0',IFX_SIP_TEMP_MAX);
    while(*pString != '\0' && *pString != ' '){
      cTempString[iTempCount++] = *pString;
      /* no need to check the value of iTempCount because pString will 
         * have max of IFX_SIP_TEMP_MAX characters */
      pString++;
    }
         cTempString[iTempCount] = '\0';
    if(iTempCount == 0){
      return IFX_SIP_FAILURE;
    }
    strcpy(pxDigest->uxDigRespType.xMsgQop.szQopVal,cTempString);
    if(IFX_SIP_strcasecmp(cTempString,"auth") == 0){
      pxDigest->uxDigRespType.xMsgQop.eQopValType = IFX_SIP_AUTH;
    }
    else if(IFX_SIP_strcasecmp(cTempString,"auth-int") == 0){
      pxDigest->uxDigRespType.xMsgQop.eQopValType = IFX_SIP_AUTH_INT;
    }
    else{
      pxDigest->uxDigRespType.xMsgQop.eQopValType = IFX_SIP_OTHER_QOPVAL;
      if(strlen(cTempString) >= IFX_SIP_MAX_TOKEN){
        return IFX_SIP_FAILURE;
      }
      /* Validate QOP value */
      if(IFX_SIP_ValidateToken(pxDigest->uxDigRespType.xMsgQop.szQopVal) ==
         IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
    }
  }
  else if(IFX_SIP_strcasecmp(cTempString,"nc") == 0){
    pxDigest->eDigRespType = IFX_SIP_NONCE_CNT;
    /* reset the local tempstring */
    memset(cTempString,'\0',IFX_SIP_TEMP_MAX);
    iTempCount = 0;
    while(*pString != '\0'){
      if(isdigit(*pString) || ((*pString >= 0x61) && (*pString <= 0x66))){
        cTempString[iTempCount++] = *pString;
        /* no need to check the value of iTempCount because pString will have
          max of IFX_SIP_TEMP_MAX characters */
        pString++;
      }
      else{
        return IFX_SIP_FAILURE;
      }
    }
    cTempString[iTempCount] = '\0';
    if(iTempCount == 0){
      return IFX_SIP_FAILURE;
    }
    strcpy(pxDigest->uxDigRespType.szNonceCount,cTempString);
  }
  else{
         eRetVal = IFX_SIP_DecodeValidateToken(cTempString);
    if(eRetVal == IFX_SIP_FAILURE){
      return (eRetVal);
    }
    else{
      pxDigest->eDigRespType = IFX_SIP_AUTH_PARAM_NAME;
      strcpy(pxDigest->uxDigRespType.xAuthParam.szAuthParamName,cTempString);
      /* reset the local tempstring */
      memset(cTempString,'\0',IFX_SIP_TEMP_MAX);
      iTempCount = 0;
      while(*pString != '\0'){
        cTempString[iTempCount++] = *pString;
        /* no need to check the value of iTempCount because 
           * pString will have max of IFX_SIP_TEMP_MAX characters */
        pString++;
      }
      cTempString[iTempCount] = '\0';
      strcpy(pxDigest->uxDigRespType.xAuthParam.szValue,cTempString);
      /* Validate Quoted String */
      if(IFX_SIP_ValidateQuotedString(pxDigest->uxDigRespType.
         xAuthParam.szValue) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
    }
  }
  return(IFX_SIP_SUCCESS);
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeCredential
*  Description  :  Decodes the Credentials
*  Input Values :  Start and End indices of credentials
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeCredential(char8** pPos,
                          char8* pcEndIndex,
                          x_IFX_SIP_Credential* pxProxyAuth,
                          x_IFX_SIP_Error* pxSipError)
{
  e_IFX_SIP_Return eRetVal;
  char8* pcCurrPos;
  char8 acTemp[IFX_SIP_TEMP_MAX] =
  {
    '\0'
  };
  int32 iCount = 0, iDigestCount = 0;
  pcCurrPos = *pPos;

  /* Remove any Leading Whitespaces */
  while(((pcCurrPos < pcEndIndex)) &&
        (*pcCurrPos == ' ' || *pcCurrPos == '\t')){
    pcCurrPos++;
  }
  if(pcCurrPos >= pcEndIndex){
    pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
    strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
    return IFX_SIP_FAILURE;
  }

  while(*pcCurrPos != ' '){
    acTemp[iCount++] = *pcCurrPos;
    if(iCount > IFX_SIP_TEMP_MAX){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_PROXY_AUTHORIZATION;
      strcpy(pxSipError->szErrorDesc,"Invalid credentials");
      return(IFX_SIP_FAILURE);
    }
    pcCurrPos++;
  }
  if(IFX_SIP_strcasecmp(acTemp,"Digest") == 0){
    pxProxyAuth->eRespType = IFX_SIP_DIGEST_RESPONSE;

    while(*pcCurrPos != '\r'){
      char cSearch = ',';
      memset(acTemp,'\0',IFX_SIP_TEMP_MAX);
      iCount = 0;
      /* skip the space */
      while((*pcCurrPos == ' ') || (*pcCurrPos == '\t')){
        pcCurrPos++;
      }
      while((*pcCurrPos != cSearch) && (*pcCurrPos != '\r')){
        if(*pcCurrPos == '\"'){
          cSearch = '\"';
        }
        acTemp[iCount++] = *pcCurrPos;
        pcCurrPos++;
      }
      if(*pcCurrPos == '\"'){
        acTemp[iCount++] = *pcCurrPos;
        pcCurrPos++;
      }
      iDigestCount = pxProxyAuth->uxRespType.xDigestResp.ucNoOfDigResp;
      eRetVal = IFX_SIP_Decode_Digest_Resp(&(pxProxyAuth->uxRespType.
                xDigestResp.axDigResp[iDigestCount]),acTemp);
      if(eRetVal == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_DIGEST_RESPONSE;
        return(IFX_SIP_FAILURE);
      }
      else{
        pxProxyAuth->uxRespType.xDigestResp.ucNoOfDigResp++;
      }

      if(pxProxyAuth->uxRespType.xDigestResp.ucNoOfDigResp >=
         IFX_SIP_MAX_DIG_RESP){
        pxSipError->eDecodeErr = IFX_SIP_MAXDIGRESP_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Max Digest Response Exceeded");
        return IFX_SIP_FAILURE;
      }
      /* check if there is a comma, then increment it and send the 
            pcCurrPos value for checking for next digest-response */
      while(*pcCurrPos == ' '){
        pcCurrPos++;
      }
      if(*pcCurrPos == ','){
        pcCurrPos++;
      }
    }
  }
  else{
    int32 iCount;
    char8* pcTemp, * pcTempEnd;

    pxProxyAuth->eRespType = IFX_SIP_OTHER_RESPONSE;
    strcpy(pxProxyAuth->uxRespType.xOtherResp.szAuthScheme,acTemp);
    /* For Decoding Auth Parameters */
    do{
      /* skip the space */
      while(*pcCurrPos == ' '){
        pcCurrPos++;
      }
      iCount = pxProxyAuth->uxRespType.xOtherResp.ucNoOfAuthParam;
      /* Decode auth-param-name */
      pcTemp = IFX_SIP_strchr(pcCurrPos,pcEndIndex,'=');
      if(pcTemp == NULL){
        /* Invalid auth-param Format Return Error */
        pxSipError->eDecodeErr = IFX_SIP_INVALID_AUTHPARAMFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid auth param format");
        return IFX_SIP_FAILURE;
      }
      else{
        /* Copy and validate the auth param name */
        pcTempEnd = pcTemp;
        while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
          pcTempEnd--;
          if(pcTempEnd < pcCurrPos){
            return IFX_SIP_FAILURE;
          }
        }
        if(((pcTempEnd - pcCurrPos) >= IFX_SIP_MAX_TOKEN) ||
           ((pcTempEnd - pcCurrPos) <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_AUTHPARAMNAME_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Auth Param name exceeded");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxProxyAuth->uxRespType.xOtherResp.axAuthParam[iCount]
          .szAuthParamName,pcCurrPos,(pcTempEnd - pcCurrPos));
        pxProxyAuth->uxRespType.xOtherResp.axAuthParam[iCount]
        .szAuthParamName[(pcTempEnd - pcCurrPos)] = '\0';
        if(IFX_SIP_ValidateToken(pxProxyAuth->uxRespType.xOtherResp
          .axAuthParam[iCount].szAuthParamName) == IFX_SIP_FAILURE){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;

          strcpy(pxSipError->szErrorDesc,"Invalid auth param name");
          return IFX_SIP_FAILURE;
        }
      }
      pcCurrPos = pcTemp + 1;
      while(*pcCurrPos == ' '){
        pcCurrPos++;
      }
      /* Decoding the Quoted String/ token */
      if(*pcCurrPos == '\"'){
        /* Quoted String */
        pcCurrPos++;/* As it points to " */
        pcTemp = IFX_SIP_strchr(pcCurrPos,pcEndIndex,'\"');
        if(pcTemp == NULL){
          /* Invalid auth-param Format Return Error */
          pxSipError->eDecodeErr = IFX_SIP_INVALID_AUTHPARAMFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid auth param format");
          return IFX_SIP_FAILURE;
        }
        else{
          /* Copy and validate the Quoted string */
          pcTempEnd = pcTemp;
          if(((pcTempEnd - pcCurrPos + 1) >= IFX_SIP_MAX_TOKEN) ||
             ((pcTempEnd - pcCurrPos + 1) <= 0)){
            pxSipError->eDecodeErr = IFX_SIP_AUTHPARAMNAME_EXCEEDED;
            strcpy(pxSipError->szErrorDesc,"Auth Param value exceeded");
            return IFX_SIP_FAILURE;
          }
          strncpy(pxProxyAuth->uxRespType.xOtherResp.axAuthParam[iCount].
                  szValue,(pcCurrPos - 1),(pcTempEnd - pcCurrPos + 2));
          pxProxyAuth->uxRespType.xOtherResp.axAuthParam[iCount].
          szValue[(pcTempEnd - pcCurrPos + 2)] = '\0';
          /* Validate Quoted String */
          if(IFX_SIP_ValidateQuotedString(pxProxyAuth->uxRespType.
            xOtherResp.axAuthParam[iCount].szValue) == IFX_SIP_FAILURE){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_QUOTEDSTRING;
            strcpy(pxSipError->szErrorDesc,
                   "Invalid authorization other response val");
            return IFX_SIP_FAILURE;
          }
        }
        pcCurrPos = pcTemp;
        pxProxyAuth->uxRespType.xOtherResp.ucNoOfAuthParam++;
        pcTemp = IFX_SIP_strchr(pcCurrPos,pcEndIndex,',');
        if(pcTemp == NULL){
          if((pcCurrPos + 1) != pcEndIndex){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
            strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
            return IFX_SIP_FAILURE;
          }
          break;
        }
        else{
          pcCurrPos = pcTemp;
        }
      }
      else{
        /* Token */
        pcTemp = IFX_SIP_strchr(pcCurrPos,pcEndIndex,',');
        if(pcTemp == NULL){
          pcTempEnd = pcEndIndex;
        }
        else{
          pcTempEnd = pcTemp;
        }

        /* Remove any Trailing Spaces */
        while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
          pcTempEnd--;
          if(pcTempEnd < pcCurrPos){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
            strcpy(pxSipError->szErrorDesc,"Invalid message format");
            return IFX_SIP_FAILURE;
          }
        }

        /* Copy and validate the token */
        if(((pcTempEnd - pcCurrPos) >= IFX_SIP_MAX_TOKEN) ||
           ((pcTempEnd - pcCurrPos) <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_AUTHPARAMNAME_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,"Auth Param value exceeded");
          return IFX_SIP_FAILURE;
        }
        strncpy(pxProxyAuth->uxRespType.xOtherResp.axAuthParam[iCount].
          szValue,pcCurrPos,(pcTempEnd - pcCurrPos));
        pxProxyAuth->uxRespType.xOtherResp.axAuthParam[iCount].
                                szValue[(pcTempEnd - pcCurrPos)] = '\0';
        if(IFX_SIP_ValidateToken(pxProxyAuth->uxRespType.xOtherResp.
          axAuthParam[iCount].szValue) == IFX_SIP_FAILURE){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
          strcpy(pxSipError->szErrorDesc,"Invalid auth param name");
          return IFX_SIP_FAILURE;
        }
        pxProxyAuth->uxRespType.xOtherResp.ucNoOfAuthParam++;
        if(pcTemp == NULL){
          break;
        }
        else{
          pcCurrPos = pcTemp;
        }
      }
    }
    while(1);   
    /* OK now memset the acTemp and iCount for later use */

    memset(acTemp,'\0',IFX_SIP_TEMP_MAX);
    iCount = 0;
  }
  *pPos = pcCurrPos;
  return(IFX_SIP_SUCCESS);
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeProduct
*  Description  :  Decodes the product of server val
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        :  product          =  token [SLASH product-version]
*          product-version  =  token  
*********************************************************************/

e_IFX_SIP_Return
IFX_SIP_DecodeProduct(IN  char8** pcStartIndex,
                       IN  char8* pcEndIndex,
                       OUT x_IFX_SIP_ServerVal* pxSer,
                       OUT x_IFX_SIP_Error* pxSipError)
{
  char* pcTempStart;
  int32 iCount = 0;
  pcTempStart = *pcStartIndex;
  pxSer->eServerValType = IFX_SIP_PRODUCT;
  while((*pcTempStart != ' ' && *pcTempStart != '/') &&
        pcTempStart < pcEndIndex){
    if(isalnum(*pcTempStart) ||
       *pcTempStart == '-' ||
       *pcTempStart == '.' ||
       *pcTempStart == '!' ||
       *pcTempStart == '%' ||
       *pcTempStart == '*' ||
       *pcTempStart == '_' ||
       *pcTempStart == '+' ||
       *pcTempStart == '\'' ||
       *pcTempStart == '`' ||
       *pcTempStart == '~'){
      pxSer->szPrStr[iCount++] = *pcTempStart;
      pcTempStart++;
    }
    else{
      pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
      strcpy(pxSipError->szErrorDesc,"Invalid Token in product descr");
      return IFX_SIP_FAILURE;
    }
  }
  if(pcTempStart == pcEndIndex){
    *pcStartIndex = pcTempStart;
  }
  else{
    /* Still some more info is present */
    while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
      pcTempStart++;
      if(pcTempStart == pcEndIndex){
        *pcStartIndex = pcTempStart;  
        return IFX_SIP_SUCCESS;
      }
    }
    if(*pcTempStart == '/'){
      pcTempStart++;
      /* Remove any Leading White spaces */
      while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
        pcTempStart++;
        if(pcTempStart > pcEndIndex){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid message format");
          return IFX_SIP_FAILURE;
        }
      }
      /* Copy the remaining part */
      pxSer->szPrStr[iCount++] = '/';
      while((*pcTempStart != ' ') && (pcTempStart < pcEndIndex)){
        if(isalnum(*pcTempStart) ||
           *pcTempStart == '-' ||
           *pcTempStart == '.' ||
           *pcTempStart == '!' ||
           *pcTempStart == '%' ||
           *pcTempStart == '*' ||
           *pcTempStart == '_' ||
           *pcTempStart == '+' ||
           *pcTempStart == '\'' ||
           *pcTempStart == '`' ||
           *pcTempStart == '~'){
          pxSer->szPrStr[iCount++] = *pcTempStart;
          pcTempStart++;
        }
        else{
          pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
          strcpy(pxSipError->szErrorDesc,"Invalid Token in product descr");
          return IFX_SIP_FAILURE;
        }
      }
    }
  }
  *pcStartIndex = pcTempStart;
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeSeverValComment
*  Description  :  Decodes Comment
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        :  comment  =  LPAREN *(ctext / quoted-pair / comment) RPAREN
*            ctext    =  %x21-27 / %x2A-5B / %x5D-7E / UTF8-NONASCII
*                 / LWS
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeSeverValComment(IN  char8** pcStartIndex,
                               IN  char8* pcEndIndex,
                               OUT x_IFX_SIP_ServerVal* pxSer,
                               OUT x_IFX_SIP_Error* pxSipError)
{
  uchar8* pcCurrPos;
  int32 iCount = 1;
  pxSer->eServerValType = IFX_SIP_COMMENT;
  pcCurrPos = (uchar8 *) (*pcStartIndex + 1);
  while((pcCurrPos < (uchar8 *) pcEndIndex)){
    if((*pcCurrPos >= 0x21 && *pcCurrPos <= 0x27) ||
       (*pcCurrPos >= 0x2a && *pcCurrPos <= 0x5b) ||
       (*pcCurrPos >= 0x5d && *pcCurrPos <= 0x7e) ||
       (*pcCurrPos >= 0xc0 && *pcCurrPos <= 0xdf) ||
       (*pcCurrPos >= 0xe0 && *pcCurrPos <= 0xef) ||
       (*pcCurrPos >= 0xf0 && *pcCurrPos <= 0xfd) ||
       (*pcCurrPos == '\"') ||
       (*pcCurrPos == 0x21) ||
       (*pcCurrPos == ' ') ||
       (*pcCurrPos == '\t') ||
       (*pcCurrPos >= 0x5d && *pcCurrPos <= 0x7e)){
      pcCurrPos++;
      continue;
    }
    else if(*pcCurrPos == '('){
      iCount++;
      pcCurrPos++;
    }
    else if(*pcCurrPos == ')'){
      iCount--;
      pcCurrPos++;
      if(iCount == 0){
        break;
      }
    }
    else{
      pxSipError->eDecodeErr = IFX_SIP_INVALID_COMMENT;
      strcpy(pxSipError->szErrorDesc,"Error in comment grammer");
      return IFX_SIP_FAILURE;
    }
  }
  if((iCount != 0) && (pcCurrPos == (uchar8 *) pcEndIndex)){
    pxSipError->eDecodeErr = IFX_SIP_INVALID_COMMENT;
    strcpy(pxSipError->szErrorDesc,"Error in comment grammer");
    return IFX_SIP_FAILURE;
  }
  if(((pcCurrPos - (uchar8 *) (*pcStartIndex)) >= IFX_SIP_MAX_TOKEN) ||
     ((pcCurrPos - (uchar8 *) (*pcStartIndex)) <= 0)){
    pxSipError->eDecodeErr = IFX_SIP_COMMENT_EXCEEDED;
    strcpy(pxSipError->szErrorDesc,"comment Buffer Exceeded");
    return IFX_SIP_FAILURE;
  }
  strncpy(pxSer->szPrStr,
          *pcStartIndex,
          (pcCurrPos - (uchar8 *) (*pcStartIndex)));
  pxSer->szPrStr[(pcCurrPos - (uchar8 *) (*pcStartIndex))] = '\0';
  *pcStartIndex = pcCurrPos;
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeRetryParam
*  Description  :  Decodes the Accept parameters
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        :   
*********************************************************************/

e_IFX_SIP_Return
IFX_SIP_DecodeRetryParam(IN  char8* pcStartIndex,
                          IN  char8* pcEndIndex,
                          OUT x_IFX_SIP_RetryParam* pxRetryParam,
                          OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcCurrPos, * pcTempEnd;
  uint32 i;
  pcTempStart = pcStartIndex;

  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'=');
  if(pcCurrPos == NULL){
    pxRetryParam->eRetryParamType = IFX_SIP_GEN_PARAM;
    if(IFX_SIP_DecodeGenericParams(pcTempStart,pcEndIndex,&pxRetryParam->
      uxRetryParamType.xGenericParam,pxSipError) == IFX_SIP_FAILURE){
      return IFX_SIP_FAILURE;
    }
  }
  else{
    pcTempEnd = pcCurrPos;
    /* Remove any Trailing Spaces */
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd < pcTempStart){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid message format");
        return IFX_SIP_FAILURE;
      }
    } 
    i = pcTempEnd - pcTempStart;

    if(strncmp(pcTempStart,"duration",IFX_SIP_MAX(i,strlen("duration"))) == 0){
      pxRetryParam->eRetryParamType = IFX_SIP_DURATION;
      pcTempStart = pcCurrPos + 1;/* As it is pointing to = */

      /* Remove any Leading Spaces */
      while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
        pcTempStart++;
        if(pcTempStart > pcEndIndex){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
          strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
          return IFX_SIP_FAILURE;
        }
      }

      pcCurrPos = pcTempStart;
      if(pcCurrPos == pcEndIndex){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid msg fmt");
        return IFX_SIP_FAILURE;
      }

      while(pcCurrPos < pcEndIndex){
        if(!isdigit(*pcCurrPos)){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid msg fmt");
          return IFX_SIP_FAILURE;
        }
        pcCurrPos++;
      }
      pxRetryParam->uxRetryParamType.iDeltaSec = atoi(pcTempStart);
    }
    else{
      pxRetryParam->eRetryParamType = IFX_SIP_GEN_PARAM;
      if(IFX_SIP_DecodeGenericParams(pcTempStart, pcEndIndex, &pxRetryParam->
         uxRetryParamType.xGenericParam, pxSipError) == IFX_SIP_FAILURE){
        return IFX_SIP_FAILURE;
      }
    }
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_SIP_DecodeWarningValue
*  Description  :  Decodes the Warning value
*  Input Values :  Start and End indices 
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        :   
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeWarningValue(IN  char8* pcStartIndex,
                            IN  char8* pcEndIndex,
                            OUT x_IFX_SIP_WarningValue* pxWarnVal,
                            OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcCurrPos, * pCurrPosHostPort;
  uint16 unCount = 0;
  char8 acDataExtracted[40];
  x_IFX_SIP_HostPort xHostPort;

  pcCurrPos = pcStartIndex;
  unCount = 0;

  while((pcCurrPos <= pcEndIndex) && (*pcCurrPos != ' ')){
    acDataExtracted[unCount++] = *pcCurrPos;
    pcCurrPos++;
  }
  if(pcCurrPos > pcEndIndex){
    pxSipError->eDecodeErr = IFX_SIP_DECODE_END_POINTER;
    strcpy(pxSipError->szErrorDesc,"Not sufficient Info");
    return IFX_SIP_FAILURE;
  }

  if(unCount != 3){
    pxSipError->eDecodeErr = IFX_SIP_DECODE_CODE_MORE_DIGIT;
    strcpy(pxSipError->szErrorDesc,"is not three digits");
    return IFX_SIP_FAILURE;
  }

  acDataExtracted[unCount] = '\0';
  pxWarnVal->nWarnCode = atoi(acDataExtracted);
  pcCurrPos++;

  if(pcCurrPos > pcEndIndex){
    pxSipError->eDecodeErr = IFX_SIP_DECODE_END_POINTER;
    strcpy(pxSipError->szErrorDesc,"Not sufficient Info");
    return IFX_SIP_FAILURE;
  }

  unCount = 0;
  pCurrPosHostPort = pcCurrPos;
  while((pcCurrPos <= pcEndIndex) && (*pcCurrPos != ' ')){
    acDataExtracted[unCount++] = *pcCurrPos;
    pcCurrPos++;
  }

  if(pcCurrPos > pcEndIndex){
    pxSipError->eDecodeErr = IFX_SIP_DECODE_END_POINTER;
    strcpy(pxSipError->szErrorDesc,"Not sufficient Info");
    return IFX_SIP_FAILURE;
  }
  acDataExtracted[unCount] = '\0';
  if(IFX_SIP_DecodeValidateToken(acDataExtracted) == IFX_SIP_SUCCESS){
    strcpy(pxWarnVal->szWarnAgent,acDataExtracted);
  }
  else if((IFX_SIP_DecodeHostPort(pCurrPosHostPort,
                                   pcCurrPos,
                                   &xHostPort,
                                   pxSipError)) ==
          IFX_SIP_SUCCESS){
    pxSipError->eDecodeErr = IFX_SIP_DECODE_WRONG_WARN_AGENT;
    strcpy(pxSipError->szErrorDesc,"Incorrect Warn Agent");
    return IFX_SIP_FAILURE;
  }
  pcCurrPos++;
  /* Remove any Leading white spaces */
  while(*pcCurrPos == ' '){
    pcCurrPos++;
    if(pcCurrPos > pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
      return IFX_SIP_FAILURE;
    }
  }

  if(*pcCurrPos != 0x22){
    pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
    strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
    return IFX_SIP_FAILURE;
  }

  if((pcEndIndex - pcCurrPos) > IFX_SIP_MAX_TOKEN){
    pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
    strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
    return IFX_SIP_FAILURE;
  }

  strncpy(pxWarnVal->szWarnText,pcCurrPos,(pcEndIndex - pcCurrPos));
  pxWarnVal->szWarnText[(pcEndIndex - pcCurrPos)] = '\0';

  if(IFX_SIP_ValidateQuotedString(pxWarnVal->szWarnText) == IFX_SIP_FAILURE){
    pxSipError->eDecodeErr = IFX_SIP_INVALID_QUOTEDSTRING;
    strcpy(pxSipError->szErrorDesc,"Invalid warn text");
    return IFX_SIP_FAILURE;
  } 
  return IFX_SIP_SUCCESS;
}

/* Added for draft-ietf-sip-replaces-02.txt */

/******************************************************************
*  Function Name:  IFX_SIP_DecodeReplaceParams
*  Description  :  Decodes the Replaces parameters
*  Input Values :  Start and End indices of To parameters
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeReplaceParams(IN  char8* pcStartIndex,
                             IN  char8* pcEndIndex,
                             OUT x_IFX_SIP_ReplaceParams* pxParam,
                             OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcTempStart, * pcCurrPos, * pcTempEnd;

  pcTempStart = pcStartIndex;

  pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'=');
  if(pcCurrPos != NULL){
    pcTempEnd = pcCurrPos;

    /* Remove any Trailing Spaces */
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd < pcTempStart){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid message format");
        return IFX_SIP_FAILURE;
      }
    }

    if((strncmp(pcTempStart,
                "from-tag",
                IFX_SIP_MAX((uint32) (pcTempEnd - pcTempStart),
                             strlen("from-tag"))) ==
        0) ||
       (strncmp(pcTempStart,
                "to-tag",
                IFX_SIP_MAX((uint32) (pcTempEnd - pcTempStart),
                             strlen("to-tag"))) ==
        0)){
      /* Set the replaces param type appropriately */
      if(strncmp(pcTempStart,
                 "to-tag",
                 IFX_SIP_MAX((uint32) (pcTempEnd - pcTempStart),
                              strlen("to-tag"))) ==
         0){
        pxParam->eParamType = IFX_SIP_RP_TOTAG;
      }
      else{
        pxParam->eParamType = IFX_SIP_RP_FROMTAG;
      }

      pcTempStart = pcCurrPos + 1;/* As it points to = */

      /* Remove any leading spaces after  = */
      while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
        pcTempStart++;
        if(pcTempStart > pcEndIndex){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
          strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
          return IFX_SIP_FAILURE;
        }
      }

      if(((pcEndIndex - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
         ((pcEndIndex - pcTempStart) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_TAGPARM_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Tag Param token exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxParam->uxRepParamType.szTagParam,
              pcTempStart,
              (pcEndIndex - pcTempStart));
      pxParam->uxRepParamType.szTagParam[(pcEndIndex - pcTempStart)] = '\0';
      /* Validate Tag Param */
      if(IFX_SIP_ValidateToken(pxParam->uxRepParamType.szTagParam) ==
         IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_TAGPARAM;
        strcpy(pxSipError->szErrorDesc,"Invalid Tag Param");
        return IFX_SIP_FAILURE;
      }
    }
    else{
      pxParam->eParamType = IFX_SIP_RP_GENPARAM;
      if(((pcTempEnd - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
         ((pcTempEnd - pcTempStart) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Gen Param token exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxParam->uxRepParamType.xGenericParam.szToken, pcTempStart,
              (pcTempEnd - pcTempStart));
      pxParam->uxRepParamType.xGenericParam.
                            szToken[(pcTempEnd - pcTempStart)] = '\0';

      /* Validate Generic Param Token */
      if(IFX_SIP_ValidateToken(pxParam->uxRepParamType.xGenericParam.
        szToken) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
        strcpy(pxSipError->szErrorDesc,"Invalid Generic Param");
        return IFX_SIP_FAILURE;
      }
      pcTempStart = pcCurrPos + 1;

      /* Remove any spaces after = */
      while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
        pcTempStart++;
        if(pcTempStart > pcEndIndex){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
          strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
          return IFX_SIP_FAILURE;
        }
      }

      if(((pcEndIndex - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
         ((pcEndIndex - pcTempStart) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Gen value in genparam exceeded");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxParam->uxRepParamType.xGenericParam.szGenValue, pcTempStart,
              (pcEndIndex - pcTempStart));
      pxParam->uxRepParamType.xGenericParam.
                              szGenValue[(pcEndIndex - pcTempStart)] = '\0';

      /* Validate Gen Param genvalue */
      if(IFX_SIP_ValidateGenValue(pxParam->uxRepParamType.xGenericParam.
        szGenValue) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_GENVALUE;
        strcpy(pxSipError->szErrorDesc,"Invalid Gen Value in GenParam");
        return IFX_SIP_FAILURE;
      }
    }
  }
  else{
    pxParam->eParamType = IFX_SIP_RP_GENPARAM;

    if(((pcEndIndex - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
       ((pcEndIndex - pcTempStart) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Gen Param token exceeded");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxParam->uxRepParamType.xGenericParam.szToken, pcTempStart,
            (pcEndIndex - pcTempStart));
    pxParam->uxRepParamType.xGenericParam.
                                szToken[(pcEndIndex - pcTempStart)] = '\0';
    /* Validate Gen Param Token */
    if(IFX_SIP_ValidateToken(pxParam->uxRepParamType.xGenericParam.szToken) ==
       IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
      strcpy(pxSipError->szErrorDesc,"Invalid Generic Param");
      return IFX_SIP_FAILURE;
    }
  }
  return IFX_SIP_SUCCESS;
}


/******************************************************************
 * *  Function Name:  IFX_SIP_ValidateToken_NoDot
 * *  Description  :  validates token without dot
 * *  Input Values :  Input string to validate
 * *  Output Values:  none
 * *  Return Value :  Success/Failure of decoding
 * *  Notes        :
 * *********************************************************************/
e_IFX_SIP_Return
IFX_SIP_ValidateToken_NoDot(char8* pszBuff)
{
  uint32 i;
  for(i = 0; i < strlen(pszBuff); i++){
    if(isalnum(pszBuff[i]) ||
       pszBuff[i] == '-' ||
       pszBuff[i] == '!' ||
       pszBuff[i] == '%' ||
       pszBuff[i] == '*' ||
       pszBuff[i] == '_' ||
       pszBuff[i] == '+' ||
       pszBuff[i] == '\'' ||
       pszBuff[i] == '`' ||
       pszBuff[i] == '~'){
      continue;
    }
    else{
      break;
    }
  }
  if(i != strlen(pszBuff)){
    return IFX_SIP_FAILURE;
  }
  return IFX_SIP_SUCCESS;
}

/******************************************************************
 *  Function Name:  IFX_SIP_DecodeEvent_Type
 *  Description  :  decodes event type
 *  Input Values :  Start and end indices of Header values
 *  Output Values:  header structure filled, Sip error filled in case of error 
 *  Return Value :  Success/Failure of decoding
 *  Notes        :
 * *********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeEvent_Type(IN  char8* pcStartIndex,
                          IN  char8* pcEndIndex,
                          OUT x_IFX_SIP_EventTypes* pxEvent,
                          OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcCurrPos, * pcTempStart, * pcTempEnd;
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  /* check for the delimiters */
  pcCurrPos = IFX_SIP_strchr(pcStartIndex,pcEndIndex,'.');
  if(pcCurrPos == NULL){
    /* Check for Boundary Condition */
    if((pcEndIndex - pcStartIndex) > IFX_SIP_MAX_TOKEN_NODOT){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
      strcpy(pxSipError->szErrorDesc,"Invalid msg format");
      return IFX_SIP_FAILURE;
    }
    /* Copy the Event Package */
    strncpy(pxEvent->acEventPackage,pcStartIndex,(pcEndIndex - pcStartIndex));
    pxEvent->acEventPackage[pcEndIndex - pcStartIndex] = '\0';
    eRetVal = IFX_SIP_ValidateToken_NoDot(pxEvent->acEventPackage);
    if(eRetVal == IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSG;
      strcpy(pxSipError->szErrorDesc,"Invalid msg format");
      return IFX_SIP_FAILURE;
    }
  }
  else{
    /* To Copy the event Before Dot */
    pcTempEnd = pcCurrPos;
    /* Check for Boundary Condition */
    if((pcTempEnd - pcStartIndex) > IFX_SIP_MAX_TOKEN_NODOT){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
      strcpy(pxSipError->szErrorDesc,"Invalid msg format");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxEvent->acEventPackage,pcStartIndex,(pcTempEnd - pcStartIndex));
    pxEvent->acEventPackage[pcTempEnd - pcStartIndex] = '\0';
    eRetVal = IFX_SIP_ValidateToken_NoDot(pxEvent->acEventPackage);
    if(eRetVal == IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_MSG;
      strcpy(pxSipError->szErrorDesc,"Invalid msg format");
      return IFX_SIP_FAILURE;
    }

    do{
      if(pxEvent->iNumEventTemplate == IFX_SIP_MAX_EVNTTEMPLATE){
        pxSipError->eDecodeErr = IFX_SIP_MAX_EVNTTMPLT_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Max event template exceeded");
        return IFX_SIP_FAILURE;
      }
      pcTempStart = pcCurrPos + 1;  /* Leave the Dot */
      pcCurrPos = IFX_SIP_strchr(pcTempStart,pcEndIndex,'.');
      if(pcCurrPos == NULL){
        pcTempEnd = pcEndIndex;
      }
      else{
        pcTempEnd = pcCurrPos;
      } /* Check for Boundary Condition */
      if((pcTempEnd - pcTempStart) > IFX_SIP_MAX_TOKEN_NODOT){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSG;
        strcpy(pxSipError->szErrorDesc,"Invalid msg format");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxEvent->acEventTemplate[pxEvent->iNumEventTemplate], pcTempStart,
              (pcTempEnd - pcTempStart));
      pxEvent->acEventTemplate[pxEvent->iNumEventTemplate]
                                          [pcTempEnd - pcTempStart] = '\0';
      eRetVal = IFX_SIP_ValidateToken_NoDot(pxEvent->
          acEventTemplate[pxEvent->iNumEventTemplate]);
      if(eRetVal == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSG;
        strcpy(pxSipError->szErrorDesc,"Invalid msg format");
        return IFX_SIP_FAILURE;
      }
      pxEvent->iNumEventTemplate++;
      if(pcCurrPos == NULL){
        break;
      }
    }
    while(1);
  }

  return IFX_SIP_SUCCESS;
}

/******************************************************************
 * *  Function Name:  IFX_SIP_DecodeEvent_GnrPrm
 * *  Description  :  Decode event params
 * *  Input Values :  start and end indices from input buffer
 * *  Output Values:  populated event hdr struct, error if any
 * *  Return Value :  Success/Failure of decoding
 * *  Notes        :
 * *********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeEvent_GnrPrm(IN  char8* pcStartIndex,
                            IN  char8* pcEndIndex,
                            OUT x_IFX_SIP_EventHdr* pxEventHdr,
                            OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcCurrPos, * pcTempStart, * pcTempEnd;
  int32 i;
  pcCurrPos = IFX_SIP_strchr(pcStartIndex,pcEndIndex,'=');
  if(pcCurrPos == NULL){
    /* Generic param with out gen-value */
    pxEventHdr->axEventParam[pxEventHdr->iNumEventParam].
                             eEventParamType = IFX_SIP_EPT_GENPARAM;
    if(((pcEndIndex - pcStartIndex) > IFX_SIP_MAX_TOKEN) ||
       ((pcEndIndex - pcStartIndex) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Generic param excedded(Token)");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxEventHdr->axEventParam[pxEventHdr->iNumEventParam].
      uxEventParamType.xGenericParam.szToken,
            pcStartIndex,
            (pcEndIndex - pcStartIndex));
    pxEventHdr->axEventParam[pxEventHdr->iNumEventParam].uxEventParamType.
    xGenericParam.szToken[(pcEndIndex - pcStartIndex)] = '\0';

    /* Validate Gen Param */
    if(IFX_SIP_ValidateToken(pxEventHdr->axEventParam[pxEventHdr->
      iNumEventParam].uxEventParamType.xGenericParam.szToken) ==
       IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
      strcpy(pxSipError->szErrorDesc,"Invalid token");
      return IFX_SIP_FAILURE;
    }
  }
  else{
    pcTempEnd = pcCurrPos;
    /* Remove any Trailing Spaces */
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd < pcStartIndex){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid message format");
        return IFX_SIP_FAILURE;
      }
    }
    i = pcTempEnd - pcStartIndex;
    if(strncmp(pcStartIndex,"id",IFX_SIP_MAX(i,strlen("id"))) == 0){
      /* Id parameters present */
      pxEventHdr->axEventParam[pxEventHdr->iNumEventParam].
                                       eEventParamType = IFX_SIP_EPT_ID;
      pcTempStart = pcCurrPos + 1; /* As it is pointing to = */
      /* Remove any Leading Spaces */
      while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
        pcTempStart++;
        if(pcTempStart > pcEndIndex){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
          strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
          return IFX_SIP_FAILURE;
        }
      }
      pcTempEnd = pcEndIndex;
      while((*(pcTempEnd - 1) == ' ') || (*(pcStartIndex - 1) == '\t')){
        pcTempEnd--;
        if(pcTempEnd < pcTempStart){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid message format");
          return IFX_SIP_FAILURE;
        }
      }
      /* Copy the ID */
      strncpy(pxEventHdr->axEventParam[pxEventHdr->iNumEventParam].
      uxEventParamType.cID,pcTempStart,(pcTempEnd - pcTempStart));
    } /* If it is not "id" */
    else{
      /*Generic parameters with token an gen value */
      pxEventHdr->axEventParam[pxEventHdr->iNumEventParam].
                               eEventParamType = IFX_SIP_EPT_GENPARAM;
      if((i >= IFX_SIP_MAX_TOKEN) || (i <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Generic param excedded(Token)");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxEventHdr->axEventParam[pxEventHdr->iNumEventParam].
          uxEventParamType.xGenericParam.szToken,pcStartIndex,i);
      pxEventHdr->axEventParam[pxEventHdr->iNumEventParam].
      uxEventParamType.xGenericParam.szToken[i] = '\0';

      /* Validate Gen Param */
      if(IFX_SIP_ValidateToken(pxEventHdr->axEventParam[pxEventHdr->
      iNumEventParam].uxEventParamType.xGenericParam.szToken) ==
         IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
        strcpy(pxSipError->szErrorDesc,"Invalid token");
        return IFX_SIP_FAILURE;
      }
      pcTempStart = pcCurrPos + 1; /* As it is pointing to = */
      /* Remove any Leading Spaces */
      while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
        pcTempStart++;
        if(pcTempStart > pcEndIndex){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
          strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
          return IFX_SIP_FAILURE;
        }
      }
      if(((pcEndIndex - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
         ((pcEndIndex - pcTempStart) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Generic param excedded(GenValue)");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxEventHdr->axEventParam[pxEventHdr->iNumEventParam].
          uxEventParamType.xGenericParam.szGenValue, pcTempStart,
              (pcEndIndex - pcTempStart));
      pxEventHdr->axEventParam[pxEventHdr->iNumEventParam].uxEventParamType.
                  xGenericParam.szGenValue[(pcEndIndex - pcTempStart)] = '\0';
      /* Validate Gen Param */
      if(IFX_SIP_ValidateGenValue(pxEventHdr->axEventParam[pxEventHdr->
      iNumEventParam].uxEventParamType.xGenericParam.szGenValue) ==
         IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_GENVALUE;
        strcpy(pxSipError->szErrorDesc,"Invalid Gen Value in GenParam");
        return IFX_SIP_FAILURE;
      }
    }
  }
  return IFX_SIP_SUCCESS;
}


/******************************************************************
 * *  Function Name:  IFX_SIP_Decode_Subexp_EventRsnVal
 * *  Description  :  Decode Reason value
 * *  Input Values :  start and end indices from input buffer
 * *  Output Values:  populated event hdr struct, error if any
 * *  Return Value :  Success/Failure of decoding
 * *  Notes        :
 * *********************************************************************/
e_IFX_SIP_Return
IFX_SIP_Decode_Subexp_EventRsnVal(IN  char8* pcStartIndex,
                                   IN  char8* pcEndIndex,
                                   OUT x_IFX_SIP_EvntRsn* pxEvntRsn,
                                   OUT x_IFX_SIP_Error* pxSipError)
{
  if((strcmp(pxEvntRsn->cEventReasonExtn,"deactivated")) == 0){
    pxEvntRsn->eEvntRsn = IFX_SIP_EVNTRSN_DEACTIVATED;
  }
  else if((strcmp(pxEvntRsn->cEventReasonExtn,"probation")) == 0){
    pxEvntRsn->eEvntRsn = IFX_SIP_EVNTRSN_PROBATION;
  }
  else if((strcmp(pxEvntRsn->cEventReasonExtn,"rejected")) == 0){
    pxEvntRsn->eEvntRsn = IFX_SIP_EVNTRSN_REJECTED;
  }
  else if((strcmp(pxEvntRsn->cEventReasonExtn,"timeout")) == 0){
    pxEvntRsn->eEvntRsn = IFX_SIP_EVNTRSN_TIMEOUT;
  }
  else if((strcmp(pxEvntRsn->cEventReasonExtn,"giveup")) == 0){
    pxEvntRsn->eEvntRsn = IFX_SIP_EVNTRSN_GIVEUP;
  }
  else if((strcmp(pxEvntRsn->cEventReasonExtn,"noresource")) == 0){
    pxEvntRsn->eEvntRsn = IFX_SIP_EVNTRSN_NORESOURSE;
  }
  else{
         pxEvntRsn->eEvntRsn = IFX_SIP_EVNTRSN_EXT;
    if((IFX_SIP_ValidateToken(pxEvntRsn->cEventReasonExtn)) ==
       IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
      strcpy(pxSipError->szErrorDesc,"Invalid extension Method");
      return IFX_SIP_FAILURE;
    }
  }
  return IFX_SIP_SUCCESS;
}


/******************************************************************
 * *  Function Name:  IFX_SIP_DecodeSubexp_Param
 * *  Description  :  Decode event params
 * *  Input Values :  start and end indices from input buffer
 * *  Output Values:  populated event hdr struct, error if any
 * *  Return Value :  Success/Failure of decoding
 * *  Notes        :
 * *********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeSubexp_Param(IN  char8* pcStartIndex,
                            IN  char8* pcEndIndex,
                            OUT x_IFX_SIP_SubExpParams* pxSubExParam,
                            OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcCurrPos, * pcTempStart, * pcTempEnd, * pcTemp;
  e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
  int32 i;
  pcCurrPos = IFX_SIP_strchr(pcStartIndex,pcEndIndex,'=');
  if(pcCurrPos == NULL){
    /* Generic param   */
    pxSubExParam->eSubExpParams = IFX_SIP_SUBEXP_GENPARAM;
    if(((pcEndIndex - pcStartIndex) > IFX_SIP_MAX_TOKEN) ||
       ((pcEndIndex - pcStartIndex) <= 0)){
      pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
      strcpy(pxSipError->szErrorDesc,"Generic param excedded(Token)");
      return IFX_SIP_FAILURE;
    }
    strncpy(pxSubExParam->ux_SubParams.xGenParamas.szToken, pcStartIndex,
            (pcEndIndex - pcStartIndex));

    pxSubExParam->ux_SubParams.xGenParamas.
                              szToken[(pcEndIndex - pcStartIndex)] = '\0';

    /* Validate Gen Param */
    if(IFX_SIP_ValidateToken(pxSubExParam->ux_SubParams.xGenParamas.szToken) ==
       IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
      strcpy(pxSipError->szErrorDesc,"Invalid token");
      return IFX_SIP_FAILURE;
    }
  }
  else{
    pcTempEnd = pcCurrPos;
    /* Remove any Trailing Spaces */
    while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
      pcTempEnd--;
      if(pcTempEnd < pcStartIndex){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
        strcpy(pxSipError->szErrorDesc,"Invalid message format");
        return IFX_SIP_FAILURE;
      }
    }
    i = pcTempEnd - pcStartIndex;
    if(strncmp(pcStartIndex,"reason",IFX_SIP_MAX(i,strlen("reason"))) == 0){
      /* Id parameters present */
      pxSubExParam->eSubExpParams = IFX_SIP_SUBEXP_REASON;
      pcTempStart = pcCurrPos + 1; /* As it is pointing to = */
      /* Remove any Leading Spaces */
      while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
        pcTempStart++;
        if(pcTempStart > pcEndIndex){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
          strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
          return IFX_SIP_FAILURE;
        }
      }
      pcTempEnd = pcEndIndex;
      while((*(pcTempEnd - 1) == ' ') || (*(pcTempEnd - 1) == '\t')){
        pcTempEnd--;
        if(pcTempEnd < pcTempStart){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid message format");
          return IFX_SIP_FAILURE;
        }
      }
      if(((pcTempEnd - pcTempStart) > IFX_SIP_MAX_EVNTRSNEXTN)){
        pxSipError->eDecodeErr = IFX_SIP_MAX_EVENTRSN_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"MAX Event Reason exceeded");
        return IFX_SIP_FAILURE;
      }
      /* Copy the Reason */
      strncpy(pxSubExParam->ux_SubParams.xEvntRsn.cEventReasonExtn,
              pcTempStart,
              (pcTempEnd - pcTempStart));
      /* make it string */
      pxSubExParam->ux_SubParams.xEvntRsn.
                            cEventReasonExtn[pcTempEnd - pcTempStart] = '\0';

      eRetVal = IFX_SIP_Decode_Subexp_EventRsnVal(pcTempStart, pcTempEnd,
                   &(pxSubExParam->ux_SubParams.xEvntRsn), pxSipError);
    } /* If it is not "reason" */
    else if(strncmp(pcStartIndex,"expires",IFX_SIP_MAX(i,strlen("expires"))) ==
            0){
      /* Id parameters present */
      pxSubExParam->eSubExpParams = IFX_SIP_SUBEXP_EXPIRES;
      pcTempStart = pcCurrPos + 1; /* As it is pointing to = */
      /* Remove any Leading Spaces */
      while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
        pcTempStart++;
        if(pcTempStart > pcEndIndex){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
          strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
          return IFX_SIP_FAILURE;
        }
      }
      pcTempEnd = pcEndIndex;
      while((*(pcTempEnd - 1) == ' ') || (*(pcStartIndex - 1) == '\t')){
        pcTempEnd--;
        if(pcTempEnd < pcTempStart){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid message format");
          return IFX_SIP_FAILURE;
        }
      }
      pcTemp = pcTempStart;
      while(pcTemp < pcTempEnd){
        if(!isdigit(*pcTemp)){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid message format");
          return IFX_SIP_FAILURE;
        }
        pcTemp++;
      }
      /* Copy the expires */
      pxSubExParam->ux_SubParams.iexpires = atoi(pcTempStart);
    } /* If it is not "expires" */
    else if(strncmp(pcStartIndex,
                    "retry-after",
                    IFX_SIP_MAX(i,strlen("retry-after"))) == 0){
      /* Id parameters present */
      pxSubExParam->eSubExpParams = IFX_SIP_SUBEXP_RETRYAFTER;
      pcTempStart = pcCurrPos + 1; /* As it is pointing to = */
      /* Remove any Leading Spaces */
      while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
        pcTempStart++;
        if(pcTempStart > pcEndIndex){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
          strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
          return IFX_SIP_FAILURE;
        }
      }
      pcTempEnd = pcEndIndex;
      while((*(pcTempEnd - 1) == ' ') || (*(pcStartIndex - 1) == '\t')){
        pcTempEnd--;
        if(pcTempEnd < pcTempStart){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_DIGIT;
          strcpy(pxSipError->szErrorDesc,"Invalid retry-after value");
          return IFX_SIP_FAILURE;
        }
      }
      pcTemp = pcTempStart;
      while(pcTemp < pcTempEnd){
        if(!isdigit(*pcTemp)){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_MSGFMT;
          strcpy(pxSipError->szErrorDesc,"Invalid message format");
          return IFX_SIP_FAILURE;
        }
        pcTemp++;
      }
      pxSubExParam->ux_SubParams.iRetryAfter = atoi(pcTempStart);
    } /* If it is not "retry-after" */
    else{
      /*Generic parameters with token an gen value */
      pxSubExParam->eSubExpParams = IFX_SIP_SUBEXP_GENPARAM;

      if((i >= IFX_SIP_MAX_TOKEN) || (i <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Generic param excedded(Token)");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxSubExParam->ux_SubParams.xGenParamas.szToken,pcStartIndex,i);

      pxSubExParam->ux_SubParams.xGenParamas.szToken[i] = '\0';

      /* Validate Gen Param */
      if(IFX_SIP_ValidateToken(pxSubExParam->ux_SubParams.xGenParamas.szToken)
          == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
        strcpy(pxSipError->szErrorDesc,"Invalid token");
        return IFX_SIP_FAILURE;
      }
      pcTempStart = pcCurrPos + 1; /* As it is pointing to = */
      /* Remove any Leading Spaces */
      while((*pcTempStart == ' ') || (*pcTempStart == '\t')){
        pcTempStart++;
        if(pcTempStart > pcEndIndex){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
          strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
          return IFX_SIP_FAILURE;
        }
      }
      if(((pcEndIndex - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
         ((pcEndIndex - pcTempStart) <= 0)){
        pxSipError->eDecodeErr = IFX_SIP_GENPARMTOK_EXCEEDED;
        strcpy(pxSipError->szErrorDesc,"Generic param excedded(GenValue)");
        return IFX_SIP_FAILURE;
      }
      strncpy(pxSubExParam->ux_SubParams.xGenParamas.szGenValue, pcTempStart,
              (pcEndIndex - pcTempStart));

      pxSubExParam->ux_SubParams.xGenParamas.
                               szGenValue[(pcEndIndex - pcTempStart)] = '\0';
      /* Validate Gen Param */
      if(IFX_SIP_ValidateGenValue(pxSubExParam->ux_SubParams.xGenParamas.
              szGenValue) == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_GENVALUE;
        strcpy(pxSipError->szErrorDesc,"Invalid Gen Value in GenParam");
        return IFX_SIP_FAILURE;
      }
    }
  }
  return IFX_SIP_SUCCESS;
}


/******************************************************************
 *  Function Name:  IFX_SIP_DecodeSubState_Value
 *  Description  :
 *  Input Values :  Start and end indices of Header values
 *  Output Values:  header structure filled, Sip error filled in case of error   *  Return Value :  Success/Failure of decoding
 *  Notes        :
 * *********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeSubState_Value(IN  char8* pcStartIndex,
                              IN  char8* pcEndIndex,
                              OUT x_IFX_SIP_SubState* pxSubState,
                              OUT x_IFX_SIP_Error* pxSipError)
{
  /*
  char8 *pcCurrPos, *pcTempStart, *pcTempEnd;
    e_IFX_SIP_Return eRetVal = IFX_SIP_SUCCESS;
    */
  x_IFX_SIP_SubStateVal* pxSubStEv;

  pxSubStEv = &(pxSubState->xSubStateVal);

  if(((pcEndIndex - pcStartIndex) > IFX_SIP_MAX_SUBSTATE)){
    pxSipError->eDecodeErr = IFX_SIP_MAX_SUBSTATE_EXCEEDED;
    strcpy(pxSipError->szErrorDesc,"MAX SUB State exceeded");
    return IFX_SIP_FAILURE;
  }
  /* Copy the Substate Value */
  strncpy(pxSubStEv->cSubStateExtn,pcStartIndex,(pcEndIndex - pcStartIndex));
  /* make it a string */
  pxSubStEv->cSubStateExtn[pcEndIndex - pcStartIndex] = '\0';

  if((strcmp(pxSubStEv->cSubStateExtn,"active")) == 0){
    pxSubStEv->eSubState = IFX_SIP_SUBSTATE_ACTIVE;
  }
  else if((strcmp(pxSubStEv->cSubStateExtn,"pending")) == 0){
    pxSubStEv->eSubState = IFX_SIP_SUBSTATE_PENDING;
  }
  else if((strcmp(pxSubStEv->cSubStateExtn,"terminated")) == 0){
    pxSubStEv->eSubState = IFX_SIP_SUBSTATE_TERMINATED;
  }
  else{
         pxSubStEv->eSubState = IFX_SIP_SUBSTATE_EXTN;
    if((IFX_SIP_ValidateToken(pxSubStEv->cSubStateExtn)) == IFX_SIP_FAILURE){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
      strcpy(pxSipError->szErrorDesc,"Invalid extension Method");
      return IFX_SIP_FAILURE;
    }
  }
  return IFX_SIP_SUCCESS;
}


#ifdef RFC_4028
/******************************************************************
*  Function Name:  IFX_SIP_DecodeRefresherParam
*  Description  :
*  Input Values :  Start and end indices of Header body values
*  Output Values:  header structure filled, Sip error filled in case of error  
*  Return Value :  Success/Failure of decoding
*  Notes        :
**************************MODIFICATION HISTORY****************************
* DATE              Tracking Info               Description
**************************************************************************
* 12-07-05  IFX_iip_devel_ph2.1_santosh/1   Initial Version
***************************************************************************/ 
e_IFX_SIP_Return
IFX_SIP_DecodeRefresherParam(IN  char8* pcStartIndex,
                              IN  char8* pcEndIndex,
                              OUT x_IFX_SIP_RefresherParam* pxRefresher,
                              OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcCurrPos;
  pcCurrPos = pcStartIndex;
  /* Remove any leading spaces */
  while((*pcCurrPos == ' ') || (*pcCurrPos == '\t')){
    pcCurrPos++;
    if(pcCurrPos > pcEndIndex){
      pxSipError->eDecodeErr = IFX_SIP_INVALID_FMT;
      strcpy(pxSipError->szErrorDesc,"Invalid Msg Format");
      return IFX_SIP_FAILURE;
    }
  }
  
  if(IFX_SIP_strncasecmp(pcCurrPos,"uas",3) == 0){
    pxRefresher->eRefresher = IFX_SIP_UAS;
    return IFX_SIP_SUCCESS;
  }
  if(IFX_SIP_strncasecmp(pcCurrPos,"uac",3) == 0){
    pxRefresher->eRefresher = IFX_SIP_UAC;
    return IFX_SIP_SUCCESS;
  }
  return IFX_SIP_SUCCESS;
}
#endif /* RFC_4028 */

/******************************************************************
*  Function Name:  IFX_SIP_DecodeDiversionParam
*  Description  :  Decodes the Diversion parameters
*  Input Values :  Start and End indices of Diversion parameters
*  Output Values:  Fills the structure passed, error info in case of failure
*  Return Value :  Success/Failure of decoding
*  Notes        : 
*********************************************************************/
e_IFX_SIP_Return
IFX_SIP_DecodeDiversionParam(IN  char8* pcStartIndex,
                              IN  char8* pcEndIndex,
                              OUT x_IFX_SIP_DivParam* pxDivParam,
                              OUT x_IFX_SIP_Error* pxSipError)
{
  char8* pcCurrPos, * pcTempStart, cRet, acTemp[IFX_SIP_MAX_TOKEN];
  int32 i, iCount;
  e_IFX_SIP_Return eRetVal;
  pcTempStart = pcCurrPos = pcStartIndex; 

  /* Leading spaces would have been removed */ 
  cRet = IFX_SIP_strtok(pcTempStart,pcEndIndex,&pcCurrPos,"=");
  switch(cRet){
    case '=':
    {
      for(i = 0; i < IFX_SIP_DIV_EXTN; i++){
        if(strncmp(pcTempStart,vtblszDivParams[i],
           IFX_SIP_MAX(strlen(vtblszDivParams[i]),
           (uint32)(pcCurrPos - pcTempStart))) == 0){
            break;
        }
      }
      /* Copy the remaining part after = into a temp buffer */
      if(((pcEndIndex - (pcCurrPos+1)) >= IFX_SIP_MAX_TOKEN) ||
         ((pcEndIndex - (pcCurrPos+1)) <= 0)){
         pxSipError->eDecodeErr = IFX_SIP_TOKEN_EXCEEDED;
         strcpy(pxSipError->szErrorDesc,
                "Diversion value exceeded");
         return IFX_SIP_FAILURE;
      }
      strncpy(acTemp,(pcCurrPos+1),(pcEndIndex - (pcCurrPos+1)));
      acTemp[(pcEndIndex -(pcCurrPos+1)) ] = '\0';
      /* Validate token or quoted string */
      if(*(pcCurrPos+1) == '\"'){
        eRetVal = IFX_SIP_ValidateQuotedString(acTemp); 
      }
      else{
        eRetVal = IFX_SIP_ValidateToken(acTemp);
      }
      if(eRetVal == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
        strcpy(pxSipError->szErrorDesc,"Invalid Diversion Value");
        return IFX_SIP_FAILURE;
      }

      if(i == IFX_SIP_DIV_EXTN){
        pxDivParam->eDivType = IFX_SIP_DIV_EXTN;
        if(((pcCurrPos - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
           ((pcCurrPos - pcTempStart) <= 0)){
           pxSipError->eDecodeErr = IFX_SIP_OTHERPARM_EXCEEDED;
           strcpy(pxSipError->szErrorDesc,
                  "Diversion Extension name exceeded the limit");
            return IFX_SIP_FAILURE;
        }
        strncpy(pxDivParam->uxDivType.xDivExtn.szDivExtnName,pcTempStart,
                        (pcCurrPos - pcTempStart));
        pxDivParam->uxDivType.xDivExtn.szDivExtnName
                [(pcCurrPos - pcTempStart)] = '\0';
        if(IFX_SIP_ValidateToken(pxDivParam->uxDivType.xDivExtn.szDivExtnName)
                        == IFX_SIP_FAILURE){
          pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
          strcpy(pxSipError->szErrorDesc,"Invalid Diversion Extension name");
          return IFX_SIP_FAILURE;
        }
        strcpy(pxDivParam->uxDivType.xDivExtn.szDivExtnValue,acTemp);
      }
      /* No white spaces allowed after ; */
      switch(i){
        case IFX_SIP_DIV_REASON:
        {
          pxDivParam->eDivType = IFX_SIP_DIV_REASON;
          for(iCount = 0; iCount < IFX_SIP_DIV_TOKEN; iCount++){
            if(IFX_SIP_strcasecmp(acTemp,vtblszDivReason[iCount]) == 0){
              break;
            }
          }
          if(iCount != IFX_SIP_DIV_TOKEN){
            pxDivParam->uxDivType.xDivReason.eDivRsn = iCount;
          }
          if(acTemp[0] == '\"'){
            pxDivParam->uxDivType.xDivReason.eDivRsn = IFX_SIP_DIV_QUOTEDSTR;
          }
          else{
            pxDivParam->uxDivType.xDivReason.eDivRsn = IFX_SIP_DIV_TOKEN;
          }
          /* Copy the contents */
          strcpy(pxDivParam->uxDivType.xDivReason.szDivRsn,acTemp); 
          break;
        }
        case IFX_SIP_DIV_COUNTER:
        {
          pxDivParam->eDivType = IFX_SIP_DIV_COUNTER;
          pxDivParam->uxDivType.iDivCount = atoi(acTemp);
          if(pxDivParam->uxDivType.iDivCount>999){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_DIGIT;
            strcpy(pxSipError->szErrorDesc,
                       "Diversion counter greater than 999");
            return IFX_SIP_FAILURE;
          }
          break;
        }
        case IFX_SIP_DIV_LIMIT:
        { 
          pxDivParam->eDivType = IFX_SIP_DIV_LIMIT;
          pxDivParam->uxDivType.iDivLimit = atoi(acTemp);
          if(pxDivParam->uxDivType.iDivLimit>999){
            pxSipError->eDecodeErr = IFX_SIP_INVALID_DIGIT;
            strcpy(pxSipError->szErrorDesc,
                       "Diversion Limit greater than 999");
            return IFX_SIP_FAILURE;
          }
          break;
        }
        case IFX_SIP_DIV_PRIVACY:
        {
          pxDivParam->eDivType = IFX_SIP_DIV_PRIVACY;
          for(iCount = 0; iCount < IFX_SIP_DIV_PRIVTOKEN; iCount++){
            if(IFX_SIP_strcasecmp(acTemp,vtblszDivPrivacy[iCount]) == 0){
              break;
            }
          }
          if(iCount != IFX_SIP_DIV_PRIVTOKEN){
            pxDivParam->uxDivType.xDivPrivacy.eDivPriv = iCount;
          }
          else{
            if(acTemp[0] == '\"'){
              pxDivParam->uxDivType.xDivPrivacy.eDivPriv = 
                    IFX_SIP_DIV_PRIVQUOTEDSTR;
            }
            else{
              pxDivParam->uxDivType.xDivPrivacy.eDivPriv = 
                      IFX_SIP_DIV_PRIVTOKEN;
            }
            /* Copy the contents */
            strcpy(pxDivParam->uxDivType.xDivPrivacy.szDivPriv,acTemp); 
          }
          break;     
        }
        case IFX_SIP_DIV_SCREEN:
        {
          pxDivParam->eDivType = IFX_SIP_DIV_SCREEN;
          if(IFX_SIP_strcasecmp(acTemp,"yes")==0){
            pxDivParam->uxDivType.xDivScreen.eDivScreen = IFX_SIP_DIV_YES;     
            strcpy(pxDivParam->uxDivType.xDivScreen.szDivScreen,acTemp); 
          }
          else if(IFX_SIP_strcasecmp(acTemp,"no")==0){
            pxDivParam->uxDivType.xDivScreen.eDivScreen = IFX_SIP_DIV_NO;     
            strcpy(pxDivParam->uxDivType.xDivScreen.szDivScreen,acTemp); 
          }
          else if(acTemp[0] == '\"'){
            pxDivParam->uxDivType.xDivScreen.eDivScreen = 
                    IFX_SIP_DIV_SCRNQUOTEDSTR;     
            /* Copy the contents */
            strcpy(pxDivParam->uxDivType.xDivScreen.szDivScreen,acTemp); 
          }
          else{
            pxDivParam->uxDivType.xDivScreen.eDivScreen=IFX_SIP_DIV_SCRNTOKEN;
            /* Copy the contents */
            strcpy(pxDivParam->uxDivType.xDivScreen.szDivScreen,acTemp); 
          }
          break;      
        }
      }
      break;
    }      
    case IFX_SIP_TOKEN_NOTFOUND:
    {
      /* Copy the extension name */
      pxDivParam->eDivType = IFX_SIP_DIV_EXTN;
      if(((pcCurrPos - pcTempStart) >= IFX_SIP_MAX_TOKEN) ||
         ((pcCurrPos - pcTempStart) <= 0)){
          pxSipError->eDecodeErr = IFX_SIP_OTHERPARM_EXCEEDED;
          strcpy(pxSipError->szErrorDesc,
                  "Diversion Extension name exceeded the limit");
          return IFX_SIP_FAILURE;
      }
      strncpy(pxDivParam->uxDivType.xDivExtn.szDivExtnName,pcTempStart,
              (pcCurrPos - pcTempStart));
      pxDivParam->uxDivType.xDivExtn.szDivExtnName
               [(pcCurrPos - pcTempStart)] = '\0';
      if(IFX_SIP_ValidateToken(pxDivParam->uxDivType.xDivExtn.szDivExtnName)
                       == IFX_SIP_FAILURE){
        pxSipError->eDecodeErr = IFX_SIP_INVALID_TOKEN;
        strcpy(pxSipError->szErrorDesc,"Invalid Diversion Extension name");
        return IFX_SIP_FAILURE;
      }
      break;        
    }
  }
  return IFX_SIP_SUCCESS;
}

