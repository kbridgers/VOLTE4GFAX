/* 
** =============================================================================
**   FILE NAME        : IFX_WanPTMLinkConfig.c
**   PROJECT          : TR69
**   MODULES          : WanDevice
**   DATE             : 03-12-2009
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This module handles ADD/DEL/GET/SET RPCs of
**                      WanPTMLinkConfig. When controller calls this module it
**                      calls respective Platform/Object APIs to handle GET/SET 
**                      of WanPTMLinkConfig specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author        $Comment
**   03-12-09         TR69 team      Intial version
** ============================================================================
*/

/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
 
#include "IFX_DEVM_Global.h"
#include "IFX_DEVM_AdaptCommon.h"
//#include "IFX_DEVM_WANDSLLinkCfg.h"

#include "IFX_DEVM_OID.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_DS.h"
#include "IFX_DEVM_StackUtil.h"
/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/

#define IFX_WANPTM_LINK_OBJ "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPTMLinkConfig."
extern char8 vcOsModId;
extern int32 IFX_SetVCCWanConDevice(int32 *iaOIDDSL,int32 iCaller, int16 Vpi, int32 Vci, char8 * l2iface_name);

int32 IFX_WanPTMLinkConfig(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                IN int32 iElements, OUT void **ppaxParamArrRet, OUT int32 *piNumRetElem);



/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/
#if 0
static int32 
IFX_GetVccObj(ATM_VCC_INFO *ppxAtmVcc, uint32 iCpeid)
{
    uint32 iFlags;
    uint32 iRet=0;
    iFlags = IFX_F_GET_ANY;
    ppxAtmVcc->iid.cpeId.Id=iCpeid;
        
    iRet=ifx_get_one_vcc_info(ppxAtmVcc);    

    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d ifx_get_all_vcc_info failed!\n", __func__, __LINE__);
        goto errorHandler;
    }
    return IFX_CWMP_SUCCESS;    
errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed!\n", __func__, __LINE__);
    return IFIN_CWMP_FAILURE;
}
#endif
/*
** =============================================================================
**   Function Name    : ValidateMac
**   Description      : 
**   Parameters       : 
**   Return Value     : 
** ============================================================================
*/
static int32 ValidateMac(char8 * MacAddr)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    char8 *p1, *p2;
    int32 count = 0;

    if(MacAddr == NULL)
    {
        iRet = IFX_CWMP_FAILURE;
        goto end;
    }
    p1 = p2= MacAddr;

    while((p2 = strchr(p1, ':')) != NULL)
    {
        count++;
        if(((p2-p1) == 0) || ((p2-p1)>2))
        {
            iRet = IFX_CWMP_FAILURE;
            goto end;
        }
        while(p1 != p2)
        {
            if(((*p2 < '0') || (*p2 > '9')) && ((*p2 < 'a') || (*p2 > 'f')) && ((*p2 < 'A') || (*p2 > 'F')))
            {
                iRet = IFX_CWMP_FAILURE;
                goto end;
            }
            p1++;
        }
        p1++;
    }
    
    if(count != 5)
    {
        iRet = IFX_CWMP_FAILURE;
        goto end;
    }
    
end:
    return iRet;    
}

/* 
** =============================================================================
**   Function Name    : GetParamOffset
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

STATIC int32
GetParamOffset(IN int32 *paiOID)
{
    int32 iCnt;

    for (iCnt = 0; paiOID[iCnt] != 0; iCnt++);

    return (iCnt - 1);
}

/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 
GetVal(IN OperInfo *pxOperInfo,INOUT ParamVal *pxParamVal,
                                IN uint32 iElements)
{
    uint32 iCpeid = 0;
    uint32 iCnt = 0;
    int32 iRet= IFX_CWMP_SUCCESS;
    PTM_CH_CFG xPtmChCfg;
    uint32 flags = IFX_F_GET_ANY;
    int32   iParamOffset;

    memset(&xPtmChCfg, 0x00, sizeof(xPtmChCfg));

    /* Get Cpeid from object ID */
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    {
       IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d]\n",_FUNCL_);
        goto end;
    }

    xPtmChCfg.iid.cpeId.Id = iCpeid;

    /* Get match object from system using MAPI */
    iRet= ifx_get_ptm_ch_cfg(&xPtmChCfg, flags);
    if(iRet != IFX_CWMP_SUCCESS)
    {
       IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d]\n",_FUNCL_);
        goto end;
    }

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
       IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d]\n",_FUNCL_);
        iRet = ERR_CWMP_INTERNAL; 
        goto end;
    }

    for( iCnt=0; iCnt<iElements; iCnt++)
    {
        // Malloc and assign the pointer to the Value attr of struct 
        (pxParamVal[iCnt]).Value = IFX_CWMP_MALLOC(20);
        if(pxParamVal[iCnt].Value == NULL)
        {
            iRet = ERR_OUT_OF_MEMORY; 
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d]\n",_FUNCL_);
            goto end;
        }

        switch(pxParamVal[iCnt].iaOID[iParamOffset])
        {
            case OID_IGD_WAND_WANCD_WANPTMLC_ENABLE:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xPtmChCfg.f_enable);
                break;     

            case OID_IGD_WAND_WANCD_WANPTMLC_LINKSTATUS:
                /* Copy the value to allocated area */
                if(xPtmChCfg.f_enable == IFX_DISABLED)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Down");
                }
                else if (xPtmChCfg.f_enable == IFX_ENABLED)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Up");
                }
                else
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Unavailable");
                }
                break;

            case OID_IGD_WAND_WANCD_WANPTMLC_MACADDRESS:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%s", xPtmChCfg.mac_addr);
                break;

            default:
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%d] [Error] Unknown requested parameter %d!\n",
                            _FUNCL_, pxParamVal[iCnt].iaOID[iParamOffset]);
                pxParamVal->iFaultCode=ERR_INVAL_PARAMETER_NAME;
                break;
        }
    }

end:
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : Validate
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
Validate(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
                            IN int32 iElements)
{
    int32 iRet=IFX_CWMP_SUCCESS;
    uint32 iCnt=0;
    int32   iParamOffset;
        
    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL; 
        goto end;
    }

    for( iCnt=0; iCnt<iElements; iCnt++)
    {
        switch(pxParamVal[iCnt].iaOID[iParamOffset])
        {
            case OID_IGD_WAND_WANCD_WANPTMLC_MACADDRESS:
                iRet = ValidateMac(pxParamVal[iCnt].Value);
                break;

            default:
                break;
        }
    }
end:
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
         "%s:%d Validate failed!\n", __func__, __LINE__);
    }
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : AddObj
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
AddObj(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
                            IN int32 iElements)
{
    /*Don't add any PTMLinkConfig sections. We don't add WCD for PTMLinkConfig.
      There is a single WCD for PTMLinkConfig and addition of VLAN objects on that is allowed*/
#if 0
    uint32 iFlags=0;
    int32 iRet=0;
    uint32 iOper;
    uint32 uiPcpeId=0;
    char8 * retStr = NULL;
    char8 sCommand[MAX_FILELINE_LEN];

    PTM_CH_CFG xPtmChCfg;
    memset(&xPtmChCfg, 0, sizeof(xPtmChCfg));

    //If owner is WEB don't add the object just return success.
    if(pxOpInfo->iCaller == ACC_WEB)
        return IFX_CWMP_SUCCESS;

    iRet = IFX_GetParentObjCpeId(pxParamVal->iaOID,&uiPcpeId);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;
    
    //Flags should be filled
    //Fills the Cpeid,ParentCepid,TR69Id,Owner
    //Fill the operation
    iOper = IFX_OP_ADD;
    iFlags =(IFX_F_DONT_ACTIVATE | IFX_F_DONT_CHECKPOINT |
            IFX_F_DONT_VALIDATE  | IFX_F_DONT_WRITE_TO_FLASH);
    
    xPtmChCfg.iid.config_owner=pxOpInfo->iCaller;
    xPtmChCfg.iid.cpeId.Id=0;
    xPtmChCfg.iid.pcpeId.Id=uiPcpeId;
    xPtmChCfg.f_enable = IFX_DISABLED;
    xPtmChCfg.vlanId = IFX_GetRand(LOW_LIMIT_VLANID, UPP_LIMIT_VLANID);

    sprintf(sCommand, "%d", uiPcpeId);
    ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, "wan_conn_dev", "cpeId", sCommand, &retStr);
    if(ret != IFX_SUCCESS)

    	#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	#endif
	goto IFX_Handler;
    }

    /* Get the old link type */
    sprintf(sCommand, "%s_l2ifname", retStr);
    if((ret = ifx_GetObjData(FILE_RC_CONF, "wan_conn_dev", sCommand, IFX_F_GET_ANY, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS)
    {
	#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	#endif
	goto IFX_Handler;
    }
    IFX_MEM_FREE(retStr)

    strcpy(xPtmChCfg.l2ifname, sValue);

    /* Nirint: If WANDevice.{i}. == 1 (ATMWAN) then VLAN = 4096.
       So that Web can mask it. */
    if(pxParamVal->iaOID[2] != WAN_DEVICE_ATM)
    {
        xPtmChCfg.vlanId = WANATM_VLAN_VAL;
    }

    //Convert array into dotted form and then strcpy
    
    iRet = IFX_ConvertOidDottedForm(pxParamVal->iaOID, xPtmChCfg.iid.tr69Id);
    if(iRet != IFX_CWMP_SUCCESS)
    {
        goto errorHandler;
    }

    iRet = ifx_set_ptm_ch_cfg(iOper, &xPtmChCfg, iFlags);
    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"ifx_set_ptm_ch_cfg add Mgmt API \
                                                         returned error\n");
        goto errorHandler;
        
    }
    return IFIN_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed!\n", __func__, __LINE__);
    return IFIN_CWMP_FAILURE;
#endif
    return IFIN_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : Modify
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 Modify(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
                            IN int32 iElements)
{
    uint32 uiCpeid = 0;
    PTM_CH_CFG xPtmChCfg;
    int32 iRet = IFX_CWMP_SUCCESS;
    uint32 iFlags = IFX_F_DEFAULT;
    int32 iaOID[OID_LENGTH];
    char8 *psTmpVal;
    uint32 iCnt = 0, i = 0, iJ = 0;
    int32 iParamOffset = 0;
    ParamVal xInParamVal;
    ParamVal *paxOutParamArr=NULL;
    ParamVal *paxTempParamVal=NULL;
    uint32 uiOutElem=0;
    int32 Wan_IP_Oid[OID_LENGTH]={0, 0, 0, 0, 0, OID_IGD_WAND_WANCD_WANIPC, MAGIC_NUMBER, OID_IGD_WAND_WANCD_WANIPC_ENABLE};
    int32 Wan_PPP_Oid[OID_LENGTH]={0, 0, 0, 0, 0, OID_IGD_WAND_WANCD_WANPPPC, MAGIC_NUMBER, OID_IGD_WAND_WANCD_WANPPPC_ENABLE};
    int32 uiOld_EnableVal = 0,uiNew_EnableVal=0;
    int32 num_vlanchannels = 0;
    vlan_ch_cfg_t * xVlanArr = NULL;
    IFX_ID ParentIID;
    vlan_ch_cfg_t vlan_entry;

    memset(iaOID,0x00,(sizeof(int32)*OID_LENGTH));
    memset(&xPtmChCfg,0x00,sizeof(xPtmChCfg));
    memset(&vlan_entry,0x00,sizeof(vlan_entry));

    //Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&uiCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    {
        goto end;
    }

    xPtmChCfg.iid.cpeId.Id = uiCpeid;
     
    //Get the object from system
    iRet= ifx_get_ptm_ch_cfg(&xPtmChCfg, IFX_F_GET_ANY);
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_get_ptm_ch_cfg failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
         goto end;
    }
    uiOld_EnableVal = xPtmChCfg.f_enable;
    
    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        goto end;
    }

    switch(pxOpInfo->iSubOper)
    {
        case OP_SETVAL_CHK_MODIFY_DEP:
            /* Iterate and check the requested parameters for enable parameter*/
            for (iCnt = 0; iCnt < iElements; iCnt++)
            {
                if(((pxParamVal[iCnt]).iaOID[iParamOffset]) == OID_IGD_WAND_WANCD_WANPTMLC_ENABLE)
                {
                    psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);
                    uiNew_EnableVal = atoi(psTmpVal);
                    if(uiNew_EnableVal == IFX_DISABLED && uiOld_EnableVal == IFX_ENABLED)
                    {
                        for(i=0; i <2; ++i)
                        {
                            /*Check if wanip/ppp connections are present on this WCD.
                              If present, the ip/ppp connections cannot be enabled while the WCD is disabled.
                              Disallow change in this case
                              Call global function to get the WanPPP/WanIP enable value
                              Pass Oid array with magic nos it should return 
                              OID,Name,Values,error_status */
                
                            memset(&xInParamVal, 0x00, sizeof(ParamVal));
                            if(i == 0)
                            {
                                memcpy(xInParamVal.iaOID,Wan_IP_Oid, (sizeof(int32)*OID_LENGTH));
                            }
                            else
                            {
                                memcpy(xInParamVal.iaOID,Wan_PPP_Oid, (sizeof(int32)*OID_LENGTH));
                            }
                            //Copy the OID from ParamVal
                            memcpy(xInParamVal.iaOID,pxParamVal->iaOID, (sizeof(int32)*(WAN_CON_DEV_DEPTH +1)));
                            
                            iRet=IFX_GlobalGetVal(&xInParamVal, &paxOutParamArr, &uiOutElem);
                            if(iRet != IFX_CWMP_SUCCESS) 
                            {
                                IFX_PrintOID(xInParamVal.iaOID);
                                IFX_FreeParamvalArr(&paxOutParamArr, uiOutElem);
                                iRet = IFX_CWMP_SUCCESS;
                                continue;
                            }
                            
                            //Based on state transition check whether Wan PPP/IPconnections
                            //are in expected state
                            paxTempParamVal = paxOutParamArr;
                            if(paxTempParamVal != NULL)
                            {
                                for(iJ=0; iJ < uiOutElem; iJ++) 
                                {
                                    //Get the Dependent WanConnection Oid & Enable parameter Value
                                    if((strcmp(paxTempParamVal->Value,"true") == 0) || (strcmp(paxTempParamVal->Value,"1")== 0))
                                    {
                                        iRet = ERR_CWMP_REQUEST_DENIED;
                                        pxParamVal[iCnt].iFaultCode = ERR_REQUEST_DENIED;
                                        goto end;
                                    }
                                    else
                                    {
                                        continue;
                                    }
                                    ++paxTempParamVal;
                                }
                            }
                            IFX_FreeParamvalArr(&paxOutParamArr, uiOutElem);
                        }
                    }
                }
            }
            break;
        case OP_SETVAL_MODIFY:
        case OP_SETVAL_ACTIVATE:
        { 
            /* Iterate and fill the requested parameters */
            for (iCnt = 0; iCnt < iElements; iCnt++)
            {
                psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

                /* Process based on the requested parameter */
                switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
                {
                    case OID_IGD_WAND_WANCD_WANPTMLC_ENABLE:
                         xPtmChCfg.f_enable = atoi(psTmpVal);
                        break;     

                    case OID_IGD_WAND_WANCD_WANPTMLC_LINKSTATUS:
                        /*Read Only parameter. Send error*/
                        iRet = ERR_NON_WRITABLE;
                        pxParamVal->iFaultCode = ERR_NON_WRITABLE_PARAM;
                        break;

                    case OID_IGD_WAND_WANCD_WANPTMLC_MACADDRESS:
                        sprintf(xPtmChCfg.mac_addr, "%s", psTmpVal);
                        break;     

                    default:
                        iRet = ERR_CWMP_INVAL_PARAM_NAME;
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "Invalid param id %d!\n",
                                    (pxParamVal[iCnt]).iaOID[iParamOffset]);
                        pxParamVal->iFaultCode=ERR_INVAL_PARAMETER_NAME;
                        goto end;
                }
            }
            iFlags = (IFX_F_MODIFY | IFX_F_DONT_WRITE_TO_FLASH);

            if(xPtmChCfg.f_enable == IFX_DISABLED)
            {
                /* Disable */
                iFlags = ( iFlags | IFX_F_DEACTIVATE | IFX_F_DONT_VALIDATE);
            }

            iRet = ifx_set_ptm_ch_cfg(IFX_OP_MOD, &xPtmChCfg, iFlags);
            if(iRet != IFX_CWMP_SUCCESS) 
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_set_ptm_ch_cfg failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
                goto end;
            }
            
            if(uiOld_EnableVal != xPtmChCfg.f_enable)
            {
                /* If PTM LinkConfig is enabled or disabled, the VLAN objects below it should be enabled and
                 disabled accordingly */
                /* Get all underlying VLAN objects .
                   Change enable value. 
                   Set back the vlan_ch_entry
                */
                ParentIID.cpeId.Id = xPtmChCfg.iid.cpeId.Id;
                strcpy(ParentIID.cpeId.secName, "ptm_channel");
                
                    iRet = mapi_get_all_vlan_ch_entries_for_l2ch(&num_vlanchannels, &xVlanArr, &ParentIID, IFX_F_GET_ANY);
                    if(iRet != IFX_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            " mapi_get_all_vlan_ch_entries_for_l2ch - Mgmt API returned error\n");
                        goto end;
                    }
                    if(num_vlanchannels == 0)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"No Vlan channels\n");
                        goto end;
                    }
                    for (i=0; i<num_vlanchannels; i++)
                    {
                       vlan_entry = xVlanArr[i];
                       if(vlan_entry.fEnable != xPtmChCfg.f_enable)
                       {
                           vlan_entry.fEnable = xPtmChCfg.f_enable;
                           iRet = mapi_set_vlan_ch_entry(IFX_OP_MOD, &vlan_entry, iFlags);
                           if(iRet != IFX_SUCCESS)
                           {
                               IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                       "mapi_set_vlan_ch_entry - Modify Mgmt API returned error\n");
                               goto end;
                           }
                       }
                    } 
                    IFX_MEM_FREE(xVlanArr);
                }
            }
            break;
         default:
            break;
     }
        
end:
    IFX_FreeParamvalArr(&paxOutParamArr, uiOutElem);

    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
              "%s:%d failed!\n", __func__, __LINE__);
    }
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : SetDelete
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
SetDelete(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
                            IN int32 iElements, OUT void **ppxParamStructRet,
                                                   OUT int32 * piNumRetElem)
{
    return IFIN_CWMP_SUCCESS;
#if 0
    uint32 uiCpeId=0;
    uint32 uiPcpeId=0;
    PTM_CH_CFG xPtmChCfg;
    int32 iRet=0;
    uint32 iOper=0,iFlags=0;
    int32 Wan_IP_Oid[OID_LENGTH]={0, 0, 0, 0, 0, OID_IGD_WAND_WANCD_WANIPC, MAGIC_NUMBER, OID_IGD_WAND_WANCD_WANIPC_ENABLE};
    int32 Wan_PPP_Oid[OID_LENGTH]={0, 0, 0, 0, 0, OID_IGD_WAND_WANCD_WANPPPC, MAGIC_NUMBER, OID_IGD_WAND_WANCD_WANPPPC_ENABLE};
    int32 i = 0, iJ = 0;
    ParamVal xInParamVal;
    ParamVal *paxOutParamArr=NULL;
    ParamVal *paxTempParamVal=NULL;
    
    memset(&xPtmChCfg,0x00,sizeof(xPtmChCfg));

    //If owner is WEB don't delete the object just return success.
    if(pxOpInfo->iCaller == ACC_WEB)
        return IFX_CWMP_SUCCESS;

    iRet = IFX_GetParentObjCpeId(paxParamVal->iaOID,&uiPcpeId);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;
   
    //Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(paxParamVal->iaOID,&uiCpeId);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;
        
    switch(pxOpInfo->iSubOper)
    {
        case OP_SETVAL_CHK_DEL_ALLOWED:
		break;
        case OP_SETVAL_CHK_DEL_DEP:
 		*ppxParamStructRet = (ParamVal *)IFX_CWMP_MALLOC(sizeof(ParamVal));
		if(*ppxParamStructRet == NULL){
			iRet = IFX_CWMP_FAILURE;
			goto errorHandler;
		}

		memcpy(*ppxParamStructRet, paxParamVal, sizeof(ParamVal));
		*piNumRetElem = 1;
 		break;

        case OP_SETVAL_DELETE:
            //handle DELETE operation
            for(i=0; i <2; ++i)
            {
                /*Check if wanip/ppp connections are present on this WCD.
                  If present, the ip/ppp connections cannot be enabled while the WCD is disabled.
                  Disallow change in this case
                  Call global function to get the WanPPP/WanIP enable value
                  Pass Oid array with magic nos it should return 
                  OID,Name,Values,error_status */
            
                memset(&xInParamVal, 0x00, sizeof(ParamVal));
                if(i == 0)
                {
                    memcpy(xInParamVal.iaOID,Wan_IP_Oid, (sizeof(int32)*OID_LENGTH));
                }
                else
                {
                    memcpy(xInParamVal.iaOID,Wan_PPP_Oid, (sizeof(int32)*OID_LENGTH));
                }
                //Copy the OID from ParamVal
                memcpy(xInParamVal.iaOID,paxParamVal->iaOID, (sizeof(int32)*(WAN_CON_DEV_DEPTH +1)));
                
                // Include once prototypes are available
                iRet=IFX_GlobalGetVal(&xInParamVal, &paxOutParamArr, &uiOutElem);
                if(iRet != IFX_CWMP_SUCCESS) 
                {
                    IFX_PrintOID(xInParamVal.iaOID);
                    IFX_FreeParamvalArr(&paxOutParamArr, uiOutElem);
                    iRet = IFX_CWMP_SUCCESS;
                    continue;
                }
                
                //Based on state transition check whether Wan PPP/IPconnections
                //are in expected state
                paxTempParamVal = paxOutParamArr;
                if(paxTempParamVal != NULL)
                {
                    for(iJ=0; iJ < uiOutElem; iJ++) 
                    {
                        //Get the Dependent WanConnection Oid & Enable parameter Value
                        //uiDep_Enable = atoi(paxTempParamVal->Value);
                        //if(uiDep_Enable == IFX_ENABLED)
                        if((strcmp(paxTempParamVal->Value,"true") == 0) || (strcmp(paxTempParamVal->Value,"1")== 0))
                        {
                            iRet = ERR_CWMP_REQUEST_DENIED;
                            pxParamVal[iCnt].iFaultCode = ERR_REQUEST_DENIED;
                            goto end;
                        }
                        else
                        {
                            continue;
                        }
                        ++paxTempParamVal;
                    }
                }
                IFX_FreeParamvalArr(&paxOutParamArr, uiOutElem);
            }
        }

            //Call Platform API to delete the obj in the system
            xPtmChCfg.iid.config_owner=pxOpInfo->iCaller;
            xPtmChCfg.iid.cpeId.Id = uiCpeId;
            xPtmChCfg.iid.pcpeId.Id = uiPcpeId;

            memset(xPtmChCfg.iid.tr69Id,0x00,MAX_TR69_ID_LEN);
            iRet = IFX_ConvertOidDottedForm(paxParamVal->iaOID, xPtmChCfg.iid.tr69Id);
            if(iRet != IFX_CWMP_SUCCESS)
            {
     	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d Oper=%d SubOper=%d Failed!\n",
	                            	__func__, __LINE__,pxOpInfo->iOper,pxOpInfo->iSubOper);
                goto errorHandler;
            }

            iOper = IFX_OP_DEL;
            iFlags = (IFX_F_DELETE | IFX_F_DONT_VALIDATE |
                    IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH);

            iRet = ifx_set_ptm_ch_cfg(iOper, &xPtmChCfg, iFlags);
            if(iRet != IFX_SUCCESS)
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "ifx_set_ptm_ch_cfg -Delete Mgmt API returned error\n");
                goto errorHandler;
            }
            break;
            
        default:
            break;
    }
    return IFIN_CWMP_SUCCESS;
    
errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed!\n", __func__, __LINE__);
    return IFIN_CWMP_FAILURE;
#endif //if 0
}


/* 
** =============================================================================
**   Function Name    : SetAttr
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

static int32
SetAttr(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
                            IN int32 iElements)
{
    uint32 iRet=IFX_CWMP_SUCCESS,i=0;
    OperInfo xOpInfo;
    
    xOpInfo.iCaller = pxOpInfo->iCaller;
    xOpInfo.iOper= OP_GETVAL;
    xOpInfo.iSubOper= OP_GETVAL_NORMAL;
    
    iRet = GetVal(&xOpInfo,pxParamVal, iElements);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorFreeHandler;
    
    iRet = IFX_SetAttributesInfo(pxOpInfo,pxParamVal, iElements);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorFreeHandler;

errorFreeHandler:
    for(i=0; i < iElements; i++)
        IFX_CWMP_FREE(pxParamVal[i].Value);
        
    if (iRet)
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed!\n", __func__, __LINE__);
    return iRet;
}



/* 
** =============================================================================
**   Function Name    : IFX_WanPTMLinkCfgInit
**   Description      : 
**   Parameters       : 
**   Return Value     : 
**   Notes            : 
** ============================================================================
*/
int32 IFX_WANPTMLinkCfgInit(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    
    /* Register the WanPTMLinkConfig module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_WANPTM_LINK_OBJ, IFX_WanPTMLinkConfig);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "Unable to Register %s with Object Model\n",
                     IFX_WANPTM_LINK_OBJ);
        goto errorHandler;
    }

errorHandler:
            return iRet;
}

/*********************************************************************************
*  Function Name  :  IFX_WanPTMLinkConfig
*  Description    :  This function handles all the sub-states inside
*                    a GET/SET operation.If it is a GET it allocates the 
*                    array(Name,Value pairs) and returns the values.
*                    If it is a SET controller allocates the array and
*                    passes the values to this function.It calls 
*                    respective internal functions which in turn calls 
*                    respective Platform APIs.
*  Parameters    :<par_type> <par_data_type>   <par_name>    <description of par>
*                    IN          OperInfo       pxOper;       Operation, Sub-operation,Owner
*                    INOUT       void *         pParamStruct; Struct which has Name,Value,etc
*                    IN          int32          iElements;    No. of Elements
*                    OUT         void *         ppParamRet;   same as ParamStruc
*                    OUT         int32 *        piNumRetElem; No. of elements                                         
*  Return Value : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes        :
***********************************************************************************/
int32 IFX_WanPTMLinkConfig(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                IN int32 iElements, OUT void **ppaxParamArrRet, OUT int32 *piNumRetElem)
{
     
    /*It calls the respective internal functions which handles resp. sub-operation*/
   
    /*Set-Operation:  
    controller should pass the entire array during all the SET-sub_operations
    It should handle only single get/set of instance at any point of time
    It does not handle partial path
    It won't handle multiple instances of the same object/module at any point of time.*/
    
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *paxParamArr = (ParamVal *)paxParameterArr;
    int32 iCnt = 0;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Oper[%d] [%d]\n", __func__, __LINE__, pxOperInfo->iOper, pxOperInfo->iSubOper);

    switch (pxOperInfo->iOper) 
    {
        /*Get the object values*/
        case OP_GETVAL:
        {
            if((iRet = GetVal(pxOperInfo, paxParamArr, iElements)) != IFX_CWMP_SUCCESS)
            {
                      IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
                      goto errorHandler;
            }
            break;
        }
        case OP_SETVAL:
        {
            /*Set the obj values*/
            switch (pxOperInfo->iSubOper) 
            {
                case OP_SETVAL_VALIDATE:
                    if((iRet = Validate(pxOperInfo,paxParamArr,
                                                       iElements)) != IFX_CWMP_SUCCESS)
                    { 
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                       "%s:%d OP_SET_VALIDATE failed!\n", __func__, __LINE__);
                        goto errorHandler;
                    }
                    break;

                case OP_SETVAL_ADD:
                    if((iRet= AddObj(pxOperInfo,paxParamArr,
                                                   iElements))!=IFX_CWMP_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d OP_SETVAL_ADD failed!\n", __func__, __LINE__);
                        goto errorHandler;
                    }                
                    break;

                case OP_SETVAL_CHK_MODIFY_DEP:
                case OP_SETVAL_MODIFY:
                case OP_SETVAL_ACTIVATE:
                    if((iRet = Modify(pxOperInfo, paxParamArr, iElements))!= IFX_CWMP_SUCCESS)
                    {
                        switch(pxOperInfo->iSubOper)
                        {
                            case OP_SETVAL_CHK_MODIFY_DEP:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                           "%s:%d OP_SETVAL_CHK_MODIFY_DEP failed!\n", __func__, __LINE__);
                                goto errorHandler;

                            case OP_SETVAL_MODIFY:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                        "%s:%d OP_SETVAL_MODIFY failed!\n", __func__, __LINE__);
                                goto errorHandler;
                                
                            case OP_SETVAL_ACTIVATE:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                      "%s:%d OP_SETVAL_ACTIVATE failed!\n", __func__, __LINE__);
                                goto errorHandler;
                        }
                    }
                    break;

                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    break;

                case OP_SETVAL_DELETE:
                    if((iRet= SetDelete(pxOperInfo, paxParamArr,
                                    iElements, ppaxParamArrRet,
                                    piNumRetElem))!= IFX_CWMP_SUCCESS)
                    {
                        switch(pxOperInfo->iSubOper)
                        {    
                            case OP_SETVAL_CHK_DEL_DEP:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
                                goto errorHandler;

                            case OP_SETVAL_CHK_DEL_ALLOWED:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
                                goto errorHandler;

                            case OP_SETVAL_DELETE:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
                                goto errorHandler;
                        }
                    }
                    break;

                case OP_SETVAL_FREE:
                    break;

                case OP_SETVAL_ATTRINFO:
                    if((iRet = SetAttr(pxOperInfo, paxParamArr,
                                              iElements)) != IFX_CWMP_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_SETVAL_ATTRINFO failed!\n", __func__, __LINE__);
                        goto errorHandler;
                    }
                    break;
                        
                default:
                    break;
            }
            break;
        }

        case OP_PARAM_VALIDATE:
        {
            if((paxParamArr->iaOID[2]) != WAN_DEVICE_ATM) //Only valid on IGD.WD.1.
            {
                /* Set the fault code to Error */
                for(iCnt = 0; iCnt < iElements; iCnt++)
                {
                    paxParamArr[iCnt].iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
                }
                goto errorHandler;
            }
            else if((paxParamArr->iaOID[2]) == WAN_DEVICE_ATM)
            {
                /*IGD.WD.1.WCD.1 is for PTMLC*/
                if((paxParamArr->iaOID[4]) != 1)
                {
            	    /* Set the fault code to Error */
    	            for(iCnt = 0; iCnt < iElements; iCnt++)
                    {
            	        paxParamArr[iCnt].iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
                    }
	            goto errorHandler;
                }
            }
            break;
        }

        default:
            break;
    }

errorHandler:
    return iRet;
}
