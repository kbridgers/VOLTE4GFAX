/* 
** =============================================================================
**   FILE NAME        : IFX_WanConnDevice.c
**   PROJECT          : TR69
**   MODULES          : WanConnDevice
**   DATE             : 28-06-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This module handles ADD/DEL/GET/SET RPCs of 
**                      WanConnDevice. When controller calls this module it
**                      calls respective Platform/Object APIs to handle GET/SET 
**                      of WanConnDevice specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author               $Comment
**   28-04-06         TR69 Team             Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
//#include <sys/socket.h>
//#include <netinet/in.h>
//#include <arpa/inet.h>

#include "IFX_DEVM_WANConnDev.h"
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
 

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;
#define IFX_WANCON_DEV_OBJ "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1."

/*
#define WAN_IP_NO_DEP_OIDS 2
#define WAN_IP_PORT_MAP_TCP 1
#define WAN_IP_PORT_MAP_UDP 2
#define NO_WAN_CON_DEVICE 16
*/

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/




/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/


extern Map_Value gaxEnable[]; 


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/
//If we maintain in an array the following issues are there
	//After reboot we need to synchronize with the system
	//If the connection goes down we may not have the correct count
	//Extra ram storage
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
int32 ifx_set_wan_conn_dev_stub(int32 operation,WAN_CONN_DEV *xWanConDev,int32 iFlags)
{

	if(xWanConDev == NULL)
	{
	   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Passed object has NULL Pointer !!! \n");
	   return IFX_SUCCESS;
	}
	
	if(operation == IFX_OP_ADD)
	{
	 	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Add operation \n");
	 }else if(operation == IFX_OP_DEL)
	 {
	 	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Del operation \n");
			
	  }else if (operation == IFX_OP_MOD)
 	{
 		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Modify operation \n");
 	}else 	
 	{
 	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: GET operation \n");
 	}

	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_CON_DEV_VPI = %d\n",xWanConDev->vc.pvc.vpi);
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_CON_DEV_VPI = %d\n",xWanConDev->vc.pvc.vci);
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_CON_DEV_CPEID = %d\n",xWanConDev->iid.cpeId.Id);
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_CON_DEV_CPEID = %d\n",xWanConDev->iid.config_owner);
	
return IFX_SUCCESS;

}
#endif
static int32 
IFX_GetNoWanConnections(IN ParamVal *pxGetParamVal,
								IN uint32 iElements, 
			OUT uint32 *uiNoOf_PPPConnections,OUT uint32 *uiNoOf_IPConnections)
{

	uint32 iRet=0 ;
	int32 Wan_IP_Enable_Oid[OID_LENGTH]={0,0,0,0,0,OID_IGD_WAND_WANCD_WANIPC,MAGIC_NUMBER,OID_IGD_WAND_WANCD_WANIPC_ENABLE};
	int32 Wan_PPP_Enable_Oid[OID_LENGTH]={0,0,0,0,0,OID_IGD_WAND_WANCD_WANPPPC,MAGIC_NUMBER,OID_IGD_WAND_WANCD_WANPPPC_ENABLE};
	uint32 uiOutElem=0;
	ParamVal axInParamArr;
	ParamVal *paxOutParamArr=NULL;
	
	//memset the structs passed to GlobalGetVal
	memset(&axInParamArr,0x00,sizeof(ParamVal));
	memcpy(axInParamArr.iaOID, Wan_IP_Enable_Oid, (sizeof(int32)*OID_LENGTH));
	memcpy(axInParamArr.iaOID,pxGetParamVal->iaOID, (sizeof(int32)*(WAN_CON_DEV_DEPTH+1)));

	iRet=IFX_GlobalGetVal(&axInParamArr,&paxOutParamArr, &uiOutElem);
	if(iRet != IFX_CWMP_SUCCESS)
	{
		IFX_PrintOID(axInParamArr.iaOID);
		IFX_FreeParamvalArr(&paxOutParamArr,uiOutElem);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                       		"%s:%d No IP Connections!\n", __func__, __LINE__);
		iRet = IFX_CWMP_SUCCESS;
	}
	*uiNoOf_IPConnections = uiOutElem;
	IFX_FreeParamvalArr(&paxOutParamArr,uiOutElem);

	//memset the structs passed to GlobalGetVal
	memset(&axInParamArr,0x00,sizeof(ParamVal));
	memcpy(axInParamArr.iaOID, Wan_PPP_Enable_Oid, (sizeof(int32)*OID_LENGTH));
	memcpy(axInParamArr.iaOID, pxGetParamVal->iaOID, (sizeof(int32)*(WAN_CON_DEV_DEPTH+1)));
        uiOutElem = 0;

	iRet=IFX_GlobalGetVal(&axInParamArr,&paxOutParamArr, &uiOutElem);
	if(iRet != IFX_CWMP_SUCCESS)
	{
		IFX_PrintOID(axInParamArr.iaOID);
		IFX_FreeParamvalArr(&paxOutParamArr,uiOutElem);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                       		"%s:%d No PPP Connections!\n", __func__, __LINE__);
		iRet = IFX_CWMP_SUCCESS;
	}
	*uiNoOf_PPPConnections = uiOutElem;
	IFX_FreeParamvalArr(&paxOutParamArr,uiOutElem);

	return IFIN_CWMP_SUCCESS;
}


/* 
** =============================================================================
**   Function Name    : IFX_WanConnDeviceGetValue
**   Description        : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes                : 
**
** ============================================================================
*/
static int32 
IFX_WanConnDeviceGetValue(IN OperInfo *pxOperInfo,INOUT ParamVal *pxGetParamVal,
								IN uint32 iElements)
{
	/*GET PARAMETER VALUES
	**Get Object OID(skip parameter ID) from the first 
	**element in the array.Get Cpeid for this Object OID

	**Get the object from the system using a Platform API
	**with cpeid 
	
	**Do reverse mapping to convert system values into TR69
	**Values.After conversion stores the values in temp storage

	**While assigning the values as per request store the 
	**values in heap and assign the ptr to the struct
	**Return all the values 
	*/


	
	//uint32 iCpeid=0,
	uint32 i=0;
	int32 iParamId=0;
	uint32 uiParamPos=0;
	uint32 uiMode=IFX_CHK_CHANGE_FLAG_BASED;
	//int32 iConType=0;
	int32 iRet=0;
	uint32 uiNoOf_IPConnections=0;	
	uint32 uiNoOf_PPPConnections=0;
	//Get the WanIpConParamPos 
	uiParamPos = IFX_GetParamIdPos(pxGetParamVal->iaOID);

	iRet = IFX_GetNoWanConnections(pxGetParamVal, iElements, &uiNoOf_PPPConnections, &uiNoOf_IPConnections);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
		
	for(i=0;i < iElements; i++)
	{
	
		iParamId = pxGetParamVal->iaOID[uiParamPos];
	
		// Malloc and assign the pointer to the Value attr of struct 
		pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
		if(pxGetParamVal->Value == NULL)
		{
			iRet = ERR_OUT_OF_MEMORY; 
			goto errorHandler;
		}	
		switch(iParamId)
		{

			// Convert the value - reverse mapping
			// Assign the correct value to the Value attr	
	    		case OID_IGD_WAND_WANCD_WANIPCONNECTIONNUMBEROFENTRIES:
				sprintf(pxGetParamVal->Value, "%d", uiNoOf_IPConnections);
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);		
				break;	 
					
	    		case OID_IGD_WAND_WANCD_WANPPPCONNECTIONNUMBEROFENTRIES:
				sprintf(pxGetParamVal->Value, "%d", uiNoOf_PPPConnections);
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			default:
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "Invalid param id %d!\n", iParamId);
				pxGetParamVal->iFaultCode=ERR_INVAL_PARAMETER_VAL;
				break;
		}					
		++pxGetParamVal;
	}

	return IFX_CWMP_SUCCESS;
		
errorHandler:
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d failed!\n", __func__, __LINE__);
	return IFIN_CWMP_FAILURE;
			

}


/* 
** =============================================================================
**   Function Name    : IFX_WanConnDeviceAddObj
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanConnDeviceAddObj(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{

	/* This API calls a Platform API which adds the object
	** in ADD_DISABLE state.
	** Pass necessary flags to the API
	** Controller should get the next instance id from DS 
    	** module and pass the full OID to this module.
	*/
		
	/* If Cisco proposal comes, this API should handle 
	**  a) Validation of values
	**  b) Forward mapping of TR69 values to system values 
	**  c) addition of object into the system
	*/
	
		
	uint32 iFlags=0;
	int32 iRet=0;
	uint32 iOper=0;
	uint32 uiPcpeId=0;
	WAN_CONN_DEV xWanConDev;

	//If owner is WEB don't add the object just return success.
	//if(pxOpInfo->iCaller == ACC_WEB)
	//	return IFX_CWMP_SUCCESS;

	memset(&xWanConDev, 0, sizeof(xWanConDev));

	iRet = IFX_GetParentObjCpeId(pxParamVal->iaOID,&uiPcpeId);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	//If owner is WEB don't add the object just return success.
	
	//Flags should be filled
	//Fills the Cpeid,ParentCepid,TR69Id,Owner
	//Fill the operation

	iOper = IFX_OP_ADD;
	iFlags =(	IFX_F_DONT_ACTIVATE|IFX_F_DONT_CHECKPOINT|
			IFX_F_DONT_VALIDATE|IFX_F_DONT_WRITE_TO_FLASH);
	
	xWanConDev.iid.config_owner=pxOpInfo->iCaller;
	xWanConDev.iid.cpeId.Id=0;
	xWanConDev.iid.pcpeId.Id=uiPcpeId;

	
        /*Do not allow adding WANConnectionDevice for WD.2. and WD.3.*/
        if(pxParamVal[0].iaOID[2] != WAN_DEVICE_ATM)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] Cannot add WANConnectionDevice on MII0 and MII1\n");
            iRet = IFIN_CWMP_FAILURE;
            goto errorHandler;
            /* Nirint: If WANDevice.{i}. != 1 (ATMWAN) then vpi = 256.
            So that Web can mask it. */
            //xWanConDev.vc.pvc.vpi = WANETH_VPI_VAL;
            //xWanConDev.vc.pvc.vci = WANETH_VCI_VAL;
        }

	//Convert array into dotted form and then strcpy
	iRet = IFX_ConvertOidDottedForm(pxParamVal->iaOID, xWanConDev.iid.tr69Id);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
	ifx_set_wan_conn_dev_stub(iOper, &xWanConDev, iFlags);
#else
	iRet = ifx_set_wan_conn_dev(iOper, &xWanConDev, iFlags);
#endif

	if(iRet != IFX_SUCCESS)
	{
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"ifx_set_wan_conn_dev Add Mgmt API returned error\n");
		goto errorHandler;
	}

	return IFIN_CWMP_SUCCESS;

errorHandler:
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d failed!\n", __func__, __LINE__);
	return IFIN_CWMP_FAILURE;
}


/* 
** =============================================================================
**   Function Name    : IFX_WanIpConnDeviceSetCommit
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanConnDeviceSetCommit()
{

	return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanConnDeviceSetUndo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanConnDeviceSetUndo()
{
	return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanConnDeviceSetDelete
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanConnDeviceSetDelete(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
				IN int32 iElements, OUT void **ppxParamStructRet, OUT int32 * piNumRetElem)
{
	uint32 i=0;
	uint32 uiCpeid=0;
	int32 iRet=0;
	uint32 iOper=0,iFlags=0;
	ParamVal *Param_DepOids=NULL;
	WAN_CONN_DEV xWanConDev;
	int32 iCnt=0;
	
	int32 ppp_stats_OID[OID_LENGTH]={0,0,0,0,0,OID_IGD_WAND_WANCD_WANPPPC,
									MAGIC_NUMBER,
									OID_IGD_WAND_WANCD_WANPPPC_S};
	int32 ppp_port_OID[OID_LENGTH]={0,0,0,0,0,OID_IGD_WAND_WANCD_WANPPPC,
									MAGIC_NUMBER,
									OID_IGD_WAND_WANCD_WANPPPC_PM,
									MAGIC_NUMBER};
	int32 ppp_OID[OID_LENGTH] = {0,0,0,0,0,OID_IGD_WAND_WANCD_WANPPPC,
									MAGIC_NUMBER};
	int32 ip_stats_OID[OID_LENGTH] = {0,0,0,0,0,OID_IGD_WAND_WANCD_WANIPC,
									MAGIC_NUMBER,
									OID_IGD_WAND_WANCD_WANIPC_S};
	int32 ip_port_OID[OID_LENGTH] ={0,0,0,0,0,OID_IGD_WAND_WANCD_WANIPC,
									MAGIC_NUMBER,
									OID_IGD_WAND_WANCD_WANIPC_PM,
									MAGIC_NUMBER};
	int32 ip_OID[OID_LENGTH] = {0,0,0,0,0,OID_IGD_WAND_WANCD_WANIPC,MAGIC_NUMBER};
#ifdef IFX_TR69_ADSLWAN
	int32 Wan_Vlan_OID[OID_LENGTH] = {0,0,0,0,0,OID_IGD_WAND_WANCD_WANDSLLC,OID_IGD_WAND_WANCD_WANDSLLC_XAC9A96V,MAGIC_NUMBER};
	int32 Wan_DslLink_OID[OID_LENGTH] = {0,0,0,0,0,OID_IGD_WAND_WANCD_WANDSLLC};
#endif
#ifdef IFX_TR69_ATMLOOPBACK
	int32 Wan_atmf5_OID[OID_LENGTH] = {0,0,0,0,0,OID_IGD_WAND_WANCD_WANATMF5LD};
#endif
#if 0
#ifdef IFX_TR69_ETHERNETWAN
	int32 Wan_Eth_OID[OID_LENGTH] = {0,0,0,0,0,OID_IGD_WAND_WANCD_WANELC};
#endif
#ifdef IFX_TR69_PTMWAN
	int32 Wan_Ptm_OID[OID_LENGTH] = {0,0,0,0,0,OID_IGD_WAND_WANCD_WANPTMLC};
	int32 Wan_PtmStats_OID[OID_LENGTH] = {0,0,0,0,0,OID_IGD_WAND_WANCD_WANPTMLC,OID_IGD_WAND_WANCD_WANPTMLC_S};
#endif
#endif
	
        /*Do not allow deleting WANConnectionDevice for WD.2. and WD.3.*/
        if(paxParamVal[0].iaOID[2] != WAN_DEVICE_ATM)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] Cannot delete WANConnectionDevice on MII0 and MII1\n");
            iRet = IFIN_CWMP_FAILURE;
            goto errorHandler;
        }
	else
        {
            if(paxParamVal[0].iaOID[4] == 1) //IGD.WD.1.WCD.1
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] Cannot delete default PTM WANConnectionDevice\n");
                iRet = IFIN_CWMP_FAILURE;
                goto errorHandler;
            }
        }

	// handle CHK_DELETE_DEP
	if(pxOpInfo->iSubOper == OP_SETVAL_CHK_DEL_DEP)
	{
			i=0;
			iCnt=7;
#ifdef IFX_TR69_ADSLWAN
			iCnt++;
			iCnt++;
#endif
#ifdef IFX_TR69_ATMLOOPBACK
			iCnt++;
#endif
#if 0
#ifdef IFX_TR69_ETHERNETWAN
			iCnt++;
#endif
#ifdef IFX_TR69_PTMWAN
			iCnt++;
			iCnt++;
#endif
#endif

			Param_DepOids = IFIN_CWMP_MALLOC(iCnt * sizeof(ParamVal));
			if(Param_DepOids == NULL)
			{
			   iRet = ERR_OUT_OF_MEMORY; 
			   goto errorHandler;
			}
			memcpy((Param_DepOids+i++)->iaOID,ppp_stats_OID,(sizeof(int32)*OID_LENGTH));
			memcpy((Param_DepOids+i++)->iaOID,ppp_port_OID,(sizeof(int32)*OID_LENGTH));
			memcpy((Param_DepOids+i++)->iaOID,ppp_OID,(sizeof(int32)*OID_LENGTH));
			
			memcpy((Param_DepOids+i++)->iaOID,ip_stats_OID,(sizeof(int32)*OID_LENGTH));
			memcpy((Param_DepOids+i++)->iaOID,ip_port_OID,(sizeof(int32)*OID_LENGTH));
			memcpy((Param_DepOids+i++)->iaOID,ip_OID,(sizeof(int32)*OID_LENGTH));
#ifdef IFX_TR69_ADSLWAN
			memcpy((Param_DepOids+i++)->iaOID,Wan_Vlan_OID,(sizeof(int32)*OID_LENGTH));
			memcpy((Param_DepOids+i++)->iaOID,Wan_DslLink_OID,(sizeof(int32)*OID_LENGTH));
#endif
#ifdef IFX_TR69_ATMLOOPBACK
			memcpy((Param_DepOids+i++)->iaOID,Wan_atmf5_OID,(sizeof(int32)*OID_LENGTH));
#endif
#if 0
#ifdef IFX_TR69_ETHERNETWAN
			memcpy((Param_DepOids+i++)->iaOID,Wan_Eth_OID,(sizeof(int32)*OID_LENGTH));
#endif
#ifdef IFX_TR69_PTMWAN
			memcpy((Param_DepOids+i++)->iaOID,Wan_Ptm_OID,(sizeof(int32)*OID_LENGTH));
			memcpy((Param_DepOids+i++)->iaOID,Wan_PtmStats_OID,(sizeof(int32)*OID_LENGTH));
#endif
#endif
			
			for(i=0; i <iCnt; ++i)
				memcpy((Param_DepOids+i)->iaOID,paxParamVal->iaOID,
								(sizeof(int32)*(WAN_CON_DEV_DEPTH+1)));

									
			*ppxParamStructRet = (void *)Param_DepOids;
			*piNumRetElem = iCnt;
			return IFIN_CWMP_SUCCESS;
			
		}
	
	//Get the Cpeid from Tr69 id
	//iRet = IFX_GetObjCpeId(paxParamVal->iaOID,&uiCpeid);
	iRet = IFX_GetCpeId(paxParamVal->iaOID,&uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	switch(pxOpInfo->iSubOper)
	{
		case OP_SETVAL_CHK_DEL_ALLOWED:
			// handle CHK_DELETE_ALLOWED
			//Check for default instance if del is called by TR69
			//if(xWanConDev->f_default == IFX_DEFAULT)
			//	goto errorHandler;
			
			break;
		case OP_SETVAL_DELETE:
			//handle DELETE operation
			//Call Platform API to delete the obj in the system
			//If del is called by web we need to pass special owner for which API 
			//will not post a message.
			
			xWanConDev.iid.config_owner=pxOpInfo->iCaller;
			xWanConDev.iid.cpeId.Id=uiCpeid;
			memset(xWanConDev.iid.tr69Id,0x00,MAX_TR69_ID_LEN);
			iOper = IFX_OP_DEL;
			iFlags = (IFX_F_DELETE|IFX_F_DONT_VALIDATE|
					IFX_F_DONT_CHECKPOINT|IFX_F_DONT_WRITE_TO_FLASH);
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS			
			ifx_set_wan_conn_dev_stub(iOper, &xWanConDev, iFlags);
#else
			iRet = ifx_set_wan_conn_dev(iOper, &xWanConDev, iFlags);
#endif
			
			if(iRet != IFX_SUCCESS)
			{
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					"ifx_set_wan_conn_dev -Delete Mgmt API returned error\n");
				goto errorHandler;		
			}
			break;
			
		default:
			break;
	}
	return IFIN_CWMP_SUCCESS;
	
errorHandler:
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d failed!\n", __func__, __LINE__);
	return IFIN_CWMP_FAILURE;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanConnDeviceSetFree
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanConnDeviceSetFree()
{
	return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanConnDeviceUpdateChildInfo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

static int32 IFX_WanConnDeviceUpdateChildInfo(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{

	//For both ADD & DEL 
	//Check whether WanIPC or WanPPPC
	//Send notification
	uint32 i=0,iRet=0;
	char8 usSecTag[IFX_MAX_SECTION_TAG_LEN]={0};
	char8 usParamTag[IFX_MAX_NAME_LEN]={0};
	uint32 uiParamPos=0,uiChildObjId=0;
	uint32 uiCpeid=0;
	int32 *iaOID=NULL;
	uint32 uiNumNV=1;
	//IFX_CpeId pxCpeId;
	IFX_Id xIfx_Id;
	IFX_NameValue pxNVArray;
	uint32 uiOper=IFX_NOTIFY_OPER_MODIFY;
	ParamVal *pxTempParamVal=pxParamVal;
	
	//memset the structs
	memset(&xIfx_Id,0x00,sizeof(xIfx_Id));
	memset(&pxNVArray,0x00,sizeof(pxNVArray));
	
	//Get Cpeid
	iRet = IFX_GetCpeId(pxTempParamVal->iaOID, &uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	//Get the child object Oid
	uiChildObjId = IFX_GetParamIdPos((int32 *)pxTempParamVal->pReserved);
	iaOID = (int32 *)pxTempParamVal->pReserved;


	for(i=0; i < iElements; i++)
	{
		//Get the Param Oid of this object
		uiParamPos= IFX_GetParamIdPos(pxTempParamVal->iaOID);
		
		switch(pxTempParamVal->iaOID[uiParamPos])
		{
			case OID_IGD_WAND_WANCD_WANIPCONNECTIONNUMBEROFENTRIES:
				if(iaOID[uiChildObjId-1] == OID_IGD_WAND_WANCD_WANIPC)
				{
					//Get the section and Paramtag
					iRet=IFX_GetSectionParamTag(pxTempParamVal->psRCTag, usParamTag, 
														usSecTag);
					if(iRet != IFX_CWMP_SUCCESS)
						goto errorHandler;

					xIfx_Id.uiConfigOwner= pxOpInfo->iCaller;
					xIfx_Id.xCpeId.uiId= uiCpeid;
					strncpy(xIfx_Id.xCpeId.sSectionTag,usSecTag, IFX_MAX_SECTION_TAG_LEN-1);
					xIfx_Id.xCpeId.sSectionTag[IFX_MAX_SECTION_TAG_LEN-1] = '\0';
					strncpy(pxNVArray.sName,usParamTag, IFX_MAX_NAME_LEN-1);
					pxNVArray.sName[IFX_MAX_NAME_LEN-1] = '\0';
				
					iRet=IFX_SendNotify(&xIfx_Id, uiNumNV, &pxNVArray, uiOper);
					if(iRet != IFX_CWMP_SUCCESS)
					{
						IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                       	    "%s:%d UpdatechildInfo IFX_SendNotify failed!\n", __func__, __LINE__);
						goto errorHandler;
					}
				}
				break;
			
			case OID_IGD_WAND_WANCD_WANPPPCONNECTIONNUMBEROFENTRIES:
				if(iaOID[uiChildObjId-1] == OID_IGD_WAND_WANCD_WANPPPC)
				{
					//Get the section and Paramtag
					iRet=IFX_GetSectionParamTag(pxTempParamVal->psRCTag, usParamTag, usSecTag);
					if(iRet != IFX_CWMP_SUCCESS)
						goto errorHandler;
					
					xIfx_Id.uiConfigOwner= pxOpInfo->iCaller;
					xIfx_Id.xCpeId.uiId= uiCpeid;
					strncpy(xIfx_Id.xCpeId.sSectionTag,usSecTag, IFX_MAX_SECTION_TAG_LEN-1);
					xIfx_Id.xCpeId.sSectionTag[IFX_MAX_SECTION_TAG_LEN-1] = '\0';
					strncpy(pxNVArray.sName,usParamTag, IFX_MAX_NAME_LEN-1);
					pxNVArray.sName[IFX_MAX_NAME_LEN-1] = '\0';

					iRet=IFX_SendNotify(&xIfx_Id, uiNumNV, &pxNVArray, uiOper);
					if(iRet != IFX_CWMP_SUCCESS)
					{
						IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                               	   "%s:%d UpdatechildInfo IFX_SendNotify failed!\n", __func__, __LINE__);
						goto errorHandler;
					}
				}
				break;
			
			default:
				break;
		}
		pxTempParamVal++;
	}

	return IFX_CWMP_SUCCESS;
		
errorHandler:
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d failed!\n", __func__, __LINE__);
	return IFX_CWMP_FAILURE;		
}

/* 
** =============================================================================
**   Function Name    : IFX_WanConnDeviceSetAttr
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

int32
IFX_WanConnDeviceSetAttr(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal, IN int32 iElements)
{
	uint32 iRet=IFX_CWMP_SUCCESS,i=0;
	OperInfo xOpInfo;
	
	xOpInfo.iCaller = pxOpInfo->iCaller;
	xOpInfo.iOper= OP_GETVAL;
	xOpInfo.iSubOper= OP_GETVAL_NORMAL;
	
	iRet = IFX_WanConnDeviceGetValue(&xOpInfo,pxParamVal, iElements);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorFreeHandler;
	
	iRet = IFX_SetAttributesInfo(pxOpInfo,pxParamVal, iElements);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorFreeHandler;

errorFreeHandler:
	for(i=0; i < iElements; i++)
	IFX_CWMP_FREE(pxParamVal[i].Value);
	
        if (iRet)
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   		 "%s:%d failed!\n", __func__, __LINE__);
	return iRet;
}



/* 
** =============================================================================
**   Function Name    : IFX_WanDslLinkConfig_Init
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_WanConnDevice_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the DeviceInfo module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_WANCON_DEV_OBJ, IFX_WanConnDevice);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "Unable to Register %s with Object Model\n", IFX_WANCON_DEV_OBJ);
        goto errorHandler;
    }

errorHandler:
    return iRet;
}

/*********************************************************************************
*  Function Name	:  IFX_WanConnDevice
      *  Description	:  This function handles all the sub-states inside
      	 		   a GET/SET operation.If it is a GET it allocates the 
			   array(Name,Value pairs) and retruns the values.
			   If it is a SET controller allocates the array and
			   passes the values to this function.It calls 
			   respective internal functions which in turn calls 
			   respective Platform APIs.
                                                                                                 
*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
							     Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has 
					  	             Name,Value,etc
                    IN          int32	       iElements;    No. of Elements
		    OUT	        void *	       ppParamRet;   same as ParamStruc
		    OUT         int32 *        piNumRetElem; No. of elements 		                                
*  Return Value        : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes               :
***********************************************************************************/
int32
IFX_WanConnDevice(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                IN int32 iElements, OUT void **ppaxParamArrRet, OUT int32 *piNumRetElem)
{
     
   //It calls the respective internal functions which handles resp. sub-operation
   
   //Set-Operation  
   //controller should pass the entire array during all the SET-sub_operations
   //It should handles only single get/set of instance at any point of time
   //It does not handle partial path
   //It won't handle multiple instances of the same object/module
   //at any point of time.

    
    int32 iRet = 0;
    ParamVal *paxParamArr = (ParamVal *)paxParameterArr;

    switch (pxOperInfo->iOper) 
    {
        //Get the object values
	case OP_GETVAL:
	    if((iRet = IFX_WanConnDeviceGetValue(pxOperInfo, paxParamArr, iElements)) != IFX_CWMP_SUCCESS)
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
		goto errorHandler;
            }
	    break;
	case OP_SETVAL:
	{
            //Set the obj values
	    switch (pxOperInfo->iSubOper) 
            {
                case OP_SETVAL_VALIDATE:  		                 
                    break;

                case OP_SETVAL_ADD:
                    if((iRet= IFX_WanConnDeviceAddObj(pxOperInfo,paxParamArr,
		    					iElements))!=IFX_CWMP_SUCCESS)
                    {
	                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d OP_SETVAL_ADD failed!\n", __func__, __LINE__);
                        goto errorHandler;
	            }
                    break;

	        case OP_SETVAL_CHK_MODIFY_DEP:
		case OP_SETVAL_MODIFY:           
	            break;

	        case OP_SETVAL_COMMIT:
	            if((iRet = IFX_WanConnDeviceSetCommit(pxOperInfo,paxParamArr, iElements)) != IFX_CWMP_SUCCESS)
                    {
	                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d OP_SETVAL_COMMIT failed!\n", __func__, __LINE__);
                        goto errorHandler;
                    }
                    break;

                case OP_SETVAL_UNDO:
                    if((iRet =IFX_WanConnDeviceSetUndo(pxOperInfo, paxParamArr, iElements)) != IFX_CWMP_SUCCESS)
                    {
	                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_UNDO failed!\n", __func__, __LINE__);
	                goto errorHandler;
	            }
	            break;
		case OP_SETVAL_CHK_DEL_DEP:
		case OP_SETVAL_CHK_DEL_ALLOWED:
	        case OP_SETVAL_DELETE:
	            if((iRet= IFX_WanConnDeviceSetDelete(pxOperInfo, paxParamArr, iElements, 
						ppaxParamArrRet, piNumRetElem))!= IFX_CWMP_SUCCESS)
                    {
                        switch(pxOperInfo->iSubOper)
			{	
			    case OP_SETVAL_CHK_DEL_DEP:
			    	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
			         goto errorHandler;
			    case OP_SETVAL_CHK_DEL_ALLOWED:
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
			        goto errorHandler;
			    case OP_SETVAL_DELETE:
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
			        goto errorHandler;
			}
                    }
	            break;
	            
                case OP_SETVAL_FREE:
	            IFX_WanConnDeviceSetFree(pxOperInfo);
		    break;

		case OP_SETVAL_ATTRINFO:
		    if((iRet =IFX_WanConnDeviceSetAttr(pxOperInfo, paxParamArr, iElements)) != IFX_CWMP_SUCCESS)
                    {
	                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    		"%s:%d OP_SETVAL_ATTRINFO failed!\n", __func__, __LINE__);
	                goto errorHandler;
	            }	
	            break;
						
	        default:
		    break;
            }
	}		
        case OP_UPDATE_CHILDINFO:
		//Updation of child related info is handled by the case
		switch(pxOperInfo->iSubOper)
		{
		    case OP_UPDATE_CHILDINFO_ADD:
	            case OP_UPDATE_CHILDINFO_DEL:
                        if((iRet =IFX_WanConnDeviceUpdateChildInfo(pxOperInfo, paxParamArr,iElements)) != IFX_CWMP_SUCCESS)
                        {
                            switch(pxOperInfo->iSubOper)
                            {
                                case OP_UPDATE_CHILDINFO_ADD:
                                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                    	             "%s:%d OP_UPDATE_CHILDINFO_ADD failed!\n", __func__, __LINE__);
				    goto errorHandler;
					
                                case OP_UPDATE_CHILDINFO_DEL:
				     IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                    			"%s:%d OP_UPDATE_CHILDINFO_DEL failed!\n", __func__, __LINE__);
				     goto errorHandler;

                            }
                        }	
                }
		break;

        case OP_PARAM_VALIDATE:
        {
            break; 
        }

	default:
            break;
    }
    return IFX_CWMP_SUCCESS;

errorHandler:
    return iRet;			
}
