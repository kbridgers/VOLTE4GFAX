
/*
** =============================================================================
** FILE NAME   : IFX_DEVM_DownloadDiags.c
** PROJECT     : TR69
** MODULES     : (InternetGateway) Device.DownloadDiagnostics.
** DATE        :
** AUTHOR      : TR69 team
** DESCRIPTION : AddObject / DeleteObject cannot be performed on this object.
**
** REFERENCES  :
** COPYRIGHT   : Copyright (c) 2006
**               Infineon Technologies AG
**               Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY     :
** $Date       $Author        $Comment
**             TR69 team      Creation
** =============================================================================
*/

#include "IFX_DEVM_Global.h"

#include "IFX_DEVM_AdaptCommon.h"


#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_StackUtil.h"
#include <resolv.h>
#include <pthread.h>


extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char *obj, modFunc pifx_module_func);
extern int32 IFX_ContAddObj(IN int32 iCaller, IN char8 * psObj);
extern int32 IFX_ContDelObj(IN int32 iCaller, IN char8 * psObj,
                            IN int32 iSession);

#ifndef DEVICE_SUPPORT
#define DOWNLOADDIAG_OBJ                      FORMNAME("DownloadDiagnostics.")
#define DOWNLOADDIAG_DEPTH                    3
#endif // DEVICE_SUPPORT

#ifdef DEVICE_SUPPORT
#define DOWNLOADDIAG_OBJ                      FORMNAME("LAN.DownloadDiagnostics.")
#define DOWNLOADDIAG_DEPTH                    4
#endif // DEVICE_SUPPORT

#define MAX_NUM_LEN          12
#define LINESIZE             256

extern int32 IFX_DownloadTest(DOWNLOAD_DIAG * xDownload, char *Iface);

pthread_mutex_t dd_msg_mutex = PTHREAD_MUTEX_INITIALIZER;

char gsDLInterface[16] = { 0 };

/*******************************************************************************
* Function: IFX_DownloadDiagSetAttrInfo
* Desc: Sets attribute information in the respective tr69 sections
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_DownloadDiagSetAttrInfo(IN int32 iCaller, INOUT ParamVal * pxPV,
                            IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    iRet = IFX_SetAttributesInfo(NULL, pxPV, iElements);

    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Updating Param Attribute Info failed\n",
                    _FUNCL_, iRet);
        goto errorHandler;
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_DownloadDiagGetNotifyValue
* Desc: gets valure from the config file and returns
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_DownloadDiagGetNotifyValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                               IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    DOWNLOAD_DIAG xDownload;
    char8 caTmp[64] = { 0 };

    memset(&xDownload, '\0', sizeof(xDownload));
    iRet = ifx_get_download_diag(&xDownload);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_download_diag() failed\n", _FUNCL_,
                    iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
    for(iI = 0; iI < iElements; iI++) {
        pxPV[iI].Value = IFX_CWMP_MALLOC(257);
        if(pxPV[iI].Value == NULL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", _FUNCL_);
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (pxPV[iI].iaOID[DOWNLOADDIAG_DEPTH - 1]) {
            case OID_IGD_DD_DIAGNOSTICSSTATE:
                strcpy(pxPV[iI].Value, xDownload.diag_state);
                break;
            case OID_IGD_DD_INTERFACE:
                strcpy(pxPV[iI].Value, xDownload.interface);
                break;
            case OID_IGD_DD_DOWNLOADURL:
                strcpy(pxPV[iI].Value, xDownload.download_url);
                break;
            case OID_IGD_DD_ETHERNETPRIORITY:
                sprintf(pxPV[iI].Value, "%u", xDownload.ethernet_priority);
                break;
            case OID_IGD_DD_ROMTIME:
                strcpy(pxPV[iI].Value, xDownload.ROMTime);
                break;
            case OID_IGD_DD_BOMTIME:
                strcpy(pxPV[iI].Value, xDownload.BOMTime);
                break;
            case OID_IGD_DD_EOMTIME:
                strcpy(pxPV[iI].Value, xDownload.EOMTime);
                break;
            case OID_IGD_DD_DSCP:
                sprintf(pxPV[iI].Value, "%d", xDownload.dscp);
                break;
            case OID_IGD_DD_TESTBYTESRECEIVED:
                sprintf(caTmp, "%d", xDownload.rxTestBytes);
                strcpy(pxPV[iI].Value, caTmp);
                break;
            case OID_IGD_DD_TOTALBYTESRECEIVED:
                sprintf(caTmp, "%d", xDownload.rxTotalBytes);
                strcpy(pxPV[iI].Value, caTmp);
                break;
            case OID_IGD_DD_TCPOPENREQUESTTIME:
                sprintf(caTmp, "%s", xDownload.tcpOpenRqstTime);
                strcpy(pxPV[iI].Value, caTmp);
                break;

            case OID_IGD_DD_TCPOPENRESPONSETIME:
                sprintf(caTmp, "%s", xDownload.tcpOpenRespTime);
                strcpy(pxPV[iI].Value, caTmp);
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", _FUNCL_,
                            pxPV[iI].iaOID[DOWNLOADDIAG_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_DownloadValidateInterface
* Desc: Validates the psInterface parameter passed. Is Successful, psIPAddr
*       will contain the IPAddress of the interface (Depending on being a
*       WANDevice or LANDevice). psIPAddr should be allocated by the caller of
*       this function.
* Parameters: IN char8 * psInterface, OUT char8 * psIPAddr
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_DownloadValidateInterface(IN char8 * psInterface, OUT char8 * psIPAddr)
{
    int32 iRet = IFX_CWMP_SUCCESS;


/*	if(psInterface == NULL)
	{
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d NULL interface name\n", _FUNCL_);
		goto errorHandler;
	}

	if (strstr(psInterface, "WANDevice"))
	{
	}
	else if (strstr(psInterface, "LANDevice"))
	{
	}
	else
	{
		iRet = IFX_CWMP_FAILURE;
		goto errorHandler;
	}

errorHandler:*/
    return iRet;
}

/*******************************************************************************
* Function: IFX_DownloadDiagValidate
* Desc:
*
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_DownloadDiagValidate(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0, iTmp = 0;
    char8 sIPAddr[64] = { 0 };


    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[DOWNLOADDIAG_DEPTH - 1]) {
            case OID_IGD_DD_INTERFACE:

                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "Entered case OID_IGD_DD_INTERFACE:\n");

                iTmp = strlen(pxPV[iI].Value);
                if(iTmp > MAX_IF_NAME) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d Interface len %d > %d (max)\n", _FUNCL_,
                                iTmp, MAX_IF_NAME);
                    iRet = ERR_CWMP_INVAL_PARAM_VAL;
                    goto errorHandler;
                }
                if(iTmp == 0) {
                    /* A NULL interface value is a valid value, use the routing
                       table */
                }
                else {

                    iRet =
                        IFX_DownloadValidateInterface(pxPV[iI].Value, sIPAddr);
                    if(iRet != IFX_CWMP_SUCCESS) {

                        iRet = ERR_CWMP_INVAL_ARGS;
                        pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "IFX_DownloadValidateInterface FAILED\n");
                        goto errorHandler;
                    }
                }
                break;
            case OID_IGD_DD_DOWNLOADURL:
                if(strstr(pxPV[iI].Value, "https")) {
                    iRet = ERR_CWMP_INVAL_ARGS;
                    pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "IFX_DownloadValidate FAILED\n");
                    goto errorHandler;
                }
                else if(strstr(pxPV[iI].Value, "http://") == 0) {
                    iRet = ERR_CWMP_INVAL_ARGS;
                    pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "IFX_DownloadValidate FAILED\n");
                    goto errorHandler;
                }
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Default case\n", _FUNCL_,
                            pxPV[iI].iaOID[DOWNLOADDIAG_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_DownloadDiagSetValue
* Desc:
*
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_DownloadDiagSetValue(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0, iActivate = 0;
    DOWNLOAD_DIAG xDownload;
    ParamVal xGetParam;
    ParamVal *paxGetParamVal = NULL;
    char8 caInterface[CWMP_MAX_OBJ_LEN] = { 0 };
    char sIfName[150] = { 0 };
    uint32 iElemOut;
    int32 wan_type = 0;

    memset(&xDownload, '\0', sizeof(xDownload));
    iRet = ifx_get_download_diag(&xDownload);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_download_diag() failed\n", _FUNCL_,
                    iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[DOWNLOADDIAG_DEPTH - 1]) {

            case OID_IGD_DD_DIAGNOSTICSSTATE:
                strncpy(xDownload.diag_state, pxPV[iI].Value,
                        MAX_DIAGSTATE_LEN);
                if(strcmp(pxPV[iI].Value, "Requested") == 0)
                    iActivate = IFX_CWMP_NEED_ACTIVATE;
                break;
            case OID_IGD_DD_INTERFACE:
                if(!strcmp(pxPV[iI].Value, "")) {
                    xDownload.interface[0] = '\0';
                    memset(gsDLInterface, '\0', sizeof(gsDLInterface));
                }
                else if(!strcmp
                        (pxPV[iI].Value,
                         "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.IPInterface.1"))
                {
                    strcpy(gsDLInterface, "br0");
                }
                else {
                    memset(&xGetParam, 0x00, sizeof(xGetParam));
                    xGetParam.Name =
                        IFX_CWMP_MALLOC(strlen(pxPV[iI].Value) + 8);
                    if(xGetParam.Name == NULL) {
                        iRet = IFX_CWMP_FAILURE;
                        goto errorHandler;
                    }

                    memset(caInterface, 0, sizeof(caInterface));
                    strcpy(caInterface, pxPV[iI].Value);
                    if(caInterface[strlen(caInterface) - 1] != '.') {
                        strcat(caInterface, ".");
                    }

                    sprintf(xGetParam.Name, "%s%s", (char *)caInterface,
                            "Name");

                    iRet =
                        IFX_GlobalGetVal(&xGetParam, &paxGetParamVal,
                                         (uint32 *) & iElemOut);
                    if(iRet != IFX_CWMP_SUCCESS) {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                                    "[%s] [%d]  IFX_GlobalGetVal failed\n",
                                    __func__, __LINE__);
                        IFX_CWMP_FREE(xGetParam.Name);
                        if(paxGetParamVal != NULL) {
                            IFX_CWMP_FREE(paxGetParamVal->Value);
                            IFX_CWMP_FREE(paxGetParamVal->Name);
                        }
                        IFX_CWMP_FREE(paxGetParamVal);
                        pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        goto errorHandler;
                    }
                    if(strstr(paxGetParamVal->Value, "WANPPP") != NULL) {
                        wan_type = WAN_TYPE_PPP;
                    }
                    else {
                        wan_type = WAN_TYPE_IP;
                    }
                    iRet =
                        ifx_get_wan_ifname_from_connName(paxGetParamVal->Value,
                                                         sIfName, wan_type);
                    if(iRet != IFX_CWMP_SUCCESS) {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                                    "[%s] [%d]  ifx_get_wan_ifname_from_conf_connName failed. Connname: %s\n",
                                    __func__, __LINE__, paxGetParamVal->Value);
                        IFX_CWMP_FREE(xGetParam.Name);
                        IFX_CWMP_FREE(paxGetParamVal->Value);
                        IFX_CWMP_FREE(paxGetParamVal->Name);
                        IFX_CWMP_FREE(paxGetParamVal);
                        iRet = ERR_CWMP_INTERNAL;
                        pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        goto errorHandler;
                    }
                    strncpy(gsDLInterface, sIfName, 15);

                    IFX_CWMP_FREE(xGetParam.Name);
                    IFX_CWMP_FREE(paxGetParamVal->Value);
                    IFX_CWMP_FREE(paxGetParamVal->Name);;
                    IFX_CWMP_FREE(paxGetParamVal);
                }
                strcpy(xDownload.interface, pxPV[iI].Value);
                break;
            case OID_IGD_DD_DOWNLOADURL:
                strcpy(xDownload.download_url, pxPV[iI].Value);
                break;
            case OID_IGD_DD_ETHERNETPRIORITY:
                sscanf(pxPV[iI].Value, "%u", &xDownload.ethernet_priority);
                break;
            case OID_IGD_DD_DSCP:
                sscanf(pxPV[iI].Value, "%d", &xDownload.dscp);
                break;
            case OID_IGD_DD_ROMTIME:
            case OID_IGD_DD_BOMTIME:
            case OID_IGD_DD_EOMTIME:
            case OID_IGD_DD_TESTBYTESRECEIVED:
            case OID_IGD_DD_TOTALBYTESRECEIVED:
            case OID_IGD_DD_TCPOPENREQUESTTIME:
            case OID_IGD_DD_TCPOPENRESPONSETIME:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%d] [Error] Non-Writable parameter %d!\n",
                            _FUNCL_, pxPV[iI].iaOID[DOWNLOADDIAG_DEPTH - 1]);
                iRet = ERR_NON_WRITABLE;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE_PARAM;
                goto errorHandler;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%d] [Error] Unknown requested parameter %d!\n",
                            _FUNCL_, pxPV[iI].iaOID[DOWNLOADDIAG_DEPTH - 1]);
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                pxPV[iI].iFaultCode = ERR_INVAL_PARAMETER_NAME;
                goto errorHandler;
        }
    }

    /* Modifying any of the parameters in this obj except DiagnosticState MUST
       result in the value of DiagnosticState parameter being set to "None" */
    if(iActivate != IFX_CWMP_NEED_ACTIVATE)
        strcpy(xDownload.diag_state, "None");

    iRet = ifx_set_download_diag(&xDownload, IFX_F_MODIFY);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_set_download_diag() failed\n", _FUNCL_,
                    iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }

  errorHandler:
    if((iActivate == IFX_CWMP_NEED_ACTIVATE) && (iRet == IFX_CWMP_SUCCESS))
        iRet = IFX_CWMP_NEED_ACTIVATE;

    return iRet;
}



/*******************************************************************************
* Function: IFX_DownloadDiagPerformTest
* Desc: Gets the value. Calls IFX_DownloadTest. Set the required value. Posts the
*       message to the Stacks FIFO about the completion of Download Diag Test
* Parameters:
* Return Value: IFX_CWMP_SUCCESS
*******************************************************************************/
void *
IFX_DownloadDiagPerformTest(void *params)
{
    int32 iRet = IFX_CWMP_SUCCESS, iFIFOFd = 0;
    DOWNLOAD_DIAG xDownload;

    memset(&xDownload, '\0', sizeof(xDownload));

    iRet = ifx_get_download_diag(&xDownload);

    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_download_diag() failed\n", _FUNCL_,
                    iRet);
        goto errorHandler;
    }

    iRet = IFX_DownloadTest(&xDownload, gsDLInterface);


    iRet = ifx_set_download_diag(&xDownload, IFX_F_MODIFY);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_download_diag() failed\n", _FUNCL_,
                    iRet);
        goto errorHandler;
    }
    /* Send msg to FIFO */
    iFIFOFd = IFX_OS_OpenFifo((uchar8 *) IFX_IPC_TR_FIFO, O_RDWR);
    if(iFIFOFd < 0) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                    "%s:%d Error opening FIFO\n", _FUNCL_);
        iRet = ERR_CWMP_FIFO_OPEN;
        goto errorHandler;
    }

    if(IFX_IPC_SendMsg
       (iFIFOFd, (uchar8) IFX_IPC_APP_DIAGNOSTIC, 0, 0, 0,
        NULL) != IFX_IPC_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Error sending msg to "
                    "FIFO\n", _FUNCL_);
    }
    else
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "message sent\n");

    IFX_OS_CloseFifo(iFIFOFd);


  errorHandler:
    pthread_mutex_unlock(&dd_msg_mutex);
    sleep(2);
    pthread_exit(0);
    return IFX_SUCCESS;
}



/*******************************************************************************
* Function: IFX_DownloadDiagnostics
* Desc:
*
* Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
*             OUT void **ppRet, OUT int32 * piNumRetElem
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_DownloadDiagnostics(IN OperInfo * pxOI,
                        INOUT void *pParamStruct,
                        IN int32 iElements, OUT void **ppRet,
                        OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;
    pthread_t downloadtest;

    switch (pxOI->iOper) {
        case OP_GETVAL:
            switch (pxOI->iSubOper) {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:
                    iRet =
                        IFX_DownloadDiagGetNotifyValue(pxOI, xpParamVal,
                                                       iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n",
                                _FUNCL_, pxOI->iSubOper);
                    break;
            }
            break;
        case OP_SETVAL:
            switch (pxOI->iSubOper) {
                case OP_SETVAL_VALIDATE:
                    iRet = IFX_DownloadDiagValidate(xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_SETVAL_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:
                    break;
                case OP_SETVAL_MODIFY:
                    iRet = IFX_DownloadDiagSetValue(xpParamVal, iElements);
                    if((iRet != IFX_SUCCESS)
                       && (iRet != IFX_CWMP_NEED_ACTIVATE)) {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                                    "%s:%d, IFX_DownloadDiagSetValue() failed! \n",
                                    _FUNCL_);
                        goto errorHandler;
                    }
                    break;
                case OP_SETVAL_ACTIVATE:
                    pthread_mutex_lock(&dd_msg_mutex);
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                                "Creating thread\n");
                    iRet =
                        pthread_create(&downloadtest, NULL,
                                       IFX_DownloadDiagPerformTest, NULL);
                    if(iRet != IFX_SUCCESS)
                        goto errorHandler;
                case OP_SETVAL_COMMIT:
                    break;
                case OP_SETVAL_UNDO:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_DELETE:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_ATTRINFO:
                    iRet =
                        IFX_DownloadDiagSetAttrInfo(pxOI->iCaller, pParamStruct,
                                                    iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                                pxOI->iSubOper);
                    break;
            }
            break;
        case OP_UPDATE_CHILDINFO:
            switch (pxOI->iSubOper) {
                case OP_UPDATE_CHILDINFO_ADD:
                case OP_UPDATE_CHILDINFO_DEL:
                    break;
            }
            break;
        case OP_PARAM_VALIDATE:
            break;
        default:
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                        pxOI->iOper);
            break;
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_DownloadDiagInit

* Parameters:
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_DownloadDiagInit()
{
    int32 iRet = IFX_CWMP_SUCCESS;
    DOWNLOAD_DIAG xDownload;

    memset(&xDownload, '\0', sizeof(xDownload));


    strcpy(xDownload.diag_state, "None");
    strcpy(xDownload.download_url, "");
    strcpy(xDownload.interface, "");
    xDownload.ethernet_priority = 0;
    strcpy(xDownload.ROMTime, "0");
    strcpy(xDownload.BOMTime, "0");
    strcpy(xDownload.EOMTime, "0");
    xDownload.rxTotalBytes = 0;
    xDownload.rxTestBytes = 0;
    xDownload.dscp = 0;
    strcpy(xDownload.tcpOpenRqstTime, "0");
    strcpy(xDownload.tcpOpenRespTime, "0");



    /* Register the IFX_DownloadDiagInit func ptr in the object model */
    iRet = ifx_ds_register_function(DOWNLOADDIAG_OBJ, IFX_DownloadDiagnostics);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Unable to Register %s with Object Model\n",
                    _FUNCL_, iRet, DOWNLOADDIAG_OBJ);
        goto errorHandler;
    }


    // iRet = ifx_set_download_diag(0, &xDownload, IFX_F_INT_ADD |
    // IFX_F_MODIFY);
    iRet = ifx_set_download_diag(&xDownload, IFX_F_INT_ADD);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Writing default "
                    "download_diag section failed in %s\n", _FUNCL_, iRet,
                    IFX_DIAG_FILE);
    }

  errorHandler:
    return iRet;
}
