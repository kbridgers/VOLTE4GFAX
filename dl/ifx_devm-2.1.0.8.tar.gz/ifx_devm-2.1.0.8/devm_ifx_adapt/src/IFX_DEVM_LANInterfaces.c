/*
** =============================================================================
** FILE NAME      : IFX_LANInterface.c
** PROJECT        : TR69
** MODULES        : InternetGatewayDevice.LANInterfaces.
** DATE           : 10-Apr-2012
** AUTHOR         : TR69 team
** DESCRIPTION    : This object is RO. SetParameterValues or AddObject cannot be
**                  performed on this object.
** REFERENCES     :  
** COPYRIGHT      : Copyright (c) 2006
**                  Infineon Technologies AG
**                  Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
** HISTORY        : 
** $Date        $Author          $Comment
** 19-Jun-2006  TR69 team        Creation         
** =============================================================================
*/
#include "IFX_DEVM_Global.h"

#include "IFX_DEVM_AdaptCommon.h"
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"

extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char8 * obj, modFunc pifx_module_func);

#define LANINTERFACE_OBJ       "InternetGatewayDevice.LANInterfaces."
#define LANINTERFACE_DEPTH     3


/*******************************************************************************
* Function: IFX_LANInterfaceSetAttrInfo
* Description: Sets attribute information in the respective tr69 sections
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_LANInterfaceSetAttrInfo(IN int32 iCaller, INOUT ParamVal * pxPV,
                         IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    iRet = IFX_SetAttributesInfo(NULL, pxPV, iElements);

    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Updating Param Attribute Info failed\n",
                    __func__, __LINE__, iRet);
        goto errorHandler;
    }
  errorHandler:
    return iRet;
}



/*******************************************************************************
* Function: IFX_LANInterface_GetNotifyValue
* Description: 
*              
* Parameters: IN OperInfo *pxOI, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_LANInterface_GetNotifyValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                      IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    char8 sTmp[3] = { 0 };

    for(iI = 0; iI < iElements; iI++) {
        pxPV[iI].Value = IFX_CWMP_MALLOC(8);
        if(pxPV[iI].Value == NULL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", __func__, __LINE__);
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (pxPV[iI].iaOID[LANINTERFACE_DEPTH - 1]) {
            case OID_IGD_LANI_LANETHERNETINTERFACENUMBEROFENTRIES:
                sprintf(sTmp, "%d", 4);
                strcpy(pxPV[iI].Value, sTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_CHANGE_FLAG_BASED);
                break;
	    case OID_IGD_LANI_LANUSBINTERFACENUMBEROFENTRIES:
		sprintf(sTmp, "%d", 0);
		strcpy (pxPV[iI].Value, sTmp);
		IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_CHANGE_FLAG_BASED);
		break;
            case OID_IGD_LANI_LANWLANCONFIGURATIONNUMBEROFENTRIES:
                sprintf(sTmp, "%d", 4);
                strcpy(pxPV[iI].Value, sTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_CHANGE_FLAG_BASED);
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                            "Default case\n", __func__, __LINE__,
                            pxPV[iI].iaOID[LANINTERFACE_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}



/*******************************************************************************
* Function: IFX_LANInterfaceValidate
* Description:
*              
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_LANInterfaceValidate(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[LANINTERFACE_DEPTH - 1]) {
            case OID_IGD_LANI_LANETHERNETINTERFACENUMBEROFENTRIES:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
	    case OID_IGD_LANI_LANUSBINTERFACENUMBEROFENTRIES:
		iRet = ERR_CWMP_INVAL_ARGS;
		 pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                 break;
            case OID_IGD_LANI_LANWLANCONFIGURATIONNUMBEROFENTRIES:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                            "Default case\n", __func__, __LINE__,
                            pxPV[iI].iaOID[LANINTERFACE_DEPTH - 1]);
                break;
        }
    }
    return iRet;
}

/*******************************************************************************
* Function: IFX_LANInterface 
* Description: 
*              
* Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
*             OUT void **ppRet, OUT int32 * piNumRetElem
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_LANInterface(IN OperInfo * pxOI, INOUT void *pParamStruct,
              IN int32 iElements, OUT void **ppRet, OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s: %s oper=%d maxElement=%d\n",
                __func__, xpParamVal[0].Name, pxOI->iSubOper, iElements);

    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:
                    iRet = IFX_LANInterface_GetNotifyValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                    if((iRet = IFX_LANInterfaceValidate(xpParamVal, iElements)) != 0) {
                        goto errorHandler;
                    }
                    break;
                case OP_SETVAL_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:
                    break;
                case OP_SETVAL_MODIFY:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_COMMIT:
                    break;
                case OP_SETVAL_UNDO:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_DELETE:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_ATTRINFO:
                    iRet = IFX_LANInterfaceSetAttrInfo(pxOI->iCaller,pParamStruct,iElements);;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_UPDATE_CHILDINFO_DEL:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break;
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d [%d] Error! Default case.\n", __func__,
                        __LINE__, pxOI->iOper);
            break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_LANIf_Init
* Description: Will initialize some of its data structures, register itself with 
*              DS.
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_LANIf_Init()
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Perform any other IGD related initializations here */

    /* Register the IFX_InternetGatewayDevice func ptr in the object model */
    iRet = ifx_ds_register_function(LANINTERFACE_OBJ,IFX_LANInterface);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Unable to "
                    "Register %s with Object Model\n", __func__, __LINE__, iRet,
                    LANINTERFACE_OBJ);
        goto errorHandler;
    }

  errorHandler:
    return iRet;
}

