
/*
** =============================================================================
** FILE NAME   : IFX_DEVM_UploadDiags.c
** PROJECT     : TR69
** MODULES     : (InternetGateway) Device.UploadDiagnostics.
** DATE        :
** AUTHOR      : TR69 team
** DESCRIPTION : AddObject / DeleteObject cannot be performed on this object.
**
** REFERENCES  :
** COPYRIGHT   : Copyright (c) 2006
**               Infineon Technologies AG
**               Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY     :
** $Date       $Author        $Comment
**             TR69 team      Creation
** =============================================================================
*/

#include "IFX_DEVM_Global.h"

#include "IFX_DEVM_AdaptCommon.h"


#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_StackUtil.h"
#include <resolv.h>
#include <pthread.h>


extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char *obj, modFunc pifx_module_func);
extern int32 IFX_ContAddObj(IN int32 iCaller, IN char8 * psObj);
extern int32 IFX_ContDelObj(IN int32 iCaller, IN char8 * psObj,
                            IN int32 iSession);

#ifndef DEVICE_SUPPORT
#define UPLOADDIAG_OBJ                      FORMNAME("UploadDiagnostics.")
#define UPLOADDIAG_DEPTH                    3
#endif // DEVICE_SUPPORT

#ifdef DEVICE_SUPPORT
#define UPLOADDIAG_OBJ                      FORMNAME("LAN.UploadDiagnostics.")
#define UPLOADDIAG_DEPTH                    4
#endif // DEVICE_SUPPORT

#define MAX_NUM_LEN          12
#define LINESIZE             256

extern int32 IFX_UploadTest(UPLOAD_DIAG * xUpload, char *Iface);
char gsULInterface[64] = { 0 };

pthread_mutex_t ud_msg_mutex = PTHREAD_MUTEX_INITIALIZER;

/*******************************************************************************
* Function: IFX_UploadDiagSetAttrInfo
* Desc: Sets attribute information in the respective tr69 sections
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_UploadDiagSetAttrInfo(IN int32 iCaller, INOUT ParamVal * pxPV,
                          IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    iRet = IFX_SetAttributesInfo(NULL, pxPV, iElements);

    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Updating Param Attribute Info failed\n",
                    _FUNCL_, iRet);
        goto errorHandler;
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_UploadDiagGetNotifyValue
* Desc: gets valure from the config file and returns
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_UploadDiagGetNotifyValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                             IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    UPLOAD_DIAG xUpload;
    char8 caTmp[64] = { 0 };

    memset(&xUpload, '\0', sizeof(xUpload));
    iRet = ifx_get_upload_diag(&xUpload);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_upload_diag() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
    for(iI = 0; iI < iElements; iI++) {
        pxPV[iI].Value = IFX_CWMP_MALLOC(257);
        if(pxPV[iI].Value == NULL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", _FUNCL_);
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (pxPV[iI].iaOID[UPLOADDIAG_DEPTH - 1]) {
            case OID_IGD_UD_DIAGNOSTICSSTATE:
                strcpy(pxPV[iI].Value, xUpload.diag_state);
                break;
            case OID_IGD_UD_INTERFACE:
                strcpy(pxPV[iI].Value, xUpload.interface);
                break;
            case OID_IGD_UD_UPLOADURL:
                strcpy(pxPV[iI].Value, xUpload.upload_url);
                break;
            case OID_IGD_UD_ETHERNETPRIORITY:
                sprintf(pxPV[iI].Value, "%u", xUpload.ethernet_priority);
                break;
            case OID_IGD_UD_ROMTIME:
                strcpy(pxPV[iI].Value, xUpload.ROMTime);
                break;
            case OID_IGD_UD_BOMTIME:
                strcpy(pxPV[iI].Value, xUpload.BOMTime);
                break;
            case OID_IGD_UD_EOMTIME:
                strcpy(pxPV[iI].Value, xUpload.EOMTime);
                break;
            case OID_IGD_UD_DSCP:
                sprintf(pxPV[iI].Value, "%d", xUpload.dscp);
                break;
            case OID_IGD_UD_TESTFILELENGTH:
                sprintf(pxPV[iI].Value, "%u", xUpload.test_file_len);
                break;
            case OID_IGD_UD_TOTALBYTESSENT:
                sprintf(caTmp, "%d", xUpload.txTotalBytes);
                strcpy(pxPV[iI].Value, caTmp);
                break;
            case OID_IGD_UD_TCPOPENREQUESTTIME:
                sprintf(caTmp, "%s", xUpload.tcpOpenRqstTime);
                strcpy(pxPV[iI].Value, caTmp);
                break;

            case OID_IGD_UD_TCPOPENRESPONSETIME:
                sprintf(caTmp, "%s", xUpload.tcpOpenRespTime);
                strcpy(pxPV[iI].Value, caTmp);
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", _FUNCL_,
                            pxPV[iI].iaOID[UPLOADDIAG_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_UploadValidateInterface
* Desc: Validates the psInterface parameter passed. Is Successful, psIPAddr
*       will contain the IPAddress of the interface (Depending on being a
*       WANDevice or LANDevice). psIPAddr should be allocated by the caller of
*       this function.
* Parameters: IN char8 * psInterface, OUT char8 * psIPAddr
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_UploadValidateInterface(IN char8 * psInterface, OUT char8 * psIPAddr)
{
    int32 iRet = IFX_CWMP_SUCCESS;


/*	if(psInterface == NULL)
	{
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d NULL interface name\n", _FUNCL_);
		goto errorHandler;
	}

	if (strstr(psInterface, "WANDevice"))
	{
	}
	else if (strstr(psInterface, "LANDevice"))
	{
	}
	else
	{
		iRet = IFX_CWMP_FAILURE;
		goto errorHandler;
	}

errorHandler:*/
    return iRet;
}

/*******************************************************************************
* Function: IFX_UploadDiagValidate
* Desc:
*
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_UploadDiagValidate(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0, iTmp = 0;
    char8 sIPAddr[64] = { 0 };


    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[UPLOADDIAG_DEPTH - 1]) {
            case OID_IGD_UD_INTERFACE:

                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "Entered case OID_IGD_UD_INTERFACE:\n");

                iTmp = strlen(pxPV[iI].Value);
                if(iTmp > MAX_IF_NAME) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d Interface len %d > %d (max)\n", _FUNCL_,
                                iTmp, MAX_IF_NAME);
                    iRet = ERR_CWMP_INVAL_PARAM_VAL;
                    goto errorHandler;
                }
                if(iTmp == 0) {
                    /* A NULL interface value is a valid value, use the routing
                       table */
                }
                else {

                    iRet = IFX_UploadValidateInterface(pxPV[iI].Value, sIPAddr);
                    if(iRet != IFX_CWMP_SUCCESS) {

                        iRet = ERR_CWMP_INVAL_ARGS;
                        pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "IFX_UploadValidateInterface FAILED\n");
                        goto errorHandler;
                    }
                }
                break;
            case OID_IGD_UD_UPLOADURL:
                if(strstr(pxPV[iI].Value, "https")) {
                    iRet = ERR_CWMP_INVAL_ARGS;
                    pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "IFX_UploadValidate FAILED\n");
                    goto errorHandler;
                }
                else if(strstr(pxPV[iI].Value, "http://") == 0) {
                    iRet = ERR_CWMP_INVAL_ARGS;
                    pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "IFX_UploadValidate FAILED\n");
                    goto errorHandler;
                }
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Default case\n", _FUNCL_,
                            pxPV[iI].iaOID[UPLOADDIAG_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_UploadDiagSetValue
* Desc:
*
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_UploadDiagSetValue(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0, iActivate = 0;
    UPLOAD_DIAG xUpload;
    ParamVal xGetParam;
    ParamVal *paxGetParamVal = NULL;
    char8 caInterface[CWMP_MAX_OBJ_LEN] = { 0 };
    char sIfName[150] = { 0 };
    uint32 iElemOut;
    int32 wan_type = 0;

    memset(&xUpload, '\0', sizeof(xUpload));

    iRet = ifx_get_upload_diag(&xUpload);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_upload_diag() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[UPLOADDIAG_DEPTH - 1]) {

            case OID_IGD_UD_DIAGNOSTICSSTATE:
                strncpy(xUpload.diag_state, pxPV[iI].Value, MAX_DIAGSTATE_LEN);
                if(strcmp(pxPV[iI].Value, "Requested") == 0)
                    iActivate = IFX_CWMP_NEED_ACTIVATE;
                break;
            case OID_IGD_UD_INTERFACE:
#if 0
                strncpy(xUpload.interface, pxPV[iI].Value, MAX_IF_NAME);
#else
                if(!strcmp(pxPV[iI].Value, "")) {
                    xUpload.interface[0] = '\0';
                    memset(gsULInterface, '\0', sizeof(gsULInterface));
                }
                else if(!strcmp
                        (pxPV[iI].Value,
                         "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.IPInterface.1"))
                {
                    strcpy(gsULInterface, "br0");
                }
                else {
                    memset(&xGetParam, 0x00, sizeof(xGetParam));
                    xGetParam.Name =
                        IFX_CWMP_MALLOC(strlen(pxPV[iI].Value) + 8);
                    if(xGetParam.Name == NULL) {
                        iRet = IFX_CWMP_FAILURE;
                        goto errorHandler;
                    }

                    memset(caInterface, 0, sizeof(caInterface));
                    strcpy(caInterface, pxPV[iI].Value);
                    if(caInterface[strlen(caInterface) - 1] != '.') {
                        strcat(caInterface, ".");
                    }

                    sprintf(xGetParam.Name, "%s%s", (char *)caInterface,
                            "Name");

                    iRet =
                        IFX_GlobalGetVal(&xGetParam, &paxGetParamVal,
                                         (uint32 *) & iElemOut);
                    if(iRet != IFX_CWMP_SUCCESS) {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                                    "[%s] [%d]  IFX_GlobalGetVal failed\n",
                                    __func__, __LINE__);
                        IFX_CWMP_FREE(xGetParam.Name);
                        if(paxGetParamVal != NULL) {
                            IFX_CWMP_FREE(paxGetParamVal->Value);
                            IFX_CWMP_FREE(paxGetParamVal->Name);
                        }
                        IFX_CWMP_FREE(paxGetParamVal);
                        pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        goto errorHandler;
                    }
                    if(strstr(paxGetParamVal->Value, "WANPPP") != NULL) {
                        wan_type = WAN_TYPE_PPP;
                    }
                    else {
                        wan_type = WAN_TYPE_IP;
                    }
                    iRet =
                        ifx_get_wan_ifname_from_connName(paxGetParamVal->Value,
                                                         sIfName, wan_type);
                    if(iRet != IFX_CWMP_SUCCESS) {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                                    "[%s] [%d]  ifx_get_wan_ifname_from_conf_connName failed. Connname: %s\n",
                                    __func__, __LINE__, paxGetParamVal->Value);
                        IFX_CWMP_FREE(xGetParam.Name);
                        IFX_CWMP_FREE(paxGetParamVal->Value);
                        IFX_CWMP_FREE(paxGetParamVal->Name);
                        IFX_CWMP_FREE(paxGetParamVal);
                        iRet = ERR_CWMP_INTERNAL;
                        pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        goto errorHandler;
                    }
                    strncpy(gsULInterface, sIfName, 15);

                    IFX_CWMP_FREE(xGetParam.Name);
                    IFX_CWMP_FREE(paxGetParamVal->Value);
                    IFX_CWMP_FREE(paxGetParamVal->Name);;
                    IFX_CWMP_FREE(paxGetParamVal);
                }
                strcpy(xUpload.interface, pxPV[iI].Value);
#endif
                break;
            case OID_IGD_UD_UPLOADURL:
                strcpy(xUpload.upload_url, pxPV[iI].Value);
                break;
            case OID_IGD_UD_ETHERNETPRIORITY:
                sscanf(pxPV[iI].Value, "%u", &xUpload.ethernet_priority);
                break;
            case OID_IGD_UD_DSCP:
                sscanf(pxPV[iI].Value, "%d", &xUpload.dscp);
                break;
            case OID_IGD_UD_TESTFILELENGTH:
                sscanf(pxPV[iI].Value, "%u", &xUpload.test_file_len);
                break;
            case OID_IGD_UD_ROMTIME:
            case OID_IGD_UD_BOMTIME:
            case OID_IGD_UD_EOMTIME:
            case OID_IGD_UD_TOTALBYTESSENT:
            case OID_IGD_UD_TCPOPENREQUESTTIME:
            case OID_IGD_UD_TCPOPENRESPONSETIME:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%d] [Error] Non-Writable parameter %d!\n",
                            _FUNCL_, pxPV[iI].iaOID[UPLOADDIAG_DEPTH - 1]);
                iRet = ERR_NON_WRITABLE;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE_PARAM;
                goto errorHandler;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%d] [Error] Unknown requested parameter %d!\n",
                            _FUNCL_, pxPV[iI].iaOID[UPLOADDIAG_DEPTH - 1]);
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                pxPV[iI].iFaultCode = ERR_INVAL_PARAMETER_NAME;
                goto errorHandler;
        }
    }

    /* Modifying any of the parameters in this obj except DiagnosticState MUST
       result in the value of DiagnosticState parameter being set to "None" */
    if(iActivate != IFX_CWMP_NEED_ACTIVATE)
        strcpy(xUpload.diag_state, "None");

    iRet = ifx_set_upload_diag(&xUpload, IFX_F_MODIFY);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_set_upload_diag() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }

  errorHandler:
    if((iActivate == IFX_CWMP_NEED_ACTIVATE) && (iRet == IFX_CWMP_SUCCESS))
        iRet = IFX_CWMP_NEED_ACTIVATE;

    return iRet;
}



/*******************************************************************************
* Function: IFX_UploadDiagPerformTest
* Desc: Gets the value. Calls IFX_UploadTest. Set the required value. Posts the
*       message to the Stacks FIFO about the completion of Upload Diag Test
* Parameters:
* Return Value: IFX_CWMP_SUCCESS
*******************************************************************************/
void *
IFX_UploadDiagPerformTest(void *params)
{
    int32 iRet = IFX_CWMP_SUCCESS, iFIFOFd = 0;
    UPLOAD_DIAG xUpload;

    memset(&xUpload, '\0', sizeof(xUpload));
    iRet = ifx_get_upload_diag(&xUpload);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_upload_diag() failed\n", _FUNCL_, iRet);
        goto errorHandler;
    }
    iRet = IFX_UploadTest(&xUpload, gsULInterface);

    // TBD handle error for IFX_UploadTest

    iRet = ifx_set_upload_diag(&xUpload, IFX_F_MODIFY);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_upload_diag() failed\n", _FUNCL_, iRet);
        goto errorHandler;
    }
    /* Send msg to FIFO */
    iFIFOFd = IFX_OS_OpenFifo((uchar8 *) IFX_IPC_TR_FIFO, O_RDWR);
    if(iFIFOFd < 0) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                    "%s:%d Error opening FIFO\n", _FUNCL_);
        iRet = ERR_CWMP_FIFO_OPEN;
        goto errorHandler;
    }

    if(IFX_IPC_SendMsg
       (iFIFOFd, (uchar8) IFX_IPC_APP_DIAGNOSTIC, 0, 0, 0,
        NULL) != IFX_IPC_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Error sending msg to "
                    "FIFO\n", _FUNCL_);
    }
    else
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "message sent\n");

    IFX_OS_CloseFifo(iFIFOFd);


  errorHandler:
    pthread_mutex_unlock(&ud_msg_mutex);
    sleep(2);
    pthread_exit(0);
    return IFX_SUCCESS;

}



/*******************************************************************************
* Function: IFX_UploadDiagnostics
* Desc:
*
* Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
*             OUT void **ppRet, OUT int32 * piNumRetElem
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_UploadDiagnostics(IN OperInfo * pxOI,
                      INOUT void *pParamStruct,
                      IN int32 iElements, OUT void **ppRet,
                      OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;
    pthread_t uploadtest;

    switch (pxOI->iOper) {
        case OP_GETVAL:
            switch (pxOI->iSubOper) {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:
                    iRet =
                        IFX_UploadDiagGetNotifyValue(pxOI, xpParamVal,
                                                     iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n",
                                _FUNCL_, pxOI->iSubOper);
                    break;
            }
            break;
        case OP_SETVAL:
            switch (pxOI->iSubOper) {
                case OP_SETVAL_VALIDATE:
                    iRet = IFX_UploadDiagValidate(xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_SETVAL_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:
                    break;
                case OP_SETVAL_MODIFY:
                    iRet = IFX_UploadDiagSetValue(xpParamVal, iElements);
                    if((iRet != IFX_SUCCESS)
                       && (iRet != IFX_CWMP_NEED_ACTIVATE)) {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                                    "%s:%d, IFX_UploadDiagSetValue() failed! \n",
                                    _FUNCL_);
                        goto errorHandler;
                    }
                    break;
                case OP_SETVAL_ACTIVATE:
                    pthread_mutex_lock(&ud_msg_mutex);
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                                "Creating thread\n");
                    iRet =
                        pthread_create(&uploadtest, NULL,
                                       IFX_UploadDiagPerformTest, NULL);
                    if(iRet != IFX_SUCCESS)
                        goto errorHandler;
                case OP_SETVAL_COMMIT:
                    break;
                case OP_SETVAL_UNDO:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_DELETE:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_ATTRINFO:
                    iRet =
                        IFX_UploadDiagSetAttrInfo(pxOI->iCaller, pParamStruct,
                                                  iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                                pxOI->iSubOper);
                    break;
            }
            break;
        case OP_UPDATE_CHILDINFO:
            switch (pxOI->iSubOper) {
                case OP_UPDATE_CHILDINFO_ADD:
                case OP_UPDATE_CHILDINFO_DEL:
                    break;
            }
            break;
        case OP_PARAM_VALIDATE:
            break;
        default:
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                        pxOI->iOper);
            break;
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_UploadDiagInit

* Parameters:
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_UploadDiagInit()
{
    int32 iRet = IFX_CWMP_SUCCESS;
    UPLOAD_DIAG xUpload;

    memset(&xUpload, '\0', sizeof(xUpload));


    strcpy(xUpload.diag_state, "None");
    strcpy(xUpload.upload_url, "");
    strcpy(xUpload.interface, "");
    xUpload.ethernet_priority = 0;
    strcpy(xUpload.ROMTime, "0");
    strcpy(xUpload.BOMTime, "0");
    strcpy(xUpload.EOMTime, "0");
    xUpload.txTotalBytes = 0;
    xUpload.dscp = 0;
    xUpload.test_file_len = 0;
    strcpy(xUpload.tcpOpenRqstTime, "0");
    strcpy(xUpload.tcpOpenRespTime, "0");



    /* Register the IFX_UploadDiagInit func ptr in the object model */
    iRet = ifx_ds_register_function(UPLOADDIAG_OBJ, IFX_UploadDiagnostics);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Unable to Register %s with Object Model\n",
                    _FUNCL_, iRet, UPLOADDIAG_OBJ);
        goto errorHandler;
    }


    // iRet = ifx_set_upload_diag(0, &xUpload, IFX_F_INT_ADD |
    // IFX_F_MODIFY);
    iRet = ifx_set_upload_diag(&xUpload, IFX_F_INT_ADD);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Writing default "
                    "upload_diag section failed in %s\n", _FUNCL_, iRet,
                    IFX_DIAG_FILE);
    }

  errorHandler:
    return iRet;
}
