/*
** =============================================================================
**   FILE NAME        : IFX_WlanConfiguration.c
**   PROJECT          : TR69
**   MODULES          : WlanConfiguration
**   DATE             :
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This module handles ADD/DEL/GET/SET RPCs of
**                      Wlan related onjects. When controller calls this module it
**                      calls respective Platform/Object APIs to handle GET/SET
**                      of WlanConfiguration specific information on the sytem.
**
**   REFERENCES       :
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          :
**   $Date            $Author        $Comment
**   		         TR69 team      Intial version
** ============================================================================
*/
/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_WLANConfiguration.h"
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;

#ifdef IFX_TR69_DEVICE 
	#define	OID_IGD_LAND_WLANC_ENABLE	OID_IGD_LAN_WLANC_ENABLE
	#define OID_IGD_LAND_WLANC_STATUS	OID_IGD_LAN_WLANC_STATUS
	#define OID_IGD_LAND_WLANC_NAME    	OID_IGD_LAN_WLANC_NAME
	#define OID_IGD_LAND_WLANC_BSSID	OID_IGD_LAN_WLANC_BSSID
	#define OID_IGD_LAND_WLANC_CHANNEL	OID_IGD_LAN_WLANC_CHANNEL
	#define OID_IGD_LAND_WLANC_AUTOCHANNELENABLE	OID_IGD_LAN_WLANC_AUTOCHANNELENABLE
	#define OID_IGD_LAND_WLANC_SSID		OID_IGD_LAN_WLANC_SSID
	#define OID_IGD_LAND_WLANC_BEACONTYPE	OID_IGD_LAN_WLANC_BEACONTYPE
	#define OID_IGD_LAND_WLANC_MACADDRESSCONTROLENABLED	OID_IGD_LAN_WLANC_MACADDRESSCONTROLENABLED
	#define OID_IGD_LAND_WLANC_STANDARD	OID_IGD_LAN_WLANC_STANDARD
	#define OID_IGD_LAND_WLANC_WEPKEYINDEX	OID_IGD_LAN_WLANC_WEPKEYINDEX
	#define OID_IGD_LAND_WLANC_KEYPASSPHRASE	OID_IGD_LAN_WLANC_KEYPASSPHRASE
	#define OID_IGD_LAND_WLANC_WEPENCRYPTIONLEVEL	OID_IGD_LAN_WLANC_WEPENCRYPTIONLEVEL
	#define OID_IGD_LAND_WLANC_POSSIBLECHANNELS	OID_IGD_LAN_WLANC_POSSIBLECHANNELS
	#define OID_IGD_LAND_WLANC_BASICDATATRANSMITRATES	OID_IGD_LAN_WLANC_BASICDATATRANSMITRATES
	#define OID_IGD_LAND_WLANC_OPERATIONALDATATRANSMITRATES	OID_IGD_LAN_WLANC_OPERATIONALDATATRANSMITRATES
	#define OID_IGD_LAND_WLANC_POSSIBLEDATATRANSMITRATES	OID_IGD_LAN_WLANC_POSSIBLEDATATRANSMITRATES
	#define OID_IGD_LAND_WLANC_BEACONADVERTISEMENTENABLED	OID_IGD_LAN_WLANC_BEACONADVERTISEMENTENABLED
	#define OID_IGD_LAND_WLANC_SSIDADVERTISEMENTENABLED	OID_IGD_LAN_WLANC_SSIDADVERTISEMENTENABLED
	#define OID_IGD_LAND_WLANC_RADIOENABLED		OID_IGD_LAN_WLANC_RADIOENABLED
	#define OID_IGD_LAND_WLANC_TRANSMITPOWERSUPPORTED	OID_IGD_LAN_WLANC_TRANSMITPOWERSUPPORTED
	#define OID_IGD_LAND_WLANC_TRANSMITPOWER	OID_IGD_LAN_WLANC_TRANSMITPOWER
	#define OID_IGD_LAND_WLANC_AUTORATEFALLBACKENABLED	OID_IGD_LAN_WLANC_AUTORATEFALLBACKENABLED
	#define OID_IGD_LAND_WLANC_WMMSUPPORTED			OID_IGD_LAN_WLANC_WMMSUPPORTED
	#define OID_IGD_LAND_WLANC_UAPSDSUPPORTED		OID_IGD_LAN_WLANC_UAPSDSUPPORTED
	#define OID_IGD_LAND_WLANC_WMMENABLE			OID_IGD_LAN_WLANC_WMMENABLE
	#define OID_IGD_LAND_WLANC_UAPSDENABLE			OID_IGD_LAN_WLANC_UAPSDENABLE
	#define OID_IGD_LAND_WLANC_TOTALBYTESSENT		OID_IGD_LAN_WLANC_TOTALBYTESSENT
	#define OID_IGD_LAND_WLANC_TOTALBYTESRECEIVED		OID_IGD_LAN_WLANC_TOTALBYTESRECEIVED
	#define OID_IGD_LAND_WLANC_TOTALPACKETSSENT		OID_IGD_LAN_WLANC_TOTALPACKETSSENT
	#define OID_IGD_LAND_WLANC_TOTALPACKETSRECEIVED		OID_IGD_LAN_WLANC_TOTALPACKETSRECEIVED
	#define OID_IGD_LAND_WLANC_TOTALASSOCIATIONS		OID_IGD_LAN_WLANC_TOTALASSOCIATIONS
	#define OID_IGD_LAND_WLANC_TOTALPSKFAILURES	OID_IGD_LAN_WLANC_TOTALPSKFAILURES 
	#define OID_IGD_LAND_WLANC_TOTALINTEGRITYFAILURES	OID_IGD_LAN_WLANC_TOTALINTEGRITYFAILURES 
	#define OID_IGD_LAND_WLANC_CHANNELSINUSE	OID_IGD_LAN_WLANC_CHANNELSINUSE
	#define OID_IGD_LAND_WLANC_DEVICEOPERATIONMODE	OID_IGD_LAN_WLANC_DEVICEOPERATIONMODE
	#define OID_IGD_LAND_WLANC_CHANNEL		OID_IGD_LAN_WLANC_CHANNEL
	#define OID_IGD_LAND_WLANC_WEPKEYINDEX		OID_IGD_LAN_WLANC_WEPKEYINDEX
	#define OID_IGD_LAND_WLANC_BASICENCRYPTIONMODES		OID_IGD_LAN_WLANC_BASICENCRYPTIONMODES
	#define OID_IGD_LAND_WLANC_BASICAUTHENTICATIONMODE	OID_IGD_LAN_WLANC_BASICAUTHENTICATIONMODE
	#define OID_IGD_LAND_WLANC_WPAENCRYPTIONMODES		OID_IGD_LAN_WLANC_WPAENCRYPTIONMODES
	#define OID_IGD_LAND_WLANC_WPAAUTHENTICATIONMODE	OID_IGD_LAN_WLANC_WPAAUTHENTICATIONMODE
	#define OID_IGD_LAND_WLANC_IEEE11IENCRYPTIONMODES	OID_IGD_LAN_WLANC_IEEE11IENCRYPTIONMODES
	#define OID_IGD_LAND_WLANC_IEEE11IAUTHENTICATIONMODE	OID_IGD_LAN_WLANC_IEEE11IAUTHENTICATIONMODE	
	#define OID_IGD_LAND_WLANC_MAXBITRATE		OID_IGD_LAN_WLANC_MAXBITRATE 
#endif
	
#define IFX_WLAN_CONF_OBJ FORMLANNAME("WLANConfiguration.1.")
#define LTQ_WLAN_MACADDRESS_DENY	1
#define LTQ_WLAN_MACADDRESS_ALLOW	0
#define LTQ_WLAN_MCADDDRESS_DISABLE     2

int32 LTQ_DEVM_GetMainNStats(int32 iCpeid, IFX_MAPI_WLAN_AP_Cfg *wlCfg, IFX_MAPI_WLAN_Stats *wlStats);
/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/
/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS>
**
** =============================================================================
*/



int32 LTQ_DEVM_GetMainNStats(int32 iCpeid, IFX_MAPI_WLAN_AP_Cfg *wlCfg, IFX_MAPI_WLAN_Stats *wlStats)
{
    int32 iRet = 0;

    if((wlCfg == NULL) || (wlStats == NULL))
    {
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Error!\n", _FUNCL_);
	goto ErrorHandler;
    }

    wlCfg->iid.cpeId.Id = iCpeid;
    
    wlCfg->phy.iid.cpeId.Id = 1;
    strcpy(wlCfg->phy.iid.cpeId.secName,"wlan_phy");
    wlCfg->phy.iid.pcpeId.Id = 1;
    strcpy(wlCfg->phy.iid.pcpeId.secName,"land");
    
    wlCfg->main.iid.cpeId.Id = iCpeid;
    strcpy(wlCfg->main.iid.cpeId.secName,"wlan_main");
    wlCfg->main.iid.pcpeId.Id = 1;
    strcpy(wlCfg->main.iid.pcpeId.secName,"land");
    
    wlCfg->sec.iid.cpeId.Id = iCpeid;
    strcpy(wlCfg->sec.iid.cpeId.secName,"wlan_security");
    wlCfg->sec.iid.pcpeId.Id = 1;
    strcpy(wlCfg->sec.iid.pcpeId.secName,"land");

    
    //Get match object from system using MAPI
    iRet = ifx_mapi_get_wlan_ap_config(wlCfg, IFX_F_GET_ANY);
    if (iRet != IFX_CWMP_SUCCESS)
    {
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Error!\n", _FUNCL_);
	goto ErrorHandler;
    }

    wlStats->iid.cpeId.Id = iCpeid;
    // Get the Wlan stats
    iRet = ifx_mapi_get_wlan_stats(wlStats,IFX_F_GET_ANY);
    if (iRet != IFX_CWMP_SUCCESS)
    {
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Error!\n", _FUNCL_);
	goto ErrorHandler;
    }

ErrorHandler:
    return iRet;
}
/*
** =============================================================================
**   Function Name    : IFX_WlanConfGetValue
**   Description      :
**   Parameters       :
**   Return Value     :
**   Notes            :
** ============================================================================
*/
static int32
IFX_WlanConfGetValue(IN OperInfo * pxOperInfo, INOUT ParamVal * pxGetParamVal,
                     IN uint32 iElements)
{
    uint32 iCpeid = 0, i = 0, iJ =0;
    char8 tmp[64];
    uint32 uiParamPos = 0, iParamId = 0;
#if 0
    char tmp[128]={0};
    int (*wlan_capability)(IFX_MAPI_WLAN_Capability *,uint32) = NULL;
    uint32 ti = 0;
#endif
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 numAssoc=0;
    IFX_MAPI_WLAN_AP_Cfg wlCfg;
    IFX_MAPI_WLAN_Stats wlStats;
    IFX_MAPI_WLAN_ChannelList wlan_ChannelList;
    IFX_MAPI_WLAN_AssocInfo *assoDev=NULL;
 //   IFX_MAPI_WLAN_Capability   wlCaps;

#ifdef CONFIG_FEATURE_IFX_WIRELESS_WAVE300
    FILE *fptr1=NULL;
    char line[128], *lptr=NULL, channels[128] ={0}, chan[4] = {0};
    int line_no=0, bss=0;
#endif
    LTQ_LOG_TIMESTAMP("Begin");

    memset(&wlCfg,0x00, sizeof(IFX_MAPI_WLAN_AP_Cfg));
    memset(&wlStats,0x00,sizeof(IFX_MAPI_WLAN_Stats));
    memset(&wlan_ChannelList, 0x00, sizeof(wlan_ChannelList));

    // Get Cpeid from object ID
    iRet = IFX_GetCpeId(pxGetParamVal->iaOID, &iCpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    wlCfg.iid.cpeId.Id = iCpeid;
    
    wlCfg.phy.iid.cpeId.Id = 1;
    strcpy(wlCfg.phy.iid.cpeId.secName,"wlan_phy");
    wlCfg.phy.iid.pcpeId.Id = 1;
    strcpy(wlCfg.phy.iid.pcpeId.secName,"land");
    
    wlCfg.main.iid.cpeId.Id = iCpeid;
    strcpy(wlCfg.main.iid.cpeId.secName,"wlan_main");
    wlCfg.main.iid.pcpeId.Id = 1;
    strcpy(wlCfg.main.iid.pcpeId.secName,"land");
    
    wlCfg.sec.iid.cpeId.Id = iCpeid;
    strcpy(wlCfg.sec.iid.cpeId.secName,"wlan_security");
    wlCfg.sec.iid.pcpeId.Id = 1;
    strcpy(wlCfg.sec.iid.pcpeId.secName,"land");
        
    //Get match object from system using MAPI
    iRet = ifx_mapi_get_wlan_ap_config(&wlCfg, IFX_F_GET_ANY);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    wlStats.iid.cpeId.Id = iCpeid;
    // Get the Wlan stats
    iRet = ifx_mapi_get_wlan_stats(&wlStats,IFX_F_GET_ANY);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Get the WlanConfParamPos
    uiParamPos = IFX_GetParamIdPos(pxGetParamVal->iaOID);
    for (i = 0; i < iElements; i++)
    {
        // Malloc and assign the pointer to the Value attr of struct
        pxGetParamVal[i].Value = IFIN_CWMP_MALLOC(257);
        if (pxGetParamVal[i].Value == NULL)
        {
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }
        iParamId = pxGetParamVal[i].iaOID[uiParamPos];
    
        switch (iParamId)
        {
        case OID_IGD_LAND_WLANC_ENABLE:
            if (wlCfg.main.apEnable)
            {
                strcpy(pxGetParamVal[i].Value,"1");
            }
            else
            {
                strcpy(pxGetParamVal[i].Value,"0");
            }
            break;
        case OID_IGD_LAND_WLANC_STATUS:
            if (wlCfg.main.apEnable)
            {
                strcpy(pxGetParamVal[i].Value,"Up");
            }
            else
            {
                strcpy(pxGetParamVal[i].Value,"Disabled");
            }
            IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal + i,
                                     IFX_CHK_CHANGE_FLAG_BASED);
            break;
        case OID_IGD_LAND_WLANC_NAME:
            strcpy(pxGetParamVal[i].Value,wlCfg.main.apName);
            break;
        case OID_IGD_LAND_WLANC_BSSID:
            strcpy(pxGetParamVal[i].Value, wlCfg.main.bssid);
            IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal + i,
                                     IFX_CHK_CHANGE_FLAG_BASED);
            break;
        case OID_IGD_LAND_WLANC_MAXBITRATE:
            if(wlCfg.main.maxBitRate==0.0) {
	        strcpy(pxGetParamVal[i].Value, "Auto");
	    } else {
	        sprintf(pxGetParamVal[i].Value, "%2.1f", wlCfg.main.maxBitRate);
	    }
            break;
        case OID_IGD_LAND_WLANC_CHANNEL:
            sprintf(pxGetParamVal[i].Value, "%u", wlCfg.phy.channelNo);
            break;
        case OID_IGD_LAND_WLANC_AUTOCHANNELENABLE:
            sprintf(pxGetParamVal[i].Value, "%u", wlCfg.phy.autoChannelEna);
            break;
        case OID_IGD_LAND_WLANC_SSID:
            strcpy(pxGetParamVal[i].Value, wlCfg.main.ssid);

            break;
        case OID_IGD_LAND_WLANC_BEACONTYPE:
	    if (wlCfg.sec.beaconType==IFX_MAPI_WLAN_BEACON_NONE){
        	strcpy(pxGetParamVal[i].Value,"None"); 
	    }
            else if (wlCfg.sec.beaconType==IFX_MAPI_WLAN_BEACON_BASIC)
                strcpy(pxGetParamVal[i].Value,"Basic");
            else if (wlCfg.sec.beaconType==IFX_MAPI_WLAN_BEACON_WPA)
                strcpy(pxGetParamVal[i].Value,"WPA");
            else if (wlCfg.sec.beaconType==IFX_MAPI_WLAN_BEACON_WPA2)
                strcpy(pxGetParamVal[i].Value,"11i");
            else if (wlCfg.sec.beaconType==IFX_MAPI_WLAN_BEACON_WPA_WPA2)
                strcpy(pxGetParamVal[i].Value,"WPAand11i");

            break;
        case OID_IGD_LAND_WLANC_MACADDRESSCONTROLENABLED:
            if ((wlCfg.sec.macAddrCntrlEna == IFX_MAPI_MACADDR_CONTROL_ALLOW) || (wlCfg.sec.macAddrCntrlEna == IFX_MAPI_MACADDR_CONTROL_DENY))
            {
		sprintf(pxGetParamVal[i].Value, "%d", TRUE);
            }
            else
            {
		sprintf(pxGetParamVal[i].Value, "%d", FALSE);
            }

            break;
        case OID_IGD_LAND_WLANC_STANDARD:
            if (wlCfg.phy.standard==IFX_MAPI_WLAN_STD_802_11BG){
		     strcpy(pxGetParamVal[i].Value,"b+g");
		}
	    else{
                strcpy(pxGetParamVal[i].Value,"g");
	    }
            if (wlCfg.phy.standard==IFX_MAPI_WLAN_STD_802_11A)
                strcpy(pxGetParamVal[i].Value,"a");
            else if (wlCfg.phy.standard==IFX_MAPI_WLAN_STD_802_11B)
                strcpy(pxGetParamVal[i].Value,"b");
            else if (wlCfg.phy.standard==IFX_MAPI_WLAN_STD_802_11G)
                strcpy(pxGetParamVal[i].Value,"g-only");
            else if (wlCfg.phy.standard==IFX_MAPI_WLAN_STD_802_11N)
                strcpy(pxGetParamVal[i].Value,"n");
            else if (wlCfg.phy.standard==IFX_MAPI_WLAN_STD_802_11AN)
                strcpy(pxGetParamVal[i].Value,"an");
            else if (wlCfg.phy.standard==IFX_MAPI_WLAN_STD_802_11BGN)
                strcpy(pxGetParamVal[i].Value,"bgn");
            IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal + i,
                                     IFX_CHK_CHANGE_FLAG_BASED);
            break;
        case OID_IGD_LAND_WLANC_WEPKEYINDEX:
 	            if(wlCfg.sec.beaconType != IFX_MAPI_WLAN_BEACON_BASIC)
             	    {
                	uint32 wepKeyIndex;
			iRet = ifx_mapi_get_wlan_wepkeyindex(iCpeid, &wepKeyIndex);
                	if (iRet != IFX_CWMP_SUCCESS)
                        	goto errorHandler;
                	sprintf(pxGetParamVal[i].Value,"%d", wepKeyIndex + 1);
            	    } else {
                	sprintf(pxGetParamVal[i].Value,"%d",(wlCfg.sec.secParams.wepCfg.wepKeyIndex) + 1);
                	IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal + i,
                                     IFX_CHK_CHANGE_FLAG_BASED);
            	    }
            break;
        case OID_IGD_LAND_WLANC_KEYPASSPHRASE:
            strcpy(pxGetParamVal[i].Value, "");  
            break;

        case OID_IGD_LAND_WLANC_WEPENCRYPTIONLEVEL:
            if (wlCfg.sec.secParams.wepCfg.wepEncrLevel)
                strcpy(pxGetParamVal[i].Value,"128-bit");
            else
                strcpy(pxGetParamVal[i].Value,"64-bit");
            break;
        case OID_IGD_LAND_WLANC_BASICENCRYPTIONMODES:
            if (wlCfg.sec.basicEncr==IFX_MAPI_WLAN_ENCR_NONE)
                strcpy(pxGetParamVal[i].Value,"None");
            else if (wlCfg.sec.basicEncr==IFX_MAPI_WLAN_ENCR_WEP)
                strcpy(pxGetParamVal[i].Value,"WEPEncryption");
            else
                strcpy(pxGetParamVal[i].Value,"None");
            break;
        case OID_IGD_LAND_WLANC_BASICAUTHENTICATIONMODE:
            if (wlCfg.sec.basicAuth==IFX_MAPI_WLAN_AUTH_OPEN)
                strcpy(pxGetParamVal[i].Value,"None");

	    else if (wlCfg.sec.basicAuth==IFX_MAPI_WLAN_AUTH_PERSONAL)
                strcpy(pxGetParamVal[i].Value,"EAPAuthentication");
            else if (wlCfg.sec.basicAuth==IFX_MAPI_WLAN_AUTH_SHARED)
                strcpy(pxGetParamVal[i].Value,"SharedAuthentication");
            else
                strcpy(pxGetParamVal[i].Value,"None");

            break;

        case OID_IGD_LAND_WLANC_WPAENCRYPTIONMODES:
            if (wlCfg.sec.wlEncr == IFX_MAPI_WLAN_ENCR_WEP)
				strcpy(pxGetParamVal[i].Value,"WEPEncryption");
            else if (wlCfg.sec.wlEncr == IFX_MAPI_WLAN_ENCR_TKIP)
                strcpy(pxGetParamVal[i].Value,"TKIPEncryption");
            else if (wlCfg.sec.wlEncr == IFX_MAPI_WLAN_ENCR_CCMP)
                strcpy(pxGetParamVal[i].Value,"AESEncryption");
            else if (wlCfg.sec.wlEncr == IFX_MAPI_WLAN_ENCR_TKIP_CCMP)
                strcpy(pxGetParamVal[i].Value,"TKIPandAESEncryption");
            else
                strcpy(pxGetParamVal[i].Value,"TKIPEncryption");

            break;

        case OID_IGD_LAND_WLANC_WPAAUTHENTICATIONMODE:
            if (wlCfg.sec.wlAuth == IFX_MAPI_WLAN_AUTH_PERSONAL)
                strcpy(pxGetParamVal[i].Value,"PSKAuthentication");
            else if (wlCfg.sec.wlAuth == IFX_MAPI_WLAN_AUTH_RADIUS)
                strcpy(pxGetParamVal[i].Value,"EAPAuthentication");
            else
                strcpy(pxGetParamVal[i].Value,"PSKAuthentication");

            break;
        case OID_IGD_LAND_WLANC_IEEE11IENCRYPTIONMODES:
            if (wlCfg.sec.wpa2Encr == IFX_MAPI_WLAN_ENCR_WEP) 
				strcpy(pxGetParamVal[i].Value,"WEPEncryption");
            else if (wlCfg.sec.wpa2Encr == IFX_MAPI_WLAN_ENCR_TKIP)
                strcpy(pxGetParamVal[i].Value,"TKIPEncryption");
            else if (wlCfg.sec.wpa2Encr == IFX_MAPI_WLAN_ENCR_CCMP)
                strcpy(pxGetParamVal[i].Value,"AESEncryption");
            else if (wlCfg.sec.wpa2Encr == IFX_MAPI_WLAN_ENCR_TKIP_CCMP)
                strcpy(pxGetParamVal[i].Value,"TKIPandAESEncryption");
            else
                strcpy(pxGetParamVal[i].Value,"AESEncryption");

            break;
        case OID_IGD_LAND_WLANC_IEEE11IAUTHENTICATIONMODE:
            if (wlCfg.sec.wpa2Auth == IFX_MAPI_WLAN_AUTH_PERSONAL) 
                strcpy(pxGetParamVal[i].Value,"PSKAuthentication");
            else if (wlCfg.sec.wpa2Auth == IFX_MAPI_WLAN_AUTH_RADIUS)
                strcpy(pxGetParamVal[i].Value,"EAPAuthentication");
            else
                strcpy(pxGetParamVal[i].Value,"PSKAuthentication");

            break;
        case OID_IGD_LAND_WLANC_POSSIBLECHANNELS:
            if (ifx_mapi_get_wlan_channel_list(iCpeid, &wlan_ChannelList,IFX_F_DEFAULT) ==
                    IFX_CWMP_SUCCESS)
            {
                //for (iJ = 0; iJ < IFX_WLAN_MAX_SUPPORTED_CHANNELS; iJ++)
                for (iJ = 0; iJ < IFX_MAPI_WLAN_MAX_PHY_CHANNELS; iJ++)
                {
                    if (wlan_ChannelList.chanNumList[iJ] != 0)
                    {
                        memset(tmp, '\0', sizeof(tmp));
                        sprintf(tmp, "%u,", wlan_ChannelList.chanNumList[iJ]);
                        strcat(pxGetParamVal[i].Value, tmp);
                    }
                    else
                    {
                        break;
                    }
                }
            }
            break;
        case OID_IGD_LAND_WLANC_BASICDATATRANSMITRATES:
            for (iJ = 0; iJ < IFX_MAPI_WLAN_MAX_DATA_RATES_NUM; iJ++)
            {
                if (wlCfg.main.basicDataRates[iJ] != 0)
                {
                    memset(tmp, '\0', sizeof(tmp));
                    sprintf(tmp, "%.1f,",
                            wlCfg.main.basicDataRates[iJ]);
                    strcat(pxGetParamVal[i].Value, tmp);
            
                }
                else
                {
                    break;
                }
            }
            break;
        case OID_IGD_LAND_WLANC_OPERATIONALDATATRANSMITRATES:
            for (iJ = 0; iJ < IFX_MAPI_WLAN_MAX_DATA_RATES_NUM; iJ++)
            {
                if (wlCfg.main.operDataRates[iJ] != 0)
                {
                    memset(tmp, '\0', sizeof(tmp));
                    sprintf(tmp, "%.1f,",
                            wlCfg.main.operDataRates[iJ]);
                    strcat(pxGetParamVal[i].Value, tmp);
                }
                else
                {
                    break;
                }
            }
            break;

        case OID_IGD_LAND_WLANC_POSSIBLEDATATRANSMITRATES:
            for (iJ = 0; iJ < IFX_MAPI_WLAN_MAX_DATA_RATES_NUM; iJ++)
            {
                if (wlCfg.main.possblDataRates[iJ] != 0)
                {
                    memset(tmp, '\0', sizeof(tmp));
                    sprintf(tmp, "%.1f,",
                            wlCfg.main.possblDataRates[iJ]);
                    strcat(pxGetParamVal[i].Value, tmp);
                }
                else
                {
                    break;
                }
            }
            IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal + i, IFX_CHK_CHANGE_FLAG_BASED);
            break;
        case OID_IGD_LAND_WLANC_BEACONADVERTISEMENTENABLED:
            sprintf(pxGetParamVal[i].Value,"%d",wlCfg.phy.beaconTxEna);
	    break;
        case OID_IGD_LAND_WLANC_SSIDADVERTISEMENTENABLED:
            sprintf(pxGetParamVal[i].Value,"%d",!wlCfg.main.ssidMode);
            break;
        case OID_IGD_LAND_WLANC_RADIOENABLED:
            sprintf(pxGetParamVal[i].Value,"%d",wlCfg.phy.radioEnable);
            break;
        case OID_IGD_LAND_WLANC_TRANSMITPOWERSUPPORTED:
#if 0
            if(wlCfg.phy.iid.cpeId.Id == 1)
               wlan_capability = &ifx_mapi_get_wlan_capability;
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
            else
               wlan_capability = &ifx_mapi_get_wlan_sec_capability;
#endif //CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	    if(wlan_capability!=NULL)
            {
                if ((iRet = wlan_capability(&wlCaps, IFX_F_DEFAULT)) != IFX_SUCCESS)
                {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"%s:%d! get wlan capability failed\n", _FUNCL_);
                    goto errorHandler;
                }
                else
                {
                    strcpy(pxGetParamVal[i].Value,"");
                    do
                    {
                        sprintf(tmp,"%d",wlCaps.powerLevelsSupported[ti]);
                        if(((char*)pxGetParamVal[i].Value)[0]!='\0')
			    strcat(pxGetParamVal[i].Value,",");

                        strcat(pxGetParamVal[i].Value,tmp);
                        ti++;
                    }while( (ti < IFX_MAPI_WLAN_MAX_STD) && (wlCaps.powerLevelsSupported[ti] != 0xFF)) ;
	        }
	    }
            else
            {
                ((char8 *)pxGetParamVal[i].Value)[0] = '\0';
	    }
#endif
            strcpy(pxGetParamVal[i].Value,"12,25,50,100,1027,207,215,108");
            break;
        case OID_IGD_LAND_WLANC_TRANSMITPOWER:
	    sprintf(pxGetParamVal[i].Value,"%d",wlCfg.phy.powerLvl);
            break;
        case OID_IGD_LAND_WLANC_AUTORATEFALLBACKENABLED:
            sprintf(pxGetParamVal[i].Value,"%d",wlCfg.phy.autoRateFallBackEna);
            break;
        case OID_IGD_LAND_WLANC_WMMSUPPORTED:
            strcpy(pxGetParamVal[i].Value,"1"); 
            break;
        case OID_IGD_LAND_WLANC_UAPSDSUPPORTED:
            strcpy(pxGetParamVal[i].Value,"1"); 
            break;
        case OID_IGD_LAND_WLANC_WMMENABLE:
            sprintf(pxGetParamVal[i].Value,"%d",wlCfg.main.WMMena);
            break;
        case OID_IGD_LAND_WLANC_UAPSDENABLE:
            sprintf(pxGetParamVal[i].Value,"%d",wlCfg.main.UAPSDena);
            break;
        case OID_IGD_LAND_WLANC_TOTALBYTESSENT:
            sprintf(pxGetParamVal[i].Value, "%u", wlStats.bytesTx);
            IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal + i, IFX_CHK_CHANGE_FLAG_BASED);
            break;

        case OID_IGD_LAND_WLANC_TOTALBYTESRECEIVED:
            sprintf(pxGetParamVal[i].Value, "%u",wlStats.bytesRx);
            IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal + i , IFX_CHK_CHANGE_FLAG_BASED);
            break;

        case OID_IGD_LAND_WLANC_TOTALPACKETSSENT:
            sprintf(pxGetParamVal[i].Value, "%u",wlStats.pktsTx);
            IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal+i , IFX_CHK_CHANGE_FLAG_BASED);
            break;

        case OID_IGD_LAND_WLANC_TOTALPACKETSRECEIVED:
            sprintf(pxGetParamVal[i].Value, "%u",wlStats.pktsRx);
            IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal+ i , IFX_CHK_CHANGE_FLAG_BASED);
            break;

        case OID_IGD_LAND_WLANC_TOTALASSOCIATIONS:
            if(ifx_mapi_get_all_wlan_assoc_devices(iCpeid,(uint32 *)&numAssoc,&assoDev,IFX_F_DEFAULT)== IFX_CWMP_SUCCESS) {
                sprintf(pxGetParamVal[i].Value, "%u", numAssoc);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal+i, IFX_CHK_CHANGE_FLAG_BASED);
            }
        case OID_IGD_LAND_WLANC_TOTALPSKFAILURES:
            strcpy(pxGetParamVal[i].Value,"1");
            break;
        case OID_IGD_LAND_WLANC_TOTALINTEGRITYFAILURES:
            strcpy(pxGetParamVal[i].Value,"0");
            break;
        case OID_IGD_LAND_WLANC_CHANNELSINUSE:
#ifdef CONFIG_FEATURE_IFX_WIRELESS_WAVE300
            system("cat /proc/net/mtlk/wlan0/aocs_channels > /tmp/acos_channels");

            fptr1 = fopen("/tmp/acos_channels","r+");
            if(fptr1 != NULL)
            {
                while(fgets(line,sizeof(line),fptr1)!=NULL)
                {
                    line_no++;
                    lptr=NULL;
                    if(line_no>2)
                    {
                        lptr=strtok(line," ");
                        strcpy(chan,lptr);
                        lptr=strtok(NULL," ");
                        bss=atoi(lptr);
                        if(bss > 0)
                        {
                            if(line_no==3)
                                sprintf(channels,chan);
                            else
                                sprintf(channels,"%s,%s",channels,chan);
                        }
                    }
                }
                fclose(fptr1);
            }
            strcpy(pxGetParamVal[i].Value,channels);
#else
            strcpy(pxGetParamVal[i].Value,"1-11");
#endif
            break;
        case OID_IGD_LAND_WLANC_DEVICEOPERATIONMODE:
            strcpy(pxGetParamVal[i].Value,"InfrastructureAccessPoint");
            break;
        default:
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d Invalid param id %d!\n", _FUNCL_, iParamId);
            pxGetParamVal->iFaultCode = ERR_INVAL_PARAMETER_VAL;
            break;
        }
    }

    IFX_CWMP_FREE(assoDev);
	LTQ_LOG_TIMESTAMP("Done");

    return IFX_CWMP_SUCCESS;

errorHandler:
    IFX_CWMP_FREE(assoDev);
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed ParamId=%d !\n", _FUNCL_, iParamId);
    return IFIN_CWMP_FAILURE;
}

/*
** =============================================================================
**   Function Name    : IFX_WlanConfSetValidate
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/
static int32
IFX_WlanConfSetValidate(IN OperInfo * pxOpInfo, INOUT ParamVal * paxTempParamVal,
                        IN int32 iElements)
{

    uint32 iCpeid = 0, i = 0, j, iJ, done;
    uint32 uiParamPos = 0, uiChannelIdMatch=0, uiCpeid;
    int32 iRet = IFX_CWMP_SUCCESS;
    char tmp[128]={0}, *tok=NULL;
    uint32 match=0;

    IFX_MAPI_WLAN_ChannelList wlan_ChannelList;
    IFX_MAPI_WLAN_MainCfg wlMain;

    memset(&wlan_ChannelList, 0x00, sizeof(wlan_ChannelList));
    memset(&wlMain, 0x00, sizeof(IFX_MAPI_WLAN_MainCfg));

    // Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(paxTempParamVal->iaOID, &uiCpeid);
    if (iRet != IFIN_CWMP_SUCCESS)
        goto errorHandler;

    wlMain.iid.cpeId.Id = uiCpeid;
           strcpy(wlMain.iid.cpeId.secName , "wlan_main");
    wlMain.iid.pcpeId.Id = 1;
    strcpy(wlMain.iid.cpeId.secName , "land");    
    iRet = ifx_mapi_get_wlan_main_config(&wlMain,IFX_F_DEFAULT);
    if (iRet != IFIN_CWMP_SUCCESS)
        goto errorHandler;
    // Get the WlanConfParamPos
    uiParamPos = IFX_GetParamIdPos(paxTempParamVal->iaOID);

    for (i = 0; i < iElements; i++)
    {

        switch (paxTempParamVal[i].iaOID[uiParamPos])
        {
#if 0
	case OID_IGD_LAND_WLANC_ENABLE:
	    if(uiCpeid==1) { // cannot set enable on AP
		 paxTempParamVal[i].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
		 iRet = ERR_CWMP_INVAL_PARAM_VAL;
		  goto errorHandler;
	    }
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	    if(uiCpeid==2) { // cannot set enable on AP
		 paxTempParamVal[i].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
		 iRet = ERR_CWMP_INVAL_PARAM_VAL;
		  goto errorHandler;
	    }
#endif
	  break;
#endif 
        case OID_IGD_LAND_WLANC_CHANNEL:
            if (ifx_mapi_get_wlan_channel_list(iCpeid,&wlan_ChannelList,IFX_F_DEFAULT) ==
                    IFX_CWMP_SUCCESS)
            {
                for (iJ = 0; iJ < IFX_MAPI_WLAN_MAX_PHY_CHANNELS; iJ++)
                {
                    if (wlan_ChannelList.chanNumList[iJ] != 0)
                    {
                        if (wlan_ChannelList.chanNumList[iJ] ==
                                atoi(paxTempParamVal[i].Value))
                        {
                            uiChannelIdMatch = 1;
                            break;
                        }
                    }
                }
			}
			if(uiChannelIdMatch!=1)
			{
                                paxTempParamVal[i].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                                iRet = ERR_CWMP_INVAL_PARAM_VAL;
                                goto errorHandler;
                        }

	      break;

        case OID_IGD_LAND_WLANC_WEPKEYINDEX:
            if (strstr("1234", (char8 *) paxTempParamVal[i].Value) == NULL)
            {
                paxTempParamVal[i].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                iRet = ERR_CWMP_INVAL_PARAM_VAL;
                goto errorHandler;
            }
            break;
        case OID_IGD_LAND_WLANC_BASICENCRYPTIONMODES:
            if (strncmp(paxTempParamVal[i].Value,"None",4) &&
                    strncmp(paxTempParamVal[i].Value,"WEPEncryption",13))
            {
                paxTempParamVal[i].iFaultCode =
                    ERR_CWMP_INVAL_PARAM_VAL;
                iRet = ERR_CWMP_INVAL_PARAM_VAL;
                goto errorHandler;
            }
            break;
        case OID_IGD_LAND_WLANC_BASICAUTHENTICATIONMODE:
            if (strncmp(paxTempParamVal[i].Value,"None",4) &&
                    strncmp(paxTempParamVal[i].Value,"SharedAuthentication",20) && strncmp(paxTempParamVal[i].Value,"EAPAuthentication", 17))
            {
                paxTempParamVal[i].iFaultCode =
                    ERR_CWMP_INVAL_PARAM_VAL;
                iRet = ERR_CWMP_INVAL_PARAM_VAL;
                goto errorHandler;
            }
            break;
        case OID_IGD_LAND_WLANC_WPAENCRYPTIONMODES:
            if (strncmp(paxTempParamVal[i].Value,"WEPEncryption",13) &&
                    strncmp(paxTempParamVal[i].Value,"TKIPEncryption",14) &&
                    strncmp(paxTempParamVal[i].Value,"AESEncryption",13) &&
                    strncmp(paxTempParamVal[i].Value,"TKIPandAESEncryption",20))
            {
                paxTempParamVal[i].iFaultCode =
                    ERR_CWMP_INVAL_PARAM_VAL;
                iRet = ERR_CWMP_INVAL_PARAM_VAL;
                goto errorHandler;
            }
            break;

        case OID_IGD_LAND_WLANC_WPAAUTHENTICATIONMODE:
            if (strncmp(paxTempParamVal[i].Value,"PSKAuthentication",17) &&
                    strncmp(paxTempParamVal[i].Value,"EAPAuthentication",17))
            {
                paxTempParamVal[i].iFaultCode =
                    ERR_CWMP_INVAL_PARAM_VAL;
                iRet = ERR_CWMP_INVAL_PARAM_VAL;
                goto errorHandler;
            }
            break;
        case OID_IGD_LAND_WLANC_IEEE11IENCRYPTIONMODES:
            if (strncmp(paxTempParamVal[i].Value,"WEPEncryption",13) &&
                                strncmp(paxTempParamVal[i].Value,"TKIPEncryption",14) &&
                                strncmp(paxTempParamVal[i].Value,"AESEncryption",13) &&
                                strncmp(paxTempParamVal[i].Value,"TKIPandAESEncryption",20))
                        {
                                paxTempParamVal[i].iFaultCode =
                                    ERR_CWMP_INVAL_PARAM_VAL;
                                iRet = ERR_CWMP_INVAL_PARAM_VAL;
                                goto errorHandler;
                        }
                        break;
        case OID_IGD_LAND_WLANC_IEEE11IAUTHENTICATIONMODE:
                        if (strncmp(paxTempParamVal[i].Value,"PSKAuthentication",17) &&
                                strncmp(paxTempParamVal[i].Value,"EAPAuthentication",17))
            {
                                paxTempParamVal[i].iFaultCode =
                                    ERR_CWMP_INVAL_PARAM_VAL;
                                iRet = ERR_CWMP_INVAL_PARAM_VAL;
                                goto errorHandler;
                        }
                        break;
            /* MaxBitrate should be one of the members of OperationalDataRate
             OperationalDataRates should contain all BasicDataRates */
        case OID_IGD_LAND_WLANC_MAXBITRATE:
            done =0;
            for (j=0;j<IFX_MAPI_WLAN_MAX_DATA_RATES_NUM;j++)
            {
                if (wlMain.operDataRates[j]==atof(paxTempParamVal[i].Value))
                    done = 1;
            }
            if (done == 0)
            {
                paxTempParamVal[i].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                iRet = ERR_CWMP_INVAL_PARAM_VAL;
                goto errorHandler;
            }
            break;
        case OID_IGD_LAND_WLANC_BASICDATATRANSMITRATES:
            if (paxTempParamVal[i].Value!=NULL)
            {
                strcpy(tmp, paxTempParamVal[i].Value);
                tok = strtok(tmp,", ");
                while (1)
                {
                    match=0;
                    if (tok==NULL)
                        break;
                    for (j=0;j<IFX_MAPI_WLAN_MAX_DATA_RATES_NUM;j++)
                    {
                        if (wlMain.basicDataRates[j] == atof(tok))
                        {
                            match =1;
                        }
                        
                    }
                        if(match == 0)
                        {
                            paxTempParamVal[i].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                            iRet = ERR_CWMP_INVAL_PARAM_VAL;
                            goto errorHandler;

                        }
                        tok = strtok(NULL,", ");
                }
            }
            break;
        default:
            break;
        }
    }

    return IFIN_CWMP_SUCCESS;
errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d, Paramid=%d Value=%s failed!\n", _FUNCL_,
                paxTempParamVal[i].iaOID[uiParamPos],
                (char8 *) paxTempParamVal->Value);
    return iRet;

}

/*
** =============================================================================
**   Function Name    : IFX_WlanConfSetValue
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/
static int32
IFX_WlanConfSetValue(IN OperInfo * pxOpInfo, INOUT ParamVal * paxParamVal,
                     IN int32 iElements)
{

    uint32 i=0, j;
    uint32 uiCpeid = 0, iOper=0;
    int32 iRet = IFX_CWMP_SUCCESS;
    uint32 uiParamPos = 0;
    char tmp[128]={0}, *tok=NULL, passPhrase[128]={0};
    uint32 iFlags= IFX_F_MODIFY ; //,oldstat;
    uint32 uiWepKeyIndx = 0;
    uint32 done = 0, ti =0;
    int (*wlan_capability)(IFX_MAPI_WLAN_Capability *,uint32) = NULL;

    uint32 f_mainCfg=0, f_phyCfg=0, f_secCfg=0;

    IFX_MAPI_WLAN_AP_Cfg wlCfg;
    IFX_MAPI_WLAN_Capability   wlCaps;

	LTQ_LOG_TIMESTAMP("Begin");
    memset(&wlCfg,0x00, sizeof(IFX_MAPI_WLAN_AP_Cfg));

    // Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(paxParamVal->iaOID, &uiCpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Get the object from system
    wlCfg.iid.cpeId.Id = uiCpeid;
    wlCfg.iid.pcpeId.Id = 1;
    
    // Get match object from system using MAPI
    iRet = ifx_mapi_get_wlan_ap_config(&wlCfg, IFX_F_GET_ANY);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Get the WlanConfParamPos
    uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);
        if((wlCfg.sec.beaconType == IFX_MAPI_WLAN_BEACON_BASIC) && (wlCfg.sec.wlEncr == IFX_MAPI_WLAN_ENCR_WEP))
             uiWepKeyIndx = wlCfg.sec.secParams.wepCfg.wepKeyIndex;

    switch (pxOpInfo->iSubOper)
    {

    case OP_SETVAL_CHK_MODIFY_DEP:
        break;

    case OP_SETVAL_ACTIVATE:
    case OP_SETVAL_MODIFY:
        iOper = IFX_OP_MOD;
        for (i=0;i<iElements;i++)
        {
            switch (paxParamVal[i].iaOID[uiParamPos])
            {
            case OID_IGD_LAND_WLANC_ENABLE:
//                oldstat = wlCfg.main.apEnable;
                if (!strcmp(paxParamVal[i].Value,"1") || !strncasecmp(paxParamVal[i].Value,"true",4))
                    wlCfg.main.apEnable = 1;
                else
                    wlCfg.main.apEnable = 0;
		f_mainCfg=1;
                break;
            case OID_IGD_LAND_WLANC_MAXBITRATE:
		if(!strcmp(paxParamVal[i].Value,"Auto")) 
			wlCfg.main.maxBitRate = 0.0;
		else
                	wlCfg.main.maxBitRate = atof(paxParamVal[i].Value);
		f_mainCfg=1;
                break;
            case OID_IGD_LAND_WLANC_CHANNEL:
                wlCfg.phy.channelNo = atoi(paxParamVal[i].Value);
                f_phyCfg=1;
                break;
            case OID_IGD_LAND_WLANC_AUTOCHANNELENABLE:
                if (!strcmp(paxParamVal[i].Value,"1") || !strncasecmp(paxParamVal[i].Value,"true",4))
                    wlCfg.phy.autoChannelEna = 1;
                else
                    wlCfg.phy.autoChannelEna = 0;
                f_phyCfg=1;
                break;
            case OID_IGD_LAND_WLANC_SSID:
                   strncpy(wlCfg.main.ssid,paxParamVal[i].Value,IFX_MAPI_WLAN_SSID_LEN);               
		f_mainCfg=1;
                break;
            case OID_IGD_LAND_WLANC_BEACONTYPE:
                            if (!strcmp(paxParamVal[i].Value,"Basic")) {
                                    wlCfg.sec.beaconType=IFX_MAPI_WLAN_BEACON_BASIC;
                    		    wlCfg.sec.wlEncr = IFX_MAPI_WLAN_ENCR_WEP;
                    		    wlCfg.sec.wlAuth = IFX_MAPI_WLAN_AUTH_OPEN;
			    }
                            else if (!strcmp(paxParamVal[i].Value,"None")) {
                                    wlCfg.sec.beaconType=IFX_MAPI_WLAN_BEACON_NONE;
                    		    wlCfg.sec.wlEncr = IFX_MAPI_WLAN_ENCR_NONE;
                    		    wlCfg.sec.wlAuth = IFX_MAPI_WLAN_AUTH_OPEN;
			    }
                            else if (!strcmp(paxParamVal[i].Value,"WPA")) {
                    		wlCfg.sec.beaconType=IFX_MAPI_WLAN_BEACON_WPA;
                		wlCfg.sec.wlAuth = IFX_MAPI_WLAN_AUTH_PERSONAL;
                    		wlCfg.sec.wlEncr = IFX_MAPI_WLAN_ENCR_TKIP;
			    }
                            else if (!strcmp(paxParamVal[i].Value,"11i")) {
		                wlCfg.sec.beaconType=IFX_MAPI_WLAN_BEACON_WPA2;
    		                wlCfg.sec.wlAuth = IFX_MAPI_WLAN_AUTH_PERSONAL;
                    		wlCfg.sec.wlEncr = IFX_MAPI_WLAN_ENCR_CCMP;
			    }
                            else if (!strcmp(paxParamVal[i].Value,"WPAand11i"))
                    	    {	
				wlCfg.sec.beaconType=IFX_MAPI_WLAN_BEACON_WPA_WPA2;
                    		wlCfg.sec.wlAuth = IFX_MAPI_WLAN_AUTH_PERSONAL;
                    		wlCfg.sec.wlEncr = IFX_MAPI_WLAN_ENCR_CCMP;
			    }
		f_secCfg=1;	
                break;
	    case OID_IGD_LAND_WLANC_MACADDRESSCONTROLENABLED:
		if (!strcmp(paxParamVal[i].Value,"1") || !strncasecmp(paxParamVal[i].Value,"true",4)) 
        		wlCfg.sec.macAddrCntrlEna = LTQ_WLAN_MACADDRESS_ALLOW;
        	else
			wlCfg.sec.macAddrCntrlEna = LTQ_WLAN_MCADDDRESS_DISABLE;
		f_secCfg=1;	
        	break;
            case OID_IGD_LAND_WLANC_WEPKEYINDEX:
		uiWepKeyIndx = (atoi(paxParamVal[i].Value)) - 1;
		f_secCfg=1;	
                break;
            case OID_IGD_LAND_WLANC_KEYPASSPHRASE: //dont set
                strncpy(passPhrase,paxParamVal[i].Value,IFX_MAPI_PASSPHRASE_MAX_LEN);
		f_secCfg=1;	
		break;
            case OID_IGD_LAND_WLANC_BASICENCRYPTIONMODES:
                if (!strcmp(paxParamVal[i].Value,"None"))
                    wlCfg.sec.wlEncr = IFX_MAPI_WLAN_ENCR_NONE;
                else if (!strcmp(paxParamVal[i].Value,"WEPEncryption"))
                    wlCfg.sec.wlEncr = IFX_MAPI_WLAN_ENCR_WEP;
		f_secCfg=1;	
                break;
            case OID_IGD_LAND_WLANC_BASICAUTHENTICATIONMODE:
                if (!strcmp(paxParamVal[i].Value,"None"))
                    wlCfg.sec.wlAuth = IFX_MAPI_WLAN_AUTH_OPEN;
                else if (!strcmp(paxParamVal[i].Value,"SharedAuthentication"))
                    wlCfg.sec.wlAuth = IFX_MAPI_WLAN_AUTH_SHARED;
		else if (!strcmp(paxParamVal[i].Value,"EAPAuthentication"))
                    wlCfg.sec.wlAuth = IFX_MAPI_WLAN_AUTH_PERSONAL;
		f_secCfg=1;	
                break;
            case OID_IGD_LAND_WLANC_WPAENCRYPTIONMODES:
                if (!strcmp(paxParamVal[i].Value,"WEPEncryption"))        
                    wlCfg.sec.wlEncr = IFX_MAPI_WLAN_ENCR_WEP;
                else if (!strcmp(paxParamVal[i].Value,"TKIPEncryption"))
                    wlCfg.sec.wlEncr = IFX_MAPI_WLAN_ENCR_TKIP;
                else if (!strcmp(paxParamVal[i].Value,"AESEncryption"))
                    wlCfg.sec.wlEncr = IFX_MAPI_WLAN_ENCR_CCMP;
                else if (!strcmp(paxParamVal[i].Value,"TKIPandAESEncryption"))
                    wlCfg.sec.wlEncr = IFX_MAPI_WLAN_ENCR_TKIP_CCMP;
		f_secCfg=1;	
                break;
            case OID_IGD_LAND_WLANC_WPAAUTHENTICATIONMODE:
                if (!strcmp(paxParamVal[i].Value,"PSKAuthentication")) 
                    wlCfg.sec.wlAuth = IFX_MAPI_WLAN_AUTH_PERSONAL;
                if (!strcmp(paxParamVal[i].Value,"EAPAuthentication" ))
                    wlCfg.sec.wlAuth = IFX_MAPI_WLAN_AUTH_RADIUS;
		f_secCfg=1;	
                break;
            case OID_IGD_LAND_WLANC_IEEE11IENCRYPTIONMODES:
                if (!strcmp(paxParamVal[i].Value,"WEPEncryption"))
                	wlCfg.sec.wlEncr = IFX_MAPI_WLAN_ENCR_WEP;
                else if (!strcmp(paxParamVal[i].Value,"TKIPEncryption"))
                        wlCfg.sec.wlEncr = IFX_MAPI_WLAN_ENCR_TKIP;
                else if (!strcmp(paxParamVal[i].Value,"AESEncryption"))
                        wlCfg.sec.wlEncr = IFX_MAPI_WLAN_ENCR_CCMP;
                else if (!strcmp(paxParamVal[i].Value,"TKIPandAESEncryption"))
                        wlCfg.sec.wlEncr = IFX_MAPI_WLAN_ENCR_TKIP_CCMP;
		f_secCfg=1;	
                break;
            case OID_IGD_LAND_WLANC_IEEE11IAUTHENTICATIONMODE:
                if (!strcmp(paxParamVal[i].Value,"PSKAuthentication"))
                    wlCfg.sec.wlAuth = IFX_MAPI_WLAN_AUTH_PERSONAL;
                if (!strcmp(paxParamVal[i].Value,"EAPAuthentication" ))
                     wlCfg.sec.wlAuth = IFX_MAPI_WLAN_AUTH_RADIUS;
		f_secCfg=1;	
                break;    
            case OID_IGD_LAND_WLANC_BASICDATATRANSMITRATES:
                if (paxParamVal[i].Value!=NULL)
                {
                    strcpy(tmp,paxParamVal[i].Value);
                    tok = strtok(tmp,", ");
                    for (j=0;j<IFX_MAPI_WLAN_MAX_DATA_RATES_NUM;j++)
                    {
                        if (tok==NULL)
                            break;
                        wlCfg.main.basicDataRates[j] = atof(tok);
                        tok = strtok(NULL,", ");
                    }
		    f_mainCfg=1;
                }
                break;
            case OID_IGD_LAND_WLANC_OPERATIONALDATATRANSMITRATES:
                if (paxParamVal[i].Value!=NULL)
                {
                    strcpy(tmp,paxParamVal[i].Value);
                    tok = strtok(tmp,", ");
                    for (j=0;j<IFX_MAPI_WLAN_MAX_DATA_RATES_NUM;j++)
                    {
                        if (tok==NULL)
                            break;
                        wlCfg.main.operDataRates[j] = atof(tok);
                        tok = strtok(NULL,", ");
                    }
		    f_mainCfg=1;
                }
                break;
            case OID_IGD_LAND_WLANC_BEACONADVERTISEMENTENABLED:
                if (!strcmp(paxParamVal[i].Value,"1") || !strncasecmp(paxParamVal[i].Value,"true",4))
				                    wlCfg.phy.beaconTxEna = 1;
		    	                else 
                    wlCfg.phy.beaconTxEna = 0;
				    f_phyCfg=1;	
				
                break;
            case OID_IGD_LAND_WLANC_SSIDADVERTISEMENTENABLED:
                if (!strcmp(paxParamVal[i].Value,"1") || !strncasecmp(paxParamVal[i].Value,"true",4))
                    wlCfg.main.ssidMode = 0;
                else
                    wlCfg.main.ssidMode = 1;
		f_mainCfg=1;
                break;
            case OID_IGD_LAND_WLANC_RADIOENABLED:
                if (!strcmp(paxParamVal[i].Value,"1") || !strncasecmp(paxParamVal[i].Value,"true",4))
                    wlCfg.phy.radioEnable = 1;
                else
                    wlCfg.phy.radioEnable = 0;
		f_phyCfg=1;	
                break;
	    case OID_IGD_LAND_WLANC_TRANSMITPOWER:
		wlCfg.phy.powerLvl = atoi(paxParamVal[i].Value);

		if(wlCfg.phy.iid.cpeId.Id == 1)
		    wlan_capability = &ifx_mapi_get_wlan_capability;
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
		else
 		    wlan_capability = &ifx_mapi_get_wlan_sec_capability;
#endif //CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
		if(wlan_capability !=NULL)
                {
        	    if ((iRet = wlan_capability(&wlCaps, IFX_F_DEFAULT)) != IFX_SUCCESS)
         	    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d wlan_capability() failed !\n", _FUNCL_);
		        goto errorHandler;
                    }
                    else
                    {
		        do
                        {
		            if (wlCfg.phy.powerLvl == wlCaps.powerLevelsSupported[ti])
		            {
                                done = 1; 
                                break;
                            }
                            ti++;
                        } while( (ti < IFX_MAPI_WLAN_MAX_STD) && (wlCaps.powerLevelsSupported[ti] != 0xFF)) ;
                        if(!done)
                        {		
                            paxParamVal[i].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                            iRet = ERR_CWMP_INVAL_PARAM_VAL;
                            goto errorHandler;
                        }
                    }
		f_phyCfg=1;	
                }
		break;
            case OID_IGD_LAND_WLANC_AUTORATEFALLBACKENABLED:
                if (!strcmp(paxParamVal[i].Value,"1") || !strncasecmp(paxParamVal[i].Value,"true",4))
                    wlCfg.phy.autoRateFallBackEna = 1;
                else
                    wlCfg.phy.autoRateFallBackEna = 0;
		f_phyCfg=1;	
                break;
             case OID_IGD_LAND_WLANC_WMMENABLE:
                if (!strcmp(paxParamVal[i].Value,"1") || !strncasecmp(paxParamVal[i].Value,"true",4))
                    wlCfg.main.WMMena = 1;
                else
                    wlCfg.main.WMMena = 0;
		f_mainCfg=1; 
                break;
             case OID_IGD_LAND_WLANC_UAPSDENABLE:
               if (!strcmp(paxParamVal[i].Value,"1") || !strncasecmp(paxParamVal[i].Value,"true",4))
                    wlCfg.main.UAPSDena = 1;
                else
                    wlCfg.main.UAPSDena = 0;
		f_mainCfg=1; 
                break;
	     case OID_IGD_LAND_WLANC_DEVICEOPERATIONMODE:
		break;	
            default:
                break;
            }
        }

        break;

    default:
        break;

    }
    if(iOper==IFX_OP_MOD) {
	/* If the latest BeconType=11i and IEEE11iAuthenticationMode = EAPAuthentication
           Read the radius config values and copy to the struct so that we retain
	   the 802.1x values configured through web*/

   /* BASIC Authentication */
   if ( wlCfg.sec.beaconType == IFX_MAPI_WLAN_BEACON_BASIC)
   {
      if ( wlCfg.sec.wlEncr == IFX_MAPI_WLAN_ENCR_WEP)
   {
      for (i = 0; i < IFX_MAPI_NUM_WEP_KEYS; i++)
          wlCfg.sec.secParams.wepCfg.wepKey[i].iid.pcpeId.Id =  wlCfg.sec.iid.cpeId.Id;

		if(ifx_mapi_get_wlan_wep_config(&wlCfg.sec.secParams.wepCfg, IFX_F_DEFAULT) != IFX_SUCCESS)
      		{
			goto errorHandler;
		}
      wlCfg.sec.secParams.wepCfg.wepKeyIndex = uiWepKeyIndx;
      }
   }
   /* WPA, WPA2 or mixed WPA_WPA2 */
   else if  (wlCfg.sec.wlAuth == IFX_MAPI_WLAN_AUTH_PERSONAL)
   {
       wlCfg.sec.secParams.personalCfg.psk.iid.pcpeId.Id =  wlCfg.sec.iid.cpeId.Id;
       if(ifx_mapi_get_wlan_personal_config(&wlCfg.sec.secParams.personalCfg, IFX_F_DEFAULT) != IFX_SUCCESS)
       {
          goto errorHandler;
       }
       if(strlen(passPhrase)!=0) {
	  wlCfg.sec.secParams.personalCfg.pskType=IFX_MAPI_WLAN_ASCII_KEY;
          strncpy(wlCfg.sec.secParams.personalCfg.psk.passPhrase, passPhrase, IFX_MAPI_PASSPHRASE_MAX_LEN);
	  strcpy(wlCfg.sec.secParams.personalCfg.psk.preSharedKey,"");
       }
   }  
    /* IFX_MAPI_WLAN_AUTH_RADIUS */
   else if (wlCfg.sec.wlAuth == IFX_MAPI_WLAN_AUTH_RADIUS)
   {
       wlCfg.sec.secParams.wlRadius.iid.pcpeId.Id = wlCfg.sec.iid.cpeId.Id;
       if ((iRet = ifx_mapi_get_wlan_802_1x_config(&wlCfg.sec.secParams.wlRadius, IFX_F_DEFAULT)) != IFX_SUCCESS)
       {
  	  goto errorHandler;
       }
   }

	if(f_mainCfg & !f_phyCfg & !f_secCfg) {
		wlCfg.main.iid.config_owner = pxOpInfo->iCaller;
		iRet = ifx_mapi_set_wlan_main_config(iOper,&wlCfg.main,iFlags);
	} else if ((!f_mainCfg) & (f_phyCfg) & (!f_secCfg)) {
		wlCfg.phy.iid.config_owner = pxOpInfo->iCaller;
                iRet = ifx_mapi_set_wlan_phy_config(iOper,&wlCfg.phy,iFlags);
	} else if (!f_mainCfg & !f_phyCfg & f_secCfg) {
		wlCfg.sec.iid.config_owner = pxOpInfo->iCaller;
              iRet = ifx_mapi_set_wlan_security_config(iOper,&wlCfg.sec,iFlags);
	} else {       
		wlCfg.iid.config_owner = pxOpInfo->iCaller;
        	iRet = ifx_mapi_set_wlan_ap_config(iOper, &wlCfg, iFlags);
	}
        if (iRet != IFX_CWMP_SUCCESS)
        	goto errorHandler;
	
    }
	LTQ_LOG_TIMESTAMP("Done");

    return IFIN_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed!\n", _FUNCL_);
	LTQ_LOG_TIMESTAMP("Done");
    return iRet;

}


/*
** =============================================================================
**   Function Name    : IFX_WlanConfSetAttr
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/

int32
IFX_WlanConfSetAttr(IN OperInfo * pxOpInfo, INOUT ParamVal * pxParamVal,
                    IN int32 iElements)
{
    int32 iRet = 0;

    iRet = IFX_SetAttributesInfo(pxOpInfo, pxParamVal, iElements);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    return IFX_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed!\n", _FUNCL_);
    return iRet;

}


/*
** =============================================================================
**   Function Name    : IFX_WanDslLinkConfig_Init
**   Description      :
**   Parameters       :
**   Return Value     :
**   Notes            :
** ============================================================================
*/
int32
IFX_WlanConfiguration_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the WanDslLinkConfig module function pointer in the object
       model */
    iRet = ifx_ds_register_function(IFX_WLAN_CONF_OBJ, IFX_WlanConfiguration);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "Unable to Register %s with Object Model\n",
                    IFX_WLAN_CONF_OBJ);
        goto errorHandler;
    }

errorHandler:
    return iRet;
}


/*********************************************************************************
*  Function Name :  IFX_WlanConfiguration
*  Description     :  This function handles all the sub-states inside
                      a GET/SET operation.If it is a GET it allocates the
                array(Name,Value pairs) and retruns the values.
               If it is a SET controller allocates the array and
               passes the values to this function.It calls
               respective internal functions which in turn calls
               respective Platform APIs.
*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation, Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has Name,Value,etc
                    IN          int32           iElements;    No. of Elements
                    OUT            void *           ppParamRet;   same as ParamStruc
                    OUT         int32 *        piNumRetElem; No. of elements
*  Return Value  : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes         :
***********************************************************************************/
int32
IFX_WlanConfiguration(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                      IN int32 iElements, OUT void **ppaxParamArrRet,
                      OUT int32 * piNumRetElem)
{
    int32 iRet = 0;
    ParamVal *paxParamArr = (ParamVal *) paxParameterArr;
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d SubOper=%d '%s' Elem=%d\n",
                _FUNCL_, pxOperInfo->iSubOper, (char8 *) paxParamArr[0].Name,
                iElements);

    LTQ_LOG_TIMESTAMP("Begin");

    switch (pxOperInfo->iOper)
    {
        // Get the object values
    case OP_GETVAL:
    case OP_GETVAL_NORMAL:
        
        if ((iRet = IFX_WlanConfGetValue(pxOperInfo, paxParamArr,
                                         iElements)) != IFX_CWMP_SUCCESS)
        {

            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d OP_GETVAL failed!\n", _FUNCL_);
            goto errorHandler;
        }
        break;
    case OP_GETVAL_NOTIFICATION:
        break;
    case OP_SETVAL:
        // Set the obj values
        switch (pxOperInfo->iSubOper)
        {
        case OP_SETVAL_VALIDATE:

            if ((iRet =
                        IFX_WlanConfSetValidate(pxOperInfo, paxParamArr,
                                                iElements)) !=
                    IFX_CWMP_SUCCESS)
            {
/*
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_SET_VALIDATE failed!\n",
                            _FUNCL_);
                goto errorHandler;*/
            }

            break;
        case OP_SETVAL_CHK_MODIFY_DEP:
        case OP_SETVAL_MODIFY:
            if ((iRet = IFX_WlanConfSetValue(pxOperInfo, paxParamArr,
                                             iElements)) !=
                    IFX_CWMP_SUCCESS)
            {
                switch (pxOperInfo->iSubOper)
                {
                case OP_SETVAL_CHK_MODIFY_DEP:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d OP_SETVAL_CHK_MODIFY_DEP failed!\n",
                                _FUNCL_);
                    goto errorHandler;

                case OP_SETVAL_MODIFY:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d OP_SETVAL_MODIFY failed!\n",
                                _FUNCL_);
                    goto errorHandler;
                }
            }
            break;
        case OP_SETVAL_ADD:
        case OP_SETVAL_COMMIT:
        case OP_SETVAL_UNDO:
        case OP_SETVAL_CHK_DEL_DEP:
        case OP_SETVAL_CHK_DEL_ALLOWED:
        case OP_SETVAL_DELETE:
        case OP_SETVAL_FREE:
            break;

        case OP_SETVAL_ATTRINFO:
            if ((iRet = IFX_WlanConfSetAttr(pxOperInfo, paxParamArr,
                                            iElements)) !=
                    IFX_CWMP_SUCCESS)
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_SETVAL_ATTRINFO failed!\n",
                            _FUNCL_);
                goto errorHandler;
            }
            break;
        default:
            break;
        }
        break;

    case OP_UPDATE_CHILDINFO:
         break;
    case OP_PARAM_VALIDATE:
    {
        break; 
    }
    default:
        break;
    }
	LTQ_LOG_TIMESTAMP("Done");
    return iRet;
errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d WlanConfiguration returned Error!\n", _FUNCL_);
	LTQ_LOG_TIMESTAMP("Done");
    return iRet;
}

