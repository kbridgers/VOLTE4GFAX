
/*
** =============================================================================
** FILE NAME   : IFX_IPPingDiag.c
** PROJECT     : TR69
** MODULES     : (InternetGateway) Device.IPPingDiagnostics.
** DATE        : 10-Jul-2006
** AUTHOR      : TR69 team
** DESCRIPTION : AddObject / DeleteObject cannot be performed on this object.
**                   
** REFERENCES  :  
** COPYRIGHT   : Copyright (c) 2006
**               Infineon Technologies AG
**               Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY     : 
** $Date       $Author        $Comment
** 10-Jul-2006 TR69 team      Creation         
** =============================================================================
*/

#include "IFX_DEVM_Global.h"
 
#include "IFX_DEVM_AdaptCommon.h"
 
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_StackUtil.h"
#include <resolv.h>

extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char *obj, modFunc pifx_module_func);

#ifndef DEVICE_SUPPORT
#define IPPINGDIAG_OBJ                      FORMNAME("IPPingDiagnostics.")
#define IPPINGDIAG_DEPTH                    3
#endif // DEVICE_SUPPORT

#ifdef DEVICE_SUPPORT
#define IPPINGDIAG_OBJ                      FORMNAME("LAN.IPPingDiagnostics.")
#define IPPINGDIAG_DEPTH                    4
#define OID_IGD_IPPD_DIAGNOSTICSSTATE       OID_IGD_LAN_IPPD_DIAGNOSTICSSTATE
#define OID_IGD_IPPD_HOST                   OID_IGD_LAN_IPPD_HOST
#define OID_IGD_IPPD_NUMBEROFREPETITIONS    OID_IGD_LAN_IPPD_NUMBEROFREPETITIONS
#define OID_IGD_IPPD_TIMEOUT                OID_IGD_LAN_IPPD_TIMEOUT
#define OID_IGD_IPPD_DATABLOCKSIZE          OID_IGD_LAN_IPPD_DATABLOCKSIZE
#define OID_IGD_IPPD_DSCP                   OID_IGD_LAN_IPPD_DSCP
#define OID_IGD_IPPD_SUCCESSCOUNT           OID_IGD_LAN_IPPD_SUCCESSCOUNT
#define OID_IGD_IPPD_FAILURECOUNT           OID_IGD_LAN_IPPD_FAILURECOUNT
#define OID_IGD_IPPD_AVERAGERESPONSETIME    OID_IGD_LAN_IPPD_AVERAGERESPONSETIME
#define OID_IGD_IPPD_MINIMUMRESPONSETIME    OID_IGD_LAN_IPPD_MINIMUMRESPONSETIME
#define OID_IGD_IPPD_MAXIMUMRESPONSETIME    OID_IGD_LAN_IPPD_MAXIMUMRESPONSETIME
#endif // DEVICE_SUPPORT

#define MAX_NUM_LEN          12
#define LINESIZE             256

/*******************************************************************************
* Function: IFX_IPPingDiagSetAttrInfo
* Desc: Sets attribute information in the respective tr69 sections
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_IPPingDiagSetAttrInfo(IN int32 iCaller, INOUT ParamVal * pxPV,
                          IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    iRet = IFX_SetAttributesInfo(NULL, pxPV, iElements);

    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Updating Param Attribute Info failed\n",
                    _FUNCL_, iRet);
        goto errorHandler;
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_IPPingDiagGetNotifyValue
* Desc: 
*              
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_IPPingDiagGetNotifyValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                             IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    IPPING_DIAG xIPPing;
    char8 caTmp[12] = { 0 };

    memset(&xIPPing, '\0', sizeof(xIPPing));
    iRet = ifx_get_ipping_diag(&xIPPing, 0);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_ipping_diag() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
    for(iI = 0; iI < iElements; iI++) {
        pxPV[iI].Value = IFX_CWMP_MALLOC(257);
        if(pxPV[iI].Value == NULL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", _FUNCL_);
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (pxPV[iI].iaOID[IPPINGDIAG_DEPTH - 1]) {
            case OID_IGD_IPPD_DIAGNOSTICSSTATE:
                strcpy(pxPV[iI].Value, xIPPing.diag_state);
                break;
#ifndef DEVICE_SUPPORT
            case OID_IGD_IPPD_INTERFACE:
                strcpy(pxPV[iI].Value, xIPPing.interface);
                break;
#endif // DEVICE_SUPPORT
            case OID_IGD_IPPD_HOST:
                strcpy(pxPV[iI].Value, xIPPing.host);
                break;
            case OID_IGD_IPPD_NUMBEROFREPETITIONS:
                sprintf(caTmp, "%d", xIPPing.num_repeat);
                strcpy(pxPV[iI].Value, caTmp);
                break;
            case OID_IGD_IPPD_TIMEOUT:
                sprintf(caTmp, "%d", xIPPing.timeout);
                strcpy(pxPV[iI].Value, caTmp);
                break;
            case OID_IGD_IPPD_DATABLOCKSIZE:
                sprintf(caTmp, "%d", xIPPing.data_size);
                strcpy(pxPV[iI].Value, caTmp);
                break;
            case OID_IGD_IPPD_DSCP:
                sprintf(caTmp, "%d", xIPPing.dscp);
                strcpy(pxPV[iI].Value, caTmp);
                break;
            case OID_IGD_IPPD_SUCCESSCOUNT:
                sprintf(caTmp, "%d", xIPPing.success_cnt);
                strcpy(pxPV[iI].Value, caTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI,
                                         IFX_CHK_CHANGE_FLAG_BASED);
                break;
            case OID_IGD_IPPD_FAILURECOUNT:
                sprintf(caTmp, "%d", xIPPing.failure_cnt);
                strcpy(pxPV[iI].Value, caTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI,
                                         IFX_CHK_CHANGE_FLAG_BASED);
                break;
            case OID_IGD_IPPD_AVERAGERESPONSETIME:
                sprintf(caTmp, "%d", xIPPing.avg_resp_time);
                strcpy(pxPV[iI].Value, caTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI,
                                         IFX_CHK_CHANGE_FLAG_BASED);
                break;
            case OID_IGD_IPPD_MINIMUMRESPONSETIME:
                sprintf(caTmp, "%d", xIPPing.min_resp_time);
                strcpy(pxPV[iI].Value, caTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI,
                                         IFX_CHK_CHANGE_FLAG_BASED);
                break;
            case OID_IGD_IPPD_MAXIMUMRESPONSETIME:
                sprintf(caTmp, "%d", xIPPing.max_resp_time);
                strcpy(pxPV[iI].Value, caTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI,
                                         IFX_CHK_CHANGE_FLAG_BASED);
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", _FUNCL_,
                            pxPV[iI].iaOID[IPPINGDIAG_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_IPPingValidateInterface
* Desc: Validates the psInterface parameter passed. Is Successful, psIPAddr
*       will contain the IPAddress of the interface (Depending on being a 
*       WANDevice or LANDevice). psIPAddr should be allocated by the caller of
*       this function.
* Parameters: IN char8 * psInterface, OUT char8 * psIPAddr
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_IPPingValidateInterface(IN char8 * psInterface, OUT char8 * psIPAddr)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    char8 caTmp[64] = { 0 }, caInterface[MAX_IF_NAME] = { 0 };

    if(strstr(psInterface, "WANDevice")) {
        strcpy(caInterface, psInterface);
        if(caInterface[(strlen(caInterface) - 1)] != '.')
            strcat(caInterface, ".");
        strcat(caInterface, "ExternalIPAddress");
        iRet = ifx_config_get_value(caInterface, caTmp);
        if(iRet == IFX_CWMP_SUCCESS)
            strcpy(psIPAddr, caTmp);
        else {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d Get %s fail\n", _FUNCL_, caInterface);
            goto errorHandler;
        }
    }
    else if(strstr(psInterface, "LANDevice")) {
        strcpy(caInterface, psInterface);
        if(caInterface[(strlen(caInterface) - 1)] != '.')
            strcat(caInterface, ".");
        strcat(caInterface, "IPInterfaceIPAddress");
        iRet = ifx_config_get_value(caInterface, caTmp);
        if(iRet == IFX_CWMP_SUCCESS)
            strcpy(psIPAddr, caTmp);
        else {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d Get %s fail\n", _FUNCL_, caInterface);
            goto errorHandler;
        }
    }
    else {
        iRet = IFX_CWMP_FAILURE;
    }

  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_IPPingDiagValidate
* Desc:
*              
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_IPPingDiagValidate(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0, iTmp = 0;
#ifndef DEVICE_SUPPORT
    char8 sIPAddr[64] = { 0 };
#endif // DEVICE_SUPPORT

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[IPPINGDIAG_DEPTH - 1]) {
            case OID_IGD_IPPD_DIAGNOSTICSSTATE:
                break;
#ifndef DEVICE_SUPPORT
            case OID_IGD_IPPD_INTERFACE:
                iTmp = strlen(pxPV[iI].Value);
                if(iTmp > MAX_IF_NAME) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d Interface len %d > %d (max)\n", _FUNCL_,
                                iTmp, MAX_IF_NAME);
                    iRet = ERR_CWMP_INVAL_PARAM_VAL;
                    goto errorHandler;
                }
                if(iTmp == 0) {
                    /* A NULL interface value is a valid value, use the routing
                       table */
                }
                else {
                    iRet = IFX_IPPingValidateInterface(pxPV[iI].Value, sIPAddr);
                    if(iRet != IFX_CWMP_SUCCESS) {
                        iRet = ERR_CWMP_INVAL_ARGS;
                        pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        goto errorHandler;
                    }
                }

                break;
#endif // DEVICE_SUPPORT
            case OID_IGD_IPPD_HOST:
                iTmp = strlen(pxPV[iI].Value);
                if((iTmp > MAX_HOST_NAME) || (iTmp < 3)) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d Host len %d > %d (max)\n", _FUNCL_,
                                iTmp, MAX_HOST_NAME);
                    iRet = ERR_CWMP_INVAL_ARGS;
                    pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    goto errorHandler;
                }
                break;
            case OID_IGD_IPPD_NUMBEROFREPETITIONS:
                break;
            case OID_IGD_IPPD_TIMEOUT:
                break;
            case OID_IGD_IPPD_DATABLOCKSIZE:
                break;
            case OID_IGD_IPPD_DSCP:
                break;
            case OID_IGD_IPPD_SUCCESSCOUNT:
                break;
            case OID_IGD_IPPD_FAILURECOUNT:
                break;
            case OID_IGD_IPPD_AVERAGERESPONSETIME:
                break;
            case OID_IGD_IPPD_MINIMUMRESPONSETIME:
                break;
            case OID_IGD_IPPD_MAXIMUMRESPONSETIME:
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", _FUNCL_,
                            pxPV[iI].iaOID[IPPINGDIAG_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_IPPingDiagSetValue
* Desc:
*              
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_IPPingDiagSetValue(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0, iActivate = 0;
    IPPING_DIAG xIPPing;

    memset(&xIPPing, '\0', sizeof(xIPPing));
    iRet = ifx_get_ipping_diag(&xIPPing, 0);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_ipping_diag() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[IPPINGDIAG_DEPTH - 1]) {
            case OID_IGD_IPPD_DIAGNOSTICSSTATE:
                strcpy(xIPPing.diag_state, pxPV[iI].Value);
                if(strcmp(pxPV[iI].Value, "Requested") == 0)
                    iActivate = IFX_CWMP_NEED_ACTIVATE;
                break;
#ifndef DEVICE_SUPPORT
            case OID_IGD_IPPD_INTERFACE:
                strcpy(xIPPing.interface, pxPV[iI].Value);
                break;
#endif // DEVICE_SUPPORT
            case OID_IGD_IPPD_HOST:
                strcpy(xIPPing.host, pxPV[iI].Value);
                break;
            case OID_IGD_IPPD_NUMBEROFREPETITIONS:
                xIPPing.num_repeat = atoi(pxPV[iI].Value);
                break;
            case OID_IGD_IPPD_TIMEOUT:
                xIPPing.timeout = atoi(pxPV[iI].Value);
                break;
            case OID_IGD_IPPD_DATABLOCKSIZE:
                xIPPing.data_size = atoi(pxPV[iI].Value);
                break;
            case OID_IGD_IPPD_DSCP:
                xIPPing.dscp = atoi(pxPV[iI].Value);
                break;
            case OID_IGD_IPPD_SUCCESSCOUNT:
            case OID_IGD_IPPD_FAILURECOUNT:
            case OID_IGD_IPPD_AVERAGERESPONSETIME:
            case OID_IGD_IPPD_MINIMUMRESPONSETIME:
            case OID_IGD_IPPD_MAXIMUMRESPONSETIME:
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case '%s'\n", _FUNCL_,
                            pxPV[iI].iaOID[IPPINGDIAG_DEPTH - 1],
                            (char8 *) pxPV[iI].Value);
                break;
        }
    }

    /* Modifying any of the parameters in this obj except DiagnosticState MUST
       result in the value of DiagnosticState parameter being set to "None" */
    if(iActivate != IFX_CWMP_NEED_ACTIVATE)
        strcpy(xIPPing.diag_state, "None");
    iRet = ifx_set_ipping_diag(IFX_F_MODIFY, &xIPPing, 0);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_set_ipping_diag() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }

  errorHandler:
    if((iActivate == IFX_CWMP_NEED_ACTIVATE) && (iRet == IFX_CWMP_SUCCESS))
        iRet = IFX_CWMP_NEED_ACTIVATE;
    return iRet;
}

typedef struct {
    char8 caDiagState[MAX_DIAGSTATE_LEN];
    int32 iSuccessCount;
    int32 iFailureCount;
    int32 iAverageResponseTime;
    int32 iMinimumResponseTime;
    int32 iMaximumResponseTime;
} IPPingResp;

/*******************************************************************************
* Function: IFX_IPPingTest
* Desc: Do not modify the pxPingQuery.
*              
* Parameters: IPPING_DIAG * pxPingQuery, IPPingResp * pxPingResp
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int
IFX_IPPingTest(IPPING_DIAG * pxPingQuery, IPPingResp * pxPingResp)
{
    FILE *fp = NULL;
    char8 mirrorline[LINESIZE], *psString = NULL, caCommand[512] = { 0 };
    int32 min = 0, avg = 0, max = 0, successcount = 0, iRet = IFX_CWMP_FAILURE;
    char8 *ptok = NULL, caTmp[CWMP_MAX_OBJ_LEN] = { 0 };
    int32 iTmp = 0;
    struct hostent xHostEnt, *pxHE = NULL;

    memset(&xHostEnt, '\0', sizeof(xHostEnt));

    strcpy(caCommand, "ping");
    /* About to execute the commands. Put Error_Internal now. Overwrite it it
       ping test succeeds */
    strcpy(pxPingResp->caDiagState, "Error_Internal");

    if(strlen(pxPingQuery->interface) > 0) {
        iRet = IFX_IPPingValidateInterface(pxPingQuery->interface, caTmp);
        if(iRet == IFX_CWMP_SUCCESS) {
            /* append the interface switch */
            strcat(caCommand, " -I ");
            strcat(caCommand, caTmp);
        }
        else {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d Get %s fail\n", _FUNCL_, pxPingQuery->interface);
            goto errorHandler;
        }
    }

    /* append the number of repetitions switch */
    if((*pxPingQuery).num_repeat <= 0) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d Mandatary field num_repeat missing\n", _FUNCL_);
        strcpy(pxPingResp->caDiagState, "Error_Other");
        iRet = IFX_CWMP_FAILURE;
        goto errorHandler;
    }
    sprintf(caTmp, "%u", (*pxPingQuery).num_repeat);
    strcat(caCommand, " -c ");
    strcat(caCommand, caTmp);

    /* append the size switch. */
    if((*pxPingQuery).data_size > 0) {
        sprintf(caTmp, "%u", (*pxPingQuery).data_size);
        strcat(caCommand, " -s ");
        strcat(caCommand, caTmp);
    }

    /*** append the timeout switch -W. (Currently not supported on Target)
    if((*pxPingQuery).timeout > 0) {
        sprintf(caTmp, "%u", (((*pxPingQuery).timeout)/1000));
        strcat(caCommand, " -W ");
        strcat(caCommand, caTmp);
    } ***/

    /* append the qos(dscp) switch. Default dscp = 0 */
    if((*pxPingQuery).dscp > 0) {
        sprintf(caTmp, "%u", (*pxPingQuery).dscp);
        strcat(caCommand, " -Q ");
        strcat(caCommand, caTmp);
    }

    /* append the quiet switch */
    strcat(caCommand, " -q ");

    /* append the host at the end */
    if((iRet = inet_pton(AF_INET, pxPingQuery->host, &iTmp)) <= 0) {
        /* The the host must be Domain Name */
        res_init();
        pxHE = gethostbyname(pxPingQuery->host);
        /*******
        memset(caTmp, '\0', sizeof(caTmp));
        iRet = gethostbyname_r(pxPingQuery->host, &xHostEnt, caTmp,
                               sizeof(caTmp), &pxHE, &iHErr);
        struct in_addr sin_addr;
        sin_addr = *(struct in_addr *) xHostEnt.h_addr_list[0];
        iTmp = ntohl(sin_addr.s_addr);
        printf("iRet=%d iHerr=%d Hostname=%s %u Host=%s caTmp='%s' %p\n", iRet,
               iHErr, xHostEnt.h_name, iTmp, pxPingQuery->host, caTmp, pxHE);**/
        if(pxHE == NULL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Invalid host %s\n",
                        _FUNCL_, pxPingQuery->host);
            strcpy(pxPingResp->caDiagState, "Error_CannotResolveHostName");
            iRet = IFX_CWMP_FAILURE;
            goto errorHandler;
        }
    }
    strcat(caCommand, (*pxPingQuery).host);

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "PINGCMD: '%s'\n", caCommand);

    if((fp = popen(caCommand, "r")) == NULL) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d popen failed for %s\n",
                    _FUNCL_, caCommand);
        iRet = IFX_CWMP_FAILURE;
        goto errorHandler;
    }

    /* start processing the file */
    do {
        if(fgets(mirrorline, LINESIZE, fp) == NULL) {
            break;
        }
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s", mirrorline);

        psString = strstr(mirrorline, "received");
        if(psString != NULL) {
            psString -= 2;
            while(*psString != ',')
                psString--;

            psString++;
            successcount = atoi(psString);
            (*pxPingResp).iSuccessCount = successcount;
            (*pxPingResp).iFailureCount =
                (*pxPingQuery).num_repeat - successcount;
        }
        strcpy(pxPingResp->caDiagState, "Complete");
        iRet = IFX_CWMP_SUCCESS;

#ifdef MIPSTARGET
        psString = strstr(mirrorline, "round-trip min/avg/max = ");
#else
        psString = strstr(mirrorline, "rtt min/avg/max/mdev = ");
#endif
        if(psString != NULL) {
#ifdef MIPSTARGET
            psString += strlen("round-trip min/avg/max = ");
#else
            psString += strlen("rtt min/avg/max/mdev = ");
#endif

            /* now pointing to first digit */
            ptok = strtok(psString, ".");
	    if(ptok!=NULL)
   	    {	
            min = atoi(ptok);
	    }
            ptok = strtok(NULL, "/");   // token has min

            ptok = strtok(NULL, ".");
            if(ptok!=NULL)
            {
            avg = atoi(ptok);
            }
            ptok = strtok(NULL, "/");   // token has avg

            ptok = strtok(NULL, ".");
            if(ptok!=NULL)
            {
            max = atoi(ptok);
            }
            ptok = strtok(NULL, "/");   // token has max

            // assign values
            (*pxPingResp).iMinimumResponseTime = min;
            (*pxPingResp).iAverageResponseTime = avg;
            (*pxPingResp).iMaximumResponseTime = max;
            /* IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "Success = %d, Min =
               %d," " Max = %d, Avg = %d\n", successcount, min, max, avg); */
            break;
        }
    } while(1);

    /* close the file */
    pclose(fp);

  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_IPPingDiagPerformTest
* Desc: Gets the value. Calls IFX_IPPingTest. Set the required value. Posts the 
*       message to the Stacks FIFO about the completion of IPPing Diag Test
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS 
*******************************************************************************/
static int32
IFX_IPPingDiagPerformTest()
{
    int32 iRet = IFX_CWMP_SUCCESS, iFIFOFd = 0;
    IPPING_DIAG xIPPing;
    IPPingResp xIPPingResp;

    memset(&xIPPing, '\0', sizeof(xIPPing));
    memset(&xIPPingResp, '\0', sizeof(xIPPingResp));

    iRet = ifx_get_ipping_diag(&xIPPing, 0);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_ipping_diag() failed\n", _FUNCL_, iRet);
        goto errorHandler;
    }

    iRet = IFX_IPPingTest(&xIPPing, &xIPPingResp);
    if(iRet == IFX_CWMP_SUCCESS) {
        xIPPing.success_cnt = xIPPingResp.iSuccessCount;
        xIPPing.failure_cnt = xIPPingResp.iFailureCount;
        xIPPing.avg_resp_time = xIPPingResp.iAverageResponseTime;
        xIPPing.min_resp_time = xIPPingResp.iMinimumResponseTime;
        xIPPing.max_resp_time = xIPPingResp.iMaximumResponseTime;
    }
    strcpy(xIPPing.diag_state, xIPPingResp.caDiagState);

    iRet = ifx_set_ipping_diag(IFX_F_MODIFY, &xIPPing, 0);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_set_ipping_diag() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
    /* Send msg to FIFO */
    iFIFOFd = IFX_OS_OpenFifo((uchar8 *) IFX_IPC_TR_FIFO, O_RDWR);
    if(iFIFOFd < 0) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s:%d Error opening FIFO\n",
                    _FUNCL_);
        iRet = ERR_CWMP_FIFO_OPEN;
        goto errorHandler;
    }

    if(IFX_IPC_SendMsg(iFIFOFd, (uchar8) IFX_IPC_APP_DIAGNOSTIC, 0, 0, 0, NULL)
       != IFX_IPC_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Error sending msg to "
                    "FIFO\n", _FUNCL_);
    }
    IFX_OS_CloseFifo(iFIFOFd);

  errorHandler:
    /* Always return SUCCESS */
    return IFX_CWMP_SUCCESS;
}


/*******************************************************************************
* Function: IFX_IPPingDiagnostics
* Desc: 
*              
* Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
*             OUT void **ppRet, OUT int32 * piNumRetElem
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_IPPingDiagnostics(IN OperInfo * pxOI,
                      INOUT void *pParamStruct,
                      IN int32 iElements, OUT void **ppRet,
                      OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;

    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:
                    iRet = IFX_IPPingDiagGetNotifyValue(pxOI, xpParamVal,
                                                        iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                                pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                    iRet = IFX_IPPingDiagValidate(xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_SETVAL_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:
                    break;
                case OP_SETVAL_MODIFY:
                    iRet = IFX_IPPingDiagSetValue(xpParamVal, iElements);
                    if(iRet != IFX_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_SETVAL_ACTIVATE:
                    iRet = IFX_IPPingDiagPerformTest();
                    if(iRet != IFX_SUCCESS)
                        goto errorHandler;
                case OP_SETVAL_COMMIT:
                    break;
                case OP_SETVAL_UNDO:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_DELETE:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_ATTRINFO:
                    iRet =
                        IFX_IPPingDiagSetAttrInfo(pxOI->iCaller, pParamStruct,
                                                  iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                                pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_UPDATE_CHILDINFO_DEL:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                        pxOI->iOper);
            break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_IPPingDiagInit
* Desc: Will initialize some of its data structures, register itself with DS.
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_IPPingDiagInit()
{
    int32 iRet = IFX_CWMP_SUCCESS;
    IPPING_DIAG xIPPing;

    memset(&xIPPing, '\0', sizeof(xIPPing));
    strcpy(xIPPing.diag_state, "None");
    strcpy(xIPPing.host, "0.0.0.0");
    strcpy(xIPPing.interface, "");
    /* TBD: Perform any LANEthernetIfCfgStatsInit related initializations here */
    /* Register the IFX_IPPingDiagInit func ptr in the object model */
    iRet = ifx_ds_register_function(IPPINGDIAG_OBJ, IFX_IPPingDiagnostics);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Unable to Register %s with Object Model\n",
                    _FUNCL_, iRet, IPPINGDIAG_OBJ);
        goto errorHandler;
    }

    iRet = ifx_set_ipping_diag(0, &xIPPing, 0);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Writing default "
                    "ipping_diag section failed in %s\n", _FUNCL_, iRet,
                    IFX_DIAG_FILE);
    }

  errorHandler:
    return iRet;
}
