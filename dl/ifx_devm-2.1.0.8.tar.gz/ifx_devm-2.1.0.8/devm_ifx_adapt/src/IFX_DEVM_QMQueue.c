/* 
** =============================================================================
**   FILE NAME        : IFX_QMQueue.c
**   PROJECT          : TR69
**   MODULES          : QueueManagement.Queue
**   DATE             : 12-01-2009
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This is the Queue Module. It is required by the 
**                      controller module of TR69 stack to GET/SET/ADD/DELETE
**                      Queue specific information.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author                         $Comment
**   15-01-2008       TR69 team                       Initial Version
**
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_QMQueue.h"
  // Required for STATIC
 
#include "IFX_DEVM_OID.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_StackUtil.h" 
#include "IFX_DEVM_DS.h"
#include "ifx_amazon_cfg.h"

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFX_QUEUE_MGMT_QUEUE_OBJ    FORMNAME("QueueManagement.Queue")
/* TBD: Temporary Placeholders, since we do not get this from Platform include
   header files */

/* IPQOS Tags */
#define TAG_IPQOS_CAPABILITY                      "qos_capability"
#define TAG_IPQOS_QM                              "qos_queuemgmt"
#define TAG_IPQOS_CLASSIFY                        "qos_class"
#define TAG_IPQOS_QUEUE                            "qos_queue"
#define PREFIX_IPQOS_CLASSIFY                      "qcl"
#define PREFIX_IPQOS_QUEUE                         "qq"

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

STATIC int32
GetParamOffset(IN int32 *paiOID);
STATIC int32
GetVal(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
       IN int32 iElements);
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
AddObj(IN OperInfo *pxOI,INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
SetDelete(IN OperInfo *pxOI,INOUT ParamVal *pxParamVal,
          IN int32 iElements, OUT void **ppxParamStructRet,
          OUT int32 * piNumRetElem);

STATIC int32 
ParamValidate(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : GetParamOffset
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

STATIC int32
GetParamOffset(IN int32 *paiOID)
{
    int32 iCnt;

    for (iCnt = 0; paiOID[iCnt] != 0; iCnt++);

    return (iCnt - 1);
}

/*
** =============================================================================
**   Function Name    : ParamValidate
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/
STATIC int32
ParamValidate(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
   int32   iRet  = IFX_CWMP_SUCCESS;
   uint32 iCpeid = 0;   
   IFX_MAPI_QoS_Queue xQMQ;
   IFX_MAPI_QoS_Interface_Type qIfType = 0;

   iRet = IFX_GetCpeId(pxParamVal->iaOID,&iCpeid);
   if(iRet != IFX_CWMP_SUCCESS)
        goto cleanup;
   
   qIfType = ifx_mapi_get_active_qos_iface();

   memset(&xQMQ, 0, sizeof(IFX_MAPI_QoS_Queue));
   /* Fill the cpeid in the structure to get the required instance */
   xQMQ.iid.cpeId.Id = iCpeid;   
      
   iRet = ifx_mapi_get_qos_queue(&xQMQ, IFX_F_DEFAULT); 
   /* Check for error */
   if (iRet != IFX_SUCCESS)
   {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_queue failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
   }
   
   if((xQMQ.qIfType != qIfType) && (xQMQ.qIfType != IFX_MAPI_QoS_LAN_ETH))
     iRet = ERR_CWMP_PARAMVAL_INVALID;

   cleanup:
    return (iRet);	
}

/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetVal(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
       IN int32 iElements)
{
    int32   iRet  = IFX_CWMP_SUCCESS;
    int32   iRtn  = IFX_SUCCESS;
    int32   iCnt  = 0;
    IFX_MAPI_QoS_Queue xQMQ;
    int32   iParamOffset;
    uint32 iCpeid = 0;
    IFX_MAPI_QoS_Interface_Type qIfType;
    char8 sBuf[MAX_FILELINE_LEN];

    // Get Cpeid from object ID
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    	goto cleanup;

    memset(&xQMQ, 0, sizeof(IFX_MAPI_QoS_Queue));

    /* Fill the cpeid in the structure to get the required instance */
    xQMQ.iid.cpeId.Id = iCpeid;

    /* Get all the IFX_MAPI_QoS_Classifier parameters using Protocol API */
    iRtn = ifx_mapi_get_qos_queue(&xQMQ, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_queue failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] qos_schtype=[%d],traffic_class=%d \n",
                    __FILE__,  __func__, __LINE__,
		    xQMQ.schedType,xQMQ.trafficClass);
    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        /* TBD: Currently keeping size as 257 bytes, since max param size is string(256) */
        (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(257);

        /* Check for error */
        if (!((pxParamVal[iCnt]).Value))
        {
            iRet = ERR_OUT_OF_MEMORY;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Allocation Failure\n",
                         __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
        }
    	qIfType = ifx_mapi_get_active_qos_iface();

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_QM_Q_QUEUEENABLE:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMQ.enable);
                break;
            case OID_IGD_QM_Q_QUEUESTATUS:
                /* Copy the value to allocated area */
                if (xQMQ.status == IPQOS_STATUS_DISABLED)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Disabled");
                }
                else if (xQMQ.status == IPQOS_STATUS_ENABLED)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Enabled");
                }
                else
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Error");
                }
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_QM_Q_TRAFFICCLASSES:
                sprintf(pxParamVal[iCnt].Value, "%s", xQMQ.trafficClass);
                break;
            case OID_IGD_QM_Q_QUEUEINTERFACE:
                /* Copy the value to allocated area */
                if (xQMQ.qIfType == qIfType){
                    sprintf(pxParamVal[iCnt].Value, "%s", "WAN");
		}
		else if (xQMQ.qIfType == IFX_MAPI_QoS_LAN_ETH){
			sprintf(pxParamVal[iCnt].Value, "%s", "LAN");
		}
                else
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Error");
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Invalid Interface, QoS supports only LAN and WAN interfaces\n",__FILE__, __func__, __LINE__);
                    goto cleanup;
		}
                break;

            case OID_IGD_QM_Q_QUEUEBUFFERLENGTH:
                // TBD: How to get this? Currently making it 0
                sprintf(pxParamVal[iCnt].Value, "%u", xQMQ.qLen);
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;
            case OID_IGD_QM_Q_QUEUEWEIGHT:
                // TBD: Do we support this since we do not support WFR and WRR? Currently Reading from struct
                sprintf(pxParamVal[iCnt].Value, "%u", xQMQ.qWt);
                break;
            case OID_IGD_QM_Q_QUEUEPRECEDENCE:
                sprintf(pxParamVal[iCnt].Value, "%u", xQMQ.qPrio);
                break;
            case OID_IGD_QM_Q_REDTHRESHOLD:
                sprintf(pxParamVal[iCnt].Value, "%u", xQMQ.redTh);
                break;
            case OID_IGD_QM_Q_REDPERCENTAGE:
                sprintf(pxParamVal[iCnt].Value, "%u", xQMQ.redPct);
                break;
            case OID_IGD_QM_Q_DROPALGORITHM:
                // TBD: Perform Conversion here for all allowable types
                if (xQMQ.dropType == IFX_MAPI_QoS_Drop_DT){
                    sprintf(pxParamVal[iCnt].Value, "%s", "DT");
		}
		else if (xQMQ.dropType == IFX_MAPI_QoS_Drop_RED){
                    sprintf(pxParamVal[iCnt].Value, "%s", "RED");
		} else
		{
                    sprintf(pxParamVal[iCnt].Value, "%s", "Error");
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Invalid DropType, QoS supports only DT and RED Drop types\n",__FILE__, __func__, __LINE__);
                    goto cleanup;
		}


                break;
            case OID_IGD_QM_Q_SCHEDULERALGORITHM:
                if (xQMQ.schedType == IFX_MAPI_QoS_Sched_SP)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "SP");
                }
		else if (xQMQ.schedType == IFX_MAPI_QoS_Sched_WFQ)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "WFQ");
		} else
		{
                    sprintf(pxParamVal[iCnt].Value, "%s", "Error");
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Invalid Scheduler Type, QoS support only SP and WFQ Scheduler types\n",__FILE__, __func__, __LINE__);
                    goto cleanup;
		}
                break;
            case OID_IGD_QM_Q_SHAPINGRATE:


                if (xQMQ.shapeRate != -1 )
		{ //if rate shaping is enabled just return the rc.conf values

                	if (xQMQ.schedType == IFX_MAPI_QoS_Sched_SP)
	                {
		                sprintf(pxParamVal[iCnt].Value, "%d", xQMQ.peakRate);
			}
			else if (xQMQ.schedType == IFX_MAPI_QoS_Sched_WFQ)
        	        {
		                sprintf(pxParamVal[iCnt].Value, "%d", xQMQ.commitRate);
			}

		} else
		{
        		//read the default interface from rc.conf
			if ((iRtn = ifx_GetObjData(FILE_SYSTEM_STATUS, "qos_bk","up_link_rate",
						IFX_F_GET_ENA, 0, sBuf)) != IFX_SUCCESS) {
                	    sprintf(pxParamVal[iCnt].Value, "%s", "Error");
	                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
        	                    "[%s:%s:%d] [Error] reading rate from /tmp/system_status failed! \n",__FILE__, __func__, __LINE__);
	                    goto cleanup;
			}

                	xQMQ.peakRate = atoi(sBuf);
			sprintf(pxParamVal[iCnt].Value, "%d", xQMQ.peakRate);
		}
                break;
            case OID_IGD_QM_Q_SHAPINGBURSTSIZE:
                if (xQMQ.shapeRate != -1 )
		{
                sprintf(pxParamVal[iCnt].Value, "%u", xQMQ.sbs);
		}else
		{
			//xQMQ.sbs = 1000;
                	sprintf(pxParamVal[iCnt].Value, "%u", 1000);
		}
                break;
            default:
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
                goto cleanup;
        }
    }

cleanup:
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : Modify
**
**   Description      : This function modifies the values of parameters in 
**                      Queue object. It calls respective Management
**                      API for same. It performs modification only if parameter 
**                      has Write permission. In certain cases it also performs 
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32       iRet       = IFX_CWMP_SUCCESS;
    int32       iRtn       = IFX_SUCCESS;
    uint32      iCpeid     = 0;
    int32       iCnt       = 0, i=0, idsCnt = 0;
    IFX_MAPI_QoS_Queue xQMQ;
    int32       iParamOffset;
    char8       *psTmpVal;
    uint32      uiFlags;
    uchar8      ucOldEnableState, ucOldPrio;
    char8       sQID[20]; //Max size of int
    IFX_MAPI_QoS_Capability xQoSC;
    IFX_MAPI_QoS_Interface_Type qIfType;
    int32 defaultQ = 0;
    IFX_MAPI_QoS_Queue *qos_queue = NULL;
    /* Get all the IFX_MAPI_QoS_Capability parameters using Protocol API */
    iRtn = ifx_mapi_get_qos_capability(&xQoSC, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_capability failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }



    // Get Cpeid from object ID
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    	goto cleanup;

    memset(&xQMQ, 0, sizeof(IFX_MAPI_QoS_Queue));

    /* Fill the cpeid in the structure to get the required instance */
    xQMQ.iid.cpeId.Id = iCpeid;

    /* Get all the IFX_MAPI_QoS_Classifier parameters using Protocol API */
    iRtn = ifx_mapi_get_qos_queue(&xQMQ, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_queue failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Set the old enable state */
    ucOldEnableState = xQMQ.enable; 
    ucOldPrio = xQMQ.qPrio;

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    qIfType = ifx_mapi_get_active_qos_iface();

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_QM_Q_QUEUEENABLE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
		    /* Doing away with check for qIfType since it can be both LAN and WAN*/
			//if(xQMQ.qIfType == qIfType) {
			xQMQ.enable = TRUE;
		    //} else {
		//	(pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                  //  	iRet = ERR_CWMP_INVAL_ARGS;
                    //	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                     //           "[%s:%s:%d] [%d] \n Queue is not attached to the active interface\n",__FILE__, __func__, __LINE__, iRet);
                 // 	goto cleanup;
		  //  }
                }
                else
                {
                    xQMQ.enable = FALSE;
                }
                break;
            case OID_IGD_QM_Q_TRAFFICCLASSES:
                if (psTmpVal)
                    strcpy(xQMQ.trafficClass, psTmpVal);
                break;
            case OID_IGD_QM_Q_QUEUEINTERFACE:
		    if(!strcmp(psTmpVal,"WAN")) {
                        xQMQ.qIfType = qIfType;
		    }
		    else if(!strcmp(psTmpVal,"LAN")) {
			    switch (qIfType)
			    {
				    case IFX_MAPI_QoS_WAN_ATM:
                        		    xQMQ.qIfType = IFX_MAPI_QoS_LAN_ATM;
					    break;
				    case IFX_MAPI_QoS_WAN_PTM:
                        		    xQMQ.qIfType = IFX_MAPI_QoS_LAN_PTM;
					    break;
				    case IFX_MAPI_QoS_WAN_ETH_0:
                        		    xQMQ.qIfType = IFX_MAPI_QoS_LAN_ETH_0;
					    break;
				    case IFX_MAPI_QoS_WAN_ETH_1:
                        		    xQMQ.qIfType = IFX_MAPI_QoS_LAN_ETH_1;
					    break;
                            	    default:
					    xQMQ.qIfType = IFX_MAPI_QoS_LAN_ETH;
			    }
		    }
		    else {
			(pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        iRet = ERR_CWMP_INVAL_ARGS;
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] \n QoS is supported only for LAN and WAN interfaces\n",
                                __FILE__, __func__, __LINE__, iRet);
                        goto cleanup;
		    }
                break;
            case OID_IGD_QM_Q_QUEUEWEIGHT:
                // TBD: Do we support this since we do not support WFR and WRR?
                xQMQ.qWt = atoi(psTmpVal);
		if( xQMQ.qWt > 0 )
			xQMQ.qWt = 1;

                break;
            case OID_IGD_QM_Q_QUEUEPRECEDENCE:
		if (atoi(psTmpVal) > (xQoSC.maxInputQs+xQoSC.maxOutputQs))
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Precedence cannot be greater than max supported Qs\n",
                                __FILE__, __func__, __LINE__, iRet);
                    goto cleanup;
                }
                xQMQ.qPrio = atoi(psTmpVal);
                break;
            case OID_IGD_QM_Q_REDTHRESHOLD:
                xQMQ.redTh = atoi(psTmpVal);
                break;
            case OID_IGD_QM_Q_REDPERCENTAGE:
                xQMQ.redPct = atoi(psTmpVal);
                break;
            case OID_IGD_QM_Q_DROPALGORITHM:
                if (!strcmp(psTmpVal, "DT")){
                    xQMQ.dropType = IFX_MAPI_QoS_Drop_DT;
                }
		else if (!strcmp(psTmpVal, "RED")){
                    xQMQ.dropType = IFX_MAPI_QoS_Drop_RED;
		}else{
			(pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        iRet = ERR_CWMP_INVAL_ARGS;
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] \n We support only DT or RED Drop Algorithms \n",__FILE__, __func__, __LINE__, iRet);
                        goto cleanup;

                }
                break;
            case OID_IGD_QM_Q_SCHEDULERALGORITHM:
	
		if (!strcmp( psTmpVal, "SP" )){
			xQMQ.schedType = IFX_MAPI_QoS_Sched_SP;
		}
		if (!strcmp( psTmpVal, "WFQ" )){
                	xQMQ.schedType = IFX_MAPI_QoS_Sched_WFQ;

		}else{
			(pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        iRet = ERR_CWMP_INVAL_ARGS;
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] \n We support only SP or WFQ Scheduler types \n",
                                __FILE__, __func__, __LINE__, iRet);
                        goto cleanup;

		}
                break;
            case OID_IGD_QM_Q_SHAPINGRATE:
		if ( xQMQ.schedType == IFX_MAPI_QoS_Sched_SP ){
			xQMQ.peakRate = atoi(psTmpVal);
		}
		if ( xQMQ.schedType == IFX_MAPI_QoS_Sched_WFQ ){
                	xQMQ.commitRate = atoi(psTmpVal);
		}else {

                	xQMQ.commitRate = atoi(psTmpVal);
			xQMQ.peakRate = atoi(psTmpVal);
		}
                
		if (xQMQ.shapeRate != 0){
                	xQMQ.shaperEnable = 1;
		}
                break;
            case OID_IGD_QM_Q_SHAPINGBURSTSIZE:
                xQMQ.sbs = atoi(psTmpVal);
                break;
            case OID_IGD_QM_Q_QUEUESTATUS:
		xQMQ.status = atoi(psTmpVal);		
		break;
            case OID_IGD_QM_Q_QUEUEBUFFERLENGTH:
                (pxParamVal[iCnt]).iFaultCode = ERR_NON_WRITABLE;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Cannot modify the parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

    /* Fill the iid structure in IFX_MAPI_QoS_Queue*/
    xQMQ.iid.config_owner = iCaller;


    //Allow enabling the queue, if there is no other queue already enabled with that precedence. This is for US Queues
    if(((xQMQ.enable == TRUE && ucOldEnableState == FALSE) || ((ucOldPrio != xQMQ.qPrio) && xQMQ.enable == TRUE)) && (xQMQ.qIfType == qIfType)) {
       if(ifx_mapi_get_all_qos_queue_if_specific( qIfType,(uint32 *)&iCnt, &qos_queue, IFX_F_DEFAULT) != IFX_SUCCESS) {
          IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] Failed to display configured queues for interface %d", __FUNCTION__, __LINE__, qIfType);
          goto cleanup;
        }
        for(i=0;i<iCnt;i++) {
          if(qos_queue[i].enable == TRUE && qos_queue[i].qPrio == xQMQ.qPrio) {
              for (iCnt = 0; iCnt < iElements; iCnt++) 
                  (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
              iRet = ERR_CWMP_INVAL_ARGS;
              IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] Enabled Queue already exists with precedence %d\n",
                     __FILE__, __func__, __LINE__, xQMQ.qPrio);
              free(qos_queue);
              goto cleanup;
          }       
        }
        free(qos_queue);
    } 
    //Allow enabling the queue, if there is no other queue already enabled with that precedence. This is for DS Queues
    if( ((xQMQ.enable == TRUE && ucOldEnableState == FALSE) || ((ucOldPrio != xQMQ.qPrio) && xQMQ.enable == TRUE)) && ((xQMQ.qIfType == IFX_MAPI_QoS_WAN) || (xQMQ.qIfType == IFX_MAPI_QoS_WAN_ALL))) {
       if(ifx_mapi_get_all_qos_queue_if_specific( qIfType,(uint32 *)&idsCnt, &qos_queue, IFX_F_DEFAULT) != IFX_SUCCESS) {
          IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] Failed to display configured queues for interface %d", __FUNCTION__, __LINE__, qIfType);
          goto cleanup;
        }
        for(i=0;i<idsCnt;i++) {
          if(qos_queue[i].enable == TRUE && qos_queue[i].qPrio == xQMQ.qPrio) {
              for (idsCnt = 0; idsCnt < iElements; idsCnt++) 
                  (pxParamVal[idsCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
              iRet = ERR_CWMP_INVAL_ARGS;
              IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] Enabled Queue already exists with precedence %d\n",
                     __FILE__, __func__, __LINE__, xQMQ.qPrio);
              free(qos_queue);
              goto cleanup;
          }       
        }
        free(qos_queue);
    } 


    /* Restrict Disabling a default Q */
    defaultQ = ifx_mapi_get_default_queue_cpeid(qIfType);

    if ((defaultQ == iCpeid) && (ucOldEnableState == TRUE) && (xQMQ.enable == FALSE))
    {
            for (iCnt = 0; iCnt < iElements; iCnt++)
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
            iRet = ERR_CWMP_INVAL_ARGS;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] Cannot disable a default Queue\n",
                     __FILE__, __func__, __LINE__);
        goto cleanup;
    }

    /* Allow disabling the Queue, only if all the classifiers attached to it are disabled */
    sprintf(sQID,"%d", iCpeid);
    iCnt = ifx_get_instance_count_from_dist_fvps(TAG_IPQOS_CLASSIFY, PREFIX_IPQOS_CLASSIFY, "qId", sQID, "enable", "1", IFX_F_GET_ANY);

    if ((iCnt > 0) && (ucOldEnableState == TRUE) && (xQMQ.enable == FALSE))
    {
            for (iCnt = 0; iCnt < iElements; iCnt++)
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
            iRet = ERR_CWMP_INVAL_ARGS;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] Queue has %d enabled Classifiers attached\n",
                     __FILE__, __func__, __LINE__, iCnt);
        goto cleanup;
    } 

    /* Set all the IFX_MAPI_QoS_Queue parameters using Object API */
    uiFlags = IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH;
    if ( xQMQ.enable == FALSE)
    {
        uiFlags |= IFX_F_DONT_VALIDATE;
#if 0
        if (ucOldEnableState == TRUE)
            uiFlags |= IFX_F_DEACTIVATE;
        else
            uiFlags |= IFX_F_DONT_ACTIVATE;
#endif
    }
    iRtn = ifx_mapi_set_qos_queue(IFX_OP_MOD, &xQMQ, uiFlags);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to set values of all "
                    "parameters\n", __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    return (iRet);

}

/* 
** =============================================================================
**   Function Name    : Validate
**
**   Description      : This function validates the values of parameters in
**                      Queue object.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      validated.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When validation of all parameters is
**                      successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in validating at least one parameter.
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iCnt;
    int32   iParamOffset;
    char8   *psTmpVal;

   /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Iterate and validate the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Return a failure if the value is NULL pointer */
        if (!psTmpVal)
        {
            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
            iRet = ERR_CWMP_INVAL_ARGS;
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_QM_Q_QUEUESTATUS:
            case OID_IGD_QM_Q_QUEUEBUFFERLENGTH:
                /* RO params - Not validating. just returtning success */
                break;
            case OID_IGD_QM_Q_QUEUEENABLE:
            case OID_IGD_QM_Q_TRAFFICCLASSES:
            case OID_IGD_QM_Q_QUEUEINTERFACE:
            case OID_IGD_QM_Q_QUEUEWEIGHT:
            case OID_IGD_QM_Q_QUEUEPRECEDENCE:
            case OID_IGD_QM_Q_REDTHRESHOLD:
            case OID_IGD_QM_Q_REDPERCENTAGE:
            case OID_IGD_QM_Q_DROPALGORITHM:
            case OID_IGD_QM_Q_SCHEDULERALGORITHM:
            case OID_IGD_QM_Q_SHAPINGRATE:
            case OID_IGD_QM_Q_SHAPINGBURSTSIZE:
                /* TBD: Will be done later if required */
                break;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

cleanup:
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Validating requested parameter failed\n",
                    __FILE__, __func__, __LINE__, iRet);
    }
    return (iRet);

}

STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iCnt;
    int32 iParamOffset;
    int32 iValueFlag = 0; /* Mandatory */

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Set the fault code to Success and value to NULL pointer for all parameters
       other than uptime */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Mark that values have been malloced. Currently always doing it, since not possible
       to keep track in a loop, for which params its malloced */
    iValueFlag = 1;

    /* Update Attribute Information */
    iRet = IFX_SetAttributesInfo(NULL, pxParamVal, iElements);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Updating Param Attribute Info failed\n",
                    __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    /* Free the Value that has been allocated */
    if (iValueFlag)
    { 
        for (iCnt = 0; iCnt < iElements; iCnt++)
        {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
        }
    }

    return (iRet);

}

STATIC int32
AddObj(IN OperInfo *pxOI,INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32 iRet=IFX_CWMP_SUCCESS;
    int32       iRtn       = IFX_SUCCESS;
    uint32 iFlags=0;
    uint32 iOper;
    uint32 uiPcpeId=0;
    IFX_MAPI_QoS_Queue xQMQ;
    int32 iCnt;
    int32 iParamOffset;
    char8       *psTmpVal;
    IFX_MAPI_QoS_Capability xQoSC;
    uint32 uiInstanceCount = 0;
    IFX_MAPI_QoS_Interface_Type qIfType;
    char8 qIf[10]={0};
    uint32  outFlag = IFX_F_DEFAULT;

//TBD: Need to put a check on the number of queues allowed in the system
    /* Get all the IFX_MAPI_QoS_Capability parameters using Protocol API */
    iRtn = ifx_mapi_get_qos_capability(&xQoSC, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_capability failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

   qIfType = ifx_mapi_get_active_qos_iface();
 
   uiInstanceCount = 0;
   uiInstanceCount = ifx_mapi_get_queue_count_for_wan_mode(qIfType);
   if ( ( (uiInstanceCount >= 4) && (qIfType == IFX_MAPI_QoS_WAN_ETH_0)) || (uiInstanceCount >= 8) )
   {
        iRet = ERR_RESOURCE_EXCEEDED;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d] Cannot add more Queues\n",
                    __FILE__,  __func__, __LINE__);
        goto cleanup;
   }

   /*This check is not required since we are not doing PVC based qos
    * if(qIfType == IFX_MAPI_QoS_WAN_ATM) {	
   	if(ifx_mapi_get_queue_add_check(qIfType)!= IFX_SUCCESS){
            iRet = ERR_RESOURCE_EXCEEDED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] Cannot add more Queues\n",
                    __FILE__,  __func__, __LINE__);
            goto cleanup;
   	}
    }*/

    memset(&xQMQ, 0, sizeof(IFX_MAPI_QoS_Queue));

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_QM_Q_QUEUEENABLE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMQ.enable = TRUE;
                }
                else
                {
                    xQMQ.enable = FALSE;
                }
                break;
            case OID_IGD_QM_Q_QUEUESTATUS:
                // Nothing to do. No place in structure
                break;
            case OID_IGD_QM_Q_TRAFFICCLASSES:
                if (psTmpVal)
                    strcpy(xQMQ.trafficClass, psTmpVal);
                break;
            case OID_IGD_QM_Q_QUEUEINTERFACE:
                //TBD: Needs to be handled
                xQMQ.qIfType = qIfType;
                break;
            case OID_IGD_QM_Q_QUEUEBUFFERLENGTH:
                //TBD: Currently not part of structure. See if it needs to be a part.
                xQMQ.qLen = atoi(psTmpVal);
                break;
            case OID_IGD_QM_Q_QUEUEWEIGHT:
                // TBD: Do we support this since we do not support WFR and WRR?
                xQMQ.qWt = atoi(psTmpVal);
                break;
            case OID_IGD_QM_Q_QUEUEPRECEDENCE:
                xQMQ.qPrio = atoi(psTmpVal);
                break;
            case OID_IGD_QM_Q_REDTHRESHOLD:
                xQMQ.redTh = atoi(psTmpVal);
                break;
            case OID_IGD_QM_Q_REDPERCENTAGE:
                xQMQ.redPct = atoi(psTmpVal);
                break;
            case OID_IGD_QM_Q_DROPALGORITHM:
                // TBD: Perform Mapping Here. Currently we support only DT. Overriding Default.
                    xQMQ.dropType = IFX_MAPI_QoS_Drop_DT;
                break;
            case OID_IGD_QM_Q_SCHEDULERALGORITHM:
                // TBD: Perform Mapping Here. Currently we support only SP. Overriding Default.
                xQMQ.schedType = IFX_MAPI_QoS_Sched_SP;
                break;
            case OID_IGD_QM_Q_SHAPINGRATE:
                xQMQ.shapeRate = atoi(psTmpVal);
                break;
            case OID_IGD_QM_Q_SHAPINGBURSTSIZE:
                xQMQ.sbs = atoi(psTmpVal);
                break;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter [%d]\n",
                            __FILE__, __func__, __LINE__, iRet, (pxParamVal[iCnt]).iaOID[iParamOffset]);
                goto cleanup;
        }
    }

        //TBD: Fill in the required params

	//Fill the operation
	iOper = IFX_OP_ADD;
	
	//Fills the Cpeid,ParentCepid,TR69Id,Owner
	iRet = IFX_GetParentObjCpeId(pxParamVal->iaOID,&uiPcpeId);
	if(iRet != IFX_CWMP_SUCCESS)
		goto cleanup;

        //read the default interface from rc.conf
	ifx_GetObjData(FILE_RC_CONF,TAG_IPQOS_QM, "qm_qIf",IFX_F_DEFAULT,&outFlag,qIf );

	xQMQ.iid.config_owner=pxOI->iCaller;
	xQMQ.iid.cpeId.Id=0;
	xQMQ.iid.pcpeId.Id=uiPcpeId;
	strcpy(xQMQ.qIf ,qIf); 
	//Convert array into dotted form and then strcpy
	
	iRet = IFX_ConvertOidDottedForm(pxParamVal->iaOID, xQMQ.iid.tr69Id);
	if(iRet != IFX_CWMP_SUCCESS)
		goto cleanup;

	//Flags should be filled
	//iFlags =(	IFX_F_DONT_ACTIVATE|IFX_F_DONT_CHECKPOINT|
	iFlags =(	IFX_F_DONT_CHECKPOINT|
			IFX_F_DONT_VALIDATE|IFX_F_DONT_WRITE_TO_FLASH);
	iRtn = ifx_mapi_set_qos_queue(iOper, &xQMQ, iFlags);

	if(iRtn != IFX_SUCCESS)
	{
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"ifx_mapi_set_qos_queue AddObj Mgmt API"					                          " returned error\n");
        iRet = ERR_CWMP_INTERNAL;
		goto cleanup;
		
	}	

cleanup:
return iRet;

}

STATIC int32
SetDelete(IN OperInfo *pxOI,INOUT ParamVal *pxParamVal,
          IN int32 iElements, OUT void **ppxParamStructRet,
          OUT int32 * piNumRetElem)
{
#define QUEUEMGMT_QUEUE_OPTION_NO_OF_DEP_OIDS 0
#define QUEUEMGMT_QUEUE_DEP_OIDS 1
#define STATS_DEPTH 5
    int32 iRet=IFX_CWMP_SUCCESS;
    int32 iRtn=IFX_SUCCESS;
    uint32 uiCpeid=0;
    IFX_MAPI_QoS_Queue xQMQ;
    uint32 iOper=0,iFlags=0;
    int32  iParamPos=0;
    ParamVal *Param_DepOids=NULL;
    char8       sQID[20]; //Max size of int
    int32       iCnt=0;
    IFX_MAPI_QoS_Interface_Type qIfType;
    int32 defaultQ;

    int32 iParamOffset;
    int32 iParamOffset2;
    int32 Queue_Stats_Queue_Oid[6]={OID_IGD,OID_IGD_QM,OID_IGD_QM_QS,MAGIC_NUMBER,OID_IGD_QM_QS_QUEUE};
    ParamVal QSParamArr[QUEUEMGMT_QUEUE_DEP_OIDS];
    ParamVal *QSOutParamArr=NULL;
    ParamVal *QSTempParamArr=NULL;
    uint32 qsOutElem=0;
    char8 qsinst[256] = {0};
    char8 *qsval;
    int32 k = 0,seccount = 0;

    // handle CHK_DELETE_DEP
    if(pxOI->iSubOper == OP_SETVAL_CHK_DEL_DEP)
    {
    	
        Param_DepOids = IFIN_CWMP_MALLOC((QUEUEMGMT_QUEUE_OPTION_NO_OF_DEP_OIDS+1)* sizeof(ParamVal));
        if(Param_DepOids == NULL)
        {
           iRet = ERR_OUT_OF_MEMORY; 
           goto cleanup;
        }

        //Get the WanIpConParamPos 
        iParamPos = IFX_GetParamIdPos(pxParamVal->iaOID);
        if (iParamPos < 0){
            IFX_CWMP_FREE(Param_DepOids);
            goto cleanup; //To fix SCA error
        }

        memcpy((Param_DepOids+0)->iaOID,pxParamVal->iaOID,
               (sizeof(int32)*(iParamPos+1)));

      *ppxParamStructRet = (void *)Param_DepOids;
      *piNumRetElem = QUEUEMGMT_QUEUE_OPTION_NO_OF_DEP_OIDS+1;

        return IFIN_CWMP_SUCCESS;
    }

    if(pxOI->iSubOper == OP_SETVAL_CHK_DEL_ALLOWED)
    {
        return IFIN_CWMP_SUCCESS;
    }

    iParamPos = IFX_GetParamIdPos(pxParamVal->iaOID);
	
    if(ifx_get_sec_count(TAG_IPQOS_QUEUESTATS,&seccount) != IFX_SUCCESS)
    {
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d:%d] ifx_get_sec_count failed \n",__FILE__, __func__, __LINE__);
	iRet = IFX_CWMP_SUCCESS;
    }
    if(seccount > 0)
    {
    	memset(QSParamArr,0x00,(sizeof(ParamVal) *QUEUEMGMT_QUEUE_DEP_OIDS));
    
    	memcpy(QSParamArr->iaOID,Queue_Stats_Queue_Oid,(sizeof(int32)*(STATS_DEPTH +1)));

    	iRet=IFX_GlobalGetVal(QSParamArr,&QSOutParamArr, &qsOutElem);

    	if(iRet != IFX_CWMP_SUCCESS) 
    	{
    		IFX_PrintOID(QSParamArr->iaOID);
        	IFX_FreeParamvalArr(&QSOutParamArr,qsOutElem);
        	iRet = IFX_CWMP_SUCCESS;
    	}
   
    	QSTempParamArr = QSOutParamArr;
    
    	iParamOffset = GetParamOffset(pxParamVal->iaOID);
    	iParamOffset = iParamOffset - 1;
    	iParamOffset2 = GetParamOffset(QSTempParamArr->iaOID);
    	iParamOffset2 = iParamOffset2 - 1;
    
    	for( k=0; k < qsOutElem; ++k)
    	{
	    if(QSTempParamArr != NULL)
	    {
	    	qsval = (char *)(QSTempParamArr->Value);
	    
	    	if(atoi(qsval) == pxParamVal->iaOID[iParamOffset])
	    	{
    			sprintf(qsinst, "InternetGatewayDevice.QueueManagement.QueueStats.%d.",QSTempParamArr->iaOID[iParamOffset2]);
    			
			if( ifx_config_del_obj(qsinst) != IFX_CWMP_SUCCESS)
			{
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d:%d] DS delete fail \n",__FILE__, __func__, __LINE__);
			}
	 	}
	    }
	    QSTempParamArr++;
    	}
    }
    /* Get all the IFX_MAPI_QoS_QM parameters using Protocol API */
    qIfType = ifx_mapi_get_active_qos_iface();
    
    // Get Cpeid from object ID
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&uiCpeid);
    
    if(iRet != IFX_CWMP_SUCCESS)
    	goto cleanup;

    defaultQ = ifx_mapi_get_default_queue_cpeid(qIfType);

    /* Do not allow to delete the default queue */
    if (defaultQ == uiCpeid)
    {

        iRet = ERR_CWMP_REQUEST_DENIED;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] Cannot delete the default queue\n",
                    __FILE__,  __func__, __LINE__);
        goto cleanup;
    }

    /* Allow deleting the Queue, only if no  classifiers are attached to it */
    sprintf(sQID,"%d", uiCpeid);
    iCnt = ifx_get_instance_count_from_dist_fvp(TAG_IPQOS_CLASSIFY, PREFIX_IPQOS_CLASSIFY, "qId", sQID, IFX_F_GET_ANY);

    if (iCnt > 0)
    {
        iRet = ERR_CWMP_REQUEST_DENIED;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] Queue has %d Classifiers attached\n",
                     __FILE__, __func__, __LINE__, iCnt);
        goto cleanup;
    } 

    memset(&xQMQ, 0, sizeof(IFX_MAPI_QoS_Queue));

    /* Fill the cpeid in the structure to get the required instance */
    xQMQ.iid.cpeId.Id = uiCpeid;

    /* Get all the IFX_MAPI_QoS_Queue parameters using Protocol API */
    iRtn = ifx_mapi_get_qos_queue(&xQMQ, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_queue failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* check whether the queue is attached to the active interface */
    /* The following is no longer true because qIftype can be LAN also
     * if(qIfType != xQMQ.qIfType) {
	iRet = ERR_CWMP_REQUEST_DENIED;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] Queue doesnot belong to the active interface\n",
                     __FILE__, __func__, __LINE__);
        goto cleanup;

    }*/

    xQMQ.iid.config_owner=pxOI->iCaller;
    xQMQ.iid.cpeId.Id=uiCpeid;
    memset(xQMQ.iid.tr69Id,0x00,MAX_TR69_ID_LEN);
    iOper = IFX_OP_DEL;
    iFlags = (IFX_F_DELETE|IFX_F_DONT_VALIDATE| IFX_F_DONT_CHECKPOINT|IFX_F_DONT_WRITE_TO_FLASH);
    iRtn = ifx_mapi_set_qos_queue(iOper, &xQMQ, iFlags);
    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "ifx_mapi_set_qos_queue -delete Mgmt API returned error\n");
        iRet = ERR_CWMP_INTERNAL;
        goto cleanup;
    }

cleanup:
    IFX_FreeParamvalArr(&QSOutParamArr,qsOutElem);
    return iRet;
}



/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : IFX_QMQueue_Init
**
**   Description      : This function is called by the controller. It registers
**                      the function responsible for handling Queue
**                      object with data structure. It also performs
**                      initializations specific to Queue object.
**
**   Parameters       : No Parameters. 
**
**   Return Value     : IFX_CWMP_SUCCESS - When Queue object is
**                      initialized successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in initializing Queue object.
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_QMQueue_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the Classification module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_QUEUE_MGMT_QUEUE_OBJ, IFX_QMQueue);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_QUEUE_MGMT_QUEUE_OBJ);
        goto cleanup;
    }

cleanup:
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_QMQueue
**
**   Description      : This function is called by the controller. It handles
**                      Queue object and performs  based on requested
**                      operations/suboperations by invoking internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_QMQueue(IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
             OUT void **ppRet, OUT int32 *piNumRetElem)
{
    int32       iRet           = IFX_CWMP_SUCCESS, iCnt=0;
    ParamVal    *pxParamVal    = (ParamVal *)pParamList;

    /* Process based on type of Operation */
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:

                    /* Get values of all the requested parameters */
                    iRet = GetVal(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_SETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:

                    /* Validate values of all the requested parameters */
                    iRet = Validate(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:

                    /* Check modify dependency of all requested parameters */
                    iRet = IFX_CWMP_SUCCESS;
                    break;
                case OP_SETVAL_MODIFY:

                    /* Set values of all the requested parameters */
                    iRet = Modify(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ATTRINFO:

                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ADD:
                    iRet = AddObj(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }
                    break;
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
                case OP_SETVAL_DELETE:
                    if((iRet= SetDelete(pxOI, pxParamVal,
                        iNumElem, ppRet, piNumRetElem))!= IFX_CWMP_SUCCESS)
                    {

                        switch(pxOI->iSubOper)
                        {
                            case OP_SETVAL_CHK_DEL_DEP:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
                                goto cleanup;
                            case OP_SETVAL_CHK_DEL_ALLOWED:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
                                goto cleanup;
                            case OP_SETVAL_DELETE:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
                                goto cleanup;
                        }
                    }
                    break;



                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_UPDATE_CHILDINFO:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD: 
                case OP_UPDATE_CHILDINFO_DEL: 
                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_PARAM_VALIDATE:
        {
            iRet = ParamValidate(pxOI, pxParamVal, iNumElem);
            /* Check for error */
            if (iRet != IFX_CWMP_SUCCESS)
            {
                for(iCnt = 0; iCnt < iNumElem; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
                }
		iRet = IFX_CWMP_SUCCESS;
		goto cleanup;
            }
	    break; 
        }
        default:
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid Operation\n",
                         __func__, __LINE__, iRet);
            goto cleanup;
    }

cleanup:
    return (iRet);
}
