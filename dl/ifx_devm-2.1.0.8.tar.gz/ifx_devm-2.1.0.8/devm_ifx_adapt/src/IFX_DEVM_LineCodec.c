/* 
** =============================================================================
**   FILE NAME        : IFX_LineCodec
**   PROJECT          : TR104
**   MODULES          : IFX_LineCodec
**   DATE             : 09-11-2006
**   AUTHOR           : TR104 team
**   DESCRIPTION   :

**   REFERENCES      : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2004
**                           Infineon Technologies AG, st. Martin Strasse 53;
**                           81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/

#include "ifx_vmapi_common.h"
#include "IFX_DEVM_VoiceLine.h"
  // Required for STATIC
 
#include "IFX_DEVM_OID.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
 
#include "IFX_DEVM_DS.h"
//#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

int32
IFX_LineCodec(IN OperInfo * pxOI, INOUT void *pParamList,
                     IN int32 iNumElem, OUT void **ppRet,
                     OUT int32 * piNumRetElem);

extern int32 IFX_ContAddObj(IN int32 iCaller, IN char8 *psObj);

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFX_LINECODEC_OBJ "InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.1.Line.1.Codec."
#define CODEC_NO_DEP_OIDS 1

extern char8 vcOsModId;

/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/
STATIC int32
GetVal(IN int32 iCaller, INOUT ParamVal *pxParamVal,
                    IN int32 iElements);
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
GetModifyDep(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
GetNotify(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
                 IN int32 iElements);
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);
/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/
int32 g_Supported_Codecs;

int32
IFX_ContAddObj(IN int32 iCaller, IN char8 * psObj);
/* 
** =============================================================================
**   Function Name    : IFX_GetLineInstanceId
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_GetLineInstanceId(IN int32 *paiOID)
{
    int32 iCnt;

    for (iCnt = 0; paiOID[iCnt] != 0; iCnt++)
    {
      if (paiOID[iCnt] == OID_IGD_S_VS_VP_L)
      {
        return(paiOID[iCnt + 1]);
      }
    }

    return 0;
}


/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetVal(IN int32 iCaller, INOUT ParamVal *pxParamVal,
                    IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iRtn = IFX_SUCCESS;
    int32   iCnt = 0;
    int32   iTmpCnt = -1; /* Mandatory */
    int32   iParamOffset;
    int32   iOID;
    int32   iMemErrorFlag = 0; /* Mandatory */
    x_IFX_VMAPI_LineCodec xLineCodec;
    uint32 uiPCpeId;

    /* NOTE: For all parameters fault code is set to success by default. If error in
       validating first parameter, fault code is set to the error type and other
       parameters are not validated. */
    /* NOTE: For all parameters value is set to NULL by default. */

    /* Set the fault code to Success and value to NULL pointer for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);

    memset(&xLineCodec, 0, sizeof(x_IFX_VMAPI_LineCodec));

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_L_C:{

            char8 sOidString[100] = {0};
            IFX_CpeId *pxCpeIdArray = NULL;
            unsigned int uiNumCpeId;

            /* Get the Parent CPE Id */
            IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT &uiPCpeId);
            xLineCodec.iid.pcpeId.Id = uiPCpeId;
            
            /*ignore the last value as it will be a parameter and we need 
              only till the last instance*/
            iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );

            strcpy(xLineCodec.iid.tr69Id,sOidString);

            /*Get the CPE Id from the corresponding tr69 Id */
            iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId,
                               OUT &pxCpeIdArray);
            if(iRet != IFX_CWMP_SUCCESS){
                   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                   __func__, __LINE__);

              return ERR_CWMP_INTERNAL;
            }
            //printf("CPEID is %d\n",pxCpeIdArray->uiId);   

            /* Fill the CPE ID of the object instance */
            xLineCodec.iid.cpeId.Id = pxCpeIdArray->uiId;
            xLineCodec.iid.config_owner = IFX_TR69;

            /* Get all the Voice Line Codec parameters using VMAPI */
            //iRtn = ifx_get_LineVoiceCodec(&xLineCodec, IFX_F_DEFAULT); 

            IFX_CWMP_FREE(pxCpeIdArray);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to get values of all "
                            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto cleanup;
            }
            }
            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
    case OID_IGD_S_VS_VP_L_C_TRANSMITCODEC:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                    sizeof(uint32));

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }


             /* Copy the value to allocated area */
             //sprintf((pxParamVal[iCnt]).Value, "%d", xLineCodec.uiTxCodec);
             sprintf((pxParamVal[iCnt]).Value, "%d", 0);
 
            break;  
          case OID_IGD_S_VS_VP_L_C_RECEIVECODEC:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                    sizeof(uint32));

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

             /* Copy the value to allocated area */
             //sprintf((pxParamVal[iCnt]).Value, "%d", xLineCodec.uiRxCodec);
             sprintf((pxParamVal[iCnt]).Value, "%d", 0);
 
            break; 
          case OID_IGD_S_VS_VP_L_C_TRANSMITBITRATE:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                    sizeof(uint32));

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

             /* Copy the value to allocated area */
             //sprintf((pxParamVal[iCnt]).Value, "%d", xLineCodec.unTxBitRate);
             sprintf((pxParamVal[iCnt]).Value, "%d", 0);
 
            break; 
          case OID_IGD_S_VS_VP_L_C_RECEIVEBITRATE:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                    sizeof(uint32));

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

               /* Copy the value to allocated area */
               //sprintf((pxParamVal[iCnt]).Value, "%d", xLineCodec.unRxBitRate);
               sprintf((pxParamVal[iCnt]).Value, "%d", 0);
 
            break; 
          case OID_IGD_S_VS_VP_L_C_TRANSMITSILENCESUPPRESSION:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              /*if(xLineCodec.bTxSilenceSupp == IFX_TR104_FALSE)
                strcpy((pxParamVal[iCnt]).Value, "false");
              else if(xLineCodec.bTxSilenceSupp == IFX_TR104_TRUE)
                strcpy((pxParamVal[iCnt]).Value, "true");*/
              strcpy((pxParamVal[iCnt]).Value, "false");

            break; 
          case OID_IGD_S_VS_VP_L_C_RECEIVESILENCESUPPRESSION:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              /*if(xLineCodec.bRxSilenceSupp == IFX_TR104_FALSE)
                strcpy((pxParamVal[iCnt]).Value, "false");
              else if(xLineCodec.bRxSilenceSupp == IFX_TR104_TRUE)
                strcpy((pxParamVal[iCnt]).Value, "true");*/
              strcpy((pxParamVal[iCnt]).Value, "false");

            break; 
          case OID_IGD_S_VS_VP_L_C_TRANSMITPACKETIZATIONPERIOD:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                    sizeof(uint16));

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

               /* Copy the value to allocated area */
               //sprintf((pxParamVal[iCnt]).Value, "%d", xLineCodec.unFrameLen);
               sprintf((pxParamVal[iCnt]).Value, "%d", 0);
 
            break;
          default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                iTmpCnt = iCnt;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
            goto cleanup;
        }
    }

cleanup:

    if (iMemErrorFlag)
    {
        (pxParamVal[iCnt]).iFaultCode = ERR_OUT_OF_MEMORY;
        iRet = ERR_OUT_OF_MEMORY;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Allocation Failure\n",
                     __FILE__, __func__, __LINE__, iRet);
    }

    if (iRet != IFX_CWMP_SUCCESS)
    {

        /* Free the allocation for value, if any. Also set the fault code. */
        for (iCnt = 0; iCnt < iElements; iCnt++)
        {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
            if (iTmpCnt != iCnt) 
            {
                (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
            }
        }
    }

    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : Modify
**
**   Description      : This function modifies the values of parameters in 
**                      LineCodec object. It calls respective VMAPI for 
**                      the same. It performs modification only if parameter 
**                      has Write permission. In certain cases it also performs 
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet         = IFX_CWMP_SUCCESS;
    int32   iRtn         = IFX_SUCCESS;
    int32   iCnt         = 0;
    int32   iParamOffset;
    int32   iOID;
    x_IFX_VMAPI_LineCodec xLineCodec;
    uint32 uiPCpeId;

    /* NOTE: For all parameters fault code is set to success by default. If error in
       validating first parameter, fault code is set to the error type and other
       parameters are not validated. */

    /* Set the fault code to Success for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
    }

    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);

    memset(&xLineCodec, 0, sizeof(x_IFX_VMAPI_LineCodec));

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_L_C:{

            char8 sOidString[100] = {0};
            IFX_CpeId *pxCpeIdArray = NULL;
            unsigned int uiNumCpeId;

            /* Get the Parent CPE Id */
            IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT &uiPCpeId);
            xLineCodec.iid.pcpeId.Id = uiPCpeId;

            /*ignore the last value as it will be a parameter and we need 
              only till the last instance*/
            iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );

            strcpy(xLineCodec.iid.tr69Id,sOidString);

            /*Get the CPE Id from the corresponding tr69 Id */
            iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId,
                               OUT &pxCpeIdArray);
            if(iRet != IFX_CWMP_SUCCESS){
                   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                   __func__, __LINE__);

              return ERR_CWMP_INTERNAL;
            }
            //printf("CPEID is %d\n",pxCpeIdArray->uiId);   

            /* Fill the CPE ID of the object instance */
            xLineCodec.iid.cpeId.Id = pxCpeIdArray->uiId;
            xLineCodec.iid.config_owner = IFX_TR69;

            /* Get all the Voice Line Codec parameters using VMAPI */
            //iRtn = ifx_get_LineVoiceCodec(&xLineCodec, IFX_F_DEFAULT); 

            IFX_CWMP_FREE(pxCpeIdArray);

            /* Check for error */
            if (iRtn != IFX_CWMP_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to get values of all "
                            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto cleanup;
            }
            }
            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_S_VS_VP_L_C_TRANSMITCODEC:
            case OID_IGD_S_VS_VP_L_C_RECEIVECODEC:
            case OID_IGD_S_VS_VP_L_C_TRANSMITBITRATE:
            case OID_IGD_S_VS_VP_L_C_RECEIVEBITRATE:
            case OID_IGD_S_VS_VP_L_C_TRANSMITSILENCESUPPRESSION:
            case OID_IGD_S_VS_VP_L_C_RECEIVESILENCESUPPRESSION:
            case OID_IGD_S_VS_VP_L_C_TRANSMITPACKETIZATIONPERIOD:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_PARAM_NOT_SUPPORTED;
                iRet = ERR_CWMP_PARAM_NOT_SUPPORTED;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Parameter Not Supported\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;  
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_L_C:

            /* Fill the iid structure in LINE_CODEC object */
            xLineCodec.iid.config_owner = IFX_TR69;

            /* Set all the LINE_CODEC  parameters using VMAPI */
            //iRtn = ifx_set_LineVoiceCodec(IFX_OP_MOD, &xLineCodec, IFX_F_DEFAULT);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to set values of all "
                            "parameters\n", __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
            }

            break;
        default:
            /* Will never come here since already checked above */
            break;
    }

cleanup:
    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : Validate
**
**   Description      : This function validates the values of parameters in
**                      LineCodec object.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      validated.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When validation of all parameters is
**                      successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in validating at least one parameter.
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : GetModifyDep
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
GetModifyDep(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    return (IFX_CWMP_SUCCESS);
}

/* 
** =============================================================================
**   Function Name    : IFX_LineCodec_ChkDelDep
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_LineCodec_ChkDelDep(IN int32 iCaller, IN ParamVal *pxParamVal,
              IN int32 iNumElem, OUT void **ppxParamStructRet,
                           OUT int32 * piNumRetElem)
{

    uint32 i=0;
    int32 iRet=0;
    uint32 uiParamPos=0;
    ParamVal *Param_DepOids=NULL;

    int32 codec_list_OID[OID_LENGTH] = {0,0,0,0,0,0,0,0,OID_IGD_S_VS_VP_L_C,OID_IGD_S_VS_VP_L_C_L,
                                    MAGIC_NUMBER};

    Param_DepOids = IFIN_CWMP_MALLOC((CODEC_NO_DEP_OIDS+1)* sizeof(ParamVal));
    if(Param_DepOids == NULL){    
      iRet = ERR_OUT_OF_MEMORY; 
        goto errorHandler;
    }

    uiParamPos = IFX_GetParamIdPos(pxParamVal->iaOID);
            
    memcpy((Param_DepOids+0)->iaOID,codec_list_OID,(sizeof(int32)*OID_LENGTH));
    memcpy((Param_DepOids+1)->iaOID,pxParamVal->iaOID,
                                (sizeof(int32)*(uiParamPos+1)));

    for(i=0; i <CODEC_NO_DEP_OIDS; ++i)
        memcpy((Param_DepOids+i)->iaOID,pxParamVal->iaOID,
                        (sizeof(int32)*(uiParamPos+1)));
        *ppxParamStructRet = (void *)Param_DepOids;
        *piNumRetElem = CODEC_NO_DEP_OIDS+1;
        return IFIN_CWMP_SUCCESS;
    
  errorHandler:
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed!\n", __func__, __LINE__);
        
        return IFIN_CWMP_FAILURE;
        

}

/* 
** =============================================================================
**   Function Name    : IFX_LineCodec_AddDel
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_LineCodec_AddDel(IN int32 iCaller, IN ParamVal *pxParamVal, 
               IN int32 iNumElem, IN int32 operation)
{
    int32   iRet = IFIN_CWMP_SUCCESS;
    int32   iCnt = 0;
    int32 iInst =0;
    char sOidString[IFX_MAX_TR69_ID_LEN];
    char sOidStringList[IFX_MAX_TR69_ID_LEN];
    int32   iParamOffset;
    IFX_CpeId *pxCpeIdArray = NULL;
    unsigned int uiNumCpeId;
    unsigned int uiPCpeId;
    x_IFX_VMAPI_LineCodec xLineCodec;
  
    x_IFX_VMAPI_VoiceCodecCapabilities xVoiceCodec;
    //x_IFX_VMAPI_CodecDesc  xCodecEntry;
    //x_IFX_VMAPI_CodecDesc  *pxTemp;
    
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                "[%s:%d] \n", __func__, __LINE__);

    
    memset(sOidString,0x00,IFX_MAX_TR69_ID_LEN);
    memset(&xLineCodec,0,sizeof(xLineCodec));

    /* Get the Parent CPE Id */
    IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT &uiPCpeId);
    xLineCodec.iid.pcpeId.Id = uiPCpeId;

    iInst = IFX_GetLineInstanceId(pxParamVal->iaOID);
    
    /* if neither delete nor add operation */ 
    if((operation != OP_SETVAL_ADD)&&(operation != OP_SETVAL_DELETE)){ 
          IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] Invalid operation\n",
                   __func__, __LINE__);
      return ERR_CWMP_INTERNAL;
    }    
   
    /* Get the Firmware supported Voice Codec capabilities list. The same
       would be populated for Line also */
    memset(&xVoiceCodec,0,sizeof(xVoiceCodec));
    xVoiceCodec.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_get_VoiceCodecCaps(&xVoiceCodec, 0))
    {
       IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
             "[%s:%d] [Error] ifx_get_VoiceCodecCaps failed\n", 
              __func__, __LINE__);
      return IFX_VMAPI_FAIL;
    }
    ifx_vmapi_freeObjectList(&xVoiceCodec,IFX_VMAPI_CODEC_CAPABS);
    g_Supported_Codecs = xVoiceCodec.uiNumCodecs;

    /* if delete operation */
    if(operation == OP_SETVAL_DELETE){ 
      // get cpeid, pass to delete function
      // here the input iaOID will be igd.s.vs.1.vp.1.l.2.
      
      xLineCodec.ucLineId = IFX_GetLineId(pxParamVal->iaOID); 

      /*ignore the last value as it will be a parameter and we need 
               only till the last instance*/
      iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );

      iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId, OUT &pxCpeIdArray);
      if(iRet != IFX_CWMP_SUCCESS){
              IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                      "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                      __func__, __LINE__);

        return ERR_CWMP_INTERNAL;
      }
    
      xLineCodec.iid.cpeId.Id = pxCpeIdArray->uiId;

      memset(xLineCodec.iid.tr69Id,0x00,MAX_TR69_ID_LEN);
    
      if(strlen(pxCpeIdArray->sSectionTag) < MAX_TAG_LEN){
        strncpy(xLineCodec.iid.cpeId.secName,pxCpeIdArray->sSectionTag, MAX_TAG_LEN-1);
        IFX_CWMP_FREE(pxCpeIdArray);
      }else{
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] strcpy : mismatch in size in buffer copy\n",
                    __func__, __LINE__);
        IFX_CWMP_FREE(pxCpeIdArray);
        return ERR_CWMP_INTERNAL;
      }
    
      /* Fill the iid structure in VOICE_LINE */
      xLineCodec.iid.config_owner = IFX_TR69;

      strncpy(xLineCodec.iid.tr69Id,sOidString, MAX_TR69_ID_LEN-1);
      xLineCodec.iid.tr69Id[MAX_TR69_ID_LEN-1] = '\0';
      //printf("========= OID is %s==============\n",sOidString);

      /* call the respective VMAPI */
      iRet = ifx_set_LineVoiceCodec( IFX_OP_DEL, &xLineCodec, IFX_F_DELETE | 
                      IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH); 
      if(iRet != IFX_CWMP_SUCCESS){
             IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [Error] ifx_set_LineVoiceCodec failed\n",
                    __func__, __LINE__);
        return ERR_CWMP_INTERNAL;
      }

      return iRet;

    }// end of delete operation

    if(operation == OP_SETVAL_ADD){  // if ADD
      // ADD operation
      // here the input iaOID will be igd.s.vs.1.vp.1.l.2.
    
      /*ignore the last value as it will be a parameter and we need 
                only till the last instance*/
      iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID,sOidString);
      strncpy(xLineCodec.iid.tr69Id,sOidString, MAX_TR69_ID_LEN-1);
      xLineCodec.iid.tr69Id[MAX_TR69_ID_LEN-1] = '\0';

      /* Get the offset of the parameter */
      iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
      if (iParamOffset < 0)
      {
          iRet = ERR_CWMP_INTERNAL;
          IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
          goto cleanup;
      }

      // fill the given parameters of this structure with the new values provided
      for( iCnt = 0; iCnt < iNumElem; iCnt++){

          /* Process based on the requested parameter */
          switch (pxParamVal[iCnt].iaOID[iParamOffset])
          {
            
            case OID_IGD_S_VS_VP_L_C_TRANSMITCODEC:
            case OID_IGD_S_VS_VP_L_C_RECEIVECODEC:
            case OID_IGD_S_VS_VP_L_C_TRANSMITBITRATE:
            case OID_IGD_S_VS_VP_L_C_RECEIVEBITRATE:
            case OID_IGD_S_VS_VP_L_C_TRANSMITSILENCESUPPRESSION:
            case OID_IGD_S_VS_VP_L_C_RECEIVESILENCESUPPRESSION:
            case OID_IGD_S_VS_VP_L_C_TRANSMITPACKETIZATIONPERIOD:
              break;  
           default:
               IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           "[%s:%d] [Error] Unknown requested parameter\n",
                              __func__, __LINE__);
             // parameter not found
             pxParamVal[iCnt].iFaultCode = ERR_INVAL_PARAMETER_NAME;

             goto cleanup;
          }
      } 

      /* Fill the iid structure in VOICE_LINE */
      xLineCodec.iid.config_owner = IFX_TR69;

      // call the VMAPI to modify
      iRet = ifx_set_LineVoiceCodec( IFX_OP_ADD, &xLineCodec, IFX_F_DEFAULT); 
      if(iRet != IFX_CWMP_SUCCESS){
             IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] ifx_set_LineVoiceCodec adding failed\n", 
                     __func__, __LINE__);
        iRet = ERR_CWMP_INTERNAL;
        goto cleanup;
      }
      
      memset(sOidStringList,0x00,IFX_MAX_TR69_ID_LEN);
      sprintf(sOidStringList ,
              "InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.1.Line.%d.Codec.List.", iInst);
      iCnt=0;
      for(iCnt =0 ; iCnt<xVoiceCodec.uiNumCodecs ; iCnt++)
      {
        IFX_ContAddObj(ACC_ROOT, sOidStringList);
      }

      return iRet;
    }

cleanup:

    /* Perform Cleanup of unnecessary LineSignaling members */

    return (iRet);

}

/* 
** =============================================================================
**   Function Name    : IFX_LineCodec_UpdateChildInfo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32 
IFX_LineCodec_UpdateChildInfo(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
              IN int32 iElements,IN int32 operation)
{
    return IFX_CWMP_SUCCESS;
    int32   iRtn         = IFX_SUCCESS;
    uint32 iRet, iCnt;
    int32   iOID;
    uint32 uiPCpeId;
    uint32 uiNumCpeId;
    x_IFX_VMAPI_LineCodecList xCodecList;
    x_IFX_VMAPI_LineCodec xLineCodec;


    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                "[%s:%d] \n", __func__, __LINE__);
    
    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);

    memset(&xCodecList, 0, sizeof(x_IFX_VMAPI_LineCodecList));
    memset(&xLineCodec, 0, sizeof(x_IFX_VMAPI_LineCodec));

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_L_C:{

            char8 sOidString[100] = {0};
            IFX_CpeId *pxCpeIdArray = NULL;

            /* Get the Parent CPE Id */
            IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT &uiPCpeId);
            xCodecList.iid.pcpeId.Id = uiPCpeId;
            //xLineCodec.iid.pcpeId.Id = uiPCpeId;
            
            /*ignore the last value as it will be a parameter and we need 
              only till the last instance*/
            iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );

            iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId, OUT &pxCpeIdArray);
            if(iRet != IFX_CWMP_SUCCESS){
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                          "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                          __func__, __LINE__);

              return ERR_CWMP_INTERNAL;
            }
    
            xCodecList.iid.cpeId.Id = pxCpeIdArray->uiId;
            //xLineCodec.iid.cpeId.Id = pxCpeIdArray->uiId;


            //strcpy(xLineCodec.iid.tr69Id,sOidString);
            strcpy(xCodecList.iid.tr69Id,sOidString);
            printf("[%s %d]TR69ID received %s\n",__FUNCTION__, __LINE__, sOidString);

            //xLineCodec.iid.config_owner = IFX_TR69;
            xCodecList.iid.config_owner = IFX_TR69;

            /* Get all the LineEvent parameters using VMAPI */
            iRtn = ifx_get_LineCodecList_All(&xCodecList,IFX_F_DEFAULT);

            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                   "[%s:%d] Number after GET %d \n", __func__, __LINE__ , xCodecList.uiNumCodecs);

            IFX_CWMP_FREE(pxCpeIdArray);

            /* Check for error */
            if (iRtn != IFX_CWMP_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to get values of all "
                            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                //goto cleanup;
                goto errorHandler;
            }
            }
            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            //goto cleanup;
            goto errorHandler;
    }

   
       {
            if(operation == OP_SETVAL_ADD)
            {
              xCodecList.uiNumCodecs++;
            }
            else
              xCodecList.uiNumCodecs -= 1;
        }

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_L_C:

            /* Fill the iid structure in LINE_EVENT */
            xCodecList.iid.config_owner = IFX_TR69;
            
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                   "[%s:%d] Number is %d \n", __func__, __LINE__ , xCodecList.uiNumCodecs);

            /* Set all the LINE_EVENT  parameters using VMAPI */
            iRtn = ifx_set_LineCodecList(IFX_OP_MOD,&xCodecList,IFX_F_DEFAULT);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to set values of all "
                            "parameters in UpdateChildInfo\n", 
                            __FILE__, __func__, __LINE__, iRet);
                goto errorHandler;
            }
            
            ifx_vmapi_freeObjectList(&xCodecList,IFX_VMAPI_VL_CODECLIST);

            break;
        default:
            /* Will never come here since already checked above */
            break;
    }
    return IFX_CWMP_SUCCESS;

errorHandler:
      IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d failed!\n", __func__, __LINE__);
      return IFX_CWMP_FAILURE;
}



/* 
** =============================================================================
**   Function Name    : GetNotify
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
GetNotify(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
                 IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : SetAttrInfo
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
  int32 iRet,i;
  iRet = IFX_SetAttributesInfo(pxOI, pxParamVal, iElements);
  if(iRet != IFX_CWMP_SUCCESS)
      goto errorHandler;

  for(i=0; i < iElements; i++)
    IFX_CWMP_FREE(pxParamVal->Value);

  return IFX_CWMP_SUCCESS;

  errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d failed!\n", __func__, __LINE__);
    return iRet;
}

/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : IFX_LineCodec_Init
**
**   Description      : This function is called by the controller. It registers
**                      the function responsible for handling LineCodec object
**                      with data structure. It also performs initializations
**                      specific to LineCodec object.
**
**   Parameters       : No Parameters. 
**
**   Return Value     : IFX_CWMP_SUCCESS - When LineCodec object is initialized
**                      successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in initializing VoiceLine object.
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_LineCodec_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the VoiceLine module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_LINECODEC_OBJ, IFX_LineCodec);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_LINECODEC_OBJ);
        goto cleanup;
    }

cleanup:
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_LineCodec
**
**   Description      : This function is called by the controller. It handles
**                      the LineCodec object and performs  based on requested
**                      operations/suboperations by invoking internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_LineCodec(IN OperInfo *pxOI, INOUT void *pParamList, 
              IN int32 iNumElem,OUT void **ppRet, 
              OUT int32 *piNumRetElem)
{
    int32       iRet           = IFX_CWMP_SUCCESS;
    ParamVal    *pxParamVal    = (ParamVal *)pParamList;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                "[%s:%d] \n", __func__, __LINE__);
    /* Process based on type of Operation */
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:

                    /* Get values of all the requested parameters */
                    iRet = GetVal(pxOI->iCaller, pxParamVal,
                                               iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_GETVAL_NOTIFICATION:

                    /* Set attribute values for all the requested parameters */
                    iRet = GetNotify(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_SETVAL:
        {
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:

                    /* Validate values of all the requested parameters */
                    iRet = Validate(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:

                   /* Check modify dependency of all requested parameters */
                    iRet = GetModifyDep(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_MODIFY:

                    /* Set values of all the requested parameters */
                    iRet = Modify(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ATTRINFO:

                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_ADD:
                    iRet = IFX_LineCodec_AddDel(pxOI->iCaller,pxParamVal, 
                              iNumElem, OP_SETVAL_ADD); // 1 = add 0=del

                    /* Check for error */
                    if (iRet != IFIN_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }


                   break;
                case OP_SETVAL_CHK_DEL_DEP:

                   iRet = IFX_LineCodec_ChkDelDep(pxOI->iCaller, pxParamVal,
                                                  iNumElem, ppRet, piNumRetElem);

                    /* Check for error */
                    if (iRet != IFIN_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                   break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                
                    return IFX_CWMP_SUCCESS;
                   break;
                case OP_SETVAL_DELETE:
                    iRet = IFX_LineCodec_AddDel(pxOI->iCaller,pxParamVal, 
                              iNumElem, OP_SETVAL_DELETE); // 1 = add 0=del

                    /* Check for error */
                    if (iRet != IFIN_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }
                   break;

                case OP_SETVAL_FREE:
                    return IFX_CWMP_SUCCESS;
                   break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD: 

                    if((iRet =IFX_LineCodec_UpdateChildInfo(pxOI,pxParamVal,
                                       iNumElem,OP_SETVAL_ADD)) != IFX_CWMP_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d OP_UPDATE_CHILDINFO_ADD failed!\n", __func__, __LINE__);
                        goto cleanup;

                    }
                  break;
                case OP_UPDATE_CHILDINFO_DEL:
                    if((iRet =IFX_LineCodec_UpdateChildInfo(pxOI,pxParamVal,
                                   iNumElem,OP_SETVAL_DELETE)) != IFX_CWMP_SUCCESS)
                    {
                         IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                     "%s:%d OP_UPDATE_CHILDINFO_DEL failed!\n", __func__, __LINE__);
                         goto cleanup;

                    }

                  break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
        {
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid Operation\n",
                         __func__, __LINE__, iRet);
            goto cleanup;
        }
    }

cleanup:
    return (iRet);
}
