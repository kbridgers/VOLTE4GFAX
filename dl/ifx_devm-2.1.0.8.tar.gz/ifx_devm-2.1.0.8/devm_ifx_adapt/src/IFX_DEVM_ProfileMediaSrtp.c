/* 
** =============================================================================
**   FILE NAME        : IFX_ProfileMediaSrtp
**   PROJECT          : TR104
**   MODULES          : IFX_ProfileMediaSrtp
**   DATE             : 27-10-2006
**   AUTHOR           : TR104 team
**   DESCRIPTION   :

**   REFERENCES      : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2004
**                   	      Infineon Technologies AG, st. Martin Strasse 53;
**                   	      81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/


/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_VoiceLine.h"
  // Required for STATIC
 
#include "IFX_DEVM_OID.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_DS.h"

//#include "ifx_voip_defs.h"
//#include "ifx_cm.h"
//#include "ifx_vmapi1.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

int32
IFX_ProfileMediaSrtp(IN OperInfo * pxOI, INOUT void *pParamList,
                     IN int32 iNumElem, OUT void **ppRet,
                     OUT int32 * piNumRetElem);

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFX_PROFILEMEDIASRTP_OBJ "InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.1.RTP.SRTP."


/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/
STATIC int32
GetVal(IN int32 iCaller, INOUT ParamVal *pxParamVal,
                    IN int32 iElements);
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
GetModifyDep(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
GetNotify(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
                 IN int32 iElements);
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);
/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/

/* 
** =============================================================================
**   Function Name    : IFX_GetParamOID
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32 ifx_get_ProfileMediaSrtp(x_IFX_VMAPI_ProfileMediaSecurity *pxProfMediaSrtp, 
                    uint32 flags)
{
  return IFX_SUCCESS;
}

int32 
ifx_set_ProfileMediaSrtp(int32 operation, 
                    x_IFX_VMAPI_ProfileMediaSecurity *pxProfMediaSrtp, 
                    uint32 flags)
{
    return IFX_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetVal(IN int32 iCaller, INOUT ParamVal *pxParamVal,
                    IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iRtn = IFX_SUCCESS;
    int32   iCnt = 0;
    int32   iTmpCnt = -1; /* Mandatory */
    int32   iParamOffset;
    int32   iOID;
    char8   sTmpTime[12]; /* Max uint32 size */
    int32   iMemErrorFlag = 0; /* Mandatory */
    x_IFX_VMAPI_ProfileMediaSecurity xProfMediaSrtp;

    /* NOTE: For all parameters fault code is set to success by default. If error in
       validating first parameter, fault code is set to the error type and other
       parameters are not validated. */
    /* NOTE: For all parameters value is set to NULL by default. */

    /* Set the fault code to Success and value to NULL pointer for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);

    memset(&xProfMediaSrtp, 0, sizeof(x_IFX_VMAPI_ProfileMediaSecurity));

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_RTP_SRTP:

            /* Fill the iid structure in x_IFX_VMAPI_ProfileMediaSecurity */

            /* Get all the VoiceLine parameters using Protocol API */
            iRtn = ifx_get_ProfileMediaSrtp(&xProfMediaSrtp, IFX_F_DEFAULT);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to get values of all "
                            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto cleanup;
            }

            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
          case OID_IGD_S_VS_VP_RTP_SRTP_ENABLE:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(9);
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              if(xProfMediaSrtp.bEnableSrtp == IFX_TR104_TRUE)
                strcpy((pxParamVal[iCnt]).Value, "Enabled");
              else if(xProfMediaSrtp.bEnableSrtp == IFX_TR104_FALSE)
                strcpy((pxParamVal[iCnt]).Value, "Disabled");
              
            break;
          case OID_IGD_S_VS_VP_RTP_SRTP_KEYINGMETHOD:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                    sizeof(uint32));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              (pxParamVal[iCnt]).Value = xProfMediaSrtp.ucSrtpKeyingMethod;
              
            break;
          case OID_IGD_S_VS_VP_RTP_SRTP_ENCRYPTKEYSIZE:
#if 0
            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                    sizeof(xProfMediaSrtp.acCName));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              strcpy((pxParamVal[iCnt]).Value , xProfMediaSrtp.acCName);
#endif         
            break;
          default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                iTmpCnt = iCnt;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
            goto cleanup;
        }
    }

cleanup:

    if (iMemErrorFlag)
    {
        (pxParamVal[iCnt]).iFaultCode = ERR_OUT_OF_MEMORY;
        iRet = ERR_OUT_OF_MEMORY;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Allocation Failure\n",
                     __FILE__, __func__, __LINE__, iRet);
    }

    if (iRet != IFX_CWMP_SUCCESS)
    {

        /* Free the allocation for value, if any. Also set the fault code. */
        for (iCnt = 0; iCnt < iElements; iCnt++)
        {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
            if (iTmpCnt != iCnt) 
            {
                (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
            }
        }
    }

    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : Modify
**
**   Description      : This function modifies the values of parameters in 
**                      DeviceInfo object. It calls respective Management API  
**                      for the same. It performs modification only if parameter 
**                      has Write permission. In certain cases it also performs 
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet         = IFX_CWMP_SUCCESS;
    int32   iRtn         = IFX_SUCCESS;
    int32   iCnt         = 0;
    int32   iParamOffset;
    int32   iOID;
    x_IFX_VMAPI_ProfileMediaSecurity xProfMediaSrtp;

    /* NOTE: For all parameters fault code is set to success by default. If error in
       validating first parameter, fault code is set to the error type and other
       parameters are not validated. */

    /* Set the fault code to Success for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
    }

    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);

    memset(&xProfMediaSrtp, 0, sizeof(x_IFX_VMAPI_ProfileMediaSecurity));

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_RTP_SRTP:

            /* Fill the iid structure in DEVICE_INFO */

            /* Get all the Voice Line parameters using Object API */
            iRtn = ifx_get_ProfileMediaSrtp(&xProfMediaSrtp, IFX_F_DEFAULT);

            /* Check for error */
            if (iRtn != IFX_CWMP_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to get values of all "
                            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto cleanup;
            }

            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_S_VS_VP_RTP_SRTP_ENABLE:
              if(!strncasecmp(pxParamVal[iCnt].Value,"Enabled",7))
                  xProfMediaSrtp.bEnableSrtp = IFX_TR104_TRUE; 
              if(!strncasecmp(pxParamVal[iCnt].Value,"Disabled",8))
                  xProfMediaSrtp.bEnableSrtp = IFX_TR104_FALSE; 
              break;
            case OID_IGD_S_VS_VP_RTP_SRTP_KEYINGMETHOD:
                  xProfMediaSrtp.ucSrtpKeyingMethod = pxParamVal[iCnt].Value; 
              break;
            case OID_IGD_S_VS_VP_RTP_SRTP_ENCRYPTKEYSIZE:
                  //strcpy(xProfMediaSrtp.acCName , pxParamVal[iCnt].Value); 
              break;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_RTP_SRTP:

            /* Fill the iid structure in DEVICE_INFO */
            xProfMediaSrtp.iid.config_owner = IFX_TR69;

            /* Set all the VOICE_LINE  parameters using Object API */
            iRtn = ifx_set_ProfileMediaSrtp(IFX_OP_MOD, &xProfMediaSrtp, 
                                     IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT | 
                                     IFX_F_DONT_WRITE_TO_FLASH);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to set values of all "
                            "parameters\n", __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
            }

            break;
        default:
            /* Will never come here since already checked above */
            break;
    }

cleanup:
    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : Validate
**
**   Description      : This function validates the values of parameters in
**                      DeviceInfo object.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      validated.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When validation of all parameters is
**                      successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in validating at least one parameter.
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
#if 0
    int32   iCnt;
    int32   iParamOffset;
    int32   iI;
    int32   iLength;
    char8   *psTmpVal;

    /* NOTE: For all parameters fault code is set to success by default. If error in
       validating first parameter, fault code is set to the error type and other
       parameters are not validated. */

    /* NOTE: Currently validation is performed only for parameters that have write permission.
       Other parameters are simply ignored. I think this should be fine since those
       validations are performed by the controller */ 

    /* Set the fault code to Success for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);

    /* Iterate and validate the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Return a failure if the value is NULL pointer */
        if (!psTmpVal)
        {
            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
            iRet = ERR_CWMP_INVAL_PARAM_VAL;
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_DI_PROVISIONINGCODE:
                /* NOTE: Currently empty string is successfully passed */
                /* Get the length of the string */
                iLength = strlen(psTmpVal);

                for (iI = 0; iI < iLength; iI += 5)
                {
                    if (((iI + 4) <= iLength) &&
                        (isdigit(psTmpVal[iI + 0]) ||
                         isupper(psTmpVal[iI + 0])) &&
                        (isdigit(psTmpVal[iI + 1]) ||
                         isupper(psTmpVal[iI + 1])) &&
                        (isdigit(psTmpVal[iI + 2]) ||
                         isupper(psTmpVal[iI + 2])) &&
                        (isdigit(psTmpVal[iI + 3]) ||
                         isupper(psTmpVal[iI + 3])))
                    {
                        if ((iI + 4) < iLength)
                        {
                            if(psTmpVal[iI + 4] == '.')
                            {
                                if ((iI + 5) != iLength)
                                {
                                    continue;
                                }
                                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                                iRet = ERR_CWMP_INVAL_PARAM_VAL;
                                goto cleanup;
                            }
                            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                            iRet = ERR_CWMP_INVAL_PARAM_VAL;
                            goto cleanup;
                        }
                        continue;
                    }
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    iRet = ERR_CWMP_INVAL_PARAM_VAL;
                    goto cleanup;
                }
                break;
            case OID_IGD_DI_MANUFACTURER:
            case OID_IGD_DI_MANUFACTUREROUI:
            case OID_IGD_DI_MODELNAME:
            case OID_IGD_DI_DESCRIPTION:
            case OID_IGD_DI_PRODUCTCLASS:
            case OID_IGD_DI_SERIALNUMBER:
            case OID_IGD_DI_HARDWAREVERSION:
            case OID_IGD_DI_SOFTWAREVERSION:
            case OID_IGD_DI_MODEMFIRMWAREVERSION:
            case OID_IGD_DI_SPECVERSION:
            case OID_IGD_DI_UPTIME:
            case OID_IGD_DI_DEVICELOG:
                /* RO params - Not validating. just returtning success */
                break;
            case OID_IGD_DI_ENABLEDOPTIONS:
            case OID_IGD_DI_ADDITIONALHARDWAREVERSION:
            case OID_IGD_DI_ADDITIONALSOFTWAREVERSION:
            case OID_IGD_DI_FIRSTUSEDATE:
            case OID_IGD_DI_VENDORCONFIGFILENUMBEROFENTRIES:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_PARAM_NOT_SUPPORTED;
                iRet = ERR_CWMP_PARAM_NOT_SUPPORTED;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Parameter Not Supported\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;  
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

cleanup:
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Validating requested parameter failed\n",
                    __FILE__, __func__, __LINE__, iRet);
    }
#endif
    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : GetModifyDep
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
GetModifyDep(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    return (IFX_CWMP_SUCCESS);
}

/* 
** =============================================================================
**   Function Name    : GetNotify
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
GetNotify(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
                 IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
#if 0
    int32   iRtn = IFX_SUCCESS;
    int32   iCnt = 0;
    int32   iTmpCnt = -1; /* Mandatory */
    DEVICE_INFO xDI;
    int32   iParamOffset;
    int32   iOID;
    char8   sTmpTime[12]; /* Max uint32 size */
    int32   iMemErrorFlag = 0; /* Mandatory */

    /* NOTE: For all parameters fault code is set to success by default. If error in
       validating first parameter, fault code is set to the error type and other
       parameters are not validated. */
    /* NOTE: For all parameters value is set to NULL by default. */

    /* Set the fault code to Success and value to NULL pointer for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);

    memset(&xDI, 0, sizeof(DEVICE_INFO));

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_DI:

            /* Fill the iid structure in DEVICE_INFO */

            /* Get all the DEVICE_INFO parameters using Protocol API */
            iRtn = ifx_get_device_info(&xDI, IFX_F_DEFAULT);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to get values of all "
                            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto cleanup;
            }

            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_DI_MANUFACTURER:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(strlen(xDI.manufacturer) + 1);

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xDI.manufacturer); 

                iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if (iRet != IFX_CWMP_SUCCESS)
                {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;  
            case OID_IGD_DI_MANUFACTUREROUI:  

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(strlen(xDI.oui) + 1);

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xDI.oui); 

                iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if (iRet != IFX_CWMP_SUCCESS)
                {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;  
            case OID_IGD_DI_MODELNAME:  

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(strlen(xDI.model_name) + 1);

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xDI.model_name); 

                iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if (iRet != IFX_CWMP_SUCCESS)
                {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;  
            case OID_IGD_DI_DESCRIPTION:  

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(strlen(xDI.description) + 1);

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xDI.description); 

                iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if (iRet != IFX_CWMP_SUCCESS)
                {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;  
            case OID_IGD_DI_PRODUCTCLASS:  

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(strlen(xDI.product_class) + 1);

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xDI.product_class); 

                iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if (iRet != IFX_CWMP_SUCCESS)
                {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;  
            case OID_IGD_DI_SERIALNUMBER:  

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(strlen(xDI.serial_number) + 1);

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xDI.serial_number); 

                iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if (iRet != IFX_CWMP_SUCCESS)
                {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;  
            case OID_IGD_DI_HARDWAREVERSION:  

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(strlen(xDI.hw_ver) + 1);

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xDI.hw_ver); 

                iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if (iRet != IFX_CWMP_SUCCESS)
                {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;  
            case OID_IGD_DI_SOFTWAREVERSION:  

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(strlen(xDI.sw_ver) + 1);

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xDI.sw_ver); 

                iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_VALUE_BASED);

                /* Check for error */
                if (iRet != IFX_CWMP_SUCCESS)
                {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;  
            case OID_IGD_DI_MODEMFIRMWAREVERSION:  

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(strlen(xDI.fw_ver) + 1);

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xDI.fw_ver); 

                iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_VALUE_BASED);

                /* Check for error */
                if (iRet != IFX_CWMP_SUCCESS)
                {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;  
            case OID_IGD_DI_SPECVERSION:  

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(strlen(xDI.igd_spec_ver) + 1);

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xDI.igd_spec_ver); 

                iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if (iRet != IFX_CWMP_SUCCESS)
                {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;  
            case OID_IGD_DI_PROVISIONINGCODE:  

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(strlen(xDI.provisioning_info) + 1);

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_OUT_OF_MEMORY;
                    iRet = ERR_OUT_OF_MEMORY;
                    iTmpCnt = iCnt;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Allocation Failure\n",
                                 __FILE__, __func__, __LINE__, iRet);
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xDI.provisioning_info); 
                break;  
            case OID_IGD_DI_UPTIME:  

                /* Assuming uptime is always changed */
                /* Get the time in string format */
                sprintf(sTmpTime,"%u",xDI.uptime);

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(strlen(sTmpTime) + 1);

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_OUT_OF_MEMORY;
                    iRet = ERR_OUT_OF_MEMORY;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, sTmpTime); 

                iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_VALUE_BASED);

                /* Check for error */
                if (iRet != IFX_CWMP_SUCCESS)
                {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;  
            case OID_IGD_DI_DEVICELOG:

                /* Assuming device log is always changed */
                iRtn = ifx_get_syslog_msg(0, NULL,(char **) &((pxParamVal[iCnt]).Value), 0);

                /* Check for error */
                if (iRtn != IFX_SUCCESS)
                {
                    /* Assuming memory error, Set the memory error flag */
                    (pxParamVal[iCnt]).iFaultCode = ERR_OUT_OF_MEMORY;
                    iRet = ERR_OUT_OF_MEMORY;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                break;  
            case OID_IGD_DI_ENABLEDOPTIONS:
            case OID_IGD_DI_ADDITIONALHARDWAREVERSION:
            case OID_IGD_DI_ADDITIONALSOFTWAREVERSION:
            case OID_IGD_DI_FIRSTUSEDATE:
            case OID_IGD_DI_VENDORCONFIGFILENUMBEROFENTRIES:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_PARAM_NOT_SUPPORTED;
                iRet = ERR_CWMP_PARAM_NOT_SUPPORTED;
                iTmpCnt = iCnt;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Parameter Not Supported\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;  
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                iTmpCnt = iCnt;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
                goto cleanup;
        }
    }

cleanup:

    if (iMemErrorFlag)
    {
        (pxParamVal[iCnt]).iFaultCode = ERR_OUT_OF_MEMORY;
        iRet = ERR_OUT_OF_MEMORY;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Allocation Failure\n",
                     __FILE__, __func__, __LINE__, iRet);
    }

    if (iRet != IFX_CWMP_SUCCESS)
    {

        /* Free the allocation for value, if any. Also set the fault code. */
        for (iCnt = 0; iCnt < iElements; iCnt++)
        {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
            if (iTmpCnt != iCnt) 
            {
                (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
            }
        }
    }
#endif
    return (iRet);
}

STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
  int32 iRet,i;
  iRet = IFX_SetAttributesInfo(pxOI, pxParamVal, iElements);
    if(iRet != IFX_CWMP_SUCCESS)
      goto errorHandler;

  for(i=0; i < iElements; i++)
    IFX_CWMP_FREE(pxParamVal->Value);

  return IFX_CWMP_SUCCESS;

  errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d failed!\n", __func__, __LINE__);
    return iRet;
}


/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : IFX_ProfileMediaSrtp_Init
**
**   Description      : This function is called by the controller. It registers
**                      the function responsible for handling VoiceLine object
**                      with data structure. It also performs initializations
**                      specific to VoiceLine object.
**
**   Parameters       : No Parameters. 
**
**   Return Value     : IFX_CWMP_SUCCESS - When VoiceLine object is initialized
**                      successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in initializing VoiceLine object.
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_ProfileMediaSrtp_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the VoiceLine module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_PROFILEMEDIASRTP_OBJ, IFX_ProfileMediaSrtp);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_PROFILEMEDIASRTP_OBJ);
        goto cleanup;
    }

cleanup:
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_ProfileMediaSrtp
**
**   Description      : This function is called by the controller. It handles
**                      the VoiceLine object and performs  based on requested
**                      operations/suboperations by invoking internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_ProfileMediaSrtp(IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
             OUT void **ppRet, OUT int32 *piNumRetElem)
{
    int32       iRet           = IFX_CWMP_SUCCESS;
    ParamVal    *pxParamVal    = (ParamVal *)pParamList;

    /* Process based on type of Operation */
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:

                    /* Get values of all the requested parameters */
                    iRet = GetVal(pxOI->iCaller, pxParamVal,
                                               iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_GETVAL_NOTIFICATION:

                    /* Set attribute values for all the requested parameters */
                    iRet = GetNotify(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_SETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:

                    /* Validate values of all the requested parameters */
                    iRet = Validate(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:

                   /* Check modify dependency of all requested parameters */
                    iRet = GetModifyDep(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_MODIFY:

                    /* Set values of all the requested parameters */
                    iRet = Modify(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ATTRINFO:

                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_FREE:
                case OP_SETVAL_ADD:
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
                case OP_SETVAL_DELETE:
                break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_UPDATE_CHILDINFO:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD: 
                case OP_UPDATE_CHILDINFO_DEL: 
                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid Operation\n",
                         __func__, __LINE__, iRet);
            goto cleanup;
    }

cleanup:
    return (iRet);
}
