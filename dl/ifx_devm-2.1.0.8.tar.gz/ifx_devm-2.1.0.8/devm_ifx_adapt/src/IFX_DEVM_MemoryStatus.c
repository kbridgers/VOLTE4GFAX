/*
 * ** =============================================================================
 * ** FILE NAME   : IFX_DEVM_MemoryStatus.c
 * ** PROJECT     : TR157
 * ** MODULES     : (InternetGateway) Device.DeviceInfo.MemoryStatus.
 * ** DATE        :
 * ** AUTHOR      : TR157 team
 * ** DESCRIPTION : AddObject / DeleteObject cannot be performed on this object.
 * **
 * ** REFERENCES  :
 * ** COPYRIGHT   : Copyright (c) 2006
 * **               Infineon Technologies AG
 * **               Am Campeon 1-12, 85579 Neubiberg, Germany
 * **
 * ** Any use of this software is subject to the conclusion of a respective
 * ** License agreement. Without such a License agreement no rights to the
 * ** software are granted
 * **
 * ** HISTORY     :
 * ** $Date       $Author        $Comment
 * **             TR157 team      Creation
 * ** =============================================================================
 * */


#include "IFX_DEVM_Global.h"

#include "IFX_DEVM_AdaptCommon.h"


#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_StackUtil.h"
#include <resolv.h>

extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char *obj, modFunc pifx_module_func);

#define MEMORYSTATUS_OBJ                      FORMNAME("DeviceInfo.MemoryStatus.")
#define MEMORYSTATUS_DEPTH                    4



/*******************************************************************************
 * * Function: IFX_MemoryStatusGetNotifyValue
 * * Desc: 
 * *              
 * * Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
static int32
IFX_MemoryStatusGetNotifyValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                             IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    

	MEMORYSTATUS xMemStat;

    memset(&xMemStat, '\0', sizeof(xMemStat));
    iRet = ifx_get_memorystatus(&xMemStat);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_memorystatus() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
    for(iI = 0; iI < iElements; iI++) {
        pxPV[iI].Value = IFX_CWMP_MALLOC(257);
        if(pxPV[iI].Value == NULL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", _FUNCL_);
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (pxPV[iI].iaOID[MEMORYSTATUS_DEPTH - 1]) {
            case OID_IGD_DI_MS_TOTAL:
                sprintf(pxPV[iI].Value , "%lu" , xMemStat.total_mem);
                break;
			case OID_IGD_DI_MS_FREE:
                sprintf(pxPV[iI].Value , "%lu" , xMemStat.free_mem);
                break;
			default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", _FUNCL_,
                            pxPV[iI].iaOID[MEMORYSTATUS_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}



 /*******************************************************************************
 * * Function: IFX_MemoryStatus
 * * Desc: 
 * *              
 * * Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
 * *             OUT void **ppRet, OUT int32 * piNumRetElem
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
int32
IFX_MemoryStatus(IN OperInfo * pxOI,
                      INOUT void *pParamStruct,
                      IN int32 iElements, OUT void **ppRet,
                      OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;

    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:

                    iRet = IFX_MemoryStatusGetNotifyValue(pxOI, xpParamVal,
                                                        iElements);
                    if(iRet != IFX_CWMP_SUCCESS) {
						IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d IFX_MemoryStatusGetNotifyValue failed.\n", _FUNCL_);
                        goto errorHandler;
					}
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                                pxOI->iSubOper);
                    break;
            }
            break;
        }
		case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
					iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
					break;
                case OP_SETVAL_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                case OP_SETVAL_CHK_MODIFY_DEP:
					iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;	
                    break;
                case OP_SETVAL_MODIFY:
					iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_ACTIVATE:
					iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;	
					break;
                case OP_SETVAL_COMMIT:
					iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_UNDO:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
			    case OP_SETVAL_DELETE:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
					iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;	
                    break;
                case OP_SETVAL_ATTRINFO:
					iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                                pxOI->iSubOper);
                    break;
            }
            break;
        }
		case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_UPDATE_CHILDINFO_DEL:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break;
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                        pxOI->iOper);
            break;
        }
    }
  errorHandler:
	if (iRet != IFX_CWMP_SUCCESS)
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d %s failed.\n", _FUNCL_, __func__);
    return iRet;
}


/*******************************************************************************
 * * Function: IFX_MemoryStatusInit                                  
 * * Desc: Will register itself with DS.
 * * Parameters:  
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
int32
IFX_MemoryStatusInit()
{
    int32 iRet = IFX_CWMP_SUCCESS;

    iRet = ifx_ds_register_function(MEMORYSTATUS_OBJ, IFX_MemoryStatus);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Unable to Register %s with Object Model\n",
                    _FUNCL_, iRet, MEMORYSTATUS_OBJ);
    }   
        
	return iRet;
}







