/*
 * ** =============================================================================
 * ** FILE NAME   : IFX_DEVM_X_LTQ_IPProtocolVersion.c
 * ** PROJECT     : TR69
 * ** MODULES     : (InternetGateway) Device.DeviceInfo.X_AC9A96_IPProtocolVersion.
 * ** DATE        :
 * ** AUTHOR      : TR69 team
 * ** DESCRIPTION : AddObject / DeleteObject cannot be performed on this object.
 * **
 * ** REFERENCES  :
 * ** COPYRIGHT   : Copyright (c) 2006
 * **               Infineon Technologies AG
 * **               Am Campeon 1-12, 85579 Neubiberg, Germany
 * **
 * ** Any use of this software is subject to the conclusion of a respective
 * ** License agreement. Without such a License agreement no rights to the
 * ** software are granted
 * **
 * ** HISTORY     :
 * ** $Date       $Author        $Comment
 * **             TR69 team      Creation
 * ** =============================================================================
 * */


#include "IFX_DEVM_Global.h"

#include "IFX_DEVM_AdaptCommon.h"


#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_StackUtil.h"
#include <resolv.h>

extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char *obj, modFunc pifx_module_func);

#define X_LTQ_IPPROTOCOLVERSION_OBJ                      FORMNAME("DeviceInfo.X_AC9A96_IPProtocolVersion.")
#define X_LTQ_IPPROTOCOLVERSION_DEPTH                    4




#define OID_IGD_DI_X_LTQ_IPPV_MODE				-4601

/*******************************************************************************
 * * Function: IFX_X_LTQ_IPProtocolVersionSetAttrInfo
 * * Desc: Sets attribute information in the respective tr69 sections
 * * Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
static int32
IFX_X_LTQ_IPProtocolVersionSetAttrInfo(IN int32 iCaller, INOUT ParamVal * pxPV,
                          IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    iRet = IFX_SetAttributesInfo(NULL, pxPV, iElements);

    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Updating Param Attribute Info failed\n",
                    _FUNCL_, iRet);
        goto errorHandler;
    }
  errorHandler:
    return iRet;
}



/*******************************************************************************
 * * Function: IFX_X_LTQ_IPProtocolVersionGetNotifyValue
 * * Desc: 
 * *              
 * * Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
static int32
IFX_X_LTQ_IPProtocolVersionGetNotifyValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                             IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    

	X_LTQ_IPPROTOCOLVERSION xIPProtVer;

    memset(&xIPProtVer, '\0', sizeof(xIPProtVer));
    iRet = ifx_get_x_ltq_ipprotocolversion_mode(&xIPProtVer, 0);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_x_ltq_ipprotocolversion_mode() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
    for(iI = 0; iI < iElements; iI++) {
        pxPV[iI].Value = IFX_CWMP_MALLOC(257);
        if(pxPV[iI].Value == NULL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", _FUNCL_);
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (pxPV[iI].iaOID[X_LTQ_IPPROTOCOLVERSION_DEPTH - 1]) {
            case OID_IGD_DI_X_LTQ_IPPV_MODE:
                strcpy(pxPV[iI].Value, xIPProtVer.mode);
                break;
			 default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", _FUNCL_,
                            pxPV[iI].iaOID[X_LTQ_IPPROTOCOLVERSION_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}




/*******************************************************************************
 * * Function: IFX_X_LTQ_IPProtocolVersionSetValue
 * * Desc:
 * *              
 * * Parameters: INOUT ParamVal * pxPV, IN int32 iElements
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
static int32
IFX_X_LTQ_IPProtocolVersionSetValue(INOUT ParamVal * pxPV, IN int32 iElements)
{
	int32 iRet = IFX_CWMP_SUCCESS, iI = 0, status;
	char8 ipprotver[50];
	memset(ipprotver, '\0' , 50);

	for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[X_LTQ_IPPROTOCOLVERSION_DEPTH - 1]) {
            case OID_IGD_DI_X_LTQ_IPPV_MODE:
				strcpy(ipprotver , pxPV[iI].Value);
				 if(strcmp(pxPV[iI].Value, "IPv4") == 0){
					status = 0;
					iRet = IFX_CWMP_NEED_ACTIVATE;
					goto errorHandler;
				}else{
					status = 1;
				}					
				break;
			
			default:
				 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", _FUNCL_,
                            pxPV[iI].iaOID[X_LTQ_IPPROTOCOLVERSION_DEPTH - 1]);
                break;
		}

	}

	iRet = ifx_ipprot_ver_set_ipv6(status , ipprotver);
	if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_ipprot_ver_set_ipv6() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }



errorHandler:
return iRet;
}



 /*******************************************************************************
 * * Function: IFX_X_LTQ_IPProtocolVersion
 * * Desc: 
 * *              
 * * Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
 * *             OUT void **ppRet, OUT int32 * piNumRetElem
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
int32
IFX_X_LTQ_IPProtocolVersion(IN OperInfo * pxOI,
                      INOUT void *pParamStruct,
                      IN int32 iElements, OUT void **ppRet,
                      OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;
    uint32 iCnt = 0;

    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:

                    iRet = IFX_X_LTQ_IPProtocolVersionGetNotifyValue(pxOI, xpParamVal,
                                                        iElements);
                    if(iRet != IFX_CWMP_SUCCESS) {
						IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d IFX_X_LTQ_IPProtocolVersionGetNotifyValue failed.\n", _FUNCL_);
                        goto errorHandler;
					}
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                                pxOI->iSubOper);
                    break;
            }
            break;
        }
		case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
					break;
                case OP_SETVAL_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                case OP_SETVAL_CHK_MODIFY_DEP:
                    break;
                case OP_SETVAL_MODIFY:
                    iRet = IFX_X_LTQ_IPProtocolVersionSetValue(xpParamVal, iElements);
                    if(iRet != IFX_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_SETVAL_ACTIVATE:
					iRet = ifx_ipprot_ver_set_ipv6(0 , "IPv4");
					if(iRet != IFX_SUCCESS) {
   					     IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
   			                 "%s:%d [%d] ifx_ipprot_ver_set_ipv6() failed\n", _FUNCL_, iRet);
   					     iRet = ERR_CWMP_INTERNAL;
   					     goto errorHandler;
   					 }
					break;
                case OP_SETVAL_COMMIT:
                    break;
                case OP_SETVAL_UNDO:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
			    case OP_SETVAL_DELETE:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_ATTRINFO:
                    iRet =
                        IFX_X_LTQ_IPProtocolVersionSetAttrInfo(pxOI->iCaller, pParamStruct,
                                                  iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                                pxOI->iSubOper);
                    break;
            }
            break;
        }
		case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_UPDATE_CHILDINFO_DEL:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            /*Vendor specific parameters should not be reported to ACS. It 
              should be available for internal updation */
            if(pxOI->iCaller == ACC_TR69)
            {
                /* Set the fault code to Error */
                for(iCnt = 0; iCnt < iElements; iCnt++)
                {
                    xpParamVal[iCnt].iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
                }
            }
            break;
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                        pxOI->iOper);
            break;
        }
    }
  errorHandler:
	if (iRet != IFX_CWMP_SUCCESS)
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d %s failed.\n", _FUNCL_, __func__);
    return iRet;
}


/*******************************************************************************
 * * Function: IFX_X_LTQ_IPProtocolVersionInit                                  
 * * Desc: Will register itself with DS.
 * * Parameters:  
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
int32
IFX_X_LTQ_IPProtocolVersionInit()
{
    int32 iRet = IFX_CWMP_SUCCESS;
    
    iRet = ifx_ds_register_function(X_LTQ_IPPROTOCOLVERSION_OBJ, IFX_X_LTQ_IPProtocolVersion);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Unable to Register %s with Object Model\n",
                    _FUNCL_, iRet, X_LTQ_IPPROTOCOLVERSION_OBJ);
        goto errorHandler;
    }   
        
	iRet = ifx_set_ipprotver();
	if(iRet != IFX_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_set_ipprotver failed\n",
                    _FUNCL_, iRet);
		goto errorHandler;
	}


errorHandler:
	return iRet;
}







