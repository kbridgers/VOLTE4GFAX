/*
** =============================================================================
** FILE NAME    : IFX_LHCMIPInterface.c
** PROJECT      : TR69
** MODULES      : IGD.LANDevice.1.LANHostConfigManagement.IPInterface.1.
** DATE         : 15-Jun-2006
** AUTHOR       : TR69 team
** DESCRIPTION  : 
**
** REFERENCES   :  
** COPYRIGHT    : Copyright (c) 2006
**                Infineon Technologies AG
**                Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
** HISTORY      : 
** $Date         $Author        $Comment
** 15-Jun-2006   TR69 team      Creation
** =============================================================================
*/
#include "IFX_DEVM_Global.h"
 
#include "IFX_DEVM_AdaptCommon.h"
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"

#include "ifx_api_proto.h"

#include <arpa/inet.h>
#include <netinet/in.h>

extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char *obj, modFunc pifx_module_func);

#define LHCMIPINTERFACE_OBJ  "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.IPInterface.1."
#define LHCMIPINTERFACE_DEPTH  7

/*******************************************************************************
* Function: IFX_LHCMIPIfSetAttrInfo
* Description: Sets attribute information in the respective tr69 sections
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_LHCMIPIfSetAttrInfo(IN int32 iCaller, INOUT ParamVal * pxPV,
                        IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    iRet = IFX_SetAttributesInfo(NULL, pxPV, iElements);

    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Updating Param Attribute Info failed\n",
                    __func__, __LINE__, iRet);
        goto errorHandler;
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_LHCMIPIfGetValue
* Description: 
*              
* Parameters: IN OperInfo * pxOI, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_LHCMIPIfGetValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                     IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0, iTmp = 0, iNum = 0;
    IP_MASK_TYPE *pxIPMask = NULL;

    if(2 == pxPV[iI].iaOID[5])	{
	    iTmp = ifx_get_lan_ip_mask("br0:1", &iNum, &pxIPMask, 0);
    }	
    else {
	    iTmp = ifx_get_lan_ip_mask("br0", &iNum, &pxIPMask, 0);
    }
	
    if(iTmp != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] get_lan_ip_mask() failed\n",
                    __func__, __LINE__, iTmp);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
    for(iI = 0; iI < iElements; iI++) {
        pxPV[iI].Value = IFX_CWMP_MALLOC(IPADDR_LEN);
        if(pxPV[iI].Value == NULL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", __func__, __LINE__);
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (pxPV[iI].iaOID[LHCMIPINTERFACE_DEPTH - 1]) {
            case OID_IGD_LAND_LANHCM_IPI_ENABLE:
                memset(pxPV[iI].Value, '\0', sizeof(pxPV[iI].Value));
                sprintf(pxPV[iI].Value,"%d", pxIPMask->f_enable);
                break;

            case OID_IGD_LAND_LANHCM_IPI_IPINTERFACEIPADDRESS:
                inet_ntop(AF_INET, &pxIPMask[0].ip_mask.ip, pxPV[iI].Value,
                          IPADDR_LEN);
                break;
            case OID_IGD_LAND_LANHCM_IPI_IPINTERFACESUBNETMASK:
                inet_ntop(AF_INET, &pxIPMask[0].ip_mask.mask, pxPV[iI].Value,
                          IPADDR_LEN);
                break;
            case OID_IGD_LAND_LANHCM_IPI_IPINTERFACEADDRESSINGTYPE:
                /* ACS expects one of there values: 'Static', 'DHCP, 'AutoIP' */
                memset(pxPV[iI].Value, '\0', sizeof(pxPV[iI].Value));
                if(pxIPMask->ip_type == IP_TYPE_STATIC)
                    strcpy(pxPV[iI].Value, "Static");
                else if(pxIPMask->ip_type == IP_TYPE_DHCP)
                    strcpy(pxPV[iI].Value, "DHCP");
                else if(pxIPMask->ip_type == IP_TYPE_AUTO)
                    strcpy(pxPV[iI].Value, "AutoIP");
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Default case\n", __func__, __LINE__,
                            pxPV[iI].iaOID[LHCMIPINTERFACE_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    IFX_CWMP_FREE(pxIPMask);
    return iRet;
}

/*******************************************************************************
* Function: IFX_LHCMIPIfValidate
* Description:
*              
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_LHCMIPIfValidate(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0, iIP = 0;

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[LHCMIPINTERFACE_DEPTH - 1]) {
            case OID_IGD_LAND_LANHCM_IPI_ENABLE:
                break;
            case OID_IGD_LAND_LANHCM_IPI_IPINTERFACEIPADDRESS:
            case OID_IGD_LAND_LANHCM_IPI_IPINTERFACESUBNETMASK:
                if((iRet = inet_pton(AF_INET, pxPV[iI].Value, &iIP)) <= 0) {
                    iRet = ERR_CWMP_INVAL_ARGS;
                    pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                }
                else
                    iRet = IFX_CWMP_SUCCESS;
                break;
            case OID_IGD_LAND_LANHCM_IPI_IPINTERFACEADDRESSINGTYPE:
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Default case\n", __func__, __LINE__,
                            pxPV[iI].iaOID[LHCMIPINTERFACE_DEPTH - 1]);
                break;
        }
    }
    return iRet;
}

/*******************************************************************************
* Function: IFX_LHCMset_lhcm_interface_details
* Description: For filling the parent details when the 2nd instance is enabled/
*	disabled
*              
* Parameters: if_enable
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int IFX_LHCMset_lhcm_interface_details(int32 if_enable){
	DHCP_SERVER_INFO xDSInfo;
	int32 iNumEntries = 0,iFlags = 0,iTmp = 0,iRet = 0;
	char ip_addr[32],mask[32],dhcp_min[32],dhcp_max[32];	
	struct in_addr iIP;
	IP_MASK_TYPE *pxIPMask = NULL;

	memset(&xDSInfo, '\0', sizeof(xDSInfo));

	iTmp = ifx_get_lan_dhcp_server_config(&xDSInfo, 0);
	if(iTmp != IFX_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		    "%s:%d [%d] ifx_get_lan_dhcp_server_cfg() failed\n",
		    __func__, __LINE__, iTmp);
		iRet = ERR_CWMP_INTERNAL;
		goto errorHandler;
	}

	if(0 == if_enable){
		iTmp = ifx_get_lan_ip_mask("br0", &iNumEntries, &pxIPMask, 0);
	}	
	else{
		iTmp = ifx_get_lan_ip_mask("br0:1", &iNumEntries, &pxIPMask, 0);
	}

	if(iTmp != IFX_SUCCESS) {
        	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] get_lan_ip_mask() failed\n",
                    __func__, __LINE__, iTmp);
	        iRet = ERR_CWMP_INTERNAL;
        	goto errorHandler;
	}

	inet_ntop(AF_INET, &pxIPMask[0].ip_mask.ip,ip_addr,IPADDR_LEN);
	inet_ntop(AF_INET, &pxIPMask[0].ip_mask.mask,mask,IPADDR_LEN);
	
	if(0 == dhcpmin_maxadress(ip_addr,mask,dhcp_min,dhcp_max)){
	
		if((iRet = inet_pton(AF_INET, dhcp_min, &iIP)) == 1) {
		    xDSInfo.start_ip = iIP;
		}
		if((iRet = inet_pton(AF_INET, dhcp_max, &iIP)) == 1) {
		    xDSInfo.end_ip = iIP;
		}
		xDSInfo.netmask = pxIPMask[0].ip_mask.mask;	
		xDSInfo.ip_gw = pxIPMask[0].ip_mask.ip;
	}

	iFlags = iFlags | IFX_F_MODIFY | IFX_F_DONT_WRITE_TO_FLASH | IFX_F_DONT_CHECKPOINT;
	xDSInfo.iid.config_owner = IFX_TR69;
        iTmp = ifx_set_lan_dhcp_server_config(IFX_OP_MOD, &xDSInfo, iFlags);
        if(iTmp != IFX_SUCCESS)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_set_lan_dhcp_server_cfg() failed\n",
                    __func__, __LINE__, iTmp);
            iRet = ERR_CWMP_INTERNAL;
            goto errorHandler;
        }
	errorHandler:
	    IFX_CWMP_FREE(pxIPMask);
	    return iRet;
}

/*******************************************************************************
* Function: IFX_LHCMIPIfSetVal
* Description:
*              
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_LHCMIPIfSetVal(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0, iTmp = 0, iNum = 0;
    IP_MASK_TYPE *pxIPMask;
    int32 oid_val = 1;
    int32 f_enable_val = 0;
    char if_name[32];	
   
    if(2 == pxPV[iI].iaOID[5])	{
	strcpy(if_name,"br0:1");
        oid_val = pxPV[iI].iaOID[5];
    }	
    else {
	strcpy(if_name,"br0");
    }
    iTmp = ifx_get_lan_ip_mask(if_name,&iNum, &pxIPMask, IFX_F_GET_ANY);
    
    if(iTmp != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] get_lan_ip_mask() failed\n",
                    __func__, __LINE__, iTmp);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[LHCMIPINTERFACE_DEPTH - 1]) {
            case OID_IGD_LAND_LANHCM_IPI_ENABLE:
		f_enable_val = pxIPMask[0].f_enable;
		if((1 == oid_val) && (0 == f_enable_val)){
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
					"%s:%d Can not Disable Ipinterface 1\n",
					__func__, __LINE__);	
		}
		else{
			if((strncasecmp(pxPV[iI].Value, "FALSE", 5) == 0) || 
			   	(strcmp(pxPV[iI].Value, "0") == 0))
			    pxIPMask[0].f_enable = 0;
			else
			    pxIPMask[0].f_enable = 1;
		}
		break;
            case OID_IGD_LAND_LANHCM_IPI_IPINTERFACEIPADDRESS:
                if((iRet =
                    inet_pton(AF_INET, pxPV[iI].Value,
                              &pxIPMask[0].ip_mask.ip)) == 1) {
                    iRet = IFX_CWMP_SUCCESS;
                }
                else {
                    iRet = ERR_CWMP_INVAL_ARGS;
                    pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                }
                break;
            case OID_IGD_LAND_LANHCM_IPI_IPINTERFACESUBNETMASK:
                if((iRet =
                    inet_pton(AF_INET, pxPV[iI].Value,
                              &pxIPMask[0].ip_mask.mask)) == 1) {
                    iRet = IFX_CWMP_SUCCESS;
                }
                else {
                    iRet = ERR_CWMP_INVAL_ARGS;
                    pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                }
                break;
            case OID_IGD_LAND_LANHCM_IPI_IPINTERFACEADDRESSINGTYPE:
                if(!(strcmp(pxPV[iI].Value,"Static")))
                    pxIPMask[0].ip_type = IP_TYPE_STATIC;
                else if(!(strcmp(pxPV[iI].Value,"DHCP")))
                    pxIPMask[0].ip_type = IP_TYPE_DHCP;
                else
                    pxIPMask[0].ip_type = IP_TYPE_AUTO;
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Default case\n", __func__, __LINE__,
                            pxPV[iI].iaOID[LHCMIPINTERFACE_DEPTH - 1]);
                break;
	}
    }
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;
    
    for(iI = 0; iI < iNum; iI++)
        pxIPMask[iI].iid.config_owner = IFX_TR69;

    iTmp = ifx_set_lan_ip_mask(IFX_OP_MOD,oid_val-1, if_name, pxIPMask,
                               IFX_F_DONT_CHECKPOINT |
                               IFX_F_DONT_WRITE_TO_FLASH | IFX_F_MODIFY);
		
    if(iTmp != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] set_lan_ip_mask() failed\n",
                    __func__, __LINE__, iTmp);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
    else{
	if(f_enable_val != pxIPMask[0].f_enable){
		if(IFX_CWMP_SUCCESS != 
		IFX_LHCMset_lhcm_interface_details(pxIPMask[0].f_enable)){
			goto errorHandler;
		}
	}
    }		
  errorHandler:
    IFX_CWMP_FREE(pxIPMask);
    return iRet;
}

/*******************************************************************************
* Function: IFX_LHCMIPInterface
* Description: 
*              
* Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
*             OUT void **ppRet, OUT int32 * piNumRetElem
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_LHCMIPInterface(IN OperInfo * pxOI, INOUT void *pParamStruct,
                    IN int32 iElements, OUT void **ppRet,
                    OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s: %s oper=%d maxElement=%d\n",
                __func__, xpParamVal[0].Name, pxOI->iSubOper, iElements);

    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                    iRet = IFX_LHCMIPIfGetValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_GETVAL_NOTIFICATION:
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                    if((iRet =
                        IFX_LHCMIPIfValidate(xpParamVal, iElements)) != 0) {
                        goto errorHandler;
                    }
                    break;
                case OP_SETVAL_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:
                    break;
                case OP_SETVAL_MODIFY:
                    iRet = IFX_LHCMIPIfSetVal(xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_SETVAL_COMMIT:
                    break;
                case OP_SETVAL_UNDO:
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_DELETE:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_ATTRINFO:
                    iRet = IFX_LHCMIPIfSetAttrInfo(pxOI->iCaller, pParamStruct,
                                                   iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_UPDATE_CHILDINFO_DEL:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d Error! Default case. Op=%d\n", __func__,
                        __LINE__, pxOI->iOper);
            break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_LHCMIPInterfaceInit
* Description: Will initialize some of its data structures, register itself with
*              DS.
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_LHCMIPInterfaceInit()
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* TBD: Perform any LHCMIPInterfaceInit related initializations here */

    /* Register the LHCMIPInterface func ptr in the object model */
    iRet = ifx_ds_register_function(LHCMIPINTERFACE_OBJ, IFX_LHCMIPInterface);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d Unable to Register %s with Object Model\n",
                    __func__, __LINE__, LHCMIPINTERFACE_OBJ);
        goto errorHandler;
    }

  errorHandler:
    return iRet;
}
