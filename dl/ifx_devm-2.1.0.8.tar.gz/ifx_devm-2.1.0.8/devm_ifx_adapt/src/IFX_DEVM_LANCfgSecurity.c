/* 
** =============================================================================
**   FILE NAME        : IFX_LANConfigSecurity.c
**   PROJECT          : TR69
**   MODULES          : LANConfigSecurity
**   DATE             : 14-05-2007
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This module handles ADD/DEL/GET/SET RPCs of 
**                      LANConfigSecurity. When controller calls this module it
**                      calls respective Platform/Object APIs to handle GET/SET 
**                      of LANConfigSecurity specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author        $Comment
**   04-09-06         TR69 team      Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/

//#include <sys/socket.h>
//#include <netinet/in.h>
//#include <arpa/inet.h>

#include "IFX_DEVM_LANCfgSecurity.h"
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
// 
// 
// 

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;

//extern Map_Value gaxWanDiagnosticState[];

#define IFX_WAN_LAN_CONF_SEC_OBJ "InternetGatewayDevice.LANConfigSecurity."


/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/






/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/

#ifdef IFX_TR69_WAN_MODS_TEST_STUBS

#endif


/* 
** =============================================================================
**   Function Name    : IFX_LANConfSecGetValue
**   Description        : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes                : 
**
** ============================================================================
*/
static int32 
IFX_LANConfSecGetValue(IN OperInfo *pxOperInfo,INOUT ParamVal *pxGetParamVal,
								IN uint32 iElements)
{
	/*GET PARAMETER VALUES
	*/

//	uint32 uiFlags=0;
//	uint32 iCpeid=0,i=0;
	int32 iParamId=0;
	uint32 uiParamPos=0;
	//int32 iRet=IFX_CWMP_SUCCESS;
	
//	uiFlags = IFX_F_GET_ANY;
	
//	iRet = ifx_get_lan_conf_security(sPasswd, uiFlags);	
//	if(iRet != IFX_CWMP_SUCCESS)
//		goto errorHandler;

	uiParamPos = IFX_GetParamIdPos(pxGetParamVal->iaOID);
	iParamId = pxGetParamVal->iaOID[uiParamPos];

		switch(iParamId)
		{

	    		case OID_IGD_LANCS_CONFIGPASSWORD:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
				if((pxGetParamVal->Value)!=NULL)
				{
				strcpy(pxGetParamVal->Value,"");	
				}
				else
				{
				goto errorHandler;
				}
				break;	 
					
				
			default:
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "Invalid param id %d!\n", iParamId);
			pxGetParamVal->iFaultCode=ERR_INVAL_PARAMETER_VAL;
			goto errorHandler;
			break;
		}

							
		
		return IFX_CWMP_SUCCESS;
		
		errorHandler:
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
			
			return IFIN_CWMP_FAILURE;
			

}

/* 
** =============================================================================
**   Function Name    : IFX_LANConfSecSetValidate
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_LANConfSecSetValidate(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
							IN int32 iElements)
{
	
	
	return IFIN_CWMP_SUCCESS;

}

/* 
** =============================================================================
**   Function Name    : IFX_LANConfSecAddObj
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_LANConfSecAddObj(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{

		
	return IFIN_CWMP_SUCCESS;

	
}

/* 
** =============================================================================
**   Function Name    : IFX_LANConfSecSetValue
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_LANConfSecSetValue(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
							IN int32 iElements)
{


	int32 iRet=IFX_CWMP_SUCCESS;
	int32 iParamId=0;
	uint32 uiParamPos=0;
	char8 sPassword[PARAMVALUE_LEN];
        int32 iOper=IFX_OP_MOD;
	uint32 uiFlags=(IFX_F_MODIFY|IFX_F_DONT_CHECKPOINT|IFX_F_DONT_WRITE_TO_FLASH);	


	uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);
	iParamId = paxParamVal->iaOID[uiParamPos];
		
	
	
	switch(pxOpInfo->iSubOper)
		{
			
			case OP_SETVAL_CHK_MODIFY_DEP:
						
				break;
					
			case OP_SETVAL_MODIFY:
				
			switch(iParamId)
			{

	    			case OID_IGD_LANCS_CONFIGPASSWORD:
				if(strcmp(paxParamVal->Value,"") !=0) {	
					strcpy(sPassword,paxParamVal->Value);	
				} else {
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
        	                        "Invalid param Value = ParamId %d!\n", iParamId);
	                                paxParamVal->iFaultCode=ERR_INVAL_PARAMETER_VAL;
					iRet = ERR_CWMP_INVAL_PARAM_VAL;
                	                goto errorHandler;
				}
				break;	 
					
				
				default:
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            	"Invalid param id %d!\n", iParamId);
				paxParamVal->iFaultCode=ERR_INVAL_PARAMETER_VAL;
				goto errorHandler;
				break;
			}

				
			iRet = ifx_set_lan_conf_security(iOper,sPassword,uiFlags);

			if(iRet != IFX_SUCCESS)
			{
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					"ifx_set_lan_conf_security -Modify Mgmt API returned error\n");
				goto errorHandler;
				
			}
			break;	

			default:
				break;
					
		}
	
	return iRet;
	
	errorHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
		return iRet;

}

/* 
** =============================================================================
**   Function Name    : IFX_LANConfSecSetCommit
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_LANConfSecSetCommit()
{
	return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_LANConfSecSetUndo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_LANConfSecSetUndo()
{
	return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_LANConfSecSetDelete
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_LANConfSecSetDelete(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
				IN int32 iElements, OUT void **ppxParamStructRet,
						   OUT int32 * piNumRetElem)
{
	
		return IFIN_CWMP_SUCCESS;
	
}

/* 
** =============================================================================
**   Function Name    : IFX_LANConfSecSetFree
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_LANConfSecSetFree()
{
	return IFX_CWMP_SUCCESS;
}


/* 
** =============================================================================
**   Function Name    : IFX_LANConfSecSetAttr
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

int32
IFX_LANConfSecSetAttr(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{
	int32 iRet,i;
	OperInfo xOpInfo;
	
	xOpInfo.iCaller = pxOpInfo->iCaller;
	xOpInfo.iOper= OP_GETVAL;
	xOpInfo.iSubOper= OP_GETVAL_NORMAL;
	
	iRet = IFX_LANConfSecGetValue(&xOpInfo,pxParamVal, iElements);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorFreeHandler;
	
	iRet = IFX_SetAttributesInfo(pxOpInfo, pxParamVal, iElements);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;

	for(i=0; i < iElements; i++)
		IFX_CWMP_FREE(pxParamVal[i].Value);

	return IFX_CWMP_SUCCESS;

	errorFreeHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
		for(i=0; i < iElements; i++)
		IFX_CWMP_FREE(pxParamVal[i].Value);
		
	errorHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
		return iRet;
		


}




/* 
** =============================================================================
**   Function Name    : IFX_LANConfigSecurity_Init
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_LANConfigSecurity_Init(void)
{
	int32 iRet = IFX_CWMP_SUCCESS;

    
	/* Register the WanDslLinkConfig module function pointer in the object model */
	iRet = ifx_ds_register_function(IFX_WAN_LAN_CONF_SEC_OBJ, IFX_LANConfigSecurity);

	/* Check for error */
	if (iRet != IFX_CWMP_SUCCESS)
	{
	    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                "Unable to Register %s with Object Model\n",
	                IFX_WAN_LAN_CONF_SEC_OBJ);
	    goto errorHandler;
	}

	errorHandler:
			return iRet;
}

/*********************************************************************************
*  Function Name	:  IFX_LANConfigSecurity
      *  Description	:  This function handles all the sub-states inside
      	 		   a GET/SET operation.If it is a GET it allocates the 
			   array(Name,Value pairs) and retruns the values.
			   If it is a SET controller allocates the array and
			   passes the values to this function.It calls 
			   respective internal functions which in turn calls 
			   respective Platform APIs.
                                                                                                 
*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
							     Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has 
					  	             Name,Value,etc
                    IN          int32	       iElements;    No. of Elements
		    OUT	        void *	       ppParamRet;   same as ParamStruc
		    OUT         int32 *        piNumRetElem; No. of elements 		                                
*  Return Value        : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes               :
***********************************************************************************/
int32
IFX_LANConfigSecurity(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                IN int32 iElements, OUT void **ppaxParamArrRet, OUT int32 *piNumRetElem)
{
     
   //It calls the respective internal functions which handles resp. sub-operation
   
   //Set-Operation  
   //controller should pass the entire array during all the SET-sub_operations
   //It should handles only single get/set of instance at any point of time
   //It does not handle partial path
   //It won't handle multiple instances of the same object/module
   //at any point of time.

    
   int32 iRet = 0;
   ParamVal *paxParamArr = (ParamVal *)paxParameterArr;

	switch (pxOperInfo->iOper) 
	{
		//Get the object values
	   	case OP_GETVAL:
		{
	            if((iRet = IFX_LANConfSecGetValue(pxOperInfo, paxParamArr,
		    							iElements)) != IFX_CWMP_SUCCESS)
			{
			  IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
			  goto errorHandler;
	            }
	            break;
                }
	        case OP_SETVAL:
		{

	    		//Set the obj values
			switch (pxOperInfo->iSubOper) 
			{
		               case OP_SETVAL_VALIDATE:
		                    if((iRet = IFX_LANConfSecSetValidate(pxOperInfo,paxParamArr,
				    							iElements)) != IFX_CWMP_SUCCESS)
					{    
		                        
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d OP_SET_VALIDATE failed!\n", __func__, __LINE__);
					goto errorHandler;
		                    }
		                    break;
		                case OP_SETVAL_ADD:
		                    if((iRet= IFX_LANConfSecAddObj(pxOperInfo,paxParamArr,
				    					iElements))!=IFX_CWMP_SUCCESS)
		                    	{
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            	"%s:%d OP_SETVAL_ADD failed!\n", __func__, __LINE__);
		                    	 goto errorHandler;
		                    	}
		                    break;
		              case OP_SETVAL_CHK_MODIFY_DEP:
				case OP_SETVAL_MODIFY:
		                    if((iRet = IFX_LANConfSecSetValue(pxOperInfo,paxParamArr,
				    					iElements))!= IFX_CWMP_SUCCESS) 
		    			{									
							IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_MODIFY failed!\n", __func__, __LINE__);
				                        goto errorHandler;
				    	 }
		                    break;
		                case OP_SETVAL_COMMIT:
		                    if((iRet = IFX_LANConfSecSetCommit(pxOperInfo,paxParamArr,
		    										iElements)) != IFX_CWMP_SUCCESS)
					{
				    	   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_COMMIT failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;
		                case OP_SETVAL_UNDO:
		                    if((iRet =IFX_LANConfSecSetUndo(pxOperInfo, paxParamArr,
				    						iElements)) != IFX_CWMP_SUCCESS)
					{
				    	   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_UNDO failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;
				case OP_SETVAL_CHK_DEL_DEP:
				case OP_SETVAL_CHK_DEL_ALLOWED:
		              case OP_SETVAL_DELETE:
		                    if((iRet= IFX_LANConfSecSetDelete(pxOperInfo, paxParamArr,
							iElements, ppaxParamArrRet,	piNumRetElem))!= IFX_CWMP_SUCCESS)
					{
				    		switch(pxOperInfo->iSubOper)
						{	
					  		case OP_SETVAL_CHK_DEL_DEP:
						    	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
				                        goto errorHandler;
							case OP_SETVAL_CHK_DEL_ALLOWED:
								IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
				                        goto errorHandler;
							case OP_SETVAL_DELETE:
								IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
				                        goto errorHandler;
						}
		                    goto errorHandler;
				    }
		                    break;
		                case OP_SETVAL_FREE:
		                    IFX_LANConfSecSetFree(pxOperInfo);
		                    break;

				case OP_SETVAL_ACTIVATE:
				   break;

				 case OP_SETVAL_ATTRINFO:
				 	if((iRet =IFX_LANConfSecSetAttr(pxOperInfo, paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS)
					{
				    	  IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            	"%s:%d OP_SETVAL_ATTRINFO failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;	
		                default:
		                    break;
			}
			break;	
		}
			case OP_UPDATE_CHILDINFO:
			break;

		case OP_PARAM_VALIDATE:
		{
			break; 
		}
		default:
		{
			break;
		}
	}
	return IFX_CWMP_SUCCESS;

errorHandler:
		return iRet;
}
//This helps to synch
 
