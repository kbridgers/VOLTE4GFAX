/*
** =============================================================================
**   FILE NAME        : IFX_WlanWps.c
**   PROJECT          : TR69
**   MODULES          : WlanWps
**   DATE             : 13-7-2009
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This module handles ADD/DEL/GET/SET RPCs of
**                      WlanWps. When controller calls this module it
**                      calls respective Platform/Object APIs to handle GET/SET
**                      of WlanWps specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          :
**   $Date            $Author        $Comment
**   13-07-09         TR69 team      Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include <unistd.h>
#include "IFX_DEVM_WLANWps.h"
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
 

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;

#ifdef IFX_TR69_DEVICE
	#define OID_IGD_LAND_WLANC_WPS_DEVICENAME	OID_IGD_LAN_WLANC_WPS_DEVICENAME
	#define OID_IGD_LAND_WLANC_WPS_DEVICEPASSWORD	OID_IGD_LAN_WLANC_WPS_DEVICEPASSWORD
	#define OID_IGD_LAND_WLANC_WPS_UUID	OID_IGD_LAN_WLANC_WPS_UUID
	#define OID_IGD_LAND_WLANC_WPS_VERSION	OID_IGD_LAN_WLANC_WPS_VERSION
	#define OID_IGD_LAND_WLANC_WPS_CONFIGMETHODSSUPPORTED	OID_IGD_LAN_WLANC_WPS_CONFIGMETHODSSUPPORTED
	#define	OID_IGD_LAND_WLANC_WPS_CONFIGMETHODSENABLED	OID_IGD_LAN_WLANC_WPS_CONFIGMETHODSENABLED
	#define OID_IGD_LAND_WLANC_WPS_SETUPLOCKEDSTATE		OID_IGD_LAN_WLANC_WPS_SETUPLOCKEDSTATE
	#define	OID_IGD_LAND_WLANC_WPS_SETUPLOCK	OID_IGD_LAN_WLANC_WPS_SETUPLOCK
	#define	OID_IGD_LAND_WLANC_WPS_CONFIGURATIONSTATE	OID_IGD_LAN_WLANC_WPS_CONFIGURATIONSTATE
	#define	OID_IGD_LAND_WLANC_WPS_LASTCONFIGURATIONERROR	OID_IGD_LAN_WLANC_WPS_LASTCONFIGURATIONERROR
	#define	OID_IGD_LAND_WLANC_WPS_REGISTRARNUMBEROFENTRIES		OID_IGD_LAN_WLANC_WPS_REGISTRARNUMBEROFENTRIES
	#define	OID_IGD_LAND_WLANC_WPS_REGISTRARESTABLISHED	OID_IGD_LAN_WLANC_WPS_REGISTRARESTABLISHED
	#define	OID_IGD_LAND_WLANC_WPS_ENABLE		OID_IGD_LAN_WLANC_WPS_ENABLE
	#define	OID_IGD_LAND_WLANC_WPS_R_ENABLE		OID_IGD_LAN_WLANC_WPS_R_ENABLE
	#define OID_IGD_LAND_WLANC_WPS_R_DEVICENAME	OID_IGD_LAN_WLANC_WPS_R_DEVICENAME
	#define	OID_IGD_LAND_WLANC_WPS_R_UUID		OID_IGD_LAN_WLANC_WPS_R_UUID
#endif
	
#define IFX_WLAN_WPS_OBJ  FORMLANNAME("WLANConfiguration.1.WPS")
#define IFX_WLAN_WPS_REG_OBJ  FORMLANNAME("WLANConfiguration.1.WPS.Registrar.1.")

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/


extern Map_Value gaxEnable[];

/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS>
**
** =============================================================================
*/

/*
** =============================================================================
**   Function Name    : IFX_WlanWpsGetValue
**   Description        :
**
**   Parameters       :
**
**   Return Value     :
**   Notes                :
**
** ============================================================================
*/
static int32
IFX_WlanWpsGetValue(IN OperInfo * pxOperInfo, INOUT ParamVal * paxParamVal,
                     IN uint32 iElements)
{

    uint32 i = 0, j =0;
    uint32 uiCpeid = 0;
    uint32 uiPcpeid = 0;
    int32 iRet = IFX_CWMP_SUCCESS;
    uint32 iFlags = 0, uiParamPos = 0;

    IFX_MAPI_WLAN_WPS_Cfg wlWps;
    
    memset(&wlWps,0x00, sizeof(IFX_MAPI_WLAN_WPS_Cfg));
    
	// Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(paxParamVal->iaOID, &uiCpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Get the pCpeid from Tr69 id
    iRet = IFX_GetParentObjCpeId(paxParamVal->iaOID, &uiPcpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Fills the Cpeid,ParentCepid,TR69Id,Owner
    iFlags = IFX_F_GET_ANY;

    // Get the WlanWpsParamPos
    uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);

    wlWps.iid.cpeId.Id = uiCpeid;
    wlWps.iid.pcpeId.Id = uiPcpeid;
    strcpy(wlWps.iid.cpeId.secName,"wlan_wps");
    strcpy(wlWps.iid.pcpeId.secName,"wlan_main");
    wlWps.iid.config_owner = pxOperInfo->iCaller;

    iRet = ifx_mapi_get_wlan_wps_config(&wlWps, iFlags);
    if (iRet != IFX_CWMP_SUCCESS) {	
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get all values"
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
        goto errorHandler;
    }

    for (i = 0; i < iElements; i++)
    {
        // Malloc and assign the pointer to the Value attr of struct
        paxParamVal[i].Value = IFIN_CWMP_MALLOC(128);
        if (paxParamVal->Value == NULL)
        {
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (paxParamVal[i].iaOID[uiParamPos])
        {
            case OID_IGD_LAND_WLANC_WPS_ENABLE:
                sprintf(paxParamVal[i].Value,"%d", wlWps.enable);
                break;

            case OID_IGD_LAND_WLANC_WPS_DEVICENAME:
                strcpy(paxParamVal[i].Value, wlWps.apWpsName);
                break;

            case OID_IGD_LAND_WLANC_WPS_DEVICEPASSWORD:
		strcpy(paxParamVal[i].Value,"");	
                break;

            case OID_IGD_LAND_WLANC_WPS_UUID:
                strcpy(paxParamVal[i].Value, wlWps.uuidAp);
                break;

            case OID_IGD_LAND_WLANC_WPS_VERSION:
//kamal: clarigication needed
		strcpy(paxParamVal[i].Value,"1");
                break;

            case OID_IGD_LAND_WLANC_WPS_CONFIGMETHODSSUPPORTED:                
                strcpy(paxParamVal[i].Value, "");
                for(j=0;j<IFX_MAPI_WPS_MAX_CFG_METHODS;j++){
                    if( wlWps.suppCfgMethods[j]!=0 ) {
                        switch(wlWps.suppCfgMethods[j])
                        {
                            case IFX_MAPI_WPS_USB_FLASH_DRIVE:
                                strcat(paxParamVal[i].Value, "USBFlashDrive");
                                break;
                            case IFX_MAPI_WPS_ETHERNET:
                                strcat(paxParamVal[i].Value, "Ethernet");
                                break;
                            case IFX_MAPI_WPS_LABEL:
                                strcat(paxParamVal[i].Value, "Label");
                                break;
                            case IFX_MAPI_WPS_DISPLAY:
                                strcat(paxParamVal[i].Value, "Display");
                                break;
                            case IFX_MAPI_WPS_EXTERNAL_NFC_TOKEN:
                                strcat(paxParamVal[i].Value, "ExternalNFCToken");
                                break;
                            case IFX_MAPI_WPS_INTEGRATED_NFC_TOKEN:
                                strcat(paxParamVal[i].Value, "IntegratedNFCToken");
                                break;
                            case IFX_MAPI_WPS_NFC_INTERFACE:
                                strcat(paxParamVal[i].Value, "NFCInterface");
                                break;
                            case IFX_MAPI_WPS_PUSH_BUTTON:
                                strcat(paxParamVal[i].Value, "PushButton");
                                break;
                            case IFX_MAPI_WPS_KEY_PAD:
                                strcat(paxParamVal[i].Value, "Keypad");
                                break;
                        }
                        if((j+1 < IFX_MAPI_WPS_MAX_CFG_METHODS) && (wlWps.suppCfgMethods[j+1]!=0))
                            strcat(paxParamVal[i].Value, ", ");
                    } else 
                        break;
                }
                break;

            case OID_IGD_LAND_WLANC_WPS_CONFIGMETHODSENABLED:
                strcpy(paxParamVal[i].Value, "");
                for(j=0;j<IFX_MAPI_WPS_MAX_CFG_METHODS;j++){
                    if( wlWps.enaCfgMethods[j]!=0 ) {
                        switch(wlWps.enaCfgMethods[j])
                        {
                            case IFX_MAPI_WPS_USB_FLASH_DRIVE:
                                strcat(paxParamVal[i].Value, "USBFlashDrive");
                                break;
                            case IFX_MAPI_WPS_ETHERNET:
                                strcat(paxParamVal[i].Value, "Ethernet");
                                break;
                            case IFX_MAPI_WPS_LABEL:
                                strcat(paxParamVal[i].Value, "Label");
                                break;
                            case IFX_MAPI_WPS_DISPLAY:
                                strcat(paxParamVal[i].Value, "Display");
                                break;
                            case IFX_MAPI_WPS_EXTERNAL_NFC_TOKEN:
                                strcat(paxParamVal[i].Value, "ExternalNFCToken");
                                break;
                            case IFX_MAPI_WPS_INTEGRATED_NFC_TOKEN:
                                strcat(paxParamVal[i].Value, "IntegratedNFCToken");
                                break;
                            case IFX_MAPI_WPS_NFC_INTERFACE:
                                strcat(paxParamVal[i].Value, "NFCInterface");
                                break;
                            case IFX_MAPI_WPS_PUSH_BUTTON:
                                strcat(paxParamVal[i].Value, "PushButton");
                                break;
                            case IFX_MAPI_WPS_KEY_PAD:
                                strcat(paxParamVal[i].Value, "Keypad");
                                break;
                        }
                        if((j+1 < IFX_MAPI_WPS_MAX_CFG_METHODS) && (wlWps.enaCfgMethods[j+1]!=0))
                            strcat(paxParamVal[i].Value, ", ");
                    } else 
                        break;
                }
                break;   

            case OID_IGD_LAND_WLANC_WPS_SETUPLOCKEDSTATE:
                if(wlWps.setupLockedState == IFX_MAPI_WPS_STA_LOCKED)
                    strcpy(paxParamVal[i].Value, "Unlocked");
                else if (wlWps.setupLockedState == IFX_MAPI_WPS_STA_LOCKED_BY_LM)
                    strcpy(paxParamVal[i].Value, "LockedByLocalManagement");
                else if (wlWps.setupLockedState == IFX_MAPI_WPS_STA_LOCKED_BY_RM)
                    strcpy(paxParamVal[i].Value, "LockedByRemoteManagement");
                else if (wlWps.setupLockedState == IFX_MAPI_WPS_STA_PIN_RETRY_LIMIT_HIT)
                    strcpy(paxParamVal[i].Value, "PINRetryLimitReached");
                break;

            case OID_IGD_LAND_WLANC_WPS_SETUPLOCK:
                sprintf(paxParamVal[i].Value,"%d", wlWps.setupLock);
                break;
            case OID_IGD_LAND_WLANC_WPS_CONFIGURATIONSTATE:
                if(wlWps.cfgState == IFX_MAPI_WPS_NOT_CONFIGURED)
                    strcpy(paxParamVal[i].Value, "Not configured");
                else if(wlWps.cfgState == IFX_MAPI_WPS_CONFIGURED)
                    strcpy(paxParamVal[i].Value, "Configured");
                break;

            case OID_IGD_LAND_WLANC_WPS_LASTCONFIGURATIONERROR:
                if(wlWps.lastConfigError == IFX_MAPI_WPS_OOB_IF_READ_ERROR)
                    strcpy(paxParamVal[i].Value, "MessageTimeout");
                else if(wlWps.lastConfigError == IFX_MAPI_WPS_DECRYPT_CRC_FAILURE)
                    strcpy(paxParamVal[i].Value, "DecryptionCRCFailure");
                else if(wlWps.lastConfigError == 0 )
                    strcpy(paxParamVal[i].Value, "NoError");
                break;

            case OID_IGD_LAND_WLANC_WPS_REGISTRARNUMBEROFENTRIES:
//kamal: clarification needed
// MAPI is not returning tis value so returning value = 1
                strcpy(paxParamVal[i].Value, "1");
                break;

            case OID_IGD_LAND_WLANC_WPS_REGISTRARESTABLISHED:
                sprintf(paxParamVal[i].Value, "%d", wlWps.regsEstbld);   
                break;
            default:
                break;
        }
    }

    return IFX_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed ParamId=%d !\n", __func__, __LINE__,
                paxParamVal->iaOID[uiParamPos]);
    return IFIN_CWMP_FAILURE;
}


/*
** =============================================================================
**   Function Name    : IFX_WlanWpsSetValue
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/
static int32
IFX_WlanWpsSetValue(IN OperInfo * pxOpInfo, INOUT ParamVal * paxParamVal,
                     IN int32 iElements)
{

    uint32 i = 0, j = 0;
    uint32 uiCpeid = 0;
    uint32 uiPcpeid = 0;
    int32 iRet = IFX_CWMP_SUCCESS;
    uint32 iOper = 0, iFlags = 0, uiParamPos = 0;
    char tmp[128]={0}, *tok=NULL;

    IFX_MAPI_WLAN_WPS_Cfg wlWps;
    
    memset(&wlWps, 0x00, sizeof(IFX_MAPI_WLAN_WPS_Cfg));
    

    // Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(paxParamVal->iaOID, &uiCpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Get the pCpeid from Tr69 id
    iRet = IFX_GetParentObjCpeId(paxParamVal->iaOID, &uiPcpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Fills the Cpeid,ParentCepid,TR69Id,Owner
    iOper = IFX_OP_MOD;
    iFlags = IFX_F_GET_ANY;

    // Get the WlanWpsParamPos
    uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);
   
    wlWps.iid.cpeId.Id = uiCpeid;
    wlWps.iid.pcpeId.Id = uiPcpeid;
    strcpy(wlWps.iid.cpeId.secName,"wlan_wps");
    strcpy(wlWps.iid.pcpeId.secName,"wlan_main");
    wlWps.iid.config_owner = pxOpInfo->iCaller;
    
    switch (pxOpInfo->iSubOper)
    {

        case OP_SETVAL_CHK_MODIFY_DEP:
            break;

        case OP_SETVAL_VALIDATE:
            break;

        case OP_SETVAL_MODIFY:
            
            iRet = ifx_mapi_get_wlan_wps_config(&wlWps, iFlags);
            if (iRet != IFX_CWMP_SUCCESS) {	
            iRet = ERR_CWMP_INTERNAL;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get all values"
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto errorHandler;
            }  

            for (i = 0; i < iElements; i++)
            {
                switch (paxParamVal[i].iaOID[uiParamPos])
                {
                    case OID_IGD_LAND_WLANC_WPS_ENABLE:
                        wlWps.enable = atoi(paxParamVal[i].Value);
                        break;
                    case OID_IGD_LAND_WLANC_WPS_DEVICEPASSWORD:
                        wlWps.apWpsPin = atoi(paxParamVal[i].Value);
                        break;
                    case OID_IGD_LAND_WLANC_WPS_CONFIGMETHODSENABLED:
                        if (paxParamVal[i].Value!=NULL)
                        {
                            j = 0;
                            strcpy(tmp, paxParamVal[i].Value);
                            tok = strtok(tmp,", ");
                            while (1)
                            {
                                if (tok==NULL)
                                    break;
                                if(!strcmp(tok,"USBFlashDrive"))
                                    wlWps.enaCfgMethods[j++] = IFX_MAPI_WPS_USB_FLASH_DRIVE;
                                else if(!strcmp(tok,"Ethernet"))
                                    wlWps.enaCfgMethods[j++] = IFX_MAPI_WPS_ETHERNET;
                                else if(!strcmp(tok,"Label"))
                                    wlWps.enaCfgMethods[j++] = IFX_MAPI_WPS_LABEL;
                                else if(!strcmp(tok,"Display"))
                                    wlWps.enaCfgMethods[j++] = IFX_MAPI_WPS_DISPLAY;
                                else if(!strcmp(tok,"ExternalNFCToken"))
                                    wlWps.enaCfgMethods[j++] = IFX_MAPI_WPS_EXTERNAL_NFC_TOKEN;
                                else if(!strcmp(tok,"IntegratedNFCToken"))
                                    wlWps.enaCfgMethods[j++] = IFX_MAPI_WPS_INTEGRATED_NFC_TOKEN;
                                else if(!strcmp(tok,"NFCInterface"))
                                    wlWps.enaCfgMethods[j++] = IFX_MAPI_WPS_NFC_INTERFACE;
                                else if(!strcmp(tok,"PushButton"))
                                    wlWps.enaCfgMethods[j++] = IFX_MAPI_WPS_PUSH_BUTTON;
                                else if(!strcmp(tok,"Keypad"))
                                    wlWps.enaCfgMethods[j++] = IFX_MAPI_WPS_KEY_PAD;
                                
                                tok = strtok(NULL,", ");
                            }
                        }
                         
                        break;
                    case OID_IGD_LAND_WLANC_WPS_SETUPLOCK:
                        wlWps.setupLock = atoi(paxParamVal[i].Value);
                        break;    
                }
            }

            
            iRet = ifx_mapi_set_wlan_wps_config(iOper, &wlWps, IFX_F_MODIFY);
            if (iRet != IFX_CWMP_SUCCESS) {	
                iRet = ERR_CWMP_INTERNAL;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to set all values"
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto errorHandler;
            }  
            
            break;
        default:
            break;
    }
    return IFIN_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed!\n", __func__, __LINE__);
    return iRet;
}

/*
** =============================================================================
**   Function Name    : IFX_WlanWpsSetAttr
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/

static int32
IFX_WlanWpsSetAttr(IN OperInfo * pxOpInfo, INOUT ParamVal * pxParamVal,
                    IN int32 iElements)
{
    int32 iRet = 0;

    iRet = IFX_SetAttributesInfo(pxOpInfo, pxParamVal, iElements);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed!\n", __func__, __LINE__);
    return iRet;
}

/*
** =============================================================================
**   Function Name    : IFX_WlanWpsRegGetValue
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/


static int32
IFX_WlanWpsRegGetValue(IN OperInfo * pxOperInfo, INOUT ParamVal * paxParamVal,
                     IN uint32 iElements)
{

    uint32 i = 0;
    uint32 uiCpeid = 0;
    uint32 uiPcpeid = 0;
    int32 iRet = IFX_CWMP_SUCCESS;
    uint32 iFlags = 0, uiParamPos = 0;

    IFX_MAPI_WLAN_WPS_Regs_Cfg wlWpsReg;
    
    memset(&wlWpsReg,0x00, sizeof(IFX_MAPI_WLAN_WPS_Regs_Cfg));
    
	// Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(paxParamVal->iaOID, &uiCpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Get the pCpeid from Tr69 id
    iRet = IFX_GetParentObjCpeId(paxParamVal->iaOID, &uiPcpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Fills the Cpeid,ParentCepid,TR69Id,Owner
    iFlags = IFX_F_GET_ANY;

    // Get the WlanWpsParamPos
    uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);

    wlWpsReg.iid.cpeId.Id = uiCpeid;
    wlWpsReg.iid.pcpeId.Id = uiPcpeid;

	iRet = ifx_mapi_get_wlan_wps_registrar_config(&wlWpsReg, iFlags);
    if (iRet != IFX_CWMP_SUCCESS) {	
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get all values"
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
        goto errorHandler;
	}

    for (i = 0; i < iElements; i++)
    {
        // Malloc and assign the pointer to the Value attr of struct
        paxParamVal[i].Value = IFIN_CWMP_MALLOC(128);
        if (paxParamVal->Value == NULL)
        {
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (paxParamVal[i].iaOID[uiParamPos])
        {
            case OID_IGD_LAND_WLANC_WPS_R_ENABLE:
                sprintf(paxParamVal[i].Value,"%d", wlWpsReg.enable);
                break;
            case OID_IGD_LAND_WLANC_WPS_R_DEVICENAME:
                strcpy(paxParamVal[i].Value, wlWpsReg.regsWpsName);
                break;
            case OID_IGD_LAND_WLANC_WPS_R_UUID:
                strcpy(paxParamVal[i].Value, wlWpsReg.uuidRegs);
                break;
            default:
                break;
        }
    }

    return IFX_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed ParamId=%d !\n", __func__, __LINE__,
                paxParamVal->iaOID[uiParamPos]);
    return IFIN_CWMP_FAILURE;
}


/*
** =============================================================================
**   Function Name    : IFX_WlanWpsRegSetValue
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/
static int32
IFX_WlanWpsRegSetValue(IN OperInfo * pxOpInfo, INOUT ParamVal * paxParamVal,
                     IN int32 iElements)
{

    uint32 i = 0;
    uint32 uiCpeid = 0;
    uint32 uiPcpeid = 0;
    int32 iRet = IFX_CWMP_SUCCESS;
    uint32 iFlags = 0, uiParamPos = 0;
    
    IFX_MAPI_WLAN_WPS_Regs_Cfg wlWpsReg;
    
    memset(&wlWpsReg, 0x00, sizeof(IFX_MAPI_WLAN_WPS_Regs_Cfg));
    
    // Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(paxParamVal->iaOID, &uiCpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Get the pCpeid from Tr69 id
    iRet = IFX_GetParentObjCpeId(paxParamVal->iaOID, &uiPcpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Fills the Cpeid,ParentCepid,TR69Id,Owner
    iFlags = IFX_F_GET_ANY;

    // Get the WlanWpsParamPos
    uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);
   
    wlWpsReg.iid.cpeId.Id = uiCpeid;
    wlWpsReg.iid.pcpeId.Id = uiPcpeid;
    
    switch (pxOpInfo->iSubOper)
    {

        case OP_SETVAL_CHK_MODIFY_DEP:
            break;

        case OP_SETVAL_VALIDATE:
            break;

        case OP_SETVAL_MODIFY:
            
            iRet = ifx_mapi_get_wlan_wps_registrar_config(&wlWpsReg, iFlags);
            if (iRet != IFX_CWMP_SUCCESS) {	
            iRet = ERR_CWMP_INTERNAL;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get all values"
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto errorHandler;
            }  

            for (i = 0; i < iElements; i++)
            {
                switch (paxParamVal[i].iaOID[uiParamPos])
                {
                    case OID_IGD_LAND_WLANC_WPS_ENABLE:
                        wlWpsReg.enable = atoi(paxParamVal[i].Value);
                        break;
                    default:
                        break;
                }
            }
            
            wlWpsReg.iid.config_owner = IFX_TR69;
            
            iRet = ifx_mapi_get_wlan_wps_registrar_config(&wlWpsReg, IFX_F_MODIFY);
            if (iRet != IFX_CWMP_SUCCESS) {	
                iRet = ERR_CWMP_INTERNAL;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to set all values"
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto errorHandler;
            }  
            
            break;
        default:
            break;
    }
    return IFIN_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed!\n", __func__, __LINE__);
    return iRet;
}


/*********************************************************************************
*  Function Name :  IFX_WlanWps
*  Description   :  This function handles all the sub-states inside
                      a GET/SET operation.If it is a GET it allocates the
               array(Name,Value pairs) and retruns the values.
               If it is a SET controller allocates the array and
               passes the values to this function.It calls
               respective internal functions which in turn calls
               respective Platform APIs.

*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
                                 Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has
                                       Name,Value,etc
                    IN          int32           iElements;    No. of Elements
            OUT            void *           ppParamRet;   same as ParamStruc
            OUT         int32 *        piNumRetElem; No. of elements
*  Return Value  : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes         :
***********************************************************************************/
int32
IFX_WlanWps(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
             IN int32 iElements, OUT void **ppaxParamArrRet,
             OUT int32 * piNumRetElem)
{

    int32 iRet = 0;
    ParamVal *paxParamArr = (ParamVal *) paxParameterArr;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d SubOper=%d '%s' Elem=%d\n",
                _FUNCL_, pxOperInfo->iSubOper, (char8 *) paxParamArr[0].Name,
                iElements);

    switch (pxOperInfo->iOper)
    {
	// Get the object values
    case OP_GETVAL_NORMAL:
    case OP_GETVAL:
        if ((iRet = IFX_WlanWpsGetValue(pxOperInfo, paxParamArr,
                                         iElements)) != IFX_CWMP_SUCCESS)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
            goto errorHandler;
        }
        break;
    case OP_SETVAL:
        // Set the obj values
        switch (pxOperInfo->iSubOper)
        {
        case OP_SETVAL_VALIDATE:
        case OP_SETVAL_CHK_MODIFY_DEP:
        case OP_SETVAL_MODIFY:
            if ((iRet = IFX_WlanWpsSetValue(pxOperInfo, paxParamArr,
                                             iElements)) !=
                    IFX_CWMP_SUCCESS)
            {
                switch (pxOperInfo->iSubOper)
                {
                case OP_SETVAL_CHK_MODIFY_DEP:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d OP_SETVAL_CHK_MODIFY_DEP failed!\n",
                                __func__, __LINE__);
                    goto errorHandler;

                case OP_SETVAL_MODIFY:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d OP_SETVAL_MODIFY failed!\n",
                                __func__, __LINE__);
                    goto errorHandler;
                }
            }
            break;
        case OP_SETVAL_UNDO:
        case OP_SETVAL_COMMIT:
        case OP_SETVAL_FREE:
        case OP_SETVAL_CHK_DEL_ALLOWED:
        case OP_SETVAL_DELETE:
        case OP_SETVAL_ADD:
            iRet = IFIN_CWMP_SUCCESS;
            break;
        case OP_SETVAL_CHK_DEL_DEP:
	*ppaxParamArrRet = (ParamVal *)IFX_CWMP_MALLOC(sizeof(ParamVal));
	if(ppaxParamArrRet!=NULL)
	{
            memcpy(*ppaxParamArrRet, paxParameterArr, sizeof(ParamVal));
            *piNumRetElem = 1;
	}
	else
	{
		goto errorHandler;
	}
            break;
        case OP_SETVAL_ATTRINFO:
            if ((iRet = IFX_WlanWpsSetAttr(pxOperInfo, paxParamArr,
                                            iElements)) !=
                    IFX_CWMP_SUCCESS)
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_SETVAL_ATTRINFO failed!\n",
                            __func__, __LINE__);
                goto errorHandler;
            }
            break;
        default:
            break;
        }
        break;
    case OP_UPDATE_CHILDINFO:
        iRet = IFIN_CWMP_SUCCESS;
        break;
    case OP_PARAM_VALIDATE:
    {
        break; 
    }
    default:
        break;
    }
    return IFX_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d  WlanWps returned error!\n", _FUNCL_);
    return iRet;
}


/*********************************************************************************
*  Function Name :  IFX_WlanWpsRegistrar
*  Description   :  This function handles all the sub-states inside
                      a GET/SET operation.If it is a GET it allocates the
               array(Name,Value pairs) and retruns the values.
               If it is a SET controller allocates the array and
               passes the values to this function.It calls
               respective internal functions which in turn calls
               respective Platform APIs.

*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
                                 Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has
                                       Name,Value,etc
                    IN          int32           iElements;    No. of Elements
            OUT            void *           ppParamRet;   same as ParamStruc
            OUT         int32 *        piNumRetElem; No. of elements
*  Return Value  : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes         :
***********************************************************************************/
int32
IFX_WlanWpsRegistrar(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
             IN int32 iElements, OUT void **ppaxParamArrRet,
             OUT int32 * piNumRetElem)
{

    int32 iRet = 0;
    ParamVal *paxParamArr = (ParamVal *) paxParameterArr;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d SubOper=%d '%s' Elem=%d\n",
                _FUNCL_, pxOperInfo->iSubOper, (char8 *) paxParamArr[0].Name,
                iElements);

    switch (pxOperInfo->iOper)
    {
        // Get the object values
        case OP_GETVAL_NORMAL:
        case OP_GETVAL:
            if ((iRet = IFX_WlanWpsRegGetValue(pxOperInfo, paxParamArr,
                                         iElements)) != IFX_CWMP_SUCCESS)
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
                goto errorHandler;
            }
            break;
        case OP_SETVAL:
            // Set the obj values
            switch (pxOperInfo->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                case OP_SETVAL_CHK_MODIFY_DEP:
                case OP_SETVAL_MODIFY:
                    if ((iRet = IFX_WlanWpsRegSetValue(pxOperInfo, paxParamArr,
                                             iElements)) !=IFX_CWMP_SUCCESS)
                    {
                        switch (pxOperInfo->iSubOper)
                        {
                            case OP_SETVAL_CHK_MODIFY_DEP:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d OP_SETVAL_CHK_MODIFY_DEP failed!\n",
                                __func__, __LINE__);
                                goto errorHandler;

                            case OP_SETVAL_MODIFY:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d OP_SETVAL_MODIFY failed!\n",
                                __func__, __LINE__);
                                goto errorHandler;
                        }
                    }
                    break;
                case OP_SETVAL_UNDO:
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_FREE:
                case OP_SETVAL_CHK_DEL_ALLOWED:
                case OP_SETVAL_DELETE:
                case OP_SETVAL_ADD:
                    iRet = IFIN_CWMP_SUCCESS;
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
		    *ppaxParamArrRet = (ParamVal *)IFX_CWMP_MALLOC(sizeof(ParamVal));
		    if(ppaxParamArrRet!=NULL) {
                     	memcpy(*ppaxParamArrRet, paxParameterArr, sizeof(ParamVal));
                    	*piNumRetElem = 1;
		    }
		    else
		    {
			goto errorHandler;
		    }
                    break;
                case OP_SETVAL_ATTRINFO:
                    if ((iRet = IFX_WlanWpsSetAttr(pxOperInfo, paxParamArr,
                                            iElements)) !=IFX_CWMP_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_SETVAL_ATTRINFO failed!\n",
                            __func__, __LINE__);
                        goto errorHandler;
                    }
                    break;
                default:
                    break;
            }
        case OP_UPDATE_CHILDINFO:
            iRet = IFIN_CWMP_SUCCESS;
            break;
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
            break;
    }
    return IFX_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d  WlanWps returned error!\n", _FUNCL_);
    return iRet;
}

/*
** =============================================================================
**   Function Name    : IFX_WlanWps_Init
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/
int32
IFX_WlanWps_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the WlanWps module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_WLAN_WPS_OBJ, IFX_WlanWps);
    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "Unable to Register %s with Object Model\n",
                    IFX_WLAN_WPS_OBJ);
        goto errorHandler;
    }

    /* Register the WlanWps module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_WLAN_WPS_REG_OBJ, IFX_WlanWpsRegistrar);
    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "Unable to Register %s with Object Model\n",
                    IFX_WLAN_WPS_REG_OBJ);
        goto errorHandler;
    }

errorHandler:
    return iRet;
}

