/* 
** =============================================================================
**   FILE NAME        : IFIN_DevInfo.c
**   PROJECT          : TR69
**   MODULES          : DeviceInfo
**   DATE             : 28-03-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This is the DeviceInfo Module. It is required by the 
**                      controller module of TR69 stack to GET/SET Device
**                      specific information.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author                         $Comment
**   28-03-2006       TR69 team                       Initial Version
**
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_DevInfo.h"
  // Required for STATIC
 
#include "IFX_DEVM_OID.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_DS.h"
#include "IFX_DEVM_StackUtil.h"
#define IFX_DEVM_SYSLOG_SIZE    4

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFX_DEVINFO_OBJ    FORMNAME("DeviceInfo.")
#define IFX_DEVINFO_VENDORCONFFILE_OBJ FORMNAME("DeviceInfo.VendorConfigFile.1.")
#define VENDOR_CONF_FILE_DEPTH 5

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;
extern char8 gcaDeviceInfoProvisioningCode[64];

/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/
STATIC int32
GetVal(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
       IN int32 iElements);
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);

extern int32
ifx_get_version_info(struct ifx_version_info *st);

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/

#ifdef IFX_TR69_INFORM_DEBUG_TRACE
extern int32 giInformCnt;
#endif

extern
int32
GetTimeInACSFormat(uint32 uiTime, char8 *psBuff);
/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetVal(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
       IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iRtn = IFX_SUCCESS;
    int32   iCnt = 0, iI = 0, iLen = 0;
    DEVICE_INFO xDI;
    int32   iParamOffset;
    char8   sTmpTime[12] = {0}, *psTmp = NULL; /* Max uint32 size */
    SYSLOG_INFO xLog;
#ifdef IFX_TR69_INFORM_DEBUG_TRACE
    struct ifx_version_info ver_st;
#endif
    char8 hwver_buf[100] = {0};

    memset(&xDI, 0, sizeof(DEVICE_INFO));
    memset(&xLog, 0, sizeof(SYSLOG_INFO));
#ifdef IFX_TR69_INFORM_DEBUG_TRACE
    memset(&ver_st,0x00,sizeof(ver_st));

    iRet = ifx_get_version_info(&ver_st);
    if (iRet != IFX_SUCCESS)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get values of all "
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
        goto cleanup; 
    }
#endif

    /* Get all the DEVICE_INFO parameters using Protocol API */
    iRet = ifx_get_device_info(&xDI, IFX_F_DEFAULT);
    if (iRet != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get values of all "
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Check for error */

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamIdPos(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(MAX_DESCRIPTION_LEN);

        /* Check for error */
        if (!((pxParamVal[iCnt]).Value))
        {
            iRet = ERR_OUT_OF_MEMORY;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Allocation Failure\n",
                         __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_DI_MANUFACTURER:

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xDI.manufacturer); 
                if (pxOI->iCaller == ACC_TR64) {
                    pxParamVal[iCnt].Name = IFX_CWMP_REALLOC(pxParamVal[iCnt].Name, strlen(pxParamVal[iCnt].Name) + 10);
                    strcat(pxParamVal[iCnt].Name, "Name");
                }
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;  
            case OID_IGD_DI_MANUFACTUREROUI:  

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xDI.oui); 
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;  
            case OID_IGD_DI_MODELNAME:  

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xDI.model_name); 
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;  
            case OID_IGD_DI_DESCRIPTION:  

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xDI.description); 
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;  
            case OID_IGD_DI_PRODUCTCLASS:  

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xDI.product_class); 
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;  
            case OID_IGD_DI_SERIALNUMBER:  

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xDI.serial_number); 
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;  
            case OID_IGD_DI_HARDWAREVERSION:  

                /* Copy the value to allocated area */
#ifdef IFX_TR69_INFORM_DEBUG_TRACE
		sprintf(hwver_buf, "%s_%d_%s", ver_st.CPU, giInformCnt, xDI.hw_ver);
#else
		sprintf(hwver_buf, "%s", xDI.hw_ver);
#endif
                strcpy((pxParamVal[iCnt]).Value, hwver_buf); 
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break; 
            case OID_IGD_DI_SOFTWAREVERSION:  

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xDI.sw_ver); 
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_VALUE_BASED);
                break;  
#ifndef DEVICE_SUPPORT
            case OID_IGD_DI_MODEMFIRMWAREVERSION:  

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xDI.fw_ver); 
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_VALUE_BASED);
                break;  
            case OID_IGD_DI_SPECVERSION:  

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xDI.igd_spec_ver); 
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;  
#endif // DEVICE_SUPPORT
            case OID_IGD_DI_PROVISIONINGCODE:  

               /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xDI.provisioning_info); 
                break;  
#ifdef DEVICE_SUPPORT
            case OID_IGD_DI_DEVICESTATUS:  

               /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, "Up"); 
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_VALUE_BASED);
                break;  
#endif
            case OID_IGD_DI_UPTIME:  

                /* Get the time in string format */
                sprintf(sTmpTime,"%u",xDI.uptime);

               /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, sTmpTime); 
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_VALUE_BASED);
                break;  
            case OID_IGD_DI_DEVICELOG:

                IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
                iRtn = ifx_get_syslog_info_filter(SYSLOG_DISP_LEVEL_DEFAULT,
                                                  &xLog, IFX_F_DEFAULT);

                /* Check for error */
                if (iRtn != IFX_SUCCESS)
                {
                    iRet = ERR_CWMP_INTERNAL;
                    goto cleanup;
                }

                if(xLog.buf) {
                    iLen = strlen(xLog.buf);
                    /* Restricting the buffer to IFX_DEVM_SYSLOG_SIZE K */
                    if(iLen >= (IFX_DEVM_SYSLOG_SIZE * 1024))
                    {
                        psTmp = xLog.buf + iLen - (IFX_DEVM_SYSLOG_SIZE*1024);
                        memmove(xLog.buf, psTmp, (IFX_DEVM_SYSLOG_SIZE*1024));
                        xLog.buf[(IFX_DEVM_SYSLOG_SIZE * 1024) - 1] = '\0';
                        iLen = (IFX_DEVM_SYSLOG_SIZE * 1024) - 1;
                    }
                    for(iI = 0; iI < iLen; iI++) {
                        if((xLog.buf[iI] == '<') || (xLog.buf[iI] == '>'))
                            xLog.buf[iI] = '~';
                    }
                    (pxParamVal[iCnt]).Value = xLog.buf;
                }
                else
                    (pxParamVal[iCnt]).Value = IFX_CWMP_MALLOC(2);
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_VALUE_BASED);
                break;  
            case OID_IGD_DI_ENABLEDOPTIONS:
            case OID_IGD_DI_ADDITIONALHARDWAREVERSION:
            case OID_IGD_DI_ADDITIONALSOFTWAREVERSION:
            case OID_IGD_DI_FIRSTUSEDATE:
#ifndef DEVICE_SUPPORT
            case OID_IGD_DI_VENDORCONFIGFILENUMBEROFENTRIES:
                sprintf((pxParamVal[iCnt]).Value, "1");
                break;
#else // DEVICE_SUPPORT
                iRet = ERR_CWMP_PARAM_NOT_SUPPORTED;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Parameter Not Supported\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
#endif
            default:
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
                goto cleanup;
        }
    }

cleanup:
    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : Modify
**
**   Description      : This function modifies the values of parameters in 
**                      DeviceInfo object. It calls respective Management API  
**                      for the same. It performs modification only if parameter 
**                      has Write permission. In certain cases it also performs 
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet         = IFX_CWMP_SUCCESS;
    int32   iRtn         = IFX_SUCCESS;
    int32   iCnt         = 0;
    DEVICE_INFO xDI;
    int32   iParamOffset;

    memset(&xDI, 0, sizeof(DEVICE_INFO));

    /* Get all the DEVICE_INFO parameters using Object API */
    iRtn = ifx_get_device_info(&xDI, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_CWMP_SUCCESS)
    {

       iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get values of all "
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamIdPos(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_DI_PROVISIONINGCODE:

                /* Check if the string fits in the buffer */
                if ((strlen((pxParamVal[iCnt]).Value) + 1) > MAX_PROVISION_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }

                /* Copy the string */
    		strcpy(xDI.provisioning_info,(pxParamVal[iCnt]).Value); 
    	        /* Copy the global string */
                strcpy(gcaDeviceInfoProvisioningCode,(pxParamVal[iCnt]).Value); 
                
		break;
#ifndef DEVICE_SUPPORT
            case OID_IGD_DI_MODEMFIRMWAREVERSION:
                if (iCaller == ACC_ROOT)
                {
                    /* Check if the string fits in the buffer */
                    if ((strlen((pxParamVal[iCnt]).Value) + 1) > MAX_VER_LEN)
                    {
                        (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                        iRet = ERR_CWMP_INVAL_ARGS;
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "[%s:%s:%d] [%d] Space not enough to hold "
                                    "requested value",__FILE__, __func__,
                                    __LINE__, iRet);
                        goto cleanup;
                    }

                    /* Copy the string */
                    strcpy(xDI.fw_ver, (pxParamVal[iCnt]).Value);
                }
                else
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_NON_WRITABLE;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Cannot modify the parameter\n",
                                __FILE__, __func__, __LINE__, iRet);
                    goto cleanup;
                }
                break;
#endif // DEVICE_SUPPORT
            case OID_IGD_DI_MANUFACTURER:
            case OID_IGD_DI_MANUFACTUREROUI:
            case OID_IGD_DI_MODELNAME:
            case OID_IGD_DI_DESCRIPTION:
            case OID_IGD_DI_PRODUCTCLASS:
            case OID_IGD_DI_SERIALNUMBER:
            case OID_IGD_DI_HARDWAREVERSION:
            case OID_IGD_DI_SOFTWAREVERSION:
#ifdef DEVICE_SUPPORT
            case OID_IGD_DI_DEVICESTATUS:
#endif
#ifndef DEVICE_SUPPORT
            case OID_IGD_DI_SPECVERSION:
#endif // DEVICE_SUPPORT
            case OID_IGD_DI_UPTIME:
            case OID_IGD_DI_DEVICELOG:
                (pxParamVal[iCnt]).iFaultCode = ERR_NON_WRITABLE;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Cannot modify the parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
            case OID_IGD_DI_ENABLEDOPTIONS:
            case OID_IGD_DI_ADDITIONALHARDWAREVERSION:
            case OID_IGD_DI_ADDITIONALSOFTWAREVERSION:
            case OID_IGD_DI_FIRSTUSEDATE:
#ifndef DEVICE_SUPPORT
            case OID_IGD_DI_VENDORCONFIGFILENUMBEROFENTRIES:
#endif // DEVICE_SUPPORT
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_PARAM_NOT_SUPPORTED;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Parameter Not Supported\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;  
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

    /* Fill the iid structure in DEVICE_INFO */
    xDI.iid.config_owner = iCaller;

    /* Set all the DEVICE_INFO parameters using Object API */
    iRtn = ifx_set_device_info(IFX_OP_MOD, &xDI, IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to set values of all "
                    "parameters\n", __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : Validate
**
**   Description      : This function validates the values of parameters in
**                      DeviceInfo object.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      validated.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When validation of all parameters is
**                      successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in validating at least one parameter.
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iCnt;
    int32   iParamOffset;
    int32   iI;
    int32   iLength;
    char8   *psTmpVal = NULL;

   /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamIdPos(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and validate the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Return a failure if the value is NULL pointer */
        if (!psTmpVal)
        {
            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
            iRet = ERR_CWMP_INVAL_ARGS;
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_DI_PROVISIONINGCODE:
                /* NOTE: Currently empty string is successfully passed */
                /* Get the length of the string */
                iLength = strlen(psTmpVal);

                for (iI = 0; iI < iLength; iI += 5)
                {
                    if (((iI + 4) <= iLength) &&
                        (isdigit(psTmpVal[iI + 0]) ||
                         isupper(psTmpVal[iI + 0])) &&
                        (isdigit(psTmpVal[iI + 1]) ||
                         isupper(psTmpVal[iI + 1])) &&
                        (isdigit(psTmpVal[iI + 2]) ||
                         isupper(psTmpVal[iI + 2])) &&
                        (isdigit(psTmpVal[iI + 3]) ||
                         isupper(psTmpVal[iI + 3])))
                    {
                        if ((iI + 4) < iLength)
                        {
                            if(psTmpVal[iI + 4] == '.')
                            {
                                if ((iI + 5) != iLength)
                                {
                                    continue;
                                }
                                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                                iRet = ERR_CWMP_INVAL_ARGS;
                                goto cleanup;
                            }
                            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                            iRet = ERR_CWMP_INVAL_ARGS;
                            goto cleanup;
                        }
                        continue;
                    }
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto cleanup;
                }
                break;
            case OID_IGD_DI_MANUFACTURER:
            case OID_IGD_DI_MANUFACTUREROUI:
            case OID_IGD_DI_MODELNAME:
            case OID_IGD_DI_DESCRIPTION:
            case OID_IGD_DI_PRODUCTCLASS:
            case OID_IGD_DI_SERIALNUMBER:
            case OID_IGD_DI_HARDWAREVERSION:
            case OID_IGD_DI_SOFTWAREVERSION:
#ifdef DEVICE_SUPPORT
            case OID_IGD_DI_DEVICESTATUS:
#endif
#ifndef DEVICE_SUPPORT
            case OID_IGD_DI_MODEMFIRMWAREVERSION:
            case OID_IGD_DI_SPECVERSION:
#endif // DEVICE_SUPPORT
            case OID_IGD_DI_UPTIME:
            case OID_IGD_DI_DEVICELOG:
                /* RO params - Not validating. just returtning success */
                break;
            case OID_IGD_DI_ENABLEDOPTIONS:
            case OID_IGD_DI_ADDITIONALHARDWAREVERSION:
            case OID_IGD_DI_ADDITIONALSOFTWAREVERSION:
            case OID_IGD_DI_FIRSTUSEDATE:
#ifndef DEVICE_SUPPORT
            case OID_IGD_DI_VENDORCONFIGFILENUMBEROFENTRIES:
#endif // DEVICE_SUPPORT
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_PARAM_NOT_SUPPORTED;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Parameter Not Supported\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;  
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

cleanup:
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Validating requested parameter failed\n",
                    __FILE__, __func__, __LINE__, iRet);
    }
    return (iRet);
}


STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32   iRtn = IFX_SUCCESS;
    int32 iCnt;
    char8   sTmpTime[12] = { 0 }; /* Max uint32 size */
    DEVICE_INFO xDI;
    int32 iParamOffset;
    int32 iValueFlag = 0; /* Mandatory */

    memset(&xDI, 0, sizeof(DEVICE_INFO));

    /* Get all the DEVICE_INFO parameters using Protocol API */
    iRtn = ifx_get_device_info(&xDI, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get values of all "
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamIdPos(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Set the fault code to Success and value to NULL pointer for all parameters
       other than uptime */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
#ifndef DEVICE_SUPPORT
        if ((((pxParamVal[iCnt]).iaOID[iParamOffset]) == OID_IGD_DI_UPTIME) ||
            (((pxParamVal[iCnt]).iaOID[iParamOffset]) == OID_IGD_DI_SOFTWAREVERSION) ||
            (((pxParamVal[iCnt]).iaOID[iParamOffset]) == OID_IGD_DI_MODEMFIRMWAREVERSION))
#else //DEVICE_SUPPORT 
        if ((((pxParamVal[iCnt]).iaOID[iParamOffset]) == OID_IGD_DI_UPTIME) ||
            (((pxParamVal[iCnt]).iaOID[iParamOffset]) == OID_IGD_DI_SOFTWAREVERSION))
#endif // DEVICE_SUPPORT
        {

            if (((pxParamVal[iCnt]).iaOID[iParamOffset]) == OID_IGD_DI_UPTIME)
            {
                /* Get the time in string format */
                sprintf(sTmpTime,"%u",xDI.uptime);

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(strlen(sTmpTime) + 1);
            }

            if (((pxParamVal[iCnt]).iaOID[iParamOffset]) == OID_IGD_DI_SOFTWAREVERSION)
            {
                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(strlen(xDI.sw_ver) + 1);
            }

#ifndef DEVICE_SUPPORT
            if (((pxParamVal[iCnt]).iaOID[iParamOffset]) == OID_IGD_DI_MODEMFIRMWAREVERSION)
            {
                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(strlen(xDI.fw_ver) + 1);
            }
#endif // DEVICE_SUPPORT

            /* Check for error */
            if (!((pxParamVal[iCnt]).Value))
            {
                (pxParamVal[iCnt]).iFaultCode = ERR_OUT_OF_MEMORY;
                iRet = ERR_OUT_OF_MEMORY;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Allocation Failure\n",
                             __FILE__, __func__, __LINE__, iRet);
                    goto cleanup;
            }

            if (((pxParamVal[iCnt]).iaOID[iParamOffset]) == OID_IGD_DI_UPTIME)
            {
                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, sTmpTime); 
            }

            if (((pxParamVal[iCnt]).iaOID[iParamOffset]) == OID_IGD_DI_SOFTWAREVERSION)
            {
                strcpy((pxParamVal[iCnt]).Value, xDI.sw_ver); 
            }

#ifndef DEVICE_SUPPORT
            if (((pxParamVal[iCnt]).iaOID[iParamOffset]) == OID_IGD_DI_MODEMFIRMWAREVERSION)
            {
                strcpy((pxParamVal[iCnt]).Value, xDI.fw_ver); 
            }
#endif // DEVICE_SUPPORT

        }
        else
        {
            (pxParamVal[iCnt]).Value = NULL;
        }
    }

    /* Mark that values have been malloced */
    iValueFlag = 1;

    /* Update Attribute Information */
    iRet = IFX_SetAttributesInfo(NULL, pxParamVal, iElements);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Updating Param Attribute Info failed\n",
                    __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    /* Free the Value that has been allocated */
    if (iValueFlag)
    { 
        for (iCnt = 0; iCnt < iElements; iCnt++)
        {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
        }
    }

    return (iRet);
}

/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : IFX_DevInfo_Init
**
**   Description      : This function is called by the controller. It registers
**                      the function responsible for handling DeviceInfo object
**                      with data structure. It also performs initializations
**                      specific to DeviceInfo object.
**
**   Parameters       : No Parameters. 
**
**   Return Value     : IFX_CWMP_SUCCESS - When DeviceInfo object is initialized
**                      successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in initializing DeviceInfo object.
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_DevInfo_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the DeviceInfo module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_DEVINFO_OBJ, IFX_DevInfo);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_DEVINFO_OBJ);
        goto cleanup;
    }

    /* Register the DeviceInfo module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_DEVINFO_VENDORCONFFILE_OBJ, IFX_VendorConfFile);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_DEVINFO_VENDORCONFFILE_OBJ);
        goto cleanup;
    }

cleanup:
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_DevInfo
**
**   Description      : This function is called by the controller. It handles
**                      the DeviceInfo object and performs  based on requested
**                      operations/suboperations by invoking internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_DevInfo(IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
             OUT void **ppRet, OUT int32 *piNumRetElem)
{
    int32       iRet           = IFX_CWMP_SUCCESS;
    ParamVal    *pxParamVal    = (ParamVal *)pParamList;

    /* Process based on type of Operation */
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:

                    /* Get values of all the requested parameters */
                    iRet = GetVal(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_SETVAL:
        {
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:

                    /* Validate values of all the requested parameters */
                    iRet = Validate(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:

                    /* Check modify dependency of all requested parameters */
                    iRet = IFX_CWMP_SUCCESS;
                    break;
                case OP_SETVAL_MODIFY:

                    /* Set values of all the requested parameters */
                    iRet = Modify(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ATTRINFO:

                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_FREE:
                case OP_SETVAL_ADD:
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
                case OP_SETVAL_DELETE:
                break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD: 
                case OP_UPDATE_CHILDINFO_DEL: 
                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
        {
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid Operation\n",
                         __func__, __LINE__, iRet);
            goto cleanup;
        }
    }

cleanup:
    return (iRet);
}


static int32
IFX_VendorConfFileModify(IN int32 iCaller, INOUT ParamVal * pxPV,
                         IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    uint32 iCpeid=0;
    VEND_CONF_FILE xVConfFile;

    iRet = IFX_GetCpeId(pxPV->iaOID,&iCpeid);
    if (iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d]\n", _FUNCL_);
        goto errorHandler;
    }

    memset(&xVConfFile, 0, sizeof(xVConfFile));
    xVConfFile.iid.cpeId.Id = iCpeid;
    iRet = ifx_get_vend_conf_file(&xVConfFile, 0);
    if (iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d]\n", _FUNCL_);
        goto errorHandler;
    }

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[VENDOR_CONF_FILE_DEPTH - 1]) {
            case OID_IGD_DI_VCF_NAME:
                strcpy(xVConfFile.name, pxPV[iI].Value);
                break;
            case OID_IGD_DI_VCF_VERSION:
                strcpy(xVConfFile.version, pxPV[iI].Value);
                break;
            case OID_IGD_DI_VCF_DATE:
                strcpy(xVConfFile.date, pxPV[iI].Value);
                break;
            case OID_IGD_DI_VCF_DESCRIPTION:
                strcpy(xVConfFile.desc, pxPV[iI].Value);
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                            "Default case\n", __func__, __LINE__,
                            pxPV[iI].iaOID[VENDOR_CONF_FILE_DEPTH - 1]);
                break;
        }
    }

    iRet = ifx_set_vend_conf_file(IFX_OP_MOD, &xVConfFile, 
                       IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT);
    if (iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d]\n", _FUNCL_);
        goto errorHandler;
    }

    return IFX_CWMP_SUCCESS;
errorHandler:
    return iRet;
}


static int32
IFX_VendorConfFileGetVal(IN int32 iCaller, INOUT ParamVal * pxPV,
                         IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    uint32 iCpeid=0;
    VEND_CONF_FILE xVConfFile;

    iRet = IFX_GetCpeId(pxPV->iaOID,&iCpeid);
    if (iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d]\n", _FUNCL_);
        goto errorHandler;
    }

    memset(&xVConfFile, 0, sizeof(xVConfFile));
    xVConfFile.iid.cpeId.Id = iCpeid;
    iRet = ifx_get_vend_conf_file(&xVConfFile, 0);
    if (iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d]\n", _FUNCL_);
        goto errorHandler;
    }

    for(iI = 0; iI < iElements; iI++) {
        pxPV[iI].Value = IFX_CWMP_MALLOC(PARAMVALUE_LEN + 1);
        if(pxPV[iI].Value == NULL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", __func__, __LINE__);
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (pxPV[iI].iaOID[VENDOR_CONF_FILE_DEPTH - 1]) {
            case OID_IGD_DI_VCF_NAME:
                sprintf(pxPV[iI].Value, "%s", xVConfFile.name);
                break;
            case OID_IGD_DI_VCF_VERSION:
                sprintf(pxPV[iI].Value, "%s", xVConfFile.version);
                break;
            case OID_IGD_DI_VCF_DATE:
                if(!(strcmp(xVConfFile.date,"")))
                    GetTimeInACSFormat(0, xVConfFile.date);
                sprintf(pxPV[iI].Value, "%s", xVConfFile.date);
                break;
            case OID_IGD_DI_VCF_DESCRIPTION:
                sprintf(pxPV[iI].Value, "%s", xVConfFile.desc);
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                            "Default case\n", __func__, __LINE__,
                            pxPV[iI].iaOID[VENDOR_CONF_FILE_DEPTH - 1]);
                break;
        }
    }
errorHandler:
    return iRet;
}

static int32
IFX_VendorConfFileAdd(IN int32 iCaller, INOUT ParamVal * pxPV,
                       IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    VEND_CONF_FILE xVConfFile;

    memset(&xVConfFile, 0, sizeof(xVConfFile));
    xVConfFile.iid.config_owner = iCaller;
    iRet = IFX_ConvertOidDottedForm(pxPV->iaOID, xVConfFile.iid.tr69Id);
    if (iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d]\n", _FUNCL_);
        goto errorHandler;
    }

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[VENDOR_CONF_FILE_DEPTH - 1]) {
            case OID_IGD_DI_VCF_NAME:
                strcpy(xVConfFile.name, pxPV[iI].Value);
                break;
            case OID_IGD_DI_VCF_VERSION:
                strcpy(xVConfFile.version, pxPV[iI].Value);
                break;
            case OID_IGD_DI_VCF_DATE:
                strcpy(xVConfFile.date, pxPV[iI].Value);
                break;
            case OID_IGD_DI_VCF_DESCRIPTION:
                strcpy(xVConfFile.desc, pxPV[iI].Value);
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                            "Default case\n", __func__, __LINE__,
                            pxPV[iI].iaOID[VENDOR_CONF_FILE_DEPTH - 1]);
                break;
        }
    }

    iRet = ifx_set_vend_conf_file(IFX_OP_ADD, &xVConfFile, 
                       IFX_F_DONT_VALIDATE | IFX_F_DONT_CHECKPOINT);
    if (iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d]\n", _FUNCL_);
        goto errorHandler;
    }

    return IFX_CWMP_SUCCESS;
errorHandler:
    return iRet;
}


static int32
IFX_VendorConfFileDelete(IN OperInfo *pxOI, INOUT ParamVal * pxPV,
                       IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    uint32 iCpeid;
    VEND_CONF_FILE xVConfFile;

    iRet = IFX_GetCpeId(pxPV->iaOID,&iCpeid);
    if (iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d]\n", _FUNCL_);
        goto errorHandler;
    }

    memset(&xVConfFile, 0, sizeof(xVConfFile));
    xVConfFile.iid.cpeId.Id = iCpeid;
    iRet = ifx_get_vend_conf_file(&xVConfFile, 0);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] "
               "ifx_get_vend_conf_file() failed\n", __func__, __LINE__, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }

    switch(pxOI->iSubOper) {
        case OP_SETVAL_CHK_DEL_ALLOWED:
            break;
        case OP_SETVAL_DELETE:
            xVConfFile.iid.config_owner = pxOI->iCaller;
            xVConfFile.iid.cpeId.Id = iCpeid;
            memset(xVConfFile.iid.tr69Id, 0x00, MAX_TR69_ID_LEN);
            iRet = ifx_set_vend_conf_file(IFX_OP_DEL, &xVConfFile,
              IFX_F_DELETE | IFX_F_DONT_VALIDATE | IFX_F_DONT_CHECKPOINT);
            if(iRet != IFX_SUCCESS) {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d]\n",
                                            _FUNCL_);
                goto errorHandler;
            }
            break;
        default:
            break;
    }

    return IFX_CWMP_SUCCESS;
errorHandler:
    return iRet;
}


/* 
** =============================================================================
**   Function Name    : IFX_VendorConfFile
**
**   Description      : This function is called by the controller. It handles
**                      the DeviceInfo object and performs  based on requested
**                      operations/suboperations by invoking internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_VendorConfFile(IN OperInfo *pxOI, INOUT void *pParamStruct, 
           IN int32 iElements, OUT void **ppRet, OUT int32 *piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;
    ParamVal    *pxVal;
    uint32 uiParamPos=0;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "%s: %s oper=%d maxElement=%d\n",
                __func__, xpParamVal[0].Name, pxOI->iSubOper, iElements);

    switch(pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                    iRet = IFX_VendorConfFileGetVal(pxOI->iCaller, xpParamVal, 
                                                                   iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_GETVAL_NOTIFICATION:
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                    if (pxOI->iCaller != ACC_ROOT) {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                               "%s:%d [%d] Not writable.\n", __func__,
                                __LINE__, pxOI->iSubOper);
                        iRet = ERR_NON_WRITABLE;
                        goto errorHandler;
                    }
                    break;
                case OP_SETVAL_ADD:
                    if (pxOI->iCaller != ACC_ROOT) {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                               "%s:%d [%d] Not writable.\n", __func__,
                                __LINE__, pxOI->iSubOper);
                        iRet = ERR_NON_WRITABLE;
                        goto errorHandler;
                    }
                    iRet = IFX_VendorConfFileAdd(pxOI->iCaller, xpParamVal, 
                                                                iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:
                    break;
                case OP_SETVAL_MODIFY:
                     if (pxOI->iCaller != ACC_ROOT) {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                               "%s:%d [%d] Not writable.\n", __func__,
                                __LINE__, pxOI->iSubOper);
                        iRet = ERR_NON_WRITABLE;
                        goto errorHandler;
                    }
                    iRet = IFX_VendorConfFileModify(pxOI->iCaller, xpParamVal,
                                                                iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_SETVAL_ACTIVATE:
                case OP_SETVAL_COMMIT:
                    break;
                case OP_SETVAL_UNDO:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                    pxVal= (void *)IFX_CWMP_MALLOC (sizeof(ParamVal));
                    uiParamPos = IFX_GetParamIdPos(xpParamVal->iaOID);
                    memcpy(pxVal->iaOID,xpParamVal->iaOID,(sizeof(int32)*(uiParamPos+1)));
                    *ppRet = (void*) pxVal;
                    *piNumRetElem = 1;
                    break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    break;
                case OP_SETVAL_DELETE:
                    if (pxOI->iCaller != ACC_ROOT) {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                               "%s:%d [%d] Not writable.\n", __func__,
                                __LINE__, pxOI->iSubOper);
                        iRet = ERR_NON_WRITABLE;
                        goto errorHandler;
                    }
                    iRet = IFX_VendorConfFileDelete(pxOI, xpParamVal, 
                                                                iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_ATTRINFO:
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                    break;
                case OP_UPDATE_CHILDINFO_DEL:
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break;
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                        "Default case\n", __func__, __LINE__, pxOI->iOper);
            break;
        }
    }
errorHandler:
    return iRet;
}


void IFX_UpdateVendorCfgFile(IN char8 *psName, IN char8 *psTime)
{
    char8 psPartialObj[CWMP_OBJ_NOLEAF_LEN];
    int32 iRtn = IFX_CWMP_SUCCESS;
    char version[32] = {0} , version_tmp[32] = {0};

	sprintf(psPartialObj,
					"InternetGatewayDevice.DeviceInfo.VendorConfigFile.1.Name");
	iRtn = ifx_config_set_value(psPartialObj, psName);
	if (iRtn != IFX_CWMP_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%s]", __func__,
						__LINE__, psPartialObj);
		goto errorHandler;
	}

	sprintf(psPartialObj,
					"InternetGatewayDevice.DeviceInfo.VendorConfigFile.1.Date");
	iRtn = ifx_config_set_value(psPartialObj, psTime);
	if (iRtn != IFX_CWMP_SUCCESS) {
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%s]", __func__,
						__LINE__, psPartialObj);
		goto errorHandler;
	}
        sprintf(psPartialObj,
                                        "InternetGatewayDevice.DeviceInfo.VendorConfigFile.1.Description");
        iRtn = ifx_config_set_value(psPartialObj, "Configuration File");
        if (iRtn != IFX_CWMP_SUCCESS) {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%s]", __func__,
                                                __LINE__, psPartialObj);
                goto errorHandler;
        }

        iRtn = ifx_get_cfgfile_version(version_tmp);
        if (iRtn != IFX_CWMP_SUCCESS) {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%s]", __func__,
                                                __LINE__, psPartialObj);
                goto errorHandler;
        }
        sscanf(version_tmp , " %s" , version);
        sprintf(psPartialObj,
                                        "InternetGatewayDevice.DeviceInfo.VendorConfigFile.1.Version");
        iRtn = ifx_config_set_value(psPartialObj, version);
        if (iRtn != IFX_CWMP_SUCCESS) {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%s]", __func__,
                                                __LINE__, psPartialObj);
                goto errorHandler;
        }

errorHandler:
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s:%d", __func__, __LINE__);
	return;
}

