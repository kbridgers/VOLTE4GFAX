/*
 * ** =============================================================================
 * ** FILE NAME   : IFX_DEVM_UserInfo.c
 * ** PROJECT     : TR157
 * ** MODULES     : InternetGatewayDevice.UserInterface.
                    InternetGatewayDevice.UserInterface.RemoteAccess.
                    InternetGatewayDevice.User.{i}.
 * ** DATE        :
 * ** AUTHOR      : TR157 team
 * ** DESCRIPTION : AddObject / DeleteObject cannot be performed on this object.
 * **
 * ** REFERENCES  :
 * ** Any use of this software is subject to the conclusion of a respective
 * ** License agreement. Without such a License agreement no rights to the
 * ** software are granted
 * **
 * ** HISTORY     :
 * ** $Date       $Author        $Comment
 * **             TR157 team      Creation
 * ** =============================================================================
 * */


#include "IFX_DEVM_Global.h"

#include "IFX_DEVM_AdaptCommon.h"
#include <time.h>

#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_StackUtil.h"
#include <resolv.h>

extern char8 vcOsModId;

#define FIREWALL_OBJ                      FORMNAME("Firewall.")
#define IFX_UTC_TIME_LEN              65




/*
** =============================================================================
**   Function Name    : GetParamOffset
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/

STATIC int32
GetTimeInACSFormat(uint32 uiTime, char8 *psBuff)
{

              IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d]  Time uiTime is:[%d]\n",
                    __FILE__, __func__, __LINE__, uiTime);

 /* TBD: Get the UTC time */   

	struct tm *rc_tm;
	char time_str[200];
	time_t t_time;
	
	
	t_time = uiTime;

	rc_tm = localtime(&t_time);

	sprintf(time_str, "%d-%.2d-%.2dT%.2d:%.2d:%.2d", (rc_tm->tm_year) + 1900,(rc_tm->tm_mon) + 1,rc_tm->tm_mday,rc_tm->tm_hour,rc_tm->tm_min,rc_tm->tm_sec);

	strcpy(psBuff,time_str); 
    return (IFX_CWMP_SUCCESS);
}
STATIC int32 GetParamOffset(IN int32 *paiOID)

{
    int32 iCnt;

    for (iCnt = 0; paiOID[iCnt] != 0; iCnt++);

    return (iCnt - 1);
}

STATIC int32 GetNotify(IN OperInfo * pxOI, INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iCnt = 0;

    for(iCnt = 0; iCnt < iElements; iCnt++) {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
        (pxParamVal[iCnt]).Value = NULL;
    }

    return (iRet);
}

STATIC int32 SetAttrInfo(IN OperInfo * pxOI, INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iCnt;

    /* Set the fault code to Success */
    for(iCnt = 0; iCnt < iElements; iCnt++) {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
    }

    /* Get the offset of the parameter */
    IFX_GetParamIdPos(pxParamVal->iaOID);

    for(iCnt = 0; iCnt < iElements; iCnt++) {
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Update Attribute Information */
    iRet = IFX_SetAttributesInfo(NULL, pxParamVal, iElements);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Updating Param Attribute Info failed\n",
                    __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    return (iRet);
}


/*******************************************************************************
* Function: IFX_FirewallSetValue
* Desc:
*
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_FirewallSetValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                             IN int32 iElements)
{
    uint32  iCnt = 0;
    int32 iRet = IFX_SUCCESS , iParamOffset = 0;
    IFX_MAPI_Firewall xFirewall;
    int32 iFlags = IFX_F_DEFAULT;
    char8 config[4][8] = {"Off", "Low", "Medium", "High"};
    int i = 0;

    memset(&xFirewall, 0x00, sizeof(xFirewall));

    if((ifx_mapi_get_firewall_status(&xFirewall,IFX_F_DEFAULT)) != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d mapi_get_firewall() failed.\n", _FUNCL_);
        iRet = IFX_FAILURE;
        goto end;
    }

   /* Get the offset of the parameter */
   iParamOffset = GetParamOffset(pxPV->iaOID);
   if (iParamOffset < 0)
   {
       IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s:%d GetParamOffset returned < 0.\n", _FUNCL_);
       iRet = ERR_CWMP_INTERNAL;
       goto end;
   }

   for( iCnt=0; iCnt<iElements; iCnt++)
   {
       switch(pxPV[iCnt].iaOID[iParamOffset])
       {
           case OID_IGD_F_CONFIG:
               for(i= 0; i<4; i++)
               {
                   if(strcmp(pxPV[iCnt].Value, config[i]) == 0)
			xFirewall.enable = i;
               }
               break;

           default:
               IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,pxOI->iSubOper);
       }
   }
   iFlags= (IFX_F_MODIFY | IFX_F_DONT_WRITE_TO_FLASH);

   iRet = ifx_mapi_set_firewall_status(&xFirewall, iFlags);
   if(iRet != IFX_SUCCESS)
   {
       IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d ifx_mapi_set_firewall_status() failed.\n", _FUNCL_);
       iRet = IFX_FAILURE;
       goto end;
   }

end:
   return iRet;
}

/*******************************************************************************
 * * Function: IFX_FirewallGetValue
 * * Desc: 
 * *              
 * * Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
static int32
IFX_FirewallGetValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                             IN int32 iElements)
{
    uint32  iCnt = 0;
    int32 iRet = IFX_SUCCESS , iParamOffset = 0;
    IFX_MAPI_Firewall xFirewall;
    char8 config[4][8] = {"Off", "Low", "Medium", "High"};
    char8 sTmpTime[IFX_UTC_TIME_LEN] = {0};

    memset(&xFirewall, 0x00, sizeof(xFirewall));

    if((ifx_mapi_get_firewall_status(&xFirewall,IFX_F_DEFAULT)) != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d mapi_get_firewall() failed.\n", _FUNCL_);
        iRet = IFX_FAILURE;
        goto end;
    }

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxPV->iaOID);
    if (iParamOffset < 0)
    {
    	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s:%d GetParamOffset returned < 0.\n", _FUNCL_);
        iRet = ERR_CWMP_INTERNAL;
        goto end;
    }
	

    for(iCnt=0; iCnt<iElements; iCnt++)
    {
        // Malloc and assign the pointer to the Value attr of struct
       (pxPV[iCnt]).Value = IFX_CWMP_MALLOC(IFX_UTC_TIME_LEN);
       if(pxPV[iCnt].Value == NULL)
       {
           IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d MALLOC FAILED.\n", _FUNCL_);
           iRet = ERR_OUT_OF_MEMORY;
           goto end;
       }
       switch(pxPV[iCnt].iaOID[iParamOffset])
       {
           case OID_IGD_F_CONFIG:
               sprintf(pxPV[iCnt].Value , "%s" , config[xFirewall.enable]);
               break;

           case OID_IGD_F_VERSION:
               sprintf(pxPV[iCnt].Value , "%s" , xFirewall.version);
               break;

           case OID_IGD_F_LASTCHANGE:
               /* Get the time in format required by ACS */
               GetTimeInACSFormat(xFirewall.lastchange_time, sTmpTime);
               strncpy(pxPV[iCnt].Value , sTmpTime, IFX_UTC_TIME_LEN);
               break;

           default:
               IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"%s:%d"
                                "[%d] Error! Default case.\n", _FUNCL_,pxOI->iSubOper);
               break;
       }
   } 
end:
   return iRet;
}


 /*******************************************************************************
 * * Function: IFX_Firewall
 * * Desc: 
 * *              
 * * Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
 * *             OUT void **ppRet, OUT int32 * piNumRetElem
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
int32 IFX_Firewall(IN OperInfo * pxOI,
                            INOUT void *pParamStruct,
                            IN int32 iElements, OUT void **ppRet,
                            OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                    iRet = IFX_FirewallGetValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d IFX_FirewallGetValue failed.\n", _FUNCL_);
                        goto errorHandler;
                    }
                    break;

                case OP_GETVAL_NOTIFICATION:
                {
                    iRet = GetNotify(pxOI, xpParamVal, iElements);
                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS)
                    {
                        goto errorHandler;
                    }
                    break;
                }


                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,pxOI->iOper);
                    break;
            }
            break;
        }
	case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                case OP_SETVAL_CHK_MODIFY_DEP:
                case OP_SETVAL_ACTIVATE:
                     break;

                case OP_SETVAL_MODIFY:
                    iRet = IFX_FirewallSetValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d IFX_RemoteAccessSetValue() failed.\n", _FUNCL_);
                        goto errorHandler;
                    }
                    break;

                case OP_SETVAL_ATTRINFO:
                    iRet = SetAttrInfo(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d SetAttrInfo() failed.\n", _FUNCL_);
                        goto errorHandler;
                    }
                    break;
                 

                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
		case OP_SETVAL_DELETE:
		    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    break;

                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,pxOI->iSubOper);
                                
                    break;
            }
            break;
        }
	case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                case OP_UPDATE_CHILDINFO_DEL:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break;
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d [%d] Error! Default case.\n", _FUNCL_, pxOI->iOper);
                        
            break;
        }
    }
errorHandler:
    if (iRet != IFX_CWMP_SUCCESS)
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d failed.\n", _FUNCL_);

    return iRet;
}


/*******************************************************************************
 * * Function: IFX_FirewallInit 
 * * Desc: Will register itself with DS.
 * * Parameters:  
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
int32 IFX_TR157_FirewallInit()
{
    int32 iRet = IFX_CWMP_SUCCESS;
    
    iRet = ifx_ds_register_function(FIREWALL_OBJ, IFX_Firewall);
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Unable to Register %s with Object Model\n",
                    _FUNCL_, iRet, FIREWALL_OBJ);
	goto errorHandler;
    }   

errorHandler:
    return iRet;
}
