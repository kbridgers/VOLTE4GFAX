/*
** =============================================================================
** FILE NAME      : IFX_LANEthernetIfConfigStats.c
** PROJECT        : TR69
** MODULES        : IGD.LANDevice.1.LANEthernetInterfaceConfig.1.Stats.
** DATE           : 15-Jun-2006
** AUTHOR         : TR69 team
** DESCRIPTION    : This object is RO. SetParameterValues or AddObject cannot be
**                  performed on this object.
** REFERENCES     :  
** COPYRIGHT      : Copyright (c) 2006
**                  Infineon Technologies AG
**                  Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
** HISTORY        : 
** $Date        $Author          $Comment
** 15-Jun-2006  Tr69 team        Creation
** =============================================================================
*/

#include "IFX_DEVM_Global.h"
 
#include "IFX_DEVM_AdaptCommon.h"
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"

extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char8 * obj, modFunc pifx_module_func);

#define IFX_WEICSTATS_OBJ    "InternetGatewayDevice.WANDevice.1.WANEthernetInterfaceConfig.Stats."
#define WEICSTATS_DEPTH  5

#ifdef MIPSTARGET
#define QUERY_INTERFACE         "br0"
#else
#define QUERY_INTERFACE         "eth0"
#endif

/*******************************************************************************
* Function: IFX_WEICStatsSetAttrInfo
* Description: Sets attribute information in the respective tr69 sections
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_WEICStatsSetAttrInfo(IN int32 iCaller, INOUT ParamVal * pxPV,
                         IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    iRet = IFX_SetAttributesInfo(NULL, pxPV, iElements);

    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Updating Param Attribute Info failed\n",
                    __func__, __LINE__, iRet);
        goto errorHandler;
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_WEICStatsGetValue
* Description: Hard coding it to br0 interface. An enhancement on this can be 
*              performed. 
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
#define   WAN_STATS_GET_ALLOC                12
static int32 IFX_WEICStatsGetValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                                                          IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    IF_STATS xIfStats;
#ifdef MIPSTARGET
    struct ifx_phyportstats_info xPort;
    int nodeNum = 0;
#endif /* MIPSTARGET */

#ifdef MIPSTARGET
    /* Memset the port structure to zero */
    memset(&xPort, 0x00, sizeof(xPort));
#endif /* MIPSTARGET */

    memset(&xIfStats, 0x00, sizeof(IF_STATS));

#ifdef MIPSTARGET
    /* Get the values for the requested instance */
    if((pxPV->iaOID[2]) == WAN_DEVICE_MII0) //IGD.WD.2.
    {
        nodeNum = 1;
    }
    else if((pxPV->iaOID[2]) == WAN_DEVICE_MII1) //IGD.WD.3.
    {
        nodeNum = 0;
    }
    ifx_get_phyportstats_info(3, &xPort, nodeNum);

    xIfStats.tx_pkts = xPort.txPktCnt;
    xIfStats.rx_pkts = xPort.rxPktCnt;
    xIfStats.tx_bytes = xPort.txByteCnt;
    xIfStats.rx_bytes = xPort.rxByteCnt;
#else
/*    if((pxPV->iaOID[2]) == WAN_DEVICE_MII0) //IGD.WD.2.
    {
        iTmp = ifx_get_if_stats(QUERY_INTERFACE, &xIfStats, 0);
        if(iTmp != IFX_SUCCESS)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] ifx_get_if_stats"
                    " failed %s\n", __func__, __LINE__, iTmp, QUERY_INTERFACE);
            iRet = ERR_CWMP_INTERNAL;
            goto errorHandler;
        }
    }
    else if((pxPV->iaOID[2]) == WAN_DEVICE_MII1) //IGD.WD.3.
    {
    }*/
    xIfStats.tx_pkts = 10;
    xIfStats.rx_pkts = 20;
    xIfStats.tx_bytes = 30;
    xIfStats.rx_bytes = 40;

#endif /* MIPSTARGET */

    for(iI = 0; iI < iElements; iI++)
    {
        pxPV[iI].Value = IFX_CWMP_MALLOC(WAN_STATS_GET_ALLOC + 1);
        if(pxPV[iI].Value == NULL)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", __func__, __LINE__);
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (pxPV[iI].iaOID[WEICSTATS_DEPTH])
        {
            case OID_IGD_WAND_WANEIC_S_BYTESSENT:
                sprintf(pxPV[iI].Value, "%lu", xIfStats.tx_bytes);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;

            case OID_IGD_WAND_WANEIC_S_BYTESRECEIVED:
                sprintf(pxPV[iI].Value, "%lu", xIfStats.rx_bytes);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;

            case OID_IGD_WAND_WANEIC_S_PACKETSSENT:
                sprintf(pxPV[iI].Value, "%lu", xIfStats.tx_pkts);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;

            case OID_IGD_WAND_WANEIC_S_PACKETSRECEIVED:
                sprintf(pxPV[iI].Value, "%lu", xIfStats.rx_pkts);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;

            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", __func__,
                            __LINE__, pxPV[iI].iaOID[WEICSTATS_DEPTH - 1]);
                break;
        }
    }
errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_WEICStatsValidate
* Description: Since this is a Stats obj, only read is allowed. SetValidate will
*              be called befor SETVAL is actually called. It returns err for 
*              each SETVAL being called.
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32 IFX_WEICStatsValidate(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;

    for(iI = 0; iI < iElements; iI++)
    {
        switch (pxPV[iI].iaOID[WEICSTATS_DEPTH - 1])
        {
            case OID_IGD_WAND_WANEIC_S_BYTESSENT:
            case OID_IGD_WAND_WANEIC_S_BYTESRECEIVED:
            case OID_IGD_WAND_WANEIC_S_PACKETSSENT:
            case OID_IGD_WAND_WANEIC_S_PACKETSRECEIVED:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE_PARAM;
                break;

            default:
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", __func__,
                            __LINE__, pxPV[iI].iaOID[WEICSTATS_DEPTH - 1]);
                break;
        }
    }
    return iRet;
}

/*******************************************************************************
* Function: IFX_WANEthernetIfCfgStats
* Description: This function is registered with the data model. Handles on 
*              GETVAL. For all other returns err code.
* Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
*             OUT void **ppRet, OUT int32 * piNumRetElem
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32 IFX_WANEthernetIfCfgStats(IN OperInfo * pxOI, INOUT void *pParamStruct,
                          IN int32 iElements, OUT void **ppRet,
                          OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS, iCnt = 0;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;


    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                    iRet = IFX_WEICStatsGetValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                    {
                        goto errorHandler;
                    }
                    break;
                case OP_GETVAL_NOTIFICATION:
                    iRet = IFX_WEICStatsGetValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                    {
                        goto errorHandler;
                    }
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                    if((iRet = IFX_WEICStatsValidate(xpParamVal, iElements)) != 0)
                    {
                        goto errorHandler;
                    }
                    break;
                case OP_SETVAL_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:
                    break;
                case OP_SETVAL_MODIFY:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_COMMIT:
                    break;
                case OP_SETVAL_UNDO:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_DELETE:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_ATTRINFO:
                    iRet = IFX_WEICStatsSetAttrInfo(pxOI->iCaller, pParamStruct,
                                                    iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                    {
                        goto errorHandler;
                    }
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_UPDATE_CHILDINFO_DEL:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            if((xpParamVal->iaOID[2]) == WAN_DEVICE_ATM) //IGD.WD.1.
            {
                /* Set the fault code to Error */
                for(iCnt = 0; iCnt < iElements; iCnt++)
                {
                    xpParamVal[iCnt].iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
                }
            }
            break; 
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d [%d] Error! Default case\n", __func__,
                        __LINE__, pxOI->iOper);
            break;
        }
    }
errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_WANEthernetIfCfgStatsInit
* Description: Initialize some data structures, register itself with 
*              DS.
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32 IFX_WANEthernetIfCfgStatsInit()
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* TBD: Perform any WANEthernetIfCfgStatsInit related initializations here */

    /* Register the IFX_WANEthernetIfCfgStatsInit func ptr in the object model */
    iRet = ifx_ds_register_function(IFX_WEICSTATS_OBJ, IFX_WANEthernetIfCfgStats);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d Unable to Register %s with Object Model\n",
                    __func__, __LINE__, IFX_WEICSTATS_OBJ);
        goto errorHandler;
    }

errorHandler:
    return iRet;
}
