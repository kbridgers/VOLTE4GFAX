/*
** =============================================================================
** FILE NAME   : IFX_LAN.c
** PROJECT     : TR111
** MODULES     : Device.LAN.
** DATE        : 09-Jan-2007
** AUTHOR      : TR111 team
** DESCRIPTION : This object is RO. SetParameterValues or AddObject cannot be
**               performed on this object.
** REFERENCES  :  
** COPYRIGHT   : Copyright (c) 2006
**               Infineon Technologies AG
**               Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY     : 
** $Date       $Author       $Comment
** 09-Jan-2007 TR111 team    Creation         
** =============================================================================
*/
#include "IFX_DEVM_Global.h"
 
#include "IFX_DEVM_AdaptCommon.h"
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
 

extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char *obj, modFunc pifx_module_func);
static int32
IFX_LAN_UpdateChildInfo(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal, IN int32 iElements);

#define LAN_OBJ           FORMNAME("LAN.")
#define LAN_DEPTH         3

/*******************************************************************************
* Function: IFX_LAN_SetAttrInfo
* Description: Sets attribute information in the respective tr69 sections
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_LAN_SetAttrInfo(IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    iRet = IFX_SetAttributesInfo(NULL, pxPV, iElements);

    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Updating Param Attribute Info failed\n",
                    __func__, __LINE__, iRet);
        goto errorHandler;
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_LAN_GetNotifyValue
* Description: 
*              
* Parameters: IN OperInfo *pxOI, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
#if 0
static int32
IFX_LAN_GetNotifyValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                        IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[LAN_DEPTH - 1]) {
            case OID_IGD_LAN_ADDRESSINGTYPE:
                break;
            case OID_IGD_LAN_IPADDRESS:
                break;
            case OID_IGD_LAN_SUBNETMASK:
                break;
            case OID_IGD_LAN_DEFAULTGATEWAY:
                break;
            case OID_IGD_LAN_DNSSERVERS:
                break;
            case OID_IGD_LAN_MACADDRESS:
                break;
            case OID_IGD_LAN_MACADDRESSOVERRIDE:
                break;
            case OID_IGD_LAN_DHCPOPTIONNUMBEROFENTRIES:
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                            "Default case\n", __func__, __LINE__,
                            pxPV[iI].iaOID[LAN_DEPTH - 1]);
                break;
        }
    }
    return iRet;
}
#endif

/*******************************************************************************
* Function: IFX_LAN_GetValue
* Description: Hard coding it to br0 interface. An enhancement on this can be 
*              performed. 
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
#define    MAC_ADDR_SIZE                20
static int32
// IFX_LAN_GetValue(IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElements)
IFX_LAN_GetValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0, iTmp = 0, iNum = 0;
    int32 iRtn = IFX_SUCCESS;
    IP_MASK_TYPE *pxIPMask;
    char sDNSTemp1[MAC_ADDR_SIZE] = {0};
    char sDNSTemp2[MAC_ADDR_SIZE] = {0};
    uint32 uiNumDHCPOption = 0;

    iTmp = ifx_get_lan_ip_mask("br0", &iNum, &pxIPMask, 0);
    if(iTmp != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] get_lan_ip_mask() failed\n",
                    __func__, __LINE__, iTmp);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
 
    for(iI = 0; iI < iElements; iI++) {
        pxPV[iI].Value = IFX_CWMP_MALLOC(MAC_ADDR_SIZE*2);
        if(pxPV[iI].Value == NULL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", __func__, __LINE__);
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (pxPV[iI].iaOID[LAN_DEPTH - 1]) {
            case OID_IGD_LAN_ADDRESSINGTYPE:
                /* ACS expects one of there values: 'Static', 'DHCP, 'AutoIP' */
                if(pxIPMask->ip_type == IP_TYPE_STATIC)
                    strcpy(pxPV[iI].Value, "Static");
                else if(pxIPMask->ip_type == IP_TYPE_DHCP)
                    strcpy(pxPV[iI].Value, "DHCP");
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_LAN_IPADDRESS:
                inet_ntop(AF_INET, &pxIPMask[0].ip_mask.ip, pxPV[iI].Value,
                          IPADDR_LEN);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI,
                                         IFX_CHK_CHANGE_FLAG_BASED);
                break;
            case OID_IGD_LAN_SUBNETMASK:
                inet_ntop(AF_INET, &pxIPMask[0].ip_mask.mask, pxPV[iI].Value,
                          IPADDR_LEN);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI,
                                         IFX_CHK_CHANGE_FLAG_BASED);
                break;
            case OID_IGD_LAN_DEFAULTGATEWAY:
                inet_ntop(AF_INET, &pxIPMask[0].gw, pxPV[iI].Value,
                          IPADDR_LEN);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI,
                                         IFX_CHK_CHANGE_FLAG_BASED);
                break;

            case OID_IGD_LAN_DNSSERVERS:
                inet_ntop(AF_INET, &pxIPMask[0].dns_servers[0], sDNSTemp1,
                          IPADDR_LEN);
	         inet_ntop(AF_INET, &pxIPMask[0].dns_servers[1], sDNSTemp2,
                          IPADDR_LEN);
	
		strcat(sDNSTemp1, ",");
		strcat(sDNSTemp1, sDNSTemp2);
		strcpy(pxPV[iI].Value, sDNSTemp1);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI,
                                         IFX_CHK_CHANGE_FLAG_BASED);
                break;

            case OID_IGD_LAN_MACADDRESS:
#ifdef MIPSTARGET
                ifx_mod_get_lan_mac(pxPV[iI].Value);
#else
                strcpy(pxPV[iI].Value, "08:11:11:11:11:11");
#endif
                break;
            case OID_IGD_LAN_MACADDRESSOVERRIDE:
                strcpy(pxPV[iI].Value, "0");
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_LAN_DHCPOPTIONNUMBEROFENTRIES:
	        iRtn = ifx_get_dhcp_option_count(&uiNumDHCPOption);
                if(iRtn != IFX_SUCCESS)
                {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] ifx_get_all_dhcp_option returned failure\n",
                                __FILE__,  __func__, __LINE__, iRtn);
                    iRet = ERR_CWMP_INTERNAL;
                    goto errorHandler;
                }

                sprintf(pxPV[iI].Value, "%d", uiNumDHCPOption);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_CHANGE_FLAG_BASED);
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                            "Default case\n", __func__, __LINE__,
                            pxPV[iI].iaOID[LAN_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_LAN_Validate
* Description:
*              
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_LAN_Validate(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[LAN_DEPTH - 1]) {
            case OID_IGD_LAN_ADDRESSINGTYPE:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            case OID_IGD_LAN_IPADDRESS:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            case OID_IGD_LAN_SUBNETMASK:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            case OID_IGD_LAN_DEFAULTGATEWAY:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            case OID_IGD_LAN_DNSSERVERS:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            case OID_IGD_LAN_MACADDRESS:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            case OID_IGD_LAN_MACADDRESSOVERRIDE:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            case OID_IGD_LAN_DHCPOPTIONNUMBEROFENTRIES:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                            "Default case\n", __func__, __LINE__,
                            pxPV[iI].iaOID[LAN_DEPTH - 1]);
                break;
        }
    }
    return iRet;
}

static int32
IFX_LAN_UpdateChildInfo(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal, IN int32 iElements)
{

	//For both ADD & DEL 
	//Check whether WanIPC or WanPPPC
	//Send notification
	uint32 i=0,iRet=0;
	char8 usSecTag[MAX_SECTIONTAG]={0};
	char8 usParamTag[MAX_PARAMTAG]={0};
	uint32 uiParamPos=0,uiChildObjId=0;
	uint32 uiCpeid=0;
	int32 *iaOID=NULL;
	uint32 uiNumNV=1;
	//IFX_CpeId pxCpeId;
	IFX_Id xIfx_Id;
	IFX_NameValue pxNVArray;
	uint32 uiOper=IFX_NOTIFY_OPER_MODIFY;
	ParamVal *pxTempParamVal=pxParamVal;
	
		//memset the structs
		memset(&xIfx_Id,0x00,sizeof(xIfx_Id));
		memset(&pxNVArray,0x00,sizeof(pxNVArray));

		//Get Cpeid
		iRet = IFX_GetCpeId(pxTempParamVal->iaOID, &uiCpeid);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;

		//Get the child object Oid
		uiChildObjId = IFX_GetParamIdPos((int32 *)pxTempParamVal->pReserved);
		iaOID = (int32 *)pxTempParamVal->pReserved;


		for(i=0; i < iElements; i++)

		{
			//Get the Param Oid of this object
			uiParamPos= IFX_GetParamIdPos(pxTempParamVal->iaOID);
			
			switch(pxTempParamVal->iaOID[uiParamPos])
			{
				case OID_IGD_LAN_DHCPOPTIONNUMBEROFENTRIES:
					if(iaOID[uiChildObjId-1] ==	OID_IGD_LAN_DHCPO)
					{
						//Get the section and Paramtag
						iRet=IFX_GetSectionParamTag(pxTempParamVal->psRCTag, usParamTag, 
															usSecTag);
						if(iRet != IFX_CWMP_SUCCESS)
							goto errorHandler;

						xIfx_Id.uiConfigOwner= pxOpInfo->iCaller;
						xIfx_Id.xCpeId.uiId= uiCpeid;
						strcpy(xIfx_Id.xCpeId.sSectionTag,usSecTag);
						strcpy(pxNVArray.sName,usParamTag);

												
						iRet=IFX_SendNotify(&xIfx_Id, uiNumNV, 
												&pxNVArray, uiOper);
						if(iRet != IFX_CWMP_SUCCESS)
						{
						IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d UpdatechildInfo IFX_SendNotify failed!\n", __func__, __LINE__);
							goto errorHandler;
						}
					}
					break;
				
								
				default:
					break;
					
	
			}
			pxTempParamVal++;
			
		}

		return IFX_CWMP_SUCCESS;
		
	errorHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d failed!\n", __func__, __LINE__);
		return IFX_CWMP_FAILURE;
		
}


/*******************************************************************************
* Function: IFX_LAN
* Description: 
*              
* Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
*             OUT void **ppRet, OUT int32 * piNumRetElem
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_LAN(IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
           OUT void **ppRet, OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s: %s oper=%d maxElement=%d\n",
                __func__, xpParamVal[0].Name, pxOI->iSubOper, iElements);

    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            iRet = IFX_LAN_GetValue(pxOI, xpParamVal, iElements);
            if(iRet != IFX_CWMP_SUCCESS)
                goto errorHandler;
            break;
        }
        case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                    if((iRet = IFX_LAN_Validate(xpParamVal, iElements)) != 0) {
                        goto errorHandler;
                    }
                    break;
                case OP_SETVAL_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:
                    break;
                case OP_SETVAL_MODIFY:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_COMMIT:
                    break;
                case OP_SETVAL_UNDO:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
                case OP_SETVAL_DELETE:
                    break;
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_ATTRINFO:
                    IFX_LAN_SetAttrInfo(pxOI->iCaller, pParamStruct, iElements);
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            //Updation of child related info is handled by the case
            switch(pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                case OP_UPDATE_CHILDINFO_DEL:
                    if((iRet = IFX_LAN_UpdateChildInfo(pxOI, xpParamVal,iElements)) != IFX_CWMP_SUCCESS)
                    {
		        switch(pxOI->iSubOper)
                        {	
                            case OP_UPDATE_CHILDINFO_ADD:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                   	    "%s:%d OP_UPDATE_CHILDINFO_ADD failed!\n", __func__, __LINE__);
                                 goto errorHandler;
						
                            case OP_UPDATE_CHILDINFO_DEL:
                    	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_UPDATE_CHILDINFO_DEL failed!\n", __func__, __LINE__);
                                goto errorHandler;

                        }

                    }	
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break;
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                        "Default case.\n", __func__, __LINE__, pxOI->iOper);
            break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_LAN_Init
* Description: Will initialize some of its data structures, register itself with 
*              DS.
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_LAN_Init()
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Perform any other LAN related initializations here */

    /* Register the IFX_LAN func ptr in the object model */
    iRet = ifx_ds_register_function(LAN_OBJ, IFX_LAN);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Unable to "
                    "Register %s with Object Model\n", __func__, __LINE__, iRet,
                    LAN_OBJ);
        goto errorHandler;
    }

  errorHandler:
    return iRet;
}
