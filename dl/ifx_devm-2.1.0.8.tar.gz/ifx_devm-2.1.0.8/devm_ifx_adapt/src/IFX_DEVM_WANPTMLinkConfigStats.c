/* 
** =============================================================================
**   FILE NAME        : IFX_DEVM_WANPTMLinkConfigStats.c
**   PROJECT          : TR69
**   MODULES          : WanPTMLinkConfig Stats
**   DATE             : 10-07-2010
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This module handles GET RPC of 
**                      WanPTMLinkConfigStats. When controller calls this module it
**                      calls respective Platform/Object APIs to handle GET of
**                      WanPTMLinkConfig Stats for specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author        $Comment
**   10-07-2010      TR69 team      Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_Global.h"
#include "IFX_DEVM_AdaptCommon.h"
#include <ctype.h>
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
 
//#include <fcntl.h>
//#include <unistd.h>
#include "IFX_DEVM_DS.h"
#include "IFX_DEVM_StackUtil.h"


/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;
int32 IFX_WanPTMLinkConfigStats(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                IN int32 iElements, OUT void **ppaxParamArrRet, OUT int32 *piNumRetElem);
#define IFX_PTM_STATS_OBJ   "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPTMLinkConfig.Stats."
/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/




/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/

/* 
** =============================================================================
**   Function Name    : GetParamOffset
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

static int32
GetParamOffset(IN int32 *paiOID)
{
    int32 iCnt;

    for (iCnt = 0; paiOID[iCnt] != 0; iCnt++);

    return (iCnt - 1);
}


/* 
** =============================================================================
**   Function Name    : IFX_DelObj
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
DelObj(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
				IN int32 iElements, OUT void **ppxParamStructRet,
							   OUT int32 * piNumRetElem)
{
	return IFX_CWMP_SUCCESS;
#if 0
	int32 iRet=0;
	uint32 uiOper;
	uint32 uiParamPos;
	int32 iaOID[OID_LENGTH];
	char8 Tr69_str[MAX_NAME_LEN];
	char8 usSecTag[IFX_MAX_SECTION_TAG_LEN];
	char8 usParamTag[IFX_MAX_NAME_LEN];
	uint32 uiCpeid;
	IFX_Id pxIfxId;

	memset(iaOID, 0x00, (sizeof(int32)*OID_LENGTH));
	
	if(pxOpInfo->iSubOper == OP_SETVAL_DELETE)
	{
		//Get the Position of the Param Id
		uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);
		memcpy(iaOID,paxParamVal->iaOID,(sizeof(int32)* (uiParamPos-1)));
		
		//Get the Parent Obj Cpeid
		iRet = IFX_GetCpeId(iaOID,&uiCpeid);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;
		
		//Get the SectionName 
		iRet=IFX_GetSectionParamTag(paxParamVal->psRCTag, usParamTag, usSecTag);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;
			
		//Convert Tr69_id into dotted form
		iRet = IFX_ConvertOidDottedForm(paxParamVal->iaOID, Tr69_str);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;
		
		//Call Protocol API to update the Mapping
		uiOper = IFX_TR69ID_MAP_TBL_OPER_DEL_ENTRY;
		pxIfxId.xCpeId.uiId = uiCpeid;
		strcpy(pxIfxId.xCpeId.sSectionTag,usSecTag);
		strcpy(pxIfxId.sTr69Id,Tr69_str);
		
		iRet = IFX_UpdateTr69CpeIdMap(&pxIfxId, uiOper);

                /* This is a hack. Currently this is invoked twice from web, due to which it fails for
                   second time. We are neglecting the return type. */
                iRet = IFX_CWMP_SUCCESS;

	}
	return IFIN_CWMP_SUCCESS;

errorHandler:
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d failed!\n", __func__, __LINE__);
	return IFIN_CWMP_FAILURE;
#endif
}
/* 
** =============================================================================
**   Function Name    : AddObj
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 AddObj(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{
	return IFX_CWMP_SUCCESS;

#if 0
	/* This API calls a Platform API which adds the object
	** in ADD_DISABLE state.
	** Pass necessary flags to the API
	** Controller should get the next instance id from DS 
    	** module and pass the full OID to this module.
	*/
		
	/* If Cisco proposal comes, this API should handle 
	**  a) Validation of values
	**  b) Forward mapping of TR69 values to system values 
	**  c) addition of object into the system
	*/
	
	int32 iRet = 0;
	uint32 uiOper = 0;
	uint32 uiParamPos = 0;
	int32 iaOID[OID_LENGTH] = { 0 };
	char8 Tr69_str[MAX_NAME_LEN] = { 0 };
	char8 usSecTag[IFX_MAX_SECTION_TAG_LEN] = { 0 };
	char8 usParamTag[IFX_MAX_NAME_LEN] = { 0 };
	uint32 uiCpeid = 0;
	IFX_Id pxIfxId;

	//Get the Position of the Param Id
	uiParamPos = IFX_GetParamIdPos(pxParamVal->iaOID);
	memset(iaOID,0x00,(sizeof(int32)*OID_LENGTH));
	memcpy(iaOID,pxParamVal->iaOID,(sizeof(int32)* (uiParamPos-1)));
	
	//Get the Parent Obj Cpeid
	iRet = IFX_GetObjCpeId(iaOID,&uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	//Get the SectionName 
	iRet=IFX_GetSectionParamTag(pxParamVal->psRCTag, usParamTag, usSecTag);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
		
	//Convert Tr69_id into dotted form
	iRet = IFX_ConvertOidDottedForm(pxParamVal->iaOID, Tr69_str);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	//Call Protocol API to update the Mapping
	uiOper = IFX_TR69ID_MAP_TBL_OPER_ADD_ENTRY;
	pxIfxId.xCpeId.uiId = uiCpeid;
	strcpy(pxIfxId.xCpeId.sSectionTag,usSecTag);
	strcpy(pxIfxId.sTr69Id,Tr69_str);
	
	iRet = IFX_UpdateTr69CpeIdMap(&pxIfxId, uiOper);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	return IFIN_CWMP_SUCCESS;

errorHandler:
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d failed!\n", __func__, __LINE__);
	return IFIN_CWMP_FAILURE;
#endif
}



/* 
** =============================================================================
**   Function Name    : IFX_WanPTMStatsGetValue
**   Description        : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes                : 
**
** ============================================================================
*/
static int32 
IFX_WanPTMStatsGetValue(IN OperInfo *pxOperInfo,INOUT ParamVal *pxGetParamVal,
								IN uint32 iElements)
{
    uint32 i=0;
    int32 iParamId=0;
    int32 uiParamPos=0;
    int32 iRet=0,  WanConnFound=0;
    uint32 wan_conn_cpeid = 0;
    uint32 uiMode=IFX_CHK_VALUE_BASED, uiOutElem=0;
    int32 iaOID[OID_LENGTH];
    char8 sTmpBuff[65]={0};
    int32 Wan_IP_Oid[OID_LENGTH]={0, 0, 0, 0, 0, OID_IGD_WAND_WANCD_WANIPC, MAGIC_NUMBER, OID_IGD_WAND_WANCD_WANIPC_ENABLE};
    int32 Wan_PPP_Oid[OID_LENGTH]={0, 0, 0, 0, 0, OID_IGD_WAND_WANCD_WANPPPC, MAGIC_NUMBER, OID_IGD_WAND_WANCD_WANPPPC_ENABLE};
    ParamVal xInParamVal;
    ParamVal *paxOutParamArr=NULL;
    IF_STATS iface_stats;
    IFX_ID wanconn_iid;

    memset(&iface_stats, 0x00, sizeof(IF_STATS));
              	

    /* Get the offset of the parameter */
    uiParamPos = GetParamOffset(pxGetParamVal->iaOID);
    if (uiParamPos < 0)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"%s:%d !\n", __func__, __LINE__);
        iRet = ERR_CWMP_INTERNAL; 
        goto errorHandler;
    }
    /*Check any WAN IP/PPP connection exists below this WCD*/
    memset(&xInParamVal, 0x00, sizeof(ParamVal));
    memcpy(xInParamVal.iaOID, Wan_IP_Oid, (sizeof(int32)*OID_LENGTH));
    //Copy the OID from ParamVal
    memcpy(xInParamVal.iaOID, pxGetParamVal->iaOID, (sizeof(int32)*(WAN_CON_DEV_DEPTH +1)));
                   
    //Get the WanIPConn object
    iRet=IFX_GlobalGetVal(&xInParamVal, &paxOutParamArr, &uiOutElem);
    if(iRet != IFX_CWMP_SUCCESS) 
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"%s:%d No IP Connections !\n", __func__, __LINE__);
        IFX_PrintOID(xInParamVal.iaOID);
        IFX_FreeParamvalArr(&paxOutParamArr, uiOutElem);
        iRet = IFX_CWMP_SUCCESS;
    }
    /**Get the object from the system using a Platform API with cpeid */
    if(paxOutParamArr != NULL)
    {
        memcpy(iaOID, paxOutParamArr->iaOID, (sizeof(int32)*OID_LENGTH));
        //Get the Cpeid from Tr69 id
        iRet = IFX_GetCpeId(iaOID, &wan_conn_cpeid);
        if(iRet != IFX_CWMP_SUCCESS)
        {
            IFX_PrintOID(iaOID);
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"%s:%d ERROR: CpeId not found!\n", __func__, __LINE__);
            goto errorHandler;
        }
        WanConnFound=1;
        strcpy(wanconn_iid.cpeId.secName,"wan_ip"); 
    }
    else
    {
        memset(&xInParamVal, 0x00, sizeof(ParamVal));
        memcpy(xInParamVal.iaOID, Wan_PPP_Oid, (sizeof(int32)*OID_LENGTH));
        //Copy the OID from ParamVal
        memcpy(xInParamVal.iaOID, pxGetParamVal->iaOID, (sizeof(int32)*(WAN_CON_DEV_DEPTH +1)));
                   
        //Get the WanPPPConn object
        iRet=IFX_GlobalGetVal(&xInParamVal, &paxOutParamArr, &uiOutElem);
        if(iRet != IFX_CWMP_SUCCESS) 
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"%s:%d No PPP Connections !\n", __func__, __LINE__);
            IFX_PrintOID(xInParamVal.iaOID);
            IFX_FreeParamvalArr(&paxOutParamArr, uiOutElem);
            iRet = IFX_CWMP_SUCCESS;
        }
        /**Get the object from the system using a Platform API with cpeid */
        if(paxOutParamArr != NULL)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"%s:%d !\n", __func__, __LINE__);
            memcpy(iaOID, paxOutParamArr->iaOID, (sizeof(int32)*OID_LENGTH));
            //Get the Cpeid from Tr69 id
            iRet = IFX_GetCpeId(iaOID, &wan_conn_cpeid);
            if(iRet != IFX_CWMP_SUCCESS)
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"%s:%d !\n", __func__, __LINE__);
                IFX_PrintOID(xInParamVal.iaOID);
                goto errorHandler;
            }
            WanConnFound=1;
            strcpy(wanconn_iid.cpeId.secName,"wan_ppp"); 
        }
    }
    if(WanConnFound == 1)
    {
        wanconn_iid.cpeId.Id = wan_conn_cpeid;
        iRet = ifx_get_wan_if_stats(&wanconn_iid, -1, NULL, &iface_stats,IFX_F_GET_ANY);
	    if(iRet != IFX_SUCCESS)
	    {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"%s:%d !\n", __func__, __LINE__);
                goto errorHandler;
            }
    }
    for(i=0;i < iElements; i++)
    {
        iParamId = pxGetParamVal->iaOID[uiParamPos];
	
        // Malloc and assign the pointer to the Value attr of struct 
        pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
        if(pxGetParamVal->Value == NULL)
        {
            iRet = ERR_OUT_OF_MEMORY; 
            goto errorHandler;
        }
        memset(sTmpBuff,0x00,sizeof(sTmpBuff));
	switch(iParamId)
	{
            case OID_IGD_WAND_WANCD_WANPTMLC_S_BYTESSENT:
                sprintf(pxGetParamVal->Value, "%lu", iface_stats.tx_bytes);
                //sprintf(sTmpBuff, "%l", iface_stats.tx_bytes);
                //strcpy(pxGetParamVal->Value,sTmpBuff);				
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANCD_WANPTMLC_S_BYTESRECEIVED:
                sprintf(pxGetParamVal->Value, "%lu", iface_stats.rx_bytes);
                //sprintf(sTmpBuff, "%l", iface_stats.rx_bytes);
                //strcpy(pxGetParamVal->Value,sTmpBuff);				
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANCD_WANPTMLC_S_FRAMESSENT:
                sprintf(sTmpBuff, "%lu", iface_stats.tx_pkts);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANCD_WANPTMLC_S_FRAMESRECEIVED:
                sprintf(sTmpBuff, "%lu", iface_stats.tx_pkts);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANCD_WANPTMLC_S_ERRORSSENT:
                sprintf(sTmpBuff, "%lu", iface_stats.tx_error_pkts);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANCD_WANPTMLC_S_ERRORSRECEIVED:
                sprintf(sTmpBuff, "%lu", iface_stats.rx_error_pkts);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANCD_WANPTMLC_S_DISCARDPACKETSSENT:
                sprintf(sTmpBuff, "%lu", iface_stats.tx_discard_pkts);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANCD_WANPTMLC_S_DISCARDPACKETSRECEIVED:
                sprintf(sTmpBuff, "%lu", iface_stats.rx_discard_pkts);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANCD_WANPTMLC_S_OOSNEAREND:
            case OID_IGD_WAND_WANCD_WANPTMLC_S_OOSFAREND:
            case OID_IGD_WAND_WANCD_WANPTMLC_S_UNICASTPACKETSSENT:
            case OID_IGD_WAND_WANCD_WANPTMLC_S_UNICASTPACKETSRECEIVED:
            case OID_IGD_WAND_WANCD_WANPTMLC_S_MULTICASTPACKETSSENT:
            case OID_IGD_WAND_WANCD_WANPTMLC_S_MULTICASTPACKETSRECEIVED:
            case OID_IGD_WAND_WANCD_WANPTMLC_S_BROADCASTPACKETSSENT:
            case OID_IGD_WAND_WANCD_WANPTMLC_S_BROADCASTPACKETSRECEIVED:
            case OID_IGD_WAND_WANCD_WANPTMLC_S_UNKNOWNPROTOPACKETSRECEIVED:
                strcpy(pxGetParamVal->Value,"0");
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;	 
	
            default:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "Invalid param id %d!\n", iParamId);
                goto errorHandler; 
        }
	++pxGetParamVal;
    }

errorHandler:
    IFX_FreeParamvalArr(&paxOutParamArr, uiOutElem);
    if(iRet != IFX_CWMP_SUCCESS)
	    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"%s:%d Get Value Failed !\n", __func__, __LINE__);
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanPTMStatsSetAttr
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

static int32
IFX_WanPTMStatsSetAttr(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{
    uint32 iRet=IFX_CWMP_SUCCESS,i=0;
    OperInfo xOpInfo;
	
    xOpInfo.iCaller = pxOpInfo->iCaller;
    xOpInfo.iOper= OP_GETVAL;
    xOpInfo.iSubOper= OP_GETVAL_NORMAL;
	
    iRet = IFX_WanPTMStatsGetValue(&xOpInfo,pxParamVal, iElements);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorFreeHandler;
	
    iRet = IFX_SetAttributesInfo(pxOpInfo,pxParamVal, iElements);
    if(iRet != IFX_CWMP_SUCCESS)
    	goto errorFreeHandler;

errorFreeHandler:
    for(i=0; i < iElements; i++)
        IFX_CWMP_FREE(pxParamVal[i].Value);
		
    if (iRet)
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanPTMLinkConfigStats_Init
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_WanPTMLinkConfigStats_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the WanPTMLinkConfig Stats module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_PTM_STATS_OBJ, IFX_WanPTMLinkConfigStats);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "Unable to Register %s with Object Model\n",
                 IFX_PTM_STATS_OBJ);
        goto errorHandler;
    }

errorHandler:
    return iRet;
}

/*********************************************************************************
*  Function Name	:  IFX_WanPTMLinkConfigStats   
*  Description	        :  This function handles all the sub-states inside
      	 		   a GET/SET operation.If it is a GET it allocates the 
			   array(Name,Value pairs) and returns the values.
			   If it is a SET, the function returns error.
                           It calls respective internal functions which in turn
                           calls respective Platform APIs.
                                                                                                 
*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
							     Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has 
					  	             Name,Value,etc
                    IN          int32	       iElements;    No. of Elements
		    OUT	        void *	       ppParamRet;   same as ParamStruc
		    OUT         int32 *        piNumRetElem; No. of elements 		                                
*  Return Value        : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes               :
***********************************************************************************/
int32 IFX_WanPTMLinkConfigStats(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                IN int32 iElements, OUT void **ppaxParamArrRet, OUT int32 *piNumRetElem)
{
    int32 iRet = 0;
    ParamVal *paxParamArr = (ParamVal *)paxParameterArr;
    int32 iCnt = 0;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"%s:%d Oper[%d:%d] !\n", __func__, __LINE__, pxOperInfo->iOper, pxOperInfo->iSubOper);
    switch (pxOperInfo->iOper) 
    {
        //Get the object values
        case OP_GETVAL:
	    if((iRet = IFX_WanPTMStatsGetValue(pxOperInfo, paxParamArr,
					iElements)) != IFX_CWMP_SUCCESS)
            {
	       IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                       "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
	        goto errorHandler;
            }
            break;

        case OP_SETVAL:
        {
            //Set the obj values
            switch (pxOperInfo->iSubOper) 
            {
                case OP_SETVAL_ATTRINFO:
                    if((iRet =IFX_WanPTMStatsSetAttr(pxOperInfo, paxParamArr,
  	               								iElements)) != IFX_CWMP_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d OP_SETVAL_ATTRINFO failed!\n", __func__, __LINE__);
                        goto errorHandler;
                    }
                    break;
		case OP_SETVAL_ADD:
                    if((iRet= AddObj(pxOperInfo,paxParamArr, iElements))!=IFX_CWMP_SUCCESS)
                    {
                         IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                        "%s:%d OP_SETVAL_ADD failed!\n", __func__, __LINE__);
                         goto errorHandler;
                    }
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
		    *ppaxParamArrRet = (ParamVal *)IFX_CWMP_MALLOC(sizeof(ParamVal));
		    if(ppaxParamArrRet!=NULL)
		    {
                       memcpy(*ppaxParamArrRet, paxParameterArr, sizeof(ParamVal));
                       *piNumRetElem = 1;
		    }
		    else
		    {
			goto errorHandler;
		    }
                    break;

		 case OP_SETVAL_DELETE:
		    if((iRet= DelObj(pxOperInfo, paxParamArr,
		    					iElements, ppaxParamArrRet,
		    					piNumRetElem))!= IFX_CWMP_SUCCESS) 
	    	    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            	"%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
	             }
                     break;
                default:
                {
                    goto errorHandler;
                }
            }
            break;
        }

        case OP_PARAM_VALIDATE:
        {
            //IGD.WD.2. or IGD.WD.3.
            if(((paxParamArr->iaOID[2]) == WAN_DEVICE_MII0) || ((paxParamArr->iaOID[2]) == WAN_DEVICE_MII1))
            {
                /* Set the fault code to Error */
                for(iCnt = 0; iCnt < iElements; iCnt++)
                {
                    paxParamArr[iCnt].iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
                }
                goto errorHandler;
            }
            else if((paxParamArr->iaOID[2]) == WAN_DEVICE_ATM)
            {
                /*IGD.WD.1.WCD.1 is for PTMLC*/
                if((paxParamArr->iaOID[4]) != 1)
                {
            	    /* Set the fault code to Error */
    	            for(iCnt = 0; iCnt < iElements; iCnt++)
                    {
            	        paxParamArr[iCnt].iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
                    }
	            goto errorHandler;
                }
            }
            break; 
        }

        default:
	    break;
    }

errorHandler:
    return iRet;
}
 
