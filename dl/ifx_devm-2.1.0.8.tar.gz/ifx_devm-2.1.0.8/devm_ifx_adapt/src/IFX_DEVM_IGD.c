/*
** =============================================================================
** FILE NAME   : IFX_InternetGatewayDevice.c
** PROJECT     : TR69
** MODULES     : InternetGatewayDevice.
** DATE        : 19-Jun-2006
** AUTHOR      : TR69 team
** DESCRIPTION : This object is RO. SetParameterValues or AddObject cannot be
**               performed on this object.
** REFERENCES  :  
** COPYRIGHT   : Copyright (c) 2006
**               Infineon Technologies AG
**               Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY     : 
** $Date       $Author       $Comment
** 19-Jun-2006 TR69 team     Creation         
** =============================================================================
*/
#include "IFX_DEVM_Global.h"
 
#include "IFX_DEVM_AdaptCommon.h"
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"

extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char *obj, modFunc pifx_module_func);

#define INTERNETGATEWAYDEVICE_OBJ   "InternetGatewayDevice."
#define INTERNETGATEWAYDEVICE_DEPTH 2
/*******************************************************************************
* Function: IFX_IGD_SetAttrInfo
* Description: Sets attribute information in the respective tr69 sections
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_IGD_SetAttrInfo(IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    iRet = IFX_SetAttributesInfo(NULL, pxPV, iElements);

    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Updating Param Attribute Info failed\n",
                    __func__, __LINE__, iRet);
        goto errorHandler;
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_IGD_GetNotifyValue
* Description: 
*              
* Parameters: IN OperInfo *pxOI, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_IGD_GetNotifyValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                       IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    char8 sTmp[3] = { 0 };

    for(iI = 0; iI < iElements; iI++) {
        pxPV[iI].Value = IFX_CWMP_MALLOC(512);
        if(pxPV[iI].Value == NULL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", __func__, __LINE__);
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (pxPV[iI].iaOID[INTERNETGATEWAYDEVICE_DEPTH - 1]) {
            case OID_IGD_DEVICESUMMARY:
#if defined(DEVICE_ASSO_SUPPORT) || defined(STUN_SUPPORT)
                strcpy(pxPV[iI].Value, "InternetGatewayDevice:1.5[](Baseline:1");
#else
                strcpy(pxPV[iI].Value, "InternetGatewayDevice:1.1[](Baseline:1");
#endif
#ifdef IFX_TR157_SELFTEST 
                strcat(pxPV[iI].Value, ", SelfTestDiag:1");
#endif
#ifdef IFX_TR157_PROCESSSTATUS
                strcat(pxPV[iI].Value, ", ProcessStatus:1");
#endif
#ifdef IFX_TR157_MEMORYSTATUS
                strcat(pxPV[iI].Value, ", MemoryStatus:1");
#endif
#ifdef IFX_TR157_NSLOOKUP
                strcat(pxPV[iI].Value, ", NSLookupDiag:1");
#endif
#ifdef IFX_TR157_FIREWALL
                strcat(pxPV[iI].Value, ", SimpleFirewall:1");
#endif
#ifdef IFX_TR157_USERINFO
                strcat(pxPV[iI].Value, ", User:1");
#endif
#ifdef IFX_TR69_ETHERNETLAN
                strcat(pxPV[iI].Value, ", EthernetLAN:2");
#endif
#ifdef IFX_TR69_USBLAN
                strcat(pxPV[iI].Value, ", USBLAN:1");
#endif
#ifdef IFX_TR69_WIFILAN
                strcat(pxPV[iI].Value, ", WiFiLAN:1");
#endif
#ifdef IFX_TR69_WIFILAN_WMM
                strcat(pxPV[iI].Value, ", WiFiWMM:1");
#endif
#ifdef IFX_TR69_WIFILAN_WPS
                strcat(pxPV[iI].Value, ", WiFiWPS:1");
#endif
#ifdef IFX_TR69_ADSLWAN
                strcat(pxPV[iI].Value, ", ADSLWAN:1");
#endif
#ifdef IFX_TR69_ADSL2WAN
                strcat(pxPV[iI].Value, ", ADSL2WAN:1");
#endif
#ifdef IFX_TR69_VDSL2WAN
                strcat(pxPV[iI].Value, ", VDSL2WAN:1");
#endif
#ifdef IFX_TR69_TIME
                strcat(pxPV[iI].Value, ", Time:1");
#endif
#ifdef IFX_TR69_IPQOS
                strcat(pxPV[iI].Value, ", QoS:1");
#endif
#ifdef IFX_TR69_ETHERNETWAN
                strcat(pxPV[iI].Value, ", EthernetWAN:1");
#endif
#ifdef IFX_TR69_PTMWAN
                strcat(pxPV[iI].Value, ", PTMWAN:1");
#endif
#ifdef IFX_TR69_IPPING
                strcat(pxPV[iI].Value, ", IPPing:1");
#endif
#ifdef IFX_TR69_TRACEROUTE
                strcat(pxPV[iI].Value, ", TraceRoute:1");
#endif
#ifdef IFX_TR143_DOWNLOADDIAGNOSTICS
                strcat(pxPV[iI].Value, ", Download:1");
#endif
#ifdef IFX_TR143_UPLOADDIAGNOSTICS
                strcat(pxPV[iI].Value, ", Upload:1");
#endif
#ifdef IFX_TR143_DOWNLOADDIAGNOSTICS
                strcat(pxPV[iI].Value, ", DownloadTCP:1");
#endif
#ifdef IFX_TR143_UPLOADDIAGNOSTICS
                strcat(pxPV[iI].Value, ", UploadTCP:1");
#endif
#ifdef IFX_TR69_ATMLOOPBACK
                strcat(pxPV[iI].Value, ", ATMLoopback:1");
#endif
#ifdef IFX_TR69_DSLDIAGNOSTICS
                strcat(pxPV[iI].Value, ", DSLDiagnostics:1");
#endif
#ifdef IFX_TR69_ADSL2DSLDIAGNOSTICS
                strcat(pxPV[iI].Value, ", ADSL2DSLDiagnostics:1");
#endif
#ifdef IFX_TR69_VDSL2DSLDIAGNOSTICS
                strcat(pxPV[iI].Value, ", VDSL2DSLDiagnostics:1");
#endif
#ifdef DEVICE_ASSO_SUPPORT
                strcat(pxPV[iI].Value, ", DeviceAssociation:1");
#endif
#ifdef STUN_SUPPORT
                strcat(pxPV[iI].Value, ", UDPConnReq:1");
#endif
                // modules present by default
                strcat(pxPV[iI].Value, ", DHCPCondServing:1");

                strcat(pxPV[iI].Value, ")");
#ifdef IFX_TR104
                strcat(pxPV[iI].Value,
                       ", VoiceService:1.0[1](SIPEndpoint:1, TAEndpoint:1)");
#endif

                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_LANDEVICENUMBEROFENTRIES:
                sprintf(sTmp, "%d", 1);
                strcpy(pxPV[iI].Value, sTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_CHANGE_FLAG_BASED);
                break;
            case OID_IGD_WANDEVICENUMBEROFENTRIES:
                sprintf(sTmp, "%d", 1);
                strcpy(pxPV[iI].Value, sTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_CHANGE_FLAG_BASED);
                break;
            case OID_IGD_USERNUMBEROFENTRIES:
                sprintf(sTmp, "%d", 2);
                strcpy(pxPV[iI].Value, sTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_CHANGE_FLAG_BASED);
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                            "Default case\n", __func__, __LINE__,
                            pxPV[iI].iaOID[INTERNETGATEWAYDEVICE_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_IGD_Validate
* Description:
*              
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_IGD_Validate(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[INTERNETGATEWAYDEVICE_DEPTH - 1]) {
            case OID_IGD_DEVICESUMMARY:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            case OID_IGD_LANDEVICENUMBEROFENTRIES:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            case OID_IGD_WANDEVICENUMBEROFENTRIES:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            case OID_IGD_USERNUMBEROFENTRIES:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                            "Default case\n", __func__, __LINE__,
                            pxPV[iI].iaOID[INTERNETGATEWAYDEVICE_DEPTH - 1]);
                break;
        }
    }
    return iRet;
}

/*******************************************************************************
* Function: IFX_InternetGatewayDevice
* Description: 
*              
* Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
*             OUT void **ppRet, OUT int32 * piNumRetElem
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_InternetGatewayDevice(IN OperInfo * pxOI, INOUT void *pParamStruct,
                          IN int32 iElements, OUT void **ppRet,
                          OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "%s: %s oper=%d maxElement=%d\n",
                __func__, xpParamVal[0].Name, pxOI->iSubOper, iElements);

    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                    iRet = IFX_IGD_GetNotifyValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_GETVAL_NOTIFICATION:
                    iRet = IFX_IGD_GetNotifyValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error"
                                "! Default case.\n", __func__, __LINE__,
                                pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                    if((iRet = IFX_IGD_Validate(xpParamVal, iElements)) != 0) {
                        goto errorHandler;
                    }
                    break;
                case OP_SETVAL_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:
                    break;
                case OP_SETVAL_MODIFY:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_COMMIT:
                    break;
                case OP_SETVAL_UNDO:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_DELETE:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_ATTRINFO:
                    IFX_IGD_SetAttrInfo(pxOI->iCaller, pParamStruct, iElements);
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_UPDATE_CHILDINFO_DEL:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                        "Default case.\n", __func__, __LINE__, pxOI->iOper);
            break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_IGD_Init
* Description: Will initialize some of its data structures, register itself with 
*              DS.
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_IGD_Init()
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Perform any other IGD related initializations here */

    /* Register the IFX_InternetGatewayDevice func ptr in the object model */
    iRet = ifx_ds_register_function(INTERNETGATEWAYDEVICE_OBJ,
                                    IFX_InternetGatewayDevice);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Unable to "
                    "Register %s with Object Model\n", __func__, __LINE__, iRet,
                    INTERNETGATEWAYDEVICE_OBJ);
        goto errorHandler;
    }

  errorHandler:
    return iRet;
}
