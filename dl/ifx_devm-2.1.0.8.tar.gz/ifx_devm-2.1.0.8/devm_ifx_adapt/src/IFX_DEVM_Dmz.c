/*
** =============================================================================
**   FILE NAME        : IFIN_Dmz.c
**   PROJECT          : TR69
**   MODULES          : X_INFINEON_COM_DMZ
**   DATE             : 28-03-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This is the X_INFINEON_COM_DMZ Module. It is required by the
**                      controller module of TR69 stack to GET/SET DMZ parameters.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          :
**   $Date            $Author                         $Comment
**   28-03-2006       TR69 team                       Initial Version
**
** ============================================================================
*/
/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_Global.h"
 
#include "IFX_DEVM_AdaptCommon.h"
#include "IFX_DEVM_OID.h"
 
#include "IFX_DEVM_Platform.h"
#include "ifx_api_include.h"

#include <resolv.h>
#include <ctype.h>


/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFIN_DMZ_OBJ    FORMNAME("X_LTQ_FIREWALL.DMZ.")
/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/
/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;
/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

static int32
IFX_Firewall_DmzSetAttrInfo(IN OperInfo * pxOpInfo, INOUT ParamVal * pxPV, IN int32 iElements);
static int32
IFX_Firewall_DmzGetValue(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);
static int32
IFX_Firewall_DmzModify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements);
/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS>
**
** =============================================================================
*/
/*
*******************************************************************************
* Function: IFX_Firewall_DmzSetAttrInfo
* Desc: Sets attribute information in the respective tr69 sections
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_Firewall_DmzSetAttrInfo(IN OperInfo * pxOpInfo, INOUT ParamVal * pxPV, IN int32 iElements)
{
	int32 iRet = IFX_CWMP_SUCCESS;
	iRet = IFX_SetAttributesInfo(pxOpInfo, pxPV, iElements);

	if (iRet != IFX_CWMP_SUCCESS) {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			            "%s:%d [%d] Updating Param Attribute Info failed\n",
			            _FUNCL_, iRet);
			goto errorHandler;
		}
errorHandler:
	return iRet;
}
/*
** =============================================================================
**   Function Name    : IFX_Firewall_DmzGetValue
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/
static int32
IFX_Firewall_DmzGetValue(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
	int32   iRet = IFX_CWMP_SUCCESS;
	int32   iRtn = IFX_SUCCESS;
	IFX_MAPI_Firewall_DMZ xDmz;
	int32   iParamIdPos;
	int32   iCnt = 0;

	memset(&xDmz, 0, sizeof(IFX_MAPI_Firewall_DMZ));

	/* Get all the Dmz parameters using Protocol API */
	iRtn = ifx_mapi_get_firewall_dmz(&xDmz, IFX_F_DEFAULT);

	/* Check for error */
	if (iRtn != IFX_SUCCESS) {
			iRet = ERR_CWMP_INTERNAL;
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			            "[%s:%s:%d] [%d] Unable to get values of all "
			            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
			goto cleanup;
		}

	/* Get the offset of the parameter */
	iParamIdPos = IFX_GetParamIdPos(pxParamVal->iaOID);
        if (iParamIdPos < 0)
        {
            iRet = ERR_CWMP_INTERNAL;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
            goto cleanup;
        }

	/* Iterate and fill the requested parameters */
	for (iCnt = 0; iCnt < iElements; iCnt++) {
			(pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(MAX_DESCRIPTION_LEN);

			/* Check for error */
			if (!((pxParamVal[iCnt]).Value)) {
					iRet = ERR_OUT_OF_MEMORY;
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					            "[%s:%s:%d] [%d] Allocation Failure\n",
					            __FILE__, __func__, __LINE__, iRet);
					goto cleanup;
				}

			switch (pxParamVal[iCnt].iaOID[iParamIdPos]) {
				case OID_IGD_XLTQFIREWALL_DMZ_FEATUREENABLE:
					/* Copy the value to allocated area */
					if (xDmz.feature_enable)
						strcpy(pxParamVal[iCnt].Value, "1");
					else
						strcpy(pxParamVal[iCnt].Value, "0");
					IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
					                         IFX_CHK_CHANGE_FLAG_BASED);
					break;

				case OID_IGD_XLTQFIREWALL_DMZ_DMZHOST:
					/* Copy the value to allocated area */
					strcpy(pxParamVal[iCnt].Value, inet_ntoa(xDmz.ip));
					IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
					                         IFX_CHK_CHANGE_FLAG_BASED);
					break;

				default:
					iRet = ERR_CWMP_INVAL_PARAM_NAME;
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					            "[%s:%s:%d] [Error] Unknown requested parameter\n",
					            __FILE__, __func__, __LINE__);
					goto cleanup;
				}
		}

cleanup:
	return (iRet);
}
/*
** =============================================================================
**   Function Name    : IFX_Firewall_DmzModify
**
**   Description      : This function modifies the value of parameter in
**                      X_INFINEON_COM_DMZ object. It calls respective Management API
**                      for the same. It performs modification only if parameter
**                      has Write permission. In certain cases it also performs
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            :
**
** ============================================================================
*/
static int32
IFX_Firewall_DmzModify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
	int32   iRet         = IFX_CWMP_SUCCESS;
	int32   iRtn         = IFX_SUCCESS;
	int32   iCnt         = 0;
	IFX_MAPI_Firewall_DMZ xDmz;
	int32   iParamIdPos;

	memset(&xDmz, 0, sizeof(IFX_MAPI_Firewall_DMZ));

	/* Get all the Dmz parameter using Object API */
	iRtn = ifx_mapi_get_firewall_dmz(&xDmz, IFX_F_DEFAULT);

	/* Check for error */
	if (iRtn != IFX_CWMP_SUCCESS) {
			iRet = ERR_CWMP_INTERNAL;
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			            "[%s:%s:%d] [%d] Unable to get values of all "
			            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
			goto cleanup;
		}

	/* Get the offset of the parameter */
	iParamIdPos = IFX_GetParamIdPos(pxParamVal->iaOID);
        if (iParamIdPos < 0)
        {
            iRet = ERR_CWMP_INTERNAL;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
            goto cleanup;
        }

	/* Iterate and fill the requested parameters */
	for (iCnt = 0; iCnt < iElements; iCnt++) {
			/* Process based on the requested parameter */
			switch ((pxParamVal[iCnt]).iaOID[iParamIdPos]) {
				case OID_IGD_XLTQFIREWALL_DMZ_FEATUREENABLE:

					/* Copy the string */
					if (strcmp(pxParamVal[iCnt].Value,"1")==0)
						xDmz.feature_enable = TRUE;
					else
						xDmz.feature_enable = FALSE;
					break;
				case OID_IGD_XLTQFIREWALL_DMZ_DMZHOST:
					/* Copy the string */
					inet_aton((pxParamVal[iCnt]).Value,&(xDmz.ip));
					break;
				default:
					pxParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
					iRet = ERR_CWMP_INVAL_ARGS;
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					            "[%s:%s:%d] [%d] Unknown Parameter\n",
					            __FILE__, __func__, __LINE__, iRet);
					goto cleanup;
				}
		}

	/* Fill the iid structure in IFX_Dmz */
	xDmz.iid.config_owner = iCaller;

	/* Set all the DMZ parameters using Object API */
	iRtn = ifx_mapi_set_firewall_dmz(&xDmz, IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH);

	/* Check for error */
	if (iRtn != IFX_SUCCESS) {
			iRet = ERR_CWMP_INTERNAL;
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			            "[%s:%s:%d] [%d] Unable to set values of all "
			            "parameters\n", __FILE__, __func__, __LINE__, iRet);
			goto cleanup;
		}

cleanup:
	return (iRet);
}

/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS>
**
** =============================================================================
*/
/*
** =============================================================================
**   Function Name    : IFX_DMZ
**
**   Description      : This function is called by the controller. It handles
**                      the DMZ object and performs  based on requested
**                      operations/suboperations by invoking internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            :
**
** =============================================================================
*/
int32
IFX_Firewall_DMZ(IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
                 OUT void **ppRet, OUT int32 *piNumRetElem)
{
	int32       iRet           = IFX_CWMP_SUCCESS;
	ParamVal    *pxParamVal    = (ParamVal *)pParamList;
        uint32   iCnt = 0;

	/* Process based on type of Operation */
	switch (pxOI->iOper)
        {
		case OP_GETVAL:
                {
			/* Process based on type of SubOperation */
			switch (pxOI->iSubOper)
                        {
				case OP_GETVAL_NORMAL:
				case OP_GETVAL_NOTIFICATION:

					/* Get values of all the requested parameters */
					iRet = IFX_Firewall_DmzGetValue(pxOI, pxParamVal, iNumElem);

					/* Check for error */
					if (iRet != IFX_CWMP_SUCCESS) {
							goto cleanup;
						}

					break;
				default:
					iRet = ERR_CWMP_INVAL_OPER;
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					            "[%s:%d] [%d] Invalid SubOperation\n",
					            __func__, __LINE__, iRet);
					goto cleanup;
			}
			break;
		}
		case OP_SETVAL:
                {
			/* Process based on type of SubOperation */
			switch (pxOI->iSubOper)
                        {
				case OP_SETVAL_FREE:
				case OP_SETVAL_VALIDATE:
					break;
				case OP_SETVAL_CHK_MODIFY_DEP:

					/* Check modify dependency of all requested parameters */
					iRet = IFX_CWMP_SUCCESS;
					break;
				case OP_SETVAL_MODIFY:

					/* Set values of all the requested parameters */
					iRet = IFX_Firewall_DmzModify(pxOI->iCaller, pxParamVal, iNumElem);

					/* Check for error */
					if (iRet != IFX_CWMP_SUCCESS) {
							goto cleanup;
						}

					break;
				case OP_SETVAL_ATTRINFO:
					iRet =
					    IFX_Firewall_DmzSetAttrInfo(pxOI, pParamList,
					                                iNumElem);
					if (iRet != IFX_CWMP_SUCCESS)
						goto cleanup;
					break;
				default:
					iRet = ERR_CWMP_INVAL_OPER;
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					            "[%s:%d] [%d] Invalid SubOperation\n",
					            __func__, __LINE__, iRet);
					goto cleanup;
			}
			break;
                }
        	case OP_PARAM_VALIDATE:
	        {
                    /*Vendor specific parameters should not be reported to ACS. It 
                      should be available for internal updation */
                    if(pxOI->iCaller == ACC_TR69)
                    {
                        /* Set the fault code to Error */
                        for(iCnt = 0; iCnt < iNumElem; iCnt++)
                        {
                            pxParamVal[iCnt].iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
                        }
                    }
        	    break; 
	        }
		default:
                {
			iRet = ERR_CWMP_INVAL_OPER;
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			            "[%s:%d] [%d] Invalid Operation\n",
			            __func__, __LINE__, iRet);
			goto cleanup;
                }
	}

cleanup:
	return (iRet);
}

/*
** =============================================================================
**   Function Name    : IFX_DMZ_Init
**
**   Description      : This function is called by the controller. It registers
**                      the function responsible for handling X_INFINEON_COM_DMZ object
**                      with data structure. It also performs initializations
**                      specific to X_INFINEON_COM_DMZ object.
**
**   Parameters       : No Parameters.
**
**   Return Value     : IFX_CWMP_SUCCESS - When DMZ object is initialized
**                      successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in initializing X_INFINEON_COM_DMZ object.
**   Notes            :
**
** =============================================================================
*/
int32
IFX_Dmz_Init(void)
{
	int32 iRet = IFX_CWMP_SUCCESS;

	/* Register the DMZ module function pointer in the object model */
	iRet = ifx_ds_register_function(IFIN_DMZ_OBJ, IFX_Firewall_DMZ);

	/* Check for error */
	if (iRet != IFX_CWMP_SUCCESS) {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			            "[%s:%d] [%d] Unable to Register %s with Object Model\n",
			            __func__, __LINE__, iRet, IFIN_DMZ_OBJ);
			goto cleanup;
		}

cleanup:
	return iRet;
}
