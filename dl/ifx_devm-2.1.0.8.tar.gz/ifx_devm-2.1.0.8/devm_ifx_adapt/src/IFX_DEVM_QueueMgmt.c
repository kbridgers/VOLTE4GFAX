/* 
** =============================================================================
**   FILE NAME        : IFX_QueueMgmt.c
**   PROJECT          : TR69
**   MODULES          : QueueManagement
**   DATE             : 12-01-2009
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This is the Queuemanagement Module. It is required by the 
**                      controller module of TR69 stack to GET/SET
**                      QueueManagement specific information.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author                         $Comment
**   15-01-2008       TR69 team                       Initial Version
**
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_QueueMgmt.h"
  // Required for STATIC
 
#include "IFX_DEVM_OID.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
 
#include "IFX_DEVM_DS.h"
#include "IFX_DEVM_StackUtil.h"

#ifndef DEVM_OVER_IPv6
extern char gcACSIP[20]; /* Mandatory */
#else
extern char gcACSIP[40]; /* Mandatory */
#endif
extern uint32 guiACSPort; /* Mandatory */
/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFX_QUEUE_MGMT_OBJ    FORMNAME("QueueManagement.")
/* TBD: Temporary Placeholders, since we do not get this from Platform include
   header files */

/* IPQOS Tags */
#define TAG_IPQOS_CAPABILITY                      "qos_capability"
#define TAG_IPQOS_QM                              "qos_queuemgmt"
#define TAG_IPQOS_CLASSIFY                        "qos_class"
#define TAG_IPQOS_QUEUE                            "qos_queue"
#define TAG_IPQOS_POLICER                          "qos_policer"
#define PREFIX_IPQOS_CLASSIFY                      "qcl"
#define PREFIX_IPQOS_QUEUE                         "qq"

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

STATIC int32
GetParamOffset(IN int32 *paiOID);
STATIC int32
GetVal(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
       IN int32 iElements);
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : GetParamOffset
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetParamOffset(IN int32 *paiOID)
{
    int32 iCnt;

    for (iCnt = 0; paiOID[iCnt] != 0; iCnt++);

    return (iCnt - 1);
}

/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetVal(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
       IN int32 iElements)
{
    int32   iRet  = IFX_CWMP_SUCCESS;
    int32   iRtn  = IFX_SUCCESS;
    int32   iCnt  = 0;
    int32   len;
    IFX_MAPI_QoS_QM xQM;
    IFX_MAPI_QoS_Capability xQoSC;
    int32   iParamOffset;
    uint32   uiInstanceCount = 0;
    IFX_MAPI_QoS_Interface_Type qIfType;

    memset(&xQM, 0, sizeof(IFX_MAPI_QoS_QM));
    memset(&xQoSC, 0, sizeof(IFX_MAPI_QoS_Capability));

    /* Get all the IFX_MAPI_QoS_QM parameters using Protocol API */
    iRtn = ifx_mapi_get_qos_qm(&xQM, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_qm failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get all the IFX_MAPI_QoS_Capability parameters using Protocol API */
    iRtn = ifx_mapi_get_qos_capability(&xQoSC, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_capability failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    qIfType = ifx_mapi_get_active_qos_iface();

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        /* TBD: Currently keeping size as 16 bytes, since parameters are only integers */
        (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(16);

        /* Check for error */
        if (!((pxParamVal[iCnt]).Value))
        {
            iRet = ERR_OUT_OF_MEMORY;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Allocation Failure\n",
                         __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_QM_ENABLE:

                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQM.enable);
                break;  
            case OID_IGD_QM_MAXQUEUES:

		switch(qIfType) {
		    case IFX_MAPI_QoS_WAN_ATM:
		    case IFX_MAPI_QoS_WAN_PTM:
		    case IFX_MAPI_QoS_WAN_ETH_1:
			sprintf(pxParamVal[iCnt].Value, "%d", 8);
			break;
		    case IFX_MAPI_QoS_WAN_ETH_0:
			sprintf(pxParamVal[iCnt].Value, "%d", 4);	
			break;
		    default:
		    	break;
		}
                break;  
            case OID_IGD_QM_MAXCLASSIFICATIONENTRIES:

                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQoSC.maxClassifiers);
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;  
            case OID_IGD_QM_CLASSIFICATIONNUMBEROFENTRIES:

                uiInstanceCount = 0;

		uiInstanceCount = ifx_mapi_get_classifier_count_for_wan_mode(qIfType);	
		sprintf(pxParamVal[iCnt].Value, "%u", uiInstanceCount);	
	
                break;  
            case OID_IGD_QM_MAXAPPENTRIES:

                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQoSC.maxApps);
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;  
            case OID_IGD_QM_APPNUMBEROFENTRIES:

                /* Copy the value to allocated area */
                // TBD: Hardcoded Currently.
                sprintf(pxParamVal[iCnt].Value, "%d", 0);
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_VALUE_BASED);
                break;  
            case OID_IGD_QM_MAXFLOWENTRIES:

                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQoSC.maxFlows);
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;  
            case OID_IGD_QM_FLOWNUMBEROFENTRIES:

                /* Copy the value to allocated area */
                // TBD: Hardcoded Currently.
                sprintf(pxParamVal[iCnt].Value, "%d", 0);
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_VALUE_BASED);
                break;  
            case OID_IGD_QM_MAXPOLICERENTRIES:

                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQoSC.maxPolicers);
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;  
            case OID_IGD_QM_POLICERNUMBEROFENTRIES:

                /* Copy the value to allocated area */
                uiInstanceCount = 0;
                ifx_get_sec_instance_count(TAG_IPQOS_POLICER, &uiInstanceCount);
                sprintf(pxParamVal[iCnt].Value, "%u", uiInstanceCount);
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;  
            case OID_IGD_QM_MAXQUEUEENTRIES:

                switch(qIfType) {
                    case IFX_MAPI_QoS_WAN_ATM:
                    case IFX_MAPI_QoS_WAN_PTM:
                    case IFX_MAPI_QoS_WAN_ETH_1:
                        sprintf(pxParamVal[iCnt].Value, "%d", 8);
                        break;
                    case IFX_MAPI_QoS_WAN_ETH_0:
                        sprintf(pxParamVal[iCnt].Value, "%d", 4);
                        break;
                    default:
                        break;
                }
                break;  
            case OID_IGD_QM_QUEUENUMBEROFENTRIES:

                /* Copy the value to allocated area */
                uiInstanceCount = 0;
                uiInstanceCount = ifx_mapi_get_queue_count_for_wan_mode(qIfType);
		sprintf(pxParamVal[iCnt].Value, "%u", uiInstanceCount);
                break;  
            case OID_IGD_QM_DEFAULTFORWARDINGPOLICY:

                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%u", xQM.defaultFwPolicy);
                break;  
            case OID_IGD_QM_DEFAULTTRAFFICCLASS:

                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQM.defaultTC);
                break;  
            case OID_IGD_QM_DEFAULTPOLICER:

                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQM.defaultPolicer);
                break;  
            case OID_IGD_QM_DEFAULTQUEUE:

                if (xQM.defaultQ != -1)
                {
                    /* The value is CPE-Id, so now we get the TR69ID and extract the
                       instance number */
		    xQM.defaultQ = ifx_mapi_get_default_queue_cpeid(qIfType);
                    IFX_Id xIfxId;
                    char *ptr=NULL;
                    memset(&xIfxId, 0, sizeof(IFX_Id));
                    strcpy(xIfxId.xCpeId.sSectionTag,TAG_IPQOS_QUEUE);
                    xIfxId.xCpeId.uiId = (uint32)(xQM.defaultQ);
                    if (IFX_GetTr69IdFromCpeId(&xIfxId) != IFX_CWMP_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] No TR69Id For secname %s and cpeid %d\n",
                            __FILE__, __func__, __LINE__,
                            xIfxId.xCpeId.sSectionTag, xIfxId.xCpeId.uiId);
                        iRet = ERR_CWMP_INTERNAL;
                        goto cleanup;
                    }
                    /* Extract the Queue Instance Number and Copy to allocated area */
                    xIfxId.sTr69Id[strlen(xIfxId.sTr69Id)-1] = '\0';
                    ptr=strrchr(xIfxId.sTr69Id,'.');
                    if (!ptr)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] No TR69Id For secname %s and cpeid %d\n",
                            __FILE__, __func__, __LINE__,
                            xIfxId.xCpeId.sSectionTag, xIfxId.xCpeId.uiId);
                        iRet = ERR_CWMP_INTERNAL;
                        goto cleanup;
                    }
                    sprintf(pxParamVal[iCnt].Value, "%d", atoi(ptr+1));
                }
                else
                {
                    /* Copy the value to allocated area */
                    sprintf(pxParamVal[iCnt].Value, "%d", xQM.defaultQ);
                }
                break;  
            case OID_IGD_QM_DEFAULTDSCPMARK:

                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQM.defaultDSCP);
                break;  
            case OID_IGD_QM_DEFAULTETHERNETPRIORITYMARK:

                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQM.defaultPbits);
                break;  
	    case OID_IGD_QM_QUEUESTATSNUMBEROFENTRIES:
		/*Queue stat entries are not supported return zero */
                sprintf(pxParamVal[iCnt].Value, "%d",xQM.queueStatsNumberOfEntries);
                break;  
            case OID_IGD_QM_AVAILABLEAPPLIST:

                /* Copy the value to allocated area */
		//limit printing the availableapplinst entries to 32
		if((len = snprintf(pxParamVal[iCnt].Value, 16, "%s", xQM.availableAppList))>=16)
		{
        		if(((pxParamVal[iCnt]).Value = IFX_CWMP_REALLOC(pxParamVal[iCnt].Value,(len+1))))
			{
                		snprintf(pxParamVal[iCnt].Value, len+1, "%s", xQM.availableAppList);
			}
		}
		

                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;  
            default:
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
                goto cleanup;
        }
    }

cleanup:
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : Modify
**
**   Description      : This function modifies the values of parameters in 
**                      QueueManagement object. It calls respective Management
**                      API for same. It performs modification only if parameter 
**                      has Write permission. In certain cases it also performs 
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet         = IFX_CWMP_SUCCESS;
    int32   iRtn         = IFX_SUCCESS;
    int32   iCnt         = 0;
    uint32      iCpeid     = 0;
    IFX_MAPI_QoS_QM xQM;
    int32   iParamOffset;
    char8   *psTmpVal;
    uint32      uiFlags;
    uchar8      ucOldEnableState;
    IFX_MAPI_QoS_Interface_Type qIfType;
	
    memset(&xQM, 0, sizeof(IFX_MAPI_QoS_QM));

    /* Get all the IFX_MAPI_QoS_QM parameters using Protocol API */
    iRtn = ifx_mapi_get_qos_qm(&xQM, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_qm failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }
    // Get Cpeid from object ID
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    	goto cleanup;

    
    /* Fill the cpeid in the structure to get the required instance */
    xQM.iid.cpeId.Id = iCpeid;

    /* Set the old enable state */
    ucOldEnableState = xQM.enable; 

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {

            case OID_IGD_QM_ENABLE:
		
                if (!strcmp(psTmpVal, "true") ||!strcmp(psTmpVal, "1"))
                {
                    qIfType = ifx_mapi_get_active_qos_iface();
                    if(qIfType == IFX_MAPI_QoS_WAN_ATM && !strcmp(xQM.qIf,"0/0") && (xQM.atmQMode == IFX_MAPI_QoS_ATM_PVC_BASED)) {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [Error] ATM bridge mode dies not support QoS\n",
                        __FILE__, __func__, __LINE__);
                        (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INTERNAL;
                        iRet = ERR_CWMP_INTERNAL;
                        goto cleanup;
                    } else {
			xQM.enable = TRUE;
                    }
                } else {
                        xQM.enable = FALSE;
		}	

                break;
            case OID_IGD_QM_DEFAULTFORWARDINGPOLICY:
                    xQM.defaultFwPolicy = atoi(psTmpVal);
                break;
            case OID_IGD_QM_DEFAULTTRAFFICCLASS:
                    xQM.defaultTC = atoi(psTmpVal);
                break;
            case OID_IGD_QM_DEFAULTPOLICER:
                    xQM.defaultPolicer = atoi(psTmpVal);
                break;
            case OID_IGD_QM_DEFAULTQUEUE:
                if (atoi(psTmpVal) == -1)
                {
                    xQM.defaultQ = atoi(psTmpVal);
                }
                else
                {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] default queue cannot be changed\n",
                            __FILE__, __func__, __LINE__);
                        (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        iRet = ERR_CWMP_INVAL_ARGS;
                        goto cleanup;
                }
                break;
            case OID_IGD_QM_DEFAULTDSCPMARK:
                xQM.defaultDSCP = atoi(psTmpVal);
                break;
            case OID_IGD_QM_DEFAULTETHERNETPRIORITYMARK:
                xQM.defaultPbits = atoi(psTmpVal);
                break;
            case OID_IGD_QM_MAXAPPENTRIES:
            case OID_IGD_QM_APPNUMBEROFENTRIES:
            case OID_IGD_QM_MAXFLOWENTRIES:
            case OID_IGD_QM_FLOWNUMBEROFENTRIES:
            case OID_IGD_QM_MAXPOLICERENTRIES:
            case OID_IGD_QM_POLICERNUMBEROFENTRIES:
            case OID_IGD_QM_MAXQUEUES:
            case OID_IGD_QM_MAXCLASSIFICATIONENTRIES:
            case OID_IGD_QM_CLASSIFICATIONNUMBEROFENTRIES:
            case OID_IGD_QM_MAXQUEUEENTRIES:
            case OID_IGD_QM_QUEUENUMBEROFENTRIES:
            case OID_IGD_QM_QUEUESTATSNUMBEROFENTRIES:
            case OID_IGD_QM_AVAILABLEAPPLIST:
                (pxParamVal[iCnt]).iFaultCode = ERR_NON_WRITABLE;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Cannot modify the parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }


    /* Fill the iid structure in IFX_MAPI_QoS_QM */
    xQM.iid.config_owner = iCaller;
   //uiFlags = IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH;
    uiFlags = IFX_F_MODIFY;

    /* Set all the IFX_MAPI_QoS_QM parameters using Object API */
    //iRtn = ifx_mapi_set_qos_qm(IFX_OP_MOD, &xQM, IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH);

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d]#### call set qos mapi ####\n",
                            __FILE__, __func__, __LINE__);
    iRtn = ifx_mapi_set_qos_qm(IFX_OP_MOD, &xQM, uiFlags);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to set values of all "
                    "parameters\n", __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Add the IPQoS Rule For ACS mgmt */
    if ((xQM.enable == TRUE) && (ucOldEnableState == FALSE))
    {
        strcpy(gcACSIP,"0.0.0.0");
        guiACSPort=0;
    }

cleanup:
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : Validate
**
**   Description      : This function validates the values of parameters in
**                      QueueManagement object.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      validated.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When validation of all parameters is
**                      successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in validating at least one parameter.
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iCnt;
    int32   iParamOffset;
    char8   *psTmpVal;

   /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Iterate and validate the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Return a failure if the value is NULL pointer */
        if (!psTmpVal)
        {
            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
            iRet = ERR_CWMP_INVAL_ARGS;
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_QM_MAXAPPENTRIES:
            case OID_IGD_QM_APPNUMBEROFENTRIES:
            case OID_IGD_QM_MAXFLOWENTRIES:
            case OID_IGD_QM_FLOWNUMBEROFENTRIES:
            case OID_IGD_QM_MAXPOLICERENTRIES:
            case OID_IGD_QM_POLICERNUMBEROFENTRIES:
            case OID_IGD_QM_MAXQUEUES:
            case OID_IGD_QM_MAXCLASSIFICATIONENTRIES:
            case OID_IGD_QM_CLASSIFICATIONNUMBEROFENTRIES:
            case OID_IGD_QM_MAXQUEUEENTRIES:
            case OID_IGD_QM_QUEUENUMBEROFENTRIES:
            case OID_IGD_QM_AVAILABLEAPPLIST:
            case OID_IGD_QM_QUEUESTATSNUMBEROFENTRIES:
                /* RO params - Not validating. just returtning success */
                break;
            case OID_IGD_QM_ENABLE:
            case OID_IGD_QM_DEFAULTFORWARDINGPOLICY:
            case OID_IGD_QM_DEFAULTTRAFFICCLASS:
            case OID_IGD_QM_DEFAULTPOLICER:
            case OID_IGD_QM_DEFAULTQUEUE:
            case OID_IGD_QM_DEFAULTDSCPMARK:
            case OID_IGD_QM_DEFAULTETHERNETPRIORITYMARK:
                /* TBD: Will be done later if required */
                break;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

cleanup:
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Validating requested parameter failed\n",
                    __FILE__, __func__, __LINE__, iRet);
    }
    return (iRet);
}

STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iCnt;
    int32 iParamOffset;
    int32 iValueFlag = 0; /* Mandatory */

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Set the fault code to Success and value to NULL pointer for all parameters
       other than uptime */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Mark that values have been malloced. Currently always doing it, since not possible
       to keep track in a loop, for which params its malloced */
    iValueFlag = 1;

    /* Update Attribute Information */
    iRet = IFX_SetAttributesInfo(NULL, pxParamVal, iElements);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Updating Param Attribute Info failed\n",
                    __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    /* Free the Value that has been allocated */
    if (iValueFlag)
    { 
        for (iCnt = 0; iCnt < iElements; iCnt++)
        {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
        }
    }

    return (iRet);
}


STATIC int32 UpdateChildInfo(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{
	uint32 i=0,iRet=0;
	char8 usSecTag[IFX_MAX_SECTION_TAG_LEN]={0};
	char8 usParamTag[IFX_MAX_NAME_LEN]={0};
	uint32 uiParamPos=0,uiChildObjId=0;
	uint32 uiCpeid=0;
	int32 *iaOID=NULL;
	uint32 uiNumNV=1;
	//IFX_CpeId pxCpeId;
	IFX_Id xIfx_Id;
	IFX_NameValue pxNVArray;
	uint32 uiOper=IFX_NOTIFY_OPER_MODIFY;
	ParamVal *pxTempParamVal=pxParamVal;
	
		//memset the structs
		memset(&xIfx_Id,0x00,sizeof(xIfx_Id));
		memset(&pxNVArray,0x00,sizeof(pxNVArray));
		//Get Cpeid
		iRet = IFX_GetCpeId(pxTempParamVal->iaOID, &uiCpeid);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;

		//Get the child object Oid
		uiChildObjId = IFX_GetParamIdPos((int32 *)pxTempParamVal->pReserved);
		iaOID = (int32 *)pxTempParamVal->pReserved;

		for(i=0; i < iElements; i++)

		{
			//Get the Param Oid of this object
			uiParamPos= IFX_GetParamIdPos(pxTempParamVal->iaOID);
			
			if(((pxTempParamVal->iaOID[uiParamPos] == OID_IGD_QM_CLASSIFICATIONNUMBEROFENTRIES) &&
                            (iaOID[uiChildObjId-1] ==    OID_IGD_QM_C)) ||
                           ((pxTempParamVal->iaOID[uiParamPos] == OID_IGD_QM_QUEUENUMBEROFENTRIES) &&
                            (iaOID[uiChildObjId-1] ==    OID_IGD_QM_Q)) ||
                           ((pxTempParamVal->iaOID[uiParamPos] == OID_IGD_QM_POLICERNUMBEROFENTRIES) &&
                            (iaOID[uiChildObjId-1] ==    OID_IGD_QM_P)))
                         			
					{
						//Get the section and Paramtag
						iRet=IFX_GetSectionParamTag(pxTempParamVal->psRCTag, usParamTag, usSecTag);
						if(iRet != IFX_CWMP_SUCCESS)
							goto errorHandler;
						
						xIfx_Id.uiConfigOwner= pxOpInfo->iCaller;
						xIfx_Id.xCpeId.uiId= uiCpeid;
						strcpy(xIfx_Id.xCpeId.sSectionTag,usSecTag);
						strcpy(pxNVArray.sName,usParamTag);
												
						iRet=IFX_SendNotify(&xIfx_Id, uiNumNV, 
												&pxNVArray, uiOper);
						if(iRet != IFX_CWMP_SUCCESS)
						{
							IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 			"%s:%d IFX_SendNotify failed!\n", __func__, __LINE__);
							
							goto errorHandler;
						}
					}

			pxTempParamVal++;
			
		}
					
		return IFX_CWMP_SUCCESS;

		errorHandler:
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
			
			return IFX_CWMP_FAILURE;
			
}





/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : IFX_QueueMgmt_Init
**
**   Description      : This function is called by the controller. It registers
**                      the function responsible for handling QueueManagement
**                      object with data structure. It also performs
**                      initializations specific to QueueManagement object.
**
**   Parameters       : No Parameters. 
**
**   Return Value     : IFX_CWMP_SUCCESS - When QueueManagement object is
**                      initialized successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in initializing QueueManagement object.
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_QueueMgmt_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the QueueManagement module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_QUEUE_MGMT_OBJ, IFX_QueueMgmt);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_QUEUE_MGMT_OBJ);
        goto cleanup;
    }

cleanup:
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_QueueMgmt
**
**   Description      : This function is called by the controller. It handles
**                      QueueManagement object and performs  based on requested
**                      operations/suboperations by invoking internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_QueueMgmt(IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
             OUT void **ppRet, OUT int32 *piNumRetElem)
{
    int32       iRet           = IFX_CWMP_SUCCESS;
    ParamVal    *pxParamVal    = (ParamVal *)pParamList;

    /* Process based on type of Operation */
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:

                    /* Get values of all the requested parameters */
                    iRet = GetVal(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_SETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:

                    /* Validate values of all the requested parameters */
                    iRet = Validate(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:

                    /* Check modify dependency of all requested parameters */
                    iRet = IFX_CWMP_SUCCESS;
                    break;
                case OP_SETVAL_MODIFY:

                    /* Set values of all the requested parameters */
                    iRet = Modify(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ATTRINFO:

                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ADD:
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_FREE:
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
                case OP_SETVAL_DELETE:
                    break;

                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_UPDATE_CHILDINFO:
			//Updation of child related info is handled by the case
				switch(pxOI->iSubOper)
				{
					case OP_UPDATE_CHILDINFO_ADD:
					case OP_UPDATE_CHILDINFO_DEL:
					 if((iRet = UpdateChildInfo(pxOI, 
									pxParamVal,iNumElem)) != IFX_CWMP_SUCCESS)
					 	{
					 		switch(pxOI->iSubOper)
							{	

								case OP_UPDATE_CHILDINFO_ADD:
								 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_UPDATE_CHILDINFO_ADD failed!\n", __func__, __LINE__);
								goto cleanup;
								
								case OP_UPDATE_CHILDINFO_DEL:
								 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_UPDATE_CHILDINFO_DEL failed!\n", __func__, __LINE__);
								goto cleanup;

							}
					 	}
						break;
                			default:
			                    iRet = ERR_CWMP_INVAL_OPER;
			                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        		        "[%s:%d] [%d] Invalid SubOperation\n",
		                                 __func__, __LINE__, iRet);
                			    goto cleanup;
            }
            break;
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid Operation\n",
                         __func__, __LINE__, iRet);
            goto cleanup;
    }

cleanup:
    return (iRet);
}
