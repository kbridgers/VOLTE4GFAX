/* 
** =============================================================================
**   FILE NAME        : IFX_WanIpConnection.c
**   PROJECT          : TR69
**   MODULES          : WanIpConnection
**   DATE             : 28-04-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This module handles ADD/DEL/GET/SET RPCs of 
**                      WanIpConnection. When controller calls this module it
**                      calls respective Platform/Object APIs to handle GET/SET 
**                      of WanIpConnection specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author        $Comment
**   28-04-06         TR69 team      Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "IFX_DEVM_WANIPConn.h"
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
 
#include "IFX_DEVM_StackUtil.h"

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;
#define IFX_WAN_IPCON_OBJ "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANIPConnection.1."
extern int32 ifx_config_get_value(char8 *, char8 *);
extern int32 ifx_config_set_value(char8 *, char8 *);
extern uint32 guiConnReqIPAddr;
extern Old_Enable_Val axOldIPState[];

uint32 uiActiveWANIPCpeid=0;
//#define WAN_IP_CON_DEPTH 6
//#define WAN_CON_DEV_DEPTH 4

//#define WAN_IP_CON_ACC wancfg.ppp
//#define WAN_PPP_CON_ACC wancfg.ip


#define WAN_IP_NO_DEP_OIDS 	2

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/

//STATIC uchar8 WanDslLink_Oid[OID_LENGTH]={"OID_IGD.OID_IGD_WAND.1.OID_IGD_WAND_WANCD.1.OID_IGD_WAND_WANCD_WANDSLLC."};
//static uint32 stiWanDslLink_Dep=7;

extern Map_Value gaxEnable[];
extern Map_Value saxDslLnkType[];
extern int32 IFX_ValidateDestAddr(char8 * dest_addr, int16 * Vpi, int32 * 
Vci);
extern int32 IFX_GetWanConnectionEnable(int32 *iaDSLOID,int32 *iaOID,uint32 *uiEnable);
int32 IFX_CheckIfWanConnPresent(int32 *iaOID);

static char8 susWanIpPossibleConTypes[]={"Unconfigured,IP_Routed,IP_Bridged"};
static Map_Value saxWanIpConStatus[]={
{"Unconfigured",SYS_DATATYPE_INT,{.uiSys_Value=WAN_IP_CONN_STATUS_UNCONFIGURED}},
{"Connecting",SYS_DATATYPE_INT,{.uiSys_Value=WAN_IP_CONN_STATUS_CONNECTING}},
{"Connected",SYS_DATATYPE_INT, {.uiSys_Value=WAN_IP_CONN_STATUS_CONNECTED}},
{"PendingDisconnect",SYS_DATATYPE_INT, {.uiSys_Value=WAN_IP_CONN_STATUS_PENDING_DISCONNECT}},
{"Disconneting",SYS_DATATYPE_INT, 	{.uiSys_Value=WAN_IP_CONN_STATUS_DISCONNECTING}},
{"Disconnected",SYS_DATATYPE_INT, 	{.uiSys_Value=WAN_IP_CONN_STATUS_DISCONNECTED}}
};

static Map_Value saxWanIpConType[]={
{"Unconfigured",SYS_DATATYPE_INT,{.uiSys_Value=WAN_IP_CONN_TYPE_UNCONFIGURED}},
{"IP_Routed",SYS_DATATYPE_INT,{.uiSys_Value=WAN_IP_CONN_TYPE_IP_ROUTED}},
{"IP_Bridged",SYS_DATATYPE_INT,{.uiSys_Value=WAN_IP_CONN_TYPE_IP_BRIDGED}}
};

Map_Value saxWanIpConTrigger[]={
{"OnDemand",SYS_DATATYPE_INT,{.uiSys_Value=CONN_TRIGGER_ON_DEMAND}},
{"AlwaysOn",SYS_DATATYPE_INT,{.uiSys_Value=CONN_TRIGGER_ALWAYS_ON}},
{"Manual",SYS_DATATYPE_INT,{.uiSys_Value=CONN_TRIGGER_MANUAL}}
};

Map_Value saxWanIpRouteProto[]={
{"Off",SYS_DATATYPE_INT,{.uiSys_Value=ROUTE_PROTO_RX_OFF}},
{"RIPv1",SYS_DATATYPE_INT,{.uiSys_Value=ROUTE_PROTO_RX_RIP_V1}},
{"RIPv2",SYS_DATATYPE_INT,{.uiSys_Value=ROUTE_PROTO_RX_RIP_V2}},
{"OSPF",SYS_DATATYPE_INT,{.uiSys_Value=ROUTE_PROTO_RX_OSPF}}
};

 static Map_Value saxWanIpAddrType[]={
{"DHCP",SYS_DATATYPE_INT,{.uiSys_Value=IP_TYPE_DHCP}},
{"Static",SYS_DATATYPE_INT,{.uiSys_Value=IP_TYPE_STATIC}},
{"Auto",SYS_DATATYPE_INT,{.uiSys_Value=IP_TYPE_AUTO}} //We need to remove once API handles
 };
 
static Map_Value saxWanIpLastConError[]={
	
{"ERROR_NONE",SYS_DATATYPE_INT,{.uiSys_Value=WANIP_LAST_CONN_ERROR_NONE}},
{"ERROR_COMMAND_ABORTED",SYS_DATATYPE_INT,{.uiSys_Value=WANIP_LAST_CONN_ERROR_COMMAND_ABORTED}},
{"ERROR_NOT_ENABLED_FOR_INTERNET",SYS_DATATYPE_INT,{.uiSys_Value=WANIP_LAST_CONN_ERROR_NOT_ENABLED_FOR_INTERNET}},
{"ERROR_USER_DISCONNECT",SYS_DATATYPE_INT,{.uiSys_Value=WANIP_LAST_CONN_ERROR_USER_DISCONNECT}},
{"ERROR_ISP_DISCONNECT",SYS_DATATYPE_INT,{.uiSys_Value=WANIP_LAST_CONN_ERROR_ISP_DISCONNECT}},
{"ERROR_IDLE_DISCONNECT",SYS_DATATYPE_INT,{.uiSys_Value=WANIP_LAST_CONN_ERROR_IDLE_DISCONNECT}},
{"ERROR_FORCED_DISCONNECT",SYS_DATATYPE_INT,{.uiSys_Value=WANIP_LAST_CONN_ERROR_FORCED_DISCONNECT}},
{"ERROR_NO_CARRIER",SYS_DATATYPE_INT,{.uiSys_Value=WANIP_LAST_CONN_ERROR_NO_CARRIER}},
{"ERROR_IP_CONFIGURATION",SYS_DATATYPE_INT,{.uiSys_Value=WANIP_LAST_CONN_ERROR_IP_CONFIGURATION}},
{"ERROR_UNKNOWN",SYS_DATATYPE_INT,{.uiSys_Value=WANIP_LAST_CONN_ERROR_UNKNOWN}}
};


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/

#ifdef IFX_TR69_ADSLWAN
static int32 
IFX_GetVccObj(ATM_VCC_INFO *ppxAtmVcc, uint32 iCpeid)
{
    uint32 iRet=0;
    ppxAtmVcc->iid.cpeId.Id=iCpeid;
        
    iRet=ifx_get_one_vcc_info(ppxAtmVcc);    

    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d ifx_get_all_vcc_info failed!\n", __func__, __LINE__);
        goto errorHandler;
    }
    return IFX_CWMP_SUCCESS;    
errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed!\n", __func__, __LINE__);
    return IFIN_CWMP_FAILURE;
}
#endif

#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
int32 ifx_set_wan_atm_vcc_config_stub(int32 op, WAN_CONN_CFG * pxMatch_Wan_Conn, uint32 flags)
 	{

		if(pxMatch_Wan_Conn == NULL)
		{
		   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Passed object has NULL Pointer !!! \n");
		   return IFX_SUCCESS;
		}
		
		if(op == IFX_OP_ADD)
		{
		 	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Add operation \n");
		}else if(op == IFX_OP_DEL)
		{
		 	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Del operation \n");
				
		 }else if (op == IFX_OP_MOD)
	 	{
	 		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Modify operation \n");
	 	}else 	
	 	{
	 	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: GET operation \n");
	 	}


		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_IP_ENABLE=%d\n",flags);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_IP_LINKTYPE=%d\n",pxMatch_Wan_Conn->type);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_IP_CONFIG_OWNER=%d\n",pxMatch_Wan_Conn->iid.config_owner);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_IP_CPEID=%d\n",pxMatch_Wan_Conn->iid.cpeId.Id);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_IP_tr69id=%s\n",pxMatch_Wan_Conn->iid.tr69Id);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_IP_CONNTYPE=%d\n",pxMatch_Wan_Conn->wancfg.ip.conn_type);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_IP_CONN_NAME=%s\n",pxMatch_Wan_Conn->wancfg.ip.wan_cfg.conn_name);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_IP_NATENABLE=%d\n",pxMatch_Wan_Conn->wancfg.ip.wan_cfg.NAT_enabled);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_IP_ADDRTYPE=%d\n",pxMatch_Wan_Conn->wancfg.ip.addr_type);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_IP_IPADDR=%s\n",inet_ntoa(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.ip_mask.ip));
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_IP_IPMASK=%s\n",inet_ntoa(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.ip_mask.mask));
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_IP_DNSENABLE=%d\n",pxMatch_Wan_Conn->wancfg.ip.wan_cfg.DNS_enabled);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_IP_MTU=%d\n",pxMatch_Wan_Conn->wancfg.ip.max_mtu);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_IP_IPGW=%s\n",inet_ntoa(pxMatch_Wan_Conn->wancfg.ip.ip_gw));
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_IP_MACADDR=%s\n",pxMatch_Wan_Conn->wancfg.ip.wan_cfg.mac_addr);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_IP_CONNTRIG=%d\n",pxMatch_Wan_Conn->wancfg.ip.wan_cfg.trigger);
		
	return IFX_SUCCESS;
	}

#endif

int32 
IFX_GetWanObj(WAN_CONN_CFG *pxWanConn, uint32 iCpeid)
{
	int32 iRet=0;
        uint32 iFlags;
	
	iFlags = IFX_F_GET_ANY;

	if(pxWanConn->type == WAN_TYPE_PPP)
		pxWanConn->wancfg.ppp.wan_cfg.iid.cpeId.Id = iCpeid;
	else if(pxWanConn->type == WAN_TYPE_IP)
		pxWanConn->wancfg.ip.wan_cfg.iid.cpeId.Id = iCpeid;

#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
	int32 uiNumOfEntries=0;			//get_all
	WAN_CONN_CFG *paxWan_Conns=NULL;	//get_all
	iRet=ifx_get_all_wan_atm_vcc_config_stub(&uiNumOfEntries, &paxWan_Conns,iFlags);	
#else
	iRet=mapi_get_wan_config(-1, pxWanConn, iFlags);
#endif
	
	if(iRet != IFX_SUCCESS)
	{
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d ifx_mapi_get_wan_config ret failed cpeid[%d] type[%d]!\n", __func__, __LINE__, iCpeid, pxWanConn->type);
		goto errorHandler;	
	}
	return IFX_CWMP_SUCCESS;

errorHandler:
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
	return IFIN_CWMP_FAILURE;	
}


int32 
IFX_GetWanIpNoPortMapObjs(char8 *usConnName, uint32 *NoOfPortEntries)
{


	//Get IfName from ConnName
	//Match IfName get the No. of Entries
	VIRTUAL_SERVER *paxWan_IpPortMaps=NULL;
	VIRTUAL_SERVER *pxTemp=NULL;
	int32 uiNumOfEntries=0;
	uint32 iFlags,i=0;
	int32 iRet=0;
	
	*NoOfPortEntries=0;
	iFlags = IFX_F_GET_ANY;
	
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS	
	iRet=ifx_get_virtual_server_info_stub(&uiNumOfEntries, &paxWan_IpPortMaps,iFlags);	
#else
	iRet=ifx_get_virtual_server_info(&uiNumOfEntries, &paxWan_IpPortMaps,iFlags);	
#endif

	if(iRet != IFX_SUCCESS)
	{
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d ifx_get_virtual_server_info ret failed!\n", __func__, __LINE__);
		goto errorHandler;
	}
	pxTemp = paxWan_IpPortMaps;

	for(i=0;i< uiNumOfEntries; i++)
	{
		if(pxTemp !=NULL)
		{
			if(strcmp(usConnName,pxTemp->wan_conn_if)==0)
			{			
				//iGotValue = 1;
				(*NoOfPortEntries)++;
			}
			pxTemp = pxTemp + 1;
		}
	}

	
	if(paxWan_IpPortMaps != NULL)
		IFIN_CWMP_FREE(paxWan_IpPortMaps);

	return IFIN_CWMP_SUCCESS;
	
errorHandler:
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
	if(paxWan_IpPortMaps != NULL)
			IFIN_CWMP_FREE(paxWan_IpPortMaps);

	return IFIN_CWMP_FAILURE;	
}



static int32 
IFX_ConvertArrToWanConCfgStruct(IN uint32 iElements, IN ParamVal *paxParamVal,	OUT WAN_CONN_CFG* pxWan_Conn)
{
	uint32 i;
	int32 iRet;
	uint32 uiParamPos=0;
	
	uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);	
	for (i=0; i < iElements; i++) 
	{
		switch(paxParamVal->iaOID[uiParamPos])
		{
			case OID_IGD_WAND_WANCD_WANIPC_ENABLE:
				if(IFX_FwdMappingValues(gaxEnable,4,
							(void *)(paxParamVal->Value),
							(void *)&(pxWan_Conn->wancfg.ip.wan_cfg.f_enable)) !=IFIN_CWMP_SUCCESS)
				{
					iRet=ERR_CWMP_INVAL_PARAM_VAL;
					goto errorHandler;
				}
				break;
			case OID_IGD_WAND_WANCD_WANIPC_CONNECTIONTYPE:
				if(IFX_FwdMappingValues(saxWanIpConType,3,
						(void *)(paxParamVal->Value),
						(void *)&(pxWan_Conn->wancfg.ip.conn_type)) !=IFIN_CWMP_SUCCESS)
				{
					iRet=ERR_CWMP_INVAL_PARAM_VAL;
					goto errorHandler;
				}
				break;

			case OID_IGD_WAND_WANCD_WANIPC_NAME:
				strncpy(pxWan_Conn->wancfg.ip.wan_cfg.conf_conn_name,
						paxParamVal->Value,
						(MAX_CONN_NAME_LEN-1));
				break;
				
			case OID_IGD_WAND_WANCD_WANIPC_AUTODISCONNECTTIME:
				pxWan_Conn->wancfg.ip.wan_cfg.auto_disconn_time =
								atoi(paxParamVal->Value);
				break;

			case OID_IGD_WAND_WANCD_WANIPC_IDLEDISCONNECTTIME:
				pxWan_Conn->wancfg.ip.wan_cfg.idle_disconn_time=
								atoi(paxParamVal->Value);
				break;

			case OID_IGD_WAND_WANCD_WANIPC_WARNDISCONNECTDELAY:
				/*pxWan_Conn->wancfg.ip.wan_cfg.warn_disconn_delay=
								atoi(paxParamVal->Value);*/
				break;

			//case OID_IGD_WAND_WANCD_WANIPC_RSIPAVAILABLE:
			case OID_IGD_WAND_WANCD_WANIPC_NATENABLED:
				if(IFX_FwdMappingValues(gaxEnable,4,
					(void *)(paxParamVal->Value),
					(void *)&(pxWan_Conn->wancfg.ip.wan_cfg.NAT_enabled)) !=IFIN_CWMP_SUCCESS)
				{
					iRet=ERR_CWMP_INVAL_PARAM_VAL;
					goto errorHandler;
				}
				break;

			case OID_IGD_WAND_WANCD_WANIPC_ADDRESSINGTYPE:
				if(IFX_FwdMappingValues(saxWanIpAddrType,3,
				  (void *)(paxParamVal->Value),
				  (void *)&(pxWan_Conn->wancfg.ip.addr_type)) !=IFIN_CWMP_SUCCESS)
				{
					iRet=ERR_CWMP_INVAL_PARAM_VAL;
					goto errorHandler;
				}
				break;

			case OID_IGD_WAND_WANCD_WANIPC_EXTERNALIPADDRESS:
				if((inet_aton(paxParamVal->Value,
					&(pxWan_Conn->wanv4.ip_mask.ip))) ==0)
				{
					iRet=ERR_CWMP_INVAL_PARAM_VAL;
					goto errorHandler;
				}
				break;
				
			case OID_IGD_WAND_WANCD_WANIPC_SUBNETMASK:
				if((inet_aton(paxParamVal->Value,
					&(pxWan_Conn->wanv4.ip_mask.mask))) ==0)
				{
					iRet=ERR_CWMP_INVAL_PARAM_VAL;
					goto errorHandler;
				}
				break;

			case OID_IGD_WAND_WANCD_WANIPC_DEFAULTGATEWAY:
				if((inet_aton(paxParamVal->Value,
					&(pxWan_Conn->wanv4.ip_gw))) ==0)
				{
					iRet=ERR_CWMP_INVAL_PARAM_VAL;
					goto errorHandler;
				}
				break;
				
			case OID_IGD_WAND_WANCD_WANIPC_DNSENABLED:
				if(IFX_FwdMappingValues(gaxEnable,4,
					(void *)(paxParamVal->Value),
					(void *)&(pxWan_Conn->wancfg.ip.wan_cfg.wandns.DNS_enabled)) !=IFIN_CWMP_SUCCESS)
				{
					iRet=ERR_CWMP_INVAL_PARAM_VAL;
					goto errorHandler;
				}
				break;
	
			case OID_IGD_WAND_WANCD_WANIPC_DNSOVERRIDEALLOWED:
				if(IFX_FwdMappingValues(gaxEnable,4,(void *)(paxParamVal->Value),
					(void *)&(pxWan_Conn->wancfg.ip.wan_cfg.wandns.DNS_override_allowed)) !=IFIN_CWMP_SUCCESS)
				{
					iRet=ERR_CWMP_INVAL_PARAM_VAL;
					goto errorHandler;
				}
				break;

			case OID_IGD_WAND_WANCD_WANIPC_DNSSERVERS:
				iRet = IFX_ConvertDNSServersStringToArr(pxWan_Conn->wancfg.ip.wan_cfg.wandns.dns_servers,
														paxParamVal->Value);				
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				break;
				
			case OID_IGD_WAND_WANCD_WANIPC_MAXMTUSIZE:
				pxWan_Conn->wancfg.ip.wan_cfg.max_mtu = atoi(paxParamVal->Value);
				break;
				
			case OID_IGD_WAND_WANCD_WANIPC_MACADDRESS:
				strncpy(pxWan_Conn->wancfg.ip.wan_cfg.mac_addr,
						paxParamVal->Value,
						(MAX_MAC_ADDRESS_LEN-1));
				break;

			case OID_IGD_WAND_WANCD_WANIPC_MACADDRESSOVERRIDE:
				if(IFX_FwdMappingValues(gaxEnable,4,(void *)(paxParamVal->Value),
				(void *)&(pxWan_Conn->wancfg.ip.wan_cfg.mac_addr_override)) !=IFIN_CWMP_SUCCESS)
				{
					iRet=ERR_CWMP_INVAL_PARAM_VAL;
					goto errorHandler;
				}
				break;

			case OID_IGD_WAND_WANCD_WANIPC_CONNECTIONTRIGGER:
				/*if(IFX_FwdMappingValues(saxWanIpConTrigger,3,(void *)(paxParamVal->Value),
				(void *)&(pxWan_Conn->wancfg.ip.wan_cfg.trigger)) !=IFIN_CWMP_SUCCESS)
				{
					iRet=ERR_CWMP_INVAL_PARAM_VAL;
					goto errorHandler;
				}*/
				break;

			case OID_IGD_WAND_WANCD_WANIPC_ROUTEPROTOCOLRX:
				if(IFX_FwdMappingValues(saxWanIpRouteProto,4,(void *)(paxParamVal->Value),
				(void *)&(pxWan_Conn->wancfg.ip.wan_cfg.route_rx)) !=IFIN_CWMP_SUCCESS)
				{
					iRet=ERR_CWMP_INVAL_PARAM_VAL;
					goto errorHandler;
				}
				break;
				//case OID_IGD_WAND_WANCD_WANIPC_PORTMAPPINGNUMBEROFENTRIES:
									
			default:
				break;
		}
		++paxParamVal;		
	}

	return IFIN_CWMP_SUCCESS;

errorHandler:
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
              		 "%s:%d failed ParamID=%d Value=%s!\n", __func__, __LINE__,
					paxParamVal->iaOID[uiParamPos],(char8 *)paxParamVal->Value);
	return iRet;
}



/* 
** =============================================================================
**   Function Name    : IFX_WanIpConGetValue
**   Description        : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes                : 
**
** ============================================================================
*/
static int32 
IFX_WanIpConGetValue(IN OperInfo *pxOperInfo,INOUT ParamVal *pxGetParamVal,
								IN uint32 iElements)
{
	/*GET PARAMETER VALUES
	**Get Object OID(skip parameter ID) from the first 
	**element in the array.Get Cpeid for this Object OID

	**Get the object from the system using a Platform API
	**with cpeid 
	
	**Do reverse mapping to convert system values into TR69
	**Values.After conversion stores the values in temp storage

	**While assigning the values as per request store the 
	**values in heap and assign the ptr to the struct
	**Return all the values 
	*/

#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
	uint32 iFlags=0;
#endif
	uint32 iCpeid=0,i=0;
	int32 iParamId=0;
	uint32 uiParamPos=0;
	int32 iRet=IFX_CWMP_SUCCESS;
	uint32 uiNoEntries=0;
	uint32 uiMode=IFX_CHK_VALUE_BASED;
	WAN_CONN_CFG xMatch_Wan_Conn;
	WAN_CONN_CFG *pxMatch_Wan_Conn=&xMatch_Wan_Conn;
	void *pvTmpBigVal=NULL; 
        IFX_Id	VlanId;
        int32 iaVLANRefOID[OID_LENGTH] = {0};
        char8 tr69_str[IFX_MAX_TR69_ID_LEN] = {0};

	// Get Cpeid from object ID
	iRet = IFX_GetCpeId(pxGetParamVal->iaOID,&iCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	memset(&xMatch_Wan_Conn,0x00,sizeof(xMatch_Wan_Conn));	
	memset(&VlanId,0x00,sizeof(VlanId));	

	pxMatch_Wan_Conn->type = WAN_TYPE_IP;
	// Get match object from system using Platform API
	iRet= IFX_GetWanObj(pxMatch_Wan_Conn, iCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	//Get the WanIpConParamPos 
	uiParamPos = IFX_GetParamIdPos(pxGetParamVal->iaOID);
	
	for(i=0;i < iElements; i++)
	{
	
		iParamId = pxGetParamVal->iaOID[uiParamPos];
	
		// Malloc and assign the pointer to the Value attr of struct 
		pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
		if(pxGetParamVal->Value == NULL)
		{
			iRet = ERR_OUT_OF_MEMORY; 
			goto errorHandler;
		}

		switch(iParamId)
		{

			// Convert the value - reverse mapping
			// Assign the correct value to the Value attr	
	    		case OID_IGD_WAND_WANCD_WANIPC_ENABLE:
				if(IFX_RevMappingValues(gaxEnable,4,
							(void *)&(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.f_enable),
							(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)				
					goto errorHandler;
				break;

	    		case OID_IGD_WAND_WANCD_WANIPC_RESET:
				strcpy(pxGetParamVal->Value, "0");
                                break;  

	    		case OID_IGD_WAND_WANCD_WANIPC_X_AC9A96_VLANREF:
				//Realloc to higher size
				pvTmpBigVal  = IFX_CWMP_REALLOC(pxGetParamVal->Value, MAX_CONN_NAME_LEN);
				if(pvTmpBigVal != NULL)
				      pxGetParamVal->Value = pvTmpBigVal;

                                VlanId.xCpeId.uiId = pxMatch_Wan_Conn->wancfg.ip.wan_cfg.iid.pcpeId.Id;
                                strcpy(VlanId.xCpeId.sSectionTag, "vlan_ch_cfg");
                                iRet = IFX_GetTr69IdFromCpeId(&VlanId);
	                        if(iRet != IFX_CWMP_SUCCESS)
				{
				        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d]\n", _FUNCL_);
					goto errorHandler;
				}

                                iRet = IFX_AscToIntOID(VlanId.sTr69Id, iaVLANRefOID);
	                        if(iRet != IFX_CWMP_SUCCESS)
				{
				        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d]\n", _FUNCL_);
					goto errorHandler;
				}

                                iRet = IFX_GlobalNameOidConversion(tr69_str, iaVLANRefOID);
                	        if(iRet != IFX_CWMP_SUCCESS)
                                {
        			    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
        					"[%s:%d] [Error] IFX_GlobalNameOidConversion failed\n",
        					__func__, __LINE__);
        	                    goto errorHandler;
        	                }

				strcpy(pxGetParamVal->Value, tr69_str);
				break;
					
		    	case OID_IGD_WAND_WANCD_WANIPC_CONNECTIONSTATUS://RO
				if(IFX_RevMappingValues(saxWanIpConStatus,6,
							(void *)&(pxMatch_Wan_Conn->wancfg.ip.conn_status),
							(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
					goto errorHandler;
	
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;	 

			case OID_IGD_WAND_WANCD_WANIPC_POSSIBLECONNECTIONTYPES://RO
				//If passive_notify
				//Compare the old with new if it is different return the 
				// success else return NULL in Value, free the mem of Value
				strcpy(pxGetParamVal->Value,susWanIpPossibleConTypes);
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
				
			case OID_IGD_WAND_WANCD_WANIPC_CONNECTIONTYPE:
				if(IFX_RevMappingValues(saxWanIpConType,3,
						(void *)&(pxMatch_Wan_Conn->wancfg.ip.conn_type),
						(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
					goto errorHandler;	
				break;

			case OID_IGD_WAND_WANCD_WANIPC_NAME:
				//Realloc to higher size
				pvTmpBigVal  = IFX_CWMP_REALLOC(pxGetParamVal->Value, MAX_CONN_NAME_LEN);
				if(pvTmpBigVal != NULL)
				      pxGetParamVal->Value = pvTmpBigVal;

				strncpy(pxGetParamVal->Value, pxMatch_Wan_Conn->wancfg.ip.wan_cfg.conf_conn_name, (MAX_CONN_NAME_LEN-1));
				break;
				
			case OID_IGD_WAND_WANCD_WANIPC_UPTIME: //RO
				sprintf(pxGetParamVal->Value, "%d", pxMatch_Wan_Conn->wancfg.ip.wan_cfg.uptime);
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
			
			case OID_IGD_WAND_WANCD_WANIPC_LASTCONNECTIONERROR: //RO
				if(IFX_RevMappingValues(saxWanIpLastConError,10,
							(void *)&(pxMatch_Wan_Conn->wancfg.ip.last_conn_error),
							(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
					goto errorHandler;

				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
				
			case OID_IGD_WAND_WANCD_WANIPC_AUTODISCONNECTTIME:
				sprintf(pxGetParamVal->Value, "%d", pxMatch_Wan_Conn->wancfg.ip.wan_cfg.auto_disconn_time);
				break;

			case OID_IGD_WAND_WANCD_WANIPC_IDLEDISCONNECTTIME:
				sprintf(pxGetParamVal->Value, "%d", pxMatch_Wan_Conn->wancfg.ip.wan_cfg.idle_disconn_time);
				break;

			case OID_IGD_WAND_WANCD_WANIPC_WARNDISCONNECTDELAY:
				strcpy(pxGetParamVal->Value, "0");
				break;

			case OID_IGD_WAND_WANCD_WANIPC_RSIPAVAILABLE: //RO
				strcpy(pxGetParamVal->Value,"0");
				/*if(IFX_RevMappingValues(gaxEnable,4,
						(void *)&(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.RSIP_avail),
						(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
				goto errorHandler;*/
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
				
			case OID_IGD_WAND_WANCD_WANIPC_NATENABLED:
				if(IFX_RevMappingValues(gaxEnable,4,
						(void *)&(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.NAT_enabled),
						(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
					goto errorHandler;
				break;
				
			case OID_IGD_WAND_WANCD_WANIPC_ADDRESSINGTYPE:
				if(IFX_RevMappingValues(saxWanIpAddrType,3,
						(void *)&(pxMatch_Wan_Conn->wancfg.ip.addr_type),
						(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
					goto errorHandler;
			
				break;
			
			case OID_IGD_WAND_WANCD_WANIPC_EXTERNALIPADDRESS:
				strncpy((char8 *)pxGetParamVal->Value,
						inet_ntoa(pxMatch_Wan_Conn->wanv4.ip_mask.ip), (MAX_IP_ADDRRESS_LEN-1));
				break;
				
			case OID_IGD_WAND_WANCD_WANIPC_SUBNETMASK:
				strncpy((char8 *)pxGetParamVal->Value,
						inet_ntoa(pxMatch_Wan_Conn->wanv4.ip_mask.mask),
						(MAX_IP_ADDRRESS_LEN-1));
				break;

			case OID_IGD_WAND_WANCD_WANIPC_DEFAULTGATEWAY:
				strncpy((char8 *)pxGetParamVal->Value,
						inet_ntoa(pxMatch_Wan_Conn->wanv4.ip_gw),
						(MAX_IP_ADDRRESS_LEN-1));
				break;

			case OID_IGD_WAND_WANCD_WANIPC_DNSENABLED:
				if(IFX_RevMappingValues(gaxEnable,4,
						(void *)&(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.wandns.DNS_enabled),
						(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
					goto errorHandler;				
				break;

			case OID_IGD_WAND_WANCD_WANIPC_DNSOVERRIDEALLOWED:
				if(IFX_RevMappingValues(gaxEnable,4,
						(void *)&(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.wandns.DNS_override_allowed),
						(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
					goto errorHandler;			
				break;
	
			case OID_IGD_WAND_WANCD_WANIPC_DNSSERVERS:
				pvTmpBigVal = IFX_CWMP_REALLOC(pxGetParamVal->Value, MAX_CONN_NAME_LEN);
				if(pvTmpBigVal != NULL)
					pxGetParamVal->Value = pvTmpBigVal;

				iRet = IFX_ConvertDNSServersArrToString(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.wandns.dns_servers,
												pxGetParamVal->Value,MAX_DNS_SERVERS);
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;

				break;

			case OID_IGD_WAND_WANCD_WANIPC_MAXMTUSIZE:
				sprintf(pxGetParamVal->Value, "%d", pxMatch_Wan_Conn->wancfg.ip.wan_cfg.max_mtu);
				break;

			case OID_IGD_WAND_WANCD_WANIPC_MACADDRESS:
				strncpy(pxGetParamVal->Value,
					pxMatch_Wan_Conn->wancfg.ip.wan_cfg.mac_addr,
					(MAX_MAC_ADDRESS_LEN-1));
				break;

			case OID_IGD_WAND_WANCD_WANIPC_MACADDRESSOVERRIDE:
				if(IFX_RevMappingValues(gaxEnable,4,
						(void *)&(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.mac_addr_override),
						(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
					goto errorHandler;
				break;
	
			case OID_IGD_WAND_WANCD_WANIPC_CONNECTIONTRIGGER:
				strcpy(pxGetParamVal->Value,"AlwaysOn");
				/*if(IFX_RevMappingValues(saxWanIpConTrigger,3,
						(void *)&(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.trigger),
						(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
					goto errorHandler;*/
				break;

			case OID_IGD_WAND_WANCD_WANIPC_ROUTEPROTOCOLRX:
				if(IFX_RevMappingValues(saxWanIpRouteProto,4,
						(void *)&(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.route_rx),
						(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
					goto errorHandler;
				break;

			case OID_IGD_WAND_WANCD_WANIPC_PORTMAPPINGNUMBEROFENTRIES://RO
				if((iRet =IFX_GetWanIpNoPortMapObjs(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.conn_name,
						&uiNoEntries)) != IFX_CWMP_SUCCESS)
					goto errorHandler;
				
				sprintf(pxGetParamVal->Value,"%d",uiNoEntries);
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, IFX_CHK_CHANGE_FLAG_BASED);			
				break;

				
			default:
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "Invalid param id %d!\n", iParamId);
				pxGetParamVal->iFaultCode=ERR_INVAL_PARAMETER_VAL;
				break;
		}
							
		++pxGetParamVal;
	}
	
	return IFX_CWMP_SUCCESS;
		
errorHandler:
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
	ifx_set_wan_atm_vcc_config_stub(pxOperInfo->iOper, pxMatch_Wan_Conn, iFlags);
#endif
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d failed ParamId=%d !\n", __func__, __LINE__,iParamId);
	return IFIN_CWMP_FAILURE;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanIpConSetValidate
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanIpConSetValidate(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
							IN int32 iElements)
{
	/*                                                                      
	** Instance check,Data_Type(1- RO,RW check,2- Int,char,etc
	** 3- String length) check and range_Check(Min,Max) will 
	** be handled by the controller.
	*/

	// Dependency check between parameters and objects should 
	// be handled by this API.This can't be done unless
	// enable is issued by the ACS.

	//Get Cpeid
	//Get the obj from system
	//If it is enabled if we try to modify following parameters return error
	//If it is disabled call IFX_MappingValues functions to check if correct values 
	//are passed.
	
	int32 iRet=IFX_CWMP_SUCCESS;
	uint32 uiCpeid=0;
	WAN_CONN_CFG xMatch_Wan_Conn;
	
	//Get the Cpeid from Tr69 id
	iRet = IFX_GetCpeId(paxParamVal->iaOID,&uiCpeid);
                                
	if(iRet != IFIN_CWMP_SUCCESS)
		goto errorHandler;

	memset(&xMatch_Wan_Conn,0x00,sizeof(xMatch_Wan_Conn));

	WAN_CONN_CFG *pxMatch_Wan_Conn=&xMatch_Wan_Conn;

	pxMatch_Wan_Conn->type = WAN_TYPE_IP;
	//Get the object from system
	iRet= IFX_GetWanObj(pxMatch_Wan_Conn, uiCpeid);
	if(iRet != IFIN_CWMP_SUCCESS)
		goto errorHandler;

	iRet = IFX_ConvertArrToWanConCfgStruct(iElements, paxParamVal, pxMatch_Wan_Conn);
        if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	return IFIN_CWMP_SUCCESS;

errorHandler:
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d failed!\n", __func__, __LINE__);
	return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanIpConAddObj
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanIpConAddObj(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{

    /* This API calls a Platform API which adds the object
    ** in ADD_DISABLE state.
    ** Pass necessary flags to the API
    ** Controller should get the next instance id from DS 
    ** module and pass the full OID to this module.
    */
	
    /* If Cisco proposal comes, this API should handle 
    **  a) Validation of values
    **  b) Forward mapping of TR69 values to system values 
    **  c) addition of object into the system
    */

    // Fill	the ATM_VCC_INFO struct and call the respective
    // ifx_add_atm_vcc api to add the entry in disabled state
    // Forward mapping is required if it has some valid values

    uint32 iFlags=0;
    int32 iRet=0;
    uint32 iOper;
    uint32 uiPcpeId=0;
    WAN_CONN_CFG xWan_Conn;
    uint32 cpeid=0;
    int32 LinkCfgOID[OID_LENGTH];
#ifdef IFX_TR69_ADSLWAN
    int32 iaWanDslLinkEnable[OID_LENGTH]={0,0,0,0,0,OID_IGD_WAND_WANCD_WANDSLLC,
			OID_IGD_WAND_WANCD_WANDSLLC_ENABLE};
    ATM_VCC_INFO xAtm_Vcc_Cfg;
    memset(&xAtm_Vcc_Cfg, 0, sizeof(xAtm_Vcc_Cfg));
#endif
#ifdef IFX_TR69_PTMWAN
    int32 iaWanPtmLinkEnable[OID_LENGTH]={0,0,0,0,0,OID_IGD_WAND_WANCD_WANPTMLC,
			OID_IGD_WAND_WANCD_WANPTMLC_ENABLE};
    PTM_CH_CFG xPtmChCfg;
    memset(&xPtmChCfg, 0, sizeof(xPtmChCfg));
    WAN_PHY_CFG xWanPhy = {0};
    int32 wan_mode = 0;
#endif
#ifdef IFX_TR69_ETHERNETWAN
    int32 iaWanEthLinkEnable[OID_LENGTH]={0,0,0,0,0,OID_IGD_WAND_WANCD_WANELC,
			OID_IGD_WAND_WANCD_WANELC_X_AC9A96_ENABLE};
    ETH_CH_CFG xEthChCfg;
    memset(&xEthChCfg, 0, sizeof(xEthChCfg));
#endif
    int32 i = 0;
    int32 num_vlanchannels = 0;
    vlan_ch_cfg_t * xVlanArr = NULL;
    IFX_ID ParentIID;
    vlan_ch_cfg_t vlan_entry;

    memset(&xWan_Conn, 0, sizeof(xWan_Conn));
    memset(&vlan_entry, 0, sizeof(vlan_entry));

#if 0
	//Need to check if this needs to be macro protected
	// Adding new WanIPConnection/WanPPPConnection is not allowed
	iRet = IFX_CheckIfWanConnPresent(pxParamVal->iaOID);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	//If owner is WEB don't add the object just return success.
	iRet = IFX_ConvertArrToWanConCfgStruct(iElements, pxParamVal, &xWan_Conn);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

#endif
    if(pxParamVal[0].iaOID[2] == WAN_DEVICE_ATM)
    {
        /*If WCD.1. then add on PTMLC
        else adding on DSLLC*/
        if(pxParamVal[0].iaOID[4] == 1)
        {
            #ifndef IFX_TR69_PTMWAN
            /*return error*/
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"Cannot add connection on Channel reserved for PTM\n");
            iRet = IFIN_CWMP_FAILURE;
            goto errorHandler;
            #endif

            #ifdef IFX_TR69_PTMWAN
            //memset the structs. Get PTM channel info
            memset(&LinkCfgOID,0x00,(sizeof(int32) * OID_LENGTH));
            memcpy(LinkCfgOID,iaWanPtmLinkEnable, (OID_LENGTH*sizeof(int32)));
            memcpy(LinkCfgOID,pxParamVal->iaOID,((WAN_CON_DEV_DEPTH+1)*sizeof(int32)));
            cpeid = 0;

            //Get the Cpeid from Tr69 id
            iRet = IFX_GetCpeId(LinkCfgOID, &cpeid);
            if(iRet != IFX_CWMP_SUCCESS)
            {
            	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Get Cpe ID Failed!\n", __func__, __LINE__);
                goto errorHandler;
             }

             xPtmChCfg.iid.cpeId.Id = cpeid;
             iRet = ifx_get_ptm_ch_cfg(&xPtmChCfg, IFX_F_DEFAULT);
             if(iRet != IFX_CWMP_SUCCESS)
                 goto errorHandler;

             /*set xPtmChCfg.cpeId as cpe id. section name as ptmChannel.
             Get all vlan entries under that.
             look for vlan id = 0. Set that cpe id as parent cpeid */
             ParentIID.cpeId.Id = xPtmChCfg.iid.cpeId.Id;
             strcpy(ParentIID.cpeId.secName, "ptm_channel");
             iRet = mapi_get_all_vlan_ch_entries_for_l2ch(&num_vlanchannels, &xVlanArr, &ParentIID, IFX_F_GET_ANY);
             if(iRet != IFX_SUCCESS)
             {
                 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                     " mapi_get_all_vlan_ch_entries_for_l2ch - Mgmt API returned error\n");
                 goto errorHandler;
             }
             if(num_vlanchannels == 0)
             {
                 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"No Vlan channels\n");
                 goto errorHandler;
             }
             for (i=0; i<num_vlanchannels; i++)
             {
                vlan_entry = xVlanArr[i];
                if(vlan_entry.vlanId == -1)
                {
                    uiPcpeId = vlan_entry.iid.cpeId.Id;
                    strcpy(xWan_Conn.wancfg.ip.wan_cfg.l2iface_name, vlan_entry.l2ifName);
                    break;
                }
             } 
             IFX_MEM_FREE(xVlanArr);
             #endif
         }
         else
	 {
             #ifndef IFX_TR69_ADSLWAN
             /*return error*/
             IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"Cannot add connection on Channel meant for ATM\n");
             iRet = IFIN_CWMP_FAILURE;
             goto errorHandler;
             #endif
             #ifdef IFX_TR69_ADSLWAN
             //memset the structs. Get DSL Link Cfg PVC
             //Get DestinationAddress from WanDslLinkConfig module
             memset(&LinkCfgOID,0x00,(sizeof(int32) * OID_LENGTH));
             memcpy(LinkCfgOID, iaWanDslLinkEnable, (OID_LENGTH*sizeof(int32)));
             memcpy(LinkCfgOID, pxParamVal->iaOID, ((WAN_CON_DEV_DEPTH+1)*sizeof(int32)));
        	
             //Get the Cpeid from Tr69 id
             iRet = IFX_GetCpeId(LinkCfgOID, &cpeid);
             if(iRet != IFX_CWMP_SUCCESS)
             {
                 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Get Cpe ID Failed!\n", __func__, __LINE__);
                 goto errorHandler;
             }
        
             xAtm_Vcc_Cfg.iid.cpeId.Id = cpeid;
             //Get the object from system
             iRet= IFX_GetVccObj(&xAtm_Vcc_Cfg, cpeid);
             if(iRet != IFX_CWMP_SUCCESS)
             {
                 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d IFX_GetVccObj Failed !\n", __func__, __LINE__);
                 goto errorHandler;
             }
             if( (xAtm_Vcc_Cfg.type != LINK_TYPE_EOATM) && (xAtm_Vcc_Cfg.type != LINK_TYPE_IPOATM) )
             {
                 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Channel LinkType=[%d] Set correct LinkType before adding IP Connection !\n", __func__, __LINE__, xAtm_Vcc_Cfg.type);
                    goto errorHandler;
             }
             /*set xAtmVccCh.cpeId as cpe id. section name as VCChannel.
               Get all vlan entries under that.
               look for vlan id = 0. Set that cpe id as parent cpeid */
         
             ParentIID.cpeId.Id = xAtm_Vcc_Cfg.iid.cpeId.Id;
             strcpy(ParentIID.cpeId.secName, "adsl_vcchannel");
             iRet = mapi_get_all_vlan_ch_entries_for_l2ch(&num_vlanchannels, &xVlanArr, &ParentIID, IFX_F_GET_ANY);
             if(iRet != IFX_SUCCESS)
             {
                 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        " mapi_get_all_vlan_ch_entries_for_l2ch - Mgmt API returned error\n");
                 goto errorHandler;
             }
             if(num_vlanchannels == 0)
             {
                 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"No Vlan channels\n");
                 goto errorHandler;
             }
             for (i=0; i<num_vlanchannels; i++)
             {
                vlan_entry = xVlanArr[i];
                if(vlan_entry.vlanId == -1)
                {
                    uiPcpeId = vlan_entry.iid.cpeId.Id;
                    strcpy(xWan_Conn.wancfg.ip.wan_cfg.l2iface_name, vlan_entry.l2ifName);
                    break;
                }
             } 
             IFX_MEM_FREE(xVlanArr);
             #endif
        }
    }	
    else
    {
#ifdef IFX_TR69_ETHERNETWAN
        //memset the structs. Get Eth channel
        memset(&LinkCfgOID,0x00,(sizeof(int32) * OID_LENGTH));
        memcpy(LinkCfgOID,iaWanEthLinkEnable, (OID_LENGTH*sizeof(int32)));
        memcpy(LinkCfgOID,pxParamVal->iaOID,((WAN_CON_DEV_DEPTH+1)*sizeof(int32)));
        cpeid = 0;
        //Get the Cpeid from Tr69 id
        iRet = IFX_GetCpeId(LinkCfgOID, &cpeid);
        if(iRet != IFX_CWMP_SUCCESS)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Get Cpe ID Failed!\n", __func__, __LINE__);
            goto errorHandler;
        }

        xEthChCfg.iid.cpeId.Id = cpeid;
        iRet = ifx_get_eth_ch_cfg(&xEthChCfg, IFX_F_DEFAULT);
        if(iRet != IFX_CWMP_SUCCESS)
            goto errorHandler;

        /*set xAtmVccCh.cpeId as cpe id. section name as VCChannel.
        Get all vlan entries under that.
        look for vlan id = 0. Set that cpe id as parent cpeid */

        ParentIID.cpeId.Id = cpeid;
        strcpy(ParentIID.cpeId.secName, "eth_channel");
        iRet = mapi_get_all_vlan_ch_entries_for_l2ch(&num_vlanchannels, &xVlanArr, &ParentIID, IFX_F_GET_ANY);
        if(iRet != IFX_SUCCESS)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                " mapi_get_all_vlan_ch_entries_for_l2ch - Mgmt API returned error\n");
            goto errorHandler;
        }
        if(num_vlanchannels == 0)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"No Vlan channels\n");
            goto errorHandler;
        }
        for (i=0; i<num_vlanchannels; i++)
        {
           vlan_entry = xVlanArr[i];
           if(vlan_entry.vlanId == -1)
           {         
               uiPcpeId = vlan_entry.iid.cpeId.Id;
               strcpy(xWan_Conn.wancfg.ip.wan_cfg.l2iface_name, vlan_entry.l2ifName);
               break;
           }
        } 
        IFX_MEM_FREE(xVlanArr);
#endif
    }
    //Flags should be filled
    //Fill the operation
    iOper = IFX_OP_ADD;
    iFlags =(	IFX_F_DONT_ACTIVATE|IFX_F_DONT_CHECKPOINT|
		IFX_F_DONT_VALIDATE|IFX_F_DONT_WRITE_TO_FLASH);

    xWan_Conn.type = WAN_TYPE_IP;
    //Fill the Cpeid,ParentCepid,TR69Id,Owner
    xWan_Conn.wancfg.ip.wan_cfg.iid.config_owner=pxOpInfo->iCaller;
    xWan_Conn.wancfg.ip.wan_cfg.iid.cpeId.Id=0;
    xWan_Conn.wancfg.ip.wan_cfg.iid.pcpeId.Id=uiPcpeId;
    xWan_Conn.wancfg.ip.wan_cfg.f_enable=IFX_DISABLED;
    xWan_Conn.wancfg.ip.wan_cfg.wandns.DNS_override_allowed = TRUE;

    //Convert array into dotted form and then strcpy
    iRet = IFX_ConvertOidDottedForm(pxParamVal->iaOID, xWan_Conn.wancfg.ip.wan_cfg.iid.tr69Id);
    if(iRet != IFX_CWMP_SUCCESS)
	goto errorHandler;


#ifdef IFX_TR69_WAN_MODS_TEST_STUBS	
    ifx_set_wan_atm_vcc_config_stub(iOper, &xWan_Conn, iFlags);

#else

    switch(pxParamVal[0].iaOID[2])
    {
        case WAN_DEVICE_ATM:
        {
                /*If WCD.1. then add on PTMLC
                else adding on DSLLC*/
	        if(pxParamVal[0].iaOID[4] == 1)
	        {
#ifdef IFX_TR69_PTMWAN
                    wan_mode = WAN_MODE_VDSL_PTM;
                    if((iRet = ifx_get_wan_phy_cfg(&xWanPhy)) == IFX_CWMP_SUCCESS)
                    {
                       if((iRet = compute_wan_mode(xWanPhy.phy_mode, xWanPhy.wan_tc)) != -1)
                       {
                           if((iRet == WAN_MODE_PTM) || (iRet == WAN_MODE_VDSL_PTM))
                           {
                               wan_mode = iRet;
                           }
                       }
                    }
                    xWan_Conn.wancfg.ip.wan_cfg.link_type = LINK_TYPE_PTM;
                    xWan_Conn.wancfg.ip.wan_cfg.wan_mode.mode = wan_mode;
#endif
                }
                else
                {
#ifdef IFX_TR69_ADSLWAN
                    xWan_Conn.wancfg.ip.wan_cfg.wan_mode.mode = WAN_MODE_ATM;
                    xWan_Conn.wancfg.ip.wan_cfg.link_type = xAtm_Vcc_Cfg.type;
#endif
                }
                break;
        }
        case WAN_DEVICE_MII0:
        {
#ifdef IFX_TR69_ETHERNETWAN
                /*...WANDevice.2.*/
                xWan_Conn.wancfg.ip.wan_cfg.wan_mode.mode = WAN_MODE_ETH0;
                xWan_Conn.wancfg.ip.wan_cfg.link_type = LINK_TYPE_ETH;
		//strcpy(xWan_Conn.wancfg.ip.wan_cfg.l2iface_name, xEthChCfg.l2ifname);
#endif
                break;
        }
        case WAN_DEVICE_MII1:
        {
#ifdef IFX_TR69_ETHERNETWAN
                /*...WANDevice.3.*/
                xWan_Conn.wancfg.ip.wan_cfg.wan_mode.mode = WAN_MODE_ETH1;
                xWan_Conn.wancfg.ip.wan_cfg.link_type = LINK_TYPE_ETH;
		//strcpy(xWan_Conn.wancfg.ip.wan_cfg.l2iface_name, xEthChCfg.l2ifname);
#endif
                break;
        }
        default:
        {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] Default case. Return Error!\n", __FUNCTION__, __LINE__);
                break;
        }
    }
    iRet = ifx_mapi_set_wan_config(iOper, &xWan_Conn, iFlags);
#endif

    if(iRet != IFX_SUCCESS)
    {
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"ifx_mapi_set_wan_config Add Mgmt API returned error\n");
	goto errorHandler;
    }	
    return IFIN_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,  "%s:%d failed!\n", __func__, __LINE__);
    return IFIN_CWMP_FAILURE;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanIpConSetValue
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_WanIpConSetValue(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
							IN int32 iElements)
{

	//It can support only one state change in a SET operation.
	//Enabled to Disabled, Disabled to Enabled 
	uint32 i=0;
	uint32 uiCpeid=0;
	uint32 uiVlanCpeid=0;
	uint32 uiOld_EnableVal=0;
	uint32 uiActive_Cpeid=0;
	WAN_CONN_CFG *pxMatch_Wan_Conn=NULL;
	WAN_CONN_CFG xMatch_Wan_Conn;
	memset(&xMatch_Wan_Conn,0x00,sizeof(xMatch_Wan_Conn));
	pxMatch_Wan_Conn=&xMatch_Wan_Conn;
	int32 iRet=IFX_CWMP_SUCCESS;
	uint32 iOper=0,iFlags=0,uiParamPos=0;
	uint32 uiDep_Enable=0;
	uint32 SetParamFlag=0;
	int32 LinkCfgOID[OID_LENGTH];
	int32 Wan_IP_Port_Enable_Oid[OID_LENGTH]={0,0,0,0,0,0,0,OID_IGD_WAND_WANCD_WANIPC_PM,
	  					MAGIC_NUMBER,OID_IGD_WAND_WANCD_WANIPC_PM_PORTMAPPINGENABLED};
	uint32 cpeid=0;
#ifdef IFX_TR69_ADSLWAN
	int32 Wan_Dsl_Link_Enable_Oid[OID_LENGTH]={0,0,0,0,0,OID_IGD_WAND_WANCD_WANDSLLC,
								OID_IGD_WAND_WANCD_WANDSLLC_ENABLE};
	ATM_VCC_INFO xAtm_Vcc_Cfg;
        memset(&xAtm_Vcc_Cfg, 0, sizeof(xAtm_Vcc_Cfg));
#endif
#ifdef IFX_TR69_PTMWAN
	int32 iaWanPtmLinkEnable[OID_LENGTH]={0,0,0,0,0,OID_IGD_WAND_WANCD_WANPTMLC,
						OID_IGD_WAND_WANCD_WANPTMLC_ENABLE};
	PTM_CH_CFG xPtmChCfg;
        memset(&xPtmChCfg, 0, sizeof(xPtmChCfg));
#endif
#ifdef IFX_TR69_ETHERNETWAN
	int32 iaWanEthLinkEnable[OID_LENGTH]={0,0,0,0,0,OID_IGD_WAND_WANCD_WANELC,
								OID_IGD_WAND_WANCD_WANELC_X_AC9A96_ENABLE};
	ETH_CH_CFG xEthChCfg;
        memset(&xEthChCfg, 0, sizeof(xEthChCfg));
#endif
	uint32 uiOutElem=0;
	ParamVal axInParamArr[WAN_IP_NO_DEP_OIDS];
	ParamVal *paxOutParamArr=NULL;
	ParamVal *paxTempParamVal=NULL;
	IFX_CpeId *pxCpeIdArray = NULL;
        int32 iaVLANRefOID[OID_LENGTH] = {0};
        vlan_ch_cfg_t xVlanChCfg;

	///  qos check related variables
	char8  sWan_Conn_vcc[MAX_CONN_NAME_LEN];
	char8  buf[MAX_FILELINE_LEN], sWAN_IDX[MAX_CONN_NAME_LEN];
	int32  nWan_Idx = -1 ;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 vcc_selected[10]={0};
	char8 sLine[256];
        char8 vlan_ref[256] = {0};

        memset (&xVlanChCfg, 0x00, sizeof(xVlanChCfg));

	buf[0]='\0';
	sWan_Conn_vcc[0]='\0';		

	//Get the Cpeid from Tr69 id
	iRet = IFX_GetCpeId(paxParamVal->iaOID,&uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	pxMatch_Wan_Conn->type = WAN_TYPE_IP;
	//Get the object from system
	iRet= IFX_GetWanObj(pxMatch_Wan_Conn, uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	uiOld_EnableVal=pxMatch_Wan_Conn->wancfg.ip.wan_cfg.f_enable;

	if(pxOpInfo->iSubOper == OP_SETVAL_MODIFY)
	{
		IFX_GetSetOldEnableVal(uiCpeid,axOldIPState,&uiOld_EnableVal,IFX_SET_OLD_ENB_VAL);
	}
	else if (pxOpInfo->iSubOper == OP_SETVAL_ACTIVATE)
	{
		IFX_GetSetOldEnableVal(uiCpeid,axOldIPState,&uiOld_EnableVal,IFX_GET_OLD_ENB_VAL);
	}

	// Store the Cpeid which matches External Ip Address with IpAddress from ConnectionReq URL
	// during MODFIY state
	// use the same Cpeid during MODIFY 
	if((pxMatch_Wan_Conn->wanv4.ip_mask.ip.s_addr == guiConnReqIPAddr) && 
		(pxOpInfo->iSubOper == OP_SETVAL_MODIFY))	
	{
		uiActive_Cpeid = uiCpeid;
	}

	//Modify on top of old values.
	if(pxOpInfo->iSubOper != OP_SETVAL_ACTIVATE)
	{
		iRet=IFX_ConvertArrToWanConCfgStruct(iElements, paxParamVal, pxMatch_Wan_Conn);          
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;
	
	        uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);	
	        for (i=0; i < iElements; i++) 
	        {
		    if(paxParamVal[i].iaOID[uiParamPos] == OID_IGD_WAND_WANCD_WANIPC_X_AC9A96_VLANREF)
		    {
                        /* paxParamVal->Value comes as a TR98 hierarchical string format.
                           convert to integer array OID. Then convert the int array to dotted form.
                           Get CpeId of vlan object. Set it as parent of the PPP connection*/
                        iRet = IFX_GlobalNameOidConversion(paxParamVal[i].Value, iaVLANRefOID);
                	if(iRet != IFX_CWMP_SUCCESS)
                        {
			    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					"[%s:%d] [Error] IFX_GlobalNameOidConversion failed\n",
					__func__, __LINE__);
	                    goto errorHandler;
	                }
	                iRet = IFX_ConvertObjOidDottedForm(iaVLANRefOID, vlan_ref);
                	if(iRet != IFX_CWMP_SUCCESS)
                        {
			    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					"[%s:%d] [Error] IFX_ConvertOidDottedForm failed\n",
					__func__, __LINE__);
	                    goto errorHandler;
	                }
		        iRet = IFX_GetCpeIdFromTr69Id(vlan_ref, &uiVlanCpeid,  &pxCpeIdArray);
		        if(iRet != IFX_CWMP_SUCCESS)
                        {
			    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					"[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
					__func__, __LINE__);
			    IFX_CWMP_FREE(pxCpeIdArray);
			    goto errorHandler;
		        }
                        xVlanChCfg.iid.cpeId.Id= pxCpeIdArray->uiId;
              		IFX_CWMP_FREE(pxCpeIdArray);
                        iRet = mapi_get_vlan_ch_entry(-1, &xVlanChCfg, IFX_F_GET_ANY);
		        if(iRet != IFX_CWMP_SUCCESS)
                        {
			    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					"[%s:%d] [Error] mapi_get_vlan_ch_entry failed [%s]\n",
					__func__, __LINE__, vlan_ref);
			    goto errorHandler;
		        }
		        pxMatch_Wan_Conn->wancfg.ip.wan_cfg.iid.pcpeId.Id = xVlanChCfg.iid.cpeId.Id;
		        strcpy(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.l2iface_name, xVlanChCfg.l2ifName);
                        break;
                } 
            }
        }
	//Get the WanIpConParamPos 
	uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);
	switch(pxOpInfo->iSubOper)
	{
		case OP_SETVAL_CHK_MODIFY_DEP:
			break;
					
		case OP_SETVAL_MODIFY:
		case OP_SETVAL_ACTIVATE:
				//TBD::Dependency check is moved into MODIFY
					
				//Call global function to get the WanPPP/WanIP enable value
				//Pass Oid array with magic nos it should return 
				//OID,Name,Values,error_status

				//IpConnection-PortMappingEntries when it is enabled
				//We cannot disable IpConnection
				//memset the structs passed to GlobalGetVal
				memset(axInParamArr,0x00,(sizeof(ParamVal) *WAN_IP_NO_DEP_OIDS));
				memcpy(axInParamArr->iaOID, Wan_IP_Port_Enable_Oid, (sizeof(int32)*OID_LENGTH));
				memcpy((axInParamArr)->iaOID,paxParamVal->iaOID, (sizeof(int32)*(uiParamPos)));

				iRet=IFX_GlobalGetVal(axInParamArr,&paxOutParamArr, &uiOutElem);
				if(iRet != IFX_CWMP_SUCCESS)
				{
					IFX_PrintOID(axInParamArr->iaOID);
					IFX_FreeParamvalArr(&paxOutParamArr,uiOutElem);
					iRet = IFX_CWMP_SUCCESS;
				}
				
				paxTempParamVal = paxOutParamArr;
				for(i=0; i < uiOutElem; ++i) 
				{
					if(paxTempParamVal != NULL)
					{
						if((iRet = IFX_FwdMappingValues(gaxEnable,4,
									(void *)(paxTempParamVal->Value),	
									(void *)&(uiDep_Enable))) !=IFX_CWMP_SUCCESS)
						{
						        goto ChkModifyDepErrorHandler;
						}
						/*Trying to disable IP Connection, Portmapping entries should not be in enabled state*/
					 	if((uiOld_EnableVal == IFX_ENABLED) && (pxMatch_Wan_Conn->wancfg.ip.wan_cfg.f_enable== IFX_DISABLED)) 
						{
							if(uiDep_Enable == IFX_ENABLED)
							{
								iRet=ERR_CWMP_INVAL_PARAM_VAL;
								goto ChkModifyDepErrorHandler;
							}
							else
							{
								continue;
							}
						}
					}
					paxTempParamVal++;
				}

ChkModifyDepErrorHandler:
				iRet = IFX_FreeParamvalArr(&paxOutParamArr,uiOutElem);
				if(iRet != IFX_CWMP_SUCCESS)
						goto errorHandler;
				
				//Completion of first case
				
    uiDep_Enable = IFX_ENABLED;
    if(paxParamVal[0].iaOID[2] == WAN_DEVICE_ATM)
    {
        /*If enabling the IPConnection, then the parent DSL or PTM link config should not be disabled*/
        if(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.f_enable== IFX_ENABLED)
	{	
            /*WCD.1 -> PTM*/
	        if(paxParamVal[0].iaOID[4] == 1)
	        {
			#ifndef IFX_TR69_PTMWAN
			/*return error*/
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"Cannot add connection on Channel reserved for PTM\n");
       			iRet = IFIN_CWMP_FAILURE;
	                goto errorHandler;
			#endif

			#ifdef IFX_TR69_PTMWAN
			//memset the structs
        		memset(&LinkCfgOID, 0x00,(sizeof(int32) * OID_LENGTH));
			memcpy(LinkCfgOID, iaWanPtmLinkEnable, (sizeof(int32)*OID_LENGTH));
			memcpy(LinkCfgOID, paxParamVal->iaOID, (sizeof(int32)*(WAN_CON_DEV_DEPTH +1)));
	
    	       //Get the Cpeid from Tr69 id
        	   iRet = IFX_GetCpeId(LinkCfgOID, &cpeid);
	           if(iRet != IFX_CWMP_SUCCESS)
    	       {
        	       IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Get Cpe ID Failed!\n", __func__, __LINE__);
            	   goto errorHandler;
	           }
   	
    	       xPtmChCfg.iid.cpeId.Id = cpeid;
        	   iRet = ifx_get_ptm_ch_cfg(&xPtmChCfg, IFX_F_DEFAULT);
               if(iRet != IFX_CWMP_SUCCESS)
               {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d ifx_get_ptm_ch_cfg() Failed!\n", __func__, __LINE__);
                    goto errorHandler;
               }
       	       uiDep_Enable = xPtmChCfg.f_enable; 
			   #endif
		   }
		   else
           {
				#ifndef IFX_TR69_ADSLWAN
				/*return error*/
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"Cannot modify connection on Channel reserved for ATM\n");
                iRet = IFIN_CWMP_FAILURE;
                goto errorHandler;
				#endif

                #ifdef IFX_TR69_ADSLWAN
            	memset(&LinkCfgOID,0x00,(sizeof(int32) * OID_LENGTH));
		    	memcpy(LinkCfgOID,Wan_Dsl_Link_Enable_Oid, (sizeof(int32)*OID_LENGTH));
		    	memcpy(LinkCfgOID,paxParamVal->iaOID, (sizeof(int32)*(WAN_CON_DEV_DEPTH +1)));
				
                //Get the Cpeid from Tr69 id
                iRet = IFX_GetCpeId(LinkCfgOID, &cpeid);
                if(iRet != IFX_CWMP_SUCCESS)
                {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Get Cpe ID Failed!\n", __func__, __LINE__);
                    goto errorHandler;
                }
       
                xAtm_Vcc_Cfg.iid.cpeId.Id = cpeid;
                //Get the object from system
                iRet= IFX_GetVccObj(&xAtm_Vcc_Cfg, cpeid);
                if(iRet != IFX_CWMP_SUCCESS)
                {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d IFX_GetVccObj() Failed!\n", __func__, __LINE__);
                    goto errorHandler;
                }

                uiDep_Enable = xAtm_Vcc_Cfg.f_enable;
#endif
            }
		    if(uiDep_Enable == IFX_DISABLED) 
		    {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Cannot enable child when parent is disabed!\n", __func__, __LINE__);
					iRet=ERR_CWMP_INVAL_PARAM_VAL;
					goto ChkModifyDepErrorHandler;
			} 
	 	}
	}
	else
	{	
#ifdef IFX_TR69_ETHERNETWAN
		    //memset the structs
        	memset(&LinkCfgOID, 0x00,(sizeof(int32) * OID_LENGTH));
			memcpy(LinkCfgOID, iaWanEthLinkEnable, (sizeof(int32)*OID_LENGTH));
			memcpy(LinkCfgOID, paxParamVal->iaOID, (sizeof(int32)*(WAN_CON_DEV_DEPTH +1)));

           //Get the Cpeid from Tr69 id
           iRet = IFX_GetCpeId(LinkCfgOID, &cpeid);
           if(iRet != IFX_CWMP_SUCCESS)
           {
               IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Get Cpe ID Failed!\n", __func__, __LINE__);
               goto errorHandler;
           }
   
           xEthChCfg.iid.cpeId.Id = cpeid;
           iRet = ifx_get_eth_ch_cfg(&xEthChCfg, IFX_F_DEFAULT);
           if(iRet != IFX_CWMP_SUCCESS)
           {
               IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d ifx_get_eth_ch_cfg() Failed!\n", __func__, __LINE__);
               goto errorHandler;
           }
           uiDep_Enable =  xEthChCfg.f_enable;
           if(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.f_enable== IFX_ENABLED)
		   {	
               if(uiDep_Enable == IFX_DISABLED)
               {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d ifx_get_eth_ch_cfg() Failed!\n", __func__, __LINE__);
					iRet=ERR_CWMP_INVAL_PARAM_VAL;
					goto ChkModifyDepErrorHandler;
               }
           }
#endif
	}
	if(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.f_enable == IFX_ENABLED) 
	{
          if(paxParamVal[0].iaOID[2] == WAN_DEVICE_ATM)
          {
               /*WCD.1 -> ATM*/
               if(paxParamVal[0].iaOID[4] != 1)
	       {
		//Minimum validation
		//Check if IPoA / CLIP /PPPoE /PPPoA is passed with IP_Bridged
		if(pxMatch_Wan_Conn->wancfg.ip.conn_type == WAN_IP_CONN_TYPE_IP_BRIDGED)
		{
			if(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.link_type != WAN_LINK_TYPE_EOATM)
			{
				iRet = ERR_CWMP_INVAL_PARAM_VAL;
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                         "%s:%d failed!\n", __func__, __LINE__);
                		goto errorHandler;
			}
		}
		if(pxMatch_Wan_Conn->wancfg.ip.conn_type == WAN_IP_CONN_TYPE_IP_ROUTED)
		{
			if((pxMatch_Wan_Conn->wancfg.ip.wan_cfg.link_type != WAN_LINK_TYPE_EOATM) && (pxMatch_Wan_Conn->wancfg.ip.wan_cfg.link_type != WAN_LINK_TYPE_IPOATM))
			{
				iRet = ERR_CWMP_INVAL_PARAM_VAL;
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                         "%s:%d failed!\n", __func__, __LINE__);
                		goto errorHandler;
			}
		}
		if(pxMatch_Wan_Conn->wancfg.ip.addr_type == IP_TYPE_AUTO)
		{
			if(pxMatch_Wan_Conn->wancfg.ip.conn_type == WAN_IP_CONN_TYPE_IP_ROUTED)
	    		{
				pxMatch_Wan_Conn->wancfg.ip.addr_type = IP_TYPE_DHCP;
	    		}

			if(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.link_type != WAN_LINK_TYPE_EOATM)
			{
				iRet = ERR_CWMP_INVAL_PARAM_VAL;
		                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                               		"%s:%d failed!\n", __func__, __LINE__);
                		goto errorHandler;
			}
		}


		if((pxMatch_Wan_Conn->wancfg.ip.wan_cfg.link_type == WAN_LINK_TYPE_PPPOATM) ||
		               (pxMatch_Wan_Conn->wancfg.ip.wan_cfg.link_type == WAN_LINK_TYPE_PPPOE))
        	{
			//	xOutWanDslLinkConf=NULL;
        		iRet = ERR_CWMP_INVAL_PARAM_VAL;
		        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                		"%s:%d failed!\n", __func__, __LINE__);
			goto errorHandler;
         	}
            }
	}				
     }

	// check for qos enabled on the interface
	if((uiOld_EnableVal == IFX_ENABLED && pxMatch_Wan_Conn->wancfg.ip.wan_cfg.f_enable == IFX_DISABLED) || 
								    pxMatch_Wan_Conn->wancfg.ip.conn_type == WAN_IP_CONN_TYPE_IP_BRIDGED )
	{
		if(ifx_GetObjData(FILE_SYSTEM_STATUS, "http_wan_vcc_select", "WAN_VCC", iFlags, &outFlag, sWAN_IDX) == IFX_SUCCESS)
		{
        	nWan_Idx = atoi(sWAN_IDX);
            nWan_Idx = ( (nWan_Idx < 1) ? 1 : nWan_Idx );

            sprintf(buf, "%s_%d_vcc", "wan", nWan_Idx);
            if (ifx_GetObjData(FILE_RC_CONF, "wan_main", buf, IFX_F_GET_ENA, &outFlag, sWan_Conn_vcc) == IFX_SUCCESS)
			{
            	ifx_GetObjData(FILE_RC_CONF, "qos_queuemgmt", "qm_atmQmode",IFX_F_DEFAULT,&outFlag,sLine);
				if (atoi(sLine) == IFX_MAPI_QoS_ATM_PVC_BASED)
				{
                	if(ifx_GetObjData(FILE_RC_CONF, "qos_queuemgmt", "qm_qIf",IFX_F_DEFAULT,&outFlag,vcc_selected) == IFX_SUCCESS)
					{
                    	if(strcmp( sWan_Conn_vcc, vcc_selected ))
						{
                        	iRet=ERR_CWMP_INVAL_OPER;
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                          "%s:%d Cannot disable the QoS enabled interface! \n "
                                          "Disable QoS before disabling the interface \n", __func__, __LINE__);
                            goto errorHandler;
						}
					}
				}
			}
		}
	}

		
		//Check if the external ipaddrress == guiConnReqIPAddr
		// and if the Owner ==  tr69 
		//     if SubOper == MODIFY then return status=1

			if(uiOld_EnableVal == IFX_ENABLED) 
			{								
				if(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.f_enable== IFX_DISABLED) 
				{
						//Call with deactivate and modify flags 
						if((pxOpInfo->iCaller == ACC_TR69) && 
							(pxOpInfo->iSubOper == OP_SETVAL_MODIFY) &&
							//(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.ip_mask.ip.s_addr 
							//			== guiConnReqIPAddr)) 
							(uiActive_Cpeid == uiCpeid))
						{ 
							SetParamFlag = 1;
							uiActiveWANIPCpeid = uiActive_Cpeid;
							iFlags= (IFX_F_DEACTIVATE|IFX_F_MODIFY|
                                     IFX_F_INT_DONT_CONFIGURE|
									IFX_F_DONT_CHECKPOINT|IFX_F_DONT_VALIDATE |
									IFX_F_DONT_WRITE_TO_FLASH);
                			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
				                  	   "%s:%d ACTIVE & MODIFY :Enable->Disable!\n", __func__, __LINE__);
						}
						else
						{
							iFlags= (IFX_F_DEACTIVATE|IFX_F_MODIFY|
								IFX_F_DONT_CHECKPOINT|IFX_F_DONT_VALIDATE |
								IFX_F_DONT_WRITE_TO_FLASH);

							//Store the current Enable Value in Old Val array
							IFX_GetSetOldEnableVal(uiCpeid,axOldIPState,
								(uint32 *)&pxMatch_Wan_Conn->wancfg.ip.wan_cfg.f_enable,
								IFX_RESET_OLD_ENB_VAL);
						}
						pxMatch_Wan_Conn->wancfg.ip.wan_cfg.f_enable = IFX_DISABLED;
						IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
				                  "%s:%d ACTIVATE | MODIFY : Enable->Disable!\n", __func__, __LINE__);
					} 
					else if (pxMatch_Wan_Conn->wancfg.ip.wan_cfg.f_enable == IFX_ENABLED) 
					{
						if((pxOpInfo->iCaller == ACC_TR69) &&
                             (pxOpInfo->iSubOper == OP_SETVAL_MODIFY) &&
								(uiActive_Cpeid == uiCpeid))
				        { 
							SetParamFlag = 1;
							uiActiveWANIPCpeid = uiActive_Cpeid;
							iFlags= (IFX_F_MODIFY|IFX_F_INT_DONT_CONFIGURE|
								IFX_F_DONT_CHECKPOINT|
								IFX_F_DONT_WRITE_TO_FLASH);
                				
						   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
				                  "%s:%d ACTIVE & MODIFY :Enable->Enable !\n", __func__, __LINE__);
						}
						else
						{	
							iFlags= (IFX_F_MODIFY|
								IFX_F_DONT_CHECKPOINT|
								IFX_F_DONT_WRITE_TO_FLASH);

							IFX_GetSetOldEnableVal(uiCpeid,axOldIPState,
								(uint32 *)&pxMatch_Wan_Conn->wancfg.ip.wan_cfg.f_enable,
								IFX_RESET_OLD_ENB_VAL);
                			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
				                  "%s:%d ACTIVATE | MODIFY :Enable->Enable !\n", __func__, __LINE__);
						}
						pxMatch_Wan_Conn->wancfg.ip.wan_cfg.f_enable = IFX_ENABLED;
					}
				}
				else if (uiOld_EnableVal == IFX_DISABLED)
				{
					if(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.f_enable == IFX_DISABLED) 
					{
						//Call with don't activate and modify
						 iFlags= (IFX_F_DONT_ACTIVATE|IFX_F_MODIFY|
								IFX_F_DONT_CHECKPOINT|IFX_F_DONT_VALIDATE|
								IFX_F_DONT_WRITE_TO_FLASH);
							
						IFX_GetSetOldEnableVal(uiCpeid,axOldIPState,
							(uint32 *)&pxMatch_Wan_Conn->wancfg.ip.wan_cfg.f_enable, IFX_RESET_OLD_ENB_VAL);

						pxMatch_Wan_Conn->wancfg.ip.wan_cfg.f_enable = IFX_DISABLED;
				        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
				                  "%s:%d MODIFY : Disable->Disable !\n", __func__, __LINE__);						
					}
					else if(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.f_enable == IFX_ENABLED) 
					{
							//Call the API with Modify
							iFlags= (IFX_F_MODIFY|
								IFX_F_DONT_CHECKPOINT|
								IFX_F_DONT_WRITE_TO_FLASH);
							
							IFX_GetSetOldEnableVal(uiCpeid,axOldIPState,
								(uint32 *)&pxMatch_Wan_Conn->wancfg.ip.wan_cfg.f_enable,
								IFX_RESET_OLD_ENB_VAL);
							pxMatch_Wan_Conn->wancfg.ip.wan_cfg.f_enable = IFX_ENABLED;
						  
						   	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
				                  "%s:%d MODIFY :Disable->Enable !\n", __func__, __LINE__);
					}	
				}
				
				//To make sure that we don't pass invalid values during DHCP mode
				//This should be handled in Validation
				if((pxMatch_Wan_Conn->wancfg.ip.addr_type == IP_TYPE_DHCP)||
						(pxMatch_Wan_Conn->wancfg.ip.addr_type == IP_TYPE_AUTO))
				{
					memset(&pxMatch_Wan_Conn->wanv4.ip_mask.ip, 0x00,sizeof(struct in_addr));
					memset(&pxMatch_Wan_Conn->wanv4.ip_mask.mask,0x00,sizeof(struct in_addr));
					memset(&pxMatch_Wan_Conn->wanv4.ip_gw, 0x00,sizeof(struct in_addr));
				}

				if(pxMatch_Wan_Conn->wancfg.ip.conn_type == WAN_IP_CONN_TYPE_IP_BRIDGED)
				{
					pxMatch_Wan_Conn->wancfg.ip.addr_type = IP_TYPE_AUTO;
				}
				//Fill the Cpeid,ParentCepid,TR69Id,Owner
				pxMatch_Wan_Conn->wancfg.ip.wan_cfg.iid.cpeId.Id=uiCpeid;
				pxMatch_Wan_Conn->wancfg.ip.wan_cfg.iid.config_owner=pxOpInfo->iCaller;
				
				iOper = IFX_OP_MOD;
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
	ifx_set_wan_atm_vcc_config_stub(iOper, pxMatch_Wan_Conn, iFlags);
#else
#if 0
        switch(paxParamVal[0].iaOID[2])
        {
            case WAN_DEVICE_ATM:
            {
                /*...WANDevice.1.*/
                /*WCD.1 -> PTM*/
	        if(paxParamVal[0].iaOID[4] == 1)
	        {
                    pxMatch_Wan_Conn->wancfg.ip.wan_cfg.link_type = LINK_TYPE_PTM;
                }
                break;
            }
            case WAN_DEVICE_MII0:
            {
#ifdef IFX_TR69_ETHERNETWAN 
                /*...WANDevice.2.*/
                pxMatch_Wan_Conn->wancfg.ip.wan_cfg.wan_mode.mode = WAN_MODE_ETH0;
#endif
                break;
            }
            case WAN_DEVICE_MII1:
            {
#ifdef IFX_TR69_ETHERNETWAN 
                /*...WANDevice.3.*/
                pxMatch_Wan_Conn->wancfg.ip.wan_cfg.wan_mode.mode = WAN_MODE_ETH1;
#endif
                break;
            }
            default:
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] Default case. Error!\n", __FUNCTION__, __LINE__);
                break;
            }
        }
#endif
        iRet = ifx_mapi_set_wan_config(iOper, pxMatch_Wan_Conn, iFlags);
#endif

        if(iRet != IFX_SUCCESS)
        {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "ifx_mapi_set_wan_config -Modify Mgmt API returned error\n");
                goto errorHandler;
        }	
        break;

		default:
			break;
					
	}
	//IFX_CWMP_FREE(pxMatch_Wan_Conn);
	if((SetParamFlag ==1) && (iRet == IFX_CWMP_SUCCESS))
	{
		return IFX_CWMP_NEED_ACTIVATE;
	}

	if((pxOpInfo->iSubOper == OP_SETVAL_ACTIVATE) && (iRet == IFX_CWMP_SUCCESS))
	{
            return IFX_CWMP_NO_REBOOT_SAVE;
	}

	return IFIN_CWMP_SUCCESS;

errorHandler:
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d failed!\n", __func__, __LINE__);
	if((uiActiveWANIPCpeid == uiCpeid) || 
		 (pxOpInfo->iSubOper == OP_SETVAL_ACTIVATE))
	{
		return IFX_CWMP_NEED_REBOOT_DONT_SAVE;
	}
	else
	{
		return iRet;
	}
}

/* 
** =============================================================================
**   Function Name    : IFX_WanIpSetCommit
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanIpConSetCommit()
{
	return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanIpConSetUndo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanIpConSetUndo()
{
	return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanIpConCheckDeleteDependency 
**   Description      : Check the dependent objects before deleting the
**                      IP Connection object
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanIpConCheckDeleteDependency(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
			IN int32 iElements, OUT void **ppxParamStructRet, OUT int32 * piNumRetElem)
{
	uint32 i = 0;
	uint32 uiParamPos=0;
	ParamVal *Param_DepOids=NULL;
	int32 ip_stats_OID[OID_LENGTH] = {0,0,0,0,0,OID_IGD_WAND_WANCD_WANIPC,
									MAGIC_NUMBER,
									OID_IGD_WAND_WANCD_WANIPC_S};
	int32 ip_port_OID[OID_LENGTH] ={0,0,0,0,0,OID_IGD_WAND_WANCD_WANIPC,
									MAGIC_NUMBER,
									OID_IGD_WAND_WANCD_WANIPC_PM,
									MAGIC_NUMBER};
	Param_DepOids = IFIN_CWMP_MALLOC((WAN_IP_NO_DEP_OIDS+1)* sizeof(ParamVal));
	if(Param_DepOids == NULL){	
	   goto errorHandler;
	}

	//Get the WanIpConParamPos 
	uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);

	memcpy((Param_DepOids+0)->iaOID,ip_stats_OID,(sizeof(int32)*OID_LENGTH));
	memcpy((Param_DepOids+1)->iaOID,ip_port_OID,(sizeof(int32)*OID_LENGTH));
	memcpy((Param_DepOids+2)->iaOID,paxParamVal->iaOID, (sizeof(int32)*(uiParamPos+1)));

	for(i=0; i <WAN_IP_NO_DEP_OIDS; ++i)
		memcpy((Param_DepOids+i)->iaOID, paxParamVal->iaOID, (sizeof(int32)*(uiParamPos+1)));

	*ppxParamStructRet = (void *)Param_DepOids;
	*piNumRetElem = WAN_IP_NO_DEP_OIDS+1;
	return IFIN_CWMP_SUCCESS;		
errorHandler:
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                          		 "%s:%d failed!\n", __func__, __LINE__);
	return IFIN_CWMP_FAILURE;
}
/* 
** =============================================================================
**   Function Name    : IFX_WanIpConSetDelete
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanIpConSetDelete(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
			IN int32 iElements, OUT void **ppxParamStructRet, OUT int32 * piNumRetElem)
{

	uint32 uiCpeid=0;
	uint32 uiStatus=0;
	WAN_CONN_CFG xMatch_Wan_Conn;
	memset(&xMatch_Wan_Conn,0x00,sizeof(xMatch_Wan_Conn));
	WAN_CONN_CFG *pxMatch_Wan_Conn=&xMatch_Wan_Conn;
	int32 iRet=0;
	uint32 iOper=0,iFlags=0;
	
	//Get the Cpeid from Tr69 id
	iRet = IFX_GetCpeId(paxParamVal->iaOID,&uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	pxMatch_Wan_Conn->type = WAN_TYPE_IP;
	//Get the object from system
	iRet= IFX_GetWanObj(pxMatch_Wan_Conn, uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	switch(pxOpInfo->iSubOper)
	{
		// handle CHK_DELETE_DEP
		case OP_SETVAL_CHK_DEL_ALLOWED:
			// handle CHK_DELETE_ALLOWED
			//Check for default instance if del is called by TR69
			if((pxOpInfo->iCaller == ACC_TR69) && 
			      (pxMatch_Wan_Conn->wanv4.ip_mask.ip.s_addr == guiConnReqIPAddr)) 
			{
				uiStatus=1;	
			}
			break;

		case OP_SETVAL_DELETE:
			//handle DELETE operation
			//Call Platform API to delete the obj in the system
			//If del is called by web we need to pass special owner for which API 
			//will not post a message.
			pxMatch_Wan_Conn->wancfg.ip.wan_cfg.iid.config_owner = pxOpInfo->iCaller;
			pxMatch_Wan_Conn->wancfg.ip.wan_cfg.iid.cpeId.Id = uiCpeid;
			pxMatch_Wan_Conn->type = WAN_TYPE_IP;
			memset(pxMatch_Wan_Conn->wancfg.ip.wan_cfg.iid.tr69Id, 0x00, MAX_TR69_ID_LEN);
			iOper = IFX_OP_DEL;
			iFlags = (IFX_F_DELETE|IFX_F_DONT_VALIDATE|
					IFX_F_DONT_CHECKPOINT|IFX_F_DONT_WRITE_TO_FLASH);

#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
			ifx_set_wan_atm_vcc_config_stub(iOper, pxMatch_Wan_Conn, iFlags);
#else
        switch(paxParamVal[0].iaOID[2])
        {
            case WAN_DEVICE_ATM:
            {
                /*...WANDevice.1.*/
                /*If WCD.1. then PTMLC
                else DSLLC*/
	            if(paxParamVal[0].iaOID[4] == 1)
	            {
                    pxMatch_Wan_Conn->wancfg.ip.wan_cfg.wan_mode.mode = WAN_MODE_VDSL_PTM;
                }
                else
                {
                    pxMatch_Wan_Conn->wancfg.ip.wan_cfg.wan_mode.mode = WAN_MODE_ATM;
                }
                break;
            }
            case WAN_DEVICE_MII0:
            {
#ifdef IFX_TR69_ETHERNETWAN
                /*...WANDevice.2.*/
                pxMatch_Wan_Conn->wancfg.ip.wan_cfg.wan_mode.mode = WAN_MODE_ETH0;
#endif
                break;
            }
            case WAN_DEVICE_MII1:
            {
#ifdef IFX_TR69_ETHERNETWAN
                /*...WANDevice.3.*/
                pxMatch_Wan_Conn->wancfg.ip.wan_cfg.wan_mode.mode = WAN_MODE_ETH1;
#endif
                break;
            }
            default:
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] Default case. Return Error!\n", __FUNCTION__, __LINE__);
                break;
            }
        }
        iRet = ifx_mapi_set_wan_config(iOper, pxMatch_Wan_Conn, iFlags);
#endif
			
	if(iRet != IFX_SUCCESS)
	{
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			"ifx_mapi_set_wan_config -delete Mgmt API returned error\n");
		goto errorHandler;
	}
	//Reset the Old Enable Value stored in the array
	IFX_GetSetOldEnableVal(uiCpeid,axOldIPState, (uint32 *)&pxMatch_Wan_Conn->wancfg.ip.wan_cfg.f_enable,
											IFX_RESET_OLD_ENB_VAL);

	break;
			
	default:
		break;
	}

	if((uiStatus==1) && (iRet == IFX_CWMP_SUCCESS))
	{
		return IFX_CWMP_NEED_ACTIVATE;
	}
	return IFIN_CWMP_SUCCESS;
	
errorHandler:
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                          		 "%s:%d failed!\n", __func__, __LINE__);
	return IFIN_CWMP_FAILURE;

}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslSetFree
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanIpConSetFree()
{
	return IFX_CWMP_SUCCESS;
}


/* 
** =============================================================================
**   Function Name    : IFX_WanIpConSetAttr
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

int32
IFX_WanIpConSetAttr(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{
	int32 iRet=IFX_CWMP_SUCCESS,i=0;
	OperInfo xOpInfo;
	
	xOpInfo.iCaller = pxOpInfo->iCaller;
	xOpInfo.iOper= OP_GETVAL;
	xOpInfo.iSubOper= OP_GETVAL_NORMAL;
	
	iRet = IFX_WanIpConGetValue(&xOpInfo,pxParamVal, iElements);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorFreeHandler;
	
	iRet = IFX_SetAttributesInfo(pxOpInfo,pxParamVal, iElements);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorFreeHandler;

	errorFreeHandler:
		for(i=0; i < iElements; i++)
		IFX_CWMP_FREE(pxParamVal[i].Value);
		
                if (iRet)
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
		return iRet;
}



/* 
** =============================================================================
**   Function Name    : IFX_WanIpConUpdateChildInfo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

static int32 IFX_WanIpConUpdateChildInfo(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{
	uint32 i=0,iRet=0;
	char8 usSecTag[IFX_MAX_SECTION_TAG_LEN]={0};
	char8 usParamTag[IFX_MAX_NAME_LEN]={0};
	uint32 uiParamPos=0,uiChildObjId=0;
	uint32 uiCpeid=0;
	int32 *iaOID=NULL;
	uint32 uiNumNV=1;
	//IFX_CpeId pxCpeId;
	IFX_Id xIfx_Id;
	IFX_NameValue pxNVArray;
	uint32 uiOper=IFX_NOTIFY_OPER_MODIFY;
	ParamVal *pxTempParamVal=pxParamVal;
	
		//memset the structs
		memset(&xIfx_Id,0x00,sizeof(xIfx_Id));
		memset(&pxNVArray,0x00,sizeof(pxNVArray));
		//Get Cpeid
		iRet = IFX_GetCpeId(pxTempParamVal->iaOID, &uiCpeid);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;

		//Get the child object Oid
		uiChildObjId = IFX_GetParamIdPos((int32 *)pxTempParamVal->pReserved);
		iaOID = (int32 *)pxTempParamVal->pReserved;

		for(i=0; i < iElements; i++)

		{
			//Get the Param Oid of this object
			uiParamPos= IFX_GetParamIdPos(pxTempParamVal->iaOID);
			
			if(pxTempParamVal->iaOID[uiParamPos] ==			
				 OID_IGD_WAND_WANCD_WANIPC_PORTMAPPINGNUMBEROFENTRIES)
				 {
					if(iaOID[uiChildObjId-1] ==	OID_IGD_WAND_WANCD_WANIPC_PM)
					{
						//Get the section and Paramtag
						iRet=IFX_GetSectionParamTag(pxTempParamVal->psRCTag, usParamTag, usSecTag);
						if(iRet != IFX_CWMP_SUCCESS)
							goto errorHandler;

						xIfx_Id.uiConfigOwner= pxOpInfo->iCaller;
						xIfx_Id.xCpeId.uiId= uiCpeid;
						strncpy(xIfx_Id.xCpeId.sSectionTag,usSecTag, IFX_MAX_SECTION_TAG_LEN-1);
						xIfx_Id.xCpeId.sSectionTag[IFX_MAX_SECTION_TAG_LEN-1] = '\0';
						strncpy(pxNVArray.sName,usParamTag, IFX_MAX_NAME_LEN-1);
						pxNVArray.sName[IFX_MAX_NAME_LEN-1] = '\0';
												
						iRet=IFX_SendNotify(&xIfx_Id, uiNumNV, 
												&pxNVArray, uiOper);
						if(iRet != IFX_CWMP_SUCCESS)
						{
							IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 			"%s:%d IFX_SendNotify failed!\n", __func__, __LINE__);
							
							goto errorHandler;
						}
					}
				}

			pxTempParamVal++;
			
		}
					
		return IFX_CWMP_SUCCESS;

		errorHandler:
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
			
			return IFX_CWMP_FAILURE;
			
}



/* 
** =============================================================================
**   Function Name    : IFX_WanDslLinkConfig_Init
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_WanIpConnection_Init(void)
{
	int32 iRet = IFX_CWMP_SUCCESS;

    
	/* Register the WanDslLinkConfig module function pointer in the object model */
	iRet = ifx_ds_register_function(IFX_WAN_IPCON_OBJ, IFX_WanIpConnection);

	/* Check for error */
	if (iRet != IFX_CWMP_SUCCESS)
	{
	    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                "Unable to Register %s with Object Model\n",
	                 IFX_WAN_IPCON_OBJ);
	    goto errorHandler;
	}

	errorHandler:
			return iRet;
}
/* 
** =============================================================================
**   Function Name    : IFX_CheckIfWanConnPresent
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

int32
IFX_CheckIfWanConnPresent(int32 *iaOID)
{
	uint32 i=0,j=0;
	int32 iRet=IFX_CWMP_SUCCESS;

	int32 iaWCDOID[OID_LENGTH];
	char8 sValIP[10]={0};
	char8 sValPPP[10]={0};

	memset(iaWCDOID, 0, sizeof(int32)*OID_LENGTH);

	// Adding new WanIPConnection/WanPPPConnection is not allowed
	memcpy(iaWCDOID,iaOID,((WAN_CON_DEV_DEPTH+1)*sizeof(int32)));
	iaWCDOID[(WAN_CON_DEV_DEPTH+1)]=OID_IGD_WAND_WANCD_WANIPCONNECTIONNUMBEROFENTRIES;

	//Get the WanConnections available on top of this WanDslLinkConfig
	iRet = ifx_config_get_val_fromOID(iaWCDOID,sValIP);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	iaWCDOID[(WAN_CON_DEV_DEPTH+1)]=OID_IGD_WAND_WANCD_WANPPPCONNECTIONNUMBEROFENTRIES;
	//Get the WanConnections available on top of this WanDslLinkConfig
	iRet = ifx_config_get_val_fromOID(iaWCDOID,sValPPP);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	i= atoi(sValIP);
	j = atoi(sValPPP);
	if(i> 0 || j > 0)  
	{
                goto errorHandler;
	}

	return IFX_CWMP_SUCCESS;

	errorHandler:
		return IFX_CWMP_FAILURE;

}

/*********************************************************************************
*  Function Name	:  IFX_WanIpConnection
      *  Description	:  This function handles all the sub-states inside
      	 		   a GET/SET operation.If it is a GET it allocates the 
			   array(Name,Value pairs) and retruns the values.
			   If it is a SET controller allocates the array and
			   passes the values to this function.It calls 
			   respective internal functions which in turn calls 
			   respective Platform APIs.
                                                                                                 
*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
							     Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has 
					  	             Name,Value,etc
                    IN          int32	       iElements;    No. of Elements
		    OUT	        void *	       ppParamRet;   same as ParamStruc
		    OUT         int32 *        piNumRetElem; No. of elements 		                                
*  Return Value        : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes               :
***********************************************************************************/
int32
IFX_WanIpConnection(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                IN int32 iElements, OUT void **ppaxParamArrRet, OUT int32 *piNumRetElem)
{
     
   //It calls the respective internal functions which handles resp. sub-operation
   
   //Set-Operation  
   //controller should pass the entire array during all the SET-sub_operations
   //It should handles only single get/set of instance at any point of time
   //It does not handle partial path
   //It won't handle multiple instances of the same object/module
   //at any point of time.

    
    int32 iRet = 0;
   ParamVal *paxParamArr = (ParamVal *)paxParameterArr;

	switch (pxOperInfo->iOper) 
	{
		//Get the object values
	   	case OP_GETVAL:
	            if((iRet = IFX_WanIpConGetValue(pxOperInfo, paxParamArr,
		    							iElements)) != IFX_CWMP_SUCCESS) {
			  IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
			  goto errorHandler;
	            }
	            break;
	        case OP_SETVAL:
		{

	    		//Set the obj values
			switch (pxOperInfo->iSubOper) 
			{
		               case OP_SETVAL_VALIDATE:
		                    if((iRet = IFX_WanIpConSetValidate(pxOperInfo,paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {     
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d OP_SET_VALIDATE failed!\n", __func__, __LINE__);
					goto errorHandler;
		                    }
		                    break;
		                case OP_SETVAL_ADD:
		                    if((iRet= IFX_WanIpConAddObj(pxOperInfo,paxParamArr,
				    					iElements))!=IFX_CWMP_SUCCESS)
		                    	{
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            	"%s:%d OP_SETVAL_ADD failed!\n", __func__, __LINE__);
		                    	 goto errorHandler;
		                    	}
		                    break;
		              case OP_SETVAL_CHK_MODIFY_DEP:
				case OP_SETVAL_MODIFY:
				 case OP_SETVAL_ACTIVATE:
		                    if((iRet = IFX_WanIpConSetValue(pxOperInfo,paxParamArr,
				    					iElements))!= IFX_CWMP_SUCCESS)
		    			{
					if ((iRet == IFX_CWMP_NEED_REBOOT_DONT_SAVE) || (iRet < IFX_CWMP_SUCCESS)){
					  	switch(pxOperInfo->iSubOper)
					  	{
						  	 case OP_SETVAL_CHK_MODIFY_DEP:
							IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_CHK_MODIFY_DEP failed!\n", __func__, __LINE__);
				                        goto errorHandler;

							case OP_SETVAL_MODIFY:
							IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_MODIFY failed!\n", __func__, __LINE__);
				                        goto errorHandler;

							case OP_SETVAL_ACTIVATE:
							IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_ACTIVATE failed!\n", __func__, __LINE__);
				                        goto errorHandler;
					  	}
				  	    } else if ((iRet == IFX_CWMP_NEED_ACTIVATE) ||
							(iRet == IFX_CWMP_NEED_REBOOT)) {
							goto errorHandler;
					    }
				    	 }

		                    break;
		                case OP_SETVAL_COMMIT:
		                    if((iRet = IFX_WanIpConSetCommit(pxOperInfo,paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
				    	   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_COMMIT failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;
		                case OP_SETVAL_UNDO:
		                    if((iRet =IFX_WanIpConSetUndo(pxOperInfo, paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
				    	   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_UNDO failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;
				case OP_SETVAL_CHK_DEL_DEP:
		                    if((iRet= IFX_WanIpConCheckDeleteDependency(pxOperInfo, paxParamArr,
				    					iElements, ppaxParamArrRet,
				    					piNumRetElem))!= IFX_CWMP_SUCCESS)
				    {
				    	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
		                        goto errorHandler;
				    }
                                    break;

			      case OP_SETVAL_CHK_DEL_ALLOWED:
		              case OP_SETVAL_DELETE:
		                    if((iRet= IFX_WanIpConSetDelete(pxOperInfo, paxParamArr,
				    					iElements, ppaxParamArrRet,
				    					piNumRetElem))!= IFX_CWMP_SUCCESS)
				    {
						if(iRet == IFX_CWMP_NEED_ACTIVATE)
							goto errorHandler;

				    		switch(pxOperInfo->iSubOper)
						{
							case OP_SETVAL_CHK_DEL_ALLOWED:
								IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                    		        	"%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
				                	        goto errorHandler;
							case OP_SETVAL_DELETE:
								IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
				                            	"%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
					                        goto errorHandler;
						}
				    }
		                    break;
		                case OP_SETVAL_FREE:
		                    IFX_WanIpConSetFree(pxOperInfo);
		                    break;

				 case OP_SETVAL_ATTRINFO:
				 	if((iRet =IFX_WanIpConSetAttr(pxOperInfo, paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
				    	  IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            	"%s:%d OP_SETVAL_ATTRINFO failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;
		                default:
		                    break;
			}

			case OP_UPDATE_CHILDINFO:
			//Updation of child related info is handled by the case
				switch(pxOperInfo->iSubOper)
				{
					case OP_UPDATE_CHILDINFO_ADD:
					case OP_UPDATE_CHILDINFO_DEL:
					 if((iRet =IFX_WanIpConUpdateChildInfo(pxOperInfo,
									paxParamArr,iElements)) != IFX_CWMP_SUCCESS)
					 	{
					 		switch(pxOperInfo->iSubOper)
							{

								case OP_UPDATE_CHILDINFO_ADD:
								 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_UPDATE_CHILDINFO_ADD failed!\n", __func__, __LINE__);
								goto errorHandler;

								case OP_UPDATE_CHILDINFO_DEL:
								 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_UPDATE_CHILDINFO_DEL failed!\n", __func__, __LINE__);
								goto errorHandler;

							}
					 	}
				}
			break;

	        }
                case OP_PARAM_VALIDATE:
                {
                    break;
                }
	        default:
	            break;
	}
	return IFX_CWMP_SUCCESS;

	errorHandler:

		return iRet;

}
//This helps to synch
 
