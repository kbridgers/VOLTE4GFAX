
/* 
** =============================================================================
**   FILE NAME        : IFX_LANUSBIfCfg
**   PROJECT          : TR69
**   MODULES          : LANEthernetInterfaceConfig
**   DATE             : 27-07-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION      :
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_Global.h"
#include "IFX_DEVM_AdaptCommon.h"
          // Required for STATIC
 
#include "IFX_DEVM_OID.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_DS.h"
#include <fcntl.h>
#include <unistd.h>

#ifdef MIPSTARGET
#define QUERY_INTERFACE         "usb0"
#else
#define QUERY_INTERFACE         "eth0"
#endif

int32
IFX_LANUSBIfCfg(IN OperInfo * pxOI, INOUT void *pParamList,
                     IN int32 iNumElem, OUT void **ppRet,
                     OUT int32 * piNumRetElem);

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFX_LUSBIC_OBJ  FORMNAME("LANDevice.1.LANUSBInterfaceConfig.")

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/
STATIC int32 GetParamOffset(IN int32 * paiOID);
STATIC int32
GetVal(IN int32 iCaller, INOUT ParamVal * pxParamVal, IN int32 iElements);
STATIC int32 Validate(INOUT ParamVal * pxParamVal, IN int32 iElements);
STATIC int32 GetModifyDep(INOUT ParamVal * pxParamVal, IN int32 iElements);
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal * pxParamVal, IN int32 iElements);
STATIC int32
GetNotify(IN OperInfo * pxOI, INOUT ParamVal * pxParamVal,
          IN int32 iElements);
STATIC int32
SetAttrInfo(IN OperInfo * pxOI, INOUT ParamVal * pxParamVal,
            IN int32 iElements);
/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/

/* 
** =============================================================================
**   Function Name    : GetParamOffset
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetParamOffset(IN int32 * paiOID)
{
    int32 iCnt;

    for(iCnt = 0; paiOID[iCnt] != 0; iCnt++);

    return (iCnt - 1);
}

/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetVal(IN int32 iCaller, INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iLen = 0;
    int32 iCnt = 0;
    int32 iTmpCnt = -1;         /* Mandatory */
    int32 iParamOffset;
    int32 iMemErrorFlag = 0;    /* Mandatory */
    char8 caBuff[100] = {0}, iFd = 0, *psTmp = NULL;

    //memset(caBuff, '\0', sizeof(caBuff));
    for(iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for(iCnt = 0; iCnt < iElements; iCnt++) {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset]) {
            case OID_IGD_LAND_LANUSBIC_ENABLE:

                (pxParamVal[iCnt]).Value =
                    (void *)IFX_CWMP_MALLOC(strlen("1") + 1);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, "1");
                break;
            case OID_IGD_LAND_LANUSBIC_STATUS:

                (pxParamVal[iCnt]).Value =
                    (void *)IFX_CWMP_MALLOC(strlen("Up") + 1);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, "Up");
                break;
            case OID_IGD_LAND_LANUSBIC_MACADDRESS:
                (pxParamVal[iCnt]).Value =
                    (void *)IFX_CWMP_MALLOC(strlen("AA:BB:CC:DD:EE:FF") + 1);
                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                /* TBD: Remove br0 hardcoding */
                iRet = system("ifconfig " QUERY_INTERFACE " | grep HWaddr > /tmp/ethaddr");
                if(iRet != IFX_CWMP_SUCCESS) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%s:%d"
                                "system() Ret[%d]\n",__FILE__, __func__, __LINE__, iRet);
                    ((char8 *)pxParamVal[iCnt].Value)[0] = '\0';
                    iRet = IFX_CWMP_SUCCESS;
                    /*iRet = ERR_CWMP_INTERNAL;
                    goto cleanup;*/
                }
                else
                {
                    iFd = open("/tmp/ethaddr", O_RDONLY);
                    if(iFd == -1)
                    {
                        ((char8 *)pxParamVal[iCnt].Value)[0] = '\0';
                        iRet = IFX_CWMP_SUCCESS;
                        break;
                    }

                    iLen = read(iFd, caBuff, sizeof(caBuff)-1);
		    caBuff[iLen] = '\0';
                    psTmp = strstr(caBuff,"HWaddr ");
                    if(psTmp == NULL)
                    {
                        ((char8 *)pxParamVal[iCnt].Value)[0] = '\0';
                        iRet = IFX_CWMP_SUCCESS;
                        break;
                    }
                    memcpy((pxParamVal[iCnt]).Value, psTmp + strlen("HWaddr "), 17);
                    close(iFd);
                    system("rm -f /tmp/ethaddr");
                }
                break;
            case OID_IGD_LAND_LANUSBIC_MACADDRESSCONTROLENABLED:

                (pxParamVal[iCnt]).Value =
                    (void *)IFX_CWMP_MALLOC(strlen("0") + 1);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, "0");
                break;
            case OID_IGD_LAND_LANUSBIC_STANDARD:

                (pxParamVal[iCnt]).Value =
                    (void *)IFX_CWMP_MALLOC(strlen("2.0") + 1);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, "2.0");
                break;
            case OID_IGD_LAND_LANUSBIC_TYPE:

                (pxParamVal[iCnt]).Value =
                    (void *)IFX_CWMP_MALLOC(strlen("Device") + 1);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, "Device");
                break;


            case OID_IGD_LAND_LANUSBIC_RATE:

                (pxParamVal[iCnt]).Value =
                    (void *)IFX_CWMP_MALLOC(strlen("High") + 1);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, "High");
                break;

            case OID_IGD_LAND_LANUSBIC_POWER:

                (pxParamVal[iCnt]).Value =
                    (void *)IFX_CWMP_MALLOC(strlen("Self") + 1);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, "Self");
                break;


            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                iTmpCnt = iCnt;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
                goto cleanup;
        }
    }

  cleanup:

    if(iMemErrorFlag) {
        (pxParamVal[iCnt]).iFaultCode = ERR_OUT_OF_MEMORY;
        iRet = ERR_OUT_OF_MEMORY;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Allocation Failure\n",
                    __FILE__, __func__, __LINE__, iRet);
    }

    if(iRet != IFX_CWMP_SUCCESS) {
        /* Free the allocation for value, if any. Also set the fault code. */
        for(iCnt = 0; iCnt < iElements; iCnt++) {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
            if(iTmpCnt != iCnt) {
                (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
            }
        }
    }
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : Modify
**
**   Description      : This function modifies the values of parameters in 
**                      DeviceInfo object. It calls respective Management API  
**                      for the same. It performs modification only if parameter 
**                      has Write permission. In certain cases it also performs 
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iCnt = 0;
    int32 iParamOffset;

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    for(iCnt = 0; iCnt < iElements; iCnt++) {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset]) {
            case OID_IGD_LAND_LANUSBIC_ENABLE:
                if((strcmp((pxParamVal[iCnt]).Value, "1") == 0) ||
                   (strcasecmp((pxParamVal[iCnt]).Value, "true") == 0)) {
                    iRet = IFX_CWMP_SUCCESS;
                    pxParamVal[iCnt].iFaultCode = IFX_CWMP_SUCCESS;
                }
                else {
                    iRet = ERR_CWMP_INVAL_ARGS;
                    pxParamVal[iCnt].iFaultCode = ERR_NON_WRITABLE;
                }
                break;

            case OID_IGD_LAND_LANUSBIC_MACADDRESSCONTROLENABLED:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxParamVal[iCnt].iFaultCode = ERR_NON_WRITABLE;
                break;

            default:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxParamVal[iCnt].iFaultCode = ERR_NON_WRITABLE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown requested parameter\n",
                            __FILE__, _FUNCL_,
                            (pxParamVal[iCnt]).iaOID[iParamOffset]);
                break;
        }
    }

cleanup:
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : Validate
**
**   Description      : This function validates the values of parameters in
**                      DeviceInfo object.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      validated.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When validation of all parameters is
**                      successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in validating at least one parameter.
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
Validate(INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32 iI;
    int32 iRet = IFX_CWMP_SUCCESS;
    for(iI = 0; iI < iElements; iI++) {
        pxParamVal[iI].iFaultCode = IFX_CWMP_SUCCESS;
    }
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : GetModifyDep
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
GetModifyDep(INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    return (IFX_CWMP_SUCCESS);
}


STATIC int32
GetNotify(IN OperInfo * pxOI, INOUT ParamVal * pxParamVal,
          IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iCnt = 0;

    for(iCnt = 0; iCnt < iElements; iCnt++) {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
        (pxParamVal[iCnt]).Value = NULL;
    }

    return (iRet);
}

STATIC int32
SetAttrInfo(IN OperInfo * pxOI, INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iCnt;

    /* Set the fault code to Success */
    for(iCnt = 0; iCnt < iElements; iCnt++) {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
    }

    /* Get the offset of the parameter */
    GetParamOffset(pxParamVal->iaOID);

    for(iCnt = 0; iCnt < iElements; iCnt++) {
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Update Attribute Information */
    iRet = IFX_SetAttributesInfo(NULL, pxParamVal, iElements);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Updating Param Attribute Info failed\n",
                    __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

  cleanup:
    return (iRet);
}

/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/


int32
IFX_LANUSBIfCfg_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    iRet = ifx_ds_register_function(IFX_LUSBIC_OBJ, IFX_LANUSBIfCfg);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_LUSBIC_OBJ);
        goto cleanup;
    }

  cleanup:
    return iRet;
}

int32
IFX_LANUSBIfCfg(IN OperInfo * pxOI, INOUT void *pParamList,
                     IN int32 iNumElem, OUT void **ppRet,
                     OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *pxParamVal = (ParamVal *) pParamList;

    /* Process based on type of Operation */
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            /* Process based on type of SubOperation */
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:

                    /* Get values of all the requested parameters */
                    iRet = GetVal(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS) {
                        goto cleanup;
                    }

                    break;
                case OP_GETVAL_NOTIFICATION:

                    /* Set attribute values for all the requested parameters */
                    iRet = GetNotify(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS) {
                        goto cleanup;
                    }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_SETVAL:
        {
            /* Process based on type of SubOperation */
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:

                    /* Validate values of all the requested parameters */
                    iRet = Validate(pxParamVal, iNumElem);

                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS) {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:

                    /* Check modify dependency of all requested parameters */
                    iRet = GetModifyDep(pxParamVal, iNumElem);

                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS) {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_MODIFY:

                    /* Set values of all the requested parameters */
                    iRet = Modify(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS) {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ATTRINFO:

                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS) {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_FREE:
                case OP_SETVAL_ADD:
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
                case OP_SETVAL_DELETE:
                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            /* Process based on type of SubOperation */
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                case OP_UPDATE_CHILDINFO_DEL:
                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
        {
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid Operation\n",
                        __func__, __LINE__, iRet);
            goto cleanup;
        }
    }

  cleanup:
    return (iRet);
}
