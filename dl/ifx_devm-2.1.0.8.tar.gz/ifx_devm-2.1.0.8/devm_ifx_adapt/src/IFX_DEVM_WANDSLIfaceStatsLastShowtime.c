/* 
** =============================================================================
**   FILE NAME        : IFX_WanDslIfaceStatsLastShowtime.c
**   PROJECT          : TR69
**   MODULES          : WanDslIfaceStats
**   DATE             : 05-03-2012
**   AUTHOR           : DevM team
**   DESCRIPTION      : This module handles ADD/DEL/GET/SET RPCs of 
**                      WanDslIfaceStats. When controller calls this module it
**                      calls respective Platform/Object APIs to handle GET/SET 
**                      of WanDslIfaceStats specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author        $Comment
**   05-Mar-2012      DevM team      Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_WANDSLStats.h"

#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"

#include <fcntl.h>
#include <unistd.h>
#include "IFX_DEVM_StackUtil.h"

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;

#define IFX_DSL_LASTSHOWTIME_STATS_OBJ "InternetGatewayDevice.WANDevice.1.WANDSLInterfaceConfig.Stats.LastShowtime."
/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/




/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/



typedef struct dsl_stats {
    uint32 RxBlocks;
    uint32 TxBlocks;
    uint32 CellDelin;
    uint32 LinkRetrain;
    uint32 InitErrors;
    uint32 InitTimeouts;
    uint32 LossOfFraming;
    uint32 LOF;
    uint32 LInit;
    uint32 ErroredSecs;
    uint32 SeverelyErroredSecs;
    uint32 FECErrors;
    uint32 ATUCFECErrors;
    uint32 HECErrors;
    uint32 ATUCHECErrors;
    uint32 CRCErrors;
    uint32 ATUCCRCErrors;
    uint32 ATUCErroredSecs;
    uint32 ATUCSeverelyErroredSecs;
} DSL_STATS;



//Mapping of TR69 parameters to DSL parameters

#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
int32
ifx_get_dsl_iface_stats_lastshowtime(OUT DSL_STATS * dslStats)
{

    uint32 cmd = 0, flags = 0;
    int ret = IFX_CWMP_SUCCESS;
    aturChannelPerfDataEntry_t perfData;
    DSL_G997_DataPathFailures_t DataPath;
    DSL_PM_LineInitCounters_t LineData;
    DSL_PM_LineSecCounters_t LineSecData;
    DSL_PM_ChannelCounters_t ChannelData;
    DSL_PM_DataPathCounters_t DataPathCounters;
    DSL_G997_LineFailures_t LineFailures;
    DSL_G997_LineInitStatus_t LineInitStatus;
    // TxBlocks and RxBlocks
    /* These parameters are supported in ADSL-MIB Enabling the ADSL-MIB options 
       will increase the foot-print adsl-mib is disabled in DSL-API build
       options */
    memset(&perfData, 0x00, sizeof(aturChannelPerfDataEntry_t));
    cmd = DSL_FIO_PM_DATA_PATH_COUNTERS_SHOWTIME_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *)&perfData, flags);
    if(ret < 0) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s,%d]IOCTL FAIL for cmd %u!\n\n", __FUNCTION__, __LINE__,
                    cmd);
    }
    dslStats->TxBlocks = perfData.adslAturChanTransmittedBlks;
    dslStats->RxBlocks = perfData.adslAturChanReceivedBlks;

    // CellDelin
    memset(&DataPath, 0x00, sizeof(DSL_G997_DataPathFailures_t));
    cmd = DSL_FIO_G997_DATA_PATH_FAILURES_STATUS_GET;
    DataPath.nDirection = DSL_NEAR_END;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *)&DataPath, flags);
    if(ret < 0) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s,%d]IOCTL FAIL for cmd %d!\n", __FUNCTION__, __LINE__,
                    cmd);
    }
    dslStats->CellDelin = DataPath.data.nDataPathFailures;

    // LinkRetrain & InitErrors
    memset(&LineData, 0x00, sizeof(DSL_PM_LineInitCounters_t));
    cmd = DSL_FIO_PM_LINE_INIT_COUNTERS_SHOWTIME_GET;
    LineData.nHistoryInterval=1;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *)&LineData, flags);
    if(ret < 0) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s,%d]IOCTL FAIL for cmd %d!\n", __FUNCTION__, __LINE__,
                    cmd);
    }
    dslStats->LinkRetrain = LineData.data.nFullInits;
    dslStats->InitErrors =
        LineData.data.nFailedFullInits + LineData.data.nFailedShortInits;

    // InitTimeouts - Currently not supported by DSL-API
    dslStats->InitTimeouts = 0;

    // LossOfFraming,ES & SES
    memset(&LineSecData, 0x00, sizeof(DSL_PM_LineSecCounters_t));
    LineSecData.nDirection = DSL_NEAR_END;
    cmd = DSL_FIO_PM_LINE_SEC_COUNTERS_SHOWTIME_GET;
    LineSecData.nHistoryInterval=1;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *)&LineSecData, flags);
    if(ret < 0) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s,%d]IOCTL FAIL for cmd %d!\n", __FUNCTION__, __LINE__,
                    cmd);
    }
    dslStats->LossOfFraming = LineSecData.data.nLOFS;
    dslStats->ErroredSecs = LineSecData.data.nES;
    dslStats->SeverelyErroredSecs = LineSecData.data.nSES;

//LOF
    memset(&LineFailures, 0x00, sizeof(DSL_G997_LineFailures_t));
    LineFailures.nDirection = DSL_NEAR_END;
    cmd =  DSL_FIO_G997_LINE_FAILURES_STATUS_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *)&LineFailures, flags);
    if(ret < 0) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s,%d]IOCTL FAIL for cmd %d!\n", __FUNCTION__, __LINE__,
                    cmd);
    }
    dslStats->LOF = LineFailures.data.nLineFailures;
//LInit
    memset(&LineInitStatus, 0x00, sizeof(DSL_G997_LineInitStatus_t));
    cmd =  DSL_FIO_G997_LINE_INIT_STATUS_GET;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *)&LineInitStatus, flags);
    if(ret < 0) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s,%d]IOCTL FAIL for cmd %d!\n", __FUNCTION__, __LINE__,
                    cmd);
    }
    dslStats->LInit = LineInitStatus.data.nLineInitStatus;



    // FECErrors,CRCErrors 
    memset(&ChannelData, 0x00, sizeof(DSL_PM_ChannelCounters_t));
    ChannelData.nDirection = DSL_NEAR_END;
    cmd = DSL_FIO_PM_CHANNEL_COUNTERS_SHOWTIME_GET;
    ChannelData.nHistoryInterval=1;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *)&ChannelData, flags);
    if(ret < 0) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s,%d]IOCTL FAIL for cmd %d!\n", __FUNCTION__, __LINE__,
                    cmd);
    }
    dslStats->FECErrors = ChannelData.data.nFEC;
    dslStats->CRCErrors = ChannelData.data.nCodeViolations;


    // ATUCFECErrors,ATUCCRCErrors
    memset(&ChannelData, 0x00, sizeof(DSL_PM_ChannelCounters_t));
    ChannelData.nDirection = DSL_FAR_END;
    ChannelData.nHistoryInterval=1;    
    ret = ifx_cpe_api_device_get_operation(cmd, (void *)&ChannelData, flags);
    if(ret < 0) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s,%d]IOCTL FAIL for cmd %d!\n", __FUNCTION__, __LINE__,
                    cmd);
    }
    dslStats->ATUCFECErrors = ChannelData.data.nFEC;
    dslStats->ATUCCRCErrors = ChannelData.data.nCodeViolations;


    // HECErrors 
    memset(&DataPathCounters, 0x00, sizeof(DSL_PM_DataPathCounters_t));
    DataPathCounters.nDirection = DSL_NEAR_END;
    cmd = DSL_FIO_PM_DATA_PATH_COUNTERS_SHOWTIME_GET;
    DataPathCounters.nHistoryInterval=1;
    ret =
        ifx_cpe_api_device_get_operation(cmd, (void *)&DataPathCounters, flags);
    if(ret < 0) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s,%d]IOCTL FAIL for cmd %d!\n", __FUNCTION__, __LINE__,
                    cmd);
    }
    dslStats->HECErrors = DataPathCounters.data.nHEC;

    // ATUCHECErrors
    memset(&DataPathCounters, 0x00, sizeof(DSL_PM_DataPathCounters_t));
    DataPathCounters.nDirection = DSL_FAR_END;
    DataPathCounters.nHistoryInterval=1;
    ret =
        ifx_cpe_api_device_get_operation(cmd, (void *)&DataPathCounters, flags);
    if(ret < 0) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s,%d]IOCTL FAIL for cmd %d!\n", __FUNCTION__, __LINE__,
                    cmd);
    }
    dslStats->ATUCHECErrors = DataPathCounters.data.nHEC;

    //ATUCErroredSecs & ATUCSeverelyErroredSecs
    memset(&LineSecData, 0x00, sizeof(DSL_PM_LineSecCounters_t));
    LineSecData.nDirection = DSL_FAR_END;
    cmd = DSL_FIO_PM_LINE_SEC_COUNTERS_SHOWTIME_GET;
    LineSecData.nHistoryInterval=1;
    ret = ifx_cpe_api_device_get_operation(cmd, (void *)&LineSecData, flags);
    if(ret < 0) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s,%d]IOCTL FAIL for cmd %d!\n", __FUNCTION__, __LINE__,
                    cmd);
    }
    dslStats->ATUCErroredSecs = LineSecData.data.nES;
    dslStats->ATUCSeverelyErroredSecs = LineSecData.data.nSES;


    return IFX_CWMP_SUCCESS;

}
#endif

/* 
** =============================================================================
**   Function Name    : IFX_WanDslIfaceStatsLastShowtimeGetValue
**   Description        : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes                : 
**
** ============================================================================
*/
static int32
IFX_WanDslIfaceStatsLastShowtimeGetValue(IN OperInfo * pxOperInfo,
                             INOUT ParamVal * pxGetParamVal,
                             IN uint32 iElements)
{
    /* GET PARAMETER VALUES **Get Object OID(skip parameter ID) from the first
       **element in the array.Get Cpeid for this Object OID

       **Get the object from the system using a Platform API **with cpeid

       **Do reverse mapping to convert system values into TR69 **Values.After
       conversion stores the values in temp storage

       **While assigning the values as per request store the **values in heap
       astShowtimend assign the ptr to the struct **Return all the values */

    uint32 i = 0;
    int32 iParamId = 0;
    uint32 uiParamPos = 0;
    int32 iRet = 0;
    uint32 uiMode = IFX_CHK_VALUE_BASED;
    // DSL_LINE_PHY_PROPERTIES xDslphys;
    DSL_STATS xDslStats;

    memset(&xDslStats, 0x00, sizeof(xDslStats));
    // Get the WanIpConParamPos
    uiParamPos = IFX_GetParamIdPos(pxGetParamVal->iaOID);


#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
    iRet = ifx_get_dsl_iface_stats_lastshowtime(&xDslStats);
    if(iRet != IFX_SUCCESS)
        goto errorHandler;

#endif
    for(i = 0; i < iElements; i++) {

        iParamId = pxGetParamVal->iaOID[uiParamPos];

        // Malloc and assign the pointer to the Value attr of struct
        pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
        if(pxGetParamVal->Value == NULL) {
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (iParamId) {

                // Convert the value - reverse mapping
                // Assign the correct value to the Value attr


            case OID_IGD_WAND_WANDSLIC_S_LS_RECEIVEBLOCKS:
                sprintf(pxGetParamVal->Value, "%u", xDslStats.RxBlocks);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                break;
            case OID_IGD_WAND_WANDSLIC_S_LS_TRANSMITBLOCKS:
                sprintf(pxGetParamVal->Value, "%u", xDslStats.TxBlocks);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                break;
            case OID_IGD_WAND_WANDSLIC_S_LS_CELLDELIN:
                sprintf(pxGetParamVal->Value, "%u", xDslStats.CellDelin);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                break;
            case OID_IGD_WAND_WANDSLIC_S_LS_LINKRETRAIN:
                sprintf(pxGetParamVal->Value, "%u", xDslStats.LinkRetrain);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                break;
            case OID_IGD_WAND_WANDSLIC_S_LS_INITERRORS:
                sprintf(pxGetParamVal->Value, "%u", xDslStats.InitErrors);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                break;
            case OID_IGD_WAND_WANDSLIC_S_LS_INITTIMEOUTS:
                sprintf(pxGetParamVal->Value, "%u", xDslStats.InitTimeouts);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                break;
            case OID_IGD_WAND_WANDSLIC_S_LS_LOSSOFFRAMING:
                sprintf(pxGetParamVal->Value,"%u", xDslStats.LossOfFraming);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                break;
            case OID_IGD_WAND_WANDSLIC_S_LS_LOF:
                sprintf(pxGetParamVal->Value, "%u", xDslStats.LOF);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                break;
            case OID_IGD_WAND_WANDSLIC_S_LS_LINIT:
                sprintf(pxGetParamVal->Value, "%u", xDslStats.LInit);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                break;
            case OID_IGD_WAND_WANDSLIC_S_LS_ERROREDSECS:
                sprintf(pxGetParamVal->Value, "%u", xDslStats.ErroredSecs);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                break;
            case OID_IGD_WAND_WANDSLIC_S_LS_SEVERELYERROREDSECS:
                sprintf(pxGetParamVal->Value, "%u", xDslStats.SeverelyErroredSecs);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                break;
            case OID_IGD_WAND_WANDSLIC_S_LS_FECERRORS:
                sprintf(pxGetParamVal->Value, "%u", xDslStats.FECErrors);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                break;
            case OID_IGD_WAND_WANDSLIC_S_LS_ATUCFECERRORS:
                sprintf(pxGetParamVal->Value, "%u", xDslStats.ATUCFECErrors);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                break;
            case OID_IGD_WAND_WANDSLIC_S_LS_HECERRORS:
                sprintf(pxGetParamVal->Value, "%u", xDslStats.HECErrors);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                break;
            case OID_IGD_WAND_WANDSLIC_S_LS_ATUCHECERRORS:
                sprintf(pxGetParamVal->Value, "%u", xDslStats.ATUCHECErrors);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                break;
            case OID_IGD_WAND_WANDSLIC_S_LS_CRCERRORS:
                sprintf(pxGetParamVal->Value, "%u", xDslStats.CRCErrors);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                break;
            case OID_IGD_WAND_WANDSLIC_S_LS_ATUCCRCERRORS:
                sprintf(pxGetParamVal->Value, "%u", xDslStats.ATUCCRCErrors);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                break;
            case OID_IGD_WAND_WANDSLIC_S_LS_ATUCERROREDSECS:
                sprintf(pxGetParamVal->Value, "%u", xDslStats.ATUCErroredSecs);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                break;
            case OID_IGD_WAND_WANDSLIC_S_LS_ATUCSEVERELYERROREDSECS:
                sprintf(pxGetParamVal->Value, "%u", xDslStats.ATUCSeverelyErroredSecs);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "Invalid param id %d!\n", iParamId);
                pxGetParamVal->iFaultCode = ERR_INVAL_PARAMETER_NAME;
                break;
        }


        ++pxGetParamVal;
    }

    return IFX_CWMP_SUCCESS;
  errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed ParamId=%d!\n", __func__, __LINE__, iParamId);
    return iRet;

}





/* 
** =============================================================================
**   Function Name    : IFX_WanDslIfaceStatsLastShowtimeSetValue
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

static int32
IFX_WanDslIfaceStatsLastShowtimeSetValue(IN OperInfo * pxOpInfo,
                             INOUT ParamVal * paxParamVal, IN int32 iElements)
{
    return IFX_CWMP_FAILURE;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslIfaceStatsLastShowtimeAddObj
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanDslIfaceStatsLastShowtimeAddObj(IN OperInfo * pxOpInfo, INOUT ParamVal * pxParamVal,
                           IN int32 iElements)
{
    return IFX_CWMP_FAILURE;
}


/* 
** =============================================================================
**   Function Name    : IFX_WanDslIfaceStatsLastShowtimeSetCommit
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanDslIfaceStatsLastShowtimeSetCommit()
{
    return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslIfaceStatsLastShowtimeSetUndo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanDslIfaceStatsLastShowtimeSetUndo()
{
    return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslIfaceStatsLastShowtimeSetDelete
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanDslIfaceStatsLastShowtimeSetDelete(IN OperInfo * pxOpInfo,
                              INOUT ParamVal * paxParamVal, IN int32 iElements,
                              OUT void **ppxParamStructRet,
                              OUT int32 * piNumRetElem)
{
    return IFX_CWMP_FAILURE;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslIfaceStatsLastShowtimeSetFree
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanDslIfaceStatsLastShowtimeSetFree()
{
    return IFX_CWMP_SUCCESS;
}


/* 
** =============================================================================
**   Function Name    : IFX_WanDslIfaceStatsLastShowtimeSetAttr
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

static int32
IFX_WanDslIfaceStatsLastShowtimeSetAttr(IN OperInfo * pxOpInfo, INOUT ParamVal * pxParamVal,
                            IN int32 iElements)
{
    uint32 iRet = IFX_CWMP_SUCCESS, i = 0;
    OperInfo xOpInfo;

    xOpInfo.iCaller = pxOpInfo->iCaller;
    xOpInfo.iOper = OP_GETVAL;
    xOpInfo.iSubOper = OP_GETVAL_NORMAL;

    iRet = IFX_WanDslIfaceStatsLastShowtimeGetValue(&xOpInfo, pxParamVal, iElements);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorFreeHandler;

    iRet = IFX_SetAttributesInfo(pxOpInfo, pxParamVal, iElements);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorFreeHandler;

  errorFreeHandler:
    for(i = 0; i < iElements; i++)
        IFX_CWMP_FREE(pxParamVal[i].Value);

    if(iRet)
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d failed!\n", __func__, __LINE__);
    return iRet;
}




/*********************************************************************************
*  Function Name	:  IFX_WanDslIfaceStatsLastShowtime   
      *  Description	:  This function handles all the sub-states inside
      	 		   a GET/SET operation.If it is a GET it allocates the 
			   array(Name,Value pairs) and retruns the values.
			   If it is a SET controller allocates the array and
			   passes the values to this function.It calls 
			   respective internal functions which in turn calls 
			   respective Platform APIs.
                                                                                                 
*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
							     Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has 
					  	             Name,Value,etc
                    IN          int32	       iElements;    No. of Elements
		    OUT	        void *	       ppParamRet;   same as ParamStruc
		    OUT         int32 *        piNumRetElem; No. of elements 		                                
*  Return Value        : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes               :
***********************************************************************************/
int32
IFX_WanDslIfaceStatsLastShowtime(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                     IN int32 iElements, OUT void **ppaxParamArrRet,
                     OUT int32 * piNumRetElem)
{

    // It calls the respective internal functions which handles resp.
    // sub-operation

    // Set-Operation 
    // controller should pass the entire array during all the
    // SET-sub_operations
    // It should handles only single get/set of instance at any point of time
    // It does not handle partial path
    // It won't handle multiple instances of the same object/module
    // at any point of time.


    int32 iRet = 0;
    ParamVal *paxParamArr = (ParamVal *) paxParameterArr;
    int32 iCnt = 0;

    switch (pxOperInfo->iOper) {
            // Get the object values
        case OP_GETVAL:
            if((iRet = IFX_WanDslIfaceStatsLastShowtimeGetValue(pxOperInfo, paxParamArr,
                                                    iElements)) !=
               IFX_CWMP_SUCCESS) {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
                goto errorHandler;
            }
            break;
        case OP_SETVAL:
            {

                // Set the obj values
                switch (pxOperInfo->iSubOper) {
                    case OP_SETVAL_VALIDATE:
                        {
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                        "%s:%d OP_SETVAL_VALIDATE failed!\n",
                                        __func__, __LINE__);
                            goto errorHandler;
                        }
                        break;
                    case OP_SETVAL_ADD:
                        if((iRet =
                            IFX_WanDslIfaceStatsLastShowtimeAddObj(pxOperInfo, paxParamArr,
                                                       iElements)) !=
                           IFX_CWMP_SUCCESS) {
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                        "%s:%d OP_SETVAL_ADD failed!\n",
                                        __func__, __LINE__);
                            goto errorHandler;
                        }
                        break;
                    case OP_SETVAL_CHK_MODIFY_DEP:
                        break;

                    case OP_SETVAL_MODIFY:
                        if((iRet =
                            IFX_WanDslIfaceStatsLastShowtimeSetValue(pxOperInfo,
                                                         paxParamArr,
                                                         iElements)) !=
                           IFX_CWMP_SUCCESS) {
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                        "%s:%d OP_SETVAL_VALUE failed!\n",
                                        __func__, __LINE__);
                            goto errorHandler;
                        }
                        break;

                    case OP_SETVAL_COMMIT:
                        if((iRet =
                            IFX_WanDslIfaceStatsLastShowtimeSetCommit(pxOperInfo,
                                                          paxParamArr,
                                                          iElements)) !=
                           IFX_CWMP_SUCCESS) {
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                        "%s:%d OP_SETVAL_COMMIT failed!\n",
                                        __func__, __LINE__);
                            goto errorHandler;
                        }
                        break;
                    case OP_SETVAL_UNDO:
                        if((iRet =
                            IFX_WanDslIfaceStatsLastShowtimeSetUndo(pxOperInfo, paxParamArr,
                                                        iElements)) !=
                           IFX_CWMP_SUCCESS) {
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                        "%s:%d OP_SETVAL_UNDO failed!\n",
                                        __func__, __LINE__);
                            goto errorHandler;
                        }
                        break;
                    case OP_SETVAL_CHK_DEL_DEP:
                    case OP_SETVAL_CHK_DEL_ALLOWED:
                    case OP_SETVAL_DELETE:
                        if((iRet =
                            IFX_WanDslIfaceStatsLastShowtimeSetDelete(pxOperInfo,
                                                          paxParamArr,
                                                          iElements,
                                                          ppaxParamArrRet,
                                                          piNumRetElem)) !=
                           IFX_CWMP_SUCCESS) {

                            switch (pxOperInfo->iSubOper) {
                                case OP_SETVAL_CHK_DEL_DEP:
                                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                                "%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n",
                                                __func__, __LINE__);
                                    goto errorHandler;
                                case OP_SETVAL_CHK_DEL_ALLOWED:
                                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                                "%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n",
                                                __func__, __LINE__);
                                    goto errorHandler;
                                case OP_SETVAL_DELETE:
                                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                                "%s:%d OP_SETVAL_DELETE failed!\n",
                                                __func__, __LINE__);
                                    goto errorHandler;
                            }
                        }
                        break;
                    case OP_SETVAL_FREE:
                        IFX_WanDslIfaceStatsLastShowtimeSetFree(pxOperInfo);
                        break;

                    case OP_SETVAL_ATTRINFO:
                        if((iRet =
                            IFX_WanDslIfaceStatsLastShowtimeSetAttr(pxOperInfo, paxParamArr,
                                                        iElements)) !=
                           IFX_CWMP_SUCCESS) {
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                        "%s:%d OP_SETVAL_ATTRINFO failed!\n",
                                        __func__, __LINE__);
                            goto errorHandler;
                        }
                        break;

                    default:
                        break;
                }
                break;
            }
        case OP_PARAM_VALIDATE:
            {
                // IGD.WD.2. or IGD.WD.3.
                if(((paxParamArr->iaOID[2]) == WAN_DEVICE_MII0)
                   || ((paxParamArr->iaOID[2]) == WAN_DEVICE_MII1)) {
                    /* Set the fault code to Error */
                    for(iCnt = 0; iCnt < iElements; iCnt++) {
                        paxParamArr[iCnt].iFaultCode =
                            ERR_CWMP_PARAMVAL_INVALID;
                    }
                }
                break;
            }
        default:
            /* printf(stderr, "%s:%d Error! In Default case\n", __func__,\ //
               __LINE__); //exit(EXIT_FAILURE); */
            break;
    }
    return IFX_CWMP_SUCCESS;

  errorHandler:
    return IFX_CWMP_FAILURE;

}

 /* 
  ** =============================================================================
  **   Function Name    : IFX_WanDslIfaceStatsLastShowtime_Init
  **   Description      : 
  **
  **   Parameters       : 
  **
  **   Return Value     : 
  **   Notes            : 
  **
  ** ============================================================================
  */
int32
IFX_WanDslIfaceStatsLastShowtime_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;


    /* Register the WanDslIfaceStats module function pointer in the object
       model */
    iRet =
        ifx_ds_register_function(IFX_DSL_LASTSHOWTIME_STATS_OBJ, IFX_WanDslIfaceStatsLastShowtime);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "Unable to Register %s with Object Model\n",
                    IFX_DSL_LASTSHOWTIME_STATS_OBJ);
        goto errorHandler;
    }

  errorHandler:
    return iRet;
}
