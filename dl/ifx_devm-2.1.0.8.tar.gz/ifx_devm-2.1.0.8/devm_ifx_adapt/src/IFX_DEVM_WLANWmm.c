/*
** =============================================================================
**   FILE NAME        : IFX_WlanWmm.c
**   PROJECT          : TR69
**   MODULES          : WlanWmm
**   DATE             : 29-08-2007
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This module handles ADD/DEL/GET/SET RPCs of
**                      WlanWmm. When controller calls this module it
**                      calls respective Platform/Object APIs to handle GET/SET
**                      of WlanWmm specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          :
**   $Date            $Author        $Comment
**   28-04-06         TR69 team      Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
//#include <sys/socket.h>
//#include <netinet/in.h>
//#include <arpa/inet.h>
#include <unistd.h>
#include "IFX_DEVM_WLANWmm.h"
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
 

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;

#ifdef IFX_TR69_DEVICE
	#define	OID_IGD_LAND_WLANC_APWMMP_AIFSN		OID_IGD_LAN_WLANC_APWMMP_AIFSN
	#define	OID_IGD_LAND_WLANC_APWMMP_ECWMIN	OID_IGD_LAN_WLANC_APWMMP_ECWMIN
	#define	OID_IGD_LAND_WLANC_APWMMP_ECWMAX	OID_IGD_LAN_WLANC_APWMMP_ECWMAX
	#define	OID_IGD_LAND_WLANC_APWMMP_TXOP		OID_IGD_LAN_WLANC_APWMMP_TXOP
	#define	OID_IGD_LAND_WLANC_APWMMP_ACKPOLICY	OID_IGD_LAN_WLANC_APWMMP_ACKPOLICY
	#define	OID_IGD_LAND_WLANC_APWMMP_AIFSN		OID_IGD_LAN_WLANC_APWMMP_AIFSN
	#define	OID_IGD_LAND_WLANC_APWMMP_ECWMIN	OID_IGD_LAN_WLANC_APWMMP_ECWMIN
	#define	OID_IGD_LAND_WLANC_APWMMP_ECWMAX	OID_IGD_LAN_WLANC_APWMMP_ECWMAX
	#define	OID_IGD_LAND_WLANC_APWMMP_TXOP		OID_IGD_LAN_WLANC_APWMMP_TXOP
	#define	OID_IGD_LAND_WLANC_APWMMP_ACKPOLICY		OID_IGD_LAN_WLANC_APWMMP_ACKPOLICY
	#define OID_IGD_LAND_WLANC_STAWMMP_AIFSN	OID_IGD_LAN_WLANC_STAWMMP_AIFSN
	#define OID_IGD_LAND_WLANC_STAWMMP_ECWMIN	OID_IGD_LAN_WLANC_STAWMMP_ECWMIN
	#define OID_IGD_LAND_WLANC_STAWMMP_ECWMAX	OID_IGD_LAN_WLANC_STAWMMP_ECWMAX
	#define	OID_IGD_LAND_WLANC_STAWMMP_TXOP		OID_IGD_LAN_WLANC_STAWMMP_TXOP
	#define	OID_IGD_LAND_WLANC_STAWMMP_ACKPOLICY	OID_IGD_LAN_WLANC_STAWMMP_ACKPOLICY
	#define	OID_IGD_LAND_WLANC_STAWMMP_AIFSN	OID_IGD_LAN_WLANC_STAWMMP_AIFSN
#endif

#define IFX_WLAN_APWMM_OBJ FORMLANNAME("WLANConfiguration.1.APWMMParameter.1.")
#define IFX_WLAN_STAWMM_OBJ FORMLANNAME("WLANConfiguration.1.STAWMMParameter.1.")

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/


extern Map_Value gaxEnable[];



/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS>
**
** =============================================================================
*/


/*
** =============================================================================
**   Function Name    : IFX_WlanApWmmGetValue
**   Description        :
**
**   Parameters       :
**
**   Return Value     :
**   Notes                :
**
** ============================================================================
*/
static int32
IFX_WlanApWmmGetValue(IN OperInfo * pxOperInfo, INOUT ParamVal * paxParamVal,
                     IN uint32 iElements)
{

    uint32 i = 0;
    uint32 uiCpeid = 0;
    uint32 uiPcpeid = 0;
    int32 iRet = IFX_CWMP_SUCCESS;
    uint32 iFlags = 0, uiParamPos = 0;

    IFX_MAPI_WLAN_AP_WMM_Cfg wlApWmm;
    
    memset(&wlApWmm,0x00, sizeof(IFX_MAPI_WLAN_AP_WMM_Cfg));
    
    // Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(paxParamVal->iaOID, &uiCpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Get the pCpeid from Tr69 id
    iRet = IFX_GetParentObjCpeId(paxParamVal->iaOID, &uiPcpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Fills the Cpeid,ParentCepid,TR69Id,Owner
    iFlags = IFX_F_GET_ANY;

    // Get the WlanWmmParamPos
    uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);

    wlApWmm.iid.cpeId.Id = uiCpeid;
    wlApWmm.iid.pcpeId.Id = uiPcpeid;        

    iRet = ifx_mapi_get_wlan_wmm_ap_config(&wlApWmm, iFlags);
    if (iRet != IFX_CWMP_SUCCESS) {	
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get all values"
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
        goto errorHandler;
	}

    for (i = 0; i < iElements; i++)
    {
        // Malloc and assign the pointer to the Value attr of struct
        paxParamVal[i].Value = IFIN_CWMP_MALLOC(128);
        if (paxParamVal->Value == NULL)
        {
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (paxParamVal[i].iaOID[uiParamPos])
        {
            case OID_IGD_LAND_WLANC_APWMMP_AIFSN:
                sprintf(paxParamVal[i].Value,"%d",wlApWmm.AIFSN);
                break;
            case OID_IGD_LAND_WLANC_APWMMP_ECWMIN:
                sprintf(paxParamVal[i].Value,"%d",wlApWmm.ECWmin);
                break;
            case OID_IGD_LAND_WLANC_APWMMP_ECWMAX:
                sprintf(paxParamVal[i].Value,"%d",wlApWmm.ECWmax);
                break;    
            case OID_IGD_LAND_WLANC_APWMMP_TXOP:
                sprintf(paxParamVal[i].Value,"%d",wlApWmm.TXOP);
                break;                
            case OID_IGD_LAND_WLANC_APWMMP_ACKPOLICY:
                sprintf(paxParamVal[i].Value,"%d",wlApWmm.ackPolicyEna);
                break;                
            default:
                break;
        }   
    }

    return IFX_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed ParamId=%d !\n", __func__, __LINE__,
                paxParamVal->iaOID[uiParamPos]);
    return IFIN_CWMP_FAILURE;
}


/*
** =============================================================================
**   Function Name    : IFX_WlanApWmmSetValue
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/
static int32
IFX_WlanApWmmSetValue(IN OperInfo * pxOpInfo, INOUT ParamVal * paxParamVal,
                     IN int32 iElements)
{

    uint32 i = 0;
    uint32 uiCpeid = 0;
    uint32 uiPcpeid = 0;
    int32 iRet = IFX_CWMP_SUCCESS;
    uint32 iOper = 0, iFlags = 0, uiParamPos = 0;
    
    IFX_MAPI_WLAN_AP_WMM_Cfg wlApWmm;
    
    memset(&wlApWmm, 0x00, sizeof(IFX_MAPI_WLAN_AP_WMM_Cfg));
    
    // Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(paxParamVal->iaOID, &uiCpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Get the pCpeid from Tr69 id
    iRet = IFX_GetParentObjCpeId(paxParamVal->iaOID, &uiPcpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Fills the Cpeid,ParentCepid,TR69Id,Owner
    iOper = IFX_OP_MOD;
    iFlags = IFX_F_GET_ANY;

    // Get the WlanWpsParamPos
    uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);
   
    wlApWmm.iid.cpeId.Id = uiCpeid;
    wlApWmm.iid.pcpeId.Id = uiPcpeid;
    
    switch (pxOpInfo->iSubOper)
    {

        case OP_SETVAL_CHK_MODIFY_DEP:
            break;

        case OP_SETVAL_VALIDATE:
            break;

        case OP_SETVAL_MODIFY:
            
            iRet = ifx_mapi_get_wlan_wmm_ap_config(&wlApWmm, iFlags);
            if (iRet != IFX_CWMP_SUCCESS) {	
            iRet = ERR_CWMP_INTERNAL;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get all values"
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto errorHandler;
            }  

            for (i = 0; i < iElements; i++)
            {
                switch (paxParamVal[i].iaOID[uiParamPos])
                {
                    case OID_IGD_LAND_WLANC_APWMMP_AIFSN:
                        wlApWmm.AIFSN = atoi(paxParamVal[i].Value);
                        if(wlApWmm.AIFSN <0 || wlApWmm.AIFSN >15)
                        {
                            iRet = ERR_CWMP_INVAL_PARAM_VAL;
                            paxParamVal->iFaultCode=ERR_CWMP_INVAL_PARAM_VAL;
                            goto errorHandler;
                        }
                        break;
                    case OID_IGD_LAND_WLANC_APWMMP_ECWMIN:
                        wlApWmm.ECWmin = atoi(paxParamVal[i].Value);
                        if(wlApWmm.ECWmin <0 || wlApWmm.ECWmin >15)
                        {
                            iRet = ERR_CWMP_INVAL_PARAM_VAL;
                            paxParamVal->iFaultCode=ERR_CWMP_INVAL_PARAM_VAL;
                            goto errorHandler;                            
                        }
                        break;
                    case OID_IGD_LAND_WLANC_APWMMP_ECWMAX:
                        wlApWmm.ECWmax = atoi(paxParamVal[i].Value);
                        if(wlApWmm.ECWmax <0 || wlApWmm.ECWmax >15)
                        {
                            iRet = ERR_CWMP_INVAL_PARAM_VAL;
                            paxParamVal->iFaultCode=ERR_CWMP_INVAL_PARAM_VAL;
                            goto errorHandler;                            
                        }
                        break;    
                    case OID_IGD_LAND_WLANC_APWMMP_TXOP:
                        wlApWmm.TXOP= atoi(paxParamVal[i].Value);
                        if(wlApWmm.TXOP <0 || wlApWmm.TXOP >255)
                        {
                            iRet = ERR_CWMP_INVAL_PARAM_VAL;
                            paxParamVal->iFaultCode=ERR_CWMP_INVAL_PARAM_VAL;
                            goto errorHandler;                            
                        }
                        break;                
                    case OID_IGD_LAND_WLANC_APWMMP_ACKPOLICY:
                        wlApWmm.ackPolicyEna= atoi(paxParamVal[i].Value);
                        break;                
                    default:
                        break;
                }
            }

            wlApWmm.iid.config_owner = IFX_TR69;
            
            iRet = ifx_mapi_set_wlan_wmm_ap_config(iOper, &wlApWmm, IFX_F_MODIFY);
            if (iRet != IFX_CWMP_SUCCESS) {	
                iRet = ERR_CWMP_INTERNAL;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to set all values "
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto errorHandler;
            }  
            
            break;
        default:
            break;
    }
    return IFIN_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed!\n", __func__, __LINE__);
    return iRet;
}

/*
** =============================================================================
**   Function Name    : IFX_WlanStaWmmGetValue
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/
static int32
IFX_WlanStaWmmGetValue(IN OperInfo * pxOperInfo, INOUT ParamVal * paxParamVal,
                     IN uint32 iElements)
{

    uint32 i = 0;
    uint32 uiCpeid = 0;
    uint32 uiPcpeid = 0;
    int32 iRet = IFX_CWMP_SUCCESS;
    uint32 iFlags = 0, uiParamPos = 0;

    IFX_MAPI_WLAN_STA_WMM_Cfg wlStaWmm;
    
    memset(&wlStaWmm,0x00, sizeof(IFX_MAPI_WLAN_STA_WMM_Cfg));
    
    // Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(paxParamVal->iaOID, &uiCpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Get the pCpeid from Tr69 id
    iRet = IFX_GetParentObjCpeId(paxParamVal->iaOID, &uiPcpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Fills the Cpeid,ParentCepid,TR69Id,Owner
    iFlags = IFX_F_GET_ANY;

    // Get the WlanWmmParamPos
    uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);

    wlStaWmm.iid.cpeId.Id = uiCpeid;
    wlStaWmm.iid.pcpeId.Id = uiPcpeid;


    iRet = ifx_mapi_get_wlan_wmm_sta_config(&wlStaWmm, iFlags);
    if (iRet != IFX_CWMP_SUCCESS) {	
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get all values"
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
        goto errorHandler;
	}

    for (i = 0; i < iElements; i++)
    {
        // Malloc and assign the pointer to the Value attr of struct
        paxParamVal[i].Value = IFIN_CWMP_MALLOC(128);
        if (paxParamVal->Value == NULL)
        {
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (paxParamVal[i].iaOID[uiParamPos])
        {
            case OID_IGD_LAND_WLANC_STAWMMP_AIFSN:
                sprintf(paxParamVal[i].Value,"%d",wlStaWmm.AIFSN);
                break;
            case OID_IGD_LAND_WLANC_STAWMMP_ECWMIN:
                sprintf(paxParamVal[i].Value,"%d",wlStaWmm.ECWmin);
                break;
            case OID_IGD_LAND_WLANC_STAWMMP_ECWMAX:
                sprintf(paxParamVal[i].Value,"%d",wlStaWmm.ECWmax);
                break;    
            case OID_IGD_LAND_WLANC_STAWMMP_TXOP:
                sprintf(paxParamVal[i].Value,"%d",wlStaWmm.TXOP);
                break;                
            case OID_IGD_LAND_WLANC_STAWMMP_ACKPOLICY:
                sprintf(paxParamVal[i].Value,"%d",wlStaWmm.ackPolicyEna);
                break;                
            default:
                break;
        }   
    }

    return IFX_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed ParamId=%d !\n", __func__, __LINE__,
                paxParamVal->iaOID[uiParamPos]);
    return IFIN_CWMP_FAILURE;
}


/*
** =============================================================================
**   Function Name    : IFX_WlanWpsSetValue
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/
static int32
IFX_WlanStaWmmSetValue(IN OperInfo * pxOpInfo, INOUT ParamVal * paxParamVal,
                     IN int32 iElements)
{

    uint32 i = 0;
    uint32 uiCpeid = 0;
    uint32 uiPcpeid = 0;
    int32 iRet = IFX_CWMP_SUCCESS;
    uint32 iOper = 0, iFlags = 0, uiParamPos = 0;
    
    IFX_MAPI_WLAN_STA_WMM_Cfg wlStaWmm;
    
    memset(&wlStaWmm, 0x00, sizeof(IFX_MAPI_WLAN_STA_WMM_Cfg));
    
    // Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(paxParamVal->iaOID, &uiCpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Get the pCpeid from Tr69 id
    iRet = IFX_GetParentObjCpeId(paxParamVal->iaOID, &uiPcpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Fills the Cpeid,ParentCepid,TR69Id,Owner
    iOper = IFX_OP_MOD;
    iFlags = IFX_F_GET_ANY;

    // Get the WlanWpsParamPos
    uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);
   
    wlStaWmm.iid.cpeId.Id = uiCpeid;
    wlStaWmm.iid.pcpeId.Id = uiPcpeid;
    
    switch (pxOpInfo->iSubOper)
    {

        case OP_SETVAL_CHK_MODIFY_DEP:
            break;

        case OP_SETVAL_VALIDATE:
            break;

        case OP_SETVAL_MODIFY:
            
            iRet = ifx_mapi_get_wlan_wmm_sta_config(&wlStaWmm, iFlags);
            if (iRet != IFX_CWMP_SUCCESS) {	
            iRet = ERR_CWMP_INTERNAL;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get all values"
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto errorHandler;
            }  

            for (i = 0; i < iElements; i++)
            {
                switch (paxParamVal[i].iaOID[uiParamPos])
                {
                    case OID_IGD_LAND_WLANC_STAWMMP_AIFSN:
                        wlStaWmm.AIFSN = atoi(paxParamVal[i].Value);
                        if(wlStaWmm.AIFSN <0 || wlStaWmm.AIFSN >15)
                        {
                            iRet = ERR_CWMP_INVAL_PARAM_VAL;
                            paxParamVal->iFaultCode=ERR_CWMP_INVAL_PARAM_VAL;
                            goto errorHandler;
                        }
                        break;
                    case OID_IGD_LAND_WLANC_STAWMMP_ECWMIN:
                        wlStaWmm.ECWmin = atoi(paxParamVal[i].Value);
                        if(wlStaWmm.ECWmin <0 || wlStaWmm.ECWmin >15)
                        {
                            iRet = ERR_CWMP_INVAL_PARAM_VAL;
                            paxParamVal->iFaultCode=ERR_CWMP_INVAL_PARAM_VAL;
                            goto errorHandler;                            
                        }
                        break;
                    case OID_IGD_LAND_WLANC_STAWMMP_ECWMAX:
                        wlStaWmm.ECWmax = atoi(paxParamVal[i].Value);
                        if(wlStaWmm.ECWmax <0 || wlStaWmm.ECWmax >15)
                        {
                            iRet = ERR_CWMP_INVAL_PARAM_VAL;
                            paxParamVal->iFaultCode=ERR_CWMP_INVAL_PARAM_VAL;
                            goto errorHandler;                            
                        }
                        break;    
                    case OID_IGD_LAND_WLANC_STAWMMP_TXOP:
                        wlStaWmm.TXOP= atoi(paxParamVal[i].Value);
                        if(wlStaWmm.TXOP <0 || wlStaWmm.TXOP >255)
                        {
                            iRet = ERR_CWMP_INVAL_PARAM_VAL;
                            paxParamVal->iFaultCode=ERR_CWMP_INVAL_PARAM_VAL;
                            goto errorHandler;                            
                        }
                        break;                
                    case OID_IGD_LAND_WLANC_STAWMMP_ACKPOLICY:
                        wlStaWmm.ackPolicyEna= atoi(paxParamVal[i].Value);
                        break;                
                    default:
                        break;
                }
            }

            wlStaWmm.iid.config_owner = IFX_TR69;
            
            iRet = ifx_mapi_set_wlan_wmm_sta_config(iOper, &wlStaWmm, IFX_F_MODIFY);
            if (iRet != IFX_CWMP_SUCCESS) {	
                iRet = ERR_CWMP_INTERNAL;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to set all values "
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto errorHandler;
            }  
            
            break;
        default:
            break;
    }
    return IFIN_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed!\n", __func__, __LINE__);
    return iRet;
}


/*
** =============================================================================
**   Function Name    : IFX_WlanWmmSetAttr
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/

int32
IFX_WlanWmmSetAttr(IN OperInfo * pxOpInfo, INOUT ParamVal * pxParamVal,
                    IN int32 iElements)
{
    int32 iRet = 0;

    iRet = IFX_SetAttributesInfo(pxOpInfo, pxParamVal, iElements);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed!\n", __func__, __LINE__);
    return iRet;
}


/*
** =============================================================================
**   Function Name    : IFX_WanDslLinkConfig_Init
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/
int32
IFX_WlanWmm_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;


    /* Register the WlanWepKey module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_WLAN_APWMM_OBJ, IFX_WlanApWmm);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "Unable to Register %s with Object Model\n",
                    IFX_WLAN_APWMM_OBJ);
        goto errorHandler;
    }

    /* Register the WlanWepKey module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_WLAN_STAWMM_OBJ, IFX_WlanStaWmm);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "Unable to Register %s with Object Model\n",
                    IFX_WLAN_STAWMM_OBJ);
        goto errorHandler;
    }

errorHandler:
    return iRet;
}


/*********************************************************************************
*  Function Name :  IFX_WlanApWmm
*  Description   :  This function handles all the sub-states inside
                      a GET/SET operation.If it is a GET it allocates the
               array(Name,Value pairs) and retruns the values.
               If it is a SET controller allocates the array and
               passes the values to this function.It calls
               respective internal functions which in turn calls
               respective Platform APIs.

*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
                                 Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has
                                       Name,Value,etc
                    IN          int32           iElements;    No. of Elements
            OUT            void *           ppParamRet;   same as ParamStruc
            OUT         int32 *        piNumRetElem; No. of elements
*  Return Value  : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes         :
***********************************************************************************/
int32
IFX_WlanApWmm(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
             IN int32 iElements, OUT void **ppaxParamArrRet,
             OUT int32 * piNumRetElem)
{

    int32 iRet = 0;
    ParamVal *paxParamArr = (ParamVal *) paxParameterArr;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d SubOper=%d '%s' Elem=%d\n",
                _FUNCL_, pxOperInfo->iSubOper, (char8 *) paxParamArr[0].Name,
                iElements);

    switch (pxOperInfo->iOper)
    {
        // Get the object values
        case OP_GETVAL_NORMAL:
        case OP_GETVAL:
            if ((iRet = IFX_WlanApWmmGetValue(pxOperInfo, paxParamArr,
                                         iElements)) != IFX_CWMP_SUCCESS)
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
                goto errorHandler;
            }
            break;
        case OP_SETVAL:
            // Set the obj values
            switch (pxOperInfo->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                case OP_SETVAL_CHK_MODIFY_DEP:
                case OP_SETVAL_MODIFY:
                    if ((iRet = IFX_WlanApWmmSetValue(pxOperInfo, paxParamArr,
                                             iElements)) !=IFX_CWMP_SUCCESS)
                    {
                        switch (pxOperInfo->iSubOper)
                        {
                            case OP_SETVAL_CHK_MODIFY_DEP:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d OP_SETVAL_CHK_MODIFY_DEP failed!\n",
                                __func__, __LINE__);
                                goto errorHandler;

                            case OP_SETVAL_MODIFY:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d OP_SETVAL_MODIFY failed!\n",
                                __func__, __LINE__);
                                goto errorHandler;
                        }
                    }
                    break;
                case OP_SETVAL_UNDO:
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_FREE:
                case OP_SETVAL_CHK_DEL_ALLOWED:
                case OP_SETVAL_DELETE:
                case OP_SETVAL_ADD:
                    iRet = IFIN_CWMP_SUCCESS;
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
		    *ppaxParamArrRet = (ParamVal *)IFX_CWMP_MALLOC(sizeof(ParamVal));
		    if(ppaxParamArrRet!=NULL)
		    {
                    	memcpy(*ppaxParamArrRet, paxParameterArr, sizeof(ParamVal));
                    	*piNumRetElem = 1;
		    }
		    else
		    {
			goto errorHandler;
		    }
                    break;
                case OP_SETVAL_ATTRINFO:
                    if ((iRet = IFX_WlanWmmSetAttr(pxOperInfo, paxParamArr,
                                            iElements)) !=IFX_CWMP_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_SETVAL_ATTRINFO failed!\n",
                            __func__, __LINE__);
                        goto errorHandler;
                    }
                    break;
                default:
                    break;
            }
            break;
        case OP_UPDATE_CHILDINFO:
            iRet = IFIN_CWMP_SUCCESS;
            break;
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
            break;
    }
    return IFX_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d  WlanWmm returned error!\n", _FUNCL_);
    return iRet;
}


/*********************************************************************************
*  Function Name :  IFX_WlanStaWmm
*  Description   :  This function handles all the sub-states inside
                      a GET/SET operation.If it is a GET it allocates the
               array(Name,Value pairs) and retruns the values.
               If it is a SET controller allocates the array and
               passes the values to this function.It calls
               respective internal functions which in turn calls
               respective Platform APIs.

*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
                                 Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has
                                       Name,Value,etc
                    IN          int32           iElements;    No. of Elements
            OUT            void *           ppParamRet;   same as ParamStruc
            OUT         int32 *        piNumRetElem; No. of elements
*  Return Value  : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes         :
***********************************************************************************/
int32
IFX_WlanStaWmm(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
             IN int32 iElements, OUT void **ppaxParamArrRet,
             OUT int32 * piNumRetElem)
{

    int32 iRet = 0;
    ParamVal *paxParamArr = (ParamVal *) paxParameterArr;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d SubOper=%d '%s' Elem=%d\n",
                _FUNCL_, pxOperInfo->iSubOper, (char8 *) paxParamArr[0].Name,
                iElements);

    switch (pxOperInfo->iOper)
    {
        // Get the object values
        case OP_GETVAL_NORMAL:
        case OP_GETVAL:
            if ((iRet = IFX_WlanStaWmmGetValue(pxOperInfo, paxParamArr,
                                         iElements)) != IFX_CWMP_SUCCESS)
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
                goto errorHandler;
            }
            break;
        case OP_SETVAL:
            // Set the obj values
            switch (pxOperInfo->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                case OP_SETVAL_CHK_MODIFY_DEP:
                case OP_SETVAL_MODIFY:
                    if ((iRet = IFX_WlanStaWmmSetValue(pxOperInfo, paxParamArr,
                                             iElements)) !=IFX_CWMP_SUCCESS)
                    {
                        switch (pxOperInfo->iSubOper)
                        {
                            case OP_SETVAL_CHK_MODIFY_DEP:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d OP_SETVAL_CHK_MODIFY_DEP failed!\n",
                                __func__, __LINE__);
                                goto errorHandler;

                            case OP_SETVAL_MODIFY:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d OP_SETVAL_MODIFY failed!\n",
                                __func__, __LINE__);
                                goto errorHandler;
                        }
                    }
                    break;
                case OP_SETVAL_UNDO:
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_FREE:
                case OP_SETVAL_CHK_DEL_ALLOWED:
                case OP_SETVAL_DELETE:
                case OP_SETVAL_ADD:
                    iRet = IFIN_CWMP_SUCCESS;
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
		*ppaxParamArrRet = (ParamVal *)IFX_CWMP_MALLOC(sizeof(ParamVal));
		if(ppaxParamArrRet!=NULL)
		{
                    memcpy(*ppaxParamArrRet, paxParameterArr, sizeof(ParamVal));
                    *piNumRetElem = 1;
		}
		else
		{
			goto errorHandler;
		}
                    break;
                case OP_SETVAL_ATTRINFO:
                    if ((iRet = IFX_WlanWmmSetAttr(pxOperInfo, paxParamArr,
                                            iElements)) !=IFX_CWMP_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_SETVAL_ATTRINFO failed!\n",
                            __func__, __LINE__);
                        goto errorHandler;
                    }
                    break;
                default:
                    break;
            }
        case OP_UPDATE_CHILDINFO:
            iRet = IFIN_CWMP_SUCCESS;
            break;
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
            break;
    }
    return IFX_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d  WlanWmm returned error!\n", _FUNCL_);
    return iRet;
}
