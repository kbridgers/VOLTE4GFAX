/*
** =============================================================================
**   FILE NAME        : IFIN_FIREWALL.c
**   PROJECT          : TR69
**   MODULES          : X_INFINEON_COM_FIREWALL
**   DATE             : 28-03-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This is the X_INFINEON_COM_FIREWALL Module. It is required by the
**                      controller module of TR69 stack to GET/SET FIREWALL parameters.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          :
**   $Date            $Author                         $Comment
**   28-03-2006       TR69 team                       Initial Version
**
** ============================================================================
*/
/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_Global.h"
 
#include "IFX_DEVM_StackUtil.h"
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
 
#include "IFX_DEVM_AdaptCommon.h"

/*#include <resolv.h>*/
/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFIN_FIREWALL_OBJ            FORMNAME("X_LTQ_FIREWALL.")
#define IFIN_FIREWALL_PF_OBJ        FORMNAME("X_LTQ_FIREWALL.PacketFilter.")
#define IFIN_FIREWALL_PF_RULE_OBJ    FORMNAME("X_LTQ_FIREWALL.PacketFilter.PFRule.")

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/
/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;


extern unsigned long int bits2netmask(int bits);

/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/
static int32
IFIN_Firewall_PF_SetAttrInfo(IN OperInfo * pxOpInfo, INOUT ParamVal * pxPV, IN int32 iElements);
static int32 IFIN_Firewall_PF_GetValue(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
                                       IN int32 iElements);
static int32
IFIN_Firewall_PF_Modify(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);
static int32
IFIN_Firewall_PF_UpdateChildInfo(IN OperInfo *pxOI, INOUT ParamVal * pxPV, IN int32 iElements);
static int32
IFIN_Firewall_PFRule_SetAttrInfo(IN OperInfo * pxOpInfo, INOUT ParamVal * pxPV, IN int32 iElements);
static int32
IFIN_Firewall_PFRule_GetValue(IN OperInfo *pxOI, INOUT ParamVal * pxPV, IN int32 iElements);
static int32
IFIN_Firewall_PFRule_Modify(IN OperInfo *pxOI, INOUT ParamVal * pxPV, IN int32 iElements);
static int32
IFIN_Firewall_PFRule_AddDel(IN OperInfo *pxOI, INOUT ParamVal * pxPV, IN int32 iElements, IN int32 oper);
static int32
IFIN_Firewall_SetAttrInfo(IN OperInfo * pxOpInfo, INOUT ParamVal * pxPV, IN int32 iElements);
/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS>
**
** =============================================================================
*/

/*
*******************************************************************************
* Function: IFIN_FIREWALL_SetAttrInfo
* Desc: Sets attribute information in the respective tr69 sections
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFIN_Firewall_SetAttrInfo(IN OperInfo * pxOpInfo, INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    iRet = IFX_SetAttributesInfo(pxOpInfo, pxPV, iElements);

    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Updating Param Attribute Info failed\n",
                    _FUNCL_, iRet);
        goto errorHandler;
    }
errorHandler:
    return iRet;
}
/*
** =============================================================================
**   Function Name    : IFIN_Firewall_GetValue
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/
static int32
IFIN_Firewall_GetValue(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    IFX_MAPI_Firewall xFirewall;
    int32   iParamIdPos;
    uint32   iCnt = 0;

    memset(&xFirewall, 0, sizeof(IFX_MAPI_Firewall));

    /* Get all the FIREWALL parameter using Protocol API */
    iRet = ifx_mapi_get_firewall_status(&xFirewall, IFX_F_DEFAULT);
    /* Check for error */
    if (iRet != IFX_SUCCESS)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get all values"
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamIdPos = IFX_GetParamIdPos(pxParamVal->iaOID);
    if (iParamIdPos < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }
    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(MAX_DESCRIPTION_LEN);
        /* Check for error */
        if (!((pxParamVal[iCnt]).Value))
        {
            iRet = ERR_OUT_OF_MEMORY;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Allocation Failure\n",
                        __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
        }

        switch (pxParamVal[iCnt].iaOID[iParamIdPos])
        {
        case OID_IGD_XLTQFIREWALL_FEATUREENABLE:
            /* Copy the value to allocated area */
            if (xFirewall.enable)
                strcpy(pxParamVal[iCnt].Value,"1");
            else
                strcpy(pxParamVal[iCnt].Value,"0");
            IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                     IFX_CHK_CHANGE_FLAG_BASED);
            break;

        default:
            iRet = ERR_CWMP_INVAL_PARAM_NAME;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [Error] Unknown requested parameter\n",
                        __FILE__, __func__, __LINE__);
            goto cleanup;
        }
    }

cleanup:
    return (iRet);
}
/*
** =============================================================================
**   Function Name    : IFIN_Firewall_Modify
**
**   Description      : This function modifies the value of parameter in
**                      X_INFINEON_COM_FIREWALL object. It calls respective Management API
**                      for the same. It performs modification only if parameter
**                      has Write permission. In certain cases it also performs
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            :
**
** ============================================================================
*/
static int32
IFIN_Firewall_Modify(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet         = IFX_CWMP_SUCCESS;
    int32   iCnt         = 0;
    IFX_MAPI_Firewall xFirewall;
    int32   iParamIdPos;

    memset(&xFirewall, 0, sizeof(IFX_MAPI_Firewall));

    /* Get all the FIREWALL parameter using Object API */
    iRet = ifx_mapi_get_firewall_status(&xFirewall, IFX_F_DEFAULT);
    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get values of all "
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamIdPos = IFX_GetParamIdPos(pxParamVal->iaOID);
    if (iParamIdPos < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }
    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamIdPos])
        {
        case OID_IGD_XLTQFIREWALL_FEATUREENABLE:
            /* Copy the string */
            if (strcmp(pxParamVal[iCnt].Value,"1")==0 || !strncasecmp(pxParamVal[iCnt].Value,"true",4))
                xFirewall.enable = TRUE;
            else
                xFirewall.enable = FALSE;
            break;

        default:
            pxParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
            iRet = ERR_CWMP_INVAL_ARGS;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unknown Parameter\n",
                        __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
        }
    }

    /* Fill the iid structure in FIREWALL */
    xFirewall.iid.config_owner = pxOI->iCaller;

    /* Set all the FIREWALL parameters using Object API */
    iRet = ifx_mapi_set_firewall_status(&xFirewall, IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH );
    /* Check for error */
    if (iRet != IFX_SUCCESS)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to set values of all "
                    "parameters\n", __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    return (iRet);
}

/*
*******************************************************************************
* Function: IFIN_FIREWALL_PF_SetAttrInfo
* Desc: Sets attribute information in the respective tr69 sections
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFIN_Firewall_PF_SetAttrInfo(IN OperInfo * pxOpInfo, INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    iRet = IFX_SetAttributesInfo(pxOpInfo, pxPV, iElements);

    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Updating Param Attribute Info failed\n",
                    _FUNCL_, iRet);
        goto errorHandler;
    }
errorHandler:
    return iRet;
}
/*
** =============================================================================
**   Function Name    : IFIN_Firewall_PF_GetValue
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/
static int32
IFIN_Firewall_PF_GetValue(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    IFX_MAPI_Firewall_PF xFirewall;
    int32   iParamIdPos;
    int32   iCnt = 0;

    memset(&xFirewall, 0, sizeof(IFX_MAPI_Firewall_PF));

    /* Get all the FIREWALL parameter using Protocol API */
    iRet = ifx_mapi_get_firewall_pfstatus(&xFirewall, IFX_F_DEFAULT);
    /* Check for error */
    if (iRet != IFX_SUCCESS)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get all values"
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamIdPos = IFX_GetParamIdPos(pxParamVal->iaOID);
    if (iParamIdPos < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }
    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(MAX_DESCRIPTION_LEN);
        /* Check for error */
        if (!((pxParamVal[iCnt]).Value))
        {
            iRet = ERR_OUT_OF_MEMORY;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Allocation Failure\n",
                        __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
        }

        switch (pxParamVal[iCnt].iaOID[iParamIdPos])
        {
        case OID_IGD_XLTQFIREWALL_PF_FEATUREENABLE:
            /* Copy the value to allocated area */
            if (xFirewall.enable)
                strcpy(pxParamVal[iCnt].Value,"1");
            else
                strcpy(pxParamVal[iCnt].Value,"0");
            IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                     IFX_CHK_CHANGE_FLAG_BASED);
            break;

        case OID_IGD_XLTQFIREWALL_PF_RULENUMBEROFENTRIES:
            /* Copy the value to allocated area */
            sprintf(pxParamVal[iCnt].Value, "%d", xFirewall.ruleNoOfEntries);
            IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                     IFX_CHK_CHANGE_FLAG_BASED);
            break;

        default:
            iRet = ERR_CWMP_INVAL_PARAM_NAME;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [Error] Unknown requested parameter\n",
                        __FILE__, __func__, __LINE__);
            goto cleanup;
        }
    }

cleanup:
    return (iRet);
}
/*
** =============================================================================
**   Function Name    : IFIN_Firewall_PF_Modify
**
**   Description      : This function modifies the value of parameter in
**                      X_INFINEON_COM_FIREWALL object. It calls respective Management API
**                      for the same. It performs modification only if parameter
**                      has Write permission. In certain cases it also performs
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            :
**
** ============================================================================
*/
static int32
IFIN_Firewall_PF_Modify(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet         = IFX_CWMP_SUCCESS;
    int32   iCnt         = 0;
    IFX_MAPI_Firewall_PF xFirewall;
    int32   iParamIdPos;

    memset(&xFirewall, 0, sizeof(IFX_MAPI_Firewall_PF));

    /* Get all the FIREWALL parameter using Object API */
    iRet = ifx_mapi_get_firewall_pfstatus(&xFirewall, IFX_F_DEFAULT);
    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get values of all "
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamIdPos = IFX_GetParamIdPos(pxParamVal->iaOID);
    if (iParamIdPos < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }
    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamIdPos])
        {
        case OID_IGD_XLTQFIREWALL_PF_FEATUREENABLE:
            /* Copy the string */
            if (strcmp(pxParamVal[iCnt].Value,"1")==0  || !strncasecmp(pxParamVal[iCnt].Value,"true",4))
                xFirewall.enable = TRUE;
            else
                xFirewall.enable = FALSE;
            break;

        default:
            pxParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
            iRet = ERR_CWMP_INVAL_ARGS;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unknown Parameter\n",
                        __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
        }
    }

    /* Fill the iid structure in FIREWALL */
    xFirewall.iid.config_owner = pxOI->iCaller;

    /* Set all the FIREWALL parameters using Object API */
    iRet = ifx_mapi_set_firewall_pfstatus(&xFirewall, IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH );
    /* Check for error */
    if (iRet != IFX_SUCCESS)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to set values of all "
                    "parameters\n", __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    return (iRet);
}

static int32
IFIN_Firewall_PF_UpdateChildInfo(IN OperInfo *pxOI, INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32   iRet         = IFX_CWMP_SUCCESS;
    IFX_MAPI_Firewall_PF xFirewall;

    memset(&xFirewall, 0, sizeof(IFX_MAPI_Firewall_PF));

    /* Get all the FIREWALL parameter using Object API */
    iRet = ifx_mapi_get_firewall_pfstatus(&xFirewall, IFX_F_DEFAULT);
    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get values of all "
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Fill the iid structure in FIREWALL */
    xFirewall.iid.config_owner = pxOI->iCaller;
    if (pxOI->iSubOper == OP_UPDATE_CHILDINFO_ADD)
        xFirewall.ruleNoOfEntries++;
    else if (pxOI->iSubOper == OP_UPDATE_CHILDINFO_DEL)
        xFirewall.ruleNoOfEntries--;

    /* Set all the FIREWALL parameters using Object API */
    iRet = ifx_mapi_set_firewall_pfstatus(&xFirewall, IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH);
    /* Check for error */
    if (iRet != IFX_SUCCESS)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to set values of all "
                    "parameters\n", __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    return (iRet);
}

static int32
IFIN_Firewall_PFRule_SetAttrInfo(IN OperInfo * pxOpInfo, INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    iRet = IFX_SetAttributesInfo(pxOpInfo, pxPV, iElements);

    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Updating Param Attribute Info failed\n",
                    _FUNCL_, iRet);
        goto errorHandler;
    }
errorHandler:
    return iRet;
}

static int32
IFIN_Firewall_PFRule_GetValue(IN OperInfo *pxOI, INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    IFX_MAPI_Firewall_PFRule xFirewallRule;
    uint32 uiCpeid;
    int32   iParamIdPos;
    int32   iCnt = 0;

    ParamVal xGetParam;
    ParamVal *paxGetParamVal = NULL;
    int32 iElemOut=0;
    int32 i,j,i_save=0;
    char sIfName[150], temp[100];
    int32 wan_type = 0;

    memset(&xFirewallRule, 0, sizeof(IFX_MAPI_Firewall_PFRule));

    iRet = IFX_GetCpeId(pxParamVal->iaOID, &uiCpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto cleanup;

    xFirewallRule.iid.cpeId.Id = uiCpeid;
    xFirewallRule.iid.config_owner = pxOI->iCaller;
    xFirewallRule.iid.pcpeId.Id = 1;
    strcpy(xFirewallRule.iid.pcpeId.secName, "firewall_packetfilter_status");
    iRet = IFX_ConvertOidDottedForm(pxParamVal->iaOID, xFirewallRule.iid.tr69Id);
    if (iRet != IFX_CWMP_SUCCESS)
        goto cleanup;
    /* Get all the Firewall Rule parameters using Protocol API */
    iRet = ifx_mapi_get_firewall_pfrule(&xFirewallRule);
    /* Check for error */
    if (iRet != IFX_SUCCESS)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get all values"
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamIdPos = IFX_GetParamIdPos(pxParamVal->iaOID);
    if (iParamIdPos < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }
    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(MAX_DESCRIPTION_LEN);
        /* Check for error */
        if (!((pxParamVal[iCnt]).Value))
        {
            iRet = ERR_OUT_OF_MEMORY;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Allocation Failure\n",
                        __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
        }

        switch (pxParamVal[iCnt].iaOID[iParamIdPos])
        {
        case OID_IGD_XLTQFIREWALL_PF_PFR_ENABLE:
            /* Copy the value to allocated area */
            if (xFirewallRule.enable)
                strcpy(pxParamVal[iCnt].Value,"1");
            else
                strcpy(pxParamVal[iCnt].Value,"0");
            IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                     IFX_CHK_CHANGE_FLAG_BASED);
            break;

        case OID_IGD_XLTQFIREWALL_PF_PFR_PROTOCOL:
            /* Copy the value to allocated area */
            sprintf(pxParamVal[iCnt].Value,"%d", xFirewallRule.protoType);
            IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                     IFX_CHK_CHANGE_FLAG_BASED);
            break;

        case OID_IGD_XLTQFIREWALL_PF_PFR_SOURCETYPE:
            sprintf(pxParamVal[iCnt].Value,"%d", xFirewallRule.srcType);
            IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                     IFX_CHK_CHANGE_FLAG_BASED);
            break;

        case OID_IGD_XLTQFIREWALL_PF_PFR_SOURCEIP:
            /* Copy the value to allocated area */
            strcpy(pxParamVal[iCnt].Value, inet_ntoa(xFirewallRule.srcIP.ip));
            IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                     IFX_CHK_CHANGE_FLAG_BASED);
            break;
        case OID_IGD_XLTQFIREWALL_PF_PFR_SOURCEMASK:

            strcpy(pxParamVal[iCnt].Value, inet_ntoa(xFirewallRule.srcIP.mask));
            IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                     IFX_CHK_CHANGE_FLAG_BASED);
            break;

        case OID_IGD_XLTQFIREWALL_PF_PFR_SOURCEPORTRANGE:
            /* Copy the value to allocated area */
            sprintf(pxParamVal[iCnt].Value, "%d", xFirewallRule.sPortRange.start_port);
            if (xFirewallRule.sPortRange.end_port)
            {
                sprintf(temp,"%d", xFirewallRule.sPortRange.end_port);
                strcat(pxParamVal[iCnt].Value,":");
                strcat(pxParamVal[iCnt].Value,temp);
            }
            IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                     IFX_CHK_CHANGE_FLAG_BASED);
            break;

        case OID_IGD_XLTQFIREWALL_PF_PFR_DESTTYPE:
            sprintf(pxParamVal[iCnt].Value,"%d", xFirewallRule.dstType);
            IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                     IFX_CHK_CHANGE_FLAG_BASED);
            break;

        case OID_IGD_XLTQFIREWALL_PF_PFR_DESTIP:
            /* Copy the value to allocated area */
            strcpy(pxParamVal[iCnt].Value, inet_ntoa(xFirewallRule.dstIP.ip));
            /*            sprintf(temp,"%d", netmask_to_len(xFirewallRule.srcIP.mask));
                        strcat(pxParamVal[iCnt].Value,"/");
                        strcat(pxParamVal[iCnt].Value,temp);*/
            IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                     IFX_CHK_CHANGE_FLAG_BASED);
            break;
        case OID_IGD_XLTQFIREWALL_PF_PFR_DESTMASK:

            strcpy(pxParamVal[iCnt].Value, inet_ntoa(xFirewallRule.dstIP.mask));
            IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                     IFX_CHK_CHANGE_FLAG_BASED);
            break;

        case OID_IGD_XLTQFIREWALL_PF_PFR_DESTPORTRANGE:
            /* Copy the value to allocated area */
            sprintf(pxParamVal[iCnt].Value, "%d", xFirewallRule.dPortRange.start_port);
            if (xFirewallRule.dPortRange.end_port)
            {
                sprintf(temp,"%d", xFirewallRule.dPortRange.end_port);
                strcat(pxParamVal[iCnt].Value,":");
                strcat(pxParamVal[iCnt].Value,temp);
            }
            IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                     IFX_CHK_CHANGE_FLAG_BASED);
            break;

        case OID_IGD_XLTQFIREWALL_PF_PFR_SOURCEMACADDRESS:
            /* Copy the value to allocated area */
            strcpy(pxParamVal[iCnt].Value, xFirewallRule.sMacAddr);
            IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                     IFX_CHK_CHANGE_FLAG_BASED);
            break;
        case OID_IGD_XLTQFIREWALL_PF_PFR_INPUTINTERFACE:
            if (!strcmp(xFirewallRule.iif,"br0"))
            {
                if (pxOI->iCaller != ACC_TR64 && pxOI->iCaller != ACC_UPNP)
                {
                    //ORP:Interface name is not terminated by dot. So removing the dot
                    strcpy(pxParamVal[iCnt].Value,"InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.IPInterface.1");
                }
                else
                {
                    strcpy(pxParamVal[iCnt].Value,"InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.IPInterface.1.");
                }
                i_save = 1; //set flag when found
            }
            else
            {

                for (j=0; j<=1; j++)   // counter to run through wanip and wanppp
                {
                    memset(&xGetParam,0x00,sizeof(xGetParam));

                    // copy the oid of IGD.WANDevice.MN.WANConnectoinDevice.MN.WANIPConnection.MN.Name
                    xGetParam.iaOID[0] = -1000;
                    xGetParam.iaOID[1] = -1224;
                    xGetParam.iaOID[2] =  MAGIC_NUMBER;
                    xGetParam.iaOID[3] =  -1385;
                    xGetParam.iaOID[4] = MAGIC_NUMBER;
                    xGetParam.iaOID[5] =  (j) ? -1432 : -1472;
                    xGetParam.iaOID[6] = MAGIC_NUMBER;
                    xGetParam.iaOID[7] = (j) ? -1437 : -1477;
                    xGetParam.iaOID[8] = 0;
                    xGetParam.iaOID[9] = 0;
                    xGetParam.iaOID[10] = 0;

                    iRet = IFX_GlobalGetVal( &xGetParam, &paxGetParamVal, (uint32 *)&iElemOut);
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d] IFX_GlobalGetVal failed \n", __func__ , __LINE__);
                        IFX_CWMP_FREE(xGetParam.Name);
                        for (i=0; i<iElemOut; i++)
                        {
                            if (paxGetParamVal != NULL)
                            {
                                //free the irrelevant dataifx_
                                IFX_CWMP_FREE(paxGetParamVal[i].Name);
                                IFX_CWMP_FREE(paxGetParamVal[i].Value);
                            }
                        }
                        IFX_CWMP_FREE(paxGetParamVal);
                        if (j == 1)
                            goto interface_end;
                        else
                            continue;
                    }

                    for (i=0; i<iElemOut; i++)
                    {
                        wan_type = (j) ? WAN_TYPE_IP : WAN_TYPE_PPP;
                        // convert the connection name to interface name
                        iRet = ifx_get_wan_ifname_from_conf_connName(paxGetParamVal[i].Value, sIfName, wan_type);
                        if (iRet != IFX_CWMP_SUCCESS)
                        {
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d]  ifx_get_wan_ifname_from_conf_connName failed \n", __func__ , __LINE__);

                            IFX_CWMP_FREE(xGetParam.Name);
                            for (i=0; i<iElemOut; i++)
                            {
                                //free the irrelevant dataifx_
                                IFX_CWMP_FREE(paxGetParamVal[i].Name);
                                IFX_CWMP_FREE(paxGetParamVal[i].Value);
                            }
                            IFX_CWMP_FREE(paxGetParamVal);
                            iRet = ERR_CWMP_INTERNAL;
                            goto cleanup;
                        }

                        // if the interface value matches, copy the name as the final response
                        if (!strcmp(xFirewallRule.iif, sIfName))
                        {
                            // copy the path just before till name
                            if (pxOI->iCaller != ACC_TR64 && pxOI->iCaller != ACC_UPNP)
                            {
                                //ORP: Get operation will give the interface name that is not terminated by dot. So substracting 5 instead of 4
                                strncpy(pxParamVal[iCnt].Value, paxGetParamVal[i].Name, strlen(paxGetParamVal[i].Name)-5);
                            }
                            else
                            {
                                strncpy(pxParamVal[iCnt].Value, paxGetParamVal[i].Name, strlen(paxGetParamVal[i].Name)-4);
                            }
                            i_save = 1; //set flag when found
                            break;
                        }// end if
                    } // end for

                    IFX_CWMP_FREE(xGetParam.Name);
                    for (i=0; i<iElemOut; i++)
                    {
                        //free the irrelevant dataifx_
                        IFX_CWMP_FREE(paxGetParamVal[i].Name);
                        IFX_CWMP_FREE(paxGetParamVal[i].Value);
                    }
                    IFX_CWMP_FREE(paxGetParamVal);

                    if (i_save == 1)        // no need to check for different type of conn if already found
                        break;
                }// end for
            }// end if-else

            IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                     IFX_CHK_CHANGE_FLAG_BASED);
interface_end :
            break;
        case OID_IGD_XLTQFIREWALL_PF_PFR_OUTPUTINTERFACE:
            if (!strcmp(xFirewallRule.oif,"br0"))
            {
                if (pxOI->iCaller != ACC_TR64 && pxOI->iCaller != ACC_UPNP)
                {
                    //ORP:Interface name is not terminated by dot. So removing the dot
                    strcpy(pxParamVal[iCnt].Value,"InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.IPInterface.1");
                }
                else
                {
                    strcpy(pxParamVal[iCnt].Value,"InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.IPInterface.1.");
                }
                i_save = 1; //set flag when found
            }
            else
            {

                for (j=0; j<=1; j++)   // counter to run through wanip and wanppp
                {
                    memset(&xGetParam,0x00,sizeof(xGetParam));

                    // copy the oid of IGD.WANDevice.MN.WANConnectoinDevice.MN.WANIPConnection.MN.Name
                    xGetParam.iaOID[0] = -1000;
                    xGetParam.iaOID[1] = -1224;
                    xGetParam.iaOID[2] =  MAGIC_NUMBER;
                    xGetParam.iaOID[3] =  -1385;
                    xGetParam.iaOID[4] = MAGIC_NUMBER;
                    xGetParam.iaOID[5] =  (j) ? -1432 : -1472;
                    xGetParam.iaOID[6] = MAGIC_NUMBER;
                    xGetParam.iaOID[7] = (j) ? -1437 : -1477;
                    xGetParam.iaOID[8] = 0;
                    xGetParam.iaOID[9] = 0;
                    xGetParam.iaOID[10] = 0;

                    iRet = IFX_GlobalGetVal( &xGetParam, &paxGetParamVal, (uint32 *)&iElemOut);
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d] IFX_GlobalGetVal failed \n", __func__ , __LINE__);
                        IFX_CWMP_FREE(xGetParam.Name);
                        for (i=0; i<iElemOut; i++)
                        {
                            if (paxGetParamVal != NULL)
                            {
                                //free the irrelevant dataifx_
                                IFX_CWMP_FREE(paxGetParamVal[i].Name);
                                IFX_CWMP_FREE(paxGetParamVal[i].Value);
                            }
                        }
                        IFX_CWMP_FREE(paxGetParamVal);
                        if (j == 1)
                            goto iface_end;
                        else
                            continue;
                    }

                    for (i=0; i<iElemOut; i++)
                    {
                        wan_type = (j) ? WAN_TYPE_IP : WAN_TYPE_PPP;
                        // convert the connection name to interface name
                        iRet = ifx_get_wan_ifname_from_conf_connName(paxGetParamVal[i].Value, sIfName, wan_type);
                        if (iRet != IFX_CWMP_SUCCESS)
                        {
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d]  ifx_get_wan_ifname_from_conf_connName failed \n", __func__ , __LINE__);

                            IFX_CWMP_FREE(xGetParam.Name);
                            for (i=0; i<iElemOut; i++)
                            {
                                //free the irrelevant dataifx_
                                IFX_CWMP_FREE(paxGetParamVal[i].Name);
                                IFX_CWMP_FREE(paxGetParamVal[i].Value);
                            }
                            IFX_CWMP_FREE(paxGetParamVal);
                            iRet = ERR_CWMP_INTERNAL;
                            goto cleanup;
                        }

                        // if the interface value matches, copy the name as the final response
                        if (!strcmp(xFirewallRule.oif, sIfName))
                        {
                            // copy the path just before till name
                            if (pxOI->iCaller != ACC_TR64 && pxOI->iCaller != ACC_UPNP)
                            {
                                //ORP: Get operation will give the interface name that is not terminated by dot. So substracting 5 instead of 4
                                strncpy(pxParamVal[iCnt].Value, paxGetParamVal[i].Name, strlen(paxGetParamVal[i].Name)-5);
                            }
                            else
                            {
                                strncpy(pxParamVal[iCnt].Value, paxGetParamVal[i].Name, strlen(paxGetParamVal[i].Name)-4);
                            }
                            i_save = 1; //set flag when found
                            break;
                        }// end if
                    } // end for

                    IFX_CWMP_FREE(xGetParam.Name);
                    for (i=0; i<iElemOut; i++)
                    {
                        //free the irrelevant dataifx_
                        IFX_CWMP_FREE(paxGetParamVal[i].Name);
                        IFX_CWMP_FREE(paxGetParamVal[i].Value);
                    }
                    IFX_CWMP_FREE(paxGetParamVal);

                    if (i_save == 1)        // no need to check for different type of conn if already found
                        break;
                }// end for
            }// end if-else
            IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                     IFX_CHK_CHANGE_FLAG_BASED);
iface_end:
            break;
        default:
            iRet = ERR_CWMP_INVAL_PARAM_NAME;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [Error] Unknown requested parameter\n",
                        __FILE__, __func__, __LINE__);
            goto cleanup;
        }
    }

cleanup:
    return (iRet);
}

static int32
IFIN_Firewall_PFRule_Modify(IN OperInfo *pxOI, INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32   iRet         = IFX_CWMP_SUCCESS;
    int32   iCnt         = 0;
    IFX_MAPI_Firewall_PFRule xFirewallRule;
    uint32 uiCpeid;
    int32   iParamIdPos;
    int32 wan_type = 0;

    char *temp = NULL, *tmp = NULL;
    int j;
    ParamVal xGetParam;
    ParamVal *paxGetParamVal = NULL;
    char8 caInterface[CWMP_MAX_OBJ_LEN] = { 0 };
    int32 iElemOut;
    char sIfName[150]={0};
    uint32 uiflags = 0;

    memset(&xFirewallRule, 0, sizeof(IFX_MAPI_Firewall_PFRule));

    iRet = IFX_GetCpeId(pxParamVal->iaOID, &uiCpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto cleanup;

    xFirewallRule.iid.cpeId.Id = uiCpeid;
    xFirewallRule.iid.config_owner = pxOI->iCaller;
    xFirewallRule.iid.pcpeId.Id = 1;
    strcpy(xFirewallRule.iid.pcpeId.secName, "firewall_packetfilter_status");
    iRet = IFX_ConvertOidDottedForm(pxParamVal->iaOID, xFirewallRule.iid.tr69Id);
    if (iRet != IFX_CWMP_SUCCESS)
        goto cleanup;

    /* Get all the FIREWALL parameter using Object API */
    iRet = ifx_mapi_get_firewall_pfrule(&xFirewallRule);
    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get values of all "
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamIdPos = IFX_GetParamIdPos(pxParamVal->iaOID);
    if (iParamIdPos < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }
    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamIdPos])
        {
        case OID_IGD_XLTQFIREWALL_PF_PFR_ENABLE:
            /* Copy the string */
            if (strcmp(pxParamVal[iCnt].Value,"1")==0  || !strncasecmp(pxParamVal[iCnt].Value,"true",4))
                xFirewallRule.enable = TRUE;
            else
            {
                xFirewallRule.enable = FALSE;
            }
            break;

        case OID_IGD_XLTQFIREWALL_PF_PFR_PROTOCOL:
            /* Copy the value to allocated area */
            xFirewallRule.protoType = atoi(pxParamVal[iCnt].Value);
            if (xFirewallRule.protoType!=IFX_MAPI_Protocol_AH&&
                    xFirewallRule.protoType!=IFX_MAPI_Protocol_ESP&&
                    xFirewallRule.protoType!=IFX_MAPI_Protocol_ICMP&&
                    xFirewallRule.protoType!=IFX_MAPI_Protocol_TCP&&
                    xFirewallRule.protoType!=IFX_MAPI_Protocol_UDP&&
                    xFirewallRule.protoType!=IFX_MAPI_Protocol_ESP&&
                    xFirewallRule.protoType!=IFX_MAPI_Protocol_ALL)
                xFirewallRule.protoType=IFX_MAPI_Protocol_ALL;
            break;

        case OID_IGD_XLTQFIREWALL_PF_PFR_SOURCETYPE:
            xFirewallRule.srcType = atoi(pxParamVal[iCnt].Value);
            break;
        case OID_IGD_XLTQFIREWALL_PF_PFR_SOURCEIP:
            /* Copy the value to allocated area */
            temp=NULL;
            temp=strchr(pxParamVal[iCnt].Value,'/');
            if (temp!=NULL && *temp!='\0')
            {
                xFirewallRule.srcIP.mask.s_addr = bits2netmask(atoi((temp+1)));
                *temp='\0';
            }
            inet_aton(pxParamVal[iCnt].Value,&(xFirewallRule.srcIP.ip));
            break;
        case OID_IGD_XLTQFIREWALL_PF_PFR_SOURCEMASK:
            inet_aton(pxParamVal[iCnt].Value,&(xFirewallRule.srcIP.mask));
            break;
        case OID_IGD_XLTQFIREWALL_PF_PFR_SOURCEPORTRANGE:
            /* Copy the value to allocated area */
            temp=NULL;
            temp=strchr(pxParamVal[iCnt].Value,':');
            if (temp!=NULL && *temp!='\0')
            {
                xFirewallRule.sPortRange.end_port = atoi((temp+1));
                *temp='\0';
            }
            xFirewallRule.sPortRange.start_port = atoi(pxParamVal[iCnt].Value);

            if( xFirewallRule.sPortRange.end_port <= xFirewallRule.sPortRange.start_port || 
                xFirewallRule.sPortRange.start_port > 65535 || atoi(pxParamVal[iCnt].Value) < 1 ||
                xFirewallRule.sPortRange.end_port > 65535 )
                        {
                                iRet = ERR_CWMP_INVAL_ARGS;
                                pxParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                                goto cleanup;
                        }

            break;

        case OID_IGD_XLTQFIREWALL_PF_PFR_DESTTYPE:
            xFirewallRule.dstType = atoi(pxParamVal[iCnt].Value);
            break;
        case OID_IGD_XLTQFIREWALL_PF_PFR_DESTIP:
            /* Copy the value to allocated area */
            temp=NULL;
            temp=strchr(pxParamVal[iCnt].Value,'/');
            if (temp!=NULL && *temp!='\0')
            {
                xFirewallRule.dstIP.mask.s_addr = bits2netmask(atoi((temp+1)));
                *temp='\0';
            }
            inet_aton(pxParamVal[iCnt].Value,&(xFirewallRule.dstIP.ip));
            break;
        case OID_IGD_XLTQFIREWALL_PF_PFR_DESTMASK:
            inet_aton(pxParamVal[iCnt].Value,&(xFirewallRule.dstIP.mask));
            break;
        case OID_IGD_XLTQFIREWALL_PF_PFR_DESTPORTRANGE:
            /* Copy the value to allocated area */
            temp=NULL;
            temp=strchr(pxParamVal[iCnt].Value,':');
            if (temp!=NULL&&*temp!='\0')
            {
                xFirewallRule.dPortRange.end_port = atoi((temp+1));
                *temp='\0';
            }
            xFirewallRule.dPortRange.start_port = atoi(pxParamVal[iCnt].Value);
            if( xFirewallRule.dPortRange.end_port <= xFirewallRule.dPortRange.start_port ||
                xFirewallRule.dPortRange.start_port > 65535 || atoi(pxParamVal[iCnt].Value) < 1 ||
                xFirewallRule.dPortRange.end_port > 65535 )
                        {
                                iRet = ERR_CWMP_INVAL_ARGS;
                                pxParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                                goto cleanup;
                        }

            break;

        case OID_IGD_XLTQFIREWALL_PF_PFR_SOURCEMACADDRESS:
            /* Copy the value to allocated area */
            //strcpy(xFirewallRule.sMacAddr, pxParamVal[iCnt].Value);

            strncpy(xFirewallRule.sMacAddr, pxParamVal[iCnt].Value, 17);
	    xFirewallRule.sMacAddr[17] = '\0';

            tmp = strtok(pxParamVal[iCnt].Value,":");
                        j = 0;
                        while (1)
                        {
                        if (tmp==NULL && j<6) {
                
                iRet = ERR_CWMP_INTERNAL;
                                pxParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                                goto cleanup;
                         
                            }

                            if( strlen(tmp)!=2 || (strtol(tmp,NULL,16))>255){

                                iRet = ERR_CWMP_INTERNAL;
                                pxParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                                goto cleanup;

                            }

                if(!((tmp[0]>='0' && tmp[0]<='9')||(tmp[0]>='a' && tmp[0]<='f')||(tmp[0]>='A' && tmp[0]<='F')) ||                     !((tmp[1]>='0' && tmp[1]<='9')||(tmp[1]>='a' && tmp[1]<='f')||(tmp[1]>='A' && tmp[1]<='F'))) {

                iRet = ERR_CWMP_INTERNAL;
                                pxParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                                goto cleanup;
                }                 

                            j++;
                            if(j>=6) break;

                            tmp = strtok(NULL,":");
                        }

            break;

        case OID_IGD_XLTQFIREWALL_PF_PFR_INPUTINTERFACE:
            /* Copy the value to allocated area */
            if (!strcmp(pxParamVal[iCnt].Value,""))
                break;
            else if (!strcmp(pxParamVal[iCnt].Value,"InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.IPInterface.1"))
                strcpy(xFirewallRule.iif,"br0");
            else
            {

                // convert the given interface to correct value and add to struct
                memset(&xGetParam,0x00,sizeof(xGetParam));
                xGetParam.Name = IFX_CWMP_MALLOC(strlen(pxParamVal[iCnt].Value)+8); // obj + name + dots
                if (xGetParam.Name == NULL)
                {
                    iRet = IFX_CWMP_FAILURE;
                    goto cleanup;
                }

                memset(caInterface,0,sizeof(caInterface));
                strcpy(caInterface,pxParamVal[iCnt].Value);
                if (caInterface[strlen(caInterface) -1]!='.')
                {
                    strcat(caInterface, ".");
                }

                sprintf(xGetParam.Name,"%s%s",(char *)caInterface,"Name");

                iRet = IFX_GlobalGetVal( &xGetParam, &paxGetParamVal, (uint32 *)&iElemOut);
                if (iRet != IFX_CWMP_SUCCESS)
                {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d]  IFX_GlobalGetVal failed\n", __func__ , __LINE__);
                    IFX_CWMP_FREE(xGetParam.Name);
                    if (paxGetParamVal != NULL)
                    {
                        IFX_CWMP_FREE(paxGetParamVal->Value);
                        IFX_CWMP_FREE(paxGetParamVal->Name);
                    }
                    IFX_CWMP_FREE(paxGetParamVal);
                    pxParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    goto cleanup;
                }
                if(strstr(pxParamVal[iCnt].Value,"WANPPPConnection") != NULL)
                {
                    wan_type = WAN_TYPE_PPP;
                } 
                else
                {
                    wan_type = WAN_TYPE_IP;
                } 

                iRet = ifx_get_wan_ifname_from_conf_connName(paxGetParamVal->Value, sIfName, wan_type);
                if (iRet != IFX_CWMP_SUCCESS)
                {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d]  ifx_get_wan_ifname_from_conf_connName failed\n", __func__ , __LINE__);
                    IFX_CWMP_FREE(xGetParam.Name);
                    IFX_CWMP_FREE(paxGetParamVal->Value);
                    IFX_CWMP_FREE(paxGetParamVal->Name);
                    IFX_CWMP_FREE(paxGetParamVal);

                    iRet = ERR_CWMP_INTERNAL;
                    pxParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    goto cleanup;
                }

                strncpy(xFirewallRule.iif,sIfName,15);

                IFX_CWMP_FREE(xGetParam.Name);
                IFX_CWMP_FREE(paxGetParamVal->Value);
                IFX_CWMP_FREE(paxGetParamVal->Name);
                IFX_CWMP_FREE(paxGetParamVal);
            }
            break;
        case OID_IGD_XLTQFIREWALL_PF_PFR_OUTPUTINTERFACE:
            /* Copy the value to allocated area */
            if (!strcmp(pxParamVal[iCnt].Value,""))
                break;
            else if (!strcmp(pxParamVal[iCnt].Value,"InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.IPInterface.1"))
                strcpy(xFirewallRule.oif,"br0");
            else
            {
                // convert the given interface to correct value and add to struct
                memset(&xGetParam,0x00,sizeof(xGetParam));
                xGetParam.Name = IFX_CWMP_MALLOC(strlen(pxParamVal[iCnt].Value)+8); // obj + name + dots
                if (xGetParam.Name == NULL)
                {
                    iRet = IFX_CWMP_FAILURE;
                    goto cleanup;
                }

                memset(caInterface,0,sizeof(caInterface));
                strcpy(caInterface,pxParamVal[iCnt].Value);
                if (caInterface[strlen(caInterface) -1]!='.')
                {
                    strcat(caInterface, ".");
                }

                sprintf(xGetParam.Name,"%s%s",(char *)caInterface,"Name");

                iRet = IFX_GlobalGetVal( &xGetParam, &paxGetParamVal, (uint32 *)&iElemOut);
                if (iRet != IFX_CWMP_SUCCESS)
                {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d]  IFX_GlobalGetVal failed\n", __func__ , __LINE__);
                    IFX_CWMP_FREE(xGetParam.Name);
                    if (paxGetParamVal != NULL)
                    {
                        IFX_CWMP_FREE(paxGetParamVal->Value);
                        IFX_CWMP_FREE(paxGetParamVal->Name);
                    }
                    IFX_CWMP_FREE(paxGetParamVal);
                    pxParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    goto cleanup;
                }
                if(strstr(pxParamVal[iCnt].Value,"WANPPPConnection") != NULL)
                {
                    wan_type = WAN_TYPE_PPP;
                } 
                else
                {
                    wan_type = WAN_TYPE_IP;
                } 

                iRet = ifx_get_wan_ifname_from_conf_connName(paxGetParamVal->Value, sIfName, wan_type);
                if (iRet != IFX_CWMP_SUCCESS)
                {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d]  ifx_get_wan_ifname_from_conf_connName failed\n", __func__ , __LINE__);
                    IFX_CWMP_FREE(xGetParam.Name);
                    IFX_CWMP_FREE(paxGetParamVal->Value);
                    IFX_CWMP_FREE(paxGetParamVal->Name);
                    IFX_CWMP_FREE(paxGetParamVal);

                    iRet = ERR_CWMP_INTERNAL;
                    pxParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    goto cleanup;
                }

                strncpy(xFirewallRule.oif,sIfName,15);

                IFX_CWMP_FREE(xGetParam.Name);
                IFX_CWMP_FREE(paxGetParamVal->Value);
                IFX_CWMP_FREE(paxGetParamVal->Name);
                IFX_CWMP_FREE(paxGetParamVal);
            }
            break;
        default:
            pxParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
            iRet = ERR_CWMP_INVAL_ARGS;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unknown Parameter\n",
                        __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
        }
    }

    
    if(!strcmp(xFirewallRule.oif,xFirewallRule.iif) && strlen(xFirewallRule.oif)) {
               iRet = ERR_CWMP_INTERNAL;
               pxParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
               IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
            "[%s:%s:%d] [%d] Ingress and egress interfaces cannot be the same\n",
                         __FILE__, __func__, __LINE__, iRet);
               goto cleanup;
    }

    /* Fill the iid structure in FIREWALL */
    xFirewallRule.iid.config_owner = pxOI->iCaller;
    uiflags |= IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT;

    /* Set all the FIREWALL parameters using Object API */
    iRet = ifx_mapi_set_firewall_pfrule(IFX_OP_MOD, &xFirewallRule, uiflags);
    /* Check for error */
    if (iRet != IFX_SUCCESS)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to set values of all "
                    "parameters\n", __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    return (iRet);
}

static int32
IFIN_Firewall_PFRule_AddDel(IN OperInfo *pxOI, INOUT ParamVal * pxParamVal, IN int32 iElements, IN int32 oper)
{
    int32   iRet         = IFX_CWMP_SUCCESS;
    int32   iCnt         = 0;
    IFX_MAPI_Firewall_PFRule xFirewallRule;
    uint32 uiCpeid, uiPcpeid;
    int32   iParamIdPos;
    int32 wan_type =0;
    char *temp = NULL;
    ParamVal xGetParam;
    ParamVal *paxGetParamVal = NULL;
    char8 caInterface[CWMP_MAX_OBJ_LEN] = { 0 };
    int32 iElemOut;
    char sIfName[150]={0};
    uint32 uiflags = 0;

    memset(&xFirewallRule, 0, sizeof(IFX_MAPI_Firewall_PFRule));

    if (oper == OP_SETVAL_ADD)
    {
        /* Get the offset of the parameter */
        iParamIdPos = IFX_GetParamIdPos(pxParamVal->iaOID);
        if (iParamIdPos < 0)
        {
            iRet = ERR_CWMP_INTERNAL;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
            goto cleanup;
        }
        /* Iterate and fill the requested parameters */
        for (iCnt = 0; iCnt < iElements; iCnt++)
        {
            /* Process based on the requested parameter */
            switch ((pxParamVal[iCnt]).iaOID[iParamIdPos])
            {
            case OID_IGD_XLTQFIREWALL_PF_PFR_ENABLE:
                /* Copy the string */
                if (strcmp(pxParamVal[iCnt].Value,"1")==0  || !strncasecmp(pxParamVal[iCnt].Value,"true",4))
                    xFirewallRule.enable = TRUE;
                else
                {
                    uiflags |= IFX_F_DONT_ACTIVATE;
                    xFirewallRule.enable = FALSE;
                }
                break;

            case OID_IGD_XLTQFIREWALL_PF_PFR_PROTOCOL:
                /* Copy the value to allocated area */
                xFirewallRule.protoType = atoi(pxParamVal[iCnt].Value);
                if (xFirewallRule.protoType!=IFX_MAPI_Protocol_AH||
                        xFirewallRule.protoType!=IFX_MAPI_Protocol_ESP||
                        xFirewallRule.protoType!=IFX_MAPI_Protocol_ICMP||
                        xFirewallRule.protoType!=IFX_MAPI_Protocol_TCP||
                        xFirewallRule.protoType!=IFX_MAPI_Protocol_UDP||
                        xFirewallRule.protoType!=IFX_MAPI_Protocol_ESP||
                        xFirewallRule.protoType!=IFX_MAPI_Protocol_ALL)
                    xFirewallRule.protoType=IFX_MAPI_Protocol_ALL;
                break;

            case OID_IGD_XLTQFIREWALL_PF_PFR_SOURCETYPE:
                xFirewallRule.srcType = atoi(pxParamVal[iCnt].Value);
                break;
            case OID_IGD_XLTQFIREWALL_PF_PFR_SOURCEIP:
                /* Copy the value to allocated area */
                temp = NULL;
                temp=strchr(pxParamVal[iCnt].Value,'/');
                if (temp != NULL && *temp!='\0')
                {
                    xFirewallRule.srcIP.mask.s_addr = bits2netmask(atoi((temp+1)));
                    *temp='\0';
                }
                inet_aton(pxParamVal[iCnt].Value,&(xFirewallRule.srcIP.ip));
                break;
            case OID_IGD_XLTQFIREWALL_PF_PFR_SOURCEMASK:
                inet_aton(pxParamVal[iCnt].Value,&(xFirewallRule.srcIP.mask));
                break;
            case OID_IGD_XLTQFIREWALL_PF_PFR_SOURCEPORTRANGE:
                /* Copy the value to allocated area */
                temp = NULL;
                temp=strchr(pxParamVal[iCnt].Value,':');
                if (temp != NULL&&*temp!='\0')
                {
                    xFirewallRule.sPortRange.end_port = atoi((temp+1));
                    *temp='\0';
                }
                xFirewallRule.sPortRange.start_port = atoi(pxParamVal[iCnt].Value);

                break;

            case OID_IGD_XLTQFIREWALL_PF_PFR_DESTTYPE:
                xFirewallRule.dstType = atoi(pxParamVal[iCnt].Value);
                break;
            case OID_IGD_XLTQFIREWALL_PF_PFR_DESTIP:
                /* Copy the value to allocated area */
                temp = NULL;
                temp=strchr(pxParamVal[iCnt].Value,'/');
                if (temp != NULL&&*temp!='\0')
                {
                    xFirewallRule.dstIP.mask.s_addr = bits2netmask(atoi((temp+1)));
                    *temp='\0';
                }

                inet_aton(pxParamVal[iCnt].Value,&(xFirewallRule.dstIP.ip));
                break;
            case OID_IGD_XLTQFIREWALL_PF_PFR_DESTMASK:
                inet_aton(pxParamVal[iCnt].Value,&(xFirewallRule.dstIP.mask));
                break;
            case OID_IGD_XLTQFIREWALL_PF_PFR_DESTPORTRANGE:
                /* Copy the value to allocated area */
                temp = NULL;
                temp=strchr(pxParamVal[iCnt].Value,':');
                if (temp != NULL&&*temp!='\0')
                {
                    xFirewallRule.dPortRange.end_port = atoi((temp+1));
                    *temp='\0';
                }

                xFirewallRule.dPortRange.start_port = atoi(pxParamVal[iCnt].Value);
                
                break;

            case OID_IGD_XLTQFIREWALL_PF_PFR_SOURCEMACADDRESS:
                /* Copy the value to allocated area */
                strcpy(xFirewallRule.sMacAddr, pxParamVal[iCnt].Value);
                break;

            case OID_IGD_XLTQFIREWALL_PF_PFR_INPUTINTERFACE:
                /* Copy the value to allocated area */

                if (!strcmp(pxParamVal[iCnt].Value,""))
                    break;
                else if (!strcmp(pxParamVal[iCnt].Value,"InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.IPInterface.1"))
                    strcpy(xFirewallRule.iif,"br0");
                else
                {
                    // convert the given interface to correct value and add to struct
                    memset(&xGetParam,0x00,sizeof(xGetParam));
                    xGetParam.Name = IFX_CWMP_MALLOC(strlen(pxParamVal[iCnt].Value)+8); // obj + name + dots
                    if (xGetParam.Name == NULL)
                    {
                        iRet = IFX_CWMP_FAILURE;
                        goto cleanup;
                    }

                    memset(caInterface,0,sizeof(caInterface));
                    strcpy(caInterface,pxParamVal[iCnt].Value);
                    if (caInterface[strlen(caInterface) -1]!='.')
                    {
                        strcat(caInterface, ".");
                    }

                    sprintf(xGetParam.Name,"%s%s",(char *)caInterface,"Name");

                    iRet = IFX_GlobalGetVal( &xGetParam, &paxGetParamVal, (uint32 *)&iElemOut);
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d]  IFX_GlobalGetVal failed\n", __func__ , __LINE__);
                        IFX_CWMP_FREE(xGetParam.Name);
                        if (paxGetParamVal != NULL)
                        {
                            IFX_CWMP_FREE(paxGetParamVal->Value);
                            IFX_CWMP_FREE(paxGetParamVal->Name);
                        }
                        IFX_CWMP_FREE(paxGetParamVal);
                        pxParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        goto cleanup;
                    }

                    if(strstr(pxParamVal[iCnt].Value,"WANPPPConnection") != NULL)
                    {
                        wan_type = WAN_TYPE_PPP;
                    } 
                    else
                    {
                        wan_type = WAN_TYPE_IP;
                    }     
                    iRet = ifx_get_wan_ifname_from_conf_connName(paxGetParamVal->Value, sIfName, wan_type);
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d]  ifx_get_wan_ifname_from_conf_connName failed\n", __func__ , __LINE__);
                        IFX_CWMP_FREE(xGetParam.Name);
                        IFX_CWMP_FREE(paxGetParamVal->Value);
                        IFX_CWMP_FREE(paxGetParamVal->Name);
                        IFX_CWMP_FREE(paxGetParamVal);

                        iRet = ERR_CWMP_INTERNAL;
                        pxParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        goto cleanup;
                    }

                    strncpy(xFirewallRule.iif,sIfName,15);
                    IFX_CWMP_FREE(xGetParam.Name);
                    IFX_CWMP_FREE(paxGetParamVal->Value);
                    IFX_CWMP_FREE(paxGetParamVal->Name);
                    IFX_CWMP_FREE(paxGetParamVal);
                }
                break;
            case OID_IGD_XLTQFIREWALL_PF_PFR_OUTPUTINTERFACE:
                /* Copy the value to allocated area */

                if (!strcmp(pxParamVal[iCnt].Value,""))
                    break;
                else if (!strcmp(pxParamVal[iCnt].Value,"InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.IPInterface.1"))
                    strcpy(xFirewallRule.oif,"br0");
                else
                {
                    // convert the given interface to correct value and add to struct
                    memset(&xGetParam,0x00,sizeof(xGetParam));
                    xGetParam.Name = IFX_CWMP_MALLOC(strlen(pxParamVal[iCnt].Value)+8); // obj + name + dots
                    if (xGetParam.Name == NULL)
                    {
                        iRet = IFX_CWMP_FAILURE;
                        goto cleanup;
                    }

                    memset(caInterface,0,sizeof(caInterface));
                    strcpy(caInterface,pxParamVal[iCnt].Value);
                    if (caInterface[strlen(caInterface) -1]!='.')
                    {
                        strcat(caInterface, ".");
                    }

                    sprintf(xGetParam.Name,"%s%s",(char *)caInterface,"Name");

                    iRet = IFX_GlobalGetVal( &xGetParam, &paxGetParamVal, (uint32 *)&iElemOut);
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d]  IFX_GlobalGetVal failed\n", __func__ , __LINE__);
                        IFX_CWMP_FREE(xGetParam.Name);
                        if (paxGetParamVal != NULL)
                        {
                            IFX_CWMP_FREE(paxGetParamVal->Value);
                            IFX_CWMP_FREE(paxGetParamVal->Name);
                        }
                        IFX_CWMP_FREE(paxGetParamVal);
                        pxParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        goto cleanup;
                    }

                    if(strstr(pxParamVal[iCnt].Value,"WANPPPConnection") != NULL)
                    {
                        wan_type = WAN_TYPE_PPP;
                    } 
                    else
                    {
                        wan_type = WAN_TYPE_IP;
                    }     
                    iRet = ifx_get_wan_ifname_from_conf_connName(paxGetParamVal->Value, sIfName, wan_type);
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s] [%d]  ifx_get_wan_ifname_from_conf_connName failed\n", __func__ , __LINE__);
                        IFX_CWMP_FREE(xGetParam.Name);
                        IFX_CWMP_FREE(paxGetParamVal->Value);
                        IFX_CWMP_FREE(paxGetParamVal->Name);
                        IFX_CWMP_FREE(paxGetParamVal);

                        iRet = ERR_CWMP_INTERNAL;
                        pxParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        goto cleanup;
                    }

                    strncpy(xFirewallRule.oif,sIfName,15);
                    IFX_CWMP_FREE(xGetParam.Name);
                    IFX_CWMP_FREE(paxGetParamVal->Value);
                    IFX_CWMP_FREE(paxGetParamVal->Name);
                    IFX_CWMP_FREE(paxGetParamVal);
                }
                break;
            default:
                pxParamVal[iCnt].iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
            }
        }
        /* Fill the iid structure in FIREWALL */
        xFirewallRule.iid.config_owner = pxOI->iCaller;
        uiflags = IFX_F_INT_ADD | IFX_F_DONT_CHECKPOINT;

        iRet = IFX_ConvertOidDottedForm(pxParamVal->iaOID, xFirewallRule.iid.tr69Id);
        if (iRet != IFX_CWMP_SUCCESS)
            goto cleanup;
        /* Set all the FIREWALL parameters using Object API */
        iRet = ifx_mapi_set_firewall_pfrule(IFX_OP_ADD, &xFirewallRule, uiflags);


    }
    else if (oper == OP_SETVAL_DELETE)
    {

        iRet = IFX_GetCpeId(pxParamVal->iaOID, &uiCpeid);
        if (iRet != IFX_CWMP_SUCCESS)
            goto cleanup;

        iRet = IFX_GetParentObjCpeId(pxParamVal->iaOID, &uiPcpeid);
        if (iRet != IFX_CWMP_SUCCESS)
            goto cleanup;

        xFirewallRule.iid.cpeId.Id = uiCpeid;
        xFirewallRule.iid.config_owner = pxOI->iCaller;
        xFirewallRule.iid.pcpeId.Id = uiPcpeid;

        /* Get all the FIREWALL parameter using Object API */
        iRet = ifx_mapi_get_firewall_pfrule(&xFirewallRule);
        /* Check for error */
        if (iRet != IFX_CWMP_SUCCESS)
        {
            iRet = ERR_CWMP_INTERNAL;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to get values of all "
                        "parameters\n",__FILE__,  __func__, __LINE__, iRet);
            goto cleanup;
        }
        uiflags |= IFX_F_DELETE|IFX_F_DONT_CHECKPOINT;
        /* Set all the FIREWALL parameters using Object API */
        iRet = ifx_mapi_set_firewall_pfrule(IFX_OP_DEL, &xFirewallRule, uiflags);

    }
    /* Check for error */
    if (iRet != IFX_SUCCESS)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to set values of all "
                    "parameters\n", __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    return (iRet);

}

/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS>
**
** =============================================================================
*/
/*
** =============================================================================
**   Function Name    : IFIN_Firewall
**
**   Description      : This function is called by the controller. It handles
**                      the FIREWALL object and performs  based on requested
**                      operations/suboperations by invoking internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            :
**
** =============================================================================
*/
int32
IFIN_Firewall(IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
              OUT void **ppRet, OUT int32 *piNumRetElem)
{
    int32       iRet           = IFX_CWMP_SUCCESS;
    ParamVal    *pxParamVal    = (ParamVal *)pParamList;
    uint32   iCnt = 0;

    /* Process based on type of Operation */
    switch (pxOI->iOper)
    {
    case OP_GETVAL:
    {
        /* Process based on type of SubOperation */
        switch (pxOI->iSubOper)
        {
        case OP_GETVAL_NORMAL:
        case OP_GETVAL_NOTIFICATION:
            /* Get values of all the requested parameters */
            iRet = IFIN_Firewall_GetValue(pxOI, pxParamVal, iNumElem);
            /* Check for error */
            if (iRet != IFX_CWMP_SUCCESS)
            {
                goto cleanup;
            }
            break;
        default:
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid SubOperation\n",
                        __func__, __LINE__, iRet);
            goto cleanup;
        }
        break;
    }
    case OP_SETVAL:
    {
        /* Process based on type of SubOperation */
        switch (pxOI->iSubOper)
        {
        case OP_SETVAL_MODIFY:
            /* Set values of all the requested parameters */
            iRet = IFIN_Firewall_Modify(pxOI, pxParamVal, iNumElem);
            /* Check for error */
            if (iRet != IFX_CWMP_SUCCESS)
            {
                goto cleanup;
            }
            break;
        case OP_SETVAL_ATTRINFO:
            /* Set attribute values for all the requested parameters */
            iRet = IFIN_Firewall_SetAttrInfo(pxOI, pParamList,
                                             iNumElem);
            if (iRet != IFX_CWMP_SUCCESS)
                goto cleanup;
            break;
        case OP_SETVAL_FREE:
        case OP_SETVAL_VALIDATE:
        case OP_SETVAL_CHK_MODIFY_DEP:
            break;
        default:
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid SubOperation\n",
                        __func__, __LINE__, iRet);
            goto cleanup;
        }
        break;
    }
    case OP_PARAM_VALIDATE:
    {
        /*Vendor specific parameters should not be reported to ACS. It 
          should be available for internal updation */
        if(pxOI->iCaller == ACC_TR69)
        {
            /* Set the fault code to Error */
            for(iCnt = 0; iCnt < iNumElem; iCnt++)
            {
                pxParamVal[iCnt].iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
            }
        }
        break; 
    }
    default:
    {
        iRet = ERR_CWMP_INVAL_OPER;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Invalid Operation\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }
    }

cleanup:
    return (iRet);
}


/*
** =============================================================================
**   Function Name    : IFIN_Firewall_PF
**
**   Description      : This function is called by the controller. It handles
**                      the FIREWALL object and performs  based on requested
**                      operations/suboperations by invoking internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            :
**
** =============================================================================
*/
int32
IFIN_Firewall_PF(IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
                 OUT void **ppRet, OUT int32 *piNumRetElem)
{
    int32       iRet           = IFX_CWMP_SUCCESS;
    ParamVal    *pxParamVal    = (ParamVal *)pParamList;
    uint32   iCnt = 0;

    /* Process based on type of Operation */
    switch (pxOI->iOper)
    {
    case OP_GETVAL:
    {
        /* Process based on type of SubOperation */
        switch (pxOI->iSubOper)
        {
        case OP_GETVAL_NORMAL:
        case OP_GETVAL_NOTIFICATION:
            /* Get values of all the requested parameters */
            iRet = IFIN_Firewall_PF_GetValue(pxOI, pxParamVal, iNumElem);
            /* Check for error */
            if (iRet != IFX_CWMP_SUCCESS)
            {
                goto cleanup;
            }
            break;
        default:
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid SubOperation\n",
                        __func__, __LINE__, iRet);
            goto cleanup;
        }
        break;
    }
    case OP_SETVAL:
    {
        /* Process based on type of SubOperation */
        switch (pxOI->iSubOper)
        {
        case OP_SETVAL_MODIFY:
            /* Set values of all the requested parameters */
            iRet = IFIN_Firewall_PF_Modify(pxOI, pxParamVal, iNumElem);
            /* Check for error */
            if (iRet != IFX_CWMP_SUCCESS)
            {
                goto cleanup;
            }
            break;
        case OP_SETVAL_ATTRINFO:
            /* Set attribute values for all the requested parameters */
            iRet = IFIN_Firewall_PF_SetAttrInfo(pxOI, pParamList,
                                                iNumElem);
            if (iRet != IFX_CWMP_SUCCESS)
                goto cleanup;
            break;
        case OP_SETVAL_FREE:
        case OP_SETVAL_VALIDATE:
        case OP_SETVAL_CHK_MODIFY_DEP:
            break;
        default:
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid SubOperation\n",
                        __func__, __LINE__, iRet);
            goto cleanup;
        }
        break;
    }
    case OP_UPDATE_CHILDINFO:
    {
        /* Process based on type of SubOperation */
        switch (pxOI->iSubOper)
        {
        case OP_UPDATE_CHILDINFO_ADD:
        case OP_UPDATE_CHILDINFO_DEL:
            if ((iRet =IFIN_Firewall_PF_UpdateChildInfo(pxOI,pxParamVal,iNumElem)) != IFX_CWMP_SUCCESS)
            {
                switch (pxOI->iSubOper)
                {
                case OP_UPDATE_CHILDINFO_ADD:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d OP_UPDATE_CHILDINFO_ADD failed!\n", __func__, __LINE__);
                    goto cleanup;

                case OP_UPDATE_CHILDINFO_DEL:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d OP_UPDATE_CHILDINFO_DEL failed!\n", __func__, __LINE__);
                    goto cleanup;

                }
            }
            break;
        default:
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid SubOperation\n",
                        __func__, __LINE__, iRet);
            goto cleanup;
        }
        break;
    }
    case OP_PARAM_VALIDATE:
    {
        /*Vendor specific parameters should not be reported to ACS. It 
          should be available for internal updation */
        if(pxOI->iCaller == ACC_TR69)
        {
            /* Set the fault code to Error */
            for(iCnt = 0; iCnt < iNumElem; iCnt++)
            {
                pxParamVal[iCnt].iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
            }
        }
        break;
    }
    default:
        iRet = ERR_CWMP_INVAL_OPER;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Invalid Operation\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    return (iRet);
}

/*
** =============================================================================
**   Function Name    : IFIN_Firewall_PFRule
**
**   Description      : This function is called by the controller. It handles
**                      the FirewallRule object and performs  based on requested
**                      operations/suboperations by invoking internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            :
**
** =============================================================================
*/
int32
IFIN_Firewall_PFRule(IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
                     OUT void **ppRet, OUT int32 *piNumRetElem)
{
    int32       iRet           = IFX_CWMP_SUCCESS;
    ParamVal    *pxParamVal    = (ParamVal *)pParamList;
    ParamVal    *pxVal;
    uint32 uiParamPos=0;
    uint32   iCnt = 0;

    /* Process based on type of Operation */
    switch (pxOI->iOper)
    {
    case OP_GETVAL:
    {
        /* Process based on type of SubOperation */
        switch (pxOI->iSubOper)
        {
        case OP_GETVAL_NORMAL:
        case OP_GETVAL_NOTIFICATION:

            /* Get values of all the requested parameters */
            iRet = IFIN_Firewall_PFRule_GetValue(pxOI, pxParamVal, iNumElem);

            /* Check for error */
            if (iRet != IFX_CWMP_SUCCESS)
            {
                goto cleanup;
            }

            break;
        default:
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid SubOperation\n",
                        __func__, __LINE__, iRet);
            goto cleanup;
        }
        break;
    }
    case OP_SETVAL:
    {
        /* Process based on type of SubOperation */
        switch (pxOI->iSubOper)
        {
        case OP_SETVAL_ADD:
            /*Add the new rules*/
            iRet = IFIN_Firewall_PFRule_AddDel(pxOI, pxParamVal, iNumElem, OP_SETVAL_ADD);
            /* Check for error */
            if (iRet != IFX_CWMP_SUCCESS)
            {
                goto cleanup;
            }
            break;
        case OP_SETVAL_DELETE:
            /*Delete the given rules*/
            iRet = IFIN_Firewall_PFRule_AddDel(pxOI, pxParamVal, iNumElem, OP_SETVAL_DELETE);
            /* Check for error */
            if (iRet != IFX_CWMP_SUCCESS)
            {
                goto cleanup;
            }
            break;
        case OP_SETVAL_MODIFY:
            /* Set values of all the requested parameters */
            iRet = IFIN_Firewall_PFRule_Modify(pxOI, pxParamVal, iNumElem);

            /* Check for error */
            if (iRet != IFX_CWMP_SUCCESS)
            {
                goto cleanup;
            }
            break;
        case OP_SETVAL_ATTRINFO:
            iRet =
                IFIN_Firewall_PFRule_SetAttrInfo(pxOI, pParamList,
                                                 iNumElem);
            if (iRet != IFX_CWMP_SUCCESS)
                goto cleanup;
            break;
        case OP_SETVAL_CHK_DEL_DEP:
            pxVal= (void *)IFX_CWMP_MALLOC (sizeof(ParamVal));
            uiParamPos = IFX_GetParamIdPos(pxParamVal->iaOID);
            memcpy(pxVal->iaOID,pxParamVal->iaOID,(sizeof(int32)*(uiParamPos+1)));
            *ppRet = (void*) pxVal;
            *piNumRetElem = 1;
        case OP_SETVAL_CHK_DEL_ALLOWED:
            return IFX_CWMP_SUCCESS;
        case OP_SETVAL_FREE:
        case OP_SETVAL_VALIDATE:
        case OP_SETVAL_CHK_MODIFY_DEP:
            break;
        default:
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid SubOperation\n",
                        __func__, __LINE__, iRet);
            goto cleanup;
        }
    }
    case OP_UPDATE_CHILDINFO:
    {
        break;
    }
    case OP_PARAM_VALIDATE:
    {
        /*Vendor specific parameters should not be reported to ACS. It 
          should be available for internal updation */
        if(pxOI->iCaller == ACC_TR69)
        {
            /* Set the fault code to Error */
            for(iCnt = 0; iCnt < iNumElem; iCnt++)
            {
                pxParamVal[iCnt].iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
            }
        }
        break;
    }

    default:
    {
        iRet = ERR_CWMP_INVAL_OPER;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Invalid Operation\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }
    }

cleanup:
    return (iRet);
}



/*
** =============================================================================
**   Function Name    : IFIN_FIREWALL_PF_Init
**
**   Description      : This function is called by the controller. It registers
**                      the function responsible for handling X_INFINEON_COM_FIREWALL object
**                      with data structure. It also performs initializations
**                      specific to X_INFINEON_COM_FIREWALL object.
**
**   Parameters       : No Parameters.
**
**   Return Value     : IFX_CWMP_SUCCESS - When FIREWALL object is initialized
**                      successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in initializing X_INFINEON_COM_FIREWALL object.
**   Notes            :
**
** =============================================================================
*/
int32
IFX_Firewall_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the FIREWALL module function pointer in the object model */
    iRet += ifx_ds_register_function(IFIN_FIREWALL_OBJ, IFIN_Firewall);
    iRet += ifx_ds_register_function(IFIN_FIREWALL_PF_OBJ, IFIN_Firewall_PF);
    iRet += ifx_ds_register_function(IFIN_FIREWALL_PF_RULE_OBJ, IFIN_Firewall_PFRule);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFIN_FIREWALL_OBJ);
        goto cleanup;
    }

cleanup:
    return iRet;
}
