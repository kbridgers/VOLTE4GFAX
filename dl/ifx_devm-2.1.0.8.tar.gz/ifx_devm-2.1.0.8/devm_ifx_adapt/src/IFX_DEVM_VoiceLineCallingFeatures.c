/* 
** =============================================================================
**   FILE NAME        : IFX_VoiceLineCallingFeatures
**   PROJECT          : TR104
**   MODULES          : IFX_VoiceLineCallingFeatures
**   DATE             : 23-11-2006
**   AUTHOR           : TR104 team
**   DESCRIPTION   :

**   REFERENCES      : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2004
**                   	      Infineon Technologies AG, st. Martin Strasse 53;
**                   	      81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/


/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "ifx_vmapi_common.h"
#include "IFX_DEVM_VoiceLine.h"
  // Required for STATIC
 
#include "IFX_DEVM_OID.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
 
#include "IFX_DEVM_DS.h"

//#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

int32
IFX_VoiceLineCallingFeatures(IN OperInfo * pxOI, INOUT void *pParamList,
                             IN int32 iNumElem, OUT void **ppRet,
                             OUT int32 * piNumRetElem);

#define VOICE_CAP_DEV_DEPTH 3
/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFX_VOICELINE_CALLFEATURES_OBJ "InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.1.Line.1.CallingFeatures."


/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/
STATIC int32
GetVal(IN int32 iCaller, INOUT ParamVal *pxParamVal,
                    IN int32 iElements);
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
GetModifyDep(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
GetNotify(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
                 IN int32 iElements);
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);
/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetVal(IN int32 iCaller, INOUT ParamVal *pxParamVal,
                    IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iRtn = IFX_SUCCESS;
    int32   iCnt = 0;
    int32   iTmpCnt = -1; /* Mandatory */
    int32   iParamOffset;
    int32   iOID;
    int32   iMemErrorFlag = 0; /* Mandatory */
    x_IFX_VMAPI_LineCallingFeatures xVLCallingFeatures;
    uint32 uiPCpeId;

    /* NOTE: For all parameters fault code is set to success by default. If error in
       validating first parameter, fault code is set to the error type and other
       parameters are not validated. */
    /* NOTE: For all parameters value is set to NULL by default. */

    /* Set the fault code to Success and value to NULL pointer for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);

    memset(&xVLCallingFeatures, 0, sizeof(x_IFX_VMAPI_LineCallingFeatures));

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_L_CF:{

            char8 sOidString[100] = {0};
            IFX_CpeId *pxCpeIdArray = NULL;
            unsigned int uiNumCpeId;

            /* Get the Parent CPE Id */
            IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT &uiPCpeId);
            xVLCallingFeatures.iid.pcpeId.Id = uiPCpeId;

            /*ignore the last value as it will be a parameter and we need 
              only till the last instance*/
            iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );

            strcpy(xVLCallingFeatures.iid.tr69Id,sOidString);

            /*Get the CPE Id from the corresponding tr69 Id */
            iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId,
                               OUT &pxCpeIdArray);
            if(iRet != IFX_CWMP_SUCCESS){
                   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                   __func__, __LINE__);

              return ERR_CWMP_INTERNAL;
            }
            //printf("CPEID is %d\n",pxCpeIdArray->uiId);   

            /* Fill the CPE ID of the object instance */
            xVLCallingFeatures.iid.cpeId.Id = pxCpeIdArray->uiId;
            xVLCallingFeatures.iid.config_owner = IFX_TR69;

            /* Get all the Line Calling Feature parameters using VMAPI */
            iRtn = ifx_get_LineCallingFeatures(&xVLCallingFeatures, 
                                                    IFX_F_DEFAULT);

            IFX_CWMP_FREE(pxCpeIdArray);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to get values of all "
                            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto cleanup;
            }
            }
            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
    case OID_IGD_S_VS_VP_L_CF_CALLERIDENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);

               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.bEnableCid ==  IFX_TR104_FALSE)
                 strcpy((pxParamVal[iCnt]).Value, "false");
               else if(xVLCallingFeatures.bEnableCid == IFX_TR104_TRUE)
                 strcpy((pxParamVal[iCnt]).Value, "true");

            break;  
          case OID_IGD_S_VS_VP_L_CF_CALLERIDNAMEENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(10);
 
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.bEnableCidName ==  IFX_TR104_FALSE)
                 strcpy((pxParamVal[iCnt]).Value, "false");
               else if(xVLCallingFeatures.bEnableCidName == IFX_TR104_TRUE)
                 strcpy((pxParamVal[iCnt]).Value, "true");
            break; 
          case OID_IGD_S_VS_VP_L_CF_CALLERIDNAME:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                strlen(xVLCallingFeatures.acCidName) + 1);

               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }

               /* Copy the value to allocated area */
               strcpy((pxParamVal[iCnt]).Value, 
                         xVLCallingFeatures.acCidName); 
            break;  
          case OID_IGD_S_VS_VP_L_CF_CALLWAITINGENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);

               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.bEnableCallWaiting ==  IFX_TR104_FALSE)
                 strcpy((pxParamVal[iCnt]).Value, "false");
               else if(xVLCallingFeatures.bEnableCallWaiting == IFX_TR104_TRUE)
                 strcpy((pxParamVal[iCnt]).Value, "true");
            break; 
          case OID_IGD_S_VS_VP_L_CF_CALLWAITINGSTATUS:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(20);

               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.ucCallWaitStatus == 
                                 IFX_VMAPI_CALL_STATUS_DISABLED )
                 strcpy((pxParamVal[iCnt]).Value, "Disabled");
               else if(xVLCallingFeatures.ucCallWaitStatus == 
                                 IFX_VMAPI_CALL_STATUS_IDLE)
                 strcpy((pxParamVal[iCnt]).Value, "Idle");
               else if(xVLCallingFeatures.ucCallWaitStatus == 
                                 IFX_VMAPI_CALL_STATUS_SEC_CONNECTING)
                 strcpy((pxParamVal[iCnt]).Value, "SecondaryConnecting");
               else if(xVLCallingFeatures.ucCallWaitStatus == 
                                 IFX_VMAPI_CALL_STATUS_SEC_CONNECTED)
                 strcpy((pxParamVal[iCnt]).Value, "SecondaryConnected");
               else if(xVLCallingFeatures.ucCallWaitStatus == 
                                 IFX_VMAPI_CALL_STATUS_RINGING)
                 strcpy((pxParamVal[iCnt]).Value, "SecondaryRinging");
            break;
          case OID_IGD_S_VS_VP_L_CF_MAXSESSIONS:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                              sizeof(uchar8));

               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }

               /* Copy the value to allocated area */
               sprintf((pxParamVal[iCnt]).Value, "%d", 
                         xVLCallingFeatures.ucMaxConfSessions); 
            break;  
          case OID_IGD_S_VS_VP_L_CF_CONFERENCECALLINGSTATUS:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(20);

               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.ucConfCallStatus ==  
                                  IFX_VMAPI_CALL_STATUS_DISABLED)
                 strcpy((pxParamVal[iCnt]).Value, "Disabled");
               else if(xVLCallingFeatures.ucConfCallStatus == 
                                  IFX_VMAPI_CALL_STATUS_IDLE)
                 strcpy((pxParamVal[iCnt]).Value, "Idle");
               else if(xVLCallingFeatures.ucConfCallStatus == 
                                 IFX_VMAPI_CALL_STATUS_SEC_CONNECTING)
                 strcpy((pxParamVal[iCnt]).Value, "SecondaryConnecting");
               else if(xVLCallingFeatures.ucConfCallStatus == 
                                 IFX_VMAPI_CALL_STATUS_SEC_CONNECTED)
                 strcpy((pxParamVal[iCnt]).Value, "SecondaryConnected");
               else if(xVLCallingFeatures.ucConfCallStatus == 
                                 IFX_VMAPI_CALL_STATUS_SEC_CALLING)
                 strcpy((pxParamVal[iCnt]).Value, "SecondaryCalling");
               else if(xVLCallingFeatures.ucConfCallStatus == 
                                 IFX_VMAPI_CALL_STATUS_IN_CONF)
                 strcpy((pxParamVal[iCnt]).Value, "InConferenceCall");
            break;
          case OID_IGD_S_VS_VP_L_CF_CONFERENCECALLINGSESSIONCOUNT:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                         sizeof(uchar8) );

               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }

               /* Copy the value to allocated area */
               sprintf((pxParamVal[iCnt]).Value, "%d", 
                         xVLCallingFeatures.ucConfCallSessionCount); 
            break; 
          case OID_IGD_S_VS_VP_L_CF_CALLFORWARDUNCONDITIONALENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.unCallFwdCfg &  
                                 IFX_VMAPI_CALL_FWD_UNCONDITIONAL)
                 strcpy((pxParamVal[iCnt]).Value, "true");
               else 
                 strcpy((pxParamVal[iCnt]).Value, "false");

            break;
          case OID_IGD_S_VS_VP_L_CF_CALLFORWARDUNCONDITIONALNUMBER:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                         strlen(xVLCallingFeatures.xCfuAddress.acUserName) + 1);

               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }

               /* Copy the value to allocated area */
               strcpy((pxParamVal[iCnt]).Value, 
                         xVLCallingFeatures.xCfuAddress.acUserName); 
            break;
          case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONBUSYENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.unCallFwdCfg & 
                                 IFX_VMAPI_CALL_FWD_BUSY )
                 strcpy((pxParamVal[iCnt]).Value, "true");
               else
                 strcpy((pxParamVal[iCnt]).Value, "false");

            break;
          case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONBUSYNUMBER:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                         strlen(xVLCallingFeatures.xCfbAddress.acUserName) + 1);

               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }

               /* Copy the value to allocated area */
               strcpy((pxParamVal[iCnt]).Value, 
                         xVLCallingFeatures.xCfbAddress.acUserName); 
            break;
          case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONNOANSWERENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.unCallFwdCfg &  
                                  IFX_VMAPI_CALL_FWD_ON_NO_ANSWER)
                 strcpy((pxParamVal[iCnt]).Value, "true");
               else
                 strcpy((pxParamVal[iCnt]).Value, "false");

            break;
          case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONNOANSWERNUMBER:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                        strlen(xVLCallingFeatures.xCfnaAddress.acUserName) + 1);

               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }

               /* Copy the value to allocated area */
               strcpy((pxParamVal[iCnt]).Value, 
                         xVLCallingFeatures.xCfnaAddress.acUserName); 
            break;
          case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONNOANSWERRINGCOUNT:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                              sizeof(uchar8));

               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }

               /* Copy the value to allocated area */
               sprintf((pxParamVal[iCnt]).Value, "%d", 
                         xVLCallingFeatures.ucCfnaRingCount); 
            break;
          case OID_IGD_S_VS_VP_L_CF_CALLTRANSFERENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.bEnableCallTransfer == IFX_TR104_FALSE)
                 strcpy((pxParamVal[iCnt]).Value, "false");
               else if(xVLCallingFeatures.bEnableCallTransfer == IFX_TR104_TRUE)
                 strcpy((pxParamVal[iCnt]).Value, "true");

            break;
          case OID_IGD_S_VS_VP_L_CF_MWIENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.bEnableMwiIndication == IFX_TR104_FALSE)
                 strcpy((pxParamVal[iCnt]).Value, "false");
               else if(xVLCallingFeatures.bEnableMwiIndication == IFX_TR104_TRUE)
                 strcpy((pxParamVal[iCnt]).Value, "true");

            break;
          case OID_IGD_S_VS_VP_L_CF_MESSAGEWAITING:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.bIsMsgWaiting == IFX_TR104_TRUE)
                 strcpy((pxParamVal[iCnt]).Value, "true");
               else if(xVLCallingFeatures.bIsMsgWaiting == IFX_TR104_FALSE)
                 strcpy((pxParamVal[iCnt]).Value, "false");

            break;
          case OID_IGD_S_VS_VP_L_CF_ANONYMOUSCALLBLOCKENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.bEnableAcb == IFX_TR104_FALSE)
                 strcpy((pxParamVal[iCnt]).Value, "false");
               else if(xVLCallingFeatures.bEnableAcb == IFX_TR104_TRUE)
                 strcpy((pxParamVal[iCnt]).Value, "true");

            break;
          case OID_IGD_S_VS_VP_L_CF_DONOTDISTURBENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.bEnableDnd == IFX_TR104_FALSE)
                 strcpy((pxParamVal[iCnt]).Value, "false");
               else if(xVLCallingFeatures.bEnableDnd == IFX_TR104_TRUE)
                 strcpy((pxParamVal[iCnt]).Value, "true");

            break;
          case OID_IGD_S_VS_VP_L_CF_CALLRETURNENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.bEnableCallRet == IFX_TR104_FALSE)
                 strcpy((pxParamVal[iCnt]).Value, "false");
               else if(xVLCallingFeatures.bEnableCallRet == IFX_TR104_TRUE)
                 strcpy((pxParamVal[iCnt]).Value, "true");

            break;
          case OID_IGD_S_VS_VP_L_CF_REPEATDIALENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.bEnableRepeatDial ==  IFX_TR104_FALSE)
                 strcpy((pxParamVal[iCnt]).Value, "false");
               else if(xVLCallingFeatures.bEnableRepeatDial == IFX_TR104_TRUE)
                 strcpy((pxParamVal[iCnt]).Value, "true");

            break;
          case OID_IGD_S_VS_VP_L_CF_ANONYMOUSCALENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.bEnableCidName ==  IFX_TR104_FALSE)
                 strcpy((pxParamVal[iCnt]).Value, "true");
               else if(xVLCallingFeatures.bEnableCidName == IFX_TR104_TRUE)
                 strcpy((pxParamVal[iCnt]).Value, "false");
            break;
          default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                iTmpCnt = iCnt;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
            goto cleanup;
        }
    }

cleanup:

    if (iMemErrorFlag)
    {
        (pxParamVal[iCnt]).iFaultCode = ERR_OUT_OF_MEMORY;
        iRet = ERR_OUT_OF_MEMORY;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Allocation Failure\n",
                     __FILE__, __func__, __LINE__, iRet);
    }

    if (iRet != IFX_CWMP_SUCCESS)
    {

        /* Free the allocation for value, if any. Also set the fault code. */
        for (iCnt = 0; iCnt < iElements; iCnt++)
        {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
            if (iTmpCnt != iCnt) 
            {
                (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
            }
        }
    }

    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : Modify
**
**   Description      : This function modifies the values of parameters in 
**                      LineCallingFeatures object. It calls respective VMAPI  
**                      for the same. It performs modification only if parameter 
**                      has Write permission. In certain cases it also performs 
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxSetParamVal, IN int32 iElements)
{
    int32   iRet         = IFX_CWMP_SUCCESS;
    int32   iRtn         = IFX_SUCCESS;
    int32   iCnt         = 0;
    int32   iParamOffset;
    int32   iOID;
    x_IFX_VMAPI_LineCallingFeatures xVLCallingFeatures;
    uint32 uiPCpeId;

    /* NOTE: For all parameters fault code is set to success by default. If error in
       validating first parameter, fault code is set to the error type and other
       parameters are not validated. */

    /* Set the fault code to Success for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxSetParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
    }

    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxSetParamVal->iaOID);

    memset(&xVLCallingFeatures, 0, sizeof(x_IFX_VMAPI_LineCallingFeatures));

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_L_CF:{

            char8 sOidString[100] = {0};
            IFX_CpeId *pxCpeIdArray = NULL;
            unsigned int uiNumCpeId;

            /* Get the Parent CPE Id */
            IFX_GetParentObjCpeId(IN pxSetParamVal->iaOID, OUT &uiPCpeId);
            xVLCallingFeatures.iid.pcpeId.Id = uiPCpeId;

            /*ignore the last value as it will be a parameter and we need 
              only till the last instance*/
            iRet = IFX_GetOIDArrayTillLastInst(pxSetParamVal->iaOID ,sOidString );

            strcpy(xVLCallingFeatures.iid.tr69Id,sOidString);

            /*Get the CPE Id from the corresponding tr69 Id */
            iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId,
                               OUT &pxCpeIdArray);
            if(iRet != IFX_CWMP_SUCCESS){
                   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                   __func__, __LINE__);

              return ERR_CWMP_INTERNAL;
            }
            //printf("CPEID is %d\n",pxCpeIdArray->uiId);   

            /* Fill the CPE ID of the object instance */
            xVLCallingFeatures.iid.cpeId.Id = pxCpeIdArray->uiId;
            xVLCallingFeatures.iid.config_owner = IFX_TR69;

            /* Get all the Line Calling Feature parameters using VMAPI */
            iRtn = ifx_get_LineCallingFeatures(&xVLCallingFeatures, 
                                                    IFX_F_DEFAULT);

            IFX_CWMP_FREE(pxCpeIdArray);

            if (iRtn != IFX_CWMP_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxSetParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to get values of all "
                            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto cleanup;
            }
            }
            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxSetParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxSetParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_S_VS_VP_L_CF_CALLERIDENABLE:
              if((!strncasecmp(pxSetParamVal[iCnt].Value,"true",4))||
                       atoi(pxSetParamVal[iCnt].Value) == 1)
                  xVLCallingFeatures.bEnableCid = IFX_TR104_TRUE; 
              else if((!strncasecmp(pxSetParamVal[iCnt].Value,"false",5)) ||
                       atoi(pxSetParamVal[iCnt].Value) == 0)
                  xVLCallingFeatures.bEnableCid = IFX_TR104_FALSE; 
             
              break;
            case OID_IGD_S_VS_VP_L_CF_CALLERIDNAMEENABLE:
              /* Copy the string */
              if((!strncasecmp(pxSetParamVal[iCnt].Value,"true",4))||
                       atoi(pxSetParamVal[iCnt].Value) == 1)
                  xVLCallingFeatures.bEnableCidName = IFX_TR104_TRUE; 
              else if((!strncasecmp(pxSetParamVal[iCnt].Value,"false",5)) ||
                       atoi(pxSetParamVal[iCnt].Value) == 0)
                  xVLCallingFeatures.bEnableCidName = IFX_TR104_FALSE; 

              break;
            case OID_IGD_S_VS_VP_L_CF_CALLERIDNAME:
                  /* Check if the string fits in the buffer */
                  if ((strlen((pxSetParamVal[iCnt]).Value) + 1) > 
                                       IFX_MAX_USR_NAME)
                  {
                    (pxSetParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_BUFFER_OVERFLOW;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                  }

                  /* Copy the string */
                  strncpy(xVLCallingFeatures.acCidName, (pxSetParamVal[iCnt]).Value,(IFX_VMAPI_MAX_USER_NAME_LEN-1));
              break;
            case OID_IGD_S_VS_VP_L_CF_CALLWAITINGENABLE:
              /* Copy the string */
              if((!strncasecmp(pxSetParamVal[iCnt].Value,"true",4))||
                       atoi(pxSetParamVal[iCnt].Value) == 1)
                  xVLCallingFeatures.bEnableCallWaiting = IFX_TR104_TRUE; 
              else if((!strncasecmp(pxSetParamVal[iCnt].Value,"false",5)) ||
                       atoi(pxSetParamVal[iCnt].Value) == 0)
                  xVLCallingFeatures.bEnableCallWaiting = IFX_TR104_FALSE; 
              break;
            case OID_IGD_S_VS_VP_L_CF_CALLWAITINGSTATUS:
              /* Copy the string */
              if(!strncasecmp(pxSetParamVal[iCnt].Value,"Disabled",8))
                  xVLCallingFeatures.ucCallWaitStatus = 
                                        IFX_VMAPI_CALL_STATUS_DISABLED; 
              else if(!strncasecmp(pxSetParamVal[iCnt].Value,"Idle",4))
                  xVLCallingFeatures.ucCallWaitStatus = 
                                        IFX_VMAPI_CALL_STATUS_IDLE; 
              else if(!strncasecmp(pxSetParamVal[iCnt].Value,
                                                  "SecondaryRinging",16))
                  xVLCallingFeatures.ucCallWaitStatus = 
                                        IFX_VMAPI_CALL_STATUS_RINGING; 
              else if(!strncasecmp(pxSetParamVal[iCnt].Value,
                                                  "SecondaryConnecting",19))
                  xVLCallingFeatures.ucCallWaitStatus = 
                                        IFX_VMAPI_CALL_STATUS_SEC_CONNECTING; 
              else if(!strncasecmp(pxSetParamVal[iCnt].Value,
                                                  "SecondaryConnected",18))
                  xVLCallingFeatures.ucCallWaitStatus = 
                                        IFX_VMAPI_CALL_STATUS_SEC_CONNECTED; 

              break;
            case OID_IGD_S_VS_VP_L_CF_MAXSESSIONS:
                /* Copy the string */
                xVLCallingFeatures.ucMaxConfSessions=
                                 atoi((pxSetParamVal[iCnt]).Value);
              break;
            case OID_IGD_S_VS_VP_L_CF_CONFERENCECALLINGSTATUS:
              /* Copy the string */
              if(!strncasecmp(pxSetParamVal[iCnt].Value,"Disabled",8))
                  xVLCallingFeatures.ucConfCallStatus = 
                                        IFX_VMAPI_CALL_STATUS_DISABLED; 
              else if(!strncasecmp(pxSetParamVal[iCnt].Value,"Idle",4))
                  xVLCallingFeatures.ucConfCallStatus = 
                                        IFX_VMAPI_CALL_STATUS_IDLE; 
              else if(!strncasecmp(pxSetParamVal[iCnt].Value,
                                                  "SecondaryCalling",16))
                  xVLCallingFeatures.ucConfCallStatus = 
                                        IFX_VMAPI_CALL_STATUS_SEC_CALLING; 
              else if(!strncasecmp(pxSetParamVal[iCnt].Value,
                                                  "SecondaryConnecting",19))
                  xVLCallingFeatures.ucConfCallStatus = 
                                        IFX_VMAPI_CALL_STATUS_SEC_CONNECTING; 
              else if(!strncasecmp(pxSetParamVal[iCnt].Value,
                                                  "SecondaryConnected",18))
                  xVLCallingFeatures.ucConfCallStatus = 
                                        IFX_VMAPI_CALL_STATUS_SEC_CONNECTED; 
              else if(!strncasecmp(pxSetParamVal[iCnt].Value,
                                                  "InConferenceCall",16))
                  xVLCallingFeatures.ucConfCallStatus = 
                                        IFX_VMAPI_CALL_STATUS_IN_CONF; 

              break;
            case OID_IGD_S_VS_VP_L_CF_CONFERENCECALLINGSESSIONCOUNT:
                  /* Copy the value */
                  xVLCallingFeatures.ucConfCallSessionCount=
                                    atoi((pxSetParamVal[iCnt]).Value);
              break;
            case OID_IGD_S_VS_VP_L_CF_CALLFORWARDUNCONDITIONALENABLE:
              /* Copy the string */
              if((!strncasecmp(pxSetParamVal[iCnt].Value,"true",4)) ||
                       atoi(pxSetParamVal[iCnt].Value) == 1)
    xVLCallingFeatures.unCallFwdCfg |= 
                                      IFX_VMAPI_CALL_FWD_UNCONDITIONAL; 
              else if((!strncasecmp(pxSetParamVal[iCnt].Value,"false",5)) ||
                       atoi(pxSetParamVal[iCnt].Value) == 0)
    xVLCallingFeatures.unCallFwdCfg &= 
                                      ~IFX_VMAPI_CALL_FWD_UNCONDITIONAL; 

              break;
            case OID_IGD_S_VS_VP_L_CF_CALLFORWARDUNCONDITIONALNUMBER:
                  /* Check if the string fits in the buffer */
                  if ((strlen((pxSetParamVal[iCnt]).Value) + 1) >
                                               IFX_VMAPI_MAX_TRANS_ADDR_LEN)
                  {
                    (pxSetParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_BUFFER_OVERFLOW;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                  }

                  /* Copy the string */
                  strncpy(xVLCallingFeatures.xCfuAddress.acUserName, (pxSetParamVal[iCnt]).Value, (IFX_VMAPI_MAX_USER_NAME_LEN-1));
                  xVLCallingFeatures.xCfuAddress.ucAddrType = IFX_VMAPI_ADDR_TYPE_TEL_NUM;
              break;
            case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONBUSYENABLE:
              /* Copy the string */
              if((!strncasecmp(pxSetParamVal[iCnt].Value,"true",4)) ||
                       atoi(pxSetParamVal[iCnt].Value) == 1)
                  xVLCallingFeatures.unCallFwdCfg |= 
                                      IFX_VMAPI_CALL_FWD_BUSY; 
              else if((!strncasecmp(pxSetParamVal[iCnt].Value,"false",5)) ||
                       atoi(pxSetParamVal[iCnt].Value) == 0)
                  xVLCallingFeatures.unCallFwdCfg &= 
                                      ~IFX_VMAPI_CALL_FWD_BUSY; 

              break;
            case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONBUSYNUMBER:
                  /* Check if the string fits in the buffer */
                  if ((strlen((pxSetParamVal[iCnt]).Value) + 1) >
                                               IFX_VMAPI_MAX_TRANS_ADDR_LEN)
                  {
                    (pxSetParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_BUFFER_OVERFLOW;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                  }

                  /* Copy the string */
                  strncpy(xVLCallingFeatures.xCfbAddress.acUserName, (pxSetParamVal[iCnt]).Value,(IFX_VMAPI_MAX_USER_NAME_LEN-1));
                  xVLCallingFeatures.xCfbAddress.ucAddrType = IFX_VMAPI_ADDR_TYPE_TEL_NUM;
              break;
            case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONNOANSWERENABLE:
              /* Copy the string */
              if((!strncasecmp(pxSetParamVal[iCnt].Value,"true",4)) ||
                       atoi(pxSetParamVal[iCnt].Value) == 1)
                  xVLCallingFeatures.unCallFwdCfg |= 
                                      IFX_VMAPI_CALL_FWD_ON_NO_ANSWER; 
              else if((!strncasecmp(pxSetParamVal[iCnt].Value,"false",5)) ||
                       atoi(pxSetParamVal[iCnt].Value) == 0)
                  xVLCallingFeatures.unCallFwdCfg &= 
                                      ~IFX_VMAPI_CALL_FWD_ON_NO_ANSWER; 

              break;
            case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONNOANSWERNUMBER:
                  /* Check if the string fits in the buffer */
                  if ((strlen((pxSetParamVal[iCnt]).Value) + 1) >
                                               IFX_VMAPI_MAX_TRANS_ADDR_LEN)
                  {
                    (pxSetParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_BUFFER_OVERFLOW;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                  }

                  /* Copy the string */
                  strncpy(xVLCallingFeatures.xCfnaAddress.acUserName,(pxSetParamVal[iCnt]).Value,(IFX_VMAPI_MAX_USER_NAME_LEN-1));
                  xVLCallingFeatures.xCfnaAddress.ucAddrType = IFX_VMAPI_ADDR_TYPE_TEL_NUM;
              break;
            case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONNOANSWERRINGCOUNT:
                  /* Copy the value */
                  xVLCallingFeatures.ucCfnaRingCount=
                                    atoi((pxSetParamVal[iCnt]).Value);
              break;
            case OID_IGD_S_VS_VP_L_CF_CALLTRANSFERENABLE:
              /* Copy the string */
              if((!strncasecmp(pxSetParamVal[iCnt].Value,"true",4))||
                       atoi(pxSetParamVal[iCnt].Value) == 1)
                  xVLCallingFeatures.bEnableCallTransfer = IFX_TR104_TRUE; 
              else if((!strncasecmp(pxSetParamVal[iCnt].Value,"false",5)) ||
                       atoi(pxSetParamVal[iCnt].Value) == 0)
                  xVLCallingFeatures.bEnableCallTransfer = IFX_TR104_FALSE; 
              break;
            case OID_IGD_S_VS_VP_L_CF_MWIENABLE:
              /* Copy the string */
              if((!strncasecmp(pxSetParamVal[iCnt].Value,"true",4))||
                       atoi(pxSetParamVal[iCnt].Value) == 1)
                  xVLCallingFeatures.bEnableMwiIndication = IFX_TR104_TRUE; 
              else if((!strncasecmp(pxSetParamVal[iCnt].Value,"false",5)) ||
                       atoi(pxSetParamVal[iCnt].Value) == 0)
                  xVLCallingFeatures.bEnableMwiIndication = IFX_TR104_FALSE; 
              break;
            case OID_IGD_S_VS_VP_L_CF_MESSAGEWAITING:
              /* Copy the string */
              if((!strncasecmp(pxSetParamVal[iCnt].Value,"true",4))||
                       atoi(pxSetParamVal[iCnt].Value) == 1)
                  xVLCallingFeatures.bIsMsgWaiting = IFX_TR104_TRUE; 
              else if((!strncasecmp(pxSetParamVal[iCnt].Value,"false",5)) ||
                       atoi(pxSetParamVal[iCnt].Value) == 0)
                  xVLCallingFeatures.bIsMsgWaiting = IFX_TR104_FALSE; 
              break;
            case OID_IGD_S_VS_VP_L_CF_ANONYMOUSCALLBLOCKENABLE:
              /* Copy the string */
              if((!strncasecmp(pxSetParamVal[iCnt].Value,"true",4))||
                       atoi(pxSetParamVal[iCnt].Value) == 1)
                  xVLCallingFeatures.bEnableAcb = IFX_TR104_TRUE; 
              else if((!strncasecmp(pxSetParamVal[iCnt].Value,"false",5)) ||
                       atoi(pxSetParamVal[iCnt].Value) == 0)
                  xVLCallingFeatures.bEnableAcb = IFX_TR104_FALSE; 
              break;
            case OID_IGD_S_VS_VP_L_CF_DONOTDISTURBENABLE:
              /* Copy the string */
              if((!strncasecmp(pxSetParamVal[iCnt].Value,"true",4))||
                       atoi(pxSetParamVal[iCnt].Value) == 1)
                  xVLCallingFeatures.bEnableDnd = IFX_TR104_TRUE; 
              else if((!strncasecmp(pxSetParamVal[iCnt].Value,"false",5)) ||
                       atoi(pxSetParamVal[iCnt].Value) == 0)
                  xVLCallingFeatures.bEnableDnd = IFX_TR104_FALSE; 
              break;
            case OID_IGD_S_VS_VP_L_CF_CALLRETURNENABLE:
              /* Copy the string */
              if((!strncasecmp(pxSetParamVal[iCnt].Value,"true",4))||
                       atoi(pxSetParamVal[iCnt].Value) == 1)
                  xVLCallingFeatures.bEnableCallRet = IFX_TR104_TRUE; 
              else if((!strncasecmp(pxSetParamVal[iCnt].Value,"false",5)) ||
                       atoi(pxSetParamVal[iCnt].Value) == 0)
                  xVLCallingFeatures.bEnableCallRet = IFX_TR104_FALSE; 
              break;
            case OID_IGD_S_VS_VP_L_CF_REPEATDIALENABLE:
              /* Copy the string */
              if((!strncasecmp(pxSetParamVal[iCnt].Value,"true",4))||
                       atoi(pxSetParamVal[iCnt].Value) == 1)
                  xVLCallingFeatures.bEnableRepeatDial = IFX_TR104_TRUE; 
              else if((!strncasecmp(pxSetParamVal[iCnt].Value,"false",5)) ||
                       atoi(pxSetParamVal[iCnt].Value) == 0)
                  xVLCallingFeatures.bEnableRepeatDial = IFX_TR104_FALSE; 
              break;
            case OID_IGD_S_VS_VP_L_CF_ANONYMOUSCALENABLE:
                (pxSetParamVal[iCnt]).iFaultCode = ERR_CWMP_PARAM_NOT_SUPPORTED;
                iRet = ERR_CWMP_PARAM_NOT_SUPPORTED;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Parameter Not Supported\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;  
            default:
                (pxSetParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_L_CF:

            /* Fill the iid structure in LINE_CALLING_FEATURES */
            xVLCallingFeatures.iid.config_owner = IFX_TR69;

            /* Set all the LINE_CALLING_FEATURES parameters using VMAPI */
            iRtn = ifx_set_LineCallingFeatures(IFX_OP_MOD, 
                            &xVLCallingFeatures, 
                            IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT | 
                            IFX_F_DONT_WRITE_TO_FLASH);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxSetParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to set values of all "
                            "parameters\n", __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
            }

            break;
        default:
            /* Will never come here since already checked above */
            break;
    }

cleanup:
    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : Validate
**
**   Description      : This function validates the values of parameters in
**                      LineCallingFeatures object.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      validated.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When validation of all parameters is
**                      successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in validating at least one parameter.
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : GetModifyDep
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
GetModifyDep(INOUT ParamVal *pxParamVal, IN int32 iElements)
{

    int32   iCnt;
    int32   iRet         = IFX_CWMP_SUCCESS;
    int32   iParamOffset;
    char8   *psTmpVal;
    uint32 uiOutElem=0;


    /* NOTE: For all parameters fault code is set to success by default. If error in
       validating first parameter, fault code is set to the error type and other
       parameters are not validated. */

    /* NOTE: Currently validation is performed only for parameters that have write permission.
       Other parameters are simply ignored. I think this should be fine since those
       validations are performed by the controller */ 

    /* Set the fault code to Success for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and validate the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Return a failure if the value is NULL pointer */
        if (!psTmpVal)
        {
            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
            iRet = ERR_CWMP_INVAL_PARAM_VAL;
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_S_VS_VP_L_CF_MAXSESSIONS:{
                //iLength = strlen(psTmpVal);
                int32 tmp1,tmp2;
                ParamVal xInVoiceCap;
                ParamVal *xOutVoiceCap=NULL;
                int32 iaUrl[OID_LENGTH]={0,0,0,0,OID_IGD_S_VS_C,
                         OID_IGD_S_VS_C_MAXSESSIONCOUNT};

                memset(&xInVoiceCap,0x00,sizeof(ParamVal));
  
                /*Get MaxSessionCount capability from Voice Capability 
                  module*/
                memcpy(xInVoiceCap.iaOID,iaUrl,(OID_LENGTH*sizeof(int32)));
                memcpy(xInVoiceCap.iaOID,pxParamVal->iaOID,
                      ((VOICE_CAP_DEV_DEPTH+1)*sizeof(int32)));

                //Get the value using global function
    
                iRet = IFX_GlobalGetVal(&xInVoiceCap, &xOutVoiceCap,
                                  &uiOutElem);
                if(iRet != IFX_CWMP_SUCCESS)
                {
                  IFX_PrintOID(xInVoiceCap.iaOID);
                  IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
               "%s:%d IFX_GlobalGetVal failed!\n", __func__, __LINE__);
                }
                if(xOutVoiceCap!=NULL){
                  tmp1 = atoi(xOutVoiceCap->Value);
		}
                tmp2 = atoi((pxParamVal[iCnt]).Value);
                //printf("MaxSess is %d %d\n",tmp1,tmp2);
                if( tmp2 >tmp1)
                {
                  printf("----FAILED---\n");
                  (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                  iRet = ERR_CWMP_INVAL_PARAM_VAL;
        		IFX_FreeParamvalArr(&xOutVoiceCap,uiOutElem); //ramesh memleak
                  goto cleanup;
                }
                //Free the members of xOutVoiceCap 
                IFX_FreeParamvalArr(&xOutVoiceCap,uiOutElem);
                //printf("Return value of Free %d\n",iRet);

              }
              break;
            case OID_IGD_S_VS_VP_L_CF_CALLERIDENABLE:
            case OID_IGD_S_VS_VP_L_CF_CALLERIDNAMEENABLE:
            case OID_IGD_S_VS_VP_L_CF_CALLERIDNAME:
            case OID_IGD_S_VS_VP_L_CF_CALLWAITINGENABLE:
            case OID_IGD_S_VS_VP_L_CF_CALLFORWARDUNCONDITIONALENABLE:
            case OID_IGD_S_VS_VP_L_CF_CALLFORWARDUNCONDITIONALNUMBER:
            case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONBUSYENABLE:
            case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONBUSYNUMBER:
            case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONNOANSWERENABLE:
            case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONNOANSWERNUMBER:
            case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONNOANSWERRINGCOUNT:
            case OID_IGD_S_VS_VP_L_CF_CALLTRANSFERENABLE:
            case OID_IGD_S_VS_VP_L_CF_MWIENABLE:
            case OID_IGD_S_VS_VP_L_CF_ANONYMOUSCALLBLOCKENABLE:
            case OID_IGD_S_VS_VP_L_CF_DONOTDISTURBENABLE:
            case OID_IGD_S_VS_VP_L_CF_CALLRETURNENABLE:
            case OID_IGD_S_VS_VP_L_CF_REPEATDIALENABLE:
                /* Not validating. just returtning success */
                break;
            case OID_IGD_S_VS_VP_L_CF_CALLWAITINGSTATUS:
            case OID_IGD_S_VS_VP_L_CF_CONFERENCECALLINGSTATUS:
            case OID_IGD_S_VS_VP_L_CF_CONFERENCECALLINGSESSIONCOUNT:
            case OID_IGD_S_VS_VP_L_CF_MESSAGEWAITING:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_PARAM_NOT_SUPPORTED;
                iRet = ERR_CWMP_PARAM_NOT_SUPPORTED;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Parameter Not Supported\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;  
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

cleanup:
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Validating dependency requested parameter failed\n",
                    __FILE__, __func__, __LINE__, iRet);
    }

    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : IFX_LineCallingFeatures_AddDel
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_LineCallingFeatures_AddDel(IN int32 iCaller, IN ParamVal *pxParamVal, 
               IN int32 iNumElem, IN int32 operation)
{
    int32   iRet = IFIN_CWMP_SUCCESS;
    int32   iCnt = 0;
    char sOidString[IFX_MAX_TR69_ID_LEN];
    int32   iParamOffset;
    IFX_CpeId *pxCpeIdArray = NULL;
    unsigned int uiNumCpeId;
    unsigned int uiPCpeId;
    x_IFX_VMAPI_LineCallingFeatures xVLCallingFeatures;


    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                "[%s:%d] \n", __func__, __LINE__);
    
    memset(sOidString,0x00,IFX_MAX_TR69_ID_LEN);
    memset(&xVLCallingFeatures,0,sizeof(xVLCallingFeatures));

    xVLCallingFeatures.ucProfileId = IFX_GetProfileId(pxParamVal->iaOID);  

    /* Get the Parent CPE Id */
    IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT &uiPCpeId);
    xVLCallingFeatures.iid.pcpeId.Id = uiPCpeId;

    /* if neither delete nor add operation */ 
    if((operation != OP_SETVAL_ADD)&&(operation != OP_SETVAL_DELETE)){ 
          IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] Invalid operation\n",
                   __func__, __LINE__);
      return ERR_CWMP_INTERNAL;
    }    
   
    /* if delete operation */
    if(operation == OP_SETVAL_DELETE){ 
      // get cpeid, pass to delete function
      // here the input iaOID will be igd.s.vs.1.vp.1.l.2.
      
      xVLCallingFeatures.ucLineId = IFX_GetLineId(pxParamVal->iaOID); 

      /*ignore the last value as it will be a parameter and we need 
               only till the last instance*/
      iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );

      //IFX_ConvertObjOidDottedForm(pxParamVal->iaOID,sOidString);
      //printf("========= OID is %s %s==============\n",sOidString, pxParamVal->Name);
      iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId, OUT &pxCpeIdArray);
      if(iRet != IFX_CWMP_SUCCESS){
              IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                      "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                      __func__, __LINE__);

        return ERR_CWMP_INTERNAL;
      }
    
      xVLCallingFeatures.iid.cpeId.Id = pxCpeIdArray->uiId;

      memset(xVLCallingFeatures.iid.tr69Id,0x00,MAX_TR69_ID_LEN);
    
      if(strlen(pxCpeIdArray->sSectionTag) < MAX_TAG_LEN){
        strncpy(xVLCallingFeatures.iid.cpeId.secName,pxCpeIdArray->sSectionTag, MAX_TAG_LEN-1);
        IFX_CWMP_FREE(pxCpeIdArray);
      }else{
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] strcpy : mismatch in size in buffer copy\n",
                    __func__, __LINE__);
        IFX_CWMP_FREE(pxCpeIdArray);
        return ERR_CWMP_INTERNAL;
      }
    
      /* Fill the iid structure in VOICE_LINE */
      xVLCallingFeatures.iid.config_owner = IFX_TR69;

      strncpy(xVLCallingFeatures.iid.tr69Id,sOidString, MAX_TR69_ID_LEN-1);
      xVLCallingFeatures.iid.tr69Id[MAX_TR69_ID_LEN-1] = '\0';
      //printf("========= OID is %s==============\n",sOidString);

      /* call the respective VMAPI */
      iRet = ifx_set_LineCallingFeatures( IFX_OP_DEL, &xVLCallingFeatures, IFX_F_DELETE | 
                      IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH); 
      if(iRet != IFX_CWMP_SUCCESS){
             IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [Error] ifx_set_LineCallingFeatures failed\n",
                    __func__, __LINE__);
        return ERR_CWMP_INTERNAL;
      }

      return iRet;

    }// end of delete operation

    if(operation == OP_SETVAL_ADD){  // if ADD
      // ADD operation
      // here the input iaOID will be igd.s.vs.1.vp.1.l.2.
    
      /*ignore the last value as it will be a parameter and we need 
                only till the last instance*/
      iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID,sOidString);
      strncpy(xVLCallingFeatures.iid.tr69Id,sOidString, MAX_TR69_ID_LEN-1);
      xVLCallingFeatures.iid.tr69Id[MAX_TR69_ID_LEN-1] = '\0';

      xVLCallingFeatures.ucLineId = IFX_GetLineId(pxParamVal->iaOID); 

      /* Get the offset of the parameter */
      iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
      if (iParamOffset < 0)
      {
          iRet = ERR_CWMP_INTERNAL;
          IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
          goto cleanup;
      }

      // fill the given parameters of this structure with the new values provided
      for( iCnt = 0; iCnt < iNumElem; iCnt++){

          /* Process based on the requested parameter */
          switch (pxParamVal[iCnt].iaOID[iParamOffset])
          {
            case OID_IGD_S_VS_VP_L_CF_CALLERIDENABLE:
            case OID_IGD_S_VS_VP_L_CF_CALLERIDNAMEENABLE:
            case OID_IGD_S_VS_VP_L_CF_CALLERIDNAME:
            case OID_IGD_S_VS_VP_L_CF_CALLWAITINGENABLE:
            case OID_IGD_S_VS_VP_L_CF_CALLWAITINGSTATUS:
            case OID_IGD_S_VS_VP_L_CF_MAXSESSIONS:
            case OID_IGD_S_VS_VP_L_CF_CONFERENCECALLINGSTATUS:
            case OID_IGD_S_VS_VP_L_CF_CONFERENCECALLINGSESSIONCOUNT:
            case OID_IGD_S_VS_VP_L_CF_CALLFORWARDUNCONDITIONALENABLE:
            case OID_IGD_S_VS_VP_L_CF_CALLFORWARDUNCONDITIONALNUMBER:
            case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONBUSYENABLE:
            case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONBUSYNUMBER:
            case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONNOANSWERENABLE:
            case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONNOANSWERNUMBER:
            case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONNOANSWERRINGCOUNT:
            case OID_IGD_S_VS_VP_L_CF_CALLTRANSFERENABLE:
            case OID_IGD_S_VS_VP_L_CF_MWIENABLE:
            case OID_IGD_S_VS_VP_L_CF_MESSAGEWAITING:
            case OID_IGD_S_VS_VP_L_CF_ANONYMOUSCALLBLOCKENABLE:
            case OID_IGD_S_VS_VP_L_CF_ANONYMOUSCALENABLE:
            case OID_IGD_S_VS_VP_L_CF_DONOTDISTURBENABLE:
            case OID_IGD_S_VS_VP_L_CF_CALLRETURNENABLE:
            case OID_IGD_S_VS_VP_L_CF_REPEATDIALENABLE:
              break;  
           default:
               IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           "[%s:%d] [Error] Unknown requested parameter\n",
                              __func__, __LINE__);
             // parameter not found
             pxParamVal[iCnt].iFaultCode = ERR_INVAL_PARAMETER_NAME;

             goto cleanup;
          }
      } 

      /* Fill the iid structure in VOICE_LINE */
      xVLCallingFeatures.iid.config_owner = IFX_TR69;

      // call the VMAPI to modify
      iRet = ifx_set_LineCallingFeatures( IFX_OP_ADD, &xVLCallingFeatures, IFX_F_DEFAULT); 
      if(iRet != IFX_CWMP_SUCCESS){
             IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] ifx_set_LineCallingFeatures adding failed\n", 
                     __func__, __LINE__);
        iRet = ERR_CWMP_INTERNAL;
        goto cleanup;
      }
      return iRet;
    }

cleanup:

    /* Perform Cleanup of unnecessary LineSignaling members */

    return (iRet);

}



/* 
** =============================================================================
**   Function Name    : GetNotify
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
GetNotify(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
                 IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iRtn = IFX_SUCCESS;
    int32   iCnt = 0;
    int32   iTmpCnt = -1; /* Mandatory */
    int32   iParamOffset;
    int32   iOID;
    int32   iMemErrorFlag = 0; /* Mandatory */
    x_IFX_VMAPI_LineCallingFeatures xVLCallingFeatures;
    uint32 uiPCpeId;

    /* NOTE: For all parameters fault code is set to success by default. If error in
       validating first parameter, fault code is set to the error type and other
       parameters are not validated. */
    /* NOTE: For all parameters value is set to NULL by default. */

    /* Set the fault code to Success and value to NULL pointer for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);

    memset(&xVLCallingFeatures, 0, sizeof(x_IFX_VMAPI_LineCallingFeatures));

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_L_CF:{

            char8 sOidString[100] = {0};
            IFX_CpeId *pxCpeIdArray = NULL;
            unsigned int uiNumCpeId;

            /* Get the Parent CPE Id */
            IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT &uiPCpeId);
            xVLCallingFeatures.iid.pcpeId.Id = uiPCpeId;

            /*ignore the last value as it will be a parameter and we need 
              only till the last instance*/
            iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );

            strcpy(xVLCallingFeatures.iid.tr69Id,sOidString);

            /*Get the CPE Id from the corresponding tr69 Id */
            iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId,
                               OUT &pxCpeIdArray);
            if(iRet != IFX_CWMP_SUCCESS){
                   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                   __func__, __LINE__);

              return ERR_CWMP_INTERNAL;
            }
            //printf("CPEID is %d\n",pxCpeIdArray->uiId);   

            /* Fill the CPE ID of the object instance */
            xVLCallingFeatures.iid.cpeId.Id = pxCpeIdArray->uiId;
            xVLCallingFeatures.iid.config_owner = IFX_TR69;

            /* Get all the Line Calling Feature parameters using VMAPI */
            iRtn = ifx_get_LineCallingFeatures(&xVLCallingFeatures, 
                                                    IFX_F_DEFAULT);

            IFX_CWMP_FREE(pxCpeIdArray);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to get values of all "
                            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto cleanup;
            }
            }
            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
    case OID_IGD_S_VS_VP_L_CF_CALLERIDENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);

               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.bEnableCid ==  IFX_TR104_FALSE)
                 strcpy((pxParamVal[iCnt]).Value, "false");
               else if(xVLCallingFeatures.bEnableCid == IFX_TR104_TRUE)
                 strcpy((pxParamVal[iCnt]).Value, "true");

            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break;  
          case OID_IGD_S_VS_VP_L_CF_CALLERIDNAMEENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(10);
 
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.bEnableCidName ==  IFX_TR104_FALSE)
                 strcpy((pxParamVal[iCnt]).Value, "false");
               else if(xVLCallingFeatures.bEnableCidName == IFX_TR104_TRUE)
                 strcpy((pxParamVal[iCnt]).Value, "true");
            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break; 
          case OID_IGD_S_VS_VP_L_CF_CALLERIDNAME:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                strlen(xVLCallingFeatures.acCidName) + 1);

               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }

               /* Copy the value to allocated area */
               strcpy((pxParamVal[iCnt]).Value, 
                         xVLCallingFeatures.acCidName); 
            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break;  
          case OID_IGD_S_VS_VP_L_CF_CALLWAITINGENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);

               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.bEnableCallWaiting ==  IFX_TR104_FALSE)
                 strcpy((pxParamVal[iCnt]).Value, "false");
               else if(xVLCallingFeatures.bEnableCallWaiting == IFX_TR104_TRUE)
                 strcpy((pxParamVal[iCnt]).Value, "true");
            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break; 
          case OID_IGD_S_VS_VP_L_CF_CALLWAITINGSTATUS:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(20);

               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.ucCallWaitStatus == 
                                 IFX_VMAPI_CALL_STATUS_DISABLED )
                 strcpy((pxParamVal[iCnt]).Value, "Disabled");
               else if(xVLCallingFeatures.ucCallWaitStatus == 
                                 IFX_VMAPI_CALL_STATUS_IDLE)
                 strcpy((pxParamVal[iCnt]).Value, "Idle");
               else if(xVLCallingFeatures.ucCallWaitStatus == 
                                 IFX_VMAPI_CALL_STATUS_SEC_CONNECTING)
                 strcpy((pxParamVal[iCnt]).Value, "SecondaryConnecting");
               else if(xVLCallingFeatures.ucCallWaitStatus == 
                                 IFX_VMAPI_CALL_STATUS_SEC_CONNECTED)
                 strcpy((pxParamVal[iCnt]).Value, "SecondaryConnected");
               else if(xVLCallingFeatures.ucCallWaitStatus == 
                                 IFX_VMAPI_CALL_STATUS_RINGING)
                 strcpy((pxParamVal[iCnt]).Value, "SecondaryRinging");
            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break;
          case OID_IGD_S_VS_VP_L_CF_MAXSESSIONS:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                              sizeof(uchar8));

               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }

               /* Copy the value to allocated area */
               sprintf((pxParamVal[iCnt]).Value, "%d", 
                         xVLCallingFeatures.ucMaxConfSessions); 
            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break;  
          case OID_IGD_S_VS_VP_L_CF_CONFERENCECALLINGSTATUS:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(20);

               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.ucConfCallStatus ==  
                                  IFX_VMAPI_CALL_STATUS_DISABLED)
                 strcpy((pxParamVal[iCnt]).Value, "Disabled");
               else if(xVLCallingFeatures.ucConfCallStatus == 
                                  IFX_VMAPI_CALL_STATUS_IDLE)
                 strcpy((pxParamVal[iCnt]).Value, "Idle");
               else if(xVLCallingFeatures.ucConfCallStatus == 
                                 IFX_VMAPI_CALL_STATUS_SEC_CONNECTING)
                 strcpy((pxParamVal[iCnt]).Value, "SecondaryConnecting");
               else if(xVLCallingFeatures.ucConfCallStatus == 
                                 IFX_VMAPI_CALL_STATUS_SEC_CONNECTED)
                 strcpy((pxParamVal[iCnt]).Value, "SecondaryConnected");
               else if(xVLCallingFeatures.ucConfCallStatus == 
                                 IFX_VMAPI_CALL_STATUS_SEC_CALLING)
                 strcpy((pxParamVal[iCnt]).Value, "SecondaryCalling");
               else if(xVLCallingFeatures.ucConfCallStatus == 
                                 IFX_VMAPI_CALL_STATUS_IN_CONF)
                 strcpy((pxParamVal[iCnt]).Value, "InConferenceCall");
            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break;
          case OID_IGD_S_VS_VP_L_CF_CONFERENCECALLINGSESSIONCOUNT:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                         sizeof(uchar8) );

               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }

               /* Copy the value to allocated area */
               sprintf((pxParamVal[iCnt]).Value, "%d", 
                         xVLCallingFeatures.ucConfCallSessionCount); 
            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break; 
          case OID_IGD_S_VS_VP_L_CF_CALLFORWARDUNCONDITIONALENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.unCallFwdCfg &  
                                 IFX_VMAPI_CALL_FWD_UNCONDITIONAL)
                 strcpy((pxParamVal[iCnt]).Value, "true");
               else 
                 strcpy((pxParamVal[iCnt]).Value, "false");

            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break;
          case OID_IGD_S_VS_VP_L_CF_CALLFORWARDUNCONDITIONALNUMBER:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                         strlen(xVLCallingFeatures.xCfuAddress.acUserName) + 1);

               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }

               /* Copy the value to allocated area */
               strcpy((pxParamVal[iCnt]).Value, 
                         xVLCallingFeatures.xCfuAddress.acUserName); 
            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break;
          case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONBUSYENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.unCallFwdCfg & 
                                 IFX_VMAPI_CALL_FWD_BUSY )
                 strcpy((pxParamVal[iCnt]).Value, "true");
               else
                 strcpy((pxParamVal[iCnt]).Value, "false");

            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break;
          case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONBUSYNUMBER:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                         strlen(xVLCallingFeatures.xCfbAddress.acUserName) + 1);

               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }

               /* Copy the value to allocated area */
               strcpy((pxParamVal[iCnt]).Value, 
                         xVLCallingFeatures.xCfbAddress.acUserName); 
            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break;
          case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONNOANSWERENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.unCallFwdCfg &  
                                  IFX_VMAPI_CALL_FWD_ON_NO_ANSWER)
                 strcpy((pxParamVal[iCnt]).Value, "true");
               else
                 strcpy((pxParamVal[iCnt]).Value, "false");

            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break;
          case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONNOANSWERNUMBER:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                        strlen(xVLCallingFeatures.xCfnaAddress.acUserName) + 1);

               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }

               /* Copy the value to allocated area */
               strcpy((pxParamVal[iCnt]).Value, 
                         xVLCallingFeatures.xCfnaAddress.acUserName); 
            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break;
          case OID_IGD_S_VS_VP_L_CF_CALLFORWARDONNOANSWERRINGCOUNT:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                              sizeof(uchar8));

               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }

               /* Copy the value to allocated area */
               sprintf((pxParamVal[iCnt]).Value, "%d", 
                         xVLCallingFeatures.ucCfnaRingCount); 
            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break;
          case OID_IGD_S_VS_VP_L_CF_CALLTRANSFERENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.bEnableCallTransfer == IFX_TR104_FALSE)
                 strcpy((pxParamVal[iCnt]).Value, "false");
               else if(xVLCallingFeatures.bEnableCallTransfer == IFX_TR104_TRUE)
                 strcpy((pxParamVal[iCnt]).Value, "true");

            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break;
          case OID_IGD_S_VS_VP_L_CF_MWIENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.bEnableMwiIndication == IFX_TR104_FALSE)
                 strcpy((pxParamVal[iCnt]).Value, "false");
               else if(xVLCallingFeatures.bEnableMwiIndication == IFX_TR104_TRUE)
                 strcpy((pxParamVal[iCnt]).Value, "true");

            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break;
          case OID_IGD_S_VS_VP_L_CF_MESSAGEWAITING:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.bIsMsgWaiting == IFX_TR104_TRUE)
                 strcpy((pxParamVal[iCnt]).Value, "true");
               else if(xVLCallingFeatures.bIsMsgWaiting == IFX_TR104_FALSE)
                 strcpy((pxParamVal[iCnt]).Value, "false");

            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break;
          case OID_IGD_S_VS_VP_L_CF_ANONYMOUSCALLBLOCKENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.bEnableAcb == IFX_TR104_FALSE)
                 strcpy((pxParamVal[iCnt]).Value, "false");
               else if(xVLCallingFeatures.bEnableAcb == IFX_TR104_TRUE)
                 strcpy((pxParamVal[iCnt]).Value, "true");

            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break;
          case OID_IGD_S_VS_VP_L_CF_DONOTDISTURBENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.bEnableDnd == IFX_TR104_FALSE)
                 strcpy((pxParamVal[iCnt]).Value, "false");
               else if(xVLCallingFeatures.bEnableDnd == IFX_TR104_TRUE)
                 strcpy((pxParamVal[iCnt]).Value, "true");

            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break;
          case OID_IGD_S_VS_VP_L_CF_CALLRETURNENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.bEnableCallRet == IFX_TR104_FALSE)
                 strcpy((pxParamVal[iCnt]).Value, "false");
               else if(xVLCallingFeatures.bEnableCallRet == IFX_TR104_TRUE)
                 strcpy((pxParamVal[iCnt]).Value, "true");

            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break;
          case OID_IGD_S_VS_VP_L_CF_REPEATDIALENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.bEnableRepeatDial ==  IFX_TR104_FALSE)
                 strcpy((pxParamVal[iCnt]).Value, "false");
               else if(xVLCallingFeatures.bEnableRepeatDial == IFX_TR104_TRUE)
                 strcpy((pxParamVal[iCnt]).Value, "true");

            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break;
          case OID_IGD_S_VS_VP_L_CF_ANONYMOUSCALENABLE:

               (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);
                
               /* Check for error */
               if (!((pxParamVal[iCnt]).Value))
               {
                   /* Set the memory error flag */
                   iMemErrorFlag = 1;
                   iTmpCnt = iCnt;
                   goto cleanup;
               }
               /* Copy the value to allocated area */
               if(xVLCallingFeatures.bEnableCidName ==  IFX_TR104_FALSE)
                 strcpy((pxParamVal[iCnt]).Value, "true");
               else if(xVLCallingFeatures.bEnableCidName == IFX_TR104_TRUE)
                 strcpy((pxParamVal[iCnt]).Value, "false");
            iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              break;
          default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                iTmpCnt = iCnt;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
            goto cleanup;
        }
    }

cleanup:

    if (iMemErrorFlag)
    {
        (pxParamVal[iCnt]).iFaultCode = ERR_OUT_OF_MEMORY;
        iRet = ERR_OUT_OF_MEMORY;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Allocation Failure\n",
                     __FILE__, __func__, __LINE__, iRet);
    }

    if (iRet != IFX_CWMP_SUCCESS)
    {

        /* Free the allocation for value, if any. Also set the fault code. */
        for (iCnt = 0; iCnt < iElements; iCnt++)
        {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
            if (iTmpCnt != iCnt) 
            {
                (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
            }
        }
    }

    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : SetAttrInfo
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
  int32 iRet,i;
  iRet = IFX_SetAttributesInfo(pxOI, pxParamVal, iElements);
    if(iRet != IFX_CWMP_SUCCESS)
      goto errorHandler;

  for(i=0; i < iElements; i++)
    IFX_CWMP_FREE(pxParamVal->Value);

  return IFX_CWMP_SUCCESS;

  errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d failed!\n", __func__, __LINE__);
    return iRet;
}
/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : IFX_LineCallingFeatures_Init
**
**   Description      : This function is called by the controller. It registers
**                      the function responsible for handling VoiceLineCallingFeatures object
**                      with data structure. It also performs initializations
**                      specific to VoiceLineCallingFeatures object.
**
**   Parameters       : No Parameters. 
**
**   Return Value     : IFX_CWMP_SUCCESS - When VoiceLineCallingFeatures object
**                      is initialized successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in initializing VoiceLineCallingFeatures
**                      object.
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_LineCallingFeatures_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the VoiceLineCallingFeatures module function pointer in the 
       object model */
    iRet = ifx_ds_register_function(IFX_VOICELINE_CALLFEATURES_OBJ, 
                                    IFX_VoiceLineCallingFeatures);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_VOICELINE_CALLFEATURES_OBJ);
        goto cleanup;
    }

cleanup:
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_VoiceLineCallingFeatures
**
**   Description      : This function is called by the controller. It handles
**                      the VoiceLineCallingFeatures object and performs based 
**                      on requested operations/suboperations by invoking 
**                      internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_VoiceLineCallingFeatures(IN OperInfo *pxOI, INOUT void *pParamList, 
                             IN int32 iNumElem,
                             OUT void **ppRet, OUT int32 *piNumRetElem)
{
    int32       iRet           = IFX_CWMP_SUCCESS;
    ParamVal    *pxParamVal    = (ParamVal *)pParamList;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                "[%s:%d] \n", __func__, __LINE__);
    /* Process based on type of Operation */
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:

                    /* Get values of all the requested parameters */
                    iRet = GetVal(pxOI->iCaller, pxParamVal,
                                               iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_GETVAL_NOTIFICATION:

                    /* Set attribute values for all the requested parameters */
                    iRet = GetNotify(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_SETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:

                    /* Validate values of all the requested parameters */
                    iRet = Validate(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:

                   /* Check modify dependency of all requested parameters */
                    iRet = GetModifyDep(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_MODIFY:

                    /* Set values of all the requested parameters */
                    iRet = Modify(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ATTRINFO:

                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:

                case OP_SETVAL_ADD:
                    iRet = IFX_LineCallingFeatures_AddDel(pxOI->iCaller,pxParamVal, 
                              iNumElem, OP_SETVAL_ADD); // 1 = add 0=del

                    /* Check for error */
                    if (iRet != IFIN_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }


                   break;
                case OP_SETVAL_CHK_DEL_DEP:
                    *ppRet = (ParamVal *)IFX_CWMP_MALLOC(sizeof(ParamVal));
		    if(ppRet!=NULL){
                    	memcpy(*ppRet, pParamList, sizeof(ParamVal));
                    	*piNumRetElem = 1;
		    	iRet=IFX_CWMP_SUCCESS;
		    	goto cleanup;
		    }
		    else{
		     	iRet=IFX_CWMP_FAILURE;
		     	goto cleanup;
		    }
                   break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                
                    return IFX_CWMP_SUCCESS;
                   break;
                case OP_SETVAL_DELETE:
                    iRet = IFX_LineCallingFeatures_AddDel(pxOI->iCaller,pxParamVal, 
                              iNumElem, OP_SETVAL_DELETE); // 1 = add 0=del

                    /* Check for error */
                    if (iRet != IFIN_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }
                   break;

                case OP_SETVAL_FREE:
                    return IFX_CWMP_SUCCESS;
                   break;
                    
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_UPDATE_CHILDINFO:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD: 
                case OP_UPDATE_CHILDINFO_DEL: 
                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid Operation\n",
                         __func__, __LINE__, iRet);
            goto cleanup;
    }

cleanup:
    return (iRet);
}
