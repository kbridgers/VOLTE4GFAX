/*
** =============================================================================
** FILE NAME     : IFX_DAPI.c
** PROJECT       : TR69
** MODULES       : DAPI
** DATE          : 26-10-2005
** AUTHOR        : TR69 Team
** DESCRIPTION   : 
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted

** HISTORY       :
** $Date   $Author    $Comment
**
** ============================================================================
*/

#include "IFX_DEVM_Global.h"
#include "IFX_DEVM_DAPI.h"
#include <unistd.h>

#define LINESIZE	265
#define TOKEN		"=,\n"
#define DATABASE_FILE	"db1.txt"
#define DATABASE_TABLE	"dbtable.txt"
#define CONFIG_FILE	"config.txt"

static FILE *fptr = NULL;
static FILE *ftbptr = NULL;

void ifx_dapi_init()
{
    fptr = fopen(DATABASE_FILE, "r+");
    if(fptr == NULL) {
	fprintf(stderr, "Unable to open database file:%s\n", DATABASE_FILE);
	exit(EXIT_FAILURE);
    }
}

void ifx_dapi_clean()
{
    if(fptr != NULL)
	fclose(fptr);
    fptr = NULL;
}


void ifx_dapitb_init()
{
    ftbptr = fopen(DATABASE_TABLE, "r+");
    if(ftbptr == NULL) {
        fprintf(stderr, "Unable to open database file:%s\n", DATABASE_TABLE);
        exit(EXIT_FAILURE);
    }
}

void ifx_dapitb_clean()
{
    if(ftbptr != NULL)
        fclose(ftbptr);
    ftbptr = NULL;
}



static void ifx_dapi_fptr_reset() 
{
    if(fptr == NULL) {
	fprintf(stderr, "File ptr NULL. Database not opened\n");
	exit(EXIT_FAILURE);
    }
    if(fseek(fptr, 0, SEEK_SET) != 0) {
	fprintf(stderr, "Unable to set file pointer to the start of file\n");
	exit(EXIT_FAILURE);
    }
}




int ifx_dapi_get_val(char *obj, char **val)
{
    char line[LINESIZE], mirrorline[LINESIZE];
    char *head;
    char *impl, *readval;

    //ifx_dapi_fptr_reset();
    if(fptr != NULL)
        fclose(fptr);
    fptr = NULL;
    fptr = fopen(DATABASE_FILE, "r+");
    if(fptr == NULL) {
        fprintf(stderr, "Unable to open database file:%s\n", DATABASE_FILE);
        exit(EXIT_FAILURE);
    }
    if(fseek(fptr, 0, SEEK_SET) != 0) {
        fprintf(stderr, "Unable to set file pointer to the start of file\n");
        exit(EXIT_FAILURE);
    }


    do {
        if(fgets(line, LINESIZE, fptr) == NULL) {
            return ERR_NOT_FOUND;
        }
        strcpy(mirrorline, line);
        head = strtok(line, TOKEN);
        if(head != NULL) {
            if(strcmp(head, obj) == 0) {
                break;
            }
        }
        else {
            fprintf(stderr, "%s\n%s:%d Database file corrupted!!!\n",mirrorline, __FILE__, __LINE__);
            exit(EXIT_FAILURE);
        }
    } while(1);

    if((impl = strtok(NULL, TOKEN)) == NULL) {
        fprintf(stderr, "%s:Database file corrupted!!!\n",mirrorline);
        exit(EXIT_FAILURE);
    }
    if(strcmp(impl, "T") == 0) {
        if((readval = strtok(NULL, TOKEN)) == NULL) {
            fprintf(stderr,"%s\n%s:%d No value field. Database file corrupted!!!\n",mirrorline,__FILE__,__LINE__);
            exit(EXIT_FAILURE);
        }
        //printf("readval=%s %x\n",readval, val); //Nirint
        *val = (char *)IFIN_CWMP_MALLOC(strlen(readval) + 1);
        strcpy(*val, readval);
        //printf("val=%s %x\n",val, val);
    }
    else if(strcmp(impl, "F") == 0) {
        //printf("Not supported\n"); //Nirint
        return ERR_NOT_SUPPORTED;
    }
    else {
        fprintf(stderr, "%s\n%s:%d Database file corrupted!!!\n",mirrorline, __FILE__, __LINE__);
        exit(EXIT_FAILURE);
    }

    return 0;
}




int ifx_dapi_get_values(ParameterValueStruct *pvs, int num)
{
    int i = 0;
    for(i = 0; i < num; i++) {
        ifx_dapi_get_val(pvs[i].Name, &pvs[i].Value); 
    }
    return 0;
}


/******************************************************************************
if(level == true) one level below
if(level == false) all parameter below that level
Hard Coding Writable parameter as for now. The functionality will be changed
appropriately.
******************************************************************************/
int ifx_dapi_get_paramnames(char *obj, int level, ParameterInfoStruct *paramInfo, int max)
{
    int i, index = 0, partial = 0, part = 0;
    char line[LINESIZE], mirrorline[LINESIZE];
    char *head = NULL, *writable= NULL, *lineptr = NULL;

    ifx_dapi_fptr_reset();
    lineptr = strlen(obj) + obj;
    lineptr--;
    if(*lineptr == '.')
        part = 1; //Partial object path

    do {
        if(fgets(line, LINESIZE, fptr) == NULL) {
            break;
        }
        strcpy(mirrorline, line);
        head = strtok(line, TOKEN);
        writable = strtok(NULL, TOKEN); //Will give F or T
        writable = strtok(NULL, TOKEN); //Will give obj value
        writable = strtok(NULL, TOKEN); //Writable
        if(head != NULL) {
            if(strstr(head, obj) != NULL) {
                //Partial object path should match completely
                if((part == 0) && (strcmp(obj, head) != 0))
                    continue;
                if(checkvisibility(mirrorline) == 0)
                    continue;
                if(level == FALSE) {
                    if(index >= max) {
                        return ERR_RESOURCE_EXCEEDED;
                    }
                    //Hard coding writable parameter to '\0'
                    paramInfo[index].Name = (char *)IFIN_CWMP_MALLOC(strlen(head) + 1);
                    strcpy(paramInfo[index].Name, head);
                    //paramInfo[index].Writable = (char *) IFIN_CWMP_MALLOC(2);
                    if(strcmp(writable, "RO") == 0)
                        strcpy(paramInfo[index].Writable, "0");
                    else
                        strcpy(paramInfo[index].Writable, "1");
                    index++;
                    continue;
                }
                lineptr = strlen(obj) + line;
                do{
                    lineptr++;
                }while((*lineptr != '.') && (*lineptr != '\0'));
                if(*lineptr == '.') {
                    *(++lineptr) = '\0';
                    partial = 1;  //Partial path == TRUE
                }

                for(i = 0; i < index; i++)
                    if(strcmp(paramInfo[i].Name, head) == 0)
                        break;
                if(i == index) {
                    if(index >= max)
                        return ERR_RESOURCE_EXCEEDED;
                    //Hard coding writable parameter to '\0'
                    paramInfo[index].Name = (char *)IFIN_CWMP_MALLOC(strlen(head) + 1);
                    strcpy(paramInfo[index].Name, head);
                    //paramInfo[index].Writable = (char *) IFIN_CWMP_MALLOC(4);
                    if(partial == 1) {
                        if(checkvisibility(mirrorline) == 2) //2 == Cannot be created
                            strcpy(paramInfo[index].Writable, "0");
                        else
                            strcpy(paramInfo[index].Writable, "1");
                    }
                    else {
                        if(strcmp(writable, "RO") == 0)
                            strcpy(paramInfo[index].Writable, "0");
                        else
                            strcpy(paramInfo[index].Writable, "1");
                    }
                    partial = 0;
                    index++;
                }
            }
        }
        else {
            fprintf(stderr, "%s\n%s:%d Database file corrupted!!!\n",mirrorline, __FILE__, __LINE__);
            exit(EXIT_FAILURE);
        }
    }while(1);
    if(index == 0)
        return ERR_NOT_FOUND;
    return 0;
}





/*********************************************************************************

Implementing GetParameterValues

Returns : 0 on success
	  ERR_NOT_FOUND on no entries found
	  ERR_OUT_OF_MEMORY on running out of memory
	  ERR_NOT_FOUND on getting a query with no response

This function returns the ParameterValueStruct filled with response.
The struct passed should be all set to NULL cause this function doesnt set the 
last unfilled struct to NULL.

**********************************************************************************/

int ifx_dapi_get_paramvalues(char *querylist[QUERY_LIST_SIZE], ParameterValueStruct (*p_paramvalues)[])
{
    char line[LINESIZE], mirrorline[LINESIZE], linetb[LINESIZE];
    char *head = NULL;char *headtb = NULL;
    char *new = NULL, *obj=NULL;
    int index = 0;int file_end = 0; int memory_out=0;int i;int index_exceeded=0;
    int ql_index = 0; 
    int partial_query, full_query, valid_query=0, no_query_match_found=0;

    ifx_dapi_fptr_reset();

     for(index=0,ql_index=0;querylist[ql_index]!= NULL; ql_index++)
     { 
	partial_query = 0;	// reset query type
	full_query = 0;		//reset query type

	obj=querylist[ql_index];
	
	// find if partial query or full query
	head = obj; 
	head += (strlen(obj) - 1);

	//now head points to last char of string
	if(!strcmp(head,"."))
		partial_query = 1;
	else	
		full_query = 1;


        ifx_dapi_fptr_reset(); // reset the file pointer to start from begining
	file_end = 0; //reset file state

	no_query_match_found = 1; 		// not a single match of query found reset

	// this does processing to a single queary
	do {
	        if(fgets(line, LINESIZE, fptr) == NULL) {
		    file_end = 1;
	            break;
        	}
	        strcpy(mirrorline, line);
		
		if(checkvisibility(mirrorline) == 0) // if  N
		{
			continue; //take the next line, this one not visible
		}

	        head = strtok(line, TOKEN);

		valid_query = 0; // reset 
		if(full_query){
			valid_query = !strcmp(head,obj);
		}
		if(partial_query){
			valid_query= !strncmp(head, obj, strlen(obj));
	   	}		

	        if(valid_query){

	                // allocate memory for the structure
//        	        if((new = IFIN_CWMP_MALLOC(strlen(head)+1)) == NULL)
//                	   { memory_out = 1;  break; }

//	                strcpy(new,head);
//        	        (*p_paramvalues)[index].Name = new;
        	        (*p_paramvalues)[index].Name = obj;

	                head = strtok(NULL,TOKEN);
        	        head = strtok(NULL,TOKEN);

                	if((new = IFIN_CWMP_MALLOC(strlen(head)+1)) == NULL)
                        	{ memory_out = 1; break;}

	                strcpy(new,head);
//			new has the string or reference key with it, now parse it
//        	        (*p_paramvalues)[index].Value = new;
		
				
			if( strncmp(new,"*",1)) {
				(*p_paramvalues)[index].Value = new;	//this is the value to return
			}
			else {
				new++;		// now new points to the key

				ifx_dapitb_init();  //open the table
				do{
					if(fgets(linetb, LINESIZE, ftbptr) == NULL){
						ifx_dapitb_clean();  //close the table
						return ERR_NOT_FOUND;
					} //end if
		
					headtb = strtok(linetb,TOKEN); //get the key in table
					if(!strcmp(headtb,new)){
						headtb = strtok(NULL,TOKEN);   //get the key=value pair in table
						(*p_paramvalues)[index].Value = headtb;		//value found, return it
						ifx_dapitb_clean();  //close the table
						break;  //found the value now exit
					} //end of if
				}while(1); //end of do
			} //end of if-else			
	
        	        index++;
			no_query_match_found = 0;
	        } // end of if

       	       }while(index < MAX_NO_OF_RESPONSES);  //end of do-while

                if(no_query_match_found == 1)
                {
                        for( i = index; i>=0; i--)
                        {
                                IFIN_CWMP_FREE((*p_paramvalues)[i].Name);
                                IFIN_CWMP_FREE((*p_paramvalues)[i].Value);
                        }

                        break;   //exit if there is a query with no reply
                } // end of if


		if(index == MAX_NO_OF_RESPONSES)
			index_exceeded = 1;   //save the state


	        if(file_end != 1)
		{
			if((memory_out == 1) || (valid_query)==0)
				index = index + 1; // correction 
			//free all allocated memory
			for( i = index-1; i>=0; i--)
			{
				IFIN_CWMP_FREE((*p_paramvalues)[i].Name);
				IFIN_CWMP_FREE((*p_paramvalues)[i].Value);
			}

			if(memory_out == 1)
				return ERR_OUT_OF_MEMORY;

                        if(index_exceeded == 1)
                                return ERR_RESOURCE_EXCEEDED;

		} // end of if
               
		//file_end = 1 ie file ends now take a new query and handle it
	} // end of for

	if(no_query_match_found == 1)
		return ERR_NOT_FOUND;


	return 0;  // processing done completely
} //end of function




/*******************************************************************************

Implementing GetParameterAttributes

Returns : 0 on success
	  ERR_NOT_FOUND on no entries found
	  ERR_OUT_OF_MEMORY on running out of memory
	  ERR_NOT_FOUND on getting a query with no response

This function returns the ParameterValueStruct filled with response.
The struct passed should be all set to NULL cause this function doesnt set the 
last unfilled struct to NULL.



*******************************************************************************/

int ifx_dapi_get_paramattributes(char *querylist[QUERY_LIST_SIZE], ParameterAttributesStruct (*p_paramattribs)[])
{
    char line[LINESIZE], mirrorline[LINESIZE];
    char *head = NULL;
    char *new = NULL, *obj=NULL;
    int index = 0;int file_end = 0; int memory_out=0;int i;int index_exceeded=0;
    int ql_index = 0; int new_int;
    int partial_query, full_query, valid_query=0, no_query_match_found=0;

    ifx_dapi_fptr_reset();

     for(index=0,ql_index=0;querylist[ql_index]!= NULL; ql_index++)
     {
        partial_query = 0;      // reset query type
        full_query = 0;         //reset query type

        obj=querylist[ql_index];

        // find if partial query or full query
        head = obj;
        head += (strlen(obj) - 1);

        //now head points to last char of string
        if(!strcmp(head,"."))
                partial_query = 1;
        else
                full_query = 1;


        ifx_dapi_fptr_reset(); // reset the file pointer to start from begining
        file_end = 0; //reset file state

        no_query_match_found = 1;               // not a single match of query found reset

        // this does processing to a single queary
            do {
                if(fgets(line, LINESIZE, fptr) == NULL) {
                    file_end = 1;
                    break;
                }
                strcpy(mirrorline, line);

                if(checkvisibility(mirrorline) == 0) // if N
                {
                        continue; //take the next line, this one not visible
                }


                head = strtok(line, TOKEN);


                valid_query = 0; // reset
                if(full_query){
                        valid_query = !strcmp(head,obj);
                }
                if(partial_query){
                        valid_query= !strncmp(head, obj, strlen(obj));
                }

                if(valid_query){
                        // allocate memory for the structure
                        if((new = IFIN_CWMP_MALLOC(strlen(head)+1)) == NULL)
                           { memory_out = 1;  break; }

                        strcpy(new,head);
                        (*p_paramattribs)[index].Name = new;

                        // get the Notification token
                        head = strtok(NULL,TOKEN);
                        head = strtok(NULL,TOKEN);
                        head = strtok(NULL,TOKEN);
                        head = strtok(NULL,TOKEN);

                        /*if((new_int = IFIN_CWMP_MALLOC(sizeof(int))) == NULL)
                                { memory_out = 1; break;}*/

                        new_int = atoi(head); // convert the token to int and save
                        (*p_paramattribs)[index].Notification = new_int;


                        // get the Acceslist token
                        if((head = strtok(NULL,TOKEN)) != NULL)
                        {/*
				//if subscriber
				if(!strncmp(head,"S",1)){
					if((new = IFIN_CWMP_MALLOC(strlen("Subscriber")+1)) == NULL)
						{ memory_out = 1; break;}
					
					strcpy(new,"Subscriber");
				
				}else{	// if anything other than subscriber
	                                if((new = IFIN_CWMP_MALLOC(strlen(head)+1)) == NULL)
        	                                { memory_out = 1; break;}
        
					 strcpy(new,head);
				}// end if-else*/

				if(!strncmp(head,"S",1))
                                    (*p_paramattribs)[index].AccessList = "Subscriber";
				else
                                    (*p_paramattribs)[index].AccessList = "";
                        }

                        index++;  // increment the counter


                        no_query_match_found = 0;
                 } // end of if

               }while(index < MAX_NO_OF_RESPONSES);  //end of do-while

		if(no_query_match_found == 1)
		{
                        for( i = index; i>=0; i--)
                        {
                                //IFIN_CWMP_FREE((*p_paramattribs)[i].Name);
                                //IFIN_CWMP_FREE((p_paramattribs)[i].Notification);
                                //IFIN_CWMP_FREE((*p_paramattribs)[i].AccessList);
                        }

			break;   //exit if there is a query with no reply
		} // end of if

                if(index == MAX_NO_OF_RESPONSES)
                        index_exceeded = 1;   //save the state


                if(file_end != 1)
                {
                        if((memory_out == 1) || (valid_query)==0)
                                index = index + 1; // correction
                        //free all allocated memory
                        for( i = index-1; i>=0; i--)
                        {
                                //IFIN_CWMP_FREE((*p_paramattribs)[i].Name);
                                //IFIN_CWMP_FREE((*p_paramattribs)[i].Notification);
                                //IFIN_CWMP_FREE((*p_paramattribs)[i].AccessList);
                        }

                        if(memory_out == 1)
                                return ERR_OUT_OF_MEMORY;

                        if(index_exceeded == 1)
                                return ERR_RESOURCE_EXCEEDED;

                } // end of if

                //file_end = 1 ie file ends now take a new query and handle it
        } // end of for

        if(no_query_match_found == 1)
                return ERR_NOT_FOUND;


        return 0;  // processing done completely
} //end of function


/********* operation to check visibility (X,C,N) ***************
takes	: pointer to string which is an object in the form of string

returns		1 = C, 2 = X	visibility there
		0		visibility not there/entry not found/other error

****************************************************************/
int checkvisibility(const char *string){
	char testline[LINESIZE], *head, *save; 
	int i;
	//testline  = (char *)IFIN_CWMP_MALLOC(strlen(string)+1);
	strcpy(testline,string);
	save = testline;

	head = strtok(testline,TOKEN);
	for(i=6; i>=1; i--)
		head = strtok(NULL,TOKEN);	//now head points to (X,C,N)


	if(!strncmp(head,"C",1))
		return 1;

        if(!strncmp(head,"N",1))
                return 0;

        if(!strncmp(head,"X",1))
                return 2;

	//no token found
	printf("None of (X,C,N) found:%s\n", string);

        //free(save); //free allocated memory
	return 0;  //assume not visible

}

/********* operation to set visibility (X,C,N) ***************
takes	: FILE pointer which is pointing to the object for which
	 	the visibility is to be set

returns         0       failure in setting
                1       successfully set 

The file pointer points to the begining of the same object again
in the end.
****************************************************************/
int setvisibility(FILE *fpdb){
	long offset;
	int written;
	char line[LINESIZE];
	char *visibilityfield = ",N,";
	char *newvisibilityfield = ",C,";
	char *pvisibility = NULL;
//	fpos_t *fpos_save;

/*	giving segmentation fault at the moment
        if(fgetpos(fpdb, fpos_save)){
		printf("\nError in saving file position");
		return 0;
	}
*/
        if(fgets(line, LINESIZE, fpdb) == NULL) {
		printf("cannot fgets\n");
		return 0;
	}


	// the file pointer has moved to the next line, so bring it back to
	// point to object

	fseek(fpdb,(-1*strlen(line)),SEEK_CUR);

/*	giving seg fault at the  moment
	if(fsetpos(fpdb, fpos_save)){
		printf("\nError in settig file position");
		return 0;
	}

*/

	//find offset of the field from start of object
	if( (pvisibility = strstr(line,visibilityfield))== NULL){
		printf("Not found or not writable\n");
		return 0;
	}else{
		offset = labs(line - pvisibility);
	}


	//move the file pointer by that distance to point to required filed
	if( !fseek(fpdb,offset,SEEK_CUR) ){
		if((written =  fwrite(newvisibilityfield, strlen(newvisibilityfield), 1, fpdb)) == 1){
			fseek(fpdb,(-1*(offset+ strlen(newvisibilityfield))),SEEK_CUR); // bring the pointer back to where it was in begining
			return 1;
		}else{
			printf("Failure in writing\n");
			return 0;
		}
	}else{
		printf("Failure in fseek\n");
		return 0;
	}//end of if-else

} // end of function




/********* operation to reset visibility (X,C,N) ie delete********
takes	: FILE pointer which is pointing to the object for which
	 	the visibility is to be set

returns         0       failure in setting
                1       successfully set 

The file pointer points to the begining of the same object again
in the end.
****************************************************************/
int resetvisibility(FILE *fpdb){
	long offset;
	int written;
	char line[LINESIZE];
	char *visibilityfield = ",C,";
	char *newvisibilityfield = ",N,";
	char *pvisibility = NULL;
//	fpos_t *fpos_save;

/*	giving segmentation fault at the moment
        if(fgetpos(fpdb, fpos_save)){
		printf("Error in saving file position\n");
		return 0;
	}
*/
        if(fgets(line, LINESIZE, fpdb) == NULL) {
		printf("cannot fgets\n");
		return 0;
	}


	// the file pointer has moved to the next line, so bring it back to
	// point to object

	fseek(fpdb,(-1*strlen(line)),SEEK_CUR);

/*	giving seg fault at the  moment
	if(fsetpos(fpdb, fpos_save)){
		printf("Error in settig file position\n");
		return 0;
	}

*/

	//find offset of the field from start of object
	if( (pvisibility = strstr(line,visibilityfield))== NULL){
		printf("Not found or not writable\n");
		return 0;
	}else{
		offset = labs(line - pvisibility);
	}


	//move the file pointer by that distance to point to required filed
	if( !fseek(fpdb,offset,SEEK_CUR) ){
		if((written =  fwrite(newvisibilityfield, strlen(newvisibilityfield), 1, fpdb)) == 1){
			fseek(fpdb,(-1*(offset+ strlen(newvisibilityfield))),SEEK_CUR); // bring the pointer back to where it was in begining
			return 1;
		}else{
			printf("Failure in writing\n");
			return 0;
		}
	}else{
		printf("Failure in fseek\n");
		return 0;
	}//end of if-else

} // end of function


/******************** implementing AddObject *************************************

takes : the object string that is to be added as char *obj

returns :	ERR_NOT_FOUND	if object not found
		instance of object created	SUCCESS

This function does a state transition from (all N) -> (all C). If there is 
any case where all the objects are not C or N, then it implies that the 
database is corrupt.

*********************************************************************************/
int ifx_dapi_addobject(char *obj)
{

	char line[LINESIZE],mirrorline[LINESIZE];
	int addobject_instance = 0;
	int file_end = 0;
	char *test_validity = NULL;
	int addobject_done = 0; //status of job
	int instance_to_be_found = 0; // flag to see if instance is found or not
	char *obj_new = NULL; // this is the object created
	char *tmp_ptr = NULL;
	int object_there = 0;
	int previous_instance_no = 0;
        // check validity of the object
        // ie it must end with a dot
	test_validity = obj;
	test_validity += (strlen(obj) - 1);  // it should point to last char
	
	if(strncmp(test_validity,".",1))
		return ERR_INVAL_OBJ;	// invalid obj

	ifx_dapi_fptr_reset();	// reset file poiter

	do{
                if(fgets(line, LINESIZE, fptr) == NULL) {
                    file_end = 1;
                    break;
                }

		fseek(fptr,(-1*strlen(line)),SEEK_CUR); // take the fptr back



                strcpy(mirrorline, line);

		// find out the instance to be created
		if(instance_to_be_found == 0){ 
			if(!strncmp(line, obj, strlen(obj))){ // if match found
				if(checkvisibility(line)){ //if  visible
					// the nxt 3 lines are added to make sure that the instance added is correct
					tmp_ptr = line;
                                        tmp_ptr += strlen(obj); //now this points to obj number
					previous_instance_no = atoi(tmp_ptr);
					
			                fseek(fptr,strlen(line),SEEK_CUR); // take the fptr to next line where it should be
					object_there = 1;
					continue;
				}else{//if not visible
					//create obj_new
					tmp_ptr = line;
					tmp_ptr += strlen(obj); //now this points to obj number
					obj_new = IFIN_CWMP_MALLOC(strlen(obj) + 3);
					strcpy(obj_new, obj);
					obj_new = strncat(obj_new,tmp_ptr,2);
					
					//set value of addobject_instance
					addobject_instance = atoi(tmp_ptr);
			
					//check if this is different from previous_instance_no
					// if its the same, then its not the one we need.
					//instead its a yet not created subobj of the obj already created there
					if(addobject_instance == previous_instance_no){
						fseek(fptr,strlen(line),SEEK_CUR); // take the fptr to next line where it should be
						object_there = 1;
						continue;
					}

					//set instance to be found
					instance_to_be_found = 1; 
				}//end if-else

			}//end-if

		}//end if


		// create all the instances of the obj_new
		if(instance_to_be_found != 0){
			if(!strncmp(line, obj_new, strlen(obj_new))){ // if match found
				if(!setvisibility(fptr)){ //failur in setting visibiliy
					printf("Database corrupt !!\n");
					exit(1);
				}else{
					addobject_done = 1;
				} //end if-else
			}//end of if

		}//end if


		fseek(fptr,strlen(line),SEEK_CUR); // take the fptr to next line where it should be
	}while(1); // do till file ends


        if((object_there == 1) && (instance_to_be_found == 0)){
                IFIN_CWMP_FREE(obj_new);
                return ERR_RESOURCE_EXCEEDED;
        }

	if(instance_to_be_found == 0){
		IFIN_CWMP_FREE(obj_new);
		return ERR_NOT_FOUND;
	}

	if(addobject_done == 0){
		// delete all the instance half created
		ifx_dapi_deleteobject(obj_new);
		IFIN_CWMP_FREE(obj_new);
		return ERR_NOT_FOUND;
	}else{
		IFIN_CWMP_FREE(obj_new);
		return addobject_instance;	//return the instance created
	}//end if-else

} // end of function


/******************** implementing DeleteObject *************************************

takes : the object string that is to be deleted as char *obj

returns :	ERR_NOT_FOUND	if object not found
		0 		deleted


This function does a state transition from (all C) -> (all N). If there is 
any case where all the objects are not C or N, then it implies that the 
database is corrupt.


*********************************************************************************/
int ifx_dapi_deleteobject(char *obj)
{

	char line[LINESIZE],mirrorline[LINESIZE];
	int deleteobject_done = 0;
	int file_end = 0;
	char *test_validity = NULL;
	int first_instance_found =0; 

        // check validity of the object
        // ie it must end with a dot
	test_validity = obj;
	test_validity += (strlen(obj) - 1);  // it should point to last char

	if(strncmp(test_validity,".",1))
		return ERR_INVAL_OBJ;	// invalid obj

	ifx_dapi_fptr_reset();	// reset file poiter

	do{
                if(fgets(line, LINESIZE, fptr) == NULL) {
                    file_end = 1;
                    break;
                }

		fseek(fptr,(-1*strlen(line)),SEEK_CUR); // take the fptr back



                strcpy(mirrorline, line);

		if(!strncmp(line, obj, strlen(obj))){ // if match found
			if(checkvisibility(mirrorline) == 1) // ie. 'C'
			{
				resetvisibility(fptr); // reset its visibility
				deleteobject_done++;
				first_instance_found = 1; //atleast one insatnce found
			}else{
				printf("object not deletable\n");
				if(first_instance_found == 1){
					printf("Database corrupt\n");
					exit(1);
				}else{
					return ERR_NOT_FOUND;
				}
			} // end if-else

		}


	 fseek(fptr,strlen(line),SEEK_CUR); // take the fptr to next line where it should be
	}while(1); // do till file ends	

	if(deleteobject_done == 0)
		return ERR_NOT_FOUND;
	else
		return 0;


} // end of function





/********* operation to check writability (RO,WO,RW) ***************
takes   : pointer to string which is an object in the form of string

returns         1 = WO, 2 = RW          writability there
                3 = RO  0 = not found   writability not there/entry not found/other error

****************************************************************/
int checkwritability(const char *string){
        char *testline, *head;
        int i;

        testline  = IFIN_CWMP_MALLOC(strlen(string)+1);
        strcpy(testline,string);

        head = strtok(testline,TOKEN);
        for(i=3; i>=1; i--)
                head = strtok(NULL,TOKEN);      //now head points to R/W

        IFIN_CWMP_FREE(testline); //free allocated memory

        if(!strncmp(head,"WO",2))
                return 1;

        if(!strncmp(head,"RW",2))
                return 2;

        if(!strncmp(head,"RO",2))
                return 3;

        //no token found
        printf("None of (RO,WO,RW) found\n");
        return 0;  //assume not visible

}


/*********************************************************************************

Implementing SetParameterValues

Returns : 0 on success
	  ERR_NOT_FOUND on no entries found
	  ERR_OUT_OF_MEMORY on running out of memory

This function doesn't save the initial states of the objects whose values are 
being modified, therefore if after a couple of valid queries an invalid query 
is encountered, then the retrun value is ERR_NOT_FOUND but the valid querys 
have been modified. 

Therefore, the API user must save the state and then if this API fails, then 
call again using the saved state and the values will be reset.

Or call getparametervalues and if it succeeds then call this funciton.
**********************************************************************************/

int ifx_dapi_set_paramvalues( ParameterValueStruct (*p_paramvalues)[])
{
    char line[LINESIZE], mirrorline[LINESIZE];
    char *head = NULL;
    char *new = NULL, *obj=NULL;
    int file_end = 0; int memory_out=0;int index_exceeded=0;
    int ql_index = 0; 
    int partial_query, full_query, valid_query, no_query_match_found;
    fpos_t start_pos, current_pos;
    int visibility;
    int writable_status = -100;


     ifx_dapi_fptr_reset();
     for(ql_index=0;(*p_paramvalues)[ql_index].Name != NULL; ql_index++)
     { 
	partial_query = 0;	// reset query type
	full_query = 0;		//reset query type
        
	obj=(*p_paramvalues)[ql_index].Name;

	// find if partial query or full query
	head = obj; 
	head += (strlen(obj) - 1);

	//now head points to last char of string
	if(!strcmp(head,"."))
		partial_query = 1;
	else
		full_query = 1;


        ifx_dapi_fptr_reset(); // reset the file pointer to start from begining
	file_end = 0; //reset file state

	no_query_match_found = 1; 		// not a single match of query found reset
	// this does processing to a single queary
	    do {
		valid_query = 0; //reset to invalid query
	        fgetpos(fptr,&start_pos);	// save the current object position

	        if(fgets(line, LINESIZE, fptr) == NULL) {
		    file_end = 1;
	            break;
        	}

	        strcpy(mirrorline, line);

		visibility = checkvisibility(mirrorline);
		if(visibility == 0) //if visibility == N
		{
			continue; //take the next line, this one not visible
		}

	        head = strtok(line, TOKEN);

		valid_query = 0; // reset 
		if(full_query){
			valid_query = !strcmp(head,obj);
		}
		if(partial_query){
			valid_query= !strncmp(head, obj, strlen(obj));
			valid_query = 0; //partial querys are invalid
	   	}		


	        if(valid_query){

			// since its a vaild query, check its writability
			writable_status=checkwritability(mirrorline);
			if(writable_status == 0) // entry not found
			{
				(*p_paramvalues)[ql_index].Status = ERR_NOT_FOUND;
				no_query_match_found =0; 
				continue; // go to next line
			}
			if(writable_status == 3) // RO
			{
				(*p_paramvalues)[ql_index].Status = ERR_NON_WRITABLE;
				no_query_match_found=0;
				continue;	
			}

			head = strtok(mirrorline, TOKEN);
//printf("line=%s\n", mirrorline);
	                // allocate memory for the structure
//        	        if((new = IFIN_CWMP_MALLOC(strlen(head)+1)) == NULL)
//                	   { memory_out = 1;  break; }

//	                strcpy(new,head);

	                head = strtok(NULL,TOKEN);
        	        head = strtok(NULL,TOKEN);

                	if((new = IFIN_CWMP_MALLOC(strlen(head)+1)) == NULL)
                        	{ memory_out = 1; break;}

	                strcpy(new,head);
//			new has the value for the given name in it

			if(1){
				//take the file pointer back to the begining of current object
				fsetpos(fptr, &start_pos);
				
				//now move it to the filed where modification is to be done
				// strlen((*p_paramvalues)[index].Name)+3
				fseek(fptr,strlen((*p_paramvalues)[ql_index].Name)+3,SEEK_CUR);
				fgetpos(fptr, &current_pos);
				fileop(fptr,&current_pos,strlen(new),(*p_paramvalues)[ql_index].Value);  

		                fgets(line, LINESIZE, fptr); // move to new object

				IFIN_CWMP_FREE(new);
			}  // end of if

			no_query_match_found = 0;
	         } // end of if
       	       }while(1);  //end of do-while

                if(no_query_match_found == 1)
                {
			(*p_paramvalues)[ql_index].Status = ERR_NOT_FOUND;

                       // dont exit  break;   //exit if there is a query with no reply
                } // end of if


		if(ql_index == MAX_NO_OF_RESPONSES)
			index_exceeded = 1;   //save the state


	        if(file_end != 1)
		{
//			if((memory_out == 1) || (valid_query)==0)
//				index = index + 1; // correction 

			if(memory_out == 1)
				return ERR_OUT_OF_MEMORY;

                        if(index_exceeded == 1)
                                return ERR_RESOURCE_EXCEEDED;

		} // end of if
               
		//file_end = 1 ie file ends now take a new query and handle it
	} // end of for


	return 0;  // processing done completely
} //end of function



/*******************************************************************************

Implementing SetParameterAttributes

Returns : 0 on success
	  ERR_NOT_FOUND on no entries found

Issues : this function only writes and then if there is an error it doesnt 
	restore the already written to their previous form as no state is saved.

	The application should first save the state and then call this function. If
	an error is encountered, then this function should be called again with the 
	saved values and the previous state will be restored.

*******************************************************************************/


int ifx_dapi_set_paramattributes(SetParameterAttributesStruct (*p_paramattribs)[])
{
    char line[LINESIZE], mirrorline[LINESIZE], saveline[LINESIZE];
    char *head = NULL;
    char  *obj=NULL;
    int index = 0;int file_end = 0; int memory_out=0;int i;int index_exceeded=0;
    int ql_index = 0; 
    int partial_query, full_query, valid_query=0, no_query_match_found=0;
    char *newfield = NULL;
    //char *pnotify = NULL;
    int offset=0,written;
    int visibility;
    char strtmp[256];
   // char * head_tag;
    fpos_t cur_pos;
    char *querylist[2];
    ParameterAttributesStruct paramvalues_existing[2];
	int len1,len2,len3,len4;

    ifx_dapi_fptr_reset();


    for(index=0,ql_index=0;(*p_paramattribs)[ql_index].Name != NULL; ql_index++)
    {
        partial_query = 0;      // reset query type
        full_query = 0;         //reset query type

        obj=(*p_paramattribs)[ql_index].Name;

        // find if partial query or full query
        head = obj;
        head += (strlen(obj) - 1);

        //now head points to last char of string
        if(!strcmp(head,"."))
                partial_query = 1;
        else
                full_query = 1;

        ifx_dapi_fptr_reset(); // reset the file pointer to start from begining
        file_end = 0; //reset file state

        no_query_match_found = 1;             // not a single match of query found reset

        // this does processing to a single query
        do {
                if(fgets(line, LINESIZE, fptr) == NULL) {
                    file_end = 1;
                    break;
                }
                strcpy(mirrorline, line);
                strcpy(saveline, line);


                visibility = checkvisibility(mirrorline);
                if(visibility == 0) //if N
                {
                        continue; //take the next line, this one not visible/modifiable
                }

                head = strtok(mirrorline, TOKEN);

                valid_query = 0; // reset
                if(full_query){
                        valid_query = !strcmp(head,obj);
                }
                if(partial_query){
                        valid_query= !strncmp(head, obj, strlen(obj));
                }

                if(valid_query){

/////////////move the stuff for checking the query and getting existing attributes here

        //find the existing attributs values for the name before resetting the pointer

        strcpy(strtmp,head);    // match the whole obj name obtained
        querylist[0]= IFIN_CWMP_MALLOC(strlen(strtmp) + 1);
        strcpy(querylist[0], strtmp);
        querylist[1]= NULL;

        paramvalues_existing[0].Name = NULL;
        paramvalues_existing[0].Notification = 0;
        paramvalues_existing[0].AccessList = NULL;

        paramvalues_existing[1].Name = NULL;
        paramvalues_existing[1].Notification = 0;
        paramvalues_existing[1].AccessList = NULL;

// save the current file ptr
        fgetpos(fptr,&cur_pos);
        ifx_dapi_fptr_reset();
        if(ifx_dapi_get_paramattributes( querylist, &paramvalues_existing)) //if fails
        {
                printf("Failure in getting the existing parameters\n");
                return ERR_NOT_FOUND;
        }



//      printf("Inside setarrtibs 3\n"); //vivek

        // the existing attributes are now known

        //resstore the file ptr
        fsetpos(fptr,&cur_pos);


//      fgets(line, LINESIZE, fptr); //vivek
//              printf("IS THE FILE AT THE RIGHT PLACE %s\n",line);


                //create the newfield string which needs to be written
                newfield = IFIN_CWMP_MALLOC(6); //,0,S,
                strcpy(newfield,",");

                if((*p_paramattribs)[ql_index].NotificationChange == 1){ // if notification change required
                        if( *(*p_paramattribs)[ql_index].Notification == 0)
                                strncat(newfield,"0,",2);
                        if( *(*p_paramattribs)[ql_index].Notification  == 1)
                                strncat(newfield,"1,",2);
                        if( *(*p_paramattribs)[ql_index].Notification == 2)
                                strncat(newfield,"2,",2);
                }else{ //notification change not required
                        // fill the region with already existing value
        //comented later                *(*p_paramattribs)[ql_index].Notification = *(paramvalues_existing[0].Notification);

                        if( (paramvalues_existing[0].Notification) == 0)
                                strncat(newfield,"0,",2);
                        if( (paramvalues_existing[0].Notification)  == 1)
                                strncat(newfield,"1,",2);
                        if( (paramvalues_existing[0].Notification) == 2)
                                strncat(newfield,"2,",2);

                }

                if((*p_paramattribs)[ql_index].AccessListChange == 1){ // if notification change required
                        strncat(newfield,(*p_paramattribs)[ql_index].AccessList,1);
                }else{
                        strncat(newfield,paramvalues_existing[0].AccessList,1);
                }

                strncat(newfield,",",1);
		IFIN_CWMP_FREE(querylist[0]);
                //now newfield is ready to be used


                        // move the file ptr back to the present obj
                        fseek(fptr,(-1*strlen(line)),SEEK_CUR); // take the fptr back

                        head = strtok(saveline,TOKEN);
						len1 = strlen(head);
                        head = strtok(NULL,TOKEN);
						len2 = strlen(head);
                        head = strtok(NULL,TOKEN);
						len3 = strlen(head);
                        head = strtok(NULL,TOKEN);
						len4 = strlen(head);

						offset = len1 + 1+ len2 + 1+ len3 + 1+ len4;

//                        head = strtok(NULL,TOKEN);      //now head contains the notify token

//                      printf("THE TOKEN IS %s\n",head); //vivek
//                      printf("line is %s\n",line);    //vivek

/*                        head_tag = IFIN_CWMP_MALLOC(2+strlen(head));
                        strcpy(head_tag,",");
                        strcat(head_tag,head);
                        strncat(head_tag,",",1);

                        if((pnotify = strstr(line,head_tag)) != NULL)
                                offset = labs(line - pnotify);
*/



//                        IFIN_CWMP_FREE(head_tag);

                        //vivek
//                      printf("LINE modifying : %s\n",line);
//                      printf("Notification ptr : %s\n",pnotify);
//                      printf("offset to use : %d\n",offset);

                        //vivek


                        //move the file pointer by that distance to point to required filed
                        if( !fseek(fptr,offset,SEEK_CUR) ){
                                if((written =  fwrite(newfield, strlen(newfield), 1, fptr)) == 1){
                                        fseek(fptr,(-1*(offset+ strlen(newfield))),SEEK_CUR); // bring the pointer back to where it was in begining
                                }else{
                                        printf("Failure in writing\n");
                                        IFIN_CWMP_FREE(newfield);
                                        return ERR_FILE_CORRUPT;
                                }//end if-else
                        }else{
                                printf("Failure in fseek\n");
                                IFIN_CWMP_FREE(newfield);
                                return ERR_FSEEK_ERROR;
                        }//end of if-else



                        index++;  // increment the counter

                        no_query_match_found = 0;

                        //move the file ptr to next object
                        fseek(fptr,strlen(line),SEEK_CUR);

                 } // end of if

               }while(index < MAX_NO_OF_RESPONSES);  //end of do-while


				// free the allocated mem 	ADDED LATER

		        IFIN_CWMP_FREE(paramvalues_existing[0].Name);
		        //free(paramvalues_existing[0].Notification);
		        IFIN_CWMP_FREE(paramvalues_existing[0].AccessList);



				if(no_query_match_found == 1)
               {
                        for( i = index; i>=0; i--)
                        {
                                IFIN_CWMP_FREE(newfield);
                        }

                        break;   //exit if there is a query with no reply
                } // end of if

                if(index == MAX_NO_OF_RESPONSES)
                        index_exceeded = 1;   //save the state


                if(file_end != 1)
                {
                        if((memory_out == 1) || (valid_query)==0)
                                index = index + 1; // correction
                        //free all allocated memory
                        for( i = index-1; i>=0; i--)
                        {
                                IFIN_CWMP_FREE(newfield);
                        }

                        if(memory_out == 1)
                                return ERR_OUT_OF_MEMORY;

                        if(index_exceeded == 1)
                                return ERR_RESOURCE_EXCEEDED;

                } // end of if

                //file_end = 1 ie file ends now take a new query and handle it
        } // end of for

        if(no_query_match_found == 1)
                return ERR_NOT_FOUND;

        IFIN_CWMP_FREE(newfield);
        return 0;  // processing done completely
} //end of function


/******************************************************************
			Implementing filop

Prototype : fileop(	pointer to file, 
			starting point to edit,
			size to remove,
			string to insert)

This function returns the edited file with the file pointer pointing 
to where it was in the begining during the function call.

*******************************************************************/
int fileop(FILE *fp, fpos_t *start_edit, int removesize, char *insertstring){

	fpos_t begin_pos;
	char filedata[3];
	FILE *fptr_tmp;
	long current_offset, initial_offset;

	//open a tmp file and set its pointer to begining
	fptr_tmp = fopen("tmp", "w+");
	if(fptr_tmp == NULL) {
	        printf("Unable to open tmp file\n");
	        exit(EXIT_FAILURE);
	}


	fgetpos(fp, &begin_pos);	// save the filep to be reset in end


	fsetpos(fp,start_edit);	//goto positon where editing is to be done
	initial_offset = ftell(fp);

	//copy data from start to the edit position
	fseek(fp,0,SEEK_SET);
	current_offset = ftell(fp);
        while((current_offset - initial_offset) != 0)
        {
		fread(filedata,1,1,fp);
                fwrite(filedata,1,1,fptr_tmp);
		current_offset = ftell(fp);
        }


	fwrite(insertstring,strlen(insertstring),1,fptr_tmp); // write the insertstring to file


	fseek(fp, removesize, SEEK_CUR);	//move fptr to save rest of data in another file.

	// copy data to tmp file
	while(fread(filedata,1,1,fp) != 0)
	{
		fwrite(filedata,1,1,fptr_tmp);
	}


        //close the orignal file file
        if(fp != NULL)
                fclose(fp);
        fp = NULL;


	//close the tmp file
	if(fptr_tmp != NULL)
        	fclose(fptr_tmp);
	fptr_tmp = NULL;

	system("mv tmp db1.txt");	// mv the files

	//open the database file now
	ifx_dapi_init();

	fsetpos(fptr, &begin_pos);	//reset the fp to where it was in begining
	return 0;
}



/*************************************************************************
		Implementing GetParameterInfo
Prototype: int ifx_dapi_get_parameterinfo(ParameterInfo (*paraminfo)[])

Return :	0	always success

*************************************************************************/
int ifx_dapi_get_parameterinfo(ParameterInfo (*paraminfo)[])
{
    char line[LINESIZE], mirrorline[LINESIZE];
    char *head = NULL;
    char *obj=NULL, *return_value;
    int file_end = 0; 
    int ql_index = 0; 
    int partial_query, full_query, valid_query, no_query_match_found;
    fpos_t start_pos;
    //int visibility;
    //int writable_status = -100;


    ifx_dapi_fptr_reset();
    for(ql_index=0;(*paraminfo)[ql_index].Name != NULL; ql_index++)
    { 
	no_query_match_found = 1; // reset

	partial_query = 0;	// reset query type
	full_query = 0;		//reset query type
        

	obj=(*paraminfo)[ql_index].Name;

	// find if partial query or full query
	head = obj; 
	head += (strlen(obj) - 1);

	//now head points to last char of string
	if(!strcmp(head,"."))
		partial_query = 1;
	else
		full_query = 1;


        ifx_dapi_fptr_reset(); // reset the file pointer to start from begining
	file_end = 0; //reset file state

	// this does processing to a single queary
	do {
		valid_query = 0; //reset to invalid query
	        fgetpos(fptr,&start_pos);	// save the current object position

	        if(fgets(line, LINESIZE, fptr) == NULL) {
		    file_end = 1;
	            break;
        	}

	        strcpy(mirrorline, line);

//		visibility = checkvisibility(mirrorline);
//		if(visibility == 0) //if visibility == N
//		{	continue; //take the next line, this one not visible
//		}

	        head = strtok(line, TOKEN);


		valid_query = 0; // reset 
		if(full_query){
			valid_query = !strcmp(head,obj);
		}
		if(partial_query){
			valid_query= !strncmp(head, obj, strlen(obj));
			valid_query = 0; //partial querys are invalid
	   	}		


	        if(valid_query){
			// set the Exist field
			(*paraminfo)[ql_index].Exist = 1; 	// the object exists

			head = strtok(NULL,TOKEN);	// now head points to the T/F field
			strcpy((*paraminfo)[ql_index].Support,head);

			head = strtok(NULL,TOKEN);	// head points to Values field
			return_value = IFIN_CWMP_MALLOC(strlen(head) + 1);
			strcpy(return_value,head);
			(*paraminfo)[ql_index].Value = return_value;	

			head = strtok(NULL,TOKEN);	// head points to the permissions RO/RW/WO field
			strcpy((*paraminfo)[ql_index].Permissions,head);

			head = strtok(NULL,TOKEN);	// head points to the notification field
			(*paraminfo)[ql_index].Notif = atoi(head);

			head = strtok(NULL,TOKEN);	// head points to accesslist
			if(*head ==  ' ') // if a blank space then return NULL
			{
				strcpy((*paraminfo)[ql_index].AccessList,"NULL");
			}else{
				if(*head == 'S'){	// if subscriber
					strcpy((*paraminfo)[ql_index].AccessList,"Subscriber");	

				}else{
					printf("Database corrupt : exiting\n");
					printf("ERROR in : %s\n",mirrorline);
					exit(1);
				}// end if-else
			} // end if-else

			head=strtok(NULL,TOKEN); 	// head points to Visibility field
			strcpy((*paraminfo)[ql_index].Visibility,head);

			no_query_match_found = 0;  //match found	

		}		

	}while(1);  //end of do-while

	if((file_end ==1)&&(no_query_match_found == 1))
	{
		(*paraminfo)[ql_index].Exist = 0; //the object does not exist
        }
		//file_end = 1 ie file ends now take a new query and handle it
    } // end of for

    return 0;  // processing done completely
} //end of function


