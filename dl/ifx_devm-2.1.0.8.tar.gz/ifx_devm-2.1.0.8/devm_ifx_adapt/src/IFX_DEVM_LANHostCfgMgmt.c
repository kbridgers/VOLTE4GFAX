/*
** =============================================================================
**   FILE NAME        : IFX_LANHostConfigMgmt.c
**   PROJECT          : TR69
**   MODULES          : IGD.LANDevice.1.LANHostConfigManagement
**   DATE             : 12-Jun-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION      : 
**
**   REFERENCES       :  
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**  $Date        $Author       $Comment
**  15-Jun-2006  TR69 team     Creation
** =============================================================================
*/
#include "IFX_DEVM_Global.h"
 
#include "IFX_DEVM_AdaptCommon.h"
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
#include <arpa/inet.h>
#include <netinet/in.h>

extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char *obj, modFunc pifx_module_func);

#define LHCM_OBJ       "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement."
#define LHCM_DEPTH     5
#define MAX_PARAM_SIZE 64
#define INFINITE_LEASE 9999999

/*******************************************************************************
* Function: IFX_LHCMSetAttrInfo
* Description: Sets attribute information in the respective tr69 sections
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_LHCMSetAttrInfo(IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    iRet = IFX_SetAttributesInfo(NULL, pxPV, iElements);

    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Updating Param Attribute Info failed\n",
                    __func__, __LINE__, iRet);
        goto errorHandler;
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_LHCMGetValue
* Description: 
*              
* Parameters: IN OperInfo *pxOI, INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_LHCMGetValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0, iTmp = 0, iNumEntries = 0;
    DHCP_SERVER_INFO xDSInfo;
    IP_MASK_TYPE *pxaIPMask = NULL;
    char caTmp[12] = { 0 };
    char macTmp[32] = { 0 };
    IFX_DHCP_COND_SERV_POOL *paxDHCPPool = NULL;
    IFX_MAPI_DHCPS_STATIC_LEASE *paxDHCPStatic = NULL;
    char sDNS[16] = { 0 };
    char sDNSServers[32] = { 0 };
    int32 iStrLen = 0;
    int32 iIndex = 0;
    char * pResvAddr = NULL;

    memset(&xDSInfo, '\0', sizeof(xDSInfo));

    iTmp = ifx_get_lan_dhcp_server_config(&xDSInfo, 0);
    if(iTmp != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_lan_dhcp_server_cfg() failed\n",
                    __func__, __LINE__, iTmp);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }


    for(iI = 0; iI < iElements; iI++) {
        pxPV[iI].Value = IFX_CWMP_MALLOC(MAX_PARAM_SIZE + 1);
        if(pxPV[iI].Value == NULL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", __func__, __LINE__);
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (pxPV[iI].iaOID[LHCM_DEPTH - 1]) {
            case OID_IGD_LAND_LANHCM_DHCPSERVERCONFIGURABLE:
                iTmp = ifx_get_dhcp_server_module_support(0);
                if(iTmp == IFX_SUPPORTED)
                    strcpy(pxPV[iI].Value, "1");
                else
                    strcpy(pxPV[iI].Value, "0");
                break;
            case OID_IGD_LAND_LANHCM_DHCPSERVERENABLE:
                memset(caTmp, '\0', sizeof(caTmp));
		if ( (ifx_get_dhcp_server_mode(IFX_F_GET_ANY) ) == IFX_DHCP_SERVER_MODE)
			strcpy(pxPV[iI].Value, "1");
		else
			strcpy(pxPV[iI].Value, "0");
                break;
            case OID_IGD_LAND_LANHCM_DHCPRELAY:
                memset(caTmp, '\0', sizeof(caTmp));

                iTmp = ifx_get_dhcp_server_mode(0);
                if(iTmp == IFX_DHCP_RELAY_MODE)
                    strcpy(caTmp, "true");
                else
                    strcpy(caTmp, "false");

                strcpy(pxPV[iI].Value, caTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI,
                                         IFX_CHK_CHANGE_FLAG_BASED);
                break;
            case OID_IGD_LAND_LANHCM_MINADDRESS:
                inet_ntop(AF_INET, &xDSInfo.start_ip, pxPV[iI].Value,
                          IPADDR_LEN);
                break;
            case OID_IGD_LAND_LANHCM_MAXADDRESS:
                inet_ntop(AF_INET, &xDSInfo.end_ip, pxPV[iI].Value, IPADDR_LEN);
                break;
            case OID_IGD_LAND_LANHCM_RESERVEDADDRESSES:
		iNumEntries = 0;
		iRet=ifx_get_all_dhcps_static_lease(&iNumEntries, &paxDHCPStatic, IFX_F_GET_ANY);
		if(iRet != IFX_SUCCESS)
		{
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					"[%s:%s:%d] [%d] ifx_get_all_dhcps_static_lease returned failure\n",
					__FILE__,  __func__, __LINE__, iRet);
			goto errorHandler;
		}
		if(iNumEntries != 0)
		{
	                IFX_MEM_FREE(pxPV[iI].Value);
			pResvAddr = IFX_CWMP_MALLOC( (iNumEntries)*(MAX_IP_MASK_LEN) );
			if(NULL == pResvAddr)
			{
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
			            "Malloc failed\n", __func__, __LINE__);
				iRet = ERR_OUT_OF_MEMORY;
				goto errorHandler;
			}
			sprintf(pResvAddr, "%s", paxDHCPStatic[0].ipAddr);
			for (iIndex = 1; iIndex < iNumEntries; iIndex++)
			{
				sprintf(pResvAddr, "%s,%s",pResvAddr, paxDHCPStatic[iIndex].ipAddr);
			}
		        pxPV[iI].Value = pResvAddr;
    		        IFX_CWMP_FREE(paxDHCPStatic);
		}
		break;
            case OID_IGD_LAND_LANHCM_SUBNETMASK:
                inet_ntop(AF_INET, &xDSInfo.netmask, pxPV[iI].Value,
                          IPADDR_LEN);
                break;
            case OID_IGD_LAND_LANHCM_DNSSERVERS:
		{
		    ifx_get_runtime_dns(sDNS, "1");
                    if(sDNS[0] != '\0')
                    {
			strncpy(sDNSServers,sDNS,15);
			sDNSServers[15] = '\0';
                    	sDNS[0] = '\0';
		    }
		    
                    ifx_get_runtime_dns(sDNS, "2");
                    if(sDNS[0] != '\0')
                    {
                        if(sDNSServers[0] != '\0')
                        {
                            snprintf(sDNSServers,31,"%s,%s",sDNSServers,sDNS);
                        }
                        else
                        {
                            snprintf(sDNSServers,31,"%s",sDNS);
                        }
                    }
		    strcpy(pxPV[iI].Value,sDNSServers);
                    break;
		}
            case OID_IGD_LAND_LANHCM_DOMAINNAME:
                iStrLen = strlen(xDSInfo.dhcp_domain_name);
                if((iStrLen > 2) && (iStrLen  < MAX_DOMAIN_NAME_LEN) )
		{
                    strncpy(pxPV[iI].Value, xDSInfo.dhcp_domain_name, iStrLen);
                }
                break;
            case OID_IGD_LAND_LANHCM_IPROUTERS:
                inet_ntop(AF_INET, &xDSInfo.ip_gw, pxPV[iI].Value, IPADDR_LEN);
                break;
            case OID_IGD_LAND_LANHCM_DHCPLEASETIME:
                sprintf(caTmp, "%d", xDSInfo.leasetime);
                if(xDSInfo.leasetime == INFINITE_LEASE)
                    strcpy(caTmp, "-1");
                strcpy(pxPV[iI].Value, caTmp);
                break;
            case OID_IGD_LAND_LANHCM_USEALLOCATEDWAN:
                break;
            case OID_IGD_LAND_LANHCM_ASSOCIATEDCONNECTION:
                break;
            case OID_IGD_LAND_LANHCM_PASSTHROUGHLEASE:
                break;
            case OID_IGD_LAND_LANHCM_PASSTHROUGHMACADDRESS:
                break;
            case OID_IGD_LAND_LANHCM_ALLOWEDMACADDRESSES:
                break;
            case OID_IGD_LAND_LANHCM_IPINTERFACENUMBEROFENTRIES:
                /* br0 hardcoded. need to find a better way */
                ifx_get_lan_ip_mask("br0", &iNumEntries, &pxaIPMask, 0);
                memset(caTmp, '\0', sizeof(caTmp));
                sprintf(caTmp, "%d", iNumEntries);
                strcpy(pxPV[iI].Value, caTmp);
                IFX_CWMP_FREE(pxaIPMask);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI,
                                         IFX_CHK_CHANGE_FLAG_BASED);
                break;

	    case OID_IGD_LAND_LANHCM_DHCPSTATICADDRESSNUMBEROFENTRIES:

		iRet=ifx_get_all_dhcps_static_lease(&iNumEntries, &paxDHCPStatic, IFX_F_GET_ANY);
    		IFX_CWMP_FREE(paxDHCPStatic); // no need of this struct
		if(iRet != IFX_SUCCESS)
		{
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					"[%s:%s:%d] [%d] ifx_get_all_dhcps_static_lease returned failure\n",
					__FILE__,  __func__, __LINE__, iRet);
			goto errorHandler;
		}

		memset(caTmp, '\0', sizeof(caTmp));
                sprintf(caTmp, "%d", iNumEntries);
                strcpy(pxPV[iI].Value, caTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI,
                                         IFX_CHK_CHANGE_FLAG_BASED);
 
                break;
	    case OID_IGD_LAND_LANHCM_DHCPCONDITIONALPOOLNUMBEROFENTRIES:

		iRet=ifx_get_all_dhcp_conditional_entries(&iNumEntries, &paxDHCPPool, IFX_F_GET_ANY);
    		IFX_CWMP_FREE(paxDHCPPool); // no need of this struct
		if(iRet != IFX_SUCCESS)
		{
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					"[%s:%s:%d] [%d] ifx_get_all_dhcp_conditional_entries returned failure\n",
					__FILE__,  __func__, __LINE__, iRet);
			goto errorHandler;
		}

		memset(caTmp, '\0', sizeof(caTmp));
                sprintf(caTmp, "%d", iNumEntries);
                strcpy(pxPV[iI].Value, caTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI,
                                         IFX_CHK_CHANGE_FLAG_BASED);
 
                break;
	    case OID_IGD_LAND_LANHCM_MACADDRESS:
		 memset(macTmp, '\0', sizeof(macTmp));
		 iRet = ifx_mod_get_lan_mac(macTmp);
	         if(iRet != IFX_SUCCESS)
		 {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					"[%s:%s:%d] [%d] Unable to get macaddress\n",
					__FILE__,  __func__, __LINE__, iRet);
			goto errorHandler;
		 }
		 strcpy(pxPV[iI].Value,macTmp);
		 IFX_CheckValueGotChanged(pxOI, pxPV + iI,
                                         IFX_CHK_CHANGE_FLAG_BASED);
		 break;	
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", __func__,
                            __LINE__, pxPV[iI].iaOID[LHCM_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_LHCMValidate
* Description:
*              
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_LHCMValidate(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0, iIP = 0;

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[LHCM_DEPTH - 1]) {
            case OID_IGD_LAND_LANHCM_DHCPSERVERCONFIGURABLE:
                break;
            case OID_IGD_LAND_LANHCM_DHCPSERVERENABLE:
                break;
            case OID_IGD_LAND_LANHCM_DHCPRELAY:
                break;
            case OID_IGD_LAND_LANHCM_MINADDRESS:
                if((iRet = inet_pton(AF_INET, pxPV[iI].Value, &iIP)) <= 0) {
                    iRet = ERR_CWMP_INVAL_ARGS;
                    pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                }
                else
                    iRet = IFX_CWMP_SUCCESS;
                break;
            case OID_IGD_LAND_LANHCM_MAXADDRESS:
                if((iRet = inet_pton(AF_INET, pxPV[iI].Value, &iIP)) <= 0) {
                    iRet = ERR_CWMP_INVAL_ARGS;
                    pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                }
                else
                    iRet = IFX_CWMP_SUCCESS;
                break;
            case OID_IGD_LAND_LANHCM_RESERVEDADDRESSES:
                break;
            case OID_IGD_LAND_LANHCM_SUBNETMASK:
                if((iRet = inet_pton(AF_INET, pxPV[iI].Value, &iIP)) <= 0) {
                    iRet = ERR_CWMP_INVAL_ARGS;
                    pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                }
                else
                    iRet = IFX_CWMP_SUCCESS;
                break;
            case OID_IGD_LAND_LANHCM_DNSSERVERS:
                break;
            case OID_IGD_LAND_LANHCM_DOMAINNAME:
                break;
            case OID_IGD_LAND_LANHCM_IPROUTERS:
                break;
            case OID_IGD_LAND_LANHCM_DHCPLEASETIME:
                if(atoi(pxPV[iI].Value) == 0) {
                    iRet = ERR_CWMP_INVAL_PARAM_VAL;
                    pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                }
                break;
            case OID_IGD_LAND_LANHCM_USEALLOCATEDWAN:
                break;
            case OID_IGD_LAND_LANHCM_ASSOCIATEDCONNECTION:
                break;
            case OID_IGD_LAND_LANHCM_PASSTHROUGHLEASE:
                break;
            case OID_IGD_LAND_LANHCM_PASSTHROUGHMACADDRESS:
                break;
            case OID_IGD_LAND_LANHCM_ALLOWEDMACADDRESSES:
                break;
            case OID_IGD_LAND_LANHCM_IPINTERFACENUMBEROFENTRIES:
                break;
            case OID_IGD_LAND_LANHCM_DHCPSTATICADDRESSNUMBEROFENTRIES:
                break;
	    case OID_IGD_LAND_LANHCM_DHCPCONDITIONALPOOLNUMBEROFENTRIES:
                break;

            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", __func__,
                            __LINE__, pxPV[iI].iaOID[LHCM_DEPTH - 1]);
                break;
        }
    }

    return iRet;
}

/*******************************************************************************
* Function: IFX_LHCMSetValue
* Description: 
*              
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_LHCMSetValue(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0, iTmp = 0;
    struct in_addr iIP;
    DHCP_SERVER_INFO xDSInfo;
    DHCP_RELAY_INFO xDRInfo;
    int iFlags = 0;
    int dhcp_relay=0;
    int32 dhcp_mode = 0;

    memset(&xDSInfo, 0, sizeof(xDSInfo));
    memset(&iIP, 0, sizeof(iIP));

    iTmp = ifx_get_lan_dhcp_server_config(&xDSInfo, IFX_F_GET_ANY);
    if(iTmp != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_lan_dhcp_server_cfg() failed\n",
                    __func__, __LINE__, iTmp);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
    dhcp_mode = ifx_get_dhcp_server_mode(IFX_F_GET_ANY);

    iTmp = ifx_get_dhcp_relay_config(&xDRInfo, IFX_F_GET_ANY);
    if(iTmp != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_dhcp_relay_cfg() failed\n",
                    __func__, __LINE__, iTmp);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }

    for(iI = 0; iI < iElements; iI++)
    {
        switch (pxPV[iI].iaOID[LHCM_DEPTH - 1])
        {

            case OID_IGD_LAND_LANHCM_DHCPSERVERCONFIGURABLE:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            case OID_IGD_LAND_LANHCM_DHCPSERVERENABLE:
                if((strncasecmp(pxPV[iI].Value, "False", 5) == 0) || (strcmp(pxPV[iI].Value, "0") == 0))
                {
                    xDSInfo.dhcp_mode = IFX_DISABLED;
                    dhcp_mode = IFX_DISABLED;
                }
                else
                {
                    xDSInfo.dhcp_mode = IFX_DHCP_SERVER_MODE;
                    dhcp_mode = IFX_DHCP_SERVER_MODE;
                }
                break;

            case OID_IGD_LAND_LANHCM_DHCPRELAY:
                if((strncasecmp(pxPV[iI].Value, "False", 5) == 0) || (strcmp(pxPV[iI].Value, "0") == 0))
                {
                    dhcp_relay = IFX_DHCP_SERVER_MODE;
                }
                else if((strncasecmp(pxPV[iI].Value, "True", 4) == 0) || (strcmp(pxPV[iI].Value, "1") == 0))
                {
                    dhcp_relay = IFX_DHCP_RELAY_MODE;
                }
                else
                {
                    iRet = ERR_CWMP_INVAL_ARGS;
                    pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                }

                break;

            case OID_IGD_LAND_LANHCM_MINADDRESS:
                if((iRet = inet_pton(AF_INET, pxPV[iI].Value, &iIP)) == 1) {
                    xDSInfo.start_ip = iIP;
                    iRet = IFX_CWMP_SUCCESS;
                }
                else {
                    iRet = ERR_CWMP_INVAL_ARGS;
                    pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                }
                break;

            case OID_IGD_LAND_LANHCM_MAXADDRESS:
                if((iRet = inet_pton(AF_INET, pxPV[iI].Value, &iIP)) == 1) {
                    xDSInfo.end_ip = iIP;
                    iRet = IFX_CWMP_SUCCESS;
                }
                else {
                    iRet = ERR_CWMP_INVAL_ARGS;
                    pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                }
                break;

            case OID_IGD_LAND_LANHCM_RESERVEDADDRESSES:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;

            case OID_IGD_LAND_LANHCM_SUBNETMASK:
                if((iRet = inet_pton(AF_INET, pxPV[iI].Value, &iIP)) == 1) {
                    xDSInfo.netmask = iIP;
                    iRet = IFX_CWMP_SUCCESS;
                }
                else {
                    iRet = ERR_CWMP_INVAL_ARGS;
                    pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                }
                break;

            case OID_IGD_LAND_LANHCM_DNSSERVERS:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;

            case OID_IGD_LAND_LANHCM_DOMAINNAME:
                strcpy(xDSInfo.dhcp_domain_name, pxPV[iI].Value);
                break;

            case OID_IGD_LAND_LANHCM_IPROUTERS:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;

            case OID_IGD_LAND_LANHCM_DHCPLEASETIME:
                if((iTmp = atoi(pxPV[iI].Value)) == -1)
                    xDSInfo.leasetime = INFINITE_LEASE;
                else
                    xDSInfo.leasetime = iTmp;
                break;

            case OID_IGD_LAND_LANHCM_USEALLOCATEDWAN:
                break;
            case OID_IGD_LAND_LANHCM_ASSOCIATEDCONNECTION:
                break;
            case OID_IGD_LAND_LANHCM_PASSTHROUGHLEASE:
                break;
            case OID_IGD_LAND_LANHCM_PASSTHROUGHMACADDRESS:
                break;
            case OID_IGD_LAND_LANHCM_ALLOWEDMACADDRESSES:
                break;

            case OID_IGD_LAND_LANHCM_IPINTERFACENUMBEROFENTRIES:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;

            case OID_IGD_LAND_LANHCM_DHCPSTATICADDRESSNUMBEROFENTRIES:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;

	    case OID_IGD_LAND_LANHCM_DHCPCONDITIONALPOOLNUMBEROFENTRIES:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
	
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", __func__,
                            __LINE__, pxPV[iI].iaOID[LHCM_DEPTH - 1]);
                break;
        }
    }
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    iFlags = iFlags | IFX_F_MODIFY | IFX_F_DONT_WRITE_TO_FLASH | IFX_F_DONT_CHECKPOINT;
    xDSInfo.iid.config_owner = IFX_TR69;
    /*If Relay is not set, set the dhcp mode as in the rc.conf or as set by ACS*/
    if( (dhcp_mode == IFX_DISABLED) || (dhcp_relay == IFX_DISABLED))
    {
        iTmp = ifx_set_dhcp_server_mode(dhcp_mode, iFlags);
        if(iTmp != IFX_SUCCESS)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_set_lan_dhcp_server_mode() failed\n",
                    __func__, __LINE__, iTmp);
            iRet = ERR_CWMP_INTERNAL;
            goto errorHandler;
        }
        iTmp = ifx_set_lan_dhcp_server_config(IFX_OP_MOD, &xDSInfo, iFlags);
        if(iTmp != IFX_SUCCESS)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_set_lan_dhcp_server_cfg() failed\n",
                    __func__, __LINE__, iTmp);
            iRet = ERR_CWMP_INTERNAL;
            goto errorHandler;
        }
    }
    else
    {
        /*Else set Relay or server mode as set by ACS*/
        iTmp = ifx_set_dhcp_server_mode(dhcp_relay, iFlags);
        if(iTmp != IFX_SUCCESS)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_set_lan_dhcp_server_mode() failed\n",
                    __func__, __LINE__, iTmp);
            iRet = ERR_CWMP_INTERNAL;
            goto errorHandler;
        }
        iTmp = ifx_set_dhcpr_dhcp_server(IFX_OP_MOD, xDRInfo.dhcpr_servers, iFlags); 
        if(iTmp != IFX_SUCCESS)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_set_dhcpr_dhcp_server() failed\n",
                    __func__, __LINE__, iTmp);
            iRet = ERR_CWMP_INTERNAL;
            goto errorHandler;
        }
    }
    
errorHandler:
    IFX_MEM_FREE(xDRInfo.dhcpr_servers)
    return iRet;
}

/*******************************************************************************
* Function: IFX_LHCMFree
* Description: 
*              
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_LHCMFree()
{
    int32 iRet = IFX_CWMP_SUCCESS;

    return iRet;
}

/*******************************************************************************
* Function: IFX_LHCMCommit
* Description: 
*              
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_LHCMCommit(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[LHCM_DEPTH - 1]) {
            case OID_IGD_LAND_LANHCM_DHCPSERVERCONFIGURABLE:
                break;
            case OID_IGD_LAND_LANHCM_DHCPSERVERENABLE:
                break;
            case OID_IGD_LAND_LANHCM_DHCPRELAY:
                break;
            case OID_IGD_LAND_LANHCM_MINADDRESS:
                break;
            case OID_IGD_LAND_LANHCM_MAXADDRESS:
                break;
            case OID_IGD_LAND_LANHCM_RESERVEDADDRESSES:
                break;
            case OID_IGD_LAND_LANHCM_SUBNETMASK:
                break;
            case OID_IGD_LAND_LANHCM_DNSSERVERS:
                break;
            case OID_IGD_LAND_LANHCM_DOMAINNAME:
                break;
            case OID_IGD_LAND_LANHCM_IPROUTERS:
                break;
            case OID_IGD_LAND_LANHCM_DHCPLEASETIME:
                break;
            case OID_IGD_LAND_LANHCM_USEALLOCATEDWAN:
                break;
            case OID_IGD_LAND_LANHCM_ASSOCIATEDCONNECTION:
                break;
            case OID_IGD_LAND_LANHCM_PASSTHROUGHLEASE:
                break;
            case OID_IGD_LAND_LANHCM_PASSTHROUGHMACADDRESS:
                break;
            case OID_IGD_LAND_LANHCM_ALLOWEDMACADDRESSES:
                break;
            case OID_IGD_LAND_LANHCM_IPINTERFACENUMBEROFENTRIES:
                break;
            case OID_IGD_LAND_LANHCM_DHCPSTATICADDRESSNUMBEROFENTRIES:
                break;
	    case OID_IGD_LAND_LANHCM_DHCPCONDITIONALPOOLNUMBEROFENTRIES:
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", __func__,
                            __LINE__, pxPV[iI].iaOID[LHCM_DEPTH - 1]);
                break;
        }
    }

    return iRet;
}

/*******************************************************************************
* Function: IFX_LHCMUndo
* Description: 
*              
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_LHCMUndo(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[LHCM_DEPTH - 1]) {
            case OID_IGD_LAND_LANHCM_DHCPSERVERCONFIGURABLE:
                break;
            case OID_IGD_LAND_LANHCM_DHCPSERVERENABLE:
                break;
            case OID_IGD_LAND_LANHCM_DHCPRELAY:
                break;
            case OID_IGD_LAND_LANHCM_MINADDRESS:
                break;
            case OID_IGD_LAND_LANHCM_MAXADDRESS:
                break;
            case OID_IGD_LAND_LANHCM_RESERVEDADDRESSES:
                break;
            case OID_IGD_LAND_LANHCM_SUBNETMASK:
                break;
            case OID_IGD_LAND_LANHCM_DNSSERVERS:
                break;
            case OID_IGD_LAND_LANHCM_DOMAINNAME:
                break;
            case OID_IGD_LAND_LANHCM_IPROUTERS:
                break;
            case OID_IGD_LAND_LANHCM_DHCPLEASETIME:
                break;
            case OID_IGD_LAND_LANHCM_USEALLOCATEDWAN:
                break;
            case OID_IGD_LAND_LANHCM_ASSOCIATEDCONNECTION:
                break;
            case OID_IGD_LAND_LANHCM_PASSTHROUGHLEASE:
                break;
            case OID_IGD_LAND_LANHCM_PASSTHROUGHMACADDRESS:
                break;
            case OID_IGD_LAND_LANHCM_ALLOWEDMACADDRESSES:
                break;
            case OID_IGD_LAND_LANHCM_IPINTERFACENUMBEROFENTRIES:
                break;
            case OID_IGD_LAND_LANHCM_DHCPSTATICADDRESSNUMBEROFENTRIES:
                break;
	    case OID_IGD_LAND_LANHCM_DHCPCONDITIONALPOOLNUMBEROFENTRIES:
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", __func__,
                            __LINE__, pxPV[iI].iaOID[LHCM_DEPTH - 1]);
                break;
        }
    }

    return iRet;
}

/*******************************************************************************
* Function: IFX_LANHostCfgMgmt
* Description: 
*              
* Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
*             OUT void **ppRet, OUT int32 * piNumRetElem
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_LANHostCfgMgmt(IN OperInfo * pxOI, INOUT void *pParamStruct,
                   IN int32 iElements, OUT void **ppRet,
                   OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                "%s %s SubOper=%d maxElement=%d\n", __func__,
                xpParamVal[0].Name, pxOI->iSubOper, iElements);
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                    iRet = IFX_LHCMGetValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
		    {
                        goto errorHandler;
                    }
                    break;
                case OP_GETVAL_NOTIFICATION:
                    iRet = IFX_LHCMGetValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                    if((iRet = IFX_LHCMValidate(xpParamVal, iElements)) != 0) {
                        goto errorHandler;
                    }
                    break;
                case OP_SETVAL_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:
                    break;
                case OP_SETVAL_MODIFY:
                    if((iRet = IFX_LHCMSetValue(xpParamVal, iElements)) != 0) {
                        goto errorHandler;
                    }
                    break;
                case OP_SETVAL_COMMIT:
                    if((iRet = IFX_LHCMCommit(xpParamVal, iElements)) != 0) {
                        goto errorHandler;
                    }
                    break;
                case OP_SETVAL_UNDO:
                    if((iRet = IFX_LHCMUndo(xpParamVal, iElements)) != 0) {
                        goto errorHandler;
                    }
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_DELETE:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    iRet = IFX_LHCMFree();
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_SETVAL_ATTRINFO:
                    iRet = IFX_LHCMSetAttrInfo(pxOI->iCaller, pParamStruct,
                                               iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                case OP_UPDATE_CHILDINFO_DEL:
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d [%d] Error! Default case\n", __func__,
                        __LINE__, pxOI->iOper);
            break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_LANHostCfgMgmtInit
* Description: Will initialize some of its data structures, register itself with 
*              DS.
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_LANHostCfgMgmtInit()
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* TBD: Perform any LANHostCfgMgmt related initializations here */

    /* Register the LANHostCfgMgmt module func ptr in the object model */
    iRet = ifx_ds_register_function(LHCM_OBJ, IFX_LANHostCfgMgmt);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d Unable to Register %s with Object Model\n",
                    __func__, __LINE__, LHCM_OBJ);
        goto errorHandler;
    }

  errorHandler:
    return iRet;
}
