/* 
** =============================================================================
**   FILE NAME        : IFX_WanIpPortMapping.c
**   PROJECT          : TR69
**   MODULES          : WanIpPortMapping
**   DATE             : 21-06-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This module handles ADD/DEL/GET/SET RPCs of 
**                      WanIpPortMapping. When controller calls this module it
**                      calls respective Platform/Object APIs to handle GET/SET 
**                      of WanIpPortMapping specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author        $Comment
**   28-04-06         TR69 team      Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>

#include "IFX_DEVM_WANIPPortMap.h"

#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"


/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;
#define IFX_WAN_IP_PORTMAP_OBJ "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANIPConnection.1.PortMapping.1."
#define IFX_WAN_PPP_PORTMAP_OBJ "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.1.PortMapping.1."

#define WAN_IP_NO_DEP_OIDS 2
#define WAN_IP_PORT_MAP_TCP 1
#define WAN_IP_PORT_MAP_UDP 2
/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/


extern Map_Value gaxEnable[];
extern Map_Value saxDslLnkType[];

static Map_Value saxWanIpPortMapProto[] = {
    {"TCP", SYS_DATATYPE_INT, {.uiSys_Value = NAT_VS_PROTOCOL_TCP}},
    {"UDP", SYS_DATATYPE_INT, {.uiSys_Value = NAT_VS_PROTOCOL_UDP}},
    {"TCP-UDP", SYS_DATATYPE_INT, {.uiSys_Value = NAT_VS_PROTOCOL_TCP_UDP}}
};

/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/


int32 lease_flag = 0;
int32 lease_num_entries = 0;
long int leaseTimeArr[20][2];
STATIC uint16 guiTimerId;

extern void IFX_CWMP_TimerCB(IN int32 reason);
extern int32 IFX_GetNameFromOID(IN int32 * iaOID, OUT char8 ** psName);
extern int ifx_config_del_obj(char *psObj);
static int32 Lease_Duration_Timer_Start(int32 lease_duration, int32 cpeId);


/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/

#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
int32
ifx_set_virtual_server_info_stub(int32 operation, VIRTUAL_SERVER * entry,
                                 uint32 flags)
{

    if(entry == NULL) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,
                    "MOD-API: Passed object has NULL Pointer !!! \n");
        return IFX_SUCCESS;
    }

    if(operation == IFX_OP_ADD) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "MOD-API: Add operation \n");
    }
    else if(operation == IFX_OP_DEL) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "MOD-API: Del operation \n");

    }
    else if(operation == IFX_OP_MOD) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,
                    "MOD-API: Modify operation \n");
    }
    else {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "MOD-API: GET operation \n");
    }

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "MOD-API: NAT_VIRTUAL_ENABLE=%d\n",
                flags);
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "MOD-API: NAT_VIRTUAL_Cpeid=%d\n",
                entry->iid.cpeId.Id);
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "MOD-API: NAT_VIRTUAL_Tr69id=%s\n",
                entry->iid.tr69Id);
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "MOD-API: NAT_VIRTUAL_Owner=%d\n",
                entry->iid.owner);
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,
                "MOD-API: NAT_VIRTUAL_LEASE = %d\n", entry->lease_duration);
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,
                "MOD-API: NAT_VIRTUAL_REMOTEIP = %s\n",
                inet_ntoa(entry->remote_ip));
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,
                "MOD-API: NAT_VIRTUAL_PUB_SPORT = %d\n", entry->public_sport);
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,
                "MOD-API: NAT_VIRTUAL_PRIV_SPORT = %d\n", entry->private_sport);
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,
                "MOD-API: NAT_VIRTUAL_PUB_EPORT = %d\n", entry->public_eport);
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,
                "MOD-API: NAT_VIRTUAL_PRIV_EPORT = %d\n", entry->private_eport);
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,
                "MOD-API: NAT_VIRTUAL_PROTO = %d\n", entry->protocol);
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,
                "MOD-API: NAT_VIRTUAL_CONNAME = %s\n", entry->wan_conn_if);
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,
                "MOD-API: NAT_VIRTUAL_PRIV_IP = %s\n",
                inet_ntoa(entry->private_ip));
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "MOD-API: NAT_VIRTUAL_DESC = %s\n",
                entry->vs_desc);

    return IFX_SUCCESS;
}
#endif

static int32
IFX_GetWanIpPortMapObj(VIRTUAL_SERVER * ppxWanIpPortMap, uint32 iCpeid)
{
    uint32 iRet = 0;
    ppxWanIpPortMap->iid.cpeId.Id = iCpeid;
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
    int32 uiNumOfEntries = 0;
    uint32 iFlags;
    VIRTUAL_SERVER *paxWan_IpPortMaps = NULL;
    iRet =
        ifx_get_virtual_server_info_stub(&uiNumOfEntries, &paxWan_IpPortMaps,
                                         iFlags);
#else
    iRet = ifx_get_one_virtual_server_info(ppxWanIpPortMap);
#endif

    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d ifx_get_virtual_server_info failed!\n", __func__,
                    __LINE__);
        goto errorHandler;
    }
    return IFX_CWMP_SUCCESS;

  errorHandler:

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed!\n", __func__, __LINE__);
    return IFIN_CWMP_FAILURE;

}



static int32
IFX_ConvertArrToWanIpPortCfgStruct(IN uint32 iElements,
                                   IN ParamVal * paxParamVal,
                                   OUT VIRTUAL_SERVER * pxWan_IpPortMap)
{
    uint32 i = 0;
    int32 iRet = 0;
    uint32 uiParamPos = 0;

    uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);

    for(i = 0; i < iElements; i++) {

        switch (paxParamVal->iaOID[uiParamPos]) {

            case OID_IGD_WAND_WANCD_WANIPC_PM_PORTMAPPINGENABLED:

                if(IFX_FwdMappingValues(gaxEnable, 4,
                                        (void *)(paxParamVal->Value),
                                        (void *)&(pxWan_IpPortMap->f_enable)) !=
                   IFIN_CWMP_SUCCESS) {
                    iRet = ERR_CWMP_INVAL_PARAM_VAL;
                    goto errorHandler;
                }
                break;

            case OID_IGD_WAND_WANCD_WANIPC_PM_PORTMAPPINGLEASEDURATION:
                lease_flag = 1;
                pxWan_IpPortMap->lease_duration = atoi(paxParamVal->Value);

                break;

            case OID_IGD_WAND_WANCD_WANIPC_PM_REMOTEHOST:
                if(strcmp((char8 *) paxParamVal->Value, "") == 0) {
                    memset(&(pxWan_IpPortMap->remote_ip), 0,
                           sizeof(struct in_addr));
                }
                else {
                    if((inet_aton(paxParamVal->Value,
                                  &(pxWan_IpPortMap->remote_ip))) == 0) {
                        iRet = ERR_CWMP_INVAL_PARAM_VAL;
                        goto errorHandler;
                    }
                }
                break;
            case OID_IGD_WAND_WANCD_WANIPC_PM_EXTERNALPORT:
                pxWan_IpPortMap->public_sport = atoi(paxParamVal->Value);
                break;
            case OID_IGD_WAND_WANCD_WANIPC_PM_INTERNALPORT:
                pxWan_IpPortMap->private_sport = atoi(paxParamVal->Value);
                break;
                // case OID_IGD_WAND_WANCD_WANIPC_PM_X_AC9A96_EXTERNALPORT_MAX:
            case OID_IGD_WAND_WANCD_WANIPC_PM_EXTERNALPORTENDRANGE:
                pxWan_IpPortMap->public_eport = atoi(paxParamVal->Value);
                break;
            case OID_IGD_WAND_WANCD_WANIPC_PM_X_AC9A96_INTERNALPORT_MAX:
                pxWan_IpPortMap->private_eport = atoi(paxParamVal->Value);
                break;
            case OID_IGD_WAND_WANCD_WANIPC_PM_PORTMAPPINGPROTOCOL:
                if(IFX_FwdMappingValues(saxWanIpPortMapProto, 3,
                                        (void *)(paxParamVal->Value),
                                        (void *)&(pxWan_IpPortMap->protocol)) !=
                   IFIN_CWMP_SUCCESS) {
                    iRet = ERR_CWMP_INVAL_PARAM_VAL;
                    goto errorHandler;
                }
                break;
                break;
            case OID_IGD_WAND_WANCD_WANIPC_PM_INTERNALCLIENT:

                if((inet_aton(paxParamVal->Value,
                              &(pxWan_IpPortMap->private_ip))) == 0) {
                    iRet = ERR_CWMP_INVAL_PARAM_VAL;
                    goto errorHandler;
                }

                break;
            case OID_IGD_WAND_WANCD_WANIPC_PM_PORTMAPPINGDESCRIPTION:
                strncpy(pxWan_IpPortMap->vs_desc, paxParamVal->Value,
                        (MAX_VS_DESC_LEN - 1));

                break;


            default:
                break;


        }


        ++paxParamVal;

    }

    return IFIN_CWMP_SUCCESS;

  errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed ParamID=%d Value=%s !\n", __func__, __LINE__,
                paxParamVal->iaOID[uiParamPos], (char8 *) paxParamVal->Value);
    return iRet;

}




/* 
** =============================================================================
**   Function Name    : IFX_WanIpPortMapGetValue
**   Description        : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes                : 
**
** ============================================================================
*/
static int32
IFX_WanIpPortMapGetValue(IN OperInfo * pxOperInfo,
                         INOUT ParamVal * pxGetParamVal, IN uint32 iElements)
{
    /* GET PARAMETER VALUES **Get Object OID(skip parameter ID) from the first
       **element in the array.Get Cpeid for this Object OID

       **Get the object from the system using a Platform API **with cpeid

       **Do reverse mapping to convert system values into TR69 **Values.After
       conversion stores the values in temp storage

       **While assigning the values as per request store the **values in heap
       and assign the ptr to the struct **Return all the values */

#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
    uint32 iFlags = 0;
#endif
    uint32 iCpeid = 0, i = 0;
    int32 iParamId = 0;
    uint32 uiParamPos = 0;
    // int32 iConType=0;
    int32 iRet = 0;
    // uchar8 sTemp[PARAMVALUE_LEN];
    VIRTUAL_SERVER xMatch_Wan_IpPortMap;
    memset(&xMatch_Wan_IpPortMap, 0x00, sizeof(xMatch_Wan_IpPortMap));
    VIRTUAL_SERVER *pxMatch_Wan_IpPortMap = &xMatch_Wan_IpPortMap;
    void *pvTmpBigVal = NULL;

    // Get Cpeid from object ID
    iRet = IFX_GetCpeId(pxGetParamVal->iaOID, &iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Get match object from system using Platform API
    iRet = IFX_GetWanIpPortMapObj(pxMatch_Wan_IpPortMap, iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Get the WanIpConParamPos 
    uiParamPos = IFX_GetParamIdPos(pxGetParamVal->iaOID);


    for(i = 0; i < iElements; i++) {

        iParamId = pxGetParamVal->iaOID[uiParamPos];

        // Malloc and assign the pointer to the Value attr of struct 
        pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
        if(pxGetParamVal->Value == NULL) {
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }
        switch (iParamId) {

                // Convert the value - reverse mapping
                // Assign the correct value to the Value attr 
            case OID_IGD_WAND_WANCD_WANIPC_PM_PORTMAPPINGENABLED:

                if(IFX_RevMappingValues(gaxEnable, 4,
                                        (void *)&(pxMatch_Wan_IpPortMap->
                                                  f_enable),
                                        (void *)(pxGetParamVal->Value)) !=
                   IFX_CWMP_SUCCESS)

                    goto errorHandler;
                break;

            case OID_IGD_WAND_WANCD_WANIPC_PM_PORTMAPPINGLEASEDURATION:
                sprintf(pxGetParamVal->Value, "%d",
                        pxMatch_Wan_IpPortMap->lease_duration);
                break;

            case OID_IGD_WAND_WANCD_WANIPC_PM_REMOTEHOST:
                strncpy((char8 *) pxGetParamVal->Value,
                        inet_ntoa(pxMatch_Wan_IpPortMap->remote_ip),
                        (MAX_IP_ADDRRESS_LEN - 1));

                // To handle wildcard as value 
                if(strcmp((char8 *) pxGetParamVal->Value, "0.0.0.0") == 0)
                    memset(pxGetParamVal->Value, '\0', PARAMVALUE_LEN);

                break;

            case OID_IGD_WAND_WANCD_WANIPC_PM_EXTERNALPORT:
                sprintf(pxGetParamVal->Value, "%d",
                        pxMatch_Wan_IpPortMap->public_sport);
                break;
            case OID_IGD_WAND_WANCD_WANIPC_PM_INTERNALPORT:
                sprintf(pxGetParamVal->Value, "%d",
                        pxMatch_Wan_IpPortMap->private_sport);
                break;
                // case OID_IGD_WAND_WANCD_WANIPC_PM_X_AC9A96_EXTERNALPORT_MAX:
            case OID_IGD_WAND_WANCD_WANIPC_PM_EXTERNALPORTENDRANGE:
                sprintf(pxGetParamVal->Value, "%d",
                        pxMatch_Wan_IpPortMap->public_eport);
                break;
            case OID_IGD_WAND_WANCD_WANIPC_PM_X_AC9A96_INTERNALPORT_MAX:
                sprintf(pxGetParamVal->Value, "%d",
                        pxMatch_Wan_IpPortMap->private_eport);
                break;
            case OID_IGD_WAND_WANCD_WANIPC_PM_PORTMAPPINGPROTOCOL:
                if(IFX_RevMappingValues(saxWanIpPortMapProto, 3,
                                        (void *)&(pxMatch_Wan_IpPortMap->
                                                  protocol),
                                        (void *)(pxGetParamVal->Value)) !=
                   IFX_CWMP_SUCCESS)
                    goto errorHandler;

                break;
            case OID_IGD_WAND_WANCD_WANIPC_PM_INTERNALCLIENT:
                strncpy((char8 *) pxGetParamVal->Value,
                        inet_ntoa(pxMatch_Wan_IpPortMap->private_ip),
                        (MAX_IP_ADDRRESS_LEN - 1));
                break;

            case OID_IGD_WAND_WANCD_WANIPC_PM_PORTMAPPINGDESCRIPTION:
                pvTmpBigVal =
                    IFX_CWMP_REALLOC(pxGetParamVal->Value, MAX_VS_DESC_LEN);
                if(pvTmpBigVal != NULL)
                    pxGetParamVal->Value = pvTmpBigVal;
                strncpy((char8 *) pxGetParamVal->Value,
                        pxMatch_Wan_IpPortMap->vs_desc, (MAX_VS_DESC_LEN - 1));
                break;


            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "Invalid param id %d!\n", iParamId);
                pxGetParamVal->iFaultCode = ERR_INVAL_PARAMETER_VAL;
                break;
        }


        ++pxGetParamVal;
    }
    return IFX_CWMP_SUCCESS;

  errorHandler:
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
    ifx_set_virtual_server_info_stub(pxOperInfo->iOper, pxMatch_Wan_IpPortMap,
                                     iFlags);
#endif
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed ParamId=%d!\n", __func__, __LINE__, iParamId);
    return IFIN_CWMP_FAILURE;


}

/* 
** =============================================================================
**   Function Name    : IFX_WanIpPortMapSetValidate
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanIpPortMapSetValidate(IN OperInfo * pxOpInfo,
                            INOUT ParamVal * paxParamVal, IN int32 iElements)
{
    /* 
     ** Instance check,Data_Type(1- RO,RW check,2- Int,char,etc
     ** 3- String length) check and range_Check(Min,Max) will 
     ** be handled by the controller.
     */

    // Dependency check between parameters and objects should 
    // be handled by this API.This can't be done unless
    // enable is issued by the ACS.

    // Get Cpeid
    // Get the obj from system
    // If it is enabled if we try to modify following parameters return error
    // If it is disabled call IFX_MappingValues functions to check if correct
    // values 
    // are passed.

    int32 iRet = IFX_CWMP_SUCCESS;
    uint32 uiCpeid = 0;
    VIRTUAL_SERVER xMatch_Wan_IpPortMap;
    memset(&xMatch_Wan_IpPortMap, 0x00, sizeof(xMatch_Wan_IpPortMap));
    VIRTUAL_SERVER *pxMatch_Wan_IpPortMap = &xMatch_Wan_IpPortMap;

    // Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(paxParamVal->iaOID, &uiCpeid);
    if(iRet != IFIN_CWMP_SUCCESS)
        goto errorHandler;

    // Get the object from system
    iRet = IFX_GetWanIpPortMapObj(pxMatch_Wan_IpPortMap, uiCpeid);
    if(iRet != IFIN_CWMP_SUCCESS)
        goto errorHandler;

    return IFIN_CWMP_SUCCESS;

  errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed!\n", __func__, __LINE__);
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanIpPortMapAddObj
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanIpPortMapAddObj(IN OperInfo * pxOpInfo, INOUT ParamVal * pxParamVal,
                       IN int32 iElements)
{

    /* This API calls a Platform API which adds the object ** in ADD_DISABLE
       state. ** Pass necessary flags to the API ** Controller should get the
       next instance id from DS ** module and pass the full OID to this
       module. */

    /* If Cisco proposal comes, this API should handle ** a) Validation of
       values ** b) Forward mapping of TR69 values to system values ** c)
       addition of object into the system */

    // Fill the ATM_VCC_INFO struct and call the respective
    // ifx_add_atm_vcc api to add the entry in disabled state
    // Forward mapping is required if it has some valid values

    uint32 iFlags = 0;
    int32 iRet = 0;
    uint32 iOper;
    uint32 uiPcpeId = 0;
    VIRTUAL_SERVER xWan_IpPortMap;

    memset(&xWan_IpPortMap, 0, sizeof(xWan_IpPortMap));

    iRet = IFX_GetParentObjCpeId(pxParamVal->iaOID, &uiPcpeId);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    iRet =
        IFX_ConvertArrToWanIpPortCfgStruct(iElements, pxParamVal,
                                           &xWan_IpPortMap);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Flags should be filled
    // Fills the Cpeid,ParentCepid,TR69Id,Owner
    // Fill the operation

    iOper = IFX_OP_ADD;
    iFlags = (IFX_F_DONT_ACTIVATE | IFX_F_DONT_CHECKPOINT |
              IFX_F_DONT_VALIDATE | IFX_F_DONT_WRITE_TO_FLASH);

    if(pxParamVal[0].iaOID[5] == OID_IGD_WAND_WANCD_WANPPPC) {
        strcpy(xWan_IpPortMap.iid.pcpeId.secName, "wan_ppp");
    }
    else if(pxParamVal[0].iaOID[5] == OID_IGD_WAND_WANCD_WANIPC) {
        strcpy(xWan_IpPortMap.iid.pcpeId.secName, "wan_ip");
    }
    else {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "Error\n");
        goto errorHandler;
    }

    xWan_IpPortMap.iid.config_owner = pxOpInfo->iCaller;
    xWan_IpPortMap.iid.owner = pxOpInfo->iCaller;
    xWan_IpPortMap.iid.cpeId.Id = 0;
    xWan_IpPortMap.iid.pcpeId.Id = uiPcpeId;
    xWan_IpPortMap.f_enable = IFX_DISABLED;

    // Convert array into dotted form and then strcpy

    iRet =
        IFX_ConvertOidDottedForm(pxParamVal->iaOID, xWan_IpPortMap.iid.tr69Id);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
    // Print the values
    ifx_set_virtual_server_info_stub(iOper, &xWan_IpPortMap, iFlags);

#else
    iRet = ifx_set_virtual_server_info(iOper, &xWan_IpPortMap, iFlags);
#endif
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "ifx_set_virtual_server_info Add Mgmt API returned error\n");
        goto errorHandler;

    }

    return IFIN_CWMP_SUCCESS;

  errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d failed!\n", __func__,
                __LINE__);
    return IFIN_CWMP_FAILURE;

}

/* 
** =============================================================================
**   Function Name    : IFX_WanIpConSetValue
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanIpPortMapSetValue(IN OperInfo * pxOpInfo, INOUT ParamVal * paxParamVal,
                         IN int32 iElements)
{

    // It can support only one state change in a SET operation.
    // Enabled to Disabled, Disabled to Enabled 

    // Get the Cpeid
    // Get the object from the system
    // Get the state(Enable/Disbale) of the object

    // Handle CHECK_MODIFY_DEP
    // Check if the state change is allowed or not

    // Handle MODIFY 
    // Get the old state
    // Forward mapping of values

    // Modify Enabled object
    // Modify Disabled object
    // Modify the disabled object and enable that object.
    // Diable the object and modify it.


    uint32 uiCpeid = 0;
    uint32 uiOld_EnableVal = 0;
    VIRTUAL_SERVER xMatch_Wan_IpPortMap;
    memset(&xMatch_Wan_IpPortMap, 0x00, sizeof(xMatch_Wan_IpPortMap));
    VIRTUAL_SERVER *pxMatch_Wan_IpPortMap = &xMatch_Wan_IpPortMap;
    int32 iRet = IFX_CWMP_SUCCESS;
    uint32 iOper = 0, iFlags = 0, uiParamPos = 0;
    uint32 uiPcpeId = 0;

    // For parent related info
    uint32 uiOutElem = 0;
    uint32 uiDep_Enable = 0;
    ParamVal axInParamArr;
    ParamVal *paxOutParamArr = NULL;
    int32 Wan_PPP_Con_Enable_OID[OID_LENGTH] =
        { 0, 0, 0, 0, 0, OID_IGD_WAND_WANCD_WANPPPC,
        MAGIC_NUMBER, OID_IGD_WAND_WANCD_WANPPPC_ENABLE
    };

    int32 Wan_IP_Con_Enable_OID[OID_LENGTH] =
        { 0, 0, 0, 0, 0, OID_IGD_WAND_WANCD_WANIPC,
        MAGIC_NUMBER, OID_IGD_WAND_WANCD_WANIPC_ENABLE
    };

    // Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(paxParamVal->iaOID, &uiCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Get the object from system
    iRet = IFX_GetWanIpPortMapObj(pxMatch_Wan_IpPortMap, uiCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;


    // Get the WanIpConParamPos 
    uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);

    uiOld_EnableVal = pxMatch_Wan_IpPortMap->f_enable;

    // Modify on top of old values.
    iRet =
        IFX_ConvertArrToWanIpPortCfgStruct(iElements, paxParamVal,
                                           pxMatch_Wan_IpPortMap);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    switch (pxOpInfo->iSubOper) {

        case OP_SETVAL_CHK_MODIFY_DEP:

            break;

        case OP_SETVAL_MODIFY:
            // Check for WanIp or WanPPP Enable value

            memset(&axInParamArr, 0x00, sizeof(ParamVal));

            if(paxParamVal->iaOID[5] == OID_IGD_WAND_WANCD_WANPPPC) {
                memcpy(axInParamArr.iaOID, Wan_PPP_Con_Enable_OID,
                       (sizeof(int32) * OID_LENGTH));
            }
            else {
                memcpy(axInParamArr.iaOID, Wan_IP_Con_Enable_OID,
                       (sizeof(int32) * OID_LENGTH));
            }
            memcpy(axInParamArr.iaOID, paxParamVal->iaOID,
                   (sizeof(int32) * (uiParamPos - 2)));

            iRet = IFX_GlobalGetVal(&axInParamArr, &paxOutParamArr, &uiOutElem);
            if(iRet != IFX_CWMP_SUCCESS) {
                IFX_PrintOID(axInParamArr.iaOID);
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d IFX_GlobalGetVal failed!\n", __func__,
                            __LINE__);
                goto ChkModifyDepErrorHandler;
            }


            if(uiOutElem > 0) {

                if((iRet = IFX_FwdMappingValues(gaxEnable, 4,
                                                (void *)(paxOutParamArr->Value),
                                                (void *)&(uiDep_Enable))) !=
                   IFX_CWMP_SUCCESS)
                    goto ChkModifyDepErrorHandler;

                if(uiDep_Enable == IFX_DISABLED) {

                    if(pxMatch_Wan_IpPortMap->f_enable == IFX_ENABLED) {

                        iRet = ERR_CWMP_INVAL_PARAM_VAL;
                        goto ChkModifyDepErrorHandler;

                    }
                }

            }
            // Free the value field inside structs and array of structs


          ChkModifyDepErrorHandler:
            IFX_FreeParamvalArr(&paxOutParamArr, uiOutElem);

            if(iRet != IFX_CWMP_SUCCESS)
                goto errorHandler;




            // Modify Enabled object
            // Modify Disabled object
            // Modify the disabled object and enable that object.
            // Diable the object and modify it.
            // Based on state transition call the Mgmt API with respective 
            // flags 

            if(uiOld_EnableVal == IFX_ENABLED) {

                if(pxMatch_Wan_IpPortMap->f_enable == IFX_DISABLED) {
                    // Call with deactivate and modify flags 
                    iFlags = (IFX_F_DEACTIVATE | IFX_F_MODIFY |
                              IFX_F_DONT_CHECKPOINT | IFX_F_DONT_VALIDATE |
                              IFX_F_DONT_WRITE_TO_FLASH);

                    pxMatch_Wan_IpPortMap->f_enable = IFX_DISABLED;


                }
                else if(pxMatch_Wan_IpPortMap->f_enable == IFX_ENABLED) {
                    // Call the API with Modify flags
                    iFlags = (IFX_F_MODIFY |
                              IFX_F_DONT_CHECKPOINT |
                              IFX_F_DONT_WRITE_TO_FLASH);
                    pxMatch_Wan_IpPortMap->f_enable = IFX_ENABLED;
                }

            }
            else if(uiOld_EnableVal == IFX_DISABLED) {

                if(pxMatch_Wan_IpPortMap->f_enable == IFX_DISABLED) {
                    // Call with don't activate and modify
                    iFlags = (IFX_F_DONT_ACTIVATE | IFX_F_MODIFY |
                              IFX_F_DONT_CHECKPOINT | IFX_F_DONT_VALIDATE |
                              IFX_F_DONT_WRITE_TO_FLASH);

                    pxMatch_Wan_IpPortMap->f_enable = IFX_DISABLED;

                }
                else if(pxMatch_Wan_IpPortMap->f_enable == IFX_ENABLED) {
                    // Call the API with Modify
                    iFlags = (IFX_F_MODIFY |
                              IFX_F_DONT_CHECKPOINT |
                              IFX_F_DONT_WRITE_TO_FLASH);
                    pxMatch_Wan_IpPortMap->f_enable = IFX_ENABLED;
                }

            }

            // Try to pass the Parent Cpeid instead of WanConnName
            // ##change is made to handle both WanIp and WanPPP portmapping
            // obects

            iRet = IFX_GetParentObjCpeId(paxParamVal->iaOID, &uiPcpeId);
            if(iRet != IFX_CWMP_SUCCESS)
                goto errorHandler;


            // Fills the Cpeid,ParentCepid,TR69Id,Owner
            pxMatch_Wan_IpPortMap->iid.cpeId.Id = uiCpeid;
            pxMatch_Wan_IpPortMap->iid.config_owner = pxOpInfo->iCaller;
            pxMatch_Wan_IpPortMap->iid.owner = pxOpInfo->iCaller;
            pxMatch_Wan_IpPortMap->iid.pcpeId.Id = uiPcpeId;
            // pxMatch_Atm_Vcc.iid.tr69ID=

            iOper = IFX_OP_MOD;
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
            ifx_set_virtual_server_info_stub(iOper, pxMatch_Wan_IpPortMap,
                                             iFlags);
#else
            iRet =
                ifx_set_virtual_server_info(iOper, pxMatch_Wan_IpPortMap,
                                            iFlags);
#endif
            if(iRet != IFX_SUCCESS) {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "ifx_set_virtual_server_info -Modify Mgmt API returned error\n");
                goto errorHandler;

            }
            if(lease_flag == 1) {
                iRet =
                    Lease_Duration_Timer_Start(pxMatch_Wan_IpPortMap->
                                               lease_duration,
                                               pxMatch_Wan_IpPortMap->iid.cpeId.
                                               Id);
                if(iRet != IFX_SUCCESS) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "Lease_Duration_Timer_Start failed\n");
                    goto errorHandler;

                }

            }

            break;

        default:
            break;

    }

  errorHandler:
    lease_flag = 0;
    if(iRet != IFIN_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d failed!\n", __func__, __LINE__);
        return iRet;
    }
    return IFIN_CWMP_SUCCESS;

}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslSetCommit
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanIpPortMapSetCommit()
{
    return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslSetUndo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanIpPortMapSetUndo()
{
    return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanIpConSetDelete
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanIpPortMapSetDelete(IN OperInfo * pxOpInfo, INOUT ParamVal * paxParamVal,
                          IN int32 iElements, OUT void **ppxParamStructRet,
                          OUT int32 * piNumRetElem)
{

    uint32 uiCpeid = 0, uiPcCpeid = 0;
    VIRTUAL_SERVER xMatch_Wan_IpPortMap;
    memset(&xMatch_Wan_IpPortMap, 0x00, sizeof(xMatch_Wan_IpPortMap));
    VIRTUAL_SERVER *pxMatch_Wan_IpPortMap = &xMatch_Wan_IpPortMap;
    int32 iRet = 0;
    uint32 iOper = 0, iFlags = 0;
    uint32 uiParamPos = 0;
    ParamVal *Param_DepOids = NULL;


    if(pxOpInfo->iSubOper == OP_SETVAL_CHK_DEL_DEP) {
        uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);
        Param_DepOids = IFIN_CWMP_MALLOC(sizeof(ParamVal));
        if(Param_DepOids == NULL) {
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }
        memcpy((Param_DepOids)->iaOID, paxParamVal->iaOID,
               (sizeof(int32) * (uiParamPos + 1)));
        *ppxParamStructRet = (void *)Param_DepOids;
        *piNumRetElem = 1;
        return IFIN_CWMP_SUCCESS;
    }
    // Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(paxParamVal->iaOID, &uiCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    iRet = IFX_GetParentObjCpeId(paxParamVal->iaOID, &uiPcCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Get the object from system
    iRet = IFX_GetWanIpPortMapObj(pxMatch_Wan_IpPortMap, uiCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;


    switch (pxOpInfo->iSubOper) {
        case OP_SETVAL_CHK_DEL_ALLOWED:
            // handle CHK_DELETE_ALLOWED
            // Check for default instance if del is called by TR69
            // if(pxMatch_Atm_Vcc->f_default == IFX_DEFAULT)
            // goto errorHandler;

            break;
        case OP_SETVAL_DELETE:
            // handle DELETE operation
            // Call Platform API to delete the obj in the system
            // If del is called by web we need to pass special owner for which
            // API 
            // will not post a message.

            pxMatch_Wan_IpPortMap->iid.config_owner = pxOpInfo->iCaller;
            pxMatch_Wan_IpPortMap->iid.owner = pxOpInfo->iCaller;
            pxMatch_Wan_IpPortMap->iid.cpeId.Id = uiCpeid;
            pxMatch_Wan_IpPortMap->iid.pcpeId.Id = uiPcCpeid;
            memset(pxMatch_Wan_IpPortMap->iid.tr69Id, 0x00, MAX_TR69_ID_LEN);
            iOper = IFX_OP_DEL;
            iFlags = (IFX_F_DELETE | IFX_F_DONT_VALIDATE |
                      IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH);
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
            ifx_set_virtual_server_info_stub(iOper, pxMatch_Wan_IpPortMap,
                                             iFlags);
#else
            iRet =
                ifx_set_virtual_server_info(iOper, pxMatch_Wan_IpPortMap,
                                            iFlags);
#endif

            if(iRet != IFX_SUCCESS) {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "ifx_set_virtual_server_info -Delete Mgmt API returned error\n");
                goto errorHandler;

            }
            break;

        default:
            break;
    }
    return IFIN_CWMP_SUCCESS;

  errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed!\n", __func__, __LINE__);
    return IFIN_CWMP_FAILURE;

}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslSetFree
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanIpPortMapSetFree()
{
    return IFX_CWMP_SUCCESS;
}


/* 
** =============================================================================
**   Function Name    : IFX_WanIpPortMapSetAttr
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

int32
IFX_WanIpPortMapSetAttr(IN OperInfo * pxOpInfo, INOUT ParamVal * pxParamVal,
                        IN int32 iElements)
{
    uint32 iRet = IFX_CWMP_SUCCESS, i = 0;
    OperInfo xOpInfo;

    xOpInfo.iCaller = pxOpInfo->iCaller;
    xOpInfo.iOper = OP_GETVAL;
    xOpInfo.iSubOper = OP_GETVAL_NORMAL;

    iRet = IFX_WanIpPortMapGetValue(&xOpInfo, pxParamVal, iElements);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorFreeHandler;

    iRet = IFX_SetAttributesInfo(pxOpInfo, pxParamVal, iElements);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorFreeHandler;

  errorFreeHandler:
    for(i = 0; i < iElements; i++)
        IFX_CWMP_FREE(pxParamVal[i].Value);

    if(iRet)
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d failed!\n", __func__, __LINE__);
    return iRet;
}




/* 
** =============================================================================
**   Function Name    : IFX_WanIpPortMapping_Init
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_WanIpPortMapping_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;


    /* Register the WanIpPortMapping module function pointer in the object
       model */
    iRet =
        ifx_ds_register_function(IFX_WAN_IP_PORTMAP_OBJ, IFX_WanIpPortMapping);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "Unable to Register %s with Object Model\n",
                    IFX_WAN_IP_PORTMAP_OBJ);
        goto errorHandler;
    }


    /* Register the WanPPPPortMapping module function pointer in the object
       model */
    iRet =
        ifx_ds_register_function(IFX_WAN_PPP_PORTMAP_OBJ, IFX_WanIpPortMapping);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "Unable to Register %s with Object Model\n",
                    IFX_WAN_PPP_PORTMAP_OBJ);
        goto errorHandler;
    }


  errorHandler:
    return iRet;
}

/*********************************************************************************
*  Function Name	:  IFX_WanIpPortMapping   
      *  Description	:  This function handles all the sub-states inside
      	 		   a GET/SET operation.If it is a GET it allocates the 
			   array(Name,Value pairs) and retruns the values.
			   If it is a SET controller allocates the array and
			   passes the values to this function.It calls 
			   respective internal functions which in turn calls 
			   respective Platform APIs.
                                                                                                 
*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
							     Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has 
					  	             Name,Value,etc
                    IN          int32	       iElements;    No. of Elements
		    OUT	        void *	       ppParamRet;   same as ParamStruc
		    OUT         int32 *        piNumRetElem; No. of elements 		                                
*  Return Value        : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes               :
***********************************************************************************/
int32
IFX_WanIpPortMapping(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                     IN int32 iElements, OUT void **ppaxParamArrRet,
                     OUT int32 * piNumRetElem)
{

    // It calls the respective internal functions which handles resp.
    // sub-operation

    // Set-Operation 
    // controller should pass the entire array during all the
    // SET-sub_operations
    // It should handles only single get/set of instance at any point of time
    // It does not handle partial path
    // It won't handle multiple instances of the same object/module
    // at any point of time.


    int32 iRet = 0;
    ParamVal *paxParamArr = (ParamVal *) paxParameterArr;

    switch (pxOperInfo->iOper) {
            // Get the object values
        case OP_GETVAL:
            if((iRet = IFX_WanIpPortMapGetValue(pxOperInfo, paxParamArr,
                                                iElements)) !=
               IFX_CWMP_SUCCESS) {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
                goto errorHandler;
            }
            break;
        case OP_SETVAL:
            {

                // Set the obj values
                switch (pxOperInfo->iSubOper) {
                    case OP_SETVAL_VALIDATE:
                        if((iRet =
                            IFX_WanIpPortMapSetValidate(pxOperInfo, paxParamArr,
                                                        iElements)) !=
                           IFX_CWMP_SUCCESS) {
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                        "%s:%d OP_SET_VALIDATE failed!\n",
                                        __func__, __LINE__);
                            goto errorHandler;
                        }

                        break;
                    case OP_SETVAL_ADD:

                        if((iRet =
                            IFX_WanIpPortMapAddObj(pxOperInfo, paxParamArr,
                                                   iElements)) !=
                           IFX_CWMP_SUCCESS) {
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                        "%s:%d OP_SETVAL_ADD failed!\n",
                                        __func__, __LINE__);
                            goto errorHandler;
                        }
                        break;
                    case OP_SETVAL_CHK_MODIFY_DEP:
                    case OP_SETVAL_MODIFY:
                        if((iRet =
                            IFX_WanIpPortMapSetValue(pxOperInfo, paxParamArr,
                                                     iElements)) !=
                           IFX_CWMP_SUCCESS) {
                            switch (pxOperInfo->iSubOper) {
                                case OP_SETVAL_CHK_MODIFY_DEP:
                                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                                "%s:%d OP_SETVAL_CHK_MODIFY_DEP failed!\n",
                                                __func__, __LINE__);
                                    goto errorHandler;

                                case OP_SETVAL_MODIFY:
                                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                                "%s:%d OP_SETVAL_MODIFY failed!\n",
                                                __func__, __LINE__);
                                    goto errorHandler;
                            }
                        }
                        break;
                    case OP_SETVAL_COMMIT:
                        if((iRet =
                            IFX_WanIpPortMapSetCommit(pxOperInfo, paxParamArr,
                                                      iElements)) !=
                           IFX_CWMP_SUCCESS) {
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                        "%s:%d OP_SETVAL_COMMIT failed!\n",
                                        __func__, __LINE__);
                            goto errorHandler;
                        }
                        break;
                    case OP_SETVAL_UNDO:
                        if((iRet =
                            IFX_WanIpPortMapSetUndo(pxOperInfo, paxParamArr,
                                                    iElements)) !=
                           IFX_CWMP_SUCCESS) {
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                        "%s:%d OP_SETVAL_UNDO failed!\n",
                                        __func__, __LINE__);
                            goto errorHandler;
                        }
                        break;
                    case OP_SETVAL_CHK_DEL_DEP:
                    case OP_SETVAL_CHK_DEL_ALLOWED:
                    case OP_SETVAL_DELETE:
                        if((iRet =
                            IFX_WanIpPortMapSetDelete(pxOperInfo, paxParamArr,
                                                      iElements,
                                                      ppaxParamArrRet,
                                                      piNumRetElem)) !=
                           IFX_CWMP_SUCCESS) {

                            switch (pxOperInfo->iSubOper) {
                                case OP_SETVAL_CHK_DEL_DEP:
                                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                                "%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n",
                                                __func__, __LINE__);
                                    goto errorHandler;
                                case OP_SETVAL_CHK_DEL_ALLOWED:
                                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                                "%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n",
                                                __func__, __LINE__);
                                    goto errorHandler;
                                case OP_SETVAL_DELETE:
                                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                                "%s:%d OP_SETVAL_DELETE failed!\n",
                                                __func__, __LINE__);
                                    goto errorHandler;
                            }
                        }
                        break;
                    case OP_SETVAL_FREE:
                        IFX_WanIpPortMapSetFree(pxOperInfo);
                        break;
                    case OP_SETVAL_ATTRINFO:
                        if((iRet =
                            IFX_WanIpPortMapSetAttr(pxOperInfo, paxParamArr,
                                                    iElements)) !=
                           IFX_CWMP_SUCCESS) {
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                        "%s:%d OP_SETVAL_ATTRINFO failed!\n",
                                        __func__, __LINE__);
                            goto errorHandler;
                        }
                        break;

                    default:
                        break;
                }
                break;
            }
        case OP_PARAM_VALIDATE:
            {
                break;
            }
        default:
            break;
    }
    return IFX_CWMP_SUCCESS;

  errorHandler:
    return IFX_CWMP_FAILURE;

}



int32
Lease_Duration_Timer_Start(int32 lease_duration, int32 cpeId)
{

    int i, pos = -1, blank_pos = -1;
    uint32 uiErr;
    int32 iId;
    long int t1 = 0;

    for(i = 0; i < lease_num_entries; i++) {

        if(cpeId == leaseTimeArr[i][0]) {
            pos = i;
            break;
        }

        if(leaseTimeArr[i][0] == 0)
            blank_pos = i;
    }


    // cpe id not in list
    if(pos == -1) {
        if(lease_duration != 0) {
            // Blank entry found within lease_num_entries 
            if(blank_pos != -1)
                pos = blank_pos;
            // Blank entry not found within lease_num_entries. Need a new
            // position and increment lease_num_entries
            else {
                if(lease_num_entries != 20)
                    pos = lease_num_entries++;
                else
                    goto Handler;
            }
        }
        else {
            /* cpe id not in list and lease duration is 0. Need to check for
               the cpe id in the list because if there is a previously stored
               entry then we ignore the deletion of that entry. handled below. */
            goto Handler;
        }
    }
    else if(pos != -1)          // cpe id found in list
    {
        if(lease_duration == 0) // No need to delete this entry anymore.
        {
            leaseTimeArr[pos][0] = 0;
            leaseTimeArr[pos][1] = 0;
            goto Handler;
        }
    }

    t1 = time(NULL);
    leaseTimeArr[pos][0] = cpeId;
    leaseTimeArr[pos][1] = t1 + lease_duration;


    iId = TM_PORTMAPPINGLEASE_TIMER_ID;

    if(IFIN_TR69_StartTimer((lease_duration * 1000), (void *)IFX_CWMP_TimerCB,
                            (void *)iId, &guiTimerId,
                            &uiErr) != IFIN_TR69_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] Error starting TimerId %d\n", __FILE__,
                    __func__, __LINE__, iId);
        return (IFX_CWMP_FAILURE);
    }
    else {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                    "[%s:%s:%d] Started Portmapping Lease  Timer-> ID = %d\n",
                    __FILE__, __func__, __LINE__, guiTimerId);
        return (IFX_CWMP_SUCCESS);
    }

  Handler:
    return IFX_SUCCESS;
}

int32
Lease_Duration_Exipry()
{
    int i;
    long int t2;
    IFX_Id xId;
    int32 iaOID[OID_LENGTH];
    int32 iRet = IFX_CWMP_SUCCESS;
    char *psName = NULL;
    char *pos = NULL;

    t2 = time(NULL);

    for(i = 0; i < lease_num_entries; i++) {
        if((leaseTimeArr[i][1] <= t2) && (leaseTimeArr[i][1] != 0)) {
            memset(&xId, 0x00, sizeof(xId));
            xId.xCpeId.uiId = leaseTimeArr[i][0];
            strcpy(xId.xCpeId.sSectionTag, "nat_virtualser");
            iRet = IFX_GetTr69IdFromCpeId(&xId);
            if(iRet != IFX_SUCCESS) {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] IFX_GetTr69IdFromCpeId\n",
                            __FILE__, __func__, __LINE__);
                goto Handler;
            }

            memset(&iaOID, 0x00, OID_LENGTH);
            sscanf(xId.sTr69Id, "%d.%d.%d.%d.%d.%d.%d.%d.%d", &(iaOID[0]),
                   &(iaOID[1]), &(iaOID[2]), &(iaOID[3]), &(iaOID[4]),
                   &(iaOID[5]), &(iaOID[6]), &(iaOID[7]), &(iaOID[8]));

            iRet = IFX_GetNameFromOID(iaOID, &psName);
            if(iRet != IFX_SUCCESS) {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] IFX_GetNameFromOID\n",
                            __FILE__, __func__, __LINE__);
                goto Handler;
            }

            pos = strstr(psName, "PortMapping");
            pos += 12;
            pos = strchr(pos, '.');
            *(pos + 1) = '\0';

            iRet = ifx_config_del_obj(psName);
            if(iRet != IFX_SUCCESS) {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] ifx_config_del_obj failed\n",
                            __FILE__, __func__, __LINE__);
                goto Handler;
            }
            leaseTimeArr[i][0] = 0;
            leaseTimeArr[i][1] = 0;
        }
    }

  Handler:
    IFX_CWMP_FREE(psName);
    return iRet;
}
