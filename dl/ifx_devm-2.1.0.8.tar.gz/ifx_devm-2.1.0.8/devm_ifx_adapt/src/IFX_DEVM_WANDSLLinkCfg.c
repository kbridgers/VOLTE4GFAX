/* 
** =============================================================================
**   FILE NAME        : IFX_WanDslLinkConfig.c
**   PROJECT          : TR69
**   MODULES          : WanDevice
**   DATE             : 28-04-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This module handles ADD/DEL/GET/SET RPCs of
**                      WanDslLinkConfig. When controller calls this module it
**                      calls respective Platform/Object APIs to handle GET/SET 
**                      of WanDslLinkConfig specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author        $Comment
**   28-04-06         TR69 team      Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_Global.h"
#include "IFX_DEVM_AdaptCommon.h"
#include "IFX_DEVM_WANDSLLinkCfg.h"
 
#include "IFX_DEVM_WANDSLIfaceCfg.h"
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_StackUtil.h"
 

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;

#define WAN_DSL_LINK_DEPTH 6
#define IFX_WANDSL_LINK_OBJ "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANDSLLinkConfig."
extern int32 ifx_set_wan_conn_dev_stub(int32 operation, WAN_CONN_DEV * xWanConDev, int32 iFlags);
extern int32 IFX_WanIpConSetValue(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
                            IN int32 iElements);
extern int32 IFX_WanPPPConSetValue(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
                            IN int32 iElements);

//#define WAN_CON_DEV_DEPTH 4
//#define MAX_VAL_LENGTH 24
/*
#define CWMP_REVERSE_MAP 1
#define CWMP_FORWARD_MAP 2
#define SYS_DATATYPE_INT 1
#define SYS_DATATYPE_CHAR 2
#define OID_CHAR_LENGTH (OID_LENGTH * 10)
*/
/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/

//STATIC uchar8 WanDslLink_Oid[OID_LENGTH]={"OID_IGD.OID_IGD_WAND.1.OID_IGD_WAND_WANCD.1.OID_IGD_WAND_WANCD_WANDSLLC."};
//static uint32 stiWanDslLink_Dep=7;


extern Map_Value gaxEnable[];

//static Map_Value saxDslLnkStatus[]={
//                 {"Up",SYS_DATATYPE_INT,{.uiSys_Value =IFX_ENABLED}},
//                 {"Down",SYS_DATATYPE_INT,{.uiSys_Value =IFX_DISABLED}}
//                 };

Map_Value saxDslLnkType[] ={
                 {"Unconfigured",SYS_DATATYPE_INT,{.uiSys_Value 
                 =LINK_TYPE_UNCONFIGURED}},
                 {"EoA",SYS_DATATYPE_INT,{.uiSys_Value =LINK_TYPE_EOATM}},
                 {"IPoA",SYS_DATATYPE_INT,{.uiSys_Value =LINK_TYPE_IPOATM}},
                 {"PPPoA",SYS_DATATYPE_INT,{.uiSys_Value =LINK_TYPE_PPPOATM}},
                 {"EoA",SYS_DATATYPE_INT,{.uiSys_Value =LINK_TYPE_PPPOE}},
                 {"CIP",SYS_DATATYPE_INT,{.uiSys_Value =LINK_TYPE_CLIP}},
                 {" ",SYS_DATATYPE_INT,{.uiSys_Value =LINK_TYPE_UNCONFIGURED}}
                };

static Map_Value saxDslLnkEncap[]={
                  {"VCMUX",SYS_DATATYPE_INT,{.uiSys_Value =VC_ENCAP_VCMUX}},
                  {"LLC",SYS_DATATYPE_INT,{.uiSys_Value =VC_ENCAP_LLC}},
                  {" ",SYS_DATATYPE_INT,{.uiSys_Value =VC_ENCAP_VCMUX}}
                 };

static Map_Value saxDslLnkAal[] = {
                 {"AAL0",SYS_DATATYPE_INT,{.uiSys_Value =AAL_TYPE_AAL0}},
                 {"AAL1",SYS_DATATYPE_INT,{.uiSys_Value =AAL_TYPE_AAL1}},
                 {"AAL2",SYS_DATATYPE_INT,{.uiSys_Value =AAL_TYPE_AAL2}},
                 {"AAL3",SYS_DATATYPE_INT,{.uiSys_Value =AAL_TYPE_AAL3}},
                 {"AAL4",SYS_DATATYPE_INT,{.uiSys_Value =AAL_TYPE_AAL4}},
                 {"AAL5",SYS_DATATYPE_INT,{.uiSys_Value =AAL_TYPE_AAL5}},
                 {" ", SYS_DATATYPE_INT,{.uiSys_Value =AAL_TYPE_AAL5}}
                };

static Map_Value saxDslLnkQos[] = {
                 {"UBR",SYS_DATATYPE_UCHAR,{.ucSys_Value =ATM_UBR}},
                 {"CBR",SYS_DATATYPE_UCHAR,{.ucSys_Value =ATM_CBR}},
//                 {"ABR",SYS_DATATYPE_UCHAR,{.ucSys_Value =ATM_ABR}},
                 {"VBR-nrt",SYS_DATATYPE_UCHAR,{.ucSys_Value =ATM_VBR_NRT}},
                 {"VBR-rt",SYS_DATATYPE_UCHAR,{.ucSys_Value =ATM_VBR_RT}},
                 {"UBR+",SYS_DATATYPE_UCHAR,{.ucSys_Value =ATM_UBR_PLUS}},
                 {" ",SYS_DATATYPE_UCHAR,{.ucSys_Value =ATM_NONE}}
                };
                 
static Map_Value saxDslLnkStatus[] = {
                 {"Up",SYS_DATATYPE_INT,{.uiSys_Value =DSL_LINK_STATUS_UP}},
                 {"Down",SYS_DATATYPE_INT,{.uiSys_Value =DSL_LINK_STATUS_DOWN}},
                 {"Initializing",SYS_DATATYPE_INT,{.uiSys_Value =DSL_LINK_STATUS_INITIALIZE}},
                 {"Unavailable",SYS_DATATYPE_INT,{.uiSys_Value =DSL_LINK_STATUS_UNAVAILABLE}},
                };
                                  

/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/

#ifdef IFX_TR69_WAN_MODS_TEST_STUBS

int32 ifx_set_vcc_cfg_stub(int32 operation, ATM_VCC_INFO *entry, uint32 flags)
{

    if(entry == NULL)
    {
       IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Passed object has NULL Pointer !!! \n");
       return IFX_SUCCESS;
    }
if(operation == IFX_OP_ADD)
{
     IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Add operation \n");
 }else if(operation == IFX_OP_DEL)
 {
     IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Del operation \n");
        
 }else if (operation == IFX_OP_MOD)
     {
         IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Modify operation \n");
     }else     
     {
     IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: GET operation \n");
     }
 
 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: VCC_INFO_ENABLE=%d\n",flags);
 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: VCC_INFO_TYPE = %d\n", entry->type);
 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: VCC_INFO_AAL = %d\n", entry->aal);
 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: VCC_INFO_ENCAP = %d\n", entry->encap);
 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: VCC_INFO_VPI = %d\n", entry->vc.pvc.vpi);
 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: VCC_INFO_VCI = %d\n", entry->vc.pvc.vci);
 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: VCC_INFO_Cpeid = %d\n",entry->iid.cpeId.Id);
 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: VCC_INFO_pCpeid = %d\n",entry->iid.pcpeId.Id);
 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: VCC_INFO_Config_Owner = %d\n",entry->iid.config_owner);
 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: VCC_INFO_TR69_id = %s\n", entry->iid.tr69Id);
 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: VCC_INFO_Traffic_Class = %d\n", entry->txtp.traffic_class);
 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: VCC_INFO_max_pcr = %d\n", entry->txtp.max_pcr);
// IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: VCC_INFO_mbs = %d\n", entry->txtp.mbs);
//  IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: VCC_INFO_cdv = %d\n", entry->txtp.cdv);
//  IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: VCC_INFO_scr = %d\n", entry->txtp.scr);
 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: VCC_INFO_min_pcr = %d\n", entry->txtp.min_pcr);

  //memcpy(&StubVcc,entry,sizeof(ATM_VCC_INFO));
  return IFX_SUCCESS;

}
#endif

/* 
** =============================================================================
**   Function Name    : GetParamOffset
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

STATIC int32
GetParamOffset(IN int32 *paiOID)
{
    int32 iCnt;

    for (iCnt = 0; paiOID[iCnt] != 0; iCnt++);

    return (iCnt - 1);
}


int32 
IFX_SetVCCWanAtmF5LoopBackDiags(int32 *iaOIDDSL,int32 iCaller, int16 Vpi,int32 Vci)
{

    WAN_ATMF5_LOOP_DIAGNOSTICS xWan_Atm_Diag;
    uint32 uiParamPos=0;
        int32 iaOID[OID_LENGTH];
    int32 iRet=IFX_CWMP_SUCCESS;
    uint32 uiFlags=0;
    uint32 uiCpeid=0;
    int32 iOper=0;    

    //Form the WanATMF5LoopBack obj oid
    memset(&xWan_Atm_Diag, 0x00, sizeof(WAN_ATMF5_LOOP_DIAGNOSTICS));    
    memset(iaOID, 0x00, (sizeof(int32)*OID_LENGTH));

        
    uiParamPos = IFX_GetParamIdPos(iaOIDDSL);
    memcpy(iaOID,iaOIDDSL,(sizeof(int32)*uiParamPos));
    iaOID[(uiParamPos-1)] = OID_IGD_WAND_WANCD_WANATMF5LD;         
    iaOID[uiParamPos] = OID_IGD_WAND_WANCD_WANATMF5LD_DIAGNOSTICSSTATE;         

    //Get the Cpeid
    iRet = IFX_GetCpeId(iaOID,&uiCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d Failed !\n", __func__, __LINE__);
        goto errorHandler;
    }    

    //Update the VCC values in WanATMF5LoopBack obj
    xWan_Atm_Diag.iid.cpeId.Id =uiCpeid;
    uiFlags = IFX_F_GET_ANY;
    
    // Get match object from system using Platform API
#ifdef MIPSTARGET
       iRet = ifx_get_atmf5_loop_diagnostics(&xWan_Atm_Diag, uiFlags);    
#endif
        if(iRet != IFX_CWMP_SUCCESS)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d Failed !\n", __func__, __LINE__);
            goto errorHandler;
        }
    
        uiFlags= (IFX_F_MODIFY|
        IFX_F_DONT_CHECKPOINT|
        IFX_F_DONT_WRITE_TO_FLASH);
        
        xWan_Atm_Diag.vpi=Vpi;
        xWan_Atm_Diag.vci=Vci;

        xWan_Atm_Diag.iid.cpeId.Id=uiCpeid;
        xWan_Atm_Diag.iid.config_owner=iCaller;
        iOper = IFX_OP_MOD;


#ifdef MIPSTARGET
        iRet = ifx_set_atmf5_loop_diagnostics(iOper, &xWan_Atm_Diag, uiFlags);
#endif
        if(iRet != IFX_SUCCESS)
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "ifx_set_atmf5_loop_diagnostics -Modify Mgmt API returned error\n");
                goto errorHandler;
                
            }

    return IFX_CWMP_SUCCESS;    
    
    errorHandler:
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed!\n", __func__, __LINE__);
        return iRet;

}

int32 
IFX_GetWanConnectionEnable(int32 *iaOIDDSL,int32 *iaOID,uint32 *uiEnable)
{
    int32 iRet=IFX_CWMP_SUCCESS;
    uint32 i=0,iJ=0;    
    ParamVal xInParamVal;
    uint32 uiOutElem=0;
    ParamVal *paxOutParamArr=NULL;
    ParamVal *paxTempParamVal=NULL;

    int32 Wan_IP_Enable_Oid[OID_LENGTH]={
                            0,0,0,0,0,OID_IGD_WAND_WANCD_WANIPC,
                            MAGIC_NUMBER,OID_IGD_WAND_WANCD_WANIPC_ENABLE};
    int32 Wan_ppp_Enable_Oid[OID_LENGTH]={
                            0,0,0,0,0,OID_IGD_WAND_WANCD_WANPPPC,
                            MAGIC_NUMBER,OID_IGD_WAND_WANCD_WANPPPC_ENABLE};

    //Get the WanConnection Oid
    for(i=0; i <2; ++i)
    {
        memset(&xInParamVal, 0x00, sizeof(ParamVal));
       
        if(i == 0 )
        {
            memcpy(xInParamVal.iaOID,Wan_IP_Enable_Oid, (sizeof(int32)*OID_LENGTH));
        }
        else
        {
            memcpy(xInParamVal.iaOID,Wan_ppp_Enable_Oid, (sizeof(int32)*OID_LENGTH));
        }
        //Copy the OID from ParamVal
        memcpy(xInParamVal.iaOID,iaOIDDSL, (sizeof(int32)*(WAN_CON_DEV_DEPTH +1)));
        
        //Get the WanIpConnection/WanPPPConnection objects
        iRet=IFX_GlobalGetVal(&xInParamVal, &paxOutParamArr, &uiOutElem);
        if(iRet != IFX_CWMP_SUCCESS)
        {
            IFX_PrintOID(xInParamVal.iaOID);
            IFX_FreeParamvalArr(&paxOutParamArr, uiOutElem);
            iRet = IFX_CWMP_SUCCESS;
            continue;
        }
         
        paxTempParamVal = paxOutParamArr;
        if(paxTempParamVal != NULL)
        {
            for(iJ=0; iJ < uiOutElem; ++iJ) 
            {
                //Get the Dependent WanConnection Oid & Enable parameter Value
                memcpy(iaOID,paxTempParamVal->iaOID,(sizeof(int32)*OID_LENGTH));
                IFX_GetParamIdPos(iaOID);
                if((iRet  = IFX_FwdMappingValues(gaxEnable, 4,
	                        (void *)(paxTempParamVal->Value),    
        	                (void *)uiEnable)) !=IFX_CWMP_SUCCESS)
                {
                    goto ChkModifyDepErrorHandler;
                    break;
                }
		else
		{
                    break;
                }
            }
        }
    }

    IFX_FreeParamvalArr(&paxOutParamArr,uiOutElem);
    return iRet;

ChkModifyDepErrorHandler:
    IFX_FreeParamvalArr(&paxOutParamArr,uiOutElem);
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d failed!\n", __func__, __LINE__);
    return iRet;        
}
int32
IFX_SetWanConnection(int32 *iaOIDDSL, int32 iCaller, int32 state)
{
    int32 iaOID[OID_LENGTH];
    uint32 uiEnable=0;
    ParamVal xInParamVal;
    OperInfo xOper;
    int32 uiParamPos=0;
    char8 sEnable[10]={0};
    int32 iRet = IFX_CWMP_SUCCESS;

    memset(iaOID, 0x00, (sizeof(int32)*OID_LENGTH));
    memset(&xInParamVal, 0x00, sizeof(ParamVal));
    memset(&xOper, 0x00, sizeof(OperInfo));

    //Get the WanConnections available on top of this WanDslLinkConfig
    iRet = IFX_GetWanConnectionEnable(iaOIDDSL,iaOID,&uiEnable);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    //If there are no WanConnection on the top ret success
    uiParamPos =  IFX_GetParamIdPos(iaOID);
    if(uiParamPos <= 1)
    {
       return IFX_CWMP_SUCCESS;
    }

    memcpy(xInParamVal.iaOID,iaOID,(sizeof(int32)*OID_LENGTH));
    if(uiEnable == IFX_ENABLED)
    {
        strcpy(sEnable,"True");
    }
    else
    {
        strcpy(sEnable,"False");
    }
    xInParamVal.Value = sEnable;

    xOper.iOper = OP_SETVAL;
    xOper.iSubOper = state;
    xOper.iCaller =  iCaller;
    
    //Call the IFX_WanIpConnSetValue or IFX_WanPPPConnSetValue based on the states
    if(iaOID[uiParamPos-2] == OID_IGD_WAND_WANCD_WANPPPC)
    {
    iRet = IFX_WanPPPConSetValue(&xOper,&xInParamVal,1);

    } else {    
    iRet = IFX_WanIpConSetValue(&xOper,&xInParamVal,1);

    }

    if((iRet < IFX_CWMP_SUCCESS) || (iRet == IFX_CWMP_NEED_REBOOT_DONT_SAVE))
        goto errorHandler;
    

    return iRet;

    errorHandler:
             IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed!\n", __func__, __LINE__);
              return iRet;        
        
}

int32 
IFX_ValidateDestAddr(char8 *dest_addr,int16 *Vpi,int32 *Vci)
{
                                                                                                 
         char8 sVCC_Type[MAX_DATA_LEN]={0};
         char8 *pstemp=NULL;
     char8 *psTmpVal=NULL;
         int i=0;              
         char8 sTmpDestAddr[PARAMVALUE_LEN]={0};

    if(dest_addr != NULL)
        strcpy(sTmpDestAddr,dest_addr);
    else
        goto errorHandler;    
        
        if((pstemp = strtok(sTmpDestAddr," :"))!= NULL)
            strcpy(sVCC_Type,pstemp);
    else
        goto errorHandler;

        if((pstemp = strtok(NULL,":\n"))!= NULL)
        {
         // To remove null char in the begining of the string
            while((*pstemp == 32) && (i <  32))
                {
                        pstemp = pstemp + 1;
                        ++i;
                }
        } else
            goto errorHandler;
       
      
      if((psTmpVal = strtok(pstemp,"/"))!= NULL)
          *Vpi =atoi(psTmpVal);
      else
          goto errorHandler;
      
       
      if((psTmpVal = strtok(NULL,"\n")) != NULL)
          *Vci =atoi(psTmpVal);
      else
          goto errorHandler;

    //To validate the range of Vpi and Vci

    if(( *Vpi < 0) || (*Vpi > 255) || (*Vci < 0) || (*Vci > 65535))
    {
            
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                          "Invalid destination address\n");
          goto errorHandler;
    }    
      
        if(strcmp(sVCC_Type,"SVC")==0)
        {       
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                          "Invalid destination address\n");
          goto errorHandler;
        
        }else if(strcmp(sVCC_Type,"PVC")==0)
        {

                return IFIN_CWMP_SUCCESS;
    
    }

    errorHandler:
         IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed \n", __func__, __LINE__);
         if(dest_addr != NULL)
         IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "dest_addr=%s \n",dest_addr);
        return IFIN_CWMP_FAILURE;
        
}


    
static int32 
IFX_GetVccObj(ATM_VCC_INFO *ppxAtmVcc, uint32 iCpeid)
{
    uint32 iRet=0;
    ppxAtmVcc->iid.cpeId.Id=iCpeid;
        
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
    int uiNumOfEntries = 0;
    ATM_VCC_INFO *paxAtm_Vccs=NULL;
    iRet=ifx_get_all_vcc_info_stub(&uiNumOfEntries, &paxAtm_Vccs,iFlags);    
#else
    iRet=ifx_get_one_vcc_info(ppxAtmVcc);    
#endif

    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d ifx_get_all_vcc_info failed!\n", __func__, __LINE__);
        goto errorHandler;
    }
    return IFX_CWMP_SUCCESS;    
errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed!\n", __func__, __LINE__);
    return IFIN_CWMP_FAILURE;
}

static int32 
IFX_ConvertArrToVccStruct(IN uint32 iElements, IN ParamVal *paxParamVal,
                                                OUT ATM_VCC_INFO *pxAtm_vcc)
{
    uint32 i;
    int32 iRet;
    char8 usDestAddr[PARAMVALUE_LEN]={0};
    
    for (i=0; i < iElements; i++) 
    {

              switch(paxParamVal->iaOID[WAN_DSL_LINK_DEPTH])
        {

                case OID_IGD_WAND_WANCD_WANDSLLC_ENABLE:

                    if(IFX_FwdMappingValues(gaxEnable,4,
                            (void *)(paxParamVal->Value),
                            (void *)&(pxAtm_vcc->f_enable)) !=IFIN_CWMP_SUCCESS)
                    {
                        iRet=ERR_CWMP_INVAL_PARAM_VAL;
                        goto errorHandler;
                    }
                    break;

                case OID_IGD_WAND_WANCD_WANDSLLC_LINKTYPE:
                    if(IFX_FwdMappingValues(saxDslLnkType,7,
                            (void *)(paxParamVal->Value),
                            (void *)&(pxAtm_vcc->type)) !=IFIN_CWMP_SUCCESS)
                    {
                        iRet=ERR_CWMP_INVAL_PARAM_VAL;
                        goto errorHandler;
                    }
                    break;

        
                case OID_IGD_WAND_WANCD_WANDSLLC_DESTINATIONADDRESS:
                        //call the function to get the VPI/VCI
                    strcpy(usDestAddr,(char8 *)paxParamVal->Value);
                    if(IFX_ValidateDestAddr(usDestAddr,
                            (int16 *)&(pxAtm_vcc->vc.pvc.vpi),
                            (int32 *)&(pxAtm_vcc->vc.pvc.vci))
                                        !=IFIN_CWMP_SUCCESS)
                    {
                        iRet=ERR_CWMP_INVAL_PARAM_VAL;
                        goto errorHandler;
                    }
                    break;

                
                case OID_IGD_WAND_WANCD_WANDSLLC_ATMENCAPSULATION: 
                    if(IFX_FwdMappingValues(saxDslLnkEncap,3,
                            (void *)(paxParamVal->Value),
                            (void *)&(pxAtm_vcc->encap)) !=IFIN_CWMP_SUCCESS)
                    {
                        iRet=ERR_CWMP_INVAL_PARAM_VAL;
                        goto errorHandler;
                    }
                    break;
                    
                case OID_IGD_WAND_WANCD_WANDSLLC_FCSPRESERVED: 
                    pxAtm_vcc->fcs_preserved=atoi(paxParamVal->Value);
                    break;

                case OID_IGD_WAND_WANCD_WANDSLLC_ATMQOS:
                    if(IFX_FwdMappingValues(saxDslLnkQos,6,
                        (void *)(paxParamVal->Value),
                        (void *)&(pxAtm_vcc->txtp.traffic_class)) !=IFIN_CWMP_SUCCESS)
                    {
                        iRet=ERR_CWMP_INVAL_PARAM_VAL;
                        goto errorHandler;
                    }
                    pxAtm_vcc->txtp.traffic_class = pxAtm_vcc->txtp.traffic_class;
                    break;
                    
                case OID_IGD_WAND_WANCD_WANDSLLC_ATMPEAKCELLRATE:
                    pxAtm_vcc->txtp.max_pcr = atoi(paxParamVal->Value);
                    break;

                case OID_IGD_WAND_WANCD_WANDSLLC_ATMMAXIMUMBURSTSIZE:
#ifdef MIPSTARGET
                     pxAtm_vcc->txtp.mbs = atoi(paxParamVal->Value);
#endif
                    break; 

                case OID_IGD_WAND_WANCD_WANDSLLC_ATMSUSTAINABLECELLRATE:
#ifdef MIPSTARGET
                     pxAtm_vcc->txtp.scr = atoi(paxParamVal->Value);
#endif
                    break; 
                    
                default:
                    break;
        }
        ++paxParamVal;
    }

    return IFIN_CWMP_SUCCESS;
    
errorHandler:
         IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d failed ParamID = %d Value =%s !\n", __func__, __LINE__,
				                    paxParamVal->iaOID[WAN_DSL_LINK_DEPTH],(char8 *)paxParamVal->Value);
        return iRet;
}


/* 
** =============================================================================
**   Function Name    : IFX_WanDslLinkGetValue
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 
IFX_WanDslLinkGetValue(IN OperInfo *pxOperInfo,INOUT ParamVal *pxGetParamVal,
                                IN uint32 iElements)
{
    /*GET PARAMETER VALUES
    **Get Object OID(skip parameter ID) from the first 
    **element in the array.Get Cpeid for this Object OID

    **Get the object from the system using a Platform API
    **with cpeid 
    
    **Do reverse mapping to convert system values into TR69
    **Values.After conversion stores the values in temp storage

    **While assigning the values as per request store the 
    **values in heap and assign the ptr to the struct
    **Return all the values 
    */
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
    uint32 iFlags=0;
#endif
    uint32 iCpeid=0,i=0;
    int32 iParamId=0;
    int32 iRet=0;
    char8 sTemp[PARAMVALUE_LEN]={0};
    ATM_VCC_INFO xMatch_Atm_Vcc;
    memset(&xMatch_Atm_Vcc,0x00,sizeof(xMatch_Atm_Vcc));
    ATM_VCC_INFO *pxMatch_Atm_Vcc=&xMatch_Atm_Vcc;
    uint32 uiMode=IFX_CHK_VALUE_BASED;
    DSL_LINE_PHY_PROPERTIES xDslphys;

    memset(&xDslphys, 0x00, sizeof(xDslphys));    
    //Fill the parameters and pass it back
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
    iRet = ifx_get_dsl_phy_properties(&xDslphys);
    if(iRet != IFX_SUCCESS)
        goto errorHandler;
    
#endif
  
    // Get Cpeid from object ID
    iRet = IFX_GetCpeId(pxGetParamVal->iaOID,&iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Get match object from system using Platform API
    iRet= IFX_GetVccObj(pxMatch_Atm_Vcc, iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    //Get ATM VCC related stats
    //ifx_get_atm_stats(wan_indx, atm_stats, flags);
    //Cpeid should be used instead of Wan_indx
    for(i=0;i < iElements; i++)
    {

        
    iParamId = pxGetParamVal->iaOID[WAN_DSL_LINK_DEPTH];
    
    // Malloc and assign the pointer to the Value attr of struct 
    pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
    if(pxGetParamVal->Value == NULL)
    {
        iRet = ERR_OUT_OF_MEMORY; 
        goto errorHandler;
    }
        switch(iParamId)
        {
            // Convert the value - reverse mapping
            // Assign the correct value to the Value attr    
            case OID_IGD_WAND_WANCD_WANDSLLC_ENABLE:
                if(IFX_RevMappingValues(gaxEnable,4,
                            (void *)&(pxMatch_Atm_Vcc->f_enable),
                            (void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
                    
	                goto errorHandler;
                break;     
                    
            case OID_IGD_WAND_WANCD_WANDSLLC_LINKSTATUS:
                if(IFX_RevMappingValues(saxDslLnkStatus,4,
                            (void *)&(pxMatch_Atm_Vcc->link_status),
                            (void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
	                goto errorHandler;
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;     

            case OID_IGD_WAND_WANCD_WANDSLLC_LINKTYPE:     
                if(IFX_RevMappingValues(saxDslLnkType,7,
                        (void *)&(pxMatch_Atm_Vcc->type),
                        (void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
	                goto errorHandler;
                break;
            
            case OID_IGD_WAND_WANCD_WANDSLLC_MODULATIONTYPE:
                strcpy(pxGetParamVal->Value,xDslphys.DslModType);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANCD_WANDSLLC_DESTINATIONADDRESS:
                sprintf(sTemp,"PVC: %d/%d",pxMatch_Atm_Vcc->vc.pvc.vpi,
                                          pxMatch_Atm_Vcc->vc.pvc.vci);
                strcpy(pxGetParamVal->Value,sTemp);                    
                break;
            
            case OID_IGD_WAND_WANCD_WANDSLLC_ATMENCAPSULATION:
                if(IFX_RevMappingValues(saxDslLnkEncap,3,
                        (void *)&(pxMatch_Atm_Vcc->encap),
                        (void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
	                goto errorHandler;        
                break;

            case OID_IGD_WAND_WANCD_WANDSLLC_FCSPRESERVED:
                sprintf(pxGetParamVal->Value,"%d",pxMatch_Atm_Vcc->fcs_preserved);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;
            
            case OID_IGD_WAND_WANCD_WANDSLLC_ATMAAL:                
                if(IFX_RevMappingValues(saxDslLnkAal,7,
                        (void *)&(pxMatch_Atm_Vcc->aal),
                        (void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
	                goto errorHandler;
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANCD_WANDSLLC_ATMQOS:
                if(IFX_RevMappingValues(saxDslLnkQos,6,
                        (void *)&(pxMatch_Atm_Vcc->txtp.traffic_class),
                        (void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
	                goto errorHandler;    
                break;
                
            case OID_IGD_WAND_WANCD_WANDSLLC_ATMPEAKCELLRATE:
                sprintf(sTemp,"%d",pxMatch_Atm_Vcc->txtp.max_pcr);
                strcpy(pxGetParamVal->Value,sTemp);
                break;

            case OID_IGD_WAND_WANCD_WANDSLLC_ATMMAXIMUMBURSTSIZE:
                //iRet = ERR_CWMP_INTERNAL;
#ifdef MIPSTARGET
                sprintf(sTemp,"%d",pxMatch_Atm_Vcc->txtp.mbs);
#endif
                strcpy(pxGetParamVal->Value,sTemp);
                break;

            case OID_IGD_WAND_WANCD_WANDSLLC_ATMSUSTAINABLECELLRATE:
#ifdef MIPSTARGET
                sprintf(sTemp,"%d",pxMatch_Atm_Vcc->txtp.scr);
#endif
                strcpy(pxGetParamVal->Value,sTemp);
                break;

            case OID_IGD_WAND_WANCD_WANDSLLC_AUTOCONFIG:
                sprintf(pxGetParamVal->Value,"%d",pxMatch_Atm_Vcc->autoconfig);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANCD_WANDSLLC_ATMTRANSMITTEDBLOCKS:
                sprintf(pxGetParamVal->Value,"%d",pxMatch_Atm_Vcc->tx_cells);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANCD_WANDSLLC_ATMRECEIVEDBLOCKS:
                sprintf(pxGetParamVal->Value,"%d",pxMatch_Atm_Vcc->rx_cells);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;

            case OID_IGD_WAND_WANCD_WANDSLLC_ATMCRCERRORS:
                sprintf(pxGetParamVal->Value,"%d",pxMatch_Atm_Vcc->crc_errors);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;
        
            case OID_IGD_WAND_WANCD_WANDSLLC_AAL5CRCERRORS:    
                 sprintf(pxGetParamVal->Value,"%d",0);
                 break;

            default:
	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "Invalid param id %d!\n", iParamId);
                pxGetParamVal->iFaultCode=ERR_INVAL_PARAMETER_VAL;
                break;
        }
        ++pxGetParamVal;
    }
    return IFX_CWMP_SUCCESS;
        
errorHandler:
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
    ifx_set_vcc_cfg_stub(pxOperInfo->iOper, pxMatch_Atm_Vcc, iFlags);
#endif
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d failed! ParamId = %d\n", __func__, __LINE__,iParamId);
    return IFIN_CWMP_FAILURE;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslLinkSetValidate
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanDslLinkSetValidate(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
                            IN int32 iElements)
{
    /*                                                                      
    ** Instance check,Data_Type(1- RO,RW check,2- Int,char,etc
    ** 3- String length) check and range_Check(Min,Max) will 
    ** be handled by the controller.
    */

    // Dependency check between parameters and objects should 
    // be handled by this API.This can't be done unless
    // enable is issued by the ACS.

    //Get Cpeid
    //Get the obj from system
    //If it is enabled if we try to modify following parameters return error
    //If it is disabled call IFX_MappingValues functions to check if correct values 
    //are passed.
    
    uint32 i=0;
    int32 iRet=IFX_CWMP_SUCCESS;
    uint32 uiCpeid=0;
    ParamVal *paxTempParamVal=NULL;
    int16 Vpi=0;
    int32 Vci=0;
    char8 usDestAddr[PARAMVALUE_LEN]={0};
    //uint32 uiNew_EnableVal=0;
    ATM_VCC_INFO xMatch_Atm_Vcc;
    memset(&xMatch_Atm_Vcc,0x00,sizeof(xMatch_Atm_Vcc));
    ATM_VCC_INFO *pxMatch_Atm_Vcc=&xMatch_Atm_Vcc;
    
    //Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(paxParamVal->iaOID,&uiCpeid);
    if(iRet != IFIN_CWMP_SUCCESS)
        goto errorHandler;

    //Get the object from system
    iRet= IFX_GetVccObj(pxMatch_Atm_Vcc, uiCpeid);
    if(iRet != IFIN_CWMP_SUCCESS)
        goto errorHandler;
    
        
    //If it is already enabled if we try to modify following parameters return error
    paxTempParamVal = paxParamVal;
    
        
        //If it is disabled call IFX_MappingValues functions to check if correct values 
        //are passed.
    
        for (i=0; i < iElements; i++)
        {
            if (paxTempParamVal->iaOID[WAN_DSL_LINK_DEPTH] == OID_IGD_WAND_WANCD_WANDSLLC_DESTINATIONADDRESS)
            {
                    strcpy(usDestAddr, (char8 *)paxTempParamVal->Value);
                    if(IFX_ValidateDestAddr(usDestAddr,&Vpi,&Vci) != IFIN_CWMP_SUCCESS)
                    {
                        iRet = ERR_CWMP_INVAL_PARAM_VAL;
                        goto errorHandler;
                    }
                    break;
            }
            paxTempParamVal++;
        }

    return IFIN_CWMP_SUCCESS;
errorHandler:
    if (paxTempParamVal)
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d failed ParamId=%d!\n", __func__, __LINE__,
					                    paxTempParamVal->iaOID[WAN_DSL_LINK_DEPTH]);
    else
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d failed\n", __func__, __LINE__);
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslLinkAddObj
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
    

static int32
IFX_WanDslLinkAddObj(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
                            IN int32 iElements)
{

    /* This API calls a Platform API which adds the object
    ** in ADD_DISABLE state.
    ** Pass necessary flags to the API
    ** Controller should get the next instance id from DS 
        ** module and pass the full OID to this module.
    */
        
    /* If Cisco proposal comes, this API should handle 
    **  a) Validation of values
    **  b) Forward mapping of TR69 values to system values 
    **  c) addition of object into the system
    */
    
    // Fill    the ATM_VCC_INFO struct and call the respective
    // ifx_add_atm_vcc api to add the entry in disabled state
    // Forward mapping is required if it has some valid values
    
    uint32 iFlags=0;
    int32 iRet=0, ret = 0;
    uint32 iOper;
    uint32 outFlag;
    uint32 uiPcpeId=0;
    char8 * retStr = NULL;
    char8 sCommand[MAX_FILELINE_LEN];
    char8 sValue[MAX_IF_NAME_LEN];
    char8 sVLAN_Obj[256] = {0};

    //int32 iaOID[OID_LENGTH];
    ATM_VCC_INFO xAtm_vcc;
    memset(&xAtm_vcc, 0, sizeof(xAtm_vcc));

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d!\n", __func__, __LINE__);
    //If owner is WEB don't add the object just return success.
    if(pxOpInfo->iCaller == ACC_WEB)
        return IFX_CWMP_SUCCESS;

    iRet = IFX_GetParentObjCpeId(pxParamVal->iaOID,&uiPcpeId);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;
    
    iRet = IFX_ConvertArrToVccStruct(iElements, pxParamVal, &xAtm_vcc);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;
        
    //Flags should be filled
    //Fills the Cpeid,ParentCepid,TR69Id,Owner
    //Fill the operation

    iOper = IFX_OP_ADD;
    iFlags =(    IFX_F_DONT_ACTIVATE|IFX_F_DONT_CHECKPOINT|
            IFX_F_DONT_VALIDATE|IFX_F_DONT_WRITE_TO_FLASH);
    
    xAtm_vcc.iid.config_owner=pxOpInfo->iCaller;
    xAtm_vcc.iid.cpeId.Id=0;
    xAtm_vcc.iid.pcpeId.Id=uiPcpeId;
    xAtm_vcc.f_enable = IFX_DISABLED;

	sprintf(sCommand, "%d", uiPcpeId);
	ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, "wan_conndev", "cpeId", sCommand, &retStr);
	if(ret != IFX_SUCCESS)
	{
    		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d!\n", __func__, __LINE__);
		goto errorHandler;
	}

	/* Get the l2ifacename */
	sprintf(sCommand, "%s_l2ifName", retStr);
	if((ret = ifx_GetObjData(FILE_RC_CONF, "wan_conndev", sCommand, IFX_F_GET_ANY, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS)
	{
    		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d!\n", __func__, __LINE__);
		goto errorHandler;
	}
	IFX_MEM_FREE(retStr)

    strcpy(xAtm_vcc.l2ifname, sValue);
    //Create a random VCC
    xAtm_vcc.vc.pvc.vci = devmrand();
    
    //Convert array into dotted form and then strcpy
    iRet = IFX_ConvertOidDottedForm(pxParamVal->iaOID, xAtm_vcc.iid.tr69Id);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    //Initialize the RO Parameters
     xAtm_vcc.aal=AAL_TYPE_AAL5;
    // xAtm_vcc.LinkStatus=DSL_LINK_STATUS_UNAVAILABLE;

#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
    
    ifx_set_vcc_cfg_stub(iOper, &xAtm_vcc, iFlags);
#else
    
    iRet = ifx_set_vcc_cfg(iOper, &xAtm_vcc, iFlags);
#endif

    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"ifx_set_vcc_cfg add Mgmt API \
                                                         returned error\n");
        goto errorHandler;
        
    }    

    //sprintf(sVLAN_Obj,"%sWANDSLLinkConfig.X_VLAN.", pxParamVal[0].Name);
    sprintf(sVLAN_Obj,"InternetGatewayDevice.WANDevice.1.WANConnectionDevice.%d.WANDSLLinkConfig.X_AC9A96_Vlan.", pxParamVal->iaOID[4]);

    iRet = ifx_config_add_obj(sVLAN_Obj);
    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] VLAN Object Add failed iRet[%d]\n", _FUNCL_, iRet);
        goto errorHandler;
    }
    return IFIN_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed!\n", __func__, __LINE__);
    return IFIN_CWMP_FAILURE;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslLinkSetValue
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanDslLinkSetValue(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
                            IN int32 iElements)
{

    //It can support only one state change in a SET operation.
    //Enabled to Disabled, Disabled to Enabled 
    
    //Get the Cpeid
    //Get the object from the system
    //Get the state(Enable/Disbale) of the object

    //Handle CHECK_MODIFY_DEP
    //Check if the state change is allowed or not

    //Handle MODIFY    
    //Get the old state
    //Forward mapping of values
    uint32 i=0, iJ = 0; 
    uint32 uiCpeid=0;
    uint32 uiOld_EnableVal=0;
    uint32 uiOld_LinkType=0;
    int32 iCnt=0;
#ifdef IFX_TR69_ADSLWAN
    ATM_VCC_INFO xMatch_Atm_Vcc;
    ATM_VCC_INFO *pxMatch_Atm_Vcc=&xMatch_Atm_Vcc;
#endif
    int32 iRet=0;
    uint32 iOper=0,iFlags=0;
    int32 iaOID[OID_LENGTH];
    uint32 uiDep_Enable=0;
    int32 Wan_IP_Enable_Oid[OID_LENGTH]={
                            0,0,0,0,0,OID_IGD_WAND_WANCD_WANIPC,
                            MAGIC_NUMBER,OID_IGD_WAND_WANCD_WANIPC_ENABLE};
    int32 Wan_ppp_Enable_Oid[OID_LENGTH]={
                            0,0,0,0,0,OID_IGD_WAND_WANCD_WANPPPC,
                            MAGIC_NUMBER,OID_IGD_WAND_WANCD_WANPPPC_ENABLE};
    uint32 uiOutElem=0;
    ParamVal axInParamArr;
    ParamVal *paxOutParamArr=NULL;
    ParamVal *paxTempParamVal=NULL;
    int32 iSetLinkType = 0;
    int32   iParamOffset = 0;
    int32 iChangeEnable = 0;
    int32 num_vlanchannels = 0;
    vlan_ch_cfg_t * xVlanArr = NULL;
    IFX_ID ParentIID;
    vlan_ch_cfg_t vlan_entry;

    memset(&iaOID,0x00,(sizeof(int32)*OID_LENGTH));
    memset(&ParentIID,0x00,sizeof(ParentIID));
    memset(&xMatch_Atm_Vcc,0x00,sizeof(xMatch_Atm_Vcc));
    memset(&vlan_entry,0x00,sizeof(vlan_entry));

    if(paxParamVal[0].iaOID[2] != WAN_DEVICE_ATM)
    {
        iRet = IFX_CWMP_SUCCESS;
        goto errorHandler;
    }

    //Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(paxParamVal->iaOID,&uiCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;
    
    //Get the object from system
    iRet= IFX_GetVccObj(pxMatch_Atm_Vcc, uiCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    
    uiOld_EnableVal = pxMatch_Atm_Vcc->f_enable;
    uiOld_LinkType  = pxMatch_Atm_Vcc->type;
    
    //Modify on top of old values.
    if(pxOpInfo->iSubOper != OP_SETVAL_ACTIVATE)
    {
        iRet=IFX_ConvertArrToVccStruct(iElements, paxParamVal, pxMatch_Atm_Vcc);          
        if(iRet != IFX_CWMP_SUCCESS)
            goto errorHandler;
    }

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(paxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
    
    switch(pxOpInfo->iSubOper)
    {
        case OP_SETVAL_CHK_MODIFY_DEP:
            /* Process based on the requested parameter */
            for(iCnt = 0; iCnt < iElements; iCnt++)
            {
                if((paxParamVal[iCnt]).iaOID[iParamOffset] == OID_IGD_WAND_WANCD_WANDSLLC_LINKTYPE)
		{
			iSetLinkType = 1;
		}
            }
            for(i=0; i <2; ++i)
            {
                /*Check if wanip/ppp connections are present on this WCD.
                  If present, the ip/ppp connections cannot be enabled while the WCD is disabled.
                  Disallow change in this case
                  Call global function to get the WanPPP/WanIP enable value
                  Pass Oid array with magic nos it should return 
                  OID,Name,Values,error_status */
                
                memset(&axInParamArr, 0x00, sizeof(ParamVal));
                if(i == 0 )
                {
                    memcpy(axInParamArr.iaOID,Wan_IP_Enable_Oid, (sizeof(int32)*OID_LENGTH));
                }
                else
                {
                    memcpy(axInParamArr.iaOID,Wan_ppp_Enable_Oid, (sizeof(int32)*OID_LENGTH));
                }
                //Copy the OID from ParamVal
                memcpy(axInParamArr.iaOID,paxParamVal->iaOID, (sizeof(int32)*(WAN_CON_DEV_DEPTH +1)));
                
                iRet=IFX_GlobalGetVal(&axInParamArr, &paxOutParamArr, &uiOutElem);
                if(iRet != IFX_CWMP_SUCCESS) 
                {
                    IFX_PrintOID(axInParamArr.iaOID);
                    IFX_FreeParamvalArr(&paxOutParamArr, uiOutElem);
                    iRet = IFX_CWMP_SUCCESS;
                    continue;
                }
                        
               //Based on state transition check whether Wan PPP/IPconnections
               //are in expected state
               paxTempParamVal = paxOutParamArr;
               if(paxTempParamVal != NULL)
               {
                   if(iSetLinkType == 1)
                   {
			/*Trying to set link type? Then cannot change the link type if connections are already present on
			this WCD. The type of IP/PPP connections created depends on the link type value
			LinkType = EoA - PPPoE, DHCP,Static,Bridge can be created
			LinkType = IPoA - DHCP, Static can be created
			LinkType = PPPoA - PPPoA can be created */
			/*Changing link type and enabling the DSLLC while Connec*/
                       if( uiOld_LinkType != pxMatch_Atm_Vcc->type) 
                       {
                           iRet=ERR_CWMP_INVAL_PARAM_VAL;
                           goto ChkModifyDepErrorHandler;
                       }
                   }
                   for(iJ=0; iJ < uiOutElem; iJ++) 
                   {
                       //Get the Dependent WanConnection Oid & Enable parameter Value
                       if((iRet  =IFX_FwdMappingValues(gaxEnable,4,
                               (void *)(paxTempParamVal->Value),    
                               (void *)&(uiDep_Enable))) != IFX_CWMP_SUCCESS)
                       {
                           iRet=ERR_CWMP_INVAL_PARAM_VAL;
                           goto ChkModifyDepErrorHandler;
                       }

                       
                        if(uiOld_EnableVal == IFX_ENABLED && (pxMatch_Atm_Vcc->f_enable == IFX_DISABLED))
                        {    
                               if(uiDep_Enable == IFX_ENABLED)
                               {
                                   iRet=ERR_CWMP_INVAL_PARAM_VAL;
                                   goto ChkModifyDepErrorHandler;
                               }
                               else
                               {
                                   continue;
                               }
                        }
                        
                        ++paxTempParamVal;
                    }
                }    
           
               iRet = IFX_FreeParamvalArr(&paxOutParamArr, uiOutElem);
               if(iRet != IFX_CWMP_SUCCESS)
                   goto errorHandler;
           }
           break;
           
           ChkModifyDepErrorHandler:
           IFX_FreeParamvalArr(&paxOutParamArr,uiOutElem);
                           
           if(iRet != IFX_CWMP_SUCCESS)
               goto errorHandler;
               
        case OP_SETVAL_MODIFY:
        case OP_SETVAL_ACTIVATE:
                
            //Modify Enabled object
            //Modify Disabled object
            //Modify the disabled object and enable that object.
            //Diable the object and modify it.
            //Based on state transition call the Mgmt API with respective 
            //flags    
            
            if(uiOld_EnableVal == IFX_ENABLED) 
            {
                if(pxMatch_Atm_Vcc->f_enable == IFX_DISABLED) 
                {
                    //Call with deactivate and modify flags 
                    iFlags= (IFX_F_DEACTIVATE|IFX_F_MODIFY|
                            IFX_F_DONT_CHECKPOINT|IFX_F_DONT_VALIDATE |
                            IFX_F_DONT_WRITE_TO_FLASH);
                    
                    pxMatch_Atm_Vcc->f_enable = IFX_DISABLED;
                    iChangeEnable = 1;
                    
                } 
                else if (pxMatch_Atm_Vcc->f_enable == IFX_ENABLED) 
                {
                    iFlags= (IFX_F_MODIFY|
                            IFX_F_DONT_CHECKPOINT|
                            IFX_F_DONT_WRITE_TO_FLASH);
                    pxMatch_Atm_Vcc->f_enable = IFX_ENABLED;
                }
            }
            else if (uiOld_EnableVal == IFX_DISABLED)
            {
                if(pxMatch_Atm_Vcc->f_enable == IFX_DISABLED) 
                {
                   //Call with don't activate and modify
                    iFlags= (IFX_F_DONT_ACTIVATE|IFX_F_MODIFY|
                       IFX_F_DONT_CHECKPOINT|IFX_F_DONT_VALIDATE|
                       IFX_F_DONT_WRITE_TO_FLASH);
                   
                       pxMatch_Atm_Vcc->f_enable = IFX_DISABLED;
                       
                }
                else if(pxMatch_Atm_Vcc->f_enable == IFX_ENABLED) 
                {
                    //Call the API with Modify
                    iFlags= (IFX_F_MODIFY|
                        IFX_F_DONT_CHECKPOINT|
                        IFX_F_DONT_WRITE_TO_FLASH);
 
                    pxMatch_Atm_Vcc->f_enable = IFX_ENABLED;
                    iChangeEnable = 1;
                }
            }
            /*
                     In Activate state/Modify state:
                        1) If Vpi/Vci is changed update the following
                            a) ifx_set_wan_conn_dev 
                            b) ifx_set_vcc_cfg
                            c) ifx_set_atmf5_loop_diagnostics
                            d) ifx_set_wan_atm_vcc_config (Pass IFX_F_DONT_ACTIVATE in OP_SETVAL_MODIFY 
                               if SetParameterValues=1)
                        2) If Any other value changed then update
                            a) ifx_set_vcc_cfg
                            b) ifx_set_wan_atm_vcc_config
            */
            if (pxOpInfo->iSubOper == OP_SETVAL_MODIFY)
            {

                iRet =  IFX_SetVCCWanConDevice(paxParamVal->iaOID, pxOpInfo->iCaller, 
                            pxMatch_Atm_Vcc->vc.pvc.vpi,pxMatch_Atm_Vcc->vc.pvc.vci, pxMatch_Atm_Vcc->l2ifname);
                if(iRet != IFX_CWMP_SUCCESS)
                    goto mapiErrorHandler;

                        
                // Update the VCC params in WanATMF5LoopBackDiag obj    
                iRet = IFX_SetVCCWanAtmF5LoopBackDiags(paxParamVal->iaOID, pxOpInfo->iCaller, 
                                            pxMatch_Atm_Vcc->vc.pvc.vpi,pxMatch_Atm_Vcc->vc.pvc.vci);
                if(iRet != IFX_CWMP_SUCCESS)
                    goto mapiErrorHandler;
        
                //Update the WanDslLinkConfig obj    
                //Pass some default values that will not be set by TR69
                pxMatch_Atm_Vcc->txtp.min_pcr=pxMatch_Atm_Vcc->txtp.max_pcr/6;
#ifdef MIPSTARGET
                pxMatch_Atm_Vcc->txtp.cdv=0;
#endif                
                //Fills the Cpeid,ParentCepid,TR69Id,Owner
                pxMatch_Atm_Vcc->iid.cpeId.Id=uiCpeid;
                pxMatch_Atm_Vcc->iid.config_owner=pxOpInfo->iCaller;
                iOper = IFX_OP_MOD;
                
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
                ifx_set_vcc_cfg_stub(iOper, pxMatch_Atm_Vcc, iFlags);
#else
                iRet = ifx_set_vcc_cfg(iOper, pxMatch_Atm_Vcc, iFlags);
#endif
                if(iRet != IFX_SUCCESS)
                {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "ifx_set_vcc_cfg -Modify Mgmt API returned error\n");
                    goto mapiErrorHandler;
                }    
                if(iChangeEnable == 1)
                {
                    /*Change the state of the underlying VLAN Channels*/
		    /* Get all underlying VLAN objects .
                       Change enable value. 
                       Set back the vlan_ch_entry
                    */
                    ParentIID.cpeId.Id = pxMatch_Atm_Vcc->iid.cpeId.Id;
                    strcpy(ParentIID.cpeId.secName, "adsl_vcchannel");
                
                    iRet = mapi_get_all_vlan_ch_entries_for_l2ch(&num_vlanchannels, &xVlanArr, &ParentIID, IFX_F_GET_ANY);
                    if(iRet != IFX_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            " mapi_get_all_vlan_ch_entries_for_l2ch - Mgmt API returned error\n");
                        goto mapiErrorHandler;
                    }
                    if(num_vlanchannels == 0)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"No Vlan channels\n");
                            
                        goto mapiErrorHandler;
                    }
                    for (i=0; i<num_vlanchannels; i++)
                    {
                       vlan_entry = xVlanArr[i];
                       if(vlan_entry.fEnable != pxMatch_Atm_Vcc->f_enable)
                       {
                           vlan_entry.fEnable = pxMatch_Atm_Vcc->f_enable;
                           iRet = mapi_set_vlan_ch_entry(iOper, &vlan_entry, iFlags);
                           if(iRet != IFX_SUCCESS)
                           {
                               IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                       "mapi_set_vlan_ch_entry - Modify Mgmt API returned error\n");
                               goto mapiErrorHandler;
                           }
                       }
                    } 
                    IFX_MEM_FREE(xVlanArr);
                }
                break;
            }
    
            default:
                break;
    } 
    if((iRet == IFX_CWMP_NEED_ACTIVATE) || (iRet == IFX_CWMP_NEED_REBOOT))
    {
        return iRet;

    }

    return IFIN_CWMP_SUCCESS;

    mapiErrorHandler:
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed!\n", __func__, __LINE__);
        if((pxOpInfo->iSubOper == OP_SETVAL_ACTIVATE) ||
                (iRet == IFX_CWMP_NEED_REBOOT_DONT_SAVE))
        {
            return IFX_CWMP_NEED_REBOOT_DONT_SAVE;
        }
        else
        {
            return iRet;
        }
    
errorHandler:
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed!\n", __func__, __LINE__);
        return iRet;

}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslLinkSetCommit
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanDslLinkSetCommit()
{
return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslLinkSetUndo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanDslLinkSetUndo()
{

return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslLinkSetDelete
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanDslLinkSetDelete(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
                            IN int32 iElements, OUT void **ppxParamStructRet,
                                                   OUT int32 * piNumRetElem)
{

    uint32 uiCpeid=0;
    ATM_VCC_INFO xMatch_Atm_Vcc;
    ATM_VCC_INFO *pxMatch_Atm_Vcc=&xMatch_Atm_Vcc;
    int32 iRet=0;
    uint32 iOper=0,iFlags=0;
    
    memset(&xMatch_Atm_Vcc,0x00,sizeof(xMatch_Atm_Vcc));
    //If owner is WEB don't add the object just return success.
    if(pxOpInfo->iCaller == ACC_WEB)
        return IFX_CWMP_SUCCESS;

    if(pxOpInfo->iSubOper == OP_SETVAL_CHK_DEL_DEP)
            return IFIN_CWMP_SUCCESS;

    //Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(paxParamVal->iaOID,&uiCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;
    
    //Get the object from system
    iRet= IFX_GetVccObj(pxMatch_Atm_Vcc, uiCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    switch(pxOpInfo->iSubOper)
    {
        case OP_SETVAL_CHK_DEL_ALLOWED:
            break;

        case OP_SETVAL_DELETE:
            //handle DELETE operation
            //Call Platform API to delete the obj in the system
            //If del is called by web we need to pass special owner for which API 
            //will not post a message.
            
            pxMatch_Atm_Vcc->iid.config_owner=pxOpInfo->iCaller;
            pxMatch_Atm_Vcc->iid.cpeId.Id=uiCpeid;
            memset(pxMatch_Atm_Vcc->iid.tr69Id,0x00,MAX_TR69_ID_LEN);
            iOper = IFX_OP_DEL;
            iFlags = (IFX_F_DELETE|IFX_F_DONT_VALIDATE|
    	                IFX_F_DONT_CHECKPOINT|IFX_F_DONT_WRITE_TO_FLASH);
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
            ifx_set_vcc_cfg_stub(iOper, pxMatch_Atm_Vcc, iFlags);
#else
            iRet = ifx_set_vcc_cfg(iOper, pxMatch_Atm_Vcc, iFlags);
#endif
            
            if(iRet != IFX_SUCCESS)
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "ifx_set_vcc_cfg -Delete Mgmt API returned error\n");
                goto errorHandler;
            }
            break;
            
        default:
            break;
        }
        return IFIN_CWMP_SUCCESS;
    
    errorHandler:
         IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed!\n", __func__, __LINE__);
        return IFIN_CWMP_FAILURE;

}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslLinkSetFree
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanDslLinkSetFree()
{
return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanDslLinkSetAttr
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

int32
IFX_WanDslLinkSetAttr(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
                            IN int32 iElements)
{
    uint32 iRet=IFX_CWMP_SUCCESS,i=0;
    OperInfo xOpInfo;
    
    xOpInfo.iCaller = pxOpInfo->iCaller;
    xOpInfo.iOper= OP_GETVAL;
    xOpInfo.iSubOper= OP_GETVAL_NORMAL;
    
    iRet = IFX_WanDslLinkGetValue(&xOpInfo,pxParamVal, iElements);
        if(iRet != IFX_CWMP_SUCCESS)
            goto errorFreeHandler;
    
    iRet = IFX_SetAttributesInfo(pxOpInfo,pxParamVal, iElements);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorFreeHandler;

    errorFreeHandler:
        for(i=0; i < iElements; i++)
        IFX_CWMP_FREE(pxParamVal[i].Value);
        
                if (iRet)
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed!\n", __func__, __LINE__);
        return iRet;
}



/* 
** =============================================================================
**   Function Name    : IFX_WanDslLinkConfig_Init
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_WanDslLinkConfig_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    
    /* Register the WanDslLinkConfig module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_WANDSL_LINK_OBJ, IFX_WanDslLinkConfig);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "Unable to Register %s with Object Model\n",
                     IFX_WANDSL_LINK_OBJ);
        goto errorHandler;
    }

    errorHandler:
            return iRet;
    
    
}

/*********************************************************************************
*  Function Name    :  IFX_WanDslLinkConfig
      *  Description    :  This function handles all the sub-states inside
                      a GET/SET operation.If it is a GET it allocates the 
               array(Name,Value pairs) and retruns the values.
               If it is a SET controller allocates the array and
               passes the values to this function.It calls 
               respective internal functions which in turn calls 
               respective Platform APIs.
                                                                                                 
*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
                                 Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has 
                                       Name,Value,etc
                    IN          int32           iElements;    No. of Elements
            OUT            void *           ppParamRet;   same as ParamStruc
            OUT         int32 *        piNumRetElem; No. of elements                                         
*  Return Value        : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes               :
***********************************************************************************/
int32
IFX_WanDslLinkConfig(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                IN int32 iElements, OUT void **ppaxParamArrRet, OUT int32 *piNumRetElem)
{
     
   //It calls the respective internal functions which handles resp. sub-operation
   
   //Set-Operation  
   //controller should pass the entire array during all the SET-sub_operations
   //It should handles only single get/set of instance at any point of time
   //It does not handle partial path
   //It won't handle multiple instances of the same object/module
   //at any point of time.

    
    int32 iRet = 0;
    ParamVal *paxParamArr = (ParamVal *)paxParameterArr;
    int32 iCnt = 0;

    switch (pxOperInfo->iOper) 
    {
           //Get the object values
           case OP_GETVAL:
                if((iRet = IFX_WanDslLinkGetValue(pxOperInfo, paxParamArr,
                                        iElements)) != IFX_CWMP_SUCCESS) {
                      IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
                      goto errorHandler;
                }
                break;
            case OP_SETVAL:
            {

                //Set the obj values
                switch (pxOperInfo->iSubOper) 
                {
                       case OP_SETVAL_VALIDATE:
                            if((iRet = IFX_WanDslLinkSetValidate(pxOperInfo,paxParamArr,
                                        iElements)) != IFX_CWMP_SUCCESS) { 
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                        "%s:%d OP_SET_VALIDATE failed!\n", __func__, __LINE__);
                                goto errorHandler;
                            }
                         
                            break;
                        case OP_SETVAL_ADD:
                            if((iRet= IFX_WanDslLinkAddObj(pxOperInfo,paxParamArr,
                                        iElements))!=IFX_CWMP_SUCCESS)
                                {
                                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d OP_SETVAL_ADD failed!\n", __func__, __LINE__);
                                    goto errorHandler;
                                }                
                            break;
                        case OP_SETVAL_CHK_MODIFY_DEP:
                        case OP_SETVAL_MODIFY:
                        case OP_SETVAL_ACTIVATE:
                            if((iRet = IFX_WanDslLinkSetValue(pxOperInfo,paxParamArr,
                            			            iElements))!= IFX_CWMP_SUCCESS)
                            {
                                        
                                if ((iRet == IFX_CWMP_NEED_REBOOT_DONT_SAVE) || (iRet < IFX_CWMP_SUCCESS))
                                {
                                    switch(pxOperInfo->iSubOper)
                                    {
                                        case OP_SETVAL_CHK_MODIFY_DEP:
                                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                                        "%s:%d OP_SETVAL_CHK_MODIFY_DEP failed!\n", __func__, __LINE__);
                                            goto errorHandler;
                                        
                                        case OP_SETVAL_MODIFY:
                                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                                "%s:%d OP_SETVAL_MODIFY failed!\n", __func__, __LINE__);
                                            goto errorHandler;
                                
                                        case OP_SETVAL_ACTIVATE:
                                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                                "%s:%d OP_SETVAL_ACTIVATE failed!\n", __func__, __LINE__);
                                            goto errorHandler;
                                    }
                               }
                               else if ((iRet == IFX_CWMP_NEED_ACTIVATE) ||
                          		  (iRet == IFX_CWMP_NEED_REBOOT))
                               {
                                   goto errorHandler;
                               }
                            }
                            break;
                        case OP_SETVAL_COMMIT:
                            if((iRet = IFX_WanDslLinkSetCommit(pxOperInfo,paxParamArr,
                                        iElements)) != IFX_CWMP_SUCCESS) {
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_COMMIT failed!\n", __func__, __LINE__);
                                goto errorHandler;
                            }
                            break;
                        case OP_SETVAL_UNDO:
                            if((iRet = IFX_WanDslLinkSetUndo(pxOperInfo, paxParamArr,
                                        iElements)) != IFX_CWMP_SUCCESS)
                            {
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_UNDO failed!\n", __func__, __LINE__);
                                goto errorHandler;
                            }
                            break;
	                case OP_SETVAL_CHK_DEL_DEP:
        	        case OP_SETVAL_CHK_DEL_ALLOWED:
                	case OP_SETVAL_DELETE:
                            if((iRet= IFX_WanDslLinkSetDelete(pxOperInfo, paxParamArr,
                                        iElements, ppaxParamArrRet,
                                        piNumRetElem))!= IFX_CWMP_SUCCESS)
                            {
                            
                                    switch(pxOperInfo->iSubOper)
                                    {    
                                      case OP_SETVAL_CHK_DEL_DEP:
                                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                        "%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
                                        goto errorHandler;
                                      case OP_SETVAL_CHK_DEL_ALLOWED:
                                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                        "%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
                                        goto errorHandler;
                                      case OP_SETVAL_DELETE:
                                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                        "%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
                                        goto errorHandler;
                                   }
                            }
                            break;
                        case OP_SETVAL_FREE:
                            IFX_WanDslLinkSetFree(pxOperInfo);
                            
                            break;

	                 case OP_SETVAL_ATTRINFO:
        	             if((iRet =IFX_WanDslLinkSetAttr(pxOperInfo, paxParamArr,
                                        iElements)) != IFX_CWMP_SUCCESS)
                             {
                	           IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        	        "%s:%d OP_SETVAL_ATTRINFO failed!\n", __func__, __LINE__);
                                	goto errorHandler;
                             }    
                             break;
                            
                         default:
                            break;
                }
                break;
            }
            case OP_PARAM_VALIDATE:
            {
                //IGD.WD.2. or IGD.WD.3.
                if(((paxParamArr->iaOID[2]) == WAN_DEVICE_MII0) || ((paxParamArr->iaOID[2]) == WAN_DEVICE_MII1))
                {
                    /* Set the fault code to Error */
                    for(iCnt = 0; iCnt < iElements; iCnt++)
                    {
                        paxParamArr[iCnt].iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
                    }
                    goto errorHandler;
                }
                else if((paxParamArr->iaOID[2]) == WAN_DEVICE_ATM)
                {
                    /*IGD.WD.1.WCD.1 is for PTMLC*/
                    if((paxParamArr->iaOID[4]) == 1)
                    {
                	/* Set the fault code to Error */
        	        for(iCnt = 0; iCnt < iElements; iCnt++)
	                {
                	    paxParamArr[iCnt].iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
        	        }
	                goto errorHandler;
                    }
                }
                break; 
            }
            default:
                break;
    }
    return IFX_CWMP_SUCCESS;

errorHandler:
    return iRet;
            
}
 
