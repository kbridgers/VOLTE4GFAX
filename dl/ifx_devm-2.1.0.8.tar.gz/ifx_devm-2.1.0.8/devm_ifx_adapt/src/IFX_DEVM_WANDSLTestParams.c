/* 
** =============================================================================
**   FILE NAME        : IFX_WanDslTestParams.c
**   PROJECT          : TR69
**   MODULES          : WanDslTestParams
**   DATE             : 
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This module handles ADD/DEL/GET/SET RPCs of 
**                      WanDslTestParams. When controller calls this module it
**                      calls respective Platform/Object APIs to handle GET/SET 
**                      of WanDslTestParams specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author        $Comment
**   16-07-07         TR69 team      Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
//#include <sys/socket.h>
//#include <netinet/in.h>
//#include <arpa/inet.h>

#include "IFX_DEVM_WANDSLTestParams.h"
#include "IFX_DEVM_WANDSLDiags.h"
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
 
#include <fcntl.h>
#include <unistd.h>
#include "IFX_DEVM_StackUtil.h"

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;
#define NO_CHAR_IN_INT 6
//extern int32 adsl_get_rate(int32 type, unsigned long *rate,unsigned long *rate_remainder);
#define IFX_DSL_TEST_PARAMS_OBJ "InternetGatewayDevice.WANDevice.1.WANDSLInterfaceConfig.TestParams."
/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/




/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : IFX_WanDslTestParamsGetValue
**   Description        : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes                : 
**
** ============================================================================
*/
static int32 
IFX_WanDslTestParamsGetValue(IN OperInfo *pxOperInfo,INOUT ParamVal *pxGetParamVal,
								IN uint32 iElements)
{
	/*GET PARAMETER VALUES
	**Get Object OID(skip parameter ID) from the first 
	**element in the array.Get Cpeid for this Object OID

	**Get the object from the system using a Platform API
	**with cpeid 
	
	**Do reverse mapping to convert system values into TR69
	**Values.After conversion stores the values in temp storage

	**While assigning the values as per request store the 
	**values in heap and assign the ptr to the struct
	**Return all the values 
	*/
	
	uint32 i=0;
	int32 iParamId=0;
	uint32 uiParamPos=0;
	uint32 ALLOC_SIZE=10;
	int32 iRet=IFX_CWMP_SUCCESS;
	int32 iRet1=IFX_CWMP_SUCCESS;
	int32 iRet2=IFX_CWMP_SUCCESS;
	int32 iRet3=IFX_CWMP_SUCCESS;
	int32 iRet4=IFX_CWMP_SUCCESS;
	uint32 uiMode=IFX_CHK_VALUE_BASED;
	DSL_TEST_PARAMS_LINE_STATUS xDslTestParamsLINESTATUS;
        DSL_TEST_PARAMS_HLOG xDslTestParamsHLOG;
        DSL_TEST_PARAMS_QLN xDslTestParamsQLN;
        DSL_TEST_PARAMS_SNR xDslTestParamsSNR;
        DSL_TEST_PARAMS_SNR_ALLOC_STATUS xDslTestParamsSNRALLOCSTATUS;
	ALLOC_SIZE = (DSL_MAX_NSC * NO_CHAR_IN_INT) + DSL_MAX_NSC;

	memset(&xDslTestParamsHLOG,0x00,sizeof(DSL_TEST_PARAMS_HLOG));	
	memset(&xDslTestParamsQLN,0x00,sizeof(DSL_TEST_PARAMS_QLN));	
	memset(&xDslTestParamsSNR,0x00,sizeof(DSL_TEST_PARAMS_SNR));	
	memset(&xDslTestParamsSNRALLOCSTATUS,0x00,sizeof(DSL_TEST_PARAMS_SNR_ALLOC_STATUS));	
	memset(&xDslTestParamsLINESTATUS,0x00,sizeof(DSL_TEST_PARAMS_LINE_STATUS));	

	//Get the WanIpConParamPos
        uiParamPos = IFX_GetParamIdPos(pxGetParamVal->iaOID);
	iRet = ifx_mapi_get_dsl_test_params_hlog(&xDslTestParamsHLOG,IFX_F_DEFAULT);
	iRet1 = ifx_mapi_get_dsl_test_params_qln(&xDslTestParamsQLN,IFX_F_DEFAULT);
	iRet2 = ifx_mapi_get_dsl_test_params_snr(&xDslTestParamsSNR,IFX_F_DEFAULT);
	iRet3 = ifx_mapi_get_dsl_test_params_snr_alloc_status(&xDslTestParamsSNRALLOCSTATUS,IFX_F_DEFAULT);
	iRet4 = ifx_mapi_get_dsl_test_params_line_status(&xDslTestParamsLINESTATUS,IFX_F_DEFAULT);
	if((iRet1 || iRet2 || iRet3 || iRet4 || iRet) != IFX_SUCCESS)
	    goto errorHandler;

	for(i=0;i < iElements; i++)
	{
		iParamId = pxGetParamVal->iaOID[uiParamPos];


		switch(iParamId)
		{

			// Convert the value - reverse mapping
			// Assign the correct value to the Value attr

#ifdef IFX_TR69_VDSL2WAN                                   
    			case OID_IGD_WAND_WANDSLIC_TP_HLOGGDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
				if(pxGetParamVal->Value!=NULL)
				{
					sprintf(pxGetParamVal->Value,"%u",xDslTestParamsHLOG.hlog_ds.data.nGroupSize);
					IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
				}
				else
				{
					goto errorHandler;
				}
					break;	
    			case OID_IGD_WAND_WANDSLIC_TP_HLOGGUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
                                if(pxGetParamVal->Value!=NULL)
                                {
				        sprintf(pxGetParamVal->Value,"%u",xDslTestParamsHLOG.hlog_us.data.nGroupSize);
				        IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                                }
                                else
                                {
                                        goto errorHandler;
                                }
				break;
#endif	
    			case OID_IGD_WAND_WANDSLIC_TP_HLOGPSDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
                                if(pxGetParamVal->Value!=NULL)
                                {
                                     iRet = IFX_ConvertArrtoString(DSL_MAX_NSC,pxGetParamVal->Value,
                                                         (void *)&(xDslTestParamsHLOG.hlog_ds.data.deltHlog.nNSCData),
                                                               IFX_UINT16_DATA_TYPE);
                                }
				if(iRet != IFX_CWMP_SUCCESS)
                                        goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
			case OID_IGD_WAND_WANDSLIC_TP_HLOGPSUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
                                if(pxGetParamVal->Value!=NULL)
                                {
                                      iRet = IFX_ConvertArrtoString(DSL_MAX_NSC,pxGetParamVal->Value,
                                                         (void *)&(xDslTestParamsHLOG.hlog_us.data.deltHlog.nNSCData),
                                                                IFX_UINT16_DATA_TYPE);
                                }
				if(iRet != IFX_CWMP_SUCCESS)
                                        goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
			case OID_IGD_WAND_WANDSLIC_TP_HLOGMTDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
                                if(pxGetParamVal->Value!=NULL)
                                {
				       sprintf(pxGetParamVal->Value,"%u",xDslTestParamsHLOG.hlog_ds.data.deltHlog.nNumData);
				       IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                                }
                                else
                                {
                                       goto errorHandler;
                                }
				break;	 
			case OID_IGD_WAND_WANDSLIC_TP_HLOGMTUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
                                if(pxGetParamVal->Value!=NULL)
                                {
				       sprintf(pxGetParamVal->Value,"%u",xDslTestParamsHLOG.hlog_us.data.deltHlog.nNumData);
				       IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                                }
                                else
                                {
                                      goto errorHandler;
                                }
				break;	

#ifdef IFX_TR69_VDSL2WAN                                   
			case OID_IGD_WAND_WANDSLIC_TP_QLNGDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
                                if(pxGetParamVal->Value!=NULL)
                                {
				      sprintf(pxGetParamVal->Value,"%u",xDslTestParamsQLN.qln_ds.data.nGroupSize);
				      IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                                }
                                else
                                {
                                      goto errorHandler;
                                }
				break;
				
			case OID_IGD_WAND_WANDSLIC_TP_QLNGUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
                                if(pxGetParamVal->Value!=NULL)
                                {
				      sprintf(pxGetParamVal->Value,"%u",xDslTestParamsQLN.qln_us.data.nGroupSize);
				      IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                                }
                                else
                                {
                                      goto errorHandler;
                                }
				break;
#endif
			case OID_IGD_WAND_WANDSLIC_TP_QLNPSDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
                                iRet = IFX_ConvertArrtoString(DSL_MAX_NSC,pxGetParamVal->Value,
                                                            (void *)&(xDslTestParamsQLN.qln_ds.data.deltQln.nNSCData),
                                                                IFX_UCHAR_DATA_TYPE);
				if(iRet != IFX_CWMP_SUCCESS)
                                        goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
			case OID_IGD_WAND_WANDSLIC_TP_QLNPSUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
                                iRet = IFX_ConvertArrtoString(DSL_MAX_NSC,pxGetParamVal->Value,
                                                            (void *)&(xDslTestParamsQLN.qln_us.data.deltQln.nNSCData),
                                                                IFX_UCHAR_DATA_TYPE);
				if(iRet != IFX_CWMP_SUCCESS)
                                        goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
			case OID_IGD_WAND_WANDSLIC_TP_QLNMTDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
                                if(pxGetParamVal->Value!=NULL)
                                {
				      sprintf(pxGetParamVal->Value,"%u",xDslTestParamsQLN.qln_ds.data.deltQln.nNumData);
				      IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                                }
                                else
                                {
                                      goto errorHandler;
                                }
				break;	 
			case OID_IGD_WAND_WANDSLIC_TP_QLNMTUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
                                if(pxGetParamVal->Value!=NULL)
                                {
				      sprintf(pxGetParamVal->Value,"%u",xDslTestParamsQLN.qln_us.data.deltQln.nNumData);
				      IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                                }
                                else
                                {
                                     goto errorHandler;
                                }
				break;	 

#ifdef IFX_TR69_VDSL2WAN                                   
			case OID_IGD_WAND_WANDSLIC_TP_SNRGDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
                                if(pxGetParamVal->Value!=NULL)
                                {
				      sprintf(pxGetParamVal->Value, "%u", xDslTestParamsSNR.snr_ds.data.nGroupSize);
				      IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                                }
                                else
                                {
                                    goto errorHandler;
                                }
				break;	 
				
			case OID_IGD_WAND_WANDSLIC_TP_SNRGUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
                                if(pxGetParamVal->Value!=NULL)
                                {
				      sprintf(pxGetParamVal->Value, "%u", xDslTestParamsSNR.snr_us.data.nGroupSize);
				      IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, uiMode);
                                }
                                else
                                {
                                      goto errorHandler;
                                }
				break;
#endif
			case OID_IGD_WAND_WANDSLIC_TP_SNRPSDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
                                iRet = IFX_ConvertArrtoString(DSL_MAX_NSC,pxGetParamVal->Value,
                            (void *)&(xDslTestParamsSNRALLOCSTATUS.snr_alloc_status_ds.data.snrAllocationNsc.nNSCData),
                                                                IFX_UCHAR_DATA_TYPE);
				if(iRet != IFX_CWMP_SUCCESS)
                                        goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			case OID_IGD_WAND_WANDSLIC_TP_SNRPSUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
                                iRet = IFX_ConvertArrtoString(DSL_MAX_NSC,pxGetParamVal->Value,
                            (void *)&(xDslTestParamsSNRALLOCSTATUS.snr_alloc_status_us.data.snrAllocationNsc.nNSCData),
                                                                IFX_UCHAR_DATA_TYPE);
				if(iRet != IFX_CWMP_SUCCESS)
                                        goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
			case OID_IGD_WAND_WANDSLIC_TP_SNRMTDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
				sprintf(pxGetParamVal->Value,"%u",xDslTestParamsSNR.snr_ds.data.deltSnr.nNumData);
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;	 
			case OID_IGD_WAND_WANDSLIC_TP_SNRMTUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
				sprintf(pxGetParamVal->Value,"%u",xDslTestParamsSNR.snr_us.data.deltSnr.nNumData);
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
			case OID_IGD_WAND_WANDSLIC_TP_LATNDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
				sprintf(pxGetParamVal->Value,"%d",xDslTestParamsLINESTATUS.linestatus_ds.data.LATN);
				if(iRet != IFX_CWMP_SUCCESS)
                                        goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
			case OID_IGD_WAND_WANDSLIC_TP_LATNUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
				sprintf(pxGetParamVal->Value,"%d",xDslTestParamsLINESTATUS.linestatus_us.data.LATN);
				if(iRet != IFX_CWMP_SUCCESS)
                                        goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
			case OID_IGD_WAND_WANDSLIC_TP_SATNDS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
				sprintf(pxGetParamVal->Value,"%d",xDslTestParamsLINESTATUS.linestatus_ds.data.SATN);
				if(iRet != IFX_CWMP_SUCCESS)
                                        goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
			case OID_IGD_WAND_WANDSLIC_TP_SATNUS:
				pxGetParamVal->Value = IFIN_CWMP_MALLOC(ALLOC_SIZE);
				sprintf(pxGetParamVal->Value,"%d",xDslTestParamsLINESTATUS.linestatus_us.data.SATN);
				if(iRet != IFX_CWMP_SUCCESS)
                                        goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
			default:
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "Invalid param id %d!\n", iParamId);
			pxGetParamVal->iFaultCode=ERR_INVAL_PARAMETER_NAME;
			break;
		}
		++pxGetParamVal;
	}

IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s, %d] \n", __FUNCTION__, __LINE__);
		return IFX_CWMP_SUCCESS;
		errorHandler:
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d failed ParamId=%d!\n", __func__, __LINE__,iParamId);
			return iRet;

}


/* 
** =============================================================================
**   Function Name    : IFX_WanDslTestParams_Init
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_WanDslTestParams_Init(void)
{
	int32 iRet = IFX_CWMP_SUCCESS;

    
	/* Register the WanDslTestParams module function pointer in the object model */
	iRet = ifx_ds_register_function(IFX_DSL_TEST_PARAMS_OBJ, IFX_WanDslTestParams);
	
	/* Check for error */
	if (iRet != IFX_CWMP_SUCCESS)
	{
	    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                "Unable to Register %s with Object Model\n",
	                 IFX_DSL_TEST_PARAMS_OBJ);
	    goto errorHandler;
	}

	errorHandler:
			return iRet;
}

/*********************************************************************************
*  Function Name	:  IFX_WanDslTestParams   
      *  Description	:  This function handles all the sub-states inside
      	 		   a GET/SET operation.If it is a GET it allocates the 
			   array(Name,Value pairs) and retruns the values.
			   If it is a SET controller allocates the array and
			   passes the values to this function.It calls 
			   respective internal functions which in turn calls 
			   respective Platform APIs.
                                                                                                 
*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
							     Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has 
					  	             Name,Value,etc
                    IN          int32	       iElements;    No. of Elements
		    OUT	        void *	       ppParamRet;   same as ParamStruc
		    OUT         int32 *        piNumRetElem; No. of elements 		                                
*  Return Value        : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes               :
***********************************************************************************/
int32
IFX_WanDslTestParams(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                IN int32 iElements, OUT void **ppaxParamArrRet, OUT int32 *piNumRetElem)
{
     
   //It calls the respective internal functions which handles resp. sub-operation
   
   //Set-Operation  
   //controller should pass the entire array during all the SET-sub_operations
   //It should handles only single get/set of instance at any point of time
   //It does not handle partial path
   //It won't handle multiple instances of the same object/module
   //at any point of time.

    
    int32 iRet = 0, iCnt = 0;
    ParamVal *paxParamArr = (ParamVal *)paxParameterArr;

	switch (pxOperInfo->iOper) 
	{
		//Get the object values
	   	case OP_GETVAL:
	            if((iRet = IFX_WanDslTestParamsGetValue(pxOperInfo, paxParamArr,
		    							iElements)) != IFX_CWMP_SUCCESS) {
	                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
			  goto errorHandler;
	            }
	            break;
                case OP_PARAM_VALIDATE:
                {
                    //IGD.WD.2. or IGD.WD.3.
                    if(((paxParamArr->iaOID[2]) == WAN_DEVICE_MII0) || ((paxParamArr->iaOID[2]) == WAN_DEVICE_MII1))
                    {
                        /* Set the fault code to Error */
                        for(iCnt = 0; iCnt < iElements; iCnt++)
                        {
                            paxParamArr[iCnt].iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
                        }
                    }
                    break; 
                }
	        default:
	            break;
	}
	return IFX_CWMP_SUCCESS;

errorHandler:
	return IFX_CWMP_FAILURE;
			
}
 
