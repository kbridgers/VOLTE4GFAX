/* 
** =============================================================================
**   FILE NAME        : IFX_DEVM_StaticDHCPAddr.c
**   PROJECT          : TR69
**   MODULES          : 
**   DATE             : 
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This is the Queue Module. It is required by the 
**                      controller module of TR69 stack to GET/SET/ADD/DELETE
**                      Queue specific information.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author                         $Comment
**   15-01-2008       TR69 team                       Initial Version
**
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_DHCPStaticAddr.h"
  // Required for STATIC
 
#include "IFX_DEVM_OID.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
 
#include "IFX_DEVM_DS.h"

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/

#define LHCMDHCPSTATICADDRESS_OBJ    FORMNAME("LANDevice.1.LANHostConfigManagement.DHCPStaticAddress.")
#define DHCP_STATIC_ADDRESS_NO_OF_DEP_OIDS 0

/* TBD: Temporary Placeholders, since we do not get this from Platform include
   header files */


/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

STATIC int32
GetParamOffset(IN int32 *paiOID);
STATIC int32
GetVal(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
       IN int32 iElements);
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
AddObj(IN OperInfo *pxOI,INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
SetDelete(IN OperInfo *pxOI,INOUT ParamVal *pxParamVal,
          IN int32 iElements, OUT void **ppxParamStructRet,
          OUT int32 * piNumRetElem);

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : GetParamOffset
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

STATIC int32
GetParamOffset(IN int32 *paiOID)
{
    int32 iCnt;

    for (iCnt = 0; paiOID[iCnt] != 0; iCnt++);

    return (iCnt - 1);
}

/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetVal(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
       IN int32 iElements)
{
    int32   iRet  = IFX_CWMP_SUCCESS;
    int32   iRtn  = IFX_SUCCESS;
    int32   iCnt  = 0;
    IFX_MAPI_DHCPS_STATIC_LEASE pp_dhcp_info;
    int32   iParamOffset;
    uint32 iCpeid = 0;

    // Get Cpeid from object ID
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    	goto cleanup;

    memset(&pp_dhcp_info, 0, sizeof(IFX_MAPI_DHCPS_STATIC_LEASE));

    /* Fill the cpeid in the structure to get the required instance */
    pp_dhcp_info.iid.cpeId.Id = iCpeid;

    /* Get all the IFX_MAPI parameters using Protocol API */
    iRtn = ifx_get_dhcps_static_lease(&pp_dhcp_info, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_get_dhcps_static_lease failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        /* TBD: Currently keeping size as 257 bytes, since max param size is string(256) */
        (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(257);

        /* Check for error */
        if (!((pxParamVal[iCnt]).Value))
        {
            iRet = ERR_OUT_OF_MEMORY;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Allocation Failure\n",
                         __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_LAND_LANHCM_DHCPSA_ENABLE:
                /* Copy the value to allocated area */
//		sprintf(pxParamVal[iCnt].Value, "%d", pp_dhcp_info.enable);
                  sprintf(pxParamVal[iCnt].Value, "%c", (pp_dhcp_info.enable)+48);
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                            "[%s:%s:%d] [Error] Unknown requested parameter pp_dhcp_info.enable -> %d\n",
                            __FILE__, __func__, __LINE__, pp_dhcp_info.enable );
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                            "[%s:%s:%d] [Error] Unknown requested parameter (pp_dhcp_info.enable)+48 -> %c\n",
                            __FILE__, __func__, __LINE__, (pp_dhcp_info.enable)+48);
                break;
            case OID_IGD_LAND_LANHCM_DHCPSA_CHADDR:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, pp_dhcp_info.macAddr);
                break;
            case OID_IGD_LAND_LANHCM_DHCPSA_YIADDR:
                sprintf(pxParamVal[iCnt].Value, pp_dhcp_info.ipAddr);
                break;
            default:
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
                goto cleanup;
        }
    }

cleanup:
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : Modify
**
**   Description      : This function modifies the values of parameters in 
**                       object. It calls respective Management
**                      API for same. It performs modification only if parameter 
**                      has Write permission. In certain cases it also performs 
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements)
{

    int32       iRet       = IFX_CWMP_SUCCESS;
    int32       iRtn       = IFX_SUCCESS;
    uint32      iCpeid     = 0;
    int32       iCnt       = 0;
    int32       iParamOffset;
    char8       *psTmpVal;
    uint32      uiFlags;
    IFX_MAPI_DHCPS_STATIC_LEASE pp_dhcp_info;
    
    // Get Cpeid from object ID
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    	goto cleanup;

    memset(&pp_dhcp_info, 0, sizeof(IFX_MAPI_DHCPS_STATIC_LEASE));
    /* Fill the cpeid in the structure to get the required instance */
    pp_dhcp_info.iid.cpeId.Id = iCpeid;

    iRtn = ifx_get_dhcps_static_lease(&pp_dhcp_info, IFX_F_DEFAULT); 

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_get_dhcps_static_lease failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }


    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {

            case OID_IGD_LAND_LANHCM_DHCPSA_ENABLE:
                if (!strcmp(psTmpVal, "1"))
                    pp_dhcp_info.enable = 1;
                else
                    pp_dhcp_info.enable = 0;
                break;

            case OID_IGD_LAND_LANHCM_DHCPSA_CHADDR:
  		/* Check if the string fits in the buffer */
                if ((strlen(psTmpVal) + 1) > MAX_MAC_ADDR_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }
                /* Copy the string */
                strcpy(pp_dhcp_info.macAddr, psTmpVal);
                break;

            case OID_IGD_LAND_LANHCM_DHCPSA_YIADDR:
		 /* Check if the string fits in the buffer */
                if ((strlen(psTmpVal) + 1) > MAX_IP_ADDR_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }
                /* Copy the string */
                strcpy(pp_dhcp_info.ipAddr, psTmpVal);
                break;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }


  /* Fill the iid structure in the pool struct */
    pp_dhcp_info.iid.config_owner = iCaller;

    /* Set all the  parameters using Object API */
    uiFlags = IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH;
//    if (pp_dhcp_info.Enable == 0)
//    uiFlags |= IFX_F_DONT_ACTIVATE | IFX_F_DONT_VALIDATE;


    iRtn = ifx_set_dhcps_static_lease(IFX_OP_MOD, &pp_dhcp_info, uiFlags);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to set values of all "
                    "parameters\n", __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    return (iRet);

}

/* 
** =============================================================================
**   Function Name    : Validate
**
**   Description      : This function validates the values of parameters in
**                      Queue object.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      validated.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When validation of all parameters is
**                      successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in validating at least one parameter.
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iCnt;
    int32   iParamOffset;
    char8   *psTmpVal;

   /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Iterate and validate the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Return a failure if the value is NULL pointer */
        if (!psTmpVal)
        {
            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
            iRet = ERR_CWMP_INVAL_ARGS;
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_LAND_LANHCM_DHCPSA_ENABLE:
            case OID_IGD_LAND_LANHCM_DHCPSA_CHADDR:
            case OID_IGD_LAND_LANHCM_DHCPSA_YIADDR:
                /* TBD: Will be done later if required */
                break;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

cleanup:
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Validating requested parameter failed\n",
                    __FILE__, __func__, __LINE__, iRet);
    }
    return (iRet);

}

STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iCnt;
    int32 iParamOffset;
    int32 iValueFlag = 0; /* Mandatory */

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Set the fault code to Success and value to NULL pointer for all parameters
       other than uptime */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Mark that values have been malloced. Currently always doing it, since not possible
       to keep track in a loop, for which params its malloced */
    iValueFlag = 1;

    /* Update Attribute Information */
    iRet = IFX_SetAttributesInfo(NULL, pxParamVal, iElements);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Updating Param Attribute Info failed\n",
                    __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    /* Free the Value that has been allocated */
    if (iValueFlag)
    { 
        for (iCnt = 0; iCnt < iElements; iCnt++)
        {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
        }
    }

    return (iRet);

}

STATIC int32
AddObj(IN OperInfo *pxOI,INOUT ParamVal *pxParamVal, IN int32 iElements)
{
	/* This API calls a Platform API which adds the object
        ** in ADD_DISABLE state.
        ** Pass necessary flags to the API
        ** Controller should get the next instance id from DS
        ** module and pass the full OID to this module.
        */
    int32 iRet=IFX_CWMP_SUCCESS;
    int32 iRtn=IFX_SUCCESS;
    uint32 iFlags=0;
    uint32 iOper;
    uint32 uiPcpeId=0;
    IFX_MAPI_DHCPS_STATIC_LEASE pp_dhcp_info;
    int32 iCnt;
    int32 iParamOffset;
    char8       *psTmpVal;

	 memset(&pp_dhcp_info, 0, sizeof(IFX_MAPI_DHCPS_STATIC_LEASE));

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {

            case OID_IGD_LAND_LANHCM_DHCPSA_ENABLE:
		pp_dhcp_info.enable = IFX_DISABLED;
                break;

            case OID_IGD_LAND_LANHCM_DHCPSA_CHADDR:
                /* Check if the string fits in the buffer */
                if ((strlen(psTmpVal) + 1) > MAX_MAC_ADDR_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }
                /* Copy the string */
                strcpy(pp_dhcp_info.macAddr, psTmpVal);
                break;

            case OID_IGD_LAND_LANHCM_DHCPSA_YIADDR:
                 /* Check if the string fits in the buffer */
                if ((strlen(psTmpVal) + 1) > MAX_IP_ADDR_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }
		 /* Copy the string */
                strcpy(pp_dhcp_info.ipAddr, psTmpVal);
                break;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter [%d]\n",
                            __FILE__, __func__, __LINE__, iRet, (pxParamVal[iCnt]).iaOID[iParamOffset]);
                goto cleanup;
        }
    }

        //TBD: Fill in the required params

	//Fill the operation
	iOper = IFX_OP_ADD;
	
	//Fills the Cpeid,ParentCepid,TR69Id,Owner
	iRet = IFX_GetParentObjCpeId(pxParamVal->iaOID,&uiPcpeId);
	if(iRet != IFX_CWMP_SUCCESS)
		goto cleanup;

	pp_dhcp_info.iid.config_owner=pxOI->iCaller;
	pp_dhcp_info.iid.cpeId.Id=0;
	pp_dhcp_info.iid.pcpeId.Id=uiPcpeId;
	
	//Convert array into dotted form and then strcpy
	
	iRet = IFX_ConvertOidDottedForm(pxParamVal->iaOID, pp_dhcp_info.iid.tr69Id);
	if(iRet != IFX_CWMP_SUCCESS)
		goto cleanup;

	//Flags should be filled
	iFlags =(	IFX_F_DONT_ACTIVATE|IFX_F_DONT_CHECKPOINT|
			IFX_F_DONT_VALIDATE|IFX_F_DONT_WRITE_TO_FLASH);
 	iRtn = ifx_set_dhcps_static_lease(iOper, &pp_dhcp_info, iFlags);

	if(iRtn != IFX_SUCCESS)
	{
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"ifx_set_dhcps_static_lease AddObj Mgmt API"					                          " returned error\n");
        iRet = ERR_CWMP_INTERNAL;
		goto cleanup;
		
	}	

cleanup:
	return iRet;

}

#if 0
int32
GetDHCPStaticInst(IFX_MAPI_DHCPS_STATIC_LEASE **ppxDHCPStatic, uint32 iCpeid)
{

    IFX_MAPI_DHCPS_STATIC_LEASE *paxDHCPStatic = NULL;
    IFX_MAPI_DHCPS_STATIC_LEASE *pxMatchDHCPStatic = NULL;
    IFX_MAPI_DHCPS_STATIC_LEASE *pxTmpDHCPStatic = NULL;
    int32 uiNumOfEntries = 0;
    uint32 iFlags, iI = 0;
    uint32 iGotValue = 0;
    int32 iRet = 0;

    pxMatchDHCPStatic=IFX_CWMP_MALLOC(sizeof(IFX_MAPI_DHCPS_STATIC_LEASE));
    if(pxMatchDHCPStatic == NULL){
        iRet = ERR_OUT_OF_MEMORY;
        goto errorHandler;
    }
    iFlags = IFX_F_GET_ANY;


    iRet=ifx_get_all_dhcps_static_lease(&uiNumOfEntries, &paxDHCPStatic, iFlags);

    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_get_all_dhcps_static_lease returned failure\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto errorHandler;
    }
    pxTmpDHCPStatic = paxDHCPStatic;
 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "NoOfEntries=%d !\n",uiNumOfEntries);

    for(iI = 0; iI < uiNumOfEntries; iI++)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "API_Cpeid=%d !\n",pxTmpDHCPStatic->iid.cpeId.Id);
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "Module_Cpeid=%d !\n",iCpeid);

        if(pxTmpDHCPStatic != NULL)
        {
            if(pxTmpDHCPStatic->iid.cpeId.Id== iCpeid)
            {
                //Memcopy the struct
                iGotValue = 1;
                memcpy(pxMatchDHCPStatic, pxTmpDHCPStatic, sizeof(DHCP_OPTION));
                *ppxDHCPStatic = pxMatchDHCPStatic;
                break;
            }
            pxTmpDHCPStatic += 1;
        }

    }

    if(iGotValue == 1)
    {

        IFX_CWMP_FREE(paxDHCPStatic);
        return IFX_CWMP_SUCCESS;
    }

    errorHandler:
 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%s:%d] failed!\n",__FILE__, __func__, __LINE__);

    IFX_CWMP_FREE(paxDHCPStatic);
    IFX_CWMP_FREE(pxMatchDHCPStatic);

    return IFX_CWMP_FAILURE;
}

#endif

STATIC int32
SetDelete(IN OperInfo *pxOI,INOUT ParamVal *pxParamVal,
          IN int32 iElements, OUT void **ppxParamStructRet,
          OUT int32 * piNumRetElem)
{
    int32 iRet=IFX_CWMP_SUCCESS;
    int32 iRtn=IFX_SUCCESS;
    uint32 uiCpeid=0;
    IFX_MAPI_DHCPS_STATIC_LEASE pp_dhcp_info;
    uint32 iOper=0,iFlags=0;
    int32 iParamPos=0;
    ParamVal *Param_DepOids=NULL;

    // handle CHK_DELETE_DEP
    if(pxOI->iSubOper == OP_SETVAL_CHK_DEL_DEP)
    {
	Param_DepOids = IFIN_CWMP_MALLOC((DHCP_STATIC_ADDRESS_NO_OF_DEP_OIDS+1)* sizeof(ParamVal));
        if(Param_DepOids == NULL)
        {
           iRet = ERR_OUT_OF_MEMORY;
           goto errorHandler;
        }

        //Get the WanIpConParamPos
        iParamPos = IFX_GetParamIdPos(pxParamVal->iaOID);
        if (iParamPos < 0){
            IFX_CWMP_FREE(Param_DepOids);
            goto errorHandler; //To fix SCA error
        }

        memcpy((Param_DepOids+0)->iaOID,pxParamVal->iaOID,
               (sizeof(int32)*(iParamPos+1)));

      *ppxParamStructRet = (void *)Param_DepOids;
      *piNumRetElem = DHCP_STATIC_ADDRESS_NO_OF_DEP_OIDS+1;

        return IFIN_CWMP_SUCCESS;
    }

    if(pxOI->iSubOper == OP_SETVAL_CHK_DEL_ALLOWED)
    {
        return IFIN_CWMP_SUCCESS;
    }

    //Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&uiCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    	goto errorHandler;

	memset(&pp_dhcp_info, 0, sizeof(IFX_MAPI_DHCPS_STATIC_LEASE));
    /* Fill the cpeid in the structure to get the required instance */
    pp_dhcp_info.iid.cpeId.Id = uiCpeid;

    iRtn = ifx_get_dhcps_static_lease(&pp_dhcp_info, IFX_F_DEFAULT);
    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_get_dhcps_static_lease failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto errorHandler;
    }


   switch(pxOI->iSubOper)
    {
        case OP_SETVAL_DELETE:
            //handle DELETE operation
            //Call Platform API to delete the obj in the system
            //If del is called by web we need to pass special owner for which API
            //will not post a message.

	    pp_dhcp_info.iid.config_owner=pxOI->iCaller;
	    pp_dhcp_info.iid.cpeId.Id=uiCpeid;
	    memset(pp_dhcp_info.iid.tr69Id,0x00,MAX_TR69_ID_LEN);
	    iOper = IFX_OP_DEL;
	    iFlags = (IFX_F_DELETE|IFX_F_DONT_VALIDATE| IFX_F_DONT_CHECKPOINT|IFX_F_DONT_WRITE_TO_FLASH);
	    iRtn = ifx_set_dhcps_static_lease(iOper, &pp_dhcp_info, iFlags);
	    if(iRet != IFX_SUCCESS)
	    {
	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "ifx_set_dhcps_static_lease -delete Mgmt API returned error\n");
      		iRet = ERR_CWMP_INTERNAL;
        	goto errorHandler;
    	    }
          break;

        default:
            break;
    }

    return IFIN_CWMP_SUCCESS;
errorHandler:
     IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                 "%s:%d failed!\n", __func__, __LINE__);

    return IFIN_CWMP_FAILURE;
}



/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : IFX_DHCPStaticAddr_Init
**
**   Description      : This function is called by the controller. It registers
**                      the function responsible for handling DHCPStaticAddress
**                      object with data structure. It also performs initializations
**                      specific to DHCPStaticAddress object.
**
**   Parameters       : No Parameters. 
**
**   Return Value     : IFX_CWMP_SUCCESS - When object is
**                      initialized successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in initializing object.
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_DHCPStaticAddr_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the Classification module function pointer in the object model */
    iRet = ifx_ds_register_function(LHCMDHCPSTATICADDRESS_OBJ, IFX_DHCPStaticAddr);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, LHCMDHCPSTATICADDRESS_OBJ);
        goto cleanup;
    }

cleanup:
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_DHCPStaticAddr
**
**   Description      : This function is called by the controller. It handles
**                      Queue object and performs  based on requested
**                      operations/suboperations by invoking internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_DHCPStaticAddr(IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
             OUT void **ppRet, OUT int32 *piNumRetElem)
{
    int32       iRet           = IFX_CWMP_SUCCESS;
    ParamVal    *pxParamVal    = (ParamVal *)pParamList;

    /* Process based on type of Operation */
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:

                    /* Get values of all the requested parameters */
                    iRet = GetVal(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_SETVAL:
        {
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:

                    /* Validate values of all the requested parameters */
                    iRet = Validate(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:

                    /* Check modify dependency of all requested parameters */
                    iRet = IFX_CWMP_SUCCESS;
                    break;
                case OP_SETVAL_MODIFY:

                    /* Set values of all the requested parameters */
                    iRet = Modify(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ATTRINFO:

                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ADD:
                    iRet = AddObj(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }
                    break;
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
                case OP_SETVAL_DELETE:
                    if((iRet= SetDelete(pxOI, pxParamVal,
                        iNumElem, ppRet, piNumRetElem))!= IFX_CWMP_SUCCESS)
                    {

                        switch(pxOI->iSubOper)
                        {
                            case OP_SETVAL_CHK_DEL_DEP:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
                                goto cleanup;
                            case OP_SETVAL_CHK_DEL_ALLOWED:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
                                goto cleanup;
                            case OP_SETVAL_DELETE:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
                                goto cleanup;
                        }
                    }
                    break;



                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD: 
                case OP_UPDATE_CHILDINFO_DEL: 
                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
        {
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid Operation\n",
                         __func__, __LINE__, iRet);
            goto cleanup;
        }
    }

cleanup:
    return (iRet);
}
