/* 
** =============================================================================
**   FILE NAME        : IFX_WanATMF5LoopbackDiagnostics.c
**   PROJECT          : TR69
**   MODULES          : WanATMF5LoopbackDiagnostics
**   DATE             : 04-09-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This module handles ADD/DEL/GET/SET RPCs of 
**                      WanATMF5LoopbackDiagnostics. When controller calls this
**                      module it calls the respective Platform/Object APIs to
**                      handle the GET/SET of WanATMF5LoopbackDiagnostics
**                      specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author        $Comment
**   04-09-06         TR69 team      Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/

//#include <sys/socket.h>
//#include <netinet/in.h>
//#include <arpa/inet.h>

#include "IFX_DEVM_WANATMF5LoopbackDiags.h"
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
 
 
 
/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;
extern Map_Value gaxWanDiagnosticState[];
#define IFX_WAN_ATMF5_LOOP_DIAG_OBJ "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANATMF5LoopbackDiagnostics."

//extern int32 ifx_config_get_value(char8 *, char8 *);
//extern int32 ifx_config_set_value(char8 *, char8 *);

//#define WAN_IP_CON_DEPTH 6
//#define WAN_CON_DEV_DEPTH 4

//#define WAN_IP_CON_ACC wancfg.ppp
//#define WAN_PPP_CON_ACC wancfg.ip


//#define WAN_IP_NO_DEP_OIDS 	2

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/




//extern Map_Value gaxEnable[];
//extern Map_Value saxDslLnkType[];

extern int32 IFX_ValidateDestAddr(char8 * dest_addr, int16 * Vpi, int32 * 
Vci);




/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/
static int32 
IFX_GetVccObj(ATM_VCC_INFO *ppxAtmVcc, uint32 iCpeid)
{
    uint32 iRet=0;
    ppxAtmVcc->iid.cpeId.Id=iCpeid;
        
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
    int uiNumOfEntries = 0;
    ATM_VCC_INFO *paxAtm_Vccs=NULL;
    iRet=ifx_get_all_vcc_info_stub(&uiNumOfEntries, &paxAtm_Vccs,iFlags);    
#else
    iRet=ifx_get_one_vcc_info(ppxAtmVcc);    
#endif

    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d ifx_get_all_vcc_info failed!\n", __func__, __LINE__);
        goto errorHandler;
    }
    return IFX_CWMP_SUCCESS;    
errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed!\n", __func__, __LINE__);
    return IFIN_CWMP_FAILURE;
}

#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
int32 ifx_set_wan_atm_f5_loop_stub(int32 op, WAN_ATMF5_LOOP_DIAGNOSTICS * pxWan_Atm_Diag, uint32 flags)
 	{

		if(pxWan_Atm_Diag == NULL)
		{
		   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Passed object has NULL Pointer !!! \n");
		   return IFX_SUCCESS;
		}
		
		if(op == IFX_OP_ADD)
		{
		 	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Add operation \n");
		}else if(op == IFX_OP_DEL)
		{
		 	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Del operation \n");
				
		 }else if (op == IFX_OP_MOD)
	 	{
	 		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Modify operation \n");
	 	}else 	
	 	{
	 	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: GET operation \n");
	 	}


		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_ATMF5_ENABLE=%d\n",flags);
		
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_ATMF5_CONFIG_OWNER=%d\n",pxWan_Atm_Diag->iid.config_owner);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_ATMF5_CPEID=%d\n",pxWan_Atm_Diag->iid.cpeId.Id);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_ATMF5_tr69id=%s\n",pxWan_Atm_Diag->iid.tr69Id);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_ATMF5_DIAG_STATE=%d\n",pxWan_Atm_Diag->diagnostic_state);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_ATMF5_TIMEOUT=%d\n",pxWan_Atm_Diag->ping_timeout);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_ATMF5_NOREPT=%d\n",pxWan_Atm_Diag->oam_pings);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_ATMF5_NORECV=%d\n",pxWan_Atm_Diag->success_count);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_ATMF5_MINTIME=%d\n",pxWan_Atm_Diag->min_resp_time);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_ATMF5_MAXTIME=%d\n",pxWan_Atm_Diag->max_resp_time);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_ATMF5_AVGTIME=%d\n",pxWan_Atm_Diag->avg_resp_time);

		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_ATMF5_VPI=%d\n",pxWan_Atm_Diag->vpi);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_ATMF5_VCI=%d\n",pxWan_Atm_Diag->vci);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_ATMF5_FENABLE=%d\n",pxWan_Atm_Diag->f_enable);
		
	return IFX_SUCCESS;
	}

#endif


static int32 
IFX_ConvertToWanATMF5LoopDiagStruct(IN uint32 iElements, IN ParamVal *paxParamVal,
								OUT WAN_ATMF5_LOOP_DIAGNOSTICS* pxDiag_State)
{
	uint32 i=0;
	int32 iRet=0;
	//uchar8 usDestAddr[MAX_NAME_LEN];
	uint32 uiParamPos=0;
	
	uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);
	
	for (i=0; i < iElements; i++) 
	{

	      	switch(paxParamVal->iaOID[uiParamPos])
		{

				case OID_IGD_WAND_WANCD_WANATMF5LD_DIAGNOSTICSSTATE:
					if(IFX_FwdMappingValues(gaxWanDiagnosticState,2,
							(void *)(paxParamVal->Value),
							(void *)&(pxDiag_State->diagnostic_state)) !=IFIN_CWMP_SUCCESS)
					{
						iRet=ERR_CWMP_INVAL_PARAM_VAL;
						goto errorHandler;
					}
					break;
				
				case OID_IGD_WAND_WANCD_WANATMF5LD_NUMBEROFREPETITIONS:
					pxDiag_State->oam_pings=
								atoi(paxParamVal->Value);
					break;
				case OID_IGD_WAND_WANCD_WANATMF5LD_TIMEOUT:
					pxDiag_State->ping_timeout=
								atoi(paxParamVal->Value);
					break;
										
									
				default:
					break;

		}


		++paxParamVal;
		
	}

	return IFIN_CWMP_SUCCESS;
	
	errorHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed ParamId=%d Value=%s !\n", 
					__func__, __LINE__,paxParamVal->iaOID[uiParamPos],
					(char8 *)paxParamVal->Value);
		return iRet;
		
}



/* 
** =============================================================================
**   Function Name    : IFX_WanATMF5LoopGetValue
**   Description        : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes                : 
**
** ============================================================================
*/
static int32 
IFX_WanATMF5LoopGetValue(IN OperInfo *pxOperInfo,INOUT ParamVal *pxGetParamVal,
								IN uint32 iElements)
{
	/*GET PARAMETER VALUES
	**Get Object OID(skip parameter ID) from the first 
	**element in the array.Get Cpeid for this Object OID

	**Get the object from the system using a Platform API
	**with cpeid 
	
	**Do reverse mapping to convert system values into TR69
	**Values.After conversion stores the values in temp storage

	**While assigning the values as per request store the 
	**values in heap and assign the ptr to the struct
	**Return all the values 
	*/

//#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
	uint32 uiFlags=0;
//#endif
	uint32 iCpeid=0,i=0;
	int32 iParamId=0;
	uint32 uiParamPos=0;
	//int32 iConType=0;
	int32 iRet=IFX_CWMP_SUCCESS;
	//uint32 uiNoEntries=0;
	uint32 uiMode=IFX_CHK_VALUE_BASED;
	//uchar8 sTemp[PARAMVALUE_LEN];
	WAN_ATMF5_LOOP_DIAGNOSTICS pxWan_AtmF5_Diag;
	
	// Get Cpeid from object ID
	iRet = IFX_GetCpeId(pxGetParamVal->iaOID,&iCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	memset(&pxWan_AtmF5_Diag, '\0',sizeof(pxWan_AtmF5_Diag));
	
	pxWan_AtmF5_Diag.iid.cpeId.Id =iCpeid;
	uiFlags = IFX_F_GET_ANY;
	
	// Get match object from system using Platform API
#ifdef MIPSTARGET
	iRet = ifx_get_atmf5_loop_diagnostics(&pxWan_AtmF5_Diag, uiFlags);	
#endif
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	//Get the WanIpConParamPos 
	uiParamPos = IFX_GetParamIdPos(pxGetParamVal->iaOID);

		
	for(i=0;i < iElements; i++)
	{
	
		iParamId = pxGetParamVal->iaOID[uiParamPos];
	
		// Malloc and assign the pointer to the Value attr of struct 
		pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
		if(pxGetParamVal->Value == NULL){
		   iRet = ERR_OUT_OF_MEMORY; 
		   goto errorHandler;
		}
		switch(iParamId)
		{

			// Convert the value - reverse mapping
			// Assign the correct value to the Value attr	
	    		case OID_IGD_WAND_WANCD_WANATMF5LD_DIAGNOSTICSSTATE:

				if(IFX_RevMappingValues(gaxWanDiagnosticState,7,
							(void *)&(pxWan_AtmF5_Diag.diagnostic_state),
							(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
					
				goto errorHandler;


				break;	 
					
	    		case OID_IGD_WAND_WANCD_WANATMF5LD_NUMBEROFREPETITIONS:
				
				sprintf(pxGetParamVal->Value,"%d",
					pxWan_AtmF5_Diag.oam_pings);
				
				break;	 

			case OID_IGD_WAND_WANCD_WANATMF5LD_TIMEOUT:
				
				sprintf(pxGetParamVal->Value,"%d",
						pxWan_AtmF5_Diag.ping_timeout);
				break;
				
								
			case OID_IGD_WAND_WANCD_WANATMF5LD_SUCCESSCOUNT:
				
				sprintf(pxGetParamVal->Value,"%d",
					pxWan_AtmF5_Diag.success_count);
				
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
		
				break;
			case OID_IGD_WAND_WANCD_WANATMF5LD_FAILURECOUNT:
				
				sprintf(pxGetParamVal->Value,"%d", pxWan_AtmF5_Diag.failure_count);
				
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
					break;
					
			case OID_IGD_WAND_WANCD_WANATMF5LD_MINIMUMRESPONSETIME:
				sprintf(pxGetParamVal->Value,"%d",pxWan_AtmF5_Diag.min_resp_time);
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
			case OID_IGD_WAND_WANCD_WANATMF5LD_MAXIMUMRESPONSETIME:
				sprintf(pxGetParamVal->Value,"%d",pxWan_AtmF5_Diag.max_resp_time);
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
			case OID_IGD_WAND_WANCD_WANATMF5LD_AVERAGERESPONSETIME:
				sprintf(pxGetParamVal->Value,"%d",pxWan_AtmF5_Diag.avg_resp_time);
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			
			default:
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "Invalid param id %d!\n", iParamId);
			pxGetParamVal->iFaultCode=ERR_INVAL_PARAMETER_VAL;
			break;
		}

							
			++pxGetParamVal;
	}
	
		
		return IFX_CWMP_SUCCESS;
		
		errorHandler:
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
			ifx_set_wan_atm_f5_loop_stub(pxOperInfo->iOper, &pxWan_AtmF5_Diag, uiFlags);
#endif
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed ParamId=%d !\n", __func__, __LINE__,iParamId);
			
			return IFIN_CWMP_FAILURE;
			

}

/* 
** =============================================================================
**   Function Name    : IFX_WanATMF5LoopSetValidate
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanATMF5LoopSetValidate(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
							IN int32 iElements)
{
	
	
	return IFIN_CWMP_SUCCESS;

}

/* 
** =============================================================================
**   Function Name    : IFX_WanATMF5LoopAddObj
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanATMF5LoopAddObj(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{
	/* This API calls a Platform API which adds the object
	** in ADD_DISABLE state.
	** Pass necessary flags to the API
	** Controller should get the next instance id from DS 
    	** module and pass the full OID to this module.
	*/

	/* If Cisco proposal comes, this API should handle 
	**  a) Validation of values
	**  b) Forward mapping of TR69 values to system values 
	**  c) addition of object into the system
	*/
	
	uint32 iFlags=0;
	int32 iRet=0;
	uint32 iOper=0;
	//uint32 uiOutElem=0;
	uint32 uiPcpeId=0;
        uint32 cpeid = 0;
	char8 usDestAddr[MAX_NAME_LEN]={0};
	WAN_ATMF5_LOOP_DIAGNOSTICS xWan_Atm_Diag;
	int32 iaWanDslLinkDestAddr[OID_LENGTH]={0,0,0,0,0,OID_IGD_WAND_WANCD_WANDSLLC,
			OID_IGD_WAND_WANCD_WANDSLLC_DESTINATIONADDRESS};
        int32 DSLLinkCfgOID[OID_LENGTH];
        ATM_VCC_INFO xAtm_Vcc_Cfg;

	memset(&xWan_Atm_Diag, 0, sizeof(xWan_Atm_Diag));
	
	//If owner is WEB don't add the object just return success.
	iRet = IFX_ConvertToWanATMF5LoopDiagStruct(iElements, pxParamVal, &xWan_Atm_Diag);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	iRet = IFX_GetParentObjCpeId(pxParamVal->iaOID,&uiPcpeId);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	//memset the structs passed to GlobalGetVal
	memset(DSLLinkCfgOID,0x00,(sizeof(int32) * OID_LENGTH));
	
	//Get DestinationAddress from WanDslLinkConfig module
	//Set these values got from global function in the xWan_Conn struct
	memcpy(DSLLinkCfgOID, iaWanDslLinkDestAddr, (OID_LENGTH*sizeof(int32)));
	memcpy(DSLLinkCfgOID, pxParamVal->iaOID, ((WAN_CON_DEV_DEPTH+1)*sizeof(int32)));

        //Get the Cpeid from Tr69 id
        iRet = IFX_GetCpeId(DSLLinkCfgOID, &cpeid);
        if(iRet != IFX_CWMP_SUCCESS)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Get Cpe ID Failed!\n", __func__, __LINE__);
            goto errorHandler;
        }
        
        xAtm_Vcc_Cfg.iid.cpeId.Id = cpeid;
        //Get the object from system
        iRet= IFX_GetVccObj(&xAtm_Vcc_Cfg, cpeid);
        if(iRet != IFX_CWMP_SUCCESS)
            goto errorHandler;

        sprintf(usDestAddr, "PVC: %d/%d", xAtm_Vcc_Cfg.vc.pvc.vpi,xAtm_Vcc_Cfg.vc.pvc.vci);

	if(pxParamVal[0].iaOID[2] == WAN_DEVICE_ATM)
	{
		if(IFX_ValidateDestAddr(usDestAddr,
				(int16 *)&(xWan_Atm_Diag.vpi),
				(int32 *)&(xWan_Atm_Diag.vci))
						    !=IFIN_CWMP_SUCCESS)
		{
			iRet=ERR_CWMP_INVAL_PARAM_VAL;
			goto errorHandler;
		}
	}
	//Flags should be filled
	//Fills the Cpeid,ParentCepid,TR69Id,Owner
	//Fill the operation
	iOper = IFX_OP_ADD;
	iFlags =( IFX_F_DONT_CHECKPOINT | IFX_F_DONT_VALIDATE | IFX_F_DONT_WRITE_TO_FLASH);
	
	xWan_Atm_Diag.iid.config_owner=pxOpInfo->iCaller;
	xWan_Atm_Diag.iid.cpeId.Id=0;
	xWan_Atm_Diag.iid.pcpeId.Id=uiPcpeId;
	xWan_Atm_Diag.f_enable=IFX_ENABLED;
	xWan_Atm_Diag.diagnostic_state = WAN_DIAG_NONE;
	
	//Convert array into dotted form and then strcpy
	iRet = IFX_ConvertOidDottedForm(pxParamVal->iaOID, xWan_Atm_Diag.iid.tr69Id);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

    /* Nirint: If WANDevice.{i}. != 1 (ATMWAN) then vpi = 256.
           So that Web can mask it. */
	if(pxParamVal[0].iaOID[2] != WAN_DEVICE_ATM)
	{
		xWan_Atm_Diag.vpi = WANETH_VPI_VAL;
		xWan_Atm_Diag.vci = WANETH_VCI_VAL;
	}
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
	ifx_set_wan_atm_f5_loop_stub(iOper, &xWan_Atm_Diag, iFlags);

#else

	iRet = ifx_set_atmf5_loop_diagnostics(iOper, &xWan_Atm_Diag, iFlags);
#endif

	if(iRet != IFX_SUCCESS)
	{
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "ifx_set_atmf5_loop_diagnostics Add Mgmt API returned error\n");
		goto errorHandler;
	}	
	return IFIN_CWMP_SUCCESS;

errorHandler:
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
	return IFIN_CWMP_FAILURE;

}

/* 
** =============================================================================
**   Function Name    : IFX_WanATMF5LoopSetValue
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanATMF5LoopSetValue(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
							IN int32 iElements)
{

	//It can support only one state change in a SET operation.
	//Enabled to Disabled, Disabled to Enabled 
	
	//Get the Cpeid
	//Get the object from the system
	//Get the state(Enable/Disbale) of the object

	//Handle CHECK_MODIFY_DEP
	//Check if the state change is allowed or not

	//Handle MODIFY	
	//Get the old state
	//Forward mapping of values

	//Modify Enabled object
	//Modify Disabled object
	//Modify the disabled object and enable that object.
	//Diable the object and modify it.


	//uint32 i;
	uint32 uiCpeid=0;
	//uint32 uiOld_EnableVal=0;
	WAN_ATMF5_LOOP_DIAGNOSTICS pxWan_Atm_Diag;
	int32 iRet=IFX_CWMP_SUCCESS;
	uint32 iOper=0,iFlags=0;
	uint32 uiOutElem=0;
	uint32 uiFlags=0;
	int32 iFIFOFd=0;
	int16 vpi=0;
	int32 vci=0;
	//parent objects parameters
	char8 usDestAddr[PARAMVALUE_LEN] = { 0 };
	int32 iaWanDslLinkDestAddr[OID_LENGTH]={0,0,0,0,0,OID_IGD_WAND_WANCD_WANDSLLC,
			OID_IGD_WAND_WANCD_WANDSLLC_DESTINATIONADDRESS};
	ParamVal xInWanDslLinkConf;
	ParamVal *xOutWanDslLinkConf=NULL;

        if(paxParamVal[0].iaOID[2] != WAN_DEVICE_ATM) {
            iRet = IFX_CWMP_SUCCESS;
            goto errorHandler;
        }

	
	//Get the Cpeid from Tr69 id
	iRet = IFX_GetCpeId(paxParamVal->iaOID,&uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	
	memset(&pxWan_Atm_Diag, '\0',sizeof(pxWan_Atm_Diag));
	
	pxWan_Atm_Diag.iid.cpeId.Id =uiCpeid;
	uiFlags = IFX_F_GET_ANY;
	
	// Get match object from system using Platform API
#ifdef MIPSTARGET
	iRet = ifx_get_atmf5_loop_diagnostics(&pxWan_Atm_Diag, uiFlags);	
#endif
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	//Get the WanIpConParamPos 
	IFX_GetParamIdPos(paxParamVal->iaOID);
		
	//Modify on top of old values.
	if(pxOpInfo->iSubOper != OP_SETVAL_ACTIVATE)
	{
		iRet=IFX_ConvertToWanATMF5LoopDiagStruct(iElements, paxParamVal, &pxWan_Atm_Diag);          
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;
	}
	
	switch(pxOpInfo->iSubOper)
		{
			
			case OP_SETVAL_CHK_MODIFY_DEP:
						
				break;
					
			case OP_SETVAL_MODIFY:
				

				//Pass the flags based on f_enable flag
								
				
				if(pxWan_Atm_Diag.f_enable== IFX_ENABLED) 
				{
								
				
						//Call the API with Modify flags
						iFlags= (IFX_F_MODIFY|
							IFX_F_DONT_CHECKPOINT|
							IFX_F_DONT_WRITE_TO_FLASH);
							
						pxWan_Atm_Diag.f_enable = IFX_ENABLED;
					

				}
				else if (pxWan_Atm_Diag.f_enable == IFX_DISABLED)
				{

					
						//Call with don't activate and modify
						iFlags= (IFX_F_DONT_ACTIVATE|IFX_F_MODIFY|
							IFX_F_DONT_CHECKPOINT|IFX_F_DONT_VALIDATE|
							IFX_F_DONT_WRITE_TO_FLASH);
							
						pxWan_Atm_Diag.f_enable = IFX_DISABLED;
					
				}


			//if(pxWan_Atm_Diag.f_enable == IFX_ENABLED) 
			//{
				//Get the parentInfo like VCC before enabling the WanIpConnection

				//memset the structs passed to GlobalGetVal
				memset(&xInWanDslLinkConf,0x00,sizeof(ParamVal));
				
				//Get DestinationAddress from WanDslLinkConfig module
				//Set these values got from global function in the xWan_Conn struct
					memcpy(xInWanDslLinkConf.iaOID,iaWanDslLinkDestAddr,
									(OID_LENGTH*sizeof(int32)));
					memcpy(xInWanDslLinkConf.iaOID,paxParamVal->iaOID,
									((WAN_CON_DEV_DEPTH+1)*sizeof(int32)));
			
					//Get the value using global function
					
					iRet = IFX_GlobalGetVal(&xInWanDslLinkConf, &xOutWanDslLinkConf,&uiOutElem);
					if((iRet != IFX_CWMP_SUCCESS) ||(xOutWanDslLinkConf ==NULL))
						{
						IFX_PrintOID(xInWanDslLinkConf.iaOID);
						IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                           		 "%s:%d IFX_GlobalGetVal failed!\n", __func__, __LINE__);
						goto errorHandler;
						}
					//Convert to Vpi/Vci
					strcpy(usDestAddr,(char8 *)xOutWanDslLinkConf->Value);
					if(IFX_ValidateDestAddr(usDestAddr,&vpi,&vci)
									    !=IFIN_CWMP_SUCCESS)
					{
						iRet=ERR_CWMP_INVAL_PARAM_VAL;
						goto errorHandler;
					}
					pxWan_Atm_Diag.vpi=vpi;
					pxWan_Atm_Diag.vci=vci;

					//Free the members of xOutWanDslLinkConf & xOutWanDslLinkConf
					iRet = IFX_FreeParamvalArr(&xOutWanDslLinkConf,uiOutElem);
					if(iRet != IFX_CWMP_SUCCESS)
						goto errorHandler;
				
			


			 //}

						
				//Fills the Cpeid,ParentCepid,TR69Id,Owner
				pxWan_Atm_Diag.iid.cpeId.Id=uiCpeid;
				pxWan_Atm_Diag.iid.config_owner=pxOpInfo->iCaller;
				//pxWan_Atm_Diag.scope=
				iOper = IFX_OP_MOD;
				
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS

		ifx_set_wan_atm_f5_loop_stub(iOper, &pxWan_Atm_Diag, iFlags);

#else

#ifdef MIPSTARGET
		iRet = ifx_set_atmf5_loop_diagnostics(iOper, &pxWan_Atm_Diag, iFlags);
#endif
#endif


			if(iRet != IFX_SUCCESS)
			{
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					"ifx_set_atmf5_loop_diagnostics -Modify Mgmt API returned error\n");
				goto errorHandler;
				
			}	

				 //Check if Diagnostic_state is set to Requested then
				//Change the ret values to NEED_ACTIVATE 
				if(pxWan_Atm_Diag.diagnostic_state ==WAN_DIAG_REQUESTED)
				{
					iRet = IFX_CWMP_NEED_ACTIVATE;
				}

				
				break;

			case OP_SETVAL_ACTIVATE:

				//Check if requested then start the atm_f5_loop_diagnostics
				//Enable the object
				//Call the API
				pxWan_Atm_Diag.diagnostic_state=WAN_DIAG_START_DIAGNOSING;
				pxWan_Atm_Diag.loopback =LOOPBACK_ENABLED; 
				pxWan_Atm_Diag.f_enable = IFX_ENABLED;
				//Pass the correct scope ::TBD
				pxWan_Atm_Diag.scope = 0;
				pxWan_Atm_Diag.iid.cpeId.Id=uiCpeid;
				pxWan_Atm_Diag.iid.config_owner=ACC_TR69;
				iOper = IFX_OP_MOD;
				iFlags= (IFX_F_MODIFY|
							IFX_F_DONT_CHECKPOINT|
							IFX_F_DONT_WRITE_TO_FLASH);
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
				ifx_set_wan_atm_f5_loop_stub(iOper, &pxWan_Atm_Diag, iFlags);

#else

#ifdef MIPSTARGET
				iRet = ifx_set_atmf5_loop_diagnostics(iOper, &pxWan_Atm_Diag, iFlags);
#endif
#endif
				if(iRet != IFX_SUCCESS)
				{
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
						"ifx_set_atmf5_loop_diagnostics -Activate Mgmt API returned error\n");
					goto errorHandler;
					
				}	

				/* Send msg to FIFO */
			    iFIFOFd = IFX_OS_OpenFifo((uchar8 *)IFX_IPC_TR_FIFO, O_RDWR);
			    if(iFIFOFd < 0) {
			        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s:%d Error opening FIFO\n",
			                    __func__, __LINE__);
			        iRet = ERR_CWMP_FIFO_OPEN;
			        goto errorHandler;
			    }

			    if(IFX_IPC_SendMsg(iFIFOFd, (uchar8) IFX_IPC_APP_DIAGNOSTIC, 0, 0, 0, NULL)
			       != IFX_IPC_SUCCESS) {
			        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Error sending msg to "
			                    "FIFO\n", __func__, __LINE__);
			    }
			    IFX_OS_CloseFifo(iFIFOFd);

			default:
				break;
					
		}
	
	return iRet;
	
	errorHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
                IFX_FreeParamvalArr(&xOutWanDslLinkConf,uiOutElem);
		return iRet;

}

/* 
** =============================================================================
**   Function Name    : IFX_WanATMF5LoopSetCommit
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanATMF5LoopSetCommit()
{
	return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanATMF5LoopSetUndo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanATMF5LoopSetUndo()
{
	return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanATMF5LoopSetDelete
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanATMF5LoopSetDelete(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
							IN int32 iElements, OUT void **ppxParamStructRet,
												   OUT int32 * piNumRetElem)
{

	//uint32 i,
	uint32 uiCpeid=0;
	//uint32 uiOld_EnableVal=0;
	//WAN_CONN_CFG*pxMatch_Wan_Conn=NULL;
	int32 iRet=0;
	uint32 iOper=0,uiFlags=0;
	//uint32 uiParamPos;
	WAN_ATMF5_LOOP_DIAGNOSTICS xWan_Atm_Diag;
	
	// handle CHK_DELETE_DEP
	if(pxOpInfo->iSubOper == OP_SETVAL_CHK_DEL_DEP)
	{
		
		return IFIN_CWMP_SUCCESS;
		
	}
	
	//Get the Cpeid from Tr69 id
#ifdef MIPSTARGET
	iRet = IFX_GetCpeId(paxParamVal->iaOID,&uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
#endif
	
	memset(&xWan_Atm_Diag, '\0',sizeof(xWan_Atm_Diag));
	
	xWan_Atm_Diag.iid.cpeId.Id =uiCpeid;
	uiFlags = IFX_F_GET_ANY;
	
	// Get match object from system using Platform API
#ifdef MIPSTARGET
	iRet = ifx_get_atmf5_loop_diagnostics(&xWan_Atm_Diag, uiFlags);	
#endif
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
		
		
	switch(pxOpInfo->iSubOper)
		{
		case OP_SETVAL_CHK_DEL_ALLOWED:
			// handle CHK_DELETE_ALLOWED
			//Check for default instance if del is called by TR69
			//if(pxMatch_Atm_Vcc->f_default == IFX_DEFAULT)
			//	goto errorHandler;
			
			break;
		case OP_SETVAL_DELETE:
			//handle DELETE operation
			//Call Platform API to delete the obj in the system
			//If del is called by web we need to pass special owner for which API 
			//will not post a message.
			
			xWan_Atm_Diag.iid.config_owner=pxOpInfo->iCaller;
			xWan_Atm_Diag.iid.cpeId.Id=uiCpeid;
			memset(xWan_Atm_Diag.iid.tr69Id,0x00,MAX_TR69_ID_LEN);
			
			iOper = IFX_OP_DEL;
			uiFlags = (IFX_F_DELETE|IFX_F_DONT_VALIDATE|
					IFX_F_DONT_CHECKPOINT|IFX_F_DONT_WRITE_TO_FLASH);
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
			ifx_set_wan_atm_f5_loop_stub(iOper, &xWan_Atm_Diag, uiFlags);

#else

#ifdef MIPSTARGET
			iRet = ifx_set_atmf5_loop_diagnostics(iOper, &xWan_Atm_Diag, uiFlags);
#endif
#endif
			
				if(iRet != IFX_SUCCESS)
				{
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
						"ifx_set_atmf5_loop_diagnostics -delete Mgmt API returned error\n");
					goto errorHandler;
					
				}
			break;
			
		default:
			break;
		}
		
		return IFIN_CWMP_SUCCESS;
	
	errorHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
		
		return IFIN_CWMP_FAILURE;

}

/* 
** =============================================================================
**   Function Name    : IFX_WanATMF5LoopSetFree
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanATMF5LoopSetFree()
{
	return IFX_CWMP_SUCCESS;
}


/* 
** =============================================================================
**   Function Name    : IFX_WanATMF5LoopSetAttr
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

int32
IFX_WanATMF5LoopSetAttr(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{
	int32 iRet=0,i=0;
	OperInfo xOpInfo;
	
	xOpInfo.iCaller = pxOpInfo->iCaller;
	xOpInfo.iOper= OP_GETVAL;
	xOpInfo.iSubOper= OP_GETVAL_NORMAL;
	
	iRet = IFX_WanATMF5LoopGetValue(&xOpInfo,pxParamVal, iElements);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorFreeHandler;
	
	iRet = IFX_SetAttributesInfo(pxOpInfo, pxParamVal, iElements);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;

	for(i=0; i < iElements; i++)
		IFX_CWMP_FREE(pxParamVal[i].Value);

	return IFX_CWMP_SUCCESS;

	errorFreeHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
		for(i=0; i < iElements; i++)
		IFX_CWMP_FREE(pxParamVal[i].Value);
		
	errorHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
		return iRet;
		


}




/* 
** =============================================================================
**   Function Name    : IFX_WanATMF5LoopbackDiagnostics_Init
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_WanATMF5LoopbackDiagnostics_Init(void)
{
	int32 iRet = IFX_CWMP_SUCCESS;

    
	/* Register the WanDslLinkConfig module function pointer in the object model */
	iRet = ifx_ds_register_function(IFX_WAN_ATMF5_LOOP_DIAG_OBJ, IFX_WanATMF5LoopbackDiagnostics);

	/* Check for error */
	if (iRet != IFX_CWMP_SUCCESS)
	{
	    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                "Unable to Register %s with Object Model\n",
	                 IFX_WAN_ATMF5_LOOP_DIAG_OBJ);
	    goto errorHandler;
	}

	errorHandler:
			return iRet;
}

/*********************************************************************************
*  Function Name	:  IFX_WanATMF5LoopbackDiagnostics
      *  Description	:  This function handles all the sub-states inside
      	 		   a GET/SET operation.If it is a GET it allocates the 
			   array(Name,Value pairs) and retruns the values.
			   If it is a SET controller allocates the array and
			   passes the values to this function.It calls 
			   respective internal functions which in turn calls 
			   respective Platform APIs.
                                                                                                 
*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
							     Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has 
					  	             Name,Value,etc
                    IN          int32	       iElements;    No. of Elements
		    OUT	        void *	       ppParamRet;   same as ParamStruc
		    OUT         int32 *        piNumRetElem; No. of elements 		                                
*  Return Value        : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes               :
***********************************************************************************/
int32
IFX_WanATMF5LoopbackDiagnostics(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                IN int32 iElements, OUT void **ppaxParamArrRet, OUT int32 *piNumRetElem)
{
     
   //It calls the respective internal functions which handles resp. sub-operation
   
   //Set-Operation  
   //controller should pass the entire array during all the SET-sub_operations
   //It should handles only single get/set of instance at any point of time
   //It does not handle partial path
   //It won't handle multiple instances of the same object/module
   //at any point of time.

    
    int32 iRet = 0;
    ParamVal *paxParamArr = (ParamVal *)paxParameterArr;
    int32 iCnt = 0;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Oper=%d:%d '%s' Num=%d\n",
                _FUNCL_, pxOperInfo->iOper, pxOperInfo->iSubOper,
                paxParamArr[0].Name, iElements);

    /* if != IGD.WANDevice.1. then not a DSL Connection. Return SUCCESS. */
	switch (pxOperInfo->iOper) 
	{
		//Get the object values
	   	case OP_GETVAL:
		
	            if((iRet = IFX_WanATMF5LoopGetValue(pxOperInfo, paxParamArr,
		    							iElements)) != IFX_CWMP_SUCCESS) {
	                
					
			  IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
			  goto errorHandler;
	            }
	            break;
	        case OP_SETVAL:
		{

	    		//Set the obj values
			switch (pxOperInfo->iSubOper) 
			{
		               case OP_SETVAL_VALIDATE:
		                    if((iRet = IFX_WanATMF5LoopSetValidate(pxOperInfo,paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {     
		                        
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d OP_SET_VALIDATE failed!\n", __func__, __LINE__);
					goto errorHandler;
		                    }
		                 
		                    break;
		                case OP_SETVAL_ADD:
		                    
		                    if((iRet= IFX_WanATMF5LoopAddObj(pxOperInfo,paxParamArr,
				    					iElements))!=IFX_CWMP_SUCCESS)
		                    	{
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            	"%s:%d OP_SETVAL_ADD failed!\n", __func__, __LINE__);
		                    	 goto errorHandler;
		                    	}
		                    break;
		                case OP_SETVAL_CHK_MODIFY_DEP:
				case OP_SETVAL_MODIFY:
				case OP_SETVAL_ACTIVATE:
		                    if((iRet = IFX_WanATMF5LoopSetValue(pxOperInfo,paxParamArr,
				    					iElements))!= IFX_CWMP_SUCCESS) 
		    			{									
					  	switch(pxOperInfo->iSubOper)
					  	{
						  	 case OP_SETVAL_CHK_MODIFY_DEP:
							IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_CHK_MODIFY_DEP failed!\n", __func__, __LINE__);
				                        goto errorHandler;
										
							case OP_SETVAL_MODIFY:
							IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_MODIFY failed!\n", __func__, __LINE__);
				                        goto errorHandler;
					  	}
				    	 }
							
		                   
		                    break;
		                case OP_SETVAL_COMMIT:
		                    if((iRet = IFX_WanATMF5LoopSetCommit(pxOperInfo,paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
				    	   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_COMMIT failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;
		                case OP_SETVAL_UNDO:
		                    if((iRet =IFX_WanATMF5LoopSetUndo(pxOperInfo, paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
				    	   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_UNDO failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;
				case OP_SETVAL_CHK_DEL_DEP:
				case OP_SETVAL_CHK_DEL_ALLOWED:
		              case OP_SETVAL_DELETE:
		                    if((iRet= IFX_WanATMF5LoopSetDelete(pxOperInfo, paxParamArr,
				    					iElements, ppaxParamArrRet,
				    					piNumRetElem))!= IFX_CWMP_SUCCESS) {
				    		switch(pxOperInfo->iSubOper)
						{	
					  		case OP_SETVAL_CHK_DEL_DEP:
						    	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
				                        goto errorHandler;
							case OP_SETVAL_CHK_DEL_ALLOWED:
								IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
				                        goto errorHandler;
							case OP_SETVAL_DELETE:
								IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
				                        goto errorHandler;
						}
								
		                    goto errorHandler;
				    }
		                    break;
		                case OP_SETVAL_FREE:
		                    IFX_WanATMF5LoopSetFree(pxOperInfo);
		                    break;

				 case OP_SETVAL_ATTRINFO:
				 	if((iRet =IFX_WanATMF5LoopSetAttr(pxOperInfo, paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
				    	  IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            	"%s:%d OP_SETVAL_ATTRINFO failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;	
		                default:
		                    break;
			}
			
			break;	
	        }
		case OP_UPDATE_CHILDINFO:
		    break;
                case OP_PARAM_VALIDATE:
                {
                    //IGD.WD.2. or IGD.WD.3.
                    if(((paxParamArr->iaOID[2]) == WAN_DEVICE_MII0) || ((paxParamArr->iaOID[2]) == WAN_DEVICE_MII1))
                    {
                        /* Set the fault code to Error */
                        for(iCnt = 0; iCnt < iElements; iCnt++)
                        {
                            paxParamArr[iCnt].iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
                        }
                        goto errorHandler;
                    }
                    else if((paxParamArr->iaOID[2]) == WAN_DEVICE_ATM)
                    {
                        /*IGD.WD.1.WCD.1 is for PTMLC*/
                        if((paxParamArr->iaOID[4]) == 1)
                        {
                            /* Set the fault code to Error */
        	            for(iCnt = 0; iCnt < iElements; iCnt++)
	                    {
                	        paxParamArr[iCnt].iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
        	            }
        	            goto errorHandler;
                        }
                    }
                    break; 
                }
	        default:
                {
	            break;
                }
	}
	return IFX_CWMP_SUCCESS;

errorHandler:
	return iRet;
}
 
