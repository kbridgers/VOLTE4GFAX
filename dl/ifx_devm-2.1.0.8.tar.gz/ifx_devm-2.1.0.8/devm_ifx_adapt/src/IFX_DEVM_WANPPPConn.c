/* 
** =============================================================================
**   FILE NAME        : IFX_WanPPPConnection.c
**   PROJECT          : TR69
**   MODULES          : WanPPPConnection
**   DATE             : 23-08-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This module handles ADD/DEL/GET/SET RPCs of 
**                      WanPPPConnection. When controller calls this module it
**                      calls respective Platform/Object APIs to handle GET/SET 
**                      of WanPPPConnection specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author        $Comment
**   23-08-06         TR69 team      Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "IFX_DEVM_WANPPPConn.h"
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
 
#include "IFX_DEVM_StackUtil.h"

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;
#define IFX_WAN_PPPCON_OBJ "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.1."
#define WAN_PPP_NO_DEP_OIDS 	2
extern uint32 guiConnReqIPAddr;
extern Old_Enable_Val axOldPPPState[];

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/

extern Map_Value gaxEnable[];
extern Map_Value saxDslLnkType[];
extern Map_Value saxWanIpConTrigger[];
extern Map_Value saxWanIpRouteProto[];

extern int32 IFX_GetWanObj(WAN_CONN_CFG *ppxWanConn, uint32 iCpeid);
extern int32 IFX_GetWanIpNoPortMapObjs(char8 *usConnName, uint32 *NoOfPortEntries);
extern int32 IFX_ValidateDestAddr(char8 * dest_addr, int16 * Vpi, int32 * Vci);
extern int32 IFX_WanDslLinkConfig (IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
             OUT void **ppRet, OUT int32 *piNumRetElem);
extern int32 IFX_CheckIfWanConnPresent(int32 *iaOID);

static char8 susWanPPPPossibleConTypes[]={"Unconfigured,IP_Routed,PPPoE_Bridged,PPPoE_Relay"};
uint32 uiActiveWANPPPCpeid=0;

static Map_Value saxWanPPPConStatus[] ={
{"Unconfigured",SYS_DATATYPE_INT,{.uiSys_Value=WAN_PPP_CONN_STATUS_UNCONFIGURED}},
{"Connecting",SYS_DATATYPE_INT,{.uiSys_Value=WAN_PPP_CONN_STATUS_CONNECTING}},
{"Connected",SYS_DATATYPE_INT,{.uiSys_Value=WAN_PPP_CONN_STATUS_CONNECTED}},
{"PendingDisconnect",SYS_DATATYPE_INT,{.uiSys_Value=WAN_PPP_CONN_STATUS_PENDING_DISCONNECT}},
{"Authenticating",SYS_DATATYPE_INT,	{.uiSys_Value=WAN_PPP_CONN_STATUS_AUTHENTICATING}},
{"Disconnecting",SYS_DATATYPE_INT,{.uiSys_Value=WAN_PPP_CONN_STATUS_DISCONNECTING}},
{"Disconnected",SYS_DATATYPE_INT,{.uiSys_Value=WAN_PPP_CONN_STATUS_DISCONNECTED}}
};

static Map_Value saxWanPPPConType[]={
{"Unconfigured",SYS_DATATYPE_INT,{.uiSys_Value=WAN_PPP_CONN_TYPE_UNCONFIGURED}},
{"IP_Routed",SYS_DATATYPE_INT,{.uiSys_Value=WAN_PPP_CONN_TYPE_IP_ROUTED}},
};

static Map_Value saxWanPPPTransportType[]={
{"PPPoA",SYS_DATATYPE_INT,{.uiSys_Value=WAN_PPP_TRANSPORT_TYPE_PPPOA}},
{"PPPoE",SYS_DATATYPE_INT,{.uiSys_Value=WAN_PPP_TRANSPORT_TYPE_PPPOE}},
};

static Map_Value saxWanPPPEncrypProto[]={
{"None",SYS_DATATYPE_INT,{.uiSys_Value=WAN_PPP_ENCR_PROTO_NONE}},
{"MPPE",SYS_DATATYPE_INT,{.uiSys_Value=WAN_PPP_ENCR_PROTO_MPPE}}
};

static Map_Value saxWanPPPCompProto[]={
{"None",SYS_DATATYPE_INT,{.uiSys_Value=WAN_PPP_COMPR_PROTO_NONE}},
{"Van Jacobsen",SYS_DATATYPE_INT,{.uiSys_Value=WAN_PPP_COMPR_PROTO_VANJACOBSON}},
{"STAC LZS",SYS_DATATYPE_INT,{.uiSys_Value=WAN_PPP_COMPR_PROTO_STACLZS}}
};

static Map_Value saxWanPPPAuthProto[]={
{"PAP",SYS_DATATYPE_INT,{.uiSys_Value=WAN_PPP_AUTH_PROTO_PAP}},
{"CHAP",SYS_DATATYPE_INT,{.uiSys_Value=WAN_PPP_AUTH_PROTO_CHAP}},
{"MS-CHAP",SYS_DATATYPE_INT,{.uiSys_Value=WAN_PPP_AUTH_PROTO_MSCHAP}}
};


static Map_Value saxWanPPPLastConError[] ={
{"ERROR_NONE",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_NONE}},
{"ERROR_ISP_TIME_OUT",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_ISP_TIME_OUT}},
{"ERROR_COMMAND_ABORTED",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_COMMAND_ABORTED}},
{"ERROR_NOT_ENABLED_FOR_INTERNET",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_NOT_ENABLED_FOR_INTERNET}},
{"ERROR_BAD_PHONE_NUMBER",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_BAD_PHONE_NUMBER}},
{"ERROR_USER_DISCONNECT",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_USER_DISCONNECT}},
{"ERROR_ISP_DISCONNECT",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_ISP_DISCONNECT}},
{"ERROR_IDLE_DISCONNECT",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_IDLE_DISCONNECT}},
{"ERROR_FORCED_DISCONNECT",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_FORCED_DISCONNECT}},
{"ERROR_SERVER_OUT_OF_RESOURCES",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_SERVER_OUT_OF_RESOURCES}},
{"ERROR_RESTRICTED_LOGON_HOURS",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_RESTRICTED_LOGON_HOURS}},
{"ERROR_ACCOUNT_DISABLED",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_ACCOUNT_DISABLED}},
{"ERROR_ACCOUNT_EXPIRED",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_ACCOUNT_EXPIRED}},
{"ERROR_PASSWORD_EXPIRED",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_PASSWORD_EXPIRED}},
{"ERROR_AUTHENTICATION_FAILURE",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_AUTHENTICATION_FAILURE}},
{"ERROR_NO_DIALTONE",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_NO_DIALTONE}},
{"ERROR_NO_CARRIER",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_NO_CARRIER}},
{"ERROR_NO_ANSWER",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_NO_ANSWER}},
{"ERROR_LINE_BUSY",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_LINE_BUSY}},
{"ERROR_UNSUPPORTED_BITSPERSECOND",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_UNSUPPORTED_BPS}},
{"ERROR_TOO_MANY_LINE_ERRORS",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_TOO_MANY_LINE_ERRORS}},
{"ERROR_IP_CONFIGURATION",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_IP_CONFIGURATION}},
{"ERROR_UNKNOWN",SYS_DATATYPE_INT,{.uiSys_Value=WANPPP_LAST_CONN_ERROR_UNKNOWN}}
};



/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/

#ifdef IFX_TR69_ADSLWAN
static int32 
IFX_GetVccObj(ATM_VCC_INFO *ppxAtmVcc, uint32 iCpeid)
{
    uint32 iRet=0;
    ppxAtmVcc->iid.cpeId.Id=iCpeid;
        
    iRet=ifx_get_one_vcc_info(ppxAtmVcc);    

    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d ifx_get_all_vcc_info failed!\n", __func__, __LINE__);
        goto errorHandler;
    }
    return IFX_CWMP_SUCCESS;    
errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed!\n", __func__, __LINE__);
    return IFIN_CWMP_FAILURE;
}
#endif

#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
int32 ifx_set_wan_atm_vcc_ppp_config_stub(int32 op, WAN_CONN_CFG * pxMatch_Wan_Conn, uint32 flags)
 	{

		if(pxMatch_Wan_Conn == NULL)
		{
		   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Passed object has NULL Pointer !!! \n");
		   return IFX_SUCCESS;
		}
		
		if(op == IFX_OP_ADD)
		{
		 	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Add operation \n");
		}else if(op == IFX_OP_DEL)
		{
		 	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Del operation \n");
				
		 }else if (op == IFX_OP_MOD)
	 	{
	 		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: Modify operation \n");
	 	}else 	
	 	{
	 	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: GET operation \n");
	 	}


		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_ENABLE=%d\n",flags);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_LINKTYPE=%d\n",pxMatch_Wan_Conn->type);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_VPI=%d\n",pxMatch_Wan_Conn->vc.pvc.vpi);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_VCI=%d\n",pxMatch_Wan_Conn->vc.pvc.vci);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_CONFIG_OWNER=%d\n",pxMatch_Wan_Conn->iid.config_owner);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_CPEID=%d\n",pxMatch_Wan_Conn->iid.cpeId.Id);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_PCPEID=%d\n",pxMatch_Wan_Conn->iid.pcpeId.Id);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_tr69id=%s\n",pxMatch_Wan_Conn->iid.tr69Id);
		
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_CONNTYPE=%d\n",pxMatch_Wan_Conn->wancfg.ppp.conn_type);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_CONN_NAME=%s\n",pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.conn_name);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_NATENABLE=%d\n",pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.NAT_enabled);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_TRANSPORTTYPE=%d\n",pxMatch_Wan_Conn->wancfg.ppp.transport_type);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_IPADDR=%s\n",inet_ntoa(pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.ip_mask.ip));
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_REMOTEIP=%s\n",inet_ntoa(pxMatch_Wan_Conn->wancfg.ppp.remote_addr));
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_DNSENABLE=%d\n",pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.DNS_enabled);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_ENABLE=%d\n",pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.f_enable);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_DNSOVERRIDE=%d\n",pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.DNS_override_allowed);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_ROUTEX=%d\n",pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.route_rx);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_WARNDISCONDELAY=%d\n",pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.warn_disconn_delay);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_AUTODISCONTIME=%d\n",pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.auto_disconn_time);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_IDLEDISCONTIME=%d\n",pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.idle_disconn_time);
		
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_MAXMRU=%d\n",pxMatch_Wan_Conn->wancfg.ppp.max_mru_size);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_CURRMRU=%d\n",pxMatch_Wan_Conn->wancfg.ppp.current_mru);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_MACADDR=%s\n",pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.mac_addr);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_CONNTRIG=%d\n",pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.trigger);

		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_COMPRPROTO=%d\n",pxMatch_Wan_Conn->wancfg.ppp.compr_proto);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_AUTHPROTO=%d\n",pxMatch_Wan_Conn->wancfg.ppp.auth_proto);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_ENCRYPPROTO=%d\n",pxMatch_Wan_Conn->wancfg.ppp.encr_proto);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_ACNAME=%s\n",pxMatch_Wan_Conn->wancfg.ppp.pppoe_ac_name);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_SERVICENAME=%s\n",pxMatch_Wan_Conn->wancfg.ppp.pppoe_service_name);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_USERNAME=%s\n",pxMatch_Wan_Conn->wancfg.ppp.ppp_user_name);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_PASSWD=%s\n",pxMatch_Wan_Conn->wancfg.ppp.ppp_user_passwd);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_LCPECHO=%d\n",pxMatch_Wan_Conn->wancfg.ppp.ppp_lcp_echo_period);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH,"MOD-API: WAN_PPP_LCPRETRY=%d\n",pxMatch_Wan_Conn->wancfg.ppp.ppp_lcp_echo_retry);

	return IFX_SUCCESS;
	}
#endif

static int32 
IFX_ConvertPPPArrToWanConCfgStruct(IN uint32 iElements, IN ParamVal *paxParamVal,
												OUT WAN_CONN_CFG* pxWan_Conn)
{
	uint32 i=0;
	int32 iRet=0;
	uint32 uiParamPos=0;
	
	uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);
	
	for (i=0; i < iElements; i++) 
	{

	      	switch(paxParamVal->iaOID[uiParamPos])
		{

				case OID_IGD_WAND_WANCD_WANPPPC_ENABLE:
					if(IFX_FwdMappingValues(gaxEnable,4,
							(void *)(paxParamVal->Value),
							(void *)&(pxWan_Conn->wancfg.ppp.wan_cfg.f_enable)) !=IFIN_CWMP_SUCCESS)
					{
						iRet=ERR_CWMP_INVAL_PARAM_VAL;
						goto errorHandler;
					}
					break;
/*	    		        case OID_IGD_WAND_WANCD_WANPPPC_VLANREF:
					strcpy(pxWan_Conn->wancfg.ppp.wan_cfg.vlan_ref, paxParamVal->Value);
					break;
*/
				case OID_IGD_WAND_WANCD_WANPPPC_RESET:
			                pxWan_Conn->wancfg.ppp.reset = atoi(paxParamVal->Value);
					break;

				//case OID_IGD_WAND_WANCD_WANPPPC_CONNECTIONSTATUS:
				//case OID_IGD_WAND_WANCD_WANPPPC_POSSIBLECONNECTIONTYPES:
				case OID_IGD_WAND_WANCD_WANPPPC_CONNECTIONTYPE:
					if(IFX_FwdMappingValues(saxWanPPPConType,7,
						(void *)(paxParamVal->Value),
						(void *)&(pxWan_Conn->wancfg.ppp.conn_type)) !=IFIN_CWMP_SUCCESS)
					{
						iRet=ERR_CWMP_INVAL_PARAM_VAL;
						goto errorHandler;
					}
					break;
				case OID_IGD_WAND_WANCD_WANPPPC_NAME:
					strncpy(pxWan_Conn->wancfg.ppp.wan_cfg.conf_conn_name,
							paxParamVal->Value,
							(MAX_CONN_NAME_LEN-1));
					break;
					
				//case OID_IGD_WAND_WANCD_WANPPPC_UPTIME:
				//case OID_IGD_WAND_WANCD_WANPPPC_LASTCONNECTIONERROR:
				case OID_IGD_WAND_WANCD_WANPPPC_AUTODISCONNECTTIME:
					pxWan_Conn->wancfg.ppp.wan_cfg.auto_disconn_time =
								atoi(paxParamVal->Value);
					break;
				case OID_IGD_WAND_WANCD_WANPPPC_IDLEDISCONNECTTIME:
					pxWan_Conn->wancfg.ppp.wan_cfg.idle_disconn_time=
								atoi(paxParamVal->Value);
					break;
				case OID_IGD_WAND_WANCD_WANPPPC_WARNDISCONNECTDELAY:
					/*pxWan_Conn->wancfg.ppp.wan_cfg.warn_disconn_delay=
								atoi(paxParamVal->Value);*/
					break;

				//case OID_IGD_WAND_WANCD_WANPPPC_RSIPAVAILABLE:
				case OID_IGD_WAND_WANCD_WANPPPC_NATENABLED:
					if(IFX_FwdMappingValues(gaxEnable,4,
						(void *)(paxParamVal->Value),
					(void *)&(pxWan_Conn->wancfg.ppp.wan_cfg.NAT_enabled)) !=IFIN_CWMP_SUCCESS)
					{
						iRet=ERR_CWMP_INVAL_PARAM_VAL;
						goto errorHandler;
					}
					break;

				case OID_IGD_WAND_WANCD_WANPPPC_USERNAME:
					strncpy(pxWan_Conn->wancfg.ppp.ppp_user_name,
							paxParamVal->Value,
							(MAX_PPP_USER_NAME_PASSWD_LEN-1));
					break;
					
				case OID_IGD_WAND_WANCD_WANPPPC_PASSWORD:
					strncpy(pxWan_Conn->wancfg.ppp.ppp_user_passwd,
							paxParamVal->Value,
							(MAX_PPP_USER_NAME_PASSWD_LEN-1));
					break;
				/*
				case OID_IGD_WAND_WANCD_WANPPPC_PPPENCRYPTIONPROTOCOL:
					if(IFX_FwdMappingValues(saxWanPPPEncrypProto,2,
						(void *)(paxParamVal->Value),
					(void *)&(pxWan_Conn->wancfg.ppp.encr_proto)) !=IFIN_CWMP_SUCCESS)
					{
						iRet=ERR_CWMP_INVAL_PARAM_VAL;
						goto errorHandler;
					}
					break;
				case OID_IGD_WAND_WANCD_WANPPPC_PPPCOMPRESSIONPROTOCOL:
					if(IFX_FwdMappingValues(saxWanPPPCompProto,2,
						(void *)(paxParamVal->Value),
					(void *)&(pxWan_Conn->wancfg.ppp.compr_proto)) !=IFIN_CWMP_SUCCESS)
					{
						iRet=ERR_CWMP_INVAL_PARAM_VAL;
						goto errorHandler;
					}
					break;
				case OID_IGD_WAND_WANCD_WANPPPC_PPPAUTHENTICATIONPROTOCOL:
					if(IFX_FwdMappingValues(saxWanPPPAuthProto,2,
						(void *)(paxParamVal->Value),
					(void *)&(pxWan_Conn->wancfg.ppp.auth_proto)) !=IFIN_CWMP_SUCCESS)
					{
						iRet=ERR_CWMP_INVAL_PARAM_VAL;
						goto errorHandler;
					}
					break;
				
				case OID_IGD_WAND_WANCD_WANPPPC_EXTERNALIPADDRESS:
					if((inet_aton(paxParamVal->Value,
						&(pxWan_Conn->wancfg.ip.wan_cfg.ip_mask.ip))) ==0)
					{
						iRet=ERR_CWMP_INVAL_PARAM_VAL;
						goto errorHandler;
					}
					break;

				case OID_IGD_WAND_WANCD_WANPPPC_REMOTEIPADDRESS:
					if((inet_aton(paxParamVal->Value,
						&(pxWan_Conn->wancfg.ppp.remote_addr))) ==0)
					{
						iRet=ERR_CWMP_INVAL_PARAM_VAL;
						goto errorHandler;
					}
					break;
				*/
				case OID_IGD_WAND_WANCD_WANPPPC_MAXMRUSIZE:
					pxWan_Conn->wancfg.ppp.max_mru_size=
								atoi(paxParamVal->Value);
					break;
				case OID_IGD_WAND_WANCD_WANPPPC_CURRENTMRUSIZE:
					pxWan_Conn->wancfg.ppp.current_mru=
								atoi(paxParamVal->Value);
					break;
					
				case OID_IGD_WAND_WANCD_WANPPPC_DNSENABLED:
					if(IFX_FwdMappingValues(gaxEnable,4,
						(void *)(paxParamVal->Value),
						(void *)&(pxWan_Conn->wancfg.ppp.wan_cfg.wandns.DNS_enabled)) !=IFIN_CWMP_SUCCESS)
					{
						iRet=ERR_CWMP_INVAL_PARAM_VAL;
						goto errorHandler;
					}
					break;
				case OID_IGD_WAND_WANCD_WANPPPC_DNSOVERRIDEALLOWED:
					if(IFX_FwdMappingValues(gaxEnable,4,(void *)(paxParamVal->Value),
						(void *)&(pxWan_Conn->wancfg.ppp.wan_cfg.wandns.DNS_override_allowed)) !=IFIN_CWMP_SUCCESS)
					{
						iRet=ERR_CWMP_INVAL_PARAM_VAL;
						goto errorHandler;
					}
					break;
				case OID_IGD_WAND_WANCD_WANPPPC_DNSSERVERS:
					iRet = IFX_ConvertDNSServersStringToArr(pxWan_Conn->wancfg.ppp.wan_cfg.wandns.dns_servers,
												paxParamVal->Value);				
					if(iRet != IFX_CWMP_SUCCESS)
						goto errorHandler;
									
				case OID_IGD_WAND_WANCD_WANPPPC_MACADDRESS:
					strncpy(pxWan_Conn->wancfg.ppp.wan_cfg.mac_addr,
							paxParamVal->Value,
							(MAX_MAC_ADDRESS_LEN-1));
					break;

				case OID_IGD_WAND_WANCD_WANPPPC_MACADDRESSOVERRIDE:
					if(IFX_FwdMappingValues(gaxEnable,4,(void *)(paxParamVal->Value),
					(void *)&(pxWan_Conn->wancfg.ppp.wan_cfg.mac_addr_override)) !=IFIN_CWMP_SUCCESS)
					{
						iRet=ERR_CWMP_INVAL_PARAM_VAL;
						goto errorHandler;
					}
					break;
					
				/*
				case OID_IGD_WAND_WANCD_WANPPPC_TRANSPORTTYPE:
					if(IFX_FwdMappingValues(saxWanPPPTransportType,4,
						(void *)(paxParamVal->Value),
					(void *)&(pxWan_Conn->wancfg.ppp.transport_type)) !=IFIN_CWMP_SUCCESS)
					{
						iRet=ERR_CWMP_INVAL_PARAM_VAL;
						goto errorHandler;
					}
					break;
				*/
				case OID_IGD_WAND_WANCD_WANPPPC_PPPOEACNAME:
					strncpy(pxWan_Conn->wancfg.ppp.pppoe_ac_name,
							paxParamVal->Value,
							(MAX_CONN_NAME_LEN-1));
					break;
				case OID_IGD_WAND_WANCD_WANPPPC_PPPOESERVICENAME:
					strncpy(pxWan_Conn->wancfg.ppp.pppoe_service_name,
							paxParamVal->Value,
							(MAX_CONN_NAME_LEN-1));
					break;

				case OID_IGD_WAND_WANCD_WANPPPC_CONNECTIONTRIGGER:
					if(IFX_FwdMappingValues(saxWanIpConTrigger,3,(void *)(paxParamVal->Value),
					(void *)&(pxWan_Conn->wancfg.ppp.trigger)) !=IFIN_CWMP_SUCCESS)
					{
						iRet=ERR_CWMP_INVAL_PARAM_VAL;
						goto errorHandler;
					}
					break;
				case OID_IGD_WAND_WANCD_WANPPPC_ROUTEPROTOCOLRX:
					if(IFX_FwdMappingValues(saxWanIpRouteProto,4,(void *)(paxParamVal->Value),
					(void *)&(pxWan_Conn->wancfg.ppp.wan_cfg.route_rx)) !=IFIN_CWMP_SUCCESS)
					{
						iRet=ERR_CWMP_INVAL_PARAM_VAL;
						goto errorHandler;
					}
					break;
					
				//case OID_IGD_WAND_WANCD_WANPPPC_PPPLCPECHO:
					
				//case OID_IGD_WAND_WANCD_WANPPPC_PPPLCPECHORETRY:
					
				//case OID_IGD_WAND_WANCD_WANPPPC_PORTMAPPINGNUMBEROFENTRIES:
					
									
									
				default:
					break;

		}


		++paxParamVal;
		
	}

	return IFIN_CWMP_SUCCESS;
	
	errorHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed ParamId =%d Value =%s!\n", __func__, __LINE__,
					  paxParamVal->iaOID[uiParamPos], (char8 *)paxParamVal->Value);
		return iRet;
		
}



/* 
** =============================================================================
**   Function Name    : IFX_WanPPPConGetValue
**   Description        : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes                : 
**
** ============================================================================
*/
static int32 
IFX_WanPPPConGetValue(IN OperInfo *pxOperInfo,INOUT ParamVal *pxGetParamVal,
								IN uint32 iElements)
{
	/*GET PARAMETER VALUES
	**Get Object OID(skip parameter ID) from the first 
	**element in the array.Get Cpeid for this Object OID

	**Get the object from the system using a Platform API
	**with cpeid 
	
	**Do reverse mapping to convert system values into TR69
	**Values.After conversion stores the values in temp storage

	**While assigning the values as per request store the 
	**values in heap and assign the ptr to the struct
	**Return all the values 
	*/

#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
	uint32 iFlags=0;
#endif
	uint32 iCpeid=0,i=0;
	int32 iParamId=0;
	uint32 uiParamPos=0;
	int32 iRet=IFX_CWMP_SUCCESS;
	uint32 uiNoEntries=0;
	uint32 uiMode=IFX_CHK_VALUE_BASED;
	WAN_CONN_CFG xMatch_Wan_Conn;
	memset(&xMatch_Wan_Conn,0x00,sizeof(xMatch_Wan_Conn));
	WAN_CONN_CFG *pxMatch_Wan_Conn=&xMatch_Wan_Conn;
        void *pvTmpBigVal=NULL;
        IFX_Id	VlanId;
        int32 iaVLANRefOID[OID_LENGTH] = {0};
        char8 tr69_str[IFX_MAX_TR69_ID_LEN] = {0};
        char * pcTmp = NULL;
	
	memset(&VlanId,0x00,sizeof(VlanId));	

	// Get Cpeid from object ID
	iRet = IFX_GetCpeId(pxGetParamVal->iaOID,&iCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	pxMatch_Wan_Conn->type = WAN_TYPE_PPP;
	// Get match object from system using Platform API
	iRet= IFX_GetWanObj(pxMatch_Wan_Conn, iCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	//Get the WanIpConParamPos 
	uiParamPos = IFX_GetParamIdPos(pxGetParamVal->iaOID);

	for(i=0;i < iElements; i++)
	{
	
		iParamId = pxGetParamVal->iaOID[uiParamPos];
	
		// Malloc and assign the pointer to the Value attr of struct 
		pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
		if(pxGetParamVal->Value == NULL)
		{
			iRet = ERR_OUT_OF_MEMORY; 
			goto errorHandler;
		}
		switch(iParamId)
		{

			// Convert the value - reverse mapping
			// Assign the correct value to the Value attr	
	    		case OID_IGD_WAND_WANCD_WANPPPC_ENABLE:
				if(IFX_RevMappingValues(gaxEnable,4,
							(void *)&(pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.f_enable),
							(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
					
					goto errorHandler;
				break;

	    		case OID_IGD_WAND_WANCD_WANPPPC_RESET:
                               strcpy(pxGetParamVal->Value, "0"); 
                               break;

	    		case OID_IGD_WAND_WANCD_WANPPPC_X_AC9A96_VLANREF:
				//Realloc to higher size
				pvTmpBigVal  = IFX_CWMP_REALLOC(pxGetParamVal->Value, MAX_CONN_NAME_LEN);
				if(pvTmpBigVal != NULL)
				      pxGetParamVal->Value = pvTmpBigVal;
                                /*pCpeId of ppp connection is cpe id of Vlan Object. Get the Tr69Id of
                                  vlan object in dotted form. Convert it to integer array.
                                  Then convert it to a user-readable format of 
                                  IGD.WD.X.WCD.X.DSL/PTMLC.X-LTQ-VLAN.X.*/
                                VlanId.xCpeId.uiId = pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.iid.pcpeId.Id;
                                strcpy(VlanId.xCpeId.sSectionTag, "vlan_ch_cfg");
                                iRet = IFX_GetTr69IdFromCpeId(&VlanId);
	                        if(iRet != IFX_CWMP_SUCCESS)
				{
				        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d]\n", _FUNCL_);
					goto errorHandler;
				}

                                iRet = IFX_AscToIntOID(VlanId.sTr69Id, iaVLANRefOID);
	                        if(iRet != IFX_CWMP_SUCCESS)
				{
				        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d]\n", _FUNCL_);
					goto errorHandler;
				}

                                iRet = IFX_GlobalNameOidConversion(tr69_str, iaVLANRefOID);
                	        if(iRet != IFX_CWMP_SUCCESS)
                                {
        			    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
        					"[%s:%d] [Error] IFX_GlobalNameOidConversion failed\n",
        					__func__, __LINE__);
        	                    goto errorHandler;
        	                }

				strcpy(pxGetParamVal->Value, tr69_str);
				break;
					
	    		case OID_IGD_WAND_WANCD_WANPPPC_CONNECTIONSTATUS://RO
				
				if(IFX_RevMappingValues(saxWanPPPConStatus,7,
							(void *)&(pxMatch_Wan_Conn->wancfg.ppp.conn_status),
							(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;	 

			case OID_IGD_WAND_WANCD_WANPPPC_POSSIBLECONNECTIONTYPES://RO
				strcpy(pxGetParamVal->Value,susWanPPPPossibleConTypes);
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
								
			case OID_IGD_WAND_WANCD_WANPPPC_CONNECTIONTYPE:			
				if(IFX_RevMappingValues(saxWanPPPConType,7,
						(void *)&(pxMatch_Wan_Conn->wancfg.ppp.conn_type),
						(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
					goto errorHandler;
				break;
                        case OID_IGD_WAND_WANCD_WANPPPC_PPPOESESSIONID:
                            sprintf(pxGetParamVal->Value, "%u",
                            pxMatch_Wan_Conn->wancfg.ppp.sessionid);
                            break;

                        case OID_IGD_WAND_WANCD_WANPPPC_DEFAULTGATEWAY:
                            strncpy((char8 *) pxGetParamVal->Value,
                            inet_ntoa(pxMatch_Wan_Conn->wancfg.ppp.defaultgw),
                            (MAX_IP_ADDRRESS_LEN - 1));
                            break;

			case OID_IGD_WAND_WANCD_WANPPPC_NAME:
				//Realloc to higher size
				pvTmpBigVal = IFX_CWMP_REALLOC(pxGetParamVal->Value, MAX_CONN_NAME_LEN);
			        if(pvTmpBigVal != NULL)
                                       pxGetParamVal->Value = pvTmpBigVal;	
				strncpy(pxGetParamVal->Value,
						pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.conf_conn_name,
						(MAX_CONN_NAME_LEN-1));
				break;
				
			case OID_IGD_WAND_WANCD_WANPPPC_UPTIME: //RO
				sprintf(pxGetParamVal->Value,"%u",
					pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.uptime);
                                if (pxOperInfo->iCaller == ACC_TR64)
                                {
                                    pcTmp = strstr(pxGetParamVal->Name, "Uptime");
                                    if(pcTmp != NULL)
                                    {
                                        strcpy(pcTmp,"UpTime");
                                    }
                                }
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			case OID_IGD_WAND_WANCD_WANPPPC_LASTCONNECTIONERROR: //RO
				if(IFX_RevMappingValues(saxWanPPPLastConError,23,
							(void *)&(pxMatch_Wan_Conn->wancfg.ppp.last_conn_error),
							(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
					goto errorHandler;
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
			
			case OID_IGD_WAND_WANCD_WANPPPC_AUTODISCONNECTTIME:
				sprintf(pxGetParamVal->Value,"%d",
					pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.auto_disconn_time);
				break;

			case OID_IGD_WAND_WANCD_WANPPPC_IDLEDISCONNECTTIME:
				sprintf(pxGetParamVal->Value,"%d",
					pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.idle_disconn_time);
				break;

			case OID_IGD_WAND_WANCD_WANPPPC_WARNDISCONNECTDELAY:
				strcpy(pxGetParamVal->Value,"0");
				break;

			case OID_IGD_WAND_WANCD_WANPPPC_RSIPAVAILABLE: //RO
				strcpy(pxGetParamVal->Value,"0");
				break;
				/*if(IFX_RevMappingValues(gaxEnable,4,
						(void *)&(pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.RSIP_avail),
						(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
					goto errorHandler;*/
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
				
			case OID_IGD_WAND_WANCD_WANPPPC_NATENABLED:
				if(IFX_RevMappingValues(gaxEnable,4,
						(void *)&(pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.NAT_enabled),
						(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
					goto errorHandler;
				break;
				
			case OID_IGD_WAND_WANCD_WANPPPC_USERNAME:
				strncpy(pxGetParamVal->Value,
						pxMatch_Wan_Conn->wancfg.ppp.ppp_user_name,
						(MAX_PPP_USER_NAME_PASSWD_LEN-1));
                                if (pxOperInfo->iCaller == ACC_TR64)
                                {
                                    pcTmp = strstr(pxGetParamVal->Name, "Username");
                                    if(pcTmp != NULL)
                                    {
                                        strcpy(pcTmp,"UserName");
                                    }
                                }
				break;
					
			case OID_IGD_WAND_WANCD_WANPPPC_PASSWORD:
				strncpy(pxGetParamVal->Value, " ", (MAX_PPP_USER_NAME_PASSWD_LEN-1));
				break;
					
		       case OID_IGD_WAND_WANCD_WANPPPC_PPPENCRYPTIONPROTOCOL:
				if(IFX_RevMappingValues(saxWanPPPEncrypProto,2,
					(void *)&(pxMatch_Wan_Conn->wancfg.ppp.encr_proto),
					(void *)(pxGetParamVal->Value)) !=IFIN_CWMP_SUCCESS)
				{
					iRet=ERR_CWMP_INVAL_PARAM_VAL;
					goto errorHandler;
				}
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			case OID_IGD_WAND_WANCD_WANPPPC_PPPCOMPRESSIONPROTOCOL:
				if(IFX_RevMappingValues(saxWanPPPCompProto,3,
					(void *)&(pxMatch_Wan_Conn->wancfg.ppp.compr_proto),
					(void *)(pxGetParamVal->Value)) !=IFIN_CWMP_SUCCESS)
				{
					iRet=ERR_CWMP_INVAL_PARAM_VAL;
					goto errorHandler;
				}
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			case OID_IGD_WAND_WANCD_WANPPPC_PPPAUTHENTICATIONPROTOCOL:
				if(IFX_RevMappingValues(saxWanPPPAuthProto,3,
					(void *)&(pxMatch_Wan_Conn->wancfg.ppp.auth_proto),
					(void *)(pxGetParamVal->Value)) !=IFIN_CWMP_SUCCESS)
				{
					iRet=ERR_CWMP_INVAL_PARAM_VAL;
					goto errorHandler;
				}
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
			
			case OID_IGD_WAND_WANCD_WANPPPC_EXTERNALIPADDRESS:
				strncpy((char8 *)pxGetParamVal->Value,
						inet_ntoa(pxMatch_Wan_Conn->wanv4.ip_mask.ip), (MAX_IP_ADDRRESS_LEN-1));
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;

			case OID_IGD_WAND_WANCD_WANPPPC_REMOTEIPADDRESS:
				strncpy((char8 *)pxGetParamVal->Value,
						inet_ntoa(pxMatch_Wan_Conn->wancfg.ppp.remote_addr),
						(MAX_IP_ADDRRESS_LEN-1));
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
							
			case OID_IGD_WAND_WANCD_WANPPPC_MAXMRUSIZE:
				sprintf(pxGetParamVal->Value,"%d", pxMatch_Wan_Conn->wancfg.ppp.max_mru_size);
				break;

			case OID_IGD_WAND_WANCD_WANPPPC_CURRENTMRUSIZE:
				sprintf(pxGetParamVal->Value,"%d", pxMatch_Wan_Conn->wancfg.ppp.current_mru);
				break;
			
			case OID_IGD_WAND_WANCD_WANPPPC_DNSENABLED:
				if(IFX_RevMappingValues(gaxEnable,4,
						(void *)&(pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.wandns.DNS_enabled),
						(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
					goto errorHandler;			
				break;

			case OID_IGD_WAND_WANCD_WANPPPC_DNSOVERRIDEALLOWED:
				if(IFX_RevMappingValues(gaxEnable,4,
						(void *)&(pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.wandns.DNS_override_allowed),
						(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
					goto errorHandler;
				break;

			case OID_IGD_WAND_WANCD_WANPPPC_DNSSERVERS:
			        pvTmpBigVal = IFX_CWMP_REALLOC(pxGetParamVal->Value, MAX_CONN_NAME_LEN);
			        if(pvTmpBigVal != NULL)
                                        pxGetParamVal->Value = pvTmpBigVal;
			        iRet = IFX_ConvertDNSServersArrToString(pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.wandns.dns_servers,
									pxGetParamVal->Value,MAX_DNS_SERVERS);
				if(iRet != IFX_CWMP_SUCCESS)
					goto errorHandler;
				break;

			case OID_IGD_WAND_WANCD_WANPPPC_MACADDRESS:
				strncpy(pxGetParamVal->Value,
					pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.mac_addr,
					(MAX_MAC_ADDRESS_LEN-1));
				if(!strcmp(pxGetParamVal->Value,""))
					sprintf(pxGetParamVal->Value, "00:00:00:00:00:00");

                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                                            "%s:%d Module mac addr =%s\n", __func__,__LINE__,
                                            pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.mac_addr);
				break;

			case OID_IGD_WAND_WANCD_WANPPPC_MACADDRESSOVERRIDE:
				if(IFX_RevMappingValues(gaxEnable,4,
						(void *)&(pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.mac_addr_override),
						(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
					goto errorHandler;
				break;

			case OID_IGD_WAND_WANCD_WANPPPC_TRANSPORTTYPE:
                                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                                            "%s:%d transport_type =%d\n", __func__,__LINE__,
                                            pxMatch_Wan_Conn->wancfg.ppp.transport_type);
				if(IFX_RevMappingValues(saxWanPPPTransportType,2,
					(void *)&(pxMatch_Wan_Conn->wancfg.ppp.transport_type),
					(void *)(pxGetParamVal->Value)) !=IFIN_CWMP_SUCCESS)
				{
                                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                                            "%s:%d transport_type =%d\n", __func__,__LINE__,
                                            pxMatch_Wan_Conn->wancfg.ppp.transport_type);
					iRet=ERR_CWMP_INVAL_PARAM_VAL;
					goto errorHandler;
				}
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
			
			case OID_IGD_WAND_WANCD_WANPPPC_PPPOEACNAME:
				pvTmpBigVal = IFX_CWMP_REALLOC(pxGetParamVal->Value, MAX_CONN_NAME_LEN);
				if(pvTmpBigVal != NULL)
                                         pxGetParamVal->Value = pvTmpBigVal;
				strncpy(pxGetParamVal->Value,
					pxMatch_Wan_Conn->wancfg.ppp.pppoe_ac_name,
						(MAX_CONN_NAME_LEN-1));
				break;

			case OID_IGD_WAND_WANCD_WANPPPC_PPPOESERVICENAME:
				pvTmpBigVal = IFX_CWMP_REALLOC(pxGetParamVal->Value, MAX_CONN_NAME_LEN);
				if(pvTmpBigVal != NULL)
                                         pxGetParamVal->Value = pvTmpBigVal;
				strncpy(pxGetParamVal->Value,
					pxMatch_Wan_Conn->wancfg.ppp.pppoe_service_name,
					(MAX_CONN_NAME_LEN-1));
				break;
					
			case OID_IGD_WAND_WANCD_WANPPPC_CONNECTIONTRIGGER:
				if(IFX_RevMappingValues(saxWanIpConTrigger,3,
						(void *)&(pxMatch_Wan_Conn->wancfg.ppp.trigger),
						(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS)
					goto errorHandler;
				break;

			case OID_IGD_WAND_WANCD_WANPPPC_ROUTEPROTOCOLRX:
				if(IFX_RevMappingValues(saxWanIpRouteProto,4,
						(void *)&(pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.route_rx),
						(void *)(pxGetParamVal->Value))!=IFX_CWMP_SUCCESS) {
                                    strcpy(pxGetParamVal->Value, "Off");
                                }
				break;
				
			case OID_IGD_WAND_WANCD_WANPPPC_PPPLCPECHO:
				sprintf(pxGetParamVal->Value,"%d",
					pxMatch_Wan_Conn->wancfg.ppp.ppp_lcp_echo_period);
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;	
				
			case OID_IGD_WAND_WANCD_WANPPPC_PPPLCPECHORETRY:
				sprintf(pxGetParamVal->Value,"%d",
					pxMatch_Wan_Conn->wancfg.ppp.ppp_lcp_echo_retry);
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
				
			case OID_IGD_WAND_WANCD_WANPPPC_PORTMAPPINGNUMBEROFENTRIES://RO
				if((iRet =IFX_GetWanIpNoPortMapObjs(pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.conn_name,
						&uiNoEntries)) != IFX_CWMP_SUCCESS)
					goto errorHandler;		
				sprintf(pxGetParamVal->Value,"%d",uiNoEntries);
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal, IFX_CHK_CHANGE_FLAG_BASED);
				break;
				
			default:
			        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                             "Invalid param id %d!\n", iParamId);
			        pxGetParamVal->iFaultCode=ERR_INVAL_PARAMETER_VAL;
			        break;
		}
		++pxGetParamVal;
	}
	
	return IFX_CWMP_SUCCESS;
		
errorHandler:
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
	ifx_set_wan_atm_vcc_ppp_config_stub(pxOperInfo->iOper, pxMatch_Wan_Conn, iFlags);
#endif
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d failed"
                                    "ParamId =%d \n", __func__,__LINE__, iParamId);

	return IFIN_CWMP_FAILURE;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanPPPConSetValidate
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanPPPConSetValidate(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
							IN int32 iElements)
{
	/*                                                                      
	** Instance check,Data_Type(1- RO,RW check,2- Int,char,etc
	** 3- String length) check and range_Check(Min,Max) will 
	** be handled by the controller.
	*/

	// Dependency check between parameters and objects should 
	// be handled by this API.This can't be done unless
	// enable is issued by the ACS.

	//Get Cpeid
	//Get the obj from system
	//If it is enabled if we try to modify following parameters return error
	//If it is disabled call IFX_MappingValues functions to check if correct values 
	//are passed.
	
	int32 iRet=IFX_CWMP_SUCCESS;
	uint32 uiCpeid=0;
	WAN_CONN_CFG xMatch_Wan_Conn;

	memset(&xMatch_Wan_Conn,0x00,sizeof(xMatch_Wan_Conn));	
	WAN_CONN_CFG *pxMatch_Wan_Conn=&xMatch_Wan_Conn;
	
	//Get the Cpeid from Tr69 id
	iRet = IFX_GetCpeId(paxParamVal->iaOID,&uiCpeid);
	if(iRet != IFIN_CWMP_SUCCESS)
		goto errorHandler;
		
	pxMatch_Wan_Conn->type = WAN_TYPE_PPP;
	//Get the object from system
	iRet= IFX_GetWanObj(pxMatch_Wan_Conn, uiCpeid);
	if(iRet != IFIN_CWMP_SUCCESS)
		goto errorHandler;

	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"%s:%d - Set Validate success!\n", __func__, __LINE__);
	return IFIN_CWMP_SUCCESS;

errorHandler:
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
       		 "%s:%d failed!\n", __func__, __LINE__);
	return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanPPPConAddObj
**   Description      : This API calls a Platform API which adds the object in ADD_DISABLE state.
**                      Pass necessary flags to the API Controller should get the next instance id from DS 
**                      module and pass the full OID to this module.
**                      If Cisco proposal comes, this API should handle  
**                      a) Validation of values
**                      b) Forward mapping of TR69 values to system values 
**                      c) addition of object into the system
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanPPPConAddObj(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{
    uint32 iFlags=0;
    int32 iRet=0;
    uint32 iOper;
    uint32 uiPcpeId=0;
    WAN_CONN_CFG xWan_Conn;
    int32 LinkCfgOID[OID_LENGTH];
    uint32 cpeid = 0;
    int32 i = 0;
#ifdef IFX_TR69_ADSLWAN
    int32 iaWanDslLinkEnable[OID_LENGTH]={0,0,0,0,0,OID_IGD_WAND_WANCD_WANDSLLC,
		OID_IGD_WAND_WANCD_WANDSLLC_ENABLE};
    ATM_VCC_INFO xAtm_Vcc_Cfg;
    memset(&xAtm_Vcc_Cfg, 0, sizeof(xAtm_Vcc_Cfg));
#endif

#ifdef IFX_TR69_PTMWAN
    int32 iaWanPtmLinkEnable[OID_LENGTH]={0,0,0,0,0,OID_IGD_WAND_WANCD_WANPTMLC,
    		OID_IGD_WAND_WANCD_WANPTMLC_ENABLE};
    PTM_CH_CFG xPtmChCfg;
    memset(&xPtmChCfg, 0, sizeof(xPtmChCfg));
    WAN_PHY_CFG xWanPhy = {0};
    int32 wan_mode = 0;
#endif
#ifdef IFX_TR69_ETHERNETWAN
    int32 iaWanEthLinkEnable[OID_LENGTH]={0,0,0,0,0,OID_IGD_WAND_WANCD_WANELC,
		OID_IGD_WAND_WANCD_WANELC_X_AC9A96_ENABLE};
    ETH_CH_CFG xEthChCfg;
    memset(&xEthChCfg, 0, sizeof(xEthChCfg));
#endif
    int32 num_vlanchannels = 0;
    vlan_ch_cfg_t * xVlanArr = NULL;
    IFX_ID ParentIID;
    vlan_ch_cfg_t vlan_entry;

    memset(&xWan_Conn, 0, sizeof(xWan_Conn));
    memset(&vlan_entry, 0, sizeof(vlan_entry));

    /*This check should not be present for multiwan support. Need to check if macro protection is required*/
#if 0
	// Adding new WanIPConnection/WanPPPConnection is not allowed
	iRet = IFX_CheckIfWanConnPresent(pxParamVal->iaOID);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
#endif
    if(pxParamVal[0].iaOID[2] == WAN_DEVICE_ATM)
    {
        /*If WCD.1. then add on PTMLC
        else adding on DSLLC*/
        if(pxParamVal[0].iaOID[4] == 1)
        {
            #ifndef IFX_TR69_PTMWAN
            /*return error*/
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"Cannot add connection on Channel reserved for PTM\n");
            iRet = IFIN_CWMP_FAILURE;
            goto errorHandler;
            #endif
            #ifdef IFX_TR69_PTMWAN
            /*memset the structs. Get PTM channel entry */
            memset(&LinkCfgOID,0x00,(sizeof(int32) * OID_LENGTH));
            memcpy(LinkCfgOID,iaWanPtmLinkEnable, (OID_LENGTH*sizeof(int32)));
            memcpy(LinkCfgOID,pxParamVal->iaOID,((WAN_CON_DEV_DEPTH+1)*sizeof(int32)));
            cpeid = 0;
            //Get the Cpeid from Tr69 id
            iRet = IFX_GetCpeId(LinkCfgOID, &cpeid);
            if(iRet != IFX_CWMP_SUCCESS)
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Get Cpe ID Failed!\n", __func__, __LINE__);
                goto errorHandler;
            }

            xPtmChCfg.iid.cpeId.Id = cpeid;
            iRet = ifx_get_ptm_ch_cfg(&xPtmChCfg, IFX_F_DEFAULT);
            if(iRet != IFX_CWMP_SUCCESS)
            {
                goto errorHandler;
            }

            /*set xPtmChCfg.cpeId as cpe id. section name as ptmChannel.
              Get all vlan entries under that.
              look for vlan id = 0. Set that cpe id as parent cpeid */
            ParentIID.cpeId.Id = xPtmChCfg.iid.cpeId.Id;
            strcpy(ParentIID.cpeId.secName, "ptm_channel");
            iRet = mapi_get_all_vlan_ch_entries_for_l2ch(&num_vlanchannels, &xVlanArr, &ParentIID, IFX_F_GET_ANY);
            if(iRet != IFX_SUCCESS)
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    " mapi_get_all_vlan_ch_entries_for_l2ch - Mgmt API returned error\n");
                goto errorHandler;
            }
            if(num_vlanchannels == 0)
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"No Vlan channels\n");
                goto errorHandler;
            }
            for (i=0; i<num_vlanchannels; i++)
            {
               vlan_entry = xVlanArr[i];
               if(vlan_entry.vlanId == -1)
               {
                   uiPcpeId = vlan_entry.iid.cpeId.Id;
                   strcpy(xWan_Conn.wancfg.ppp.wan_cfg.l2iface_name, vlan_entry.l2ifName);
                   break;
               }
            }  
            IFX_MEM_FREE(xVlanArr);
            #endif
        }
        else
        {
            #ifndef IFX_TR69_ADSLWAN
            /*return error*/
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"Cannot add connection on Channel meant for ATM\n");
            iRet = IFIN_CWMP_FAILURE;
            goto errorHandler;
            #endif
            #ifdef IFX_TR69_ADSLWAN
            /*memset the structs. Get DSL Link Cfg entry*/
    	    memset(&LinkCfgOID,0x00,(sizeof(int32) * OID_LENGTH));
    	    memcpy(LinkCfgOID, iaWanDslLinkEnable, (OID_LENGTH*sizeof(int32)));
            memcpy(LinkCfgOID, pxParamVal->iaOID, ((WAN_CON_DEV_DEPTH+1)*sizeof(int32)));

            //Get the Cpeid from Tr69 id
            iRet = IFX_GetCpeId(LinkCfgOID, &cpeid);
            if(iRet != IFX_CWMP_SUCCESS)
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Get Cpe ID Failed!\n", __func__, __LINE__);
                goto errorHandler;
            }
    
            xAtm_Vcc_Cfg.iid.cpeId.Id = cpeid;
            //Get the object from system
            iRet= IFX_GetVccObj(&xAtm_Vcc_Cfg, cpeid);
            if(iRet != IFX_CWMP_SUCCESS)
            {
                 goto errorHandler;
            }
            /*set xAtmVccCh.cpeId as cpe id. section name as VCChannel.
              Get all vlan entries under that.
              look for vlan id = 0. Set that cpe id as parent cpeid */
                 
            ParentIID.cpeId.Id = xAtm_Vcc_Cfg.iid.cpeId.Id;
            strcpy(ParentIID.cpeId.secName, "adsl_vcchannel");
            iRet = mapi_get_all_vlan_ch_entries_for_l2ch(&num_vlanchannels, &xVlanArr, &ParentIID, IFX_F_GET_ANY);
            if(iRet != IFX_SUCCESS)
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                     " mapi_get_all_vlan_ch_entries_for_l2ch - Mgmt API returned error\n");
                goto errorHandler;
            }
            if(num_vlanchannels == 0)
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"No Vlan channels\n");
                goto errorHandler;
            }
            for (i=0; i<num_vlanchannels; i++)
            {
                   vlan_entry = xVlanArr[i];
                   if(vlan_entry.vlanId == -1)
                   {
                       uiPcpeId = vlan_entry.iid.cpeId.Id;
                       strcpy(xWan_Conn.wancfg.ppp.wan_cfg.l2iface_name, vlan_entry.l2ifName);
                       break;
                   }
            } 
            IFX_MEM_FREE(xVlanArr);
            if( (xAtm_Vcc_Cfg.type != LINK_TYPE_EOATM) && (xAtm_Vcc_Cfg.type != LINK_TYPE_PPPOATM) )
            {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Channel LinkType=[%d] Set correct LinkType before adding PPP Connection !\n", __func__, __LINE__, xAtm_Vcc_Cfg.type);
   	         goto errorHandler;
            }
            #endif
        }
    }
    else
    {
#ifdef IFX_TR69_ETHERNETWAN
		//memset the structs. Get Eth channel
		memset(&LinkCfgOID,0x00,(sizeof(int32) * OID_LENGTH));
		memcpy(LinkCfgOID,iaWanEthLinkEnable, (OID_LENGTH*sizeof(int32)));
		memcpy(LinkCfgOID,pxParamVal->iaOID,((WAN_CON_DEV_DEPTH+1)*sizeof(int32)));
        	cpeid = 0;
	        //Get the Cpeid from Tr69 id
        	iRet = IFX_GetCpeId(LinkCfgOID, &cpeid);
	        if(iRet != IFX_CWMP_SUCCESS)
        	{
	            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Get Cpe ID Failed!\n", __func__, __LINE__);
        	    goto errorHandler;
	        }

        	xEthChCfg.iid.cpeId.Id = cpeid;
	        iRet = ifx_get_eth_ch_cfg(&xEthChCfg, IFX_F_DEFAULT);
        	if(iRet != IFX_CWMP_SUCCESS)
	            goto errorHandler;

                /*set xAtmVccCh.cpeId as cpe id. section name as VCChannel.
                Get all vlan entries under that.
                look for vlan id = 0. Set that cpe id as parent cpeid */
         
                ParentIID.cpeId.Id = cpeid;
                strcpy(ParentIID.cpeId.secName, "eth_channel");
                iRet = mapi_get_all_vlan_ch_entries_for_l2ch(&num_vlanchannels, &xVlanArr, &ParentIID, IFX_F_GET_ANY);
                if(iRet != IFX_SUCCESS)
                {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        " mapi_get_all_vlan_ch_entries_for_l2ch - Mgmt API returned error\n");
                    goto errorHandler;
                }
                if(num_vlanchannels == 0)
                {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"No Vlan channels\n");
                    goto errorHandler;
                }
                for (i=0; i<num_vlanchannels; i++)
                {
                   vlan_entry = xVlanArr[i];
                   if(vlan_entry.vlanId == -1)
                   {
                       uiPcpeId = vlan_entry.iid.cpeId.Id;
	               strcpy(xWan_Conn.wancfg.ppp.wan_cfg.l2iface_name, vlan_entry.l2ifName);
                       break;
                   }
                }
                IFX_MEM_FREE(xVlanArr);
#endif //IFX_TR69_ETHERNETWAN
    }
    //Flags should be filled
    //Fill the Cpeid,ParentCepid,TR69Id,Owner
    //Fill the operation

    iOper = IFX_OP_ADD;
    iFlags =(	IFX_F_DONT_ACTIVATE|IFX_F_DONT_CHECKPOINT|
    		IFX_F_DONT_VALIDATE|IFX_F_DONT_WRITE_TO_FLASH);

    iRet = IFX_ConvertPPPArrToWanConCfgStruct(iElements, pxParamVal, &xWan_Conn);
    if(iRet != IFX_CWMP_SUCCESS)
    	goto errorHandler;

    xWan_Conn.wancfg.ppp.wan_cfg.iid.pcpeId.Id = uiPcpeId;
    xWan_Conn.wancfg.ppp.wan_cfg.iid.cpeId.Id = 0;
    xWan_Conn.wancfg.ppp.wan_cfg.iid.config_owner = pxOpInfo->iCaller;
    xWan_Conn.wancfg.ppp.wan_cfg.f_enable = IFX_DISABLED;
    xWan_Conn.wancfg.ppp.wan_cfg.max_mtu = 1492;
    xWan_Conn.wancfg.ppp.wan_cfg.wandns.DNS_override_allowed = TRUE;
    strcpy(xWan_Conn.wancfg.ppp.ppp_user_name, "pppUser");
    strcpy(xWan_Conn.wancfg.ppp.ppp_user_passwd, "pppPass");
    //Convert array into dotted form and then strcpy
    iRet = IFX_ConvertOidDottedForm(pxParamVal->iaOID, xWan_Conn.wancfg.ppp.wan_cfg.iid.tr69Id);
    if(iRet != IFX_CWMP_SUCCESS)
    	goto errorHandler;

    //Initialize the RO params with Default Values
    xWan_Conn.wancfg.ppp.encr_proto=WAN_PPP_ENCR_PROTO_NONE;
    xWan_Conn.wancfg.ppp.compr_proto=WAN_PPP_COMPR_PROTO_NONE;
    xWan_Conn.wancfg.ppp.auth_proto=WAN_PPP_AUTH_PROTO_PAP;
    xWan_Conn.wancfg.ppp.transport_type=WAN_PPP_TRANSPORT_TYPE_PPPOE;
    xWan_Conn.type= WAN_TYPE_PPP;
	
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
    ifx_set_wan_atm_vcc_ppp_config_stub(iOper, &xWan_Conn, iFlags);
#else
    switch(pxParamVal[0].iaOID[2])
    {
        case WAN_DEVICE_ATM:
        {
            /*...WANDevice.1.*/
            /*If WCD.1. then add on PTMLC
            else adding on DSLLC*/
            if(pxParamVal[0].iaOID[4] == 1)
            {
#ifdef IFX_TR69_PTMWAN
                    wan_mode = WAN_MODE_VDSL_PTM;
                    if((iRet = ifx_get_wan_phy_cfg(&xWanPhy)) == IFX_CWMP_SUCCESS)
                    {
                       if((iRet = compute_wan_mode(xWanPhy.phy_mode, xWanPhy.wan_tc)) != -1)
                       {
                           if((iRet == WAN_MODE_PTM) || (iRet == WAN_MODE_VDSL_PTM))
                           {
                               wan_mode = iRet;
                           }
                       }
                    }
                    iRet = IFX_CWMP_SUCCESS;
                    xWan_Conn.wancfg.ppp.wan_cfg.wan_mode.mode = wan_mode;
                    xWan_Conn.wancfg.ppp.wan_cfg.link_type = LINK_TYPE_PPPOE;
#endif
            }
            else
            {
#ifdef IFX_TR69_ADSLWAN
                /*Copy l2ifname from the ATM/PTM object.*/
                xWan_Conn.wancfg.ppp.wan_cfg.wan_mode.mode = WAN_MODE_ATM;
                if(xAtm_Vcc_Cfg.type == LINK_TYPE_EOATM) 
    		    xWan_Conn.wancfg.ppp.wan_cfg.link_type = LINK_TYPE_PPPOE;
                else if(xAtm_Vcc_Cfg.type == LINK_TYPE_PPPOATM) 
    		    xWan_Conn.wancfg.ppp.wan_cfg.link_type = LINK_TYPE_PPPOATM;
#endif
            }
            break;
        }
        case WAN_DEVICE_MII0:
        {
#ifdef IFX_TR69_ETHERNETWAN
            /*...WANDevice.2.*/
            xWan_Conn.wancfg.ppp.wan_cfg.wan_mode.mode = WAN_MODE_ETH0;
            xWan_Conn.wancfg.ppp.wan_cfg.link_type = LINK_TYPE_PPPOE;
            break;
#endif
        }
        case WAN_DEVICE_MII1:
        {
#ifdef IFX_TR69_ETHERNETWAN
            /*...WANDevice.3.*/
            xWan_Conn.wancfg.ppp.wan_cfg.wan_mode.mode = WAN_MODE_ETH1;
            xWan_Conn.wancfg.ppp.wan_cfg.link_type = LINK_TYPE_PPPOE;
            break;
#endif
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] Default case. Error!\n", __FUNCTION__, __LINE__);
            break;
        }
    }
    iRet = ifx_mapi_set_wan_config(iOper, &xWan_Conn, iFlags);
#endif
    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"Add Mgmt API returned error\n");
   	goto errorHandler;		
    }	
    return IFIN_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d failed!\n", __func__, __LINE__);
    return IFIN_CWMP_FAILURE;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanPPPConSetValue
**   Description      : It can support only one state change in a SET operation.Enabled to Disabled, 
**                      Disabled to Enabled.
**                      Get the Cpeid. Get the object from the system. Get the state(Enable/Disbale) 
**                      of the object
**	                Handle CHECK_MODIFY_DEP. Check if the state change is allowed or not
**                      Handle MODIFY. Get the old state. Forward mapping of values
**                      Modify Enabled object. Modify Disabiled object. Modify the disabled object 
**                      and enable that object.Diable the object and modify it.
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_WanPPPConSetValue(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
							IN int32 iElements)
{
	/*It can support only one state change in a SET operation.Enabled to Disabled, Disabled to Enabled 
	
	  Get the Cpeid. Get the object from the system.Get the state(Enable/Disbale) of the object

	  Handle CHECK_MODIFY_DEP. Check if the state change is allowed or not

	  Handle MODIFY. Get the old state. Forward mapping of values
	*/

	uint32 i=0;
	uint32 uiCpeid=0;
	uint32 uiOld_EnableVal=0;
	WAN_CONN_CFG xMatch_Wan_Conn;
	memset(&xMatch_Wan_Conn,0x00,sizeof(xMatch_Wan_Conn));
	WAN_CONN_CFG *pxMatch_Wan_Conn=&xMatch_Wan_Conn;
	int32 iRet=IFX_CWMP_SUCCESS;
	uint32 iOper=0,iFlags=0,uiParamPos=0;
	uint32 uiVlanCpeid=0;
	uint32 uiDep_Enable=0;
	uint32 SetParamFlag=0;
	int32 Wan_PPP_Port_Enable_Oid[OID_LENGTH]={
						0,0,0,0,0,0,0,OID_IGD_WAND_WANCD_WANPPPC_PM,
						MAGIC_NUMBER,OID_IGD_WAND_WANCD_WANPPPC_PM_PORTMAPPINGENABLED};
	uint32 uiOutElem=0;
	ParamVal axInParamArr[WAN_PPP_NO_DEP_OIDS];
	ParamVal *paxOutParamArr=NULL;
	ParamVal *paxTempParamVal=NULL;
        uint32 cpeid=0;
        int32 LinkCfgOID[OID_LENGTH];
	//parent objects parameters
#ifdef IFX_TR69_ADSLWAN
	int32 Wan_Dsl_Link_Enable_Oid[OID_LENGTH]={0,0,0,0,0,OID_IGD_WAND_WANCD_WANDSLLC, OID_IGD_WAND_WANCD_WANDSLLC_ENABLE};
        ATM_VCC_INFO xAtm_Vcc_Cfg;
        memset(&xAtm_Vcc_Cfg,0,sizeof(xAtm_Vcc_Cfg));
#endif
#ifdef IFX_TR69_PTMWAN
	int32 iaWanPtmLinkEnable[OID_LENGTH]={0,0,0,0,0,OID_IGD_WAND_WANCD_WANPTMLC,
			OID_IGD_WAND_WANCD_WANPTMLC_ENABLE};
        PTM_CH_CFG xPtmChCfg;
        memset(&xPtmChCfg,0,sizeof(xPtmChCfg));
#endif
#ifdef IFX_TR69_ETHERNETWAN
	int32 iaWanEthLinkEnable[OID_LENGTH]={0,0,0,0,0,OID_IGD_WAND_WANCD_WANELC,
								OID_IGD_WAND_WANCD_WANELC_X_AC9A96_ENABLE};
	ETH_CH_CFG xEthChCfg;
        memset(&xEthChCfg, 0, sizeof(xEthChCfg));
#endif
        ///  qos check related variables
	char8  sWan_Conn_vcc[MAX_CONN_NAME_LEN];
        char8  buf[MAX_FILELINE_LEN], sWAN_IDX[MAX_CONN_NAME_LEN];
        int32  nWan_Idx = -1 ;
        uint32 outFlag = IFX_F_DEFAULT;
        char8 vcc_selected[10]={0};
	char8 sLine[256];
        char8 vlan_ref[256] = {0};
	IFX_CpeId *pxCpeIdArray = NULL;
        int32 iaVLANRefOID[OID_LENGTH] = {0};
        vlan_ch_cfg_t xVlanChCfg;

        memset (&xVlanChCfg, 0x00, sizeof(xVlanChCfg));
        buf[0]='\0';
        sWan_Conn_vcc[0]='\0';

	//Get the Cpeid from Tr69 id
	iRet = IFX_GetCpeId(paxParamVal->iaOID,&uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	pxMatch_Wan_Conn->type = WAN_TYPE_PPP;
	//Get the object from system
	iRet= IFX_GetWanObj(pxMatch_Wan_Conn, uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;


	uiOld_EnableVal = pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.f_enable;
	
	if(pxOpInfo->iSubOper == OP_SETVAL_MODIFY)
        {
		/*Store the old enable value in axOldPPPState*/
		IFX_GetSetOldEnableVal(uiCpeid,axOldPPPState,&uiOld_EnableVal,IFX_SET_OLD_ENB_VAL);

	}
        else if (pxOpInfo->iSubOper == OP_SETVAL_ACTIVATE)
        {
		/*Get the current enable value in axOldPPPState*/
		IFX_GetSetOldEnableVal(uiCpeid,axOldPPPState,&uiOld_EnableVal,IFX_GET_OLD_ENB_VAL);
	}
	
	//Modify on top of old values.
	if(pxOpInfo->iSubOper != OP_SETVAL_ACTIVATE)
	{
		iRet=IFX_ConvertPPPArrToWanConCfgStruct(iElements, paxParamVal, pxMatch_Wan_Conn);          
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;

	        uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);	
	        for (i=0; i < iElements; i++) 
	        {
		    if(paxParamVal[i].iaOID[uiParamPos] == OID_IGD_WAND_WANCD_WANPPPC_X_AC9A96_VLANREF)
		    {
                        /* paxParamVal->Value comes as a TR98 hierarchical string format.
                           convert to integer array OID. Then convert the int array to dotted form.
                           Get CpeId of vlan object. Set it as parent of the PPP connection*/
                        iRet = IFX_GlobalNameOidConversion(paxParamVal[i].Value, iaVLANRefOID);
                	if(iRet != IFX_CWMP_SUCCESS)
                        {
			    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					"[%s:%d] [Error] IFX_GlobalNameOidConversion failed\n",
					__func__, __LINE__);
	                    goto errorHandler;
	                }
	                iRet = IFX_ConvertObjOidDottedForm(iaVLANRefOID, vlan_ref);
                	if(iRet != IFX_CWMP_SUCCESS)
                        {
			    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					"[%s:%d] [Error] IFX_ConvertOidDottedForm failed\n",
					__func__, __LINE__);
	                    goto errorHandler;
	                }

		        iRet = IFX_GetCpeIdFromTr69Id(vlan_ref, &uiVlanCpeid,  &pxCpeIdArray);
		        if(iRet != IFX_CWMP_SUCCESS)
                        {
			    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					"[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed [%s]\n",
					__func__, __LINE__, vlan_ref);
			    IFX_CWMP_FREE(pxCpeIdArray);
			    goto errorHandler;
		        }
                        xVlanChCfg.iid.cpeId.Id= pxCpeIdArray->uiId;
              		IFX_CWMP_FREE(pxCpeIdArray);
                        iRet = mapi_get_vlan_ch_entry(-1, &xVlanChCfg, IFX_F_GET_ANY);
		        if(iRet != IFX_CWMP_SUCCESS)
                        {
			    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					"[%s:%d] [Error] mapi_get_vlan_ch_entry failed [%s]\n",
					__func__, __LINE__, vlan_ref);
			    goto errorHandler;
		        }
		        pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.iid.pcpeId.Id = xVlanChCfg.iid.cpeId.Id;
		        strcpy(pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.l2iface_name, xVlanChCfg.l2ifName);
                        break;
     	            }
                } 
	}

	//Get the WanPPPConParamPos 
	uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);

	switch(pxOpInfo->iSubOper)
	{			
		case OP_SETVAL_CHK_MODIFY_DEP:
			break;
					
		case OP_SETVAL_MODIFY:
		case OP_SETVAL_ACTIVATE:
			//TBD::Dependency check is moved into MODIFY
				
			//Call global function to get the WanPPPPortEnable Enable value
			//Pass Oid array with magic nos it should return 
			//OID,Name,Values,error_status

			//PPPConnection-PortMappingEntries when it is enabled
			//We cannot disable PPPConnection
			//memset the structs passed to GlobalGetVal

			memset(axInParamArr,0x00,(sizeof(ParamVal) *WAN_PPP_NO_DEP_OIDS));
			
			memcpy(axInParamArr->iaOID,Wan_PPP_Port_Enable_Oid,
								(sizeof(int32)*OID_LENGTH));
			memcpy((axInParamArr)->iaOID,paxParamVal->iaOID,
							(sizeof(int32)*(uiParamPos)));

			iRet=IFX_GlobalGetVal(axInParamArr,&paxOutParamArr, &uiOutElem);
			if(iRet != IFX_CWMP_SUCCESS) 
			{
				IFX_PrintOID(axInParamArr->iaOID);
				IFX_FreeParamvalArr(&paxOutParamArr,uiOutElem);
				iRet = IFX_CWMP_SUCCESS;
			}

			paxTempParamVal = paxOutParamArr;
			for(i=0; i < uiOutElem; ++i) 
			{
				if(paxTempParamVal != NULL)
				{
					if((iRet  =IFX_FwdMappingValues(gaxEnable,4,
								(void *)(paxTempParamVal->Value),	
								(void *)&(uiDep_Enable))) !=IFX_CWMP_SUCCESS)
                                        {
					       goto ChkModifyDepErrorHandler;
                                        }
					if((uiOld_EnableVal == IFX_ENABLED) && (pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.f_enable== IFX_DISABLED))
					{			
						/*If old/present value is enable and we are trying to enable the 
						  ppp connection while the port mapping is enabled, then error!*/
						if(uiDep_Enable == IFX_ENABLED)
						{
							iRet=ERR_CWMP_INVAL_OPER;
							goto ChkModifyDepErrorHandler;	
						}
						else
						{
							continue;
						}
					}
				}
				paxTempParamVal++;
			}
ChkModifyDepErrorHandler:
			IFX_FreeParamvalArr(&paxOutParamArr,uiOutElem);
			if(iRet != IFX_CWMP_SUCCESS)
				goto errorHandler;

				
			//Completion of first case
                        uiDep_Enable = IFX_ENABLED;
	            	if(paxParamVal[0].iaOID[2] == WAN_DEVICE_ATM)
			{
                            /*If enabling the IPConnection, then the parent DSL or PTM link config should not be disabled*/
                            if(pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.f_enable== IFX_ENABLED)
                   	    {	
                                /*WCD.1 -> PTM*/
			        if(paxParamVal[0].iaOID[4] == 1)
	        		{
					#ifndef IFX_TR69_PTMWAN
					/*return error*/
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"Cannot add connection on Channel reserved for PTM\n");
                			iRet = IFIN_CWMP_FAILURE;
			                goto errorHandler;
					#endif
				#ifdef IFX_TR69_PTMWAN
				//memset the structs
       		 		memset(&LinkCfgOID, 0x00,(sizeof(int32) * OID_LENGTH));
				memcpy(LinkCfgOID, iaWanPtmLinkEnable, (sizeof(int32)*OID_LENGTH));
				memcpy(LinkCfgOID, paxParamVal->iaOID, (sizeof(int32)*(WAN_CON_DEV_DEPTH +1)));
	
       		 	        //Get the Cpeid from Tr69 id
       		         	iRet = IFX_GetCpeId(LinkCfgOID, &cpeid);
		                if(iRet != IFX_CWMP_SUCCESS)
       		 	        {
       		         	    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Get Cpe ID Failed!\n", __func__, __LINE__);
		                    goto errorHandler;
       			        }
        
               		 	xPtmChCfg.iid.cpeId.Id = cpeid;
				iRet = ifx_get_ptm_ch_cfg(&xPtmChCfg, IFX_F_DEFAULT);
		                if(iRet != IFX_CWMP_SUCCESS)
               		        {
		                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d ifx_get_ptm_ch_cfg() Failed!\n", __func__, __LINE__);
                		    goto errorHandler;
		                }
       	       		        uiDep_Enable = xPtmChCfg.f_enable; 
				#endif
		   	}
		   	else
           		{
				#ifndef IFX_TR69_ADSLWAN
				/*return error*/
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"Cannot modify connection on Channel reserved for ATM\n");
		                iRet = IFIN_CWMP_FAILURE;
                		goto errorHandler;
				#endif


				#ifdef IFX_TR69_ADSLWAN
		        	memset(&LinkCfgOID,0x00,(sizeof(int32) * OID_LENGTH));
				memcpy(LinkCfgOID,Wan_Dsl_Link_Enable_Oid, (sizeof(int32)*OID_LENGTH));
				memcpy(LinkCfgOID,paxParamVal->iaOID, (sizeof(int32)*(WAN_CON_DEV_DEPTH +1)));
					
		                //Get the Cpeid from Tr69 id
       		 	        iRet = IFX_GetCpeId(LinkCfgOID, &cpeid);
       		         	if(iRet != IFX_CWMP_SUCCESS)
		                {
       		 	            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Get Cpe ID Failed!\n", __func__, __LINE__);
       		         	    goto errorHandler;
		                }
        
       		 	        xAtm_Vcc_Cfg.iid.cpeId.Id = cpeid;
       		         	//Get the object from system
		                iRet= IFX_GetVccObj(&xAtm_Vcc_Cfg, cpeid);
       		 	        if(iRet != IFX_CWMP_SUCCESS)
       		         	    goto errorHandler;

                		uiDep_Enable = xAtm_Vcc_Cfg.f_enable;
                                #endif
			    }
				if(uiDep_Enable == IFX_DISABLED) 
				{
		                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Cannot enable child when parent is disabed!\n", __func__, __LINE__);
				    iRet=ERR_CWMP_INVAL_PARAM_VAL;
				    goto ChkModifyDepErrorHandler;
				}	 
			}
		}	
        else
	{
#ifdef IFX_TR69_ETHERNETWAN
		    //memset the structs
        	memset(&LinkCfgOID, 0x00,(sizeof(int32) * OID_LENGTH));
			memcpy(LinkCfgOID, iaWanEthLinkEnable, (sizeof(int32)*OID_LENGTH));
			memcpy(LinkCfgOID, paxParamVal->iaOID, (sizeof(int32)*(WAN_CON_DEV_DEPTH +1)));

           //Get the Cpeid from Tr69 id
           iRet = IFX_GetCpeId(LinkCfgOID, &cpeid);
           if(iRet != IFX_CWMP_SUCCESS)
           {
               IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Get Cpe ID Failed!\n", __func__, __LINE__);
               goto errorHandler;
           }
   
           xEthChCfg.iid.cpeId.Id = cpeid;
           iRet = ifx_get_eth_ch_cfg(&xEthChCfg, IFX_F_DEFAULT);
           if(iRet != IFX_CWMP_SUCCESS)
           {
               IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d ifx_get_eth_ch_cfg() Failed!\n", __func__, __LINE__);
               goto errorHandler;
           }
           uiDep_Enable =  xEthChCfg.f_enable;
           if(pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.f_enable== IFX_ENABLED)
		   {	
               if(uiDep_Enable == IFX_DISABLED)
               {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d ifx_get_eth_ch_cfg() Failed!\n", __func__, __LINE__);
					iRet=ERR_CWMP_INVAL_PARAM_VAL;
					goto ChkModifyDepErrorHandler;
               }
           }
#endif
	}
							
			if(paxParamVal[0].iaOID[2] == WAN_DEVICE_ATM)
			{	
				if(pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.f_enable == IFX_ENABLED) 
				{
					//Minimum validation
					if((pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.link_type != WAN_LINK_TYPE_PPPOE) &&
					    (pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.link_type != WAN_LINK_TYPE_PPPOATM))
					{
						//Please return err string for WanConnectionType
	 	                		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            			"%s:%d failed!\n", __func__, __LINE__);
						
						iRet = ERR_CWMP_INVAL_PARAM_VAL;
						goto errorHandler;
					}
					if((pxMatch_Wan_Conn->wancfg.ppp.transport_type == WAN_PPP_TRANSPORT_TYPE_PPPOA) &&
					    (pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.link_type != WAN_LINK_TYPE_PPPOATM))
					{
	 	                		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            			"%s:%d failed!\n", __func__, __LINE__);
						
						iRet = ERR_CWMP_INVAL_PARAM_VAL;
						goto errorHandler;
					}
					if((pxMatch_Wan_Conn->wancfg.ppp.transport_type == WAN_PPP_TRANSPORT_TYPE_PPPOE) &&
					    (pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.link_type != WAN_LINK_TYPE_PPPOE))
					{
	 	                		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            			"%s:%d failed!\n", __func__, __LINE__);
						
						iRet = ERR_CWMP_INVAL_PARAM_VAL;
						goto errorHandler;
					}
				}
	        	}
        	        // check for qos enabled on the interface
                	if(uiOld_EnableVal == IFX_ENABLED && pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.f_enable == IFX_DISABLED)
			{
				if(ifx_GetObjData(FILE_SYSTEM_STATUS, "http_wan_vcc_select", "WAN_VCC", iFlags, &outFlag, sWAN_IDX) == IFX_SUCCESS)
				{
                        		nWan_Idx = atoi(sWAN_IDX);
	                                nWan_Idx = ( (nWan_Idx < 1) ? 1 : nWan_Idx );
	
        	                        sprintf(buf, "%s_%d_vcc", "wan", nWan_Idx);
                	                if (ifx_GetObjData(FILE_RC_CONF, "wan_main", buf, IFX_F_GET_ENA, &outFlag, sWan_Conn_vcc) == IFX_SUCCESS)
					{
                                	        ifx_GetObjData(FILE_RC_CONF, "qos_queuemgmt", "qm_atmQmode",IFX_F_DEFAULT,&outFlag,sLine);
						if (atoi(sLine) == IFX_MAPI_QoS_ATM_PVC_BASED)
						{
		                                	if(ifx_GetObjData(FILE_RC_CONF, "qos_queuemgmt", "qm_qIf",IFX_F_DEFAULT,&outFlag,vcc_selected) == IFX_SUCCESS)
							{
                		                                if(strcmp( sWan_Conn_vcc, vcc_selected ))
								{
        	                        	                    iRet=ERR_CWMP_INVAL_OPER;
                	                        	            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                                        	         "%s:%d Cannot disable the QoS enabled interface! \n "
                                                                	 "Disable QoS before disabling the interface \n", __func__, __LINE__);
	                        	                            goto errorHandler;
        	                        	                }
                	                        	}
                        	                }
                                	}
                        	}
	                }

			if(uiOld_EnableVal == IFX_ENABLED) 
			{
				if(pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.f_enable== IFX_DISABLED) 
				{
					//Call with deactivate and modify flags 
					if((pxOpInfo->iCaller == ACC_TR69) && (pxOpInfo->iSubOper == OP_SETVAL_MODIFY)
						&& (pxMatch_Wan_Conn->wanv4.ip_mask.ip.s_addr == guiConnReqIPAddr)) 
					{
						SetParamFlag = 1;
						uiActiveWANPPPCpeid = uiCpeid;
						iFlags= (IFX_F_MODIFY| IFX_F_INT_DONT_CONFIGURE|
                                                                IFX_F_DEACTIVATE|
								IFX_F_DONT_CHECKPOINT|IFX_F_DONT_VALIDATE |
								IFX_F_DONT_WRITE_TO_FLASH);
        	       				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			    	                  "%s:%d ACTIVE & MODIFY :Enable->Disable!\n", __func__, __LINE__);
					}
					else
					{
						//SetParamFlag = 0;
						//uiNeedReboot=1;
						iFlags= (IFX_F_DEACTIVATE|IFX_F_MODIFY|
									IFX_F_DONT_CHECKPOINT|IFX_F_DONT_VALIDATE |
									IFX_F_DONT_WRITE_TO_FLASH);
						IFX_GetSetOldEnableVal(uiCpeid,axOldPPPState,
							(uint32 *)&pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.f_enable,
									IFX_RESET_OLD_ENB_VAL);
               					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			   	                     "%s:%d ACTIVATE | MODIFY :Enable->Disable !\n", __func__, __LINE__);
					}

					pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.f_enable = IFX_DISABLED;
				} 
				else if (pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.f_enable == IFX_ENABLED) 
				{
					if((pxOpInfo->iCaller == ACC_TR69) && 
						(pxOpInfo->iSubOper == OP_SETVAL_MODIFY) &&
						(pxMatch_Wan_Conn->wanv4.ip_mask.ip.s_addr == guiConnReqIPAddr)) 
					{ 
						SetParamFlag = 1;
						uiActiveWANPPPCpeid = uiCpeid;
						iFlags= (IFX_F_MODIFY|IFX_F_INT_DONT_CONFIGURE|
									IFX_F_DONT_CHECKPOINT|
								IFX_F_DONT_WRITE_TO_FLASH);
						IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
				                  "%s:%d ACTIVE & MODIFY :Enable->Enable !\n", __func__, __LINE__);
					}
					else
					{	
						iFlags= (IFX_F_MODIFY|
								IFX_F_DONT_CHECKPOINT|
								IFX_F_DONT_WRITE_TO_FLASH);

						IFX_GetSetOldEnableVal(uiCpeid,axOldPPPState,
						    (uint32 *)&pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.f_enable,
							IFX_RESET_OLD_ENB_VAL);
       						IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
				                  "%s:%d ACTIVATE | MODIFY :Enable->Enable !\n", __func__, __LINE__);

					}
					pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.f_enable = IFX_ENABLED;
				}
			}
			else if (uiOld_EnableVal == IFX_DISABLED)
			{
				if(pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.f_enable == IFX_DISABLED) 
				{
					//Call with don't activate and modify
					 iFlags= (IFX_F_DONT_ACTIVATE|IFX_F_MODIFY|
						IFX_F_DONT_CHECKPOINT|IFX_F_DONT_VALIDATE|
						IFX_F_DONT_WRITE_TO_FLASH);				
					IFX_GetSetOldEnableVal(uiCpeid,axOldPPPState,
						(uint32 *)&pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.f_enable,
						IFX_RESET_OLD_ENB_VAL);
					pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.f_enable = IFX_DISABLED;
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                  			"%s:%d MODIFY : Disable->Disable !\n", __func__, __LINE__);	
				}
				else if(pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.f_enable == IFX_ENABLED) 
				{
					//Call the API with Modify
					iFlags= (IFX_F_MODIFY|
						IFX_F_DONT_CHECKPOINT|
						IFX_F_DONT_WRITE_TO_FLASH);
					IFX_GetSetOldEnableVal(uiCpeid,axOldPPPState,
						(uint32 *)&pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.f_enable,
						IFX_RESET_OLD_ENB_VAL);
							
					pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.f_enable = IFX_ENABLED;
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                  		"%s:%d MODIFY :Disable->Enable !\n", __func__, __LINE__);
				}		
			}

			//MTU size
			pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.max_mtu = 1492;
			pxMatch_Wan_Conn->wancfg.ppp.max_mru_size = 1492;
				
			//Fill the Cpeid,ParentCepid,TR69Id,Owner
			pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.iid.cpeId.Id=uiCpeid;
			pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.iid.config_owner=pxOpInfo->iCaller;
				
			iOper = IFX_OP_MOD;

#ifdef IFX_TR69_WAN_MODS_TEST_STUBS				
			ifx_set_wan_atm_vcc_ppp_config_stub(iOper, pxMatch_Wan_Conn, iFlags);
#else
#if 0
        switch(paxParamVal[0].iaOID[2])
        {
            case WAN_DEVICE_ATM:
            {
                /*...WANDevice.1.*/
                /*WCD.1 -> PTM*/
	        if(paxParamVal[0].iaOID[4] == 1)
		{
		    pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.wan_mode.mode = WAN_MODE_VDSL_PTM;
		}
	        else
                {
                    pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.wan_mode.mode = WAN_MODE_ATM;
                }
                break;
            }
            case WAN_DEVICE_MII0:
            {
#ifdef IFX_TR69_ETHERNETWAN 
                /*...WANDevice.2.*/
                pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.wan_mode.mode = WAN_MODE_ETH0;
#endif
                break;
            }
            case WAN_DEVICE_MII1:
            {
#ifdef IFX_TR69_ETHERNETWAN 
                /*...WANDevice.3.*/
                pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.wan_mode.mode = WAN_MODE_ETH1;
#endif
                break;
            }
            default:
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] Default case. Error!\n", __FUNCTION__, __LINE__);
                break;
            }
        }
#endif
		iRet = ifx_mapi_set_wan_config(iOper, pxMatch_Wan_Conn, iFlags);
#endif
		if(iRet != IFX_SUCCESS)
		{
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
			"ifx_mapi_set_wan_config -Modify Mgmt API returned error\n",
			_FUNCL_);
			goto errorHandler;
		}	

		break;

		default:
			break;
	}
	if((SetParamFlag ==1) && (iRet == IFX_CWMP_SUCCESS))
	{
		return IFX_CWMP_NEED_ACTIVATE;
	}

	if((pxOpInfo->iSubOper == OP_SETVAL_ACTIVATE) && (iRet == IFX_CWMP_SUCCESS))
	{
            return IFX_CWMP_NO_REBOOT_SAVE;
	}

	return IFIN_CWMP_SUCCESS;

	errorHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d failed!\n", __func__, __LINE__);
				
    	if((uiActiveWANPPPCpeid == uiCpeid) ||
		  (pxOpInfo->iSubOper == OP_SETVAL_ACTIVATE))
	{
		return IFX_CWMP_NEED_REBOOT_DONT_SAVE;
	}
	else
	{
		return iRet;
	}
}

/* 
** =============================================================================
**   Function Name    : IFX_WanPPPConSetCommit
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanPPPConSetCommit()
{
	return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanPPPConSetUndo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanPPPConSetUndo()
{
	return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanPPPConCheckDeleteDependency 
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_WanPPPConCheckDeleteDependency(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
				IN int32 iElements, OUT void **ppxParamStructRet, OUT int32 * piNumRetElem)
{
	ParamVal *Param_DepOids=NULL;
	uint32 uiParamPos=0;
	int32 i=0;
	int32 ppp_stats_OID[OID_LENGTH]={0,0,0,0,0,OID_IGD_WAND_WANCD_WANPPPC,
									MAGIC_NUMBER,
									OID_IGD_WAND_WANCD_WANPPPC_S};
	int32 ppp_port_OID[OID_LENGTH]={0,0,0,0,0,OID_IGD_WAND_WANCD_WANPPPC,
									MAGIC_NUMBER,
									OID_IGD_WAND_WANCD_WANPPPC_PM,
									MAGIC_NUMBER};

	Param_DepOids = IFIN_CWMP_MALLOC((WAN_PPP_NO_DEP_OIDS+1)* sizeof(ParamVal));
	if(Param_DepOids == NULL)
	{
		goto errorHandler;
	}

	//Get the WanpppConParamPos 
	uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);

	memcpy((Param_DepOids+0)->iaOID,ppp_stats_OID, (sizeof(int32)*OID_LENGTH));
	memcpy((Param_DepOids+1)->iaOID,ppp_port_OID, (sizeof(int32)*OID_LENGTH));
	memcpy((Param_DepOids+2)->iaOID,paxParamVal->iaOID, (sizeof(int32)*(uiParamPos+1)));

	for(i=0; i <WAN_PPP_NO_DEP_OIDS; ++i)
		memcpy((Param_DepOids+i)->iaOID,paxParamVal->iaOID, (sizeof(int32)*(uiParamPos+1)));

	*ppxParamStructRet = (void *)Param_DepOids;
	*piNumRetElem = WAN_PPP_NO_DEP_OIDS+1;
	return IFIN_CWMP_SUCCESS;

errorHandler:
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
	return IFIN_CWMP_FAILURE;
}
/* 
** =============================================================================
**   Function Name    : IFX_WanPPPConSetDelete
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanPPPConSetDelete(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
				IN int32 iElements, OUT void **ppxParamStructRet, OUT int32 * piNumRetElem)
{

	uint32 uiCpeid=0;
	WAN_CONN_CFG xMatch_Wan_Conn;
        WAN_CONN_CFG *pxMatch_Wan_Conn=&xMatch_Wan_Conn;
	int32 iRet=0;
	uint32 iOper,iFlags=0;
	uint32 uiStatus=0;
#ifdef IFX_TR69_ADSLWAN
        ATM_VCC_INFO xAtm_Vcc_Cfg;
        memset(&xAtm_Vcc_Cfg,0,sizeof(xAtm_Vcc_Cfg));
#endif
#ifdef IFX_TR69_PTMWAN
        PTM_CH_CFG xPtmChCfg;
        memset(&xPtmChCfg,0,sizeof(xPtmChCfg));
#endif

        memset(&xMatch_Wan_Conn,0x00,sizeof(xMatch_Wan_Conn));

	//Get the Cpeid from Tr69 id
	iRet = IFX_GetCpeId(paxParamVal->iaOID,&uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
	{
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Get Cpe ID Failed!\n", __func__, __LINE__);
		goto errorHandler;
	}
	
	pxMatch_Wan_Conn->type = WAN_TYPE_PPP;
	//Get the object from system
	iRet= IFX_GetWanObj(pxMatch_Wan_Conn, uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
	{
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Get WAN Obj Failed!\n", __func__, __LINE__);
		goto errorHandler;
	}
	
	switch(pxOpInfo->iSubOper)
	{
		case OP_SETVAL_CHK_DEL_ALLOWED:
			// handle CHK_DELETE_ALLOWED
			//Check for default instance if del is called by TR69
			//if(pxMatch_Atm_Vcc->f_default == IFX_DEFAULT)
			//	goto errorHandler;
			if((pxOpInfo->iCaller == ACC_TR69) && 
			      (pxMatch_Wan_Conn->wancfg.ppp.local_addr.s_addr == guiConnReqIPAddr)) 
			{
				uiStatus=1;	
			}
			break;

		case OP_SETVAL_DELETE:
			//handle DELETE operation
			//Call Platform API to delete the obj in the system
			//If del is called by web we need to pass special owner for which API 
			//will not post a message.
                        pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.iid.config_owner=pxOpInfo->iCaller;
			pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.iid.cpeId.Id=uiCpeid;
			memset(pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.iid.tr69Id,0x00,MAX_TR69_ID_LEN);
			iOper = IFX_OP_DEL;
			iFlags = (IFX_F_DELETE|IFX_F_DONT_VALIDATE|
					IFX_F_DONT_CHECKPOINT|IFX_F_DONT_WRITE_TO_FLASH);
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
			ifx_set_wan_atm_vcc_ppp_config_stub(iOper, pxMatch_Wan_Conn, iFlags);
#else
			switch(paxParamVal[0].iaOID[2])
		        {
				case WAN_DEVICE_ATM:
				{
			                /*...WANDevice.1.*/
                /*If WCD.1. then PTMLC
                else DSLLC*/
	            if(paxParamVal[0].iaOID[4] == 1)
	            {
#ifdef IFX_TR69_PTMWAN
			                    pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.wan_mode.mode = WAN_MODE_VDSL_PTM;
					    //strcpy(pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.l2iface_name, xPtmChCfg.l2ifname);
#endif
                }
                else
                {
#ifdef IFX_TR69_ADSLWAN
			                pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.wan_mode.mode = WAN_MODE_ATM;
					//strcpy(pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.l2iface_name, xAtm_Vcc_Cfg.l2ifname);
#endif
                }
			                break;
            			}
				case WAN_DEVICE_MII0:
            			{
			                /*...WANDevice.2.*/
					#ifdef IFX_TR69_ETHERNETWAN
			                pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.wan_mode.mode = WAN_MODE_ETH0;
					//strcpy(pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.l2iface_name, "eth0");
					#endif
			                break;
            			}
			        case WAN_DEVICE_MII1:
			        {
			                /*...WANDevice.3.*/
					#ifdef IFX_TR69_ETHERNETWAN
			                pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.wan_mode.mode = WAN_MODE_ETH1;
					//strcpy(pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.l2iface_name, "eth1");
					#endif
			                break;
            			}
			        default:
            			{
			                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] Default case. Return Error!\n", __FUNCTION__, __LINE__);
			                break;
            			}
        		}
		        iRet = ifx_mapi_set_wan_config(iOper, pxMatch_Wan_Conn, iFlags);
#endif
			
			if(iRet != IFX_SUCCESS)
			{
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					"ifx_mapi_set_wan_config() - delete Mgmt API returned error\n");
				goto errorHandler;					
			}
			
			//Reset the Old Enable Value stored in the array
			IFX_GetSetOldEnableVal(uiCpeid,axOldPPPState,
				(uint32 *)&pxMatch_Wan_Conn->wancfg.ppp.wan_cfg.f_enable,
					IFX_RESET_OLD_ENB_VAL);
			break;
			
		default:
			break;
	}

	if((uiStatus==1) && (iRet == IFX_CWMP_SUCCESS))
		return IFX_CWMP_NEED_ACTIVATE;

	return IFIN_CWMP_SUCCESS;
	
errorHandler:
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
	return IFIN_CWMP_FAILURE;

}

/* 
** =============================================================================
**   Function Name    : IFX_WanPPPConSetFree
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanPPPConSetFree()
{
	return IFX_CWMP_SUCCESS;
}


/* 
** =============================================================================
**   Function Name    : IFX_WanPPPConSetAttr
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

int32
IFX_WanPPPConSetAttr(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{
	int32 iRet=IFX_CWMP_SUCCESS,i=0;
	OperInfo xOpInfo;
	
	xOpInfo.iCaller = pxOpInfo->iCaller;
	xOpInfo.iOper= OP_GETVAL;
	xOpInfo.iSubOper= OP_GETVAL_NORMAL;
	
	iRet = IFX_WanPPPConGetValue(&xOpInfo,pxParamVal, iElements);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorFreeHandler;
	
	iRet = IFX_SetAttributesInfo(pxOpInfo,pxParamVal, iElements);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorFreeHandler;

	errorFreeHandler:
		for(i=0; i < iElements; i++)
		IFX_CWMP_FREE(pxParamVal[i].Value);
		
                if (iRet)
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
		return iRet;
}



/* 
** =============================================================================
**   Function Name    : IFX_WanPPPConUpdateChildInfo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

static int32 IFX_WanPPPConUpdateChildInfo(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{
	uint32 i=0,iRet=0;
	char8 usSecTag[IFX_MAX_SECTION_TAG_LEN]={0};
	char8 usParamTag[IFX_MAX_NAME_LEN]={0};
	uint32 uiParamPos=0,uiChildObjId=0;
	uint32 uiCpeid=0;
	int32 *iaOID=NULL;
	uint32 uiNumNV=1;
	//IFX_CpeId pxCpeId;
	IFX_Id xIfx_Id;
	IFX_NameValue pxNVArray;
	uint32 uiOper=IFX_NOTIFY_OPER_MODIFY;
	ParamVal *pxTempParamVal=pxParamVal;

		//memset the structs
		memset(&xIfx_Id,0x00,sizeof(xIfx_Id));
		memset(&pxNVArray,0x00,sizeof(pxNVArray));

		//Get Cpeid
		iRet = IFX_GetCpeId(pxTempParamVal->iaOID, &uiCpeid);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;

		//Get the child object Oid
		uiChildObjId = IFX_GetParamIdPos((int32 *)pxTempParamVal->pReserved);
		iaOID = (int32 *)pxTempParamVal->pReserved;

		for(i=0; i < iElements; i++)

		{
			//Get the Param Oid of this object
			uiParamPos= IFX_GetParamIdPos(pxTempParamVal->iaOID);
			
			if(pxTempParamVal->iaOID[uiParamPos] ==			
				 OID_IGD_WAND_WANCD_WANPPPC_PORTMAPPINGNUMBEROFENTRIES)
				 {
					if(iaOID[uiChildObjId-1] ==	OID_IGD_WAND_WANCD_WANPPPC_PM)
					{
						//Get the section and Paramtag
						iRet=IFX_GetSectionParamTag(pxTempParamVal->psRCTag, usParamTag, usSecTag);
						if(iRet != IFX_CWMP_SUCCESS)
							goto errorHandler;
						
						xIfx_Id.uiConfigOwner= pxOpInfo->iCaller;
						xIfx_Id.xCpeId.uiId= uiCpeid;
						strncpy(xIfx_Id.xCpeId.sSectionTag,usSecTag, IFX_MAX_SECTION_TAG_LEN-1);
						xIfx_Id.xCpeId.sSectionTag[IFX_MAX_SECTION_TAG_LEN-1] = '\0';
						strncpy(pxNVArray.sName,usParamTag, IFX_MAX_NAME_LEN-1);
						pxNVArray.sName[IFX_MAX_NAME_LEN-1] = '\0';
												
						iRet=IFX_SendNotify(&xIfx_Id, uiNumNV, 
												&pxNVArray, uiOper);
						if(iRet != IFX_CWMP_SUCCESS)
						{
							IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 			"%s:%d IFX_SendNotify failed!\n", __func__, __LINE__);
							
							goto errorHandler;
						}
					}
				}

			pxTempParamVal++;
			
		}
					
		return IFX_CWMP_SUCCESS;

		errorHandler:
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
			
			return IFX_CWMP_FAILURE;
			
}



/* 
** =============================================================================
**   Function Name    : IFX_WanPPPConnection_Init
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_WanPPPConnection_Init(void)
{
	int32 iRet = IFX_CWMP_SUCCESS;

    
	/* Register the WanPPPConnection module function pointer in the object model */
	iRet = ifx_ds_register_function(IFX_WAN_PPPCON_OBJ, IFX_WanPPPConnection);

	/* Check for error */
	if (iRet != IFX_CWMP_SUCCESS)
	{
	    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                "Unable to Register %s with Object Model\n",
	                 IFX_WAN_PPPCON_OBJ);
	    goto errorHandler;
	}

	errorHandler:
			return iRet;
}

/*********************************************************************************
*  Function Name	:  IFX_WanPPPConnection
      *  Description	:  This function handles all the sub-states inside
      	 		   a GET/SET operation.If it is a GET it allocates the 
			   array(Name,Value pairs) and retruns the values.
			   If it is a SET controller allocates the array and
			   passes the values to this function.It calls 
			   respective internal functions which in turn calls 
			   respective Platform APIs.
                                                                                                 
*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
							     Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has 
					  	             Name,Value,etc
                    IN          int32	       iElements;    No. of Elements
		    OUT	        void *	       ppParamRet;   same as ParamStruc
		    OUT         int32 *        piNumRetElem; No. of elements 		                                
*  Return Value        : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes               :
***********************************************************************************/
int32
IFX_WanPPPConnection(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                IN int32 iElements, OUT void **ppaxParamArrRet, OUT int32 *piNumRetElem)
{
     
   //It calls the respective internal functions which handles resp. sub-operation
   
   //Set-Operation  
   //controller should pass the entire array during all the SET-sub_operations
   //It should handles only single get/set of instance at any point of time
   //It does not handle partial path
   //It won't handle multiple instances of the same object/module
   //at any point of time.

    
    int32 iRet = 0;
    ParamVal *paxParamArr = (ParamVal *)paxParameterArr;
IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"%s:%d Oper[%d], suboper [%d]\n", __func__, __LINE__, pxOperInfo->iOper, pxOperInfo->iSubOper);
                            

	switch (pxOperInfo->iOper) 
	{
		//Get the object values
	   	case OP_GETVAL:
		
	            if((iRet = IFX_WanPPPConGetValue(pxOperInfo, paxParamArr,
		    							iElements)) != IFX_CWMP_SUCCESS) {
	                
					
			  IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
			  goto errorHandler;
	            }
	            break;
	        case OP_SETVAL:
		{

	    		//Set the obj values
			switch (pxOperInfo->iSubOper) 
			{
		               case OP_SETVAL_VALIDATE:
		                    if((iRet = IFX_WanPPPConSetValidate(pxOperInfo,paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {     
		                        
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d OP_SET_VALIDATE failed!\n", __func__, __LINE__);
					goto errorHandler;
		                    }
		                 
		                    break;
		                case OP_SETVAL_ADD:
		                    
		                    if((iRet= IFX_WanPPPConAddObj(pxOperInfo,paxParamArr,
				    					iElements))!=IFX_CWMP_SUCCESS)
		                    	{
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            	"%s:%d OP_SETVAL_ADD failed!\n", __func__, __LINE__);
		                    	 goto errorHandler;
		                    	}
		                    break;
		              case OP_SETVAL_CHK_MODIFY_DEP:
				case OP_SETVAL_MODIFY:
				case OP_SETVAL_ACTIVATE:
		                    if((iRet = IFX_WanPPPConSetValue(pxOperInfo,paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
		    												
					if ((iRet == IFX_CWMP_NEED_REBOOT_DONT_SAVE) || (iRet < IFX_CWMP_SUCCESS)){
					  	switch(pxOperInfo->iSubOper) {
						  	 case OP_SETVAL_CHK_MODIFY_DEP:
							IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_CHK_MODIFY_DEP failed!\n", __func__, __LINE__);
				                        goto errorHandler;
										
							case OP_SETVAL_MODIFY:
							IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_MODIFY failed!\n", __func__, __LINE__);
				                        goto errorHandler;
							
							case OP_SETVAL_ACTIVATE:
							IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_ACTIVATE failed!\n", __func__, __LINE__);
				                        goto errorHandler;
	
					  	}
				  	    } else if ((iRet == IFX_CWMP_NEED_ACTIVATE) ||
							(iRet == IFX_CWMP_NEED_REBOOT)) {
							goto errorHandler;
					    }
				    	 }
							
		                   
		                    break;
		                case OP_SETVAL_COMMIT:
		                    if((iRet = IFX_WanPPPConSetCommit(pxOperInfo,paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
				    	   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_COMMIT failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;

		                case OP_SETVAL_UNDO:
		                    if((iRet =IFX_WanPPPConSetUndo(pxOperInfo, paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
				    	   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_UNDO failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;

				case OP_SETVAL_CHK_DEL_DEP:
		                    if((iRet= IFX_WanPPPConCheckDeleteDependency(pxOperInfo, paxParamArr,
				    					iElements, ppaxParamArrRet,
				    					piNumRetElem)) != IFX_CWMP_SUCCESS)
				    {
				        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		                            	"%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
				        goto errorHandler;
				    }
				    break;

			      case OP_SETVAL_CHK_DEL_ALLOWED:
		              case OP_SETVAL_DELETE:
		                    if((iRet= IFX_WanPPPConSetDelete(pxOperInfo, paxParamArr,
				    					iElements, ppaxParamArrRet,
				    					piNumRetElem)) != IFX_CWMP_SUCCESS) {

						if(iRet == IFX_CWMP_NEED_ACTIVATE)
							goto errorHandler;

				    		switch(pxOperInfo->iSubOper)
						{	
							case OP_SETVAL_CHK_DEL_ALLOWED:
								IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
				                            	"%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
					                        goto errorHandler;
							case OP_SETVAL_DELETE:
								IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
		        		                    	"%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
				        	                goto errorHandler;
						}
								
				    }
		                    break;
		                case OP_SETVAL_FREE:
		                    IFX_WanPPPConSetFree(pxOperInfo);
		                    break;

				 case OP_SETVAL_ATTRINFO:
				 	if((iRet =IFX_WanPPPConSetAttr(pxOperInfo, paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
				    	  IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            	"%s:%d OP_SETVAL_ATTRINFO failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;	
		                default:
		                    break;
			}
			break;	
		}
			case OP_UPDATE_CHILDINFO:
                        {
				//Updation of child related info is handled by the case
				switch(pxOperInfo->iSubOper)
				{
					case OP_UPDATE_CHILDINFO_ADD:
					case OP_UPDATE_CHILDINFO_DEL:
					 if((iRet =IFX_WanPPPConUpdateChildInfo(pxOperInfo, 
									paxParamArr,iElements)) != IFX_CWMP_SUCCESS)
				 	{
				 		switch(pxOperInfo->iSubOper)
						{	

							case OP_UPDATE_CHILDINFO_ADD:
								 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
				                            	"%s:%d OP_UPDATE_CHILDINFO_ADD failed!\n", __func__, __LINE__);
								goto errorHandler;
								
							case OP_UPDATE_CHILDINFO_DEL:
								 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
				                            	"%s:%d OP_UPDATE_CHILDINFO_DEL failed!\n", __func__, __LINE__);
								goto errorHandler;

						}
				 	
					}
					break;
			        }	
				break;
			}
	                case OP_PARAM_VALIDATE:
        	        {
                	    break; 
                	}
	        default:
	            break;
	}
	return IFX_CWMP_SUCCESS;

	errorHandler:
		
		return iRet;
			
}
 
