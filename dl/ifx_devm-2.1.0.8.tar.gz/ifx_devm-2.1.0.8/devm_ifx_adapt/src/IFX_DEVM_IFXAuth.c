/*
** =============================================================================
** FILE NAME   : IFX_Auth.c
** PROJECT     : TR69
** MODULES     : (InternetGateway) Device.X_AC9A96_LTQ.Auth.
** DATE        : 19-Jun-2006
** AUTHOR      : TR69 team
** DESCRIPTION : This object is RO. SetParameterValues or AddObject cannot be
**               performed on this object.
** REFERENCES  :  
** COPYRIGHT   : Copyright (c) 2006
**               Infineon Technologies AG
**               Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY     : 
** $Date        $Author          $Comment
** 30-Aug-2006  TR69 team        Creation         
** =============================================================================
*/
#include "IFX_DEVM_Global.h"
 
#include "IFX_DEVM_AdaptCommon.h"
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"

extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char *obj, modFunc pifx_module_func);

#define IFXAUTH_OBJ       FORMNAME("X_AC9A96_LTQ.Auth.")
#define IFXAUTH_DEPTH     4

/*******************************************************************************
* Function: IFX_AuthSetAttrInfo
* Desc: 
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: 
*******************************************************************************/
static int32
IFX_AuthSetAttrInfo(IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = ERR_CWMP_REQUEST_DENIED;
    return iRet;
}

/*******************************************************************************
* Function: IFX_AuthGetNotifyValue
* Desc: 
* Parameters: IN OperInfo *pxOI, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: 
*******************************************************************************/
static int32
IFX_AuthGetNotifyValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                 IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    return iRet;
}

/*******************************************************************************
* Function: IFX_AuthGetValue
* Desc: 
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_AuthGetValue(IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    TR69_AUTH xTR69Auth;

    memset(&xTR69Auth, 0, sizeof(xTR69Auth));
    iRet = ifx_get_tr69_auth(&xTR69Auth, 0);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] "
                    "ifx_get_tr69_auth() failed\n", __func__, __LINE__, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
    for(iI = 0; iI < iElements; iI++) {

		pxPV[iI].Value = IFX_CWMP_MALLOC(256);
              if(pxPV[iI].Value == NULL) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                                "Malloc failed\n", __func__, __LINE__);
                    iRet = ERR_OUT_OF_MEMORY;
                    goto errorHandler;
              }
		
        switch (pxPV[iI].iaOID[IFXAUTH_DEPTH - 1]) {
            case OID_IGD_XAC9A96LTQ_A_REALM:
                
                strcpy(pxPV[iI].Value, xTR69Auth.realm);
                break;
            case OID_IGD_XAC9A96LTQ_A_NONCE:
              
                strcpy(pxPV[iI].Value, xTR69Auth.nonce);
                break;
            case OID_IGD_XAC9A96LTQ_A_URI:
               
                strcpy(pxPV[iI].Value, xTR69Auth.uri);
                break;
            case OID_IGD_XAC9A96LTQ_A_ALGO:
               
                strcpy(pxPV[iI].Value, xTR69Auth.algo);
                break;
            case OID_IGD_XAC9A96LTQ_A_CNONCE:
               
                strcpy(pxPV[iI].Value, xTR69Auth.cnonce);
                break;
            case OID_IGD_XAC9A96LTQ_A_OPAQUE:
              
                strcpy(pxPV[iI].Value, xTR69Auth.opaque);
                break;
            case OID_IGD_XAC9A96LTQ_A_QOP:
                
                strcpy(pxPV[iI].Value, xTR69Auth.qop);
                break;
            case OID_IGD_XAC9A96LTQ_A_NC:
               
                strcpy(pxPV[iI].Value, xTR69Auth.nc);
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                            "Default case\n", __func__, __LINE__,
                            pxPV[iI].iaOID[IFXAUTH_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_AuthValidate
* Desc:
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_AuthValidate(IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;

     if(iCaller != ACC_ROOT) {
                    iRet = ERR_CWMP_INVAL_ARGS;
                    pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                }
    return iRet;
}

/*******************************************************************************
* Function: IFX_AuthModify
* Desc:
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_AuthModify(IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    TR69_AUTH xTR69Auth;

    memset(&xTR69Auth, 0, sizeof(xTR69Auth));
    iRet = ifx_get_tr69_auth(&xTR69Auth, 0);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] "
                    "ifx_get_tr69_auth() failed\n", __func__, __LINE__, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
 
    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[IFXAUTH_DEPTH - 1]) {
            case OID_IGD_XAC9A96LTQ_A_REALM:
                strcpy(xTR69Auth.realm, pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_A_NONCE:
                strcpy(xTR69Auth.nonce, pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_A_URI:
                strcpy(xTR69Auth.uri, pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_A_ALGO:
                strcpy(xTR69Auth.algo, pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_A_CNONCE:
                strcpy(xTR69Auth.cnonce, pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_A_OPAQUE:
                strcpy(xTR69Auth.opaque, pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_A_QOP:
                strcpy(xTR69Auth.qop, pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_A_NC:
                strcpy(xTR69Auth.nc, pxPV[iI].Value);
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! " "Default case\n", __func__,
                            __LINE__, pxPV[iI].iaOID[IFXAUTH_DEPTH - 1]);
                break;
        }
    }

    xTR69Auth.iid.config_owner = IFX_TR69;

    iRet = ifx_set_tr69_auth(IFX_OP_MOD, &xTR69Auth, 
                             IFX_F_MODIFY | IFX_F_DONT_WRITE_TO_FLASH |
                             IFX_F_DONT_CHECKPOINT);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] "
                    "ifx_set_tr69_auth() failed\n", __func__, __LINE__, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_Auth
* Desc: 
* Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
*             OUT void **ppRet, OUT int32 * piNumRetElem
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_Auth(IN OperInfo * pxOI, INOUT void *pParamStruct,
         IN int32 iElements, OUT void **ppRet, OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;
    uint32 iCnt = 0;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "%s: %s oper=%d maxElement=%d\n",
                __func__, xpParamVal[0].Name, pxOI->iSubOper, iElements);

    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                    iRet = IFX_AuthGetValue(pxOI->iCaller, xpParamVal,
                                            iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_GETVAL_NOTIFICATION:
                    iRet = IFX_AuthGetNotifyValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                    iRet = IFX_AuthValidate(pxOI->iCaller, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_SETVAL_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:
                    break;
                case OP_SETVAL_MODIFY:
                    iRet = IFX_AuthModify(pxOI->iCaller, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_SETVAL_COMMIT:
                    break;
                case OP_SETVAL_UNDO:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_DELETE:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_ACTIVATE:
                    break;
                case OP_SETVAL_ATTRINFO:
                    IFX_AuthSetAttrInfo(pxOI->iCaller, pParamStruct, iElements);
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_UPDATE_CHILDINFO_DEL:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            /*Vendor specific parameters should not be reported to ACS. It 
              should be available for internal updation */
            if(pxOI->iCaller == ACC_TR69)
            {
                /* Set the fault code to Error */
                for(iCnt = 0; iCnt < iElements; iCnt++)
                {
                    xpParamVal[iCnt].iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
                }
            }
            break;
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                        "Default case\n", __func__, __LINE__, pxOI->iOper);
            break;
        }
    }
errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_AuthInit
* Desc: Will initialize some of its data structures, register itself with DS
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_AuthInit()
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* TBD: Perform any AuthInit related initializations here */

    /* Register the IFX_AuthInit func ptr in the object model */
    iRet = ifx_ds_register_function(IFXAUTH_OBJ, IFX_Auth);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFXAUTH_OBJ);
        goto errorHandler;
    }

  errorHandler:
    return iRet;
}
