/* 
** =============================================================================
**   FILE NAME        : IFX_WanCommonInterfaceConfig.c
**   PROJECT          : TR69
**   MODULES         : WanCommonInterfaceConfig
**   DATE               : 21-06-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION   : This module handles ADD/DEL/GET/SET RPCs of 
**                      WanCommonInterfaceConfig. When controller calls this module it
**                      calls respective Platform/Object APIs to handle GET/SET 
**                      of WanCommonInterfaceConfig specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author        $Comment
**   28-04-06         TR69 team      Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
//#include <sys/socket.h>
//#include <netinet/in.h>
//#include <arpa/inet.h>

#include "IFX_DEVM_WANCommonIfaceCfg.h"
#include "IFX_DEVM_WANDSLIfaceCfg.h"
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
 
#include <fcntl.h>
#include <unistd.h>

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;

extern int32 adsl_get_rate(int32 type, unsigned long *rate,unsigned long *rate_remainder);

#define IFX_WAN_COMMON_INTF_CONFIG_OBJ "InternetGatewayDevice.WANDevice.1.WANCommonInterfaceConfig."
static uint32 uiEnableInternet=1;
extern Map_Value gaxEnable[];
/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/




/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/





/* 
** =============================================================================
**   Function Name    : IFX_WanCommonInterfaceConfigGetValue
**   Description        : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes                : 
**
** ============================================================================
*/
static int32 
IFX_WanCommonInterfaceConfigGetValue(IN OperInfo *pxOperInfo,INOUT ParamVal *pxGetParamVal,
                                IN uint32 iElements)
{
    /*GET PARAMETER VALUES
    **Get Object OID(skip parameter ID) from the first 
    **element in the array.Get Cpeid for this Object OID

    **Get the object from the system using a Platform API
    **with cpeid 
    
    **Do reverse mapping to convert system values into TR69
    **Values.After conversion stores the values in temp storage

    **While assigning the values as per request store the 
    **values in heap and assign the ptr to the struct
    **Return all the values 
    */


    
    //uint32 iCpeid=0,
    uint32 i=0;
    int32 iParamId=0;
    uint32 uiParamPos=0;
    //int32 iConType=0;
    int32 iRet=0;
    //uint32 uiCpeid;
    uint32 uiMode=IFX_CHK_VALUE_BASED;
    uint32 uiflags=IFX_F_GET_ANY;

    char8 sTmpBuff[65]={0};
#if defined(MIPSTARGET) && defined(CONFIG_PACKAGE_IFX_DSL_CPE_API)
    //unsigned long dsDataRate_remain=0, usDataRate_remain=0;
#endif
    //unsigned long dsDataRate=0, usDataRate=0;
    int32 ifd=0;
    char8 cAdsl_status[10]={0};
    uint32 uiphy_status=0;
    int32 uiNumOfEntries=0;
    WAN_CONN_CFG *paxWan_Conns=NULL;
    IFACE_STATS *pxIfStats=NULL;
    int32 iI=0;
    int32 iWanCount=0;
    int32 iTotalTxPkts=0;
    int32 iTotalRxPkts=0;
    int32 iTotalTxBytes=0;
    int32 iTotalRxBytes=0;
#ifdef CONFIG_FEATURE_ETH_WAN_SUPPORT
    struct ifx_phyport_info xPort;
#ifdef MIPSTARGET
    int nodeNum = 0;
#endif
#endif

    //Fill the parameters and pass it back
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
    DSL_LINE_PHY_PROPERTIES xDslphys;
    memset(&xDslphys,0x00,sizeof(xDslphys));    

    iRet = ifx_get_dsl_phy_properties(&xDslphys);
    if(iRet != IFX_SUCCESS)
        goto errorHandler;
    
#endif
#ifdef CONFIG_FEATURE_ETH_WAN_SUPPORT
    /*Memset the structs*/
    memset(&xPort, '\0', sizeof(xPort));
    #ifdef MIPSTARGET
    /* Get the values for the requested instance */
    if((pxGetParamVal->iaOID[2]) == WAN_DEVICE_MII0) //IGD.WD.2.
    {
        nodeNum = 1;
    }
    else if((pxGetParamVal->iaOID[2]) == WAN_DEVICE_MII1) //IGD.WD.3.
    {
        nodeNum = 0;
    }
    ifx_get_phyport_info(3, &xPort, nodeNum);//Only the port 3/GigE is used as wan port
    #endif
#endif
    iRet = ifx_get_all_wan_if_stats(&iWanCount, &pxIfStats, IFX_F_DEFAULT);

    if (iRet != IFX_SUCCESS)
    {
        iRet = ERR_CWMP_INTERNAL;
        return iRet;
    }

    for(iI=0; iI<iWanCount; iI++)
    {
            iTotalTxPkts += pxIfStats[iI].stats.tx_pkts;
            iTotalRxPkts += pxIfStats[iI].stats.rx_pkts;
            iTotalTxBytes += pxIfStats[iI].stats.tx_bytes;
            iTotalRxBytes += pxIfStats[iI].stats.rx_bytes;
    }
    IFX_CWMP_FREE(pxIfStats);
    //Get the WanIpConParamPos 
    uiParamPos = IFX_GetParamIdPos(pxGetParamVal->iaOID);

    for(i=0;i < iElements; i++)
    {
    
        iParamId = pxGetParamVal->iaOID[uiParamPos];
    
        // Malloc and assign the pointer to the Value attr of struct 
        pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
        if(pxGetParamVal->Value == NULL){
            iRet = ERR_OUT_OF_MEMORY; 
            goto errorHandler;
        }
        switch(iParamId)
        {

            // Convert the value - reverse mapping
            // Assign the correct value to the Value attr
            case OID_IGD_WAND_WANCIC_ENABLEDFORINTERNET:
                sprintf(sTmpBuff,"%d",uiEnableInternet);
                strcpy(pxGetParamVal->Value,sTmpBuff);
                //IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;
            case OID_IGD_WAND_WANCIC_WANACCESSTYPE:
                if(pxGetParamVal->iaOID[2] == WAN_DEVICE_ATM)
                    strcpy(pxGetParamVal->Value,"DSL");
                else
                    strcpy(pxGetParamVal->Value,"Ethernet");

                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;
            case OID_IGD_WAND_WANCIC_LAYER1UPSTREAMMAXBITRATE:
#if defined(MIPSTARGET) && defined(CONFIG_PACKAGE_IFX_DSL_CPE_API)
                //adsl_get_rate(0,&usDataRate,&usDataRate_remain);
                sprintf(sTmpBuff,"%d",xDslphys.usCurrRate);
#endif
                             //sprintf(sTmpBuff,"%lu",usDataRate);
                //strcpy(pxGetParamVal->Value,sTmpBuff);
                
                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;
            case OID_IGD_WAND_WANCIC_LAYER1DOWNSTREAMMAXBITRATE:
#if defined(MIPSTARGET) && defined(CONFIG_PACKAGE_IFX_DSL_CPE_API)
                //adsl_get_rate(1,&dsDataRate,&dsDataRate_remain);
                sprintf(sTmpBuff,"%d",xDslphys.dsCurrRate);
#endif
                //sprintf(sTmpBuff,"%lu",dsDataRate);
                //strcpy(pxGetParamVal->Value,sTmpBuff);
                strcpy(pxGetParamVal->Value,sTmpBuff);

                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;
            case OID_IGD_WAND_WANCIC_PHYSICALLINKSTATUS:
                if((pxGetParamVal->iaOID[2]) == WAN_DEVICE_ATM) //IGD.WD.1.
                {
                    ifd = open("/tmp/adsl_status", O_RDONLY);
                    if(ifd >= 0)
                    {
                        read(ifd, cAdsl_status, sizeof(cAdsl_status));
                        close(ifd);
                        uiphy_status = atoi(cAdsl_status);
                    }  
                    if(uiphy_status == 7)
                       strcpy(pxGetParamVal->Value,"Up");
                    else
                        strcpy(pxGetParamVal->Value,"Down");
                }
                #ifdef CONFIG_FEATURE_ETH_WAN_SUPPORT
                else if( ((pxGetParamVal->iaOID[2]) == WAN_DEVICE_MII0) || ((pxGetParamVal->iaOID[2]) == WAN_DEVICE_MII1) ) 
                {
                    //IGD.WD.2/3.
                    if(xPort.link)
                        strcpy(pxGetParamVal->Value, "Up");
                    else
                        strcpy(pxGetParamVal->Value, "Down");
                }
		#endif
                else
                {
                    strcpy(pxGetParamVal->Value, "Down");
                }
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;
            case OID_IGD_WAND_WANCIC_WANACCESSPROVIDER:
                //sprintf(sTmpBuff,"%l",usDataRate);
                strcpy(pxGetParamVal->Value,"IFX_ISP");
                break;
            case OID_IGD_WAND_WANCIC_TOTALBYTESSENT:
                        sprintf(pxGetParamVal->Value,"%d",iTotalTxBytes);
                break;
            case OID_IGD_WAND_WANCIC_TOTALBYTESRECEIVED:
                        sprintf(pxGetParamVal->Value,"%d",iTotalRxBytes);
                break;
            case OID_IGD_WAND_WANCIC_TOTALPACKETSSENT:
                        sprintf(pxGetParamVal->Value,"%d",iTotalTxPkts);
                break;
            case OID_IGD_WAND_WANCIC_TOTALPACKETSRECEIVED:
                        sprintf(pxGetParamVal->Value,"%d",iTotalRxPkts);
                break;
            case OID_IGD_WAND_WANCIC_MAXIMUMACTIVECONNECTIONS:
                strcpy(pxGetParamVal->Value,"14");
                break;
            case OID_IGD_WAND_WANCIC_NUMBEROFACTIVECONNECTIONS:
                ifx_get_all_wan(&uiNumOfEntries, &paxWan_Conns,uiflags);
                IFIN_CWMP_FREE(paxWan_Conns);

		if(uiNumOfEntries == 0)
                	sprintf(sTmpBuff,"%d",uiNumOfEntries);
		else
                	sprintf(sTmpBuff,"%d",(uiNumOfEntries-1));

                strcpy(pxGetParamVal->Value,sTmpBuff);
                IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "Invalid param id %d!\n", iParamId);
                pxGetParamVal->iFaultCode=ERR_INVAL_PARAMETER_NAME;
            break;
        }

            ++pxGetParamVal;
    }

        //IFX_CWMP_FREE(pxWanConn);
        return IFX_CWMP_SUCCESS;

        errorHandler:
            //IFX_CWMP_FREE(pxWanConn);
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed ParamId=%d!\n", __func__, __LINE__,iParamId);
            return iRet;

}


/* 
** =============================================================================
**   Function Name    : IFX_WanCommonInterfaceConfigSetValue
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

static int32
IFX_WanCommonInterfaceConfigSetValue(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
                            IN int32 iElements)
{

    //uint32 uiCpeid=0;
    int32 iRet=IFX_CWMP_SUCCESS;
    //uint32 uiflags=0,
    uint32 i=0;
    uint32 uiParamPos=0;
    //GATEWAY_INFO xgateway_info;
    ParamVal *pxTmpPramVal=NULL;
    //uint32 uioper=0;

    uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);
    
    pxTmpPramVal = paxParamVal;
    
    for (i=0; i < iElements; i++) 
    {

        switch(pxTmpPramVal->iaOID[uiParamPos])
        {

            case OID_IGD_WAND_WANCIC_ENABLEDFORINTERNET:
                 /* Check if the string fits in the buffer */
            if(IFX_FwdMappingValues(gaxEnable,4,
                            (void *)(paxParamVal->Value),
                            (void *)&(uiEnableInternet)) !=IFIN_CWMP_SUCCESS)
                    {
                        iRet=ERR_CWMP_INVAL_PARAM_VAL;
                        goto errorHandler;
                    }
                    break;

        }

        pxTmpPramVal++;
        
    }

    return IFX_CWMP_SUCCESS;

    errorHandler:
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "[%s:%s:%d] [%d] WanCommonInterfaceConfig SetParamValues failed "
                                    ,__FILE__, __func__, __LINE__, iRet);
        return iRet;
    

}

/* 
** =============================================================================
**   Function Name    : IFX_WanCommonInterfaceConfigAddObj
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanCommonInterfaceConfigAddObj(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
                            IN int32 iElements)
{

return IFX_CWMP_FAILURE;

}


/* 
** =============================================================================
**   Function Name    : IFX_WanCommonInterfaceConfigSetCommit
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanCommonInterfaceConfigSetCommit()
{
    return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanCommonInterfaceConfigSetUndo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanCommonInterfaceConfigSetUndo()
{
    return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanCommonInterfaceConfigSetDelete
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_WanCommonInterfaceConfigSetDelete(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
                            IN int32 iElements, OUT void **ppxParamStructRet,
                                                   OUT int32 * piNumRetElem)
{
    return IFX_CWMP_FAILURE;
}

/* 
** =============================================================================
**   Function Name    : IFX_WanCommonInterfaceConfigSetFree
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_WanCommonInterfaceConfigSetFree()
{
    return IFX_CWMP_SUCCESS;
}


/* 
** =============================================================================
**   Function Name    : IFX_WanCommonInterfaceConfigSetAttr
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

static int32
IFX_WanCommonInterfaceConfigSetAttr(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
                            IN int32 iElements)
{
    uint32 iRet=IFX_CWMP_SUCCESS,i=0;
    OperInfo xOpInfo;
    
    xOpInfo.iCaller = pxOpInfo->iCaller;
    xOpInfo.iOper= OP_GETVAL;
    xOpInfo.iSubOper= OP_GETVAL_NORMAL;
    
    iRet = IFX_WanCommonInterfaceConfigGetValue(&xOpInfo,pxParamVal, iElements);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorFreeHandler;
    
    iRet = IFX_SetAttributesInfo(pxOpInfo,pxParamVal, iElements);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorFreeHandler;

    errorFreeHandler:
        for(i=0; i < iElements; i++)
        IFX_CWMP_FREE(pxParamVal[i].Value);
        
                if (iRet)
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed!\n", __func__, __LINE__);
        return iRet;
}



/* 
** =============================================================================
**   Function Name    : IFX_WanCommonInterfaceConfig_Init
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_WanCommonInterfaceConfig_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    
    /* Register the WanCommonInterfaceConfig module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_WAN_COMMON_INTF_CONFIG_OBJ, IFX_WanCommonInterfaceConfig);
    
    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "Unable to Register %s with Object Model\n",
                     IFX_WAN_COMMON_INTF_CONFIG_OBJ);
        goto errorHandler;
    }


    errorHandler:
            return iRet;
}

/*********************************************************************************
*  Function Name    :  IFX_WanCommonInterfaceConfig   
*  Description    :  This function handles all the sub-states inside
                      a GET/SET operation.If it is a GET it allocates the 
               array(Name,Value pairs) and retruns the values.
               If it is a SET controller allocates the array and
               passes the values to this function.It calls 
               respective internal functions which in turn calls 
               respective Platform APIs.
                                                                                                 
*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
            IN          OperInfo       pxOper;       Operation,
                                 Sub-operation,Owner
            INOUT       void *         pParamStruct; Struct which has 
                                       Name,Value,etc
            IN          int32           iElements;    No. of Elements
            OUT            void *           ppParamRet;   same as ParamStruc
            OUT         int32 *        piNumRetElem; No. of elements                                         
*  Return Value        : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes               :
***********************************************************************************/
int32
IFX_WanCommonInterfaceConfig(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                IN int32 iElements, OUT void **ppaxParamArrRet, OUT int32 *piNumRetElem)
{
     
   //It calls the respective internal functions which handles resp. sub-operation
   
   //Set-Operation  
   //controller should pass the entire array during all the SET-sub_operations
   //It should handles only single get/set of instance at any point of time
   //It does not handle partial path
   //It won't handle multiple instances of the same object/module
   //at any point of time.

    
   int32 iRet = 0;
   ParamVal *paxParamArr = (ParamVal *)paxParameterArr;

    switch (pxOperInfo->iOper) 
    {
        //Get the object values
        case OP_GETVAL:
                if((iRet = IFX_WanCommonInterfaceConfigGetValue(pxOperInfo, paxParamArr,
                                    iElements)) != IFX_CWMP_SUCCESS) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
              goto errorHandler;
                }
                break;
            case OP_SETVAL:
        {

            //Set the obj values
            switch (pxOperInfo->iSubOper) 
            {
                       case OP_SETVAL_VALIDATE:
                               
                            break;
                        case OP_SETVAL_ADD:
                            
                            if((iRet= IFX_WanCommonInterfaceConfigAddObj(pxOperInfo,paxParamArr,
                                        iElements))!=IFX_CWMP_SUCCESS)
                                {
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d OP_SETVAL_ADD failed!\n", __func__, __LINE__);
                                     goto errorHandler;
                                }
                            break;
                      case OP_SETVAL_CHK_MODIFY_DEP:
                      break;
                      
                case OP_SETVAL_MODIFY:
                            if((iRet = IFX_WanCommonInterfaceConfigSetValue(pxOperInfo,paxParamArr,
                                        iElements)) != IFX_CWMP_SUCCESS) {
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_VALUE failed!\n", __func__, __LINE__);
                                goto errorHandler;
                            }
                            break;
                            
                        case OP_SETVAL_COMMIT:
                            if((iRet = IFX_WanCommonInterfaceConfigSetCommit(pxOperInfo,paxParamArr,
                                        iElements)) != IFX_CWMP_SUCCESS) {
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_COMMIT failed!\n", __func__, __LINE__);
                                goto errorHandler;
                            }
                            break;
                        case OP_SETVAL_UNDO:
                            if((iRet =IFX_WanCommonInterfaceConfigSetUndo(pxOperInfo, paxParamArr,
                                        iElements)) != IFX_CWMP_SUCCESS) {
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_UNDO failed!\n", __func__, __LINE__);
                                goto errorHandler;
                            }
                            break;
                case OP_SETVAL_CHK_DEL_DEP:
                                   // *ppaxParamArrRet = (ParamVal *)IFX_CWMP_MALLOC(sizeof(ParamVal));
                                   // memcpy(*ppaxParamArrRet, paxParameterArr, sizeof(ParamVal));
                                    //*piNumRetElem = 1;
                                    break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                      case OP_SETVAL_DELETE:
                        if((iRet= IFX_WanCommonInterfaceConfigSetDelete(pxOperInfo, paxParamArr,
                                        iElements, ppaxParamArrRet,
                                        piNumRetElem))!= IFX_CWMP_SUCCESS) 
                        {
                            
                                switch(pxOperInfo->iSubOper)
                            {    
                                  case OP_SETVAL_CHK_DEL_DEP:
                                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
                                            goto errorHandler;
                                case OP_SETVAL_CHK_DEL_ALLOWED:
                                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
                                            goto errorHandler;
                                case OP_SETVAL_DELETE:
                                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
                                            goto errorHandler;
                            }
                     }
                            break;
                        case OP_SETVAL_FREE:
                            IFX_WanCommonInterfaceConfigSetFree(pxOperInfo);
                    break;

                 case OP_SETVAL_ATTRINFO:
                     if((iRet =IFX_WanCommonInterfaceConfigSetAttr(pxOperInfo, paxParamArr,
                                        iElements)) != IFX_CWMP_SUCCESS) {
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d OP_SETVAL_ATTRINFO failed!\n", __func__, __LINE__);
                                goto errorHandler;
                            }
                            break;
                            
                        default:
                            break;
            }
           break; 
            }
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
            default:
                break;
    }
    return IFX_CWMP_SUCCESS;

    errorHandler:
        return IFX_CWMP_FAILURE;
            
}
 
