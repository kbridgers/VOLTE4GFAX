/* 
** =============================================================================
**   FILE NAME        : IFX_QMClassify.c
**   PROJECT          : TR69
**   MODULES          : QueueManagement.Classification
**   DATE             : 12-01-2009
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This is the Classification Module. It is required by the 
**                      controller module of TR69 stack to GET/SET/ADD/DELETE
**                      Classification specific information.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author                         $Comment
**   15-01-2008       TR69 team                       Initial Version
**
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_QMClassify.h"
  // Required for STATIC
 
#include "IFX_DEVM_OID.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
 
#include "IFX_DEVM_DS.h"

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFX_QUEUE_MGMT_CLASSIFY_OBJ    FORMNAME("QueueManagement.Classification")
/* TBD: Temporary Placeholders, since we do not get this from Platform include
   header files */

/* IPQOS Tags */
#define TAG_IPQOS_CAPABILITY                      "qos_capability"
#define TAG_IPQOS_QM                              "qos_queuemgmt"
#define TAG_IPQOS_CLASSIFY                        "qos_class"
#define TAG_IPQOS_QUEUE                            "qos_queue"
#define PREFIX_IPQOS_CLASSIFY                      "qcl"
#define PREFIX_IPQOS_QUEUE                         "qq"

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

STATIC int32
GetParamOffset(IN int32 *paiOID);
STATIC int32
GetVal(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
       IN int32 iElements);
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
AddObj(IN OperInfo *pxOI,INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
SetDelete(IN OperInfo *pxOI,INOUT ParamVal *pxParamVal,
          IN int32 iElements, OUT void **ppxParamStructRet,
          OUT int32 * piNumRetElem);
STATIC int32
ParamValidate(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);
/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : GetParamOffset
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

STATIC int32
GetParamOffset(IN int32 *paiOID)
{
    int32 iCnt;

    for (iCnt = 0; paiOID[iCnt] != 0; iCnt++);

    return (iCnt - 1);
}


/*
** =============================================================================
**   Function Name    : ParamValidate
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/

STATIC int32
ParamValidate(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
   int32   iRet  = IFX_CWMP_SUCCESS;
   uint32 iCpeid = 0;
   int32 count = 0, i = 0;
   static IFX_MAPI_QoS_Classifier *qos_class = NULL; 
   IFX_MAPI_QoS_Interface_Type qIfType = 0;

   iRet = IFX_GetCpeId(pxParamVal->iaOID,&iCpeid);
   if(iRet != IFX_CWMP_SUCCESS)
        goto cleanup;

   qIfType = ifx_mapi_get_active_qos_iface();

   if(qos_class == NULL) {
       iRet = ifx_mapi_get_all_qos_classifier_if_specific(qIfType, (uint32 *)&count, &qos_class, IFX_F_DEFAULT);   
       /* Check for error */
       if (iRet != IFX_SUCCESS)
       {

           iRet = ERR_CWMP_INTERNAL;
           IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_queue failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
            goto cleanup;
       }
   }

   iRet = ERR_CWMP_PARAMVAL_INVALID;
   for( i = 0; i < count; i++) {
      if( qos_class[i].iid.cpeId.Id == iCpeid ) {
         iRet  = IFX_CWMP_SUCCESS; 
         break;
      }
   }

   IFX_MEM_FREE(qos_class); 
   cleanup:
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetVal(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
       IN int32 iElements)
{
    int32   iRet  = IFX_CWMP_SUCCESS;
    int32   iRtn  = IFX_SUCCESS;
    int32   iCnt  = 0;
    IFX_MAPI_QoS_Classifier xQMC;
    int32   iParamOffset;
    uint32 iCpeid = 0;

    // Get Cpeid from object ID
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    	goto cleanup;

    memset(&xQMC, 0, sizeof(IFX_MAPI_QoS_Classifier));

    /* Fill the cpeid in the structure to get the required instance */
    xQMC.iid.cpeId.Id = iCpeid;

    /* Get all the IFX_MAPI_QoS_Classifier parameters using Protocol API */
    iRtn = ifx_mapi_get_qos_classifier(&xQMC, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_classifier failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        /* TBD: Currently keeping size as 257 bytes, since max param size is string(256) */
        (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(257);

        /* Check for error */
        if (!((pxParamVal[iCnt]).Value))
        {
            iRet = ERR_OUT_OF_MEMORY;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Allocation Failure\n",
                         __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_QM_C_CLASSIFICATIONENABLE:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.enable);
                break;
            case OID_IGD_QM_C_CLASSIFICATIONSTATUS:
                /* Copy the value to allocated area */
                if (xQMC.status == IPQOS_STATUS_DISABLED)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Disabled");
                }
                else if (xQMC.status == IPQOS_STATUS_ENABLED)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Enabled");
                }
                else
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Error");
                }
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_QM_C_CLASSIFICATIONORDER:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%u", xQMC.order);
                break;
            case OID_IGD_QM_C_CLASSINTERFACE:
                /* Copy the value to allocated area */
                //TBD: Needs to be handled
                if (xQMC.classIf == IFX_MAPI_QoS_LAN_ALL)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "LAN");
                }
                else if (xQMC.classIf == IFX_MAPI_QoS_LOCAL)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "LOCAL");
                }
                else if (xQMC.classIf == IFX_MAPI_QoS_ALL)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "LOCAL+LAN");
                }
                else if (xQMC.classIf == IFX_MAPI_QoS_WAN)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "WAN");
                }
                else if (xQMC.classIf == IFX_MAPI_QoS_WAN_ALL)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "LOCAL+WAN");
                }
                else
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "");
                }
                break;

                //sprintf(pxParamVal[iCnt].Value, "%d", xQMC.classIf);
                break;
            case OID_IGD_QM_C_DESTIP:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%s", xQMC.dstIP.ip);
                break;
            case OID_IGD_QM_C_DESTMASK:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%s", xQMC.dstIP.mask);
                break;
            case OID_IGD_QM_C_DESTIPEXCLUDE:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.dstIPExcl);
                break;
            case OID_IGD_QM_C_SOURCEIP:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%s", xQMC.srcIP.ip);
                break;
            case OID_IGD_QM_C_SOURCEMASK:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%s", xQMC.srcIP.mask);
                break;
            case OID_IGD_QM_C_SOURCEIPEXCLUDE:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.srcIPExcl);
                break;
            case OID_IGD_QM_C_PROTOCOL:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.protoNum);
                break;
            case OID_IGD_QM_C_PROTOCOLEXCLUDE:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.protoExcl);
                break;
            case OID_IGD_QM_C_DESTPORT:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.dstPortRange.start_port);
                break;
            case OID_IGD_QM_C_DESTPORTRANGEMAX:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.dstPortRange.end_port);
                break;
            case OID_IGD_QM_C_DESTPORTEXCLUDE:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.dstPortExcl);
                break;
            case OID_IGD_QM_C_SOURCEPORT:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.srcPortRange.start_port);
                break;
            case OID_IGD_QM_C_SOURCEPORTRANGEMAX:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.srcPortRange.end_port);
                break;
            case OID_IGD_QM_C_SOURCEPORTEXCLUDE:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.srcPortExcl);
                break;
            case OID_IGD_QM_C_SOURCEMACADDRESS:
                /* Copy the value to allocated area */
                //TBD: Assuming the MAC address is NULL terminated and has : separated
                sprintf(pxParamVal[iCnt].Value, "%s", xQMC.srcMac);
                break;
            case OID_IGD_QM_C_SOURCEMACEXCLUDE:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.srcMacExcl);
                break;
            case OID_IGD_QM_C_DESTMACADDRESS:
                /* Copy the value to allocated area */
                //TBD: Assuming the MAC address is NULL terminated and has : separated
                sprintf(pxParamVal[iCnt].Value, "%s", xQMC.dstMac);
                break;
            case OID_IGD_QM_C_DESTMACEXCLUDE:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.dstMacExcl);
                break;
            case OID_IGD_QM_C_DSCPCHECK:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.dscpCheck);
                break;
            case OID_IGD_QM_C_DSCPEXCLUDE:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.dscpExcl);
                break;
            case OID_IGD_QM_C_DSCPMARK:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.dscpMark);
                break;
            case OID_IGD_QM_C_ETHERNETPRIORITYCHECK:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.pBitsCheck);
                break;
            case OID_IGD_QM_C_ETHERNETPRIORITYEXCLUDE:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.pBitsExcl);
                break;
            case OID_IGD_QM_C_ETHERNETPRIORITYMARK:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.pBitsMark);
                break;
            case OID_IGD_QM_C_VLANIDCHECK:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.vlanCheck);
                break;
            case OID_IGD_QM_C_VLANIDEXCLUDE:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.vlanExcl);
                break;
            case OID_IGD_QM_C_FORWARDINGPOLICY:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%u", xQMC.fwPolicy);
                break;
            case OID_IGD_QM_C_TRAFFICCLASS:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.trafficClassId);
                break;
            case OID_IGD_QM_C_CLASSPOLICER:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMC.policerId);
                break;
            case OID_IGD_QM_C_CLASSQUEUE:
                if (xQMC.qId != -1)
                {
                    /* The value is CPE-Id, so now we get the TR69ID and extract the
                       instance number */
                    IFX_Id xIfxId;
                    char *ptr=NULL;
                    memset(&xIfxId, 0, sizeof(IFX_Id));
                    strcpy(xIfxId.xCpeId.sSectionTag,TAG_IPQOS_QUEUE);
                    xIfxId.xCpeId.uiId = (uint32)(xQMC.qId);
                    if (IFX_GetTr69IdFromCpeId(&xIfxId) != IFX_CWMP_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] No TR69Id For secname %s and cpeid %d\n",
                            __FILE__, __func__, __LINE__,
                            xIfxId.xCpeId.sSectionTag, xIfxId.xCpeId.uiId);
                        iRet = ERR_CWMP_INTERNAL;
                        goto cleanup;
                    }
                    /* Extract the Queue Instance Number and Copy to allocated area */
                    xIfxId.sTr69Id[strlen(xIfxId.sTr69Id)-1] = '\0';
                    ptr=strrchr(xIfxId.sTr69Id,'.');
                    if (!ptr)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] No TR69Id For secname %s and cpeid %d\n",
                            __FILE__, __func__, __LINE__,
                            xIfxId.xCpeId.sSectionTag, xIfxId.xCpeId.uiId);
                        iRet = ERR_CWMP_INTERNAL;
                        goto cleanup;
                    }
                    sprintf(pxParamVal[iCnt].Value, "%d", atoi(ptr+1));
                }
                else
                {
                    /* Copy the value to allocated area */
                    sprintf(pxParamVal[iCnt].Value, "%d", xQMC.qId);
                }

                break;
            default:
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
                goto cleanup;
        }
    }

cleanup:
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : Modify
**
**   Description      : This function modifies the values of parameters in 
**                      Classification object. It calls respective Management API  
**                      for the same. It performs modification only if parameter 
**                      has Write permission. In certain cases it also performs 
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32       iRet       = IFX_CWMP_SUCCESS;
    int32       iRtn       = IFX_SUCCESS;
    uint32      iCpeid     = 0;
    int32       iCnt       = 0, iQcnt = 0;
    IFX_MAPI_QoS_Classifier xQMC;
    int32       iParamOffset;
    char8       *psTmpVal;
    uint32      uiFlags;
    uint32 uiInstanceCount = 0;
    char8       sCpeId[20]; //Max size of int
    int32 dscpVals[] = {-1,0,14,12,10,8,22,20,18,16,30,28,26,24,38,36,34,32,46,40,48,56}, itmp=0;

    IFX_MAPI_QoS_Queue *qos_queue = NULL; 
    IFX_MAPI_QoS_Interface_Type qIfType;

    // Get Cpeid from object ID
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    	goto cleanup;

    memset(&xQMC, 0, sizeof(IFX_MAPI_QoS_Classifier));

    /* Fill the cpeid in the structure to get the required instance */
    xQMC.iid.cpeId.Id = iCpeid;

    /* Get all the IFX_MAPI_QoS_Classifier parameters using Protocol API */
    iRtn = ifx_mapi_get_qos_classifier(&xQMC, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_classifier failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }


    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_QM_C_CLASSIFICATIONENABLE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMC.enable = TRUE;
                }
                else
                {
                    xQMC.enable = FALSE;
                }
                break;
            case OID_IGD_QM_C_CLASSIFICATIONORDER:
                /* TBD: Verify. Here if the ACS modifies the order to a value greater than the no of entries,
                    ddxQMC.qId = atoi(psTmpVal);
                   then we place the entry at the end */
                uiInstanceCount = 0;
                ifx_get_sec_instance_count(TAG_IPQOS_CLASSIFY, &uiInstanceCount);
                if (atoi(psTmpVal) > uiInstanceCount)
                {
                    xQMC.order = uiInstanceCount;
                }
                else
                {
                    xQMC.order = atoi(psTmpVal);
                }
                break;
            case OID_IGD_QM_C_CLASSINTERFACE:
                //TBD: Needs to be handled
		if(psTmpVal!=NULL)
	       {
                if (!psTmpVal)
                {
                    xQMC.classIf = IFX_MAPI_QoS_ALL;
                }
                if (!strcmp(psTmpVal, "LAN"))
                {
                    xQMC.classIf = IFX_MAPI_QoS_LAN_ALL;
                }
                if (!strcmp(psTmpVal, "LOCAL"))
                {
                    xQMC.classIf = IFX_MAPI_QoS_LOCAL;
                }
                if (!strcmp(psTmpVal, "LOCAL+LAN"))
                {
                    xQMC.classIf = IFX_MAPI_QoS_ALL;
                }
                if (!strcmp(psTmpVal, "WAN"))
                {
                    xQMC.classIf = IFX_MAPI_QoS_WAN;
                }
                if (!strcmp(psTmpVal, "LOCAL+WAN"))
                {
                    xQMC.classIf = IFX_MAPI_QoS_WAN_ALL;
                }
	      }
                break;
            case OID_IGD_QM_C_DESTIP:
                if (psTmpVal)
                    strcpy(xQMC.dstIP.ip,psTmpVal);
                else
                    strcpy(xQMC.dstIP.ip,"");
                break;
            case OID_IGD_QM_C_DESTMASK:
                if (psTmpVal)
                    strcpy(xQMC.dstIP.mask,psTmpVal);
                else
                    strcpy(xQMC.dstIP.mask,"");
                break;
            case OID_IGD_QM_C_DESTIPEXCLUDE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMC.dstIPExcl = TRUE;
                }
                else
                {
                    xQMC.dstIPExcl = FALSE;
                }
                break;
            case OID_IGD_QM_C_SOURCEIP:
                if (psTmpVal)
                    strcpy(xQMC.srcIP.ip,psTmpVal);
                else
                    strcpy(xQMC.srcIP.ip,"");
                break;
            case OID_IGD_QM_C_SOURCEMASK:
                if (psTmpVal)
                    strcpy(xQMC.srcIP.mask,psTmpVal);
                else
                    strcpy(xQMC.srcIP.mask,"");
                break;
            case OID_IGD_QM_C_SOURCEIPEXCLUDE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMC.srcIPExcl = TRUE;
                }
                else
                {
                    xQMC.srcIPExcl = FALSE;
                }
                break;
            case OID_IGD_QM_C_PROTOCOL:
                xQMC.protoNum = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_PROTOCOLEXCLUDE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMC.protoExcl = TRUE;
                }
                else
                {
                    xQMC.protoExcl = FALSE;
                }
                break;
            case OID_IGD_QM_C_DESTPORT:
                xQMC.dstPortRange.start_port = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_DESTPORTRANGEMAX:
                xQMC.dstPortRange.end_port = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_DESTPORTEXCLUDE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMC.dstPortExcl = TRUE;
                }
                else
                {
                    xQMC.dstPortExcl = FALSE;
                }
                break;
            case OID_IGD_QM_C_SOURCEPORT:
                xQMC.srcPortRange.start_port = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_SOURCEPORTRANGEMAX:
                xQMC.srcPortRange.end_port = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_SOURCEPORTEXCLUDE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMC.srcPortExcl = TRUE;
                }
                else
                {
                    xQMC.srcPortExcl = FALSE;
                }
                break;
            case OID_IGD_QM_C_SOURCEMACADDRESS:
                if (psTmpVal)
                    strcpy(xQMC.srcMac,psTmpVal);
                else
                    strcpy(xQMC.srcMac,"");
                break;
            case OID_IGD_QM_C_SOURCEMACEXCLUDE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMC.srcMacExcl = TRUE;
                }
                else
                {
                    xQMC.srcMacExcl = FALSE;
                }
                break;
            case OID_IGD_QM_C_DESTMACADDRESS:
                if (psTmpVal)
                    strcpy(xQMC.dstMac,psTmpVal);
                else
                    strcpy(xQMC.dstMac,"");
                break;
            case OID_IGD_QM_C_DESTMACEXCLUDE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMC.dstMacExcl = TRUE;
                }
                else
                {
                    xQMC.dstMacExcl = FALSE;
                }
                break;
            case OID_IGD_QM_C_DSCPCHECK:
                //TBD: What is the formula for user
                xQMC.dscpCheck = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_DSCPEXCLUDE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMC.dscpExcl = TRUE;
                }
                else
                {
                    xQMC.dscpExcl = FALSE;
                }
                break;
            case OID_IGD_QM_C_DSCPMARK:
                //TBD: What is the formula for user
                xQMC.dscpMark = atoi(psTmpVal);
		for(itmp=(sizeof(dscpVals)/4)-1;itmp>=0;itmp--) {
                    if(xQMC.dscpMark == dscpVals[itmp])
                        break;
                }
                if(itmp == -1) {
                     (  pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        iRet = ERR_CWMP_INVAL_ARGS;

                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] invalid DSCP Value \n",
                            __FILE__, __func__, __LINE__);
                        goto cleanup;
                }
                break;
            case OID_IGD_QM_C_ETHERNETPRIORITYCHECK:
                //TBD: What is the formula for user
                xQMC.pBitsCheck = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_ETHERNETPRIORITYEXCLUDE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMC.pBitsExcl = TRUE;
                }
                else
                {
                    xQMC.pBitsExcl = FALSE;
                }
                break;
            case OID_IGD_QM_C_ETHERNETPRIORITYMARK:
                //TBD: What is the formula for user
                xQMC.pBitsMark = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_VLANIDCHECK:
                //TBD: What is the formula for user
                xQMC.vlanCheck = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_VLANIDEXCLUDE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMC.vlanExcl = TRUE;
                }
                else
                {
                    xQMC.vlanExcl = FALSE;
                }
                break;
            case OID_IGD_QM_C_FORWARDINGPOLICY:
                xQMC.fwPolicy = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_TRAFFICCLASS:
                xQMC.trafficClassId = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_CLASSPOLICER:
                xQMC.policerId = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_CLASSQUEUE:
                if (atoi(psTmpVal) == -1)
                {
		(	pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        iRet = ERR_CWMP_INVAL_ARGS;
                        
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Qid -1 is not supported \n",
                            __FILE__, __func__, __LINE__);
			goto cleanup;	
                }
                else
                {
                    /* TR69 Instance number is specified. We need to get CPE-ID */
                    /* Construct TR69 Id from instance number */
                    char8 sTr69Id[IFX_MAX_TR69_ID_LEN]={0};
                    uint32 uiNumCpeId;
                    IFX_CpeId *pxCpeIdArray = NULL;
                    int32 iLoopCntr=0;
                    sprintf(sTr69Id,"%d.%d.%d.%d.",OID_IGD,OID_IGD_QM,
                            OID_IGD_QM_Q,atoi(psTmpVal));
                    /* Get CPE ID From TR69 ID */
                    if (IFX_GetCpeIdFromTr69Id(sTr69Id, &uiNumCpeId, &pxCpeIdArray) != IFX_CWMP_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] No cpeid for tr69id %s\n",
                            __FILE__, __func__, __LINE__, sTr69Id);
                        (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        iRet = ERR_CWMP_INVAL_ARGS;
                        goto cleanup;
                    }
                    /* Get the respective CPE ID from matching section */
                    for (iLoopCntr=0; iLoopCntr<uiNumCpeId; iLoopCntr++)
                    {
                        if (!strcmp(pxCpeIdArray[iLoopCntr].sSectionTag, TAG_IPQOS_QUEUE))
                        {
                            xQMC.qId = pxCpeIdArray[iLoopCntr].uiId;
                            IFX_CWMP_FREE(pxCpeIdArray);
                            break;
                        }
                    }
                    if (iLoopCntr == uiNumCpeId)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] No cpeid for tr69id %s with section as %s\n",
                            __FILE__, __func__, __LINE__, sTr69Id, TAG_IPQOS_QUEUE);
                        IFX_CWMP_FREE(pxCpeIdArray);
                        (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        iRet = ERR_CWMP_INVAL_ARGS;
                        goto cleanup;
                    }
                }
                break;
            case OID_IGD_QM_C_CLASSIFICATIONSTATUS:
                (pxParamVal[iCnt]).iFaultCode = ERR_NON_WRITABLE;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Cannot modify the parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }


    /********** Perform Validation that is based on values of other params or objects ******/
    /* Port Range Check */
    //TBD: Need to fill the fault code at exact location
    if (((xQMC.srcPortRange.end_port != -1 ) && ((xQMC.srcPortRange.end_port) < (xQMC.srcPortRange.start_port))) ||
        ((xQMC.dstPortRange.end_port != -1) && (xQMC.dstPortRange.end_port) < (xQMC.dstPortRange.start_port)))

    {
        for (iCnt = 0; iCnt < iElements; iCnt++)
            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
        iRet = ERR_CWMP_INVAL_ARGS;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] End Port is less than Start Port\n",
                    __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

    if (((xQMC.srcPortRange.start_port != -1 ) || (xQMC.srcPortRange.end_port != -1 ) ||
        (xQMC.dstPortRange.start_port != -1 ) || (xQMC.dstPortRange.end_port != -1 )) &&
        ((xQMC.protoNum != 6) && (xQMC.protoNum != 17)))
    {
        for (iCnt = 0; iCnt < iElements; iCnt++)
            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
        iRet = ERR_CWMP_INVAL_ARGS;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Port should always be specified with a valid protocol\n",
                    __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* check whether the queueid specified is on the active interface */
    qIfType = ifx_mapi_get_active_qos_iface();
    
    if(ifx_mapi_get_all_qos_queue_if_specific( qIfType,(uint32 *)&iQcnt, &qos_queue, IFX_F_DEFAULT) != IFX_SUCCESS) {
          IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] Failed to display configured queues for interface %d", __FUNCTION__, __LINE__, qIfType);
          goto cleanup;
    }
    
    for (iCnt = 0; iCnt < iQcnt; iCnt++) {
        if(qos_queue[iCnt].iid.cpeId.Id == xQMC.qId) 
          break;
    }    

    if(iCnt == iQcnt) {
        for (iCnt = 0; iCnt < iElements; iCnt++)
            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
        iRet = ERR_CWMP_INVAL_ARGS;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Queue specified doesnot belong to an active interface\n",
                    __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    
    }

    /* Classificati n Result Check */
    //TBD: Need to fill the fault code at exact location
    /* Currently this has to be specified before enabling since this is the only one that we support.
       We do not support TrafficClass and ClassApp */
    if ((xQMC.enable == TRUE) && (xQMC.qId == -1))
    {
        for (iCnt = 0; iCnt < iElements; iCnt++)
            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
        iRet = ERR_CWMP_INVAL_ARGS;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Need to specify the Proper Class Queue Value\n",
                    __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Classification Criteria Check */
    /* TBD: Need to fill the fault code at exact location. Also note that if a new classification 
       criteria parameter is added, it should be added to this list */
    /* TBD: Currently not considering params that do not have functionality support */
    if ((xQMC.enable == TRUE) &&
        (xQMC.protoNum == -1) &&
        (xQMC.srcPortRange.start_port == -1) &&
        (xQMC.srcPortRange.end_port == -1) &&
        (xQMC.dstPortRange.start_port == -1) &&
        (xQMC.dstPortRange.end_port == -1) &&
        (xQMC.dscpCheck == -1) &&
        (!strcmp(xQMC.dstIP.ip,"")) &&
        (!strcmp(xQMC.srcIP.ip,"")) &&
        (!strlen(xQMC.srcMac)))
    {
        for (iCnt = 0; iCnt < iElements; iCnt++)
            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
        iRet = ERR_CWMP_INVAL_ARGS;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Need to specify some Classification Criteria\n",
                    __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }
        

    /*********** Fill Remaining Parameters Required by Structure ************/
    // Fill the type of Classifier
    //TBD: Need some logic for identifying the type of classifier
    if ((xQMC.enable == TRUE) && (xQMC.dscpCheck != -1))
    {
        xQMC.mfClass = IFX_MAPI_QoS_DSCP;
    }

    /* Overright the type of classifier */
    /* TBD: if other classification criteria is also specified */
    /* TBD: Currently not considering params that do not have functionality support */
    if ((xQMC.enable == TRUE) &&
        ((xQMC.protoNum != -1) ||
        (xQMC.srcPortRange.start_port != -1) ||
        (xQMC.srcPortRange.end_port != -1) ||
        (xQMC.dstPortRange.start_port != -1) ||
        (xQMC.dstPortRange.end_port != -1) ||
        (strcmp(xQMC.dstIP.ip,"")) ||
        (strcmp(xQMC.srcIP.ip,"")) ||
        (strlen(xQMC.srcMac))))
    {
        xQMC.mfClass = IFX_MAPI_QoS_Multi_Field;
    }

    /* Allow enabling the classifier, only if the queue to which it is attached is enabled */
    sprintf(sCpeId,"%d", xQMC.qId);
    iCnt = ifx_get_instance_count_from_dist_fvp(TAG_IPQOS_QUEUE, PREFIX_IPQOS_QUEUE, "cpeId", sCpeId, IFX_F_GET_ENA);

    if ((iCnt <= 0) && (xQMC.enable == TRUE))
    {
        for (iCnt = 0; iCnt < iElements; iCnt++)
            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
        iRet = ERR_CWMP_INVAL_ARGS;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] Queue with CpeId %d to which the Classifier has to be attached is disabled\n",
                     __FILE__, __func__, __LINE__, xQMC.qId);
        goto cleanup;
    } 

    /* Fill the iid structure in IFX_MAPI_QoS_Classifier*/
    xQMC.iid.config_owner = iCaller;

    /* Set all the IFX_MAPI_QoS_Classifier parameters using Object API */
    uiFlags = IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH;
    /* Validating only if we are enabling the entry. Always activating the entry, to maintain order.
       Old state of enable parameter does not make any impact. */
    if (xQMC.enable == FALSE)
        uiFlags |=  IFX_F_DONT_VALIDATE; 
    
    if ((xQMC.classIf == IFX_MAPI_QoS_ALL) || (xQMC.classIf == IFX_MAPI_QoS_LAN_ALL))
    {
	    iRtn = ifx_mapi_set_qos_classifier(IFX_OP_MOD, &xQMC, uiFlags);

    }
    if ((xQMC.classIf == IFX_MAPI_QoS_WAN_ALL) || (xQMC.classIf == IFX_MAPI_QoS_WAN))
    {
	    iRtn = ifx_mapi_set_qos_ds_classifier(IFX_OP_MOD, &xQMC, uiFlags);
    }


    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to set values of all "
                    "parameters\n", __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    IFX_CWMP_FREE(qos_queue); 
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : Validate
**
**   Description      : This function validates the values of parameters in
**                      Classification object.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      validated.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When validation of all parameters is
**                      successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in validating at least one parameter.
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iCnt;
    int32   iParamOffset;
    char8   *psTmpVal;

   /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Iterate and validate the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Return a failure if the value is NULL pointer */
        if (!psTmpVal)
        {
            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
            iRet = ERR_CWMP_INVAL_ARGS;
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_QM_C_CLASSIFICATIONSTATUS:
                /* RO params - Not validating. just returtning success */
                break;
            case OID_IGD_QM_C_CLASSIFICATIONENABLE:
            case OID_IGD_QM_C_DESTIPEXCLUDE:
            case OID_IGD_QM_C_SOURCEIPEXCLUDE:
            case OID_IGD_QM_C_PROTOCOLEXCLUDE:
            case OID_IGD_QM_C_DESTPORTEXCLUDE:
            case OID_IGD_QM_C_SOURCEPORTEXCLUDE:
            case OID_IGD_QM_C_SOURCEMACEXCLUDE:
            case OID_IGD_QM_C_DESTMACEXCLUDE:
            case OID_IGD_QM_C_DSCPEXCLUDE:
            case OID_IGD_QM_C_ETHERNETPRIORITYEXCLUDE:
            case OID_IGD_QM_C_VLANIDEXCLUDE:
                if(!(!strcmp(psTmpVal, "true") ||
                   !strcmp(psTmpVal, "false") ||
                   !strcmp(psTmpVal, "1") ||
                   !strcmp(psTmpVal, "0")))
 
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto cleanup;
                }
                break;
            case OID_IGD_QM_C_DESTIP:
            case OID_IGD_QM_C_DESTMASK:
            case OID_IGD_QM_C_SOURCEIP:
            case OID_IGD_QM_C_SOURCEMASK:
                if (psTmpVal && (strcmp(psTmpVal,"")))
                {
                    struct in_addr inp;
                    if (!inet_aton(psTmpVal, &inp))
                    {
                        (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        iRet = ERR_CWMP_INVAL_ARGS;
                        goto cleanup;
                    }
                }
                break;
            case OID_IGD_QM_C_SOURCEMACADDRESS:
            case OID_IGD_QM_C_DESTMACADDRESS:
            case OID_IGD_QM_C_CLASSIFICATIONORDER:
            case OID_IGD_QM_C_CLASSINTERFACE:
            case OID_IGD_QM_C_PROTOCOL:
            case OID_IGD_QM_C_DESTPORT:
            case OID_IGD_QM_C_DESTPORTRANGEMAX:
            case OID_IGD_QM_C_SOURCEPORT:
            case OID_IGD_QM_C_SOURCEPORTRANGEMAX:
            case OID_IGD_QM_C_DSCPCHECK:
            case OID_IGD_QM_C_DSCPMARK:
            case OID_IGD_QM_C_ETHERNETPRIORITYCHECK:
            case OID_IGD_QM_C_ETHERNETPRIORITYMARK:
            case OID_IGD_QM_C_VLANIDCHECK:
            case OID_IGD_QM_C_FORWARDINGPOLICY:
            case OID_IGD_QM_C_TRAFFICCLASS:
            case OID_IGD_QM_C_CLASSPOLICER:
            case OID_IGD_QM_C_CLASSQUEUE:
                /* TBD: Will be done later if required */
                break;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

cleanup:
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Validating requested parameter failed\n",
                    __FILE__, __func__, __LINE__, iRet);
    }
    return (iRet);
}

STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iCnt;
    int32 iParamOffset;
    int32 iValueFlag = 0; /* Mandatory */

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Set the fault code to Success and value to NULL pointer for all parameters
       other than uptime */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Mark that values have been malloced. Currently always doing it, since not possible
       to keep track in a loop, for which params its malloced */
    iValueFlag = 1;

    /* Update Attribute Information */
    iRet = IFX_SetAttributesInfo(NULL, pxParamVal, iElements);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Updating Param Attribute Info failed\n",
                    __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    /* Free the Value that has been allocated */
    if (iValueFlag)
    { 
        for (iCnt = 0; iCnt < iElements; iCnt++)
        {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
        }
    }

    return (iRet);
}

STATIC int32
AddObj(IN OperInfo *pxOI,INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32 iRet=IFX_CWMP_SUCCESS;
    int32       iRtn       = IFX_SUCCESS;
    uint32 iFlags=0;
    uint32 iOper;
    uint32 uiPcpeId=0;
    IFX_MAPI_QoS_Classifier xQMC;
    uint32 uiInstanceCount = 0;
    int32 iCnt;
    int32 iParamOffset;
    char8       *psTmpVal;
    IFX_MAPI_QoS_Capability xQoSC;
    IFX_MAPI_QoS_Interface_Type qIfType;

    //TBD: Need to put a check on the number of classifiers allowed

    /* Get all the IFX_MAPI_QoS_Capability parameters using Protocol API */
    iRtn = ifx_mapi_get_qos_capability(&xQoSC, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_capability failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

   qIfType = ifx_mapi_get_active_qos_iface();
   uiInstanceCount = 0;
   uiInstanceCount = ifx_mapi_get_classifier_count_for_wan_mode(qIfType);
   if (uiInstanceCount >= xQoSC.maxClassifiers)
   {
        iRet = ERR_RESOURCE_EXCEEDED;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] Cannot add more Classifiers\n",
                    __FILE__,  __func__, __LINE__);
        goto cleanup;
   }

    memset(&xQMC, 0, sizeof(IFX_MAPI_QoS_Classifier));

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_QM_C_CLASSIFICATIONENABLE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMC.enable = TRUE;
                }
                else
                {
                    xQMC.enable = FALSE;
                }
                break;
            case OID_IGD_QM_C_CLASSIFICATIONSTATUS:
                // Nothing to be done here since it is not stored in rc.conf
                break;
            case OID_IGD_QM_C_CLASSIFICATIONORDER:
                xQMC.order = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_CLASSINTERFACE:
                //TBD: Needs to be handled
               if(psTmpVal!=NULL)
	       {
                if (!psTmpVal)
                {
                    xQMC.classIf = IFX_MAPI_QoS_ALL;
                }
                if (!strcmp(psTmpVal, "LAN"))
                {
                    xQMC.classIf = IFX_MAPI_QoS_LAN_ALL;
                }
                else if (!strcmp(psTmpVal, "Local"))
                {
                    xQMC.classIf = IFX_MAPI_QoS_LOCAL;
                }
                else
                {
                    xQMC.classIf = IFX_MAPI_QoS_ALL;
                }
	      }
                break;
            case OID_IGD_QM_C_DESTIP:
                if (psTmpVal)
                    strcpy(xQMC.dstIP.ip,psTmpVal);
                else
                    strcpy(xQMC.dstIP.ip,"");
                break;
            case OID_IGD_QM_C_DESTMASK:
                if (psTmpVal)
                    strcpy(xQMC.dstIP.mask,psTmpVal);
                else
                    strcpy(xQMC.dstIP.mask,"");
                break;
            case OID_IGD_QM_C_DESTIPEXCLUDE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMC.dstIPExcl = TRUE;
                }
                else
                {
                    xQMC.dstIPExcl = FALSE;
                }
                break;
            case OID_IGD_QM_C_SOURCEIP:
                if (psTmpVal)
                    strcpy(xQMC.srcIP.ip,psTmpVal);
                else
                    strcpy(xQMC.srcIP.ip,"");
                break;
            case OID_IGD_QM_C_SOURCEMASK:
                if (psTmpVal)
                    strcpy(xQMC.srcIP.mask,psTmpVal);
                else
                    strcpy(xQMC.srcIP.mask,"");
                break;
            case OID_IGD_QM_C_SOURCEIPEXCLUDE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMC.srcIPExcl = TRUE;
                }
                else
                {
                    xQMC.srcIPExcl = FALSE;
                }
                break;
            case OID_IGD_QM_C_PROTOCOL:
                xQMC.protoNum = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_PROTOCOLEXCLUDE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMC.protoExcl = TRUE;
                }
                else
                {
                    xQMC.protoExcl = FALSE;
                }
                break;
            case OID_IGD_QM_C_DESTPORT:
                xQMC.dstPortRange.start_port = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_DESTPORTRANGEMAX:
                xQMC.dstPortRange.end_port = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_DESTPORTEXCLUDE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMC.dstPortExcl = TRUE;
                }
                else
                {
                    xQMC.dstPortExcl = FALSE;
                }
                break;
            case OID_IGD_QM_C_SOURCEPORT:
                xQMC.srcPortRange.start_port = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_SOURCEPORTRANGEMAX:
                xQMC.srcPortRange.end_port = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_SOURCEPORTEXCLUDE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMC.srcPortExcl = TRUE;
                }
                else
                {
                    xQMC.srcPortExcl = FALSE;
                }
                break;
            case OID_IGD_QM_C_SOURCEMACADDRESS:
                if (psTmpVal)
                    strcpy(xQMC.srcMac,psTmpVal);
                else
                    strcpy(xQMC.srcMac,"");
                break;
            case OID_IGD_QM_C_SOURCEMACEXCLUDE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMC.srcMacExcl = TRUE;
                }
                else
                {
                    xQMC.srcMacExcl = FALSE;
                }
                break;
            case OID_IGD_QM_C_DESTMACADDRESS:
                if (psTmpVal)
                    strcpy(xQMC.dstMac,psTmpVal);
                else
                    strcpy(xQMC.dstMac,"");
                break;
            case OID_IGD_QM_C_DESTMACEXCLUDE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMC.dstMacExcl = TRUE;
                }
                else
                {
                    xQMC.dstMacExcl = FALSE;
                }
                break;
            case OID_IGD_QM_C_DSCPCHECK:
                xQMC.dscpCheck = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_DSCPEXCLUDE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMC.dscpExcl = TRUE;
                }
                else
                {
                    xQMC.dscpExcl = FALSE;
                }
                break;
            case OID_IGD_QM_C_DSCPMARK:
                xQMC.dscpMark = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_ETHERNETPRIORITYCHECK:
                //TBD: What is the formula for user
                xQMC.pBitsCheck = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_ETHERNETPRIORITYEXCLUDE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMC.pBitsExcl = TRUE;
                }
                else
                {
                    xQMC.pBitsExcl = FALSE;
                }
                break;
            case OID_IGD_QM_C_ETHERNETPRIORITYMARK:
                //TBD: What is the formula for user
                xQMC.pBitsMark = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_VLANIDCHECK:
                //TBD: What is the formula for user
                xQMC.vlanCheck = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_VLANIDEXCLUDE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMC.vlanExcl = TRUE;
                }
                else
                {
                    xQMC.vlanExcl = FALSE;
                }
                break;
            case OID_IGD_QM_C_FORWARDINGPOLICY:
                xQMC.fwPolicy = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_TRAFFICCLASS:
                xQMC.trafficClassId = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_CLASSPOLICER:
                xQMC.policerId = atoi(psTmpVal);
                break;
            case OID_IGD_QM_C_CLASSQUEUE:
                if (atoi(psTmpVal) == -1)
                {
                    xQMC.qId = atoi(psTmpVal);
                }
                else
                {
                    /* TR69 Instance number is specified. We need to get CPE-ID */
                    /* Construct TR69 Id from instance number */
                    char8 sTr69Id[IFX_MAX_TR69_ID_LEN]={0};
                    uint32 uiNumCpeId;
                    IFX_CpeId *pxCpeIdArray = NULL;
                    int32 iLoopCntr=0;
                    sprintf(sTr69Id,"%d.%d.%d.%d.",OID_IGD,OID_IGD_QM,
                            OID_IGD_QM_Q,atoi(psTmpVal));
                    /* Get CPE ID From TR69 ID */
                    if (IFX_GetCpeIdFromTr69Id(sTr69Id, &uiNumCpeId, &pxCpeIdArray) != IFX_CWMP_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] No cpeid for tr69id %s\n",
                            __FILE__, __func__, __LINE__, sTr69Id);
                        iRet = ERR_CWMP_INTERNAL;
                        goto cleanup;
                    }
                    /* Get the respective CPE ID from matching section */
                    for (iLoopCntr=0; iLoopCntr<uiNumCpeId; iLoopCntr++)
                    {
                        if (!strcmp(pxCpeIdArray[iLoopCntr].sSectionTag, TAG_IPQOS_QUEUE))
                        {
                            xQMC.qId = pxCpeIdArray[iLoopCntr].uiId;
                            IFX_CWMP_FREE(pxCpeIdArray);
                            break;
                        }
                    }
                    if (iLoopCntr == uiNumCpeId)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] No cpeid for tr69id %s with section as %s\n",
                            __FILE__, __func__, __LINE__, sTr69Id, TAG_IPQOS_QUEUE);
                        IFX_CWMP_FREE(pxCpeIdArray);
                        iRet = ERR_CWMP_INTERNAL;
                        goto cleanup;
                    }
                }
                break;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter %d\n",
                            __FILE__, __func__, __LINE__, iRet, (pxParamVal[iCnt]).iaOID[iParamOffset]);
                goto cleanup;
        }
    }

    /*********** Fill Remaining Parameters Required by Structure ************/
    /* TBD: Here actually the enum of mfClass should have a value of none. Since it is not present, I am putting DSCp. */
    xQMC.mfClass = IFX_MAPI_QoS_DSCP;

    /* Fill in the order */
    uiInstanceCount = 0;
    ifx_get_sec_instance_count(TAG_IPQOS_CLASSIFY, &uiInstanceCount);
    xQMC.order = uiInstanceCount+1;

    if(xQMC.qId <=0) {
	xQMC.qId = ifx_mapi_get_default_queue_cpeid(qIfType);
    }

	//Fill the operation
	iOper = IFX_OP_ADD;
	
	//Fills the Cpeid,ParentCepid,TR69Id,Owner
	iRet = IFX_GetParentObjCpeId(pxParamVal->iaOID,&uiPcpeId);
	if(iRet != IFX_CWMP_SUCCESS)
		goto cleanup;

	xQMC.iid.config_owner=pxOI->iCaller;
	xQMC.iid.cpeId.Id=0;
	xQMC.iid.pcpeId.Id=uiPcpeId;
	
	//Flags should be filled
        /* Activating the entry to maintain order */
	iFlags =(IFX_F_DONT_CHECKPOINT| IFX_F_DONT_VALIDATE|IFX_F_DONT_WRITE_TO_FLASH);

	//Convert array into dotted form and then strcpy
	
	iRet = IFX_ConvertOidDottedForm(pxParamVal->iaOID, xQMC.iid.tr69Id);
	if(iRet != IFX_CWMP_SUCCESS)
		goto cleanup;

	iRtn = ifx_mapi_set_qos_classifier(iOper, &xQMC, iFlags);

	if(iRtn != IFX_SUCCESS)
	{
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"ifx_mapi_set_qos_classifier AddObj Mgmt API"					                          " returned error\n");
        iRet = ERR_CWMP_INTERNAL;
		goto cleanup;
		
	}	

cleanup:
return iRet;

}

STATIC int32
SetDelete(IN OperInfo *pxOI,INOUT ParamVal *pxParamVal,
          IN int32 iElements, OUT void **ppxParamStructRet,
          OUT int32 * piNumRetElem)
{
#define QUEUEMGMT_CLASSIFY_OPTION_NO_OF_DEP_OIDS 0
    int32 iRet=IFX_CWMP_SUCCESS;
    int32 iRtn=IFX_SUCCESS;
    uint32 uiCpeid=0;
    IFX_MAPI_QoS_Classifier xQMC;
    uint32 iOper=0,iFlags=0;
    int32  iParamPos=0;
    ParamVal *Param_DepOids=NULL;

    // handle CHK_DELETE_DEP
    if(pxOI->iSubOper == OP_SETVAL_CHK_DEL_DEP)
    {
        Param_DepOids = IFIN_CWMP_MALLOC((QUEUEMGMT_CLASSIFY_OPTION_NO_OF_DEP_OIDS+1)* sizeof(ParamVal));
        if(Param_DepOids == NULL)
        {
           iRet = ERR_OUT_OF_MEMORY; 
           goto cleanup;
        }

        //Get the WanIpConParamPos 
        iParamPos = IFX_GetParamIdPos(pxParamVal->iaOID);
        if (iParamPos < 0){
            IFX_CWMP_FREE(Param_DepOids);
            goto cleanup; //To fix SCA error
        }

        memcpy((Param_DepOids+0)->iaOID,pxParamVal->iaOID,
               (sizeof(int32)*(iParamPos+1)));

      *ppxParamStructRet = (void *)Param_DepOids;
      *piNumRetElem = QUEUEMGMT_CLASSIFY_OPTION_NO_OF_DEP_OIDS+1;

        return IFIN_CWMP_SUCCESS;
    }

    if(pxOI->iSubOper == OP_SETVAL_CHK_DEL_ALLOWED)
    {
        return IFIN_CWMP_SUCCESS;
    }

    // Get Cpeid from object ID
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&uiCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    	goto cleanup;

    memset(&xQMC, 0, sizeof(IFX_MAPI_QoS_Classifier));

    /* Fill the cpeid in the structure to get the required instance */
    xQMC.iid.cpeId.Id = uiCpeid;

    /* Get all the IFX_MAPI_QoS_Classifier parameters using Protocol API */
    iRtn = ifx_mapi_get_qos_classifier(&xQMC, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_classifier failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    xQMC.iid.config_owner=pxOI->iCaller;
    xQMC.iid.cpeId.Id=uiCpeid;
    memset(xQMC.iid.tr69Id,0x00,MAX_TR69_ID_LEN);
    iOper = IFX_OP_DEL;
    /* (Enable--> Delete) or (Disable --> Delete), Always activating the entry since order has to be maintained */
    iFlags = (IFX_F_DELETE|IFX_F_DONT_VALIDATE| IFX_F_DONT_CHECKPOINT|IFX_F_DONT_WRITE_TO_FLASH);
    iRtn = ifx_mapi_set_qos_classifier(iOper, &xQMC, iFlags);
    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "ifx_mapi_set_qos_classifier -delete Mgmt API returned error\n");
        iRet = ERR_CWMP_INTERNAL;
        goto cleanup;
    }

cleanup:
    return iRet;
}


/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : IFX_QMClassify_Init
**
**   Description      : This function is called by the controller. It registers
**                      the function responsible for handling Classification
**                      object with data structure. It also performs
**                      initializations specific to Classification object.
**
**   Parameters       : No Parameters. 
**
**   Return Value     : IFX_CWMP_SUCCESS - When Classification object is
**                      initialized successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in initializing Classification object.
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_QMClassify_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the Classification module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_QUEUE_MGMT_CLASSIFY_OBJ, IFX_QMClassify);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_QUEUE_MGMT_CLASSIFY_OBJ);
        goto cleanup;
    }

cleanup:
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_QMClassify
**
**   Description      : This function is called by the controller. It handles
**                      Classification object and performs  based on requested
**                      operations/suboperations by invoking internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_QMClassify(IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
             OUT void **ppRet, OUT int32 *piNumRetElem)
{
    int32       iRet           = IFX_CWMP_SUCCESS, iCnt = 0;
    ParamVal    *pxParamVal    = (ParamVal *)pParamList;

    /* Process based on type of Operation */
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:

                    /* Get values of all the requested parameters */
                    iRet = GetVal(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_SETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:

                    /* Validate values of all the requested parameters */
                    iRet = Validate(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:

                    /* Check modify dependency of all requested parameters */
                    iRet = IFX_CWMP_SUCCESS;
                    break;
                case OP_SETVAL_MODIFY:

                    /* Set values of all the requested parameters */
                    iRet = Modify(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ATTRINFO:

                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ADD:
                    iRet = AddObj(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }
                    break;
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
                case OP_SETVAL_DELETE:
                    if((iRet= SetDelete(pxOI, pxParamVal,
                        iNumElem, ppRet, piNumRetElem))!= IFX_CWMP_SUCCESS)
                    {

                        switch(pxOI->iSubOper)
                        {
                            case OP_SETVAL_CHK_DEL_DEP:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
                                goto cleanup;
                            case OP_SETVAL_CHK_DEL_ALLOWED:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
                                goto cleanup;
                            case OP_SETVAL_DELETE:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
                                goto cleanup;
                        }
                    }
                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_UPDATE_CHILDINFO:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD: 
                case OP_UPDATE_CHILDINFO_DEL: 
                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_PARAM_VALIDATE:
        {
            iRet = ParamValidate(pxOI, pxParamVal, iNumElem);
            /* Check for error */
            if (iRet != IFX_CWMP_SUCCESS)
            {
                for(iCnt = 0; iCnt < iNumElem; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
                }
                iRet = IFX_CWMP_SUCCESS;
                goto cleanup;
            }
	    break; 
        }
        default:
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid Operation\n",
                         __func__, __LINE__, iRet);
            goto cleanup;
    }

cleanup:
    return (iRet);
}
