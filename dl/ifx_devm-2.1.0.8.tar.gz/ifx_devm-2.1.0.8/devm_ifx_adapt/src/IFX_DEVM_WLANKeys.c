/*
** =============================================================================
**   FILE NAME        : IFX_WlanKeys.c
**   PROJECT          : TR69
**   MODULES          : WlanKeys
**   DATE             : 29-08-2007
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This module handles ADD/DEL/GET/SET RPCs of
**                      WlanKeys. When controller calls this module it
**                      calls respective Platform/Object APIs to handle GET/SET
**                      of WlanKeys specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          :
**   $Date            $Author        $Comment
**   28-04-06         TR69 team      Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
//#include <sys/socket.h>
//#include <netinet/in.h>
//#include <arpa/inet.h>
#include <unistd.h>
#include "IFX_DEVM_WLANKeys.h"
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
 

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;

#ifdef IFX_TR69_DEVICE
	#define OID_IGD_LAND_WLANC_WEPK		OID_IGD_LAN_WLANC_WEPK
	#define OID_IGD_LAND_WLANC_WEPK_WEPKEY		OID_IGD_LAN_WLANC_WEPK_WEPKEY
	#define OID_IGD_LAND_WLANC_PSK		OID_IGD_LAN_WLANC_PSK
	#define	OID_IGD_LAND_WLANC_PSK_KEYPASSPHRASE	OID_IGD_LAN_WLANC_PSK_KEYPASSPHRASE
	#define OID_IGD_LAND_WLANC_PSK_PRESHAREDKEY	OID_IGD_LAN_WLANC_PSK_PRESHAREDKEY
#endif

#define IFX_WLAN_WEP_OBJ FORMLANNAME("WLANConfiguration.1.WEPKey.1.")
#define IFX_WLAN_PSK_OBJ FORMLANNAME("WLANConfiguration.1.PreSharedKey.1.")

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/


extern Map_Value gaxEnable[];



/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS>
**
** =============================================================================
*/
static int ishexdigit(char c)
{
if (isdigit(c)||(c>='A'&& c<='F')||(c>='a'&& c<='f'))
return 1;
else
return 0;
}
/*
** =============================================================================
**   Function Name    : IFX_WlanKeysGetValue
**   Description        :
**
**   Parameters       :
**
**   Return Value     :
**   Notes                :
**
** ============================================================================
*/
static int32
IFX_WlanKeysGetValue(IN OperInfo * pxOperInfo, INOUT ParamVal * paxParamVal,
                     IN uint32 iElements)
{

    uint32 i = 0,j=0;
    uint32 uiCpeid = 0;
    uint32 uiPcpeid = 0, keyIndex = 0;
    int32 iRet = IFX_CWMP_SUCCESS;
    uint32 iFlags = 0, uiParamPos = 0;

    IFX_MAPI_WLAN_WEP_Cfg wlWep;
    IFX_MAPI_WLAN_PersonalCfg wlPsk;

    memset(&wlWep,0x00, sizeof(IFX_MAPI_WLAN_WEP_Cfg));
    memset(&wlPsk,0x00, sizeof(IFX_MAPI_WLAN_PersonalCfg));

    // Get the Cpeid from Tr69 id

    iRet = IFX_GetCpeId(paxParamVal->iaOID, &uiCpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Get the pCpeid from Tr69 id
    iRet = IFX_GetParentObjCpeId(paxParamVal->iaOID, &uiPcpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Fills the Cpeid,ParentCepid,TR69Id,Owner
    iFlags = IFX_F_GET_ANY;

    // Get the WlanKeysParamPos
    uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);

    for (i = 0; i < iElements; i++)
    {
        // Malloc and assign the pointer to the Value attr of struct
        paxParamVal[i].Value = IFIN_CWMP_MALLOC(128);
        if (paxParamVal->Value == NULL)
        {
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (paxParamVal[i].iaOID[uiParamPos - 2])
        {
        case OID_IGD_LAND_WLANC_WEPK:
            keyIndex = paxParamVal[i].iaOID[uiParamPos - 1];

            for (j = 0; j < IFX_MAPI_NUM_WEP_KEYS; j++)
            {
                //    wlWep.wepKey[j].iid.cpeId.Id = uiCpeid;
                wlWep.wepKey[j].iid.pcpeId.Id = uiPcpeid;
            }


            iRet = ifx_mapi_get_wlan_wep_config(&wlWep, iFlags);
            if (iRet != IFX_CWMP_SUCCESS)


                goto errorHandler;


            switch (paxParamVal[i].iaOID[uiParamPos])
            {
            case OID_IGD_LAND_WLANC_WEPK_WEPKEY:
                strncpy(paxParamVal[i].Value, wlWep.wepKey[keyIndex-1].wepKey, IFX_MAPI_WEP_KEY_MAX_LEN);
                break;
            default:
                break;
            }
            break;
        case OID_IGD_LAND_WLANC_PSK:
            wlPsk.psk.iid.cpeId.Id = uiCpeid;
            wlPsk.psk.iid.pcpeId.Id = uiPcpeid;
            iRet=ifx_mapi_get_wlan_personal_config(&wlPsk,iFlags);
            if (iRet != IFX_CWMP_SUCCESS)
                goto errorHandler;

            switch (paxParamVal[i].iaOID[uiParamPos])
            {
            case OID_IGD_LAND_WLANC_PSK_KEYPASSPHRASE:
		if(wlPsk.pskType == IFX_MAPI_WLAN_ASCII_KEY){
                	strncpy(paxParamVal[i].Value,wlPsk.psk.passPhrase,IFX_MAPI_PASSPHRASE_MAX_LEN);
		}
                break;
            case OID_IGD_LAND_WLANC_PSK_PRESHAREDKEY:
		if(wlPsk.pskType == IFX_MAPI_WLAN_HEX_KEY){
                	strncpy(paxParamVal[i].Value,wlPsk.psk.preSharedKey,IFX_MAPI_PSK_MAX_LEN);
		} 
		else {
			strncpy(paxParamVal[i].Value,wlPsk.psk.passPhrase,IFX_MAPI_PASSPHRASE_MAX_LEN);
	 	}	
		
                break;
            default:
                break;
            }
            break;
        default:
            break;
        }
    }

    return IFX_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed ParamId=%d !\n", __func__, __LINE__,
                paxParamVal->iaOID[uiParamPos]);
    return IFIN_CWMP_FAILURE;
}


/*
** =============================================================================
**   Function Name    : IFX_WlanKeysSetValue
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/
static int32
IFX_WlanKeysSetValue(IN OperInfo * pxOpInfo, INOUT ParamVal * paxParamVal,
                     IN int32 iElements)
{

    uint32 i = 0, j = 0, k;
    uint32 uiCpeid = 0, keyIndex = 0;
    uint32 uiPcpeid = 0;
    int32 iRet = IFX_CWMP_SUCCESS;
    uint32 iOper = 0, iFlags = 0, uiParamPos = 0;

    IFX_MAPI_WLAN_WEP_Cfg wlWep;
    IFX_MAPI_WLAN_PersonalCfg wlPsk;
    

    memset(&wlWep, 0x00, sizeof(IFX_MAPI_WLAN_WEP_Cfg));
    memset(&wlPsk, 0x00, sizeof(IFX_MAPI_WLAN_PersonalCfg));


    // Get the Cpeid from Tr69 id
    iRet = IFX_GetCpeId(paxParamVal->iaOID, &uiCpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Get the pCpeid from Tr69 id
    iRet = IFX_GetParentObjCpeId(paxParamVal->iaOID, &uiPcpeid);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;



    // Fills the Cpeid,ParentCepid,TR69Id,Owner
    iOper = IFX_OP_MOD;
    iFlags = IFX_F_GET_ANY;

    // Get the WlanKeysParamPos
    uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);

    switch (pxOpInfo->iSubOper)
    {

    case OP_SETVAL_CHK_MODIFY_DEP:
        break;

    case OP_SETVAL_VALIDATE:
	for (i = 0; i < iElements; i++)
        {
	    switch (paxParamVal[i].iaOID[uiParamPos - 2])
            {
		case OID_IGD_LAND_WLANC_WEPK:
		    keyIndex = paxParamVal[i].iaOID[uiParamPos - 1];
                    strcpy(wlWep.wepKey[keyIndex-1].wepKey, paxParamVal[i].Value);
		    for(k=0;k<strlen(wlWep.wepKey[keyIndex-1].wepKey);k++) {
                        if(!ishexdigit(wlWep.wepKey[keyIndex-1].wepKey[k])) {
                            iRet = ERR_CWMP_INVAL_PARAM_VAL;
                            paxParamVal->iFaultCode=ERR_CWMP_INVAL_PARAM_VAL;
                            goto errorHandler;
			}
                    }
		    break;
                case OID_IGD_LAND_WLANC_PSK:
                    strcpy(wlPsk.psk.preSharedKey, paxParamVal[i].Value);
		    if(paxParamVal[i].iaOID[uiParamPos] == OID_IGD_LAND_WLANC_PSK_PRESHAREDKEY) {
                        for(k=0;k<strlen(wlPsk.psk.preSharedKey);k++) {
                            if(!ishexdigit(wlPsk.psk.preSharedKey[k])) {
                                iRet = ERR_CWMP_INVAL_PARAM_VAL;
                                paxParamVal->iFaultCode=ERR_CWMP_INVAL_PARAM_VAL;
                                goto errorHandler;
			    }
                        }
		    }
		    break;
		default:
		    break;
	   }
	}
        break;

    case OP_SETVAL_MODIFY:
        for (i = 0; i < iElements; i++)
        {
            switch (paxParamVal[i].iaOID[uiParamPos - 2])
            {
            case OID_IGD_LAND_WLANC_WEPK:
                keyIndex = paxParamVal[i].iaOID[uiParamPos - 1];

                for (j = 0; j < IFX_MAPI_NUM_WEP_KEYS; j++)
                {
                    wlWep.wepKey[j].iid.pcpeId.Id = uiPcpeid;
                }

                iRet = ifx_mapi_get_wlan_wep_config(&wlWep, iFlags);
                if (iRet != IFX_CWMP_SUCCESS)
                {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "ifx_set_wlan_wep_config -Modify Mgmt API returned error\n");
                    goto errorHandler;
                }

                switch (paxParamVal[i].iaOID[uiParamPos])
                {
                case OID_IGD_LAND_WLANC_WEPK_WEPKEY:

                    strcpy(wlWep.wepKey[keyIndex-1].wepKey, paxParamVal[i].Value);
                    wlWep.wepKey[keyIndex-1].iid.config_owner = pxOpInfo->iCaller;
                    wlWep.wepKeyType = IFX_MAPI_WLAN_HEX_KEY;
				
		    for(k=0;k<strlen(wlWep.wepKey[keyIndex-1].wepKey);k++) {
                        if(!ishexdigit(wlWep.wepKey[keyIndex-1].wepKey[k])) {
                            iRet = ERR_CWMP_INVAL_PARAM_VAL;
                            paxParamVal->iFaultCode=ERR_CWMP_INVAL_PARAM_VAL;
                            goto errorHandler;
						}
                    }
					
                    if(strlen(wlWep.wepKey[keyIndex-1].wepKey)>0) {
                        if(strlen(wlWep.wepKey[keyIndex-1].wepKey) == 10) {
                        	wlWep.wepEncrLevel = IFX_MAPI_WEP_ENCR_LVL_64BIT;	//64bit
                        } else if(strlen(wlWep.wepKey[keyIndex-1].wepKey) == 26) {
		        	wlWep.wepEncrLevel = IFX_MAPI_WEP_ENCR_LVL_128BIT; //128bit
			} else {
				iRet = ERR_CWMP_INVAL_PARAM_VAL;
                                paxParamVal->iFaultCode=ERR_CWMP_INVAL_PARAM_VAL;
                                goto errorHandler;									
                        } 

			iRet = ifx_mapi_set_wlan_wep_config(iOper, &wlWep, IFX_F_MODIFY);
                    
                        if (iRet != IFX_SUCCESS)
                        {
                            iRet = ERR_CWMP_INVAL_PARAM_VAL;
                            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "ifx_set_wlan_wep_config -Modify Mgmt API returned error\n");
                            goto errorHandler;
                        }
                    }
                    break;
                default:
                    break;
                }
                break;

            case OID_IGD_LAND_WLANC_PSK:

                wlPsk.psk.iid.cpeId.Id = uiCpeid;
                wlPsk.psk.iid.pcpeId.Id = uiPcpeid;
                iRet=ifx_mapi_get_wlan_personal_config(&wlPsk,iFlags);
                if (iRet != IFX_CWMP_SUCCESS)
                    goto errorHandler;

                wlPsk.psk.iid.config_owner = pxOpInfo->iCaller;

                switch (paxParamVal[i].iaOID[uiParamPos])
                {
                case OID_IGD_LAND_WLANC_PSK_KEYPASSPHRASE:
		   
                   if (strlen(paxParamVal[i].Value) > (IFX_MAPI_PASSPHRASE_MAX_LEN-1) || strlen(paxParamVal[i].Value) < 8 )
                    {
                        iRet = ERR_CWMP_INVAL_PARAM_VAL;
                        paxParamVal->iFaultCode=ERR_CWMP_INVAL_PARAM_VAL;
                        goto errorHandler;
                    }
		    
		    strcpy(wlPsk.psk.passPhrase, paxParamVal[i].Value);
		    strcpy(wlPsk.psk.preSharedKey, "");
                    wlPsk.pskType = IFX_MAPI_WLAN_ASCII_KEY;
                    
		    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"%s:%d wlPsk.psk.passPhrase:%s!\n", __func__, __LINE__,wlPsk.psk.passPhrase);

                    iRet = ifx_mapi_set_wlan_passphrase_config(iOper, &(wlPsk.psk), IFX_F_MODIFY);
                    if (iRet != IFX_SUCCESS)
                    {
                        iRet = ERR_CWMP_INVAL_PARAM_VAL;
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d ifx_set_wlan_passphrase_config failed\n",
                                    _FUNCL_);
                        goto errorHandler;
                    }
                    break;
		case OID_IGD_LAND_WLANC_PSK_PRESHAREDKEY:
                   
		   if (strlen(paxParamVal[i].Value) >  (IFX_MAPI_PSK_MAX_LEN-1) || strlen(paxParamVal[i].Value) < 8 )
                    {
                        iRet = ERR_CWMP_INVAL_PARAM_VAL;
                        paxParamVal->iFaultCode=ERR_CWMP_INVAL_PARAM_VAL;
                        goto errorHandler;
                    }
                    strcpy(wlPsk.psk.preSharedKey, paxParamVal[i].Value);
		    strcpy(wlPsk.psk.passPhrase,"");
		    wlPsk.pskType = IFX_MAPI_WLAN_HEX_KEY; 

                    for(k=0;k<strlen(wlPsk.psk.preSharedKey);k++) {
                       if(!ishexdigit(wlPsk.psk.preSharedKey[k])) {
#if 0
                          iRet = ERR_CWMP_INVAL_PARAM_VAL;
                          paxParamVal->iFaultCode=ERR_CWMP_INVAL_PARAM_VAL;
                          goto errorHandler;
#endif
			  strcpy(wlPsk.psk.passPhrase, paxParamVal[i].Value);
                    	  strcpy(wlPsk.psk.preSharedKey, "");
                    	  wlPsk.pskType = IFX_MAPI_WLAN_ASCII_KEY;
			  break;
                       }
                    }

                    iRet = ifx_mapi_set_wlan_passphrase_config(iOper,&(wlPsk.psk), IFX_F_MODIFY);
                    if (iRet != IFX_SUCCESS)
                    {
                        iRet = ERR_CWMP_INVAL_PARAM_VAL;
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d ifx_set_wlan_passphrase_config failed\n",
                                    _FUNCL_);
                        goto errorHandler;
                    }
                default:
                    break;

                }
                break;

            default:
                break;
            }

        }
    default:
        break;
    }
    return IFIN_CWMP_SUCCESS;

errorHandler:

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed!\n", __func__, __LINE__);
    return iRet;
}



/*
** =============================================================================
**   Function Name    : IFX_WlanKeysSetAttr
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/

int32
IFX_WlanKeysSetAttr(IN OperInfo * pxOpInfo, INOUT ParamVal * pxParamVal,
                    IN int32 iElements)
{
    int32 iRet = 0;

    iRet = IFX_SetAttributesInfo(pxOpInfo, pxParamVal, iElements);
    if (iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed!\n", __func__, __LINE__);
    return iRet;
}

/*
** =============================================================================
**   Function Name    : IFX_WlanKeys_Init
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/
int32
IFX_WlanKeys_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;


    /* Register the WlanWepKey module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_WLAN_WEP_OBJ, IFX_WlanKeys);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "Unable to Register %s with Object Model\n",
                    IFX_WLAN_WEP_OBJ);
        goto errorHandler;
    }

    /* Register the WlanWepKey module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_WLAN_PSK_OBJ, IFX_WlanKeys);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "Unable to Register %s with Object Model\n",
                    IFX_WLAN_PSK_OBJ);
        goto errorHandler;
    }

errorHandler:
    return iRet;
}


/*********************************************************************************
*  Function Name :  IFX_WlanKeys
*  Description   :  This function handles all the sub-states inside
                      a GET/SET operation.If it is a GET it allocates the
               array(Name,Value pairs) and retruns the values.
               If it is a SET controller allocates the array and
               passes the values to this function.It calls
               respective internal functions which in turn calls
               respective Platform APIs.

*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
                                 Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has
                                       Name,Value,etc
                    IN          int32           iElements;    No. of Elements
            OUT            void *           ppParamRet;   same as ParamStruc
            OUT         int32 *        piNumRetElem; No. of elements
*  Return Value  : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes         :
***********************************************************************************/
int32
IFX_WlanKeys(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
             IN int32 iElements, OUT void **ppaxParamArrRet,
             OUT int32 * piNumRetElem)
{

    int32 iRet = 0;
    ParamVal *paxParamArr = (ParamVal *) paxParameterArr;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d SubOper=%d '%s' Elem=%d\n",
                _FUNCL_, pxOperInfo->iSubOper, (char8 *) paxParamArr[0].Name,
                iElements);

    switch (pxOperInfo->iOper)
    {
        // Get the object values
    case OP_GETVAL_NORMAL:
    case OP_GETVAL:
        if ((iRet = IFX_WlanKeysGetValue(pxOperInfo, paxParamArr,
                                         iElements)) != IFX_CWMP_SUCCESS)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
            goto errorHandler;
        }
        break;
    case OP_SETVAL:
        // Set the obj values
        switch (pxOperInfo->iSubOper)
        {
        case OP_SETVAL_VALIDATE:
        case OP_SETVAL_CHK_MODIFY_DEP:
        case OP_SETVAL_MODIFY:
            if ((iRet = IFX_WlanKeysSetValue(pxOperInfo, paxParamArr,
                                             iElements)) !=
                    IFX_CWMP_SUCCESS)
            {
                switch (pxOperInfo->iSubOper)
                {
                case OP_SETVAL_CHK_MODIFY_DEP:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d OP_SETVAL_CHK_MODIFY_DEP failed!\n",
                                __func__, __LINE__);
                    goto errorHandler;

                case OP_SETVAL_MODIFY:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d OP_SETVAL_MODIFY failed!\n",
                                __func__, __LINE__);
                    goto errorHandler;
                }
            }
            break;
        case OP_SETVAL_UNDO:
        case OP_SETVAL_COMMIT:
        case OP_SETVAL_FREE:
        case OP_SETVAL_CHK_DEL_ALLOWED:
        case OP_SETVAL_DELETE:
        case OP_SETVAL_ADD:
            iRet = IFIN_CWMP_SUCCESS;
            break;
        case OP_SETVAL_CHK_DEL_DEP:
	    *ppaxParamArrRet = (ParamVal *)IFX_CWMP_MALLOC(sizeof(ParamVal));
 	    if(ppaxParamArrRet!=NULL) {
            	memcpy(*ppaxParamArrRet, paxParameterArr, sizeof(ParamVal));
            	*piNumRetElem = 1;
	    }
	    else {
		goto errorHandler;
 	    }
            break;
        case OP_SETVAL_ATTRINFO:
            if ((iRet = IFX_WlanKeysSetAttr(pxOperInfo, paxParamArr,
                                            iElements)) !=
                    IFX_CWMP_SUCCESS)
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_SETVAL_ATTRINFO failed!\n",
                            __func__, __LINE__);
                goto errorHandler;
            }
            break;
        default:
            break;
        }
        break;
    case OP_UPDATE_CHILDINFO:
        iRet = IFIN_CWMP_SUCCESS;
        break;
    case OP_PARAM_VALIDATE:
    {
        break; 
    }
    default:
        break;
    }
    return IFX_CWMP_SUCCESS;

errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d  WlanKeys returned error!\n", _FUNCL_);
    return iRet;
}
