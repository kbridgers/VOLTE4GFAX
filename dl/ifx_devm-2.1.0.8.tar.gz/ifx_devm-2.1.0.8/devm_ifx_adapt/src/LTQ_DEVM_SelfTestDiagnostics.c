/*
** =============================================================================
** FILE NAME   : LTQ_SelfTestDiagnostics.c
** PROJECT     : TR69
** MODULES     : InternetGateway.SelfTestDiagnostics.
** DATE        : 04-Jan-2013
** AUTHOR      : TR69 team
** DESCRIPTION : AddObject / DeleteObject cannot be performed on this object.
**                   
** REFERENCES  :  
** COPYRIGHT   : Copyright (c) 2006
**               Infineon Technologies AG
**               Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY     : 
** $Date       $Author        $Comment
** 04-Jan-2012 TR69 team      Creation         
** =============================================================================
*/

#include "IFX_DEVM_Global.h"
#include "IFX_DEVM_AdaptCommon.h"
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_StackUtil.h"
#include <resolv.h>


#define LTQ_CHECK_LANSATUS             0x1
#define LTQ_CHECK_WANSTATUS            0x2
#define LTQ_CHECK_WLANSTATUS           0X4
#define LTQ_CHECK_DSLSTATUS            0x8
#define LTQ_CHECK_LANPING              0x10
#define LTQ_CHECK_WANPING              0x20
#define LTQ_CHECK_DNSPING1             0x40
#define LTQ_CHECK_OAM		       0x80
#define LTQ_CHECK_ALL                  0x100

extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char *obj, modFunc pifx_module_func);

#define SELFTESTDIAG_OBJ                      FORMNAME("SelfTestDiagnostics.")
#define SELFTESTDIAG_DEPTH                    3

/*******************************************************************************
* Function: LTQ_SelfTestDiagSetAttrInfo
* Desc: Sets attribute information in the respective tr69 sections
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
LTQ_SelfTestDiagSetAttrInfo(IN int32 iCaller, INOUT ParamVal * pxPV,
                          IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    iRet = IFX_SetAttributesInfo(NULL, pxPV, iElements);

    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Updating Param Attribute Info failed\n",
                    _FUNCL_, iRet);
        goto errorHandler;
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: LTQ_SelfTestDiagGetValue
* Desc: 
*              
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
LTQ_SelfTestDiagGetValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                             IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    DIAGNOSTICS_TEST_SUITE xDiagTest;
    uint32 flags;

    memset(&xDiagTest, '\0', sizeof(xDiagTest));

    flags = IFX_F_DEFAULT;

    iRet = ltq_mapi_get_diagnostics_status(&xDiagTest, flags);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ltq_mapi_get_diagnostics_status() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }

    for(iI = 0; iI < iElements; iI++) {
        pxPV[iI].Value = IFX_CWMP_MALLOC(MAX_DATA_LEN);
        if(pxPV[iI].Value == NULL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", _FUNCL_);
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }
        switch (pxPV[iI].iaOID[SELFTESTDIAG_DEPTH - 1]) {

            case OID_IGD_STD_DIAGNOSTICSSTATE:
                strcpy(pxPV[iI].Value, xDiagTest.diag_state);
                break;

            case OID_IGD_STD_RESULTS:
                strcpy(pxPV[iI].Value, xDiagTest.caResult);
                break;

            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", _FUNCL_,
                            pxPV[iI].iaOID[SELFTESTDIAG_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: LTQ_SelfTestDiagSetValue
* Desc:
*              
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
LTQ_SelfTestDiagSetValue(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0, iActivate = 0;
    DIAGNOSTICS_TEST_SUITE xDiagTest;
    uint32 flags;

    memset(&xDiagTest, '\0', sizeof(xDiagTest));

    flags = IFX_F_DEFAULT;

    iRet = ltq_mapi_get_diagnostics_status(&xDiagTest, flags);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ltq_mapi_get_diagnostics_status() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[SELFTESTDIAG_DEPTH - 1]) {
            case OID_IGD_STD_DIAGNOSTICSSTATE:
                strcpy(xDiagTest.diag_state, pxPV[iI].Value);
                if(strcmp(pxPV[iI].Value, "Requested") == 0)
                    iActivate = IFX_CWMP_NEED_ACTIVATE;
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case '%s'\n", _FUNCL_,
                            pxPV[iI].iaOID[SELFTESTDIAG_DEPTH - 1],
                            (char8 *) pxPV[iI].Value);
                break;
        }
    }

    /* Modifying any of the parameters in this obj except DiagnosticState MUST
       result in the value of DiagnosticState parameter being set to "None" */
    if(iActivate != IFX_CWMP_NEED_ACTIVATE)
        strcpy(xDiagTest.diag_state, "None");

    iRet = ltq_mapi_set_diagnostics_status(&xDiagTest, IFX_F_MODIFY);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ltq_mapi_set_diagnostics_status() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }

  errorHandler:
    if((iActivate == IFX_CWMP_NEED_ACTIVATE) && (iRet == IFX_CWMP_SUCCESS))
        iRet = IFX_CWMP_NEED_ACTIVATE;
    return iRet;
}

/*******************************************************************************
* Function: LTQ_SelfTestDiagPerformTest
* Desc: Gets the value. Set the required value. Calls MAPI function with 
* ltq_mapi_performtest to perform to perform the Diagnostics test.
* Posts the message to the Stacks FIFO about the completion of SelfTest Diag Test
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS 
*******************************************************************************/
static int32
LTQ_SelfTestDiagPerformTest()
{
    int32 iRet = IFX_CWMP_SUCCESS, iFIFOFd = 0;
    DIAGNOSTICS_TEST_SUITE xDiagTest;
    uint32 uiflags;

    memset(&xDiagTest, '\0', sizeof(DIAGNOSTICS_TEST_SUITE));

    uiflags = IFX_F_DEFAULT;

    iRet = ltq_mapi_get_diagnostics_status(&xDiagTest, uiflags);
    if(iRet != IFX_SUCCESS) {
         IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                     "%s:%d [%d]ltq_mapi_get_diagnostics_status() failed\n", _FUNCL_, iRet);
         goto errorHandler;
    }

    xDiagTest.diag_test_cnt = LTQ_CHECK_ALL;

    iRet = ltq_mapi_performtest(&xDiagTest);
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d LTQ_mapi_performtest() failed\n",_FUNCL_,iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }

    strcpy(xDiagTest.diag_state, "Complete");

    iRet = ltq_mapi_set_diagnostics_status(&xDiagTest, IFX_F_MODIFY);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ltq_mapi_set_diagnostics_status() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
   }
    /* Send msg to FIFO */
    iFIFOFd = IFX_OS_OpenFifo((uchar8 *) IFX_IPC_TR_FIFO, O_RDWR);
    if(iFIFOFd < 0) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s:%d Error opening FIFO\n",
                    _FUNCL_);
        iRet = ERR_CWMP_FIFO_OPEN;
        goto errorHandler;
    }

    if(IFX_IPC_SendMsg(iFIFOFd, (uchar8) IFX_IPC_APP_DIAGNOSTIC, 0, 0, 0, NULL)
       != IFX_IPC_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Error sending msg to "
                    "FIFO\n", _FUNCL_);
    }
    IFX_OS_CloseFifo(iFIFOFd);

  errorHandler:
    /* Always return SUCCESS */
    return IFX_CWMP_SUCCESS;
}

/*******************************************************************************
* Function: LTQ_SelfTestDiagnostics
* Desc: 
*              
* Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
*             OUT void **ppRet, OUT int32 * piNumRetElem
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
LTQ_SelfTestDiagnostics(IN OperInfo * pxOI,
                      INOUT void *pParamStruct,
                      IN int32 iElements, OUT void **ppRet,
                      OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;

    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:
                    iRet = LTQ_SelfTestDiagGetValue(pxOI, xpParamVal,
                                                        iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                                pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                    break;
                case OP_SETVAL_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:
                    break;
                case OP_SETVAL_MODIFY:
                    iRet = LTQ_SelfTestDiagSetValue(xpParamVal, iElements);
                    if((iRet != IFX_SUCCESS) && (iRet != IFX_CWMP_NEED_ACTIVATE))
                    {
                           IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                                       "%s:%d, LTQ_SelfTestDiagSetValue() failed! \n", _FUNCL_);
                                        goto errorHandler;
                        goto errorHandler;
                    }
                    break;
                case OP_SETVAL_ACTIVATE:
                    iRet = LTQ_SelfTestDiagPerformTest();
                    if(iRet != IFX_SUCCESS)
                        goto errorHandler;
                case OP_SETVAL_COMMIT:
                    break;
                case OP_SETVAL_UNDO:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_DELETE:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_ATTRINFO:
                    iRet =
                        LTQ_SelfTestDiagSetAttrInfo(pxOI->iCaller, pParamStruct,
                                                  iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                                pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_UPDATE_CHILDINFO_DEL:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
            break;
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                        pxOI->iOper);
            break;
        }
    }
  errorHandler:
    return iRet;
}
/************************************************************
* Function: LTQ_SelfTestDiagInit
* Desc: Will initialize some of its data structures, register itself with DS.
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
LTQ_SelfTestDiagInit()
{
    int32 iRet = IFX_CWMP_SUCCESS;
    DIAGNOSTICS_TEST_SUITE xDiagTest;

    memset(&xDiagTest, '\0', sizeof(xDiagTest));
    strcpy(xDiagTest.diag_state, "None");
    /* Register the LTQ_SelfTestDiagInit func ptr in the object model */
    iRet = ifx_ds_register_function(SELFTESTDIAG_OBJ, LTQ_SelfTestDiagnostics);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Unable to Register %s with Object Model\n",
                    _FUNCL_, iRet, SELFTESTDIAG_OBJ);
        goto errorHandler;
    }

    iRet = ltq_mapi_set_diagnostics_status(&xDiagTest, IFX_F_INT_ADD);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Writing default "
                    "ltq_mapi_set_diagnostics_status() failed in %s\n", _FUNCL_, iRet,
                    IFX_DIAG_FILE);
    }

  errorHandler:
    return iRet;
}
