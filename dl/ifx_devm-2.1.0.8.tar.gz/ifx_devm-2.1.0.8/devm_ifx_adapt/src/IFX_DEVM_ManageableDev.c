/* 
** =============================================================================
**   FILE NAME        : IFX_ManageableDevice.c
**   PROJECT          : TR69
**   MODULES         : ManageableDevice
**   DATE               : 21-06-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION   : This module handles ADD/DEL/GET/SET RPCs of 
**                      ManageableDevice. When controller calls this module it
**                      calls respective Platform/Object APIs to handle GET/SET 
**                      of ManageableDevice specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author        $Comment
**   28-04-06         TR69 team      Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
//#include <sys/socket.h>
//#include <netinet/in.h>
//#include <arpa/inet.h>

#include "IFX_DEVM_ManageableDev.h"
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
 

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;

#define IFX_MANAGEABLE_DEVICE_OBJ "InternetGatewayDevice.ManagementServer.ManageableDevice.1."


/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/




/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/
STATIC int32 
IFX_ManageableDevice_UpdateChildInfo(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,IN int32 iElements);




/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/



/* 
** =============================================================================
**   Function Name    : IFX_ManageableDevice_UpdateChildInfo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

static int32 IFX_ManageableDevice_UpdateChildInfo(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
								IN int32 iElements)
{
	uint32 i = 0, iRet = IFX_CWMP_SUCCESS;
	char8 sSecTag[IFX_MAX_SECTION_TAG_LEN] = { 0 };
	char8 sParamTag[IFX_MAX_NAME_LEN] = { 0 };
	uint32 uiParamPos = 0, uiChildObjId = 0;
	uint32 uiCpeid = 0;
	int32 *iaOID = NULL;
	uint32 uiNumNV = 1;
	//IFX_CpeId pxCpeId;
	IFX_Id xIfx_Id;
	IFX_NameValue pxNVArray;
	uint32 uiOper = IFX_NOTIFY_OPER_MODIFY;
	ParamVal *pxTempParamVal = pxParamVal;
	
	memset(&pxNVArray, '\0', sizeof(IFX_NameValue));

		//Get Cpeid
		iRet = IFX_GetCpeId(pxTempParamVal->iaOID, &uiCpeid);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;

		//Get the child object Oid
		uiChildObjId = IFX_GetParamIdPos((int32 *)pxTempParamVal->pReserved);
		iaOID = (int32 *)pxTempParamVal->pReserved;

		for(i=0; i < iElements; i++)

		{
			//Get the Param Oid of this object
			uiParamPos= IFX_GetParamIdPos(pxTempParamVal->iaOID);
			
			if(pxTempParamVal->iaOID[uiParamPos] == OID_IGD_MS_MANAGEABLEDEVICENUMBEROFENTRIES)
				 {
					if(iaOID[uiChildObjId-1] == OID_IGD_MS_MD )
					{
						//Get the section and Paramtag
						iRet=IFX_GetSectionParamTag(pxTempParamVal->psRCTag, sParamTag, sSecTag);
						if(iRet != IFX_CWMP_SUCCESS)
							goto errorHandler;
						
						xIfx_Id.uiConfigOwner= pxOpInfo->iCaller;
						xIfx_Id.xCpeId.uiId= uiCpeid;
						strncpy(xIfx_Id.xCpeId.sSectionTag,sSecTag, IFX_MAX_SECTION_TAG_LEN-1);
						xIfx_Id.xCpeId.sSectionTag[IFX_MAX_SECTION_TAG_LEN-1] = '\0';
						strncpy(pxNVArray.sName,sParamTag, IFX_MAX_NAME_LEN-1);
						pxNVArray.sName[IFX_MAX_NAME_LEN-1] = '\0';
												
						iRet=IFX_SendNotify(&xIfx_Id, uiNumNV, &pxNVArray, uiOper);
						if(iRet != IFX_CWMP_SUCCESS)
						{
							IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 			"%s:%d IFX_SendNotify failed!\n", __func__, __LINE__);
							
							goto errorHandler;
						}
					}
				}

			pxTempParamVal++;
			
		}
					
		return IFX_CWMP_SUCCESS;

		errorHandler:
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
			
			return IFX_CWMP_FAILURE;
}




int32 
IFX_GetManageableDevice(MANAGEABLE_DEVICE **ppxManageDevice, uint32 iCpeid)
{

	MANAGEABLE_DEVICE *paxManage_Dev=NULL;
	MANAGEABLE_DEVICE *pxTemp=NULL;
	MANAGEABLE_DEVICE *pxMatch_Manage_Dev=NULL;
	int32 uiNumOfEntries = 0;
	uint32 iFlags,i=0;
	uint32 iGotValue=0;
	int32 iRet=0;
	
	pxMatch_Manage_Dev=IFIN_CWMP_MALLOC(sizeof(MANAGEABLE_DEVICE));
	if(pxMatch_Manage_Dev == NULL){
		return ERR_OUT_OF_MEMORY;
	}

	
	iFlags = IFX_F_GET_ANY;


	iRet=ifx_get_all_manageable_devices(&uiNumOfEntries, &paxManage_Dev,iFlags);	

	if(iRet != IFX_SUCCESS)
	{
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d ifx_get_all_manageable_devices ret failed!\n", __func__, __LINE__);
		goto errorHandler;
	}

	pxTemp = paxManage_Dev;

	
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_LOW,
                          		 "NoOfEntries=%d !\n",uiNumOfEntries);
	
	for(i=0;i< uiNumOfEntries; i++)
	{
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_LOW,
	                          		 "API_Cpeid=%d !\n",pxTemp->iid.cpeId.Id);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_LOW,
	                          		 "Module_Cpeid=%d !\n",iCpeid);
		
		if(pxTemp != NULL)
		{
			if(pxTemp->iid.cpeId.Id== iCpeid)
			{	
				//Memcopy the struct
				iGotValue = 1;
				memcpy(pxMatch_Manage_Dev, pxTemp,sizeof(MANAGEABLE_DEVICE));
				*ppxManageDevice=pxMatch_Manage_Dev;
				break;
			}
			pxTemp = pxTemp + 1;
		}

	}


	if(iGotValue == 1)
	{	
		
		IFIN_CWMP_FREE(paxManage_Dev);
				
		return IFIN_CWMP_SUCCESS;
	} 

	errorHandler:

		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                       		 "%s:%d failed!\n", __func__, __LINE__);
		
		IFIN_CWMP_FREE(paxManage_Dev);
		IFIN_CWMP_FREE(pxMatch_Manage_Dev);	

		return IFIN_CWMP_FAILURE;
	
}



/* 
** =============================================================================
**   Function Name    : IFX_ManageableDeviceGetValue
**   Description        : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes                : 
**
** ============================================================================
*/
static int32 
IFX_ManageableDeviceGetValue(IN OperInfo *pxOperInfo,INOUT ParamVal *pxGetParamVal,
								IN uint32 iElements)
{
	/*GET PARAMETER VALUES
	**Get Object OID(skip parameter ID) from the first 
	**element in the array.Get Cpeid for this Object OID

	**Get the object from the system using a Platform API
	**with cpeid 
	
	**Do reverse mapping to convert system values into TR69
	**Values.After conversion stores the values in temp storage

	**While assigning the values as per request store the 
	**values in heap and assign the ptr to the struct
	**Return all the values 
	*/


	uint32 i=0;
	int32 iParamId=0;
	uint32 uiParamPos=0;
	int32 iRet=0;
	uint32 uiCpeid = 0;
	uint32 uiMode=IFX_CHK_VALUE_BASED;
	int32 iStrLen;
	MANAGEABLE_DEVICE *pxManageable_device = NULL;
	
	//Get the Cpeid 
	iRet = IFX_GetCpeId(pxGetParamVal->iaOID,&uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	
 	//pxManageable_device->iid.cpeId.Id = uiCpeid;
	//uiflags=IFX_F_GET_ANY;
	
	iRet = IFX_GetManageableDevice(&pxManageable_device, uiCpeid);
	if(iRet != IFX_SUCCESS)
	    goto errorHandler;

	//Fill the parameters and pass it back
	
	//Get the WanIpConParamPos 
	uiParamPos = IFX_GetParamIdPos(pxGetParamVal->iaOID);

			
	for(i=0;i < iElements; i++)
	{
	
		iParamId = pxGetParamVal->iaOID[uiParamPos];
	
		// Malloc and assign the pointer to the Value attr of struct 
		pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);
		if(pxGetParamVal->Value == NULL){
			iRet = ERR_OUT_OF_MEMORY ;
			goto errorHandler;
		}

		switch(iParamId)
		{

			// Convert the value - reverse mapping
			// Assign the correct value to the Value attr	
	    		case OID_IGD_MS_MD_MANUFACTUREROUI:
				
				strcpy(pxGetParamVal->Value,pxManageable_device->oui);				
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;	 
					
	    		case OID_IGD_MS_MD_PRODUCTCLASS:
				strcpy(pxGetParamVal->Value,pxManageable_device->product_class);
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
				
			case OID_IGD_MS_MD_SERIALNUMBER:
				strcpy(pxGetParamVal->Value,pxManageable_device->serial_number);
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
			
			case OID_IGD_MS_MD_X_AC9A96_IPADDRESS:
                                iStrLen = strlen(pxManageable_device->ipaddr);
                                if(iStrLen >= PARAMVALUE_LEN)
                                    iStrLen = PARAMVALUE_LEN -1;

				strncpy(pxGetParamVal->Value, pxManageable_device->ipaddr, iStrLen);
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;             
				
			default:
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "Invalid param id %d!\n", iParamId);
			pxGetParamVal->iFaultCode=ERR_INVAL_PARAMETER_NAME;
			break;
		}

							
			++pxGetParamVal;
	}

		IFX_CWMP_FREE(pxManageable_device);
		return IFX_CWMP_SUCCESS;
		
		errorHandler:
			IFX_CWMP_FREE(pxManageable_device);
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d failed!\n", __func__, __LINE__);
			return iRet;
			

}


/* 
** =============================================================================
**   Function Name    : IFX_ManageableDeviceSetValue
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

static int32
IFX_ManageableDeviceSetValue(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
							IN int32 iElements)
{

	uint32 uiCpeid=0;
	int32 iRet=IFX_CWMP_SUCCESS;
	uint32 uiflags = 0, i = 0;
	uint32 uiParamPos = 0;
	MANAGEABLE_DEVICE *pxManageable_device = NULL;
	ParamVal *pxTmpPramVal = NULL;
	uint32 uioper = 0;
	
	//Initialize the structs
	//memset(&xManageable_device,'\0',sizeof(MANAGEABLE_DEVICE));

	if (pxOpInfo->iCaller != ACC_ROOT)
       {
            //(pxParamVal[iCnt]).iFaultCode = ERR_NON_WRITABLE;
                iRet = ERR_NON_WRITABLE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%d] [%d] Cannot modify the parameter\n",
                            __func__, __LINE__, iRet);
                goto errorHandler;
        }

	//Get the Cpeid from Tr69 id
	iRet = IFX_GetCpeId(paxParamVal->iaOID,&uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	//Get the object from system
	iRet = IFX_GetManageableDevice(&pxManageable_device, uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);
	
	pxTmpPramVal = paxParamVal;
	
	for (i=0; i < iElements; i++) 
	{

	      	switch(pxTmpPramVal->iaOID[uiParamPos])
		{

			case OID_IGD_MS_MD_MANUFACTUREROUI:
				 /* Check if the string fits in the buffer */
	                if ((strlen(pxTmpPramVal->Value) + 1) > MAX_OUI_LEN)
	                {
	                    pxTmpPramVal->iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
	                    iRet = ERR_CWMP_BUFFER_OVERFLOW;
	                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                                "[%s:%s:%d] [%d] Space not enough to hold "
	                                "requested value",__FILE__, __func__,
	                                __LINE__, iRet);
				goto errorHandler;
	                }

	                /* Copy the string */
	                strcpy(pxManageable_device->oui,pxTmpPramVal->Value);
			break;

			case OID_IGD_MS_MD_PRODUCTCLASS:
			
	                /* Check if the string fits in the buffer */
	                if ((strlen(pxTmpPramVal->Value) + 1) > MAX_PROD_CLASS_LEN)
	                {
	                    pxTmpPramVal->iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
	                    iRet = ERR_CWMP_BUFFER_OVERFLOW;
	                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                                "[%s:%s:%d] [%d] Space not enough to hold "
	                                "requested value",__FILE__, __func__,
	                                __LINE__, iRet);
				goto errorHandler;
	                }

	                /* Copy the string */
	                strcpy(pxManageable_device->product_class, pxTmpPramVal->Value);
			break;

			case OID_IGD_MS_MD_SERIALNUMBER:
			/* Check if the string fits in the buffer */
	                if ((strlen(pxTmpPramVal->Value) + 1) > MAX_SERIAL_NUM_LEN)
	                {
	                    pxTmpPramVal->iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
	                    iRet = ERR_CWMP_BUFFER_OVERFLOW;
	                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                                "[%s:%s:%d] [%d] Space not enough to hold "
	                                "requested value",__FILE__, __func__,
	                                __LINE__, iRet);
				goto errorHandler;
	                }
			
	                /* Copy the string */
	                strcpy(pxManageable_device->serial_number, pxTmpPramVal->Value);
			break;

			case OID_IGD_MS_MD_X_AC9A96_IPADDRESS:
			/* Check if the string fits in the buffer */
	                if ((strlen(pxTmpPramVal->Value) + 1) > MAX_IPADDR_LIST_LEN)
	                {
	                    pxTmpPramVal->iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
	                    iRet = ERR_CWMP_BUFFER_OVERFLOW;
	                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                                "[%s:%s:%d] [%d] Space not enough to hold "
	                                "requested value",__FILE__, __func__,
	                                __LINE__, iRet);
				goto errorHandler;
	                }
			
	                /* Copy the string */
	                strcpy(pxManageable_device->ipaddr, pxTmpPramVal->Value);
			break;
			
	  	}

		pxTmpPramVal++;
		
	}

	uioper=IFX_OP_MOD;
	uiflags=(IFX_F_MODIFY| IFX_F_DONT_CHECKPOINT|IFX_F_DONT_WRITE_TO_FLASH);
	pxManageable_device->iid.cpeId.Id=uiCpeid;
	//pxManageable_device->iid.config_owner = pxOpInfo->iCaller;
	pxManageable_device->iid.config_owner = IFX_TR69;
	
	iRet = ifx_set_manageable_device(uioper, pxManageable_device, uiflags);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	IFX_CWMP_FREE(pxManageable_device);
	return IFX_CWMP_SUCCESS;

	errorHandler:
		IFX_CWMP_FREE(pxManageable_device);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                                "[%s:%s:%d] [%d] ManageableDevice SetParamValues failed "
	                                ,__FILE__, __func__, __LINE__, iRet);
		return iRet;
	

}

/* 
** =============================================================================
**   Function Name    : IFX_ManageableDeviceAddObj
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_ManageableDeviceAddObj(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
							IN int32 iElements)
{

	//uint32 uiCpeid=0;
	int32 iRet=IFX_CWMP_SUCCESS;
	uint32 uiflags = 0, i = 0;
	uint32 uiParamPos = 0;
	MANAGEABLE_DEVICE xManageable_device;
	ParamVal *pxTmpPramVal = NULL;
	uint32 uioper = 0;
	
	//Initialize the structs
	memset(&xManageable_device,'\0',sizeof(MANAGEABLE_DEVICE));

	if (pxOpInfo->iCaller != ACC_ROOT)
       {
            //(pxParamVal[iCnt]).iFaultCode = ERR_NON_WRITABLE;
                iRet = ERR_INTERNAL_ERROR;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%d] [%d] Cannot Add this object \n",
                            __func__, __LINE__, iRet);
                goto errorHandler;
        }

	//TODO::Check for duplicate object before adding
	
	uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);
	
	pxTmpPramVal = paxParamVal;
	
	for (i=0; i < iElements; i++) 
	{

	      	switch(pxTmpPramVal->iaOID[uiParamPos])
		{

			case OID_IGD_MS_MD_MANUFACTUREROUI:
				 /* Check if the string fits in the buffer */
	                if ((strlen(pxTmpPramVal->Value) + 1) > MAX_OUI_LEN)
	                {
	                    pxTmpPramVal->iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
	                    iRet = ERR_CWMP_BUFFER_OVERFLOW;
	                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                                "[%s:%s:%d] [%d] Space not enough to hold "
	                                "requested value",__FILE__, __func__,
	                                __LINE__, iRet);
				goto errorHandler;
	                }

	                /* Copy the string */
	                strcpy(xManageable_device.oui,pxTmpPramVal->Value);
			break;

			case OID_IGD_MS_MD_PRODUCTCLASS:
			
	                /* Check if the string fits in the buffer */
	                if ((strlen(pxTmpPramVal->Value) + 1) > MAX_PROD_CLASS_LEN)
	                {
	                    pxTmpPramVal->iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
	                    iRet = ERR_CWMP_BUFFER_OVERFLOW;
	                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                                "[%s:%s:%d] [%d] Space not enough to hold "
	                                "requested value",__FILE__, __func__,
	                                __LINE__, iRet);
				goto errorHandler;
	                }

	                /* Copy the string */
	                strcpy(xManageable_device.product_class, pxTmpPramVal->Value);
			break;

			case OID_IGD_MS_MD_SERIALNUMBER:
			/* Check if the string fits in the buffer */
	                if ((strlen(pxTmpPramVal->Value) + 1) > MAX_SERIAL_NUM_LEN)
	                {
	                    pxTmpPramVal->iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
	                    iRet = ERR_CWMP_BUFFER_OVERFLOW;
	                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                                "[%s:%s:%d] [%d] Space not enough to hold "
	                                "requested value",__FILE__, __func__,
	                                __LINE__, iRet);
				goto errorHandler;
	                }

	                /* Copy the string */
	                strcpy(xManageable_device.serial_number, pxTmpPramVal->Value);
			break;

			case OID_IGD_MS_MD_X_AC9A96_IPADDRESS:
			/* Check if the string fits in the buffer */
	                if ((strlen(pxTmpPramVal->Value) + 1) > MAX_SERIAL_NUM_LEN)
	                {
	                    pxTmpPramVal->iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
	                    iRet = ERR_CWMP_BUFFER_OVERFLOW;
	                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                                "[%s:%s:%d] [%d] Space not enough to hold "
	                                "requested value",__FILE__, __func__,
	                                __LINE__, iRet);
				goto errorHandler;
	                }

	                /* Copy the string */
	                strcpy(xManageable_device.ipaddr, pxTmpPramVal->Value);
			break;

	  	}

		pxTmpPramVal++;
		
	}

	uioper=IFX_OP_ADD;
	uiflags=(	IFX_F_DONT_ACTIVATE|IFX_F_DONT_CHECKPOINT|
			IFX_F_DONT_VALIDATE|IFX_F_DONT_WRITE_TO_FLASH);
	//xManageable_device.iid.cpeId.Id=uiCpeid;
	//pxManageable_device->iid.config_owner = pxOpInfo->iCaller;
	xManageable_device.iid.config_owner = IFX_TR69;

	iRet = IFX_ConvertOidDottedForm(paxParamVal->iaOID, xManageable_device.iid.tr69Id);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	iRet = ifx_set_manageable_device(uioper, &xManageable_device, uiflags);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	
	return IFX_CWMP_SUCCESS;

	errorHandler:
		
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                                "[%s:%s:%d] [%d] ManageableDevice Add object  failed "
	                                ,__FILE__, __func__, __LINE__, iRet);
		return iRet;
	


}


/* 
** =============================================================================
**   Function Name    : IFX_ManageableDeviceSetCommit
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_ManageableDeviceSetCommit()
{
	return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_ManageableDeviceSetUndo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_ManageableDeviceSetUndo()
{
	return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_ManageableDeviceSetDelete
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_ManageableDeviceSetDelete(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
							IN int32 iElements, OUT void **ppxParamStructRet,
												   OUT int32 * piNumRetElem)
{
	uint32 uiCpeid=0;
	int32 iRet=IFX_CWMP_SUCCESS;
	uint32 uiflags = 0;
	MANAGEABLE_DEVICE *pxManageable_device = NULL;
	uint32 uioper = 0;
	
	//Initialize the structs
	//memset(&xManageable_device,'\0',sizeof(MANAGEABLE_DEVICE));

	if (pxOpInfo->iCaller != ACC_ROOT)
       {
            //(pxParamVal[iCnt]).iFaultCode = ERR_NON_WRITABLE;
                iRet = ERR_NON_WRITABLE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%d] [%d] Cannot modify the parameter\n",
                            __func__, __LINE__, iRet);
                goto errorHandler;
        }

	switch(pxOpInfo->iSubOper)
	{
		case OP_SETVAL_CHK_DEL_ALLOWED:
			
		return IFX_CWMP_SUCCESS;
	}
	
	//Get the Cpeid from Tr69 id
	iRet = IFX_GetCpeId(paxParamVal->iaOID,&uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	//Get the object from system
	iRet = IFX_GetManageableDevice(&pxManageable_device, uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
		
	uioper=IFX_OP_DEL;
	uiflags=(IFX_F_DELETE|IFX_F_DONT_VALIDATE|
			IFX_F_DONT_CHECKPOINT|IFX_F_DONT_WRITE_TO_FLASH);
	pxManageable_device->iid.cpeId.Id=uiCpeid;
	//pxManageable_device->iid.config_owner = pxOpInfo->iCaller;
	pxManageable_device->iid.config_owner = IFX_TR69;
	memset( pxManageable_device->iid.tr69Id,0x00,MAX_TR69_ID_LEN);
	
	iRet = ifx_set_manageable_device(uioper, pxManageable_device, uiflags);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	IFX_CWMP_FREE(pxManageable_device);
	return IFX_CWMP_SUCCESS;

	errorHandler:
		IFX_CWMP_FREE(pxManageable_device);
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                                "[%s:%s:%d] [%d] ManageableDevice Delete Object failed "
	                                ,__FILE__, __func__, __LINE__, iRet);
		return iRet;
	
}

/* 
** =============================================================================
**   Function Name    : IFX_ManageableDeviceSetFree
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_ManageableDeviceSetFree()
{
	return IFX_CWMP_SUCCESS;
}


/* 
** =============================================================================
**   Function Name    : IFX_ManageableDeviceSetAttr
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

static int32
IFX_ManageableDeviceSetAttr(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{
	uint32 iRet = IFX_CWMP_SUCCESS, i = 0;
	OperInfo xOpInfo;
	
	xOpInfo.iCaller = pxOpInfo->iCaller;
	xOpInfo.iOper= OP_GETVAL;
	xOpInfo.iSubOper= OP_GETVAL_NORMAL;
	
	iRet = IFX_ManageableDeviceGetValue(&xOpInfo,pxParamVal, iElements);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorFreeHandler;
	
	iRet = IFX_SetAttributesInfo(pxOpInfo,pxParamVal, iElements);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;

	for(i=0; i < iElements; i++)
		IFX_CWMP_FREE(pxParamVal[i].Value);

	return IFX_CWMP_SUCCESS;

	errorFreeHandler:
		 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d failed!\n", __func__, __LINE__);
		for(i=0; i < iElements; i++)
		IFX_CWMP_FREE(pxParamVal[i].Value);
		
	errorHandler:
		 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d failed!\n", __func__, __LINE__);
		return IFX_CWMP_FAILURE;
		


}



/* 
** =============================================================================
**   Function Name    : IFX_ManageableDevice_Init
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_ManageableDevice_Init(void)
{
	int32 iRet = IFX_CWMP_SUCCESS;

    
	/* Register the ManageableDevice module function pointer in the object model */
	iRet = ifx_ds_register_function(IFX_MANAGEABLE_DEVICE_OBJ, IFX_ManageableDevice);
	
	/* Check for error */
	if (iRet != IFX_CWMP_SUCCESS)
	{
	    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                "Unable to Register %s with Object Model\n",
	                 IFX_MANAGEABLE_DEVICE_OBJ);
	    goto errorHandler;
	}


	errorHandler:
			return iRet;
}

/*********************************************************************************
*  Function Name	:  IFX_ManageableDevice   
      *  Description	:  This function handles all the sub-states inside
      	 		   a GET/SET operation.If it is a GET it allocates the 
			   array(Name,Value pairs) and retruns the values.
			   If it is a SET controller allocates the array and
			   passes the values to this function.It calls 
			   respective internal functions which in turn calls 
			   respective Platform APIs.
                                                                                                 
*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
							     Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has 
					  	             Name,Value,etc
                    IN          int32	       iElements;    No. of Elements
		    OUT	        void *	       ppParamRet;   same as ParamStruc
		    OUT         int32 *        piNumRetElem; No. of elements 		                                
*  Return Value        : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes               :
***********************************************************************************/
int32
IFX_ManageableDevice(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                IN int32 iElements, OUT void **ppaxParamArrRet, OUT int32 *piNumRetElem)
{
     
   //It calls the respective internal functions which handles resp. sub-operation
   
   //Set-Operation  
   //controller should pass the entire array during all the SET-sub_operations
   //It should handles only single get/set of instance at any point of time
   //It does not handle partial path
   //It won't handle multiple instances of the same object/module
   //at any point of time.

    
   int32 iRet = 0;
   ParamVal *paxParamArr = (ParamVal *)paxParameterArr;

   switch (pxOperInfo->iOper) 
   {
	   //Get the object values
	   case OP_GETVAL:
       {
		   if((iRet = IFX_ManageableDeviceGetValue(pxOperInfo, paxParamArr,
						   iElements)) != IFX_CWMP_SUCCESS) {
			   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
					   "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
			   goto errorHandler;
		   }
		   break;
       }
	   case OP_SETVAL:
       {
		   //Set the obj values
		   switch (pxOperInfo->iSubOper) 
		   {
			   case OP_SETVAL_VALIDATE:

				   break;
			   case OP_SETVAL_ADD:

				   if((iRet= IFX_ManageableDeviceAddObj(pxOperInfo,paxParamArr,
								   iElements))!=IFX_CWMP_SUCCESS)
				   {
					   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
							   "%s:%d OP_SETVAL_ADD failed!\n", __func__, __LINE__);
					   goto errorHandler;
				   }
				   break;
			   case OP_SETVAL_CHK_MODIFY_DEP:
				   break;

			   case OP_SETVAL_MODIFY:
				   if((iRet = IFX_ManageableDeviceSetValue(pxOperInfo,paxParamArr,
								   iElements)) != IFX_CWMP_SUCCESS) {
					   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
							   "%s:%d OP_SETVAL_VALUE failed!\n", __func__, __LINE__);
					   goto errorHandler;
				   }
				   break;

			   case OP_SETVAL_COMMIT:
				   if((iRet = IFX_ManageableDeviceSetCommit(pxOperInfo,paxParamArr,
								   iElements)) != IFX_CWMP_SUCCESS) {
					   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
							   "%s:%d OP_SETVAL_COMMIT failed!\n", __func__, __LINE__);
					   goto errorHandler;
				   }
				   break;
			   case OP_SETVAL_UNDO:
				   if((iRet =IFX_ManageableDeviceSetUndo(pxOperInfo, paxParamArr,
								   iElements)) != IFX_CWMP_SUCCESS) {
					   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
							   "%s:%d OP_SETVAL_UNDO failed!\n", __func__, __LINE__);
					   goto errorHandler;
				   }
				   break;
			   case OP_SETVAL_CHK_DEL_DEP:
				   *ppaxParamArrRet = (ParamVal *)IFX_CWMP_MALLOC(sizeof(ParamVal));
				   if(*ppaxParamArrRet == NULL)
					   return ERR_OUT_OF_MEMORY ;

				   memcpy(*ppaxParamArrRet, paxParameterArr, sizeof(ParamVal));
				   *piNumRetElem = 1;
				   break;
			   case OP_SETVAL_CHK_DEL_ALLOWED:
			   case OP_SETVAL_DELETE:
				   if((iRet= IFX_ManageableDeviceSetDelete(pxOperInfo, paxParamArr,
								   iElements, ppaxParamArrRet,
								   piNumRetElem))!= IFX_CWMP_SUCCESS) 
				   {

					   switch(pxOperInfo->iSubOper)
					   {	
						   case OP_SETVAL_CHK_DEL_DEP:
							   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
									   "%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
							   goto errorHandler;
						   case OP_SETVAL_CHK_DEL_ALLOWED:
							   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
									   "%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
							   goto errorHandler;
						   case OP_SETVAL_DELETE:
							   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
									   "%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
							   goto errorHandler;
					   }
				   }
				   break;
			   case OP_SETVAL_FREE:
				   IFX_ManageableDeviceSetFree(pxOperInfo);
				   break;

			   case OP_SETVAL_ATTRINFO:
				   if((iRet =IFX_ManageableDeviceSetAttr(pxOperInfo, paxParamArr,
								   iElements)) != IFX_CWMP_SUCCESS) {
					   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
							   "%s:%d OP_SETVAL_ATTRINFO failed!\n", __func__, __LINE__);
					   goto errorHandler;
				   }
				   break;


			   default:
				   break;
		   }
		   break;

       }
	   case OP_UPDATE_CHILDINFO:
       {
		   //Updation of child related info is handled by the case
		   switch(pxOperInfo->iSubOper)
		   {
			   case OP_UPDATE_CHILDINFO_ADD:
			   case OP_UPDATE_CHILDINFO_DEL:
				   if((iRet =IFX_ManageableDevice_UpdateChildInfo(pxOperInfo, paxParamArr,iElements)) != IFX_CWMP_SUCCESS)
				   {
					   switch(pxOperInfo->iSubOper)
					   {	
						   case OP_UPDATE_CHILDINFO_ADD:
							   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
									   "%s:%d OP_UPDATE_CHILDINFO_ADD failed!\n", __func__, __LINE__);
							   goto errorHandler;

						   case OP_UPDATE_CHILDINFO_DEL:
							   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
									   "%s:%d OP_UPDATE_CHILDINFO_DEL failed!\n", __func__, __LINE__);
							   goto errorHandler;

					   }
				   }
		   }
		   break;
        }
        case OP_PARAM_VALIDATE:
        {
            break; 
        }

	   default:
		   /*printf(stderr, "%s:%d Error! In Default case\n", __func__,\
		   //       __LINE__);
		   //exit(EXIT_FAILURE); */
		   break;
   }
   return IFX_CWMP_SUCCESS;

	errorHandler:
		return IFX_CWMP_FAILURE;
			
}
 
