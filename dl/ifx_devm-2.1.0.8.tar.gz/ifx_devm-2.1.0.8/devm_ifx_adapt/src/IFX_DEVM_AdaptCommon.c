/* 
** =============================================================================
** FILE NAME     : IFX_MOD_Common.c
** PROJECT       : TR69
** MODULES       : Common Functions
** DATE          : 15-06-2006
** AUTHOR        : TR69 team
** DESCRIPTION   : This module has common uitlity functions which might 
**                 be used by various other modules in the system.
**
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author        $Comment
** 28-04-2006  TR69 team      Intial version 
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/

#include <time.h>
#include <ctype.h>
#include <unistd.h>
#include <signal.h>
#include "IFX_DEVM_AdaptCommon.h"
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
 
#include "IFX_DEVM_StackUtil.h"

#include "IFX_DEVM_QueueMgmt.h"
#include "IFX_DEVM_QMClassify.h"
#include "IFX_DEVM_QMPolicer.h"
#include "IFX_DEVM_QMQueue.h"


#define MAX_FIRMWARE_DL_FILESIZE ((1024*1024*CONFIG_IFX_CONFIG_FLASH_SIZE) - (64*1024))   //maximum file size that can be downloaded
#define MIN_FIRMWARE_DL_FILESIZE (512*1024)
#define MAX_SYSCONF_DL_FILESIZE (72 * 1024)
#define MIN_SYSCONF_DL_FILESIZE (3 * 1024)

#ifdef STUNNEL_SSL
#define LINESIZE        265
#define TOKEN           "=\n"
#endif

int giStunnelProcess=0;
static int g_ssl_pid[2] = { -1, -1 };

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/

extern uchar8 vcOsModId;
extern int32 ifx_set_wan_conn_dev_stub(int32 operation,WAN_CONN_DEV *xWanConDev,int32 iFlags);
extern int32 IFX_GatewayInfo_Init();
extern int32 IFX_LAN_Init();
extern int32 IFX_Device_Init();
extern int32 IFX_IGD_Init();
extern int32 IFIN_Layer3Forwawrding_Init();
extern int32 IFX_LANDeviceInit();
extern int32 IFX_LANIf_Init();
extern int32 IFX_DHCPOption_Init();
extern int32 IFX_LHCMIPInterfaceInit();
extern int32 IFX_LANEthernetIfCfg_Init();
extern int32 IFX_LANEthernetIfCfgStatsInit();
extern int32 IFX_LANUSBIfCfg_Init();
extern int32 IFX_LANUSBIfCfgStatsInit();
extern int32 IFX_LANHostCfgMgmtInit();
extern int32 IFX_DHCPCondServ_Init();
extern int32 IFX_DHCPStaticAddr_Init();
extern int32 IFX_WanDslLinkConfig_Init();
extern int32 IFX_WanDevice_Init();
extern int32 IFX_WanConnDevice_Init();
extern int32 IFX_WanIpConnection_Init();
extern int32 IFX_WanIpPortMapping_Init();
extern int32 IFX_WanIpConnStats_Init();
extern int32 IFX_WanPPPConnection_Init();
extern int32 IFX_WanATMF5LoopbackDiagnostics_Init();
extern int32 IFX_WanDslDiagnostics_Init();
extern int32 IFX_ManageableDevice_Init();
extern int32 IFX_WanCommonInterfaceConfig_Init();
#ifndef CONFIG_FEATURE_IFX_TR69_DEVICE
extern int32 IFX_Hosts_Init();
#endif
extern int32 IFX_LANConfigSecurity_Init();
extern int32 IFX_Time_Init();
extern int32 IFX_WanDslInterfaceConfig_Init();
extern int32 IFX_WanDslTestParams_Init();
extern int32 IFX_WanDslStats_Init();
#ifdef CONFIG_FEATURE_IFX_TR69_WANDSLOBJS_FULL
extern int32 IFX_WanDslIfaceStats_Init();
extern int32 IFX_WanDslIfaceStatsLastShowtime_Init();
#endif

extern int32 IFX_WlanKeys_Init();
#ifndef CONFIG_FEATURE_IFX_TR69_DEVICE
extern int32 IFX_WlanAssocDevice_Init();
#endif
extern int32 IFX_WlanConfiguration_Init();
extern int32 IFX_WlanStats_Init();
extern int32 IFX_WlanWps_Init();
extern int32 IFX_WlanWmm_Init();

//firewall objects
extern int32 IFX_Dmz_Init(void);
extern int32 IFX_Firewall_Init(void);

//Objects Common to both IGD and Device 
extern int32 IFX_DevInfo_Init();
extern int32 IFX_MgmtServer_Init();
extern int32 IFX_IPPingDiagInit();

#ifdef IFX_TR69_X_LTQ_IPPROTOCOLVERSION
extern int32 IFX_X_LTQ_IPProtocolVersionInit();
#endif

extern int32 IFX_DeviceConfigInit();

#ifdef IFX_TR157_MEMORYSTATUS
extern int32 IFX_MemoryStatusInit();
#endif

#ifdef IFX_TR157_FIREWALL
extern int32 IFX_TR157_FirewallInit();
#endif

#ifdef IFX_TR157_PROCESSSTATUS
extern int32 IFX_ProcessStatusInit();
#endif

#ifndef DEVICE_SUPPORT
#ifdef IFX_TR157_USERINFO
extern int32 IFX_UserInfoInit();
#endif
#endif

extern int32 IFX_AuthInit();
extern int32 IFX_DownloadAuthInit();
extern int32 IFX_IFXInit();

#ifdef IFX_TR69_ETHERNETWAN
//Ethernet WAN objects
extern int32 IFX_WANEthernetIfCfgInit();
extern int32 IFX_WANEthernetIfCfgStatsInit();
extern int32 IFX_WANEthernetLinkCfgInit();
#endif

#ifdef IFX_TR69_TRACEROUTE
extern int32 IFX_TraceRouteDiagInit();
#endif

#ifdef IFX_TR143_DOWNLOADDIAGNOSTICS
extern int32 IFX_DownloadDiagInit();
#endif

#ifdef IFX_TR143_UPLOADDIAGNOSTICS
extern int32 IFX_UploadDiagInit();
#endif


#ifdef IFX_TR157_NSLOOKUP
extern int32 IFX_NSLookupDiagInit();
#endif

#ifdef IFX_TR157_SELFTEST
extern int32 LTQ_SelfTestDiagInit();
#endif

#ifdef IFX_TR69_PERFORMDIAG
extern int32 LTQ_PerformanceDiagnosticInit();
#endif

#ifdef IFX_TR69_PTMWAN
//PTM WAN objects
extern int32 IFX_WANPTMLinkCfgInit();
extern int32 IFX_WanPTMLinkConfigStats_Init();
#endif

int32 IFX_WANVlanInit(void);

#ifdef IFX_TR104
extern int32   IFX_VoiceService_Init();
extern int32   IFX_VoiceServiceCapabilities_Init();
extern int32   IFX_VoiceServSipCapab_Init();
extern int32   IFX_VoiceServCodecCapab_Init();
extern int32   IFX_VoiceProfile_Init();
extern int32   IFX_ProfileServiceProviderInfo_Init();
extern int32   IFX_ProfileSignaling_Init();
extern int32   IFX_ProfileMediaRtp_Init();
extern int32   IFX_ProfileMediaRtcp_Init();
extern int32   IFX_VoiceLine_Init();
extern int32   IFX_LineSignaling_Init();
extern int32   IFX_LineSignaling_Event_Init();
extern int32   IFX_LineCodec_Init();
extern int32   IFX_LineCodecList_Init();
extern int32   IFX_LineCallingFeatures_Init();
extern int32   IFX_LineVoiceProcessing_Init();
extern int32   IFX_LineSession_Init();
extern int32   IFX_LineStats_Init();
extern int32   IFX_VoiceServPhyIf_Init();
extern int32   IFX_Service_Init();
extern int32   IFX_Profile_NumPlan_Init();
extern int32   IFX_Profile_NumPlan_PrefixInfo_Init();
extern int32   IFX_Profile_FaxT38Init();
extern int32   IFX_Profile_Event_Init();
#endif

#ifdef IFX_TR69_WIFILAN
    int giWifi_lan =1;
#else 
    int giWifi_lan =0;
#endif

#define IFX_ACCESS_CONTROL_SET 1
#define IFX_NOTIFICATION_SET 1

/*
#define WAN_DSL_LINK_DEPTH 6
#define WAN_CON_DEV_DEPTH 4
#define MAX_VAL_LENGTH 24

#define CWMP_REVERSE_MAP 1
#define CWMP_FORWARD_MAP 2
#define SYS_DATATYPE_INT 1
#define SYS_DATATYPE_CHAR 2
#define OID_CHAR_LENGTH (OID_LENGTH * 10)

*/
/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/
/*
typedef struct map_value
{
	uchar8 sTR69_Value[MAX_VAL_LENGTH];
	uint32  uiSys_DataType;

		union system_value
			{
			uchar8 sSys_Value[MAX_VAL_LENGTH];
			uint32  uiSys_Value;
			}uxSys_Val;

}Map_Value;



#ifdef IFX_TR69_WAN_MODS_TEST_STUBS

extern int32 IFX_GetCpeIdFromTr69Id_stub(char8 * Tr69Id,uint32 *puiNumCpeId,IFX_CpeId **ppxCpeIdArray);

#endif

*/
 Map_Value gaxWanDiagnosticState[]={
{"Requested",SYS_DATATYPE_INT,{.uiSys_Value=WAN_DIAG_REQUESTED}},
{"None",SYS_DATATYPE_INT,{.uiSys_Value=WAN_DIAG_NONE}},
{"Complete",SYS_DATATYPE_INT, {.uiSys_Value=WAN_DIAG_COMEPLETE}},
{"Error_Internal",SYS_DATATYPE_INT, {.uiSys_Value=WAN_DIAG_ERROR_INT}},
{"Error_Other",SYS_DATATYPE_INT, {.uiSys_Value=WAN_DIAG_ERROR_EXT}},
{"Requested",SYS_DATATYPE_INT, {.uiSys_Value=WAN_DIAG_START_DIAGNOSING}},
{"Requested",SYS_DATATYPE_INT, {.uiSys_Value=WAN_DIAG_STILL_DIAGNOSING}}
};


Map_Value gaxEnable[]={
    {"true", SYS_DATATYPE_INT, {.uiSys_Value = IFX_ENABLED}},
    {"false", SYS_DATATYPE_INT, {.uiSys_Value =IFX_DISABLED}},
    {"1", SYS_DATATYPE_INT, {.uiSys_Value =IFX_ENABLED}},
    {"0", SYS_DATATYPE_INT, {.uiSys_Value =IFX_DISABLED}}
};

Map_Value saxAttrAccessCtrl[]={
    {" ", SYS_DATATYPE_UCHAR, {.ucSys_Value = IFX_ACL_NOT_ALLOWED}},
    {"Subscriber", SYS_DATATYPE_UCHAR, {.ucSys_Value =IFX_ACL_ALLOWED}}
};

Map_Value saxAttrNotify[]={
    {"0", SYS_DATATYPE_UCHAR, {.ucSys_Value = IFX_NOTIFY_NOT}},
    {"1", SYS_DATATYPE_UCHAR, {.ucSys_Value =IFX_NOTIFY_PASSIVE}},
    {"2", SYS_DATATYPE_UCHAR, {.ucSys_Value =IFX_NOTIFY_ACTIVE}}
};

/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/

#ifdef MIPSTARGET
#ifndef SPI_SUPPORT
//static void ifx_http_remove_modules();
#endif /* SPI_SUPPORT */ 
#endif


/* 
** =============================================================================
**   Function Name    : IFX_PrintOID
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32 IFX_GetCpeIdFromTr69Id_stub(IN char8 sTr69Id[IFX_MAX_TR69_ID_LEN],
                             OUT uint32 *puiNumCpeId,
                             OUT IFX_CpeId **ppxCpeIdArray)
{
    IFX_CpeId *Temp_Cpeid=NULL;
    int32 iRet=0;

    *puiNumCpeId = 1;
    //Temp_Cpeid = calloc(1,sizeof(IFX_CpeId));
    Temp_Cpeid = IFX_CWMP_MALLOC(sizeof(IFX_CpeId));
    if(Temp_Cpeid == NULL){
        iRet = ERR_OUT_OF_MEMORY;
        goto errorHandler;
    }

    Temp_Cpeid->uiId = 2;
    *ppxCpeIdArray = Temp_Cpeid;

    return IFX_SUCCESS;

    errorHandler:
        return iRet;
}


int32
IFX_PrintOID(int32 *paiArr_Oid)
{
    uint32 i=0;
    int32 *paiTemp_OID=NULL;
    uint32 Oid_Depth=0;
    //uchar8 sTemp[OID_CHAR_LENGTH];

    //memset(psOid_str,'\0',strlen(psOid_str));
    Oid_Depth=IFX_GetParamIdPos(paiArr_Oid);
    paiTemp_OID=paiArr_Oid;

    if(Oid_Depth == 0)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d OID depth is Zero failed!\n", _FUNCL_);
        //goto errorHandler;
    }

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"OID::");

    for(i=0; i <= OID_LENGTH; ++i)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"%d.",paiTemp_OID[i]);
        //strcat(psOid_str,sTemp);
    }

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"\n");
    return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_GetParamIdPos
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/


int32
IFX_GetParamIdPos(IN int32 *paiOID)
{
    int32 iCnt=0;

    for (iCnt = 0; ((iCnt < OID_LENGTH) && (paiOID[iCnt] != 0)); iCnt++);

    return (iCnt - 1);
}


/* 
** =============================================================================
**   Function Name    : IFX_MappingValues
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

uint32 
IFX_MappingValues(IN uint32 uiDirFlags, IN Map_Value *axMap_arr,
                  IN uint32 iNoElements, IN void* psElement,OUT void* pValue)
{
	uint32 i=0;
	uint32 iFlag=0;

	for(i=0; i < iNoElements;++i)
	{

		if(uiDirFlags == CWMP_FORWARD_MAP)
		{

			if(strcasecmp(axMap_arr->sTR69_Value,(char8 *)psElement)==0)
			{
				iFlag=1;

				if(axMap_arr->uiSys_DataType == SYS_DATATYPE_INT)
				{

					*(int32 *)pValue = axMap_arr->uxSys_Val.uiSys_Value;

				}else if(axMap_arr->uiSys_DataType == SYS_DATATYPE_CHAR)
				{

					strcpy((char8 *)pValue,axMap_arr->uxSys_Val.sSys_Value);
				}
				else if(axMap_arr->uiSys_DataType == SYS_DATATYPE_UCHAR)
				{
					*(uchar8 *)pValue = axMap_arr->uxSys_Val.ucSys_Value;

				}
				else
					IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_LOW,
							"Incorrect data type\n");
				break;
			}
		} else if(uiDirFlags == CWMP_REVERSE_MAP)
		{

			if(axMap_arr->uiSys_DataType == SYS_DATATYPE_CHAR)
			{
				if(strcasecmp(axMap_arr->uxSys_Val.sSys_Value,(char8 *)psElement)==0)
				{
					iFlag=1;
					strcpy((char8 *)pValue,axMap_arr->sTR69_Value);
					break;
				}
			}else if(axMap_arr->uiSys_DataType == SYS_DATATYPE_INT)
			{
				if(axMap_arr->uxSys_Val.uiSys_Value == (*(int32 *)psElement))
				{
					iFlag=1;
					strcpy((char8 *)pValue,axMap_arr->sTR69_Value);
					break;
				}
			}else if(axMap_arr->uiSys_DataType == SYS_DATATYPE_UCHAR)
			{
				if(axMap_arr->uxSys_Val.ucSys_Value == (*(uchar8 *)psElement))
				{
					iFlag=1;
					strcpy((char8 *)pValue,axMap_arr->sTR69_Value);
					break;
				}
			}
		}

		++axMap_arr;

	}


	if(iFlag)
	{
		return IFIN_CWMP_SUCCESS;

	} else
	{
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			"F/R Mapping value did not match\n");
		return IFIN_CWMP_FAILURE;
	}
}

/* 
** =============================================================================
**   Function Name    : IFX_FwdMappingValues
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_FwdMappingValues(IN Map_Value *axMap_arr, IN uint32 iNoElements,
                     IN void* psElement,OUT void* pValue)
{
    int32 iRet;

    iRet = IFX_MappingValues(CWMP_FORWARD_MAP, axMap_arr, iNoElements,
                             psElement, pValue);
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_RevMappingValues
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

int32
IFX_RevMappingValues(IN Map_Value *axMap_arr, IN uint32 iNoElements,
                     IN void* psElement,OUT void* pValue)
{
    int32 iRet;

    iRet = IFX_MappingValues(CWMP_REVERSE_MAP, axMap_arr, iNoElements,
                             psElement, pValue);
    return iRet;
}



/* 
** =============================================================================
**   Function Name    : IFX_ConvertObjOidDottedForm
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

int32
IFX_ConvertObjOidDottedForm(int32 *paiArr_Oid,char8 *psOid_str)
{
    uint32 i=0;
    int32 *paiTemp_OID=paiArr_Oid;
    uint32 Oid_Depth=0;
    char8 sTemp[OID_CHAR_LENGTH]={0};

    memset(psOid_str,'\0',strlen(psOid_str));
    Oid_Depth=IFX_GetParamIdPos(paiArr_Oid);

    if(Oid_Depth == 0)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d Oid depth is Zero failed!\n", _FUNCL_);
        goto errorHandler;
    }

    for(i=0; i <= Oid_Depth  ; ++i)
    {
        sprintf(sTemp,"%d.",paiTemp_OID[i]);
        strcat(psOid_str,sTemp);

    }

    return IFIN_CWMP_SUCCESS;

    errorHandler:
        return IFX_CWMP_FAILURE;
}

/* 
** =============================================================================
**   Function Name    : IFX_GetObjCpeId
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

int32
IFX_GetObjCpeId(IN int32 *aiOID,OUT uint32 *iCpeid)
{
    //Convert the object ID into dotted form
    //Get Cpeid by calling a mapping Protocol API

    char8 sObj_Id[OID_CHAR_LENGTH]={0};
    uint32 iRet=IFX_CWMP_SUCCESS;
    uint32 uiNumCpeId=0;
    IFX_CpeId *pxCpeIdArray=NULL;

    //Convert into dotted form
    iRet=IFX_ConvertObjOidDottedForm(aiOID,sObj_Id);
    if(iRet != IFIN_CWMP_SUCCESS)
        goto errorHandler;

#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
    iRet = IFX_GetCpeIdFromTr69Id_stub(sObj_Id, &uiNumCpeId, &pxCpeIdArray);
#else
    //Get Cpeid using the mapping API
    iRet = IFX_GetCpeIdFromTr69Id(sObj_Id, &uiNumCpeId, &pxCpeIdArray);
#endif
    if((uiNumCpeId > 0) && (iRet == IFIN_CWMP_SUCCESS))
        *iCpeid = pxCpeIdArray->uiId;
    else
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d IFX_GetCpeIdFromTr69Id failed!\n", _FUNCL_);
        IFX_PrintOID(aiOID);
        goto errorHandler;
    }
    IFX_CWMP_FREE(pxCpeIdArray);

    return IFIN_CWMP_SUCCESS;

    errorHandler:
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                             "%s:%d failed!\n", _FUNCL_);
        IFX_CWMP_FREE(pxCpeIdArray);
        return IFIN_CWMP_FAILURE;
}



/* 
** =============================================================================
**   Function Name    : IFX_ConvertOidDottedForm
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

int32
IFX_ConvertOidDottedForm(int32 *paiArr_Oid,char8 *psOid_str)
{
    uint32 i=0;
    int32 *paiTemp_OID=paiArr_Oid;
    uint32 Oid_Depth=0;
    char8 sTemp[OID_CHAR_LENGTH]={0};
    memset(psOid_str,'\0',strlen(psOid_str));
    Oid_Depth=IFX_GetParamIdPos(paiArr_Oid);

    if(Oid_Depth == 0)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d Oid depth is Zero failed!\n", _FUNCL_);
        goto errorHandler;
    }

    for(i=0; i < Oid_Depth  ; ++i)
    {
        sprintf(sTemp,"%d.",paiTemp_OID[i]);
        strcat(psOid_str,sTemp);
    }

    return IFIN_CWMP_SUCCESS;

    errorHandler:
        return IFX_CWMP_FAILURE;
}

/* 
** =============================================================================
**   Function Name    : IFX_GetCpeId
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

int32
IFX_GetCpeId(IN int32 *aiOID,OUT uint32 *iCpeid)
{
    //Convert the object ID into dotted form
    //Get Cpeid by calling a mapping Protocol API

    char8 sObj_Id[OID_CHAR_LENGTH]={0};
    uint32 iRet=IFX_CWMP_SUCCESS;
    uint32 uiNumCpeId=0;
    IFX_CpeId *pxCpeIdArray=NULL;

    //Convert into dotted form
    iRet=IFX_ConvertOidDottedForm(aiOID,sObj_Id);
    if(iRet != IFIN_CWMP_SUCCESS)
        goto errorHandler;

#ifdef IFX_TR69_WAN_MODS_TEST_STUBS
    iRet = IFX_GetCpeIdFromTr69Id_stub(sObj_Id, &uiNumCpeId, &pxCpeIdArray);
#else
    //Get Cpeid using the mapping API
    iRet = IFX_GetCpeIdFromTr69Id(sObj_Id, &uiNumCpeId, &pxCpeIdArray);
#endif
    if((uiNumCpeId > 0) && (iRet == IFIN_CWMP_SUCCESS))
        *iCpeid = pxCpeIdArray->uiId;
    else
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d IFX_GetCpeIdFromTr69Id failed! uiNumCpeId[%d] sObj_Id[%s] iRet[%d] \n", _FUNCL_,uiNumCpeId, sObj_Id, iRet);
        IFX_PrintOID(aiOID);
        goto errorHandler;
    }
    IFX_CWMP_FREE(pxCpeIdArray);

    return IFIN_CWMP_SUCCESS;

    errorHandler:
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d failed!\n", _FUNCL_);
        IFX_CWMP_FREE(pxCpeIdArray);
        return IFIN_CWMP_FAILURE;
}

/* 
** =============================================================================
**   Function Name    : IFX_GetParentObjCpeId
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

int32
IFX_GetParentObjCpeId(IN int32 *aiOID,OUT uint32 *iCpeid)
{
    //Convert the object ID into dotted form
    //Get Cpeid by calling a mapping Protocol API

    uint32 iRet=IFX_CWMP_SUCCESS;
    int32 aiParentOID[OID_LENGTH]={0};
    uint32 uiParamPos=0;
    uint32 uiActParamPos=0;
    uint32 i=0;
    uint32 uiInst=0;

    //Get the Parent Oid
    uiParamPos =IFX_GetParamIdPos(aiOID);
    if(uiParamPos == 0)
        goto errorHandler;


    //Memset the iParentOID
    memset(aiParentOID,0x00, (sizeof(int32)*OID_LENGTH));

    uiActParamPos =uiParamPos;

    for(i=uiParamPos; i >= 0; i--)
    {
        if(aiOID[i] < 0)
        {
            --uiActParamPos;
        } else
        {
            //We need to skip the check for instance
            uiInst++;
            continue;
        }

        if (((uiParamPos - (uiActParamPos-uiInst)) == 2) ||
            ((uiParamPos - (uiActParamPos-uiInst)) == 3))
            break;
    }

    memcpy(aiParentOID,aiOID, (sizeof(int32) *(uiActParamPos-uiInst+1)));


    //Call IFX_GetObjCpeId to get the parent Cpeid
    iRet = IFX_GetObjCpeId(aiParentOID, iCpeid);
    if(iRet != IFIN_CWMP_SUCCESS)
        goto errorHandler;

    return IFIN_CWMP_SUCCESS;

    errorHandler:
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                             "%s:%d failed!\n", _FUNCL_);
        return IFIN_CWMP_FAILURE;
}




int32 IFX_FreeParamvalArr(IN ParamVal **paxParamVal, IN uint32 uiNoElem)
{
    ParamVal *paxTempParamVal=*paxParamVal;
    uint32 i=0;

    if(paxTempParamVal != NULL)
    {
        for(i=0; i < uiNoElem; ++i)
        {
            IFIN_CWMP_FREE(paxTempParamVal->Value);
            IFIN_CWMP_FREE(paxTempParamVal->Name);
            IFIN_CWMP_FREE(paxTempParamVal->psFaultStr);
            IFIN_CWMP_FREE(paxTempParamVal->psRCTag);
            IFIN_CWMP_FREE(paxTempParamVal->pReserved);
            paxTempParamVal++;
        }
        IFIN_CWMP_FREE(*paxParamVal);
    }

    return IFX_CWMP_SUCCESS;
}

int32
IFX_GetSectionParamTag(IN char8 * psRCTag, OUT char8 * psParamTag,
                       OUT char8 *psSectionTag)
{
    char8 caRCTag[MAX_RCTAG]={0};
    char8 *psTag=NULL;
    char8 caParamTag[IFX_MAX_NAME_LEN]={0};

    //memset(caRCTag, '\0', sizeof(caRCTag));
    //memset(caParamTag, '\0', sizeof(caParamTag));
    if(psRCTag != NULL)
        strncpy(caRCTag, psRCTag, MAX_RCTAG-1);
    else
        return IFX_CWMP_FAILURE;

    if((psTag = strtok(caRCTag, IFX_RCTAG_SEP)) == NULL)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                       "%s:%d failed!\n", _FUNCL_);
        return ERR_NOT_FOUND;
    }
    strncpy(psSectionTag, psTag,IFX_MAX_SECTION_TAG_LEN-1);
    if((psTag = strtok(NULL, IFX_RCTAG_SEP)) == NULL)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d failed!\n", _FUNCL_);
        return ERR_NOT_FOUND;
    }
    strncpy(caParamTag, psTag,IFX_MAX_NAME_LEN-1);
    if((psTag = strtok(NULL, IFX_RCTAG_SEP)) == NULL)
        strncpy(psParamTag, caParamTag, IFX_MAX_NAME_LEN-1);
    else
        strncpy(psParamTag, psTag, IFX_MAX_NAME_LEN-1);

    return IFX_CWMP_SUCCESS;
}




int32 IFX_SetAttributesInfo(IN OperInfo *pxOperInfo,IN ParamVal
				*paxParamArr,IN uint32 uiElements)
{

//Group the parameters based on section
//Arr to maintain no_section and No_Elements_Section
	//For each section
	//Malloc the array IFX_Attrinfo
	//Get the CpeId from TR69_Id & match with section
	//Form each IFX_Attrinfo struct in the Array

	//**AccessList can be list of subscribers who are allowed to access
	//**Pass the Attribute struct in the Reserved field in ParamVal

	//Form the flags
	//if passive notify is enabled on RO paramter then copy the value to 
	// the  IFX_Attrinfo struct

	//Write the IFX_Attrinfo array
	//Continue writing IFX_Attrinfo array untill end of ParamVal array


	Grp_ParamVal_SecTag paxSectionSubArr[MAX_NO_SECTIONS];
	Grp_ParamVal_SecTag *paxTempSecSubArr =NULL;
	char8 usOldSecTag[IFX_MAX_SECTION_TAG_LEN]=" ";
	char8 usSecTag[IFX_MAX_SECTION_TAG_LEN]={0};
	char8 usParamTag[IFX_MAX_NAME_LEN]={0};
	char8 usTr69_Id[MAX_NAME_LEN]={0};
	//char8 usTemp[MAX_NAME_LEN];
	ParamVal *paxTempParamVal=NULL;
	IFX_AttrInfo *paxAttrInfo=NULL;
	IFX_AttrInfo *paxTempAttrInfo=NULL;
	IFX_CpeId *paxCpeIdArray=NULL;
	uint32 uiNumCpeId=0;
	IFX_CpeId pxCpeId;
	uint32 uiNumAttrInfo=0;
	uint32 uiNumValAttrInfo=1;
	uint32 uiParamPos=0;
	//uint32 uiTemp_Flags;
	SetParameterAttributesStruct *pxParamAttrInfo=NULL;
	uint32 i=0,j=0,k=0,iRet=0;
        uint16 uiCSum = 0;

	//Group the paramVal arr into sub-array based on sections
	memset(paxSectionSubArr,0,(MAX_NO_SECTIONS*sizeof(Grp_ParamVal_SecTag)));
	memset(&pxCpeId,0x00,sizeof(pxCpeId));
	paxTempSecSubArr = paxSectionSubArr;

	for(i=0,k=0; i  <uiElements; ++i)
	{
		iRet=IFX_GetSectionParamTag((paxParamArr+i)->psRCTag, usParamTag, usSecTag);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;


		if(strcmp(usOldSecTag,usSecTag) == 0)
		{
			//Keep incrementing the no.of elements
			++((paxTempSecSubArr+k)->uiNoElements);
		} else
		{
			//If SectionName does not match,NEW Section

			if(i !=0)
			++k;

			(paxTempSecSubArr+k)->paxHeadParamValSubArr = (paxParamArr+i);
			(paxTempSecSubArr+k)->uiNoElements = 1;

			if(k >=  MAX_NO_SECTIONS)
				goto errorHandler;

			strcpy(usOldSecTag,usSecTag);
		}

	}

	//Form the IFX_AttrInfo array and Set the Attributes
	for(j=0; j < MAX_NO_SECTIONS; ++j)
	{

	if((paxSectionSubArr+j)->uiNoElements != 0)
	{
		paxTempParamVal = (paxSectionSubArr+j)->paxHeadParamValSubArr;
		uiNumAttrInfo = (paxSectionSubArr+j)->uiNoElements;

		iRet = IFX_ConvertOidDottedForm(paxTempParamVal->iaOID, usTr69_Id);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;

		iRet = IFX_GetCpeIdFromTr69Id(usTr69_Id, &uiNumCpeId, &paxCpeIdArray);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;
		
		memset(usParamTag,'\0', IFX_MAX_NAME_LEN);
		memset(usSecTag,'\0', IFX_MAX_SECTION_TAG_LEN);

		iRet=IFX_GetSectionParamTag(paxTempParamVal->psRCTag, usParamTag, usSecTag);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;


			for(i=0; i < uiNumCpeId; ++i )
			{
				//Find the exact Cpeid
				if(strcmp((paxCpeIdArray+i)->sSectionTag,usSecTag) ==0)
				{
					//Fill the Cpeid and SectionTag
					pxCpeId.uiId= (paxCpeIdArray+i)->uiId;
					strcpy(pxCpeId.sSectionTag,(paxCpeIdArray+i)->sSectionTag);
					break;
				}
			}
			//Free the IFX_Cpeid array
			IFX_CWMP_FREE(paxCpeIdArray);


			paxAttrInfo = IFX_CWMP_MALLOC(sizeof(IFX_AttrInfo) *uiNumAttrInfo);
			if(paxAttrInfo == NULL){
				iRet = ERR_OUT_OF_MEMORY;
				goto errorHandler;
			}

			paxTempAttrInfo = paxAttrInfo;

			for (k=0;k <uiNumAttrInfo; k++ )
			{
				pxParamAttrInfo=(SetParameterAttributesStruct
								*) (paxTempParamVal->pReserved);
				//Fill the IFX_AttrInfo structs
					//Fill Acl
					if(pxParamAttrInfo->AccessListChange== IFX_ACCESS_CONTROL_SET)
					{
						if(IFX_FwdMappingValues(saxAttrAccessCtrl,2,
							(void *)(pxParamAttrInfo->AccessList),
							(void *)&(paxTempAttrInfo->ucACL)) !=IFIN_CWMP_SUCCESS)
						{
							iRet=ERR_CWMP_INVAL_PARAM_VAL;
							goto errorRetHandler;
						}
						paxTempAttrInfo->uiFlags = paxTempAttrInfo->uiFlags |
							IFX_ATTR_INFO_F_MODIFY_ACL;
					}
					//Fill Notify
					if(pxParamAttrInfo->NotificationChange== IFX_NOTIFICATION_SET)
					{
						//sprintf(usTemp,"%d", atoi(*(pxParamAttrInfo->Notification)));

						if(IFX_FwdMappingValues(saxAttrNotify,3,
							(void *)(pxParamAttrInfo->Notification),
							(void *)&(paxTempAttrInfo->ucNotify)) !=IFIN_CWMP_SUCCESS)
						{
							iRet=ERR_CWMP_INVAL_PARAM_VAL;
							goto errorRetHandler;
						}
						paxTempAttrInfo->uiFlags = paxTempAttrInfo->uiFlags |
							IFX_ATTR_INFO_F_MODIFY_NOTIFY;
					}

					//Fill AccessType
					paxTempAttrInfo->ucParamType = paxTempParamVal->iAccessType;

					//Fill ParamId
					uiParamPos = IFX_GetParamIdPos(paxTempParamVal->iaOID);
					paxTempAttrInfo->iParamOid = paxTempParamVal->iaOID[uiParamPos];

					//Fill ChangeFlag
					//paxTempAttrInfo->ucChangeFlag = IFX_CHANGE_FLAG_CLEAR;
					//paxTempAttrInfo->uiFlags = paxTempAttrInfo->uiFlags |
					//IFX_ATTR_INFO_F_MODIFY_CHANGE_FLAG;

					memset(usParamTag,'\0', IFX_MAX_NAME_LEN);
					memset(usSecTag,'\0', IFX_MAX_SECTION_TAG_LEN);
					//Fill ParamTag
					iRet=IFX_GetSectionParamTag(paxTempParamVal->psRCTag, usParamTag, usSecTag);
					strcpy(paxTempAttrInfo->sParamTag,usParamTag);


					paxTempParamVal++;
					paxTempAttrInfo++;

			}

			//To delete the Parameters if the Oper and Sub-Oper is DELETE
			int ij=0;
			for(ij=0; ij < uiNumAttrInfo; ij++)
			{

				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                                            "#### SectionName =%s  \
					     ParamName =%s \
					     Cpeid= %d !\n", pxCpeId.sSectionTag,paxAttrInfo[ij].sParamTag,
									pxCpeId.uiId);		
		
			}


			//Update Access control and notification by passing the entire array
			iRet = IFX_UpdateAttrInfo(&pxCpeId, uiNumAttrInfo, paxAttrInfo);
			
			if(iRet != IFX_CWMP_SUCCESS)
			{
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d IFX_UpdateAttrInfo failed!\n", _FUNCL_);
				goto errorHandler;
			}


			//Update the value of parameters for this section.
			paxTempParamVal = (paxSectionSubArr+j)->paxHeadParamValSubArr;
			paxTempAttrInfo = paxAttrInfo;
			for (k=0;k <uiNumAttrInfo; k++ )
			{

					//Fill Value
					if((paxTempAttrInfo->ucNotify == IFX_NOTIFY_PASSIVE) &&
						(paxTempAttrInfo->ucParamType == IFX_PARAM_TYPE_RO))
						{
							if(paxTempParamVal->Value != NULL)
							{
							//Store the flags in temporary variable
							//uiTemp_Flags = paxTempAttrInfo->uiFlags;

							strncpy(paxTempAttrInfo->sParamVal,paxTempParamVal->Value,
											IFX_MAX_VAL_LEN);
							IFX_Checksum(&uiCSum, paxTempParamVal->Value);
							sprintf(paxTempAttrInfo->sParamVal, "%d", uiCSum);
							paxTempAttrInfo->uiFlags = IFX_ATTR_INFO_F_MODIFY_PARAM_VALUE;

							//Call update AttributeInfo to update only value 
							//for a single parameter
							iRet = IFX_UpdateAttrInfo(&pxCpeId, uiNumValAttrInfo, paxTempAttrInfo);
							if(iRet != IFX_CWMP_SUCCESS)
							{
								IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                                                            "%s:%d  IFX_UpdateAttrInfo failed!\n",
                                                                            _FUNCL_);
								goto errorHandler;
							}
							//Restore the flags back into the paxTempAttrInfo->uiFlags
							//paxTempAttrInfo->uiFlags=uiTemp_Flags ;
							}
						}

					paxTempParamVal++;
					paxTempAttrInfo++;
			}

			//Free the paxAttrInfo array
			IFX_CWMP_FREE(paxAttrInfo)

	}


	}
	IFX_CWMP_FREE(paxCpeIdArray);
	return IFX_CWMP_SUCCESS;

	errorHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                             "%s:%d failed!\n", _FUNCL_);
		IFX_CWMP_FREE(paxCpeIdArray);
		IFX_CWMP_FREE(paxAttrInfo);
		return IFX_CWMP_FAILURE;

	errorRetHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                             "%s:%d failed!\n", _FUNCL_);
		IFX_CWMP_FREE(paxCpeIdArray);
		IFX_CWMP_FREE(paxAttrInfo);
		return iRet;
}

int32
IFX_CheckValueGotChanged(IN OperInfo *OprInfo, IN ParamVal *pxNewParamVal, IN uint32 uiMode)
{
	//Check if Oper is passive_notify
	//Compare the old with new if it is different return the 
	//success else return NULL in Value, free the mem of Value
	//If it is different Update rc.conf
	//***Handle ChangeFlag case also

	uint32 uiCpeid=0,iRet=0;
	char8 usSecTag[IFX_MAX_SECTION_TAG_LEN]={0};
	char8 usParamTag[IFX_MAX_NAME_LEN]={0};
	//uchar8 usTr69_Id[MAX_NAME_LEN];
	//IFX_CpeId *paxCpeIdArray;
	IFX_CpeId pxCpeId;
	IFX_AttrInfo pxAttrInfoArray[1];
	uint32 uiNumAttrInfo=1;
	//uint32 uiFlags;
        uint16 uiCSum = 0;
        char8 caCSum[8] = {0};

	memset(&pxCpeId,0x00,sizeof(pxCpeId));
	memset(&pxAttrInfoArray,0x00,sizeof(pxAttrInfoArray));

	//If Get_Notification 
	if(OprInfo->iSubOper == OP_GETVAL_NOTIFICATION)
	{
		//Get Cpeid
		iRet = IFX_GetCpeId(pxNewParamVal->iaOID, &uiCpeid);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;


		//Get SectionName and ParamName from rc_tag
		iRet=IFX_GetSectionParamTag(pxNewParamVal->psRCTag, usParamTag, usSecTag);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;


		//Get the Old Value using Protocol API
		pxCpeId.uiId = uiCpeid;
		strncpy(pxCpeId.sSectionTag,usSecTag,IFX_MAX_SECTION_TAG_LEN-1);
		strncpy(pxAttrInfoArray->sParamTag,usParamTag,IFX_MAX_NAME_LEN-1);

		iRet = IFX_GetAttrInfo(&pxCpeId, uiNumAttrInfo, pxAttrInfoArray);
		if(iRet != IFX_CWMP_SUCCESS)
		{
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d IFX_GetAttrInfo failed!\n", _FUNCL_);
			goto errorHandler;
		}
		//Compare Old and new Value
		if(uiMode == IFX_CHK_VALUE_BASED)
		{
                            IFX_Checksum(&uiCSum, pxNewParamVal->Value);
                            sprintf(caCSum, "%d", uiCSum);
			    if(strcmp(pxAttrInfoArray->sParamVal, caCSum) == 0)
			        IFX_CWMP_FREE(pxNewParamVal->Value); //if unchanged Free the Value pointer
		}else if(uiMode == IFX_CHK_CHANGE_FLAG_BASED)
		{
			//If ChangeFlag based
			if(pxAttrInfoArray->ucChangeFlag == IFX_CHANGE_FLAG_SET)
			{
			} else
			{
				IFX_CWMP_FREE(pxNewParamVal->Value);
			}
		}
	}
	return IFX_CWMP_SUCCESS;

	errorHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d failed!\n", _FUNCL_);
		return IFX_CWMP_FAILURE;
}

int32
IFX_GetWanConType(uint32 LinkType)
{
    switch(LinkType)
    {
        case LINK_TYPE_CLIP:
        case LINK_TYPE_EOATM:
        case LINK_TYPE_IPOATM:
            return IP_CON_TYPE;


        case LINK_TYPE_PPPOE:
        case LINK_TYPE_PPPOATM:
            return PPP_CON_TYPE;

        case LINK_TYPE_UNCONFIGURED:
        default:
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d failed!\n", _FUNCL_);
            return IFX_CWMP_FAILURE;
    }
}


/*******************************************************************************
* Function: IFX_MOD_TimeStrToInt())
* Desc: Will accept sTime in "2005-01-03T03:04:05" format only. Return time_t
* Parameters: IN char * psDateTime, OUT time_t * ptTime
* Return Value: IFX_CWMP_SUCCESS if successful, -ve Error code otherwise
*******************************************************************************/
#define DATETIME_SEP    "-T:"
int32
IFX_MOD_TimeStrToInt(IN char8 * psDateTime, OUT time_t * ptTime)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    size_t tMinLen = 0;
    char8 caTime[32] = { 0 }, *psTmp = NULL;
    struct tm xTM;

    memset(&xTM, 0, sizeof(xTM));
    tMinLen = strlen("2005-01-03T04:05:06");
    if(strlen(psDateTime) < tMinLen) {
        iRet = ERR_CWMP_INVAL_ARGS;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Invalid Arg %s\n",
                    _FUNCL_, psDateTime);
        goto errorHandler;
    }
    strncpy(caTime, psDateTime, (sizeof(caTime) - 1));
    psTmp = strtok(caTime, DATETIME_SEP);
    if(psTmp)
        xTM.tm_year = atoi(psTmp) - 1900;
    psTmp = strtok(NULL, DATETIME_SEP);
    if(psTmp)
        xTM.tm_mon = atoi(psTmp) - 1;
    psTmp = strtok(NULL, DATETIME_SEP);
    if(psTmp)
        xTM.tm_mday = atoi(psTmp);
    psTmp = strtok(NULL, DATETIME_SEP);
    if(psTmp)
        xTM.tm_hour = atoi(psTmp);
    psTmp = strtok(NULL, DATETIME_SEP);
    if(psTmp)
        xTM.tm_min = atoi(psTmp);
    psTmp = strtok(NULL, DATETIME_SEP);
    if(psTmp)
        xTM.tm_sec = atoi(psTmp);
    *ptTime = mktime(&xTM);
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_MOD_TimeIntToStr
* Desc: Converts from time_t format to "2006=03=04:T05:06:07" format. psDateTime
*       is allocated by caller. Atleat 32 bytes should be allocated
* Parameters: IN time_t * ptTime, OUT char8 * psDateTime
* Return Value: IFX_CWMP_SUCCESS
*******************************************************************************/
int32
IFX_MOD_TimeIntToStr(IN time_t * ptTime, OUT char8 * psDateTime)
{
    struct tm *pxTM;
    pxTM = localtime(ptTime);
    if(pxTM!=NULL) {
		    strftime(psDateTime, 32, "%Y-%m-%dT%H:%M:%S", pxTM);
		    return IFX_CWMP_SUCCESS;
    }		
    else
       return IFX_CWMP_FAILURE;	
}

int32 IFX_ConvertDNSServersArrToString(struct in_addr *arrHead,char8 *DNSstring,uint32 NoElements)
{
    uint32 i=0;
    char8 sTempBuf[MAX_IP_ADDRRESS_LEN]={0};

    if(arrHead == NULL || DNSstring == NULL)
        goto errorHandler;

    for(i=0;i<NoElements;i++)
    {
        memset(sTempBuf,0x00,MAX_IP_ADDRRESS_LEN);

        if(arrHead[i].s_addr ==0)
            continue;

        if(i != 0)
            strcat(DNSstring,",");

        strncpy(sTempBuf, inet_ntoa(arrHead[i]), (MAX_IP_ADDRRESS_LEN-1));

        strcat(DNSstring,sTempBuf);

        //if(arrHead[i].s_addr
        //if(i < (NoElements -1))

    }
    return IFX_CWMP_SUCCESS;

    errorHandler:
        return IFX_CWMP_FAILURE;

}


int32 IFX_ConvertDNSServersStringToArr(struct in_addr *arrHead,char8 *DNSstring)
{
    uint32 i=0;
    char8 *sToken=NULL;

    if(arrHead == NULL || DNSstring == NULL)
        goto errorHandler;

    for(sToken =strtok(DNSstring, ","),i=0; sToken != NULL && i < MAX_DNS_SERVERS; sToken = strtok(NULL, ","),i++)
    {
        if((inet_aton(sToken,(arrHead+i))) ==0)
            goto errorHandler;
    }


    sToken = strtok(NULL, ".");
    if(sToken != NULL)
        goto errorHandler;

    return IFX_CWMP_SUCCESS;

    errorHandler:
        return IFX_CWMP_FAILURE;
}

int32
ifx_mod_init()
{
    int32 iRet=IFX_CWMP_SUCCESS;

    // All the modules should call their init()'s here
#ifdef DEVICE_SUPPORT
// Device specfic modules

#ifdef DEVICE_ASSO_SUPPORT
    iRet = IFX_GatewayInfo_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif // DEVICE_ASSO_SUPPORT

    iRet = IFX_Device_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }

#ifdef IFX_TR69_DEVICE_LAN
    iRet = IFX_LAN_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_DHCPOption_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif // IFX_TR69_DEVICE_LAN

#else // DEVICE_SUPPORT
//IGD specific modules
    iRet = IFX_IGD_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFIN_Layer3Forwawrding_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_LHCMIPInterfaceInit();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }

#ifdef IFX_TR69_PERFORMDIAG
    iRet = LTQ_PerformanceDiagnosticInit();
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", __func__, __LINE__);
    }
#endif 

#ifdef IFX_TR69_ETHERNETLAN
    iRet = IFX_LANEthernetIfCfg_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_LANEthernetIfCfgStatsInit();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif // IFX_TR69_ETHERNETLAN

#ifdef IFX_TR69_USBLAN
    iRet = IFX_LANUSBIfCfg_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_LANUSBIfCfgStatsInit();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif // IFX_TR69_USBLAN

    iRet = IFX_LANHostCfgMgmtInit();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_LANDeviceInit();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_LANIf_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
	        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_DHCPCondServ_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_DHCPStaticAddr_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_WanDevice_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_WanConnDevice_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_WanIpConnection_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_WanPPPConnection_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#ifdef IFX_TR69_ATMLOOPBACK
    iRet = IFX_WanATMF5LoopbackDiagnostics_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif // IFX_TR69_ATMLOOPBACK

#ifdef IFX_TR69_ADSLWAN
    iRet = IFX_WanDslInterfaceConfig_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_WanDslStats_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#ifdef CONFIG_FEATURE_IFX_TR69_WANDSLOBJS_FULL 
    iRet = IFX_WanDslIfaceStats_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_WanDslIfaceStatsLastShowtime_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif
    iRet = IFX_WanDslLinkConfig_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
         IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                     "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_WanDslTestParams_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
         IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                     "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif // IFX_TR69_ADSLWAN


#ifdef IFX_TR69_DSLDIAGNOSTICS
    iRet = IFX_WanDslDiagnostics_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif // IFX_TR69_DSLDIAGNOSTICS

    iRet = IFX_WanIpPortMapping_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_WanIpConnStats_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_WanCommonInterfaceConfig_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }

    iRet = IFX_LANConfigSecurity_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }

#ifndef CONFIG_FEATURE_IFX_TR69_DEVICE
    iRet = IFX_Hosts_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif

// firewall_support

    iRet = IFX_Firewall_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }

    iRet = IFX_Dmz_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }


#ifdef DEVICE_ASSO_SUPPORT
    iRet = IFX_ManageableDevice_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif // DEVICE_ASSO_SUPPORT

#ifdef IFX_TR104

    iRet = IFX_Service_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_VoiceService_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_VoiceServiceCapabilities_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_VoiceServSipCapab_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_VoiceServCodecCapab_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_VoiceProfile_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_ProfileServiceProviderInfo_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_ProfileSignaling_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_ProfileMediaRtp_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_ProfileMediaRtcp_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_VoiceLine_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_LineSignaling_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_LineSignaling_Event_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_LineCodec_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_LineCodecList_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_LineCallingFeatures_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_LineVoiceProcessing_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }

    iRet = IFX_LineSession_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }

    iRet = IFX_LineStats_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }


    iRet = IFX_VoiceServPhyIf_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_Profile_NumPlan_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_Profile_NumPlan_PrefixInfo_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_Profile_FaxT38Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_Profile_Event_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif // IFX_TR104

#ifdef IFX_TR69_ETHERNETWAN
    iRet = IFX_WANEthernetIfCfgInit();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_WANEthernetIfCfgStatsInit();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_WANEthernetLinkCfgInit();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif // IFX_TR69_ETHERNETWAN

#ifdef IFX_TR69_PTMWAN
    iRet = IFX_WANPTMLinkCfgInit();
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }

    iRet = IFX_WanPTMLinkConfigStats_Init();
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif // IFX_TR69_PTMWAN

    iRet = IFX_WANVlanInit();
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }

#ifdef IFX_TR157_FIREWALL
    iRet = IFX_TR157_FirewallInit();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif

#ifdef IFX_TR69_IPQOS
    iRet = IFX_QueueMgmt_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_QMClassify_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_QMPolicer_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_QMQueue_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif // IFX_TR69_IPQOS

#endif // DEVICE_SUPPORT

//Modules common to both IGD and Device
#ifdef IFX_TR69_WIFILAN
    iRet = IFX_WlanConfiguration_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_WlanKeys_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#ifndef CONFIG_FEATURE_IFX_TR69_DEVICE
    iRet = IFX_WlanAssocDevice_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif
    iRet = IFX_WlanStats_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#ifdef IFX_TR69_WIFILAN_WMM    
    iRet = IFX_WlanWmm_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif //IFX_TR69_WIFILAN_WMM

#ifdef IFX_TR69_WIFILAN_WPS    
    iRet = IFX_WlanWps_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif //IFX_TR69_WIFILAN_WPS     
#endif // IFX_TR69_WIFILAN

    iRet = IFX_DevInfo_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_MgmtServer_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }

#ifdef IFX_TR69_TIME
    iRet = IFX_Time_Init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif // IFX_TR69_TIME

#ifdef IFX_TR69_IPPING
    iRet = IFX_IPPingDiagInit();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif // IFX_TR69_IPPING

#ifdef IFX_TR69_X_LTQ_IPPROTOCOLVERSION
    iRet = IFX_X_LTQ_IPProtocolVersionInit();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif

    iRet = IFX_DeviceConfigInit();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }


#ifdef IFX_TR157_MEMORYSTATUS
    iRet= IFX_MemoryStatusInit();
         if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif


#ifdef IFX_TR157_PROCESSSTATUS
    iRet= IFX_ProcessStatusInit();
         if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif

#ifndef DEVICE_SUPPORT
#ifdef IFX_TR157_USERINFO
    iRet= IFX_UserInfoInit();
         if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
#endif
#endif


#ifdef IFX_TR69_TRACEROUTE
    iRet = IFX_TraceRouteDiagInit();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", __func__, __LINE__);
    }
#endif //IFX_TR69_TRACEROUTE

#ifdef IFX_TR143_DOWNLOADDIAGNOSTICS
    iRet = IFX_DownloadDiagInit();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", __func__, __LINE__);
    }
#endif

#ifdef IFX_TR143_UPLOADDIAGNOSTICS
    iRet = IFX_UploadDiagInit();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", __func__, __LINE__);
    }
#endif

#ifdef IFX_TR157_NSLOOKUP
    iRet = IFX_NSLookupDiagInit();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", __func__, __LINE__);
    }
#endif //IFX_TR157_NSLOOKUP

#ifdef IFX_TR157_SELFTEST
    iRet = LTQ_SelfTestDiagInit();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", __func__, __LINE__);
    }
#endif //IFX_157_SELFTEST

    iRet = IFX_AuthInit();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_DownloadAuthInit();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }
    iRet = IFX_IFXInit();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d MODULE Reg Failed!\n", _FUNCL_);
    }

    return iRet;
}

#ifdef IFX_TR104

/* 
** =============================================================================
**   Function Name    : IFX_GetObjectOID
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_GetObjectOID(IN int32 *paiOID)
{
    int32 iOID=0;
    int32 iCnt=0;

    for (iCnt = 0; paiOID[iCnt] != 0; iCnt++);

    if (paiOID[iCnt - 2] > 0)
    {
        iOID = paiOID[iCnt - 3];
    }
    else
    {
        iOID = paiOID[iCnt - 2];
    }

    return (iOID);
}

/* 
** =============================================================================
**   Function Name    : IFX_GetParamOID
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_GetParamOID(IN int32 *paiOID)
{
    int32 iCnt=0;

    for (iCnt = 0; paiOID[iCnt] != 0; iCnt++);

    return (iCnt - 1);
}

/******************************************************************
*  Function Name:  IFX_ValidateIPv4Addr
*  Description  :  Validate Ipv4 address
*  Input Values :  character string
*  Output Values:  -
*  Return Value :  Success or failure of validation
*  Notes        : 
*********************************************************************/
int32
IFX_ValidateIPv4Addr(char8* pszBuff)
{
  uint32 iCount = 0, iDotCount = 0;
  char8 acTemp[4]={0};

  while(*pszBuff != '\0'){
    if(*pszBuff == '.'){
      iDotCount++;
      acTemp[iCount] = '\0';
      if((iCount > 0) && (atoi(acTemp) < 256)){
        memset(acTemp,'\0',4);
        iCount = 0;
        pszBuff++;
      }
      else{
        return IFX_CWMP_FAILURE;
      }
    }
    else{
      if(!isdigit(*pszBuff)){
        return IFX_CWMP_FAILURE;
      }
      acTemp[iCount++] = *pszBuff;
      pszBuff++;
      if(iCount > 3){
        return IFX_CWMP_FAILURE;
      }
    }
  }
  if(iCount<1 || atoi(acTemp)> 256 || iDotCount > 3){
    return IFX_CWMP_FAILURE;
  }
  return IFX_CWMP_SUCCESS;
}

/******************************************************************
*  Function Name:  IFX_ValidatePhoneDigit
*  Description  :  Checks if it is a valid Phone digit
*  Input Values :  start pointer to the null terminated string
*  Output Values:  None
*  Return Value :  Success/Failure
*  Notes        : 
*********************************************************************/
int32
IFX_ValidatePhoneDigit(char8* pszBuff)
{
  uint32 i = 0;
  while(i < strlen(pszBuff)){
    if(isdigit(pszBuff[i]) ||
       (pszBuff[i] == '-') ||
       (pszBuff[i] == '(') ||
       (pszBuff[i] == ')') ||
       (pszBuff[i] == '(')){
      i++;
      continue;
    }
    else{
      break;
    }
  }
  if(i != strlen(pszBuff)){
    return IFX_CWMP_FAILURE;
  }
  return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_GetObjectDepth
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_GetObjectDepth(IN int32 *paiOID)
{
    int32 iDepth = -1;
    int32 iCnt=0;

    for (iCnt = 0; paiOID[iCnt] != 0; iCnt++)
    {
        if (paiOID[iCnt] < 0)
        {
            iDepth++;
        }
    }
    return (iDepth-1);
}

/* 
** =============================================================================
**   Function Name    : IFX_GetProfileId
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_GetProfileId(IN int32 *paiOID)
{
    int32 iCnt=0;

    for (iCnt = 0; paiOID[iCnt] != 0; iCnt++)
    {
      if (paiOID[iCnt] == OID_IGD_S_VS_VP)
      {
        return(paiOID[iCnt + 1]);
      }
    }

    return 0;
}

/* 
** =============================================================================
**   Function Name    : IFX_GetLineId
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_GetLineId(IN int32 *paiOID)
{
    int32 iCnt=0;

    for (iCnt = 0; paiOID[iCnt] != 0; iCnt++)
    {
      if (paiOID[iCnt] == OID_IGD_S_VS_VP_L)
      {
        return(paiOID[iCnt + 1]);
      }
    }

    return 0;
}

/* 
** =============================================================================
**   Function Name    : IFX_GetOIDArrayTillLastInst
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_GetOIDArrayTillLastInst(IN int32 *paiOID, INOUT char8* sOidString)
{
    int32   iCnt = 0;
    char sTmp[15]={0};
    while(paiOID[iCnt+1]!= 0) {
    // ignore the last value as it will be a parameter & we need only till the last instance
          snprintf(sTmp,15,"%d",paiOID[iCnt]);
          strcat(sOidString,sTmp);
          strcat(sOidString,".");
          iCnt++;
     }

    return 0;
}

/* 
** =============================================================================
**   Function Name    : IFX_SearchString
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_SearchString(IN char8* inString, IN char8* searchString)
{
  char8* ptr=NULL;
  char8* result = NULL;
  ptr = inString;
  while(ptr != NULL)
  {
    result = strchr(ptr, ',');
    if(result != NULL)
    {
      if(strncmp(ptr, searchString,strlen(searchString)) == 0)
      {
        if(strlen(searchString) == (strlen(ptr) - strlen(result)))
        {
          return IFX_CWMP_SUCCESS;
        }
        else
        {
          return IFX_CWMP_FAILURE;
        }
      }
    }
    else
    {
      if(strncmp(ptr, searchString,strlen(searchString)) == 0)
      {
        if(ptr != inString)
        {
          if(strlen(searchString) == (strlen(inString) - strlen(ptr)))
          {
            return IFX_CWMP_SUCCESS;
          }
          else
          {
            return IFX_CWMP_FAILURE;
          }
        }
        else
        {
          if(strlen(searchString) == (strlen(inString)))
          {
            return IFX_CWMP_SUCCESS;
          }
          else
          {
            return IFX_CWMP_FAILURE;
          }
        }
      }
    }
    if(result != NULL)
    {
      ptr = result+1;
    }
    else
    {
      break;
    }
  }
  return IFX_CWMP_FAILURE;
}

/* 
** =============================================================================
**   Function Name    : IFX_ValidateEmail
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_ValidateEmail(char8* pszBuff)
{
  int32 iCount = 0, iLat = 0, iDot = 0;
  char8 dot = '.';
  char8 at = '@';
  char8* atIndex = NULL;
  char8* ptr = NULL;

  if ((strchr(pszBuff , at) != NULL) && (strchr(pszBuff , dot) != NULL))
  {
   if(pszBuff!=NULL)
   {
    iLat = strlen(strchr(pszBuff , at));
    iDot = strlen(strchr(pszBuff , dot));
   }
   else
   {
   return  IFX_CWMP_FAILURE;
   }
  }

  ptr = pszBuff;

  /* Check the presence of atleast one @ and make sure that it shouldn't be
     at the begining or at the end */
  if ((strchr(pszBuff , at) == 0) || iLat == 1 || iLat == strlen(pszBuff)){
    return IFX_CWMP_FAILURE;
  }

  /* Check the presence of atleast one . and make sure that it shouldn't be
     at the begining or at the end */
  if ((strchr(pszBuff , dot) == 0) || iDot == 1 || iDot == strlen(pszBuff)){
    return IFX_CWMP_FAILURE;
  }

  /* there shouldn't be any space */
  if ((strchr(pszBuff , ' ') != 0)){
    return IFX_CWMP_FAILURE;
  }

  /* there shouldn't be any . before and after the @ */
 if(pszBuff!=NULL)
 {
  if ((*(strchr(pszBuff , at)+1) ==  dot) ||
       (*(strchr(pszBuff , at)-1) ==  dot)){
    return IFX_CWMP_FAILURE;
  }
 }
  /* there shouldn't be more than one @ */
  while(ptr != NULL){
    atIndex = strchr(ptr , at);
    if(atIndex != NULL)
    {
      ptr = atIndex+1;
    }
    else{
      break;
    }
    iCount++;
  }
  if(iCount != 1)
  {
    return IFX_CWMP_FAILURE;
  }

  atIndex = NULL;
  ptr = pszBuff;

  /* there should be atleast one . after the @ */
  atIndex = strchr(ptr,at) ;
  if (strchr(atIndex +1, dot) ==0)
  {
    return IFX_CWMP_FAILURE;
  }

  return IFX_CWMP_SUCCESS;

}

/* 
** =============================================================================
**   Function Name    : IFX_ValidateURL
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_ValidateURL(char8 *pszBuff)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    if((strncmp(pszBuff, "http:",5) != 0)&&(strncmp(pszBuff, "https:",6) != 0))
    {
        iRet = ERR_CWMP_INVAL_PARAM_VAL;
    }

    return (iRet);
}
#endif // IFX_TR104




/**********************************************
This function is called just prior to begining of download
Tis can be used to free memory by killing processes

If there is no such operation required, keep the function empty

***********************************************/

void ifx_download_pre()
{
#ifdef MIPSTARGET

//    kill(getppid(), SIGKILL);
//    system("killall sipALGd ripd ifxsip");
//    system("ifconfig ra0 down");
//    system("rmmod rt3062ap");
//    system("killall httpd cli_fe cli_be");
//    sleep(2);
//    system("killall check_dsl swreset oamd syslogd klogd tftpd ftpd telnetd snmpd udhcpd atmarpd");
//    sleep(5);
//    system("killall inetd");
//    remove("/ramdisk/etc");
//    remove("/ramdisk/var");
//    remove("/ramdisk/tftp_upload");

    ifx_run_command("/etc/rc.d/free_memory.sh tr69");

    /*Sumedh: Free LAN DMA buffers. FIXME: need to get sock info on interface. you can download from lan too..For now, we assume upgrade from web is from LAN side. and from TR69 is from WAN side */

#ifndef DEVICE_SUPPORT
    // system("/bin/mknod /dev/free_dma_dev c 235 0");
    // system("/sbin/insmod free_dma.o");
    // system("/sbin/ifconfig eth0 0 down");   kamal: fix for devm download over MII0
    // system("/usr/sbin/free_dma 1");
#endif // DEVICE_SUPPORT

    sleep(2);
#endif // MIPSTARGET
}

/*********************************************
This function is called immediately after download
It can be used to kill still more processes to make 
room for upgrade operation.

If there is no such operation required, keep the function empty


**********************************************/
void ifx_download_post()
{
    ifx_run_command ("/etc/rc.d/free_memory.sh tr69_postdl");
#if 0
    // DOWNLOAD DONE, KILL ALL PROCESSES
    system("killall pppd dnrd udhcpc");
    system("killall ip-down rc.bringup_wan_services");
#ifdef MIPSTARGET
#ifndef DEVICE_SUPPORT
    system("killall br2684ctld");
#endif // DEVICE_SUPPORT
    system("rmmod iproxyd");
    //system("killall dsl_cpe_control");

    /* Perform graceful shutdown of DSL API threads
     * Stop AutobootControl and DSL CPE Control */
    system("/opt/ifx/bin/dsl_cpe_pipe.sh acs 0");
    sleep(1);
    system("/opt/ifx/bin/dsl_cpe_pipe.sh quit");
    sleep(2);

    system("/bin/mknod /dev/free_dma_dev c 235 0"); 
    system("/sbin/insmod free_dma.o"); 
    system("/usr/sbin/free_dma 2 &");

#endif // MIPSTARGET
#endif
    sleep(2);
}


/*****************************************************

If thefile is downloaded and the file size correct
Then this function is called to allow you to invoke your 
custom upgrade procedure

input parameter
	caFileName	Filename that has been downloaded

return value
	iRet_chkImage	0	Success (image sane)
			1	Failure (image not sane)

******************************************************/
char8 temp1[200]={0};
char8 img_type[16] ={0};
int32 iExpandDir = 0;

int ifx_download_check_image(char8 *caFileName, int32 iFileType)
{
        int iRet_chkImage;

        if(iFileType == FT_FIRMWARE)
            iRet_chkImage = ifx_chkImage(caFileName, temp1, img_type, &iExpandDir);
        else
            iRet_chkImage = ifx_chkSysConf(caFileName);

        return iRet_chkImage;
}



/*************************************************
This function is called after basic checks are done 
on the image. This will allow custom handling by vendors.

You can chose to upgrade imange if image is sane.
If the image is not sane, then you can chose to either 
reboot or return without reboot in which case CWMP will
send a fault response.

Parameter passed iRet_chkImage is 0 if image is sane
				  1 if image is not sane


		 caFileName   is the name of the file
**************************************************/


void ifx_download_upgrade_image(int iRet_chkImage, char8 *caFileName,
                                int32 iFileType)
{
#ifdef MIPSTARGET

    if(!iRet_chkImage) {
        // Free rest of unneeded stuff
#ifndef SPI_SUPPORT
//        ifx_http_remove_modules(); //remove unneeded modules
#endif /* SPI_SUPPORT */
        if(iFileType == FT_FIRMWARE) {
            remove("/flash/rc.conf"); //remove rc.conf
            ifx_invokeUpgd(caFileName, img_type, iExpandDir);
        }
        else {
            if(rename("/tmp/sysconf","/flash/rc.conf") == 0) {
                ifx_run_command("/etc/rc.d/backup");
		sync();
                IFX_Config_RebootSystem();
            } else {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d Failed\n", _FUNCL_);
            }
        }
    }
    else {
	sync();
        IFX_Config_RebootSystem();
    }
#endif // MIPSTARGET
}




#ifdef MIPSTARGET
#if 0
#ifndef SPI_SUPPORT
static void ifx_http_remove_modules()
{
    FILE *fpmod;
    char sModule[70] = {0};
    char sLine[100]={0};
    char *pLine=NULL;
    char *pModule = NULL;
    char sCommand[100]={0};

    fpmod = fopen("/proc/modules","r");
    if(fpmod == NULL)
        goto errorHandler;
    do{
        if(fgets(sLine, 90, fpmod) == NULL)
            break;

        pLine = sLine;
        pModule = sModule;
        while(( *pLine != ' ')&&( *pLine != '\n')){
            *pModule = *pLine;
            pModule++;
            pLine++;
        }

        *pModule = '\0';

        sprintf(sCommand,"rmmod %s ",sModule);
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "[%s : %d] Executing '%s'\n",
                    _FUNCL_, sCommand);
        if(strstr(sCommand, "drv_ter1x66"))
            continue;
        system(sCommand);
    } while(1);

    fclose(fpmod);
  errorHandler:
    return;
}
#endif /* SPI_SUPPORT */
#endif

int
ifx_mod_get_lan_mac(char8 *psMac)
{
    char8  mac[19] = {0};
    FILE *fp = NULL;

    ifx_run_command("upgrade mac_get 0 > /tmp/tmp_mac");
    fp = fopen("/tmp/tmp_mac","r");
    if(fp)
    {
        fread(mac, 19, 1, fp);
        fclose(fp);
    }
    ifx_run_command("rm -rf /tmp/tmp_mac");

    strncpy(psMac, mac, (sizeof(mac) - 1));

    return 0;
}
#endif

Old_Enable_Val axOldIPState[IFX_MAX_CONF_WAN_CONN];
Old_Enable_Val axOldPPPState[IFX_MAX_CONF_WAN_CONN];
Old_Enable_Val axOldRouteState[IFX_MAX_CONF_WAN_CONN];

int32 
IFX_GetSetOldEnableVal(uint32 Cpeid,Old_Enable_Val *axOldState,uint32 *OldEnable,uint32 Oper)
{
    uint32 i=0;
  
    switch(Oper) {

        case IFX_GET_OLD_ENB_VAL:
            for(i=0 ; i < IFX_MAX_CONF_WAN_CONN;i++)
            {
                 if(axOldState[i].uiCpeid == Cpeid) 
                 {
                     *OldEnable=axOldState[i].uiOldEnable;
                     break;
                 }
            }
            break;
        case IFX_SET_OLD_ENB_VAL:
            for(i=0 ; i < IFX_MAX_CONF_WAN_CONN;i++)
            {
                if(axOldState[i].uiCpeid == 0) 
                {
                    axOldState[i].uiCpeid = Cpeid;
                    axOldState[i].uiOldEnable=*OldEnable;
                    break;
                }
            }
            break;
        case IFX_RESET_OLD_ENB_VAL:
            for(i=0 ; i < IFX_MAX_CONF_WAN_CONN;i++)
            {
                if(axOldState[i].uiCpeid == Cpeid) 
                {
                    axOldState[i].uiCpeid = 0;
                    break;
                }
            }
            break;

        default:
            break;
    }

    if(i == IFX_MAX_CONF_WAN_CONN)
        return IFX_CWMP_FAILURE;

    return IFX_CWMP_SUCCESS;
}


int ifx_get_filesize(int option)
{
    if(option == MAX_FW_DL_LIMIT)
        return MAX_FIRMWARE_DL_FILESIZE;

    if(option == MIN_FW_DL_LIMIT)
        return MIN_FIRMWARE_DL_FILESIZE;

    if(option == MAX_SYSCONF_DL_LIMIT)
        return MAX_SYSCONF_DL_FILESIZE;

    if(option == MIN_SYSCONF_DL_LIMIT)
        return MIN_SYSCONF_DL_FILESIZE;

    return 0;
}

extern uint32 uiActiveWANIPCpeid;
extern uint32 uiActiveWANPPPCpeid;
/* To reset global Variables used to maintain state for Status=1 scenarios
   of Active WAN Connection */

void IFX_MOD_CleanUp()
{

//uiActiveWANIPCpeid=0;
//uiActiveWANPPPCpeid=0;

}

static unsigned long randnext = 1;

 /* RAND_MAX assumed to be 32767 */
int32 devmrand(void)
{
    randnext = randnext * 1103515245 + 12345;
    return((unsigned)(randnext/65536) % 32768);
}


int32
IFX_SetVCCWanConDevice(int32 *iaOIDDSL,int32 iCaller, int16 Vpi, int32 Vci, char8 * l2iface_name)
{
    WAN_CONN_DEV xWan_con_dev;
    //uint32 uiParamPos=0;
 //       int32 iaOID[OID_LENGTH];
    int32 iRet=IFX_CWMP_SUCCESS;
    uint32 uiFlags=0;
    uint32 uiParCpeid=0;
    int32 iOper=0;    

    memset(&xWan_con_dev, 0x00, sizeof(WAN_CONN_DEV));    
//    memset(iaOID, 0x00, (sizeof(int32)*OID_LENGTH));
    
//    uiParamPos = IFX_GetParamIdPos(iaOIDDSL);
//    memcpy(iaOID,iaOIDDSL,(sizeof(int32)*uiParamPos));
        
    //Get the parent objects Cpeid
    iRet = IFX_GetParentObjCpeId(iaOIDDSL, &uiParCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    //Set the Vpi and Vci values
    xWan_con_dev.vc.pvc.vpi = Vpi;
    xWan_con_dev.vc.pvc.vci = Vci;
    strncpy(xWan_con_dev.l2iface_name,l2iface_name, strlen(l2iface_name));
        
        
    //Call the ifx_set_wan_conn_dev with modify
    iOper = IFX_OP_MOD;
    xWan_con_dev.iid.cpeId.Id = uiParCpeid;
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"%s: %d WANDev[%d] \
             \n", __FUNCTION__, __LINE__, iaOIDDSL[2]);
    
    xWan_con_dev.iid.pcpeId.Id = iaOIDDSL[2];
    xWan_con_dev.iid.config_owner = iCaller;

    uiFlags= (IFX_F_MODIFY|
        IFX_F_DONT_CHECKPOINT|
        IFX_F_DONT_WRITE_TO_FLASH);
                    
#ifdef IFX_TR69_WAN_MODS_TEST_STUBS    
    ifx_set_wan_conn_dev_stub(iOper, &xWan_con_dev, uiFlags);
#endif
    iRet = ifx_set_wan_conn_dev(iOper, &xWan_con_dev, uiFlags);
    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"ifx_set_wan_conn_dev Modify Mgmt API \
             returned error\n");
        goto errorHandler;
                        
    }    

    return IFX_CWMP_SUCCESS;

errorHandler:
         IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d failed \n", __func__, __LINE__);
        return IFX_CWMP_FAILURE;

}


#ifdef STUNNEL_SSL
static FILE *fptr = NULL;

static int
ifx_config_init()
{
    fptr = fopen(IFX_CWMP_SSL_CONF_FILENAME, "r+");
    if(fptr == NULL) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "Unable to open file %s\n",
                    IFX_CWMP_SSL_CONF_FILENAME);
        return IFX_CWMP_FAILURE;
    }
    return IFX_CWMP_SUCCESS;
}

static void
ifx_config_clean()
{
    if(fptr != NULL)
        fclose(fptr);
    fptr = NULL;
}


static int
ifx_config_fptr_reset()
{
    if(fptr == NULL) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "fptr NULL. %s not opened\n",
                    IFX_CWMP_SSL_CONF_FILENAME);
        return IFX_CWMP_FAILURE;
    }
    if(fseek(fptr, 0, SEEK_SET) != 0) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                    "Unable to set file pointer to the start of file\n");
        return IFX_CWMP_FAILURE;
    }
    return IFX_CWMP_SUCCESS;
}

int
ifx_stunnel_config_set_value(char *key, char *val)
{
    char line[LINESIZE] = { 0 };
    char tmp_line[LINESIZE] = { 0 };
    char *head = NULL;
    FILE *fptr_tmp = NULL;
    int key_found = 0;
    int iRet = 0;


    // open a tmp file and set its pointer to begining
    fptr_tmp = fopen("/tmp/tmpssl", "w+");
    if(fptr_tmp == NULL) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                    "Unable to open tmp ssl config file\n");
        return IFX_CWMP_FAILURE;
    }


    iRet = ifx_config_init();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [Error] UNABLE TO OPEN STUNNEL CONFIG FILE\n",
                    _FUNCL_);
        return IFX_CWMP_FAILURE;
    }

    ifx_config_fptr_reset();
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [Error] UNABLE TO OPEN STUNNEL CONFIG FILE\n",
                    _FUNCL_);
        return IFX_CWMP_FAILURE;
    }

    do {
        if(fgets(line, LINESIZE, fptr) == NULL) {

            // close all the open files
            ifx_config_clean();
            if(fptr_tmp != NULL)
                fclose(fptr_tmp);
            fptr_tmp = NULL;

            if(key_found == 0) {
                val = NULL;
                return IFX_CWMP_FAILURE;
            }
            else {              // key found and file end

                rename("/tmp/tmpssl", IFX_CWMP_SSL_CONF_FILENAME);
                remove("/tmp/tmpssl");
                return IFX_CWMP_SUCCESS;
            }                   // end if-else
        }

        strcpy(tmp_line, line);

        head = strtok(line, TOKEN);


        if(head != NULL) {
            if(strstr(head, key) != NULL) {
                /* If the line contains verify */
                if(!strcmp(key,"verify"))
                {
                    /* If key = "verify" and val = "0", then comment line, else nothing */
                    if(!strncmp(val,"0",1)) {
                        fwrite("# verify", strlen("# verify"), 1, fptr_tmp);
                        fwrite(" = ", 3, 1, fptr_tmp);
                        fwrite(val, strlen(val), 1, fptr_tmp);
                        fwrite("\n", 1, 1, fptr_tmp);
                        key_found = 1;  // set the flag
                        continue;
                    }
                    else {
                        fwrite(key, strlen(key), 1, fptr_tmp);
                        fwrite(" = ", 3, 1, fptr_tmp);
                        fwrite(val, strlen(val), 1, fptr_tmp);
                        fwrite("\n", 1, 1, fptr_tmp);
                        key_found = 1;  // set the flag
                        continue;
                    }
                }
                /* If the line is not a comment */
                if(*head != '#')
                {
                    // if the line with the key found, write the new key=val pair 
                    fwrite(key, strlen(key), 1, fptr_tmp);
                    fwrite(" = ", 3, 1, fptr_tmp);
                    fwrite(val, strlen(val), 1, fptr_tmp);
                    fwrite("\n", 1, 1, fptr_tmp);
                    key_found = 1;  // set the flag
                }
            }
            else {              // write the line as it is in the tmp file
                fprintf(fptr_tmp, tmp_line);
            }                   // end if-else
        }
    } while(1);

// code will never reach here
    return IFX_CWMP_SUCCESS;
}
#endif

/****************************************

operation :     0 = tr69 session
		1 = download session

****************************************/
int
startSSL(char *url, int operation)
{
    FILE *fp = NULL;
    char argstring[250] = { 0 };

    if(!strncmp(url, "https://", strlen("https://"))) {
        char *tmp = NULL;
        char a = '\0';
        pid_t tPid = 0;
        tmp = strchr(url + strlen("https://"), '/');
        if(tmp) {
            a = *tmp;
            *tmp = '\0';
            *tmp = 0;
        }
#ifdef STUNNEL_SSL
        char https_port[5] = ":443";
        char https_url[256] = { 0 };

        strcpy(https_url,url);
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,"URL received : %s \n",https_url);
        /* If URL contains https:// */
        if(!strncmp(https_url,"https://", strlen("https://")))
        {
            char *port = NULL;
            port = strchr(https_url + strlen("https://"), ':');
            if (port == NULL)
            {
                strcat(https_url , https_port);
            }
            else if ((*(port+1) == '\0') || (!(isdigit(*(port+1)))))
            {
                /* Replace ':' with '\0' in the https_url */
                *port = '\0';
                strcat(https_url , https_port);
            }

            FILE *cert = fopen ("/flash/Cert.pem" , "r");
            if( cert != NULL )
            {
                fclose(cert);
                if(ifx_stunnel_config_set_value("verify", "1") != 0) {
                    return IFX_CWMP_FAILURE;
                }
            }
            else
            {
                if(ifx_stunnel_config_set_value("verify", "0") != 0) {
                    return IFX_CWMP_FAILURE;
                }
            }
        }
        if(ifx_stunnel_config_set_value("connect", https_url + strlen("https://")) !=
           0) {
            return IFX_CWMP_FAILURE;
        }

        // prepare the arguments to be given to execlp
        strcpy(argstring, IFX_CWMP_SSL_CONF_FILENAME);
#endif

#ifdef MATRIX_SSL
        strcpy(argstring,
               IFX_CWMP_SSL_EXE " -c -v1 -P " IFX_CWMP_SSL_PID_FILE " -d " SSL_IP ":" SSL_PORT " -r ");
        if(strlen(argstring) + strlen(url) < sizeof(argstring))
            strcat(argstring, url + strlen("https://"));
        else
            return IFX_CWMP_FAILURE;
#endif

        if(tmp) {
            *tmp = a;
        }

        remove(IFX_CWMP_SSL_PID_FILE);

#ifdef STUNNEL_SSL
        tPid = fork();

        if(tPid == 0) {
            sleep(3);

            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                        "In Function [%s] : Executing : %s %s\n", __func__,
                        IFX_CWMP_SSL_EXE, argstring);

            if(execlp(IFX_CWMP_SSL_EXE, IFX_CWMP_SSL_EXE, argstring, (char *)0)
               == -1) {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                            "In Function [%s] : Error--> Failed to start SSL!!\n\n",
                            __func__);
                return IFX_CWMP_FAILURE;
            }
        }
        else {

#endif
#ifdef MATRIX_SSL
/*            if(1) {*/
                ifx_run_command(argstring);
#endif
                do {
                    while((fp = fopen(IFX_CWMP_SSL_PID_FILE, "r")) == NULL);
                    fscanf(fp, "%d", &tPid);
                    fclose(fp);
                    if((tPid < 0) || (tPid > 32767))
                        return IFX_CWMP_FAILURE;

                } while(tPid == 0);
                /* Some cases, SSL pid is 0, to ignore that and wait till new
                   pid is written */

                g_ssl_pid[operation] = tPid;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                            "PID of Stunnel = %d\n", g_ssl_pid[operation]);
                // break; 
#ifdef STUNNEL_SSL
            }
#endif
    }
    return IFX_CWMP_SUCCESS;
}


/***************************************************
Return value :
	SUCCESS : if propper process is killed
		  or when there is no process to kill

	FAILURE : when there is a process to kill
		   but kill fails

****************************************************/

int
stopSSL(int operation)
{
    int status = 0, /*status1 = 0, status2=0, status3=0,*/ temp_pid=0;
    pid_t tPid=0;
    FILE *fp=NULL;

    if((fp = fopen(IFX_CWMP_SSL_PID_FILE, "r")) != NULL) {
        fscanf(fp, "%d", &tPid);
        fclose(fp);
        /* Some cases, SSL pid is 0, to ignore that and wait till new
           pid is written */
        g_ssl_pid[operation] = tPid;
        remove(IFX_CWMP_SSL_PID_FILE);
    }

    if(g_ssl_pid[operation] > 1) {
        // First send SIGTERM to (s)tunnel for clean shutdown. Then send SIGKILL for forcefull shutdown
        status = kill(g_ssl_pid[operation], SIGTERM);
        temp_pid = (g_ssl_pid[operation]) + 1;
        /*status2 =*/ kill(temp_pid, SIGTERM);

	/*status1 =*/ kill(g_ssl_pid[operation], SIGKILL);
        /*status3 =*/ kill(temp_pid, SIGKILL);
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "Killing stunnel %d\n",
                    g_ssl_pid[operation]);
    }

    g_ssl_pid[operation] = -1;

    if(status == 0) {
        giStunnelProcess = 0;
        return IFX_CWMP_SUCCESS;
    }
    else
        return IFX_CWMP_FAILURE;
}

#ifdef DEVICE_SUPPORT
int32 IFX_HostHandleDHCPLeaseChange(void)
{
        return IFX_CWMP_SUCCESS;
}

int32
Lease_Duration_Exipry()
{
        return IFX_SUCCESS;
}
#endif

#if defined(DEVICE_SUPPORT)||!defined(IFX_TR69_WIFILAN)
int32 IFX_BuildAssocDevList(void)
{
        return IFX_CWMP_SUCCESS;
}
#endif

