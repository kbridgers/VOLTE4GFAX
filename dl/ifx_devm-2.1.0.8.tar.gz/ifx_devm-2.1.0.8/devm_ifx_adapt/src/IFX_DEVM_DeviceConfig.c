/*
 * ** =============================================================================
 * ** FILE NAME   : IFX_DEVM_DeviceConfig.c
 * ** PROJECT     : TR69
 * ** MODULES     : (InternetGateway) Device.DeviceConfig.ConfigFile.
 * ** DATE        :
 * ** AUTHOR      : TR69 team
 * ** DESCRIPTION : AddObject / DeleteObject cannot be performed on this object.
 * **
 * ** REFERENCES  :
 * ** COPYRIGHT   : Copyright (c) 2006
 * **               Infineon Technologies AG
 * **               Am Campeon 1-12, 85579 Neubiberg, Germany
 * **
 * ** Any use of this software is subject to the conclusion of a respective
 * ** License agreement. Without such a License agreement no rights to the
 * ** software are granted
 * **
 * ** HISTORY     :
 * ** $Date       $Author        $Comment
 * **             TR69 team      Creation
 * ** =============================================================================
 * */


#include "IFX_DEVM_Global.h"

#include "IFX_DEVM_AdaptCommon.h"


#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_StackUtil.h"
#include <resolv.h>
#include <sys/time.h>

extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char *obj, modFunc pifx_module_func);

#define DEVICECONFIG_OBJ                      FORMNAME("DeviceConfig.")
#define DEVICECONFIG_DEPTH                    3


/*******************************************************************************
 * * Function: DeviceConfigSetAttrInfo
 * * Desc: Sets attribute information in the respective tr69 sections
 * * Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
static int32
DeviceConfigSetAttrInfo(IN int32 iCaller, INOUT ParamVal * pxPV,
                        IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    iRet = IFX_SetAttributesInfo(NULL, pxPV, iElements);

    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Updating Param Attribute Info failed\n",
                    _FUNCL_, iRet);
        goto errorHandler;
    }
  errorHandler:
    return iRet;
}


int32 LTQ_DEVM_GetDeviceConfig(char8 *xConfigFile)
{
    int iRet = IFX_CWMP_SUCCESS;
    if(xConfigFile == NULL)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Error!\n", _FUNCL_);
        goto ErrorHandler;
    }

    iRet = ifx_mapi_backup_config(0);

        if(iRet != IFX_SUCCESS) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d [%d] ifx_mapi_backup_config() failed\n", _FUNCL_, iRet);
            iRet = ERR_CWMP_INTERNAL;
            goto ErrorHandler;
        }
    iRet = ifx_get_configfile(xConfigFile);

   if(iRet != IFX_SUCCESS) { 
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_configfile() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto ErrorHandler;
    }

    ErrorHandler:
        return iRet;
}


/*******************************************************************************
 * * Function: DeviceConfigGetNotifyValue
 * * Desc: 
 * *              
 * * Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
static int32
DeviceConfigGetNotifyValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                           IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    char8 *xConfigFile = NULL;

    xConfigFile = IFX_CWMP_MALLOC(32768);
    if(xConfigFile == NULL)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", _FUNCL_);
        iRet = ERR_OUT_OF_MEMORY;
        goto errorHandler;
    }

    iRet = ifx_mapi_backup_config(0);

    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_mapi_backup_config() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }

    iRet = ifx_get_configfile(xConfigFile);

    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_configfile() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
    for(iI = 0; iI < iElements; iI++)
    {
        switch (pxPV[iI].iaOID[DEVICECONFIG_DEPTH - 1])
        {
            case OID_IGD_DC_CONFIGFILE:
                pxPV[iI].Value = xConfigFile;
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", _FUNCL_,
                            pxPV[iI].iaOID[DEVICECONFIG_DEPTH - 1]);
                break;
        }
    }
    errorHandler:	
  		if (iRet != IFX_SUCCESS)			//ramesh
			IFX_MEM_FREE(xConfigFile);
        return iRet;
}


/*******************************************************************************
 * * Function: DeviceConfigSetValue
 * * Desc:
 * *              
 * * Parameters: INOUT ParamVal * pxPV, IN int32 iElements
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
static int32
DeviceConfigSetValue(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    char8 configfile[32768];

    memset(configfile, '\0', 32768);

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[DEVICECONFIG_DEPTH - 1]) {
            case OID_IGD_DC_CONFIGFILE:
                strcpy(configfile, pxPV[iI].Value);
                break;

            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", _FUNCL_,
                            pxPV[iI].iaOID[DEVICECONFIG_DEPTH - 1]);
                break;
        }

    }

// Convert File from ASCII and copy to rc.conf
    iRet = ifx_set_configfile(configfile);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_set_configfile() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }

    iRet = ifx_mapi_restore_config(0 , 0);
//iRet = -2;
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_mapi_restore_config() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
    iRet = IFX_CWMP_NEED_ACTIVATE;


  errorHandler:
    return iRet;
}



 /*******************************************************************************
 * * Function: IFX_DeviceConfig
 * * Desc: 
 * *              
 * * Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
 * *             OUT void **ppRet, OUT int32 * piNumRetElem
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
int32
IFX_DeviceConfig(IN OperInfo * pxOI,
                 INOUT void *pParamStruct,
                 IN int32 iElements, OUT void **ppRet, OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;

    switch (pxOI->iOper) {
        case OP_GETVAL:
            {
                if ((pxOI->iCaller == ACC_UPNP) || (pxOI->iCaller == ACC_TR64))
                {
                    if((iRet =  DeviceConfigGetNotifyValue(pxOI,xpParamVal, iElements)) != IFX_CWMP_SUCCESS)
                    {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                 "%s:%d OP_GETVAL failed!\n", _FUNCL_);
                        goto errorHandler;
                    }
                }
                else
                {
                    switch (pxOI->iSubOper) {
                        case OP_GETVAL_NORMAL:
                                iRet = DeviceConfigGetNotifyValue(pxOI, xpParamVal,
                                                                  iElements);
                            if(iRet != IFX_CWMP_SUCCESS) {
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                           "%s:%d DeviceConfigGetNotifyValue failed.\n",
                                           _FUNCL_);
                                goto errorHandler;
                            }
                         
                            break;

                        default:
                            break;
                    }
                }
                break;
            }
        case OP_SETVAL:
            {
                switch (pxOI->iSubOper) {
                    case OP_SETVAL_VALIDATE:
                        break;
                    case OP_SETVAL_ADD:
                        iRet = ERR_CWMP_INVAL_ARGS;
                        goto errorHandler;
                    case OP_SETVAL_CHK_MODIFY_DEP:
                        break;
                    case OP_SETVAL_MODIFY:
                        iRet = DeviceConfigSetValue(xpParamVal, iElements);
                        if((iRet != IFX_SUCCESS)
                           && (iRet != IFX_CWMP_NEED_ACTIVATE))
                            goto errorHandler;
                        break;
                    case OP_SETVAL_ACTIVATE:
                         iRet = IFX_CWMP_NEED_REBOOT ;
                        break;
                    case OP_SETVAL_COMMIT:
                        break;
                    case OP_SETVAL_UNDO:
                        iRet = ERR_CWMP_INVAL_ARGS;
                        goto errorHandler;
                        break;
                    case OP_SETVAL_CHK_DEL_DEP:
                        iRet = ERR_CWMP_INVAL_ARGS;
                        goto errorHandler;
                        break;
                    case OP_SETVAL_CHK_DEL_ALLOWED:
                        iRet = ERR_CWMP_INVAL_ARGS;
                        goto errorHandler;
                        break;
                    case OP_SETVAL_DELETE:
                        iRet = ERR_CWMP_INVAL_ARGS;
                        goto errorHandler;
                        break;
                    case OP_SETVAL_FREE:
                        break;
                    case OP_SETVAL_ATTRINFO:
                        iRet =
                            DeviceConfigSetAttrInfo(pxOI->iCaller, pParamStruct,
                                                    iElements);
                        if(iRet != IFX_CWMP_SUCCESS)
                            goto errorHandler;
                        break;
                    default:
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d [%d] Error! Default case.\n",
                                    _FUNCL_, pxOI->iSubOper);
                        break;
                }
                break;
            }
        case OP_UPDATE_CHILDINFO:
            {
                switch (pxOI->iSubOper) {
                    case OP_UPDATE_CHILDINFO_ADD:
                        iRet = ERR_CWMP_INVAL_ARGS;
                        goto errorHandler;
                        break;
                    case OP_UPDATE_CHILDINFO_DEL:
                        iRet = ERR_CWMP_INVAL_ARGS;
                        goto errorHandler;
                        break;
                }
                break;
            }
        case OP_PARAM_VALIDATE:
            {
                break;
            }
        default:
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                            pxOI->iOper);
                break;
            }
    }
  errorHandler:
    if(iRet == IFX_CWMP_FAILURE)
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d %s failed.\n", _FUNCL_,
                    __func__);
    return iRet;
}


/*******************************************************************************
 * * Function: DeviceConfigInit                                  
 * * Desc: Will register itself with DS.
 * * Parameters:  
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
int32
IFX_DeviceConfigInit()
{
    int32 iRet = IFX_CWMP_SUCCESS;

    iRet = ifx_ds_register_function(DEVICECONFIG_OBJ, IFX_DeviceConfig);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Unable to Register %s with Object Model\n",
                    _FUNCL_, iRet, DEVICECONFIG_OBJ);
        goto errorHandler;
    }

    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_set_configfile failed\n", _FUNCL_, iRet);
        goto errorHandler;
    }


  errorHandler:
    return iRet;
}



