/*
** =============================================================================
** FILE NAME   : IFX_IFX.c
** PROJECT     : TR69
** MODULES     : (InternetGateway) Device.X_AC9A96_LTQ.
** DATE        : 19-Jun-2006
** AUTHOR      : TR69 team
** DESCRIPTION : This object is RO. SetParameterValues or AddObject cannot be
**               performed on this object.
** REFERENCES  :  
** COPYRIGHT   : Copyright (c) 2006
**               Infineon Technologies AG
**               Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY     : 
** $Date        $Author          $Comment
** 30-Aug-2006  TR69 team        Creation         
** =============================================================================
*/
#include "IFX_DEVM_Global.h"
 
#include "IFX_DEVM_AdaptCommon.h"
#include "IFX_DEVM_OID.h"
 
#include "IFX_DEVM_Platform.h"

extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char *obj, modFunc pifx_module_func);

#define IFX_OBJ       FORMNAME("X_AC9A96_LTQ.")
#define IFX_DEPTH     3

/*******************************************************************************
* Function: IFX_IFXSetAttrInfo
* Desc: 
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: 
*******************************************************************************/
static int32
IFX_IFXSetAttrInfo(IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = ERR_CWMP_REQUEST_DENIED;
    return iRet;
}

/*******************************************************************************
* Function: IFX_IFXGetNotifyValue
* Desc: 
* Parameters: IN OperInfo *pxOI, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: 
*******************************************************************************/
static int32
IFX_IFXGetNotifyValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                      IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    return iRet;
}

/*******************************************************************************
* Function: IFX_IFXGetValue
* Desc: 
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_IFXGetValue(IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    TR69_MISC xTR69Misc;

    memset(&xTR69Misc, 0, sizeof(xTR69Misc));
    iRet = ifx_get_tr69_misc(&xTR69Misc, 0);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] "
                    "ifx_get_tr69_misc() failed\n", __func__, __LINE__, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
    for(iI = 0; iI < iElements; iI++) {
#define IFX_TR69_MAX_IFX_IFX_MODULE_ALLOC_SIZE 32

        pxPV[iI].Value = IFX_CWMP_MALLOC(IFX_TR69_MAX_IFX_IFX_MODULE_ALLOC_SIZE);
        if(pxPV[iI].Value == NULL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", __func__, __LINE__);
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (pxPV[iI].iaOID[IFX_DEPTH - 1]) {
            case OID_IGD_XAC9A96LTQ_AUTHACS:
                sprintf(pxPV[iI].Value, "%d", xTR69Misc.auth_acs);
                break;
            case OID_IGD_XAC9A96LTQ_AUTHTYPE:
                strcpy(pxPV[iI].Value, xTR69Misc.auth_type);
                break;
            case OID_IGD_XAC9A96LTQ_EVENT:
                sprintf(pxPV[iI].Value, "%u", xTR69Misc.event);
                break;
            case OID_IGD_XAC9A96LTQ_COMMANDKEY:
                strcpy(pxPV[iI].Value, xTR69Misc.cmd_key);
                break;
            case OID_IGD_XAC9A96LTQ_INCLUDEXMLVERSTRING:
                sprintf(pxPV[iI].Value, "%d", xTR69Misc.inc_xml);
                break;
            case OID_IGD_XAC9A96LTQ_INCLUDESOAPACTION:
                sprintf(pxPV[iI].Value, "%d", xTR69Misc.inc_soap_action);
                break;
            case OID_IGD_XAC9A96LTQ_ACSGETRPC:
                sprintf(pxPV[iI].Value, "%d", xTR69Misc.acs_get_rpc);
                break;
            case OID_IGD_XAC9A96LTQ_BOOTSTRAP:
                sprintf(pxPV[iI].Value, "%d", xTR69Misc.bootstrap);
                break;
            case OID_IGD_XAC9A96LTQ_INSTANCES:
                IFX_CWMP_FREE(pxPV[iI].Value);
                IFX_GetTr69Instances((char8 **) & pxPV[iI].Value);
                break;
#ifdef TR64_SUPPORT
            case OID_IGD_XAC9A96LTQ_TR64ENABLE:
                sprintf(pxPV[iI].Value, "%d", xTR69Misc.tr64_enable);
                break;
            case OID_IGD_XAC9A96LTQ_UPNPENABLE:
                sprintf(pxPV[iI].Value, "%d", xTR69Misc.upnp_enable);
                break;
#endif
            case OID_IGD_XAC9A96LTQ_PREVIOUSTIME:
                sprintf(pxPV[iI].Value, "%d", xTR69Misc.abs_prev_time);
                break;
	    case OID_IGD_XAC9A96LTQ_URLSTATUS:
                sprintf(pxPV[iI].Value, "%d", xTR69Misc.url_status);
		break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                            "Default case\n", __func__, __LINE__,
                            pxPV[iI].iaOID[IFX_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_IFXValidate
* Desc:
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_IFXValidate(IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;

    if(iCaller != ACC_ROOT) {
        iRet = ERR_CWMP_INVAL_ARGS;
        pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
    }

    return iRet;
}

/*******************************************************************************
* Function: IFX_IFXModify
* Desc:
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_IFXModify(IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    TR69_MISC xTR69Misc;

    memset(&xTR69Misc, 0, sizeof(xTR69Misc));
    iRet = ifx_get_tr69_misc(&xTR69Misc, 0);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] "
                    "ifx_get_tr69_misc() failed\n", __func__, __LINE__, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[IFX_DEPTH - 1]) {
            case OID_IGD_XAC9A96LTQ_AUTHACS:
            case OID_IGD_XAC9A96LTQ_AUTHTYPE:
            case OID_IGD_XAC9A96LTQ_INCLUDEXMLVERSTRING:
            case OID_IGD_XAC9A96LTQ_ACSGETRPC:
            case OID_IGD_XAC9A96LTQ_INCLUDESOAPACTION:
            case OID_IGD_XAC9A96LTQ_BOOTSTRAP:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                goto errorHandler;
                break;
            case OID_IGD_XAC9A96LTQ_EVENT:
                xTR69Misc.event = (uint32) atoi(pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_COMMANDKEY:
                strcpy(xTR69Misc.cmd_key, pxPV[iI].Value);
                break;
            case OID_IGD_XAC9A96LTQ_INSTANCES:
                IFX_SetTr69Instances(pxPV[iI].Value);
                break;
#ifdef TR64_SUPPORT
            case OID_IGD_XAC9A96LTQ_TR64ENABLE:
            case OID_IGD_XAC9A96LTQ_UPNPENABLE:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                goto errorHandler;
                break;
#endif
            case OID_IGD_XAC9A96LTQ_PREVIOUSTIME:
                xTR69Misc.abs_prev_time = atoi(pxPV[iI].Value);
                break;
	    case OID_IGD_XAC9A96LTQ_URLSTATUS:
                xTR69Misc.url_status = atoi(pxPV[iI].Value);
		break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! " "Default case\n", __func__,
                            __LINE__, pxPV[iI].iaOID[IFX_DEPTH - 1]);
                break;
        }
    }

    xTR69Misc.iid.config_owner = IFX_TR69;

    iRet = ifx_set_tr69_misc(IFX_OP_MOD, &xTR69Misc,
                             IFX_F_MODIFY | IFX_F_DONT_WRITE_TO_FLASH |
                             IFX_F_DONT_CHECKPOINT);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] "
                    "ifx_set_tr69_misc() failed\n", __func__, __LINE__, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_IFX
* Desc: 
* Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
*             OUT void **ppRet, OUT int32 * piNumRetElem
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_IFX(IN OperInfo * pxOI, INOUT void *pParamStruct,
        IN int32 iElements, OUT void **ppRet, OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;
    uint32 iCnt = 0;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "%s: %s oper=%d maxElement=%d\n",
                __func__, xpParamVal[0].Name, pxOI->iSubOper, iElements);
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                    iRet = IFX_IFXGetValue(pxOI->iCaller, xpParamVal,
                                           iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_GETVAL_NOTIFICATION:
                    iRet = IFX_IFXGetNotifyValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n",
                                __func__, __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                    iRet = IFX_IFXValidate(pxOI->iCaller, xpParamVal,
                                           iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_SETVAL_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:
                    break;
                case OP_SETVAL_MODIFY:
                    iRet = IFX_IFXModify(pxOI->iCaller, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_SETVAL_COMMIT:
                    break;
                case OP_SETVAL_UNDO:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_DELETE:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_ACTIVATE:
                    break;
                case OP_SETVAL_ATTRINFO:
                    IFX_IFXSetAttrInfo(pxOI->iCaller, pParamStruct, iElements);
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n",
                                __func__, __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_UPDATE_CHILDINFO_DEL:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            /*Vendor specific parameters should not be reported to ACS. It 
              should be available for internal updation */
            if(pxOI->iCaller == ACC_TR69)
            {
                /* Set the fault code to Error */
                for(iCnt = 0; iCnt < iElements; iCnt++)
                {
                    xpParamVal[iCnt].iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
                }
            }
            break;
        }

        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! "
                        "Default case\n", __func__, __LINE__, pxOI->iOper);
            break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_IFXInit
* Desc: Will initialize some of its data structures, register itself with DS
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_IFXInit()
{
    int32 iRet = IFX_CWMP_SUCCESS;
    /* TBD: Perform any IFXInit related initializations here */
    /* Register the IFX_IFXInit func ptr in the object model */
    iRet = ifx_ds_register_function(IFX_OBJ, IFX_IFX);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_OBJ);
        goto errorHandler;
    }

  errorHandler:
    return iRet;
}
