/*
** =============================================================================
** FILE NAME      : IFX_LANEthernetIfConfigStats.c
** PROJECT        : TR69
** MODULES        : IGD.LANDevice.1.LANEthernetInterfaceConfig.1.Stats.
** DATE           : 15-Jun-2006
** AUTHOR         : TR69 team
** DESCRIPTION    : This object is RO. SetParameterValues or AddObject cannot be
**                  performed on this object.
** REFERENCES     :  
** COPYRIGHT      : Copyright (c) 2006
**                  Infineon Technologies AG
**                  Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
** HISTORY        : 
** $Date        $Author          $Comment
** 15-Jun-2006  Tr69 team        Creation
** =============================================================================
*/

#include "IFX_DEVM_Global.h"
 
#include "IFX_DEVM_AdaptCommon.h"
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"

extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char8 * obj, modFunc pifx_module_func);

#define LUSBICSTATS_OBJ    "InternetGatewayDevice.LANDevice.1.LANUSBInterfaceConfig.1.Stats."
#define LUSBICSTATS_DEPTH  7

/*******************************************************************************
* Function: IFX_LUSBICStatsSetAttrInfo
* Description: Sets attribute information in the respective tr69 sections
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_LUSBICStatsSetAttrInfo(IN int32 iCaller, INOUT ParamVal * pxPV,
                         IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    iRet = IFX_SetAttributesInfo(NULL, pxPV, iElements);

    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Updating Param Attribute Info failed\n",
                    __func__, __LINE__, iRet);
        goto errorHandler;
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_LUSBICStatsGetValue
* Description: Hard coding it to br0 interface. An enhancement on this can be 
*              performed. 
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
#define   USB_STATS_GET_ALLOC                12
static int32
IFX_LUSBICStatsGetValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                      IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0, iTmp = 0;
    IF_STATS xIfStats;
    char8 sTmp[USB_STATS_GET_ALLOC] = {0};

    memset(&xIfStats, '\0', sizeof(IF_STATS));
#ifdef MIPSTARGET
    iTmp = ifx_get_if_stats("usb0", &xIfStats, 0);
#endif
    if(iTmp != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] "
                    "ifx_get_if_stats() failed\n", __func__, __LINE__, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
    for(iI = 0; iI < iElements; iI++) {
        pxPV[iI].Value = IFX_CWMP_MALLOC(USB_STATS_GET_ALLOC + 1);
        if(pxPV[iI].Value == NULL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", __func__, __LINE__);
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (pxPV[iI].iaOID[LUSBICSTATS_DEPTH - 1]) {
            case OID_IGD_LAND_LANUSBIC_S_BYTESSENT:
                sprintf(sTmp, "%lu", xIfStats.tx_bytes);
                strcpy(pxPV[iI].Value, sTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_LAND_LANUSBIC_S_BYTESRECEIVED:
                sprintf(sTmp, "%lu", xIfStats.rx_bytes);
                strcpy(pxPV[iI].Value, sTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_LAND_LANUSBIC_S_CELLSSENT:
                sprintf(sTmp, "%lu", xIfStats.tx_pkts);
                strcpy(pxPV[iI].Value, sTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_LAND_LANUSBIC_S_CELLSRECEIVED:
                sprintf(sTmp, "%lu", xIfStats.rx_pkts);
                strcpy(pxPV[iI].Value, sTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", __func__,
                            __LINE__, pxPV[iI].iaOID[LUSBICSTATS_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_LUSBICStatsValidate
* Description: Since this is a Stats obj, only read is allowed. SetValidate will
*              be called befor SETVAL is actually called. It returns err for 
*              each SETVAL being called.
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_LUSBICStatsValidate(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[LUSBICSTATS_DEPTH - 1]) {
            case OID_IGD_LAND_LANUSBIC_S_BYTESSENT:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            case OID_IGD_LAND_LANUSBIC_S_BYTESRECEIVED:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            case OID_IGD_LAND_LANUSBIC_S_CELLSSENT:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            case OID_IGD_LAND_LANUSBIC_S_CELLSRECEIVED:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", __func__,
                            __LINE__, pxPV[iI].iaOID[LUSBICSTATS_DEPTH - 1]);
                break;
        }
    }
    return iRet;
}

/*******************************************************************************
* Function: IFX_LANUSBIfCfgStats
* Description: This function is registered with the data model. Handles on 
*              GETVAL. For all other returns err code.
* Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
*             OUT void **ppRet, OUT int32 * piNumRetElem
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_LANUSBIfCfgStats(IN OperInfo * pxOI, INOUT void *pParamStruct,
                          IN int32 iElements, OUT void **ppRet,
                          OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s: %s oper=%d maxElem=%d\n",
                __func__, xpParamVal[0].Name, pxOI->iOper, iElements);

    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                    iRet = IFX_LUSBICStatsGetValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_GETVAL_NOTIFICATION:
                    iRet = IFX_LUSBICStatsGetValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                    if((iRet =
                        IFX_LUSBICStatsValidate(xpParamVal, iElements)) != 0) {
                        goto errorHandler;
                    }
                    break;
                case OP_SETVAL_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:
                    break;
                case OP_SETVAL_MODIFY:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_COMMIT:
                    break;
                case OP_SETVAL_UNDO:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_DELETE:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_ATTRINFO:
                    iRet = IFX_LUSBICStatsSetAttrInfo(pxOI->iCaller, pParamStruct,
                                                    iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_UPDATE_CHILDINFO_DEL:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d [%d] Error! Default case\n", __func__,
                        __LINE__, pxOI->iOper);
            break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_LANUSBIfCfgStatsInit
* Description: Will initialize some of its data structures, register itself with 
*              DS.
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_LANUSBIfCfgStatsInit()
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* TBD: Perform any LANEthernetIfCfgStatsInit related initializations here */

    /* Register the IFX_LANUSBIfCfgStatsInit func ptr in the object model */
    iRet = ifx_ds_register_function(LUSBICSTATS_OBJ, IFX_LANUSBIfCfgStats);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d Unable to Register %s with Object Model\n",
                    __func__, __LINE__, LUSBICSTATS_OBJ);
        goto errorHandler;
    }

  errorHandler:
    return iRet;
}
