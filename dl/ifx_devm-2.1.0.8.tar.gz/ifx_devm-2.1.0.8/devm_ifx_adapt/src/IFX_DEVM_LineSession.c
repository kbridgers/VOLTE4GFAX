/* 
** =============================================================================
**   FILE NAME        : IFX_LineSession
**   PROJECT          : TR104
**   MODULES          : IFX_LineSession
**   DATE             : 17-11-2006
**   AUTHOR           : TR104 team
**   DESCRIPTION   :

**   REFERENCES      : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2004
**                   	      Infineon Technologies AG, st. Martin Strasse 53;
**                   	      81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/


/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "ifx_vmapi_common.h"
#include "IFX_DEVM_VoiceLine.h"
  // Required for STATIC
 
#include "IFX_DEVM_OID.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
 
#include "IFX_DEVM_AdaptCommon.h"
#include "IFX_DEVM_DS.h"

//#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

int32
IFX_LineSession(IN OperInfo * pxOI, INOUT void *pParamList,
                     IN int32 iNumElem, OUT void **ppRet,
                     OUT int32 * piNumRetElem);

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFX_LINESESSION_OBJ "InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.1.Line.1.Session.1."


/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/
STATIC int32
GetVal(IN int32 iCaller, INOUT ParamVal *pxParamVal,
                    IN int32 iElements);
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
GetModifyDep(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
GetNotify(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
                 IN int32 iElements);
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);
/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/

/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetVal(IN int32 iCaller, INOUT ParamVal *pxParamVal,
                    IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iRtn = IFX_SUCCESS;
    int32   iCnt = 0;
    int32   iTmpCnt = -1; /* Mandatory */
    int32   iParamOffset;
    int32   iOID;
    int32   iMemErrorFlag = 0; /* Mandatory */
    x_IFX_VMAPI_LineSession xLineSession;
    uint32 uiPCpeId;

    /* NOTE: For all parameters fault code is set to success by default. If error in
       validating first parameter, fault code is set to the error type and other
       parameters are not validated. */
    /* NOTE: For all parameters value is set to NULL by default. */

    /* Set the fault code to Success and value to NULL pointer for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);

    memset(&xLineSession, 0, sizeof(x_IFX_VMAPI_LineSession));

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_L_S:{

            char8 sOidString[100] = {0};
            IFX_CpeId *pxCpeIdArray = NULL;
            unsigned int uiNumCpeId;

            /* Get the Parent CPE Id */
            IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT &uiPCpeId);
            xLineSession.iid.pcpeId.Id = uiPCpeId;

            /*ignore the last value as it will be a parameter and we need 
              only till the last instance*/
            iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );

            strcpy(xLineSession.iid.tr69Id,sOidString);

            /*Get the CPE Id from the corresponding tr69 Id */
            iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId,
                               OUT &pxCpeIdArray);
            if(iRet != IFX_CWMP_SUCCESS){
                   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                   __func__, __LINE__);

              return ERR_CWMP_INTERNAL;
            }
            //printf("CPEID is %d\n",pxCpeIdArray->uiId);   

            /* Fill the CPE ID of the object instance */
            xLineSession.iid.cpeId.Id = pxCpeIdArray->uiId;
            xLineSession.iid.config_owner = IFX_TR69;

            /* Get all the Voice Line Session parameters using VMAPI */
            //iRtn = ifx_get_LineVoiceSession(&xLineSession, IFX_F_DEFAULT);

            IFX_CWMP_FREE(pxCpeIdArray);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to get values of all "
                            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto cleanup;
            }
            }
            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_S_VS_VP_L_S_SESSIONSTARTTIME:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                               sizeof(xLineSession.acSessStartTime));

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }


               /* Copy the value to allocated area */
               /*strcpy((pxParamVal[iCnt]).Value ,
                                xLineSession.acSessStartTime);*/
 
               //strcpy((pxParamVal[iCnt]).Value , "00:00");
               IFX_MOD_TimeIntToStr((time_t *) & xLineSession.acSessStartTime,
                                     (char8 *) pxParamVal[iCnt].Value);
            break;  
          case OID_IGD_S_VS_VP_L_S_SESSIONDURATION:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                    sizeof(uint32));

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

               /* Copy the value to allocated area */
               /*sprintf((pxParamVal[iCnt]).Value, "%d", 
                                xLineSession.uiSessDuration);*/
               sprintf((pxParamVal[iCnt]).Value, "%d", 0);
 
            break; 
          case OID_IGD_S_VS_VP_L_S_FARENDIPADDRESS:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                sizeof(xLineSession.acDestAddress));

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }


               /* Copy the value to allocated area */
               //strcpy((pxParamVal[iCnt]).Value , xLineSession.acDestAddress);
               strcpy((pxParamVal[iCnt]).Value , "localhost");
 
            break; 
          case OID_IGD_S_VS_VP_L_S_FARENDUDPPORT:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                    sizeof(uint16));

                /* Check for error */
                if (!((pxParamVal[iCnt]).Value))
                {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

               /* Copy the value to allocated area */
               //sprintf((pxParamVal[iCnt]).Value, "%d", xLineSession.unDestPort);
               sprintf((pxParamVal[iCnt]).Value, "%d", 0);
 
            break; 
          case OID_IGD_S_VS_VP_L_S_LOCALUDPPORT:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                    sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              //sprintf((pxParamVal[iCnt]).Value, "%d", xLineSession.unLocalPort);
              sprintf((pxParamVal[iCnt]).Value, "%d", 0);

            break; 
          default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                iTmpCnt = iCnt;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
            goto cleanup;
        }
    }

cleanup:

    if (iMemErrorFlag)
    {
        (pxParamVal[iCnt]).iFaultCode = ERR_OUT_OF_MEMORY;
        iRet = ERR_OUT_OF_MEMORY;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Allocation Failure\n",
                     __FILE__, __func__, __LINE__, iRet);
    }

    if (iRet != IFX_CWMP_SUCCESS)
    {

        /* Free the allocation for value, if any. Also set the fault code. */
        for (iCnt = 0; iCnt < iElements; iCnt++)
        {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
            if (iTmpCnt != iCnt) 
            {
                (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
            }
        }
    }

    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : Modify
**
**   Description      : This function modifies the values of parameters in 
**                      LineSession object. It calls respective VMAPI  
**                      for the same. It performs modification only if parameter 
**                      has Write permission. In certain cases it also performs 
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet         = IFX_CWMP_SUCCESS;
    int32   iRtn         = IFX_SUCCESS;
    int32   iCnt         = 0;
    int32   iParamOffset;
    int32   iOID;
    x_IFX_VMAPI_LineSession xLineSession;
    uint32 uiPCpeId;

    /* NOTE: For all parameters fault code is set to success by default. If error in
       validating first parameter, fault code is set to the error type and other
       parameters are not validated. */

    /* Set the fault code to Success for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
    }

    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);

    memset(&xLineSession, 0, sizeof(x_IFX_VMAPI_LineSession));

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_L_S:

            /* Get the Parent CPE Id */
            IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT &uiPCpeId);
            xLineSession.iid.pcpeId.Id = uiPCpeId;

            /* Get all the Voice Line Session parameters using VMAPI */
            //iRtn = ifx_get_LineVoiceSession(&xLineSession, IFX_F_DEFAULT);

            /* Check for error */
            if (iRtn != IFX_CWMP_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to get values of all "
                            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto cleanup;
            }

            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_S_VS_VP_L_S_SESSIONSTARTTIME:
            case OID_IGD_S_VS_VP_L_S_SESSIONDURATION:
            case OID_IGD_S_VS_VP_L_S_FARENDIPADDRESS:
            case OID_IGD_S_VS_VP_L_S_FARENDUDPPORT:
            case OID_IGD_S_VS_VP_L_S_LOCALUDPPORT:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_PARAM_NOT_SUPPORTED;
                iRet = ERR_CWMP_PARAM_NOT_SUPPORTED;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Parameter Not Supported\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;  
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_L_S:

            /* Fill the iid structure in LINE_SESSION */
            xLineSession.iid.config_owner = IFX_TR69;

            /* Set all the VOICE_LINE_SESSION  parameters using VMAPI */
            //iRtn = ifx_set_LineVoiceSession(IFX_OP_MOD, &xLineSession, IFX_F_DEFAULT);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to set values of all "
                            "parameters\n", __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
            }

            break;
        default:
            /* Will never come here since already checked above */
            break;
    }

cleanup:
    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : Validate
**
**   Description      : This function validates the values of parameters in
**                      DeviceInfo object.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      validated.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When validation of all parameters is
**                      successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in validating at least one parameter.
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32 iI;
    int32 iRet = IFX_CWMP_FAILURE;
    for(iI = 0; iI < iElements; iI++) {
        iRet = ERR_CWMP_INVAL_ARGS;
        pxParamVal[iI].iFaultCode = ERR_NON_WRITABLE;
    }
    return iRet;

}
/* 
** =============================================================================
**   Function Name    : GetModifyDep
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
GetModifyDep(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    return (IFX_CWMP_SUCCESS);
}

/* 
** =============================================================================
**   Function Name    : IFX_LineSession_AddDel
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_LineSession_AddDel(IN int32 iCaller, IN ParamVal *pxParamVal, 
               IN int32 iNumElem, IN int32 operation)
{
    return IFIN_CWMP_SUCCESS;

    int32   iRet = IFIN_CWMP_SUCCESS;
    int32   iCnt = 0;
    char sOidString[IFX_MAX_TR69_ID_LEN];
    int32   iParamOffset;
    IFX_CpeId *pxCpeIdArray = NULL;
    unsigned int uiNumCpeId;
    unsigned int uiPCpeId;
    //x_IFX_VMAPI_LineEvents xLineEvents;
    x_IFX_VMAPI_LineSession xLineSession;
    
    memset(sOidString,0x00,IFX_MAX_TR69_ID_LEN);
    memset(&xLineSession,0,sizeof(xLineSession));

    /* if neither delete nor add operation */ 
    if((operation != OP_SETVAL_ADD)&&(operation != OP_SETVAL_DELETE)){ 
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] Invalid operation\n",
                   __func__, __LINE__);
        return ERR_CWMP_INTERNAL;
    }

    /* Get the Parent CPE Id */
    IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT &uiPCpeId);
    xLineSession.iid.pcpeId.Id = uiPCpeId;
   
    /* if delete operation */
    if(operation == OP_SETVAL_DELETE) { 
        // get cpeid, pass to delete function
        // here the input iaOID will be igd.s.vs.1.vp.1.l.2.

        xLineSession.ucLineId = IFX_GetLineId(pxParamVal->iaOID); 

        /*ignore the last value as it will be a parameter and we need 
               only till the last instance*/
        iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );

        //IFX_ConvertObjOidDottedForm(pxParamVal->iaOID,sOidString);
        //printf("========= OID is %s %s==============\n",sOidString, pxParamVal->Name);
        iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId, OUT &pxCpeIdArray);
        if(iRet != IFX_CWMP_SUCCESS){
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                      "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                      __func__, __LINE__);

            return ERR_CWMP_INTERNAL;
        }

        xLineSession.iid.cpeId.Id = pxCpeIdArray->uiId;

        memset(xLineSession.iid.tr69Id,0x00,MAX_TR69_ID_LEN);

        if(strlen(pxCpeIdArray->sSectionTag) < MAX_TAG_LEN) {
            strncpy(xLineSession.iid.cpeId.secName,pxCpeIdArray->sSectionTag, MAX_TAG_LEN-1);
            IFX_CWMP_FREE(pxCpeIdArray);
        }
        else {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [Error] strcpy : mismatch in size in buffer copy\n",
                        __func__, __LINE__);
            IFX_CWMP_FREE(pxCpeIdArray);
            return ERR_CWMP_INTERNAL;
        }

        /* Fill the iid structure in LINE_EVENT */
        xLineSession.iid.config_owner = IFX_TR69;

        strcpy(xLineSession.iid.tr69Id,sOidString);
        //printf("========= OID is %s==============\n",sOidString);

        /* call the respective VMAPI */
        iRet = ifx_set_LineVoiceSession( IFX_OP_DEL, &xLineSession, IFX_F_DEFAULT); 
        if(iRet != IFX_VMAPI_SUCCESS){
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [Error] ifx_set_LineEvents failed\n",
                        __func__, __LINE__);
            return ERR_CWMP_INTERNAL;
        }

        return iRet;

    }// end of delete operation

    if(operation == OP_SETVAL_ADD) { // if ADD
        // ADD operation
        // here the input iaOID will be igd.s.vs.1.vp.1.l.2.
  
        /*ignore the last value as it will be a parameter and we need 
                only till the last instance*/
        iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID,sOidString);
        strcpy(xLineSession.iid.tr69Id,sOidString);

        /* Get the offset of the parameter */
        iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);

        // fill the given parameters of this structure with the new values provided
        for( iCnt = 0; iCnt < iNumElem; iCnt++) {

            /* Process based on the requested parameter */
            switch (pxParamVal[iCnt].iaOID[iParamOffset])
            {
                case OID_IGD_S_VS_VP_L_S_SESSIONSTARTTIME:
                case OID_IGD_S_VS_VP_L_S_SESSIONDURATION:
                case OID_IGD_S_VS_VP_L_S_FARENDIPADDRESS:
                case OID_IGD_S_VS_VP_L_S_FARENDUDPPORT:
                case OID_IGD_S_VS_VP_L_S_LOCALUDPPORT:
                    break;  
               default:
                   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                               "[%s:%d] [Error] Unknown requested parameter\n",
                                __func__, __LINE__);
                   // parameter not found
                   pxParamVal[iCnt].iFaultCode = ERR_INVAL_PARAMETER_NAME;
                   goto cleanup;
           }
      } 


      /* Fill the iid structure of LINE_EVENTS */
      xLineSession.iid.config_owner = IFX_TR69;
    
      // call the VMAPI to modify
      iRet = ifx_set_LineVoiceSession( IFX_OP_ADD, &xLineSession, IFX_F_DEFAULT); 
      if(iRet != IFX_CWMP_SUCCESS) {
          IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] ifx_set_LineSession adding failed\n", 
                     __func__, __LINE__);
          iRet = ERR_CWMP_INTERNAL;
          goto cleanup;
      }
      return iRet;
    }

cleanup:
    /* Perform Cleanup of unnecessary VoiceLine members */
    return (iRet);
}





/* 
** =============================================================================
**   Function Name    : GetNotify
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
GetNotify(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
                 IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : SetAttrInfo
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32 iRet,i;
    iRet = IFX_SetAttributesInfo(pxOI, pxParamVal, iElements);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    for(i=0; i < iElements; i++)
        IFX_CWMP_FREE(pxParamVal->Value);

    return IFX_CWMP_SUCCESS;

  errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed!\n", __func__, __LINE__);
    return iRet;
}
/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : IFX_LineSession_Init
**
**   Description      : This function is called by the controller. It registers
**                      the function responsible for handling LineSession object
**                      with data structure. It also performs initializations
**                      specific to LineSession object.
**
**   Parameters       : No Parameters. 
**
**   Return Value     : IFX_CWMP_SUCCESS - When LineSession object is initialized
**                      successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in initializing LineSession object.
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_LineSession_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the VoiceLine module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_LINESESSION_OBJ, IFX_LineSession);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_LINESESSION_OBJ);
        goto cleanup;
    }

cleanup:
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_LineSession
**
**   Description      : This function is called by the controller. It handles
**                      the LineSession object and performs  based on requested
**                      operations/suboperations by invoking internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_LineSession(IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
             OUT void **ppRet, OUT int32 *piNumRetElem)
{
    int32       iRet           = IFX_CWMP_SUCCESS;
    ParamVal    *pxParamVal    = (ParamVal *)pParamList;

    /* Process based on type of Operation */
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:

                    /* Get values of all the requested parameters */
                    iRet = GetVal(pxOI->iCaller, pxParamVal,
                                               iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_GETVAL_NOTIFICATION:

                    /* Set attribute values for all the requested parameters */
                    iRet = GetNotify(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_SETVAL:
        {
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:

                    /* Validate values of all the requested parameters */
                    iRet = Validate(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:

                   /* Check modify dependency of all requested parameters */
                    iRet = GetModifyDep(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_MODIFY:

                    /* Set values of all the requested parameters */
                    iRet = Modify(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ATTRINFO:

                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_ADD:

                    iRet = IFX_LineSession_AddDel(pxOI->iCaller,pxParamVal, 
                              iNumElem, OP_SETVAL_ADD); // 1 = add 0=del

                    /* Check for error */
                    if (iRet != IFIN_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }


                   break;

                case OP_SETVAL_CHK_DEL_DEP:
                     *ppRet = (ParamVal *)IFX_CWMP_MALLOC(sizeof(ParamVal));
                    //	ppRet = IFX_CWMP_MALLOC(sizeof(ParamVal));
			if(ppRet!=NULL){
                    		memcpy(*ppRet, pParamList, sizeof(ParamVal));
                    		*piNumRetElem = 1;
			}
			else{
				iRet=IFX_CWMP_FAILURE;
				goto cleanup;
			}
                   break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    return IFX_CWMP_SUCCESS;

                   break;
                case OP_SETVAL_DELETE:
                    iRet = IFX_LineSession_AddDel(pxOI->iCaller,pxParamVal, 
                              iNumElem, OP_SETVAL_DELETE); // 1 = add 0=del

                    /* Check for error */
                    if (iRet != IFIN_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }


                   break;
                case OP_SETVAL_FREE:
                    return IFX_CWMP_SUCCESS;
                break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD: 
                case OP_UPDATE_CHILDINFO_DEL: 
                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
        {
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid Operation\n",
                         __func__, __LINE__, iRet);
            goto cleanup;
       }
    }
 
   return IFX_CWMP_SUCCESS;
cleanup:
    return (iRet);
}
