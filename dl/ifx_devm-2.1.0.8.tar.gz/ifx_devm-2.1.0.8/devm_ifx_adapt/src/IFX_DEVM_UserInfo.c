/*
 * ** =============================================================================
 * ** FILE NAME   : IFX_DEVM_UserInfo.c
 * ** PROJECT     : TR157
 * ** MODULES     : InternetGatewayDevice.UserInterface.
                    InternetGatewayDevice.UserInterface.RemoteAccess.
                    InternetGatewayDevice.User.{i}.
 * ** DATE        :
 * ** AUTHOR      : TR157 team
 * ** DESCRIPTION : AddObject / DeleteObject cannot be performed on this object.
 * **
 * ** REFERENCES  :
 * ** Any use of this software is subject to the conclusion of a respective
 * ** License agreement. Without such a License agreement no rights to the
 * ** software are granted
 * **
 * ** HISTORY     :
 * ** $Date       $Author        $Comment
 * **             TR157 team      Creation
 * ** =============================================================================
 * */


#include "IFX_DEVM_Global.h"

#include "IFX_DEVM_AdaptCommon.h"


#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_StackUtil.h"
#include <resolv.h>

extern char8 vcOsModId;

#define USER_OBJ                      FORMNAME("User.1.")
#define USERINTERFACE_OBJ             FORMNAME("UserInterface.")
#define REMOTEACCESS_OBJ              FORMNAME("UserInterface.RemoteAccess.")




/*
** =============================================================================
**   Function Name    : GetParamOffset
**   Description      :
**
**   Parameters       :
**
**   Return Value     :
**   Notes            :
**
** ============================================================================
*/

STATIC int32 GetParamOffset(IN int32 *paiOID)

{
    int32 iCnt;

    for (iCnt = 0; paiOID[iCnt] != 0; iCnt++);

    return (iCnt - 1);
}

STATIC int32 GetNotify(IN OperInfo * pxOI, INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iCnt = 0;

    for(iCnt = 0; iCnt < iElements; iCnt++) {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
        (pxParamVal[iCnt]).Value = NULL;
    }

    return (iRet);
}

STATIC int32 SetAttrInfo(IN OperInfo * pxOI, INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iCnt;

    /* Set the fault code to Success */
    for(iCnt = 0; iCnt < iElements; iCnt++) {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
    }

    /* Get the offset of the parameter */
    IFX_GetParamIdPos(pxParamVal->iaOID);

    for(iCnt = 0; iCnt < iElements; iCnt++) {
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Update Attribute Information */
    iRet = IFX_SetAttributesInfo(NULL, pxParamVal, iElements);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Updating Param Attribute Info failed\n",
                    __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    return (iRet);
}


/*******************************************************************************
* Function: IFX_RemoteAccessSetValue
* Desc:
*
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_RemoteAccessSetValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                             IN int32 iElements)
{
    uint32  iCnt = 0;
    int32 iRet = IFX_SUCCESS , iParamOffset = 0;
    remote_access_t xRemoteAccess;

    memset(&xRemoteAccess, 0x00, sizeof(xRemoteAccess));

    if((mapi_remote_access_details_get(&xRemoteAccess,IFX_F_DEFAULT)) != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d mapi_remote_access_details_get() failed.\n", _FUNCL_);
        iRet = IFX_FAILURE;
        goto end;
    }

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxPV->iaOID);
    if (iParamOffset < 0)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s:%d GetParamOffset returned < 0.\n", _FUNCL_);
        iRet = ERR_CWMP_INTERNAL;
        goto end;
    }

    for( iCnt=0; iCnt<iElements; iCnt++)
    {

	switch(pxPV[iCnt].iaOID[iParamOffset])
        {
                case OID_IGD_UI_RA_ENABLE:
			xRemoteAccess.f_enable = atoi(pxPV[iCnt].Value );
                        break;

                case OID_IGD_UI_RA_PORT:
			xRemoteAccess.port = atoi(pxPV[iCnt].Value);
                        break;

                case OID_IGD_UI_RA_SUPPORTEDPROTOCOLS:
                        sprintf(pxPV[iCnt].Value , "HTTPS");
                        break;

                case OID_IGD_UI_RA_PROTOCOL:
			strcpy(xRemoteAccess.proto , pxPV[iCnt].Value);
                        break;

		default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,pxOI->iSubOper);
        }

    }

    iRet = mapi_remote_access_details_set(&xRemoteAccess, IFX_F_MODIFY);
    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d mapi_remote_access_details_set() failed.\n", _FUNCL_);
        iRet = IFX_FAILURE;
        goto end;
    }

end:

    return iRet;
}

/*******************************************************************************
 * * Function: IFX_RemoteAccessGetValue
 * * Desc: 
 * *              
 * * Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
static int32
IFX_RemoteAccessGetValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                             IN int32 iElements)
{
    uint32  iCnt = 0;
    int32 iRet = IFX_SUCCESS , iParamOffset = 0;
    remote_access_t xRemoteAccess;

    memset(&xRemoteAccess, 0x00, sizeof(xRemoteAccess));
	
    if((mapi_remote_access_details_get(&xRemoteAccess,IFX_F_DEFAULT)) != IFX_SUCCESS) 
    {
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d mapi_remote_access_details_get() failed.\n", _FUNCL_);
	iRet = IFX_FAILURE;
	goto end;
    }

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxPV->iaOID);
    if (iParamOffset < 0)
    {
    	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s:%d GetParamOffset returned < 0.\n", _FUNCL_);
        iRet = ERR_CWMP_INTERNAL;
        goto end;
    }
	

    for( iCnt=0; iCnt<iElements; iCnt++)
    {
        // Malloc and assign the pointer to the Value attr of struct
        (pxPV[iCnt]).Value = IFX_CWMP_MALLOC(16);
        if(pxPV[iCnt].Value == NULL)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d MALLOC FAILED.\n", _FUNCL_);
            iRet = ERR_OUT_OF_MEMORY;
            goto end;
        }
        switch(pxPV[iCnt].iaOID[iParamOffset])
        {
		case OID_IGD_UI_RA_ENABLE:
			sprintf(pxPV[iCnt].Value , "%d" , xRemoteAccess.f_enable);
			break;

		case OID_IGD_UI_RA_PORT:
			sprintf(pxPV[iCnt].Value , "%u" , xRemoteAccess.port);
			break;

		case OID_IGD_UI_RA_SUPPORTEDPROTOCOLS:
			sprintf(pxPV[iCnt].Value , "HTTP,HTTPS");
			break;

		case OID_IGD_UI_RA_PROTOCOL:
			sprintf(pxPV[iCnt].Value , "%s", xRemoteAccess.proto);
			break;

		default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,pxOI->iSubOper);
	}
    }

end:
	return iRet;

}

/*******************************************************************************
 * * Function: IFX_UserSetValue
 * * Desc:
 * *
 * * Parameters: INOUT ParamVal * pxPV, IN int32 iElements
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
static int32
IFX_UserSetValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                             IN int32 iElements)
{
    uint32 iCpeid ;
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    user_obj_t xUserObj;
    int32 iParamOffset = 0;
    memset(&xUserObj, '\0', sizeof(xUserObj));

    iRet = IFX_GetCpeId(pxPV->iaOID, &iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d IFX_GetCpeId failed.\n", _FUNCL_);
        goto end;
    }

    xUserObj.iid.cpeId.Id = iCpeid;

    iRet = mapi_user_obj_details_get(&xUserObj, IFX_F_DEFAULT);
    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] mapi_user_obj_details_get() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto end;
    }
    
    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxPV->iaOID);
    if (iParamOffset < 0)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s:%d GetParamOffset returned < 0.\n", _FUNCL_);
        iRet = ERR_CWMP_INTERNAL;
        goto end;
    }

    for(iI = 0; iI < iElements; iI++)
    {
        switch (pxPV[iI].iaOID[iParamOffset])
        {
            case OID_IGD_U_ENABLE:
		xUserObj.f_enable = atoi(pxPV[iI].Value );
                break;

            case OID_IGD_U_REMOTEACCESSCAPABLE:
		xUserObj.webAccess = (atoi(pxPV[iI].Value) > 0) ? 3 : 1; /* 3 for Local and Remote access. 1 for Local access only */
                break;

            case OID_IGD_U_USERNAME:
		strncpy(xUserObj.username , pxPV[iI].Value , MAX_NAME_SIZE - 1);
                break;

            case OID_IGD_U_PASSWORD:
		strncpy(xUserObj.password , pxPV[iI].Value , MAX_NAME_SIZE - 1);
                break;

            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d] ParamOID [%d] Error! Default case\n", _FUNCL_,
                                                                                        pxPV[iI].iaOID[iParamOffset]);
                break;
        }
    }
  
    iRet = mapi_user_obj_details_set(IFX_OP_MOD, &xUserObj, (IFX_F_MODIFY | IFX_F_DONT_WRITE_TO_FLASH));
    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] mapi_user_obj_details_set() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto end;
    }

end:
    return iRet ;
}


/*******************************************************************************
 * * Function: IFX_UserGetValue
 * * Desc: 
 * *              
 * * Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
static int32
IFX_UserGetValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                             IN int32 iElements)
{
    uint32 iCpeid = 0;
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    user_obj_t xUserObj;
    int32 iParamOffset = 0;
    memset(&xUserObj, '\0', sizeof(xUserObj));

    iRet = IFX_GetCpeId(pxPV->iaOID, &iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    {
	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d IFX_GetCpeId failed.\n", _FUNCL_);
        goto end;
    }

    xUserObj.iid.cpeId.Id = iCpeid;
    iRet = mapi_user_obj_details_get(&xUserObj, IFX_F_DEFAULT);
    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] mapi_user_obj_details_get() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto end;
    }


    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxPV->iaOID);
    if (iParamOffset < 0)
    {
    	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s:%d GetParamOffset returned < 0.\n", _FUNCL_);
        iRet = ERR_CWMP_INTERNAL;
        goto end;
    }

    for(iI = 0; iI < iElements; iI++)
    {
        pxPV[iI].Value = IFX_CWMP_MALLOC(128);
        if(pxPV[iI].Value == NULL)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d Malloc failed\n", _FUNCL_);
            iRet = ERR_OUT_OF_MEMORY;
            goto end;
        }
        switch (pxPV[iI].iaOID[iParamOffset])
        {
            case OID_IGD_U_ENABLE:
                sprintf(pxPV[iI].Value , "%d" , xUserObj.f_enable);
                break;

            case OID_IGD_U_REMOTEACCESSCAPABLE:
                sprintf(pxPV[iI].Value , "%d" , (xUserObj.webAccess > 1) ? 1 : 0); /* webAccess = 2/3 means remote access enabled */
                break;

            case OID_IGD_U_USERNAME:
                sprintf(pxPV[iI].Value , "%s" , xUserObj.username);
                break;

            case OID_IGD_U_PASSWORD:
                sprintf(pxPV[iI].Value , "%s" , "");
                break;

            case OID_IGD_U_LANGUAGE:
                sprintf(pxPV[iI].Value , "%s" , "");
                break;

            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%d] ParamOID [%d] Error! Default case\n", _FUNCL_,
                			            					pxPV[iI].iaOID[iParamOffset]);
                break;
        }
    }

end:
    return iRet;
}


 /*******************************************************************************
 * * Function: IFX_RemoteAccess
 * * Desc: 
 * *              
 * * Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
 * *             OUT void **ppRet, OUT int32 * piNumRetElem
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
int32 IFX_RemoteAccess(IN OperInfo * pxOI,
                            INOUT void *pParamStruct,
                            IN int32 iElements, OUT void **ppRet,
                            OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;

    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                    iRet = IFX_RemoteAccessGetValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d IFX_RemoteAccessGetValue() failed.\n", _FUNCL_);
                        goto errorHandler;
                    }
                    break;

                case OP_GETVAL_NOTIFICATION:
                {
                    iRet = GetNotify(pxOI, xpParamVal, iElements);
                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS)
                    {
                        goto errorHandler;
                    }
                    break;
                }

                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! Default case.\n", _FUNCL_, pxOI->iSubOper);
                    break;
            }
            break;
        }
	case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                case OP_SETVAL_CHK_MODIFY_DEP:
                case OP_SETVAL_ACTIVATE:
                     break;

                case OP_SETVAL_MODIFY:
                    iRet = IFX_RemoteAccessSetValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d IFX_RemoteAccessSetValue() failed.\n", _FUNCL_);
                        goto errorHandler;
                    }
                    break;

                case OP_SETVAL_ATTRINFO:
                    iRet = SetAttrInfo(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d SetAttrInfo() failed.\n", _FUNCL_);
                        goto errorHandler;
                    }
                    break;
                 
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
		case OP_SETVAL_DELETE:
		case OP_SETVAL_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    break;

                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"%s:%d [%d] Error! Default case.\n", _FUNCL_, pxOI->iSubOper);
                    break;
            }
            break;
        }
	case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                case OP_UPDATE_CHILDINFO_DEL:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break;
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Error! Default case.\n", _FUNCL_,pxOI->iOper);
                        
            break;
        }
    }
errorHandler:
    if (iRet != IFX_CWMP_SUCCESS)
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d failed.\n", _FUNCL_);

    return iRet;
}


 /*******************************************************************************
 * * Function: IFX_UserInterface
 * * Desc: 
 * *              
 * * Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
 * *             OUT void **ppRet, OUT int32 * piNumRetElem
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
int32 IFX_UserInterface(IN OperInfo * pxOI,
                            INOUT void *pParamStruct,
                            IN int32 iElements, OUT void **ppRet,
                            OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:
                    break;

                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                                pxOI->iSubOper);
                    break;
            }
            break;
        }
	case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                case OP_SETVAL_ADD:
                case OP_SETVAL_CHK_MODIFY_DEP:
                case OP_SETVAL_MODIFY:
                case OP_SETVAL_ACTIVATE:
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
		case OP_SETVAL_DELETE:
		case OP_SETVAL_ATTRINFO:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,
                                pxOI->iSubOper);
                    break;
            }
            break;
        }
	case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                case OP_UPDATE_CHILDINFO_DEL:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break;
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d [%d] Error! Default case.\n", _FUNCL_,pxOI->iOper);
                        
            break;
        }
    }
errorHandler:
    if (iRet != IFX_CWMP_SUCCESS)
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d failed.\n", _FUNCL_);

    return iRet;
}


 /*******************************************************************************
 * * Function: IFX_User
 * * Desc: 
 * *              
 * * Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
 * *             OUT void **ppRet, OUT int32 * piNumRetElem
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
int32 IFX_User(IN OperInfo * pxOI,
                            INOUT void *pParamStruct,
                            IN int32 iElements, OUT void **ppRet,
                            OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                    iRet = IFX_UserGetValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d IFX_UserGetValue failed.\n", _FUNCL_);
                        goto errorHandler;
                    }
                    break;

                case OP_GETVAL_NOTIFICATION:
                {
                    iRet = GetNotify(pxOI, xpParamVal, iElements);
                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS)
                    {
                        goto errorHandler;
                    }
                    break;
                }


                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,pxOI->iOper);
                    break;
            }
            break;
        }
	case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                case OP_SETVAL_CHK_MODIFY_DEP:
                case OP_SETVAL_ACTIVATE:
                     break;

                case OP_SETVAL_MODIFY:
                    iRet = IFX_UserSetValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d IFX_RemoteAccessSetValue() failed.\n", _FUNCL_);
                        goto errorHandler;
                    }
                    break;

                case OP_SETVAL_ATTRINFO:
                    iRet = SetAttrInfo(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                    {
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d SetAttrInfo() failed.\n", _FUNCL_);
                        goto errorHandler;
                    }
                    break;
                 

                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
		case OP_SETVAL_DELETE:
		    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    break;

                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", _FUNCL_,pxOI->iSubOper);
                                
                    break;
            }
            break;
        }
	case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                case OP_UPDATE_CHILDINFO_DEL:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break;
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d [%d] Error! Default case.\n", _FUNCL_, pxOI->iOper);
                        
            break;
        }
    }
errorHandler:
    if (iRet != IFX_CWMP_SUCCESS)
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d failed.\n", _FUNCL_);

    return iRet;
}


/*******************************************************************************
 * * Function: IFX_UserInfoInit                                  
 * * Desc: Will register itself with DS.
 * * Parameters:  
 * * Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
 * *******************************************************************************/
int32 IFX_UserInfoInit()
{
    int32 iRet = IFX_CWMP_SUCCESS;
    
    iRet = ifx_ds_register_function(USER_OBJ, IFX_User);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Unable to Register %s with Object Model\n",
                    _FUNCL_, iRet, USER_OBJ);
	goto errorHandler;
    }   

    iRet = ifx_ds_register_function(USERINTERFACE_OBJ, IFX_UserInterface);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Unable to Register %s with Object Model\n",
                    _FUNCL_, iRet, USERINTERFACE_OBJ);
	goto errorHandler;
    }   

    iRet = ifx_ds_register_function(REMOTEACCESS_OBJ, IFX_RemoteAccess);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Unable to Register %s with Object Model\n",
                    _FUNCL_, iRet, REMOTEACCESS_OBJ);
    }

errorHandler:
    return iRet;
}
