/* 
** =============================================================================
**   FILE NAME        : IFX_QMPolicer.c
**   PROJECT          : TR69
**   MODULES          : QueueManagement.Policer
**   DATE             : 07-02-2009
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This is the Policer Module. It is required by the 
**                      controller module of TR69 stack to GET/SET/ADD/DELETE
**                      Policer specific information.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author                         $Comment
**   15-01-2008       TR69 team                       Initial Version
**
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_QMPolicer.h"
  // Required for STATIC
 
#include "IFX_DEVM_OID.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
 
#include "IFX_DEVM_DS.h"

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFX_QUEUE_MGMT_POLICER_OBJ    FORMNAME("QueueManagement.Policer")
/* TBD: Temporary Placeholders, since we do not get this from Platform include
   header files */

/* IPQOS Tags */
#define TAG_IPQOS_CAPABILITY                      "qos_capability"
#define TAG_IPQOS_QM                              "qos_queuemgmt"
#define TAG_IPQOS_CLASSIFY                        "qos_class"
#define TAG_IPQOS_QUEUE                            "qos_queue"
#define TAG_IPQOS_POLICER                            "qos_policer"

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

STATIC int32
GetParamOffset(IN int32 *paiOID);
STATIC int32
GetVal(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
       IN int32 iElements);
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
AddObj(IN OperInfo *pxOI,INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
SetDelete(IN OperInfo *pxOI,INOUT ParamVal *pxParamVal,
          IN int32 iElements, OUT void **ppxParamStructRet,
          OUT int32 * piNumRetElem);

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : GetParamOffset
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

STATIC int32
GetParamOffset(IN int32 *paiOID)
{
    int32 iCnt;

    for (iCnt = 0; paiOID[iCnt] != 0; iCnt++);

    return (iCnt - 1);
}

/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetVal(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
       IN int32 iElements)
{
    int32   iRet  = IFX_CWMP_SUCCESS;
    int32   iRtn  = IFX_SUCCESS;
    int32   iCnt  = 0;
    IFX_MAPI_QoS_Policer xQMP;
    int32   iParamOffset;
    uint32 iCpeid = 0;

    // Get Cpeid from object ID
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    	goto cleanup;

    memset(&xQMP, 0, sizeof(IFX_MAPI_QoS_Policer));

    /* Fill the cpeid in the structure to get the required instance */
    xQMP.iid.cpeId.Id = iCpeid;

    /* Get all the IFX_MAPI_QoS_Policer parameters using Protocol API */
    iRtn = ifx_mapi_get_qos_policer(&xQMP, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_oplicer failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        /* TBD: Currently keeping size as 65 bytes, since max param size is string(64) */
        (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(65);

        /* Check for error */
        if (!((pxParamVal[iCnt]).Value))
        {
            iRet = ERR_OUT_OF_MEMORY;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Allocation Failure\n",
                         __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_QM_P_POLICERENABLE:
                /* Copy the value to allocated area */
                sprintf(pxParamVal[iCnt].Value, "%d", xQMP.enable);
                break;
            case OID_IGD_QM_P_POLICERSTATUS:
                /* Copy the value to allocated area */
                if (xQMP.status == IPQOS_STATUS_DISABLED)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Disabled");
                }
                else if (xQMP.status == IPQOS_STATUS_ENABLED)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Enabled");
                }
                else
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Error");
                }
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_QM_P_COMMITTEDRATE:
                sprintf(pxParamVal[iCnt].Value, "%u", xQMP.cr);
                break;
            case OID_IGD_QM_P_COMMITTEDBURSTSIZE:
                sprintf(pxParamVal[iCnt].Value, "%u", xQMP.cbs);
                break;
            case OID_IGD_QM_P_EXCESSBURSTSIZE:
                sprintf(pxParamVal[iCnt].Value, "%u", xQMP.ebs);
                break;
            case OID_IGD_QM_P_PEAKRATE:
                sprintf(pxParamVal[iCnt].Value, "%u", xQMP.pr);
                break;
            case OID_IGD_QM_P_PEAKBURSTSIZE:
                sprintf(pxParamVal[iCnt].Value, "%u", xQMP.pbs);
                break;
            case OID_IGD_QM_P_METERTYPE:
                /* Copy the value to allocated area */
                if (xQMP.mtrType == IFX_MAPI_QoS_Meter_STB)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "SimpleTokenBucket");
                }
                else if (xQMP.mtrType == IFX_MAPI_QoS_Meter_SRTCM)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "SingleRateThreeColor");
                }
                else
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "TwoRateThreeColor");
                }
                break;
            case OID_IGD_QM_P_POSSIBLEMETERTYPES:
               //TBD: Get it from the capability section. Needs to be handled. Currently hardcoding it.
                sprintf(pxParamVal[iCnt].Value, "%s", "SimpleTokenBucket,SingleRateThreeColor,TwoRateThreeColor");
                break;
            case OID_IGD_QM_P_CONFORMINGACTION:
                /* Copy the value to allocated area */
                if (xQMP.cfmAction == IFX_MAPI_QoS_Policer_NULL)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Null");
                }
                else if (xQMP.cfmAction == IFX_MAPI_QoS_Policer_Drop)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Drop");
                }
                else if (xQMP.cfmAction == IFX_MAPI_QoS_Policer_DSCP_Mark)
                {
                    sprintf(pxParamVal[iCnt].Value, "%u", xQMP.cfmDscpMark);
                }
                else if (xQMP.cfmAction == IFX_MAPI_QoS_Policer_P_Bits_Mark)
                {
                    sprintf(pxParamVal[iCnt].Value, ":%u", xQMP.cfmPbitsMark);
                }
                else
                {
                    sprintf(pxParamVal[iCnt].Value, "%u:%u", xQMP.cfmDscpMark, xQMP.cfmPbitsMark);
                }
                break;
            case OID_IGD_QM_P_PARTIALCONFORMINGACTION:
                /* Copy the value to allocated area */
                if (xQMP.partCfmAction == IFX_MAPI_QoS_Policer_NULL)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Null");
                }
                else if (xQMP.partCfmAction == IFX_MAPI_QoS_Policer_Drop)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Drop");
                }
                else if (xQMP.partCfmAction == IFX_MAPI_QoS_Policer_DSCP_Mark)
                {
                    sprintf(pxParamVal[iCnt].Value, "%u", xQMP.partCfmDscpMark);
                }
                else if (xQMP.partCfmAction == IFX_MAPI_QoS_Policer_P_Bits_Mark)
                {
                    sprintf(pxParamVal[iCnt].Value, ":%u", xQMP.partCfmPbitsMark);
                }
                else
                {
                    sprintf(pxParamVal[iCnt].Value, "%u:%u", xQMP.partCfmDscpMark, xQMP.partCfmPbitsMark);
                }
                break;
            case OID_IGD_QM_P_NONCONFORMINGACTION:
                /* Copy the value to allocated area */
                if (xQMP.nonCfmAction == IFX_MAPI_QoS_Policer_NULL)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Null");
                }
                else if (xQMP.nonCfmAction == IFX_MAPI_QoS_Policer_Drop)
                {
                    sprintf(pxParamVal[iCnt].Value, "%s", "Drop");
                }
                else if (xQMP.nonCfmAction == IFX_MAPI_QoS_Policer_DSCP_Mark)
                {
                    sprintf(pxParamVal[iCnt].Value, "%u", xQMP.nonCfmDscpMark);
                }
                else if (xQMP.nonCfmAction == IFX_MAPI_QoS_Policer_P_Bits_Mark)
                {
                    sprintf(pxParamVal[iCnt].Value, ":%u", xQMP.nonCfmPbitsMark);
                }
                else
                {
                    sprintf(pxParamVal[iCnt].Value, "%u:%u", xQMP.nonCfmDscpMark, xQMP.nonCfmPbitsMark);
                }

                break;
            case OID_IGD_QM_P_COUNTEDPACKETS:
                //TBD: Need to get it from system
                sprintf(pxParamVal[iCnt].Value, "%u", 0);
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_QM_P_COUNTEDBYTES:
                //TBD: Need to get it from system
                sprintf(pxParamVal[iCnt].Value, "%u", 0);
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_VALUE_BASED);
                break;
            default:
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
                goto cleanup;
        }
    }

cleanup:
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : Modify
**
**   Description      : This function modifies the values of parameters in 
**                      Policer object. It calls respective Management
**                      API for same. It performs modification only if parameter 
**                      has Write permission. In certain cases it also performs 
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32       iRet       = IFX_CWMP_SUCCESS;
    int32       iRtn       = IFX_SUCCESS;
    uint32      iCpeid     = 0;
    int32       iCnt       = 0;
    IFX_MAPI_QoS_Policer xQMP;
    int32       iParamOffset;
    char8       *psTmpVal;
    uint32      uiFlags;
    char8       *pcTmp;

//TBD: What to do about Precedence

    // Get Cpeid from object ID
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&iCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    	goto cleanup;

    memset(&xQMP, 0, sizeof(IFX_MAPI_QoS_Policer));

    /* Fill the cpeid in the structure to get the required instance */
    xQMP.iid.cpeId.Id = iCpeid;

    /* Get all the IFX_MAPI_QoS_Classifier parameters using Protocol API */
    iRtn = ifx_mapi_get_qos_policer(&xQMP, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_policer failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }


    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_QM_P_POLICERENABLE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMP.enable = TRUE;
                }
                else
                {
                    xQMP.enable = FALSE;
                }
                break;
            case OID_IGD_QM_P_COMMITTEDRATE:
                xQMP.cr = atoi(psTmpVal);
                break;
            case OID_IGD_QM_P_COMMITTEDBURSTSIZE:
                xQMP.cbs = atoi(psTmpVal);
                break;
            case OID_IGD_QM_P_EXCESSBURSTSIZE:
                xQMP.ebs = atoi(psTmpVal);
                break;
            case OID_IGD_QM_P_PEAKRATE:
                xQMP.pr = atoi(psTmpVal);
                break;
            case OID_IGD_QM_P_PEAKBURSTSIZE:
                xQMP.pbs = atoi(psTmpVal);
                break;
            case OID_IGD_QM_P_METERTYPE:
                if (!strcmp(psTmpVal, "SimpleTokenBucket"))
                {
                    xQMP.mtrType = IFX_MAPI_QoS_Meter_STB;
                }
                else if (!strcmp(psTmpVal, "SingleRateThreeColor"))
                {
                    xQMP.mtrType = IFX_MAPI_QoS_Meter_SRTCM;
                }
                else
                {
                    xQMP.mtrType = IFX_MAPI_QoS_Meter_TRTCM;
                }
                break;
            case OID_IGD_QM_P_CONFORMINGACTION:
                if (!strcmp(psTmpVal, "Null"))
                {
                    xQMP.cfmAction = IFX_MAPI_QoS_Policer_NULL;
                }
                else if (!strcmp(psTmpVal, "Drop"))
                {
                    xQMP.cfmAction = IFX_MAPI_QoS_Policer_Drop;
                }
                else if ((pcTmp = strstr(psTmpVal, ":")) == NULL)
                {
                    
                    xQMP.cfmAction = IFX_MAPI_QoS_Policer_DSCP_Mark;
                    xQMP.cfmDscpMark = atoi(psTmpVal);
                }
                else if (pcTmp == psTmpVal)
                {
                    xQMP.cfmAction = IFX_MAPI_QoS_Policer_P_Bits_Mark;
                    xQMP.cfmPbitsMark = atoi(psTmpVal+1);
                }
                else
                {
                    xQMP.cfmAction = IFX_MAPI_QoS_Policer_DSCP_P_Bits_Mark;
                    xQMP.cfmDscpMark = atoi(psTmpVal);
                    xQMP.cfmPbitsMark = atoi(pcTmp+1);
                }
                break;
            case OID_IGD_QM_P_PARTIALCONFORMINGACTION:
                if (!strcmp(psTmpVal, "Null"))
                {
                    xQMP.partCfmAction = IFX_MAPI_QoS_Policer_NULL;
                }
                else if (!strcmp(psTmpVal, "Drop"))
                {
                    xQMP.partCfmAction = IFX_MAPI_QoS_Policer_Drop;
                }
                else if ((pcTmp = strstr(psTmpVal, ":")) == NULL)
                {
                    
                    xQMP.partCfmAction = IFX_MAPI_QoS_Policer_DSCP_Mark;
                    xQMP.partCfmDscpMark = atoi(psTmpVal);
                }
                else if (pcTmp == psTmpVal)
                {
                    xQMP.partCfmAction = IFX_MAPI_QoS_Policer_P_Bits_Mark;
                    xQMP.partCfmPbitsMark = atoi(psTmpVal+1);
                }
                else
                {
                    xQMP.partCfmAction = IFX_MAPI_QoS_Policer_DSCP_P_Bits_Mark;
                    xQMP.partCfmDscpMark = atoi(psTmpVal);
                    xQMP.partCfmPbitsMark = atoi(pcTmp+1);
                }
                break;
            case OID_IGD_QM_P_NONCONFORMINGACTION:
                if (!strcmp(psTmpVal, "Null"))
                {
                    xQMP.nonCfmAction = IFX_MAPI_QoS_Policer_NULL;
                }
                else if (!strcmp(psTmpVal, "Drop"))
                {
                    xQMP.nonCfmAction = IFX_MAPI_QoS_Policer_Drop;
                }
                else if ((pcTmp = strstr(psTmpVal, ":")) == NULL)
                {
                    
                    xQMP.nonCfmAction = IFX_MAPI_QoS_Policer_DSCP_Mark;
                    xQMP.nonCfmDscpMark = atoi(psTmpVal);
                }
                else if (pcTmp == psTmpVal)
                {
                    xQMP.nonCfmAction = IFX_MAPI_QoS_Policer_P_Bits_Mark;
                    xQMP.nonCfmPbitsMark = atoi(psTmpVal+1);
                }
                else
                {
                    xQMP.nonCfmAction = IFX_MAPI_QoS_Policer_DSCP_P_Bits_Mark;
                    xQMP.nonCfmDscpMark = atoi(psTmpVal);
                    xQMP.nonCfmPbitsMark = atoi(pcTmp+1);
                }
                break;
            case OID_IGD_QM_P_POLICERSTATUS:
            case OID_IGD_QM_P_POSSIBLEMETERTYPES:
            case OID_IGD_QM_P_COUNTEDPACKETS:
            case OID_IGD_QM_P_COUNTEDBYTES:
                (pxParamVal[iCnt]).iFaultCode = ERR_NON_WRITABLE;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Cannot modify the parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

    /* Fill the iid structure in IFX_MAPI_QoS_Policer*/
    xQMP.iid.config_owner = iCaller;

    //TBD: Needs some logic for combinations of enable<-->disable

    /* Set all the IFX_MAPI_QoS_Queue parameters using Object API */
    uiFlags = IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH;
    if (xQMP.enable == FALSE)
    uiFlags |= IFX_F_DONT_ACTIVATE | IFX_F_DONT_VALIDATE; 
    iRtn = ifx_mapi_set_qos_policer(IFX_OP_MOD, &xQMP, uiFlags);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to set values of all "
                    "parameters\n", __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    return (iRet);

}

/* 
** =============================================================================
**   Function Name    : Validate
**
**   Description      : This function validates the values of parameters in
**                      Policer object.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      validated.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When validation of all parameters is
**                      successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in validating at least one parameter.
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iCnt;
    int32   iParamOffset;
    char8   *psTmpVal;

   /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Iterate and validate the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Return a failure if the value is NULL pointer */
        if (!psTmpVal)
        {
            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
            iRet = ERR_CWMP_INVAL_ARGS;
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_QM_P_POLICERKEY:
            case OID_IGD_QM_P_POSSIBLEMETERTYPES:
            case OID_IGD_QM_P_COUNTEDPACKETS:
            case OID_IGD_QM_P_COUNTEDBYTES:
                /* RO params - Not validating. just returtning success */
                break;
            case OID_IGD_QM_P_POLICERENABLE:
            case OID_IGD_QM_P_COMMITTEDRATE:
            case OID_IGD_QM_P_COMMITTEDBURSTSIZE:
            case OID_IGD_QM_P_EXCESSBURSTSIZE:
            case OID_IGD_QM_P_PEAKRATE:
            case OID_IGD_QM_P_PEAKBURSTSIZE:
            case OID_IGD_QM_P_METERTYPE:
            case OID_IGD_QM_P_CONFORMINGACTION:
            case OID_IGD_QM_P_PARTIALCONFORMINGACTION:
            case OID_IGD_QM_P_NONCONFORMINGACTION:
                /* TBD: Will be done later if required */
                break;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

cleanup:
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Validating requested parameter failed\n",
                    __FILE__, __func__, __LINE__, iRet);
    }
    return (iRet);

}

STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iCnt;
    int32 iParamOffset;
    int32 iValueFlag = 0; /* Mandatory */

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Set the fault code to Success and value to NULL pointer for all parameters
       other than uptime */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Mark that values have been malloced. Currently always doing it, since not possible
       to keep track in a loop, for which params its malloced */
    iValueFlag = 1;

    /* Update Attribute Information */
    iRet = IFX_SetAttributesInfo(NULL, pxParamVal, iElements);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Updating Param Attribute Info failed\n",
                    __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    /* Free the Value that has been allocated */
    if (iValueFlag)
    { 
        for (iCnt = 0; iCnt < iElements; iCnt++)
        {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
        }
    }

    return (iRet);

}

STATIC int32
AddObj(IN OperInfo *pxOI,INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32 iRet=IFX_CWMP_SUCCESS;
    int32       iRtn       = IFX_SUCCESS;
    uint32 iFlags=0;
    uint32 iOper;
    uint32 uiPcpeId=0;
    IFX_MAPI_QoS_Policer xQMP;
    int32 iCnt;
    int32 iParamOffset;
    char8       *psTmpVal;
    char8       *pcTmp;
    IFX_MAPI_QoS_Capability xQoSC;
    uint32 uiInstanceCount = 0;

//TBD: Need to put a check on the number of policers allowed in the system
    /* Get all the IFX_MAPI_QoS_Capability parameters using Protocol API */
    iRtn = ifx_mapi_get_qos_capability(&xQoSC, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_capability failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

   uiInstanceCount = 0;
   ifx_get_sec_instance_count(TAG_IPQOS_POLICER, &uiInstanceCount);
   if (uiInstanceCount >= xQoSC.maxPolicers)
   {
        iRet = ERR_RESOURCE_EXCEEDED;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] Cannot add more Policers\n",
                    __FILE__,  __func__, __LINE__);
        goto cleanup;
   }

    memset(&xQMP, 0, sizeof(IFX_MAPI_QoS_Policer));

    /* Get the offset of the parameter */
    iParamOffset = GetParamOffset(pxParamVal->iaOID);
    if (iParamOffset < 0)
        goto cleanup; //To fix SCA error.

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_QM_P_POLICERENABLE:
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xQMP.enable = TRUE;
                }
                else
                {
                    xQMP.enable = FALSE;
                }
                break;
            case OID_IGD_QM_P_POLICERSTATUS:
                // Nothing to do. No place in structure
                break;
            case OID_IGD_QM_P_COMMITTEDRATE:
                xQMP.cr = atoi(psTmpVal);
                break;
            case OID_IGD_QM_P_COMMITTEDBURSTSIZE:
                xQMP.cbs = atoi(psTmpVal);
                break;
            case OID_IGD_QM_P_EXCESSBURSTSIZE:
                xQMP.ebs = atoi(psTmpVal);
                break;
            case OID_IGD_QM_P_PEAKRATE:
                xQMP.pr = atoi(psTmpVal);
                break;
            case OID_IGD_QM_P_PEAKBURSTSIZE:
                xQMP.pbs = atoi(psTmpVal);
                break;
            case OID_IGD_QM_P_METERTYPE:
                if (!strcmp(psTmpVal, "SimpleTokenBucket"))
                {
                    xQMP.mtrType = IFX_MAPI_QoS_Meter_STB;
                }
                else if (!strcmp(psTmpVal, "SingleRateThreeColor"))
                {
                    xQMP.mtrType = IFX_MAPI_QoS_Meter_SRTCM;
                }
                else
                {
                    xQMP.mtrType = IFX_MAPI_QoS_Meter_TRTCM;
                }
                break;
            case OID_IGD_QM_P_POSSIBLEMETERTYPES:
                // Nothing to do. No place in structure
                break;
            case OID_IGD_QM_P_CONFORMINGACTION:
                if (!strcmp(psTmpVal, "Null"))
                {
                    xQMP.cfmAction = IFX_MAPI_QoS_Policer_NULL;
                }
                else if (!strcmp(psTmpVal, "Drop"))
                {
                    xQMP.cfmAction = IFX_MAPI_QoS_Policer_Drop;
                }
                else if ((pcTmp = strstr(psTmpVal, ":")) == NULL)
                {
                    
                    xQMP.cfmAction = IFX_MAPI_QoS_Policer_DSCP_Mark;
                    xQMP.cfmDscpMark = atoi(psTmpVal);
                }
                else if (pcTmp == psTmpVal)
                {
                    xQMP.cfmAction = IFX_MAPI_QoS_Policer_P_Bits_Mark;
                    xQMP.cfmPbitsMark = atoi(psTmpVal+1);
                }
                else
                {
                    xQMP.cfmAction = IFX_MAPI_QoS_Policer_DSCP_P_Bits_Mark;
                    xQMP.cfmDscpMark = atoi(psTmpVal);
                    xQMP.cfmPbitsMark = atoi(pcTmp+1);
                }
                break;
            case OID_IGD_QM_P_PARTIALCONFORMINGACTION:
                if (!strcmp(psTmpVal, "Null"))
                {
                    xQMP.partCfmAction = IFX_MAPI_QoS_Policer_NULL;
                }
                else if (!strcmp(psTmpVal, "Drop"))
                {
                    xQMP.partCfmAction = IFX_MAPI_QoS_Policer_Drop;
                }
                else if ((pcTmp = strstr(psTmpVal, ":")) == NULL)
                {
                    
                    xQMP.partCfmAction = IFX_MAPI_QoS_Policer_DSCP_Mark;
                    xQMP.partCfmDscpMark = atoi(psTmpVal);
                }
                else if (pcTmp == psTmpVal)
                {
                    xQMP.partCfmAction = IFX_MAPI_QoS_Policer_P_Bits_Mark;
                    xQMP.partCfmPbitsMark = atoi(psTmpVal+1);
                }
                else
                {
                    xQMP.partCfmAction = IFX_MAPI_QoS_Policer_DSCP_P_Bits_Mark;
                    xQMP.partCfmDscpMark = atoi(psTmpVal);
                    xQMP.partCfmPbitsMark = atoi(pcTmp+1);
                }
                break;
            case OID_IGD_QM_P_NONCONFORMINGACTION:
                if (!strcmp(psTmpVal, "Null"))
                {
                    xQMP.nonCfmAction = IFX_MAPI_QoS_Policer_NULL;
                }
                else if (!strcmp(psTmpVal, "Drop"))
                {
                    xQMP.nonCfmAction = IFX_MAPI_QoS_Policer_Drop;
                }
                else if ((pcTmp = strstr(psTmpVal, ":")) == NULL)
                {
                    
                    xQMP.nonCfmAction = IFX_MAPI_QoS_Policer_DSCP_Mark;
                    xQMP.nonCfmDscpMark = atoi(psTmpVal);
                }
                else if (pcTmp == psTmpVal)
                {
                    xQMP.nonCfmAction = IFX_MAPI_QoS_Policer_P_Bits_Mark;
                    xQMP.nonCfmPbitsMark = atoi(psTmpVal+1);
                }
                else
                {
                    xQMP.nonCfmAction = IFX_MAPI_QoS_Policer_DSCP_P_Bits_Mark;
                    xQMP.nonCfmDscpMark = atoi(psTmpVal);
                    xQMP.nonCfmPbitsMark = atoi(pcTmp+1);
                }
                break;
            case OID_IGD_QM_P_COUNTEDPACKETS:
            case OID_IGD_QM_P_COUNTEDBYTES:
                // Nothing to do. No place in structure
                break;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter [%d]\n",
                            __FILE__, __func__, __LINE__, iRet, (pxParamVal[iCnt]).iaOID[iParamOffset]);
                goto cleanup;
        }
    }

        //TBD: Fill in the required params

	//Fill the operation
	iOper = IFX_OP_ADD;
	
	//Fills the Cpeid,ParentCepid,TR69Id,Owner
	iRet = IFX_GetParentObjCpeId(pxParamVal->iaOID,&uiPcpeId);
	if(iRet != IFX_CWMP_SUCCESS)
		goto cleanup;

	xQMP.iid.config_owner=pxOI->iCaller;
	xQMP.iid.cpeId.Id=0;
	xQMP.iid.pcpeId.Id=uiPcpeId;
	
	//Convert array into dotted form and then strcpy
	
	iRet = IFX_ConvertOidDottedForm(pxParamVal->iaOID, xQMP.iid.tr69Id);
	if(iRet != IFX_CWMP_SUCCESS)
		goto cleanup;

	//Flags should be filled
	iFlags =(	IFX_F_DONT_ACTIVATE|IFX_F_DONT_CHECKPOINT|
			IFX_F_DONT_VALIDATE|IFX_F_DONT_WRITE_TO_FLASH);
	iRtn = ifx_mapi_set_qos_policer(iOper, &xQMP, iFlags);

	if(iRtn != IFX_SUCCESS)
	{
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"ifx_mapi_set_qos_policer AddObj Mgmt API"					                          " returned error\n");
        iRet = ERR_CWMP_INTERNAL;
		goto cleanup;
		
	}	

cleanup:
return iRet;

}

STATIC int32
SetDelete(IN OperInfo *pxOI,INOUT ParamVal *pxParamVal,
          IN int32 iElements, OUT void **ppxParamStructRet,
          OUT int32 * piNumRetElem)
{
#define QUEUEMGMT_POLICER_OPTION_NO_OF_DEP_OIDS 0
    int32 iRet=IFX_CWMP_SUCCESS;
    int32 iRtn=IFX_SUCCESS;
    uint32 uiCpeid=0;
    IFX_MAPI_QoS_Policer xQMP;
    uint32 iOper=0,iFlags=0;
    int32  iParamPos=0;
    ParamVal *Param_DepOids=NULL;

    // handle CHK_DELETE_DEP
    if(pxOI->iSubOper == OP_SETVAL_CHK_DEL_DEP)
    {
        Param_DepOids = IFIN_CWMP_MALLOC((QUEUEMGMT_POLICER_OPTION_NO_OF_DEP_OIDS+1)* sizeof(ParamVal));
        if(Param_DepOids == NULL)
        {
           iRet = ERR_OUT_OF_MEMORY; 
           goto cleanup;
        }

        //Get the WanIpConParamPos 
        iParamPos = IFX_GetParamIdPos(pxParamVal->iaOID);
        if (iParamPos < 0) {
            IFX_CWMP_FREE(Param_DepOids);
            goto cleanup; //To fix SCA error
        }

        memcpy((Param_DepOids+0)->iaOID,pxParamVal->iaOID,
               (sizeof(int32)*(iParamPos+1)));

      *ppxParamStructRet = (void *)Param_DepOids;
      *piNumRetElem = QUEUEMGMT_POLICER_OPTION_NO_OF_DEP_OIDS+1;

        return IFIN_CWMP_SUCCESS;
    }

    if(pxOI->iSubOper == OP_SETVAL_CHK_DEL_ALLOWED)
    {
        return IFIN_CWMP_SUCCESS;
    }


    // Get Cpeid from object ID
    iRet = IFX_GetCpeId(pxParamVal->iaOID,&uiCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
    	goto cleanup;

    memset(&xQMP, 0, sizeof(IFX_MAPI_QoS_Policer));

    /* Fill the cpeid in the structure to get the required instance */
    xQMP.iid.cpeId.Id = uiCpeid;

    /* Get all the IFX_MAPI_QoS_Queue parameters using Protocol API */
    iRtn = ifx_mapi_get_qos_policer(&xQMP, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] ifx_mapi_get_qos_policer failed\n",
                    __FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    xQMP.iid.config_owner=pxOI->iCaller;
    xQMP.iid.cpeId.Id=uiCpeid;
    memset(xQMP.iid.tr69Id,0x00,MAX_TR69_ID_LEN);
    iOper = IFX_OP_DEL;
    iFlags = (IFX_F_DELETE|IFX_F_DONT_VALIDATE| IFX_F_DONT_CHECKPOINT|IFX_F_DONT_WRITE_TO_FLASH);
    iRtn = ifx_mapi_set_qos_policer(iOper, &xQMP, iFlags);
    if(iRet != IFX_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "ifx_mapi_set_qos_policer -delete Mgmt API returned error\n");
        iRet = ERR_CWMP_INTERNAL;
        goto cleanup;
    }

cleanup:
    return iRet;
}



/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : IFX_QMPolicer_Init
**
**   Description      : This function is called by the controller. It registers
**                      the function responsible for handling Policer
**                      object with data structure. It also performs
**                      initializations specific to Policer object.
**
**   Parameters       : No Parameters. 
**
**   Return Value     : IFX_CWMP_SUCCESS - When Policer object is
**                      initialized successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in initializing Policer object.
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_QMPolicer_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the Classification module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_QUEUE_MGMT_POLICER_OBJ, IFX_QMPolicer);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_QUEUE_MGMT_POLICER_OBJ);
        goto cleanup;
    }

cleanup:
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_QMPolicer
**
**   Description      : This function is called by the controller. It handles
**                      Policer object and performs  based on requested
**                      operations/suboperations by invoking internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_QMPolicer(IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
             OUT void **ppRet, OUT int32 *piNumRetElem)
{
    int32       iRet           = IFX_CWMP_SUCCESS;
    ParamVal    *pxParamVal    = (ParamVal *)pParamList;

    /* Process based on type of Operation */
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:

                    /* Get values of all the requested parameters */
                    iRet = GetVal(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_SETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:

                    /* Validate values of all the requested parameters */
                    iRet = Validate(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:

                    /* Check modify dependency of all requested parameters */
                    iRet = IFX_CWMP_SUCCESS;
                    break;
                case OP_SETVAL_MODIFY:

                    /* Set values of all the requested parameters */
                    iRet = Modify(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ATTRINFO:

                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ADD:
                    iRet = AddObj(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }
                    break;
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
                case OP_SETVAL_DELETE:
                    if((iRet= SetDelete(pxOI, pxParamVal,
                        iNumElem, ppRet, piNumRetElem))!= IFX_CWMP_SUCCESS)
                    {

                        switch(pxOI->iSubOper)
                        {
                            case OP_SETVAL_CHK_DEL_DEP:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
                                goto cleanup;
                            case OP_SETVAL_CHK_DEL_ALLOWED:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
                                goto cleanup;
                            case OP_SETVAL_DELETE:
                                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                            "%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
                                goto cleanup;
                        }
                    }
                    break;



                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_UPDATE_CHILDINFO:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD: 
                case OP_UPDATE_CHILDINFO_DEL: 
                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid Operation\n",
                         __func__, __LINE__, iRet);
            goto cleanup;
    }

cleanup:
    return (iRet);
}
