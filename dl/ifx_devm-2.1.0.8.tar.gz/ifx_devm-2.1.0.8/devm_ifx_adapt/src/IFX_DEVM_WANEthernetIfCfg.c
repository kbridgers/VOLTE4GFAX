/* 
** =============================================================================
**   FILE NAME        : IFX_WANEthernetIfCfg
**   PROJECT          : TR69
**   MODULES          : WANEthernetInterfaceConfig
**   DATE             : 2-12-2009
**   AUTHOR           : TR69 team
**   DESCRIPTION      :
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_Global.h"
#include "IFX_DEVM_AdaptCommon.h"
// Required for STATIC

#include "IFX_DEVM_OID.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_DS.h"
//#include <fcntl.h>
//#include <unistd.h>
extern char8 vcOsModId;

int32 IFX_WANEthernetIfCfg(IN OperInfo * pxOI, INOUT void *pParamList,
                                   IN int32 iNumElem, OUT void **ppRet,
                                               OUT int32 * piNumRetElem);
/*
** =============================================================================
**                              <LOCAL DEFINITIONS>
** =============================================================================
*/
#define IFX_WEIC_OBJ "InternetGatewayDevice.WANDevice.1.WANEthernetInterfaceConfig."
/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/

STATIC int32 GetVal(IN int32 iCaller, INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iLen = 0;
    int32 iCnt = 0;
    int32 iParamOffset = 0;
    int32 iFd = -1;
    char8 caBuff[100] = { 0 }, *psTmp = NULL;
    struct ifx_phyport_info xPort;
#ifdef MIPSTARGET
    int nodeNum = 0;
#endif

    /* Memset the port structure to zero */
    memset(&xPort, '\0', sizeof(xPort));

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamIdPos(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }
	
    for(iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
        (pxParamVal[iCnt]).Value = NULL;
    }

#ifdef MIPSTARGET
    /* Get the values for the requested instance */
    if((pxParamVal->iaOID[2]) == WAN_DEVICE_MII0) //IGD.WD.2.
    {
        nodeNum = 1;
    }
    else if((pxParamVal->iaOID[2]) == WAN_DEVICE_MII1) //IGD.WD.3.
    {
        nodeNum = 0;
    }
    ifx_get_phyport_info(3, &xPort, nodeNum);//Only the port 3/GigE is used as wan port
#endif

    /* Iterate and fill the requested parameters */
    for(iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* TBD: 20 is the maximum size of parameter */
        (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(20);

        /* Check for error */
        if(!((pxParamVal[iCnt]).Value))
        {
            iRet = ERR_OUT_OF_MEMORY;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Allocation Failure\n",
                        __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_WAND_WANEIC_ENABLE:
                /* Copy the value to allocated area */
		sprintf((pxParamVal[iCnt]).Value, "%d", xPort.enable);
                break;

            case OID_IGD_WAND_WANEIC_STATUS:
                /* Copy the value to allocated area */
                if(xPort.link)
                    strcpy((pxParamVal[iCnt]).Value, "Up");
                else
                    strcpy((pxParamVal[iCnt]).Value, "NoLink");
                break;

            case OID_IGD_WAND_WANEIC_MACADDRESS:
                /* TBD: Remove br0 hardcoding for target */
                if((pxParamVal->iaOID[2]) == WAN_DEVICE_MII0)
                {
                    iRet = system("ifconfig eth0 | grep HWaddr > /tmp/ethaddr");
                }
                else if((pxParamVal->iaOID[2]) == WAN_DEVICE_MII1)
                {
                    iRet = system("ifconfig eth1 | grep HWaddr > /tmp/ethaddr");
                }
                else
                {
                    sprintf((pxParamVal[iCnt]).Value, "00:00:00:00:00:00");
                    iRet = IFX_CWMP_SUCCESS;
                    break;
                }
                if(iRet != IFX_CWMP_SUCCESS)
                {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] "
                                "system() failed query MAC address\n", _FUNCL_, iRet);
                    iRet = ERR_CWMP_INTERNAL;
                    goto cleanup;
                }
                iFd = open("/tmp/ethaddr", O_RDONLY);
                iLen = read(iFd, caBuff, (sizeof(caBuff) - 1));
		caBuff[iLen] = '\0';
                psTmp = strstr(caBuff, "HWaddr ");
                memcpy((pxParamVal[iCnt]).Value, psTmp + strlen("HWaddr "), 17);
                close(iFd);
                system("rm -f /tmp/ethaddr");
                break;

            case OID_IGD_WAND_WANEIC_MAXBITRATE:
                /* Copy the value to allocated area */
                if(xPort.speed == 0)
                    strcpy((pxParamVal[iCnt]).Value, "Auto");
                else
                    sprintf((pxParamVal[iCnt]).Value, "%d", xPort.speed);
                break;

            case OID_IGD_WAND_WANEIC_DUPLEXMODE:
                /* Copy the value to allocated area */
                if(xPort.duplex == 0)
                    strcpy((pxParamVal[iCnt]).Value, "Half");
		else if(xPort.duplex == 1)
                    strcpy((pxParamVal[iCnt]).Value, "Full");
                break;

            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_INVAL_PARAMETER_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
                goto cleanup;
        }
    }

cleanup:
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : Modify
**
**   Description      : This function modifies the values of parameters in 
**                      DeviceInfo object. It calls respective Management API  
**                      for the same. It performs modification only if parameter 
**                      has Write permission. In certain cases it also performs 
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            : 
** 
** ============================================================================
*/
STATIC int32 Modify(IN int32 iCaller, INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iCnt = 0, iParamOffset = 0;
    struct ifx_phyport_info xPort;
#ifdef MIPSTARGET
    int nodeNum = 0;
#endif

    if(pxParamVal[0].iaOID[2] == WAN_DEVICE_ATM) {
        iRet = IFX_CWMP_SUCCESS;
        return iRet;
    }

    /* Memset the port structure to zero */
    memset(&xPort, '\0', sizeof(xPort));

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamIdPos(pxParamVal->iaOID);
    if (iParamOffset <= 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Get the Instance Position */

#ifdef MIPSTARGET
    /* Get the values for the requested instance */
    if((pxParamVal->iaOID[2]) == WAN_DEVICE_MII0) //IGD.WD.2.
    {
        nodeNum = 1;
    }
    else if((pxParamVal->iaOID[2]) == WAN_DEVICE_MII1) //IGD.WD.3.
    {
        nodeNum = 0;
    }
    ifx_get_phyport_info(3, &xPort, nodeNum); 
#endif

    /* Iterate and fill the requested parameters */
    for(iCnt = 0; iCnt < iElements; iCnt++)
    {
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
	{
            case OID_IGD_WAND_WANEIC_ENABLE:
	    {
		if((strcmp((pxParamVal[iCnt]).Value, "1") == 0) || (strcasecmp((pxParamVal[iCnt]).Value, "true") == 0))
		{
                    #ifdef MIPSTARGET
		    ifx_set_phyport_info(3, IFX_MAPI_LANEIC_ENABLE, "1", nodeNum);
                    #endif
		}
                else if((strcmp((pxParamVal[iCnt]).Value, "0") == 0) || (strcasecmp((pxParamVal[iCnt]).Value, "false") == 0))
		{
                    #ifdef MIPSTARGET
		    ifx_set_phyport_info(3, IFX_MAPI_LANEIC_ENABLE, "0", nodeNum);
                    #endif
                }
                else
		{
                    iRet = ERR_CWMP_INVAL_PARAM_VAL;
                    pxParamVal[iCnt].iFaultCode = ERR_INVAL_PARAMETER_VAL;
                }
	    }             
	    break;

            case OID_IGD_WAND_WANEIC_STATUS:
            case OID_IGD_WAND_WANEIC_MACADDRESS:
            {
		iRet = ERR_NON_WRITABLE;
                (pxParamVal[iCnt]).iFaultCode = ERR_NON_WRITABLE_PARAM;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%s:%d] [%d] "
                            "Non writable parameter\n", __FILE__, __func__,
                            __LINE__, (pxParamVal[iCnt]).iaOID[iParamOffset]);
                
                break;
            }
            case OID_IGD_WAND_WANEIC_MAXBITRATE:
            {
                #ifdef MIPSTARGET
                ifx_set_phyport_info(3, IFX_MAPI_LANEIC_SPEED, (pxParamVal[iCnt]).Value, nodeNum);
                #endif
                break;
	    }

            case OID_IGD_WAND_WANEIC_DUPLEXMODE:
            {
                #ifdef MIPSTARGET
                ifx_set_phyport_info( 3, IFX_MAPI_LANEIC_DUPLEX, (pxParamVal[iCnt]).Value, nodeNum);
                #endif
                break;
	    }

            default:
            {
		iRet = ERR_CWMP_INVAL_PARAM_NAME;
                (pxParamVal[iCnt]).iFaultCode = ERR_INVAL_PARAMETER_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "[%s:%s:%d] [%d] "
                            "Unknown requested parameter\n", __FILE__, __func__,
                            __LINE__, (pxParamVal[iCnt]).iaOID[iParamOffset]);
                break;
	    }
        }
    }
cleanup:
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : Validate
**
**   Description      : This function validates the values of parameters in
**                      DeviceInfo object.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      validated.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When validation of all parameters is
**                      successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in validating at least one parameter.
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32 Validate(INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : GetModifyDep
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32 GetModifyDep(INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    return (IFX_CWMP_SUCCESS);
}

STATIC int32 GetNotify(IN OperInfo * pxOI, INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iCnt = 0;

    for(iCnt = 0; iCnt < iElements; iCnt++) {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
        (pxParamVal[iCnt]).Value = NULL;
    }

    return (iRet);
}

STATIC int32 SetAttrInfo(IN OperInfo * pxOI, INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iCnt;

    /* Set the fault code to Success */
    for(iCnt = 0; iCnt < iElements; iCnt++) {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
    }

    /* Get the offset of the parameter */
    IFX_GetParamIdPos(pxParamVal->iaOID);

    for(iCnt = 0; iCnt < iElements; iCnt++) {
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Update Attribute Information */
    iRet = IFX_SetAttributesInfo(NULL, pxParamVal, iElements);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Updating Param Attribute Info failed\n",
                    __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    return (iRet);
}

int32 IFX_WANEthernetIfCfgInit(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    iRet = ifx_ds_register_function(IFX_WEIC_OBJ, IFX_WANEthernetIfCfg);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_WEIC_OBJ);
        goto cleanup;
    }

cleanup:
    return iRet;
}


int32 IFX_WANEthernetIfCfg(IN OperInfo * pxOI, INOUT void *pParamList,
                                   IN int32 iNumElem, OUT void **ppRet,
                                               OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS, iCnt = 0;
    ParamVal *pxParamVal = (ParamVal *) pParamList;

    /* Process based on type of Operation */
    switch(pxOI->iOper)
    {
        case OP_GETVAL:
        {
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                {
                    /* Get values of all the requested parameters */
                    iRet = GetVal(pxOI->iCaller, pxParamVal, iNumElem);
                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }
                    break;
                }
                case OP_GETVAL_NOTIFICATION:
                {
                    /* Set attribute values for all the requested parameters */
                    iRet = GetNotify(pxOI, pxParamVal, iNumElem);
                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }
                    break;
                }
                default:
                {
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%d] [%d] Invalid SubOperation\n",
                                                                          __func__, __LINE__, iRet);
                    goto cleanup;
                }
            }
            break;
        }
        case OP_SETVAL:
        {
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                {
                    /* Validate values of all the requested parameters */
                    iRet = Validate(pxParamVal, iNumElem);
                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }
                    break;
                }
                case OP_SETVAL_CHK_MODIFY_DEP:
                {
                    /* Check modify dependency of all requested parameters */
                    iRet = GetModifyDep(pxParamVal, iNumElem);
                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                } 
                case OP_SETVAL_MODIFY:
                {
                    /* Set values of all the requested parameters */
                    iRet = Modify(pxOI->iCaller, pxParamVal, iNumElem);
                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                }
                case OP_SETVAL_ATTRINFO:
                {
                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);
                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                }
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_FREE:
                case OP_SETVAL_ADD:
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
                case OP_SETVAL_DELETE:
                {
                    break;
                }
                default:
                {
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                __func__, __LINE__, iRet);
                    goto cleanup;
                }
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            /* Process based on type of SubOperation */
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                case OP_UPDATE_CHILDINFO_DEL:
                {
                     break;
                }
                default:
                {
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                __func__, __LINE__, iRet);
                    goto cleanup;
                }
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            if((pxParamVal->iaOID[2]) == WAN_DEVICE_ATM) //IGD.WD.1.
            {
                /* Set the fault code to Error */
                for(iCnt = 0; iCnt < iNumElem; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_PARAMVAL_INVALID;
                }
            }
            break; 
        }
        default:
        {
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid Operation\n",
                        __func__, __LINE__, iRet);
            goto cleanup;
        }
    }
cleanup:
    return (iRet);
}
