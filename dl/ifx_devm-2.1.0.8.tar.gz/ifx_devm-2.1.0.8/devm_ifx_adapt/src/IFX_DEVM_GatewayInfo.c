/* 
** =============================================================================
**   FILE NAME        : IFX_GatewayInfo.c
**   PROJECT          : TR69
**   MODULES         : GatewayInfo
**   DATE               : 21-06-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION   : This module handles ADD/DEL/GET/SET RPCs of 
**                      GatewayInfo. When controller calls this module it
**                      calls respective Platform/Object APIs to handle GET/SET 
**                      of GatewayInfo specific information on the sytem.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author        $Comment
**   28-04-06         TR69 team      Intial version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
//#include <sys/socket.h>
//#include <netinet/in.h>
//#include <arpa/inet.h>

#include "IFX_DEVM_GatewayInfo.h"
 
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
 

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
extern uchar8 vcOsModId;

#define IFX_GATEWAY_INFO_OBJ "Device.GatewayInfo."


/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/




/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/





/* 
** =============================================================================
**   Function Name    : IFX_GatewayInfoGetValue
**   Description        : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes                : 
**
** ============================================================================
*/
static int32 
IFX_GatewayInfoGetValue(IN OperInfo *pxOperInfo,INOUT ParamVal *pxGetParamVal,
								IN uint32 iElements)
{
	/*GET PARAMETER VALUES
	**Get Object OID(skip parameter ID) from the first 
	**element in the array.Get Cpeid for this Object OID

	**Get the object from the system using a Platform API
	**with cpeid 
	
	**Do reverse mapping to convert system values into TR69
	**Values.After conversion stores the values in temp storage

	**While assigning the values as per request store the 
	**values in heap and assign the ptr to the struct
	**Return all the values 
	*/


	
	//uint32 iCpeid=0,
	uint32 i=0;
	int32 iParamId=0;
	uint32 uiParamPos=0;
	//int32 iConType=0;
	int32 iRet=0;
	uint32 uiCpeid;
	uint32 uiMode=IFX_CHK_CHANGE_FLAG_BASED;
	uint32 uiflags;
	GATEWAY_INFO xgateway_info;
	
	//IFX_ID iid;
	//IF_STATS if_stats;
	//uint32 iConType=0;
	//WAN_CONN_CFG *pxWanConn;

	//Memset the structs
	memset(&xgateway_info,0x00,sizeof(xgateway_info));
	
	//Get the Cpeid 
	iRet = IFX_GetCpeId(pxGetParamVal->iaOID,&uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	
 	xgateway_info.iid.cpeId.Id = uiCpeid;
	uiflags=IFX_F_GET_ANY;
	
	//Call the MAPI to get the values from conf file
	iRet = ifx_get_gateway_info(&xgateway_info, uiflags);
	if(iRet != IFX_SUCCESS)
	    goto errorHandler;

	//Fill the parameters and pass it back
	
	//Get the WanIpConParamPos 
	uiParamPos = IFX_GetParamIdPos(pxGetParamVal->iaOID);

			
	for(i=0;i < iElements; i++)
	{
	
		iParamId = pxGetParamVal->iaOID[uiParamPos];
	
		// Malloc and assign the pointer to the Value attr of struct 
		pxGetParamVal->Value = IFIN_CWMP_MALLOC(PARAMVALUE_LEN);


		switch(iParamId)
		{

			// Convert the value - reverse mapping
			// Assign the correct value to the Value attr	
	    		case OID_IGD_GI_MANUFACTUREROUI:
				
				strcpy(pxGetParamVal->Value,xgateway_info.oui);				
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;	 
					
	    		case OID_IGD_GI_PRODUCTCLASS:
				strcpy(pxGetParamVal->Value,xgateway_info.product_class);
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
				
			case OID_IGD_GI_SERIALNUMBER:
				strcpy(pxGetParamVal->Value,xgateway_info.serial_number);
				IFX_CheckValueGotChanged(pxOperInfo, pxGetParamVal,uiMode);
				break;
			
					
			default:
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "Invalid param id %d!\n", iParamId);
			pxGetParamVal->iFaultCode=ERR_INVAL_PARAMETER_NAME;
			break;
		}

							
			++pxGetParamVal;
	}

		//IFX_CWMP_FREE(pxWanConn);
		return IFX_CWMP_SUCCESS;
		
		errorHandler:
			//IFX_CWMP_FREE(pxWanConn);
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d failed!\n", __func__, __LINE__);
			return iRet;
			

}


/* 
** =============================================================================
**   Function Name    : IFX_GatewayInfoSetValue
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

static int32
IFX_GatewayInfoSetValue(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
							IN int32 iElements)
{

	uint32 uiCpeid=0;
	int32 iRet=IFX_CWMP_SUCCESS;
	uint32 uiflags=0,i=0;
	uint32 uiParamPos=0;
	GATEWAY_INFO xgateway_info;
	ParamVal *pxTmpPramVal=NULL;
	uint32 uioper=0;
	
	//Initialize the structs
	memset(&xgateway_info,'\0',sizeof(xgateway_info));

	if (pxOpInfo->iCaller != ACC_ROOT)
       {
            //(pxParamVal[iCnt]).iFaultCode = ERR_NON_WRITABLE;
                iRet = ERR_NON_WRITABLE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%d] [%d] Cannot modify the parameter\n",
                            __func__, __LINE__, iRet);
                goto errorHandler;
        }

	//Get the Cpeid from Tr69 id
	iRet = IFX_GetCpeId(paxParamVal->iaOID,&uiCpeid);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	//Get the object from system
	iRet = ifx_get_gateway_info(&xgateway_info, uiflags);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;
	
	uiParamPos = IFX_GetParamIdPos(paxParamVal->iaOID);
	
	pxTmpPramVal = paxParamVal;
	
	for (i=0; i < iElements; i++) 
	{

	      	switch(pxTmpPramVal->iaOID[uiParamPos])
		{

			case OID_IGD_GI_MANUFACTUREROUI:
				 /* Check if the string fits in the buffer */
	                if ((strlen(pxTmpPramVal->Value) + 1) > MAX_OUI_LEN)
	                {
	                    pxTmpPramVal->iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
	                    iRet = ERR_CWMP_BUFFER_OVERFLOW;
	                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                                "[%s:%s:%d] [%d] Space not enough to hold "
	                                "requested value",__FILE__, __func__,
	                                __LINE__, iRet);
				goto errorHandler;
	                }

	                /* Copy the string */
	                strcpy(xgateway_info.oui,pxTmpPramVal->Value);
			break;

			case OID_IGD_GI_PRODUCTCLASS:
			
	                /* Check if the string fits in the buffer */
	                if ((strlen(pxTmpPramVal->Value) + 1) > MAX_PROD_CLASS_LEN)
	                {
	                    pxTmpPramVal->iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
	                    iRet = ERR_CWMP_BUFFER_OVERFLOW;
	                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                                "[%s:%s:%d] [%d] Space not enough to hold "
	                                "requested value",__FILE__, __func__,
	                                __LINE__, iRet);
				goto errorHandler;
	                }

	                /* Copy the string */
	                strcpy(xgateway_info.product_class, pxTmpPramVal->Value);
			break;

			case OID_IGD_GI_SERIALNUMBER:
			/* Check if the string fits in the buffer */
	                if ((strlen(pxTmpPramVal->Value) + 1) > MAX_SERIAL_NUM_LEN)
	                {
	                    pxTmpPramVal->iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
	                    iRet = ERR_CWMP_BUFFER_OVERFLOW;
	                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                                "[%s:%s:%d] [%d] Space not enough to hold "
	                                "requested value",__FILE__, __func__,
	                                __LINE__, iRet);
				goto errorHandler;
	                }

	                /* Copy the string */
	                strcpy(xgateway_info.serial_number, pxTmpPramVal->Value);
			break;
	  	}

		pxTmpPramVal++;
		
	}

	uioper=IFX_OP_MOD;
	uiflags=(IFX_F_MODIFY| IFX_F_DONT_CHECKPOINT|IFX_F_DONT_WRITE_TO_FLASH);
	xgateway_info.iid.cpeId.Id=uiCpeid;
	//xgateway_info.iid.config_owner = pxOpInfo->iCaller;
    	xgateway_info.iid.config_owner = IFX_WEB;
	
	iRet = ifx_set_gateway_info(uioper, &xgateway_info, uiflags);
	if(iRet != IFX_CWMP_SUCCESS)
		goto errorHandler;

	return IFX_CWMP_SUCCESS;

	errorHandler:
		IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                                "[%s:%s:%d] [%d] GatewayInfo SetParamValues failed "
	                                ,__FILE__, __func__, __LINE__, iRet);
		return iRet;
	

}

/* 
** =============================================================================
**   Function Name    : IFX_GatewayInfoAddObj
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_GatewayInfoAddObj(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{

return IFX_CWMP_FAILURE;

}


/* 
** =============================================================================
**   Function Name    : IFX_GatewayInfoSetCommit
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_GatewayInfoSetCommit()
{
	return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_GatewayInfoSetUndo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_GatewayInfoSetUndo()
{
	return IFX_CWMP_SUCCESS;
}

/* 
** =============================================================================
**   Function Name    : IFX_GatewayInfoSetDelete
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_GatewayInfoSetDelete(IN OperInfo *pxOpInfo,INOUT ParamVal *paxParamVal,
							IN int32 iElements, OUT void **ppxParamStructRet,
												   OUT int32 * piNumRetElem)
{
	return IFX_CWMP_FAILURE;
}

/* 
** =============================================================================
**   Function Name    : IFX_GatewayInfoSetFree
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32 IFX_GatewayInfoSetFree()
{
	return IFX_CWMP_SUCCESS;
}


/* 
** =============================================================================
**   Function Name    : IFX_GatewayInfoSetAttr
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

static int32
IFX_GatewayInfoSetAttr(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{
	uint32 iRet,i;
	OperInfo xOpInfo;
	
	xOpInfo.iCaller = pxOpInfo->iCaller;
	xOpInfo.iOper= OP_GETVAL;
	xOpInfo.iSubOper= OP_GETVAL_NORMAL;
	
	iRet = IFX_GatewayInfoGetValue(&xOpInfo,pxParamVal, iElements);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorFreeHandler;
	
	iRet = IFX_SetAttributesInfo(pxOpInfo,pxParamVal, iElements);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;

	for(i=0; i < iElements; i++)
		IFX_CWMP_FREE(pxParamVal[i].Value);

	return IFX_CWMP_SUCCESS;

	errorFreeHandler:
		 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d failed!\n", __func__, __LINE__);
		for(i=0; i < iElements; i++)
		IFX_CWMP_FREE(pxParamVal[i].Value);
		
	errorHandler:
		 IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d failed!\n", __func__, __LINE__);
		return IFX_CWMP_FAILURE;
		


}



/* 
** =============================================================================
**   Function Name    : IFX_GatewayInfo_Init
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_GatewayInfo_Init(void)
{
	int32 iRet = IFX_CWMP_SUCCESS;

    
	/* Register the GatewayInfo module function pointer in the object model */
	iRet = ifx_ds_register_function(IFX_GATEWAY_INFO_OBJ, IFX_GatewayInfo);
	
	/* Check for error */
	if (iRet != IFX_CWMP_SUCCESS)
	{
	    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                "Unable to Register %s with Object Model\n",
	                 IFX_GATEWAY_INFO_OBJ);
	    goto errorHandler;
	}


	errorHandler:
			return iRet;
}

/*********************************************************************************
*  Function Name	:  IFX_GatewayInfo   
      *  Description	:  This function handles all the sub-states inside
      	 		   a GET/SET operation.If it is a GET it allocates the 
			   array(Name,Value pairs) and retruns the values.
			   If it is a SET controller allocates the array and
			   passes the values to this function.It calls 
			   respective internal functions which in turn calls 
			   respective Platform APIs.
                                                                                                 
*  Parameters    :<par_type> <par_data_type>  <par_name>   <description of par>
                    IN          OperInfo       pxOper;       Operation,
							     Sub-operation,Owner
                    INOUT       void *         pParamStruct; Struct which has 
					  	             Name,Value,etc
                    IN          int32	       iElements;    No. of Elements
		    OUT	        void *	       ppParamRet;   same as ParamStruc
		    OUT         int32 *        piNumRetElem; No. of elements 		                                
*  Return Value        : ret (SUCCESS== 0 / FAIL !=0 )
*  Notes               :
***********************************************************************************/
int32
IFX_GatewayInfo(IN OperInfo * pxOperInfo, INOUT void *paxParameterArr,
                IN int32 iElements, OUT void **ppaxParamArrRet, OUT int32 *piNumRetElem)
{
     
   //It calls the respective internal functions which handles resp. sub-operation
   
   //Set-Operation  
   //controller should pass the entire array during all the SET-sub_operations
   //It should handles only single get/set of instance at any point of time
   //It does not handle partial path
   //It won't handle multiple instances of the same object/module
   //at any point of time.

    
    int32 iRet = 0;
   ParamVal *paxParamArr = (ParamVal *)paxParameterArr;

	switch (pxOperInfo->iOper) 
	{
		//Get the object values
	   	case OP_GETVAL:
                {
	            if((iRet = IFX_GatewayInfoGetValue(pxOperInfo, paxParamArr,
		    							iElements)) != IFX_CWMP_SUCCESS) {
	                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d OP_GETVAL failed!\n", __func__, __LINE__);
			  goto errorHandler;
	            }
	            break;
                }
	        case OP_SETVAL:
		{

	    		//Set the obj values
			switch (pxOperInfo->iSubOper) 
			{
		               case OP_SETVAL_VALIDATE:
		                       
		                    break;
		                case OP_SETVAL_ADD:
		                    
		                    if((iRet= IFX_GatewayInfoAddObj(pxOperInfo,paxParamArr,
				    					iElements))!=IFX_CWMP_SUCCESS)
		                    	{
			                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                            	"%s:%d OP_SETVAL_ADD failed!\n", __func__, __LINE__);
			                    	 goto errorHandler;
		                    	}
		                    break;
		              case OP_SETVAL_CHK_MODIFY_DEP:
					  break;
					  
				case OP_SETVAL_MODIFY:
		                    if((iRet = IFX_GatewayInfoSetValue(pxOperInfo,paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
		                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_VALUE failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;
		                    
		                case OP_SETVAL_COMMIT:
		                    if((iRet = IFX_GatewayInfoSetCommit(pxOperInfo,paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
		                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_COMMIT failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;
		                case OP_SETVAL_UNDO:
		                    if((iRet =IFX_GatewayInfoSetUndo(pxOperInfo, paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
		                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_UNDO failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;
				case OP_SETVAL_CHK_DEL_DEP:
                                   // *ppaxParamArrRet = (ParamVal *)IFX_CWMP_MALLOC(sizeof(ParamVal));
                                   // memcpy(*ppaxParamArrRet, paxParameterArr, sizeof(ParamVal));
                                    //*piNumRetElem = 1;
                                    break;
				case OP_SETVAL_CHK_DEL_ALLOWED:
		              case OP_SETVAL_DELETE:
		                    if((iRet= IFX_GatewayInfoSetDelete(pxOperInfo, paxParamArr,
				    					iElements, ppaxParamArrRet,
				    					piNumRetElem))!= IFX_CWMP_SUCCESS) 
				    	{
		                    
			                    switch(pxOperInfo->iSubOper)
							{	
						  		case OP_SETVAL_CHK_DEL_DEP:
							    	IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_CHK_DEL_DEP failed!\n", __func__, __LINE__);
					                        goto errorHandler;
								case OP_SETVAL_CHK_DEL_ALLOWED:
									IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_CHK_DEL_ALLOWED failed!\n", __func__, __LINE__);
					                        goto errorHandler;
								case OP_SETVAL_DELETE:
									IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
			                            	"%s:%d OP_SETVAL_DELETE failed!\n", __func__, __LINE__);
					                        goto errorHandler;
							}
				     }
		                    break;
		                case OP_SETVAL_FREE:
		                    IFX_GatewayInfoSetFree(pxOperInfo);
					break;

				 case OP_SETVAL_ATTRINFO:
				 	if((iRet =IFX_GatewayInfoSetAttr(pxOperInfo, paxParamArr,
				    					iElements)) != IFX_CWMP_SUCCESS) {
		                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            	"%s:%d OP_SETVAL_ATTRINFO failed!\n", __func__, __LINE__);
		                        goto errorHandler;
		                    }
		                    break;
							
		                default:
		                    break;
			}
			break;
	        }
                case OP_PARAM_VALIDATE:
		{
			break;
		}
	        default:
                {
	            break;
                }
	}
	return IFX_CWMP_SUCCESS;

	errorHandler:
		return IFX_CWMP_FAILURE;
			
}
 
