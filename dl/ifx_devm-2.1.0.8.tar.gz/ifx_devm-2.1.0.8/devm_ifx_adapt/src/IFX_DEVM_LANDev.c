/*
** =============================================================================
** FILE NAME      : IFX_LANDevice.c
** PROJECT        : TR69
** MODULES        : InternetGatewayDevice.LANDevice.
** DATE           : 19-Jun-2006
** AUTHOR         : TR69 team
** DESCRIPTION    : This object is RO. SetParameterValues or AddObject cannot be
**                  performed on this object.
** REFERENCES     :  
** COPYRIGHT      : Copyright (c) 2006
**                  Infineon Technologies AG
**                  Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
** HISTORY        : 
** $Date        $Author          $Comment
** 19-Jun-2006  TR69 team        Creation         
** =============================================================================
*/
#include "IFX_DEVM_Global.h"
 
#include "IFX_DEVM_AdaptCommon.h"
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"

extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char8 * obj, modFunc pifx_module_func);

#define LANDEVICE_OBJ       "InternetGatewayDevice.LANDevice."
#define LANDEVICE_DEPTH     4

/*******************************************************************************
* Function: IFX_LANDeviceSetAttrInfo
* Description: Sets attribute information in the respective tr69 sections
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_LANDeviceSetAttrInfo(IN int32 iCaller, INOUT ParamVal * pxPV,
                         IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    iRet = IFX_SetAttributesInfo(NULL, pxPV, iElements);

    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Updating Param Attribute Info failed\n",
                    __func__, __LINE__, iRet);
        goto errorHandler;
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_LANDeviceGetValue
* Description: 
*              
* Parameters: IN OperInfo *pxOI, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
#define   LAN_DEVICE_GET_ALLOC                12
static int32
IFX_LANDeviceGetValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                      IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0, iNum = 0;
    char8 sTmp[LAN_DEVICE_GET_ALLOC] = {0};
#ifdef CONFIG_FEATURE_IFX_WIRELESS
    IFX_MAPI_WLAN_MainCfg      *wlMain=NULL;
#endif
    for(iI = 0; iI < iElements; iI++) {
        pxPV[iI].Value = IFX_CWMP_MALLOC(LAN_DEVICE_GET_ALLOC + 1);
        if(pxPV[iI].Value == NULL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", __func__, __LINE__);
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (pxPV[iI].iaOID[LANDEVICE_DEPTH - 1]) {
            case OID_IGD_LAND_LANETHERNETINTERFACENUMBEROFENTRIES:
#ifdef MIPSTARGET
                iRet = ifx_get_bridge_num_eth_ifs("br0", &iNum, 0);
#endif
                if(iRet != IFX_SUCCESS) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] "
                                "Get LANEthNumIf failed\n", __func__,
                                __LINE__, iRet);
                    iRet = ERR_CWMP_INTERNAL;
                    goto errorHandler;
                }
                sprintf(sTmp, "%d", iNum);
                strcpy(pxPV[iI].Value, sTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_CHANGE_FLAG_BASED);
                break;
            case OID_IGD_LAND_LANUSBINTERFACENUMBEROFENTRIES:
#ifdef MIPSTARGET
                iRet = ifx_get_bridge_num_usb_ifs("br0", &iNum, 0);
#endif
                if(iRet != IFX_SUCCESS) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] "
                                "Get USBNumIf failed\n", __func__,
                                __LINE__, iRet);
                    iRet = ERR_CWMP_INTERNAL;
                    goto errorHandler;
                }
                sprintf(sTmp, "%d", iNum);
                strcpy(pxPV[iI].Value, sTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_CHANGE_FLAG_BASED);
                break;
            case OID_IGD_LAND_LANWLANCONFIGURATIONNUMBEROFENTRIES:
#ifdef MIPSTARGET
                iRet = ifx_get_bridge_num_wlan_ifs("br0", &iNum, 0);
#endif
#ifdef CONFIG_FEATURE_IFX_WIRELESS
                iRet = ifx_mapi_get_all_wlan_main_config((uint32 *)&iNum, &wlMain, IFX_F_DEFAULT);
#endif
                if(iRet != IFX_SUCCESS) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] "
                                "Get WLANNumIf failed\n", __func__,
                                __LINE__, iRet);
                    iRet = ERR_CWMP_INTERNAL;
                    goto errorHandler;
                }
                sprintf(sTmp, "%d", iNum);
                strcpy(pxPV[iI].Value, sTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_CHANGE_FLAG_BASED);
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", __func__,
                            __LINE__, pxPV[iI].iaOID[LANDEVICE_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
#ifdef CONFIG_FEATURE_IFX_WIRELESS
    IFX_MEM_FREE(wlMain);
#endif
    return iRet;
}

/*******************************************************************************
* Function: IFX_LANDeviceValidate
* Description:
*              
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_LANDeviceValidate(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[LANDEVICE_DEPTH - 1]) {
            case OID_IGD_LAND_LANETHERNETINTERFACENUMBEROFENTRIES:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            case OID_IGD_LAND_LANUSBINTERFACENUMBEROFENTRIES:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            case OID_IGD_LAND_LANWLANCONFIGURATIONNUMBEROFENTRIES:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", __func__,
                            __LINE__, pxPV[iI].iaOID[LANDEVICE_DEPTH - 1]);
                break;
        }
    }
    return iRet;
}

/*******************************************************************************
* Function: IFX_LANDevice
* Description: 
*              
* Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
*             OUT void **ppRet, OUT int32 * piNumRetElem
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_LANDevice(IN OperInfo * pxOI, INOUT void *pParamStruct,
              IN int32 iElements, OUT void **ppRet, OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s: %s oper=%d maxElement=%d\n",
                __func__, xpParamVal[0].Name, pxOI->iSubOper, iElements);

    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                    iRet = IFX_LANDeviceGetValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_GETVAL_NOTIFICATION:
                    iRet = IFX_LANDeviceGetValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                    if((iRet =
                        IFX_LANDeviceValidate(xpParamVal, iElements)) != 0) {
                        goto errorHandler;
                    }
                    break;
                case OP_SETVAL_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:
                    break;
                case OP_SETVAL_MODIFY:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_COMMIT:
                    break;
                case OP_SETVAL_UNDO:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_DELETE:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_ATTRINFO:
                    IFX_LANDeviceSetAttrInfo(pxOI->iCaller, pParamStruct,
                                             iElements);
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
             //       iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_UPDATE_CHILDINFO_DEL:
               //     iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d [%d] Error! Default case.\n", __func__,
                        __LINE__, pxOI->iOper);
            break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_LANDeviceInit
* Description: Will initialize some of its data structures, register itself with 
*              DS.
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_LANDeviceInit()
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* TBD: Perform any LANEthernetIfCfgStatsInit related initializations here */

    /* Register the IFX_LANDeviceInit func ptr in the object model */
    iRet = ifx_ds_register_function(LANDEVICE_OBJ, IFX_LANDevice);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, LANDEVICE_OBJ);
        goto errorHandler;
    }

  errorHandler:
    return iRet;
}
