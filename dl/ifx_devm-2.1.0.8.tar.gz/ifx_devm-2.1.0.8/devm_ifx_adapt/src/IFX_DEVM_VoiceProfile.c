/* 
** =============================================================================
**   FILE NAME        : IFX_VoiceProfile
**   PROJECT          : TR104
**   MODULES          : IFX_VoiceProfile
**   DATE             : 11-11-2006
**   AUTHOR           : TR104 team
**   DESCRIPTION   :

**   REFERENCES      : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2004
**                         Infineon Technologies AG, st. Martin Strasse 53;
**                         81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/


/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "ifx_vmapi_common.h"
#include "IFX_DEVM_VoiceLine.h"
          // Required for STATIC
 
#include "IFX_DEVM_OID.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
 
#include "IFX_DEVM_DS.h"

//#include "ifx_voip_defs.h"
//#include "ifx_cm.h"
//#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

int32
IFX_VoiceProfileCfg(IN OperInfo * pxOI, INOUT void *pParamList,
                    IN int32 iNumElem, OUT void **ppRet,
                    OUT int32 * piNumRetElem);

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFX_VOICEPROFILE_OBJ "InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.1."

#define VOICE_CAP_DEV_DEPTH 3
#define PROF_NO_DEP_OIDS 6
/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/
STATIC int32
GetVal(IN int32 iCaller, INOUT ParamVal * pxParamVal, IN int32 iElements);
STATIC int32 Validate(INOUT ParamVal * pxParamVal, IN int32 iElements);
STATIC int32 GetModifyDep(INOUT ParamVal * pxParamVal, IN int32 iElements);
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal * pxParamVal, IN int32 iElements);
STATIC int32
GetNotify(IN OperInfo * pxOI, INOUT ParamVal * pxParamVal, IN int32 iElements);
STATIC int32
SetAttrInfo(IN OperInfo * pxOI, INOUT ParamVal * pxParamVal,
            IN int32 iElements);
/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/

#if 0
/*****************************************************************************
 *  Function Name   : ifx_AssocProfile
 *  Description     : This function is called in ifx_set_voip_sip_lineadv/linebasicprofile
 *  Input Values    : 
 *  Output Values   :
 *
 *  Return Value    : 
 *                    
 *  Notes           : 
 ****************************************************************************/
void
ifx_AssocProfile(uchar8 * pProfNum)
{

    int32 flag1 = 0, count1 = 0, x = 0;
    uchar8 ucPrevProf = 0;
    x_IFX_VMAPI_VoiceProfile xVoiceProf;
    x_IFX_VMAPI_VoiceLine xVoiceLine;
    a_assert(wp);

    memset(&xVoiceLine, 0, sizeof(xVoiceLine));
    xVoiceLine.ucLineId = g_LINE_ID_IS;
    xVoiceLine.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_get_VoiceLine(&xVoiceLine, 0)) {
        return;
    }

    /* There is no change in Profile Association. Just return */
    if(xVoiceLine.ucProfileId == atoi(pProfNum)) {
        return;
    }

    /* Line is already associated with the other Profile. So LineId has to be
       deleted from the AssoLineIds of that Profile */
    ucPrevProf = xVoiceLine.ucProfileId;


    if(ucPrevProf != 0) {
        memset(&xVoiceProf, 0, sizeof(xVoiceProf));
        xVoiceProf.ucProfileId = ucPrevProf;
        xVoiceProf.iid.config_owner = IFX_WEB;
        if(IFX_VMAPI_SUCCESS != ifx_get_VoiceProfile(&xVoiceProf, 0)) {
            return;
        }
        /* Checking if Line is already associated */
        while(xVoiceProf.aucAssoLineIds[x] != 0) {
            if(xVoiceProf.aucAssoLineIds[x] == xVoiceLine.ucLineId) {
                count1 = x;
                xVoiceProf.ucNoOfLines -= 1;
                while(xVoiceProf.aucAssoLineIds[count1] != 0) {
                    xVoiceProf.aucAssoLineIds[count1] =
                        xVoiceProf.aucAssoLineIds[count1 + 1];
                    count1++;
                }
            }
            x++;
        }
        if(IFX_VMAPI_SUCCESS != ifx_set_VoiceProfile(IFX_OP_MOD, &xVoiceProf,
                                                     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
        {
            return;
        }
    }

    /* Association with the Profile means, the pCpeId of Line needs to be set
       with the associated profile */
    xVoiceLine.ucProfileId = atoi(pProfNum);
    xVoiceLine.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_set_VoiceLine(IFX_OP_MOD, &xVoiceLine, 0)) {
        not_flag = 0;
        return;
    }
    else {
        not_flag = 1;
    }

    /* Profile Association */
    /* If no profile,give error */
    if(atoi(pProfNum) == 0) {
        return;
    }

    /* If no error,Assigning Line Id to the AssoLineIds of profile */
    memset(&xVoiceProf, 0, sizeof(xVoiceProf));
    xVoiceProf.ucProfileId = atoi(pProfNum);
    xVoiceProf.iid.config_owner = IFX_WEB;
    if(IFX_VMAPI_SUCCESS != ifx_get_VoiceProfile(&xVoiceProf, 0)) {
        return;
    }

    count1 = 0;
    x = 0;
    /* Checking if Line is already associated in the VoiceProfile */
    while(xVoiceProf.aucAssoLineIds[x] != 0) {
        if(xVoiceProf.aucAssoLineIds[x] == xVoiceLine.ucLineId) {
            flag1 = 1;
            return;             /* No need to set the VoiceProfile */
        }
        count1++;
        x++;
    }

    /* If not associated then assign it to the AssoLineIds of the profile */
    if(flag1 == 0) {
        xVoiceProf.aucAssoLineIds[count1] = xVoiceLine.ucLineId;
        xVoiceProf.ucNoOfLines += 1;
        if(IFX_VMAPI_SUCCESS != ifx_set_VoiceProfile(IFX_OP_MOD, &xVoiceProf,
                                                     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ))
        {
            return;
        }
    }

}

#endif

/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetVal(IN int32 iCaller, INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iRtn = IFX_SUCCESS;
    int32 iCnt = 0;
    int32 iTmpCnt = -1;         /* Mandatory */
    int32 iParamOffset;
    int32 iOID;
    int32 iMemErrorFlag = 0;    /* Mandatory */
    x_IFX_VMAPI_VoiceProfile xVoiceProfile;
    uint32 uiPCpeId;

    /* NOTE: For all parameters fault code is set to success by default. If
       error in validating first parameter, fault code is set to the error type 
       and other parameters are not validated. */
    /* NOTE: For all parameters value is set to NULL by default. */

    /* Set the fault code to Success and value to NULL pointer for all
       parameters */
    for(iCnt = 0; iCnt < iElements; iCnt++) {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);

    memset(&xVoiceProfile, 0, sizeof(x_IFX_VMAPI_VoiceProfile));

    /* Process based on the object */
    switch (iOID) {
        case OID_IGD_S_VS_VP:{

                char8 sOidString[100] = { 0 };
                IFX_CpeId *pxCpeIdArray = NULL;
                unsigned int uiNumCpeId;

                /* Get the Parent CPE Id */
                IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT & uiPCpeId);
                xVoiceProfile.iid.pcpeId.Id = uiPCpeId;

                /* ignore the last value as it will be a parameter and we need
                   only till the last instance */
                iRet =
                    IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID, sOidString);

                strcpy(xVoiceProfile.iid.tr69Id, sOidString);

                /* Get the CPE Id from the corresponding tr69 Id */
                iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT & uiNumCpeId,
                                              OUT & pxCpeIdArray);
                if(iRet != IFX_CWMP_SUCCESS) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                                __func__, __LINE__);

                    return ERR_CWMP_INTERNAL;
                }
                // printf("CPEID is %d\n",pxCpeIdArray->uiId); 

                /* Fill the CPE ID of the object instance */
                xVoiceProfile.iid.cpeId.Id = pxCpeIdArray->uiId;
                xVoiceProfile.iid.config_owner = IFX_TR69;

                /* Get all the VoiceProfile parameters using VMAPI */
                iRtn = ifx_get_VoiceProfile(&xVoiceProfile, IFX_F_DEFAULT);

                IFX_CWMP_FREE(pxCpeIdArray);

                /* Check for error */
                if(iRtn != IFX_SUCCESS) {
                    /* Set the fault code to Failure for all parameters */
                    for(iCnt = 0; iCnt < iElements; iCnt++) {
                        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                    }

                    iRet = IFX_CWMP_FAILURE;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Unable to get values of all "
                                "parameters\n", __FILE__, __func__, __LINE__,
                                iRet);
                    goto cleanup;
                }
            }
            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for(iCnt = 0; iCnt < iElements; iCnt++) {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset]) {
            case OID_IGD_S_VS_VP_ENABLE:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(10);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }


                /* Copy the value to allocated area */
                /*if(xVoiceProfile.ucState == IFX_VMAPI_VP_STATE_DISABLED)*/
                if(xVoiceProfile.ucState == 0)
                    strcpy((pxParamVal[iCnt]).Value, "Disabled");
                else if(xVoiceProfile.ucState == IFX_VMAPI_VP_STATE_QUIESCENT)
                    strcpy((pxParamVal[iCnt]).Value, "Quiscent");
                else if(xVoiceProfile.ucState == IFX_VMAPI_VP_STATE_ENABLED)
                    strcpy((pxParamVal[iCnt]).Value, "Enabled");

                break;
            case OID_IGD_S_VS_VP_RESET:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                if(xVoiceProfile.bReset == IFX_TR104_FALSE)
                    strcpy((pxParamVal[iCnt]).Value, "false");
                else if(xVoiceProfile.bReset == IFX_TR104_TRUE)
                    strcpy((pxParamVal[iCnt]).Value, "true");
                break;
            case OID_IGD_S_VS_VP_NUMBEROFLINES:

                (pxParamVal[iCnt]).Value =
                    (void *)IFX_CWMP_MALLOC(sizeof(uchar8));

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }


                /* Copy the value to allocated area */
                sprintf((pxParamVal[iCnt]).Value, "%d",
                        xVoiceProfile.ucNoOfLines);

                break;
            case OID_IGD_S_VS_VP_NAME:

                (pxParamVal[iCnt]).Value =
                    (void *)
                    IFX_CWMP_MALLOC(sizeof(xVoiceProfile.acProfileName));

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xVoiceProfile.acProfileName);

                break;
            case OID_IGD_S_VS_VP_SIGNALINGPROTOCOL:

                (pxParamVal[iCnt]).Value =
                    (void *)IFX_CWMP_MALLOC(sizeof(IFX_VMAPI_SIG_PROTOCOL));

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, IFX_VMAPI_SIG_PROTOCOL);

                break;
            case OID_IGD_S_VS_VP_MAXSESSIONS:

                (pxParamVal[iCnt]).Value =
                    (void *)IFX_CWMP_MALLOC(sizeof(IFX_VMAPI_VP_MAX_SESSIONS));

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                /* Copy the value to allocated area */
                sprintf((pxParamVal[iCnt]).Value, "%d",
                        IFX_VMAPI_VP_MAX_SESSIONS);

                break;
            case OID_IGD_S_VS_VP_DTMFMETHOD:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(8);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                if(xVoiceProfile.ucDtmfMethod == IFX_VMAPI_VP_DTMF_MTHD_INBAND)
                    strcpy((pxParamVal[iCnt]).Value, "InBand");
                else if(xVoiceProfile.ucDtmfMethod ==
                        IFX_VMAPI_VP_DTMF_MTHD_RFC2833)
                    strcpy((pxParamVal[iCnt]).Value, "RFC2833");
                if(xVoiceProfile.ucDtmfMethod == IFX_VMAPI_VP_DTMF_MTHD_INFO)
                    strcpy((pxParamVal[iCnt]).Value, "SIPInfo");

                break;
            case OID_IGD_S_VS_VP_DTMFMETHODG711:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(8);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                if(xVoiceProfile.ucG711DtmfMethod ==
                   IFX_VMAPI_VP_DTMF_MTHD_INBAND)
                    strcpy((pxParamVal[iCnt]).Value, "InBand");
                else if(xVoiceProfile.ucG711DtmfMethod ==
                        IFX_VMAPI_VP_DTMF_MTHD_RFC2833)
                    strcpy((pxParamVal[iCnt]).Value, "RFC2833");
                if(xVoiceProfile.ucG711DtmfMethod ==
                   IFX_VMAPI_VP_DTMF_MTHD_INFO)
                    strcpy((pxParamVal[iCnt]).Value, "SIPInfo");

                break;
            case OID_IGD_S_VS_VP_REGION:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(2);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                if(xVoiceProfile.uiAssocCountry == IFX_VMAPI_COUNTRY_USA)
                    strcpy((pxParamVal[iCnt]).Value,
                           IFX_VMAPI_COUNTRY_NAME_USA);
                if(xVoiceProfile.uiAssocCountry == IFX_VMAPI_COUNTRY_GERMANY)
                    strcpy((pxParamVal[iCnt]).Value,
                           IFX_VMAPI_COUNTRY_NAME_GERMANY);
                if(xVoiceProfile.uiAssocCountry == IFX_VMAPI_COUNTRY_CHINA)
                    strcpy((pxParamVal[iCnt]).Value,
                           IFX_VMAPI_COUNTRY_NAME_CHINA);
                if(xVoiceProfile.uiAssocCountry == IFX_VMAPI_COUNTRY_TAIWAN)
                    strcpy((pxParamVal[iCnt]).Value,
                           IFX_VMAPI_COUNTRY_NAME_TAIWAN);
                if(xVoiceProfile.uiAssocCountry == IFX_VMAPI_COUNTRY_INDIA)
                    strcpy((pxParamVal[iCnt]).Value,
                           IFX_VMAPI_COUNTRY_NAME_INDIA);
                if(xVoiceProfile.uiAssocCountry == IFX_VMAPI_COUNTRY_JAPAN)
                    strcpy((pxParamVal[iCnt]).Value,
                           IFX_VMAPI_COUNTRY_NAME_JAPAN);

                break;
            case OID_IGD_S_VS_VP_DIGITMAP:

                (pxParamVal[iCnt]).Value =
                    (void *)IFX_CWMP_MALLOC(sizeof(xVoiceProfile.acDigitMap));

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xVoiceProfile.acDigitMap);

                break;
            case OID_IGD_S_VS_VP_DIGITMAPENABLE:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }


                /* Copy the value to allocated area */
                if(xVoiceProfile.bEnableDigitMap == IFX_TR104_FALSE)
                    strcpy((pxParamVal[iCnt]).Value, "false");
                else if(xVoiceProfile.bEnableDigitMap == IFX_TR104_TRUE)
                    strcpy((pxParamVal[iCnt]).Value, "true");
                break;
            case OID_IGD_S_VS_VP_STUNENABLE:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                if(xVoiceProfile.bEnableStun == IFX_TR104_FALSE)
                    strcpy((pxParamVal[iCnt]).Value, "false");
                else if(xVoiceProfile.bEnableStun == IFX_TR104_TRUE)
                    strcpy((pxParamVal[iCnt]).Value, "true");
                break;

            case OID_IGD_S_VS_VP_STUNSERVER:

                (pxParamVal[iCnt]).Value =
                    (void *)
                    IFX_CWMP_MALLOC(sizeof
                                    (xVoiceProfile.xStunConfig.acStunServer));

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value,
                       xVoiceProfile.xStunConfig.acStunServer);

                break;
            case OID_IGD_S_VS_VP_NONVOICEBANDWIDTHRESERVEDUPSTREAM:

                (pxParamVal[iCnt]).Value =
                    (void *)
                    IFX_CWMP_MALLOC(sizeof(xVoiceProfile.uiDataResUpBandwidth));

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                sprintf((pxParamVal[iCnt]).Value, "%d",
                        xVoiceProfile.uiDataResUpBandwidth);

                break;
            case OID_IGD_S_VS_VP_NONVOICEBANDWIDTHRESERVEDDOWNSTREAM:

                (pxParamVal[iCnt]).Value =
                    (void *)
                    IFX_CWMP_MALLOC(sizeof
                                    (xVoiceProfile.uiDataResDownBandwidth));

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                sprintf((pxParamVal[iCnt]).Value, "%d",
                        xVoiceProfile.uiDataResDownBandwidth);

                break;
            case OID_IGD_S_VS_VP_PSTNFAILOVER:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }


                /* Copy the value to allocated area */
                if(xVoiceProfile.bPstnFailOver == IFX_TR104_FALSE)
                    strcpy((pxParamVal[iCnt]).Value, "false");
                else if(xVoiceProfile.bPstnFailOver == IFX_TR104_TRUE)
                    strcpy((pxParamVal[iCnt]).Value, "true");
                break;
            case OID_IGD_S_VS_VP_FAXPASSTHROUGH:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(8);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                if(xVoiceProfile.bFaxPassThru == IFX_TR104_FALSE)
                    strcpy((pxParamVal[iCnt]).Value, "false");
                else if(xVoiceProfile.bFaxPassThru == IFX_TR104_TRUE)
                    strcpy((pxParamVal[iCnt]).Value, "true");

                break;
            case OID_IGD_S_VS_VP_MODEMPASSTHROUGH:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(8);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                if(xVoiceProfile.bModemPassThru == IFX_TR104_FALSE)
                    strcpy((pxParamVal[iCnt]).Value, "false");
                else if(xVoiceProfile.bModemPassThru == IFX_TR104_TRUE)
                    strcpy((pxParamVal[iCnt]).Value, "true");

                break;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                iTmpCnt = iCnt;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
                goto cleanup;
        }
    }

  cleanup:

    if(iMemErrorFlag) {
        (pxParamVal[iCnt]).iFaultCode = ERR_OUT_OF_MEMORY;
        iRet = ERR_OUT_OF_MEMORY;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Allocation Failure\n",
                    __FILE__, __func__, __LINE__, iRet);
    }

    if(iRet != IFX_CWMP_SUCCESS) {

        /* Free the allocation for value, if any. Also set the fault code. */
        for(iCnt = 0; iCnt < iElements; iCnt++) {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
            if(iTmpCnt != iCnt) {
                (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
            }
        }
    }

    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : Modify
**
**   Description      : This function modifies the values of parameters in 
**                      VoiceProfile object. It calls respective VMAPI for  
**                      the same. It performs modification only if parameter 
**                      has Write permission. In certain cases it also performs 
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iRtn = IFX_SUCCESS;
    int32 iCnt = 0;
    int32 iParamOffset;
    int32 iOID;
    int32 iMemErrorFlag = 0;    /* Mandatory */
    int32 iTmpCnt = -1;         /* Mandatory */
    x_IFX_VMAPI_VoiceProfile xVoiceProfile;
    uint32 uiPCpeId;

    /* NOTE: For all parameters fault code is set to success by default. If
       error in validating first parameter, fault code is set to the error type 
       and other parameters are not validated. */

    /* Set the fault code to Success for all parameters */
    for(iCnt = 0; iCnt < iElements; iCnt++) {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
    }

    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);

    memset(&xVoiceProfile, 0, sizeof(x_IFX_VMAPI_VoiceProfile));

    /* Process based on the object */
    switch (iOID) {
        case OID_IGD_S_VS_VP:{

                char8 sOidString[100] = { 0 };
                IFX_CpeId *pxCpeIdArray = NULL;
                unsigned int uiNumCpeId;

                /* Get the Parent CPE Id */
                IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT & uiPCpeId);
                xVoiceProfile.iid.pcpeId.Id = uiPCpeId;

                /* ignore the last value as it will be a parameter and we need
                   only till the last instance */
                iRet =
                    IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID, sOidString);

                strcpy(xVoiceProfile.iid.tr69Id, sOidString);

                /* Get the CPE Id from the corresponding tr69 Id */
                iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT & uiNumCpeId,
                                              OUT & pxCpeIdArray);
                if(iRet != IFX_CWMP_SUCCESS) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                                __func__, __LINE__);

                    return ERR_CWMP_INTERNAL;
                }

                /* Fill the CPE ID of the object instance */
                xVoiceProfile.iid.cpeId.Id = pxCpeIdArray->uiId;
                xVoiceProfile.iid.config_owner = IFX_TR69;

                /* Get all the VoiceProfile parameters using VMAPI */
                iRtn = ifx_get_VoiceProfile(&xVoiceProfile, IFX_F_DEFAULT);

                IFX_CWMP_FREE(pxCpeIdArray);

                /* Check for error */
                if(iRtn != IFX_CWMP_SUCCESS) {
                    /* Set the fault code to Failure for all parameters */
                    for(iCnt = 0; iCnt < iElements; iCnt++) {
                        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                    }

                    iRet = IFX_CWMP_FAILURE;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Unable to get values of all "
                                "parameters\n", __FILE__, __func__, __LINE__,
                                iRet);
                    goto cleanup;
                }
            }
            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for(iCnt = 0; iCnt < iElements; iCnt++) {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset]) {
            case OID_IGD_S_VS_VP_ENABLE:
                if(!strncasecmp(pxParamVal[iCnt].Value, "Disabled", 8))
                    xVoiceProfile.ucState = IFX_VMAPI_VL_STATE_DISABLED;
                else if(!strncasecmp(pxParamVal[iCnt].Value, "Quiescent", 9))
                    xVoiceProfile.ucState = IFX_VMAPI_VL_STATE_QUIESCENT;
                else if(!strncasecmp(pxParamVal[iCnt].Value, "Enabled", 7))
                    xVoiceProfile.ucState = IFX_VMAPI_VL_STATE_ENABLED;

                break;
            case OID_IGD_S_VS_VP_RESET:

                if((!strncasecmp(pxParamVal[iCnt].Value, "true", 4)) ||
                   atoi(pxParamVal[iCnt].Value) == 1)
                    xVoiceProfile.bReset = IFX_TR104_TRUE;
                else if((!strncasecmp(pxParamVal[iCnt].Value, "false", 5)) ||
                        atoi(pxParamVal[iCnt].Value) == 0)
                    xVoiceProfile.bReset = IFX_TR104_FALSE;
                break;
            case OID_IGD_S_VS_VP_NAME:
                strncpy(xVoiceProfile.acProfileName, pxParamVal[iCnt].Value, (IFX_VMAPI_VP_NAME_LEN-1));
                break;
            case OID_IGD_S_VS_VP_SIGNALINGPROTOCOL:
                // strcpy(xVoiceProfile.acProfileName,pxParamVal[iCnt].Value); 
                break;
            case OID_IGD_S_VS_VP_MAXSESSIONS:
                // xVoiceProfile.acProfileName = pxParamVal[iCnt].Value; 
                break;
            case OID_IGD_S_VS_VP_DTMFMETHOD:

                if(!strncasecmp(pxParamVal[iCnt].Value, "InBand", 6))
                    xVoiceProfile.ucDtmfMethod = IFX_VMAPI_VP_DTMF_MTHD_INBAND;
                else if(!strncasecmp(pxParamVal[iCnt].Value, "RFC2833", 7))
                    xVoiceProfile.ucDtmfMethod = IFX_VMAPI_VP_DTMF_MTHD_RFC2833;
                else if(!strncasecmp(pxParamVal[iCnt].Value, "SIPInfo", 7))
                    xVoiceProfile.ucDtmfMethod = IFX_VMAPI_VP_DTMF_MTHD_INFO;
                break;
            case OID_IGD_S_VS_VP_DTMFMETHODG711:

                if(!strncasecmp(pxParamVal[iCnt].Value, "InBand", 6))
                    xVoiceProfile.ucG711DtmfMethod =
                        IFX_VMAPI_VP_DTMF_MTHD_INBAND;
                else if(!strncasecmp(pxParamVal[iCnt].Value, "RFC2833", 7))
                    xVoiceProfile.ucG711DtmfMethod =
                        IFX_VMAPI_VP_DTMF_MTHD_RFC2833;
                else if(!strncasecmp(pxParamVal[iCnt].Value, "SIPInfo", 7))
                    xVoiceProfile.ucG711DtmfMethod =
                        IFX_VMAPI_VP_DTMF_MTHD_INFO;
                break;
            case OID_IGD_S_VS_VP_REGION:
                if(!strcmp(pxParamVal[iCnt].Value, IFX_VMAPI_COUNTRY_NAME_USA))
                    xVoiceProfile.uiAssocCountry = IFX_VMAPI_COUNTRY_USA;
                else if(!strcmp(pxParamVal[iCnt].Value,
                                IFX_VMAPI_COUNTRY_NAME_GERMANY))
                    xVoiceProfile.uiAssocCountry = IFX_VMAPI_COUNTRY_GERMANY;
                else if(!strcmp(pxParamVal[iCnt].Value,
                                IFX_VMAPI_COUNTRY_NAME_CHINA))
                    xVoiceProfile.uiAssocCountry = IFX_VMAPI_COUNTRY_CHINA;
                else if(!strcmp(pxParamVal[iCnt].Value,
                                IFX_VMAPI_COUNTRY_NAME_TAIWAN))
                    xVoiceProfile.uiAssocCountry = IFX_VMAPI_COUNTRY_TAIWAN;
                else if(!strcmp(pxParamVal[iCnt].Value,
                                IFX_VMAPI_COUNTRY_NAME_INDIA))
                    xVoiceProfile.uiAssocCountry = IFX_VMAPI_COUNTRY_INDIA;
                else if(!strcmp(pxParamVal[iCnt].Value,
                                IFX_VMAPI_COUNTRY_NAME_JAPAN))
                    xVoiceProfile.uiAssocCountry = IFX_VMAPI_COUNTRY_JAPAN;
                break;
            case OID_IGD_S_VS_VP_DIGITMAP:
                strncpy(xVoiceProfile.acDigitMap, pxParamVal[iCnt].Value, (IFX_VMAPI_VP_MAX_DIGIT_MAP_LEN-1));
                break;
            case OID_IGD_S_VS_VP_DIGITMAPENABLE:

                if((!strncasecmp(pxParamVal[iCnt].Value, "true", 4)) ||
                   atoi(pxParamVal[iCnt].Value) == 1)
                    xVoiceProfile.bEnableDigitMap = IFX_TR104_TRUE;
                else if((!strncasecmp(pxParamVal[iCnt].Value, "false", 5)) ||
                        atoi(pxParamVal[iCnt].Value) == 0)
                    xVoiceProfile.bEnableDigitMap = IFX_TR104_FALSE;
                break;
            case OID_IGD_S_VS_VP_STUNENABLE:

                if((!strncasecmp(pxParamVal[iCnt].Value, "true", 4)) ||
                   atoi(pxParamVal[iCnt].Value) == 1)
                    xVoiceProfile.bEnableStun = IFX_TR104_TRUE;
                else if((!strncasecmp(pxParamVal[iCnt].Value, "false", 5)) ||
                        atoi(pxParamVal[iCnt].Value) == 0)
                    xVoiceProfile.bEnableStun = IFX_TR104_FALSE;
                break;
            case OID_IGD_S_VS_VP_STUNSERVER:
                strncpy(xVoiceProfile.xStunConfig.acStunServer,pxParamVal[iCnt].Value, IFX_VMAPI_MAX_TRANS_ADDR_LEN-1);
                break;
            case OID_IGD_S_VS_VP_NONVOICEBANDWIDTHRESERVEDUPSTREAM:
                xVoiceProfile.uiDataResUpBandwidth =
                    atoi(pxParamVal[iCnt].Value);
                break;
            case OID_IGD_S_VS_VP_NONVOICEBANDWIDTHRESERVEDDOWNSTREAM:
                xVoiceProfile.uiDataResDownBandwidth =
                    atoi(pxParamVal[iCnt].Value);
                break;
            case OID_IGD_S_VS_VP_PSTNFAILOVER:

                if((!strncasecmp(pxParamVal[iCnt].Value, "true", 4)) ||
                   atoi(pxParamVal[iCnt].Value) == 1)
                    xVoiceProfile.bPstnFailOver = IFX_TR104_TRUE;
                else if((!strncasecmp(pxParamVal[iCnt].Value, "false", 5)) ||
                        atoi(pxParamVal[iCnt].Value) == 0)
                    xVoiceProfile.bPstnFailOver = IFX_TR104_FALSE;
                break;
            case OID_IGD_S_VS_VP_FAXPASSTHROUGH:

                break;
            case OID_IGD_S_VS_VP_MODEMPASSTHROUGH:

                break;

            case OID_IGD_S_VS_VP_NUMBEROFLINES:
                /* NumberOfLines can be changed if caller is ROOT */
                if(iCaller == ACC_ROOT) {

                    (pxParamVal[iCnt]).Value =
                        (void *)IFX_CWMP_MALLOC(sizeof(uchar8));

                    /* Check for error */
                    if(!((pxParamVal[iCnt]).Value)) {
                        /* Set the memory error flag */
                        iMemErrorFlag = 1;
                        iTmpCnt = iCnt;
                        goto cleanup;
                    }

                    /* Copy the value to allocated area */
                    xVoiceProfile.ucNoOfLines = atoi(pxParamVal[iCnt].Value);
                }
                else {
                    (pxParamVal[iCnt]).Value = NULL;
                }
                break;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

    /* Process based on the object */
    switch (iOID) {
        case OID_IGD_S_VS_VP:

            /* Fill the iid structure in VOICE_PROFILE */
            xVoiceProfile.iid.config_owner = IFX_TR69;

            /* Set all the VOICE_PROFILE parameters using VMAPI */
            // iRtn = ifx_set_VoiceProfile(IFX_OP_MOD, &xVoiceProfile, 
            // IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT | 
            // IFX_F_DONT_WRITE_TO_FLASH);
            iRtn = ifx_set_VoiceProfile(IFX_OP_MOD, &xVoiceProfile, 0);

            /* Check for error */
            if(iRtn != IFX_SUCCESS) {
                /* Set the fault code to Failure for all parameters */
                for(iCnt = 0; iCnt < iElements; iCnt++) {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to set values of all "
                            "parameters\n", __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
            }

            break;
        default:
            /* Will never come here since already checked above */
            break;
    }

  cleanup:

    if(iMemErrorFlag) {
        (pxParamVal[iCnt]).iFaultCode = ERR_OUT_OF_MEMORY;
        iRet = ERR_OUT_OF_MEMORY;
        iTmpCnt = iCnt;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Allocation Failure\n",
                    __FILE__, __func__, __LINE__, iRet);
    }

    if(iRet != IFX_CWMP_SUCCESS) {

        /* Free the allocation for value, if any. Also set the fault code. */
        for(iCnt = 0; iCnt < iElements; iCnt++) {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
            if(iTmpCnt != iCnt) {
                (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
            }
        }
    }
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : Validate
**
**   Description      : This function validates the values of parameters in
**                      VoiceProfile object.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      validated.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When validation of all parameters is
**                      successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in validating at least one parameter.
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
Validate(INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iCnt;
    int32 iParamOffset;

    /* NOTE: For all parameters fault code is set to success by default. If
       error in validating first parameter, fault code is set to the error type 
       and other parameters are not validated. */

    /* NOTE: Currently validation is performed only for parameters that have
       write permission. Other parameters are simply ignored. I think this
       should be fine since those validations are performed by the controller */

    /* Set the fault code to Success for all parameters */
    for(iCnt = 0; iCnt < iElements; iCnt++) {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and validate the requested parameters */
    for(iCnt = 0; iCnt < iElements; iCnt++) {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset]) {
            case OID_IGD_S_VS_VP_ENABLE:
            case OID_IGD_S_VS_VP_RESET:
            case OID_IGD_S_VS_VP_NAME:
            case OID_IGD_S_VS_VP_SIGNALINGPROTOCOL:
            case OID_IGD_S_VS_VP_MAXSESSIONS:
            case OID_IGD_S_VS_VP_DTMFMETHOD:
            case OID_IGD_S_VS_VP_DTMFMETHODG711:
            case OID_IGD_S_VS_VP_REGION:
            case OID_IGD_S_VS_VP_DIGITMAP:
            case OID_IGD_S_VS_VP_STUNENABLE:
            case OID_IGD_S_VS_VP_STUNSERVER:
            case OID_IGD_S_VS_VP_FAXPASSTHROUGH:
            case OID_IGD_S_VS_VP_MODEMPASSTHROUGH:
                /* RO params - Not validating. just returtning success */
                break;
            case OID_IGD_S_VS_VP_NUMBEROFLINES:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_PARAM_NOT_SUPPORTED;
                iRet = ERR_CWMP_PARAM_NOT_SUPPORTED;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Parameter Not Supported\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

  cleanup:
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Validating requested parameter failed\n",
                    __FILE__, __func__, __LINE__, iRet);
    }
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : GetModifyDep
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
GetModifyDep(INOUT ParamVal * pxParamVal, IN int32 iElements)
{

    int32 iCnt;
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iRtn = IFX_SUCCESS;
    int32 iParamOffset;
    int32 iLength;
    char8 *psTmpVal;
    uint32 uiOutElem = 0;

    int32 tmp1, tmp2;
    ParamVal xInVoiceCap;

    /* NOTE: For all parameters fault code is set to success by default. If
       error in validating first parameter, fault code is set to the error type 
       and other parameters are not validated. */

    /* NOTE: Currently validation is performed only for parameters that have
       write permission. Other parameters are simply ignored. I think this
       should be fine since those validations are performed by the controller */

    /* Set the fault code to Success for all parameters */
    for(iCnt = 0; iCnt < iElements; iCnt++) {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and validate the requested parameters */
    for(iCnt = 0; iCnt < iElements; iCnt++) {

        psTmpVal = (char8 *) ((pxParamVal[iCnt]).Value);

        /* Return a failure if the value is NULL pointer */
        if(!psTmpVal) {
            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
            iRet = ERR_CWMP_INVAL_PARAM_VAL;
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset]) {
            case OID_IGD_S_VS_VP_SIGNALINGPROTOCOL:
#if 0
                ParamVal * xOutVoiceCap = NULL;
                /* Get the length of the string */
                iLength = strlen(psTmpVal);
                int32 iaUrl[OID_LENGTH] = { 0, 0, 0, 0, OID_IGD_S_VS_C,
                    OID_IGD_S_VS_C_SIGNALINGPROTOCOLS
                };

                memset(&xInVoiceCap, 0x00, sizeof(ParamVal));

                /* Get Signalling Protcols capability from Voice Capability
                   module */
                memcpy(xInVoiceCap.iaOID, iaUrl, (OID_LENGTH * sizeof(int32)));
                memcpy(xInVoiceCap.iaOID, pxParamVal->iaOID,
                       ((VOICE_CAP_DEV_DEPTH + 1) * sizeof(int32)));

                // Get the value using global function

                iRet = IFX_GlobalGetVal(&xInVoiceCap, &xOutVoiceCap,
                                        &uiOutElem);
                if(iRet != IFX_CWMP_SUCCESS) {
                    IFX_PrintOID(xInVoiceCap.iaOID);
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d IFX_GlobalGetVal failed!\n", __func__,
                                __LINE__);
                }

                // printf("Value %s,%s\n",(char8
                // *)xOutVoiceCap->Value,psTmpVal);
                iRet =
                    IFX_SearchString((char8 *) xOutVoiceCap->Value, psTmpVal);

                // Free the members of xOutVoiceCap 
                iRtn = IFX_FreeParamvalArr(&xOutVoiceCap, uiOutElem);
                // printf("Return value of SigProto Free %d\n",iRtn);
                if(iRet != IFX_CWMP_SUCCESS) {
                    printf("----SIGPROTO FAILED---\n");
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    iRet = ERR_CWMP_INVAL_PARAM_VAL;
                    goto cleanup;
                }
                break;
#endif
            case OID_IGD_S_VS_VP_MAXSESSIONS:{
                    ParamVal *xOutVoiceCap1 = NULL;
                    int32 iaUrl1[OID_LENGTH] = { 0, 0, 0, 0, OID_IGD_S_VS_C,
                        OID_IGD_S_VS_C_MAXSESSIONCOUNT
                    };

                    memset(&xInVoiceCap, 0x00, sizeof(ParamVal));

                    /* Get MaxSessionCount capability from Voice Capability
                       module */
                    memcpy(xInVoiceCap.iaOID, iaUrl1,
                           (OID_LENGTH * sizeof(int32)));
                    memcpy(xInVoiceCap.iaOID, pxParamVal->iaOID,
                           ((VOICE_CAP_DEV_DEPTH + 1) * sizeof(int32)));

                    // Get the value using global function

                    iRet = IFX_GlobalGetVal(&xInVoiceCap, &xOutVoiceCap1,
                                            &uiOutElem);
                    if(iRet != IFX_CWMP_SUCCESS) {
                        IFX_PrintOID(xInVoiceCap.iaOID);
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d IFX_GlobalGetVal failed!\n",
                                    __func__, __LINE__);
                    }
                    if(xOutVoiceCap1!=NULL) {
                    	tmp1 = atoi(xOutVoiceCap1->Value);
		    }
                    tmp2 = atoi((pxParamVal[iCnt]).Value);
                    // Free the members of xOutVoiceCap 
                    IFX_FreeParamvalArr(&xOutVoiceCap1, uiOutElem);
                    if(tmp2 > tmp2) {
                        printf("----FAILED---\n");
                        (pxParamVal[iCnt]).iFaultCode =
                            ERR_CWMP_INVAL_PARAM_VAL;
                        iRet = ERR_CWMP_INVAL_PARAM_VAL;
                        goto cleanup;
                    }
                }
                break;
            case OID_IGD_S_VS_VP_REGION:
                /* Get the length of the string */
                iLength = strlen(psTmpVal);
                ParamVal *xOutVoiceCap2 = NULL;
                int32 iaUrl2[OID_LENGTH] = { 0, 0, 0, 0, OID_IGD_S_VS_C,
                    OID_IGD_S_VS_C_REGIONS
                };

                memset(&xInVoiceCap, 0x00, sizeof(ParamVal));

                /* Get Signalling Protcols capability from Voice Capability
                   module */
                memcpy(xInVoiceCap.iaOID, iaUrl2, (OID_LENGTH * sizeof(int32)));
                memcpy(xInVoiceCap.iaOID, pxParamVal->iaOID,
                       ((VOICE_CAP_DEV_DEPTH + 1) * sizeof(int32)));

                // Get the value using global function

                iRet = IFX_GlobalGetVal(&xInVoiceCap, &xOutVoiceCap2,
                                        &uiOutElem);
                if(iRet != IFX_CWMP_SUCCESS) {
                    IFX_PrintOID(xInVoiceCap.iaOID);
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d IFX_GlobalGetVal failed!\n", __func__,
                                __LINE__);
                }

                // printf("Region Value is %s \n",(char8
                // *)xOutVoiceCap2->Value);
                if(xOutVoiceCap2!=NULL)
                {
                    iRet =
                         IFX_SearchString((char8 *) xOutVoiceCap2->Value, psTmpVal);
                }
                // Free the members of xOutVoiceCap 
                iRtn = IFX_FreeParamvalArr(&xOutVoiceCap2, uiOutElem);
                // printf("Return value of Region Free %d\n",iRtn);
                if(iRet != IFX_CWMP_SUCCESS) {
                    // printf("----REGION FAILED---\n");
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    iRet = ERR_CWMP_INVAL_PARAM_VAL;
                    goto cleanup;
                }
                break;
            case OID_IGD_S_VS_VP_DIGITMAP:
                /* Get the length of the string */
                iLength = strlen(psTmpVal);
                ParamVal *xOutVoiceCap3 = NULL;
                int32 iaUrl3[OID_LENGTH] = { 0, 0, 0, 0, OID_IGD_S_VS_C,
                    OID_IGD_S_VS_C_DIGITMAP
                };

                memset(&xInVoiceCap, 0x00, sizeof(ParamVal));

                /* Get Signalling Protcols capability from Voice Capability
                   module */
                memcpy(xInVoiceCap.iaOID, iaUrl3, (OID_LENGTH * sizeof(int32)));
                memcpy(xInVoiceCap.iaOID, pxParamVal->iaOID,
                       ((VOICE_CAP_DEV_DEPTH + 1) * sizeof(int32)));

                // Get the value using global function

                iRet = IFX_GlobalGetVal(&xInVoiceCap, &xOutVoiceCap3,
                                        &uiOutElem);
                if(iRet != IFX_CWMP_SUCCESS) {
                    IFX_PrintOID(xInVoiceCap.iaOID);
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d IFX_GlobalGetVal failed!\n", __func__,
                                __LINE__);
                }

                // printf("DigitMap Value is %s \n",(char8
                // *)xOutVoiceCap3->Value);

                // Free the members of xOutVoiceCap 
                iRtn = IFX_FreeParamvalArr(&xOutVoiceCap3, uiOutElem);
#if 0
                if(strcmp(((char8 *) xOutVoiceCap3->Value), "false") == 0) {
                    printf("----DIGITMAP FAILED---\n");
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    iRet = ERR_CWMP_INVAL_PARAM_VAL;
                    goto cleanup;
                }
#endif
                break;
            case OID_IGD_S_VS_VP_FAXPASSTHROUGH:
                /* Get the length of the string */
                iLength = strlen(psTmpVal);
                ParamVal *xOutVoiceCap4 = NULL;
                int32 iaUrl4[OID_LENGTH] = { 0, 0, 0, 0, OID_IGD_S_VS_C,
                    OID_IGD_S_VS_C_FAXPASSTHROUGH
                };

                memset(&xInVoiceCap, 0x00, sizeof(ParamVal));

                /* Get FaxPassThrough capability from Voice Capability module */
                memcpy(xInVoiceCap.iaOID, iaUrl4, (OID_LENGTH * sizeof(int32)));
                memcpy(xInVoiceCap.iaOID, pxParamVal->iaOID,
                       ((VOICE_CAP_DEV_DEPTH + 1) * sizeof(int32)));

                // Get the value using global function

                iRet = IFX_GlobalGetVal(&xInVoiceCap, &xOutVoiceCap4,
                                        &uiOutElem);
                if(iRet != IFX_CWMP_SUCCESS) {
                    IFX_PrintOID(xInVoiceCap.iaOID);
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d IFX_GlobalGetVal failed!\n", __func__,
                                __LINE__);
                }

                // printf("FaxPassThrough is %s \n",(char8
                // *)xOutVoiceCap4->Value);

                // Free the members of xOutVoiceCap4 
                iRtn = IFX_FreeParamvalArr(&xOutVoiceCap4, uiOutElem);
                // printf("Return value of FaxPassThru Free %d\n",iRtn);
                if(iRet != IFX_CWMP_SUCCESS) {
                    // printf("----FAXPASSTHROUGH FAILED---\n");
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    iRet = ERR_CWMP_INVAL_PARAM_VAL;
                    goto cleanup;
                }
                break;
            case OID_IGD_S_VS_VP_MODEMPASSTHROUGH:
                /* Get the length of the string */
                iLength = strlen(psTmpVal);
                ParamVal *xOutVoiceCap5 = NULL;
                int32 iaUrl5[OID_LENGTH] = { 0, 0, 0, 0, OID_IGD_S_VS_C,
                    OID_IGD_S_VS_C_MODEMPASSTHROUGH
                };

                memset(&xInVoiceCap, 0x00, sizeof(ParamVal));

                /* Get ModemPassThrough capability from Voice Capability
                   module */
                memcpy(xInVoiceCap.iaOID, iaUrl5, (OID_LENGTH * sizeof(int32)));
                memcpy(xInVoiceCap.iaOID, pxParamVal->iaOID,
                       ((VOICE_CAP_DEV_DEPTH + 1) * sizeof(int32)));

                // Get the value using global function

                iRet = IFX_GlobalGetVal(&xInVoiceCap, &xOutVoiceCap5,
                                        &uiOutElem);
                if(iRet != IFX_CWMP_SUCCESS) {
                    IFX_PrintOID(xInVoiceCap.iaOID);
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d IFX_GlobalGetVal failed!\n", __func__,
                                __LINE__);
                }

                // printf("ModemPassThru is %s \n",(char8
                // *)xOutVoiceCap5->Value);

                // Free the members of xOutVoiceCap 
                iRtn = IFX_FreeParamvalArr(&xOutVoiceCap5, uiOutElem);
                // printf("Return value of ModemPassThru Free %d\n",iRtn);
                if(iRet != IFX_CWMP_SUCCESS) {
                    // printf("----MODEMPASSTHROUGH FAILED---\n");
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    iRet = ERR_CWMP_INVAL_PARAM_VAL;
                    goto cleanup;
                }
                break;
            case OID_IGD_S_VS_VP_ENABLE:
            case OID_IGD_S_VS_VP_RESET:
            case OID_IGD_S_VS_VP_NAME:
            case OID_IGD_S_VS_VP_DTMFMETHOD:
            case OID_IGD_S_VS_VP_DTMFMETHODG711:
            case OID_IGD_S_VS_VP_STUNENABLE:
            case OID_IGD_S_VS_VP_STUNSERVER:
                /* Not validating. just returtning success */
                break;
            case OID_IGD_S_VS_VP_NUMBEROFLINES:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_PARAM_NOT_SUPPORTED;
                iRet = ERR_CWMP_PARAM_NOT_SUPPORTED;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Parameter Not Supported\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

  cleanup:
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Validating dependency requested parameter failed\n",
                    __FILE__, __func__, __LINE__, iRet);
    }

    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : IFX_VoiceProfile_ChkDelDep
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_VoiceProfile_ChkDelDep(IN int32 iCaller, IN ParamVal * pxParamVal,
                           IN int32 iNumElem, OUT void **ppxParamStructRet,
                           OUT int32 * piNumRetElem)
{

    uint32 i = 0;
    int32 iRet = 0;
    uint32 uiParamPos = 0;
    ParamVal *Param_DepOids = NULL;
    x_IFX_VMAPI_VoiceService xVoiceServ;

	/*Code added so that acs can not delete profile if minimum number of profile are present*/
        memset(&xVoiceServ, 0, sizeof(xVoiceServ));
        /* Fill the iid structure in VOICE_LINE */
        xVoiceServ.iid.config_owner = IFX_TR69;

        iRet = ifx_get_VoiceService(&xVoiceServ, IFX_F_DEFAULT);
        if(iRet != IFX_CWMP_SUCCESS) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [Error] ifx_set_VoiceProfile adding failed\n",
                        __func__, __LINE__);
            return ERR_CWMP_INTERNAL;
        }

        if(xVoiceServ.uiNumProfiles == IFX_VMAPI_MIN_VOICE_PROFILES) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [Error] MIN Voice Profiles reached\n",
                        __func__, __LINE__);
            return ERR_CWMP_INTERNAL;
        }


    int32 prof_event_OID[OID_LENGTH] =
        { 0, 0, 0, 0, 0, 0, OID_IGD_S_VS_VP_SIP, OID_IGD_S_VS_VP_SIP_ES,
        MAGIC_NUMBER
    };
    int32 prof_signal_OID[OID_LENGTH] =
        { 0, 0, 0, 0, 0, 0, OID_IGD_S_VS_VP_SIP };
    int32 prof_serprovider_OID[OID_LENGTH] =
        { 0, 0, 0, 0, 0, 0, OID_IGD_S_VS_VP_SPI };
    int32 prof_rtcp_OID[OID_LENGTH] =
        { 0, 0, 0, 0, 0, 0, OID_IGD_S_VS_VP_RTP, OID_IGD_S_VS_VP_RTP_RTCP };
    int32 prof_rtp_OID[OID_LENGTH] = { 0, 0, 0, 0, 0, 0, OID_IGD_S_VS_VP_RTP };
    int32 prof_fax_OID[OID_LENGTH] = { 0, 0, 0, 0, 0, 0, OID_IGD_S_VS_VP_FT38 };

    Param_DepOids = IFIN_CWMP_MALLOC((PROF_NO_DEP_OIDS + 1) * sizeof(ParamVal));
    if(Param_DepOids == NULL) {
        iRet = ERR_OUT_OF_MEMORY;
        goto errorHandler;
    }

    // Get the WanIpConParamPos 
    uiParamPos = IFX_GetParamIdPos(pxParamVal->iaOID);

    memcpy((Param_DepOids + 0)->iaOID, prof_event_OID,
           (sizeof(int32) * OID_LENGTH));
    memcpy((Param_DepOids + 1)->iaOID, prof_signal_OID,
           (sizeof(int32) * OID_LENGTH));
    memcpy((Param_DepOids + 2)->iaOID, prof_serprovider_OID,
           (sizeof(int32) * OID_LENGTH));
    memcpy((Param_DepOids + 3)->iaOID, prof_rtcp_OID,
           (sizeof(int32) * OID_LENGTH));
    memcpy((Param_DepOids + 4)->iaOID, prof_rtp_OID,
           (sizeof(int32) * OID_LENGTH));
    memcpy((Param_DepOids + 5)->iaOID, prof_fax_OID,
           (sizeof(int32) * OID_LENGTH));
    memcpy((Param_DepOids + 6)->iaOID, pxParamVal->iaOID,
           (sizeof(int32) * (uiParamPos + 1)));

    for(i = 0; i < PROF_NO_DEP_OIDS; ++i)
        memcpy((Param_DepOids + i)->iaOID, pxParamVal->iaOID,
               (sizeof(int32) * (uiParamPos + 1)));
    *ppxParamStructRet = (void *)Param_DepOids;
    *piNumRetElem = PROF_NO_DEP_OIDS + 1;
    return IFIN_CWMP_SUCCESS;

  errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed!\n", __func__, __LINE__);

    return IFIN_CWMP_FAILURE;


}


/* 
** =============================================================================
**   Function Name    : IFX_VoiceProfile_AddDel
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_VoiceProfile_AddDel(IN int32 iCaller, IN ParamVal * pxParamVal,
                        IN int32 iNumElem, IN int32 operation)
{
    int32 iRet = IFIN_CWMP_SUCCESS;
    int32 iCnt = 0;
    char sOidString[IFX_MAX_TR69_ID_LEN];
    int32 iParamOffset;
    IFX_CpeId *pxCpeIdArray = NULL;
    unsigned int uiNumCpeId;
    unsigned int uiPCpeId;
    x_IFX_VMAPI_VoiceProfile xVoiceProfile;
    x_IFX_VMAPI_ProfileEventSubsTable xProfEvent1;
    x_IFX_VMAPI_VoiceService xVoiceServ;

    memset(sOidString, 0x00, IFX_MAX_TR69_ID_LEN);
    memset(&xVoiceProfile, 0, sizeof(xVoiceProfile));

    /* Get the Parent CPE Id */
    IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT & uiPCpeId);
    xVoiceProfile.iid.pcpeId.Id = uiPCpeId;

    /* if neither delete nor add operation */
    if((operation != OP_SETVAL_ADD) && (operation != OP_SETVAL_DELETE)) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [Error] Invalid operation\n", __func__, __LINE__);
        return ERR_CWMP_INTERNAL;
    }

    /* if delete operation */
    if(operation == OP_SETVAL_DELETE) {
        // get cpeid, pass to delete function
        // here the input iaOID will be igd.s.vs.1.vp.2.

        /* ignore the last value as it will be a parameter and we need only
           till the last instance */
        iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID, sOidString);

        iRet =
            IFX_GetCpeIdFromTr69Id(IN sOidString, OUT & uiNumCpeId,
                                   OUT & pxCpeIdArray);
        if(iRet != IFX_CWMP_SUCCESS) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                        __func__, __LINE__);

            return ERR_CWMP_INTERNAL;
        }

        /* Get the Cpe Id */
        xVoiceProfile.iid.cpeId.Id = pxCpeIdArray->uiId;

        memset(xVoiceProfile.iid.tr69Id, 0x00, MAX_TR69_ID_LEN);
        if(strlen(pxCpeIdArray->sSectionTag) < MAX_TAG_LEN) {
            strncpy(xVoiceProfile.iid.cpeId.secName, pxCpeIdArray->sSectionTag,
                    MAX_TAG_LEN - 1);
            IFX_CWMP_FREE(pxCpeIdArray);
        }
        else {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [Error] strcpy : mismatch in size in buffer copy\n",
                        __func__, __LINE__);
            IFX_CWMP_FREE(pxCpeIdArray);
            return ERR_CWMP_INTERNAL;
        }
        /* Get the Profile Id */
        xVoiceProfile.ucProfileId = IFX_GetProfileId(pxParamVal->iaOID);

        /* Fill the iid structure in VOICE_LINE */
        xVoiceProfile.iid.config_owner = IFX_TR69;

        strncpy(xVoiceProfile.iid.tr69Id, sOidString, MAX_TR69_ID_LEN-1);
	xVoiceProfile.iid.tr69Id[MAX_TR69_ID_LEN-1] = '\0';

        /* call the respective VMAPI */
        iRet = ifx_set_VoiceProfile(IFX_OP_DEL, &xVoiceProfile, IFX_F_DEFAULT);
        if(iRet != IFX_CWMP_SUCCESS) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [Error] ifx_set_VoiceProfile failed\n",
                        __func__, __LINE__);
            return ERR_CWMP_INTERNAL;
        }

        /* call the respective VMAPI for Profile Event */
        memset(&xProfEvent1, 0, sizeof(xProfEvent1));
        xProfEvent1.iid.pcpeId.Id = xVoiceProfile.iid.cpeId.Id;
        xProfEvent1.iid.cpeId.Id = xVoiceProfile.iid.cpeId.Id;
        xProfEvent1.ucProfileId = xVoiceProfile.ucProfileId;
        xProfEvent1.iid.config_owner = IFX_TR69;
        iRet =
            ifx_set_ProfileEventSubsTable(IFX_OP_DEL, &xProfEvent1,
                                          IFX_F_DEFAULT);
        if(iRet != IFX_CWMP_SUCCESS) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [Error] ifx_set_ProfileEventSubsTable failed\n",
                        __func__, __LINE__);
            return ERR_CWMP_INTERNAL;
        }

        return iRet;

    }                           // end of delete operation

    if(operation == OP_SETVAL_ADD) {    // if ADD
        // here the input iaOID will be igd.s.vs.1.vp.

        memset(&xVoiceServ, 0, sizeof(xVoiceServ));
        /* Fill the iid structure in VOICE_LINE */
        xVoiceServ.iid.config_owner = IFX_TR69;

        iRet = ifx_get_VoiceService(&xVoiceServ, IFX_F_DEFAULT);
        if(iRet != IFX_CWMP_SUCCESS) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [Error] ifx_set_VoiceProfile adding failed\n",
                        __func__, __LINE__);
            iRet = ERR_CWMP_INTERNAL;
            goto cleanup;
        }

        if(xVoiceServ.uiNumProfiles == IFX_VMAPI_MAX_VOICE_PROFILES) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [Error] MAX Voice Profiles reached\n",
                        __func__, __LINE__);
            iRet = ERR_CWMP_INTERNAL;
            goto cleanup;
        }

        /* ignore the last value as it will be a parameter and we need only
           till the last instance */
        iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID, sOidString);
        strncpy(xVoiceProfile.iid.tr69Id, sOidString, MAX_TR69_ID_LEN-1);
	xVoiceProfile.iid.tr69Id[MAX_TR69_ID_LEN-1] = '\0';

        /* Get the offset of the parameter */
        iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
        if (iParamOffset < 0)
        {
            iRet = ERR_CWMP_INTERNAL;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
            goto cleanup;
        }

        // fill the given parameters of this structure with the new values
        // provided
        for(iCnt = 0; iCnt < iNumElem; iCnt++) {

            /* Process based on the requested parameter */
            switch (pxParamVal[iCnt].iaOID[iParamOffset]) {
                case OID_IGD_S_VS_VP_ENABLE:
                    if(!strncasecmp(pxParamVal[iCnt].Value, "Disabled", 8))
                        xVoiceProfile.ucState = IFX_VMAPI_VL_STATE_DISABLED;
                    else if(!strncasecmp
                            (pxParamVal[iCnt].Value, "Quiescent", 9))
                        xVoiceProfile.ucState = IFX_VMAPI_VL_STATE_QUIESCENT;
                    else if(!strncasecmp(pxParamVal[iCnt].Value, "Enabled", 7))
                        xVoiceProfile.ucState = IFX_VMAPI_VL_STATE_ENABLED;

                    break;

                case OID_IGD_S_VS_VP_RESET:
                case OID_IGD_S_VS_VP_NUMBEROFLINES:
                case OID_IGD_S_VS_VP_NAME:
                case OID_IGD_S_VS_VP_SIGNALINGPROTOCOL:
                case OID_IGD_S_VS_VP_MAXSESSIONS:
                case OID_IGD_S_VS_VP_DTMFMETHOD:
                case OID_IGD_S_VS_VP_DTMFMETHODG711:
                case OID_IGD_S_VS_VP_REGION:
                case OID_IGD_S_VS_VP_DIGITMAP:
                case OID_IGD_S_VS_VP_DIGITMAPENABLE:
                case OID_IGD_S_VS_VP_STUNENABLE:
                case OID_IGD_S_VS_VP_STUNSERVER:
                case OID_IGD_S_VS_VP_FAXPASSTHROUGH:
                case OID_IGD_S_VS_VP_MODEMPASSTHROUGH:
                case OID_IGD_S_VS_VP_NONVOICEBANDWIDTHRESERVEDUPSTREAM:
                case OID_IGD_S_VS_VP_NONVOICEBANDWIDTHRESERVEDDOWNSTREAM:
                case OID_IGD_S_VS_VP_PSTNFAILOVER:
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] Unknown requested parameter %d\n",
                                __func__, __LINE__,
                                pxParamVal[iCnt].iaOID[iParamOffset]);
                    // parameter not found
                    pxParamVal[iCnt].iFaultCode = ERR_INVAL_PARAMETER_NAME;

                    goto cleanup;
            }
        }

        /* Fill the iid structure in VOICE_LINE */
        xVoiceProfile.iid.config_owner = IFX_TR69;

        // call the VMAPI to modify
        iRet = ifx_set_VoiceProfile(IFX_OP_ADD, &xVoiceProfile, IFX_F_DEFAULT);
        if(iRet != IFX_CWMP_SUCCESS) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [Error] ifx_set_VoiceProfile adding failed\n",
                        __func__, __LINE__);
            iRet = ERR_CWMP_INTERNAL;
            goto cleanup;
        }

        /* ProfileEventSubscriptionTable is not a TR104 object but this holds
           the number of Subscription happend and the list of all the events.
           So we need to add this section also in the config file. */

        /* Create the new instance of ProfileEventSubsTable */
        memset(&xProfEvent1, 0, sizeof(xProfEvent1));
        xProfEvent1.iid.pcpeId.Id = xVoiceProfile.iid.cpeId.Id;
        xProfEvent1.ucProfileId = xVoiceProfile.ucProfileId;
        xProfEvent1.iid.config_owner = IFX_TR69;

        xProfEvent1.ucNoOfSubscrElements = 0;
        iRet =
            ifx_set_ProfileEventSubsTable(IFX_OP_ADD, &xProfEvent1,
                                          IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);
        if(iRet != IFX_VMAPI_SUCCESS) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [Error] ifx_set_ProfileEventSubsTable adding failed\n",
                        __func__, __LINE__);
            iRet = ERR_CWMP_INTERNAL;
            goto cleanup;
        }


        return iRet;

    }                           // end of add operation

  cleanup:

    /* Perform Cleanup of unnecessary VoiceProfile members */

    return (iRet);

}

/* 
** =============================================================================
**   Function Name    : GetNotify
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
GetNotify(IN OperInfo * pxOI, INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32 iRtn = IFX_SUCCESS;
    int32 iCnt = 0;
    int32 iTmpCnt = -1;         /* Mandatory */
    int32 iParamOffset;
    int32 iOID;
    int32 iMemErrorFlag = 0;    /* Mandatory */
    x_IFX_VMAPI_VoiceProfile xVoiceProfile;

    /* NOTE: For all parameters fault code is set to success by default. If
       error in validating first parameter, fault code is set to the error type 
       and other parameters are not validated. */
    /* NOTE: For all parameters value is set to NULL by default. */

    /* Set the fault code to Success and value to NULL pointer for all
       parameters */
    for(iCnt = 0; iCnt < iElements; iCnt++) {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);

    memset(&xVoiceProfile, 0, sizeof(x_IFX_VMAPI_VoiceProfile));

    /* Process based on the object */
    switch (iOID) {
        case OID_IGD_S_VS_VP:{

                char8 sOidString[100] = { 0 };
                IFX_CpeId *pxCpeIdArray = NULL;
                unsigned int uiNumCpeId;

                xVoiceProfile.ucProfileId = IFX_GetProfileId(pxParamVal->iaOID);
                // printf("Profile Id is %d\n",xVoiceProfile.ucProfileId);

                /* ignore the last value as it will be a parameter and we need
                   only till the last instance */
                iRet =
                    IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID, sOidString);

                strcpy(xVoiceProfile.iid.tr69Id, sOidString);

                /* Get the CPE Id from the corresponding tr69 Id */
                iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT & uiNumCpeId,
                                              OUT & pxCpeIdArray);
                if(iRet != IFX_CWMP_SUCCESS) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                                __func__, __LINE__);

                    return ERR_CWMP_INTERNAL;
                }
                // printf("CPEID is %d\n",pxCpeIdArray->uiId); 

                /* Fill the CPE ID of the object instance */
                xVoiceProfile.iid.cpeId.Id = pxCpeIdArray->uiId;
                xVoiceProfile.iid.config_owner = IFX_TR69;

                /* Get all the VoiceProfile parameters using VMAPI */
                iRtn = ifx_get_VoiceProfile(&xVoiceProfile, IFX_F_DEFAULT);

                IFX_CWMP_FREE(pxCpeIdArray);

                /* Check for error */
                if(iRtn != IFX_SUCCESS) {
                    /* Set the fault code to Failure for all parameters */
                    for(iCnt = 0; iCnt < iElements; iCnt++) {
                        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                    }

                    iRet = IFX_CWMP_FAILURE;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Unable to get values of all "
                                "parameters\n", __FILE__, __func__, __LINE__,
                                iRet);
                    goto cleanup;
                }
            }
            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for(iCnt = 0; iCnt < iElements; iCnt++) {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset]) {
            case OID_IGD_S_VS_VP_ENABLE:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(10);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }


                /* Copy the value to allocated area */
                if(xVoiceProfile.ucState == IFX_VMAPI_VP_STATE_DISABLED)
                    strcpy((pxParamVal[iCnt]).Value, "Disabled");
                else if(xVoiceProfile.ucState == IFX_VMAPI_VP_STATE_QUIESCENT)
                    strcpy((pxParamVal[iCnt]).Value, "Quiscent");
                else if(xVoiceProfile.ucState == IFX_VMAPI_VP_STATE_ENABLED)
                    strcpy((pxParamVal[iCnt]).Value, "Enabled");

                iRet =
                    IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                             IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if(iRet != IFX_CWMP_SUCCESS) {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;
            case OID_IGD_S_VS_VP_RESET:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                if(xVoiceProfile.bReset == IFX_TR104_FALSE)
                    strcpy((pxParamVal[iCnt]).Value, "false");
                else if(xVoiceProfile.bReset == IFX_TR104_TRUE)
                    strcpy((pxParamVal[iCnt]).Value, "true");
                iRet =
                    IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                             IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if(iRet != IFX_CWMP_SUCCESS) {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;
            case OID_IGD_S_VS_VP_NUMBEROFLINES:

                (pxParamVal[iCnt]).Value =
                    (void *)IFX_CWMP_MALLOC(sizeof(uchar8));

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }


                /* Copy the value to allocated area */
                sprintf((pxParamVal[iCnt]).Value, "%d",
                        xVoiceProfile.ucNoOfLines);

                iRet =
                    IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                             IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if(iRet != IFX_CWMP_SUCCESS) {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;
            case OID_IGD_S_VS_VP_NAME:

                (pxParamVal[iCnt]).Value =
                    (void *)
                    IFX_CWMP_MALLOC(sizeof(xVoiceProfile.acProfileName));

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xVoiceProfile.acProfileName);

                iRet =
                    IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                             IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if(iRet != IFX_CWMP_SUCCESS) {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;
            case OID_IGD_S_VS_VP_SIGNALINGPROTOCOL:

                (pxParamVal[iCnt]).Value =
                    (void *)IFX_CWMP_MALLOC(sizeof(IFX_VMAPI_SIG_PROTOCOL));

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, IFX_VMAPI_SIG_PROTOCOL);

                iRet =
                    IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                             IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if(iRet != IFX_CWMP_SUCCESS) {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;
            case OID_IGD_S_VS_VP_MAXSESSIONS:

                (pxParamVal[iCnt]).Value =
                    (void *)IFX_CWMP_MALLOC(sizeof(IFX_VMAPI_VP_MAX_SESSIONS));

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                /* Copy the value to allocated area */
                sprintf((pxParamVal[iCnt]).Value, "%d",
                        IFX_VMAPI_VP_MAX_SESSIONS);

                iRet =
                    IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                             IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if(iRet != IFX_CWMP_SUCCESS) {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;
            case OID_IGD_S_VS_VP_DTMFMETHOD:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(8);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                if(xVoiceProfile.ucDtmfMethod == IFX_VMAPI_VP_DTMF_MTHD_INBAND)
                    strcpy((pxParamVal[iCnt]).Value, "InBand");
                else if(xVoiceProfile.ucDtmfMethod ==
                        IFX_VMAPI_VP_DTMF_MTHD_RFC2833)
                    strcpy((pxParamVal[iCnt]).Value, "RFC2833");
                if(xVoiceProfile.ucDtmfMethod == IFX_VMAPI_VP_DTMF_MTHD_INFO)
                    strcpy((pxParamVal[iCnt]).Value, "SIPInfo");

                iRet =
                    IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                             IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if(iRet != IFX_CWMP_SUCCESS) {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;
            case OID_IGD_S_VS_VP_DTMFMETHODG711:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(8);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                if(xVoiceProfile.ucG711DtmfMethod ==
                   IFX_VMAPI_VP_DTMF_MTHD_INBAND)
                    strcpy((pxParamVal[iCnt]).Value, "InBand");
                else if(xVoiceProfile.ucG711DtmfMethod ==
                        IFX_VMAPI_VP_DTMF_MTHD_RFC2833)
                    strcpy((pxParamVal[iCnt]).Value, "RFC2833");
                if(xVoiceProfile.ucG711DtmfMethod ==
                   IFX_VMAPI_VP_DTMF_MTHD_INFO)
                    strcpy((pxParamVal[iCnt]).Value, "SIPInfo");

                iRet =
                    IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                             IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if(iRet != IFX_CWMP_SUCCESS) {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;
            case OID_IGD_S_VS_VP_REGION:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(2);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                if(xVoiceProfile.uiAssocCountry == IFX_VMAPI_COUNTRY_USA)
                    strcpy((pxParamVal[iCnt]).Value,
                           IFX_VMAPI_COUNTRY_NAME_USA);
                if(xVoiceProfile.uiAssocCountry == IFX_VMAPI_COUNTRY_GERMANY)
                    strcpy((pxParamVal[iCnt]).Value,
                           IFX_VMAPI_COUNTRY_NAME_GERMANY);
                if(xVoiceProfile.uiAssocCountry == IFX_VMAPI_COUNTRY_CHINA)
                    strcpy((pxParamVal[iCnt]).Value,
                           IFX_VMAPI_COUNTRY_NAME_CHINA);
                if(xVoiceProfile.uiAssocCountry == IFX_VMAPI_COUNTRY_TAIWAN)
                    strcpy((pxParamVal[iCnt]).Value,
                           IFX_VMAPI_COUNTRY_NAME_TAIWAN);
                if(xVoiceProfile.uiAssocCountry == IFX_VMAPI_COUNTRY_INDIA)
                    strcpy((pxParamVal[iCnt]).Value,
                           IFX_VMAPI_COUNTRY_NAME_INDIA);
                if(xVoiceProfile.uiAssocCountry == IFX_VMAPI_COUNTRY_JAPAN)
                    strcpy((pxParamVal[iCnt]).Value,
                           IFX_VMAPI_COUNTRY_NAME_JAPAN);

                iRet =
                    IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                             IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if(iRet != IFX_CWMP_SUCCESS) {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;
            case OID_IGD_S_VS_VP_DIGITMAP:

                (pxParamVal[iCnt]).Value =
                    (void *)IFX_CWMP_MALLOC(sizeof(xVoiceProfile.acDigitMap));

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xVoiceProfile.acDigitMap);

                iRet =
                    IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                             IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if(iRet != IFX_CWMP_SUCCESS) {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;
            case OID_IGD_S_VS_VP_DIGITMAPENABLE:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }


                /* Copy the value to allocated area */
                if(xVoiceProfile.bEnableDigitMap == IFX_TR104_FALSE)
                    strcpy((pxParamVal[iCnt]).Value, "false");
                else if(xVoiceProfile.bEnableDigitMap == IFX_TR104_TRUE)
                    strcpy((pxParamVal[iCnt]).Value, "true");
                iRet =
                    IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                             IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if(iRet != IFX_CWMP_SUCCESS) {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;
            case OID_IGD_S_VS_VP_STUNENABLE:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                if(xVoiceProfile.bEnableStun == IFX_TR104_FALSE)
                    strcpy((pxParamVal[iCnt]).Value, "false");
                else if(xVoiceProfile.bEnableStun == IFX_TR104_TRUE)
                    strcpy((pxParamVal[iCnt]).Value, "true");
                iRet =
                    IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                             IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if(iRet != IFX_CWMP_SUCCESS) {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;

            case OID_IGD_S_VS_VP_STUNSERVER:

                (pxParamVal[iCnt]).Value =
                    (void *)
                    IFX_CWMP_MALLOC(sizeof
                                    (xVoiceProfile.xStunConfig.acStunServer));

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value,
                       xVoiceProfile.xStunConfig.acStunServer);

                iRet =
                    IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                             IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if(iRet != IFX_CWMP_SUCCESS) {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                iRet =
                    IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                             IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if(iRet != IFX_CWMP_SUCCESS) {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;
            case OID_IGD_S_VS_VP_NONVOICEBANDWIDTHRESERVEDUPSTREAM:

                (pxParamVal[iCnt]).Value =
                    (void *)
                    IFX_CWMP_MALLOC(sizeof(xVoiceProfile.uiDataResUpBandwidth));

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                sprintf((pxParamVal[iCnt]).Value, "%d",
                        xVoiceProfile.uiDataResUpBandwidth);

                iRet =
                    IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                             IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if(iRet != IFX_CWMP_SUCCESS) {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;
            case OID_IGD_S_VS_VP_NONVOICEBANDWIDTHRESERVEDDOWNSTREAM:

                (pxParamVal[iCnt]).Value =
                    (void *)
                    IFX_CWMP_MALLOC(sizeof
                                    (xVoiceProfile.uiDataResDownBandwidth));

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                sprintf((pxParamVal[iCnt]).Value, "%d",
                        xVoiceProfile.uiDataResDownBandwidth);

                iRet =
                    IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                             IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if(iRet != IFX_CWMP_SUCCESS) {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;
            case OID_IGD_S_VS_VP_PSTNFAILOVER:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(6);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }


                /* Copy the value to allocated area */
                if(xVoiceProfile.bPstnFailOver == IFX_TR104_FALSE)
                    strcpy((pxParamVal[iCnt]).Value, "false");
                else if(xVoiceProfile.bPstnFailOver == IFX_TR104_TRUE)
                    strcpy((pxParamVal[iCnt]).Value, "true");
                iRet =
                    IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                             IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if(iRet != IFX_CWMP_SUCCESS) {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;
            case OID_IGD_S_VS_VP_FAXPASSTHROUGH:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(8);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                if(xVoiceProfile.bFaxPassThru == IFX_TR104_FALSE)
                    strcpy((pxParamVal[iCnt]).Value, "false");
                else if(xVoiceProfile.bFaxPassThru == IFX_TR104_TRUE)
                    strcpy((pxParamVal[iCnt]).Value, "true");

                iRet =
                    IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                             IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if(iRet != IFX_CWMP_SUCCESS) {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;
            case OID_IGD_S_VS_VP_MODEMPASSTHROUGH:

                (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(8);

                /* Check for error */
                if(!((pxParamVal[iCnt]).Value)) {
                    /* Set the memory error flag */
                    iMemErrorFlag = 1;
                    iTmpCnt = iCnt;
                    goto cleanup;
                }

                /* Copy the value to allocated area */
                if(xVoiceProfile.bModemPassThru == IFX_TR104_FALSE)
                    strcpy((pxParamVal[iCnt]).Value, "false");
                else if(xVoiceProfile.bModemPassThru == IFX_TR104_TRUE)
                    strcpy((pxParamVal[iCnt]).Value, "true");

                iRet =
                    IFX_CheckValueGotChanged(pxOI, pxParamVal + iCnt,
                                             IFX_CHK_CHANGE_FLAG_BASED);

                /* Check for error */
                if(iRet != IFX_CWMP_SUCCESS) {
                    iTmpCnt = iCnt;
                    goto cleanup;
                }
                break;
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                iTmpCnt = iCnt;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
                goto cleanup;
        }
    }

  cleanup:

    if(iMemErrorFlag) {
        (pxParamVal[iCnt]).iFaultCode = ERR_OUT_OF_MEMORY;
        iRet = ERR_OUT_OF_MEMORY;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Allocation Failure\n",
                    __FILE__, __func__, __LINE__, iRet);
    }

    if(iRet != IFX_CWMP_SUCCESS) {

        /* Free the allocation for value, if any. Also set the fault code. */
        for(iCnt = 0; iCnt < iElements; iCnt++) {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
            if(iTmpCnt != iCnt) {
                (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
            }
        }
    }

    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : SetAttrInfo
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
SetAttrInfo(IN OperInfo * pxOI, INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32 iRet, i;
    iRet = IFX_SetAttributesInfo(pxOI, pxParamVal, iElements);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    for(i = 0; i < iElements; i++)
        IFX_CWMP_FREE(pxParamVal->Value);

    return IFX_CWMP_SUCCESS;

  errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed!\n", __func__, __LINE__);
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_VoiceProfile_UpdateChildInfo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
IFX_VoiceProfile_UpdateChildInfo(IN OperInfo * pxOpInfo,
                                 INOUT ParamVal * pxParamVal,
                                 IN int32 iElements, IN int32 operation)
{
    return IFX_CWMP_SUCCESS;
    int32 iRtn = IFX_SUCCESS;
    uint32 i, iRet, iCnt;
    // char8 sSecTag[MAX_SECTIONTAG];
    // char8 sParamTag[MAX_PARAMTAG];
    uint32 uiParamPos, uiChildObjId;
    uint32 uiCpeid;
    int32 *iaOID = NULL;
    int32 iOID;
    // uint32 uiNumNV=1;
    // IFX_CpeId pxCpeId;
    // IFX_Id xIfx_Id;
    // uint32 uiOper=IFX_NOTIFY_OPER_MODIFY;
    // uint32 uiMode=IFX_CHK_FLAG_BASED;
    ParamVal *pxTempParamVal = pxParamVal;
    x_IFX_VMAPI_VoiceProfile xVoiceProfile;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                "[%s:%d] \n", __func__, __LINE__);
    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);

    memset(&xVoiceProfile, 0, sizeof(x_IFX_VMAPI_VoiceProfile));

    /* Process based on the object */
    switch (iOID) {
        case OID_IGD_S_VS_VP:{

                char8 sOidString[100] = { 0 };
                IFX_CpeId *pxCpeIdArray = NULL;
                unsigned int uiNumCpeId;

                xVoiceProfile.ucProfileId = IFX_GetProfileId(pxParamVal->iaOID);

                /* ignore the last value as it will be a parameter and we need
                   only till the last instance */
                iRet =
                    IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID, sOidString);

                strcpy(xVoiceProfile.iid.tr69Id, sOidString);

                /* Get the CPE Id from the corresponding tr69 Id */
                iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT & uiNumCpeId,
                                              OUT & pxCpeIdArray);
                if(iRet != IFX_CWMP_SUCCESS) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                                __func__, __LINE__);

                    return ERR_CWMP_INTERNAL;
                }

                /* Fill the CPE ID of the object instance */
                xVoiceProfile.iid.cpeId.Id = pxCpeIdArray->uiId;

                /* Get all the VoiceProfile parameters using VMAPI */
                iRtn = ifx_get_VoiceProfile(&xVoiceProfile, IFX_F_DEFAULT);

                IFX_CWMP_FREE(pxCpeIdArray);

                /* Check for error */
                if(iRtn != IFX_CWMP_SUCCESS) {
                    /* Set the fault code to Failure for all parameters */
                    for(iCnt = 0; iCnt < iElements; iCnt++) {
                        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                    }

                    iRet = IFX_CWMP_FAILURE;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Unable to get values of all "
                                "parameters\n", __FILE__, __func__, __LINE__,
                                iRet);
                    // goto cleanup;
                    goto errorHandler;
                }
            }
            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            // goto cleanup;
            goto errorHandler;
    }

    /* Get Cpeid */
    iRet = IFX_GetCpeId(pxTempParamVal->iaOID, &uiCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
        goto errorHandler;

    // Get the offset of child object 
    uiChildObjId = IFX_GetParamOID((int32 *) pxTempParamVal->pReserved);
    iaOID = (int32 *) pxTempParamVal->pReserved;

    for(i = 0; i < iElements; i++) {
        // Get the Param Oid of this object
        uiParamPos = IFX_GetParamOID(pxTempParamVal->iaOID);

        if(pxTempParamVal->iaOID[uiParamPos] == OID_IGD_S_VS_VP_NUMBEROFLINES) {
#if 0
            // if(iaOID[uiChildObjId-1] == OID_IGD_S_VS_VP_L)
            // {
            // Get the section and Paramtag
            iRet = IFX_GetSectionParamTag(pxTempParamVal->psRCTag, sParamTag,
                                          sSecTag);
            if(iRet != IFX_CWMP_SUCCESS)
                goto errorHandler;

            xIfx_Id.uiConfigOwner = pxOpInfo->iCaller;
            xIfx_Id.xCpeId.uiId = uiCpeid;
            // xIfx_Id.xCpeId.uiId= pxCpeIdArray;
            strcpy(xIfx_Id.xCpeId.sSectionTag, sSecTag);
            strcpy(pxNVArray.sName, sParamTag);

            iRet = IFX_SendNotify(&xIfx_Id, uiNumNV, &pxNVArray, uiOper);
            if(iRet != IFX_CWMP_SUCCESS) {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d IFX_SendNotify failed!\n", __func__,
                            __LINE__);

                goto errorHandler;
            }
#endif
            if(operation == OP_SETVAL_ADD) {
                xVoiceProfile.ucNoOfLines += 1;
            }
            else
                xVoiceProfile.ucNoOfLines -= 1;
            // }
        }

        pxTempParamVal++;

    }
#if 1
    /* Process based on the object */
    switch (iOID) {
        case OID_IGD_S_VS_VP:

            /* Fill the iid structure in VOICE_PROFILE */
            xVoiceProfile.iid.config_owner = IFX_TR69;
            xVoiceProfile.ucProfileId = 1;
            xVoiceProfile.iid.cpeId.Id = 1;
            /* Get the Parent CPE Id */
            xVoiceProfile.iid.pcpeId.Id = 1;
            // xVoiceProfile.ucNoOfLines = 2;
            /* Set all the VOICE_PROFILE parameters using VMAPI */
            iRtn = ifx_set_VoiceProfile(IFX_OP_MOD, &xVoiceProfile, 0);

            /* Check for error */
            if(iRtn != IFX_SUCCESS) {
                /* Set the fault code to Failure for all parameters */
                for(iCnt = 0; iCnt < iElements; iCnt++) {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to set values of all "
                            "parameters in UpdateChildInfo\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto errorHandler;
            }

            break;
        default:
            /* Will never come here since already checked above */
            break;
    }
#endif
    return IFX_CWMP_SUCCESS;

  errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d failed!\n", __func__, __LINE__);

    return IFX_CWMP_FAILURE;

}


/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : IFX_VoiceProfile_Init
**
**   Description      : This function is called by the controller. It registers
**                      the function responsible for handling VoiceProfile 
**                      object with data structure. It also performs 
**                      initializations specific to VoiceProfile object.
**
**   Parameters       : No Parameters. 
**
**   Return Value     : IFX_CWMP_SUCCESS - If VoiceProfile object is initialized
**                      successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in initializing VoiceProfile object.
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_VoiceProfile_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the VoiceProfile module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_VOICEPROFILE_OBJ, IFX_VoiceProfileCfg);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_VOICEPROFILE_OBJ);
        goto cleanup;
    }

  cleanup:
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_VoiceProfileCfg
**
**   Description      : This function is called by the controller. It handles
**                      the VoiceProfile object and performs based on requested
**                      operations/suboperations by invoking internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_VoiceProfileCfg(IN OperInfo * pxOI, INOUT void *pParamList,
                    IN int32 iNumElem, OUT void **ppRet,
                    OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *pxParamVal = (ParamVal *) pParamList;


    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                "[%s:%d] \n", __func__, __LINE__);

    /* Process based on type of Operation */
    switch (pxOI->iOper) {
        case OP_GETVAL:
            /* Process based on type of SubOperation */
            switch (pxOI->iSubOper) {
                case OP_GETVAL_NORMAL:

                    /* Get values of all the requested parameters */
                    iRet = GetVal(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS) {
                        goto cleanup;
                    }

                    break;
                case OP_GETVAL_NOTIFICATION:

                    /* Set attribute values for all the requested parameters */
                    iRet = GetNotify(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS) {
                        goto cleanup;
                    }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_SETVAL:
            /* Process based on type of SubOperation */
            switch (pxOI->iSubOper) {
                case OP_SETVAL_VALIDATE:

                    /* Validate values of all the requested parameters */
                    iRet = Validate(pxParamVal, iNumElem);

                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS) {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:

                    /* Check modify dependency of all requested parameters */
                    iRet = GetModifyDep(pxParamVal, iNumElem);

                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS) {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_MODIFY:

                    /* Set values of all the requested parameters */
                    iRet = Modify(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS) {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ATTRINFO:

                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if(iRet != IFX_CWMP_SUCCESS) {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_ADD:
                    iRet = IFX_VoiceProfile_AddDel(pxOI->iCaller, pxParamVal, iNumElem, OP_SETVAL_ADD); // 1 
                                                                                                        // = 
                                                                                                        // add 
                                                                                                        // 0=del

                    /* Check for error */
                    if(iRet != IFIN_CWMP_SUCCESS) {
                        goto cleanup;
                    }
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                    iRet = IFX_VoiceProfile_ChkDelDep(pxOI->iCaller, pxParamVal,
                                                      iNumElem, ppRet,
                                                      piNumRetElem);

                    /* Check for error */
                    if(iRet != IFIN_CWMP_SUCCESS) {
                        goto cleanup;
                    }

                    // *ppRet = (ParamVal *)IFX_CWMP_MALLOC(sizeof(ParamVal));
                    // memcpy(*ppRet, pParamList, sizeof(ParamVal));
                    // *piNumRetElem = 1;
                    // return IFX_CWMP_SUCCESS;

                    break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    return IFX_CWMP_SUCCESS;

                    break;
                case OP_SETVAL_DELETE:
                    iRet = IFX_VoiceProfile_AddDel(pxOI->iCaller, pxParamVal, iNumElem, OP_SETVAL_DELETE);      // 1 
                                                                                                                // = 
                                                                                                                // add 
                                                                                                                // 0=del

                    /* Check for error */
                    if(iRet != IFIN_CWMP_SUCCESS) {
                        goto cleanup;
                    }
                    break;
                case OP_SETVAL_FREE:
                    return IFX_CWMP_SUCCESS;

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_UPDATE_CHILDINFO:
            /* Process based on type of SubOperation */
            switch (pxOI->iSubOper) {
                case OP_UPDATE_CHILDINFO_ADD:
                    if((iRet =
                        IFX_VoiceProfile_UpdateChildInfo(pxOI, pxParamVal,
                                                         iNumElem,
                                                         OP_SETVAL_ADD)) !=
                       IFX_CWMP_SUCCESS) {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d OP_UPDATE_CHILDINFO_ADD failed!\n",
                                    __func__, __LINE__);
                        goto cleanup;

                    }
                    break;
                case OP_UPDATE_CHILDINFO_DEL:
                    if((iRet =
                        IFX_VoiceProfile_UpdateChildInfo(pxOI, pxParamVal,
                                                         iNumElem,
                                                         OP_SETVAL_DELETE)) !=
                       IFX_CWMP_SUCCESS) {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d OP_UPDATE_CHILDINFO_DEL failed!\n",
                                    __func__, __LINE__);
                        goto cleanup;

                    }
                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid Operation\n",
                        __func__, __LINE__, iRet);
            goto cleanup;
    }

  cleanup:
    return (iRet);
}
