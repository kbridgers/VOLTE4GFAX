/*
** =============================================================================
** FILE NAME   : IFX_DEVM_NSLookupDiags.c
** PROJECT     : TR69
** MODULES     : (InternetGateway) Device.NSLookupDiagnostics.
** DATE        :
** AUTHOR      : TR69 team
** DESCRIPTION : AddObject / DeleteObject cannot be performed on this object.
**
** REFERENCES  :
** COPYRIGHT   : Copyright (c) 2006
**               Infineon Technologies AG
**               Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY     :
** $Date       $Author        $Comment
**             TR69 team      Creation
** =============================================================================
*/

#include "IFX_DEVM_Global.h"

#include "IFX_DEVM_AdaptCommon.h"


#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_StackUtil.h"
#include <resolv.h>
#include <pthread.h>


#include<time.h>
#include<stdlib.h>
#include<sys/time.h>

extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char *obj, modFunc pifx_module_func);
extern int32 IFX_ContAddObj(IN int32 iCaller, IN char8 * psObj);
extern int32 IFX_ContDelObj(IN int32 iCaller, IN char8 * psObj,
                            IN int32 iSession);

#ifndef DEVICE_SUPPORT
#define NSLOOKUPDIAG_OBJ                     FORMNAME("NSLookupDiagnostics.")
#define RESULT_OBJ                           FORMNAME("NSLookupDiagnostics.Result.")
#define NSLOOKUPDIAG_DEPTH                       3
#endif // DEVICE_SUPPORT

#ifdef DEVICE_SUPPORT
#define NSLOOKUPDIAG_OBJ                     FORMNAME("LAN.NSLookupDiagnostics.")
#define NSLOOKUPDIAG_DEPTH                   4
#endif // DEVICE_SUPPORT

#define MAX_NUM_LEN          12
#define LINESIZE             256

pthread_mutex_t nsl_msg_mutex = PTHREAD_MUTEX_INITIALIZER;

typedef struct {
    char8 caDiagState[MAX_DIAGSTATE_LEN];
    int32 iResponseTime;
    int32 iResultNumberOfSuccess;
    RESULT *pxResult;
} NSLookupResp;

/*******************************************************************************
* Function: IFX_NSLookupDiagSetAttrInfo
* Desc: Sets attribute information in the respective tr69 sections
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_NSLookupDiagSetAttrInfo(IN int32 iCaller, INOUT ParamVal * pxPV,
                            IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    iRet = IFX_SetAttributesInfo(NULL, pxPV, iElements);

    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Updating Param Attribute Info failed\n",
                    _FUNCL_, iRet);
        goto errorHandler;
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_NSLookupDiagGetNotifyValue
* Desc: gets valure from the config file and returns
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_NSLookupDiagGetNotifyValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                               IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    NSLOOKUP_DIAG xNSLookup;
    char8 caTmp[64] = { 0 };

    memset(&xNSLookup, '\0', sizeof(xNSLookup));
    iRet = ifx_get_nslookup_diag(&xNSLookup);

    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_nslookup_diag() failed\n", _FUNCL_,
                    iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
    for(iI = 0; iI < iElements; iI++) {
        pxPV[iI].Value = IFX_CWMP_MALLOC(257);
        if(pxPV[iI].Value == NULL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", _FUNCL_);
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }
        switch (pxPV[iI].iaOID[NSLOOKUPDIAG_DEPTH - 1]) {
            case OID_IGD_NSLD_DIAGNOSTICSSTATE:
                strcpy(pxPV[iI].Value, xNSLookup.diag_state);
                break;
            case OID_IGD_NSLD_INTERFACE:
                strcpy(pxPV[iI].Value, xNSLookup.interface);
                break;
            case OID_IGD_NSLD_HOSTNAME:
                strcpy(pxPV[iI].Value, xNSLookup.hostname);
                break;
            case OID_IGD_NSLD_DNSSERVER:
                strcpy(caTmp, xNSLookup.dnsserver);
                strcpy(pxPV[iI].Value, caTmp);
                break;
            case OID_IGD_NSLD_TIMEOUT:
                sprintf(caTmp, "%d", xNSLookup.timeout);
                strcpy(pxPV[iI].Value, caTmp);
                break;
            case OID_IGD_NSLD_NUMBEROFREPETITIONS:
                sprintf(caTmp, "%d", xNSLookup.num_repetitions);
                strcpy(pxPV[iI].Value, caTmp);
                break;
            case OID_IGD_NSLD_SUCCESSCOUNT:
                sprintf(caTmp, "%d", xNSLookup.success_count);
                strcpy(pxPV[iI].Value, caTmp);
                break;
            case OID_IGD_NSLD_RESULTNUMBEROFENTRIES:
                sprintf(caTmp, "%d", xNSLookup.result_num_entries);
                strcpy(pxPV[iI].Value, caTmp);
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", _FUNCL_,
                            pxPV[iI].iaOID[NSLOOKUPDIAG_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_NSLookupValidateInterface
* Desc: Validates the psInterface parameter passed. Is Successful, psIPAddr
*       will contain the IPAddress of the interface (Depending on being a
*       WANDevice or LANDevice). psIPAddr should be allocated by the caller of
*       this function.
* Parameters: IN char8 * psInterface, OUT char8 * psIPAddr
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_NSLookupValidateInterface(IN char8 * psInterface, OUT char8 * psIPAddr)
{
    int32 iRet = IFX_CWMP_SUCCESS;


/*      if(psInterface == NULL)
        {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "%s:%d NULL interface name\n", _FUNCL_);
                goto errorHandler;
        }

        if (strstr(psInterface, "WANDevice"))
        {
        }
        else if (strstr(psInterface, "LANDevice"))
        {
        }
        else
        {
                iRet = IFX_CWMP_FAILURE;
                goto errorHandler;
        }

errorHandler:*/
    return iRet;
}

/*******************************************************************************
* Function: IFX_NSLookupDiagValidate
* Desc:
*
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_NSLookupDiagValidate(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0, iTmp = 0;
    char8 sIPAddr[64] = { 0 };


    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[NSLOOKUPDIAG_DEPTH - 1]) {
            case OID_IGD_NSLD_INTERFACE:

                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "Entered case OID_IGD_NSLD_INTERFACE:\n");

                iTmp = strlen(pxPV[iI].Value);
                if(iTmp > MAX_IF_NAME) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d Interface len %d > %d (max)\n", _FUNCL_,
                                iTmp, MAX_IF_NAME);
                    iRet = ERR_CWMP_INVAL_PARAM_VAL;
                    goto errorHandler;
                }
                if(iTmp == 0) {
                    /* A NULL interface value is a valid value, use the routing
                       table */
                }
                else {

                    iRet =
                        IFX_NSLookupValidateInterface(pxPV[iI].Value, sIPAddr);
                    if(iRet != IFX_CWMP_SUCCESS) {

                        iRet = ERR_CWMP_INVAL_ARGS;
                        pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "IFX_NSLookupValidateInterface FAILED\n");
                        goto errorHandler;
                    }
                }
                break;
            case OID_IGD_NSLD_HOSTNAME:

                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "Entered case OID_IGD_NSLD_HOSTNAME:\n");

                iTmp = strlen(pxPV[iI].Value);
                if((iTmp > MAX_HOST_NAME) || (iTmp < 3)) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d Host len: %d \n", _FUNCL_, iTmp);
                    iRet = ERR_CWMP_INVAL_ARGS;
                    pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    goto errorHandler;
                }
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", _FUNCL_,
                            pxPV[iI].iaOID[NSLOOKUPDIAG_DEPTH - 1]);
                goto errorHandler;
        }
    }
  errorHandler:
    return iRet;
}


/*******************************************************************************
* Function: IFX_NSLookupDiagSetValue
* Desc:
*
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_NSLookupDiagSetValue(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0, iActivate = 0;
    NSLOOKUP_DIAG xNSLookup;
    ParamVal xGetParam;
    ParamVal *paxGetParamVal = NULL;
    char8 caInterface[CWMP_MAX_OBJ_LEN] = { 0 };
    char sIfName[150] = { 0 };
    uint32 iElemOut;
    int32 wan_type = 0;

    memset(&xNSLookup, '\0', sizeof(xNSLookup));
    iRet = ifx_get_nslookup_diag(&xNSLookup);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_nslookup_diag() failed\n", _FUNCL_,
                    iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[NSLOOKUPDIAG_DEPTH - 1]) {

            case OID_IGD_NSLD_DIAGNOSTICSSTATE:
                strncpy(xNSLookup.diag_state, pxPV[iI].Value,
                        MAX_DIAGSTATE_LEN);
                if(strcmp(pxPV[iI].Value, "Requested") == 0)
                    iActivate = IFX_CWMP_NEED_ACTIVATE;
                break;
            case OID_IGD_NSLD_INTERFACE:
#if 0
                strncpy(xNSLookup.interface, pxPV[iI].Value, MAX_IF_NAME);
#else
                if(!strcmp(pxPV[iI].Value, "")) {
                    xNSLookup.interface[0] = '\0';
                }
                else if(!strcmp
                        (pxPV[iI].Value,
                         "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.IPInterface.1"))
                {
//                    strcpy(xNSLookup.interface, "br0");
                }
                else {
                    memset(&xGetParam, 0x00, sizeof(xGetParam));
                    xGetParam.Name =
                        IFX_CWMP_MALLOC(strlen(pxPV[iI].Value) + 8);
                    if(xGetParam.Name == NULL) {
                        iRet = IFX_CWMP_FAILURE;
                        goto errorHandler;
                    }

                    memset(caInterface, 0, sizeof(caInterface));
                    strcpy(caInterface, pxPV[iI].Value);
                    if(caInterface[strlen(caInterface) - 1] != '.') {
                        strcat(caInterface, ".");
                    }

                    sprintf(xGetParam.Name, "%s%s", (char *)caInterface,
                            "Name");

                    iRet =
                        IFX_GlobalGetVal(&xGetParam, &paxGetParamVal,
                                         (uint32 *) & iElemOut);
                    if(iRet != IFX_CWMP_SUCCESS) {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                                    "[%s] [%d]  IFX_GlobalGetVal failed\n",
                                    __func__, __LINE__);
                        IFX_CWMP_FREE(xGetParam.Name);
                        if(paxGetParamVal != NULL) {
                            IFX_CWMP_FREE(paxGetParamVal->Value);
                            IFX_CWMP_FREE(paxGetParamVal->Name);
                        }
                        IFX_CWMP_FREE(paxGetParamVal);
                        pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        goto errorHandler;
                    }
                    if(strstr(paxGetParamVal->Value, "WANPPP") != NULL) {
                        wan_type = WAN_TYPE_PPP;
                    }
                    else {
                        wan_type = WAN_TYPE_IP;
                    }
                    iRet =
                        ifx_get_wan_ifname_from_connName(paxGetParamVal->Value,
                                                         sIfName, wan_type);
                    if(iRet != IFX_CWMP_SUCCESS) {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                                    "[%s] [%d]  ifx_get_wan_ifname_from_conf_connName failed. Connname: %s\n",
                                    __func__, __LINE__, paxGetParamVal->Value);
                        IFX_CWMP_FREE(xGetParam.Name);
                        IFX_CWMP_FREE(paxGetParamVal->Value);
                        IFX_CWMP_FREE(paxGetParamVal->Name);
                        IFX_CWMP_FREE(paxGetParamVal);
                        iRet = ERR_CWMP_INTERNAL;
                        pxPV[iI].iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                        goto errorHandler;
                    }
#if 0
                    strncpy(xNSLookup.interface, sIfName, 15);
#endif
                    IFX_CWMP_FREE(xGetParam.Name);
                    IFX_CWMP_FREE(paxGetParamVal->Value);
                    IFX_CWMP_FREE(paxGetParamVal->Name);;
                    IFX_CWMP_FREE(paxGetParamVal);
                }
                strncpy(xNSLookup.interface, pxPV[iI].Value, MAX_IF_NAME);
#endif
                break;
            case OID_IGD_NSLD_HOSTNAME:
                strncpy(xNSLookup.hostname, pxPV[iI].Value, MAX_HOST_NAME);
                break;
            case OID_IGD_NSLD_DNSSERVER:
                strncpy(xNSLookup.dnsserver, pxPV[iI].Value, MAX_HOST_NAME);
                break;
            case OID_IGD_NSLD_NUMBEROFREPETITIONS:
                xNSLookup.num_repetitions = atoi(pxPV[iI].Value);
                break;
            case OID_IGD_NSLD_TIMEOUT:
                xNSLookup.timeout = atoi(pxPV[iI].Value);
                if(xNSLookup.timeout <= 0) {
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Invalid timeout value\n", _FUNCL_,
                                iRet);
                    iRet = ERR_CWMP_INVAL_PARAM_VAL;
                    goto errorHandler;
                }
                break;
            case OID_IGD_NSLD_SUCCESSCOUNT:
            case OID_IGD_NSLD_RESULTNUMBEROFENTRIES:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%d] [Error] Non-Writable parameter %d!\n",
                            _FUNCL_, pxPV[iI].iaOID[NSLOOKUPDIAG_DEPTH - 1]);
                iRet = ERR_NON_WRITABLE;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE_PARAM;
                goto errorHandler;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%d] [Error] Unknown requested parameter %d!\n",
                            _FUNCL_, pxPV[iI].iaOID[NSLOOKUPDIAG_DEPTH - 1]);
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                pxPV[iI].iFaultCode = ERR_INVAL_PARAMETER_NAME;
                goto errorHandler;
        }
    }

    /* Modifying any of the parameters in this obj except DiagnosticState MUST
       result in the value of DiagnosticState parameter being set to "None" */
    if(iActivate != IFX_CWMP_NEED_ACTIVATE)
        strcpy(xNSLookup.diag_state, "None");

    iRet = ifx_set_nslookup_diag(&xNSLookup, IFX_F_MODIFY);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_set_nslookup_diag() failed\n", _FUNCL_,
                    iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }

  errorHandler:
    if((iActivate == IFX_CWMP_NEED_ACTIVATE) && (iRet == IFX_CWMP_SUCCESS))
        iRet = IFX_CWMP_NEED_ACTIVATE;

    return iRet;
}


/*******************************************************************************
* Function: IFX_Set_NSLookup_Result
* Desc: Set the value. Calls ifx_set_result. Set the required value.
* Return Value: IFX_CWMP_SUCCESS
*******************************************************************************/
static
  int32
IFX_Set_NSLookup_Result(int32 numresult, RESULT * result)
{
    int32 ret = IFX_SUCCESS;
    uint32 iI, flags;
    char sOidStringList[IFX_MAX_TR69_ID_LEN];

    flags = IFX_F_INT_ADD;

    for(iI = 0; iI < numresult; iI++) {
        memset(sOidStringList, '\0', IFX_MAX_TR69_ID_LEN);
        sprintf(sOidStringList,
                "InternetGatewayDevice.NSLookupDiagnostics.Result.");
        ret = IFX_ContAddObj(ACC_ROOT, sOidStringList);
        if(ret <= 0) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                        "[%s:%d] IFX_ContAddObj() failed.\n", _FUNCL_);
            continue;
        }
        else {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                        "[%s:%d] IFX_ContAddObj() succeded with instance id: %d.\n",
                        _FUNCL_, ret);
        }

        result[iI].iid.cpeId.Id = iI + 1;
        result[iI].iid.config_owner = IFX_TR69;
        memset(result[iI].iid.tr69Id, '\0', sizeof(result[iI].iid.tr69Id));
        sprintf(result[iI].iid.tr69Id, "-1000.-6000.-6011.%d.", iI + 1);
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                    "[%s:%d] Adding result for cpeId %d.\n", _FUNCL_,
                    result[iI].iid.cpeId.Id);
        ret = ifx_set_result(IFX_OP_ADD, &result[iI], flags);
        if(ret != IFX_SUCCESS) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] Adding result for cpeId %d failed !!!.\n",
                        _FUNCL_, result[iI].iid.cpeId.Id);
            goto IFX_Handler;
        }
    }

  IFX_Handler:
    if(ret != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_set_result failed\n", _FUNCL_, ret);
        return ret;
    }
    else
        return IFX_SUCCESS;
}

/*******************************************************************************
* Function: IFX_NSLookupTest
* Desc:
*
* Parameters: NSLOOKUP_DIAG * pxNSLookupQuery, NSLookupResp * pxNSLookupResp
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int
IFX_NSLookupTest(INOUT NSLOOKUP_DIAG * pxNSLookupQuery,
                 OUT NSLookupResp * pxNSLookupResp)
{
    FILE *fp = NULL;
    int32 iRet = IFX_CWMP_FAILURE;
    char8 caCommand[256] = { 0 } , ipaddr_str[256];;
    int32 iTmp = 0, iloop = 0 , *hostname_flag = NULL, *dnssserver_flag = NULL;
    RESULT *pxResult = NULL;
    struct hostent *pxHE = NULL;

    int32 i, j , k;          
    char8 dnsserver_used[LINESIZE];
    char8 line[180], server[20], name[100], IPAddress[10][20], rest_addr[50];
    int32 addr_count = 0, addr_Idx, success_count = 0;


    struct timeval tv;
    time_t currtime;
    char buff[30];
    int hr,min,sec;
    long int t1=0,t2;

    strcpy(pxNSLookupResp->caDiagState,"Error_Internal");

    iloop =
        pxNSLookupQuery->num_repetitions >
        0 ? pxNSLookupQuery->num_repetitions : 0;

    hostname_flag = (int *)IFX_CWMP_MALLOC(iloop * sizeof(int));
    dnssserver_flag = (int *)IFX_CWMP_MALLOC(iloop * sizeof(int));

    pxResult = (RESULT *) IFX_CWMP_MALLOC((iloop * sizeof(RESULT)));
//NULL CHECK
    if( hostname_flag == NULL || dnssserver_flag == NULL || pxResult == NULL)
        goto errorHandler;

    memset(pxResult , 0x00 ,(iloop * sizeof(RESULT)));
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, " number of repetitionst:'%d'\n",
                pxNSLookupQuery->num_repetitions);

    pxNSLookupQuery->result_num_entries = 0;

    for(i = 0; i < iloop; i++) {
        addr_count = 0;        

        strcpy(caCommand, "nslookup ");
        /* About to execute the commands. Put Error_Internal now. Overwrite it
           if nslookup test succeeds */
#if 0
        /* append the hostname */
        if((iRet = inet_pton(AF_INET, pxNSLookupQuery->hostname, &iTmp)) <= 0) {
            /* The the host must be Domain Name */
            res_init();
            pxHE = gethostbyname(pxNSLookupQuery->hostname);
            if(pxHE == NULL) {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d Invalid host %s\n", _FUNCL_,
                            pxNSLookupQuery->hostname);
                hostname_flag[i] = 1;
                iRet = IFX_CWMP_FAILURE;
                goto testComplete;
            }
        }
#endif
        strcat(caCommand, pxNSLookupQuery->hostname);
        strcat(caCommand, " ");


	strcpy(dnsserver_used, pxNSLookupQuery->dnsserver);
        /* append the DNSServer */
        if((iRet = inet_pton(AF_INET, pxNSLookupQuery->dnsserver, &iTmp)) <= 0) {
            /* The the host must be Domain Name */
            res_init();
            pxHE = gethostbyname(pxNSLookupQuery->dnsserver);
            if(pxHE == NULL) {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d Invalid DNSServer %s\n", _FUNCL_,
                            pxNSLookupQuery->dnsserver);
                dnssserver_flag[i] = 1;
//                iRet = IFX_CWMP_FAILURE;
                ifx_get_runtime_dns(dnsserver_used, "1");
                // goto testComplete;
            }
            else {
                strcpy(dnsserver_used, pxNSLookupQuery->dnsserver);
            }
        }
        strcat(caCommand, dnsserver_used);

        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "NSLOOKUPCMD: '%s'\n",
                    caCommand);


        gettimeofday(&tv , NULL);
	currtime = tv.tv_sec;
	strftime(buff,30,"%T." , localtime(&currtime));
	sscanf(buff , "%d:%d:%d." , &hr , &min , &sec);
	t1 = (hr*60*60*1000) + (min*60*1000) +(sec*1000) + (tv.tv_usec /1000);

        if((fp = popen(caCommand, "r")) == NULL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d popen failed for %s\n", _FUNCL_, caCommand);
            iRet = IFX_CWMP_FAILURE;
            goto errorHandler;
        }

	gettimeofday(&tv , NULL);
        currtime = tv.tv_sec;
        strftime(buff,30,"%T." , localtime(&currtime));
        sscanf(buff , "%d:%d:%d." , &hr , &min , &sec);
        t2 = (hr*60*60*1000) + (min*60*1000)+(sec*1000) + (tv.tv_usec/1000);


        hostname_flag[i] = 1;
        while((fgets(line, 80, fp)) != NULL) {
            if(strstr(line, "Name")) {
                sscanf(line, "Name: %s\n", name);
                hostname_flag[i] = 0;
            }
            if(strstr(line, "Address")) {
                sscanf(line, "Address %d: %s %s\n", &addr_Idx,
                       IPAddress[addr_count], rest_addr);
                addr_count++;
            }

            if(strstr(line, "Server")) {
                sscanf(line, "Server: %s\n", server);
                fgets(line, 80, fp);
            }
        }
     
//      testComplete:
        if(hostname_flag[i] == 1) {
            strcpy(pxResult[i].status, "Error_HostNameNotResolved");
            strcpy(pxResult[i].anstype , "None");
	    pxResult[i].resp_time = 0;
            pxNSLookupQuery->result_num_entries += 1;    
        }
        else {
            success_count += 1;
            strcpy(pxResult[i].status , "Success");
            strcpy(pxResult[i].dnsserver_ip, server);
            strcpy(pxResult[i].hostname_ret, name);
	    memset(ipaddr_str , '\0' , 256);
            for(j = 0; j < addr_count; j++) {
                strcat(ipaddr_str, IPAddress[j]);
                if(j != (addr_count - 1))
                    strcat(ipaddr_str, ",");
            }
	    strcpy(pxResult[i].ipaddresses , ipaddr_str);
            pxResult[i].resp_time = t2 -t1 ; //TBD
            strcpy(pxResult[i].anstype , "NonAuthoritative");
            pxNSLookupQuery->result_num_entries += 1;
        }
    }

    strcpy(pxNSLookupResp->caDiagState,"Error_Other");
    for( j = 0 ; j < pxNSLookupQuery->num_repetitions ; j++ ){
        if(hostname_flag[j] == 0){
            strcpy(pxNSLookupResp->caDiagState,"Error_DNSServerNotResolved");
            for( k = 0 ; k < pxNSLookupQuery->num_repetitions ; k++ )
                if(dnssserver_flag[k] == 0){
                    strcpy(pxNSLookupResp->caDiagState,"None");
                    break;
                }
            break;
        }
    }    

    pclose(fp);

  errorHandler:
    pxNSLookupResp->iResultNumberOfSuccess = success_count;

    if(pxResult != NULL)
       pxNSLookupResp->pxResult = pxResult;

    if(strcmp(pxNSLookupResp->caDiagState,"None")==0)
        strcpy(pxNSLookupResp->caDiagState,"Complete");

    IFX_CWMP_FREE(hostname_flag);
    IFX_CWMP_FREE(dnssserver_flag);
    return IFX_SUCCESS;
}

/*******************************************************************************
* Function: IFX_NSLookupDiagPerformTest
* Desc: Gets the value. Calls IFX_NSLookupTest. Set the required value. Posts the
*       message to the Stacks FIFO about the completion of Traaceroute Diag Test
* Parameters:
* Return Value: IFX_CWMP_SUCCESS
*******************************************************************************/
void
 *
IFX_NSLookupDiagPerformTest(void
                            *params)
{
    int32 iRet = IFX_CWMP_SUCCESS, iFIFOFd = 0, i, iLastCpeId = -1;
    NSLOOKUP_DIAG xNSLookup;
    NSLookupResp xNSLookupResp;
    RESULT xResult;
    uint32 uiflags, outFlag;
    char8 sValue[MAX_FILELINE_LEN];
    char sOidStringList[IFX_MAX_TR69_ID_LEN];

    memset(&xNSLookup, '\0', sizeof(xNSLookup));
    memset(&xNSLookupResp, '\0', sizeof(xNSLookupResp));
    iRet = ifx_get_nslookup_diag(&xNSLookup);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId,
                    IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_nslookup_diag() failed\n",
                    _FUNCL_, iRet);
        goto errorHandler;
    }

    memset(sValue, '\0', sizeof(sValue));
    if((iRet =
        ifx_GetObjData(FILE_RC_CONF,
                       "next_cpeid",
                       "nslookup_result_nextCpeId",
                       IFX_F_DEFAULT, &outFlag, sValue)) != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId,
                    IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_GetObjData() failed\n", _FUNCL_, iRet);
        goto errorHandler;
    }
    else {
        iLastCpeId = atoi(sValue);
    }

    for(i = iLastCpeId; i > 2; i--) {
        memset(sOidStringList, '\0', IFX_MAX_TR69_ID_LEN);
        /* Object ID = cpeId - 1 = i - 2 */
        sprintf(sOidStringList,
                "InternetGatewayDevice.NSLookupDiagnostics.Result.%d.", i - 2);
        iRet = IFX_ContDelObj(ACC_ROOT, sOidStringList, NO_SESSION);
        if(iRet != IFX_SUCCESS) {
            IFX_DBG_Log(vcOsModId,
                        IFX_DBG_LVL_ERROR,
                        "%s:%d [%d] IFX_ContDelObj() failed\n", _FUNCL_, iRet);
            iRet = ERR_CWMP_INTERNAL;
            goto errorHandler;
        }

        xResult.iid.cpeId.Id = i - 1;
        xResult.iid.config_owner = IFX_TR69;
        xResult.iid.pcpeId.Id = 1;
        IFX_DBG_Log(vcOsModId,
                    IFX_DBG_LVL_NORMAL,
                    "Getting results for cpeid %d.\n", xResult.iid.cpeId.Id);
        iRet = ifx_get_result(&xResult);
        if(iRet != IFX_SUCCESS) {
            IFX_DBG_Log(vcOsModId,
                        IFX_DBG_LVL_ERROR,
                        "%s:%d [%d] ifx_get_result() failed\n", _FUNCL_, iRet);
            iRet = ERR_CWMP_INTERNAL;
            goto errorHandler;
        }

        uiflags = IFX_F_DELETE | IFX_F_DONT_CHECKPOINT;
        IFX_DBG_Log(vcOsModId,
                    IFX_DBG_LVL_NORMAL,
                    "Deleting results for cpeid %d.\n", xResult.iid.cpeId.Id);
        iRet = ifx_set_result(IFX_OP_DEL, &xResult, uiflags);
        if(iRet != IFX_CWMP_SUCCESS) {
            IFX_DBG_Log(vcOsModId,
                        IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Result Delete Object failed ",
                        __FILE__, __func__, __LINE__, iRet);
            iRet = ERR_CWMP_INTERNAL;
            goto errorHandler;
        }
    }

    memset(sValue, '\0', sizeof(sValue));
    strcpy(sValue, "nslookup_result_nextCpeId=\"2\"\n");
    if((iRet =
        ifx_SetObjData(FILE_RC_CONF,
                       "next_cpeid", IFX_F_MODIFY, 1, sValue)) != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId,
                    IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_SetObjData() failed\n", _FUNCL_, iRet);
        goto errorHandler;
    }

    iRet = IFX_NSLookupTest(&xNSLookup, &xNSLookupResp);
    if(iRet == IFX_CWMP_SUCCESS) {
        xNSLookup.success_count = xNSLookupResp.iResultNumberOfSuccess;
    }
    strcpy(xNSLookup.diag_state, xNSLookupResp.caDiagState);
    IFX_DBG_Log(vcOsModId,
                IFX_DBG_LVL_NORMAL,
                "%s:%d: IFX_NSLookupTest returned\n", _FUNCL_);
    iRet = ifx_set_nslookup_diag(&xNSLookup, IFX_F_MODIFY);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId,
                    IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_set_nslookup_diag() failed\n",
                    _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "saved the xNSLookup\n");
    IFX_DBG_Log(vcOsModId,
                IFX_DBG_LVL_NORMAL,
                "%s:%d [*] saving Result. Count = %d\n",
                _FUNCL_, xNSLookup.num_repetitions);
    if(xNSLookupResp.pxResult == NULL){
        IFX_DBG_Log(vcOsModId,
                    IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] No Result instances \n",
                    _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
    iRet =
        IFX_Set_NSLookup_Result
        (xNSLookup.num_repetitions, xNSLookupResp.pxResult);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId,
                    IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_set_nslookup_result() failed\n",
                    _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, " saved the pxResult\n");
    sleep(2);
    /* Free xNSLookupResp.pxResult array*/
    //IFX_CWMP_FREE(xNSLookupResp.pxResult);
    /* Send msg to FIFO */
    iFIFOFd = IFX_OS_OpenFifo((uchar8 *)
                              IFX_IPC_TR_FIFO, O_RDWR);
    if(iFIFOFd < 0) {
        IFX_DBG_Log(vcOsModId,
                    IFX_DBG_LVL_NORMAL, "%s:%d Error opening FIFO\n", _FUNCL_);
        iRet = ERR_CWMP_FIFO_OPEN;
        goto errorHandler;
    }

    if(IFX_IPC_SendMsg(iFIFOFd, (uchar8)
                       IFX_IPC_APP_DIAGNOSTIC, 0, 0, 0, NULL)
       != IFX_IPC_SUCCESS) {
        IFX_DBG_Log(vcOsModId,
                    IFX_DBG_LVL_ERROR,
                    "%s:%d Error sending msg to " "FIFO\n", _FUNCL_);
    }
    else
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, " message sent\n");
    IFX_OS_CloseFifo(iFIFOFd);
  errorHandler:
    /* Always return SUCCESS */
    /* Free xNSLookupResp.pxResult array */
    IFX_CWMP_FREE(xNSLookupResp.pxResult);
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, " thread returns\n");
    pthread_mutex_unlock(&nsl_msg_mutex);
    sleep(2);
    pthread_exit(0);
}


/*******************************************************************************
* Function: IFX_NSLookupDiagnostics
* Desc:
*
* Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
*             OUT void **ppRet, OUT int32 * piNumRetElem
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_NSLookupDiagnostics(IN OperInfo * pxOI, INOUT void
                        *pParamStruct, IN int32 iElements, OUT void
                        **ppRet, OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;
    pthread_t nslookuptest;
    switch (pxOI->iOper) {
        case OP_GETVAL:
            switch (pxOI->iSubOper) {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:
                    iRet =
                        IFX_NSLookupDiagGetNotifyValue
                        (pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId,
                                IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n",
                                _FUNCL_, pxOI->iSubOper);
                    break;
            }
            break;
        case OP_SETVAL:
            switch (pxOI->iSubOper) {
                case OP_SETVAL_VALIDATE:
                    iRet = IFX_NSLookupDiagValidate(xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_SETVAL_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:
                    break;
                case OP_SETVAL_MODIFY:
                    iRet = IFX_NSLookupDiagSetValue(xpParamVal, iElements);
                    if((iRet != IFX_SUCCESS)
                       && (iRet != IFX_CWMP_NEED_ACTIVATE)) {
                        IFX_DBG_Log(vcOsModId,
                                    IFX_DBG_LVL_NORMAL,
                                    "%s:%d, IFX_NSLookupDiagSetValue() failed! \n",
                                    _FUNCL_);
                        goto errorHandler;
                    }
                    break;
                case OP_SETVAL_ACTIVATE:
                    pthread_mutex_lock(&nsl_msg_mutex);
                    IFX_DBG_Log(vcOsModId,
                                IFX_DBG_LVL_NORMAL, "Creating thread\n");
                    iRet =
                        pthread_create(&nslookuptest, NULL,
                                       IFX_NSLookupDiagPerformTest, NULL);
                    if(iRet != IFX_SUCCESS)
                        goto errorHandler;
                case OP_SETVAL_COMMIT:
                    break;
                case OP_SETVAL_UNDO:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_DELETE:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_ATTRINFO:
                    iRet =
                        IFX_NSLookupDiagSetAttrInfo(pxOI->
                                                    iCaller,
                                                    pParamStruct, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId,
                                IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case.\n",
                                _FUNCL_, pxOI->iSubOper);
                    break;
            }
            break;
        case OP_UPDATE_CHILDINFO:
            switch (pxOI->iSubOper) {
                case OP_UPDATE_CHILDINFO_ADD:
                case OP_UPDATE_CHILDINFO_DEL:
                    break;
            }
            break;
        case OP_PARAM_VALIDATE:
            break;
        default:
            IFX_DBG_Log(vcOsModId,
                        IFX_DBG_LVL_ERROR,
                        "%s:%d [%d] Error! Default case.\n",
                        _FUNCL_, pxOI->iOper);
            break;
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_ResultGetValue
* Desc:
*
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_ResultGetValue(IN OperInfo *
                   pxOI, INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    RESULT xResult;
    uint32 uiCpeid, uiPcpeid;
    uint32 uiParamPos = 0;
    memset(&xResult, '\0', sizeof(xResult));
    iRet = IFX_GetCpeId(pxPV->iaOID, &uiCpeid);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId,
                    IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] IFX_GetCpeId() failed\n", _FUNCL_, iRet);
        goto errorHandler;
    }

    iRet = IFX_GetParentObjCpeId(pxPV->iaOID, &uiPcpeid);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId,
                    IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] IFX_GetParentObjCpeId() failed\n",
                    _FUNCL_, iRet);
        goto errorHandler;
    }

    xResult.iid.cpeId.Id = uiCpeid;
    xResult.iid.config_owner = pxOI->iCaller;
    xResult.iid.pcpeId.Id = uiPcpeid;
    iRet = ifx_get_result(&xResult);
    if(iRet != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId,
                    IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] ifx_get_result() failed\n", _FUNCL_, iRet);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }

    uiParamPos = IFX_GetParamIdPos(pxPV->iaOID);
    for(iI = 0; iI < iElements; iI++) {
        pxPV[iI].Value = IFX_CWMP_MALLOC(257);
        if(pxPV[iI].Value == NULL) {
            IFX_DBG_Log(vcOsModId,
                        IFX_DBG_LVL_ERROR, "%s:%d " "Malloc failed\n", _FUNCL_);
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (pxPV[iI].iaOID[uiParamPos]) {
            case OID_IGD_NSLD_R_STATUS:
                strcpy(pxPV[iI].Value, xResult.status);
                break;
            case OID_IGD_NSLD_R_ANSWERTYPE:
                strcpy(pxPV[iI].Value, xResult.anstype);
                break;
            case OID_IGD_NSLD_R_HOSTNAMERETURNED:
                strcpy(pxPV[iI].Value, xResult.hostname_ret);
                break;
            case OID_IGD_NSLD_R_IPADDRESSES:
                strcpy(pxPV[iI].Value, xResult.ipaddresses);
                break;
            case OID_IGD_NSLD_R_DNSSERVERIP:
                strcpy(pxPV[iI].Value, xResult.dnsserver_ip);
                break;
            case OID_IGD_NSLD_R_RESPONSETIME:
                sprintf(pxPV[iI].Value, "%d", xResult.resp_time);
                break;
            default:
                IFX_DBG_Log(vcOsModId,
                            IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n",
                            _FUNCL_, pxPV[iI].iaOID[NSLOOKUPDIAG_DEPTH - 1]);
                break;
        }
    }

  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_Result
* Desc:
*
* Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
*             OUT void **ppRet, OUT int32 * piNumRetElem
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_Result(IN OperInfo * pxOI,
           INOUT void
           *pParamStruct,
           IN int32 iElements, OUT void **ppRet, OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *pxParamVal = (ParamVal *) pParamStruct;
    ParamVal *pxVal;
    uint32 uiParamPos = 0;
    IFX_DBG_Log(vcOsModId,
                IFX_DBG_LVL_NORMAL,
                "Entered IFX_Result [%d :: %d]\n", pxOI->iOper, pxOI->iSubOper);
    switch (pxOI->iOper) {
        case OP_GETVAL:
            {
                IFX_DBG_Log(vcOsModId,
                            IFX_DBG_LVL_NORMAL, "Entered OP_GETVAL\n");
                switch (pxOI->iSubOper) {
                    case OP_GETVAL_NORMAL:
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                                    "Entered OP_GETVAL_NORMAL\n");
                    case OP_GETVAL_NOTIFICATION:
                        IFX_DBG_Log(vcOsModId,
                                    IFX_DBG_LVL_NORMAL,
                                    "Entered OP_GETVAL_NOTIFICATION\n");
                        iRet = IFX_ResultGetValue(pxOI, pxParamVal, iElements);
                        if(iRet != IFX_CWMP_SUCCESS) {
                            IFX_DBG_Log(vcOsModId,
                                        IFX_DBG_LVL_NORMAL,
                                        "IFX_ResultGetValue FAILED\n");
                            goto errorHandler;
                        }
                        break;
                    default:
                        goto errorHandler;
                        break;
                }
                break;
            }
        case OP_SETVAL:
            {
                /* Process based on type of SubOperation */
                switch (pxOI->iSubOper) {
                    case OP_SETVAL_VALIDATE:
                    case OP_SETVAL_MODIFY:
                    case OP_SETVAL_ACTIVATE:
                    case OP_SETVAL_ADD:
                    case OP_SETVAL_CHK_MODIFY_DEP:
                    case OP_SETVAL_CHK_DEL_ALLOWED:
                    case OP_SETVAL_DELETE:
                    case OP_SETVAL_ATTRINFO:
                    case OP_SETVAL_FREE:
                        break;
                    case OP_SETVAL_CHK_DEL_DEP:
                        pxVal = (void *)IFX_CWMP_MALLOC(sizeof(ParamVal));
                        uiParamPos = IFX_GetParamIdPos(pxParamVal->iaOID);
                        memcpy(pxVal->iaOID, pxParamVal->iaOID,
                               (sizeof(int32) * (uiParamPos + 1)));
                        *ppRet = (void *)pxVal;
                        *piNumRetElem = 1;
                        break;
                    default:
                        IFX_DBG_Log(vcOsModId,
                                    IFX_DBG_LVL_ERROR,
                                    "[%s:%d] [Error] Requested SubOperation not"
                                    " permitted on Object\n",
                                    __func__, __LINE__);
                        iRet = IFX_CWMP_FAILURE;
                        goto errorHandler;
                }
                break;
            }
        case OP_PARAM_VALIDATE:
            break;
        default:
            {
                IFX_DBG_Log(vcOsModId,
                            IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case.\n",
                            _FUNCL_, pxOI->iOper);
                break;
            }
    }

  errorHandler:
    IFX_DBG_Log(vcOsModId,
                IFX_DBG_LVL_NORMAL, "IFX_Result returning %d\n", iRet);
    return iRet;
}

/*******************************************************************************
* Function: IFX_NSLookupDiagInit

* Parameters:
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_NSLookupDiagInit()
{
    int32 iRet = IFX_CWMP_SUCCESS;
    NSLOOKUP_DIAG xNSLookup;

    memset(&xNSLookup, '\0', sizeof(xNSLookup));
    
    strcpy(xNSLookup.diag_state , "None");
    strcpy(xNSLookup.interface , "");
    strcpy(xNSLookup.hostname , "");
    strcpy(xNSLookup.dnsserver , "");
    xNSLookup.num_repetitions = 0;
    xNSLookup.timeout = 5000;
    xNSLookup.success_count = 0;
    xNSLookup.result_num_entries = 0;

    
    /* Register the IFX_NSLookupDiagInit func ptr in the object model */
    iRet = ifx_ds_register_function(NSLOOKUPDIAG_OBJ, IFX_NSLookupDiagnostics);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId,
                    IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Unable to Register %s with Object Model\n",
                    _FUNCL_, iRet, NSLOOKUPDIAG_OBJ);
        goto errorHandler;
    }

    iRet = ifx_ds_register_function(RESULT_OBJ, IFX_Result);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId,
                    IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Unable to Register %s with Object Model\n",
                    _FUNCL_, iRet, RESULT_OBJ);
        goto errorHandler;
    }

    iRet = ifx_set_nslookup_diag(&xNSLookup, IFX_F_INT_ADD);
        if (iRet != IFX_SUCCESS) {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] Writing default "
                            "nslookup_diag section failed in %s\n", _FUNCL_, iRet,
                            IFX_DIAG_FILE);
        }

    ifx_cleanup_nslookup_tr69_maps();
    ifx_cleanup_nslookup_tr69_instances();
    ifx_reset_nslookup_next_cpeid();

  errorHandler:
    return iRet;
}
