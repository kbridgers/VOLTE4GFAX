/*
** =============================================================================
** FILE NAME      : IFX_LANEthernetIfConfigStats.c
** PROJECT        : TR69
** MODULES        : IGD.LANDevice.1.LANEthernetInterfaceConfig.1.Stats.
** DATE           : 15-Jun-2006
** AUTHOR         : TR69 team
** DESCRIPTION    : This object is RO. SetParameterValues or AddObject cannot be
**                  performed on this object.
** REFERENCES     :  
** COPYRIGHT      : Copyright (c) 2006
**                  Infineon Technologies AG
**                  Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
** HISTORY        : 
** $Date        $Author          $Comment
** 15-Jun-2006  Tr69 team        Creation
** =============================================================================
*/

#include "IFX_DEVM_Global.h"
 
#include "IFX_DEVM_AdaptCommon.h"
#include "IFX_DEVM_OID.h"
#include "IFX_DEVM_Platform.h"

extern char8 vcOsModId;
extern int32 ifx_ds_register_function(char8 * obj, modFunc pifx_module_func);

#define LEICSTATS_OBJ    "InternetGatewayDevice.LANDevice.1.LANEthernetInterfaceConfig.1.Stats."
#define LEICSTATS_DEPTH  7

#ifdef MIPSTARGET
#define QUERY_INTERFACE         "br0"
#else
#define QUERY_INTERFACE         "eth0"
#endif

/*******************************************************************************
* Function: IFX_LEICStatsSetAttrInfo
* Description: Sets attribute information in the respective tr69 sections
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_LEICStatsSetAttrInfo(IN int32 iCaller, INOUT ParamVal * pxPV,
                         IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    iRet = IFX_SetAttributesInfo(NULL, pxPV, iElements);

    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d [%d] Updating Param Attribute Info failed\n",
                    __func__, __LINE__, iRet);
        goto errorHandler;
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_LEICStatsGetValue
* Description: Hard coding it to br0 interface. An enhancement on this can be 
*              performed. 
* Parameters: IN int32 iCaller, INOUT ParamVal * pxPV, IN int32 iElement
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
#define   LAN_STATS_GET_ALLOC                12
static int32
IFX_LEICStatsGetValue(IN OperInfo * pxOI, INOUT ParamVal * pxPV,
                      IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;
    IF_STATS xIfStats;
    char8 sTmp[LAN_STATS_GET_ALLOC] = {0};
#ifdef MIPSTARGET
    int32 iParamOffset;
    int32 iInstancePos = 0;
    struct ifx_phyportstats_info xPort;
#endif /* MIPSTARGET */

#ifdef MIPSTARGET
    /* Memset the port structure to zero */
    memset(&xPort, '\0', sizeof(xPort));
#endif /* MIPSTARGET */

    memset(&xIfStats, '\0', sizeof(IF_STATS));

#ifdef MIPSTARGET
    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamIdPos(pxPV->iaOID);
    if ((iParamOffset <= 1) || (iParamOffset > OID_LENGTH))
    {
            iRet = ERR_CWMP_INTERNAL;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
            goto errorHandler;
    }

    /* Get the Instance Position */
    iInstancePos = (iParamOffset - 2) ;

#ifdef AMAZON_SE_RT_EL_1ETH_PNOR_SAMPLE
    iI = ifx_get_if_stats("br0", &xIfStats, 0);
    if(iI != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                "%s:%d [%d] ifx_get_if_stats failed %s\n",
                 __func__, __LINE__, iI, QUERY_INTERFACE);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }
#else
    /* Get the values for the requested instance */
#if defined(PLATFORM_VR9) || defined(PLATFORM_AR10)
    ifx_get_phyportstats_info(((pxPV->iaOID[iInstancePos]) - 1), &xPort, 0);
#else
    ifx_get_phyportstats_info(((pxPV->iaOID[iInstancePos]) - 1), &xPort, 1);
#endif

    xIfStats.tx_pkts = xPort.txPktCnt;
    xIfStats.rx_pkts = xPort.rxPktCnt;
    xIfStats.tx_bytes = xPort.txByteCnt;
    xIfStats.rx_bytes = xPort.rxByteCnt;
    xIfStats.tx_error_pkts = xPort.txErrors;
    xIfStats.tx_discard_pkts = xPort.txDscrdPktCnt;
    xIfStats.rx_error_pkts = xPort.rxErrors;
    xIfStats.rx_discard_pkts = xPort.rxDscrdPktCnt;
    xIfStats.tx_unicast_pkts = xPort.txUnicastPktCnt;
    xIfStats.rx_unicast_pkts = xPort.rxUnicastPktCnt;
    xIfStats.tx_multicast_pkts = xPort.txMulticastPktCnt;
    xIfStats.rx_multicast_pkts = xPort.rxMulticastPktCnt;
    xIfStats.tx_broadcast_pkts = xPort.txBroadcastPktCnt;
    xIfStats.rx_broadcast_pkts = xPort.rxBroadcastPktCnt;
    xIfStats.rx_unknownproto_pkts = xPort.rxUnknownProtoPktCnt;
#endif
#else
/*    iTmp = ifx_get_if_stats(QUERY_INTERFACE, &xIfStats, 0);
    if(iTmp != IFX_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d [%d] ifx_get_if_stats"
                    " failed %s\n", __func__, __LINE__, iTmp, QUERY_INTERFACE);
        iRet = ERR_CWMP_INTERNAL;
        goto errorHandler;
    }*/
    xIfStats.tx_pkts = 10;
    xIfStats.rx_pkts = 20;
    xIfStats.tx_bytes = 30;
    xIfStats.rx_bytes = 40;
#endif /* MIPSTARGET */

    for(iI = 0; iI < iElements; iI++) {
        pxPV[iI].Value = IFX_CWMP_MALLOC(LAN_STATS_GET_ALLOC + 1);
        if(pxPV[iI].Value == NULL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%d "
                        "Malloc failed\n", __func__, __LINE__);
            iRet = ERR_OUT_OF_MEMORY;
            goto errorHandler;
        }

        switch (pxPV[iI].iaOID[LEICSTATS_DEPTH - 1]) {
            case OID_IGD_LAND_LANEIC_S_BYTESSENT:
                sprintf(sTmp, "%lu", xIfStats.tx_bytes);
                strcpy(pxPV[iI].Value, sTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_LAND_LANEIC_S_BYTESRECEIVED:
                sprintf(sTmp, "%lu", xIfStats.rx_bytes);
                strcpy(pxPV[iI].Value, sTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_LAND_LANEIC_S_PACKETSSENT:
                sprintf(sTmp, "%lu", xIfStats.tx_pkts);
                strcpy(pxPV[iI].Value, sTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_LAND_LANEIC_S_PACKETSRECEIVED:
                sprintf(sTmp, "%lu", xIfStats.rx_pkts);
                strcpy(pxPV[iI].Value, sTmp);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_LAND_LANEIC_S_ERRORSSENT:
                sprintf(pxPV[iI].Value, "%lu", xIfStats.tx_error_pkts);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_LAND_LANEIC_S_ERRORSRECEIVED:
                sprintf(pxPV[iI].Value, "%lu", xIfStats.rx_error_pkts);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_LAND_LANEIC_S_DISCARDPACKETSSENT:
                sprintf(pxPV[iI].Value, "%lu", xIfStats.tx_discard_pkts);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_LAND_LANEIC_S_DISCARDPACKETSRECEIVED:
                sprintf(pxPV[iI].Value, "%lu", xIfStats.rx_discard_pkts);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_LAND_LANEIC_S_UNICASTPACKETSSENT:
                sprintf(pxPV[iI].Value, "%lu", xIfStats.tx_unicast_pkts);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_LAND_LANEIC_S_UNICASTPACKETSRECEIVED:
                sprintf(pxPV[iI].Value, "%lu", xIfStats.rx_unicast_pkts);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break; 
            case OID_IGD_LAND_LANEIC_S_MULTICASTPACKETSSENT:
                sprintf(pxPV[iI].Value, "%lu", xIfStats.tx_multicast_pkts);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_LAND_LANEIC_S_MULTICASTPACKETSRECEIVED:
                sprintf(pxPV[iI].Value, "%lu", xIfStats.rx_multicast_pkts);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_LAND_LANEIC_S_BROADCASTPACKETSSENT:
                sprintf(pxPV[iI].Value, "%lu", xIfStats.tx_broadcast_pkts);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_LAND_LANEIC_S_BROADCASTPACKETSRECEIVED:
                sprintf(pxPV[iI].Value, "%lu", xIfStats.rx_broadcast_pkts);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;
            case OID_IGD_LAND_LANEIC_S_UNKNOWNPROTOPACKETSRECEIVED:
                sprintf(pxPV[iI].Value, "%lu", xIfStats.rx_unknownproto_pkts);
                IFX_CheckValueGotChanged(pxOI, pxPV + iI, IFX_CHK_VALUE_BASED);
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", __func__,
                            __LINE__, pxPV[iI].iaOID[LEICSTATS_DEPTH - 1]);
                break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_LEICStatsValidate
* Description: Since this is a Stats obj, only read is allowed. SetValidate will
*              be called befor SETVAL is actually called. It returns err for 
*              each SETVAL being called.
* Parameters: INOUT ParamVal * pxPV, IN int32 iElements
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
static int32
IFX_LEICStatsValidate(INOUT ParamVal * pxPV, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS, iI = 0;

    for(iI = 0; iI < iElements; iI++) {
        switch (pxPV[iI].iaOID[LEICSTATS_DEPTH - 1]) {
            case OID_IGD_LAND_LANEIC_S_BYTESSENT:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            case OID_IGD_LAND_LANEIC_S_BYTESRECEIVED:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            case OID_IGD_LAND_LANEIC_S_PACKETSSENT:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            case OID_IGD_LAND_LANEIC_S_PACKETSRECEIVED:
                iRet = ERR_CWMP_INVAL_ARGS;
                pxPV[iI].iFaultCode = ERR_NON_WRITABLE;
                break;
            default:
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "%s:%d [%d] Error! Default case\n", __func__,
                            __LINE__, pxPV[iI].iaOID[LEICSTATS_DEPTH - 1]);
                break;
        }
    }
    return iRet;
}

/*******************************************************************************
* Function: IFX_LANEthernetIfCfgStats
* Description: This function is registered with the data model. Handles on 
*              GETVAL. For all other returns err code.
* Parameters: IN OperInfo * pxOI, INOUT void *pParamStruct, IN int32 iElements,
*             OUT void **ppRet, OUT int32 * piNumRetElem
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_LANEthernetIfCfgStats(IN OperInfo * pxOI, INOUT void *pParamStruct,
                          IN int32 iElements, OUT void **ppRet,
                          OUT int32 * piNumRetElem)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    ParamVal *xpParamVal = (ParamVal *) pParamStruct;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL, "%s: %s oper=%d maxElem=%d\n",
                __func__, xpParamVal[0].Name, pxOI->iOper, iElements);

    switch (pxOI->iOper)
    {
        case OP_GETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                    iRet = IFX_LEICStatsGetValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                case OP_GETVAL_NOTIFICATION:
                    iRet = IFX_LEICStatsGetValue(pxOI, xpParamVal, iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_SETVAL:
        {
            switch (pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:
                    if((iRet =
                        IFX_LEICStatsValidate(xpParamVal, iElements)) != 0) {
                        goto errorHandler;
                    }
                    break;
                case OP_SETVAL_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:
                    break;
                case OP_SETVAL_MODIFY:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_COMMIT:
                    break;
                case OP_SETVAL_UNDO:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_DEP:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_DELETE:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_SETVAL_FREE:
                    break;
                case OP_SETVAL_ATTRINFO:
                    iRet = IFX_LEICStatsSetAttrInfo(pxOI->iCaller, pParamStruct,
                                                    iElements);
                    if(iRet != IFX_CWMP_SUCCESS)
                        goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_UPDATE_CHILDINFO:
        {
            switch (pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                case OP_UPDATE_CHILDINFO_DEL:
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto errorHandler;
                    break;
                default:
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d [%d] Error! Default case\n", __func__,
                                __LINE__, pxOI->iSubOper);
                    break;
            }
            break;
        }
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "%s:%d [%d] Error! Default case\n", __func__,
                        __LINE__, pxOI->iOper);
            break;
        }
    }
  errorHandler:
    return iRet;
}

/*******************************************************************************
* Function: IFX_LANEthernetIfCfgStatsInit
* Description: Will initialize some of its data structures, register itself with 
*              DS.
* Parameters: 
* Return Value: IFX_CWMP_SUCCESS if success, -ve err code for failure
*******************************************************************************/
int32
IFX_LANEthernetIfCfgStatsInit()
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* TBD: Perform any LANEthernetIfCfgStatsInit related initializations here */

    /* Register the IFX_LANEthernetIfCfgStatsInit func ptr in the object model */
    iRet = ifx_ds_register_function(LEICSTATS_OBJ, IFX_LANEthernetIfCfgStats);
    if(iRet != IFX_CWMP_SUCCESS) {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "%s:%d Unable to Register %s with Object Model\n",
                    __func__, __LINE__, LEICSTATS_OBJ);
        goto errorHandler;
    }

  errorHandler:
    return iRet;
}
