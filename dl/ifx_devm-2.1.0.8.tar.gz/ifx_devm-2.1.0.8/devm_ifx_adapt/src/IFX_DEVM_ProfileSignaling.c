/* 
** =============================================================================
**   FILE NAME        : IFX_ProfileSignaling
**   PROJECT          : TR104
**   MODULES          : IFX_ProfileSignaling
**   DATE             : 24-11-2006
**   AUTHOR           : TR104 team
**   DESCRIPTION   :

**   REFERENCES      : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2004
**                   	      Infineon Technologies AG, st. Martin Strasse 53;
**                   	      81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/


/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "ifx_vmapi_common.h"
#include "IFX_DEVM_VoiceLine.h"
  // Required for STATIC
 
#include "IFX_DEVM_OID.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
 
#include "IFX_DEVM_DS.h"

//#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

int32
IFX_ProfileSignaling(IN OperInfo * pxOI, INOUT void *pParamList,
                     IN int32 iNumElem, OUT void **ppRet,
                     OUT int32 * piNumRetElem);

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFX_PROFILESIGNALING_OBJ "InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.1.SIP."

#define SIP_NO_DEP_OIDS 1

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/
STATIC int32
GetVal(IN int32 iCaller, INOUT ParamVal *pxParamVal,
                    IN int32 iElements);
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
GetModifyDep(INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
GetNotify(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
                 IN int32 iElements);
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);
/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/

/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetVal(IN int32 iCaller, INOUT ParamVal *pxParamVal,
                    IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iRtn = IFX_SUCCESS;
    int32   iCnt = 0;
    int32   iTmpCnt = -1; /* Mandatory */
    int32   iParamOffset;
    int32   iOID;
    int32   iMemErrorFlag = 0; /* Mandatory */
    x_IFX_VMAPI_ProfileSignaling xProfSignaling;
    uint32 uiPCpeId;

    /* NOTE: For all parameters fault code is set to success by default. If error in
       validating first parameter, fault code is set to the error type and other
       parameters are not validated. */
    /* NOTE: For all parameters value is set to NULL by default. */

    /* Set the fault code to Success and value to NULL pointer for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);

    memset(&xProfSignaling, 0, sizeof(x_IFX_VMAPI_ProfileSignaling));

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_SIP:{

            char8 sOidString[100] = {0};
            IFX_CpeId *pxCpeIdArray = NULL;
            unsigned int uiNumCpeId;

            /* Get the Parent CPE Id */
            IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT &uiPCpeId);
            xProfSignaling.iid.pcpeId.Id = uiPCpeId;

            /*ignore the last value as it will be a parameter and we need 
              only till the last instance*/
            iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );

            strcpy(xProfSignaling.iid.tr69Id,sOidString);

            /*Get the CPE Id from the corresponding tr69 Id */
            iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId,
                               OUT &pxCpeIdArray);
            if(iRet != IFX_CWMP_SUCCESS){
                   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                   __func__, __LINE__);

              return ERR_CWMP_INTERNAL;
            }
            //printf("CPEID is %d\n",pxCpeIdArray->uiId);   

            /* Fill the CPE ID of the object instance */
            xProfSignaling.iid.cpeId.Id = pxCpeIdArray->uiId;
            xProfSignaling.iid.config_owner = IFX_TR69;

            /* Get all the Profile Signaling parameters using VMAPI */
            iRtn = ifx_get_ProfileSignaling(&xProfSignaling, IFX_F_DEFAULT);

            IFX_CWMP_FREE(pxCpeIdArray);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to get values of all "
                            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto cleanup;
            }
            }
            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
          case OID_IGD_S_VS_VP_SIP_PROXYSERVER:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                sizeof(xProfSignaling.acProxyAddr));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              strcpy((pxParamVal[iCnt]).Value,
                                xProfSignaling.acProxyAddr);
              
            break;
          case OID_IGD_S_VS_VP_SIP_PROXYSERVERPORT:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                    sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", 
                               xProfSignaling.unProxyPort);
              
            break;
          case OID_IGD_S_VS_VP_SIP_PROXYSERVERTRANSPORT:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(5);
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              if(xProfSignaling.ucProxyProtocol == IFX_VMAPI_SIG_TRANSPORT_UDP)
                strcpy((pxParamVal[iCnt]).Value, "UDP");
              else if(xProfSignaling.ucProxyProtocol == 
                                    IFX_VMAPI_SIG_TRANSPORT_TCP)
                strcpy((pxParamVal[iCnt]).Value, "TCP");
              else if(xProfSignaling.ucProxyProtocol == 
                                    IFX_VMAPI_SIG_TRANSPORT_TLS)
                strcpy((pxParamVal[iCnt]).Value, "TLS");
              else if(xProfSignaling.ucProxyProtocol == 
                                    IFX_VMAPI_SIG_TRANSPORT_SCTP)
                strcpy((pxParamVal[iCnt]).Value, "SCTP");
              
            break;
          case OID_IGD_S_VS_VP_SIP_REGISTRARSERVER:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                sizeof(xProfSignaling.acRegistrarAddr));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              strcpy((pxParamVal[iCnt]).Value,
                                xProfSignaling.acRegistrarAddr);
              
            break;
          case OID_IGD_S_VS_VP_SIP_REGISTRARSERVERPORT:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                    sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", 
                          xProfSignaling.unRegistrarPort);
              
            break;
          case OID_IGD_S_VS_VP_SIP_REGISTRARSERVERTRANSPORT:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(5);
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              if(xProfSignaling.ucRegistrarProtocol == 
                                    IFX_VMAPI_SIG_TRANSPORT_UDP)
                strcpy((pxParamVal[iCnt]).Value, "UDP");
              else if(xProfSignaling.ucRegistrarProtocol == 
                                    IFX_VMAPI_SIG_TRANSPORT_TCP)
                strcpy((pxParamVal[iCnt]).Value, "TCP");
              else if(xProfSignaling.ucRegistrarProtocol == 
                                    IFX_VMAPI_SIG_TRANSPORT_TLS)
                strcpy((pxParamVal[iCnt]).Value, "TLS");
              else if(xProfSignaling.ucRegistrarProtocol == 
                                    IFX_VMAPI_SIG_TRANSPORT_SCTP)
                strcpy((pxParamVal[iCnt]).Value, "SCTP");
              
            break;
          case OID_IGD_S_VS_VP_SIP_USERAGENTDOMAIN:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                sizeof(xProfSignaling.acUADomain));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
              /* Copy the value to allocated area */
              if(xProfSignaling.acUADomain[0] != 0){
              	strcpy((pxParamVal[iCnt]).Value,xProfSignaling.acUADomain);
	      }else{
              	strcpy((pxParamVal[iCnt]).Value,"domain");
	      }              
            break;
          case OID_IGD_S_VS_VP_SIP_USERAGENTPORT:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unUAPort);
              
            break;
          case OID_IGD_S_VS_VP_SIP_USERAGENTTRANSPORT:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(5);
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              if(xProfSignaling.ucUAProtocol == 
                                    IFX_VMAPI_SIG_TRANSPORT_UDP)
                strcpy((pxParamVal[iCnt]).Value, "UDP");
              else if(xProfSignaling.ucUAProtocol == 
                                    IFX_VMAPI_SIG_TRANSPORT_TCP)
                strcpy((pxParamVal[iCnt]).Value, "TCP");
              else if(xProfSignaling.ucUAProtocol == 
                                    IFX_VMAPI_SIG_TRANSPORT_TLS)
                strcpy((pxParamVal[iCnt]).Value, "TLS");
              else if(xProfSignaling.ucUAProtocol == 
                                    IFX_VMAPI_SIG_TRANSPORT_SCTP)
                strcpy((pxParamVal[iCnt]).Value, "SCTP");
              
            break;
          case OID_IGD_S_VS_VP_SIP_OUTBOUNDPROXY:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                sizeof(xProfSignaling.acOutboundProxyAddr));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              strcpy((pxParamVal[iCnt]).Value,
                                xProfSignaling.acOutboundProxyAddr);
              
            break;
          case OID_IGD_S_VS_VP_SIP_OUTBOUNDPROXYPORT:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", 
                            xProfSignaling.unOutboundProxyPort);
              
            break;
          case OID_IGD_S_VS_VP_SIP_ORGANIZATION:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                sizeof(xProfSignaling.acOrg));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              strcpy((pxParamVal[iCnt]).Value,
                                xProfSignaling.acOrg);
              
            break;
          case OID_IGD_S_VS_VP_SIP_REGISTRATIONPERIOD:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint32)+4);		//Invalid write fix
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d",
                             xProfSignaling.uiRegExpirationTime);
              
            break;
          case OID_IGD_S_VS_VP_SIP_TIMERT1:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unT1);
              
            break;
          case OID_IGD_S_VS_VP_SIP_TIMERT2:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unT2);
              
            break;
          case OID_IGD_S_VS_VP_SIP_TIMERT4:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unT4);

            break;
          case OID_IGD_S_VS_VP_SIP_TIMERA:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unTa);
              
            break;
          case OID_IGD_S_VS_VP_SIP_TIMERB:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unTb);
              
            break;
          case OID_IGD_S_VS_VP_SIP_TIMERC:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unTc);
              
            break;
          case OID_IGD_S_VS_VP_SIP_TIMERD:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unTd);
              
            break;
          case OID_IGD_S_VS_VP_SIP_TIMERE:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unTe);
              
            break;
          case OID_IGD_S_VS_VP_SIP_TIMERF:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unTf);
              
            break;
          case OID_IGD_S_VS_VP_SIP_TIMERG:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unTg);
              
            break;
          case OID_IGD_S_VS_VP_SIP_TIMERH:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unTh);
              
            break;
          case OID_IGD_S_VS_VP_SIP_TIMERI:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unTi);
              
            break;
          case OID_IGD_S_VS_VP_SIP_TIMERJ:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unTj);
              
            break;
          case OID_IGD_S_VS_VP_SIP_TIMERK:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unTk);
              
            break;
          case OID_IGD_S_VS_VP_SIP_INVITEEXPIRES:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", 
                               xProfSignaling.unInvExpires);
              
            break;
          case OID_IGD_S_VS_VP_SIP_REINVITEEXPIRES:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", 
                            xProfSignaling.unReInvExpires);
              
            break;
          case OID_IGD_S_VS_VP_SIP_REGISTEREXPIRES:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", 
                              xProfSignaling.unRegExpires);
              
            break;
          case OID_IGD_S_VS_VP_SIP_REGISTERSMINEXPIRES:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", 
                             xProfSignaling.unRegMinExpires);
              
            break;
          case OID_IGD_S_VS_VP_SIP_REGISTERRETRYINTERVAL:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", 
                                xProfSignaling.unRegRetryTime);
              
            break;
          case OID_IGD_S_VS_VP_SIP_INBOUNDAUTH:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                sizeof(xProfSignaling.ucInboundAuth));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              if(xProfSignaling.ucInboundAuth == 
                                  IFX_VMAPI_AUTH_METHOD_NONE)
                strcpy((pxParamVal[iCnt]).Value, "None");
              else if(xProfSignaling.ucInboundAuth == 
                                  IFX_VMAPI_AUTH_METHOD_DIGEST)
                strcpy((pxParamVal[iCnt]).Value, "Digest");
              
            break;
          case OID_IGD_S_VS_VP_SIP_INBOUNDAUTHUSERNAME:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                sizeof(xProfSignaling.acInbAuthUserName));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
            
              strcpy((pxParamVal[iCnt]).Value, 
                               xProfSignaling.acInbAuthUserName);
            break;
          case OID_IGD_S_VS_VP_SIP_INBOUNDAUTHPASSWORD:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                sizeof(xProfSignaling.acInbAuthPassword));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
            
              strcpy((pxParamVal[iCnt]).Value, 
                               xProfSignaling.acInbAuthPassword);
            break;
          case OID_IGD_S_VS_VP_SIP_USECODECPRIORITYINSDPRESPONSE:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(5);
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
            
              strcpy((pxParamVal[iCnt]).Value, "true");
            break;
          case OID_IGD_S_VS_VP_SIP_DSCPMARK:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uchar8)+4);		//Invalid write fix
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.ucSipDscp);
              
            break;
          case OID_IGD_S_VS_VP_SIP_VLANIDMARK:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(int32));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", 
                                   xProfSignaling.iSipVlanId);
              
            break;
          case OID_IGD_S_VS_VP_SIP_ETHERNETPRIORITYMARK:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uchar8));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", 
                             xProfSignaling.ucSipEthPriority);
              
            break;
          case OID_IGD_S_VS_VP_SIP_SIPEVENTSUBSCRIBENUMBEROFELEMENTS:
            
            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint32));
    
              x_IFX_VMAPI_ProfileEventSubsTable xProfileEvent;

              xProfileEvent.iid.pcpeId.Id = uiPCpeId;
              xProfileEvent.iid.cpeId.Id = xProfSignaling.iid.cpeId.Id ;
              xProfileEvent.iid.config_owner = IFX_TR69;

              /* Get all the ProfileEvent parameters using VMAPI */
              iRtn = ifx_get_ProfileEventSubsTable(&xProfileEvent,IFX_F_DEFAULT);

              /* Check for error */
              if (iRtn != IFX_CWMP_SUCCESS)
              {
                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to get values of all ifx_get_ProfileEventSubsTable"
                            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto cleanup;
              }
              ifx_vmapi_freeObjectList(&xProfileEvent,IFX_VMAPI_VP_EVENT_SUBSCR);
              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", 
                                xProfileEvent.ucNoOfSubscrElements);
            break;
          case OID_IGD_S_VS_VP_SIP_SIPRESPONSEMAPNUMBEROFELEMENTS:

            break;
    default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                iTmpCnt = iCnt;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
            goto cleanup;
        }
    }

cleanup:

    if (iMemErrorFlag)
    {
        (pxParamVal[iCnt]).iFaultCode = ERR_OUT_OF_MEMORY;
        iRet = ERR_OUT_OF_MEMORY;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Allocation Failure\n",
                     __FILE__, __func__, __LINE__, iRet);
    }

    if (iRet != IFX_CWMP_SUCCESS)
    {

        /* Free the allocation for value, if any. Also set the fault code. */
        for (iCnt = 0; iCnt < iElements; iCnt++)
        {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
            if (iTmpCnt != iCnt) 
            {
                (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
            }
        }
    }

    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : Modify
**
**   Description      : This function modifies the values of parameters in 
**                      DeviceInfo object. It calls respective Management API  
**                      for the same. It performs modification only if parameter 
**                      has Write permission. In certain cases it also performs 
**                      modification of values of parameters that do not have
**                      Write permissions but the caller is the protocol stack.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      modified.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When modification of all parameters
**                      is successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in modifying at least one parameter.
**
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
Modify(IN int32 iCaller, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet         = IFX_CWMP_SUCCESS;
    int32   iRtn         = IFX_SUCCESS;
    int32   iCnt         = 0;
    int32   iParamOffset;
    int32   iOID;
    x_IFX_VMAPI_ProfileSignaling xProfSignaling;
    uint32 uiPCpeId;

    /* NOTE: For all parameters fault code is set to success by default. If error in
       validating first parameter, fault code is set to the error type and other
       parameters are not validated. */

    /* Set the fault code to Success for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
    }

    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);

    memset(&xProfSignaling, 0, sizeof(x_IFX_VMAPI_ProfileSignaling));

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_SIP:{

            char8 sOidString[100] = {0};
            IFX_CpeId *pxCpeIdArray = NULL;
            unsigned int uiNumCpeId;

            /* Get the Parent CPE Id */
            IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT &uiPCpeId);
            xProfSignaling.iid.pcpeId.Id = uiPCpeId;

            /*ignore the last value as it will be a parameter and we need 
              only till the last instance*/
            iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );

            strcpy(xProfSignaling.iid.tr69Id,sOidString);

            /*Get the CPE Id from the corresponding tr69 Id */
            iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId,
                               OUT &pxCpeIdArray);
            if(iRet != IFX_CWMP_SUCCESS){
                   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                   __func__, __LINE__);

              return ERR_CWMP_INTERNAL;
            }
            printf("CPEID is %d\n",pxCpeIdArray->uiId);   

            /* Fill the CPE ID of the object instance */
            xProfSignaling.iid.cpeId.Id = pxCpeIdArray->uiId;
            xProfSignaling.iid.config_owner = IFX_TR69;

            /* Get all the Profile Signaling parameters using VMAPI */
            iRtn = ifx_get_ProfileSignaling(&xProfSignaling, IFX_F_DEFAULT);

            IFX_CWMP_FREE(pxCpeIdArray);

            /* Check for error */
            if (iRtn != IFX_CWMP_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to get values of all "
                            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto cleanup;
            }
            }
            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_S_VS_VP_SIP_PROXYSERVER:
              if(strlen((char8*)pxParamVal[iCnt].Value) != 0)
              {
                xProfSignaling.bEnableProxy = IFX_TR104_TRUE;
                strncpy(xProfSignaling.acProxyAddr,pxParamVal[iCnt].Value,(IFX_VMAPI_MAX_TRANS_ADDR_LEN-1)); 
              }
              else
              {
                xProfSignaling.bEnableProxy = IFX_TR104_FALSE;
                memset(xProfSignaling.acProxyAddr,0,sizeof(xProfSignaling.acProxyAddr)); 
              }
              break;
            case OID_IGD_S_VS_VP_SIP_PROXYSERVERPORT:
                xProfSignaling.unProxyPort = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_PROXYSERVERTRANSPORT:

              if(!strncasecmp(pxParamVal[iCnt].Value,"UDP",3))
                xProfSignaling.ucProxyProtocol = IFX_VMAPI_SIG_TRANSPORT_UDP; 
              if(!strncasecmp(pxParamVal[iCnt].Value,"TCP",3))
                xProfSignaling.ucProxyProtocol = IFX_VMAPI_SIG_TRANSPORT_TCP; 
              if(!strncasecmp(pxParamVal[iCnt].Value,"TLS",3))
                xProfSignaling.ucProxyProtocol = IFX_VMAPI_SIG_TRANSPORT_TLS; 
              if(!strncasecmp(pxParamVal[iCnt].Value,"SCTP",4))
                xProfSignaling.ucProxyProtocol = IFX_VMAPI_SIG_TRANSPORT_SCTP; 

              break;
            case OID_IGD_S_VS_VP_SIP_REGISTRARSERVER:
              if(strlen((char8*)pxParamVal[iCnt].Value) != 0)
              {
                xProfSignaling.bEnableRegistrar = IFX_TR104_TRUE;
                strncpy(xProfSignaling.acRegistrarAddr,pxParamVal[iCnt].Value, (IFX_VMAPI_MAX_TRANS_ADDR_LEN-1)); 
              }
              else
              {
                xProfSignaling.bEnableRegistrar = IFX_TR104_FALSE;
                //strcpy(xProfSignaling.acRegistrarAddr,pxParamVal[iCnt].Value); 
                memset(xProfSignaling.acRegistrarAddr,0,sizeof(xProfSignaling.acRegistrarAddr)); 
              }
              break;
            case OID_IGD_S_VS_VP_SIP_REGISTRARSERVERPORT:
                xProfSignaling.unRegistrarPort = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_REGISTRARSERVERTRANSPORT:

              if(!strncasecmp(pxParamVal[iCnt].Value,"UDP",3))
                xProfSignaling.ucRegistrarProtocol = 
                                      IFX_VMAPI_SIG_TRANSPORT_UDP; 
              if(!strncasecmp(pxParamVal[iCnt].Value,"TCP",3))
                xProfSignaling.ucRegistrarProtocol = 
                                      IFX_VMAPI_SIG_TRANSPORT_TCP; 
              if(!strncasecmp(pxParamVal[iCnt].Value,"TLS",3))
                xProfSignaling.ucRegistrarProtocol = 
                                      IFX_VMAPI_SIG_TRANSPORT_TLS; 
              if(!strncasecmp(pxParamVal[iCnt].Value,"SCTP",4))
                xProfSignaling.ucRegistrarProtocol = 
                                      IFX_VMAPI_SIG_TRANSPORT_SCTP; 

              break;
            case OID_IGD_S_VS_VP_SIP_USERAGENTDOMAIN:
                strncpy(xProfSignaling.acUADomain,pxParamVal[iCnt].Value, (IFX_VMAPI_MAX_DOMAIN_NAME_LEN-1)); 
              break;
            case OID_IGD_S_VS_VP_SIP_USERAGENTPORT:
                xProfSignaling.unUAPort = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_USERAGENTTRANSPORT:

              if(!strncasecmp(pxParamVal[iCnt].Value,"UDP",6))
                xProfSignaling.ucUAProtocol = 
                                      IFX_VMAPI_SIG_TRANSPORT_UDP; 
              if(!strncasecmp(pxParamVal[iCnt].Value,"TCP",6))
                xProfSignaling.ucUAProtocol = 
                                      IFX_VMAPI_SIG_TRANSPORT_TCP; 
              if(!strncasecmp(pxParamVal[iCnt].Value,"TLS",6))
                xProfSignaling.ucUAProtocol = 
                                      IFX_VMAPI_SIG_TRANSPORT_TLS; 
              if(!strncasecmp(pxParamVal[iCnt].Value,"SCTP",6))
                xProfSignaling.ucUAProtocol = 
                                      IFX_VMAPI_SIG_TRANSPORT_SCTP; 

              break;
            case OID_IGD_S_VS_VP_SIP_OUTBOUNDPROXY:
              strncpy(xProfSignaling.acOutboundProxyAddr,
                                      pxParamVal[iCnt].Value, (IFX_VMAPI_MAX_TRANS_ADDR_LEN-1)); 
              break;
            case OID_IGD_S_VS_VP_SIP_OUTBOUNDPROXYPORT:
              xProfSignaling.unOutboundProxyPort = 
                                 atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_ORGANIZATION:
              strncpy(xProfSignaling.acOrg,pxParamVal[iCnt].Value, (IFX_VMAPI_MAX_USER_NAME_LEN-1)); 
              break;
            case OID_IGD_S_VS_VP_SIP_REGISTRATIONPERIOD:
              xProfSignaling.uiRegExpirationTime = 
                                 atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_TIMERT1:
              xProfSignaling.unT1 = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_TIMERT2:
              xProfSignaling.unT2 = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_TIMERT4:
              xProfSignaling.unT4 = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_TIMERA:
              xProfSignaling.unTa = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_TIMERB:
              xProfSignaling.unTb = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_TIMERC:
              xProfSignaling.unTc = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_TIMERD:
              xProfSignaling.unTd = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_TIMERE:
              xProfSignaling.unTe = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_TIMERF:
              xProfSignaling.unTf = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_TIMERG:
              xProfSignaling.unTg = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_TIMERH:
              xProfSignaling.unTh = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_TIMERI:
              xProfSignaling.unTi = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_TIMERJ:
              xProfSignaling.unTj = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_TIMERK:
              xProfSignaling.unTk = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_INVITEEXPIRES:
              xProfSignaling.unInvExpires = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_REINVITEEXPIRES:
              xProfSignaling.unReInvExpires = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_REGISTEREXPIRES:
              xProfSignaling.unRegExpires = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_REGISTERSMINEXPIRES:
              xProfSignaling.unRegMinExpires = atoi(pxParamVal[iCnt].Value); 
              printf("[%s %d] RegMin is %d\n",__FUNCTION__, __LINE__, xProfSignaling.unRegMinExpires);
              break;
            case OID_IGD_S_VS_VP_SIP_REGISTERRETRYINTERVAL:
              xProfSignaling.unRegRetryTime = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_INBOUNDAUTH:
              xProfSignaling.ucInboundAuth = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_INBOUNDAUTHUSERNAME:
              strncpy(xProfSignaling.acInbAuthUserName, pxParamVal[iCnt].Value, (IFX_VMAPI_MAX_USER_NAME_LEN-1)); 
              break;
            case OID_IGD_S_VS_VP_SIP_INBOUNDAUTHPASSWORD:
              strncpy(xProfSignaling.acInbAuthPassword, pxParamVal[iCnt].Value, (IFX_VMAPI_MAX_USER_PASSWD_LEN-1)); 
              break;
            case OID_IGD_S_VS_VP_SIP_DSCPMARK:
                xProfSignaling.ucSipDscp = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_VLANIDMARK:
                xProfSignaling.iSipVlanId = atoi(pxParamVal[iCnt].Value); 
              break;
            case OID_IGD_S_VS_VP_SIP_ETHERNETPRIORITYMARK:
                xProfSignaling.ucSipEthPriority = atoi(pxParamVal[iCnt].Value); 
              break;
          case OID_IGD_S_VS_VP_SIP_USECODECPRIORITYINSDPRESPONSE:
                if((!strncasecmp(pxParamVal[iCnt].Value,"true",4))||
                           atoi(pxParamVal[iCnt].Value) == 1)
                    xProfSignaling.bAnnounceMethod = IFX_VMAPI_CODEC_ANNOUNCE_AS_PER_PRIORITY; 
                else if((!strncasecmp(pxParamVal[iCnt].Value,"false",5)) ||
                           atoi(pxParamVal[iCnt].Value) == 0)
                    xProfSignaling.bAnnounceMethod = IFX_VMAPI_CODEC_ANNOUNCE_RANDOM_ORDER; 

              break;

            case OID_IGD_S_VS_VP_SIP_SIPEVENTSUBSCRIBENUMBEROFELEMENTS:
            case OID_IGD_S_VS_VP_SIP_SIPRESPONSEMAPNUMBEROFELEMENTS:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_PARAM_NOT_SUPPORTED;
                iRet = ERR_CWMP_PARAM_NOT_SUPPORTED;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Parameter Not Supported\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;  
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_SIP:

            /* Fill the iid structure in PROFILE_SIGNALING */
            xProfSignaling.iid.config_owner = IFX_TR69;

            /* Set all the PROFILE_SIGNALING  parameters using VMAPI */
            iRtn = ifx_set_ProfileSignaling(IFX_OP_MOD, &xProfSignaling, IFX_F_DEFAULT);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to set values of all "
                            "parameters\n", __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
            }

            break;
        default:
            /* Will never come here since already checked above */
            break;
    }

cleanup:
    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : Validate
**
**   Description      : This function validates the values of parameters in
**                      DeviceInfo object.
**
**   Parameters       : pxParamVal - List of parameters whose values need to be
**                      validated.
**                      iElements - Number of parameters in the above list.
**
**   Return Value     : IFX_CWMP_SUCCESS - When validation of all parameters is
**                      successful.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in validating at least one parameter.
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
Validate(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : GetModifyDep
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
GetModifyDep(INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    return (IFX_CWMP_SUCCESS);
}

/* 
** =============================================================================
**   Function Name    : IFX_ProfileSignaling_ChkDelDep
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
static int32
IFX_ProfileSignaling_ChkDelDep(IN int32 iCaller, IN ParamVal *pxParamVal,
              IN int32 iNumElem, OUT void **ppxParamStructRet,
                           OUT int32 * piNumRetElem)
{

  uint32 i=0;
  int32 iRet=0;
  uint32 uiParamPos=0;
  ParamVal *Param_DepOids=NULL;

  int32 prof_event_OID[OID_LENGTH] = {0,0,0,0,0,0,OID_IGD_S_VS_VP_SIP,OID_IGD_S_VS_VP_SIP_ES,
                  MAGIC_NUMBER};

  Param_DepOids = IFIN_CWMP_MALLOC((SIP_NO_DEP_OIDS+1)* sizeof(ParamVal));
  if(Param_DepOids == NULL){  
    iRet = ERR_OUT_OF_MEMORY; 
    goto errorHandler;
  }

  uiParamPos = IFX_GetParamIdPos(pxParamVal->iaOID);
      
  memcpy((Param_DepOids+0)->iaOID,prof_event_OID,(sizeof(int32)*OID_LENGTH));
  memcpy((Param_DepOids+1)->iaOID,pxParamVal->iaOID,
                (sizeof(int32)*(uiParamPos+1)));

  for(i=0; i <SIP_NO_DEP_OIDS; ++i)
    memcpy((Param_DepOids+i)->iaOID,pxParamVal->iaOID,
            (sizeof(int32)*(uiParamPos+1)));
    *ppxParamStructRet = (void *)Param_DepOids;
    *piNumRetElem = SIP_NO_DEP_OIDS+1;
    return IFIN_CWMP_SUCCESS;
  
  errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d failed!\n", __func__, __LINE__);
    
    return IFIN_CWMP_FAILURE;
    

}


/* 
** =============================================================================
**   Function Name    : IFX_ProfileSignaling_AddDel
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
int32
IFX_ProfileSignaling_AddDel(IN int32 iCaller, 
                            IN ParamVal *pxParamVal, 
                            IN int32 iNumElem, 
                            IN int32 operation)
{
    int32   iRet = IFIN_CWMP_SUCCESS,iCnt = 0, iParamOffset;
    char sOidString[IFX_MAX_TR69_ID_LEN];
    unsigned int uiNumCpeId,uiPCpeId;
    IFX_CpeId *pxCpeIdArray = NULL;
    x_IFX_VMAPI_ProfileSignaling xProfSignaling;
  
    memset(sOidString,0x00,IFX_MAX_TR69_ID_LEN);
    memset(&xProfSignaling,0,sizeof(xProfSignaling));

    /* Get the Parent CPE Id */
    IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT &uiPCpeId);
    xProfSignaling.iid.pcpeId.Id = uiPCpeId;

    /* if neither delete nor add operation */ 
    if((operation != OP_SETVAL_ADD)&&(operation != OP_SETVAL_DELETE)){ 
          IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] Invalid operation\n",
                   __func__, __LINE__);
      return ERR_CWMP_INTERNAL;
    }    
   
    /* if delete operation */
    if(operation == OP_SETVAL_DELETE)
    { 
      /*get cpeid, pass to delete function- here input iaOID will be igd.l3f.f.2.
      ignore the last value as it will be a parameter and  we need only till 
      the last instance*/
      iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );
      iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId, OUT &pxCpeIdArray);
     
      if(iRet != IFX_CWMP_SUCCESS)
      {
       IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
       "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n", __func__, __LINE__);
       return ERR_CWMP_INTERNAL;
      }
      /* Get the Cpe Id*/  
      xProfSignaling.iid.cpeId.Id = pxCpeIdArray->uiId;
      memset(xProfSignaling.iid.tr69Id,0x00,MAX_TR69_ID_LEN);
      
      if(strlen(pxCpeIdArray->sSectionTag) < MAX_TAG_LEN)
      {
        strncpy(xProfSignaling.iid.cpeId.secName,pxCpeIdArray->sSectionTag, MAX_TAG_LEN-1);
        IFX_CWMP_FREE(pxCpeIdArray);
      }
      else
      {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
        "[%s:%d] [Error] strcpy : mismatch in size in buffer copy\n",
         __func__, __LINE__);
        IFX_CWMP_FREE(pxCpeIdArray);
        return ERR_CWMP_INTERNAL;
      }
      /* Get the Profile Id*/    
      xProfSignaling.ucProfileId = IFX_GetProfileId(pxParamVal->iaOID);  

      /* Fill the iid structure in VOICE_LINE */
      xProfSignaling.iid.config_owner = IFX_TR69;
      strncpy(xProfSignaling.iid.tr69Id,sOidString, MAX_TR69_ID_LEN-1);
      xProfSignaling.iid.tr69Id[MAX_TR69_ID_LEN-1] = '\0';

      /* call the respective VMAPI */
      iRet =  ifx_set_ProfileSignaling(IFX_OP_DEL, &xProfSignaling, IFX_F_DEFAULT); 
      if(iRet != IFX_CWMP_SUCCESS)
      {
       IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
       "[%s:%d] [Error] ifx_set_ProfileSignaling failed\n",__func__, __LINE__);
         return ERR_CWMP_INTERNAL;
      }
      return iRet;

    }/*End of delete operation*/

    if(operation == OP_SETVAL_ADD)
    {  
      /*If ADD - the input iaOID will be igd.l3f.f.2. Ignore the last value as 
      it will be a parameter and we need only till the last instance*/
      iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );
      strncpy(xProfSignaling.iid.tr69Id,sOidString, MAX_TR69_ID_LEN-1);
      xProfSignaling.iid.tr69Id[MAX_TR69_ID_LEN-1] = '\0';
      IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,"[%s:%d] sOidString =%s\n",
              __func__, __LINE__, sOidString);

      /* Get the Profile Id*/    
      xProfSignaling.ucProfileId = IFX_GetProfileId(pxParamVal->iaOID);  
      /* Get the offset of the parameter */
      iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
      if (iParamOffset < 0)
      {
          iRet = ERR_CWMP_INTERNAL;
          IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
          goto cleanup;
      }
      // fill the given parameters of this structure with the new values provided
      for( iCnt = 0; iCnt < iNumElem; iCnt++)
      {
       /* Process based on the requested parameter */
        switch (pxParamVal[iCnt].iaOID[iParamOffset])
        {
            case OID_IGD_S_VS_VP_SIP_PROXYSERVER: 
            case OID_IGD_S_VS_VP_SIP_PROXYSERVERPORT: 
            case OID_IGD_S_VS_VP_SIP_PROXYSERVERTRANSPORT: 
            case OID_IGD_S_VS_VP_SIP_REGISTRARSERVER: 
            case OID_IGD_S_VS_VP_SIP_REGISTRARSERVERPORT: 
            case OID_IGD_S_VS_VP_SIP_REGISTRARSERVERTRANSPORT: 
            case OID_IGD_S_VS_VP_SIP_USERAGENTDOMAIN: 
            case OID_IGD_S_VS_VP_SIP_USERAGENTPORT: 
            case OID_IGD_S_VS_VP_SIP_USERAGENTTRANSPORT: 
            case OID_IGD_S_VS_VP_SIP_OUTBOUNDPROXY: 
            case OID_IGD_S_VS_VP_SIP_OUTBOUNDPROXYPORT: 
            case OID_IGD_S_VS_VP_SIP_ORGANIZATION: 
            case OID_IGD_S_VS_VP_SIP_REGISTRATIONPERIOD: 
            case OID_IGD_S_VS_VP_SIP_TIMERT1: 
            case OID_IGD_S_VS_VP_SIP_TIMERT2: 
            case OID_IGD_S_VS_VP_SIP_TIMERT4: 
            case OID_IGD_S_VS_VP_SIP_TIMERA: 
            case OID_IGD_S_VS_VP_SIP_TIMERB: 
            case OID_IGD_S_VS_VP_SIP_TIMERC: 
            case OID_IGD_S_VS_VP_SIP_TIMERD: 
            case OID_IGD_S_VS_VP_SIP_TIMERE: 
            case OID_IGD_S_VS_VP_SIP_TIMERF: 
            case OID_IGD_S_VS_VP_SIP_TIMERG: 
            case OID_IGD_S_VS_VP_SIP_TIMERH: 
            case OID_IGD_S_VS_VP_SIP_TIMERI: 
            case OID_IGD_S_VS_VP_SIP_TIMERJ: 
            case OID_IGD_S_VS_VP_SIP_TIMERK: 
            case OID_IGD_S_VS_VP_SIP_INVITEEXPIRES: 
            case OID_IGD_S_VS_VP_SIP_REINVITEEXPIRES: 
            case OID_IGD_S_VS_VP_SIP_REGISTEREXPIRES: 
            case OID_IGD_S_VS_VP_SIP_REGISTERSMINEXPIRES: 
            case OID_IGD_S_VS_VP_SIP_REGISTERRETRYINTERVAL: 
            case OID_IGD_S_VS_VP_SIP_INBOUNDAUTH: 
            case OID_IGD_S_VS_VP_SIP_INBOUNDAUTHUSERNAME:
            case OID_IGD_S_VS_VP_SIP_INBOUNDAUTHPASSWORD:
            case OID_IGD_S_VS_VP_SIP_USECODECPRIORITYINSDPRESPONSE:
            case OID_IGD_S_VS_VP_SIP_DSCPMARK:
            case OID_IGD_S_VS_VP_SIP_VLANIDMARK:
            case OID_IGD_S_VS_VP_SIP_ETHERNETPRIORITYMARK:
            case OID_IGD_S_VS_VP_SIP_SIPEVENTSUBSCRIBENUMBEROFELEMENTS:
            case OID_IGD_S_VS_VP_SIP_SIPRESPONSEMAPNUMBEROFELEMENTS:
                 break;
            default:
               IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           "[%s:%d] Unknown requested parameter %d\n",
                           __func__, __LINE__, pxParamVal[iCnt].iaOID[iParamOffset]);
               pxParamVal[iCnt].iFaultCode = ERR_INVAL_PARAMETER_NAME;
               goto cleanup;
         }
      } 
      /* Fill the iid structure in VOICE PROFILE */
      xProfSignaling.iid.config_owner = IFX_TR69;
      // call the VMAPI to modify
      iRet =  ifx_set_ProfileSignaling( IFX_OP_ADD, &xProfSignaling, IFX_F_DEFAULT); 
      if(iRet != IFX_CWMP_SUCCESS)
      {
             IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] ifx_set_ProfileServiceProviderInfo adding failed\n", 
                     __func__, __LINE__);
        iRet = ERR_CWMP_INTERNAL;
        goto cleanup;
      }
      return iRet;
    
    }/*End of add operation*/

cleanup:
    /* Perform Cleanup of unnecessary VoiceProfile members */
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : IFX_ProfileSignaling_UpdateChildInfo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32 
IFX_ProfileSignaling_UpdateChildInfo(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
              IN int32 iElements,IN int32 operation)
{
    int32   iRtn         = IFX_SUCCESS;
    uint32 i,iRet, iCnt;
    //char8 sSecTag[MAX_SECTIONTAG];
    //char8 sParamTag[MAX_PARAMTAG];
    uint32 uiParamPos,uiChildObjId;
    uint32 uiCpeid;
    int32 *iaOID=NULL;
    int32   iOID;
    //uint32 uiNumNV=1;
    //IFX_CpeId pxCpeId;
    //IFX_Id xIfx_Id;
    //IFX_NameValue pxNVArray;
    //uint32 uiOper=IFX_NOTIFY_OPER_MODIFY;
    //uint32 uiMode=IFX_CHK_FLAG_BASED;
    ParamVal *pxTempParamVal=pxParamVal;
    uint32 uiPCpeId;
    x_IFX_VMAPI_ProfileSignaling xProfSignaling;
    x_IFX_VMAPI_ProfileEventSubsTable xProfileEvent;


    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                "[%s:%d] \n", __func__, __LINE__);
    
    memset(&xProfSignaling, 0, sizeof(x_IFX_VMAPI_ProfileSignaling));
    memset(&xProfileEvent, 0, sizeof(x_IFX_VMAPI_ProfileEventSubsTable));
    
    /* Get the Parent CPE Id */
    IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT &uiPCpeId);
    xProfSignaling.iid.pcpeId.Id = uiPCpeId;
    xProfileEvent.iid.pcpeId.Id = uiPCpeId;
    
    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);


    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_SIP:{

            char8 sOidString[100] = {0};
            IFX_CpeId *pxCpeIdArray = NULL;
            unsigned int uiNumCpeId;

            xProfileEvent.ucProfileId = IFX_GetProfileId(pxParamVal->iaOID);  

            /*ignore the last value as it will be a parameter and we need 
              only till the last instance*/
            iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );

            strcpy(xProfSignaling.iid.tr69Id,sOidString);

            /*Get the CPE Id from the corresponding tr69 Id */
            iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId,
                               OUT &pxCpeIdArray);
            if(iRet != IFX_CWMP_SUCCESS){
                   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed for %s\n",
                   __func__, __LINE__,sOidString);

              return ERR_CWMP_INTERNAL;
            }

            /* Fill the CPE ID of the object instance */
            xProfSignaling.iid.cpeId.Id = pxCpeIdArray->uiId;
            xProfileEvent.iid.cpeId.Id = pxCpeIdArray->uiId;
            xProfileEvent.iid.config_owner = IFX_TR69;

            /* Get all the ProfileEvent parameters using VMAPI */
            iRtn = ifx_get_ProfileEventSubsTable(&xProfileEvent,IFX_F_DEFAULT);

            IFX_CWMP_FREE(pxCpeIdArray);

            /* Check for error */
            if (iRtn != IFX_CWMP_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to get values of all "
                            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                //goto cleanup;
                goto errorHandler;
            }
            }
            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            //goto cleanup;
            goto errorHandler;
    }

    /*Get Cpeid*/
    iRet = IFX_GetCpeId(pxTempParamVal->iaOID, &uiCpeid);
    if(iRet != IFX_CWMP_SUCCESS)
      goto errorHandler;

    //Get the offset of child object 
    uiChildObjId = IFX_GetParamOID((int32 *)pxTempParamVal->pReserved);
    iaOID = (int32 *)pxTempParamVal->pReserved;

    for(i=0; i < iElements; i++)
    {
       //Get the Param Oid of this object
       uiParamPos= IFX_GetParamOID(pxTempParamVal->iaOID);
      
       if(pxTempParamVal->iaOID[uiParamPos] == 
                       OID_IGD_S_VS_VP_SIP_SIPEVENTSUBSCRIBENUMBEROFELEMENTS)
       {
            if(operation == OP_SETVAL_ADD)
            {
              xProfileEvent.ucNoOfSubscrElements += 1;
            }
            else
              xProfileEvent.ucNoOfSubscrElements -= 1;
        }

      pxTempParamVal++;
      
    }
    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_SIP:

            /* Fill the iid structure in VOICE_PROFILE */
            xProfileEvent.iid.config_owner = IFX_TR69;
            xProfileEvent.ucProfileId = IFX_GetProfileId(pxParamVal->iaOID);  
            /* Get the Parent CPE Id */
            xProfileEvent.iid.pcpeId.Id = xProfileEvent.ucProfileId;
            
            /* Set all the PROFILE_EVENT  parameters using VMAPI */
            iRtn = ifx_set_ProfileEventSubsTable(IFX_OP_MOD,&xProfileEvent,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to set values of all "
                            "parameters in UpdateChildInfo\n", 
                            __FILE__, __func__, __LINE__, iRet);
                goto errorHandler;
            }

            break;
        default:
            /* Will never come here since already checked above */
            break;
    }
    return IFX_CWMP_SUCCESS;

errorHandler:
      IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d failed!\n", __func__, __LINE__);
      return IFX_CWMP_FAILURE;
      
}



/* 
** =============================================================================
**   Function Name    : GetNotify
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
GetNotify(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
                 IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iRtn = IFX_SUCCESS;
    int32   iCnt = 0;
    int32   iTmpCnt = -1; /* Mandatory */
    int32   iParamOffset;
    int32   iOID;
    int32   iMemErrorFlag = 0; /* Mandatory */
    x_IFX_VMAPI_ProfileSignaling xProfSignaling;
    uint32 uiPCpeId;


    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                "[%s:%d] \n", __func__, __LINE__);

    /* NOTE: For all parameters fault code is set to success by default. If error in
       validating first parameter, fault code is set to the error type and other
       parameters are not validated. */
    /* NOTE: For all parameters value is set to NULL by default. */

    /* Set the fault code to Success and value to NULL pointer for all parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_SUCCESS;
        (pxParamVal[iCnt]).Value = NULL;
    }

    /* Get the OID of the object whose parameter values are requested */
    iOID = IFX_GetObjectOID(pxParamVal->iaOID);

    memset(&xProfSignaling, 0, sizeof(x_IFX_VMAPI_ProfileSignaling));

    /* Process based on the object */
    switch (iOID)
    {
        case OID_IGD_S_VS_VP_SIP:{

            char8 sOidString[100] = {0};
            IFX_CpeId *pxCpeIdArray = NULL;
            unsigned int uiNumCpeId;

            /* Get the Parent CPE Id */
            IFX_GetParentObjCpeId(IN pxParamVal->iaOID, OUT &uiPCpeId);
            xProfSignaling.iid.pcpeId.Id = uiPCpeId;

            /*ignore the last value as it will be a parameter and we need 
              only till the last instance*/
            iRet = IFX_GetOIDArrayTillLastInst(pxParamVal->iaOID ,sOidString );

            strcpy(xProfSignaling.iid.tr69Id,sOidString);

            /*Get the CPE Id from the corresponding tr69 Id */
            iRet = IFX_GetCpeIdFromTr69Id(IN sOidString, OUT &uiNumCpeId,
                               OUT &pxCpeIdArray);
            if(iRet != IFX_CWMP_SUCCESS){
                   IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                   "[%s:%d] [Error] IFX_GetCpeIdFromTr69Id failed\n",
                   __func__, __LINE__);

              return ERR_CWMP_INTERNAL;
            }
            //printf("CPEID is %d\n",pxCpeIdArray->uiId);   

            /* Fill the CPE ID of the object instance */
            xProfSignaling.iid.cpeId.Id = pxCpeIdArray->uiId;
            xProfSignaling.iid.config_owner = IFX_TR69;

            /* Get all the Profile Signaling parameters using VMAPI */
            iRtn = ifx_get_ProfileSignaling(&xProfSignaling, IFX_F_DEFAULT);

            IFX_CWMP_FREE(pxCpeIdArray);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                /* Set the fault code to Failure for all parameters */
                for (iCnt = 0; iCnt < iElements; iCnt++)
                {
                    (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
                }

                iRet = IFX_CWMP_FAILURE;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unable to get values of all "
                            "parameters\n",__FILE__,  __func__, __LINE__, iRet);
                goto cleanup;
            }
            }
            break;
        default:
            /* Actually should never come here */
            iRet = ERR_CWMP_OBJ_NOT_SUPPORTED;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to process the requested "
                        "object\n", __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamOID(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
          case OID_IGD_S_VS_VP_SIP_PROXYSERVER:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                sizeof(xProfSignaling.acProxyAddr));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              strcpy((pxParamVal[iCnt]).Value,
                                xProfSignaling.acProxyAddr);

              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
 
            break;
          case OID_IGD_S_VS_VP_SIP_PROXYSERVERPORT:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                    sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", 
                               xProfSignaling.unProxyPort);
                 
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_PROXYSERVERTRANSPORT:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(5);
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              if(xProfSignaling.ucProxyProtocol == IFX_VMAPI_SIG_TRANSPORT_UDP)
                strcpy((pxParamVal[iCnt]).Value, "UDP");
              else if(xProfSignaling.ucProxyProtocol == 
                                    IFX_VMAPI_SIG_TRANSPORT_TCP)
                strcpy((pxParamVal[iCnt]).Value, "TCP");
              else if(xProfSignaling.ucProxyProtocol == 
                                    IFX_VMAPI_SIG_TRANSPORT_TLS)
                strcpy((pxParamVal[iCnt]).Value, "TLS");
              else if(xProfSignaling.ucProxyProtocol == 
                                    IFX_VMAPI_SIG_TRANSPORT_SCTP)
                strcpy((pxParamVal[iCnt]).Value, "SCTP");
                         
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
  
            break;
          case OID_IGD_S_VS_VP_SIP_REGISTRARSERVER:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                sizeof(xProfSignaling.acRegistrarAddr));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              strcpy((pxParamVal[iCnt]).Value,
                                xProfSignaling.acRegistrarAddr);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_REGISTRARSERVERPORT:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                    sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", 
                          xProfSignaling.unRegistrarPort);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_REGISTRARSERVERTRANSPORT:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(5);
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              if(xProfSignaling.ucRegistrarProtocol == 
                                    IFX_VMAPI_SIG_TRANSPORT_UDP)
                strcpy((pxParamVal[iCnt]).Value, "UDP");
              else if(xProfSignaling.ucRegistrarProtocol == 
                                    IFX_VMAPI_SIG_TRANSPORT_TCP)
                strcpy((pxParamVal[iCnt]).Value, "TCP");
              else if(xProfSignaling.ucRegistrarProtocol == 
                                    IFX_VMAPI_SIG_TRANSPORT_TLS)
                strcpy((pxParamVal[iCnt]).Value, "TLS");
              else if(xProfSignaling.ucRegistrarProtocol == 
                                    IFX_VMAPI_SIG_TRANSPORT_SCTP)
                strcpy((pxParamVal[iCnt]).Value, "SCTP");
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
#if 1
          case OID_IGD_S_VS_VP_SIP_USERAGENTDOMAIN:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                sizeof(xProfSignaling.acUADomain));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              strcpy((pxParamVal[iCnt]).Value,
                                xProfSignaling.acUADomain);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_USERAGENTPORT:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unUAPort);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_USERAGENTTRANSPORT:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(5);
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              if(xProfSignaling.ucUAProtocol == 
                                    IFX_VMAPI_SIG_TRANSPORT_UDP)
                strcpy((pxParamVal[iCnt]).Value, "UDP");
              else if(xProfSignaling.ucUAProtocol == 
                                    IFX_VMAPI_SIG_TRANSPORT_TCP)
                strcpy((pxParamVal[iCnt]).Value, "TCP");
              else if(xProfSignaling.ucUAProtocol == 
                                    IFX_VMAPI_SIG_TRANSPORT_TLS)
                strcpy((pxParamVal[iCnt]).Value, "TLS");
              else if(xProfSignaling.ucUAProtocol == 
                                    IFX_VMAPI_SIG_TRANSPORT_SCTP)
                strcpy((pxParamVal[iCnt]).Value, "SCTP");
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_OUTBOUNDPROXY:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                sizeof(xProfSignaling.acOutboundProxyAddr));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              strcpy((pxParamVal[iCnt]).Value,
                                xProfSignaling.acOutboundProxyAddr);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_OUTBOUNDPROXYPORT:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", 
                            xProfSignaling.unOutboundProxyPort);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_ORGANIZATION:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                sizeof(xProfSignaling.acOrg));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              strcpy((pxParamVal[iCnt]).Value,
                                xProfSignaling.acOrg);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_REGISTRATIONPERIOD:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint32));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d",
                             xProfSignaling.uiRegExpirationTime);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_TIMERT1:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unT1);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_TIMERT2:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unT2);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_TIMERT4:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unT4);
             
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_TIMERA:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unTa);
                 
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
          
            break;
          case OID_IGD_S_VS_VP_SIP_TIMERB:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unTb);
                     
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
      
            break;
          case OID_IGD_S_VS_VP_SIP_TIMERC:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unTc);
                         
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
  
            break;
          case OID_IGD_S_VS_VP_SIP_TIMERD:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unTd);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_TIMERE:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unTe);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_TIMERF:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unTf);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_TIMERG:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unTg);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_TIMERH:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unTh);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_TIMERI:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unTi);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_TIMERJ:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unTj);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_TIMERK:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.unTk);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_INVITEEXPIRES:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", 
                               xProfSignaling.unInvExpires);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_REINVITEEXPIRES:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", 
                            xProfSignaling.unReInvExpires);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_REGISTEREXPIRES:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", 
                              xProfSignaling.unRegExpires);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_REGISTERSMINEXPIRES:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", 
                             xProfSignaling.unRegMinExpires);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_REGISTERRETRYINTERVAL:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uint16));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", 
                                xProfSignaling.unRegRetryTime);
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_INBOUNDAUTH:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                sizeof(xProfSignaling.ucInboundAuth));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              if(xProfSignaling.ucInboundAuth == 
                                  IFX_VMAPI_AUTH_METHOD_NONE)
                strcpy((pxParamVal[iCnt]).Value, "None");
              else if(xProfSignaling.ucInboundAuth == 
                                  IFX_VMAPI_AUTH_METHOD_DIGEST)
                strcpy((pxParamVal[iCnt]).Value, "Digest");
                           
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_INBOUNDAUTHUSERNAME:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                sizeof(xProfSignaling.acInbAuthUserName));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
            
              strcpy((pxParamVal[iCnt]).Value, 
                               xProfSignaling.acInbAuthUserName);
             
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_INBOUNDAUTHPASSWORD:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                sizeof(xProfSignaling.acInbAuthPassword));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
            
              strcpy((pxParamVal[iCnt]).Value, 
                               xProfSignaling.acInbAuthPassword);
             
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_USECODECPRIORITYINSDPRESPONSE:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(5);
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
            
              strcpy((pxParamVal[iCnt]).Value, "true");
             
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

            break;
          case OID_IGD_S_VS_VP_SIP_DSCPMARK:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uchar8));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", xProfSignaling.ucSipDscp);
                 
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
          
            break;
          case OID_IGD_S_VS_VP_SIP_VLANIDMARK:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(int32));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", 
                                   xProfSignaling.iSipVlanId);
                     
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
      
            break;
          case OID_IGD_S_VS_VP_SIP_ETHERNETPRIORITYMARK:

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(
                                   sizeof(uchar8));
                
              /* Check for error */
              if (!((pxParamVal[iCnt]).Value))
              {
                  /* Set the memory error flag */
                  iMemErrorFlag = 1;
                  iTmpCnt = iCnt;
                  goto cleanup;
              }

              /* Copy the value to allocated area */
              sprintf((pxParamVal[iCnt]).Value, "%d", 
                             xProfSignaling.ucSipEthPriority);
                         
              iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);

              /* Check for error */
              if (iRet != IFX_CWMP_SUCCESS)
              {
                  iTmpCnt = iCnt;
                  goto cleanup;
              }
  
            break;
          case OID_IGD_S_VS_VP_SIP_SIPEVENTSUBSCRIBENUMBEROFELEMENTS:

            break;
          case OID_IGD_S_VS_VP_SIP_SIPRESPONSEMAPNUMBEROFELEMENTS:

            break;
#endif
    default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                iTmpCnt = iCnt;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
            goto cleanup;
        }
    }

cleanup:

    if (iMemErrorFlag)
    {
        (pxParamVal[iCnt]).iFaultCode = ERR_OUT_OF_MEMORY;
        iRet = ERR_OUT_OF_MEMORY;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Allocation Failure\n",
                     __FILE__, __func__, __LINE__, iRet);
    }

    if (iRet != IFX_CWMP_SUCCESS)
    {

        /* Free the allocation for value, if any. Also set the fault code. */
        for (iCnt = 0; iCnt < iElements; iCnt++)
        {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
            if (iTmpCnt != iCnt) 
            {
                (pxParamVal[iCnt]).iFaultCode = IFX_CWMP_FAILURE;
            }
        }
    }

    return (iRet);

    //int32   iRet = IFX_CWMP_SUCCESS;
    //return (iRet);
}

/* 
** =============================================================================
**   Function Name    : SetAttrInfo
**
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
  int32 iRet,i;
  iRet = IFX_SetAttributesInfo(pxOI, pxParamVal, iElements);
    if(iRet != IFX_CWMP_SUCCESS)
      goto errorHandler;

  for(i=0; i < iElements; i++)
    IFX_CWMP_FREE(pxParamVal->Value);

  return IFX_CWMP_SUCCESS;

  errorHandler:
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d failed!\n", __func__, __LINE__);
    return iRet;
}
/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : IFX_ProfileSignaling_Init
**
**   Description      : This function is called by the controller. It registers
**                      the function responsible for handling VoiceLine object
**                      with data structure. It also performs initializations
**                      specific to VoiceLine object.
**
**   Parameters       : No Parameters. 
**
**   Return Value     : IFX_CWMP_SUCCESS - When VoiceLine object is initialized
**                      successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When there
**                      is failure in initializing VoiceLine object.
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_ProfileSignaling_Init(void)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    /* Register the VoiceLine module function pointer in the object model */
    iRet = ifx_ds_register_function(IFX_PROFILESIGNALING_OBJ, IFX_ProfileSignaling);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_PROFILESIGNALING_OBJ);
        goto cleanup;
    }

cleanup:
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_ProfileSignaling
**
**   Description      : This function is called by the controller. It handles
**                      the VoiceLine object and performs  based on requested
**                      operations/suboperations by invoking internal functions.
**
**   Parameters       : pxOI - States the requested operation and suboperation.
**                      pParamList - List of parameters of the object on which
**                      requested operation/suboperation is performed.
**                      iNumElem - Number of parameters in the parameter list.
**                      ppRet - Reserved for future use.
**                      piNumRetElem - Reserved for future use.
**   Return Value     : IFX_CWMP_SUCCESS - When the operation/suboperation is
**                      performed successfully.
**                      IFX_CWMP_FAILURE ( or other error codes) - When the
**                      operation/suboperation is not performed successfully.
**
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_ProfileSignaling(IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
             OUT void **ppRet, OUT int32 *piNumRetElem)
{
    int32       iRet           = IFX_CWMP_SUCCESS;
    ParamVal    *pxParamVal    = (ParamVal *)pParamList;

    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                "[%s:%d] \n", __func__, __LINE__);
    /* Process based on type of Operation */
    switch (pxOI->iOper)
    {
        case OP_GETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:

                    /* Get values of all the requested parameters */
                    iRet = GetVal(pxOI->iCaller, pxParamVal,
                                               iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_GETVAL_NOTIFICATION:

                    /* Set attribute values for all the requested parameters */
                    iRet = GetNotify(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_SETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:

                    /* Validate values of all the requested parameters */
                    iRet = Validate(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:

                   /* Check modify dependency of all requested parameters */
                    iRet = GetModifyDep(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_MODIFY:

                    /* Set values of all the requested parameters */
                    iRet = Modify(pxOI->iCaller, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ATTRINFO:

                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_ADD:
                    iRet = IFX_ProfileSignaling_AddDel(pxOI->iCaller,pxParamVal, 
                              iNumElem, OP_SETVAL_ADD); // 1 = add 0=del

                    /* Check for error */
                    if (iRet != IFIN_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }
                   break;
                case OP_SETVAL_CHK_DEL_DEP:

                   iRet = IFX_ProfileSignaling_ChkDelDep(pxOI->iCaller, pxParamVal,
                              iNumElem, ppRet, piNumRetElem);

                   /* Check for error */
                    if (iRet != IFIN_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }


                    //*ppRet = (ParamVal *)IFX_CWMP_MALLOC(sizeof(ParamVal));
                    //memcpy(*ppRet, pParamList, sizeof(ParamVal));
                    //*piNumRetElem = 1;
                    //return IFX_CWMP_SUCCESS;

                   break;
                case OP_SETVAL_CHK_DEL_ALLOWED:
                    return IFX_CWMP_SUCCESS;

                   break;
                case OP_SETVAL_DELETE:
                    iRet = IFX_ProfileSignaling_AddDel(pxOI->iCaller,pxParamVal, 
                              iNumElem, OP_SETVAL_DELETE); // 1 = add 0=del

                    /* Check for error */
                    if (iRet != IFIN_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }
                break;
                case OP_SETVAL_FREE:
                    return IFX_CWMP_SUCCESS;

                break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_UPDATE_CHILDINFO:
              /* Process based on type of SubOperation */
              switch(pxOI->iSubOper)
              {
                case OP_UPDATE_CHILDINFO_ADD: 
                    if((iRet =IFX_ProfileSignaling_UpdateChildInfo(pxOI,pxParamVal,
                                       iNumElem,OP_SETVAL_ADD)) != IFX_CWMP_SUCCESS)
                     {
                       IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "%s:%d OP_UPDATE_CHILDINFO_ADD failed!\n", __func__, __LINE__);
                        goto cleanup;
                
                    }
                  break;
                case OP_UPDATE_CHILDINFO_DEL:
                    if((iRet =IFX_ProfileSignaling_UpdateChildInfo(pxOI,pxParamVal,
                                   iNumElem,OP_SETVAL_DELETE)) != IFX_CWMP_SUCCESS)
                     {
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                               "%s:%d OP_UPDATE_CHILDINFO_DEL failed!\n", __func__, __LINE__);
                        goto cleanup;

                    }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid Operation\n",
                         __func__, __LINE__, iRet);
            goto cleanup;
    }

cleanup:
    return (iRet);
}
