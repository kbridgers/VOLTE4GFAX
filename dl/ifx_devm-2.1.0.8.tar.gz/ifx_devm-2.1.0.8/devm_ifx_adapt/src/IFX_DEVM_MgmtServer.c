/* 
** =============================================================================
**   FILE NAME        : IFIN_MgmtServer.c
**   PROJECT          : TR69
**   MODULES          : ManagementServer
**   DATE             : 28-03-2006
**   AUTHOR           : TR69 team
**   DESCRIPTION      : This is the ManagementServer Module. It is required by
**                      the controller module of TR69 stack to GET/SET Device
**                      specific information.
**
**   REFERENCES       : < List of design docs covering this file >
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
**   HISTORY          : 
**   $Date            $Author                         $Comment
**   28-03-2006       TR69 team                       Initial Version
**
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "IFX_DEVM_MgmtServer.h"
  // Required for STATIC
 
#include "IFX_DEVM_OID.h"
#include <ctype.h>
#include "IFX_DEVM_Platform.h"
#include "IFX_DEVM_DS.h"
#include "IFX_DEVM_Pseudo.h"
#include <unistd.h>
#include <stdlib.h> 
#include <time.h> 
 
#include "IFX_DEVM_STUN.h"

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFX_MGMTSERVER_OBJ            FORMNAME("ManagementServer.")
#define IFX_UTC_TIME_LEN              65
#define IFX_MINPERIODICINFORMINTERVAL 1

#define IFX_CHANGE_CONNREQ                 0x1
#define IFX_CHANGE_PERIODICINFORMINTERVAL  0x2
#define IFX_CHANGE_PERIODICINFORMENABLE    0x4
#define IFX_CHANGE_ACSURL                  0x8
#define IFX_CHANGE_ENABLECWMP		   0x10
#define IFX_CHANGE_ACSUNPW                 0x20

#if 1 // PeriodicInformTime
#define IFX_CHANGE_PERIODICINFORMTIME     0x40
#endif

#define IFX_CHANGE_STUNPARAM              0x10

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/

/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 gcaParameterKey[32];
extern int Pseudo_server_SockFd_TCP;
extern char8 vcOsModId;
extern int32 viTR69RdFd;
extern int32 iTR69Status;
#ifdef STUN_SUPPORT
extern int STUNEnable;
#endif
STATIC uint32 guiTimeout = 0;
STATIC uint32 guiEnabled = 0;
STATIC uint16 guiTimerId;
STATIC char8 gxMSurl[MAX_URL_LEN] = {0};

/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/
STATIC int32
GetVal(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
       IN int32 iElements);
STATIC int32
Validate(INOUT ParamVal * pxParamVal, IN int32 iElements);
STATIC int32
Modify(IN OperInfo *pxOpInfo, INOUT ParamVal * pxParamVal, IN int32 iElements);
int32
GetTimeInACSFormat(uint32 uiTime, char8 *psBuff);
STATIC int32
ValidateTimeInACSFormat(char8 *psBuff);
STATIC int32
GetTimeFromACSFormat(uint32 *puiTime, char8 *psBuff);
STATIC int32
ValidateURL(char8 *psBuff);
STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements);
STATIC int32
StartTimer(int32 iSecs, int32 iId);
STATIC int32
CancelTimer(IN int32 iId);
STATIC void
TimerCB(int32 iReason);
#ifndef DEVICE_SUPPORT
#ifdef DEVICE_ASSO_SUPPORT
static int32 
UpdateChildInfo(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements);
#endif /* DEVICE_ASSO_SUPPORT */
#endif /* DEVICE_SUPPORT */
/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/
STATIC void
TimerCB(int32 iReason)
{
    switch (iReason) {
        case TM_PERIODIC_TIMER_ID:
            if(IFX_IPC_SendMsg(viTR69RdFd, IFX_IPC_APP_ID_PERIODIC_INFORM,(uchar8)0,
                     strlen("Periodic Timer Msg")+1, 0,
                     (char8 *)"Periodic Timer Msg")== IFX_IPC_FAIL)
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] Error in sending Message\n",
                            __FILE__,  __func__, __LINE__);
            }
            if (guiEnabled == TRUE)
            {
                StartTimer(guiTimeout, TM_PERIODIC_TIMER_ID);
            }
            break;
        default:
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] Invalid TimerId %d\n",
                        __FILE__,  __func__, __LINE__, iReason);
            break;
    }
}
STATIC int32
StartTimer(int32 iSecs, int32 iId)
{
    uint32 uiErr;

    if((iId == TM_PERIODIC_TIMER_ID) && (iSecs > 29))
    {
        if(IFIN_TR69_StartTimer((iSecs * 1000), (void *)TimerCB,
                               (void *)iId, &guiTimerId, &uiErr) != IFIN_TR69_SUCCESS)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] Error starting TimerId %d\n",
                        __FILE__,  __func__, __LINE__, iId);
            return (IFX_CWMP_FAILURE);
        }
        else
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                        "[%s:%s:%d] Started Periodic Inform Timer-> ID = %d\n",
                        __FILE__,  __func__, __LINE__, guiTimerId);
            return (IFX_CWMP_SUCCESS);
        }
    }
    else
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] Invalid Input Params\n",
                    __FILE__,  __func__, __LINE__);
        return (IFX_CWMP_FAILURE);
    }
}

STATIC int32
CancelTimer(IN int32 iId)
{
    if(iId == TM_PERIODIC_TIMER_ID)
    {
        if(IFIN_TR69_StopTimer(guiTimerId) != IFIN_TR69_SUCCESS)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] Error stopping TimerId %d\n",
                        __FILE__,  __func__, __LINE__, iId);
            return (IFX_CWMP_FAILURE);
        }
        else
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_NORMAL,
                        "[%s:%s:%d] Stopped Periodic Inform Timer-> ID = %d\n",
                        __FILE__,  __func__, __LINE__, guiTimerId);
            return (IFX_CWMP_SUCCESS);
        }
    }
    else
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] Invalid Input Params\n",
                    __FILE__,  __func__, __LINE__);
        return (IFX_CWMP_FAILURE);
    }
}

/* 
** =============================================================================
**   Function Name    : GetVal
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
GetVal(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal,
       IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iRtn = IFX_SUCCESS;
    int32   iCnt = 0;
    MGMT_SERVER xMS;
    int32   iParamOffset;
    char8   sTmpBuff[12] = { 0 };
    char8   sTmpTime[IFX_UTC_TIME_LEN] = { 0 };

#ifndef DEVICE_SUPPORT
#ifdef DEVICE_ASSO_SUPPORT
     MANAGEABLE_DEVICE *paxManage_Dev=NULL;
     int32 uiNumOfEntries=0;
     uint32 iFlags=0;
#endif /* DEVICE_ASSO_SUPPORT */
#endif /* DEVICE_SUPPORT */
    
    memset(&xMS, 0, sizeof(MGMT_SERVER));

    /* Get all the MGMT_SERVER parameters using Protocol API */
    iRtn = ifx_get_mgmt_server(&xMS, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get values of all "
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamIdPos(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and fill the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(MAX_URL_LEN);

        /* Check for error */
        if (!((pxParamVal[iCnt]).Value))
        {
            iRet = ERR_OUT_OF_MEMORY;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Allocation Failure\n",
                         __FILE__, __func__, __LINE__, iRet);
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {

            case OID_IGD_MS_URL:

               /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xMS.url); 
                break;  
            case OID_IGD_MS_USERNAME:  

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xMS.uname); 
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;  
            case OID_IGD_MS_PASSWORD:  

                /* Passwords should be returned as blank if caller is not ROOT */
                if (pxOI->iCaller == ACC_ROOT)
                {

                   /* Copy the value to allocated area */
                    strcpy((pxParamVal[iCnt]).Value, xMS.passwd); 
                }
                else
                {
                    IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
                    (pxParamVal[iCnt]).Value = NULL;
                }
                break;  
            case OID_IGD_MS_PERIODICINFORMENABLE:  

                /* Get the value in string format */
                sprintf(sTmpBuff,"%d",xMS.period_inform_enable);

               /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, sTmpBuff); 
                break;  
            case OID_IGD_MS_PERIODICINFORMINTERVAL:  

                /* Get the value in string format */
                sprintf(sTmpBuff,"%u",xMS.period_inform_interval);

               /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, sTmpBuff); 
                break;  
            case OID_IGD_MS_PERIODICINFORMTIME:  

                /* Get the time in format required by ACS */
                GetTimeInACSFormat(xMS.period_abs_inform_time, sTmpTime);

                /* Copy the value to allocated area */
                strncpy((pxParamVal[iCnt]).Value, sTmpTime, IFX_UTC_TIME_LEN-1); 
		((char *)((pxParamVal[iCnt]).Value))[IFX_UTC_TIME_LEN - 1] = '\0';
                break;  
            case OID_IGD_MS_PARAMETERKEY:  

               /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xMS.parameter_key);
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;  
            case OID_IGD_MS_CONNECTIONREQUESTURL:  

               /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xMS.conn_req_url); 
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break;  
            case OID_IGD_MS_CONNECTIONREQUESTUSERNAME:  

               /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xMS.conn_req_uname); 
                break;  
            case OID_IGD_MS_CONNECTIONREQUESTPASSWORD:  

                /* Passwords should be returned as blank if caller is not ROOT */
                if (pxOI->iCaller == ACC_ROOT)
                {
                   /* Copy the value to allocated area */
                    strcpy((pxParamVal[iCnt]).Value, xMS.conn_req_passwd); 
                }
                else
                {
                    IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
                    (pxParamVal[iCnt]).Value = NULL;
                }
                break;  
            case OID_IGD_MS_UPGRADESMANAGED:  

                /* Get the value in string format */
                sprintf(sTmpBuff,"%d",xMS.upgrades_managed);

               /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, sTmpBuff); 
                break;  
            case OID_IGD_MS_KICKURL:
            case OID_IGD_MS_DOWNLOADPROGRESSURL:
                iRet = ERR_CWMP_PARAM_NOT_SUPPORTED;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Parameter Not Supported\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup; 

            /**** TR111 related parameters ***********/		
#ifdef STUN_SUPPORT
            case OID_IGD_MS_UDPCONNECTIONREQUESTADDRESS:  

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, xMS.udp_conn_req_url); 
                //iRet = IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_VALUE_BASED);
                IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
                break; 
            case OID_IGD_MS_UDPCONNECTIONREQUESTADDRESSNOTIFICATIONLIMIT:  

                /* Get the value in string format */
                sprintf(sTmpBuff,"%d",xMS.udp_conn_req_address_notification_limit);

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, sTmpBuff); 
                break; 
            case OID_IGD_MS_STUNENABLE:  

                /* Get the value in string format */
                sprintf(sTmpBuff,"%d",xMS.stun_enable);

                /* Copy the value to allocated area */
                strcpy((pxParamVal[iCnt]).Value, sTmpBuff); 
                break; 
            case OID_IGD_MS_STUNSERVERADDRESS:  

		strncpy((char8 *)pxParamVal[iCnt].Value,
			inet_ntoa(xMS.stun_server_address),
			(MAX_IP_ADDRRESS_LEN-1));
               	break; 

		case OID_IGD_MS_STUNSERVERPORT:  

	                /* Get the value in string format */
	                sprintf(sTmpBuff,"%d",xMS.stun_server_port);

	                /* Copy the value to allocated area */
	                strcpy((pxParamVal[iCnt]).Value, sTmpBuff); 
	                break; 
		case OID_IGD_MS_STUNUSERNAME:  

	                /* Copy the value to allocated area */
	                strcpy((pxParamVal[iCnt]).Value, xMS.stun_server_uname); 
	                break; 
				
		case OID_IGD_MS_STUNPASSWORD:  

			/* Passwords should be returned as blank if caller is not ROOT */
			if (pxOI->iCaller == ACC_ROOT)
			{

				/* Copy the value to allocated area */
				strcpy((pxParamVal[iCnt]).Value, xMS.stun_passwd); 
			}
			else
			{
				IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
				(pxParamVal[iCnt]).Value = NULL;
			}
			break;  

		case OID_IGD_MS_STUNMAXIMUMKEEPALIVEPERIOD:  

	                /* Get the value in string format */
	                sprintf(sTmpBuff,"%d",xMS.stun_max_keep_alive_period);

                        /* Copy the value to allocated area */
	                strcpy((pxParamVal[iCnt]).Value, sTmpBuff); 
	                break; 
		case OID_IGD_MS_STUNMINIMUMKEEPALIVEPERIOD:  

	                /* Get the value in string format */
	                sprintf(sTmpBuff,"%d",xMS.stun_min_keep_alive_period);

                /* Copy the value to allocated area */
	                strcpy((pxParamVal[iCnt]).Value, sTmpBuff); 
	                break; 
		case OID_IGD_MS_NATDETECTED:  

	                /* Get the value in string format */
	                sprintf(sTmpBuff,"%d",xMS.nat_detected);

                        /* Copy the value to allocated area */
	                strcpy((pxParamVal[iCnt]).Value, sTmpBuff); 
                	IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
	                break; 
#endif /* STUN_SUPPORT */
#ifndef DEVICE_SUPPORT	
#ifdef DEVICE_ASSO_SUPPORT
		case OID_IGD_MS_MANAGEABLEDEVICENUMBEROFENTRIES:
	 	
     		    iFlags = IFX_F_GET_ANY;
 		    ifx_get_all_manageable_devices(&uiNumOfEntries, &paxManage_Dev,iFlags);
                    IFX_CWMP_FREE (paxManage_Dev);
		    sprintf(sTmpBuff,"%d",uiNumOfEntries);
		    strcpy((pxParamVal[iCnt]).Value, sTmpBuff);	
	            IFX_CheckValueGotChanged(pxOI,  pxParamVal + iCnt, IFX_CHK_CHANGE_FLAG_BASED);
		    break;

		case OID_IGD_MS_MANAGEABLEDEVICENOTIFICATIONLIMIT:
	        	   sprintf(sTmpBuff,"%d",xMS.mngdevnotifylimit);

                        /* Copy the value to allocated area */
                        strcpy((pxParamVal[iCnt]).Value, sTmpBuff);
                        break;
#endif /* DEVICE_ASSO_SUPPORT */
#endif /* DEVICE_SUPPORT */
				
                 case OID_IGD_MS_ENABLECWMP:
                        sprintf(sTmpBuff, "%d", xMS.enable_cwmp);
                        strcpy((pxParamVal[iCnt]).Value, sTmpBuff);
                        break;
	
            default:
                iRet = ERR_CWMP_INVAL_PARAM_NAME;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [Error] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__);
                goto cleanup;
        }
    }

cleanup:

   return (iRet);
}

/* 
** =============================================================================
**   Function Name    : Modify
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/
STATIC int32
Modify(IN OperInfo *pxOpInfo, INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32   iRet         = IFX_CWMP_SUCCESS;
    int32   iRtn         = IFX_SUCCESS;
    int32   iCnt         = 0;
    MGMT_SERVER xMS;
    int32   iParamOffset;
    int32   iChange = 0;
    char8   *psTmpVal = NULL;
    uint32  uiTime;
    int32   iPeriodInformEnable = 0;
    int32   iEnableCWMP = 0, iActivate = 0;
    int32   iPeriodInformInterval = 0;
    char8   sConnReqUname[MAX_CONN_REQ_UNAME_LEN] = { 0 };
    char8   sConnReqPasswd[MAX_CONN_REQ_PASSWD_LEN] = { 0 };
    int32   iTimerStartFlag = 0;

    memset(&xMS, 0, sizeof(MGMT_SERVER));

    /* Get all the MGMT_SERVER parameters using Object API */
    iRtn = ifx_get_mgmt_server(&xMS, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_CWMP_SUCCESS)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get values of all "
                    "parameters\n", __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }
    xMS.iid.config_owner = pxOpInfo->iCaller;
    if(pxOpInfo->iSubOper == OP_SETVAL_MODIFY)
    {
        /* Get the offset of the parameter */
        iParamOffset = IFX_GetParamIdPos(pxParamVal->iaOID);
        if (iParamOffset < 0)
        {
            iRet = ERR_CWMP_INTERNAL;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
            goto cleanup;
        }

        /* Iterate and fill the requested parameters */
        for (iCnt = 0; iCnt < iElements; iCnt++)
        {
            psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

            /* Return a failure if the value is NULL pointer */
            if (!psTmpVal)
            {
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                iRet = ERR_CWMP_INVAL_ARGS;
                goto cleanup;
            }

            /* Process based on the requested parameter */
            switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
            {
                case OID_IGD_MS_URL:

                    /* Check if the string fits in the buffer */
                    if ((strlen(psTmpVal) + 1) > MAX_URL_LEN)
                    {
                        (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                        iRet = ERR_CWMP_INVAL_ARGS;
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                        goto cleanup;
                    }

                    if (strcmp(xMS.url, psTmpVal))
                        iChange |= IFX_CHANGE_ACSURL;
                    /* Copy the string */
                    strcpy(xMS.url,psTmpVal);
                    strcpy(gxMSurl,psTmpVal);
                    if(pxOpInfo->iCaller != ACC_TR69)
                    {
                        strcpy(xMS.url, gxMSurl);
                    }
                    break;
                case OID_IGD_MS_PASSWORD:
    
                    /* Check if the string fits in the buffer */
                    if ((strlen(psTmpVal) + 1) > MAX_PASSWORD_LEN)
                    {
                        (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                        iRet = ERR_CWMP_INVAL_ARGS;
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                 __LINE__, iRet);
                        goto cleanup;
                    }

                    if(strcmp(xMS.passwd,psTmpVal))
                        iChange |= IFX_CHANGE_ACSUNPW;
                    /* Copy the string */
                    strcpy(xMS.passwd,psTmpVal);
                    break;
                case OID_IGD_MS_USERNAME:
                if(strcmp(xMS.uname,psTmpVal))
                    iChange |= IFX_CHANGE_ACSUNPW;

                strcpy(xMS.uname, psTmpVal);
                break;
            case OID_IGD_MS_PERIODICINFORMENABLE:

                iPeriodInformEnable = xMS.period_inform_enable;
                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xMS.period_inform_enable = TRUE;
                }
                else
                {
                    xMS.period_inform_enable = FALSE;
                }

                if (iPeriodInformEnable != xMS.period_inform_enable)
                {
                    iChange  |= IFX_CHANGE_PERIODICINFORMENABLE;
                }
                break;
            case OID_IGD_MS_PERIODICINFORMINTERVAL:
                iPeriodInformInterval = xMS.period_inform_interval;
                xMS.period_inform_interval = atoi(psTmpVal);
                if (iPeriodInformInterval != xMS.period_inform_interval)
                {
                    iChange  |= IFX_CHANGE_PERIODICINFORMINTERVAL;
                }
                break;
            case OID_IGD_MS_PERIODICINFORMTIME:

                GetTimeFromACSFormat(&uiTime, psTmpVal);
            
#if 1 // PeriodicInformTime              
               if (xMS.period_abs_inform_time != uiTime)
		{
		     iChange  |= IFX_CHANGE_PERIODICINFORMTIME;  
                     xMS.period_abs_inform_time = uiTime;
		}
#else
		xMS.period_abs_inform_time = uiTime;        
#endif
		  break;
            case OID_IGD_MS_PARAMETERKEY:
                if ( pxOpInfo->iCaller == ACC_ROOT)
                {
		   
                    /* Check if the string fits in the buffer */
                    if ((strlen(psTmpVal) + 1) > MAX_PARAMETER_KEY_LEN)
                    {
                        (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                        iRet = ERR_CWMP_INVAL_ARGS;
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "[%s:%s:%d] [%d] Space not enough to hold "
                                    "requested value",__FILE__, __func__,
                                    __LINE__, iRet);
                        goto cleanup;
                    }

                    /* Copy the string */
                    strcpy(xMS.parameter_key, psTmpVal);
    		    /* Copy the string */
    	            strcpy(gcaParameterKey, psTmpVal);

                }
                else
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_NON_WRITABLE;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Cannot modify the parameter\n",
                                __func__, __LINE__, iRet);
                    goto cleanup;
                }
                break;
            case OID_IGD_MS_CONNECTIONREQUESTURL:
                if ( pxOpInfo->iCaller == ACC_ROOT)
                {
                    /* http only sets this value. Hence no notification should be
                       reported to ACS */
                    xMS.iid.config_owner = IFX_TR69;
                    /* Check if the string fits in the buffer */
                    if ((strlen(psTmpVal) + 1) > MAX_CONN_REQ_URL_LEN)
                    {
                        (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                        iRet = ERR_CWMP_INVAL_ARGS;
                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                    "[%s:%s:%d] [%d] Space not enough to hold "
                                    "requested value",__FILE__, __func__,
                                    __LINE__, iRet);
                        goto cleanup;
                    }

                    /* Copy the string */
                    strcpy(xMS.conn_req_url, psTmpVal);
                }
                else
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_NON_WRITABLE;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Cannot modify the parameter\n",
                                __func__, __LINE__, iRet);
                    goto cleanup;
                }
                break;
            case OID_IGD_MS_CONNECTIONREQUESTUSERNAME:

                strcpy(sConnReqUname, xMS.conn_req_uname);
                /* Check if the string fits in the buffer */
                if ((strlen(psTmpVal) + 1) > MAX_CONN_REQ_UNAME_LEN)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }

                /* Copy the string */
                strcpy(xMS.conn_req_uname, psTmpVal);

                if (strcmp(sConnReqUname, xMS.conn_req_uname))
                {
                    iChange |= IFX_CHANGE_CONNREQ;
                }
                break;
            case OID_IGD_MS_CONNECTIONREQUESTPASSWORD:

                strcpy(sConnReqPasswd, xMS.conn_req_passwd);
                /* Check if the string fits in the buffer */
                if ((strlen(psTmpVal) + 1) > MAX_CONN_REQ_PASSWD_LEN)
                { 
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%s:%d] [%d] Space not enough to hold "
                                "requested value",__FILE__, __func__,
                                __LINE__, iRet);
                    goto cleanup;
                }

                /* Copy the string */
                strcpy(xMS.conn_req_passwd, psTmpVal);

                if (strcmp(sConnReqPasswd, xMS.conn_req_passwd))
                {
                    iChange |= IFX_CHANGE_CONNREQ;
                }
                break;
            case OID_IGD_MS_UPGRADESMANAGED:

                if (!strcmp(psTmpVal, "true") ||
                    !strcmp(psTmpVal, "1"))
                {
                    xMS.upgrades_managed = TRUE;
                }
                else
                {
                    xMS.upgrades_managed = FALSE;
                }
                break;
            case OID_IGD_MS_KICKURL:
            case OID_IGD_MS_DOWNLOADPROGRESSURL:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_PARAM_NOT_SUPPORTED;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Parameter Not Supported\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;

		/**** TR111 related parameters ***********/		
#ifdef STUN_SUPPORT
		case OID_IGD_MS_UDPCONNECTIONREQUESTADDRESS:
	              if ( pxOpInfo->iCaller == ACC_ROOT)
                {     
    			xMS.iid.config_owner = IFX_WEB;
                     /* Check if the string fits in the buffer */
	                if ((strlen(psTmpVal) + 1) > MAX_URL_LEN)
	                {
	                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
	                    iRet = ERR_CWMP_INVAL_ARGS;
	                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                                "[%s:%s:%d] [%d] Space not enough to hold "
	                                "requested value",__FILE__, __func__,
	                                __LINE__, iRet);
                            goto cleanup;
	                }

	                /* Copy the string */
	                strcpy(xMS.udp_conn_req_url,psTmpVal);
	           }else
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_NON_WRITABLE;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Cannot modify the parameter\n",
                                __func__, __LINE__, iRet);
                    goto cleanup;
                }
                break;
	             	
		case OID_IGD_MS_UDPCONNECTIONREQUESTADDRESSNOTIFICATIONLIMIT:
	              //  iPeriodInformInterval = xMS.period_inform_interval;
	              xMS.udp_conn_req_address_notification_limit= atoi(psTmpVal);
	              break;

		case OID_IGD_MS_STUNENABLE:
			 if (!strcmp(psTmpVal, "true") ||
	                    !strcmp(psTmpVal, "1"))
	                {
	                    xMS.stun_enable= TRUE;
	                }
	                else
	                {
	                    xMS.stun_enable= FALSE;
			    //VIVEK : when turning off stun, reset the nat detected param
                   	    xMS.nat_detected = 0;
	                }

                        iChange |= IFX_CHANGE_STUNPARAM;
			break;
		
		case OID_IGD_MS_STUNSERVERADDRESS:
			if(strcmp(psTmpVal,"")){   // if ipaddress is empty, then don't set it
				iChange |= IFX_CHANGE_STUNPARAM;
				break;

			}

			if((inet_aton(psTmpVal, &(xMS.stun_server_address))) ==0)
				{
					iRet=ERR_CWMP_INVAL_PARAM_VAL;
					goto cleanup;
				}
                        iChange |= IFX_CHANGE_STUNPARAM;
			break;
		case OID_IGD_MS_STUNSERVERPORT:
			xMS.stun_server_port = atoi(psTmpVal);
                        iChange |= IFX_CHANGE_STUNPARAM;
			break;
		case OID_IGD_MS_STUNUSERNAME:
			if ((strlen(psTmpVal) + 1) > MAX_CONN_REQ_UNAME_LEN)
	                    {
	                        (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
	                        iRet = ERR_CWMP_INVAL_ARGS;
	                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                                    "[%s:%s:%d] [%d] Space not enough to hold "
	                                    "requested value",__FILE__, __func__,
	                                    __LINE__, iRet);
                                goto cleanup;
	                    }

	                /* Copy the string */
	                strcpy(xMS.stun_server_uname, psTmpVal);
                        iChange |= IFX_CHANGE_STUNPARAM;
			break;
		case OID_IGD_MS_STUNPASSWORD:
			if ((strlen(psTmpVal) + 1) > MAX_CONN_REQ_PASSWD_LEN)
	                    {
	                        (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_BUFFER_OVERFLOW;
	                        iRet = ERR_CWMP_INVAL_ARGS;
	                        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
	                                    "[%s:%s:%d] [%d] Space not enough to hold "
	                                    "requested value",__FILE__, __func__,
	                                    __LINE__, iRet);
                                goto cleanup;
	                    }

	                /* Copy the string */
	                strcpy(xMS.stun_passwd, psTmpVal);
                        iChange |= IFX_CHANGE_STUNPARAM;
			break;
		
		case OID_IGD_MS_STUNMAXIMUMKEEPALIVEPERIOD:
			xMS.stun_max_keep_alive_period= atoi(psTmpVal);
                        iChange |= IFX_CHANGE_STUNPARAM;
			break;
		
		case OID_IGD_MS_STUNMINIMUMKEEPALIVEPERIOD:
			xMS.stun_min_keep_alive_period= atoi(psTmpVal);
                        iChange |= IFX_CHANGE_STUNPARAM;
			break;
		
		case OID_IGD_MS_NATDETECTED:
			if ( pxOpInfo->iCaller == ACC_ROOT)
			{ 
				xMS.nat_detected = atoi(psTmpVal);
			} else 
			{
				(pxParamVal[iCnt]).iFaultCode = ERR_NON_WRITABLE;
				iRet = ERR_CWMP_INVAL_ARGS;
				IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
						"[%s:%d] [%d] Cannot modify the parameter\n",
						__func__, __LINE__, iRet);
				goto cleanup;
			}	
			break;
#endif /* STUN_SUPPORT */

#ifndef DEVICE_SUPPORT		
#ifdef DEVICE_ASSO_SUPPORT 
		case OID_IGD_MS_MANAGEABLEDEVICENOTIFICATIONLIMIT:	
		   xMS.mngdevnotifylimit = atoi(psTmpVal);
		   break;
#endif /* DEVICE_ASSO_SUPPORT */
#endif /* DEVICE_SUPPORT */
	      case OID_IGD_MS_ENABLECWMP:
                iEnableCWMP = xMS.enable_cwmp;
 		if (!strcasecmp(psTmpVal, "true") ||
		    !strcmp(psTmpVal, "1"))
		{
			xMS.enable_cwmp = TRUE;
		}
		else
		{
			xMS.enable_cwmp = FALSE;
		}
		if(iEnableCWMP != xMS.enable_cwmp)
		{
		       iChange  |= IFX_CHANGE_ENABLECWMP;
		}
		break;

            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown Parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                    goto cleanup;
            }
        }
    }
    else if(pxOpInfo->iSubOper == OP_SETVAL_ACTIVATE)
    {
        /* Copy the string */
        //strcpy(xMS.url,psTmpVal);
        if(strlen(gxMSurl) > 4)
        {
            strcpy(xMS.url, gxMSurl);
            memset(gxMSurl, 0x00, MAX_URL_LEN);
        }
    }
    /* Set all the MGMT_SERVER parameters using Object API */
    iRtn = ifx_set_mgmt_server(IFX_OP_MOD, &xMS, IFX_F_MODIFY | IFX_F_DONT_CHECKPOINT | IFX_F_DONT_WRITE_TO_FLASH);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to set values of all "
                    "parameters\n", __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }
    if((pxOpInfo->iSubOper == OP_SETVAL_ACTIVATE) || (pxOpInfo->iCaller != ACC_TR69))
    {
        if(xMS.enable_cwmp == 0)
        {
            iTR69Status = 0;
            if((iTR69Status == 0) && (Pseudo_server_SockFd_TCP != -1))
                       IFX_Pseudo_ServerSocketStop(SOCK_STREAM);
        }
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] Activate Return Success\n"
                    , __FILE__, __func__, __LINE__);
        iRet = IFX_CWMP_SUCCESS;
        goto cleanup;
    }
    
    if(((iRtn == IFX_SUCCESS) && (iChange & IFX_CHANGE_ENABLECWMP)) && (pxOpInfo->iCaller == ACC_TR69))
    {
	 if(xMS.enable_cwmp == 0) {
             iActivate = 1;
         }
    }
    if((iRtn == IFX_SUCCESS))
    {
        if(((iChange & IFX_CHANGE_CONNREQ) || (iChange & IFX_CHANGE_ACSURL) || (iChange & IFX_CHANGE_ACSUNPW)) && (pxOpInfo->iCaller == ACC_TR69))
        {
             iActivate = 1;
        }
    }

    if((iRtn == IFX_SUCCESS) && (iChange & IFX_CHANGE_CONNREQ))
    {
         IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "Either Username or "
                     "Password is modified. Calling IFX_Pseudo_Config_Init()\n");
         IFX_Pseudo_Config_Init();
    }

    if(iRtn == IFX_SUCCESS)
    {
        guiEnabled = xMS.period_inform_enable;
        guiTimeout = xMS.period_inform_interval;
    }

    if((iRtn == IFX_SUCCESS) && 
       (iChange & IFX_CHANGE_PERIODICINFORMENABLE))
    {
        if (xMS.period_inform_enable == TRUE)
        {
            StartTimer(xMS.period_inform_interval, TM_PERIODIC_TIMER_ID);
            iTimerStartFlag = 1;
        }
        else
        {
            CancelTimer(TM_PERIODIC_TIMER_ID);
        }
    }

    if((iRtn == IFX_SUCCESS) && 
       (iChange & IFX_CHANGE_PERIODICINFORMINTERVAL))
    {
        if ((xMS.period_inform_enable == TRUE) && (!iTimerStartFlag))
        {
            CancelTimer(TM_PERIODIC_TIMER_ID);
            StartTimer(xMS.period_inform_interval, TM_PERIODIC_TIMER_ID);
        }
    }


#if 1 // PeriodicInformTime
    if((iRtn == IFX_SUCCESS) &&
       (iChange & IFX_CHANGE_PERIODICINFORMTIME))
    {
        if ((xMS.period_inform_enable == TRUE))
        {
	     CancelTimer(TM_PERIODIC_TIMER_ID);
	     
	     time_t c_time;
	     double diff = 0;
	     int ival;
	     c_time = time(NULL);
		
 	     if (xMS.period_abs_inform_time > c_time)
	     {
		diff = difftime(xMS.period_abs_inform_time , c_time);
		ival = (int)diff % xMS.period_inform_interval;
	     }
	     else
	     {

		diff = difftime(c_time , xMS.period_abs_inform_time);
		ival = xMS.period_inform_interval - (int)diff % xMS.period_inform_interval;

	     }

	     StartTimer(ival , TM_PERIODIC_TIMER_ID);
        }
    }

#endif

    if((iRtn == IFX_SUCCESS) && (iChange & IFX_CHANGE_ACSURL)) {
        if(IFX_IPC_SendMsg(viTR69RdFd, IFX_IPC_APP_ID_BOOTSTRAP,
                           (uchar8) 0, 0, 0, NULL) == IFX_IPC_FAIL) {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR, "%s:%s:%d Error "
                        "sending BOOTSTRAP Mesg\n", __FILE__, _FUNCL_);
        }
    }


#ifdef STUN_SUPPORT
	/*call IFX_TR69_STUNStart when
	   disable -> enable|disable
	   enable -> disable|enable	
	*/
    if((iRtn == IFX_SUCCESS) && (iChange & IFX_CHANGE_STUNPARAM))
    {
            IFX_TR69_STUNStart();
    }
#endif

    

cleanup:
    if(iActivate == 1)
       	return IFX_CWMP_NEED_ACTIVATE;
    else
        return (iRet);
}

/* 
** =============================================================================
**   Function Name    : Validate
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** =============================================================================
*/
STATIC int32
Validate(INOUT ParamVal * pxParamVal, IN int32 iElements)
{
    int32   iRet = IFX_CWMP_SUCCESS;
    int32   iCnt;
    int32   iParamOffset;
    char8   *psTmpVal = NULL;

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamIdPos(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup;
    }

    /* Iterate and validate the requested parameters */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {

        psTmpVal = (char8 *)((pxParamVal[iCnt]).Value);

        /* Return a failure if the value is NULL pointer */
        if (!psTmpVal)
        {
            (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
            iRet = ERR_CWMP_INVAL_ARGS;
            goto cleanup;
        }

        /* Process based on the requested parameter */
        switch ((pxParamVal[iCnt]).iaOID[iParamOffset])
        {
            case OID_IGD_MS_URL:
                iRet = ValidateURL(psTmpVal);

                /* Check for error */
                if(iRet != IFX_CWMP_SUCCESS)
                {
                    (pxParamVal[iCnt]).iFaultCode = iRet;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto cleanup;
                }

                break;
            case OID_IGD_MS_PASSWORD:
                /* No specific validation required */
                break;
            case OID_IGD_MS_PERIODICINFORMENABLE:
            case OID_IGD_MS_UPGRADESMANAGED:
	    case OID_IGD_MS_ENABLECWMP:
                if(!(!strcasecmp(psTmpVal, "true") ||
                   !strcasecmp(psTmpVal, "false") ||
                   !strcmp(psTmpVal, "1") ||
                   !strcmp(psTmpVal, "0")))
 
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto cleanup;
                }
                break;
            case OID_IGD_MS_PERIODICINFORMINTERVAL:
                if(atoi(psTmpVal) < IFX_MINPERIODICINFORMINTERVAL)
                {
                    (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_VAL;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto cleanup;
                }
                break;
            case OID_IGD_MS_PERIODICINFORMTIME:
                iRet = ValidateTimeInACSFormat(psTmpVal);

                /* Check for error */
                if(iRet != IFX_CWMP_SUCCESS)
                {
                    (pxParamVal[iCnt]).iFaultCode = iRet;
                    iRet = ERR_CWMP_INVAL_ARGS;
                    goto cleanup;
                }

                break;
            case OID_IGD_MS_PARAMETERKEY:
                /* No specific validation required */
                break;
            case OID_IGD_MS_CONNECTIONREQUESTUSERNAME:
                /* No specific validation required */
                break;
            case OID_IGD_MS_CONNECTIONREQUESTPASSWORD:
                /* No specific validation required */
                break;
            case OID_IGD_MS_USERNAME:
				
            case OID_IGD_MS_CONNECTIONREQUESTURL:
		 
                 break;
#ifdef STUN_SUPPORT
		case OID_IGD_MS_UDPCONNECTIONREQUESTADDRESS:
			break;
		case OID_IGD_MS_UDPCONNECTIONREQUESTADDRESSNOTIFICATIONLIMIT:
			break;
		case OID_IGD_MS_STUNENABLE:
			break;
		case OID_IGD_MS_STUNMAXIMUMKEEPALIVEPERIOD:
			break;
		case OID_IGD_MS_STUNMINIMUMKEEPALIVEPERIOD:
			break;
		case OID_IGD_MS_STUNPASSWORD:
			break;
		case OID_IGD_MS_STUNSERVERADDRESS:
			break;
		case OID_IGD_MS_STUNSERVERPORT:
			break;
		case OID_IGD_MS_STUNUSERNAME:
			break;
		case OID_IGD_MS_NATDETECTED:
			break;
#endif /* STUN_SUPPORT */
#ifndef DEVICE_SUPPORT	
#ifdef DEVICE_ASSO_SUPPORT	
		case OID_IGD_MS_MANAGEABLEDEVICENOTIFICATIONLIMIT:
			break;
#endif /* DEVICE_ASSO_SUPPORT */
#endif/* DEVICE_SUPPORT */
            case OID_IGD_MS_KICKURL:
            case OID_IGD_MS_DOWNLOADPROGRESSURL:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_PARAM_NOT_SUPPORTED;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Parameter Not Supported\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;  
            default:
                (pxParamVal[iCnt]).iFaultCode = ERR_CWMP_INVAL_PARAM_NAME;
                iRet = ERR_CWMP_INVAL_ARGS;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Unknown requested parameter\n",
                            __FILE__, __func__, __LINE__, iRet);
                goto cleanup;
        }
    }

cleanup:
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Validating requested parameter failed\n",
                    __FILE__, __func__, __LINE__, iRet);
    }
    return (iRet);
}


int32
GetTimeInACSFormat(uint32 uiTime, char8 *psBuff)
{

              IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d]  Time uiTime is:[%d]\n",
                    __FILE__, __func__, __LINE__, uiTime);

 /* TBD: Get the UTC time */   

#if 1 // PeriodicInformTime
	struct tm *rc_tm;
	char time_str[200];
	time_t t_time;
	
	
	t_time = uiTime;

	rc_tm = localtime(&t_time);

	sprintf(time_str, "%d-%.2d-%.2dT%.2d:%.2d:%.2d", (rc_tm->tm_year) + 1900,(rc_tm->tm_mon) + 1,rc_tm->tm_mday,rc_tm->tm_hour,rc_tm->tm_min,rc_tm->tm_sec);

	strcpy(psBuff,time_str); 
#else     
	strcpy(psBuff, "0001-01-01T00:00:00");
#endif   
	 return (IFX_CWMP_SUCCESS);
}

STATIC int32
ValidateTimeInACSFormat(char8 *psBuff)
{
/*
 
 Not Required,validation is done by default
   
#if 1 // PeriodicInformTime

	int len,i,mon,year,day,hr,min,sec;
	int mdays[] = {31,28,31,30,31,30,31,31,30,31,30,31};

	len = strlen(psBuff);

	if(len != 19 && len !=25)
	{
	    goto PARAM_ERR;
	}

	for(i = 0 ; i < 19 ; i++)
	{
	     if((i==4 || i==7) && psBuff[i]!='-')
	     {
		goto PARAM_ERR;
		break;
	     }
	     else if((i==10) && psBuff[i]!='T')
	     {
                goto PARAM_ERR;
                break;
             }  
	     else if((i==13 || i==16) && psBuff[i]!=':')
	     {
                goto PARAM_ERR;
                break;
             }  
	     else if( i!=4 && i!=7 && i!=10 && i!=13 && i!=16)
	     {
		if (psBuff[i]<'0' || psBuff[i]>'9')
		{
		     goto PARAM_ERR;
                     break;
                }
	     }
	}


	sscanf(psBuff, "%d-%d-%dT%d:%d:%d", &year, &mon, &day, &hr, &min, &sec);
	
	if ((year % 400 == 0 && year % 100 == 0) || (year % 100 != 0 && year % 4 == 0 ))
	{
	     mdays[1]=29;
	}

	if( mon > 11 || day > mdays[mon-1] || hr > 23 || min > 59 || sec > 59 )
	{
	     goto PARAM_ERR;
	}

	return (IFX_CWMP_SUCCESS);

	PARAM_ERR:
	return (ERR_CWMP_INVAL_ARGS);  
#else		
	return (IFX_CWMP_SUCCESS);
#endif
*/

	return (IFX_CWMP_SUCCESS);
}

STATIC int32
GetTimeFromACSFormat(uint32 *puiTime, char8 *psBuff)
{
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d]  Time psBuff is:[%s]\n",
                    __FILE__, __func__, __LINE__, psBuff);
        
         /* TBD: Get the time in seconds */

#if 1 // PeriodicInformTime
	int year,mon,day,hr,min,sec;
        struct tm tm;
        time_t t_time;

        sscanf(psBuff, "%d-%d-%dT%d:%d:%d", &year,&mon,&day,&hr,&min,&sec);
	tm.tm_year = year - 1900;
	tm.tm_mon = mon - 1;
	tm.tm_mday = day;
	tm.tm_hour = hr;
	tm.tm_min = min;
	tm.tm_sec = sec;  

	t_time = mktime(&tm);    

	*puiTime = t_time;
#else
        *puiTime = 2000;
#endif   
       return (IFX_CWMP_SUCCESS);
}

STATIC int32
ValidateURL(char8 *psBuff)
{
    int32 iRet = IFX_CWMP_SUCCESS;

    if((strncmp(psBuff, "http:",5) != 0)&&(strncmp(psBuff, "https:",6) != 0))
    {
        iRet = ERR_CWMP_INVAL_PARAM_VAL;
    }

    return (iRet);
}


#ifndef DEVICE_SUPPORT
#ifdef DEVICE_ASSO_SUPPORT
/* 
** =============================================================================
**   Function Name    : UpdateChildInfo
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** ============================================================================
*/

static int32 UpdateChildInfo(IN OperInfo *pxOpInfo,INOUT ParamVal *pxParamVal,
							IN int32 iElements)
{
	uint32 i,iRet;
	char8 usSecTag[IFX_MAX_SECTION_TAG_LEN] = { 0 };
	char8 usParamTag[IFX_MAX_NAME_LEN] = { 0 };
	uint32 uiChildObjId;
	int32 iParamPos;
	uint32 uiCpeid;
	int32 *iaOID=NULL;
	uint32 uiNumNV=1;
	//IFX_CpeId pxCpeId;
	IFX_Id xIfx_Id;
	IFX_NameValue pxNVArray;
	uint32 uiOper=IFX_NOTIFY_OPER_MODIFY;
	ParamVal *pxTempParamVal=pxParamVal;
	
	memset(&pxNVArray, '\0', sizeof(IFX_NameValue));
		//Get Cpeid
		iRet = IFX_GetCpeId(pxTempParamVal->iaOID, &uiCpeid);
		if(iRet != IFX_CWMP_SUCCESS)
			goto errorHandler;

		//Get the child object Oid
		uiChildObjId = IFX_GetParamIdPos((int32 *)pxTempParamVal->pReserved);
		iaOID = (int32 *)pxTempParamVal->pReserved;

		for(i=0; i < iElements; i++)

		{
			//Get the Param Oid of this object
			iParamPos= IFX_GetParamIdPos(pxTempParamVal->iaOID);
                       if (iParamPos < 0)
                       {
                           iRet = ERR_CWMP_INTERNAL;
                           IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
                           goto errorHandler;
                       }
			
			if(pxTempParamVal->iaOID[iParamPos] ==			
				 OID_IGD_MS_MANAGEABLEDEVICENUMBEROFENTRIES)
				 {
					if(iaOID[uiChildObjId-1] ==	OID_IGD_MS_MD)
					{
						//Get the section and Paramtag
						iRet=IFX_GetSectionParamTag(pxTempParamVal->psRCTag, usParamTag, 
															usSecTag);
						if(iRet != IFX_CWMP_SUCCESS)
							goto errorHandler;
						
						//xIfx_Id.uiConfigOwner= pxOpInfo->iCaller;
    						xIfx_Id.uiConfigOwner = IFX_WEB;
						xIfx_Id.xCpeId.uiId= uiCpeid;
						strncpy(xIfx_Id.xCpeId.sSectionTag,usSecTag, IFX_MAX_SECTION_TAG_LEN-1);
						xIfx_Id.xCpeId.sSectionTag[IFX_MAX_SECTION_TAG_LEN-1] = '\0';
						strncpy(pxNVArray.sName,usParamTag, IFX_MAX_NAME_LEN-1);
						pxNVArray.sName[IFX_MAX_NAME_LEN-1] = '\0';
												
						iRet=IFX_SendNotify(&xIfx_Id, uiNumNV, 
												&pxNVArray, uiOper);
						if(iRet != IFX_CWMP_SUCCESS)
						{
							IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 			"%s:%d IFX_SendNotify failed!\n", __func__, __LINE__);
							
							goto errorHandler;
						}
					}
				}

			pxTempParamVal++;
			
		}
					
		return IFX_CWMP_SUCCESS;

		errorHandler:
			IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                           		 "%s:%d failed!\n", __func__, __LINE__);
			
			return IFX_CWMP_FAILURE;
			
}
#endif /* DEVICE_ASSO_SUPPORT */
#endif /* DEVICE_SUPPORT */

STATIC int32
SetAttrInfo(IN OperInfo *pxOI, INOUT ParamVal *pxParamVal, IN int32 iElements)
{
    int32 iRet = IFX_CWMP_SUCCESS;
    int32   iRtn = IFX_SUCCESS;
    int32 iCnt;
    MGMT_SERVER xMS;
    int32 iParamOffset;
    int32 iValueFlag = 0; /* Mandatory */
#ifndef DEVICE_SUPPORT
#ifdef DEVICE_ASSO_SUPPORT
     MANAGEABLE_DEVICE *paxManage_Dev=NULL;
     int32 uiNumOfEntries=0;
     char8 sTmpBuff[13] = { 0 };
#endif /* DEVICE_ASSO_SUPPORT */
#endif /* DEVICE_SUPPORT */
    

    memset(&xMS, 0, sizeof(MGMT_SERVER));

    /* Get all the MGMT_SERVER parameters using Protocol API */
    iRtn = ifx_get_mgmt_server(&xMS, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get values of all "
                    "parameters\n",__FILE__,  __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the offset of the parameter */
    iParamOffset = IFX_GetParamIdPos(pxParamVal->iaOID);
    if (iParamOffset < 0)
    {
        iRet = ERR_CWMP_INTERNAL;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,"[%s:%s:%d][%d] Unable to get offset \n",__FILE__, __func__,__LINE__,iRet);
        goto cleanup; 
    }

    /* Set the fault code to Success and value to NULL pointer for all parameters
       other than uptime */
    for (iCnt = 0; iCnt < iElements; iCnt++)
    {
        if (((pxParamVal[iCnt]).iaOID[iParamOffset]) == OID_IGD_MS_CONNECTIONREQUESTURL)
        {

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(strlen(xMS.conn_req_url) + 1);

            /* Check for error */
            if (!((pxParamVal[iCnt]).Value))
            {
                (pxParamVal[iCnt]).iFaultCode = ERR_OUT_OF_MEMORY;
                iRet = ERR_OUT_OF_MEMORY;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Allocation Failure\n",
                             __FILE__, __func__, __LINE__, iRet);
                    goto cleanup;
            }
            strcpy((pxParamVal[iCnt]).Value, xMS.conn_req_url); 

        }
#ifndef DEVICE_SUPPORT	
#ifdef DEVICE_ASSO_SUPPORT
        if (((pxParamVal[iCnt]).iaOID[iParamOffset]) == OID_IGD_MS_MANAGEABLEDEVICENUMBEROFENTRIES)
        {

            (pxParamVal[iCnt]).Value = (void *)IFX_CWMP_MALLOC(13);

	

            /* Check for error */
            if (!((pxParamVal[iCnt]).Value))
            {
                (pxParamVal[iCnt]).iFaultCode = ERR_OUT_OF_MEMORY;
                iRet = ERR_OUT_OF_MEMORY;
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                            "[%s:%s:%d] [%d] Allocation Failure\n",
                             __FILE__, __func__, __LINE__, iRet);
                    goto cleanup;
            }
            ifx_get_all_manageable_devices(&uiNumOfEntries, &paxManage_Dev,IFX_F_GET_ANY);
            IFX_CWMP_FREE (paxManage_Dev);
            sprintf(sTmpBuff,"%d",uiNumOfEntries);
            strcpy((pxParamVal[iCnt]).Value, sTmpBuff); 
         }
#endif /* DEVICE_ASSO_SUPPORT */
#endif /* DEVICE_SUPPORT */
	else
	{
                (pxParamVal[iCnt]).Value = NULL;
        }
    }

    /* Mark that values have been malloced */
    iValueFlag = 1;

    /* Update Attribute Information */
    iRet = IFX_SetAttributesInfo(NULL, pxParamVal, iElements);

    /* Check for error */
    if(iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Updating Param Attribute Info failed\n",
                    __FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    /* Free the Value that has been allocated */
    if (iValueFlag)
    { 
        for (iCnt = 0; iCnt < iElements; iCnt++)
        {
            IFX_CWMP_FREE((pxParamVal[iCnt]).Value);
        }
    }


    return (iRet);
}



/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/

int32 IFX_MgmtServer_ReInit(int32 iChangeFlag)
{
    int32 iRtn = 0;
    MGMT_SERVER xMS;
    
    /* Get all the MGMT_SERVER parameters using Protocol API */
    iRtn = ifx_get_mgmt_server(&xMS, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {
        iRtn = IFX_CWMP_FAILURE;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get values of all "
                    "parameters\n",__FILE__, __func__, __LINE__, iRtn);
        goto cleanup;
    }

    guiTimeout = xMS.period_inform_interval;
    guiEnabled = xMS.period_inform_enable;
    if(iChangeFlag == PERINFENA_CHANGE)
    {
        /* Start the Periodic Inform Timer if it is enabled in rc.conf */
        if(xMS.period_inform_enable == TRUE)
        {
            iRtn = StartTimer(xMS.period_inform_interval, TM_PERIODIC_TIMER_ID);

            /* Check for error */
            if (iRtn != IFX_CWMP_SUCCESS)
            {
                IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to Start the Periodic Inform"
                        "Timer\n",__FILE__, __func__, __LINE__, iRtn);
                goto cleanup;
            }
  
        }
        else
        {
            CancelTimer(TM_PERIODIC_TIMER_ID);
        }
    }
    else if(iChangeFlag == PERINFINT_CHANGE)
    {
        if(xMS.period_inform_enable == FALSE)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Nothing to do. Enable = FALSE \n"
                    ,__FILE__, __func__, __LINE__, iRtn);
            iRtn = IFX_CWMP_SUCCESS;
            goto cleanup;
        }
        CancelTimer(TM_PERIODIC_TIMER_ID);
        iRtn = StartTimer(xMS.period_inform_interval, TM_PERIODIC_TIMER_ID);

        /* Check for error */
        if (iRtn != IFX_CWMP_SUCCESS)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to Start the Periodic Inform"
                    "Timer\n",__FILE__, __func__, __LINE__, iRtn);
            goto cleanup;
        }
    }
    else
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unknown notification",__FILE__, __func__, __LINE__, iRtn);
        iRtn = IFX_CWMP_FAILURE;
    } 
cleanup:
  return iRtn; 
}
/* 
** =============================================================================
**   Function Name    : IFX_MgmtServer_Init
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_MgmtServer_Init(void)
{
    int32       iRet = IFX_CWMP_SUCCESS;
    int32       iRtn = IFX_SUCCESS;
    MGMT_SERVER xMS;

    memset(&xMS, 0, sizeof(MGMT_SERVER));
    /* Register the ManagementServer module function pointer in object model */
    iRet = ifx_ds_register_function(IFX_MGMTSERVER_OBJ, IFX_MgmtServer);

    /* Check for error */
    if (iRet != IFX_CWMP_SUCCESS)
    {
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%d] [%d] Unable to Register %s with Object Model\n",
                    __func__, __LINE__, iRet, IFX_MGMTSERVER_OBJ);
        goto cleanup;
    }

    /* Get all the MGMT_SERVER parameters using Protocol API */
    iRtn = ifx_get_mgmt_server(&xMS, IFX_F_DEFAULT);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {
        iRet = IFX_CWMP_FAILURE;
        IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                    "[%s:%s:%d] [%d] Unable to get values of all "
                    "parameters\n",__FILE__, __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Start the Periodic Inform Timer if it is enabled in rc.conf */
    if (xMS.period_inform_enable == TRUE)
    {
        guiTimeout = xMS.period_inform_interval;
        guiEnabled = TRUE;
        iRet = StartTimer(xMS.period_inform_interval, TM_PERIODIC_TIMER_ID);

        /* Check for error */
        if (iRet != IFX_CWMP_SUCCESS)
        {
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%s:%d] [%d] Unable to Start the Periodic Inform"
                        "Timer\n",__FILE__, __func__, __LINE__, iRet);
            goto cleanup;
        }
    }
    else
    {
        guiEnabled = FALSE;
    }

cleanup:
    return iRet;
}

/* 
** =============================================================================
**   Function Name    : IFX_MgmtServer
**   Description      : 
**
**   Parameters       : 
**
**   Return Value     : 
**   Notes            : 
**
** =============================================================================
*/
int32
IFX_MgmtServer(IN OperInfo *pxOI, INOUT void *pParamList, IN int32 iNumElem,
             OUT void **ppRet, OUT int32 *piNumRetElem)
{
    int32       iRet           = IFX_CWMP_SUCCESS;
    ParamVal    *pxParamVal    = (ParamVal *)pParamList;

    /* Process based on type of Operation */
    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_HIGH, "%s %s oper=%d maxElement=%d\n",
                __func__, pxParamVal[0].Name, pxOI->iOper, iNumElem);

    switch (pxOI->iOper)
    {
        case OP_GETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_GETVAL_NORMAL:
                case OP_GETVAL_NOTIFICATION:

                    /* Get values of all the requested parameters */
                    iRet = GetVal(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_SETVAL:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_SETVAL_VALIDATE:

                    /* Validate values of all the requested parameters */
                    iRet = Validate(pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_CHK_MODIFY_DEP:

                   /* Check modify dependency of all requested parameters */
                    iRet = IFX_CWMP_SUCCESS;

                    break;
                case OP_SETVAL_MODIFY:

                    /* Set values of all the requested parameters */
                    iRet = Modify(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_ACTIVATE:
                    /* Handle URL, And ACS and ConnReq U/N and P/W Set*/
                    iRet = Modify(pxOI, pxParamVal, iNumElem);
                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }
		   break;
                case OP_SETVAL_ATTRINFO:

                    /* Set attribute values for all the requested parameters */
                    iRet = SetAttrInfo(pxOI, pxParamVal, iNumElem);

                    /* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }

                    break;
                case OP_SETVAL_COMMIT:
                case OP_SETVAL_UNDO:
                case OP_SETVAL_FREE:
                case OP_SETVAL_ADD:
                case OP_SETVAL_CHK_DEL_DEP:
                case OP_SETVAL_CHK_DEL_ALLOWED:
                case OP_SETVAL_DELETE:
                break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_UPDATE_CHILDINFO:
            /* Process based on type of SubOperation */
            switch(pxOI->iSubOper)
            {
                case OP_UPDATE_CHILDINFO_ADD: 
                case OP_UPDATE_CHILDINFO_DEL: 
#ifndef DEVICE_SUPPORT
#ifdef DEVICE_ASSO_SUPPORT
			iRet = UpdateChildInfo(pxOI, pxParamVal, iNumElem);
			/* Check for error */
                    if (iRet != IFX_CWMP_SUCCESS)
                    {
                        goto cleanup;
                    }
#endif /* DEVICE_ASSO_SUPPORT */
#endif /* DEVICE_SUPPORT */
                    break;
                default:
                    iRet = ERR_CWMP_INVAL_OPER;
                    IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                                "[%s:%d] [%d] Invalid SubOperation\n",
                                 __func__, __LINE__, iRet);
                    goto cleanup;
            }
            break;
        case OP_PARAM_VALIDATE:
        {
            break; 
        }
        default:
            iRet = ERR_CWMP_INVAL_OPER;
            IFX_DBG_Log(vcOsModId, IFX_DBG_LVL_ERROR,
                        "[%s:%d] [%d] Invalid Operation\n",
                         __func__, __LINE__, iRet);
            goto cleanup;
    }

cleanup:
    return (iRet);
}
