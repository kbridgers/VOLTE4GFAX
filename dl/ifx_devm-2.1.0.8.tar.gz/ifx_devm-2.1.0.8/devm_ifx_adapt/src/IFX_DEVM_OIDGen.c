/*
** =============================================================================
** FILE NAME      : IFIN_OID_Gen.c
** PROJECT        : TR69
** MODULES        : 
** DATE           : 15-Jun-2006
** AUTHOR         : TR69 team
** DESCRIPTION    : This application is used by makefile to generate IFX_DEVM_OID.h
**
** REFERENCES     :  
** COPYRIGHT      : Copyright (c) 2006
**                  Infineon Technologies AG
**                  Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted
**
** HISTORY        : 
** $Date           $Author          $Comment
** 15-Jun-2006     Tr69 team        Creation         
** =============================================================================
*/

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define INPUT_FILEPATH             "./"
#define INPUT_FILENAME             "tr69_db.txt"
#define OUTPUT_FILEPATH            "./"
#define OUTPUT_FILENAME            "IFX_DEVM_OID.h"
#define OUTPUT_FILEID              "__IFIN_OID_H__"
#define OUTPUT_FILEHEADER          "#ifndef " OUTPUT_FILEID NEWLINE "#define " OUTPUT_FILEID NEWLINE NEWLINE
#define OUTPUT_FILEFOOTER          NEWLINE "#endif " COMMENT_BEGIN OUTPUT_FILEID COMMENT_END NEWLINE
#define PREFIX                     "#define OID"
#define SEPARATOR                  "_"
#define NEWLINE                    "\n"        
#define COMMENT_BEGIN              "/*"
#define COMMENT_END                "*/"

char buffer[256][256];
int buff_index = 0;

size_t getObject(char *buff, char *name, char *id,int buffer_flag);
size_t getParam(char *buff, char *id);

int main(int argc, char *argv[])
{
  FILE   *pfInput  = NULL;
  FILE   *pfOutput = NULL;
  char   *pcLine   = NULL;
  size_t iSize     = 0;
  size_t iStatus;
  char   cTmpName[100];
  char   cName[105];
  char   cId[10];
  int    iI = 0;
  int    iRtn = 0;

  if (argc != 3)
  {
    iRtn = -1;
    goto error;
  } 

  /* Open the Input file for reading */
  pfInput = fopen(argv[1], "r");
  /* Check for error */
  if (!pfInput)
  {
    iRtn = -1;
    goto error;
  }

  /* Open the Output file for writing */
  pfOutput = fopen(argv[2], "w");
  /* Check for error */
  if (!pfOutput)
  {
    iRtn = -1;
    goto error;
  }

  /* Write the file header */
  fprintf(pfOutput, OUTPUT_FILEHEADER);

  /* Loop forever extracting and processing each line. Loop terminates if
     End-of-file is encountered. */
  while (1)
  {
    iI = 0;

    /* Read a line from the file */ 
    iStatus = getline(&pcLine, &iSize, pfInput);

    /* Check for error */
    if (iStatus == -1)
    {
      /* Exit the loop if End-of-file is encountered */
      if (feof(pfInput)) break;

      /* Process the actual error */
      iRtn = -1;
      goto error;
    }

    /* Switch based on the first character in the line */
    switch (pcLine[iI])
    {
      /* This is a object entry */
      case '#':

        /* Ignore all the initial '#' characters */
        while (pcLine[iI] == '#') iI++;

        /* Extract the object name and object id from line */
        iStatus = getObject(pcLine + iI, (char *)&cTmpName, (char *)&cId, 1);

        /* Ignore the object entry in case it is erronious */
        if (iStatus == -1) continue;

        /* Temporary fix for Device. Modifies it to InternetGatewayDevice */
        if (!strstr(cTmpName,"IGD"))
        {
          strcpy(cName,"IG"); 
          strcat(cName,cTmpName);
        }
        else
        {
          strcpy(cName,cTmpName);
        }

        /* Write the object entry in the output file */
        fprintf(pfOutput, PREFIX SEPARATOR "%s %s" NEWLINE, cName, cId);
        break;
      /* This is a commented entry */
      case '/':
        /* Ignore all the initial '#' or '/'  characters */
        while (pcLine[iI] == '/' || pcLine[iI] == '#') iI++;

        if (pcLine[iI - 1] == '#') /* Commented object entry */
        {
          /* Extract the object name and object id from line */
          iStatus = getObject(pcLine + iI, (char *)&cTmpName, (char *)&cId, 1);

          /* Ignore the object entry in case it is erronious */
          if (iStatus == -1) continue;

          /* Temporary fix for Device. Modifies it to InternetGatewayDevice */
          if (!strstr(cTmpName,"IGD"))
          {
            strcpy(cName,"IG"); 
            strcat(cName,cTmpName);
          }
          else
          {
            strcpy(cName,cTmpName);
          }

          /* Write the object entry in the output file */
          fprintf(pfOutput, PREFIX SEPARATOR "%s %s" NEWLINE, cName, cId);
        }
        else /* Commented parameter entry */
        {
          /* Extract the parameter name and parameter id from line. Here parameter name is modified
             in the input line buffer itself */
          iStatus = getParam(pcLine + iI, (char *)&cId);

          /* Ignore the parameter entry in case it is erronious */
          if (iStatus == -1) continue;

          /* Write the parameter entry in the output file */
          fprintf(pfOutput, PREFIX SEPARATOR "%s" SEPARATOR "%s %s" NEWLINE, cName, pcLine + iI, cId);
        } 

        break;
      /* These are blank entries */
      case '\n':
      case ' ':
      case '\r':
        /* No processing has to be done. Just ignore the entries */
        break;
      /* This is a parameter entry */
      default:
        /* Extract the parameter name and parameter id from line. Here parameter name is modified
           in the input line buffer itself */
        iStatus = getParam(pcLine, (char *)&cId);

        /* Ignore the parameter entry in case it is erronious */
        if (iStatus == -1) continue;

        /* Write the parameter entry in the output file */
        fprintf(pfOutput, PREFIX SEPARATOR "%s" SEPARATOR "%s %s" NEWLINE, cName, pcLine, cId);
        break;
    }
  }

  /* Write the file footer */
  fprintf(pfOutput, OUTPUT_FILEFOOTER);

error:
  if (pfInput) fclose(pfInput);
  if (pfOutput) fclose(pfOutput);
  if (pcLine) free(pcLine);
  return iRtn;
}

size_t getObject(char *buff, char *name, char *id, int buffer_flag)
{
  char *tmp;
  int len,i;
  int j=0;
  int flag = 0;
  int tmp1  = 0;
  char xxx[100];
  char yyy[100] = {0};
  int r = 0;

  tmp = strtok(buff,"~");
  if (tmp)
  {
    tmp1 = strlen(tmp);
    tmp = strtok(buff,".");
    if (tmp)
    {
      len = strlen(tmp);
      for(i=0;i<len;i++)
      {
        if (isupper(tmp[i]))
          name[j++] = tmp[i];
        if (isdigit(tmp[i]) && (i!=0))
          name[j++] = tmp[i];
      }
      flag = 1;
      while((tmp =  strtok(NULL,"."))!= NULL)
      {
        if (flag) {name[j++] = '_'; flag = 0;}
        len = strlen(tmp);
        for(i=0;i<len;i++)
        {
          if (isupper(tmp[i]))
            {name[j++] = tmp[i]; flag = 1; r=i;strcpy(yyy,tmp);}
          if (isdigit(tmp[i]) && (i!=0))
            {name[j++] = tmp[i]; flag = 1; r=i;strcpy(yyy,tmp);}
        }
      }
    }
  }
  if (flag)
    name[j] = '\0';
  else
    name[j-1] = '\0';

        if (buffer_flag)
        {
          int m;
loop_here:
          for (m=0;m<buff_index;m++)
          {
            if (!strcmp(buffer[m],name))
            {
              xxx[0] = toupper(yyy[++r]); xxx[1] = '\0';
              strcat(name,xxx);
              goto loop_here;
            }
          }
          strcpy(buffer[buff_index],name);
          buff_index++;
        }

  tmp =  strtok(buff + tmp1 + 1,"~");
  j = 0;
  if (tmp)
  {
    len = strlen(tmp);
    for(i=0;i<len;i++)
    {
      if ((isdigit(tmp[i])) || (tmp[i] == '-'))
        id[j++] = tmp[i];
    }
  }
  id[j] = '\0';

  return 0;
}

size_t getParam(char *buff, char *id)
{
  char *tmp;
  int len,i;
  int j=0;

  tmp = strtok(buff,"~");
  if (tmp)
  {
    len = strlen(tmp);
    for(i=0;i<len;i++)
    {
      buff[i] = toupper(buff[i]);
    }
  }

  tmp =  strtok(NULL,"~");
  if (tmp)
  {
    len = strlen(tmp);
    for(i=0;i<len;i++)
    {
      if ((isdigit(tmp[i])) || (tmp[i] == '-'))
        id[j++] = tmp[i];
    }
  }
  id[j] = '\0';

  return 0;
}

