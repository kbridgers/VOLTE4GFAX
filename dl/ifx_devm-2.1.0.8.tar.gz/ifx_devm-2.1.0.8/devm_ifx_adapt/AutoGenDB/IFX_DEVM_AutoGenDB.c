/* 
** =============================================================================
** FILE NAME     : IFX_AutoGenDB.c
** PROJECT       : TR69
** MODULES       : Micellaneous
** DATE          : 11-01-2007
** AUTHOR        : TR69 Team
** DESCRIPTION   : Read XML files and generate tr69_db.txt. The generated file
**                 will be placed in blrcwmp\cwmp\bin folder.  Pass command 
**                 line arguments For e.g. ./AutoGenDB TR111. In XML file With each 
**                 node Model Element is added "<Model>TR069,TR111</Model>".
**                 If ./AutoGenDB TR111 is invoked, Model element should have TR111 
**                 in the comma seperated list. If TR111 is not found in the list, 
**                 it is not included in the final tr69_db.txt file.
**                 Similarly for ./AutoGenDB TR069.
**
** REFERENCES    : 
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       : 
** $Date   $Author    $Comment
** Modified this file on 17-08-2007.
**
** ============================================================================
*/

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <libgen.h>
#include "ixml.h"

#define MAX_SIZE 		1024
#define ROW_SIZE 		18
#define COL_SIZE 		102
#define BUFF_SIZE               1200000       //TODO
#define OUT_FILE                "tr69_db.txt"

/* Function Declarations */
void gen_tr69_db(FILE *, IXML_Node *, char *capArgv[], int);
char *form_object_name(IXML_Node *);
IXML_Node *xpRoot = NULL;
char *type_form(char *);
int isPrintableObject(char *, char *str[], int);

/* main() : It generates the tr69_db.txt file based on inputs */

int
main(int argc, char *argv[])
{
    IXML_Document *xpXmlDoc = NULL;
    IXML_Node *xpNode = NULL, *xprootNode = NULL;
    int iErr = 0, i;
    char caBuf[BUFF_SIZE], *capArgv[25];
    FILE *xpFP=NULL, *xpOutFP=NULL;

    if(argc <= 1) {
        printf("Usage: %s <TR069> <TR111> ...\n", basename(argv[0]));
        exit(EXIT_FAILURE);
    }

    xpFP = fopen(argv[1], "r");
    if(xpFP == NULL) {
        printf("%s:%d Unable to open %s\n", __func__, __LINE__, argv[1]);
        exit(EXIT_FAILURE);
    }
    memset(caBuf, '\0', sizeof(caBuf));
    fread(caBuf, sizeof(caBuf), 1, xpFP);

    if((iErr = ixmlParseBufferEx(caBuf, &xpXmlDoc)) != IXML_SUCCESS) {
        if(iErr == IXML_INSUFFICIENT_MEMORY) {
            printf("%s:%d Out of memory!!\n", __func__, __LINE__);
            exit(EXIT_FAILURE);
        }
    }
    /* Parse through all the nodes till you reach the rpc call node */
    if((xpNode = ixmlNode_getFirstChild((IXML_Node *) xpXmlDoc)) == NULL) {
        printf("%s:%d No ParameterDictionary node.\n", __func__, __LINE__);
	goto end;
    }
    if(strstr((char *)ixmlNode_getNodeName(xpNode), "ParameterDictionary")
       == NULL) {
        printf("%s:%d No ParameterDictionary node.\n", __func__, __LINE__);
	goto end;
    }

    if((xprootNode = ixmlNode_getFirstChild(xpNode)) == NULL) {
        printf("%s:%d No Root Parameter node.\n", __func__, __LINE__);
	goto end;
    }
    /* Generate the tr69_db.txt file */
    xpOutFP = fopen(OUT_FILE, "a");
    if(xpOutFP == NULL) {
        printf("%s:%d Unable to open %s\n", __func__, __LINE__, OUT_FILE);
        exit(EXIT_FAILURE);
    }
    xpRoot = xprootNode;
    for(i = 0; i < (argc - 2); i++) {
        capArgv[i] = (char *)malloc(32);
        strcpy(capArgv[i], argv[i + 2]);
    }
    gen_tr69_db(xpOutFP, xprootNode, capArgv, (argc - 2));
    fprintf(xpOutFP, "\n");
end:
    fclose(xpOutFP);
    fclose(xpFP);

    return 0;

}                               // End of Main()


void
gen_tr69_db(FILE * xpOutFP, IXML_Node * xpParent, char *capArgv[], int iargc)
{
    IXML_NodeList *xpChild = NULL, *xpTmpChild = NULL;
    IXML_Node *xpParam = NULL, *xpDenyActNotif = NULL, *xpModel = NULL;
    IXML_Node *xpName = NULL, *xpType = NULL, *xpOID = NULL;
    IXML_Node *xpWritable = NULL, *xpActive = NULL, *xpInst = NULL;
    IXML_Node *xpRCConf = NULL, *xpDefVal = NULL, *xpValidation = NULL;
    char caName[COL_SIZE], caType[COL_SIZE], caWritable[ROW_SIZE];
    char caHeader[COL_SIZE], caRdWr[ROW_SIZE], caRCConf[COL_SIZE];
    char caOID[ROW_SIZE], caActive[ROW_SIZE], caInstance[ROW_SIZE],
        caModel[ROW_SIZE];
    char caDefVal[ROW_SIZE], caValidation[MAX_SIZE], caDenyActNotif[ROW_SIZE];
    int iFlag = 0, DAN = 0, No_DefVal_Flag = 0, No_ValidVal_Flag = 0;
    int inst = 0, iPRINTABLE = 0;
    static int FIRST = 1;

    memset(caDefVal, '\0', sizeof(caDefVal));
    memset(caValidation, '\0', sizeof(caValidation));
    memset(caDenyActNotif, '\0', sizeof(caDenyActNotif));
    memset(caName, '\0', sizeof(caName));
    memset(caType, '\0', sizeof(caType));
    memset(caWritable, '\0', sizeof(caWritable));
    memset(caOID, '\0', sizeof(caOID));
    memset(caHeader, '\0', sizeof(caHeader));
    memset(caActive, '\0', sizeof(caActive));
    memset(caModel, '\0', sizeof(caModel));
    memset(caInstance, '\0', sizeof(caInstance));
    memset(caRdWr, '\0', sizeof(caRdWr));
    memset(caRCConf, '\0', sizeof(caRCConf));

    if(strstr((char *)ixmlNode_getNodeName(xpParent), "Object") != NULL) {

        xpTmpChild = xpChild = ixmlNode_getChildNodes(xpParent);
        while(xpChild != NULL) {
            if(strstr((char *)ixmlNode_getNodeName(xpChild->nodeItem), "OID")) {
                xpOID = ixmlNode_getFirstChild(xpChild->nodeItem);
                if((char *)ixmlNode_getNodeValue(xpOID) != NULL) {
                    strcpy(caOID, (char *)ixmlNode_getNodeValue(xpOID));
                    iFlag = 1;
                }
            }
            if(strstr((char *)ixmlNode_getNodeName(xpChild->nodeItem), "Model")) {
                xpModel = ixmlNode_getFirstChild(xpChild->nodeItem);
                if((char *)ixmlNode_getNodeValue(xpModel) != NULL) {
                    strcpy(caModel, (char *)ixmlNode_getNodeValue(xpModel));
                    iPRINTABLE = isPrintableObject(caModel, capArgv, iargc);
                }
            }
            if(strstr
               ((char *)ixmlNode_getNodeName(xpChild->nodeItem), "Active")) {
                xpActive = ixmlNode_getFirstChild(xpChild->nodeItem);
                if((char *)ixmlNode_getNodeValue(xpActive) != NULL) {
                    strcpy(caActive, (char *)ixmlNode_getNodeValue(xpActive));
                }
            }
            if(strstr
               ((char *)ixmlNode_getNodeName(xpChild->nodeItem), "Instance")) {
                xpInst = ixmlNode_getFirstChild(xpChild->nodeItem);
                if((char *)ixmlNode_getNodeValue(xpInst) != NULL) {
                    strcpy(caInstance, (char *)ixmlNode_getNodeValue(xpInst));
                }
            }
            if(strstr
               ((char *)ixmlNode_getNodeName(xpChild->nodeItem), "Writable")) {
                xpWritable = ixmlNode_getFirstChild(xpChild->nodeItem);
		if((char *)ixmlNode_getNodeValue(xpWritable) != NULL) {
                    strcpy(caWritable, (char *)ixmlNode_getNodeValue(xpWritable));
            }
	  }
            xpChild = xpChild->next;
        }                       // end of while(xpChild != NULL)
        if(strcasecmp(caWritable, "true") == 0) {
            strcpy(caRdWr, "RW");
        }
        else {
            strcpy(caRdWr, "RO");
        }

        if(strcasecmp(caInstance, "true") == 0) {
            inst = 1;
        }
        if(strcasecmp(caInstance, "false") == 0) {
            inst = 0;
        }
        if(iPRINTABLE) {
            if(iFlag) {
                strcpy(caHeader, form_object_name(xpParent));
                if(FIRST) {
                    if(strcasecmp(caActive, "true") == 0) {
                        fprintf(xpOutFP, "%s.~%s~%d~%s~\n", caHeader, caOID,
                                inst, caRdWr);
                    }
                    if(strcasecmp(caActive, "false") == 0) {
                        fprintf(xpOutFP, "//%s.~%s~%d~%s~\n", caHeader, caOID,
                                inst, caRdWr);
                    }
                    FIRST = 0;
                }
                else {
                    if(strcasecmp(caActive, "true") == 0) {
                        fprintf(xpOutFP, "\n%s.~%s~%d~%s~\n", caHeader, caOID,
                                inst, caRdWr);
                    }
                    if(strcasecmp(caActive, "false") == 0) {
                        fprintf(xpOutFP, "\n//%s.~%s~%d~%s~\n", caHeader, caOID,
                                inst, caRdWr);
                    }
                }
                iFlag = 0;
            }                   // end of if(iFlag)
            iPRINTABLE = 0;
        }                       // end of if (iPRINTABLE)
    }                           // end of if ( *Object*)
    else {
        printf("%s:%d No Root Parameter node.\n", __func__, __LINE__);
        return;
    }

    xpChild = xpTmpChild;

    do {
        if(strstr((char *)ixmlNode_getNodeName(xpChild->nodeItem), "Parameter")) {
            xpParam = ixmlNode_getFirstChild(xpChild->nodeItem);
            if(xpParam) {
                do {
                    if(strstr((char *)ixmlNode_getNodeName(xpParam), "Name")) {
                        xpName = ixmlNode_getFirstChild(xpParam);
			if((char *)ixmlNode_getNodeValue(xpName) != NULL) {
                            strcpy(caName, (char *)ixmlNode_getNodeValue(xpName));
                        }
                    }
                    if(strstr((char *)ixmlNode_getNodeName(xpParam), "OID")) {
                        xpOID = ixmlNode_getFirstChild(xpParam);
			if((char *)ixmlNode_getNodeValue(xpOID) != NULL) {
                            strcpy(caOID, (char *)ixmlNode_getNodeValue(xpOID));
			}
                    }
                    if(strstr((char *)ixmlNode_getNodeName(xpParam), "Model")) {
                        xpModel = ixmlNode_getFirstChild(xpParam);
			if((char *)ixmlNode_getNodeValue(xpModel) !=NULL) {
                            strcpy(caModel, (char *)ixmlNode_getNodeValue(xpModel));
                            iPRINTABLE = isPrintableObject(caModel, capArgv, iargc);
                        }
                    }
                    if(strstr((char *)ixmlNode_getNodeName(xpParam), "Type")) {
                        xpType = ixmlNode_getFirstChild(xpParam);
			if((char *)ixmlNode_getNodeValue(xpType) !=NULL) {
                            strcpy(caType, (char *)ixmlNode_getNodeValue(xpType));
			}
                    }
                    if(strstr
                       ((char *)ixmlNode_getNodeName(xpParam), "Writable")) {
                        xpWritable = ixmlNode_getFirstChild(xpParam);
                        if((char *)ixmlNode_getNodeValue(xpType) !=NULL) {
                             strcpy(caWritable,
                                        (char *)ixmlNode_getNodeValue(xpWritable));
                        }
                    }
                    if(strstr((char *)ixmlNode_getNodeName(xpParam), "Active")) {
                        xpActive = ixmlNode_getFirstChild(xpParam);
                        memset(caActive, '\0', sizeof(caActive));
                        if((char *)ixmlNode_getNodeValue(xpActive) != NULL) {
                             strcpy(caActive,
                                        (char *)ixmlNode_getNodeValue(xpActive));
                        }
                    }
                    if(strstr
                       ((char *)ixmlNode_getNodeName(xpParam), "RCConfTag")) {
                        xpRCConf = ixmlNode_getFirstChild(xpParam);
			if((char *)ixmlNode_getNodeValue(xpRCConf) !=NULL) {
                             strcpy(caRCConf,
                                        (char *)ixmlNode_getNodeValue(xpRCConf));
			}
                    }
                    if(strstr
                       ((char *)ixmlNode_getNodeName(xpParam),
                        "DenyactiveNotification")) {
                        xpDenyActNotif = ixmlNode_getFirstChild(xpParam);
			if((char *)ixmlNode_getNodeValue(xpDenyActNotif) !=NULL) {
                             strcpy(caDenyActNotif,
                                       (char *)ixmlNode_getNodeValue(xpDenyActNotif));
			}
                    }
                    if(strstr
                       ((char *)ixmlNode_getNodeName(xpParam),
                        "DefaultValue")) {
                        xpDefVal = ixmlNode_getFirstChild(xpParam);
                        if((char *)ixmlNode_getNodeValue(xpDefVal) != NULL) {
                             strcpy(caDefVal,
                                      (char *)ixmlNode_getNodeValue(xpDefVal));
			}
                    
                         else {
                            No_DefVal_Flag = 1;
                         }
                    }
                    if(strstr
                       ((char *)ixmlNode_getNodeName(xpParam),
                        "ValidationValues")) {
                        xpValidation = ixmlNode_getFirstChild(xpParam);
                        if((char *)ixmlNode_getNodeValue(xpValidation) != NULL) {
                             strcpy(caValidation, 
                                      (char *)ixmlNode_getNodeValue(xpValidation));
                        }
                        else {
                            No_ValidVal_Flag = 1;
                        }
                    }
                } while((xpParam = ixmlNode_getNextSibling(xpParam)) != NULL);
                if(strcasecmp(caWritable, "true") == 0)
                    strcpy(caRdWr, "RW");
                else
                    strcpy(caRdWr, "RO");

                if(strcasecmp(caDenyActNotif, "Active") == 0) {
                    DAN = 2;
                }
                if(strcasecmp(caDenyActNotif, "true") == 0) {
                    DAN = 1;
                }
                if(strcasecmp(caDenyActNotif, "false") == 0) {
                    DAN = 0;
                }
                if(iPRINTABLE) {
                    // write all param values to output file
                    if(strcasecmp(caActive, "true") == 0) {
                        fprintf(xpOutFP, "%s", "");
                    }
                    if(strcasecmp(caActive, "false") == 0) {
                        fprintf(xpOutFP, "%s", "//");
                    }
                    if(No_DefVal_Flag && No_ValidVal_Flag)
                        fprintf(xpOutFP, "%s~%s~%s~%s~%s~%d~ ~\n", caName,
                                caOID, type_form(caType), caRCConf, caRdWr,
                                DAN);
                    if(No_DefVal_Flag && !No_ValidVal_Flag)
                        fprintf(xpOutFP, "%s~%s~%s~%s~%s~%d~%s~\n", caName,
                                caOID, type_form(caType), caRCConf, caRdWr, DAN,
                                caValidation);
                    if(!No_DefVal_Flag && No_ValidVal_Flag)
                        fprintf(xpOutFP, "%s~%s~%s~%s~%s~%d~[%s]~\n", caName,
                                caOID, type_form(caType), caRCConf, caRdWr, DAN,
                                caDefVal);
                    if(!No_DefVal_Flag && !No_ValidVal_Flag)
                        fprintf(xpOutFP, "%s~%s~%s~%s~%s~%d~[%s],%s~\n", caName,
                                caOID, type_form(caType), caRCConf, caRdWr, DAN,
                                caDefVal, caValidation);
                    No_DefVal_Flag = No_ValidVal_Flag = 0;
                    iPRINTABLE = 0;
                }               // End of if(iPRINTABLE)
            }                   // End of if (xpParam)
        }                       // parameter
        xpChild = xpChild->next;

    } while(xpChild != NULL);

    while(xpTmpChild != NULL) {

        if(strstr((char *)ixmlNode_getNodeName(xpTmpChild->nodeItem), "Object")) {
            gen_tr69_db(xpOutFP, xpTmpChild->nodeItem, capArgv, iargc);

        }
        xpTmpChild = xpTmpChild->next;
    }                           // end of while (xpChild->nodeItem != NULL)

}                               // End of gen_tr69_db()


char *
form_object_name(IXML_Node * childNode)
{
    IXML_NamedNodeMap *NODE = NULL;
    char old[2*COL_SIZE] = "", new[COL_SIZE] = "", temp[2*COL_SIZE] = ".";
    static char obj_path[MAX_SIZE] = "";

    strcpy(obj_path, "#");
    if(childNode == xpRoot) {
        NODE = ixmlNode_getAttributes(childNode);
	if(NODE!=NULL) {
        strcpy(new, (char *)NODE->nodeItem->nodeValue);
        }
        strcat(obj_path, new);
        return obj_path;
    }

    while(childNode != xpRoot) {
        NODE = ixmlNode_getAttributes(childNode);
        if(NODE!=NULL) {
        strcpy(new, (char *)NODE->nodeItem->nodeValue);
        }
        strcat(temp, new);
        strcat(temp, old);
        strcpy(old, temp);
        strcpy(temp, ".");
        childNode = ixmlNode_getParentNode(childNode);

    }
    NODE = ixmlNode_getAttributes(childNode);
    if(NODE!=NULL) {
    strcpy(new, (char *)NODE->nodeItem->nodeValue);
    }
    strcat(new, old);
    strcat(obj_path, new);

    return obj_path;

}                               // end of form_object_name(IXML_Node *)


char *
type_form(char type_name[])
{
    static char caResType[8];
    char caType[25]={0}, caNum[25] = {0};
    int iLen = 0, iNum = 0;

    memset(caResType, '\0', sizeof(caResType));
    //memset(caType, '\0', sizeof(caType));
    //memset(caNum, '\0', sizeof(caNum));

    sscanf(type_name, "%24[^(]( %[^)]", caType, caNum);
    if(strcasecmp(caType, "Base64") == 0) {
        if((iLen = strlen(caNum)) == 1) {
            strcat(caResType, "b00");
            strncat(caResType, caNum, iLen);
        }
        if(iLen == 2) {
            strcat(caResType, "b0");
            strncat(caResType, caNum, iLen);
            //strcat(caResType, caNum);
        }
        if(iLen >= 3) {
            strcat(caResType, "b");
            strncat(caResType, caNum, iLen);
            //strcat(caResType, caNum);
        }
    }
    if(strcasecmp(caType, "string") == 0) {
        if((iLen = strlen(caNum)) == 1) {
            strcat(caResType, "s00");
            strncat(caResType, caNum, iLen);
            //strcat(caResType, caNum);
        }
        if(iLen == 2) {
            strcat(caResType, "s0");
            strncat(caResType, caNum, iLen);
            //strcat(caResType, caNum);
        }
        if(iLen == 3) {
            strcat(caResType, "s");
            strncat(caResType, caNum, iLen);
            //strcat(caResType, caNum);
        }
        if(iLen == 4) {
            strcat(caResType, "s0");
            iNum = atoi(caNum) / 1024;
            sprintf(caNum, "%dk", iNum);
            strcat(caResType, caNum);
        }
        if(iLen >= 5) {
            strcat(caResType, "s");
            sprintf(caNum, "%dk", (atoi(caNum)) / 1024);
            strcat(caResType, caNum);
        }
    }                           // end of if (string)
    sscanf(type_name, "%24[^[][ %24[^]]", caType, caNum);
    if(strcasecmp(caType, "unsignedInt") == 0) {
        strcat(caResType, "uint");
    }                           // end if (unsignedInt)
    if(strcasecmp(caType, "int") == 0) {
        strcat(caResType, "int");
    }                           // end of if (int)
    if(strcasecmp(caType, "boolean") == 0) {
        strcpy(caResType, "bool");
    }                           // end of if (boolean)
    if(strcasecmp(caType, "dateTime") == 0) {
        strcpy(caResType, "date");
    }                           // end of if (dateTime)

    return caResType;

}                               // End of type_form(char *type)


int
isPrintableObject(char *cpModel, char *capArgv[], int iArgc)
{
    int i;

    for(i = 0; i < iArgc; i++) {
        if(strcasestr(cpModel, capArgv[i]))
            return 1;
    }
    return 0;
}                               // end of isPrintableObject()
