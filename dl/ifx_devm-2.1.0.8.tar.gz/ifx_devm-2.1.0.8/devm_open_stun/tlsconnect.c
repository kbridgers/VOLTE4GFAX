/* ====================================================================
 * Copyright (c) 2004 - Infeneon-ADMtek Technologies AG. 
 *
 * All rights reserved.
 * ====================================================================
 *
 * ====================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ====================================================================
 */

/* ====================================================================
 *
 * File Name: tlsconnect.c 
 * Author: Eric Tsai
 * Date:
 * 
 * ====================================================================
 *
 * Projects: <Amazon/Stun>
 * Block: <Client/tls>
 *
 * ====================================================================
 * Contents:
 *
 * ====================================================================
 * References: 
 */

#include <stdio.h>
#include <inttypes.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <openssl/ssl.h>
#include <openssl/rand.h>
#include <openssl/md5.h>
#include <openssl/rc4.h>
#include <openssl/hmac.h>
#include <openssl/err.h>


#include "tlsconnect.h"

SSL_CTX *ctx;
SSL *ssl;
BIO *sbio;

extern StunAtrString gotusername;
extern StunAtrString gotpassword;


#ifndef CRYPT_DEBUG
#define CRYPT_DEBUG 0
#endif

#ifndef TLS_DEBUG
#define TLS_DEBUG 1
#endif


#if TLS_DEBUG
void tls_debug(char *fun, u_char * buf, int size, char *comment)
{
  int i;
  printf("%%%% %s %%%%: %s", fun, comment);
  if (buf != NULL) {
    printf("\n\tPacket size is %d decimal %x hex", size, size);
    for (i = 0; i < size; i++) {
      if (i % 16 == 0)
	printf("\n\t");
      printf("%.2x ", *(buf + i));
    }
  }
  printf("\n");

}
#endif

int tls_init(char *root_cert)
{
  //char *root_cert = (char *) "./myrootca.crt";

  SSL_library_init();
  SSL_load_error_strings();
  ctx = SSL_CTX_new(TLSv1_method());
  if (ctx == NULL) {
    printf("(TLS) Couldn't initalize OpenSSL TLS library!\n");
    return INIT_SSL_ERR;
  }

  if (tls_load_root_cert(root_cert) < 0) {
    printf("Load root CA failed!\n");
    return LOAD_ROOTCA_ERR;
  } else
    printf("Load root CA successfully!\n");

#if TLS_DEBUG
  printf("(TLS) Initialized TLS Successfully!\n");
#endif
  return NO_ERR;
}

int tls_shutdown(void)
{
#if TLS_DEBUG
  printf("(TLS) Cleaning up.\n");
#endif
  if (ctx)
    SSL_CTX_free(ctx);		// Will free ssl automatically
  else if (ssl)
    SSL_free(ssl);

  ssl = NULL;
  ctx = NULL;
  return 0;
}

void tls_close(void)
{

}

int tls_connect(int sock, char *serverid)
{
  int ssl_ret;
  X509 *peer;
  char peer_CN[256];

  if (ssl)
    SSL_free(ssl);

  ssl = SSL_new(ctx);
  if (!ssl) {
    printf("Couldn't create SSL object!\n");
    return CREATE_SSL_ERR;
  }

  sbio = BIO_new_socket(sock, BIO_NOCLOSE);
  SSL_set_bio(ssl, sbio, sbio);

  SSL_set_verify(ssl, SSL_VERIFY_PEER | SSL_VERIFY_FAIL_IF_NO_PEER_CERT,
		 NULL);

  printf("SSL_connect: start!\n");
  ssl_ret = SSL_connect(ssl);
  printf("SSL_connect: end! ssl_ret = %d\n", ssl_ret);
  if(ssl_ret <= 0) return SSL_CONNECT_ERR; // SSL connection failed

  if (SSL_get_verify_result(ssl) != X509_V_OK) {
    printf("The verification of STUN server doesn't pass!\n");
    return SSL_VERIFY_FAIL;
  }

  if (serverid != NULL) {	// for RFC 2818
    peer = SSL_get_peer_certificate(ssl);
    X509_NAME_get_text_by_NID(X509_get_subject_name(peer),
			      NID_commonName, peer_CN, 256);
    if (strcasecmp(peer_CN, serverid)) {	// not equal
      printf("(TLS) the name doesn't match host name\n");
      return STUN_SERVERID_ERR;
    }
  }
  return NO_ERR;
}

static void ssl_info_callback(SSL * in_ssl, int w, int r)
{
  printf("     --- SSL : %s\n", SSL_state_string_long(in_ssl));
  if (w & SSL_CB_ALERT)
    printf("     --- ALERT : %s\n", SSL_alert_desc_string_long(r));
}

int tls_load_root_cert(char *path_to_cert)
{
  if (path_to_cert == NULL) {
    printf("Error loading cert!  Path to cert is NULL!\n");
    return -1;
  } else {
    printf("Loading certificate %s . . . \n", path_to_cert);
  }

  SSL_CTX_set_info_callback(ctx, (void (*) ()) ssl_info_callback);
  //SSL_CTX_set_info_callback(ctx, (*ssl_info_callback));

  if (SSL_CTX_load_verify_locations(ctx, path_to_cert, NULL) == 0) {
    printf("(TLS) Failed to initalize path to root certificate!\n");
    printf("Error : %s\n", ERR_error_string(ERR_get_error(), NULL));
    SSL_CTX_free(ctx);
    ctx = NULL;
    return -1;
  }

  if (SSL_CTX_set_default_verify_paths(ctx) == 0) {
    printf("(TLS) Failed to initalize root certificate!\n");
    printf("Error : %s\n", ERR_error_string(ERR_get_error(), NULL));
    SSL_CTX_free(ctx);
    ctx = NULL;
    return -1;
  }

  return 0;
}

int shared_secret_negotiate(StunAddress4 * dest,
			    bool verbose)
{
  char buf[STUN_MAX_MESSAGE_SIZE];
  int buflen = STUN_MAX_MESSAGE_SIZE;
  int len, count;
  UInt32 interval = 0;
  StunMessage req, resp;
  bool ret;

  memset(&req, 0, sizeof(StunMessage));
  stunCreateSharedSecretRequest(&req);
  memset(buf, 0, sizeof(buf));
  count = 0;
  while ((len = shared_secret_message(&req, buf, buflen,
				      dest, verbose)) < 0) {
    count++;
    if (count == 9)
      break;

    if (count == 1)
      interval = 100;
    else {
      interval *= 2;
      if (interval >= 1600)
	interval = 1600;
    }
    usleep(interval * 1000);
    memset(buf, 0, sizeof(buf));
  }
  if (len < 0)
    return SHAREDSECRET_MSG_ERR;
  if (verbose)
    printf("Got a shared secret response\n");
  memset(&resp, 0, sizeof(StunMessage));
  ret = stunParseMessage(buf, len, &resp, verbose);
  if (ret) {
    if (verbose) {
      int i;
      printf("Parse shared secret response ok!\n");
      printf("Msg type = 0x%x\n", resp.msgHdr.msgType);
      printf("Msg len = %d\n", resp.msgHdr.msgLength);
      printf("\t id= ");
      for (i = 0; i < 16; i++)
	printf("%2x ", resp.msgHdr.id.octet[i]);
      printf("\n");
    }
    if (resp.hasUsername)
      memcpy(&gotusername, &(resp.username), sizeof(StunAtrString));
    if (resp.hasPassword)
      memcpy(&gotpassword, &(resp.password), sizeof(StunAtrString));

    if ((resp.hasUsername) && (resp.hasPassword))
      return NO_ERR;
    else {
      memset(&gotusername, 0, sizeof(StunAtrString));
      memset(&gotpassword, 0, sizeof(StunAtrString));
      return GET_SHAREDSECRET_FAIL;
    }
  } else {
    if (verbose)
      printf("Shared Secret Response Error!\n");
    return SHAREDSECRET_MSG_ERR;
  }
}

int shared_secret_message(StunMessage * req, char *buf,
			  int buflen, StunAddress4 * dest, bool verbose)
{
  int len;
  int r;
  UInt32 addr = ntohl(dest->addr);

  len = stunEncodeMessage(req, buf, buflen, NULL, verbose);

  r = SSL_write(ssl, buf, len);
  switch (SSL_get_error(ssl, r)) {
  case SSL_ERROR_NONE:
    if (len != r) {
      printf("SSL write incompletely!\n");
      return -1;
    } else {
      printf("Send %d bytes to %s over TLS\n", len,
	     inet_ntoa(*(struct in_addr *) &addr));
    }
    break;
  default:
    printf("SSL write problem!\n");
    return -1;
  }

  while (1) {
    r = SSL_read(ssl, buf, STUN_MAX_MESSAGE_SIZE);
    switch (SSL_get_error(ssl, r)) {
    case SSL_ERROR_NONE:
      len = r;
      printf("Receive %d bytes from %s over TLS\n", len,
	     inet_ntoa(*(struct in_addr *) &addr));
      return len;
      break;
    case SSL_ERROR_ZERO_RETURN:
      r = SSL_shutdown(ssl);
      if (r != 1)
	printf("SSL shutdown failed!\n");
      return -1;
      break;
    default:
      printf("SSL read problem!\n");
      return -1;
    }
  }
}

/* ====================================================================
 * Revision History:
 *
 * $Log: tlsconnect.c,v $
 * Revision 1.4  2004/05/17 12:55:36  erict
 * Change file header comments
 *
 * ====================================================================
 */


