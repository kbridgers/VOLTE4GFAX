#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DIGEST_SHA1		0x02

int SHA1_Calc(unsigned char *output, unsigned char *input, unsigned int len);

int HMAC_SHA1_Init(unsigned int *output, unsigned char *key, unsigned int key_len);

int HMAC_SHA1_Calc(unsigned char *output, unsigned char *input, unsigned int input_len,
				unsigned int *key_hash);

int HMAC_Calc(unsigned char *output, unsigned char *input, unsigned int input_len,
			unsigned char *key, unsigned int key_len, unsigned char method);

int Digest_Calc(unsigned char *output, unsigned char *input, 
				 unsigned int len, unsigned char method);

