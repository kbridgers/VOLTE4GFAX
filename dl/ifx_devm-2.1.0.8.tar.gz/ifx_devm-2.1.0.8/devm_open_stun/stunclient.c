/* ====================================================================
 * Copyright (c) 2004 - Infeneon-ADMtek Technologies AG.
 *
 * All rights reserved.
 * ====================================================================
 *
 * ====================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ====================================================================
 */
                                                                                
/* ====================================================================
 *
 * File Name: stunclient.c
 * Author: Eric Tsai
 * Date:
 *
 * ====================================================================
 *
 * Projects: <Amazon/Stun>
 * Block: <Client/sample>
 *
 * ====================================================================
 * Contents:
 *
 * ====================================================================
 * References:
 */

#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>

#include "ifx_stun_api.h"


void usage(void)
{
  printf("stunc v0.91.3(20050617) by Infineon-ADMtek\n");
  printf("Usage:\n");
  printf
      ("    ./stunclient stunServer [-v] [-q] [-t] [-p srcPort] [-i srcAddress]\n");
  printf("  -v verbose\n");
  printf("  -q quick mode\n");
  printf("  -t shared secret negociation over TLS\n\n");

  printf
      ("For example, if the STUN server was stun.ifx.com, you could do:\n");
  printf("   ./stunclient stun.ifx.com\n");
  printf("Return Values:\n");
  printf(" -1  Generic Error\n\n");
  printf("low order bits (mask 0x07)\n");
  printf("  0  No NAT Present (Open)\n");
  printf("  1  Full Cone NAT\n");
  printf("  2  Address Restricted Cone NAT\n");
  printf("  3  Port Restricted Cone NAT\n");
  printf("  4  Symmetric NAT\n");
  printf("  5  Symmetric Firewall\n");
  printf("  6  Blocked or Network Error\n\n");
  printf("0x08 bit is set if the NAT supports hairpinning\n\n");
}

void exitstun(void)
{
  IFX_STUN_Reset();
  exit(0);
}

#ifdef USESSL
int main(int argc, char *argv[])
{
  int32 arg;
  int32 port = 0;
  Boolean init_TLS_flag = 0;
  int32 iRetSSN = -1;
  int32 iRetNatDetect = -1;
  T_IFX_STUN_OTP tOTP;
  T_IFX_STUN_BINDING tEntry;
  char8 cSrcAddr[20], cServername[20];
  int32 addr;
  char8 cOption = 0;

  memset(cSrcAddr, 0, sizeof(cSrcAddr));
  memset(cServername, 0, sizeof(cServername));
  IFX_STUN_Reset();

  for (arg = 1; arg < argc; arg++) {
    if (!strcmp(argv[arg], "-i")) {
      arg++;
      if (argc <= arg) {
	usage();
	exitstun();
      }
      strcpy(cSrcAddr, argv[arg]);
    } else if (!strcmp(argv[arg], "-p")) {
      arg++;
      if (argc <= arg) {
	usage();
	exitstun();
      }
      port = strtol(argv[arg], NULL, 10);
    } else if (!strcmp(argv[arg], "-t")) {
      if (IFX_STUN_TLS_Init((char *) "./myrootca.crt") >= 0)
	init_TLS_flag = 1;
      else {
	printf("Init TLS failed! Bye bye!\n");
	exitstun();
      }
    } else if (!strcmp(argv[arg], "-v")) {
      cOption |= 0x01;
    } else if (!strcmp(argv[arg], "-q")) {
      cOption |= 0x02;
    } else {
      strcpy(cServername, argv[arg]);
    }
  }

  if (argc < 2) {
    usage();
    exitstun();
  }

  memset(&tOTP, 0, sizeof(T_IFX_STUN_OTP));
  if (init_TLS_flag) {
    iRetSSN = IFX_STUN_SharedSecretNegotiate(cServername, &tOTP);
    if(iRetSSN != NO_ERR) exit(0);
  }
  memset(&tEntry, 0, sizeof(T_IFX_STUN_BINDING));
  if (inet_aton(cSrcAddr, (struct in_addr *) &addr))
    tEntry.iSrcIP = htonl(addr);
  if (port)
    tEntry.iSrcPort = (int16) port;
  iRetNatDetect = IFX_STUN_NAT_Detect(cServername, &tOTP, &tEntry, cOption);
  printf("iRetNatDetect = %d\n", iRetNatDetect);

  addr = ntohl(tEntry.iSrcIP);
  printf("SourceAddress: %s:%d\n", inet_ntoa(*(struct in_addr *) &addr),
         tEntry.iSrcPort);
  addr = ntohl(tEntry.iMappedIP);
  printf("MappedAddress: %s:%d\n", inet_ntoa(*(struct in_addr *) &addr),
         tEntry.iMappedPort);

  return iRetNatDetect;
}
#else
int main(int argc, char *argv[])
{
  int32 arg;
  int32 port = 0;
  int32 iRetNatDetect = -1;
  T_IFX_STUN_OTP tOTP;
  T_IFX_STUN_BINDING tEntry;
  char8 cSrcAddr[20], cServername[20];
  int32 addr;
  char cOption = 0;

  memset(cSrcAddr, 0, sizeof(cSrcAddr));
  memset(cServername, 0, sizeof(cServername));
  for (arg = 1; arg < argc; arg++) {
    if (!strcmp(argv[arg], "-i")) {
      arg++;
      if (argc <= arg) {
	usage();
	exitstun();
      }
      strcpy(cSrcAddr, argv[arg]);
    } else if (!strcmp(argv[arg], "-p")) {
      arg++;
      if (argc <= arg) {
	usage();
	exitstun();
      }
      port = strtol(argv[arg], NULL, 10);
    } else if (!strcmp(argv[arg], "-t")) {
      printf("No SSL support!\n");
    } else if (!strcmp(argv[arg], "-v")) {
      cOption |= 0x01;
    } else if (!strcmp(argv[arg], "-q")) {
      cOption |= 0x02;
    } else {
      strcpy(cServername, argv[arg]);
    }
  }

  if (argc < 2) {
    usage();
    exitstun();
  }

  memset(&tOTP, 0, sizeof(T_IFX_STUN_OTP));
  memset(&tEntry, 0, sizeof(T_IFX_STUN_BINDING));
  if (inet_aton(cSrcAddr, (struct in_addr *) &addr))
    tEntry.iSrcIP = htonl(addr);
  if (port)
    tEntry.iSrcPort = (int16) port;
  iRetNatDetect = IFX_STUN_NAT_Detect(cServername, &tOTP, &tEntry, cOption);
  printf("iRetNatDetect = %d\n", iRetNatDetect);

  addr = ntohl(tEntry.iSrcIP);
  printf("SourceAddress: %s:%d\n", inet_ntoa(*(struct in_addr *) &addr),
         tEntry.iSrcPort);
  addr = ntohl(tEntry.iMappedIP);
  printf("MappedAddress: %s:%d\n", inet_ntoa(*(struct in_addr *) &addr),
         tEntry.iMappedPort);

  return iRetNatDetect;
}

#endif

/* ====================================================================
 * Revision History:
 *
 * $Log: stunclient.c,v $
 * Revision 1.3  2004/05/17 13:11:56  erict
 * 1. Change file header comments
 * 2. Add USESSL pre-compile option
 *
 * ====================================================================
 */

