/* ====================================================================
 * Copyright (c) 2004 - Infeneon-ADMtek Technologies AG.
 *
 * All rights reserved.
 * ====================================================================
 *
 * ====================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ====================================================================
 */
                                                                                
/* ====================================================================
 *
 * File Name: tlsconnect.h
 * Author: Eric Tsai
 * Date:
 *
 * ====================================================================
 *
 * Projects: <Amazon/Stun>
 * Block: <Client/tls>
 *
 * ====================================================================
 * Contents:
 *
 * ====================================================================
 * References:
 */

#ifndef _TLSCONNECT_H_
#define _TLSCONNECT_H_

#include "stun.h"

#define CRYPT_SESSION_KEY_CONST              "client encryption"
#define CRYPT_SESSION_KEY_CONST_SIZE         21
#define CRYPT_SESSION_KEY_SIZE               128

/*********** FUNCTION PROTOTYPES ****************/
int tls_init(char *);
int tls_shutdown(void);
int tls_connect(int, char *);
int tls_load_root_cert(char *);
int shared_secret_negotiate(StunAddress4 *, bool);
int shared_secret_message(StunMessage *, char *, int,
			  StunAddress4 *, bool);

#endif	/* _TLSCONNECT_H_ */

/* ====================================================================
 * Revision History:
 *
 * $Log: tlsconnect.h,v $
 * Revision 1.4  2004/05/17 12:56:00  erict
 * Change file header comments
 *
 * ====================================================================
 */


