#include <scrypt.h>
#include "sha1.h"

static void BE_INT2Char(unsigned int in, unsigned char *out, unsigned int start);

void SHA1_Hash(unsigned int cv[5], unsigned char * out, unsigned char * in, unsigned int len, 
			unsigned char isHMAC)
{
	unsigned char *start = in;
	unsigned char *last_segs;
	unsigned int bits_len = len * 8;
	int total_len = 0;
	unsigned int Digest_buf[5] = { 0, 0, 0, 0, 0 };
	int i;

	/*Step 1: Count padding */
	last_segs = Common_Step1(in, len, &total_len);

	/*Step 2 of sha1 */
	if(isHMAC == 1){
		BE_INT2Char(bits_len + 512, last_segs, 124);
	}else{
		BE_INT2Char(bits_len, last_segs, 124);
	}

	/*Step 3, Initial of cv*/
	memcpy(Digest_buf, cv, 20);

	/*Step 4 in sha1 */
	for (i = 0; i < total_len / (BITS_512) - 2; i++) {
		SHA1_Encode(Digest_buf, start + i * BITS_512);
	}
	if((total_len / (BITS_512) - i) == 2){
		SHA1_Encode(Digest_buf, last_segs);
	}
	SHA1_Encode(Digest_buf, last_segs + BITS_512);

	/*Step 5 */
	for (i = 0; i < 5; i++) {
		BE_INT2Char(Digest_buf[i], out, i * 4);
	}

	free(last_segs);
}

void SHA1_Encode(unsigned int * cv, unsigned char * y)
{
	int i, j;

	unsigned int W[80];
	unsigned int A = cv[0];
	unsigned int B = cv[1];
	unsigned int C = cv[2];
	unsigned int D = cv[3];
	unsigned int E = cv[4];

	/*Initial value of W */
	for (i = 0, j = 0; j < 64; i++, j += 4) {
		W[i] = ((unsigned int) y[j] << 24) | ((unsigned int) y[j + 1] << 16) | 
				((unsigned int) y[j + 2] << 8) | ((unsigned int) y[j + 3]);
	}

	for (i = 16; i < 80; i++) {
		W[i] = ROT_LEFT(W[i - 16] ^ W[i - 14] ^ W[i - 8] ^ W[i - 3], 1);
	}

	/*Round 1 */
	SHA1_R1(A, B, C, D, E, W[0], Ki1);
	SHA1_R1(E, A, B, C, D, W[1], Ki1);
	SHA1_R1(D, E, A, B, C, W[2], Ki1);
	SHA1_R1(C, D, E, A, B, W[3], Ki1);
	SHA1_R1(B, C, D, E, A, W[4], Ki1);

	SHA1_R1(A, B, C, D, E, W[5], Ki1);
	SHA1_R1(E, A, B, C, D, W[6], Ki1);
	SHA1_R1(D, E, A, B, C, W[7], Ki1);
	SHA1_R1(C, D, E, A, B, W[8], Ki1);
	SHA1_R1(B, C, D, E, A, W[9], Ki1);

	SHA1_R1(A, B, C, D, E, W[10], Ki1);
	SHA1_R1(E, A, B, C, D, W[11], Ki1);
	SHA1_R1(D, E, A, B, C, W[12], Ki1);
	SHA1_R1(C, D, E, A, B, W[13], Ki1);
	SHA1_R1(B, C, D, E, A, W[14], Ki1);

	SHA1_R1(A, B, C, D, E, W[15], Ki1);
	SHA1_R1(E, A, B, C, D, W[16], Ki1);
	SHA1_R1(D, E, A, B, C, W[17], Ki1);
	SHA1_R1(C, D, E, A, B, W[18], Ki1);
	SHA1_R1(B, C, D, E, A, W[19], Ki1);

	/*Round 2 */
	SHA1_R24(A, B, C, D, E, W[20], Ki2);
	SHA1_R24(E, A, B, C, D, W[21], Ki2);
	SHA1_R24(D, E, A, B, C, W[22], Ki2);
	SHA1_R24(C, D, E, A, B, W[23], Ki2);
	SHA1_R24(B, C, D, E, A, W[24], Ki2);

	SHA1_R24(A, B, C, D, E, W[25], Ki2);
	SHA1_R24(E, A, B, C, D, W[26], Ki2);
	SHA1_R24(D, E, A, B, C, W[27], Ki2);
	SHA1_R24(C, D, E, A, B, W[28], Ki2);
	SHA1_R24(B, C, D, E, A, W[29], Ki2);

	SHA1_R24(A, B, C, D, E, W[30], Ki2);
	SHA1_R24(E, A, B, C, D, W[31], Ki2);
	SHA1_R24(D, E, A, B, C, W[32], Ki2);
	SHA1_R24(C, D, E, A, B, W[33], Ki2);
	SHA1_R24(B, C, D, E, A, W[34], Ki2);

	SHA1_R24(A, B, C, D, E, W[35], Ki2);
	SHA1_R24(E, A, B, C, D, W[36], Ki2);
	SHA1_R24(D, E, A, B, C, W[37], Ki2);
	SHA1_R24(C, D, E, A, B, W[38], Ki2);
	SHA1_R24(B, C, D, E, A, W[39], Ki2);

	/*Round 3 */
	SHA1_R3(A, B, C, D, E, W[40], Ki3);
	SHA1_R3(E, A, B, C, D, W[41], Ki3);
	SHA1_R3(D, E, A, B, C, W[42], Ki3);
	SHA1_R3(C, D, E, A, B, W[43], Ki3);
	SHA1_R3(B, C, D, E, A, W[44], Ki3);

	SHA1_R3(A, B, C, D, E, W[45], Ki3);
	SHA1_R3(E, A, B, C, D, W[46], Ki3);
	SHA1_R3(D, E, A, B, C, W[47], Ki3);
	SHA1_R3(C, D, E, A, B, W[48], Ki3);
	SHA1_R3(B, C, D, E, A, W[49], Ki3);

	SHA1_R3(A, B, C, D, E, W[50], Ki3);
	SHA1_R3(E, A, B, C, D, W[51], Ki3);
	SHA1_R3(D, E, A, B, C, W[52], Ki3);
	SHA1_R3(C, D, E, A, B, W[53], Ki3);
	SHA1_R3(B, C, D, E, A, W[54], Ki3);

	SHA1_R3(A, B, C, D, E, W[55], Ki3);
	SHA1_R3(E, A, B, C, D, W[56], Ki3);
	SHA1_R3(D, E, A, B, C, W[57], Ki3);
	SHA1_R3(C, D, E, A, B, W[58], Ki3);
	SHA1_R3(B, C, D, E, A, W[59], Ki3);

	/*Round 4 */
	SHA1_R24(A, B, C, D, E, W[60], Ki4);
	SHA1_R24(E, A, B, C, D, W[61], Ki4);
	SHA1_R24(D, E, A, B, C, W[62], Ki4);
	SHA1_R24(C, D, E, A, B, W[63], Ki4);
	SHA1_R24(B, C, D, E, A, W[64], Ki4);

	SHA1_R24(A, B, C, D, E, W[65], Ki4);
	SHA1_R24(E, A, B, C, D, W[66], Ki4);
	SHA1_R24(D, E, A, B, C, W[67], Ki4);
	SHA1_R24(C, D, E, A, B, W[68], Ki4);
	SHA1_R24(B, C, D, E, A, W[69], Ki4);

	SHA1_R24(A, B, C, D, E, W[70], Ki4);
	SHA1_R24(E, A, B, C, D, W[71], Ki4);
	SHA1_R24(D, E, A, B, C, W[72], Ki4);
	SHA1_R24(C, D, E, A, B, W[73], Ki4);
	SHA1_R24(B, C, D, E, A, W[74], Ki4);

	SHA1_R24(A, B, C, D, E, W[75], Ki4);
	SHA1_R24(E, A, B, C, D, W[76], Ki4);
	SHA1_R24(D, E, A, B, C, W[77], Ki4);
	SHA1_R24(C, D, E, A, B, W[78], Ki4);
	SHA1_R24(B, C, D, E, A, W[79], Ki4);

	cv[0] += A;
	cv[1] += B;
	cv[2] += C;
	cv[3] += D;
	cv[4] += E;

	memset(W, 0, 80);
}

static void BE_INT2Char(unsigned int in, unsigned char *out, unsigned int start){
    out[start] = (unsigned char) ((in >> 24) & 0xff);
    out[start + 1] = (unsigned char) ((in >> 16) & 0xff);
    out[start + 2] = (unsigned char) ((in >> 8) & 0xff); 
    out[start + 3] = (unsigned char) (in & 0xff);
}
