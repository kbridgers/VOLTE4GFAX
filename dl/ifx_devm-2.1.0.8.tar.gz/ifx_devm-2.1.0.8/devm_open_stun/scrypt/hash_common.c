#include "hash_common.h"

unsigned char *Common_Step1(unsigned char *in, unsigned int len, int *total_len){
	int padding_len = 0;
	unsigned char *last_segs;

    padding_len = BITS_448 - len % (BITS_512);
    if (padding_len <= 0) {
        padding_len += BITS_512;
    }

    *total_len = len + padding_len + BITS_64;

    last_segs = malloc(BITS_1024);  //�N�ӥΦۤv��malloc���N,
    memset(last_segs, 0, BITS_1024);    //�N�i�smemset�]�b�� 

    if (*total_len == BITS_512) {
        memcpy(last_segs + BITS_512, in, len);
    } else {
        memcpy(last_segs, in + (*total_len - BITS_1024),
               BITS_1024 - padding_len - BITS_64);
    }
    memcpy(last_segs + BITS_1024 - padding_len - BITS_64, PADDING_BITS,
           padding_len);

	return last_segs;
}

