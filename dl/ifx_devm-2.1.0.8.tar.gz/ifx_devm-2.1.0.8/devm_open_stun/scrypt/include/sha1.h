#include "hash_common.h"
#include "hash_funcs.h"

#define Ki1 0x5a827999
#define Ki2 0x6ed9eba1
#define Ki3 0x8f1bbcdc
#define Ki4 0xca62c1d6

#define F1(b, c, d) ((b & c) | (~b & d))
#define F3(b, c, d) ((b & c) | (b & d) | (c & d))
#define F24(b, c, d) ((b) ^ (c) ^ (d))

#define SHA1_R1(a, b, c, d, e, w, k) { \
	e += F1(b, c, d) + ROT_LEFT(a, 5) + w + k; \
	b = ROT_LEFT(b, 30); \
}

/*Since Round 2 only differ with round 4 in constant K,
  I'll deal it in function "Sha1_Encode" :-). 
  M.A. C.S. Lee */
#define SHA1_R24(a, b, c, d, e, w, k) { \
	e += F24(b, c, d) + ROT_LEFT(a, 5) + w + k; \
	b = ROT_LEFT(b, 30); \
}

#define SHA1_R3(a, b, c, d, e, w, k) { \
	e += F3(b, c, d) + ROT_LEFT(a, 5) + w + k; \
	b = ROT_LEFT(b, 30); \
}

