#ifndef _HASH_COMMON_H

#define _HASH_COMMON_H
#include <scrypt.h>

#define ROT_LEFT(x, n) (((x) << (n)) | ((x) >> (32 - (n))))
#define ROT_RIGHT(x, n) (((x) >> (n)) | ((x) << (32 - (n))))

#define BITS_64 8
#define BITS_512 64
#define BITS_448 56
#define BITS_1024 128

static const unsigned char PADDING_BITS[64] = {
	0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

unsigned char *Common_Step1(unsigned char *, unsigned int, int *);

#endif
