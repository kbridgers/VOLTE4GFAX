void MD5_Hash(unsigned int cv[5], unsigned char *out, 
			unsigned char *in, unsigned int len,
			unsigned char isHMAC);
void MD5_Encode(unsigned int *, unsigned char *);

void SHA1_Hash(unsigned int cv[5], unsigned char *out, 
			unsigned char *in, unsigned int len,
			unsigned char isHMAC);
void SHA1_Encode(unsigned int *, unsigned char *);

void RMD160_Hash(unsigned int cv[5], unsigned char *out, 
			unsigned char *in, unsigned int len,
			unsigned char isHMAC);
void RMD160_Encode(unsigned int *, unsigned char *);

void SHA256_Hash(unsigned int cv[8], unsigned char *out, 
			unsigned char *in, unsigned int len,
			unsigned char isHMAC);
void SHA256_Encode(unsigned int *, unsigned char *);
