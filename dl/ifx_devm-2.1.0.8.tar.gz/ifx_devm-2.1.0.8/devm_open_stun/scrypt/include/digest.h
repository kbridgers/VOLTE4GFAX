
//The initial constant of sha1 is equal to ripemd
static unsigned int SHA1_CONST[5] =
{0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476, 0xc3d2e1f0};

