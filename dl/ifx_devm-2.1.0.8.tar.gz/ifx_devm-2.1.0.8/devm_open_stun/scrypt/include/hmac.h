#include <scrypt.h>
#include "digest.h"
#include "hash_funcs.h"
