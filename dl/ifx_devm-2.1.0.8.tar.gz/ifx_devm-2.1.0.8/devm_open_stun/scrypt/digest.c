#include <scrypt.h>
#include "digest.h"
#include "hash_funcs.h"

int SHA1_Calc(unsigned char *out, unsigned char *in, unsigned int len){
	if(out == NULL || in == NULL)
		return -1;

    SHA1_Hash((unsigned int *)SHA1_CONST, out, in, len, 0);

	return 1;
}

int Digest_Calc(unsigned char *out, unsigned char *in, unsigned int len, unsigned char method){
	if(out == NULL || in == NULL)
		return -1;

	if(method == DIGEST_SHA1){
		SHA1_Hash((unsigned int *)SHA1_CONST, out, in, len, 0);
	}else{
		return -1;
	}

	return 1;
}

