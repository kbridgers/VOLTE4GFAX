#include "hmac.h"

static void HMAC_Common_Init(unsigned char *key, unsigned int key_len,
							unsigned char *Si, unsigned char *So, 
							unsigned char method);


int HMAC_SHA1_Init(unsigned int *output, unsigned char *key, unsigned int key_len){
	unsigned char *Si, *So;
	unsigned int out_tmp1[5], out_tmp2[5];

	if(output == NULL || key == NULL || key_len == 0){
		return -1;
	}

	/*Step 1, 2, 5 will be the same in HMAC_MD5, HMAC_SHA1, HMAC_RMD160*/
	Si = malloc(64);
	memset(Si, 0, 64);

	So = malloc(64);
	memset(So, 0, 64);

	HMAC_Common_Init(key, key_len, Si, So, DIGEST_SHA1);

	/*Count hash of Si*/
	memcpy(out_tmp1, SHA1_CONST, 20);
	SHA1_Encode(out_tmp1, Si);

	/*Count hash of Si*/
	memcpy(out_tmp2, SHA1_CONST, 20);
	SHA1_Encode(out_tmp2, So);

	/*Generate output in one loop*/
	memcpy(output, out_tmp1, 20);
	memcpy(output + 5, out_tmp2, 20);

	free(Si);
	free(So);

	return 1;
}

static void HMAC_Common_Init(unsigned char *key, unsigned int key_len,
							unsigned char *Si, unsigned char *So, unsigned char method){
	int i;
	/*Step 1, make k+; 
	  k_plus will be Si with ipad, So with opad, thus omitted here*/
	if(key_len > 64){
		unsigned char key_tmp[16];

		Digest_Calc(key_tmp, key, key_len, method);

		key = key_tmp;
		key_len = 16;
	}
	memcpy(Si, key, key_len);
	memcpy(So, key, key_len);

	/*Step 2, 5, make Si and So*/
	for(i = 0; i < 64; i++){
		Si[i] ^= 0x36;	/*xor with 0b00110110 series*/
		So[i] ^= 0x5c;  /*xor with 0b01011100 series*/		
	}
}

int HMAC_SHA1_Calc(unsigned char *output, unsigned char *input, unsigned int input_len,
				   unsigned int *key_hash){
	unsigned char out_tmp[20];

	if(output == NULL || input == NULL || key_hash == NULL || input_len == 0)
		return -1;

	/*Calc message hash, use hash of Si as IV*/
	/*Some source will call this action as "inner hash"*/
	SHA1_Hash(key_hash, out_tmp, input, input_len, 1);

	/*So let's do some "outer hash" now*/
	/*Use output of inner hash as input here*/
	SHA1_Hash(key_hash + 5, output, out_tmp, 20, 1);

	return 1;
}

int HMAC_Calc(unsigned char *output, unsigned char *input, unsigned int input_len,
			   unsigned char *key, unsigned int key_len, unsigned char method){

	if(output == NULL || input == NULL || key == NULL || 
		key_len == 0 || input_len == 0)
		return -1;

	if(method == DIGEST_SHA1){
		unsigned int tmp[10];
		HMAC_SHA1_Init(tmp, key, key_len);
		HMAC_SHA1_Calc(output, input, input_len, tmp);
	}else
		return -1;

	return 1;
}

