/* ====================================================================
 * Copyright (c) 2004 - Infeneon-ADMtek Technologies AG.
 *
 * All rights reserved.
 * ====================================================================
 *
 * ====================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ====================================================================
 */
                                                                                
/* ====================================================================
 *
 * File Name: ifx_stun_api.c
 * Author: Eric Tsai
 * Date:
 *
 * ====================================================================
 *
 * Projects: <Amazon/Stun>
 * Block: <Client/api>
 *
 * ====================================================================
 * Contents:
 *
 * ====================================================================
 * References:
 */

#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>

#include "ifx_stun_types.h"
#include "ifx_stun_api.h"
#include "stun.h"

#ifdef USESSL
#include "tlsconnect.h"
#endif

int natType = -1;
T_IFX_STUN_BINDING bindEntry;
Boolean init_TLS = false;
StunAddress4 stunServerAddr;
extern Socket tcp_connect(UInt32 *);

#ifdef USESSL
void IFX_STUN_TLS_Shutdown(void)
{
  if (init_TLS) {
    tls_shutdown();
    init_TLS = false;
  }
}
#endif

static Boolean IFX_STUN_Get_Server(char8 * pcServername,
				   StunAddress4 * addr)
{
  Boolean ret = stunParseServerName(pcServername, addr);
  if (ret != true) {
    printf("%s is not a valid host name\n", pcServername);
  }
  return ret;
}

#ifdef USESSL
int32 IFX_STUN_TLS_Init(char8 * rootca)
{
  int32 ret = 0;
  ret = tls_init(rootca);
  bindEntry.iSrcIP=0;
  bindEntry.iSrcPort=0;
  bindEntry.iMappedIP=0;
  bindEntry.iMappedPort=0;
  if (ret == NO_ERR)
    init_TLS = true;
  return ret;
}
#endif

void IFX_STUN_Reset(void)
{
#ifdef USESSL
  IFX_STUN_TLS_Shutdown();
#endif
  memset(&stunServerAddr, 0, sizeof(StunAddress4));
  stunSetUserPass(NULL, NULL); // Reset
}

#ifdef USESSL
int32 IFX_STUN_SharedSecretNegotiate(char8 * pcServername,
				     T_IFX_STUN_OTP * ptOTP)
{
  Socket tcp_sock = 0;
  int32 ret = 0;
  StunAtrString username, password;
  Boolean bret = false;

  if (init_TLS != true)
    return SSL_NOT_INIT_YET;
  memset(&stunServerAddr, 0, sizeof(StunAddress4));
  if ((bret = IFX_STUN_Get_Server(pcServername, &stunServerAddr)) == false) {
    memset(&stunServerAddr, 0, sizeof(StunAddress4));
    IFX_STUN_TLS_Shutdown();
    return STUN_SERVER_UNKNOWN;
  }

  tcp_sock = tcp_connect(&(stunServerAddr.addr));
  if (tcp_sock < 0) {
    printf("TCP for TLS failed! Bye bye!\n");
    IFX_STUN_TLS_Shutdown();
    return TCP_CONNECT_FAIL;
  } else {
    if ((ret = tls_connect(tcp_sock, pcServername)) < 0) {
      printf("TLS connect failed! Bye bye!\n");
      IFX_STUN_TLS_Shutdown();
      return ret;
    }
    printf("TLS connect successfully! Start shared secret negociation.\n");
    if ((ret = shared_secret_negotiate(&stunServerAddr, false))
	< 0) {
      printf("Shared secret negociate failed!\n");
      IFX_STUN_TLS_Shutdown();
      return ret;
    } else {
      printf("Got username and shared secret(OTP)!\n");
      stunGetUserPass(&username, &password);
      memcpy(ptOTP->cUsername, username.value, username.sizeValue);
      ptOTP->iUsernameSize = username.sizeValue;
      memcpy(ptOTP->cPassword, password.value, password.sizeValue);
      ptOTP->iPasswordSize = password.sizeValue;
      return NO_ERR;
    }
  }
}
#endif

int32 IFX_STUN_NAT_GetBinding(T_IFX_STUN_BINDING * ptEntry)
{
  *ptEntry=bindEntry;
  return natType;
}

int32 IFX_STUN_NAT_Detect(char8 * pcServername, T_IFX_STUN_OTP * ptOTP,
			  T_IFX_STUN_BINDING * ptEntry, char8 cOption)
{
  StunAddress4 sAddr, mAddr;
  StunAtrString username, password;
  int32 retval = 0;
  bool presPort = false;
  bool hairpin = false;
  bool bVerbose, bQuick;
  NatType stype;

  if ((stunServerAddr.addr == 0)||(iServerAddressReset == 1)) {
    Boolean bret = false;
    iServerAddressReset = 0;  //reset the flag that is set in cwmp stack
    if ((bret =
	 IFX_STUN_Get_Server(pcServername, &stunServerAddr)) == false) {
      memset(&stunServerAddr, 0, sizeof(StunAddress4));
#ifdef USESSL
      IFX_STUN_TLS_Shutdown();
#endif
      return STUN_SERVER_UNKNOWN;
    }
  }

  if (ptOTP) {
    memset(&username, 0, sizeof(StunAtrString));
    memcpy(username.value, ptOTP->cUsername, ptOTP->iUsernameSize);
    username.sizeValue = ptOTP->iUsernameSize;
    memset(&password, 0, sizeof(StunAtrString));
    memcpy(password.value, ptOTP->cPassword, ptOTP->iPasswordSize);
    password.sizeValue = ptOTP->iPasswordSize;
    stunSetUserPass(&username, &password);
  }

  if (cOption & 0x01) bVerbose = true;
  else bVerbose = false;
  if (cOption & 0x02) bQuick = true;
  else bQuick = false;
 
  memset(&bindEntry, 0, sizeof(T_IFX_STUN_BINDING));

  printf("Stun binding messages communication...\n");

  sAddr.addr = ptEntry->iSrcIP;
  sAddr.port = ptEntry->iSrcPort;
  stype = stunNatType(&stunServerAddr, bVerbose, &presPort, &hairpin, bQuick, 
			sAddr.port, &sAddr, &mAddr);
  ptEntry->iMappedIP = mAddr.addr;
  ptEntry->iMappedPort = mAddr.port;
  ptEntry->iSrcPort = sAddr.port;

  /* Store values, to be able to query them again without complete STUN check */
  bindEntry.iSrcIP = ptEntry->iSrcIP;
  bindEntry.iSrcPort = ptEntry->iSrcPort;
  bindEntry.iMappedIP = mAddr.addr;
  bindEntry.iMappedPort = mAddr.port;

  printf("Internet connection is type: ");
  switch (stype) {
  case StunTypeUnknown:
    printf("Some error detetecting NAT type");
    retval = 0x07;
    break;
  case StunTypeOpen:
    printf("Open");
    retval = 0;
    break;
  case StunTypeConeNat:
    printf("Full Cone Nat");
    if (presPort)
      printf(", preserves ports");
    else
      printf(", random port");
    if (hairpin)
      printf(", will hairpin");
    else
      printf(", no hairpin");
    retval = 0x01;
    break;
  case StunTypeRestrictedNat:
    printf("Address Restricted Nat");
    if (presPort)
      printf(", preserves ports");
    else
      printf(", random port");
    if (hairpin)
      printf(", will hairpin");
    else
      printf(", no hairpin");
    retval = 0x02;
    break;
  case StunTypePortRestrictedNat:
    printf("Port Restricted Nat");
    if (presPort)
      printf(", preserves ports");
    else
      printf(", random port");
    if (hairpin)
      printf(", will hairpin");
    else
      printf(", no hairpin");
    retval = 0x03;
    break;
  case StunTypeSymNat:
    printf("Symmetric Nat");
    if (presPort)
      printf(", preserves ports");
    else
      printf(", random port");
    if (hairpin)
      printf(", will hairpin");
    else
      printf(", no hairpin");
    retval = 0x04;
    break;
  case StunTypeSymFirewall:
    printf("Symmetric Firewall");
    if (hairpin)
      printf(", will hairpin");
    else
      printf(", no hairpin");
    retval = 0x05;
    break;
  case StunTypeBlocked:
    printf("Blocked or could not reach STUN server");
    retval = 0x06;
    break;
  default:
    printf("Unkown NAT type: %d\n", stype);
    retval = 0x07;		// Unknown NAT type
    break;
  }
  printf("\n");
  if (hairpin) {
    retval |= 0x08;
  }

  natType = retval;
  return retval;
}

/* ====================================================================
 * Revision History:
 *
 * $Log: ifx_stun_api.c,v $
 * Revision 1.4  2004/05/17 12:44:48  erict
 * Add USESSL precompile option
 *
 * ====================================================================
 */

