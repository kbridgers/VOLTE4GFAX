/* ====================================================================
 * Copyright (c) 2004 - Infeneon-ADMtek Technologies AG.
 *
 * All rights reserved.
 * ====================================================================
 *
 * ====================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ====================================================================
 */
                                                                                
#ifndef STUN_H
#define STUN_H

#include "udp.h"

// if you change this version, change in makefile too 
#define STUN_VERSION_MAJOR 0
#define STUN_VERSION_MINOR 91

#define STUN_MAX_STRING 256

#define STUN_MAX_UNKNOWN_ATTRIBUTES 4

#define STUN_MAX_MESSAGE_SIZE 2048

#define STUN_PORT 3478

//#define true  1
//#define false 0

// define some basic types
typedef unsigned char UInt8;
typedef unsigned short UInt16;
typedef unsigned int UInt32;
//typedef char           bool;
#if defined( WIN32 )
typedef unsigned __int64 UInt64;
#else
typedef unsigned long long UInt64;
#endif
typedef struct {
  unsigned char octet[16];
} UInt128;

/// define a structure to hold a stun address 
//const UInt8  IPv4Family = 0x01;
//const UInt8  IPv6Family = 0x02;
#define  IPv4Family  0x01
#define  IPv6Family  0x02

// define  flags  
//const UInt32 ChangeIpFlag   = 4;
//const UInt32 ChangePortFlag = 2;
#define ChangeIpFlag    4
#define ChangePortFlag  2


// define  stun attribute
#define MappedAddress     0x0001
#define ResponseAddress   0x0002
#define ChangeRequest     0x0003
#define SourceAddress     0x0004
#define ChangedAddress    0x0005
#define Username          0x0006
#define Password          0x0007
#define MessageIntegrity  0x0008
#define ErrorCode         0x0009
#define UnknownAttribute  0x000A
#define ReflectedFrom     0x000B

#ifdef TR111_STUN

	#define ConnectionRequestBinding	0xC001
	#define	BindingChange				0xC002

#endif /* TR111_STUN */ 

// define types for a stun message 
#define BindRequestMsg                0x0001
#define BindResponseMsg               0x0101
#define BindErrorResponseMsg          0x0111
#define SharedSecretRequestMsg        0x0002
#define SharedSecretResponseMsg       0x0102
#define SharedSecretErrorResponseMsg  0x0112

#define udpMaxMessageLength           10240

// define error code
#define NO_ERR				0
#define INIT_SSL_ERR			-100 
#define LOAD_ROOTCA_ERR			-105
#define SSL_NOT_INIT_YET		-110
#define STUN_SERVER_UNKNOWN		-115
#define TCP_CONNECT_FAIL		-120
#define CREATE_SSL_ERR			-125
#define SSL_CONNECT_ERR			-130
#define SSL_VERIFY_FAIL			-135
#define STUN_SERVERID_ERR		-140
#define SHAREDSECRET_MSG_ERR		-145
#define GET_SHAREDSECRET_FAIL		-150
#define INTEGRITY_ERR			-155
#define MISS_USERNAME			-160

typedef struct {
  UInt16 msgType;
  UInt16 msgLength;
  UInt128 id;
} StunMsgHdr;


typedef struct {
  UInt16 type;
  UInt16 length;
} StunAtrHdr;

typedef struct {
  UInt16 port;
  UInt32 addr;
} StunAddress4;

typedef struct {
  UInt8 pad;
  UInt8 family;
  StunAddress4 ipv4;
} StunAtrAddress4;


typedef struct {
  UInt32 value;
} StunAtrChangeRequest;

typedef struct {
  UInt16 pad;			// all 0
  UInt8 errorClass;
  UInt8 number;
  char reason[STUN_MAX_STRING];
  UInt16 sizeReason;
} StunAtrError;

typedef struct {
  UInt16 attrType[STUN_MAX_UNKNOWN_ATTRIBUTES];
  UInt16 numAttributes;
} StunAtrUnknown;

typedef struct {
  char value[STUN_MAX_STRING];
  UInt16 sizeValue;
} StunAtrString;


typedef struct {
  char hash[20];
} StunAtrIntegrity;

typedef enum {
  HmacUnkown,
  HmacOK,
  HmacBadUserName,
  HmacUnkownUserName,
  HmacFailed,
} StunHmacStatus;

typedef struct {
  StunMsgHdr msgHdr;

  bool hasMappedAddress;
  StunAtrAddress4 mappedAddress;

  bool hasResponseAddress;
  StunAtrAddress4 responseAddress;

  bool hasChangeRequest;
  StunAtrChangeRequest changeRequest;

  bool hasSourceAddress;
  StunAtrAddress4 sourceAddress;

  bool hasChangedAddress;
  StunAtrAddress4 changedAddress;

  bool hasUsername;
  StunAtrString username;

  bool hasPassword;
  StunAtrString password;

  bool hasMessageIntegrity;
  StunAtrIntegrity messageIntegrity;

  bool hasErrorCode;
  StunAtrError errorCode;

  bool hasUnknownAttributes;
  StunAtrUnknown unknownAttributes;

  bool hasReflectedFrom;
  StunAtrAddress4 reflectedFrom;


#ifdef TR111_STUN

//  bool hasRequestBinding;
  StunAtrString RequestBinding;

  bool hasBindingChange;
  StunAtrString BindingChange;  

#endif 


} StunMessage;

// Define enum with different types of NAT 
typedef enum {
  StunTypeUnknown,
  StunTypeOpen,
  StunTypeConeNat,
  StunTypeRestrictedNat,
  StunTypePortRestrictedNat,
  StunTypeSymNat,
  StunTypeSymFirewall,
  StunTypeBlocked,
} NatType;

// Define enum of the state of stun client 
typedef enum {
  START,
  TESTI_REQ_OUT,
  TESTI_RSP_IN_NNAT, 
  TESTI_RSP_IN_NAT, 
  TESTII_REQ_OUT_NNAT,
  TESTII_REQ_OUT_NAT, 
  TESTII_RSP_IN_NNAT,
  TESTII_RSP_IN_NAT,
  TESTI2_REQ_OUT,
  TESTI2_RSP_IN,
  TESTIII_REQ_OUT,
  TESTIII_RSP_IN,
  END,
} StunClientState;

/*#ifdef WIN32
typedef SOCKET Socket;
#else
typedef int Socket;
#endif*/

typedef struct {
  StunAddress4 myAddr;
  StunAddress4 altAddr;
  Socket myFd;
  Socket altPortFd;
  Socket altIpFd;
  Socket altIpPortFd;
} StunServerInfo;

void stunSetUserPass(StunAtrString *username, StunAtrString *password);

void stunGetUserPass(StunAtrString *username, StunAtrString *password);

bool
stunParseMessage(char *buf,
		 unsigned int bufLen, StunMessage * message, bool verbose);

void
stunBuildReqSimple(StunMessage * msg,
		   const StunAtrString * username,
		   bool changePort, bool changeIp, unsigned int id);

unsigned int
stunEncodeMessage(const StunMessage * message,
		  char *buf,
		  unsigned int bufLen,
		  const StunAtrString * password, bool verbose);

void stunCreateSharedSecretRequest(StunMessage *);

void
stunCreateUserName(const StunAddress4 * addr, StunAtrString * username);

void
stunGetUserNameAndPassword(const StunAddress4 * dest,
			   StunAtrString * username,
			   StunAtrString * password);

void
stunCreatePassword(const StunAtrString * username,
		   StunAtrString * password);

int stunRand(void);

UInt64 stunGetSystemTimeSecs(void);

/// find the IP address of a the specified stun server - return false is fails parse 
bool stunParseServerName(char *serverName, StunAddress4 * stunServerAddr);

bool
stunParseHostName(char *peerName, StunAddress4 * addr, UInt16 defaultPort);

/// returns number of address found - take array or addres 
int stunFindLocalInterfaces(UInt32 * addresses, int maxSize);

void
stunTest(StunAddress4 * dest, int testNum, bool verbose,
	 StunAddress4 * sAddr);

NatType stunNatType(StunAddress4 * dest, bool verbose, bool * preservePort,	// if set, is return for if NAT preservers ports or not
		    bool * hairpin,	// if set, is the return for if NAT will hairpin packets
		    bool quickmode,
		    int port,	// port to use for the test, 0 to choose random port
		    StunAddress4 * sAddr,	// NIC to use 
		    StunAddress4 * mAddr	// Mapped address&port
    );


int
stunOpenSocket(StunAddress4 * dest, StunAddress4 * sAddr, int port,
	       bool verbose);

bool
stunOpenSocketPair(StunAddress4 * dest, StunAddress4 * sAddr,
		   int *fd1, int *fd2, int port, bool verbose);

#endif

/* ====================================================================
 * Revision History:
 *
 * $Log: stun.h,v $
 * Revision 1.4  2004/05/17 12:54:32  erict
 * Add stunSetUserPass() and stunGetUserPass()
 * Add file header comments
 *
 * ====================================================================
 */

