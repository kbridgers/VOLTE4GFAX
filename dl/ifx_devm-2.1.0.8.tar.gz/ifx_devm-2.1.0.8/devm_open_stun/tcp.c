/* ====================================================================
 * Copyright (c) 2004 - Infeneon-ADMtek Technologies AG.
 *
 * All rights reserved.
 * ====================================================================
 *
 * ====================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ====================================================================
 */
                                                                                
/* ====================================================================
 *
 * File Name: tcp.c
 * Author: Eric Tsai
 * Date:
 *
 * ====================================================================
 *
 * Projects: <Amazon/Stun>
 * Block: <Client/tls>
 *
 * ====================================================================
 * Contents:
 *
 * ====================================================================
 * References:
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <netdb.h>
#include <string.h>

#include "stun.h"

Socket tcp_connect(UInt32 * serveraddr)
{
  struct sockaddr_in addr;
  int sock = 0;

  addr.sin_addr.s_addr = htonl(*serveraddr);
  addr.sin_family = AF_INET;
  addr.sin_port = htons(STUN_PORT);

  if ((sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
    printf("Create tcp socket failed!\n");
    return -1;
  }
  if (connect(sock, (struct sockaddr *) &addr, sizeof(addr)) < 0) {
    printf("Couldn't connect tcp socket!\n");
    return -1;
  }

  return sock;
}

/* ====================================================================
 * Revision History:
 *
 * $Log: tcp.c,v $
 * Revision 1.4  2004/05/17 12:55:01  erict
 * Change file header comments
 *
 * ====================================================================
 */

