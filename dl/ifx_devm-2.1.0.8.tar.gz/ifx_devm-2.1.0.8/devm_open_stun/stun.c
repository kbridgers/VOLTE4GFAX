/* ====================================================================
 * Copyright (c) 2004 - Infeneon-ADMtek Technologies AG.
 *
 * All rights reserved.
 * ====================================================================
 *
 * ====================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ====================================================================
 */

#include <stdlib.h>
#include <assert.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/nameser.h>
#include <resolv.h>
#include <net/if.h>

#if defined(__sparc__) || defined(WIN32) || defined(linux)
#endif


#include "stun.h"
#include "sha1.h"

StunAtrString gotusername;
StunAtrString gotpassword;
int StunState; /* for state machine */
int MaxRetran;
int request_bind = TRUE;


extern int closesocket(Socket fs);
extern int getErrno(void);

void stunSetUserPass(StunAtrString *username, StunAtrString *password)
{
  memset(&gotusername, 0, sizeof(StunAtrString));
  if(username){
    memcpy(&gotusername, username, sizeof(StunAtrString));
    printf("Set user: %s\n", gotusername.value);
  }
  memset(&gotpassword, 0, sizeof(StunAtrString));
  if(password){
    memcpy(&gotpassword, password, sizeof(StunAtrString));
    printf("Set pass: %s\n", gotpassword.value);
  }
}

void stunGetUserPass(StunAtrString *username, StunAtrString *password)
{
  if(username){
    memset(username, 0, sizeof(StunAtrString));
    memcpy(username, &gotusername, sizeof(StunAtrString));
  }
  if(password){
    memset(password, 0, sizeof(StunAtrString));
    memcpy(password, &gotpassword, sizeof(StunAtrString));
  }
}

static void
computeHmac(char *hmac, const char *input, int length, const char *key,
	    int keySize);

static bool
stunParseAtrAddress(char *body, unsigned int hdrLen,
		    StunAtrAddress4 * result)
{
  if (hdrLen != 8) {
    printf("hdrLen wrong for Address\n");
    return false;
  }
  result->pad = *body++;
  result->family = *body++;
  if (result->family == IPv4Family) {
    UInt32 naddr;
    UInt16 nport;
    memcpy(&nport, body, 2);
    body += 2;
    result->ipv4.port = ntohs(nport);

    memcpy(&naddr, body, 4);
    body += 4;
    result->ipv4.addr = ntohl(naddr);
    return true;
  } else if (result->family == IPv6Family) {
    printf("ipv6 not supported\n");
  } else {
    printf("bad address family: %d\n", result->family);
  }

  return false;
}

static bool
stunParseAtrChangeRequest(char *body, unsigned int hdrLen,
			  StunAtrChangeRequest * result)
{
  if (hdrLen != 4) {
    printf("hdr length = %d, expecting %d\n", hdrLen, sizeof(result));

    printf("Incorrect size for ChangeRequest\n");
    return false;
  } else {
    memcpy(&(result->value), body, sizeof(UInt32));
    result->value = ntohl(result->value);
    return true;
  }
}

static bool
stunParseAtrError(char *body, unsigned int hdrLen, StunAtrError * result)
{
  if (hdrLen >= sizeof(StunAtrError)) {
    printf("head on Error too large\n");
    return false;
  } else {
    memcpy(&(result->pad), body, sizeof(UInt16));
    body += 2;
    result->pad = ntohs(result->pad);
    result->errorClass = *body++;
    result->number = *body++;

    result->sizeReason = hdrLen - 4;
    memcpy(result->reason, body, result->sizeReason);
    result->reason[result->sizeReason] = 0;
    return true;
  }
}

static bool
stunParseAtrUnknown(char *body, unsigned int hdrLen,
		    StunAtrUnknown * result)
{
  if (hdrLen >= sizeof(result)) {
    return false;
  } else {
    int i;
    if (hdrLen % 4 != 0)
      return false;
    result->numAttributes = hdrLen / 4;
    for (i = 0; i < result->numAttributes; i++) {
      memcpy(&(result->attrType[i]), body, sizeof(UInt16));
      body += 2;
      result->attrType[i] = ntohs(result->attrType[i]);
    }
    return true;
  }
}


static bool
stunParseAtrString(char *body, unsigned int hdrLen, StunAtrString * result)
{
  if (hdrLen >= STUN_MAX_STRING) {
    printf("String is too large\n");
    return false;
  } else {
    if (hdrLen % 4 != 0) {
      printf("Bad length string %d\n", hdrLen);
      return false;
    }

    result->sizeValue = hdrLen;
    memcpy(result->value, body, hdrLen);
    result->value[hdrLen] = 0;
    return true;
  }
}


static bool
stunParseAtrIntegrity(char *body, unsigned int hdrLen,
		      StunAtrIntegrity * result)
{
  if (hdrLen != 20) {
    printf("MessageIntegrity must be 20 bytes\n");
    return false;
  } else {
    memcpy(result->hash, body, hdrLen);
    return true;
  }
}


bool
stunParseMessage(char *buf, unsigned int bufLen, StunMessage * msg,
		 bool verbose)
{
  char *body;
  unsigned int size;

  if (verbose)
    printf("Received stun message: %d bytes\n", bufLen);
  memset(msg, 0, sizeof(StunMessage));

  if (sizeof(StunMsgHdr) > bufLen) {
    printf("Bad message\n");
    return false;
  }

  memcpy(&(msg->msgHdr), buf, sizeof(StunMsgHdr));
  msg->msgHdr.msgType = ntohs(msg->msgHdr.msgType);
  msg->msgHdr.msgLength = ntohs(msg->msgHdr.msgLength);

  if (msg->msgHdr.msgLength + sizeof(StunMsgHdr) != bufLen) {
    printf
	("Message header length doesn't match message size: %d - %d\n",
	 msg->msgHdr.msgLength, bufLen);
    return false;
  }

  body = buf + sizeof(StunMsgHdr);
  size = msg->msgHdr.msgLength;

  if (verbose)
    printf("bytes after header = %d\n", size);

  while (size > 0) {
    // !jf! should check that there are enough bytes left in the buffer
    int atrType;

    StunAtrHdr *attr = (StunAtrHdr *) (body);

    unsigned int attrLen = ntohs(attr->length);
    atrType = ntohs(attr->type);

    //if (verbose) printf("Found attribute type= %s, ltngth= %d", AttrNames[atrType], attrLen);
    if (attrLen + 4 > size) {
      printf
	  ("claims attribute is larger than size of message (attribute type=%d)\n",
	   atrType);
      return false;
    }

    body += 4;			// skip the length and type in attribute header
    size -= 4;

    switch (atrType) {
    case MappedAddress:
      msg->hasMappedAddress = true;
      if (stunParseAtrAddress(body, attrLen, &(msg->mappedAddress))
	  == false) {
	printf("problem parsing MappedAddress\n");
	return false;
      } else {
	if (verbose) {
	  UInt32 addr = ntohl(msg->mappedAddress.ipv4.addr);
	  printf("MappedAddress = %s:%d\n",
		 inet_ntoa(*(struct in_addr *) &addr),
		 msg->mappedAddress.ipv4.port);
	}
      }

      break;

    case ResponseAddress:
      msg->hasResponseAddress = true;
      if (stunParseAtrAddress(body, attrLen, &(msg->responseAddress))
	  == false) {
	printf("problem parsing ResponseAddress\n");
	return false;
      } else {
	if (verbose) {
	  UInt32 addr = ntohl(msg->responseAddress.ipv4.addr);
	  printf("ResponseAddress = %s:%d\n",
		 inet_ntoa(*(struct in_addr *) &addr),
		 msg->responseAddress.ipv4.port);
	}
      }
      break;

    case ChangeRequest:
      msg->hasChangeRequest = true;
      if (stunParseAtrChangeRequest
	  (body, attrLen, &(msg->changeRequest)) == false) {
	printf("problem parsing ChangeRequest\n");
	return false;
      } else {
	if (verbose)
	  printf("ChangeRequest = %d\n", msg->changeRequest.value);
      }
      break;

    case SourceAddress:
      msg->hasSourceAddress = true;
      if (stunParseAtrAddress(body, attrLen, &(msg->sourceAddress))
	  == false) {
	printf("problem parsing SourceAddress\n");
	return false;
      } else {
	if (verbose) {
	  UInt32 addr = ntohl(msg->sourceAddress.ipv4.addr);
	  printf("SourceAddress = %s:%d\n",
		 inet_ntoa(*(struct in_addr *) &addr),
		 msg->sourceAddress.ipv4.port);
	}
      }
      break;

    case ChangedAddress:
      msg->hasChangedAddress = true;
      if (stunParseAtrAddress(body, attrLen, &(msg->changedAddress))
	  == false) {
	printf("problem parsing ChangedAddress\n");
	return false;
      } else {
	if (verbose) {
	  UInt32 addr = ntohl(msg->changedAddress.ipv4.addr);
	  printf("ChangedAddress = %s:%d\n",
		 inet_ntoa(*(struct in_addr *) &addr),
		 msg->changedAddress.ipv4.port);
	}
      }
      break;

    case Username:
      msg->hasUsername = true;
      if (stunParseAtrString(body, attrLen, &(msg->username)) == false) {
	printf("problem parsing Username\n");
	return false;
      } else {
	if (verbose) {
	  printf("Username = %s\n", msg->username.value);
	  printf("Username len= %d\n", (int) msg->username.sizeValue);
	}
      }

      break;

    case Password:
      msg->hasPassword = true;
      if (stunParseAtrString(body, attrLen, &(msg->password)) == false) {
	printf("problem parsing Password\n");
	return false;
      } else {
	if (verbose) {
	  printf("Password = %s\n", msg->password.value);
	  printf("Password len= %d\n", (int) msg->password.sizeValue);
	}
      }
      break;

    case MessageIntegrity:
      msg->hasMessageIntegrity = true;
      if (stunParseAtrIntegrity
	  (body, attrLen, &(msg->messageIntegrity)) == false) {
	printf("problem parsing MessageIntegrity\n");
	return false;
      } else {
	if (verbose) printf("MessageIntegrity = %s\n", msg->messageIntegrity.hash);
      }

      // read the current HMAC
      // look up the password given the user of given the transaction id 
      // compute the HMAC on the buffer
      // decide if they match or not
      break;

    case ErrorCode:
      msg->hasErrorCode = true;
      if (stunParseAtrError(body, attrLen, &(msg->errorCode)) == false) {
	printf("problem parsing ErrorCode\n");
	return false;
      } else {
	if (verbose)
	  printf("ErrorCode = %d %d %s\n",
		 msg->errorCode.errorClass,
		 msg->errorCode.number, msg->errorCode.reason);
      }

      break;

    case UnknownAttribute:
      msg->hasUnknownAttributes = true;
      if (stunParseAtrUnknown
	  (body, attrLen, &(msg->unknownAttributes)) == false) {
	printf("problem parsing UnknownAttribute\n");
	return false;
      }
      break;

    case ReflectedFrom:
      msg->hasReflectedFrom = true;
      if (stunParseAtrAddress(body, attrLen, &(msg->reflectedFrom))
	  == false) {
	printf("problem parsing ReflectedFrom\n");
	return false;
      }
      break;

    default:
      if (verbose)
	printf("Unknown attribute: %d\n", atrType);
      if (atrType <= 0x7FFF)
	return false;
    }

    body += attrLen;
    size -= attrLen;
  }

  return true;
}


static char *encode16(char *buf, UInt16 data)
{
  UInt16 ndata = htons(data);
  memcpy(buf, (void *) (&ndata), sizeof(UInt16));
  return buf + sizeof(UInt16);
}

static char *encode32(char *buf, UInt32 data)
{
  UInt32 ndata = htonl(data);
  memcpy(buf, (void *) (&ndata), sizeof(UInt32));
  return buf + sizeof(UInt32);
}


static char *encode(char *buf, const char *data, unsigned int length)
{
  memcpy(buf, data, length);
  return buf + length;
}


static char *encodeAtrAddress4(char *ptr, UInt16 type,
			       const StunAtrAddress4 * atr)
{
  ptr = encode16(ptr, type);
  ptr = encode16(ptr, 8);
  *ptr++ = atr->pad;
  *ptr++ = IPv4Family;
  ptr = encode16(ptr, atr->ipv4.port);
  ptr = encode32(ptr, atr->ipv4.addr);

  return ptr;
}

static char *encodeAtrChangeRequest(char *ptr,
				    const StunAtrChangeRequest * atr)
{
  ptr = encode16(ptr, ChangeRequest);
  ptr = encode16(ptr, 4);
  ptr = encode32(ptr, atr->value);
  return ptr;
}

static char *encodeAtrError(char *ptr, const StunAtrError * atr)
{
  ptr = encode16(ptr, ErrorCode);
  ptr = encode16(ptr, 6 + atr->sizeReason);
  ptr = encode16(ptr, atr->pad);
  *ptr++ = atr->errorClass;
  *ptr++ = atr->number;
  ptr = encode(ptr, atr->reason, atr->sizeReason);
  return ptr;
}

static char *encodeAtrUnknown(char *ptr, const StunAtrUnknown * atr)
{
  int i;
  ptr = encode16(ptr, UnknownAttribute);
  ptr = encode16(ptr, 2 + 2 * atr->numAttributes);
  for (i = 0; i < atr->numAttributes; i++) {
    ptr = encode16(ptr, atr->attrType[i]);
  }
  return ptr;
}

static char *encodeAtrString(char *ptr, UInt16 type,
			     const StunAtrString * atr)
{
  assert(atr->sizeValue % 4 == 0);

  ptr = encode16(ptr, type);
  ptr = encode16(ptr, atr->sizeValue);
  ptr = encode(ptr, atr->value, atr->sizeValue);
  return ptr;
}

#ifdef TR111_STUN
static char *encodeAtrRequestBinding(char* ptr,UInt16 type,
					const StunAtrString * atr)
{
  ptr = encode16(ptr, type);
  ptr = encode16(ptr, atr->sizeValue);
  ptr = encode(ptr, atr->value, atr->sizeValue);
  return ptr;  
  
}

#endif


static char *encodeAtrIntegrity(char *ptr, const StunAtrIntegrity * atr)
{
  ptr = encode16(ptr, MessageIntegrity);
  ptr = encode16(ptr, 20);
  ptr = encode(ptr, atr->hash, sizeof(atr->hash));
  return ptr;
}


unsigned int
stunEncodeMessage(const StunMessage * msg,
		  char *buf,
		  unsigned int bufLen,
		  const StunAtrString * password, bool verbose)
{
  char *ptr, *lengthp;

  assert(bufLen >= sizeof(StunMsgHdr));
  ptr = buf;

  ptr = encode16(ptr, msg->msgHdr.msgType);
  lengthp = ptr;
  ptr = encode16(ptr, 0);
  ptr =
      encode(ptr, (const char *) (msg->msgHdr.id.octet),
	     sizeof(msg->msgHdr.id));

  if (verbose)
    printf("Encoding stun message: \n");
  if (msg->hasMappedAddress) {
    if (verbose) {
      UInt32 addr = ntohl(msg->mappedAddress.ipv4.addr);
      printf("Encoding MappedAddress: %s:%d\n",
	     inet_ntoa(*(struct in_addr *) &addr),
	     msg->mappedAddress.ipv4.port);
    }
    ptr = encodeAtrAddress4(ptr, MappedAddress, &(msg->mappedAddress));
  }
  if (msg->hasResponseAddress) {
    if (verbose) {
      UInt32 addr = ntohl(msg->responseAddress.ipv4.addr);
      printf("Encoding ResponseAddress: %s:%d\n",
	     inet_ntoa(*(struct in_addr *) &addr),
	     msg->responseAddress.ipv4.port);
    }
    ptr = encodeAtrAddress4(ptr, ResponseAddress, &(msg->responseAddress));
  }

#ifdef TR111_STUN
  if (request_bind == TRUE) {
      	  printf("\nAdding CONNECTION-REQUEST-BINDNIG\n");
	  ptr = encodeAtrRequestBinding(ptr,ConnectionRequestBinding,  &(msg->RequestBinding));
  }

  if( (request_bind == TRUE) && (msg->hasBindingChange == TRUE) )
  {
          printf("\n Adding BINDING-CHANGE\n");
	  ptr = encodeAtrRequestBinding(ptr, Binding_Change, &(msg->BindingChange));		   
  }
#endif

  if (msg->hasChangeRequest) {
    if (verbose)
      printf("Encoding ChangeRequest: %d\n", msg->changeRequest.value);
    ptr = encodeAtrChangeRequest(ptr, &(msg->changeRequest));
  }
  if (msg->hasSourceAddress) {
    if (verbose) {
      UInt32 addr = ntohl(msg->sourceAddress.ipv4.addr);
      printf("Encoding SourceAddress: %s:%d\n",
	     inet_ntoa(*(struct in_addr *) &addr),
	     msg->sourceAddress.ipv4.port);
    }
    ptr = encodeAtrAddress4(ptr, SourceAddress, &(msg->sourceAddress));
  }
  if (msg->hasChangedAddress) {
    if (verbose) {
      UInt32 addr = ntohl(msg->changedAddress.ipv4.addr);
      printf("Encoding ChangedAddress: %s:%d\n",
	     inet_ntoa(*(struct in_addr *) &addr),
	     msg->changedAddress.ipv4.port);
    }
    ptr = encodeAtrAddress4(ptr, ChangedAddress, &(msg->changedAddress));
  }
  if (msg->hasUsername) {
    if (verbose)
      printf("Encoding Username: %s\n", msg->username.value);
    ptr = encodeAtrString(ptr, Username, &(msg->username));
  }
  if (msg->hasPassword) {
    if (verbose)
      printf("Encoding Password: %s\n", msg->password.value);
    ptr = encodeAtrString(ptr, Password, &(msg->password));
  }
  if (msg->hasErrorCode) {
    if (verbose)
      printf("Encoding ErrorCode: class=%d number=%d reason=%s\n",
	     (int) msg->errorCode.errorClass,
	     (int) msg->errorCode.number, msg->errorCode.reason);

    ptr = encodeAtrError(ptr, &(msg->errorCode));
  }
  if (msg->hasUnknownAttributes) {
    if (verbose)
      printf("Encoding UnknownAttribute: ???\n");
    ptr = encodeAtrUnknown(ptr, &(msg->unknownAttributes));
  }
  if (msg->hasReflectedFrom) {
    if (verbose) {
      UInt32 addr = ntohl(msg->reflectedFrom.ipv4.addr);
      printf("Encoding ReflectedFrom: %s:%d\n",
	     inet_ntoa(*(struct in_addr *) &addr),
	     msg->reflectedFrom.ipv4.port);
    }
    ptr = encodeAtrAddress4(ptr, ReflectedFrom, &(msg->reflectedFrom));
  }

  if ((password) && (password->sizeValue > 0)) {
    StunAtrIntegrity integrity;

  // if msg integrity is to be added, write the correct length now+ 24 (for msg integrity length 
  encode16(lengthp, (unsigned short) (ptr - buf - sizeof(StunMsgHdr) + 24));

    if (verbose)
      printf("HMAC with password: %s\n", password->value);

    computeHmac(integrity.hash, buf, (int) (ptr - buf),
		password->value, password->sizeValue);
    ptr = encodeAtrIntegrity(ptr, &integrity);
  }
  if (verbose)
    printf("\n");

  encode16(lengthp, (unsigned short) (ptr - buf - sizeof(StunMsgHdr)));
  return (unsigned int) (ptr - buf);
}

int stunRand()
{
  // return 32 bits of random stuff
  static bool init = false;
  assert(sizeof(int) == 4);
  if (!init) {
    UInt64 tick = 0;
    int seed;

#if defined(WIN32)
    volatile unsigned int lowtick = 0, hightick = 0;
    __asm {
    rdtsc mov lowtick, eax mov hightick, edx} tick = hightick;
    tick <<= 32;
    tick |= lowtick;
#elif defined(__GNUC__) && ( defined(__i686__) || defined(__i386__) )
  asm("rdtsc":"=A"(tick));
#elif defined (__SUNPRO_CC) || defined( __sparc__ )
    tick = gethrtime();
#elif defined(__MACH__)
    int fd = open("/dev/random", O_RDONLY);
    read(fd, &tick, sizeof(tick));
    closesocket(fd);
#elif defined(__MIPS__)
    int fd = open("/dev/urandom", O_RDONLY);
    read(fd, &tick, sizeof(tick));
    closesocket(fd);
#else
//#     error Need some way to seed the random number generator 
#endif

    init = true;
    seed = (int) (tick);

#ifdef WIN32
    srand(seed);
#else
    srandom(seed);
#endif
  }
#ifdef WIN32
  assert(RAND_MAX == 0x7fff);
  int r1 = rand();
  int r2 = rand();

  int ret = (r1 << 16) + r2;

  return ret;
#else
  return random();
#endif
}


/// return a random number to use as a port 
static int randomPort(void)
{
  int min = 0x4000;
  int max = 0x7FFF;

  int ret = stunRand();
  ret = ret | min;
  ret = ret & max;

  return ret;
}

static void
computeHmac(char *hmac, const char *input, int length, const char *key,
	    int sizeKey)
{
  char *phmac;
  int count = 20;
  char * text = NULL;
  int size=0;
 /* we need to pad the input buffer to make it multiple of 64 bytes */

 size = ((length/64) + 1)*64 ;
 text = (char *)malloc(size);
 memset(text, 0x00, size);
 memcpy(text,input,length);

  sha1_hmac((unsigned char *)key, sizeKey, (unsigned char *)text, size, (unsigned char *)hmac);

  phmac = hmac;

  printf("\nHMAC : ");
  while(count >= 1){
	  printf("%02x",(unsigned char)(*phmac++));
	  count--;
  }
  printf("\n");

  free(text);

}


#if 0
static void toHex(const char *buffer, int bufferSize, char *output)
{
  static char hexmap[] = "0123456789abcdef";

  const char *p = buffer;
  char *r = output;
  int i;
  for (i = 0; i < bufferSize; i++) {
    unsigned char temp = *p++;

    int hi = (temp & 0xf0) >> 4;
    int low = (temp & 0xf);

    *r++ = hexmap[hi];
    *r++ = hexmap[low];
  }
  *r = 0;
}

void
stunCreateUserName(const StunAddress4 * source, StunAtrString * username)
{
  UInt64 ttime, lotime;
  char buffer[1024];
  char hmac[20];
  char key[] = "Jason";
  char hmacHex[41];
  int l, p, a, i;

  ttime = stunGetSystemTimeSecs();
  ttime -= (ttime % 20 * 60);
  //UInt64 hitime = ttime >> 32;
  lotime = ttime & 0xFFFFFFFF;

  sprintf(buffer,
	  "%08x:%08x:%08x:",
	  (UInt32) (source->addr),
	  (UInt32) (stunRand()), (UInt32) (lotime));
  assert(strlen(buffer) < 1024);

  assert(strlen(buffer) + 41 < STUN_MAX_STRING);

  computeHmac(hmac, buffer, strlen(buffer), key, strlen(key));
  toHex(hmac, 20, hmacHex);
  hmacHex[40] = 0;

  strcat(buffer, hmacHex);

  l = strlen(buffer);
  assert(l + 1 < STUN_MAX_STRING);
  username->sizeValue = l;
  memcpy(username->value, buffer, l);
  //username->value[l]=0;
  p = l % 4;
  if (p) {
    a = 4 - p;
    for (i = 0; i < a; i++)
      username->value[l + i] = 0;
    username->sizeValue = l + a;
  } else
    username->sizeValue = l;


  //if (verbose) printf("computed username= %d\n", username->value);
}

void
stunCreatePassword(const StunAtrString * username,
		   StunAtrString * password)
{
  char hmac[20];
  char key[] = "Fluffy";
  //char buffer[STUN_MAX_STRING];
  computeHmac(hmac, username->value, strlen(username->value), key,
	      strlen(key));
  toHex(hmac, 20, password->value);
  password->sizeValue = 40;
  password->value[40] = 0;

  //printf("password=%d\n", password->value);
}


UInt64 stunGetSystemTimeSecs()
{
  UInt64 ttime = 0;
#if defined(WIN32)
  SYSTEMTIME t;
  GetSystemTime(&t);
  ttime = (t.wHour * 60 + t.wMinute) * 60 + t.wSecond;
#else
  struct timeval now;
  gettimeofday(&now, NULL);
  //assert( now );
  ttime = now.tv_sec;
#endif
  return ttime;
}

#endif

// returns true if it scucceeded
bool
stunParseHostName(char *peerName, StunAddress4 * addr, UInt16 defaultPort)
{
  struct in_addr sin_addr;
  char host[512];
  char *port = NULL;
  int portNum = defaultPort;
  char *sep;
  // figure out the host part 
  struct hostent h_result, *h;
  int ret, h_err = 0;
  char h_buf[512];


  strncpy(host, peerName, 512);
  host[512 - 1] = '\0';

  // pull out the port part if present.
  sep = strchr(host, ':');
  if (sep == NULL) {
    portNum = defaultPort;
  } else {
    char *endPtr;

    *sep = '\0';
    port = sep + 1;
    // set port part

    endPtr = NULL;

    portNum = strtol(port, &endPtr, 10);

    if (endPtr != NULL) {
      if (*endPtr != '\0') {
	portNum = defaultPort;
      }
    }
  }

  if (portNum < 1024)
    return false;
  if (portNum >= 0xFFFF)
    return false;


#ifdef WIN32
  assert(strlen(host) >= 1);
  if (isdigit(host[0])) {
    // assume it is a ip address 
    unsigned long a = inet_addr(host);
    //printf("a=" << hex << a);

    ip = ntohl(a);
  } else {
    // assume it is a host name 
    h = gethostbyname(host);

    if (h == NULL) {
      int err = getErrno();
      printf("error was %d\n", err);
      assert(err != WSANOTINITIALISED);

      ip = ntohl(0x7F000001L);

      return false;
    } else {
      sin_addr = *(struct in_addr *) h->h_addr;
      ip = ntohl(sin_addr.s_addr);
    }
  }

#else
  ret = gethostbyname_r(host, &h_result, h_buf, sizeof(h_buf), &h, &h_err);
  if (ret || (h == NULL)) {
    printf("ret = %d, h_error was %d\n", ret, h_err);
    addr->addr = ntohl(0x7F000001L);
    return false;
  } else {
    sin_addr = *(struct in_addr *) h->h_addr;
    addr->addr = ntohl(sin_addr.s_addr);
  }
#endif

  addr->port = portNum;

  return true;
}


bool stunParseServerName(char *name, StunAddress4 * addr)
{
  bool ret;

  assert(name);

  // TODO - put in DNS SRV stuff.

  ret = stunParseHostName(name, addr, 3478);
  if (ret != true) {
    addr->port = 0xFFFF;
  }
  return ret;
}

#define STUN_MAX_MESSAGE_SIZE 2048
#if 0
//static void
void
stunCreateSharedSecretErrorResponse(StunMessage * response, int cl,
				    int number, const char *msg)
{
  response->msgHdr.msgType = SharedSecretErrorResponseMsg;
  response->hasErrorCode = true;
  response->errorCode.errorClass = cl;
  response->errorCode.number = number;
  strcpy(response->errorCode.reason, msg);
}

void stunCreateSharedSecretRequest(StunMessage * req)
{
  int i;

  req->msgHdr.msgType = SharedSecretRequestMsg;
  for (i = 0; i < 16; i = i + 4) {
    int r;
    assert(i + 3 < 16);
    r = stunRand();
    req->msgHdr.id.octet[i + 0] = r >> 0;
    req->msgHdr.id.octet[i + 1] = r >> 8;
    req->msgHdr.id.octet[i + 2] = r >> 16;
    req->msgHdr.id.octet[i + 3] = r >> 24;
  }
}
#endif

int stunFindLocalInterfaces(UInt32 * addresses, int maxRet)
{
#if defined(WIN32) || defined(__sparc__)
  return 0;
#else
  struct ifconf ifc;

  int s = socket(AF_INET, SOCK_DGRAM, 0);
  int len = 100 * sizeof(struct ifreq);

  char buf[len];
  int e = ioctl(s, SIOCGIFCONF, &ifc);
  char *ptr = buf;
  int tl = ifc.ifc_len;
  int count = 0;

  ifc.ifc_len = len;
  ifc.ifc_buf = buf;
  while ((tl > 0) && (count < maxRet)) {
    struct ifreq *ifr = (struct ifreq *) ptr;
    int si;
    struct ifreq ifr2;
    struct sockaddr a;
    struct sockaddr_in *addr;
    UInt32 ai;

    si = sizeof(ifr->ifr_name) + sizeof(struct sockaddr);
    tl -= si;
    ptr += si;
    //char* name = ifr->ifr_ifrn.ifrn_name;
    //printf("name = %s\n", name);

    ifr2 = *ifr;

    e = ioctl(s, SIOCGIFADDR, &ifr2);
    if (e == -1) {
      break;
    }
    //printf("ioctl addr e = %d\n", e);

    a = ifr2.ifr_addr;
    addr = (struct sockaddr_in *) &a;

    ai = ntohl(addr->sin_addr.s_addr);
    if ((int) ((ai >> 24) & 0xFF) != 127) {
      addresses[count++] = ai;
    }
#if 0
    printf("Detected interface %d.%d.%d.%d\n",
	   (int) ((ai >> 24) & 0xFF), (int) ((ai >> 16) & 0xFF),,
	   (int) ((ai >> 8) & 0xFF), (int) ((ai) & 0xFF));
#endif
  }

  closesocket(s);

  return count;
#endif
}


void
stunBuildReqSimple(StunMessage * msg,
		   const StunAtrString * username,
		   bool changePort, bool changeIp, unsigned int id)
{
  int i;

  assert(msg);
  memset(msg, 0, sizeof(StunMessage));

  msg->msgHdr.msgType = BindRequestMsg;

  for (i = 0; i < 16; i = i + 4) {
    int r;
    assert(i + 3 < 16);
    r = stunRand();
    msg->msgHdr.id.octet[i + 0] = r >> 0;
    msg->msgHdr.id.octet[i + 1] = r >> 8;
    msg->msgHdr.id.octet[i + 2] = r >> 16;
    msg->msgHdr.id.octet[i + 3] = r >> 24;
  }

  if (id != 0) {
    msg->msgHdr.id.octet[0] = id;
  }

  if(changeIp || changePort){
    msg->hasChangeRequest = true;
    msg->changeRequest.value = (changeIp ? ChangeIpFlag : 0) |
      		(changePort ? ChangePortFlag : 0);
  }else{
    msg->hasChangeRequest = false;
  }

  if (username->sizeValue > 0) {
    msg->hasUsername = true;
    memcpy(&(msg->username), username, sizeof(StunAtrString));
  }

#ifdef TR111_STUN
    msg->RequestBinding.sizeValue = 0x14;
    strcpy(msg->RequestBinding.value,"dslforum.org/TR-111 ");
#endif
}


static void
stunSendTest(Socket myFd, StunAddress4 * dest,
	     const StunAtrString * username,
	     const StunAtrString * password, int testNum, bool verbose)
{
  bool changePort = false;
  bool changeIP = false;
  bool discard = false;
  StunMessage req;
  char buf[STUN_MAX_MESSAGE_SIZE];
  int len = STUN_MAX_MESSAGE_SIZE;

  assert(dest->addr != 0);
  assert(dest->port != 0);
  switch (testNum) {
  case 1:
  case 10:
  case 11:
    break;
  case 2:
    changeIP = true;
    changePort = true;
    break;
  case 3:
    changePort = true;
    break;
  case 4:
    changeIP = true;
    break;
  case 5:
    discard = true;
    break;
  default:
    printf("Test %d is unknown\n", testNum);
    assert(0);
  }

  memset(&req, 0, sizeof(StunMessage));

  stunBuildReqSimple(&req, username, changePort, changeIP, testNum);

  len = stunEncodeMessage(&req, buf, len, password, verbose);

  if (verbose) {
    UInt32 addr = ntohl(dest->addr);
    printf("About to send msg of len %d to %s:%d\n", len,
	   inet_ntoa(*(struct in_addr *) &addr), dest->port);
  }

  sendMessage(myFd, buf, len, dest->addr, dest->port);

  // add some delay so the packets don't get sent too quickly 
#ifdef WIN32			// !cj! TODO - should fix this up in windows
  clock_t now = clock();
  assert(CLOCKS_PER_SEC == 1000);
  while (clock() <= now + 10) {
  };
#else
  usleep(10 * 1000); /* sleep 10ms */
#endif

}


void
stunGetUserNameAndPassword(const StunAddress4 * dest,
			   StunAtrString * username,
			   StunAtrString * password)
{
  // !cj! This is totally bogus - need to make TLS connection to dest and get a
  // username and password to use 
  //stunCreateUserName(dest, username);
  //stunCreatePassword(username, password);

  // This is written by ADMtek. username and password are got from stun server    // by shared secret messages over TLS connection.
  memcpy(username, &gotusername, sizeof(StunAtrString));
  memcpy(password, &gotpassword, sizeof(StunAtrString));
}


void
stunTest(StunAddress4 * dest, int testNum, bool verbose,
	 StunAddress4 * sAddr)
{
  int port;
  UInt32 interfaceIp = 0;
  Socket myFd;
  char msg[STUN_MAX_MESSAGE_SIZE];
  int msgLen = STUN_MAX_MESSAGE_SIZE;
  StunAddress4 from;
  StunMessage resp;
  bool ok;
  StunAtrString username, password;

  assert(dest->addr != 0);
  assert(dest->port != 0);

  port = randomPort();
  if (sAddr) {
    interfaceIp = sAddr->addr;
    if (sAddr->port != 0) {
      port = sAddr->port;
    }
  }
  myFd = openPort(port, interfaceIp);

  username.sizeValue = 0;
  password.sizeValue = 0;

#ifdef USE_TLS
  stunGetUserNameAndPassword(dest, &username, &password);
#endif

  stunSendTest(myFd, dest, &username, &password, testNum, verbose);

  getMessage(myFd, msg, &msgLen, &(from.addr), &(from.port));

  memset(&resp, 0, sizeof(StunMessage));

  if (verbose)
    printf("Got a response\n");
  ok = stunParseMessage(msg, msgLen, &resp, verbose);

  if (verbose) {
    int i;
    printf("\t ok= %d\n", ok);
    printf("\t id= ");
    for (i = 0; i < 16; i++)
      printf("%2x ", resp.msgHdr.id.octet[i]);
    printf("\n");
    printf("\t mappedAddr= %s:%d\n",
	   inet_ntoa(*(struct in_addr *) &resp.mappedAddress.ipv4.
		     addr), resp.mappedAddress.ipv4.port);
    printf("\t changedAddr= %s:%d\n\n",
	   inet_ntoa(*(struct in_addr *) &resp.changedAddress.ipv4.
		     addr), resp.changedAddress.ipv4.port);
  }

  if (sAddr) {
    sAddr->port = resp.mappedAddress.ipv4.port;
    sAddr->addr = resp.mappedAddress.ipv4.addr;
  }
}

int
stunTxStateTransit(Socket Fd, StunAddress4 *dest, StunAddress4 *testI2dest,
	     	   const StunAtrString *username,
	     	   const StunAtrString *password, int *count, bool verbose)
{
  switch(StunState)
  {
  case START:
    *count = 0;
    printf("Send TestI Req: No.%d\n", *count);
    stunSendTest(Fd, dest, username, password, 1, verbose);
    StunState = TESTI_REQ_OUT;
    (*count)++;
    break;
  case TESTI_REQ_OUT:
    if(*count >= MaxRetran){
      printf("No TestI response!\n");
      StunState = END;
      return StunTypeBlocked;
    }else{
      printf("Send TestI Req: No.%d\n", *count);
      stunSendTest(Fd, dest, username, password, 1, verbose);
      (*count)++;
    }
    break;
  case TESTI_RSP_IN_NNAT:
    *count = 0;
    printf("Send TestII Req: No.%d\n", *count);
    stunSendTest(Fd, dest, username, password, 2, verbose);
    StunState = TESTII_REQ_OUT_NNAT;
    (*count)++;
    break;
  case TESTII_REQ_OUT_NNAT:
    if(*count >= MaxRetran){
      printf("No TestII response!\n");
      StunState = END;
      return StunTypeSymFirewall;
    }else{
      printf("Send TestII Req: No.%d\n", *count);
      stunSendTest(Fd, dest, username, password, 2, verbose);
      (*count)++;
    }
    break;
  case TESTI_RSP_IN_NAT:
    *count = 0;
    printf("Send TestII Req: No.%d\n", *count);
    stunSendTest(Fd, dest, username, password, 2, verbose);
    StunState = TESTII_REQ_OUT_NAT;
    (*count)++;
    break;
  case TESTII_REQ_OUT_NAT:
    if(*count >= MaxRetran){
      (*count) = 0;
      printf("No TestII response!\n");
      printf("Send TestI2 Req: No.%d\n", *count);
      stunSendTest(Fd, testI2dest, username, password, 10, verbose);
      StunState = TESTI2_REQ_OUT;
      (*count)++;
    }else{
      printf("Send TestII Req: No.%d\n", *count);
      stunSendTest(Fd, dest, username, password, 2, verbose);
      (*count)++;
    }
    break;
  case TESTI2_REQ_OUT:
    if(*count >= MaxRetran){
      *count = 0;
      printf("No TestI2 response!\n");
      printf("Still Send TestIII Req: No.%d\n", *count);
      stunSendTest(Fd, dest, username, password, 3, verbose);
      StunState = TESTIII_REQ_OUT;
      (*count)++;
    }else{
      printf("Send TestI2 Req: No.%d\n", *count);
      stunSendTest(Fd, testI2dest, username, password, 10, verbose);
      (*count)++;
    }
    break;
  case TESTI2_RSP_IN:
    *count = 0;
    printf("Send TestIII Req: No.%d\n", *count);
    stunSendTest(Fd, dest, username, password, 3, verbose);
    StunState = TESTIII_REQ_OUT;
    (*count)++;
    break;
  case TESTIII_REQ_OUT:
    if(*count >= MaxRetran){
      printf("No TestIII response!\n");
      StunState = END;
      return StunTypePortRestrictedNat;
    }else{
      printf("Send TestIII Req: No.%d\n", *count);
      stunSendTest(Fd, dest, username, password, 3, verbose);
      (*count)++;
    }
    break;
  }
  return -1;
}

int
stunRxStateTransit(StunMessage *resp, StunAddress4 *testIchangedAddr,
		   StunAddress4 *testImappedAddr, StunAddress4 *testI2dest, 
		   StunAddress4 *testI2mappedAddr, StunAddress4 *mAddr, 
		   int *respTest)
{
  Socket s;
  int tmpaddr;

  switch (resp->msgHdr.id.octet[0]) {
  case 1: /* TestI response */
    {
      if (StunState == TESTI_REQ_OUT) {
        testIchangedAddr->addr = resp->changedAddress.ipv4.addr;
        testIchangedAddr->port = resp->changedAddress.ipv4.port;
	testImappedAddr->addr = resp->mappedAddress.ipv4.addr;
	testImappedAddr->port = resp->mappedAddress.ipv4.port;
	testI2dest->addr = resp->changedAddress.ipv4.addr;
  	tmpaddr = ntohl(testI2dest->addr);	
	printf("testI2dest address: %s\n", inet_ntoa(*(struct in_addr *)&tmpaddr));
	mAddr->port = testImappedAddr->port;
	mAddr->addr = testImappedAddr->addr;
        // see if we can bind to this address 
        s = openPort(0 /*use ephemeral */ , testImappedAddr->addr);
        if (s != INVALID_SOCKET) {
          closesocket(s);
          printf("No NAT!\n");
	  StunState = TESTI_RSP_IN_NNAT;
        } else {
          printf("Behind NAT!\n");
	  StunState = TESTI_RSP_IN_NAT;
        }
        *respTest = 1;
      }
    }
    break;
  case 2: /* TestII response */
    {
      if(StunState == TESTII_REQ_OUT_NNAT){
        StunState = TESTII_RSP_IN_NNAT;
        *respTest = 2;
        return StunTypeOpen;
      }else if(StunState == TESTII_REQ_OUT_NAT){
        StunState = TESTII_RSP_IN_NAT;
        *respTest = 2;
        return StunTypeConeNat;
      }
    }
    break;
  case 3: /* TestIII response */
    {
      if(StunState == TESTIII_REQ_OUT){
/**********************************************************/
/* AMTEST */
/**********************************************************/
	testIchangedAddr->addr = resp->changedAddress.ipv4.addr;
        testIchangedAddr->port = resp->changedAddress.ipv4.port;
	testImappedAddr->addr = resp->mappedAddress.ipv4.addr;
	testImappedAddr->port = resp->mappedAddress.ipv4.port;
  	tmpaddr = ntohl(testI2dest->addr);	
	printf("testIIIdest address: %s\n", inet_ntoa(*(struct in_addr *)&tmpaddr));
	mAddr->port = testImappedAddr->port;
	mAddr->addr = testImappedAddr->addr;
/**********************************************************/
	StunState = TESTIII_RSP_IN;
        *respTest = 3;
	return StunTypeRestrictedNat;
      }
    }
    break;
  case 10:
    {
      if (StunState == TESTI2_REQ_OUT) {
        testI2mappedAddr->addr = resp->mappedAddress.ipv4.addr;
        testI2mappedAddr->port = resp->mappedAddress.ipv4.port;
        *respTest = 10;
        if ((testI2mappedAddr->addr == testImappedAddr->addr)
	      && (testI2mappedAddr->port == testImappedAddr->port)) {
	  StunState = TESTI2_RSP_IN;
        }else{
	  return StunTypeSymNat;
	}
      }
    }
    break;
  case 11:
    {
      /*if (hairpin) {
        *hairpin = true;
      }
      respTestHairpin = true;*/
    }
    break;
  }
  return -1;
}

NatType stunNatType(StunAddress4 * dest, bool verbose, bool * preservePort,	// if set, is return for if NAT preservers ports or not
		    bool * hairpin,	// if set, is the return for if NAT will hairpin packets
		    bool quickmode,
		    int port,	// port to use for the test, 0 to choose random port
		    StunAddress4 *sAddr,	// NIC to use 
		    StunAddress4 *mAddr		// Mapped address&port
    )
{
  UInt32 interfaceIp = 0;
  int respTest = 0;
  bool respTestI = false;
  bool respTestII = false;
  bool respTestIII = false;
  bool respTestI2 = false;
  StunAddress4 testIchangedAddr;
  StunAddress4 testImappedAddr;
  StunAddress4 testI2mappedAddr;
  StunAddress4 testI2dest;
  //bool respTestHairpin = false;
  Socket myFd, myFd1;
  StunAtrString username, password;
  int count = 0;
  int ret, interval, wt;

  assert(dest->addr != 0);
  assert(dest->port != 0);

  if (hairpin) {
    *hairpin = false;
  }

  if (port == 0) {
    port = randomPort();
    sAddr->port = port;
  }
  if (sAddr->addr) {
    interfaceIp = sAddr->addr;
  }
  myFd1 = openPort(port, interfaceIp);
  if (myFd1 == INVALID_SOCKET) {
    printf("Some problem opening port/interface to send on\n");
    return StunTypeUnknown;
  }

  assert(myFd1 != INVALID_SOCKET);

  memcpy(&testI2dest, dest, sizeof(StunAddress4));
  memset(&testImappedAddr, 0, sizeof(testImappedAddr));

  username.sizeValue = 0;
  password.sizeValue = 0;
  StunState = START;
  count = 0;
  interval = 0; wt = 0;

//#ifdef USE_TLS
  stunGetUserNameAndPassword(dest, &username, &password);
//#endif

  if (quickmode){
    MaxRetran = 3; /* for Quick */
  }else{
    MaxRetran = 9; /* According to RFC */
  }

  while (1) {
    struct timeval tv;
#ifdef WIN32
    unsigned int fdSetSize;
#else
    int fdSetSize;
#endif
    fd_set fdSet;
    int err, e;

    FD_ZERO(&fdSet);
    fdSetSize = 0;
    FD_SET(myFd1, &fdSet);
    fdSetSize = (myFd1 + 1 > fdSetSize) ? myFd1 + 1 : fdSetSize;
    tv.tv_sec = 0;
    if (quickmode){
      if (count == 0)
        tv.tv_usec = 0;
      else if(count == 1){
        tv.tv_usec = 100 * 1000; /* 100 ms */
      }else{
        tv.tv_usec = 300 * 1000; /* 300 ms */
      }
    }else{
      if (count == 0)
        tv.tv_usec = 0; /* 0 ms */
      else if(count == 1){
        interval = 100;      
        wt = 100;
        tv.tv_usec = wt * 1000; /* 100 ms */
      }else{
        interval = interval*2;
        if(interval >= 1600) interval = 1600; 
        wt = wt + interval; /* 300, 700, 1500,..., 7900 ms */
        tv.tv_usec = wt * 1000;
      }
    }

    err = select(fdSetSize, &fdSet, NULL, NULL, &tv);
    e = getErrno();
    if (err == SOCKET_ERROR) {
      // error occured
      printf("Error %d %s in select", e, strerror(e));
    } else if (err == 0) {
      // timeout occured 
      ret = stunTxStateTransit(myFd1, dest, &testI2dest, &username, 
				&password, &count, verbose);
      if(ret >= 0) break;
    } else {
      // message coming in
      assert(err > 0);
      myFd = myFd1;
      if (FD_ISSET(myFd, &fdSet)) {
	char msg[udpMaxMessageLength];
	int msgLen = udpMaxMessageLength;
	StunMessage resp;
	StunAddress4 from;

	getMessage(myFd, msg, &msgLen, &(from.addr), &(from.port));
	memset(&resp, 0, sizeof(StunMessage));
	stunParseMessage(msg, msgLen, &resp, verbose);
	if (verbose) {
	  printf("Received message of type %d id= %d\n",
		    resp.msgHdr.msgType, (int) (resp.msgHdr.id.octet[0]));
	}
	ret = stunRxStateTransit(&resp, &testIchangedAddr, &testImappedAddr,
				     &testI2dest, &testI2mappedAddr, mAddr, 
				     &respTest);
	switch(respTest){
	case 1: 
          respTestI = true; 
	  if (preservePort) {
	    *preservePort = (testImappedAddr.port == port);
	  }
          break;
	case 2: respTestII = true; break;
	case 3: respTestIII = true; break;
	case 10: respTestI2 = true; break;
	}
        if(ret >= 0) break;
      }
    }
  }

  if (verbose) {
    printf("test I = %d\n", respTestI);
    printf("test II = %d\n", respTestII);
    printf("test III = %d\n", respTestIII);
    printf("test I(2) = %d\n", respTestI2);
  }
  closesocket(myFd1);
 
  return ret;
}

int
stunOpenSocket(StunAddress4 * dest, StunAddress4 * sAddr, int port,
	       bool verbose)
{
  UInt32 interfaceIp = 0;
  Socket myFd;
  char msg[udpMaxMessageLength];
  int msgLen;
  StunAtrString username;
  StunAtrString password;
  StunAddress4 from;
  StunMessage resp;
  bool ok;
  StunAddress4 mappedAddr, changedAddr;

  assert(dest->addr != 0);
  assert(dest->port != 0);

  if (port == 0) {
    port = randomPort();
  }
  if (sAddr) {
    interfaceIp = sAddr->addr;
  }
  myFd = openPort(port, interfaceIp);

  msgLen = sizeof(msg) / sizeof(*msg);

  username.sizeValue = 0;
  password.sizeValue = 0;

#ifdef USE_TLS
  stunGetUserNameAndPassword(dest, &username, &password);
#endif

  stunSendTest(myFd, dest, &username, &password, 1, 0);

  getMessage(myFd, msg, &msgLen, &(from.addr), &(from.port));

  memset(&resp, 0, sizeof(StunMessage));

  ok = stunParseMessage(msg, msgLen, &resp, verbose);
  if (!ok) {
    return -1;
  }

  memcpy(&mappedAddr, &(resp.mappedAddress.ipv4), sizeof(StunAddress4));
  memcpy(&changedAddr, &(resp.changedAddress.ipv4), sizeof(StunAddress4));

  //printf("--- stunOpenSocket --- \n");
  //printf("\treq  id= %d\n", req.id);
  //printf("\tresp id= %d\n", id);
  //printf("\tmappedAddr= %s\n", inet_ntoa(*(struct in_addr*)&mappedAddr.addr));

  memcpy(sAddr, &mappedAddr, sizeof(StunAddress4));

  return myFd;
}


bool
stunOpenSocketPair(StunAddress4 * dest, StunAddress4 * sAddr,
		   int *fd1, int *fd2, int port, bool verbose)
{
  const int NUM = 3;
  char msg[udpMaxMessageLength];
  int msgLen;
  StunAddress4 from;
  int fd[NUM];
  int i;
  UInt32 interfaceIp = 0;
  StunAtrString username, password;

  StunAddress4 mappedAddr[NUM];
  assert(dest->addr != 0);
  assert(dest->port != 0);

  if (port == 0) {
    port = randomPort();
  }

  *fd1 = -1;
  *fd2 = -1;

  msgLen = sizeof(msg) / sizeof(*msg);

  if (sAddr)
    interfaceIp = sAddr->addr;
  for (i = 0; i < NUM; i++) {
    fd[i] = openPort((port == 0) ? 0 : (port + i), interfaceIp);
    if (fd[i] < 0) {
      while (i > 0) {
	closesocket(fd[--i]);
      }
      return false;
    }
  }

  username.sizeValue = 0;
  password.sizeValue = 0;

#ifdef USE_TLS
  stunGetUserNameAndPassword(dest, &username, &password);
#endif

  for (i = 0; i < NUM; i++) {
    stunSendTest(fd[i], dest, &username, &password, 1, 0 /*false */ );
  }

  for (i = 0; i < NUM; i++) {
    StunMessage resp;
    bool ok;
    StunAddress4 changedAddr;

    msgLen = sizeof(msg) / sizeof(*msg);
    getMessage(fd[i], msg, &msgLen, &(from.addr), &(from.port));

    memset(&resp, 0, sizeof(StunMessage));

    ok = stunParseMessage(msg, msgLen, &resp, verbose);
    if (!ok) {
      return false;
    }

    mappedAddr[i] = resp.mappedAddress.ipv4;
    memcpy(&changedAddr, &(resp.changedAddress.ipv4),
	   sizeof(StunAddress4));
  }

  if (verbose) {
    printf("--- stunOpenSocketPair --- \n");
    for (i = 0; i < NUM; i++) {
      UInt32 addr = ntohl(mappedAddr[i].addr);
      printf("\tmappedAddr=%s:%d\n",
	     inet_ntoa(*(struct in_addr *) &addr), mappedAddr[i].port);
    }
  }

  if (mappedAddr[0].port % 2 == 0) {
    if (mappedAddr[0].port + 1 == mappedAddr[1].port) {
      *sAddr = mappedAddr[0];
      *fd1 = fd[0];
      *fd2 = fd[1];
      closesocket(fd[2]);
      return true;
    }
  } else {
    if ((mappedAddr[1].port % 2 == 0)
	&& (mappedAddr[1].port + 1 == mappedAddr[2].port)) {
      *sAddr = mappedAddr[1];
      *fd1 = fd[1];
      *fd2 = fd[2];
      closesocket(fd[0]);
      return true;
    }
  }

  for (i = 0; i < NUM; i++) {
    closesocket(fd[i]);
  }

  return false;
}

/* ====================================================================
 * Revision History:
 *
 * $Log: stun.c,v $
 * Revision 1.5  2004/05/17 12:52:18  erict
 * 1. Add USESSL pre-compile option
 * 2. Add stunSetUserPass() and stunGetUserPass()
 * 3. Add using hmac sha1 without OpenSSL
 *
 * ====================================================================
 */

