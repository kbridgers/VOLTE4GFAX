#!/bin/bash
TOPDIR=`pwd`/../../../../
. ${TOPDIR}tools/build_tools/Path.sh
APPS_NAME="STUN tools"

echo "----------------------------------------------------------------------"
echo "------------------  build STUN library and client  -------------------"
echo "----------------------------------------------------------------------"

parse_args $@

if [ "$1" = "config_only" ] ;then
	exit 0
fi

if [ $BUILD_CLEAN -eq 1 ]; then
	make  clean
	[ ! $BUILD_CONFIGURE -eq 1 ] && exit 0
fi

make AR=${IFX_AR} AS=${IFX_AS} LD=${IFX_LD} NM=${IFX_NM} CC=${IFX_CC} BUILDCC=${IFX_HOSTCC} GCC=${IFX_CC} CXX=${IFX_CXX} CPP=${IFX_CPP} RANLIB=${IFX_RANLIB} STRIP=${IFX_STRIP} IFX_CFLAGS="${IFX_CFLAGS}" IFX_LDFLAGS="${IFX_LDFLAGS}"
ifx_error_check $? 

${IFX_STRIP} stunclient
${IFX_STRIP} libifxstun.so
install -d ${BUILD_ROOTFS_DIR}usr/lib/
install -d ${BUILD_ROOTFS_DIR}usr/bin/
cp -f stunclient ${BUILD_ROOTFS_DIR}usr/bin/
cp -f libifxstun.so ${BUILD_ROOTFS_DIR}usr/lib/
ifx_error_check $? 

