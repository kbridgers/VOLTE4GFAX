
/* ============================================================================
 * Copyright (C) 2005 -Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 *============================================================================
 *
 * This document contains proprietary information belonging to Infineon 
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 * 
 * ============================================================================
 */

/* ===========================================================================
 *
 * File Name:   adsl_menu_func.c
 * Author :     Nirav Salot
 * Date: 		April, 2005
 *
 * ===========================================================================
 *
 * Project: Amazon
 *
 * ===========================================================================
 * Contents: This file implements ADSL menu related specific functions.
 *  
 * ===========================================================================
 * References: 
 *
 */
#include <stdio.h>
#include <string.h>
#include "common.h"

int lan_dhcp_server_set_post(struct cmd_entry *cmd, char *poststr)
{
	char *strstartip = NULL;
	char *strendip = NULL;
	int StartOctets[4] = { 0 }, EndOctets[4] = {
	0};
	char *next, *tptr = NULL;
	unsigned int i = 0;
	char str[16] = { 0 };

	strstartip = get_field_entry(cmd, "DhcpsStartIP")->cur_value;
	strendip = get_field_entry(cmd, "DhcpsEndIP")->cur_value;
	next = strtok_r(strstartip, ".", &tptr);
	while (i < 4) {
		if (next) {
			//Vicky_Note: We need to return(some value) if we are not able to extract ip. Need to figure out what to return
			StartOctets[i] = atoi(next);
		}
		next = strtok_r(NULL, ".", &tptr);
		i++;
	}

	i = 0;
	next = strtok_r(strendip, ".", &tptr);
	while (i < 4) {
		if (next)
			EndOctets[i] = atoi(next);

		next = strtok_r(NULL, ".", &tptr);
		i++;
	}

	str[0] = '\0';
	snprintf(str, sizeof(str), "%d", StartOctets[0]);
	strcat(poststr, "DhcpsStartIP1=");
	strcat(poststr, str);
	strcat(poststr, "&");
	str[0] = '\0';
	snprintf(str, sizeof(str), "%d", StartOctets[1]);
	strcat(poststr, "DhcpsStartIP2=");
	strcat(poststr, str);
	strcat(poststr, "&");
	str[0] = '\0';
	snprintf(str, sizeof(str), "%d", StartOctets[2]);
	strcat(poststr, "DhcpsStartIP3=");
	strcat(poststr, str);
	strcat(poststr, "&");
	str[0] = '\0';
	snprintf(str, sizeof(str), "%d", StartOctets[3]);
	strcat(poststr, "DhcpsStartIP4=");
	strcat(poststr, str);
	strcat(poststr, "&");

	str[0] = '\0';
	snprintf(str, sizeof(str), "%d", EndOctets[0]);
	strcat(poststr, "DhcpsEndIP1=");
	strcat(poststr, str);
	strcat(poststr, "&");
	str[0] = '\0';
	snprintf(str, sizeof(str), "%d", EndOctets[1]);
	strcat(poststr, "DhcpsEndIP2=");
	strcat(poststr, str);
	strcat(poststr, "&");
	str[0] = '\0';
	snprintf(str, sizeof(str), "%d", EndOctets[2]);
	strcat(poststr, "DhcpsEndIP3=");
	strcat(poststr, str);
	strcat(poststr, "&");
	str[0] = '\0';
	snprintf(str, sizeof(str), "%d", EndOctets[3]);
	strcat(poststr, "DhcpsEndIP4=");
	strcat(poststr, str);
	return 0;
}

int dhcp_ipaddrs_validate(struct cmd_entry *cmd, char *poststr)
{
	char strip[20], strstartip[20], strendip[20];
	char *next, *tptr = NULL;
	int StartOctets[4] = { 0 }, EndOctets[4] = {
	0};
	char lanipm[250] =
	    "IP address you entered is invalid.\n Either you have not entered all of the numbers \n or some of the numbers you entered are invalid. \n The number in each entry box should be between 0 - 255";
	unsigned int i = 0, idx = 0, count = 0, flag = 0;
	IP_MASK_TYPE *ip_array = NULL;

	sprintf(strstartip, "%s",
		get_field_entry(cmd, "DhcpsStartIP")->cur_value);
	sprintf(strendip, "%s", get_field_entry(cmd, "DhcpsEndIP")->cur_value);
	next = strtok_r(strstartip, ".", &tptr);
	while (i < 4) {
		if (next) {
			StartOctets[i] = atoi(next);
		}
		next = strtok_r(NULL, ".", &tptr);
		i++;
	}

	i = 0;
	next = strtok_r(strendip, ".", &tptr);
	while (i < 4) {
		if (next)
			EndOctets[i] = atoi(next);
		next = strtok_r(NULL, ".", &tptr);
		i++;
	}
	if ((StartOctets[0] != EndOctets[0]) ||
	    (StartOctets[1] != EndOctets[1]) ||
	    (StartOctets[2] != EndOctets[2])) {
		sprintf(poststr,
			"Error : First three octets of start IP and end IP should be same \n");
		return -1;
	}

	if ((StartOctets[0] == 224) && (StartOctets[1] >= 168)) {
		sprintf(poststr, "Error : %s \n", lanipm);
		return -1;
	}
	if ((StartOctets[0] == 254) && (StartOctets[1] <= 168)) {
		sprintf(poststr, "Error : %s \n", lanipm);
		return -1;
	}
	if ((StartOctets[0] > 224) && (StartOctets[1] < 254)) {
		sprintf(poststr, "Error : %s \n", lanipm);
		return -1;
	}

	if ((EndOctets[0] == 224) && (EndOctets[1] >= 168)) {
		sprintf(poststr, "Error : %s \n", lanipm);
		return -1;
	}
	if ((EndOctets[0] == 254) && (EndOctets[1] <= 168)) {
		sprintf(poststr, "Error : %s \n", lanipm);
		return -1;
	}
	if ((EndOctets[0] > 224) && (EndOctets[1] < 254)) {
		sprintf(poststr, "Error : %s \n", lanipm);
		return -1;
	}

	if (StartOctets[3] > EndOctets[3]) {
		sprintf(poststr,
			"Error : The End IP Should Be Greater than Start IP \n");
		return -1;
	}

	if (ifx_get_lan_ip_mask
	    ("br0", (int32 *) & count, &ip_array,
	     IFX_F_DEFAULT) != IFX_SUCCESS) {
	} else {
		for (idx = 0; idx < count; idx++) {
			sprintf(strip, "%s",
				inet_ntoa((ip_array + idx)->ip_mask.ip));
			i = 0;
			next = strtok_r(strip, ".", &tptr);
			while (i < 3)	//check whether first three octets of lan ip and dhcp ips are same
			{
				if (next) {
					if (StartOctets[i] != atoi(next)) {
						flag = 1;
						break;
					}
				}
				next = strtok_r(NULL, ".", &tptr);
				i++;
			}
			if (flag == 0) {	//first three octets of lan ip and dhcp ips are same
				if (next == NULL) {
					sprintf(poststr, "%s",
						"Error : Unable to read IP Address \n");
					return -1;
				}
				if ((atoi(next) >= StartOctets[3])
				    && (atoi(next) <= EndOctets[3])) {
					sprintf(poststr, "%s",
						"Error : LAN IP Address cannot be in DHCP Server Address Pool \n");
					return -1;
				}
			}
		}
		if (ip_array) {
			free(ip_array);
			ip_array = NULL;
		}
	}

	if (ip_array) {
		free(ip_array);
		ip_array = NULL;
	}
	return 0;
}

int lan_setting_config_validate(struct cmd_entry *cmd, char *poststr)
{
	char strip[20], strstartip[20], strendip[20];
	char *next, *tptr = NULL;
	int StartOctets[4] = { 0 }, EndOctets[4] = {
	0};
	unsigned int i = 0, flag = 0;
	DHCP_SERVER_INFO dhcp;

	sprintf(strip, "%s", get_field_entry(cmd, "sysip")->cur_value);
	if (ifx_get_dhcp_server_mode(IFX_F_DEFAULT) == IFX_DHCP_SERVER_MODE) {
		if (ifx_get_lan_dhcp_server_config(&dhcp, IFX_F_DEFAULT) !=
		    IFX_SUCCESS) {
			return -1;
		} else {
			sprintf(strstartip, "%s", inet_ntoa(dhcp.start_ip));
			sprintf(strendip, "%s", inet_ntoa(dhcp.end_ip));
			next = strtok_r(strstartip, ".", &tptr);
			while (i < 4) {
				if (next) {
					StartOctets[i] = atoi(next);
				}
				next = strtok_r(NULL, ".", &tptr);
				i++;
			}

			i = 0;
			next = strtok_r(strendip, ".", &tptr);
			while (i < 4) {
				if (next) {
					EndOctets[i] = atoi(next);
				}
				next = strtok_r(NULL, ".", &tptr);
				i++;
			}

			i = 0;
			next = strtok_r(strip, ".", &tptr);
			while (i < 3)	//check whether first three octets of lan ip and dhcp ips are same
			{
				if (next) {
					if (StartOctets[i] != atoi(next)) {
						flag = 1;
						break;
					}
				}
				next = strtok_r(NULL, ".", &tptr);
				i++;
			}
			if (flag == 0) {	//first three octets of lan ip and dhcp ips are same
				if (next) {
					if ((atoi(next) >= StartOctets[3])
					    && (atoi(next) <= EndOctets[3])) {
						sprintf(poststr, "%s",
							"Error : LAN IP Address cannot be in DHCP Server Address Pool \n");
						return -1;
					}
				}
			}

		}
	}

	return 0;
}
