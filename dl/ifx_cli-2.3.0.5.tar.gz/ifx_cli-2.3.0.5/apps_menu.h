#ifndef __APPS_MENU_H
#define	__APPS_MENU_H

#include "apps_menu_func.h"

struct value_set server_acl_status_values[] = {
	{.display_value = "enable",.submit_value = "1"},
	{.display_value = "disable",.submit_value = "0"}
};

struct cmd_field server_acl_status_cmd_field[] = {
	{
	 .field_name = "SERVERS_ACL_ENABLE",
	 .field_help = "This field represent the status of acl",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "status",
	 .field_gui_name = "Status",
	 .values = server_acl_status_values,
	 .tot_values =
	 sizeof(server_acl_status_values) / sizeof(struct value_set)
	 }
};

struct cmd_entry server_acl_status_cmd = {
	.fields = server_acl_status_cmd_field,
	.tot_fields =
	    sizeof(server_acl_status_cmd_field) / sizeof(struct cmd_field),
	.help = "This command configures acl settings",
	.post_url = "/goform/ifx_set_servers_acl",
	.get_url = "servers_acl.cli"
};

struct value_set server_acl_config_cmd_index_values[] = {
	{"Rule1", "1"},
	{"Rule2", "2"},
	{"Rule3", "3"},
	{"Rule4", "4"},
	{"Rule5", "5"},
	{"Rule6", "6"},
	{"Rule7", "7"},
	{"Rule8", "8"},
	{"Rule9", "9"},
	{"Rule10", "10"},
	{"Rule11", "11"},
	{"Rule12", "12"},
	{"Rule13", "13"},
	{"Rule14", "14"},
	{"Rule15", "15"},
	{"Rule16", "16"}
};

struct cmd_field server_acl_config_set_cmd_fields[] = {
	{
	 .field_name = "index",
	 .field_help = "This field represent the index of ip address",
	 .data_type = INT,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "index",
	 .field_gui_name = "Index",
	 .tot_values =
	 sizeof(server_acl_config_cmd_index_values) / sizeof(struct value_set),
	 .values = server_acl_config_cmd_index_values},
	{
	 .field_name = "SERVERS_ACL",
	 .field_help = "This field represent the ip address of acl server",
	 .data_type = IPADDR,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "ipaddr",
	 .field_gui_name = "IP address"}
};

struct cmd_entry server_acl_config_set_cmd = {
	.fields = server_acl_config_set_cmd_fields,
	.tot_fields =
	    sizeof(server_acl_config_set_cmd_fields) / sizeof(struct cmd_field),
	.help = "configures ip address for acl",
	.post_url = "/goform/ifx_set_servers_acl",
	.custom_processing_post = server_acl_config_post_flag,
	.get_url = "servers_acl.cli"
};

struct menu_entry server_acl_config_entries[] = {
	{
	 .entry_help = "This is acl config show entry",
	 .cli_name = "Show",.cli_url = "servers_acl_config.cli"},
	{
	 .entry_help = "This is acl config set entry",
	 .cli_name = "Set",.cmd = &server_acl_config_set_cmd}
};

struct menu_page server_acl_config_page = {
	.entries = server_acl_config_entries,
	.tot_entries =
	    sizeof(server_acl_config_entries) / sizeof(struct menu_entry),
	.page_help = "This is acl config entry page",
	.cli_title = "Config"
};

struct menu_entry server_acl_status_entries[] = {
	{
	 .entry_help = "This is acl status show entry",
	 .cli_name = "Show",.cli_url = "servers_acl_status.cli"},
	{
	 .entry_help = "This is acl config set entry",
	 .cli_name = "Set",.cmd = &server_acl_status_cmd}
};

struct menu_page server_acl_status_page = {
	.entries = server_acl_status_entries,
	.tot_entries =
	    sizeof(server_acl_status_entries) / sizeof(struct menu_entry),
	.page_help = "This is acl status entry page",
	.cli_title = "status"
};

struct menu_entry server_acl_page_entries[] = {
#if 0
	{
	 .entry_help = "This is acl show entry",
	 .cli_name = "Show",.cli_url = "servers_acl.cli"},
#endif
	{
	 .next_page = &server_acl_status_page,
	 .entry_help = "This is acl status entry",
	 .cli_name = "Status"},
	{
	 .next_page = &server_acl_config_page,
	 .entry_help = "This is acl config entry",
	 .cli_name = "Config"}
};

struct menu_page server_acl_page = {
	.entries = server_acl_page_entries,
	.tot_entries =
	    sizeof(server_acl_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is acl entry page",
	.cli_title = "acl",
	.gui_title = "ACL"
};

struct value_set server_apps_common_set_values[] = {
	{.display_value = "reject",.submit_value = "0"},
	{.display_value = "accept",.submit_value = "1"}
};

struct cmd_field server_apps_web_set_cmd_fields[] = {
	{
	 .field_name = "WEB_WAN_ENABLE",
	 .field_help = "This field represent the status of web wan",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "wan",
	 .field_gui_name = "WAN Status",
	 .values = server_apps_common_set_values,
	 .tot_values =
	 sizeof(server_apps_common_set_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "WEB_WAN_PORT",
	 .field_help = "This field represent the web wan port number",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "port",
	 .field_gui_name = "Port"},
	{
	 .field_name = "WEB_LAN_ENABLE",
	 .field_help = "This field represent the status of web lan",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "lan",
	 .field_gui_name = "LAN Status",
	 .values = server_apps_common_set_values,
	 .tot_values =
	 sizeof(server_apps_common_set_values) / sizeof(struct value_set)
	 }
};

struct cmd_field server_apps_telnet_set_cmd_fields[] = {
	{
	 .field_name = "TELNET_WAN_ENABLE",
	 .field_help = "This field represent the status of telnet wan",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "wan",
	 .field_gui_name = "WAN Status",
	 .values = server_apps_common_set_values,
	 .tot_values =
	 sizeof(server_apps_common_set_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "TELNET_WAN_PORT",
	 .field_help = "This field represent the telnet wan port number",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "port",.field_gui_name = "Port"},
	{
	 .field_name = "TELNET_LAN_ENABLE",
	 .field_help = "This field represent the status of telnet lan",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "lan",
	 .field_gui_name = "LAN Status",
	 .values = server_apps_common_set_values,
	 .tot_values =
	 sizeof(server_apps_common_set_values) / sizeof(struct value_set)
	 }
};

struct cmd_field server_apps_ssh_set_cmd_fields[] = {
	{
	 .field_name = "SSH_WAN_ENABLE",
	 .field_help = "This field represent the status of ssh wan",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "wan",
	 .field_gui_name = "WAN Status",
	 .values = server_apps_common_set_values,
	 .tot_values =
	 sizeof(server_apps_common_set_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "SSH_WAN_PORT",
	 .field_help = "This field represent the ssh wan port number",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "port",.field_gui_name = "Port"},
	{
	 .field_name = "SSH_LAN_ENABLE",
	 .field_help = "This field represent the status of ssh lan",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "lan",
	 .field_gui_name = "LAN Status",
	 .values = server_apps_common_set_values,
	 .tot_values =
	 sizeof(server_apps_common_set_values) / sizeof(struct value_set)
	 }
};

struct cmd_field server_apps_tftp_set_cmd_fields[] = {
	{
	 .field_name = "TFTP_WAN_ENABLE",
	 .field_help = "This field represent the status of tftp wan",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "wan",
	 .field_gui_name = "WAN Status",
	 .values = server_apps_common_set_values,
	 .tot_values =
	 sizeof(server_apps_common_set_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "TFTP_WAN_PORT",
	 .field_help = "This field represent the tftp wan port number",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "port",.field_gui_name = "Port"},
	{
	 .field_name = "TFTP_LAN_ENABLE",
	 .field_help = "This field represent the status of tftp lan",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "lan",
	 .field_gui_name = "LAN Status",
	 .values = server_apps_common_set_values,
	 .tot_values =
	 sizeof(server_apps_common_set_values) / sizeof(struct value_set)
	 }
};

struct cmd_field server_apps_ftp_set_cmd_fields[] = {
	{
	 .field_name = "FTP_WAN_ENABLE",
	 .field_help = "This field represent the status of ftp wan",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "wan",
	 .field_gui_name = "WAN Status",
	 .values = server_apps_common_set_values,
	 .tot_values =
	 sizeof(server_apps_common_set_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "FTP_WAN_PORT",
	 .field_help = "This field represent the ftp wan port number",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "port",.field_gui_name = "Port"},
	{
	 .field_name = "FTP_LAN_ENABLE",
	 .field_help = "This field represent the status of ftp lan",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "lan",
	 .field_gui_name = "LAN Status",
	 .values = server_apps_common_set_values,
	 .tot_values =
	 sizeof(server_apps_common_set_values) / sizeof(struct value_set)
	 }
};

struct cmd_field server_apps_snmp_set_cmd_fields[] = {
	{
	 .field_name = "SNMP_WAN_ENABLE",
	 .field_help = "This field represent the status of snmp wan",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "wan",
	 .field_gui_name = "WAN Status",
	 .values = server_apps_common_set_values,
	 .tot_values =
	 sizeof(server_apps_common_set_values) / sizeof(struct value_set)
	 }
};

struct cmd_field server_apps_igmp_set_cmd_fields[] = {
	{
	 .field_name = "IGMP_ENABLE",
	 .field_help = "This field represent the status of igmp",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "status",
	 .field_gui_name = "WAN Status",
	 .values = server_apps_common_set_values,
	 .tot_values =
	 sizeof(server_apps_common_set_values) / sizeof(struct value_set)
	 }
};

struct cmd_entry server_apps_web_set_cmd = {
	.fields = server_apps_web_set_cmd_fields,
	.tot_fields =
	    sizeof(server_apps_web_set_cmd_fields) / sizeof(struct cmd_field),
	.help = "configures web server settings",
	.post_url = "/goform/ifx_set_apps_settings",
	.get_url = "apps_serv.cli"
};

struct cmd_entry server_apps_telnet_set_cmd = {
	.fields = server_apps_telnet_set_cmd_fields,
	.tot_fields =
	    sizeof(server_apps_telnet_set_cmd_fields) /
	    sizeof(struct cmd_field),
	.help = "configures telnet server settings",
	.post_url = "/goform/ifx_set_apps_settings",
	.get_url = "apps_serv.cli"
};

struct cmd_entry server_apps_ssh_set_cmd = {
	.fields = server_apps_ssh_set_cmd_fields,
	.tot_fields =
	    sizeof(server_apps_ssh_set_cmd_fields) / sizeof(struct cmd_field),
	.help = "configures ssh server settings",
	.post_url = "/goform/ifx_set_apps_settings",
	.get_url = "apps_serv.cli"
};

struct cmd_entry server_apps_tftp_set_cmd = {
	.fields = server_apps_tftp_set_cmd_fields,
	.tot_fields =
	    sizeof(server_apps_tftp_set_cmd_fields) / sizeof(struct cmd_field),
	.help = "configures tftp server settings",
	.post_url = "/goform/ifx_set_apps_settings",
	.get_url = "apps_serv.cli"
};

struct cmd_entry server_apps_ftp_set_cmd = {
	.fields = server_apps_ftp_set_cmd_fields,
	.tot_fields =
	    sizeof(server_apps_ftp_set_cmd_fields) / sizeof(struct cmd_field),
	.help = "configures ftp server settings",
	.post_url = "/goform/ifx_set_apps_settings",
	.get_url = "apps_serv.cli"
};

struct cmd_entry server_apps_snmp_set_cmd = {
	.fields = server_apps_snmp_set_cmd_fields,
	.tot_fields =
	    sizeof(server_apps_snmp_set_cmd_fields) / sizeof(struct cmd_field),
	.help = "configures snmp server settings",
	.post_url = "/goform/ifx_set_apps_settings",
	.get_url = "apps_serv.cli"
};

struct cmd_entry server_apps_igmp_set_cmd = {
	.fields = server_apps_igmp_set_cmd_fields,
	.tot_fields =
	    sizeof(server_apps_igmp_set_cmd_fields) / sizeof(struct cmd_field),
	.help = "configures igmp server settings",
	.post_url = "/goform/ifx_set_apps_settings",
	.get_url = "apps_serv.cli"
};

struct menu_entry server_apps_web_entries[] = {
	{
	 .entry_help = "This is web app server show configuration",
	 .cli_name = "Show",
	 .cli_url = "apps_serv_web.cli"},
	{
	 .entry_help = "This is web app server set configuration",
	 .cli_name = "Set",
	 .cmd = &server_apps_web_set_cmd}
};

struct menu_entry server_apps_telnet_entries[] = {
	{
	 .entry_help = "This is telnet app server show configuration",
	 .cli_name = "Show",
	 .cli_url = "apps_serv_telnet.cli"},
	{
	 .entry_help = "This is telnet app server set configuration",
	 .cli_name = "Set",
	 .cmd = &server_apps_telnet_set_cmd}
};

struct menu_entry server_apps_ssh_entries[] = {
	{
	 .entry_help = "This is ssh app server show configuration",
	 .cli_name = "Show",
	 .cli_url = "apps_serv_ssh.cli"},
	{
	 .entry_help = "This is ssh app server set configuration",
	 .cli_name = "Set",
	 .cmd = &server_apps_ssh_set_cmd}
};

struct menu_entry server_apps_tftp_entries[] = {
	{
	 .entry_help = "This is tftp app server show configuration",
	 .cli_name = "Show",
	 .cli_url = "apps_serv_tftp.cli"},
	{
	 .entry_help = "This is tftp app server set configuration",
	 .cli_name = "Set",
	 .cmd = &server_apps_tftp_set_cmd}
};

struct menu_entry server_apps_ftp_entries[] = {
	{
	 .entry_help = "This is ftp app server show configuration",
	 .cli_name = "Show",
	 .cli_url = "apps_serv_ftp.cli"},
	{
	 .entry_help = "This is ftp app server set configuration",
	 .cli_name = "Set",
	 .cmd = &server_apps_ftp_set_cmd}
};

struct menu_entry server_apps_snmp_entries[] = {
	{
	 .entry_help = "This is snmp app server show configuration",
	 .cli_name = "Show",
	 .cli_url = "apps_serv_snmp.cli"},
	{
	 .entry_help = "This is snmp app server set configuration",
	 .cli_name = "Set",
	 .cmd = &server_apps_snmp_set_cmd}
};

struct menu_entry server_apps_igmp_entries[] = {
	{
	 .entry_help = "This is igmp app server show configuration",
	 .cli_name = "Show",
	 .cli_url = "apps_serv_igmp.cli"},
	{
	 .entry_help = "This is igmp app server set configuration",
	 .cli_name = "Set",
	 .cmd = &server_apps_igmp_set_cmd}
};

struct menu_page server_apps_web_page = {
	.entries = server_apps_web_entries,
	.tot_entries =
	    sizeof(server_apps_web_entries) / sizeof(struct menu_entry),
	.page_help =
	    "This page allows show and set web application server configuration",
	.cli_title = "web page"
};

struct menu_page server_apps_telnet_page = {
	.entries = server_apps_telnet_entries,
	.tot_entries =
	    sizeof(server_apps_telnet_entries) / sizeof(struct menu_entry),
	.page_help =
	    "This page allows show and set telnet application server configuration",
	.cli_title = "telnet page"
};

struct menu_page server_apps_ssh_page = {
	.entries = server_apps_ssh_entries,
	.tot_entries =
	    sizeof(server_apps_ssh_entries) / sizeof(struct menu_entry),
	.page_help =
	    "This page allows show and set ssh application server configuration",
	.cli_title = "ssh page"
};

struct menu_page server_apps_tftp_page = {
	.entries = server_apps_tftp_entries,
	.tot_entries =
	    sizeof(server_apps_tftp_entries) / sizeof(struct menu_entry),
	.page_help =
	    "This page allows show and set tftp application server configuration",
	.cli_title = "tftp page"
};

struct menu_page server_apps_ftp_page = {
	.entries = server_apps_ftp_entries,
	.tot_entries =
	    sizeof(server_apps_ftp_entries) / sizeof(struct menu_entry),
	.page_help =
	    "This page allows show and set ftp application server configuration",
	.cli_title = "ftp page"
};

struct menu_page server_apps_snmp_page = {
	.entries = server_apps_snmp_entries,
	.tot_entries =
	    sizeof(server_apps_snmp_entries) / sizeof(struct menu_entry),
	.page_help =
	    "This page allows show and set snmp application server configuration",
	.cli_title = "snmp page"
};

struct menu_page server_apps_igmp_page = {
	.entries = server_apps_igmp_entries,
	.tot_entries =
	    sizeof(server_apps_igmp_entries) / sizeof(struct menu_entry),
	.page_help =
	    "This page allows show and set igmp application server configuration",
	.cli_title = "igmp page"
};

struct menu_entry server_apps_page_entries[] = {
	{
	 .next_page = &server_apps_web_page,
	 .entry_help = "Configures web server",
	 .cli_name = "WEB",
	 },
	{
	 .next_page = &server_apps_telnet_page,
	 .entry_help = "Configures telnet server",
	 .cli_name = "TELNET",
	 },
	{
	 .next_page = &server_apps_ssh_page,
	 .entry_help = "Configures ssh server",
	 .cli_name = "SSH",
	 },
	{
	 .next_page = &server_apps_tftp_page,
	 .entry_help = "Configures tftp server",
	 .cli_name = "TFTP",
	 },
	{
	 .next_page = &server_apps_ftp_page,
	 .entry_help = "Configures ftp server",
	 .cli_name = "FTP",
	 },
	{
	 .next_page = &server_apps_snmp_page,
	 .entry_help = "Configures snmp server",
	 .cli_name = "SNMP",
	 },
	{
	 .next_page = &server_apps_igmp_page,
	 .entry_help = "Configures igmp server",
	 .cli_name = "IGMP",
	 }
};

struct menu_page server_apps_page = {
	.entries = server_apps_page_entries,
	.tot_entries =
	    sizeof(server_apps_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is application page",
	.cli_title = "apps serv",.gui_title = "Application server"
};

struct menu_entry server_page_entries[] = {
	{
	 .next_page = &server_apps_page,
	 .entry_help = "This is application server settings entry",
	 .cli_name = "settings",.gui_name = "APPS",.gui_url = "apps_serv.asp"},
	{
	 .next_page = &server_acl_page,
	 .entry_help = "This is acl server entry",
	 .cli_name = "acl",.gui_name = "ACL",.gui_url = "server_acl.asp"}
};

struct menu_page server_page = {
	.entries = server_page_entries,
	.tot_entries = sizeof(server_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is server page",
	.cli_title = "appserver",.gui_title = "Server"
};
#endif
