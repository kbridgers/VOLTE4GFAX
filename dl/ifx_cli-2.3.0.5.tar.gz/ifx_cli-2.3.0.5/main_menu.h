
struct menu_entry main_menu_entries[] = {
	{
	 .next_page = &system_page,
	 .entry_help = "This is system entry",
	 .cli_name = "system",
	 .gui_name = "System",
	 },
	{
	 .next_page = &statistics_page,
	 .entry_help = "This is statistics entry",
	 .cli_name = "statistics",
	 .gui_name = "Statistics",
	 },
#if 0
	{
	 .next_page = &adsl_page,
	 .entry_help = "The adsl menu",
	 .cli_name = "adsl",
	 .gui_name = "ADSL",

	 },
#endif
	{
	 .next_page = &route_page,
	 .entry_help = "This is route entry",
	 .cli_name = "routing",
	 .gui_name = "Routing",
	 },
	{
	 .next_page = &lan_page,
	 .entry_help = "This is lan entry",
	 .cli_name = "lan",
	 .gui_name = "LAN",
	 },
#if 0
	{
	 .next_page = &firewall_page,
	 .entry_help = "This is firewall entry",
	 .cli_name = "firewall",
	 .gui_name = "Firewall",
	 },
#endif
#ifndef CONFIG_FEATURE_SEMINDIA
#if 0
	{
	 .next_page = &snmp_page,
	 .entry_help = "This is snmp entry",
	 .cli_name = "SNMP",
	 .gui_name = "SNMP",
	 },
	{
	 .next_page = &wireless_page,
	 .entry_help = "This is wireless entry",
	 .cli_name = "wireless",
	 .gui_name = "Wireless",
	 },
#endif
#endif				//CONFIG_FEATURE_SEMINDIA
#if 0
	{
	 .next_page = &nat_page,
	 .entry_help = "This is nat entry",
	 .cli_name = "nat",
	 .gui_name = "NAT",
	 },
#endif

#ifndef CONFIG_FEATURE_SEMINDIA
#if 0
	{
	 .next_page = &vlan_page,
	 .entry_help = "This is vlan entry",
	 .cli_name = "vlan",
	 .gui_name = "VLAN",
	 },
#endif
#endif				// CONFIG_FEATURE_SEMINDIA
#ifndef CONFIG_FEATURE_SEMINDIA
#if 0
	{
	 .next_page = &qos_page,
	 .entry_help = "This is qos entry",
	 .cli_name = "QoS",
	 .gui_name = "QoS",
	 },
#endif
#endif				// CONFIG_FEATURE_SEMINDIA
#if 0
	{
	 .next_page = &server_page,
	 .entry_help = "This is appilcation server entry",
	 .cli_name = "server",
	 .gui_name = "Server",
	 },
#endif
	{
	 .next_page = &tr69_page,
	 .entry_help = "This is TR69 entry",
	 .cli_name = "tr69",
	 .gui_name = "TR69",
	 },
#ifdef CONFIG_FEATURE_SAMBA
	{
	 .next_page = &content_sharing_page,
	 .entry_help = "This is content sharing entry",
	 .cli_name = "sharing",
	 .gui_name = "Content Sharing",
	 },
#endif
	{
	 .entry_help = "This is top level show entry",
	 .cli_name = "show",
	 .cli_url = "index.cli",
	 .gui_name = "show",
	 .gui_url = "index.asp"}
};

struct menu_page main_menu = {
	main_menu_entries,
	sizeof(main_menu_entries) / sizeof(struct menu_entry),
	"The left main page",
	"Main Menu",
	"Main Menu",
	1
};

struct menu_entry cli_menu_entries[] = {
	{
	 .next_page = &main_menu,
	 .entry_help = "This main menu entry",
	 .cli_name = "main",
	 .gui_name = "main",
	 }
};

struct menu_page cli_menu = {
	cli_menu_entries,
	sizeof(cli_menu_entries) / sizeof(struct menu_entry),
	"The Welcome page",
	"CLI Welcome",
	"GUI Welcome",
	1
};
