/* ============================================================================
 * Copyright (C) 2005 -Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 *============================================================================
 *
 * This document contains proprietary information belonging to Infineon 
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 * 
 * ============================================================================
 */

/* ===========================================================================
 *
 * File Name:   adsl_menu_func.c
 * Author :     Nirav Salot
 * Date: 		April, 2005
 *
 * ===========================================================================
 *
 * Project: Amazon
 *
 * ===========================================================================
 * Contents: This file implements ADSL menu related specific functions.
 *  
 * ===========================================================================
 * References: 
 *
 */
#include "common.h"

#define MAX_FIELD_LEN  256
#define INT_STR_LEN 32

char manual_mode_str[40];
int adsl_manual_mode_cmd_fprocessing(struct cmd_field *cur_field, char *poststr)
{
	char tmp[3];
	poststr[strlen(poststr) - 1] = '\0';
	if (strcmp("g992_1a", cur_field->field_name) == 0) {
		strcpy(manual_mode_str, "adsl_mode=Manual");
		if (strcmp("Enable", cur_field->cur_value) == 0) {
			sprintf(tmp, "_%d", 1);
		} else {
			sprintf(tmp, "_%d", 0);
		}
		strcat(manual_mode_str, tmp);
	}
	if (strcmp("g992_2", cur_field->field_name) == 0) {
		if (strcmp("Enable", cur_field->cur_value) == 0) {
			sprintf(tmp, "_%d", 1);
		} else {
			sprintf(tmp, "_%d", 0);
		}
		strcat(manual_mode_str, tmp);
	}
	if (strcmp("g992_3a", cur_field->field_name) == 0) {
		if (strcmp("Enable", cur_field->cur_value) == 0) {
			sprintf(tmp, "_%d", 1);
		} else {
			sprintf(tmp, "_%d", 0);
		}
		strcat(manual_mode_str, tmp);
	}
	if (strcmp("g992_5a", cur_field->field_name) == 0) {
		if (strcmp("Enable", cur_field->cur_value) == 0) {
			sprintf(tmp, "_%d", 1);
		} else {
			sprintf(tmp, "_%d", 0);
		}
		strcat(manual_mode_str, tmp);
	}
	if (strcmp("t1_413", cur_field->field_name) == 0) {
		if (strcmp("Enable", cur_field->cur_value) == 0) {
			sprintf(tmp, "_%d", 1);
		} else {
			sprintf(tmp, "_%d", 0);
		}
		strcat(manual_mode_str, tmp);
	}
	if (strcmp("g992_3l", cur_field->field_name) == 0) {
		if (strcmp("Enable", cur_field->cur_value) == 0) {
			sprintf(tmp, "_%d", 1);
		} else {
			sprintf(tmp, "_%d", 0);
		}
		strcat(manual_mode_str, tmp);
	}
	if (strcmp("g992_3i", cur_field->field_name) == 0) {
		if (strcmp("Enable", cur_field->cur_value) == 0) {
			sprintf(tmp, "_%d", 1);
		} else {
			sprintf(tmp, "_%d", 0);
		}
		strcat(manual_mode_str, tmp);
	}
	if (strcmp("g992_5i", cur_field->field_name) == 0) {
		if (strcmp("Enable", cur_field->cur_value) == 0) {
			sprintf(tmp, "_%d", 1);
		} else {
			sprintf(tmp, "_%d", 0);
		}
		strcat(manual_mode_str, tmp);
	}
	if (strcmp("g992_3m", cur_field->field_name) == 0) {
		if (strcmp("Enable", cur_field->cur_value) == 0) {
			sprintf(tmp, "_%d", 1);
		} else {
			sprintf(tmp, "_%d", 0);
		}
		strcat(manual_mode_str, tmp);
	}
	if (strcmp("g992_5m", cur_field->field_name) == 0) {
		if (strcmp("Enable", cur_field->cur_value) == 0) {
			sprintf(tmp, "_%d", 1);
		} else {
			sprintf(tmp, "_%d", 0);
		}
		strcat(manual_mode_str, tmp);
	}
	if (strcmp("g992_1b", cur_field->field_name) == 0) {
		if (strcmp("Enable", cur_field->cur_value) == 0) {
			sprintf(tmp, "_%d", 1);
		} else {
			sprintf(tmp, "_%d", 0);
		}
		strcat(manual_mode_str, tmp);
	}
	if (strcmp("g992_3b", cur_field->field_name) == 0) {
		if (strcmp("Enable", cur_field->cur_value) == 0) {
			sprintf(tmp, "_%d", 1);
		} else {
			sprintf(tmp, "_%d", 0);
		}
		strcat(manual_mode_str, tmp);
	}
	if (strcmp("g992_5b", cur_field->field_name) == 0) {
		if (strcmp("Enable", cur_field->cur_value) == 0) {
			sprintf(tmp, "_%d", 1);
		} else {
			sprintf(tmp, "_%d", 0);
		}
		strcat(manual_mode_str, tmp);
	}
	if (strcmp("g992_3j", cur_field->field_name) == 0) {
		if (strcmp("Enable", cur_field->cur_value) == 0) {
			sprintf(tmp, "_%d", 1);
		} else {
			sprintf(tmp, "_%d", 0);
		}
		strcat(manual_mode_str, tmp);
	}
	if (strcmp("g992_5j", cur_field->field_name) == 0) {
		if (strcmp("Enable", cur_field->cur_value) == 0) {
			sprintf(tmp, "_%d", 1);
		} else {
			sprintf(tmp, "_%d", 0);
		}
		strcat(manual_mode_str, tmp);
	}
	return 0;
}

int adsl_phyconfig_autoselected_mode_post_flag(struct cmd_entry *p,
					       char *poststr)
{
	strcat(poststr, "submit_action=adsl_mode");
	return 0;
}

int adsl_phyconfig_manual_mode_post_flag(struct cmd_entry *p, char *poststr)
{
	strcat(poststr, "submit_action=adsl_mode");
	strcat(poststr, "&");
	strcat(poststr, manual_mode_str);
	return 0;
}

int adsl_phyconfig_testmode_control_post_flag(struct cmd_entry *p,
					      char *poststr)
{
	strcat(poststr, "submit_action=testmode_control");
	return 0;
}

int adsl_phyconfig_power_mgnt_control_post_flag(struct cmd_entry *p,
						char *poststr)
{
	strcat(poststr, "submit_action=power_management_control");
	return 0;
}
