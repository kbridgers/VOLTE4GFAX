
int static_route_add_post_flag(struct cmd_entry *cmd, char *poststr);
int static_route_del_custom_valid(struct cmd_entry *cmd, char *errstr);
int static_route_del_post_flag(struct cmd_entry *cmd, char *poststr);
int dynamic_route_config_custom_valid(struct cmd_entry *cmd, char *errstr);
