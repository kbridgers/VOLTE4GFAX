
int server_acl_config_post_flag(struct cmd_entry *cmd, char *poststr);
