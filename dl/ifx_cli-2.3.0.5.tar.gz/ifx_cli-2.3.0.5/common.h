#ifndef __COMMON_H
#define __COMMON_H
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <ctype.h>
#include <unistd.h>
#include <termios.h>
#include <fcntl.h>

#define IFX_CLI_PROMPTEDMODE
#define IFX_CLI_INACTIVITY_TIMEOUT		300	/* Wait for 5 mins of inactivity before exiting the server */

#if 1
#ifdef IFX_DEMALLOC
#include <dmalloc.h>
#endif
#endif

#include "ifx_common.h"		/* For ifx_GetCfgData functions */

#include "ifx_emf.h"
#include "ifx_amazon_cgi.h"	/* For webGetCfgData and other constant */

#include "menu_def.h"

#define FILE_RC_CONF	"/flash/rc.conf"

#define DIR_MOD	0777
#define SOCK_FE_PATH "/tmp/cli_fe_socket"
#define SOCK_BE_PATH "/tmp/cli_be_socket"

#define HDR_GETHTML		"GET /%s HTTP/1.1\r\n" \
						"Host: 127.0.0.1\r\n" \
						"Connection: keep-alive\r\n" \
						"User-Agent: cli. IFX-Config-Id %d\r\n" \
						"Referer: http://127.0.0.1/\r\n" \
						"\r\n"

#define HDR_POSTHTML	"POST /%s HTTP/1.1\r\n" \
						"Host: 127.0.0.1\r\n" \
						"Connection: keep-alive\r\n" \
						"User-Agent: cli. IFX-Config-Id %d\r\n" \
						"Referer: http://127.0.0.1/\r\n" \
						"Content-Length: %d\r\n" \
						"\r\n"
#define CMD_READ_MODIFY_WRITE 1

#define IFX_FREE(p)  free((p)); p=NULL

#define IFX_OK		0

#ifdef IFX_ERR
#undef IFX_ERR
#endif
#define IFX_ERR	 -1

#define	PREVIOUS_CHAR	"<"
#define HELP_CHAR		"?"
#define	EXIT_CHAR		"@"
#define LOGOUT_CHAR		"!"

#define COLON_POS	50
#define SCREEN_WIDTH	50

//#define T(str)        (str)

int create_dir_struct(struct menu_page *current_page);
struct menu_entry *find_menu_entry(char *query);
int http_query(char *url, char *body, enum HTTP_REQTYPE req_type);
void free_cmd_fvset(struct field_value_set *pfvset, int *ptot_fvset);
void free_vset(struct cmd_entry *cmd);
void reset_cmd_field_values(struct cmd_entry *);
void print_cmd_fvset(struct field_value_set *pfvset, int tot_fvset);
int tot_strchr(char *start, char *end, char searchchr);
struct field_value_set *make_fvset(char *cmd, int *ptot_fvset);
struct field_value_set *make_get_fvset(char *url, int *ptot_fvset);

int get_dynamic_fvset(struct cmd_entry *cmd);

int check_syntax(struct cmd_entry *cur_cmd, struct field_value_set *pfvset,
		 int tot_fvset);
void gen_syntax(struct menu_entry *cur_entry, char *str_syntax, int paramhelp);

int multifield_poststr(char *prefix, char *value, int startval, char *delim,
		       char *poststr);
int ip_nm_gw_processing(struct cmd_field *field, char *poststr);
int mac_addr_processing(struct cmd_field *field, char *poststr);

int generate_poststr(struct cmd_entry *cmd, char *poststr);
int getindex(char *prefix, char *searchstr, int bPartial, char *foundstr);

void print_help(struct menu_entry *cur_entry, char *help);
void get_help(char *str, struct menu_entry *cmd_menu, char *out_help);
int check_type(struct cmd_entry *cur_cmd, struct field_value_set *pfvset,
	       int tot_pfvset);

int isipaddr(char *str);
int isnum(char *str);

int populate_fieldvalues(struct cmd_entry *cmd, struct field_value_set *pfvset,
			 int tot_fvset);
int print_field_values(struct cmd_entry *cmd);
struct cmd_field *get_field_entry(struct cmd_entry *p, char *field_name);

extern char *cli_root_dir;
extern char *cli_fe_path;

extern struct menu_page cli_menu;

void websGetIFInfo(int IF_type, int IP_Type, int nIDX, int nReqIdx, int bBreak,
		   char *pRetValue);

int make_be_msg(struct menu_entry *cur_menu_entry, char **ppresponse,
		int *preslen);
int make_cmd_msg(struct cmd_entry *cmd, char **ppresponse, int *preslen);
int make_menu_msg(struct menu_page *page, char **ppresponse, int *preslen);
int make_show_msg(char *curres, char **ppresponse, int *preslen);

void get_httpd_data(char *url, enum HTTP_REQTYPE req_type, char *body,
		    char **ppresponse, int *preslen);

int update_cmd_cur_values(struct cmd_entry *cmd,
			  struct field_value_set *cmd_get_fvset,
			  int tot_get_fvset);
void update_poststr_from_backend(struct field_value_set *fvset, int num_fv,
				 char *poststr);

int prompt_validate_value(struct cmd_msg *pcur_cmd_msg);
#endif
