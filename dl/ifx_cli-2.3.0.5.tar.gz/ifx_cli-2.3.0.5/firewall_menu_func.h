
int firewall_macctrl_del_post_flag(struct cmd_entry *cmd, char *poststr);
int firewall_packetfilter_del_post(struct cmd_entry *cmd, char *poststr);
int packetfilter_add_valid(struct cmd_entry *cmd, char *errstr);
