/* ============================================================================
 * Copyright (C) 2005 -Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 *============================================================================
 *
 * This document contains proprietary information belonging to Infineon 
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 * 
 * ============================================================================
 */

/* ===========================================================================
 *
 * File Name:   adsl_menu_func.c
 * Author :     Nirav Salot
 * Date: 		April, 2005
 *
 * ===========================================================================
 *
 * Project: Amazon
 *
 * ===========================================================================
 * Contents: This file implements ADSL menu related specific functions.
 *  
 * ===========================================================================
 * References: 
 *
 */
#include <stdio.h>
#include <string.h>
#include "common.h"
int dynamic_route_config_custom_valid(struct cmd_entry *cmd, char *errstr)
{
	char *mode_val = NULL;
	int bListenMode = 0;
	int bSupplyMode = 0;

	mode_val = get_field_entry(cmd, "wkMode")->cur_value;
	if (get_field_entry(cmd, "RtListenMode")->cur_value)
		bListenMode = 1;
	if (get_field_entry(cmd, "RtSupplyMode")->cur_value)
		bSupplyMode = 1;

	printf
	    ("dynamic_route_config_custom_valid : mode [%s] supplymode %d and listenmode %d\n",
	     mode_val, bSupplyMode, bListenMode);
	if (strcmp(mode_val, "enable") == 0) {
		if (bListenMode == 0 || bSupplyMode == 0) {
			sprintf(errstr,
				"Please specify the values for ListenMode and SupplyMode\n");
			return -1;
		}
	}
	return 0;
}

int static_route_del_custom_valid(struct cmd_entry *cmd, char *errstr)
{
	char *sIP = NULL;
	char *sNM = NULL;
	char *sGW = NULL;

	sIP = get_field_entry(cmd, "AIP")->cur_value;
	sNM = get_field_entry(cmd, "ANM")->cur_value;
	sGW = get_field_entry(cmd, "AGW")->cur_value;

	if (sIP == NULL && sNM == NULL && sGW == NULL) {
		sprintf(errstr,
			"Please enter at least one of the field to delete the route.\n");
		return -1;
	}
	return 0;
}

#define MAX_FIELD_LEN  256
int static_route_del_post_flag(struct cmd_entry *cmd, char *poststr)
{
	char *sIP = NULL;
	char *sNM = NULL;
	char *sGW = NULL;
	char searchstr[256];
	char foundstr[256];
	//int delindex = -1;
	char sValue[MAX_FIELD_LEN];
	char command[MAX_FIELD_LEN];
	int i, nChannel_Size = 0;

	sIP = get_field_entry(cmd, "AIP")->cur_value;
	sNM = get_field_entry(cmd, "ANM")->cur_value;
	sGW = get_field_entry(cmd, "AGW")->cur_value;

	memset(searchstr, 0x00, sizeof(searchstr));
	memset(foundstr, 0x00, sizeof(foundstr));
	/*
	   if(sIP)
	   {
	   strcat(searchstr,sIP);
	   strcat(searchstr," netmask ");
	   }
	   if(sNM)
	   {
	   if(sIP == NULL)
	   strcat(searchstr," netmask ");
	   strcat(searchstr,sNM);
	   }
	   if(sGW)
	   {
	   strcat(searchstr," gw ");
	   strcat(searchstr,sGW);
	   }
	 */

	if (ifx_GetCfgData(FILE_RC_CONF, "routing", T("routing_Count"), sValue)
	    == 0) {
		printf("No routing entries found !\n");
		return -1;
	}
	nChannel_Size = atoi(sValue);

	for (i = 0; i < nChannel_Size; i++) {
		snprintf(command, sizeof(command), "route_%d_dstIp", i);
		ifx_GetCfgData(FILE_RC_CONF, "routing", command, sValue);

		if (strncmp(sValue, sIP, strlen(sValue))) {
			continue;
		}

		snprintf(command, sizeof(command), "route_%d_dstMask", i);
		ifx_GetCfgData(FILE_RC_CONF, "routing", command, sValue);

		if (strncmp(sValue, sNM, strlen(sValue))) {
			continue;
		}

		snprintf(command, sizeof(command), "route_%d_gw", i);
		ifx_GetCfgData(FILE_RC_CONF, "routing", command, sValue);

		if (strncmp(sValue, sGW, strlen(sValue))) {
			continue;
		}

		//matche route entry now        
		snprintf(command, sizeof(command), "route_%d_cpeId", i);
		ifx_GetCfgData(FILE_RC_CONF, "routing", command, sValue);

		snprintf(command, sizeof(command), "delcpeID=%s", sValue);
		strlcat(poststr, command, MAX_FIELD_LEN);

		snprintf(command, sizeof(command), "&deldst=%s", sIP);
		strlcat(poststr, command, MAX_FIELD_LEN);

		snprintf(command, sizeof(command), "&delnetmask=%s", sNM);
		strlcat(poststr, command, MAX_FIELD_LEN);

		snprintf(command, sizeof(command), "&delgw=%s", sGW);
		strlcat(poststr, command, MAX_FIELD_LEN);
		return 0;

	}

	printf("Could not found the route to be deleted\n");
	sprintf(poststr, "Could not found the route to be deleted\n");
	return -1;
	/*
	   if(sIP && sNM && sGW)
	   delindex = getindex("staticRoute",searchstr,0,foundstr);
	   else
	   delindex = getindex("staticRoute",searchstr,1,foundstr);
	   if(delindex >= 0)
	   {
	   char strIndex[4];

	   printf("static_route_del_post_flag : route to be deleted [%s]\n",foundstr);
	   memset(strIndex,0x00,sizeof(strIndex));
	   sprintf(strIndex,"%d",delindex);
	   //strcat(poststr,"delflag=1&"); // this is added as hidden flag 
	   strcat(poststr,"delindex=");
	   strcat(poststr,strIndex);
	   return 0;
	   } else
	   {
	   printf("Could not found the route to be deleted\n");
	   sprintf(poststr,"Could not found the route to be deleted\n");
	   return -1;
	   }
	 */
}

int static_route_add_post_flag(struct cmd_entry *cmd, char *poststr)
{
	char *sIP = NULL;
	char *sNM = NULL;
	char *sGW = NULL;
	char *sTemp = NULL;
	char searchstr[256];
	char foundstr[256];
	//int delindex = -1;

	char sValue[MAX_FIELD_LEN];
	char command[MAX_FIELD_LEN];
	int i, nChannel_Size = 0;

	sIP = get_field_entry(cmd, "AIP")->cur_value;
	sNM = get_field_entry(cmd, "ANM")->cur_value;
	sGW = get_field_entry(cmd, "AGW")->cur_value;

	memset(searchstr, 0x00, sizeof(searchstr));
	memset(foundstr, 0x00, sizeof(foundstr));

	if (ifx_GetCfgData(FILE_RC_CONF, "routing", T("routing_Count"), sValue)
	    == 0) {
		printf("No routing entries found !\n");
		return -1;
	}
	nChannel_Size = atoi(sValue);

	for (i = 0; i < nChannel_Size; i++) {
		snprintf(command, sizeof(command), "route_%d_dstIp", i);
		ifx_GetCfgData(FILE_RC_CONF, "routing", command, sValue);

		if (strncmp(sValue, sIP, strlen(sValue))) {
			continue;
		}

		snprintf(command, sizeof(command), "route_%d_dstMask", i);
		ifx_GetCfgData(FILE_RC_CONF, "routing", command, sValue);

		if (strncmp(sValue, sNM, strlen(sValue))) {
			continue;
		}

		snprintf(command, sizeof(command), "route_%d_gw", i);
		ifx_GetCfgData(FILE_RC_CONF, "routing", command, sValue);

		if (strncmp(sValue, sGW, strlen(sValue))) {
			continue;
		}

		printf("Route present\n");
		snprintf(poststr, sizeof(command), "Route present\n");
		return -1;

	}

//add route entry if no match

	sTemp = strtok(sIP, ".");
	snprintf(command, sizeof(command), "AIP1=%s", sTemp);
	strlcat(poststr, command, MAX_FIELD_LEN);
	sTemp = strtok(NULL, ".");
	snprintf(command, sizeof(command), "AIP2=%s", sTemp);
	strlcat(poststr, command, MAX_FIELD_LEN);
	sTemp = strtok(NULL, ".");
	snprintf(command, sizeof(command), "AIP3=%s", sTemp);
	strlcat(poststr, command, MAX_FIELD_LEN);
	sTemp = strtok(NULL, ".");
	snprintf(command, sizeof(command), "AIP4=%s", sTemp);
	strlcat(poststr, command, MAX_FIELD_LEN);

	sTemp = strtok(sNM, ".");
	snprintf(command, sizeof(command), "ANM1=%s", sTemp);
	strlcat(poststr, command, MAX_FIELD_LEN);
	sTemp = strtok(NULL, ".");
	snprintf(command, sizeof(command), "ANM2=%s", sTemp);
	strlcat(poststr, command, MAX_FIELD_LEN);
	sTemp = strtok(NULL, ".");
	snprintf(command, sizeof(command), "ANM3=%s", sTemp);
	strlcat(poststr, command, MAX_FIELD_LEN);
	sTemp = strtok(NULL, ".");
	snprintf(command, sizeof(command), "ANM4=%s", sTemp);
	strlcat(poststr, command, MAX_FIELD_LEN);

	sTemp = strtok(sGW, ".");
	snprintf(command, sizeof(command), "AGW1=%s", sTemp);
	strlcat(poststr, command, MAX_FIELD_LEN);
	sTemp = strtok(NULL, ".");
	snprintf(command, sizeof(command), "AGW2=%s", sTemp);
	strlcat(poststr, command, MAX_FIELD_LEN);
	sTemp = strtok(NULL, ".");
	snprintf(command, sizeof(command), "AGW3=%s", sTemp);
	strlcat(poststr, command, MAX_FIELD_LEN);
	sTemp = strtok(NULL, ".");
	snprintf(command, sizeof(command), "AGW4=%s", sTemp);
	strlcat(poststr, command, MAX_FIELD_LEN);
	IFX_DBG("-- %s \n", poststr);
	return 0;

}
