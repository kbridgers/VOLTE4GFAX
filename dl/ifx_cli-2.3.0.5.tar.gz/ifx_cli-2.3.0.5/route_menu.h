
#include "route_menu_func.h"

struct menu_entry route_table_entries[] = {
	{
	 .entry_help = "This is show_route_table entry",
	 .cli_name = "Show",
	 .cli_url = "route_table.cli",
	 }
};

struct menu_page route_table_page = {
	.entries = route_table_entries,
	.tot_entries = sizeof(route_table_entries) / sizeof(struct menu_entry),
	.page_help = "This is route_table page",
	.cli_title = "routetable",
	.gui_title = "Route Table"
};

struct value_set dynamic_route_config_cmd_mode_values[] = {
	{
	 .display_value = "enable",
	 .submit_value = "1"},
	{
	 .display_value = "disable",
	 .submit_value = "0"}
};

struct value_set dynamic_route_config_cmd_supplymode_values[] = {
	{
	 .display_value = "disable",
	 .submit_value = "0"},
	{
	 .display_value = "rip1",
	 .submit_value = "1"},
	{
	 .display_value = "rip2",
	 .submit_value = "2"}
};

struct value_set dynamic_route_config_cmd_listenmode_values[] = {
	{
	 .display_value = "disable",
	 .submit_value = "0"},
	{
	 .display_value = "rip1",
	 .submit_value = "1"},
	{
	 .display_value = "rip2",
	 .submit_value = "2"},
	{
	 .display_value = "both",
	 .submit_value = "3"},
};

struct cmd_field dynamic_route_config_cmd_fields[] = {
	{
	 .field_name = "wkMode",
	 .field_help = "This field represent the wk mode",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "mode",
	 .field_gui_name = "WK Mode",
	 .values = dynamic_route_config_cmd_mode_values,
	 .tot_values =
	 sizeof(dynamic_route_config_cmd_mode_values) /
	 sizeof(struct value_set),
	 },
	{
	 .field_name = "RtListenMode",
	 .field_help = "This field represent the listen mode",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "listenmode",
	 .field_gui_name = "Listen Mode",
	 .field_gui_name = "Listen Mode",
	 .values = dynamic_route_config_cmd_listenmode_values,
	 .tot_values =
	 sizeof(dynamic_route_config_cmd_listenmode_values) /
	 sizeof(struct value_set),
	 },
	{
	 .field_name = "RtSupplyMode",
	 .field_help = "This field represent the supple mode",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "supplymode",
	 .field_gui_name = "Supply Mode",
	 .field_gui_name = "Supply Mode",
	 .values = dynamic_route_config_cmd_supplymode_values,
	 .tot_values =
	 sizeof(dynamic_route_config_cmd_supplymode_values) /
	 sizeof(struct value_set),
	 }

};

struct cmd_entry dynamic_route_config_cmd = {
	.fields = dynamic_route_config_cmd_fields,
	.tot_fields =
	    sizeof(dynamic_route_config_cmd_fields) / sizeof(struct cmd_field),
	.help = "Allows to configure dynamic routing",
	.post_url = "/goform/ifx_set_route_dynamic",
	//.custom_validation=dynamic_route_config_custom_valid,
	.get_url = "route_dynamic.cli"
};

struct menu_entry dynamic_routing_page_entries[] = {
	{
	 .entry_help = "This is show_dynamic_route entry",
	 .cli_name = "Show",
	 .cli_url = "route_dynamic.cli",
	 },
	{
	 .entry_help = "This is config_dynamic_route entry",
	 .cli_name = "Set",
	 .cmd = &dynamic_route_config_cmd}

};

struct menu_page dynamic_routing_page = {
	.entries = dynamic_routing_page_entries,
	.tot_entries =
	    sizeof(dynamic_routing_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is Dynamic Routing page",
	.cli_title = "dynamic routing",
	.gui_title = "Dynamic Routing"
};

struct menu_entry table_list_page_entries[] = {
	{
	 .entry_help = "This is show_route_table entry",
	 .cli_name = "Show",
	 .cli_url = "route_table.cli"},
	{

	 .entry_help = "This is del_route_table_entry entry",
	 .cli_name = "Delete",
	 .cmd = NULL}
};

struct menu_page table_list_page = {
	.entries = table_list_page_entries,
	.tot_entries =
	    sizeof(table_list_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is table_list page",
	.cli_title = "Table List",
	.gui_title = "Table List"
};

struct cmd_field del_static_route_cmd_fields[] = {
	{
	 .field_name = "AIP",
	 .field_help = "This field represent the ip address",
	 .data_type = IPADDR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "destip",
	 .field_gui_name = "Destination IP Address",
	 },
	{
	 .field_name = "ANM",
	 .field_help = "This field represent the netmask",
	 .data_type = NETMASK,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "Netmask",
	 },
	{
	 .field_name = "AGW",
	 .field_help = "This field represent the gateway address",
	 .data_type = IPADDR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "gw",
	 .field_gui_name = "Gateway",
	 },
	{
	 .field_name = "delflag",
	 .field_help = NULL,
	 .data_type = STR,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .field_display_name = NULL,
	 .fprocessing_post = NULL,
	 .cur_value = "1"}
};

struct cmd_entry del_static_route_cmd = {
	.fields = del_static_route_cmd_fields,
	.tot_fields =
	    sizeof(del_static_route_cmd_fields) / sizeof(struct cmd_field),
	.help = "This command deletes static route",
	.post_url = "/goform/ifx_set_route_static",
	//.custom_validation=static_route_del_custom_valid,
	.custom_processing_post = static_route_del_post_flag
};

struct cmd_field add_static_route_cmd_fields[] = {
	{
	 .field_name = "AIP",
	 .field_help = "This field represent the ip address",
	 .data_type = IPADDR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "destip",
	 .field_gui_name = "Destination IP Address",
	 .fprocessing_post = ip_nm_gw_processing},
	{
	 .field_name = "ANM",
	 .field_help = "This field represent the netmask",
	 .data_type = NETMASK,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "Netmask",
	 .fprocessing_post = ip_nm_gw_processing},
	{
	 .field_name = "AGW",
	 .field_help = "This field represent the gateway address",
	 .data_type = IPADDR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "gw",
	 .field_gui_name = "Gateway",
	 .fprocessing_post = ip_nm_gw_processing},
	{
	 .field_name = "addflag",
	 .field_help = NULL,
	 .data_type = STR,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .field_display_name = NULL,
	 .fprocessing_post = NULL,
	 .cur_value = "1"}
};

struct cmd_entry add_static_route_cmd = {
	.fields = add_static_route_cmd_fields,
	.tot_fields =
	    sizeof(add_static_route_cmd_fields) / sizeof(struct cmd_field),
	.help = "This command adds static route",
	.post_url = "/goform/ifx_set_route_static",
	.custom_processing_post = static_route_add_post_flag
};

struct menu_entry static_routing_page_entries[] = {
	{
	 .entry_help = "This is show_static_route entry",
	 .cli_name = "Show",
	 "route_static.cli",
	 },
	{
	 .entry_help = "This is add_static_route entry",
	 .cli_name = "Add",
	 .cmd = &add_static_route_cmd},
	{
	 .entry_help = "This is del_static_route entry",
	 .cli_name = "Delete",
	 .cmd = &del_static_route_cmd}
};

struct menu_page static_routing_page = {
	.entries = static_routing_page_entries,
	.tot_entries =
	    sizeof(static_routing_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is static_routing page",
	.cli_title = "Static Routing",
	.gui_title = "Static Routing"
};

struct menu_entry route_page_entries[] = {
	{
	 .next_page = &static_routing_page,
	 .entry_help = "This is static_routing entry",
	 .cli_name = "static",

	 .gui_name = "Static Routing",
	 .gui_url = "route_static.asp"},
#ifndef CONFIG_FEATURE_SEMINDIA
#if 0
	{
	 .next_page = &dynamic_routing_page,
	 .entry_help = "This is dynamic_routing entry",
	 .cli_name = "dynamic",

	 .gui_name = "Dynamic Routing",
	 .gui_url = "route_dynamic.asp"},
#endif
#endif				// CONFIG_FEATURE_SEMINDIA
	{
	 .next_page = &route_table_page,
	 .entry_help = "This is route_table entry",
	 .cli_name = "table",

	 .gui_name = "Routing Table",
	 .gui_url = "route_table.asp"}

};

struct menu_page route_page = {
	.entries = route_page_entries,
	.tot_entries = sizeof(route_page_entries) / sizeof(struct menu_entry),
	.page_help = "The Route page",
	.cli_title = "Route Page",
	.gui_title = "Route Page",
	.fpos = 1
};
