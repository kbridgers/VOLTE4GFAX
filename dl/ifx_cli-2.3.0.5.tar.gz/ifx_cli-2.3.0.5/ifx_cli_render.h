#ifndef __CLI_RENDER_H__
#define __CLI_RENDER_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define SCREEN_WIDTH 80

#define TAB_SPACE 3
#define BUF_LEN 2048

#define TRUE 1
#define FALSE 0

#define ALIGN_LEFT	0
#define ALIGN_RIGHT	1
#define ALIGN_CENTER	2

struct tr;
struct table;

struct td_params {
	char align;
	char nowrap;
	short width;
	short computed_width;	/* strlen(str)+1 */
	short display_width;	/*shall be calculated */
	short printed_width;	/* shall be calculated */
};

struct tr_params {
	char align;
	short width;
};

struct td {
	struct td_params params;
	char *str;
	struct tr *tr;		/* back reference */
};

struct tr {
	int num_td;
	struct tr_params params;
	struct td *td;
	struct table *table;	/* back reference */
	int th;
};

struct table {
	int border;
	char align;
	int num_tr;		/* rows */
	int num_td;		/* cols */
	int table_width;
	struct td_params *td_params_array;	/* num_td elements */
	struct tr *tr;

};

struct html_page {
	char *title;
	char *pre_str;
	struct table *table;
	int num_tables;
	char *post_str;

	/* Processing related fields */
	int parse_flag;
	char **pp_out;		/* Points to the current buffer ptr */
	char title_done;
};

void draw_tr(struct table *table, int pos);
void draw_td(struct table *table, int pos);
int ifx_compute_td_params(struct table *table);
void draw_table(struct html_page *html_page, int table_id);
char *draw_html_page(struct html_page *page, int scr_width);

#endif				//end of #define __CLI_RENDER_H__
