
void wrap_up(void)
{
}

main()
{
	signal(SIGINT, wrap_up);
	while (1) {
		printf("Entering Menu\n");
		printf("enter cli title : ");
		scanf("%s", cli_title);
		printf("enter gui title : ");
		gets(gui_title);
		printf("enter gui url : ");
		scanf("%s", gui_url);
		printf("enter page help : ");
		gets(page_help);

		printf("Creating entries for %s\n", cli_title);
		printf("enter cli name : ");
		scanf("%s", cli_name);
		scanf("enter entry help : ");
		gets(entry_help);
		printf("enter 1 for command for %s\nenter 2 for page for %s\n",
		       cli_name);
		scanf("%d", &entry_ch);
		switch (entry_ch) {
		case 1:
			printf("Creating command with name %s\n", cli_name);
			printf("enter help : ");
			gets(help);
			printf("enter url : ");
			scanf("%s", post_url);
			printf("want to have fields ? 1 for yes : 0 for no\n");
			scanf("%d", &field_ch);
			if (field_ch == 1) {
				printf
				    ("Creating fields\nType 0 to quit any time\n");
				while (field_ch == 1) {
					printf("enter field name : ");
					scanf("%s", field_name);
					printf("enter data type : ");
					scanf("%s", data_type);
					printf("enter field type : ");
					scanf("%s", field_type);
					printf("is mandatory ? 1 or 0 : ");
					scanf("%d", &mandatory);
					printf("enter field help : ");
					gets(field_help);
					if (strcmpcase(field_type, "STATIC") ==
					    0) {
						printf
						    ("field type is STATIC, enter value set\n");
						while (field_ch == 1) {
							printf
							    ("enter field display value : ");
							scanf("%s",
							      display_value);
							printf
							    ("enter field submit value : ");
							scanf("%s",
							      submit_value);
							printf
							    ("continue ? 1 for yes 0 for no : ");
							scanf("%d", &field_ch);
						}
						field_ch = 1;
					}
				}
			}
