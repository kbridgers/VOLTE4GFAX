/* ============================================================================
 * Copyright (C) 2005 -Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 *============================================================================
 *
 * This document contains proprietary information belonging to Infineon 
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 * 
 * ============================================================================
 */

/* ===========================================================================
 *
 * File Name:   match.c
 * Author :     Ritesh Banerjee
 * Date: 		April, 2005
 *
 * ===========================================================================
 *
 * Project: Amazon
 *
 * ===========================================================================
 * Contents: This file implements regular expression library based parsing for
 * simple HTML, and converting that into page intermediate structure or field-
 * value pairs. The former allows the rendering engine to draw the command
 * output on the screen. The latter allows existing or preconfigured parameter
 * values to be retrieved from the HTML page received from the CLI backend.
 *  
 * ===========================================================================
 * References: 
 *
 * $Log$
 */
#include <sys/types.h>
#include <regex.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include "match.h"
#include "ifx_cli_render.h"

/*
 * Match string against the extended regular expression in
 * pattern, treating errors as no match.
 *
 * Return 1 for match, 0 for no match.
 */

regex_t g_topregex;
regex_t g_select_optionregex;

#define HTML_PROCESS_OUTPUT	0
#define HTML_PROCESS_FVSET	1
#define HTML_PROCESS_DATASTRUCT 2

#define DEBUG_MATCH   0

int g_html_process_mode;
int g_html_flag = 0;
int g_debug_flag = 1;

#define GET_SPOS(spos, pm)	((spos) + (pm)[0].rm_so)
#define GET_MATCH_EPOS(spos, pm)	((spos) + (pm)[0].rm_eo)

#if 0
#define IPRINTF(fmt, args...)	fprintf(stderr, "(%-20s) ", __FUNCTION__),fprintf(stderr, fmt, ##args)
#else
#define IPRINTF(fmt, args...)
#endif
#if 1
#define DPRINTF(fmt, args...)	fprintf(stderr, "(%-20s) ", __FUNCTION__),fprintf(stderr, fmt, ##args)
#else
#define DPRINTF(fmt, args...)

#endif
#if 0
#define XPRINTF(fmt, args...)	fprintf(stderr, fmt, ##args)
#else
#define XPRINTF(fmt, args...)

#endif

/*pass the out of memory bit [i.e., oom_bit = 1] in case of alloc failure*/

#define ERR_RETURN_ON_NULL(ptr, oom_bit)            \
{                                                   \
            if(!(ptr)) {                            \
                if((oom_bit))                       \
                    printf("\nOut Of Memory\n");    \
                return -1;                          \
            }                                       \
}

#define CMP_TOKEN_PREFIX(ptr, buf)	(!strncasecmp( 		\
			(ptr)->token_prefix_str, buf, strlen(buf)))

#define ALLOC_NEW_NODE(ptr, num)			\
	(num) = (num) + 1;				\
	(ptr) = realloc ((ptr), (num) * sizeof(*(ptr)));\
	memset(&(ptr)[num-1], 0x0, sizeof(*(ptr)));	\


#define GET_TABLE(phtml, tableindex)			\
	(tableindex)>0?&((phtml)->table[(tableindex) - 1]):0

#define GET_TR(ptable, trindex)				\
	(trindex)>0?&((ptable)->tr[(trindex) - 1]):0

#define GET_TD(ptr, tdindex)				\
	(tdindex)>0?&((ptr)->td[(tdindex) - 1]):0

#define GET_CURRENT_TD(phtml, ptd)			\
{							\
	struct td *t_td=NULL;				\
	struct tr *t_tr;				\
	struct table *t_tab;				\
	(ptd) = NULL;					\
	t_tab = GET_TABLE((phtml), (phtml)->num_tables);	\
	if (t_tab != NULL) {					\
	t_tr = GET_TR(t_tab, t_tab->num_tr);			\
		if (t_tr != NULL) {				\
		t_td = GET_TD(t_tr, t_tr->num_td);		\
		ptd = t_td;					\
		if ((phtml)->parse_flag != PARSE_TD) {		\
			DPRINTF("Can't get TD as not parsing TD!\n");	\
			ptd = NULL;				\
		}						\
		}						\
	}							\
}

#define GET_CURRENT_TR_TD(phtml,ptr, ptd)			\
{							\
	struct td *t_td=NULL;				\
	struct tr *t_tr;				\
	struct table *t_tab;				\
	(ptd) = NULL;					\
	t_tab = GET_TABLE((phtml), (phtml)->num_tables);	\
	if (t_tab != NULL) {					\
	t_tr = GET_TR(t_tab, t_tab->num_tr);			\
		if (t_tr != NULL) {				\
		ptr = t_tr;						\
		t_td = GET_TD(t_tr, t_tr->num_td);		\
		ptd = t_td;					\
		if ((phtml)->parse_flag != PARSE_TD) {		\
			DPRINTF("Can't get TD as not parsing TD!\n");	\
			ptd = NULL;				\
		}						\
		}						\
	}							\
}

#define GET_TABLE_MODE_STR(flag) 				\
	flag==PARSE_TABLE?"Table":flag==PARSE_TR?"TR":flag ==	\
		PARSE_TD?"TD":"Non-table tag"

#define MAX_REGEXP_TOKENS	20

#define SET_T_WIDTH(buf, len, width)				\
		if (buf[(len)-1] == '%') { 			\
			buf[(len)-1]='\0';			\
			(width) = -atoi(buf);			\
		} else {					\
			(width) = atoi(buf);			\
		}

/*
 * Match regexp patterns 
 */
#define PAT_ALNUM	"A-Z0-9"
#define PAT_SPCHR1	"!|#&-=+_%$():;~"
#define PAT_SPACE	" \t"
#define PAT_NL		"\n\r"
#define PAT_QUOTE	"'\""

#define PAT_HTML_BEG	">["
#define PAT_BOX_STAR	"]*"
#define PAT_BOX_PLUS	"]+"
#define PAT_BOX_OPEN	"["
#define PAT_HTML_END	"<"
#define PAT_TAG_BEG	"<"
#define PAT_TAG_END	">"

#define PAT_SPCHR3	"-"

/*#define PAT_HTML_TEXT	\
		PAT_HTML_BEG PAT_ALNUM PAT_SPCHR1 PAT_SPACE PAT_NL PAT_QUOTE \
		PAT_SPCHR3 PAT_BOX_STAR PAT_BOX_OPEN \
		PAT_ALNUM PAT_SPCHR1 PAT_QUOTE PAT_SPCHR3 PAT_BOX_PLUS PAT_BOX_OPEN\
		PAT_ALNUM PAT_SPCHR1 PAT_SPACE PAT_NL PAT_QUOTE \
		PAT_SPCHR3 PAT_BOX_STAR PAT_HTML_END*/
#define PAT_HTML_TEXT	">[^><]*<"

#define PAT_HTML_ATTRIB		\
		PAT_BOX_OPEN PAT_ALNUM PAT_SPCHR1 PAT_SPACE \
		PAT_NL PAT_QUOTE PAT_BOX_PLUS PAT_TAG_END

#if 1				/* [ Temp */
struct field_value_set {
	char *field_name;
	char *field_value;
};
#endif				/* ] Temp - take out ! */

struct field_value_set *pg_fvset;
int g_num_fields = 0;

struct html_page *pg_html = NULL;

struct html_token {
	char *token_regexp_str;
	char *token_prefix_str;
	int index;		/* leave 0, auto initialized */
	int (*fptr) (char *inbuf, char *outbuf, int spos, int *epos,
		     regmatch_t * pm, struct html_token * ptr);
#if 1
	regex_t token_regex;
	struct html_token *sub_token_array;
	void *private_data;
#endif
};

#define MAX_FIELD_LEN 1024

struct select_info {
	char select_name[MAX_FIELD_LEN];
	char option_val[MAX_FIELD_LEN];
	char match_val[MAX_FIELD_LEN];
	char *option_name;
	int size;
	unsigned int selected:1;
	unsigned int disabled:1;
};

struct select_info g_select_info;

#define INPUT_TYPE_RADIO	1
#define INPUT_TYPE_CHECKBOX	2
#define INPUT_TYPE_TEXT		3
#define INPUT_TYPE_BUTTON	4

#define PARSE_TABLE		1
#define PARSE_TR		2
#define PARSE_TD		3

struct input_info {
#if 0
	int input_type;
#else
	char input_type[MAX_FIELD_LEN];
#endif
	char input_name[MAX_FIELD_LEN];
	char *input_val;
	char match_val[MAX_FIELD_LEN];
	unsigned int checked:1;
	unsigned int hidden:1;
};
struct input_info g_input_info = {.input_val = 0 };

struct div_info {
	char id[MAX_FIELD_LEN];
	char match_val[MAX_FIELD_LEN];
};

struct div_info g_div_info;
void init_match_engine(void);

char *match_token_ex(char *inbuf, char *outbuf, int spos, int *epos, struct
		     html_token *p_token_array, regex_t * pregex,
		     regmatch_t * pm, size_t * pnum_pm);

int copy_bytes(char *inbuf, char *outbuf, int spos, int *epos,
	       regmatch_t * pm, struct html_token *ptr);
int copy_ds_bytes(char *inbuf, char *outbuf, int spos, int *epos,
		  regmatch_t * pm, struct html_token *ptr);
int copy_value_bytes(char *inbuf, char *outbuf, int spos, int *epos,
		     regmatch_t * pm, struct html_token *ptr);

int table_copy(char *inbuf, char *outbuf, int spos, int *epos,
	       regmatch_t * pm, struct html_token *ptr);
int table_end_copy(char *inbuf, char *outbuf, int spos, int *epos,
		   regmatch_t * pm, struct html_token *ptr);
int table_copy_bytes(char *inbuf, char *outbuf, int spos, int *epos,
		     regmatch_t * pm, struct html_token *ptr);
int
script_skip(char *inbuf, char *outbuf, int spos, int *epos,
	    regmatch_t * p_pm, struct html_token *ptr);
int
store_select_name(char *inbuf, char *outbuf, int spos, int *epos,
		  regmatch_t * p_pm, struct html_token *ptr);
int
store_select_size(char *inbuf, char *outbuf, int spos, int *epos,
		  regmatch_t * p_pm, struct html_token *ptr);
int
store_option_disabled(char *inbuf, char *outbuf, int spos, int *epos,
		      regmatch_t * p_pm, struct html_token *ptr);
int
process_option_value(char *inbuf, char *outbuf, int spos, int *epos,
		     regmatch_t * p_pm, struct html_token *ptr);
int
store_option_value(char *inbuf, char *outbuf, int spos, int *epos,
		   regmatch_t * p_pm, struct html_token *ptr);
int
store_option_name(char *inbuf, char *outbuf, int spos, int *epos,
		  regmatch_t * p_pm, struct html_token *ptr);

int
store_match_value(char *inbuf, char *outbuf, int spos, int *epos,
		  regmatch_t * p_pm, struct html_token *ptr);
int
selected_option_value(char *inbuf, char *outbuf, int spos, int *epos,
		      regmatch_t * p_pm, struct html_token *ptr);
int select_copy(char *inbuf, char *outbuf, int spos, int *epos,
		regmatch_t * pm, struct html_token *ptr);
int
store_input_name(char *inbuf, char *outbuf, int spos, int *epos,
		 regmatch_t * p_pm, struct html_token *ptr);

int
store_input_type(char *inbuf, char *outbuf, int spos, int *epos,
		 regmatch_t * p_pm, struct html_token *ptr);

int
store_input_value(char *inbuf, char *outbuf, int spos, int *epos,
		  regmatch_t * p_pm, struct html_token *ptr);

int
input_match_value(char *inbuf, char *outbuf, int spos, int *epos,
		  regmatch_t * p_pm, struct html_token *ptr);

int
checked_input_value(char *inbuf, char *outbuf, int spos, int *epos,
		    regmatch_t * p_pm, struct html_token *ptr);

int
hidden_input_value(char *inbuf, char *outbuf, int spos, int *epos,
		   regmatch_t * p_pm, struct html_token *ptr);

int input_copy(char *inbuf, char *outbuf, int spos, int *epos,
	       regmatch_t * pm, struct html_token *ptr);

int
div_copy(char *inbuf, char *outbuf, int spos, int *epos,
	 regmatch_t * p_pm, struct html_token *ptr);
int
token_to_end_token_skip(char *tagstr, char *inbuf, char *outbuf, int spos,
			int *epos, regmatch_t * p_pm, struct html_token *ptr);

int copy_html(char *inbuf, char *outbuf, int spos, int *epos,
	      regmatch_t * pm, struct html_token *ptr);

int copy_title(char *inbuf, char *outbuf, int spos, int *epos,
	       regmatch_t * pm, struct html_token *ptr);

int nbsp_copy(char *inbuf, char *outbuf, int spos, int *epos,
	      regmatch_t * pm, struct html_token *ptr);

int br_copy(char *inbuf, char *outbuf, int spos, int *epos,
	    regmatch_t * pm, struct html_token *ptr);
int p_copy(char *inbuf, char *outbuf, int spos, int *epos,
	   regmatch_t * pm, struct html_token *ptr);
int
store_div_id(char *inbuf, char *outbuf, int spos, int *epos,
	     regmatch_t * p_pm, struct html_token *ptr);
int
store_div_matchval(char *inbuf, char *outbuf, int spos, int *epos,
		   regmatch_t * p_pm, struct html_token *ptr);

struct html_token g_table_tokens[] = {
#if 1
	{"width[ ]*=[\"']([0-9]+[%]{0,1})[\"']", "width", -2, table_copy_bytes,
	 {0}, NULL, NULL},
	{"border[ ]*=[ ]*[\"']([0-9]+)[\"']", "border", -2, table_copy_bytes,
	 {0}, NULL, NULL},
#if 1
	{" align[ ]*=[ ]*[\"'](left|right|center)[\"']", " align", -2,
	 table_copy_bytes, {0}, NULL, NULL},
#else
	{"align=[\"']([leftrighcn]+)[\"']", "align", -2, table_copy_bytes, {0},
	 NULL, NULL},
#endif
	{"nowrap", "nowrap", -1, table_copy_bytes, {0}, NULL, NULL},
#endif
	{NULL, NULL, 0, NULL, {0}, NULL, NULL}
};

struct html_token g_option_tokens[] = {
	{"value=[\"']([0-9a-z_ :-]*)[\"']", "value", -2, store_option_value,
	 {0}, NULL, &g_select_info},
	{"value=([0-9a-z_:-]+)[ >]", "value", -2, store_option_value, {0}, NULL,
	 &g_select_info},
//      {"&nbsp", "&nbsp", -1, nbsp_copy, {0}, NULL, NULL},
	{"<br>", "<br>", -1, br_copy, {0}, NULL, NULL},
	{">([a-z0-9&+;:_.()\n\t\r -]+)</option[ ]*>", ">", -2,
	 store_option_name, {0}, NULL,
	 &g_select_info},
	{"matchval[ ]*=[ ]*[\"']([a-z0-9:$-_ ])+[\"']", "matchval", -2,
	 store_match_value, {0}, NULL, &g_select_info},
	{"selected", "selected", -1, selected_option_value, {0}, NULL,
	 &g_select_info},
	{"disabled", "disabled", -1, store_option_disabled, {0}, NULL,
	 &g_select_info},
	{NULL, NULL, 0, NULL, {0}, NULL, NULL}

};

#if 1
struct html_token g_select_tokens[] = {
	{"name=[\"']([a-z0-9_]+)[\"']", "name=", -2, store_select_name, {0},
	 NULL,
	 &g_select_info},

	{"size=[\"']([0-9]+)[\"']", "size=", -2, store_select_size, {0}, NULL,
	 &g_select_info},
	{NULL, NULL, 0, NULL, {0}, NULL, NULL}
};

struct html_token g_option_val_tokens[] = {
	{"<option[ a-z0-9#:_=\"';-]+>", "<option", -1, process_option_value,
	 {0}, g_option_tokens, &g_select_info},
	{NULL, NULL, 0, NULL, {0}, NULL, NULL}
};

struct html_token g_select_option_tokens[] = {
#if 0
	{"<option[ a-z0-9#:-_=\"']+>", "<option", process_option_value,
	 {0}, g_option_tokens, &g_select_info},
#else
	{"</SELECT[ ]*>", "</SELECT", -1, NULL,
	 {0}, g_option_val_tokens, &g_select_info},
#endif
	{NULL, NULL, 0, NULL, {0}, NULL, NULL}
};

struct html_token g_div_tokens[] = {
	{"id=[\"']([a-z0-9_]+)[\"']", "id=", -2, store_div_id, {0}, NULL,
	 &g_div_info},
	{"matchval=[\"']([0-9]+)[\"']", "matchval=", -2, store_div_matchval,
	 {0}, NULL, &g_div_info},
	{NULL, NULL, 0, NULL, {0}, NULL, NULL}
};

struct html_token g_input_tokens[] = {
	{"name=[\"']([a-z0-9_;:-_.]+)[\"']", "name=", -2, store_input_name, {0},
	 NULL,
	 &g_input_info},
	{"type=[\"'](radio|button|checkbox|text|hidden|password)[\"']", "type=",
	 -2,
	 store_input_type, {0}, NULL, &g_input_info},
	{"type=(radio|button|checkbox|text|hidden|password)[ >]", "type=", -2,
	 store_input_type, {0}, NULL, &g_input_info},
	{"value=[\"']([a-z0-9_ .-]*)[\"']", "value=", -2, store_input_value,
	 {0}, NULL,
	 &g_input_info},
	{"value=([a-z0-9_.-]+)[ >]", "value=", -2, store_input_value, {0}, NULL,
	 &g_input_info},
	{"matchval[ ]*=[ \\]*[\"']([a-z0-9:$-_ ]*)[\"']", "matchval", -2,
	 input_match_value, {0},
	 NULL, &g_input_info},
	{"checked", "checked", -1, checked_input_value, {0}, NULL,
	 &g_input_info},
//      {"hidden", "hidden", -1, hidden_input_value, {0}, NULL, &g_input_info},
	{NULL, NULL, 0, NULL, {0}, NULL, NULL}
};

#endif

#define STRNCPY(d, s, n)  strncpy((d), (s), (n)); (d)[n]='\0'
#if 1
#define STRNCAT(d, s, n) {				\
	int oldlen = 0;					\
	oldlen = strlen((d));				\
	strncat((d), (s), (n)); 			\
	(d)[oldlen + (n)] = '\0';			\
}

#else
#define STRNCAT(d, s, n)  strncat((d), (s), (n))
#endif

#define th_copy table_copy
#define tr_copy table_copy
#define td_copy table_copy
struct html_token g_html_token_array[] = {
	{"<HTML>", "<HTML>", -1, copy_html, {0}, NULL, NULL},
	{"</HTML>", "</HTML>", -1, copy_html, {0}, NULL, NULL},
	{"<TITLE>", "<TITLE", -1, copy_title, {0}, NULL, NULL},
	{"</TITLE>", "</TITLE>", -1, copy_title, {0}, NULL, NULL},
	{"<TABLE[ A-Z0-9#=%:_\"']*>", "<TABLE", -1, table_copy, {0},
	 g_table_tokens, NULL},
	{"<TH[ A-Z0-9#=%:_\"']*>", "<TH", -1, th_copy, {0}, g_table_tokens,
	 NULL},
	{"<TR[ A-Z0-9#=%:_\"']*>", "<TR", -1, tr_copy, {0}, g_table_tokens,
	 NULL},
	{"<TD[ A-Z0-9#=%:_\"']*>", "<TD", -1, td_copy, {0}, g_table_tokens,
	 NULL},
	{"</TABLE>", "</TABLE>", -1, table_end_copy, {0}, NULL, NULL},
	{"</TR>", "</TR>", -1, table_end_copy, {0}, NULL, NULL},
	{"</TH>", "</TH>", -1, table_end_copy, {0}, NULL, NULL},
	{"</TD>", "</TD>", -1, table_end_copy, {0}, NULL, NULL},
	{"<P>", "<P>", -1, p_copy, {0}, NULL, NULL},
#if 0
	{"<SCRIPT[ A-Z0-9#=%:_\"']*>", "<SCRIPT", -1, script_skip, {0}, NULL,
	 NULL},
	{"<SELECT[ A-Z0-9#=%:_();\"']+>", "<SELECT", -1, select_copy, {0},
	 g_select_tokens, &g_select_info},
	{"<INPUT[ A-Z0-9#=%:_\"'.-]+>", "<INPUT", -1, input_copy, {0},
	 g_input_tokens, &g_input_info},
#else
	{"<SCRIPT" PAT_HTML_ATTRIB, "<SCRIPT", -1, script_skip, {0}, NULL,
	 NULL},
	{"<SELECT" PAT_HTML_ATTRIB, "<SELECT", -1, select_copy, {0},
	 g_select_tokens, &g_select_info},
	{"<INPUT" PAT_HTML_ATTRIB, "<INPUT", -1, input_copy, {0},
	 g_input_tokens, &g_input_info},

#endif
	{"<DIV[ A-Z0-9#=%:_\"']+>", "<DIV", -1, div_copy, {0}, g_div_tokens,
	 &g_div_info},
	{"<br>", "<br>", -1, br_copy, {0}, NULL, NULL},
#if 0
	{"&nbsp;", "&nbsp;", -1, nbsp_copy, {0}, NULL, NULL},
	/* Error in the HTML */
#endif
#if 0
	{">[A-Z0-9!|#&-=+_%$() \t\n\r.;]*[A-Z0-9!|#&-=+_%$().]+[A-Z0-9!|#&-=+_%$() \t\n\r.;]*<", ">", -1, copy_value_bytes, {0}, NULL, NULL},	/* May require
																		   to take into account more complex embedded stuff */
#else
	{PAT_HTML_TEXT, ">", -1, copy_value_bytes, {0}, NULL, NULL},
#endif
	{NULL, NULL, 0, NULL, {0}, NULL}
};

int g_nest_level = 0;

int remove_non_html_chars(char *buf, char *rem_str)
{
	char *pend, *pstart;
	int num_rep = 0;
	int pos = 0;
	int i = 0;

	pstart = buf;
	pend = strlen(buf) + buf;
	while (buf < pend) {
		pos = strcspn(buf, rem_str);
		buf += pos;
		pos = strspn(buf, rem_str);
		if (buf < pend) {
			if ((pstart != buf) && (buf[pos] != '\0')) {
				*buf = ' ';	/* Browsers replace with single space */
				i = 1;
			} else {
				i = 0;
			}
			memmove(buf + i, buf + pos, pend - buf - pos);
			num_rep += pos;
			pend -= (pos - i);
			*(pend) = '\0';
		}
	}
	DPRINTF("# subs <%d>\n", num_rep);
	return (num_rep);
}

int replace_special_str(char *buf, char *find_str, char *rep_str)
{
	int num_rep = 0;
	int lenf = 0;
	int lenr = 0;
	char *pend;

	lenf = strlen(find_str);
	lenr = strlen(rep_str);
	pend = strlen(buf) + buf;

	if (lenr > lenf) {
		/* XXX: Do realloc later if rep_str larger than find_str */
		/*      Currently, we don't need this support */
		DPRINTF("Currently rep str can't be larger than find str!\n");
		return -1;
	}
	DPRINTF("to replace [%s] special str !\n", find_str);
	while (buf) {
		buf = strstr(buf, find_str);
		if (buf) {
			memcpy(buf, rep_str, lenr);	/* write rep_str */
			memmove(buf + lenr, buf + lenf, pend - buf - lenf);
			buf += lenr;
			pend -= (lenf - lenr);	/* lenf reduced, lenr increased
						 */
			*(pend) = '\0';	/* keep NULL terminating :-) */
		}
	}
	DPRINTF("# subs <%d>\n", num_rep);
	return (num_rep);
}

int find_entries_token_array(struct html_token *array)
{
	struct html_token *p = &array[0];
	int count = 0;

	while (p->token_regexp_str && p->token_regexp_str[0] != '\0') {
		count++;
		p++;
	}
	DPRINTF("Found <%d> entries in <%p:%s> array!\n", count, array,
		array[0].token_prefix_str);

	return count;
}

int init_tok_engine(struct html_token *array, regex_t * regexp)
{
	char pattern[2000];
	int i = 0;
	int j = 0;
	int index = 1;
	struct html_token *p;

	if (array == NULL) {
		return 0;
	}
	p = &array[0];
	DPRINTF("Before find_entries_token_array for <%p:%s>\n", array,
		array[0].token_regexp_str);
	j = find_entries_token_array(array);
	pattern[0] = '\0';
	for (i = 0; i < j; i++, p++) {
		strcat(pattern, p->token_regexp_str);
		if (i < (j - 1)) {
			strcat(pattern, "|");
		}
		if (p->index >= 0) {
			continue;	/* already init */
		}
		if (p->index == -2) {
			p->index = index;	/* save this entry's index inside the
						   entry aka this ptr */
			index++;
		} else {
			p->index = 0;	/* only 1 match element */
		}
		DPRINTF("pattern : [%s] - Index [%d]\n",
			p->token_prefix_str, p->index);
		/* Recurse to handle child arrays */
		init_tok_engine(p->sub_token_array, &p->token_regex);
	}

	if ((j =
	     regcomp(regexp, pattern,
		     REG_EXTENDED | REG_ICASE /*|REG_NOSUB */ )) != 0) {
		IPRINTF("Pattern compile error [%d]!\n", j);
		return (-1);	/* Report error. */
	}

	IPRINTF("Pattern successfully compiled for array <%p>\n\n<%s>!\n",
		array, pattern);

	return (0);
}

int copy_bytes(char *inbuf, char *outbuf, int spos, int *epos,
	       regmatch_t * pm, struct html_token *ptr)
{
	int eff_spos;
	int len;

	eff_spos = GET_SPOS(spos, pm);
	len = *epos - eff_spos;

	DPRINTF("\n==============<<<<  copy_bytes spos[%d:%ld], epos[%d]\n",
		spos, (ulong) eff_spos, *epos);
	DPRINTF("outbuf [%s]\n", outbuf);
	STRNCAT(outbuf, inbuf + eff_spos, len);
	DPRINTF("outbuf [%s]\n", outbuf);

//lbl_ahead:
	return (*epos - GET_SPOS(spos, pm));
}

int copy_ds_bytes(char *inbuf, char *outbuf, int spos, int *epos,
		  regmatch_t * pm, struct html_token *ptr)
{
	int eff_spos;
	int len;
	int oldlen;

	eff_spos = GET_SPOS(spos, pm);
	len = *epos - eff_spos;
	DPRINTF(" copying [%d] bytes from [%d]!\n", len, eff_spos);

	if (g_html_process_mode == HTML_PROCESS_DATASTRUCT) {
		if (!*(pg_html->pp_out)) {
			DPRINTF(" No buffer ptr set to copy ! Skipping\n");
			return 0;
		}
		oldlen = strlen(*(pg_html->pp_out));
		*(pg_html->pp_out) = realloc(*(pg_html->pp_out),
					     len + oldlen + 1);
		if (*(pg_html->pp_out) == NULL) {
			DPRINTF("Out of memory !\n");
			return -1;
		}

		copy_bytes(inbuf, *(pg_html->pp_out), spos, epos, pm, ptr);
	}
	return (*epos - GET_SPOS(spos, pm));
}

int copy_value_bytes(char *inbuf, char *outbuf, int spos, int *epos,
		     regmatch_t * pm, struct html_token *ptr)
{
	int ret = 0;

	(*epos)--;
#ifdef DEBUG_MATCH
	if (g_debug_flag == 1) {
		DPRINTF("copy_value_bytes: spos+1<%d:%d>, epos<%d>\n", spos + 1,
			GET_SPOS(spos + 1, pm), *epos);
		DPRINTF("inbuf at match [%s]!\n",
			inbuf + GET_SPOS(spos + 1, pm));
		ret = (copy_bytes(inbuf, outbuf, spos + 1, epos, pm, ptr));
	}
#endif
	if (g_html_process_mode == HTML_PROCESS_DATASTRUCT) {
		if ((pg_html->pp_out == NULL)
		    || ((pg_html->pp_out && *pg_html->pp_out == NULL)
			&& (pg_html->title_done || pg_html->pre_str))) {
			DPRINTF("\n\n******** Error : Null pp_out *********\n");
		} else {
			int len = 0;

			if (*pg_html->pp_out) {
				len = strlen(*pg_html->pp_out);
			} else {
				pg_html->pp_out = &pg_html->pre_str;
				*pg_html->pp_out = calloc(1, 1);
			}
			ret =
			    (copy_ds_bytes
			     (inbuf, *(pg_html->pp_out), spos + 1, epos, pm,
			      ptr));
			/* Need to weed out all '\n' and '\t' from the buffer */
			remove_non_html_chars((*pg_html->pp_out) + len,
					      "\r\n\t");
			replace_special_str((*pg_html->pp_out) + len, "&nbsp;",
					    " ");
		}
	}
	(*epos)++;
	DPRINTF("Outbuf [%s]!\n", outbuf);
	return (ret);
}

int copy_title(char *inbuf, char *outbuf, int spos, int *epos,
	       regmatch_t * pm, struct html_token *ptr)
{
	if (g_html_process_mode == HTML_PROCESS_DATASTRUCT) {
		if (CMP_TOKEN_PREFIX(ptr, "<TITLE")) {
			if (pg_html->title_done == 0) {
				/* make a 1 byte buffer to reassure copy_bytes */
				pg_html->title = calloc(1, 1);
				pg_html->pp_out = &(pg_html->title);
			}
		}
		if (CMP_TOKEN_PREFIX(ptr, "</TITLE")) {
			if (pg_html->title_done == 0) {
				pg_html->title_done = 1;
				/* make a 1 byte buffer to reassure copy_bytes */
#if 0
				/* XXX : Nirav. This is not required as done at HTML tag only */
				pg_html->pre_str = calloc(1, 1);
#endif
				pg_html->pp_out = &(pg_html->pre_str);
			}
		}
	}
#ifdef DEBUG_MATCH
	if (g_debug_flag == 1) {
		return (copy_bytes(inbuf, outbuf, spos, epos, pm, ptr));
	}
#endif

	return (0);		/* no bytes copied */
}

int copy_html(char *inbuf, char *outbuf, int spos, int *epos,
	      regmatch_t * pm, struct html_token *ptr)
{
	g_html_flag = 1;	/* Now we are all set to process HTML ! */

	if (g_html_process_mode == HTML_PROCESS_DATASTRUCT) {
		/* XXX: Nirav. This is to ensure handling of <p> without <title> */
		/* make a 1 byte buffer to reassure copy_bytes */
		if (CMP_TOKEN_PREFIX(ptr, "<HTML>")) {
			pg_html->pre_str = calloc(1, 1);
			pg_html->pp_out = &(pg_html->pre_str);
		}
		return (0);	/* just skip */
	} else {
		return (copy_bytes(inbuf, outbuf, spos, epos, pm, ptr));
	}

}

int table_copy(char *inbuf, char *outbuf, int spos, int *epos,
	       regmatch_t * pm, struct html_token *ptr)
{
	char *string = inbuf;
	regmatch_t lpm[MAX_REGEXP_TOKENS];
	int eff_spos = 0;
	int num = 0;
	struct table *ptab;
	struct tr *p_tr;
	struct td *ptd;

	eff_spos = GET_SPOS(spos, pm);

#ifdef DEBUG_MATCH
	if (g_debug_flag == 1) {
		DPRINTF("outbuf [%s]\n", outbuf);
		strcat(outbuf, ptr->token_prefix_str);
		DPRINTF("outbuf [%s]\n", outbuf);
		{
			char buf[1000];

			STRNCPY(buf, inbuf + eff_spos, *epos - eff_spos);
			DPRINTF("Temp buf [%s]\n", buf);

		}
	}
#endif

	if (g_html_process_mode == HTML_PROCESS_DATASTRUCT) {
		if (CMP_TOKEN_PREFIX(ptr, "<TABLE")) {
			/* Create a table node */
			ALLOC_NEW_NODE(pg_html->table, pg_html->num_tables);
//                      pg_html->pp_out = NULL; /* No str is allowed here */
			if (!pg_html->table) {
				DPRINTF("(%s) Error - Out of memory allocating "
					"table !\n", __FUNCTION__);
				return -1;
			}
			pg_html->parse_flag = PARSE_TABLE;
		} else if (CMP_TOKEN_PREFIX(ptr, "<TR")) {
			/* Create a TR node */
			ptab = GET_TABLE(pg_html, pg_html->num_tables);

			ERR_RETURN_ON_NULL(ptab, 1);

			ALLOC_NEW_NODE(ptab->tr, ptab->num_tr);

			if (!ptab->tr) {
				DPRINTF("(%s) Error - Out of memory allocating "
					"tr !\n", __FUNCTION__);
				return -1;
			}
			ptab->tr[ptab->num_tr - 1].params.align = -1;
			pg_html->parse_flag = PARSE_TR;
		} else if (CMP_TOKEN_PREFIX(ptr, "<TH")) {
			/* Create a TD with special attributes */
			ptab = GET_TABLE(pg_html, pg_html->num_tables);

			ERR_RETURN_ON_NULL(ptab, 0);

			p_tr = GET_TR(ptab, ptab->num_tr);

			ERR_RETURN_ON_NULL(p_tr, 0);

			ALLOC_NEW_NODE(p_tr->td, p_tr->num_td);
			if (!p_tr->td) {
				DPRINTF("(%s) Error - Out of memory allocating "
					"td !\n", __FUNCTION__);
				return -1;
			}
			pg_html->parse_flag = PARSE_TD;
			p_tr->th = 1;	/* Mark as table header */
			ptd = GET_TD(p_tr, p_tr->num_td);

			ERR_RETURN_ON_NULL(ptd, 0);

			ptd->str = calloc(1, 1);	/* make a 1 byte buffer to
							   reassure copy_bytes */
			pg_html->pp_out = &ptd->str;
		} else if (CMP_TOKEN_PREFIX(ptr, "<TD")) {
			/* Create a TD */
			ptab = GET_TABLE(pg_html, pg_html->num_tables);
			ERR_RETURN_ON_NULL(ptab, 0);
			p_tr = GET_TR(ptab, ptab->num_tr);
			ERR_RETURN_ON_NULL(p_tr, 0);
			ALLOC_NEW_NODE(p_tr->td, p_tr->num_td);
			if (!p_tr->td) {
				DPRINTF("(%s) Error - Out of memory allocating "
					"td !\n", __FUNCTION__);
				return -1;
			}
			pg_html->parse_flag = PARSE_TD;
			ptd = GET_TD(p_tr, p_tr->num_td);
			ERR_RETURN_ON_NULL(ptd, 0);
			pg_html->pp_out = &ptd->str;
			ptd->str = calloc(1, 1);	/* make a 1 byte buffer to
							   reassure copy_bytes */
			ptd->params.align = -1;
		} else {
			DPRINTF("Unknown table token [%s]\n",
				ptr->token_prefix_str);
			return -1;
		}
	}

	while (*epos > eff_spos) {
		num = MAX_REGEXP_TOKENS;
		if (match_token_ex(string, outbuf, eff_spos, epos,
				   ptr->sub_token_array,
				   &ptr->token_regex, lpm,
				   (size_t *) & num) == NULL) {

			DPRINTF("(%s) - match_token_ex returned NULL!\n",
				__FUNCTION__);
			break;
		}
		eff_spos = GET_MATCH_EPOS(eff_spos, lpm);

	}

#ifdef DEBUG_MATCH
	strcat(outbuf, ">");
	DPRINTF("outbuf [%s]\n", outbuf);
#endif
	return (0);
}

int table_end_copy(char *inbuf, char *outbuf, int spos, int *epos,
		   regmatch_t * pm, struct html_token *ptr)
{
	if (g_html_process_mode == HTML_PROCESS_DATASTRUCT) {
		if (CMP_TOKEN_PREFIX(ptr, "</TABLE")) {
			if (pg_html->parse_flag != PARSE_TABLE) {
				DPRINTF("(%s) Error - Found </TABLE> with"
					"parse_flag<%d>\n",
					__FUNCTION__, pg_html->parse_flag);
				return -1;
			}
			pg_html->parse_flag = 0;
			if (pg_html->post_str == NULL) {
				pg_html->post_str = calloc(1, 1);	/* make a 1 byte buffer */
			}
			(pg_html->pp_out) = &pg_html->post_str;

		}
		if (CMP_TOKEN_PREFIX(ptr, "</TR")) {
			if (pg_html->parse_flag != PARSE_TR) {
				DPRINTF("(%s) Error - Found </TR> with"
					"parse_flag<%d>\n",
					__FUNCTION__, pg_html->parse_flag);
				return -1;
			}
			pg_html->parse_flag = PARSE_TABLE;

		}
		if (CMP_TOKEN_PREFIX(ptr, "</TD") ||
		    CMP_TOKEN_PREFIX(ptr, "</TH")) {
			if (pg_html->parse_flag != PARSE_TD) {
				DPRINTF("(%s) Error - Found </TD|TH> with"
					"parse_flag<%d>\n",
					__FUNCTION__, pg_html->parse_flag);
				return -1;
			}
			pg_html->parse_flag = PARSE_TR;
			(pg_html->pp_out) = NULL;
		}
	}
#ifdef DEBUG_MATCH
	if (g_debug_flag == 1) {
		copy_bytes(inbuf, outbuf, spos, epos, pm, ptr);
	}
#endif
	return (*epos - spos);	/* Check this later */
}

int get_align_val(char *buf)
{
	if (!strcasecmp(buf, "left")) {
		return ALIGN_LEFT;
	}
	if (!strcasecmp(buf, "right")) {
		return ALIGN_RIGHT;
	}
	if (!strcasecmp(buf, "center")) {
		return ALIGN_CENTER;
	}

	return -1;
}

int table_copy_bytes(char *inbuf, char *outbuf, int spos, int *epos,
		     regmatch_t * pm, struct html_token *ptr)
{
	char buf[512];
	char *string = inbuf;
	struct td *p_td;
	struct tr *p_tr = NULL;
	int len;
	int i;
	int eff_spos;
	int ret = 0;

	i = ptr->index;

#ifdef DEBUG_MATCH
	if (g_debug_flag == 1) {
		eff_spos = GET_SPOS(spos, pm);
		strcat(outbuf, " ");
		STRNCAT(outbuf, string + eff_spos, *epos - eff_spos);
		DPRINTF("table_copy_bytes : %s - [%s] \n",
			ptr->token_prefix_str, outbuf);
		IPRINTF("table_copy_bytes : %s \n", ptr->token_prefix_str);
	}
#endif

	if (g_html_process_mode == HTML_PROCESS_DATASTRUCT) {
		eff_spos = GET_SPOS(spos, &pm[i]);
		len = pm[i].rm_eo - pm[i].rm_so;
		STRNCPY(buf, string + eff_spos, len);

		GET_CURRENT_TR_TD(pg_html, p_tr, p_td);
		if (CMP_TOKEN_PREFIX(ptr, "width")) {
			if (pg_html->parse_flag == PARSE_TABLE) {
				struct table *p_table;
				p_table =
				    GET_TABLE(pg_html, pg_html->num_tables);
				if (p_table == NULL) {
					ret = -1;
					goto lbl_ret;
				}
				SET_T_WIDTH(buf, len, p_table->table_width);
				DPRINTF("TABLE WIDTH=%d\n",
					p_table->table_width);
			} else if (pg_html->parse_flag == PARSE_TD) {
				if (p_td == NULL) {
					ret = -1;
					goto lbl_ret;
				}
				SET_T_WIDTH(buf, len, p_td->params.width);
				DPRINTF("TD WIDTH=%d\n", p_td->params.width);
			}
		} else if (CMP_TOKEN_PREFIX(ptr, " align")) {
			char *p_align = NULL;
			struct table *p_table;
			if (pg_html->parse_flag == PARSE_TABLE) {
				p_table =
				    GET_TABLE(pg_html, pg_html->num_tables);
				if (p_table == NULL) {
					ret = -1;
					goto lbl_ret;
				}

				p_align = &(p_table->align);
				DPRINTF("TABLE");
			} else if (pg_html->parse_flag == PARSE_TR) {
				if (p_tr == NULL) {
					ret = -1;
					goto lbl_ret;
				}
				p_align = &(p_tr->params.align);
				DPRINTF("TR");
			} else if (pg_html->parse_flag == PARSE_TD) {
				if (p_td == NULL) {
					ret = -1;
					goto lbl_ret;
				}
				p_align = &(p_td->params.align);
				DPRINTF("TD");
			}
			if (p_align) {
				if (*p_align) {
					*p_align = get_align_val(buf);
					DPRINTF(" Align=[%d:%s]\n", *p_align,
						buf);
				}
			}
		} else if (CMP_TOKEN_PREFIX(ptr, "border")) {
			struct table *ptab;

			ptab = GET_TABLE(pg_html, pg_html->num_tables);
			if (ptab == NULL) {
				ret = -1;
				goto lbl_ret;
			}
			ptab->border = atoi(buf);
			DPRINTF("TABLE Border=[%d:%s]\n", ptab->border, buf);
		} else if (!strcasecmp(buf, "nowrap")) {
			if (p_td == NULL) {
				ret = -1;
				goto lbl_ret;
			}
			p_td->params.nowrap = 1;
			DPRINTF("TD nowrap=[%d]\n", p_td->params.nowrap);
		}
	}
	ret = 0;

      lbl_ret:
	if (ret < 0) {
		DPRINTF(" Table Mode : [%s]; Processing failed !\n",
			GET_TABLE_MODE_STR(pg_html->parse_flag));
	}

	return (ret);
}

#if 1
int select_copy(char *inbuf, char *outbuf, int spos, int *epos,
		regmatch_t * pm, struct html_token *ptr)
{
	regmatch_t lpm[MAX_REGEXP_TOKENS];
	size_t num_lpm = MAX_REGEXP_TOKENS;
	char *p, *p_new;
	int ret;
	int endpos = 0;
	int eff_spos = 0;

	eff_spos = GET_SPOS(spos, pm);
	memset(&g_select_info, 0x0, sizeof(g_select_info));
	g_select_info.size = 1;	/* XXX: MUST do since we have strict check */

#ifdef DEBUG_MATCH
	if (g_debug_flag == 1) {
		strcat(outbuf, ptr->token_prefix_str);

		DPRINTF("spos<%d>, *epos<%d>\n", eff_spos, *epos);

		DPRINTF("in select_copy !\n");
	}
#endif

	endpos = *epos;		/* init */
	while (*epos > eff_spos) {
		memset(lpm, 0x0, sizeof(lpm));
		DPRINTF("spos <%d>\n", eff_spos);

		if ((p_new = match_token_ex(inbuf, outbuf, eff_spos, &endpos,
					    ptr->sub_token_array,
					    &(ptr->token_regex), lpm,
					    &num_lpm)) == NULL) {
			DPRINTF("(%s) match_token_ex returned NULL\n",
				__FUNCTION__);
			break;
		}
		num_lpm = MAX_REGEXP_TOKENS;	/* reinit for next pass */
		DPRINTF("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n\n");
		DPRINTF("Token found at lpm[0].rm_so<%ld>, lpm[0].rm_eo<%ld>\n",
			(ulong) lpm[0].rm_so, (ulong) lpm[0].rm_eo);
		DPRINTF("spos <%d>, endpos <%d>, *epos <%d>!\n",
			eff_spos, endpos, *epos);
		eff_spos = GET_MATCH_EPOS(eff_spos, lpm);
	}
#ifdef DEBUG_MATCH
	if (g_debug_flag == 1) {
		strcat(outbuf, ">");
	}
#endif
	/* Now we need to find out the <OPTION> statements 
	 * Note that this is not linked in to the g_select_tokens directly
	 * The problem is that OPTION statements are not attributes of a
	 * SELECT tag. However, we want to process all <OPTION> tags inside
	 * a SELECT block together. This seems to be one way
	 */
	DPRINTF("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n"
		": in select_copy going for option matching !\n");
	p = inbuf;
	eff_spos = endpos;
	DPRINTF("inbuf: [%s]\n", p);
	if ((ret =
	     regexec(&g_select_optionregex, p + eff_spos, (size_t) 1, &lpm[0],
		     0)) != 0) {
		/* Searching for </SELECT> */
		DPRINTF("End matching regexp ! Error<%d>\n", ret);
		DPRINTF("</SELECT> not found for <SELECT>!\n");
		return -1;
		//goto lbl_ahead;
	}

	DPRINTF("lpm <%ld:%ld>!\n", (ulong) lpm[0].rm_so, (ulong) lpm[0].rm_eo);
	endpos = endpos + lpm[0].rm_eo;	/* recalibrate epos */
	DPRINTF("YYYYYYYYYYYYYYYYYYYYYYYYY\n\n\n"
		"*epos:endpos <%d:%d>!\n", *epos, endpos);

	*epos = endpos;		/* bump the epos passed forward */

	DPRINTF("XXX: in select_copy going for option matching !\n");

	while (endpos > eff_spos) {
		struct select_info *q;
		q = (struct select_info *)ptr->private_data;
		memset(lpm, 0x0, sizeof(lpm));

		num_lpm = MAX_REGEXP_TOKENS;	/* reinit for next pass */
		/* Reset all option related params */
		if (q->option_name) {
			free(q->option_name);
			q->option_name = NULL;
		}
		q->selected = 0;
		q->disabled = 0;
		q->option_val[0] = '\0';
		q->match_val[0] = '\0';
		/* end of reset option related params */

		if ((p_new = match_token_ex(p, outbuf, eff_spos, &endpos,
					    g_option_val_tokens,
					    &g_select_option_tokens->
					    token_regex, lpm,
					    &num_lpm)) == NULL) {
			ret = -1;
			DPRINTF("ZZZZ: match_token_ex failed for"
				"g_option_val_tokens!\n");
			break;
		}
		eff_spos = GET_MATCH_EPOS(eff_spos, lpm);

		{

			if (g_debug_flag == 1) {
				DPRINTF
				    ("========================SELECT INFO====================\n");
				DPRINTF("\tSelect Name\t:%s\n", q->select_name);
				DPRINTF("\tOption Name\t:%s\n", q->option_name);
				DPRINTF("\tOption Val\t:%s\n", q->option_val);
				DPRINTF("\tMatch Value\t:%s\n", q->match_val);
				DPRINTF("\tSelect Size\t:%d\n", q->size);
				DPRINTF("\tSelected\t:%s\n",
					q->selected ? "YES" : "NO");
				DPRINTF("\tDisabled\t:%s\n",
					q->disabled ? "YES" : "NO");
			}

			if (g_html_process_mode == HTML_PROCESS_FVSET) {
				struct field_value_set *ptr;

				if (q->match_val[0] != '\0') {
					if (strcmp(q->match_val, q->option_val)) {
						goto lbl_skip;
					}
				}
				if (q->size == 1 && q->selected == 0) {
					goto lbl_skip;
				}
				if (q->disabled) {
					goto lbl_skip;
				}

				ALLOC_NEW_NODE(pg_fvset, g_num_fields);

				if (pg_fvset == NULL) {
					DPRINTF("Out of memory !\n");
					return -1;
				}

				ptr = &pg_fvset[g_num_fields - 1];

				ptr->field_name = calloc(1,
							 strlen(q->
								select_name) +
							 1);
				ptr->field_value =
				    calloc(1, strlen(q->option_val) + 1);

				if (!ptr->field_name || !ptr->field_value) {
					DPRINTF
					    ("select_copy : Out of memory !\n");
					if (ptr->field_name)
						free(ptr->field_name);
					if (ptr->field_value)
						free(ptr->field_value);
					return -1;
				}
				strcpy(ptr->field_name, q->select_name);
				strcpy(ptr->field_value, q->option_val);

			} else if (g_html_process_mode ==
				   HTML_PROCESS_DATASTRUCT) {
				regmatch_t t_pm = { 0 };
				char tmp_str[10] = { 0 };
				int tmp_len = 7;
				if (q->match_val[0] != '\0') {
					if (strcmp(q->match_val, q->option_val)) {
						goto lbl_skip;
					}
				}
				if (q->size == 1 && q->selected == 0) {
					goto lbl_skip;
				}
				/* Copy the text between <option>...</option> */
				if (q->option_name) {
					tmp_len = strlen(q->option_name);
					copy_ds_bytes(q->option_name, NULL, 0,
						      &tmp_len, &t_pm, ptr);
					if ((q->size > 1) && (q->disabled == 0)) {
						tmp_len = 7;
						if (q->selected) {
							strcat(tmp_str,
							       " ( x ) ");
						} else {
							strcat(tmp_str,
							       " (   ) ");
						}
						copy_ds_bytes(tmp_str, NULL, 0,
							      &tmp_len, &t_pm,
							      ptr);
					}
				}
			}
			/* Reinit the option related members in the struct */
		}
	      lbl_skip:
		DPRINTF(" ~~~~~~~~~~~~~~~~~~~~ ==> Endpos:*epos <%d:%d>\n",
			endpos, *epos);

	}

#ifdef DEBUG_MATCH
	if (g_debug_flag == 1) {
		strcat(outbuf, ">");
	}
#endif
	*epos = endpos;
	return (0);
}
#endif

int
store_select_name(char *inbuf, char *outbuf, int spos, int *epos,
		  regmatch_t * p_pm, struct html_token *ptr)
{
	struct select_info *p;
	int eff_spos;
	int index = ptr->index;

	eff_spos = GET_SPOS(spos, &p_pm[index]);

	p = (struct select_info *)ptr->private_data;

	DPRINTF("pat_spos [%d]; *epos [%d] !\n", eff_spos, *epos);
	STRNCPY(p->select_name, inbuf + eff_spos,
		p_pm[index].rm_eo - p_pm[index].rm_so);
	DPRINTF("===>Select Name : %s\n", p->select_name);

	return 0;

}

int
store_input_name(char *inbuf, char *outbuf, int spos, int *epos,
		 regmatch_t * p_pm, struct html_token *ptr)
{
	struct input_info *p;
	int eff_spos;
	int index = ptr->index;

	eff_spos = GET_SPOS(spos, &p_pm[index]);

	p = (struct input_info *)ptr->private_data;

	DPRINTF("pat_spos [%d]; *epos [%d] !\n", eff_spos, *epos);
	STRNCPY(p->input_name, inbuf + eff_spos,
		p_pm[index].rm_eo - p_pm[index].rm_so);
	DPRINTF("===>Input Name : %s\n", p->input_name);

	return 0;
}

int
store_input_type(char *inbuf, char *outbuf, int spos, int *epos,
		 regmatch_t * p_pm, struct html_token *ptr)
{
	struct input_info *p;
	int eff_spos;
	int index = ptr->index;

	eff_spos = GET_SPOS(spos, &p_pm[index]);

	p = (struct input_info *)ptr->private_data;

	DPRINTF("index[%d] pat_spos [%d]; *epos [%d] !\n", index, eff_spos,
		*epos);
	DPRINTF("===>Input Buf at input_type : [%s]\n", inbuf + eff_spos);
	STRNCPY(p->input_type, inbuf + eff_spos,
		p_pm[index].rm_eo - p_pm[index].rm_so);
	DPRINTF("===>Input Type : %s\n", p->input_type);

	if (!strcasecmp(p->input_type, "HIDDEN")) {
		p->hidden = 1;
		DPRINTF(" Hidden element [%s]\n", p->input_name);
	}
#ifdef DEBUG_MATCH
	/* If HTML Output */
	{

	}
#endif

	return 0;
}

int
store_input_value(char *inbuf, char *outbuf, int spos, int *epos,
		  regmatch_t * p_pm, struct html_token *ptr)
{
	struct input_info *p;
	int eff_spos;
	int index = ptr->index;
	int len = 0;

	DPRINTF(" spos <%d> rm_so[%ld], rm_eo[%ld]\n", spos,
		(ulong) p_pm[index].rm_so, (ulong) p_pm[index].rm_eo);

	eff_spos = GET_SPOS(spos, &p_pm[index]);

	p = (struct input_info *)ptr->private_data;

	DPRINTF("pat_spos [%d]; *epos [%d] !\n", eff_spos, *epos);
	if (p && p->input_val) {
		free(p->input_val);
		p->input_val = NULL;
	}
	len = p_pm[index].rm_eo - p_pm[index].rm_so;
	if (len < 0) {
		DPRINTF("(%s) len[%d] of match < 0! Error !\n", __FUNCTION__,
			len);
		DPRINTF("spos [%d]; *epos [%d] !\n", spos, *epos);
		DPRINTF("pm.spos [%ld]; pm.epos [%ld] !\n",
			(ulong) p_pm[index].rm_so, (ulong) p_pm[index].rm_eo);
		DPRINTF("inbuf[spos] : [%s]\n", &inbuf[spos]);
		DPRINTF("Index : [%d] \n", index);
		return -1;
	}

	if (!p) {
		return -1;
	}

	p->input_val = calloc(len + 2, 1);

	if (!p->input_val) {
		DPRINTF("store_input_value: Out of Memory error !\n");
		return -1;
	}

	STRNCPY(p->input_val, inbuf + eff_spos, len);
	DPRINTF("===>Input value : %s\n", p->input_val);

	return 0;
}

int
input_match_value(char *inbuf, char *outbuf, int spos, int *epos,
		  regmatch_t * p_pm, struct html_token *ptr)
{
	struct input_info *p;
	int eff_spos;
	int index = ptr->index;

	eff_spos = GET_SPOS(spos, &p_pm[index]);

	p = (struct input_info *)ptr->private_data;

	DPRINTF("pat_spos [%d]; *epos [%d] !\n", eff_spos, *epos);
	STRNCPY(p->match_val, inbuf + eff_spos,
		p_pm[index].rm_eo - p_pm[index].rm_so);
	DPRINTF("===>Input Matchval : %s\n", p->match_val);

	return 0;
}

int
checked_input_value(char *inbuf, char *outbuf, int spos, int *epos,
		    regmatch_t * p_pm, struct html_token *ptr)
{
	struct input_info *p;

	p = (struct input_info *)ptr->private_data;
	p->checked = 1;
	DPRINTF("******** Option value checked *****!\n");

	return 0;
}

int
hidden_input_value(char *inbuf, char *outbuf, int spos, int *epos,
		   regmatch_t * p_pm, struct html_token *ptr)
{
	struct input_info *p;

	/* XXX: NOT REQUIRED. No such requirement */

	p = (struct input_info *)ptr->private_data;
	p->hidden = 1;
	DPRINTF("******** Hidden value checked *****!\n");

	return 0;
}

int input_copy(char *inbuf, char *outbuf, int spos, int *epos,
	       regmatch_t * pm, struct html_token *ptr)
{
	regmatch_t lpm[MAX_REGEXP_TOKENS];
	size_t num_lpm = MAX_REGEXP_TOKENS;
	char *p_new;
	int endpos = 0;
	int eff_spos = 0;

	eff_spos = GET_SPOS(spos, pm);

	/*
	 * Check if old alloc of input value is there, free it then 
	 */
	if (g_input_info.input_val) {
		free(g_input_info.input_val);
	}
	memset(&g_input_info, 0x0, sizeof(g_input_info));

	DPRINTF("spos<%d>, *epos<%d>\n", eff_spos, *epos);

	DPRINTF("in input_copy !\n");

	endpos = *epos;		/* init */
	while (*epos > eff_spos) {
		memset(lpm, 0x0, sizeof(lpm));
		DPRINTF("spos <%d>\n", eff_spos);

		if ((p_new = match_token_ex(inbuf, outbuf, eff_spos, &endpos,
					    ptr->sub_token_array,
					    &(ptr->token_regex), lpm,
					    &num_lpm)) == NULL) {
			DPRINTF("(%s) match_token_ex returned NULL\n",
				__FUNCTION__);
			break;
		}
		num_lpm = MAX_REGEXP_TOKENS;	/* reinit for next pass */
		DPRINTF("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n\n");
		DPRINTF("Token found at lpm[0].rm_so<%ld>, lpm[0].rm_eo<%ld>\n",
			(ulong) lpm[0].rm_so, (ulong) lpm[0].rm_eo);
		DPRINTF("spos <%d>, endpos <%d>, *epos <%d>!\n",
			eff_spos, endpos, *epos);
		eff_spos = GET_MATCH_EPOS(eff_spos, lpm);
	}

	{
		struct input_info *q;
		q = (struct input_info *)ptr->private_data;

		if (q->input_type[0] == '\0') {
			/* default to text box */
			strcpy(q->input_type, "TEXT");
		}
		if (g_debug_flag == 1) {

			DPRINTF
			    ("========================INPUT INFO====================\n");
			DPRINTF("\tInput Name\t:%s\n", q->input_name);
			DPRINTF("\tInput Type\t:%s\n", q->input_type);
			DPRINTF("\tInput Val\t:%s\n", q->input_val);
			DPRINTF("\tMatch Value\t:%s\n", q->match_val);
			DPRINTF("\tChecked\t:%s\n", q->checked ? "YES" : "NO");
			DPRINTF("\tHidden\t:%s\n", q->hidden ? "YES" : "NO");

			if (q->match_val[0] != '\0') {
				if (!strcmp(q->match_val, q->input_val)) {
					DPRINTF("match_val MATCHED ********\n");
				}
			}
		}

		if (g_html_process_mode == HTML_PROCESS_FVSET) {
			struct field_value_set *ptr;

			if (!strcasecmp(q->input_type, "BUTTON")) {
				goto lbl_skip;
			}
			if (q->hidden != 0) {
				goto lbl_skip;
			}

			if (q->match_val[0] != '\0') {
				if (strcmp(q->match_val, q->input_val)) {
					DPRINTF
					    ("MatchVal [%s] != InputVal [%s]\n",
					     q->match_val, q->input_val);
					goto lbl_skip;
				}
			}
			if (!strcasecmp(q->input_type, "RADIO") ||
			    !strcasecmp(q->input_type, "CHECKBOX")) {
				if (q->checked == 0)
					goto lbl_skip;
			} else if (strcasecmp(q->input_type, "TEXT") &&
				   strcasecmp(q->input_type, "PASSWORD")) {
				IPRINTF("Input Type <%s> unknown !\n",
					q->input_type);
				goto lbl_skip;
			}

			ALLOC_NEW_NODE(pg_fvset, g_num_fields);

			if (pg_fvset == NULL) {
				DPRINTF("Out of memory !\n");
				return -1;
			}

			ptr = &pg_fvset[g_num_fields - 1];

			ptr->field_name = NULL;
			ptr->field_value = NULL;
			if (q->input_name) {
				ptr->field_name = calloc(1,
							 strlen(q->input_name) +
							 1);
				if (!ptr->field_name) {
					DPRINTF
					    ("input_copy : Out of memory !\n");
					return -1;
				}
				strcpy(ptr->field_name, q->input_name);
			}
			if (q->input_val) {
				ptr->field_value = calloc(1,
							  strlen(q->input_val) +
							  1);
				if (!ptr->field_value) {
					DPRINTF
					    ("input_copy : Out of memory !\n");
					free(ptr->field_name);
					return -1;
				}
				strcpy(ptr->field_value, q->input_val);
			}
		} else if (g_html_process_mode == HTML_PROCESS_DATASTRUCT) {
			regmatch_t t_pm = { 0 };
			char tmp_str[10];
			char *p_instr = NULL;
			//char *p_outstr;
			int tmp_len = 7;
			if (!strcasecmp(q->input_type, "BUTTON")) {
				goto lbl_skip;
			}
			if (q->hidden != 0) {
				goto lbl_skip;
			}
			if (q->match_val[0] != '\0') {
				if (strcmp(q->match_val, q->input_val)) {
#if 0
					goto lbl_skip;
#else
					q->checked = 0;	/* reset checked */
				} else {
					q->checked = 1;
#endif
				}
			}
			if (!strcasecmp(q->input_type, "RADIO")) {
				if (q->checked) {
					strcpy(tmp_str, " ( x ) ");
				} else {
					strcpy(tmp_str, " (   ) ");
				}
				p_instr = tmp_str;
			} else if (!strcasecmp(q->input_type, "CHECKBOX")) {
				if (q->checked) {
					strcpy(tmp_str, " [ x ] ");
				} else {
					strcpy(tmp_str, " [   ] ");
				}
				p_instr = tmp_str;
			} else if (!strcasecmp(q->input_type, "TEXT") ||
				   !strcasecmp(q->input_type, "PASSWORD")) {
				p_instr = q->input_val;
				t_pm.rm_so = 0;
				if (q->input_val) {
					tmp_len = strlen(q->input_val);
				} else {
					IPRINTF
					    (" XXX: Error - input value = NULL !\n");
					goto lbl_skip;
				}
				if (!strcasecmp(q->input_type, "PASSWORD")) {
					int k;
					/* Turn all characters to '*' */
					for (k = 0; k < tmp_len; k++) {
						p_instr[k] = '*';
					}
				}
			} else {
				/* Unsupported 'type' */
				goto lbl_skip;
			}
			t_pm.rm_eo = tmp_len;
			if (q->input_val && tmp_len) {
				copy_ds_bytes(p_instr, NULL, 0, &tmp_len,
					      &t_pm, ptr);
			}
		}
	}
      lbl_skip:
	DPRINTF(" ~~~~~~~~~~~~~~~~~~~~ ==> Endpos:*epos <%d:%d>\n",
		endpos, *epos);

//      strcat(outbuf, ">");
	*epos = endpos;
	return (0);
}

int
store_select_size(char *inbuf, char *outbuf, int spos, int *epos,
		  regmatch_t * p_pm, struct html_token *ptr)
{
	char buf[100] = { 0 };
	struct select_info *p;
	int eff_spos;
	int index = ptr->index;

	p = (struct select_info *)ptr->private_data;
	eff_spos = GET_SPOS(spos, &p_pm[index]);

	DPRINTF("spos [%d]; *epos [%d] !\n", spos, *epos);
	STRNCPY(buf, inbuf + eff_spos, p_pm[index].rm_eo - p_pm[index].rm_so);
	p->size = atoi(buf);
	DPRINTF("===>Select Size : %s[%d]\n", buf, p->size);

	return 0;
}

int
store_option_disabled(char *inbuf, char *outbuf, int spos, int *epos,
		      regmatch_t * p_pm, struct html_token *ptr)
{
	struct select_info *p;

	p = (struct select_info *)ptr->private_data;

	p->disabled = 1;
	DPRINTF("===>Select Disabled \n");

	return 0;
}

int
store_option_name(char *inbuf, char *outbuf, int spos, int *epos,
		  regmatch_t * p_pm, struct html_token *ptr)
{
	struct select_info *p;
	int len;
	int eff_spos;
	int index = ptr->index;

	p = (struct select_info *)ptr->private_data;

	eff_spos = GET_SPOS(spos, &p_pm[index]);

	DPRINTF("&&&&&&&&&&&&&&&&\n\nIn store_option_name ..........\n");
	DPRINTF("spos [%d]; *epos [%d] !\n", spos, *epos);
	DPRINTF("pm.spos [%ld]; pm.epos [%ld] !\n", (ulong) p_pm[index].rm_so,
		(ulong) p_pm[index].rm_eo);
	len = p_pm[index].rm_eo - p_pm[index].rm_so;
	if (len < 0) {
		DPRINTF("(%s) len[%d] of match < 0! Error !\n", __FUNCTION__,
			len);
		DPRINTF("spos [%d]; *epos [%d] !\n", spos, *epos);
		DPRINTF("pm.spos [%ld]; pm.epos [%ld] !\n",
			(ulong) p_pm[index].rm_so, (ulong) p_pm[index].rm_eo);
		DPRINTF("inbuf[spos] : [%s]\n", &inbuf[spos]);
		DPRINTF("Index : [%d] \n", index);
	}
	p->option_name = calloc(len + 2, 1);
	if (!p->option_name) {
		DPRINTF("store_option_name: Out of Memory error !\n");
		return -1;
	}
	STRNCPY(p->option_name, inbuf + eff_spos, len);
	/* Do processing as a HTML string */
	{
		//int len=0;
		/* Need to weed out all '\n' and '\t' from the buffer */
		remove_non_html_chars(p->option_name, "\r\n\t");
		replace_special_str(p->option_name, "&nbsp;", " ");
	}
	DPRINTF("===>Option Name : %s\n", p->option_name);

	return 0;
}

int
store_option_value(char *inbuf, char *outbuf, int spos, int *epos,
		   regmatch_t * p_pm, struct html_token *ptr)
{
	struct select_info *p;
	int eff_spos;
	int index = ptr->index;

	p = (struct select_info *)ptr->private_data;
	eff_spos = GET_SPOS(spos, &p_pm[index]);

	DPRINTF("&&&&&&&&&&&&&&&&\n\nIn store_option_value ..........\n");
	DPRINTF("spos [%d]; *epos [%d] !\n", spos, *epos);
	DPRINTF("pm.spos [%ld]; pm.epos [%ld] !\n", (ulong) p_pm[index].rm_so,
		(ulong) p_pm[index].rm_eo);
	STRNCPY(p->option_val, inbuf + eff_spos,
		p_pm[index].rm_eo - p_pm[index].rm_so);
	DPRINTF("===>Option Value : %s\n", p->option_val);

	return 0;
}
int
process_option_value(char *inbuf, char *outbuf, int spos, int *epos,
		     regmatch_t * p_pm, struct html_token *ptr)
{
	regmatch_t lpm[MAX_REGEXP_TOKENS];
	regmatch_t tpm = { 0 };
	size_t num_lpm;
	char *p, *p_new;
	int endpos = 0;
	int eff_spos = 0;
	int eff_endpos = 0;

	DPRINTF("spos [%d]; *epos [%d] !\n", spos, *epos);
	DPRINTF("===>Process option value\n");

	endpos = *epos;
	eff_spos = GET_SPOS(spos, p_pm);
	p = inbuf;

#if 1
	token_to_end_token_skip("</option>", inbuf, outbuf, eff_spos,
				&endpos, &tpm, ptr);
	DPRINTF("spos[%d:%d] *epos [%d], endpos[%d:%d]\n", spos, eff_spos,
		*epos, endpos, eff_endpos);

#endif
	eff_endpos = endpos;

	while (eff_endpos > eff_spos) {
		num_lpm = MAX_REGEXP_TOKENS;	/* init for next pass */

#if 1
		if ((p_new = match_token_ex(p, outbuf, eff_spos, &endpos,
					    ptr->sub_token_array,
					    &(ptr->token_regex), lpm,
					    &num_lpm)) == NULL) {
			DPRINTF("subtoken array <%s> match failed !\n",
				ptr->sub_token_array[0].token_prefix_str);
			break;
		}
		eff_spos = GET_MATCH_EPOS(eff_spos, lpm);
		DPRINTF(" p_new-p [%d] ;  lpm.rmso:rmeo [%ld:%ld]!\n",
			p_new - p, (ulong) lpm[0].rm_so, (ulong) lpm[0].rm_eo);
	}
	DPRINTF(">>>>>>>>>>Outbuf [%s]\n", outbuf);
	DPRINTF("skipping to </option> ...\n");
#if 0
	/* Find the end of "</option>" */
	token_to_end_token_skip("</option>", inbuf, outbuf, spos,
				&endpos, &lpm[0], ptr);
#endif

	/* Copy data between <OPTION> ... </OPTION> */
#if 0
	STRNCAT(outbuf, inbuf + spos, lpm[0].rm_so);
#else
	STRNCAT(outbuf, inbuf + spos, endpos - spos);
#endif

	/* since *epos is set, "</OPTION>" will be skipped */

#endif
	DPRINTF(" At the end of (%s),  spos<%d>, endpos<%d>, *epos<%d>!\n",
		__FUNCTION__, spos, endpos, *epos);
#if 0				//Causes seg fault
	if (pg_html->pp_out != NULL)
		DPRINTF("[%s]\n", *pg_html->pp_out);
#endif

	*epos = endpos;

	return 0;
}

int
selected_option_value(char *inbuf, char *outbuf, int spos, int *epos,
		      regmatch_t * p_pm, struct html_token *ptr)
{
	struct select_info *p;

	p = (struct select_info *)ptr->private_data;
	p->selected = 1;
	DPRINTF("******** Option value selected *****!\n");

	return 0;
}
int
store_match_value(char *inbuf, char *outbuf, int spos, int *epos,
		  regmatch_t * p_pm, struct html_token *ptr)
{
	int eff_spos;
	int index = ptr->index;
	struct select_info *p;

	p = (struct select_info *)ptr->private_data;
	eff_spos = GET_SPOS(spos, &p_pm[index]);

	STRNCPY(p->match_val, inbuf + eff_spos, p_pm[index].rm_eo -
		p_pm[index].rm_so);
	DPRINTF("******** Match_value [%s] \n", p->match_val);

	return 0;
}

int
token_to_end_token_skip(char *tagstr, char *inbuf, char *outbuf, int spos,
			int *epos, regmatch_t * p_pm, struct html_token *ptr)
{
	int ret = 0;
	regex_t endtoken;
	DPRINTF("\n\n########### spos<%d>, *epos <%d>!\n", spos, *epos);

	if (regcomp(&endtoken, tagstr, REG_EXTENDED | REG_ICASE) != 0) {
		IPRINTF("Error generating regexp !\n");
		return (-1);
	}

	if (regexec(&endtoken, inbuf + spos, (size_t) 1, p_pm, 0) != 0) {
		DPRINTF("Error matching regexp !\n");
		ret = -1;
		goto lbl_ret;
	}

	*epos = p_pm->rm_eo + spos;
	DPRINTF("*epos set to [%d]!\n", *epos);

      lbl_ret:
	regfree(&endtoken);
	return (ret);
}

int
script_skip(char *inbuf, char *outbuf, int spos, int *epos,
	    regmatch_t * p_pm, struct html_token *ptr)
{
	DPRINTF("script_skip *********** HIT ***************!\n");
	return (token_to_end_token_skip("</SCRIPT>", inbuf, outbuf, spos, epos,
					p_pm, ptr));
}

int
div_copy(char *inbuf, char *outbuf, int spos, int *epos,
	 regmatch_t * p_pm, struct html_token *ptr)
{
	regmatch_t lpm[MAX_REGEXP_TOKENS];
	size_t num_lpm = MAX_REGEXP_TOKENS;
	char *p_new = NULL;
	//int ret;
	int endpos = 0;
	int eff_spos = 0;
	struct div_info *p;

	DPRINTF("DIV *********** HIT ***************!\n");
#if 0
	len = p_pm[1].rm_eo - p_pm[1].rm_so;
	STRNCPY(id, inbuf + p_pm[1].rm_so, len);

	len = p_pm[2].rm_eo - p_pm[2].rm_so;
	STRNCPY(match_val, inbuf + p_pm[2].rm_so, len);

	DPRINTF("\t\tDIV Id:Matchval <%s:%s>!\n", id, match_val);
	if (!match_val[0] || !strcmp(id, match_val)) {
		/* DIV Id matches */
		*epos = p_pm[0].rm_eo;
		DPRINTF("DIV Id matches! *epos [%d]\n", *epos);
		return (0);
	} else {
		/* Skip the whole <DIV> </DIV> section */

		DPRINTF("DIV Id does NOT match! Skipping \n");
		return (token_to_end_token_skip("</DIV>", inbuf, outbuf,
						spos, epos, p_pm, ptr));
	}
#endif

	eff_spos = GET_SPOS(spos, p_pm);
	memset(&g_div_info, 0x0, sizeof(g_div_info));

#ifdef DEBUG_MATCH
	if (g_debug_flag == 1) {
		strcat(outbuf, ptr->token_prefix_str);

		DPRINTF("spos<%d>, *epos<%d>\n", eff_spos, *epos);

		DPRINTF("in div_copy !\n");
	}
#endif
	endpos = *epos;		/* init */
	while (*epos > eff_spos) {
		memset(lpm, 0x0, sizeof(lpm));
		DPRINTF("spos <%d>\n", eff_spos);

		if ((p_new = match_token_ex(inbuf, outbuf, eff_spos, &endpos,
					    ptr->sub_token_array,
					    &(ptr->token_regex), lpm,
					    &num_lpm)) == NULL) {
			DPRINTF("(%s) match_token_ex returned NULL\n",
				__FUNCTION__);
			break;
		}
		num_lpm = MAX_REGEXP_TOKENS;	/* reinit for next pass */
		DPRINTF("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n\n");
		DPRINTF("Token found at lpm[0].rm_so<%ld>, lpm[0].rm_eo<%ld>\n",
			(ulong) lpm[0].rm_so, (ulong) lpm[0].rm_eo);
		DPRINTF("spos <%d>, endpos <%d>, *epos <%d>!\n",
			eff_spos, endpos, *epos);
		eff_spos = GET_MATCH_EPOS(eff_spos, lpm);
	}
	p = (struct div_info *)ptr->private_data;
	if (g_debug_flag == 1) {
		IPRINTF
		    ("========================DIV INFO====================\n");
		IPRINTF("\tDIV Id\t:%s\n", p->id);
		IPRINTF("\tDIV Matchval :%s\n", p->match_val);
	}

	if (p->id[0] != '\0' && p->match_val[0] != '\0') {
		if (strcmp(p->id, p->match_val)) {
			regmatch_t tpm = { 0 };
			/* Skip it */
			token_to_end_token_skip("</div>", inbuf, outbuf,
						eff_spos, &endpos, &tpm, ptr);
#if 0
			DPRINTF("spos[%d:%d] *epos [%d], endpos[%d:%d]\n",
				spos, eff_spos, *epos, endpos, eff_endpos);
#endif

			*epos = endpos;
		}
	}
	return 0;
}

#if 0
int nbsp_copy(char *inbuf, char *outbuf, int spos, int *epos,
	      regmatch_t * pm, struct html_token *ptr)
{
	int ret = 0;
	int eff_spos;
#ifdef DEBUG_MATCH
	eff_spos = GET_SPOS(spos, pm);
	if (g_debug_flag == 1) {
		DPRINTF("outbuf [%s]\n", outbuf);
		strcat(outbuf, ptr->token_prefix_str);
		DPRINTF("outbuf [%s]\n", outbuf);
		{
			char buf[1000];

			STRNCPY(buf, inbuf + eff_spos, *epos - eff_spos);
			DPRINTF("Temp buf [%s]\n", buf);

		}
	}
#endif
	if (g_html_process_mode == HTML_PROCESS_DATASTRUCT) {
		if (pg_html->pp_out == NULL) {
			DPRINTF("\n\n******** Error : Null pp_out *********\n");
			ret = -1;
		} else {
			strcat(*pg_html->pp_out, " ");
		}
	}
	return (ret);
}
#endif

int br_copy(char *inbuf, char *outbuf, int spos, int *epos,
	    regmatch_t * pm, struct html_token *ptr)
{
	int ret = 0;
	int eff_spos;
#ifdef DEBUG_MATCH
	eff_spos = GET_SPOS(spos, pm);
	if (g_debug_flag == 1) {
		DPRINTF("outbuf [%s]\n", outbuf);
		strcat(outbuf, ptr->token_prefix_str);
		DPRINTF("outbuf [%s]\n", outbuf);
		{
			char buf[1000];

			STRNCPY(buf, inbuf + eff_spos, *epos - eff_spos);
			DPRINTF("Temp buf [%s]\n", buf);

		}
	}
#endif
	if (g_html_process_mode == HTML_PROCESS_DATASTRUCT) {
		if (pg_html->pp_out == NULL) {
			DPRINTF("******** Error : Null pp_out *********\n");
			ret = -1;
		} else {
#if 1
			int temp_epos;
			regmatch_t t_pm = { 0 };

			temp_epos = 1;

			ret = (copy_ds_bytes("\n", *pg_html->pp_out, 0,
					     &temp_epos, &t_pm, ptr));
#else
			strcat(*pg_html->pp_out, "\n");
#endif
		}
	}
	return (ret);
}

int p_copy(char *inbuf, char *outbuf, int spos, int *epos,
	   regmatch_t * pm, struct html_token *ptr)
{
	int ret = 0;
	int eff_spos;
#ifdef DEBUG_MATCH
	eff_spos = GET_SPOS(spos, pm);
	if (g_debug_flag == 1) {
		DPRINTF("outbuf [%s]\n", outbuf);
		strcat(outbuf, ptr->token_prefix_str);
		DPRINTF("outbuf [%s]\n", outbuf);
		{
			char buf[1000];

			STRNCPY(buf, inbuf + eff_spos, *epos - eff_spos);
			DPRINTF("Temp buf [%s]\n", buf);

		}
	}
#endif
	if (g_html_process_mode == HTML_PROCESS_DATASTRUCT) {
		if (pg_html->pp_out == NULL) {
			DPRINTF("******** Error : Null pp_out *********\n");
			ret = -1;
		} else {
#if 1
			int temp_epos;
			regmatch_t t_pm = { 0 };

			temp_epos = 2;

			ret = (copy_ds_bytes("\n\t", *pg_html->pp_out, 0,
					     &temp_epos, &t_pm, ptr));
#else
			strcat(*pg_html->pp_out, "\n\t");
#endif
		}
	}
	return (ret);
}

int
store_div_id(char *inbuf, char *outbuf, int spos, int *epos,
	     regmatch_t * p_pm, struct html_token *ptr)
{
	struct div_info *p;
	int eff_spos;
	int index = ptr->index;
	int len = 0;

	DPRINTF(" spos <%d> rm_so[%ld], rm_eo[%ld]\n", spos,
		(ulong) p_pm[index].rm_so, (ulong) p_pm[index].rm_eo);

	eff_spos = GET_SPOS(spos, &p_pm[index]);

	p = (struct div_info *)ptr->private_data;

	DPRINTF("pat_spos [%d]; *epos [%d] !\n", eff_spos, *epos);
	len = p_pm[index].rm_eo - p_pm[index].rm_so;
	if (len < 0) {
		DPRINTF("(%s) len[%d] of match < 0! Error !\n", __FUNCTION__,
			len);
		DPRINTF("spos [%d]; *epos [%d] !\n", spos, *epos);
		DPRINTF("pm.spos [%ld]; pm.epos [%ld] !\n",
			(ulong) p_pm[index].rm_so, (ulong) p_pm[index].rm_eo);
		DPRINTF("Index : [%d] \n", index);
		return -1;
	}
	if (len >= MAX_FIELD_LEN) {
		DPRINTF("Id string too long [%d:%d] !\n", len, MAX_FIELD_LEN);
		return -1;
	}

	STRNCPY(p->id, inbuf + eff_spos, len);
	DPRINTF("===>Input value : %s\n", p->id);

	return 0;
}

int
store_div_matchval(char *inbuf, char *outbuf, int spos, int *epos,
		   regmatch_t * p_pm, struct html_token *ptr)
{
	struct div_info *p;
	int eff_spos;
	int index = ptr->index;
	int len = 0;

	DPRINTF(" spos <%d> rm_so[%ld], rm_eo[%ld]\n", spos,
		(ulong) p_pm[index].rm_so, (ulong) p_pm[index].rm_eo);

	eff_spos = GET_SPOS(spos, &p_pm[index]);

	p = (struct div_info *)ptr->private_data;

	DPRINTF("pat_spos [%d]; *epos [%d] !\n", eff_spos, *epos);
	len = p_pm[index].rm_eo - p_pm[index].rm_so;
	if (len < 0) {
		DPRINTF("(%s) len[%d] of match < 0! Error !\n", __FUNCTION__,
			len);
		DPRINTF("spos [%d]; *epos [%d] !\n", spos, *epos);
		DPRINTF("pm.spos [%ld]; pm.epos [%ld] !\n",
			(ulong) p_pm[index].rm_so, (ulong) p_pm[index].rm_eo);
		DPRINTF("Index : [%d] \n", index);
		return -1;
	}
	if (len >= MAX_FIELD_LEN) {
		DPRINTF("Id string too long [%d:%d] !\n", len, MAX_FIELD_LEN);
		return -1;
	}

	STRNCPY(p->match_val, inbuf + eff_spos, len);
	IPRINTF("===>DIV match_val : %s\n", p->match_val);

	return 0;
}

struct html_token *find_token_entry(struct html_token *p_token_array,
				    char *inbuf, int spos, regmatch_t * pm)
{
	int i = 1;
	struct html_token *p;

	p = &p_token_array[0];

	while (p->token_regexp_str) {
		XPRINTF(">>>>>>>> [%s]\n", p->token_prefix_str);
		if (!strncasecmp(inbuf + spos, p->token_prefix_str,
				 strlen(p->token_prefix_str))) {
			/* double check if this is the right string */
			if (pm && pm[p->index].rm_eo == -1) {
				DPRINTF(" Not the correct entry <%d>\n", i);
				p++;
				i++;
				continue;
			}
#if 0
			DPRINTF("Token match : [%s]; inbuf[%s]!\n",
				p->token_prefix_str, inbuf);
#else
			DPRINTF("Token match : [%s] at spos<%d>!\n",
				p->token_prefix_str, spos);
#endif
			return (p);
		}
		i++;
		p++;
	}
	DPRINTF("Token str not found! [%s:%s]\n", inbuf + spos,
		p->token_prefix_str);
	return (NULL);
}

#if 1
char *match_token(char *inbuf, char *outbuf, struct html_token *p_token_array,
		  regex_t * pregex, regmatch_t * pm)
{
	int i = 0;
	int endpos = 0;
	struct html_token *ptoken;
	char *ret = NULL;

	g_nest_level++;
	DPRINTF(" Nest Level [%d]\n", g_nest_level);
	DPRINTF("Inbuf [%s]\n", inbuf);
	if ((i = regexec(pregex, inbuf, (size_t) 1, pm, 0)) != 0) {
		if (i != REG_NOMATCH) {
			DPRINTF("Error executing regexp !\n");
		}
//      DPRINTF("Error2 executing regexp !\n");
		goto lbl_ret;
	}

	DPRINTF("--> spos<%ld>, epos<%ld>!\n", (ulong) pm->rm_so,
		(ulong) pm->rm_eo);
	ptoken = find_token_entry(p_token_array, inbuf, pm->rm_so, NULL);
	if (!ptoken) {
		goto lbl_ret;
	}
	if (g_html_flag == 0 && strcasecmp(ptoken->token_prefix_str, "<HTML>")) {
		DPRINTF("HTML header not found yet !\n");
		goto lbl_ret1;
	} else if (g_html_flag == 0) {
		DPRINTF("HTML token found! Starting processing of buffer...\n");
	}
#if 0
	if (ptoken->fptr && ptoken->fptr(inbuf, outbuf, pm->rm_so,
					 (int *)&pm->rm_eo, pm, ptoken) < 0) {
		return NULL;
	}
#else
	endpos = pm->rm_eo + 0;
#if 1
	if (ptoken->fptr && ptoken->fptr(inbuf, outbuf, 0,
					 (int *)&endpos, pm, ptoken) < 0) {
		DPRINTF("Handler function returned < 0\n");
		return NULL;
	}
	DPRINTF("ENDPOS : [%ld:%d]\n", (ulong) pm->rm_eo, endpos);
	pm->rm_eo = endpos;
#endif

#endif

      lbl_ret1:
	if (inbuf[pm->rm_eo - 1] == '>' || inbuf[pm->rm_eo - 1] == '<') {
		/* need to keep '>' in the inbuf */
		ret = (inbuf + pm->rm_eo - 1);
	} else {
		ret = (inbuf + pm->rm_eo);
	}
      lbl_ret:
	g_nest_level--;
	return ret;
}
#endif

char *match_token_ex(char *inbuf, char *outbuf, int spos, int *epos,
		     struct html_token *p_token_array, regex_t * pregex,
		     regmatch_t * pm, size_t * pnum_pm)
{
	int i = 0, valid = -1;
	struct html_token *ptoken;
	int endpos = 0;
	char *ret = NULL;

	g_nest_level++;
	DPRINTF("((Nest Level [%d]: #pm<%d>\n", g_nest_level, *pnum_pm);
	DPRINTF("Inbuf [%s]\n", inbuf + spos);
	memset(pm, 0x0, sizeof(*pm) * (*pnum_pm));
	if ((i = regexec(pregex, inbuf + spos, *pnum_pm, pm, 0)) != 0) {
		if (i != REG_NOMATCH) {
			DPRINTF("Error executing regexp !\n");
		}
		ret = NULL;
		goto lbl_ret;
	}
	for (i = 0; i < *pnum_pm; i++) {
		if (pm[i].rm_so == -1 || pm[i].rm_eo == -1) {
			XPRINTF("[%d] -> regexec  done !\n", i);
			continue;
		}
		/* XXX Should we start from i=1 instead of i=0
		 *     maybe not ? XXX */
#if 0
		if ((pm[i].rm_eo + spos) > (*epos))
#else
		if ((pm[i].rm_so + spos) > (*epos))
#endif
		{
#if 0
			char xxx[1000] = { 0 };
			/* We have matched beyond our mandate */
			DPRINTF
			    (" XXXXXXXXX: End of top token match at index[%d]! [%ld:%d]\n",
			     i, pm[i].rm_eo, *epos);
			STRNCPY(xxx, inbuf, pm[i].rm_so);
			DPRINTF("YYYYY1: [%s]!\n", xxx);
			STRNCPY(xxx, inbuf, pm[i].rm_eo);
			DPRINTF("YYYYY1: [%s]!\n", xxx);
			STRNCPY(xxx, inbuf, *epos);
			DPRINTF("YYYYY1: [%s]!\n", xxx);
#endif

			pm[i].rm_eo = pm[i].rm_so = -1;	/* reset entry */
			continue;
		}
		valid = i;
		DPRINTF("--> [%d] pat_spos<%d>, pat_epos<%d>!\n",
			i, pm[i].rm_so + spos, pm[i].rm_eo + spos);
	}
	if (valid >= 0) {
		*pnum_pm = valid;
	} else {
		ret = NULL;	/* Added XXX */
		goto lbl_ret;
	}
	/* Use the 1st match as it should give the token */
	DPRINTF("********** token found [%s]\n", inbuf + spos + pm[0].rm_so);
	ptoken = find_token_entry(p_token_array, inbuf + spos, pm[0].rm_so, pm);
	if (!ptoken) {
		DPRINTF("Token not found ? Error !\n");
		ret = NULL;
		goto lbl_ret;
	}
	DPRINTF("--> pm Index [%d:%d] \n", valid, ptoken->index);

	/* All the match sections can be accessed from pm. pm[0] contains
	 * the entire match. pm[1], pm[2] contains specific sections
	 * enclose in '(' and ')'! */
#if 0
	if (ptoken->fptr && ptoken->fptr(inbuf, outbuf, pm->rm_so,
					 (int *)&pm[*pnum_pm - 1].rm_eo, pm,
					 ptoken) < 0) {
		return NULL;
	}
#else
	endpos = pm[0].rm_eo + spos;
	if (ptoken->fptr && ptoken->fptr(inbuf, outbuf, spos,
					 (int *)&endpos, pm, ptoken) < 0) {
		ret = NULL;
	}
#endif

#if 1
	/* XXX: pm[0] has the entire match. Use this and not the last valid
	 * pm[i] entry ! - Ritesh */
	if (inbuf[endpos - 1] == '>' || inbuf[endpos - 1] == '<') {
		/* need to keep '>' in the inbuf */
		ret = (inbuf + endpos - 1);
		pm[0].rm_eo--;	/* Adjust since caller may use this */

	} else {
		ret = (inbuf + endpos);
	}
#endif

      lbl_ret:
	g_nest_level--;
	return (ret);
}

int top_level_process_buf(char *buf, int flags)
{
	char *p, *end;
	char *outbuf = NULL;
	int len;
	regmatch_t pm;

#ifdef DEBUG_MATCH
	outbuf = calloc(1, 10000);
	if (outbuf == NULL) {
		return -1;
	}
#endif
	len = strlen(buf);
	end = buf + len;

	p = buf;
	DPRINTF("p<%p> ; end <%p> ; len<%d>\n", p, end, len);
	while (p && p < end) {
		DPRINTF(" Inbuf [%s]\n", p);
		p = match_token(p, outbuf, g_html_token_array, &g_topregex,
				&pm);
		if (!p) {
			DPRINTF("No pattern match !\n");
		}
		memset(&pm, 0x0, sizeof(pm));
		DPRINTF("Outbuf : [%s]\n", outbuf);
	}
#ifdef DEBUG_MATCH
	if (outbuf != NULL) {
		free(outbuf);
		outbuf = NULL;
	}
#endif
	g_html_flag = 0;
	return 0;
}

void reset_vars(void)
{
	g_num_fields = 0;
	pg_fvset = NULL;
//      pg_html = NULL;

}

int parse_and_fill_fvset(char *buf, struct field_value_set **pp_fvset,
			 int *num_fields)
{
	int ret = 0;
	g_html_process_mode = HTML_PROCESS_FVSET;

	ret = top_level_process_buf(buf, 0);

	*pp_fvset = pg_fvset;
	*num_fields = g_num_fields;

	reset_vars();

	return (ret);
}

int parse_html_and_fill_struct(char *buf, struct html_page **pp_html)
{
	int ret = 0;
	struct html_page *p_html;
	g_html_process_mode = HTML_PROCESS_DATASTRUCT;

	DPRINTF(" HTML STRUCT Mode !\n");
//      getchar();

	p_html = calloc(1, sizeof(*p_html));

	if (!p_html) {
		DPRINTF("Parsing html - Out of Memory error!\n");
		return -1;
	}

	*pp_html = p_html;
	ret = top_level_process_buf(buf, 0);

	reset_vars();

	return (ret);
}

int dump_fvset(struct field_value_set *p_fvset, int num_fields)
{
	int i;

	DPRINTF("=====>>>>> DUMP Field Value set <<<<<-------\n");
	DPRINTF("Number of fields : [%d]\n", num_fields);

	for (i = 0; i < num_fields; i++) {
		DPRINTF("[%d] ==>  Field:Value = [%s:%s]!\n", i,
			p_fvset[i].field_name, p_fvset[i].field_value);
	}

	return 0;
}

#if 1
int dump_datastruct(struct html_page *p_html)
{
	int i, j, k;
	struct table *ptab;
	struct tr *ptr;
	struct td *ptd;

	DPRINTF("=====>>>>> DUMP Data struct Value set <<<<<-------\n");

	DPRINTF("TITLE :\n[%s]\n", p_html->title);
	DPRINTF("Pre String :[%s]\n", p_html->pre_str);
	DPRINTF("TABLE(s)\n");

	for (i = 0; i < p_html->num_tables; i++) {
		ptab = &p_html->table[i];
		DPRINTF
		    ("[%d] ==> border[%d], width[%d], align[%d], row[%d], col[%d] \n",
		     i, ptab->border, ptab->table_width, ptab->align,
		     ptab->num_tr, ptab->num_td);
		for (j = 0; j < ptab->num_tr; j++) {
			ptr = &ptab->tr[j];
			DPRINTF("TR[%d A:%d]-#TD:[%d]\n", j, ptr->params.align,
				ptr->num_td);
			for (k = 0; k < ptr->num_td; k++) {
				ptd = &ptr->td[k];
				DPRINTF("[A:%d,NW:%d,W:%d]:[%s]\n",
					ptd->params.align, ptd->params.nowrap,
					ptd->params.width, ptd->str);

			}
		}
	}
	DPRINTF("Post String :[%s]\n", p_html->post_str);

	return 0;
}
#endif

#if 0
int main(int argc, char *argv[])
{
	char buf[50000];
	char buf1[100];
	char pat[100];
	struct field_value_set *p_fvset;
	int num_fields = 0;
#if 1
	int fd = open(argv[1], O_RDONLY);
	if (fd < 0) {
		DPRINTF("open error\n");
		exit(0);
	}
	buf[0] = '\0';

	memset(buf1, 0x00, sizeof(buf1));
	while ((read(fd, buf1, sizeof(buf1) - 1)) > 0) {
		buf1[sizeof(buf1) - 1] = '\0';
		strcat(buf, buf1);
		memset(buf1, 0x00, sizeof(buf1));
	}
	close(fd);

#else
	DPRINTF("Input string : ");
	gets(buf);
	DPRINTF("Input pat : ");
	gets(pat);
#endif

	init_match_engine();

#if 0
	top_level_process_buf(buf, 0);
#else
	while (1) {
#if 0
		parse_and_fill_fvset(buf, &p_fvset, &num_fields);
		dump_fvset(p_fvset, num_fields);
		free(p_fvset);
#else
		int kk = 0;
		extern void free_table();
		extern void free_page();
		parse_html_and_fill_struct(buf, &pg_html);
		dump_datastruct(pg_html);
#if 1
		{
			char *outstr;
			DPRINTF
			    ("\n\n\n\n\n ***** Now chandrav's code ***** \n\n\n\n\n");
			//getchar();
			outstr = (draw_html_page(pg_html, 75));
			DPRINTF("\n%s\n------------\n", outstr);
			free(outstr);
		}
#else
		for (kk = 0; kk < pg_html->num_tables; kk++) {
			free_table(pg_html, kk);
		}
		free_page(pg_html);
#endif
#endif
		g_num_fields = 0;
		pg_html = NULL;
		getchar();
	}

#endif
	return 0;
}
#endif

char *call_draw_html_page(char *pstr)
{
#if 1
	parse_html_and_fill_struct(pstr, &pg_html);
	dump_datastruct(pg_html);
	return draw_html_page(pg_html, 75);
#endif
}

void init_match_engine(void)
{
#ifdef DEBUG_MATCH
	g_debug_flag = 1;
#endif
	init_tok_engine(g_html_token_array, &g_topregex);
	init_tok_engine(g_select_option_tokens, &g_select_optionregex);
	reset_vars();
}

#if 0

void free_table(struct html_page *page, int table_id)
{
	int i, j;

	for (i = 0; i < page->table[table_id].num_tr; i++) {
		for (j = 0; j < page->table[table_id].tr[i].num_td; j++) {
			if (page->table[table_id].tr[i].td[j].str) {
				free(page->table[table_id].tr[i].td[j].str);
			}
		}
		if (page->table[table_id].tr[i].td) {
			free(page->table[table_id].tr[i].td);
		}
	}

	if (page->table[table_id].tr) {
		free(page->table[table_id].tr);
	}

	if (page->table[table_id].td_params_array) {
		free(page->table[table_id].td_params_array);
	}

}

void free_page(struct html_page *page)
{

	if (page->title) {
		free(page->title);
	}
#if 1
	if (page->pre_str) {
		free(page->pre_str);
	}
#endif
	if (page->post_str) {
		free(page->post_str);
	}

	if (page->table) {
		free(page->table);
	}
	if (page) {
		free(page);
	}

}
#endif
