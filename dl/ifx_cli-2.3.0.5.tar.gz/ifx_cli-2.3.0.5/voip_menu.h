
struct menu_entry sip_reg_page_entries[] = {
	{
	 NULL,
	 "This is registrar page show entry",
	 "Show",
	 "voip_sip_reg.cli",
	 NULL,
	 NULL,
	 NULL},
	{
	 NULL,
	 "This is registrar page config entry",
	 "Config",
	 NULL,
	 NULL,
	 NULL,
	 &reg_page_config_cmd}
};

struct menu_page voip_sip_reg_page = {
	sip_reg_page_entries,
	sizeof(sip_reg_page_entries) / sizeof(struct menu_entry),
	"This is sip registrar setting page",
	"sipreg",
	NULL,
	0
};

struct value_set user_config_option_values[] = {
	{
	 "confproxy",
	 "0"},
	{
	 "confregist",
	 "1"},
	{
	 "confuser",
	 "2"},
	{
	 "confgwrtp",
	 "3"},
	{
	 "confjitterbuff",
	 "4"},
	{
	 "confother",
	 "5"},
	{
	 "confteluri",
	 "6"},
	{
	 "confphone",
	 "7"},
	{
	 "confaddrbook",
	 "8"},
	{
	 "confcodec",
	 "9"}
};

struct cmd_field user_page_config_cmd_field[] = {
	//this field may not be required
	{
	 "option",
	 "This field represent the configure type",
	 STR,
	 STATIC,
	 IFX_TRUE,
	 "option",
	 user_config_option_values,
	 sizeof(user_config_option_values) / sizeof(struct value_set),
	 NULL,
	 NULL,
	 NULL},
	{
	 "uname",
	 "This field represent the user name",
	 STR,
	 USR_DEF,
	 IFX_TRUE,
	 "uname",
	 NULL,
	 0,
	 NULL,
	 NULL},
	{
	 "dname",
	 "This field represent the display name",
	 STR,
	 USR_DEF,
	 IFX_TRUE,
	 "dname",
	 NULL,
	 0,
	 NULL,
	 NULL},
	{
	 "domain",
	 "This field represent the domain name",
	 STR,
	 USR_DEF,
	 IFX_TRUE,
	 "domain",
	 NULL,
	 0,
	 NULL,
	 NULL},
	{
	 "authname",
	 "This field represent the authorization name",
	 STR,
	 USR_DEF,
	 IFX_TRUE,
	 "authname",
	 NULL,
	 0,
	 NULL,
	 NULL},
	{
	 "authpwd",
	 "This field represent the password",
	 STR,
	 USR_DEF,
	 IFX_TRUE,
	 "pass",
	 NULL,
	 0,
	 NULL,
	 NULL}
};

struct cmd_entry user_page_config_cmd = {
	user_page_config_cmd_field,
	sizeof(user_page_config_cmd_field) / sizeof(struct cmd_field),
	"This command configures sip settings",
	//not specified
	NULL,
	NULL,
	NULL
};

struct menu_entry sip_user_page_entries[] = {
	{
	 NULL,
	 "This is user page show entry",
	 "Show",
	 "voip_sip_user.cli",
	 NULL,
	 NULL,
	 NULL},
	{
	 NULL,
	 "This is user page config entry",
	 "Config",
	 NULL,
	 NULL,
	 NULL,
	 &user_page_config_cmd}
};

struct menu_page voip_sip_user_page = {
	sip_user_page_entries,
	sizeof(sip_user_page_entries) / sizeof(struct menu_entry),
	"This is sip user page",
	"sipuser",
	"SIP User",
	0
};

struct menu_entry voip_page_entries[] = {
	{
	 &voip_sip_user_page,
	 "This is sip user entry",
	 "sipuser",
	 NULL,
	 "VOIP SIP User",
	 "voip_sip_user.asp",
	 NULL,
	 },
	{
	 &voip_sip_reg_page,
	 NULL,
	 "This is sip reg entry",
	 "sipreg",
	 NULL,
	 "VOIP SIP REG",
	 "voip_sip_reg.asp",
	 NULL,
	 },
	{
	 //&voip_sip_phone_page,
	 NULL,
	 "This is sip phone entry",
	 "sipphone",
	 NULL,
	 "VOIP SIP phone",
	 "voip_sip_phone.asp",
	 NULL,
	 },
	{
	 //&voip_sip_other_page,
	 NULL,
	 "This is sip other entry",
	 "sipother",
	 NULL,
	 "VOIP SIP other",
	 "voip_sip_other.asp",
	 NULL,
	 },
	{
	 //&voip_sip_jitter_page,
	 NULL,
	 "This is sip jitter entry",
	 "sipjitter",
	 NULL,
	 "VOIP SIP jitter",
	 "voip_sip_jitter.asp",
	 NULL,
	 },
	{
	 //&voip_sip_gw_page,
	 NULL,
	 "This is sip gw entry",
	 "sipgw",
	 NULL,
	 "VOIP SIP GW",
	 "voip_sip_gw.asp",
	 NULL,
	 },
	{
	 //&voip_sip_fax_page,
	 NULL,
	 "This is sip fax entry",
	 "sipfax",
	 NULL,
	 "VOIP SIP Fax",
	 "voip_sip_fax.asp",
	 NULL,
	 },
	{
	 //&voip_sip_addrbook_page,
	 NULL,
	 "This is sip addrbook entry",
	 "sipaddr",
	 NULL,
	 "VOIP SIP AddrBook",
	 "voip_sip_addrbook.asp",
	 NULL,
	 },
	{
	 //&voip_sip_portset_page,
	 NULL,
	 "This is sip portset entry",
	 "sipportset",
	 NULL,
	 "VOIP SIP Port Set",
	 "voip_sip_portset.asp",
	 NULL,
	 },
	{
	 //&voip_sip_teluri_page,
	 NULL,
	 "This is sip teluri entry",
	 "sipteluri",
	 NULL,
	 "VOIP SIP TelUri",
	 "voip_sip_teluri.asp",
	 NULL,
	 },
	{
	 //&voip_sip_proxy_page,
	 NULL,
	 "This is sip proxy entry",
	 "sipproxy",
	 NULL,
	 "VOIP SIP Proxy",
	 "voip_sip_proxy.asp",
	 NULL,
	 },
	{
	 //&voip_sip_rm_page,
	 NULL,
	 "This is sip user entry",
	 "siprm",
	 NULL,
	 "VOIP SIP RM",
	 "voip_sip_rm.asp",
	 NULL,
	 }
};

struct menu_page voip_page = {
	voip_page_entries,
	sizeof(voip_page_entries) / sizeof(struct menu_entry),
	"This is voip page",
	"voip",
	"VOIP",
	0
};
