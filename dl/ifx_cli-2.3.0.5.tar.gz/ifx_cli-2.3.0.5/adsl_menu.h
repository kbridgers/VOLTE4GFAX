#ifndef __ADSL_MENU_H
#define __ADSL_MENU_H
#include "adsl_menu_func.h"
#include "wan_menu_func.h"

struct value_set phyconfig_config_tcmod_values[] = {
	{.display_value = "Enable",.submit_value = "1"},
	{.display_value = "Disable",.submit_value = "0"}
};

struct value_set adsl_autoselected_mode_values[] = {
	{.display_value = "AnnexA",.submit_value =
	 "AnnexA_1_1_1_1_1_1_1_1_1_1_0_0_0_0_0"},
	{.display_value = "AnnexB",.submit_value =
	 "AnnexB_0_0_0_0_0_0_0_0_1_1_1_1_1_1_1"},
	{.display_value = "AnnexM",.submit_value =
	 "AnnexM_0_0_0_0_0_0_0_0_1_1_0_0_0_0_0"},
	{.display_value = "AnnexI",.submit_value =
	 "AnnexI_0_0_0_0_0_0_1_1_0_0_0_0_0_0_0"},
	{.display_value = "AnnexJ",.submit_value =
	 "AnnexJ_0_0_0_0_0_0_0_0_0_0_0_0_0_1_1"},
};

struct value_set adsl_mode_values[] = {
	{.display_value = "Enable",.submit_value = "1"},
	{.display_value = "Disable",.submit_value = "0"}
};

struct value_set adsl_testmode_control_values[] = {
	{.display_value = "Disable",.submit_value = "Disable"},
	{.display_value = "ShowTimeLock",.submit_value = "ShowTimeLock"},
	{.display_value = "QuietMode",.submit_value = "QuietMode"}
};

struct value_set adsl_power_mgnt_control_values[] = {
	{.display_value = "L0",.submit_value = "PMCL0"},
	{.display_value = "L3",.submit_value = "PMCL3"}
};

#ifdef IFX_SMALL_FOOTPRINT
struct value_set phyconfig_config_addlmode_values[] = {
	{.display_value = "Enable_L3_Power_Mode",.submit_value = "1"},
	{.display_value = "Disable_L3_Power_Mode",.submit_value = "2"},
	{.display_value = "Quiet Mode",.submit_value = "3"},
	{.display_value = "ShowTimeLock_Mode",.submit_value = "4"}
};
#endif

struct cmd_field adsl_autoselected_mode_cmd_field[] = {
	{
	 .field_name = "adsl_mode",
	 .field_help = "This field represent the auto-selected adsl mode",
	 //.field_help="AnnexA(G991.1A,G992.2,G992.3A,G992.5A,T1.413,G992.3L,G992.3I,G992.5I,G992.3M,G992.5M),AnnexB(G992.1B,G992.3B,G992.5B,G992.3J,G992.5J),AnnexM(G992.3M,G992.5M),AnnexI(G992.3I,G992.5I),AnnexJ(G992.3J,G992.5J)",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "adsl_mode",
	 .field_gui_name = "ATU Transmission system Enabling",
	 .values = adsl_autoselected_mode_values,
	 .tot_values =
	 sizeof(adsl_autoselected_mode_values) / sizeof(struct value_set)
	 }
#if IFX_SMALL_FOOTPRINT
	,
	{
	 .field_name = "ADSL_ADDL_MODE",
	 .field_help =
	 "This field represent the additional feature of ADSL modulation",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "addlmode",
	 .field_display_name = "Additional Modulation",
	 .values = phyconfig_config_addlmod_values,
	 .tot_values =
	 sizeof(phyconfig_config_addlmod_values) / sizeof(struct value_set)
	 }
#endif
#if 0
	,
	{
	 .field_name = "ADSL_TRELLIES",
	 .field_help =
	 "This field represent the status of trellis coded modulation",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "tcmod",
	 .field_display_name = "Trellis Modulation",
	 .values = phyconfig_config_tcmod_values,
	 .tot_values =
	 sizeof(phyconfig_config_tcmod_values) / sizeof(struct value_set)
	 }
#endif
};

struct cmd_field adsl_manual_mode_cmd_field[] = {
	{
	 .field_name = "g992_1a",
	 .field_help = "G.992.1 Annex A mode",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "G992_1A",
	 .field_gui_name = "G.992.1 Annex A",
	 .values = adsl_mode_values,
	 .tot_values = sizeof(adsl_mode_values) / sizeof(struct value_set),
	 .fprocessing_post = adsl_manual_mode_cmd_fprocessing},
	{
	 .field_name = "g992_2",
	 .field_help = "G.992.2 mode",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "G992_2",
	 .field_gui_name = "G.992.2",
	 .values = adsl_mode_values,
	 .tot_values = sizeof(adsl_mode_values) / sizeof(struct value_set),
	 .fprocessing_post = adsl_manual_mode_cmd_fprocessing},
	{
	 .field_name = "g992_3a",
	 .field_help = "G.992.3 Annex A mode",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "G992_3A",
	 .field_gui_name = "G.992.3 Annex A",
	 .values = adsl_mode_values,
	 .tot_values = sizeof(adsl_mode_values) / sizeof(struct value_set),
	 .fprocessing_post = adsl_manual_mode_cmd_fprocessing},
	{
	 .field_name = "g992_5a",
	 .field_help = "G.992.5 Annex A mode",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "G992_5A",
	 .field_gui_name = "G.992.5 Annex A",
	 .values = adsl_mode_values,
	 .tot_values = sizeof(adsl_mode_values) / sizeof(struct value_set),
	 .fprocessing_post = adsl_manual_mode_cmd_fprocessing},
	{
	 .field_name = "t1_413",
	 .field_help = "T1.413 mode",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "T1_413",
	 .field_gui_name = "T1.413",
	 .values = adsl_mode_values,
	 .tot_values = sizeof(adsl_mode_values) / sizeof(struct value_set),
	 .fprocessing_post = adsl_manual_mode_cmd_fprocessing},
	{
	 .field_name = "g992_3l",
	 .field_help = "G.992.3 Annex L mode",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "G992_3L",
	 .field_gui_name = "G.992.3 Annex L",
	 .values = adsl_mode_values,
	 .tot_values = sizeof(adsl_mode_values) / sizeof(struct value_set),
	 .fprocessing_post = adsl_manual_mode_cmd_fprocessing},
	{
	 .field_name = "g992_3i",
	 .field_help = "G.992.3 Annex I mode",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "G992_3I",
	 .field_gui_name = "G.992.3 Annex I",
	 .values = adsl_mode_values,
	 .tot_values = sizeof(adsl_mode_values) / sizeof(struct value_set),
	 .fprocessing_post = adsl_manual_mode_cmd_fprocessing},
	{
	 .field_name = "g992_5i",
	 .field_help = "G.992.5 Annex I mode",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "G995_3I",
	 .field_gui_name = "G.992.5 Annex I",
	 .values = adsl_mode_values,
	 .tot_values = sizeof(adsl_mode_values) / sizeof(struct value_set),
	 .fprocessing_post = adsl_manual_mode_cmd_fprocessing},
	{
	 .field_name = "g992_3m",
	 .field_help = "G.992.3 Annex M mode",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "G992_3M",
	 .field_gui_name = "G.992.3 Annex M",
	 .values = adsl_mode_values,
	 .tot_values = sizeof(adsl_mode_values) / sizeof(struct value_set),
	 .fprocessing_post = adsl_manual_mode_cmd_fprocessing},
	{
	 .field_name = "g992_5m",
	 .field_help = "G.992.5 Annex M mode",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "G995_3M",
	 .field_gui_name = "G.992.5 Annex M",
	 .values = adsl_mode_values,
	 .tot_values = sizeof(adsl_mode_values) / sizeof(struct value_set),
	 .fprocessing_post = adsl_manual_mode_cmd_fprocessing},
	{
	 .field_name = "g992_1b",
	 .field_help = "G.992.1 Annex B mode",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "G992_1B",
	 .field_gui_name = "G.992.1 Annex B",
	 .values = adsl_mode_values,
	 .tot_values = sizeof(adsl_mode_values) / sizeof(struct value_set),
	 .fprocessing_post = adsl_manual_mode_cmd_fprocessing},
	{
	 .field_name = "g992_3b",
	 .field_help = "G.992.3 Annex B mode",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "G992_3B",
	 .field_gui_name = "G.992.3 Annex B",
	 .values = adsl_mode_values,
	 .tot_values = sizeof(adsl_mode_values) / sizeof(struct value_set),
	 .fprocessing_post = adsl_manual_mode_cmd_fprocessing},
	{
	 .field_name = "g992_5b",
	 .field_help = "G.992.5 Annex B mode",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "G992_5B",
	 .field_gui_name = "G.992.5 Annex B",
	 .values = adsl_mode_values,
	 .tot_values = sizeof(adsl_mode_values) / sizeof(struct value_set),
	 .fprocessing_post = adsl_manual_mode_cmd_fprocessing},
	{
	 .field_name = "g992_3j",
	 .field_help = "G.992.3 Annex J mode",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "G992_3J",
	 .field_gui_name = "G.992.3 Annex J",
	 .values = adsl_mode_values,
	 .tot_values = sizeof(adsl_mode_values) / sizeof(struct value_set),
	 .fprocessing_post = adsl_manual_mode_cmd_fprocessing},
	{
	 .field_name = "g992_5j",
	 .field_help = "G.992.5 Annex J mode",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "G992_5J",
	 .field_gui_name = "G.992.5 Annex J",
	 .values = adsl_mode_values,
	 .tot_values = sizeof(adsl_mode_values) / sizeof(struct value_set),
	 .fprocessing_post = adsl_manual_mode_cmd_fprocessing}
};

struct cmd_field adsl_testmode_control_cmd_field[] = {
	{
	 .field_name = "testmode_control",
	 .field_help = "This field represent the testmode control",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "testmode_control",
	 .field_gui_name = "TestMode Control",
	 .values = adsl_testmode_control_values,
	 .tot_values =
	 sizeof(adsl_testmode_control_values) / sizeof(struct value_set)
	 }
};

struct cmd_field adsl_power_mgmt_control_cmd_field[] = {
	{
	 .field_name = "power_mgmt_control",
	 .field_help = "This field represent the power management control",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "power_mgmt_control",
	 .field_gui_name = "Power Management Control",
	 .values = adsl_power_mgnt_control_values,
	 .tot_values =
	 sizeof(adsl_power_mgnt_control_values) / sizeof(struct value_set)
	 }
};

struct cmd_entry adsl_autoselected_mode_cmd = {
	.fields = adsl_autoselected_mode_cmd_field,
	.tot_fields =
	    sizeof(adsl_autoselected_mode_cmd_field) / sizeof(struct cmd_field),
	.help = "This command configures adsl autoselected mode",
	.post_url = "/goform/ifx_cgi_adsl_phyconfig",
	.custom_processing_post = adsl_phyconfig_autoselected_mode_post_flag
};

struct cmd_entry adsl_manual_mode_cmd = {
	.fields = adsl_manual_mode_cmd_field,
	.tot_fields =
	    sizeof(adsl_manual_mode_cmd_field) / sizeof(struct cmd_field),
	.help = "This command configures adsl manual mode",
	.post_url = "/goform/ifx_cgi_adsl_phyconfig",
	.custom_processing_post = adsl_phyconfig_manual_mode_post_flag
};

struct cmd_entry adsl_testmode_control_cmd = {
	.fields = adsl_testmode_control_cmd_field,
	.tot_fields =
	    sizeof(adsl_testmode_control_cmd_field) / sizeof(struct cmd_field),
	.help = "This command configures testmode control",
	.post_url = "/goform/ifx_cgi_adsl_phyconfig",
	.custom_processing_post = adsl_phyconfig_testmode_control_post_flag
};

struct cmd_entry adsl_power_mgmt_control_cmd = {
	.fields = adsl_power_mgmt_control_cmd_field,
	.tot_fields =
	    sizeof(adsl_power_mgmt_control_cmd_field) /
	    sizeof(struct cmd_field),
	.help = "This command configures testmode control",
	.post_url = "/goform/ifx_cgi_adsl_phyconfig",
	.custom_processing_post = adsl_phyconfig_power_mgnt_control_post_flag
};

struct menu_entry adsl_tone_entries[] = {
	{
	 .entry_help = "The bits allocated per tone",
	 .cli_name = "tone1",
	 .cli_url = "adsl_tone_1.cli",
	 .gui_name = "Tone No: 0~63",
	 },
	{
	 .entry_help = "The bits allocated per tone",
	 .cli_name = "tone2",
	 .cli_url = "adsl_tone_2.cli",
	 .gui_name = "Tone No: 64~127",
	 },
	{
	 .entry_help = "The bits allocated per tone",
	 .cli_name = "tone3",
	 .cli_url = "adsl_tone_3.cli",
	 .gui_name = "Tone No: 128~191",
	 },
	{
	 .entry_help = "The bits allocated per tone",
	 .cli_name = "tone4",
	 .cli_url = "adsl_tone_4.cli",
	 .gui_name = "Tone No: 192~255",
	 },
	{
	 .entry_help = "The bits allocated per tone",
	 .cli_name = "tone5",
	 .cli_url = "adsl_tone_5.cli",
	 .gui_name = "Tone No: 256~319",
	 },
	{
	 .entry_help = "The bits allocated per tone",
	 .cli_name = "tone6",
	 .cli_url = "adsl_tone_6.cli",
	 .gui_name = "Tone No: 320~383",
	 },
	{
	 .entry_help = "The bits allocated per tone",
	 .cli_name = "tone7",
	 .cli_url = "adsl_tone_7.cli",
	 .gui_name = "Tone No: 384~447",
	 },
	{
	 .entry_help = "The bits allocated per tone",
	 .cli_name = "tone8",
	 .cli_url = "adsl_tone_8.cli",
	 .gui_name = "Tone No: 448~512",
	 }
};

struct menu_page adsl_tone_page = {
	.entries = adsl_tone_entries,
	.tot_entries = sizeof(adsl_tone_entries) / sizeof(struct menu_entry),
	.page_help = "This is adsl_tone page",
	.cli_title = "ADSL Tone",.gui_title = "ADSL Tone",
};

struct menu_entry adsl_phyconfig_entries[] = {
	{
	 .entry_help = "Set ADSL Mode (auto-selected mode)",
	 .cli_name = "adsl_autoselected_mode",
	 .gui_name = "ATU Transmission system Enabling (auto-selected mode)",
	 .cmd = &adsl_autoselected_mode_cmd},
	{
	 .entry_help = "Set ADSL Mode (manual mode)",
	 .cli_name = "adsl_manual_mode",
	 .gui_name = "ATU Transmission system Enabling (manual mode)",
	 .cmd = &adsl_manual_mode_cmd},
	{
	 .entry_help = "Testmode Control",
	 .cli_name = "testmode_control",
	 .gui_name = "Testmode Control",
	 .cmd = &adsl_testmode_control_cmd},
	{
	 .entry_help = "Power Management Control",
	 .cli_name = "power_mgmt_control",
	 .gui_name = "Power Management Control",
	 .cmd = &adsl_power_mgmt_control_cmd},
	{
	 .next_page = &adsl_tone_page,
	 .entry_help = "The bits allocated per tone",
	 .cli_name = "tone",
	 .gui_name = "The bits allocated per tone"}
};

struct menu_page adsl_phyconfig_page = {
	.entries = adsl_phyconfig_entries,
	.tot_entries =
	    sizeof(adsl_phyconfig_entries) / sizeof(struct menu_entry),
	.page_help = "This is adsl_phyconfig page",
	.cli_title = "ADSL PHY Config",.gui_title = "ADSL PHY Config",
};

struct menu_entry adsl_status_entries[] = {
	{
	 .entry_help = "Shows ATU-C System Verdor Information",
	 .cli_name = "VendorID",.cli_url = "adsl_line_vendorid.cli",
	 },
	{
	 .entry_help = "Shows ADSL Line Configuraton and Status",
	 .cli_name = "Status",.cli_url = "adsl_line_status.cli",
	 },
	{
	 .entry_help = "Shows ADSL Line Rates",
	 .cli_name = "Rate",.cli_url = "adsl_line_rate.cli"},
	{
	 .entry_help = "Shows ADSL Line Information",
	 .cli_name = "Info",.cli_url = "adsl_line_info.cli",
	 .gui_name = "Information",
	 },
	{
	 .entry_help = "Shows ADSL Line Performance",
	 .cli_name = "Perf",.cli_url = "adsl_line_perf.cli",
	 },
#if 0
	{
	 .entry_help = "This command displays adsl status",
	 .cli_name = "Show",.cli_url = "adsl_status.cli",
	 .gui_name = "ADSL staus show",.gui_url = "adsl_status.asp"}
#endif
};

struct menu_page adsl_status_page = {
	.entries = adsl_status_entries,
	.tot_entries = sizeof(adsl_status_entries) / sizeof(struct menu_entry),
	.page_help = "The adsl staus page",
	.cli_title = "ADSL Status page",.gui_title = "ADSL Status page"
};

struct menu_entry adsl_page_entries[] = {
	{
	 .next_page = &adsl_status_page,
	 .entry_help = "The adsl status",.cli_name = "status",
	 .gui_name = "ADSL Staus",.gui_url = "adsl.asp"},
	{
	 .next_page = &adsl_phyconfig_page,
	 .entry_help = "The ADSL Phyconfig",
	 .cli_name = "phyconfig",
	 .gui_name = "ADSL Phyconfig",.gui_url = "adsl_phyconfig.asp"}
};

struct menu_page adsl_page = {
	.entries = adsl_page_entries,
	.tot_entries = sizeof(adsl_page_entries) / sizeof(struct menu_entry),
	.page_help = "The adsl page",.cli_title = "adsl page",
	.gui_title = "ADSL Page",.fpos = 1
};
#endif
