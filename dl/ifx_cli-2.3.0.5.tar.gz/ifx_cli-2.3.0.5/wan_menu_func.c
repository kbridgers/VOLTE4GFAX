
/* ============================================================================
 * Copyright (C) 2005 -Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 *============================================================================
 *
 * This document contains proprietary information belonging to Infineon 
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 * 
 * ============================================================================
 */

/* ===========================================================================
 *
 * File Name:   adsl_menu_func.c
 * Author :     Nirav Salot
 * Date: 		April, 2005
 *
 * ===========================================================================
 *
 * Project: Amazon
 *
 * ===========================================================================
 * Contents: This file implements ADSL menu related specific functions.
 *  
 * ===========================================================================
 * References: 
 *
 */
#include <stdio.h>
#include <string.h>
#include "common.h"

int validate_password(struct cmd_entry *cmd, char *errstr);
int validate_vlan(struct cmd_entry *cmd, char *errstr);

int validate_vlan_and_password(struct cmd_entry *cmd, char *errstr)
{
	if (validate_password(cmd, errstr) == 0) {
		if (validate_vlan(cmd, errstr) == 0)
			return 0;
	}
	return 1;
}

int validate_password(struct cmd_entry *cmd, char *errstr)
{
	struct cmd_field *ps_field;
	struct cmd_field *re_field;
	struct cmd_field *reconnect_field;
	struct cmd_field *idle_time_field;
	struct cmd_field *mtu_field;

	ps_field = get_field_entry(cmd, "PW");
	re_field = get_field_entry(cmd, "PWV");
	reconnect_field = get_field_entry(cmd, "reconnect");
	idle_time_field = get_field_entry(cmd, "IDLE");
	mtu_field = get_field_entry(cmd, "MTU");

	if (strcmp(ps_field->cur_value, re_field->cur_value)) {
		sprintf(errstr, "Passwords do not match\n");
		return 1;
	}

	if (reconnect_field == NULL) {
		return 1;
	} else {
		if (reconnect_field->cur_value == NULL) {
			return 1;
		}
		if (!strcmp(reconnect_field->cur_value, "on")) {
			if (idle_time_field == NULL) {
				sprintf(errstr,
					"Please enter value for Reconnect\n");
				return 1;
			}
			if (idle_time_field->cur_value == NULL) {
				sprintf(errstr,
					"Please enter value for Reconnect\n");
				return 1;
			}
		}
	}

	if (mtu_field == NULL) {
		return 1;
	} else {
		if (mtu_field->cur_value == NULL) {
			return 1;
		}

		if (atoi(mtu_field->cur_value) < 1400
		    || atoi(mtu_field->cur_value) > 1500) {
			sprintf(errstr,
				"Please enter value for MTU in the range [1400..1500]\n");
			return 1;
		}
	}

	return 0;
}

int wan_config_cmd_post_flag(struct cmd_entry *cmd, char *poststr)
{
	struct cmd_field *field_wanid = get_field_entry(cmd, "WAN");
	struct cmd_field *field_wantype = get_field_entry(cmd, "WT");
	struct cmd_field *field_wanvcc = get_field_entry(cmd, "vcChannel");
	struct value_set *wanvcc_vset = NULL;
	struct value_set *wanid_vset = NULL;
	int nWAN_IDX = 0;
	char *pWAN_TYPE = NULL;
	char str[32];
	char sTYPE[MAX_DATA_LEN];
	char sWAN_TYPE[MAX_DATA_LEN];
	char sWAN_VCC[MAX_DATA_LEN];
#if 1				//hsumc
	//char sWAN_TAG[MAX_DATA_LEN];
	// char sCommand[MAX_FILELINE_LEN];
#endif
	char *pWAN_VCC = NULL;
	int i;

	for (i = 0, wanid_vset = field_wanid->values;
	     i < field_wanid->tot_values; i++, wanid_vset++) {
		if (strcmp(wanid_vset->display_value, field_wanid->cur_value) ==
		    0) {
			nWAN_IDX = atoi(wanid_vset->submit_value);
			break;
		}
	}

	pWAN_TYPE = field_wantype->cur_value;
	for (i = 0, wanvcc_vset = field_wanvcc->values;
	     i < field_wanvcc->tot_values; i++, wanvcc_vset++) {
		if (strcmp(wanvcc_vset->display_value, field_wanvcc->cur_value)
		    == 0)
			pWAN_VCC = wanvcc_vset->submit_value;
	}
	memset(str, 0x00, sizeof(str));
	//hsumc 
	snprintf(str, sizeof(str), "WAN_VCC=\"%d\"\n", nWAN_IDX);
	printf("%s : WAN_VCC = %s\n", __FUNCTION__, str);
	ifx_SetCfgData(FILE_SYSTEM_STATUS, "http_wan_vcc_select", 1, str);

	memset(sTYPE, 0x00, sizeof(sTYPE));
	switch (atoi(pWAN_TYPE)) {
	case 1:
		sprintf(sTYPE, "DHCPC");
		break;
	case 2:
		sprintf(sTYPE, "FIXED");
		break;
	case 3:
		sprintf(sTYPE, "PPPOE");
		break;
	case 4:
		sprintf(sTYPE, "PPPOA");
		break;
	case 5:
		sprintf(sTYPE, "BRIDGE");
		break;
	case 0:
	default:
		sprintf(sTYPE, "UNKNOWN");
		break;
	}

	if (atoi(pWAN_TYPE) != IP_BOOT_UNKNOWN) {
		sprintf(sWAN_TYPE, "ipoption_wan=\"%s\"\n", sTYPE);
		sprintf(sWAN_VCC, "WAN_VCC=\"%s\"\n", pWAN_VCC);
		ifx_SetCfgData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, 2, sWAN_TYPE,
			       sWAN_VCC);
	}
	strcat(poststr, "dummy=0");
	return 0;
}

int pppoea_config_reconnect_post(struct cmd_field *cur_field, char *poststr)
{
	if (strcmp(cur_field->cur_value, "on") == 0)
		strcat(poststr, "reconnect=1");
	else
		strcat(poststr, "norecon=0");
	return 0;
}

int pppoe_config_relay_post(struct cmd_field *cur_field, char *poststr)
{
	if (strcmp(cur_field->cur_value, "on") == 0)
		strcat(poststr, "relay=1");
	else
		strcat(poststr, "relay=0");
	return 0;
}

#define MAX_FIELD_LEN  256
#define INT_STR_LEN 64
#if 0
int get_value_set_modified(struct value_set **pp_value_set, int *p_num_entries)
{
	char sValue[MAX_FIELD_LEN];
	char command[MAX_FIELD_LEN];
	char *fvpair;
	int nChannel_Size = 0;
	int i = 0, temp = 0;
	int Encp_mode, VPI_value, VCI_value, QoS_mode;
	struct value_set *p_value_set_entry;

	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, T("VCChannelCount"),
	     sValue) == 0) {
		printf("VCC entries not found !\n");
		return -1;
	}

	nChannel_Size = atoi(sValue);

	*pp_value_set =
	    calloc(nChannel_Size, sizeof(**pp_value_set) * nChannel_Size);
	if (*pp_value_set == NULL) {
		return -1;
	}

	for (i = 0; i < nChannel_Size; i++) {
		sprintf(command, "VCChannel%d", i);
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, command, sValue) == 0) {
			printf("ADSL VCC entry  not found\n");
			return -1;
		}
		sscanf(sValue, "%d_%d/%d_%d", &Encp_mode, &VPI_value,
		       &VCI_value, &QoS_mode);
		fvpair = strchr(sValue, ',');
		p_value_set_entry = &(*pp_value_set[i]);
		p_value_set_entry->display_value =
		    calloc(INT_STR_LEN * 2 + 1, 1);
		if (p_value_set_entry->display_value == NULL) {
			temp = i;
			free_cmd_fvset(*pp_value_set, p_num_entries);
			return -1;
		}
		sprintf(p_value_set_entry->display_value, "%d/%d", VPI_value,
			VCI_value);
		p_value_set_entry->submit_value = calloc(INT_STR_LEN, 1);
		if (p_value_set_entry->submit_value == NULL) {
			temp = i;
			free_cmd_fvset(*pp_value_set, p_num_entries);
			return -1;
		}
		if (fvpair != NULL)
			sprintf(p_value_set_entry->submit_value,
				"%d_%d/%d_%d_%s%s", Encp_mode, VPI_value,
				VCI_value, QoS_mode,
				Encp_mode == 0 ? "LLC/SNAP" : "VcMux", fvpair);
		else
			sprintf(p_value_set_entry->submit_value,
				"%d_%d/%d_%d_%s", Encp_mode, VPI_value,
				VCI_value, QoS_mode,
				Encp_mode == 0 ? "LLC/SNAP" : "VcMux");
//get_atm_qos_by_id(QoS_mode)

	}

	return (0);
}
#endif
/*
 * #define MAX_FIELD_LEN  256
 * #define INT_STR_LEN 10
 * */

int get_vpivci_fvset(struct value_set **pp_value_set, int *p_num_entries)
{
	char sValue[MAX_FIELD_LEN];
	char command[MAX_FIELD_LEN];
	char *fvpair;
	int nChannel_Size = 0;
	int i = 0;
	int uTemp = 0;
	int Encp_mode, VPI_value, VCI_value, QoS_mode;
	struct value_set *p_value_set_entry;

	memset(sValue, 0x00, sizeof(sValue));

	//hsumc if (ifx_GetCfgData(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, T("VCChannelCount"), sValue) == 0)
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, T("adsl_vcchannel_Count"),
	     sValue) == 0) {
		printf("VCC entries not found !\n");
		return -1;
	}

	nChannel_Size = atoi(sValue);

	//*pp_value_set = calloc(sizeof(**pp_value_set),nChannel_Size);
	//if (*pp_value_set == NULL) {
	//      return -1;
	//}

	*pp_value_set = 0;
	*p_num_entries = 0;
	for (i = 0; i < nChannel_Size; i++) {
		//hsumc sprintf(command,"VCChannel%d",i);
		sprintf(command, "VCChannel_%d_vcc", i);
		memset(sValue, 0x00, sizeof(sValue));
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, command, sValue) == 0) {
			printf("ADSL VCC entry  not found\n");
			return -1;
		}
		//hsumc sscanf(sValue,"%d_%d/%d_%d",&Encp_mode,&VPI_value,&VCI_value,&QoS_mode);

		sscanf(sValue, "%d/%d", &VPI_value, &VCI_value);

		sprintf(command, "VCChannel_%d_encap", i);
		memset(sValue, 0x00, sizeof(sValue));
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, command, sValue) == 0) {
			printf("ADSL ENCAP entry  not found\n");
			return -1;
		}
		//hsumc sscanf(sValue,"%d_%d/%d_%d",&Encp_mode,&VPI_value,&VCI_value,&QoS_mode);
		sscanf(sValue, "%d", &Encp_mode);

		sprintf(command, "VCChannel_%d_qos", i);
		memset(sValue, 0x00, sizeof(sValue));
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, command, sValue) == 0) {
			printf("ADSL QoS entry  not found\n");
			return -1;
		}
		//hsumc sscanf(sValue,"%d_%d/%d_%d",&Encp_mode,&VPI_value,&VCI_value,&QoS_mode);
		sscanf(sValue, "%d", &QoS_mode);

		if (VPI_value != 256) {
			*pp_value_set =
			    realloc(*pp_value_set,
				    sizeof(**pp_value_set) * (i - uTemp + 1));
			*p_num_entries = i - uTemp + 1;
			if (*pp_value_set == NULL) {
				return -1;
			}
			fvpair = strchr(sValue, ',');
			p_value_set_entry = (*pp_value_set) + i - uTemp;
			p_value_set_entry->display_value =
			    calloc(INT_STR_LEN, 1);
			if (p_value_set_entry->display_value == NULL) {
				return -1;
			}
			sprintf(p_value_set_entry->display_value, "%d.%d",
				VPI_value, VCI_value);
			p_value_set_entry->submit_value =
			    calloc(INT_STR_LEN, 1);
			if (p_value_set_entry->submit_value == NULL) {
				return -1;
			}
			if (fvpair != NULL)
				//hsumcsprintf(p_value_set_entry->submit_value, "%d_%d/%d_%d_%s%s", Encp_mode, VPI_value, VCI_value, QoS_mode,Encp_mode==0?"LLC/SNAP":"VcMux",fvpair);
				sprintf(p_value_set_entry->submit_value,
					"%d/%d,%s%s", VPI_value, VCI_value,
					Encp_mode == 0 ? "LLC/SNAP" : "VcMux",
					fvpair);
			else
				//hsumc sprintf(p_value_set_entry->submit_value, "%d_%d/%d_%d_%s", Encp_mode, VPI_value, VCI_value, QoS_mode,Encp_mode==0?"LLC/SNAP":"VcMux");
				sprintf(p_value_set_entry->submit_value,
					"%d/%d,%s", VPI_value, VCI_value,
					Encp_mode == 0 ? "LLC/SNAP" : "VcMux");
		} else {
			uTemp++;
		}
	}

	return (0);
}

int f5_cmd_vpivci_fprocessing(struct cmd_field *cur_field, char *poststr)
{
#if 0
	struct value_set *vpivci_valueset = cur_field->values;
	int i = 0;
#endif
	char *str = NULL;
	char *strvpivci = NULL;

#if 0
	for (i = 0; i < cur_field->tot_values; i++, vpivci_valueset++) {
		if (strcmp(vpivci_valueset->display_value, cur_field->cur_value)
		    == 0)
			strvpivci = vpivci_valueset->submit_value;
	}
#else
	strvpivci = cur_field->cur_value;
#endif
	str = strtok(strvpivci, ".");
	strcat(poststr, "OAM_F5_VPI_CHANNEL=");

	if (str)
		strcat(poststr, str);

	strcat(poststr, "&OAM_F5_VCI_CHANNEL=");
	str = strtok(NULL, ".");

	if (str)
		strcat(poststr, str);
	return 0;
}

int adsl_vcconfig_add_post_flag(struct cmd_entry *p, char *poststr)
{
	strcat(poststr, "submit_action=addVPIVCI");
	return 0;
}

int validate_oam_vcc(struct cmd_entry *p, char *errstr)
{
	int vpi = 0, vci = 0;
	struct cmd_field *p_vpi, *p_vci;

	if (errstr) {
		errstr[0] = '\0';
	}

	p_vpi = get_field_entry(p, "OAM_F5_VPI_CHANNEL");
	p_vci = get_field_entry(p, "OAM_F5_VCI_CHANNEL");

	if (!p_vci || !p_vpi) {
		if (errstr)
			strcpy(errstr, "Internal CLI error !\n");
		return IFX_ERR;
	}
	if ((!strcasecmp(p_vpi->cur_value, "TR037"))
	    || (!strcasecmp(p_vpi->cur_value, "ILMI"))) {
		if ((!strcasecmp(p_vci->cur_value, "TR037"))
		    || (!strcasecmp(p_vci->cur_value, "ILMI"))) {
			/* Backend expects it to be uppercase only */
			strcpy(p_vpi->cur_value, "TR037");
			strcpy(p_vci->cur_value, "TR037");
			return IFX_OK;
		}
	}
	errno = 0;
	vpi = strtol(p_vpi->cur_value, NULL, 10);
	if (errno == EINVAL || errno == ERANGE || vpi < 0 || vpi > 255) {
		if (errstr)
			strcpy(errstr, "Invalid VPI value. Range [0-255]!\n");
		return IFX_ERR;
	}
	vci = strtol(p_vci->cur_value, NULL, 10);
	if (errno == EINVAL || errno == ERANGE || vci < 32 || vci > 65535) {
		if (errstr)
			strcpy(errstr,
			       "Invalid VCI value. Range [32-65535]!\n");
		return IFX_ERR;
	}

	/* XXX: Hack to handle ILMI/TR037 VCI.
	 * For now, we just sneak in and change the values of vpi and vci in
	 * the field structure. Later, we should atleast use the VPI/VCI values
	 * from configured data! - Ritesh
	 */
	if (vpi == 0 && vci == 16) {
		IFX_FREE(p_vpi->cur_value);
		IFX_FREE(p_vci->cur_value);
		p_vpi->cur_value = calloc(strlen("TR037") + 1, 1);
		p_vci->cur_value = calloc(strlen("TR037") + 1, 1);
		if (!p_vpi->cur_value || !p_vci->cur_value) {
			if (errstr)
				strcpy(errstr, "Error : Out of memory!\n");
			return IFX_ERR;
		}
		strcpy(p_vci->cur_value, "TR037");
		strcpy(p_vpi->cur_value, "TR037");
	}

	return IFX_OK;
}

int adsl_vcconfig_add_custom_valid(struct cmd_entry *cmd, char *errstr)
{
	char sValue[MAX_FIELD_LEN];
	char command[MAX_FIELD_LEN];
	int nChannel_Size = 0;
	int i = 0;
	int VPI_value, VCI_value;
	struct cmd_field *cur_field;

	memset(sValue, 0x00, sizeof(sValue));
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, T("adsl_vcchannel_Count"),
	     sValue) == 0)
		//hsumc if (ifx_GetCfgData(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, T("VCChannelCount"), sValue) == 0)
	{
		strcat(errstr, "VCC entries not found !\n");
		return 1;
	}

	nChannel_Size = atoi(sValue);
	cur_field = get_field_entry(cmd, "vcSetting");

	sscanf(cur_field->cur_value, "%d/%d", &VPI_value, &VCI_value);
	if (VPI_value < 0 || VPI_value > 255) {
		sprintf(errstr,
			"Error : Wrong VPI value[%d]. VPI value should be in the range [0-255]\n",
			VPI_value);
		return 1;
	}
	if (VCI_value < 32 || VCI_value > 65535) {
		sprintf(errstr,
			"Error : Wrong VCI value[%d]. VCI value should be in the range [32-65535]\n",
			VCI_value);
		return 1;
	}
	if (VPI_value == 0 && VCI_value == 0) {
		sprintf(errstr, "%s", "Error : wrong VPI/VCI[0/0] value\n");
		return 1;
	}

	for (i = 0; i < nChannel_Size; i++) {
		char temp[16];
		//hsumc sprintf(command,"VCChannel%d",i);
		sprintf(command, "VCChannel_%d_vcc", i);
		memset(sValue, 0x00, sizeof(sValue));
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, command, sValue) == 0) {
			strcat(errstr, "ADSL VCC entry  not found\n");
			return 1;
		}
		sscanf(sValue, "%d/%d", &VPI_value, &VCI_value);
		//hsumc sscanf(sValue,"%d_%d/%d_%d",&Encp_mode,&VPI_value,&VCI_value,&QoS_mode);
		memset(temp, 0x00, sizeof(temp));
		snprintf(temp, sizeof(temp), "%d/%d", VPI_value, VCI_value);
		printf("checking [%s] and [%s] !\n", temp,
		       cur_field->cur_value);
		if (strcmp(cur_field->cur_value, temp) == 0) {
			strcat(errstr,
			       "Error : This VPI/VCI entry is already present\n");
			return 1;
		}
	}

	return 0;
}

int adsl_vcconfig_del_post_flag(struct cmd_entry *cmd, char *poststr)
{
	char sValue[MAX_FIELD_LEN];
	char command[MAX_FIELD_LEN];
	char temp[16];
	//char  *sValues = NULL;
	//char  *vcSetting = NULL;
	int nChannel_Size = 0;
	int i = 0;
	char *cur_ch;
	//int           Encp_mode;
	//int   QoS_mode;
	char tem[4];
	//int           VPI_value, VCI_value;
	struct cmd_field *cur_field = NULL;

	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, T("adsl_vcchannel_Count"),
	     sValue) == 0)
		//hsumc if (ifx_GetCfgData(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, T("VCChannelCount"), sValue) == 0)
	{
		printf("VCC entries not found !\n");
		return 1;
	}

	nChannel_Size = atoi(sValue);
	cur_field = get_field_entry(cmd, "vpivci_value");
	cur_ch = cur_field->cur_value;
	for (i = 0; i < nChannel_Size; i++) {
		memset(sValue, 0x00, sizeof(sValue));
		memset(tem, 0x00, sizeof(tem));

		//hsumc sprintf(command,"VCChannel%d",i);
		sprintf(command, "VCChannel_%d_vcc", i);
		memset(sValue, 0x00, sizeof(sValue));
		memset(temp, 0x00, sizeof(temp));
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, command, sValue) == 0) {
			printf("ADSL VCC entry  not found\n");
			return 1;
		}

		if (!(strncmp(sValue, cur_ch, strlen(cur_ch)))) {
			sprintf(temp, "vcChannel=%s", cur_ch);
			strcat(poststr, temp);

			sprintf(command, "VCChannel_%d_cpeId", i);
			memset(sValue, 0x00, sizeof(sValue));
			memset(temp, 0x00, sizeof(temp));
			if (ifx_GetCfgData
			    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, command,
			     sValue) == 0) {
				printf("ADSL VCC entry  not found\n");
				return 1;
			}
			snprintf(temp, sizeof(temp), "&remove%d=1",
				 atoi(sValue));
			strlcat(poststr, temp, sizeof(temp));
			strcat(poststr, "&submit_action=delVPIVCI");
			IFX_DBG("-- %s", poststr);
			return 0;
		}
	}

	strcpy(poststr, "Error : Invalid Index of vpi/vci pair\n");
	return (1);
}

int validate_test_oam(struct cmd_entry *p, char *poststr)
{
	//struct value_set *v_set;
	//int entries = 0;
	int i = 0;
	struct cmd_field *cur_field = NULL;
	char sValue[40], command[40];
	char loopback[MAX_FIELD_LEN], continuity[MAX_FIELD_LEN],
	    VPI_value[MAX_FIELD_LEN], VCI_value[MAX_FIELD_LEN],
	    f5_time[MAX_FIELD_LEN], direction[MAX_FIELD_LEN];
	char temp[10];		//, *value;
	char *cur_ch;
	int nChannel_Size = 0;

	strcat(poststr, "submit_action=testF5");

	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_ADSL_OAM_F5, T("adsl_oam_f5_Count"),
	     sValue) == 0) {
		printf("OAM entries not found !\n");
		return 1;
	}

	nChannel_Size = atoi(sValue);

	cur_field = get_field_entry(p, "testVPIVCI");
	if (cur_field == NULL) {
		strcpy(poststr, "Error : vpi vci not present!\n");
		return 1;
	}

	cur_ch = cur_field->cur_value;
	if (cur_ch == NULL) {
		strcpy(poststr, "Error : vpi vci not present!\n");
		return 1;
	}

	for (i = 0; i < nChannel_Size; i++) {
		memset(sValue, 0x00, sizeof(sValue));
		memset(temp, 0x00, sizeof(temp));

		sprintf(command, "adsl_oam_f5_%d_vpi", i);
		memset(sValue, 0x00, sizeof(sValue));
		memset(temp, 0x00, sizeof(temp));

		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_ADSL_OAM_F5, command, VPI_value) == 0) {
			printf("ADSL OAM entry  not found\n");
			return 1;
		}

		sprintf(command, "adsl_oam_f5_%d_vci", i);
		ifx_GetCfgData(FILE_RC_CONF, TAG_ADSL_OAM_F5, command,
			       VCI_value);

		sprintf(command, "adsl_oam_f5_%d_loopback", i);
		ifx_GetCfgData(FILE_RC_CONF, TAG_ADSL_OAM_F5, command,
			       loopback);

		sprintf(command, "adsl_oam_f5_%d_contCheck", i);
		ifx_GetCfgData(FILE_RC_CONF, TAG_ADSL_OAM_F5, command,
			       continuity);

		sprintf(command, "adsl_oam_f5_%d_contCheckOpt", i);
		ifx_GetCfgData(FILE_RC_CONF, TAG_ADSL_OAM_F5, command,
			       direction);

		sprintf(command, "adsl_oam_f5_%d_timeout", i);
		ifx_GetCfgData(FILE_RC_CONF, TAG_ADSL_OAM_F5, command, f5_time);

		snprintf(temp, sizeof(temp), "%s/%s", VPI_value, VCI_value);
		if (!(strcmp(cur_ch, temp))) {
			strcat(poststr, "&OAM_F5_VPI_CHANNEL=");
			strcat(poststr, VPI_value);
			strcat(poststr, "&OAM_F5_VCI_CHANNEL=");
			strcat(poststr, VCI_value);
			strcat(poststr, "&OAM_F5_LOOPBACK=");
			strcat(poststr, loopback);
			strcat(poststr, "&OAM_F5_CCheck=");
			strcat(poststr, continuity);
			strcat(poststr, "&OAM_F5_CC_OPT=");
			strcat(poststr, direction);
			strcat(poststr, "&OAM_F5_TIME=");
			strcat(poststr, f5_time);
			strcat(poststr, "&OAM_F5_TX_CELLS=5");	/* hard coded, since we don't ask for these values from user currently */
			return 0;
		}
	}
	return 1;
}

int validate_vlan(struct cmd_entry *cmd, char *errstr)
{
	struct cmd_field *vid_field;
	struct cmd_field *vprio_field;

	vid_field = get_field_entry(cmd, "VID");
	vprio_field = get_field_entry(cmd, "VPRIO");

	if (vid_field != NULL) {
		if (vid_field->cur_value != NULL) {
			if ((atoi(vid_field->cur_value) < 1)
			    || (atoi(vid_field->cur_value) > 4095)) {
				sprintf(errstr,
					"Please enter value for VID in the range [1..4095]\n");
				return 1;
			}
		}
	}

	if (vprio_field != NULL) {
		if (vprio_field->cur_value != NULL) {
			if (strlen(vprio_field->cur_value) > 4
			    || strlen(vprio_field->cur_value) == 0) {
				sprintf(errstr,
					"Maximum length for VPIO is 4\n");
				return 1;
			}
		}
	}

	return 0;
}
