
/* ============================================================================
 * Copyright (C) 2005 -Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 *============================================================================
 *
 * This document contains proprietary information belonging to Infineon 
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 * 
 * ============================================================================
 */

#include <stdio.h>
#include <string.h>
#include "common.h"

int validate_password_in_tr69(struct cmd_entry *cmd, char *errstr)
{
	struct cmd_field *ps_field;
	struct cmd_field *re_field;

	ps_field = get_field_entry(cmd, "APW");
	re_field = get_field_entry(cmd, "APWV");

	if (strcmp(ps_field->cur_value, re_field->cur_value))
		return 1;
	return 0;
}

int tr69_config_cmd_post(struct cmd_entry *cmd, char *poststr)
{

	return 0;
}

int tr69_set_cmd_post(struct cmd_entry *cmd, char *poststr)
{
	return 0;
}
