int validate_password_in_tr69(struct cmd_entry *cmd, char *errstr);
