/* ============================================================================
 * Copyright (C) 2005 -Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 *============================================================================
 *
 * This document contains proprietary information belonging to Infineon 
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 * 
 * ============================================================================
 */

/* ===========================================================================
 *
 * File Name:   cli_be.c
 * Author :     Nirav Salot
 * Date: 		April, 2005
 *
 * ===========================================================================
 *
 * Project: Amazon
 *
 * ===========================================================================
 * Contents: This file implements the CLI backend infrastructure which provides
 * all the CLI processing capabilities. The CLI frontend (cli_fe) interacts
 * with the cli_be and in turn, cli_be interacts with the web server.
 *  
 * ===========================================================================
 * References: 
 *
 */

/* ===========================================================================
 * Revision History:
 *
 * $Log$
 * ===========================================================================
 */
#include <stdio.h>
#include <string.h>
#include <common.h>
#include "firewall_menu_func.h"
#define MAX_FIELD_LEN  256

int firewall_macctrl_del_post_flag(struct cmd_entry *cmd, char *poststr)
{
	char *macAddr = NULL;
	char foundstr[64];
	//int delindex = -1;
	char sValue[MAX_FIELD_LEN];
	char command[MAX_FIELD_LEN];
	int i, nChannel_Size = 0;

	macAddr = get_field_entry(cmd, "macfilterAdd")->cur_value;
	memset(foundstr, 0x00, sizeof(foundstr));

	if (ifx_GetCfgData(FILE_RC_CONF, "firewall_mac", T("PC_Count"), sValue)
	    == 0) {
		printf("No MAC entries found !\n");
		return -1;
	}
	nChannel_Size = atoi(sValue);

	for (i = 0; i < nChannel_Size; i++) {
		sprintf(command, "PC_MACADDR%d", i);
		ifx_GetCfgData(FILE_RC_CONF, "firewall_mac", command, sValue);
		if (strncmp(sValue, macAddr, strlen(sValue))) {
			continue;
		}

		sprintf(command, "delindex=%d", i);
		strcat(poststr, command);
		return 0;
	}

	printf("Could not found the MAC to be deleted\n");
	sprintf(poststr, "Could not found the MAC to be deleted\n");
	return -1;

	/*
	   delindex = getindex("MAC_DENY_", macAddr, 0, foundstr);
	   if(delindex >= 0)
	   {
	   char strIndex[4];

	   printf("macCtrl_del_post_flag : MacAddress to be deleted [%s]\n",foundstr);
	   memset(strIndex,0x00,sizeof(strIndex));
	   sprintf(strIndex,"%d",delindex);
	   strcat(poststr,"delindex=");
	   strcat(poststr,strIndex);
	   } else
	   {
	   printf("Could not find the MacAddress to be deleted\n");
	   sprintf(poststr,"Error : Could not find the MacAddress to be deleted\n");
	   return -1;
	   } */

}

int firewall_packetfilter_del_post(struct cmd_entry *cmd, char *poststr)
{
	struct cmd_field *index_field = get_field_entry(cmd, "index");
	char sValue[256];
	char sCommand[128];
	char temp[16];
	int nCount = 0;

	memset(sCommand, 0x00, sizeof(sCommand));
	memset(sValue, 0x00, sizeof(sValue));
	sprintf(sCommand, "grep \"^%sCount\" %s | cut -f2 -d'\"'",
		PREFIX_FIREWALL_PACKETFILTER, FILE_RC_CONF);
	if (ifx_GetCfgData(sCommand, NULL, "1", sValue) == 0) {
		sprintf(poststr, "Error : Could not find %sCount from %s\n",
			PREFIX_FIREWALL_PACKETFILTER, FILE_RC_CONF);
		return -1;
	}

	nCount = atoi(sValue);
	if (nCount <= 0) {
		strcpy(poststr, "Error : No rules added to be deleted\n");
		return -1;
	}
	if (nCount < atoi(index_field->cur_value)
	    || atoi(index_field->cur_value) <= 0) {
		sprintf(poststr,
			"Error : Please enter a no. between 1-%d only\n",
			nCount);
		printf("%s : %s\n", __FUNCTION__, poststr);
		return -1;
	}
	nCount = atoi(index_field->cur_value);
	nCount--;
	memset(temp, 0x00, sizeof(temp));
	sprintf(temp, "%d", (int16_t) nCount);
	strcat(poststr, "delindex=");
	strlcat(poststr, temp, sizeof(temp));
	return 0;
}

int packetfilter_add_valid(struct cmd_entry *cmd, char *errstr)
{
	struct cmd_field *cur_field = NULL;
	char *proto;
	int st_port = 0;
	int end_port = 0;

	cur_field = get_field_entry(cmd, "PF_TYPE_ADD");
	proto = cur_field->cur_value;

	cur_field = get_field_entry(cmd, "PF_PORT_SRC_START_ADD");
	if (cur_field->cur_value)
		st_port = atoi(cur_field->cur_value);
	cur_field = get_field_entry(cmd, "PF_PORT_SRC_END_ADD");
	if (cur_field->cur_value)
		end_port = atoi(cur_field->cur_value);

	if (!strcmp(proto, "tcp") || !strcmp(proto, "udp"))
		if (st_port > end_port) {
			strcpy(errstr,
			       "Error : Source Port1 should be less than Source Port2\n");
			return 1;
		}

	cur_field = get_field_entry(cmd, "PF_PORT_DST_START_ADD");
	st_port = 0;
	end_port = 0;
	if (cur_field->cur_value)
		st_port = atoi(cur_field->cur_value);
	cur_field = get_field_entry(cmd, "PF_PORT_DST_END_ADD");
	if (cur_field->cur_value)
		end_port = atoi(cur_field->cur_value);

	if (!strcmp(proto, "tcp") || !strcmp(proto, "udp"))
		if (st_port > end_port) {
			strcpy(errstr,
			       "Error : Destination Port1 should be less than Destination Port2\n");
			return 1;
		}

	return 0;
}
