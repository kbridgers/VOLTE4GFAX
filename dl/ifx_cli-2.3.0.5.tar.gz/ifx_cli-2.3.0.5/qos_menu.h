/*
000001:tc.chen 2005/06/07 add IP QoS and 802.1P priority queue
*/

#include "qos_menu_func.h"	//000001:tc.chen

struct value_set qos_diffserv_cmd_values[] = {
	{.display_value = "disable",.submit_value = "0"},
	{.display_value = "enable",.submit_value = "1"}
};

/* 000001:tc.chen 
struct cmd_field qos_diffserv_cmd_fields[] =
		{
			{
				.field_name="DsVs",
				.field_help="Represents the qos status of qos virtual server",
				.data_type=STR, .field_type=STATIC, .mandatory=IFX_FALSE,
				.field_display_name="DsVs",
				.field_gui_name="Status",
				.values=qos_diffserv_cmd_values,
				.tot_values=sizeof(qos_diffserv_cmd_values)/sizeof(struct value_set)
			}
		};

struct cmd_entry qos_diffserv_cmd =
		{
			.fields=qos_diffserv_cmd_fields,
			.tot_fields=sizeof(qos_diffserv_cmd_fields)/sizeof(struct cmd_field),
			.help="This command configures qos virtual server",
			.post_url="/goform/ifx_set_qos_diffserv_setting",
			.get_url="qos_diffserv.cli"
		};	

struct menu_entry qos_diffserv_entries[] =
		{
			{
				.entry_help="This is qos_diffserv show_entry",
				.cli_name="Show", .cli_url="qos_diffserv.cli"
			},
			{
				.entry_help="This is qos_diffserv config_entry",
				.cli_name="Config", .cmd=&qos_diffserv_cmd
			}
		};
*/

// 000001:tc.chen start
#ifdef CONFIG_FEATURE_QOS_PRIORITY_QUEUE
#ifdef CONFIG_FEATURE_QOS_IPPTOS
struct value_set qos_prio_IPPTOS_cmd_values[] = {
	{.display_value = "disable",.submit_value = "0"},
	{.display_value = "enable",.submit_value = "1"}
};
#endif				//IFX_CONIFG_QOS_IPPTOS
#ifdef CONFIG_FEATURE_QOS_8021P
struct value_set qos_prio_8021p_cmd_values[] = {
	{.display_value = "disable",.submit_value = "0"},
	{.display_value = "enable",.submit_value = "1"}
};
#endif				//IFX_CONIFG_QOS_8021P
struct value_set qos_prioity_queue_cmd_values[] = {
	{.display_value = "disable",.submit_value = "0"},
	{.display_value = "enable",.submit_value = "1"}
};

struct value_set qos_priority_add_priority_values[] = {
	{.display_value = "0",.submit_value = "0"},
	{.display_value = "1",.submit_value = "1"},
	{.display_value = "2",.submit_value = "2"},
	{.display_value = "3",.submit_value = "3"},
	{.display_value = "4",.submit_value = "4"},
	{.display_value = "5",.submit_value = "5"},
	{.display_value = "6",.submit_value = "6"},
	{.display_value = "7",.submit_value = "7"}
};

struct value_set qos_priority_add_prio_type_values[] = {
	{.display_value = "None",.submit_value = "0"},
#ifdef CONFIG_FEATURE_QOS_8021P
	{.display_value = "802.1P",.submit_value = "1"},
#endif
#ifdef CONFIG_FEATURE_QOS_IPPTOS
	{.display_value = "IP_PTOS",.submit_value = "2"},
#endif
	{.display_value = "All",.submit_value = "3"}
};

struct value_set qos_priority_add_dir_values[] = {
	{.display_value = "Upstream",.submit_value = "0"},
	{.display_value = "Downstream",.submit_value = "1"}
};

struct value_set qos_priority_add_ip_values[] = {
	{.display_value = "all",.submit_value = "*"},
	{.display_value = "single",.submit_value = "1"},
	{.display_value = "subnet",.submit_value = "2"}
};
struct value_set qos_priority_add_lan_if_values[] = {
	{.display_value = "ALL",.submit_value = "0"},
	{.display_value = "Port_0",.submit_value = "1"},
	{.display_value = "Port_1",.submit_value = "2"},
	{.display_value = "Port_2",.submit_value = "3"},
	{.display_value = "Port_3",.submit_value = "4"},
	{.display_value = "WLAN",.submit_value = "5"}
};

struct value_set qos_priority_add_protocol_values[] = {
	{.display_value = "tcp",.submit_value = "tcp"},
	{.display_value = "udp",.submit_value = "udp"}
};

struct cmd_field qos_priority_add_cmd_field[] = {
	{
	 .field_name = "QP_IF_ADD",
	 .field_help = "This field represents the lan port",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "lan_if",
	 .field_gui_name = "Lan Port",
	 .values = qos_priority_add_lan_if_values,
	 .tot_values =
	 sizeof(qos_priority_add_lan_if_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "QP_PROTO_ADD",
	 .field_help = "This field represents the protocol type",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "proto",
	 .field_gui_name = "Protocol",
	 .values = qos_priority_add_protocol_values,
	 .tot_values =
	 sizeof(qos_priority_add_protocol_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "QP_IP_SRC_TYPE_ADD",
	 .field_help = "This field represents the Source IP Type",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "srctype",
	 .field_gui_name = "Source Type",
	 .values = qos_priority_add_ip_values,
	 .tot_values =
	 sizeof(qos_priority_add_ip_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "QP_IP_SRC_IP_ADD",
	 .field_help = "This field represents the Source IP Address",
	 .data_type = IPADDR,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "srcip",
	 .field_gui_name = "Source IP Address"},
	{
	 .field_name = "QP_IP_SRC_MASK_ADD",
	 .field_help = "This field represents the Source Subnet Mask",
	 .data_type = IPADDR,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "srcmask",
	 .field_gui_name = "Netmask"},
	{
	 .field_name = "QP_PORT_SRC_START_ADD",
	 .field_help = "This field represents the Source starting port number",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "srcport_start",
	 .field_gui_name = "Source Start Port"},
	{
	 .field_name = "QP_PORT_SRC_END_ADD",
	 .field_help = "This field represent the Source ending port number",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "srcport_end",
	 .field_gui_name = "Source End Port"},
	{
	 .field_name = "QP_IP_DST_TYPE_ADD",
	 .field_help = "This field represents the Destination IP Type",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "dsttype",
	 .field_gui_name = "Destination Type",
	 .values = qos_priority_add_ip_values,
	 .tot_values =
	 sizeof(qos_priority_add_ip_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "QP_IP_DST_IP_ADD",
	 .field_help = "This field represents the Destination IP Address",
	 .data_type = IPADDR,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "dstip",
	 .field_gui_name = "Destination IP Address"},
	{
	 .field_name = "QP_IP_DST_MASK_ADD",
	 .field_help = "This field represents the Destination Subnet Mask",
	 .data_type = IPADDR,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "dstmask",
	 .field_gui_name = "Netmask"},
	{
	 .field_name = "QP_PORT_DST_START_ADD",
	 .field_help =
	 "This field represents the Destination starting port number",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "dstport_start",
	 .field_gui_name = "Destination Start Port"},
	{
	 .field_name = "QP_PORT_DST_END_ADD",
	 .field_help =
	 "This field represents the Destination ending port number",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "dstport_end",
	 .field_gui_name = "Destination End Port"},
	{
	 .field_name = "QP_DIR_ADD",
	 .field_help = "This field represents the packet flow direction",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "dir",
	 .field_gui_name = "Direction",
	 .values = qos_priority_add_dir_values,
	 .tot_values =
	 sizeof(qos_priority_add_dir_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "QP_TYPE_ADD",
	 .field_help = "This field represents the priority type",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "prio_type",
	 .field_gui_name = "Priority Type",
	 .values = qos_priority_add_prio_type_values,
	 .tot_values =
	 sizeof(qos_priority_add_prio_type_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "QP_PRIO_ADD",
	 .field_help = "This field represents the priority",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "prio",
	 .field_gui_name = "Priority",
	 .values = qos_priority_add_priority_values,
	 .tot_values =
	 sizeof(qos_priority_add_priority_values) / sizeof(struct value_set)
	 }
};
struct cmd_entry qos_prioqueue_add_cmd = {
	.fields = qos_priority_add_cmd_field,
	.tot_fields =
	    sizeof(qos_priority_add_cmd_field) / sizeof(struct cmd_field),
	.help = "This command adds a qos priority rule",
	.post_url = "/goform/ifx_set_qos_priority_add",
	.custom_validation = qos_priority_add_valid,
	.get_url = "qos_priority.cli"
};

struct cmd_field qos_prioqueue_del_cmd_field[] = {
	{
	 .field_name = "index",
	 .field_help = "This field represents the rule index to be deleted",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "index",
	 .field_gui_name = "Index"},
	{
	 .field_name = "delflag",
	 .field_help = NULL,
	 .data_type = STR,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .field_display_name = NULL,
	 .cur_value = "1"}
};

struct cmd_entry qos_prioqueue_del_cmd = {
	.fields = qos_prioqueue_del_cmd_field,
	.tot_fields =
	    sizeof(qos_prioqueue_del_cmd_field) / sizeof(struct cmd_field),
	.help = "This command deletes a priority queue Rule",
	.post_url = "/goform/ifx_set_qos_priority",
	.custom_processing_post = qos_priority_queue_del_post,
	.get_url = "qos_priority.cli"
};

struct menu_entry qos_priority_setting_entries[] = {
	{
	 .entry_help = "This is qos_prioity_setting show_entry",
	 .cli_name = "Show",.cli_url = "qos_priority.cli"},
	{
	 .entry_help = "Add a priority queue uule entry",
	 .cli_name = "Add",.cmd = &qos_prioqueue_add_cmd},
	{
	 .entry_help = "This is qos_prioity_setting config_entry",
	 .cli_name = "Delete",.cmd = &qos_prioqueue_del_cmd}
};
#endif
// 000001:tc.chen end

struct value_set qos_config_cmd_values[] = {
	{.display_value = "disable",.submit_value = "0"},
	{.display_value = "enable",.submit_value = "1"}
};

struct cmd_field qos_config_cmd_fields[] = {
	{
	 .field_name = "QosStatus",
	 .field_help = "This field represent the qos status",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "QosStatus",
	 .field_gui_name = "QoS status",	//000001:tc.chen
	 .values = qos_config_cmd_values,
	 .tot_values = sizeof(qos_config_cmd_values) / sizeof(struct value_set)
// 000001:tc.chen start
	 },
	{
	 .field_name = "DsVs",
	 .field_help = "Represents the qos status of qos virtual server",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "DsVs",
	 .field_gui_name = "Virutal server bandwidth control",
	 .values = qos_diffserv_cmd_values,
	 .tot_values =
	 sizeof(qos_diffserv_cmd_values) / sizeof(struct value_set)
#ifdef CONFIG_FEATURE_QOS_PRIORITY_QUEUE
	 },
	{
	 .field_name = "QosPrioStatus",
	 .field_help = "Represents the qos status of priority queue",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "QosPrioStatus",
	 .field_gui_name = "Priority queue status",
	 .values = qos_prioity_queue_cmd_values,
	 .tot_values =
	 sizeof(qos_prioity_queue_cmd_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "QOS_8021P",
	 .field_help = "Represents the qos status of 802.1p priority queue",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "QOS_8021P",
	 .field_gui_name = "802.1P priority status",
	 .values = qos_prio_8021p_cmd_values,
	 .tot_values =
	 sizeof(qos_prio_8021p_cmd_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "QOS_IPPTOS",
	 .field_help = "Represents the qos status of IP precedence priority ",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "QOS_IPPTOS",
	 .field_gui_name = "IP priority status",
	 .values = qos_prio_IPPTOS_cmd_values,
	 .tot_values =
	 sizeof(qos_prio_IPPTOS_cmd_values) / sizeof(struct value_set)
#endif				//CONFIG_FEATURE_QOS_PRIORITY_QUEUE
// 000001:tc.chen end
	 }
};

struct cmd_entry qos_config_cmd = {
	.fields = qos_config_cmd_fields,
	.tot_fields = sizeof(qos_config_cmd_fields) / sizeof(struct cmd_field),
	.help = "This command configures qos settings",
	.post_url = "/goform/ifx_set_qos_main",
	.get_url = "qos_main.cli"
};

struct menu_entry qos_setting_entries[] = {
	{
	 .entry_help = "This is qos_setting show_entry",
	 .cli_name = "Show",.cli_url = "qos_main.cli"},
	{
	 .entry_help = "This is qos_setting config_entry",
	 .cli_name = "Config",.cmd = &qos_config_cmd}
};

struct menu_page qos_setting_page = {
	.entries = qos_setting_entries,
	.tot_entries = sizeof(qos_setting_entries) / sizeof(struct menu_entry),
	.page_help = "qos setting page",.cli_title = "setting",.gui_title =
	    "Setting"
};

/* 000001:tc.chen
struct menu_page qos_diffserv_page =
		{
			.entries=qos_diffserv_entries,
			.tot_entries=sizeof(qos_diffserv_entries)/sizeof(struct menu_entry),
			.page_help="qos diffserv page", .cli_title="Diffserv", .gui_title="Diffserv"
		};
*/
// 000001:tc.chen start
#ifdef CONFIG_FEATURE_QOS_PRIORITY_QUEUE
struct menu_page qos_priority_setting_page = {
	.entries = qos_priority_setting_entries,
	.tot_entries =
	    sizeof(qos_priority_setting_entries) / sizeof(struct menu_entry),
	.page_help = "qos priority queue page",.cli_title =
	    "Priority Queue Setting",.gui_title = "Priority Queue Setting"
};
#endif				//CONFIG_FEATURE_QOS_PRIORITY_QUEUE
// 000001:tc.chen end

struct menu_entry qos_page_entries[] = {
	{
	 .next_page = &qos_setting_page,
	 .entry_help = "qos setting entry",.cli_name = "Setting"},
/* 000001:tc.chen
			{
				.next_page=&qos_diffserv_page,
				.entry_help="qos diffserv entry", .cli_name="Diffserv"
			}
*/
// 000001:tc.chen start
#ifdef CONFIG_FEATURE_QOS_PRIORITY_QUEUE
	{
	 .next_page = &qos_priority_setting_page,
	 .entry_help = "qos priority queue entry",.cli_name =
	 "Priority_Queue_Setting"}
#endif				//CONFIG_FEATURE_QOS_PRIORITY_QUEUE
// 000001:tc.chen end
};

struct menu_page qos_page = {
	.entries = qos_page_entries,
	.tot_entries = sizeof(qos_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is qos page",.cli_title = "qos",.gui_title =
	    "QoS Page"
};
