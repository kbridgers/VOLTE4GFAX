#ifndef __MENU_DEF_H
#define __MENU_DEF_H
enum DATA_TYPE { INT = 0, CHAR, STR, IPADDR, NETMASK, MACADDR, PASSWD };
enum FIELD_TYPE { USR_DEF = 0,	/* NA implies any value can be added by user */
	HIDDEN,			/* HIDDEN fields are not entered by the user and required by the backend */
	STATIC,			/* STATIC implies the value of the field will come from the set which is well defined and will not change */
	DYNAMIC
};				/* DYNAMIC implies the value set is field will come from the set which is not pre-defined */
enum BOOL { IFX_FALSE = 0, IFX_TRUE };

enum HTTP_REQTYPE { REQ_GET = 0, REQ_POST };

struct field_value_set {
	char *field_name;	/* The display field name as entered by the user */
	char *field_value;	/* The value as entered by the user */
};

struct value_set {
	char *display_value;	/* The value to be displayed */
	char *submit_value;	/* The value to be submitted */
};

struct cmd_field {
	char *field_name;	/* The name which should be used while generating post string */
	char *field_help;	/* Help about this field */

	enum DATA_TYPE data_type;	/* INT, CHAR, STR */
	enum FIELD_TYPE field_type;	/* STATIC, DYNAMIC. For the DYNAMIC field the
					   values = NULL and will be fetched at the runtime. */
	enum BOOL mandatory;	/* TRUE, FALSE */

	char *field_display_name;	/* The name to be displayed for this field */
	char *field_gui_name;	/* The GUI name for this field */

	struct value_set *values;	/* All the static values (if any) for this field */
	int tot_values;		/* Total no of static values for this field */
	int (*get_vset) (struct value_set **, int *num_entries);	/* This function gets the value_set in case this field is dynamic */
	int (*fprocessing_post) (struct cmd_field *, char *poststr);	/* This function converts the field_value in the form required by post string of the httpd */
	char *cur_value;	/* This is the current value for this field as entered by the user */
};

struct cmd_entry {
	struct cmd_field *fields;	/* points to the array of cmd_field */
	int tot_fields;

	char *help;
	char *post_url;		/* URL to which the post request is to be made */

	int (*custom_validation) (struct cmd_entry *, char *errstr);	/* This function performs the custom validation of the field values. In GUI this is done through java script */
	int (*custom_processing_post) (struct cmd_entry *, char *poststr);	/* This function generates special fields, such as hidden field, required for this command while making post request */

	char *get_url;
};

struct menu_page {
	struct menu_entry *entries;	/* points to the array of menu_entry */
	int tot_entries;
	char *page_help;

	/** CLI **/
	char *cli_title;

	/** GUI **/
	char *gui_title;
	int fpos;		/* lefttop, leftsub, right */
};

struct menu_entry {
	struct menu_page *next_page;	/* NULL at leaf level */

	char *entry_help;
	/** CLI **/
	char *cli_name;
	char *cli_url;		/* show */

	/** GUI **/
	char *gui_name;
	char *gui_url;

	struct cmd_entry *cmd;	/* if this is final command */
};

enum MSG_TYPE_BE { MSG_SHOW = 1, MSG_MENU, MSG_CMD };
enum MSG_TYPE_FE { MSG_QUERY = 1, MSG_SUBMIT };

struct menu_msg {
	char *menu_display_name;
	char *menu_submit_name;
	char *menu_help;
	struct menu_msg *next;
};

struct cmd_msg {
	enum DATA_TYPE data_type;
	enum FIELD_TYPE field_type;
	enum BOOL mandatory;
	int tot_statvalues;
	char *field_name;
	char *display_str;
	char *default_val;
	char *field_help;
	char *cur_value;
	char *str_statvalues;
	struct cmd_msg *next;
};

struct toplevel_be_msg {
	enum MSG_TYPE_BE msg_type;
	int tot_entries;
};

struct toplevel_fe_msg {
	enum MSG_TYPE_FE msg_type;
	pid_t cli_fe_pid;
};
#endif
