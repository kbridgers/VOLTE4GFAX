#ifdef CONFIG_FEATURE_SAMBA
int samba_setting_validate(struct cmd_entry *cmd, char *poststr);
#endif
