
/* ============================================================================
 * Copyright (C) 2005 -Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 *============================================================================
 *
 * This document contains proprietary information belonging to Infineon 
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 * 
 * ============================================================================
 */

/* ===========================================================================
 *
 * File Name:   cli_be.c
 * Author :     Nirav Salot
 * Date: 		April, 2005
 *
 * ===========================================================================
 *
 * Project: Amazon
 *
 * ===========================================================================
 * Contents: This file implements the CLI backend infrastructure which provides
 * all the CLI processing capabilities. The CLI frontend (cli_fe) interacts
 * with the cli_be and in turn, cli_be interacts with the web server.
 *  
 * ===========================================================================
 * References: 
 *
 */

/* ===========================================================================
 * Revision History:
 *
 * $Log$
 * ===========================================================================
 */
#include <sys/stat.h>
#include <sys/types.h>
#include "common.h"
//#include "ifx_amazon_cfg.h"

extern pid_t cli_fe_cur_pid;
int parse_and_fill_fvset(char *buf, struct field_value_set **pp_fvset,
			 int *num_fields);

/* Creates the directory  for all the menu
 * and links pointing to the cli_fe for all the commands
 * */
#ifndef IFX_CLI_PROMPTEDMODE
int create_dir_struct(struct menu_page *current_page)
{
	int i;
	static int nest = 0;
	struct menu_entry *current_entry = current_page->entries;

	for (i = 0; i < current_page->tot_entries; i++, current_entry++) {
		printf("meny_entry->cli_name <%s> !\n",
		       current_entry->cli_name);
		if (current_entry->next_page) {
			char pwd[128];

			memset(pwd, 0x00, sizeof(pwd));
			getcwd(pwd, sizeof(pwd));

			mkdir(current_entry->cli_name, DIR_MOD);
			chdir(current_entry->cli_name);
			++nest;
			printf("[%d] Created subdir <%s>!\n", nest,
			       current_entry->cli_name);

			create_dir_struct(current_entry->next_page);
			--nest;
			chdir(pwd);
		} else {
			symlink(cli_fe_path, current_entry->cli_name);
			printf("[%d] Created command <%s>!\n", nest,
			       current_entry->cli_name);
		}
	}
	return 0;
}
#endif
/*
 * For the given query string of the form /cli_root/route/static/add
 * finds the pointer of the "add" command
 */
struct menu_entry *find_menu_entry(char *query)
{
	struct menu_page *current_page = NULL;
	struct menu_entry *matched_entry = NULL;
	char cmd_str[128];
	char *cmd = NULL;
	char *cmd_end = NULL;
	int end = 0;
	int i;

	cmd_end = strchr(query, ' ');	/* separate the command and the argument part */
	memset(cmd_str, 0x00, sizeof(cmd_str));
	if (cmd_end == NULL) {
		strncpy(cmd_str, query, sizeof(cmd_str) - 1);
		cmd_str[strlen(cmd_str)] = '\0';
	} else
		strlcpy(cmd_str, query, sizeof(cmd_str));
	cmd = cmd_str;
	printf("find_menu_entry : cmd [%s]\n", cmd);
#ifndef IFX_CLI_PROMPTEDMODE
	/* Skip the cli_root path from the command */
	if (strncmp(query, cli_root_dir, strlen(cli_root_dir)) == 0)
		cmd += strlen(cli_root_dir);
#endif

	//while(*cmd == '/')
	if (*cmd == '/')
		cmd++;

	current_page = &cli_menu;

	while (!end && current_page != NULL) {
		struct menu_entry *current_entry = current_page->entries;
		char *subcmd_end = NULL;
		char subcmd[32];

		subcmd_end = strchr(cmd, '/');	/* Find the next subcommand */
		memset(subcmd, 0x00, sizeof(subcmd));
		if (subcmd_end == NULL) {
			end = 1;
			strcpy(subcmd, cmd);
		} else {
			strncpy(subcmd, cmd, subcmd_end - cmd);
		}

		//printf("find_menu_entry : searching for [%s]\n",subcmd);
		for (i = 0; i < current_page->tot_entries; i++, current_entry++) {
			/* check if the current cli_name is same as subcommand */
			if (strcmp(current_entry->cli_name, subcmd) == 0) {
				matched_entry = current_entry;
				current_page = current_entry->next_page;
				//printf("matched : %s\n",subcmd);
				break;
			}
		}
		cmd = subcmd_end + 1;
	}			/* while */

	if (end) {
		return matched_entry;
	}
	return NULL;
}

/*
 * Makes the http query to the httpd server
 * If the request type is get then no body is sent
 * For the request type post the body is also sent
 */
static char http_query_str[3072];
int http_query(char *url, char *body, enum HTTP_REQTYPE req_type)
{
	int s, len;
	struct sockaddr_un remote;

	/* create the unix domain socket */
	if ((s = socket(AF_UNIX, SOCK_STREAM, 0)) == -1) {
		perror("http socket");
		return -1;
	}

	remote.sun_family = AF_UNIX;
	strcpy(remote.sun_path, SOCK_BE_PATH);
	len = strlen(remote.sun_path) + sizeof(remote.sun_family);
	/* connect to the httpd unix socket */
	if (connect(s, (struct sockaddr *)&remote, len) == -1) {
		perror("connect to be");
		close(s);
		return -1;
	}
	memset(http_query_str, 0x00, sizeof(http_query_str));
	if (req_type == REQ_GET) {
		sprintf(http_query_str, HDR_GETHTML, url, cli_fe_cur_pid);
	} else if (req_type == REQ_POST) {
		sprintf(http_query_str, HDR_POSTHTML, url, cli_fe_cur_pid,
			strlen(body));
		strcat(http_query_str, body);
	}
	if (send(s, http_query_str, strlen(http_query_str), 0) <
	    strlen(http_query_str)) {
		perror("send to be");
		close(s);
		return -1;
	}
	return s;
}

/*
 * Free the field_value_set generated from the user command argument
 */
void free_cmd_fvset(struct field_value_set *pfvset, int *ptot_fvset)
{
	struct field_value_set *pcur_fvset = pfvset;

	while (*ptot_fvset > 0) {
		if (pcur_fvset->field_name)
			free(pcur_fvset->field_name);
		if (pcur_fvset->field_value)
			free(pcur_fvset->field_value);
		(*ptot_fvset)--;
		pcur_fvset++;
	}
	if (pfvset)
		free(pfvset);
	pfvset = NULL;
	*ptot_fvset = 0;
}

void free_vset(struct cmd_entry *cmd)
{
	int i;
	struct cmd_field *cur_field = NULL;

	if (cmd == NULL)
		return;
	cur_field = cmd->fields;
	for (i = 0; i < cmd->tot_fields; i++, cur_field++) {
		if (cur_field->field_type == HIDDEN)
			continue;

		if (cur_field->field_type == DYNAMIC && cur_field->values) {
			int j;
			struct value_set *cur_vset = cur_field->values;
			for (j = 0; j < cur_field->tot_values; j++, cur_vset++) {
				if (cur_vset->display_value)
					free(cur_vset->display_value);
				if (cur_vset->submit_value)
					free(cur_vset->submit_value);
			}
			free(cur_field->values);
			cur_field->values = NULL;
			cur_field->tot_values = 0;
		}
	}
}

/*
 * For each field the value is made null
 */
void reset_cmd_field_values(struct cmd_entry *cmd)
{
	int i = 0;
	struct cmd_field *cur_field = cmd->fields;

	for (i = 0; i < cmd->tot_fields; i++, cur_field++) {
		if (cur_field->field_type == HIDDEN)
			continue;
		cur_field->cur_value = NULL;
	}
}

/*
 * Prints the field_value_set generated. For debugging only
 */
void print_cmd_fvset(struct field_value_set *pfvset, int tot_fvset)
{
	struct field_value_set *pcur_fvset = pfvset;
	int i = 0;

	if (pcur_fvset == NULL)
		return;
	for (i = 0; i < tot_fvset; i++, pcur_fvset++) {
		printf("pfvset[%d]->field_name = [%s]\n", i + 1,
		       pcur_fvset->field_name);
		printf("pfvset[%d]->field_value = [%s]\n", i + 1,
		       pcur_fvset->field_value);
	}
}

/*
 */
int tot_strchr(char *start, char *end, char searchchr)
{
	int totchar = 0;
	if (start == NULL || end == NULL)
		return 0;
	while (start <= end) {
		if (*start == searchchr)
			totchar++;
		start++;
	}
	return totchar;

}

/*
 * Generates the field_value_set structure from the command arguments
 */
struct field_value_set *make_fvset(char *cmd, int *ptot_fvset)
{
	char *cmd_args = NULL;
	char *cur_arg = NULL;
	struct field_value_set *pcmd_fvset = NULL;
	int end = 0;

	*ptot_fvset = 0;
	/* separate the command and arguments */
	cmd_args = strchr(cmd, ' ');
	if (cmd_args == NULL)
		return NULL;

	while (*cmd_args == ' ')
		cmd_args++;
	if (strlen(cmd_args) == 0)
		return NULL;

	printf("For command [%s] arguments [%s]\n", cmd, cmd_args);

	cur_arg = cmd_args;
	while (!end) {
		char fvset[64];
		char *cur_value = NULL;
		char *next_arg = NULL;
		struct field_value_set *pcur_fvset = NULL;

		memset(fvset, 0x00, sizeof(fvset));
		/* Considering ' ' as the end of current field=value */
		next_arg = strchr(cur_arg, ' ');
		/*while((tot_strchr(cur_arg,next_arg,'"') % 2) != 0)
		   next_arg = strchr(next_arg,' '); */
		if (next_arg == NULL) {
			end = 1;
			strcpy(fvset, cur_arg);
		} else {
			strlcpy(fvset, cur_arg, next_arg - cur_arg + 1);
		}
		/* considering '=' as the delimiter between field and value */
		cur_value = strchr(fvset, '=');
		if (cur_value == NULL) {
			/* if the '=' is not found then the command is ill-formed */
			free_cmd_fvset(pcmd_fvset, ptot_fvset);
			pcmd_fvset = NULL;
			*ptot_fvset = -1;
			break;
		}
		/* allocate next field_value_set */
		pcmd_fvset =
		    (struct field_value_set *)realloc(pcmd_fvset,
						      sizeof(struct
							     field_value_set) *
						      (*ptot_fvset + 1));
		if (pcmd_fvset == NULL) {
			printf("ERROR: realloc failure");
			return NULL;
		}
		pcur_fvset = pcmd_fvset + (*ptot_fvset);

		pcur_fvset->field_name =
		    (char *)calloc(1, cur_value - fvset + 1);

		if (pcur_fvset->field_name == NULL) {
			printf("ERROR: calloc failure");
			free(pcur_fvset);
			free(pcmd_fvset);
			return NULL;
		}

		strncpy(pcur_fvset->field_name, fvset, cur_value - fvset);

		cur_value++;
		if (strlen(cur_value)) {
			pcur_fvset->field_value =
			    (char *)calloc(1, strlen(cur_value) + 1);

			if (pcur_fvset->field_value == NULL) {
				printf("ERROR: calloc failure");
				free(pcur_fvset->field_name);
				free(pcur_fvset);
				free(pcmd_fvset);
				return NULL;
			}

			strcpy(pcur_fvset->field_value, cur_value);
		}
		(*ptot_fvset)++;
		cur_arg = next_arg + 1;
	}
	return pcmd_fvset;
}

/*
 * Generates the field_value_set structure from the command arguments
 */
#define BUF_CHUNK	1024
struct field_value_set *make_get_fvset(char *url, int *ptot_fvset)
{
	int reqfd = 0;
	int n;
	int num_fields = 0;
	struct field_value_set *p_fvset = NULL;
	char *pbuf = NULL;
	int tot_recived = 0;

	/* call http_query with url */
	if ((reqfd = http_query(url, NULL, REQ_GET)) < 0) {
		printf("HTTP GET error !\n");
		return NULL;
	}

	/* receive response from the httpd */
	tot_recived = 0;
	pbuf = NULL;
	do {
		pbuf =
		    (char *)realloc(pbuf,
				    (tot_recived + BUF_CHUNK) * sizeof(char));
		memset(pbuf + tot_recived, 0x00, BUF_CHUNK);
		n = recv(reqfd, pbuf + tot_recived, BUF_CHUNK - 1, 0);
		if (n <= 0) {
			if (n < 0)
				perror("recv from be_sock");
			break;
		}
		tot_recived += n;
	} while (1);

	/* generate fvset and return it */
	parse_and_fill_fvset(pbuf, &p_fvset, &num_fields);

	*ptot_fvset = num_fields;
	if (pbuf)
		free(pbuf);

	if (reqfd)
		close(reqfd);

	return (p_fvset);
}

/*
 * Checks the syntax of the command entered
 * A. Checks if all the fields entered by the user is part of the current command field
 * B. Checks if all the mandatory fields of the command is entered by the user
 */
#ifndef IFX_CLI_PROMPTEDMODE
int check_syntax(struct cmd_entry *cur_cmd, struct field_value_set *pfvset,
		 int tot_fvset)
{
	struct field_value_set *top_pfvset = pfvset;
	struct cmd_field *pcmd_fields = NULL;
	int i, j;

	if (tot_fvset > cur_cmd->tot_fields)
		return -1;

	/* Checks if all the fields entered are part of the command */
	printf("Checking all fields are part of command ...\n");
	for (i = 0; i < tot_fvset; i++, pfvset++) {
		int ffound = 0;
		pcmd_fields = cur_cmd->fields;
		for (j = 0; j < cur_cmd->tot_fields; j++, pcmd_fields++) {
			if (pcmd_fields->field_type == HIDDEN)
				continue;
			if (strcasecmp
			    (pfvset->field_name,
			     pcmd_fields->field_display_name) == 0) {
				/* Trying to give user a bit of input flexibility */
				strcpy(pfvset->field_name,
				       pcmd_fields->field_display_name);
				ffound = 1;
				break;
			}
		}
		if (!ffound)
			return -1;
	}

	printf("Checking all mandatory fields are present ...\n");
	/* Checks if all the mandatory fields are present */
	pcmd_fields = cur_cmd->fields;
	for (i = 0; i < cur_cmd->tot_fields; i++, pcmd_fields++) {
		int ffound = 0;
		if (pcmd_fields->mandatory == IFX_FALSE)
			continue;

		for (j = 0, pfvset = top_pfvset; j < tot_fvset; j++, pfvset++) {
			if (strcmp
			    (pfvset->field_name,
			     pcmd_fields->field_display_name) == 0) {
				ffound = 1;
				break;
			}
		}
		if (!ffound) {

			printf
			    ("Cmd parameter validation FAILED : Mandatory field [%s] not found!\n",
			     pcmd_fields->field_display_name);
			return -1;
		}
	}
	printf("Cmd parameter validation ok !\n");
	return 0;
}
#endif

/*
 * Generate syntax of the command
 * If parahelp = 0, just generates the syntax 
 * If parahelp = 1, with the syntax also generates the parameter help
 */
void gen_syntax(struct menu_entry *cur_entry, char *str_syntax, int paramhelp)
{
	struct cmd_field *cur_field = cur_entry->cmd->fields;
	struct value_set *cur_fvalues = NULL;
#define BUFF_LEN 1024
	char tmp_syntax[BUFF_LEN];
	int i = 0;
	int j = 0;

	bzero(tmp_syntax, sizeof(tmp_syntax));

	strlcat(tmp_syntax, cur_entry->cli_name, BUFF_LEN);
	if (paramhelp)
		strlcat(tmp_syntax, "\n\n", BUFF_LEN);
	for (i = 0; i < cur_entry->cmd->tot_fields; i++, cur_field++) {
		if (cur_field->field_type == HIDDEN)
			continue;
		strlcat(tmp_syntax, " ", BUFF_LEN);
		if (paramhelp)
			strlcat(tmp_syntax, "\t", BUFF_LEN);
		/* If the field is not mandatory */
		if (cur_field->mandatory == IFX_FALSE)
			strlcat(tmp_syntax, "[", BUFF_LEN);
		strlcat(tmp_syntax, cur_field->field_display_name, BUFF_LEN);
		/* For the value of the field */
		strlcat(tmp_syntax, "=<", BUFF_LEN);

		switch (cur_field->field_type) {
		case HIDDEN:
			break;

			/* For static type, print all the allowable value for the field */
		case STATIC:
		case DYNAMIC:
			cur_fvalues = cur_field->values;
			if (cur_fvalues == NULL)
				break;
			for (j = 0; j < cur_field->tot_values; j++) {
				strlcat(tmp_syntax, cur_fvalues->display_value,
					BUFF_LEN);
				strlcat(tmp_syntax, "|", BUFF_LEN);
				cur_fvalues++;
			}
			tmp_syntax[strlen(tmp_syntax) - 1] = '\0';
			break;

		case USR_DEF:
			switch (cur_field->data_type) {
			case INT:
				strlcat(tmp_syntax, "number", BUFF_LEN);
				break;
			case STR:
				strlcat(tmp_syntax, "string", BUFF_LEN);
				break;
			case PASSWD:
				strlcat(tmp_syntax, "password", BUFF_LEN);
				break;
			case CHAR:
				strlcat(tmp_syntax, "character", BUFF_LEN);
				break;
			case IPADDR:
				strlcat(tmp_syntax, "ip address", BUFF_LEN);
				break;
			case NETMASK:
				strlcat(tmp_syntax, "net mask", BUFF_LEN);
			case MACADDR:
				strlcat(tmp_syntax, "mac address", BUFF_LEN);
				break;
			}
			break;
		}
		strlcat(tmp_syntax, ">", BUFF_LEN);
		if (cur_field->mandatory == IFX_FALSE)
			strlcat(tmp_syntax, "]", BUFF_LEN);
		if (paramhelp) {
			strlcat(tmp_syntax, "\n\t\t", BUFF_LEN);
			strlcat(tmp_syntax, cur_field->field_help, BUFF_LEN);
			strlcat(tmp_syntax, "\n\n", BUFF_LEN);
		}
	}
	if (paramhelp == 0)
		strlcat(tmp_syntax, "\n", BUFF_LEN);

	strlcat(str_syntax, tmp_syntax, BUFF_LEN);
}

/*
 * Populates the cur_value of the field in case its value is entered by the user
 */
int populate_fieldvalues(struct cmd_entry *cmd, struct field_value_set *pfvset,
			 int tot_fvset)
{
	int i, j;

	for (i = 0; i < tot_fvset; i++, pfvset++) {
		struct cmd_field *cur_field = cmd->fields;
		for (j = 0; j < cmd->tot_fields; j++, cur_field++) {
			if (cur_field->field_type == HIDDEN)
				continue;
			if (strcmp
			    (pfvset->field_name,
			     cur_field->field_display_name) == 0) {
				cur_field->cur_value = pfvset->field_value;
				break;
			}
		}
	}
	return 0;
}

/*
 * Prints the cur_value of the all the field. For debugging
 */
int print_field_values(struct cmd_entry *cmd)
{
	int i;
	struct cmd_field *cur_field = cmd->fields;

	for (i = 0; i < cmd->tot_fields; i++, cur_field++) {
		if (cur_field->cur_value && cur_field->field_type != HIDDEN)
			printf("Entered %s = [%s]\n",
			       cur_field->field_display_name,
			       cur_field->cur_value);
	}

	return 0;
}

#ifndef IFX_CLI_PROMPTEDMODE
/* Validates if the current field value is part of the defined values */
int validate_values(char *value, struct value_set *valueset, int tot_values)
{
	int i;
	if (valueset == NULL) {
		printf("valueset is NUL ?? \n");
		return -1;
	}
	for (i = 0; i < tot_values; i++, valueset++) {
		if (strcasecmp(value, valueset->display_value) == 0) {
			/* Trying to give user a bit of input flexibility */
			strcpy(value, valueset->display_value);
			return 0;
		}
	}
	printf("[%s] and [%s] did not match\n", value, valueset->display_value);
	return -1;
}

#define MACADDR_CHR "0123456789ABCDEFabcdef"

int ismacaddr(char *str)
{
	char macaddr[64];
	char *next_tok = NULL;
	int i;

	memset(macaddr, 0x00, sizeof(macaddr));
	strcpy(macaddr, str);

	if (macaddr[strlen(macaddr) - 1] == ':')
		return 0;

	next_tok = strtok(macaddr, ":");
	for (i = 0; i < 6; i++) {
		if (next_tok == NULL)
			return 0;

		if (strchr(MACADDR_CHR, next_tok[0]) == NULL &&
		    strchr(MACADDR_CHR, next_tok[1]) == NULL &&
		    strlen(next_tok) > 2)
			return 0;
		next_tok = strtok(NULL, ":");
	}
	if (next_tok != NULL)
		return 0;

	return 1;
}

/* Checks if current string is number */
int isnum(char *str)
{
	while (isdigit(*str))
		str++;
	return (*str) ? 0 : 1;
}

/* Checks if current string is ipaddr. i.e. xxx.xxx.xxx.xxx where 0 <= xxx <= 255 */
int isipaddr(char *str)
{
	char ipaddr[64];
	char *next_tok;
	int count = 0;
	int i;

	memset(ipaddr, 0x00, sizeof(ipaddr));
	strncpy(ipaddr, str, sizeof(ipaddr) - 1);

	if (ipaddr[strlen(ipaddr) - 1] == '.')
		return 0;

	next_tok = strtok(ipaddr, ".");
	for (i = 0; i < 4; i++) {
		int num = 0;
		if (next_tok == NULL)
			return 0;
		if (!isnum(next_tok))
			return 0;
		num = strtol(next_tok, NULL, 10);
		if (num < 0 || num > 255)
			return 0;
		if (num == 0)
			count++;
		next_tok = strtok(NULL, ".");
	}
	if (count == 4)
		return 0;
	if (next_tok != NULL)
		return 0;
	return 1;
}

/*
 * Checks the type of the current field
 * A. For static type matches the value entered by the user with pre-defined values
 * B. For char type checks if it is single character
 * C. For int type checks if it is number
 * D. For ipaddr and netmask does proper validation
 */
int check_type(struct cmd_entry *cur_cmd, struct field_value_set *pfvset,
	       int tot_pfvset)
{
	int i, j;
/*	struct field_value_set *temp = pfvset; */

	for (i = 0; i < tot_pfvset; i++, pfvset++) {
		struct cmd_field *cur_field = cur_cmd->fields;
		printf("Variable Index [%d:%s]\n", i, pfvset->field_name);

		for (j = 0; j < cur_cmd->tot_fields; j++, cur_field++) {
			if (cur_field->field_type == HIDDEN)
				continue;
			printf("\tCmd Field Index [%d:%s]\n", j,
			       cur_field->field_name);
			if (strcmp
			    (cur_field->field_display_name,
			     pfvset->field_name) == 0) {
				switch (cur_field->field_type) {
				case HIDDEN:
					break;

				case STATIC:
				case DYNAMIC:
					if (validate_values
					    (pfvset->field_value,
					     cur_field->values,
					     cur_field->tot_values)) {
						printf
						    ("%s : %s static/dynamic validation failed\n",
						     __FUNCTION__,
						     pfvset->field_name);
						return -1;
					}
					break;

				case USR_DEF:
					switch (cur_field->data_type) {
					case INT:
						if (!isnum(pfvset->field_value)) {
							printf
							    ("%s : %s=%s int validation failed\n",
							     __FUNCTION__,
							     pfvset->field_name,
							     pfvset->
							     field_value);
							return -1;
						}
						break;

					case CHAR:
						if (!isalpha
						    (pfvset->field_value)) {
							printf
							    ("%s : %s=%s char validation failed\n",
							     __FUNCTION__,
							     pfvset->field_name,
							     pfvset->
							     field_value);
							return -1;
						}
						break;

					case IPADDR:
					case NETMASK:
						if (!isipaddr
						    (pfvset->field_value)) {
							printf
							    ("%s : %s=%s ip validation failed\n",
							     __FUNCTION__,
							     pfvset->field_name,
							     pfvset->
							     field_value);
							return -1;
						}
						break;

					case MACADDR:
						if (!ismacaddr
						    (pfvset->field_value)) {
							printf
							    ("%s : %s=%s macaddr validation failed\n",
							     __FUNCTION__,
							     pfvset->field_name,
							     pfvset->
							     field_value);
							return -1;
						}

					case PASSWD:
					case STR:
						break;
					}
					break;
				}
			}
		}
	}
	return 0;
}
#endif

/*
 * For each value delimited by delim, generates field=value pair where
 * field = prefix<n> where 'n' is index of the current field
 */
int multifield_poststr(char *prefix, char *value, int startval, char *delim,
		       char *poststr)
{
	char prefixval[32];
	char *next_tok = NULL;
	char strvalue[128];
	int i = startval;
	int bfirst = 1;

	memset(strvalue, 0x00, sizeof(strvalue));
	strncpy(strvalue, value, sizeof(strvalue) - 1);

	next_tok = strtok(strvalue, delim);
	while (next_tok) {
		if (!bfirst) {
			strcat(poststr, "&");
		}
		memset(prefixval, 0x00, sizeof(prefixval));
		sprintf(prefixval, "%s%d", prefix, i);
		strcat(poststr, prefixval);
		strcat(poststr, "=");
		strcat(poststr, next_tok);
		i++;
		next_tok = strtok(NULL, delim);
		bfirst = 0;
	}
	return 0;
}

/*
 * For ipaddress, netmask and gateway generates multiple field<n>=value pairs
 */
int ip_nm_gw_processing(struct cmd_field *field, char *poststr)
{
	return (multifield_poststr
		(field->field_name, field->cur_value, 1, ".", poststr));
}

int mac_addr_processing(struct cmd_field *field, char *poststr)
{
	return (multifield_poststr
		(field->field_name, field->cur_value, 0, ":", poststr));
}

int generate_poststr(struct cmd_entry *cmd, char *poststr)
{
	int i;
	struct cmd_field *cur_field = cmd->fields;

	strcat(poststr, "page=cli_defaultpage.htm");
	for (i = 0; i < cmd->tot_fields; i++, cur_field++) {
		if (cur_field->cur_value == NULL)
			continue;
		strcat(poststr, "&");
		if (cur_field->fprocessing_post) {
			cur_field->fprocessing_post(cur_field, poststr);
			continue;
		}
		strcat(poststr, cur_field->field_name);
		strcat(poststr, "=");
		if (cur_field->field_type == STATIC
		    || cur_field->field_type == DYNAMIC) {
			struct value_set *cur_value_set = cur_field->values;
			int j;
			if (cur_value_set == NULL)
				continue;
			for (j = 0; j < cur_field->tot_values;
			     j++, cur_value_set++) {
				if (strcmp
				    (cur_value_set->display_value,
				     cur_field->cur_value) == 0) {
					strcat(poststr,
					       cur_value_set->submit_value);
					break;
				}
			}
		} else {
			strcat(poststr, cur_field->cur_value);
		}
	}

	if (cmd->custom_processing_post) {
		strcat(poststr, "&");
		if (cmd->custom_processing_post(cmd, poststr))
			return -1;
	}
	printf("poststr : [%s] !\n", poststr);
	return 0;
}

void print_menu_help(struct menu_entry *cur_entry, char *help)
{
	int i;

	strcat(help, cur_entry->cli_name);
	strcat(help, "\t");

	if (cur_entry->cmd != NULL) {
		strcat(help, cur_entry->cmd->help);
		strcat(help, "\n");
	} else {
		strcat(help, cur_entry->entry_help);
		strcat(help, "\n");
		if (cur_entry->next_page != NULL || cur_entry->cmd != NULL) {
			for (i = 0; i < cur_entry->next_page->tot_entries; i++)
				print_menu_help(&cur_entry->next_page->
						entries[i], help);
		}
	}
}

void print_cmd_help(struct menu_entry *cur_entry, char *help)
{
	struct cmd_entry *cur_cmd = cur_entry->cmd;
	int i;

	strcat(help, cur_cmd->help);
	strcat(help, "\n");
	for (i = 0; i < cur_cmd->tot_fields; i++) {
		if (cur_cmd->fields[i].field_type == HIDDEN)
			continue;
		strcat(help, cur_cmd->fields[i].field_display_name);
		strcat(help, "\n\t");
		strcat(help, cur_cmd->fields[i].field_help);
		strcat(help, "\n\n");
	}

}

void print_help(struct menu_entry *cur_entry, char *help)
{
	if (cur_entry->cmd == NULL)
		print_menu_help(cur_entry, help);
	else
		print_cmd_help(cur_entry, help);
}

void get_help(char *str, struct menu_entry *cmd_menu, char *out_help)
{
	memset(out_help, 0x00, sizeof(out_help));
	strcat(out_help, "Hierarchical Help for \t");
	strcat(out_help, str);
	strcat(out_help, "\n\n");
	print_help(cmd_menu, out_help);
	if (cmd_menu->cmd == NULL) {
	} else {
		strcat(out_help, "The syntax is \n");
		gen_syntax(cmd_menu, out_help, 0);
	}
}

int getindex(char *prefix, char *searchstr, int bPartial, char *foundstr)
{
	char sValue[256];
	char sCommand[128];
	int bFound = 0;
	int nCount = 0;
	int i;

	printf("%s : searchstr [%s]\n", __FUNCTION__, searchstr);
	memset(sCommand, 0x00, sizeof(sCommand));
	memset(sValue, 0x00, sizeof(sValue));
	sprintf(sCommand, "grep \"^%sCount\" %s | cut -f2 -d'\"'", prefix,
		FILE_RC_CONF);
	printf("Trying to execute [%s]\n", sCommand);
	if (ifx_GetCfgData(sCommand, NULL, "1", sValue) == 0)
		return -1;

	nCount = atoi(sValue);
	if (nCount <= 0)
		return -1;

	printf("getindex : for prefix %s nCount %d\n", prefix, nCount);
	for (i = 0; i < nCount; i++) {
		memset(sCommand, 0x00, sizeof(sCommand));
		memset(sValue, 0x00, sizeof(sValue));
		sprintf(sCommand, "grep %s%d %s | cut -f2 -d'\"'", prefix, i,
			FILE_RC_CONF);
		if (ifx_GetCfgData(sCommand, NULL, "1", sValue) == 0)
			return -1;
		printf("%s : sValue [%s]\n", __FUNCTION__, sValue);
		if (bPartial && strstr(sValue, searchstr)) {
			bFound = 1;
			break;
		} else if (!bPartial && (strcmp(sValue, searchstr) == 0)) {
			bFound = 1;
			break;
		}
	}
	if (bFound) {
		strcpy(foundstr, sValue);
		return i;
	}
	return -1;
}

//void make_actual_fvset(struct cmd_entry * cur_cmd,struct field_value_set *set,int total, char * poststr){
void update_poststr_from_backend(struct field_value_set *fvset, int num_fv,
				 char *poststr)
{
	char *post = poststr;
	char searchstr[256];
	struct field_value_set *ptr = NULL;
	int total = 0;
	int i;

	ptr = fvset;
	for (i = 0; i < num_fv; i++) {
		sprintf(searchstr, "&%s=", ptr->field_name);
		if (strstr(post, searchstr) == NULL) {
			if (strncmp(post, &searchstr[1], strlen(&searchstr[1]))) {
				if (ptr->field_value) {
					printf
					    ("Field [%s:%s] not in poststr. Adding ...!\n",
					     ptr->field_name, ptr->field_value);
					strcat(post, searchstr);
					strcat(post, ptr->field_value);
				} else {
					printf
					    ("Field [%s:%s] not in poststr, but null and so NOT Adding ...!\n",
					     ptr->field_name, ptr->field_value);
				}
			}
//                      break;
		}
		total--;
		ptr++;
	}

	printf("poststring [%s] !\n", post);
}

int get_dynamic_fvset(struct cmd_entry *cmd)
{
	int i;
	struct cmd_field *cur_field = NULL;

	if (cmd == NULL)
		return -1;

	cur_field = cmd->fields;
	for (i = 0; i < cmd->tot_fields; i++, cur_field++) {
		if (cur_field->field_type == HIDDEN)
			continue;
		if (cur_field->field_type == DYNAMIC) {
			if (cur_field->get_vset) {
				if (cur_field->
				    get_vset(&cur_field->values,
					     &cur_field->tot_values))
					return -1;
			} else {
				return -1;
			}
		}
	}
	return 0;
}

struct cmd_field *get_field_entry(struct cmd_entry *p, char *field_name)
{
	int i = 0;

	for (i = 0; i < p->tot_fields; i++) {
		if (!strcasecmp(p->fields[i].field_name, field_name)) {
			return (&p->fields[i]);
		}
	}
	return (NULL);
}

void websGetIFInfo(int IF_type, int IP_Type, int nIDX, int nReqIdx, int bBreak,
		   char *pRetValue)
{
	char sTAG_NAME[MAX_DATA_LEN];
	char sCFG_NAME[MAX_DATA_LEN];
	char sValue[MAX_DATA_LEN];
	char *ip;
	int nIndex = 0;

	if (IF_type == LAN_IF_TYPE)	// LAN
		sprintf(sTAG_NAME, "Lan%d_IF_Info", nIDX);
	else			// WAN
		sprintf(sTAG_NAME, "Wan%d_IF_Info", nIDX);

	if (IP_Type == IP_INFO)
		sprintf(sCFG_NAME, "IP");
	else if (IP_Type == MASK_INFO)
		sprintf(sCFG_NAME, "MASK");

	if (ifx_GetCfgData(FILE_SYSTEM_STATUS, sTAG_NAME, sCFG_NAME, sValue) !=
	    1)
		sprintf(sValue, "0.0.0.0");

	if (bBreak == 0 && nReqIdx == 4)	// Wanna full IP address
	{
		strcpy(pRetValue, sValue);
		return;
	}

	nIndex = 0;
	do {
		if (nIndex == 0)
			ip = strtok(sValue, ".");
		else
			ip = strtok(NULL, ".");
		nIndex++;
		if (bBreak == 0) {
			if (ip == NULL) {
				break;
			}
			strcat(pRetValue, (const char *)ip);
			strcat(pRetValue, ".");
		}
	} while (ip != NULL && nIndex < nReqIdx);

	if (bBreak == 1 && nIndex == nReqIdx && ip != NULL) {
		strcpy(pRetValue, (const char *)ip);
		return;
	}
}

int update_cmd_cur_values(struct cmd_entry *cmd,
			  struct field_value_set *cmd_get_fvset,
			  int tot_get_fvset)
{
	int i;
	struct cmd_field *cur_field = NULL;

	for (i = 0, cur_field = cmd->fields; i < cmd->tot_fields;
	     i++, cur_field++) {
		struct field_value_set *cur_get_fvset = NULL;
		int j;
		if (cur_field->field_type == HIDDEN)
			continue;
		for (j = 0, cur_get_fvset = cmd_get_fvset; j < tot_get_fvset;
		     j++, cur_get_fvset++) {
			if (strcmp
			    (cur_field->field_name,
			     cur_get_fvset->field_name) == 0) {
				cur_field->cur_value =
				    cur_get_fvset->field_value;
				break;
			}
		}
	}
	return 0;
}

void get_httpd_data(char *url, enum HTTP_REQTYPE req_type, char *body,
		    char **ppresponse, int *preslen)
{
	int be_sock = 0;
	int n;
	int tot_bytes = 0;
	char *pstr = NULL;

	printf("making http request with url = %s, type = %d, body = %s\n", url,
	       req_type, body);
	be_sock = http_query(url, body, req_type);
	if (be_sock <= 0) {
		pstr = calloc(128, sizeof(char));
		perror("Could not connect to httpd:");
		*ppresponse = pstr;
		if (pstr != NULL) {
			strcpy(pstr,
			       "<html><title>Error</title><p>Could not connect to httpd</p></html>");
			*preslen = strlen(pstr);
		}
		return;
	}
	printf("Connected to httpd.\n");

	do {
		pstr = (char *)realloc(pstr, tot_bytes + BUF_CHUNK);
		memset(pstr + tot_bytes, 0x00, BUF_CHUNK);
		n = recv(be_sock, pstr + tot_bytes, BUF_CHUNK - 1, 0);
		if (n <= 0) {
			if (n < 0)
				perror("recv from be_sock");
			break;
		}
		tot_bytes += n;
	} while (1);

	*ppresponse = pstr;
	*preslen = tot_bytes;
	if (be_sock)
		close(be_sock);
}
