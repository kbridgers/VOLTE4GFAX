
#include "wireless_menu_func.h"

struct value_set wireless_security_pskauth_pass_values[] = {
	{"disable", "0"},
	{"enable", "1"}
};

struct value_set wireless_security_openauth_set_activekey_values[] = {
	{"none", "0"},
	{"key1", "1"},
	{"key2", "2"},
	{"key3", "3"},
	{"key4", "4"}
};

struct value_set wireless_security_openauth_set_encrypt_values[] = {
	{"none", "1"},
	{"wep64", "2"},
	{"wep128", "3"},
	{"802.1x", "4"},
	{"tkip", "5"}
};

struct value_set wireless_security_sharedauth_set_encrypt_values[] = {
	{"wep64", "2"},
	{"wep128", "3"}
};

struct value_set wireless_security_wpaauth_set_encrypt_values[] = {
	{"tkip", "5"}
};

struct value_set wireless_security_pskauth_set_encrypt_values[] = {
	{"tkip", "5"}
};

struct value_set wireless_security_openauth_set_keylen_values[] = {
	{"64", "0"},
	{"128", "1"}
};

struct cmd_field wireless_security_openauth_set_cmd_fields[] = {
	{
	 .field_name = "AuthType",
	 .field_help = NULL,
	 .data_type = STR,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .field_display_name = NULL,
	 .cur_value = "1"},
	{
	 .field_name = "EncryType",
	 .field_help = "This field represent the encryption type",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "encrypt",
	 .field_gui_name = "Encryption Type",
	 .values = wireless_security_openauth_set_encrypt_values,
	 .tot_values =
	 sizeof(wireless_security_openauth_set_encrypt_values) /
	 sizeof(struct value_set)

	 },
	{
	 .field_name = "KeyUsed",
	 "This field represent the type of key used",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "activekey",
	 .field_gui_name = "Active Key",
	 .values = wireless_security_openauth_set_activekey_values,
	 .tot_values =
	 sizeof(wireless_security_openauth_set_activekey_values) /
	 sizeof(struct value_set)

	 },
	{
	 .field_name = "Key1",
	 .field_help = "This field represent the key1",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "key1",
	 .field_gui_name = "Key1"},
	{
	 .field_name = "Key2",
	 .field_help = "This field represent the key2",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "key2",
	 .field_gui_name = "Key2"},
	{
	 .field_name = "Key3",
	 .field_help = "This field represent the key3",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "key3",
	 .field_gui_name = "Key3"},
	{
	 .field_name = "Key4",
	 .field_help = "This field represent the key4",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "key4",
	 .field_gui_name = "Key4"},
	{
	 .field_name = "Nas_iden",
	 .field_help = "This field represent the NAS identifier",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "nas",
	 .field_gui_name = "NAS Identifier"},
	{
	 .field_name = "radius_ip",
	 .field_help = "This field represent the radius server ip address",
	 .data_type = IPADDR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "radiusip",
	 .field_gui_name = "Radius Server Address"},
	{
	 .field_name = "radius_port",
	 .field_help = "This field represent the radius server port number",
	 .data_type = INT,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "radiusport",
	 .field_gui_name = "Radius Server Port"},
	{
	 .field_name = "radius_secret",
	 .field_help = "This field represent the radius server secret number",
	 .data_type = INT,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "radiussecret",
	 .field_gui_name = "Radius Server Secret"},
	{
	 .field_name = "P1x_key_len",
	 .field_help = "This field represent the key length",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "keylen",
	 .field_gui_name = "1x Key Length",
	 .values = wireless_security_openauth_set_keylen_values,
	 .tot_values =
	 sizeof(wireless_security_openauth_set_keylen_values) /
	 sizeof(struct value_set)
	 }
};

struct cmd_field wireless_security_sharedauth_set_cmd_fields[] = {
	{
	 .field_name = "AuthType",
	 .field_help = NULL,
	 .data_type = STR,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .field_display_name = NULL,
	 .cur_value = "2"},
	{
	 .field_name = "EncryType",
	 .field_help = "This field represent the encryption type",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "encrypt",
	 .field_gui_name = "Encryption Type",
	 .values = wireless_security_sharedauth_set_encrypt_values,
	 .tot_values =
	 sizeof(wireless_security_sharedauth_set_encrypt_values) /
	 sizeof(struct value_set)

	 },
	{
	 .field_name = "KeyUsed",
	 "This field represent the type of key used",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "activekey",
	 .field_gui_name = "Active Key",
	 .values = wireless_security_openauth_set_activekey_values,
	 .tot_values =
	 sizeof(wireless_security_openauth_set_activekey_values) /
	 sizeof(struct value_set)

	 },
	{
	 .field_name = "Key1",
	 .field_help = "This field represent the key1",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "key1",
	 .field_gui_name = "Key1"},
	{
	 .field_name = "Key2",
	 .field_help = "This field represent the key2",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "key2",
	 .field_gui_name = "Key2"},
	{
	 .field_name = "Key3",
	 .field_help = "This field represent the key3",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "key3",
	 .field_gui_name = "Key3"},
	{
	 .field_name = "Key4",
	 .field_help = "This field represent the key4",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "key4",
	 .field_gui_name = "Key4"}
};

struct cmd_field wireless_security_wpaauth_set_cmd_fields[] = {
	{
	 .field_name = "AuthType",
	 .field_help = NULL,
	 .data_type = STR,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .field_display_name = NULL,
	 .cur_value = "3"},
	{
	 .field_name = "EncryType",
	 .field_help = "This field represent the encryption type",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "encrypt",
	 .field_gui_name = "Encryption Type",
	 .values = wireless_security_wpaauth_set_encrypt_values,
	 .tot_values =
	 sizeof(wireless_security_wpaauth_set_encrypt_values) /
	 sizeof(struct value_set)

	 },
	{
	 .field_name = "Nas_iden",
	 .field_help = "This field represent the NAS identifier",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "nas",
	 .field_gui_name = "NAS Identifier"},
	{
	 .field_name = "radius_ip",
	 .field_help = "This field represent the radius server ip address",
	 .data_type = IPADDR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "radiusip",
	 .field_gui_name = "Radius Server Address",
	 .fprocessing_post = ip_nm_gw_processing},
	{
	 .field_name = "radius_port",
	 .field_help = "This field represent the radius server port number",
	 .data_type = INT,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "radiusport",
	 .field_gui_name = "Radius Server Port"},
	{
	 .field_name = "radius_secret",
	 .field_help = "This field represent the radius server secret number",
	 .data_type = INT,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "radiussecret",
	 .field_gui_name = "Radius Server Secret"}
};

struct cmd_field wireless_security_pskauth_set_cmd_fields[] = {
	{
	 .field_name = "EncryType",
	 .field_help = "This field represent the encryption type",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "encrypt",
	 .field_gui_name = "Encryption Type",
	 .values = wireless_security_pskauth_set_encrypt_values,
	 .tot_values =
	 sizeof(wireless_security_pskauth_set_encrypt_values) /
	 sizeof(struct value_set)

	 },
	{
	 .field_name = "PSK",
	 .field_help = "This field represent the PSK key",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "psk",
	 .field_gui_name = "PSK Key"},
	{
	 .field_name = "IsPassPhrase",
	 .field_help = "This field represent the status of passphrase",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "passphrase",
	 .field_gui_name = "Enable Passphrase",
	 .values = wireless_security_pskauth_pass_values,
	 .tot_values =
	 sizeof(wireless_security_pskauth_pass_values) /
	 sizeof(struct value_set),
	 },
	{
	 .field_name = "AuthType",
	 .field_help = NULL,
	 .data_type = STR,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .field_display_name = NULL,
	 .cur_value = "4"}
};

struct cmd_entry wireless_security_openauth_set_cmd = {
	.fields = wireless_security_openauth_set_cmd_fields,
	.tot_fields =
	    sizeof(wireless_security_openauth_set_cmd_fields) /
	    sizeof(struct cmd_field),
	.help =
	    "This command allows to configure wireless security open authentication parameters",
	.custom_validation = validate_key,
	.post_url = "/goform/ifx_set_wlan_security",
	.get_url = "wireless_security.cli"
};

struct cmd_entry wireless_security_sharedauth_set_cmd = {
	.fields = wireless_security_sharedauth_set_cmd_fields,
	.tot_fields =
	    sizeof(wireless_security_sharedauth_set_cmd_fields) /
	    sizeof(struct cmd_field),
	.help =
	    "This command allows to configure wireless security shared authentication parameters",
	.post_url = "/goform/ifx_set_wlan_security",
	.custom_validation = validate_key,
	.get_url = "wireless_security.cli"
};

struct cmd_entry wireless_security_wpaauth_set_cmd = {
	.fields = wireless_security_wpaauth_set_cmd_fields,
	.tot_fields =
	    sizeof(wireless_security_wpaauth_set_cmd_fields) /
	    sizeof(struct cmd_field),
	.help =
	    "This command allows to configure wireless security wpa authentication parameters",
	.post_url = "/goform/ifx_set_wlan_security",
	.get_url = "wireless_security.cli"
};

struct cmd_entry wireless_security_pskauth_set_cmd = {
	.fields = wireless_security_pskauth_set_cmd_fields,
	.tot_fields =
	    sizeof(wireless_security_pskauth_set_cmd_fields) /
	    sizeof(struct cmd_field),
	.help =
	    "This command allows to configure wireless security psk authentication parameters",
	.post_url = "/goform/ifx_set_wlan_security",
	.get_url = "wireless_security.cli"
};

struct menu_entry wireless_security_openauth_entries[] = {
	{
	 .next_page = NULL,
	 .entry_help =
	 "This is wireless security open authentication show configuration",
	 .cli_name = "Show",
	 .cli_url = "wireless_security_openauth.cli",
	 .cmd = NULL},
	{
	 .next_page = NULL,
	 .entry_help =
	 "This is wireless security open authentication set configuration",
	 .cli_name = "Set",
	 .cmd = &wireless_security_openauth_set_cmd}
};

struct menu_entry wireless_security_sharedauth_entries[] = {
	{
	 .next_page = NULL,
	 .entry_help =
	 "This is wireless security shared authentication show configuration",
	 .cli_name = "Show",
	 .cli_url = "wireless_security_sharedauth.cli",
	 .cmd = NULL},
	{
	 .next_page = NULL,
	 .entry_help =
	 "This is wireless security shared authentication set configuration",
	 .cli_name = "Set",
	 .cmd = &wireless_security_sharedauth_set_cmd,
	 }
};

struct menu_entry wireless_security_wpaauth_entries[] = {
	{
	 .next_page = NULL,
	 .entry_help =
	 "This is wireless security wpa authentication show configuration",
	 .cli_name = "Show",
	 .cli_url = "wireless_security_wpaauth.cli",
	 .cmd = NULL},
	{
	 .next_page = NULL,
	 .entry_help =
	 "This is wireless security wpa authentication set configuration",
	 .cli_name = "Set",
	 .cmd = &wireless_security_wpaauth_set_cmd}
};

struct menu_entry wireless_security_pskauth_entries[] = {
	{
	 .next_page = NULL,
	 .entry_help =
	 "This is wireless security psk authentication show configuration",
	 .cli_name = "Show",
	 .cli_url = "wireless_security_pskauth.cli",
	 .cmd = NULL},
	{
	 .next_page = NULL,
	 .entry_help =
	 "This is wireless security psk authentication set configuration",
	 .cli_name = "Set",
	 .cmd = &wireless_security_pskauth_set_cmd}
};

struct menu_page wireless_security_openauth_page = {
	.entries = wireless_security_openauth_entries,
	.tot_entries =
	    sizeof(wireless_security_openauth_entries) /
	    sizeof(struct menu_entry),
	.page_help =
	    "This page is for open authentication configuration show and set",
	.cli_title = "open authentication",
};

struct menu_page wireless_security_sharedauth_page = {
	.entries = wireless_security_sharedauth_entries,
	.tot_entries =
	    sizeof(wireless_security_sharedauth_entries) /
	    sizeof(struct menu_entry),
	.page_help =
	    "This page is for shared authentication configuration show and set",
	.cli_title = "shared authentication",
};

struct menu_page wireless_security_wpaauth_page = {
	.entries = wireless_security_wpaauth_entries,
	.tot_entries =
	    sizeof(wireless_security_wpaauth_entries) /
	    sizeof(struct menu_entry),
	.page_help =
	    "This page is for wpa authentication configuration show and set",
	.cli_title = "wpa authentication",
};

struct menu_page wireless_security_pskauth_page = {
	.entries = wireless_security_pskauth_entries,
	.tot_entries =
	    sizeof(wireless_security_pskauth_entries) /
	    sizeof(struct menu_entry),
	.page_help =
	    "This page is for psk authentication configuration show and set",
	.cli_title = "psk authentication",
};

struct menu_entry wireless_security_page_entries[] = {
	{
	 .next_page = &wireless_security_openauth_page,
	 .entry_help = "This entry is for open authentication",
	 .cli_name = "Openauth",
	 },
	{
	 .next_page = &wireless_security_sharedauth_page,
	 .entry_help = "This entry is for shared authentication",
	 .cli_name = "Sharedauth",
	 },
	{
	 .next_page = &wireless_security_wpaauth_page,
	 .entry_help = "This entry is for wpa authentication",
	 .cli_name = "Wpaauth",
	 },
	{
	 .next_page = &wireless_security_pskauth_page,
	 .entry_help = "This entry is for psk authentication",
	 .cli_name = "Pskauth",
	 }
};

struct menu_page wireless_security_page = {
	.entries = wireless_security_page_entries,
	.tot_entries =
	    sizeof(wireless_security_page_entries) / sizeof(struct menu_entry),
	.page_help = "this is security page",
	.cli_title = "security",
	.gui_title = "Security"
};

struct value_set wireless_setting_preamble_values[] = {
	{.display_value = "short",.submit_value = "1"},
	{.display_value = "long",.submit_value = "2"},
	{.display_value = "auto",.submit_value = "3"},
};

struct value_set wireless_setting_op_rate_values[] = {
	{.display_value = "802.11b",.submit_value = "1"},
	{.display_value = "802.11g",.submit_value = "2"},
	{.display_value = "auto",.submit_value = "3"}
};

struct value_set wireless_setting_channel_values[] = {
	{.display_value = "ch1",.submit_value = "1"},
	{.display_value = "ch2",.submit_value = "2"},
	{.display_value = "ch3",.submit_value = "3"},
	{.display_value = "ch4",.submit_value = "4"},
	{.display_value = "ch5",.submit_value = "5"},
	{.display_value = "ch6",.submit_value = "6"},
	{.display_value = "ch7",.submit_value = "7"},
	{.display_value = "ch8",.submit_value = "8"},
	{.display_value = "ch9",.submit_value = "9"},
	{.display_value = "ch10",.submit_value = "10"},
	{.display_value = "ch11",.submit_value = "11"},
	{.display_value = "ch12",.submit_value = "12"},
	{.display_value = "ch13",.submit_value = "13"},
	{.display_value = "ch14",.submit_value = "14"}
};

struct value_set wireless_settings_ssid_values[] = {
	{.display_value = "advertise",.submit_value = "0"},
	{.display_value = "hide",.submit_value = "1"}
};

struct cmd_field wireless_settings_config_cmd_field[] = {
	{
	 .field_name = "nick",
	 .field_help = "This field represent the AP Name",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "nick",
	 .field_gui_name = "AP Name"},
	{
	 .field_name = "hiddenSsid",
	 .field_help = "This field represent the ssid mode",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "ssid",
	 .field_gui_name = "SSID Mode",
	 .values = wireless_settings_ssid_values,
	 .tot_values =
	 sizeof(wireless_settings_ssid_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "essid",
	 .field_help = "This field represent the essid",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "essid",
	 .field_gui_name = "ESSID"},
	{
	 .field_name = "channel",
	 .field_help = "This field represent the channel",
	 .data_type = STR,
	 .field_type = STATIC,
	 .values = wireless_setting_channel_values,
	 .tot_values =
	 sizeof(wireless_setting_channel_values) / sizeof(struct value_set),
	 .mandatory = IFX_FALSE,
	 .field_display_name = "channel",
	 .field_gui_name = "Channel ID"},
	{
	 .field_name = "preamble",
	 .field_help = "This field represent the preamble",
	 .data_type = STR,
	 .field_type = STATIC,
	 .values = wireless_setting_preamble_values,
	 .tot_values =
	 sizeof(wireless_setting_preamble_values) / sizeof(struct value_set),
	 .mandatory = IFX_FALSE,
	 .field_display_name = "preamble",
	 .field_gui_name = "Preamble Mode"},
	{
	 .field_name = "op_rate",
	 .field_help = "This field represent the operation rate",
	 .data_type = STR,
	 .field_type = STATIC,
	 .values = wireless_setting_op_rate_values,
	 .tot_values =
	 sizeof(wireless_setting_op_rate_values) / sizeof(struct value_set),
	 .mandatory = IFX_FALSE,
	 .field_display_name = "op_rate",
	 .field_gui_name = "Operation Rate"},
	{
	 .field_name = "beacon_interval",
	 .field_help = "This field represent the beacon interval",
	 .data_type = INT,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "beacon_int",
	 .field_gui_name = "Beacon Interval"},
	{
	 .field_name = "rts",
	 .field_help = "This field represent the RTS threshold",
	 .data_type = INT,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "rts",
	 .field_gui_name = "RTS Threshold"},
	{
	 .field_name = "fts",
	 .field_help = "This field represent the FTS threshold",
	 .data_type = INT,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "fts",
	 .field_gui_name = "Fragmentation Threshold"}
};

struct cmd_entry wireless_settings_config_cmd = {
	.fields = wireless_settings_config_cmd_field,
	.tot_fields =
	    sizeof(wireless_settings_config_cmd_field) /
	    sizeof(struct cmd_field),
	.help = "This command configures security settings",
	.post_url = "/goform/ifx_set_wlan_settings",
	.get_url = "wireless_settings.cli"
	    //settings_config_custom_valid
	    //settings_config_post_flag
};

struct menu_entry wireless_settings_entries[] = {
	{
	 .entry_help = "This is settings show entry",
	 .cli_name = "Show",
	 .cli_url = "wireless_settings.cli"},
	{
	 .entry_help = "This is settings config entry",
	 .cli_name = "Set",
	 .cmd = &wireless_settings_config_cmd}
};

struct menu_page wireless_settings_page = {
	.entries = wireless_settings_entries,
	.tot_entries =
	    sizeof(wireless_settings_entries) / sizeof(struct menu_entry),
	.page_help = "This is wireless settings page",
	.cli_title = "wireless settings",
	.gui_title = "Wireless Settings"
};

struct menu_entry wireless_page_entries[] = {
	{
	 .next_page = &wireless_security_page,
	 .entry_help = "wireless security",
	 .cli_name = "security",
	 .gui_name = "Security",
	 .gui_url = "wireless_security.asp",
	 },
	{
	 .next_page = &wireless_settings_page,
	 .entry_help = "wireless settings",
	 .cli_name = "settings",
	 .gui_name = "Settings",
	 .gui_url = "wireless_settings.asp",
	 }
};

struct menu_page wireless_page = {
	.entries = wireless_page_entries,
	.tot_entries =
	    sizeof(wireless_page_entries) / sizeof(struct menu_entry),
	.page_help = "The wireless page",
	.cli_title = "wireless",
	.gui_title = "Wireless",
	.fpos = 1
};
