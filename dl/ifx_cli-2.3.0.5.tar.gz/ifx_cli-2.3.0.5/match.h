#ifndef __MATCH_H__		/* [ */
#define __MATCH_H__

#define ALIGN_LEFT	0
#define ALIGN_RIGHT	1
#define ALIGN_CENTER	2

#endif				/* ] __MATCH_H__ */
