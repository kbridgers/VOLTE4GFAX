
struct value_set snmp_config_enable1_values[] = {
	{.display_value = "enable",.submit_value = "1"},
	{.display_value = "disable",.submit_value = "0"}
};

struct value_set snmp_config_enable_values[] = {
	{.display_value = "disable",.submit_value = "0"},
	{.display_value = "enable",.submit_value = "1"}
};

struct cmd_field snmp_config_cmd_fields[] = {
	{
	 .field_name = "SNMPEnable",
	 .field_help = "Represents the status of snmp",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "SNMPEnable",.values = snmp_config_enable_values,
	 .field_gui_name = "SNMP Status",
	 .tot_values =
	 sizeof(snmp_config_enable_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "SNMProcommunity",
	 .field_help = "Represents the read only community",
	 .data_type = STR,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "SNMProcommunity",
	 .field_gui_name = "Read Only Community",
	 },
	{
	 .field_name = "SNMPrwcommunity",
	 .field_help = "Represents the read write community",
	 .data_type = STR,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "SNMPrwcommunity",
	 .field_gui_name = "Read Write Community",
	 },
	{
	 .field_name = "SNMPTrapEnable",
	 .field_help = "Represents status of snmp trap",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "SNMPTrapEnable",
	 .field_gui_name = "Enable Trap",
	 .values = snmp_config_enable_values,
	 .tot_values =
	 sizeof(snmp_config_enable_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "SNMPTrapIP",
	 .field_help = "Represents the snmp trap ip address",
	 .data_type = IPADDR,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "SNMPTrapIP",
	 .field_gui_name = "Trap IP Address"},
	{
	 .field_name = "SNMPTrapPort",
	 .field_help = "Represents the snmp trap port number",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "SNMPTrapPort",
	 .field_gui_name = "Trap Port"},
	{
	 .field_name = "SNMPTrapCommunity",
	 .field_help = "Represents the snmp trap community",
	 .data_type = STR,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "SNMPTrapCommunity",
	 .field_gui_name = "Trap COmmunity"},
};

struct cmd_entry snmp_config_cmd = {
	.fields = snmp_config_cmd_fields,
	.tot_fields = sizeof(snmp_config_cmd_fields) / sizeof(struct cmd_field),
	.help = "This command configures snmp settings",
	.post_url = "/goform/ifx_set_snmp_settings",
	.get_url = "snmp_settings.cli"
};

struct menu_entry snmp_page_entries[] = {
	{
	 .entry_help = "This is snmp_show entry",
	 .cli_name = "Show",.cli_url = "snmp_settings.cli"},
	{
	 .entry_help = "This is snmp_config entry",
	 .cli_name = "Config",.cmd = &snmp_config_cmd}
};

struct menu_page snmp_page = {
	.entries = snmp_page_entries,
	.tot_entries = sizeof(snmp_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is snmp page",.cli_title = "snmp",.gui_title = "SNMP"
};
