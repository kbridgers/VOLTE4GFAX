/*
000001:tc.chen 2005/06/07 add IP QoS and 802.1P priority queue
*/
//000001:tc.chen start
int qos_priority_queue_del_post(struct cmd_entry *cmd, char *poststr);
int qos_priority_add_valid(struct cmd_entry *cmd, char *errstr);
//000001:tc.chen end
