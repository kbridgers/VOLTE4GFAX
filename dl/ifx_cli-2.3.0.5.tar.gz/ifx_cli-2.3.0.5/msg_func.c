/*
000001:tc.chen 2005/06/07 add IP QoS and 802.1P priority queue
*/
/* ============================================================================
 * Copyright (C) 2005 -Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 *============================================================================
 *
 * This document contains proprietary information belonging to Infineon 
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 * 
 * ============================================================================
 */

/* ===========================================================================
 *
 * File Name:   adsl_menu_func.c
 * Author :     Nirav Salot
 * Date: 		April, 2005
 *
 * ===========================================================================
 *
 * Project: Amazon
 *
 * ===========================================================================
 * Contents: This file implements ADSL menu related specific functions.
 *  
 * ===========================================================================
 * References: 
 *
 */
#include "common.h"

#define ADDNEWSTR(strdest,cursize,strsrc,strsave)	strdest = (char *)realloc(strdest,(cursize) + strlen(strsrc) + 1); 	\
		memset(strdest + cursize,0x00,strlen(strsrc) + 1);	\
		strcpy(strdest + cursize,strsrc);	\
		strsave = (char *)(cursize);			\
		cursize += strlen(strsrc) + 1;

#define MAX_STRSIZE	256

int make_show_msg(char *curres, char **ppresponse, int *preslen)
{
	struct toplevel_be_msg cur_be_msg;
	bzero(&cur_be_msg, sizeof(cur_be_msg));

	if (curres == NULL) {
		return -1;
	}

	*ppresponse = calloc(1, sizeof(cur_be_msg) + strlen(curres));

	if (*ppresponse == NULL) {
		return -1;
	}

	cur_be_msg.msg_type = MSG_SHOW;
	memcpy(*ppresponse, &cur_be_msg, sizeof(cur_be_msg));
	*preslen = sizeof(cur_be_msg);
	strncpy(*ppresponse + *preslen, curres, strlen(curres));
	*preslen += strlen(curres);
	return 0;
}

int make_menu_msg(struct menu_page *cur_page, char **ppresponse, int *preslen)
{
	struct menu_entry *cur_menu_entry = NULL;
	int i;
	int ntot_bytes = 0;
	struct toplevel_be_msg tmsg;
	struct menu_msg cur_menu_msg;
	int menu_msgloc = 0;
	int tot_entries = 0;

	if (cur_page == NULL) {
		return -1;
	}

	*ppresponse = (char *)calloc(1, sizeof(tmsg));

	if (*ppresponse == NULL) {
		return -1;
	}

	tmsg.msg_type = MSG_MENU;
	ntot_bytes = sizeof(tmsg);

	for (i = 0, cur_menu_entry = cur_page->entries;
	     i < cur_page->tot_entries; i++, cur_menu_entry++) {
		*ppresponse =
		    (char *)realloc(*ppresponse,
				    ntot_bytes + sizeof(cur_menu_msg));
		menu_msgloc = ntot_bytes;
		ntot_bytes += sizeof(cur_menu_msg);

		if (cur_menu_entry->gui_name) {
			ADDNEWSTR(*ppresponse, ntot_bytes,
				  cur_menu_entry->gui_name,
				  cur_menu_msg.menu_display_name);
		} else {
			ADDNEWSTR(*ppresponse, ntot_bytes,
				  cur_menu_entry->cli_name,
				  cur_menu_msg.menu_display_name);
		}

		ADDNEWSTR(*ppresponse, ntot_bytes, cur_menu_entry->cli_name,
			  cur_menu_msg.menu_submit_name);

		if (cur_menu_entry->cmd) {
			//char strhelp[1024]; 000001:tc.chen
			char strhelp[2048];	//000001:tc.chen
			memset(strhelp, 0x00, sizeof(strhelp));
			gen_syntax(cur_menu_entry, strhelp, 1);
			ADDNEWSTR(*ppresponse, ntot_bytes, strhelp,
				  cur_menu_msg.menu_help);
		} else {
			ADDNEWSTR(*ppresponse, ntot_bytes,
				  cur_menu_entry->entry_help,
				  cur_menu_msg.menu_help);
		}

		cur_menu_msg.next = (struct menu_msg *)ntot_bytes;
		memcpy(*ppresponse + menu_msgloc, &cur_menu_msg,
		       sizeof(cur_menu_msg));
		tot_entries++;
	}
	if (tot_entries > 0) {
		cur_menu_msg.next = (struct menu_msg *)NULL;
		memcpy(*ppresponse + menu_msgloc, &cur_menu_msg,
		       sizeof(cur_menu_msg));
	}
	*preslen = ntot_bytes;
	//finally copy the top level message
	tmsg.tot_entries = tot_entries;
	if (*ppresponse)
		memcpy(*ppresponse, &tmsg, sizeof(tmsg));
	return 0;
}

int make_cmd_msg(struct cmd_entry *cmd, char **ppresponse, int *preslen)
{
	struct cmd_field *cur_field = NULL;
	int i;
	int ntot_bytes = 0;
	struct toplevel_be_msg tmsg;
	struct cmd_msg cur_cmd_msg;
	int cmd_msgloc = 0;
	struct field_value_set *cmd_get_fvset = NULL;
	int tot_get_fvset = 0;
	int tot_entries = 0;

	bzero(&cur_cmd_msg, sizeof(cur_cmd_msg));

	if (cmd == NULL) {
		return -1;
	}

	*ppresponse = (char *)calloc(1, sizeof(tmsg));

	if (*ppresponse == NULL) {
		return -1;
	}

	tmsg.msg_type = MSG_CMD;
	ntot_bytes = sizeof(tmsg);
#if CMD_READ_MODIFY_WRITE
	/* If for the current command get_url is defined... */
	if (cmd->get_url) {
		tot_get_fvset = 0;
		cmd_get_fvset = make_get_fvset(cmd->get_url, &tot_get_fvset);
#if 0
		if (cmd_get_fvset == NULL) {
			char response[128];
			sprintf(response,
				"Error : No data received from httpd server [%s] !\n",
				cmd->get_url);
			if (*ppresponse)
				free(*ppresponse);
			*ppresponse = NULL;
			*preslen = 0;
			make_show_msg(response, ppresponse, preslen);
			/* can not be proceeded... */
			return -1;
		}
#endif
		update_cmd_cur_values(cmd, cmd_get_fvset, tot_get_fvset);
	}
#endif
	if (get_dynamic_fvset(cmd)) {
		char response[128];
		if (*ppresponse)
			free(*ppresponse);
		*ppresponse = NULL;
		*preslen = 0;
		sprintf(response,
			"Error : Could not fetch field valus from backend\n");
		make_show_msg(response, ppresponse, preslen);
#if CMD_READ_MODIFY_WRITE
		printf("cli_be : calling free_cmd_get_fvset\n");
		free_cmd_fvset(cmd_get_fvset, &tot_get_fvset);
#endif
		/* can not be proceeded... */
		return -1;
	}

	for (i = 0, cur_field = cmd->fields; i < cmd->tot_fields;
	     i++, cur_field++) {
		char strdisplay[MAX_STRSIZE];
		char str_statvalues[MAX_STRSIZE];
		int n_curstatval = 1;

		if (cur_field->field_type == HIDDEN)
			continue;

		*ppresponse =
		    (char *)realloc(*ppresponse,
				    ntot_bytes + sizeof(cur_cmd_msg));
		cmd_msgloc = ntot_bytes;
		ntot_bytes += sizeof(cur_cmd_msg);

		ADDNEWSTR(*ppresponse, ntot_bytes,
			  cur_field->field_display_name,
			  cur_cmd_msg.field_name);

		memset(strdisplay, 0x00, sizeof(strdisplay));
		memset(str_statvalues, 0x00, sizeof(str_statvalues));
		if (cur_field->field_gui_name)
			strcpy(strdisplay, cur_field->field_gui_name);
		else
			strcpy(strdisplay, cur_field->field_display_name);
		if (cur_field->field_type == STATIC
		    || cur_field->field_type == DYNAMIC) {
			int k;
			struct value_set *cur_vset = NULL;
			strcat(strdisplay, " [");
			for (k = 0, cur_vset = cur_field->values;
			     k < cur_field->tot_values; k++, cur_vset++) {
				char temp[8];
				snprintf(temp, sizeof(temp), "%d",
					 (int16_t) k + 1);
				strcat(strdisplay, temp);
				strcat(strdisplay, "-");
				strcat(strdisplay, cur_vset->display_value);
				strcat(str_statvalues, cur_vset->display_value);
				if (k < cur_field->tot_values - 1) {
					strcat(strdisplay, ",");
					strcat(str_statvalues, ",");
				}
				if (cur_field->cur_value) {
					if (strcmp
					    (cur_field->cur_value,
					     cur_vset->submit_value) == 0)
						n_curstatval = k + 1;
				}
			}
			strcat(strdisplay, "]");
			cur_cmd_msg.tot_statvalues = cur_field->tot_values;
		} else {
			cur_cmd_msg.tot_statvalues = 0;
			cur_cmd_msg.str_statvalues = NULL;
		}

		ADDNEWSTR(*ppresponse, ntot_bytes, strdisplay,
			  cur_cmd_msg.display_str);

		if (cur_field->cur_value && cur_field->field_type != STATIC
		    && cur_field->field_type != DYNAMIC) {
			ADDNEWSTR(*ppresponse, ntot_bytes, cur_field->cur_value,
				  cur_cmd_msg.default_val);
		} else if (cur_field->field_type == STATIC
			   || cur_field->field_type == DYNAMIC) {
			char tstr[8];
			memset(tstr, 0x00, sizeof(tstr));
			snprintf(tstr, sizeof(tstr), "%d",
				 (int16_t) n_curstatval);
			ADDNEWSTR(*ppresponse, ntot_bytes, tstr,
				  cur_cmd_msg.default_val);
		} else {
			ADDNEWSTR(*ppresponse, ntot_bytes, "\0",
				  cur_cmd_msg.default_val);
		}

		ADDNEWSTR(*ppresponse, ntot_bytes, cur_field->field_help,
			  cur_cmd_msg.field_help);

		if (strcmp(str_statvalues, "") == 0) {
			ADDNEWSTR(*ppresponse, ntot_bytes, "\0",
				  cur_cmd_msg.str_statvalues);
		} else {
			ADDNEWSTR(*ppresponse, ntot_bytes, str_statvalues,
				  cur_cmd_msg.str_statvalues);
		}

		cur_cmd_msg.data_type = cur_field->data_type;
		cur_cmd_msg.field_type = cur_field->field_type;
		cur_cmd_msg.mandatory = cur_field->mandatory;
		cur_cmd_msg.next = (struct cmd_msg *)ntot_bytes;

		if (*ppresponse)
			memcpy(*ppresponse + cmd_msgloc, &cur_cmd_msg,
			       sizeof(cur_cmd_msg));
		tot_entries++;
	}

	if (tot_entries > 0) {
		cur_cmd_msg.next = (struct cmd_msg *)NULL;
		memcpy(*ppresponse + cmd_msgloc, &cur_cmd_msg,
		       sizeof(cur_cmd_msg));
	}
	*preslen = ntot_bytes;

#if CMD_READ_MODIFY_WRITE
	printf("%s : calling free_cmd_get_fvset\n", __FUNCTION__);
	free_cmd_fvset(cmd_get_fvset, &tot_get_fvset);
	printf("%s : calling reset_cmd_field_values\n", __FUNCTION__);
	reset_cmd_field_values(cmd);
#endif
	printf("%s : calling free_vset\n", __FUNCTION__);
	free_vset(cmd);
	//finally copy the top level message
	tmsg.tot_entries = tot_entries;

	if (ppresponse)
		memcpy(*ppresponse, &tmsg, sizeof(tmsg));

	return 0;
}

int make_be_msg(struct menu_entry *cur_menu_entry, char **ppresponse,
		int *preslen)
{
	if (cur_menu_entry == NULL) {
		return -1;
	}

	if (cur_menu_entry->cmd)
		make_cmd_msg(cur_menu_entry->cmd, ppresponse, preslen);
	else if (cur_menu_entry->next_page)
		make_menu_msg(cur_menu_entry->next_page, ppresponse, preslen);
	else
		sprintf(*ppresponse,
			"No type found for cur_menu_entry->cli_name [%s]\n",
			cur_menu_entry->cli_name);
	return 0;
}
