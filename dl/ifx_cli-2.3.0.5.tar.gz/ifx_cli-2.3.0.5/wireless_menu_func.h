
int validate_key(struct cmd_entry *cmd, char *errstr);
