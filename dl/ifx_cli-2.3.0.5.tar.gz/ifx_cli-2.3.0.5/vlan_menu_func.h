int vlan_portmap_cmd_post(struct cmd_entry *cur_cmd, char *poststr);
