
/* ============================================================================
 * Copyright (C) 2005 -Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 *============================================================================
 *
 * This document contains proprietary information belonging to Infineon 
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 * 
 * ============================================================================
 */

/* ===========================================================================
 *
 * File Name:   cli_be.c
 * Author :     Nirav Salot
 * Date: 		April, 2005
 *
 * ===========================================================================
 *
 * Project: Amazon
 *
 * ===========================================================================
 * Contents: This file implements the CLI backend infrastructure which provides
 * all the CLI processing capabilities. The CLI frontend (cli_fe) interacts
 * with the cli_be and in turn, cli_be interacts with the web server.
 *  
 * ===========================================================================
 * References: 
 *
 */

/* ===========================================================================
 * Revision History:
 *
 * $Log$
 * ===========================================================================
 */
#include "common.h"

#define PREVIOUS_CHAR   "<"

#define IFX_OK		0
#define IFX_ERR 	-1
#define IFX_CANCEL	-2
#define IFX_GOBACK	-3
#define IFX_HELP	-4
#define IFX_ERRRANGE	-5

#define MAX_PROMPT_SIZE 256

/* Checks if current string is number */
int isnum(char *str)
{
	while (isdigit(*str))
		str++;
	return (*str) ? 0 : 1;
}

int prompt_string(char *prompt, char *def_val, char *str_val, int max_len,
		  int special, int bint, int min_val, int max_val);
int prompt_int(char *prompt, char *def_val, char *int_val, int min_val,
	       int max_val);

int PROMPT_STRING(char *prompt, char *help, char *def_val, char *var,
		  int maxlen, int bmandatory, int special, int bint,
		  int min_val, int max_val)
{
	int stat;
	do {
		stat =
		    prompt_string(prompt, def_val, var, maxlen, special, bint,
				  min_val, max_val);
		if (stat == IFX_ERR)
			printf("Wrong Input Type . Try again.. \n");
		else if (stat == IFX_HELP)
			printf("%s\n", help);
		else if (stat == IFX_ERRRANGE) {
		} else if (strcmp(var, "") == 0 && bmandatory)
			printf("This is mandatory field.\n");
		else
			break;
	} while (1);
	return stat;
}

#if 0
int PROMPT_INT(char *prompt, char *help, char *def_val, char *var, int min_val,
	       int max_val, int bmandatory)
{
	int stat;
	do {
		stat = prompt_int(prompt, def_val, var, min_val, max_val);
		if (stat == IFX_ERR)
			printf("Wrong Input Type . Try again.. \n");
		else if (stat == IFX_ERRRANGE)
			printf
			    ("Input out of range. Please enter between [%d-%d]\n",
			     min_val, max_val);
		else if (stat == IFX_HELP)
			printf("%s\n", help);
		else if (strcmp(var, "") == 0 && bmandatory)
			printf("This is mandatory field.\n");
		else
			break;
	} while (1);
	return stat;
}
#endif
#define PROMPT_HEX(prompt,def_val,var) \
{ \
	int stat; \
	do { \
		stat=prompt_hex(prompt,def_val,var,16); \
		if (stat == IFX_ERR) \
			printf("Wrong Input Type . Try again.. \n"); \
	} while(stat !=IFX_OK);  \
}

int check_specialval(char *tstr)
{
	if (strcmp(tstr, PREVIOUS_CHAR) == 0)
		return (IFX_GOBACK);
	else if (strcmp(tstr, HELP_CHAR) == 0)
		return (IFX_HELP);
	else if (strcmp(tstr, EXIT_CHAR) == 0)
		return (IFX_CANCEL);
	else
		return 0;
}

#if 0
int prompt_int(char *prompt, char *def_val, char *int_val, int min_val,
	       int max_val)
{
	int stat = 0;
	int j = 0;
	char ch = -1;
	char buf[MAX_PROMPT_SIZE];
	char tstr[MAX_PROMPT_SIZE];
	int val;

	memset(buf, 0x00, sizeof(buf));
	memset(tstr, 0x00, sizeof(tstr));
	strcat(buf, prompt);

	for (j = strlen(buf); ((j + strlen(def_val) + 4) % COLON_POS) != 0; j++)
		buf[j] = ' ';

	if (strcmp(def_val, "") == 0) {
		strcat(buf, " ");
		strcat(buf, "  :");
	} else {
		strcat(buf, "[");
		strcat(buf, def_val);
		strcat(buf, "] :");
	}

	j = 0;
	while (j < strlen(buf)) {
		putchar(buf[j]);
		j++;
		if ((j % COLON_POS) == 0 && j != strlen(buf))
			putchar('\n');
	}
	putchar(' ');
	memset(tstr, 0x00, sizeof(tstr));
	for (j = 0; ch != '\n'; j++) {
		ch = getchar();
		if ((j == 0) && (ch == '\n')) {
			strcpy(int_val, def_val);	/* Copy default value */
			return (IFX_OK);
		}
		tstr[j] = ch;
	}
	tstr[--j] = '\0';
	strcpy(int_val, tstr);
	stat = check_specialval(tstr);
	if (stat)
		return stat;
	if (!isnum(tstr))
		return IFX_ERR;
	val = strtol(tstr, NULL, 10);
	if (val < min_val || val > max_val) {
		return IFX_ERRRANGE;
	}
	return (IFX_OK);
}
#endif

int prompt_string(char *prompt, char *def_val, char *str_val, int max_len,
		  int special, int bint, int min_val, int max_val)
{
	int stat = 0;
	int j = 0;
	int len;
	//char ch = -1;
	char buf[MAX_PROMPT_SIZE];
	char *ptr1;
	char *ptr2 = NULL;
	struct termios old, new;
	int val;

	memset(buf, 0x00, sizeof(buf));
	strcat(buf, prompt);

	ptr1 = buf;
	j = 0;
	len = 0;
	while (j < strlen(buf)) {
		len++;
		ptr2 = NULL;
		if (buf[j] == ',') {
			if (ptr1 != NULL) {
				ptr1 = strchr(ptr1, ',');
				if (ptr1 == NULL) {
					putchar('\n');
					len = 0;
				} else {
					ptr2 = strchr(ptr1 + 1, ',');
					if (ptr2 == NULL) {
						if ((len >= COLON_POS)
						    && strlen(buf) >
						    COLON_POS) {
							putchar('\n');
							len = 0;
						}
					} else if (ptr2 - ptr1 + len >
						   COLON_POS) {
						putchar('\n');
						len = 0;
					}
					ptr1 = ptr1 + 1;
				}
			}
		} else {
			if ((len % COLON_POS) == 0)
				len = 0;
		}
		putchar(buf[j]);
		j++;
	}
	if (len + 4 >= COLON_POS)
		len = 0;
	for (j = len; ((j + strlen(def_val) + 4) % COLON_POS) != 0; j++)
		putchar(' ');
	if (strcmp(def_val, "") == 0)
		printf("  :");
	else
		printf("[%s]:", def_val);
	putchar(' ');

	if (special) {		/* For password */
		tcgetattr(STDIN_FILENO, &old);
		tcgetattr(STDIN_FILENO, &new);
		//new.c_iflag &= ~(IXON|IXOFF|IXANY);
		new.c_lflag &= ~(ECHO);
		tcsetattr(STDIN_FILENO, TCSANOW, &new);
	}
#if 1
	j = 0;
	while ((str_val[j++] = getchar()) != '\n') ;
	str_val[--j] = '\0';
	if (special) {
		tcsetattr(STDIN_FILENO, TCSANOW, &old);
		printf("\n");
	}
	if ((str_val[j] == '\0') && (j == 0)) {
		strcpy(str_val, def_val);	/* Copy default value */
		return (IFX_OK);
	}
#else
	for (j = 0; ch != '\n'; j++) {
		ch = getchar();
		if ((ch == '\n') && (j == 0)) {
			strcpy(str_val, def_val);	/* Copy default value */
			if (special) {
				tcsetattr(STDIN_FILENO, TCSANOW, &old);
				printf("\n");
			}
			return (IFX_OK);
		}
		str_val[j] = ch;
	}
	if (special) {
		tcsetattr(STDIN_FILENO, TCSANOW, &old);
		printf("\n");
	}
	str_val[--j] = '\0';
#endif
	stat = check_specialval(str_val);
	if (stat)
		return stat;
	if (j > max_len) {
		strcpy(str_val, def_val);
		return IFX_ERR;
	}
	if (bint) {
		if (!isnum(str_val))
			return IFX_ERR;
		val = strtol(str_val, NULL, 10);
		if (val < min_val || val > max_val) {
			printf
			    ("Input out of range. Please enter between [%d-%d]\n",
			     min_val, max_val);
			return IFX_ERRRANGE;
		}
	}
	return (IFX_OK);
}

#define MACADDR_CHR "0123456789ABCDEFabcdef"

int ismacaddr(char *str)
{
	char macaddr[64];
	char *next_tok = NULL;
	int i;

	memset(macaddr, 0x00, sizeof(macaddr));
	strlcpy(macaddr, str, sizeof(macaddr));
	if (macaddr[strlen(macaddr) - 1] == ':')
		return 0;
	next_tok = strtok(macaddr, ":");
	for (i = 0; i < 6; i++) {
		if (next_tok == NULL)
			return 0;

		if (strchr(MACADDR_CHR, next_tok[0]) == NULL ||
		    strchr(MACADDR_CHR, next_tok[1]) == NULL ||
		    strlen(next_tok) > 2)
			return 0;
		next_tok = strtok(NULL, ":");
	}
	if (next_tok != NULL)
		return 0;
	return 1;
}

/* Checks if current string is ipaddr. i.e. xxx.xxx.xxx.xxx where 0 <= xxx <= 255 */
int isipaddr(char *str)
{
	char ipaddr[64];
	char *next_tok;
	int i;

	memset(ipaddr, 0x00, sizeof(ipaddr));
	strncpy(ipaddr, str, sizeof(ipaddr) - 1);

	if (ipaddr[strlen(ipaddr) - 1] == '.')
		return 0;

	next_tok = strtok(ipaddr, ".");
	for (i = 0; i < 4; i++) {
		int num = 0;
		if (next_tok == NULL)
			return 0;
		if (!isnum(next_tok))
			return 0;
		num = strtol(next_tok, NULL, 10);
		if (num < 0 || num > 255)
			return 0;
		next_tok = strtok(NULL, ".");
	}
	if (next_tok != NULL)
		return 0;

	return 1;
}

void index_to_val(int index, char *sep, char *src, char *dest)
{
	char *ptemp = NULL;
	int i = 0;
	char buf[256];

	memset(buf, 0x00, sizeof(buf));
	strcpy(buf, src);

	while (i < index) {
		if (i == 0)
			ptemp = strtok(buf, sep);
		else
			ptemp = strtok(NULL, sep);
		i++;
	}
	if (ptemp)
		strcpy(dest, ptemp);
}

int prompt_validate_value(struct cmd_msg *pcur_cmd_msg)
{
	char tstr[128];
	int retval = 0;
	int stat = 0;
	int done;
	do {
		do {
			memset(tstr, 0x00, sizeof(tstr));
			done = 0;
			switch (pcur_cmd_msg->field_type) {
			case HIDDEN:	/* Not possible */
				break;

			case STATIC:
			case DYNAMIC:
				stat =
				    PROMPT_STRING(pcur_cmd_msg->display_str,
						  pcur_cmd_msg->field_help,
						  pcur_cmd_msg->default_val,
						  tstr, sizeof(tstr),
						  pcur_cmd_msg->mandatory, 0, 1,
						  1,
						  pcur_cmd_msg->tot_statvalues);
				if (stat == IFX_OK) {
					int val;
					val = atoi(tstr);
					if ((val < 0) || (val > 32767)) {
						done = 0;
						break;
					}
					index_to_val(val, ",",
						     pcur_cmd_msg->
						     str_statvalues, tstr);
					done = 1;
				}
				break;

			case USR_DEF:
				switch (pcur_cmd_msg->data_type) {
				case INT:
					stat =
					    PROMPT_STRING(pcur_cmd_msg->
							  display_str,
							  pcur_cmd_msg->
							  field_help,
							  pcur_cmd_msg->
							  default_val, tstr,
							  sizeof(tstr),
							  pcur_cmd_msg->
							  mandatory, 0, 1, 0,
							  65535);
					if (stat == IFX_OK)
						done = 1;
					break;

				case CHAR:
				case STR:
					stat =
					    PROMPT_STRING(pcur_cmd_msg->
							  display_str,
							  pcur_cmd_msg->
							  field_help,
							  pcur_cmd_msg->
							  default_val, tstr,
							  sizeof(tstr),
							  pcur_cmd_msg->
							  mandatory, 0, 0, 0,
							  0);
					if (stat == IFX_OK)
						done = 1;
					break;

				case PASSWD:
					stat =
					    PROMPT_STRING(pcur_cmd_msg->
							  display_str,
							  pcur_cmd_msg->
							  field_help,
							  pcur_cmd_msg->
							  default_val, tstr,
							  sizeof(tstr),
							  pcur_cmd_msg->
							  mandatory, 1, 0, 0,
							  0);
					if (stat == IFX_OK)
						done = 1;
					break;

				case IPADDR:
				case NETMASK:
					stat =
					    PROMPT_STRING(pcur_cmd_msg->
							  display_str,
							  pcur_cmd_msg->
							  field_help,
							  pcur_cmd_msg->
							  default_val, tstr,
							  sizeof(tstr),
							  pcur_cmd_msg->
							  mandatory, 0, 0, 0,
							  0);
					if (stat == IFX_OK) {
						if (isipaddr(tstr))
							done = 1;
						else if (strcmp(tstr, "") == 0
							 && pcur_cmd_msg->
							 mandatory == IFX_FALSE)
							done = 1;
						else
							printf
							    ("This is not a valid ip address\n");
					}
					break;
				case MACADDR:
					stat =
					    PROMPT_STRING(pcur_cmd_msg->
							  display_str,
							  pcur_cmd_msg->
							  field_help,
							  pcur_cmd_msg->
							  default_val, tstr,
							  sizeof(tstr),
							  pcur_cmd_msg->
							  mandatory, 0, 0, 0,
							  0);
					if (stat == IFX_OK) {
						if (ismacaddr(tstr))
							done = 1;
						else if (strcmp(tstr, "") == 0
							 && pcur_cmd_msg->
							 mandatory == IFX_FALSE)
							done = 1;
						else
							printf
							    ("This is not a valid mac address\n");
					}
					break;
				}
				break;
			}
			if (stat == IFX_GOBACK || stat == IFX_CANCEL)
				return stat;
		} while (!done);
		pcur_cmd_msg->cur_value =
		    (char *)realloc(pcur_cmd_msg->cur_value, strlen(tstr) + 1);
		if (pcur_cmd_msg->cur_value == NULL) {
			printf("Out of Memory\n");
			if (pcur_cmd_msg->next->cur_value)
				free(pcur_cmd_msg->next->cur_value);

			free(pcur_cmd_msg);

			return -1;
		}
		memset(pcur_cmd_msg->cur_value, 0x00, strlen(tstr) + 1);
		strcpy(pcur_cmd_msg->cur_value, tstr);

		if (pcur_cmd_msg->next)
			retval = prompt_validate_value(pcur_cmd_msg->next);
	} while (retval != IFX_OK && retval != IFX_CANCEL);
	return retval;
}
