#include "system_menu_func.h"

struct value_set system_time_tz_values[] = {
	{"Eniwetok", "0"},
	{"MidwayIsland", "1"},
	{"Hawaii", "2"},
	{"Alaska", "3"},
	{"PacificTime(US&Canada)", "4"},
	{"Arizona", "5"},
	{"MountainTime(US&Canada)", "6"},
	{"Central America", "7"},
	{"CentralTime(US&Canada)", "8"},
	{"MexicoCity", "9"},
	{"Saskatchewan", "10"},
	{"Bogota", "11"},
	{"EasternTime(US&Canada)", "12"},
	{"Indiana(East)", "13"},
	{"AtlanticTime", "14"},
	{"Caracas", "15"},
	{"Santiago", "16"},
	{"Newfoundland", "17"},
	{"Brasilia", "18"},
	{"BuenosAires", "19"},
	{"Greenland", "20"},
	{"Mid-Atlantic", "21"},
	{"Azores", "22"},
	{"CapeVerde", "23"},
	{"Casablanca", "24"},
	{"GMTLondon", "25"},
	{" Amsterdam", "26"},
	{" Belgrade", "27"},
	{" Paris", "28"},
	{" Sarajevo", "29"},
	{" WestCentralAfrica", "30"},
	{" Athens", "31"},
	{" Bucharest", "32"},
	{" Cairo", "33"},
	{" Harare", "34"},
	{" Helsinki", "35"},
	{" Jerusalem", "36"},
	{" Baghdad", "37"},
	{" Kuwait", "38"},
	{" Moscow", "39"},
	{" Nairobi", "40"},
	{" Tehran", "41"},
	{" AbuDhabi", "42"},
	{" Baku", "43"},
	{" Kabul", "44"},
	{" Ekaterinburg", "45"},
	{" Islamabad", "47"},
	{" New Delhi", "48"},
	{" Kathmandu", "49"},
	{" Almaty", "50"},
	{" Dhaka", "51"},
	{" SriJayawardenepura", "52"},
	{" Rangoon", "53"},
	{" Bangkok", "54"},
	{" Krasnoyarsk", "55"},
	{" Beijing", "56"},
	{" Irkutsk", "57"},
	{" Kuala Lumpur", "57"},
	{" Perth", "58"},
	{" Taipei", "59"},
	{" Toyko", "60"},
	{" Seoul", "61"},
	{" Yakutsk", "62"},
	{" Adelaide", "63"},
	{" Darwin", "64"},
	{" Brisbane", "65"},
	{" Canberra", "66"},
	{" Guam", "67"},
	{" Hobart", "68"},
	{" Vladivostok", "69"},
	{" Solamon", "70"},
	{" Wellington", "71"},
	{" Fiji", "72"},
	{" Nuku'alofa", "73"}
};

/*struct value_set system_time_tz_values[] =
		{
			  { " Eniwetok, Kwajalein","0"},
		      { " Midway Island, Samoa","1"},
	    	  { " Hawaii","2"},
		      { " Alaska","3"},
			  { " Pacific Time (US & Canada); Tijuana","4"},
			  { " Arizona","5"},
			  { " Mountain Time (US & Canada)","6"},
			  { " Central America","7"},
			  { " Central Time (US & Canada)","8"},
			  { " Mexico City","9"},
			  { " Saskatchewan","10"},
			  { " Bogota, Lima, Quito","11"},
			  { " Eastern Time (US & Canada)","12"},
			  { " Indiana (East)","13"},
			  { " Atlantic Time (Canada)","14"},
			  { " Caracas, La Paz","15"},
			  { " Santiago","16"},
			  { " Newfoundland","17"},
			  { " Brasilia","18"},
			  { " Buenos Aires, Georgetown","19"},
			  { " Greenland","20"},
			  { " Mid-Atlantic","21"},
			  { " Azores","22"},
			  { " Cape Verde Is.","23"},
	          { " Casablanca, Monrovia","24"},
              { " Greenwich Mean Time: Dublin, Edinburgh, Lisbon, London","25"},
		      { " Amsterdam, Berlin, Bern, Rome, Stockholm, Vienna","26"},
			  { " Belgrade, Bratislava, Budapest, Ljubljana, Prague","27"},
			  { " Brussels, Copenhagen, Madrid, Paris","28"},
			  { " Sarajevo, Sofija, Warsaw, Zagreb, Skopje, Vilnius","29"},
			  { " West Central Africa","30"},
			  { " Athens, Istanbul, Minsk","31"},
			  { " Bucharest","32"},
			  { " Cairo","33"},
			  { " Harare, Pretoria","34"},
			  { " Helsinki, Riga, Tallinn","35"},
			  { " Jerusalem","36"},
			  { " Baghdad","37"},
			  { " Kuwait, Riyadh","38"},
			  { " Moscow, St. Petersburg, Volgograd","39"},
			  { " Nairobi","40"},
			  { " Tehran","41"},
			  { " Abu Dhabi, Muscat","42"},
			  { " Baku, Tbilisi, Yerevan","43"},
			  { " Kabul","44"},
			  { " Ekaterinburg","45"},
			  { " Islamabad, Karachi, Tashkent","47"},
              { " Calcutta, Chennai, Mumbai, New Delhi","48"},
              { " Kathmandu","49"},
              { " Almaty, Novosibirsk","50"},
              { " Astana, Dhaka","51"},
              { " Sri, Jayawardenepura","52"},
              { " Rangoon","53"},
              { " Bangkok, Hanoi, Jakarta","54"},
              { " Krasnoyarsk","55"},
              { " Beijing, Chongqing, Hong Kong, Urumqi","56"},
              { " Irkutsk, Ulaan Bataar","57"},
              { " Kuala Lumpur, Singapore","57"},
              { " Perth","58"},
              { " Taipei","59"},
              { " Osaka, Sapporo, Toyko","60"},
              { " Seoul","61"},
              { " Yakutsk","62"},
              { " Adelaide","63"},
              { " Darwin","64"},
              { " Brisbane","65"},
              { " Canberra, Melbourne, Sydney","66"},
              { " Guam, Port Moresby","67"},	
			  { " Hobart","68"},
              { " Vladivostok","69"},
	          { " Magadan, Solamon, New Caledonia","70"},
		      { " Auckland, Wellington","71"},
		      { " Fiji, Kamchatka, Marshall Is.","72"},
			  { " Nuku'alofa","73"}
		};*/

struct value_set system_time_ntpclient_values[] = {
	{
	 "Enable",
	 "1"},
	{
	 "Disable",
	 "0"}
};

struct value_set system_time_ntpserver_values[] = {
	{
	 "time.windows.com",
	 "0"},
	{
	 "time.nist.gov",
	 "1"},
	{
	 "time-a.nist.gov",
	 "2"},
	{
	 "time-b.nist.gov",
	 "3"},
	{
	 "time-a.timefreq.bldrdoc.gov",
	 "4"},
	{
	 "time-b.timefreq.bldrdoc.gov",
	 "5"},
	{
	 "time-c.timefreq.bldrdoc.gov",
	 "6"},
	{
	 "time-nw.nist.gov",
	 "7"}
};

struct cmd_field system_time_config_cmd_fields[] = {
	{
	 .field_name = "tz",
	 .field_help = "This field represent the time zone",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "timezone",
	 .field_gui_name = "Time Zone",
	 .values = system_time_tz_values,
	 .tot_values = sizeof(system_time_tz_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "NTP_Client",
	 .field_help = "This field represent the status of sntp client",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "ntpclient",
	 .field_gui_name = "NTP Client",
	 .values = system_time_ntpclient_values,
	 .tot_values =
	 sizeof(system_time_ntpclient_values) / sizeof(struct value_set)
	 },
	{
	 "NTP_Server_List",
	 .field_help = "This field represent the SNTP Server",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "ntpserver",
	 .field_gui_name = "NTR Server",
	 .values = system_time_ntpserver_values,
	 .tot_values =
	 sizeof(system_time_ntpserver_values) / sizeof(struct value_set)
	 }
};

struct cmd_entry system_time_config_cmd = {
	.fields = system_time_config_cmd_fields,
	.tot_fields =
	    sizeof(system_time_config_cmd_fields) / sizeof(struct cmd_field),
	.help = "This command allows to configure system time",
	.post_url = "/goform/ifx_set_wizard_tz"
	    //system_time_config_custom_valid
	    //system_time_config_post_flag
};

struct menu_entry system_time_page_entries[] = {
	{
	 .entry_help = "This is system time show entry",
	 .cli_name = "Show",
	 .cli_url = "system_time.cli",
	 },
	{
	 .entry_help = "This is system time config entry",
	 .cli_name = "Config",
	 .cmd = &system_time_config_cmd}
};

struct menu_page system_time_page = {
	.entries = system_time_page_entries,
	.tot_entries =
	    sizeof(system_time_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is system time page",
	.cli_title = "Time",
	.gui_title = "System Time",
	.fpos = 1
};

struct value_set reset_factory_values[] = {
	{.display_value = "Yes",.submit_value = "1"},
	{.display_value = "No",.submit_value = "0"}
};

struct cmd_field restore_default_field[] = {
	{
	 .field_name = "factory",
	 .field_help =
	 "This field represent the factory settings for system reset",
	 .data_type = INT,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "factory",
	 .field_gui_name = "Factory Setting",
	 .values = reset_factory_values,
	 .tot_values = sizeof(reset_factory_values) / sizeof(struct value_set)
	 }
};

struct cmd_entry system_reset_cmd = {
	.help = "Reboots the device",
	.post_url = "/goform/ifx_set_system_reset"
	    //system_reset_custom_valid
	    //system_reset_post_flag
};

struct cmd_entry restore_default_cmd = {
	.fields = restore_default_field,
	.tot_fields = sizeof(restore_default_field) / sizeof(struct cmd_field),
	.help = "Reset the device to the default factory settings",
	.post_url = "/goform/ifx_set_system_reset"
	    //system_reset_custom_valid
	    //      .custom_processing_post=system_restore_post_flag
};

struct menu_entry system_reset_page_entries[] = {
	{
	 .entry_help = "This is system reset entry",
	 .cli_name = "Reboot",
	 .cmd = &system_reset_cmd},
	{
	 .entry_help = "This is restore to default entry",
	 .cli_name = "restoredefault",
	 .gui_name = "Restore Default Configuration",
	 .cmd = &restore_default_cmd}
};

struct menu_page system_reset_page = {
	.entries = system_reset_page_entries,
	.tot_entries =
	    sizeof(system_reset_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is system reset page",
	.cli_title = "Reset",
	.gui_title = "Reset"
};

struct cmd_field firmware_upgrade_cmd_fields[] = {
	{
	 .field_name = "webUpload",
	 .field_help =
	 "This field represent the file to which the firmware to be upgraded",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "upgradefile",
	 .field_gui_name = "Upgrade File"}
};

struct cmd_entry firmware_upgrade_cmd = {
	.fields = firmware_upgrade_cmd_fields,
	.tot_fields =
	    sizeof(firmware_upgrade_cmd_fields) / sizeof(struct cmd_field),
	.help = "this command upgrades current version of firmware",
	.post_url = "/goform/ifx_set_system_upgrade"
	    //firmware_upgrade_custom_valid
	    //firmware_upgrade_post_flag
};

struct menu_entry firmware_upgrade_page_entries[] = {
	{
	 .entry_help = "This is firmware show entry",
	 .cli_name = "Show",
	 .cli_url = "system_upgrade.cli",
	 },
	{
	 .entry_help = "This is firmware set entry",
	 .entry_help = "Config",
	 .cmd = &firmware_upgrade_cmd}
};

struct menu_page firmware_upgrade_page = {
	.entries = firmware_upgrade_page_entries,
	.tot_entries =
	    sizeof(firmware_upgrade_page_entries) / sizeof(struct menu_entry),
	.page_help = "the firmware upgrade page",
	.cli_title = "Firmware Upgrade",
	.gui_title = "Firmware Upgrade",
	.fpos = 1
};

struct cmd_field system_set_password_cmd_fields[] = {
	{
	 .field_name = "userOldPswd",
	 .field_help = "This field represent the current password",
	 .data_type = PASSWD,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "oldpass",
	 .field_gui_name = "Old Password"},
	{
	 .field_name = "userNewPswd",
	 .field_help = "This field represent the new password",
	 .data_type = PASSWD,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "newpass",
	 .field_gui_name = "New Password"},
	{
	 .field_name = "userConPswd",
	 .field_help = "This field represent the confirm password",
	 .data_type = PASSWD,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "confirmpass",
	 .field_gui_name = "COnfirm Password"},
};

struct cmd_entry system_set_password_cmd = {
	.fields = system_set_password_cmd_fields,
	.tot_fields =
	    sizeof(system_set_password_cmd_fields) / sizeof(struct cmd_field),
	.help = "This command allows you to set the password",
	.post_url = "/goform/ifx_set_user_password"
	    //system_set_password_custom_valid
	    //system_set_password_post_flag
};

struct menu_entry user_setting_page_entries[] = {
	{
	 .entry_help = "sets the password",
	 .cli_name = "Password",
	 .cmd = &system_set_password_cmd}
};

struct menu_page user_setting_page = {
	.entries = user_setting_page_entries,
	.tot_entries =
	    sizeof(user_setting_page_entries) / sizeof(struct menu_entry),
	.page_help = "This menu allows to configure user pages",
	.cli_title = "User Setting",
	.gui_title = "User Setting"
};

struct value_set log_clear_values[] = {
	{.display_value = "Clear",.submit_value = "Clear"},
	{.display_value = "Keep",.submit_value = "0"}
};

struct cmd_field log_clear_field[] = {
	{
	 .field_name = "securityclear",
	 .field_help = "This field repesent the status of clear",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "securityclear",
	 .field_gui_name = "Security Clear",
	 .values = log_clear_values,
	 .tot_values = sizeof(log_clear_values) / sizeof(struct value_set)
	 }
};

struct cmd_entry system_log_clear_cmd = {
	.fields = log_clear_field,
	.tot_fields = sizeof(log_clear_field) / sizeof(struct cmd_field),
	.help = "This command clears the System Log",
	.post_url = "/goform/ifx_set_system_log",
	//.custom_processing_post=system_log_clear_post_flag
};

struct value_set log_filter_values[] = {
	{.display_value = "SYSLOG_DISP_LEVEL_DEFAULT",.submit_value = "8"},
	{.display_value = "SYSLOG_DISP_LEVEL_EMERG",.submit_value = "0"},
	{.display_value = "SYSLOG_DISP_LEVEL_ALERT",.submit_value = "1"},
	{.display_value = "SYSLOG_DISP_LEVEL_CRIT",.submit_value = "2"},
	{.display_value = "SYSLOG_DISP_LEVEL_ERR",.submit_value = "3"},
	{.display_value = "SYSLOG_DISP_LEVEL_WARN",.submit_value = "4"},
	{.display_value = "SYSLOG_DISP_LEVEL_NOTICE",.submit_value = "5"},
	{.display_value = "SYSLOG_DISP_LEVEL_INFO",.submit_value = "6"},
	{.display_value = "SYSLOG_DISP_LEVEL_DEBUG",.submit_value = "7"}
};

struct cmd_field system_log_show_cmd_fields[] = {
	{
	 .field_name = "syslog_disp_level",
	 .field_help = "Filter level to show system log",
	 .data_type = INT,	/* TODO : can a static field be of int type ?? */
	 .field_type = STATIC,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "syslog_disp_level",
	 .field_gui_name = "View Filter Level",
	 .values = log_filter_values,
	 .tot_values = sizeof(log_filter_values) / sizeof(struct value_set)
	 }
};

struct cmd_entry system_log_show_cmd = {
	.fields = system_log_show_cmd_fields,
	.tot_fields =
	    sizeof(system_log_show_cmd_fields) / sizeof(struct cmd_field),
	.help = "This command will set the system log view filter level",
	.post_url = "/goform/ifx_set_system_log",
//                      .get_url="system_log_view.cli"
	.custom_processing_post = system_log_view_post_flag
};

struct menu_entry system_log_disp_entries[] = {
	{
	 .entry_help = "system log show entry",
	 .cli_name = "Show",
	 .cli_url = "system_log_view.cli"},
	{
	 .entry_help = "This is system log view filter set entry",
	 .cli_name = "Set",
	 .cmd = &system_log_show_cmd},
	{
	 .entry_help = "Clears the System Log",
	 .cli_name = "Clear",
	 .cmd = &system_log_clear_cmd}
};

struct menu_page system_log_disp_page = {
	.entries = system_log_disp_entries,
	.tot_entries =
	    sizeof(system_log_disp_entries) / sizeof(struct menu_entry),
	.page_help = "system log display page",
	.cli_title = "display",
	.gui_title = "Display"
};

struct value_set log_mode_values[] = {
	{.display_value = "SYSLOG_LOCAL",.submit_value = "0"},
	{.display_value = "SYSLOG_REMOTE",.submit_value = "1"},
	{.display_value = "SYSLOG_BOTH_LOCAL_REMOTE",.submit_value = "2"}
};

struct cmd_field system_log_set_cmd_fields[] = {
	{
	 .field_name = "log_mode",
	 .field_help = "Logging mode",
	 .data_type = STR,	/* TODO : can a static field be of int type ?? */
	 .field_type = STATIC,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "log_mode",
	 .field_gui_name = "log_mode",
	 .values = log_mode_values,
	 .tot_values = sizeof(log_mode_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "rlog_ip",
	 .field_help = "IP Address of host where messages should be logged",
	 .data_type = IPADDR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "rlog_ip",
	 .field_gui_name = "rlog_ip"},
	{
	 .field_name = "rlog_port",
	 .field_help = "Port number on remote host",
	 .data_type = INT,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "rlog_port",	/* does not seem to accept spaces !! */
	 .field_gui_name = "rlog_port"},
	{
	 .field_name = "syslog_conf_level",
	 .field_help = "Filter level to show system log",
	 .data_type = STR,	/* TODO : can a static field be of int type ?? */
	 .field_type = STATIC,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "syslog_conf_level",
	 .field_gui_name = "syslog_conf_level",
	 .values = log_filter_values,
	 .tot_values = sizeof(log_filter_values) / sizeof(struct value_set)
	 }
};

struct cmd_entry system_log_set_cmd = {
	.fields = system_log_set_cmd_fields,
	.tot_fields =
	    sizeof(system_log_set_cmd_fields) / sizeof(struct cmd_field),
	.help =
	    "This command configured the way messages should be logged, locally, remotely or both",
	.post_url = "/goform/ifx_set_system_log",
	.get_url = "system_log.cli",
	.custom_validation = system_log_custom_valid,
	.custom_processing_post = system_log_set_post_flag
};

struct menu_entry system_log_set_entries[] = {
	{
	 .entry_help = "system log set entry",
	 .cli_name = "Show",
	 .cli_url = "system_log.cli"},
	{
	 .entry_help = "This is system logging options set entry",
	 .cli_name = "Set",
	 .cmd = &system_log_set_cmd},
};

struct menu_page system_log_set_page = {
	.entries = system_log_set_entries,
	.tot_entries =
	    sizeof(system_log_set_entries) / sizeof(struct menu_entry),
	.page_help = "system log set page",
	.cli_title = "set",
	.gui_title = "Set"
};

struct menu_entry system_log_entries[] = {
	{
	 .next_page = &system_log_disp_page,
	 .entry_help = "system log display entry",
	 .cli_name = "display",
	 .gui_name = "Display",
	 .gui_url = "system_log_view.asp"},
	{
	 .next_page = &system_log_set_page,
	 .entry_help = "system log set entry",
	 .cli_name = "set",
	 .gui_name = "Set",
	 .gui_url = "system_log.asp"},
};

struct menu_page system_log_page = {
	.entries = system_log_entries,
	.tot_entries = sizeof(system_log_entries) / sizeof(struct menu_entry),
	.page_help = "This is System Log Page",
	.cli_title = "System Log",
	.gui_title = "System Log"
};

struct cmd_field host_name_config_cmd_fields[] = {
	{
	 .field_name = "HostName",
	 .field_help = "The Host Name",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "hostname",
	 .field_gui_name = "Host Name"},
	{
	 .field_name = "DomainName",
	 .field_help = "The Domain Name",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "domain",
	 .field_gui_name = "Domain name"}
};

struct cmd_field admin_setting_chpass_cmd_fields[] = {
	{
	 .field_name = "userOldPswd",
	 .field_help = "The Old password",
	 .data_type = PASSWD,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "oldpass",
	 .field_gui_name = "Old Password"},
	{
	 .field_name = "userNewPswd",
	 .field_help = "The New password",
	 .data_type = PASSWD,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "newpass",
	 .field_gui_name = "New Password"},
	{
	 .field_name = "userConPswd",
	 .field_help = "The Confirm New password",
	 .data_type = PASSWD,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "conpass",
	 .field_gui_name = "Confirm Password"}
};

struct cmd_entry host_name_config_cmd = {
	.fields = host_name_config_cmd_fields,
	.tot_fields =
	    sizeof(host_name_config_cmd_fields) / sizeof(struct cmd_field),
	.help =
	    "This command allows to edit Host Name and Domain Name Configuration",
	.post_url = "/goform/ifx_set_wizard_host",
	//host_name_config_custom_valid
	//host_name_config_post_flag
	.get_url = "system_hostname.cli"
};

struct cmd_entry admin_setting_chpass_cmd = {
	.fields = admin_setting_chpass_cmd_fields,
	.tot_fields =
	    sizeof(admin_setting_chpass_cmd_fields) / sizeof(struct cmd_field),
	.help = "This command changes the system password\n",
	.post_url = "/goform/ifx_set_system_password"
	    //admin_setting_chpass_custom_valid
	    //admin_setting_chpass_post_flag
};

struct menu_entry host_name_config_entries[] = {
	{
	 .entry_help = "Displays current hostname configuration",
	 .cli_name = "Show",
	 .cli_url = "system_hostname.cli",
	 },
	{
	 .entry_help = "Configure current hostname and domainname",
	 .cli_name = "Set",
	 .cmd = &host_name_config_cmd}
};

struct menu_entry admin_setting_entries[] = {
	{
	 .entry_help = "Change system password",
	 .cli_name = "Password",
	 .cmd = &admin_setting_chpass_cmd}
};

struct menu_page host_name_config_page = {
	.entries = host_name_config_entries,
	.tot_entries =
	    sizeof(host_name_config_entries) / sizeof(struct menu_entry),
	.page_help = "The host name config page",
	.cli_title = "Host Name Config Page",
	.gui_title = "Host Name Config Page"
};

struct menu_page admin_setting_page = {
	.entries = admin_setting_entries,
	.tot_entries =
	    sizeof(admin_setting_entries) / sizeof(struct menu_entry),
	.page_help = "The Administrator Setting page",
	.cli_title = "Administrator Setting Page",
	.gui_title = "Administrator Setting Page"
};

struct menu_entry system_page_entries[] = {
	{
	 .next_page = &host_name_config_page,
	 .entry_help = "Configure and show  Host Name",
	 .cli_name = "hostname",
	 .gui_name = "Host Name",
	 .gui_url = "system_hostname.asp"},
	{
	 .next_page = &admin_setting_page,
	 .entry_help = "The Administrative Setting",
	 .cli_name = "admin",
	 .gui_name = "Administrator",
	 .gui_url = "system_password.htm"},
#if 0
	{
	 .next_page = &user_setting_page,
	 .entry_help = "The User Settings",
	 .cli_name = "user",
	 .gui_name = "User",
	 .gui_url = "user_password.asp"},
#endif				// 0
	{
	 .next_page = &system_log_page,
	 .entry_help = "The System Log",
	 .cli_name = "log",
	 .gui_name = "System Log",
	 .gui_url = "system_log.asp"},
#ifndef CONFIG_FEATURE_SEMINDIA
#if 0
	{
	 .next_page = &firmware_upgrade_page,
	 .entry_help = "The firmware upgrade",
	 .cli_name = "upgrade",
	 .gui_name = "Firmware Upgrade",
	 .gui_url = "system_upgrade.asp"},
#endif
#endif				//CONFIG_FEATURE_SEMINDIA
	{
	 .next_page = &system_reset_page,
	 .entry_help = "The system reset",
	 .cli_name = "reset",
	 .gui_name = "Reset",
	 .gui_url = "system_reset.asp"},
#if 0
	{
	 .next_page = &system_time_page,
	 .entry_help = "The system time",
	 .cli_name = "time",
	 .gui_name = "Time",
	 .gui_url = "system_time.asp"}
#endif
};

struct menu_page system_page = {
	.entries = system_page_entries,
	.tot_entries = sizeof(system_page_entries) / sizeof(struct menu_entry),
	.page_help = "The system page",
	.cli_title = "System Page",
	.gui_title = "System Page",
	.fpos = 1
};
