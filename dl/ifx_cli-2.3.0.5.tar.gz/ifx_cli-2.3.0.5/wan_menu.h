
#include "adsl_menu_func.h"
#include "wan_menu_func.h"

struct value_set bridge_stp_values[] = {
	{.display_value = "disable",.submit_value = "0"},
	{.display_value = "enable",.submit_value = "1"}
};

struct value_set vlan_tag_values[] = {
	{.display_value = "disable",.submit_value = "0"},
	{.display_value = "enable",.submit_value = "1"}
};

struct value_set oamconfig_loopback_values[] = {
	{.display_value = "disable",.submit_value = "0"},
	{.display_value = "enable",.submit_value = "1"}
};

struct value_set oamconfig_ccheck_values[] = {
	{.display_value = "disable",.submit_value = "0"},
	{.display_value = "enable",.submit_value = "1"}
};

struct value_set oamconfig_direction_values[] = {
	{.display_value = "Sink",.submit_value = "1"},
	{.display_value = "Source",.submit_value = "2"},
	{.display_value = "Both",.submit_value = "3"}
};

struct value_set adsl_oamconfig_values[] = {
	{.display_value = "Enable",.submit_value = "1"},
	{.display_value = "Disable",.submit_value = "0"}
};

struct cmd_field adsl_oamenable_cmd_field[] = {
	{
	 .field_name = "OAM_ENABLE",
	 .field_help = "This field represent the status of oam",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "Status",
	 .field_gui_name = "Status",
	 .values = adsl_oamconfig_values,
	 .tot_values = sizeof(adsl_oamconfig_values) / sizeof(struct value_set)
	 }
};

struct cmd_field adsl_oam_f5_cmd_field[] = {
	{
	 .field_name = "OAM_F5_VPIVCI_CHANNEL",
	 .field_help = "represent the vpi/vci pair",
	 .data_type = STR,.field_type = DYNAMIC,.mandatory = IFX_TRUE,
	 .field_display_name = "vpivci",
	 .field_gui_name = "VPI/VCI",
	 .get_vset = get_vpivci_fvset,
	 .fprocessing_post = f5_cmd_vpivci_fprocessing},
	{
	 .field_name = "OAM_F5_LOOPBACK",
	 .field_help = "This field represent the f5 loopback",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "Loopback",
	 .field_gui_name = "Loopback",
	 .values = oamconfig_loopback_values,
	 .tot_values =
	 sizeof(oamconfig_loopback_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "OAM_F5_TIME_TMP",
	 .field_help = "This field represent f5 transmit time",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "Time",
	 .field_gui_name = "Time",
	 },
	{
	 .field_name = "OAM_F5_CCheck",
	 .field_help = "This field represent the f5 continuity check",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "cc",
	 .field_gui_name = "Continuity Check",
	 .values = oamconfig_ccheck_values,
	 .tot_values =
	 sizeof(oamconfig_ccheck_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "OAM_F5_CC_OPT",
	 .field_help = "This field represent the direction",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "dir",
	 .field_gui_name = "Direction",
	 .values = oamconfig_direction_values,
	 .tot_values =
	 sizeof(oamconfig_direction_values) / sizeof(struct value_set)
	 }
};

struct cmd_field adsl_oam_test_cmd_field[] = {
	{
	 .field_name = "testVPIVCI",
	 .field_help = "represents the vpivci pair to be tested",
	 .data_type = STR,.field_type = USR_DEF,.mandatory = 1,
	 .field_display_name = "VPI/VCI",
	 .field_gui_name = "VPI/VCI",
	 },
	{
	 .field_name = "testOwner",
	 .data_type = STR,.field_type = HIDDEN,.mandatory = IFX_FALSE,
	 .cur_value = "CLI"}
	/*
	   {
	   .field_name="OAM_F5_VPIVCI_CHANNEL",
	   .field_help="represent the vpi/vci pair",
	   .data_type=STR,.field_type=DYNAMIC,.mandatory=IFX_TRUE,
	   .field_display_name="OAM_F5_VPIVCI_CHANNEL",
	   .field_gui_name="VPI/VCI",
	   .get_vset=get_vpivci_fvset,
	   .fprocessing_post=f5_cmd_vpivci_fprocessing
	   },
	   {
	   .field_name="OAM_F5_LOOPBACK",
	   .field_help="This field represent the f5 loopback",
	   .data_type=STR ,.field_type=STATIC, .mandatory=IFX_FALSE,
	   .field_display_name="OAM_F5_LOOPBACK",
	   .field_gui_name="Loopback",
	   .values=oamconfig_loopback_values,
	   .tot_values=sizeof(oamconfig_loopback_values)/sizeof(struct value_set)
	   },
	   {
	   .field_name="OAM_F5_TIME",
	   .field_help="This field represent f5 transmit time",
	   .data_type=INT ,.field_type=USR_DEF, .mandatory=IFX_FALSE,
	   .field_display_name="OAM_F5_TIME",
	   .field_gui_name="Time",
	   },
	   {
	   .field_name="OAM_F5_TX_CELLS",
	   .field_help="This field represent f5 tx cells",
	   .data_type=INT ,.field_type=USR_DEF, .mandatory=IFX_FALSE,
	   .field_display_name="OAM_F5_TIME",
	   .field_gui_name="Time",
	   }
	 */
	/*
	   {
	   .field_name="OAM_F5_CCheck",
	   .field_help="This field represent the f5 continuity check",
	   .data_type=STR ,.field_type=STATIC ,.mandatory=IFX_FALSE,
	   .field_display_name="cc",
	   .field_gui_name="OAM_F5_CCheck",
	   .values=oamconfig_ccheck_values,
	   .tot_values=sizeof(oamconfig_ccheck_values)/sizeof(struct value_set)
	   },
	   {
	   .field_name="OAM_F5_CC_OPT",
	   .field_help="This field represent the direction",
	   .data_type=STR ,.field_type=STATIC ,.mandatory=IFX_FALSE,
	   .field_display_name="OAM_F5_CC_OPT",
	   .field_gui_name="Direction",
	   .values=oamconfig_direction_values,
	   .tot_values=sizeof(oamconfig_direction_values)/sizeof(struct value_set)
	   }
	 */
};

struct cmd_entry adsl_oam_test_cmd = {
	.fields = adsl_oam_test_cmd_field,
	.tot_fields =
	    sizeof(adsl_oam_test_cmd_field) / sizeof(struct cmd_field),
	.help = "tests an vpi vci pair",
	.post_url = "/goform/ifx_set_adsl_oamconfig",
	.custom_processing_post = validate_test_oam
};

struct cmd_entry adsl_oam_f5_cmd = {
	.fields = adsl_oam_f5_cmd_field,
	.tot_fields = sizeof(adsl_oam_f5_cmd_field) / sizeof(struct cmd_field),
	.help = "This command configures adsl oam settings",
	.post_url = "/goform/ifx_set_adsl_oamconfig",
	/*adsl_oamconfig_custom_valid */
	//.custom_validation=validate_oam_vcc,
	.custom_processing_post = adsl_oam_post_flag
};

struct cmd_entry adsl_oamenable_cmd = {
	.fields = adsl_oamenable_cmd_field,
	.tot_fields =
	    sizeof(adsl_oamenable_cmd_field) / sizeof(struct cmd_field),
	.help = "This command enables or disables adsl oam settings",
	.post_url = "/goform/ifx_set_adsl_oamconfig",
	/*adsl_oamconfig_custom_valid */
	.custom_processing_post = adsl_oam_post_flag
};

struct menu_entry adsl_oamconfig_entries[] = {
	{
	 .entry_help = "This is adsl oamconfig show entry",
	 .cli_name = "Show",.cli_url = "adsl_oamconfig.cli",
	 },
	/* {
	   .entry_help="Enable or Disable OAM functionality",
	   .cli_name="Set" ,.cmd=&adsl_oamenable_cmd
	   },
	   {
	   .entry_help="This is adsl oamconfig config entry",
	   .cli_name="F5" ,.cmd=&adsl_oam_f5_cmd
	   },
	 */
	{
	 .entry_help = "This is adsl oamconfig f5 ping test entry",
	 .cli_name = "Test",.cmd = &adsl_oam_test_cmd}
};

struct menu_page adsl_oamconfig_page = {
	.entries = adsl_oamconfig_entries,
	.tot_entries =
	    sizeof(adsl_oamconfig_entries) / sizeof(struct menu_entry),
	.page_help = "This is adsl oamconfig entry",
	.cli_title = "Oam",.gui_title = "OAM Configuration"
};

struct value_set adsl_vcconfig_add_qos_values[] = {
	{.display_value = "UBR",.submit_value = "0"},
	{.display_value = "CBR",.submit_value = "1"},
	{.display_value = "NRT-VBR",.submit_value = "2"},
	{.display_value = "RT-VBR",.submit_value = "3"}
};

struct value_set adsl_vcconfig_add_encapmode_values[] = {
	{.display_value = "LLC/SNAP",.submit_value = "0"},
	{.display_value = "VCMux",.submit_value = "1"}
};

struct cmd_field adsl_vcconfig_add_cmd_fields[] = {
	{
	 .field_name = "CapMode",
	 .field_help = "This field represent the encapsulation mode",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "encap",
	 .field_gui_name = "Encapsulation",
	 .values = adsl_vcconfig_add_encapmode_values,
	 .tot_values =
	 sizeof(adsl_vcconfig_add_encapmode_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "vcSetting",
	 .field_help = "This field represent the vpi/vci setting",
	 .data_type = STR,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "vpivci",
	 .field_gui_name = "VPI/VCI"},
	{
	 .field_name = "QoSMode",
	 .field_help = "This field represent the service mode",
	 .data_type = INT,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "qosclass",
	 .field_gui_name = "ATM QoS Class",
	 .values = adsl_vcconfig_add_qos_values,
	 .tot_values =
	 sizeof(adsl_vcconfig_add_qos_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "peakCell",
	 .field_help = "This field represent the peak cell rate",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "peakcell",
	 .field_gui_name = "Peak Cell Rate (PCR)"},
	{
	 .field_name = "cellDelayVarition",
	 .field_help = "This field represent the variation in cell delay",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "cdv",
	 .field_gui_name = "Cell Delay Variation (CDV)"},
	{
	 .field_name = "sustainableCell",
	 .field_help = "This field represent the sustainable cell rate",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "scr",
	 .field_gui_name = "Sustainable Cell Rate (SCR)"},
	{
	 .field_name = "maximumBurst",
	 .field_help = "This field represent the maximum cell burst rate",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "mbr",
	 .field_gui_name = "Max Burst Rate"}
};

struct cmd_entry adsl_vcconfig_add_cmd = {
	.fields = adsl_vcconfig_add_cmd_fields,
	.tot_fields =
	    sizeof(adsl_vcconfig_add_cmd_fields) / sizeof(struct cmd_field),
	.help = "This command adds a vpi vci pair",
	.post_url = "/goform/ifx_set_adsl_vcconfig",
	.custom_validation = adsl_vcconfig_add_custom_valid,
	.custom_processing_post = adsl_vcconfig_add_post_flag
};

struct cmd_field adsl_vcconfig_del_cmd_field[] = {
	{
	 .field_name = "vpivci_value",
	 .field_help = "This field represent the vpi/vci setting",
	 .data_type = STR,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "vpivci",
	 .field_gui_name = "VPI/VCI"}
};

struct cmd_entry adsl_vcconfig_del_cmd = {
	.fields = adsl_vcconfig_del_cmd_field,
	.tot_fields =
	    sizeof(adsl_vcconfig_del_cmd_field) / sizeof(struct cmd_field),
	.help = "Deletes a vpi vci setting",
	.post_url = "/goform/ifx_set_adsl_vcconfig",
	.custom_processing_post = adsl_vcconfig_del_post_flag
};

struct menu_entry adsl_vcconfig_entries[] = {
	{
	 .entry_help = "This is adsl_vcconfig_show entry",
	 .cli_name = "Show",.cli_url = "adsl_vcconfig.cli"},
	{
	 .entry_help = "This is adsl_vcconfig_add entry",
	 .cli_name = "Add",.cmd = &adsl_vcconfig_add_cmd,
	 .gui_name = "Add VC"},
	{
	 .entry_help = "This is adsl_vcconfig_del entry",
	 .cli_name = "Delete",.cmd = &adsl_vcconfig_del_cmd,
	 .gui_name = "Delete VC"}
};

struct menu_page adsl_vcconfig_page = {
	.entries = adsl_vcconfig_entries,
	.tot_entries =
	    sizeof(adsl_vcconfig_entries) / sizeof(struct menu_entry),
	.page_help = "This is adsl_vcconfig page",
	.cli_title = "ADSL VC Config",
	.gui_title = "ADSL VC Config",
	.fpos = 0
};

struct value_set wan_interface_values[] = {
	{.display_value = "wan1",.submit_value = "1"},
	{.display_value = "wan2",.submit_value = "2"},
	{.display_value = "wan3",.submit_value = "3"},
	{.display_value = "wan4",.submit_value = "4"},
	{.display_value = "wan5",.submit_value = "5"},
	{.display_value = "wan6",.submit_value = "6"},
	{.display_value = "wan7",.submit_value = "7"},
	{.display_value = "wan8",.submit_value = "8"},
	{.display_value = "wan9",.submit_value = "9"},
	{.display_value = "wan10",.submit_value = "10"},
	{.display_value = "wan11",.submit_value = "11"},
	{.display_value = "wan12",.submit_value = "12"},
	{.display_value = "wan13",.submit_value = "13"},
	{.display_value = "wan14",.submit_value = "14"}
};

struct value_set dhcp_atmp_values[] = {
#ifdef CONFIG_FEATURE_CLIP
	{.display_value = "classic_ip",.submit_value = "clip"},
#endif
	{.display_value = "eth_over_atm",.submit_value = "rfc2684_eoa"},
	{.display_value = "ip_over_atm",.submit_value = "rfc2684_ipoa"}
};

struct value_set static_atmp_values[] = {
#ifdef CONFIG_FEATURE_CLIP
	{.display_value = "classic_ip",.submit_value = "clip"},
#endif
	{.display_value = "eth_over_atm",.submit_value = "rfc2684_eoa"},
	{.display_value = "ip_over_atm",.submit_value = "rfc2684_ipoa"}
};

struct cmd_field dhcp_config_cmd_field[] = {
	{
	 .field_name = "WAN",
	 .field_help = "The WAN interface to be configured",
	 .data_type = INT,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "wanif",
	 .field_gui_name = "WAN Interface",
	 .values = wan_interface_values,
	 .tot_values = sizeof(wan_interface_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "vcChannel",
	 .field_help = "represent the vpi/vci pair",
	 .data_type = STR,.field_type = DYNAMIC,.mandatory = IFX_TRUE,
	 .field_display_name = "vpivci",
	 .field_gui_name = "VPI/VCI",
	 .get_vset = get_vpivci_fvset},
	{
	 .field_name = "ATM_PROTOCOL",
	 .field_help = "This field represent the atm protocol type",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "atmp",
	 .field_gui_name = "ATM Protocol",
	 .values = dhcp_atmp_values,
	 .tot_values = sizeof(dhcp_atmp_values) / sizeof(struct value_set)
	 },
	/* vlan related [ */
	{
	 .field_name = "VID",
	 .field_help = "This field represent the vlan id",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "VID",
	 .field_gui_name = "VLAN ID"},
	{
	 .field_name = "VPRIO",
	 .field_help = "This field represent the vlan priority",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "VPRIO",
	 .field_gui_name = "VLAN Priority"},
	{
	 .field_name = "VTAG",
	 .field_help = "This field represent the vlan tag",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "VTAG",
	 .field_gui_name = "TAG",
	 .values = vlan_tag_values,
	 .tot_values = sizeof(vlan_tag_values) / sizeof(struct value_set)
	 },
#if 0
	{
	 .field_name = "VUNTAG",
	 .field_help = "This field represent the vlan un-tag",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "VUNTAG",
	 .field_gui_name = "UN-TAG",
	 .values = vlan_tag_values,
	 .tot_values = sizeof(vlan_tag_values) / sizeof(struct value_set)
	 },
#else
	{
	 .field_name = "VUNTAG",
	 .data_type = STR,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .cur_value = "0"},
#endif				// 0
	/* ] */
	{
	 .field_name = "WT",
	 .data_type = INT,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .cur_value = "1"}
};

struct cmd_entry dhcp_config_cmd = {
	.fields = dhcp_config_cmd_field,
	.tot_fields = sizeof(dhcp_config_cmd_field) / sizeof(struct cmd_field),
	.help = "This command configures dhcp",
	.post_url = "/goform/ifx_set_wan_dhcp",
	.custom_validation = validate_vlan,
	.custom_processing_post = wan_config_cmd_post_flag
};

struct cmd_field defgw_cmd_field[] = {
	{
	 .field_name = "def_gw",
	 .field_help = "The WAN interface to be configured",
	 .data_type = INT,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "wanif",
	 .field_gui_name = "WAN Interface",
	 .values = wan_interface_values,
	 .tot_values = sizeof(wan_interface_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "operation",
	 .data_type = STR,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .cur_value = "def_gw"},
	{
	 .field_name = "WAN",
	 .data_type = STR,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .cur_value = "1"}
};

struct cmd_entry defgw_cmd = {
	.fields = defgw_cmd_field,
	.tot_fields = sizeof(defgw_cmd_field) / sizeof(struct cmd_field),
	.help = "This command allows to edit Default GW Configuration",
	.post_url = "/goform/ifx_set_wan_vcc_settings"
	    //.custom_processing_post=wan_config_cmd_post_flag 
	    //host_name_config_custom_valid
	    //host_name_config_post_flag
	    //.get_url="system_hostname.cli"
};

struct menu_entry wan_dhcp_page_entries[] = {
#if 0
	{
	 .entry_help = "This is dhcp show entry",
	 .cli_name = "Show",.cli_url = "wan_dhcp.cli",
	 },
#endif
	{
	 .entry_help = "This is dhcp config entry",
	 .cli_name = "Config",.cmd = &dhcp_config_cmd}
};

struct menu_entry wan_defgw_page_entries[] = {
#if 1
	{
	 .entry_help = "This is defgw show entry",
	 .cli_name = "Show",.cli_url = "wan_def_gw.cli",
	 },
#endif
	{
	 .entry_help = "This is defgw config entry",
	 .cli_name = "Config",.cmd = &defgw_cmd}
};

struct menu_page wan_dhcp_page = {
	.entries = wan_dhcp_page_entries,
	.tot_entries =
	    sizeof(wan_dhcp_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is wan dhcp page",
	.cli_title = "dhcp",.gui_title = "DHCP"
};

struct menu_page wan_defgw_page = {
	.entries = wan_defgw_page_entries,
	.tot_entries =
	    sizeof(wan_defgw_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is wan defgw page",
	.cli_title = "defgw",.gui_title = "DEFGW"
};

struct cmd_field static_config_cmd_field[] = {
	{
	 .field_name = "WAN",
	 .field_help = "The WAN interface to be configured",
	 .data_type = INT,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "wanif",
	 .field_gui_name = "WAN Interface",
	 .values = wan_interface_values,
	 .tot_values = sizeof(wan_interface_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "vcChannel",
	 .field_help = "represent the vpi/vci pair",
	 .data_type = STR,.field_type = DYNAMIC,.mandatory = IFX_TRUE,
	 .field_display_name = "vpivci",
	 .field_gui_name = "VPI/VCI",
	 .get_vset = get_vpivci_fvset},
	{
	 .field_name = "IP",
	 .field_help = "This field represent the static ip address",
	 .data_type = IPADDR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "ipaddr",
	 .field_gui_name = "IP Address",
	 .fprocessing_post = ip_nm_gw_processing},
	{
	 .field_name = "NM",
	 .field_help = "This field represent the static netmask ip address",
	 .data_type = IPADDR,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "netmask",
	 .field_gui_name = "Netmask",
	 .fprocessing_post = ip_nm_gw_processing},
	{
	 .field_name = "GIP",
	 .field_help = "This field represent the static gateway ip address",
	 .data_type = IPADDR,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "gipaddr",
	 .field_gui_name = "Gateway IP Address",
	 .fprocessing_post = ip_nm_gw_processing},
	{
	 .field_name = "ATM_PROTOCOL",
	 .field_help = "This field represent the atm protocol used",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "atmp",
	 .field_gui_name = "ATM Protocol",
	 .values = static_atmp_values,
	 .tot_values = sizeof(static_atmp_values) / sizeof(struct value_set)
	 },
	/* vlan related [ */
	{
	 .field_name = "VID",
	 .field_help = "This field represent the vlan id",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "VID",
	 .field_gui_name = "VLAN ID"},
	{
	 .field_name = "VPRIO",
	 .field_help = "This field represent the vlan priority",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "VPRIO",
	 .field_gui_name = "VLAN Priority"},
	{
	 .field_name = "VTAG",
	 .field_help = "This field represent the vlan tag",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "VTAG",
	 .field_gui_name = "TAG",
	 .values = vlan_tag_values,
	 .tot_values = sizeof(vlan_tag_values) / sizeof(struct value_set)
	 },
#if 0
	{
	 .field_name = "VUNTAG",
	 .field_help = "This field represent the vlan un-tag",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "VUNTAG",
	 .field_gui_name = "UN-TAG",
	 .values = vlan_tag_values,
	 .tot_values = sizeof(vlan_tag_values) / sizeof(struct value_set)
	 },
#else
	{
	 .field_name = "VUNTAG",
	 .data_type = STR,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .cur_value = "0"},
#endif				// 0
	/* ] */
	{
	 .field_name = "WT",
	 .data_type = INT,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .cur_value = "2"}
};

struct cmd_entry static_config_cmd = {
	.fields = static_config_cmd_field,
	.tot_fields =
	    sizeof(static_config_cmd_field) / sizeof(struct cmd_field),
	.help =
	    "This command is used for static,netmask ip address configuration",
	.post_url = "/goform/ifx_set_wan_static",
	.custom_validation = validate_vlan,
	.custom_processing_post = wan_config_cmd_post_flag,
};

struct menu_entry wan_static_page_entries[] = {
#if 0
	{
	 .entry_help = "This is static show entry",
	 .cli_name = "Show",.cli_url = "wan_static.cli"},
#endif
	{
	 .entry_help = "This is static config entry",
	 .cli_name = "Config",.cmd = &static_config_cmd}
};

struct menu_page wan_static_page = {
	.entries = wan_static_page_entries,
	.tot_entries =
	    sizeof(wan_static_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is static page",.cli_title = "static",
	.gui_title = "Static"
};

struct value_set pppoe_config_relay_values[] = {
	{.display_value = "disable",.submit_value = "0"},
	{.display_value = "enable",.submit_value = "1"}
};

struct value_set pppoea_config_reconnect_values[] = {
	{.display_value = "off",.submit_value = "0"},
	{.display_value = "on",.submit_value = "1"}
};

struct cmd_field pppoe_config_cmd_field[] = {
	{
	 .field_name = "WAN",
	 .field_help = "The WAN interface to be configured",
	 .data_type = INT,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "wanif",
	 .field_gui_name = "WAN Interface",
	 .values = wan_interface_values,
	 .tot_values = sizeof(wan_interface_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "vcChannel",
	 .field_help = "represent the vpi/vci pair",
	 .data_type = STR,.field_type = DYNAMIC,.mandatory = IFX_TRUE,
	 .field_display_name = "vpivci",
	 .field_gui_name = "VPI/VCI",
	 .get_vset = get_vpivci_fvset},
	{
	 .field_name = "UN",
	 .field_help = "This field represent the username",
	 .data_type = STR,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "un",
	 .field_gui_name = "User Name"},
	{
	 .field_name = "PW",
	 .field_help = "This field represent the new password",
	 .data_type = PASSWD,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "pw",
	 .field_gui_name = "Password"},
	{
	 .field_name = "PWV",
	 .field_help = "This field represent the retyped new password",
	 .data_type = PASSWD,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "pwv",
	 .field_gui_name = "Re-Type Password"},
	{
	 .field_name = "MTU",
	 .field_help = "This field represent the max transfer unit",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "mtu",
	 .field_gui_name = "MTU"},
	{
	 .field_name = "reconnect",
	 .field_help = "This field represent the status of dial on demand",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "reconnect",
	 .field_gui_name = "Reconnect",
	 .values = pppoea_config_reconnect_values,
	 .tot_values =
	 sizeof(pppoea_config_reconnect_values) / sizeof(struct value_set),
	 .fprocessing_post = pppoea_config_reconnect_post},
	{
	 .field_name = "IDLE",
	 .field_help =
	 "This field represent the maximum idle time (in miutes) for dial on demand",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "IDLE",
	 .field_gui_name = "Maximum Idle Time"},
#if 1
	{
	 .field_name = "relay",
	 .field_help = "This field represent relay of lan side pppoe session",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "relay",
	 .field_gui_name = "Relay lan side pppoe",
	 .values = pppoe_config_relay_values,
	 .tot_values =
	 sizeof(pppoe_config_relay_values) / sizeof(struct value_set)
//                              .fprocessing_post=pppoe_config_relay_post
	 },
#endif
	/* vlan related [ */
	{
	 .field_name = "VID",
	 .field_help = "This field represent the vlan id",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "VID",
	 .field_gui_name = "VLAN ID"},
	{
	 .field_name = "VPRIO",
	 .field_help = "This field represent the vlan priority",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "VPRIO",
	 .field_gui_name = "VLAN Priority"},
	{
	 .field_name = "VTAG",
	 .field_help = "This field represent the vlan tag",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "VTAG",
	 .field_gui_name = "TAG",
	 .values = vlan_tag_values,
	 .tot_values = sizeof(vlan_tag_values) / sizeof(struct value_set)
	 },
#if 0
	{
	 .field_name = "VUNTAG",
	 .field_help = "This field represent the vlan un-tag",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "VUNTAG",
	 .field_gui_name = "UN-TAG",
	 .values = vlan_tag_values,
	 .tot_values = sizeof(vlan_tag_values) / sizeof(struct value_set)
	 },
#else
	{
	 .field_name = "VUNTAG",
	 .data_type = STR,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .cur_value = "0"},
#endif				// 0
	/* ] */
	{
	 .field_name = "WT",
	 .data_type = INT,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .cur_value = "3"}
};

struct cmd_entry pppoe_config_cmd = {
	.fields = pppoe_config_cmd_field,
	.tot_fields = sizeof(pppoe_config_cmd_field) / sizeof(struct cmd_field),
	.help = "This command configures pppoe settings",
	.post_url = "/goform/ifx_set_wan_pppoe",
	.custom_processing_post = wan_config_cmd_post_flag,
	.custom_validation = validate_vlan_and_password	/* this will validate the password as well as the vlan fields */
};

struct menu_entry wan_pppoe_page_entries[] = {
#if 0
	{
	 .entry_help = "This is pppoe show entry",
	 .cli_name = "Show",.cli_url = "wan_pppoe.cli"},
#endif
	{
	 .entry_help = "This is pppoe config entry",
	 .cli_name = "Config",.cmd = &pppoe_config_cmd}
};

struct menu_page wan_pppoe_page = {
	.entries = wan_pppoe_page_entries,
	.tot_entries =
	    sizeof(wan_pppoe_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is wan pppoe page",
	.cli_title = "pppoe",.gui_title = "PPPoE"
};

struct cmd_field pppoa_config_cmd_field[] = {
	{
	 .field_name = "WAN",
	 .field_help = "The WAN interface to be configured",
	 .data_type = INT,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "wanif",
	 .field_gui_name = "WAN Interface",
	 .values = wan_interface_values,
	 .tot_values = sizeof(wan_interface_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "vcChannel",
	 .field_help = "represent the vpi/vci pair",
	 .data_type = STR,.field_type = DYNAMIC,.mandatory = IFX_TRUE,
	 .field_display_name = "vpivci",
	 .field_gui_name = "VPI/VCI",
	 .get_vset = get_vpivci_fvset},
	{
	 .field_name = "UN",
	 .field_help = "This field represent the username",
	 .data_type = STR,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "un",
	 .field_gui_name = "User Name"},
	{
	 .field_name = "PW",
	 .field_help = "This field represent the new password",
	 .data_type = PASSWD,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "pw",
	 .field_gui_name = "Password"},
	{
	 .field_name = "PWV",
	 .field_help = "This field represent the retyped new password",
	 .data_type = PASSWD,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "pwv",
	 .field_gui_name = "Re-Type Password"},
	{
	 .field_name = "MTU",
	 .field_help = "This field represent the max transfer unit",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "mtu",
	 .field_gui_name = "MTU"},
	{
	 .field_name = "reconnect",
	 .field_help = "This field represent the status of dial on demand",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "reconnect",
	 .field_gui_name = "Reconnect",
	 .values = pppoea_config_reconnect_values,
	 .tot_values =
	 sizeof(pppoea_config_reconnect_values) / sizeof(struct value_set),
	 .fprocessing_post = pppoea_config_reconnect_post},
	{
	 .field_name = "IDLE",
	 .field_help =
	 "This field represent the maximum idle time (in miutes) for dial on demand",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "IDLE",
	 .field_gui_name = "Maximum Idle Time"},
	{
	 .field_name = "WT",
	 .data_type = INT,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .cur_value = "4"}
};

struct cmd_entry pppoa_config_cmd = {
	.fields = pppoa_config_cmd_field,
	.tot_fields = sizeof(pppoa_config_cmd_field) / sizeof(struct cmd_field),
	.help = "This command configures pppoa settings",
	.post_url = "/goform/ifx_set_wan_pppoa",
	.custom_processing_post = wan_config_cmd_post_flag,
	.custom_validation = validate_password
};

struct menu_entry wan_pppoa_page_entries[] = {
#if 0
	{
	 .entry_help = "This is pppoa show entry",.cli_name = "Show",
	 .cli_url = "wan_pppoa.cli"},
#endif
	{

	 .entry_help = "This is pppoa config entry",.cli_name = "Config",
	 .cmd = &pppoa_config_cmd}
};

#ifndef CONFIG_FEATURE_SEMINDIA
#if 1
struct menu_page wan_pppoa_page = {
	.entries = wan_pppoa_page_entries,
	.tot_entries =
	    sizeof(wan_pppoa_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is wan pppoa page",
	.cli_title = "pppoa",.gui_title = "PPPoA"
};
#endif
#endif				//CONFIG_FEATURE_SEMINDIA

struct cmd_field dns_config_cmd_field[] = {
	{
	 .field_name = "DIP1",
	 .field_help = "This field represent the primary domain ip address",
	 .data_type = IPADDR,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "primipaddr",
	 .field_gui_name = "Primary IP Address",
	 .fprocessing_post = ip_nm_gw_processing},
	{
	 .field_name = "DIP2",
	 .field_help = "This field represent the secondary domain ip address",
	 .data_type = IPADDR,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "secipaddr",
	 .field_gui_name = "Secondary IP Address",
	 .fprocessing_post = ip_nm_gw_processing}
};

struct cmd_entry dns_config_cmd = {
	.fields = dns_config_cmd_field,
	.tot_fields = sizeof(dns_config_cmd_field) / sizeof(struct cmd_field),
	.help = "This command configures domain address",
	.post_url = "/goform/ifx_set_wan_dns",
	.get_url = "wan_dns.cli"
};

struct menu_entry dns_page_entries[] = {
	{
	 .entry_help = "This is dns show entry",
	 .cli_name = "Show",.cli_url = "wan_dns.cli"},
	{
	 .entry_help = "This is dns config entry",
	 .cli_name = "Config",.cmd = &dns_config_cmd}
};

struct menu_page wan_dns_page = {
	.entries = dns_page_entries,
	.tot_entries = sizeof(dns_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is dns page",.cli_title = "dns",.gui_title = "DNS"
};

struct cmd_field wan_vlan_cmd_field[] = {
	{
	 .field_name = "wan_vlan_status",
	 .field_help =
	 "This field represent the status of wan vlan configuration",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "wan_vlan_status",
	 .field_gui_name = "Enable",
	 .values = vlan_tag_values,
	 .tot_values = sizeof(vlan_tag_values) / sizeof(struct value_set)
	 }
};

struct cmd_entry wan_vlan_cmd = {
	.fields = wan_vlan_cmd_field,
	.tot_fields = sizeof(wan_vlan_cmd_field) / sizeof(struct cmd_field),
	.help =
	    "This command either enables or disables wan vlan configuration",
	.post_url = "/goform/ifx_set_wan_vlan",
	.get_url = "wan_vlan_config.cli"
};

struct menu_entry wan_vlan_page_entries[] = {
	{
	 .entry_help = "This is wan vlan show entry",
	 .cli_name = "Show",.cli_url = "wan_vlan_config.cli"},
	{
	 .entry_help = "This is wan vlan config entry",
	 .cli_name = "Config",.cmd = &wan_vlan_cmd}
};

struct menu_page wan_vlan_page = {
	.entries = wan_vlan_page_entries,
	.tot_entries =
	    sizeof(wan_vlan_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is wan vlan page",.cli_title = "vlan",.gui_title =
	    "WAN VLAN Config"
};

#if 0
struct cmd_field wanif_cmd_field[] = {
#if 0
	{
	 .field_name = "WAN",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "iface_no"},
#endif
	{
	 .field_name = "WAN",
	 .field_help = "The WAN interface to be configured",
	 .field_help = "represent the vpi/vci pair",
	 .data_type = STR,.field_type = DYNAMIC,.mandatory = IFX_TRUE,
	 .field_display_name = "vpivci"}
};

struct cmd_entry wanif_cmd = {
	.fields = wanif_cmd_field,
	.tot_fields = sizeof(wanif_cmd_field) / sizeof(struct cmd_field),
	.help = "sets interface number to vpi vci entry",
	.post_url = "/goform/ifx_set_wan_vcc_settings"
};
#endif

struct cmd_field disable_cmd_field[] = {
	{
	 .field_name = "WAN",
	 .field_help = "The WAN interface to be configured",
	 .data_type = INT,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "wanif",
	 .field_gui_name = "WAN Interface",
	 .values = wan_interface_values,
	 .tot_values = sizeof(wan_interface_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "vcChannel",
	 .field_help = "represent the vpi/vci pair",
	 .data_type = STR,.field_type = DYNAMIC,.mandatory = IFX_TRUE,
	 .field_display_name = "vpivci",
	 .field_gui_name = "VPI/VCI",
	 .get_vset = get_vpivci_fvset},
	{
	 .field_name = "WT",
	 .data_type = INT,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .cur_value = "0"}
};

struct cmd_entry disable_cmd = {
	.fields = disable_cmd_field,
	.help =
	    "This command disables the chosen wan interface with corresponding vpivci",
	.tot_fields = sizeof(disable_cmd_field) / sizeof(struct cmd_field),
	.post_url = "/goform/ifx_set_wan",
	.custom_processing_post = wan_config_cmd_post_flag
};

struct cmd_field bridge_cmd_field[] = {
	{
	 .field_name = "WAN",
	 .field_help = "The WAN interface to be configured",
	 .data_type = INT,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "wanif",
	 .field_gui_name = "WAN Interface",
	 .values = wan_interface_values,
	 .tot_values = sizeof(wan_interface_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "vcChannel",
	 .field_help = "represent the vpi/vci pair",
	 .data_type = STR,.field_type = DYNAMIC,.mandatory = IFX_TRUE,
	 .field_display_name = "vpivci",
	 .field_gui_name = "VPI/VCI",
	 .get_vset = get_vpivci_fvset},
	{
	 .field_name = "BridgeSetting",
	 .field_help = "This field represent the stp mode",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "STP",
	 .field_gui_name = "STP",
	 .values = bridge_stp_values,
	 .tot_values = sizeof(bridge_stp_values) / sizeof(struct value_set)
	 },
	/* vlan related [ */
	{
	 .field_name = "VID",
	 .field_help = "This field represent the vlan id",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "VID",
	 .field_gui_name = "VLAN ID"},
	{
	 .field_name = "VPRIO",
	 .field_help = "This field represent the vlan priority",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "VPRIO",
	 .field_gui_name = "VLAN Priority"},
	{
	 .field_name = "VTAG",
	 .field_help = "This field represent the vlan tag",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "VTAG",
	 .field_gui_name = "TAG",
	 .values = vlan_tag_values,
	 .tot_values = sizeof(vlan_tag_values) / sizeof(struct value_set)
	 },
#if 0
	{
	 .field_name = "VUNTAG",
	 .field_help = "This field represent the vlan un-tag",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "VUNTAG",
	 .field_gui_name = "UN-TAG",
	 .values = vlan_tag_values,
	 .tot_values = sizeof(vlan_tag_values) / sizeof(struct value_set)
	 },
#else
	{
	 .field_name = "VUNTAG",
	 .data_type = STR,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .cur_value = "0"},
#endif				// 0
	/* ] */
	{
	 .field_name = "WT",
	 .data_type = INT,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .cur_value = "5"}
};

struct cmd_entry bridge_cmd = {
	.fields = bridge_cmd_field,
	.tot_fields = sizeof(bridge_cmd_field) / sizeof(struct cmd_field),
	.help = "This command configures bridge settings",
	.post_url = "/goform/ifx_set_bridge_settings",
	.custom_processing_post = wan_config_cmd_post_flag
};

struct menu_entry wan_settings_entries[] = {
	{
	 .next_page = &wan_pppoe_page,.entry_help = "This is wan pppoe entry",
	 .cli_name = "pppoe",.gui_name = "PPPoE",.gui_url = "wan_pppoe.asp"},
#ifndef CONFIG_FEATURE_SEMINDIA
#if 1

	{
	 .next_page = &wan_pppoa_page,.entry_help =
	 "This is wan vcc pppoa entry",
	 .cli_name = "pppoa",.gui_name = "PPPoA",.gui_url = "wan_pppoa.asp"},
#endif
#endif				//CONFIG_FEATURE_SEMINDIA
	{
	 .next_page = &wan_static_page,.entry_help = "This is wan static entry",
	 .cli_name = "static",.gui_name = "Static",.gui_url = "wan_static.asp"},
	{
	 .next_page = &wan_dhcp_page,.entry_help = "This is wan dynamic entry",
	 .cli_name = "dynamic",.gui_name = "Dynamic",.gui_url = "wan_dhcp.asp"},
	{
	 .next_page = &wan_defgw_page,.entry_help = "This is wan defgw entry",
	 .cli_name = "defgw",.gui_name = "Default Gateway",.gui_url =
	 "wan_vcc_select.asp"},
	{
	 .entry_help = "This is wan dhcp bigpond entry",.cli_name = "Bridge",
	 .cmd = &bridge_cmd},
	{
	 .entry_help = "This is wan disable entry",.cli_name = "Delete",
	 .cmd = &disable_cmd},
	{
	 .entry_help = "This is wan show entry",.cli_name = "Show",
	 //.cli_url="wan_status.cli"
	 .cli_url = "wan_vcc_select.cli"}
};

struct menu_page wan_settings_page = {
	.entries = wan_settings_entries,
	.tot_entries = sizeof(wan_settings_entries) / sizeof(struct menu_entry),
	.cli_title = "settings",.gui_title = "settings",
	.page_help = "wan settings page"
};

struct menu_entry wan_status_entries[] = {
	{
	 .entry_help = "status show entry",
	 .cli_name = "Show",.cli_url = "wan_status.cli"
	 //.cli_name="Show" ,.cli_url="wan_vcc_select.cli"
	 }
};

struct menu_page wan_status_page = {
	.entries = wan_status_entries,
	.tot_entries = sizeof(wan_status_entries) / sizeof(struct menu_entry),
	.page_help = "wan status page",
	.cli_title = "status",.gui_title = "Status"
};

struct menu_entry wan_page_entries[] = {
	{
	 .next_page = &adsl_vcconfig_page,
	 .entry_help = "The adsl VC config",.cli_name = "vcconfig",
	 .gui_name = "VC Configuration",.gui_url = "adsl_vcconfig.asp"},
	{
	 .next_page = &wan_settings_page,
	 .entry_help = "wan settings entry",
	 .cli_name = "settings",.gui_name = "Settings",.gui_url =
	 "wan_vcc_select.asp"},
#if 0
	{
	 .entry_help = "wan interface entry",
	 .cli_name = "wanif",.cmd = &wanif_cmd},
#endif
	{
	 .next_page = &wan_vlan_page,
	 .entry_help = "wan vlan entry",
	 .cli_name = "vlan",.gui_name = "WAN VLAN Config",.gui_url =
	 "wan_vlan_config.asp"},
	{
	 .next_page = &wan_status_page,
	 .entry_help = "wan status entry",
	 .cli_name = "status",.gui_name = "Status",.gui_url = "wan_status.asp"},
	{
	 .next_page = &wan_dns_page,
	 .entry_help = "wan dns entry",
	 .cli_name = "dns",.gui_name = "DNS",.gui_url = "wan_dns.asp"},
	{
	 .next_page = &adsl_oamconfig_page,
	 .entry_help = "The adsl OAM config",.cli_name = "oam",
	 .gui_name = "OAM Configuration",.gui_url = "adsl_oamconfig.asp"}
};

struct menu_page wan_page = {
	.entries = wan_page_entries,
	.tot_entries = sizeof(wan_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is wan page",.cli_title = "wan",.gui_title = "WAN"
};
