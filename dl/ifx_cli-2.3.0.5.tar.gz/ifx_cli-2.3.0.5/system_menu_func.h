
int system_log_clear_post_flag(struct cmd_entry *cmd, char *poststr);
//int system_restore_post_flag(struct cmd_entry *cmd,char *poststr);
int system_log_view_post_flag(struct cmd_entry *cmd, char *poststr);
int system_log_custom_valid(struct cmd_entry *cmd, char *errstr);
int system_log_set_post_flag(struct cmd_entry *cmd, char *poststr);
