/* ============================================================================
 * Copyright (C) 2005 -Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 *============================================================================
 *
 * This document contains proprietary information belonging to Infineon 
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 * 
 * ============================================================================
 */

/* ===========================================================================
 *
 * File Name:   cli_fe.c
 * Author :     Nirav Salot
 * Date: 		April, 2005
 *
 * ===========================================================================
 *
 * Project: Amazon
 *
 * ===========================================================================
 * Contents: This file implements the CLI front-end which is responsible for
 * displaying the CLI menus and command output, and inputting commands from
 * the user.
 *  
 * ===========================================================================
 * References: 
 *
 */

/* ===========================================================================
 * Revision History:
 *
 * $Log$
 * ===========================================================================
 */
#include "common.h"

#define SOCK_FE_PATH "/tmp/cli_fe_socket"
#define CMD_LENGTH	512
#define CHR_TO_ENCODE " &@=$%~!"

#define BUF_CHUNK 1024

#define RELOCATE_PTR(base,deststr,desttype)	deststr = (desttype)(base + (int)deststr)

char cur_path[128];
char cur_display_path[128];
char cur_cmd[256];
struct toplevel_fe_msg cur_fe_msg;
enum MSG_TYPE_FE prev_msg;

int checknexit(char *token, int *count)
{
	char c = 0, command[128];
	int cnt = 0, state = 0, grep = 0;
	sprintf(command, "ps | grep %s > /tmp/chktmp.txt", token);
	system(command);
	FILE *fp;
	fp = fopen("/tmp/chktmp.txt", "r");
	if (fp != NULL) {
		while ((c = getc(fp)) != EOF) {
			/* parsing for 'grep' in the file */
			switch (state) {
			case 0:
				if (c == 'g')
					state = 1;
				else if (c == '\n') {
					if (!grep)
						cnt++;
					grep = 0;
				}
				break;
			case 1:
				if (c == 'r')
					state = 2;
				else
					state = 0;
				break;
			case 2:
				if (c == 'e')
					state = 3;
				else
					state = 0;
				break;
			case 3:
				if (c == 'p')
					grep = 1;
				state = 0;
				break;
			default:
				break;
			}
		}
		*count = cnt;
		fclose(fp);
	} else
		return -1;

	system("rm -f /tmp/chktmp.txt");
	return 0;
}

void encodestr(char *source, char *dest)
{

/*Assumption: We assume sizeof(dest) is always 256*/
#define MAX_DEST_SIZE 256

	char *curpos = NULL;
	char *chrfound = NULL;

	if ((curpos = strchr(source, '=')) != NULL) {
		strlcat(dest, source, MAX_DEST_SIZE);
		source = curpos + 1;
	}
	curpos = source;
	while ((chrfound = strpbrk(curpos, CHR_TO_ENCODE)) != NULL) {
		char temp[8];
		memset(temp, 0x00, sizeof(temp));

		sprintf(temp, "%%%x", *chrfound);
		strlcat(dest, curpos, MAX_DEST_SIZE);
		strlcat(dest, temp, MAX_DEST_SIZE);
		curpos = chrfound + 1;
	}
	strlcat(dest, curpos, MAX_DEST_SIZE);
}

int process_menu_msg(char *pstr, int tot_entries)
{
	struct menu_msg *phead_menu_msg = NULL;
	struct menu_msg *pcur_menu_msg = NULL;
	int cur_choice = 0;
	int i, numfe = 0;

	phead_menu_msg =
	    (struct menu_msg *)(pstr + sizeof(struct toplevel_be_msg));
	pcur_menu_msg = phead_menu_msg;
	do {
		RELOCATE_PTR(pstr, pcur_menu_msg->menu_display_name, char *);
		RELOCATE_PTR(pstr, pcur_menu_msg->menu_submit_name, char *);
		RELOCATE_PTR(pstr, pcur_menu_msg->menu_help, char *);

		if (pcur_menu_msg->next)
			RELOCATE_PTR(pstr, pcur_menu_msg->next,
				     struct menu_msg *);
		pcur_menu_msg = pcur_menu_msg->next;
	} while (pcur_menu_msg);

	do {
		char tstr[16];
		int i = 1;
		pcur_menu_msg = phead_menu_msg;
		//printf("\n%s\n",cur_display_path);
		printf
		    ("\nEnter your choice ['H'|'h'-Home, '%s'-Help, '%s'-Previous, '%s'-Exit '%s'-Logout] [1-%d] :\n",
		     HELP_CHAR, PREVIOUS_CHAR, EXIT_CHAR, LOGOUT_CHAR,
		     tot_entries);
		while (pcur_menu_msg) {
			printf("%3d. %s\n", i,
			       pcur_menu_msg->menu_display_name);
			pcur_menu_msg = pcur_menu_msg->next;
			i++;
		}

		printf("\n%s -> ", cur_display_path);
		memset(tstr, 0x00, sizeof(tstr));
		i = 0;
		while ((tstr[i++] = getchar()) != '\n') ;
		tstr[--i] = '\0';
		cur_choice = atoi(tstr);

		if (strcmp(tstr, PREVIOUS_CHAR) == 0) {
			cur_choice = 0;
			break;
		} else if (strcmp(tstr, "H") == 0 || strcmp(tstr, "h") == 0) {
			cur_choice = -1;
			strcpy(cur_path, "/main");
			strcpy(cur_display_path, "/Main");
			break;
		} else if (strncmp(tstr, HELP_CHAR, strlen(HELP_CHAR)) == 0) {
			char *temp = NULL;
			int nIndex;
			temp = strchr(tstr, ' ');
			if (temp) {
				temp++;
				nIndex = atoi(temp);
				if (nIndex < 1 || nIndex > tot_entries)
					printf("Error : Invalid choice.\n");
				else {
					for (i = 1, pcur_menu_msg =
					     phead_menu_msg; i < nIndex;
					     i++, pcur_menu_msg =
					     pcur_menu_msg->next) ;
					printf("%s\n",
					       pcur_menu_msg->menu_help);
				}
			}
			printf("Press <enter> to continue...");
			getchar();
		} else if (strcmp(tstr, EXIT_CHAR) == 0) {
#if 1
			char *args[2] = { 0 };
			char shell[10];
			strcpy(shell, "/bin/sh");
			checknexit("cli_fe", &numfe);
			if (numfe == 1) {
				system("killall -9 cli_be");
			}
			args[0] = shell;
			execv(args[0], args);
#else
			system("/bin/sh");
#endif
			return -1;
		} else if (strcmp(tstr, LOGOUT_CHAR) == 0) {
			checknexit("cli_fe", &numfe);
			if (numfe == 1) {
				system("killall -9 cli_be");
			}
			return -1;
		} else if (cur_choice == 0 && tstr[0] != '0') {
			printf("Error : Invalid input.\n");
		} else if (cur_choice < 1 || cur_choice > tot_entries) {
			printf("Error : Invalid choice.\n");
		} else
			break;
	} while (1);

	if (cur_choice == 0) {
		if (strcmp(cur_path, "/main") != 0) {
			char *temp;
			temp = strrchr(cur_path, '/');
			cur_path[temp - cur_path] = '\0';
			temp = strrchr(cur_display_path, '/');
			cur_display_path[temp - cur_display_path] = '\0';
		}
	} else if (cur_choice > 0) {
		for (i = 1, pcur_menu_msg = phead_menu_msg; i < cur_choice;
		     i++, pcur_menu_msg = pcur_menu_msg->next) ;
		strcat(cur_path, "/");
		strcat(cur_path, pcur_menu_msg->menu_submit_name);
		strcat(cur_display_path, "/");
		strcat(cur_display_path, pcur_menu_msg->menu_display_name);
	}
	cur_fe_msg.msg_type = MSG_QUERY;
	return 0;
}

int process_cmd_msg(char *pstr, int tot_entries)
{
	struct cmd_msg *phead_cmd_msg = NULL;
	struct cmd_msg *pcur_cmd_msg = NULL;

	if (tot_entries <= 0) {
		memset(cur_cmd, 0x00, sizeof(cur_cmd));
		cur_fe_msg.msg_type = MSG_SUBMIT;
		return 0;
	}

	phead_cmd_msg =
	    (struct cmd_msg *)(pstr + sizeof(struct toplevel_be_msg));
	pcur_cmd_msg = phead_cmd_msg;
	do {
		RELOCATE_PTR(pstr, pcur_cmd_msg->field_name, char *);
		RELOCATE_PTR(pstr, pcur_cmd_msg->display_str, char *);
		RELOCATE_PTR(pstr, pcur_cmd_msg->default_val, char *);
		RELOCATE_PTR(pstr, pcur_cmd_msg->field_help, char *);
		RELOCATE_PTR(pstr, pcur_cmd_msg->str_statvalues, char *);
		pcur_cmd_msg->cur_value = NULL;

		if (pcur_cmd_msg->next)
			RELOCATE_PTR(pstr, pcur_cmd_msg->next,
				     struct cmd_msg *);
		pcur_cmd_msg = pcur_cmd_msg->next;
	} while (pcur_cmd_msg);

	memset(cur_cmd, 0x00, sizeof(cur_cmd));
//      getchar();
	if (strcmp(phead_cmd_msg->field_name, "G992_1A") == 0) {
		printf("\n");
		printf("Rule 1:\n");
		printf
		    (" AnnexA include G.992.1_A, G.992.2,  G.992.3_A, G.992.5_A, T1.413, G.992.3_L, G.992.3_I, G.992.5_I, G.992.3_M, G.992.5_M\n");
		printf
		    (" AnnexB include G.992.1_B, G.992.3_B, G.992.5_B, G.992.3_J, G.992.3_J\n");
		printf(" AnnexI include G.992.3_I, G.992.5_I\n");
		printf(" AnnexJ include G.992.3_J, G.992.5_J\n");
		printf(" AnnexM include G.992.3_M, G.992.5_M\n");
		printf
		    (" Multimode can't be allowed as long as they are not in the same group(Annex A or Annex B).\n");
		printf(" Example :\n");
		printf
		    ("   you can select G.992.1_A, but you can't add G.992.1_B into this selection.\n");
		printf("\n");
		printf("Rule 2:\n");
		printf(" G.992.3_L requires G.992.3_A also to be selected\n");
		printf("\n");
	}

	if (prompt_validate_value(phead_cmd_msg)) {
		char *temp;
		temp = strrchr(cur_path, '/');
		cur_path[temp - cur_path] = '\0';
		temp = strrchr(cur_display_path, '/');
		cur_display_path[temp - cur_display_path] = '\0';
		cur_fe_msg.msg_type = MSG_SHOW;
	} else {
		pcur_cmd_msg = phead_cmd_msg;
		while (pcur_cmd_msg) {
			if (strcmp(pcur_cmd_msg->cur_value, "") != 0) {
				strcat(cur_cmd, pcur_cmd_msg->field_name);
				strcat(cur_cmd, "=");
				encodestr(pcur_cmd_msg->cur_value, cur_cmd);
				strcat(cur_cmd, " ");
			}
			pcur_cmd_msg = pcur_cmd_msg->next;
		}
		//Vicky_Note: Why strlen - 1. It should ideally be just strl
		cur_cmd[strlen(cur_cmd) - 1] = '\0';
		cur_fe_msg.msg_type = MSG_SUBMIT;
	}

	pcur_cmd_msg = phead_cmd_msg;
	while (pcur_cmd_msg) {
		if (pcur_cmd_msg->cur_value)
			free(pcur_cmd_msg->cur_value);
		pcur_cmd_msg = pcur_cmd_msg->next;
	}
	return 0;
}

int process_show_msg(char *pstr)
{
	char *ptemp = NULL;
	int nLines = 0;

	pstr += sizeof(struct toplevel_be_msg);
	if (prev_msg != MSG_QUERY || strstr(pstr, "Error")) {
		ptemp = strtok(pstr, "\n");
#if 0
		if (prev_msg != MSG_CMD)
			getchar();
#endif

		printf("\n");
		while (ptemp) {
			printf("%s\n", ptemp);
			ptemp = strtok(NULL, "\n");
			nLines++;
			if (nLines > SCREEN_WIDTH) {
				printf("\nPress <enter> to continue...");
				getchar();
				nLines = 0;
			}
		}
	}
	if (strcmp(cur_path, "/main") != 0) {
		char *temp;
		temp = strrchr(cur_path, '/');
		cur_path[temp - cur_path] = '\0';
		temp = strrchr(cur_display_path, '/');
		cur_display_path[temp - cur_display_path] = '\0';
	}
	cur_fe_msg.msg_type = MSG_QUERY;
	printf("\nPress <enter> to continue...");
	getchar();
	return 0;
}

int process_msg(char *pstr, int tot_bytes)
{
	struct toplevel_be_msg *ptmsg = NULL;
	char *temp = NULL;
	int retval = 0;

	ptmsg = (struct toplevel_be_msg *)pstr;
	switch (ptmsg->msg_type) {
	case MSG_MENU:
		retval = process_menu_msg(pstr, ptmsg->tot_entries);
		prev_msg = MSG_MENU;
		break;

	case MSG_CMD:
		retval = process_cmd_msg(pstr, ptmsg->tot_entries);
		prev_msg = MSG_CMD;
		break;

	case MSG_SHOW:
		retval = process_show_msg(pstr);
		prev_msg = MSG_QUERY;
		break;

	default:
		printf("Unknown msg_type [%d]\n", ptmsg->msg_type);
		cur_fe_msg.msg_type = MSG_QUERY;
		if (strcmp(cur_path, "/main") != 0) {
			temp = strrchr(cur_path, '/');
			cur_path[temp - cur_path] = '\0';
			temp = strrchr(cur_display_path, '/');
			cur_display_path[temp - cur_display_path] = '\0';
		}
		prev_msg = MSG_QUERY;
		break;
	}
	return retval;
}

void make_fe_msg(char *msg, int *pmsglen)
{
	cur_fe_msg.cli_fe_pid = getpid();
	memcpy(msg, &cur_fe_msg, sizeof(cur_fe_msg));
	msg += sizeof(cur_fe_msg);
	*pmsglen = sizeof(cur_fe_msg);
	strcpy(msg, cur_path);
	*pmsglen += strlen(cur_path);
	if (cur_fe_msg.msg_type == MSG_SUBMIT && strlen(cur_cmd) > 0) {
		strcat(msg, " ");
		strlcat(msg, cur_cmd, sizeof(cur_cmd));
		*pmsglen += strlen(cur_cmd) + 1;
	}

}

int main(int argc, char *argv[])
{
	memset(cur_path, 0x00, sizeof(cur_path));
	memset(cur_display_path, 0x00, sizeof(cur_display_path));
	strcpy(cur_path, "/main");
	strcpy(cur_display_path, "/Main");
	cur_fe_msg.msg_type = MSG_QUERY;

	do {
		int bexit = 0;
		int local_sock, t, len;
		struct sockaddr_un remote;
		char *pstr = NULL;
		int tot_bytes;
		char cmd[CMD_LENGTH];
		int cmd_len = 0;

		memset(cmd, 0x00, sizeof(cmd));
		if ((local_sock = socket(AF_UNIX, SOCK_STREAM, 0)) == -1) {
			perror("socket");
			exit(1);
		}

		remote.sun_family = AF_UNIX;
		strcpy(remote.sun_path, SOCK_FE_PATH);
		len = strlen(remote.sun_path) + sizeof(remote.sun_family);

		if (connect(local_sock, (struct sockaddr *)&remote, len) == -1) {
			perror("connect");
			exit(1);
		}

		make_fe_msg(cmd, &cmd_len);
		if (send(local_sock, cmd, cmd_len, 0) == -1) {
			perror("send");
			exit(1);
		}

		tot_bytes = 0;
		pstr = NULL;
		while (1) {
			pstr = (char *)realloc(pstr, tot_bytes + BUF_CHUNK);
			memset(pstr + tot_bytes, 0x00, BUF_CHUNK);
			if ((t =
			     recv(local_sock, pstr + tot_bytes, BUF_CHUNK - 1,
				  0)) > 0) {
				tot_bytes += t;
			} else {
				if (t < 0)
					perror("recv");
				break;
			}
		}

		close(local_sock);

		if (pstr != NULL) {
			bexit = process_msg(pstr, tot_bytes);
			free(pstr);
			if (bexit)
				break;
		}
	} while (1);

	return 0;
}
