/* ============================================================================
 * Copyright (C) 2005 -Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 *============================================================================
 *
 * This document contains proprietary information belonging to Infineon 
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 * 
 * ============================================================================
 */

/* ===========================================================================
 *
 * File Name:   apps_menu_func.c
 * Author :     Nirav Salot
 * Date: 		April, 2005
 *
 * ===========================================================================
 *
 * Project: Amazon
 *
 * ===========================================================================
 * Contents: This file implements Application menu related specific functions.
 *  
 * ===========================================================================
 * References: 
 *
 * $Log$
 *
 */
#include <stdio.h>
#include "common.h"

int server_acl_config_post_flag(struct cmd_entry *cmd, char *poststr)
{
	struct cmd_field *cur_field = cmd->fields;
	char *strindex = NULL;
	char *strip = NULL;
	int i, index;
	char temp[8];

	for (i = 0; i < cmd->tot_fields; i++, cur_field++) {
		if (strcmp(cur_field->field_display_name, "index") == 0) {
			struct value_set *cur_value = NULL;
			int j;
			for (j = 0, cur_value = cur_field->values;
			     j < cur_field->tot_values; j++, cur_value++) {
				if (strcmp
				    (cur_value->display_value,
				     cur_field->cur_value) == 0) {
					strindex = cur_value->submit_value;
					break;
				}
			}
		} else if (strcmp(cur_field->field_display_name, "ipaddr") == 0)
			strip = cur_field->cur_value;
	}

	if (strindex == NULL) {
		sprintf(poststr, "Error : strindex is NULL\n");
		return -1;
	}

	index = atoi(strindex);

	if (index < 1 || index > 16) {
		sprintf(poststr,
			"Error : index can only be within range [1-16]\n");
		return -1;
	}

	memset(temp, 0x00, sizeof(temp));
	sprintf(temp, "%d", index - 1);
	strcat(poststr, "SERVERS_ACL");
	strcat(poststr, temp);
	strcat(poststr, "=");

	strcat(poststr, (strip) ? strip : "\"\"");

	return 0;

}
