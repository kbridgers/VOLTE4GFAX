#include "content_sharing_menu_func.h"

#ifdef CONFIG_FEATURE_SAMBA	/* CONFIG_FEATURE_SAMBA_SERVER */
struct value_set samba_setting_set_cmd_fields_values[] = {
	{.display_value = "disable",.submit_value = "0"},
	{.display_value = "enable",.submit_value = "1"}
};

struct cmd_field content_sharing_samba_server_set_cmd_fields[] = {
	{
	 .field_name = "SAMBAEnable",
	 .field_help = NULL,
	 .data_type = STR,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "sambaenable",
	 .field_gui_name = "SAMBA",
	 .values = samba_setting_set_cmd_fields_values,
	 .tot_values =
	 sizeof(samba_setting_set_cmd_fields_values) / sizeof(struct value_set),
	 .cur_value = "enable"},
	{
	 .field_name = "SSN",
	 .field_help = "SAMBA server name",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "servername",
	 .field_gui_name = "Server Name"},
	{
	 .field_name = "SSD",
	 .field_help = "SAMBA server description",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "serverdescr",
	 .field_gui_name = "Server Description"},
	{
	 .field_name = "WG",
	 .field_help = "SAMBA workgroup",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "workgroup",
	 .field_gui_name = "Work Group"}
};

struct cmd_entry content_sharing_samba_server_set_cmd = {
	.fields = content_sharing_samba_server_set_cmd_fields,
	.tot_fields =
	    sizeof(content_sharing_samba_server_set_cmd_fields) /
	    sizeof(struct cmd_field),
	.help = "Command to set SAMBA server configuration",
	.post_url = "/goform/ifx_set_samba_settings",
	.custom_validation = samba_setting_validate,
	.get_url = "content_sharing_samba_server.cli"
};

struct menu_entry content_sharing_samba_server_entries[] = {
	{
	 .entry_help = "Command to see SAMBA server current configuration",
	 .cli_name = "Show",
	 .cli_url = "content_sharing_samba_server.cli",
	 .cmd = NULL},
	{
	 .entry_help = "Command to set SAMBA server configuration",
	 .cli_name = "Set",
	 .cli_url = NULL,
	 .cmd = &content_sharing_samba_server_set_cmd}
};

struct menu_page content_sharing_samba_server_page = {
	.entries = content_sharing_samba_server_entries,
	.tot_entries =
	    sizeof(content_sharing_samba_server_entries) /
	    sizeof(struct menu_entry),
	.page_help = "This is SAMBA server configuration page",
	.cli_title = "SAMBA Server",
	.fpos = 0
};

struct cmd_field content_sharing_samba_disable_cmd_fields[] = {
	{
	 .field_name = "SAMBAEnable",
	 .field_help = NULL,
	 .data_type = STR,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .values = samba_setting_set_cmd_fields_values,
	 .tot_values =
	 sizeof(samba_setting_set_cmd_fields_values) / sizeof(struct value_set),
	 .cur_value = "disable"}
};

struct cmd_entry content_sharing_samba_disable_cmd = {
	.fields = content_sharing_samba_disable_cmd_fields,
	.tot_fields =
	    sizeof(content_sharing_samba_disable_cmd_fields) /
	    sizeof(struct cmd_field),
	.help = "This field allows to disable SAMBA",
	.post_url = "/goform/ifx_set_samba_settings",
	.get_url = "content_sharing_samba_server.cli"
};

struct menu_entry content_sharing_samba_page_entries[] = {
	{
	 .next_page = &content_sharing_samba_server_page,
	 .entry_help = "SAMBA server configuration",
	 .cli_name = "Server",
	 .cli_url = NULL},
	{
	 .entry_help = "SAMBA disable",
	 .cli_name = "Disable",
	 .cmd = &content_sharing_samba_disable_cmd}
};

struct menu_page content_sharing_samba_page = {
	.entries = content_sharing_samba_page_entries,
	.tot_entries =
	    sizeof(content_sharing_samba_page_entries) /
	    sizeof(struct menu_entry),
	.page_help = "This is content sharing samba page",
	.cli_title = "Samba",
	.gui_title = "SAMBA"
};

struct menu_entry content_sharing_page_entries[] = {
	{
	 .next_page = &content_sharing_samba_page,
	 .entry_help = "This is content sharing samba entry",
	 .cli_name = "samba",
	 .gui_name = "SAMBA"}
};

struct menu_page content_sharing_page = {
	.entries = content_sharing_page_entries,
	.tot_entries =
	    sizeof(content_sharing_page_entries) / sizeof(struct menu_entry),
	.page_help = "The Content Sharing Page",
	.cli_title = "Content Sharing Page",
	.gui_title = "Content Sharing Page",
	.fpos = 1
};
#endif				/* CONFIG_FEATURE_SAMBA_SERVER */
