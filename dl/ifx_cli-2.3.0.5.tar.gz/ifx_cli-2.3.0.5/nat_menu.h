
#include "nat_menu_func.h"

struct value_set nat_dmz_set_status_values[] = {
	{"disable", "0"},
	{"enable", "1"}
};

struct cmd_field nat_dmz_set_cmd_fields[] = {
	{
	 .field_name = "C1",
	 .field_help = "This field represents the status of the DMZ",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "status",
	 .field_gui_name = "Status",
	 .values = nat_dmz_set_status_values,
	 .tot_values =
	 sizeof(nat_dmz_set_status_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "dmzip",
	 .field_help = "This field represents the ipadd of the DMZ host",
	 .data_type = IPADDR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "ipaddr",
	 .field_gui_name = "DMZ Host IP Address",
	 .fprocessing_post = ip_nm_gw_processing}
};

struct cmd_entry nat_dmz_set_cmd = {
	.fields = nat_dmz_set_cmd_fields,
	.tot_fields = sizeof(nat_dmz_set_cmd_fields) / sizeof(struct cmd_field),
	.help = "This command allows user to change the DMZ configuration",
	.post_url = "/goform/ifx_set_firewall_dmz",
	.get_url = "firewall_dmz.cli"
};

struct menu_entry nat_dmz_entries[] = {
	{
	 .entry_help = "This entry allows to see the DMZ configuration",
	 .cli_name = "Show",
	 .cli_url = "firewall_dmz.cli"},
	{
	 .entry_help = "This entry allows to set the DMZ configuration",
	 .cli_name = "Set",
	 .cmd = &nat_dmz_set_cmd}
};

struct menu_page nat_dmz_page = {
	.entries = nat_dmz_entries,
	.tot_entries = sizeof(nat_dmz_entries) / sizeof(struct menu_entry),
	.page_help = "This is NAT DMZ page",
	.cli_title = "dmz",
	.gui_title = "DMZ",
	.fpos = 1
};

struct value_set nat_virtualser_set_proto_values[] = {
	{"tcp", "1"},
	{"udp", "2"}
};

struct value_set nat_virtualser_set_status_values[] = {
	{"disable", "0"},
	{"enable", "1"}
};

struct value_set nat_virtualser_set_index_values[] = {
	{"Rule1", "1"},
	{"Rule2", "2"},
	{"Rule3", "3"},
	{"Rule4", "4"},
	{"Rule5", "5"}
};

struct cmd_field nat_virtualser_set_cmd_fields[] = {
	{
	 .field_name = "index",
	 .field_help =
	 "This field represents the index [1-5] of the current rule",
	 .data_type = INT,
	 .field_type = STATIC,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "index",
	 .field_gui_name = "Index",
	 .tot_values =
	 sizeof(nat_virtualser_set_index_values) / sizeof(struct value_set),
	 .values = nat_virtualser_set_index_values},
	{
	 .field_name = "NATVS_PIP",
	 .field_help = "This field represents the private ip address",
	 .data_type = IPADDR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "ip",
	 .field_gui_name = "Private IP Address"},
	{
	 .field_name = "NATVS_PPORT",
	 .field_help = "This field represents the private port",
	 .data_type = INT,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "pport",
	 .field_gui_name = "Private Port"},
	{
	 .field_name = "NATVS_TYPE",
	 .field_help = "This field represents the type of the protocol",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "proto",
	 .field_gui_name = "Protocol Type",
	 .values = nat_virtualser_set_proto_values,
	 .tot_values =
	 sizeof(nat_virtualser_set_proto_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "NATVS_PUPORT",
	 .field_help = "This field represents the public port",
	 .data_type = INT,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "puport",
	 .field_gui_name = "Public Port"},
	{
	 .field_name = "NATVS_F",
	 .field_help = "This field represents the status of the current rule",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "status",
	 .field_gui_name = "Status",
	 .values = nat_virtualser_set_status_values,
	 .tot_values =
	 sizeof(nat_virtualser_set_status_values) / sizeof(struct value_set)
	 },
};

struct cmd_entry nat_virtualser_set_cmd = {
	.fields = nat_virtualser_set_cmd_fields,
	.tot_fields =
	    sizeof(nat_virtualser_set_cmd_fields) / sizeof(struct cmd_field),
	.help =
	    "This command allows user to configure NAT Virtual Server parameters",
	.post_url = "/goform/ifx_set_nat_virtualser",
	.custom_processing_post = nat_virtualser_set_cmd_post,
	.get_url = "nat_virtualser.cli",
};

struct menu_entry nat_virtualser_page_entries[] = {
	{
	 .entry_help =
	 "This is the NAT Virtual Server configuration show entry",
	 .cli_name = "Show",
	 .cli_url = "nat_virtualser.cli",
	 },
	{
	 .entry_help = "This is the NAT Virtual Server configuration set entry",
	 .cli_name = "Set",
	 .cmd = &nat_virtualser_set_cmd}
};

struct menu_page nat_virtualser_page = {
	.entries = nat_virtualser_page_entries,
	.tot_entries =
	    sizeof(nat_virtualser_page_entries) / sizeof(struct menu_entry),
	.page_help =
	    "This page allows show and set configuration for NAT Virtual Server",
	.cli_title = "virtualserver",
};

struct value_set nat_portmap_config_status_values[] = {
	{"disable", "0"},
	{"enable", "1"}
};

struct value_set nat_portmap_config_index_values[] = {
	{"Rule1", "1"},
	{"Rule2", "2"},
	{"Rule3", "3"},
	{"Rule4", "4"},
	{"Rule5", "5"}
};

struct cmd_field nat_portmap_config_cmd_field[] = {
	{
	 .field_name = "index",
	 .field_help =
	 "This field represents the index [1-5] of the current clone",
	 .data_type = INT,
	 .field_type = STATIC,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "index",
	 .field_gui_name = "Index",
	 .tot_values =
	 sizeof(nat_portmap_config_index_values) / sizeof(struct value_set),
	 .values = nat_portmap_config_index_values},
	{
	 .field_name = "CLONE_IP",
	 .field_help = "This field represent clone ip address",
	 .data_type = IPADDR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "cloneip",
	 .field_gui_name = "Clone IP Address"},
	{
	 .field_name = "CLONE_PORTS",
	 .field_help = "This field represent clone port",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "cloneport",
	 .field_gui_name = "Mapping Port"},
	{
	 .field_name = "CLONE_ENABLE",
	 .field_help = "This field represent enabling of the current clone",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "status",
	 .field_gui_name = "Status",
	 .values = nat_portmap_config_status_values,
	 .tot_values =
	 sizeof(nat_portmap_config_status_values) / sizeof(struct value_set)
	 }
};

struct cmd_entry nat_portmap_config_cmd = {
	.fields = nat_portmap_config_cmd_field,
	.tot_fields =
	    sizeof(nat_portmap_config_cmd_field) / sizeof(struct cmd_field),
	.help = "This command configures nat portmap settings",
	.post_url = "/goform/ifx_set_nat_portmap",
	.custom_processing_post = nat_portmap_config_cmd_post,
	.get_url = "nat_portmap.cli"
};

struct menu_entry nat_portmap_page_entries[] = {
	{
	 .entry_help = "This is portmap show entry",
	 .cli_name = "Show",
	 .cli_url = "nat_portmap.cli"},
	{
	 .entry_help = "This is portmap config entry",
	 .cli_name = "Set",
	 .cmd = &nat_portmap_config_cmd}
};

struct menu_page nat_portmap_page = {
	.entries = nat_portmap_page_entries,
	.tot_entries =
	    sizeof(nat_portmap_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is nat portmap page",
	.cli_title = "portmap",
	.gui_title = "PortMap",
	.fpos = 1
};

struct value_set nat_setting_set_cmd_fields_values[] = {
	{"disable", "0"},
	{"enable", "1"}
};

struct cmd_field nat_setting_set_cmd_fields[] = {
	{
	 .field_name = "NATStatus",
	 .field_help = "This is the status of the NAT",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "status",
	 .field_gui_name = "Status",
	 .values = nat_setting_set_cmd_fields_values,
	 .tot_values =
	 sizeof(nat_setting_set_cmd_fields_values) / sizeof(struct value_set)
	 }
};

struct cmd_entry nat_setting_set_cmd = {
	.fields = nat_setting_set_cmd_fields,
	.tot_fields =
	    sizeof(nat_setting_set_cmd_fields) / sizeof(struct cmd_field),
	.help = "This command allows user to change the configuration of NAT",
	.post_url = "/goform/ifx_set_nat_main"
};

struct menu_entry nat_setting_page_entries[] = {
	{
	 .entry_help = "This entry allows to show the current NAT configuation",
	 .cli_name = "Show",
	 .cli_url = "nat_main.cli"},
	{
	 .entry_help =
	 "This entry allows user to set the current configuration of NAT",
	 .cli_name = "Set",
	 .cmd = &nat_setting_set_cmd,
	 }
};

struct menu_page nat_setting_page = {
	.entries = nat_setting_page_entries,
	.tot_entries =
	    sizeof(nat_setting_page_entries) / sizeof(struct menu_entry),
	.page_help = "This page show and set the NAT configuration",
	.cli_title = "nat configuration",
	.fpos = 1
};

struct menu_entry nat_page_entries[] = {
	{
	 .next_page = &nat_setting_page,
	 .entry_help = "This is nat configuration entry",
	 .cli_name = "configuration",
	 .gui_name = "NAT Settings",
	 .gui_url = "nat_main.asp"},
#ifndef CONFIG_FEATURE_SEMINDIA
#if 0
	{
	 .next_page = &nat_portmap_page,
	 .entry_help = "This is nat portmap entry",
	 .cli_name = "portmap",
	 .gui_name = "PortMap",
	 .gui_url = "nat_portmap.asp"},
#endif
#endif				//CONFIG_FEATURE_SEMINDIA
	{
	 .next_page = &nat_virtualser_page,
	 .entry_help = "This is nat virtual server entry",
	 .cli_name = "virtualser",
	 .gui_name = "Virtual Server",
	 .gui_url = "nat_virtualser.asp"},
	{
	 .next_page = &nat_dmz_page,
	 .entry_help = "This is nat dmz entry",
	 .cli_name = "dmz",
	 .gui_name = "DMZ",
	 .gui_url = "firewall_dmz.asp"}
};

struct menu_page nat_page = {
	.entries = nat_page_entries,
	.tot_entries = sizeof(nat_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is nat page",
	.cli_title = "nat",
	.gui_title = "NAT"
};
