
/* ============================================================================
 * Copyright (C) 2005 -Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 *============================================================================
 *
 * This document contains proprietary information belonging to Infineon 
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 * 
 * ============================================================================
 */

/* ===========================================================================
 *
 * File Name:   adsl_menu_func.c
 * Author :     Nirav Salot
 * Date: 		April, 2005
 *
 * ===========================================================================
 *
 * Project: Amazon
 *
 * ===========================================================================
 * Contents: This file implements ADSL menu related specific functions.
 *  
 * ===========================================================================
 * References: 
 *
 */
#include <stdio.h>

#include "common.h"

int system_log_clear_post_flag(struct cmd_entry *cmd, char *poststr)
{
	strcat(poststr, "securityclear=Clear");
	return 0;
}

int system_restore_post_flag(struct cmd_entry *cmd, char *poststr)
{
	strcat(poststr, "factory=1");
	return 0;
}

int system_log_custom_valid(struct cmd_entry *cmd, char *errstr)
{
	char *mode = NULL;
	char *sIP = NULL;
	char *sPort = NULL;
	//char buf[100];

	mode = get_field_entry(cmd, "log_mode")->cur_value;
	sIP = get_field_entry(cmd, "rlog_ip")->cur_value;
	sPort = get_field_entry(cmd, "rlog_port")->cur_value;

	/* mode = 2 is SYSLOG_REMOTE, mode = 2 is SYSLOG_BOTH_LOCAL_REMOTE */
	if (!strcmp(mode, "SYSLOG_REMOTE")
	    || !strcmp(mode, "SYSLOG_BOTH_LOCAL_REMOTE")) {
		if (sIP == NULL) {
			sprintf(errstr, "Please enter remote ip address.\n");
			return -1;
		}
		if (strlen(sIP) == 0) {
			sprintf(errstr, "Please enter remote ip address.\n");
			return -1;
		}
		if (sPort == NULL) {
			sprintf(errstr, "Please enter remote port number.\n");
			return -1;
		}
		if (strlen(sPort) == 0) {
			sprintf(errstr, "Please enter remote port number.\n");
			return -1;
		}
		if (atoi(sPort) <= 0 || atoi(sPort) > 32767) {	/* TODO : confirm */
			sprintf(errstr,
				"Please enter valid remote port number. Should be in the range [1-32767]\n");
			return -1;
		}
	}
	return 0;
}

int system_log_view_post_flag(struct cmd_entry *cmd, char *poststr)
{
	strcat(poststr, "show_syslog=Loading..");
	return 0;
}

int system_log_set_post_flag(struct cmd_entry *cmd, char *poststr)
{
	strcat(poststr, "logAction=Please wait..");
	return 0;
}
