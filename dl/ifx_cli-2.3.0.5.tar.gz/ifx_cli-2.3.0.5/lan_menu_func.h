
int lan_dhcp_server_set_post(struct cmd_entry *cmd, char *poststr);
int dhcp_ipaddrs_validate(struct cmd_entry *cmd, char *poststr);
int lan_setting_config_validate(struct cmd_entry *cmd, char *poststr);
