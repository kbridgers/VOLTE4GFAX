/* ============================================================================
 * Copyright (C) 2005 -Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 *============================================================================
 *
 * This document contains proprietary information belonging to Infineon 
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 * 
 * ============================================================================
 */

/* ===========================================================================
 *
 * File Name:   adsl_menu_func.c
 * Author :     Nirav Salot
 * Date: 		April, 2005
 *
 * ===========================================================================
 *
 * Project: Amazon
 *
 * ===========================================================================
 * Contents: This file implements ADSL menu related specific functions.
 *  
 * ===========================================================================
 * References: 
 *
 */
#include<stdio.h>
#include "common.h"

int validate_key(struct cmd_entry *cmd, char errstr[])
{
	char *key1 = NULL;
	char *key2 = NULL;
	char *key3 = NULL;
	char *key4 = NULL;
	int key = 0;
	int keylen = 0;

	if (get_field_entry(cmd, "EncryType") == NULL
	    || get_field_entry(cmd, "KeyUsed") == NULL
	    || get_field_entry(cmd, "EncryType")->cur_value == NULL
	    || get_field_entry(cmd, "KeyUsed")->cur_value == NULL) {
		strcpy(errstr, "Error : Fields not Found !\n");
		return 1;
	}

	if (!strcmp(get_field_entry(cmd, "EncryType")->cur_value, "none"))
		return 0;
	if (!strcmp(get_field_entry(cmd, "KeyUsed")->cur_value, "none")) {
		strcpy(errstr, "Error : ActiveKey not selected !\n");
		return 1;
	}

	if (!strcmp(get_field_entry(cmd, "EncryType")->cur_value, "wep64"))
		keylen = 10;
	else if (!strcmp
		 (get_field_entry(cmd, "EncryType")->cur_value, "wep128"))
		keylen = 26;
	else
		return 0;

	if (!strcmp(get_field_entry(cmd, "KeyUsed")->cur_value, "key1"))
		key = 1;
	if (!strcmp(get_field_entry(cmd, "KeyUsed")->cur_value, "key2"))
		key = 2;
	if (!strcmp(get_field_entry(cmd, "KeyUsed")->cur_value, "key3"))
		key = 3;
	if (!strcmp(get_field_entry(cmd, "KeyUsed")->cur_value, "key4"))
		key = 4;

	key1 = get_field_entry(cmd, "Key1")->cur_value;
	key2 = get_field_entry(cmd, "Key2")->cur_value;
	key3 = get_field_entry(cmd, "Key3")->cur_value;
	key4 = get_field_entry(cmd, "Key4")->cur_value;

	switch (key) {
	case 1:
		if (key1 == NULL) {
			{
				sprintf(errstr,
					"Error : length of Activekey 1 should be %d !\n",
					keylen);
				return 1;
			}
		} else if (strlen(key1) < keylen) {
			sprintf(errstr,
				"Error : length of Activekey 1 should be %d !\n",
				keylen);
			return 1;
		}
		break;
	case 2:
		if (key2 == NULL) {
			{
				sprintf(errstr,
					"Error : length of Activekey 2 should be %d !\n",
					keylen);
				return 1;
			}
		} else if (strlen(key2) < keylen) {
			sprintf(errstr,
				"Error : length of Activekey 2 should be %d !\n",
				keylen);
			return 1;
		}
		break;
	case 3:
		if (key3 == NULL) {
			{
				sprintf(errstr,
					"Error : length of Activekey 3 should be %d !\n",
					keylen);
				return 1;
			}
		} else if (strlen(key3) < keylen) {
			sprintf(errstr,
				"Error : length of Activekey 3 should be %d !\n",
				keylen);
			return 1;
		}
		break;
	case 4:
		if (key4 == NULL) {
			{
				sprintf(errstr,
					"Error : length of Activekey 4 should be %d !\n",
					keylen);
				return 1;
			}
		} else if (strlen(key4) < keylen) {
			sprintf(errstr,
				"Error : length of Activekey 4 should be %d !\n",
				keylen);
			return 1;
		}
	}

	return 0;
}
