#include "lan_menu_func.h"

struct value_set lan_setting_config_cmd_dhcp_values[] = {
	{.display_value = "disable",.submit_value = "OFF"},
	{.display_value = "enable",.submit_value = "ON"}
};

struct value_set lan_dhcp_relay_set_interface_values[] = {
	{.display_value = "WAN1",.submit_value = "WAN1"},
	{.display_value = "WAN2",.submit_value = "WAN2"},
	{.display_value = "WAN3",.submit_value = "WAN3"},
	{.display_value = "WAN4",.submit_value = "WAN4"},
	{.display_value = "WAN5",.submit_value = "WAN5"},
	{.display_value = "WAN6",.submit_value = "WAN6"},
	{.display_value = "WAN7",.submit_value = "WAN7"},
	{.display_value = "WAN8",.submit_value = "WAN8"},
	{.display_value = "WAN9",.submit_value = "WAN9"},
	{.display_value = "WAN10",.submit_value = "WAN10"},
	{.display_value = "WAN11",.submit_value = "WAN11"},
	{.display_value = "WAN12",.submit_value = "WAN12"},
	{.display_value = "WAN13",.submit_value = "WAN13"},
	{.display_value = "WAN14",.submit_value = "WAN14"},
	{.display_value = "WAN15",.submit_value = "WAN15"}
};

struct cmd_field lan_dhcp_relay_set_cmd_fields[] = {
	{
	 .field_name = "dhcp_relay_if",
	 .field_help = "This is the interface for relay agent",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "if",
	 .field_gui_name = "Interface",
	 .values = lan_dhcp_relay_set_interface_values,
	 .tot_values =
	 sizeof(lan_dhcp_relay_set_interface_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "dhcp_relay_server",
	 .field_help = "This is the ipaddr of the dhcp server",
	 .data_type = IPADDR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "serverip",
	 .field_gui_name = "Server IP Address"},
	{
	 .field_name = "lan_dhcp_mode",
	 .field_help = NULL,
	 .data_type = STR,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .cur_value = "relay"}
};

struct value_set lan_dhcp_server_set_lease_values[] = {
	{.display_value = "half_hour",.submit_value = "0"},
	{.display_value = "one_hour",.submit_value = "1"},
	{.display_value = "two_hours",.submit_value = "2"},
	{.display_value = "half_day",.submit_value = "3"},
	{.display_value = "one_day",.submit_value = "4"},
	{.display_value = "two_days",.submit_value = "5"},
	{.display_value = "one_week",.submit_value = "6"},
	{.display_value = "two_weeks",.submit_value = "7"}
};

struct cmd_field lan_dhcp_server_set_cmd_fields[] = {
	{
	 .field_name = "DhcpsStartIP",
	 .field_help = "DHCP server ip pool start address",
	 .data_type = IPADDR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "startip",
	 .field_gui_name = "Start IP Address",
	 },
	{
	 .field_name = "DhcpsEndIP",
	 .field_help = "DHCP server ip pool end address",
	 .data_type = IPADDR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "endip",
	 .field_gui_name = "End IP Address",
	 },
	{
	 .field_name = "LeaseTime",
	 .field_help = "DHCP server lease time",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "lease",
	 .field_gui_name = "Lease Time",
	 .values = lan_dhcp_server_set_lease_values,
	 .tot_values =
	 sizeof(lan_dhcp_server_set_lease_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "DN",
	 .field_help = "DHCP server Local Domain name",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_FALSE,
	 .field_display_name = "domainname",
	 .field_gui_name = "Domain Name"},
	{
	 .field_name = "lan_dhcp_mode",
	 .field_help = NULL,
	 .data_type = STR,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .cur_value = "server"}
};

struct cmd_entry lan_dhcp_server_set_cmd = {
	.fields = lan_dhcp_server_set_cmd_fields,
	.tot_fields =
	    sizeof(lan_dhcp_server_set_cmd_fields) / sizeof(struct cmd_field),
	.help = "Command to set DHCP server configuration",
	.post_url = "/goform/ifx_set_lan_dhcps",
	.custom_processing_post = lan_dhcp_server_set_post,
	.custom_validation = dhcp_ipaddrs_validate,
	.get_url = "lan.cli"
};

struct cmd_entry lan_dhcp_relay_set_cmd = {
	.fields = lan_dhcp_relay_set_cmd_fields,
	.tot_fields =
	    sizeof(lan_dhcp_relay_set_cmd_fields) / sizeof(struct cmd_field),
	.help = "Command to set DHCP relay configuration",
	.post_url = "/goform/ifx_set_lan_dhcps",
	.get_url = "lan.cli"
};

struct menu_entry lan_dhcp_server_entries[] = {
	{
	 .entry_help = "Command to see DHCP server current configuration",
	 .cli_name = "Show",
	 .cli_url = "lan_dhcp_server.cli",
	 .cmd = NULL},
	{
	 .entry_help = "Command to set DHCP server configuration",
	 .cli_name = "Set",
	 .cli_url = NULL,
	 .cmd = &lan_dhcp_server_set_cmd}
};

struct menu_entry lan_dhcp_relay_entries[] = {
	{
	 .entry_help = "Command to see DHCP relay current configuration",
	 .cli_name = "Show",
	 .cli_url = "lan_dhcp_relay.cli",
	 .cmd = NULL},
	{
	 .entry_help = "Command to set DHCP relay configuration",
	 .cli_name = "Set",
	 .cli_url = NULL,
	 .cmd = &lan_dhcp_relay_set_cmd}
};

struct menu_page lan_dhcp_server_page = {
	.entries = lan_dhcp_server_entries,
	.tot_entries =
	    sizeof(lan_dhcp_server_entries) / sizeof(struct menu_entry),
	.page_help = "This is DHCP server configuration page",
	.cli_title = "DHCP Server",
	.fpos = 0
};

struct menu_page lan_dhcp_relay_page = {
	.entries = lan_dhcp_relay_entries,
	.tot_entries =
	    sizeof(lan_dhcp_relay_entries) / sizeof(struct menu_entry),
	.page_help = "This is DHCP relay configuration page",
	.cli_title = "DHCP Relay",
	.fpos = 0
};

struct cmd_field lan_dhcp_disable_cmd_fields[] = {
	{
	 .field_name = "lan_dhcp_mode",
	 .field_help = NULL,
	 .data_type = STR,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .cur_value = "disable"}
};

struct cmd_entry lan_dhcp_disable_cmd = {
	.fields = lan_dhcp_disable_cmd_fields,
	.tot_fields =
	    sizeof(lan_dhcp_disable_cmd_fields) / sizeof(struct cmd_field),
	.help = "This field allows to disable DHCP",
	.post_url = "/goform/ifx_set_lan_dhcps",
	.get_url = "lan.cli"
};

struct menu_entry lan_dhcp_page_entries[] = {
	{
	 .next_page = &lan_dhcp_server_page,
	 .entry_help = "DHCP server configuration",
	 .cli_name = "Server",
	 .cli_url = NULL,
	 },
	{
	 .next_page = &lan_dhcp_relay_page,
	 .entry_help = "DHCP relay configuration",
	 .cli_name = "Relay",
	 .cli_url = NULL,
	 },
	{
	 .entry_help = "DHCP disable",
	 .cli_name = "Disable",
	 .cmd = &lan_dhcp_disable_cmd}
};

struct menu_page lan_dhcp_page = {
	.entries = lan_dhcp_page_entries,
	.tot_entries =
	    sizeof(lan_dhcp_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is lan dhcp page",
	.cli_title = "Dhcp",
	.gui_title = "DHCP"
};

struct value_set lan_setting_config_wireless_values[] = {
	{.display_value = "disable",.submit_value = "0"},
	{.display_value = "enable",.submit_value = "1"}
};

struct value_set lan_config_stp_bridge_cmd_values[] = {
	{.display_value = "disable",.submit_value = "0"},
	{.display_value = "enable",.submit_value = "1"}
};

struct cmd_field lan_config_stp_bridge_cmd_fields[] = {
	{
	 .field_name = "BridgeSetting",
	 .field_help =
	 "This field represents if the amazon as a bridge is enabled or disabled",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "stpbridge",
	 .field_gui_name = "STP Bridge",
	 .values = lan_config_stp_bridge_cmd_values,
	 .tot_values =
	 sizeof(lan_config_stp_bridge_cmd_values) / sizeof(struct value_set)
	 }
};

struct cmd_entry lan_config_stp_bridge_cmd = {
	.fields = lan_config_stp_bridge_cmd_fields,
	.tot_fields =
	    sizeof(lan_config_stp_bridge_cmd_fields) / sizeof(struct cmd_field),
	.help = "This command configures lan stp settings",
	.post_url = "/goform/ifx_set_bridge_settings"
};

struct menu_entry lan_stp_bridge_entries[] = {
	{
	 .entry_help = "Show Page",
	 .cli_name = "Show",
	 .cli_url = "bridge_settings.cli"}
	, {
	   .entry_help = "Configuring Amazon as bridge",
	   .cli_name = "Config",
	   .cmd = &lan_config_stp_bridge_cmd}
};

struct menu_page lan_stp_bridge_page = {
	.entries = lan_stp_bridge_entries,
	.tot_entries =
	    sizeof(lan_stp_bridge_entries) / sizeof(struct menu_entry),
	.page_help = " ",
	.cli_title = "Stpbridge",
	.gui_title = "STP Bridge"
};

struct value_set dhcp_mode_values[] = {
	{
	 "Disable",
	 "disable"},
	{
	 "Server",
	 "server"},
	{
	 "relay_agent",
	 "relay"}
};

struct cmd_field lan_setting_config_cmd_fields[] = {
	{
	 .field_name = "sysip",
	 .field_help = "This field represent the ip address",
	 .data_type = IPADDR,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "ipaddr",
	 .field_gui_name = "IP Address",
	 .fprocessing_post = ip_nm_gw_processing},
	{
	 .field_name = "sysmask",
	 .field_help = "This field represent the net mask",
	 .data_type = NETMASK,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "netmask",
	 .field_gui_name = "Netmask",
	 .fprocessing_post = ip_nm_gw_processing}
/* santosh: functionality to be removed in this pkg 
	{
		.field_name="wlan_enable",
		.field_help="This field represent the wireless mode",
		.data_type=STR ,.field_type=STATIC ,.mandatory=IFX_FALSE,
		.field_display_name="wireless",
		.field_gui_name="Wireless",
		.values=lan_setting_config_wireless_values,
		.tot_values=sizeof(lan_setting_config_wireless_values)/sizeof(struct value_set)
	}
*/
};

struct cmd_entry lan_setting_config_cmd = {
	.fields = lan_setting_config_cmd_fields,
	.tot_fields =
	    sizeof(lan_setting_config_cmd_fields) / sizeof(struct cmd_field),
	.help = "This command configures lan settings",
	.post_url = "/goform/ifx_set_lan_dhcps",
	.custom_validation = lan_setting_config_validate,
	.get_url = "lan.cli"
};

struct menu_entry lan_settings_page_entries[] = {
	{
	 .entry_help = "This is show_lan_settings entry",
	 .cli_name = "Show",
	 .cli_url = "lan.cli"},
	{
	 .entry_help = "This is configure lan_settings entry",
	 .cli_name = "Set",
	 .cmd = &lan_setting_config_cmd}
};

struct menu_page lan_settings_page = {
	.entries = lan_settings_page_entries,
	.tot_entries =
	    sizeof(lan_settings_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is LAN Settings page",
	.cli_title = "Configure",
	.gui_title = "LAN Settings"
};

struct menu_entry lan_page_entries[] = {
	{
	 .next_page = &lan_settings_page,
	 .entry_help = "This is lan setting entry",
	 .cli_name = "Set",
	 .gui_name = "LAN ipaddress",
	 .gui_url = "lan.asp",
	 NULL},
/* santosh: functionality to be removed in this pkg 
	{
		.next_page=&lan_stp_bridge_page,
		.entry_help="This is Amazon Bridge entry",
		.cli_name="stpbridge",
		.gui_name="STP Bridge",
		.gui_url="bridge_settings.asp",
		NULL
	},
*/
	{
	 .next_page = &lan_dhcp_page,
	 .entry_help = "This is lan dhcp entry",
	 .cli_name = "dhcp",
	 .gui_name = "DHCP"},
	{
	 .entry_help = "This is dhcp clients show entry",
	 .cli_name = "DHCP_Clients",
	 .cli_url = "lan_dhcp_clients.cli"}
};

struct menu_page lan_page = {
	.entries = lan_page_entries,
	.tot_entries = sizeof(lan_page_entries) / sizeof(struct menu_entry),
	.page_help = "The LAN Page",
	.cli_title = "LAN Page",
	.gui_title = "LAN Page",
	.fpos = 1
};
