#include "vlan_menu_func.h"

struct value_set vlan_portmap_tag_values[] = {
	{.display_value = "enable",.submit_value = "1"},
	{.display_value = "disable",.submit_value = "0"}
};

struct value_set vlan_portmap_cmd_index_values[] = {
	{"Rule1", "1"},
	{"Rule2", "2"},
	{"Rule3", "3"},
	{"Rule4", "4"},
	{"Rule5", "5"}
};

struct cmd_field vlan_portmap_cmd_field[] = {
	{
	 .field_name = "index",
	 .field_help =
	 "This field represents the index [1-5] of the current vlan rule",
	 .data_type = INT,
	 .field_type = STATIC,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "index",
	 .field_gui_name = "Index",
	 .tot_values =
	 sizeof(vlan_portmap_cmd_index_values) / sizeof(struct value_set),
	 .values = vlan_portmap_cmd_index_values},
	{
	 .field_name = "PORT_PVID",
	 .field_help = "This field represents the id of the vlan",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "vlanid",
	 .field_gui_name = "Port VLAN ID"},
	{
	 .field_name = "PORT_TAG",
	 .field_help = "This field represents the status of the current rule",
	 .data_type = STR,
	 .field_type = STATIC,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "status",
	 .field_gui_name = "Status",
	 .values = vlan_portmap_tag_values,
	 .tot_values =
	 sizeof(vlan_portmap_tag_values) / sizeof(struct value_set)
	 }
};

struct cmd_entry vlan_portmap_cmd = {
	.fields = vlan_portmap_cmd_field,
	.tot_fields = sizeof(vlan_portmap_cmd_field) / sizeof(struct cmd_field),
	.help = "configures portmap settings",
	.post_url = "/goform/ifx_set_vlan_portmap",
	.custom_processing_post = vlan_portmap_cmd_post,
	.get_url = "vlan_portmap.cli"
};

struct menu_entry vlan_portmap_page_entries[] = {
	{
	 .cli_name = "Show",.cli_url = "vlan_portmap.cli",
	 .entry_help = "shows vlan portmap settings"},
	{
	 .cli_name = "Set",.cmd = &vlan_portmap_cmd,
	 .entry_help = "portmap command"}
};

struct menu_page vlan_portmap_page = {
	.entries = vlan_portmap_page_entries,
	.tot_entries =
	    sizeof(vlan_portmap_page_entries) / sizeof(struct menu_entry),
	.cli_title = "portmap",.gui_title = "Portmap",
	.page_help = "portmap entry"
};

struct value_set vlan_setting_cmd_values[] = {
	{.display_value = "enable",.submit_value = "1"},
	{.display_value = "disable",.submit_value = "0"}
};

struct cmd_field vlan_setting_cmd_field[] = {
	{
	 .field_name = "VLANStatus",
	 .field_help = "represent the status",
	 .data_type = STR,.field_type = STATIC,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "status",
	 .field_gui_name = "Status",
	 .values = vlan_setting_cmd_values,
	 .tot_values =
	 sizeof(vlan_setting_cmd_values) / sizeof(struct value_set)
	 }
};

struct cmd_entry vlan_setting_cmd = {
	.fields = vlan_setting_cmd_field,
	.tot_fields = sizeof(vlan_setting_cmd_field) / sizeof(struct cmd_field),
	.help = "configures vlan settings",
	.post_url = "/goform/ifx_set_vlan_main"
};

struct menu_entry vlan_setting_entries[] = {
	{
	 .cli_name = "Show",.cli_url = "vlan_main.cli",
	 .entry_help = "shows vlan main settings"},
	{
	 .cli_name = "Set",.cmd = &vlan_setting_cmd,
	 .entry_help = "settings command"}
};

struct menu_page vlan_settings_page = {
	.entries = vlan_setting_entries,
	.tot_entries = sizeof(vlan_setting_entries) / sizeof(struct menu_entry),
	.page_help = "vlan settings page",
	.cli_title = "settings",.gui_title = "settings",
};

struct menu_entry vlan_page_entries[] = {
	{
	 .next_page = &vlan_settings_page,
	 .entry_help = "vlan settings entry",
	 .cli_name = "Settings",.gui_name = "Settings",
	 .gui_url = "vlan_main.asp"},
	{
	 .next_page = &vlan_portmap_page,
	 .entry_help = "vlan portmap entry",
	 .cli_name = "Portmap",.gui_name = "Portmap",
	 .gui_url = "vlan_portmap.asp"}
};

struct menu_page vlan_page = {
	.entries = vlan_page_entries,
	.tot_entries = sizeof(vlan_page_entries) / sizeof(struct menu_entry),
	.cli_title = "vlan",.gui_title = "VLAN",
	.page_help = "vlan page"
};
