#ifndef __FW_MENU_H
#define __FW_MENU_H
#include "firewall_menu_func.h"

struct value_set firewall_settings_config_values[] = {
	{.display_value = "disable",.submit_value = "0"},
	{.display_value = "enable",.submit_value = "1"}
};

struct cmd_field firewall_settings_set_cmd_field[] = {
	{
	 .field_name = "FirewallStatus",
	 .field_help = "This field Enables or Disables the Firewall Status",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "status",
	 .field_gui_name = "Firewall Status",
	 .values = firewall_settings_config_values,
	 .tot_values =
	 sizeof(firewall_settings_config_values) / sizeof(struct value_set)
	 }
};

struct cmd_entry firewall_settings_set_cmd = {
	.fields = firewall_settings_set_cmd_field,
	.tot_fields =
	    sizeof(firewall_settings_set_cmd_field) / sizeof(struct cmd_field),
	.help = "This command configures Firewall Settings",
	.post_url = "/goform/ifx_set_firewall_main"
};

struct menu_entry firewall_settings_entries[] = {
	{
	 .entry_help = "Shows the firewall status settings",
	 .cli_name = "Show",.cli_url = "firewall_main.cli"},
	{
	 .entry_help = "Enable or Disable Firewall Settings",
	 .cli_name = "Set",
	 .cmd = &firewall_settings_set_cmd}
};

struct menu_page firewall_settings_page = {
	.entries = firewall_settings_entries,
	.tot_entries =
	    sizeof(firewall_settings_entries) / sizeof(struct menu_entry),
	.page_help = "Firewall Status Settings page",
	.cli_title = "firewall status",.gui_title = "Firewall Settings"
};

struct value_set firewall_dos_config_values[] = {
	{.display_value = "disable",.submit_value = "0"},
	{.display_value = "enable",.submit_value = "1"}
};

struct cmd_field firewall_dos_set_cmd_field[] = {
	{
	 .field_name = "DoSProtect",
	 .field_help =
	 "This field represent the status of hacker attack protect",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "hackerprotect",
	 .field_gui_name = "Hacker Attack",
	 .values = firewall_dos_config_values,
	 .tot_values =
	 sizeof(firewall_dos_config_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "C1",
	 .field_help =
	 "This field represent the status of discard ping forward",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "pingfwd",
	 .field_gui_name = "PING Forward",
	 .values = firewall_dos_config_values,
	 .tot_values =
	 sizeof(firewall_dos_config_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "PingGW",
	 .field_help =
	 "This field represent the status of discard ping to gateway",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "pinggw",
	 .field_gui_name = "PING Gateway",
	 .values = firewall_dos_config_values,
	 .tot_values =
	 sizeof(firewall_dos_config_values) / sizeof(struct value_set)
	 }
};

struct cmd_entry firewall_dos_set_cmd = {
	.fields = firewall_dos_set_cmd_field,
	.tot_fields =
	    sizeof(firewall_dos_set_cmd_field) / sizeof(struct cmd_field),
	.help = "This command configures DoS Options",
	.post_url = "/goform/ifx_set_firewall_disablewan",
	.get_url = "firewall_disablewan.cli"
};

struct menu_entry firewall_dos_entries[] = {
	{
	 .entry_help = "Displays the configured DoS Options",
	 .cli_name = "Show",.cli_url = "firewall_disablewan.cli"},
	{
	 .entry_help = "Configure DoS Options",
	 .cli_name = "Set",.cmd = &firewall_dos_set_cmd}
};

struct menu_page firewall_dos_page = {
	.entries = firewall_dos_entries,
	.tot_entries = sizeof(firewall_dos_entries) / sizeof(struct menu_entry),
	.page_help = "Firewall DoS Settings page",
	.cli_title = "Firewall DoS",.gui_title = "Firewall DoS Settings"
};

struct value_set firewall_pktfilter_add_status_values[] = {
	{.display_value = "disable",.submit_value = "0"},
	{.display_value = "enable",.submit_value = "1"}
};

struct value_set firewall_pktfilter_add_ip_values[] = {
	{.display_value = "all",.submit_value = "*"},
	{.display_value = "single",.submit_value = "1"},
	{.display_value = "subnet",.submit_value = "2"}
};

struct value_set firewall_pktfilter_add_protocol_values[] = {
	{.display_value = "tcp",.submit_value = "6"},
	{.display_value = "udp",.submit_value = "17"},
	{.display_value = "icmp",.submit_value = "1"},
	{.display_value = "ah",.submit_value = "51"},
	{.display_value = "esp",.submit_value = "50"},
	{.display_value = "all",.submit_value = "0"}
};

struct cmd_field firewall_packetfilter_add_cmd_field[] = {
	{
	 .field_name = "PF_TYPE_ADD",
	 .field_help = "This field represents the Packet filter protocol type",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "proto",
	 .field_gui_name = "Protocol",
	 .values = firewall_pktfilter_add_protocol_values,
	 .tot_values =
	 sizeof(firewall_pktfilter_add_protocol_values) /
	 sizeof(struct value_set)
	 },
	{
	 .field_name = "PF_IP_SRC_TYPE_ADD",
	 .field_help = "This field represents the Source IP Type",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "srctype",
	 .field_gui_name = "Source Type",
	 .values = firewall_pktfilter_add_ip_values,
	 .tot_values =
	 sizeof(firewall_pktfilter_add_ip_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "PF_IP_SRC_IP_ADD",
	 .field_help = "This field represents the Source IP Address",
	 .data_type = IPADDR,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "srcip",
	 .field_gui_name = "Source IP Address"},
	{
	 .field_name = "PF_IP_SRC_MASK_ADD",
	 .field_help = "This field represents the Source Subnet Mask",
	 .data_type = IPADDR,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "srcmask",
	 .field_gui_name = "Netmask"},
	{
	 .field_name = "PF_PORT_SRC_START_ADD",
	 .field_help = "This field represents the Source starting port number",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "srcport_start",
	 .field_gui_name = "Source Start Port"},
	{
	 .field_name = "PF_PORT_SRC_END_ADD",
	 .field_help = "This field represent the Source ending port number",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "srcport_end",
	 .field_gui_name = "Source End Port"},
	{
	 .field_name = "PF_IP_DST_TYPE_ADD",
	 .field_help = "This field represents the Destination IP Type",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "dsttype",
	 .field_gui_name = "DEstination Type",
	 .values = firewall_pktfilter_add_ip_values,
	 .tot_values =
	 sizeof(firewall_pktfilter_add_ip_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "PF_IP_DST_IP_ADD",
	 .field_help = "This field represents the Destination IP Address",
	 .data_type = IPADDR,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "dstip",
	 .field_gui_name = "Destination IP Address"},
	{
	 .field_name = "PF_IP_DST_MASK_ADD",
	 .field_help = "This field represents the Destination Subnet Mask",
	 .data_type = IPADDR,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "dstmask",
	 .field_gui_name = "Netmask"},
	{
	 .field_name = "PF_PORT_DST_START_ADD",
	 .field_help =
	 "This field represents the Destination starting port number",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "dstport_start",
	 .field_gui_name = "Destination Start Port"},
	{
	 .field_name = "PF_PORT_DST_END_ADD",
	 .field_help =
	 "This field represents the Destination ending port number",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_FALSE,
	 .field_display_name = "dstport_end",
	 .field_gui_name = "Destination End Port"},
	{
	 .field_name = "PF_F_ADD",
	 .field_help = "This field represents the state of this filter rule",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_FALSE,
	 .field_display_name = "status",
	 .field_gui_name = "Enable",
	 .values = firewall_pktfilter_add_status_values,
	 .tot_values =
	 sizeof(firewall_pktfilter_add_status_values) / sizeof(struct value_set)
	 }
};

struct cmd_field firewall_packetfilter_del_cmd_field[] = {
	{
	 .field_name = "index",
	 .field_help = "This field represents the rule index to be deleted",
	 .data_type = INT,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "index",
	 .field_gui_name = "Index"},
	{
	 .field_name = "delflag",
	 .field_help = NULL,
	 .data_type = STR,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .field_display_name = NULL,
	 .cur_value = "1"}
};

struct cmd_entry firewall_packetfilter_add_cmd = {
	.fields = firewall_packetfilter_add_cmd_field,
	.tot_fields =
	    sizeof(firewall_packetfilter_add_cmd_field) /
	    sizeof(struct cmd_field),
	.help = "This command adds a Packetfilter Rule",
	.post_url = "/goform/ifx_set_firewall_packetfilter_add",
	.custom_validation = packetfilter_add_valid,
	.get_url = "firewall_packetfilter.cli"
};

struct cmd_entry firewall_packetfilter_del_cmd = {
	.fields = firewall_packetfilter_del_cmd_field,
	.tot_fields =
	    sizeof(firewall_packetfilter_del_cmd_field) /
	    sizeof(struct cmd_field),
	.help = "This command deletes a Packetfilter Rule",
	.post_url = "/goform/ifx_set_firewall_packetfilter",
	.custom_processing_post = firewall_packetfilter_del_post,
	.get_url = "firewall_packetfilter.cli"
};

struct value_set firewall_packetfilter_set_pfstatus_values[] = {
	{.display_value = "disable",.submit_value = "0"},
	{.display_value = "enable",.submit_value = "1"}
};

struct cmd_field firewall_packetfilter_set_cmd_field[] = {
	{
	 .field_name = "pfStatus",
	 .field_help = "This field represents the status of packet filtering",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "status",
	 .field_gui_name = "Status",
	 .values = firewall_packetfilter_set_pfstatus_values,
	 .tot_values =
	 sizeof(firewall_packetfilter_set_pfstatus_values) /
	 sizeof(struct value_set)
	 }
};

struct cmd_entry firewall_packetfilter_set_cmd = {
	.fields = firewall_packetfilter_set_cmd_field,
	.tot_fields =
	    sizeof(firewall_packetfilter_set_cmd_field) /
	    sizeof(struct cmd_field),
	.help = "This is packetfilter set command",
	.post_url = "/goform/ifx_set_firewall_packetfilter"
};

struct menu_entry firewall_packetfilter_page_entries[] = {
	{
	 .entry_help = "Displays Packetfilter Entries",
	 .cli_name = "Show",.cli_url = "firewall_packetfilter.cli",
	 },
	{
	 .entry_help = "Configures Packetfilter status",
	 .cli_name = "Set",.cmd = &firewall_packetfilter_set_cmd},
	{
	 .entry_help = "Add a Packetfilter entry",
	 .cli_name = "Add",.cmd = &firewall_packetfilter_add_cmd},
	{
	 .entry_help = "Delete a Packetfilter entry",
	 .cli_name = "Delete",.cmd = &firewall_packetfilter_del_cmd}
};

struct menu_page firewall_packetfilter_page = {
	.entries = firewall_packetfilter_page_entries,
	.tot_entries =
	    sizeof(firewall_packetfilter_page_entries) /
	    sizeof(struct menu_entry),
	.page_help = "This is packetfilter page",
	.cli_title = "packetfilter",.gui_title = "Packet Filter"
};

struct value_set firewall_macctrl_set_cmd_values[] = {
	{.display_value = "disable",.submit_value = "0"},
	{.display_value = "denyall",.submit_value = "1"},
	{.display_value = "permitall",.submit_value = "2"}
};

struct cmd_field firewall_macctrl_set_cmd_field[] = {
	{
	 .field_name = "check",
	 .field_help = "This field represents the status of Mac Control",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "control",
	 .field_gui_name = "Control",
	 .values = firewall_macctrl_set_cmd_values,
	 .tot_values =
	 sizeof(firewall_macctrl_set_cmd_values) / sizeof(struct value_set)
	 }
};

struct cmd_entry firewall_macctrl_set_cmd = {
	.fields = firewall_macctrl_set_cmd_field,
	.tot_fields =
	    sizeof(firewall_macctrl_set_cmd_field) / sizeof(struct cmd_field),
	.help = "This is macControl set command",
	.post_url = "/goform/ifx_set_firewall_mac",
	.get_url = "firewall_mac.cli"
};

struct value_set firewall_macctrl_add_cmd_values[] = {
	{.display_value = "disable",.submit_value = "0"},
	{.display_value = "deny",.submit_value = "1"},
	{.display_value = "permit",.submit_value = "2"}
};

struct cmd_field firewall_macctrl_add_cmd_field[] = {
	{
	 .field_name = "macfilterAction",
	 .field_help = "This field represent the status of filter action",
	 .data_type = STR,.field_type = STATIC,.mandatory = IFX_TRUE,
	 .field_display_name = "action",
	 .field_gui_name = "Policy",
	 .values = firewall_macctrl_add_cmd_values,
	 .tot_values =
	 sizeof(firewall_macctrl_add_cmd_values) / sizeof(struct value_set)
	 },
	{
	 .field_name = "macfilterAdd",
	 .field_help = "This field represent the mac address",
	 .data_type = MACADDR,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "macaddress",
	 .field_gui_name = "MAC Address",
	 .fprocessing_post = mac_addr_processing},
	{
	 .field_name = "hostAdd1",
	 .field_help = NULL,
	 .data_type = STR,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .field_display_name = NULL,
	 .fprocessing_post = NULL,
	 .cur_value = "MacAdd"}
};

struct cmd_entry firewall_macctrl_add_cmd = {
	.fields = firewall_macctrl_add_cmd_field,
	.tot_fields =
	    sizeof(firewall_macctrl_add_cmd_field) / sizeof(struct cmd_field),
	.help = "This command configures mac settings of device",
	.post_url = "/goform/ifx_set_firewall_mac",
	.get_url = "firewall_mac.cli"
};

struct cmd_field firewall_macctrl_del_cmd_field[] = {
	{
	 .field_name = "macfilterAdd",
	 .field_help = "This field represent the mac address",
	 .data_type = MACADDR,.field_type = USR_DEF,.mandatory = IFX_TRUE,
	 .field_display_name = "macaddress",
	 .field_gui_name = "MAC Address",

	 },
	{
	 .field_name = "delflag",
	 .field_help = NULL,
	 .data_type = STR,
	 .field_type = HIDDEN,
	 .mandatory = IFX_FALSE,
	 .field_display_name = NULL,
	 .fprocessing_post = NULL,
	 .cur_value = "1"}
};

struct cmd_entry firewall_macctrl_del_cmd = {
	.fields = firewall_macctrl_del_cmd_field,
	.tot_fields =
	    sizeof(firewall_macctrl_del_cmd_field) / sizeof(struct cmd_field),
	.help = "This command configures mac settigns of device",
	.post_url = "/goform/ifx_set_firewall_mac",
	.custom_processing_post = firewall_macctrl_del_post_flag,
	.get_url = "firewall_mac.cli"
};

struct menu_entry firewall_mac_entries[] = {
	{
	 .entry_help = "Displays MacControl Entries",
	 .cli_name = "Show",.cli_url = "firewall_mac.cli"},
	{
	 .entry_help = "Configures MacControl status",
	 .cli_name = "Set",.cmd = &firewall_macctrl_set_cmd},
	{
	 .entry_help = "Add a MacControl entry",
	 .cli_name = "Add",.cmd = &firewall_macctrl_add_cmd},
	{
	 .entry_help = "Delete a MacControl entry",
	 .cli_name = "Delete",.cmd = &firewall_macctrl_del_cmd}
};

struct menu_page firewall_mac_page = {
	.entries = firewall_mac_entries,
	.tot_entries = sizeof(firewall_mac_entries) / sizeof(struct menu_entry),
	.page_help = "This is Macfilter page",
	.cli_title = "macfilter",.gui_title = "Mac Filter"
};

struct menu_entry firewall_page_entries[] = {
	{
	 .next_page = &firewall_settings_page,
	 .entry_help = "Firewall Settings",.cli_name = "setting",
	 .gui_name = "Firewall Settings",.gui_url = "firewall_main.asp"},
	{
	 .next_page = &firewall_dos_page,
	 .entry_help = "Firewall DoS Options",.cli_name = "Dos",
	 .gui_name = "Disablewan",.gui_url = "firewall_disable_wan.asp"},
	{
	 .next_page = &firewall_packetfilter_page,
	 .entry_help = "Firewall PacketFilter",.cli_name = "packetfilter",
	 .gui_name = "Packet Filtering",.gui_url = "firewall_packetfilter.asp"},
	{
	 .next_page = &firewall_mac_page,
	 .entry_help = "Firewall MAC Control",.cli_name = "mac",
	 .gui_name = "MAC Control",.gui_url = "firewall_mac.asp"}
};

struct menu_page firewall_page = {
	.entries = firewall_page_entries,
	.tot_entries =
	    sizeof(firewall_page_entries) / sizeof(struct menu_entry),
	.page_help = "Firewall",
	.cli_title = "firewall",.gui_title = "Firewall",
	.fpos = 1
};
#endif /*__FW_MENU_H */
