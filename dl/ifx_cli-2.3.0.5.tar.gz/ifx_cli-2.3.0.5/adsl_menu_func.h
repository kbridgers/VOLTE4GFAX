
int adsl_phyconfig_autoselected_mode_post_flag(struct cmd_entry *p,
					       char *poststr);
int adsl_phyconfig_manual_mode_post_flag(struct cmd_entry *p, char *poststr);
int adsl_phyconfig_testmode_control_post_flag(struct cmd_entry *p,
					      char *poststr);
int adsl_phyconfig_power_mgnt_control_post_flag(struct cmd_entry *p,
						char *poststr);
int adsl_vcconfig_add_post_flag(struct cmd_entry *p, char *poststr);
int adsl_vcconfig_del_post_flag(struct cmd_entry *p, char *poststr);
int validate_oam_vcc(struct cmd_entry *p, char *errstr);
int adsl_vcconfig_add_custom_valid(struct cmd_entry *cmd, char *errstr);
int adsl_oam_post_flag(struct cmd_entry *p, char *poststr);
int adsl_manual_mode_cmd_fprocessing(struct cmd_field *cur_field,
				     char *poststr);
int f5_cmd_vpivci_fprocessing(struct cmd_field *cur_field, char *poststr);
int validate_test_oam(struct cmd_entry *p, char *poststr);
