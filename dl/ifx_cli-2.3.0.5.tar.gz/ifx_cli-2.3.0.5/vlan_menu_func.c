
/* ============================================================================
 * Copyright (C) 2005 -Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 *============================================================================
 *
 * This document contains proprietary information belonging to Infineon 
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 * 
 * ============================================================================
 */

/* ===========================================================================
 *
 * File Name:   adsl_menu_func.c
 * Author :     Nirav Salot
 * Date: 		April, 2005
 *
 * ===========================================================================
 *
 * Project: Amazon
 *
 * ===========================================================================
 * Contents: This file implements ADSL menu related specific functions.
 *  
 * ===========================================================================
 * References: 
 *
 */
#include <stdio.h>
#include <string.h>
#include "common.h"

int vlan_portmap_cmd_post(struct cmd_entry *cmd, char *poststr)
{
	struct value_set *status_value = NULL;
	struct value_set *index_value = NULL;
	int i, index = 0;
	char *strindex = NULL;
	char *strid = NULL;
	char strtemp[32];
	struct cmd_field *index_field = NULL;
	struct cmd_field *status_field = NULL;

	strid = get_field_entry(cmd, "PORT_PVID")->cur_value;
	status_field = get_field_entry(cmd, "PORT_TAG");
	index_field = get_field_entry(cmd, "index");
	for (i = 0, index_value = index_field->values;
	     i < index_field->tot_values; i++, index_value++) {
		if (strcmp(index_value->display_value, index_field->cur_value)
		    == 0) {
			strindex = index_value->submit_value;
			break;
		}
	}

	if (strindex) {
		index = atoi(strindex);
		sprintf(poststr, "Error : NULL passed to atoi\n");
		return -1;
	}

	if (index < 1 || index > 5) {
		sprintf(poststr,
			"Error : Invalid index.\nThe index value can only be between 1 to 5\n");
		return -1;
	}
	memset(strtemp, 0x00, sizeof(strtemp));
	sprintf(strtemp, "PORT%d_PVID=%s&", index - 1, strid);
	strcat(poststr, strtemp);

	memset(strtemp, 0x00, sizeof(strtemp));
	for (i = 0, status_value = status_field->values;
	     i < status_field->tot_values; i++, status_value++)
		if (strcmp(status_value->display_value, status_field->cur_value)
		    == 0) {
			sprintf(strtemp, "PORT%d_TAG=%s", index - 1,
				status_value->submit_value);
			break;
		}
	strcat(poststr, strtemp);
	return 0;
}
