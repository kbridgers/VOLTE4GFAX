
int validate_vlan_and_password(struct cmd_entry *cmd, char *errstr);

int validate_password(struct cmd_entry *cmd, char *errstr);

int wan_config_cmd_post_flag(struct cmd_entry *cmd, char *poststr);

int pppoea_config_reconnect_post(struct cmd_field *cur_field, char *poststr);

int pppoe_config_relay_post(struct cmd_field *cur_field, char *poststr);

int get_vpivci_fvset(struct value_set **pp_value_set, int *p_num_entries);

int validate_vlan(struct cmd_entry *cmd, char *errstr);
