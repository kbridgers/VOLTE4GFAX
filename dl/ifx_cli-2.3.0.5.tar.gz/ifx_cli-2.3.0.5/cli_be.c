/* ============================================================================
 * Copyright (C) 2005 -Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 *============================================================================
 *
 * This document contains proprietary information belonging to Infineon 
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 * 
 * ============================================================================
 */

/* ===========================================================================
 *
 * File Name:   cli_be.c
 * Author :     Nirav Salot
 * Date: 		April, 2005
 *
 * ===========================================================================
 *
 * Project: Amazon
 *
 * ===========================================================================
 * Contents: This file implements the CLI backend infrastructure which provides
 * all the CLI processing capabilities. The CLI frontend (cli_fe) interacts
 * with the cli_be and in turn, cli_be interacts with the web server.
 *  
 * ===========================================================================
 * References: 
 *
 */

/* ===========================================================================
 * Revision History:
 *
 * $Log$
 * ===========================================================================
 */
#include "common.h"
#include "system_menu.h"
#include "statistics_menu.h"
#include "adsl_menu.h"
#include "route_menu.h"
#include "snmp_menu.h"
#include "lan_menu.h"
#include "qos_menu.h"
#include "firewall_menu.h"
#include "wan_menu.h"
#include "wireless_menu.h"
#include "nat_menu.h"
#include "vlan_menu.h"
#include "apps_menu.h"
#include "tr69_menu.h"
#ifdef CONFIG_FEATURE_SAMBA
#include "content_sharing_menu.h"
#endif
#include "main_menu.h"

#ifndef IFX_CLI_PROMPTEDMODE
char *cli_root_dir;
char *cli_fe_path;
#endif

pid_t cli_fe_cur_pid;

#define BUF_CHUNK 1024
#define REDIRECT_RESHEADER "HTTP/1.0 302"

void init_match_engine(void);
char *call_draw_html_page(char *pstr);

int main(int argc, char *argv[])
{
	int s, fe_sock;
#ifndef IFX_CLI_FROM_INETD
	int len;
	struct sockaddr_un local;
#endif
	struct sockaddr_un remote;

#ifndef IFX_CLI_PROMPTEDMODE
	if (argc != 3) {
		printf("Usage : cli_be cli_root_dir cli_fe_path\n");
		return 1;
	}

	cli_root_dir = argv[1];
	cli_fe_path = argv[2];

	printf("root directory name [%s] !\n", cli_root_dir);
	sprintf(cmd, "rm -rf %s/*", cli_root_dir);
	system(cmd);
	cmd[0] = '\0';
	chdir(cli_root_dir);
	create_dir_struct(&main_menu);
#endif

#ifndef IFX_CLI_FROM_INETD
	if ((s = socket(AF_UNIX, SOCK_STREAM, 0)) == -1) {
		perror("socket");
		exit(2);
	}
	local.sun_family = AF_UNIX;
	strcpy(local.sun_path, SOCK_FE_PATH);
	unlink(local.sun_path);
	len = strlen(local.sun_path) + sizeof(local.sun_family);
	if (bind(s, (struct sockaddr *)&local, len) == -1) {
		perror("bind");
		exit(1);
	}

	if (listen(s, 5) == -1) {
		perror("listen");
		exit(1);
	}
#else
	s = 0;			/* When run from inetd, use stdin as the listening socket */
#endif
	/* Make it a daemon */
	daemon(0, 0);

#if CMD_READ_MODIFY_WRITE
	init_match_engine();
#endif

	for (;;) {
		int n;
		int tot_fvset = 0;
		struct menu_entry *cur_menu_entry = NULL;
		char str[512];
		char poststr[1024];
		char *url = NULL;
		enum HTTP_REQTYPE req_type;
		char *pstr = NULL;
		struct toplevel_fe_msg *cur_fe_msg = NULL;
		int tot_bytes = 0;
		char ErrRes[1024];
		char *outbuf = NULL;
		int selret = 0;
		//struct timeval timeout_val;
		fd_set readfd;

		FD_ZERO(&readfd);
		FD_SET(s, &readfd);
	//	timeout_val.tv_sec = IFX_CLI_INACTIVITY_TIMEOUT;
	//	timeout_val.tv_usec = 0;

		printf("Waiting for a connection...\n");
		//selret = select(s + 1, &readfd, 0, 0, &timeout_val);
		selret = select(s + 1, &readfd, 0, 0, 0);

		if (selret == 0)
			break;
		if (!FD_ISSET(s, &readfd))
			continue;
		n = sizeof(remote);

		if ((fe_sock =
		     accept(s, (struct sockaddr *)&remote,
			    (socklen_t *) & n)) == -1) {
			perror("accept");
			continue;
		}

		printf("Connected to fe.\n");
		memset(str, 0x00, sizeof(str));
		n = recv(fe_sock, str, sizeof(str), 0);
		if (n < 0) {
			perror("recv from fe_sock:");
			close(fe_sock);
			continue;
		}

		pstr = str + sizeof(*cur_fe_msg);
		cur_fe_msg = (struct toplevel_fe_msg *)str;
		cli_fe_cur_pid = cur_fe_msg->cli_fe_pid;
		memset(poststr, 0x00, sizeof(poststr));

		cur_menu_entry = find_menu_entry(pstr);
		if (cur_menu_entry == NULL) {
			char *response = NULL;
			int reslen = 0;
			sprintf(ErrRes, "command not found\n");
			make_show_msg(ErrRes, &response, &reslen);

			if (response) {
				send(fe_sock, response, reslen, 0);
				free(response);
			}

			close(fe_sock);
			continue;
		}

		if (cur_menu_entry->cmd != NULL
		    && cur_fe_msg->msg_type == MSG_SUBMIT) {
			struct field_value_set *cmd_fvset = NULL;
#if CMD_READ_MODIFY_WRITE
			struct field_value_set *cmd_get_fvset = NULL;	/* generated from the get url */
#endif
			int all_validation_successful = 0;
			int tot_get_fvset = 0;

			do {
				if (get_dynamic_fvset(cur_menu_entry->cmd)) {
					sprintf(ErrRes,
						"Error : Could not fetch field valus from backend\n");
					break;
				}
				printf("%s : cur str [%s]\n", __FUNCTION__,
				       pstr);
				cmd_fvset = make_fvset(pstr, &tot_fvset);
				if (tot_fvset == -1) {
					sprintf(ErrRes,
						"Error : Invalid syntax\n");
					gen_syntax(cur_menu_entry, ErrRes, 0);
					break;
				}
				print_cmd_fvset(cmd_fvset, tot_fvset);

#ifndef IFX_CLI_PROMPTEDMODE
				if (check_syntax
				    (cur_menu_entry->cmd, cmd_fvset,
				     tot_fvset)) {
					sprintf(ErrRes,
						"Error : Invalid syntax\n");
					gen_syntax(cur_menu_entry, ErrRes, 0);
					break;
				}
				if (check_type
				    (cur_menu_entry->cmd, cmd_fvset,
				     tot_fvset)) {
					sprintf(ErrRes,
						"Error : Invalid type\n");
					gen_syntax(cur_menu_entry, ErrRes, 0);
					break;
				}
#endif
				printf("populating set\n");
				populate_fieldvalues(cur_menu_entry->cmd,
						     cmd_fvset, tot_fvset);
				print_field_values(cur_menu_entry->cmd);

				printf("cli_be : trying custom_validation\n");
				if (cur_menu_entry->cmd->custom_validation) {
					if (cur_menu_entry->cmd->
					    custom_validation(cur_menu_entry->
							      cmd, ErrRes)) {
						gen_syntax(cur_menu_entry,
							   ErrRes, 0);
						break;
					}
				}

				printf("cli_be : calling generate_poststr\n");
				if (generate_poststr
				    (cur_menu_entry->cmd, poststr)) {
					strcpy(ErrRes, poststr);
					memset(poststr, 0x00, sizeof(poststr));
					break;
				}
				printf("poststr [%s]\n", poststr);

#if CMD_READ_MODIFY_WRITE
				/* If for the current command get_url is defined... */
				tot_get_fvset = 0;
				if (cur_menu_entry->cmd->get_url) {
					cmd_get_fvset =
					    make_get_fvset(cur_menu_entry->cmd->
							   get_url,
							   &tot_get_fvset);
				}

				update_poststr_from_backend(cmd_get_fvset,
							    tot_get_fvset,
							    poststr);
#endif
				all_validation_successful = 1;
			} while (0);	/* one time loop */

#if 1
			printf("cli_be : calling free_cmd_fvset\n");
			free_cmd_fvset(cmd_fvset, &tot_fvset);
#endif
#if CMD_READ_MODIFY_WRITE
			printf("cli_be : calling free_cmd_get_fvset\n");
			free_cmd_fvset(cmd_get_fvset, &tot_get_fvset);
#endif
			printf("cli_ne : calling free_vset\n");
			free_vset(cur_menu_entry->cmd);

			printf("cli_be : calling reset_cmd_field_values\n");
			reset_cmd_field_values(cur_menu_entry->cmd);
			if (all_validation_successful == 0) {
				char *response = NULL;
				int reslen = 0;
				make_show_msg(ErrRes, &response, &reslen);

				if (response) {
					send(fe_sock, response, reslen, 0);
					free(response);
				}

				close(fe_sock);
				continue;
			}
			url = cur_menu_entry->cmd->post_url;
			req_type = REQ_POST;
		} else if (cur_menu_entry->cmd != NULL
			   && cur_fe_msg->msg_type == MSG_QUERY) {
			char *response = NULL;
			int reslen = 0;

			make_cmd_msg(cur_menu_entry->cmd, &response, &reslen);

			if (response) {
				send(fe_sock, response, reslen, 0);
				free(response);
			}

			close(fe_sock);
			continue;
		} else if (cur_menu_entry->cli_url != NULL
			   && cur_fe_msg->msg_type == MSG_QUERY) {
			url = cur_menu_entry->cli_url;
			req_type = REQ_GET;
			printf("URL [%s]\n", url);
		} else if (cur_fe_msg->msg_type == MSG_QUERY) {
			char *response = NULL;
			int reslen = 0;
			make_menu_msg(cur_menu_entry->next_page, &response,
				      &reslen);

			if (response) {
				send(fe_sock, response, reslen, 0);
				free(response);
			}

			close(fe_sock);
			continue;
		} else {
			char *response = NULL;
			int reslen = 0;

			sprintf(ErrRes, "command not found\n");
			make_show_msg(ErrRes, &response, &reslen);
			if (response) {
				send(fe_sock, response, reslen, 0);
				free(response);
			}

			close(fe_sock);
			continue;
		}

		pstr = NULL;
		tot_bytes = 0;
		get_httpd_data(url, req_type, poststr, &pstr, &tot_bytes);
		if (pstr) {
			if (strncmp
			    (pstr, REDIRECT_RESHEADER,
			     strlen(REDIRECT_RESHEADER)) == 0) {
				char *startLoc = NULL;
				char *endLoc = NULL;
				char redirectUrl[128];

				startLoc = strstr(pstr, "Location:");
				if (startLoc) {
					endLoc = strstr(startLoc, "\r\n");
					pstr[endLoc - pstr] = '\0';
					startLoc = strrchr(startLoc, '/');
					startLoc++;
					memset(redirectUrl, 0x00,
					       sizeof(redirectUrl));
					strlcpy(redirectUrl, startLoc, endLoc - startLoc + 1);	// + 1 for NULL termination 
					printf("Redirect URL [%s]\n",
					       redirectUrl);
					if (pstr)
						free(pstr);
					tot_bytes = 0;
					req_type = REQ_GET;
					get_httpd_data(redirectUrl, req_type,
						       NULL, &pstr, &tot_bytes);
				}
			}
#if 0
			printf("%s : pstrlen [%d]\n", __FUNCTION__, tot_bytes);
			{
				FILE *fp = NULL;
				fp = fopen("/tmp/out.html", "a+");
				if (fp != NULL) {
					fprintf(fp, "%s", pstr);
					fclose(fp);
				}
			}
#endif
			outbuf = call_draw_html_page(pstr);
			if (pstr)
				free(pstr);
		}
		pstr = NULL;
		tot_bytes = 0;
		if (!make_show_msg(outbuf, &pstr, &tot_bytes)) {
			printf("sending %d bytes\n", tot_bytes);
			n = send(fe_sock, pstr, tot_bytes, 0);

			if (n < 0)
				perror("send to fe_sock");

			free(pstr);
			pstr = NULL;
		}

		if (pstr) {
			free(pstr);
			pstr = NULL;
		}

		if (fe_sock)
			close(fe_sock);
		if (outbuf)
			free(outbuf);
	}

	close(s);
	return 0;
}

int adsl_oam_post_flag(struct cmd_entry *p, char *poststr)
{
	//struct value_set *v_set;
	//int entries = 0;
	int i = 0;
	struct cmd_field *cur_field = NULL;
	char sValue[40], command[40]/*, *loopback, *continuity*/, *VPI_value,
	    *VCI_value, *f5_time;
	char temp[10], /**direction,*/ *value;
	int cur_ch = 0;
	int nChannel_Size = 0;
	if (p->fields == adsl_oamenable_cmd_field) {
		strcat(poststr, "submit_action=submit");
	} else if (p->fields == adsl_oam_f5_cmd_field) {
		strcat(poststr, "submit_action=modifyF5");
	} else {

	}
/*	get time value from rc.conf
 *	if that is also null use default value (600)
 *	else use the stored value without modification
 */
	strcat(poststr, "&OAM_F5_TIME=");
	if (get_field_entry(p, "OAM_F5_TIME_TMP") != NULL) {
		value = get_field_entry(p, "OAM_F5_TIME_TMP")->cur_value;
		if (value == NULL)
			goto labela;
		strcat(poststr, value);
	} else {
	      labela:if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_ADSL_OAM_F5, T("adsl_oam_f5Count"),
		     sValue) == 0) {
			printf("OAM entries not found !\n");
			return 1;
		}

		nChannel_Size = atoi(sValue);

		cur_field = get_field_entry(p, "OAM_F5_VPIVCI_CHANNEL");
		cur_ch = atoi(cur_field->cur_value);
		for (i = 0; i < nChannel_Size; i++) {
			memset(sValue, 0x00, sizeof(sValue));
			memset(temp, 0x00, sizeof(temp));

			sprintf(command, "adsl_oam_f5%d", i);
			memset(sValue, 0x00, sizeof(sValue));
			memset(temp, 0x00, sizeof(temp));
			if (ifx_GetCfgData
			    (FILE_RC_CONF, TAG_ADSL_OAM_F5, command,
			     sValue) == 0) {
				printf("ADSL OAM entry  not found\n");
				return 1;
			}
			VPI_value = strtok(sValue, "_");
			VCI_value = strtok(NULL, "_");
			//loopback = strtok(NULL, "_");
			//continuity = strtok(NULL, "_");
			//direction = strtok(NULL, "_");
			f5_time = strtok(NULL, "_");
			sprintf(temp, "%s/%s", VPI_value, VCI_value);
			if (cur_ch == i) {
				if (f5_time == NULL)
					strcat(poststr, "600");
				else
					strcat(poststr, f5_time);
				return 0;
			}
		}
	}
	return 0;
}
