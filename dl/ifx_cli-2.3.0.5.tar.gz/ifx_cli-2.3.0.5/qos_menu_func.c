/*
000001:tc.chen 2005/06/07 add IP QoS and 802.1P priority queue
*/
/* ============================================================================
 * Copyright (C) 2005 -Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 *============================================================================
 *
 * This document contains proprietary information belonging to Infineon 
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 * 
 * ============================================================================
 */

/* ===========================================================================
 *
 * File Name:   qos_menu_func.c
 * Author :     tc.chen
 * Date: 		June, 2005
 *
 * ===========================================================================
 *
 * Project: Amazon
 *
 * ===========================================================================
 * Contents: This file implements the CLI backend infrastructure which provides
 * all the CLI processing capabilities. The CLI frontend (cli_fe) interacts
 * with the cli_be and in turn, cli_be interacts with the web server.
 *  
 * ===========================================================================
 * References: 
 *
 */

/* ===========================================================================
 * Revision History:
 *
 * $Log$
 * ===========================================================================
 */
#include <stdio.h>
#include <string.h>
#include <common.h>
#include "qos_menu_func.h"

#ifdef CONFIG_FEATURE_QOS_PRIORITY_QUEUE

int qos_priority_queue_del_post(struct cmd_entry *cmd, char *poststr)
{
	struct cmd_field *index_field = get_field_entry(cmd, "index");
	char sValue[256];
	char sCommand[128];
	char temp[4];
	int nCount = 0;

	memset(sCommand, 0x00, sizeof(sCommand));
	memset(sValue, 0x00, sizeof(sValue));
	sprintf(sCommand, "grep \"^%sCount\" %s | cut -f2 -d'\"'",
		PREFIX_QOS_PRIORITY, FILE_RC_CONF);
	if (ifx_GetCfgData(sCommand, NULL, "1", sValue) == 0) {
		sprintf(poststr, "Error : Could not find %sCount from %s\n",
			PREFIX_QOS_PRIORITY, FILE_RC_CONF);
		return -1;
	}

	nCount = atoi(sValue);
	if (nCount <= 0) {
		strcpy(poststr, "Error : No rules added to be deleted\n");
		return -1;
	}
	if (nCount < atoi(index_field->cur_value)
	    || atoi(index_field->cur_value) <= 0) {
		sprintf(poststr,
			"Error : Please enter a no. between 1-%d only\n",
			nCount);
		printf("%s : %s\n", __FUNCTION__, poststr);
		return -1;
	}
	nCount = atoi(index_field->cur_value);
	nCount--;
	memset(temp, 0x00, sizeof(temp));
	sprintf(temp, "%d", nCount);
	strcat(poststr, "delindex=");
	strcat(poststr, temp);
	return 0;
}

int qos_priority_add_valid(struct cmd_entry *cmd, char *errstr)
{
	struct cmd_field *cur_field = NULL;
	char *proto;
	int st_port = 0;
	int end_port = 0;

	cur_field = get_field_entry(cmd, "QP_PROTO_ADD");
	proto = cur_field->cur_value;

	cur_field = get_field_entry(cmd, "QP_PORT_SRC_START_ADD");
	if (cur_field->cur_value)
		st_port = atoi(cur_field->cur_value);
	cur_field = get_field_entry(cmd, "QP_PORT_SRC_END_ADD");
	if (cur_field->cur_value)
		end_port = atoi(cur_field->cur_value);

	if (!strcmp(proto, "tcp") || !strcmp(proto, "udp"))
		if (end_port != 0 && st_port > end_port) {
			strcpy(errstr,
			       "Error : Source Port1 should be less than Source Port2\n");
			return 1;
		}

	cur_field = get_field_entry(cmd, "QP_PORT_DST_START_ADD");
	st_port = 0;
	end_port = 0;
	if (cur_field->cur_value)
		st_port = atoi(cur_field->cur_value);
	cur_field = get_field_entry(cmd, "QP_PORT_DST_END_ADD");
	if (cur_field->cur_value)
		end_port = atoi(cur_field->cur_value);

	if (!strcmp(proto, "tcp") || !strcmp(proto, "udp"))
		if (end_port != 0 && st_port > end_port)
			//if(st_port > end_port)
		{
			strcpy(errstr,
			       "Error : Destination Port1 should be less than Destination Port2\n");
			return 1;
		}

	return 0;
}
#endif				//CONFIG_FEATURE_QOS_PRIORITY_QUEUE
