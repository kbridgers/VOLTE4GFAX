
struct menu_entry wan_statistics_page_entries[] = {
	{
	 .entry_help = "This is wan statistics show entry",
	 .cli_name = "Show",.cli_url = "wan_if_stats.cli",
	 }
};

struct menu_page wan_statistics_page = {
	.entries = wan_statistics_page_entries,
	.tot_entries =
	    sizeof(wan_statistics_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is wan statistics page",.cli_title =
	    "wan",.gui_title = "WAN"
};

struct menu_entry lan_statistics_page_entries[] = {
	{
	 .entry_help = "This is lan statistics show entry",
	 .cli_name = "Show",.cli_url = "lan_if_stats.cli",
	 }
};

struct menu_page lan_statistics_page = {
	.entries = lan_statistics_page_entries,
	.tot_entries =
	    sizeof(lan_statistics_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is lan statistics page",.cli_title =
	    "lan",.gui_title = "LAN"
};

struct menu_entry statistics_page_entries[] = {
	{
	 .next_page = &lan_statistics_page,
	 .entry_help = "lan statistics entry",
	 .cli_name = "lan",.gui_name = "LAN",.gui_url = "lan_if_stats.asp"},
	{
	 .next_page = &wan_statistics_page,
	 .entry_help = "wan statistics entry",
	 .cli_name = "wan",.gui_name = "WAN",.gui_url = "wan_if_stats.asp"}

};

struct menu_page statistics_page = {
	.entries = statistics_page_entries,
	.tot_entries =
	    sizeof(statistics_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is statistics page",.cli_title =
	    "statistics",.gui_title = "Statistics"
};
