int nat_portmap_config_cmd_post(struct cmd_entry *cur_cmd, char *poststr);
int nat_virtualser_set_cmd_post(struct cmd_entry *cur_cmd, char *poststr);
