
/* ============================================================================
 * Copyright (C) 2005 -Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 *============================================================================
 *
 * This document contains proprietary information belonging to Infineon 
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 * 
 * ============================================================================
 */

/* ===========================================================================
 *
 * File Name:   adsl_menu_func.c
 * Author :     Nirav Salot
 * Date: 		April, 2005
 *
 * ===========================================================================
 *
 * Project: Amazon
 *
 * ===========================================================================
 * Contents: This file implements ADSL menu related specific functions.
 *  
 * ===========================================================================
 * References: 
 *
 */
#include <stdio.h>
#include <string.h>
#include "common.h"

int nat_portmap_config_cmd_post(struct cmd_entry *cmd, char *poststr)
{
	struct value_set *status_value = NULL;
	int i, index;
	char *strindex = NULL;
	char *strip = NULL;
	char *strport = NULL;
	char strtemp[32];
	char sServerIP[16];
	struct value_set *cur_value = NULL;
	struct cmd_field *index_field = NULL;
	struct cmd_field *status_field = NULL;

	memset(sServerIP, 0x00, sizeof(sServerIP));
	websGetIFInfo(LAN_IF_TYPE, IP_INFO, 1, 3, 0, sServerIP);

	strip = get_field_entry(cmd, "CLONE_IP")->cur_value;
	strport = get_field_entry(cmd, "CLONE_PORTS")->cur_value;
	status_field = get_field_entry(cmd, "CLONE_ENABLE");

	index_field = get_field_entry(cmd, "index");
	for (i = 0, cur_value = index_field->values;
	     i < index_field->tot_values; i++, cur_value++) {
		if (strcmp(cur_value->display_value, index_field->cur_value) ==
		    0) {
			strindex = cur_value->submit_value;
			break;
		}
	}

	if (strindex) {
		index = atoi(strindex);
	} else {
		sprintf(poststr, "Error : Unable to retrive index\n");
		return -1;
	}

	if (index < 1 || index > 5) {
		sprintf(poststr,
			"Error : Invalid index.\nThe index value can only be between 1 to 5\n");
		return -1;
	}
	if (strncmp(sServerIP, strip, strlen(sServerIP))) {
		sprintf(poststr,
			"Error : Invalid IP address. It should have prefix %s\n",
			sServerIP);
		return -1;
	}

	strip = strip + strlen(sServerIP);
	memset(strtemp, 0x00, sizeof(strtemp));
	sprintf(strtemp, "CLONE_IP%s=%s&", strindex, strip);
	strcat(poststr, strtemp);
	memset(strtemp, 0x00, sizeof(strtemp));
	sprintf(strtemp, "CLONE_PORTS%s=%s&", strindex, strport);
	strcat(poststr, strtemp);

	memset(strtemp, 0x00, sizeof(strtemp));
	for (i = 0, status_value = status_field->values;
	     i < status_field->tot_values; i++, status_value++)
		if (strcmp(status_value->display_value, status_field->cur_value)
		    == 0)
			sprintf(strtemp, "CLONE_ENABLE%s=%s", strindex,
				status_value->submit_value);
	strcat(poststr, strtemp);
	return 0;
}

int nat_virtualser_set_cmd_post(struct cmd_entry *cmd, char *poststr)
{
	struct value_set *status_value = NULL;
	struct value_set *proto_value = NULL;
	struct value_set *index_value = NULL;
	int i, index;
	char *strindex = NULL;
	char *strip = NULL;
	char *strpport = NULL;
	char *strpuport = NULL;
	char strtemp[32];
	char sServerIP[16];
	struct cmd_field *index_field = NULL;
	struct cmd_field *status_field = NULL;
	struct cmd_field *proto_field = NULL;

	memset(sServerIP, 0x00, sizeof(sServerIP));
	websGetIFInfo(LAN_IF_TYPE, IP_INFO, 1, 3, 0, sServerIP);

	strip = get_field_entry(cmd, "NATVS_PIP")->cur_value;
	strpport = get_field_entry(cmd, "NATVS_PPORT")->cur_value;
	strpuport = get_field_entry(cmd, "NATVS_PUPORT")->cur_value;
	status_field = get_field_entry(cmd, "NATVS_F");
	proto_field = get_field_entry(cmd, "NATVS_TYPE");
	index_field = get_field_entry(cmd, "index");
	for (i = 0, index_value = index_field->values;
	     i < index_field->tot_values; i++, index_value++) {
		if (strcmp(index_value->display_value, index_field->cur_value)
		    == 0) {
			strindex = index_value->submit_value;
			break;
		}
	}
	if (strindex) {
		index = atoi(strindex);
	} else {
		sprintf(poststr, "Error : Unable to retrive index\n");
		return -1;
	}
	if (index < 1 || index > 5) {
		sprintf(poststr,
			"Error : Invalid index.\nThe index value can only be between 1 to 5\n");
		return -1;
	}
	if (strncmp(sServerIP, strip, strlen(sServerIP))) {
		sprintf(poststr,
			"Error : Invalid IP address. It should have prefix %s\n",
			sServerIP);
		return -1;
	}

	strip = strip + strlen(sServerIP);
	memset(strtemp, 0x00, sizeof(strtemp));
	sprintf(strtemp, "NATVS_PIP%s=%s&", strindex, strip);
	strcat(poststr, strtemp);
	memset(strtemp, 0x00, sizeof(strtemp));
	sprintf(strtemp, "NATVS_PPORT%s=%s&", strindex, strpport);
	strcat(poststr, strtemp);
	sprintf(strtemp, "NATVS_PUPORT%s=%s&", strindex, strpuport);
	strcat(poststr, strtemp);

	memset(strtemp, 0x00, sizeof(strtemp));
	for (i = 0, proto_value = proto_field->values;
	     i < proto_field->tot_values; i++, proto_value++)
		if (strcmp(proto_value->display_value, proto_field->cur_value)
		    == 0)
			sprintf(strtemp, "NATVS_PTYPE%s=%s&", strindex,
				proto_value->submit_value);
	strcat(poststr, strtemp);

	memset(strtemp, 0x00, sizeof(strtemp));
	for (i = 0, status_value = status_field->values;
	     i < status_field->tot_values; i++, status_value++)
		if (strcmp(status_value->display_value, status_field->cur_value)
		    == 0)
			sprintf(strtemp, "NATVS_F%s=%s", strindex,
				status_value->submit_value);
	strcat(poststr, strtemp);
	return 0;
}
