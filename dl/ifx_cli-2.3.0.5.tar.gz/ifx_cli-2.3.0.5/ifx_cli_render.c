/* ============================================================================
 * Copyright (C) 2005 -Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 *============================================================================
 *
 * This document contains proprietary information belonging to Infineon 
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 * 
 * ============================================================================
 */

/* ===========================================================================
 *
 * File Name:   ifx_cli_render.c
 * Author :     Vempali Chandra 
 * Date: 		April, 2005
 *
 * ===========================================================================
 *
 * Project: Amazon
 *
 * ===========================================================================
 * Contents: This file implements rendering of simple HTML including tables. 
 *  
 * ===========================================================================
 * References: 
 *
 * $Log$
 *
 */
#include "ifx_cli_render.h"

#define printf(format,args...)
#define fflush(stdout)

extern void remove_non_html_chars(char *buf, char *rem_str);

int col_var_len = -1;
int g_ifx_screen_width_table;
int g_ifx_screen_width = -1;

char *outbuf = NULL;

void append_to_outbuf(char *buf)
{
	outbuf = realloc(outbuf, strlen(outbuf) + strlen(buf) + 1);
	if (!outbuf) {
		printf("\nError No free memory..Exiting...\n");
		exit(1);
	}
	strncat(outbuf, buf, strlen(buf) + 1);

}

void free_table(struct html_page *page, int table_id)
{
	int i, j;

	for (i = 0; i < page->table[table_id].num_tr; i++) {
		for (j = 0; j < page->table[table_id].tr[i].num_td; j++) {
			if (page->table[table_id].tr[i].td[j].str) {
				free(page->table[table_id].tr[i].td[j].str);
			}
		}
		if (page->table[table_id].tr[i].td) {
			free(page->table[table_id].tr[i].td);
		}
	}

	if (page->table[table_id].tr) {
		free(page->table[table_id].tr);
	}

	if (page->table[table_id].td_params_array) {
		free(page->table[table_id].td_params_array);
	}

}

void free_page(struct html_page *page)
{

	if (page == NULL) {
		return;
	}

	if (page->title) {
		free(page->title);
	}
	if (page->pre_str) {
		free(page->pre_str);
	}
	if (page->post_str) {
		free(page->post_str);
	}
#if 0
	if (page->pp_out) {
		free(page->pp_out);
	}
#endif

	if (page->table) {
		free(page->table);
	}
	if (page) {
		free(page);
	}
}

#if 0				//may chandrav no need, dup of match.c:remove_non_html_chars()
void remove_tabs_from_str(char **src)
{
	int k;
	char buf[BUF_LEN] = { '\0' };
	int spos = 0;
	int copy_not_done;
	int len = -1;
	int tab_cnt;
	char *str = *src;

	memset(buf, 0x0, BUF_LEN);
	len = strlen(str);
	spos = 0;
	copy_not_done = 1;
	while (copy_not_done) {
		copy_not_done = 0;
		for (k = spos; k <= len; k++) {
			if (str[k] == '\t') {
				break;
			}
		}
		k++;
		if (k <= len + 1) {
			strncat(buf, str + spos, k - spos - 1);
			tab_cnt = TAB_SPACE;
			while (tab_cnt--) {
				strcat(buf, " ");
			}
			spos += k - spos;
			if (spos < len) {
				copy_not_done = 1;
			}
		} else {
			strncat(buf, str + spos, k - spos);
		}
	}

	*src = realloc(*src, strlen(buf) + 1);
	if (!(*src)) {
		printf("\nError No free memory..Exiting...\n");
		exit(1);
	}

	strncpy(*src, buf, strlen(buf) + 1);
}
#endif

void print_strs(char *dst, char *src)
{
	int printed_len = 0, l;
	int len;
	int newline_flag = FALSE;

	memset(dst, 0x0, BUF_LEN);
	strcat(dst, "\n");
	//may 6 , chandrav --to fix free(pre_str) crash 
	//remove_tabs_from_str(&src);
	remove_non_html_chars(src, "\t");

	// chandrav apr28 len = strlen(src)+1;
	len = strlen(src);

	if (strchr(src, '\n')) {
		newline_flag = TRUE;
	}
	//chandrav apr28
	if (len <= g_ifx_screen_width) {
		strncat(dst, src, len);
		strcat(dst, "\n");
		return;
	}
	if (newline_flag == FALSE) {

		while (printed_len < len + 1) {

			strncat(dst, src + printed_len, g_ifx_screen_width);
			strcat(dst, "\n");
			printed_len += g_ifx_screen_width;
		}
		strcat(dst, "\n");
		return;
	} else {
		while (printed_len < len + 1) {
			for (l = printed_len;
			     l < printed_len + g_ifx_screen_width; l++) {
				//chandrav may5
				if (src[l] == '\0') {	// end of string case
					strcat(dst, src + printed_len);
					strcat(dst, "\n");
					return;
				}

				if (src[l] == '\n') {
					break;
				}
			}
			if (l <= printed_len + g_ifx_screen_width) {
				// new line within a screen width
				strncat(dst, src + printed_len,
					l - printed_len + 1);
				strcat(dst, "\n");
				printed_len += l - printed_len + 1;
			} else {	// no new line in screen width
				strncat(dst, src + printed_len,
					g_ifx_screen_width);
				strcat(dst, "\n");
				printed_len += g_ifx_screen_width;
			}
		}
		strcat(dst, "\n");
		return;
	}

}

char *draw_html_page(struct html_page *page, int screen_width)
{

	int i = 0;
	char buf[BUF_LEN];

	outbuf = NULL;

	if (screen_width > 0) {
		g_ifx_screen_width = screen_width;
	} else {
		g_ifx_screen_width = SCREEN_WIDTH;
	}

	outbuf = malloc(1);
	if (!outbuf) {
		printf("\nError No free memory... Exiting...\n");
		exit(1);
	}

	strcpy(outbuf, "");

	if (page->title) {

		printf("\n%s\n", page->title);
		memset(buf, 0x0, BUF_LEN);
		print_strs(buf, page->title);
		append_to_outbuf(buf);
	}
	if (page->pre_str) {
		printf("\n%s\n", page->pre_str);
		memset(buf, 0x0, BUF_LEN);
		print_strs(buf, page->pre_str);
		append_to_outbuf(buf);
	}

	for (i = 0; i < page->num_tables; i++) {
		if (ifx_compute_td_params(&page->table[i]) != 0) {

			printf("\nError in printing the table number:%d \n",
			       (i + 1));
			memset(buf, 0x0, BUF_LEN);
			sprintf(buf,
				"\nError in printing the table number:%d \n",
				(i + 1));
			append_to_outbuf(buf);
			free_table(page, i);
			continue;
		}
		if (page->table[i].num_td <= 0) {
			continue;
		}
		draw_table(page, i);
		printf("\n\n");
		memset(buf, 0x0, BUF_LEN);
		sprintf(buf, "\n\n");
		append_to_outbuf(buf);
		free_table(page, i);
	}
	if (page->post_str) {
		printf("\n%s\n", page->post_str);
		memset(buf, 0x0, BUF_LEN);
		print_strs(buf, page->post_str);
		append_to_outbuf(buf);
	}
	free_page(page);
	return outbuf;
}

void draw_table(struct html_page *html_page, int table_id)
{
	int trn = 0;
	int i = 0;
	int border_cnt;
	int line_length = 0;
	char buf[BUF_LEN];

	trn = html_page->table[table_id].num_tr;

	for (i = 0; i < html_page->table[table_id].num_td; i++) {
		line_length +=
		    html_page->table[table_id].td_params_array[i].
		    display_width + 1;
	}

	i = 0;
	while (i < trn) {
		if (html_page->table[table_id].border == 1 ||
		    html_page->table[table_id].tr[i].th == 1) {
			for (border_cnt = 0; border_cnt < line_length;
			     border_cnt++) {
				printf("-");
				memset(buf, 0x0, BUF_LEN);
				sprintf(buf, "-");
				append_to_outbuf(buf);
			}
			printf("\n");
			memset(buf, 0x0, BUF_LEN);
			sprintf(buf, "\n");
			append_to_outbuf(buf);
		}

		draw_tr(&html_page->table[table_id], i);

		if (html_page->table[table_id].tr[i].th == 1 &&
		    html_page->table[table_id].border != 1) {
			for (border_cnt = 0; border_cnt < line_length;
			     border_cnt++) {
				printf("-");
				memset(buf, 0x0, BUF_LEN);
				sprintf(buf, "-");
				append_to_outbuf(buf);
			}
			printf("\n");
			memset(buf, 0x0, BUF_LEN);
			sprintf(buf, "\n");
			append_to_outbuf(buf);
		}
		i++;
	}

	if (html_page->table[table_id].border == 1) {
		for (border_cnt = 0; border_cnt < line_length; border_cnt++) {
			printf("-");
			memset(buf, 0x0, BUF_LEN);
			sprintf(buf, "-");
			append_to_outbuf(buf);
		}
		printf("\n");
		memset(buf, 0x0, BUF_LEN);
		sprintf(buf, "\n");
		append_to_outbuf(buf);
	}

}

int find_alignment(struct table *table, int pos, int col)
{

	if (col < table->tr[pos].num_td &&
	    table->tr[pos].td[col].params.align >= 0) {
		return table->tr[pos].td[col].params.align;
	} else if (pos < table->num_tr && table->tr[pos].params.align >= 0) {
		return table->tr[pos].params.align;
	}
	return ALIGN_LEFT;
}
void draw_tr(struct table *table, int pos)
{
	draw_td(table, pos);
}

void draw_td(struct table *table, int pos)
{
	int i = 0, l = 0;
	int all_printing_done = 0;
	char temp[200] = { '\0' };
	int ncol = -1;
	int newline_flag = FALSE;
	int newline_col_flag = FALSE;
	char buf[BUF_LEN];
	int skip = 0;
	int align = ALIGN_LEFT;

	ncol = table->num_td;

	while (!all_printing_done) {
		all_printing_done = 1;

		for (i = 0; i < ncol; i++) {

			align = find_alignment(table, pos, i);	//find alignment for this col

			if (i == 0 && table->border == 1) {
				printf("|");
				fflush(stdout);
				memset(buf, 0x0, BUF_LEN);
				sprintf(buf, "|");
				append_to_outbuf(buf);
			}

			if (i >= table->tr[pos].num_td ||
			    table->tr[pos].td[i].str == NULL ||
			    (!strcmp(table->tr[pos].td[i].str, ""))) {
				printf("%-*c",
				       table->td_params_array[i].display_width,
				       ' ');
				fflush(stdout);

				memset(buf, 0x0, BUF_LEN);
				sprintf(buf, "%-*c",
					table->td_params_array[i].display_width,
					' ');
				append_to_outbuf(buf);

			} else if (table->tr[pos].td[i].params.computed_width <= table->td_params_array[i].display_width) {	//nowrap/fixed width case/len is less

				if (strchr(table->tr[pos].td[i].str, '\n')) {
					newline_flag = TRUE;
				}

				if (newline_flag == FALSE) {
					printf("%-*s",
					       table->td_params_array[i].
					       display_width,
					       table->tr[pos].td[i].str +
					       table->tr[pos].td[i].params.
					       printed_width);
					fflush(stdout);

					memset(buf, 0x0, BUF_LEN);

					switch (align) {
					case ALIGN_LEFT:
						sprintf(buf, "%-*s",
							table->
							td_params_array[i].
							display_width,
							table->tr[pos].td[i].
							str +
							table->tr[pos].td[i].
							params.printed_width);
						break;

					case ALIGN_RIGHT:
						sprintf(buf, "%*s",
							table->
							td_params_array[i].
							display_width,
							table->tr[pos].td[i].
							str +
							table->tr[pos].td[i].
							params.printed_width);
						break;

					case ALIGN_CENTER:
						if ((table->tr[pos].td[i].
						     params.computed_width -
						     table->tr[pos].td[i].
						     params.printed_width) <
						    table->td_params_array[i].
						    display_width - 1) {
							int len =
							    strlen(table->
								   tr[pos].
								   td[i].str +
								   table->
								   tr[pos].
								   td[i].params.
								   printed_width);
							skip =
							    (table->
							     td_params_array[i].
							     display_width -
							     len) / 2.0;
							snprintf(buf,
								 sizeof(buf),
								 "%-*c%-*s",
								 skip, ' ',
								 table->
								 td_params_array
								 [i].
								 display_width -
								 skip,
								 table->tr[pos].
								 td[i].str +
								 table->tr[pos].
								 td[i].params.
								 printed_width);
						} else {
							sprintf(buf, "%*s",
								table->
								td_params_array
								[i].
								display_width,
								table->tr[pos].
								td[i].str +
								table->tr[pos].
								td[i].params.
								printed_width);
						}
						break;
					default:
						sprintf(buf, "%*s",
							table->
							td_params_array[i].
							display_width,
							table->tr[pos].td[i].
							str +
							table->tr[pos].td[i].
							params.printed_width);
					}

#if 0
					if (table->td_params_array[i].align ==
					    ALIGN_LEFT) {
						sprintf(buf, "%-*s",
							table->
							td_params_array[i].
							display_width,
							table->tr[pos].td[i].
							str +
							table->tr[pos].td[i].
							params.printed_width);
					} else if (table->td_params_array[i].
						   align == ALIGN_RIGHT) {
						sprintf(buf, "%+*s",
							table->
							td_params_array[i].
							display_width,
							table->tr[pos].td[i].
							str +
							table->tr[pos].td[i].
							params.printed_width);
					} else if (table->td_params_array[i].
						   align == ALIGN_CENTER) {
						if ((table->tr[pos].td[i].
						     params.computed_width -
						     table->tr[pos].td[i].
						     params.printed_width) <
						    table->td_params_array[i].
						    display_width - 1) {
							int len =
							    strlen(table->
								   tr[pos].
								   td[i].str +
								   table->
								   tr[pos].
								   td[i].params.
								   printed_width);
							skip =
							    (table->
							     td_params_array[i].
							     display_width -
							     len) / 2.0;
							sprintf(buf, "%-*c%-*s",
								skip, ' ',
								table->
								td_params_array
								[i].
								display_width -
								skip,
								table->tr[pos].
								td[i].str +
								table->tr[pos].
								td[i].params.
								printed_width);
						} else {
							sprintf(buf, "%*s",
								table->
								td_params_array
								[i].
								display_width,
								table->tr[pos].
								td[i].str +
								table->tr[pos].
								td[i].params.
								printed_width);
						}
					} else {
						sprintf(buf, "%*s",
							table->
							td_params_array[i].
							display_width,
							table->tr[pos].td[i].
							str +
							table->tr[pos].td[i].
							params.printed_width);
					}
#endif

					append_to_outbuf(buf);
//                                      table->tr[pos].td[i].str = NULL;
					memset(table->tr[pos].td[i].str, 0x00,
					       strlen(table->tr[pos].td[i].
						      str));
				} else {	/*  new line exits in less len/nowrap/fixed-width string */
					int str_done = FALSE;
					for (l =
					     table->tr[pos].td[i].params.
					     printed_width;
					     l <
					     table->tr[pos].td[i].params.
					     computed_width - 1; l++) {
						if (table->tr[pos].td[i].
						    str[l] == '\0') {
							str_done = TRUE;
							break;
						}

						if (table->tr[pos].td[i].
						    str[l] == '\n') {
							break;
						}
					}
					if (str_done) {
						strncpy(temp,
							table->tr[pos].td[i].
							str +
							table->tr[pos].td[i].
							params.printed_width,
							sizeof(temp));
					} else {
						strncpy(temp,
							table->tr[pos].td[i].
							str +
							table->tr[pos].td[i].
							params.printed_width,
							(l -
							 table->tr[pos].td[i].
							 params.printed_width));
						temp[l -
						     table->tr[pos].td[i].
						     params.printed_width] =
						    '\0';
					}
					printf("%-*s",
					       table->td_params_array[i].
					       display_width, temp);
					fflush(stdout);
					memset(buf, 0x0, BUF_LEN);
					switch (align) {
					case ALIGN_LEFT:
						sprintf(buf, "%-*s",
							table->
							td_params_array[i].
							display_width, temp);
						break;
					case ALIGN_RIGHT:
						sprintf(buf, "%*s",
							table->
							td_params_array[i].
							display_width, temp);
						break;
					case ALIGN_CENTER:
						if ((table->tr[pos].td[i].
						     params.computed_width -
						     table->tr[pos].td[i].
						     params.printed_width) <
						    table->td_params_array[i].
						    display_width - 1) {
							int len = strlen(temp);
							skip =
							    (table->
							     td_params_array[i].
							     display_width -
							     len) / 2.0;
							sprintf(buf, "%-*c%-*s",
								skip, ' ',
								table->
								td_params_array
								[i].
								display_width -
								skip, temp);
						} else {
							sprintf(buf, "%*s",
								table->
								td_params_array
								[i].
								display_width,
								temp);
						}
						break;
					default:
						sprintf(buf, "%*s",
							table->
							td_params_array[i].
							display_width, temp);
					}

#if 0
					if (table->td_params_array[i].align ==
					    ALIGN_LEFT) {
						sprintf(buf, "%-*s",
							table->
							td_params_array[i].
							display_width, temp);
					} else if (table->td_params_array[i].
						   align == ALIGN_RIGHT) {
						sprintf(buf, "%+*s",
							table->
							td_params_array[i].
							display_width, temp);
					} else if (table->td_params_array[i].
						   align == ALIGN_CENTER) {
						if ((table->tr[pos].td[i].
						     params.computed_width -
						     table->tr[pos].td[i].
						     params.printed_width) <
						    table->td_params_array[i].
						    display_width - 1) {
							int len = strlen(temp);
							skip =
							    (table->
							     td_params_array[i].
							     display_width -
							     len) / 2.0;
							sprintf(buf, "%-*c%-*s",
								skip, ' ',
								table->
								td_params_array
								[i].
								display_width -
								skip, temp);
						} else {
							sprintf(buf, "%*s",
								table->
								td_params_array
								[i].
								display_width,
								temp);
						}
					} else {
						sprintf(buf, "%*s",
							table->
							td_params_array[i].
							display_width, temp);
					}
#endif

					append_to_outbuf(buf);

					if (!str_done) {
						table->tr[pos].td[i].params.
						    printed_width +=
						    (l -
						     table->tr[pos].td[i].
						     params.printed_width) + 1;
						if (table->tr[pos].td[i].params.
						    printed_width <
						    table->tr[pos].td[i].params.
						    computed_width) {
							all_printing_done = 0;
						} else {
//                                                      table->tr[pos].td[i].str = NULL;
							memset(table->tr[pos].
							       td[i].str, 0x00,
							       strlen(table->
								      tr[pos].
								      td[i].
								      str));
						}
					} else {
//                                              table->tr[pos].td[i].str = NULL;
						memset(table->tr[pos].td[i].str,
						       0x00,
						       strlen(table->tr[pos].
							      td[i].str));
					}
				}

			} else {	// wrap case computed_width > display_width

				if (strchr(table->tr[pos].td[i].str, '\n')) {
					newline_flag = TRUE;
				}
				if (newline_flag == FALSE) {	//no newline wrap case

					strncpy(temp,
						table->tr[pos].td[i].str +
						table->tr[pos].td[i].params.
						printed_width,
						table->td_params_array[i].
						display_width);

					temp[table->td_params_array[i].
					     display_width] = '\0';

					printf("%-*s",
					       table->td_params_array[i].
					       display_width, temp);
					fflush(stdout);
					memset(buf, 0x0, BUF_LEN);
					switch (align) {
					case ALIGN_LEFT:
						sprintf(buf, "%-*s",
							table->
							td_params_array[i].
							display_width, temp);
						break;
					case ALIGN_RIGHT:
						sprintf(buf, "%*s",
							table->
							td_params_array[i].
							display_width, temp);
						break;
					case ALIGN_CENTER:
						if ((table->tr[pos].td[i].
						     params.computed_width -
						     table->tr[pos].td[i].
						     params.printed_width) <
						    table->td_params_array[i].
						    display_width - 1) {
							int len = strlen(temp);
							skip =
							    (table->
							     td_params_array[i].
							     display_width -
							     len) / 2.0;
							sprintf(buf, "%-*c%-*s",
								skip, ' ',
								table->
								td_params_array
								[i].
								display_width -
								skip, temp);
						} else {
							sprintf(buf, "%*s",
								table->
								td_params_array
								[i].
								display_width,
								temp);
						}
						break;
					default:
						sprintf(buf, "%*s",
							table->
							td_params_array[i].
							display_width, temp);
					}
#if 0
					if (table->td_params_array[i].align ==
					    ALIGN_LEFT) {
						sprintf(buf, "%-*s",
							table->
							td_params_array[i].
							display_width, temp);
					} else if (table->td_params_array[i].
						   align == ALIGN_RIGHT) {
						sprintf(buf, "%+*s",
							table->
							td_params_array[i].
							display_width, temp);
					} else if (table->td_params_array[i].
						   align == ALIGN_CENTER) {
						if ((table->tr[pos].td[i].
						     params.computed_width -
						     table->tr[pos].td[i].
						     params.printed_width) <
						    table->td_params_array[i].
						    display_width - 1) {
							int len = strlen(temp);
							skip =
							    (table->
							     td_params_array[i].
							     display_width -
							     len) / 2.0;
							sprintf(buf, "%-*c%-*s",
								skip, ' ',
								table->
								td_params_array
								[i].
								display_width -
								skip, temp);
						} else {
							sprintf(buf, "%*s",
								table->
								td_params_array
								[i].
								display_width,
								temp);
						}
					} else {
						sprintf(buf, "%*s",
							table->
							td_params_array[i].
							display_width, temp);
					}
#endif
					append_to_outbuf(buf);

					table->tr[pos].td[i].params.
					    printed_width +=
					    table->td_params_array[i].
					    display_width;
					if (table->tr[pos].td[i].params.
					    printed_width <
					    table->tr[pos].td[i].params.
					    computed_width) {
						all_printing_done = 0;
					} else {
//                                              table->tr[pos].td[i].str = NULL;
						memset(table->tr[pos].td[i].str,
						       0x00,
						       strlen(table->tr[pos].
							      td[i].str));
					}
				} else {	//new line is there  wrap case
					int str_done = FALSE;
					newline_col_flag = FALSE;

					for (l =
					     table->tr[pos].td[i].params.
					     printed_width;
					     l <
					     table->tr[pos].td[i].params.
					     printed_width +
					     table->td_params_array[i].
					     display_width; l++) {
						if (table->tr[pos].td[i].
						    str[l] == '\0') {
							str_done = TRUE;
							break;
						}

						if (table->tr[pos].td[i].
						    str[l] == '\n') {
							newline_col_flag = TRUE;
							break;
						}
					}
					if (str_done) {
						strcpy(temp,
						       table->tr[pos].td[i].
						       str +
						       table->tr[pos].td[i].
						       params.printed_width);
					} else {
						strncpy(temp,
							table->tr[pos].td[i].
							str +
							table->tr[pos].td[i].
							params.printed_width,
							l -
							table->tr[pos].td[i].
							params.printed_width);

						temp[l -
						     table->tr[pos].td[i].
						     params.printed_width] =
						    '\0';
					}

					printf("%-*s",
					       table->td_params_array[i].
					       display_width, temp);
					fflush(stdout);
					memset(buf, 0x0, BUF_LEN);
					switch (align) {

					case ALIGN_LEFT:
						sprintf(buf, "%-*s",
							table->
							td_params_array[i].
							display_width, temp);
						break;
					case ALIGN_RIGHT:
						sprintf(buf, "%*s",
							table->
							td_params_array[i].
							display_width, temp);
						break;
					case ALIGN_CENTER:
						if ((table->tr[pos].td[i].
						     params.computed_width -
						     table->tr[pos].td[i].
						     params.printed_width) <
						    table->td_params_array[i].
						    display_width - 1) {
							int len = strlen(temp);
							skip =
							    (table->
							     td_params_array[i].
							     display_width -
							     len) / 2.0;
							sprintf(buf, "%-*c%-*s",
								skip, ' ',
								table->
								td_params_array
								[i].
								display_width -
								skip, temp);
						} else {
							sprintf(buf, "%*s",
								table->
								td_params_array
								[i].
								display_width,
								temp);
						}
						break;
					default:
						sprintf(buf, "%*s",
							table->
							td_params_array[i].
							display_width, temp);
					}
#if 0
					if (table->td_params_array[i].align ==
					    ALIGN_LEFT) {
						sprintf(buf, "%-*s",
							table->
							td_params_array[i].
							display_width, temp);
					} else if (table->td_params_array[i].
						   align == ALIGN_RIGHT) {
						sprintf(buf, "%+*s",
							table->
							td_params_array[i].
							display_width, temp);
					} else if (table->td_params_array[i].
						   align == ALIGN_CENTER) {
						if ((table->tr[pos].td[i].
						     params.computed_width -
						     table->tr[pos].td[i].
						     params.printed_width) <
						    table->td_params_array[i].
						    display_width - 1) {
							int len = strlen(temp);
							skip =
							    (table->
							     td_params_array[i].
							     display_width -
							     len) / 2.0;
							sprintf(buf, "%-*c%-*s",
								skip, ' ',
								table->
								td_params_array
								[i].
								display_width -
								skip, temp);
						} else {
							sprintf(buf, "%*s",
								table->
								td_params_array
								[i].
								display_width,
								temp);
						}
					} else {
						sprintf(buf, "%*s",
							table->
							td_params_array[i].
							display_width, temp);
					}
#endif

					append_to_outbuf(buf);

					if (!str_done) {
						if (newline_col_flag == TRUE) {
							table->tr[pos].td[i].
							    params.
							    printed_width +=
							    (l -
							     table->tr[pos].
							     td[i].params.
							     printed_width) + 1;
						} else {
							table->tr[pos].td[i].
							    params.
							    printed_width +=
							    (l -
							     table->tr[pos].
							     td[i].params.
							     printed_width);
						}
						if (table->tr[pos].td[i].params.
						    printed_width <
						    table->tr[pos].td[i].params.
						    computed_width) {
							all_printing_done = 0;
						} else {
//                                                      table->tr[pos].td[i].str = NULL;
							memset(table->tr[pos].
							       td[i].str, 0x00,
							       strlen(table->
								      tr[pos].
								      td[i].
								      str));
						}
					} else {
//                                              table->tr[pos].td[i].str = NULL;
						memset(table->tr[pos].td[i].str,
						       0x00,
						       strlen(table->tr[pos].
							      td[i].str));
					}
				}

			}

			if (table->border == 1) {
				printf("|");
				fflush(stdout);
				memset(buf, 0x0, BUF_LEN);
				sprintf(buf, "|");
				append_to_outbuf(buf);

			} else {
				printf(" ");
				fflush(stdout);
				memset(buf, 0x0, BUF_LEN);
				sprintf(buf, " ");
				append_to_outbuf(buf);
			}
			if (i == ncol - 1) {
				printf("\n");
				fflush(stdout);
				memset(buf, 0x0, BUF_LEN);
				sprintf(buf, "\n");
				append_to_outbuf(buf);
			}

		}

	}

}

void replace_tabs(struct table *table)
{
	int i, j;
	for (i = 0; i < table->num_tr; i++) {
		for (j = 0; j < table->tr[i].num_td; j++) {
			if (!strchr(table->tr[i].td[j].str, '\t')) {
				continue;
			}
			//may 6 , chandrav --to fix free(pre_str) crash 
			//remove_tabs_from_str(&table->tr[i].td[j].str);
			remove_non_html_chars(table->tr[i].td[j].str, "\t");

		}
	}
}

int ifx_compute_td_params(struct table *table)
{
	int i, j, k, l;
	int maxcols = -1;
	int ncol = -1;
	int fixed_len = 0;
	int num_fixed_cols = 0;
	int max = -999;
	float scaling_factor = 1;
	int row_percent_width = 0;
	int col_width_flag = FALSE;
	char buf[BUF_LEN];
	int nowrap_done = FALSE;
	int width_done = FALSE;

	col_var_len = 0;

	/* find table width */
	if (table->table_width > 0) {
		if (table->table_width > g_ifx_screen_width) {
			g_ifx_screen_width_table =
			    table->table_width * g_ifx_screen_width / 1024;
		} else {
			g_ifx_screen_width_table = table->table_width;
		}

	} else if (table->table_width < 0) {
		if (table->table_width < -100) {
			printf("Error ..wrong table width specification\n");
			memset(buf, 0x0, BUF_LEN);
			sprintf(buf,
				"Error.. wrong table width specification\n");
			append_to_outbuf(buf);
			return -1;
		}
		g_ifx_screen_width_table =
		    -1 * g_ifx_screen_width * table->table_width / 100;
	} else {
		g_ifx_screen_width_table = g_ifx_screen_width;
	}
	/* fill number of cols */
	for (i = 0; i < table->num_tr; i++) {
		if (table->tr[i].num_td > maxcols) {
			maxcols = table->tr[i].num_td;
		}
	}
	table->num_td = maxcols;	/* store the max num of columns */
	ncol = table->num_td;
	if (ncol <= 0) {
		return 0;
	}

	/* repalce tabs in all strings */
	replace_tabs(table);

	/* compute the width of each column */
	for (i = 0; i < table->num_tr; i++) {
		for (j = 0; j < table->tr[i].num_td; j++) {
			table->tr[i].td[j].params.computed_width =
			    strlen(table->tr[i].td[j].str) + 1;
			table->tr[i].td[j].params.printed_width = 0;
			table->tr[i].td[j].params.display_width = 0;

		}
	}
	/* memory allocation for td_params_array */
	table->td_params_array = (struct td_params *)
	    malloc((table->num_td) * sizeof(struct td_params));
	if (!(table->td_params_array)) {
		printf("\nError No free memory... Exiting...\n");
		exit(1);
		//memset(buf,0x0,BUF_LEN);
		//sprintf(buf,"\nError malloc failure..no free memory\n");
		//append_to_outbuf(buf);
		//return -1;
	}
	memset(table->td_params_array, 0,
	       (table->num_td) * sizeof(struct td_params));

	row_percent_width = 0;
	/*fill in td_params_array */

#if 0

	for (i = 0; i < table->num_td; i++) {
		for (j = 0; j < table->num_tr; j++) {
			//may2 chandrav
			if (j == 0 && i < table->tr[j].num_td &&	//take whatever is there in 1st row
			    table->tr[j].td[i].params.align != -1) {
				table->td_params_array[i].align =
				    table->tr[j].td[i].params.align;
			}

			if (i < table->tr[j].num_td &&
			    table->tr[j].td[i].params.nowrap != -1) {
				table->td_params_array[i].nowrap =
				    table->tr[j].td[i].params.nowrap;
			}

			if (i < table->tr[j].num_td &&
			    table->tr[j].td[i].params.width > 0) {
				table->td_params_array[i].width =
				    table->tr[j].td[i].params.width;
			} else if (i < table->tr[j].num_td &&
				   table->tr[j].td[i].params.width < 0) {

				if (table->tr[j].td[i].params.width < -100) {
					printf
					    ("Error. Wrong column width specification\n");
					return -1;

				}
				table->td_params_array[i].width =
				    -1 * g_ifx_screen_width_table *
				    (table->tr[j].td[i].params.width) / 100.0;
			}
		}		/* end of for (j =0 ... */
		//may 3 chandrav
		//row_percent_width +=table->tr[j-1].td[i].params.width ;
		if (table->td_params_array[i].width < 0) {
			row_percent_width += table->td_params_array[i].width;
		}
	}			/* end of for (i =0 ...) */
#endif

	/* we read all the parameters whatever is there in the first available column
	   and use the same for rest of the corresponding columns */
#if 1
	for (i = 0; i < table->num_td; i++) {

		//align_done = 0;
		nowrap_done = 0;
		width_done = 0;

		for (j = 0; j < table->num_tr; j++) {

			//may5 chandrav
#if 0
			if (align_done == 0 &&
			    i < table->tr[j].num_td &&
			    table->tr[j].td[i].params.align != -1) {
				table->td_params_array[i].align =
				    table->tr[j].td[i].params.align;
				align_done = 1;
			}
#endif

			if (nowrap_done == 0 &&
			    i < table->tr[j].num_td &&
			    table->tr[j].td[i].params.nowrap != -1) {
				table->td_params_array[i].nowrap =
				    table->tr[j].td[i].params.nowrap;
				nowrap_done = 1;
			}
			if (width_done == 0) {
				if (i < table->tr[j].num_td &&
				    table->tr[j].td[i].params.width > 0) {
					table->td_params_array[i].width =
					    table->tr[j].td[i].params.width;
					width_done = 1;
				} else if (i < table->tr[j].num_td &&
					   table->tr[j].td[i].params.width <
					   0) {
					if (table->tr[j].td[i].params.width <
					    -100) {
						printf
						    ("Error. Wrong column width specification\n");
						return -1;
					}
					table->td_params_array[i].width =
					    -1 * g_ifx_screen_width_table *
					    (table->tr[j].td[i].params.width) /
					    100.0;
					width_done = 1;
				}
			}
		}		/* end of for (j =0 ... */

		//may 3 chandrav
		//row_percent_width +=table->tr[j-1].td[i].params.width ;
		if (table->td_params_array[i].width < 0) {
			row_percent_width += table->td_params_array[i].width;
		}
	}			/* end of for (i =0 ...) */
#endif

	if (row_percent_width < -100) {
		scaling_factor = -100.0 / (float)row_percent_width;
		for (k = 0; k < table->num_td; k++) {
			table->td_params_array[k].width *= scaling_factor;
		}
	}

	scaling_factor = 1;
	for (k = 0; k < table->num_td; k++) {
		max = -999;
		if (table->td_params_array[k].nowrap == 1) {
			for (l = 0; l < table->num_tr; l++) {
				//chandrav apr28
				if (k < table->tr[l].num_td) {
					if (table->tr[l].td[k].params.
					    computed_width > max) {
						max =
						    table->tr[l].td[k].params.
						    computed_width;
					}
				}
			}
			table->td_params_array[k].display_width = max;
			fixed_len += table->td_params_array[k].display_width;
			num_fixed_cols++;

		} else if (table->td_params_array[k].width != 0) {
			fixed_len += (table->td_params_array[k].width) + 1;
			table->td_params_array[k].display_width =
			    table->td_params_array[k].width;
			num_fixed_cols++;
		}

	}

	if (fixed_len + ncol > g_ifx_screen_width_table) {
		for (k = 0; k < table->num_td; k++) {
			if (table->td_params_array[k].display_width >=
			    g_ifx_screen_width_table) {
				col_width_flag = TRUE;
				break;
			}
		}
		if (col_width_flag) {
			scaling_factor = g_ifx_screen_width_table / 1024.0;
		} else {
			scaling_factor =
			    (float)g_ifx_screen_width_table /
			    (float)(fixed_len + ncol);
		}
	}

	for (k = 0; k < table->num_td; k++) {
		table->td_params_array[k].display_width *= scaling_factor;
	}
	if (scaling_factor != 1) {
		fixed_len = fixed_len * scaling_factor - 1;
	} else {
		fixed_len *= scaling_factor;
	}

	/* compute the display width for each column */
	if (table->border == 1) {
		if (ncol > num_fixed_cols) {
			if (g_ifx_screen_width_table - fixed_len - ncol <= 0) {
				printf
				    ("Error 1:table length is more than screen width\n");
				memset(buf, 0x0, BUF_LEN);
				sprintf(buf,
					"Error 1:table length is more than screen width\n");
				append_to_outbuf(buf);
				return -1;
			}
			col_var_len =
			    (g_ifx_screen_width_table - fixed_len -
			     ncol) / (ncol - num_fixed_cols);
		} else if (ncol < num_fixed_cols) {
			col_var_len = 0;
			if (fixed_len > g_ifx_screen_width_table) {
				printf
				    ("Error 2:table length is more than screen width\n");
				memset(buf, 0x0, BUF_LEN);
				sprintf(buf,
					"Error 2:table length is more than screen width\n");
				append_to_outbuf(buf);
				return -1;
			}
		} else {
			if (g_ifx_screen_width_table - fixed_len - ncol < 0) {
				printf
				    ("Error 3:table length is more than screen width\n");
				memset(buf, 0x0, BUF_LEN);
				sprintf(buf,
					"Error 3:table length is more than screen width\n");
				append_to_outbuf(buf);
				return -1;
			}
			col_var_len = 0;
		}
	} else {
		if (ncol > num_fixed_cols) {
			if (g_ifx_screen_width_table - fixed_len - ncol <= 0) {
				printf
				    ("Error 1:table length is more than screen width\n");
				memset(buf, 0x0, BUF_LEN);
				sprintf(buf,
					"Error 1:table length is more than screen width\n");
				append_to_outbuf(buf);
				return -1;
			}
			col_var_len =
			    (g_ifx_screen_width_table - fixed_len -
			     ncol) / (ncol - num_fixed_cols);
		} else if (ncol < num_fixed_cols) {
			col_var_len = 0;
			if (fixed_len > g_ifx_screen_width_table) {
				printf
				    ("Error 2:table length is more than screen width\n");
				memset(buf, 0x0, BUF_LEN);
				sprintf(buf,
					"Error 2:table length is more than screen width\n");
				append_to_outbuf(buf);
				return -1;
			}

		} else {
			if (g_ifx_screen_width_table - fixed_len - ncol < 0) {
				printf
				    ("Error 3:table length is more than screen width\n");
				memset(buf, 0x0, BUF_LEN);
				sprintf(buf,
					"Error 3:table length is more than screen width\n");
				append_to_outbuf(buf);
				return -1;
			}
			col_var_len = 0;
		}
	}

	if (col_var_len < 0 || col_var_len > g_ifx_screen_width_table) {
		printf("Error: table column length is out of bounds\n");
		memset(buf, 0x0, BUF_LEN);
		sprintf(buf, "Error: table column length is out of bounds\n");
		append_to_outbuf(buf);
		return -1;
	}
	for (k = 0; k < table->num_td; k++) {
		if (table->td_params_array[k].display_width == 0) {
			table->td_params_array[k].display_width = col_var_len;
		}
	}
	return 0;

}

#if 0
int main()
{
	struct html_page *html_page;

	html_page = (struct html_page *)malloc(sizeof(struct html_page));
	html_page->table = (struct table *)malloc(2 * sizeof(struct table));
	memset(html_page->table, 0, 2 * sizeof(struct table));
	html_page->num_tables = 2;

	html_page->table[0].table_width = 60;
	html_page->table[0].num_tr = 2;
	html_page->table[0].border = 1;
	html_page->table[0].td_params_array = (struct td_params *)
	    malloc(3 * sizeof(struct td_params));
	memset(html_page->table[0].td_params_array, 0,
	       3 * sizeof(struct td_params));
//html_page->table[0].td_params_array[1].nowrap = 1;
//html_page->table[0].td_params_array[1].width = 5;

	html_page->table[0].tr = (struct tr *)malloc(2 * sizeof(struct tr));
	html_page->table[0].tr[0].num_td = 3;
	html_page->table[0].tr[0].td =
	    (struct td *)malloc(3 * sizeof(struct td));
	memset(html_page->table[0].tr[0].td, 0, 3 * sizeof(struct td));

	html_page->table[0].tr[0].td[0].params.width = 5;
	html_page->table[0].tr[0].td[1].params.width = 5;
	html_page->table[0].tr[0].td[2].params.width = -10;

//html_page->table[0].tr[0].td[1].params.nowrap = 1;

	html_page->table[0].tr[0].td[0].str = (char *)malloc(100);
	html_page->table[0].tr[0].td[1].str = (char *)malloc(100);
	html_page->table[0].tr[0].td[2].str = (char *)malloc(100);

	strcpy(html_page->table[0].tr[0].td[0].str, "iamchandravhow");
	strcpy(html_page->table[0].tr[0].td[1].str, "canwedothis");
	strcpy(html_page->table[0].tr[0].td[2].str, "wecandoit");

	html_page->table[0].tr[1].num_td = 3;
	html_page->table[0].tr[1].td =
	    (struct td *)malloc(3 * sizeof(struct td));
	memset(html_page->table[0].tr[1].td, 0, 3 * sizeof(struct td));

	html_page->table[0].tr[1].td[0].str = (char *)malloc(100);
	html_page->table[0].tr[1].td[1].str = (char *)malloc(100);
	html_page->table[0].tr[1].td[2].str = (char *)malloc(100);

	strcpy(html_page->table[0].tr[1].td[0].str, "BB");
	strcpy(html_page->table[0].tr[1].td[1].str, "CCCHow_AreUUUIIIIUU");
	strcpy(html_page->table[0].tr[1].td[2].str, "DEFI_AM_GREAT");

/////////////
	html_page->table[1].table_width = 40;
	html_page->table[1].num_tr = 2;
	html_page->table[1].border = 1;
	html_page->table[1].td_params_array = (struct td_params *)
	    malloc(3 * sizeof(struct td_params));
	memset(html_page->table[1].td_params_array, 0,
	       3 * sizeof(struct td_params));

	html_page->table[1].tr = (struct tr *)malloc(2 * sizeof(struct tr));
	html_page->table[1].tr[0].num_td = 2;
	html_page->table[1].tr[0].td =
	    (struct td *)malloc(3 * sizeof(struct td));
	memset(html_page->table[1].tr[0].td, 0, 3 * sizeof(struct td));

	html_page->table[1].tr[0].td[0].params.width = 15;
//html_page->table[1].tr[0].td[1].params.nowrap = 1;

	html_page->table[1].tr[0].td[0].str = (char *)malloc(100);
	html_page->table[1].tr[0].td[1].str = (char *)malloc(100);
	html_page->table[1].tr[0].td[2].str = NULL;	//(char *)malloc(100);

	strcpy(html_page->table[1].tr[0].td[0].str, "222iamchandravhow");
	strcpy(html_page->table[1].tr[0].td[1].str, "222canwedothis");
//strcpy(html_page->table[1].tr[0].td[2].str,"222wecandoit");

	html_page->table[1].tr[1].num_td = 3;
	html_page->table[1].tr[1].td =
	    (struct td *)malloc(3 * sizeof(struct td));
	memset(html_page->table[1].tr[1].td, 0, 3 * sizeof(struct td));

	html_page->table[1].tr[1].td[0].str = (char *)malloc(100);
	html_page->table[1].tr[1].td[1].str = (char *)malloc(100);
	html_page->table[1].tr[1].td[2].str = (char *)malloc(100);

	strcpy(html_page->table[1].tr[1].td[0].str, "222BB");
	strcpy(html_page->table[1].tr[1].td[1].str, "222CCCHow_AreUUUIIIIUU");
	strcpy(html_page->table[1].tr[1].td[2].str, "222DEFI_AM_GREAT");

//draw_table(table);
	draw_html_page(html_page, 70);
}
#endif
