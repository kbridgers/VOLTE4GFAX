
#include "tr69_menu_func.h"

struct value_set tr69_setting_set_cmd_fields_values[] = {

	{.display_value = "disable",.submit_value = "0"},
	{.display_value = "enable",.submit_value = "1"}
};

struct cmd_field tr69_setting_set_cmd_fields[] = {
	{
	 .field_name = "TR69_ON",
	 .field_help = "TR-69",
	 .data_type = INT,
	 .field_type = STATIC,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "tr69_on",
	 .field_gui_name = "TR-69",
	 .values = tr69_setting_set_cmd_fields_values,
	 .tot_values =
	 sizeof(tr69_setting_set_cmd_fields_values) / sizeof(struct value_set)
	 }
	,
	{
	 .field_name = "AAUTH",
	 .field_help = "ACS Authenticate",
	 .data_type = INT,
	 .field_type = STATIC,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "aauth",
	 .field_gui_name = "ACS Authenticate",
	 .values = tr69_setting_set_cmd_fields_values,
	 .tot_values =
	 sizeof(tr69_setting_set_cmd_fields_values) / sizeof(struct value_set)
	 }
	,
	{
	 .field_name = "AURL",
	 .field_help = "ACS URL",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "aurl",
	 .field_gui_name = "ACS URL"}
	,
	{
	 .field_name = "AUN",
	 .field_help = "ACS Username",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "aun",
	 .field_gui_name = "ACS Username"}
	,
	{
	 .field_name = "APW",
	 .field_help = "ACS Password",
	 .data_type = PASSWD,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "apw",
	 .field_gui_name = "ACS Password"}
	,
	{
	 .field_name = "CRUN",
	 .field_help = "ConnectionRequest Username",
	 .data_type = STR,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "crun",
	 .field_gui_name = "ConnectionRequest Username"}
	,
	{
	 .field_name = "CRPW",
	 .field_help = "ConnectionRequest Password",
	 .data_type = PASSWD,
	 .field_type = USR_DEF,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "crpw",
	 .field_gui_name = "ConnectionRequest Password"}
	,
	{
	 .field_name = "TR64_ON",
	 .field_help = "TR-64",
	 .data_type = INT,
	 .field_type = STATIC,
	 .mandatory = IFX_TRUE,
	 .field_display_name = "tr64_on",
	 .field_gui_name = "TR-64",
	 .values = tr69_setting_set_cmd_fields_values,
	 .tot_values =
	 sizeof(tr69_setting_set_cmd_fields_values) / sizeof(struct value_set)
	 }

};

struct cmd_entry tr69_setting_set_cmd = {
	.fields = tr69_setting_set_cmd_fields,
	.tot_fields =
	    sizeof(tr69_setting_set_cmd_fields) / sizeof(struct cmd_field),
	.help = "This command allows user to change the configuration of TR69",
	.post_url = "/goform/ifx_set_tr69_mgmtserver",
};

struct menu_entry tr69_page_entries[] = {
	{
	 .entry_help =
	 "This entry allows user to set the current configuration of TR69",
	 .cli_name = "Set",
	 .cmd = &tr69_setting_set_cmd},
	{
	 .entry_help = "This entry shows TR69 configuration",
	 .cli_name = "Show",
	 .cli_url = "tr69.cli"}
};

struct menu_page tr69_page = {
	.entries = tr69_page_entries,
	.tot_entries = sizeof(tr69_page_entries) / sizeof(struct menu_entry),
	.page_help = "This is TR69 page",
	.cli_title = "tr69",
	.gui_title = "TR69"
};
