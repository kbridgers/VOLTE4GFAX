/**************************************************************************
 **   SRC_FILE          : MT_T38_caps.h
 **   PROJECT           : T.38 Fax Relay
 **   MODULES           :
 **   SRC VERSION       : v1.0
 **   DATE              : 15-04-2003
 **   AUTHOR            : Andrew Matveyev, Sergey Boidenko
 **   DESCRIPTION       : T38 capabilities definition
 **   FUNCTIONS         :
 **   COMPILER          :
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : "METASOFT" SIA 1997-2005

 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
***********************************************************************/

#ifndef __MT_T38_CAPS_H__
#define __MT_T38_CAPS_H__

/* Capability types */
typedef enum {
  MT_T38_CapType_TCP,   /* TCP capabilities */
  MT_T38_CapType_UDP    /* UDP capabilities */
} e_MT_T38_CapType;

#define MT_T38CAP_FL_TCF_LOCAL             0x01
#define MT_T38CAP_FL_TCF_TRANSFERRED       0x02

#define MT_T38CAP_FL_OPT_FILL_BIT_REMOVAL  0x0001
#define MT_T38CAP_FL_OPT_TRANSCODING_MMR   0x0002
#define MT_T38CAP_FL_OPT_TRANSCODING_JBIG  0x0004

#define MT_T38CAP_FL_EC_REDUNDANCY         0x01
#define MT_T38CAP_FL_EC_FEC                0x02

/* T38 capabilities */
typedef struct {
  /* capability type */
  uint32         uiTransportProtocol;
  uchar8         ucVersion;
  /* GetCapabilities: any combination of MT_T38CAP_FL_TCF_XXX values *
   * SessionCapabilities: one of MT_T38CAP_FL_TCF_XXX values         */
  uchar8         ucRateManagement;
  /* units 100 bit/s */
  uint16         unMaxBitRate;
  /* any combination of MT_T38CAP_FL_OPT_XXX values */
  uint32         uiBitOptions;
  /* UDP options */
  uint16         unUDPMaxBufferSize;
  uint16         unUDPMaxDatagramSize;
  /* GetCapabilities: any combination of MT_T38CAP_FL_EC_XXX values *
   * SessionCapabilities: one of MT_T38CAP_FL_EC_XXX values         */
  uchar8         ucUDPErrCorrection;

} x_MT_T38_Caps;

#endif /*__MT_T38_CAPS_H__*/
