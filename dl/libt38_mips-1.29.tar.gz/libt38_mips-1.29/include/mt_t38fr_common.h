/**************************************************************************
 **   SRC_FILE          : MT_T38FR_Common.h
 **   PROJECT           : Fax Relay
 **   MODULES           : For all modules in T.38 Fax Relay
 **   SRC VERSION       : v1.0
 **   DATE              : 18-12-2006
 **   AUTHOR            : Andrew Matveyev, Sergey Boidenko
 **   DESCRIPTION       : T.38 Fax Relay common definitions.
 **   FUNCTIONS         :
 **   COMPILER          :
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : "METASOFT" SIA 1997-2010

 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
***********************************************************************/

#ifndef __MT_T38FR_COMMON_H__
#define __MT_T38FR_COMMON_H__

#include "ifx_common_defs.h"

   /*** T38 build version ***/
#define MT_T38_MAJOR_VERSION       1
#define MT_T38_MINOR_VERSION       29

   /*** Compiler specific features ***/
#define _NOPAR(p)     (void)(p)   /*unused parameter*/

#ifndef MT_T38_MAX_CHANNELS
#warning "MT_T38_MAX_CHANNELS is default!"
#define MT_T38_MAX_CHANNELS        8  /*max number of channels*/
#endif

   /*** Modules context sizes ***/
#define MT_T38PCK_CTX_SIZE  7u*256u+86u    /*T38 packet encoder/decoder (in dwords)*/
#define MT_T38_CTX_SIZE     12u*256u+128u  /*T38 (in dwords)*/


   /*** T.38 Settings ***/
#define MT_T38_DBM_LEVEL_DEFAULT   10     /*default Fax signal level*/
#define MT_T38_UDP_BUILD           1      /*UDP support*/
#define MT_T38_UDP_CHECK           1      /*UDP build with additional packet structure check */
#define MT_T38_REDUNDANCY_FEC      1      /*FEC recovering in UDP support*/
#define MT_T38_REDUNDANCY_PCK_MAX  4      /*max recovery IFP packets for encoding*/
#define MT_T38_UDP_MAX_FECS        3      /*max FEC packets for encoding*/
#define MT_T38_UDP_TOTAL_PACKETS_IN_FECS  6 /*Max packets in FECs for encoding
                                             *(udpErrRecoveryPackets * udpPriorPacketsForFEC)
                                             */
#define MT_T38_DYNAMIC_MEM         0      /*dynamic buffer memory allocation*/
#define MT_T38_TXBUFF_MAX          480    /*maximal IFP size to transmit
                                           *(for max indication size 2048)
                                           */
#define MT_T38_AUTOSTART_MOD       1      /*support of automatic modulation of
                                           *V.21 responses*/
#define MT_T38_STATISTICS          1      /*collect T38 statistics*/
#ifndef MT_T38_SWAP_MESSAGES
#warning "MT_T38_SWAP_MESSAGES is default!"
#define MT_T38_SWAP_MESSAGES       0      /*byte order within the words of the
                                           *DSP message data field. If 1, all
                                           *bytes, except the first 4, in DSP
                                           *messages are swapped.
                                           */
#endif /* MT_T38_SWAP_MESSAGES */
#ifndef MT_T38_DATA_PLD_FMT
#warning "MT_T38_DATA_PLD_FMT is default!"
#define MT_T38_DATA_PLD_FMT        1      /* 0 - VINETIC format, 1 - MIPS 24Kec format*/
#endif /* MT_T38_DATA_PLD_FMT */
#define MT_T38_DELAY_SIGEND        0      /*Customer specific feature
                                            sigend will be joined with last data and
                                            delay in IP will be added between last two data packets
                                            length of delay will depends from data in last packet
                                            */
#define MT_T38_DELAY_NOSIGNAL      0      /*Customer specific feature
                                            nosignal indicator will be delayed */
#define MT_T38_HEARTBEAT           0      /*heartbeat*/
#define MT_T38_NSX_PATCH_OPT       0      /*additional NSX patch features*/
#define MT_T38_STATE_REPORT        1       /*report fax session state change */
#define MT_T38_FRAME_ENCODING      0       /*enable frame based encoding for IP packets */
#define MT_T38_MAX_DATAGRAM_CHECK  1       /*enable max datagram check on start*/
#ifndef MT_FR_TRACE_2
#warning "MT_FR_TRACE_2 is default!"
#define MT_FR_TRACE_2              0       /*trace output include channel number as parameter*/
#endif /* MT_FR_TRACE_2 */

   /*** Trace support ***/
#ifdef _DEBUG  /*trace support for DEBUG build*/
/*accumulate trace for flushing on end of session*/
#define MT_FR_ACCUMULATE_TRACE     0
#define MT_FR_TRACE_SIZE_IN_BYTES  1024*256
/*text trace*/
#define MT_OSIF_MTRACE_ACTIVE               /*ifdef then trace support enable*/
#define MT_OSIF_MTRACE_MASK        0x100C3030    /*mask of traced events*/
#else          /*trace support for RELEASE build*/
/* recomended trace mask for release ( ~ 200 000 octets for 100 pages fax session )
#define MT_OSIF_MTRACE_ACTIVE
#define MT_OSIF_MTRACE_MASK   0x10041010
*/
#endif /*_DEBUG*/

#endif /*__MT_T38FR_COMMON_H__*/
