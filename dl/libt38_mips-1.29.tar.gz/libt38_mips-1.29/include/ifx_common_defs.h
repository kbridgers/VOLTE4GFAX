/****************************************************************************
                  Copyright � 2005  Infineon Technologies AG
                 St. Martin Strasse 53; 81669 Munich, Germany

   THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED NON-EXCLUSIVE,
   WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE AND SUBLICENSE THIS
   SOFTWARE IS FREE OF CHARGE.

   THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY DISCLAIMS
   ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR IMPLIED, INCLUDING
   WITHOUT LIMITATION, WARRANTIES OR REPRESENTATIONS OF WORKMANSHIP,
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, DURABILITY, THAT THE
   OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR FREE OR FREE OF ANY
   THIRD PARTY CLAIMS, INCLUDING WITHOUT LIMITATION CLAIMS OF THIRD PARTY
   INTELLECTUAL PROPERTY INFRINGEMENT.

   EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
   EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE FOR
   ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
   TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
   SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 ****************************************************************************
   \file ifx_commom_defs.h
   \remarks Common types
 *******************************************************************/
#ifndef         __IFX_COMMON_DEFS_H__
#define         __IFX_COMMON_DEFS_H__

#if FOIP_CHANNEL_VERSION
#include "typedef.h"
#else
#ifdef PP_T38
#include "basic_types.h"
typedef unsigned char      uint8;
typedef unsigned short int uint16;
typedef unsigned int       uint32;
typedef unsigned char      uchar8;
typedef char               char8;

#else /* Not using POLT-A and POTS Proxy */
/* ============================= */
/* Global Macros & Definitions   */
/* ============================= */

#define PUBLIC
#define EXTERN                  extern
#define STATIC                  static

#define PRINT                   printf

#define IN
#define OUT
#define IN_OUT

/* updated by shweta */
#define nullptr(Type)  (Type *)NULL

typedef char               char8;
typedef unsigned char      uchar8;
#ifndef basic_types
#define basic_types
typedef char               int8;
typedef unsigned char      uint8;
typedef short int                int16;
typedef unsigned short int      uint16;
typedef int                int32;
typedef unsigned int          uint32;
#endif /* basic_types */

typedef float              float32;
typedef double             float64;
typedef float              double32;
typedef double             double64;
typedef long               long32;
typedef unsigned long      ulong32;
/*typedef char               bool;*/
typedef char               boolean;

#endif /* PP_T38 */

#endif/*FOIP_CHANNEL_VERSION*/

#endif  /* __IFX_COMMON_DEFS_H__ */
