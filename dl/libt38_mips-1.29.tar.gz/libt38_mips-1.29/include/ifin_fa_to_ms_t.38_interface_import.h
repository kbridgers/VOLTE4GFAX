#ifndef __IFIN_FA_TO_MS_T38_INTERFACE_IMPORT_H__

#define __IFIN_FA_TO_MS_T38_INTERFACE_IMPORT_H__

/****************************************************************************
                  Copyright � 2005  Infineon Technologies AG
                 St. Martin Strasse 53; 81669 Munich, Germany

   THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED NON-EXCLUSIVE,
   WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE AND SUBLICENSE THIS
   SOFTWARE IS FREE OF CHARGE.

   THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY DISCLAIMS
   ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR IMPLIED, INCLUDING
   WITHOUT LIMITATION, WARRANTIES OR REPRESENTATIONS OF WORKMANSHIP,
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, DURABILITY, THAT THE
   OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR FREE OR FREE OF ANY
   THIRD PARTY CLAIMS, INCLUDING WITHOUT LIMITATION CLAIMS OF THIRD PARTY
   INTELLECTUAL PROPERTY INFRINGEMENT.

   EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
   EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE FOR
   ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
   TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
   SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 ****************************************************************************
   \file    : IFIN_FA_To_MS_T.38_Interface_Import.h
   \remarks : Fax agent t.38 interface functions prototypes.
 *******************************************************************/


/* ============================= */
/* Includes                      */
/* ============================= */

#if !FOIP_CHANNEL_VERSION
#include "ifin_tlib_interface_import.h"
#include "ifin_mlib_interface_import.h"
#endif

/* ============================= */
/* Local Macros & Definitions    */
/* ============================= */

#define IFIN_FA_SUCCESS 0
#define IFIN_FA_FAILURE -1

/* TEP Flag Defines */
#define IFIN_FA_NO_TEP           0
#define IFIN_FA_GENERATE_TEP     1


/* Training Sequence Flag Defines */
#define IFIN_FA_SHORT_TRAINING_SEQ     0
#define IFIN_FA_LONG_TRAINING_SEQ      1

/* Equaliser Flag Defines */
#define IFIN_FA_RESET_EQUALIZER_B4_DEMOD    0
#define IFIN_FA_REUSE_PREV_EQUALIZER_COEFFS 1

/* ============================= */
/* Global function declaration   */
/* ============================= */

#if !FOIP_CHANNEL_VERSION
int32 IFIN_FA_SendPacket(uint16 unChannelID, uchar8 *pucOutBuffer,
                                              uint32 uiOutBufferSize);
#else
int32 IFIN_FA_SendPacket(void *pv_UpperCtx, uchar8 *pucOutBuffer,
                                              uint32 uiOutBufferSize);
#endif
#if !FOIP_CHANNEL_VERSION
int32 IFIN_FA_SendDataToDataPump(uint16 unChannelID, uchar8 *pucMsgToDataPump,
                                 uint32 uiMsgSize);
#endif

int32 IFIN_FA_EndOfFAXData(uint16 unChannelID);


#ifdef IFX_T38_NETTRACE
int32 IFIN_IAD_OutTraceString(uint16 unChannelID, char8 *pcString);
#else
void IFIN_IAD_OutTraceString(char8 *pcString);
#endif

int32 IFIN_FA_SetModDemodParam(uint16 unChannelID, uchar8 ucDPNR,
                                                        uchar8 ucGain1, uchar8 ucGain2, uint16 unMOBSM,
                                                                                 uint16 unMOBRD, uint16 unDMBSD);
#if !FOIP_CHANNEL_VERSION
int32 IFIN_FA_StartModulator(uint16 unChannelID, uchar8 ucDBM,
                                                      uchar8 ucTEP, uchar8 ucTRN, uchar8 ucSTD,
                                                                          uint16 unSGLEN);
#else
int32 IFIN_FA_StartModulator(void *pv_UpperCtx, uchar8 ucDBM,
                                                      uchar8 ucTEP, uchar8 ucTRN, uchar8 ucSTD,
                                                                          uint16 unSGLEN);
#endif

#if !FOIP_CHANNEL_VERSION
int32 IFIN_FA_StartDemodulator(uint16 unChannelID, uchar8 ucTRN, uchar8 ucEQ,
                                                        uchar8 ucSTD2, uchar8 ucSTD1);
#else
int32 IFIN_FA_StartDemodulator(void *pv_UpperCtx, uchar8 ucTRN, uchar8 ucEQ,
                                                        uchar8 ucSTD2, uchar8 ucSTD1);
#endif

#if !FOIP_CHANNEL_VERSION
int32 IFIN_FA_DisableDataPump(uint16 unChannelID);
#else
int32 IFIN_FA_DisableDataPump(void *pv_UpperCtx);
#endif

void IFIN_FA_TimerCallback(void *pvInfo);

void IFIN_FA_FaxStateChanged(uint16 unChannelID, e_MT_T38_PP_FaxRelayState uiNewState);

#endif
