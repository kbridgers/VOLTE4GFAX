#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <time.h>

#include "ifx_alg.h"
#include "ifx_alg_common.h"

#if 0
#define NPRINTF(format, args...) printf(format, ##args)
#else
#define NPRINTF(format, args...)
#endif

/*  chandrav 
 *  The fix for bug wherein we are unable to make call from External Phone to 
 *  Internal Phone to its Registered IP address and Port
 *  The fix is made under the tag IFX_SIP_ALG_EXTERNAL_PHONE_CALL_TCP_FIX
 *	Do not undefine this
 */
#define IFX_SIP_ALG_EXTERNAL_PHONE_CALL_TCP_FIX

extern int ifx_run_command(char *command);

char command1[256];
char command2[256];
char command_temp[256];
char command_reg[256];
char command_reg1[256];

int main(void)
{
	int dev_file = 0, dev_file_conn = 0;
	struct sip_dnat_param sipparam;
	int ret = -1;

#if 0
	dev_file_conn = ifx_open_device(DEVICE_FILE_NAME_SIP_CONN);
	if (dev_file_conn < 0) {
		printf("Error: ... Dev cannot be opened\n");
		exit(1);
	}
#else
	time_t t;
	dev_file = open(DEVICE_FILE_NAME_SIP, 0);
	if (dev_file_conn < 0) {
		printf("Error: ... Dev cannot be opened\n");
		exit(1);
	}
#endif
	for (;;) {
		memset(&sipparam, 0, sizeof(struct sip_dnat_param));
		memset(sipparam.original_ip_address, '\0',
		       sizeof(sipparam.original_ip_address));
		memset(sipparam.changed_ip_address, '\0',
		       sizeof(sipparam.changed_ip_address));
		//Start monitoring the devices for any port 
		//registration
		//ifx_ioctl(dev_file_conn, IOCTL_READ_SIP_PORT_CONN, &parameters);

		ioctl(dev_file, IOCTL_SIP_ALG_DAEMON, &sipparam);
		if (sipparam.validdataflag == 1) {
			//initialize the memory space first
			memset(command1, '\0', sizeof(command1));
			memset(command2, '\0', sizeof(command2));
			memset(command_temp, '\0', sizeof(command_temp));
			memset(command_reg, '\0', sizeof(command_reg));
			memset(command_reg1, '\0', sizeof(command_reg));

			sprintf(command1, "iptables -t nat ");
			sprintf(command2, "iptables -t nat ");
			sprintf(command_reg, "nfappcfg sip ");

			if (sipparam.typeofchange == ADD_RULE) {
#ifndef PORTA_GW		/* [ Ritesh, 20070125 */
				strcat(command1, "-I PREROUTING ");
#else				/* ][ */
				strcat(command1, "-I SIP_ALG ");
#endif				/* ] */
				strcat(command2, "-I IFX_NAPT_SNAT_MASQ ");
				strcat(command_reg, "enable ");
			} else if (sipparam.typeofchange == DELETE_RULE) {
#ifndef PORTA_GW		/* [ Ritesh, 20070125 */
				strcat(command1, "-D PREROUTING ");
#else				/* ][ */
				strcat(command1, "-D SIP_ALG ");
#endif				/* ] */
				strcat(command2, "-D IFX_NAPT_SNAT_MASQ ");
				strcat(command_reg, "disable ");
			}

			sprintf(command_temp, "%s -d %s ", command1,
				sipparam.changed_ip_address);
			memcpy(command1, command_temp,
			       strlen(command_temp) + 1);

			sprintf(command_temp, "%s -s %s ", command2,
				sipparam.original_ip_address);
			memcpy(command2, command_temp,
			       strlen(command_temp) + 1);

			if (sipparam.proto == IP_PROTO_UDP) {
				strcat(command1, "-p udp ");
				strcat(command2, "-p udp ");
				strcat(command_reg, "-tudp ");
			} else if (sipparam.proto == IP_PROTO_TCP) {
				strcat(command1, "-p tcp ");
				strcat(command2, "-p tcp ");
				strcat(command_reg, "-ttcp ");
			}

			if (sipparam.original_port) {
				sprintf(command_temp,
					"%s --dport %d -j DNAT --to-destination %s:%d",
					command1, sipparam.changed_port,
					sipparam.original_ip_address,
					sipparam.original_port);
				sprintf(command_reg1, "%s -p%d -b", command_reg,
					sipparam.original_port);
			} else {
				sprintf(command_temp,
					"%s --dport %d -j DNAT --to-destination %s",
					command1, sipparam.changed_port,
					sipparam.original_ip_address);
			}
			memcpy(command1, command_temp, strlen(command_temp));

			sprintf(command_temp,
				"%s --sport %d -j MASQUERADE --to-ports %d",
				command2, sipparam.original_port,
				sipparam.changed_port);
			memcpy(command2, command_temp, strlen(command_temp));
#if 0
#ifdef IFX_SIP_ALG_EXTERNAL_PHONE_CALL_TCP_FIX	// chandrav
			if (sipparam.proto == IP_PROTO_UDP) {
				if (sipparam.typeofchange == ADD_RULE) {
					if (sipparam.original_port)
						sprintf(command1,
							"iptables -t nat -I PREROUTING  -d %s -p udp --dport %d -j DNAT --to-destination %s:%d",
							sipparam.
							changed_ip_address,
							sipparam.changed_port,
							sipparam.
							original_ip_address,
							sipparam.original_port);
					else
						sprintf(command1,
							"iptables -t nat -I PREROUTING  -d %s -p udp --dport %d -j DNAT --to-destination %s",
							sipparam.
							changed_ip_address,
							sipparam.changed_port,
							sipparam.
							original_ip_address);
				} else if (sipparam.typeofchange == DELETE_RULE) {
					if (sipparam.original_port)
						sprintf(command1,
							"iptables -t nat -D PREROUTING  -d %s -p udp --dport %d -j DNAT --to-destination %s:%d",
							sipparam.
							changed_ip_address,
							sipparam.changed_port,
							sipparam.
							original_ip_address,
							sipparam.original_port);
					else
						sprintf(command1,
							"iptables -t nat -D PREROUTING  -d %s -p udp --dport %d -j DNAT --to-destination %s",
							sipparam.
							changed_ip_address,
							sipparam.changed_port,
							sipparam.
							original_ip_address);
				}

			} else if (sipparam.proto == IP_PROTO_TCP) {
				if (sipparam.typeofchange == ADD_RULE) {
					if (sipparam.original_port)
						sprintf(command1,
							"iptables -t nat -I PREROUTING  -d %s -p tcp --dport %d -j DNAT --to-destination %s:%d",
							sipparam.
							changed_ip_address,
							sipparam.changed_port,
							sipparam.
							original_ip_address,
							sipparam.original_port);
					else
						sprintf(command1,
							"iptables -t nat -I PREROUTING  -d %s -p tcp --dport %d -j DNAT --to-destination %s",
							sipparam.
							changed_ip_address,
							sipparam.changed_port,
							sipparam.
							original_ip_address);
				} else if (sipparam.typeofchange == DELETE_RULE) {
					if (sipparam.original_port)
						sprintf(command1,
							"iptables -t nat -D PREROUTING  -d %s -p tcp --dport %d -j DNAT --to-destination %s:%d",
							sipparam.
							changed_ip_address,
							sipparam.changed_port,
							sipparam.
							original_ip_address,
							sipparam.original_port);
					else
						sprintf(command1,
							"iptables -t nat -D PREROUTING  -d %s -p tcp --dport %d -j DNAT --to-destination %s",
							sipparam.
							changed_ip_address,
							sipparam.changed_port,
							sipparam.
							original_ip_address);
				}

			}
#endif				// IFX_SIP_ALG_EXTERNAL_PHONE_CALL_TCP_FIX   chandrav
#endif

			printf("New command [%s]\n", command1);
			ret = ifx_run_command(command1);
			time(&t);
			printf("command exec at time: [%u]\n", (unsigned int)t);
			if (ret == SUCCESS) {
				printf("Sys command success\n");
			}

			if (!
			    (sipparam.original_port == 5060
			     && sipparam.typeofchange == DELETE_RULE)) {
#if 1
				ret = ifx_run_command(command_reg1);
				if (ret == SUCCESS) {
					printf("Sys command success 1\n");
				}
#endif
			}

#if 0				//Sumedh  (testing)
			printf("New command2 [%s]\n", command2);
			ret = ifx_run_command(command2);
			if (ret == SUCCESS) {
				printf("Sys command2 success\n");
			}
#endif				//Sumedh
#if 0

			printf("\n\n");
			printf("Received data from device\n");
			printf("Original port no: [%d]\n",
			       sipparam.original_port);
			printf("Original ip addr: [%s]\n",
			       sipparam.original_ip_address);
			printf("Changed port no: [%d]\n",
			       sipparam.changed_port);
			printf("Changed ip addr: [%s]\n",
			       sipparam.changed_ip_address);
			printf("Proto no:[%d] [%s]\n", sipparam.proto,
			       sipparam.proto == IP_PROTO_UDP ? "UDP" : "TCP");
			printf("Type of change:[%d] [%s]\n",
			       sipparam.typeofchange,
			       sipparam.typeofchange ==
			       DELETE_RULE ? "DELETE" : "ADD");
#endif
		}
	}
}
