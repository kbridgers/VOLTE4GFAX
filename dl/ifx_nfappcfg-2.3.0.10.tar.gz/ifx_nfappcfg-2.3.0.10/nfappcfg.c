#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ifx_alg_common.h>

//#include "ifx_alg_api.c"

#if 0
#define NPRINTF(format,args...) printf(format,##args)
#else
#define NPRINTF(format,args...)
#endif

#define PROGNAME "nfappcfg"
void usage(void)
{
	printf("%s usage:\n", PROGNAME);
	printf("\t\t %s init\n", PROGNAME);
	printf("\t\t %s <app protocol> <enable/disable> [-llanif] [-wwanif]\n"
	       "\t\t\t	[<-ttransportproto> <-pdestport> <-b> <-n>]\n",
	       PROGNAME);
	printf("\n -b : TO add rules in both direction");
	printf("\n -n : Shows that NAT is not enabled \n");
	exit(1);
}

int main(int argc, char *argv[])
{

	int proto_id, flag, trans_proto = 0, port = 0;
	int ret = 0;
	int i = 0;
	int bidir = 0;
	char *lanif = NULL, *wanif = NULL;
	int nat_flag = NAT_ENABLE;
	NPRINTF("\n program started \n");

	if (argc == 2) {
		if (!strcmp(argv[1], "show")) {
			ifx_alg_app_init(0);
			exit(0);
		}
		if (!strcmp(argv[1], "init")) {
			ifx_alg_app_init(1);
			exit(0);
		}
	}

	if (argc < 3) {
		NPRINTF("No of argument less than 3\n");
		usage();
	}

	proto_id = ifx_find_app_proto(argv[1]);

	if (proto_id < 0) {
		printf("Invalid application [%s] !\n", argv[1]);
		usage();
	}

	if (strcmp(argv[2], "enable") == 0) {
		flag = ENABLE;
	} else {
		flag = DISABLE;
	}

	for (i = 3; i < argc; i++) {
		if (argv[i][0] != '-') {
			NPRINTF("Arg do not start with -\n");
			usage();
		}

		switch (argv[i][1]) {
		case 'l':
			NPRINTF("got the lan interface\n");
			lanif = &argv[i][2];
			break;
		case 'w':
			NPRINTF("got the wan interface\n");
			wanif = &argv[i][2];
			break;
		case 't':
			if (!strcmp(&argv[i][2], "tcp")) {
				NPRINTF("transport is tcp\n");
				trans_proto = IP_PROTO_TCP;
			} else if (!strcmp(&argv[i][2], "udp")) {
				NPRINTF("transport is udp\n");
				trans_proto = IP_PROTO_UDP;
			} else if (!strcmp(&argv[i][2], "tcpudp")) {
				NPRINTF("transport is tcpudp\n");
				trans_proto = IP_PROTO_TCP_UDP;
			} else {
				NPRINTF("transport not matching\n");
				usage();
			}
			break;
		case 'p':
			NPRINTF("got the port\n");
			port = strtol(&argv[i][2], NULL, 10);
			break;
		case 'b':
			NPRINTF("Bidir enable\n");
			bidir = 1;
			break;
		case 'n':
			printf("Nat flag disabled\n");
			nat_flag = NAT_DISABLE;
			break;
		default:
			NPRINTF("Flags for argument not matching\n");
			usage();	/* Exit */
			break;
		}
	}

	if (trans_proto == 0 || port == 0) {
		if (!(trans_proto == 0 && port == 0)) {
			NPRINTF("port and protocol both 0\n");
			usage();
		}
	}

	NPRINTF("app<%d>, enable<%d>, Transport <%d>, Port <%d>, Lan <%s>, Wan"
		"<%s> NAT<%d> bidir <%d>\n", proto_id, flag,
		trans_proto, port, lanif, wanif, nat_flag, bidir);

	ifx_alg_app_init(0);	/* init lib */

	if (flag == ENABLE) {

		if ((ret =
		     ifx_enable_alg(proto_id, trans_proto, port, lanif, wanif,
				    nat_flag, bidir)) < 0)
			NPRINTF("\n Error : Enable fails\n");
		else
			NPRINTF("\n Enable successfull \n");
	} else {
		if ((ret =
		     ifx_disable_alg(proto_id, trans_proto, port, lanif, wanif,
				     bidir)) < 0)
			NPRINTF("\n Error : Disable fails\n");
		else
			NPRINTF("\n Disable successfull \n");
	}

	return ret;
}
