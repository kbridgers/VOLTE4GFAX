// 603296:linjoe 2006/03/29 add for vdsl2 web pages ,need more web buffer and ifx_httpdWtite support %u and %f
#include	<ifx_emf.h>
#include "ifx_httpd_method.h"
#include <ifx_exportFunc.h>
#include "ifx_common.h"

#include "./ifx_amazon_cgi.h"
#include "./ifx_amazon_cgi_getFunctions.h"
#include "./ifx_cgi_common.h"
// #include "./ifx_amazon_cgi.h" // 603296:linjoe

#ifdef DMALLOC
#include "dmalloc.h"
#endif

#define WEBS_MAX_PASS 32
static char_t websPassword[WEBS_MAX_PASS];	/* Access password (decoded) */
static char_t websUser[WEBS_MAX_PASS];	/* Access user (decoded) */
extern int (*ifx_sendHeaders) (int s, char *title, char *extra_header, char *me,
			       char *mt, off_t b, time_t mod,
			       char *redirectURL);
extern int (*ifx_read) (int fd, void *buf, int len);
extern int (*ifx_write) (int fd, const void *buf, int len);

extern int32 mapi_get_all_user_obj_details(int32 *user_count, user_obj_t **user_obj, uint32 flags);
// 603296:linjoe #define  MAX_PAGE_BUF  1024
#ifdef CONFIG_FEATURE_IFX_VDSL2	// 603296:linjoe
#define  MAX_PAGE_BUF	15000	// 603296:linjoe
#else				// 603296:linjoe
#define  MAX_PAGE_BUF	5 * 1024	// 603296:linjoe
#endif				// 603296:linjoe
int ifx_httpdWrite(httpd_t wp, char_t * fmt, ...)
{
	va_list vargs;
	char destBuf[MAX_PAGE_BUF];
#if 1
	char *s;
	int d;
	unsigned int u;		//603296:linjoe
	float f;		//603296:linjoe
	char *cp;		//603296:linjoe
	int curLoc = 0;
	char tmpbuf[MAX_PAGE_BUF];
	char dec_fmt[20];	/* max 20 precision including decimal */
	int i = 0;

	memset(destBuf, 0x00, MAX_PAGE_BUF);
	memset(tmpbuf, 0x00, MAX_PAGE_BUF);
	memset(dec_fmt, 0x00, sizeof(dec_fmt));
	va_start(vargs, fmt);
	for (cp = fmt; cp && *cp; cp++) {
		if (*cp == '%') {
			switch (*(cp + 1)) {
			case '0':
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
			case '.':
				i = 0;
				memset(dec_fmt, 0x00, sizeof(dec_fmt));
				dec_fmt[i++] = *(cp);
				cp++;
				do {
					dec_fmt[i++] = *(cp);
					cp++;
				} while ((*(cp) >= '0' && *(cp) <= '9')
					 || *(cp) == '.');
				cp--;	// go back one character
				break;
			}

			switch (*(cp + 1)) {
			case 'd':
				d = va_arg(vargs, int);
				snprintf(tmpbuf, MAX_PAGE_BUF, "%s%d", destBuf,
					 d);
				strncpy(destBuf, tmpbuf, MAX_PAGE_BUF);
				curLoc = strlen(destBuf);
				cp++;
				break;
				//603296:linjoe-start
			case 'u':
				u = va_arg(vargs, unsigned int);
				snprintf(tmpbuf, MAX_PAGE_BUF, "%s%u", destBuf,
					 u);
				strncpy(destBuf, tmpbuf, MAX_PAGE_BUF);
				curLoc = strlen(destBuf);
				cp++;
				break;
			case 'f':
				f = va_arg(vargs, double);

				if (strlen(dec_fmt)) {
					strcat(dec_fmt, "f");

					memset(tmpbuf, 0x00, sizeof(tmpbuf));
					snprintf(tmpbuf, MAX_PAGE_BUF, dec_fmt,
						 f);
					strncat(destBuf, tmpbuf,
						strlen(tmpbuf));
				} else {
					snprintf(tmpbuf, MAX_PAGE_BUF, "%s%f",
						 destBuf, f);
					strncpy(destBuf, tmpbuf, MAX_PAGE_BUF);
				}

				curLoc = strlen(destBuf);
				cp++;
				memset(dec_fmt, 0x00, sizeof(dec_fmt));
				break;
				//603296:linjoe-end
			case 's':
				s = va_arg(vargs, char *);
				strncat(destBuf, s, strlen(s));
				curLoc += strlen(s);
				cp++;
				break;
			case '%':
				destBuf[curLoc++] = *cp;
				cp++;
				break;
			case 'l':
				switch (*(cp + 2)) {
				case 'u':
					u = va_arg(vargs, unsigned long);
					snprintf(tmpbuf, MAX_PAGE_BUF, "%s%u",
						 destBuf, u);
					strncpy(destBuf, tmpbuf, MAX_PAGE_BUF);
					curLoc = strlen(destBuf);
					cp += 2;
					break;
				}
				break;
			default:
				destBuf[curLoc++] = *cp;
				break;
			}
		} else {
			destBuf[curLoc++] = *cp;
		}
	}
	va_end(vargs);

#if 0
	char *s;
	int d;
	unsigned int u;		//603296:linjoe
	float f;		//603296:linjoe     
	char *cp;		//603296:linjoe
	int curLoc = 0;
	char tmpbuf[MAX_PAGE_BUF];

	memset(destBuf, 0x00, MAX_PAGE_BUF);
	memset(tmpbuf, 0x00, MAX_PAGE_BUF);
	va_start(vargs, fmt);
	for (cp = fmt; cp && *cp; cp++) {
		if (*cp == '%') {
			//      continue;
			//if(*(cp-1) == '%')
			switch (*(cp + 1)) {
			case 'd':
				d = va_arg(vargs, int);
				snprintf(tmpbuf, MAX_PAGE_BUF, "%s%d", destBuf,
					 d);
				strncpy(destBuf, tmpbuf, MAX_PAGE_BUF);
				curLoc = strlen(destBuf);
				cp++;
				break;
//603296:linjoe-start
			case 'u':
				u = va_arg(vargs, unsigned int);
				snprintf(tmpbuf, MAX_PAGE_BUF, "%s%u", destBuf,
					 u);
				strncpy(destBuf, tmpbuf, MAX_PAGE_BUF);
				curLoc = strlen(destBuf);
				cp++;
				break;
			case 'f':
				f = va_arg(vargs, double);
				snprintf(tmpbuf, MAX_PAGE_BUF, "%s%f", destBuf,
					 f);
				strncpy(destBuf, tmpbuf, MAX_PAGE_BUF);
				curLoc = strlen(destBuf);
				cp++;
				break;
//603296:linjoe-end
			case 's':
				s = va_arg(vargs, char *);
				gstrncat(destBuf, s, strlen(s));
				curLoc += strlen(s);
				cp++;
				break;
			case '%':
				destBuf[curLoc++] = *cp;
				cp++;
				break;
			case 'l':
				switch (*(cp + 2)) {
				case 'u':
					u = va_arg(vargs, unsigned long);
					snprintf(tmpbuf, MAX_PAGE_BUF, "%s%lu",
						 destBuf, u);
					strncpy(destBuf, tmpbuf, MAX_PAGE_BUF);
					curLoc = strlen(destBuf);
					cp += 2;
					break;
				}
				break;
			default:
				destBuf[curLoc++] = *cp;
				break;
			}
		} else {
			destBuf[curLoc++] = *cp;
		}
	}
	va_end(vargs);
	//wp->ifx_return_value = 0;
	//gstrncat(wp->ifx_buff,destBuf,strlen(destBuf));       
#endif				// 0

#else
	va_start(vargs, fmt);

	if (vsnprintf(destBuf, sizeof(destBuf), fmt, vargs) >= sizeof(destBuf)) {
		ifx_debug_printf("ifx_httpdWrite : Truncated Line!\n");
	}
	va_end(vargs);
#endif
	(*ifx_write) (wp->ifxWriteFd, (const void *)destBuf, strlen(destBuf));
	ifx_debug_printf("ifx_httpdWrite : wrote [%s]\n", destBuf);
	return 0;
}

char msgBeg[] = T("<html><head><title>Document Error: %d</title></head>\r\n\
		<body><h2>Access Error: %d</h2>\r\n\
		<p>");
char msgEnd[] = T("</p></body></html>\r\n");
#define MAX_ERR_PAGE_LEN	512

void ifx_httpdError(httpd_t wp, int code, char_t * fmt, ...)
{
	va_list vargs;
	char destBuf[MAX_ERR_PAGE_LEN] = { 0 };
	char msg[MAX_ERR_PAGE_LEN];
	char tmpbuf[MAX_ERR_PAGE_LEN];
#if 0
	char *s;
	char *cp;
	int curLoc = 0;

	//wp->bSendHeader = 1;  //Enable seding of header
	//wp->responseCode = code;
	//strcpy(wp->redirectURL,"");
	//sendHeaders(code);    will be called from calling function.
#endif
	if (wp->bSendHeader)
		(*ifx_sendHeaders) (code, "Ok", "", "", "text/html; charset=%s",
				    (off_t) - 1, (time_t) - 1, NULL);
	memset(msg, 0x00, MAX_ERR_PAGE_LEN);
	strncat(msg, msgBeg, strlen(msgBeg));
#if 0
	strncat(msg, fmt, strlen(fmt));
	strcat(msg, msgEnd);

	memset(destBuf, 0x00, MAX_ERR_PAGE_LEN);
	va_start(vargs, fmt);
	for (cp = msg; cp && *cp; cp++) {
		if (*cp == '%') {
			//      continue;
			//if(*(cp-1) == '%')
			switch (*(cp + 1)) {
			case 'd':
				snprintf(tmpbuf, MAX_ERR_PAGE_LEN, "%s%d",
					 destBuf, code);
				strncpy(destBuf, tmpbuf, MAX_ERR_PAGE_LEN);
				curLoc = strlen(destBuf);
				cp++;
				break;
			case 's':
				s = va_arg(vargs, char *);
				gstrncat(destBuf, s, strlen(s));
				curLoc += strlen(s);
				cp++;
				break;
			default:
				destBuf[curLoc++] = *cp;
				break;
			}
		} else {
			destBuf[curLoc++] = *cp;
		}
	}
	va_end(vargs);
#else
	va_start(vargs, fmt);

	vsnprintf(msg, sizeof(msg), fmt, vargs);
	va_end(vargs);

	snprintf(tmpbuf, sizeof(tmpbuf), msgBeg, code, code);
	snprintf(destBuf, sizeof(destBuf), "%s%s%s", tmpbuf, msg, msgEnd);

#endif

	//wp->ifx_return_value = -1;
	//gstrncat(wp->ifx_buff,destBuf,strlen(destBuf));
	ifx_debug_printf("From httpdError responseCode[%d] and string[%s]\n",
			 code, destBuf);
	(*ifx_write) (wp->ifxWriteFd, (const void *)destBuf, strlen(destBuf));
	return;
}

/******************************************************************************/

/*
 * Function to parse arguments passed in the web page. Use for "dynamic C
 * binding feature" support. This allows calling a C function from the HTML
 * when processed by the IFX web server
 */

int ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...)
{
	va_list vargs;
	char_t *p_ch, **pp_str;
	int *ip;
	int args;

	va_start(vargs, fmt);

	if (argv == NULL) {
		return 0;
	}

	for (args = 0, p_ch = fmt; p_ch && *p_ch && argv[args];) {
		if (*p_ch++ != '%') {
			continue;
		}

		switch (*p_ch) {
		case 'd':
			ip = va_arg(vargs, int *);
			*ip = gatoi(argv[args]);
			break;

		case 's':
			pp_str = va_arg(vargs, char_t **);
			*pp_str = argv[args];
			break;

		default:
			break;
		}
		args++;
	}

	va_end(vargs);
	return args;
}

/******************************************************************************/
/*
 *	Default error handler.  The developer should insert code to handle
 *	error messages in the desired manner.
 */

void defaultErrorHandler(int etype, char_t * msg)
{
#if 1
	write(1, msg, gstrlen(msg));
#endif
}

/******************************************************************************/
/*
 *	Trace log. Customize this function to log trace output
 */

void defaultTraceHandler(int level, char_t * buf)
{
/*
 *	The following code would write all trace regardless of level
 *	to stdout.
 */
#ifdef DEBUG
	if (buf) {
		write(1, buf, gstrlen(buf));
	}
#endif
}

void ifx_httpdDone(httpd_t wp, int code)
{
	//wp->bSendHeader = 1;
	//wp->responseCode = code;
	(*ifx_sendHeaders) (code, "Ok", "", "", "text/html; charset=%s",
			    (off_t) - 1, (time_t) - 1, NULL);
}

#if 0
int ifx_httpdGetVarBufLen(httpd_t wp, char *var)
{
	struct ifx_arg_list *pArgList = NULL;
	int i;

	pArgList = wp->ifx_ptr_arg_list;
	if (pArgList == NULL) {
		ifx_debug_printf
		    ("ifx_httpdGetVarBufLen Error : wp->ifx_ptr_arg_list is NULL\n");
		return -1;
	}

	for (i = 0; i < wp->ifx_no_argument && pArgList;
	     i++, pArgList = pArgList->next) {
		if (gstrncmp(pArgList->pifx_param_name, var, strlen(var)) == 0) {
			ifx_debug_printf
			    ("ifx_httpdGetVarBufLen : var %s found len as %d\n",
			     var, pArgList->totBufLen);
			return pArgList->totBufLen;
		}
	}
	printf("ifx_httpdGetVarBufLen : var %s not found. Returning %d\n", var,
	       -1);
	return -1;

}

int ifx_httpdGetMBufNextBuf(httpd_t wp, char *var, char **retBuf, int readLoc)
{
	struct ifx_arg_list *pArgList = NULL;
	int i, j;

	pArgList = wp->ifx_ptr_arg_list;
	if (pArgList == NULL) {
		ifx_debug_printf
		    ("ifx_httpdGetMBufNextBuf Error : wp->ifx_ptr_arg_list is NULL\n");
		return -1;
	}

	for (i = 0; i < wp->ifx_no_argument && pArgList;
	     i++, pArgList = pArgList->next) {
		if (gstrncmp(pArgList->pifx_param_name, var, strlen(var)) == 0) {
			j = 0;
			ifx_debug_printf
			    ("ifx_httpdGetMBufNextBuf : var %s found with totBufLen %d.\n",
			     var, pArgList->totBufLen);
			if (readLoc > pArgList->totBufLen) {
				ifx_debug_printf
				    ("ifx_httpdGetMBufNextBuf : var %s has totBufLen %d while required readLoc is %d.\n",
				     var, pArgList->totBufLen, readLoc);
				return -1;
			}
			while (readLoc >=
			       pArgList->ifx_param_value.pArrMultiBuf[j].len
			       && j < pArgList->numMultiBufs) {
				readLoc -=
				    pArgList->ifx_param_value.pArrMultiBuf[j].
				    len;
				j++;
			}
			ifx_debug_printf
			    ("###ifx_httpdGetMBufNextBuf : readLoc [%d] cur numMultiBufs [%d] current len[%d]\n",
			     readLoc, j,
			     pArgList->ifx_param_value.pArrMultiBuf[j].len);
			*retBuf =
			    pArgList->ifx_param_value.pArrMultiBuf[j].buf +
			    readLoc;
			return pArgList->ifx_param_value.pArrMultiBuf[j].len -
			    readLoc;
		}
	}
	printf("ifx_httpdGetVarBufLen : var %s not found. Returning %d\n", var,
	       -1);
	return -1;

}
#endif

//For certification
int ifx_httpdGetVarMbuff(httpd_t wp, char_t * var, char_t * defaultGetValue)
{
	struct ifx_arg_list *pArgList = NULL;
	int i;
	FILE *fp;
	int bFirstTime = 1;
#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	fp = fopen("/tmp/certificate.txt", "w");
	if (fp == NULL) {
		printf("wensGetVar Error : wp->ifx_ptr_arg_list is NULL\n");
		return IFX_FAILURE;
	}
	pArgList = wp->ifx_ptr_arg_list;
	if (pArgList == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		printf("wensGetVar Error : wp->ifx_ptr_arg_list is NULL\n");
		fprintf(fp, "%s", defaultGetValue);
	}
	for (i = 0; i < wp->ifx_no_argument && pArgList;
	     i++, pArgList = pArgList->next) {
		if (bFirstTime) {
			fputs("-----", fp);
			bFirstTime = 0;
		}
		if ((gstrncmp(pArgList->pifx_param_name, var, strlen(var)) == 0)
		    && (strlen(pArgList->pifx_param_name) == strlen(var))) {
			if (pArgList->numMultiBufs) {
				ifx_debug_printf
				    ("ifx_httpdGetVar : var %s is multiBuf with numMultiBufs %d\n",
				     var,
				     pArgList->ifx_param_value.numMultiBufs);
				//fprintf(fp,"%s",pArgList->ifx_param_value.pArrMultiBuf);
				if (strstr
				    (pArgList->ifx_param_value.pArrMultiBuf->
				     buf, "BEGIN CERTIFICATE")
				    && strstr(pArgList->ifx_param_value.
					      pArrMultiBuf->buf,
					      "END CERTIFICATE"))

					fputs(pArgList->ifx_param_value.
					      pArrMultiBuf->buf, fp);
				else {
					if (fp)
						fclose(fp);
					return IFX_FAILURE;
				}
			} else {
				ifx_debug_printf
				    ("ifx_httpdGetVar : var %s found as %s\n",
				     var, pArgList->ifx_param_value.buf);
				if (strlen(pArgList->ifx_param_value.buf) <=
				    CERT_MAX_SIZE) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] [%s]",__FUNCTION__, __LINE__,pArgList->ifx_param_value.buf);
#endif
					//fprintf(fp,"%s",pArgList->ifx_param_value.buf);
					if (strstr
					    (pArgList->ifx_param_value.buf,
					     "BEGIN CERTIFICATE")
					    && strstr(pArgList->ifx_param_value.
						      buf, "END CERTIFICATE"))
						fputs(pArgList->ifx_param_value.
						      buf, fp);
					else {
						if (fp)
							fclose(fp);
						return IFX_FAILURE;
					}
				} else {
					if (fp)
						fclose(fp);
					return IFX_FAILURE;
				}
			}
		}
	}
	if (!bFirstTime)
		fputs("-----", fp);
	if (fp)
		fclose(fp);

	return IFX_SUCCESS;
}

int ltq_httpdUpdateVal(httpd_t wp, char_t * var, char_t * value);
/*Function to update 'wp' parameter list --rajendra*/
int ltq_httpdUpdateVal(httpd_t wp, char_t * var, char_t * value)
{

	struct ifx_arg_list *pArgList = NULL;
	int i;
	int iRet = 0;
	pArgList = wp->ifx_ptr_arg_list;
	if (pArgList == NULL) {
		printf("wensGetVar Error : wp->ifx_ptr_arg_list is NULL\n");
		return IFX_FAILURE;
	}

	for (i = 0; i < wp->ifx_no_argument && pArgList;
	     i++, pArgList = pArgList->next) {
		if ((gstrncmp(pArgList->pifx_param_name, var, strlen(var)) == 0)
		    && (strlen(pArgList->pifx_param_name) == strlen(var))) {
			sprintf(pArgList->ifx_param_value.buf, "%s",
				value ? value : "");
			iRet = 1;
		}
	}
	if (iRet == 0) {
		return IFX_FAILURE;
	}
	return IFX_SUCCESS;
}

/*Funtion to get values of fields in webpage */
char_t *ifx_httpdGetVar(httpd_t wp, char_t * var, char_t * defaultGetValue)
{

	struct ifx_arg_list *pArgList = NULL;
	int i;

	pArgList = wp->ifx_ptr_arg_list;
	if (pArgList == NULL) {
		printf("wensGetVar Error : wp->ifx_ptr_arg_list is NULL\n");
		return defaultGetValue;
	}

	for (i = 0; i < wp->ifx_no_argument && pArgList;
	     i++, pArgList = pArgList->next) {
		if ((gstrncmp(pArgList->pifx_param_name, var, strlen(var)) == 0)
		    && (strlen(pArgList->pifx_param_name) == strlen(var))) {
			if (pArgList->numMultiBufs) {
				ifx_debug_printf
				    ("ifx_httpdGetVar : var %s is multiBuf with numMultiBufs %d\n",
				     var, pArgList->numMultiBufs);
				return NULL;
			} else {
				ifx_debug_printf
				    ("ifx_httpdGetVar : var %s found as %s\n",
				     var, pArgList->ifx_param_value.buf);
				return pArgList->ifx_param_value.buf;
			}
		}
	}
	//printf("ifx_httpdGetVar : var %s not found. Returning %s\n",var,defaultGetValue);
	return defaultGetValue;
}

#define WEBS_MAX_URL 256
int ifx_isHostlinklocal(httpd_t wp)
{
	if (strstr(wp->host, "[fe8") || strstr(wp->host, "[fe9") ||
	    strstr(wp->host, "[FE8") || strstr(wp->host, "[FE9") ||
	    strstr(wp->host, "[fE8") || strstr(wp->host, "[fE9") ||
	    strstr(wp->host, "[Fe8") || strstr(wp->host, "[Fe9")) {
		return IFX_SUCCESS;
	}
	return IFX_FAILURE;
}

void ifx_jsRedirect(httpd_t wp, char_t * url)
{
	char_t *msgbuf, *urlbuf;	//, *redirectFmt;

	urlbuf = NULL;
	msgbuf = NULL;
/*
 *	Add human readable message for completeness. Should not be required.
 */
	if (*url == '/') {
		url++;
	}

	msgbuf = (char *)calloc(WEBS_MAX_URL + 200, sizeof(char));
	if (msgbuf)
		snprintf(msgbuf, WEBS_MAX_URL + 200, ("<html><head>\r\n\
<script type=\"text/javascript\">\r\n\
location.href=\"/%s\";\r\n\
</script>\r\n\
</head><body>\r\n\
This document has moved to a new <a href=\"%s\">location</a>.\r\n\
Please update your documents to reflect the new location.\r\n\
</body></html>\r\n"), url, url);

	ifx_debug_printf
	    ("From ifx_jsRedirect responseCode[%d] and string[%s]\n", 200,
	     msgbuf);
	(*ifx_sendHeaders) (200, "Ok", "", "", "text/html; charset=%s",
			    (off_t) - 1, (time_t) - 1, NULL);
	ifx_httpdWrite(wp, msgbuf, url);

	if (urlbuf != NULL)
		free(urlbuf);
	if (msgbuf != NULL)
		free(msgbuf);
}

void ifx_httpdRedirect_302(httpd_t wp, char_t * url)
{
				char_t *msgbuf, *urlbuf;	//, *redirectFmt;

				urlbuf = NULL;
				msgbuf = NULL;
				/*
				 *	Some browsers require a http://host qualified URL for redirection
				 */
				if(gstrstr(url, T("http://")) == NULL || gstrstr(url, T("https://")) == NULL) {
								if(*url == '/') {
												url++;
								}

								/*manohar : added to check whether request is from http or https*/
								char_t https_enable[40];
								if(ifx_GetObjData(FILE_RC_CONF, TAG_SYSTEM_WEB_CONFIG,"HTTPsEnable",IFX_F_GET_ANY,NULL,https_enable) != IFX_SUCCESS) {
												ifx_httpdError(wp, 500, T("https enable not found"));
												return;
								}
								/*
									 fp = popen("cat /etc/mini_httpd.conf", "r");
									 if(fp == NULL) {
									 ifx_debug_printf("Failed to read mini_httpd.conf");
									 return;
									 }
									 if(fp != NULL) {
									 while(fgets(sslbuf, 100, fp) != 0) {
									 sslbuf[strlen(sslbuf) - 1] = '\0';
									 if(!strcmp(sslbuf,"ssl"))
									 {
									 do_ssl = 1;
									 break;
									 }
									 }
									 }
									 pclose(fp);
								 */
								/*manohar end*/

								urlbuf = (char *)calloc(WEBS_MAX_URL + 80, sizeof(char));
								ifx_debug_printf("From ifx_httpdRedirect : host_name [%s]\n", wp->host);
								if(urlbuf)
								{

												if(atoi(https_enable) == 1)
																snprintf(urlbuf, WEBS_MAX_URL + 80, "https://%s/%s", wp->host, url);
												else
																snprintf(urlbuf, WEBS_MAX_URL + 80, "http://%s/%s", wp->host, url);
								}   
								url = urlbuf;
				}

				/*
				 *	Add human readable message for completeness. Should not be required.
				 */
				msgbuf = (char *)calloc(WEBS_MAX_URL + 200, sizeof(char));
				if (msgbuf)
								snprintf(msgbuf, WEBS_MAX_URL + 200, ("<html><head></head><body>\r\n\
																				This document has moved to a new <a href=\"%s\">location</a>.\r\n\
																				Please update your documents to reflect the new location.\r\n\
																				</body></html>\r\n"),
																url);

				//wp->bSendHeader = 1;
				//wp->responseCode = 302;
				//strncpy(wp->redirectURL,url,IFX_REDIRECT_URL_LEN);
				ifx_debug_printf
								("From ifx_httpdRedirect responseCode[%d] and string[%s]\n", 302,
								 msgbuf);
				(*ifx_sendHeaders) (302, "Found", "", "", "text/html; charset=%s",
												(off_t) - 1, (time_t) - 1, url);
				ifx_httpdWrite(wp, msgbuf, url);

				if (urlbuf != NULL)
								free(urlbuf);
				if (msgbuf != NULL)
								free(msgbuf);
}

void ifx_httpdRedirect(httpd_t wp, char_t * url)
{
	if (ifx_isHostlinklocal(wp) == IFX_SUCCESS) {
		ifx_jsRedirect(wp, url);
	} else {
		ifx_jsRedirect(wp, url);
		//ifx_httpdRedirect_302(wp, url);
	}
}

void ifx_httpdSetPassword(char_t * password)
{
	memset(websPassword, 0x00, sizeof(websPassword));
	gstrncpy(websPassword, password, sizeof(websPassword));
}

char_t *ifx_httpdGetPassword()
{
	return websPassword;
}

void ifx_httpdUpdateUsrPwd(char_t *user, char_t *pwd)
{
				strcpy(websUser, user);
				strcpy(websPassword, pwd);
}

/******************************************************************************/
/*
 *	Convert integer to ascii string. Allow a NULL string in which case we
 *	allocate a dynamic buffer. 
 */
char_t *stritoa(int n, char_t * string, int width)
{
	char_t *cp, *lim, *s;
	char_t buf[16];		/* Just temp to hold number */
	int next, minus;

	a_assert(string && width > 0);

	if (string == NULL) {
		if (width == 0) {
			width = 10;
		}
		if ((string = malloc(width + 1)) == NULL) {
			return NULL;
		}
	}
	if (n < 0) {
		minus = 1;
		n = -n;
		width--;
	} else {
		minus = 0;
	}

	cp = buf;
	lim = &buf[width - 1];
	while (n > 9 && cp < lim) {
		next = n;
		n /= 10;
		*cp++ = (char_t) (next - n * 10 + '0');
	}
	if (cp < lim) {
		*cp++ = (char_t) (n + '0');
	}

	s = string;
	if (minus) {
		*s++ = '-';
	}

	while (cp > buf) {
		*s++ = *--cp;
	}

	*s++ = '\0';
	return string;
}

/******************************************************************************/
/*
 *	Trace log. Customize this function to log trace output
 */

void trace(int level, char_t * fmt, ...)
{
	va_list args;

	va_start(args, fmt);
	va_end(args);
}
