#include <ifx_emf.h>
#include "ifx_httpd_method.h"
#include "./ifx_cgi_common.h"
#include "ifx_amazon_cgi.h"
#include <sys/syslog.h>
#include <ifx_common.h>
#include "ifx_amazon_cgi_time.h"
#include "ifx_api_util.h"


#if  defined(CONFIG_FEATURE_FIREWALL) && defined(CONFIG_FEATURE_IPv6)
#define FIREWALL_CMD "/etc/rc.d/firewall6"
extern LTQ_MAPI_Firewall_Config * mapi_get_firewall_config(LTQ_MAPI_Firewall_Config *fwl_config);
extern LTQ_MAPI_Firewall_Config * mapi_set_firewall_config(LTQ_MAPI_Firewall_Config *fwl_config);
extern LTQ_MAPI_Firewall_Rule * mapi_set_firewall_rule(LTQ_MAPI_Firewall_Rule *fwl_rule, int32 index);
extern void websNextPage(httpd_t wp);
extern int ifx_get_glob_IPv6();
extern char *status_str;

static int index_selected = -1;

extern LTQ_MAPI_Firewall_Rule * mapi_get_firewall_rule(LTQ_MAPI_Firewall_Rule *fwl_rule, int32 index);
extern LTQ_MAPI_Firewall_Rule * mapi_set_firewall_rule_add(LTQ_MAPI_Firewall_Rule *fwl_rule, int32 index);
extern LTQ_MAPI_Firewall_Rule * mapi_set_firewall_rule_del(LTQ_MAPI_Firewall_Rule *fwl_rule, int32 index);
extern int mapi_get_int(char *variable, void *val, int len, char *rc_file, char *tag);
extern int mapi_get_str(char *variable, void *val, int len, char *rc_file, char *tag);
extern int mapi_set_str(char *variable, char *val, char *rc_file, char *tag);
extern int mapi_set_int(char *variable, int val, char *rc_file, char *tag);

void ifx_get_firewall_config(int eid, httpd_t wp, int argc, char_t ** argv)
{
	LTQ_MAPI_Firewall_Config cf;
	char local_buf[256];

	a_assert(wp);
	memset(&cf, 0x00, sizeof(cf));

	mapi_get_firewall_config(&cf);

#if 0
	snprintf(local_buf, sizeof(local_buf), "Enable :%d, Config:%d, AdvancedLevel:%d, Type:\"%s\",\
 Version:\"%s\", LastChange:\"%d\", LevelNumberOfEntries:%d, ChainNumberOfEntries:%d", 
	cf.Enable, cf.Config, cf.AdvancedLevel, cf.Type,
	cf.Version, (int)cf.LastChange, cf.LevelNumberOfEntries,
	cf.ChainNumberOfEntries); 
#else
	snprintf(local_buf, sizeof(local_buf), "Enable :%d, Config:%d",
	cf.Enable, cf.Config); 

#endif
	ifx_httpdWrite(wp, T("%s"), local_buf);

}

void ifx_set_ipv6_firewall_post(httpd_t wp, char_t * path, char_t * query)
{
	char	cmd[128];
	char_t *fmode = ifx_httpdGetVar(wp, T("firewall_mode"), T(""));
	int	firewall_mode = atoi(fmode);
	LTQ_MAPI_Firewall_Config cf;
	if(ifx_get_glob_IPv6() == 0) {
		websNextPage(wp);
		return;
	}

	memset(&cf, 0x00, sizeof(cf));
	mapi_get_firewall_config(&cf);

	/* Update Configuration */

	if (firewall_mode >=0 && firewall_mode < 5) {
		cf.Config = firewall_mode;
		if(firewall_mode == 0) {
			cf.Enable = 0;
		} else {
			cf.Enable = 1;
		}
	}
	
	/* Save configuration */

	if (mapi_set_firewall_config(&cf) == NULL) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}

	if (ifx_flash_write() <= 0) {
		int ret=0;
		COPY_TO_STATUS("%s", "Failed to save settings")
		ifx_httpdRedirect(wp, "err_page.html");
IFX_Handler:
		return ;
	}

		
	/* Execute command */

	snprintf(cmd, sizeof(cmd), "%s stop filter all", FIREWALL6_CMD);
	system(cmd);
	switch (firewall_mode) {
	case 0: /* Off */
		break;
	case 1:	/* CPE Policy */
		snprintf(cmd, sizeof(cmd), "%s start filter all", FIREWALL6_CMD);
		system(cmd);
		break;
	case 2: /* High */
	case 3: /* Low */
	case 4: /* Advanced */
		snprintf(cmd, sizeof(cmd), "%s start filter all", FIREWALL6_CMD);
		system(cmd);
		break;
		
	}
	websNextPage(wp);
}
const char * get_proto(int prot) 
{
	struct my_proto {
		int prot;
		char protocol[8];
	};
	int i;
	static struct my_proto list[] = {
		{ 17, "UDP"},
		{ 6, "TCP"},
		{ 1, "ICMP"},
		{ 51, "AH"},
		{ 50, "ESP"},
		{ 58, "ICMPv6"},
		{ 0, "" },
	};
	for(i=0; i< sizeof(list)/sizeof(list[0]); i++) {
		if(prot == list[i].prot)
			return list[i].protocol;
	}
	return "*";
}
	
void ifx_get_firewall_packetfilter_ng(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char tbuf[2048];
	LTQ_MAPI_Firewall_Rule rule;
	
	int count = 0, i;
	
	/* Sample "[\"3\",\"4000::2\",\"443\",\"5009::2/64\", \"*\",\"UDP\",\"LAN0\",\"WANIP0\", \"1\" ],\n"; */

	mapi_get_int(TAG_FIREWALL_RULE"_Count", &count, sizeof(count), FILE_RC_CONF, TAG_FIREWALL_RULE);
	for(i=0; i< count; i++) {
		memset(&rule, sizeof(rule), sizeof(rule));
		if(mapi_get_firewall_rule(&rule, i) != NULL) {
			char sip[64] = "*";
			char dip[64] = "*";
			char dp[64] = "*";
			char sp[64] = "*";
			
			if(strcmp(rule.SourceIP, "::") && rule.SourceIP[0] != '\0' ) {
				char prelen[8] = "";
				if(rule.SourceMask > 0 && rule.SourceMask <=128) {
					snprintf(prelen, sizeof(prelen), "/%d", rule.SourceMask); 
				}
				snprintf(sip, sizeof(sip), "%s%s%s", 
					rule.SourceIPExclude?"!":"", rule.SourceIP, prelen );
			}
			if(strcmp(rule.DestIP, "::") && rule.DestIP[0] != '\0' ) {
				char prelen[8] = "";
				if(rule.DestMask > 0 && rule.DestMask <=128) {
					snprintf(prelen, sizeof(prelen), "/%d", rule.DestMask); 
				}
				snprintf(dip, sizeof(dip), "%s%s%s", 
					rule.DestIPExclude?"!":"", rule.DestIP, prelen );
			}


			if(rule.SourcePort > 0 ) {
				char spr[16];
				snprintf(spr, sizeof(spr), "%d", rule.SourcePortRangeMax);
				snprintf(sp, sizeof(sp), "%s%d%s%s", rule.SourcePortExclude?"!":"",
							rule.SourcePort, rule.SourcePortRangeMax?":":"",
							rule.SourcePortRangeMax?spr:"");
			}

			if(rule.DestPort > 0 ) {
				char dpr[16];
				snprintf(dpr, sizeof(dpr), "%d", rule.DestPortRangeMax);
				snprintf(dp, sizeof(dp), "%s%d%s%s", rule.DestPortExclude?"!":"",
							rule.DestPort, rule.DestPortRangeMax?":":"",
							rule.DestPortRangeMax?dpr:"");
			}

			snprintf(tbuf, sizeof(tbuf), 
			"[\"%d\",\"%s\",\"%s\",\"%s\", \"%s\",\"%s%s\",\"%s%s\",\"%s%s\", \"%s\", \"%d\"],\n",
			i+1,
			sip,
			sp,
			dip,
			dp,
			rule.ProtocolExclude?"!":"", get_proto(rule.Protocol),
			rule.SourceInterfaceExclude?"!":"", rule.SourceInterface,
			rule.DestInterfaceExclude?"!":"", rule.DestInterface,
			rule.Target,
			rule.Enable);
			
			
			ifx_httpdWrite(wp, tbuf);
		}
	}
}
void ifx_get_firewall_packetfilter_modify_ng(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char tbuf[1024] = { 0 };
	/* "2", "LAN0", "1", "Any", "0", "IPv6", "3000::1", "64", "0", "2001:1:2:3::", "48", "0", "6", "0", "790", "800", "1", "80", "", "0", "2", "1" */

	LTQ_MAPI_Firewall_Rule rule;
	if (index_selected != -1 ) {
		if(mapi_get_firewall_rule(&rule, index_selected) != NULL) {
			snprintf(tbuf, sizeof(tbuf), 
				"\"%d\", \"%s\", \"%d\", \"%s\", \"%d\", \"%s\","
				"\"%s\", \"%d\", \"%d\", \"%s\", \"%d\", \"%d\","
				"\"%d\", \"%d\", \"%d\", \"%d\", \"%d\", \"%d\","
				"\"%d\", \"%d\", \"%s\", \"%d\", \"%d\"",
				index_selected, rule.SourceInterface, rule.SourceInterfaceExclude,
				rule.DestInterface, rule.DestInterfaceExclude, (rule.IPVersion ==4)?"IPv4":"IPv6", 
				rule.DestIP, rule.DestMask, rule.DestIPExclude,
				rule.SourceIP, rule.SourceMask, rule.SourceIPExclude,
				rule.Protocol, rule.ProtocolExclude, rule.DestPort, 
				rule.DestPortRangeMax, rule.DestPortExclude, rule.SourcePort,
				rule.SourcePortRangeMax, rule.SourcePortExclude, rule.Target,
				rule.Enable, rule.iid.cpeId.Id);

			ifx_httpdWrite(wp, tbuf);
		}
	}
	index_selected = -1;
}

void ifx_get_firewall_packetfilter_enabled(int eid, httpd_t wp, int argc, char_t ** argv)
{

	int pfilter_disabled = 0;
	int enabled;

	mapi_get_int("FWL_pfilter_DISABLED", &pfilter_disabled, sizeof(int), FILE_RC_CONF, "firewall_plugins");
	enabled = (!pfilter_disabled);
	if (enabled == 0) {
		ifx_httpdWrite(wp, "");
	}else {
		ifx_httpdWrite(wp, "checked");
	}
}


void ifx_set_firewall_packetfilter_ng(httpd_t wp, char_t * path, char_t * query)
{
	int  pfStatus = atoi(ifx_httpdGetVar(wp, T("pfStatus"), T("")));
	int  pfilter_disabled = 0;
	int  enabled;
	char cmd[256];
	int  config_save = 0; /* off */
	char *subaction = ifx_httpdGetVar(wp, T("subaction"), T(""));
	enum action { ADD_ENTRY=1, DELETE_ENTRY, MODIFY_ENTRY} action ;
	LTQ_MAPI_Firewall_Rule rule;
	int ret = -1;
	int dont_run_cmd = 0;

	if(ifx_get_glob_IPv6() == 0) {
		websNextPage(wp);
		return;
	}

	if (!strcmp(subaction, "MODIFY_ENTRY")) {
		action = MODIFY_ENTRY;
	} else if (!strcmp(subaction, "ADD_ENTRY")) {
		action = ADD_ENTRY;
	} else if (!strcmp(subaction, "DELETE_ENTRY")) {
		action = DELETE_ENTRY;
	} else {
		action = 0;
	}

	index_selected = atoi(ifx_httpdGetVar(wp, T("delindex"), T("")));
	
	switch (action) {
	case ADD_ENTRY:
		index_selected = -1;
	case MODIFY_ENTRY:
		websNextPage(wp);
		return;
	case DELETE_ENTRY:
		if(mapi_get_firewall_rule(&rule, index_selected) != NULL) {
			if (mapi_set_firewall_rule_del(&rule, index_selected) == NULL) {
		 		COPY_TO_STATUS("Error occured while saving the config.");
                                ifx_httpdRedirect(wp, "err_page.html");
				return;
			}
		}
		config_save = 1;
		break;
	default:
		break;
	}
	
	

	/* Check for Enable / Disable */
	mapi_get_int("FWL_pfilter_DISABLED", &pfilter_disabled, sizeof(int), FILE_RC_CONF, "firewall_plugins");
	enabled = (!pfilter_disabled);

	if(pfStatus != 1) { /* stop before set */
		snprintf(cmd, sizeof(cmd), "%s stop filter pfilter", FIREWALL_CMD);
		system(cmd);
		dont_run_cmd = 1;
	}

	if (enabled != pfStatus) {
		int ret;
		ret = mapi_set_int("FWL_pfilter_DISABLED", enabled, FILE_RC_CONF, "firewall_plugins");
		if(pfStatus == 1) { /* stop before set */
			snprintf(cmd, sizeof(cmd), "%s start filter pfilter", FIREWALL_CMD);
			system(cmd);
			dont_run_cmd = 1;
		}
		if(ret != IFX_SUCCESS) {
			ifx_httpdError(wp, 400, T("Internal Error, Unable to save config "));
			return;
		}
		config_save = 1; /* on */
	}

	

	

	if (config_save == 1 ) {
		if(enabled == 1) {
			snprintf(cmd, sizeof(cmd), "%s start filter pfilter", FIREWALL_CMD);
		} else {
			snprintf(cmd, sizeof(cmd), "%s stop filter pfilter", FIREWALL_CMD);
		}
		if(dont_run_cmd == 0) {
			system(cmd);
		}
		if (ifx_flash_write() <= 0) {
                	ifx_httpdError(wp, 500, "Fail to save Setting");
                	return;
        	}
	}
	websNextPage(wp);

IFX_Handler:
	if(ret != IFX_SUCCESS) {
	}
	ifx_httpdError(wp, 500, "Internal Error");
}
void ifx_set_firewall_packetfilter_add_ng(httpd_t wp, char_t * path, char_t * query)
{

	int ret;
	LTQ_MAPI_Firewall_Rule rule; 
	struct sockaddr_in6 addr;
	char_t *iintf = ifx_httpdGetVar(wp, T("RULE_INGRESS_INTF"), T(""));
	char_t *eintf = ifx_httpdGetVar(wp, T("RULE_EGRESS_INTF"), T(""));
	/* int ipversion = atoi(ifx_httpdGetVar(wp, T("RULE_IPVERSION"), T("")));  */
	char_t *dstaddr = ifx_httpdGetVar(wp, T("RULE_IPV6_DST_ADDR"), T(""));
	int dprefix_len = atoi(ifx_httpdGetVar(wp, T("dst_prefix_len"), T("")));
	char_t *srcaddr = ifx_httpdGetVar(wp, T("RULE_IPV6_SRC_ADDR"), T(""));
	int sprefix_len = atoi(ifx_httpdGetVar(wp, T("src_prefix_len"), T("")));
	int protocol =  atoi(ifx_httpdGetVar(wp, T("RULE_PROTOCOL"), T("")));
	int sport_start = atoi(ifx_httpdGetVar(wp, T("RULE_SRC_PORT_START"), T("")));
	int sport_end = atoi(ifx_httpdGetVar(wp, T("RULE_SRC_PORT_END"), T("")));
	int dport_start = atoi(ifx_httpdGetVar(wp, T("RULE_DST_PORT_START"), T("")));
	int dport_end = atoi(ifx_httpdGetVar(wp, T("RULE_DST_PORT_END"), T("")));
	char *rule_target = ifx_httpdGetVar(wp, T("RULE_TARGET"), T(""));
	int rule_enabled = atoi(ifx_httpdGetVar(wp, T("RULE_ENABLE"), T("")));
	int iintf_ex = atoi(ifx_httpdGetVar(wp, T("RULE_INGRESS_INTF_EXCLUDE"), T("")));
	int eintf_ex = atoi(ifx_httpdGetVar(wp, T("RULE_EGRESS_INTF_EXCLUDE"), T("")));
	int saddr_ex = atoi(ifx_httpdGetVar(wp, T("RULE_IPV6_SRC_ADDR_EXCLUDE"), T("")));
	int daddr_ex = atoi(ifx_httpdGetVar(wp, T("RULE_IPV6_DST_ADDR_EXCLUDE"), T("")));
	int prot_ex = atoi(ifx_httpdGetVar(wp, T("RULE_PROTOCOL_EXCLUDE"), T("")));
	int dport_ex = atoi(ifx_httpdGetVar(wp, T("RULE_DST_PORT_EXCLUDE"), T("")));
	int sport_ex = atoi(ifx_httpdGetVar(wp, T("RULE_SRC_PORT_EXCLUDE"), T("")));
	int delindex = atoi(ifx_httpdGetVar(wp, T("delindex"), T("")));
	char *subaction = ifx_httpdGetVar(wp, T("subaction"), T(""));
	char cmd[256];

	if(ifx_get_glob_IPv6() == 0) {
		websNextPage(wp);
		return;
	}

	memset(&rule, 0, sizeof(rule));
	ret = inet_pton(AF_INET6, dstaddr, &(addr.sin6_addr));
	if (ret > 0 ) {
		snprintf(rule.DestIP, sizeof(rule.DestIP), "%s", dstaddr);
		if (!(dprefix_len > 0 && dprefix_len <=128)) {
			dprefix_len = 0;
		}
		rule.DestMask = dprefix_len;
		rule.DestIPExclude = daddr_ex;
	}

	ret = inet_pton(AF_INET6, srcaddr, &(addr.sin6_addr));
	if (ret > 0 ) {
		snprintf(rule.SourceIP, sizeof(rule.SourceIP), "%s", srcaddr);
		if (!(sprefix_len > 0 && sprefix_len <=128)) {
			sprefix_len = 0;
		}
		rule.SourceMask = sprefix_len;
		rule.SourceIPExclude = saddr_ex;
	}
	
	

        rule.Enable = rule_enabled;
        rule.Status = 1;
        snprintf(rule.Target, sizeof(rule.Target), "%s",  rule_target);
	snprintf(rule.SourceInterface, sizeof(rule.SourceInterface), "%s", iintf);
	rule.SourceInterfaceExclude = iintf_ex;
	snprintf(rule.DestInterface, sizeof(rule.DestInterface), "%s", eintf);
	rule.DestInterfaceExclude = eintf_ex;
        rule.IPVersion = 41; 	/* ipv6 = 41, ipv4 = 4 */
        rule.Protocol = protocol;
        rule.ProtocolExclude = prot_ex;
	rule.iid.cpeId.Id = delindex;

	if ( protocol == 6 /* TCP */ || protocol == 17 )
	switch (protocol) {
	
	case 6: 	/* TCP */
	case 17: 	/* UDP */
		rule.DestPort = dport_start;
        	rule.DestPortRangeMax = dport_end;
        	rule.DestPortExclude = dport_ex; 
        	rule.SourcePort = sport_start;
       		rule.SourcePortRangeMax = sport_end;
        	rule.SourcePortExclude = sport_ex;
		break;
	}

	if (!strcmp(subaction, "MODIFY")) {
		rule.iid.cpeId.Id = delindex;
		if(mapi_set_firewall_rule(&rule, delindex) != NULL) {
			snprintf(cmd, sizeof(cmd), "%s start filter pfilter", FIREWALL_CMD);
			system(cmd);
			if (ifx_flash_write() <= 0) {
		 		COPY_TO_STATUS("Error occured while saving the config.");
                                ifx_httpdRedirect(wp, "err_page.html");
				return;
			}
		} else {

		 	COPY_TO_STATUS("Error occured while modifying the entry");
                        ifx_httpdRedirect(wp, "err_page.html");
			return;
		}
	} else if(!strcmp(subaction, "ADD")) {
		if(mapi_set_firewall_rule_add(&rule, delindex) != NULL) {
			snprintf(cmd, sizeof(cmd), "%s start filter pfilter", FIREWALL_CMD);
			system(cmd);
			if (ifx_flash_write() <= 0) {
		 		COPY_TO_STATUS("Error occured while saving the config.");
				ifx_httpdRedirect(wp, "err_page.html");
				return;
			}

		} else {
		 	COPY_TO_STATUS("Error occured while adding the entry");
                        ifx_httpdRedirect(wp, "err_page.html");
			return;
		}
	}
	websNextPage(wp);
IFX_Handler:
	ifx_httpdError(wp, 500, "Internal Error");
}
#endif				//CONFIG_FEATURE_FIREWALL
