#ifndef _IFX_CGI_H
#define _IFX_CGI_H

#include "ifx_amazon_cgi.h"
extern int ifx_httpdWrite(httpd_t wp, char_t * fmt, ...);
extern void ifx_httpdError(httpd_t wp, int code, char_t * msg, ...);
extern int ifx_httpdWrite(httpd_t wp, char_t * fmt, ...);
extern int ifx_cgi_adsl_phyconfig_get_bit_allocated_per_tone(int eid,
							     httpd_t wp,
							     int argc,
							     char_t ** argv);
extern char_t *ifx_httpdGetVar(httpd_t wp, char_t * var, char_t * def);
extern void websNextPage(httpd_t wp);

#ifdef PLATFORM_VR9
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
#define DSL_CPE_DEVICE_NAME "/dev/dsl_cpe_api"
#else
#define DSL_CPE_DEVICE_NAME "/dev/dsl_cpe_api/0"
#endif
#else
#define DSL_CPE_DEVICE_NAME "/dev/dsl_cpe_api"
#endif

#endif
