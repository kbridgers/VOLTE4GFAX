#include <ifx_emf.h>
#include "./ifx_cgi_common.h"
#include "ifx_httpd_method.h"
#include "ifx_amazon_cgi_time.h"
#include <time.h>
#include <ifx_common.h>
#include "./ifx_amazon_cgi.h"
#include "./ifx_amazon_cgi_getFunctions.h"
#include <string.h>
#include <signal.h>
#include <stdbool.h>
#include <sys/types.h>
#include <sys/wait.h>
#define IFNAMSIZ 16
#define TAG_MULTICAST	"mcast_proxy_snooping"
#define IFACE_SIZE		256

struct igmp_wan_list {
	char8 wan_name[MAX_NAME_SIZE];
	char8 ifname[MAX_NAME_SIZE];
};

struct igmp_wan_list igmp_wan[MAX_VCCs];
int32 igmp_wan_populate = 0;
#ifndef AARIF
struct igmp_rc {
	uint32 igmp_query_interval;
	uint32 igmp_query_resp_interval;
	uint32 igmp_last_mem_query_interval;
	uint32 igmp_last_mem_query_count;
	int32 igmp_query_interval_status;
	int32 igmp_query_resp_interval_status;
	int32 igmp_last_mem_query_interval_status;
	int32 igmp_last_mem_query_count_status;
	int32 igmp_fast_leave_status;
	int32 igmp_snooping_status;
	int32 igmp_proxy_status;
	int32 igmp_snooping_mode;

	uint32 mld_query_interval;
	uint32 mld_query_resp_interval;
	uint32 mld_last_mem_query_interval;
	uint32 mld_last_mem_query_count;
	int32 mld_query_interval_status;
	int32 mld_query_resp_interval_status;
	int32 mld_last_mem_query_interval_status;
	int32 mld_last_mem_query_count_status;
	int32 mld_fast_leave_status;
	int32 mld_snooping_status;
	int32 mld_proxy_status;
	int32 mld_snooping_mode;
#ifdef FEATURE_LTQ_MCAST_FILTER_PORT	
	int32 mcast_iface_filter_status;
#endif
	char8 mcast_grp_entry[MAX_DATA_LEN];
	char8 up_iface_str[IFACE_SIZE];
	char8 up_wan_iface_str[IFACE_SIZE];
	char8 down_iface_str[IFACE_SIZE];
#ifdef FEATURE_LTQ_MCAST_FILTER_PORT	
	char8 mcast_iface_filter_str[IFACE_SIZE];
#endif
};
#else
struct igmp_rc {
	uint32 query_interval;
	uint32 query_resp_interval;
	uint32 last_mem_query_interval;
	uint32 last_mem_query_count;
	char8 mcast_grp_entry[MAX_DATA_LEN];
	char8 up_iface_str[IFACE_SIZE];
	char8 up_wan_iface_str[IFACE_SIZE];
	char8 down_iface_str[IFACE_SIZE];
	int32 query_interval_status;
	int32 query_resp_interval_status;
	int32 last_mem_query_interval_status;
	int32 last_mem_query_count_status;
	int32 fast_leave_status;
	int32 igmp_snooping_status;
	int32 igmp_proxy_status;
	int32 igmp_snooping_mode;
};
#endif

extern void websNextPage(httpd_t wp);
extern int ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);

void populate_igmp_wan_list();
//+++++++++++++++++++++++++++++ IGMP SNOOPING SETTINGS ++++++++++++++++++++++++++++++++++++++++//

void ifx_set_igmp_snooping_status(httpd_t wp, char8 * path, char8 * query);	// wizard_host.asp; system_hostname.asp
int32 ifx_get_igmp_snooping_status(int32 eid, httpd_t wp, int32 argc,
				   char8 ** argv);

//+++++++++++++++++++++++++++++ IGMP PROXY SETTINGS ++++++++++++++++++++++++++++++++++++++++//

int ifx_get_igmp_wan_interface_list(int32 eid, httpd_t wp, int32 argc,
				    char8 ** argv);
void ifx_get_igmp_wan_interface_table_data(int32 eid, httpd_t wp, int32 argc,
					   char8 ** argv);
void ifx_set_igmp_proxy(httpd_t wp, char8 * path, char8 * query);
int32 ifx_get_igmp_proxy_status(int32 eid, httpd_t wp, int32 argc,
				char8 ** argv);
void ifx_get_wan_conn_name(int32 eid, httpd_t wp, int32 argc, char8 ** argv);
void ifx_get_wan_confconn_name(int32 eid, httpd_t wp, int32 argc, char8 ** argv);
//+++++++++++++++++++++++++++++ IGMP ADVANCED SETTINGS ++++++++++++++++++++++++++++++++++++++++//

extern void ifx_GetIgmpParam_FromRcConf(struct igmp_rc *ptrGet);
extern int ifx_SetIgmpParam_ToRcConf(struct igmp_rc *ptrSet);
extern int ifx_get_all_wan_conn_names(char **wan_conn_names, int *count);
extern int ifx_get_all_wan_confconn_names(char **wan_conn_names, int *count);

void ifx_set_igmp_advanced(httpd_t wp, char8 * path, char8 * query);

void ifx_get_igmp_advanced_fast_leave(int32 eid, httpd_t wp, int32 argc,
				      char8 ** argv);

void ifx_get_igmp_advanced_query_interval(int32 eid, httpd_t wp, int32 argc,
					  char8 ** argv);
void ifx_get_igmp_advanced_query_interval_range(int32 eid, httpd_t wp,
						int32 argc, char8 ** argv);

void ifx_get_igmp_advanced_query_interval_response(int32 eid, httpd_t wp,
						   int32 argc, char8 ** argv);
void ifx_get_igmp_advanced_query_interval_response_range(int32 eid, httpd_t wp,
							 int32 argc,
							 char8 ** argv);

void ifx_get_igmp_advanced_last_member_query_interval(int32 eid, httpd_t wp,
						      int32 argc,
						      char8 ** argv);
void ifx_get_igmp_advanced_last_member_query_interval_range(int32 eid,
							    httpd_t wp,
							    int32 argc,
							    char8 ** argv);

void ifx_get_igmp_advanced_last_member_query_count(int32 eid, httpd_t wp,
						   int32 argc, char8 ** argv);
void ifx_get_igmp_advanced_last_member_query_count_range(int32 eid, httpd_t wp,
							 int32 argc,
							 char8 ** argv);

void ifx_populate_static_entry_parameters(int32 eid, httpd_t wp, int32 argc,
					  char8 ** argv);
//+++++++++++++++++++++++++++++ IGMP ADVANCED SETTINGS ++++++++++++++++++++++++++++++++++++++++//

int ifx_get_tunnel_wan_interface_list(int32 eid, httpd_t wp, int32 argc,
				      char8 ** argv);

/**************  IGMP SNOOPING FUNCTIONS  **********************/

void ifx_set_igmp_snooping_status(httpd_t wp, char8 * path, char8 * query)
{
	char8 *pCheck_igmp = NULL;
	int32 mode = 0;
	int32 mcast_status = 0;
	struct igmp_rc igmp_rc_tt;
	int32 ret = IFX_SUCCESS, outFlag = IFX_F_DEFAULT, flags = IFX_F_DEFAULT;
        char8 sValue[MAX_FILELINE_LEN];
	a_assert(wp);

	// Get value from ASP file
	pCheck_igmp = ifx_httpdGetVar(wp, T("igmp_snooping_enable"), T(""));

	mcast_status = atoi(pCheck_igmp);

	if (mcast_status == 1 ) {
		pCheck_igmp = ifx_httpdGetVar(wp, T("snooping_mode"), T(""));
		mode = atoi(pCheck_igmp);
	}

	/* Read rc.conf file and populate the structure */
	ifx_GetIgmpParam_FromRcConf(&igmp_rc_tt);

	if ((igmp_rc_tt.igmp_snooping_status != mcast_status) ||
            ((mcast_status == 1) && (igmp_rc_tt.igmp_snooping_mode != mode))){

		/* Update  related structure field with current value */
		igmp_rc_tt.igmp_snooping_status = mcast_status;



	if ((ret =
             ifx_GetObjData(FILE_RC_CONF, TAG_IPV6, "ipv6_status", flags,
                            (IFX_OUT uint32 *) & outFlag,
                            sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
        }
	
	if(atoi(sValue)==1)
  		igmp_rc_tt.mld_snooping_status = mcast_status;              
        

		if (mcast_status == 1)
			igmp_rc_tt.igmp_snooping_mode = mode;

		if (mcast_status == 1)
			igmp_rc_tt.mld_snooping_mode = mode;

		//Write to /ramdisk/flash/rc.conf
		if (IFX_FAILURE == ifx_SetIgmpParam_ToRcConf(&igmp_rc_tt)) {
			ifx_httpdError(wp, 500,
				       "Fail to set multicast snooping parameters in rc.conf");
			return;
		}
	}

	websNextPage(wp);
}

int32 ifx_get_igmp_snooping_status(int32 eid, httpd_t wp, int32 argc,
				   char8 ** argv)
{
	int32 snooping_status = 0;
	char_t *name = NULL;
	char8 sVal[MAX_DATA_LEN];

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	if (!gstrcmp(name, T("igmp_snooping"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_snooping_status",
		     sVal) == 1) {
			snooping_status = atoi(sVal);
		}
	}

	else if (!gstrcmp(name, T("mld_snooping"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_snooping_status",
		     sVal) == 1) {
			snooping_status = atoi(sVal);
		}
	}

	ifx_httpdWrite(wp, T("%d"), snooping_status);

	return 0;
}

int32 ifx_get_igmp_snooping_mode(int32 eid, httpd_t wp, int32 argc,
				 char8 ** argv)
{
	int32 snooping_mode = 0;
	char8 sVal[MAX_DATA_LEN];

	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_snooping_mode",
	     sVal) == 1) {
		snooping_mode = atoi(sVal);
	}

	ifx_httpdWrite(wp, T("%d"), snooping_mode);

	return 0;
}

int32 ifx_get_igmp_proxy_status(int32 eid, httpd_t wp, int32 argc,
				char8 ** argv)
{
	int32 proxy_status = 0;
	char_t *name = NULL;
	char8 sVal[MAX_DATA_LEN];

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	if (!gstrcmp(name, T("igmp_proxy"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_proxy_status",
		     sVal) == 1) {
			proxy_status = atoi(sVal);
		}
	}

	else if (!gstrcmp(name, T("mld_proxy"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_proxy_status",
		     sVal) == 1) {
			proxy_status = atoi(sVal);
		}
	}

	ifx_httpdWrite(wp, T("%d"), proxy_status);

	return 0;
}

void ifx_get_igmp_wan_interface_table_data(int32 eid, httpd_t wp, int32 argc,
					   char8 ** argv)
{
	char8 sVal[MAX_DATA_LEN], iflist[MAX_DATA_LEN];
	char8 wan_confconnName[MAX_CONN_NAME_LEN];
	WAN_TYPE wan_type = WAN_TYPE_IP;

	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_MULTICAST, "mcast_upstream_wan", sVal) == 1) {
		if (sVal[0] != '\0') {
			char8 *ptr = NULL;
			char8 *ptr_iflist = NULL;
			int32 i;

			if (igmp_wan_populate == 0) {
				populate_igmp_wan_list();
				igmp_wan_populate = 1;
			}
			ptr_iflist = iflist;

			ptr = strtok(sVal, ",");
			while (ptr) {
				for (i = 0; i < MAX_VCCs; i++) {
					if (!strcmp(igmp_wan[i].wan_name, ptr)) {
						if (strstr(igmp_wan[i].wan_name, "WANIP"))
				                        wan_type = WAN_TYPE_IP;
				                else if (strstr(igmp_wan[i].wan_name, "WANPPP"))
				                        wan_type = WAN_TYPE_PPP;	
						if (ifx_get_wan_confconnName_from_connName (ptr, wan_confconnName, wan_type) == IFX_SUCCESS)
						strcpy(ptr_iflist,
						       wan_confconnName);
						ptr_iflist +=
						    strlen(wan_confconnName);
						strcpy(ptr_iflist, ",");
						ptr_iflist += strlen(",");
						break;
					}
				}
				ptr = strtok(NULL, ",");
			}

			ptr_iflist--;
			ptr_iflist[0] = '\0';
			ifx_httpdWrite(wp, T("%s"), iflist);
		} else {
			sVal[0] = '\0';
			ifx_httpdWrite(wp, T("%s"), sVal);
		}
	}
}

int ifx_get_igmp_wan_interface_list(int32 eid, httpd_t wp, int32 argc,
				    char8 ** argv)
{
	char8 *wan_conn_names = NULL;
	char8 wan_confconnName[MAX_CONN_NAME_LEN];
	int32 wancnt = 0, i;
	WAN_TYPE wan_type = WAN_TYPE_IP;

	ifx_httpdWrite(wp,
		       T("\t\t<option value=0>select interface</option>\n"));

	if (IFX_SUCCESS != ifx_get_all_wan_conn_names(&wan_conn_names, &wancnt)) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error-->Failed to get the WAN connections !!\n\n",
		     __func__);
		goto IFX_Err_Handler;
	}

	for (i = 0; i < wancnt; i++) {
		memset(igmp_wan[i].wan_name, 0x00,
		       sizeof(igmp_wan[i].wan_name));
		memset(igmp_wan[i].ifname, 0x00, sizeof(igmp_wan[i].ifname));

		sprintf(igmp_wan[i].wan_name, "%s",
			GET_WAN_CONN_NAME(wan_conn_names, i));

		if (strstr(igmp_wan[i].wan_name, "WANIP"))
			wan_type = WAN_TYPE_IP;
		else if (strstr(igmp_wan[i].wan_name, "WANPPP"))
			wan_type = WAN_TYPE_PPP;

		if (IFX_SUCCESS !=
		    ifx_get_wan_ifname_from_connName(igmp_wan[i].wan_name,
						     igmp_wan[i].ifname,
						     wan_type)) {
			IFX_DBG
			    ("\n\n In Function [%s] : Error-->Failed to get the interface name of %s !!\n\n",
			     __func__, igmp_wan[i].wan_name);
			igmp_wan[i].ifname[0] = '\0';
		}

		if (ifx_get_wan_confconnName_from_connName (GET_WAN_CONN_NAME(wan_conn_names, i),wan_confconnName ,wan_type) == IFX_SUCCESS)
                        {
                                ifx_httpdWrite(wp, T("\"%s\";\n"),wan_confconnName);
                        }

                        ifx_httpdWrite(wp,
                                       T
                                       ("\t\t\t\t\t<option value=\"%d\">%s</option>\n"),
                                       (i + 1), wan_confconnName);
	}

      IFX_Err_Handler:
	igmp_wan_populate = 1;
	IFX_MEM_FREE(wan_conn_names);

	return 0;
}


int ifx_get_tunnel_wan_interface_list(int32 eid, httpd_t wp, int32 argc,
				      char8 ** argv)
{
	char8 *wan_conn_names = NULL;
	int32 wancnt = 0, i;

	ifx_httpdWrite(wp,
		       T("\t\t<option value=\"0\">select interface</option>"));

	if (IFX_SUCCESS != ifx_get_all_wan_conn_names(&wan_conn_names, &wancnt)) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error-->Failed to get the WAN connections !!\n\n",
		     __func__);
		goto IFX_Err_Handler;
	}

	for (i = 0; i < wancnt; i++)
                ifx_httpdWrite(wp, T("\t\t<option value=\"%s\">%s</option>"), 
				GET_WAN_CONN_NAME(wan_conn_names, i), 
				GET_WAN_CONN_NAME(wan_conn_names, i));


      IFX_Err_Handler:
	IFX_MEM_FREE(wan_conn_names);

	return 0;
}

void populate_igmp_wan_list(httpd_t wp, char8 * path, char8 * query)
{
	WAN_TYPE wan_type = WAN_TYPE_IP;
	char8 *wan_conn_names = NULL;
	int32 wancnt = 0, i;

	if (IFX_SUCCESS != ifx_get_all_wan_conn_names(&wan_conn_names, &wancnt)) {
		IFX_DBG
		    ("\n\n In Function [%s] : Error-->Failed to get the WAN connections !!\n\n",
		     __func__);
		goto IFX_Err_Handler;
	}

	for (i = 0; i < wancnt; i++) {
		memset(igmp_wan[i].wan_name, 0x00,
		       sizeof(igmp_wan[i].wan_name));
		memset(igmp_wan[i].ifname, 0x00, sizeof(igmp_wan[i].ifname));

		sprintf(igmp_wan[i].wan_name, "%s",
			GET_WAN_CONN_NAME(wan_conn_names, i));

		if (strstr(igmp_wan[i].wan_name, "WANIP"))
			wan_type = WAN_TYPE_IP;
		else if (strstr(igmp_wan[i].wan_name, "WANPPP"))
			wan_type = WAN_TYPE_PPP;

		if (IFX_SUCCESS !=
		    ifx_get_wan_ifname_from_connName(igmp_wan[i].wan_name,
						     igmp_wan[i].ifname,
						     wan_type)) {
			IFX_DBG
			    ("\n\n In Function [%s] : Error-->Failed to get the interface name of %s !!\n\n",
			     __func__, igmp_wan[i].wan_name);
			igmp_wan[i].ifname[0] = '\0';
		}

		ifx_httpdWrite(wp, T("\t\t<option value=\"%d\">%s</option>\n"),
			       (i + 1), GET_WAN_CONN_NAME(wan_conn_names, i));
	}

      IFX_Err_Handler:
	igmp_wan_populate = 1;
	IFX_MEM_FREE(wan_conn_names);
}


void ifx_get_wan_conn_name(int32 eid, httpd_t wp, int32 argc, char8 ** argv)
{
	int32 i = 0, count = 0, ret = IFX_SUCCESS;
        char8 iflist[MAX_DATA_LEN], *wan_conn_names = NULL, *ptr_iflist=NULL;

	ptr_iflist=iflist;
	       if ((ret =
                     ifx_get_all_wan_conn_names(&wan_conn_names,&count)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                        IFX_DBG
                            ("\n\n In Function [%s] : Error--> Failed to get wan connection names !!\n\n",
                             __FUNCTION__);
#endif
			return;
          	}
	for (i = 0; i < count; i++) {
                                                strcpy(ptr_iflist, GET_WAN_CONN_NAME(wan_conn_names, i));
                                                ptr_iflist +=
                                                    strlen(GET_WAN_CONN_NAME(wan_conn_names, i));
                                                strcpy(ptr_iflist, ",");
                                                ptr_iflist += strlen(",");
                                }
	ptr_iflist[0]='\0';
	ifx_httpdWrite(wp, T("%s"),iflist);
	
}

void ifx_get_wan_confconn_name(int32 eid, httpd_t wp, int32 argc, char8 ** argv)
{
	int32 i = 0, count = 0, ret = IFX_SUCCESS;
        char8 iflist[MAX_DATA_LEN], *wan_confconn_names = NULL, *ptr_iflist=NULL;

	ptr_iflist=iflist;
                if ((ret =
                     ifx_get_all_wan_confconn_names(&wan_confconn_names,&count)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                        IFX_DBG
                            ("\n\n In Function [%s] : Error--> Failed to get wan connection names !!\n\n",
                             __FUNCTION__);
#endif
			return;
                }
	for (i = 0; i < count; i++) {
                                                strcpy(ptr_iflist, GET_WAN_CONN_NAME(wan_confconn_names, i));
                                                ptr_iflist +=
                                                    strlen(GET_WAN_CONN_NAME(wan_confconn_names, i));
                                                strcpy(ptr_iflist, ",");
                                                ptr_iflist += strlen(",");
                                }
        ptr_iflist[0]='\0';
	ifx_httpdWrite(wp, T("%s"),iflist);

}

void ifx_set_igmp_proxy(httpd_t wp, char8 * path, char8 * query)
{
	char8 *pCheck_igmp = NULL;
	char8 *pCheck_mld = NULL;
	char8 *added_interface_list = NULL;
	struct igmp_rc igmp_rc_tp;
	char8 *ptr = NULL;
	char8 *iflist = NULL, *ptr_iflist = NULL;
	int32 i;
	a_assert(wp);

	// Get value from ASP file
	pCheck_igmp = ifx_httpdGetVar(wp, T("igmp_proxy_enable"), T(""));
	pCheck_mld = ifx_httpdGetVar(wp, T("mld_proxy_enable"), T(""));
	added_interface_list =
	    ifx_httpdGetVar(wp, T("added_interface_list"), T(""));

	/* Read rc.conf file and populate the structure */
	ifx_GetIgmpParam_FromRcConf(&igmp_rc_tp);

	/* Update  related structure field with current value */
	igmp_rc_tp.igmp_proxy_status = atoi(pCheck_igmp);
	igmp_rc_tp.mld_proxy_status = atoi(pCheck_mld);

	if (added_interface_list[0] != '\0') {
		iflist = (char *)malloc(strlen(added_interface_list) + 1);
		if (iflist == NULL) {
			ifx_httpdError(wp, 500, "Fail to allocate memory");
			return;
		}
		memset(iflist, 0, strlen(added_interface_list) + 1);
		ptr_iflist = iflist;

		ptr = strtok(added_interface_list, ",");
		while (ptr) {
			for (i = 0; i < MAX_VCCs; i++) {
				if (!strcmp(igmp_wan[i].wan_name, ptr)) {
					strcpy(ptr_iflist,
					       igmp_wan[i].wan_name);
					ptr_iflist +=
					    strlen(igmp_wan[i].wan_name);
					strcpy(ptr_iflist, ",");
					ptr_iflist += strlen(",");
					break;
				}
			}
			ptr = strtok(NULL, ",");
		}

		ptr_iflist--;
		ptr_iflist[0] = '\0';

		strcpy(igmp_rc_tp.up_wan_iface_str, iflist);
		free(iflist);
		iflist = NULL;
	} else
	{
		igmp_rc_tp.up_wan_iface_str[0] = '\0';
		igmp_rc_tp.up_iface_str[0] = '\0';
	}
	//Write to /ramdisk/flash/rc.conf
	if (IFX_FAILURE == ifx_SetIgmpParam_ToRcConf(&igmp_rc_tp)) {
		ifx_httpdError(wp, 500,
			       "Fail to set multicast proxy parameters in rc.conf");
		return;
	}

	websNextPage(wp);
}

//+++++++++++++++++++++++++++++ IGMP ADVANCED SETTINGS ++++++++++++++++++++++++++++++++++++++++//

void ifx_set_igmp_advanced(httpd_t wp, char8 * path, char8 * query)
{
	char8 *fast_leave_igmp;

	char8 *query_interval_igmp;
	char8 *query_interval_range_igmp;

	char8 *qresp_intv_igmp;
	char8 *qresp_intv_range_igmp;

	char8 *lmem_qintv_igmp;
	char8 *lmem_qintv_range_igmp;

	char8 *lmem_qcnt_igmp;
	char8 *lmem_qcnt_range_igmp;

	char8 *static_entry = NULL;

	int32 int_fast_leave_igmp;

	int32 iquery_interval_igmp;
	int32 iquery_interval_range_igmp;

	int32 iqresp_intv_igmp;
	int32 iqresp_intv_range_igmp;

	int32 ilmem_qintv_igmp;
	int32 ilmem_qintv_range_igmp;

	int32 ilmem_qcnt_igmp;
	int32 ilmem_qcnt_range_igmp;

	char8 *fast_leave_mld;

	char8 *query_interval_mld;
	char8 *query_interval_range_mld;

	char8 *qresp_intv_mld;
	char8 *qresp_intv_range_mld;

	char8 *lmem_qintv_mld;
	char8 *lmem_qintv_range_mld;

	char8 *lmem_qcnt_mld;
	char8 *lmem_qcnt_range_mld;

	int32 int_fast_leave_mld;

	int32 iquery_interval_mld;
	int32 iquery_interval_range_mld;

	int32 iqresp_intv_mld;
	int32 iqresp_intv_range_mld;

	int32 ilmem_qintv_mld;
	int32 ilmem_qintv_range_mld;

	int32 ilmem_qcnt_mld;
	int32 ilmem_qcnt_range_mld;

	struct igmp_rc igmp_rc_t;
	bool need_signal = false;

	fast_leave_igmp =
	    ifx_httpdGetVar(wp, T("igmp_advanced_fast_leave"), T(""));
	int_fast_leave_igmp = atoi((const char8 *)fast_leave_igmp);

	query_interval_igmp =
	    ifx_httpdGetVar(wp, T("igmp_advanced_query_interval"), T(""));
	iquery_interval_igmp = atoi((const char8 *)query_interval_igmp);

	query_interval_range_igmp =
	    ifx_httpdGetVar(wp, T("igmp_advanced_query_interval_range"), T(""));
	iquery_interval_range_igmp =
	    atoi((const char8 *)query_interval_range_igmp);

	qresp_intv_igmp =
	    ifx_httpdGetVar(wp, T("igmp_advanced_query_response_interval"),
			    T(""));
	iqresp_intv_igmp = atoi((const char8 *)qresp_intv_igmp);

	qresp_intv_range_igmp =
	    ifx_httpdGetVar(wp,
			    T("igmp_advanced_query_response_interval_range"),
			    T(""));
	iqresp_intv_range_igmp = atoi((const char8 *)qresp_intv_range_igmp);

	lmem_qintv_igmp =
	    ifx_httpdGetVar(wp, T("igmp_advanced_last_member_query_interval"),
			    T(""));
	ilmem_qintv_igmp = atoi((const char8 *)lmem_qintv_igmp);

	lmem_qintv_range_igmp =
	    ifx_httpdGetVar(wp,
			    T("igmp_advanced_last_member_query_interval_range"),
			    T(""));
	ilmem_qintv_range_igmp = atoi((const char8 *)lmem_qintv_range_igmp);

	lmem_qcnt_igmp =
	    ifx_httpdGetVar(wp, T("igmp_advanced_last_member_query_count"),
			    T(""));
	ilmem_qcnt_igmp = atoi((const char8 *)lmem_qcnt_igmp);

	lmem_qcnt_range_igmp =
	    ifx_httpdGetVar(wp,
			    T("igmp_advanced_last_member_query_count_range"),
			    T(""));
	ilmem_qcnt_range_igmp = atoi((const char8 *)lmem_qcnt_range_igmp);

	fast_leave_mld =
	    ifx_httpdGetVar(wp, T("mld_advanced_fast_leave"), T(""));
	int_fast_leave_mld = atoi((const char8 *)fast_leave_mld);

	query_interval_mld =
	    ifx_httpdGetVar(wp, T("mld_advanced_query_interval"), T(""));
	iquery_interval_mld = atoi((const char8 *)query_interval_mld);

	query_interval_range_mld =
	    ifx_httpdGetVar(wp, T("mld_advanced_query_interval_range"), T(""));
	iquery_interval_range_mld =
	    atoi((const char8 *)query_interval_range_mld);

	qresp_intv_mld =
	    ifx_httpdGetVar(wp, T("mld_advanced_query_response_interval"),
			    T(""));
	iqresp_intv_mld = atoi((const char8 *)qresp_intv_mld);

	qresp_intv_range_mld =
	    ifx_httpdGetVar(wp, T("mld_advanced_query_response_interval_range"),
			    T(""));
	iqresp_intv_range_mld = atoi((const char8 *)qresp_intv_range_mld);

	lmem_qintv_mld =
	    ifx_httpdGetVar(wp, T("mld_advanced_last_member_query_interval"),
			    T(""));
	ilmem_qintv_mld = atoi((const char8 *)lmem_qintv_mld);

	lmem_qintv_range_mld =
	    ifx_httpdGetVar(wp,
			    T("mld_advanced_last_member_query_interval_range"),
			    T(""));
	ilmem_qintv_range_mld = atoi((const char8 *)lmem_qintv_range_mld);

	lmem_qcnt_mld =
	    ifx_httpdGetVar(wp, T("mld_advanced_last_member_query_count"),
			    T(""));
	ilmem_qcnt_mld = atoi((const char8 *)lmem_qcnt_mld);

	lmem_qcnt_range_mld =
	    ifx_httpdGetVar(wp, T("mld_advanced_last_member_query_count_range"),
			    T(""));
	ilmem_qcnt_range_mld = atoi((const char8 *)lmem_qcnt_range_mld);

	static_entry = ifx_httpdGetVar(wp, T("static_entry"), T(""));

	/* Read rc.conf file and populate the structure */
	ifx_GetIgmpParam_FromRcConf(&igmp_rc_t);

	if (((igmp_rc_t.igmp_fast_leave_status != int_fast_leave_igmp) ||
	     (igmp_rc_t.igmp_query_interval_status != iquery_interval_igmp) ||
	     (igmp_rc_t.igmp_query_interval != iquery_interval_range_igmp) ||
	     (igmp_rc_t.igmp_query_resp_interval_status != iqresp_intv_igmp) ||
	     (igmp_rc_t.igmp_query_resp_interval != iqresp_intv_range_igmp) ||
	     (igmp_rc_t.igmp_last_mem_query_interval_status != ilmem_qintv_igmp)
	     || (igmp_rc_t.igmp_last_mem_query_interval !=
		 ilmem_qintv_range_igmp)
	     || (igmp_rc_t.igmp_last_mem_query_count_status != ilmem_qcnt_igmp)
	     || (igmp_rc_t.igmp_last_mem_query_count != ilmem_qcnt_range_igmp)
	     || (igmp_rc_t.mld_fast_leave_status != int_fast_leave_mld)
	     || (igmp_rc_t.mld_query_interval_status != iquery_interval_mld)
	     || (igmp_rc_t.mld_query_interval != iquery_interval_range_mld)
	     || (igmp_rc_t.mld_query_resp_interval_status != iqresp_intv_mld)
	     || (igmp_rc_t.mld_query_resp_interval != iqresp_intv_range_mld)
	     || (igmp_rc_t.mld_last_mem_query_interval_status !=
		 ilmem_qintv_mld)
	     || (igmp_rc_t.mld_last_mem_query_interval != ilmem_qintv_range_mld)
	     || (igmp_rc_t.mld_last_mem_query_count_status != ilmem_qcnt_mld)
	     || (igmp_rc_t.mld_last_mem_query_count != ilmem_qcnt_range_mld)
	     || (static_entry != NULL
		 && strcmp(igmp_rc_t.mcast_grp_entry, static_entry)))) {
		need_signal = true;
	}

	if (need_signal) {
		/* Update  related structure field with current value */
		igmp_rc_t.igmp_fast_leave_status = int_fast_leave_igmp;

		igmp_rc_t.igmp_query_interval_status = iquery_interval_igmp;
		if (igmp_rc_t.igmp_query_interval_status)
			igmp_rc_t.igmp_query_interval =
			    iquery_interval_range_igmp;

		igmp_rc_t.igmp_query_resp_interval_status = iqresp_intv_igmp;
		if (igmp_rc_t.igmp_query_resp_interval_status)
			igmp_rc_t.igmp_query_resp_interval =
			    iqresp_intv_range_igmp;

		igmp_rc_t.igmp_last_mem_query_interval_status =
		    ilmem_qintv_igmp;
		if (igmp_rc_t.igmp_last_mem_query_interval_status)
			igmp_rc_t.igmp_last_mem_query_interval =
			    ilmem_qintv_range_igmp;

		igmp_rc_t.igmp_last_mem_query_count_status = ilmem_qcnt_igmp;
		if (igmp_rc_t.igmp_last_mem_query_count_status)
			igmp_rc_t.igmp_last_mem_query_count =
			    ilmem_qcnt_range_igmp;

		igmp_rc_t.mld_fast_leave_status = int_fast_leave_mld;

		igmp_rc_t.mld_query_interval_status = iquery_interval_mld;
		if (igmp_rc_t.mld_query_interval_status)
			igmp_rc_t.mld_query_interval =
			    iquery_interval_range_mld;

		igmp_rc_t.mld_query_resp_interval_status = iqresp_intv_mld;
		if (igmp_rc_t.mld_query_resp_interval_status)
			igmp_rc_t.mld_query_resp_interval =
			    iqresp_intv_range_mld;

		igmp_rc_t.mld_last_mem_query_interval_status = ilmem_qintv_mld;
		if (igmp_rc_t.mld_last_mem_query_interval_status)
			igmp_rc_t.mld_last_mem_query_interval =
			    ilmem_qintv_range_mld;

		igmp_rc_t.mld_last_mem_query_count_status = ilmem_qcnt_mld;
		if (igmp_rc_t.mld_last_mem_query_count_status)
			igmp_rc_t.mld_last_mem_query_count =
			    ilmem_qcnt_range_mld;
		strcpy(igmp_rc_t.mcast_grp_entry, static_entry);

		//Write to /ramdisk/flash/rc.conf
		if (IFX_FAILURE == ifx_SetIgmpParam_ToRcConf(&igmp_rc_t)) {
			ifx_httpdError(wp, 500,
				       "Fail to Save Multicast Advanced Setting in rc.conf");
			return;
		}
	}

	websNextPage(wp);
}

void ifx_get_igmp_advanced_fast_leave(int32 eid, httpd_t wp, int32 argc,
				      char8 ** argv)
{
	int32 isEnabled = 0;
	char_t *name = NULL;
	char8 sVal[MAX_DATA_LEN];

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return;
	}

	if (!gstrcmp(name, T("igmp"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_MULTICAST,
		     "mcast_igmp_fast_leave_status", sVal) == 1) {
			isEnabled = atoi(sVal);
		}
	}

	else if (!gstrcmp(name, T("mld"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_fast_leave_status",
		     sVal) == 1) {
			isEnabled = atoi(sVal);
		}
	}

	if (isEnabled)
		ifx_httpdWrite(wp, T("checked"));
	else
		ifx_httpdWrite(wp, T(""));
}

void ifx_get_igmp_advanced_query_interval(int32 eid, httpd_t wp, int32 argc,
					  char8 ** argv)
{
	int32 isEnabled = 0;
	char_t *name = NULL;
	char8 sVal[MAX_DATA_LEN];

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return;
	}

	if (!gstrcmp(name, T("igmp"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_MULTICAST,
		     "mcast_igmp_query_interval_status", sVal) == 1) {
			isEnabled = atoi(sVal);
		}
	}

	else if (!gstrcmp(name, T("mld"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_MULTICAST,
		     "mcast_mld_query_interval_status", sVal) == 1) {
			isEnabled = atoi(sVal);
		}
	}

	if (isEnabled)
		ifx_httpdWrite(wp, T("checked"));
	else
		ifx_httpdWrite(wp, T(""));
}

void ifx_get_igmp_advanced_query_interval_range(int32 eid, httpd_t wp,
						int32 argc, char8 ** argv)
{
	int32 range_val = 125;
	char_t *name = NULL;
	char8 sVal[MAX_DATA_LEN];

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return;
	}

	if (!gstrcmp(name, T("igmp"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_query_interval",
		     sVal) == 1) {
			range_val = atoi(sVal);
		}
	}

	else if (!gstrcmp(name, T("mld"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_query_interval",
		     sVal) == 1) {
			range_val = atoi(sVal);
		}
	}

	ifx_httpdWrite(wp, T("%d"), range_val);
}

void ifx_get_igmp_advanced_query_response_interval(int32 eid, httpd_t wp,
						   int32 argc, char8 ** argv)
{
	int32 isEnabled = 0;
	char8 sVal[MAX_DATA_LEN];
	char_t *name = NULL;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return;
	}

	if (!gstrcmp(name, T("igmp"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_MULTICAST,
		     "mcast_igmp_query_resp_interval_status", sVal) == 1) {
			isEnabled = atoi(sVal);
		}
	}

	else if (!gstrcmp(name, T("mld"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_MULTICAST,
		     "mcast_mld_query_resp_interval_status", sVal) == 1) {
			isEnabled = atoi(sVal);
		}
	}
	if (isEnabled)
		ifx_httpdWrite(wp, T("checked"));
	else
		ifx_httpdWrite(wp, T(""));
}

void ifx_get_igmp_advanced_query_response_interval_range(int32 eid, httpd_t wp,
							 int32 argc,
							 char8 ** argv)
{
	int32 range_val = 10;
	char8 sVal[MAX_DATA_LEN];
	char_t *name = NULL;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return;
	}

	if (!gstrcmp(name, T("igmp"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_MULTICAST,
		     "mcast_igmp_query_resp_interval", sVal) == 1) {
			range_val = atoi(sVal);
		}
	}

	else if (!gstrcmp(name, T("mld"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_MULTICAST,
		     "mcast_mld_query_resp_interval", sVal) == 1) {
			range_val = atoi(sVal);
		}
	}

	ifx_httpdWrite(wp, T("%d"), range_val);
}

void ifx_get_igmp_advanced_last_member_query_interval(int32 eid, httpd_t wp,
						      int32 argc, char8 ** argv)
{
	int32 isEnabled = 0;
	char8 sVal[MAX_DATA_LEN];
	char_t *name = NULL;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return;
	}

	if (!gstrcmp(name, T("igmp"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_MULTICAST,
		     "mcast_igmp_last_mem_query_interval_status", sVal) == 1) {
			isEnabled = atoi(sVal);
		}
	}

	else if (!gstrcmp(name, T("mld"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_MULTICAST,
		     "mcast_mld_last_mem_query_interval_status", sVal) == 1) {
			isEnabled = atoi(sVal);
		}
	}

	if (isEnabled)
		ifx_httpdWrite(wp, T("checked"));
	else
		ifx_httpdWrite(wp, T(""));
}

void ifx_get_igmp_advanced_last_member_query_interval_range(int32 eid,
							    httpd_t wp,
							    int32 argc,
							    char8 ** argv)
{
	int32 range_val = 1;
	char8 sVal[MAX_DATA_LEN];
	char_t *name = NULL;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return;
	}

	if (!gstrcmp(name, T("igmp"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_MULTICAST,
		     "mcast_igmp_last_mem_query_interval", sVal) == 1) {
			range_val = atoi(sVal);
		}
	}

	else if (!gstrcmp(name, T("mld"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_MULTICAST,
		     "mcast_mld_last_mem_query_interval", sVal) == 1) {
			range_val = atoi(sVal);
		}
	}

	ifx_httpdWrite(wp, T("%d"), range_val);
}

void ifx_get_igmp_advanced_last_member_query_count(int32 eid, httpd_t wp,
						   int32 argc, char8 ** argv)
{
	int32 isEnabled = 0;
	char8 sVal[MAX_DATA_LEN];
	char_t *name = NULL;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return;
	}

	if (!gstrcmp(name, T("igmp"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_MULTICAST,
		     "mcast_igmp_last_mem_query_count_status", sVal) == 1) {
			isEnabled = atoi(sVal);
		}
	}

	else if (!gstrcmp(name, T("mld"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_MULTICAST,
		     "mcast_mld_last_mem_query_count_status", sVal) == 1) {
			isEnabled = atoi(sVal);
		}
	}

	if (isEnabled)
		ifx_httpdWrite(wp, T("checked"));
	else
		ifx_httpdWrite(wp, T(""));
}

void ifx_get_igmp_advanced_last_member_query_count_range(int32 eid, httpd_t wp,
							 int32 argc,
							 char8 ** argv)
{
	int32 range_val = 2;
	char8 sVal[MAX_DATA_LEN];
	char_t *name = NULL;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return;
	}

	if (!gstrcmp(name, T("igmp"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_MULTICAST,
		     "mcast_igmp_last_mem_query_count", sVal) == 1) {
			range_val = atoi(sVal);
		}
	}

	else if (!gstrcmp(name, T("mld"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_MULTICAST,
		     "mcast_mld_last_mem_query_count", sVal) == 1) {
			range_val = atoi(sVal);
		}
	}

	ifx_httpdWrite(wp, T("%d"), range_val);
}

void ifx_populate_static_entry_parameters(int32 eid, httpd_t wp, int32 argc,
					  char8 ** argv)
{
	char8 sVal[MAX_DATA_LEN];

	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_MULTICAST, "mcast_grp_entries", sVal) == 1) {
		ifx_httpdWrite(wp, T("%s"), sVal);
	} else {
		ifx_httpdWrite(wp, T(""));
	}

}

//+++++++++++++++++++++++++++++ IGMP ADVANCED SETTINGS ++++++++++++++++++++++++++++++++++++++++//
