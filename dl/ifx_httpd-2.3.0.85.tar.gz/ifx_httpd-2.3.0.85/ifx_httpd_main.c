/* ============================================================================
 * Copyright (C) 2004-2005 -Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 *============================================================================
 *
 * This document contains proprietary information belonging to Infineon 
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 * 
 * ============================================================================
 */

/* ===========================================================================
 *
 * File Name:   ifx_httpd_main.c
 * Author :     Neeraj Gupta, Nirav Salot
 * Date: 		October, 2004
 *
 * ===========================================================================
 *
 * Project: Amazon
 *
 * ===========================================================================
 * Contents: This is the main for IFX web infrastructure allowing dynamic
 * "C - binding". 
 *  
 * ===========================================================================
 * References: 
 *
 */

/* ===========================================================================
 * Revision History:
 *
 * $Log$
 * ===========================================================================
 */
//000013:fchang 2005/6/2 Modified by Jelly to fix the compilier issue on amazon16_4_adsl
// 509151:jelly:2005/09/15 porting Voip 2.1

#include <dlfcn.h>
#include <ifx_emf.h>
#include "ifx_httpd_method.h"
#include "ifx_httpd.h"
#include <ifx_exportFunc.h>
#include "ifx_amazon_cgi.h"
#include "ifx_lock.h"
#include "ifx_cgi_common.h"

#ifdef CONFIG_FEATURE_IFX_VOIP	//000013:fchang
//#include "ifx_common_defs.h"
#include "ifx_ipc.h"		// 509151:jelly
#endif				//000013:fchang

#define WEBS_MAX_PASS			32	/* Size of password */

#define IFX_BYPASS_URL	"login.asp login_redirect.asp final.css images/Button.png goform/ifx_set_login flash/f1.swf loginerr.htm"

#if 0
int (*ifx_sendHeaders) (int responseNum, char *redirectURL);
int (*ifx_read) (int fd, void *buf, int len);
int (*ifx_write) (int fd, const void *buf, int len);
void (*ifx_getHeaderData) (const char *, char **);
#else
IFX_SENDHEADERS ifx_sendHeaders;
IFX_READ ifx_read;
IFX_WRITE ifx_write;
IFX_GETHEADERDATA ifx_getHeaderData;
#endif

void *dlHandle;
struct connection_profil_list *connlist = NULL;
int nIdleTime = 0;
extern char *status_str;

#ifndef IFX_WEB
#define IFX_WEB  1
#endif				// IFX_WEB

#include "ifx_lock.h"
#include "ifx_common.h"

#ifndef TRY_LOCK_SUPPORT
#define TRY_LOCK_SUPPORT
#endif				// TRY_LOCK_SUPPORT
#define LOCK_FILE_NAME "/flash/lock.txt"

#ifdef CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE
extern int get_remote_hwaddr(IN char_t *ipaddr, OUT char_t *hwaddr);
#endif /* CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE */
//VIVEK start
FILE *fpFirmwareUpgrade;
//VIVEK end
//805151:<IFTW-leon> start
struct auto_pvc auto_pvc_db[] =
    { {1, -1, -1, 0}, {1, -1, -1, 0}, {1, -1, -1, 0}, {1, -1, -1, 0}, {1, -1,
								       -1, 0},
    {1, -1, -1, 0},
{1, -1, -1, 0}, {1, -1, -1, 0}, {1, -1, -1, 0}, {1, -1, -1, 0}, {1, -1, -1, 0},
    {1, -1, -1, 0},
{1, -1, -1, 0}, {1, -1, -1, 0}, {1, -1, -1, 0}, {1, -1, -1, 0},
};

//805151:<IFTW-leon> end
int ifx_main()
{
	char_t sValue[WEBS_MAX_PASS];
	int ret = IFX_SUCCESS;
	int i = 0, vpi_previous = 0, vci_previous = 0;	//805151:<IFTW-leon> 
	char sItem[15];
	char8 *delim = "/\n";
	char8 *vpi_channel = NULL, *vci_channel = NULL;
	char8 *vpi_channel_previous = NULL, *vci_channel_previous = NULL;	//805151:<IFTW-leon> start  

	if (!dlHandle) {
		fprintf(stderr, "%s\n", dlerror());
		fprintf(stderr, "\n ifx_main Error : dlopen fails.\n");
		return -1;
	}
#ifdef TRY_LOCK_SUPPORT
	IFX_INIT_LOCK(LOCK_FILE_NAME, ret);
	if (ret != IFX_SUCCESS) {
		fprintf(stderr, "\n Lock Initialization failed !!!\n");
	}
#endif				// TRY_LOCK_SUPPORT
//805151:<IFTW-leon> start
	memset(sValue, 0x00, WEBS_MAX_PASS);
	if (ifx_GetCfgData
	    (FILE_RC_CONF, "auto_pvc_db_previous", "autovcc_previous",
	     sValue) == 1) {
		vpi_channel_previous = strtok(sValue, delim);
		vci_channel_previous = strtok(NULL, delim);
		if (vci_channel_previous)
			vci_previous = gatoi(vci_channel_previous);
		if (vpi_channel_previous)
			vpi_previous = gatoi(vpi_channel_previous);

	}
//805151:<IFTW-leon> end
	memset(sValue, 0x00, WEBS_MAX_PASS);
//805071:<IFTW-leon> start
	for (i = 0; i < 16; ++i) {
		sprintf(sItem, "autovcc_%d", i);
		if (ifx_GetCfgData(FILE_RC_CONF, "auto_pvc_db", sItem, sValue)
		    == 1) {
			vpi_channel = strtok(sValue, delim);
			vci_channel = strtok(NULL, delim);
			if (vci_channel)
				auto_pvc_db[i].vci = gatoi(vci_channel);
			if (vpi_channel)
				auto_pvc_db[i].vpi = gatoi(vpi_channel);
			//805151:<IFTW-leon> start

			if (vpi_previous != -1) {
				if ((vpi_previous == auto_pvc_db[i].vpi)
				    && (vci_previous == auto_pvc_db[i].vci))
					auto_pvc_db[i].previous = 1;
			}
			if (auto_pvc_db[i].vpi == -1)
				auto_pvc_db[i].empty = 1;
			else
				auto_pvc_db[i].empty = 0;

		}
	}
	memset(sValue, 0x00, WEBS_MAX_PASS);

	//805151:<IFTW-leon> end
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_SYSTEM_PASSWORD, T("Password"), sValue) == 0) {
		//trace(8, "Cannot found password in rc.cof");
		memset(sValue, 0x00, WEBS_MAX_PASS);
	}
	ifx_httpdSetPassword(sValue);
#if 0
/* NOt required - as it is handled from VOIP httpd */
#ifdef CONFIG_FEATURE_IFX_VOIP
	/* Init CM-WEB arch */
	IFX_CM_MgtInit(IFX_IPC_APP_ID_WEB);	// 509151:jelly
#endif
#endif
	return 0;
}

int ifx_RegisterFunc(struct ifx_exportFuncList *pifx_exportedFunc)
{
	ifx_debug_printf("###Inside ifx_RegisterFunc.\n");
	ifx_sendHeaders = pifx_exportedFunc->ifx_sendHeaders;
	ifx_read = pifx_exportedFunc->ifx_read;
	ifx_write = pifx_exportedFunc->ifx_write;
	ifx_getHeaderData = pifx_exportedFunc->ifx_getHeaderData;
	dlHandle = pifx_exportedFunc->dlHandle;
	return ifx_main();
}

/****************************************************************************
 *
 > $Function: decodeString()
 *
 * $Description: Given a URL encoded string, convert it to plain ascii.
 *   Since decoding always makes strings smaller, the decode is done in-place.
 *   Thus, callers should strdup() the argument if they do not want the
 *   argument modified.  The return is the original pointer, allowing this
 *   function to be easily used as arguments to other functions.
 *
 * $Parameters:
 *      (char *) string . . . The first string to decode.
 *      (int)    flag   . . . 1 if require decode '+' as ' ' for CGI
 *
 * $Return: (char *)  . . . . A pointer to the decoded string (same as input).
 *
 * $Errors: None
 *
 ****************************************************************************/
static char *decodeString(char *orig, int flag_plus_to_space)
{
	/* note that decoded string is always shorter than original */
	char *string = orig;
	char *ptr = string;

	while (*ptr) {
		if (*ptr == '+' && flag_plus_to_space) {
			*string++ = ' ';
			ptr++;
		} else if (*ptr != '%')
			*string++ = *ptr++;
		else {
			unsigned int value;
			sscanf(ptr + 1, "%2X", &value);
			*string++ = value;
			ptr += 3;
		}
	}
	*string = '\0';
	return orig;
}

// Get string between two pointers
int ifx_get_string(char *start_ptr, char *end_ptr, char *ifx_command_buff)
{
	if ((start_ptr == NULL) || (end_ptr == NULL)
	    || (ifx_command_buff == NULL))
		return -1;
	memmove(ifx_command_buff, start_ptr,
		(char *)end_ptr - (char *)start_ptr);

	ifx_command_buff[end_ptr - start_ptr] = '\0';
	return strlen(ifx_command_buff);
}

// Check if arg is string and if successfull Get string between ""
int ifx_update_argument(char *arg)
{
	char *result = NULL;
	int ret = 0;
	ret = strtol(arg, &result, 10);
	if ((result != NULL) && (ret == 0)) {
		ifx_debug_printf("\n Argument is string \n");
		if (ifx_get_string
		    (((char *)strchr(arg, '"') + 1), strrchr(arg, '"'),
		     arg) < 0) {
			return -1;
		}
	}

	return 0;
}

// Get Function anme and update argument List
char *ifx_get_function(char *string, char **arg_list, int *no_of_arg)
{
	char *ifx_function_name = NULL;
	char *temp, *arg;

	ifx_function_name = (char *)calloc(IFX_FUN_NAME_LENGTH, sizeof(char));
	if (ifx_function_name == NULL)
		return NULL;
	*no_of_arg = 0;

	temp = strchr(string, '(');
	strncpy(ifx_function_name, string, (char *)temp - (char *)string);

	arg = temp + 1;

	while ((temp) && ((temp = strchr(temp, ',')) != NULL)) {
		arg_list[*no_of_arg] = (char *)calloc(IFX_ARG_LEN, 1);
		if (arg_list[*no_of_arg] == NULL) {
			IFX_MEM_FREE(ifx_function_name)
			    return NULL;
		}
		strncpy(arg_list[*no_of_arg], arg, (char *)temp - (char *)arg);
		arg_list[*no_of_arg][(char *)temp - (char *)arg] = '\0';
		if (ifx_update_argument(arg_list[*no_of_arg]) < 0) {
			*no_of_arg = *no_of_arg + 1;
			IFX_MEM_FREE(ifx_function_name)
			    return NULL;
		}
		*no_of_arg = *no_of_arg + 1;
		if (*no_of_arg == IFX_MAX_NO_ARG) {
			break;
		}
		temp = temp + 1;
		arg = temp;
	}

	if ((temp = strchr(string, ')')) != NULL) {
		// In case of now argument don't put space (fn())
		if ((arg == temp) && (*no_of_arg == 0)) {
			ifx_debug_printf("\n No argument Case .... \n");
			return ifx_function_name;
		}

		arg_list[*no_of_arg] = (char *)calloc(IFX_ARG_LEN, 1);
		if (arg_list[*no_of_arg] == NULL) {
			IFX_MEM_FREE(ifx_function_name)
			    return NULL;
		}
		strncpy(arg_list[*no_of_arg], arg, (char *)temp - (char *)arg);
		arg_list[*no_of_arg][(char *)temp - (char *)arg] = '\0';
		if (ifx_update_argument(arg_list[*no_of_arg]) < 0) {
			*no_of_arg = *no_of_arg + 1;
			IFX_MEM_FREE(ifx_function_name)
			    return NULL;
		}
		*no_of_arg = *no_of_arg + 1;

	} else {
		IFX_MEM_FREE(ifx_function_name)
		    return NULL;
	}

	return ifx_function_name;
}

char *myPriorityStrStr(char *str)
{
	char *strTokBeg = NULL;
#if 0
	char *strCommBeg = NULL;
	char *strCommEnd = NULL;

	strCommBeg =
	    strstr(str, IFX_COMMENT_BEG) ? strstr(str,
						  IFX_COMMENT_BEG) : (str +
								      strlen
								      (str));
	strCommEnd =
	    strstr(str, IFX_COMMENT_END) ? strstr(str,
						  IFX_COMMENT_END) : (str +
								      strlen
								      (str));
	strTokBeg =
	    strstr(str, IFX_TOKEN_BEG) ? strstr(str,
						IFX_TOKEN_BEG) : (str +
								  strlen(str));

	if ((strCommBeg == strCommEnd) && (strCommEnd == strTokBeg))
		return NULL;
	if ((strCommBeg < strCommEnd) && (strCommBeg < strTokBeg))
		return strCommBeg;
	if (strCommEnd < strTokBeg)
		return strCommEnd;
	return strTokBeg;
#else
	strTokBeg =
	    strstr(str, IFX_TOKEN_BEG) ? strstr(str,
						IFX_TOKEN_BEG) : (str +
								  strlen(str));
	return strTokBeg;
#endif
}

int ifx_sendDHTMLFile(char *buff, const char *host, int count, int writeFd,
		      int *pbNewFile)
{
	char *rcv_buff;
	char *start_ptr = NULL, *end_ptr = NULL, *write_ptr = NULL;
	char ifx_command_buff[IFX_COMMAND_LENGTH];
	struct ifx_wp ifx_wp_data;
	void *ifx_function_ptr = NULL;
	char *ifx_function_name = NULL;
	char **arg_list;
	int no_of_arg = 0;
	int i;
	char *error;
	int writtenCount = 0;
	char *tempPtr = NULL;

	ifx_debug_printf("\nIn ifx_sendDHTMLFile() ... !\n");
	if (*pbNewFile) {
		pbNewFile = 0;
	}

	rcv_buff = buff;
	rcv_buff[count] = '\0';	/* Null terminate buffer to allow use of standard
				   string routines. */

	// Initially write_ptr should point to satrt of buffer
	write_ptr = rcv_buff;

	while ((start_ptr = myPriorityStrStr(write_ptr)) != NULL) {
		//Comment handling 
#if 0
		if ((strncmp
		     (start_ptr, IFX_COMMENT_BEG, strlen(IFX_COMMENT_BEG)) == 0)
		    ||
		    (strncmp
		     (start_ptr, IFX_COMMENT_END,
		      strlen(IFX_COMMENT_END)) == 0)) {
			//Begining of the comment or end of the comment found.
			end_ptr = NULL;
			if (strncmp
			    (start_ptr, IFX_COMMENT_END,
			     strlen(IFX_COMMENT_END)) == 0) {
				//Previous comment is ending here.
				ifx_debug_printf
				    ("###In ifx_sendDHTMLFile : end of comment found start_ptr[%s]\n",
				     start_ptr);
				end_ptr = start_ptr;
				bNoEOC = 0;
			} else
			    if (strncmp
				(start_ptr, IFX_COMMENT_BEG,
				 strlen(IFX_COMMENT_BEG)) == 0) {
				//Begining of the comment is found.
				ifx_debug_printf
				    ("###In ifx_sendDHTMLFile : begining of comment found start_ptr[%s]\n",
				     start_ptr);
				end_ptr = strstr(start_ptr, IFX_COMMENT_END);
				ifx_debug_printf
				    ("###In ifx_sendDHTMLFile : end of comment found end_ptr[%s]\n",
				     end_ptr);
			}

			if (end_ptr) {
				//End of the comment found.
				end_ptr += strlen(IFX_COMMENT_END);
				writtenCount =
				    (*ifx_write) (writeFd, write_ptr,
						  (end_ptr - write_ptr));
				if (writtenCount != (end_ptr - write_ptr))
					return write_ptr - rcv_buff +
					    writtenCount;
				write_ptr = end_ptr;
				bNoEOC = 0;
				continue;
			} else {
				//End of the comment not found.
				bNoEOC = 1;
				break;
			}
		}
		//Begining of the IFX_TOKEN_BEG found.
		ifx_debug_printf
		    ("###In ifx_sendDHTMLFile : begining of TOKEN found with bNoEOC = %d\n",
		     bNoEOC);
		if (bNoEOC) {
			//Previous comment has not ended yet so ignore this IFX_TOKEN_BEG
			//write_ptr = start_ptr + strlen(IFX_TOKEN_BEG);
			write_ptr += strlen(IFX_TOKEN_BEG);
			continue;
		}
#endif
		//writtenCount = bb_full_write(a_c_w, write_ptr, (start_ptr - write_ptr));
		writtenCount =
		    (*ifx_write) (writeFd, write_ptr, (start_ptr - write_ptr));
		if (writtenCount != (start_ptr - write_ptr))
			return write_ptr - rcv_buff + writtenCount;

		end_ptr = NULL;
		end_ptr = strstr(start_ptr, IFX_TOKEN_END);

		if (end_ptr == NULL) {
			// Case where full string is not in same buffer
			ifx_debug_printf("\nFound %s and no %s\n",
					 IFX_TOKEN_BEG, IFX_TOKEN_END);
			return start_ptr - rcv_buff;
		}
		//Added to ignore spaces.
		start_ptr += strlen(IFX_TOKEN_BEG);
		while (isspace(*start_ptr++)) ;
		start_ptr--;

		ifx_get_string(start_ptr, end_ptr, ifx_command_buff);
		ifx_debug_printf("ifx_command is %s \n", ifx_command_buff);

		arg_list = (char **)calloc(IFX_MAX_NO_ARG, (sizeof(char **)));
		if (arg_list == NULL)
			return -1;

		ifx_function_name =
		    ifx_get_function(ifx_command_buff, arg_list, &no_of_arg);

		if (ifx_function_name != NULL) {
			ifx_debug_printf("No of arguments %d \n", no_of_arg);

			ifx_debug_printf("ifx_function_name is %s \n",
					 ifx_function_name);
			for (i = 0; i < no_of_arg; i++) {
				ifx_debug_printf("argument (%d) is (%s)\n ", i,
						 arg_list[i]);
			}

			ifx_function_ptr =
			    dlsym(dlHandle, (char *)ifx_function_name);
			if ((error = dlerror()) != NULL) {
				ifx_debug_printf("%s\n", error);
				ifx_debug_printf("Error : dlsym fails for [%s]\n", ifx_function_name);
				//return start_ptr - rcv_buff;
			} else {
				//memset(ifx_wp_data.ifx_buff,0x00,IFX_DATA_BUFF);
				//ifx_wp_data.ifx_return_value = 10;
				strcpy(ifx_wp_data.host, host);
				ifx_wp_data.ifxReadFd = 0;
				ifx_wp_data.ifxWriteFd = writeFd;
				(*ifx_getHeaderData) ("Remote IP", &tempPtr);
				if (tempPtr != NULL)
					strncpy(ifx_wp_data.ipaddr, tempPtr,
						sizeof(ifx_wp_data.ipaddr)-1);
				ifx_wp_data.bSendHeader = 0;

				ifx_debug_printf
				    ("\n Try to call function ....\n");
				if (ifx_function_ptr) {
					(*
					 (int (*)
					  (int, struct ifx_wp *, int,
					   char **))ifx_function_ptr) (0,
								       &ifx_wp_data,
								       no_of_arg,
								       arg_list);
				}
				//ifx_debug_printf("\n Ret_buff is %s and retVal is %d\n",ifx_wp_data.ifx_buff,ifx_wp_data.ifx_return_value);
				//bb_full_write(a_c_w, ifx_wp_data.ifx_buff, strlen(ifx_wp_data.ifx_buff));
			}
		}

		if (no_of_arg > 0) {
			ifx_debug_printf
			    ("\n Tryin to free arg_list member Inside while loop \n");
			for (i = 0; i < no_of_arg; i++) {
				IFX_FREE(arg_list[i]);
			}
			no_of_arg = 0;
		}

		IFX_FREE(arg_list);
		IFX_FREE(ifx_function_name);

		// shift buff to end of IFX_TOKEN_END
		write_ptr = end_ptr + strlen(IFX_TOKEN_END);

	}			// End of while Loop

	//bb_full_write(a_c_w, write_ptr, strlen(write_ptr));
	(*ifx_write) (writeFd, write_ptr, strlen(write_ptr));
	return count;

}				// end of function ifx_decode_string

void ifx_freeArgList(struct ifx_wp *pifx_wp)
{
	struct ifx_arg_list *pCurArg, *pNextArg;
	int i;

	pCurArg = pifx_wp->ifx_ptr_arg_list;
	while (pCurArg) {
		pNextArg = pCurArg->next;
		IFX_FREE(pCurArg->pifx_param_name);
		if (pCurArg->numMultiBufs) {
			for (i = 0; i < pCurArg->numMultiBufs; i++) {
				IFX_FREE(pCurArg->ifx_param_value.
					 pArrMultiBuf[i].buf);
			}
			IFX_FREE(pCurArg->ifx_param_value.pArrMultiBuf);
		} else {
			IFX_FREE(pCurArg->ifx_param_value.buf);
		}
		IFX_FREE(pCurArg);
		pCurArg = pNextArg;
	}
	IFX_FREE(pifx_wp->pBoundary);
}

struct ifx_arg_list *ifx_MakeArgNode(void)
{
	struct ifx_arg_list *pCurArg;
	(pCurArg) = (struct ifx_arg_list *)malloc(sizeof(struct ifx_arg_list));
	if (pCurArg == NULL)
		return NULL;
	(pCurArg)->pifx_param_name = NULL;
	(pCurArg)->ifx_param_value.buf = NULL;
	(pCurArg)->numMultiBufs = 0;
	(pCurArg)->next = NULL;
	(pCurArg)->totBufLen = 0;
	return pCurArg;
}

int ifx_parsePostArgBuf(char *inBuf, struct ifx_wp *ifx_data_ptr, int count,
			int *parg_incomplete)
{
	char *nextTok = NULL;
	char *strArgs = NULL;
	char *pCurParaValLoc = NULL;
	struct ifx_arg_list *pCurArg = NULL;
	struct ifx_arg_list *pPreArg = NULL;

	if (count <= 0)
		return 0;
	ifx_debug_printf("\n ORG_BUFF is %s \n", inBuf);

	//Reach till the end of the current argument list
	if (ifx_data_ptr->ifx_ptr_arg_list) {
		pPreArg = ifx_data_ptr->ifx_ptr_arg_list;
		while (pPreArg->next)
			pPreArg = pPreArg->next;
	}

	strArgs = inBuf;
	do {
		int paramLen = 0;
		nextTok = strchr(strArgs, '&');
		if (*parg_incomplete > 0) {
			if (*parg_incomplete == 1) {
				//The previous argument name is spanning accross the packets.
				pCurParaValLoc = strchr(strArgs, '=');
				if (pPreArg->pifx_param_name)
					paramLen =
					    strlen(pPreArg->pifx_param_name) +
					    pCurParaValLoc - strArgs + 1;
				else
					paramLen = pCurParaValLoc - strArgs + 1;
				pPreArg->pifx_param_name =
				    (char *)realloc(pPreArg->pifx_param_name,
						    paramLen);
				/* \todo fix here potential overwriting, because of uninitialized memory */
				if (pPreArg->pifx_param_name) {
					strncat(pPreArg->pifx_param_name,
						strArgs,
						pCurParaValLoc - strArgs);
				}
				pPreArg->pifx_param_name[paramLen - 1] = 0x00;
				strArgs = pCurParaValLoc + 1;
				ifx_debug_printf
				    ("###In ifx_parsePostArgBuf : pifx_param_name [%s]\n",
				     pPreArg->pifx_param_name);

			}

			if (nextTok == NULL) {
				//The previous argument is the last argument of all and now we have the last part of the uncompleted argument value
				if (strArgs)
					paramLen =
					    (pPreArg->ifx_param_value.
					     buf ? strlen(pPreArg->
							  ifx_param_value.
							  buf) : 0) +
					    strlen(strArgs) + 1;
				else
					paramLen =
					    (pPreArg->ifx_param_value.
					     buf ? strlen(pPreArg->
							  ifx_param_value.
							  buf) : 0) + 1;
			} else {
				//The previous argument completes here and there are more to follow.
				paramLen =
				    (pPreArg->ifx_param_value.
				     buf ? strlen(pPreArg->ifx_param_value.
						  buf) : 0) + nextTok -
				    strArgs + 1;
			}

			if (pPreArg->ifx_param_value.buf) {
				//If buffer is already allocated for the current argument value then reallocate it.
				pPreArg->ifx_param_value.buf =
				    (char *)realloc(pPreArg->ifx_param_value.
						    buf, paramLen);
			} else {
				//If the buffer is not allocated yet then allocate it.
				pPreArg->ifx_param_value.buf =
				    (char *)calloc(paramLen, sizeof(char));
			}

/*
			if ((strArgs) && (pPreArg->ifx_param_value.buf))
				strncat(pPreArg->ifx_param_value.buf, strArgs,
					paramLen - 1);
			pPreArg->totBufLen = paramLen - 1;
			pPreArg->ifx_param_value.buf[paramLen - 1] = 0x00;
*/
			if ((strArgs) && (pPreArg->ifx_param_value.buf)) {
				if (strlen(pPreArg->ifx_param_value.buf) > paramLen) {
					printf("Overwriting limits of pPreArg->ifx_param_value.buf!!\n");
					printf("strArgs: %s\n", strArgs);
					printf("strlen(strArgs): %d, pPreArg->totBufLen: %d, ifx_param_value.buf: %s, strlen(ifx_param_value.buf): %d\n",
						strlen(strArgs), pPreArg->totBufLen, pPreArg->ifx_param_value.buf, strlen(pPreArg->ifx_param_value.buf));
					return 0;
				}
				strncat(pPreArg->ifx_param_value.buf, strArgs, paramLen - strlen(pPreArg->ifx_param_value.buf) - 1);
				pPreArg->totBufLen = paramLen - 1;
				pPreArg->ifx_param_value.buf[paramLen - 1] = 0x00;
			}

			*parg_incomplete = 0;
		} else {
			//We have found new argument (name,value) pair.
			pCurArg = ifx_MakeArgNode();
			ifx_data_ptr->ifx_no_argument++;

			pCurParaValLoc = strchr(strArgs, '=');
			if (pCurParaValLoc == NULL) {
				//The current argument name is incomplete.
				paramLen = strlen(strArgs) + 1;
				*parg_incomplete = 1;
			} else {
				paramLen = pCurParaValLoc - strArgs + 1;
			}
			if (pCurArg == NULL) {
				break;
			}
			pCurArg->pifx_param_name =
			    (char *)calloc(paramLen, sizeof(char));
			memcpy(pCurArg->pifx_param_name, strArgs, paramLen - 1);
			strArgs = pCurParaValLoc + 1;
			if (*parg_incomplete == 0) {
				if (nextTok == NULL) {
					//The current argument value is incomplete.
					paramLen = strlen(strArgs) + 1;
					*parg_incomplete = 2;
				} else if (pCurParaValLoc) {
					//The current argument value is complete.
					paramLen = nextTok - strArgs + 1;
				}
				pCurArg->ifx_param_value.buf =
				    (char *)calloc(paramLen, sizeof(char));
				memcpy(pCurArg->ifx_param_value.buf, strArgs,
				       paramLen - 1);
				pCurArg->totBufLen = paramLen - 1;
			}

			ifx_debug_printf
			    ("###In ifx_parsePostArgBuf : *parg_incomplete = %d\n",
			     *parg_incomplete);
			if (ifx_data_ptr->ifx_ptr_arg_list == NULL)
				ifx_data_ptr->ifx_ptr_arg_list = pCurArg;

			if (pPreArg != NULL)
				pPreArg->next = pCurArg;
			pPreArg = pCurArg;

		}
		strArgs = nextTok + 1;
		if (*parg_incomplete != 1) {
			//Decode the argument name and value.
			decodeString(pPreArg->ifx_param_value.buf, 1);
			decodeString(pPreArg->pifx_param_name, 1);
			ifx_debug_printf
			    ("###In ifx_parsePostArgBuf : pifx_param_name [%s] and ifx_param_value.buf [%s]\n",
			     pPreArg->pifx_param_name,
			     pPreArg->ifx_param_value.buf);
		}
	} while (nextTok != NULL);

	return 0;
}

/*Remove any extra unwanted characters at the begining or end of the string as per the direction. */
char *ifx_RmExtraChar(char *str, int dir)
{
	if (str) {
		while (*str == '\r' || *str == '\n' || *str == '-') {
			if (dir == FORWARD)
				str++;
			else if (dir == BACKWARD)
				str--;
		}
	}
	return str;
}

/*Special strstr, which searches for Needle in the Heap till len, irrespective of null termination in Heap*/
char *xstrstr(char *strHeap, char *strNeedle, int len)
{
	int iLoc = 0;
	while (iLoc < len) {
		if (strncmp(strHeap, strNeedle, strlen(strNeedle)) == 0)
			return strHeap;
		strHeap++;
		iLoc++;
	}
	return NULL;
}

int ifx_parseMPartArgBuf(char *inBuf, struct ifx_wp *ifx_data_ptr, int count,
			 int *parg_incomplete, int *pbFirstTime)
{
	char *nextTok = NULL;
	char *strArgs = NULL;
	char *pCurParaValLoc = NULL;
	struct ifx_arg_list *pCurArg = NULL;
	struct ifx_arg_list *pPreArg = NULL;

	//ifx_debug_printf("\n ORG_BUFF is %s \n",inBuf);

	if (count <= 0)
		return 0;

	//Reach till the end of the current argument list
	if (ifx_data_ptr->ifx_ptr_arg_list) {
		pPreArg = ifx_data_ptr->ifx_ptr_arg_list;
		while (pPreArg->next)
			pPreArg = pPreArg->next;
	}

	strArgs = inBuf;
	//If this is called for the first time then forward the pointer to 
	//escape the boundary in the begining of the buffer.
	if (*pbFirstTime == 1) {
		nextTok = xstrstr(strArgs, ifx_data_ptr->pBoundary, count);
		strArgs = nextTok + strlen(ifx_data_ptr->pBoundary);
		*pbFirstTime = 0;
	}

	do {
		int paramLen = 0;
		char *ptemp = NULL;

		nextTok =
		    xstrstr(strArgs, ifx_data_ptr->pBoundary,
			    count - (strArgs - inBuf));

		if (*parg_incomplete == 2) {
			//The previous argument value is spanning accross the packets.
			//We are not taking care of the case where the boundary or argument name spans accross the packets.
			if (nextTok) {
				//The end of uncomplete argument value is reached.
				ptemp = ifx_RmExtraChar(nextTok, BACKWARD);
				ptemp += 1;
				paramLen = ptemp - strArgs + 1;
				*parg_incomplete = 0;
			} else {
				//Even this packet contains the argument value in partial form.
				paramLen = count + 1;
				*parg_incomplete = 2;
			}
			if (pPreArg) {
				if (paramLen <= (MALLOC_BUF_SIZE / 2)
				    && pPreArg->numMultiBufs == 0) {
					//The paramLen is small enough to store the argument value in a single buffer.
					if (pPreArg->ifx_param_value.buf)
						pPreArg->ifx_param_value.buf =
						    (char *)realloc(pPreArg->
								    ifx_param_value.
								    buf,
								    paramLen +
								    strlen
								    (pPreArg->
								     ifx_param_value.
								     buf));
					else
						pPreArg->ifx_param_value.buf =
						    (char *)calloc(paramLen,
								   sizeof
								   (char));
					if ((pPreArg->ifx_param_value.buf)
					    && (strArgs))
						strncat(pPreArg->
							ifx_param_value.buf,
							strArgs,
							nextTok - strArgs);
					pPreArg->totBufLen = paramLen - 1;
					ifx_debug_printf
					    ("###In ifx_parseMPartArgBuf : pifx_param_name [%s] and ifx_param_value.buf [%s]\n",
					     pPreArg->pifx_param_name,
					     pPreArg->ifx_param_value.buf);
				} else {
					//The paramLen large and hence the argument value should be stored in multiple buffers.
					if (pPreArg->numMultiBufs == 0
					    && pPreArg->ifx_param_value.buf) {
						//The part of the current argument value came in the last packet.
						//So, attach the previously allocated single buffer as the first buffer of the multiple buffer
						ptemp =
						    pPreArg->ifx_param_value.
						    buf;
						pPreArg->ifx_param_value.buf =
						    NULL;
						pPreArg->numMultiBufs += 1;
#if 0
						pPreArg->ifx_param_value.
						    pArrMultiBuf =
						    (T_MULTI_BUF *)
						    realloc(pPreArg->
							    ifx_param_value.
							    pArrMultiBuf,
							    pPreArg->
							    numMultiBufs *
							    sizeof
							    (T_MULTI_BUF));
						pPreArg->ifx_param_value.
						    pArrMultiBuf[pPreArg->
								 numMultiBufs -
								 1].buf = ptemp;
						pPreArg->ifx_param_value.
						    pArrMultiBuf[pPreArg->
								 numMultiBufs -
								 1].len =
						    pPreArg->totBufLen;
#endif
//VIVEK start
						fwrite(ptemp, pPreArg->totBufLen, 1, fpFirmwareUpgrade);	//VIVEK
//VIVEK end

						ifx_debug_printf
						    ("###In ifx_parseMPartArgBuf : pifx_param_name [%s] and ifx_param_value.pArrMultiBuf[%d].len [%d]\n",
						     pPreArg->pifx_param_name,
						     pPreArg->numMultiBufs - 1,
						     pPreArg->ifx_param_value.
						     pArrMultiBuf[pPreArg->
								  numMultiBufs -
								  1].len);
					}
					if (strArgs)
						fwrite(strArgs, paramLen - 1, 1, fpFirmwareUpgrade);	//VIVEK

#if 0				//VIVEK
					//Allocate new mulitiple buffer structure and copy the argument value.
					pPreArg->numMultiBufs += 1;
					pPreArg->ifx_param_value.pArrMultiBuf =
					    (T_MULTI_BUF *) realloc(pPreArg->
								    ifx_param_value.
								    pArrMultiBuf,
								    pPreArg->
								    numMultiBufs
								    *
								    sizeof
								    (T_MULTI_BUF));

					pPreArg->ifx_param_value.
					    pArrMultiBuf[pPreArg->numMultiBufs -
							 1].buf =
					    (char *)calloc(paramLen,
							   sizeof(char));
					memcpy(pPreArg->ifx_param_value.
					       pArrMultiBuf[pPreArg->
							    numMultiBufs -
							    1].buf, strArgs,
					       paramLen - 1);
					pPreArg->ifx_param_value.
					    pArrMultiBuf[pPreArg->numMultiBufs -
							 1].len = paramLen - 1;
					//Adjust the totBufLen to reflect the summation of the length of all the buffer of this multiple buffer.
					pPreArg->totBufLen += paramLen - 1;
					ifx_debug_printf
					    ("###In ifx_parseMPartArgBuf : pifx_param_name [%s] and ifx_param_value.pArrMultiBuf[%d].len [%d]\n",
					     pPreArg->pifx_param_name,
					     pPreArg->numMultiBufs - 1,
					     pPreArg->ifx_param_value.
					     pArrMultiBuf[pPreArg->
							  numMultiBufs -
							  1].len);
#endif				//VIVEK

					pPreArg->totBufLen += paramLen - 1;	// delete this
				}
			}
		} else {
			//We have found new argument (name,value) pair.
			if (strArgs)
				pCurParaValLoc =
				    strstr(strArgs, "Content-Disposition");
			if (pCurParaValLoc == NULL)
				break;

			pCurArg = ifx_MakeArgNode();
			ifx_data_ptr->ifx_no_argument++;

			strArgs =
			    pCurParaValLoc + strlen("Content-Disposition");
			pCurParaValLoc = strstr(strArgs, "name=\"");
			strArgs = pCurParaValLoc + strlen("name=\"");
			if (strArgs)
				ptemp = strchr(strArgs, '"');
			paramLen = ptemp - strArgs + 1;
			if (pCurArg)
				pCurArg->pifx_param_name =
				    (char *)calloc(paramLen, sizeof(char));
			if (pCurArg->pifx_param_name)
				strncpy(pCurArg->pifx_param_name, strArgs,
					paramLen - 1);

			strArgs = ptemp + 1;
			strArgs = strchr(strArgs, '\n');
			strArgs = ifx_RmExtraChar(strArgs, FORWARD);
			//Ignore and forward the buffer if the strArg contains Content-Type
			if (strncmp
			    (strArgs, "Content-Type",
			     strlen("Content-Type")) == 0) {
				strArgs = strstr(strArgs, "\n");
				strArgs = ifx_RmExtraChar(strArgs, FORWARD);
			}
			if (nextTok) {
				//The current argument value is complete with in the read packet.
				ptemp = ifx_RmExtraChar(nextTok, BACKWARD);
				ptemp += 1;
				paramLen = ptemp - strArgs + 1;
			} else {
				//The current argument value spans accross the packets.
				paramLen = count - (strArgs - inBuf) + 1;
				*parg_incomplete = 2;
			}
			pCurArg->ifx_param_value.buf =
			    (char *)calloc(paramLen, sizeof(char));
			if (pCurArg->ifx_param_value.buf)
				//fwrite(strArgs, paramLen - 1, 1, fpFirmwareUpgrade ); //VIVEK
				memcpy(pCurArg->ifx_param_value.buf, strArgs,
				       paramLen - 1);
			pCurArg->totBufLen = paramLen - 1;

			ifx_debug_printf
			    ("###In ifx_parseMPartArgBuf : *parg_incomplete = %d\n",
			     *parg_incomplete);
			//Attach the current argument node in the argument list of the ifx_data_ptr.
			if (ifx_data_ptr->ifx_ptr_arg_list == NULL)
				ifx_data_ptr->ifx_ptr_arg_list = pCurArg;

			if (pPreArg != NULL)
				pPreArg->next = pCurArg;
			pPreArg = pCurArg;

			ifx_debug_printf
			    ("###In ifx_parseMPartArgBuf : pifx_param_name [%s] and ifx_param_value.buf [%s] with len [%d]\n",
			     pPreArg->pifx_param_name,
			     pPreArg->ifx_param_value.buf, pCurArg->totBufLen);
		}
		//Forward the strArgs to point to the begining of the next argument.
		strArgs = nextTok + strlen(ifx_data_ptr->pBoundary);
	} while (nextTok != NULL);

	return 0;
}

#if 0
// Just for debug
void print_arg_list(struct ifx_wp *ifx_data_ptr)
{
	struct ifx_arg_list *ptr;

	if (ifx_data_ptr == NULL)
		return;

	ptr = ifx_data_ptr->ifx_ptr_arg_list;

	ifx_debug_printf("\n No. of arguments is %d\n",
			 ifx_data_ptr->ifx_no_argument);

	while (ptr) {
		ifx_debug_printf("\n ifx_ptr_arg->pifx_param_name = %s ",
				 ptr->pifx_param_name);
		ifx_debug_printf("\n ifx_ptr_arg->ifx_param_value.buf %s",
				 ptr->ifx_param_value.buf);
		ptr = ptr->next;
	}

	return;
}
#endif

//Check and extract the boundary.
void ifx_ExtractMPartBoundary(const char *content_type, struct ifx_wp *pifx_wp)
{
	if (content_type == NULL)
		return;
	if (strstr(content_type, "multipart/form-data")) {
		char *ptemp = NULL;
		ptemp = strstr(content_type, "boundary=");
		if (ptemp) {
			ptemp += strlen("boundary=");
			pifx_wp->pBoundary = strdup(ptemp);
			ifx_debug_printf("Multipart Boundary found as [%s]\n",
					 pifx_wp->pBoundary);
		}
	}
}

void ifx_setsocket_nonblocking(int socket)
{
	int opts = -1;

	// set the socket to nonblocking                                                                           
	opts = fcntl(socket, F_GETFL);
	if (opts < 0) {
		perror("fcntl(F_GETFL)");
		//exit(EXIT_FAILURE);                                                                              
	}
	opts = (opts | O_NONBLOCK);
	if (fcntl(socket, F_SETFL, opts) < 0) {
		perror("fcntl(F_SETFL)");
		//exit(EXIT_FAILURE);                                                                              
	}
}

int ifx_sendGoform(const char *url,
		   const char *request, const char *urlArgs,
		   int bodyLen, const char *cookie,
		   const char *content_type, const char *host, int readFd,
		   int writeFd)
{
	char wbuf[IFX_DATA_BUFF];
	int count;
	struct ifx_wp ifx_data_ptr;
	void *ifx_function_ptr = NULL;
	char *ifx_function_name;
	//void *handle = NULL;
	char *error;
	char *tempPtr = NULL;
	int arg_incomplete_flag = 0;
	int bFirstTime = 1;
	int tlen = 0;
	char *image_begin = NULL;
	int ret = IFX_SUCCESS;
	int upgrade_func = 0;
	int DownloadFileOpen = -1;

	ifx_function_name = (char *)calloc(IFX_FUN_NAME_LENGTH, sizeof(char));
	if (ifx_function_name == NULL)
		return -1;
	memset(&ifx_data_ptr, 0x0, sizeof(ifx_data_ptr));
	ifx_data_ptr.ifx_no_argument = 0;
	ifx_data_ptr.ifx_ptr_arg_list = NULL;
	ifx_data_ptr.pBoundary = NULL;
	char command[100] = { 0 };

	ifx_ExtractMPartBoundary(content_type, &ifx_data_ptr);

	if (bodyLen > IFX_MAX_DOWNLOAD_SIZE) {
		IFX_DBG
		    ("Download file size=%d greater than max=%d. Can't upgrade.\n",
		     bodyLen, IFX_MAX_DOWNLOAD_SIZE);
		system("/etc/rc.d/rebootcpe.sh 5 &");	// this can be removed later if a print is thrown on the screen saying that the upload failed
		IFX_MEM_FREE(ifx_function_name)
		    ifx_freeArgList(&ifx_data_ptr);
		return -1;
	}

	if (gstrstr(url, "ifx_set_system_upgrade") != NULL) {
		/* Call free memory with remote ip and indicate that upgrading firmware from http */
		(*ifx_getHeaderData) ("Remote IP", &tempPtr);
		sprintf(command, "/etc/rc.d/free_memory.sh http %s", tempPtr);
		system(command);
		upgrade_func = 1;
	}

/* [ Ritesh taking care of multiple pages and the like */
	do {

		if (bodyLen - tlen > IFX_DATA_BUFF - 1)
			count = IFX_DATA_BUFF - 1;
		else
			count = bodyLen - tlen;

/*manohar : if there is nothing to read then no need to call read func*/
    if(count == 0)
       break;

		memset(wbuf, '\0', IFX_DATA_BUFF);

		// Plug out LAN cable during Firmware download needs alternate solution
		// ifx_setsocket_nonblocking(readFd);

		/*manohar : to handle if read doesn't happen at single shot */
		if (gstrstr(url, "ifx_set_sysconfig_upgrade") != NULL
		    && bodyLen <= IFX_DATA_BUFF) {
			int flen = bodyLen;
			char *buf = wbuf;
			do {
				//count = (*ifx_read) (readFd, buf, flen);
				count = read(readFd, buf, flen);
				if (count > 0 && count <= flen) {
					buf += count;
					flen -= count;
				}
				// ifx_debug_printf("configuration data : count = %d flen = %d\n",count,flen);
			} while (count > 0);
			ifx_parseMPartArgBuf(wbuf, &ifx_data_ptr,
					     (unsigned int)(buf - wbuf),
					     &arg_incomplete_flag, &bFirstTime);
			break;
		}

	//	count = (*ifx_read) (readFd, wbuf, count);
		count = read(readFd, wbuf, count);
		if (count == 0) {
			break;
		}
		if (count < 0) {
			if (upgrade_func) {
				system("/etc/rc.d/rebootcpe.sh 5 &");
			}
			IFX_MEM_FREE(ifx_function_name)
			    return -1;
		}
		tlen += count;

		if (bodyLen > 0 && tlen > bodyLen) {
			fprintf(stderr,
				"\nBytes Read [%d] exceeds Content-Length [%d]! \n",
				bodyLen, tlen);
			if (upgrade_func) {
				IFX_MEM_FREE(ifx_function_name)
				    system("/etc/rc.d/rebootcpe.sh 5 &");
			}
			IFX_MEM_FREE(ifx_function_name)
			    return -1;
		}
		/*
		 * The code below works on the assumption that all large form data
		 * is going to be in "multipart" form of HTTP and small form data
		 * will be normal POST/GET. So for "multipart", we keep the data
		 * in several smaller buffers (prevent malloc failure), while for
		 * the normal case, we just do a realloc (to prevent having to rewrite
		 * all functions which do string/memory operations on a single 
		 * contiguous buffer!) 
		 * Example of a large POST is firmware upgrade operation.  - Ritesh
		 */
		if (ifx_data_ptr.pBoundary) {
#if 0
			/* for image upgrade -- wes
			   Below upgrading block is only for Amazon's upgrade procedure, because
			   the image file is large (sometime more than 3MB) then write the
			   upgrading image directly to temporary file and let upgrade program
			   do it. In future we should modify it
			 */
			if ((image_begin = strstr(wbuf, "AMZN"))) {
				FILE *fp = fopen("/tmp/web_image", "wb");
				unsigned long length =
				    *((unsigned long *)(image_begin + 4)) + 64;

				if (fp && length <= 0x400040) {
					unsigned long left =
					    (unsigned long)(wbuf +
							    sizeof(wbuf)) -
					    (unsigned long)image_begin - 1;

					fwrite(image_begin, left, 1, fp);
					length -= left;
					do {
						count =
						    (*ifx_read) (readFd, wbuf,
								 length >
								 sizeof(wbuf) ?
								 sizeof(wbuf) :
								 length);
						fwrite(wbuf, count, 1, fp);
						//ifx_data_ptr.multiDatalen += count;
						length -= count;
					} while (count == sizeof(wbuf));
					//printf("Success to create web tmp file!!:%d\n",left);
				} else
					printf
					    ("Error in create web tmp file!!\n");
				if (fp)
					fclose(fp);
				break;
			} else
#endif

			if (bFirstTime) {
				sprintf(command, "rm -rf %s",
					FILE_IMAGE_KERNEL);
				system(command);
				fpFirmwareUpgrade =
				    fopen(FILE_IMAGE_KERNEL, "ab");
				DownloadFileOpen = 1;
			}

			ifx_parseMPartArgBuf(wbuf, &ifx_data_ptr, count,
					     &arg_incomplete_flag, &bFirstTime);
		} else
			ifx_parsePostArgBuf(wbuf, &ifx_data_ptr, count,
					    &arg_incomplete_flag);
	} while (1);

	if ((fpFirmwareUpgrade) && (DownloadFileOpen == 1)) {

		fclose(fpFirmwareUpgrade);
		fpFirmwareUpgrade = NULL;
	}
	//IFX_DBG("url is %s\n",url);

	if (strncmp(url, "goform/", 7) == 0)
		url += 7;
	LTQ_STRNCPY(ifx_function_name, url, IFX_FUN_NAME_LENGTH);

	//IFX_DBG("Function to be execute is %s \n",ifx_function_name);
	//print_arg_list(&ifx_data_ptr);

	ifx_function_ptr = dlsym(dlHandle, (char *)ifx_function_name);
	if ((error = dlerror()) != NULL) {
		ifx_freeArgList(&ifx_data_ptr);
		IFX_FREE(ifx_function_name);
		if (upgrade_func) {
			system("/etc/rc.d/rebootcpe.sh 5 &");
		}
		return -1;
	} else {
#ifdef TRY_LOCK_SUPPORT
//                              syslog(LOG_KERN, "function name is [%s] !!", ifx_function_name);
		if ((gstrstr(ifx_function_name, "ifx_set_") != NULL)
		    && (gstrstr(ifx_function_name, "ifx_set_login") == NULL)
		    && (gstrstr(ifx_function_name, "ifx_set_logout") == NULL)) {
			IFX_TIMED_LOCK(LOCK_FILE_NAME, IFX_WEB, 4000, ret);
			if (ret != IFX_SUCCESS) {	// Get the lock on rc.conf
				sleep(1);
				IFX_TRY_LOCK(LOCK_FILE_NAME, IFX_WEB, ret);
				if (ret != IFX_SUCCESS) {

					ifx_debug_printf
					    ("Try to call post function ....\n");

					/* otherwise print a page which will say tr69 is currently in session
					 * do the necessary memory free if required */
					ifx_function_ptr =
					    dlsym(dlHandle,
						  "ifx_get_error_page");

					memset(ifx_data_ptr.host, '\0',
					       sizeof(ifx_data_ptr.host));
					strncpy(ifx_data_ptr.host, host,
						sizeof(ifx_data_ptr.host));
					ifx_data_ptr.ifxReadFd = readFd;
					ifx_data_ptr.ifxWriteFd = writeFd;
					(*ifx_getHeaderData) ("Remote IP",
							      &tempPtr);
					if (tempPtr != NULL)
						strncpy(ifx_data_ptr.ipaddr,
							tempPtr, sizeof(ifx_data_ptr.ipaddr)-1);
					ifx_debug_printf
					    ("###Remote IP addr : %s\n",
					     ifx_data_ptr.ipaddr);
					ifx_data_ptr.bSendHeader = 1;

					ifx_debug_printf
					    ("\n Try to call function ....\n");
					if (ifx_function_ptr)
						(*
						 (int (*)
						  (struct ifx_wp *, char *,
						   char *))
						 ifx_function_ptr)
					    (&ifx_data_ptr, NULL, NULL);
				} else
					goto call_http_func;
			} else {
			      call_http_func:

				ifx_debug_printf
				    ("Try to call post function ....\n");

				memset(ifx_data_ptr.host, '\0',
				       sizeof(ifx_data_ptr.host));
				strncpy(ifx_data_ptr.host, host,
					sizeof(ifx_data_ptr.host));
				ifx_data_ptr.ifxReadFd = readFd;
				ifx_data_ptr.ifxWriteFd = writeFd;
				(*ifx_getHeaderData) ("Remote IP", &tempPtr);
				if (tempPtr != NULL)
					strncpy(ifx_data_ptr.ipaddr, tempPtr,
						sizeof(ifx_data_ptr.ipaddr)-1);
				ifx_debug_printf("###Remote IP addr : %s\n",
						 ifx_data_ptr.ipaddr);
				ifx_data_ptr.bSendHeader = 1;
				if (ifx_function_ptr) {

					(*
					 (int (*)
					  (struct ifx_wp *, char *,
					   char *))
					 ifx_function_ptr) (&ifx_data_ptr, NULL,
							    NULL);
					ret = IFX_SUCCESS;
					IFX_UNLOCK(LOCK_FILE_NAME, IFX_WEB, ret)	// Release the lock on rc.conf */
				} else {
					ret = IFX_FAILURE;
				}
				//      ret = IFX_SUCCESS;
				//      IFX_UNLOCK(LOCK_FILE_NAME, IFX_WEB, ret) // Release the lock on rc.conf */
				if (ret != IFX_SUCCESS) {
					ifx_function_ptr =
					    dlsym(dlHandle,
						  (char *)"ifx_get_error_page");
					if (ifx_function_ptr)
						(*
						 (int (*)
						  (int, struct ifx_wp *, int,
						   char **))
						 ifx_function_ptr) (0,
								    &ifx_data_ptr,
								    0, NULL);
				}
			}
		} else {

			ifx_debug_printf("Try to call post function ....\n");

			memset(ifx_data_ptr.host, '\0',
			       sizeof(ifx_data_ptr.host));
			strncpy(ifx_data_ptr.host, host,
				sizeof(ifx_data_ptr.host));
			ifx_data_ptr.ifxReadFd = readFd;
			ifx_data_ptr.ifxWriteFd = writeFd;
			(*ifx_getHeaderData) ("Remote IP", &tempPtr);
			if (tempPtr != NULL)
				strncpy(ifx_data_ptr.ipaddr, tempPtr, sizeof(ifx_data_ptr.ipaddr)-1);
			ifx_debug_printf("###Remote IP addr : %s\n",
					 ifx_data_ptr.ipaddr);
			ifx_data_ptr.bSendHeader = 1;
			if (ifx_function_ptr != NULL) {
				(*(int (*)(struct ifx_wp *, char *, char *))
				 ifx_function_ptr) (&ifx_data_ptr, NULL, NULL);
			}
		}

#else

		ifx_debug_printf("Try to call post function ....\n");

		memset(ifx_data_ptr.host, '\0', sizeof(ifx_data_ptr.host));
		strncpy(ifx_data_ptr.host, host, sizeof(ifx_data_ptr.host));
		ifx_data_ptr.ifxReadFd = readFd;
		ifx_data_ptr.ifxWriteFd = writeFd;
		(*ifx_getHeaderData) ("Remote IP", &tempPtr);
		if (tempPtr != NULL)
			strncpy(ifx_data_ptr.ipaddr, tempPtr, sizeof(ifx_data_ptr.ipaddr)-1);
		ifx_debug_printf("###Remote IP addr : %s\n",
				 ifx_data_ptr.ipaddr);
		ifx_data_ptr.bSendHeader = 1;

		(*(int (*)(struct ifx_wp *, char *, char *))
		 ifx_function_ptr) (&ifx_data_ptr, NULL, NULL);
		//ifx_debug_printf("\n ifx_data_ptr.ifx_return_value is %d and ifx_data_ptr.ifx_buff is %s\n",ifx_data_ptr.ifx_return_value,ifx_data_ptr.ifx_buff);

		//bb_full_write(a_c_w,ifx_data_ptr.ifx_buff,strlen(ifx_data_ptr.ifx_buff));
#endif				// TRY_LOCK_SUPPORT
	}
	if (image_begin == 0)
		ifx_freeArgList(&ifx_data_ptr);
	IFX_FREE(ifx_function_name);

	return 0;
}

/******************************************************************************/
/*
 *	Home page handler
 */

int ifx_AuthHandler(char *url,char *referer, int readFd, int writeFd)
{
	char_t sValue[8]={0};
	httpdType wp;
	int now;
	char *tempPtr = NULL;
	struct connection_profil_list *seekPtr = NULL, *prevseekPtr = NULL;
	now = time((time_t *) NULL);

	/* If idle time variable is set to 0 (new connection/session is getting established),
	 * then read idle time from rc.conf and store in variable */
	if (!nIdleTime) {
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_SYSTEM_WEB_CONFIG, "AutoLogoutTime",
		     IFX_F_GET_ANY, NULL, sValue) != IFX_SUCCESS) {
			/* If value is not found in rc.conf, then use default value */
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("[%s:%d] fetching from rc.conf failed and hence idle time out is [%d]",
			     __FUNCTION__, __LINE__, nIdleTime);
#endif
			nIdleTime = MAX_WEB_IDELTIME;
		} else {
			nIdleTime = atoi(sValue);
		}
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] idle time out is [%d]", __FUNCTION__, __LINE__,
			nIdleTime);
#endif
	}

#if 0 // [ 0
	if (now - connection_new.time > nIdleTime) {
		ifx_debug_printf("Previous administrator's time has expired\n");
		memset(connection_new.ipaddr, 0x00, sizeof(connection_new.ipaddr));
#ifdef CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE
		memset(connection_new.macaddr, 0x00, sizeof(connection_new.macaddr));
#endif /* CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE */
	}
	if (now - connection.time > nIdleTime) {
		ifx_debug_printf("Previous administrator's time has expired\n");
		memset(connection.ipaddr, 0x00, sizeof(connection.ipaddr));
#ifdef CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE
		memset(connection.macaddr, 0x00, sizeof(connection.macaddr));
#endif /* CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE */
	}

printf("stage 1\n");
	seekPtr = connlist;
	prevseekPtr = seekPtr;
	while(seekPtr != NULL) {
		printf("[%s:%d] comparing session:incoming ip [%s:%s]\n", __FUNCTION__, __LINE__,
							seekPtr->connection.ipaddr, wp.ipaddr);
		if((strncmp(seekPtr->connection.ipaddr, wp.ipaddr, sizeof(seekPtr->connection.ipaddr)) == 0)) {
			if (now - seekPtr->connection.time > nIdleTime) {
				printf("[%s:%d] current time:session creation time [%u:%u] session time expired, so resetting\n", __FUNCTION__, __LINE__, now, seekPtr->connection.time);
				prevseekPtr->next = seekPtr->next;
				IFX_MEM_FREE(seekPtr)
  	    if(atoi(sValue) != 1)
					ifx_httpdRedirect(&wp, T("login.asp"));
				else
					return 0;
				return 1;
			}
			/* Session time has not gone past idle time */
			break;
		}
		prevseekPtr = seekPtr;
		seekPtr = seekPtr->next;
	}
#endif // 0 ]

	sValue[0]='\0';
	if (ifx_GetObjData(FILE_RC_CONF,TAG_SYSTEM_PASSWORD, T("PasswdProtect"),IFX_F_GET_ANY,NULL,sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s][%d] passwd protect not found",__FUNCTION__,__LINE__);
#endif
		return -1;
	}

  if(atoi(sValue) != 1)
	if (strstr(IFX_BYPASS_URL, url)) {
		ifx_debug_printf("URL : %s\n", IFX_BYPASS_URL);
		return 0;
	}
  //IFX_DBG("[%s][%d] url = [%s]\nreferer = [%s]\n",__FUNCTION__,__LINE__,url,referer);
	(*ifx_getHeaderData) ("Remote IP", &tempPtr);
	strncpy(wp.ipaddr, tempPtr, sizeof(wp.ipaddr));

	(*ifx_getHeaderData) ("Host", &tempPtr);
	strncpy(wp.host, tempPtr, sizeof(wp.host));
        
	wp.ifxReadFd = readFd;
	wp.ifxWriteFd = writeFd;
#if 0
//#ifndef CONFIG_LTQ_AEI_CUST
#ifdef CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE
	if (strncmp(connection.ipaddr, wp.ipaddr, sizeof(connection.ipaddr)) != 0)
	{
		char_t macaddr[32];
		memset(macaddr, 0x00, sizeof(macaddr));
		// Get the sender mac address from ARP table
		// Compare the sender mac address
		// if matched, update the sender IP address in the connection profile,
		// so that user can continue web access with the newly assigned host IP address
		if (!get_remote_hwaddr(wp.ipaddr, macaddr) && !strcasecmp(macaddr, connection.macaddr)) {
			memcpy(connection.ipaddr, wp.ipaddr, sizeof(connection.ipaddr) - 1);
		}
	}
	if (strncmp(connection.ipaddr, wp.ipaddr, sizeof(connection.ipaddr)) == 0) {
#else /* CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE */
	if (strncmp(connection.ipaddr, wp.ipaddr, strlen(wp.ipaddr)) == 0) {
#endif /* !CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE */
		if (now - connection.time < nIdleTime) {
			ifx_debug_printf("the same ip is %s\n",
					 connection.ipaddr);
			ifx_debug_printf("allowed\n");
			connection.time = now;
			return 0;
		} else {
			ifx_debug_printf("NOT allowed\n");
			memset(connection.ipaddr, 0x00,
			       sizeof(connection.ipaddr));
#ifdef CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE
			memset(connection.macaddr, 0x00,
			       sizeof(connection.macaddr));
#endif /* CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE */
			//IFX_CM_WebShut();
			connection.time = 0;
    if(atoi(sValue) != 1)
			ifx_httpdRedirect(&wp, T("login_redirect.asp"));
		else
			return 0;
			return 1;
		}
	}
	}
#endif

	/* Check if session exists mataching IP and MAC address
	 * if session exists and
	 * a. session time < idle time then do nothing
	 * b. session time > idle time then remove session entry
	 */
	if(connlist != NULL) {
		seekPtr = connlist;
		prevseekPtr = seekPtr;
		if(seekPtr != NULL && (strncmp(seekPtr->connection.ipaddr, wp.ipaddr, sizeof(seekPtr->connection.ipaddr)) == 0)) {
			/* 1st in the list is matched */
			if (now - seekPtr->connection.time < nIdleTime) {
	#ifdef IFX_LOG_DEBUG
				IFX_DBG("the same  https ip is %s allowed\n",
					seekPtr->connection.ipaddr);
	#endif
				seekPtr->connection.time = now;
				return 0;
			}
			else
			{
				connlist = seekPtr->next;
				IFX_MEM_FREE(seekPtr)
		    if(atoi(sValue) != 1)
					ifx_httpdRedirect(&wp, T("login.asp"));
				else
					return 0;
				return 1;
			}
		}
		else {
			/* otherwise */
			seekPtr = connlist->next;
			prevseekPtr = connlist;
			while(seekPtr != NULL) {
				if((strncmp(seekPtr->connection.ipaddr, wp.ipaddr, sizeof(seekPtr->connection.ipaddr)) == 0)) {
					if (now - seekPtr->connection.time < nIdleTime) {
		#ifdef IFX_LOG_DEBUG
						IFX_DBG("the same  https ip is %s allowed\n",
							seekPtr->connection.ipaddr);
		#endif
						seekPtr->connection.time = now;
						return 0;
					}
					else
					{
						prevseekPtr->next = seekPtr->next;
						IFX_MEM_FREE(seekPtr)
		  	    if(atoi(sValue) != 1)
							ifx_httpdRedirect(&wp, T("login.asp"));
						else
							return 0;
						return 1;
					}
				}
				prevseekPtr = seekPtr;
				seekPtr = seekPtr->next;
			}
		}
	}

/*manohar end*/
//#endif
  if(atoi(sValue) != 1) {
#if 0
		/* if auto-login is disabled check if existing session count = 4
		 * if so, deny new session creation
		 */
		int sess_count = 0;
		seekPtr = connlist;
		while(seekPtr != NULL) {
			seekPtr = seekPtr -> next;
			sess_count++;
		}

		if(sess_count >= 4) {
			ifx_httpdWrite(&wp, "Number of active sessions has reached system limit. Please try after some time.");
			return 1;
		}
		else {
			ifx_httpdRedirect(&wp, T("login.asp"));
		}
#endif // 0
		/* new session to be established */
		ifx_httpdRedirect(&wp, T("login.asp"));
	}
	else {
		return 0;
	}
	return 1;
}
