//#include <sys/syslog.h>
#include <ifx_emf.h>
#include "ifx_httpd_method.h"
//#include <signal.h>
//#include <unistd.h>
//#include <sys/types.h>
//#include <sys/wait.h>
//#include <ifx_common.h>
#include "./ifx_amazon_cgi.h"
//#include "./ifx_amazon_cgi_getFunctions.h"
//#include "ifx_snmp_api.h"
//#include "ifx_api_ipt_common.h"
//#include <sys/ioctl.h>
#include "./ifx_cgi_common.h"

#ifdef CONFIG_FEATURE_QOS
int ifx_get_qos_status(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_qos_diffserv_setting(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_qos_algs(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_qos_alg_setting(int eid, httpd_t wp, int argc, char_t ** argv);
void ifx_set_qos_main(httpd_t wp, char_t * path, char_t * query);	// qos_main.asp
void ifx_set_qos_diffserv_setting(httpd_t wp, char_t * path, char_t * query);	// qos_diffserv.asp
#endif				// CONFIG_FEATURE_QOS

int ifx_get_default_queue_check(int eid, httpd_t wp, int argc, char_t ** arg_v);
extern int ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);
extern int32 ifx_get_another_fvp_from_dist_fvp(char8 * secName, char8 * fName,
					       char8 * fValue, char8 * fRetName,
					       char8 * fRetValue, uint32 flags);
extern void websNextPage(httpd_t wp);
extern char *def_q_err;
extern char *def_prio_err;
extern char *qcl_depend_err;
extern char *status_str;
extern char *q_name_err;
extern char *class_name_err;
extern char *q_depend_err;
extern char *max_limit_err;
extern char *peak_rate_err;
char qosOperation[20];
char qoscpeId[10];

//manohar
typedef struct {
	/* Web ASP selected option value index */
	uint value;
	/* Web ASP selected option value index content */
	char_t *str;
} CGI_ENUMSEL_S;

//000001:tc.chen start transfer QoSPriority table to system configuration syntax
#ifdef CONFIG_FEATURE_QOS_PRIORITY_QUEUE
int
websUpdate_QoSPriorityTable2File(int nQoSPriority_Table_Size,
				 CGI_TABLE_S * QoSPriorityTable)
{
	int nIndex = 0, nQoSPriority_Counter = 0;
	char_t sBuf[BUF_SIZE_50K];
	sBuf[0] = '\0';

	// count the table size
	for (nIndex = 0; nIndex < nQoSPriority_Table_Size; nIndex++) {
		if (QoSPriorityTable[nIndex].nIndex >= 0) {
			nQoSPriority_Counter++;
		}
	}

	sprintf(sBuf, "%sCount=\"%d\"\n", PREFIX_QOS_PRIORITY,
		nQoSPriority_Counter);
	nQoSPriority_Counter = 0;
	// update data from table to file
	for (nIndex = 0; nIndex < nQoSPriority_Table_Size; nIndex++) {
		if (QoSPriorityTable[nIndex].nIndex >= 0) {
			char_t sLine[MAX_FILELINE_LEN];
			sprintf(sLine, "%sPRIO%d=\"%d\"\n", PREFIX_QOS_PRIORITY,
				nQoSPriority_Counter,
				QoSPriorityTable[nIndex].nState);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sIP_SRC_IP%d=\"%s\"\n",
				PREFIX_QOS_PRIORITY, nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.
				sQP_IP_SRC_IP);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sIP_SRC_MASK%d=\"%s\"\n",
				PREFIX_QOS_PRIORITY, nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.
				sQP_IP_SRC_MASK);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sPORT_SRC_START%d=\"%s\"\n",
				PREFIX_QOS_PRIORITY, nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.
				sQP_PORT_SRC_START);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sPORT_SRC_END%d=\"%s\"\n",
				PREFIX_QOS_PRIORITY, nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.
				sQP_PORT_SRC_END);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sIP_DST_IP%d=\"%s\"\n",
				PREFIX_QOS_PRIORITY, nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.
				sQP_IP_DST_IP);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sIP_DST_MASK%d=\"%s\"\n",
				PREFIX_QOS_PRIORITY, nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.
				sQP_IP_DST_MASK);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sPORT_DST_START%d=\"%s\"\n",
				PREFIX_QOS_PRIORITY, nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.
				sQP_PORT_DST_START);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sPORT_DST_END%d=\"%s\"\n",
				PREFIX_QOS_PRIORITY, nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.
				sQP_PORT_DST_END);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sPROTO%d=\"%s\"\n",
				PREFIX_QOS_PRIORITY, nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.
				sQP_PROTO);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sIF%d=\"%s\"\n", PREFIX_QOS_PRIORITY,
				nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.sQP_IF);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sDIR%d=\"%s\"\n", PREFIX_QOS_PRIORITY,
				nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.sQP_DIR);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sTYPE%d=\"%s\"\n", PREFIX_QOS_PRIORITY,
				nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.
				sQP_TYPE);
			strcat(sBuf, sLine);
			nQoSPriority_Counter++;
		}
	}
	return (ifx_SetCfgData(FILE_RC_CONF, TAG_QOS_PRIORITY, 1, sBuf));
}
#endif				// CONFIG_FEATURE_QOS_PRIORITY_QUEUE

#ifdef CONFIG_FEATURE_QOS
//////////////////////////////////////////////////////////////////////////////////
//510251:sumedh start (ALGs)
//      PAGE : qos_algs.asp
void ifx_set_qos_algs(httpd_t wp, char_t * path, char_t * query)
{
	char_t *buffer, buf[MAX_DATA_LEN];
	// char_t *pWanIface;
	char_t sValue[MAX_FILELINE_LEN];
	int i;
	int alg_qos_enable = 0;
	// char_t *pLanIface = NULL;
	struct alg_struct_t {
		char_t statusName[32];
		char_t qosStatusName[32];
		char_t up_minBWName[32];
		char_t up_maxBWName[32];
		char_t dwn_maxBWName[32];
		char_t displayName[32];
	};
	struct alg_struct_t alg_struct[] = {
		{"NETMEETING_STATUS", "NETMEETING_QOS", "UP_NETMEETING_MINBW",
		 "UP_NETMEETING_MAXBW", "DWN_NETMEETING_MAXBW", "Netmeeting"},
		{"PPTP_STATUS", "PPTP_QOS", "UP_PPTP_MINBW", "UP_PPTP_MAXBW",
		 "DWN_PPTP_MAXBW", "PPTP"}, {"RTSP_STATUS", "RTSP_QOS",
					     "UP_RTSP_MINBW", "UP_RTSP_MAXBW",
					     "DWN_RTSP_MAXBW", "RTSP/RTP"},
		{"FTP_STATUS", "FTP_QOS", "UP_FTP_MINBW", "UP_FTP_MAXBW",
		 "DWN_FTP_MAXBW", "FTP"}, {"IPSEC_STATUS", "IPSEC_QOS",
					   "UP_IPSEC_MINBW",
					   "UP_IPSEC_MAXBW", "DWN_IPSEC_MAXBW",
					   "IPSec"},
		{"ICMP_STATUS", "ICMP_QOS", "UP_ICMP_MINBW", "UP_ICMP_MAXBW",
		 "DWN_ICMP_MAXBW", "ICMP"}, {"SIP_STATUS", "SIP_QOS",
					     "UP_SIP_MINBW",
					     "UP_SIP_MAXBW", "DWN_SIP_MAXBW",
					     "SIP"}
//510251:sumedh (commented out as backend is not complete)
	};
	char_t *pFunc, *pQosEnable, *pUpMinBandwidth, *pUpMaxBandwidth,
	    *pDwnMaxBandwidth;
	char_t sUpMinBandwidth[sizeof(alg_struct) /
			       sizeof(struct alg_struct_t)][MAX_DATA_LEN],
	    sUpMaxBandwidth[sizeof(alg_struct) /
			    sizeof(struct alg_struct_t)][MAX_DATA_LEN],
	    sDwnMaxBandwidth[sizeof(alg_struct) /
			     sizeof(struct alg_struct_t)][MAX_DATA_LEN];
	char_t sFunc[sizeof(alg_struct) /
		     sizeof(struct alg_struct_t)][MAX_DATA_LEN];
	char_t sQosEnable[sizeof(alg_struct) /
			  sizeof(struct alg_struct_t)][MAX_DATA_LEN];
	int algMinBw = 0;

	a_assert(wp);
	buf[0] = '\0';
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_QOS_CONFIG, T("QOS_ENABLE"), sValue) != 0) {
		if (!gstrcmp(sValue, "1")) {
			if (ifx_GetCfgData
			    (FILE_RC_CONF, TAG_QOS_DIFFSERV_CONFIG,
			     T("QOS_ALG"), sValue) != 0) {
				if (!gstrcmp(sValue, "1"))
					alg_qos_enable = 1;
			}
		}
	}
	for (i = 0; i < sizeof(alg_struct) / (sizeof(struct alg_struct_t)); i++) {
		/* Set QOS_ENABLE#, MIN_BW#, and MAX_BW# to rc.iptables. */
		memset(sQosEnable[i], 0x00, sizeof(sQosEnable[i]));
		memset(buf, 0x00, sizeof(buf));
		gsprintf(buf, T("%s"), alg_struct[i].qosStatusName);
		pQosEnable = ifx_httpdGetVar(wp, buf, T(""));
		if (!gstrcmp(pQosEnable, T("1")))
			gsprintf(sQosEnable[i], "%s=\"1\"\n", buf);
		else
			gsprintf(sQosEnable[i], "%s=\"0\"\n", buf);

		memset(sUpMinBandwidth[i], 0x00, sizeof(sUpMinBandwidth[i]));
		memset(buf, 0x00, sizeof(buf));
		gsprintf(buf, T("%s"), alg_struct[i].up_minBWName);
		pUpMinBandwidth = ifx_httpdGetVar(wp, buf, T(""));
		if (pUpMinBandwidth[0]) {
			gsprintf(sUpMinBandwidth[i], T("%s=\"%s\"\n"), buf,
				 pUpMinBandwidth);
			if (!gstrcmp(pQosEnable, T("1")))
				algMinBw += atoi(pUpMinBandwidth);
		} else {
			gsprintf(sUpMinBandwidth[i], T("%s=\"\"\n"), buf);
		}

		memset(sUpMaxBandwidth[i], 0x00, sizeof(sUpMaxBandwidth[i]));
		memset(buf, 0x00, sizeof(buf));
		gsprintf(buf, T("%s"), alg_struct[i].up_maxBWName);
		pUpMaxBandwidth = ifx_httpdGetVar(wp, buf, T(""));
		if (pUpMaxBandwidth[0])
			gsprintf(sUpMaxBandwidth[i], T("%s=\"%s\"\n"), buf,
				 pUpMaxBandwidth);
		else
			gsprintf(sUpMaxBandwidth[i], T("%s=\"\"\n"), buf);

		memset(sDwnMaxBandwidth[i], 0x00, sizeof(sDwnMaxBandwidth[i]));
		memset(buf, 0x00, sizeof(buf));
		gsprintf(buf, T("%s"), alg_struct[i].dwn_maxBWName);
		pDwnMaxBandwidth = ifx_httpdGetVar(wp, buf, T(""));
		if (pDwnMaxBandwidth[0])
			gsprintf(sDwnMaxBandwidth[i], T("%s=\"%s\"\n"), buf,
				 pDwnMaxBandwidth);
		else
			gsprintf(sDwnMaxBandwidth[i], T("%s=\"\"\n"), buf);
		// Set NATVS_F# to rc.iptables.
		memset(sFunc[i], 0x00, sizeof(sFunc[i]));
		gsprintf(buf, T("%s"), alg_struct[i].statusName);
		pFunc = ifx_httpdGetVar(wp, buf, T(""));
		if (!gstrcmp(pFunc, "1")) {
			gsprintf(sFunc[i], T("%s=\"1\"\n"), buf);
		} else {
			gsprintf(sFunc[i], T("%s=\"0\"\n"), buf);
		}
	}

	buffer = (char_t *) malloc(sizeof(char_t) * (BUF_SIZE_50K));
	gstrcpy(buffer, "");
	gsprintf(buffer, T("ALG_MINBW=\"%d\"\n"), algMinBw);

	for (i = 0; i < sizeof(alg_struct) / sizeof(struct alg_struct_t); i++) {
		gstrcat(buffer, sFunc[i]);
		gstrcat(buffer, sQosEnable[i]);
		gstrcat(buffer, sUpMinBandwidth[i]);
		gstrcat(buffer, sUpMaxBandwidth[i]);
		gstrcat(buffer, sDwnMaxBandwidth[i]);
	}

	ifx_SetCfgData(FILE_RC_CONF, TAG_ALG, 1, buffer);

#if 0
	if (buffer && *buffer)
		free(buffer);
#else
	IFX_MEM_FREE(buffer);
#endif
	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}
	// Restart service
	system(SERVICE_QOS_RESTART);

	websNextPage(wp);
}

//510251:sumedh end
void ifx_set_qos_main(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pCheck, sCheck[MAX_FILELINE_LEN];
//000001:tc.chen start move ifx_set_qos_diffserv_setting to here
//                    and add qos priority setting
#ifdef CONFIG_FEATURE_IFX_VOIP
	char_t *pDsVoip = ifx_httpdGetVar(wp, T("DsVoip"), T(""));
	char_t sDsVoip[MAX_DATA_LEN];
#endif

	char_t *pDsVs = ifx_httpdGetVar(wp, T("DsVs"), T(""));
	char_t sDsVs[MAX_DATA_LEN];

	// manohar start
	char_t *wanIf = ifx_httpdGetVar(wp, T("wanif"), T(""));
	char_t swanIf[MAX_DATA_LEN];
	// manohar end

//510251:sumedh start (ALGs)
	char_t *pqos_alg = ifx_httpdGetVar(wp, T("QOS_ALG"), T(""));
	char_t sqos_alg[MAX_DATA_LEN];
//510251:sumedh end (ALGs)

	char_t *pPrio = ifx_httpdGetVar(wp, T("QosPrioStatus"), T(""));
	char_t sPrio[MAX_DATA_LEN] = "QOS_PRIO=\"0\"\n";
	char_t sPrePrio[MAX_DATA_LEN];
	char_t *pQOSIPPTOS;
	char_t sQOSIPPTOS[MAX_DATA_LEN] = "QOS_IPPTOS=\"0\"\n";
	char_t *pQOS8021P;
	char_t sQOS8021P[MAX_DATA_LEN] = "QOS_8021P=\"0\"\n";
#ifdef CONFIG_FEATURE_QOS_IPPTOS
	pQOSIPPTOS = ifx_httpdGetVar(wp, T("QOS_IPPTOS"), T(""));
#endif
#ifdef CONFIG_FEATURE_QOS_8021P
	pQOS8021P = ifx_httpdGetVar(wp, T("QOS_8021P"), T(""));
#endif
//000001:tc.chen end
	a_assert(wp);
	sCheck[0] = '\0';

	// Get value from ASP filz
	pCheck = ifx_httpdGetVar(wp, T("QosStatus"), T(""));

	if (!gstrcmp(pCheck, "1")) {
		gsprintf(sCheck, T("QOS_ENABLE=\"%s\"\n"), pCheck);
	} else {
		gsprintf(sCheck, T("QOS_ENABLE=\"0\"\n"));
	}

	// 000001:tc.chen ifx_SetCfgData(FILE_RC_CONF, TAG_QOS_CONFIG, 1, sCheck);

// 000001:tc.chen start
#ifdef CONFIG_FEATURE_QOS_PRIORITY_QUEUE
	ifx_GetCfgData(FILE_RC_CONF, TAG_QOS_CONFIG, "QOS_PRIO", sPrePrio);
	if (!gstrcmp(pPrio, "1")) {
		gsprintf(sPrio, T("QOS_PRIO=\"%s\"\n"), pCheck);
	} else {
		gsprintf(sPrio, T("QOS_PRIO=\"0\"\n"));
	}
#endif				// CONFIG_FEATURE_QOS_PRIORITY_QUEUE
//000001:tc.chen end
	ifx_SetCfgData(FILE_RC_CONF, TAG_QOS_CONFIG, 2, sCheck, sPrio);

#ifdef CONFIG_FEATURE_IFX_VOIP
	// Set to rc.conf file
	if (!gstrcmp(pDsVoip, T("1")))
		gsprintf(sDsVoip, "DIFFSERV_DUT_VOIP=\"1\"\n");
	else
		gsprintf(sDsVoip, "DIFFSERV_DUT_VOIP=\"0\"\n");
#endif

	if (!gstrcmp(pDsVs, T("1")))
		gsprintf(sDsVs, "DIFFSERV_VIRTUAL_SERVER=\"1\"\n");
	else
		gsprintf(sDsVs, "DIFFSERV_VIRTUAL_SERVER=\"0\"\n");
//510251:sumedh start (ALGs)
	if (!gstrcmp(pqos_alg, T("1")))
		gsprintf(sqos_alg, "QOS_ALG=\"1\"\n");
	else
		gsprintf(sqos_alg, "QOS_ALG=\"0\"\n");
//510251:sumedh end (ALGs)

#ifdef CONFIG_FEATURE_QOS_PRIORITY_QUEUE
#ifdef CONFIG_FEATURE_QOS_IPPTOS
	if (!gstrcmp(pQOSIPPTOS, T("1")))
		gsprintf(sQOSIPPTOS, "QOS_IPPTOS=\"1\"\n");
	else
		gsprintf(sQOSIPPTOS, "QOS_IPPTOS=\"0\"\n");
#endif
#ifdef CONFIG_FEATURE_QOS_8021P
	if (!gstrcmp(pQOS8021P, T("1")))
		gsprintf(sQOS8021P, "QOS_8021P=\"1\"\n");
	else
		gsprintf(sQOS8021P, "QOS_8021P=\"0\"\n");
#endif
#endif

#ifdef CONFIG_FEATURE_IFX_VOIP
	ifx_SetCfgData(FILE_RC_CONF, TAG_QOS_DIFFSERV_CONFIG, 5, sDsVoip, sDsVs, sqos_alg, sQOSIPPTOS, sQOS8021P);	// 000001:tc
#else
	ifx_SetCfgData(FILE_RC_CONF, TAG_QOS_DIFFSERV_CONFIG, 4, sDsVs, sqos_alg, sQOSIPPTOS, sQOS8021P);	// 000001:tc
#endif

//000001:tc.chen end

	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}
//000001:tc.chen start
#ifdef CONFIG_FEATURE_QOS_PRIORITY_QUEUE
	if (sPrePrio[0] != pPrio[0]) {
		if (sPrePrio[0] == '0') {
			system(SERVICE_PIF_START);	/* 509023:linmars */
		} else if (sPrePrio[0] == '1') {
			system(SERVICE_PIF_STOP);	/* 509023:linmars */
		}
	}
#endif				// CONFIG_FEATURE_QOS_PRIORITY_QUEUE
//000001:tc.chen end

	// Runtime Change
	system(SERVICE_QOS_RESTART);

	websNextPage(wp);
}

// 000001:tc.chen start
#ifdef CONFIG_FEATURE_QOS_PRIORITY_QUEUE
// update qos priority rules or delete a priority rule
void ifx_set_qos_priority(httpd_t wp, char_t * path, char_t * query)
{
	char_t buf[MAX_DATA_LEN];
	CGI_TABLE_S QoSPriorityTable[QOS_PRIORITY_TABLE_NUM];
	char_t *pPrio;
	char_t *pDel = ifx_httpdGetVar(wp, T("delflag"), T(""));
	int nIndex, nQoSPriority_Size = 0;

	a_assert(wp);

	buf[0] = '\0';

	// Get original data form file
	nQoSPriority_Size =
	    websGetCfgData2Table(wp, FILE_RC_CONF, TAG_QOS_PRIORITY,
				 PREFIX_QOS_PRIORITY, QoSPriorityTable,
				 QOS_PRIORITY_TABLE_TYPE);
	if (nQoSPriority_Size == -1) {
		ifx_httpdError(wp, 500,
			       "Insufficient data for PacketFilter table");
		return;
	}
	// Get Priority status & Update QoSPriorityTable
	for (nIndex = 0; nIndex < nQoSPriority_Size; nIndex++) {
		gsprintf(buf, "QP_PRIO%d", nIndex);
		pPrio = ifx_httpdGetVar(wp, buf, T(""));

		if (!pPrio) {
			ifx_httpdError(wp, 500, "Insufficient data ");
			return;
		}
		QoSPriorityTable[nIndex].nState = atoi(pPrio);
	}

	// Submit data form press delete button, remove the rule.
	if (!gstrcmp(pDel, T("1"))) {
		char_t *pDelIndex = ifx_httpdGetVar(wp, T("delindex"), T(""));
		int nDelIndex = gatoi(pDelIndex);
		trace(8, "Del table\n");
		// Remove DelIndex form Table
		for (nIndex = nDelIndex + 1; nIndex < nQoSPriority_Size;
		     nIndex++) {
			QoSPriorityTable[nIndex].nIndex--;
		}
		QoSPriorityTable[nDelIndex].nIndex = -1;
	}
	// //////// Update Table to File ///////////////
	websUpdate_QoSPriorityTable2File(nQoSPriority_Size, QoSPriorityTable);

	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}

	system(SERVICE_QOS_PRIORITY_RESTART);
	websNextPage(wp);
}

// add  a qos priority rule
void ifx_set_qos_priority_add(httpd_t wp, char_t * path, char_t * query)
{
	CGI_TABLE_S QoSPriorityTable[QOS_PRIORITY_TABLE_NUM];
	int nQoSPriority_Size = 0;
	char_t *pQP_TYPE = ifx_httpdGetVar(wp, T("QP_TYPE_ADD"), T(""));
	char_t *pQP_IP_SRC_IP =
	    ifx_httpdGetVar(wp, T("QP_IP_SRC_IP_ADD"), T(""));
	char_t *pQP_IP_SRC_TYPE =
	    ifx_httpdGetVar(wp, T("QP_IP_SRC_TYPE_ADD"), T(""));
	char_t *pQP_IP_SRC_MASK =
	    ifx_httpdGetVar(wp, T("QP_IP_SRC_MASK_ADD"), T(""));
	char_t *pQP_IP_DST_TYPE =
	    ifx_httpdGetVar(wp, T("QP_IP_DST_TYPE_ADD"), T(""));
	char_t *pQP_IP_DST_IP =
	    ifx_httpdGetVar(wp, T("QP_IP_DST_IP_ADD"), T(""));
	char_t *pQP_IP_DST_MASK =
	    ifx_httpdGetVar(wp, T("QP_IP_DST_MASK_ADD"), T(""));
	char_t *pQP_PORT_SRC_START =
	    ifx_httpdGetVar(wp, T("QP_PORT_SRC_START_ADD"), T(""));
	char_t *pQP_PORT_SRC_END =
	    ifx_httpdGetVar(wp, T("QP_PORT_SRC_END_ADD"), T(""));
	char_t *pQP_PORT_DST_START =
	    ifx_httpdGetVar(wp, T("QP_PORT_DST_START_ADD"), T(""));
	char_t *pQP_PORT_DST_END =
	    ifx_httpdGetVar(wp, T("QP_PORT_DST_END_ADD"), T(""));
	char_t *pQP_PROTO = ifx_httpdGetVar(wp, T("QP_PROTO_ADD"), T(""));
	char_t *pQP_IF = ifx_httpdGetVar(wp, T("QP_IF_ADD"), T(""));
	char_t *pQP_PRIO = ifx_httpdGetVar(wp, T("QP_PRIO_ADD"), T(""));
	char_t *pQP_DIR = ifx_httpdGetVar(wp, T("QP_DIR_ADD"), T(""));

	// copy data to QoSPriorityTable
	nQoSPriority_Size =
	    websGetCfgData2Table(wp, FILE_RC_CONF, TAG_QOS_PRIORITY,
				 PREFIX_QOS_PRIORITY, QoSPriorityTable,
				 QOS_PRIORITY_TABLE_TYPE);
	if (nQoSPriority_Size >= QOS_PRIORITY_TABLE_NUM) {
		ifx_httpdError(wp, 500,
			       T("Out of space to add QoS Priority entry"));
		return;
	}

	memset(&QoSPriorityTable[nQoSPriority_Size], 0x00, sizeof(CGI_TABLE_S));

	// update index
	QoSPriorityTable[nQoSPriority_Size].nIndex =
	    QoSPriorityTable[nQoSPriority_Size - 1].nIndex + 1;
	QoSPriorityTable[nQoSPriority_Size].nState = atoi(pQP_PRIO);
	// copy source ip and source netmask
	if (atoi(pQP_IP_SRC_TYPE) != 0 && strlen(pQP_IP_SRC_IP)) {
		strcpy(QoSPriorityTable[nQoSPriority_Size].Data.QP_TABLE.
		       sQP_IP_SRC_IP, pQP_IP_SRC_IP);
		if (atoi(pQP_IP_SRC_TYPE) == 2 && strlen(pQP_IP_SRC_MASK)) {
			sprintf(QoSPriorityTable[nQoSPriority_Size].Data.
				QP_TABLE.sQP_IP_SRC_MASK, "%d",
				netmask2bits(inet_addr(pQP_IP_SRC_MASK)));
		} else {
			sprintf(QoSPriorityTable[nQoSPriority_Size].Data.
				QP_TABLE.sQP_IP_SRC_MASK, "0");
		}
	} else {
		sprintf(QoSPriorityTable[nQoSPriority_Size].Data.QP_TABLE.
			sQP_IP_SRC_IP, "*");
		sprintf(QoSPriorityTable[nQoSPriority_Size].Data.QP_TABLE.
			sQP_IP_SRC_MASK, "0");
	}

	// copy source port
	if (!pQP_PORT_SRC_START[0]) {
		sprintf(QoSPriorityTable[nQoSPriority_Size].Data.QP_TABLE.
			sQP_PORT_SRC_START, "*");
	} else {
		strcpy(QoSPriorityTable[nQoSPriority_Size].Data.QP_TABLE.
		       sQP_PORT_SRC_START, pQP_PORT_SRC_START);
	}

	if (pQP_PORT_SRC_END[0]) {
		strcpy(QoSPriorityTable[nQoSPriority_Size].Data.QP_TABLE.
		       sQP_PORT_SRC_END, pQP_PORT_SRC_END);
	} else {
		strcpy(QoSPriorityTable[nQoSPriority_Size].Data.QP_TABLE.
		       sQP_PORT_SRC_END,
		       QoSPriorityTable[nQoSPriority_Size].Data.QP_TABLE.
		       sQP_PORT_SRC_START);
	}
	// copy destination ip
	if (atoi(pQP_IP_DST_TYPE) != 0 && strlen(pQP_IP_DST_IP)) {
		strcpy(QoSPriorityTable[nQoSPriority_Size].Data.QP_TABLE.
		       sQP_IP_DST_IP, pQP_IP_DST_IP);
		if (atoi(pQP_IP_DST_TYPE) == 2 && strlen(pQP_IP_DST_MASK)) {
			sprintf(QoSPriorityTable[nQoSPriority_Size].Data.
				QP_TABLE.sQP_IP_DST_MASK, "%d",
				netmask2bits(inet_addr(pQP_IP_DST_MASK)));
		} else {
			sprintf(QoSPriorityTable[nQoSPriority_Size].Data.
				QP_TABLE.sQP_IP_DST_MASK, "0");
		}
	} else {
		sprintf(QoSPriorityTable[nQoSPriority_Size].Data.QP_TABLE.
			sQP_IP_DST_IP, "*");
		sprintf(QoSPriorityTable[nQoSPriority_Size].Data.QP_TABLE.
			sQP_IP_DST_MASK, "0");
	}

	// copy destination port
	if (!pQP_PORT_DST_START[0]) {
		sprintf(QoSPriorityTable[nQoSPriority_Size].Data.QP_TABLE.
			sQP_PORT_DST_START, "*");
	} else {
		strcpy(QoSPriorityTable[nQoSPriority_Size].Data.QP_TABLE.
		       sQP_PORT_DST_START, pQP_PORT_DST_START);
	}

	if (pQP_PORT_DST_END[0]) {
		strcpy(QoSPriorityTable[nQoSPriority_Size].Data.QP_TABLE.
		       sQP_PORT_DST_END, pQP_PORT_DST_END);
	} else {
		strcpy(QoSPriorityTable[nQoSPriority_Size].Data.QP_TABLE.
		       sQP_PORT_DST_END,
		       QoSPriorityTable[nQoSPriority_Size].Data.QP_TABLE.
		       sQP_PORT_DST_START);
	}

	strcpy(QoSPriorityTable[nQoSPriority_Size].Data.QP_TABLE.sQP_IF,
	       pQP_IF);
	strcpy(QoSPriorityTable[nQoSPriority_Size].Data.QP_TABLE.sQP_DIR,
	       pQP_DIR);
	strcpy(QoSPriorityTable[nQoSPriority_Size].Data.QP_TABLE.sQP_TYPE,
	       pQP_TYPE);

	// copy priority
	strcpy(QoSPriorityTable[nQoSPriority_Size].Data.QP_TABLE.sQP_PROTO,
	       pQP_PROTO);
	nQoSPriority_Size++;
	// //////// Update Table to File ///////////////
	websUpdate_QoSPriorityTable2File(nQoSPriority_Size, QoSPriorityTable);

	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}

	system(SERVICE_QOS_PRIORITY_RESTART);
	websNextPage(wp);
}
#endif				// CONFIG_FEATURE_QOS_PRIORITY_QUEUE
// 000001:tc.chen end

//#endif //CONFIG_FEATURE_DIFFSERV
#endif				// CONFIG_FEATURE_QOS

#ifdef CONFIG_FEATURE_IFX_IPQOS
void ifx_set_qos_main(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pCheck, *pCheck_up, *pCheck_dw, *pCheck_8021p, *pDefDSCP, *pDefQueue, *queueMode, *phyPortRate, *phyPortRate_ds,
	    *upstreamPortRate, *downstreamPortRate, *tcpPrio, *class_accel_mgr;
	uint32 flags = IFX_F_DEFAULT;
	int32 ret = IFX_SUCCESS;
	// char_t sValue[MAX_FILENAME_LEN];
	// int count = 0,i = 0;
	WAN_PHY_CFG pstWanPhy;
	// IFX_MAPI_QoS_Queue *queues = NULL;
	IFX_MAPI_QoS_QM qos_qm;

	a_assert(wp);

	memset(&qos_qm, 0x00, sizeof(qos_qm));
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));

	ifx_get_wan_phy_cfg(&pstWanPhy);
	/* Get value from ASP file */
	pCheck = ifx_httpdGetVar(wp, T("QoSStatus"), T(""));
	pCheck_up = ifx_httpdGetVar(wp, T("UPQoSStatus"), T(""));
	pCheck_dw = ifx_httpdGetVar(wp, T("DWQoSStatus"), T(""));
	pCheck_8021p = ifx_httpdGetVar(wp, T("8021PStatus"), T(""));
	pDefDSCP = ifx_httpdGetVar(wp, T("defDscpMark"), T(""));
	pDefQueue = ifx_httpdGetVar(wp, T("defQueue"), T(""));
	queueMode = ifx_httpdGetVar(wp, T("queue_mode"), T(""));
	phyPortRate = ifx_httpdGetVar(wp, T("phy_port_rate"), T(""));
	phyPortRate_ds = ifx_httpdGetVar(wp, T("phy_port_rate_ds"), T(""));
	upstreamPortRate = ifx_httpdGetVar(wp, T("upstream_port_rate"), T(""));
	downstreamPortRate = ifx_httpdGetVar(wp, T("downstream_port_rate"), T(""));
	tcpPrio = ifx_httpdGetVar(wp, T("tcp_prio"), T(""));
	class_accel_mgr = ifx_httpdGetVar(wp, T("class_session_mngr"), T(""));
	if (ifx_mapi_get_qos_qm(&qos_qm, IFX_F_DEFAULT) != IFX_SUCCESS) {
		COPY_TO_STATUS("%s",
			       "<span class=\"textTitle\">Error:QoS Configuration failed.</span>");
		ifx_httpdRedirect(wp, "err_page.html");
		return;
	}

	qos_qm.atmQMode = 1;
	qos_qm.enable = atoi(pCheck);
	qos_qm.USenable = atoi(pCheck_up);
	qos_qm.DSenable = atoi(pCheck_dw);
	qos_qm.P8021enable = atoi(pCheck_8021p);
	qos_qm.defaultDSCP = atoi(pDefDSCP);
	qos_qm.defaultQ = atoi(pDefQueue);

	if ((pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2)
	    && (pstWanPhy.wan_tc == WAN_TC_ATM)) {
		qos_qm.atmQMode = atoi(queueMode);
	}
	qos_qm.portRateLimitEnable = atoi(phyPortRate);
	qos_qm.DSportRateLimitEnable = atoi(phyPortRate_ds);
	qos_qm.upstreamPortRateLimit = atoi(upstreamPortRate);
	qos_qm.downstreamPortRateLimit = atoi(downstreamPortRate);
	qos_qm.tcpackprio = atoi(tcpPrio);
	qos_qm.class_accel_mngr = atoi(class_accel_mgr);

	qos_qm.iid.cpeId.Id = 1;
	qos_qm.iid.pcpeId.Id = 1;
	sprintf(qos_qm.iid.cpeId.secName, "%s", TAG_IPQOS_QM);
	sprintf(qos_qm.iid.pcpeId.secName, "%s", TAG_IGD);	// TODO
	qos_qm.iid.config_owner = IFX_WEB;

	IFX_DBG("[%s:%d] qIf=%s ", __FUNCTION__, __LINE__, qos_qm.qIf);
	flags = IFX_F_MODIFY;
	ret = ifx_mapi_set_qos_qm(IFX_OP_MOD, &qos_qm, flags);
	if (ret != IFX_SUCCESS) {
		switch (ret) {
		case IFX_ACL_CHECK_FAILED:
			COPY_TO_STATUS("%s",
				       "<span class=\"textTitle\">Error:ACL Check Failed for Modify.</span>");
			break;
		case -300:
			COPY_TO_STATUS("%s",
				       "<span class=\"textTitle\">Error:QoS Rate Validation Failed. Disabling QoS.</span>");
			break;
		case -200:
			COPY_TO_STATUS("%s",
				       "<span class=\"textTitle\">Error:QoS Rate Validation Failed.</span>");
			break;
		case -10:
			COPY_TO_STATUS("%s",
				       "<span class=\"textTitle\">Error:QoS Port Rate > Link Rate.</span>");
			break;
		case -20:
			COPY_TO_STATUS("%s",
				       "<span class=\"textTitle\">Error:QoS Peak Rate > Port Rate.</span>");
			break;
		case -30:
			COPY_TO_STATUS("%s",
				       "<span class=\"textTitle\">Error:QoS Peak Rate < Commit Rate.</span>");
			break;
		case -40:
			COPY_TO_STATUS("%s",
				       "<span class=\"textTitle\">Error:QoS Sum of Commit Rates > Port Rate.</span>");
			break;
		case -50:
			COPY_TO_STATUS("%s",
				       "<span class=\"textTitle\">Error:QoS Sum of PeakRates > 3 times Link Rate.</span>");
			break;
		default:
			COPY_TO_STATUS("%s",
				       "<span class=\"textTitle\">Error:QoS Configuration failed.</span>");
			break;
		}
		ifx_httpdRedirect(wp, "err_page.html");
		return;
	}
      IFX_Handler:
	websNextPage(wp);
}

void ifx_set_qos_queue_config(httpd_t wp, char_t * path, char_t * query)
{
	char_t *qAction, *pQCpeid, *pQName, *pQIf, *pQPrio, *pRedThreshold,
	    *pRedPercent, *QWt, *ShaperEnable, *CommitRate, *PeakRate,
	    *EgressPVC;
	char_t *pDropAlgo, *pSchedAlgo, *pCheck, sCpeid[11], port_rate[10] =
	    { 0 }, down_port_rate[10] = { 0 };

	int32 operation = IFX_OP_ADD, ret = IFX_SUCCESS, qPrevState =
	    IFX_DISABLED;
	uint32 flags = IFX_F_DEFAULT;
	uint32 outFlag = IFX_F_DEFAULT;

	IFX_MAPI_QoS_QM qos_qm;
	IFX_MAPI_QoS_Queue queue;
	IFX_MAPI_QoS_Capability qos_capab;
	WAN_PHY_CFG pstWanPhy;
	memset(&qos_qm, 0x00, sizeof(qos_qm));

	qAction = ifx_httpdGetVar(wp, T("qosAction"), T(""));
	pQCpeid = ifx_httpdGetVar(wp, T("qosCpeid"), T(""));
	pQName = ifx_httpdGetVar(wp, T("QOS_QUEUE_NAME_ADD"), T(""));
	pQIf = ifx_httpdGetVar(wp, T("QOS_QUEUE_INTERFACE"), T(""));
	pQPrio = ifx_httpdGetVar(wp, T("QOS_PRECEDENCE_ADD"), T(""));
	pRedThreshold = ifx_httpdGetVar(wp, T("QOS_RED_THRESHOLD_ADD"), T(""));
	pRedPercent = ifx_httpdGetVar(wp, T("QOS_RED_PERCENTAGE_ADD"), T(""));
	pDropAlgo = ifx_httpdGetVar(wp, T("QOS_DROP_ALGO_ADD"), T(""));
	pSchedAlgo = ifx_httpdGetVar(wp, T("QOS_SCHED_ALGO_ADD"), T(""));
	pCheck = ifx_httpdGetVar(wp, T("QOS_QUEUE_ADD_ENA"), T(""));
	QWt = ifx_httpdGetVar(wp, T("QOS_QUEUE_WEIGHT_ADD"), T(""));
	ShaperEnable = ifx_httpdGetVar(wp, T("QOS_QUEUE_SHAPING_ENA"), T(""));
	CommitRate = ifx_httpdGetVar(wp, T("QOS_QUEUE_COMM_SHAPE_RATE"), T(""));
	PeakRate = ifx_httpdGetVar(wp, T("QOS_QUEUE_PEAK_SHAPE_RATE"), T(""));
	EgressPVC = ifx_httpdGetVar(wp, T("wanif"), T(""));

	/* Currently this param configuration not supported pQWt =
	   ifx_httpdGetVar(wp, T("qwt"), T("")); */
	IFX_MAPI_QoS_Interface_Type ifType;
	ifType = ifx_mapi_get_active_qos_iface();

	ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_upPortRateLim",
		       IFX_F_DEFAULT, &outFlag, port_rate);
	ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_downPortRateLim",
		       IFX_F_DEFAULT, &outFlag, down_port_rate);

	IFX_DBG
	    ("[%s:%d] qAction=%s pQCpeid=%s pQName=%s pQIf=%s pQPrio=%s pRedThreshold=%s pRedPercent=%s pDropAlgo=%s pSchedAlgo=%s pCheck=%s ShaperEnable=%s",
	     __FUNCTION__, __LINE__, qAction, pQCpeid, pQName, pQIf, pQPrio,
	     pRedThreshold, pRedPercent, pDropAlgo, pSchedAlgo, pCheck,
	     ShaperEnable);
	ifx_get_wan_phy_cfg(&pstWanPhy);

	IFX_DBG("[%s:%d] ifType=%d ", __FUNCTION__, __LINE__, ifType);
	memset(&queue, 0x00, sizeof(queue));
	memset(&qos_capab, 0x00, sizeof(qos_capab));

	if (!(gstrcmp(qAction, "Add_US_Queue"))) {
		strcpy(qosOperation, qAction);
		ifx_httpdRedirect(wp, "qos_us_queue_config.asp");
		return;
	}
	else if (!(gstrcmp(qAction, "Add_DS_Queue"))) {
		strcpy(qosOperation, qAction);
		ifx_httpdRedirect(wp, "qos_ds_queue_config.asp");
		return;
	}
	else if (!(gstrcmp(qAction, "Modify_US_Queue"))) {
		strcpy(qosOperation, qAction);
		strcpy(qoscpeId, pQCpeid);
		ifx_httpdRedirect(wp, "qos_us_queue_config.asp");
		return;
	} 
	else if (!(gstrcmp(qAction, "Modify_DS_Queue"))) {
		strcpy(qosOperation, qAction);
		strcpy(qoscpeId, pQCpeid);
		ifx_httpdRedirect(wp, "qos_ds_queue_config.asp");
		return;
	} else if (!gstrcmp(qAction, "Delete")) {
		operation = IFX_OP_DEL;
		flags = IFX_F_DELETE;
	} else if (!gstrcmp(qAction, "Modify")) {
		operation = IFX_OP_MOD;
		flags = IFX_F_MODIFY;
	} else if (!gstrcmp(qAction, "Add")) {
		operation = IFX_OP_ADD;
		flags = IFX_F_DEFAULT;
	}
	
	if (operation == IFX_OP_ADD || operation == IFX_OP_MOD) 
	{

		if ( (!strcmp(pQIf, "LAN")) && (atoi(pQPrio) > 4))
		{
			COPY_TO_STATUS("%s",
				       "<span class=\"textTitle\">Error:Downstream Queue Precedence cannot be greater than 4.</span>");
			ifx_httpdRedirect(wp,
					  "err_page.html");
			return;
		}

		if (operation == IFX_OP_MOD) 
		{
			queue.iid.cpeId.Id = atoi(pQCpeid);
			if (ifx_mapi_get_qos_queue(&queue, IFX_F_DEFAULT) !=
			    IFX_SUCCESS) 
			{
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to read previous configuration of this classifier"));
				return;
			}
			flags = IFX_F_MODIFY;
		} 
		else if (operation == IFX_OP_ADD) 
		{
			/* Validation moved to WEB */
#if 0
			if (ifx_mapi_get_qos_capability
			    (&qos_capab, IFX_F_DEFAULT) != IFX_SUCCESS) 
			{
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to read previous configuration of this classifier"));
				return;
			}
			/* if(ifx_get_sec_instance_count(TAG_IPQOS_QUEUE, &q_count) !=
			   IFX_SUCCESS) { ifx_httpdError(wp, 400, T("Failed to read
			   previous configuration of this classifier")); return; } */
			q_count = ifx_mapi_get_queue_count_for_wan_mode(ifType);
			if (q_count ==
			    (qos_capab.maxInputQs + qos_capab.maxOutputQs)
			    || q_count >
			    (qos_capab.maxInputQs + qos_capab.maxOutputQs)) 
			{
				COPY_TO_STATUS(max_limit_err, "Queue", "Queue",
					       "Queue", "Queue");
				ifx_httpdRedirect(wp, "err_page.html");
				return;
			}
#endif
		}

		qPrevState = queue.enable;

		if (!gstrcmp(pCheck, "1")) 
		{
			queue.enable = IFX_ENABLED;
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		} 
		else 
		{
			queue.enable = IFX_DISABLED;
			/* Pass the Disable flags to hash out the entry in rc.conf */
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
			if (operation == IFX_OP_ADD)
				flags |= IFX_F_DONT_VALIDATE;
			else if (operation == IFX_OP_MOD)
				flags |= IFX_F_DONT_VALIDATE;
		}

		if (pQName != NULL && strlen(pQName))
			strcpy(queue.qName, pQName);
		/* Commenting pQIf will be LAN or WAN */
		/*
		if(pQIf != NULL && strlen(pQIf))
		    strcpy(queue.qIf, pQIf);
		IFX_DBG("[%s:%d] queue.qIf=%s", __FUNCTION__, __LINE__, pQIf);
		if(!gstrcmp(pQIf, "WAN"))
		strcpy(queue.qIf, pQIf);
		*/

		if (operation == IFX_OP_ADD) 
		{
			if (!(strcmp(pQIf, "LAN"))) 
			{
				switch(ifType) {
				case IFX_MAPI_QoS_WAN_ATM:
					queue.qIfType = IFX_MAPI_QoS_LAN_ATM;
					break;
				case IFX_MAPI_QoS_WAN_PTM:
					queue.qIfType = IFX_MAPI_QoS_LAN_PTM;
					break;
				case IFX_MAPI_QoS_WAN_ETH_0:
					queue.qIfType = IFX_MAPI_QoS_LAN_ETH_0;
					break;
				case IFX_MAPI_QoS_WAN_ETH_1:
					queue.qIfType = IFX_MAPI_QoS_LAN_ETH_1;
					break;
				default:
					break;
				}
				strcpy(queue.qIf, pQIf);
				ifx_GetObjData("/tmp/system_status", "qos_bk", "down_link_rate", IFX_F_GET_ENA, 0, port_rate);
			}

			if (!(strcmp(pQIf, "WAN"))) 
			{
				queue.qIfType = ifx_mapi_get_active_qos_iface();
				strcpy(queue.qIf, pQIf);
			}
		}

		if (pQPrio != NULL && strlen(pQPrio))
			queue.qPrio = atoi(pQPrio);

		/* Validate if Queue name is Unique*/	
		NULL_TERMINATE(sCpeid, 0x00, sizeof(sCpeid));

		ret =
		    ifx_check_unique_fvp_for_qos_iface(queue.qIfType,
							       "qName", pQName,
							       "cpeId", sCpeid,
							       IFX_F_GET_ANY);
		if (operation == IFX_OP_ADD) 
		{
			if (ret == IFX_SUCCESS && strlen(sCpeid)) 
			{
				IFX_DBG("[%s:%d] qName=%s cpeId=%s ",
					__FUNCTION__, __LINE__, pQName,
					sCpeid);
				COPY_TO_STATUS(q_name_err, "Name",
					       pQName, "Name");
				ifx_httpdRedirect(wp, "err_page.html");
				return;
			}
		} 
		else if (operation == IFX_OP_MOD) 
		{
			if (pQName)
				ret =
				    ifx_get_instance_count_from_dist_fvp_for_qos
				    (queue.qIfType, TAG_IPQOS_QUEUE,
				     PREFIX_IPQOS_QUEUE, "qName",
				     pQName, IFX_F_GET_ANY);
			else
				ret = IFX_FAILURE;
			
			if (ret == IFX_FAILURE) 
			{
				IFX_DBG("[%s:%d] qName=%s cpeId=%s ",
					__FUNCTION__, __LINE__, pQName,
					sCpeid);
				COPY_TO_STATUS(q_name_err, "Name",
					       pQName, "Name");
				ifx_httpdRedirect(wp, "err_page.html");
				return;
			} 
			else 
			{
				if (ret == 1) 
				{
					if (strlen(sCpeid)
					    && atoi(sCpeid) != 0) 
					{
						if (queue.iid.cpeId.
						    Id !=
						    atoi(sCpeid)) 
						{
							IFX_DBG
							    ("[%s:%d] qName=%s cpeId=%s ",
							     __FUNCTION__,
							     __LINE__,
							     pQName,
							     sCpeid);
							COPY_TO_STATUS
							    (q_name_err,
							     "Name",
							     pQName,
							     "Name");
							ifx_httpdRedirect
							    (wp,
							     "err_page.html");
							return;
						}
					}
				}
				if (ret > 1) 
				{
					IFX_DBG
					    ("[%s:%d] qName=%s cpeId=[%s:%d] ",
					     __FUNCTION__, __LINE__,
					     pQName, sCpeid,
					     queue.iid.cpeId.Id);
					COPY_TO_STATUS(q_name_err,
						       "Name", pQName,
						       "Name");
					ifx_httpdRedirect(wp,
							  "err_page.html");
					return;
				}
			}
		}
		/* End of Validation of Unique Queue Name */
		
		/* Validate uniqueness of queue precedence */
		if (queue.enable == IFX_ENABLED) 
		{
			NULL_TERMINATE(sCpeid, 0x00, sizeof(sCpeid));
			ret =
			    ifx_get_instance_count_from_dist_fvps_for_qos
			    (queue.qIfType, TAG_IPQOS_QUEUE,
			     PREFIX_IPQOS_QUEUE, "qPrio", pQPrio,
			     "enable", "1", IFX_F_GET_ANY);

			if (operation == IFX_OP_ADD) 
			{
				if (ret) 
				{
					COPY_TO_STATUS(q_name_err,
						       "Priority",
						       pQPrio,
						       "Priority");
					ifx_httpdRedirect(wp,
							  "err_page.html");
					return;
				}
			} 
			else if (operation == IFX_OP_MOD) 
			{

				if (pQPrio)
					ret =
					    ifx_get_instance_count_from_dist_fvps_for_qos
					    (queue.qIfType,
					     TAG_IPQOS_QUEUE,
					     PREFIX_IPQOS_QUEUE,
					     "qPrio", pQPrio, "enable",
					     "1", IFX_F_GET_ANY);
				else
					ret = IFX_FAILURE;
				if (ret == IFX_FAILURE) 
				{
					COPY_TO_STATUS(q_name_err,
						       "Priority",
						       pQPrio,
						       "Priority");
					ifx_httpdRedirect(wp,
							  "err_page.html");
					return;
				}

				if (ret == 1) 
				{
					NULL_TERMINATE(sCpeid, 0x00,
						       sizeof(sCpeid));
					ifx_get_fvp_from_another_fvps_for_qos
					    (queue.qIfType,
					     TAG_IPQOS_QUEUE,
					     PREFIX_IPQOS_QUEUE,
					     "qPrio", pQPrio, "enable",
					     "1", "cpeId", sCpeid,
					     IFX_F_GET_ANY);

					if (strlen(sCpeid)
					    && atoi(sCpeid) != 0) 
					{
						if (queue.iid.cpeId.
						    Id !=
						    atoi(sCpeid)) 
						{
							IFX_DBG
							    ("[%s:%d] Priority=%s sCpeid=%s ",
							     __FUNCTION__,
							     __LINE__,
							     pQPrio,
							     sCpeid);
							COPY_TO_STATUS
							    (q_name_err,
							     "Priority",
							     pQPrio,
							     "Priority");
							ifx_httpdRedirect
							    (wp,
							     "err_page.html");
							return;
						}
					}
				} 
				else if (ret > 1) 
				{
					IFX_DBG
					    ("[%s:%d] Priority=%s sCpeid=%s ",
					     __FUNCTION__, __LINE__,
					     pQPrio, sCpeid);
						COPY_TO_STATUS(q_name_err,
					       "Priority",
						       pQPrio,
						       "Priority");
					ifx_httpdRedirect(wp,
							  "err_page.html");
					return;
				}
				/* ret = 0; no queue found matching the priority, continue */
			}
			/* End of Validate uniqueness of queue precedence */
		}/* End of Queue Enable Condition*/ 
		else 
		{
			if (operation == IFX_OP_MOD) 
			{
				sprintf(sCpeid, "%d",
					queue.iid.cpeId.Id);
				if (qPrevState == IFX_ENABLED
				    && queue.enable == IFX_DISABLED) 
				{
					ret =
					    ifx_get_instance_count_from_dist_fvps
					    (TAG_IPQOS_CLASSIFY,
					     PREFIX_IPQOS_CLASSIFY,
					     "qId", sCpeid, "enable",
					     "1", IFX_F_GET_ANY);
					if (ret == IFX_FAILURE) 
					{
						COPY_TO_STATUS("%s",
							       "<span class=\"textTitle\">Error:Queue Modification failed.</span>");
						ifx_httpdRedirect(wp,
								  "err_page.html");
						return;
					} 
					else if (ret) 
					{
						COPY_TO_STATUS
						    (q_depend_err,
						     "active ",
						     "disable/delete",
						     "disabling");
						ifx_httpdRedirect(wp,
								  "err_page.html");
						return;
					}

					if (queue.iid.cpeId.Id ==
					    ifx_mapi_get_default_queue_cpeid
					    (queue.qIfType)) 
					{
						COPY_TO_STATUS("%s",
							       def_q_err);
						ifx_httpdRedirect(wp,
								  "err_page.html");
						return;
					}

					
				}
			}
		}/* End of Queue Enable Condition*/
		if (pRedThreshold != NULL && strlen(pRedThreshold))
			queue.redTh = atoi(pRedThreshold);

		if (pRedPercent != NULL && strlen(pRedPercent))
			queue.redPct = atoi(pRedPercent);

		if (QWt != NULL && strlen(QWt)) 
		{
			queue.qWt = atoi(QWt);
				queue.weightEnable = 1;
		} 
		else 
		{
			queue.weightEnable = 0;
		}
		
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		
		if (ShaperEnable != NULL && strlen(ShaperEnable))
			queue.shaperEnable = 1;
		else
			queue.shaperEnable = 0;
		
		if (CommitRate != NULL && strlen(CommitRate))
			queue.commitRate = atoi(CommitRate);
		
		if (ShaperEnable != NULL && strlen(ShaperEnable)) 
		{
			if (PeakRate != NULL && strlen(PeakRate))
				queue.peakRate = atoi(PeakRate);
			else
			{
				if(!(strcmp(pQIf, "WAN")))
					queue.peakRate = atoi(port_rate);
				if(!(strcmp(pQIf, "LAN")))
					queue.peakRate = atoi(down_port_rate);
			}
		}
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		
		if (EgressPVC != NULL && strlen(EgressPVC))
			gstrcpy(queue.egressPVC, EgressPVC);

		if (pSchedAlgo != NULL && strlen(pSchedAlgo)) 
		{
			IFX_DBG("[%s:%d] %s", __FUNCTION__, __LINE__,
				pSchedAlgo);
			if (!gstrcmp(pSchedAlgo, "SP"))
				queue.schedType = IFX_MAPI_QoS_Sched_SP;
			else if (!gstrcmp(pSchedAlgo, "WQ"))
				queue.schedType =
				    IFX_MAPI_QoS_Sched_WFQ;
		}
		if (pDropAlgo != NULL && strlen(pDropAlgo)) 
		{
			if (!gstrcmp(pDropAlgo, "DT"))
				queue.dropType = IFX_MAPI_QoS_Drop_DT;
			else if (!gstrcmp(pDropAlgo, "RED"))
				queue.dropType = IFX_MAPI_QoS_Drop_RED;
			else if (!gstrcmp(pDropAlgo, "NONE"))
				queue.dropType = IFX_MAPI_QoS_Drop_NONE;
			else if (!gstrcmp(pDropAlgo, "WRED"))
				queue.dropType = IFX_MAPI_QoS_Drop_WRED;
			else if (!gstrcmp(pDropAlgo, "BLUE"))
				queue.dropType = IFX_MAPI_QoS_Drop_BLUE;
		}
	}/* End of Operation = ADD | MOD */
	else if (operation == IFX_OP_DEL) 
	{
		queue.iid.cpeId.Id = atoi(pQCpeid);

#if 0
		if (ifx_mapi_get_qos_qm(&qos_qm, IFX_F_DEFAULT) != IFX_SUCCESS) 
		{
			ifx_httpdError(wp, 400, T("%s"),
			       "Failed to read previous configuration");
			return;
		}

		if (qos_qm.defaultQ == queue.iid.cpeId.Id) 
		{
			COPY_TO_STATUS("%s", def_q_err);
			ifx_httpdRedirect(wp, "err_page.html");
			return;
		}
#endif
		if (queue.iid.cpeId.Id ==
		    ifx_mapi_get_default_queue_cpeid(queue.qIfType)) 
		{
			COPY_TO_STATUS("%s", def_q_err);
			ifx_httpdRedirect(wp, "err_page.html");
			return;
		}

		if (ifx_mapi_get_qos_queue(&queue, IFX_F_GET_ANY) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 400, T("%s"),
				       "Failed to read previous configuration");
			return;
		}

		sprintf(sCpeid, "%d", queue.iid.cpeId.Id);
		
		if (!(gstrcmp(queue.qIf, "LAN"))) {
			ret =
			    ifx_get_instance_count_from_dist_fvp(TAG_IPQOS_DS_CLASSIFY,
								 PREFIX_IPQOS_DS_CLASSIFY,
								 "qId", sCpeid,
								 IFX_F_GET_ANY);
		}
	
		if (!(gstrcmp(queue.qIf, "WAN"))) {
			ret =
			    ifx_get_instance_count_from_dist_fvp(TAG_IPQOS_CLASSIFY,
							 PREFIX_IPQOS_CLASSIFY,
							 "qId", sCpeid,
							 IFX_F_GET_ANY);
		}

		if (ret == IFX_FAILURE) {
			
			COPY_TO_STATUS("%s",
			       "<span class=\"textTitle\">Error:Queue Deletion failed.</span>");
			ifx_httpdRedirect(wp, "err_page.html");
			return;
		} 
		else if (ret) 
		{
			COPY_TO_STATUS(q_depend_err, "", "delete", "deleting");
			ifx_httpdRedirect(wp, "err_page.html");
			return;
		}
	}

	sprintf(queue.iid.cpeId.secName, "%s", TAG_IPQOS_QUEUE);
	sprintf(queue.iid.pcpeId.secName, "%s", TAG_IPQOS_QM);	// TODO
	queue.iid.config_owner = IFX_WEB;
	queue.iid.pcpeId.Id = 1;
	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);

	ret = ifx_mapi_set_qos_queue(operation, &queue, flags);
	if (ret != IFX_SUCCESS) 
	{
		switch (ret) 
		{
			case -200:
				COPY_TO_STATUS("%s",
						       "<span class=\"textTitle\">Error:QoS Rate Validation Failed.</span>");
					break;
			case -10:
				COPY_TO_STATUS("%s",
					       "<span class=\"textTitle\">Error:QoS Port Rate > Link Rate.</span>");
				break;
			case -20:
				COPY_TO_STATUS("%s",
					       "<span class=\"textTitle\">Error:QoS Peak Rate > Port Rate.</span>");
				break;
			case -30:
				COPY_TO_STATUS("%s",
					       "<span class=\"textTitle\">Error:QoS Peak Rate < Commit Rate.</span>");
				break;
			case -40:
				COPY_TO_STATUS("%s",
					       "<span class=\"textTitle\">Error:QoS Sum of Commit Rates > Port Rate.</span>");
				break;
			case -50:
				COPY_TO_STATUS("%s",
					       "<span class=\"textTitle\">Error:QoS Sum of PeakRates > 3 times Link Rate.</span>");
				break;
			default:
				COPY_TO_STATUS("%s",
					       "<span class=\"textTitle\">Error:QoS Configuration failed.</span>");
				break;
		}
		ifx_httpdRedirect(wp, "err_page.html");
		return;
	}

	IFX_Handler:
	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	if (!(strcmp(pQIf, "WAN"))) {
		ifx_httpdRedirect(wp, T("qos_queue.asp"));
	}
	if (!(strcmp(pQIf, "LAN"))) {
		ifx_httpdRedirect(wp, T("qos_ds_queue.asp"));
	}

	return;
}

	void ifx_set_qos_class_config(httpd_t wp, char_t * path, char_t * query) 
	{
		char_t *qAction = ifx_httpdGetVar(wp, T("qosAction"), T(""));
		char_t *pClassName =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_NAME"), T(""));
		char_t *pOrder =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_ORDER"), T(""));
		char_t *pClassType =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_TYPE_ADD"), T(""));
		char_t *pQId =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_QUEUE_ADD"), T(""));
		char_t *pInDscp =
		    ifx_httpdGetVar(wp, T("QOS_IN_DSCP_ADD"), T(""));
		char_t *pOutDscp =
		    ifx_httpdGetVar(wp, T("QOS_OUT_DSCP_ADD"), T(""));
		char_t *pIngIface =
		    ifx_httpdGetVar(wp, T("QOS_IN_INTF_ADD"), T(""));
		char_t *pClassIface =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_INTF_ADD"), T(""));
		char_t *pSrcIP =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_SRC_IP_ADD"), T(""));
		char_t *pSrcMask =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_SRC_IP_MASK_ADD"), T(""));
		char_t *pSrcIPExcl =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_SRC_IP_EXCL"), T(""));
		char_t *pDstIP =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_DEST_IP_ADD"), T(""));
		char_t *pDstMask =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_DEST_IP_MASK_ADD"), T(""));
		char_t *pDstIPExcl =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_DEST_IP_EXCL"), T(""));
		char_t *pL3Proto =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_L3_PROTOCOL_ADD"), T(""));
		char_t *pL3ProtoExcl =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_L3_PROTO_EXCL"), T(""));
		char_t *pProto =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_L4_PROTOCOL_ADD"), T(""));
		char_t *pProtoExcl =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_L4_PROTO_EXCL"), T(""));
		char_t *pSrcPortStart =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_SRC_PORT_START_ADD"),
				    T(""));
		char_t *pSrcPortEnd =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_SRC_PORT_END_ADD"), T(""));
		char_t *pSrcPortExcl =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_SRC_PORT_EXCL"), T(""));
		char_t *pDstPortStart =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_DEST_PORT_START_ADD"),
				    T(""));
		char_t *pDstPortEnd =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_DEST_PORT_END_ADD"),
				    T(""));
		char_t *pDstPortExcl =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_DEST_PORT_EXCL"), T(""));
		char_t *pSrcMac =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_SRC_MAC_ADD"), T(""));
		char_t *pSrcMacExcl =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_SRC_MAC_EXCL"), T(""));
		char_t *pEnable =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_ENABLE"), T(""));
		char_t *pCpeid = ifx_httpdGetVar(wp, T("qosCpeid"), T(""));
		char_t *pIn802p =
		    ifx_httpdGetVar(wp, T("QOS_IN_802P_ADD"), T(""));
		char_t *pRCtrl =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_RATE_CONTROL_ENABLE"),
				    T(""));
		char_t *pRLmt =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_RATE_LIMIT"), T(""));
		/* 5.2 Additions */
		char_t *pDstMac = ifx_httpdGetVar(wp, T("QOS_CLASS_DEST_MAC_ADD"), T(""));
		char_t *pDstMacExcl = ifx_httpdGetVar(wp, T("QOS_CLASS_DEST_MAC_EXCL"), T(""));
		char_t *pDstMacMask = ifx_httpdGetVar(wp, T("QOS_CLASS_DEST_MAC_MASK_ADD"), T(""));
		char_t *pSrcMacMask = ifx_httpdGetVar(wp, T("QOS_CLASS_SRC_MAC_MASK_ADD"), T(""));
		char_t *pOut802p = ifx_httpdGetVar(wp, T("QOS_OUT_802P_ADD"), T(""));
		char_t *pVlanId = ifx_httpdGetVar(wp, T("QOS_CLASS_VLAN_ID"), T(""));
		char_t *pVlanExcl = ifx_httpdGetVar(wp, T("QOS_CLASS_VLAN_EXCL"), T(""));
		/* 5.3 Additions */
		char_t *Disable_Accel = ifx_httpdGetVar(wp, T("SESSION_ACCEL_DISABLE"), T(""));

		char_t sCpeid[10];
		char_t sEnable[10];
		char_t sqIf[10];
		char_t classifyType[10];
		int32 operation = IFX_OP_ADD, ret = IFX_SUCCESS;
		uint32 flags = IFX_F_DEFAULT, cl_count = 0, count = 0, i = 0;
		IFX_MAPI_QoS_Interface_Type qIfType;
		IFX_MAPI_QoS_Interface_Type wanqIfType;
		IFX_MAPI_QoS_Classifier qos_class;
		IFX_MAPI_QoS_Capability qos_capab;
		IFX_MAPI_QoS_Queue *queue = NULL;
		wanqIfType = IFX_MAPI_QoS_LAN_ETH;
		IFX_DBG("[%s:%d] ", __FUNCTION__, __LINE__);
		qIfType = ifx_mapi_get_active_qos_iface();

		memset(&qos_class, 0x00, sizeof(qos_class));
		memset(&qos_capab, 0x00, sizeof(qos_capab));
		memset(&queue, 0x00, sizeof(queue));


		if (!gstrcmp(qAction, "Delete")) {
			operation = IFX_OP_DEL;
			flags = IFX_F_DELETE;
		} else if (!gstrcmp(qAction, "Modify")) {
			operation = IFX_OP_MOD;
			flags = IFX_F_MODIFY;
		} else if (!gstrcmp(qAction, "Add")) {
			operation = IFX_OP_ADD;
			flags = IFX_F_DEFAULT;
		} 
		else if (!gstrcmp(qAction, "Add_US_Class")) {
			strcpy(qosOperation, qAction);
			ifx_httpdRedirect(wp, "qos_us_class_config.asp");
			return;
		} 
		else if (!gstrcmp(qAction, "Add_DS_Class")) {
			strcpy(qosOperation, qAction);
			ifx_httpdRedirect(wp, "qos_ds_class_config.asp");
			return;
		} 
		else if (!gstrcmp(qAction, "Modify_US_Class")) {
			strcpy(qosOperation, qAction);
			strcpy(qoscpeId, pCpeid);
			ifx_httpdRedirect(wp, "qos_us_class_config.asp");
			return;
		} 
		else if (!gstrcmp(qAction, "Modify_DS_Class")) {
			strcpy(qosOperation, qAction);
			strcpy(qoscpeId, pCpeid);
			ifx_httpdRedirect(wp, "qos_ds_class_config.asp");
			return;
		} 
		else if (!gstrcmp(qAction, "View")) {
			strcpy(qosOperation, qAction);
			strcpy(qoscpeId, pCpeid);
			ifx_httpdRedirect(wp, "qos_class_view.asp");
			return;
		}

		if (operation == IFX_OP_ADD || operation == IFX_OP_MOD) 
		{
			if (operation == IFX_OP_MOD) 
			{
				qos_class.iid.cpeId.Id = atoi(pCpeid);
				if (ifx_mapi_get_qos_classifier
				    (&qos_class,
				     IFX_F_DEFAULT) != IFX_SUCCESS) 
				{
					ifx_httpdError(wp, 400,
						       T
						       ("Failed to read previous configuration of this classifier"));
					return;
				}
				flags = IFX_F_MODIFY;
			} 
			else if (operation == IFX_OP_ADD) 
			{
				if (ifx_mapi_get_qos_capability
				    (&qos_capab,
				     IFX_F_DEFAULT) != IFX_SUCCESS) 
				{
					ifx_httpdError(wp, 400,
						       T
						       ("Failed to read previous configuration of this classifier"));
					return;
				}
				cl_count =
				    ifx_mapi_get_classifier_count_for_wan_mode
				    (qIfType);
				if (cl_count == qos_capab.maxClassifiers) 
				{
					COPY_TO_STATUS(max_limit_err,
						       "Classifier",
						       "Classifier",
						       "Classifier",
						       "Classifier");
					ifx_httpdRedirect(wp, "err_page.html");
					return;
				}
			}

			/*Handling for Acceleration */
			IFX_DBG("[%s:%d] \n ", __FUNCTION__, __LINE__);
			if (!gstrcmp(Disable_Accel, "1")) {
				qos_class.disableAccel = IFX_ENABLED;
				printf("[%s:%d],disableAccel=%d \n", __FUNCTION__, __LINE__,qos_class.disableAccel);
			}
			 else {
				qos_class.disableAccel = IFX_DISABLED;
				printf("[%s:%d],disableAccel=%d \n", __FUNCTION__, __LINE__,qos_class.disableAccel);
				flags |= IFX_F_DONT_VALIDATE;
			}


			qos_class.qId = atoi(pQId);

			IFX_DBG("[%s:%d] ", __FUNCTION__, __LINE__);
			if (!gstrcmp(pEnable, "1")) {
				qos_class.enable = IFX_ENABLED;
				/* check if associated queue is enabled, if not fail */
				ret =
				    ifx_get_another_fvp_from_dist_fvp
				    (TAG_IPQOS_QUEUE, "cpeId", pQId, "enable",
				     sEnable, IFX_F_GET_ANY);
				if ((ret != IFX_SUCCESS) || (!atoi(sEnable))) 
				{
					COPY_TO_STATUS(qcl_depend_err, pQId);
					ifx_httpdRedirect(wp, "err_page.html");
					return;
				}
			} 
			else 
			{
				qos_class.enable = IFX_DISABLED;
				flags |= IFX_F_DONT_VALIDATE;
			}

			IFX_DBG("[%s:%d] ", __FUNCTION__, __LINE__);
			if (pOrder != NULL && strlen(pOrder)) 
			{
				IFX_DBG("[%s:%d] ", __FUNCTION__, __LINE__);
				if (!gstrcmp(pOrder, "-1")) 
				{
					IFX_DBG("[%s:%d] ", __FUNCTION__,
						__LINE__);
					/* if the user has given order as -1 (last), then we need
					   to get the order from (sec_count + 1) */
					/* 
					   if(ifx_get_sec_instance_count(TAG_IPQOS_CLASSIFY,
					   &qos_class.order) != IFX_SUCCESS) { ifx_httpdError(wp,
					   400, T("Failed to get Classifier configuration"));
					   return; } */
					if((operation == IFX_OP_ADD) || (operation == IFX_OP_MOD))
					{
						ret =
				    			ifx_get_another_fvp_from_dist_fvp
				    			(TAG_IPQOS_QUEUE, "cpeId", pQId, "qIf",
				     			sqIf, IFX_F_GET_ANY);
						if(!gstrcmp(sqIf, "LAN"))
						{
							switch(qIfType)
							{
								case IFX_MAPI_QoS_WAN_ATM:
									wanqIfType = IFX_MAPI_QoS_LAN_ATM;
								break;
								case IFX_MAPI_QoS_WAN_PTM:
									wanqIfType = IFX_MAPI_QoS_LAN_PTM;
								break;
								case IFX_MAPI_QoS_WAN_ETH_0:
									wanqIfType = IFX_MAPI_QoS_LAN_ETH_0;
								break;
								case IFX_MAPI_QoS_WAN_ETH_1:
									wanqIfType = IFX_MAPI_QoS_LAN_ETH_1;
								break;
								default:
								break;
							}
							qos_class.order =
					    			(ifx_mapi_get_classifier_mfc_count_for_wan_mode
					    			(wanqIfType));
						}
						if(!gstrcmp(sqIf, "WAN"))
						{
							qos_class.order =
					    			(ifx_mapi_get_classifier_mfc_count_for_wan_mode
					    			(qIfType));
					
						}	
					}
					if (operation == IFX_OP_MOD) 
					{
						ret =
						    ifx_get_another_fvp_from_dist_fvp
						    (TAG_IPQOS_CLASSIFY,
						     "cpeId", pCpeid, "type",
						     classifyType,
						     IFX_F_GET_ANY);

						IFX_DBG
						    ("[%s:%d] cpeid=%s type=%s operation=%d order=%d",
						     __FUNCTION__, __LINE__,
						     pCpeid, classifyType,
						     operation,
						     qos_class.order);
					}
					IFX_DBG("[%s:%d] operation=%d order=%d",
						__FUNCTION__, __LINE__,
						operation, qos_class.order);
					if (operation == IFX_OP_ADD
					    || ((operation == IFX_OP_MOD)
						&& (atoi(classifyType) !=
						    IFX_MAPI_QoS_Multi_Field)))
					{
						IFX_DBG("[%s:%d] ",
							__FUNCTION__, __LINE__);
						qos_class.order =
						    qos_class.order + 1;
						IFX_DBG("[%s:%d] order = %d",
							__FUNCTION__, __LINE__,
							qos_class.order);
					}
				} 
				else 
				{
					IFX_DBG("[%s:%d] ", __FUNCTION__,
						__LINE__);
					qos_class.order = atoi(pOrder);
				}
			}/* End of order loop */

			IFX_DBG("[%s:%d] order = %d", __FUNCTION__, __LINE__,
				qos_class.order);
			if (pClassName != NULL && strlen(pClassName))
				sprintf(qos_class.classifierName, "%s",
					pClassName);

			/* Validate uniqueness of classifier name */
#if 1
			NULL_TERMINATE(sCpeid, 0x00, sizeof(sCpeid));
			ret =
			    ifx_check_unique_fvp_for_qos_class(qIfType,
							       "className",
							       qos_class.
							       classifierName,
							       "cpeId", sCpeid,
							       IFX_F_GET_ANY);
			if (operation == IFX_OP_ADD) 
			{
				if (ret == IFX_SUCCESS && strlen(sCpeid)
				    && qIfType ==
				    ifx_mapi_get_class_iface(sCpeid)) 
				{
					COPY_TO_STATUS(class_name_err, "Name",
						       qos_class.classifierName,
						       "Name");
					ifx_httpdRedirect(wp, "err_page.html");
					return;
				}
			} 
			else if (operation == IFX_OP_MOD) 
			{
#if 1
				ret =
				    ifx_get_instance_count_from_dist_fvp_for_class
				    (qIfType, TAG_IPQOS_CLASSIFY,
				     PREFIX_IPQOS_CLASSIFY, "className",
				     qos_class.classifierName, IFX_F_GET_ANY);
				IFX_DBG("count with name [%s] is [%d",
					qos_class.classifierName, ret);
				IFX_DBG("cpeids [%d:%d]",
					qos_class.iid.cpeId.Id, atoi(sCpeid));
				if (ret == IFX_FAILURE) 
				{
					COPY_TO_STATUS(class_name_err, "Name",
						       qos_class.classifierName,
						       "Name");
					ifx_httpdRedirect(wp, "err_page.html");
					return;
				} 
				else 
				{
					if (ret == 1) 
					{
						if (qos_class.iid.cpeId.Id !=
						    atoi(sCpeid)) 
						{
							COPY_TO_STATUS
							    (class_name_err,
							     "Name",
							     qos_class.
							     classifierName,
							     "Name");
							ifx_httpdRedirect(wp,
									  "err_page.html");
							return;
						}
					}
					if (ret > 1) {
						COPY_TO_STATUS(class_name_err,
							       "Name",
							       qos_class.
							       classifierName,
							       "Name");
						ifx_httpdRedirect(wp,
								  "err_page.html");
						return;
					}
				}
#endif
			}
#endif			/* End of Validation of Unique Upstream Classifier NAME */

			qos_class.IngIf = -1;
			if (pClassIface != NULL && strlen(pClassIface)) 
			{
				if (!strcmp(pClassIface, "LOCAL"))
					qos_class.classIf = IFX_MAPI_QoS_LOCAL;
				else if (!strcmp(pClassIface, "LAN"))
					qos_class.classIf =
					    IFX_MAPI_QoS_LAN_ALL;
				else if (!strcmp(pClassIface, "LOCAL+LAN"))
					qos_class.classIf = IFX_MAPI_QoS_ALL;
				else if (!strcmp(pClassIface, "WAN"))
					qos_class.classIf =
					    IFX_MAPI_QoS_WAN;
				else if (!strcmp(pClassIface, "LOCAL+WAN"))
					qos_class.classIf =
					    IFX_MAPI_QoS_WAN_ALL;
			}
			if (pIngIface != NULL && strlen(pIngIface)) {
				if (!strcmp(pIngIface, "LAN"))
					qos_class.IngIf = IFX_MAPI_QoS_LAN_ALL;
				else if (!strcmp(pIngIface, "WAN"))
					qos_class.IngIf = IFX_MAPI_QoS_WAN_ALL;
				else if (!strcmp(pIngIface, "WLAN"))
					qos_class.IngIf = IFX_MAPI_QoS_LAN_WIFI;
				else
					qos_class.IngIf = -1;
			}

			/* 5.2 Additions */
			qos_class.dscpCheck = -1;
			qos_class.pBitsCheck = -1;
			qos_class.vlanCheck = -1;
			qos_class.vlanExcl = IFX_DISABLED;
			qos_class.dscpMark = -1;
			qos_class.pBitsMark = -1;
			sprintf(qos_class.dstMac, "%s", "");
			qos_class.srcMacExcl = IFX_DISABLED;
			sprintf(qos_class.dstMacMask, "%s", "");
			sprintf(qos_class.srcMacMask, "%s", "");
			/*  End of 5.2 Additions */

			/* fill default values for remaining fields */
			qos_class.rateCtrlEnbl = IFX_DISABLED;
			qos_class.rateLmt = -1;
			qos_class.protoNum = -1;
			qos_class.protoExcl = IFX_DISABLED;
			qos_class.srcPortRange.start_port =
			    qos_class.srcPortRange.end_port = -1;
			qos_class.srcPortExcl = IFX_DISABLED;
			qos_class.dstPortRange.start_port =
			    qos_class.dstPortRange.end_port = -1;
			qos_class.dstPortExcl = IFX_DISABLED;
			sprintf(qos_class.srcIP.ip, "%s", "");
			sprintf(qos_class.srcIP.mask, "%s", "");
			qos_class.srcIPExcl = IFX_DISABLED;
			sprintf(qos_class.dstIP.ip, "%s", "");
			sprintf(qos_class.dstIP.mask, "%s", "");
			qos_class.dstIPExcl = IFX_DISABLED;
			sprintf(qos_class.srcMac, "%s", "");
			qos_class.srcMacExcl = IFX_DISABLED;

			if (ifx_mapi_get_all_qos_queue_if_specific
			    (qIfType, &count, &queue,
			     IFX_F_DEFAULT) != IFX_SUCCESS) {
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to read previous configuration of this classifier"));
				return;
			}

			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
			if (!gstrcmp(pRCtrl, "1"))
				qos_class.rateCtrlEnbl = IFX_ENABLED;
			else
				qos_class.rateCtrlEnbl = IFX_DISABLED;
			/* Value of classifier based rate limiting */
			if (strlen(pRLmt) && atoi(pRLmt) >= 0)
				qos_class.rateLmt = atoi(pRLmt);
			else
				qos_class.rateLmt = -1;
			for (i = 0; i < count; i++) {
				if (atoi(pQId) == (queue + i)->iid.cpeId.Id) {
					if ((!gstrcmp(pRCtrl, "1")
					     && strlen(pRLmt))
					    && ((atoi(pRLmt) < 0)
						|| (atoi(pRLmt) >
						    (queue + i)->peakRate))) {
						COPY_TO_STATUS("%s",
							       "<span class=\"textTitle\">Invalid Rate Limit Value</span>");
						ifx_httpdRedirect(wp,
								  "err_page.html");
						return;
					}
				}
			}

			if (!gstrcmp(pClassType, "DSCP")) {
				qos_class.mfClass = IFX_MAPI_QoS_DSCP;
				if (pInDscp != NULL && strlen(pInDscp))
					qos_class.dscpCheck = atoi(pInDscp);
				if (pOutDscp != NULL && strlen(pOutDscp))
					qos_class.dscpMark = atoi(pOutDscp);
				qos_class.pBitsCheck = -1;
				qos_class.pBitsMark = -1;
			} else if (!gstrcmp(pClassType, "802.1P")) {
				qos_class.mfClass = IFX_MAPI_QoS_P_Bits;
				qos_class.dscpCheck = -1;
				qos_class.dscpMark = -1;
				if (pIn802p != NULL && strlen(pIn802p))
					qos_class.pBitsCheck = atoi(pIn802p);
				if (pOut802p != NULL && strlen(pOut802p))
					qos_class.pBitsMark = atoi(pOut802p);
			} else if (!gstrcmp(pClassType, "MFC")) {
				qos_class.mfClass = IFX_MAPI_QoS_Multi_Field;
				// qos_class.dscpCheck = -1;
				// qos_class.pBitsCheck = -1;
				qos_class.dscpCheck = atoi(pInDscp);
				/* Manamohan,Klocwork updates 7,March 2012 */
				if(pIn802p != NULL)
					qos_class.pBitsCheck = atoi(pIn802p);
				if (pSrcIP != NULL && strlen(pSrcIP))
					sprintf(qos_class.srcIP.ip, "%s",
						pSrcIP);

				if (pSrcMask != NULL && strlen(pSrcMask))
					sprintf(qos_class.srcIP.mask, "%s",
						pSrcMask);
				if (pSrcIPExcl != NULL && strlen(pSrcIPExcl)) {
					if (!gstrcmp(pSrcIPExcl, "1"))
						qos_class.srcIPExcl =
						    IFX_ENABLED;
					else
						qos_class.srcIPExcl =
						    IFX_DISABLED;
				}

				if (pDstIP != NULL && strlen(pDstIP))
					sprintf(qos_class.dstIP.ip, "%s",
						pDstIP);

				if (pDstMask != NULL && strlen(pDstMask))
					sprintf(qos_class.dstIP.mask, "%s",
						pDstMask);

				if (pDstIPExcl != NULL && strlen(pDstIPExcl)) {
					if (!gstrcmp(pDstIPExcl, "1"))
						qos_class.dstIPExcl =
						    IFX_ENABLED;
					else
						qos_class.dstIPExcl =
						    IFX_DISABLED;
				}

				if (pProto != NULL && strlen(pProto)) {
					if (!gstrcmp(pProto, "ICMP"))
						qos_class.protoNum = 1;
					else if (!gstrcmp(pProto, "UDP"))
						qos_class.protoNum = 17;
					else if (!gstrcmp(pProto, "TCP"))
						qos_class.protoNum = 6;
				}

				if (pProtoExcl != NULL && strlen(pProtoExcl)) {
					/* TODO */
					/* if(!gstrcmp(pProtoExcl. "1")) */
					if (!gstrcmp(pProtoExcl, "1"))
						qos_class.protoExcl =
						    IFX_ENABLED;
					else
						qos_class.protoExcl =
						    IFX_DISABLED;
				}
				
				if (pL3Proto != NULL && strlen(pL3Proto)) {
					if (!gstrcmp(pL3Proto, "IPv4"))
						qos_class.L3protoNum = 1;
					else if (!gstrcmp(pL3Proto, "IPv6"))
						qos_class.L3protoNum = 2;
				}

				if (pL3ProtoExcl != NULL && strlen(pL3ProtoExcl)) {
					if (!gstrcmp(pL3ProtoExcl, "1"))
						qos_class.L3protoExcl =
						    IFX_ENABLED;
					else
						qos_class.L3protoExcl =
						    IFX_DISABLED;
				}

				if (pSrcPortStart != NULL
				    && strlen(pSrcPortStart))
					qos_class.srcPortRange.start_port =
					    atoi(pSrcPortStart);

				if (pSrcPortEnd != NULL && strlen(pSrcPortEnd))
					qos_class.srcPortRange.end_port =
					    atoi(pSrcPortEnd);

				if (pSrcPortExcl != NULL
				    && strlen(pSrcPortExcl)) {
					if (!gstrcmp(pSrcPortExcl, "1"))
						qos_class.srcPortExcl =
						    IFX_ENABLED;
					else
						qos_class.srcPortExcl =
						    IFX_DISABLED;
				}

				if (pDstPortStart != NULL
				    && strlen(pDstPortStart))
					qos_class.dstPortRange.start_port =
					    atoi(pDstPortStart);

				if (pDstPortEnd != NULL && strlen(pDstPortEnd))
					qos_class.dstPortRange.end_port =
					    atoi(pDstPortEnd);

				if (pDstPortExcl != NULL
				    && strlen(pDstPortExcl)) {
					if (!gstrcmp(pDstPortExcl, "1"))
						qos_class.dstPortExcl =
						    IFX_ENABLED;
					else
						qos_class.dstPortExcl =
						    IFX_DISABLED;
				}

				if (pSrcMac != NULL && strlen(pSrcMac))
					sprintf(qos_class.srcMac, "%s",
						pSrcMac);

				if (pSrcMacExcl != NULL && strlen(pSrcMacExcl)) {
					if (!gstrcmp(pSrcMacExcl, "1"))
						qos_class.srcMacExcl =
						    IFX_ENABLED;
					else
						qos_class.srcMacExcl =
						    IFX_DISABLED;
				}
				if (pSrcMacMask != NULL && strlen(pSrcMacMask))
					sprintf(qos_class.srcMacMask, "%s",
						pSrcMacMask);
				if (pDstMac != NULL && strlen(pDstMac))
					sprintf(qos_class.dstMac, "%s",
						pDstMac);
				if (pDstMacMask != NULL && strlen(pDstMacMask))
					sprintf(qos_class.dstMacMask, "%s",
						pDstMacMask);
				if (pDstMacExcl != NULL && strlen(pDstMacExcl)) {
					if (!gstrcmp(pDstMacExcl, "1"))
						qos_class.dstMacExcl =
						    IFX_ENABLED;
					else
						qos_class.dstMacExcl =
						    IFX_DISABLED;
				}
				if (pIn802p != NULL && strlen(pIn802p))
					qos_class.pBitsCheck = atoi(pIn802p);
				if (pVlanExcl != NULL && strlen(pVlanExcl)) {
					if (!gstrcmp(pVlanExcl, "1"))
						qos_class.vlanExcl =
						    IFX_ENABLED;
					else
						qos_class.vlanExcl =
						    IFX_DISABLED;
				}
				if (!qos_class.vlanExcl && pVlanId != NULL
				    && strlen(pVlanId))
					qos_class.vlanCheck = atoi(pVlanId);
				if (pOutDscp != NULL && strlen(pOutDscp))
					qos_class.dscpMark = atoi(pOutDscp);
				if (pOut802p != NULL && strlen(pOut802p))
					qos_class.pBitsMark = atoi(pOut802p);

			} else {
				ifx_httpdWrite(wp, T("Mode not supported"));
				return;
			}
		} else if (operation == IFX_OP_DEL) {
			qos_class.iid.cpeId.Id = atoi(pCpeid);

			if (ifx_mapi_get_qos_classifier
			    (&qos_class, IFX_F_GET_ANY) != IFX_SUCCESS) {
				ifx_httpdError(wp, 400, T("%s"),
					       "Failed to read previous configuration");
				return;
			}
		}

		sprintf(qos_class.iid.cpeId.secName, "%s", TAG_IPQOS_CLASSIFY);
		sprintf(qos_class.iid.pcpeId.secName, "%s", TAG_IPQOS_QM);	// TODO
		qos_class.iid.config_owner = IFX_WEB;
		qos_class.iid.pcpeId.Id = 1;

		if (ifx_mapi_set_qos_classifier(operation, &qos_class, flags) !=
		    IFX_SUCCESS) {
			COPY_TO_STATUS("%s",
				       "<span class=\"textTitle\">Classifier Configuration failed</span>");
			ifx_httpdRedirect(wp, "err_page.html");
			return;
		}

	      IFX_Handler:
		ifx_httpdRedirect(wp, T("qos_class.asp"));
	}
#endif				// CONFIG_FEATURE_IFX_IPQOS

#ifdef CONFIG_FEATURE_IFX_IPQOS

#define IFX_GET_QOS_DROP_TYPE_STR(dropType, pDrop) { \
                                                     switch(dropType) { \
                                                        case IFX_MAPI_QoS_Drop_DT: \
                                                                          pDrop = "DT"; \
                                                                          break; \
                                                        case IFX_MAPI_QoS_Drop_RED: \
                                                                          pDrop = "RED"; \
                                                                          break; \
                                                        case IFX_MAPI_QoS_Drop_NONE: \
                                                                          pDrop = "NONE"; \
                                                                          break; \
                                                        case IFX_MAPI_QoS_Drop_WRED: \
                                                                          pDrop = "WRED"; \
                                                                          break; \
                                                        case IFX_MAPI_QoS_Drop_BLUE: \
                                                                          pDrop = "BLUE"; \
                                                                          break; \
                                 } \
                           }

#define IFX_GET_QOS_SCHED_TYPE_STR(schedType, pSched) { \
                                                             switch(schedType) { \
                                                                case IFX_MAPI_QoS_Sched_SP: \
                                                                                  pSched = "SP"; \
                                                                                  break; \
                                                                case IFX_MAPI_QoS_Sched_WRR: \
                                                                                  pSched = "WRR"; \
                                                                                  break; \
                                                                case IFX_MAPI_QoS_Sched_WFQ: \
                                                                                  pSched = "WQ"; \
                                                                                  break; \
                                                                case IFX_MAPI_QoS_Sched_HTB: \
                                                                                  pSched = "HTB"; \
                                                                                  break; \
                                                             } \
                                           }

	CGI_ENUMSEL_S web_Enum_DSCP_Opt_List[] = {
		{-1, "-"}
		,
		{0x00, "CS0"}
		,
		{0x0e, "AF13"}
		,
		{0x0c, "AF12"}
		,
		{0x0a, "AF11"}
		,
		{0x08, "CS1"}
		,
		{0x16, "AF23"}
		,
		{0x14, "AF22"}
		,
		{0x12, "AF21"}
		,
		{0x10, "CS2"}
		,
		{0x1e, "AF33"}
		,
		{0x1c, "AF32"}
		,
		{0x1a, "AF31"}
		,
		{0x18, "CS3"}
		,
		{0x26, "AF43"}
		,
		{0x24, "AF42"}
		,
		{0x22, "AF41"}
		,
		{0x20, "CS4"}
		,
		{0x2e, "EF"}
		,
		{0x28, "CS5"}
		,
		{0x30, "CS6"}
		,
		{0x38, "CS7"}
	};

	
	void ifx_set_qos_ds_class_config(httpd_t wp, char_t * path, char_t * query) 
	{
		char_t *qAction = ifx_httpdGetVar(wp, T("qosAction"), T(""));
		char_t *pClassName =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_NAME"), T(""));
		char_t *pOrder =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_ORDER"), T(""));
		char_t *pClassType =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_TYPE_ADD"), T(""));
		char_t *pQId =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_QUEUE_ADD"), T(""));
		char_t *pInDscp =
		    ifx_httpdGetVar(wp, T("QOS_IN_DSCP_ADD"), T(""));
		char_t *pOutDscp =
		    ifx_httpdGetVar(wp, T("QOS_OUT_DSCP_ADD"), T(""));
		char_t *pIngIface =
		    ifx_httpdGetVar(wp, T("QOS_IN_INTF_ADD"), T(""));
		char_t *pClassIface =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_INTF_ADD"), T(""));
		char_t *pSrcIP =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_SRC_IP_ADD"), T(""));
		char_t *pSrcMask =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_SRC_IP_MASK_ADD"), T(""));
		char_t *pSrcIPExcl =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_SRC_IP_EXCL"), T(""));
		char_t *pDstIP =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_DEST_IP_ADD"), T(""));
		char_t *pDstMask =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_DEST_IP_MASK_ADD"), T(""));
		char_t *pDstIPExcl =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_DEST_IP_EXCL"), T(""));
		char_t *pL3Proto =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_L3_PROTOCOL_ADD"), T(""));
		char_t *pL3ProtoExcl =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_L3_PROTO_EXCL"), T(""));
		char_t *pProto =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_L4_PROTOCOL_ADD"), T(""));
		char_t *pProtoExcl =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_L4_PROTO_EXCL"), T(""));
		char_t *pSrcPortStart =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_SRC_PORT_START_ADD"),
				    T(""));
		char_t *pSrcPortEnd =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_SRC_PORT_END_ADD"), T(""));
		char_t *pSrcPortExcl =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_SRC_PORT_EXCL"), T(""));
		char_t *pDstPortStart =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_DEST_PORT_START_ADD"),
				    T(""));
		char_t *pDstPortEnd =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_DEST_PORT_END_ADD"),
				    T(""));
		char_t *pDstPortExcl =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_DEST_PORT_EXCL"), T(""));
		char_t *pSrcMac =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_SRC_MAC_ADD"), T(""));
		char_t *pSrcMacExcl =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_SRC_MAC_EXCL"), T(""));
		char_t *pEnable =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_ENABLE"), T(""));
		char_t *pCpeid = ifx_httpdGetVar(wp, T("qosCpeid"), T(""));
		char_t *pIn802p =
		    ifx_httpdGetVar(wp, T("QOS_IN_802P_ADD"), T(""));
		char_t *pRCtrl =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_RATE_CONTROL_ENABLE"),
				    T(""));
		char_t *pRLmt =
		    ifx_httpdGetVar(wp, T("QOS_CLASS_RATE_LIMIT"), T(""));
		/* 5.2 Additions */
		char_t *pDstMac = ifx_httpdGetVar(wp, T("QOS_CLASS_DEST_MAC_ADD"), T(""));
		char_t *pDstMacExcl = ifx_httpdGetVar(wp, T("QOS_CLASS_DEST_MAC_EXCL"), T(""));
		char_t *pDstMacMask = ifx_httpdGetVar(wp, T("QOS_CLASS_DEST_MAC_MASK_ADD"), T(""));
		char_t *pSrcMacMask = ifx_httpdGetVar(wp, T("QOS_CLASS_SRC_MAC_MASK_ADD"), T(""));
		char_t *pOut802p = ifx_httpdGetVar(wp, T("QOS_OUT_802P_ADD"), T(""));
		char_t *pVlanId = ifx_httpdGetVar(wp, T("QOS_CLASS_VLAN_ID"), T(""));
		char_t *pVlanExcl = ifx_httpdGetVar(wp, T("QOS_CLASS_VLAN_EXCL"), T(""));
		/* 5.3 Additions */
		char_t *Disable_Accel = ifx_httpdGetVar(wp, T("SESSION_ACCEL_DISABLE"), T(""));

		char_t sCpeid[10];
		char_t sEnable[10];
		char_t sqIf[10];
		char_t classifyType[10];
		int32 operation = IFX_OP_ADD, ret = IFX_SUCCESS;
		uint32 flags = IFX_F_DEFAULT, cl_count = 0, count = 0, i = 0;
		IFX_MAPI_QoS_Interface_Type qIfType;
		IFX_MAPI_QoS_Interface_Type wanqIfType;
		IFX_MAPI_QoS_Classifier qos_class;
		IFX_MAPI_QoS_Capability qos_capab;
		IFX_MAPI_QoS_Queue *queue = NULL;
		wanqIfType = IFX_MAPI_QoS_LAN_ETH;
		IFX_DBG("[%s:%d] ", __FUNCTION__, __LINE__);
		qIfType = ifx_mapi_get_active_qos_iface();

		memset(&qos_class, 0x00, sizeof(qos_class));
		memset(&qos_capab, 0x00, sizeof(qos_capab));
		memset(&queue, 0x00, sizeof(queue));

		if (!gstrcmp(qAction, "Delete")) {
			operation = IFX_OP_DEL;
			flags = IFX_F_DELETE;
		} else if (!gstrcmp(qAction, "Modify")) {
			operation = IFX_OP_MOD;
			flags = IFX_F_MODIFY;
		} else if (!gstrcmp(qAction, "Add")) {
			operation = IFX_OP_ADD;
			flags = IFX_F_DEFAULT;
		} 
		else if (!gstrcmp(qAction, "Add_US_Class")) {
			strcpy(qosOperation, qAction);
			ifx_httpdRedirect(wp, "qos_us_class_config.asp");
			return;
		} 
		else if (!gstrcmp(qAction, "Add_DS_Class")) {
			strcpy(qosOperation, qAction);
			ifx_httpdRedirect(wp, "qos_ds_class_config.asp");
			return;
		} 
		else if (!gstrcmp(qAction, "Modify_US_Class")) {
			strcpy(qosOperation, qAction);
			strcpy(qoscpeId, pCpeid);
			ifx_httpdRedirect(wp, "qos_us_class_config.asp");
			return;
		} 
		else if (!gstrcmp(qAction, "Modify_DS_Class")) {
			strcpy(qosOperation, qAction);
			strcpy(qoscpeId, pCpeid);
			ifx_httpdRedirect(wp, "qos_ds_class_config.asp");
			return;
		} 
		else if (!gstrcmp(qAction, "View")) {
			strcpy(qosOperation, qAction);
			strcpy(qoscpeId, pCpeid);
			ifx_httpdRedirect(wp, "qos_class_view.asp");
			return;
		}

		if (operation == IFX_OP_ADD || operation == IFX_OP_MOD) 
		{
			if (operation == IFX_OP_MOD) {
				qos_class.iid.cpeId.Id = atoi(pCpeid);
				if (ifx_mapi_get_qos_ds_classifier
				    (&qos_class,
				     IFX_F_DEFAULT) != IFX_SUCCESS) {
					ifx_httpdError(wp, 400,
						       T
						       ("Failed to read previous configuration of this classifier"));
					return;
				}
				flags = IFX_F_MODIFY;
			} else if (operation == IFX_OP_ADD) {
				if (ifx_mapi_get_qos_capability
				    (&qos_capab,
				     IFX_F_DEFAULT) != IFX_SUCCESS) {
					ifx_httpdError(wp, 400,
						       T
						       ("Failed to read previous configuration of this classifier"));
					return;
				}
				/* if(ifx_get_sec_instance_count(TAG_IPQOS_CLASSIFY, &cl_count) 
				   != IFX_SUCCESS) { ifx_httpdError(wp, 400, T("Failed to read
				   previous configuration of this classifier")); return; } */
				cl_count =
				    ifx_mapi_get_ds_classifier_count_for_wan_mode
				    (qIfType);
				if (cl_count == qos_capab.maxClassifiers) {
					COPY_TO_STATUS(max_limit_err,
						       "Classifier",
						       "Classifier",
						       "Classifier",
						       "Classifier");
					ifx_httpdRedirect(wp, "err_page.html");
					return;
				}
			}
			/*Handling for Acceleration */
			IFX_DBG("[%s:%d] \n ", __FUNCTION__, __LINE__);
			if (!gstrcmp(Disable_Accel, "1")) {
				qos_class.disableAccel = IFX_ENABLED;
				printf("[%s:%d],disableAccel=%d \n", __FUNCTION__, __LINE__,qos_class.disableAccel);
			}
			 else {
				qos_class.disableAccel = IFX_DISABLED;
				printf("[%s:%d],disableAccel=%d \n", __FUNCTION__, __LINE__,qos_class.disableAccel);
				flags |= IFX_F_DONT_VALIDATE;
			}

			qos_class.qId = atoi(pQId);

			IFX_DBG("[%s:%d] ", __FUNCTION__, __LINE__);
			if (!gstrcmp(pEnable, "1")) {
				qos_class.enable = IFX_ENABLED;
				/* Check if associated queue is enabled, if not fail */
				ret =
				    ifx_get_another_fvp_from_dist_fvp
				    (TAG_IPQOS_QUEUE, "cpeId", pQId, "enable",
				     sEnable, IFX_F_GET_ANY);
				if ((ret != IFX_SUCCESS) || (!atoi(sEnable))) {
					COPY_TO_STATUS(qcl_depend_err, pQId);
					ifx_httpdRedirect(wp, "err_page.html");
					return;
				}
			} else {
				qos_class.enable = IFX_DISABLED;
				flags |= IFX_F_DONT_VALIDATE;
			}

			IFX_DBG("[%s:%d] ", __FUNCTION__, __LINE__);
			if (pOrder != NULL && strlen(pOrder)) 
			{
				IFX_DBG("[%s:%d] ", __FUNCTION__, __LINE__);
				if (!gstrcmp(pOrder, "-1")) 
				{
					if((operation == IFX_OP_ADD) || (operation == IFX_OP_MOD))
					{
						ret =
				    			ifx_get_another_fvp_from_dist_fvp
				    			(TAG_IPQOS_QUEUE, "cpeId", pQId, "qIf",
				     			sqIf, IFX_F_GET_ANY);
						if(!gstrcmp(sqIf, "LAN"))
						{
							switch(qIfType)
							{
								case IFX_MAPI_QoS_WAN_ATM:
									wanqIfType = IFX_MAPI_QoS_LAN_ATM;
								break;
								case IFX_MAPI_QoS_WAN_PTM:
									wanqIfType = IFX_MAPI_QoS_LAN_PTM;
								break;
								case IFX_MAPI_QoS_WAN_ETH_0:
									wanqIfType = IFX_MAPI_QoS_LAN_ETH_0;
								break;
								case IFX_MAPI_QoS_WAN_ETH_1:
									wanqIfType = IFX_MAPI_QoS_LAN_ETH_1;
								break;
								default:
								break;
							}
							qos_class.order =
					    			(ifx_mapi_get_ds_classifier_mfc_count_for_wan_mode
					    			(wanqIfType));
						}
						if(!gstrcmp(sqIf, "WAN"))
						{
							qos_class.order =
					    			(ifx_mapi_get_ds_classifier_mfc_count_for_wan_mode
					    			(qIfType));
					
						}	
					}
					if (operation == IFX_OP_MOD) 
					{
						ret =
						    ifx_get_another_fvp_from_dist_fvp
						    (TAG_IPQOS_DS_CLASSIFY,
						     "cpeId", pCpeid, "type",
						     classifyType,
						     IFX_F_GET_ANY);

						IFX_DBG
						    ("[%s:%d] cpeid=%s type=%s operation=%d order=%d",
						     __FUNCTION__, __LINE__,
						     pCpeid, classifyType,
						     operation,
						     qos_class.order);
					}
					IFX_DBG("[%s:%d] operation=%d order=%d",
						__FUNCTION__, __LINE__,
						operation, qos_class.order);
					if (operation == IFX_OP_ADD
					    || ((operation == IFX_OP_MOD)
						&& (atoi(classifyType) !=
						    IFX_MAPI_QoS_Multi_Field)))
					{
						IFX_DBG("[%s:%d] ",
							__FUNCTION__, __LINE__);
						qos_class.order =
						    qos_class.order + 1;
						IFX_DBG("[%s:%d] order = %d",
							__FUNCTION__, __LINE__,
							qos_class.order);
					}
				} 
				else 
				{
					IFX_DBG("[%s:%d] ", __FUNCTION__,
						__LINE__);
					qos_class.order = atoi(pOrder);
				}
			} /* End of order LOOP */
			
			IFX_DBG("[%s:%d] order = %d", __FUNCTION__, __LINE__,
				qos_class.order);
			
			if (pClassName != NULL && strlen(pClassName))
				sprintf(qos_class.classifierName, "%s",
					pClassName);

			/* Validate uniqueness of classifier name */
#if 1
			NULL_TERMINATE(sCpeid, 0x00, sizeof(sCpeid));
			// ret = ifx_get_another_fvp_from_dist_fvp(TAG_IPQOS_CLASSIFY,
			// "className", qos_class.classifierName, "cpeId", sCpeid,
			// IFX_F_GET_ANY);
			ret =
			    ifx_check_unique_fvp_for_qos_ds_class(qIfType,
							       "className",
							       qos_class.
							       classifierName,
							       "cpeId", sCpeid,
							       IFX_F_GET_ANY);
			if (operation == IFX_OP_ADD) 
			{
				if (ret == IFX_SUCCESS && strlen(sCpeid)
				    && qIfType ==
				    ifx_mapi_get_ds_class_iface(sCpeid)) {
					COPY_TO_STATUS(class_name_err, "Name",
						       qos_class.classifierName,
						       "Name");
					ifx_httpdRedirect(wp, "err_page.html");
					return;
				}
			} 
			else if (operation == IFX_OP_MOD) 
			{
#if 1
				ret =
				    ifx_get_instance_count_from_dist_fvp_for_ds_class
				    (qIfType, TAG_IPQOS_DS_CLASSIFY,
				     PREFIX_IPQOS_DS_CLASSIFY, "className",
				     qos_class.classifierName, IFX_F_GET_ANY);
				IFX_DBG("count with name [%s] is [%d",
					qos_class.classifierName, ret);
				IFX_DBG("cpeids [%d:%d]",
					qos_class.iid.cpeId.Id, atoi(sCpeid));
				if (ret == IFX_FAILURE) 
				{
					COPY_TO_STATUS(class_name_err, "Name",
						       qos_class.classifierName,
						       "Name");
					ifx_httpdRedirect(wp, "err_page.html");
					return;
				} 
				else 
				{
					if (ret == 1) {
						if (qos_class.iid.cpeId.Id !=
						    atoi(sCpeid)) {
							COPY_TO_STATUS
							    (class_name_err,
							     "Name",
							     qos_class.
							     classifierName,
							     "Name");
							ifx_httpdRedirect(wp,
									  "err_page.html");
							return;
						}
					}
					if (ret > 1) {
						COPY_TO_STATUS(class_name_err,
							       "Name",
							       qos_class.
							       classifierName,
							       "Name");
						ifx_httpdRedirect(wp,
								  "err_page.html");
						return;
					}
				}
#endif
			}
#endif				
			qos_class.IngIf = -1;
			if (pClassIface != NULL && strlen(pClassIface)) 
			{
				if (!strcmp(pClassIface, "LOCAL"))
					qos_class.classIf = IFX_MAPI_QoS_LOCAL;
				else if (!strcmp(pClassIface, "LAN"))
					qos_class.classIf =
					    IFX_MAPI_QoS_LAN_ALL;
				else if (!strcmp(pClassIface, "LOCAL+LAN"))
					qos_class.classIf = IFX_MAPI_QoS_ALL;
				else if (!strcmp(pClassIface, "WAN"))
					qos_class.classIf =
					    IFX_MAPI_QoS_WAN;
				else if (!strcmp(pClassIface, "LOCAL+WAN"))
					qos_class.classIf =
					    IFX_MAPI_QoS_WAN_ALL;
			}
			if (pIngIface != NULL && strlen(pIngIface)) 
			{
				if (!strcmp(pIngIface, "LAN"))
					qos_class.IngIf = IFX_MAPI_QoS_LAN_ALL;
				else if (!strcmp(pIngIface, "WAN"))
					qos_class.IngIf = IFX_MAPI_QoS_WAN_ALL;
				else if (!strcmp(pIngIface, "WLAN"))
					qos_class.IngIf = IFX_MAPI_QoS_LAN_WIFI;
				else
					qos_class.IngIf = -1;
			}

			/* 5.2 Additions */
			qos_class.dscpCheck = -1;
			qos_class.pBitsCheck = -1;
			qos_class.vlanCheck = -1;
			qos_class.vlanExcl = IFX_DISABLED;
			qos_class.dscpMark = -1;
			qos_class.pBitsMark = -1;
			sprintf(qos_class.dstMac, "%s", "");
			qos_class.srcMacExcl = IFX_DISABLED;
			sprintf(qos_class.dstMacMask, "%s", "");
			sprintf(qos_class.srcMacMask, "%s", "");
			/* End of 5.2 Additions */

			/* fill default values for remaining fields */
			qos_class.rateCtrlEnbl = IFX_DISABLED;
			qos_class.rateLmt = -1;
			qos_class.protoNum = -1;
			qos_class.protoExcl = IFX_DISABLED;
			qos_class.srcPortRange.start_port =
			    qos_class.srcPortRange.end_port = -1;
			qos_class.srcPortExcl = IFX_DISABLED;
			qos_class.dstPortRange.start_port =
			    qos_class.dstPortRange.end_port = -1;
			qos_class.dstPortExcl = IFX_DISABLED;
			sprintf(qos_class.srcIP.ip, "%s", "");
			sprintf(qos_class.srcIP.mask, "%s", "");
			qos_class.srcIPExcl = IFX_DISABLED;
			sprintf(qos_class.dstIP.ip, "%s", "");
			sprintf(qos_class.dstIP.mask, "%s", "");
			qos_class.dstIPExcl = IFX_DISABLED;
			sprintf(qos_class.srcMac, "%s", "");
			qos_class.srcMacExcl = IFX_DISABLED;

			if (ifx_mapi_get_all_qos_queue_if_specific
			    (qIfType, &count, &queue,
			     IFX_F_DEFAULT) != IFX_SUCCESS) {
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to read previous configuration of this classifier"));
				return;
			}

			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
			if (!gstrcmp(pRCtrl, "1"))
				qos_class.rateCtrlEnbl = IFX_ENABLED;
			else
				qos_class.rateCtrlEnbl = IFX_DISABLED;
			/* Value of classifier based rate limiting */
			if (strlen(pRLmt) && atoi(pRLmt) >= 0)
				qos_class.rateLmt = atoi(pRLmt);
			else
				qos_class.rateLmt = -1;
			for (i = 0; i < count; i++) {
				if (atoi(pQId) == (queue + i)->iid.cpeId.Id) {
					if ((!gstrcmp(pRCtrl, "1")
					     && strlen(pRLmt))
					    && ((atoi(pRLmt) < 0)
						|| (atoi(pRLmt) >
						    (queue + i)->peakRate))) {
						COPY_TO_STATUS("%s",
							       "<span class=\"textTitle\">Invalid Rate Limit Value</span>");
						ifx_httpdRedirect(wp,
								  "err_page.html");
						return;
					}
				}
			}

			if (!gstrcmp(pClassType, "DSCP")) {
				qos_class.mfClass = IFX_MAPI_QoS_DSCP;
				if (pInDscp != NULL && strlen(pInDscp))
					qos_class.dscpCheck = atoi(pInDscp);
				if (pOutDscp != NULL && strlen(pOutDscp))
					qos_class.dscpMark = atoi(pOutDscp);
				qos_class.pBitsCheck = -1;
				qos_class.pBitsMark = -1;
			} else if (!gstrcmp(pClassType, "802.1P")) {
				qos_class.mfClass = IFX_MAPI_QoS_P_Bits;
				qos_class.dscpCheck = -1;
				qos_class.dscpMark = -1;
				if (pIn802p != NULL && strlen(pIn802p))
					qos_class.pBitsCheck = atoi(pIn802p);
				if (pOut802p != NULL && strlen(pOut802p))
					qos_class.pBitsMark = atoi(pOut802p);
			} else if (!gstrcmp(pClassType, "MFC")) {
				qos_class.mfClass = IFX_MAPI_QoS_Multi_Field;
				// qos_class.dscpCheck = -1;
				// qos_class.pBitsCheck = -1;
				qos_class.dscpCheck = atoi(pInDscp);
				/* Manamohan,Klocwork updates 7,March 2012 */
				if(pIn802p != NULL)
					qos_class.pBitsCheck = atoi(pIn802p);
				if (pSrcIP != NULL && strlen(pSrcIP))
					sprintf(qos_class.srcIP.ip, "%s",
						pSrcIP);

				if (pSrcMask != NULL && strlen(pSrcMask))
					sprintf(qos_class.srcIP.mask, "%s",
						pSrcMask);
				if (pSrcIPExcl != NULL && strlen(pSrcIPExcl)) {
					if (!gstrcmp(pSrcIPExcl, "1"))
						qos_class.srcIPExcl =
						    IFX_ENABLED;
					else
						qos_class.srcIPExcl =
						    IFX_DISABLED;
				}

				if (pDstIP != NULL && strlen(pDstIP))
					sprintf(qos_class.dstIP.ip, "%s",
						pDstIP);

				if (pDstMask != NULL && strlen(pDstMask))
					sprintf(qos_class.dstIP.mask, "%s",
						pDstMask);

				if (pDstIPExcl != NULL && strlen(pDstIPExcl)) {
					if (!gstrcmp(pDstIPExcl, "1"))
						qos_class.dstIPExcl =
						    IFX_ENABLED;
					else
						qos_class.dstIPExcl =
						    IFX_DISABLED;
				}

				if (pProto != NULL && strlen(pProto)) {
					if (!gstrcmp(pProto, "ICMP"))
						qos_class.protoNum = 1;
					else if (!gstrcmp(pProto, "UDP"))
						qos_class.protoNum = 17;
					else if (!gstrcmp(pProto, "TCP"))
						qos_class.protoNum = 6;
				}

				if (pProtoExcl != NULL && strlen(pProtoExcl)) {
					/* TODO */
					/* if(!gstrcmp(pProtoExcl. "1")) */
					if (!gstrcmp(pProtoExcl, "1"))
						qos_class.protoExcl =
						    IFX_ENABLED;
					else
						qos_class.protoExcl =
						    IFX_DISABLED;
				}
				
				if (pL3Proto != NULL && strlen(pL3Proto)) {
					if (!gstrcmp(pL3Proto, "IPv4"))
						qos_class.L3protoNum = 1;
					else if (!gstrcmp(pL3Proto, "IPv6"))
						qos_class.L3protoNum = 2;
				}

				if (pL3ProtoExcl != NULL && strlen(pL3ProtoExcl)) {
					/* TODO */
					/* if(!gstrcmp(pProtoExcl. "1")) */
					if (!gstrcmp(pL3ProtoExcl, "1"))
						qos_class.L3protoExcl =
						    IFX_ENABLED;
					else
						qos_class.L3protoExcl =
						    IFX_DISABLED;
				}

				if (pSrcPortStart != NULL
				    && strlen(pSrcPortStart))
					qos_class.srcPortRange.start_port =
					    atoi(pSrcPortStart);

				if (pSrcPortEnd != NULL && strlen(pSrcPortEnd))
					qos_class.srcPortRange.end_port =
					    atoi(pSrcPortEnd);

				if (pSrcPortExcl != NULL
				    && strlen(pSrcPortExcl)) {
					if (!gstrcmp(pSrcPortExcl, "1"))
						qos_class.srcPortExcl =
						    IFX_ENABLED;
					else
						qos_class.srcPortExcl =
						    IFX_DISABLED;
				}

				if (pDstPortStart != NULL
				    && strlen(pDstPortStart))
					qos_class.dstPortRange.start_port =
					    atoi(pDstPortStart);

				if (pDstPortEnd != NULL && strlen(pDstPortEnd))
					qos_class.dstPortRange.end_port =
					    atoi(pDstPortEnd);

				if (pDstPortExcl != NULL
				    && strlen(pDstPortExcl)) {
					if (!gstrcmp(pDstPortExcl, "1"))
						qos_class.dstPortExcl =
						    IFX_ENABLED;
					else
						qos_class.dstPortExcl =
						    IFX_DISABLED;
				}

				if (pSrcMac != NULL && strlen(pSrcMac))
					sprintf(qos_class.srcMac, "%s",
						pSrcMac);

				if (pSrcMacExcl != NULL && strlen(pSrcMacExcl)) {
					if (!gstrcmp(pSrcMacExcl, "1"))
						qos_class.srcMacExcl =
						    IFX_ENABLED;
					else
						qos_class.srcMacExcl =
						    IFX_DISABLED;
				}
				if (pSrcMacMask != NULL && strlen(pSrcMacMask))
					sprintf(qos_class.srcMacMask, "%s",
						pSrcMacMask);
				if (pDstMac != NULL && strlen(pDstMac))
					sprintf(qos_class.dstMac, "%s",
						pDstMac);
				if (pDstMacMask != NULL && strlen(pDstMacMask))
					sprintf(qos_class.dstMacMask, "%s",
						pDstMacMask);
				if (pDstMacExcl != NULL && strlen(pDstMacExcl)) {
					if (!gstrcmp(pDstMacExcl, "1"))
						qos_class.dstMacExcl =
						    IFX_ENABLED;
					else
						qos_class.dstMacExcl =
						    IFX_DISABLED;
				}
				if (pIn802p != NULL && strlen(pIn802p))
					qos_class.pBitsCheck = atoi(pIn802p);
				if (pVlanExcl != NULL && strlen(pVlanExcl)) {
					if (!gstrcmp(pVlanExcl, "1"))
						qos_class.vlanExcl =
						    IFX_ENABLED;
					else
						qos_class.vlanExcl =
						    IFX_DISABLED;
				}
				if (!qos_class.vlanExcl && pVlanId != NULL
				    && strlen(pVlanId))
					qos_class.vlanCheck = atoi(pVlanId);
				if (pOutDscp != NULL && strlen(pOutDscp))
					qos_class.dscpMark = atoi(pOutDscp);
				if (pOut802p != NULL && strlen(pOut802p))
					qos_class.pBitsMark = atoi(pOut802p);

			} 
			else 
			{
				ifx_httpdWrite(wp, T("Mode not supported"));
				return;
			}
		} 
		else if (operation == IFX_OP_DEL) 
		{
			qos_class.iid.cpeId.Id = atoi(pCpeid);

			if (ifx_mapi_get_qos_ds_classifier
			    (&qos_class, IFX_F_GET_ANY) != IFX_SUCCESS) 
			{
				ifx_httpdError(wp, 400, T("%s"),
					       "Failed to read previous configuration");
				return;
			}
		}

		sprintf(qos_class.iid.cpeId.secName, "%s", TAG_IPQOS_DS_CLASSIFY);
		sprintf(qos_class.iid.pcpeId.secName, "%s", TAG_IPQOS_QM);
		qos_class.iid.config_owner = IFX_WEB;
		qos_class.iid.pcpeId.Id = 1;

		if (ifx_mapi_set_qos_ds_classifier(operation, &qos_class, flags) !=
		    IFX_SUCCESS) {
			COPY_TO_STATUS("%s",
				       "<span class=\"textTitle\">Downstream Classifier Configuration failed</span>");
			ifx_httpdRedirect(wp, "err_page.html");
			return;
		}

	      IFX_Handler:
		ifx_httpdRedirect(wp, T("qos_ds_class.asp"));
	}
#endif				// CONFIG_FEATURE_IFX_IPQOS

#ifdef CONFIG_FEATURE_IFX_IPQOS

#define IFX_GET_QOS_DROP_TYPE_STR(dropType, pDrop) { \
                                                     switch(dropType) { \
                                                        case IFX_MAPI_QoS_Drop_DT: \
                                                                          pDrop = "DT"; \
                                                                          break; \
                                                        case IFX_MAPI_QoS_Drop_RED: \
                                                                          pDrop = "RED"; \
                                                                          break; \
                                                        case IFX_MAPI_QoS_Drop_NONE: \
                                                                          pDrop = "NONE"; \
                                                                          break; \
                                                        case IFX_MAPI_QoS_Drop_WRED: \
                                                                          pDrop = "WRED"; \
                                                                          break; \
                                                        case IFX_MAPI_QoS_Drop_BLUE: \
                                                                          pDrop = "BLUE"; \
                                                                          break; \
                                 } \
                           }

#define IFX_GET_QOS_SCHED_TYPE_STR(schedType, pSched) { \
                                                             switch(schedType) { \
                                                                case IFX_MAPI_QoS_Sched_SP: \
                                                                                  pSched = "SP"; \
                                                                                  break; \
                                                                case IFX_MAPI_QoS_Sched_WRR: \
                                                                                  pSched = "WRR"; \
                                                                                  break; \
                                                                case IFX_MAPI_QoS_Sched_WFQ: \
                                                                                  pSched = "WQ"; \
                                                                                  break; \
                                                                case IFX_MAPI_QoS_Sched_HTB: \
                                                                                  pSched = "HTB"; \
                                                                                  break; \
                                                             } \
                                           }

	
	void ifx_get_qos_main(int eid, httpd_t wp, int argc, char_t ** argv) 
	{
		IFX_MAPI_QoS_QM qos_qm;
		IFX_MAPI_QoS_Capability qos_capab;
		char_t *name = NULL, sValue[20];;
		int i = 0;
		int count = 0;
		IFX_MAPI_QoS_Queue *queues = NULL;

		memset(&qos_qm, 0x00, sizeof(qos_qm));
		memset(&qos_capab, 0x00, sizeof(qos_capab));

		if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) 
		{
			ifx_httpdError(wp, 400, T("Insufficient args\n"));
			return;
		}

		if (ifx_mapi_get_qos_qm(&qos_qm, IFX_F_DEFAULT) != IFX_SUCCESS) 
		{
			ifx_httpdError(wp, 400,
				       T("Failed to read QoS configuration"));
			return;
		}

		if (!gstrcmp(name, "status")) 
		{
			ifx_httpdWrite(wp, T("%d"), qos_qm.enable);
		} 
		else if (!gstrcmp(name, "USstatus")) 
		{
			ifx_httpdWrite(wp, T("%d"), qos_qm.USenable);
		} 
		else if (!gstrcmp(name, "DSstatus")) 
		{
			ifx_httpdWrite(wp, T("%d"), qos_qm.DSenable);
		} 
		else if (!gstrcmp(name, "8021PStatus")) 
		{
			ifx_httpdWrite(wp, T("%d"), qos_qm.P8021enable);
		} 
		else if (!gstrcmp(name, "tcpackprio_status")) 
		{
			ifx_httpdWrite(wp, T("%d"), qos_qm.tcpackprio);
		} 
		else if (!gstrcmp(name, "queue_mode")) 
		{
			ifx_httpdWrite(wp, T("%d"), qos_qm.atmQMode);
		} 
		else if (!gstrcmp(name, "ingress_int")) 
		{
			ifx_httpdWrite(wp,
				       T
				       ("<option value=\"eth0\">ETH0</option>"));
#if defined(CONFIG_FEATURE_IFX_USB_HOST)
			ifx_httpdWrite(wp,
				       T("<option value=\"usb\">USB</option>"));
#endif
#ifdef CONFIG_FEATURE_IFX_WIRELESS
			ifx_httpdWrite(wp,
				       T
				       ("<option value=\"wlan\">WLAN</option>"));
#endif
		} 
		else if (!gstrcmp(name, "port_rate_limit")) 
		{
			if (qos_qm.portRateLimitEnable)
				ifx_httpdWrite(wp,
					       T
					       ("<input type=\"checkbox\" value=\"1\" name=\"phy_port_rate\" checked onClick=\"port_rate_limit_disable();\" checked>"));
			else
				ifx_httpdWrite(wp,
					       T
					       ("<input type=\"checkbox\" value=\"1\" name=\"phy_port_rate\" onClick=\"port_rate_limit_disable();\">"));
		} 
		else if (!gstrcmp(name, "port_rate_limit_ds")) 
		{
			if (qos_qm.DSportRateLimitEnable)
				ifx_httpdWrite(wp,
					       T
					       ("<input type=\"checkbox\" value=\"1\" name=\"phy_port_rate_ds\" checked onClick=\"downstream_port_rate_limit_disable();\" checked>"));
			else
				ifx_httpdWrite(wp,
					       T
					       ("<input type=\"checkbox\" value=\"1\" name=\"phy_port_rate_ds\" onClick=\"downstream_port_rate_limit_disable();\">"));
		} 
		else if (!gstrcmp(name, "upstream_rate")) 
		{
			ifx_httpdWrite(wp, T("%d"),
				       qos_qm.upstreamPortRateLimit);
		} 
		else if (!gstrcmp(name, "downstream_rate")) 
		{
			ifx_httpdWrite(wp, T("%d"),
				       qos_qm.downstreamPortRateLimit);
		} 
		else if (!gstrcmp(name, "max_order")) 
		{
			if (ifx_mapi_get_qos_capability
			    (&qos_capab, IFX_F_DEFAULT) != IFX_SUCCESS) 
			{
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to read QoS configuration"));
				return;
			}

			ifx_httpdWrite(wp, T("%u"), qos_capab.maxClassifiers);
		} 
		else if (!gstrcmp(name, "def_dscp")) 
		{
			for (i = 0;
			     i <
			     sizeof(web_Enum_DSCP_Opt_List) /
			     sizeof(CGI_ENUMSEL_S); i++) 
			{
				// Get Selected option index form admweb.conf
				if (qos_qm.defaultDSCP ==
				    web_Enum_DSCP_Opt_List[i].value)
					gsprintf(sValue, T("%s"), "selected");
				else
					gsprintf(sValue, T("%s"), "");
				ifx_httpdWrite(wp,
					       T
					       ("\t<option value=\"%d\" %s>%s</option>\n"),
					       web_Enum_DSCP_Opt_List[i].value,
					       sValue,
					       web_Enum_DSCP_Opt_List[i].str);
			}
		} 
		else if (!gstrcmp(name, "def_queue")) 
		{

			if (ifx_mapi_get_all_qos_queue
			    ((uint32 *) & count, &queues,
			     IFX_F_DEFAULT) != IFX_SUCCESS) 
			{
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to display configured QoS queues"));
				return;
			}

			for (i = 0; i < count; i++) 
			{
				if ((queues + i)->enable == 1) 
				{
					if (qos_qm.defaultQ ==
					    (queues + i)->iid.cpeId.Id)
						gsprintf(sValue, T("%s"),
							 "selected");
					else
						gsprintf(sValue, T("%s"), "");

					ifx_httpdWrite(wp,
						       T
						       ("\t<option value=\"%d\" %s>%s</option>\n"),
						       (queues +
							i)->iid.cpeId.Id,
						       sValue,
						       (queues + i)->qName);
				}
			}

			IFX_MEM_FREE(queues)
		} 
		else if (!gstrcmp(name, "in_dscp")) 
		{
			for (i = 1;
			     i <
			     sizeof(web_Enum_DSCP_Opt_List) /
			     sizeof(CGI_ENUMSEL_S); i++) 
			{
				// Get Selected option index form admweb.conf
				if (qos_qm.defaultDSCP ==
				    web_Enum_DSCP_Opt_List[i].value)
					gsprintf(sValue, T("%s"), "selected");
				else
					gsprintf(sValue, T("%s"), "");
				ifx_httpdWrite(wp,
					       T
					       ("\t<option value=\"%d\" %s>%s</option>\n"),
					       web_Enum_DSCP_Opt_List[i].value,
					       sValue,
					       web_Enum_DSCP_Opt_List[i].str);
			}

		} else if (!gstrcmp(name, "class_session_mngr")) {
		
			ifx_httpdWrite(wp, T("%d"), qos_qm.class_accel_mngr);
		}
	}

	void ifx_get_qos_queue(int eid, httpd_t wp, int argc, char_t ** argv) {
		char_t *name = NULL, *pDrop = NULL, *pSched = NULL;
		int count = 0, lan_count = 0, i = 0, j = 0;
		char sCommand[256];

		/* Update Flags */
		sprintf(sCommand, "queuecfg -u 0/0");
		system(sCommand);

		/* Update Rates */
		sprintf(sCommand, "queuecfg -r 0/0");
		system(sCommand);

		IFX_MAPI_QoS_Queue *queues = NULL;
		IFX_MAPI_QoS_Queue *lan_queues = NULL;

		WAN_PHY_CFG pstWanPhy;
		memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
		ifx_get_wan_phy_cfg(&pstWanPhy);

		if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
			ifx_httpdError(wp, 400, T("Insufficient args\n"));
			return;
		}

		if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2
		    && pstWanPhy.wan_tc == WAN_TC_ATM) {
			if (ifx_mapi_get_all_qos_queue_if_specific
			    (IFX_MAPI_QoS_WAN_ATM, (uint32 *) & count, &queues,
			     IFX_F_DEFAULT) != IFX_SUCCESS) {
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to display configured ATM QoS queues"));
				return;
			}
			if (ifx_mapi_get_all_qos_queue_if_specific
			    (IFX_MAPI_QoS_LAN_ATM, (uint32 *) & lan_count,
			     &lan_queues, IFX_F_DEFAULT) != IFX_SUCCESS) {
				IFX_DBG("[%s:%d] lan_count=%d ", __FUNCTION__,
					__LINE__, lan_count);
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to display configured LAN QoS queues"));
				return;
			}
		}else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2
			  &&  pstWanPhy.wan_tc == WAN_TC_PTM){
			if (ifx_mapi_get_all_qos_queue_if_specific
			    (IFX_MAPI_QoS_WAN_PTM, (uint32 *) & count, &queues,
			     IFX_F_DEFAULT) != IFX_SUCCESS) {
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to display configured PTM QoS queues"));
				return;
			}
			if (ifx_mapi_get_all_qos_queue_if_specific
			    (IFX_MAPI_QoS_LAN_PTM, (uint32 *) & lan_count,
			     &lan_queues, IFX_F_DEFAULT) != IFX_SUCCESS) {
				IFX_DBG("[%s:%d] lan_count=%d ", __FUNCTION__,
					__LINE__, lan_count);
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to display configured LAN QoS queues"));
				return;
			}

		}	
	       	else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII0) {
			if (ifx_mapi_get_all_qos_queue_if_specific
			    (IFX_MAPI_QoS_WAN_ETH_0, (uint32 *) & count,
			     &queues, IFX_F_DEFAULT) != IFX_SUCCESS) {
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to display configured MII-0 QoS queues"));
				return;
			}
			if (ifx_mapi_get_all_qos_queue_if_specific
			    (IFX_MAPI_QoS_LAN_ETH_0, (uint32 *) & lan_count,
			     &lan_queues, IFX_F_DEFAULT) != IFX_SUCCESS) {
				IFX_DBG("[%s:%d] lan_count=%d ", __FUNCTION__,
					__LINE__, lan_count);
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to display configured LAN QoS queues"));
				return;
			}
		} else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII1) {
			if (ifx_mapi_get_all_qos_queue_if_specific
			    (IFX_MAPI_QoS_WAN_ETH_1, (uint32 *) & count,
			     &queues, IFX_F_DEFAULT) != IFX_SUCCESS) {
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to display configured MII-1 QoS queues"));
				return;
			}
			IFX_DBG("[%s:%d] wan_count=%d ", __FUNCTION__, __LINE__,
				count);
			if (ifx_mapi_get_all_qos_queue_if_specific
			    (IFX_MAPI_QoS_LAN_ETH_1, (uint32 *) & lan_count,
			     &lan_queues, IFX_F_DEFAULT) != IFX_SUCCESS) {
				IFX_DBG("[%s:%d] lan_count=%d ", __FUNCTION__,
					__LINE__, lan_count);
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to display configured LAN QoS queues"));
				return;
			}
			IFX_DBG("[%s:%d] lan_count=%d ", __FUNCTION__, __LINE__,
				lan_count);

		} else if (pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2) {
			if (ifx_mapi_get_all_qos_queue_if_specific
			    (IFX_MAPI_QoS_WAN_PTM, (uint32 *) & count, &queues,
			     IFX_F_DEFAULT) != IFX_SUCCESS) {
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to display configured PTM QoS queues"));
				return;
			}
			IFX_DBG("[%s:%d] wan_count=%d ", __FUNCTION__, __LINE__,
				count);
			if (ifx_mapi_get_all_qos_queue_if_specific
			    (IFX_MAPI_QoS_LAN_PTM, (uint32 *) & lan_count,
			     &lan_queues, IFX_F_DEFAULT) != IFX_SUCCESS) {
				IFX_DBG("[%s:%d] lan_count=%d ", __FUNCTION__,
					__LINE__, lan_count);
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to display configured LAN QoS queues"));
				return;
		}
			IFX_DBG("[%s:%d] lan_count=%d ", __FUNCTION__, __LINE__,
				lan_count);

		}
		/* Getting WAN QUEUE RELATED INFO */
		if ((name) && (!gstrcmp(name, "wanqnames"))) {
			IFX_DBG("[%s:%d] count=%d ", __FUNCTION__, __LINE__,
				count);
			for (i = 0; i < count; i++) 
			{
				ifx_httpdWrite(wp,
					       T
					       ("<option value='%d'>%s</option>"),
					       (queues + i)->iid.cpeId.Id,
					       (queues + i)->qName);
			}
		} 
		else 
		{
			if (name != NULL
			    && !gstrcmp(name, "queue_usinfo")) 
			{
				for (i = 0; i < count; i++) 
				{
					if (atoi(qoscpeId) !=
					    (queues + i)->iid.cpeId.Id) 
					{
						continue;
					}
					IFX_DBG
					    ("[%s:%d]instance=%d, wan_count=%d, wan_queue= %s,qIf=%s,qPrio=%d, ",
					     __FUNCTION__, __LINE__, i, count,
					     (queues + i)->qName,
					     (queues + i)->qIf,
					     (queues + i)->qPrio);
					ifx_httpdWrite(wp,
					       T
					       ("\"%s\",\"%s\",\"%d\",\"%d\",\"%d\""),
					       (queues + i)->qName,
					       (queues + i)->qIf,
					       (queues + i)->qPrio,
					       (queues + i)->redTh,
					       (queues + i)->redPct);

					IFX_GET_QOS_DROP_TYPE_STR((queues +
							   i)->dropType,
							  pDrop)
				 	IFX_GET_QOS_SCHED_TYPE_STR((queues +
								i)->
							       schedType,
							       pSched)
				    	ifx_httpdWrite(wp,
						   T
						   (",\"%s\",\"%s\",\"%d\",\"%d\",\"%d\",\"%d\",\"%d\",\"%d\",\"%s\""),
						   pDrop, pSched,
						   (queues + i)->enable,
						   (queues +
						    i)->iid.cpeId.Id,
						   (queues + i)->qWt,
						   (queues +
						    i)->commitRate,
						   (queues +
						    i)->peakRate,
						   (queues +
						    i)->shaperEnable,
						   (queues +
						    i)->egressPVC);
					break;
				}/* End of count loop */
			}/* End of Queue us info */
			if(name != NULL && !gstrcmp(name, "us_info"))
			{
				for (i = 0; i < count; i++) 
				{
					ifx_httpdWrite(wp,
					       "<input type=\"hidden\" name=\"cpeId%d\" value=\"%d\">",
					       i, (queues + i)->iid.cpeId.Id);
					ifx_httpdWrite(wp,
					       "<tr><td id=\"qos_qname%d\">%s</td><td id=\"qos_qprec%d\">%d</td>",
					       i, (queues + i)->qName, i,
					       (queues + i)->qPrio);

					IFX_GET_QOS_DROP_TYPE_STR((queues +
							   i)->dropType, pDrop)
			    		IFX_GET_QOS_SCHED_TYPE_STR((queues +
								i)->schedType,
							       pSched)
			    		ifx_httpdWrite(wp,
						   T
						   ("<td id=\"qos_dalgo%d\">%s</td><td id=\"qos_salgo%d\">%s</td>"),
						   i, pDrop, i, pSched);
					if (!strcmp(pSched, "SP"))
						ifx_httpdWrite(wp,
						       T
						       ("<td id=\"qos_wt%d\">%d</td><td id=\"commit_rate%d\">%d</td><td id=\"peak_rate%d\">%d</td>"),
						       i, 0, i, 0, i,
						       (queues + i)->peakRate);
					else
						ifx_httpdWrite(wp,
						       T
						       ("<td id=\"qos_wt%d\">%d</td><td id=\"commit_rate%d\">%d</td><td id=\"peak_rate%d\">%d</td>"),
						       i, (queues + i)->qWt, i,
						       (queues + i)->commitRate,
						       i,
						       (queues + i)->peakRate);
					ifx_httpdWrite(wp,
					       "<td id=\"qos_qen%d\">%s</td>",
					       i,
					       (queues +
						i)->enable ? "Yes" : "No");
					ifx_httpdWrite(wp,
					       "<td><input type='radio' name='QoSSelect' value='%d'></td></tr>",
					       (queues + i)->iid.cpeId.Id);
				}/* End count loop */
			}/* End of us_info */
		}/* End of else loop */
		/* END of Getting WAN QUEUE RELATED INFO */
		
		/* Getting LAN QUEUE RELATED INFO */
		if ((name) && (!gstrcmp(name, "lanqnames"))) {
			IFX_DBG("[%s:%d] lan_count=%d ", __FUNCTION__, __LINE__,
				lan_count);
			for (j = 0; j < lan_count; j++) {
				ifx_httpdWrite(wp,
					       T
					       ("<option value='%d'>%s</option>"),
					       (lan_queues + j)->iid.cpeId.Id,
					       (lan_queues + j)->qName);
			}
		}
		else 
		{
			if (name != NULL
			    && !gstrcmp(name, "queue_dsinfo")) 
			{
				for (j = 0; j < lan_count; j++) 
				{
					if (atoi(qoscpeId) !=
					    (lan_queues + j)->iid.cpeId.Id) 
					{
						continue;
					}
					ifx_httpdWrite(wp,
						       T
						       ("\"%s\",\"%s\",\"%d\",\"%d\",\"%d\""),
						       (lan_queues + j)->qName,
						       (lan_queues + j)->qIf,
						       (lan_queues + j)->qPrio,
						       (lan_queues + j)->redTh,
						       (lan_queues +
							j)->redPct);

					IFX_GET_QOS_DROP_TYPE_STR((lan_queues +
								   j)->dropType,
								  pDrop)
					IFX_GET_QOS_SCHED_TYPE_STR((lan_queues + j)->schedType, pSched)
					ifx_httpdWrite(wp,
							   T
							   (",\"%s\",\"%s\",\"%d\",\"%d\",\"%d\",\"%d\",\"%d\",\"%d\",\"%s\""),
							   pDrop, pSched,
							   (lan_queues +
							    j)->enable,
							   (lan_queues +
							    j)->iid.cpeId.Id,
							   (lan_queues +
							    j)->qWt,
							   (lan_queues +
							    j)->commitRate,
							   (lan_queues +
							    j)->peakRate,
							   (lan_queues +
							    j)->shaperEnable,
							   (lan_queues +
							    j)->egressPVC);
					break;	
				}/* End of lan_count */
			}/* End of queue_dsinfo */
			if(name != NULL && !gstrcmp(name, "ds_info"))
			{
				for (j = 0; j < lan_count; j++) 
				{
					ifx_httpdWrite(wp,
					       "<input type=\"hidden\" name=\"cpeId%d\" value=\"%d\">",
					       j,
					       (lan_queues + j)->iid.cpeId.Id);
					ifx_httpdWrite(wp,
					       "<tr><td id=\"qos_qname%d\">%s</td><td id=\"qos_qprec%d\">%d</td>",
					       j, (lan_queues + j)->qName, j,
					       (lan_queues + j)->qPrio);

					IFX_GET_QOS_DROP_TYPE_STR((lan_queues +
							   j)->dropType, pDrop)
			    		IFX_GET_QOS_SCHED_TYPE_STR((lan_queues +
								j)->schedType,
							       pSched)
			    		ifx_httpdWrite(wp,
						   T
						   ("<td id=\"qos_dalgo%d\">%s</td><td id=\"qos_salgo%d\">%s</td>"),
						   j, pDrop, j, pSched);
					if (!strcmp(pSched, "SP"))
						ifx_httpdWrite(wp,
						       T
						       ("<td id=\"qos_wt%d\">%d</td><td id=\"commit_rate%d\">%d</td><td id=\"peak_rate%d\">%d</td>"),
						       j, 0, j, 0, j,
						       (lan_queues +
							j)->peakRate);
					else
						ifx_httpdWrite(wp,
						       T
						       ("<td id=\"qos_wt%d\">%d</td><td id=\"commit_rate%d\">%d</td><td id=\"peak_rate%d\">%d</td>"),
						       j, (lan_queues + j)->qWt,
						       j,
						       (lan_queues +
							j)->commitRate, j,
						       (lan_queues +
							j)->peakRate);
					ifx_httpdWrite(wp,
					       "<td id=\"qos_qen%d\">%s</td>",
					       j,
					       (lan_queues +
						j)->enable ? "Yes" : "No");
					ifx_httpdWrite(wp,
					       "<td><input type='radio' name='QoSSelect' value='%d'></td></tr>",
					       (lan_queues + j)->iid.cpeId.Id);
				}/* End of lan_count */
			}/* End of ds_info */
		}/* End of else */
		/* END of Getting LAN QUEUE RELATED INFO */
		IFX_MEM_FREE(queues)
		IFX_MEM_FREE(lan_queues)
	}

	void ifx_get_qos_classifier(int eid, httpd_t wp, int argc, char_t ** argv)
	{
		char_t *name = NULL, class_if[MAX_FILELINE_LEN], ing_if[MAX_FILELINE_LEN];
		char_t cpeIdStr[20], qName[MAX_NAME_LEN];
		int count = 0, i = 0, bFound = 0; 
		WAN_PHY_CFG pstWanPhy;
		memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
		ifx_get_wan_phy_cfg(&pstWanPhy);
		IFX_MAPI_QoS_Classifier *qos_class = NULL;

		if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
			ifx_httpdError(wp, 400, T("Insufficient args\n"));
			return;
		}

		if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2
		    && pstWanPhy.wan_tc == WAN_TC_ATM) 
		{
			if (ifx_mapi_get_all_qos_classifier_if_specific
			    (IFX_MAPI_QoS_WAN_ATM, (uint32 *) & count,
			     &qos_class, IFX_F_DEFAULT) != IFX_SUCCESS) 
			{
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to display configured ATM QoS classifiers"));
				IFX_MEM_FREE(qos_class)
				    return;
			}
		} 
		else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2
		    && pstWanPhy.wan_tc == WAN_TC_PTM) 
		{
			if (ifx_mapi_get_all_qos_classifier_if_specific
			    (IFX_MAPI_QoS_WAN_PTM, (uint32 *) & count,
			     &qos_class, IFX_F_DEFAULT) != IFX_SUCCESS) 
			{
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to display configured ATM QoS classifiers"));
				IFX_MEM_FREE(qos_class)
				    return;
			}
		}
		else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII0) 
		{
			if (ifx_mapi_get_all_qos_classifier_if_specific
			    (IFX_MAPI_QoS_WAN_ETH_0, (uint32 *) & count,
			     &qos_class, IFX_F_DEFAULT) != IFX_SUCCESS) 
			{
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to display configured MII-0 QoS classifiers"));
				IFX_MEM_FREE(qos_class)
				    return;
			}
		} 
		else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII1) 
		{
			if (ifx_mapi_get_all_qos_classifier_if_specific
			    (IFX_MAPI_QoS_WAN_ETH_1, (uint32 *) & count,
			     &qos_class, IFX_F_DEFAULT) != IFX_SUCCESS) 
			{
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to display configured MII-1 QoS classifiers"));
				IFX_MEM_FREE(qos_class)
				    return;
			}

		} 
		else 
		{
			if (ifx_mapi_get_all_qos_classifier_if_specific
			    (IFX_MAPI_QoS_WAN_PTM, (uint32 *) & count,
			     &qos_class, IFX_F_DEFAULT) != IFX_SUCCESS) 
			{
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to display configured PTM QoS classifiers"));
				IFX_MEM_FREE(qos_class)
				    return;
			}
		}
		
		/* UPSTREAM Classifier handling */
		if ((name) && (!gstrcmp(name, "us_info"))) 
		{
			for (i = 0; i < count; i++) 
			{
				ifx_httpdWrite(wp,
					       "<input type=\"hidden\" name=\"cpeId%d\" value=\"%d\">",
					       i,
					       (qos_class + i)->iid.cpeId.Id);
				ifx_httpdWrite(wp,
					       "<tr><td id=\"qos_cname%d\">%s</td><td id=\"qos_corder%d\">%d</td>",
					       i,
					       (qos_class + i)->classifierName,
					       i, (qos_class + i)->order);
				if ((qos_class + i)->mfClass ==
				    IFX_MAPI_QoS_DSCP)
					ifx_httpdWrite(wp,
						       T
						       ("<td id=\"mfclass%d\">%s</td>"),
						       i, "DSCP");
				else if ((qos_class + i)->mfClass ==
					 IFX_MAPI_QoS_Multi_Field)
					ifx_httpdWrite(wp,
						       T
						       ("<td id=\"mfclass%d\">%s</td>"),
						       i, "MFC");
				else if ((qos_class + i)->mfClass ==
					 IFX_MAPI_QoS_P_Bits)
					ifx_httpdWrite(wp,
						       T
						       ("<td id=\"mfclass%d\">%s</td>"),
						       i, "802.1p");
				switch ((qos_class + i)->classIf) 
				{
					case IFX_MAPI_QoS_LAN_ALL:
						ifx_httpdWrite(wp,
						       T
						       ("<td id=\"classif%d\">%s</td>"),
						       i, "LAN");
						break;
					case IFX_MAPI_QoS_LOCAL:
						ifx_httpdWrite(wp,
						       T
						       ("<td id=\"classif%d\">%s</td>"),
						       i, "LOCAL");
						break;
					case IFX_MAPI_QoS_ALL:
						ifx_httpdWrite(wp,
						       T
						       ("<td id=\"classif%d\">%s</td>"),
						       i, "LAN+LOCAL");
						break;
					default:
						ifx_httpdWrite(wp,
						       T
						       ("<td id=\"classif%d\">%s</td>"),
						       i, "");
						break;
				}
				sprintf(cpeIdStr, "%d", (qos_class + i)->qId);
				if (ifx_get_another_fvp_from_dist_fvp
				    (TAG_IPQOS_QUEUE, "cpeId", cpeIdStr,
				     "qName", qName,
				     IFX_F_GET_ANY) != IFX_SUCCESS)
					ifx_httpdWrite(wp,
						       "<td id=\"qos_qname%d\">%s</td>",
						       i, "");
				else
					ifx_httpdWrite(wp,
						       "<td id=\"qos_qname%d\">%s</td>",
						       i, qName);
				ifx_httpdWrite(wp,
					       "<td id=\"qos_out_dscp%d\">%d</td><td id=\"qos_en%d\">%s</td>",
					       i, (qos_class + i)->dscpMark, i,
					       (qos_class + i)->enable ==
					       IFX_ENABLED ? "Yes" : "No");

				ifx_httpdWrite(wp,
					       "<td><input type='radio' name='ClassSelect'"
					       "value='%d'></td></tr>",
					       (qos_class + i)->iid.cpeId.Id);
			}
		}/* End of US INFO */
		else if (!gstrcmp(name, "us_order")) 
		{
			for (i = 0; i < count; i++) 
			{
				if ((qos_class + i)->mfClass ==
				    IFX_MAPI_QoS_Multi_Field)
					ifx_httpdWrite(wp,
						       T
						       ("<option value='%d'>%d</option>"),
						       (qos_class + i)->order,
						       (qos_class + i)->order);
			}
			//if(i == 0)
				ifx_httpdWrite(wp, T("%s"),
					       "<option value='-1' selected>Last</option>");
			//else
			   //ifx_httpdWrite(wp, T("%s"), "<option value='-1'>Last</option>");
			 
		} 
		else 
		{
			if (name != NULL && gstrcmp(name, "us_info") && gstrcmp(name, "ds_info"))
			{
			for (i = 0; i < count; i++) 
			{

				if (name != NULL
				    && !gstrcmp(name, "us_class_info")) 
				{
					if (atoi(qoscpeId) !=
					    (qos_class + i)->iid.cpeId.Id) 
					{
						continue;
					}
					/* write the tuple here */
					switch ((qos_class + i)->classIf) 
					{
						case IFX_MAPI_QoS_LAN_ALL:
							sprintf(class_if, "%s", "LAN");
							break;
						case IFX_MAPI_QoS_LOCAL:
							sprintf(class_if, "%s",
								"LOCAL");
							break;
						case IFX_MAPI_QoS_ALL:
							sprintf(class_if, "%s",
								"LOCAL+LAN");
							break;
						default:
							sprintf(class_if, "%s", "");
							break;
					}
					switch ((qos_class + i)->IngIf) 
					{
						case IFX_MAPI_QoS_LAN_ALL:
							sprintf(ing_if, "%s", "LAN");
							break;
						case IFX_MAPI_QoS_WAN_ALL:
							sprintf(ing_if, "%s",
								"WAN");
							break;
						case IFX_MAPI_QoS_LAN_WIFI:
							sprintf(ing_if, "%s",
								"WLAN");
							break;
						default:
							break;
					}
					ifx_httpdWrite(wp, T("\"%s\",\"%d\",\"%d\",\"%d\",\"%d\""), (qos_class + i)->classifierName, (qos_class + i)->enable, (qos_class + i)->disableAccel, (qos_class + i)->order, (qos_class + i)->qId);	 

					if ((qos_class + i)->mfClass ==
					    IFX_MAPI_QoS_DSCP)
						ifx_httpdWrite(wp, T(",\"%s\""),
							       "DSCP");
					else if ((qos_class + i)->mfClass ==
						 IFX_MAPI_QoS_Multi_Field)
						ifx_httpdWrite(wp, T(",\"%s\""),
							       "MFC");
					else if ((qos_class + i)->mfClass ==
						 IFX_MAPI_QoS_P_Bits)
						ifx_httpdWrite(wp, T(",\"%s\""),
							       "802.1P");

					ifx_httpdWrite(wp, T(",\"%s\""),
						       class_if);
					ifx_httpdWrite(wp, T(",\"%s\""),
						       ing_if);

					if ((qos_class + i)->protoNum == 1)
						ifx_httpdWrite(wp, T(",\"%s\""),
							       "ICMP");
					else if ((qos_class + i)->protoNum ==
						 17)
						ifx_httpdWrite(wp, T(",\"%s\""),
							       "UDP");
					else if ((qos_class + i)->protoNum == 6)
						ifx_httpdWrite(wp, T(",\"%s\""),
							       "TCP");
					else
						ifx_httpdWrite(wp, T(",\"%s\""),
							       "-1");

					ifx_httpdWrite(wp, T(",\"%d\""),
						       (qos_class +
							i)->protoExcl);

					if ((qos_class + i)->L3protoNum == 1)
						ifx_httpdWrite(wp, T(",\"%s\""),
							       "IPv4");
					else if ((qos_class + i)->L3protoNum ==
						 2)
						ifx_httpdWrite(wp, T(",\"%s\""),
							       "IPv6");
					else
						ifx_httpdWrite(wp, T(",\"%s\""),
							       "-1");

					ifx_httpdWrite(wp, T(",\"%d\""),
						       (qos_class +
							i)->L3protoExcl);

					ifx_httpdWrite(wp,
						       T
						       (",\"%s\",\"%s\",\"%d\",\"%d\",\"%d\",\"%d\",\"%s\",\"%s\",\"%d\",\"%d\",\"%d\",\"%d\""),
						       (qos_class +
							i)->srcIP.ip,
						       (qos_class +
							i)->srcIP.mask,
						       (qos_class +
							i)->srcIPExcl,
						       (qos_class +
							i)->srcPortRange.
						       start_port,
						       (qos_class +
							i)->srcPortRange.
						       end_port,
						       (qos_class +
							i)->srcPortExcl,
						       (qos_class +
							i)->dstIP.ip,
						       (qos_class +
							i)->dstIP.mask,
						       (qos_class +
							i)->dstIPExcl,
						       (qos_class +
							i)->dstPortRange.
						       start_port,
						       (qos_class +
							i)->dstPortRange.
						       end_port,
						       (qos_class +
							i)->dstPortExcl);

					ifx_httpdWrite(wp,
						       T
						       (",\"%s\",\"%s\",\"%d\",\"%s\",\"%s\",\"%d\",\"%d\",\"%d\",\"%d\",\"%d\",\"%d\",\"%d\",\"%d\",\"%d\",\"%d\""),
						       (qos_class + i)->srcMac,
						       (qos_class +
							i)->srcMacMask,
						       (qos_class +
							i)->srcMacExcl,
						       (qos_class + i)->dstMac,
						       (qos_class +
							i)->dstMacMask,
						       (qos_class +
							i)->dstMacExcl,
						       (qos_class +
							i)->dscpCheck,
						       (qos_class +
							i)->dscpMark,
						       (qos_class +
							i)->iid.cpeId.Id,
						       (qos_class +
							i)->pBitsCheck,
						       (qos_class +
							i)->pBitsMark,
						       (qos_class +
							i)->vlanCheck,
						       (qos_class +
							i)->vlanExcl,
						       (qos_class + i)->rateLmt,
						       (qos_class +
							i)->rateCtrlEnbl);
					break;
				} /* End of US Class info */
				if (name != NULL && !gstrcmp(name, "show_one")) 
				{
					if (atoi(qoscpeId) !=
					    (qos_class + i)->iid.cpeId.Id) {
						continue;
					}
					bFound = 1;
				}

			/*	ifx_httpdWrite(wp,
					       "<tr><th class=\"curveLeft\" colspan=4><span class='cellWrapper'><img alt=\"\" src='images/RightCurve.png'></span>Configuration details of Classifier entry</td></tr>");
				// ifx_httpdWrite(wp, "<tr><td colspan=4><br></td></tr>");

				ifx_httpdWrite(wp, "<tr><td>%s</td><td>%s</td>",
					       "Classifier Name",
					       (qos_class + i)->classifierName);
				ifx_httpdWrite(wp,
					       T("<td>%s</td><td>%s</td></tr>"),
					       "Enable",
					       ((qos_class +
						 i)->enable) ? "Yes" : "No");

				ifx_httpdWrite(wp, "<tr><td>%s</td><td>",
					       "Classifier Type");
				switch ((qos_class + i)->mfClass) {
				case IFX_MAPI_QoS_Multi_Field:
					ifx_httpdWrite(wp,
						       T
						       ("Multi-field Based</td>"));
					break;
				case IFX_MAPI_QoS_DSCP:
					ifx_httpdWrite(wp,
						       T("DSCP Based</td>"));
					break;
				case IFX_MAPI_QoS_P_Bits:
					ifx_httpdWrite(wp,
						       T("802.1p Based</td>"));
					break;
				default:
					ifx_httpdWrite(wp, T("</td>"));
					break;
				}
				sprintf(cpeIdStr, "%d", (qos_class + i)->qId);
				if (ifx_get_another_fvp_from_dist_fvp
				    (TAG_IPQOS_QUEUE, "cpeId", cpeIdStr,
				     "qName", qName,
				     IFX_F_DEFAULT) != IFX_SUCCESS) {
					ifx_httpdWrite(wp,
						       T
						       ("<td>%s</td><td></td></tr>"),
						       "Queue Name");
				} else {
					ifx_httpdWrite(wp,
						       T
						       ("<td>%s</td><td>%s</td></tr>"),
						       "Queue Name", qName);
				}
				ifx_httpdWrite(wp, "<tr><td>%s</td><td>",
					       "Interface");
				switch ((qos_class + i)->classIf) {
				case IFX_MAPI_QoS_LAN_ALL:
					ifx_httpdWrite(wp, T("LAN</td>"));
					break;
				case IFX_MAPI_QoS_LOCAL:
					ifx_httpdWrite(wp, T("LOCAL</td>"));
					break;
				case IFX_MAPI_QoS_ALL:
					ifx_httpdWrite(wp, T("LAN+LOCAL</td>"));
					break;
					// case IFX_MAPI_QoS_WAN_ALL:
					//     ifx_httpdWrite(wp, T("WAN</td>"));
					//     break;
				default:
					ifx_httpdWrite(wp, T("</td>"));
					break;
				}
				ifx_httpdWrite(wp, T("</td>"));
				ifx_httpdWrite(wp,
					       T("<td>%s</td><td>%d</td></tr>"),
					       "Order", (qos_class + i)->order);

				ifx_httpdWrite(wp, T("<tr><td>%s</td><td>%d</td><td>%s</td><td>%s</td></tr>"), "Protocol", (qos_class + i)->protoNum */	/* TODO 
																			 *//* , "Exclude",
					       ((qos_class +
						 i)->protoExcl) ? "Yes" : "No");

				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"),
					       "Source IP",
					       (qos_class + i)->srcIP.ip,
					       "Exclude",
					       ((qos_class +
						 i)->srcIPExcl) ? "Yes" : "No");

				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"),
					       "Source MASK",
					       (qos_class + i)->srcIP.mask,
					       "Exclude",
					       ((qos_class +
						 i)->srcIPExcl) ? "Yes" : "No");

				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%d:%d</td><td>%s</td><td>%s</td></tr>"),
					       "Source Port",
					       (qos_class +
						i)->srcPortRange.start_port,
					       (qos_class +
						i)->srcPortRange.end_port,
					       "Exclude",
					       ((qos_class +
						 i)->
						srcPortExcl) ? "Yes" : "No");

				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"),
					       "Destination IP",
					       (qos_class + i)->dstIP.ip,
					       "Exclude",
					       ((qos_class +
						 i)->dstIPExcl) ? "Yes" : "No");
				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"),
					       "Destination Mask",
					       (qos_class + i)->dstIP.mask,
					       "Exclude",
					       ((qos_class +
						 i)->dstIPExcl) ? "Yes" : "No");

				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%d:%d</td><td>%s</td><td>%s</td></tr>"),
					       "Destination Port",
					       (qos_class +
						i)->dstPortRange.start_port,
					       (qos_class +
						i)->dstPortRange.end_port,
					       "Exclude",
					       ((qos_class +
						 i)->
						dstPortExcl) ? "Yes" : "No");

				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"),
					       "Source MAC",
					       (qos_class + i)->srcMac,
					       "Exclude",
					       ((qos_class +
						 i)->
						srcMacExcl) ? "Yes" : "No");

				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%d</td><td>&nbsp;</td><td>&nbsp;</td></tr>"),
					       "Incoming DSCP",
					       (qos_class + i)->dscpCheck);

				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%d</td><td>&nbsp;</td><td>&nbsp;</td></tr>"),
					       "Outgoing DSCP",
					       (qos_class + i)->dscpMark);

				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%d</td><td>&nbsp;</td><td>&nbsp;</td></tr>"),
					       "Incoming 802.1P",
					       (qos_class + i)->pBitsCheck);

				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%d</td><td>&nbsp;</td><td>&nbsp;</td></tr>"),
					       "Classifier Rate Limit",
					       (qos_class + i)->rateLmt);

				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%d</td><td>&nbsp;</td><td>&nbsp;</td></tr>"),
					       "Classifier Rate Control Enable",
					       (qos_class + i)->rateCtrlEnbl);

				if (bFound)
					break; */
			}
			}
		}
		IFX_MEM_FREE(qos_class)
	}

	
	void ifx_get_qos_ds_classifier(int eid, httpd_t wp, int argc, char_t ** argv) 
	{
		char_t *name = NULL, class_if[MAX_FILELINE_LEN], ing_if[MAX_FILELINE_LEN];
		char_t cpeIdStr[20], qName[MAX_NAME_LEN];
		int i = 0, bFound = 0, wan_class_count =
		    0 ;
		char_t sLine[256];
		WAN_PHY_CFG pstWanPhy;
		memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
		ifx_get_wan_phy_cfg(&pstWanPhy);
		IFX_MAPI_QoS_Classifier *Wqos_class = NULL;

		if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) 
		{
			ifx_httpdError(wp, 400, T("Insufficient args\n"));
			return;
		}

		if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2
		    && pstWanPhy.wan_tc == WAN_TC_ATM) 
		{
			if (ifx_mapi_get_all_qos_ds_classifier_if_specific
			    (IFX_MAPI_QoS_LAN_ATM, (uint32 *) & wan_class_count,
			     &Wqos_class, IFX_F_DEFAULT) != IFX_SUCCESS) 
			{
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to display configured PTM QoS classifiers"));
				IFX_MEM_FREE(Wqos_class)
				    return;
			}
		} 
		else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2
		    && pstWanPhy.wan_tc == WAN_TC_PTM) 
		{
			if (ifx_mapi_get_all_qos_ds_classifier_if_specific
			    (IFX_MAPI_QoS_LAN_PTM, (uint32 *) & wan_class_count,
			     &Wqos_class, IFX_F_DEFAULT) != IFX_SUCCESS) 
			{
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to display configured PTM QoS classifiers"));
				IFX_MEM_FREE(Wqos_class)
				    return;
			}
		}
		else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII0) 
		{
			if (ifx_mapi_get_all_qos_ds_classifier_if_specific
			    (IFX_MAPI_QoS_LAN_ETH_0, (uint32 *) & wan_class_count,
			     &Wqos_class, IFX_F_DEFAULT) != IFX_SUCCESS) 
			{
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to display configured PTM QoS classifiers"));
				IFX_MEM_FREE(Wqos_class)
				    return;
			}
		} 
		else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII1) 
		{
			if (ifx_mapi_get_all_qos_ds_classifier_if_specific
			    (IFX_MAPI_QoS_LAN_ETH_1, (uint32 *) & wan_class_count,
			     &Wqos_class,
			     IFX_F_DEFAULT) != IFX_SUCCESS) 
			{
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to display configured MII-1 QoS classifiers"));
				IFX_MEM_FREE(Wqos_class)
				return;
			}
			IFX_DBG("[%s:%d] class_count=%d ", __FUNCTION__,
				__LINE__, wan_class_count);
			//if (wan_class_count) {
			sprintf(sLine, "WAN_numClass=\"%d\"\n",
				wan_class_count);
			ifx_SetObjData("/tmp/system_status", "qos_bk",
				       IFX_F_INT_ADD, 1, sLine);
			//}
		} 
		else 
		{
			if (ifx_mapi_get_all_qos_ds_classifier_if_specific
			    (IFX_MAPI_QoS_LAN_PTM, (uint32 *) & wan_class_count,
			     &Wqos_class, IFX_F_DEFAULT) != IFX_SUCCESS) 
			{
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to display configured PTM QoS classifiers"));
				IFX_MEM_FREE(Wqos_class)
				    return;
			}
		}
		
		int j = 0;
		/* Handling for Dowstream Classifiers */
		if ((name) && (!gstrcmp(name, "ds_info"))) 
		{
			for (j = 0; j < wan_class_count; j++) 
			{
				IFX_DBG("[%s:%d] class_count=%d ", __FUNCTION__,
					__LINE__, wan_class_count);
				ifx_httpdWrite(wp,
					       "<input type=\"hidden\" name=\"cpeId%d\" value=\"%d\">",
					       j,
					       (Wqos_class + j)->iid.cpeId.Id);
				ifx_httpdWrite(wp,
					       "<tr><td id=\"qos_cname%d\">%s</td><td id=\"qos_corder%d\">%d</td>",
					       j,
					       (Wqos_class + j)->classifierName,
					       j, (Wqos_class + j)->order);
				if ((Wqos_class + j)->mfClass ==
				    IFX_MAPI_QoS_DSCP)
					ifx_httpdWrite(wp,
						       T
						       ("<td id=\"mfclass%d\">%s</td>"),
						       j, "DSCP");
				else if ((Wqos_class + j)->mfClass ==
					 IFX_MAPI_QoS_Multi_Field)
					ifx_httpdWrite(wp,
						       T
						       ("<td id=\"mfclass%d\">%s</td>"),
						       j, "MFC");
				else if ((Wqos_class + j)->mfClass ==
					 IFX_MAPI_QoS_P_Bits)
					ifx_httpdWrite(wp,
						       T
						       ("<td id=\"mfclass%d\">%s</td>"),
						       j, "802.1p");
				switch ((Wqos_class + j)->classIf) 
				{
					case IFX_MAPI_QoS_WAN:
						ifx_httpdWrite(wp,
						       T
						       ("<td id=\"classif%d\">%s</td>"),
						       j, "WAN");
					break;
					case IFX_MAPI_QoS_LOCAL:
						ifx_httpdWrite(wp,
						       T
						       ("<td id=\"classif%d\">%s</td>"),
						       j, "LOCAL");
					break;
					case IFX_MAPI_QoS_WAN_ALL:
						ifx_httpdWrite(wp,
						       T
						       ("<td id=\"classif%d\">%s</td>"),
						       j, "LOCAL+WAN");
					break;
					default:
						ifx_httpdWrite(wp,
						       T
						       ("<td id=\"classif%d\">%s</td>"),
						       j, "");
					break;
				}
				sprintf(cpeIdStr, "%d", (Wqos_class + j)->qId);
				if (ifx_get_another_fvp_from_dist_fvp
				    (TAG_IPQOS_QUEUE, "cpeId", cpeIdStr,
				     "qName", qName,
				     IFX_F_GET_ANY) != IFX_SUCCESS)
					ifx_httpdWrite(wp,
						       "<td id=\"qos_qname%d\">%s</td>",
						       j, "");
				else
					ifx_httpdWrite(wp,
						       "<td id=\"qos_qname%d\">%s</td>",
						       j, qName);
				ifx_httpdWrite(wp,
					       "<td id=\"qos_out_dscp%d\">%d</td><td id=\"qos_en%d\">%s</td>",
					       j, (Wqos_class + j)->dscpMark, j,
					       (Wqos_class + j)->enable ==
					       IFX_ENABLED ? "Yes" : "No");

				ifx_httpdWrite(wp,
					       "<td><input type='radio' name='ClassSelect'"
					       "value='%d'></td></tr>",
					       (Wqos_class + j)->iid.cpeId.Id);
			}
		}/* End of DS Info */

		else if (!gstrcmp(name, "ds_order")) 
		{
			for (j = 0; j < wan_class_count; j++) 
			{
				if ((Wqos_class + j)->mfClass ==
				    IFX_MAPI_QoS_Multi_Field)
					ifx_httpdWrite(wp,
						       T
						       ("<option value='%d'>%d</option>"),
						       (Wqos_class + j)->order,
						       (Wqos_class + j)->order);
			}
			//if (j == 0)
				ifx_httpdWrite(wp, T("%s"),
					       "<option value='-1' selected>Last</option>");
			//else
			//	ifx_httpdWrite(wp, T("%s"),
			//		       "<option value='-1'>Last</option>");
		} 
		else 
		{
			if (name != NULL && gstrcmp(name, "us_info") && gstrcmp(name, "ds_info"))
			{ 
			for (j = 0; j < wan_class_count; j++) 
			{

				if (name != NULL
				    && !gstrcmp(name, "ds_class_info")) 
				{
					if (atoi(qoscpeId) !=
					    (Wqos_class + j)->iid.cpeId.Id) 
					{
						continue;
					}
					/* write the tuple here */
					switch ((Wqos_class + j)->classIf) 
					{
						case IFX_MAPI_QoS_LOCAL:
							sprintf(class_if, "%s", "LOCAL");
						break;
						case IFX_MAPI_QoS_WAN:
							sprintf(class_if, "%s", "LOCAL+WAN");
						break;
						case IFX_MAPI_QoS_WAN_ALL:
							sprintf(class_if, "%s", "WAN");
						break;
						default:
							sprintf(class_if, "%s", "");
						break;
					}
					switch ((Wqos_class + j)->IngIf) 
					{
					case IFX_MAPI_QoS_LAN_ALL:
						sprintf(ing_if, "%s", "WAN");
						break;
					case IFX_MAPI_QoS_WAN_ALL:
						sprintf(ing_if, "%s",
							"LAN");
						break;
					case IFX_MAPI_QoS_LAN_WIFI:
						sprintf(ing_if, "%s",
							"WLAN");
						break;
					default:
						break;
					}
					ifx_httpdWrite(wp, T("\"%s\",\"%d\",\"%d\",\"%d\",\"%d\""), (Wqos_class + j)->classifierName, (Wqos_class + j)->enable, (Wqos_class + j)->disableAccel, (Wqos_class + j)->order, (Wqos_class + j)->qId);	 

					if ((Wqos_class + j)->mfClass ==
					    IFX_MAPI_QoS_DSCP)
						ifx_httpdWrite(wp, T(",\"%s\""),
							       "DSCP");
					else if ((Wqos_class + j)->mfClass ==
						 IFX_MAPI_QoS_Multi_Field)
						ifx_httpdWrite(wp, T(",\"%s\""),
							       "MFC");
					else if ((Wqos_class + j)->mfClass ==
						 IFX_MAPI_QoS_P_Bits)
						ifx_httpdWrite(wp, T(",\"%s\""),
							       "802.1P");

					ifx_httpdWrite(wp, T(",\"%s\""),
						       class_if);
					ifx_httpdWrite(wp, T(",\"%s\""),
						       ing_if);

					if ((Wqos_class + j)->protoNum == 1)
						ifx_httpdWrite(wp, T(",\"%s\""),
							       "ICMP");
					else if ((Wqos_class + j)->protoNum ==
						 17)
						ifx_httpdWrite(wp, T(",\"%s\""),
							       "UDP");
					else if ((Wqos_class + j)->protoNum ==
						 6)
						ifx_httpdWrite(wp, T(",\"%s\""),
							       "TCP");
					else
						ifx_httpdWrite(wp, T(",\"%s\""),
							       "-1");

					ifx_httpdWrite(wp, T(",\"%d\""),
						       (Wqos_class +
							j)->protoExcl);

					if ((Wqos_class + i)->L3protoNum == 1)
						ifx_httpdWrite(wp, T(",\"%s\""),
							       "IPv4");
					else if ((Wqos_class + i)->L3protoNum ==
						 2)
						ifx_httpdWrite(wp, T(",\"%s\""),
							       "IPv6");
					else
						ifx_httpdWrite(wp, T(",\"%s\""),
							       "-1");

					ifx_httpdWrite(wp, T(",\"%d\""),
						       (Wqos_class +
							i)->L3protoExcl);

					ifx_httpdWrite(wp,
						       T
						       (",\"%s\",\"%s\",\"%d\",\"%d\",\"%d\",\"%d\",\"%s\",\"%s\",\"%d\",\"%d\",\"%d\",\"%d\""),
						       (Wqos_class +
							j)->srcIP.ip,
						       (Wqos_class +
							j)->srcIP.mask,
						       (Wqos_class +
							j)->srcIPExcl,
						       (Wqos_class +
							j)->srcPortRange.
						       start_port,
						       (Wqos_class +
							j)->srcPortRange.
						       end_port,
						       (Wqos_class +
							j)->srcPortExcl,
						       (Wqos_class +
							j)->dstIP.ip,
						       (Wqos_class +
							j)->dstIP.mask,
						       (Wqos_class +
							j)->dstIPExcl,
						       (Wqos_class +
							j)->dstPortRange.
						       start_port,
						       (Wqos_class +
							j)->dstPortRange.
						       end_port,
						       (Wqos_class +
							j)->dstPortExcl);

					ifx_httpdWrite(wp,
						       T
						       (",\"%s\",\"%s\",\"%d\",\"%s\",\"%s\",\"%d\",\"%d\",\"%d\",\"%d\",\"%d\",\"%d\",\"%d\",\"%d\",\"%d\",\"%d\""),
						       (Wqos_class + j)->srcMac,
						       (Wqos_class +
							j)->srcMacMask,
						       (Wqos_class +
							j)->srcMacExcl,
						       (Wqos_class + j)->dstMac,
						       (Wqos_class +
							j)->dstMacMask,
						       (Wqos_class +
							j)->dstMacExcl,
						       (Wqos_class +
							j)->dscpCheck,
						       (Wqos_class +
							j)->dscpMark,
						       (Wqos_class +
							j)->iid.cpeId.Id,
						       (Wqos_class +
							j)->pBitsCheck,
						       (Wqos_class +
							j)->pBitsMark,
						       (Wqos_class +
							j)->vlanCheck,
						       (Wqos_class +
							j)->vlanExcl,
						       (Wqos_class +
							j)->rateLmt,
						       (Wqos_class +
							j)->rateCtrlEnbl);
					break;
				} /* End of DS class info */
				if (name != NULL && !gstrcmp(name, "show_one")) {
					if (atoi(qoscpeId) !=
					    (Wqos_class + j)->iid.cpeId.Id) {
						continue;
					}
					bFound = 1;
				}
				
		/*		ifx_httpdWrite(wp,
					       "<tr><th class=\"curveLeft\" colspan=4><span class='cellWrapper'><img alt=\"\" src='images/RightCurve.png'></span>Configuration details of Classifier entry</td></tr>");
				// ifx_httpdWrite(wp, "<tr><td colspan=4><br></td></tr>");

				ifx_httpdWrite(wp, "<tr><td>%s</td><td>%s</td>",
					       "Classifier Name",
					       (Wqos_class +
						j)->classifierName);
				ifx_httpdWrite(wp,
					       T("<td>%s</td><td>%s</td></tr>"),
					       "Enable",
					       ((Wqos_class +
						 j)->enable) ? "Yes" : "No");

				ifx_httpdWrite(wp, "<tr><td>%s</td><td>",
					       "Classifier Type");
				switch ((Wqos_class + j)->mfClass) {
				case IFX_MAPI_QoS_Multi_Field:
					ifx_httpdWrite(wp,
						       T
						       ("Multi-field Based</td>"));
					break;
				case IFX_MAPI_QoS_DSCP:
					ifx_httpdWrite(wp,
						       T("DSCP Based</td>"));
					break;
				case IFX_MAPI_QoS_P_Bits:
					ifx_httpdWrite(wp,
						       T("802.1p Based</td>"));
					break;
				default:
					ifx_httpdWrite(wp, T("</td>"));
					break;
				}
				sprintf(cpeIdStr, "%d", (Wqos_class + j)->qId);
				if (ifx_get_another_fvp_from_dist_fvp
				    (TAG_IPQOS_QUEUE, "cpeId", cpeIdStr,
				     "qName", qName,
				     IFX_F_DEFAULT) != IFX_SUCCESS) {
					ifx_httpdWrite(wp,
						       T
						       ("<td>%s</td><td></td></tr>"),
						       "Queue Name");
				} else {
					ifx_httpdWrite(wp,
						       T
						       ("<td>%s</td><td>%s</td></tr>"),
						       "Queue Name", qName);
				}
				ifx_httpdWrite(wp, "<tr><td>%s</td><td>",
					       "Interface");
				switch ((Wqos_class + j)->classIf) {
				case IFX_MAPI_QoS_WAN:
					ifx_httpdWrite(wp, T("WAN</td>"));
					break;
				case IFX_MAPI_QoS_LOCAL:
					ifx_httpdWrite(wp, T("LOCAL</td>"));
					break;
				case IFX_MAPI_QoS_WAN_ALL:
					ifx_httpdWrite(wp, T("LOCAL+WAN</td>"));
					break;
				default:
					ifx_httpdWrite(wp, T("</td>"));
					break;
				}
				ifx_httpdWrite(wp, T("</td>"));
				ifx_httpdWrite(wp,
					       T("<td>%s</td><td>%d</td></tr>"),
					       "Order",
					       (Wqos_class + j)->order);

				ifx_httpdWrite(wp, T("<tr><td>%s</td><td>%d</td><td>%s</td><td>%s</td></tr>"), "Protocol", (Wqos_class + j)->protoNum */	/* TODO 
																			 *//* , "Exclude",
					       ((Wqos_class +
						 j)->protoExcl) ? "Yes" : "No");

				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"),
					       "Source IP",
					       (Wqos_class + j)->srcIP.ip,
					       "Exclude",
					       ((Wqos_class +
						 j)->srcIPExcl) ? "Yes" : "No");

				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"),
					       "Source MASK",
					       (Wqos_class + j)->srcIP.mask,
					       "Exclude",
					       ((Wqos_class +
						 j)->srcIPExcl) ? "Yes" : "No");

				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%d:%d</td><td>%s</td><td>%s</td></tr>"),
					       "Source Port",
					       (Wqos_class +
						j)->srcPortRange.start_port,
					       (Wqos_class +
						j)->srcPortRange.end_port,
					       "Exclude",
					       ((Wqos_class +
						 j)->
						srcPortExcl) ? "Yes" : "No");

				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"),
					       "Destination IP",
					       (Wqos_class + j)->dstIP.ip,
					       "Exclude",
					       ((Wqos_class +
						 j)->dstIPExcl) ? "Yes" : "No");
				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"),
					       "Destination Mask",
					       (Wqos_class + j)->dstIP.mask,
					       "Exclude",
					       ((Wqos_class +
						 j)->dstIPExcl) ? "Yes" : "No");

				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%d:%d</td><td>%s</td><td>%s</td></tr>"),
					       "Destination Port",
					       (Wqos_class +
						j)->dstPortRange.start_port,
					       (Wqos_class +
						j)->dstPortRange.end_port,
					       "Exclude",
					       ((Wqos_class +
						 j)->
						dstPortExcl) ? "Yes" : "No");

				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"),
					       "Source MAC",
					       (Wqos_class + j)->srcMac,
					       "Exclude",
					       ((Wqos_class +
						 j)->
						srcMacExcl) ? "Yes" : "No");

				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%d</td><td>&nbsp;</td><td>&nbsp;</td></tr>"),
					       "Incoming DSCP",
					       (Wqos_class + j)->dscpCheck);

				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%d</td><td>&nbsp;</td><td>&nbsp;</td></tr>"),
					       "Outgoing DSCP",
					       (Wqos_class + j)->dscpMark);

				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%d</td><td>&nbsp;</td><td>&nbsp;</td></tr>"),
					       "Incoming 802.1P",
					       (Wqos_class + j)->pBitsCheck);

				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%d</td><td>&nbsp;</td><td>&nbsp;</td></tr>"),
					       "Classifier Rate Limit",
					       (Wqos_class + j)->rateLmt);

				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%s</td><td>%d</td><td>&nbsp;</td><td>&nbsp;</td></tr>"),
					       "Classifier Rate Control Enable",
					       (Wqos_class + j)->rateCtrlEnbl);

				if (bFound)
					break;*/
			}
			}
		}
		IFX_MEM_FREE(Wqos_class)
	}

	void ifx_get_qos_operation(int eid, httpd_t wp, int argc,
				   char_t ** argv) {
		ifx_httpdWrite(wp, T("%s"), qosOperation);
	}
#endif				// CONFIG_FEATURE_IFX_IPQOS

#ifdef CONFIG_FEATURE_QOS
	int ifx_get_qos_status(int eid, httpd_t wp, int argc, char_t ** argv) {
		char_t sValue[MAX_FILELINE_LEN];
		char_t *name;	// 000001:tc.chen

		// 000001:tc.chen start
		if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
			ifx_httpdError(wp, 400, T("Insufficient args\n"));
			return -1;
		}
		// 000001:tc.chen end
		sValue[0] = '\0';

		if (!gstrcmp(name, T("QoS")))	// 000001:tc.chen
		{		// 000001:tc.chen
			if (ifx_GetCfgData
			    (FILE_RC_CONF, TAG_QOS_CONFIG, T("QOS_ENABLE"),
			     sValue) == 1) {
				if (!gstrcmp(sValue, "1")) {
					gstrcpy(sValue, "1");
				} else {
					gstrcpy(sValue, "0");
				}
			}
// 000001:tc.chen start add qos priority enable/disable option
		}
#ifdef CONFIG_FEATURE_QOS_PRIORITY_QUEUE
		if (!gstrcmp(name, T("Prio"))) {
			if (ifx_GetCfgData
			    (FILE_RC_CONF, TAG_QOS_CONFIG, T("QOS_PRIO"),
			     sValue) == 1) {
				if (!gstrcmp(sValue, "1")) {
					gstrcpy(sValue, "1");
				} else {
					gstrcpy(sValue, "0");
				}
			} else {
				gstrcpy(sValue, "0");
			}
		}
#endif				// CONFIG_FEATURE_QOS_PRIORITY_QUEUE
		if (!gstrcmp(name, T("Priority_queue_module_begin"))) {
#ifdef CONFIG_FEATURE_QOS_PRIORITY_QUEUE
			gstrcpy(sValue, " ");
#else
			gstrcpy(sValue, "document.write(\"<!--\");");
#endif
		}
		if (!gstrcmp(name, T("Priority_queue_module_end"))) {
#ifdef CONFIG_FEATURE_QOS_PRIORITY_QUEUE
			gstrcpy(sValue, " ");
#else
			gstrcpy(sValue, "document.write(\"-->\");");
#endif
		}
		// 507283:tc.chen start
		if (!gstrcmp(name, T("Qos_Voip_module_begin"))) {
#ifdef CONFIG_FEATURE_IFX_VOIP
			gstrcpy(sValue, " ");
#else
			gstrcpy(sValue, "document.write(\"<!--\");");
#endif
		}
		if (!gstrcmp(name, T("Qos_Voip_module_end"))) {
#ifdef CONFIG_FEATURE_IFX_VOIP
			gstrcpy(sValue, " ");
#else
			gstrcpy(sValue, "document.write(\"-->\");");
#endif
		}
		// 507283:tc.chen end

//000001:tc.chen end

		ifx_httpdWrite(wp, T("%s"), sValue);
		return 0;
	}

/////////////////////////////////////////////////////////////////////////////
// 510251: sumedh start (ALGs)
//              PAGE : qos_alg.asp
	int ifx_get_algmin(int eid, httpd_t wp, int argc, char_t ** argv) {
		char_t sValue[MAX_DATA_LEN];
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_ALG, T("ALG_MINBW"), sValue) == 1) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		} else {
			ifx_httpdWrite(wp, T("0"));
		}
		return 0;
	}

	int ifx_get_vsmin(int eid, httpd_t wp, int argc, char_t ** argv) {
		char_t sValue[MAX_DATA_LEN];
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_NAT_VIRTUALSER, T("VS_MINBW"),
		     sValue) == 1) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		} else {
			ifx_httpdWrite(wp, T("0"));
		}
		return 0;
	}

	int ifx_get_qos_algs(int eid, httpd_t wp, int argc, char_t ** argv) {
		// char_t *name;
		char_t buf[MAX_DATA_LEN];
		char_t sValue[MAX_FILELINE_LEN];
		int i;
		int alg_qos_enable = 0;
		struct alg_struct_t {
			char_t statusName[32];
			char_t qosStatusName[32];
			char_t up_minBWName[32];
			char_t up_maxBWName[32];
			char_t dwn_maxBWName[32];
			char_t displayName[32];
		};
		struct alg_struct_t alg_struct[] = {
			{"NETMEETING_STATUS", "NETMEETING_QOS",
			 "UP_NETMEETING_MINBW",
			 "UP_NETMEETING_MAXBW", "DWN_NETMEETING_MAXBW",
			 "Netmeeting"},
			{"PPTP_STATUS", "PPTP_QOS", "UP_PPTP_MINBW",
			 "UP_PPTP_MAXBW",
			 "DWN_PPTP_MAXBW", "PPTP"}, {"RTSP_STATUS", "RTSP_QOS",
						     "UP_RTSP_MINBW",
						     "UP_RTSP_MAXBW",
						     "DWN_RTSP_MAXBW",
						     "RTSP/RTP"},
			{"FTP_STATUS", "FTP_QOS", "UP_FTP_MINBW",
			 "UP_FTP_MAXBW",
			 "DWN_FTP_MAXBW", "FTP"}, {"IPSEC_STATUS", "IPSEC_QOS",
						   "UP_IPSEC_MINBW",
						   "UP_IPSEC_MAXBW",
						   "DWN_IPSEC_MAXBW", "IPSec"},
			{"ICMP_STATUS", "ICMP_QOS", "UP_ICMP_MINBW",
			 "UP_ICMP_MAXBW",
			 "DWN_ICMP_MAXBW", "ICMP"}, {"SIP_STATUS", "SIP_QOS",
						     "UP_SIP_MINBW",
						     "UP_SIP_MAXBW",
						     "DWN_SIP_MAXBW", "SIP"}
//510251:sumedh (commented out as backend is not complete)
		};
		char_t getCommand[MAX_FILELINE_LEN];
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t<table border=0 cellspacing=1 cellpadding=5 width=225>\n"));
		ifx_httpdWrite(wp, T("\t\t\t<tr class=\"celltitle\">\n"));

		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t\t<th nowrap rowspan=\"3\">&nbsp;</th>\n"));
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t\t<th nowrap rowspan=\"3\">ALG</th>\n"));

		sValue[0] = '\0';
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_QOS_CONFIG, T("QOS_ENABLE"), sValue)
		    != 0) {
			if (!gstrcmp(sValue, "1")) {
				sValue[0] = '\0';
				if (ifx_GetCfgData
				    (FILE_RC_CONF, TAG_QOS_DIFFSERV_CONFIG,
				     T("QOS_ALG"), sValue) != 0) {
					if (!gstrcmp(sValue, "1")) {
						alg_qos_enable = 1;
						ifx_httpdWrite(wp,
							       T
							       ("\t\t\t\t<th nowrap colspan=\"4\">QoS</th>\n"));
					}
				}
			}
		}
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t</tr>\n\t\t\t<tr class=\"celltitle\">\n"));
		if (alg_qos_enable) {
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t<th nowrap rowspan=\"2\">Enable</th>\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t<th nowrap colspan=\"2\">Up Stream</th>\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t<th nowrap>Down Stream</th>\n"));

			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t</tr>\n\t\t\t<tr class=\"celltitle\">\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t<th nowrap>Min.Bandwidth</th>\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t<th nowrap>Max.Bandwidth</th>\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t<th nowrap>Max.Bandwidth</th>\n"));
		}
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t</tr><tr></tr>\n\t\t\t<font size=\"2\" face=\"Arial, Helvetica, sans-serif\">\n"));
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t<input type=\"hidden\" name=\"alg_qos_enable\" value=\"%d\">\n"),
			       alg_qos_enable);

		for (i = 0;
		     i < sizeof(alg_struct) / (sizeof(struct alg_struct_t));
		     i++) {
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t<tr align=center bgcolor=#ffffff>\n"));
			ifx_httpdWrite(wp, T("\t\t\t\t<td nowrap>%d</td>\n"),
				       i + 1);

			ifx_httpdWrite(wp, T("\t\t\t\t<td nowrap>%s"),
				       alg_struct[i].displayName);
			buf[0] = '\0';
			sValue[0] = '\0';

			if (alg_qos_enable) {
				ifx_httpdWrite(wp, T("\t\t\t\t<td nowrap>"));
				gsprintf(buf, T("%s"),
					 alg_struct[i].qosStatusName);
				if ((ifx_GetCfgData
				     (FILE_RC_CONF, TAG_ALG, buf, sValue) == 0)
				    || (gstrcmp(sValue, "1")))
					ifx_httpdWrite(wp,
						       T
						       ("<input type=\"checkbox\" name=\"%s\" value=\"1\"></td>\n"),
						       buf);
				else
					ifx_httpdWrite(wp,
						       T
						       ("<input type=\"checkbox\" name=\"%s\" value=\"1\"%s></td>\n"),
						       buf, " CHECKED");

				ifx_httpdWrite(wp, T("\t\t\t\t<td nowrap>"));
				gsprintf(buf, T("%s"),
					 alg_struct[i].up_minBWName);
				gsprintf(getCommand,
					 T("grep \"%s\" %s | cut -f2 -d\\\""),
					 buf, FILE_RC_CONF);
				if (ifx_GetCfgData
				    ((char_t *) getCommand, NULL, "1",
				     sValue) == 0)
					ifx_httpdWrite(wp,
						       T
						       ("<input maxLength=\"3\" name=\"%s\" size=\"6\" value=\"\">%%</td>\n"),
						       buf);
				else
					ifx_httpdWrite(wp,
						       T
						       ("<input maxLength=\"3\" name=\"%s\" size=\"6\" value=\"%s\">%%</td>\n"),
						       buf, sValue);

				ifx_httpdWrite(wp, T("\t\t\t\t<td nowrap>"));
				gsprintf(buf, T("%s"),
					 alg_struct[i].up_maxBWName);
				gsprintf(getCommand,
					 T("grep \"%s\" %s | cut -f2 -d\\\""),
					 buf, FILE_RC_CONF);
				if (ifx_GetCfgData
				    ((char_t *) getCommand, NULL, "1",
				     sValue) == 0)
					ifx_httpdWrite(wp,
						       T
						       ("<input maxLength=\"3\" name=\"%s\" size=\"6\" value=\"\">%%</td>\n"),
						       buf);
				else
					ifx_httpdWrite(wp,
						       T
						       ("<input maxLength=\"3\" name=\"%s\" size=\"6\" value=\"%s\">%%</td>\n"),
						       buf, sValue);

				ifx_httpdWrite(wp, T("\t\t\t\t<td nowrap>"));
				buf[0] = '\0';
				sValue[0] = '\0';
				gsprintf(buf, T("%s"),
					 alg_struct[i].dwn_maxBWName);
				getCommand[0] = '\0';
				gsprintf(getCommand,
					 T("grep \"%s\" %s | cut -f2 -d\\\""),
					 buf, FILE_RC_CONF);
				if (ifx_GetCfgData
				    ((char_t *) getCommand, NULL, "1",
				     sValue) == 0)
					ifx_httpdWrite(wp,
						       T
						       ("<input maxLength=\"3\" name=\"%s\" size=\"6\" value=\"\">%%</td>\n"),
						       buf);
				else
					ifx_httpdWrite(wp,
						       T
						       ("<input maxLength=\"3\" name=\"%s\" size=\"6\" value=\"%s\">%%</td>\n"),
						       buf, sValue);
			}
			// Get f# value from rc.conf file.
			gsprintf(buf, T("%s"), alg_struct[i].statusName);
//Nirav : Currently, user is not allowed to disable ALGS
#if 1
			if ((ifx_GetCfgData(FILE_RC_CONF, TAG_ALG, buf, sValue)
			     == 0)
			    || (gstrcmp(sValue, "1")))
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t\t<input type=\"hidden\" name=\"%s\" value=\"0\"></td>\n"),
					       buf);
			else
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t\t<input type=\"hidden\" name=\"%s\" value=\"1\"></td>\n"),
					       buf);
#endif

			ifx_httpdWrite(wp, T("\t\t\t</tr>\n"));
		}

		ifx_httpdWrite(wp, T("\t\t\t</font>\n\t\t\t</table>\n"));
		return 0;
	}
// 510251: sumedh end (ALGs)

/////////////////////////////////////////////////////////////////////////////
// 510251: sumedh start (ALGs)
//              PAGE : qos_main.asp
	int ifx_get_qos_alg_setting(int eid, httpd_t wp, int argc,
				    char_t ** argv) {
		char_t *name, sValue[MAX_FILELINE_LEN];

		if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
			ifx_httpdError(wp, 400, T("Insufficient args\n"));
			return -1;
		}

		if (!gstrcmp(name, T("QOS_ALG"))) {
			if (ifx_GetCfgData
			    (FILE_RC_CONF, TAG_QOS_DIFFSERV_CONFIG, "QOS_ALG",
			     sValue) == 1) {
				if (!gstrcmp(sValue, "1"))
					ifx_httpdWrite(wp, T("checked"));
				else
					ifx_httpdWrite(wp, T(""));
			}
		}
		return 0;
	}
// 510251: sumedh end (ALGs)

	int ifx_get_qos_diffserv_setting(int eid, httpd_t wp, int argc,
					 char_t ** argv) {
		char_t *name, sValue[MAX_FILELINE_LEN];

		if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
			ifx_httpdError(wp, 400, T("Insufficient args\n"));
			return -1;
		}

#ifdef CONFIG_FEATURE_IFX_VOIP
		if (!gstrcmp(name, T("DsVoip"))) {
			if (ifx_GetCfgData
			    (FILE_RC_CONF, TAG_QOS_DIFFSERV_CONFIG,
			     "DIFFSERV_DUT_VOIP", sValue) == 1) {
				if (!gstrcmp(sValue, "1"))
					ifx_httpdWrite(wp, T("checked"));
				else
					ifx_httpdWrite(wp, T(""));
			}
		} else
#endif
		if (!gstrcmp(name, T("DsVs"))) {
			if (ifx_GetCfgData
			    (FILE_RC_CONF, TAG_QOS_DIFFSERV_CONFIG,
			     "DIFFSERV_VIRTUAL_SERVER", sValue) == 1) {
				if (!gstrcmp(sValue, "1"))
					ifx_httpdWrite(wp, T("checked"));
				else
					ifx_httpdWrite(wp, T(""));
			}
		}
#ifdef CONFIG_FEATURE_QOS_PRIORITY_QUEUE
#ifdef CONFIG_FEATURE_QOS_IPPTOS
		if (!gstrcmp(name, T("QOS_IPPTOS"))) {
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_QOS_DIFFSERV_CONFIG,
			     "QOS_IPPTOS", 0, NULL, sValue) == IFX_SUCCESS) {
				if (!gstrcmp(sValue, "1"))
					ifx_httpdWrite(wp, T("checked"));
				else
					ifx_httpdWrite(wp, T(""));
			}
		}
#endif
#ifdef CONFIG_FEATURE_QOS_8021P
		if (!gstrcmp(name, T("QOS_8021P"))) {
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_QOS_DIFFSERV_CONFIG, "QOS_8021P",
			     0, NULL, sValue) == IFX_SUCCESS) {
				if (!gstrcmp(sValue, "1"))
					ifx_httpdWrite(wp, T("checked"));
				else
					ifx_httpdWrite(wp, T(""));
			}
		}
#endif
#endif				// CONFIG_FEATURE_QOS_PRIORITY_QUEUE
// 000001:tc.chen end

		return 0;
	}

#ifdef CONFIG_FEATURE_QOS_PRIORITY_QUEUE
// 000001:tc.chen start get qos proirity rule from system configuration to web page
	int ifx_get_qos_priority(int eid, httpd_t wp, int argc, char_t ** argv) {
		char_t *name;
		int i = 0, nQoSPriority_Size = 0, j = 0;
		CGI_TABLE_S QoSPriorityTable[QOS_PRIORITY_TABLE_NUM];
		struct in_addr nm;
		int nm_bits;
		if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
			ifx_httpdError(wp, 400, T("Insufficient args\n"));
			return -1;
		}

		if (!gstrcmp(name, T("Info"))) {
			// get qos priority setting from system configuration data
			// and
			// store to QoSPriorityTable
			nQoSPriority_Size =
			    websGetCfgData2Table(wp, FILE_RC_CONF,
						 TAG_QOS_PRIORITY,
						 PREFIX_QOS_PRIORITY,
						 QoSPriorityTable,
						 QOS_PRIORITY_TABLE_TYPE);
			for (i = 0;
			     i < nQoSPriority_Size
			     && i < QOS_PRIORITY_TABLE_NUM; i++) {
				int lan_if = 0;
				ifx_httpdWrite(wp,
					       T
					       ("<tr bgcolor=\"#ffffff\" align=left>\n"));
				ifx_httpdWrite(wp,
					       T
					       ("<td nowrap align=center>%d</td>\n"),
					       i + 1);
				ifx_httpdWrite(wp,
					       T
					       ("<td nowrap align=center><font size=\"2\" face=\"Arial, Helvetica, sans-serif\">"));
				lan_if =
				    atoi(QoSPriorityTable[i].Data.QP_TABLE.
					 sQP_IF);
				// lan_if:1~4: switch port 0~3, 5:WLAN interface 0: All lan
				// IF
				switch (lan_if) {
				case 1:
				case 2:
				case 3:
				case 4:
					ifx_httpdWrite(wp, "Port%d",
						       lan_if - 1);
					break;
				case 5:
					ifx_httpdWrite(wp, "WLAN");
					break;
				case 0:
				default:
					ifx_httpdWrite(wp, "ALL\n");
					break;
				}
				ifx_httpdWrite(wp, "</font></td>\n");
				ifx_httpdWrite(wp,
					       T
					       ("<td nowrap align=center><font size=\"2\" face=\"Arial, Helvetica, sans-serif\">"));
				if (!strcmp
				    (QoSPriorityTable[i].Data.QP_TABLE.
				     sQP_PROTO, "tcp")) {
					ifx_httpdWrite(wp, T("TCP</font>\n"));
				} else if (!strcmp
					   (QoSPriorityTable[i].Data.QP_TABLE.
					    sQP_PROTO, "udp")) {
					ifx_httpdWrite(wp, T("UDP</font>\n"));
				}
				// show source IP
				ifx_httpdWrite(wp,
					       T
					       ("<td nowrap align=center><font face=\"Arial, Helvetica, sans-serif\" size=\"2\">"));
				nm_bits =
				    atoi(QoSPriorityTable[i].Data.QP_TABLE.
					 sQP_IP_SRC_MASK);
				if (gstrcmp
				    (QoSPriorityTable[i].Data.QP_TABLE.
				     sQP_IP_SRC_IP, "*")
				    && nm_bits > 0 && nm_bits < 32) {
					ifx_httpdWrite(wp,
						       T("%s/%d</font></td>\n"),
						       QoSPriorityTable[i].Data.
						       QP_TABLE.sQP_IP_SRC_IP,
						       atoi(QoSPriorityTable[i].
							    Data.QP_TABLE.
							    sQP_IP_SRC_MASK));
				} else {
					ifx_httpdWrite(wp,
						       T("%s</font></td>\n"),
						       QoSPriorityTable[i].Data.
						       QP_TABLE.sQP_IP_SRC_IP);
				}

				// show source port
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t<td nowrap align=center><font size=\"2\" face=\"Arial, Helvetica, sans-serif\">"));
				// check if PORT SRC_START is same as PORT SRC_END
				if (gstrlen
				    (QoSPriorityTable[i].Data.QP_TABLE.
				     sQP_PORT_SRC_END)
				    == 0
				    || gatoi(QoSPriorityTable[i].Data.QP_TABLE.
					     sQP_PORT_SRC_START) ==
				    gatoi(QoSPriorityTable[i].Data.QP_TABLE.
					  sQP_PORT_SRC_END)) {
					// only show PORT_START
					ifx_httpdWrite(wp,
						       T("%s</font></td>\n"),
						       QoSPriorityTable[i].Data.
						       QP_TABLE.
						       sQP_PORT_SRC_START);
				} else {
					// show PORT RANGE
					ifx_httpdWrite(wp,
						       T("%s~%s</font></td>\n"),
						       QoSPriorityTable[i].Data.
						       QP_TABLE.
						       sQP_PORT_SRC_START,
						       QoSPriorityTable[i].Data.
						       QP_TABLE.
						       sQP_PORT_SRC_END);
				}

				// show destination IP
				ifx_httpdWrite(wp,
					       T
					       ("<td nowrap align=center><font face=\"Arial, Helvetica, sans-serif\" size=\"2\">"));
				nm_bits =
				    atoi(QoSPriorityTable[i].Data.QP_TABLE.
					 sQP_IP_DST_MASK);
				if (gstrcmp
				    (QoSPriorityTable[i].Data.QP_TABLE.
				     sQP_IP_DST_IP, "*")
				    && nm_bits > 0 && nm_bits < 32) {
					nm.s_addr = bits2netmask
					    (atoi
					     (QoSPriorityTable[i].Data.QP_TABLE.
					      sQP_IP_DST_MASK));
					// ifx_httpdWrite(wp, T("%s/%s</font></td>\n"),
					// QoSPriorityTable[i].Data.QP_TABLE.sQP_IP_DST_IP,inet_ntoa(nm));
					ifx_httpdWrite(wp,
						       T("%s/%d</font></td>\n"),
						       QoSPriorityTable[i].Data.
						       QP_TABLE.sQP_IP_DST_IP,
						       atoi(QoSPriorityTable[i].
							    Data.QP_TABLE.
							    sQP_IP_DST_MASK));
				} else {
					ifx_httpdWrite(wp,
						       T("%s</font></td>\n"),
						       QoSPriorityTable[i].Data.
						       QP_TABLE.sQP_IP_DST_IP);
				}

				// show distination port
				ifx_httpdWrite(wp,
					       T
					       ("<td nowrap align=center><font size=\"2\" face=\"Arial, Helvetica, sans-serif\">"));
				// check if PORT DST_START is same as PORT DST_END
				if (gstrlen
				    (QoSPriorityTable[i].Data.QP_TABLE.
				     sQP_PORT_DST_END)
				    == 0
				    || gatoi(QoSPriorityTable[i].Data.QP_TABLE.
					     sQP_PORT_DST_START)
				    == gatoi(QoSPriorityTable[i].Data.QP_TABLE.
					     sQP_PORT_DST_END)) {
					// only show PORT_START
					ifx_httpdWrite(wp,
						       T("%s</font></td>\n"),
						       QoSPriorityTable[i].Data.
						       QP_TABLE.
						       sQP_PORT_DST_START);
				} else {
					// show PORT RANGE
					ifx_httpdWrite(wp,
						       T("%s~%s</font></td>\n"),
						       QoSPriorityTable[i].Data.
						       QP_TABLE.
						       sQP_PORT_DST_START,
						       QoSPriorityTable[i].Data.
						       QP_TABLE.
						       sQP_PORT_DST_END);
				}

				// show packet direction (Upstream/Downstream)
				ifx_httpdWrite(wp,
					       T
					       ("<td nowrap align=center><font size=\"2\" face=\"Arial, Helvetica, sans-serif\">"));
				if (atoi
				    (QoSPriorityTable[i].Data.QP_TABLE.
				     sQP_DIR)) {
					ifx_httpdWrite(wp,
						       T("Down</font></td>\n"));
				} else {
					ifx_httpdWrite(wp,
						       T("Up</font></td>\n"));
				}

				// show apply to which priority type
				ifx_httpdWrite(wp,
					       T
					       ("<td nowrap align=center><font size=\"2\" face=\"Arial, Helvetica, sans-serif\">\n"));
				switch (atoi
					(QoSPriorityTable[i].Data.QP_TABLE.
					 sQP_TYPE)) {
#ifdef CONFIG_FEATURE_QOS_8021P
				case 1:
					ifx_httpdWrite(wp, T("802.1P"));
					break;
#endif
#ifdef CONFIG_FEATURE_QOS_IPPTOS
				case 2:
					ifx_httpdWrite(wp, T("IP"));
					break;
#endif
#if defined(CONFIG_FEATURE_QOS_8021P) && defined (CONFIG_FEATURE_QOS_IPPTOS)
				case 3:
					ifx_httpdWrite(wp, T("ALL"));
					break;
#endif
				case 0:
				default:
					ifx_httpdWrite(wp, T("None"));
					break;
				}
				ifx_httpdWrite(wp, T("</font></td>\n"));
// show priority
				ifx_httpdWrite(wp,
					       T
					       ("<td><select name=\"QP_PRIO%d\" size=\"1\">\n"),
					       i);
				for (j = 0; j < 8; j++) {
					ifx_httpdWrite(wp,
						       T
						       ("<option value=\"%d\" %s>%d</option>\n"),
						       j,
						       j ==
						       QoSPriorityTable[i].
						       nState ? "selected" :
						       " ", j);
				}
				ifx_httpdWrite(wp,
					       T
					       ("<option value=\"%d\" %s>Disable</option>\n"),
					       j,
					       j ==
					       QoSPriorityTable[i].
					       nState ? "selected" : " ");
				ifx_httpdWrite(wp, T("</select></td>\n"));
				// add delete button
				ifx_httpdWrite(wp,
					       T("<td nowrap align=center>\n"));
				if (i < nQoSPriority_Size) {
					ifx_httpdWrite(wp,
						       T
						       ("<input type=\"button\" name=\"QP_DEL%d\" value=\" Delete \" onClick=\"return delEntry(%d);\">\n"),
						       i, i);
				}
				ifx_httpdWrite(wp, T("\t\t\t\t</td></tr>\n"));
			}	// enf
			// for
		}

		return 0;
	}
#endif				// CONFIG_FEATURE_QOS_PRIORITY_QUEUE
//000001:tc.chen end

//#endif //CONFIG_FEATURE_DIFFSERV

#else

	int ifx_get_algmin(int eid, httpd_t wp, int argc, char_t ** argv) {
		ifx_httpdWrite(wp, T("0"));
		return 0;
	}
#endif				// CONFIG_FEATURE_QOS

//manohar 
	int ifx_get_queue_count(int eid, httpd_t wp, int argc, char_t ** arg_v) {

		int count = 0;
		IFX_MAPI_QoS_Interface_Type ifType;
		ifType = ifx_mapi_get_active_qos_iface();
		count = ifx_mapi_get_queue_count_for_wan_mode(ifType);
		ifx_httpdWrite(wp, T("%d"), count);
		return IFX_SUCCESS;
	}
	//Shashi
	int ifx_get_lan_queue_count(int eid, httpd_t wp, int argc,
				    char_t ** arg_v) {

		int count = 0;
		IFX_MAPI_QoS_Interface_Type ifType;
		ifType = IFX_MAPI_QoS_LAN_ETH;
		count = ifx_mapi_get_queue_count_for_wan_mode(ifType);
		ifx_httpdWrite(wp, T("%d"), count);
		return IFX_SUCCESS;
	}
	//Shashi

	int ifx_get_qos_count(int eid, httpd_t wp, int argc, char_t ** arg_v) {
		WAN_PHY_CFG pstWanPhy;
		memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
		ifx_get_wan_phy_cfg(&pstWanPhy);
		if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2
		    && pstWanPhy.wan_tc == WAN_TC_ATM) {
			if (ifx_mapi_get_queue_add_check(IFX_MAPI_QoS_WAN_ATM)
			    != IFX_SUCCESS) {
				ifx_httpdWrite(wp, T("%d"), 0);
				return IFX_SUCCESS;
			}
		}
		if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2
		    && pstWanPhy.wan_tc == WAN_TC_PTM) {
			if (ifx_mapi_get_queue_add_check(IFX_MAPI_QoS_WAN_PTM)
			    != IFX_SUCCESS) {
				ifx_httpdWrite(wp, T("%d"), 0);
				return IFX_SUCCESS;
			}
		}
		ifx_httpdWrite(wp, T("%d"), 1);
		return IFX_SUCCESS;
	}

	int ifx_get_qos_channel(int eid, httpd_t wp, int argc, char_t ** arg_v) {
#if 0				// TBD TODO: -- rakha
		char8 sWAN_VCC[MAX_NAME_SIZE];
		char_t vcc_selected[8] = { 0 }, writeBuf[MAX_DATA_LEN] = {
		0}, atm_qmode[8] = {
		0};
		int ret = IFX_SUCCESS, i = 0, wan_count = 0, bFlag = 0;
		uint32 outFlag = IFX_F_DEFAULT;
		WAN_CONN_CFG *wan_cfg = NULL;

		ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_atmQmode",
			       IFX_F_DEFAULT, &outFlag, atm_qmode);
		if (!gstrcmp(atm_qmode, "0")) {
			ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_qIf",
				       IFX_F_DEFAULT, &outFlag, vcc_selected);
			ifx_httpdWrite(wp,
				       T
				       ("<tr>\n<td width=\"50%\">Egress ATM PVC</td>\n<td>"));
			if (ifx_get_all_wan_atm_vcc_config
			    (&wan_count, &wan_cfg,
			     IFX_F_DEFAULT) != IFX_SUCCESS) {
				goto IFX_Handler;
			}

			for (i = 0; i < wan_count; i++) {
				sprintf(sWAN_VCC, "%d/%d",
					(wan_cfg + i)->vc.pvc.vpi,
					(wan_cfg + i)->vc.pvc.vci);
				if ((wan_cfg + i)->WAN_IP_CONN.conn_type ==
				    WAN_IP_CONN_TYPE_IP_ROUTED
				    && (wan_cfg + i)->wan_mode.mode ==
				    WAN_MODE_ATM) {
					if (!gstrcmp(vcc_selected, sWAN_VCC))
						sprintf(writeBuf,
							"%s <option VALUE='%s' selected >",
							writeBuf, sWAN_VCC);
					else
						sprintf(writeBuf,
							"%s <option VALUE='%s'>",
							writeBuf, sWAN_VCC);
					sprintf(writeBuf,
						"%s VCC : %s</option>",
						writeBuf, sWAN_VCC);
					bFlag = 1;
				}
			}
			if (bFlag) {
				ifx_httpdWrite(wp,
					       "<select name='wanif' size='1'>");
				ifx_httpdWrite(wp, "%s</select>", writeBuf);
			} else
				ifx_httpdWrite(wp,
					       "<select name='wanif' disabled><option value='0' selected>No WAN connections in Routed mode</option></select>\n");
			ifx_httpdWrite(wp, T("</td></tr>\n"));
		}
	      IFX_Handler:
		IFX_MEM_FREE(wan_cfg);
		if (ret != IFX_SUCCESS)
			return ret;
		else
#endif				// TODO
			return IFX_SUCCESS;
	}

	int ifx_get_qos_enable(int eid, httpd_t wp, int argc, char_t ** arg_v) {
		char_t enable[8] = { 0 };
		uint32 outFlag = IFX_F_DEFAULT;
		ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_enable",
			       IFX_F_DEFAULT, &outFlag, enable);
		ifx_httpdWrite(wp, T("%d"), atoi(enable));
		return IFX_SUCCESS;
	}

	int ifx_get_qm_If(int eid, httpd_t wp, int argc, char_t ** arg_v) {
		char_t qIf[8] = { 0 };
		uint32 outFlag = IFX_F_DEFAULT;
		ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_qIf",
			       IFX_F_DEFAULT, &outFlag, qIf);
		ifx_httpdWrite(wp, T("%s"), qIf);
		return IFX_SUCCESS;
	}

	int ifx_check_queue_dependency(int eid, httpd_t wp, int argc,
				       char_t ** argv) {
		char_t sWan_Conn_vcc[MAX_CONN_NAME_LEN];
		char_t sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN];
		int32 nWAN_IDX = -1;
		uint32 outFlag = IFX_F_DEFAULT;
		char_t vcc_selected[8] = { 0 };
		WAN_PHY_CFG pstWanPhy;
		char_t sLine[256];
		WAN_MODE WanType;

		buf[0] = '\0';
		sValue[0] = '\0';
		sWan_Conn_vcc[0] = '\0';
		memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));

		ifx_get_wan_phy_cfg(&pstWanPhy);
		ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_atmQmode",
			       IFX_F_GET_ENA, 0, sLine);
		if (atoi(sLine) == IFX_MAPI_QoS_ATM_PVC_BASED) {
			if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2
			    && pstWanPhy.wan_tc == WAN_TC_ATM) {
				IFX_GET_WAN_SELECTED_INDEX(IFX_F_GET_ENA,
							   outFlag, sValue,
							   nWAN_IDX, WanType)

				    sprintf(buf, "%s_%d_vcc", PREFIX_WAN_MAIN,
					    nWAN_IDX);
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_WAN_MAIN, buf,
				     IFX_F_GET_ENA, &outFlag,
				     sWan_Conn_vcc) != IFX_SUCCESS) {
					return -1;
				}
				ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM,
					       "qm_qIf", IFX_F_DEFAULT,
					       &outFlag, vcc_selected);

				if (!gstrcmp(vcc_selected, sWan_Conn_vcc)) {
					ifx_httpdWrite(wp, T("-1"));
					return -1;
				}

			}
		}

		ifx_httpdWrite(wp, T("0"));
		return 0;
	}

	int ifx_get_default_queue_check(int eid, httpd_t wp, int argc,
					char_t ** arg_v) {
		uint32 ret = IFX_SUCCESS;
		IFX_MAPI_QoS_Interface_Type ifType;
		ifType = ifx_mapi_get_active_qos_iface();
		ret = ifx_mapi_get_default_queue_cpeid(ifType);
		ifx_httpdWrite(wp, T("%d"), ret);
		return IFX_SUCCESS;
	}
//manohar end
