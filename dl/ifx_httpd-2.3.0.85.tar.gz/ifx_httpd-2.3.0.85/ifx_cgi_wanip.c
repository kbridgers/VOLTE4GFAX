#include <ifx_emf.h>
#include "ifx_httpd_method.h"
#include "./ifx_amazon_cgi.h"
#include "./ifx_cgi_common.h"
/* Best Viewed with Tab Setting 2 (set ts=2) */

extern int ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);
extern void websNextPage(httpd_t wp);
int ifx_set_wan_dhcp(httpd_t wp, char_t * path, char_t * query);	// wizard_calbe.asp; wan_dhcpc.asp
int ifx_get_WanProtocol(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_set_wan_static(httpd_t wp, char_t * path, char_t * query);	// wizard_static.asp; wan_static_alias.asp
int ifx_set_bridge_settings(httpd_t wp, char_t * path, char_t * query);	//bridge_settings.asp
int ifx_get_bridge_setting(int eid, httpd_t wp, int argc, char_t ** argv);	//bridge_settings.asp
int ifx_get_wan_ipv6(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_wan_sixrd(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_wan_dslite(int eid, httpd_t wp, int argc, char_t ** argv);
extern int get_wan_dslite_parameter(char *name, char *retVal7, int size);
extern int get_wan_dslite_allstatus(char *name, char *retVal6, char *retVal8,
				    char *retVal12, char *retVal9, int size,
				    int nWAN_IDX, char *wantype, char *wantag,
				    char *wan_basename);
extern int32 ifx_get_another_fvp_from_dist_fvp(char8 * secName, char8 * fName,
					       char8 * fValue, char8 * fRetName,
					       char8 * fRetValue, uint32 flags);
extern int ifx_get_wan_mode_selected();
extern int32 ltq_bridge_validation(); 
extern int32 ifx_mapi_set_wan_config(int32 operation,
				     WAN_CONN_CFG * wan_conn_cfg, uint32 flags);
extern int32 ifx_cgi_set_wan_config(int32 operation, WAN_CONN_CFG * wan_cfg,
				    uint32 flags);
extern char *pcr_chk_err;
extern char *status_str;
extern char *ppp_to_ip_err;
extern char *dw_config_err;
extern char newconnName[MAX_CONN_NAME_LEN];
inline void ifx_check_dw_status(int *def_wan, char *DefWanRet)
{
	if (!strcmp(DefWanRet, "1")) {
		*def_wan = 1;
	} else {
		*def_wan = 0;
	}

}

#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
	extern pwb_cfg_t *cgi_pwb;
#endif
//wan_dhcp.asp

//#if defined(CONFIG_FEATURE_DHCP_CLIENT) && defined(CONFIG_PACKAGE_BR2684CTL)
int ifx_set_wan_dhcp(httpd_t wp, char_t * path, char_t * query)
{
	// Update Wan Mode
	int nWAN_IDX = -1;
	char_t sValue[MAX_NAME_SIZE];
	char8 *pconfcon = ifx_httpdGetVar(wp, T("confconname"),T(""));
#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
	char_t igmpoldconnName[MAX_NAME_SIZE]="";
	char_t igmpnewconnName[MAX_NAME_SIZE]="";
	char sVal[MAX_DATA_LEN]="";
	int32 mcast_wan_flag;
#endif
#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
	#if 0
	char_t sWAN_VCC[10], *retVal = NULL;
	#endif
#endif
	//                      char_t  *pATMProtocol = ifx_httpdGetVar(wp, T("ATM_PROTOCOL"), T(""));

	uint32 flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT, wan_cpeId =
	    0, wan_pcpeId = 0;
	/* TBD : Need IPv6 team support here
	   uint32 wan_ipv4 = 0, wan_ipv6 = 0, wan_dhcp_mode = 0, wan_iana =
	   0, wan_iapd = 0, wan_slaid = 0, wan_rapid = 0, wan_duid_t = 0;
	   uint32 wan_sixrd = 0;
	 */
	char8 retVal6[MAX_FILELINE_LEN];
	int32 operation = IFX_OP_ADD, ret = IFX_SUCCESS;
	//char8   *link_type = NULL, buf[MAX_NAME_SIZE];
	char8 buf[MAX_NAME_SIZE];
	char_t *page = ifx_httpdGetVar(wp, T("page"), T(""));
	WAN_CONN_CFG wan_cfg;
	WAN_COMMON_CFG pWan;
	WAN_TYPE wan_type = WAN_TYPE_IP;

	/* pstWanPhy: Global WAN Mode ADSL2+, MIIO, MII1 or PTM */
	WAN_PHY_CFG pstWanPhy;
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	ifx_get_wan_phy_cfg(&pstWanPhy);

	/* WanType: denotes the current WAN Mode selected from Drop-down list
	 * This variable is stored in the System Status file as
	 * ETHx - Ethernet (MIIO & MII1), PTMx - PTM WAN and VPI/VCI - ATM WAN */
	WAN_MODE WanType;
	WanType = ifx_get_wan_mode_selected();

	/* nWAN_IDX: Selected WAN index being configured */
	IFX_GET_WAN_SELECTED_INDEX(IFX_F_GET_ANY, outFlag, buf, nWAN_IDX,
				   wan_type)
	    //char_t  *pATMProtocol = ifx_httpdGetVar(wp, T("ATM_PROTOCOL"), T(""));
	    /* AMS */
#if 1				/* TBD : Need IPv6 team support here */
	char_t *pVer4 = ifx_httpdGetVar(wp, T("ipv4"), T(""));
	char_t *pVer6 = ifx_httpdGetVar(wp, T("ipv6"), T(""));
	char_t *pIntrf = ifx_httpdGetVar(wp, T("INTRF"), T(""));
	char_t *pIana_id = ifx_httpdGetVar(wp, T("IANA_ID"), T(""));
	char_t *pIapd_id = ifx_httpdGetVar(wp, T("IAPD_ID"), T(""));
	char_t *pSla_id = ifx_httpdGetVar(wp, T("SLA_ID"), T(""));
	char_t *pRapid = ifx_httpdGetVar(wp, T("RAPID"), T(""));
	char_t *pduidt = ifx_httpdGetVar(wp, T("DUID_T"), T(""));
#endif				// 0

        char_t *PDNS1 = ifx_httpdGetVar(wp, T("PDNS1"), T(""));
        char_t *PDNS2 = ifx_httpdGetVar(wp, T("PDNS2"), T(""));
        char_t *PDNS3 = ifx_httpdGetVar(wp, T("PDNS3"), T(""));
        char_t *PDNS4 = ifx_httpdGetVar(wp, T("PDNS4"), T(""));
        char_t *SDNS1 = ifx_httpdGetVar(wp, T("SDNS1"), T(""));
        char_t *SDNS2 = ifx_httpdGetVar(wp, T("SDNS2"), T(""));
        char_t *SDNS3 = ifx_httpdGetVar(wp, T("SDNS3"), T(""));
        char_t *SDNS4 = ifx_httpdGetVar(wp, T("SDNS4"), T(""));
	char_t *dns_check = ifx_httpdGetVar(wp, T("dns_check_value"), T(""));

	memset(&pWan, 0, sizeof(WAN_COMMON_CFG));

	memset(&wan_cfg, 0x00, sizeof(wan_cfg));
	buf[0] = '\0';

/* AMS */
#if 0
	wan_cfg.WAN_IP_CONN.wan_cfg.ipv4 = atoi(pVer4);
	if (atoi(pVer6) == 2)
		wan_cfg.WAN_IP_CONN.wan_cfg.ipv6 = atoi(pVer6);
	else
		wan_cfg.WAN_IP_CONN.wan_cfg.ipv6 = 1;
	wan_cfg.WAN_IP_CONN.wan_cfg.dhcp_mode = atoi(pIntrf);
	wan_cfg.WAN_IP_CONN.wan_cfg.iana = atoi(pIana_id);
	wan_cfg.WAN_IP_CONN.wan_cfg.iapd = atoi(pIapd_id);
	wan_cfg.WAN_IP_CONN.wan_cfg.slaid = atoi(pSla_id);
	wan_cfg.WAN_IP_CONN.wan_cfg.rapid = atoi(pRapid);
	wan_cfg.WAN_IP_CONN.wan_cfg.duid_t = atoi(pduidt);
	sprintf(buf, "wanip_%d_tunnel", nWAN_IDX);
	if (ifx_GetObjData
	    (FILE_RC_CONF, TAG_WAN_IP, buf, flags, (IFX_OUT uint32 *) & outFlag,
	     retVal6) != IFX_SUCCESS) {
		wan_cfg.WAN_IP_CONN.wan_cfg.tunnel = 0;
	} else {
		wan_cfg.WAN_IP_CONN.wan_cfg.tunnel = atoi(retVal6);
	}
#endif

	pWan.tunnel = 0;

	/* WAN instance exists in configuration - possible to MODIFY or DELETE this instance
	 * Fetch the WAN Configuration for this WAN Index */

	if (wan_type == WAN_TYPE_PPP && nWAN_IDX >= 0) {

		wan_cfg.type = wan_type;
		ret =
		    mapi_get_wan_config(nWAN_IDX, &wan_cfg, IFX_F_GET_ANY);

		if (ret != IFX_SUCCESS) {
			IFX_DBG
			    ("[%s:%d] unable to get details of existing WAN PPP connection with index [%d]",
			     __FUNCTION__, __LINE__, nWAN_IDX);
			ifx_httpdError(wp, 400,
				       "Unable to get details of existing WAN PPP connection with index [%d]",
				       nWAN_IDX);
			return -1;
		}
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] WAN PPP get on [%d] succeeded", __FUNCTION__,
			__LINE__, nWAN_IDX);
#endif
		GET_WAN_COMM_PTR_1(pWan, wan_cfg)

		    pWan.wan_index = nWAN_IDX;

		/* Set the DELETE operation & Flags */
		operation = IFX_OP_DEL;
		flags = IFX_F_DELETE;

		/* Store the CPE & pCPE Id for this WAN Device
		 * Since this operation is a modify, we need to ADD back with the same values */
		sprintf(pWan.iid.cpeId.secName, "%s", TAG_WAN_PPP);
		wan_cpeId = pWan.iid.cpeId.Id;
		sprintf(buf, "wanppp_%d_tunnel", nWAN_IDX);
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, retVal6) == IFX_SUCCESS) {
			pWan.tunnel = atoi(retVal6);
		}
		/* AMS */
/* TODO : Need to check with IPv6 team here
   wan_ipv4 = wan_cfg.ipv4;
   wan_ipv6 = wan_cfg.ipv6;
   wan_dhcp_mode = wan_cfg.dhcp_mode;
   wan_iana = wan_cfg.iana;
   wan_iapd = wan_cfg.iapd;
   wan_slaid = wan_cfg.slaid;
   wan_rapid = wan_cfg.rapid;
   wan_sixrd = wan_cfg.tunnel;
                wan_duid_t = wan_cfg.duid_t;
*/
		sprintf(pWan.iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);
		wan_pcpeId = pWan.iid.pcpeId.Id;
		pWan.iid.config_owner = IFX_WEB;

		memcpy(&wan_cfg.WAN_PPP_CONN.wan_cfg, &pWan, sizeof(pWan));

#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
		strcpy(igmpoldconnName,pWan.conn_name);
#endif
		ret = mapi_delete_old_virtualserver( pWan.conn_name, "modify");
		if (ret != IFX_SUCCESS) {
                        IFX_DBG
                            ("[%s:%d] unable to delete virtual server of wan index  with index [%d]",
                             __FUNCTION__, __LINE__, pWan.wan_index);
                        return -1;
                }

#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
		if(mapi_pwb_delentry_on_wanchange(pWan.conn_name, &cgi_pwb) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                      	IFX_DBG("delete pwb entry failed in function [%s] line [%d]  !!", __FUNCTION__, __LINE__);
#endif
                }
#endif

#ifdef LTQ_AEI_CUST
		/* Case of changing WAN type from EoA/IPoA to PPPoA */
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] cpeid:sec pcpeid:sec [%d:%s] [%d:%s]", __FUNCTION__, __LINE__,
			wan_cfg.wancfg.ppp.wan_cfg.iid.cpeId.Id, wan_cfg.wancfg.ppp.wan_cfg.iid.cpeId.secName,
			wan_cfg.wancfg.ppp.wan_cfg.iid.pcpeId.Id, wan_cfg.wancfg.ppp.wan_cfg.iid.pcpeId.secName);
#endif

		/* Set the DELETE operation & Flags */
		operation = IFX_OP_DEL;
		flags = IFX_F_DELETE;

		if(wan_cfg.wancfg.ppp.wan_cfg.link_type == WAN_LINK_TYPE_PPPOATM && (WanType == WAN_MODE_ATM || WanType == WAN_MODE_VDSL_ATM)) {
			if(mapi_wan_for_l2_get(wan_cfg.wancfg.ppp.wan_cfg.iid, &vc, &vlan_cfg) != IFX_SUCCESS) {
	#ifdef IFX_LOG_DEBUG
				IFX_DBG
			    ("[%s:%d] Failed to get details of L2 for this WAN PPP connection with index [%d]",
			     __FUNCTION__, __LINE__, nWAN_IDX);
	#endif
				ifx_httpdError(wp, 400,
			    "Failed to get details of L2 for this WAN PPP connection with index [%d]", nWAN_IDX);
				return -1;
			}
		}
#endif

		/* Invoke the CGI handler function to DELETE this WAN connection */
		if (ifx_cgi_set_wan_config
		    (operation, &wan_cfg,
		     flags | IFX_F_DONT_WRITE_TO_FLASH) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "WAN[%d] couldn't be modified !!\n",
				       nWAN_IDX);
			return -1;
		}

#ifdef LTQ_AEI_CUST
		ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, "WAN_VCC",
			       IFX_F_GET_ANY, &outFlag, pWan.l2iface_name);

#if 0 // can't do this, because current l2iface_name is 'pppoatmX'
		/* Get link type of VC channel instance with l2ifName = pWan.l2iface_name */
		vc.type = get_link_type_based_on_l2if(pWan.l2iface_name);
		if (vc.type < 0)
			vc.type = LINK_TYPE_UNCONFIGURED;
#endif

		/* Set link type to EoATM and encapsulation to LLC */
		vc.type = LINK_TYPE_EOATM;
		vc.encap = VC_ENCAP_LLC;

		/* this API call would take care of updating L3 as well ! */
		if(wan_cfg.wancfg.ppp.wan_cfg.link_type == WAN_LINK_TYPE_PPPOATM && (WanType == WAN_MODE_ATM || WanType == WAN_MODE_VDSL_ATM)) {
			operation = IFX_OP_MOD;
			flags = IFX_F_MODIFY;
			if(ifx_set_vcc_cfg(operation, &vc, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("Failed to modify L2 link type to PPPoA");
#endif
				ifx_httpdError(wp, 400, "Failed to modify L2 link type to PPPoA");
				return -1;
			}
			sprintf(buf, "WAN_VCC=\"%s\"\n", vc.l2ifname);
			SetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, IFX_F_MODIFY, 1, buf);
		}
#endif

		memset(&wan_cfg, 0x00, sizeof(wan_cfg));
		memset(&pWan, 0x00, sizeof(pWan));

		/* Populate the CPE and pCPE ID structure by Restoring the 
		 * CPE and pCPE Ids stored during DELETE of this Connection */
		sprintf(pWan.iid.cpeId.secName, "%s", TAG_WAN_IP);
		pWan.iid.cpeId.Id = wan_cpeId;
		sprintf(pWan.iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);
		pWan.iid.pcpeId.Id = wan_pcpeId;

		/* Set the ADD Operation Flags */
		operation = IFX_OP_ADD;
		flags = IFX_F_INT_ADD;
	} else if (wan_type == WAN_TYPE_IP && nWAN_IDX >= 0) {

		wan_cfg.type = wan_type;
		ret =
		    mapi_get_wan_config(nWAN_IDX, &wan_cfg, IFX_F_GET_ANY);

		if (ret != IFX_SUCCESS) {
			IFX_DBG
			    ("[%s:%d] unable to get details of existing WAN IP connection with index [%d]",
			     __FUNCTION__, __LINE__, nWAN_IDX);
			ifx_httpdError(wp, 400,
				       "Unable to get details of existing WAN IP connection with index [%d]",
				       nWAN_IDX);
			return -1;
		}

		sprintf(buf, "wanip_%d_tunnel", nWAN_IDX);
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_WAN_IP, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, retVal6) == IFX_SUCCESS) {
			pWan.tunnel = atoi(retVal6);
		}

#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] WAN IP get on [%d] succeeded", __FUNCTION__,
			__LINE__, nWAN_IDX);
#endif
		operation = IFX_OP_MOD;
		flags = IFX_F_MODIFY;

		GET_WAN_COMM_PTR_1(pWan, wan_cfg)

		    /* CANNOT Modify Disabled WAN Connections.
		     * These are configured from TR069 ACS and can't enable the same from Web */
		    if (pWan.f_enable == IFX_DISABLED) {
			ifx_httpdError(wp, 400,
				       "WAN[%d] is currently disabled - Can't modify !!\n",
				       nWAN_IDX);
			return -1;
		}
#if 0 /* TBD */
#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
		/* SPECIAL Case: While modifying the WAN ATM Parameters, i.e VCC information from the drop-down menu,
		 * if the selected VCC is disabled, then we can't configure the WAN Connection
		 * These disabled VCC Channels (DSLLinkConfig Object)could be created from TR069 in DISABLED mode */
		if (WanType == WAN_MODE_ATM) {
			/* Check if the VCC selected is in Disabled Mode
			 * If the vc channel is disabled, can't enable the same from Web */

			/* TBD: We need to find this WAN's pcpeId in VC channel section to find the parent VC channel instance */
			sprintf(buf, "wanip_%d_pcpeId", nWAN_IDX);
			ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf,
				       IFX_F_GET_ANY, &outFlag, sWAN_VCC);
			if ((ret =
			     ifx_ret_substr_from_distfield(FILE_RC_CONF,
							   TAG_VLAN_CHANNEL,
							   "cpeId", sWAN_VCC,
							   &retVal)) !=
			    IFX_SUCCESS) {
				/* Cannot be - seriously something wrong here */
				ifx_httpdError(wp, 400,
					       "VC Channel [%s] doesn't exist!\n",
					       sWAN_VCC);
				/* Free the returned VCC information */
				IFX_MEM_FREE(retVal)
				    return -1;
			}

			/* Check if the VCC selected is in Disabled Mode */
			memset(sValue, 0x00, sizeof(sValue));
			sprintf(buf, "%s_fEnable", retVal);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_VLAN_CHANNEL, buf,
			     IFX_F_GET_ANY, &outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("\n\nIn Function [%s] : Error--> f_enable not found for vc channel [%s] !!\n\n",
				     __FUNCTION__, retVal);
#endif
				IFX_MEM_FREE(retVal);
				return -1;
			}
			if (atoi(sValue) == IFX_DISABLED) {
				ifx_httpdError(wp, 400,
					       "VC Channel[%s] is currently disabled - Can't select!!\n",
					       sWAN_VCC);
				IFX_MEM_FREE(retVal);
				return -1;
			}
		}
#endif				// CONFIG_FEATURE_ADSL_WAN_SUPPORT
#endif // 0

	} else {
		operation = IFX_OP_ADD;
		flags = IFX_F_INT_ADD;
	}

	/* Currently assume its only ADD op that is supported. Modify support TBD */
#if 0
	if (ifx_GetObjData
	    (FILE_SYSTEM_STATUS, buf, "STATUS", IFX_F_GET_ANY, &outFlag,
	     sValue) != IFX_SUCCESS) {
		/* WAN instance doesn't exist - hence OP_ADD */
		operation = IFX_OP_ADD;
		flags = IFX_F_INT_ADD;
		GET_GLOBAL_RIP_LISTEN_MODE(pWAN.route_rx)
	} else {
		/* Here we need to handle the cases for WAN Connection MODIFICATIONS
		 * 1. MODIFY from one WAN Type to another, i.e PPPoX->DHCP
		 * 2. MODIFY Wan Connection among similar types, i.e Static->DHCP, DHCP->DHCP,..

		 * CASE1: In Modification of WAN Connections across different types, PPPoX->DHCP,
		 * we need to Delete the existing connection and Add the newly configured connection

		 * CASE2: Modify the WAN Connection parameters directly here */

		/* WAN instance exists in configuration - possible to MODIFY or DELETE this instance
		 * Fetch the WAN Configuration for this WAN Index */
		ret =
		    mapi_get_wan_config(nWAN_IDX, &wan_cfg, IFX_F_GET_ANY);

		if (!strcmp(sValue, "UNCONFIGURED") && ret != IFX_SUCCESS) {
			/* Speical case where this WAN instance was previously configured
			 * and now this WAN instance is deleted - hence ADD Operation */
			operation = IFX_OP_ADD;
			flags = IFX_F_INT_ADD;
#if 0
			/* get wan conn name out of wan index */
			sprintf(pWan.WAN_CONN_NAME, "%s%d", "WAN", nWAN_IDX);
#endif				// 0
		} else {

			if (ret != IFX_SUCCESS) {
				/* Shouldn't happen - Error Condition */
				ifx_httpdError(wp, 400,
					       T
					       ("No WAN Connection on Wan index[%d] !!\n\n"),
					       nWAN_IDX);
				return -1;
			}

			GET_WAN_COMM_PTR_1(pWan, wan_cfg)

			    /* MODIFY: Case where the previous connection was PPP that is now being modified to DHCP 
			     * In this case, delete the existing PPP connection and make way for new connection (ADD) */
			    if (pWan.link_type == WAN_LINK_TYPE_PPPOE
				|| pWan.link_type == WAN_LINK_TYPE_PPPOATM) {
				pWan.wan_index = nWAN_IDX;

				/* Set the DELETE operation & Flags */
				operation = IFX_OP_DEL;
				flags = IFX_F_DELETE;

				/* Store the CPE & pCPE Id for this WAN Device
				 * Since this operation is a modify, we need to ADD back with the same values */
				sprintf(pWan.iid.cpeId.secName, "%s",
					TAG_WAN_MAIN);
				wan_cpeId = pWan.iid.cpeId.Id;
				/* AMS */
/* TODO : Need to check with IPv6 team here
   wan_ipv4 = wan_cfg.ipv4;
   wan_ipv6 = wan_cfg.ipv6;
   wan_dhcp_mode = wan_cfg.dhcp_mode;
   wan_iana = wan_cfg.iana;
   wan_iapd = wan_cfg.iapd;
   wan_slaid = wan_cfg.slaid;
   wan_rapid = wan_cfg.rapid;
   wan_sixrd = wan_cfg.tunnel;
                wan_duid_t = wan_cfg.duid_t;
*/
				sprintf(pWan.iid.pcpeId.secName, "%s",
					TAG_WAN_CONN_DEVICE);
				wan_pcpeId = pWan.iid.pcpeId.Id;
				pWan.iid.config_owner = IFX_WEB;

				/* Invoke the CGI handler function to DELETE this WAN connection */
				if (ifx_cgi_set_wan_config
				    (operation, &wan_cfg,
				     flags | IFX_F_DONT_WRITE_TO_FLASH) !=
				    IFX_SUCCESS) {
					ifx_httpdError(wp, 400,
						       "WAN[%d] couldn't be modified !!\n",
						       nWAN_IDX);
					return -1;
				}

				/* PREPARE FOR ADDING NEW CONNECTION NOW */
				/* Now that we've deleted the WAN Connection above, prepare 
				 * for ADDing the new WAN Type Connection here */
				memset(&wan_cfg, 0x00, sizeof(wan_cfg));

				/* Populate the CPE and pCPE ID structure by Restoring the 
				 * CPE and pCPE Ids stored during DELETE of this Connection */
				sprintf(pWan.iid.cpeId.secName, "%s",
					TAG_WAN_MAIN);
				pWan.iid.cpeId.Id = wan_cpeId;
				sprintf(pWan.iid.pcpeId.secName, "%s",
					TAG_WAN_CONN_DEVICE);
				pWan.iid.pcpeId.Id = wan_pcpeId;

				/* Set the ADD Operation Flags */
				operation = IFX_OP_ADD;
				flags = IFX_F_INT_ADD;

			} else {

				/* MODIFY: Case where the previous connection was of similar Type - Static, DHCP or Bridge 
				 * Modify from Static->DHCP, Bridge->DHCP or DHCP->DHCP */

				operation = IFX_OP_MOD;
				flags = IFX_F_MODIFY;

				/* CANNOT Modify Disabled WAN Connections.
				 * These are configured from TR069 ACS and can't enable the same from Web */
				if (pWan.f_enable == IFX_DISABLED) {
					ifx_httpdError(wp, 400,
						       "WAN[%d] is currently disabled - Can't modify !!\n",
						       nWAN_IDX);
					return -1;
				}
#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
				/* SPECIAL Case: While modifying the WAN ATM Parameters, i.e VCC information from the drop-down menu,
				 * if the selected VCC is disabled, then we can't configure the WAN Connection
				 * These disabled VCC Channels (DSLLinkConfig Object)could be created from TR069 in DISABLED mode */
				if (WanType == WAN_MODE_ATM || WanType == WAN_MODE_VDSL_ATM) {
					/* Check if the VCC selected is in Disabled Mode
					 * If the vc channel is disabled, can't enable the same from Web */

					/* ATM WAN Mode: get the vcc selected from system status file */
					ifx_GetObjData(FILE_SYSTEM_STATUS,
						       TAG_WAN_MAIN, "WAN_VCC",
						       IFX_F_GET_ANY, &outFlag,
						       sWAN_VCC);
					/* TBD: We need to find this WAN's pcpeId in VC channel section to find the parent VC channel instance */
					sprintf(buf, "wanip_%d_pcpeId",
						nWAN_IDX);
					ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP,
						       buf, IFX_F_GET_ANY,
						       &outFlag, sWAN_VCC);
					if ((ret =
					     ifx_ret_substr_from_distfield
					     (FILE_RC_CONF, TAG_VLAN_CHANNEL,
					      "cpeId", sWAN_VCC,
					      &retVal)) != IFX_SUCCESS) {
						/* Cannot be - seriously something wrong here */
						ifx_httpdError(wp, 400,
							       "VC Channel [%s] doesn't exist!\n",
							       sWAN_VCC);
						/* Free the returned VCC information */
						IFX_MEM_FREE(retVal)
						    return -1;
					}

					/* Check if the VCC selected is in Disabled Mode */
					memset(sValue, 0x00, sizeof(sValue));
					sprintf(buf, "%s_fEnable", retVal);
					if (ifx_GetObjData
					    (FILE_RC_CONF, TAG_VLAN_CHANNEL,
					     buf, IFX_F_GET_ANY, &outFlag,
					     sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
						IFX_DBG
						    ("\n\nIn Function [%s] : Error--> f_enable not found for vc channel [%s] !!\n\n",
						     __FUNCTION__, retVal);
#endif
						IFX_MEM_FREE(retVal);
						return -1;
					}
					if (atoi(sValue) == IFX_DISABLED) {
						ifx_httpdError(wp, 400,
							       "VC Channel[%s] is currently disabled - Can't select!!\n",
							       sWAN_VCC);
						IFX_MEM_FREE(retVal);
						return -1;
					}
				}
				IFX_MEM_FREE(retVal);
#endif				/* CONFIG_FEATURE_ADSL_WAN_SUPPORT */

			}
		}
	}

	operation = IFX_OP_ADD;
	flags = IFX_F_INT_ADD;
	GET_GLOBAL_RIP_LISTEN_MODE(pWan.route_rx)
#endif				// 0
#if 1
	    pWan.ipv4 = atoi(pVer4);
	if (atoi(pVer6) == 2)
		pWan.ipv6 = atoi(pVer6);
	else
		pWan.ipv6 = 1;
	pWan.dhcp_mode = atoi(pIntrf);
	pWan.iana = atoi(pIana_id);
	pWan.iapd = atoi(pIapd_id);
	pWan.slaid = atoi(pSla_id);
	pWan.rapid = atoi(pRapid);
	pWan.duid_t = atoi(pduidt);
#endif
	/* Use the unique interface information to establish the Parent-Child relationship
	 * In case of ATM WAN, VCC information is used and in PTM, ETH WAN connections, the
	 * interface information is used along with VLAN Tag */
	/* For ATM WAN Mode, link type check for eoa or ipoa or clip in atm_protocol */
	if (WanType == WAN_MODE_ATM || WanType == WAN_MODE_VDSL_ATM) {
		/*
		   link_type = strrchr(pATMProtocol, '_');
		   if(link_type)
		   {
		   if (!gstrcmp(link_type, "_ipoa"))
		   pWan.link_type = WAN_LINK_TYPE_IPOATM;
		   else if (!gstrcmp(link_type, "_eoa"))
		   pWan.link_type = WAN_LINK_TYPE_EOATM;
		   }
		 */
		ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, "WAN_VCC",
			       IFX_F_GET_ANY, &outFlag, pWan.l2iface_name);

		/* Get link type of VC channel instance with l2ifName = pWan.l2iface_name */
		pWan.link_type = get_link_type_based_on_l2if(pWan.l2iface_name);
		if (pWan.link_type < 0)
			pWan.link_type = LINK_TYPE_UNCONFIGURED;
		/* This code is needed when VDSL ATM support is available */
		/* TBD : currently we dont support WAN_MODE_VDSL_ATM (ADSL-ATM) on VRX platforms, take care in future */
		if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2)
			pWan.wan_mode.mode = WAN_MODE_ATM;
		else
			pWan.wan_mode.mode = WAN_MODE_VDSL_ATM;
	} else if (WanType == WAN_MODE_PTM || WanType == WAN_MODE_VDSL_PTM) {
		ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, "WAN_VCC",
			       IFX_F_GET_ANY, &outFlag, pWan.l2iface_name);

		pWan.link_type = WAN_LINK_TYPE_PTM;
		/* TBD : This code is needed when ADSL PTM support is available on VRX platforms, take care in future */
		if (pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2)
			pWan.wan_mode.mode = WAN_MODE_VDSL_PTM;
		else
			pWan.wan_mode.mode = WAN_MODE_PTM;
#if 0
#ifdef PLATFORM_VR9
			pWan.wan_mode.mode = WAN_MODE_VDSL_PTM;
#else
			pWan.wan_mode.mode = WAN_MODE_PTM;
#endif
#endif
		//gstrcpy(pWan.wan_mode.iface,"ptm0"); 
	} else {
		ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, "WAN_VCC",
			       IFX_F_GET_ANY, &outFlag, pWan.l2iface_name);
		pWan.link_type = WAN_LINK_TYPE_ETH;

		if (strstr(pWan.l2iface_name, "eth0"))
			pWan.wan_mode.mode = WAN_MODE_ETH0;
		else if (strstr(pWan.l2iface_name, "eth1"))
			pWan.wan_mode.mode = WAN_MODE_ETH1;
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] wan mode is %d", __FUNCTION__, __LINE__,
			pWan.wan_mode.mode);
#endif

	}
#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] wan mode is %d", __FUNCTION__, __LINE__,
		pWan.wan_mode.mode);
#endif
	/* TBD: this is nt reqd, check */
	/* Reset the IPAddr, NetMask and Gateway fields in DHCP */
#if 0
	wan_cfg.WAN_PPP_CONN.WAN_CONN_IPADDR.s_addr = INADDR_ANY;
	wan_cfg.WAN_PPP_CONN.WAN_CONN_IPMASK.s_addr = INADDR_ANY;
	wan_cfg.WAN_IP_CONN.ip_gw.s_addr = INADDR_ANY;
#endif				// 0

	/* Set the wan index */
	pWan.wan_index = nWAN_IDX;

	if (operation == IFX_OP_ADD) {
#ifdef CONFIG_FEATURE_RIP
		/* Set RIP information based on the Global RIP State & Listen Mode */
		ifx_set_wanif_route_proto(nWAN_IDX, &pWan);
#endif
	}
#ifdef CONFIG_FEATURE_NAPT
	/* Currently we set the NAT on interface level as always ENABLED 
	 * Once the interface level option is configurable, then it can be put here */
	pWan.WAN_CONN_NAT_ENABLED = IFX_ENABLED;
#endif

	ifx_check_dw_status(&(pWan.def_wan),
			    ifx_httpdGetVar(wp, T("def_wan"), T("")));

	/* set the dns override option to true */
	pWan.wandns.WAN_CONN_DNS_OVERRIDE = IFX_ENABLED;
		
	if(atoi(dns_check)) {
		pWan.wandns.WAN_CONN_DNS_OVERRIDE = IFX_DISABLED;
		memset(buf, 0x00, sizeof(buf));
		snprintf(buf, sizeof(buf), T("%s.%s.%s.%s"), PDNS1, PDNS2, PDNS3, PDNS4);
		pWan.wandns.dns_servers[0].s_addr = inet_addr(buf);
		memset(buf, 0x00, sizeof(buf));
		snprintf(buf, sizeof(buf), T("%s.%s.%s.%s"), SDNS1, SDNS2, SDNS3, SDNS4);
		pWan.wandns.dns_servers[1].s_addr = inet_addr(buf);
	}

	/* Enable this WAN Connection & Set the config owner to WEB */
	pWan.f_enable = IFX_ENABLED;
	pWan.iid.config_owner = IFX_WEB;
	sprintf(pWan.conf_conn_name,"%s" , pconfcon);


	/* Populate the CPE and pCPE Section Names */
	sprintf(pWan.iid.cpeId.secName, "%s", TAG_WAN_IP);
	sprintf(pWan.iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);

	memcpy(&wan_cfg.WAN_IP_CONN.wan_cfg, &pWan, sizeof(pWan));

	ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, "ipoption_wan",
		       IFX_F_GET_ANY, &outFlag, sValue);

	/* get ipoption_wan and interpret connType out of it */
	if (!gstrcmp(sValue, "FIXED") || !gstrcmp(sValue, "DHCPC"))
		wan_cfg.WAN_IP_CONN.conn_type = WAN_IP_CONN_TYPE_IP_ROUTED;

	/* get ipoption_wan and interpret addr_type out of it */
	if (!gstrcmp(sValue, "DHCPC"))
		wan_cfg.WAN_IP_CONN.addr_type = IP_TYPE_DHCP;

	/* Set the status as connecting */
	wan_cfg.WAN_PPP_CONN.conn_status = WAN_IP_CONN_STATUS_CONNECTING;

	if (operation == IFX_OP_MOD) {
		/* Check for dependencies with the modified WAN Connection */
		if (ifx_check_wan_configuration_dependency(&wan_cfg) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 500,
				       T
				       ("Modification of link type of wan connection from or to CLIP mode is not allowed !!"));
			return -1;
		}
	}

#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] operation [%d:%u]", __FUNCTION__, __LINE__, operation,
		flags);
#endif
	/* Invoke the CGI function to configure the WAN Connection */
	ret = ifx_cgi_set_wan_config(operation, &wan_cfg, flags);
	if (ret != IFX_SUCCESS) 
	{
		/* Should be checked for only ATM WAN Connections */
		if (ret == IFX_PCR_CHK_FAIL) {
			COPY_TO_STATUS("%s", pcr_chk_err)
			    ifx_httpdRedirect(wp, T("err_page.html"));
			return 0;
		}
	}
	else
	{
		
#ifdef CONFIG_FEATURE_NAPT

		IFX_DBG("[%s:%d] ", __FUNCTION__, __LINE__);
		if(strlen(newconnName) != 0)
		{

#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
			strcpy(igmpnewconnName,newconnName);
			mcast_wan_flag=Update_mcast_wan_flag(0,0);
			ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_upstream_wan", sVal);
			
			if (strlen(igmpoldconnName) != 0 ) {
				if (mcast_wan_flag == 1) {
					Update_igmp_config(igmpoldconnName,igmpnewconnName,0);
					mcast_wan_flag=0;
				} else if (mcast_wan_flag == 2 ) {
					mcast_wan_flag=0;
				} else if (mcast_wan_flag == 0){
					if ( strstr(sVal,igmpoldconnName) != NULL ) {
						mcast_wan_flag =3;
						Update_mcast_wan_flag(1,mcast_wan_flag);
						Update_igmp_config(igmpoldconnName,igmpnewconnName,0);
						mcast_wan_flag=0;
					}
				}
				Update_mcast_wan_flag(1,mcast_wan_flag);
			}
#endif
#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
      	          	if(mapi_pwb_modentry_on_wanchange(newconnName, cgi_pwb) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                      		IFX_DBG("function [%s] line [%d]  !!", __FUNCTION__, __LINE__);
#endif
               		}               
#endif

#ifdef CONFIG_FEATURE_NAPT
               		ret = Update_virtual_server_config(newconnName, "modify");
#endif
		}
#endif
	}

      IFX_Handler:

	if (!strcmp(page, "wan_dhcp.asp"))
		ifx_httpdRedirect(wp, T("wan_vcc_select.asp"));
	if (!strcmp(page, "wan_vcc_select.asp"))
		ifx_httpdRedirect(wp, T("wan_vcc_select.asp"));

	return 0;
}

//#endif

int ifx_get_wanip(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_IP_ADDR_LEN];
	char_t *name;
	char_t *delim = ". \n\t";
	char_t *ipaddr1 = NULL, *ipaddr2 = NULL, *ipaddr3 = NULL, *ipaddr4 =
	    NULL;
	char8	wanIp[MAX_IP_ADDR_LEN], wanMask[MAX_IP_ADDR_LEN],
		wanStatus[MAX_NAME_LEN], wanGW[MAX_IP_ADDR_LEN];
	int32	wanIdx = -1, nIndex = 0, ret = IFX_SUCCESS;
	uint32 flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT;
	WAN_TYPE sWAN_TYPE = WAN_TYPE_IP;
	IFX_ID	iid;

	memset(sValue, 0x00, sizeof(sValue));

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	if(argc == 1) {
		IFX_GET_WAN_SELECTED_INDEX(flags, outFlag, sValue, wanIdx, sWAN_TYPE)
	}
	else {
		if (ifx_get_default_wan_if(&iid, &wanIdx, sValue, IFX_F_DEFAULT)
	    != IFX_SUCCESS) {
		}
		if(!strcmp(iid.cpeId.secName, TAG_WAN_IP))
			sWAN_TYPE = WAN_TYPE_IP;
		else
			sWAN_TYPE = WAN_TYPE_PPP;
	}

	if (!gstrncmp(name, "OE_DNS", 6)) {
		WAN_CONN_CFG wan_cfg;
		memset(&wan_cfg, 0x00, sizeof(wan_cfg));
		wan_cfg.type = WAN_TYPE_IP;
		name += 3;
		ret = mapi_get_wan_config(wanIdx, &wan_cfg, flags);	
		if(ret == IFX_SUCCESS) {
			if(!gstrcmp(name, T("DNS1"))) {
				ifx_httpdWrite(wp,T("DNS = \"%s\";"),
						inet_ntoa(wan_cfg.wancfg.ip.wan_cfg.wandns.dns_servers[0]));
			}else if(!gstrcmp(name, T("DNS2"))) {
				ifx_httpdWrite(wp,T("DNS = \"%s\";"),
						inet_ntoa(wan_cfg.wancfg.ip.wan_cfg.wandns.dns_servers[1]));
			}else if(!gstrcmp(name, T("DNS_OVERRIDE"))) {
				if (wan_cfg.wancfg.ip.wan_cfg.wandns.DNS_override_allowed == IFX_DISABLED)
					ifx_httpdWrite(wp, T("checked"));
				else
					ifx_httpdWrite(wp, T(" "));
			}		
		}
	} else {
		wan_tuple_get(wanIdx, sWAN_TYPE, wanIp, wanMask, wanGW,
				wanStatus);

		if (!gstrncmp(name, "IP", 2)) {
			sscanf(name, "IP%d", &nIndex);
			sprintf(sValue, "%s", wanIp);
		} else if (!gstrncmp(name, "NM", 2)) {
			sscanf(name, "NM%d", &nIndex);
			sprintf(sValue, "%s", wanMask);
		} else if (!gstrncmp(name, "GW", 2)) {
			sscanf(name, "GW%d", &nIndex);
			sprintf(sValue, "%s", wanGW);
		}
	
		if(strlen(sValue) < 7 || !strcmp(sValue, "Unconfigured")) {
			ifx_httpdWrite(wp, "");
			return 0;
		}

		ipaddr1 = strtok(sValue, delim);
		ipaddr2 = strtok(NULL, delim);
		ipaddr3 = strtok(NULL, delim);
		ipaddr4 = strtok(NULL, delim);

		switch (nIndex) {
		case 1:
			ifx_httpdWrite(wp, T("%s"), ipaddr1);
			break;
		case 2:
			ifx_httpdWrite(wp, T("%s"), ipaddr2);
			break;
		case 3:
			ifx_httpdWrite(wp, T("%s"), ipaddr3);
			break;
		case 4:
			ifx_httpdWrite(wp, T("%s"), ipaddr4);
			break;
		}
	}

	return ret;
}

int ifx_get_wanip6_static(int eid, httpd_t wp, int argc, char_t ** argv)
{
        char_t sValue[MAX_IP6_ADDR_LEN];
        char_t *name;
        char8 addrbuf[MAX_FILELINE_LEN];
        char8 plbuf[MAX_FILELINE_LEN], gwbuf[MAX_FILELINE_LEN],
            lanprebuf[MAX_FILELINE_LEN];
        char8 dns1buf[MAX_FILELINE_LEN], dns2buf[MAX_FILELINE_LEN];
        char8 sWAN_Sec1[MAX_FILELINE_LEN], sWAN_Sec2[MAX_FILELINE_LEN], sWAN_Sec3[MAX_FILELINE_LEN];
        int32   wanIdx = -1;
        uint32 flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT;
        char8 buf1[MAX_FILELINE_LEN], buf2[MAX_FILELINE_LEN], buf3[MAX_FILELINE_LEN], buf4[MAX_FILELINE_LEN];
        char8 wanip_cpeId[MAX_FILELINE_LEN], wanv4cfg_pcpeId[MAX_FILELINE_LEN], wan_ipv4_Counts[MAX_FILELINE_LEN];
//        WAN_TYPE sWAN_TYPE = WAN_TYPE_IP;
        //IFX_ID        iid;


        memset(sValue, 0x00, sizeof(sValue));

        if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
                ifx_httpdError(wp, 400, T("Insufficient args\n"));
                return -1;
        }

        IFX_GET_WANIP_SELECTED_INDEX(flags, outFlag, sValue, wanIdx)
        sprintf(sWAN_Sec1, "WanIP%d_IF_IPv6_Info", wanIdx);
        sprintf(sWAN_Sec2, "WanIP%d_IF_IPv6_STATIC_Info", wanIdx);
        sprintf(sWAN_Sec3, "WanIP%d_IF_IPv6_Dns", wanIdx);

        sprintf(buf1, "wanip_%d_cpeId", wanIdx);
        ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf1, flags,
                               (IFX_OUT uint32 *) & outFlag, wanip_cpeId);
        syslog(1, "wanip_cpeId is %s\n", wanip_cpeId);
        ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IPV4, "wan_ipv4_Count", flags,
                               (IFX_OUT uint32 *) & outFlag, wan_ipv4_Counts);
        syslog(1, "wan_ipv4_Counts is %s\n", wan_ipv4_Counts);
        int32 i =0;
        while ( i < atoi(wan_ipv4_Counts) )
        {
            sprintf(buf2, "wanipv4%d_%d_pcpeId", atoi(wanip_cpeId), i);
            ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IPV4, buf2, flags,
                               (IFX_OUT uint32 *) & outFlag, wanv4cfg_pcpeId);
            syslog(1, "wanv4cfg_pcpeId is %s\n", wanv4cfg_pcpeId);

            if ( atoi(wanv4cfg_pcpeId) == atoi(wanip_cpeId) )
            {
               sprintf(buf3, "wanipv4%d_%d_dns6server1", atoi(wanip_cpeId), i);
               sprintf(buf4, "wanipv4%d_%d_dns6server2", atoi(wanip_cpeId), i);
               ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IPV4, buf3, flags,
                               (IFX_OUT uint32 *) & outFlag, dns1buf);
               syslog(1, "dns1buf is %s\n", dns1buf);
               ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IPV4, buf4, flags,
                               (IFX_OUT uint32 *) & outFlag, dns2buf);
               syslog(1, "dns2buf is %s\n", dns2buf);
            }
            i+=1;
        }


        if (ifx_GetObjData(FILE_SYSTEM_STATUS, sWAN_Sec1, "IPv6", IFX_F_GET_ENA,
                                        &outFlag, addrbuf) != IFX_SUCCESS) {
                        return -1;
        }
        if (ifx_GetObjData(FILE_SYSTEM_STATUS, sWAN_Sec2, "PRELEN", IFX_F_GET_ENA,
                                        &outFlag, plbuf) != IFX_SUCCESS) {
                        return -1;
        }
        if (ifx_GetObjData(FILE_SYSTEM_STATUS, sWAN_Sec2, "GW6", IFX_F_GET_ENA,
                                        &outFlag, gwbuf) != IFX_SUCCESS) {
                        return -1;
        }
        if (ifx_GetObjData(FILE_SYSTEM_STATUS, sWAN_Sec2, "LANPREFIX", IFX_F_GET_ENA,
                                        &outFlag, lanprebuf) != IFX_SUCCESS) {
                        return -1;
        }
#if 0
        if (ifx_GetObjData(FILE_SYSTEM_STATUS, sWAN_Sec3, "DNSv61", IFX_F_GET_ENA,
                                        &outFlag, dns1buf) != IFX_SUCCESS) {
                        return -1;
        }
        if (ifx_GetObjData(FILE_SYSTEM_STATUS, sWAN_Sec3, "DNSv62", IFX_F_GET_ENA,
                                        &outFlag, dns2buf) != IFX_SUCCESS) {
                        return -1;
        }
#endif



        if (!gstrcmp(name, T("IP6_1")))
                ifx_httpdWrite(wp, T("%s"), addrbuf);
        else if (!gstrcmp(name, T("PL6_1")))
                ifx_httpdWrite(wp, T("%s"), plbuf);
        else if (!gstrcmp(name, T("GIP6_1")))
                ifx_httpdWrite(wp, T("%s"), gwbuf);
        else if (!gstrcmp(name, T("LP6_1")))
                ifx_httpdWrite(wp, T("%s"), lanprebuf);
        else if (!gstrcmp(name, T("DNS6_1")))
                ifx_httpdWrite(wp, T("%s"), dns1buf);
        else if (!gstrcmp(name, T("DNS6_2")))
                ifx_httpdWrite(wp, T("%s"), dns2buf);



        return 0;
}


int ifx_get_WanProtocol(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char8 *name = NULL, sValue[MAX_FILELINE_LEN];
	int32 wanIdx = -1, linkType;
	uint32 flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT;
	WAN_TYPE sWAN_TYPE = WAN_TYPE_IP;
	IFX_ID	iid;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	memset(sValue, 0x00, sizeof(sValue));

	if(argc == 1) {
		IFX_GET_WAN_SELECTED_INDEX(flags, outFlag, sValue, wanIdx, sWAN_TYPE)
	}
	else {
		if (ifx_get_default_wan_if(&iid, &wanIdx, sValue, IFX_F_DEFAULT)
	    != IFX_SUCCESS) {
		}
		if(!strcmp(iid.cpeId.secName, TAG_WAN_IP))
			sWAN_TYPE = WAN_TYPE_IP;
		else
			sWAN_TYPE = WAN_TYPE_PPP;
	}

	if(link_type_get_from_wan_index(wanIdx, sWAN_TYPE, &linkType) != IFX_SUCCESS) {

	}
	else {
#ifdef CONFIG_FEATURE_CLIP
		if (!strcmp(name, T("static"))) {
			if (linkType == LINK_TYPE_CLIP)
				ifx_httpdWrite(wp,
					       "<option value=\"clip\" %s >Classic IP</option>\n",
					       "selected");
			else
				ifx_httpdWrite(wp,
					       "<option value=\"clip\" >Classic IP</option>\n");
		}
#endif				//CONFIG_FEATURE_CLIP
		
#ifdef CONFIG_PACKAGE_BR2684CTL
		if (linkType == WAN_LINK_TYPE_EOATM)
			ifx_httpdWrite(wp,
				       "<option value=\"rfc2684_eoa\" %s >RFC 2684  EoA</option>\n",
				       "selected");
		else
			ifx_httpdWrite(wp,
				       "<option value=\"rfc2684_eoa\" >RFC 2684  EoA</option>\n");
		
		if (linkType == WAN_LINK_TYPE_IPOATM)
			ifx_httpdWrite(wp,
				       "<option value=\"rfc2684_ipoa\" %s >RFC 2684  IPoA</option>\n",
				       "selected");
		else
			ifx_httpdWrite(wp,
				       "<option value=\"rfc2684_ipoa\" >RFC 2684  IPoA</option>\n");
#else
		ifx_httpdWrite(wp, "<option value=\"none\" %s >None</option>\n",
			       "selected");
#endif				//CONFIG_PACKAGE_BR2684CTL
	}

	return 0;
}

//#endif  /* IFX_HAVE_WAN_STATIC_IP */

//wan_static.asp
int ifx_set_wan_static(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pIP1 = ifx_httpdGetVar(wp, T("IP1"), T(""));
	char_t *pIP2 = ifx_httpdGetVar(wp, T("IP2"), T(""));
	char_t *pIP3 = ifx_httpdGetVar(wp, T("IP3"), T(""));
	char_t *pIP4 = ifx_httpdGetVar(wp, T("IP4"), T(""));
	char_t *pNM1 = ifx_httpdGetVar(wp, T("NM1"), T(""));
	char_t *pNM2 = ifx_httpdGetVar(wp, T("NM2"), T(""));
	char_t *pNM3 = ifx_httpdGetVar(wp, T("NM3"), T(""));
	char_t *pNM4 = ifx_httpdGetVar(wp, T("NM4"), T(""));
	char_t *pGIP1 = ifx_httpdGetVar(wp, T("GIP1"), T(""));
	char_t *pGIP2 = ifx_httpdGetVar(wp, T("GIP2"), T(""));
	char_t *pGIP3 = ifx_httpdGetVar(wp, T("GIP3"), T(""));
	char_t *pGIP4 = ifx_httpdGetVar(wp, T("GIP4"), T(""));
        char_t *PDNS1 = ifx_httpdGetVar(wp, T("PDNS1"), T(""));
        char_t *PDNS2 = ifx_httpdGetVar(wp, T("PDNS2"), T(""));
        char_t *PDNS3 = ifx_httpdGetVar(wp, T("PDNS3"), T(""));
        char_t *PDNS4 = ifx_httpdGetVar(wp, T("PDNS4"), T(""));
        char_t *SDNS1 = ifx_httpdGetVar(wp, T("SDNS1"), T(""));
        char_t *SDNS2 = ifx_httpdGetVar(wp, T("SDNS2"), T(""));
        char_t *SDNS3 = ifx_httpdGetVar(wp, T("SDNS3"), T(""));
        char_t *SDNS4 = ifx_httpdGetVar(wp, T("SDNS4"), T(""));
	char_t *dns_check = ifx_httpdGetVar(wp, T("dns_check_value"), T(""));

#if 1 //AMS
       char_t  temp[50], ip6addr[50], pl6len[50], ip6gw[50], lan6prefix[50], dns6srv1[50], dns6srv2[50];
       char_t  *pIP6_FLAG = ifx_httpdGetVar(wp, T("ipv61"), T(""));
       gsprintf(temp, T("%s"), pIP6_FLAG);
       char_t  *pIP6_1 = ifx_httpdGetVar(wp, T("IP6_1"), T(""));
       gsprintf(ip6addr, T("%s"), pIP6_1);
       char_t  *pPL6_1 = ifx_httpdGetVar(wp, T("PL6_1"), T(""));
       gsprintf(pl6len, T("%s"), pPL6_1);
       char_t  *pGIP6_1 = ifx_httpdGetVar(wp, T("GIP6_1"), T(""));
       gsprintf(ip6gw, T("%s"), pGIP6_1);
       char_t  *pLP6_1 = ifx_httpdGetVar(wp, T("LP6_1"), T(""));
       gsprintf(lan6prefix, T("%s"), pLP6_1);
       char_t  *pDNS6_1 = ifx_httpdGetVar(wp, T("DNS6_1"), T(""));
       int32 sval1 = strlen(pDNS6_1);
       gsprintf(dns6srv1, T("%s"), pDNS6_1);
       char_t  *pDNS6_2 = ifx_httpdGetVar(wp, T("DNS6_2"), T(""));
       int32 sval2 = strlen(pDNS6_2);
       gsprintf(dns6srv2, T("%s"), pDNS6_2);
       int32 retadd;
#endif
	char8 *pconfcon = ifx_httpdGetVar(wp, T("confconname"),T(""));
	//char_t  *pATMProtocol = ifx_httpdGetVar(wp, T("ATM_PROTOCOL"), T(""));
	int nWAN_IDX = -1;
	uint32 flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT, wan_cpeId =
	    0, wan_pcpeId = 0;
	int32 operation = IFX_OP_ADD, ret = IFX_SUCCESS;
	//char8   *link_type = NULL, buf[MAX_FILELINE_LEN];
	char8 buf[MAX_FILELINE_LEN];
	char_t sValue[MAX_NAME_SIZE];
	sValue[0] = '\0';
#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
	char_t igmpoldconnName[MAX_NAME_SIZE]="";
	char_t igmpnewconnName[MAX_NAME_SIZE]="";
	char sVal[MAX_DATA_LEN]="";
	int32 mcast_wan_flag;
#endif
#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
 #if 0
	char8 sWAN_VCC[10], *retVal = NULL;
 #endif
#endif
	WAN_CONN_CFG wan_cfg;
	WAN_COMMON_CFG pWan;
	WAN_TYPE wan_type = WAN_TYPE_IP;
	char_t *page = ifx_httpdGetVar(wp, T("page"), T(""));

	memset(&wan_cfg, 0x00, sizeof(wan_cfg));
	memset(&pWan, 0x00, sizeof(WAN_COMMON_CFG));

	memset(buf, 0x00, sizeof(buf));

 /* pstWanPhy: Global WAN Mode ADSL2+, MIIO, MII1 or PTM */
	WAN_PHY_CFG pstWanPhy;
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	ifx_get_wan_phy_cfg(&pstWanPhy);

	/* WanType: denotes the current WAN Mode selected from Drop-down list
	 * This variable is stored in the System Status file as
	 * ETHx - Ethernet (MIIO & MII1), PTMx - PTM WAN and VPI/VCI - ATM WAN */
	WAN_MODE WanType;
	WanType = ifx_get_wan_mode_selected();
	IFX_GET_WAN_SELECTED_INDEX(IFX_F_GET_ANY, outFlag, buf, nWAN_IDX,
				   wan_type)

	/* Validate the IP Address and Gateway Address */
	if (pIP1 == 0 || gatoi(pIP1) > 255 || pIP2 == 0 || gatoi(pIP2) > 255 ||
	    pIP3 == 0 || gatoi(pIP3) > 255 || pIP4 == 0 || gatoi(pIP4) > 255) {
		ifx_httpdError(wp, 204, "Invalidate IP address");
		return -1;
	}

	if (pNM1 == 0 || gatoi(pNM1) > 255 || pNM2 == 0 || gatoi(pNM2) > 255 ||
	    pNM3 == 0 || gatoi(pNM3) > 255 || pNM4 == 0 || gatoi(pNM4) > 255) {
		ifx_httpdError(wp, 204, "Invalidate Netmask IP address");
		return -1;
	}

#if 0 //AMS
        /* Validate the IP Address and Gateway Address */
        retadd = inet_pton(AF_INET6, (const char *)&ip6addr, &temp6);
        if(retadd <= 0)
        {
               ifx_httpdError(wp, 204, "Invalidate IPv6 address");
               return -1;
        }

        retadd = inet_pton(AF_INET6, (const char *)&ip6gw, &temp6);
        if(retadd <= 0)
        {
               ifx_httpdError(wp, 204, "Invalidate Gateway IPv6 address");
               return -1;
        }
#endif

        if ( pPL6_1 == 0 || gatoi(pPL6_1) > 128) {
               COPY_TO_STATUS("%s", "Invalidate Prefix Length.");
               ifx_httpdRedirect(wp, "err_page.html");
               return -1;
        }

	/* Check if a section is present for this index in system_status file
	 * if present the operation is Modify otherwise Add */

	if (wan_type == WAN_TYPE_PPP && nWAN_IDX >= 0) {

		wan_cfg.type = wan_type;
		ret =
		    mapi_get_wan_config(nWAN_IDX, &wan_cfg, IFX_F_GET_ANY);

		if (ret != IFX_SUCCESS) {
			IFX_DBG
			    ("[%s:%d] unable to get details of existing WAN PPP connection with index [%d]",
			     __FUNCTION__, __LINE__, nWAN_IDX);
			ifx_httpdError(wp, 400,
				       "Unable to get details of existing WAN PPP connection with index [%d]",
				       nWAN_IDX);
			return -1;
		}
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] WAN PPP get on [%d] succeeded", __FUNCTION__,
			__LINE__, nWAN_IDX);
#endif
		GET_WAN_COMM_PTR_1(pWan, wan_cfg)

		    pWan.wan_index = nWAN_IDX;

		/* Set the DELETE operation & Flags */
		operation = IFX_OP_DEL;
		flags = IFX_F_DELETE;

		/* Store the CPE & pCPE Id for this WAN Device
		 * Since this operation is a modify, we need to ADD back with the same values */
		sprintf(pWan.iid.cpeId.secName, "%s", TAG_WAN_PPP);
		wan_cpeId = pWan.iid.cpeId.Id;
		/* AMS */
/* TODO : Need to check with IPv6 team here
   wan_ipv4 = wan_cfg.ipv4;
   wan_ipv6 = wan_cfg.ipv6;
   wan_dhcp_mode = wan_cfg.dhcp_mode;
   wan_iana = wan_cfg.iana;
   wan_iapd = wan_cfg.iapd;
   wan_slaid = wan_cfg.slaid;
   wan_rapid = wan_cfg.rapid;
   wan_sixrd = wan_cfg.tunnel;
                wan_duid_t = wan_cfg.duid_t;
*/
		sprintf(pWan.iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);
		wan_pcpeId = pWan.iid.pcpeId.Id;
		pWan.iid.config_owner = IFX_WEB;
		sprintf(pWan.conf_conn_name,"%s" , pconfcon);

		memcpy(&wan_cfg.WAN_PPP_CONN.wan_cfg, &pWan, sizeof(pWan));
#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
		strcpy(igmpoldconnName,pWan.conn_name);
#endif

#ifdef LTQ_AEI_CUST
		/* Case of changing WAN type from EoA/IPoA to PPPoA */
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] cpeid:sec pcpeid:sec [%d:%s] [%d:%s]", __FUNCTION__, __LINE__,
			wan_cfg.wancfg.ppp.wan_cfg.iid.cpeId.Id, wan_cfg.wancfg.ppp.wan_cfg.iid.cpeId.secName,
			wan_cfg.wancfg.ppp.wan_cfg.iid.pcpeId.Id, wan_cfg.wancfg.ppp.wan_cfg.iid.pcpeId.secName);
#endif

		/* Set the DELETE operation & Flags */
		operation = IFX_OP_DEL;
		flags = IFX_F_DELETE;

		if(wan_cfg.wancfg.ppp.wan_cfg.link_type == WAN_LINK_TYPE_PPPOATM && (WanType == WAN_MODE_ATM || WanType == WAN_MODE_VDSL_ATM)) {
			if(mapi_wan_for_l2_get(wan_cfg.wancfg.ppp.wan_cfg.iid, &vc, &vlan_cfg) != IFX_SUCCESS) {
	#ifdef IFX_LOG_DEBUG
				IFX_DBG
			    ("[%s:%d] Failed to get details of L2 for this WAN PPP connection with index [%d]",
			     __FUNCTION__, __LINE__, nWAN_IDX);
	#endif
				ifx_httpdError(wp, 400,
			    "Failed to get details of L2 for this WAN PPP connection with index [%d]", nWAN_IDX);
				return -1;
			}
		}
#endif

		/* Invoke the CGI handler function to DELETE this WAN connection */
		if (ifx_cgi_set_wan_config
		    (operation, &wan_cfg,
		     flags | IFX_F_DONT_WRITE_TO_FLASH) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "WAN[%d] couldn't be modified !!\n",
				       nWAN_IDX);
			return -1;
		}

#ifdef LTQ_AEI_CUST
		ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, "WAN_VCC",
			       IFX_F_GET_ANY, &outFlag, pWan.l2iface_name);

#if 0 // can't do this, because current l2iface_name is 'pppoatmX'
		/* Get link type of VC channel instance with l2ifName = pWan.l2iface_name */
		vc.type = get_link_type_based_on_l2if(pWan.l2iface_name);
		if (vc.type < 0)
			vc.type = LINK_TYPE_UNCONFIGURED;
#endif

		/* Set link type to EoATM and encapsulation to LLC */
		vc.type = LINK_TYPE_EOATM;
		vc.encap = VC_ENCAP_LLC;

		/* this API call would take care of updating L3 as well ! */
		if(wan_cfg.wancfg.ppp.wan_cfg.link_type == WAN_LINK_TYPE_PPPOATM && (WanType == WAN_MODE_ATM || WanType == WAN_MODE_VDSL_ATM)) {
			operation = IFX_OP_MOD;
			flags = IFX_F_MODIFY;
			if(ifx_set_vcc_cfg(operation, &vc, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("Failed to modify WAN connection to PPPoE");
#endif
				ifx_httpdError(wp, 400, "Failed to modify L2 link type to PPPoA");
				return -1;
			}
			sprintf(buf, "WAN_VCC=\"%s\"\n", vc.l2ifname);
			SetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, IFX_F_MODIFY, 1, buf);
		}
#endif

		memset(&wan_cfg, 0x00, sizeof(wan_cfg));
		memset(&pWan, 0x00, sizeof(pWan));

		/* Populate the CPE and pCPE ID structure by Restoring the 
		 * CPE and pCPE Ids stored during DELETE of this Connection */
		sprintf(pWan.iid.cpeId.secName, "%s", TAG_WAN_IP);
		pWan.iid.cpeId.Id = wan_cpeId;
		sprintf(pWan.iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);
		pWan.iid.pcpeId.Id = wan_pcpeId;

		/* Set the ADD Operation Flags */
		operation = IFX_OP_ADD;
		flags = IFX_F_INT_ADD;
	} else if (wan_type == WAN_TYPE_IP && nWAN_IDX >= 0) {

		wan_cfg.type = wan_type;
		ret =
		    mapi_get_wan_config(nWAN_IDX, &wan_cfg, IFX_F_GET_ANY);

		if (ret != IFX_SUCCESS) {
			IFX_DBG
			    ("[%s:%d] unable to get details of existing WAN IP connection with index [%d]",
			     __FUNCTION__, __LINE__, nWAN_IDX);
			ifx_httpdError(wp, 400,
				       "Unable to get details of existing WAN IP connection with index [%d]",
				       nWAN_IDX);
			return -1;
		}

#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] WAN IP get on [%d] succeeded", __FUNCTION__,
			__LINE__, nWAN_IDX);
#endif
		operation = IFX_OP_MOD;
		flags = IFX_F_MODIFY;

		GET_WAN_COMM_PTR_1(pWan, wan_cfg)

		    /* CANNOT Modify Disabled WAN Connections.
		     * These are configured from TR069 ACS and can't enable the same from Web */
		    if (pWan.f_enable == IFX_DISABLED) {
			ifx_httpdError(wp, 400,
				       "WAN[%d] is currently disabled - Can't modify !!\n",
				       nWAN_IDX);
			return -1;
		}
#if 0 /* TBD */
#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
		/* SPECIAL Case: While modifying the WAN ATM Parameters, i.e VCC information from the drop-down menu,
		 * if the selected VCC is disabled, then we can't configure the WAN Connection
		 * These disabled VCC Channels (DSLLinkConfig Object)could be created from TR069 in DISABLED mode */
		if (WanType == WAN_MODE_ATM) {
			/* Check if the VCC selected is in Disabled Mode
			 * If the vc channel is disabled, can't enable the same from Web */

			/* ATM WAN Mode: get the vcc selected from system status file */
			ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN,
				       "WAN_VCC", IFX_F_GET_ANY, &outFlag,
				       sWAN_VCC);
			/* TBD: We need to find this WAN's pcpeId in VC channel section to find the parent VC channel instance */
			sprintf(buf, "wanip_%d_pcpeId", nWAN_IDX);
			ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf,
				       IFX_F_GET_ANY, &outFlag, sWAN_VCC);
			IFX_DBG("[%s:%d] asking [%s=%s] in [%s]", __FUNCTION__,
				__LINE__, "cpeId", sWAN_VCC,
				TAG_VLAN_CHANNEL);
			if ((ret =
			     ifx_ret_substr_from_distfield(FILE_RC_CONF,
							   TAG_VLAN_CHANNEL,
							   "cpeId", sWAN_VCC,
							   &retVal)) !=
			    IFX_SUCCESS) {
				/* Cannot be - seriously something wrong here */
				ifx_httpdError(wp, 400,
					       "VC Channel [%s] doesn't exist!\n",
					       sWAN_VCC);
				/* Free the returned VCC information */
				IFX_MEM_FREE(retVal)
				    return -1;
			}

			/* Check if the VCC selected is in Disabled Mode */
			memset(sValue, 0x00, sizeof(sValue));
			sprintf(buf, "%s_fEnable", retVal);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_VLAN_CHANNEL, buf,
			     IFX_F_GET_ANY, &outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("\n\nIn Function [%s] : Error--> f_enable not found for vc channel [%s] !!\n\n",
				     __FUNCTION__, retVal);
#endif
				IFX_MEM_FREE(retVal);
				return -1;
			}
			if (atoi(sValue) == IFX_DISABLED) {
				ifx_httpdError(wp, 400,
					       "VC Channel[%s] is currently disabled - Can't select!!\n",
					       sWAN_VCC);
				IFX_MEM_FREE(retVal);
				return -1;
			}
		}
#endif				// CONFIG_FEATURE_ADSL_WAN_SUPPORT
#endif // 0

	} else {
		operation = IFX_OP_ADD;
		flags = IFX_F_INT_ADD;
	}

	/* Currently assume its only ADD op that is supported. Modify support TBD */
#if 0
	if (ifx_GetObjData
	    (FILE_SYSTEM_STATUS, buf, "STATUS", IFX_F_GET_ANY, &outFlag,
	     sValue) != IFX_SUCCESS) {
		/* WAN instance doesn't exist - hence OP_ADD */
		operation = IFX_OP_ADD;
		flags = IFX_F_INT_ADD;
		GET_GLOBAL_RIP_LISTEN_MODE(wan_cfg.wancfg.ip.wan_cfg.route_rx)
	} else {
		/* Here we need to handle the cases for WAN Connection MODIFICATIONS
		 * 1. MODIFY from one WAN Type to another, i.e PPPoX->Static
		 * 2. MODIFY Wan Connection among similar types, i.e Static->,Static DHCP->Static,..

		 * CASE1: In Modification of WAN Connections across different types, PPPoX->Static,
		 * we need to Delete the existing connection and Add the newly configured connection

		 * CASE2: Modify the WAN Connection parameters directly here */

		/* WAN instance exists in configuration - possible to MODIFY or DELETE this instance
		 * Fetch the WAN Configuration for this WAN Index */

		ret =
		    mapi_get_wan_config(nWAN_IDX, &wan_cfg, IFX_F_GET_ANY);

		GET_WAN_COMM_PTR_1(pWan, wan_cfg)

		    if (!strcmp(sValue, "UNCONFIGURED") && (ret != IFX_SUCCESS)) {
			/* Speical case where this WAN instance was previously configured
			 * and now this WAN instance is deleted - hence ADD Operation */
			operation = IFX_OP_ADD;
			flags = IFX_F_INT_ADD;
#if 0
			/* get wan conn name out of wan index */
			sprintf(wan_cfg.WAN_IP_CONN.WAN_CONN.WAN_CONN_NAME,
				"%s%d", "WAN", nWAN_IDX);
#endif				// 0
		} else {

			if (ret != IFX_SUCCESS) {
				/* Shouldn't happen - Error Condition */
				ifx_httpdError(wp, 400,
					       T
					       ("No WAN Connection define on Wan index[%d] !!\n\n"),
					       nWAN_IDX);
				return -1;
			}

			/* MODIFY: Case where the previous connection was PPP that is now being modified to Static
			 * In this case, delete the existing PPP connection and make way for new connection (ADD) */
			if (wan_cfg.type == WAN_LINK_TYPE_PPPOE
			    || wan_cfg.type == WAN_LINK_TYPE_PPPOATM) {
				pWan.wan_index = nWAN_IDX;

				/* Set the DELETE operation & Flags */
				operation = IFX_OP_DEL;
				flags = IFX_F_DELETE;

				/* Store the CPE & pCPE Id for this WAN Device
				 * Since this operation is a modify, we need to ADD back with the same values */
				sprintf(pWan.iid.cpeId.secName, "%s",
					TAG_WAN_MAIN);
				wan_cpeId = pWan.iid.cpeId.Id;
				sprintf(pWan.iid.pcpeId.secName, "%s",
					TAG_WAN_CONN_DEVICE);
				wan_pcpeId = pWan.iid.pcpeId.Id;
				pWan.iid.config_owner = IFX_WEB;

				/* Invoke the CGI handler function to DELETE this WAN connection */
				if (ifx_cgi_set_wan_config
				    (operation, &wan_cfg,
				     flags | IFX_F_DONT_WRITE_TO_FLASH) !=
				    IFX_SUCCESS) {
					ifx_httpdError(wp, 400,
						       "WAN[%d] couldn't be modified !!\n",
						       nWAN_IDX);
					return -1;
				}

				/* PREPARE FOR ADDING NEW CONNECTION NOW */
				/* Now that we've deleted the WAN Connection above, prepare 
				 * for ADDing the new WAN Type Connection here */
				memset(&wan_cfg, 0x00, sizeof(wan_cfg));

				/* Populate the CPE and pCPE ID structure by Restoring the 
				 * CPE and pCPE Ids stored during DELETE of this Connection */
				sprintf(pWan.iid.cpeId.secName, "%s",
					TAG_WAN_MAIN);
				pWan.iid.cpeId.Id = wan_cpeId;
				sprintf(pWan.iid.pcpeId.secName, "%s",
					TAG_WAN_CONN_DEVICE);
				pWan.iid.pcpeId.Id = wan_pcpeId;

				/* Set the ADD Operation Flags */
				operation = IFX_OP_ADD;
				flags = IFX_F_INT_ADD;

			} else {

				/* MODIFY: Case where the previous connection was of similar Type - Static, DHCP or Bridge 
				 * Modify from Static->DHCP, Bridge->DHCP or DHCP->DHCP */

				operation = IFX_OP_MOD;
				flags = IFX_F_MODIFY;

				/* CANNOT Modify Disabled WAN Connections.
				 * These are configured from TR069 ACS and can't enable the same from Web */
				if (pWan.f_enable == IFX_DISABLED) {
					ifx_httpdError(wp, 400,
						       "WAN[%d] is currently disabled - Can't modify !!\n",
						       nWAN_IDX);
					return -1;
				}
#if 0 /* TBD */
#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
				/* SPECIAL Case: While modifying the WAN ATM Parameters, i.e VCC information from the drop-down menu,
				 * if the selected VCC is disabled, then we can't configure the WAN Connection
				 * These disabled VCC Channels (DSLLinkConfig Object)could be created from TR069 in DISABLED mode */
				if (WanType == WAN_MODE_ATM) {
					/* Check if the VCC selected is in Disabled Mode
					 * If the vc channel for this connection is disabled, can't enable the same from Web */

					/* ATM WAN Mode: get the l2 interface selected from system status file */
					ifx_GetObjData(FILE_SYSTEM_STATUS,
						       TAG_WAN_MAIN, "WAN_VCC",
						       IFX_F_GET_ANY, &outFlag,
						       sWAN_VCC);
					IFX_DBG
					    ("[%s:%d] asking [%s=%s] in [%s]",
					     __FUNCTION__, __LINE__, "l2ifName",
					     sWAN_VCC, TAG_VLAN_CHANNEL);
					if (ifx_ret_substr_from_distfield
					    (FILE_RC_CONF, TAG_VLAN_CHANNEL,
					     "l2ifName", sWAN_VCC,
					     &retVal) != IFX_SUCCESS) {
						/* Cannot be - seriously something wrong here */
						ifx_httpdError(wp, 400,
							       "VC Channel [%s] doesn't exist!\n",
							       sWAN_VCC);
						/* Free the returned VCC information */
						IFX_MEM_FREE(retVal)
						    return -1;
					}

					/* Check if the VCC selected is in Disabled Mode */
					memset(sValue, 0x00, sizeof(sValue));
					sprintf(buf, "%s_fEnable", retVal);
					if (ifx_GetObjData
					    (FILE_RC_CONF, TAG_VLAN_CHANNEL,
					     buf, IFX_F_GET_ANY, &outFlag,
					     sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
						IFX_DBG
						    ("\n\nIn Function [%s] : Error--> f_enable not found for vc channel [%s] !!\n\n",
						     __FUNCTION__, retVal);
#endif
						IFX_MEM_FREE(retVal);
						return -1;
					}
					if (atoi(sValue) == IFX_DISABLED) {
						ifx_httpdError(wp, 400,
							       "VC Channel[%s] is currently disabled - Can't select!!\n",
							       sWAN_VCC);
						IFX_MEM_FREE(retVal);
						return -1;
					}
				}
				IFX_MEM_FREE(retVal);
#endif				/* CONFIG_FEATURE_ADSL_WAN_SUPPORT */
#endif // 0
			}
		}
	}

	operation = IFX_OP_ADD;
	flags = IFX_F_INT_ADD;
	GET_GLOBAL_RIP_LISTEN_MODE(wan_cfg.wancfg.ip.wan_cfg.route_rx)
#endif				// 0
	    /* Use the unique interface information to establish the Parent-Child relationship
	     * In case of ATM WAN, VCC information is used and in PTM, ETH WAN connections, the
	     * interface information is used along with VLAN Tag */
	    /* For ATM WAN Mode, link type check for eoa or ipoa or clip in atm_protocol */
	if (WanType == WAN_MODE_ATM || WanType == WAN_MODE_VDSL_ATM) {
		/*
		   link_type = strrchr(pATMProtocol, '_');
		   if(link_type)
		   {
		   if (!gstrcmp(link_type, "_ipoa"))
		   pWan.link_type = WAN_LINK_TYPE_IPOATM;
		   else if (!gstrcmp(link_type, "_eoa"))
		   pWan.link_type = WAN_LINK_TYPE_EOATM;
		   }
		 */
		ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, "WAN_VCC",
			       IFX_F_GET_ANY, &outFlag, pWan.l2iface_name);

		/* Get link type of VC channel instance with l2ifName = pWan.l2iface_name */
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] l2iface [%s]", __FUNCTION__, __LINE__,
			pWan.l2iface_name);
#endif
		pWan.link_type = get_link_type_based_on_l2if(pWan.l2iface_name);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] link type [%d] for l2iface [%s]", __FUNCTION__,
			__LINE__, pWan.link_type, pWan.l2iface_name);
#endif
		if (pWan.link_type < 0)
			pWan.link_type = LINK_TYPE_UNCONFIGURED;

		if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2)
			pWan.wan_mode.mode = WAN_MODE_ATM;
		else
			pWan.wan_mode.mode = WAN_MODE_VDSL_ATM;
	} else if (WanType == WAN_MODE_PTM || WanType == WAN_MODE_VDSL_PTM) {
		ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, "WAN_VCC",
			       IFX_F_GET_ANY, &outFlag, pWan.l2iface_name);
		pWan.link_type = WAN_LINK_TYPE_PTM;
		/* TBD : This code is needed when ADSL PTM support is available on VRX platforms, take care in future */
		if (pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2)
			pWan.wan_mode.mode = WAN_MODE_VDSL_PTM;
		else
			pWan.wan_mode.mode = WAN_MODE_PTM;
#if 0
#ifdef PLATFORM_VR9
			pWan.wan_mode.mode = WAN_MODE_VDSL_PTM;
#else
			pWan.wan_mode.mode = WAN_MODE_PTM;
#endif
#endif
		//      gstrcpy(pWan.wan_mode.iface,"ptm0"); 
	} else {
		ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, "WAN_VCC",
			       IFX_F_GET_ANY, &outFlag, pWan.l2iface_name);
		pWan.link_type = WAN_LINK_TYPE_ETH;
		if (strstr(pWan.l2iface_name, "eth0"))
			pWan.wan_mode.mode = WAN_MODE_ETH0;
		else if (strstr(pWan.l2iface_name, "eth1"))
			pWan.wan_mode.mode = WAN_MODE_ETH1;
		/* In case of global WAN Mode as ADSL, the user is trying to
		 * configure an Ethernet WAN Connection, we assume that it'll be over
		 * MII0 interface */
		/*else if(pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2) 
		   gstrcpy(pWan.wan_mode.iface,"eth0"); */
	}

	/* Set the wan index */
	pWan.wan_index = nWAN_IDX;

	if (operation == IFX_OP_ADD) {
#ifdef CONFIG_FEATURE_RIP
		/* Set RIP information based on the Global RIP State & Listen Mode */
		ifx_set_wanif_route_proto(nWAN_IDX, &pWan);
#endif
	}
#ifdef CONFIG_FEATURE_NAPT
	/* Currently we set the NAT on interface level as always ENABLED 
	 * Once the interface level option is configurable, then it can be put here */
	pWan.WAN_CONN_NAT_ENABLED = IFX_ENABLED;
#endif

	ifx_check_dw_status(&(pWan.def_wan),
			    ifx_httpdGetVar(wp, T("def_wan"), T("")));

	/* set the dns override option to true */
	pWan.wandns.WAN_CONN_DNS_OVERRIDE = IFX_ENABLED;
		
	if(atoi(dns_check)) {
		pWan.wandns.WAN_CONN_DNS_OVERRIDE = IFX_DISABLED;
		memset(buf, 0x00, sizeof(buf));
		snprintf(buf, sizeof(buf), T("%s.%s.%s.%s"), PDNS1, PDNS2, PDNS3, PDNS4);
		pWan.wandns.dns_servers[0].s_addr = inet_addr(buf);
		memset(buf, 0x00, sizeof(buf));
		snprintf(buf, sizeof(buf), T("%s.%s.%s.%s"), SDNS1, SDNS2, SDNS3, SDNS4);
		pWan.wandns.dns_servers[1].s_addr = inet_addr(buf);
	}

	/* Enable this WAN Connection & Set the config owner to WEB */
	pWan.f_enable = IFX_ENABLED;
	pWan.iid.config_owner = IFX_WEB;

	/* Populate the CPE and pCPE Section Names */
	sprintf(pWan.iid.cpeId.secName, "%s", TAG_WAN_MAIN);
	sprintf(pWan.iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);

        if (atoi(temp) == 2)
                pWan.ipv6 = atoi(temp);        /* 2 means enabled */
        else
                pWan.ipv6 = 1;  /* 1 means disabled */


	sprintf(pWan.conf_conn_name,"%s" , pconfcon);
	memcpy(&wan_cfg.WAN_IP_CONN.wan_cfg, &pWan, sizeof(pWan));

	/* get ip address and netmask */
	memset(buf, 0x00, sizeof(buf));
	gsprintf(buf, T("%s.%s.%s.%s"), pIP1, pIP2, pIP3, pIP4);
	wan_cfg.WAN_IPv4_CFG.WAN_CONN_IPADDR.s_addr = inet_addr(buf);

	memset(buf, 0x00, sizeof(buf));
	gsprintf(buf, T("%s.%s.%s.%s"), pNM1, pNM2, pNM3, pNM4);
	wan_cfg.WAN_IPv4_CFG.WAN_CONN_IPMASK.s_addr = inet_addr(buf);

	/* Set the gateway IP Address */
	if (pGIP1 != 0) {
		memset(buf, 0x00, sizeof(buf));
		gsprintf(buf, T("%s.%s.%s.%s"), pGIP1, pGIP2, pGIP3, pGIP4);
		wan_cfg.WAN_IPv4_CFG.ip_gw.s_addr = inet_addr(buf);
	}

#if 1 //AMS
     if (atoi(temp) == 2)
     {
        retadd = inet_pton(AF_INET6, (const char *)&ip6addr, &wan_cfg.wanv6.WAN_CONN_IPADDR6.s6_addr);
        if (retadd <= 0) {
                COPY_TO_STATUS("%s", "Invalidate IPv6 address.");
                ifx_httpdRedirect(wp, "err_page.html");
                return -1;
        }

        wan_cfg.WAN_IPv6_CFG.ip6_mask.prefixlen = atoi(pl6len); 

        retadd = inet_pton(AF_INET6, (const char *)&ip6gw, &wan_cfg.WAN_IPv6_CFG.ip6_gw.s6_addr);
        if (retadd <= 0) {
                COPY_TO_STATUS("%s", "Invalidate IPv6 Gateway address.");
                ifx_httpdRedirect(wp, "err_page.html");
                return -1;
        }

        retadd = inet_pton(AF_INET6, (const char *)&lan6prefix, &wan_cfg.WAN_IPv6_CFG.lan_prefix);
        if (retadd <= 0) {
                COPY_TO_STATUS("%s", "Invalidate Lan Prefix");
                ifx_httpdRedirect(wp, "err_page.html");
                return -1;
        }

        if (sval1 != 0)
        {
          retadd = inet_pton(AF_INET6, (const char *)&dns6srv1, &wan_cfg.WAN_IPv6_CFG.ip6_dns1.s6_addr);
          if (retadd <= 0) {
                COPY_TO_STATUS("%s", "Invalidate IPv6 Primary DNS Server address.");
                ifx_httpdRedirect(wp, "err_page.html");
                return -1;
          }
        }
        if (sval2 != 0)
        {
          retadd = inet_pton(AF_INET6, (const char *)&dns6srv2, &wan_cfg.WAN_IPv6_CFG.ip6_dns2.s6_addr);
          if (retadd <= 0) {
                COPY_TO_STATUS("%s", "Invalidate IPv6 Secondary DNS Server address.");
                ifx_httpdRedirect(wp, "err_page.html");
                return -1;
          }
        }
     }
#endif

	ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, "ipoption_wan",
		       IFX_F_GET_ANY, &outFlag, sValue);

	/* get ipoption_wan and interpret connType out of it */
	if (!gstrcmp(sValue, "FIXED") || !gstrcmp(sValue, "DHCPC"))
		wan_cfg.WAN_IP_CONN.conn_type = WAN_IP_CONN_TYPE_IP_ROUTED;

	/* set the status as connecting */
	wan_cfg.WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_CONNECTING;

	/* get ipoption_wan and interpret addr_type out of it */
	if (!gstrcmp(sValue, "FIXED"))
		wan_cfg.WAN_IP_CONN.addr_type = IP_TYPE_STATIC;
	if (!gstrcmp(sValue, "DHCPC"))
		wan_cfg.WAN_IP_CONN.addr_type = IP_TYPE_DHCP;

	if (operation == IFX_OP_MOD) {
		/* Check for dependencies with the modified WAN Connection */
		if (ifx_check_wan_configuration_dependency(&wan_cfg) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 500,
				       T
				       ("Modification of link type of wan connection from or to CLIP mode is not allowed !!"));
			return -1;
		}
	}

	/* Invoke the CGI function to configure the WAN Connection */
	ret = ifx_cgi_set_wan_config(operation, &wan_cfg, flags);
#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
	if(strlen(newconnName) != 0) {
			strcpy(igmpnewconnName,newconnName);
			mcast_wan_flag=Update_mcast_wan_flag(0,0);
			ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_upstream_wan", sVal);
			
			if (strlen(igmpoldconnName) != 0 ) {
				if (mcast_wan_flag == 1) {
					Update_igmp_config(igmpoldconnName,igmpnewconnName,0);
					mcast_wan_flag=0;
				} else if (mcast_wan_flag == 2 ) {
					mcast_wan_flag=0;
				} else if (mcast_wan_flag == 0){
					if ( strstr(sVal,igmpoldconnName) != NULL ) {
						mcast_wan_flag =3;
						Update_mcast_wan_flag(1,mcast_wan_flag);
						Update_igmp_config(igmpoldconnName,igmpnewconnName,0);
						mcast_wan_flag=0;
					}
				}
				Update_mcast_wan_flag(1,mcast_wan_flag);
			}
	}
#endif
	if (ret != IFX_SUCCESS) {
		if (ret == IFX_PCR_CHK_FAIL) {
			/* Should be checked for only ATM WAN Connections */
			COPY_TO_STATUS("%s", pcr_chk_err)
			    ifx_httpdRedirect(wp, T("err_page.html"));
			return 0;
		} else
			ifx_httpdError(wp, 500,
				       T
				       ("Failed to configure Static parameters on this wan connection"));
		return -1;
	}
	else
        {
#ifdef CONFIG_FEATURE_NAPT

                IFX_DBG("[%s:%d] ", __FUNCTION__, __LINE__);
                if(strlen(newconnName) != 0)
                {
                        ret = Update_virtual_server_config(newconnName,"modify");
                }
#endif
        }
	

IFX_Handler:
	if (!strcmp(page, "wan_static.asp"))
		ifx_httpdRedirect(wp, T("wan_vcc_select.asp"));
	if (!strcmp(page, "wan_vcc_select.asp"))
		ifx_httpdRedirect(wp, T("wan_vcc_select.asp"));
	return 0;
}

//end wan_static.asp

//bridge_setting.asp
int ifx_set_bridge_settings(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pCheck;
	char_t sCheck[MAX_FILELINE_LEN];
	char_t sCommand[MAX_FILELINE_LEN];
	char_t sValue[MAX_NAME_SIZE];
	int nWAN_IDX = -1;
	uint32 flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT, wan_cpeId =
	    0, wan_pcpeId = 0;
	int32 operation = IFX_OP_ADD, ret = IFX_SUCCESS;
        int32 bridge_voip = 0;
	char8 buf[MAX_FILELINE_LEN];
	WAN_CONN_CFG wan_cfg;
	WAN_COMMON_CFG pWan;
	char_t *page = ifx_httpdGetVar(wp, T("page"), T(""));
	char8 *pconfcon = ifx_httpdGetVar(wp, T("confconname"),T(""));
	WAN_TYPE wan_type = WAN_TYPE_IP;

	sCheck[0] = '\0';
	sCommand[0] = '\0';
	memset(buf, 0x00, sizeof(buf));
	memset(&wan_cfg, 0x00, sizeof(wan_cfg));
	memset(&pWan, 0x00, sizeof(pWan));

	/* pstWanPhy: Global WAN Mode ADSL2+, MIIO, MII1 or PTM */
	WAN_PHY_CFG pstWanPhy;
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	ifx_get_wan_phy_cfg(&pstWanPhy);

	/* WanType: denotes the current WAN Mode selected from Drop-down list
	 * This variable is stored in the System Status file as
	 * ETHx - Ethernet (MIIO & MII1), PTMx - PTM WAN and VPI/VCI - ATM WAN */
	WAN_MODE WanType;

	WanType = ifx_get_wan_mode_selected();
	IFX_GET_WAN_SELECTED_INDEX(flags, outFlag, sValue, nWAN_IDX, wan_type)
	//v Bridge Validation
#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
	if(ltq_bridge_validation(WanType) != IFX_SUCCESS){
 		COPY_TO_STATUS("%s", dw_config_err)
			ifx_httpdRedirect(wp, T("err_page.html")); 
		return IFX_FAILURE;
	}
#endif

	    /* WAN instance exists in configuration - possible to MODIFY or DELETE this instance
	     * Fetch the WAN Configuration for this WAN Index */
	    if (wan_type == WAN_TYPE_PPP && nWAN_IDX >= 0) {

		wan_cfg.type = wan_type;
		ret =
		    mapi_get_wan_config(nWAN_IDX, &wan_cfg, IFX_F_GET_ANY);

		if (ret != IFX_SUCCESS) {
			IFX_DBG
			    ("[%s:%d] unable to get details of existing WAN PPP connection with index [%d]",
			     __FUNCTION__, __LINE__, nWAN_IDX);
			ifx_httpdError(wp, 400,
				       "Unable to get details of existing WAN PPP connection with index [%d]",
				       nWAN_IDX);
			return -1;
		}
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] WAN PPP get on [%d] succeeded", __FUNCTION__,
			__LINE__, nWAN_IDX);
#endif
		GET_WAN_COMM_PTR_1(pWan, wan_cfg)

		    pWan.wan_index = nWAN_IDX;

		/* Set the DELETE operation & Flags */
		operation = IFX_OP_DEL;
		flags = IFX_F_DELETE;

		/* Store the CPE & pCPE Id for this WAN Device
		 * Since this operation is a modify, we need to ADD back with the same values */
		sprintf(pWan.iid.cpeId.secName, "%s", TAG_WAN_PPP);
		wan_cpeId = pWan.iid.cpeId.Id;
		/* AMS */
/* TODO : Need to check with IPv6 team here
   wan_ipv4 = wan_cfg.ipv4;
   wan_ipv6 = wan_cfg.ipv6;
   wan_dhcp_mode = wan_cfg.dhcp_mode;
   wan_iana = wan_cfg.iana;
   wan_iapd = wan_cfg.iapd;
   wan_slaid = wan_cfg.slaid;
   wan_rapid = wan_cfg.rapid;
   wan_sixrd = wan_cfg.tunnel;
                wan_duid_t = wan_cfg.duid_t;
*/
		sprintf(pWan.iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);
		wan_pcpeId = pWan.iid.pcpeId.Id;
		pWan.iid.config_owner = IFX_WEB;

		sprintf(pWan.conf_conn_name,"%s" , pconfcon);
		memcpy(&wan_cfg.WAN_PPP_CONN.wan_cfg, &pWan, sizeof(pWan));

#ifdef LTQ_AEI_CUST
		/* Case of changing WAN type from EoA/IPoA to PPPoA */
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] cpeid:sec pcpeid:sec [%d:%s] [%d:%s]", __FUNCTION__, __LINE__,
			wan_cfg.wancfg.ppp.wan_cfg.iid.cpeId.Id, wan_cfg.wancfg.ppp.wan_cfg.iid.cpeId.secName,
			wan_cfg.wancfg.ppp.wan_cfg.iid.pcpeId.Id, wan_cfg.wancfg.ppp.wan_cfg.iid.pcpeId.secName);
#endif

		/* Set the DELETE operation & Flags */
		operation = IFX_OP_DEL;
		flags = IFX_F_DELETE;

		if(wan_cfg.wancfg.ppp.wan_cfg.link_type == WAN_LINK_TYPE_PPPOATM && (WanType == WAN_MODE_ATM || WanType == WAN_MODE_VDSL_ATM)) {
			if(mapi_wan_for_l2_get(wan_cfg.wancfg.ppp.wan_cfg.iid, &vc, &vlan_cfg) != IFX_SUCCESS) {
	#ifdef IFX_LOG_DEBUG
				IFX_DBG
			    ("[%s:%d] Failed to get details of L2 for this WAN PPP connection with index [%d]",
			     __FUNCTION__, __LINE__, nWAN_IDX);
	#endif
				ifx_httpdError(wp, 400,
			    "Failed to get details of L2 for this WAN PPP connection with index [%d]", nWAN_IDX);
				return -1;
			}
		}
#endif

		/* Invoke the CGI handler function to DELETE this WAN connection */
		if (ifx_cgi_set_wan_config
		    (operation, &wan_cfg,
		     flags | IFX_F_DONT_WRITE_TO_FLASH) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "WAN[%d] couldn't be modified !!\n",
				       nWAN_IDX);
			return -1;
		}

#ifdef LTQ_AEI_CUST
		ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, "WAN_VCC",
			       IFX_F_GET_ANY, &outFlag, pWan.l2iface_name);

#if 0 // can't do this, because current l2iface_name is 'pppoatmX'
		/* Get link type of VC channel instance with l2ifName = pWan.l2iface_name */
		vc.type = get_link_type_based_on_l2if(pWan.l2iface_name);
		if (vc.type < 0)
			vc.type = LINK_TYPE_UNCONFIGURED;
#endif

		/* Set link type to EoATM and encapsulation to LLC */
		vc.type = LINK_TYPE_EOATM;
		vc.encap = VC_ENCAP_LLC;

		/* this API call would take care of updating L3 as well ! */
		if(wan_cfg.wancfg.ppp.wan_cfg.link_type == WAN_LINK_TYPE_PPPOATM && (WanType == WAN_MODE_ATM || WanType == WAN_MODE_VDSL_ATM)) {
			operation = IFX_OP_MOD;
			flags = IFX_F_MODIFY;
			if(ifx_set_vcc_cfg(operation, &vc, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("Failed to modify WAN connection to PPPoE");
#endif
				ifx_httpdError(wp, 400, "Failed to modify L2 link type to PPPoA");
				return -1;
			}
			sprintf(buf, "WAN_VCC=\"%s\"\n", vc.l2ifname);
			SetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, IFX_F_MODIFY, 1, buf);
		}
#endif

		memset(&wan_cfg, 0x00, sizeof(wan_cfg));
		memset(&pWan, 0x00, sizeof(pWan));

		/* Populate the CPE and pCPE ID structure by Restoring the 
		 * CPE and pCPE Ids stored during DELETE of this Connection */
		sprintf(pWan.iid.cpeId.secName, "%s", TAG_WAN_IP);
		pWan.iid.cpeId.Id = wan_cpeId;
		sprintf(pWan.iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);
		pWan.iid.pcpeId.Id = wan_pcpeId;

		/* Set the ADD Operation Flags */
		operation = IFX_OP_ADD;
		flags = IFX_F_INT_ADD;
	} else if (wan_type == WAN_TYPE_IP && nWAN_IDX >= 0) {

		wan_cfg.type = wan_type;
		ret =
		    mapi_get_wan_config(nWAN_IDX, &wan_cfg, IFX_F_GET_ANY);

		if (ret != IFX_SUCCESS) {
			IFX_DBG
			    ("[%s:%d] unable to get details of existing WAN IP connection with index [%d]",
			     __FUNCTION__, __LINE__, nWAN_IDX);
			ifx_httpdError(wp, 400,
				       "Unable to get details of existing WAN IP connection with index [%d]",
				       nWAN_IDX);
			return -1;
		}

#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] WAN IP get on [%d] succeeded", __FUNCTION__,
			__LINE__, nWAN_IDX);
#endif
		operation = IFX_OP_MOD;
		flags = IFX_F_MODIFY;

		GET_WAN_COMM_PTR_1(pWan, wan_cfg)

		    /* CANNOT Modify Disabled WAN Connections.
		     * These are configured from TR069 ACS and can't enable the same from Web */
		    if (pWan.f_enable == IFX_DISABLED) {
			ifx_httpdError(wp, 400,
				       "WAN[%d] is currently disabled - Can't modify !!\n",
				       nWAN_IDX);
			return -1;
		}
#if 0 /* TBD */
#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
		/* SPECIAL Case: While modifying the WAN ATM Parameters, i.e VCC information from the drop-down menu,
		 * if the selected VCC is disabled, then we can't configure the WAN Connection
		 * These disabled VCC Channels (DSLLinkConfig Object)could be created from TR069 in DISABLED mode */
		if (WanType == WAN_MODE_ATM) {
			/* Check if the VCC selected is in Disabled Mode
			 * If the vc channel is disabled, can't enable the same from Web */

			/* TBD: We need to find this WAN's pcpeId in VC channel section to find the parent VC channel instance */
			sprintf(buf, "wanip_%d_pcpeId", nWAN_IDX);
			ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf,
				       IFX_F_GET_ANY, &outFlag, sWAN_VCC);
			IFX_DBG("[%s:%d] asking [%s=%s] in [%s]", __FUNCTION__,
				__LINE__, "cpeId", sWAN_VCC,
				TAG_VLAN_CHANNEL);
			if ((ret =
			     ifx_ret_substr_from_distfield(FILE_RC_CONF,
							   TAG_VLAN_CHANNEL,
							   "cpeId", sWAN_VCC,
							   &retVal)) !=
			    IFX_SUCCESS) {
				/* Cannot be - seriously something wrong here */
				ifx_httpdError(wp, 400,
					       "VC Channel [%s] doesn't exist!\n",
					       sWAN_VCC);
				/* Free the returned VCC information */
				IFX_MEM_FREE(retVal)
				    return -1;
			}

			/* Check if the VCC selected is in Disabled Mode */
			memset(sValue, 0x00, sizeof(sValue));
			sprintf(buf, "%s_fEnable", retVal);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_VLAN_CHANNEL, buf,
			     IFX_F_GET_ANY, &outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("\n\nIn Function [%s] : Error--> f_enable not found for vc channel [%s] !!\n\n",
				     __FUNCTION__, retVal);
#endif
				IFX_MEM_FREE(retVal);
				return -1;
			}
			if (atoi(sValue) == IFX_DISABLED) {
				ifx_httpdError(wp, 400,
					       "VC Channel[%s] is currently disabled - Can't select!!\n",
					       sWAN_VCC);
				IFX_MEM_FREE(retVal);
				return -1;
			}
		}
#endif				// CONFIG_FEATURE_ADSL_WAN_SUPPORT
#endif // 0

	} else {
		operation = IFX_OP_ADD;
		flags = IFX_F_INT_ADD;
	}

	/* Currently assume its only ADD op that is supported. Modify support TBD */
#if 0
	if (ifx_GetObjData
	    (FILE_SYSTEM_STATUS, buf, "STATUS", IFX_F_GET_ENA, &outFlag,
	     sValue) != IFX_SUCCESS) {
		operation = IFX_OP_ADD;
		flags = IFX_F_INT_ADD;
		/* WAN instance doesn't exist - hence OP_ADD */
		GET_GLOBAL_RIP_LISTEN_MODE(pWan.route_rx)
	} else {
		/* Here we need to handle the cases for WAN Connection MODIFICATIONS
		 * 1. MODIFY from one WAN Type to another, i.e PPPoX->Bridge
		 * 2. MODIFY Wan Connection among similar types, i.e Static->Bridge, DHCP->Bridge,..

		 * CASE1: In Modification of WAN Connections across different types, PPPoX->Bridge,
		 * we need to Delete the existing connection and Add the newly configured connection

		 * CASE2: Modify the WAN Connection parameters directly here */

		/* WAN instance exists in configuration - possible to MODIFY or DELETE this instance
		 * Fetch the WAN Configuration for this WAN Index */

		ret =
		    mapi_get_wan_config(nWAN_IDX, &wan_cfg, IFX_F_GET_ANY);

		if (!strcmp(sValue, "UNCONFIGURED") && (ret != IFX_SUCCESS)) {
			/* Speical case where this WAN instance was previously configured
			 * and now this WAN instance is deleted - hence ADD Operation */
			operation = IFX_OP_ADD;
			flags = IFX_F_INT_ADD;
#if 0
			/* get wan conn name out of wan index */
			sprintf(pWan.WAN_CONN_NAME, "%s%d", "WAN", nWAN_IDX);
#endif				// 0
		} else {

			if (ret != IFX_SUCCESS) {
				/* Shouldn't happen - Error Condition */
				ifx_httpdError(wp, 400,
					       T
					       ("No WAN Connection define on Wan index[%d] !!\n\n"),
					       nWAN_IDX);
				return -1;
			}

			/* MODIFY: Case where the previous connection was PPP that is now being modified to Bridge
			 * In this case, delete the existing PPP connection and make way for new connection (ADD) */
			if (wan_cfg.type == WAN_LINK_TYPE_PPPOE
			    || wan_cfg.type == WAN_LINK_TYPE_PPPOATM) {
				pWan.wan_index = nWAN_IDX;

				/* Set the DELETE operation & Flags */
				operation = IFX_OP_DEL;
				flags = IFX_F_DELETE;

				/* Store the CPE & pCPE Id for this WAN Device
				 * Since this operation is a modify, we need to ADD back with the same values */
				sprintf(pWan.iid.cpeId.secName, "%s",
					TAG_WAN_MAIN);
				wan_cpeId = pWan.iid.cpeId.Id;
				sprintf(pWan.iid.pcpeId.secName, "%s",
					TAG_WAN_CONN_DEVICE);
				wan_pcpeId = pWan.iid.pcpeId.Id;
				pWan.iid.config_owner = IFX_WEB;

				/* Invoke the CGI handler function to DELETE this WAN connection */
				if (ifx_cgi_set_wan_config
				    (operation, &wan_cfg,
				     flags | IFX_F_DONT_WRITE_TO_FLASH) !=
				    IFX_SUCCESS) {
					ifx_httpdError(wp, 400,
						       "WAN[%d] couldn't be modified !!\n",
						       nWAN_IDX);
					return -1;
				}

				/* PREPARE FOR ADDING NEW CONNECTION NOW */
				/* Now that we've deleted the WAN Connection above, prepare 
				 * for ADDing the new WAN Type Connection here */
				memset(&wan_cfg, 0x00, sizeof(wan_cfg));
				GET_GLOBAL_RIP_LISTEN_MODE(wan_cfg.wancfg.ip.
							   wan_cfg.route_rx)

				    /* Populate the CPE and pCPE ID structure by Restoring the 
				     * CPE and pCPE Ids stored during DELETE of this Connection */
				    sprintf(pWan.iid.cpeId.secName, "%s",
					    TAG_WAN_MAIN);
				pWan.iid.cpeId.Id = wan_cpeId;
				sprintf(pWan.iid.pcpeId.secName, "%s",
					TAG_WAN_CONN_DEVICE);
				pWan.iid.pcpeId.Id = wan_pcpeId;

				/* Set the ADD Operation Flags */
				operation = IFX_OP_ADD;
				flags = IFX_F_INT_ADD;

			} else {

				/* MODIFY: Case where the previous connection was of similar Type - Static, DHCP or Bridge 
				 * Modify from Static->DHCP, Bridge->DHCP or DHCP->DHCP */
				operation = IFX_OP_MOD;
				flags = IFX_F_MODIFY;

				/* CANNOT Modify Disabled WAN Connections.
				 * These are configured from TR069 ACS and can't enable the same from Web */
				if (pWan.f_enable == IFX_DISABLED) {
					ifx_httpdError(wp, 400,
						       "WAN[%d] is currently disabled - Can't modify !!\n",
						       nWAN_IDX);
					return -1;
				}
#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
				/* SPECIAL Case: While modifying the WAN ATM Parameters, i.e VCC information from the drop-down menu,
				 * if the selected VCC is disabled, then we can't configure the WAN Connection
				 * These disabled VCC Channels (DSLLinkConfig Object)could be created from TR069 in DISABLED mode */
				if (WanType == WAN_MODE_ATM || WanType == WAN_MODE_VDSL_ATM) {
					/* Check if the VCC selected is in Disabled Mode
					 * If the vc channel for this connection is disabled, can't enable the same from Web */

					/* ATM WAN Mode: get the vcc selected from system status file */
					ifx_GetObjData(FILE_SYSTEM_STATUS,
						       TAG_WAN_MAIN, "WAN_VCC",
						       IFX_F_GET_ANY, &outFlag,
						       sWAN_VCC);
					IFX_DBG
					    ("[%s:%d] asking [%s=%s] in [%s]",
					     __FUNCTION__, __LINE__, "l2ifName",
					     sWAN_VCC, TAG_VLAN_CHANNEL);
					if (ifx_ret_substr_from_distfield
					    (FILE_RC_CONF, TAG_VLAN_CHANNEL,
					     "l2ifName", sWAN_VCC,
					     &retVal) != IFX_SUCCESS) {
						/* Cannot be - seriously something wrong here */
						ifx_httpdError(wp, 400,
							       "VC Channel [%s] doesn't exist!\n",
							       sWAN_VCC);
						/* Free the returned VCC information */
						IFX_MEM_FREE(retVal)
						    return -1;
					}

					/* Check if the VCC selected is in Disabled Mode */
					memset(sValue, 0x00, sizeof(sValue));
					sprintf(buf, "%s_fEnable", retVal);
					if (ifx_GetObjData
					    (FILE_RC_CONF, TAG_VLAN_CHANNEL,
					     buf, IFX_F_GET_ANY, &outFlag,
					     sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
						IFX_DBG
						    ("\n\nIn Function [%s] : Error--> f_enable not found for vc channel [%s] !!\n\n",
						     __FUNCTION__, retVal);
#endif
						IFX_MEM_FREE(retVal);
						return -1;
					}
					if (atoi(sValue) == IFX_DISABLED) {
						ifx_httpdError(wp, 400,
							       "VC Channel[%s] is currently disabled - Can't select!!\n",
							       sWAN_VCC);
						IFX_MEM_FREE(retVal);
						return -1;
					}
				}
				IFX_MEM_FREE(retVal);
#endif				/* CONFIG_FEATURE_ADSL_WAN_SUPPORT */

			}
		}
	}

	operation = IFX_OP_ADD;
	flags = IFX_F_INT_ADD;
#endif				// 0

	/* Set the wan index */
	pWan.wan_index = nWAN_IDX;

	/* TBD: dont need this, chk */
	/* Reset the IPAddr, NetMask and Gateway fields */
#if 0
	wan_cfg.WAN_IP_CONN.WAN_CONN.WAN_CONN_IPADDR.s_addr = INADDR_ANY;
	wan_cfg.WAN_IP_CONN.WAN_CONN.WAN_CONN_IPMASK.s_addr = INADDR_ANY;
	wan_cfg.WAN_IP_CONN.ip_gw.s_addr = INADDR_ANY;
#endif				// 0

	pWan.f_enable = IFX_ENABLED;

	if (WanType == WAN_MODE_ATM || WanType == WAN_MODE_VDSL_ATM) {
		ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, "WAN_VCC",
			       IFX_F_GET_ANY, &outFlag, pWan.l2iface_name);

		/* Bridge connection is possible only in case of EoATM type */
		pWan.link_type = LINK_TYPE_EOATM;

		if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2)
			pWan.wan_mode.mode = WAN_MODE_ATM;
		else
			pWan.wan_mode.mode = WAN_MODE_VDSL_ATM;
	} else if (WanType == WAN_MODE_PTM || WanType == WAN_MODE_VDSL_PTM) {
		ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, "WAN_VCC",
			       IFX_F_GET_ANY, &outFlag, pWan.l2iface_name);
		pWan.link_type = LINK_TYPE_PTM;
		/* TBD : This code is needed when ADSL PTM support is available on VRX platforms, take care in future */
		if (pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2)
			pWan.wan_mode.mode = WAN_MODE_VDSL_PTM;
		else
			pWan.wan_mode.mode = WAN_MODE_PTM;
	} else {

		ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, "WAN_VCC",
			       IFX_F_GET_ANY, &outFlag, pWan.l2iface_name);
		pWan.link_type = LINK_TYPE_ETH;
		if (strstr(pWan.l2iface_name, "eth0"))
			pWan.wan_mode.mode = WAN_MODE_ETH0;
		else if (strstr(pWan.l2iface_name, "eth1"))
			pWan.wan_mode.mode = WAN_MODE_ETH1;
		/* In case of global WAN Mode as ADSL, the user is trying to
		 * configure an Ethernet WAN Connection, we assume that it'll be over
		 * MII0 interface */
		/*else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2)
			pWan.wan_mode.mode = WAN_MODE_ETH0; */
	}

#ifdef CONFIG_FEATURE_NAPT
	pWan.WAN_CONN_NAT_ENABLED = IFX_ENABLED;	// Enable NAT if Global NAT is enabled
#endif				// CONFIG_FEATURE_NAPT

	ifx_check_dw_status(&(pWan.def_wan),
			    ifx_httpdGetVar(wp, T("def_wan"), T("")));

        if ( pWan.def_wan == 1 && !strcmp(page,"wan_vcc_select.asp")){
			    pWan.def_wan = 0;
			    bridge_voip = 1;
        } else {
			    bridge_voip = 0;
        }
               

	/* set the dns override option to true */
	pWan.wandns.WAN_CONN_DNS_OVERRIDE = IFX_ENABLED;

	/* Populate the CPE and pCPE Section Names */
	sprintf(pWan.iid.cpeId.secName, "%s", TAG_WAN_IP);
	sprintf(pWan.iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);

	/* Using all the above information populate the WAN_CONN_CFG data structure
	 * and then invoke our Management API ifx_set_wan_config */
	pWan.iid.config_owner = IFX_WEB;

#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] l2iface [%s]", __FUNCTION__, __LINE__,
		pWan.l2iface_name);
#endif
	sprintf(pWan.conf_conn_name,"%s" , pconfcon);
	memcpy(&wan_cfg.WAN_IP_CONN.wan_cfg, &pWan, sizeof(pWan));
#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] l2iface [%s]", __FUNCTION__, __LINE__,
		wan_cfg.WAN_IP_CONN.wan_cfg.l2iface_name);
#endif

	if (operation == IFX_OP_MOD) {
		/* Check for dependencies with the modified WAN Connection */
		if (ifx_check_wan_configuration_dependency(&wan_cfg) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 500,
				       T
				       ("Modification of link type of wan connection from or to CLIP mode is not allowed !!"));
			return -1;
		}
	}

	/* set the status as connecting */
	wan_cfg.WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_CONNECTING;

	/* Set Connection Type as Bridge */
	wan_cfg.WAN_IP_CONN.conn_type = WAN_IP_CONN_TYPE_IP_BRIDGED;

	wan_cfg.WAN_IP_CONN.addr_type = IP_TYPE_AUTO;

	/* Invoke the CGI function to configure the WAN Connection */
	if ((ret =
	     ifx_cgi_set_wan_config(operation, &wan_cfg,
				    flags)) != IFX_SUCCESS) {
		if (ret == IFX_PCR_CHK_FAIL) {
			/* Should be checked for only ATM WAN Connections */
			COPY_TO_STATUS("%s", pcr_chk_err)
			    ifx_httpdRedirect(wp, T("err_page.html"));
			return 0;
		} else
			ifx_httpdError(wp, 500,
				       T
				       ("Failed to configure this wan connection in bridged mode !!"));
		return -1;
	}

	if (bridge_voip == 1)
        {
           CPE_ID *ptr_wanCfg_cpeId;
           if ( wan_cfg.type == WAN_TYPE_IP)
               ptr_wanCfg_cpeId = &wan_cfg.wancfg.ip.wan_cfg.iid.cpeId;
           else 
               ptr_wanCfg_cpeId = &wan_cfg.wancfg.ppp.wan_cfg.iid.cpeId;
               
           ifx_get_index_from_cpe_id(FILE_RC_CONF, ptr_wanCfg_cpeId, &nWAN_IDX);
	   if (ifx_set_voip_interface(nWAN_IDX , wan_cfg.type, IFX_F_MODIFY) != IFX_SUCCESS)
	    {
           	COPY_TO_STATUS("%s","Unable to set the default voip");
            	ifx_httpdRedirect(wp,T("err_page.html"));
            	return -1;
            }
        }	

	/* Set the STP Settings */
	pCheck = ifx_httpdGetVar(wp, T("BridgeSetting"), T(""));

	if (!gstrcmp(pCheck, "1")) {
		gsprintf(sCheck, T("STP_Bridge_ENABLE=\"%s\"\n"), pCheck);
		gsprintf(sCommand, "brctl stp %s on", IFX_BRIDGE_IF);
	} else {
		gsprintf(sCheck, T("STP_Bridge_ENABLE=\"0\"\n"));
		gsprintf(sCommand, "brctl stp %s off", IFX_BRIDGE_IF);
	}

	ifx_SetCfgData(FILE_RC_CONF, TAG_LAN_STP_BRIDGE, 1, sCheck);

	/* save STP setting to flash */
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return -1;
	}
	//Runtime Change
	system(sCommand);

IFX_Handler:
	if (!strcmp(page, "bridge_settings.asp"))
		ifx_httpdRedirect(wp, T("wan_vcc_select.asp"));
	if (!strcmp(page, "wan_vcc_select.asp"))
		ifx_httpdRedirect(wp, T("wan_vcc_select.asp"));		
	return 0;
}

int ifx_get_bridge_setting(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_FILELINE_LEN];

	sValue[0] = '\0';
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_LAN_STP_BRIDGE, T("STP_Bridge_ENABLE"),
	     sValue) == 0) {
		ifx_httpdError(wp, 500, "STP_Bridge_ENABLE not found");
		return -1;
	}
	if (sValue[0] == '1')
		ifx_httpdWrite(wp, T("checked"));
	else
		ifx_httpdWrite(wp, T(""));
	return 0;
}

int ifx_get_wan_ipv6(int eid, httpd_t wp, int argc, char_t ** argv)
{
#if 1				/* TBD : Need IPv6 team support here */
	char_t *name, sValue[MAX_FILELINE_LEN];
	int nWAN_IDX = -1;
	uint32 flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT;
	WAN_CONN_CFG wan_cfg;
	char8 buf[MAX_FILELINE_LEN], retVal[MAX_FILELINE_LEN];
	char8 retVal1[MAX_FILELINE_LEN], retVal2[MAX_FILELINE_LEN],
	    retVal3[MAX_FILELINE_LEN];
	char8 retVal4[MAX_FILELINE_LEN], retVal5[MAX_FILELINE_LEN],
	    retVal6[MAX_FILELINE_LEN];
	WAN_TYPE sWAN_TYPE;

	memset(&wan_cfg, 0x00, sizeof(wan_cfg));
	sValue[0] = '\0';

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	IFX_GET_WAN_SELECTED_INDEX(IFX_F_GET_ENA, outFlag, sValue, nWAN_IDX,
				   sWAN_TYPE)

	    name += 3;

	if (WAN_TYPE_IP == sWAN_TYPE) {
		sprintf(buf, "wanip_%d_ianaID", nWAN_IDX);
		ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags,
			       (IFX_OUT uint32 *) & outFlag, retVal);
		sprintf(buf, "wanip_%d_iapdID", nWAN_IDX);
		ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags,
			       (IFX_OUT uint32 *) & outFlag, retVal1);
		sprintf(buf, "wanip_%d_slaID", nWAN_IDX);
		ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags,
			       (IFX_OUT uint32 *) & outFlag, retVal2);
		sprintf(buf, "wanip_%d_rapid", nWAN_IDX);
		ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags,
			       (IFX_OUT uint32 *) & outFlag, retVal3);
		sprintf(buf, "wanip_%d_dhcpv6State", nWAN_IDX);
		ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags,
			       (IFX_OUT uint32 *) & outFlag, retVal4);
		sprintf(buf, "wanip_%d_ipv6", nWAN_IDX);
		ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags,
			       (IFX_OUT uint32 *) & outFlag, retVal5);
		sprintf(buf, "wanip_%d_duidt", nWAN_IDX);
		ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags,
			       (IFX_OUT uint32 *) & outFlag, retVal6);

	} else if (WAN_TYPE_PPP == sWAN_TYPE) {

		sprintf(buf, "wanppp_%d_ianaID", nWAN_IDX);
		ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			       (IFX_OUT uint32 *) & outFlag, retVal);
		sprintf(buf, "wanppp_%d_iapdID", nWAN_IDX);
		ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			       (IFX_OUT uint32 *) & outFlag, retVal1);
		sprintf(buf, "wanppp_%d_slaID", nWAN_IDX);
		ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			       (IFX_OUT uint32 *) & outFlag, retVal2);
		sprintf(buf, "wanppp_%d_rapid", nWAN_IDX);
		ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			       (IFX_OUT uint32 *) & outFlag, retVal3);
		sprintf(buf, "wanppp_%d_dhcpv6State", nWAN_IDX);
		ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			       (IFX_OUT uint32 *) & outFlag, retVal4);
		sprintf(buf, "wanppp_%d_ipv6", nWAN_IDX);
		ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			       (IFX_OUT uint32 *) & outFlag, retVal5);
		sprintf(buf, "wanppp_%d_duidt", nWAN_IDX);
		ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			       (IFX_OUT uint32 *) & outFlag, retVal6);
	}

	if (!gstrcmp(name, T("IANAID")))
		ifx_httpdWrite(wp, T("%s"), retVal);
	else if (!gstrcmp(name, T("IAPDID")))
		ifx_httpdWrite(wp, T("%s"), retVal1);
	else if (!gstrcmp(name, T("SLAID")))
		ifx_httpdWrite(wp, T("%s"), retVal2);
	else if (!gstrcmp(name, T("RAP"))) {
		if (!strcmp(retVal3, "1"))
			ifx_httpdWrite(wp, T("checked"));
		ifx_httpdWrite(wp, T(""));
	} else if (!gstrcmp(name, T("WANMODE")))
		ifx_httpdWrite(wp, T("%s"), retVal4);
	else if (!gstrcmp(name, T("DUID_T")))
		ifx_httpdWrite(wp, T("%s"), retVal6);
	else if (!gstrcmp(name, T("IPV6STATUS"))) {
		if (!strcmp(retVal5, "1"))
			ifx_httpdWrite(wp, T(""));
		else
			ifx_httpdWrite(wp, T("checked"));
	}
#endif

	return 0;
}

//end bridge_setting.asp

int ifx_get_wan_sixrd(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
	int nWAN_IDX = 1, type=1;
	int32 ret = IFX_SUCCESS;
	uint32 flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT;
	char8 buf[MAX_FILELINE_LEN];
	char8 retVal6[MAX_FILELINE_LEN];
	char8 retVal7[MAX_FILELINE_LEN];
	char8 retVal12[MAX_FILELINE_LEN];

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	name += 3;
        retVal12[0] = '\0';
	if ((!gstrcmp(name, T("SIXRDWANIDX")))
	    || (!gstrcmp(name, T("SIXRDSTATUS")))) {
		sprintf(buf, "wan_sixrdwanidx");
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, TAG_IPV6, buf, flags,
				    (IFX_OUT uint32 *) & outFlag,
				    retVal12)) != IFX_SUCCESS) {
			if (!gstrcmp(name, T("SIXRDWANIDX")))
				ifx_httpdWrite(wp, T("0"));
			else if (!gstrcmp(name, T("SIXRDSTATUS")))
				ifx_httpdWrite(wp, T(""));
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__);
#endif
			return IFX_FAILURE;
		}

               if (!strncmp(retVal12, "WANPPP", 6)) {
                       nWAN_IDX=atoi(retVal12 + 6);
                       type=1;
               }
               else if (!strncmp(retVal12, "WANIP", 5)) {
                       nWAN_IDX=atoi(retVal12 + 5);
                       type=2;
               }
               else
                       type=3;


	}

		if (!gstrcmp(name, T("SIXRDWANIDX"))) {
		
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d: %s] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__, retVal12);
#endif
			ifx_httpdWrite(wp, T("%s"), retVal12);
		}
		else if (!gstrcmp(name, T("SIXRDSTATUS"))) {
#if 0
			if (nWAN_IDX != 0) {
				sprintf(buf, "wan_%d_tunnel", nWAN_IDX);
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_WAN_MAIN, buf, flags,
				     (IFX_OUT uint32 *) & outFlag,
				     retVal6) != IFX_SUCCESS) {
					ifx_httpdWrite(wp, T(""));
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] Form Name=Value buffer Fail",
					     __FUNCTION__, __LINE__);
#endif
					return IFX_FAILURE;
				}
				if ((!strcmp(retVal6, "1"))
				    || (!strcmp(retVal6, "3")))
					ifx_httpdWrite(wp, T("checked"));
				else
					ifx_httpdWrite(wp, T(""));

				return 0;
			} 
#endif

                       if (type != 3) {
                               if (type ==1) {
                                       sprintf(buf, "wanppp_%d_tunnel", nWAN_IDX);
                                       if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, flags, (IFX_OUT uint32 *)&outFlag, 
						retVal6) != IFX_SUCCESS) {
                                                ifx_httpdWrite(wp, T(""));
#ifdef IFX_LOG_DEBUG
                                               	IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
#endif
                                               	return IFX_FAILURE;
                                       }
                              }
                               else {
                                       sprintf(buf, "wanip_%d_tunnel", nWAN_IDX);
                                       if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags, (IFX_OUT uint32 *)&outFlag, 
						retVal6) != IFX_SUCCESS) {
                                                ifx_httpdWrite(wp, T(""));
#ifdef IFX_LOG_DEBUG
                                                IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
#endif
                                                return IFX_FAILURE;
                                        }
                               }

	                        if((!strcmp(retVal6, "1")) || (!strcmp(retVal6, "3")))
                                        ifx_httpdWrite(wp, T("checked"));
                                else
                                        ifx_httpdWrite(wp, T(""));

                                return 0;
                        }
			else {
				ifx_httpdWrite(wp, T(""));
				return 0;
			}
		}
		else {}
				
	
	if (!gstrcmp(name, T("SIXRDPREFIX"))) {
		sprintf(buf, "wan_sixrdprefix");
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_IPV6, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, retVal7) != IFX_SUCCESS) {
			ifx_httpdWrite(wp, T("0"));
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__);
#endif
			return IFX_FAILURE;
		}
		ifx_httpdWrite(wp, T("%s"), retVal7);
	} else if (!gstrcmp(name, T("SIXRDPREFIXLEN"))) {
		sprintf(buf, "wan_sixrdprefixlen");
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_IPV6, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, retVal7) != IFX_SUCCESS) {
			ifx_httpdWrite(wp, T("0"));
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__);
#endif
			return IFX_FAILURE;
		}
		ifx_httpdWrite(wp, T("%s"), retVal7);
	} else if (!gstrcmp(name, T("SIXRDBRIP"))) {
		sprintf(buf, "wan_sixrdbrip");
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_IPV6, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, retVal7) != IFX_SUCCESS) {
			ifx_httpdWrite(wp, T("0.0.0.0"));
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__);
#endif
			return IFX_FAILURE;
		}
		ifx_httpdWrite(wp, T("%s"), retVal7);
	} else if (!gstrcmp(name, T("SIXRDMASKLEN"))) {
		sprintf(buf, "wan_sixrdmasklen");
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_IPV6, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, retVal7) != IFX_SUCCESS) {
			ifx_httpdWrite(wp, T("0"));
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__);
#endif
			return IFX_FAILURE;
		}
		ifx_httpdWrite(wp, T("%s"), retVal7);
	} else if (!gstrcmp(name, T("WANSIXRDMODE"))) {
		sprintf(buf, "wan_sixrd_mode");
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_IPV6, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, retVal7) != IFX_SUCCESS) {
			ifx_httpdWrite(wp, T("0"));
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__);
#endif
			return IFX_FAILURE;
		}
		ifx_httpdWrite(wp, T("%s"), retVal7);
	} else if (!gstrcmp(name, T("SIXRDWANIDX"))) {
#if 0
		if (nWAN_IDX != 0) {
			sprintf(buf, "wan_%d_tunnel", nWAN_IDX);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_WAN_MAIN, buf, flags,
			     (IFX_OUT uint32 *) & outFlag,
			     retVal6) != IFX_SUCCESS) {
				ifx_httpdWrite(wp, T("0"));
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
					__FUNCTION__, __LINE__);
#endif
				return IFX_FAILURE;
			}
		}
#endif
                if (type != 3) {
                       if (type ==1) {
                               sprintf(buf, "wanppp_%d_tunnel", nWAN_IDX);
                               if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, flags, (IFX_OUT uint32 *)&outFlag, 
					retVal6) != IFX_SUCCESS) {
                                        ifx_httpdWrite(wp, T("0"));
#ifdef IFX_LOG_DEBUG
                                        IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
#endif
                                        return IFX_FAILURE;
                               }
                       }
                       else {
                               sprintf(buf, "wanip_%d_tunnel", nWAN_IDX);
                               if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags, (IFX_OUT uint32 *)&outFlag, 
					retVal6) != IFX_SUCCESS) {
                                        ifx_httpdWrite(wp, T("0"));
#ifdef IFX_LOG_DEBUG
                                        IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
#endif
                                        return IFX_FAILURE;
                                }
                        }
               }
	       // ifx_httpdWrite(wp, T("%s"), retVal6);
	} else if (!gstrcmp(name, T("MTU"))) {
		sprintf(buf, "wan_sixrd_mtu");
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_IPV6, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, retVal7) != IFX_SUCCESS) {
			ifx_httpdWrite(wp, T(""));
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__);
#endif
			return IFX_FAILURE;
		}
		if (!strcmp(retVal7, "0"))
			ifx_httpdWrite(wp, T(""));
		else
			ifx_httpdWrite(wp, T("%s"), retVal7);
	}
	return 0;
}

int ifx_get_wan_dslite(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
	int nWAN_IDX = 1;
	int32 ret = IFX_SUCCESS;
	uint32 flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT;
	char8 buf[MAX_FILELINE_LEN];
	char8 retVal6[MAX_FILELINE_LEN];
	char8 retVal7[MAX_FILELINE_LEN];
	char8 retVal8[MAX_FILELINE_LEN];
	char8 retVal9[MAX_FILELINE_LEN];
	char8 retVal12[MAX_FILELINE_LEN];
	int	wantype=0;
	char *wt[2] = {"ppp", "ip"};
	char *wantag = NULL;
	char wan_basename[16]={0};
	buf[0] = '\0';
	retVal7[0] = '\0';
	retVal6[0] = '\0';
	retVal12[0] = '\0';
	retVal8[0] = '\0';
	retVal9[0] = '\0';

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	name += 3;

	if ((!gstrcmp(name, T("DSLITEWANIDX")))
	    || (!gstrcmp(name, T("DSLITESTATUS")))
	    || (!gstrcmp(name, T("ALLSTATUS")))) {
		snprintf(buf, sizeof(buf), "wan_dslitewanidx");

		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, TAG_IPV6, buf, flags,
				    (IFX_OUT uint32 *) & outFlag,
				    retVal12)) != IFX_SUCCESS) {
			if (!gstrcmp(name, T("DSLITEWANIDX")))
				ifx_httpdWrite(wp, T("0"));
			else if (!gstrcmp(name, T("DSLITESTATUS")))
				ifx_httpdWrite(wp, T(""));
			else if (!gstrcmp(name, T("ALLSTATUS"))) {
				ifx_httpdWrite(wp, T(""));
			}
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__);
#endif
			return IFX_FAILURE;
		}
		if(strstr(retVal12, "IP")) {
			wantype=1;
			nWAN_IDX=atoi(retVal12+5);
		} else if(strstr(retVal12, "PPP")) {
			wantype=0;
			nWAN_IDX=atoi(retVal12+6);
		} else {
			ifx_httpdWrite(wp, T(""));
		}
		wantag = (wantype?TAG_WAN_IP:TAG_WAN_PPP);
		strncpy(wan_basename, retVal12, sizeof(wan_basename));

		if (!gstrcmp(name, T("DSLITESTATUS"))) {
				snprintf(buf, sizeof(buf), "wan%s_%d_tunnel", wt[wantype], nWAN_IDX);
				if (ifx_GetObjData(FILE_RC_CONF, wantag, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal6) != IFX_SUCCESS) {
					ifx_httpdWrite(wp, T(""));
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] Form Name=Value buffer Fail",
					     __FUNCTION__, __LINE__);
#endif
					return IFX_FAILURE;
				}
				if ((!strcmp(retVal6, "2"))
				    || (!strcmp(retVal6, "3")))
					ifx_httpdWrite(wp, T("checked"));
				else
					ifx_httpdWrite(wp, T(""));

				return 0;
		} else if (!gstrcmp(name, T("DSLITEWANIDX"))) {
				snprintf(buf, sizeof(buf), "wan%s_%d_tunnel", wt[wantype], nWAN_IDX);
				if (ifx_GetObjData(FILE_RC_CONF, wantag, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal6) != IFX_SUCCESS) {
					ifx_httpdWrite(wp, T("0"));
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] Form Name=Value buffer Fail",
					     __FUNCTION__, __LINE__);
#endif
					return IFX_FAILURE;
				}
			ifx_httpdWrite(wp, T("%s"), retVal12);
			return 0;
		} else if (!gstrcmp(name, T("ALLSTATUS"))) {
				retVal6[0] = '\0';
				retVal12[0] = '\0';
				get_wan_dslite_allstatus(name, retVal6, retVal8,
							 retVal12, retVal9,
							 MAX_FILELINE_LEN - 1,
							 nWAN_IDX, wt[wantype], 
							 wantag, wan_basename);
				if (!strcmp(retVal6, "connected")) {
					ifx_httpdWrite(wp, T("%s %s %s %s"),
						       "connected", retVal8,
						       retVal12, retVal9);
				} else {
					ifx_httpdWrite(wp, T("%s %s %s %s"),
						       "Not_connected",
						       "Undefined", "Undefined",
						       "Undefined");
				}
			return 0;
		}
		return 0;
	}
	get_wan_dslite_parameter(name, retVal7, MAX_FILELINE_LEN - 1);
	ifx_httpdWrite(wp, T("%s"), retVal7);
	return 0;
}
