#ifdef CONFIG_FEATURE_IFX_WIRELESS
#if defined (CONFIG_FEATURE_LTQ_WIRELESS_VB) || defined (CONFIG_FEATURE_LTQ_WIRELESS_STA_SUPPORT)
/* ========================================================================== */
/*                                 Includes                                   */
/* ========================================================================== */
#include <ifx_emf.h>
#include "ifx_httpd_method.h"
#include <sys/types.h>
#include <sys/time.h>
#include <ifx_common.h>
#include "ifx_cgi.h"
#include <ifx_api_ipt_common.h>
#include "ltq_cgi_wlan.h"

/* ========================================================================== */
/*                             Macro definitions                              */
/* ========================================================================== */

char8 vb_cts_prot_mode[][32] = {
	{"None"}
	,
	{"RTS/CTS"}
	,
	{"CTS2SELF"}
};

char8 vb_standard[][32] = {
	{"802.11 bg"}
	,
	{"802.11 a"}
	,
	{"802.11 b"}
	,
	{"802.11 g"}
	,
	{"802.11 n"}
	,
	{"802.11 bgn"}
	,
	{"802.11 gn"}
	,
	{"802.11 an"}
};

char8 vb_freqBand[][32] = {
	{"2.4GHz"}
	,
	{"5GHz"}
	,
	{"Dual Band"}
	,
	{"Concurrent Dual Band"}
};

char8 vb_preamble[][32] = {
	{"No Preamble"}
	,
	{"Short Preamble"}
	,
	{"Long Preamble"}
	,
	{"Auto Selection"}
};

char8 vb_wps_status[][32] = {
	{"No Preamble"}
	,
	{"Short Preamble"}
	,
	{"Long Preamble"}
	,
	{"Auto Selection"}
};

char8 vb_beacon_type[][32] = {
	{"Basic"}
	,
	{"WPA"}
	,
	{"WPA2"}
	,
	{"WPA/WPA2 mixed"}
};

char8 vb_auth_type[][32] = {
	{"Open Authentication"}
	,
	{"Shared Authentication"}
	,
	{"Enterprise(RADIUS)"}
	,
	{"Personal(PSK)"}
	,
	{"Enterprise/Personal"}
};

char8 vb_enable[][32] = {
	{"OFF"}
	,
	{"ON"}
};

char8 vb_AckBoost[][32] = {
	{"Full Boost on all packets"}
	,
	{"Full Boost on data packets"}
	,
	{"Regular Boost on all packets"}
	,
	{"Regular Boost on data packets"}
	,
	{"No Boost"}
};

extern int reboot_status;
extern char8 wlan_channel_width[][32];
extern char8 wlan_guard_intvl[][32];
extern char8 wlan_encr_type[][32];

static int flagVbConfigLoaded = 0;
static int flagVbDisconnectFromAp = 0;

LTQ_MAPI_WLAN_VB_GEN_BD_Cfg g_vbGenConfig[1];
LTQ_MAPI_VB_WLAN_Cfg g_vbWlanConfig[1];
LTQ_MAPI_VB_ETH_PHY_Cfg g_vbEthPhyConfig[2];
int g_vbEthPhyCount;
LTQ_MAPI_VB_WLAN_Profile gVbWlProfile =
    { "", "", 0, 0, 0, 0, 0, 0, "", "", "", "", "", "", 0, 0, "" };
static int gCurrentWpsStatusLoop = 0;
/* ========================================================================== */
/*                           Function prototypes                              */
/* ========================================================================== */
extern int ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);
extern int ltq_get_wlan_freqBand(httpd_t wp, IFX_MAPI_WLAN_FreqBand freqBand);
extern void ltq_get_wlan_wmmStaConfig(httpd_t wp,
				      IFX_MAPI_WLAN_STA_WMM_Cfg * wlStaWmm,
				      IFX_MAPI_WLAN_WMM_AC ac);

void ltq_vb_load_global_config(int eid, httpd_t wp, int argc, char_t ** argv);
int ltq_get_vb_gbc_config(int eid, httpd_t wp, int argc, char_t ** argv);	// wlan_vb_config.asp
int ltq_get_vb_lbc_config(int eid, httpd_t wp, int argc, char_t ** argv);	// wlan_vb_lan_bd_cfg.asp
int ltq_get_vb_wlan_config(int eid, httpd_t wp, int argc, char_t ** argv);	// wlan_vb_gen_wlan_config.asp
int ltq_get_vb_wmm_configuration(int eid, httpd_t wp, int argc, char_t ** argv);	// wlan_vb_wmm_config.asp
void ltq_get_vb_wps_status(int eid, httpd_t wp, int argc, char_t ** argv);	// wlan_vb_wps_status.asp
int ltq_get_vb_Info(int eid, httpd_t wp, int argc, char_t ** argv);	// index.asp
void ltq_get_vb_scan_results(int eid, httpd_t wp, int argc, char_t ** argv);
void ltq_vb_get_link_status(int eid, httpd_t wp, int argc, char_t ** argv);
void ltq_set_wmm_config(httpd_t wp, char_t * path, char_t * query);
void ltq_set_gbd_vb_config(httpd_t wp, char_t * path, char_t * query);
void ltq_set_lbd_vb_config(httpd_t wp, char_t * path, char_t * query);
void ltq_set_wlan_config(httpd_t wp, char_t * path, char_t * query);
void ltq_set_wps_config(httpd_t wp, char_t * path, char_t * query);
void LTQ_WLAN_VB_PrepareConnect(httpd_t wp, char_t * path, char_t * query);
void ltq_set_vb_connect(httpd_t wp, char_t * path, char_t * query);
void ltq_set_vb_ssid_wildcard(httpd_t wp, char_t * path, char_t * query);

/**

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void ltq_vb_load_global_config(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char8 sValue[MAX_FILELINE_LEN];
	char8 *ipaddr1, *ipaddr2, *ipaddr3, *ipaddr4;
	char8 *delim = ". \n\t";

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_vb_load_global_config",
		"flagVbConfigLoaded: %d", flagVbConfigLoaded);

	/* always one */
	gNumEntries = 1;

	/* determine the supported capabilites */
	if (ifx_mapi_get_wlan_capability(&g_wlCaps[0], IFX_F_DEFAULT) !=
		IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_vb_load_global_config", "");
		ifx_httpdError(wp, 400, T("Failed to get the device capabilities\n\r"));
		return;
	}

	if (!flagVbConfigLoaded) {
		/* initialize all structures */
		memset(&g_vbGenConfig[0], 0, sizeof(LTQ_MAPI_WLAN_VB_GEN_BD_Cfg));

		/*
		   after we have initialized global video bridge with all required
		   values, we now call function to fill in the rest with values from
		   rc.conf */
		if (ltq_mapi_get_vb_gbd_config(&g_vbGenConfig[0], IFX_F_DEFAULT)
		    != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_vb_load_global_config",
				       "");
			ifx_httpdError(wp, 400,
				       T
				       ("Could not get general VB configuration\n\r"));
			return;
		}

		/* initialize all structures */
		memset(&g_vbWlanConfig[0], 0, sizeof(LTQ_MAPI_VB_WLAN_Cfg));
		/* get the configuration from rc.conf */
		if (ltq_mapi_get_vb_wlan_config
		    (&g_vbWlanConfig[0], IFX_F_DEFAULT) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_vb_load_global_config",
				       "");
			ifx_httpdError(wp, 400,
				       T
				       ("Could not get VB WLAN configuration\n\r"));
			return;
		}
		/* set flag that configuration is already stored in global arrays */
		flagVbConfigLoaded = 1;
	}
	/*
	 *  get the configuration from rc.conf
	 *  this should always be done, because it might have
	 *  been updated after WPS finished successfully
	 */
	if (ltq_mapi_get_vb_wlan_profile(&gVbWlProfile, IFX_F_DEFAULT) !=
	    IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_vb_load_global_config", "");
		ifx_httpdError(wp, 400, T("Could not get VB WLAN profile\n\r"));
		return;
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_vb_load_global_config", "mode: %d",
		g_vbGenConfig[0].mode);
	ifx_httpdWrite(wp,
		T("<input type='hidden' name='wlVbCurrentMode' value='%d'>\n"),
		g_vbGenConfig[0].mode);

	sprintf(sValue, "%s", inet_ntoa(g_vbGenConfig[0].mgmtIP));
	ipaddr1 = strtok(sValue, delim);
	ipaddr2 = strtok(NULL, delim);
	ipaddr3 = strtok(NULL, delim);
	ipaddr4 = strtok(NULL, delim);
	ifx_httpdWrite(wp,
		       T
		       ("<input type='hidden' name='wlVbCurrentIP1' value='%s'>\n"),
		       ipaddr1);
	ifx_httpdWrite(wp,
		       T
		       ("<input type='hidden' name='wlVbCurrentIP2' value='%s'>\n"),
		       ipaddr2);
	ifx_httpdWrite(wp,
		       T
		       ("<input type='hidden' name='wlVbCurrentIP3' value='%s'>\n"),
		       ipaddr3);
	ifx_httpdWrite(wp,
		       T
		       ("<input type='hidden' name='wlVbCurrentIP4' value='%s'>\n"),
		       ipaddr4);

	ifx_httpdWrite(wp,
		       T
		       ("<input type='hidden' name='wlProfBeaconType' value='%d'>\n"),
		       gVbWlProfile.beaconType);
	ifx_httpdWrite(wp,
		       T
		       ("<input type='hidden' name='wlProfAuthType' value='%d'>\n"),
		       gVbWlProfile.authType);
	ifx_httpdWrite(wp,
		       T
		       ("<input type='hidden' name='wlProfEncrType' value='%d'>\n"),
		       gVbWlProfile.encrType);
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"wpsEnable_0\" value=\"%d\">\n"),
		       g_vbWlanConfig[0].wpsEna);

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_vb_load_global_config", "");
	return;
}

/**

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int ltq_get_vb_gbc_config(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 ret = IFX_SUCCESS;
	LTQ_MAPI_WLAN_VB_GEN_BD_Cfg vbGenConfig;
	char_t *name = NULL;
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_gbc_config", "");

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return IFX_FAILURE;
	}

	/* restore from global variable to save time */
	memcpy(&vbGenConfig, &g_vbGenConfig[0],
	       sizeof(LTQ_MAPI_WLAN_VB_GEN_BD_Cfg));

	if (!gstrcmp(name, T("wlan_vb_mode"))) {
		ifx_httpdWrite(wp, T("<option value=\"0\" %s>STA</option>"),
			vbGenConfig.mode == LTQ_MAPI_WLAN_VB_STA ? "selected" : "");
		ifx_httpdWrite(wp, T("<option value=\"1\" %s>AP</option>"),
			vbGenConfig.mode == LTQ_MAPI_WLAN_VB_AP ? "selected" : "");
		ifx_httpdWrite(wp, T("<option value=\"2\" %s>AUTO</option>"),
			vbGenConfig.mode==LTQ_MAPI_WLAN_VB_AUTO?"selected":"");
	} else if (!gstrcmp(name, T("wlan_vb_device_name"))) {
		ifx_httpdWrite(wp, T("%s"), vbGenConfig.name);
	} else if (!gstrcmp(name, T("wlan_vb_ip_addr"))) {
		char8 sValue[MAX_FILELINE_LEN], sCommand[MAX_FILELINE_LEN];
		char8 *ipaddr1, *ipaddr2, *ipaddr3, *ipaddr4;
		char8 *delim = ". \n\t";
		uint32 outFlag = IFX_F_DEFAULT;

		sprintf(sValue, "%s", inet_ntoa(vbGenConfig.mgmtIP));
		/* get the IP address from SYSTEM_STATUS file */
		if (vbGenConfig.dhcpClntEna && !gstrcmp(sValue, T("0.0.0.0"))) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_gbc_config",
				       "get IP address");
			/* get the ip address for this lan device entry */
			sprintf(sCommand, "Lan0_IF_Info");
			if (ifx_GetObjData(FILE_SYSTEM_STATUS, sCommand, "IP",
					   IFX_F_DEFAULT, &outFlag,
					   sValue) != IFX_SUCCESS) {
				sprintf(sValue, "%s", ("0.0.0.0"));
			}
		}

		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_gbc_config", "sValue: %s",
			       sValue);
		ipaddr1 = strtok(sValue, delim);
		ipaddr2 = strtok(NULL, delim);
		ipaddr3 = strtok(NULL, delim);
		ipaddr4 = strtok(NULL, delim);

		ifx_httpdWrite(wp,
			       T
			       ("<input maxLength=\"3\" name=\"vbIP1\" size=\"3\" value=%s>."),
			       ipaddr1);
		ifx_httpdWrite(wp,
			       T
			       ("<input maxLength=\"3\" name=\"vbIP2\" size=\"3\" value=%s>."),
			       ipaddr2);
		ifx_httpdWrite(wp,
			       T
			       ("<input maxLength=\"3\" name=\"vbIP3\" size=\"3\" value=%s>."),
			       ipaddr3);
		ifx_httpdWrite(wp,
			       T
			       ("<input maxLength=\"3\" name=\"vbIP4\" size=\"3\" value=%s>"),
			       ipaddr4);
	} else if (!gstrcmp(name, T("wlan_vb_net_mask"))) {
		char8 sValue[MAX_FILELINE_LEN], sCommand[MAX_FILELINE_LEN];
		char8 *ipaddr1, *ipaddr2, *ipaddr3, *ipaddr4;
		char8 *delim = ". \n\t";
		uint32 outFlag = IFX_F_DEFAULT;

		sprintf(sValue, "%s", inet_ntoa(vbGenConfig.mgmtNetMask));
		/* get the IP address from SYSTEM_STATUS file */
		if (vbGenConfig.dhcpClntEna && !gstrcmp(sValue, T("0.0.0.0"))) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_gbc_config",
				       "get IP address");
			/* get the ip address for this lan device entry */
			sprintf(sCommand, "Lan0_IF_Info");
			if (ifx_GetObjData(FILE_SYSTEM_STATUS, sCommand, "MASK",
					   IFX_F_DEFAULT, &outFlag,
					   sValue) != IFX_SUCCESS) {
				sprintf(sValue, "%s", ("0.0.0.0"));
			}
		}

		ipaddr1 = strtok(sValue, delim);
		ipaddr2 = strtok(NULL, delim);
		ipaddr3 = strtok(NULL, delim);
		ipaddr4 = strtok(NULL, delim);

		ifx_httpdWrite(wp,
			       T
			       ("<input maxLength=\"3\" name=\"vbNetMask1\" size=\"3\" value=%s>."),
			       ipaddr1);
		ifx_httpdWrite(wp,
			       T
			       ("<input maxLength=\"3\" name=\"vbNetMask2\" size=\"3\" value=%s>."),
			       ipaddr2);
		ifx_httpdWrite(wp,
			       T
			       ("<input maxLength=\"3\" name=\"vbNetMask3\" size=\"3\" value=%s>."),
			       ipaddr3);
		ifx_httpdWrite(wp,
			       T
			       ("<input maxLength=\"3\" name=\"vbNetMask4\" size=\"3\" value=%s>"),
			       ipaddr4);
	} else if (!gstrcmp(name, T("wlan_vb_dhcp_ena"))) {
		if (vbGenConfig.dhcpClntEna == 1)
			ifx_httpdWrite(wp, T("%s"), "checked");
		else
			ifx_httpdWrite(wp, T("%s"), "");
	} else if (!gstrcmp(name, T("wlan_vb_allow_wlan_config"))) {
		if (vbGenConfig.wlanMgmt == 1)
			ifx_httpdWrite(wp, T("%s"), "checked");
		else
			ifx_httpdWrite(wp, T("%s"), "");
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_gbc_config", "");
	return ret;
}

/**

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int ltq_get_vb_lbc_config(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 ret = IFX_SUCCESS;
	LTQ_MAPI_WLAN_VB_GEN_BD_Cfg vbGenConfig;
	LTQ_MAPI_WLAN_VB_LAN_BD_Cfg vbLanConfig;
	char_t *name = NULL;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_lbc_config", "");

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return IFX_FAILURE;
	}

	/* get the global configuration from rc.conf */
	ret = ltq_mapi_get_vb_gbd_config(&vbGenConfig, IFX_F_DEFAULT);
	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_lbc_config", "");
		ifx_httpdError(wp, 400,
			       T("Could not get general VB configuration\n\r"));
		goto LTQ_Handler;
	}
	/* get the LAN configuration for VB from rc.conf */
	ret = ltq_mapi_get_wlan_vb_lan_config(&vbLanConfig, IFX_F_DEFAULT);
	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_lbc_config", "");
		ifx_httpdError(wp, 400,
			       T("Could not get LAN VB configuration\n\r"));
		goto LTQ_Handler;
	}

	if (!gstrcmp(name, T("wlan_vb_lan_netmode_onchange"))) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_lbc_config", "");
		/*
		 * different options for VB AP and VB STA mode
		 * for VB AP mode: Bridged and Four-Address mode
		 * for VB STA mode: L2-NAT, MAC cloning, Four-Address mode
		 */
		if (vbGenConfig.currentMode == LTQ_MAPI_WLAN_VB_STA) {
			ifx_httpdWrite(wp, T("<option value=\"0\" selected>"
				"Bridged</option>"));
			ifx_httpdWrite(wp, T("<option value=\"1\">Four-Address</option>"));
		} else if (vbGenConfig.currentMode == LTQ_MAPI_WLAN_VB_AP) {
			ifx_httpdWrite(wp, T("<option value=\"0\" selected>"
				"L2-NAT</option>"));
			ifx_httpdWrite(wp, T("<option value=\"1\">"
				"MAC cloning</option>"));
    		ifx_httpdWrite(wp, T("<option value=\"2\">"
				"Four-Address</option>"));
		} else {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_lbc_config", "");
			ifx_httpdError(wp, 400, T("VB mode is invalid\n\r"));
			goto LTQ_Handler;
		}
	} else if (!gstrcmp(name, T("wlan_vb_lan_netmode"))) {
		/*
			* different options for VB AP and VB STA mode
			* for VB AP mode: Bridged and Four-Address mode
			* for VB STA mode: L2-NAT, MAC cloning, Four-Address mode
			*/
		if (vbGenConfig.currentMode == LTQ_MAPI_WLAN_VB_STA) {
			ifx_httpdWrite(wp, T("<option value=\"0\" %s>L2-NAT</option>"),
				vbLanConfig.endPtNetMode==LTQ_MAPI_WLAN_VB_LAN_STA_MODE_L2NAT?"selected":"");
			ifx_httpdWrite(wp, T("<option value=\"1\" %s>MAC cloning</option>"),
				vbLanConfig.endPtNetMode==LTQ_MAPI_WLAN_VB_LAN_STA_MODE_CLONING?"selected":"");
			ifx_httpdWrite(wp, T("<option value=\"2\" %s>Four-Address</option>"),
				vbLanConfig.endPtNetMode==LTQ_MAPI_WLAN_VB_LAN_STA_MODE_4_ADDR?"selected":"");
		}
		else if (vbGenConfig.currentMode == LTQ_MAPI_WLAN_VB_AP) {
			ifx_httpdWrite(wp, T("<option value=\"0\" %s>Bridged</option>"),
				vbLanConfig.masterNetMode==LTQ_MAPI_WLAN_VB_LAN_AP_MODE_BRIDGE?"selected":"");
			ifx_httpdWrite(wp, T("<option value=\"1\" %s>Four-Address</option>"),
				vbLanConfig.masterNetMode==LTQ_MAPI_WLAN_VB_LAN_AP_MODE_4_ADDR?"selected":"");
		} else {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_lbc_config", "");
			ifx_httpdError(wp, 400, T("VB mode is invalid\n\r"));
			goto LTQ_Handler;
		}
	} else if (!gstrcmp(name, T("wlan_vb_lan_lbt_ena"))) {
		if (vbLanConfig.endPtLbEna == 1)
			ifx_httpdWrite(wp, T("%s"), "checked");
		else
			ifx_httpdWrite(wp, T("%s"), "");
	} else if (!gstrcmp(name, T("wlan_vb_lan_clonMacAddr"))) {
		char_t 	sValue[4], sDisabled[9];
		int32	i = 0;

		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_lbc_config",
			"cloned MAC address: %s\n", vbLanConfig.endPtClonedMacAddr);

		/* check if MAC cloning address field must be disabled initially */
		memset(sDisabled, 0x00, sizeof(sValue));
		if ((vbGenConfig.currentMode == LTQ_MAPI_WLAN_VB_AP) ||
			(vbLanConfig.endPtNetMode != LTQ_MAPI_WLAN_VB_LAN_STA_MODE_CLONING))
			sprintf(sDisabled,"%s", "disabled");

		memset(sValue, 0x00, sizeof(sValue));
		sValue[2] = 0;
		for (i=0; i < 6; i++) {
			sValue[0] = vbLanConfig.endPtClonedMacAddr[3*i];
			sValue[1] = vbLanConfig.endPtClonedMacAddr[3*i+1];
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_lbc_config", "i: %d:\n"
				"svalue[0]: %c, sValue[1]: %c", i, sValue[0], sValue[1]);
			if (i < 5) {
				ifx_httpdWrite(wp, T("<input maxLength='3' "
					"name='wlan_vb_lan_cloneMAC_%d' size='2' value=%s %s>:"),
					i, sValue, sDisabled);
			} else {
				ifx_httpdWrite(wp, T("<input maxLength='3' "
					"name='wlan_vb_lan_cloneMAC_%d' size='2' value=%s %s>"),
					i, sValue, sDisabled);
			}
		}
	} else if (!gstrcmp(name, T("wlan_vb_sta_ena"))) {
		if (vbGenConfig.currentMode == LTQ_MAPI_WLAN_VB_STA)
			ifx_httpdWrite(wp, T("1"));
		else
			ifx_httpdWrite(wp, T("0"));
	}

      LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_lbc_config", "");
	return ret;
}

/**

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int ltq_get_vb_wlan_config(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 ret = IFX_SUCCESS, i = 0;
	LTQ_MAPI_VB_WLAN_Cfg vbWlanConfig;
	char_t *name = NULL;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_wlan_config", "");

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return IFX_FAILURE;
	}

	/* get the configuration from rc.conf */
	ret = ltq_mapi_get_vb_wlan_config(&vbWlanConfig, IFX_F_DEFAULT);

	if (ret != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_wlan_config", "");
		ifx_httpdError(wp, 400,
			       T("Could not get VB WLAN configuration\n\r"));
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	}

	if (!gstrcmp(name, T("wlan_vb_freq"))) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_wlan_config",
			       "freqBand: 0x%x", vbWlanConfig.freqBand);
		ifx_httpdWrite(wp, T("<script>"));
		/*
		   call static support function to determine display options for
		   frequency bands */
		if ((ret =
		     ltq_get_wlan_freqBand(wp,
					   vbWlanConfig.freqBand)) !=
		    IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_wlan_config", "");
			ret = IFX_FAILURE;
			goto LTQ_Handler;
		}
		ifx_httpdWrite(wp, T("</script>"));
	} else if (!gstrcmp(name, T("wlan_vb_tx_power"))) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_wlan_config",
			       "TX Power Level: 0x%x", vbWlanConfig.powerLvl);
		ifx_httpdWrite(wp, T("<option value='0'"));
		if (g_wlPhy[g_idx].powerLvl == 0) {
			ifx_httpdWrite(wp, T("%s"), "selected");
		}
		ifx_httpdWrite(wp, T(">AUTO</option>"));
		i = 0;
		do {
			ifx_httpdWrite(wp, T("<option value='%d'"),
				       g_wlCaps[g_idx].powerLevelsSupported[i]);
			if (vbWlanConfig.powerLvl ==
			    g_wlCaps[g_idx].powerLevelsSupported[i]) {
				ifx_httpdWrite(wp, T("%s"), "selected");
			}
			ifx_httpdWrite(wp, T(">%d %</option>"),
				       g_wlCaps[g_idx].powerLevelsSupported[i]);
			i++;
		} while ((i < IFX_MAPI_WLAN_MAX_STD)
			 && (g_wlCaps[g_idx].powerLevelsSupported[i] != 0xFF));
	} else if (!gstrcmp(name, T("wlan_vb_cts_prot"))) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_wlan_config",
			       "CTS protection type: 0x%x",
			       vbWlanConfig.ctsProtctMode);
		for (i = 0; i <= 2; i++) {
			ifx_httpdWrite(wp, T("<option value='%d'"), i);
			if (i == vbWlanConfig.ctsProtctMode)
				ifx_httpdWrite(wp, T("%s"), "selected");
			ifx_httpdWrite(wp, T(">%s</option>"),
				       vb_cts_prot_mode[i]);
		}
	} else if (!gstrcmp(name, T("wlan_vb_rts_thrshld"))) {
		ifx_httpdWrite(wp,
			       T
			       ("<input name=\"wlan_vb_rts_thrshld\" value=%d> in bytes [0..2347]"),
			       vbWlanConfig.rts);
	} else if (!gstrcmp(name, T("wlan_vb_chan_width"))) {
		/*
		   depending on capability of device, different options are displayed */
		if (g_wlCaps[g_idx].wideChanSupport) {
			for (i = 0; i <= 2; i++) {
				ifx_httpdWrite(wp, T("<option value='%d' "), i);
				if (vbWlanConfig.nChanWidth == i) {
					ifx_httpdWrite(wp, T("%s"), "selected");
				}
				ifx_httpdWrite(wp, T(">%s"),
					       wlan_channel_width[i]);
			}
		} else {
			ifx_httpdWrite(wp, T("<option value=\"0\" selected>%s"),
				       wlan_channel_width[0]);
		}
	} else if (!gstrcmp(name, T("wlan_vb_guard_intval"))) {
		for (i = 0; i <= 2; i++) {
			ifx_httpdWrite(wp, T("<option value='%d' "), i);
			if (vbWlanConfig.nGuardIntvl == i) {
				ifx_httpdWrite(wp, T("%s"), "selected");
			}
			ifx_httpdWrite(wp, T(">%s"), wlan_guard_intvl[i]);
		}
	} else if (!gstrcmp(name, T("wlan_vb_preamble"))) {
		for (i = 1; i < IFX_MAX_WLAN_PREAMBLE_MODES; i++) {
			ifx_httpdWrite(wp, T("<option value='%d' "), i);
			if (vbWlanConfig.preamble == i) {
				ifx_httpdWrite(wp, T("%s"), "selected");
			}
			ifx_httpdWrite(wp, T(">%s"), vb_preamble[i]);
		}
	} else if (!gstrcmp(name, T("wlan_vb_stbc"))) {
		for (i = 0; i <= 1; i++) {
			ifx_httpdWrite(wp, T("<option value='%d' "), i);
			if (vbWlanConfig.nSTBCrx == i) {
				ifx_httpdWrite(wp, T("%s"), "selected");
			}
			ifx_httpdWrite(wp, T(">%s"), vb_enable[i]);
		}
	}
#if 0
	else if (!gstrcmp(name, T("vb_radar_ena"))) {
		for (i = 0; i <= 1; i++) {
			ifx_httpdWrite(wp, T("<option value='%d' "), i);
			if (vbWlanConfig.radarEna == i) {
				ifx_httpdWrite(wp, T("%s"), "selected");
			}
			ifx_httpdWrite(wp, T(">%s"), vb_enable[i]);
		}
	}
#endif
	else if (!gstrcmp(name, T("vb_ldpc_ena"))) {
		for (i = 0; i <= 1; i++) {
			ifx_httpdWrite(wp, T("<option value='%d' "), i);
			if (vbWlanConfig.ldpcEna == i) {
				ifx_httpdWrite(wp, T("%s"), "selected");
			}
			ifx_httpdWrite(wp, T(">%s"), vb_enable[i]);
		}
	} else if (!gstrcmp(name, T("vb_bf_ena"))) {
		ifx_httpdWrite(wp, T("<option value='0' "), i);
		if (vbWlanConfig.beamForm == LTQ_MAPI_WLAN_BEAMFORM_OFF) {
			ifx_httpdWrite(wp, T("%s"), "selected");
		}
		ifx_httpdWrite(wp, T(">OFF\n"));
		ifx_httpdWrite(wp, T("<option value='3' "), i);
		if (vbWlanConfig.beamForm == LTQ_MAPI_WLAN_BEAMFORM_IMPLICIT) {
			ifx_httpdWrite(wp, T("%s"), "selected");
		}
		ifx_httpdWrite(wp, T(">Implicit BF\n"));
	}
#if 0
	else if (!gstrcmp(name, T("vb_mc2uc_ena"))) {
		for (i = 0; i <= 1; i++) {
			ifx_httpdWrite(wp, T("<option value='%d' "), i);
			if (vbWlanConfig.mc2ucEna == i) {
				ifx_httpdWrite(wp, T("%s"), "selected");
			}
			ifx_httpdWrite(wp, T(">%s"), vb_enable[i]);
		}
	}
#endif
	else if (!gstrcmp(name, T("vb_ackBoost"))) {
		for (i = 0; i <= 4; i++) {
			ifx_httpdWrite(wp, T("<option value='%d' "), i);
			if (vbWlanConfig.boostMode == i) {
				ifx_httpdWrite(wp, T("%s"), "selected");
			}
			ifx_httpdWrite(wp, T(">%s"), vb_AckBoost[i]);
		}
	}

      LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_wlan_config", "");
	return ret;
}

/**
   This function gets information required to display the web page for "WMM
   Settings" properly. It is called from wlan_vb_wmm_config.asp.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int ltq_get_vb_wmm_configuration(int eid, httpd_t wp, int argc, char_t ** argv)
{
	IFX_MAPI_WLAN_STA_WMM_Cfg wlVbStaWmm[IFX_MAPI_WLAN_WMM_NUM_AC];
	int32 ret = IFX_SUCCESS;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_wmm_configuration", "");
	/* get all WMM parameters */
	if ((ret =
	     ltq_mapi_get_vb_wmm_sta_config(wlVbStaWmm,
					    IFX_F_DEFAULT)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400,
			       T
			       ("Failed to get the complete STA WMM configuration\n\r"));
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_wmm_configuration", "");

	/* store for all ap/vap parameters of STA WMM in hidden variables */
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"sta_cwMin_BE_0\" value=\"%d\">\n"),
		       (wlVbStaWmm + 0)->ECWmin);
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"sta_cwMin_BK_0\" value=\"%d\">\n"),
		       (wlVbStaWmm + 1)->ECWmin);
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"sta_cwMin_VI_0\" value=\"%d\">\n"),
		       (wlVbStaWmm + 2)->ECWmin);
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"sta_cwMin_VO_0\" value=\"%d\">\n"),
		       (wlVbStaWmm + 3)->ECWmin);
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"sta_cwMax_BE_0\" value=\"%d\">\n"),
		       (wlVbStaWmm + 0)->ECWmax);
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"sta_cwMax_BK_0\" value=\"%d\">\n"),
		       (wlVbStaWmm + 1)->ECWmax);
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"sta_cwMax_VI_0\" value=\"%d\">\n"),
		       (wlVbStaWmm + 2)->ECWmax);
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"sta_cwMax_VO_0\" value=\"%d\">\n"),
		       (wlVbStaWmm + 3)->ECWmax);
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"sta_aifsn_BE_0\" value=\"%d\">\n"),
		       (wlVbStaWmm + 0)->AIFSN);
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"sta_aifsn_BK_0\" value=\"%d\">\n"),
		       (wlVbStaWmm + 1)->AIFSN);
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"sta_aifsn_VI_0\" value=\"%d\">\n"),
		       (wlVbStaWmm + 2)->AIFSN);
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"sta_aifsn_VO_0\" value=\"%d\">\n"),
		       (wlVbStaWmm + 3)->AIFSN);
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"sta_txop_BE_0\" value=\"%d\">\n"),
		       (wlVbStaWmm + 0)->TXOP);
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"sta_txop_BK_0\" value=\"%d\">\n"),
		       (wlVbStaWmm + 1)->TXOP);
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"sta_txop_VI_0\" value=\"%d\">\n"),
		       (wlVbStaWmm + 2)->TXOP);
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"sta_txop_VO_0\" value=\"%d\">\n"),
		       (wlVbStaWmm + 3)->TXOP);
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"sta_ackPolicy_BE_0\" value=\"%d\">\n"),
		       (wlVbStaWmm + 0)->ackPolicyEna);
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"sta_ackPolicy_BK_0\" value=\"%d\">\n"),
		       (wlVbStaWmm + 1)->ackPolicyEna);
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"sta_ackPolicy_VI_0\" value=\"%d\">\n"),
		       (wlVbStaWmm + 2)->ackPolicyEna);
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"sta_ackPolicy_VO_0\" value=\"%d\">\n"),
		       (wlVbStaWmm + 3)->ackPolicyEna);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_wmm_configuration", "");
      LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_wmm_configuration", "ret: %d", ret);
	return ret;
}

/**
   This function gets information required to display the web page for "WLAN
   SCAN results" properly. It is called from wlan_vb_scan_result.asp.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void ltq_get_vb_scan_results(int eid, httpd_t wp, int argc, char_t ** argv)
{
	uint32 count = 0, i = 0, tmpFreqBand = 0;
	LTQ_MAPI_VB_WLAN_Scan *wlVbScan = NULL;
	struct timeval tv;

	gettimeofday(&tv, NULL);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_scan_results", "%d:%d",
		       (int32) tv.tv_sec, (int32) tv.tv_usec);

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_scan_results",
		       "flagVbDisconnectFromAp: %d", flagVbDisconnectFromAp);
	if (ltq_mapi_get_wlan_scan(&count, &wlVbScan, flagVbDisconnectFromAp) !=
	    IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_scan_results", "");
		ifx_httpdWrite(wp,
			       T("<tr>\n<td colspan=\"9\" align=\"center\"><h2>"
				 "No SCAN results available!!!</h2></td>\n</tr>"));
		goto LTQ_Handler;
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_scan_results", "count: %d", count);
	for (i = 0; i < count; i++) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_scan_results",
			       "ssid: %s, strlen: %d", (wlVbScan + i)->ssid,
			       strlen((wlVbScan + i)->ssid));
		if (strlen((wlVbScan + i)->ssid) == 0) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_scan_results",
				       "HIDDEN SSID detected in position %d of scan results.",
				       i);
		} else {
			ifx_httpdWrite(wp,
				       T
				       ("<tr>\n<td id=\"vbScan_ssid%d\">%s</td>\n"),
				       i, (wlVbScan + i)->ssid);

			IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_scan_results",
				       "band: %s, beacon: %d",
				       (wlVbScan + i)->freqBand,
				       (wlVbScan + i)->beaconType);
			ifx_httpdWrite(wp,
				       T
				       ("<td id=\"vbScan_freqBand%d\">%s</td>\n"
					"<td id=\"vbScan_bandwidth%d\">%s</td>\n"
					"<td id=\"vbScan_beacon%d\">%s</td>\n"),
				       i, (wlVbScan + i)->freqBand, i,
				       wlan_channel_width[(wlVbScan +
							   i)->chanBW], i,
				       vb_beacon_type[(wlVbScan +
						       i)->beaconType]);

			IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_scan_results",
				       "standard: %s, auth type: %d",
				       (wlVbScan + i)->standard,
				       (wlVbScan + i)->authType);
			/* authType = -1 => open or shared authentication to be decided by
			   user; */
			if ((wlVbScan + i)->authType == -1) {
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"vbScan_auth%d\">n/a</td>\n"));
			} else {
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"vbScan_auth%d\">%s</td>\n"),
					       i,
					       vb_auth_type[(wlVbScan +
							     i)->authType]);
			}
			ifx_httpdWrite(wp,
				       T("<td id=\"vbScan_encr%d\">%s</td>\n"),
				       i,
				       wlan_encr_type[(wlVbScan +
						       i)->encrType]);

			IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_scan_results",
				       "standard: %s",
				       (wlVbScan + i)->standard);
			ifx_httpdWrite(wp,
				       T
				       ("<td id=\"vbScan_standard%d\">%s</td>\n"),
				       i, (wlVbScan + i)->standard);

			ifx_httpdWrite(wp,
				       T("<td id=\"vbScan_rssi%d\">%s</td>\n"),
				       i, (wlVbScan + i)->rssi);

			ifx_httpdWrite(wp, "<td id=\"vbScan_wpsEna%d\">%s</td>",
				       i,
				       (wlVbScan + i)->wpsEna ? "Yes" : "No");

			ifx_httpdWrite(wp,
				       "<td><input type='radio' name='vbConIdx' value='%d'></td>\n</tr>\n",
				       i);

			ifx_httpdWrite(wp,
				       "<input type=\"hidden\" name=\"vbScan_ssid%d\" value=\"%s\">\n",
				       i, (wlVbScan + i)->ssid);
			ifx_httpdWrite(wp,
				       "<input type=\"hidden\" name=\"vbScan_bssid%d\" value=\"%s\">\n",
				       i, (wlVbScan + i)->bssid);
			/*
			 * freqBand in scan result is string:
			 * 1. translate to integer (2.4GHz = 2, 5.2GHz = 5)
			 * 2. translate to MAPI enum (0: 2.4GHz, 1: 5GHz)
			 */
			tmpFreqBand = atoi((wlVbScan + i)->freqBand);
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_scan_results",
				       "tmpFreqBand: %d, scanFreqBand: %s",
				       tmpFreqBand, (wlVbScan + i)->freqBand);
			if (tmpFreqBand == 2)
				ifx_httpdWrite(wp,
					       "<input type=\"hidden\" name=\"vbScan_freqBand%d\" value=\"0\">\n",
					       i);
			else if (tmpFreqBand == 5)
				ifx_httpdWrite(wp,
					       "<input type=\"hidden\" name=\"vbScan_freqBand%d\" value=\"1\">\n",
					       i);

			ifx_httpdWrite(wp,
				       "<input type=\"hidden\" name=\"vbScan_bandwidth%d\" value=\"%d\">\n",
				       i, (wlVbScan + i)->chanBW);
			ifx_httpdWrite(wp,
				       "<input type=\"hidden\" name=\"vbScan_standard%d\" value=\"%s\">\n",
				       i, (wlVbScan + i)->standard);
			ifx_httpdWrite(wp,
				       "<input type=\"hidden\" name=\"vbScan_beacon%d\" value=\"%d\">\n",
				       i, (wlVbScan + i)->beaconType);
			ifx_httpdWrite(wp,
				       "<input type=\"hidden\" name=\"vbScan_auth%d\" value=\"%d\">\n",
				       i, (wlVbScan + i)->authType);
			ifx_httpdWrite(wp,
				       "<input type=\"hidden\" name=\"vbScan_encr%d\" value=\"%d\">\n",
				       i, (wlVbScan + i)->encrType);
		}
	}

      LTQ_Handler:
	IFX_MEM_FREE(wlVbScan)
	    /* reset flag indicating to disconnect from AP before scanning */
	    flagVbDisconnectFromAp = 0;
	gettimeofday(&tv, NULL);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_scan_results", "%d:%d",
		       (int32) tv.tv_sec, (int32) tv.tv_usec);
	return;
}

/**
   This function gets information required to display the web page for "WLAN
   Link Status" properly. It is called from wlan_vb_status.asp.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void ltq_vb_get_link_status(int eid, httpd_t wp, int argc, char_t ** argv)
{
	LTQ_MAPI_VB_WLAN_LinkStatus vbWlLinkStatus;
	char_t *name = NULL;
	struct timeval tv;

	gettimeofday(&tv, NULL);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_vb_get_link_status", "%d:%d",
		       (int32) tv.tv_sec, (int32) tv.tv_usec);

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Invalid number of args\n"));
		return;
	}

	memset(&vbWlLinkStatus, 0x00, sizeof(LTQ_MAPI_VB_WLAN_LinkStatus));
	if (ltq_mapi_get_vb_wlan_link_status(&vbWlLinkStatus, IFX_F_DEFAULT) !=
	    IFX_SUCCESS) {
		ifx_httpdError(wp, 400,
			       T("Failed to get video bridge link status."));
		return;
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_vb_get_link_status", "%s", name);
	if (!gstrcmp(name, T("wlan_vb_link_status"))) {
		ifx_httpdWrite(wp,
			       T
			       ("<input TYPE=\"text\" NAME=\"wlan_vb_wlan_status\""
				"MAXLENGTH=\"60\" SIZE=\"21\" value=\"%s\" disabled>\n"),
			       vbWlLinkStatus.status);
	} else if (!gstrcmp(name, T("wlan_vb_link_status_all"))) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_vb_get_link_status",
			       "ssid: %s, auth type: %d\n",
			       gVbWlProfile.ssid, gVbWlProfile.authType);

		ifx_httpdWrite(wp,
			       T
			       ("<tr>\n<td id=\"vbLinkStatus_ssid\">%s</td>\n"),
			       gVbWlProfile.ssid);

		if (!strcmp(vbWlLinkStatus.status, "Not Connected")) {
			ifx_httpdWrite(wp,
				       T
				       ("<td id=\"vbLinkStatus_freqBand\">%s</td>\n"
					"<td id=\"vbLinkStatus_bandwidth\">%s</td>\n"
				    "<td id=\"vbLinkStatus_channel\">n/a</td>\n"
				    "<td id=\"vbLinkStatus_country\">%s</td>\n"),
				       vb_freqBand[gVbWlProfile.freqBand],
				       wlan_channel_width[gVbWlProfile.chanBW],
				       vbWlLinkStatus.country);

			ifx_httpdWrite(wp,
				       T
				       ("<td id=\"vbLinkStatus_beaconType\">%s</td>\n"
					"<td id=\"vbLinkStatus_authType\">%s</td>\n"
					"<td id=\"vbLinkStatus_encrType\">%s</td>\n"),
				       vb_beacon_type[gVbWlProfile.beaconType],
				       vb_auth_type[gVbWlProfile.authType],
				       wlan_encr_type[gVbWlProfile.encrType]);

			ifx_httpdWrite(wp,
				       T
				       ("<td id=\"vbLinkStatus_standard\">%s</td>\n"
					"<td id=\"vbLinkSignalStrength\">%s</td>\n"
					"<td id=\"vbLinkQuality\">%s</td>\n"
					"<td id=\"vbPhyRate\">%s</td>\n"
					"<td id=\"vbConnectStatus\">%s</td>\n"),
				       "n/a", "None", "None", "n/a",
				       "Not Connected");
		} else {
			ifx_httpdWrite(wp,
				       T
				       ("<td id=\"vbLinkStatus_freqBand\">%s</td>\n"
					"<td id=\"vbLinkStatus_bandwidth\">%s</td>\n"
				    "<td id=\"vbLinkStatus_channel\">%d</td>\n"
				    "<td id=\"vbLinkStatus_country\">%s</td>\n"),
				       vb_freqBand[vbWlLinkStatus.freqBand],
				       wlan_channel_width[vbWlLinkStatus.
				       chanBW],
					   vbWlLinkStatus.channel, vbWlLinkStatus.country);

			ifx_httpdWrite(wp,
				       T
				       ("<td id=\"vbLinkStatus_beaconType\">%s</td>\n"
					"<td id=\"vbLinkStatus_authType\">%s</td>\n"
					"<td id=\"vbLinkStatus_encrType\">%s</td>\n"),
				       vb_beacon_type[gVbWlProfile.beaconType],
				       vb_auth_type[gVbWlProfile.authType],
				       wlan_encr_type[gVbWlProfile.encrType]);

			ifx_httpdWrite(wp,
				       T
				       ("<td id=\"vbLinkStatus_standard\">%s</td>\n"
					"<td id=\"vbLinkSignalStrength\">%d</td>\n"
					"<td id=\"vbLinkQuality\">%s</td>\n"
					"<td id=\"vbPhyRate\">%.1f</td>\n"
					"<td id=\"vbConnectStatus\">%s</td>\n"),
				       gVbWlProfile.standard,
				       vbWlLinkStatus.signalStrength,
				       vbWlLinkStatus.quality,
				       vbWlLinkStatus.txRate,
				       vbWlLinkStatus.status);
		}
		ifx_httpdWrite(wp, T("</tr>\n"));
	}

	gettimeofday(&tv, NULL);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_vb_get_link_status", "%d:%d",
		       (int32) tv.tv_sec, (int32) tv.tv_usec);
	return;
}

/**
   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void ltq_get_vb_wps_status(int eid, httpd_t wp, int argc, char_t ** argv)
{
	LTQ_MAPI_WPS_ConnectionStatus vbWlWpsLinkConnectStatus = LTQ_MAPI_WPS_CONNECTION_IDLE;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_wps_status", "");


	if (ltq_mapi_get_wps_connection_status(&vbWlWpsLinkConnectStatus) !=
	    IFX_SUCCESS) {
		ifx_httpdWrite(wp, "wpsStatus = \"IDLE\";\n");
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_wps_status",
			       "Failed to get video bridge wps connection status.");
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_wps_status",
		       "Connection status: %d", vbWlWpsLinkConnectStatus);

	switch (vbWlWpsLinkConnectStatus) {
	case LTQ_MAPI_WPS_CONNECTION_IDLE:
		ifx_httpdWrite(wp, "wpsStatus = \"IDLE\";\n");
		break;
	case LTQ_MAPI_WPS_CONNECTION_IN_PROGRESS:
		ifx_httpdWrite(wp, "wpsStatus = \"IN_PROGRESS\";\n");
		break;
	case LTQ_MAPI_WPS_CONNECTION_TIMEOUT:
		ifx_httpdWrite(wp, "wpsStatus = \"TIMEOUT\";\n");
		break;
	case LTQ_MAPI_WPS_CONNECTION_OVERLAP_ERR:
		ifx_httpdWrite(wp, "wpsStatus = \"OVERLAP\";\n");
		break;
	case LTQ_MAPI_WPS_CONNECTION_SUCCESS:
		ifx_httpdWrite(wp, "wpsStatus = \"SUCCESS\";\n");
		break;
	default:
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_wps_status",
			       "Invalid WPS connection status.");
		break;
	}

LTQ_Handler:
	ifx_httpdWrite(wp, T("loopObjectWps.current = %d;\n"),
		       gCurrentWpsStatusLoop++);
}

/**
   \param wp      web page structure

   \param path

   \param query

   \return
   None
*/
void ltq_get_vb_wps_result(httpd_t wp, char_t * path, char_t * query)
{
	char8 *pApVapActionType;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_wps_result", "");

	pApVapActionType = ifx_httpdGetVar(wp, T("submit_action"), T(""));
	if (!pApVapActionType) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_wps_result",
			       "(!pApVapActionType)");
		return;
	}

	if (!gstrcmp(pApVapActionType, "timeout")) {
		ifx_httpdRedirect(wp, "wlan_wps_status_timeout.html");
	} else if (!gstrcmp(pApVapActionType, "overlap")) {
		ifx_httpdRedirect(wp, "wlan_wps_status_overlap.html");
	} else if (!gstrcmp(pApVapActionType, "success")) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_wps_result", "");
	}

	websNextPage(wp);
}

/**
   \param wp      web page structure

   \param path

   \param query

   \return
   None
*/
void ltq_set_gbd_vb_config(httpd_t wp, char_t * path, char_t * query)
{
	LTQ_MAPI_WLAN_VB_GEN_BD_Cfg vbGenConfig;
	int32 flags = IFX_F_DEFAULT;
	char8 *pValue;
//	char8 ipaddr[MAX_IP_ADDR_LEN], ipMask[MAX_IP_ADDR_LEN];
	int32 oper = 0;
	char_t *pReboot = ifx_httpdGetVar(wp, T("reboot"), T(""));

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_gbd_vb_config", "");

	memset(&vbGenConfig, 0, sizeof(LTQ_MAPI_WLAN_VB_GEN_BD_Cfg));

	if (ltq_mapi_get_vb_gbd_config(&vbGenConfig, flags) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to get wlan vb config");
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_gbd_vb_config", "");
		return;
	}

#if 0
	ipaddr[0] = '\0';
	pValue = ifx_httpdGetVar(wp, "vbIP1", T(""));
	strcat(ipaddr, pValue);
	strcat(ipaddr, ".");
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_gbd_vb_config", "ipaddr: %s", ipaddr);
	pValue = ifx_httpdGetVar(wp, "vbIP2", T(""));
	strcat(ipaddr, pValue);
	strcat(ipaddr, ".");
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_gbd_vb_config", "ipaddr: %s", ipaddr);
	pValue = ifx_httpdGetVar(wp, "vbIP3", T(""));
	strcat(ipaddr, pValue);
	strcat(ipaddr, ".");
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_gbd_vb_config", "ipaddr: %s", ipaddr);
	pValue = ifx_httpdGetVar(wp, "vbIP4", T(""));
	strcat(ipaddr, pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_gbd_vb_config", "ipaddr: %s", ipaddr);
	inet_aton(ipaddr, &vbGenConfig.mgmtIP);

	/* IP Mask */
	ipMask[0] = '\0';
	pValue = ifx_httpdGetVar(wp, "vbNetMask1", T(""));
	strcat(ipMask, pValue);
	strcat(ipMask, ".");
	pValue = ifx_httpdGetVar(wp, "vbNetMask2", T(""));
	strcat(ipMask, pValue);
	strcat(ipMask, ".");
	pValue = ifx_httpdGetVar(wp, "vbNetMask3", T(""));
	strcat(ipMask, pValue);
	strcat(ipMask, ".");
	pValue = ifx_httpdGetVar(wp, "vbNetMask4", T(""));
	strcat(ipMask, pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_gbd_vb_config", "ipMask: %s", ipMask);
	inet_aton(ipMask, &vbGenConfig.mgmtNetMask);
#endif

	pValue = ifx_httpdGetVar(wp, T("wlan_vb_mode"), T(""));
	vbGenConfig.mode = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_gbd_vb_config",
		       "VB mode: %d", vbGenConfig.mode);

	pValue = ifx_httpdGetVar(wp, "wlan_vb_device_name", T(""));
	strcpy(vbGenConfig.name, pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_gbd_vb_config",
		       "apName: %s", vbGenConfig.name);

	oper = IFX_OP_MOD;
	if (pReboot && pReboot[0] == '0') {
#if 0
		pValue = ifx_httpdGetVar(wp, T("wlan_vb_dhcp_ena"), T(""));
		vbGenConfig.dhcpClntEna = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_gbd_vb_config",
			       "DHCP client enabled: %d",
			       vbGenConfig.dhcpClntEna);

		pValue =
		    ifx_httpdGetVar(wp, T("wlan_vb_allow_wlan_config"), T(""));
		vbGenConfig.wlanMgmt = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_gbd_vb_config",
			       "VB management via WLAN: %d",
			       vbGenConfig.wlanMgmt);
#endif

		flags = IFX_F_MODIFY;
		if (ltq_mapi_set_wlan_vb_config(oper, &vbGenConfig, flags) !=
		    IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_gbd_vb_config", "");
			ifx_httpdError(wp, 400, "Failed to set wlan vb config");
			return;
		}
		/*
		 * reset flag to make sure updated configuration is re-loaded to global arrays
		 * the next time a WLAN web page is opened
		 */
		flagVbConfigLoaded = 0;
	} else if (pReboot && pReboot[0] == '1') {
#if 0
		/*
		 * mode is switched, therefore new mode is opposite of current
		 * mode
		 */
		pValue = ifx_httpdGetVar(wp, T("wlVbCurrentMode"), T(""));
		if (gatoi(pValue) == LTQ_MAPI_WLAN_VB_STA)
			vbGenConfig.mode = LTQ_MAPI_WLAN_VB_AP;
		else
			vbGenConfig.mode = LTQ_MAPI_WLAN_VB_STA;

		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_gbd_vb_config",
			       "VB mode: %d", vbGenConfig.mode);
#endif

		/*
		 * only update rc.conf in case reboot is required, but do not call low level scripts
		 */
		flags = IFX_F_MODIFY | IFX_F_INT_DONT_CONFIGURE;
		if (ltq_mapi_set_wlan_vb_config(oper, &vbGenConfig, flags) !=
		    IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_gbd_vb_config", "");
			ifx_httpdError(wp, 400, "Failed to set wlan vb config");
			return;
		}
	}
	else if (pReboot && pReboot[0]=='3') {
#if 0
		pValue = ifx_httpdGetVar(wp, T("wlan_vb_mode"), T(""));
		vbGenConfig.mode = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_gbd_vb_config",
				"VB mode: %d", vbGenConfig.mode);

		pValue = ifx_httpdGetVar(wp, "wlan_vb_device_name", T(""));
		strcpy(vbGenConfig.name, pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_gbd_vb_config",
				"apName: %s", vbGenConfig.name);

		pValue = ifx_httpdGetVar(wp, T("wlan_vb_dhcp_ena"), T(""));
		vbGenConfig.dhcpClntEna = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_gbd_vb_config",
               "DHCP client enabled: %d", vbGenConfig.dhcpClntEna);

		pValue = ifx_httpdGetVar(wp, T("wlan_vb_allow_wlan_config"), T(""));
		vbGenConfig.wlanMgmt = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_gbd_vb_config",
				"VB management via WLAN: %d", vbGenConfig.wlanMgmt);
#endif

		/*
		 * only update rc.conf because reboot is required;
		 * do not call low level scripts
		*/
		flags = IFX_F_MODIFY | IFX_F_INT_DONT_CONFIGURE;
		if ( ltq_mapi_set_wlan_vb_config(oper, &vbGenConfig, flags) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_gbd_vb_config", "");
			ifx_httpdError(wp, 400, "Failed to set wlan vb config");
			return;
		}
	}

	/*
	 * reboot if changing from STA to AP mode or vice versa
	 * but first get unique values for IP and network mode
	 */
#if 0
	if (pReboot && pReboot[0] == '2') {
		ifx_httpdRedirect(wp, "wlan_vb_change_mode.asp");
		return;
	}
#endif
	if ((pReboot && pReboot[0]=='1') || (pReboot && pReboot[0]=='3')) {
		reboot_status = 3;
#ifdef CONFIG_FEATURE_LTQ_WIRELESS_VB
		ifx_httpdRedirect(wp, "reboot_vb300.html");
#else
		ifx_httpdRedirect(wp, "reboot_cpe.html");
#endif
		system("/etc/rc.d/rebootcpe.sh 5 &");
		return;
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_gbd_vb_config", "");
	websNextPage(wp);
}

/**
   \param wp      web page structure

   \param path

   \param query

   \return
   None
*/
void ltq_set_lbd_vb_config(httpd_t wp, char_t * path, char_t * query)
{
	LTQ_MAPI_WLAN_VB_GEN_BD_Cfg vbGenConfig;
	LTQ_MAPI_WLAN_VB_LAN_BD_Cfg vbLanConfig;
	int32 ret = IFX_SUCCESS, flags = IFX_F_DEFAULT;
	char8 *pValue, *pMac1 = NULL, *pMac2 = NULL, *pMac3 = NULL;
	char8 *pMac4 = NULL, *pMac5 = NULL, *pMac6 = NULL;
	int32 oper = 0;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_lbd_vb_config", "");

	memset(&vbGenConfig, 0, sizeof(LTQ_MAPI_WLAN_VB_GEN_BD_Cfg));
	memset(&vbLanConfig, 0, sizeof(LTQ_MAPI_WLAN_VB_LAN_BD_Cfg));

	if ((ret =
	     ltq_mapi_get_vb_gbd_config(&vbGenConfig, flags)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to get wlan vb config");
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_lbd_vb_config", "");
		return;
	}

	if ((ret =
	     ltq_mapi_get_wlan_vb_lan_config(&vbLanConfig,
					     flags)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to get wlan vb lan config");
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_lbd_vb_config", "");
		return;
	}

	pValue = ifx_httpdGetVar(wp, T("wlan_vb_lan_netmode"), T(""));
	if (vbGenConfig.mode == LTQ_MAPI_WLAN_VB_STA) {
		vbLanConfig.endPtNetMode = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_lbd_vb_config",
			       "VB LAN STA mode: %d", vbLanConfig.endPtNetMode);
	} else if (vbGenConfig.mode == LTQ_MAPI_WLAN_VB_AP) {
		vbLanConfig.masterNetMode = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_lbd_vb_config",
			       "VB LAN AP mode: %d", vbLanConfig.masterNetMode);
	}
#if 0
	pValue = ifx_httpdGetVar(wp, T("wlan_vb_lan_lbt_ena"), T(""));
	vbLanConfig.endPtLbEna = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_lbd_vb_config", "VB enable LBT: %d",
		       vbLanConfig.endPtLbEna);
#endif

	pMac1 = ifx_httpdGetVar(wp, T("wlan_vb_lan_cloneMAC_0"), T(""));
	pMac2 = ifx_httpdGetVar(wp, T("wlan_vb_lan_cloneMAC_1"), T(""));
	pMac3 = ifx_httpdGetVar(wp, T("wlan_vb_lan_cloneMAC_2"), T(""));
	pMac4 = ifx_httpdGetVar(wp, T("wlan_vb_lan_cloneMAC_3"), T(""));
	pMac5 = ifx_httpdGetVar(wp, T("wlan_vb_lan_cloneMAC_4"), T(""));
	pMac6 = ifx_httpdGetVar(wp, T("wlan_vb_lan_cloneMAC_5"), T(""));

	sprintf(vbLanConfig.endPtClonedMacAddr, "%s:%s:%s:%s:%s:%s",
		pMac1, pMac2, pMac3, pMac4, pMac5, pMac6);

	oper = IFX_OP_MOD;
	flags = IFX_F_MODIFY;
	if ((ret =
	     ltq_mapi_set_wlan_vb_lan_config(oper, &vbLanConfig,
					     flags)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_lbd_vb_config", "");
		ifx_httpdError(wp, 400, "Failed to set wlan vb lan config");
		return;
	}
	/*
	 * reset flag to make sure updated configuration is re-loaded to global arrays
	 * the next time a WLAN web page is opened
	 */
	flagVbConfigLoaded = 0;
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_lbd_vb_config", "");
	websNextPage(wp);
}

/**
   \param wp      web page structure

   \param path

   \param query

   \return
   None
*/
void ltq_set_wlan_config(httpd_t wp, char_t * path, char_t * query)
{
	LTQ_MAPI_VB_WLAN_Cfg vbWlanConfig;
	int32 ret = IFX_SUCCESS, flags = IFX_F_DEFAULT, oper = 0;
	char8 *pValue;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_config", "");

	memset(&vbWlanConfig, 0, sizeof(LTQ_MAPI_VB_WLAN_Cfg));

	if ((ret =
	     ltq_mapi_get_vb_wlan_config(&vbWlanConfig,
					 flags)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to get wlan vb config");
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_config", "");
		return;
	}

	pValue = ifx_httpdGetVar(wp, T("wlan_vb_freq"), T(""));
	vbWlanConfig.freqBand = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_config", "VB frequency band: %d",
		       vbWlanConfig.freqBand);

	switch (vbWlanConfig.freqBand) {
	case IFX_MAPI_WLAN_2_4_GHz_Freq:
		vbWlanConfig.standard = IFX_MAPI_WLAN_STD_802_11BGN;
		break;
	case IFX_MAPI_WLAN_5_GHz_Freq:
		vbWlanConfig.standard = IFX_MAPI_WLAN_STD_802_11AN;
		break;
	case IFX_MAPI_WLAN_DUAL_BAND:
		vbWlanConfig.standard = IFX_MAPI_WLAN_STD_802_11_ALL;
		break;
	default:
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_config",
			       "Invalid selection for frequency band");
		ifx_httpdError(wp, 400, "Invalid selection for frequency band");
		return;

	}

	pValue = ifx_httpdGetVar(wp, T("wlan_vb_tx_power"), T(""));
	vbWlanConfig.powerLvl = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_config", "VB TX power: %d",
		       vbWlanConfig.powerLvl);

	pValue = ifx_httpdGetVar(wp, T("wlan_vb_cts_prot"), T(""));
	vbWlanConfig.ctsProtctMode = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_config", "VB CTS protection: %d",
		       vbWlanConfig.ctsProtctMode);

	pValue = ifx_httpdGetVar(wp, T("wlan_vb_rts_thrshld"), T(""));
	vbWlanConfig.rts = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_config", "VB RTS: %d",
		       vbWlanConfig.rts);

	pValue = ifx_httpdGetVar(wp, T("wlan_vb_chan_width"), T(""));
	vbWlanConfig.nChanWidth = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_config", "VB Channel width %d",
		       vbWlanConfig.nChanWidth);

	pValue = ifx_httpdGetVar(wp, T("wlan_vb_guard_intval"), T(""));
	vbWlanConfig.nGuardIntvl = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_config", "VB Guard interval: %d",
		       vbWlanConfig.nGuardIntvl);

	pValue = ifx_httpdGetVar(wp, T("wlan_vb_preamble"), T(""));
	vbWlanConfig.preamble = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_config", "VB preamble mode: %d",
		       vbWlanConfig.preamble);

	pValue = ifx_httpdGetVar(wp, T("wlan_vb_stbc"), T(""));
	vbWlanConfig.nSTBCrx = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_config", "VB STBC mode: %d",
		       vbWlanConfig.nSTBCrx);

#if 0
	pValue = ifx_httpdGetVar(wp, T("vb_radar_ena"), T(""));
	vbWlanConfig.radarEna = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_config", "VB Radar detection: %s",
		       pValue);
#endif

	pValue = ifx_httpdGetVar(wp, T("vb_ldpc_ena"), T(""));
	vbWlanConfig.ldpcEna = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_config", "LDPC: %s", pValue);

	pValue = ifx_httpdGetVar(wp, T("vb_bf_ena"), T(""));
	vbWlanConfig.beamForm = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_config", "Beamforming: %s",
		       pValue);

#if 0
	pValue = ifx_httpdGetVar(wp, T("vb_mc2uc_ena"), T(""));
	vbWlanConfig.mc2ucEna = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_config", "MC 2 UC conversion: %s",
		       pValue);
#endif

	pValue = ifx_httpdGetVar(wp, T("vb_ackBoost"), T(""));
	vbWlanConfig.boostMode = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_config", "VB AckBoost: %s",
		       pValue);

	oper = IFX_OP_MOD;
	flags = IFX_F_MODIFY;
	if ((ret =
	     ltq_mapi_set_wlan_vb_wlan_config(oper, &vbWlanConfig,
					      flags)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_config", "");
		ifx_httpdError(wp, 400, "Failed to set wlan vb config");
		return;
	}
	/*
	 * reset flag to make sure updated configuration is re-loaded to global arrays
	 * the next time a WLAN web page is opened
	 */
	flagVbConfigLoaded = 0;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_config", "");
	websNextPage(wp);
}

/**
   This function is called from web page wlan_vb_wmm_config.asp. Values entered on the web
   page are retrieved and stored in corresponding structures of type
   IFX_MAPI_WLAN_STA_WMM_Cfg. These structure are provided to MAPI. Two additional
   parameters (operation and flags) specify the operations that will be executed
   within IFX WLAN MAPI (e.g. add, delete, modify). Note, that this function is only
   called for modify operations.

   \param wp      web page structure

   \param path

   \param query

   \return
   None.
*/
void ltq_set_wmm_config(httpd_t wp, char_t * path, char_t * query)
{
	IFX_MAPI_WLAN_STA_WMM_Cfg wlVbStaWmm[IFX_MAPI_WLAN_WMM_NUM_AC];
	int32 ret = IFX_SUCCESS, oper = IFX_OP_MOD;
	char8 *pValue;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wmm_config", "");
	/* get all WMM parameters */
	if ((ret =
	     ltq_mapi_get_vb_wmm_sta_config(wlVbStaWmm,
					    IFX_F_DEFAULT)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400,
			       T
			       ("Failed to get the complete STA WMM configuration\n\r"));
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wmm_config", "");

	/*
	 * get the new parameters
	 */
	/*
	 * ECWmin
	 */
	pValue = ifx_httpdGetVar(wp, T("sta_cwMin_BE"), T(""));
	(wlVbStaWmm + 0)->ECWmin = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wmm_config", "VB WMM ECWmin BE: %d",
		       (wlVbStaWmm + 0)->ECWmin);
	pValue = ifx_httpdGetVar(wp, T("sta_cwMin_BK"), T(""));
	(wlVbStaWmm + 1)->ECWmin = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wmm_config", "VB WMM ECWmin BE: %d",
		       (wlVbStaWmm + 1)->ECWmin);
	pValue = ifx_httpdGetVar(wp, T("sta_cwMin_VI"), T(""));
	(wlVbStaWmm + 2)->ECWmin = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wmm_config", "VB WMM ECWmin BE: %d",
		       (wlVbStaWmm + 2)->ECWmin);
	pValue = ifx_httpdGetVar(wp, T("sta_cwMin_VO"), T(""));
	(wlVbStaWmm + 3)->ECWmin = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wmm_config", "VB WMM ECWmin BE: %d",
		       (wlVbStaWmm + 3)->ECWmin);

	/* ECWmax */
	pValue = ifx_httpdGetVar(wp, T("sta_cwMax_BE"), T(""));
	(wlVbStaWmm + 0)->ECWmax = gatoi(pValue);
	pValue = ifx_httpdGetVar(wp, T("sta_cwMax_BK"), T(""));
	(wlVbStaWmm + 1)->ECWmax = gatoi(pValue);
	pValue = ifx_httpdGetVar(wp, T("sta_cwMax_VI"), T(""));
	(wlVbStaWmm + 2)->ECWmax = gatoi(pValue);
	pValue = ifx_httpdGetVar(wp, T("sta_cwMax_VO"), T(""));
	(wlVbStaWmm + 3)->ECWmax = gatoi(pValue);

	/* AIFSN */
	pValue = ifx_httpdGetVar(wp, T("sta_aifsn_BE"), T(""));
	(wlVbStaWmm + 0)->AIFSN = gatoi(pValue);
	pValue = ifx_httpdGetVar(wp, T("sta_aifsn_BK"), T(""));
	(wlVbStaWmm + 1)->AIFSN = gatoi(pValue);
	pValue = ifx_httpdGetVar(wp, T("sta_aifsn_VI"), T(""));
	(wlVbStaWmm + 2)->AIFSN = gatoi(pValue);
	pValue = ifx_httpdGetVar(wp, T("sta_aifsn_VO"), T(""));
	(wlVbStaWmm + 3)->AIFSN = gatoi(pValue);

	/* TXOP */
	pValue = ifx_httpdGetVar(wp, T("sta_txop_BE"), T(""));
	(wlVbStaWmm + 0)->TXOP = gatoi(pValue);
	pValue = ifx_httpdGetVar(wp, T("sta_txop_BK"), T(""));
	(wlVbStaWmm + 1)->TXOP = gatoi(pValue);
	pValue = ifx_httpdGetVar(wp, T("sta_txop_VI"), T(""));
	(wlVbStaWmm + 2)->TXOP = gatoi(pValue);
	pValue = ifx_httpdGetVar(wp, T("sta_txop_VO"), T(""));
	(wlVbStaWmm + 3)->TXOP = gatoi(pValue);

	/* Ack policy */
	pValue = ifx_httpdGetVar(wp, T("sta_ackPolicy_BE"), T(""));
	(wlVbStaWmm + 0)->ackPolicyEna = gatoi(pValue);
	pValue = ifx_httpdGetVar(wp, T("sta_ackPolicy_BK"), T(""));
	(wlVbStaWmm + 1)->ackPolicyEna = gatoi(pValue);
	pValue = ifx_httpdGetVar(wp, T("sta_ackPolicy_VI"), T(""));
	(wlVbStaWmm + 2)->ackPolicyEna = gatoi(pValue);
	pValue = ifx_httpdGetVar(wp, T("sta_ackPolicy_VO"), T(""));
	(wlVbStaWmm + 3)->ackPolicyEna = gatoi(pValue);

	/* now write the complete configuration to flash */
	oper = IFX_OP_MOD;
	/* set the wlan wmm configuration */
	if ((ret =
	     ltq_mapi_set_wlan_vb_wmm_config(oper, wlVbStaWmm,
					     IFX_F_DEFAULT)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to set wlan wmm sta config");
		goto LTQ_Handler;
	}

	/*
	 * reset flag to make sure updated configuration is re-loaded to global arrays
	 * the next time a WLAN web page is loaded
	 */
	flagVbConfigLoaded = 0;

      LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wmm_config", "ret: %d", ret);
	if (ret != IFX_SUCCESS)
		return;
	else
		websNextPage(wp);
}

/**
   This function is called from web page wlan_vb_wps_config.asp. Values entered on the web
   page are retrieved and stored in corresponding structures of type
   xxx. These structure are
   provided to IFX WLAN MAPI. Two additional parameters (operation and flags)
   specify the operations that will be executed within IFX WLAN MAPI (e.g. add,
   delete, modify). Note, that this function is only called for modify
   operations.

   \param wp      web page structure

   \param path

   \param query

   \return
   None.
*/
void ltq_set_wps_config(httpd_t wp, char_t * path, char_t * query)
{
	int32 ret = IFX_SUCCESS, flags = IFX_F_DEFAULT, oper = 0;
	LTQ_MAPI_VB_WLAN_Cfg vbWlanConfig;
	char8 *pApVapActionType, *pValue;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wps_config", "");

	pApVapActionType = ifx_httpdGetVar(wp, T("submit_action"), T(""));
	if (!pApVapActionType) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wps_config",
			       "(!pApVapActionType)");
		return;
	}

	if (!gstrcmp(pApVapActionType, "wpsPbcStart")) {
		/* trigger wps pbc pairing */
		if ((ret = ifx_mapi_trigger_wps_pbc(1)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wps_config", "");
			ifx_httpdError(wp, 400,
				       "Failed to trigger wps pbc pairing");
			goto LTQ_Handler;
		}
		gCurrentWpsStatusLoop = 1;
		ifx_httpdRedirect(wp, "wlan_vb_wps_status.asp");
		return;
	} else if (!gstrcmp(pApVapActionType, "wpsPinStart")) {
		/* trigger wps pin pairing */
		if ((ret = ifx_mapi_trigger_wps_pin(1, "12345670", "FF:FF:FF:FF:FF:FF"))
			!= IFX_SUCCESS) {
				ifx_httpdError(wp, 400, "Failed to trigger wps pin based pairing");
				goto LTQ_Handler;
		}
		gCurrentWpsStatusLoop = 1;
		ifx_httpdRedirect(wp, "wlan_vb_wps_status.asp");
		return;
	} else if (!gstrcmp(pApVapActionType, "wpsConfig")) {
		memset(&vbWlanConfig, 0, sizeof(LTQ_MAPI_VB_WLAN_Cfg));

		/* restore from global variable to save time */
		memcpy(&vbWlanConfig, &g_vbWlanConfig[0],
		       sizeof(LTQ_MAPI_VB_WLAN_Cfg));

		pValue = ifx_httpdGetVar(wp, T("wpsEnable"), T(""));
		vbWlanConfig.wpsEna = atoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wps_config", "wpsEnable: %d",
			       vbWlanConfig.wpsEna);
		oper = IFX_OP_MOD;
		flags = IFX_F_MODIFY;
		if ((ret =
		     ltq_mapi_set_wlan_vb_wlan_config(oper, &vbWlanConfig,
						      flags)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wps_config", "");
			ifx_httpdError(wp, 400, "Failed to set wlan vb config");
			return;
		}
	}

	/*
	 * reset flag to make sure updated configuration is re-loaded to global arrays
	 * the next time a WLAN web page is loaded
	 */
	flagVbConfigLoaded = 0;

      LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wps_config", "ret: %d", ret);
	if (ret != IFX_SUCCESS)
		return;
	else
		websNextPage(wp);
}

/**
   This function is called from web page wlan_vb_scan_result.asp.

   \param wp      web page structure

   \param path

   \param query

   \return
   None.
*/
void LTQ_WLAN_VB_PrepareConnect(httpd_t wp, char_t * path, char_t * query)
{
	uint32 vbConIdx = -1;
	char8 *pValue, sCommand[MAX_DATA_LEN];
	char8 *pApVapActionType;
	IFX_MAPI_WLAN_AuthType auth;
	IFX_MAPI_WLAN_EncrType encr;
#if 0
	int32 flags = IFX_F_DEFAULT, oper = 0;
	LTQ_MAPI_VB_WLAN_Cfg vbWlanConfig;
#endif

	IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_VB_PrepareConnect", "");

	pApVapActionType = ifx_httpdGetVar(wp, T("submit_action"), T(""));
	if (!pApVapActionType) {
		IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_VB_PrepareConnect",
			       "(!pApVapActionType)");
		return;
	}

	if (!gstrcmp(pApVapActionType, "connect")) {
		pValue = ifx_httpdGetVar(wp, T("vbConIdx"), T(""));
		vbConIdx = atoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_VB_PrepareConnect",
			       "selected index to connect: %d", vbConIdx);

		/*
		 * collect wlan_profile information, store it in global variable for
		 * later usage and proceed to "wlan_vb_connect.asp" to enter security
		 * credentials
		 */

		sprintf(sCommand, T("vbScan_ssid%d"), vbConIdx);
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_VB_PrepareConnect",
			       "selected SSID: %s", pValue);
		strcpy(gVbWlProfile.ssid, pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_VB_PrepareConnect",
			       "selected SSID: %s", gVbWlProfile.ssid);

		sprintf(sCommand, T("vbScan_bssid%d"), vbConIdx);
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_VB_PrepareConnect",
			       "selected BSSID: %s", pValue);
		strcpy(gVbWlProfile.bssid, pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_VB_PrepareConnect",
			       "selected BSSID: %s", gVbWlProfile.bssid);

		sprintf(sCommand, T("vbScan_auth%d"), vbConIdx);
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		auth = atoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_VB_PrepareConnect",
			       "authentication: %d", auth);

		sprintf(sCommand, T("vbScan_encr%d"), vbConIdx);
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		encr = atoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_VB_PrepareConnect",
			       "encryption: %d", encr);

		sprintf(sCommand, T("vbScan_beacon%d"), vbConIdx);
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		gVbWlProfile.beaconType = atoi(pValue);
		gVbWlProfile.authType = auth;
		gVbWlProfile.encrType = encr;
		IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_VB_PrepareConnect",
			       "beacon: %d", gVbWlProfile.beaconType);

		sprintf(sCommand, T("vbScan_freqBand%d"), vbConIdx);
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		gVbWlProfile.freqBand = atoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_VB_PrepareConnect",
			       "freqBand: %d", gVbWlProfile.freqBand);

		sprintf(sCommand, T("vbScan_bandwidth%d"), vbConIdx);
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		gVbWlProfile.chanBW = atoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_VB_PrepareConnect",
			       "chanBW: %d", gVbWlProfile.chanBW);

		sprintf(sCommand, T("vbScan_standard%d"), vbConIdx);
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		strcpy(gVbWlProfile.standard, pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_VB_PrepareConnect",
			       "standard: %s", gVbWlProfile.standard);

		if (ltq_mapi_set_vb_wlan_profile
		    (IFX_OP_MOD, &gVbWlProfile, IFX_F_MODIFY)
		    != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_VB_PrepareConnect",
				       "");
			ifx_httpdError(wp, 400,
				       "Failed to set wlan vb profile");
			goto LTQ_Handler;
		}

		/*
		 * in case of open security, skip the next page and directly connect
		 */
		if ((gVbWlProfile.beaconType == IFX_MAPI_WLAN_BEACON_BASIC) &&
		    (gVbWlProfile.encrType == IFX_MAPI_WLAN_ENCR_NONE)) {
			IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_VB_PrepareConnect",
				       "");
			/* trigger the script to connect to AP stored in rc.conf
			   wlan_profile */
			if (ltq_mapi_trigger_vb_connect() != IFX_SUCCESS) {
				IFX_MAPI_DEBUG(fd,
					       "/tmp/LTQ_WLAN_VB_PrepareConnect",
					       "");
				ifx_httpdError(wp, 400,
					       "Failed to trigger connection to AP");
				goto LTQ_Handler;
			}
			ifx_httpdRedirect(wp, "wlan_vb_status.asp");
		}
//                      return;
		websNextPage(wp);
	} else if (!gstrcmp(pApVapActionType, "scan")) {
#if 0
		memset(&vbWlanConfig, 0, sizeof(LTQ_MAPI_VB_WLAN_Cfg));
		if (ltq_mapi_get_vb_wlan_config(&vbWlanConfig, IFX_F_DEFAULT) !=
		    IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_VB_PrepareConnect",
				       "");
			ifx_httpdError(wp, 400, "Failed to get wlan vb config");
			goto LTQ_Handler;
		}

		pValue = ifx_httpdGetVar(wp, T("wlan_vb_freq"), T(""));
		vbWlanConfig.freqBand = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_VB_PrepareConnect",
			       "VB frequency band: %d", vbWlanConfig.freqBand);

		switch (vbWlanConfig.freqBand) {
		case IFX_MAPI_WLAN_2_4_GHz_Freq:
			vbWlanConfig.standard = IFX_MAPI_WLAN_STD_802_11BGN;
			break;
		case IFX_MAPI_WLAN_5_GHz_Freq:
			vbWlanConfig.standard = IFX_MAPI_WLAN_STD_802_11AN;
			break;
		case IFX_MAPI_WLAN_DUAL_BAND:
			vbWlanConfig.standard = IFX_MAPI_WLAN_STD_802_11_ALL;
			break;
		default:
			IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_VB_PrepareConnect",
				       "Invalid selection for frequency band");
			ifx_httpdError(wp, 400,
				       "Invalid selection for frequency band");
			goto LTQ_Handler;
		}

		oper = IFX_OP_MOD;
		flags = IFX_F_MODIFY | IFX_F_INT_DONT_CONFIGURE;
		if (ltq_mapi_set_wlan_vb_wlan_config(oper, &vbWlanConfig, flags)
		    != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_VB_PrepareConnect",
				       "");
			ifx_httpdError(wp, 400, "Failed to set wlan vb config");
			goto LTQ_Handler;
		}
		/*
		 * reset flag to make sure updated configuration is re-loaded to global arrays
		 * the next time a WLAN web page is opened
		 */
		flagVbConfigLoaded = 0;

		IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_VB_PrepareConnect", "");
#endif
		ifx_httpdRedirect(wp, "wlan_vb_scan_result.asp");
	}
      LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_VB_PrepareConnect", "");
	return;
}

/**
   This function is called from web page wlan_vb_connect.asp.

   \param wp      web page structure

   \param path

   \param query

   \return
   None.
*/
void ltq_set_vb_connect(httpd_t wp, char_t * path, char_t * query)
{
	LTQ_MAPI_VB_WLAN_Profile vbWlanProfile;
	int32 ret = IFX_SUCCESS, flags = IFX_F_DEFAULT, oper = 0;
	char8 *pValue;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_connect", "");

	memset(&vbWlanProfile, 0, sizeof(LTQ_MAPI_VB_WLAN_Profile));
	/* restore from global variable to save time */
	memcpy(&vbWlanProfile, &gVbWlProfile, sizeof(LTQ_MAPI_VB_WLAN_Profile));

	if (vbWlanProfile.encrType == IFX_MAPI_WLAN_ENCR_WEP) {
		pValue = ifx_httpdGetVar(wp, T("wepAuthType"), T(""));
		vbWlanProfile.authType = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_connect",
			       "VB auth type: %d",
			       vbWlanProfile.authType);

		pValue = ifx_httpdGetVar(wp, T("wepKey1"), T(""));
		strcpy(vbWlanProfile.wepKey1, pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_connect",
			       "VB wep Key 1: %s", vbWlanProfile.wepKey1);

		pValue = ifx_httpdGetVar(wp, T("wepKey2"), T(""));
		strcpy(vbWlanProfile.wepKey2, pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_connect",
			       "VB wep Key 2: %s", vbWlanProfile.wepKey2);

		pValue = ifx_httpdGetVar(wp, T("wepKey3"), T(""));
		strcpy(vbWlanProfile.wepKey3, pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_connect",
			       "VB wep Key 3: %s", vbWlanProfile.wepKey3);

		pValue = ifx_httpdGetVar(wp, T("wepKey4"), T(""));
		strcpy(vbWlanProfile.wepKey4, pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_connect",
			       "VB wep Key 4: %s", vbWlanProfile.wepKey4);

		pValue = ifx_httpdGetVar(wp, T("keyIndex"), T(""));
		vbWlanProfile.wepKeyIndex = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_connect",
			       "VB wep Key index: %d",
			       vbWlanProfile.wepKeyIndex);

		pValue = ifx_httpdGetVar(wp, T("wepKeyType"), T(""));
		vbWlanProfile.wepKeyType = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_connect",
			       "VB wep Key index: %d",
			       vbWlanProfile.wepKeyType);

		pValue = ifx_httpdGetVar(wp, T("wepEncrLevel"), T(""));
		vbWlanProfile.wepEncrLevel = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_connect",
			       "VB wep Key index: %d",
			       vbWlanProfile.wepEncrLevel);
	} else if (vbWlanProfile.authType ==
		   IFX_MAPI_WLAN_AUTH_ENTERPRISE_PERSONAL) {
		pValue = ifx_httpdGetVar(wp, T("authType"), T(""));
		vbWlanProfile.authType = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_connect",
			       "VB auth type: %d", vbWlanProfile.authType);
		if (vbWlanProfile.authType == IFX_MAPI_WLAN_AUTH_PERSONAL) {
			pValue = ifx_httpdGetVar(wp, T("passPhrase"), T(""));
			strcpy(vbWlanProfile.passPhrase, pValue);
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_connect",
				       "VB passphrase: %s",
				       vbWlanProfile.passPhrase);
		} else if (vbWlanProfile.authType == IFX_MAPI_WLAN_AUTH_RADIUS) {
			pValue =
			    ifx_httpdGetVar(wp, T("radiusPassPhrase"), T(""));
			strcpy(vbWlanProfile.passPhrase, pValue);
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_connect",
				       "VB RADIUS passphrase: %s",
				       vbWlanProfile.passPhrase);

			pValue =
			    ifx_httpdGetVar(wp, T("radiusUserName"), T(""));
			strcpy(vbWlanProfile.userName, pValue);
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_connect",
				       "VB RADIUS userName: %s",
				       vbWlanProfile.userName);
		}
	} else if (vbWlanProfile.authType == IFX_MAPI_WLAN_AUTH_PERSONAL) {
		pValue = ifx_httpdGetVar(wp, T("passPhrase"), T(""));
		strcpy(vbWlanProfile.passPhrase, pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_connect",
			       "VB passphrase: %s", vbWlanProfile.passPhrase);
	} else if (vbWlanProfile.authType == IFX_MAPI_WLAN_AUTH_RADIUS) {
		pValue = ifx_httpdGetVar(wp, T("radiusPassPhrase"), T(""));
		strcpy(vbWlanProfile.passPhrase, pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_connect",
			       "VB RADIUS passphrase: %s",
			       vbWlanProfile.passPhrase);

		pValue = ifx_httpdGetVar(wp, T("radiusUserName"), T(""));
		strcpy(vbWlanProfile.userName, pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_connect",
			       "VB RADIUS userName: %s",
			       vbWlanProfile.userName);
	}

	/*
	 * update beacon type according to user selection:
	 * encryptionType is CCMP for WPA2 and TKIP for WPA
	*/
	if (vbWlanProfile.beaconType == IFX_MAPI_WLAN_BEACON_WPA_WPA2) {
		pValue = ifx_httpdGetVar(wp, T("beaconType"), T(""));
		vbWlanProfile.beaconType = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_connect",
					"VB security: %d",
					vbWlanProfile.beaconType);
		if (vbWlanProfile.beaconType == IFX_MAPI_WLAN_BEACON_WPA)
			vbWlanProfile.encrType = IFX_MAPI_WLAN_ENCR_TKIP;
		else
			vbWlanProfile.encrType = IFX_MAPI_WLAN_ENCR_CCMP;
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_connect",
					"VB encryption: %d",
					vbWlanProfile.encrType);
	}

	oper = IFX_OP_MOD;
	flags = IFX_F_MODIFY;
	if ((ret =
	     ltq_mapi_set_vb_wlan_profile(oper, &vbWlanProfile,
					  flags)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_connect", "");
		ifx_httpdError(wp, 400, "Failed to set wlan vb profile");
		goto LTQ_Handler;
	}

	/* trigger the script to connect to AP stored in rc.conf wlan_profile */
	if ((ret = ltq_mapi_trigger_vb_connect()) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_connect", "");
		ifx_httpdError(wp, 400, "Failed to trigger connection to AP");
		goto LTQ_Handler;
	}
      LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_connect", "ret: %d", ret);
	websNextPage(wp);
}

/**
   This function is called from web page wlan_vb_gen_wlan_configasp.

   \param wp      web page structure

   \param path

   \param query

   \return
   None.
*/
void ltq_set_vb_ssid_wildcard(httpd_t wp, char_t * path, char_t * query)
{
	char8 *pValue;
	LTQ_MAPI_VB_WLAN_Scan wlVbScan;
#if 0
	LTQ_MAPI_VB_WLAN_Cfg vbWlanConfig;
#endif

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_ssid_wildcard", "");

	memset(&wlVbScan, 0, sizeof(LTQ_MAPI_VB_WLAN_Scan));

	pValue = ifx_httpdGetVar(wp, T("disconnect"), T(""));
	flagVbDisconnectFromAp = atoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_ssid_wildcard",
		       "flagVbDisconnectFromAp: %d", flagVbDisconnectFromAp);

	pValue = ifx_httpdGetVar(wp, T("ssid_wildcard"), T(""));
	strcpy(wlVbScan.ssid_wildcard, pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_ssid_wildcard", "ssid_wildcard: %s",
		       wlVbScan.ssid_wildcard);

	if (ltq_mapi_set_wlan_vb_scan_config
	    (IFX_OP_MOD, &wlVbScan, IFX_F_MODIFY) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_ssid_wildcard", "");
		ifx_httpdError(wp, 400, "Failed to set wlan vb scan config");
		goto LTQ_Handler;
	}
#if 0
	if (ltq_mapi_get_vb_wlan_config(&vbWlanConfig, IFX_F_DEFAULT) !=
	    IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to get wlan vb config");
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_ssid_wildcard", "");
		return;
	}

	pValue = ifx_httpdGetVar(wp, T("wlan_vb_freq"), T(""));
	vbWlanConfig.freqBand = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_ssid_wildcard",
		       "VB frequency band: %d", vbWlanConfig.freqBand);

	switch (vbWlanConfig.freqBand) {
	case IFX_MAPI_WLAN_2_4_GHz_Freq:
		vbWlanConfig.standard = IFX_MAPI_WLAN_STD_802_11BGN;
		break;
	case IFX_MAPI_WLAN_5_GHz_Freq:
		vbWlanConfig.standard = IFX_MAPI_WLAN_STD_802_11AN;
		break;
	case IFX_MAPI_WLAN_DUAL_BAND:
		vbWlanConfig.standard = IFX_MAPI_WLAN_STD_802_11_ALL;
		break;
	default:
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_ssid_wildcard",
			       "Invalid selection for frequency band");
		ifx_httpdError(wp, 400, "Invalid selection for frequency band");
		return;

	}

	if (ltq_mapi_set_wlan_vb_wlan_config
	    (IFX_OP_MOD, &vbWlanConfig, IFX_F_MODIFY | IFX_F_INT_DONT_CONFIGURE)
	    != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_config", "");
		ifx_httpdError(wp, 400, "Failed to set wlan vb config");
		return;
	}
	/*
	 * reset flag to make sure updated configuration is re-loaded to global arrays
	 * the next time a WLAN web page is opened
	 */
	flagVbConfigLoaded = 0;
#endif
      LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_vb_ssid_wildcard", "");
	ifx_httpdRedirect(wp, "wlan_vb_scan_result.asp");
	return;
}

int ltq_get_vb_mode(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("VBX"));
	return IFX_SUCCESS;
}

int ltq_get_vb_Info(int eid, httpd_t wp, int argc, char_t **argv)
{
	int32 		ret = IFX_SUCCESS;
	LTQ_MAPI_WLAN_VB_GEN_BD_Cfg     vbGenConfig;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_Info","");

	/* get the global bridge device configuration from rc.conf */
	ret = ltq_mapi_get_vb_gbd_config(&vbGenConfig, IFX_F_DEFAULT);
	if (ret != IFX_SUCCESS)	{
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_Info","");
		ifx_httpdError(wp,400,T("Could not get general configuration\n\r"));
		goto LTQ_Handler;
	}

	ifx_httpdWrite(wp, T("document.write(\"<th colspan=\\\"3\\\">"
		"VB Information</th>\");\n"));
	ifx_httpdWrite(wp, T("document.write(\"<tr>\");\n"));
	ifx_httpdWrite(wp, T("document.write(\"<td width=\\\"47%\\\">"
		"IP Address</td>\");\n"));
	ifx_httpdWrite(wp, T("document.write(\"<td>%s</td></tr>\");\n"),
		inet_ntoa(vbGenConfig.mgmtIP));

	if (vbGenConfig.mode == LTQ_MAPI_WLAN_VB_AUTO) {
		IFX_MAPI_WLAN_DevType	apType;
		char8	buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
		uint32	outFlag = IFX_F_DEFAULT;
		/*
			gbc_mode is still set to auto, therefore we get the AP type
			from wlmn_0_apType parameter
		*/
		sprintf(buf, "wlmn_0_apType");
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAIN,
			buf, IFX_F_GET_ANY, &outFlag, sValue)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_Info", "");
			return IFX_FAILURE;
		}
		apType = atoi(sValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_Info", "apType: %d", apType);
		ifx_httpdWrite(wp, T("document.write(\"<tr> <td width=\\\"47%\\\">"
			"VB Mode</td> <td>%s</td> </tr>\");\n"),
			apType==IFX_MAPI_WLAN_DEV_TYPE_STA?"STA":"AP");
	} else {
		ifx_httpdWrite(wp, T("document.write(\"<tr> <td width=\\\"47%\\\">"
			"VB Mode</td> <td>%s</td> </tr>\");\n"),
			vbGenConfig.mode==LTQ_MAPI_WLAN_VB_STA?"STA":"AP");
	}
	ifx_httpdWrite(wp, T("document.write(\"<tr> <td width=\\\"47%\\\">"
		"DHCP Mode</td> <td>%s</td></tr>\");\n"),
		vbGenConfig.dhcpClntEna==1?"DHCP Client":"Static");

LTQ_Handler:
	return ret;
}

int ltq_vb_load_eth_phy_config(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT, i = 0;
	char8 sBuf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_vb_load_eth_phy_config", "");

	sBuf[0] = '\0';
	sValue[0] = '\0';
	sprintf(sBuf, "%s_Count", TAG_VB_ETH_PHY);
	if (ifx_GetObjData(FILE_RC_CONF, TAG_VB_ETH_PHY, sBuf,
			   IFX_F_GET_ANY,
			   (IFX_OUT uint32 *) & outFlag,
			   sValue) != IFX_SUCCESS) {
		return IFX_FAILURE;
	}

	g_vbEthPhyCount = atoi(sValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_vb_load_eth_phy_config",
		       "number of ethernet ports: %d", g_vbEthPhyCount);
	if ((g_vbEthPhyCount > 2) || (g_vbEthPhyCount < 0)) {
		g_vbEthPhyCount = 0;
		return IFX_FAILURE;
	}

	for (i = 0; i < g_vbEthPhyCount; i++) {
		memset(&g_vbEthPhyConfig[i], 0,
		       sizeof(LTQ_MAPI_VB_ETH_PHY_Cfg));

		sprintf(g_vbEthPhyConfig[i].iid.cpeId.secName, "%s",
			TAG_VB_ETH_PHY);
		g_vbEthPhyConfig[i].iid.cpeId.Id = i + 1;
		g_vbEthPhyConfig[i].iid.config_owner = IFX_WEB;

		if (ltq_mapi_get_vb_eth_phy_config(&g_vbEthPhyConfig[i], flags)
		    != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to get vb eth phy port config");
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_vb_load_eth_phy_config",
				       "port: %d", i + 1);
			return IFX_FAILURE;
		}
	}

	return IFX_SUCCESS;
}
#endif				/* #ifdef CONFIG_FEATURE_LTQ_WIRELESS_VB */

/* ========================================================================== */
/*                         Function pointer exports                           */
/* ========================================================================== */
#endif				/* #ifdef CONFIG_FEATURE_IFX_WIRELESS */
