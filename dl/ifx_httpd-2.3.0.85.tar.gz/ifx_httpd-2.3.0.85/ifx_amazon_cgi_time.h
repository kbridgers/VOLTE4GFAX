/*
** =============================================================================
**   FILE NAME        : ifx_amazon_cgi_time.h
**   PROJECT          : AMAZON
**   DATE             : 23-Feb-2009
**   AUTHOR           : Amazon Team
**   DESCRIPTION      : This file contains the CGI constant definitions
**   REFERENCES       :
**   COPYRIGHT        : Copyright (c) 2008
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          :
**   $Date            $Author                         $Comment
**
** ============================================================================
*/

#ifndef _IFX_AMAZON_CGI_TIME_H_
#define _IFX_AMAZON_CGI_TIME_H_

typedef struct {
	/* Web ASP selected option value index */
	int value;
	/* Web ASP selected option value index content */
	char_t *str;
} CGI_ENUMSEL_S;

#endif				/* _IFX_AMAZON_CGI_TIME_H_ */
