//#include <sys/syslog.h>
//#include <ifx_emf.h>
//#include "ifx_httpd_method.h"
//#include <signal.h>
//#include <unistd.h>
//#include <sys/types.h>
//#include <sys/wait.h>
//#include <ifx_common.h>
//#include "./ifx_amazon_cgi.h"
//#include "./ifx_amazon_cgi_getFunctions.h"
//#include "ifx_api_ipt_common.h"
//#include <sys/ioctl.h>

#ifdef IFX_CONFIG_TR037
int ifx_get_wan_tr037(int eid, httpd_t wp, int argc, char_t ** argv);
#endif				//IFX_CONFIG_TR037

//tr037.asp

#ifdef IFX_CONFIG_TR037
void ifx_set_wan_tr037(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pCheck;
	char_t sCheck[6][MAX_FILELINE_LEN];
	char_t sParams[][32] = {
		"TR037_PROTO",
#ifdef CONFIG_PACKAGE_PPP_MOD_PPPOA
		"TR037_UN", "TR037_PW",
#endif				//CONFIG_PACKAGE_PPP_MOD_PPPOA
		"TR037_IP", "TR037_NM", "TR037_GW"
	};
	int i = 0, j = 0;;
	int proto = 0;
	int sParams_length = 1;

#ifdef CONFIG_PACKAGE_PPP_MOD_PPPOA
	sParams_length += 2;
#endif
	sParams_length += 3;

	a_assert(wp);
	sCheck[0] = '\0';

#ifdef CONFIG_PACKAGE_PPP_MOD_PPPOA
	for (i = 0; i < 3; i++)
#endif				//CONFIG_PACKAGE_PPP_MOD_PPPOA
	{
		// Get value from ASP file
		pCheck = ifx_httpdGetVar(wp, sParams[i], T(""));
		gsprintf(sCheck[i], "%s=\"%s\"\n", sParams[i], pCheck);
		if (i == 0) {
#ifdef CONFIG_PACKAGE_PPP_MOD_PPPOA
			if (!strcmp(pCheck, "PPPOA")) {
				proto = IP_BOOT_PPPOA;
			}
#endif				//CONFIG_PACKAGE_PPP_MOD_PPPOA
			if (!strcmp(pCheck, "BR2684")) {
				proto = IP_BOOT_FIXED;
			}
		}
	}

#ifdef CONFIG_PACKAGE_PPP_MOD_PPPOA
	for (i = 3; i < sParams_length; i++)
#else
	for (i = 1; i < sParams_length; i++)
#endif				//CONFIG_PACKAGE_PPP_MOD_PPPOA
	{
		char IP[MAX_FILELINE_LEN];
		IP[0] = '\0';
		for (j = 1; j < 5; j++) {
			char VarName[MAX_FILELINE_LEN];
			sprintf(VarName, "%s%d", sParams[i], j);
			pCheck = ifx_httpdGetVar(wp, VarName, T(""));
			if (strlen(pCheck) > 0) {
				if (atoi(pCheck) > 255
				    || (atoi(pCheck) <= 0
					&& pCheck[0] != '0')) {
					ifx_httpdError(wp, 400,
						       "Invalidate IP address");
					return;
				}
				strcat(IP, pCheck);
				if (j != 4)
					strcat(IP, ".");
			} else {
				if (proto == IP_BOOT_FIXED) {
					ifx_httpdError(wp, 400,
						       "Invalidate IP address");
					return;
				}
				sprintf(IP, " ");
				break;
			}
		}
		gsprintf(sCheck[i], "%s=\"%s\"\n", sParams[i], IP);
	}
	system(SERVICE_WAN_STOP);
	ifx_SetCfgData(FILE_RC_CONF, TAG_WAN_TR037, 6, sCheck[0], sCheck[1],
		       sCheck[2], sCheck[3], sCheck[4], sCheck[5]);
	// Update Wan Mode to rc.conf
	gsprintf(sCheck[0], "ipoption_wan=\"TR037\"\n");
	ifx_SetCfgData(FILE_RC_CONF, TAG_WAN_MAIN, 1, sCheck[0]);

	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}
	//Runtime Change
	system(SERVICE_WAN_START);

	websNextPage(wp);
}
#endif				//IFX_CONFIG_TR037

// tr037.asp
#ifdef IFX_CONFIG_TR037
int ifx_get_wan_tr037(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_FILELINE_LEN];
	char_t *name, tmp_name[MAX_FILELINE_LEN];

	sValue[0] = '\0';

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	if (!gstrncmp(name, "TR037_IP", 8) || !gstrncmp(name, "TR037_NM", 8)
	    || !gstrncmp(name, "TR037_GW", 8)) {
		memset(tmp_name, 0, sizeof(tmp_name));
		memcpy(tmp_name, name, 8);
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WAN_TR037, tmp_name, sValue) == 1) {
			char *delim = ". \n";
			char *pValue;
			int i = 0;
			pValue = strtok(sValue, delim);
			if (name[8] == '1') {
				if (pValue == NULL) {
					ifx_httpdWrite(wp, T(" "));
					return 0;
				}
				ifx_httpdWrite(wp, T("%s"), pValue);
			}
			for (i = 1; i < 4; i++) {
				pValue = strtok(NULL, delim);
				if (pValue == NULL) {
					ifx_httpdWrite(wp, T(" "));
					return 0;
				}
				if (i == name[8] - '1') {
					ifx_httpdWrite(wp, T("%s"), pValue);
					return 0;
				}
			}
		}
	} else if (ifx_GetCfgData(FILE_RC_CONF, TAG_WAN_TR037, name, sValue) ==
		   1) {
		if (!gstrcmp(name, "TR037_PROTO")) {
			int proto_type = IP_BOOT_UNKNOWN;
#ifdef CONFIG_PACKAGE_PPP_MOD_PPPOA
			if (!gstrcmp(sValue, "PPPOA")) {
				proto_type = IP_BOOT_PPPOA;
			}
#endif				//CONFIG_PACKAGE_PPP_MOD_PPPOA
#ifdef CONFIG_PACKAGE_BR2684CTL
			if (!gstrcmp(sValue, "BR2684")) {
				proto_type = IP_BOOT_FIXED;
			}
#endif				//CONFIG_PACKAGE_BR2684CTL
#ifdef CONFIG_FEATURE_CLIP
			if (!gstrcmp(sValue, "CLIP")) {
				proto_type = IP_BOOT_FIXED;
			}
#endif				//CONFIG_FEATURE_CLIP
			gsprintf(sValue, "%d", proto_type);
			ifx_httpdWrite(wp, sValue);
			return 0;
		}
		ifx_httpdWrite(wp, T("%s"), sValue);
		return 0;
	}

	return 0;
}
#endif				//IFX_CONFIG_TR037

//end tr037.asp
