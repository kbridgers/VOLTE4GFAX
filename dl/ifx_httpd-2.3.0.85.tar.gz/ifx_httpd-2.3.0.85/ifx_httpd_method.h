
/********************************** Includes **********************************/

#include	<ctype.h>
#include	<stdlib.h>
#include	<string.h>
#include	<stdarg.h>

/********************************** Defines ***********************************/
/* 
 *	Read handler flags and state
 */
#define WEBS_BEGIN			0x1	/* Beginning state */
#define WEBS_HEADER			0x2	/* Ready to read first line */
#define WEBS_POST			0x4	/* POST without content */
#define WEBS_POST_CLEN		0x8	/* Ready to read content for POST */
#define WEBS_PROCESSING		0x10	/* Processing request */
#define WEBS_KEEP_TIMEOUT	15000	/* Keep-alive timeout (15 secs) */
#define WEBS_TIMEOUT		60000	/* General request timeout (60) */

#define PAGE_READ_BUFSIZE	512	/* bytes read from page files */
#define MAX_PORT_LEN		10	/* max digits in port number */
#define WEBS_SYM_INIT		64	/* initial # of sym table entries */

#ifdef IFX_DEBUG
#define	ifx_debug_printf(format, args...) printf(format, ##args)
#else
#define	ifx_debug_printf(format, args...)
#endif

#ifdef IFX_DEBUG
#define IFX_FREE(x) (x) ? free((x)) : \
ifx_debug_printf("\n Error : Try to free NULL Pointer from function[%s],\
		line [%d] \n", __FUNCTION__, __LINE__)
#else
#define IFX_FREE(x) (x) ?  free((x)): (x)

#endif

/*
 *	Defines for file open.
 */
#ifndef CE
#define	SOCKET_RDONLY	O_RDONLY
#define	SOCKET_BINARY	O_BINARY
#else				/* CE */
#define	SOCKET_RDONLY	0x1
#define	SOCKET_BINARY	0x2
#endif				/* CE */

/*
typedef struct websRec {
	int retVal;
	char ErrBuff[128];
} websRec;

typedef websRec	*httpd_t;
typedef websRec httpdType;
*/

#include "ifx_httpd.h"

/******************************** Prototypes **********************************/
extern int ifx_httpdWrite(httpd_t wp, char_t * fmt, ...);
extern void ifx_httpdError(httpd_t wp, int code, char_t * msg, ...);

extern int ejArgs(int argc, char_t ** argv, char_t * fmt, ...);
extern void ejSetResult(int eid, char_t * s);

extern void ifx_httpdDone(httpd_t wp, int code);
extern void ifx_httpdFooter(httpd_t wp);
extern char_t *ifx_httpdGetPassword();
extern char_t *ifx_httpdGetVar(httpd_t wp, char_t * var, char_t * def);

extern int ifx_httpdGetVarMbuff(httpd_t wp, char_t * var, char_t * def);

extern void ifx_httpdHeader(httpd_t wp);
extern void ifx_httpdRedirect(httpd_t wp, char_t * url);
extern void ifx_httpdRedirect_302(httpd_t wp, char_t * url);
extern void ifx_jsRedirect(httpd_t wp, char_t * url);
extern int ifx_isHostlinklocal(httpd_t wp);
extern void ifx_httpdSetPassword(char_t * password);
extern char_t *stritoa(int n, char_t * string, int width);

extern int get_config_version(const char *configFile, char *version);
extern struct st_versionnode *search_config_node(struct st_versionnode
						 **configheadNode,
						 pid_t configPID);
extern int add_config_node(struct st_versionnode **configheadNode,
			   pid_t newPID);
