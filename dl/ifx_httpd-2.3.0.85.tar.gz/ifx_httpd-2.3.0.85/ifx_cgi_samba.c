#include <ifx_emf.h>
#include "ifx_httpd_method.h"
#include "./ifx_amazon_cgi.h"
#include "./ifx_amazon_cgi_getFunctions.h"
#include "./ifx_cgi_common.h"

#ifdef CONFIG_FEATURE_SAMBA	//#ifdef CONFIG_PACKAGE_samba3
char fileShareAction[20];
char fileShareOrder[10];
char fileUserAction[20];
char fileUserOrder[10];

extern void websNextPage(httpd_t wp);
extern int ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);

extern char *status_str;

int ifx_set_smb_users()
{
	//Save the smbpasswd file into rc.conf
	{
		const char *fname = "/etc/samba/smbpasswd";
		FILE *fp = NULL;
		char sLine[MAX_FILELINE_LEN];
		char sTemp[MAX_FILELINE_LEN];
		char buf[BUF_SIZE_1K];
		char main_buf[BUF_SIZE_1K];
		int i;

		if ((fp = fopen(fname, "r")) == NULL) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("\ncan't open file %s\n", fname);
#endif
		} else {
			sLine[0] = '\0';
			sTemp[0] = '\0';
			buf[0] = '\0';
			main_buf[0] = '\0';
			i = 0;
			while (fgets(sLine, sizeof(sLine), fp)) {
				sLine[strlen(sLine)-1]='\0';
				snprintf(sTemp, sizeof(sTemp), "%s%d='%s'\n",
					 TAG_SMB_PASSWORD_FILE_LINE, i, sLine);
				LTQ_STRNCAT(buf, sTemp, sizeof(buf));
				i++;
				sLine[0] = '\0';
				sTemp[0] = '\0';
			}
			snprintf(main_buf, sizeof(main_buf), "%s='%d'\n%s",
				 TAG_SMB_PASSWORD_FILE_LINE, i, buf);
			fclose(fp);
			ifx_SetCfgData(FILE_RC_CONF, PREFIX_SMB_PASSWORD_FILE,
				       1, main_buf);
		}
	}
	// save setting
	if (ifx_flash_write() <= 0) {
		return IFX_FAILURE;
	}

	return IFX_SUCCESS;
}

int ifx_set_system_user(uint32 oper, uint32 id, char_t * user,
			char_t * userPswd)
{
#if 0
	int32 ret = IFX_SUCCESS;
#ifdef IFX_LOG_DEBUG
	IFX_DBG("\nbefore system update\n");
#endif
	if ((ret =
	     ifx_set_system_username_password(oper, id, user,
					      userPswd)) != IFX_SUCCESS) {
		return ret;
	}
#ifdef IFX_LOG_DEBUG
	IFX_DBG("\nfile user updated in system password file\n");
#endif
#endif

	//Save the password file into rc.conf
	{
		const char *fname = "/ramdisk/flash/passwd";
		FILE *fp = NULL;
		char sLine[MAX_FILELINE_LEN];
		char sTemp[MAX_FILELINE_LEN];
		char buf[BUF_SIZE_1K];
		char main_buf[BUF_SIZE_1K];
		int i;

		if ((fp = fopen(fname, "r")) == NULL) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("\ncan't open file %s\n", fname);
#endif
		} else {
			sLine[0] = '\0';
			sTemp[0] = '\0';
			buf[0] = '\0';
			main_buf[0] = '\0';
			i = 0;
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("\nfile user updated in system password file\n");
#endif
			while (fgets(sLine, sizeof(sLine), fp)) {
				sLine[strlen(sLine)-1]='\0';
				snprintf(sTemp, sizeof(sTemp), "%s%d='%s'\n",
					 TAG_PASSWORD_FILE_LINE, i, sLine);
				LTQ_STRNCAT(buf, sTemp, sizeof(buf));
				i++;
				sLine[0] = '\0';
				sTemp[0] = '\0';
			}
			snprintf(main_buf, sizeof(main_buf), "%s='%d'\n%s",
				 TAG_PASSWORD_FILE_LINE, i, buf);
			fclose(fp);
			ifx_SetCfgData(FILE_RC_CONF, PREFIX_PASSWORD_FILE, 1,
				       main_buf);
		}
	}
#ifdef IFX_LOG_DEBUG
	IFX_DBG("\nfile user updated in system password file\n");
#endif
	// save setting
	if (ifx_flash_write() <= 0) {
		return IFX_FAILURE;
	}

	return IFX_SUCCESS;
}

void ifx_set_samba_settings(httpd_t wp, char_t * path, char_t * query)
{
	uint32 operation = IFX_OP_MOD;
	uint32 flags = IFX_F_DEFAULT;
	char_t *pSAMBAEnable;
	LTQ_MAPI_SAMBA_Server smbSrvr;

	// Get values from the samba_settings.asp file
	smbSrvr.iid.cpeId.Id = gatoi(ifx_httpdGetVar(wp, T("cpeId"), T("")));
	smbSrvr.iid.pcpeId.Id = gatoi(ifx_httpdGetVar(wp, T("pcpeId"), T("")));
	pSAMBAEnable = ifx_httpdGetVar(wp, T("SAMBAEnable"), T(""));
	if ((pSAMBAEnable) && (!gstrcmp(pSAMBAEnable, "1"))) {
		smbSrvr.smbEna = 1;
	} else {
		smbSrvr.smbEna = 0;
	}
	gsprintf(smbSrvr.smbName, "%s", ifx_httpdGetVar(wp, T("SSN"), T("")));
	gsprintf(smbSrvr.smbDescr, "%s", ifx_httpdGetVar(wp, T("SSD"), T("")));
	gsprintf(smbSrvr.wrkgrpName, "%s", ifx_httpdGetVar(wp, T("WG"), T("")));

	// Call the mapi interface to set the SAMBA parameters
	if (ifx_set_samba_server(operation, &smbSrvr, flags) != IFX_SUCCESS) {
		ifx_httpdError(wp, 500,
			       T("FAILED TO CONFIGURE SAMBA SERVER !!!"));
		goto IFX_Handler;
	}

	websNextPage(wp);

      IFX_Handler:
	return;
}

int ifx_get_samba_settings(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
	uint32 flags = IFX_F_DEFAULT;
	int32 ret = IFX_SUCCESS;
	LTQ_MAPI_SAMBA_Server smbSrvr;

	// Get name of parameters from the samba_settings.asp file
	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	smbSrvr.iid.config_owner = IFX_WEB;

	// Call the mapi interface to get the SAMBA parameters
	ret = ifx_get_samba_server(&smbSrvr, flags);
	if (ret != IFX_FAILURE) {
		if (!gstrcmp(name, "cpeId")) {
			ifx_httpdWrite(wp, T("%d"), smbSrvr.iid.cpeId.Id);
		} else if (!gstrcmp(name, "pcpeId")) {
			ifx_httpdWrite(wp, T("%d"), smbSrvr.iid.pcpeId.Id);
		} else if (!gstrcmp(name, T("SAMBAEnable"))) {
			if (smbSrvr.smbEna == 1) {
				ifx_httpdWrite(wp, T("checked"));
			} else {
				ifx_httpdWrite(wp, T(""));
			}
		} else if (!gstrcmp(name, T("SSN"))) {
			if (!gstrcmp(smbSrvr.smbName, "0")) {
				ifx_httpdWrite(wp, T(""));
			} else {
				ifx_httpdWrite(wp, T("%s"), smbSrvr.smbName);
			}
		} else if (!gstrcmp(name, T("SSD"))) {
			if (!gstrcmp(smbSrvr.smbDescr, "0")) {
				ifx_httpdWrite(wp, T(""));
			} else {
				ifx_httpdWrite(wp, T("%s"), smbSrvr.smbDescr);
			}
		} else if (!gstrcmp(name, T("WG"))) {
			if (!gstrcmp(smbSrvr.wrkgrpName, "0")) {
				ifx_httpdWrite(wp, T(""));
			} else {
				ifx_httpdWrite(wp, T("%s"), smbSrvr.wrkgrpName);
			}
		}
	}

	return IFX_SUCCESS;
}

void ifx_set_file_share_settings(httpd_t wp, char_t * path, char_t * query)
{
	char_t *fsAction = ifx_httpdGetVar(wp, T("fsAction"), T(""));
	char_t *fsOrder = ifx_httpdGetVar(wp, T("fsOrder"), T(""));
	int32 instCount;
	uint32 operation = IFX_OP_ADD, ret = IFX_SUCCESS;
	uint32 flags = IFX_F_DEFAULT;
	char_t *pUsers;
	char_t *pAL;
	LTQ_MAPI_File_Share fileShare;
	char command[MAX_FILELINE_LEN];

	memset(&fileShare, 0x00, sizeof(fileShare));

	if (!gstrcmp(fsAction, "Add_Config")) {
		if (ifx_get_sec_instance_count
		    (TAG_FILE_SHARE, (uint32 *) & instCount) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       T
				       ("Failed to read File Share instance count"));
			return;
		}
		if (instCount == MAX_SHARES) {
			/* TODO: need to support max 16 distinct share name */
			COPY_TO_STATUS("%s",
				       "<span class=\"textTitle\">File Share configuration failed.</span><br><p>Number of configured File Share has reached maximum limit(16).<br>Please delete existing entry before configuring new one.</p>");
			ifx_httpdRedirect(wp, "err_page.html");
		}
		strcpy(fileShareAction, fsAction);
		//strcpy(fileShareOrder, fsOrder);
		ifx_httpdRedirect(wp, "share_mgmt_settings.asp");
		return;
	} else if (!gstrcmp(fsAction, "Modify_Config")) {
		strcpy(fileShareAction, fsAction);
		strcpy(fileShareOrder, fsOrder);
		ifx_httpdRedirect(wp, "share_mgmt_settings.asp");
		return;
	} else if (!gstrcmp(fsAction, "Add")) {
		operation = IFX_OP_ADD;
		flags = IFX_F_DEFAULT;
	} else if (!gstrcmp(fsAction, "Delete")) {
		operation = IFX_OP_DEL;
		flags = IFX_F_DELETE;
	} else if (!gstrcmp(fsAction, "Modify")) {
		operation = IFX_OP_MOD;
		flags = IFX_F_MODIFY;
	}

	if (operation == IFX_OP_ADD || operation == IFX_OP_MOD) {
		if (operation == IFX_OP_MOD) {
			fileShare.iid.cpeId.Id = gatoi(fsOrder);
			if (ifx_get_file_share(&fileShare, IFX_F_DEFAULT) !=
			    IFX_SUCCESS) {
				ifx_httpdError(wp, 400, T("%s"),
					       "Failed to get previous File Share configuration.");
				return;
			}

			flags = IFX_F_MODIFY;
		}
		// Get values from the samba_settings.asp file
		gsprintf(fileShare.shareName, "%s",
			 ifx_httpdGetVar(wp, T("FSN"), T("")));
		gsprintf(fileShare.folderPath, "%s",
			 ifx_httpdGetVar(wp, T("FP"), T("")));
		pAL = ifx_httpdGetVar(wp, T("AL"), T(""));
		if (!gstrcmp(pAL, "1")) {
			fileShare.rwAccess = 1;
		} else {
			fileShare.rwAccess = 0;
		}
		pUsers = ifx_httpdGetVar(wp, T("Users"), T(""));
		if (!gstrcmp(pUsers, "All")) {
			fileShare.allUsers = 1;
		} else {
			fileShare.allUsers = 0;
			// FIXME: multiple users???
			gsprintf(fileShare.users[0], "%s", pUsers);
		}

		sprintf(fileShare.iid.cpeId.secName, "%s", TAG_FILE_SHARE);
		sprintf(fileShare.iid.pcpeId.secName, "%s", TAG_LAN_MAIN);	//FIXME
		fileShare.iid.config_owner = IFX_WEB;
		fileShare.iid.pcpeId.Id = 1;
		/* validate share folder path */
		sprintf(command, "test -d /mnt/usb%s", fileShare.folderPath);
		if (system(command) != IFX_SUCCESS) {
			COPY_TO_STATUS
			    ("<font class='title'>Error:File Share Configuration failed.</font><br><font class='subtitle'>Folder path '%s' does not exist. Please configure File Share with proper folder path.</font>",
			     fileShare.folderPath);
			ifx_httpdRedirect(wp, "err_page.html");
			return;
		}
	} else if (operation == IFX_OP_DEL) {
		fileShare.iid.cpeId.Id = atoi(fsOrder);
		if (ifx_get_file_share(&fileShare, IFX_F_GET_ANY) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 400, T("%s"),
				       "Failed to get File Share configuration.");
			return;
		}
	}
	// Call the mapi interface to set the SAMBA parameters
	ret = ifx_set_file_share(operation, &fileShare, flags);
	if (ret == IFX_DUPLICATE_ENTRY) {
		COPY_TO_STATUS
		    ("<font class='title'>Error:File Share Configuration failed.</font><br><font class='subtitle'>Either Share '%s' with user '%s' already exist, or Share '%s' exists with folder path other than '%s'. Please configure File Share with another Share Name and/or User Name and/or same folder path.</font>",
		     fileShare.shareName, fileShare.users[0],
		     fileShare.shareName, fileShare.folderPath);
		ifx_httpdRedirect(wp, "err_page.html");
		return;
	} else if (ret != IFX_SUCCESS) {
		ifx_httpdError(wp, 500,
			       T("FAILED TO CONFIGURE FILE SHARE !!!"));
		return;
	}
	//websNextPage(wp);

      IFX_Handler:
	ifx_httpdRedirect(wp, T("share_mgmt.asp"));
	return;
}

int ifx_get_file_share_settings(int eid, httpd_t wp, int argc, char_t ** argv)
{
	LTQ_MAPI_File_Share *fileShare = NULL, *tmpuser = NULL;
	uint32 num_shares;
	int32 i;

	if (ifx_get_all_file_share_entries
	    (&num_shares, &fileShare, IFX_F_GET_ANY) == IFX_SUCCESS) {

		tmpuser = fileShare;

		if (num_shares > 0) {
#if 0
			ifx_httpdWrite(wp,
				       T
				       ("\n<table class=\"tableInfo\" cellspacing=\"1\" cellpadding=\"6\" summary=\"\">"));
			ifx_httpdWrite(wp, T("\n<tr>"));
			ifx_httpdWrite(wp,
				       T
				       ("\n<th class=\"curveLeft\">Share Name</th>"));
			ifx_httpdWrite(wp, T("\n<th>Folder Path</th>"));
			ifx_httpdWrite(wp, T("\n<th>Users</th>"));
			ifx_httpdWrite(wp,
				       T
				       ("\n<th class=\"colInput curveRight\"></th>"));
			ifx_httpdWrite(wp, T("\n</tr>\n"));
#endif				// 0

			for (i = 0; i < num_shares; i++) {
				ifx_httpdWrite(wp,
					       "<input type=\"hidden\" name=\"cpeId%d\" value=\"%d\">",
					       i, fileShare->iid.cpeId.Id);
				ifx_httpdWrite(wp, T("\n<tr>"));
				ifx_httpdWrite(wp,
					       T
					       ("\n<td id=\"share_name%d\">%s</td>"),
					       i, fileShare->shareName);
				ifx_httpdWrite(wp,
					       T
					       ("\n<td id=\"folder_path%d\">%s</td>"),
					       i, fileShare->folderPath);
				ifx_httpdWrite(wp,
					       T
					       ("\n<td id=\"users%d\">%s</td>"),
					       i, fileShare->users[0]);
				if (fileShare->rwAccess == 1)
					ifx_httpdWrite(wp,
						       T
						       ("\n<td id=\"access_lvl%d\">Read-Write</td>"),
						       i);
				else
					ifx_httpdWrite(wp,
						       T
						       ("\n<td id=\"access_lvl%d\">Read-Only</td>"),
						       i);
				ifx_httpdWrite(wp,
					       T
					       ("\n<td><input type=\"radio\" name=\"ClassSelect\" value=\"%d\"></td>"),
					       fileShare->iid.cpeId.Id);
				ifx_httpdWrite(wp, T("\n</tr>\n"));
				fileShare++;
			}
			//              free(fileShare);

#if 0
			ifx_httpdWrite(wp, T("\n</table>"));
#endif				// 0
		}
	}
	IFX_MEM_FREE(tmpuser);
	return IFX_SUCCESS;
}

void ifx_get_file_share_operation(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%s"), fileShareAction);
}

void ifx_get_file_share_info(int eid, httpd_t wp, int argc, char_t ** argv)
{
	LTQ_MAPI_File_Share *fileShare;
	uint32 num_shares;
	int32 i;
	int32 order;

	if (!gstrcmp(fileShareAction, "Modify_Config")) {

		order = atoi(fileShareOrder);
		if (order != 0) {
			if (ifx_get_all_file_share_entries
			    (&num_shares, &fileShare,
			     IFX_F_GET_ANY) == IFX_SUCCESS) {
				if (num_shares > 0) {
					for (i = 0; i < num_shares; i++) {
						if ((fileShare +
						     i)->iid.cpeId.Id ==
						    order) {
							/* Found requsted entry */
							ifx_httpdWrite(wp,
								       T
								       ("\"%s\""),
								       (fileShare
									+
									i)->
								       shareName);
							ifx_httpdWrite(wp,
								       T
								       (",\"%s\""),
								       (fileShare
									+
									i)->
								       folderPath);
							ifx_httpdWrite(wp,
								       T
								       (",\"%d\""),
								       (fileShare
									+
									i)->
								       rwAccess);
							if ((fileShare +
							     i)->allUsers ==
							    1) {
								ifx_httpdWrite
								    (wp,
								     T
								     (",\"All\""));
							} else {
								ifx_httpdWrite
								    (wp,
								     T
								     (",\"%s\""),
								     (fileShare
								      +
								      i)->
								     users[0]);
							}
							ifx_httpdWrite(wp,
								       T
								       (",\"%d\""),
								       order);
							break;
						}
					}
				}
			}
			free(fileShare);
		}
	}
}

#if 0 /* SAMBA User management is now handled by User Accounts Management.
 So removing functions:
	ifx_set_user_settings
	ifx_get_user_info
	ifx_get_user_operation
	ifx_get_user_settings
*/

void ifx_set_user_settings(httpd_t wp, char_t * path, char_t * query)
{
	char_t *fsAction = ifx_httpdGetVar(wp, T("userAction"), T(""));
	char_t *fsOrder = ifx_httpdGetVar(wp, T("userOrder"), T(""));
	int32 instCount;
	uint32 operation = IFX_OP_ADD, ret = IFX_SUCCESS;
	uint32 flags = IFX_F_DEFAULT;
	char_t *pAL;
	LTQ_MAPI_File_User fileUser;

	memset(&fileUser, 0x00, sizeof(fileUser));

	if (!gstrcmp(fsAction, "Add_Config")) {
		if (ifx_get_sec_instance_count
		    (TAG_FILE_USER, (uint32 *) & instCount) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       T
				       ("Failed to read File User instance count"));
			return;
		}
		if (instCount == MAX_USERS) {
			COPY_TO_STATUS("%s",
				       "<span class=\"textTitle\">File User configuration failed.</span><br><p>Number of configured File User has reached maximum limit(8).<br>Please delete existing entry before configuring new one.</p>");
			ifx_httpdRedirect(wp, "err_page.html");
		}
		strcpy(fileUserAction, fsAction);
		//strcpy(fileUserOrder, fsOrder);
		ifx_httpdRedirect(wp, "user_mgmt_settings.asp");
		return;
	} else if (!gstrcmp(fsAction, "Modify_Config")) {
		strcpy(fileUserAction, fsAction);
		strcpy(fileUserOrder, fsOrder);
		ifx_httpdRedirect(wp, "user_mgmt_settings.asp");
		return;
	} else if (!gstrcmp(fsAction, "Add")) {
		operation = IFX_OP_ADD;
		flags = IFX_F_DEFAULT;
	} else if (!gstrcmp(fsAction, "Delete")) {
		operation = IFX_OP_DEL;
		flags = IFX_F_DELETE;
	} else if (!gstrcmp(fsAction, "Modify")) {
		operation = IFX_OP_MOD;
		flags = IFX_F_MODIFY;
	}

	if (operation == IFX_OP_ADD || operation == IFX_OP_MOD) {
		if (operation == IFX_OP_MOD) {
			fileUser.iid.cpeId.Id = gatoi(fsOrder);
			if (ifx_get_fs_usr_act(&fileUser, IFX_F_DEFAULT) !=
			    IFX_SUCCESS) {
				ifx_httpdError(wp, 400, T("%s"),
					       "Failed to get previous File User configuration.");
				return;
			}

			flags = IFX_F_MODIFY;
		}
		// Get values from the user_mgmt_settings.asp file
		gsprintf(fileUser.userName, "%s",
			 ifx_httpdGetVar(wp, T("UN"), T("")));
		gsprintf(fileUser.pwd, "%s",
			 ifx_httpdGetVar(wp, T("PASSWD"), T("")));
		gsprintf(fileUser.shares[0], "%s",
			 ifx_httpdGetVar(wp, T("SN"), T("")));
		pAL = ifx_httpdGetVar(wp, T("AL"), T(""));
		if (!gstrcmp(pAL, "1")) {
			fileUser.rwAccess = 1;
		} else {
			fileUser.rwAccess = 0;
		}

		sprintf(fileUser.iid.cpeId.secName, "%s", TAG_FILE_USER);
		sprintf(fileUser.iid.pcpeId.secName, "%s", TAG_LAN_MAIN);	//FIXME
		fileUser.iid.config_owner = IFX_WEB;
		fileUser.iid.pcpeId.Id = 1;
	} else if (operation == IFX_OP_DEL) {
		fileUser.iid.cpeId.Id = atoi(fsOrder);
		if (ifx_get_fs_usr_act(&fileUser, IFX_F_GET_ANY) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400, T("%s"),
				       "Failed to get File User configuration.");
			return;
		}
	}
	/* verify if the user exists in the share list */
	if (operation != IFX_OP_ADD) {
		LTQ_MAPI_File_Share *fileShare = NULL;
		uint32 num_shares;
		int32 i;

		if (operation == IFX_OP_DEL) {
			if (ifx_get_all_file_share_entries
			    (&num_shares, &fileShare,
			     IFX_F_GET_ANY) == IFX_SUCCESS) {
				if (num_shares > 0) {
					for (i = 0; i < num_shares; i++) {
						if (!strcmp
						    ((fileShare + i)->users[0],
						     fileUser.userName)) {
							/* Found requsted entry */
							COPY_TO_STATUS
							    ("<font class='title'>Error:File User Configuration failed.</font><br><font class='subtitle'>User '%s' exists in the share list. Please delete all the File share with the user first.</font>",
							     fileUser.userName);
							ifx_httpdRedirect(wp,
									  "err_page.html");
							free(fileShare);
							return;
						}
					}
					//      free(fileShare);
				}
			}
		} else if (operation == IFX_OP_MOD && fileUser.rwAccess == 0) {
			if (ifx_get_all_file_share_entries
			    (&num_shares, &fileShare,
			     IFX_F_GET_ANY) == IFX_SUCCESS) {
				if (num_shares > 0) {
					for (i = 0; i < num_shares; i++) {
						if (!strcmp
						    ((fileShare + i)->users[0],
						     fileUser.userName)
						    && (fileShare +
							i)->rwAccess == 1) {
							/* Found requsted entry */
							COPY_TO_STATUS
							    ("<font class='title'>Error:File User Configuration failed.</font><br><font class='subtitle'>User '%s' exists in the share list with RW permission. Please delete all the RW File share with the user first.</font>",
							     fileUser.userName);
							ifx_httpdRedirect(wp,
									  "err_page.html");
							free(fileShare);
							return;
						}
					}
					//      free(fileShare);
				}
			}
		}
		IFX_MEM_FREE(fileShare);
	}
	// Call the mapi interface to set the SAMBA parameters
	ret = ifx_set_fs_usr_act(operation, &fileUser, flags);
	if (ret == IFX_DUPLICATE_ENTRY) {
		COPY_TO_STATUS
		    ("<font class='title'>Error:File User Configuration failed.</font><br><font class='subtitle'>User '%s' already exist. Please configure File User with another User Name.</font>",
		     fileUser.userName);
		ifx_httpdRedirect(wp, "err_page.html");
		return;
	} else if (ret != IFX_SUCCESS) {
		ifx_httpdError(wp, 500, T("FAILED TO CONFIGURE FILE USER !!!"));
		return;
	}
#ifdef IFX_LOG_DEBUG
	IFX_DBG("\nfile user updated in system password file\n");
#endif

	ret =
	    ifx_set_system_user(operation, fileUser.iid.cpeId.Id,
				fileUser.userName, fileUser.pwd);
	if (ret == IFX_DUPLICATE_ENTRY) {
		COPY_TO_STATUS
		    ("<font class='title'>Error:File User Configuration failed.</font><br><font class='subtitle'>User '%s' already exist. Please configure File User with another User Name.</font>",
		     fileUser.userName);
		ifx_httpdRedirect(wp, "err_page.html");
		return;
	} else if (ret != IFX_SUCCESS) {
		ifx_httpdError(wp, 500,
			       T("FAILED TO CONFIGURE SYSTEM USER !!!"));
		return;
	}
#ifdef IFX_LOG_DEBUG
	IFX_DBG("\nfile user updated in system password file\n");
#endif

	ret = ifx_set_smb_users();
	if (ret != IFX_SUCCESS) {
		ifx_httpdError(wp, 500, T("FAILED TO CONFIGURE FILE USER !!!"));
		return;
	}
#ifdef IFX_LOG_DEBUG
	IFX_DBG("\nfile user updated in rc.conf\n");
#endif

	//websNextPage(wp);

      IFX_Handler:
	ifx_httpdRedirect(wp, T("user_mgmt.asp"));
	return;
}

int ifx_get_user_settings(int eid, httpd_t wp, int argc, char_t ** argv)
{
	LTQ_MAPI_File_User *fileUser = NULL, *tmpuser = NULL;
	uint32 num_users;
	int32 i;

	if (ifx_get_all_fs_usr_act_entries(&num_users, &fileUser, IFX_F_GET_ANY)
	    == IFX_SUCCESS) {

		tmpuser = fileUser;

		if (num_users > 0) {

			for (i = 0; i < num_users; i++) {
				ifx_httpdWrite(wp,
					       "<input type=\"hidden\" name=\"cpeId%d\" value=\"%d\">",
					       i, fileUser->iid.cpeId.Id);
				ifx_httpdWrite(wp, T("\n<tr>"));
				ifx_httpdWrite(wp,
					       T
					       ("\n<td id=\"user_name%d\">%s</td>"),
					       i, fileUser->userName);
				ifx_httpdWrite(wp,
					       T
					       ("\n<td id=\"share_name%d\">%s</td>"),
					       i, fileUser->shares[0]);
				if (fileUser->rwAccess == 1)
					ifx_httpdWrite(wp,
						       T
						       ("\n<td id=\"access_lvl%d\">Read-Write</td>"),
						       i);
				else
					ifx_httpdWrite(wp,
						       T
						       ("\n<td id=\"access_lvl%d\">Read-Only</td>"),
						       i);
				ifx_httpdWrite(wp,
					       T
					       ("\n<td><input type=\"radio\" name=\"ClassSelect\" value=\"%d\"></td>"),
					       fileUser->iid.cpeId.Id);
				ifx_httpdWrite(wp, T("\n</tr>\n"));
				fileUser++;
			}
		}
	}

	IFX_MEM_FREE(tmpuser);
	return IFX_SUCCESS;
}

void ifx_get_user_operation(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%s"), fileUserAction);
}

void ifx_get_user_info(int eid, httpd_t wp, int argc, char_t ** argv)
{
	LTQ_MAPI_File_User *fileUser;
	uint32 num_users;
	int32 i;
	int32 order;

	if (!gstrcmp(fileUserAction, "Modify_Config")) {

		order = atoi(fileUserOrder);
		if (order != 0) {
			if (ifx_get_all_fs_usr_act_entries
			    (&num_users, &fileUser,
			     IFX_F_GET_ANY) == IFX_SUCCESS) {
				if (num_users > 0) {
					for (i = 0; i < num_users; i++) {
						if ((fileUser +
						     i)->iid.cpeId.Id ==
						    order) {
							/* Found requsted entry */
							ifx_httpdWrite(wp,
								       T
								       ("\"%s\""),
								       (fileUser
									+
									i)->
								       userName);
							ifx_httpdWrite(wp,
								       T
								       (",\"%s\""),
								       (fileUser
									+
									i)->
								       pwd);
							ifx_httpdWrite(wp,
								       T
								       (",\"%s\""),
								       (fileUser
									+
									i)->
								       shares
								       [0]);
							ifx_httpdWrite(wp,
								       T
								       (",\"%d\""),
								       (fileUser
									+
									i)->
								       rwAccess);
							ifx_httpdWrite(wp,
								       T
								       (",\"%d\""),
								       order);
							break;
						}
					}
					//free(fileUser);
				}
			}
			free(fileUser);
		}
	}
}

#endif /* ! if 0 */

int ifx_get_file_users(int eid, httpd_t wp, int argc, char_t ** argv)
{
	//char_t *userType;
	//uint32 num_users;
	//int32 i;

///////////////////
	user_obj_t *users = NULL;
	int32   i = 0, count = 0; //, users_count = 0;
	
//	if (ifx_httpd_parse_args(argc, argv, T("%s"), &userType) < 1) {
//		ifx_httpdError(wp, 400, T("Insufficient args\n"));
//		return -1;
//	}

	if(mapi_get_all_user_obj_details(&count, &users, IFX_F_DEFAULT) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] failed to get user accounts details", __FUNCTION__, __LINE__);
#endif
	}
	else {
		for(i=0; i<count ;i++) {
			if ((users + i)->fileShareAccess > 1) {
				ifx_httpdWrite(wp,T("<option value=\'%s\'>%s</option>"), (users + i)->username, (users + i)->username);
			}
			//	users_count++;
		}
		IFX_MEM_FREE(users);
	}

	return IFX_SUCCESS;
}

#endif				/* CONFIG_PACKAGE_samba3 */
