//#include <sys/syslog.h>
#include <ifx_emf.h>
#include "ifx_httpd_method.h"
//#include <signal.h>
//#include <unistd.h>
//#include <sys/types.h>
//#include <sys/wait.h>
//#include <ifx_common.h>
#include "./ifx_amazon_cgi.h"
//#include "./ifx_amazon_cgi_getFunctions.h"
//#include "ifx_snmp_api.h"
//#include "ifx_api_ipt_common.h"
//#include <sys/ioctl.h>
#include "./ifx_cgi_common.h"

extern int ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);
extern int ifx_get_wan_vcc_state(char *vcChannel);
extern int ifx_find_vc_channel(int type, char_t * pVPIChannel,
			       char_t * pVCIChannel);
extern void websNextPage(httpd_t wp);
#ifdef CONFIG_PACKAGE_IFX_OAM
#if 1
int ifx_oam_f5_ping(int vpi, int vci, char scope, int ping_timeout,
		    int num_cells_tx, int *num_cells_rx, int *max_resp_time,
		    int *min_resp_time, int *avg_resp_time);
int ifx_oam_f4_ping(int vpi, char scope, int ping_timeout, int num_cells_tx, int *num_cells_rx, int *max_resp_time, int *min_resp_time, int *avg_resp_time);
#endif
int ifx_oam_channel_operation(int type, int oper, char_t * pVPIChannel,
			      char_t * pVCIChannel, char_t * pData);
void ifx_set_adsl_oamconfig(httpd_t wp, char_t * path, char_t * query);
#endif				//CONFIG_PACKAGE_IFX_OAM
void ifx_set_adsl_vcconfig(httpd_t wp, char_t * path, char_t * query);
#if defined(CONFIG_PACKAGE_IFX_OAM) || defined(CONFIG_FEATURE_IFX_OAM_FULL) || defined(CONFIG_FEATURE_IFX_OAM_F5_LOOPBACK)
int ifx_get_ADSLOAM_List(int eid, httpd_t wp, int argc, char_t ** argv);
#endif
int ifx_get_ADSLVcConfig(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_ADSLVcChannel_List(int eid, httpd_t wp, int argc, char_t ** argv);

extern int mapi_set_vlan_ch_entry(int32 operation, vlan_ch_cfg_t * entry,
				  uint32 flags);
char vpivci_selected[10];
extern char_t *status_str, *oam_ping_res;
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
extern int ltq_cgi_set_autodetect_config(httpd_t wp, char *layer);
#endif
int ifx_find_vc_channel(int type, char_t * pVPIChannel, char_t * pVCIChannel)
{
	int32 i = 0, count = 0, num_entries = 0;
	ATM_VCC_INFO *vcc_array = NULL;

	if (ifx_get_all_vcc_info(&num_entries, &vcc_array, IFX_F_GET_ANY) !=
	    IFX_SUCCESS) {
		return 0;
	}

	count = 0;
	if ((num_entries > 0) && (num_entries < 32767))
		for (i = 0; i < num_entries; i++) {
			if (((vcc_array + i)->vc.pvc.vpi == atoi(pVPIChannel))) {
				if ((type == 4)
				    || (type == 5
					&& ((vcc_array + i)->vc.pvc.vci ==
					    atoi(pVCIChannel)))) {
					count++;
				}
			}
		}

	IFX_MEM_FREE(vcc_array)
	    return count;
}

#ifdef CONFIG_PACKAGE_IFX_OAM
int ifx_oam_channel_operation(int type, int oper, char_t * pVPIChannel,
			      char_t * pVCIChannel, char_t * pData)
{
	char_t tag[MAX_FILELINE_LEN];
	char_t command[MAX_FILELINE_LEN];
	int current_idx = 0;
	char_t sValue[MAX_FILELINE_LEN], sBuf[MAX_FILELINE_LEN * MAX_VCCs * 2];
	int i, nSelIdx, nFound = 0;

	switch (type) {
	case 4:
		sprintf(tag, "%s", TAG_ADSL_OAM_F4);
		break;
	case 5:
		sprintf(tag, "%s", TAG_ADSL_OAM_F5);
		break;
	default:
		return -1;
		break;
	}

	if (oper == 0
	    && ifx_find_vc_channel(type, pVPIChannel, pVCIChannel) > 0)
		return 0;

	sprintf(command, "%sCount", tag);
	sBuf[0] = '\0';
	if (ifx_GetCfgData(FILE_RC_CONF, tag, command, sValue) == 0) {
		return -1;
	}
	sprintf(command, "%sCount", tag);
	nSelIdx = gatoi(sValue);

	if (oper == 0)
		sprintf(sBuf, "%s=%d\n", command, nSelIdx - 1);
	else if (oper == 1)
		sprintf(sBuf, "%s=%d\n", command, nSelIdx + 1);
	else
		sprintf(sBuf, "%s=%d\n", command, nSelIdx);
	for (i = 0; i < nSelIdx; i++) {
		char *p;
		gsprintf(command, "%s%d", tag, i);
		if (ifx_GetCfgData(FILE_RC_CONF, tag, command, sValue) == 0) {
			return -1;
		}
		p = strchr(sValue, '_');
		if (p && p - sValue == strlen(pVPIChannel)
		    && gstrncmp(pVPIChannel, sValue, p - sValue) == 0) {
			if (type == 5) {
				char *prev_p;
				prev_p = p + 1;
				p = strchr(prev_p, '_');
				if (p && p - prev_p == strlen(pVCIChannel)
				    && gstrncmp(pVCIChannel, prev_p,
						p - prev_p) == 0) {
					// do nothing
				} else {
					snprintf(command, sizeof(command),
						 "%s%d=%s\n", tag,
						 current_idx++, sValue);
					LTQ_STRNCAT(sBuf, command, sizeof(sBuf));
					continue;
				}
			}
			nFound = 1;
			// found same channel data
			switch (oper) {
				// del
			case 0:
				continue;
				break;
				// add
			case 1:
				return 1;
				break;
			case 2:
				gsprintf(command, "%s%d=%s\n", tag,
					 current_idx++, pData);
				break;
			}
		} else {
			snprintf(command,MAX_FILELINE_LEN, "%s%d=%s\n", tag, current_idx++,
				 sValue);
		}
		LTQ_STRNCAT(sBuf, command, sizeof(sBuf));
	}
	if (oper == 1) {
		if (type == 4)
			gsprintf(command, "%s%d=%s_0_0_3_600\n", tag,
				 current_idx++, pVPIChannel);
		else if (type == 5)
			gsprintf(command, "%s%d=%s_%s_0_0_3_600\n", tag,
				 current_idx++, pVPIChannel, pVCIChannel);
		LTQ_STRNCAT(sBuf, command, sizeof(sBuf));
	} else if (oper == 0 && !nFound) {
		return -1;
	}

	ifx_SetCfgData(FILE_RC_CONF, tag, 1, sBuf);
	return 0;

}

void ifx_set_adsl_oamconfig(httpd_t wp, char_t * path, char_t * query)
{
	char_t sSettingValue[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN],
	sBuf[MAX_FILELINE_LEN];
	char_t command[MAX_FILELINE_LEN];
	char_t *pSubmit_Action = ifx_httpdGetVar(wp, T("submit_action"), T(""));
	char_t prefix[MAX_FILELINE_LEN];
	char_t tag[MAX_FILELINE_LEN];
	char_t *pCCheck = NULL, *pCCOpt = NULL, *pTTime = NULL;
	char_t *pLoopback = NULL, *pVPIChannel = NULL, *pVCIChannel = NULL;
	char_t bOAMEnable = 0;
	char_t bTestF5Lb = 0, bTestF4Lb = 0;;
	int32 i = 0, num_entries = 0, type = 0, ret = 0;
	char_t *pPingTimeout = NULL, *pCellsTx = NULL;

	WAN_ATMF5_LOOP_DIAGNOSTICS atmf5_diag, *f_atmf5_diag = NULL;

	a_assert(wp);

	memset(&atmf5_diag, 0x00, sizeof(atmf5_diag));
	memset(sSettingValue, 0x00, sizeof(sSettingValue));
	memset(sValue, 0x00, sizeof(sValue));
	memset(sBuf, 0x00, sizeof(sBuf));
	memset(command, 0x00, sizeof(command));
	memset(prefix, 0x00, sizeof(prefix));
	sprintf(prefix, "OAM");

	if (!gstrcmp(pSubmit_Action, "submit")) {
		pCCheck = ifx_httpdGetVar(wp, "OAM_ENABLE", T(""));
		if (!gstrcmp(pCCheck, "1")) {
			gsprintf(sValue, "OAM_ENABLE=\"1\"\n");
			bOAMEnable = 1;
		} else {
			gsprintf(sValue, "OAM_ENABLE=\"0\"\n");
			bOAMEnable = 0;
		}
		ifx_SetCfgData(FILE_RC_CONF, TAG_ADSL_OAM, 1, sValue);
		//Runtime Change
		if (bOAMEnable) {
			system(SERVICE_OAM_START);
		} else {
			system(SERVICE_OAM_STOP);
		}
		goto IFX_Handler;
	} else if (!gstrcmp(pSubmit_Action, "modifyF4")) {
		sprintf(tag, "%s", TAG_ADSL_OAM_F4);
		type = 4;
	} else if (!gstrcmp(pSubmit_Action, "modifyF5")) {
		sprintf(tag, "%s", TAG_ADSL_OAM_F5);
		type = 5;
		sprintf(command, "%s_VCI_CHANNEL", prefix);
		pVCIChannel = ifx_httpdGetVar(wp, command, T(""));
	} else if (!gstrcmp(pSubmit_Action, "testF5")) {
		sprintf(tag, "%s", TAG_ADSL_OAM_F5);
		type = 5;
		sprintf(command, "%s_VCI_CHANNEL", prefix);
		pVCIChannel = ifx_httpdGetVar(wp, command, T(""));
		bTestF5Lb = 1;
	} else if (!gstrcmp(pSubmit_Action, "testF4")) {
		sprintf(tag, "%s", TAG_ADSL_OAM_F4);
		type = 4;
		sprintf(command, "%s_VCI_CHANNEL", prefix);
		pVCIChannel = ifx_httpdGetVar(wp, command, T(""));
		bTestF4Lb = 1;
	} else {
		ifx_httpdError(wp, 500, "Insufficient data for Configuration");
	}

	sprintf(command, "%s_VPI_CHANNEL", prefix);
	pVPIChannel = ifx_httpdGetVar(wp, command, T(""));
	sprintf(command, "%s_LOOPBACK", prefix);
	pLoopback = ifx_httpdGetVar(wp, command, T(""));
	sprintf(command, "%s_CCheck", prefix);
	pCCheck = ifx_httpdGetVar(wp, command, T(""));
	sprintf(command, "%s_CC_OPT", prefix);
	pCCOpt = ifx_httpdGetVar(wp, command, T(""));
	sprintf(command, "%s_TIME", prefix);
	pTTime = ifx_httpdGetVar(wp, command, T(""));
	atmf5_diag.vpi = atoi(pVPIChannel);
	atmf5_diag.loopback = atoi(pLoopback);
	atmf5_diag.cc_check = atoi(pCCheck);
	atmf5_diag.cc_check_opt = atoi(pCCOpt);
	atmf5_diag.ping_timeout = atoi(pTTime);
	
	if (type == 5 || type == 4) {
		atmf5_diag.vci = atoi(pVCIChannel);
		pPingTimeout = ifx_httpdGetVar(wp, T("OAM_TIME"), T(""));
		pCellsTx = ifx_httpdGetVar(wp, T("OAM_TX_CELLS"), T(""));

		atmf5_diag.ping_timeout = atoi(pPingTimeout);
		atmf5_diag.oam_pings = atoi(pCellsTx);
	}

	if (type == 4 && bTestF4Lb == 0) {
		gsprintf(sSettingValue, "%s_", pVPIChannel);

		if (!gstrcmp(pLoopback, "1")) {
			gsprintf(command, "1_");
		} else {
			gsprintf(command, "0_");
		}

		strcat(sSettingValue, command);
		if (!gstrcmp(pCCheck, "1")) {
			gsprintf(command, "1_");
		} else {
			gsprintf(command, "0_");
		}

		strcat(sSettingValue, command);
		gsprintf(command, "%s_%s", pCCOpt, pTTime);
		strcat(sSettingValue, command);

		//Runtime Change
		system(SERVICE_OAM_STOP);

		ifx_oam_channel_operation(type, 2, pVPIChannel, pVCIChannel,
					  sSettingValue);

		//Runtime Change
		system(SERVICE_OAM_START);
	} else if (type == 5 || type == 4) {
		if (bTestF5Lb == 0 && bTestF4Lb == 0)
			gsprintf(sSettingValue, "%s_%s_", pVPIChannel,
				 pVCIChannel);
		else {
			int vpi = atoi(pVPIChannel);
			int vci = atoi(pVCIChannel);
			unsigned int cells_tx, cells_rx, min_resp, max_resp,
			    avg_resp, ping_timeout;
			char_t *testOwner = NULL;

			testOwner = ifx_httpdGetVar(wp, T("testOwner"), "");

			ping_timeout = atoi(pPingTimeout);
			cells_tx = atoi(pCellsTx);
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("In Function [%s:%d] : calling with vpi [%d], vci [%d], scope [4], ping_timeout [%d], "
			     "repetitions [%d], success_count [%d], max_resp [%d], min_resp [%d], avg_resp [%d]",
			     __FUNCTION__, __LINE__, vpi, vci, ping_timeout,
			     cells_tx, cells_rx, min_resp, max_resp, avg_resp);
#endif
			if(type == 5) { 
				ret = ifx_oam_f5_ping(vpi, vci, 4, ping_timeout, cells_tx,(int *)&cells_rx, (int *)&min_resp,(int *)&max_resp, (int *)&avg_resp);
			} 
			else {
				ret = ifx_oam_f4_ping(vpi, 4, ping_timeout, cells_tx,(int *)&cells_rx, (int *)&min_resp,(int *)&max_resp, (int *)&avg_resp);
			}
			if (testOwner != NULL && !gstrcmp(testOwner, "CLI")) {
				if (type == 5) {
				ifx_httpdWrite(wp, T("<center>%s<br></center>"),
					       (ret ==
						0) ? "OAM F5 Ping OK!" :
					       "OAM F5 Ping Failed!");
				ifx_httpdWrite(wp,T("<center>OAM F5 VPI=%d, VCI=%d loopback test Results!!! <br></center>"),vpi, vci);

						}
				else {
				ifx_httpdWrite(wp, T("<center>%s<br></center>"),(ret ==0) ? "OAM F4 Ping OK!" :"OAM Ping F4 Failed!");
				ifx_httpdWrite(wp,T("<center>OAM F4 VPI=%d, loopback test Results!!! <br></center>"),vpi);
				}
				ifx_httpdWrite(wp,
					       T
					       ("<center>Cells Tx=%d -> Cells Rx OK=%d, Cells Not Rx=%d <br></center>"),
					       cells_tx, cells_rx,
					       cells_tx - cells_rx);
				ifx_httpdWrite(wp,
					       T
					       ("<center>Max Resp Time=%d ; Min Resp Time=%d ; Avg Resp Time=%d millisecs <br></center>"),
					       max_resp, min_resp, avg_resp);
			} else {
				if(type == 5) {

				COPY_TO_STATUS
				    ("<span class=\"textTitle\">%s</span><div align=\"center\"><table class=\"tableinfo\" ><tr><td>VPI/VCI</td><td id=\"oam_vpi_vci\">%d/%d</td></tr><tr><td width=\"50%%\">Cells Tx</td><td id=\"oam_cell_tx\">%d</td></tr><tr><td>Cells Rx</td><td id=\"oam_cell_rx\">%d</td></tr><tr><td>Cells Not Rx</td><td id=\"oam_cell_not_rx\">%d</td></tr><tr><td>Max Resp Time</td><td id=\"oam_max_resp_time\">%d</td></tr><tr><td>Min Resp Time</td><td id=\"oam_min_resp_time\">%d</td></tr><tr><td>Avg Resp Time(millisecs)</td><td id=\"oam_avg_time\">%d</td></tr></table></div> ",
				     (ret ==
				      0) ? "OAM F5 Ping Successful!" :
				     "OAM F5 Ping Failed!", vpi, vci, cells_tx,
				     cells_rx, cells_tx - cells_rx, max_resp,
				     min_resp, avg_resp);

				ifx_httpdRedirect(wp, T("err_page.html"));
				}
				else {
				COPY_TO_STATUS
				    ("<span class=\"textTitle\">%s</span><div align=\"center\"><table class=\"tableinfo\" ><tr><td>VPI</td><td id=\"oam_vpi_vci\">%d</td></tr><tr><td width=\"50%%\">Cells Tx</td><td id=\"oam_cell_tx\">%d</td></tr><tr><td>Cells Rx</td><td id=\"oam_cell_rx\">%d</td></tr><tr><td>Cells Not Rx</td><td id=\"oam_cell_not_rx\">%d</td></tr><tr><td>Max Resp Time</td><td id=\"oam_max_resp_time\">%d</td></tr><tr><td>Min Resp Time</td><td id=\"oam_min_resp_time\">%d</td></tr><tr><td>Avg Resp Time(millisecs)</td><td id=\"oam_avg_time\">%d</td></tr></table></div> ",
				     (ret ==
				      0) ? "OAM F4 Ping Successful!" :
				     "OAM F4 Ping Failed!", vpi, cells_tx,
				     cells_rx, cells_tx - cells_rx, max_resp,
				     min_resp, avg_resp);
				ifx_httpdRedirect(wp, T("err_page.html"));
	
				}
			}
			return;
		}
		if (ifx_get_all_wan_atmf5_loop_diagnostics
		    (&num_entries, &f_atmf5_diag,
		     IFX_F_GET_ANY) == IFX_SUCCESS) {
			for (i = 0; i < num_entries; i++) {
				if (((f_atmf5_diag + i)->vpi == atmf5_diag.vpi)
				    && ((f_atmf5_diag + i)->vci ==
					atmf5_diag.vci)) {
					if ((f_atmf5_diag + i)->f_enable ==
					    IFX_DISABLED) {
						ifx_httpdError(wp, 400,
							       "Error : oam f5 entry is currently disabled, cannot do enable !!");
						IFX_MEM_FREE(f_atmf5_diag)
						    return;
					}
					atmf5_diag.iid =
					    (f_atmf5_diag + i)->iid;
					break;
				}
			}
		}

		atmf5_diag.scope = '0';
		atmf5_diag.f_enable = IFX_ENABLED;
		atmf5_diag.diagnostic_state = WAN_DIAG_START_DIAGNOSING;

		if (ifx_set_atmf5_loop_diagnostics
		    (IFX_OP_MOD, &atmf5_diag, IFX_F_MODIFY) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to modify the f5 parameters for the vc [%d/%d]",
				       atmf5_diag.vpi, atmf5_diag.vci);
			IFX_MEM_FREE(f_atmf5_diag)
			    return;
		}
	}

      IFX_Handler:
	IFX_MEM_FREE(f_atmf5_diag)
	    websNextPage(wp);
}
#endif				// CONFIG_PACKAGE_IFX_OAM

void ifx_set_adsl_vcconfig(httpd_t wp, char_t * path, char_t * query)
{
				char_t sValue[MAX_FILELINE_LEN], sBuf[MAX_FILELINE_LEN],baseifname[MAX_FILELINE_LEN];
				char *dup_vc_err =
								"<font class='title'>Error:VC Configuration failed.</font><br><font class='subtitle'>VPI/VCI with value [ %d/%d ] already exist. Please configure VC Channel with another VPI/VCI value.</font>";
				char_t *pSubmit_Action = ifx_httpdGetVar(wp, T("submit_action"), T(""));
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
	if(pSubmit_Action != NULL)
		if (!gstrcmp(pSubmit_Action, T("ads_update"))) {
			if(ltq_cgi_set_autodetect_config(wp, "l2") == IFX_SUCCESS){
				ifx_httpdRedirect(wp, T("atm_channel_config.asp"));	
			}
			return;
	}
#endif
				int operation = 0;
				int ret = IFX_SUCCESS, i = 0;
				int status = 0, Qs_Status = 0, outFlag = IFX_F_DEFAULT, atmf5_count = 0, f_vpi = 0, f_vci = 0;
				uint32 flags = IFX_F_DEFAULT;
				char_t *Enc_mode = NULL;
				char_t *vcSetting_ch;
				char_t *QoS_mode = NULL;
				char_t *peakCell = NULL;
				char_t *mininumCell = NULL;
				char_t *sustainableCell = NULL;
				char_t *maximumBurst = NULL;
				char_t *cellDelayVarition = NULL;
				char8 *retVal = NULL;
				char8 *delim = "/\n";
				char8 *vpi_channel = NULL, *vci_channel = NULL;
				char_t *vpivci_select = NULL;
				char8 *linkType = NULL;
				char_t *pNewVcc = NULL;
				vcSetting_ch = (char_t *) malloc(sizeof(char_t) * (MAX_NAME_SIZE));
                                if (!vcSetting_ch)
                                     goto IFX_Handler;

				char_t *vcc_channel_name = NULL;

				char_t *remove_num = NULL;

#ifdef  CONFIG_FEATURE_PTM_WAN_SUPPORT
				PTM_CH_CFG ptm_ch;
				memset(&ptm_ch, 0x00, sizeof(ptm_ch));
#endif
				WAN_ATMF5_LOOP_DIAGNOSTICS atmf5_diag;
				ATM_VCC_INFO vcc;
				WAN_CONN_DEV wan_connDev;
#ifdef CONFIG_FEATURE_ETH_WAN_SUPPORT
				ETH_CH_CFG eth_ch;
				memset(&eth_ch, 0x00, sizeof(eth_ch));
#endif
				vlan_ch_cfg_t vlan_ch;
				memset(&vlan_ch, 0x00, sizeof(vlan_ch));
				a_assert(wp);
				sValue[0] = '\0';
				sBuf[0] = '\0';
				memset(&vcc, 0x00, sizeof(vcc));
				memset(&wan_connDev, 0x00, sizeof(wan_connDev));
				memset(&atmf5_diag, 0x00, sizeof(atmf5_diag));
#ifdef IFX_LOG_DEBUG
				IFX_DBG("inside [%s] !!\n", __FUNCTION__);
#endif
				status = gatoi(ifx_httpdGetVar(wp, T("vpivci_status"), T("")));
				Qs_Status = gatoi(ifx_httpdGetVar(wp, T("qs_status"), T("")));

				if (status == 1) {
								vpivci_select = ifx_httpdGetVar(wp, T("vpivci_value"), T(""));
								strcpy(vpivci_selected, vpivci_select);
								websNextPage(wp);
				} else {
								if (!gstrcmp(pSubmit_Action, T("addVPIVCI"))) {
												operation = IFX_OP_ADD;
												flags = IFX_F_INT_ADD;

												// operation : 1:add channel  2:delete channel
												Enc_mode = ifx_httpdGetVar(wp, T("CapMode"), T(""));
												vcc.encap = gatoi(Enc_mode);
												pNewVcc = ifx_httpdGetVar(wp, T("vcSetting"), T(""));
												strcpy(vcSetting_ch, pNewVcc);

												QoS_mode = ifx_httpdGetVar(wp, T("QoSMode"), T(""));

												switch (atoi(QoS_mode)) {
																case 0:	// From WEB : UBR
																				vcc.txtp.traffic_class = ATM_QOS_UBR;
																				break;
																case 1:	// From WEB : CBR
																				vcc.txtp.traffic_class = ATM_QOS_CBR;
																				break;
																case 2:	// From WEB : NRT_VBR
																				vcc.txtp.traffic_class = ATM_QOS_NRT_VBR;
																				break;
																case 3:	// From WEB : RT_VBR
																				vcc.txtp.traffic_class = ATM_QOS_RT_VBR;
																				break;
																case 4:	// From WEB : UBR+
																				vcc.txtp.traffic_class = ATM_QOS_UBR_PLUS;
																				break;
																default:
																				vcc.txtp.traffic_class = ATM_QOS_UBR;
												}

												peakCell = ifx_httpdGetVar(wp, T("peakCell"), T(""));
												vcc_channel_name =
																ifx_httpdGetVar(wp, T("vc_channel_name"), T(""));
												mininumCell =
																ifx_httpdGetVar(wp, T("mininumCell"), T(""));
												sustainableCell =
																ifx_httpdGetVar(wp, T("sustainableCell"), T(""));
												maximumBurst =
																ifx_httpdGetVar(wp, T("maximumBurst"), T(""));
												cellDelayVarition =
																ifx_httpdGetVar(wp, T("cellDelayVarition"), T(""));
												linkType = ifx_httpdGetVar(wp, "linkType", "");
			IFX_ID iid;
			if( ifx_check_for_available_bandwidth(iid,atoi(peakCell),atoi(QoS_mode)) != IFX_SUCCESS)
			{
				COPY_TO_STATUS("Configured PCR exceeds max. allowed bandwidth -> Connection creation Failed!");
				ifx_httpdRedirect(wp, "err_page.html");
				goto IFX_Handler;
			}
#ifdef IFX_LOG_DEBUG
												IFX_DBG
																("\n\n In Function [%s] : #### linkType --> [%s]!!\n\n",
																 __FUNCTION__, linkType);
#endif
												gstrcpy(vcc.vcc_ch_name, vcc_channel_name);

												if (!Enc_mode[0] || !vcSetting_ch[0] || !QoS_mode[0]) {
  IFX_MEM_FREE( vcSetting_ch );
																ifx_httpdError(wp, 500,
																								"Insufficient data for VC Configuration");
																return;
												}

												switch (vcc.txtp.traffic_class) {
																case ATM_QOS_RT_VBR:
																case ATM_QOS_NRT_VBR:
																				if (sustainableCell[0]) {
																								vcc.txtp.scr = gatoi(sustainableCell);
																				}
																				if (maximumBurst[0]) {
																								vcc.txtp.mbs = gatoi(maximumBurst);
																				}
																case ATM_QOS_UBR:
																case ATM_QOS_CBR:
																				if (peakCell[0]) {
																								vcc.txtp.max_pcr = gatoi(peakCell);
																				}
																				if (cellDelayVarition[0]) {
																								vcc.txtp.cdv = gatoi(cellDelayVarition);
																				}
																case ATM_QOS_UBR_PLUS:
																				if (peakCell[0]) {
																								vcc.txtp.max_pcr = gatoi(peakCell);
																				}
																				if (cellDelayVarition[0]) {
																								vcc.txtp.cdv = gatoi(cellDelayVarition);
																				}
																				if (mininumCell[0]) {
																								vcc.txtp.min_pcr = gatoi(mininumCell);
																				}
																default:
																				break;
												}
												vpi_channel = strtok(vcSetting_ch, delim);
												vci_channel = strtok(NULL, delim);
												if (vci_channel)
																vcc.vc.pvc.vci = gatoi(vci_channel);
												if (vpi_channel)
																vcc.vc.pvc.vpi = gatoi(vpi_channel);
												vcc.f_enable = IFX_ENABLED;

												vcc.type = atoi(linkType);

								} else if (!gstrcmp(pSubmit_Action, T("delVPIVCI"))) {

												//manohar
												int num = 0, j;
												char_t sWAN_VCC[10];
												char_t remove[15];
												operation = IFX_OP_DEL;
												flags = IFX_F_DELETE;
												ATM_VCC_INFO *vcc1 = NULL;
												if (ifx_get_all_vcc_info(&num, &vcc1, IFX_F_DEFAULT) !=
																				IFX_SUCCESS) {
																ifx_httpdError(wp, 200,
																								T
																								("Failed to get the configured wan connections"));
																IFX_MEM_FREE(vcc1);
																return;
												}
												for (j = 0; j < num; j++) {
																snprintf(remove, sizeof(remove), "remove%d",
																								(vcc1 + j)->iid.cpeId.Id);
																remove_num = NULL;
																remove_num =
																				ifx_httpdGetVar(wp, T(remove), T(""));
																if (!gstrcmp(remove_num, "1")) {
																				snprintf(sWAN_VCC, sizeof(sWAN_VCC),
																												"%d/%d",
																												(vcc1 + j)->vc.pvc.vpi,
																												(vcc1 + j)->vc.pvc.vci);
																				vpivci_select = sWAN_VCC;
																				snprintf(vpivci_selected,
																												sizeof(vpivci_selected), "%s",
																												sWAN_VCC);
																				/* Check if the vc channel specified exists in the adsl_vcchannel section */
																				if ((ret =
																																ifx_ret_substr_from_distfield
																																(FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
																																 "vcc", vpivci_selected,
																																 &retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
																								IFX_DBG
																												("\n\n In FUnction [%s] : Error--> Trying to get the wan index for vcc [%s] !!\n\n",
																												 __FUNCTION__,
																												 vpivci_selected);
#endif
																								goto IFX_Handler;
																				}
																				/* If vc channel entry exists, but is being used by any wan connection then we return an Error !! */
																				/* TBD : needs multi WAN adaptation */
																				if (ifx_get_wan_vcc_state(vpivci_select)
																												!= IFX_SUCCESS) {
																								ifx_httpdError(wp, 200,
																																"This VC Channel is currently being used - Cannot Delete !!");
																								IFX_MEM_FREE(retVal)
																												return;
																				}

																				sprintf(sBuf, "%s_fEnable", retVal);
																				if ((ret =
																																ifx_GetObjData(FILE_RC_CONF,
																																				TAG_ADSL_VCCHANNEL,
																																				sBuf, IFX_F_GET_ANY,
																																				(IFX_OUT uint32 *) &
																																				outFlag,
																																				sValue)) !=
																												IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
																								IFX_DBG
																												("\n\n In Function [%s] : Error--> f_enable not found for [%s] !! \n\n",
																												 __FUNCTION__, retVal);
#endif
																								goto IFX_Handler;
																				}
																				if (atoi(sValue) == IFX_DISABLED) {
#ifdef IFX_LOG_DEBUG
																								IFX_DBG
																												("In Function [%s] : Error--> f_enable is set to IFX_DISABLED for [%s], Cannot do Delete !!",
																												 __FUNCTION__, retVal);
#endif
																								ifx_httpdError(wp, 400,
																																"The selected VC Channel is disabled, cannot do Delete !!");
																								IFX_MEM_FREE(retVal)
																												return;
																				}


																				sprintf(sBuf, "%s_l2ifName", retVal);
																				if ((ret =
																																ifx_GetObjData(FILE_RC_CONF,
																																				TAG_ADSL_VCCHANNEL,
																																				sBuf, IFX_F_GET_ANY,
																																				(IFX_OUT uint32 *) &
																																				outFlag,
																																				sValue)) !=
																												IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
																								IFX_DBG
																												("\n\n In Function [%s] : Error--> cpeid not found for [%s] !! \n\n",
																												 __FUNCTION__, retVal);
#endif
																								goto IFX_Handler;
																				}
																				snprintf(baseifname,
																												sizeof(baseifname), "%s",
																												sValue);


																				sprintf(sBuf, "%s_cpeId", retVal);
																				if ((ret =
																																ifx_GetObjData(FILE_RC_CONF,
																																				TAG_ADSL_VCCHANNEL,
																																				sBuf, IFX_F_GET_ANY,
																																				(IFX_OUT uint32 *) &
																																				outFlag,
																																				sValue)) !=
																												IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
																								IFX_DBG
																												("\n\n In Function [%s] : Error--> cpeid not found for [%s] !! \n\n",
																												 __FUNCTION__, retVal);
#endif
																								goto IFX_Handler;
																				} else {
																								vcc.iid.cpeId.Id = atoi(sValue);
																								ret =
																												ifx_ret_substr_from_distfield
																												(FILE_RC_CONF,
																												 TAG_WAN_CONN_DEVICE, "vcc",
																												 vpivci_selected, &retVal);
																								if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
																												IFX_DBG
																																("\n\n In Function [%s] : Error--> Failed to get wan connection device for VCC [%s]!!\n\n",
																																 __FUNCTION__,
																																 vpivci_selected);
#endif
																												IFX_MEM_FREE(retVal)
																																return;
																								}
																								sprintf(sBuf, "%s_cpeId",
																																retVal);
																								if ((ret =
																																				ifx_GetObjData
																																				(FILE_RC_CONF,
																																				 TAG_WAN_CONN_DEVICE, sBuf,
																																				 IFX_F_GET_ANY,
																																				 (IFX_OUT uint32 *) &
																																				 outFlag,
																																				 sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
																												IFX_DBG
																																("\n\n In Function [%s] : Error--> Failed to get cpeid for vcc [%s] !!\n\n",
																																 __FUNCTION__,
																																 vpivci_selected);
#endif
																												goto IFX_Handler;
																								}
																								wan_connDev.iid.cpeId.Id =
																												gatoi(sValue);
																								vcc.iid.pcpeId.Id =
																												atoi(sValue);
																								operation = IFX_OP_DEL;
																								flags = IFX_F_DELETE;
																								vpi_channel =
																												strtok(vpivci_selected,
																																				"/");
																								vci_channel = strtok(NULL, "/");
																								if (vpi_channel)
																												vcc.vc.pvc.vpi =
																																atoi(vpi_channel);
																								if (vci_channel)
																												vcc.vc.pvc.vci =
																																atoi(vci_channel);
																								sprintf(sBuf, "%s_Count",
																																TAG_WAN_ATMF5);
																								if ((ret =
																																				ifx_GetObjData
																																				(FILE_RC_CONF,
																																				 TAG_WAN_ATMF5, sBuf,
																																				 IFX_F_GET_ANY,
																																				 (IFX_OUT uint32 *) &
																																				 outFlag,
																																				 sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
																												IFX_DBG
																																("\n\n In Function [%s] : Error--> Failed to get atmf5 channel count !!\n\n",
																																 __FUNCTION__);
#endif
																												goto IFX_Handler;
																								}
																								atmf5_count = atoi(sValue);
																								//#if 0				/* TBD : Temporary */
																								for (i = 0; i < atmf5_count;
																																i++) {
																												sprintf(sBuf,
																																				"%s_%d_vpi",
																																				PREFIX_WAN_ATMF5,
																																				i);
																												if ((ret =
																																								ifx_GetObjData
																																								(FILE_RC_CONF,
																																								 TAG_WAN_ATMF5,
																																								 sBuf,
																																								 IFX_F_GET_ANY,
																																								 (IFX_OUT uint32 *)
																																								 & outFlag,
																																								 sValue)) !=
																																				IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
																																IFX_DBG
																																				("\n\n In Function [%s] : Error--> Failed to get [%s] !!\n\n",
																																				 __FUNCTION__,
																																				 sBuf);
#endif
																																goto IFX_Handler;
																												}
																												f_vpi = atoi(sValue);
																												sprintf(sBuf,
																																				"%s_%d_vci",
																																				PREFIX_WAN_ATMF5,
																																				i);
																												if ((ret =
																																								ifx_GetObjData
																																								(FILE_RC_CONF,
																																								 TAG_WAN_ATMF5,
																																								 sBuf,
																																								 IFX_F_GET_ANY,
																																								 (IFX_OUT uint32 *)
																																								 & outFlag,
																																								 sValue)) !=
																																				IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
																																IFX_DBG
																																				("\n\n In Function [%s] : Error--> Failed to get [%s] !!\n\n",
																																				 __FUNCTION__,
																																				 sBuf);
#endif
																																goto IFX_Handler;
																												}
																												f_vci = atoi(sValue);
																												if (vpi_channel)
																																if (atoi
																																								(vpi_channel)
																																								== f_vpi
																																								&&
																																								atoi
																																								(vci_channel)
																																								== f_vci) {
																																				sprintf
																																								(sBuf,
																																								 "%s_%d_cpeId",
																																								 PREFIX_WAN_ATMF5,
																																								 i);
																																				if ((ret
																																																=
																																																ifx_GetObjData
																																																(FILE_RC_CONF,
																																																 TAG_WAN_ATMF5,
																																																 sBuf,
																																																 IFX_F_GET_ANY,
																																																 (IFX_OUT
																																																	uint32
																																																	*)
																																																 &
																																																 outFlag,
																																																 sValue))
																																												!=
																																												IFX_SUCCESS)
																																				{
#ifdef IFX_LOG_DEBUG
																																								IFX_DBG
																																												("\n\n In Function [%s] : Error--> Failed to get [%s] !!\n\n",
																																												 __FUNCTION__,
																																												 sBuf);
#endif
																																								goto IFX_Handler;
																																				}
																																				atmf5_diag.
																																								iid.
																																								cpeId.
																																								Id =
																																								atoi
																																								(sValue);
																																				break;
																																}
																								}
																								//#endif				/* TBD : Temporary */
																				}

																				wan_connDev.iid.config_owner = IFX_WEB;
																				//manohar
																				wan_connDev.iid.pcpeId.Id = 1;
																				if (vpi_channel)
																								wan_connDev.vc.pvc.vpi =
																												atoi(vpi_channel);
																				if (vci_channel)
																								wan_connDev.vc.pvc.vci =
																												atoi(vci_channel);
																				snprintf(wan_connDev.iid.cpeId.secName,
																												strlen(TAG_WAN_CONN_DEVICE) +
																												1, "%s", TAG_WAN_CONN_DEVICE);
																				if (operation == IFX_OP_DEL) {
																								/* atmf5_diag.diagnostic_state = WAN_DIAG_START_DIAGNOSING; ??? what should be the state ??? */
																								atmf5_diag.f_enable =
																												IFX_DISABLED;
																								atmf5_diag.iid.config_owner =
																												IFX_WEB;
																								atmf5_diag.iid.pcpeId.Id =
																												wan_connDev.iid.cpeId.Id;
																								atmf5_diag.scope = '0';
																								if (vpi_channel) {
																												atmf5_diag.vpi =
																																atoi(vpi_channel);
																												atmf5_diag.vci =
																																atoi(vci_channel);
																								}
																								IFX_MEM_FREE(retVal)
																												sprintf(sValue, "%d",
																																				atmf5_diag.iid.
																																				pcpeId.Id);
																								if ((ret =
																																				ifx_ret_substr_from_distfield
																																				(FILE_RC_CONF,
																																				 TAG_WAN_ATMF5, "pcpeId",
																																				 sValue,
																																				 &retVal)) !=
																																IFX_SUCCESS) {
																												ifx_httpdError(wp, 405,
																																				T
																																				("Failed to find the cpeid for atmf5 [%d/%d]"),
																																				atmf5_diag.
																																				vpi,
																																				atmf5_diag.
																																				vci);
																												IFX_MEM_FREE(retVal)
																																return;
																								}
																								sprintf(sBuf, "%s_cpeId",
																																retVal);
																								if (ifx_GetObjData
																																(FILE_RC_CONF,
																																 TAG_WAN_ATMF5, sBuf,
																																 IFX_F_GET_ENA,
																																 (IFX_OUT uint32 *) &
																																 outFlag,
																																 sValue) != IFX_SUCCESS) {
																												ifx_httpdError(wp, 405,
																																				T
																																				("Failed to find the cpeid for atmf5 [%d/%d]"),
																																				atmf5_diag.
																																				vpi,
																																				atmf5_diag.
																																				vci);
																												goto IFX_Handler;
																								}
																								atmf5_diag.iid.cpeId.Id =
																												atoi(sValue);
																								sprintf(atmf5_diag.iid.cpeId.
																																secName, "%s",
																																TAG_WAN_ATMF5);
																								sprintf(atmf5_diag.iid.pcpeId.
																																secName, "%s",
																																TAG_WAN_CONN_DEVICE);
																								ret =
																												ifx_set_atmf5_loop_diagnostics
																												(IFX_OP_DEL, &atmf5_diag,
																												 IFX_F_DELETE |
																												 IFX_F_DONT_WRITE_TO_FLASH);
																								//#endif				/* TBD : Temporary */
																								ret = IFX_SUCCESS;
																								if (ret != IFX_SUCCESS) {
																												ifx_httpdError(wp, 400,
																																				"Error : Failed to delete the atmf5 object for [%d/%d] !!",
																																				atmf5_diag.
																																				vpi,
																																				atmf5_diag.
																																				vci);
																								}
																								vlan_ch.iid.pcpeId.Id=vcc.iid.cpeId.Id;//pcpeid value


																								if ((ret =
																																				ifx_ret_substr_from_distfield
																																				(FILE_RC_CONF,
																																				 TAG_VLAN_CHANNEL,"l2ifName",
																																				 baseifname,
																																				 &retVal)) !=
																																IFX_SUCCESS) {
																												ifx_httpdError(wp, 405,
																																				T
																																				("Failed to find sub field from l2if for vlan channel"));
																												return;
																								}

																								sprintf(sBuf, "%s_cpeId", retVal);
																								if ((ret =
																																				ifx_GetObjData(FILE_RC_CONF,
																																								TAG_VLAN_CHANNEL,
																																								sBuf, IFX_F_GET_ANY,
																																								(IFX_OUT uint32 *) &
																																								outFlag,
																																								sValue)) !=
																																IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
																												IFX_DBG
																																("\n\n In Function [%s] : Error--> cpeid not found for [%s] !! \n\n",
																																 __FUNCTION__, retVal);
#endif
																												goto IFX_Handler;
																								}

																								vlan_ch.iid.cpeId.Id=atoi(sValue);//cpeid value


																								snprintf(vlan_ch.iid.cpeId.secName,
																																strlen(TAG_VLAN_CHANNEL) + 1, "%s",
																																TAG_VLAN_CHANNEL);     //section name

																								snprintf(vlan_ch.iid.pcpeId.secName,
																																strlen(TAG_ADSL_VCCHANNEL) + 1, "%s",
																																TAG_ADSL_VCCHANNEL);   //parent section name

																								vlan_ch.iid.config_owner = IFX_WEB;  //owner

																								vlan_ch.fEnable = IFX_ENABLED; //fenable

																								vlan_ch.vlanId = 0;//vlanid 

																								vlan_ch.macAddrOvrd = 0;//macoverride

																								gstrcpy(vlan_ch.macAddr, "");//mac address


																								if ((ret =
																																				ifx_ret_substr_from_distfield
																																				(FILE_RC_CONF, TAG_WAN_IP,
																																				 "l2ifName", baseifname,
																																				 &retVal)) ==
																																IFX_SUCCESS) {
																												ifx_httpdError(wp, 400,
																																				"Vlan Channel is currently being used - Cannot Delete !!");
																												goto IFX_Handler;
																								}
																								if ((ret =
																																				ifx_ret_substr_from_distfield
																																				(FILE_RC_CONF, TAG_WAN_PPP,
																																				 "l2ifName", baseifname,
																																				 &retVal)) ==
																																IFX_SUCCESS) {
																												ifx_httpdError(wp, 400,
																																				"Vlan Channel is currently being used - Cannot Delete !!");
																												goto IFX_Handler;
																								}


																								ret = mapi_set_vlan_ch_entry(operation, &vlan_ch,flags | IFX_F_INT_DONT_CONFIGURE);

																								if (ret != IFX_SUCCESS) {
																												IFX_DBG
																																("In Function [%s] line [%d]: Failed to set vlan channel config  !!",
																																 __FUNCTION__, __LINE__);
																												goto IFX_Handler;
																								}
																								else {
																												if(ifx_get_one_vcc_info(&vcc) != IFX_SUCCESS) {
																																IFX_DBG
																																				("In Function [%s] line [%d]: Failed to get atm vc channel config for cpeid [%d] !!",
																																				 __FUNCTION__, __LINE__, vcc.iid.cpeId.Id);
																																goto IFX_Handler;

																												}
																												snprintf(vcc.iid.cpeId.
																																				secName,
																																				strlen
																																				(TAG_ADSL_VCCHANNEL)
																																				+ 1, "%s",
																																				TAG_ADSL_VCCHANNEL);
																												vcc.iid.pcpeId.Id =
																																wan_connDev.iid.
																																cpeId.Id;
																												strncpy(vcc.iid.pcpeId.
																																				secName,
																																				wan_connDev.iid.
																																				pcpeId.secName,
																																				strlen
																																				(wan_connDev.
																																				 iid.pcpeId.
																																				 secName));
																												vcc.iid.config_owner =
																																IFX_WEB;
																												/* call the api to update the adsl vcchannel section for this vpi/vci */
																												ret =
																																ifx_set_vcc_cfg
																																(operation, &vcc,
																																 flags);
																												if (ret == IFX_FAILURE) {
																																ifx_httpdError
																																				(wp, 200,
																																				 "Error deleting vc channel entry for [%d/%d] !!",
																																				 vcc.vc.pvc.
																																				 vpi,
																																				 vcc.vc.pvc.
																																				 vci);
																												} 
																												else {
																																if ((ret =
																																												ifx_set_wan_conn_dev
																																												(operation,
																																												 &wan_connDev,
																																												 flags)) !=
																																								IFX_SUCCESS)
																																{
#ifdef IFX_LOG_DEBUG
																																				IFX_DBG
																																								("\n\n In Function [%s] : Error-->Trying to get the wan connection device iid !!\n\n",
																																								 __FUNCTION__);
#endif
																																				ifx_httpdError
																																								(wp,
																																								 200,
																																								 "Error deleting wan connection device entry for [%d/%d] !!",
																																								 vcc.
																																								 vc.
																																								 pvc.
																																								 vpi,
																																								 vcc.
																																								 vc.
																																								 pvc.
																																								 vci);
																																				goto IFX_Handler;
																																}
																												}
																								}
																				}
																}	//if
												}	// for
												IFX_MEM_FREE(vcc1);
								} else {
												operation = 0;
								}
								/* call the api to update the wan connection device section for this vpi/vci setting */
								wan_connDev.iid.config_owner = IFX_WEB;
								wan_connDev.iid.pcpeId.Id = 1;
								if (vpi_channel)
												wan_connDev.vc.pvc.vpi = atoi(vpi_channel);
								if (vci_channel)
												wan_connDev.vc.pvc.vci = atoi(vci_channel);
								snprintf(wan_connDev.iid.cpeId.secName,
																strlen(TAG_WAN_CONN_DEVICE) + 1, "%s",
																TAG_WAN_CONN_DEVICE);

								if (operation == IFX_OP_ADD) {
												if ((ret =
																								ifx_set_wan_conn_dev(operation, &wan_connDev,
																												flags |
																												IFX_F_DONT_WRITE_TO_FLASH)) !=
																				IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
																IFX_DBG
																				("\n\n In Function [%s] : Error-->Trying to get the wan connection device iid !!\n\n",
																				 __FUNCTION__);
#endif
																COPY_TO_STATUS(dup_vc_err,
																								wan_connDev.vc.pvc.vpi,
																								wan_connDev.vc.pvc.vci);
																ifx_httpdRedirect(wp, "err_page.html");
																//    ifx_httpdError(wp, 200, "Error : Failed to add the wan connection device for [%d/%d] !!",
																//                     wan_connDev.vc.pvc.vpi, wan_connDev.vc.pvc.vci);
																goto IFX_Handler;
												}

												snprintf(vcc.iid.cpeId.secName,
																				strlen(TAG_ADSL_VCCHANNEL) + 1, "%s",
																				TAG_ADSL_VCCHANNEL);
												vcc.iid.pcpeId.Id = wan_connDev.iid.cpeId.Id;
												strncpy(vcc.iid.pcpeId.secName,
																				wan_connDev.iid.pcpeId.secName,
																				strlen(wan_connDev.iid.pcpeId.secName));
												vcc.iid.config_owner = IFX_WEB;
												/* call the api to update the adsl vcchannel section for this vpi/vci */
												ret =
																ifx_set_vcc_cfg(operation, &vcc,
																								flags | IFX_F_DONT_WRITE_TO_FLASH);
												if (ret == IFX_FAILURE)
																ifx_httpdError(wp, 200,
																								"Error : Failed to add the vc channel for [%d/%d] !!",
																								vcc.vc.pvc.vpi, vcc.vc.pvc.vci);
												else {	/* add a atmf5 object */
																/* No ping diagnostic during channel add */
																atmf5_diag.diagnostic_state =
																			WAN_DIAG_NONE;
																atmf5_diag.f_enable = IFX_ENABLED;
																atmf5_diag.iid.config_owner = IFX_WEB;
																atmf5_diag.iid.pcpeId.Id =
																				wan_connDev.iid.cpeId.Id;
																atmf5_diag.scope = '0';
																/* configure the default value from web */

																atmf5_diag.ping_timeout = 600;
																atmf5_diag.oam_pings = 1;
																if (vpi_channel) {
																				atmf5_diag.vpi = atoi(vpi_channel);
																				atmf5_diag.vci = atoi(vci_channel);
																}
																sprintf(atmf5_diag.iid.cpeId.secName, "%s",
																								TAG_WAN_ATMF5);
																sprintf(atmf5_diag.iid.pcpeId.secName, "%s",
																								TAG_WAN_CONN_DEVICE);

#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT) || defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
																ret =
																				ifx_set_atmf5_loop_diagnostics(IFX_OP_ADD,
																												&atmf5_diag,
																												IFX_F_INT_ADD
																												|
																												IFX_F_DONT_WRITE_TO_FLASH);
#else
																if (Qs_Status == 1)
																				ret =
																								ifx_set_atmf5_loop_diagnostics
																								(IFX_OP_ADD, &atmf5_diag,
																								 IFX_F_INT_ADD);
																else
																				ret =
																								ifx_set_atmf5_loop_diagnostics
																								(IFX_OP_ADD, &atmf5_diag,
																								 IFX_F_INT_ADD |
																								 IFX_F_DONT_WRITE_TO_FLASH);
#endif
																if (ret != IFX_SUCCESS)
																				ifx_httpdError(wp, 500,
																												"Error : Failed to add the atmf5 object [%d/%d] !!",
																												atmf5_diag.vpi,
																												atmf5_diag.vci);
																//#endif				/* TBD : temporary */

																/*vlan chennel entry (NEW) */
																snprintf(vlan_ch.iid.cpeId.secName,
																								strlen(TAG_VLAN_CHANNEL) + 1, "%s",
																								TAG_VLAN_CHANNEL);
																snprintf(vlan_ch.iid.pcpeId.secName,
																								strlen(TAG_ADSL_VCCHANNEL) + 1, "%s",
																								TAG_ADSL_VCCHANNEL);
																vlan_ch.iid.pcpeId.Id = vcc.iid.cpeId.Id;
																vlan_ch.iid.config_owner = IFX_WEB;

																//vlan_ch.iid.cpeId=0;
																//vlan_ch.iid.pcpeId=0;
																gstrcpy(vlan_ch.iid.pcpeId.secName,
																								"adsl_vcchannel");
																vlan_ch.fEnable = IFX_ENABLED;
																gstrcpy(vlan_ch.chName, "");
																vlan_ch.vlanId = -1;
																vlan_ch.macAddrOvrd = 0;
																gstrcpy(vlan_ch.macAddr, "");
																strncpy(vlan_ch.baseIf, vcc.l2ifname,
																								strlen(vcc.l2ifname));
#ifdef IFX_LOG_DEBUG
																IFX_DBG
																				("%s %d vlan_ch.baseIf %s ,vcc.l2ifname %s!!",
																				 __FUNCTION__, __LINE__, vlan_ch.baseIf,
																				 vcc.l2ifname);
#endif
																ret =
																				mapi_set_vlan_ch_entry(operation, &vlan_ch,
																												flags | IFX_F_INT_DONT_CONFIGURE);
																if (ret != IFX_SUCCESS) {
																				IFX_DBG
																								("In Function [%s] line [%d]: Failed to set vlan channel config  !!",
																								 __FUNCTION__, __LINE__);
																}

												}

								}
				}

IFX_Handler:
				IFX_MEM_FREE(retVal)
				if (Qs_Status == 1)
					ifx_httpdRedirect(wp, T("atm_channel_config.asp"));	//manohar
				else
					websNextPage(wp);
}

#ifdef CONFIG_PACKAGE_IFX_OAM
int ifx_get_ADSLOAM_List_modified(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_FILELINE_LEN], *name;
	char_t command[MAX_FILELINE_LEN];
	char_t pVPIChannel[MAX_FILELINE_LEN], pVCIChannel[MAX_FILELINE_LEN],
	    pLo[MAX_FILELINE_LEN], pCc[MAX_FILELINE_LEN],
	    pCcOpt[MAX_FILELINE_LEN], pTtime[MAX_FILELINE_LEN];
	char_t sSpace[MAX_FILELINE_LEN];
	char_t sCcOpt[MAX_FILELINE_LEN];
	int i, nChannel_Size;
	char_t *tag_name;
	int type;
	int uTemp = 0;
	sValue[0] = '\0';
	command[0] = '\0';
	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	if (!strcmp(name, "OAM_F4_List")) {
		type = 4;
		tag_name = TAG_ADSL_OAM_F4;
	} else if (!strcmp(name, "OAM_F5_List")) {
		type = 5;
		tag_name = TAG_ADSL_OAM_F5;
	} else if (!strcmp(name, "OAM_ENABLE")) {
		if (ifx_GetCfgData(FILE_RC_CONF, TAG_ADSL_OAM, name, sValue) ==
		    0) {
			ifx_httpdError(wp, 500,
				       "ADSL VCChannelCount not found");
			return -1;
		}
		if (gstrcmp(sValue, "1") == 0)
			ifx_httpdWrite(wp, "checked");
		else
			ifx_httpdWrite(wp, "");
		return 0;
	} else {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	gsprintf(command, "%s_Count", tag_name);
	if (ifx_GetCfgData(FILE_RC_CONF, tag_name, command, sValue) == 0) {
		ifx_httpdError(wp, 500, "ADSL VCChannelCount not found");
		return -1;
	}
	if (type == 5)
		ifx_httpdWrite(wp,
			       T
			       ("<tr><th width=\"5%\">NO</th><th width=\"20%\">VPI/VCI</th><th width=\"15%\">Loopback</th><th width=\"20%\">Transmit Time</th></tr>\n"));
	else
		ifx_httpdWrite(wp,
			       T
			       ("<tr><th width=\"5%\">NO</th><th width=\"15%\">VPI</th><th width=\"20%\">Loopback</th><th width=\"20%\">Continuity</th><th width=\"20%\">Directory</th><th width=\"20%\">Transmit Time</th></tr>\n"));
	nChannel_Size = gatoi(sValue);
	for (i = 0; i < nChannel_Size; i++) {
		int j = 0;
		gsprintf(command, "%s_%d_vpi", tag_name, i);
		if (ifx_GetCfgData(FILE_RC_CONF, tag_name, command, pVPIChannel)
		    == 0) {
			ifx_httpdError(wp, 500, "ADSL VCChannel not found");
			return -1;
		}
		if (atoi(pVPIChannel) != 256) {
			if (type == 5) {
				gsprintf(command, "%s_%d_vci", tag_name, i);
				ifx_GetCfgData(FILE_RC_CONF, tag_name, command,
					       pVCIChannel);
			}
			gsprintf(command, "%s_%d_loopback", tag_name, i);
			ifx_GetCfgData(FILE_RC_CONF, tag_name, command, pLo);

			gsprintf(command, "%s_%d_contCheck", tag_name, i);
			ifx_GetCfgData(FILE_RC_CONF, tag_name, command, pCc);

			gsprintf(command, "%s_%d_contCheckOpt", tag_name, i);
			ifx_GetCfgData(FILE_RC_CONF, tag_name, command, pCcOpt);

			gsprintf(command, "%s_%d_timeout", tag_name, i);
			ifx_GetCfgData(FILE_RC_CONF, tag_name, command, pTtime);
			sprintf(command, "&nbsp;&nbsp;");
			memset(sSpace, 0x00, sizeof(sSpace));
			for (j = 0; j < (5 - strlen(pVPIChannel)) / 2; j++) {
				strcat(sSpace, command);
			}
			if ((5 - strlen(pVPIChannel)) % 2) {
				strcat(sSpace, "&nbsp;");
			}
			switch (atoi(pCcOpt)) {
			case 1:
				sprintf(sCcOpt, "Sink");
				break;
			case 2:
				sprintf(sCcOpt, "Source");
				break;
			case 3:
				sprintf(sCcOpt, "Both");
				break;
			}
			if (type == 5)
				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%d</td><td>%s/%s</td><td>%s</td><td>%s</td></tr>\n"),
					       i + 1 - uTemp, pVPIChannel,
					       pVCIChannel,
					       atoi(pLo) ? "Enable" : "Disable",
					       pTtime);
			else
				ifx_httpdWrite(wp,
					       T
					       ("<tr><td>%d</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>\n"),
					       i + 1 - uTemp, pVPIChannel,
					       atoi(pLo) ? "Enable" : "Disable",
					       atoi(pCc) ? "Enable" : "Disable",
					       sCcOpt, pTtime);
		} else {
			uTemp++;
		}
	}

	return 0;
}
#endif

int ifx_get_OAM_type(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
	ifx_httpdError(wp, 400, T("Insufficient args\n"));
	return -1;
	}

if (!strcmp(name, "OAM_MODE")) {
		#ifdef CONFIG_FEATURE_IFX_OAM_FULL
		 ifx_httpdWrite(wp, T("%s"), "<option value='1' selected>OAM_F5</option>\n");
		 ifx_httpdWrite(wp, T("%s"), "<option value='0' selected>OAM_F4</option>");
#else
#ifdef CONFIG_FEATURE_IFX_OAM_F5_LOOPBACK
		 ifx_httpdWrite(wp, T("%s"), "<option value='1' selected>OAM_F5</option>");
#endif
#endif
		}

else {
#ifdef CONFIG_FEATURE_IFX_OAM_FULL
        ifx_httpdWrite(wp, T("%s"), "OAM_FULL");
#else
#ifdef CONFIG_FEATURE_IFX_OAM_F5_LOOPBACK
        ifx_httpdWrite(wp, T("%s"), "OAM_F5");
#endif
#endif
}


	return 0;
}

#if defined(CONFIG_PACKAGE_IFX_OAM) || defined(CONFIG_FEATURE_IFX_OAM_FULL) || defined(CONFIG_FEATURE_IFX_OAM_F5_LOOPBACK)	// 000001:jelly:2005/6/14
int ifx_get_ADSLOAM_List(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_FILELINE_LEN], *name;
	char_t command[MAX_FILELINE_LEN];
	char_t pVPIChannel[MAX_FILELINE_LEN], pVCIChannel[MAX_FILELINE_LEN],
	    pLo[MAX_FILELINE_LEN];
	char_t pCc[MAX_FILELINE_LEN], pCcOpt[MAX_FILELINE_LEN],
	    pTtime[MAX_FILELINE_LEN], pTxCells[MAX_FILELINE_LEN];
	char_t *_pVPIChannel = NULL, /**_pLo = NULL, *_pCc = NULL,*/ *_pCcOpt = NULL /*,*_pTtime = NULL*/;
	char_t sSpace[MAX_FILELINE_LEN];
	char_t sCcOpt[MAX_FILELINE_LEN];
	int i = 0, nChannel_Size;
	char_t *tag_name;
	char_t *delim = "_\n";
	int type;
	uint32 outFlag = IFX_F_DEFAULT;
	uint32 uTemp = 0;
	int32 num_entries = 0;
	WAN_ATMF5_LOOP_DIAGNOSTICS *atmf5 = NULL;

	sValue[0] = '\0';
	command[0] = '\0';

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	if (!strcmp(name, "OAM_F4_List")) {
		type = 4;
		tag_name = TAG_ADSL_OAM_F4;
	} else if (!strcmp(name, "OAM_F5_List")) {
		type = 5;
		tag_name = TAG_ADSL_OAM_F5;
	} else if (!strcmp(name, "OAM_ENABLE")) {
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_ADSL_OAM, name, IFX_F_GET_ENA, &outFlag,
		     sValue) != IFX_SUCCESS) {
			ifx_httpdError(wp, 500, "OAM Enable tag not found");
			return -1;
		}
		if (gstrcmp(sValue, "1") == 0)
			ifx_httpdWrite(wp, "checked");
		else
			ifx_httpdWrite(wp, "");
		return 0;
	} else {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	ifx_httpdWrite(wp,
		       T
		       ("\t\t\t\t<option disabled>"),
		       sValue); 

/*#ifdef CONFIG_FEATURE_IFX_OAM_FULL	// 000001:jelly:2005/6/14
	if (type == 5)
		ifx_httpdWrite(wp,
			       T
			       ("NO--&nbsp;&nbsp;VPI&nbsp;&nbsp;--&nbsp;&nbsp;VCI&nbsp;&nbsp;--Loopback--Continuity--Directory--Transmit Time</option>\n"));
	else
		ifx_httpdWrite(wp,
			       T
			       ("NO--&nbsp;&nbsp;VPI&nbsp;&nbsp;--Loopback--Continuity--Directory--Transmit Time</option>\n"));
#endif*/
#ifdef CONFIG_FEATURE_IFX_OAM_F5_LOOPBACK	// 000001:jelly:2005/6/14
	/* Pramod - Loopback not required for OAM_F5 */
	if (type == 5)
		/* Pramod - Loopback not required for OAM_F5 */
		ifx_httpdWrite(wp,
			       T
			       ("<tr align=\"center\"><th><b>No</b></th><th><b>VPI/VCI</b></th><th><b>Loopback</b></th><th><b>Transmit Time</b></th><th><b>TX Cells</b></th><th><b>Update Entry</b></th></TR>\n"));

	//  ifx_httpdWrite(wp, T("NO--&nbsp;&nbsp;VPI&nbsp;&nbsp;--&nbsp;&nbsp;VCI&nbsp;&nbsp;--Loopback--Transmit Time</option>\n"));

#endif

	if (type == 5) {

		if (ifx_get_all_wan_atmf5_loop_diagnostics
		    (&num_entries, &atmf5, IFX_F_DEFAULT) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("In Function [%s] : Failed to get the atmf5 entries !!",
			     __FUNCTION__);
#endif
			ifx_httpdError(wp, 400,
				       "Failed to get the atmf5 entries !!");
			return -1;
		}

		for (i = 0; i < num_entries; i++) {
			sValue[0] = '\0';
			pVPIChannel[0] = '\0';
			pVCIChannel[0] = '\0';
			pLo[0] = '\0';
			pCc[0] = '\0';
			pCcOpt[0] = '\0';
			pTtime[0] = '\0';
			pTxCells[0] = '\0';
			if ((atmf5 + i)->vpi != 256) {
				/* sValue of the format vpi_vci_loopback_cccheck_cccheckopt_pingtimeout */
				sprintf(sValue, "%d_%d_%d_%d_%d_%d_%d",
					(atmf5 + i)->vpi, (atmf5 + i)->vci,
					(atmf5 + i)->loopback,
					(atmf5 + i)->cc_check,
					(atmf5 + i)->cc_check_opt,
					(atmf5 + i)->ping_timeout,
					(atmf5 + i)->oam_pings);
				/*        if (i==0) {
				   ifx_httpdWrite(wp, T("\t\t\t\t<option VALUE=\"%s\" selected >"), sValue);
				   } else {
				   ifx_httpdWrite(wp, T("\t\t\t\t<option VALUE=\"%s\">"), sValue);
				   } */
				sprintf(pVPIChannel, "%d", (atmf5 + i)->vpi);
				sprintf(pVCIChannel, "%d", (atmf5 + i)->vci);
				sprintf(pLo, "%d", (atmf5 + i)->loopback);
				sprintf(pCc, "%d", (atmf5 + i)->cc_check);
				sprintf(pCcOpt, "%d",
					(atmf5 + i)->cc_check_opt);
				sprintf(pTtime, "%d",
					(atmf5 + i)->ping_timeout);
				sprintf(pTxCells, "%d", (atmf5 + i)->oam_pings);
				sprintf(command, "&nbsp;&nbsp;");

				memset(sSpace, 0x00, sizeof(sSpace));
				int j = 0;
				for (j = 0; j < (5 - strlen(pVPIChannel)) / 2;
				     j++) {
					strcat(sSpace, command);
				}

				if ((5 - strlen(pVPIChannel)) % 2) {
					strcat(sSpace, "&nbsp;");
				}

				switch (atoi(pCcOpt)) {
				case 0:
					sprintf(sCcOpt, "Sink");
					break;
				case 1:
					sprintf(sCcOpt, "Source");
					break;
				case 2:
					sprintf(sCcOpt, "Both");
					break;
				}
/*#ifdef CONFIG_FEATURE_IFX_OAM_FULL	// 000001:jelly:2005/6/14
				ifx_httpdWrite(wp,
					       T
					       ("&nbsp;&nbsp;%d&nbsp;--%s%s%s--%s%s%s--&nbsp;&nbsp;&nbsp;%s&nbsp;&nbsp;&nbsp;--&nbsp;&nbsp;%s&nbsp;&nbsp;--%s&nbsp;&nbsp;--&nbsp;&nbsp;%s&nbsp;&nbsp;--&nbsp;&nbsp;%s\n"),
					       i + 1 - uTemp, sSpace,
					       pVPIChannel, sSpace, sSpace,
					       pVCIChannel, sSpace,
					       atoi(pLo) ? "Enable" : "Disable",
					       atoi(pCc) ? "Enable" : "Disable",
					       sCcOpt, pTtime, pTxCells);
#endif*/
#ifdef CONFIG_FEATURE_IFX_OAM_F5_LOOPBACK	// 000001:jelly:2005/6/14
				/* Pramod - Loopback not required for OAM_F5 */
				if (i == 0)
					ifx_httpdWrite(wp,
						       T
						       ("<tr align=\"center\"><td name=\"oam_no_%d\">%d</td><td name=\"oam_vpvc_%d\">%s/%s</td><td  name=\"oam_lback_%d\">%s</td><td name=\"oam_ttime_%d\">%s</td><td  name=\"oam_txcell_%d\">%s</td><td name=\"oam_uentry_%d\"><input type='radio' name='OAM_F5_List' value='%s' checked onClick=\"update_Setting();\"></td></TR>\n"),
						       i + 1 - uTemp,
						       i + 1 - uTemp,
						       i + 1 - uTemp,
						       pVPIChannel, pVCIChannel,
						       i + 1 - uTemp,
						       atoi(pLo) ? "Enable" :
						       "Disable", i + 1 - uTemp,
						       pTtime, i + 1 - uTemp,
						       pTxCells, i + 1 - uTemp,
						       sValue);
				else
					ifx_httpdWrite(wp,
						       T
						       ("<tr align=\"center\"><td name=\"oam_no_%d\">%d</td><td name=\"oam_vpvc_%d\">%s/%s</td><td name=\"oam_lback_%d\">%s</td><td name=\"oam_ttime_%d\">%s</td><td  name=\"oam_txcell_%d\">%s</td><td name=\"oam_uentry_%d\"><input type='radio' name='OAM_F5_List' value='%s' onClick=\"update_Setting();\" ></td></TR>\n"),
						       i + 1 - uTemp,
						       i + 1 - uTemp,
						       i + 1 - uTemp,
						       pVPIChannel, pVCIChannel,
						       i + 1 - uTemp,
						       atoi(pLo) ? "Enable" :
						       "Disable", i + 1 - uTemp,
						       pTtime, i + 1 - uTemp,
						       pTxCells, i + 1 - uTemp,
						       sValue);

				//     ifx_httpdWrite(wp, T("&nbsp;&nbsp;%d&nbsp;--%s%s%s--%s%s%s--&nbsp;&nbsp;&nbsp;%s&nbsp;&nbsp;&nbsp;--&nbsp;&nbsp;%s&nbsp;&nbsp;--&nbsp;&nbsp;%s\n"),i+1-uTemp,sSpace,pVPIChannel,sSpace,sSpace,pVCIChannel,sSpace,atoi(pLo)?"Enable":"Disable",pTtime,pTxCells);
#endif
			} else {
				uTemp++;
			}
		}
	} else {
		gsprintf(command, "%sCount", tag_name);
		if (ifx_GetCfgData(FILE_RC_CONF, tag_name, command, sValue) ==
		    0) {
			ifx_httpdError(wp, 500,
				       "ADSL VCChannelCount not found");
			return -1;
		}

		nChannel_Size = gatoi(sValue);
		for (i = 0; i < nChannel_Size; i++) {
			int j = 0;
			gsprintf(command, "%s%d", tag_name, i);
			if (ifx_GetCfgData
			    (FILE_RC_CONF, tag_name, command, sValue) == 0) {
				ifx_httpdError(wp, 500,
					       "ADSL VCChannel not found");
				return -1;
			}
			if (i == 0) {
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t<option VALUE=\"%s\" selected >"),
					       sValue);
			} else {
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t<option VALUE=\"%s\">"),
					       sValue);
			}
			_pVPIChannel = strtok(sValue, delim);
			/*_pLo =*/ strtok(NULL, delim);
			/*_pCc = */strtok(NULL, delim);
			_pCcOpt = strtok(NULL, delim);
			/*_pTtime =*/ strtok(NULL, delim);
			sprintf(command, "&nbsp;&nbsp;");
			memset(sSpace, 0x00, sizeof(sSpace));
			if (_pVPIChannel) {
				for (j = 0; j < (5 - strlen(_pVPIChannel)) / 2;
				     j++) {
					strcat(sSpace, command);
				}
				if ((5 - strlen(_pVPIChannel)) % 2) {
					strcat(sSpace, "&nbsp;");
				}
			}
			if (_pCcOpt) {
				switch (atoi(_pCcOpt)) {
				case 0:
					sprintf(sCcOpt, "Sink");
					break;
				case 1:
					sprintf(sCcOpt, "Source");
					break;
				case 2:
					sprintf(sCcOpt, "Both");
					break;
				}
			}
/*#ifdef CONFIG_FEATURE_IFX_OAM_FULL	// 000001:jelly:2005/6/14
			ifx_httpdWrite(wp,
				       T
				       ("&nbsp;&nbsp;%d&nbsp;--%s%s%s--&nbsp;&nbsp;&nbsp;%s&nbsp;&nbsp;&nbsp;--&nbsp;&nbsp;%s&nbsp;&nbsp;--&nbsp;&nbsp;%s--&nbsp;&nbsp;%s\n"),
				       i + 1, sSpace, _pVPIChannel, sSpace,
				       atoi(_pLo) ? "Enable" : "Disable",
				       atoi(_pCc) ? "Enable" : "Disable",
				       sCcOpt, _pTtime);
#endif*/
		}
	}

	IFX_MEM_FREE(atmf5)
	    return 0;
}
#endif

//adsl_vcconfig.asp
int ifx_get_ADSLVcConfig(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name, sValue[MAX_DATA_LEN];
	sValue[0] = '\0';

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	if (!gstrcmp(name, T("TRAutoConfig"))) {
		gstrcpy(sValue, "1");
	} else if (!gstrcmp(name, T("FirstVCConfig"))) {
		gstrcpy(sValue, "1");

	}

	ifx_httpdWrite(wp, sValue);

	return 0;

}
