//#include <sys/syslog.h>
#include <ifx_emf.h>
#include "ifx_httpd_method.h"
//#include <signal.h>
//#include <unistd.h>
//#include <sys/types.h>
//#include <sys/wait.h>
//#include <ifx_common.h>
#include "./ifx_amazon_cgi.h"
#include "ifx_amazon_cgi_time.h"
#include "./ifx_amazon_cgi_getFunctions.h"
//#include "ifx_snmp_api.h"
//#include "ifx_api_ipt_common.h"
//#include <sys/ioctl.h>
#include "./ifx_cgi_common.h"

extern char *status_str;
extern int ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);
extern int ifx_get_all_wan_conn_names(char **wan_conn_names, int *count);
extern void websNextPage(httpd_t wp);
char natvsAction[20];
char natcpeId[10];
char natptcpeId[20];
#ifdef CONFIG_FEATURE_NAPT
void ifx_set_nat_main(httpd_t wp, char_t * path, char_t * query);	//nat_main.asp
void ifx_set_nat_virtualser(httpd_t wp, char_t * path, char_t * query);	//nat_virtualser.asp
void ifx_set_nat_portmap(httpd_t wp, char_t * path, char_t * query);	//nat_portmap.asp
void ifx_set_firewall_dmz(httpd_t wp, char_t * path, char_t * query);	//firewall_dmz.asp
int ifx_get_NATStatus(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_nat_virtualser(int eid, httpd_t wp, int argc, char_t ** argv);	//nat_virtualser.asp
int ifx_get_nat_portmap(int eid, httpd_t wp, int argc, char_t ** argv);	//nat_portmap.asp
int ifx_get_firewall_dmz(int eid, httpd_t wp, int argc, char_t ** argv);	//firewall_dmz.asp
#endif

//vipul start
static CGI_ENUMSEL_S web_Port_TriggerList[] = {
	{0, "Select One--"},
	{1, "Aim Talk"},
	{2, "Asheron's Call"},
	{3, "Calista IP Phone"},
	{4, "Delta Force (Client/Server)"},
	{5, "ICQ"},
//    { 6, "Napster"},
	{6, "Net2Phone"},
	{7, "QuickTime 4 Client"},
	{8, "Rainbow Six/Rogue Spea"},
};

static CGI_ENUMSEL_S web_Port_ForwardList[] = {
	{0, "Select One--"},
	{1, "Age of Empires"},
	{2, "Age of Empires Expansion: The Rise of Rome"},
	{3, "AOL Instant Messenger"},
	{4, "AUTH"},
	{5, "Buddy Phone"},
	{6, "Bungie.net"},
	{7, "Delta Force"},
	{8, "Freetel"},
	{9, "FTP Server"},
	{10, "IPSEC"},
	{11, "KaZaA"},
	{12, "Mail (POP3)"},
	{13, "Mail (SMTP)"},
	{14, "Myth"},
	{15, "SNMP"},
	{16, "TFTP"},
	{17, "Yahoo Messenger Chat"},
};

//vipul end 

///////////////////////////////////////////////////////////////////////////////
//vipul start
int ifx_get_nat_porttrigger(int eid, httpd_t wp, int argc, char_t ** argv);

int ifx_get_nat_porttrigger(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char8 sValue[MAX_FILELINE_LEN];
	char8 *name = NULL;
	int num;
	int ret = IFX_SUCCESS, i;
	uint32 Flags = IFX_F_DEFAULT;
	PORT_TRIGGER *port_trigger = NULL;
	ifx_httpd_parse_args(argc, argv, T("%s"), &name);

	ret = ifx_get_all_port_trigger_info(&num, &port_trigger, Flags);

	if (ret == IFX_SUCCESS) {
		if (name != NULL) {
			ifx_httpdWrite(wp, T("\"%d\""), num);
		} else {
			for (i = 0; i < num; i++) {
				ifx_httpdWrite(wp,
					       "<input type=\"hidden\" name=\"cpeId%d\" value=\"%d\">",
					       i,
					       (port_trigger +
						i)->iid.cpeId.Id);
				ifx_httpdWrite(wp,
					       T("<tr align=\"center\">\n"));
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"ptrig_app_name%d\">%s</td>\n"),
					       i,
					       (port_trigger +
						i)->Application_Name);
				sprintf(sValue, "%d",
					(port_trigger + i)->trigger_start_port);
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"ptrig_sport%d\">%s</td>\n"),
					       i, sValue);
				sprintf(sValue, "%d",
					(port_trigger + i)->trigger_end_port);
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"ptrig_eport%d\">%s</td>\n"),
					       i, sValue);
				if ((port_trigger + i)->protocol == 1)
					strcpy(sValue, "TCP");
				else if ((port_trigger + i)->protocol == 2)
					strcpy(sValue, "UDP");
				else
					strcpy(sValue, "TCP/UDP");
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"ptrig_tprot%d\">%s</td>\n"),
					       i, sValue);
				sprintf(sValue, "%d",
					(port_trigger +
					 i)->external_start_port);
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"ptrig_ext_sport%d\">%s</td>\n"),
					       i, sValue);
				sprintf(sValue, "%d",
					(port_trigger + i)->external_end_port);
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"ptrig_ext_eport%d\">%s</td>\n"),
					       i, sValue);
				if ((port_trigger + i)->open_protocol == 1)
					strcpy(sValue, "TCP");
				else if ((port_trigger + i)->open_protocol == 2)
					strcpy(sValue, "UDP");
				else
					strcpy(sValue, "TCP/UDP");
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"ptrig_oprot%d\">%s</td>\n"),
					       i, sValue);
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t<td align=center><input type=\"checkbox\" name=\"penable%d\" value=\"1\"%s onClick=\"ModifyValue(\'%d\',\'%d\');\"></td>\n"),
					       i,
					       (port_trigger + i)->f_enable ==
					       1 ? " CHECKED" : " ", i,
					       (port_trigger +
						i)->iid.cpeId.Id);

				ifx_httpdWrite(wp,
					       T
					       ("<td><a href=\"#\" class=\"button\" value=\"Delete\" onClick=\"DelValue(\'%d\', \'%d\');\">Delete</a>\n"),
					       i,
					       (port_trigger +
						i)->iid.cpeId.Id);
				ifx_httpdWrite(wp,
					       T
					       ("<a href=\"#\" class=\"button\" value=\"Modify\" onClick=\"ModifyValue(\'%d\', \'%d\');\">Modify</a></td>\n"),
					       i,
					       (port_trigger +
						i)->iid.cpeId.Id);

				ifx_httpdWrite(wp, T("</tr>"));
			}
		}
	} else {
		ifx_httpdError(wp, 500, "Error");
	}

	IFX_MEM_FREE(port_trigger)
	    return 0;
}

// vipul end
/////////////////////////////////////////////////////////////////////////////
int ifx_get_nat_porttrigger_data(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char8 *name = NULL;
	//  char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN], *sServerIP = NULL, *retVal = NULL;
	int32 ret = IFX_SUCCESS;
	//  int32 num_entries = 0, i =0, flags = IFX_F_DEFAULT;
	//   int32   count = 0, j = 0, diffserv_vs_enable = 0, diffserv_done = 0;
//    char8   *wan_conn_names = NULL, wan_conn_name[MAX_FILELINE_LEN];
	//  uint32  outFlag = IFX_F_DEFAULT;
	PORT_TRIGGER port_trigger;
	memset(&port_trigger, 0x00, sizeof(port_trigger));
	//  sValue[0]='\0';
	//  buf[0]='\0';
	port_trigger.iid.cpeId.Id = atoi(natptcpeId);
	if ((ret = ifx_get_port_trigger_info(&port_trigger)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get the port trigger info !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
	}

	if (atoi(natptcpeId) == port_trigger.iid.cpeId.Id) {
		/* cpe id match, populate the fields in nat_portmap_add.asp */
		if (!gstrcmp(name, "cpeId"))
			ifx_httpdWrite(wp, T("%s"), natptcpeId);
		else {

			if (!gstrcmp(name, "application_name"))
				ifx_httpdWrite(wp, T("%s"),
					       port_trigger.Application_Name);
			else if (!gstrcmp(name, "trigger_sport"))
				ifx_httpdWrite(wp, T("%d"),
					       port_trigger.trigger_start_port);
			else if (!gstrcmp(name, "trigger_eport"))
				ifx_httpdWrite(wp, T("%d"),
					       port_trigger.trigger_end_port);
			else if (!gstrcmp(name, "external_sport"))
				ifx_httpdWrite(wp, T("%d"),
					       port_trigger.
					       external_start_port);
			else if (!gstrcmp(name, "external_eport"))
				ifx_httpdWrite(wp, T("%d"),
					       port_trigger.external_end_port);
			else if (!gstrcmp(name, "protocol_tcp")) {
				ifx_httpdWrite(wp, T("%s"),
					       port_trigger.protocol ==
					       NAT_VS_PROTOCOL_TCP ? "SELECTED"
					       : "");
			} else if (!gstrcmp(name, "protocol_udp")) {
				ifx_httpdWrite(wp, T("%s"),
					       port_trigger.protocol ==
					       NAT_VS_PROTOCOL_UDP ? "SELECTED"
					       : "");
			} else if (!gstrcmp(name, "protocol_tcp_udp")) {
				ifx_httpdWrite(wp, T("%s"),
					       port_trigger.protocol ==
					       (NAT_VS_PROTOCOL_TCP_UDP -
						NAT_VS_PROTOCOL_TCP_UDP) ?
					       "SELECTED" : "");
			} else if (!gstrcmp(name, "open_protocol_tcp")) {
				ifx_httpdWrite(wp, T("%s"),
					       port_trigger.open_protocol ==
					       NAT_VS_PROTOCOL_TCP ? "SELECTED"
					       : "");
			} else if (!gstrcmp(name, "open_protocol_udp")) {
				ifx_httpdWrite(wp, T("%s"),
					       port_trigger.open_protocol ==
					       NAT_VS_PROTOCOL_UDP ? "SELECTED"
					       : "");
			} else if (!gstrcmp(name, "open_protocol_tcp_udp")) {
				ifx_httpdWrite(wp, T("%s"),
					       port_trigger.open_protocol ==
					       (NAT_VS_PROTOCOL_TCP_UDP -
						NAT_VS_PROTOCOL_TCP_UDP) ?
					       "SELECTED" : "");
			} else if (!gstrcmp(name, "fenable")) {
				ifx_httpdWrite(wp, T("%s"),
					       port_trigger.f_enable ==
					       1 ? "CHECKED" : "");
			}
		}
	}

      IFX_Handler:
	return 0;
}

////////////////////////////////////////////////////////////////////////////
//vipul start

int ifx_get_nat_porttrigger_entries(int eid, httpd_t wp, int argc,
				    char_t ** argv);
int ifx_get_nat_porttrigger_entries(int eid, httpd_t wp, int argc,
				    char_t ** argv)
{
	int nIndex = 0;
	for (nIndex = 0;
	     nIndex < sizeof(web_Port_TriggerList) / sizeof(CGI_ENUMSEL_S);
	     nIndex++) {
		if (nIndex == 0)
			ifx_httpdWrite(wp,
				       T
				       ("\t<option value=\"%d\" %s>%s</option>\n"),
				       nIndex, "SELECTED",
				       web_Port_TriggerList[nIndex].str);
		else
			ifx_httpdWrite(wp,
				       T
				       ("\t<option value=\"%d\" %s>%s</option>\n"),
				       nIndex, "",
				       web_Port_TriggerList[nIndex].str);
	}
	return 0;
}

int ifx_get_nat_portforward_entries(int eid, httpd_t wp, int argc,
				    char_t ** argv);
int ifx_get_nat_portforward_entries(int eid, httpd_t wp, int argc,
				    char_t ** argv)
{
	int nIndex = 0;
	for (nIndex = 0;
	     nIndex < sizeof(web_Port_ForwardList) / sizeof(CGI_ENUMSEL_S);
	     nIndex++) {
		if (nIndex == 0)
			ifx_httpdWrite(wp,
				       T
				       ("\t<option name=\"srvname%d\" value=\"%d\" %s>%s</option>\n"),
				       nIndex, nIndex, "SELECTED",
				       web_Port_ForwardList[nIndex].str);
		else
			ifx_httpdWrite(wp,
				       T
				       ("\t<option name=\"srvname%d\" value=\"%d\" %s>%s</option>\n"),
				       nIndex, nIndex, "",
				       web_Port_ForwardList[nIndex].str);
	}
	return 0;
}

//vipul end
///////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////
//vipul start

void ifx_set_nat_porttrigger(httpd_t wp, char_t * path, char_t * query);
void ifx_set_nat_porttrigger(httpd_t wp, char_t * path, char_t * query)
{
	int32 ret = IFX_SUCCESS, flags = IFX_F_DEFAULT, operation = 0;
	int32 cpeId = 0;
	// int32   pIndex;
	char8 *action_type = NULL;
	//    char8   *pindex = NULL;
	char8 *Appl_NAME;
	char8 *scpeId = NULL, *status = NULL, sbuf[MAX_FILELINE_LEN];
	char8 *pprotocol = NULL, *popen_protocol = NULL, *ptrigger_sport =
	    NULL, *ptrigger_eport = NULL, *pexternal_sport =
	    NULL, *pexternal_eport = NULL, *retVal = NULL;
	PORT_TRIGGER port_trigger;

	a_assert(wp);

	memset(&port_trigger, 0x00, sizeof(port_trigger));
	memset(&sbuf, 0x00, sizeof(sbuf));

	action_type = ifx_httpdGetVar(wp, "natptAction", T(""));
	scpeId = ifx_httpdGetVar(wp, "cpeId_selected", T(""));

	if (!(gstrcmp(action_type, "Add_porttrigger"))) {

		strcpy(natptcpeId, scpeId);
		ifx_httpdRedirect(wp, "port_trigger_config.asp");
		return;
	} else if (!(gstrcmp(action_type, "Modify_porttrigger"))) {

		strcpy(natptcpeId, scpeId);
		ifx_httpdRedirect(wp, "port_trigger_mod.asp");
		return;
	} else if (!gstrcmp(action_type, "Delete")) {
		operation = IFX_OP_DEL;
		flags = IFX_F_DELETE;
	} else if (!gstrcmp(action_type, "Add")) {
		operation = IFX_OP_ADD;
		flags = IFX_F_DEFAULT;
	} else if (!gstrcmp(action_type, "Modify")) {
		operation = IFX_OP_MOD;
		flags = IFX_F_DEFAULT;
	}

	if (operation == IFX_OP_ADD || operation == IFX_OP_MOD) {
		//     port_trigger.iid.cpeId.Id = atoi(scpeId);
		port_trigger.iid.cpeId.Id = atoi(natptcpeId);
		port_trigger.iid.pcpeId.Id = 1;
		Appl_NAME = ifx_httpdGetVar(wp, "applicationname", T(""));
		strcpy(port_trigger.Application_Name, Appl_NAME);
		pprotocol = ifx_httpdGetVar(wp, "protocol", T(""));
		port_trigger.protocol = atoi(pprotocol);
		ptrigger_sport = ifx_httpdGetVar(wp, "trigger_sport", T(""));
		port_trigger.trigger_start_port = atoi(ptrigger_sport);
		ptrigger_eport = ifx_httpdGetVar(wp, "trigger_eport", T(""));
		port_trigger.trigger_end_port = atoi(ptrigger_eport);
		pexternal_sport = ifx_httpdGetVar(wp, "external_sport", T(""));
		port_trigger.external_start_port = atoi(pexternal_sport);
		pexternal_eport = ifx_httpdGetVar(wp, "external_eport", T(""));
		port_trigger.external_end_port = atoi(pexternal_eport);
		popen_protocol = ifx_httpdGetVar(wp, "open_protocol", T(""));
		port_trigger.open_protocol = atoi(popen_protocol);
		status = ifx_httpdGetVar(wp, "fenable", T(""));
		port_trigger.f_enable = atoi(status);
	} else if (operation == IFX_OP_DEL) {
		cpeId = atoi(scpeId);
		port_trigger.iid.cpeId.Id = cpeId;
		flags = IFX_F_DELETE;
		status = ifx_httpdGetVar(wp, "penable", T(""));
	}
/*
else if (operation == IFX_OP_MOD) {
                pindex = ifx_httpdGetVar(wp,"index",T(""));
                cpeId = atoi(scpeId);
                pIndex= atoi(pindex);
               port_trigger.iid.cpeId.Id = cpeId;
                sprintf(sbuf,"penable%d",pIndex);
                status = ifx_httpdGetVar(wp,sbuf,T(""));
                ret=ifx_get_port_trigger_info(&port_trigger);
                port_trigger.f_enable = atoi(status);
      }
*/

	//disable case
	if ((status) && (!gstrcmp(status, "1"))) {
	} else {

		if (operation == IFX_OP_ADD)
			flags |= (IFX_F_DONT_ACTIVATE | IFX_F_DONT_VALIDATE);
		else if (operation == IFX_OP_MOD)
			flags |= (IFX_F_DEACTIVATE | IFX_F_DONT_VALIDATE);
	}
	strncpy(port_trigger.iid.cpeId.secName, TAG_NAT_PORT_TRIGGER,
		strlen(TAG_NAT_PORT_TRIGGER));
	port_trigger.iid.config_owner = IFX_WEB;
	ret = ifx_set_port_trigger_info(operation, &port_trigger, flags);

	if (ret != IFX_SUCCESS) {
		ifx_httpdError(wp, 500, T("Failed to save"));
	}
// IFX_Handler:
	IFX_MEM_FREE(retVal)
	    ifx_httpdRedirect(wp, T("port_trigger.asp"));
}

//vipul end
//////////////////////////////////////////////////////////////

const int websGetPortNums(char_t * pData, ST_NAT_PORT_MAP_LIST * pstPortList)
{
	int i, nReturn = -1, nStartPort, nEndPort;
	long lPort;
	char_t *pNextToken = pData;
	char_t *pEnd;

	i = 0;
	while (*pNextToken) {
		EATW(pNextToken);
		if (*pNextToken == 0) {
			break;
		}
		// Get port from string to long
		lPort = gstrtol(pNextToken, &pEnd, 10);
		if (*pNextToken && pNextToken == pEnd) {
			goto fault;	// Null
		}

		EATW(pEnd);

		if (*pEnd == ';' || *pEnd == ',' || *pEnd == 0) {
			nStartPort = lPort;
			nEndPort = lPort;
		} else if (*pEnd == '-') {
			// Check dash here
			nStartPort = lPort;

			// Get end port
			pNextToken = pEnd + 1;
			EATW(pNextToken);

			lPort = gstrtol(pNextToken, &pEnd, 10);

			if (*pNextToken && pNextToken == pEnd) {
				goto fault;	// Null
			}

			EATW(pEnd);

			nEndPort = lPort;
		} else {
			goto fault;
		}

		// Insert to list queue
		if (nStartPort > nEndPort || nStartPort < 1 || nEndPort > 65535) {
			goto fault;
		}

		if (i >= NAT_VS_CLONE_NUM) {
			nReturn = -2;
			goto fault;
		}

		gsprintf(pstPortList[i].sRetValue, T("%d:%d"), nStartPort,
			 nEndPort);

		// Advanced to next clone index
		i++;

		// Continue for next port range
		if (*pEnd == 0) {
			break;
		}
		pNextToken = pEnd + 1;
	}			//end while(*pNextToken)

	return i;

      fault:
	return nReturn;
}

#ifdef CONFIG_FEATURE_NAPT
void ifx_set_nat_main(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pCheck;

	a_assert(wp);

	// Get value from ASP filz
	pCheck = ifx_httpdGetVar(wp, T("NATStatus"), T(""));

	ifx_set_global_nat(atoi(pCheck), IFX_F_MODIFY);
	if (ifx_set_global_nat(atoi(pCheck), IFX_F_MODIFY) != IFX_SUCCESS) {
		ifx_httpdWrite(wp,
			       T
			       ("<html><br><br><br><br><subtitle><b>Failed to Set the NAT Status !!</b><br><br><br><br>"));
		ifx_httpdWrite(wp,
			       T
			       ("<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"));
		ifx_httpdWrite(wp,
			       T
			       ("<tr><td><div align=\"right\"><a href=\"javascript:void(0);\" onClick=\"window.open('help.htm#nat','help', 'toolbar=0,status=0,menubar=0,scrollbars=1,resizable=1,width=530,height=400,left=150,top=150');\"><img src=\"images/help.gif\" width=\"57\" height=\"57\" border=\"0\"></a>"));
		ifx_httpdWrite(wp,
			       T
			       ("<a href=\"javascript:history.back();\"><img src=\"images/cancel.gif\" alt border=\"0\" width=\"56\" height=\"57\"></a>"));
		ifx_httpdWrite(wp, T("</div> </td> </tr> </table>"));
	}
	websNextPage(wp);
}

//////////////////////////////////////////////////////////////////////////////////
// nat_virtualser.asp
//vipul start
void ifx_set_nat_virtualser(httpd_t wp, char_t * path, char_t * query)
{
	int32 ret = IFX_SUCCESS, flags = IFX_F_DEFAULT, operation = 0;
	int32 i = 0, count = 0, outFlag = IFX_F_DEFAULT, cpeId = 0;
	char8 buf[MAX_FILELINE_LEN], *action_type = NULL, *pFunc =
	    NULL, *sServerIP = NULL, buf1[MAX_FILELINE_LEN];
	char8 sValue[MAX_FILELINE_LEN], *pPriIP1 = NULL, *pPriIP2 =
	    NULL, *pPriIP3 = NULL, *pPriIP4 = NULL, *pRemIP = NULL, *pPriPort =
	    NULL, *Appl_NAME = NULL;
	char8 *wan_conn_name = NULL, *scpeId = NULL, wan_conn_if[IFNAMSIZE];
	char8 *pPriType = NULL, *pPubPort = NULL, *retVal = NULL;
	char8 *pQosEnable = NULL, *pMinBandwidth = NULL, *pMaxBandwidth = NULL;
	WAN_TYPE wan_type = WAN_TYPE_IP;
	VIRTUAL_SERVER virtual;

	a_assert(wp);

	memset(&virtual, 0x00, sizeof(virtual));
	wan_conn_if[0] = '\0';

	action_type = ifx_httpdGetVar(wp, "natvsAction", T(""));
	scpeId = ifx_httpdGetVar(wp, "cpeId_selected", T(""));
	if (!(gstrcmp(action_type, "Add_portmap"))) {
		strcpy(natvsAction, action_type);
		strcpy(natcpeId, scpeId);
		ifx_httpdRedirect(wp, "nat_virtualser_add.asp");
		return;
	} else if (!(gstrcmp(action_type, "Modify_portmap"))) {
		strcpy(natvsAction, action_type);
		strcpy(natcpeId, scpeId);
		ifx_httpdRedirect(wp, "nat_virtualser_mod.asp");
		return;
	} else if (!gstrcmp(action_type, "Delete")) {
		operation = IFX_OP_DEL;
		flags = IFX_F_DELETE;
	} else if (!gstrcmp(action_type, "Modify")) {
		operation = IFX_OP_MOD;
		flags = IFX_F_MODIFY;
	} else if (!gstrcmp(action_type, "Add")) {
		operation = IFX_OP_ADD;
		flags = IFX_F_DEFAULT;
	}

	//Set NATVS_PIP# to rc.iptables.

	if (operation == IFX_OP_ADD || operation == IFX_OP_MOD) {
		struct in_addr ip, mask, network;

		virtual.iid.cpeId.Id = atoi(scpeId);
		virtual.iid.pcpeId.Id = 1;

		sprintf(buf, "Lan%d_IF_Info", 1);	// hard coded for First Lan Device
		if ((ret =
		     ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "IP",
				    IFX_F_GET_ANY, (IFX_OUT uint32 *) & outFlag,
				    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("\n\n In Function [%s] : Error-->Lan IP Address not found !!\n\n",
			     __FUNCTION__);
#endif
			ret = IFX_FAILURE;
		}
		ip.s_addr = inet_addr(sValue);

		sprintf(buf, "Lan%d_IF_Info", 1);	// hard coded for First Lan Device
		if ((ret =
		     ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "MASK",
				    IFX_F_GET_ANY, (IFX_OUT uint32 *) & outFlag,
				    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("\n\n In Function [%s] : Error-->Lan IP Address not found !!\n\n",
			     __FUNCTION__);
#endif
			ret = IFX_FAILURE;
		}
		mask.s_addr = inet_addr(sValue);

		network.s_addr = ip.s_addr & mask.s_addr;
		sprintf(sValue, "%s", inet_ntoa(network));

		memset(buf1, 0x00, sizeof(buf1));
		sServerIP = strtok(sValue, ".");
		while (sServerIP != NULL) {
			if (!gstrcmp(sServerIP, "0"))
				count++;
			else {
				strcat(buf1, sServerIP);
				strcat(buf1, ".");
			}
			sServerIP = strtok(NULL, ".");
		}
		buf1[strlen(buf1) - 1] = '\0';

		Appl_NAME = ifx_httpdGetVar(wp, "applicationname", T(""));
		strcpy(virtual.vs_desc, Appl_NAME);

		pPriIP1 = ifx_httpdGetVar(wp, T("NATVS_PIP1"), T(""));
		pPriIP2 = ifx_httpdGetVar(wp, T("NATVS_PIP2"), T(""));
		pPriIP3 = ifx_httpdGetVar(wp, T("NATVS_PIP3"), T(""));
		pPriIP4 = ifx_httpdGetVar(wp, T("NATVS_PIP4"), T(""));
		sprintf(buf1, "%s.%s.%s.%s", pPriIP1, pPriIP2, pPriIP3,
			pPriIP4);

/*      for (i = count; i > 0; i--) {
            gsprintf(buf, T("%s%d"), "NATVS_PIP", 5- i);
            pPriIP= ifx_httpdGetVar(wp, buf, T(""));
            strcat(buf1, ".");
            if (pPriIP == NULL || strlen(pPriIP) == 0)
                strcat(buf1, "0");
            else
                strcat(buf1, pPriIP);
        }
*/
		virtual.private_ip.s_addr = inet_addr(buf1);

		//Set NATVS_RIP# to rc.iptables.
		memset(buf1, 0x00, sizeof(buf1));
		for (i = 1; i <= 4; i++) {
			gsprintf(buf, T("%s%d"), "NATVS_RIP", i);
			pRemIP = ifx_httpdGetVar(wp, buf, T(""));
			strcat(buf1, pRemIP);
			strcat(buf1, ".");
		}
		buf1[strlen(buf1) - 1] = '\0';	/* remove the last extra dot !! */
		if (!gstrcmp(buf1, "..."))
			sprintf(buf1, "%s", "0.0.0.0");
		virtual.remote_ip.s_addr = inet_addr(buf1);

		//Set NATVS_PPORT# to rc.iptables.
		pPriPort = ifx_httpdGetVar(wp, "NATVS_sPPORT", T(""));
		virtual.private_sport = gatoi(pPriPort);
		pPriPort = ifx_httpdGetVar(wp, "NATVS_ePPORT", T(""));
		virtual.private_eport = gatoi(pPriPort);

		//Set NATVS_PTYPE# to rc.iptables.
		pPriType = ifx_httpdGetVar(wp, "NATVS_PTYPE", T(""));

		if (pPriType[0]) {
			if (!gstrcmp(pPriType, T("1"))) {
				virtual.protocol = gatoi(pPriType);
			} else if (!gstrcmp(pPriType, T("2"))) {
				virtual.protocol = gatoi(pPriType);
			} else if (!gstrcmp(pPriType, T("3"))) {
				virtual.protocol = gatoi(pPriType);
			}
		} else {
			virtual.protocol = gatoi(pPriType);
		}

		//Set NATVS_PUPORT# to rc.iptables.
		pPubPort = ifx_httpdGetVar(wp, "NATVS_sPUPORT", T(""));
		virtual.public_sport = gatoi(pPubPort);
		pPubPort = ifx_httpdGetVar(wp, "NATVS_ePUPORT", T(""));
		virtual.public_eport = gatoi(pPubPort);

		/* Set NATVS_QOS_ENABLE#, NATVS_MIN_BW#, and NATVS_MAX_BW# to rc.iptables. */
		pQosEnable = ifx_httpdGetVar(wp, "NATVS_UP_QOS_ENABLE", T(""));
		if (!gstrcmp(pQosEnable, T("1")))
			virtual.up_qos.qos_enabled = 1;
		else
			virtual.up_qos.qos_enabled = 0;

		pMinBandwidth = ifx_httpdGetVar(wp, "NATVS_UP_MIN_BW", T(""));
		virtual.up_qos.min_bw = gatoi(pMinBandwidth);

		pMaxBandwidth = ifx_httpdGetVar(wp, "NATVS_UP_MAX_BW", T(""));
		virtual.up_qos.max_bw = gatoi(pMaxBandwidth);

		/* Set NATVS_DN_QOS_ENABLE, NATVS_DN_MIN_BW, and NATVS_DN_MAX_BW to rc.iptables. */
		pQosEnable = ifx_httpdGetVar(wp, "NATVS_DN_QOS_ENABLE", T(""));
		if (!gstrcmp(pQosEnable, T("1")))
			virtual.dn_qos.qos_enabled = 1;
		else
			virtual.dn_qos.qos_enabled = 0;

		pMinBandwidth = ifx_httpdGetVar(wp, "NATVS_DN_MIN_BW", T(""));
		virtual.dn_qos.min_bw = gatoi(pMinBandwidth);

		pMaxBandwidth = ifx_httpdGetVar(wp, "NATVS_DN_MAX_BW", T(""));
		virtual.dn_qos.max_bw = gatoi(pMaxBandwidth);

		//Set NATVS_F# to rc.iptables.
		gsprintf(buf, T("NATVS_F"));
		pFunc = ifx_httpdGetVar(wp, "NATVS_F", T(""));
		if (!gstrcmp(pFunc, "1")) {
			virtual.f_enable = IFX_ENABLED;
		} else {

			virtual.f_enable = IFX_DISABLED;
			// Pass the Disable flags to hash out the entry in rc.conf
			if (operation == IFX_OP_ADD)
				flags |=
				    (IFX_F_DONT_ACTIVATE | IFX_F_DONT_VALIDATE);
			else if (operation == IFX_OP_MOD)
				flags |= IFX_F_DEACTIVATE;
		}

	}			// IFX_OP_ADD or IFX_OP_MOD
	if (operation == IFX_OP_ADD || operation == IFX_OP_MOD) {
		wan_conn_name = ifx_httpdGetVar(wp, "NATVS_WAN_CONN", T(""));
		if (strstr(wan_conn_name, "WANIP"))
			wan_type = WAN_TYPE_IP;
		else if (strstr(wan_conn_name, "WANPPP"))
			wan_type = WAN_TYPE_PPP;

		sprintf(wan_conn_if, "%s", wan_conn_name);
		if (strlen(wan_conn_if) < 1) {
			ifx_httpdError(wp, 400,
				       T
				       ("No wan connection with [%s] name found !!"),
				       wan_conn_name);
			return;
		}
	}
	if (operation == IFX_OP_DEL) {
		wan_conn_name =
		    ifx_httpdGetVar(wp, T("wanConnName_selected"), T(""));
		sprintf(virtual.wan_conn_if, "%s", wan_conn_name);
		if (strstr(wan_conn_name, "WANIP"))
			wan_type = WAN_TYPE_IP;
		else if (strstr(wan_conn_name, "WANPPP"))
			wan_type = WAN_TYPE_PPP;
	}
	//strncpy(virtual.wan_conn_if, wan_conn_if, strlen(wan_conn_if));
	if ((ret =
	     ifx_ret_substr_from_distfield(FILE_RC_CONF,
					   wan_type ==
					   WAN_TYPE_IP ? TAG_WAN_IP :
					   TAG_WAN_PPP, "connName",
					   wan_conn_name,
					   &retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\nIn Function [%s] : Error--> No wan connection exists with the name [%s] !!\n\n",
		     __FUNCTION__, wan_conn_name);
#endif
		IFX_MEM_FREE(retVal)
		    return;
	}
	sprintf(buf, "%s_cpeId", retVal);
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF,
			    wan_type == WAN_TYPE_IP ? TAG_WAN_IP : TAG_WAN_PPP,
			    buf, IFX_F_GET_ANY, (IFX_OUT uint32 *) & outFlag,
			    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\nIn Function [%s] : Error--> Failed to get the cpeid for the wan connection [%s] !!\n\n",
		     __FUNCTION__, wan_conn_name);
#endif
		IFX_MEM_FREE(retVal)
		    return;
	}

	/* Parent section name compulsory */
	sprintf(virtual.iid.pcpeId.secName, "%s", wan_type == WAN_TYPE_IP ? TAG_WAN_IP : TAG_WAN_PPP);

	strncpy(virtual.iid.cpeId.secName, TAG_NAT_VIRTUALSER, strlen(TAG_NAT_VIRTUALSER));

	/* Parent cpeId compulsory */
	if (operation == IFX_OP_ADD || operation == IFX_OP_MOD) {
		LTQ_STRNCPY(virtual.wan_conn_if, wan_conn_if, MAX_CONN_NAME_LEN-1);
		virtual.iid.pcpeId.Id = atoi(sValue);
	}			// IFX_OP_ADD or IFX_OP_MOD
	else if (operation == IFX_OP_DEL) {
		cpeId = atoi(scpeId);
		virtual.iid.cpeId.Id = cpeId;
	}
	virtual.iid.config_owner = IFX_WEB;

	sprintf(buf, "%s_wanMode", retVal);
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF,
			    wan_type == WAN_TYPE_IP ? TAG_WAN_IP : TAG_WAN_PPP,
			    buf, IFX_F_GET_ANY, (IFX_OUT uint32 *) & outFlag,
			    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\nIn Function [%s] : Error--> Failed to get the wan mode value for the wan connection [%s] !!\n\n",
		     __FUNCTION__, wan_conn_name);
#endif
		IFX_MEM_FREE(retVal)
		    return;
	}


#if defined(CONFIG_FEATURE_CELL_WAN_SUPPORT)
	/* Attention : Connection name WANPPP0 is always 3G WAN. Any change in name has to be taken care manually here */
	if(!strcmp(virtual.wan_conn_if, "WANPPP0")) {
		ret = ifx_set_virtual_server_info_Without_TR69(operation, &virtual, flags);
	}
	else {
		ret = ifx_set_virtual_server_info(operation, &virtual, flags);
	}
#else
	if(atoi(sValue) == 7 ){
	ret = ifx_set_virtual_server_info_Without_TR69(operation, &virtual, flags);
	}
	else{
		ret = ifx_set_virtual_server_info(operation, &virtual, flags);
	}
#endif

	if (ret != IFX_SUCCESS) {
		COPY_TO_STATUS("%s",
			       "<span class=\"textTitle\">Failed to configure the virtual server rule.</span>");
		ifx_httpdRedirect(wp, "err_page.html");
	}

      IFX_Handler:
	IFX_MEM_FREE(retVal)
	ifx_httpdRedirect(wp, T("nat_virtualser.asp"));
}

//vipul end

//////////////////////////////////////////////////////////////////////////////////
// nat_portmap.asp
//
#ifdef NAT_PORTMAP
void ifx_set_nat_portmap(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pCloneIP, *pClonePort, *pCloneEnable, *buffer;
	char_t sServerIP[MAX_DATA_LEN], buf[MAX_FILELINE_LEN];
	char_t sCloneIP[NAT_VS_LINK_NUM][MAX_FILELINE_LEN],
	    sClonePort[NAT_VS_LINK_NUM][MAX_FILELINE_LEN];
	char_t sCloneEnable[NAT_VS_LINK_NUM][MAX_FILELINE_LEN];
	char_t sSerialPort[NAT_VS_CLONE_NUM][MAX_DATA_LEN],
	    sPortsNum[NAT_VS_LINK_NUM][MAX_DATA_LEN];
	int i, idx, nRetNum[NAT_VS_LINK_NUM];
	ST_NAT_PORT_MAP_LIST stPortList[NAT_VS_CLONE_NUM];
	//char_t  *pWanIface = NULL;
	char_t sCommand[MAX_DATA_LEN];

	a_assert(wp);

	for (i = 0; i < NAT_VS_LINK_NUM; i++) {
		//Set CLONE_IP# to rc.iptables.
		memset(sCloneIP[i], 0x00, sizeof(sCloneIP[i]));

		gsprintf(buf, T("CLONE_IP%d"), i + 1);
		pCloneIP = ifx_httpdGetVar(wp, buf, T(""));

		if (pCloneIP[0]) {
			sServerIP[0] = '\0';
			websGetIFInfo(LAN_IF_TYPE, IP_INFO, 1, 3, FALSE, NULL,
				      sServerIP);
			gsprintf(sCloneIP[i], T("%s=\"%s%s\"\n"), buf,
				 sServerIP, pCloneIP);
		} else {
			gsprintf(sCloneIP[i], T("%s=\"\"\n"), buf);
		}
		trace(8, T("%s\n"), sCloneIP[i]);

		//Set CLONE_PORTS# to rc.iptables.
		memset(sClonePort[i], 0x00, sizeof(sClonePort[i]));
		gsprintf(buf, T("CLONE_PORTS%d"), i + 1);
		pClonePort = ifx_httpdGetVar(wp, buf, T(""));

		if (pClonePort[0]) {
			gsprintf(sClonePort[i], T("%s=\"%s\"\n"), buf,
				 pClonePort);
		} else {
			gsprintf(sClonePort[i], T("%s=\"0\"\n"), buf);
		}
		trace(8, T("%s\n"), sClonePort[i]);

		//Set CLONE_ENABLE# to rc.iptables.
		memset(sCloneEnable[i], 0x00, sizeof(sCloneEnable[i]));

		gsprintf(buf, T("CLONE_ENABLE%d"), i + 1);
		pCloneEnable = ifx_httpdGetVar(wp, buf, T(""));

		if (!gstrcmp(pCloneEnable, "1")) {
			if ((pCloneIP && *pCloneIP)
			    && (pClonePort && *pClonePort)) {
				gsprintf(sCloneEnable[i], T("%s=\"%s\"\n"), buf,
					 pCloneEnable);
			} else {
				gsprintf(sCloneEnable[i], T("%s=\"0\"\n"), buf);
			}
		} else {
			gsprintf(sCloneEnable[i], T("%s=\"0\"\n"), buf);
		}
		trace(8, T("%s\n"), sCloneEnable[i]);
	}

	buffer = (char_t *) malloc(sizeof(char_t) * (BUF_SIZE_50K));
	gstrcpy(buffer, "");
	gsprintf(buf, T("CLONE_NUM=\"%d\"\n"), NAT_VS_LINK_NUM);
	gstrcat(buffer, buf);

	for (i = 0; i < NAT_VS_LINK_NUM; i++) {
		gstrcat(buffer, sCloneIP[i]);
		gstrcat(buffer, sClonePort[i]);

		//Set CLONE_PORTS#_NUM to rc.iptables.
		for (idx = 0; idx < NAT_VS_CLONE_NUM; idx++) {
			stPortList[idx].nRangeIdx = 0;
			memset(stPortList[idx].sRetValue, 0x00,
			       sizeof(stPortList[idx].sRetValue));
		}
		nRetNum[i] = -1;
		gsprintf(buf, T("CLONE_PORTS%d"), i + 1);
		pClonePort = ifx_httpdGetVar(wp, buf, T(""));

		nRetNum[i] = websGetPortNums(pClonePort, stPortList);
		memset(sPortsNum[i], 0x00, sizeof(sPortsNum[i]));

		if (nRetNum[i] == -1) {
			//ifx_httpdError(wp, 204, T("Mapping port Input format error!"));
			gsprintf(sPortsNum[i], T("CLONE_PORTS%d_NUM=\"0\"\n"),
				 i + 1);
			gstrcat(buffer, sPortsNum[i]);
		} else if (nRetNum[i] == -2) {
			//ifx_httpdError(wp, 204, T("Cannot not set more than %d sets of ports!"), NAT_VS_CLONE_NUM);
			gsprintf(sPortsNum[i], T("CLONE_PORTS%d_NUM=\"0\"\n"),
				 i + 1);
			gstrcat(buffer, sPortsNum[i]);
		} else if (nRetNum[i] > 0) {
			gsprintf(sPortsNum[i], T("CLONE_PORTS%d_NUM=\"%d\"\n"),
				 i + 1, nRetNum[i]);
			gstrcat(buffer, sPortsNum[i]);

			for (idx = 0; idx < NAT_VS_CLONE_NUM; idx++) {
				memset(sSerialPort[idx], 0x00,
				       sizeof(sSerialPort[idx]));
			}

			for (idx = 0; idx < nRetNum[i]; idx++) {
				gsprintf(sSerialPort[idx],
					 T("CLONE_PORTS%d_%d=\"%s\"\n"), i + 1,
					 idx + 1, stPortList[idx].sRetValue);
				gstrcat(buffer, sSerialPort[idx]);
			}
		}

		gstrcat(buffer, sCloneEnable[i]);
	}
	trace(8, "buffer=%sEND\n", buffer);
	ifx_SetCfgData(FILE_RC_CONF, TAG_NAT_PORTMAP, 1, buffer);

	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}
#if 0
	if (buffer && *buffer)
		free(buffer);
#else
	IFX_MEM_FREE(buffer);
#endif
	//Runtime Change
	sprintf(sCommand, "%s --PMinit", NAPTCFG);
	system(sCommand);

	websNextPage(wp);
}
#endif
#endif				//CONFIG_FEATURE_NAPT

#ifdef CONFIG_FEATURE_NAPT
//////////////////////////////////////////////////////////////////////////////////
// firewall_dmz.asp
//
#ifdef ORGCODE
void ifx_set_firewall_dmz(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pCheck, *pDmzIP1, *pDmzIP2, *pDmzIP3, *pDmzIP4;
	char_t sCheck[MAX_FILELINE_LEN], sDmzIP[MAX_FILELINE_LEN];
	char_t sCommand[MAX_DATA_LEN];

	a_assert(wp);
	memset(sCheck, 0x00, sizeof(sCheck));
	memset(sDmzIP, 0x00, sizeof(sDmzIP));

	// Get value from ASP file
	pCheck = ifx_httpdGetVar(wp, T("C1"), T(""));
	pDmzIP1 = ifx_httpdGetVar(wp, T("dmzip1"), T(""));
	pDmzIP2 = ifx_httpdGetVar(wp, T("dmzip2"), T(""));
	pDmzIP3 = ifx_httpdGetVar(wp, T("dmzip3"), T(""));
	pDmzIP4 = ifx_httpdGetVar(wp, T("dmzip4"), T(""));

	if (!gstrcmp(pCheck, "1")) {
		gsprintf(sCheck, T("DMZ_ENABLE=\"%s\"\n"), pCheck);
		sprintf(sCommand, "%s --DMZ 1\n", NAPTCFG);
	} else {
		gsprintf(sCheck, T("DMZ_ENABLE=\"0\"\n"));
		sprintf(sCommand, "%s --DMZ 0\n", NAPTCFG);
	}
	gsprintf(sDmzIP, T("DMZ_HOST=\"%s.%s.%s.%s\"\n"), pDmzIP1, pDmzIP2,
		 pDmzIP3, pDmzIP4);

	ifx_SetCfgData(FILE_RC_CONF, TAG_FIREWALL_DMZ, 2, sCheck, sDmzIP);

	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}
	//Runtime Change
	system(sCommand);
	sprintf(sCommand, "%s --DMZinit\n", NAPTCFG);
	system(sCommand);

	websNextPage(wp);
}
#else
void ifx_set_firewall_dmz(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pCheck, *pDmzIP1, *pDmzIP2, *pDmzIP3, *pDmzIP4;
	char_t sDmzIP[MAX_FILELINE_LEN];

	IFX_MAPI_Firewall_DMZ dmz;

	a_assert(wp);
	memset(&dmz, 0x00, sizeof(dmz));
	memset(sDmzIP, 0x00, sizeof(sDmzIP));

	dmz.iid.config_owner = IFX_WEB;
	// Get value from ASP file
	pCheck = ifx_httpdGetVar(wp, T("C1"), T(""));
	pDmzIP1 = ifx_httpdGetVar(wp, T("dmzip1"), T(""));
	pDmzIP2 = ifx_httpdGetVar(wp, T("dmzip2"), T(""));
	pDmzIP3 = ifx_httpdGetVar(wp, T("dmzip3"), T(""));
	pDmzIP4 = ifx_httpdGetVar(wp, T("dmzip4"), T(""));

	gsprintf(sDmzIP, T("%s.%s.%s.%s"), pDmzIP1, pDmzIP2, pDmzIP3, pDmzIP4);

	dmz.feature_enable = atoi(pCheck);
	inet_aton(sDmzIP, &(dmz.ip));

	ifx_mapi_set_firewall_dmz(&dmz, IFX_F_MODIFY);

	websNextPage(wp);
}
#endif				//ORGCODE
#endif				//CONFIG_FEATURE_NAPT

#ifdef CONFIG_FEATURE_NAPT
int ifx_get_NATStatus(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 ret = IFX_SUCCESS;
	uint32 flags = IFX_F_GET_ENA;

	ret = ifx_get_global_nat(flags);
	if (ret < IFX_SUCCESS) {

		ifx_httpdError(wp, 400, "Insufficient Args !!\n");
	}

	ifx_httpdWrite(wp, T("%d"), ret);
	return 0;
}

//////////////////////////////////////////////////////////////////////////////////
// nat_virtualser.asp
//

int ifx_get_nat_virtualser_modified(int eid, httpd_t wp, int argc,
				    char_t ** argv)
{
	char_t buf[MAX_DATA_LEN];
	char_t sValue[MAX_FILELINE_LEN], sServerIP[MAX_DATA_LEN];
	char_t getCommand[MAX_FILELINE_LEN]/*, setCommand[MAX_FILELINE_LEN]*/;
	int i;
	int diffserv_vs_enable = 0;
//	setCommand[0] = '\0';
	sServerIP[0] = '\0';

	websGetIFInfo(LAN_IF_TYPE, IP_INFO, 1, 3, FALSE, NULL, sServerIP);

	//508103:tc.chen ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"diffserv_vs_enable\" value=\"%d\">\n"),diffserv_vs_enable);
	ifx_httpdWrite(wp,
		       T
		       ("<table border=0 cellspacing=1 cellpadding=5 width=425>\n"));
	ifx_httpdWrite(wp, T("<tr class=\"celltitle\">\n"));

	ifx_httpdWrite(wp, T("<th nowrap width=\"5%\">&nbsp;</th>\n"));
	ifx_httpdWrite(wp, T("<th nowrap width=\"25%\">Private IP</th>\n"));
	ifx_httpdWrite(wp, T("<th nowrap width=\"20%\">Private Port</th>\n"));
	ifx_httpdWrite(wp, T("<th nowrap width=\"15%\">Type</th>\n"));
	ifx_httpdWrite(wp, T("<th nowrap width=\"20%\">Public Port</th>\n"));
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_QOS_CONFIG, T("QOS_ENABLE"), sValue) != 0) {
		if (!gstrcmp(sValue, "1")) {
			if (ifx_GetCfgData
			    (FILE_RC_CONF, TAG_QOS_DIFFSERV_CONFIG,
			     T("DIFFSERV_VIRTUAL_SERVER"), sValue) != 0) {
				if (!gstrcmp(sValue, "1")) {
					diffserv_vs_enable = 1;
					ifx_httpdWrite(wp,
						       T
						       ("<th nowrap width=\"15%\">QoS</th>\n"));
				}
			}
		}
	}
	ifx_httpdWrite(wp, T("<th nowrap width=\"15%\">Enabled</th>\n"));
	ifx_httpdWrite(wp, T("</tr>\n<tr class=\"celltitle\">\n"));
	if (diffserv_vs_enable) {
		ifx_httpdWrite(wp, T("<th nowrap>Enable</th>\n"));
		ifx_httpdWrite(wp, T("<th nowrap>Min.Bandwidth</th>\n"));
		ifx_httpdWrite(wp, T("<th nowrap>Max.Bandwidth</th>\n"));
	}
	ifx_httpdWrite(wp,
		       T
		       ("</tr>\n<font size=\"2\" face=\"Arial, Helvetica, sans-serif\">\n"));
	//508103:tc.chen
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"diffserv_vs_enable\" value=\"%d\">\n"),
		       diffserv_vs_enable);

	for (i = 1; i <= NAT_RD_LINK_NUM; i++) {
		ifx_httpdWrite(wp, T("<tr align=center bgcolor=#ffffff>\n"));
		ifx_httpdWrite(wp, T("<td nowrap>%d</td>\n"), i);

		ifx_httpdWrite(wp, T("<td nowrap>%s"), sServerIP);
		gsprintf(buf, T("NATVS_PIP%d"), i);
		gsprintf(getCommand,
			 T("grep \"%s\" %s | cut -f2 -d\\\" | cut -f4 -d."),
			 buf, FILE_RC_CONF);
		if (ifx_GetCfgData((char_t *) getCommand, NULL, "1", sValue) ==
		    0)
			ifx_httpdWrite(wp,
				       T
				       ("<input maxlength=\"3\" name=\"%s\" size=\"3\" value=\"\"></td>\n"),
				       buf);
		else
			ifx_httpdWrite(wp,
				       T
				       ("<input maxlength=\"3\" name=\"%s\" size=\"3\" value=\"%s\"></td>\n"),
				       buf, sValue);

		ifx_httpdWrite(wp, T("<td nowrap>"));
		gsprintf(buf, T("NATVS_PPORT%d"), i);
		gsprintf(getCommand, T("grep \"%s\" %s | cut -f2 -d\\\""), buf,
			 FILE_RC_CONF);
		if (ifx_GetCfgData((char_t *) getCommand, NULL, "1", sValue) ==
		    0)
			ifx_httpdWrite(wp,
				       T
				       ("<input maxLength=\"5\" name=\"%s\" size=\"6\" value=\"\"></td>\n"),
				       buf);
		else
			ifx_httpdWrite(wp,
				       T
				       ("<input maxLength=\"5\" name=\"%s\" size=\"6\" value=\"%s\"></td>\n"),
				       buf, sValue);
		ifx_httpdWrite(wp, T("<td nowrap>\n"));

		gsprintf(buf, T("NATVS_PTYPE%d"), i);
		if ((ifx_GetCfgData
		     (FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf, sValue) == 0)
		    || !gstrcmp(sValue, PROTOCOL_TYPE_TCP)) {
			ifx_httpdWrite(wp,
				       T
				       ("\t<input type=\"radio\" name=\"%s\" value=\"1\"%s>TCP\n"),
				       buf, " CHECKED");
			ifx_httpdWrite(wp,
				       T
				       ("\t<input type=\"radio\" name=\"%s\" value=\"2\">UDP\n</td>\n"),
				       buf);
		} else if (!gstrcmp(sValue, PROTOCOL_TYPE_UDP)) {
			ifx_httpdWrite(wp,
				       T
				       ("\t<input type=\"radio\" name=\"%s\" value=\"1\">TCP\n"),
				       buf);
			ifx_httpdWrite(wp,
				       T
				       ("\t<input type=\"radio\" name=\"%s\" value=\"2\"%s>UDP\n</td>\n"),
				       buf, " CHECKED");
		}

		ifx_httpdWrite(wp, T("<td nowrap>"));
		gsprintf(buf, T("NATVS_PUPORT%d"), i);
		gsprintf(getCommand, T("grep \"%s\" %s | cut -f2 -d\\\""), buf,
			 FILE_RC_CONF);
		if (ifx_GetCfgData((char_t *) getCommand, NULL, "1", sValue) ==
		    0)
			ifx_httpdWrite(wp,
				       T
				       ("<input maxLength=\"5\" name=\"%s\" size=\"6\" value=\"\"></td>\n"),
				       buf);
		else
			ifx_httpdWrite(wp,
				       T
				       ("<input maxLength=\"5\" name=\"%s\" size=\"6\" value=\"%s\"></td>\n"),
				       buf, sValue);

		if (diffserv_vs_enable) {
			ifx_httpdWrite(wp, T("<td nowrap>"));
			gsprintf(buf, T("NATVS_QOS_ENABLE%d"), i);
			if ((ifx_GetCfgData
			     (FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,
			      sValue) == 0) || (gstrcmp(sValue, "1")))
				ifx_httpdWrite(wp,
					       T
					       ("<input type=\"checkbox\" name=\"%s\" value=\"1\"></td>\n"),
					       buf);
			else
				ifx_httpdWrite(wp,
					       T
					       ("<input type=\"checkbox\" name=\"%s\" value=\"1\"%s></td>\n"),
					       buf, " CHECKED");

			ifx_httpdWrite(wp, T("<td nowrap>"));
			gsprintf(buf, T("NATVS_MIN_BW%d"), i);
			gsprintf(getCommand,
				 T("grep \"%s\" %s | cut -f2 -d\\\""), buf,
				 FILE_RC_CONF);
			if (ifx_GetCfgData
			    ((char_t *) getCommand, NULL, "1", sValue) == 0)
				ifx_httpdWrite(wp,
					       T
					       ("<input maxLength=\"3\" name=\"%s\" size=\"6\" value=\"\">%%</td>\n"),
					       buf);
			else
				ifx_httpdWrite(wp,
					       T
					       ("<input maxLength=\"3\" name=\"%s\" size=\"6\" value=\"%s\">%%</td>\n"),
					       buf, sValue);

			ifx_httpdWrite(wp, T("<td nowrap>"));
			gsprintf(buf, T("NATVS_MAX_BW%d"), i);
			gsprintf(getCommand,
				 T("grep \"%s\" %s | cut -f2 -d\\\""), buf,
				 FILE_RC_CONF);
			if (ifx_GetCfgData
			    ((char_t *) getCommand, NULL, "1", sValue) == 0)
				ifx_httpdWrite(wp,
					       T
					       ("<input maxLength=\"3\" name=\"%s\" size=\"6\" value=\"\">%%</td>\n"),
					       buf);
			else
				ifx_httpdWrite(wp,
					       T
					       ("<input maxLength=\"3\" name=\"%s\" size=\"6\" value=\"%s\">%%</td>\n"),
					       buf, sValue);
		}
		ifx_httpdWrite(wp, T("<td nowrap>"));
		//Get f# value from rc.conf file.
		gsprintf(buf, T("NATVS_F%d"), i);
		if ((ifx_GetCfgData
		     (FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf, sValue) == 0)
		    || (gstrcmp(sValue, "1")))
			ifx_httpdWrite(wp,
				       T
				       ("\t<input type=\"checkbox\" name=\"%s\" value=\"1\"></td>\n"),
				       buf);
		else
			ifx_httpdWrite(wp,
				       T
				       ("\t<input type=\"checkbox\" name=\"%s\" value=\"1\"%s></td>\n"),
				       buf, " CHECKED");

		ifx_httpdWrite(wp, T("</tr>\n"));
	}

	ifx_httpdWrite(wp, T("</font>\n</table>\n"));
	return 0;
}

int32 ifx_get_network_ip_and_textbox_count(char network[], int *count)
{
	char8 buf[40], sValue[40], *sServerIP = NULL;
	int32 flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT, ret =
	    IFX_SUCCESS, t_count = 0;
	struct in_addr ip, mask, t_network;

	t_count = 0;

	sprintf(buf, "Lan%d_IF_Info", 1);	// hard coded for First Lan Device
	if ((ret =
	     ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "IP", flags,
			    (IFX_OUT uint32 *) & outFlag,
			    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error-->Lan IP Address not found !!\n\n",
		     __FUNCTION__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	ip.s_addr = inet_addr(sValue);

	sprintf(buf, "Lan%d_IF_Info", 1);	// hard coded for First Lan Device
	if ((ret =
	     ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "MASK", flags,
			    (IFX_OUT uint32 *) & outFlag,
			    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error-->Lan IP Address not found !!\n\n",
		     __FUNCTION__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	mask.s_addr = inet_addr(sValue);

	t_network.s_addr = ip.s_addr & mask.s_addr;
	sprintf(sValue, "%s", inet_ntoa(t_network));

	memset(network, 0x00, sizeof(network));
	sServerIP = strtok(sValue, ".");
	while (sServerIP != NULL) {
		if (!gstrcmp(sServerIP, "0"))
			t_count++;
		else {
			strcat(network, sServerIP);
			strcat(network, ".");
		}
		sServerIP = strtok(NULL, ".");
	}
	*count = t_count;
      IFX_Handler:
	if (ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}

// int32 ifx_get_ip_network_address(char8 *net_ipaddr)
int32 ifx_get_ip_addr_format(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char8 buf[40], *name = NULL;
	int32 count = 0, i = 0;

	buf[0] = '\0';

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, "Insufficient Args !!\n");
		return IFX_FAILURE;
	}

	ifx_get_network_ip_and_textbox_count(buf, &count);

	if (!gstrcmp(name, "pip_indices")) {
		for (i = count; i > 0; i--) {
			ifx_httpdWrite(wp, T("%d,"), (5 - i));
		}
	} else {
		ifx_httpdWrite(wp, T("\t\t\t\t%s"), buf);
//              for(i=1; i<=(4 - count); i++) {
		for (i = count; i > 0; i--) {
			ifx_httpdWrite(wp,
				       T
				       ("<input name=\"%s%d\" maxLength=\"3\" size=\"3\" value=\"1\">"),
				       name, (5 - i));
			if (i > 1)
				ifx_httpdWrite(wp, T("."));
//                      ifx_httpdWrite(wp, T("<input name=\"%s%d\" maxLength=\"3\" size=\"3\">."), name, i + 1);
		}
	}

	return 0;
}

int32 ifx_get_nat_operation(int eid, httpd_t wp, int argc, char_t ** argv)
{
	if (strlen(natcpeId) > 0)
		ifx_httpdWrite(wp, T("Modify"));
	else
		ifx_httpdWrite(wp, T("Add"));

	return 0;
}

int ifx_get_qos_supported(int eid, httpd_t wp, int argc, char_t ** argv)
{
#ifdef CONFIG_FEATURE_QOS
	uint32 flags = IFX_F_GET_ENA, outFlag = IFX_F_DEFAULT;
	char_t sValue[MAX_FILELINE_LEN], *name = NULL;

	sValue[0] = '\0';

#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s] called !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", __FUNCTION__);
#endif
	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdWrite(wp, "0");
		return 0;
	}

	if (ifx_GetObjData
	    (FILE_RC_CONF, TAG_QOS_CONFIG, T("QOS_ENABLE"), flags, &outFlag,
	     sValue) == IFX_SUCCESS) {
		if (atoi(sValue) == 1) {
			sValue[0] = '\0';
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_QOS_DIFFSERV_CONFIG,
			     T("DIFFSERV_VIRTUAL_SERVER"), flags, &outFlag,
			     sValue) != IFX_SUCCESS) {
				ifx_httpdWrite(wp, "0");
			} else {
				if (atoi(sValue) == 0) {
					ifx_httpdWrite(wp, "0");
				} else {
					ifx_httpdWrite(wp, "1");
				}
			}
		} else {
			ifx_httpdWrite(wp, "0");
		}
	} else {
		ifx_httpdWrite(wp, "0");
	}

	return 0;

#else

	ifx_httpdWrite(wp, "0");
	return 0;
#endif				// CONFIG_FEATURE_QOS
}

void ifx_get_nat_vs_bandwidth(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 ret = IFX_SUCCESS, num_entries = 0, up_min_bw = 0, dn_min_bw =
	    0, i = 0;
	char_t *name;
	VIRTUAL_SERVER *virtual = NULL;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdWrite(wp, T("-1"));
		return;
	}

	if ((ret =
	     ifx_get_virtual_server_info(&num_entries, &virtual,
					 IFX_F_GET_ENA)) != IFX_SUCCESS) {
		ifx_httpdWrite(wp, T("-1"));
		IFX_MEM_FREE(virtual)
		    return;
	}

	for (i = 0; i < num_entries; i++) {
		up_min_bw += (virtual + i)->up_qos.min_bw;
		dn_min_bw += (virtual + i)->dn_qos.min_bw;
	}

	if (!gstrcmp(name, "up_min_bw")) {
		ifx_httpdWrite(wp, T("%d"), up_min_bw);
	}
	if (!gstrcmp(name, "dn_min_bw")) {
		ifx_httpdWrite(wp, T("%d"), dn_min_bw);
	}

	IFX_MEM_FREE(virtual);
	return;
}

int ifx_get_nat_virtualser_data(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char8 *name =
	    NULL, buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN], *sServerIP =
	    NULL, *retVal = NULL;
	int32 ret = IFX_SUCCESS, num_entries = 0, i = 0, flags = IFX_F_DEFAULT;
	int32 count = 0, j = 0, diffserv_vs_enable = 0, diffserv_done = 0;
	char8 *wan_conn_names = NULL, wan_conn_name[MAX_FILELINE_LEN];
	uint32 outFlag = IFX_F_DEFAULT;
	VIRTUAL_SERVER *virtual = NULL;

	sValue[0] = '\0';
	buf[0] = '\0';

	if ((ret =
	     ifx_get_virtual_server_info(&num_entries, &virtual,
					 flags)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get the virtual server info !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}

	sprintf(buf, "Lan%d_IF_Info", 1);	// hard coded for First Lan Device
	if ((ret =
	     ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "IP", flags, &outFlag,
			    sValue)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}

	diffserv_done = 0;
	for (i = 0; i < num_entries; i++) {

		if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		}

		if (!gstrcmp(name, "diffserv_vs_enable") && !diffserv_done) {
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_QOS_CONFIG, T("QOS_ENABLE"),
			     flags, &outFlag, sValue) == IFX_SUCCESS) {
				if (!gstrcmp(sValue, "1")) {
					if (ifx_GetObjData
					    (FILE_RC_CONF,
					     TAG_QOS_DIFFSERV_CONFIG,
					     T("DIFFSERV_VIRTUAL_SERVER"),
					     IFX_F_DEFAULT, &outFlag,
					     sValue) == IFX_SUCCESS) {
						if (!gstrcmp(sValue, "1")) {
							diffserv_vs_enable = 1;
						}
					}
				}
			}
			ifx_httpdWrite(wp, T("%d"), diffserv_vs_enable);
			diffserv_done = 1;
		}

		if (atoi(natcpeId) == (virtual + i)->iid.cpeId.Id) {
			/* cpe id match, populate the fields in nat_portmap_add.asp */
			if (!gstrcmp(name, "cpeId"))
				ifx_httpdWrite(wp, T("%s"), natcpeId);
			else {

				ifx_get_network_ip_and_textbox_count(buf,
								     &count);

				/*  if (!gstrcmp(name, "private_ip")) {
				   ifx_httpdWrite(wp, T("\t\t\t\t%s"), buf);
				   sprintf(sValue, "%s", (char8 *)inet_ntoa((virtual + i)->private_ip));
				   sServerIP = strtok(sValue, ".");
				   for (i = 0; i < (4 - count - 1); i++) {
				   sServerIP = strtok(NULL, ".");
				   }
				   for (i = 0; i < count; i++) {
				   sServerIP = strtok(NULL, ".");
				   ifx_httpdWrite(wp, T("<input name=\"NATVS_PIP%d\" maxLength=\"3\" size=\"3\" value=\"%s\">"), (5 - cou
				   nt + i), sServerIP);
				   if (i < (count - 1))
				   ifx_httpdWrite(wp, T("."));
				   }
				   } */
				if (!gstrncmp
				    (name, "private_ip",
				     strlen("private_ip"))) {
					sprintf(sValue, "%s",
						(char8 *)
						inet_ntoa((virtual +
							   i)->private_ip));
					sscanf(name, "private_ip%d", &count);
					sServerIP = strtok(sValue, ".");
					if (i >= 0 && i < 32767) {
						for (i = 1; i < count; i++) {
							sServerIP =
							    strtok(NULL, ".");
						}
					}
					ifx_httpdWrite(wp, T("%s"), sServerIP);
				}

				else if (!gstrncmp
					 (name, "remote_ip",
					  strlen("remote_ip"))) {
					sprintf(sValue, "%s",
						(char8 *)
						inet_ntoa((virtual +
							   i)->remote_ip));
					sscanf(name, "remote_ip%d", &count);
					sServerIP = strtok(sValue, ".");
					for (i = 1; i < count; i++) {
						sServerIP = strtok(NULL, ".");
					}
					ifx_httpdWrite(wp, T("%s"), sServerIP);
				} else if (!gstrcmp(name, "application_name"))
					ifx_httpdWrite(wp, T("%s"),
						       (virtual + i)->vs_desc);
				else if (!gstrcmp(name, "private_sport"))
					ifx_httpdWrite(wp, T("%d"),
						       (virtual +
							i)->private_sport);
				else if (!gstrcmp(name, "private_eport"))
					ifx_httpdWrite(wp, T("%d"),
						       (virtual +
							i)->private_eport);
				else if (!gstrcmp(name, "public_sport"))
					ifx_httpdWrite(wp, T("%d"),
						       (virtual +
							i)->public_sport);
				else if (!gstrcmp(name, "public_eport"))
					ifx_httpdWrite(wp, T("%d"),
						       (virtual +
							i)->public_eport);
				else if (!gstrcmp(name, "protocol_tcp")) {
					ifx_httpdWrite(wp, T("%s"),
						       (virtual +
							i)->protocol ==
						       NAT_VS_PROTOCOL_TCP ?
						       "SELECTED" : "");
				} else if (!gstrcmp(name, "protocol_udp")) {
					ifx_httpdWrite(wp, T("%s"),
						       (virtual +
							i)->protocol ==
						       NAT_VS_PROTOCOL_UDP ?
						       "SELECTED" : "");
				} else if (!gstrcmp(name, "protocol_tcp_udp")) {
					ifx_httpdWrite(wp, T("%s"),
						       (virtual +
							i)->protocol ==
						       NAT_VS_PROTOCOL_TCP_UDP ?
						       "SELECTED" : "");
				} else if (!gstrcmp(name, "f_enable"))
					ifx_httpdWrite(wp, T("%s"),
						       (virtual +
							i)->f_enable ==
						       1 ? "CHECKED" : "");
				else if (!gstrcmp(name, "wan_conn_if")) {
					ifx_get_all_wan_conn_names
					    (&wan_conn_names, &count);
					sprintf(buf, "%d",
						(virtual + i)->iid.cpeId.Id);
					if ((ret =
					     ifx_ret_substr_from_distfield
					     (FILE_RC_CONF, TAG_NAT_VIRTUALSER,
					      "cpeId", buf,
					      &retVal)) != IFX_SUCCESS) {
					}
					sprintf(buf, "%s_wanConnIf", retVal);
					IFX_MEM_FREE(retVal)
					    if ((ret =
						 ifx_GetObjData(FILE_RC_CONF,
								TAG_NAT_VIRTUALSER,
								buf,
								IFX_F_DEFAULT,
								&outFlag,
								wan_conn_name))
						!= IFX_SUCCESS) {
					}
#ifdef REQUIRED_FOR_VENDOR_EXTENSION
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t<option value=\"ALL\">ALL</option>\n"));
#endif				// REQUIRED_FOR_VENDOR_EXTENSION
					IFX_GET_WAN_CONN_NAME_LIST(j, count,
								   (virtual +
								    i)->
								   wan_conn_if,
								   wan_conn_names)
				} else if (!gstrcmp(name, "up_qos")) {
					ifx_httpdWrite(wp, T("%s"),
						       ((virtual +
							 i)->up_qos.
							qos_enabled ==
							IFX_ENABLED) ? "checked"
						       : "");
				} else if (!gstrcmp(name, "up_min_bw")) {
					ifx_httpdWrite(wp, T("%d"),
						       (virtual +
							i)->up_qos.min_bw);
				} else if (!gstrcmp(name, "up_max_bw")) {
					ifx_httpdWrite(wp, T("%d"),
						       (virtual +
							i)->up_qos.max_bw);
				} else if (!gstrcmp(name, "dn_qos")) {
					ifx_httpdWrite(wp, T("%s"),
						       ((virtual +
							 i)->dn_qos.
							qos_enabled ==
							IFX_ENABLED) ? "checked"
						       : "");
				} else if (!gstrcmp(name, "dn_min_bw")) {
					ifx_httpdWrite(wp, T("%d"),
						       (virtual +
							i)->dn_qos.min_bw);
				} else if (!gstrcmp(name, "dn_max_bw")) {
					ifx_httpdWrite(wp, T("%d"),
						       (virtual +
							i)->dn_qos.max_bw);
				}
				break;
			}
		}
	}

      IFX_Handler:
	IFX_MEM_FREE(retVal)
	    IFX_MEM_FREE(virtual)
	    IFX_MEM_FREE(wan_conn_names)
	    return 0;
}

//vipul start

int ifx_get_nat_virtualser(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 diffserv_vs_enable = 0, count = 0, ret =
	    IFX_SUCCESS, num_entries = 0;
	int32 i = 0, flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT, j =
	    0, cpeId = 0;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN], pType[MAX_FILELINE_LEN];
	char8 *wan_conn_names = NULL, wan_conn_name[MAX_NAME_SIZE];
	char8 wan_confconnName[MAX_NAME_SIZE];
	VIRTUAL_SERVER *virtual = NULL;
	WAN_TYPE wan_type;

	sValue[0] = '\0';
	wan_conn_name[0] = '\0';

#if 0
	ifx_get_network_ip_and_textbox_count(sValue1, &count);
	count = 0;
#endif

	ifx_httpdWrite(wp,
		       T
		       ("\t\t\t<div align=\"center\"><table class=\"tableInfo\" summary=\"Table\">\n"));
	ifx_httpdWrite(wp, T("\t\t\t<tr>\n"));
	ifx_httpdWrite(wp,
		       T
		       ("\t\t\t\t<th class=\"curveLeft\" rowspan=\"2\">&nbsp;</th>\n"));
	ifx_httpdWrite(wp,
		       T
		       ("\t\t\t\t<th rowspan=\"2\">Application <br> name</th>\n"));
	ifx_httpdWrite(wp,
		       T("\t\t\t\t<th rowspan=\"2\">Private <br> IP</th>\n"));
	ifx_httpdWrite(wp,
		       T("\t\t\t\t<th rowspan=\"2\">Remote <br> IP</th>\n"));
	ifx_httpdWrite(wp,
		       T
		       ("\t\t\t\t<th rowspan=\"2\">Private <br> Start Port</th>\n"));
	ifx_httpdWrite(wp,
		       T
		       ("\t\t\t\t<th rowspan=\"2\">Private <br> End Port</th>\n"));
	ifx_httpdWrite(wp, T("\t\t\t\t<th rowspan=\"2\">Protocol</th>\n"));
	ifx_httpdWrite(wp,
		       T
		       ("\t\t\t\t<th rowspan=\"2\">Public <br> Start Port</th>\n"));
	ifx_httpdWrite(wp,
		       T
		       ("\t\t\t\t<th rowspan=\"2\">Public <br> End Port</th>\n"));
	if (ifx_GetObjData
	    (FILE_RC_CONF, TAG_QOS_CONFIG, T("QOS_ENABLE"), flags,
	     (IFX_OUT uint32 *) & outFlag, sValue) == IFX_SUCCESS) {
		if (!gstrcmp(sValue, "1")) {
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_QOS_DIFFSERV_CONFIG,
			     T("DIFFSERV_VIRTUAL_SERVER"), IFX_F_DEFAULT,
			     (IFX_OUT uint32 *) & outFlag,
			     sValue) == IFX_SUCCESS) {
				if (!gstrcmp(sValue, "1")) {
					diffserv_vs_enable = 1;
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t<th colspan=\"3\">Upstream QoS</th>\n"));
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t<th colspan=\"3\">Downstream QoS</th>\n"));
				}
			}
		}
	}

	ifx_httpdWrite(wp, T("\t\t\t\t<th rowspan=\"2\">Enable</th>\n"));
	ifx_httpdWrite(wp, T("\t\t\t\t<th rowspan=\"2\">WAN Interface</th>\n"));
	ifx_httpdWrite(wp, T("\t\t\t\t<th rowspan=\"2\">Port Type</th>\n"));
	ifx_httpdWrite(wp,
		       T
		       ("\t\t\t\t<th class=\"colInput curveRight\" rowspan=\"2\"></th>\n"));
	ifx_httpdWrite(wp, T("\t\t\t</tr>\n\t\t\t<tr>\n"));

	if (diffserv_vs_enable) {
		ifx_httpdWrite(wp, T("\t\t\t\t<th>QoS Enable</th>\n"));
		ifx_httpdWrite(wp, T("\t\t\t\t<th>Min.Bandwidth</th>\n"));
		ifx_httpdWrite(wp, T("\t\t\t\t<th>Max.Bandwidth</th>\n"));
		ifx_httpdWrite(wp, T("\t\t\t\t<th>QoS Enable</th>\n"));
		ifx_httpdWrite(wp, T("\t\t\t\t<th>Min.Bandwidth</th>\n"));
		ifx_httpdWrite(wp, T("\t\t\t\t<th>Max.Bandwidth</th>\n"));
	}
	ifx_httpdWrite(wp, T("\t\t\t</tr>\n\t\t\t\n"));
	ifx_httpdWrite(wp,
		       T
		       ("\t\t\t<input type=\"hidden\" name=\"diffserv_vs_enable\" value=\"%d\">\n"),
		       diffserv_vs_enable);
	if ((ret =
	     ifx_get_all_wan_conn_names(&wan_conn_names,
					&count)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get wan connection names !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}

	if ((ret =
	     ifx_get_virtual_server_info(&num_entries, &virtual,
					 IFX_F_DEFAULT)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get the virtual server info !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}

	for (i = 0; i < num_entries; i++) {
		cpeId = (virtual + i)->iid.cpeId.Id;
		ifx_httpdWrite(wp,
			       "<input type=\"hidden\" name=\"cpeId%d\" value=\"%d\">",
			       i, cpeId);
		ifx_httpdWrite(wp, T("\t\t\t<tr>\n"));
		ifx_httpdWrite(wp, T("\t\t\t\t<td id=\"vser_no%d\">%d</td>\n"),
			       i, i + 1);
		gsprintf(buf, T("nat_virtualser_%d_desc"), i);
		strcpy(sValue, (virtual + i)->vs_desc);
		ifx_httpdWrite(wp, T("<td id=\"vser_app_name%d\">%s</td>\n"), i,
			       sValue);
		gsprintf(buf, T("nat_virtualser_%d_privateIp"), i);
		sprintf(sValue, "%s", inet_ntoa((virtual + i)->private_ip));
//              ifx_httpdWrite(wp, T("\t\t\t\t<td nowrap disabled>"));
		// Pramod : should display wild card '*' for ip address 0.0.0.0 and not 255.255.255.255
		// if(!gstrcmp(sValue, "255.255.255.255")) {
		if (!gstrcmp(sValue, "0.0.0.0")) {
			ifx_httpdWrite(wp, T("\t\t\t\t<td disabled>"));
			ifx_httpdWrite(wp, T("*</td>"));
		} else {
			ifx_httpdWrite(wp, T("<td id=\"vser_pip%d\">%s</td>\n"),
				       i, sValue);
		}
#if 0
		else {
			ifx_httpdWrite(wp, T("\t\t\t\t<td nowrap disabled>%s"),
				       sValue1);

			sServerIP = strtok(sValue, ".");
			if (sServerIP != NULL)
				sServerIP = strtok(NULL, ".");
			if (sServerIP != NULL)
				sServerIP = strtok(NULL, ".");
			if (sServerIP != NULL) {
				sServerIP = strtok(NULL, ".");
			}
			ifx_httpdWrite(wp,
				       T
				       ("<input maxlength=\"3\" name=\"%s\" size=\"3\" value=\"%s\" ></td>\n"),
				       buf, sServerIP);
		}
#endif

		gsprintf(buf, T("nat_virtualser_%d_remoteIp"), i);

		sprintf(sValue, "%s", inet_ntoa((virtual + i)->remote_ip));
		if (!gstrcmp(sValue, "0.0.0.0")) {
			ifx_httpdWrite(wp, T("\t\t\t\t<td disabled>"));
			ifx_httpdWrite(wp, T("*</td>"));
		} else {
			ifx_httpdWrite(wp, T("<td id=\"vser_rip%d\">%s</td>\n"),
				       i, sValue);

		}
#if 0
		else {
			ifx_httpdWrite(wp, T("\t\t\t\t<td nowrap disabled>%s"),
				       sValue1);

			sServerIP = strtok(sValue, ".");
			if (sServerIP != NULL)
				sServerIP = strtok(NULL, ".");
			if (sServerIP != NULL)
				sServerIP = strtok(NULL, ".");
			if (sServerIP != NULL) {
				sServerIP = strtok(NULL, ".");
			}

			ifx_httpdWrite(wp,
				       T
				       ("<input maxlength=\"3\" name=\"%s\" size=\"3\" value=\"%s\" ></td>\n"),
				       buf, sServerIP);
		}
#endif

		gsprintf(buf, T("nat_virtualser_%d_spport"), i);
		if ((virtual + i)->private_sport < 1) {
			ifx_httpdWrite(wp, T("\t\t\t\t<td disabled>"));
			ifx_httpdWrite(wp,
				       T
				       ("<p maxLength=\"5\" name=\"%s\" size=\"6\" value=\"\" ></td>\n"),
				       buf);
		} else
			ifx_httpdWrite(wp,
				       T
				       ("<td id=\"vser_priv_sport%d\">%d</td>\n"),
				       i, (virtual + i)->private_sport);
		gsprintf(buf, T("nat_virtualser_%d_epport"), i);
		if ((virtual + i)->private_eport < 1) {
			ifx_httpdWrite(wp, T("\t\t\t\t<td disabled>"));
			ifx_httpdWrite(wp,
				       T
				       ("<p maxLength=\"5\" name=\"%s\" size=\"6\" value=\"\" ></td>\n"),
				       buf);
		} else
			ifx_httpdWrite(wp,
				       T
				       ("<td id=\"vser_priv_eport%d\">%d</td>\n"),
				       i, (virtual + i)->private_eport);

		gsprintf(buf, T("nat_virtualser_%d_ptype"), i);
		if ((virtual + i)->protocol == 1)
			strcpy(sValue, "TCP");
		else if ((virtual + i)->protocol == 2)
			strcpy(sValue, "UDP");
		else
			strcpy(sValue, "TCP/UDP");
		ifx_httpdWrite(wp, T("<td id=\"vser_prot%d\">%s</td>\n"), i,
			       sValue);

		gsprintf(buf, T("nat_virtualser_%d_spuport"), i);
		if ((virtual + i)->public_sport < 1) {
			ifx_httpdWrite(wp, T("\t\t\t\t<td nowrap disabled>"));
			ifx_httpdWrite(wp,
				       T
				       ("<p maxLength=\"5\" name=\"%s\" size=\"6\" value=\"\" ></td>\n"),
				       buf);
		} else
			ifx_httpdWrite(wp,
				       T
				       ("<td id=\"vser_pub_sport%d\">%d</td>\n"),
				       i, (virtual + i)->public_sport);

		gsprintf(buf, T("nat_virtualser_%d_epuport"), i);
		if ((virtual + i)->public_eport < 1) {
			ifx_httpdWrite(wp, T("\t\t\t\t<td disabled>"));
			ifx_httpdWrite(wp,
				       T
				       ("<p maxLength=\"5\" name=\"%s\" size=\"6\" value=\"\" ></td>\n"),
				       buf);
		} else
			ifx_httpdWrite(wp,
				       T
				       ("<td id=\"vser_pub_eport%d\">%d</td>\n"),
				       i, (virtual + i)->public_eport);

		if (diffserv_vs_enable) {
			ifx_httpdWrite(wp, T("\t\t\t\t<td disabled>"));
			gsprintf(buf, T("nat_virtualser_%d_upqosEnable"), i);
			if ((virtual + i)->up_qos.qos_enabled)
				ifx_httpdWrite(wp,
					       T
					       ("<input type=\"checkbox\" name=\"%s\" value=\"1\" %s></td>\n"),
					       buf, " CHECKED");
			else
				ifx_httpdWrite(wp,
					       T
					       ("<input type=\"checkbox\" name=\"%s\" value=\"1\" ></td>\n"),
					       buf);
			ifx_httpdWrite(wp, T("\t\t\t\t<td disabled>"));
			gsprintf(buf, T("nat_virtualser_%d_upminBW"), i);
			if ((virtual + i)->up_qos.min_bw)
				ifx_httpdWrite(wp,
					       T
					       ("<input maxLength=\"3\" name=\"%s\" size=\"6\" value=\"%d\" >%</td>\n"),
					       buf,
					       (virtual + i)->up_qos.min_bw);
			else
				ifx_httpdWrite(wp,
					       T
					       ("<input maxLength=\"3\" name=\"%s\" size=\"6\" value=\"\" >%</td>\n"),
					       buf);

			ifx_httpdWrite(wp, T("\t\t\t\t<td disabled>"));
			gsprintf(buf, T("nat_virtualser_%d_upmaxBW"), i);
			if ((virtual + i)->up_qos.max_bw)
				ifx_httpdWrite(wp,
					       T
					       ("<input maxLength=\"3\" name=\"%s\" size=\"6\" value=\"%d\" >%</td>\n"),
					       buf,
					       (virtual + i)->up_qos.max_bw);
			else
				ifx_httpdWrite(wp,
					       T
					       ("<input maxLength=\"3\" name=\"%s\" size=\"6\" value=\"\" >%</td>\n"),
					       buf);

			ifx_httpdWrite(wp, T("\t\t\t\t<td disabled>"));
			gsprintf(buf, T("nat_virtualser_%d_dnqosEnable"), i);
			if ((virtual + i)->dn_qos.qos_enabled)
				ifx_httpdWrite(wp,
					       T
					       ("<input type=\"checkbox\" name=\"%s\" value=\"1\"  %s></td>\n"),
					       buf, " CHECKED");
			else
				ifx_httpdWrite(wp,
					       T
					       ("<input type=\"checkbox\" name=\"%s\" value=\"1\" ></td>\n"),
					       buf);

			ifx_httpdWrite(wp, T("\t\t\t\t<td disabled>"));
			gsprintf(buf, T("nat_virtualser_%d_dnminBW"), i);
			if ((virtual + i)->dn_qos.min_bw)
				ifx_httpdWrite(wp,
					       T
					       ("<input maxLength=\"3\" name=\"%s\" size=\"6\" value=\"%d\" >%</td>\n"),
					       buf,
					       (virtual + i)->dn_qos.min_bw);
			else
				ifx_httpdWrite(wp,
					       T
					       ("<input maxLength=\"3\" name=\"%s\" size=\"6\" value=\"\" >%</td>\n"),
					       buf);

			ifx_httpdWrite(wp, T("\t\t\t\t<td disabled>"));
			gsprintf(buf, T("nat_virtualser_%d_dnmaxBW"), i);
			if ((virtual + i)->dn_qos.max_bw)
				ifx_httpdWrite(wp,
					       T
					       ("<input maxLength=\"3\" name=\"%s\" size=\"6\" value=\"%d\" >%</td>\n"),
					       buf,
					       (virtual + i)->dn_qos.max_bw);
			else
				ifx_httpdWrite(wp,
					       T
					       ("<input maxLength=\"3\" name=\"%s\" size=\"6\" value=\"\" >%</td>\n"),
					       buf);
		}

		ifx_httpdWrite(wp, T("\t\t\t\t<td disabled>"));
		gsprintf(buf, T("nat_virtualser_%d_fEnable"), i);
		if ((virtual + i)->f_enable < 0) {
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t\t<input type=\"checkbox\" name=\"%s\" value=\"1\" disabled></td>\n"),
				       buf);
		} else {
			if ((virtual + i)->f_enable == 0)
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t\t<input type=\"checkbox\" name=\"%s\" value=\"1\"  disabled></td>\n"),
					       buf);
			else
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t\t<input type=\"checkbox\" name=\"%s\" value=\"1\"%s disabled></td>\n"),
					       buf, " CHECKED");
		}

		ifx_httpdWrite(wp, T("\t\t\t\t<td disabled>"));
		gsprintf(buf, T("nat_virtualser_%d_wanConnIf"), i);
		if (strlen((virtual + i)->wan_conn_if) == 0)
			sprintf(wan_conn_name, "%s", "\0");
		else {
			memset(wan_conn_name, 0x00, sizeof(wan_conn_name));	// PRAMOD : TESTING
			LTQ_STRNCPY(wan_conn_name, (virtual + i)->wan_conn_if,
				sizeof(wan_conn_name));
		}

		ifx_httpdWrite(wp, T("\t\t\t\t<select name=\"%s\" disabled>"),
			       buf);
#ifdef REQUIRED_FOR_VENDOR_EXTENSION
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t\t<option value=\"ALL\">ALL</option>\n"));
#endif				// REQUIRED_FOR_VENDOR_EXTENSION
		for (j = 0; j < count; j++) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("comparing [%s] with array element [%s]!!",
				wan_conn_name, GET_WAN_CONN_NAME(wan_conn_names,
								 j));
#endif
   			if (strstr(GET_WAN_CONN_NAME(wan_conn_names, j),"IP") != NULL) {
                                wan_type = WAN_TYPE_IP;
                        } else {
                                wan_type = WAN_TYPE_PPP;
                        }

                        if (ifx_get_wan_confconnName_from_connName(GET_WAN_CONN_NAME(wan_conn_names, j),wan_confconnName,wan_type) == IFX_SUCCESS)
                        {

				if (!gstrcmp (wan_conn_name, GET_WAN_CONN_NAME(wan_conn_names, j))){
					ifx_httpdWrite(wp,T("\t\t\t\t\t<option value=\"%s\" selected>%s</option>\n"), GET_WAN_CONN_NAME(wan_conn_names, j),wan_confconnName);
				}
				else{
					ifx_httpdWrite(wp,T("\t\t\t\t\t<option value=\"%s\">%s</option>\n"), GET_WAN_CONN_NAME(wan_conn_names,j),wan_confconnName);
				}
			}
		}

                ifx_httpdWrite(wp, T("\t\t\t\t</select></td>\n"));

                gsprintf(buf, T("nat_virtualser_%d_owner"), i);
                sprintf(sValue, "%d", ((virtual + i)->iid.owner));
                if(((virtual + i)->iid.owner) == IFX_UPNP)
		{
			strcpy(pType, "Dynamic");
                        ifx_httpdWrite(wp, T("\t\t\t<td id=\"vser_own=%d\">%s</td>\n"),sValue, pType);
		}
		else  
		{
			strcpy(pType, "Static");
                        ifx_httpdWrite(wp, T("\t\t\t<td id=\"vser_own=%d\">%s</td>\n"),sValue, pType);
		}

		ifx_httpdWrite(wp, T("\t\t\t\t<td>"));
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t\t<a href=\"#\" class=\"button\" onclick=\"delNatEntry('%d', '%s');\" value=\"Delete\">Delete</a>\n"),
			       cpeId, wan_conn_name);
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t\t<a href=\"#\" class=\"button\" onclick=\"modNatEntry('%d', '%s');\" value=\"Modify\">Modify</a>\n"),
			       cpeId, wan_conn_name);
		ifx_httpdWrite(wp, T("\t\t\t</tr>\n"));
	}

	ifx_httpdWrite(wp, T("\t\t\t\n\t\t\t</table></div>\n"));

      IFX_Handler:
	IFX_MEM_FREE(virtual)
	    IFX_MEM_FREE(wan_conn_names)
	    return 0;
}

//vipul end

#endif				//CONFIG_FEATURE_NAPT

#ifdef CONFIG_FEATURE_NAPT
#ifdef NAT_PORTMAP
//////////////////////////////////////////////////////////////////////////////////
// nat_portmap.asp
//
int ifx_get_nat_portmap(int eid, httpd_t wp, int argc, char_t ** argv)
{
	//char_t  *name;
	char_t buf[MAX_DATA_LEN];
	char_t sValue[MAX_FILELINE_LEN], sServerIP[MAX_DATA_LEN];
	char_t getCommand[MAX_FILELINE_LEN], setCommand[MAX_FILELINE_LEN];
	int i;

	setCommand[0] = '\0';
	sServerIP[0] = '\0';

	//websGetInterfaceIP(pLanIface, 3, FALSE, sServerIP);
	websGetIFInfo(LAN_IF_TYPE, IP_INFO, 1, 3, FALSE, NULL, sServerIP);

	for (i = 1; i <= NAT_VS_LINK_NUM; i++) {
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t<tr align=center bgcolor=\"#ffffff\">\n"));
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t\t<td nowrap><font face=\"Arial, Helvetica, sans-serif\" size=\"2\">%d</font></td>\n"),
			       i);
		buf[0] = '\0';
		sValue[0] = '\0';
		getCommand[0] = '\0';

		gsprintf(buf, T("CLONE_IP%d"), i);
		gsprintf(getCommand,
			 T("grep \"%s\" %s | cut -f2 -d\\\" | cut -f4 -d."),
			 buf, FILE_RC_CONF);
		if (ifx_GetCfgData((char_t *) getCommand, NULL, "1", sValue) ==
		    0) {
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t\t<td nowrap><font face=\"Arial, Helvetica, sans-serif\" size=\"2\">%s\n"),
				       sServerIP);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t\t<input maxLength=\"3\" name=\"%s\" size=\"3\" value=\"\"></font></td>\n"),
				       buf);
		} else {
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t\t<td nowrap><font face=\"Arial, Helvetica, sans-serif\" size=\"2\">%s\n"),
				       sServerIP);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t\t<input maxLength=\"3\" name=\"%s\" size=\"3\" value=\"%s\"></font></td>\n"),
				       buf, sValue);
		}

		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t\t<td nowrap><font size=\"2\" face=\"Arial, Helvetica, sans-serif\">\n"));

		buf[0] = '\0';
		sValue[0] = '\0';

		gsprintf(buf, T("CLONE_PORTS%d"), i);
		if (ifx_GetCfgData(FILE_RC_CONF, TAG_NAT_PORTMAP, buf, sValue)
		    == 0) {
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t\t<input maxLength=\"120\" name=\"%s\" size=\"50\" value=\"\"></font></td>\n"),
				       buf);
		} else {
			if (gstrcmp(sValue, "0") != 0) {
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t\t<input maxLength=\"120\" name=\"%s\" size=\"50\" value=\"%s\"></font></td>\n"),
					       buf, sValue);
			} else if (!gstrcmp(sValue, "0")) {
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t\t<input maxLength=\"120\" name=\"%s\" size=\"50\" value=\"\"></font></td>\n"),
					       buf);
			}
		}
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t\t<td nowrap> <font size=\"2\" face=\"Arial, Helvetica, sans-serif\">\n"));

		buf[0] = '\0';
		sValue[0] = '\0';

		gsprintf(buf, T("CLONE_ENABLE%d"), i);
		if (ifx_GetCfgData(FILE_RC_CONF, TAG_NAT_PORTMAP, buf, sValue)
		    == 0) {
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t\t<input type=\"checkbox\" name=\"%s\" value=\"1\"></font></td>\n"),
				       buf);
		} else {
			if (!gstrcmp(sValue, "1")) {
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t\t<input type=\"checkbox\" name=\"%s\" value=\"1\"%s></font></td>\n"),
					       buf, " CHECKED");
			} else if (!gstrcmp(sValue, "0")) {
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t\t<input type=\"checkbox\" name=\"%s\" value=\"1\"%s></font></td>\n"),
					       buf, "");
			}
		}

		ifx_httpdWrite(wp, T("\t\t\t</tr>\n"));
	}

	return 0;
}
#endif

// firewall_dmz.asp
#ifdef ORGCODE
int ifx_get_firewall_dmz(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
	char_t sValue[MAX_FILELINE_LEN];
	char_t command[MAX_FILELINE_LEN];

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	memset(sValue, 0x00, sizeof(sValue));
	memset(command, 0x00, sizeof(command));

	if (!gstrcmp(name, T("C1"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_FIREWALL_DMZ, T("feature_enable"),
		     sValue) == 1) {
			if (!gstrcmp(sValue, "1"))
				ifx_httpdWrite(wp, T("checked"));
			else
				ifx_httpdWrite(wp, T(""));
		}
	} else if (!gstrcmp(name, T("dmzip1"))) {

		gsprintf(command,
			 T("grep %s %s | cut -f2 -d\\\" | cut -f1 -d."),
			 "ipAddr", FILE_RC_CONF);
		if (ifx_GetCfgData((char_t *) command, NULL, "1", sValue) == 1) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		}
	} else if (!gstrcmp(name, T("dmzip2"))) {
		gsprintf(command,
			 T("grep %s %s | cut -f2 -d\\\" | cut -f2 -d."),
			 "ipAddr", FILE_RC_CONF);
		if (ifx_GetCfgData((char_t *) command, NULL, "1", sValue) == 1) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		}
	} else if (!gstrcmp(name, T("dmzip3"))) {
		gsprintf(command,
			 T("grep %s %s | cut -f2 -d\\\" | cut -f3 -d."),
			 "ipAddr", FILE_RC_CONF);
		if (ifx_GetCfgData((char_t *) command, NULL, "1", sValue) == 1) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		}
	} else if (!gstrcmp(name, T("dmzip4"))) {
		gsprintf(command,
			 T("grep %s %s | cut -f2 -d\\\" | cut -f4 -d."),
			 "ipAddr", FILE_RC_CONF);
		if (ifx_GetCfgData((char_t *) command, NULL, "1", sValue) == 1) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		}
	}

	return 0;
}
#else
int ifx_get_firewall_dmz(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
	char_t sValue[MAX_FILELINE_LEN];
	char_t ip[4][4];
	int i, j, k;
	IFX_MAPI_Firewall_DMZ dmz;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	memset(sValue, 0x00, sizeof(sValue));
	memset(ip, 0x00, sizeof(ip));
	memset(&dmz, 0x00, sizeof(IFX_MAPI_Firewall_DMZ));

	ifx_mapi_get_firewall_dmz(&dmz, IFX_F_DEFAULT);
	strcpy(sValue, inet_ntoa(dmz.ip));
	k = 0;
	for (i = 0; i < strlen(sValue); i++) {
		for (j = 0;
		     (sValue[i] != '.' && sValue[i] != '\0'
		      && i < strlen(sValue)); j++, i++) {
			ip[k][j] = sValue[i];
		}
		ip[k][j] = '\0';
		k++;
	}

	if (!gstrcmp(name, T("C1"))) {
		if (dmz.feature_enable)
			ifx_httpdWrite(wp, T("checked"));
		else
			ifx_httpdWrite(wp, T(""));
	} else {
		if (!gstrcmp(name, T("dmzip1")))
			ifx_httpdWrite(wp, T("%s"), ip[0]);
		else {
			if (!gstrcmp(name, T("dmzip2")))
				ifx_httpdWrite(wp, T("%s"), ip[1]);
			else {
				if (!gstrcmp(name, T("dmzip3")))
					ifx_httpdWrite(wp, T("%s"), ip[2]);
				else {
					if (!gstrcmp(name, T("dmzip4")))
						ifx_httpdWrite(wp, T("%s"),
							       ip[3]);
				}
			}
		}
	}

	return 0;
}

#endif				//ORGCODE
#endif				//CONFIG_FEATURE_NAPT
