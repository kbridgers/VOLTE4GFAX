/******************************************************************************

                               Copyright (c) 2008
                            Infineon Technologies AG
                     Am Campeon 1-12; 81726 Munich, Germany

  THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED NON-EXCLUSIVE,
  WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE AND SUBLICENSE THIS
  SOFTWARE IS FREE OF CHARGE.

  THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY DISCLAIMS
  ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR IMPLIED, INCLUDING
  WITHOUT LIMITATION, WARRANTIES OR REPRESENTATIONS OF WORKMANSHIP,
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, DURABILITY, THAT THE
  OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR FREE OR FREE OF ANY THIRD
  PARTY CLAIMS, INCLUDING WITHOUT LIMITATION CLAIMS OF THIRD PARTY INTELLECTUAL
  PROPERTY INFRINGEMENT.

  EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND EXCEPT
  FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE FOR ANY CLAIM
  OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
  ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
  DEALINGS IN THE SOFTWARE.

******************************************************************************/

/**
   \file ifx_src_wlan_getFunctions.c
   This file contains the implementation of WLAN related functions, used to
   provide information about an underlying WLAN device to the Web GUI. This is
   accomplished through function calls to the WLAN MAPI.
*/
#ifdef CONFIG_FEATURE_IFX_WIRELESS
/* ========================================================================== */
/*                                 Includes                                   */
/* ========================================================================== */
#include <ifx_emf.h>
#include "ifx_httpd_method.h"
#include <sys/types.h>
#include <sys/time.h>
#include <ifx_common.h>
#include <ifx_api_ipt_common.h>
#include "ifx_amazon_cgi.h"
#include "ltq_cgi_wlan.h"

/* ========================================================================== */
/*                             Macro definitions                              */
/* ========================================================================== */

/* ========================================================================== */
/*                             Type definitions                               */
/* ========================================================================== */

/* ========================================================================== */
/*                             Global variables                               */
/* ========================================================================== */
/* the order of strings in this array must correspond to the typedef enum
   IFX_MAPI_WLAN_Country */
char8 ifx_mapi_wlan_country[][2][50] = {
	{"AFGHANISTAN", "AF"}
	,			/* IFX_MAPI_WLAN_COUNTRY_INDIA */
	{"ALAND ISLANDS", "AX"}
	,			/* IFX_MAPI_WLAN_COUNTRY_US */
	{"ALBANIA", "AL"}
	,			/* IFX_MAPI_WLAN_COUNTRY_CHINA */
	{"ALGERIA", "DZ"}
	,			/* IFX_MAPI_WLAN_COUNTRY_FRANCE */
	{"AMERICAN SAMOA", "AS"}
	,			/* IFX_MAPI_WLAN_COUNTRY_GER */
	{"ANDORRA", "AD"}
	,			/* IFX_MAPI_WLAN_COUNTRY_IC */
	{"ANGOLA", "AO"}
	,			/* IFX_MAPI_WLAN_COUNTRY_ETSI */
	{"ANGUILLA", "AI"}
	,			/* IFX_MAPI_WLAN_COUNTRY_JAP */
	{"ANTARCTICA", "AQ"}
	,			/* IFX_MAPI_WLAN_COUNTRY_ESP */
	{"ANTIGUA AND BARBUDA", "AG"}
	,
	{"ARGENTINA", "AR"}
	,
	{"ARMENIA", "AM"}
	,
	{"ARUBA", "AW"}
	,
	{"AUSTRALIA", "AU"}
	,
	{"AUSTRIA", "AT"}
	,
	{"AZERBAIJAN", "AZ"}
	,
	{"BAHAMAS", "BS"}
	,
	{"BAHRAIN", "BH"}
	,
	{"BANGLADESH", "BD"}
	,
	{"BARBADOS", "BB"}
	,
	{"BELARUS", "BY"}
	,
	{"BELGIUM", "BE"}
	,
	{"BELIZE", "BZ"}
	,
	{"BENIN", "BJ"}
	,
	{"BERMUDA", "BM"}
	,
	{"BHUTAN", "BT"}
	,
	{"BOLIVIA, PLURINATIONAL STATE OF", "BO"}
	,
	{"BOSNIA AND HERZEGOVINA", "BA"}
	,
	{"BOTSWANA", "BW"}
	,
	{"BOUVET ISLAND", "BV"}
	,
	{"BRAZIL", "BR"}
	,
	{"BRITISH INDIAN OCEAN TERRITORY", "IO"}
	,
	{"BRUNEI DARUSSALAM", "BN"}
	,
	{"BULGARIA", "BG"}
	,
	{"BURKINA FASO", "BF"}
	,
	{"BURUNDI", "BI"}
	,
	{"CAMBODIA", "KH"}
	,
	{"CAMEROON", "CM"}
	,
	{"CANADA", "CA"}
	,
	{"CAPE VERDE", "CV"}
	,
	{"CAYMAN ISLANDS", "KY"}
	,
	{"CENTRAL AFRICAN REPUBLIC", "CF"}
	,
	{"CHAD", "TD"}
	,
	{"CHILE", "CL"}
	,
	{"CHINA", "CN"}
	,
	{"CHRISTMAS ISLAND", "CX"}
	,
	{"COCOS (KEELING) ISLANDS", "CC"}
	,
	{"COLOMBIA", "CO"}
	,
	{"COMOROS", "KM"}
	,
	{"CONGO", "CG"}
	,
	{"CONGO, THE DEMOCRATIC REPUBLIC OF THE", "CD"}
	,
	{"COOK ISLANDS", "CK"}
	,
	{"COSTA RICA", "CR"}
	,
	{"C�TE D'IVOIRE", "CI"}
	,
	{"CROATIA", "HR"}
	,
	{"CUBA", "CU"}
	,
	{"CYPRUS", "CY"}
	,
	{"CZECH REPUBLIC", "CZ"}
	,
	{"DENMARK", "DK"}
	,
	{"DJIBOUTI", "DJ"}
	,
	{"DOMINICA", "DM"}
	,
	{"DOMINICAN REPUBLIC", "DO"}
	,
	{"ECUADOR", "EC"}
	,
	{"EGYPT", "EG"}
	,
	{"EL SALVADOR", "SV"}
	,
	{"EQUATORIAL GUINEA", "GQ"}
	,
	{"ERITREA", "ER"}
	,
	{"ESTONIA", "EE"}
	,
	{"ETHIOPIA", "ET"}
	,
	{"FALKLAND ISLANDS (MALVINAS)", "FK"}
	,
	{"FAROE ISLANDS", "FO"}
	,
	{"FIJI", "FJ"}
	,
	{"FINLAND", "FI"}
	,
	{"FRANCE", "FR"}
	,
	{"FRENCH GUIANA", "GF"}
	,
	{"FRENCH POLYNESIA", "PF"}
	,
	{"FRENCH SOUTHERN TERRITORIES", "TF"}
	,
	{"GABON", "GA"}
	,
	{"GAMBIA", "GM"}
	,
	{"GEORGIA", "GE"}
	,
	{"GERMANY", "DE"}
	,
	{"GHANA", "GH"}
	,
	{"GIBRALTAR", "GI"}
	,
	{"GREECE", "GR"}
	,
	{"GREENLAND", "GL"}
	,
	{"GRENADA", "GD"}
	,
	{"GUADELOUPE", "GP"}
	,
	{"GUAM", "GU"}
	,
	{"GUATEMALA", "GT"}
	,
	{"GUERNSEY", "GG"}
	,
	{"GUINEA", "GN"}
	,
	{"GUINEA-BISSAU", "GW"}
	,
	{"GUYANA", "GY"}
	,
	{"HAITI", "HT"}
	,
	{"HEARD ISLAND AND MCDONALD ISLANDS", "HM"}
	,
	{"HOLY SEE (VATICAN CITY STATE)", "VA"}
	,
	{"HONDURAS", "HN"}
	,
	{"HONG KONG", "HK"}
	,
	{"HUNGARY", "HU"}
	,
	{"ICELAND", "IS"}
	,
	{"INDIA", "IN"}
	,
	{"INDONESIA", "ID"}
	,
	{"IRAN,ISLAMIC REPUBLIC OF", "IR"}
	,
	{"IRAQ", "IQ"}
	,
	{"IRELAND", "IE"}
	,
	{"ISLE OF MAN", "IM"}
	,
	{"ISRAEL", "IL"}
	,
	{"ITALY", "IT"}
	,
	{"JAMAICA", "JM"}
	,
	{"JAPAN", "JP"}
	,
	{"JERSEY", "JE"}
	,
	{"JORDAN", "JO"}
	,
	{"KAZAKHSTAN", "KZ"}
	,
	{"KENYA", "KE"}
	,
	{"KIRIBATI", "KI"}
	,
	{"KOREA,DEMOCRATIC PEOPLE'S REPUBLIC OF", "KP"}
	,
	{"KOREA,REPUBLIC OF", "KR"}
	,
	{"KUWAIT", "KW"}
	,
	{"KYRGYZSTAN", "KG"}
	,
	{"LAO PEOPLE'S DEMOCRATIC REPUBLIC", "LA"}
	,
	{"LATVIA", "LV"}
	,
	{"LEBANON", "LB"}
	,
	{"LESOTHO", "LS"}
	,
	{"LIBERIA", "LR"}
	,
	{"LIBYAN ARAB JAMAHIRIYA", "LY"}
	,
	{"LIECHTENSTEIN", "LI"}
	,
	{"LITHUANIA", "LT"}
	,
	{"LUXEMBOURG", "LU"}
	,
	{"MACAO", "MO"}
	,
	{"MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF", "MK"}
	,
	{"MADAGASCAR", "MG"}
	,
	{"MALAWI", "MW"}
	,
	{"MALAYSIA", "MY"}
	,
	{"MALDIVES", "MV"}
	,
	{"MALI", "ML"}
	,
	{"MALTA", "MT"}
	,
	{"MARSHALL ISLANDS", "MH"}
	,
	{"MARTINIQUE", "MQ"}
	,
	{"MAURITANIA", "MR"}
	,
	{"MAURITIUS", "MU"}
	,
	{"MAYOTTE", "YT"}
	,
	{"MEXICO", "MX"}
	,
	{"MICRONESIA, FEDERATED STATES OF", "FM"}
	,
	{"MOLDOVA, REPUBLIC OF", "MD"}
	,
	{"MONACO", "MC"}
	,
	{"MONGOLIA", "MN"}
	,
	{"MONTENEGRO", "ME"}
	,
	{"MONTSERRAT", "MS"}
	,
	{"MOROCCO", "MA"}
	,
	{"MOZAMBIQUE", "MZ"}
	,
	{"MYANMAR", "MM"}
	,
	{"NAMIBIA", "NA"}
	,
	{"NAURU", "NR"}
	,
	{"NEPAL", "NP"}
	,
	{"NETHERLANDS", "NL"}
	,
	{"NETHERLANDS ANTILLES", "AN"}
	,
	{"NEW CALEDONIA", "NC"}
	,
	{"NEW ZEALAND", "NZ"}
	,
	{"NICARAGUA", "NI"}
	,
	{"NIGER", "NE"}
	,
	{"NIGERIA", "NG"}
	,
	{"NIUE", "NU"}
	,
	{"NORFOLK ISLAND", "NF"}
	,
	{"NORTHERN MARIANA ISLANDS", "MP"}
	,
	{"NORWAY", "NO"}
	,
	{"OMAN", "OM"}
	,
	{"PAKISTAN", "PK"}
	,
	{"PALAU", "PW"}
	,
	{"PALESTINIAN TERRITORY, OCCUPIED", "PS"}
	,
	{"PANAMA", "PA"}
	,
	{"PAPUA NEW GUINEA", "PG"}
	,
	{"PARAGUAY", "PY"}
	,
	{"PERU", "PE"}
	,
	{"PHILIPPINES", "PH"}
	,
	{"PITCAIRN", "PN"}
	,
	{"POLAND", "PL"}
	,
	{"PORTUGAL", "PT"}
	,
	{"PUERTO RICO", "PR"}
	,
	{"QATAR", "QA"}
	,
	{"R�UNION", "RE"}
	,
	{"ROMANIA", "RO"}
	,
	{"RUSSIAN FEDERATION", "RU"}
	,
	{"RWANDA", "RW"}
	,
	{"SAINT BARTH�LEMY", "BL"}
	,
	{"SAINT HELENA, ASCENSION AND TRISTAN DA CUNHA", "SH"}
	,
	{"SAINT KITTS AND NEVIS", "KN"}
	,
	{"SAINT LUCIA", "LC"}
	,
	{"SAINT MARTIN", "MF"}
	,
	{"SAINT PIERRE AND MIQUELON", "PM"}
	,
	{"SAINT VINCENT AND THE GRENADINES", "VC"}
	,
	{"SAMOA", "WS"}
	,
	{"SAN MARINO", "SM"}
	,
	{"SAO TOME AND PRINCIPE", "ST"}
	,
	{"SAUDI ARABIA", "SA"}
	,
	{"SENEGAL", "SN"}
	,
	{"SERBIA", "RS"}
	,
	{"SEYCHELLES", "SC"}
	,
	{"SIERRA LEONE", "SL"}
	,
	{"SINGAPORE", "SG"}
	,
	{"SLOVAKIA", "SK"}
	,
	{"SLOVENIA", "SI"}
	,
	{"SOLOMON ISLANDS", "SB"}
	,
	{"SOMALIA", "SO"}
	,
	{"SOUTH AFRICA", "ZA"}
	,
	{"SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS", "GS"}
	,
	{"SPAIN", "ES"}
	,
	{"SRI LANKA", "LK"}
	,
	{"SUDAN", "SD"}
	,
	{"SURINAME", "SR"}
	,
	{"SVALBARD AND JAN MAYEN", "SJ"}
	,
	{"SWAZILAND", "SZ"}
	,
	{"SWEDEN", "SE"}
	,
	{"SWITZERLAND", "CH"}
	,
	{"SYRIAN ARAB REPUBLIC", "SY"}
	,
	{"TAIWAN", "TW"}
	,
	{"TAJIKISTAN", "TJ"}
	,
	{"TANZANIA, UNITED REPUBLIC OF", "TZ"}
	,
	{"THAILAND", "TH"}
	,
	{"TIMOR-LESTE", "TL"}
	,
	{"TOGO", "TG"}
	,
	{"TOKELAU", "TK"}
	,
	{"TONGA", "TO"}
	,
	{"TRINIDAD AND TOBAGO", "TT"}
	,
	{"TUNISIA", "TN"}
	,
	{"TURKEY", "TR"}
	,
	{"TURKMENISTAN", "TM"}
	,
	{"TURKS AND CAICOS ISLANDS", "TC"}
	,
	{"TUVALU", "TV"}
	,
	{"UGANDA", "UG"}
	,
	{"UKRAINE", "UA"}
	,
	{"UNITED ARAB EMIRATES", "AE"}
	,
	{"UNITED KINGDOM", "GB"}
	,
	{"UNITED STATES", "US"}
	,
	{"UNITED STATES MINOR OUTLYING ISLANDS", "UM"}
	,
	{"URUGUAY", "UY"}
	,
	{"UZBEKISTAN", "UZ"}
	,
	{"VANUATU", "VU"}
	,
	{"VATICAN CITY STATE", "VA"}
	,
	{"VENEZUELA, BOLIVARIAN REPUBLIC OF", "VE"}
	,
	{"VIET NAM", "VN"}
	,
	{"VIRGIN ISLANDS, BRITISH", "VG"}
	,
	{"VIRGIN ISLANDS, U.S.", "VI"}
	,
	{"WALLIS AND FUTUNA", "WF"}
	,
	{"WESTERN SAHARA", "EH"}
	,
	{"YEMEN", "YE"}
	,
	{"ZAMBIA", "ZM"}
	,
	{"ZIMBABWE", "ZW"}
	,
	{"Unknown or unspecified country", "ZZ"}
};

/* the order of string in this array must correspond to the typedef enum
   IFX_MAPI_WLAN_Country */
int32 ifx_mapi_wlan_country_enum[IFX_MAPI_WLAN_MAX_COUNTRY] = {
	IFX_MAPI_WLAN_COUNTRY_INDIA, IFX_MAPI_WLAN_COUNTRY_US,
	IFX_MAPI_WLAN_COUNTRY_CHINA, IFX_MAPI_WLAN_COUNTRY_FRANCE,
	IFX_MAPI_WLAN_COUNTRY_GER, IFX_MAPI_WLAN_COUNTRY_IC,
	IFX_MAPI_WLAN_COUNTRY_ETSI, IFX_MAPI_WLAN_COUNTRY_JAPAN,
	IFX_MAPI_WLAN_COUNTRY_ESP
};

/* the order of strings in this array must match to the typedef enum
   IFX_MAPI_WLAN_Standard; this is mandatory to guarantee that the correct
   options are displayed in the Web GUI */
char8 ifx_mapi_wlan_standard[][32] = {
	{"802.11BG"},			/* IFX_MAPI_WLAN_STANDARD_802_11BG */
	{"802.11A"},			/* IFX_MAPI_WLAN_STANDARD_802_11A */
	{"802.11B"},			/* IFX_MAPI_WLAN_STANDARD_802_11B */
	{"802.11G"},			/* IFX_MAPI_WLAN_STANDARD_802_11G */
	{"802.11N"},			/* IFX_MAPI_WLAN_STANDARD_802_11N */
	{"802.11BGN"},			/* IFX_MAPI_WLAN_STANDARD_802_11BGN */
	{"802.11GN"},			/* IFX_MAPI_WLAN_STANDARD_802_11GN */
	{"802.11AN"},			/* IFX_MAPI_WLAN_STANDARD_802_11AN */
	{"802.11AC"},			/* IFX_MAPI_WLAN_STANDARD_802_11AC */
	{"802.11ACN"},			/* IFX_MAPI_WLAN_STANDARD_802_11ACN */
	{"802.11ACNA"}			/* IFX_MAPI_WLAN_STANDARD_802_11ACNA */
};

/* the order of strings in this array must correspond to the typedef enum
   IFX_MAPI_WLAN_UsageEnv */
char8 ifx_mapi_wlan_usage_env[][32] = {
	{"All Environments"}
	,			/* IFX_MAPI_WLAN_ALL_ENV */
	{"Indoor"}
	,			/* IFX_MAPI_WLAN_INSIDE_ENV */
	{"Outdoor"}		/* IFX_MAPI_WLAN_OUTSIDE_ENV */
};

/* the order of strings in this array must correspond to the typedef enum
   IFX_MAPI_WLAN_PreambleType */
char8 ifx_mapi_wlan_preamble[][32] = {
	{"No Preamble"}
	,			/* IFX_MAPI_WLAN_PREAMBLE_NONE */
	{"Short Preamble"}
	,			/* IFX_MAPI_WLAN_PREAMBLE_SHORT */
	{"Long Preamble"}
	,			/* IFX_MAPI_WLAN_PREAMBLE_LONG */
	{"Auto Selection"}	/* IFX_MAPI_WLAN_PREAMBLE_AUTO */
};

/* the order of strings in this array must correspond to the typedef enum
   IFX_MAPI_WLAN_PreambleType */
char8 ltq_mapi_wlan_nAntenna[][32] = {
	{"1x1"},
	{"2x2"},
	{"3x3"}
};

char8 wlan_beacon_type[][32] = {
	{"WLAN_BEACON_BASIC"}
	,
	{"WLAN_BEACON_WPA"}
	,
	{"WLAN_BEACON_WPA2"}
	,
	{"WLAN_BEACON_WPA_WPA2"}
};

char8 wlan_encr_type[][32] = {
	{"None"}
	,
	{"WEP"}
	,
	{"TKIP"}
	,
	{"CCMP"}
	,
	{"TKIP_CCMP"}
};

char8 wlan_key_index[][32] = {
	{"Key1"}
	,
	{"Key2"}
	,
	{"Key3"}
	,
	{"Key4"}
};

char8 wlan_encr_lvl[][32] = {
	{"64-bit"}
	,
	{"128-bit"}
};

char8 wlan_key_type[][32] = {
	{"ASCII Key"}
	,
	{"HEX Key"}
};
char8 wlan_auth_type[][32] = {
	{"Open Authentication"}
	,
	{"Shared Authentication"}
	,
	{"Enterprise(RADIUS)"}
	,
	{"Personal(PSK)"}
};

char8 wlan_power_level[][32] = {
	{"100%"}
	,
	{"80%"}
	,
	{"60%"}
	,
	{"40%"}
	,
	{"20%"}
	,
	{"Automatic Selection"}
};

char8 wlan_channel_width[][32] = {
	{"20MHz"},
	{"20/40 MHz"},
	{"40MHz"},
	{"80MHz"},
	{"160MHz"}
};

char8 wlan_ext_chan[][32] = {
	{"Above Control Channel"}
	,
	{"Below Control Channel"}
};

char8 wlan_direction[][32] = {
	{"RX"}
	,
	{"TX"}
	,
	{"Both"}
};

char8 stbc_enable[][32] = {
	{"OFF"}
	,
	{"ON"}
};

char8 wlan_enable[][32] = {
	{"OFF"}
	,
	{"ON"}
};

char8 wlan_40M_intolerant[][32] = {
	{"Not Intolerant"}
	,
	{"Intolerant"}
};

char8 wlan_aggregation_ampdu_length[][32] = {
	{"8191"}
	,
	{"16383"}
	,
	{"32767"}
	,
	{"65535"}
};

char8 wlan_aggregation_amsdu_length[][32] = {
	{"3839"}
	,
	{"7935"}
};

char8 wlan_guard_intvl[][32] = {
	{"Short (400ns)"}
	,
	{"Long (800ns)"}
	,
	{"Auto"}
};

char8 wlan_net_mode_class[][32] = {
	{"802.11 B or N"},
	{"802.11 G, BG, GN or BGN"},
	{"802.11 A, N or AN"}
};

char8 wlan_mcs[][32] = {
	{"MCS 0"}
	,
	{"MCS 1"}
	,
	{"MCS 2"}
	,
	{"MCS 3"}
	,
	{"MCS 4"}
	,
	{"MCS 5"}
	,
	{"MCS 6"}
	,
	{"MCS 7"}
	,
	{"MCS 8"}
	,
	{"MCS 9"}
	,
	{"MCS 10"}
	,
	{"MCS 11"}
	,
	{"MCS 12"}
	,
	{"MCS 13"}
	,
	{"MCS 14"}
	,
	{"MCS 15"}
	,
	{"Auto"}
};

char8 wave_AckBoost[][32] = {
	{"Full Boost on all packets"}
	,
	{"Full Boost on data packets"}
	,
	{"Regular Boost on all packets"}
	,
	{"Regular Boost on data packets"}
	,
	{"No Boost"}
};

char8 wlan_11b_rates [][32] = {
	{"Auto"},
	{"1.0"},
	{"2.0"},
	{"5.5"},
	{"11.0"}
};

char8 wlan_11a_rates [][32] = {
	{"Auto"},
	{"6.0"},
	{"9.0"},
	{"12.0"},
	{"18.0"},
	{"24.0"},
	{"36.0"},
	{"48.0"},
	{"54.0"}
};

char8 wlan_11g_rates [][32] = {
	{"Auto"},
	{"1.0"},
	{"2.0"},
	{"5.5"},
	{"6.0"},
	{"9.0"},
	{"11.0"},
	{"12.0"},
	{"18.0"},
	{"24.0"},
	{"36.0"},
	{"48.0"},
	{"54.0"}
};

/* available rates in 802.11xn mode, 20MHz bandwidth, guard interval = high */
char8 wlan_11n_20_rates [][32] = {
	{"Auto"},
	{"6.5"},
	{"13.0"},
	{"19.5"},
	{"26.0"},
	{"39.0"},
	{"52.0"},
	{"58.5"},
	{"65.0"},
	{"78.0"},
	{"104.0"},
	{"117.0"},
	{"130.0"}
};

/* available rates in 802.11xn mode, 20MHz bandwidth, guard interval = low */
char8 wlan_11n_20_low_rates [][32] = {
	{"Auto"},
	{"7.2"},
	{"14.4"},
	{"21.7"},
	{"28.9"},
	{"43.3"},
	{"57.8"},
	{"65.0"},
	{"72.2"},
	{"86.7"},
	{"115.6"},
	{"130.0"},
	{"144.4"}
};

/* available rates in 802.11xn mode, 40MHz bandwidth, guard interval = high */
char8 wlan_11n_40_rates [][32] = {
	{"Auto"},
	{"13.0"},
	{"27.0"},
	{"40.5"},
	{"54.0"},
	{"81.0"},
	{"108.0"},
	{"121.5"},
	{"135.0"},
	{"162.0"},
	{"216.0"},
	{"243.0"},
	{"270.0"}
};

/* available rates in 802.11xn mode, 40MHz bandwidth, guard interval = low */
char8 wlan_11n_40_low_rates [][32] = {
	{"Auto"},
	{"15.0"},
	{"30.0"},
	{"45.0"},
	{"60.0"},
	{"90.0"},
	{"120.0"},
	{"135.0"},
	{"150.0"},
	{"180.0"},
	{"240.0"},
	{"270.0"},
	{"300.0"}
};

#ifdef CONFIG_FEATURE_LTQ_WIRELESS_VB
extern LTQ_MAPI_WLAN_VB_GEN_BD_Cfg g_vbGenConfig[1];
extern void ltq_vb_load_global_config(int eid, httpd_t wp, int argc,
				      char_t ** argv);
#endif

int g_idx = 0;
int gNumEntries = 0;
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
int gNumVapRadio1 = 1;
int gNumVapRadio2 = 1;
#endif				/* #ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS */

IFX_MAPI_WLAN_MAC_Control g_wlMacControl[LTQ_MAX_NUM_VAP][LTQ_MAX_NUM_MAC_FILTER_ENTRIES];
int gMacCount[LTQ_MAX_NUM_VAP];

LTQ_MAPI_WLAN_WPS_EP_MAC_Cfg	g_wlWpsEpMacTable[LTQ_MAX_NUM_VAP][LTQ_MAX_NUM_WPS_EP_MAC];
int gWpsEpMacCount[LTQ_MAX_NUM_VAP];

IFX_MAPI_WLAN_MAC_Control g_wlWdsPeerMacList[LTQ_MAX_NUM_VAP][LTQ_MAX_NUM_MAC_FILTER_ENTRIES];
int gWdsPeerMacCount[LTQ_MAX_NUM_VAP];

/* ========================================================================== */
/*                           Function prototypes                              */
/* ========================================================================== */
extern int ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);
static int WLAN_GetStandard(httpd_t wp, IFX_MAPI_WLAN_PhyCfg * wlPhy);
int ltq_get_wlan_freqBand(httpd_t wp, IFX_MAPI_WLAN_FreqBand freqBand);
static int WLAN_GetCountry(httpd_t wp, IFX_MAPI_WLAN_PhyCfg * wlPhy);

int IFX_WLAN_GetBasicSettings(int eid, httpd_t wp, int argc, char_t ** argv);
int IFX_WLAN_Get80211nSettings(int eid, httpd_t wp, int argc, char_t ** argv);
int ltq_get_wave_adv_settings(int eid, httpd_t wp, int argc, char_t ** argv);
int IFX_WLAN_GetChannelList(int eid, httpd_t wp, int argc, char_t ** argv);
int LTQ_WLAN_GetMainConfiguration(int eid, httpd_t wp, int argc,
				  char_t ** argv);
int IFX_WLAN_GetApList(int eid, httpd_t wp, int argc, char_t ** argv);
int IFX_WLAN_GetAllWmmConfigurations(int eid, httpd_t wp, int argc,
				     char_t ** argv);
int IFX_WLAN_GetAllWpsConfigurations(int eid, httpd_t wp, int argc,
				     char_t ** argv);
int IFX_WLAN_GetWpsConfiguration(int eid, httpd_t wp, int argc, char_t ** argv);
int IFX_WLAN_GetSecurityConfiguration(int eid, httpd_t wp, int argc,
				      char_t ** argv);
int IFX_WLAN_GetAllSecurityConfigurations(int eid, httpd_t wp, int argc,
					  char_t ** argv);
int IFX_WLAN_GetMacControl(int eid, httpd_t wp, int argc, char_t ** argv);
int IFX_WLAN_GetMacCount(int eid, httpd_t wp, int argc, char_t ** argv);
int IFX_WLAN_GetAllGlobalMacContrlEntries(int eid, httpd_t wp, int argc,
					  char_t ** argv);
int IFX_WLAN_GetGlobalMacControlStatus(int eid, httpd_t wp, int argc,
				       char_t ** argv);
void IFX_WLAN_GetDeviceAssociations(int eid, httpd_t wp, int argc,
				    char_t ** argv);
void IFX_WLAN_GetStatistics(int eid, httpd_t wp, int argc, char_t ** argv);
int IFX_WLAN_GetApSettings(int eid, httpd_t wp, int argc, char_t ** argv);
int IFX_WLAN_GetApValues(int eid, httpd_t wp, int argc, char_t ** argv);
/*
 * For diagnostics web page
 */
int ifx_diag_get_wlan_enable(int eid, httpd_t wp, int argc, char_t ** argv);
int ltq_update_wps_page(int eid, httpd_t wp, int argc, char_t ** argv);
void ltq_get_ap_index_list(int eid, httpd_t wp, int argc, char_t ** argv);
void ltq_load_global_config(int eid, httpd_t wp, int argc, char_t ** argv);
void ltq_update_settings_for_vap(int eid, httpd_t wp, int argc, char_t ** argv);
void ltq_update_settings_wmm(int eid, httpd_t wp, int argc, char_t ** argv);
void ltq_get_validation_before_wpsStart(int eid, httpd_t wp, int argc,
					char_t ** argv);
void ltq_wlan_get_all_mac_filter_config(int eid, httpd_t wp, int argc,
				   char_t ** argv);
void ltq_wlan_get_all_wds_config(int eid, httpd_t wp, int argc, char_t ** argv);
void ltq_wlan_wds_update_peer_mac_table(int eid, httpd_t wp, int argc,
		char_t ** argv);
void ltq_wlan_create_peer_mac_table(int eid, httpd_t wp, int argc, char_t ** argv);

/* ========================================================================== */
/*                         Function implementation                            */
/* ========================================================================== */

/**
   Local support function to add quoting to strings that contain " ' \

   \param char_t	str

   \param char_t	quotedStr
*/
static void ltq_wlan_add_quoting_2_string(char_t *str, char_t *quotedStr)
{
	int i = 0, j = 0;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_add_quoting_2_string", "string: %s", str);
	for (i = 0; i < strlen(str); i++) {
		if ((str[i] == '\'') ||
			(str[i] == '\"') ||
			(str[i] == '\\')) {
			quotedStr[j++] = '\\';
			quotedStr[j] = str[i];
		} else {
			quotedStr[j] = str[i];
		}
		j++;
	}
	quotedStr[j] = '\0';
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_add_quoting_2_string", "quotedStr: %s", quotedStr);
}

/**
   Local support function to obtain information about the selected operation
   mode (802.11 standard, b, g, etc.). The information is presented on web page
   "Radio Settings" (wlan_basic.asp).

   \param wp      web page structure

   \param wlPhy   point to IFX_MAPI_WLAN_PhyCfg structure holding information
                  about common (radio) parameters

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
static int WLAN_GetStandard(httpd_t wp, IFX_MAPI_WLAN_PhyCfg * wlPhy)
{
	int32 ret = IFX_SUCCESS, i;

	IFX_MAPI_DEBUG(fd, "/tmp/WLAN_GetStandard", "");

	ifx_httpdWrite(wp, T("<td width=\"40%\">"));
	ifx_httpdWrite(wp, T("Operational Mode"));
	ifx_httpdWrite(wp, T("</td>"));
	ifx_httpdWrite(wp, T("<td width=\"60%\">"));
	ifx_httpdWrite(wp, T ("<select name=\"op_mode\" onChange=\"updatePage()\">"));
	IFX_MAPI_DEBUG(fd, "/tmp/WLAN_GetStandard", "g_idx: %d", g_idx);
	IFX_MAPI_DEBUG(fd, "/tmp/WLAN_GetStandard", "standard: %d, freqBand: %d",
		wlPhy->standard, wlPhy->freqBand);
	/*
	   depending on standard and capability of device, different options are
	   displayed */
	i = 0;
	/* do-while to go through all supported standards in capabilities */
	do {
		if ((wlPhy->freqBand == IFX_MAPI_WLAN_2_4_GHz_Freq &&
		     (g_wlCaps[g_idx].std[i] == IFX_MAPI_WLAN_STD_802_11BG ||
		      g_wlCaps[g_idx].std[i] == IFX_MAPI_WLAN_STD_802_11B ||
		      g_wlCaps[g_idx].std[i] == IFX_MAPI_WLAN_STD_802_11G ||
		      g_wlCaps[g_idx].std[i] == IFX_MAPI_WLAN_STD_802_11N ||
		      g_wlCaps[g_idx].std[i] == IFX_MAPI_WLAN_STD_802_11BGN ||
		      g_wlCaps[g_idx].std[i] == IFX_MAPI_WLAN_STD_802_11GN)
		    ) ||
		    (wlPhy->freqBand == IFX_MAPI_WLAN_5_GHz_Freq &&
		     (g_wlCaps[g_idx].std[i] == IFX_MAPI_WLAN_STD_802_11A ||
		      g_wlCaps[g_idx].std[i] == IFX_MAPI_WLAN_STD_802_11N ||
		      g_wlCaps[g_idx].std[i] == IFX_MAPI_WLAN_STD_802_11AN ||
		      g_wlCaps[g_idx].std[i] == IFX_MAPI_WLAN_STD_802_11AC ||
		      g_wlCaps[g_idx].std[i] == IFX_MAPI_WLAN_STD_802_11ACN ||
		      g_wlCaps[g_idx].std[i] == IFX_MAPI_WLAN_STD_802_11ACNA)
		    )) {
			IFX_MAPI_DEBUG(fd, "/tmp/WLAN_GetStandard",
				       "g_wlCaps[g_idx=%d].std[i=%d]: %d",
				       g_idx, i, g_wlCaps[g_idx].std[i]);
			ifx_httpdWrite(wp, T("<option value='%d'"),
				       g_wlCaps[g_idx].std[i]);
			/* if this is also current selected country according to wlPhy
			   configuration, display this accordingly */
#ifdef CONFIG_LTQ_AEI_CUST
			if ((gOpMode < IFX_MAPI_WLAN_STD_802_11_ALL) &&
				(wlPhy->standard == IFX_MAPI_WLAN_STD_802_11BG)) {
				if (gOpMode == g_wlCaps[g_idx].std[i])
					ifx_httpdWrite(wp, T("%s"), " selected");
			}
			else 
#endif
			if (wlPhy->standard == g_wlCaps[g_idx].std[i])
				ifx_httpdWrite(wp, T("%s"), " selected");

			/* select the correct string from the array ifx_mapi_wlan_standard */
			ifx_httpdWrite(wp, T(">%s</option>"),
				       ifx_mapi_wlan_standard[g_wlCaps[g_idx].
							      std[i]]);
		}
		i++;
	} while ((i < IFX_MAPI_WLAN_MAX_STD)
		 && (g_wlCaps[g_idx].std[i] != 0xFFFFFFFF));

	/* closing tags */
	ifx_httpdWrite(wp, T("</script></select></td>"));
	return ret;
}

/**
   Local support function to obtain information about the selected frequency
   band (2.4 GHz or 5GHz band). The information is presented on web page
   "Radio Settings" (wlan_basic.asp).

   \param wp      web page structure

   \param wlPhy   point to IFX_MAPI_WLAN_PhyCfg structure holding information
                  about common (radio) parameters

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int ltq_get_wlan_freqBand(httpd_t wp, IFX_MAPI_WLAN_FreqBand freqBand)
{
	int32 ret = IFX_SUCCESS;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_wlan_freqBand", "g_idx: %d", g_idx);

	/*
	   depending on the device capabilty, options are displayed or the dialogue
	   is disabled */
	switch (g_wlCaps[g_idx].freq) {
	case IFX_MAPI_WLAN_2_4_GHz_Freq:
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_wlan_freqBand", "");
		ifx_httpdWrite(wp,
			       T
			       ("document.write(\"<option value=\\\"0\\\" selected>2.4GHZ</option>\");"));
		// ifx_httpdWrite(wp, T("document.write(\"<option
		// value=\\\"1\\\">5GHZ</option>\");"));
		ifx_httpdWrite(wp,
			       T("document.tF0.frequency.disabled = false;"));
		break;
	case IFX_MAPI_WLAN_5_GHz_Freq:
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_wlan_freqBand", "");
		ifx_httpdWrite(wp,
			       T
			       ("document.write(\"<option value=\\\"1\\\" selected>5GHZ</option>\");"));
		ifx_httpdWrite(wp,
			       T("document.tF0.frequency.disabled = false;"));
		break;
	case IFX_MAPI_WLAN_DUAL_BAND:
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_wlan_freqBand", "");
		if (freqBand == IFX_MAPI_WLAN_2_4_GHz_Freq)
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<option value=\\\"0\\\" selected>2.4GHZ</option>\");"));
		else
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<option value=\\\"0\\\">2.4GHZ</option>\");"));

		if (freqBand == IFX_MAPI_WLAN_5_GHz_Freq)
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<option value=\\\"1\\\" selected>5GHZ</option>\");"));
		else
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<option value=\\\"1\\\">5GHZ</option>\");"));

#ifdef CONFIG_FEATURE_LTQ_WIRELESS_VB
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_wlan_freqBand", "mode: %d",
			       g_vbGenConfig[0].mode);
		if (g_vbGenConfig[0].mode == LTQ_MAPI_WLAN_VB_STA) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_wlan_freqBand",
				       "freqBand: %d", freqBand);
			if (freqBand == IFX_MAPI_WLAN_DUAL_BAND)
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<option value=\\\"2\\\" selected>Both</option>\");"));
			else
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<option value=\\\"2\\\">Both</option>\");"));
		}
#endif
		break;
	default:
		ifx_httpdWrite(wp, T("document.write(\"<option value=\\\"0\\\" "
			"selected>2.4GHZ</option>\");"));
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_wlan_freqBand", "Invalid entry for WLAN "
			"frequency band found in device capabilities: 0x%x",
			g_wlCaps[g_idx].freq);
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	}

      LTQ_Handler:
	return ret;
}

/**
   Local support function to obtain information about the selected regulatroy
   domain (country). The information is presented on web page "Radio Settings"
   (wlan_basic.asp).

   \param wp      web page structure

   \param wlPhy   point to IFX_MAPI_WLAN_PhyCfg structure holding information
                  about common (radio) parameters

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
static int WLAN_GetCountry(httpd_t wp, IFX_MAPI_WLAN_PhyCfg * wlPhy)
{
	int32 ret = IFX_SUCCESS, i = 0;

	/*
	   depending on capability of device, different options are displayed */
	i = 0;
	do {
		ifx_httpdWrite(wp, T("<option value='%s' "),
			       ifx_mapi_wlan_country[i][1]);
		/* if this is also current selected country according to wlPhy
		   configuration, display this accordingly */
		if (!gstrcmp(wlPhy->country, ifx_mapi_wlan_country[i][1]))
			ifx_httpdWrite(wp, T("%s"), "selected");
		ifx_httpdWrite(wp, T(">%s</opion>\n"),
			       ifx_mapi_wlan_country[i][0]);
		i++;
	} while (i < IFX_MAPI_WLAN_MAX_COUNTRY);

	return ret;
}

/**
   This function gets information required to display the web page for "Basic
   Settings" properly. It is called from wlan_basic.asp and wlan_advsetup.asp.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int IFX_WLAN_GetBasicSettings(int eid, httpd_t wp, int argc, char_t ** argv)
{
	IFX_MAPI_WLAN_ChannelList wlChanList;
	int32 ret = IFX_SUCCESS;
	uint32 i = 0, flags = IFX_F_DEFAULT;
	char8 *name, *cpeId;
	IFX_MAPI_WLAN_Capability wlCaps;
	bool f_nAntennasFound = FALSE;
	IFX_MAPI_WLAN_PhyCfg wlan_phy;

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetBasicSettings", "");

	/* parse arguments passed from web page */
	if (ifx_httpd_parse_args(argc, argv, T("%s,%s"), &name, &cpeId) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* initialize all structures */
	memset(&wlChanList, 0, sizeof(IFX_MAPI_WLAN_ChannelList));
	g_idx = atoi(cpeId);
	g_idx--;

	/*
	 * determine the supported capabilites
	*/
	/* initialize all structures */
	memset(&wlCaps, 0xFF, sizeof(IFX_MAPI_WLAN_Capability));
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	if (g_idx == 0) {
		if (ifx_mapi_get_wlan_capability(&wlCaps, IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400, T("Failed to get the device capabilities\n\r"));
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	} else if (g_idx == 1) {
		if (ifx_mapi_get_wlan_sec_capability(&wlCaps, IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400, T("Failed to get the second device capabilities\n\r"));
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	} else {
		ifx_httpdError(wp, 400, T("Radio index out of range\n"));
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
#else
	if (g_idx == 0) {
		if (ifx_mapi_get_wlan_capability(&wlCaps, IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400, T("Failed to get the device capabilities\n\r"));
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	} else {
		ifx_httpdError(wp, 400, T("Radio index out of range\n"));
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
#endif

	memset(&wlan_phy, 0, sizeof(IFX_MAPI_WLAN_PhyCfg));
	sprintf(wlan_phy.iid.cpeId.secName, "%s", TAG_WLAN_PHY);
	sprintf(wlan_phy.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
	wlan_phy.iid.cpeId.Id = atoi(cpeId);
	if ((ret = ifx_mapi_get_wlan_static_phy_config(&wlan_phy, IFX_F_DEFAULT)) !=
		IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get wlan radio configuration\n"));
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	if (!gstrcmp(name, T("COMMON_SETTINGS"))) {
		ifx_httpdWrite(wp, T("<table class=\"tableInput\" summary=\"\">\n"));
		ifx_httpdWrite(wp, T("<tr>\n<th class=\"curveLeft\" colspan=\"2\">"
			"Common Settings</th>\n</tr>\n"));
		/* WLAN_ENABLE */
		/* status or wlan radio enable button */
		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td width=\"40%\">"));
		ifx_httpdWrite(wp, T("WLAN Radio Enable"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("<td width=\"60%\">"));
		if (wlan_phy.radioEnable)
			ifx_httpdWrite(wp,T("<input type=CHECKBOX name=\"wlan_enable\" "
			"value=1 checked>"));
		else
			ifx_httpdWrite(wp, T("<input type=CHECKBOX name=\"wlan_enable\" "
			"value=1>"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("</tr>\n"));

		/* status of wlan */
		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td width=\"40%\">"));
		ifx_httpdWrite(wp, T("WLAN Radio Status"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("<td width=\"60%\"> "));
		if (wlan_phy.status)
			ifx_httpdWrite(wp, T("UP"));
		else
			ifx_httpdWrite(wp, T("DOWN"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("</tr>\n"));

		/* FREQ_BAND */
		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td width=\"40%\">"));
		ifx_httpdWrite(wp, T("Frequency Band"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("<td width=\"60%\">"));
		ifx_httpdWrite(wp, T("<select name=\"frequency\" id=\"frequency\" "
			"onChange=\"update_on_freq_change();\">"));
		ifx_httpdWrite(wp, T("<script>"));
		/*
		   call static support function to determine display options for
		   frequency bands */
		if ((ret = ltq_get_wlan_freqBand(wp, wlan_phy.freqBand)) !=
		    IFX_SUCCESS) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		ifx_httpdWrite(wp, T("</script>"));
		ifx_httpdWrite(wp, T("</select>"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("</tr>\n"));

		/* COUNTRY */
		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td width=\"40%\">"));
		ifx_httpdWrite(wp, T("Country"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("<td width=\"60%\">"));
		ifx_httpdWrite(wp,
			       T
			       ("<select name=\"country\" onChange=\"disable_ch_list()\">"));
		/*
		   call static support function to determine display options for
		   country settings */
		if ((ret = WLAN_GetCountry(wp, &wlan_phy)) != IFX_SUCCESS) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		ifx_httpdWrite(wp, T("</select>"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("</tr>\n"));

		/* ACS */
		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td width=\"40%\">"));
		ifx_httpdWrite(wp, T("Auto Channel Select Enable"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("<td width=\"60%\">"));
		ifx_httpdWrite(wp,
			       T
			       ("<input type=CHECKBOX name=\"auto_channel_select\" value=1 onclick=\"updateOnAutoChanSelChange();\""));
		if (wlan_phy.autoChannelEna)
			ifx_httpdWrite(wp, T("checked >"));
		else
			ifx_httpdWrite(wp, T(">"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("</tr>\n"));

		/* CHANNEL */
		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td width=\"40%\">"));
		ifx_httpdWrite(wp, T("Channel No."));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("<td width=\"60%\">"));
		ifx_httpdWrite(wp,
			T("<select name=\"channel\" onChange=\"updateExtChan();\">"));
		if (wlan_phy.autoChannelEna)
			ifx_httpdWrite(wp,
				       T("<option value='0' selected>Auto"));
		else {
			/* channel list depends on standard, frequncy and country setting */
			wlChanList.std = wlan_phy.standard;
			wlChanList.freqBand = wlan_phy.freqBand;
			gstrcpy(wlChanList.country, wlan_phy.country);
			if ((ret = ifx_mapi_get_wlan_channel_list(wlan_phy.iid.cpeId.Id,
				&wlChanList, flags)) != IFX_SUCCESS) {
				ret = IFX_FAILURE;
				ifx_httpdError(wp, 400, T("Failed to get channel list\n"));
				goto IFX_Handler;
			}

			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetBasicSettings",
				"length: %d; channel: %d", wlChanList.length,
				wlan_phy.channelNo);
			for (i = 0; i < wlChanList.length; i++) {
				ifx_httpdWrite(wp, T("<option value='%d' "),
					wlChanList.chanNumList[i]);
				IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetBasicSettings",
					"channel[%d]: %d", i, wlChanList.chanNumList[i]);
				if (wlan_phy.channelNo ==
				    wlChanList.chanNumList[i]) {
					ifx_httpdWrite(wp, T("%s"), "selected");
				}
				ifx_httpdWrite(wp, T(">%d</option>"),
					       wlChanList.chanNumList[i]);
			}
		}
		ifx_httpdWrite(wp, T("</select>"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("</tr>\n"));


		/* OPER_MODE */
		ifx_httpdWrite(wp, T("<tr>"));
		/*
		   call static support function to determine display options for
		   operation mode */
		if ((ret = WLAN_GetStandard(wp, &wlan_phy)) != IFX_SUCCESS) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		ifx_httpdWrite(wp, T("</tr>\n"));

		if (ltq_mapi_get_wlan_supported_features(wlan_phy.iid.cpeId.Id,
			IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_NETMODE_PER_VAP) {
			ifx_httpdWrite(wp, T("</table>\n"));
			ifx_httpdWrite(wp, T("<div id=\"net_mode_vap\">\n"));
			ifx_httpdWrite(wp, T("<table class=\"tableInput\" summary=\"\">\n"));
			/* Network mode per VAP */
			ifx_httpdWrite(wp, T("<tr>"));
			ifx_httpdWrite(wp, T("<td width=\"40%\">"));
			ifx_httpdWrite(wp, T("Enable network mode per VAP settings"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("<td width=\"60%\">"));
			if (wlan_phy.netModeClass < LTQ_MAPI_WLAN_NET_CLASS_OFF)
				ifx_httpdWrite(wp, T("<input type=CHECKBOX "
				"name=\"net_mode_vap_ena\" value=1 onclick=\"updatePage();\" checked>"));
			else
				ifx_httpdWrite(wp, T("<input type=CHECKBOX "
				"name=\"net_mode_vap_ena\" value=1 onclick=\"updatePage();\">"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("</tr>\n"));
			ifx_httpdWrite(wp, T("</table>\n</div>\n\n"));

			ifx_httpdWrite(wp, T("<div id=\"net_mode_class\">\n"));
			ifx_httpdWrite(wp, T("<table class=\"tableInput\" summary=\"\">\n"));
			/* Select operational mode class */
			ifx_httpdWrite(wp, T("<tr>"));
			ifx_httpdWrite(wp, T("<td width=\"40%\">"));
			ifx_httpdWrite(wp, T("Select Network Mode Class"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("<td width=\"60%\">"));

			ifx_httpdWrite(wp, T("<select name=\"net_mode_class\">"));
			switch (wlan_phy.freqBand) {
			case IFX_MAPI_WLAN_2_4_GHz_Freq:
				for (i = 0; i < 2; i++) {
					ifx_httpdWrite(wp, T("<option value='%d' "), i);
					if (wlan_phy.netModeClass == i) {
						ifx_httpdWrite(wp, T("%s"), "selected");
					}
					ifx_httpdWrite(wp, T(">%s"), wlan_net_mode_class[i]);
				}
				break;
			case IFX_MAPI_WLAN_5_GHz_Freq:
				ifx_httpdWrite(wp, T("<option value='2'"), i);
				if (wlan_phy.netModeClass == LTQ_MAPI_WLAN_NET_CLASS_A_N_AN) {
					ifx_httpdWrite(wp, T(" %s"), "selected");
				}
				ifx_httpdWrite(wp, T(">%s"), wlan_net_mode_class[2]);
				break;
			default:
				IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetBasicSettings",
					"FreqBand out of range");
				break;
			}
			ifx_httpdWrite(wp, T("</select\n>"));
			ifx_httpdWrite(wp, T("</td\n>"));
			ifx_httpdWrite(wp, T("</tr>\n"));
			ifx_httpdWrite(wp, T("</table>\n</div>\n\n"));

			ifx_httpdWrite(wp, T("<table class=\"tableInput\" summary=\"\">\n"));
		} /* LTQ_WAVE_NETWORK_MODE_PER_VAP */

		/* ARF */
		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td width=\"40%\">"));
		ifx_httpdWrite(wp, T("Auto Rate Fallback Enable"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("<td width=\"60%\">"));
		ifx_httpdWrite(wp,
			       T("<input type=CHECKBOX name=\"ARF\" value=1 "));
		if (wlan_phy.autoRateFallBackEna)
			ifx_httpdWrite(wp, T("checked>"));
		else
			ifx_httpdWrite(wp, T(">"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("</tr>\n"));

		if (ltq_mapi_get_wlan_vendor(g_idx+1, IFX_F_DEFAULT) ==
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			/*
			 *  max number of clients per radio
			 */
			ifx_httpdWrite(wp, T("<tr>\n"));
			ifx_httpdWrite(wp, T("<td width=\"40%\">"));
			ifx_httpdWrite(wp, T("Max. number of WLAN clients per radio"));
			ifx_httpdWrite(wp, T("</td>\n"));
			ifx_httpdWrite(wp, T("<td width=\"60%\">\n"));
			if (g_wlCaps[g_idx].maxWlanClients == 0) {
				ifx_httpdWrite(wp,
					T("<input name=\"maxClientsPerRadio\" value=\"n/a\" disabled>\n"));
			}
			else {
				ifx_httpdWrite(wp,
					T("<input name=\"maxClientsPerRadio\" value=\" %d\" disabled>\n"),
					g_wlCaps[g_idx].maxWlanClients);
			}
			ifx_httpdWrite(wp, T("</td></tr>\n"));
		}

		ifx_httpdWrite(wp, T("</table>\n"));
	} else if (!gstrcmp(name, T("ADVANCED"))) {
		ifx_httpdWrite(wp,
			T("<input type=hidden name=\"frequency_%d\" value=%d>"),
			g_idx + 1, wlan_phy.freqBand);
		ifx_httpdWrite(wp,
			T("<tr class=\"decBold\">\n<th colspan=\"2\">"
			"WLAN General Config</th>\n</tr>"));

		/* PREAMBLE */
		ifx_httpdWrite(wp, T("<tr>\n<td>Preamble</td>\n<td>\n"
			"<select name=\"preamble\">\n"));

		if (ltq_mapi_get_wlan_vendor(g_idx+1, IFX_F_DEFAULT) ==
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			i = 1;
		} else {
			i = 0;
		}
		for (; i < IFX_MAX_WLAN_PREAMBLE_MODES; i++) {
			ifx_httpdWrite(wp, T("<option value='%d' "), i);
			if (wlan_phy.preamble == i) {
				ifx_httpdWrite(wp, T("%s"), "selected");
			}
			ifx_httpdWrite(wp, T(">%s"), ifx_mapi_wlan_preamble[i]);
		}
		ifx_httpdWrite(wp, T("</select>\n</td>\n</tr>\n"));

		/* BEACON enable */
		if (ltq_mapi_get_wlan_vendor(g_idx+1, IFX_F_DEFAULT) ==
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			ifx_httpdWrite(wp, T("<input type=hidden name=\"beacon_tx_enable\" "
				"value=\"1\">"));
		} else {
			ifx_httpdWrite(wp, T("<tr>\n\t<td>Beacon Transmission Enable</td>"
				"\n<td>\n"));
			ifx_httpdWrite(wp, T("<input type=CHECKBOX name=\"beacon_tx_enable\" "
				"value=1 "));
			if (wlan_phy.beaconTxEna)
				ifx_httpdWrite(wp, T("checked>"));
			else
				ifx_httpdWrite(wp, T(">"));
			ifx_httpdWrite(wp, T("</td>\n\t</tr>"));
		}

		/* BEACON interval */
		ifx_httpdWrite(wp, T("<tr>\n<td width=\"40%\">Beacon Interval</td>\n"
			"<td width=\"60%\">"));
		if (ltq_mapi_get_wlan_vendor(g_idx+1, IFX_F_DEFAULT) ==
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			ifx_httpdWrite(wp, T("<input name=\"beacon_int\" value=%d> in ms "
				"[20..999]"), wlan_phy.beaconIntvl);
		} else {
			ifx_httpdWrite(wp, T("<input name=\"beacon_int\" value=%d> in ms "
				"[1..65535]"), wlan_phy.beaconIntvl);
		}
		ifx_httpdWrite(wp, T("</td>\n</tr>"));

		/* DTIM interval */
		ifx_httpdWrite(wp,
			       T
			       ("<tr>\n<td>DTIM Interval</td>\n<td>\n<input name=\"dtim_int\" value="));
		ifx_httpdWrite(wp, T("%u"), wlan_phy.dtimInt);
		ifx_httpdWrite(wp, T("> in beacons [1..255]</td>\n</tr>"));

		/* Power level */
		ifx_httpdWrite(wp,
			       T
			       ("<tr>\n<td>Power Level</td>\n<td>\n<select name=\"power_level\">"));
		ifx_httpdWrite(wp, T("<option value='0'"));
		if (wlan_phy.powerLvl == 0) {
			ifx_httpdWrite(wp, T("%s"), "selected");
		}
		ifx_httpdWrite(wp, T(">Auto</option>"));
		i = 0;
		do {
			ifx_httpdWrite(wp, T("<option value='%d'"),
				       g_wlCaps[g_idx].powerLevelsSupported[i]);
			if (wlan_phy.powerLvl ==
			    g_wlCaps[g_idx].powerLevelsSupported[i]) {
				ifx_httpdWrite(wp, T("%s"), "selected");
			}
			ifx_httpdWrite(wp, T(">%d %</option>"),
				       g_wlCaps[g_idx].powerLevelsSupported[i]);
			i++;
		} while ((i < IFX_MAPI_WLAN_MAX_STD)
			 && (g_wlCaps[g_idx].powerLevelsSupported[i] != 0xFF));
		ifx_httpdWrite(wp, T("</select>\n</td>\n</tr>"));

		/* RTS */
		ifx_httpdWrite(wp, T("<tr>\n<td>\nRTS Threshold</td>\n<td>"));
		ifx_httpdWrite(wp, T("<input name=\"rts\" value=%d> in bytes [0..2347]"),
			wlan_phy.rts);
		ifx_httpdWrite(wp, T("</td>\n</tr>"));

		/* Fragmentation threshold (not supported by WAVE) */
		if (ltq_mapi_get_wlan_vendor(g_idx+1, IFX_F_DEFAULT) !=
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			ifx_httpdWrite(wp, T("<tr>\n<td>Fragmentation Threshold</td>\n<td>"));
			ifx_httpdWrite(wp, T("<input name=\"fts\" value=%d> in bytes "
				"[256..2346]"), wlan_phy.fts);
			ifx_httpdWrite(wp, T("</td></tr>"));
		}

		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetBasicSettings",
			"standard: %d; bandwidth: %d, guard: %d, staticRate: %f",
			wlan_phy.standard, wlan_phy.phy11N.chanBW,
			wlan_phy.phy11N.guardIntvl, wlan_phy.staticRate);

		/* STATIC RATE */
		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td width=\"40%\">"));
		ifx_httpdWrite(wp, T("Static Rate in Mbit/s"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("<td width=\"60%\">"));

		ifx_httpdWrite(wp, T("<select name=\"static_rate\">"));
		if (wlan_phy.standard >= IFX_MAPI_WLAN_STD_802_11N) {
			if (wlan_phy.phy11N.chanBW == IFX_MAPI_WLAN_BW_20MHZ) {
				if (wlan_phy.phy11N.guardIntvl == IFX_MAPI_WLAN_GI_LOW) {
					for (i = 0; i <= 12; i++) {
						ifx_httpdWrite(wp, T("<option value='%d' "), i);
						if (wlan_phy.staticRate == (float)strtod(wlan_11n_20_rates[i], (char **)NULL))
							ifx_httpdWrite(wp, T("%s"), "selected");
	
						ifx_httpdWrite(wp, T(">%s"), wlan_11n_20_low_rates[i]);
					}
				} else {
					for (i = 0; i <= 12; i++) {
						ifx_httpdWrite(wp, T("<option value='%d' "), i);
						if (wlan_phy.staticRate == (float)strtod(wlan_11n_20_rates[i], (char **)NULL))
							ifx_httpdWrite(wp, T("%s"), "selected");
	
						ifx_httpdWrite(wp, T(">%s"), wlan_11n_20_rates[i]);
					}
				}
			} else {
				if (wlan_phy.phy11N.guardIntvl == IFX_MAPI_WLAN_GI_LOW) {
					for (i = 0; i <= 12; i++) {
						ifx_httpdWrite(wp, T("<option value='%d' "), i);
						if (wlan_phy.staticRate == (float)strtod(wlan_11n_40_rates[i], (char **)NULL))
							ifx_httpdWrite(wp, T("%s"), "selected");
		
						ifx_httpdWrite(wp, T(">%s"), wlan_11n_40_low_rates[i]);
					}
				} else {
					for (i = 0; i <= 12; i++) {
						ifx_httpdWrite(wp, T("<option value='%d' "), i);
						if (wlan_phy.staticRate == (float)strtod(wlan_11n_40_rates[i], (char **)NULL))
							ifx_httpdWrite(wp, T("%s"), "selected");
	
						ifx_httpdWrite(wp, T(">%s"), wlan_11n_40_rates[i]);
					}
				}
			}
		}
		else if (wlan_phy.standard == IFX_MAPI_WLAN_STD_802_11A) {
			for (i = 0; i <= 8; i++) {
				ifx_httpdWrite(wp, T("<option value='%d' "), i);
				if (wlan_phy.staticRate == (float)strtod(wlan_11a_rates[i], (char **)NULL))
					ifx_httpdWrite(wp, T("%s"), "selected");
	
				ifx_httpdWrite(wp, T(">%s"), wlan_11a_rates[i]);
			}
		}
		else if (wlan_phy.standard == IFX_MAPI_WLAN_STD_802_11B) {
			for (i = 0; i <= 4; i++) {
				ifx_httpdWrite(wp, T("<option value='%d' "), i);
				if (wlan_phy.staticRate == (float)strtod(wlan_11b_rates[i], (char **)NULL))
					ifx_httpdWrite(wp, T("%s"), "selected");
	
				ifx_httpdWrite(wp, T(">%s"), wlan_11b_rates[i]);
			}
		}
		else {
			for (i = 0; i <= 12; i++) {
				ifx_httpdWrite(wp, T("<option value='%d' "), i);
				if (wlan_phy.staticRate == (float)strtod(wlan_11g_rates[i], (char **)NULL))
					ifx_httpdWrite(wp, T("%s"), "selected");
	
				ifx_httpdWrite(wp, T(">%s"), wlan_11g_rates[i]);
			}
		}
		ifx_httpdWrite(wp, T("</select>"));

		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("</tr>"));

		if (ltq_mapi_get_wlan_vendor(g_idx+1, IFX_F_DEFAULT) ==
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			/* 802.11h Radar Detection */
			if (wlan_phy.freqBand == IFX_MAPI_WLAN_5_GHz_Freq) {
				ifx_httpdWrite(wp, T("<tr>"));
				ifx_httpdWrite(wp,
						   T("<td width=\"40%\">802.11h Radar Detection</td>\n"));
				ifx_httpdWrite(wp, T("<td width=\"60%\">\n"));

				ifx_httpdWrite(wp, T("<select name=\"wave_radar_ena\">\n"));
				for (i = 0; i <= 1; i++) {
					ifx_httpdWrite(wp, T("<option value='%d' "), i);
					if (wlan_phy.radarEna == i) {
						ifx_httpdWrite(wp, T("%s"), "selected");
					}
					ifx_httpdWrite(wp, T(">%s"), wlan_enable[i]);
				}
				ifx_httpdWrite(wp, T("</select>\n"));
				ifx_httpdWrite(wp, T("</td>\n</tr>\n"));
			}
		}

		/* Environment (not supported by WAVE) */
		if (ltq_mapi_get_wlan_vendor(g_idx+1, IFX_F_DEFAULT) !=
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			ifx_httpdWrite(wp, T("<tr>\n<td>Usage Environment</td>\n<td>"));
			ifx_httpdWrite(wp, T("<select name=\"usage_env\">"));
			for (i = 0; i < 3; i++) {
				ifx_httpdWrite(wp, T("<option value='%d' "), i);
				/* if this is also current selected country according to wlPhy
				   configuration, display this accordingly */
				if (wlan_phy.usageEnv == i)
					ifx_httpdWrite(wp, T("%s"), "selected");
				ifx_httpdWrite(wp, T(">%s"),
						   ifx_mapi_wlan_usage_env[i]);
			}
			ifx_httpdWrite(wp, T("</select>"));
			ifx_httpdWrite(wp, T("</td></tr>"));
		}
	} else if (!gstrcmp(name, T("AUTO_COC"))) {
		if (ltq_mapi_get_wlan_supported_features(wlan_phy.iid.cpeId.Id,
			IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_AUTOCOC) {
			/* Auto CoC */
			ifx_httpdWrite(wp, T("<div align='center'>\n"));
			ifx_httpdWrite(wp, T("<table class='tableInput' summary=''>\n"));
			ifx_httpdWrite(wp, T("<tr>"));
			ifx_httpdWrite(wp,
					   T("<td width=\"40%\">Auto CoC</td>\n"));
			ifx_httpdWrite(wp, T("<td width=\"60%\">\n"));

			ifx_httpdWrite(wp, T("<select name=\"wave_auto_coc_ena\" onChange=\"updatePageWlanAdvRadioSettings()\">\n"));
			for (i = 0; i <= 1; i++) {
				ifx_httpdWrite(wp, T("<option value='%d' "), i);
				if (wlan_phy.phyAutoCoC.autoCocEnable == i) {
					ifx_httpdWrite(wp, T("%s"), "selected");
				}
				ifx_httpdWrite(wp, T(">%s"), wlan_enable[i]);
			}
			ifx_httpdWrite(wp, T("</select>\n"));
			ifx_httpdWrite(wp, T("</td>\n</tr>\n"));
			ifx_httpdWrite(wp, T("</table>\n</div>\n"));

			ifx_httpdWrite(wp, T("<div id='wave_auto_coc' align='center'>\n"));
			ifx_httpdWrite(wp, T("<table class='tableInput' summary=''>\n"));
			/* Number of antennas */
			ifx_httpdWrite(wp, T("<tr>\n<td width='40%'>Number of Antennas</td>\n<td width='60%'>\n"
				"<select name=\"wave_num_antenna\">\n"));
			f_nAntennasFound = FALSE;
			for (i = 0; i < g_wlCaps[g_idx].numTxAntns; i++) {
				ifx_httpdWrite(wp, T("<option value='%d' "), i+1);
				if (wlan_phy.phyAutoCoC.nAntennas == i+1) {
					ifx_httpdWrite(wp, T("%s"), "selected");
					f_nAntennasFound = TRUE;
				}
				if ((i == g_wlCaps[g_idx].numTxAntns - 1) && (!f_nAntennasFound)) {
					ifx_httpdWrite(wp, T("%s"), "selected");
				}
				ifx_httpdWrite(wp, T(">%s"), ltq_mapi_wlan_nAntenna[i]);
			}
			ifx_httpdWrite(wp, T("</select>\n</td>\n</tr>\n</table>\n"));
			ifx_httpdWrite(wp, T("</div>\n"));


			ifx_httpdWrite(wp, T("<div id='wave_auto_coc_debug' align='center'>\n"));
			ifx_httpdWrite(wp, T("<table class='tableInput' summary=''>\n"));

			ifx_httpdWrite(wp, T("<tr>\n<td width='40%'>Auto CoC Timer Interval 1x1</td>\n"));
			ifx_httpdWrite(wp, T("<td width='60%'>\n<input name='auto_coc_timer_1x1' value=%d>"
				" in 100ms</td>\n</tr>\n"), wlan_phy.phyAutoCoC.timerIntval_1x1);

			ifx_httpdWrite(wp, T("<tr>\n<td>Auto CoC Timer Interval 2x2</td>\n"));
			ifx_httpdWrite(wp, T("<td>\n<input name='auto_coc_timer_2x2' value=%d>"
				" in 100ms</td>\n</tr>\n"), wlan_phy.phyAutoCoC.timerIntval_2x2);

			ifx_httpdWrite(wp, T("<tr>\n<td>Auto CoC Timer Interval 3x3</td>\n"));
			ifx_httpdWrite(wp, T("<td>\n<input name='auto_coc_timer_3x3' value=%d>"
				" in 100ms</td>\n</tr>\n"), wlan_phy.phyAutoCoC.timerIntval_3x3);

			ifx_httpdWrite(wp, T("<tr>\n<td width='40%'>Auto CoC 1x1 High Limit</td>\n"));
			ifx_httpdWrite(wp, T("<td width='60%'>\n<input name='auto_coc_high_lim_1x1' value=%d>"
				" in Mbit/s</td>\n</tr>\n"), wlan_phy.phyAutoCoC.highLim_1x1);

			ifx_httpdWrite(wp, T("<tr>\n<td width='40%'>Auto CoC 2x2 Low Limit</td>\n"));
			ifx_httpdWrite(wp, T("<td width='60%'>\n<input name='auto_coc_low_lim_2x2' value=%d>"
				" in Mbit/s</td>\n</tr>\n"), wlan_phy.phyAutoCoC.lowLim_2x2);

			ifx_httpdWrite(wp, T("<tr>\n<td width='40%'>Auto CoC 2x2 High Limit</td>\n"));
			ifx_httpdWrite(wp, T("<td width='60%'>\n<input name='auto_coc_high_lim_2x2' value=%d>"
				" in Mbit/s</td>\n</tr>\n"), wlan_phy.phyAutoCoC.highLim_2x2);

			ifx_httpdWrite(wp, T("<tr>\n<td width='40%'>Auto CoC 3x3 Low Limit</td>\n"));
			ifx_httpdWrite(wp, T("<td width='60%'>\n<input name='auto_coc_low_lim_3x3' value=%d>"
				" in Mbit/s</td>\n</tr>\n"), wlan_phy.phyAutoCoC.lowLim_3x3);

			ifx_httpdWrite(wp, T("</table>\n</div>\n"));
		} /* LTQ_WAVE_AUTO_COC */
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetBasicSettings", "ret: %d", ret);
	return ret;
}

/**
   This function gets information required to display the web page for "WLAN
   Radio Settings" properly. It is called from wlan_basic.asp.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int IFX_WLAN_Get80211nSettings(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 ret = IFX_SUCCESS, i = 0, idx = -1;
	char8 *name, *cpeId;
	bool mcsSelect = FALSE;
	IFX_MAPI_WLAN_Capability wlCaps;

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_Get80211nSettings", "");

	/* parse arguments passed from web page */
	if (ifx_httpd_parse_args(argc, argv, T("%s,%s"), &name, &cpeId) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	idx = atoi(cpeId) - 1;
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_Get80211nSettings", "idx: %d", idx);

	/* initialize all structures */
	memset(&wlCaps, 0xFF, sizeof(IFX_MAPI_WLAN_Capability));
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	if (idx == 0) {
		if (ifx_mapi_get_wlan_capability(&wlCaps, IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400, T("Failed to get the device capabilities\n\r"));
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	} else if (idx == 1) {
		if (ifx_mapi_get_wlan_sec_capability(&wlCaps, IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400, T("Failed to get the second device capabilities\n\r"));
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	} else {
		ifx_httpdError(wp, 400, T("Radio index out of range\n"));
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
#else
	if (idx == 0) {
		if (ifx_mapi_get_wlan_capability(&wlCaps, IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400, T("Failed to get the device capabilities\n\r"));
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	} else {
		ifx_httpdError(wp, 400, T("Radio index out of range\n"));
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
#endif
	if (!gstrcmp(name, T("BASIC"))) {
		/*
		 * depending on capability of device, different options are displayed
		*/
		ifx_httpdWrite(wp, T("<input type=hidden name=\"channelbandwidth%d\""
			" value=%d>"), idx+1, g_wlPhy[idx].phy11N.chanBW);
		if (wlCaps.wideChanSupport) {
			ifx_httpdWrite(wp, T("<tr>"));
			ifx_httpdWrite(wp, T("<td width=\"40%\">"));
			ifx_httpdWrite(wp, T("Channel Bandwidth"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("<td width=\"60%\">"));

			ifx_httpdWrite(wp, T("<select name=\"chan_width\" "
				"onChange=\"updateExtChan()\">"));
			for (i = 0; i <= 4; i++) {
				ifx_httpdWrite(wp, T("<option value='%d' "), i);
				if (g_wlPhy[idx].phy11N.chanBW == i) {
					ifx_httpdWrite(wp, T("%s"), "selected");
				}
				ifx_httpdWrite(wp, T(">%s"), wlan_channel_width[i]);
			}
			ifx_httpdWrite(wp, T("</select>"));

			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("</tr>"));
		} else {
			ifx_httpdWrite(wp, T("<tr>"));
			ifx_httpdWrite(wp, T("<td width=\"40%\">"));
			ifx_httpdWrite(wp, T("Channel Bandwidth"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("<td width=\"60%\">"));
			ifx_httpdWrite(wp,
				       T
				       ("<select name=\"chan_width\" disabled>"));
			ifx_httpdWrite(wp, T("<option value=\"0\" selected>%s"),
				       wlan_channel_width[0]);
			ifx_httpdWrite(wp, T("</select>"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("</tr>"));
		}

		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_Get80211nSettings",
			       "extChan: %d", g_wlPhy[idx].phy11N.extChPos);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=hidden name=\"extchann%d\" value=%d>"),
			       idx+1, g_wlPhy[idx].phy11N.extChPos);
		/* extension channel control */
		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td width=\"40%\">"));
		ifx_httpdWrite(wp, T("Extension Channel"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("<td width=\"60%\">"));
		ifx_httpdWrite(wp,
			       T
			       ("<select name=\"ext_chan\" onChange=\"validateExtChan()\">"));
		for (i = 0; i <= 1; i++) {
			ifx_httpdWrite(wp, T("<option value='%d' "), i);
			if (g_wlPhy[idx].phy11N.extChPos == i) {
				ifx_httpdWrite(wp, T("%s"), "selected");
			}
			ifx_httpdWrite(wp, T(">%s"), wlan_ext_chan[i]);
		}
		ifx_httpdWrite(wp, T("</select>"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("</tr>"));

		/* guard interval */
		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td width=\"40%\">"));
		ifx_httpdWrite(wp, T("Guard Interval"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("<td width=\"60%\">"));

		ifx_httpdWrite(wp, T("<select name=\"guard_intvl\">"));
		for (i = 0; i <= 2; i++) {
			ifx_httpdWrite(wp, T("<option value='%d' "), i);
			if (g_wlPhy[g_idx].phy11N.guardIntvl == i) {
				ifx_httpdWrite(wp, T("%s"), "selected");
			}
			ifx_httpdWrite(wp, T(">%s"), wlan_guard_intvl[i]);
		}
		ifx_httpdWrite(wp, T("</select>"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("</tr>"));

		/* MCS (not supported by WAVE300) */
		if (ltq_mapi_get_wlan_vendor(idx+1, IFX_F_DEFAULT) !=
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			ifx_httpdWrite(wp, T("<tr>"));
			ifx_httpdWrite(wp, T("<td width=\"40%\">"));
			ifx_httpdWrite(wp, T("MCS"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("<td width=\"60%\">"));

			ifx_httpdWrite(wp, T("<select name=\"mcs\">"));
			mcsSelect = FALSE;
			for (i = 0; i <= wlCaps.mcsRange; i++) {
				ifx_httpdWrite(wp, T("<option value='%d' "), i);
				if (g_wlPhy[g_idx].phy11N.mcs == i) {
					ifx_httpdWrite(wp, T("%s"), "selected");
					/* store info if selected option was found in variable */
					mcsSelect = TRUE;
				}
				ifx_httpdWrite(wp, T(">%s"), wlan_mcs[i]);
			}
			/* if not selected MCS was found select AUTO */
			if (mcsSelect == FALSE)
				ifx_httpdWrite(wp, T("<option value='%d' selected"),
						   -1);
			else
				ifx_httpdWrite(wp, T("<option value='%d'"), -1);

			ifx_httpdWrite(wp, T(">%s"), wlan_mcs[16]);
			ifx_httpdWrite(wp, T("</select>"));

			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("</tr>"));
		}
	} else if (!gstrcmp(name, T("ADVANCED"))) {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_Get80211nSettings",
			       "ADVANCED");
		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<th class=\"curveLeft\" colspan=\"2\">802.11n "
			"Settings</th>"));
		ifx_httpdWrite(wp, T("</tr>"));
		/*
		   store operational mode in hidden variable -> required for decision
		   to display 802.11N settings */
		ifx_httpdWrite(wp, T("<script type=\"text/javascript\">"
			"document.tF0.op_mode.value = %d;</script>"),
			g_wlPhy[g_idx].standard);
		/* window size for block acknowledgement (not supported by WAVE300) */
		if (ltq_mapi_get_wlan_vendor(idx+1, IFX_F_DEFAULT) !=
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			ifx_httpdWrite(wp, T("<tr>"));
			ifx_httpdWrite(wp, T("<td width=\"40%\">"));
			ifx_httpdWrite(wp, T("Block ACK window sizes"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("<td width=\"60%\">"));
			ifx_httpdWrite(wp, T("<input name=\"ba_size\" value="));

			ifx_httpdWrite(wp, T("%u"), g_wlPhy[g_idx].phy11N.baWinSize);

			ifx_httpdWrite(wp, T("> [1..64]"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("</tr>"));

			/* Aggregation MPDU */
			/* Enable Aggregation */
			ifx_httpdWrite(wp, T("<tr>"));
			ifx_httpdWrite(wp, T("<td width=\"40%\">"));
			ifx_httpdWrite(wp, T("A-MPDU Aggregation Enable"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("<td width=\"60%\">"));

			ifx_httpdWrite(wp,
					   T
					   ("<input type=CHECKBOX name=\"aggr_ampdu_enable\" value=1 onclick=\"updateAggrMpdu();\""));
			if (g_wlPhy[g_idx].phy11N.aggr.ampduEna)
				ifx_httpdWrite(wp, T(" checked>"));
			else
				ifx_httpdWrite(wp, T(">"));

			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("</tr>"));

			/* Select direction for aggregation */
			ifx_httpdWrite(wp, T("<tr>"));
			ifx_httpdWrite(wp, T("<td width=\"40%\">"));
			ifx_httpdWrite(wp, T("Select direction for MPDU aggregation"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("<td width=\"60%\">"));

			ifx_httpdWrite(wp, T("<select name=\"ampdu_direction\">"));
			for (i = 0; i <= 2; i++) {
				ifx_httpdWrite(wp, T("<option value='%d' "), i);
				if (g_wlPhy[g_idx].phy11N.aggr.ampduDir == i) {
					ifx_httpdWrite(wp, T("%s"), "selected");
				}
				ifx_httpdWrite(wp, T(">%s"), wlan_direction[i]);
			}
			ifx_httpdWrite(wp, T("</select>"));

			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("</tr>"));
		}

		/* Select size for aggregation */
		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td width=\"40%\">"));
		ifx_httpdWrite(wp, T("Length of MPDU aggregation"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("<td width=\"60%\">"));

		ifx_httpdWrite(wp, T("<select name=\"ampdu_length\">"));
		for (i = 0; i <= 3; i++) {
			ifx_httpdWrite(wp, T("<option value='%d' "), i);
			if (g_wlPhy[g_idx].phy11N.aggr.ampduLen == i)
				ifx_httpdWrite(wp, T("%s"), "selected");

			ifx_httpdWrite(wp, T(">%s"),
				       wlan_aggregation_ampdu_length[i]);
		}
		ifx_httpdWrite(wp, T("</select>"));

		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("</tr>"));
		/* display the selected length for A-MPDU on web page */
		switch (g_wlPhy[g_idx].phy11N.aggr.ampduLen) {
		case IFX_MAPI_WLAN_AMPDU_LEN1:
			ifx_httpdWrite(wp,
				       T
				       ("<script>document.tF0.ampdu_length[0].selected = true;</script>"));
			break;
		case IFX_MAPI_WLAN_AMPDU_LEN2:
			ifx_httpdWrite(wp,
				       T
				       ("<script>document.tF0.ampdu_length[1].selected = true;</script>"));
			break;
		case IFX_MAPI_WLAN_AMPDU_LEN3:
			ifx_httpdWrite(wp,
				       T
				       ("<script>document.tF0.ampdu_length[2].selected = true;</script>"));
			break;
		case IFX_MAPI_WLAN_AMPDU_LEN4:
			ifx_httpdWrite(wp,
				       T
				       ("<script>document.tF0.ampdu_length[3].selected = true;</script>"));
			break;
		}

		/* max. number of frames (not supported by WAVE300) */
		if (ltq_mapi_get_wlan_vendor(idx+1, IFX_F_DEFAULT) !=
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			ifx_httpdWrite(wp, T("<tr>"));
			ifx_httpdWrite(wp, T("<td width=\"40%\">"));
			ifx_httpdWrite(wp, T("Density of MPDU frames"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("<td width=\"60%\">"));
			ifx_httpdWrite(wp, T("<input name=\"ampdu_frame_density\" value="));

			ifx_httpdWrite(wp, T("%u"),
				g_wlPhy[g_idx].phy11N.aggr.ampduFrmsDensity);

			ifx_httpdWrite(wp, T("> in frames [1..64]"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("</tr>"));
		}

		if (g_wlPhy[idx].phy11N.aggr.ampduEna == IFX_MAPI_WLAN_DISABLED) {
			/* AMPDU direction (not supported by WAVE300) */
			if (ltq_mapi_get_wlan_vendor(idx+1, IFX_F_DEFAULT) !=
				LTQ_MAPI_WLAN_VENDOR_WAVE300) {
				ifx_httpdWrite(wp, T("<script>document.tF0.ampdu_direction.disabled "
					"= true;</script>"));
				ifx_httpdWrite(wp, T("<script>document.tF0.ampdu_frame_density.disabled "
					"= true;</script>"));
			}
			ifx_httpdWrite(wp, T("<script>document.tF0.ampdu_length.disabled "
				"= true;</script>"));
		}

		/* Aggregation MSDU */
		/* Enable Aggregation (not supported by WAVE300) */
		if (ltq_mapi_get_wlan_vendor(idx+1, IFX_F_DEFAULT) !=
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			ifx_httpdWrite(wp, T("<tr>"));
			ifx_httpdWrite(wp, T("<td width=\"40%\">"));
			ifx_httpdWrite(wp, T("A-MSDU Aggregation Enable"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("<td width=\"60%\">"));

			ifx_httpdWrite(wp, T("<input type=CHECKBOX name=\"aggr_amsdu_enable\" "
				"value=1 onclick=\"updateAggrMsdu();\""));
			if (g_wlPhy[g_idx].phy11N.aggr.amsduEna)
				ifx_httpdWrite(wp, T(" checked>"));
			else
				ifx_httpdWrite(wp, T(">"));

			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("</tr>"));

			/* Select direction for aggregation */
			ifx_httpdWrite(wp, T("<tr>"));
			ifx_httpdWrite(wp, T("<td width=\"40%\">"));
			ifx_httpdWrite(wp, T("Select direction for MSDU aggregation"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("<td width=\"60%\">"));

			ifx_httpdWrite(wp, T("<select name=\"amsdu_direction\">"));
			for (i = 0; i <= 2; i++) {
				ifx_httpdWrite(wp, T("<option value='%d' "), i);
				if (g_wlPhy[g_idx].phy11N.aggr.amsduDir == i) {
					ifx_httpdWrite(wp, T("%s"), "selected");
				}
				ifx_httpdWrite(wp, T(">%s"), wlan_direction[i]);
			}
			ifx_httpdWrite(wp, T("</select>"));

			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("</tr>"));

			/* Select size for aggregation */
			ifx_httpdWrite(wp, T("<tr>"));
			ifx_httpdWrite(wp, T("<td width=\"40%\">"));
			ifx_httpdWrite(wp, T("Length of MSDU aggregation"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("<td width=\"60%\">"));

			ifx_httpdWrite(wp, T("<select name=\"amsdu_length\">"));
			for (i = 0; i <= 1; i++) {
				ifx_httpdWrite(wp, T("<option value='%d' "), i);
				ifx_httpdWrite(wp, T(">%s"), wlan_aggregation_amsdu_length[i]);
			}
			ifx_httpdWrite(wp, T("</select>"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("</tr>"));

			/* display the selected length for A-MSDU on web page */
			switch (g_wlPhy[g_idx].phy11N.aggr.amsduLen) {
			case IFX_MAPI_WLAN_AMSDU_LEN1:
				ifx_httpdWrite(wp, T("<script>document.tF0.amsdu_length[0].selected "
					"= true;</script>"));
				break;
			case IFX_MAPI_WLAN_AMSDU_LEN2:
				ifx_httpdWrite(wp, T("<script>document.tF0.amsdu_length[1].selected "
					"= true;</script>"));
				break;
			}

			if (g_wlPhy[g_idx].phy11N.aggr.amsduEna ==
				IFX_MAPI_WLAN_DISABLED) {
				ifx_httpdWrite(wp, T("<script>document.tF0.amsdu_direction.disabled "
					"= true;</script>"));
				ifx_httpdWrite(wp, T("<script>document.tF0.amsdu_length.disabled "
					"= true;</script>"));
			}
		}

		/* Select direction for STBC */
		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td width=\"40%\">"));
		ifx_httpdWrite(wp, T("STBC"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("<td width=\"60%\">"));

		ifx_httpdWrite(wp, T("<select name=\"stbc_direction\">"));
		for (i = 0; i <= 1; i++) {
			ifx_httpdWrite(wp, T("<option value='%d' "), i);
			if (g_wlPhy[g_idx].phy11N.rxStbc == i) {
				ifx_httpdWrite(wp, T("%s"), "selected");
			}
			ifx_httpdWrite(wp, T(">%s"), stbc_enable[i]);
		}
		ifx_httpdWrite(wp, T("</select>"));

		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("</tr>"));

		/* Diversity */
		/* Enable Diversity (not supported by WAVE300) */
		if (ltq_mapi_get_wlan_vendor(idx+1, IFX_F_DEFAULT) !=
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			ifx_httpdWrite(wp, T("<tr>"));
			ifx_httpdWrite(wp, T("<td width=\"40%\">"));
			ifx_httpdWrite(wp, T("Diversity Enable"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("<td width=\"60%\">"));

			ifx_httpdWrite(wp, T("<input type=CHECKBOX name=\"diversity_enable\" "
				"value=1 onclick=\"updateDiversity();\""));
			if (g_wlPhy[g_idx].phy11N.diversity.diversityEna)
				ifx_httpdWrite(wp, T(" checked>"));
			else
				ifx_httpdWrite(wp, T(">"));

			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("</tr>"));

			/* Select direction for diversity */
			ifx_httpdWrite(wp, T("<tr>"));
			ifx_httpdWrite(wp, T("<td width=\"40%\">"));
			ifx_httpdWrite(wp, T("Select diversity direction"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("<td width=\"60%\">"));

			ifx_httpdWrite(wp, T("<select name=\"diversity_direction\">"));
			for (i = 0; i <= 2; i++) {
				ifx_httpdWrite(wp, T("<option value='%d' "), i);
				if (g_wlPhy[g_idx].phy11N.diversity.diversityDir == i) {
					ifx_httpdWrite(wp, T("%s"), "selected");
				}
				ifx_httpdWrite(wp, T(">%s"), wlan_direction[i]);
			}
			ifx_httpdWrite(wp, T("</select>"));

			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("</tr>"));

			/* number of antennas */
			ifx_httpdWrite(wp, T("<tr>"));
			ifx_httpdWrite(wp, T("<td width=\"40%\">"));
			ifx_httpdWrite(wp, T("Diversity - Number of antennas"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("<td width=\"60%\">"));
			ifx_httpdWrite(wp, T("<input name=\"num_antenna\" value="));

			ifx_httpdWrite(wp, T("%u"), g_wlPhy[g_idx].phy11N.diversity.antenna);

			ifx_httpdWrite(wp, T("> [1..3]"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("</tr>"));

			if (g_wlPhy[g_idx].phy11N.diversity.diversityEna == IFX_MAPI_WLAN_DISABLED) {
				ifx_httpdWrite(wp, T("<script>document.tF0.diversity_direction.disabled "
					"= true;</script>"));
				ifx_httpdWrite(wp, T("<script>document.tF0.num_antenna.disabled "
					"= true;</script>"));
			}
		}

		/* Only relevant for 2.4GHz */
		if (g_wlPhy[idx].freqBand == IFX_MAPI_WLAN_2_4_GHz_Freq) {
			ifx_httpdWrite(wp, T("<tr>"));
			ifx_httpdWrite(wp, T("<td width=\"40%\">"));
			ifx_httpdWrite(wp, T("40 MHz Intolerance"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("<td width=\"60%\">"));

			if (ltq_mapi_get_wlan_vendor(idx+1, IFX_F_DEFAULT) ==
				LTQ_MAPI_WLAN_VENDOR_WAVE300) {
				ifx_httpdWrite(wp, T("<select name=\"40M_intolerance\">"));
			} else {
				ifx_httpdWrite(wp, T("<select name=\"40M_intolerance\" disabled>"));
			}

			for (i = 0; i <= 1; i++) {
				ifx_httpdWrite(wp, T("<option value='%d' "), i);
				if (g_wlPhy[g_idx].phy11N.fourtyMHzIntolerant == i) {
					ifx_httpdWrite(wp, T("%s"), "selected");
				}
				ifx_httpdWrite(wp, T(">%s"), wlan_40M_intolerant[i]);
			}
			ifx_httpdWrite(wp, T("</select>"));

			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("</tr>"));

			ifx_httpdWrite(wp, T("</table>\n"));
			ifx_httpdWrite(wp, T("</div>\n"));
			ifx_httpdWrite(wp, T("<div id=\"20_40_coex_hidden_params\" align=\"center\">\n"));
			ifx_httpdWrite(wp, T("<table class=\"tableInput\" summary=\"\">\n"));

			/* Transition delay factor */
			ifx_httpdWrite(wp,T("<tr>\n<td width=\"40%\">Transition Delay Factor</td>\n"));
			ifx_httpdWrite(wp,T("<td width=\"60%\">"));
			ifx_httpdWrite(wp,
					   T("<input name=\"trans_delay\" value=%d> Range [1..100]"),
					   g_wlPhy[g_idx].phy11N.transDelayFactor);
			ifx_httpdWrite(wp, T("</td>\n</tr>\n"));

			/* OBSS Scan interval */
			ifx_httpdWrite(wp,T("<tr>\n<td width=\"40%\">OBSS Scan Interval</td>\n"));
			ifx_httpdWrite(wp,T("<td width=\"60%\">"));
			ifx_httpdWrite(wp,
					   T("<input name=\"obss_scan\" value=%d> sec [10..3600]"),
					   g_wlPhy[g_idx].phy11N.obssScan);
			ifx_httpdWrite(wp, T("</td>\n</tr>\n"));
		}
	} else if (!gstrcmp(name, T("COEX"))) {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_Get80211nSettings", "g_idx: %d", g_idx);
		/* 20/40 MHz coexistence */
		if ((g_idx == 0) && (g_2040CoexRadio1 == IFX_ENABLED)) {
			ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"twenty_fourty_coex_24\" value=\"1\">"));
		} else if ((g_idx == 1) && (g_2040CoexRadio2 == IFX_ENABLED)) {
			ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"twenty_fourty_coex_24\" value=\"1\">"));
		} else {
			ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"twenty_fourty_coex_24\" value=\"0\">"));
		}

		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td width=\"40%\">"));
		ifx_httpdWrite(wp, T("20/40 MHz Co-Existence Enable"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("<td width=\"60%\">"));
		ifx_httpdWrite(wp,
					T("<input type=checkbox name=\"twenty_fourty_coex\" value=1 "));
		if (g_wlPhy[g_idx].phy11N.twentyFourtyCoex)
			ifx_httpdWrite(wp, T("checked"));

		if (ltq_mapi_get_wlan_vendor(idx+1, IFX_F_DEFAULT) !=
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			ifx_httpdWrite(wp, T(" disabled>"));
		} else {
			ifx_httpdWrite(wp, T(">"));
		}
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("</tr>"));
	}

IFX_Handler:
	return ret;
}

/**
   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int ltq_get_wave_adv_settings(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 ret = IFX_SUCCESS, i = 0, idx = -1;
	char8 *cpeId;
	IFX_MAPI_WLAN_Capability wlCaps;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_wave_adv_settings", "");

	/* parse arguments passed from web page */
	if (ifx_httpd_parse_args(argc, argv, T("%s"), &cpeId) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return IFX_FAILURE;
	}

	/* determine index */
	idx = atoi(cpeId) - 1;
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	if (idx == 0) {
		if (ifx_mapi_get_wlan_capability(&wlCaps, IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400, T("Failed to get the device capabilities\n\r"));
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	} else if (idx == 1) {
		if (ifx_mapi_get_wlan_sec_capability(&wlCaps, IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400, T("Failed to get the second device capabilities\n\r"));
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	} else {
		ifx_httpdError(wp, 400, T("Radio index out of range\n"));
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
#else
	if (idx == 0) {
		if (ifx_mapi_get_wlan_capability(&wlCaps, IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400, T("Failed to get the device capabilities\n\r"));
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	} else {
		ifx_httpdError(wp, 400, T("Radio index out of range\n"));
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
#endif
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_wave_adv_settings", "idx: %d", idx);

	/* WAVE specific sections */
	if (ltq_mapi_get_wlan_vendor(idx+1, IFX_F_DEFAULT) ==
		LTQ_MAPI_WLAN_VENDOR_WAVE300) {
		ifx_httpdWrite(wp, T("<div id=\"wave_adv\" align=\"center\">\n"));
		ifx_httpdWrite(wp, T("<table class=\"tableInput\" summary=\"\">\n"));

		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<th class=\"curveLeft\" colspan=\"2\">"
			"WAVE Specific Settings</th>"));
		ifx_httpdWrite(wp, T("</tr>\n"));

		/* Advanced Low Densitiy Parity Check (LDPC) */
		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp,
				   T
				   ("<td width=\"40%\">Advanced Low Density Parity Check (LDPC)</td>\n"));
		ifx_httpdWrite(wp, T("<td width=\"60%\">\n"));

		ifx_httpdWrite(wp, T("<select name=\"wave_ldpc_ena\">\n"));
		for (i = 0; i <= 1; i++) {
			ifx_httpdWrite(wp, T("<option value='%d' "), i);
			if (g_wlPhy[g_idx].phy11N.ldpcEna == i) {
				ifx_httpdWrite(wp, T("%s"), "selected");
			}
			ifx_httpdWrite(wp, T(">%s"), wlan_enable[i]);
		}
		ifx_httpdWrite(wp, T("</select>\n"));
		ifx_httpdWrite(wp, T("</td>\n</tr>\n"));

		/* Beamforming */
		ifx_httpdWrite(wp, T("<tr>\n"));
		ifx_httpdWrite(wp, T("<td width=\"40%\">Beamforming</td>\n"));
		ifx_httpdWrite(wp, T("<td width=\"60%\">\n"));

		/*
		 * Beamforming cannot be used on radio-2 and is not available if
		 * less than three antennas are mounted (returned from capability script
		 */
		if (wlCaps.numTxAntns < 3) {
			ifx_httpdWrite(wp, T("<select name=\"wave_bf_ena\" disabled>\n"));
			ifx_httpdWrite(wp, T("<option value='0' selected"), i);
			ifx_httpdWrite(wp, T(">OFF\n"));
			ifx_httpdWrite(wp, T("</select>\n"));
			ifx_httpdWrite(wp, T("</td>\n</tr>\n"));
		}
		else {
			ifx_httpdWrite(wp, T("<select name=\"wave_bf_ena\">\n"));
			ifx_httpdWrite(wp, T("<option value='0' "), i);
			if (g_wlPhy[g_idx].beamForm == LTQ_MAPI_WLAN_BEAMFORM_OFF) {
				ifx_httpdWrite(wp, T("%s"), "selected");
			}
			ifx_httpdWrite(wp, T(">OFF\n"));
			ifx_httpdWrite(wp, T("<option value='3' "), i);
			if (g_wlPhy[g_idx].beamForm == LTQ_MAPI_WLAN_BEAMFORM_IMPLICIT) {
				ifx_httpdWrite(wp, T("%s"), "selected");
			}
			ifx_httpdWrite(wp, T(">Implicit BF\n"));
			ifx_httpdWrite(wp, T("</select>\n"));
			ifx_httpdWrite(wp, T("</td>\n</tr>\n"));
		}

		/* close table */
		ifx_httpdWrite(wp, T("</table>\n</div>\n"));

//		ifx_httpdWrite(wp, T("<br>\n"));

		/* WAVE specfic settings (shown only in debug mode) */
		ifx_httpdWrite(wp,
				   T("<div id=\"vb_debug_options\" align=\"center\">\n"));
		ifx_httpdWrite(wp, T("<table class=\"tableInput\" summary=\"\">\n"));

		/* Reliable Multicast */
		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp,
				   T
				   ("<td width=\"40%\">Multicast to Unicast Conversion (Reliable Multicast)</td>\n"));
		ifx_httpdWrite(wp, T("<td width=\"60%\">\n"));

		ifx_httpdWrite(wp, T("<select name=\"wave_mc2uc_ena\">\n"));
		for (i = 0; i <= 1; i++) {
			ifx_httpdWrite(wp, T("<option value='%d' "), i);
			if (g_wlPhy[g_idx].mc2ucEna == i) {
				ifx_httpdWrite(wp, T("%s"), "selected");
			}
			ifx_httpdWrite(wp, T(">%s"), wlan_enable[i]);
		}
		ifx_httpdWrite(wp, T("</select>\n"));
		ifx_httpdWrite(wp, T("</td>\n</tr>\n"));

		/* AckBoost selection */
		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp,
				   T("<td width=\"40%\">Select AckBoost Option</td>\n"));
		ifx_httpdWrite(wp, T("<td width=\"60%\">\n"));

		ifx_httpdWrite(wp, T("<select name=\"wave_ackBoost\">\n"));
		for (i = 0; i <= 4; i++) {
			ifx_httpdWrite(wp, T("<option value='%d' "), i);
			if (g_wlPhy[g_idx].boostMode == i) {
				ifx_httpdWrite(wp, T("%s"), "selected");
			}
			ifx_httpdWrite(wp, T(">%s"), wave_AckBoost[i]);
		}
		ifx_httpdWrite(wp, T("</select>\n"));
		ifx_httpdWrite(wp, T("</td>\n</tr>\n"));

		/* Logserver Enable */
		if (idx == 0) {
			ifx_httpdWrite(wp, T("<tr id=\"logserver\">"));
			ifx_httpdWrite(wp, T("<td width=\"40%\">Enable Logserver</td>\n"));
			ifx_httpdWrite(wp, T("<td width=\"60%\">\n"));

			ifx_httpdWrite(wp, T("<select name=\"wave_logserver_ena\">\n"));
			for (i = 0; i <= 1; i++) {
				ifx_httpdWrite(wp, T("<option value='%d'"), i);
				if (g_wlPhy[g_idx].wlVendorWaveCfg.logServerEna == i) {
					ifx_httpdWrite(wp, T("%s"), " selected");
				}
				ifx_httpdWrite(wp, T(">%s"), wlan_enable[i]);
			}
			ifx_httpdWrite(wp, T("</select>\n"));
			ifx_httpdWrite(wp, T("</td>\n</tr>\n"));
		}

		ifx_httpdWrite(wp, T("</table>\n</div>\n<br>\n"));
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_wave_adv_settings", "ret: %d", ret);
	return ret;
}

/**
   This function gets information required to display the web page for "Main
   AP/VAP Settings" properly. It is called from wlan_advsetup.asp.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int IFX_WLAN_GetApSettings(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 ret = IFX_SUCCESS;
	uint32 i = 0, nApVap = 0, nVapRadio1 = 0, nVapRadio2 = 0;
	IFX_MAPI_WLAN_MainCfg *wlMain = NULL;
	IFX_MAPI_WLAN_SecCfg *wlSec = NULL;
	IFX_MAPI_WLAN_Capability wlCaps;
	char8 quotedSsid[IFX_MAPI_WLAN_SSID_LEN+4];
	char8 *name;
	IFX_MAPI_WLAN_Standard networkMode = IFX_MAPI_WLAN_STD_802_11_ALL;

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetApSettings", "");

	/* parse arguments passed from web page */
	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	if ((ret = ifx_mapi_get_all_wlan_main_config (&nApVap, &wlMain,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get all wlan main config\n"));
		goto IFX_Handler;
	}
	if ((ret = ifx_mapi_get_all_wlan_security_config (&nApVap, &wlSec,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get all wlan security config\n"));
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetApSettings", "DEBUG: nApVAp: %d",
		nApVap);

	for (i = 0; i < nApVap; i++) {
		if (wlMain[i].radioCpeId == 1)
			nVapRadio1++;
		else if (wlMain[i].radioCpeId == 2)
			nVapRadio2++;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetApSettings",
		"nVapRadio1: %d, nVapRadio2: %d",
		nVapRadio1, nVapRadio2);

	if (!gstrcmp(name, T("RADIO-1"))) {
		if (ifx_mapi_get_wlan_capability(&wlCaps, IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400, T("Failed to get the device capabilities\n\r"));
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		if (wlCaps.maxVAPSupported <= nVapRadio1) {
			ifx_httpdWrite(wp, T("<script type=\"text/javascript\">"
				"document.getElementById('addVapButton').style.display  = 'none';</script>"));
		}
		for (i = 0; i < nApVap; i++) {
#ifndef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
			if (i == 1 && (wlMain[i].devType == IFX_MAPI_WLAN_DEV_TYPE_AP)) {
				IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetApSettings",
					"ERROR: On single radio platforms, there should be no second AP");
				/* Second AP in this case is second radio */ 
				continue;
			}
#endif	/* #ifndef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS */

			if (wlMain[i].radioCpeId == 1) {
				if (ifx_mapi_get_wlan_dyn_vap_info(&wlMain[i], IFX_F_DEFAULT) !=
					IFX_SUCCESS) {
					ifx_httpdError(wp, 400, T("Failed to get wlan dyn vap info\n"));
					goto IFX_Handler;
				}
				ifx_httpdWrite(wp,T("<input type=\"hidden\" name=\"cpeId%d\" value=\"%d\">"),
					i, i + 1);
				ifx_httpdWrite(wp, T("<tr>"));	/* opening a row */

				ifx_httpdWrite(wp, T("<td id=\"apname_%d\">%s</td>"),
					i, wlMain[i].apName);

				/* replace leading < with &lt; to avoid interpretation of < as html tag */
				if (wlMain[i].ssid[0] == '<') {
					memset(quotedSsid, 0x00, sizeof(quotedSsid));
					sprintf(quotedSsid, "%s", "&lt;");
					strcat(quotedSsid, &wlMain[i].ssid[1]);
					IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetApSettings", "quotedSsid: %s",
						quotedSsid);
					ifx_httpdWrite(wp, T("<td id=\"ssid_%d\">%s</td>"),
						i, quotedSsid);
				} else {
					ifx_httpdWrite(wp, T("<td id=\"ssid_%d\">%s</td>"),
						i, wlMain[i].ssid);
				}

				/* ap type */
				ifx_httpdWrite(wp, T("<td id=\"dev_type_%d\">"), i);
				switch (wlMain[i].devType) {
				case IFX_MAPI_WLAN_DEV_TYPE_AP:
					ifx_httpdWrite(wp, T("%s"), "AP");
					break;
				case IFX_MAPI_WLAN_DEV_TYPE_VAP:
					ifx_httpdWrite(wp, T("%s"), "VAP");
					break;
				case IFX_MAPI_WLAN_DEV_TYPE_STA:
					ifx_httpdWrite(wp, T("%s"), "Station");
					break;
				case IFX_MAPI_WLAN_DEV_TYPE_REP:
					ifx_httpdWrite(wp, T("%s"), "Repeater");
					break;
				case IFX_MAPI_WLAN_DEV_TYPE_BRIDGE:
					ifx_httpdWrite(wp, T("%s"), "Bridge");
					break;
				default:
					ifx_httpdError(wp, 400,
							   T("Illegal value for AP type\n"));
					goto IFX_Handler;
				}
				ifx_httpdWrite(wp, T("</td>"));

				/* security */
				ifx_httpdWrite(wp, T("<td id=\"beacon_type_%d\">"), i);
				switch (wlSec[i].beaconType) {
				case IFX_MAPI_WLAN_BEACON_BASIC:
					ifx_httpdWrite(wp, T("%s"), "Basic");
					break;
				case IFX_MAPI_WLAN_BEACON_WPA:
					ifx_httpdWrite(wp, T("%s"), "WPA");
					break;
				case IFX_MAPI_WLAN_BEACON_WPA2:
					ifx_httpdWrite(wp, T("%s"), "WPA2");
					break;
				case IFX_MAPI_WLAN_BEACON_WPA_WPA2:
				case IFX_MAPI_WLAN_BEACON_WPA_WPA2_NON_COMPLIANT:
					ifx_httpdWrite(wp, T("%s"), "WPA_WPA2 mixed mode");
					break;
#if defined (CONFIG_LTQ_AEI_CUST)
				case IFX_MAPI_WLAN_BEACON_NONE:
					ifx_httpdWrite(wp, T("%s"), "None");
					break;
#endif
				default:
					ifx_httpdError(wp, 400, T("Illegal value for security configuration\n"));
					goto IFX_Handler;
				}
				ifx_httpdWrite(wp, T("</td>"));

				/* encryption */
				ifx_httpdWrite(wp, T("<td id=\"encr_%d\">"), i);
				switch (wlSec[i].wlEncr) {
				case IFX_MAPI_WLAN_ENCR_NONE:
					ifx_httpdWrite(wp, T("%s"), "None");
					break;
				case IFX_MAPI_WLAN_ENCR_WEP:
					ifx_httpdWrite(wp, T("%s"), "WEP");
					break;
				case IFX_MAPI_WLAN_ENCR_TKIP:
					ifx_httpdWrite(wp, T("%s"), "TKIP");
					break;
				case IFX_MAPI_WLAN_ENCR_CCMP:
					ifx_httpdWrite(wp, T("%s"), "CCMP");
					break;
				case IFX_MAPI_WLAN_ENCR_TKIP_CCMP:
					ifx_httpdWrite(wp, T("%s"), "TKIP and CCMP");
					break;
				default:
					ifx_httpdError(wp, 400, T("Illegal value for encryption parameter\n"));
					goto IFX_Handler;
				}
				ifx_httpdWrite(wp, T("</td>"));

				/* authentication */
				ifx_httpdWrite(wp, T("<td id=\"auth_%d\">"), i);
				switch (wlSec[i].wlAuth) {
				case IFX_MAPI_WLAN_AUTH_OPEN:
					ifx_httpdWrite(wp, T("%s"), "Open");
					break;
				case IFX_MAPI_WLAN_AUTH_SHARED:
					ifx_httpdWrite(wp, T("%s"), "Shared");
					break;
				case IFX_MAPI_WLAN_AUTH_RADIUS:
					ifx_httpdWrite(wp, T("%s"), "Enterprise");
					break;
				case IFX_MAPI_WLAN_AUTH_PERSONAL:
					ifx_httpdWrite(wp, T("%s"), "Personal");
					break;
				default:
					ifx_httpdError(wp, 400,
						T("Illegal value for authentication parameter\n"));
					goto IFX_Handler;
				}
				ifx_httpdWrite(wp, T("</td>"));

				if (ltq_mapi_get_wlan_supported_features(wlMain[i].radioCpeId,
					IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_NETMODE_PER_VAP) {
					networkMode = wlMain[i].networkMode;
				} else {
					networkMode = g_wlPhy[wlMain[i].radioCpeId-1].standard;
				}
				/* net mode */
				IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetApSettings",
					"networkMode: %d", networkMode);
				ifx_httpdWrite(wp, T("<td id=\"netMode_%d\">"), i);
				switch (networkMode) {
					case IFX_MAPI_WLAN_STD_802_11BG:
						ifx_httpdWrite(wp, T("%s"), "802.11bg");
						break;
					case IFX_MAPI_WLAN_STD_802_11A:
						ifx_httpdWrite(wp, T("%s"), "802.11a");
						break;
					case IFX_MAPI_WLAN_STD_802_11B:
						ifx_httpdWrite(wp, T("%s"), "802.11b");
						break;
					case IFX_MAPI_WLAN_STD_802_11G:
						ifx_httpdWrite(wp, T("%s"), "802.11g");
						break;
					case IFX_MAPI_WLAN_STD_802_11N:
						ifx_httpdWrite(wp, T("%s"), "802.11n");
						break;
					case IFX_MAPI_WLAN_STD_802_11BGN:
						ifx_httpdWrite(wp, T("%s"), "802.11bgn");
						break;
					case IFX_MAPI_WLAN_STD_802_11GN:
						ifx_httpdWrite(wp, T("%s"), "802.11gn");
						break;
					case IFX_MAPI_WLAN_STD_802_11AN:
						ifx_httpdWrite(wp, T("%s"), "802.11an");
						break;
					case IFX_MAPI_WLAN_STD_802_11AC:
						ifx_httpdWrite(wp, T("%s"), "802.11ac");
						break;
					case IFX_MAPI_WLAN_STD_802_11ACN:
						ifx_httpdWrite(wp, T("%s"), "802.11acn");
						break;
					case IFX_MAPI_WLAN_STD_802_11ACNA:
						ifx_httpdWrite(wp, T("%s"), "802.11acna");
						break;
					default:
						ifx_httpdError(wp, 400, T("Illegal value for network mode parameter\n"));
						goto IFX_Handler;
				}
				ifx_httpdWrite(wp, T("</td>"));

				ifx_httpdWrite(wp, T("<td><input type='checkbox' name='apEna%d' "
					"value='1' %s disabled></td>"), (i + 1),
					(wlMain[i].apEnable == IFX_ENABLED) ? "checked" : "");

				ifx_httpdWrite(wp, T("<td><name='vapStatus%d'>%s</td>\n"), (i + 1),
					(wlMain[i].status == IFX_ENABLED) ? "UP" : "DOWN");
				ifx_httpdWrite(wp, T("<td>\n"));
				ifx_httpdWrite(wp, T("<a class=\"button\" href=\"#\" name=\"modAp%d\" "
					"value=\" Modify \" onClick=\"window.location='wlan_cfg.asp?Mod%d'\">Modify</a>\n"),
					i + 1, i + 1, i + 1);

				if (wlMain[i].devType == IFX_MAPI_WLAN_DEV_TYPE_VAP) {
					ifx_httpdWrite(wp, T("\t\t\t\t<a class=\"button\" href=\"#\" "
						"name=\"delAp%d\" value=\" Delete \" "
						"onClick=\"return deleteVAP(%d);\">Delete</a>\n"), i + 1, i + 1);
				}
				ifx_httpdWrite(wp, T("\t\t\t\t</td>\n"));

				ifx_httpdWrite(wp, T("</tr>"));	/* closing a row */
			}
		}
	}
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	else if (!gstrcmp(name, T("RADIO-2"))) {
		for (i = 0; i < nApVap; i++) {
			if (wlMain[i].radioCpeId == 2) {
				if (ifx_mapi_get_wlan_dyn_vap_info(&wlMain[i], IFX_F_DEFAULT) !=
					IFX_SUCCESS) {
					ifx_httpdError(wp, 400, T("Failed to get wlan dyn vap info\n"));
					goto IFX_Handler;
				}
				ifx_httpdWrite(wp,T("<input type='hidden' "
					"name='cpeId%d' value='%d'>\n"), i, i + 1);
				ifx_httpdWrite(wp, T("<tr>\n"));	/* opening a row */
				ifx_httpdWrite(wp, T("<td id='apname_%d'>%s</td>"),
					i, wlMain[i].apName);

#if 1
//				ifx_httpdWrite(wp, T("}\n</script>\n"));
				/* replace leading < with &lt; to avoid interpretation of < as html tag */
				if (wlMain[i].ssid[0] == '<') {
					memset(quotedSsid, 0x00, sizeof(quotedSsid));
					sprintf(quotedSsid, "%s", "&lt;");
					strcat(quotedSsid, &wlMain[i].ssid[1]);
					IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetApSettings", "quotedSsid: %s",
						quotedSsid);
					ifx_httpdWrite(wp, T("<td id=\"ssid_%d\">%s</td>"),
						i, quotedSsid);
				} else {
					ifx_httpdWrite(wp, T("<td id=\"ssid_%d\">%s</td>"),
						i, wlMain[i].ssid);
				}
//				ifx_httpdWrite(wp, T("<script>\nif(\"CONCURRENT_DUAL_WIRELESS\" == \"CONCURRENT_DUAL_WIRELESS\") {\n"));
#else
				/* replace leading < with &lt; to avoid interpretation of < as html tag */
				if (wlMain[i].ssid[0] == '<') {
					memset(quotedSsid, 0x00, sizeof(quotedSsid));
					sprintf(quotedSsid, "%s", "&lt;");
					strcat(quotedSsid, &wlMain[i].ssid[1]);
					IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetApSettings", "quotedSsid: %s",
						quotedSsid);
					ifx_httpdWrite(wp, T("document.write(\"<td id=\\\"ssid_%d\\\">%s</td>\");"),
						i, quotedSsid);
				} else {
					ifx_httpdWrite(wp, T("document.write(\"<td id=\\\"ssid_%d\\\">%s</td>\");"),
						i, wlMain[i].ssid);
				}
#endif

				/* ap type */
				ifx_httpdWrite(wp, T("<td id='dev_type_%d'>"), i);
				switch (wlMain[i].devType) {
				case IFX_MAPI_WLAN_DEV_TYPE_AP:
					ifx_httpdWrite(wp, T("%s"), "AP");
					break;
				case IFX_MAPI_WLAN_DEV_TYPE_VAP:
					ifx_httpdWrite(wp, T("%s"), "VAP");
					break;
				case IFX_MAPI_WLAN_DEV_TYPE_STA:
					ifx_httpdWrite(wp, T("%s"), "Station");
					break;
				case IFX_MAPI_WLAN_DEV_TYPE_REP:
					ifx_httpdWrite(wp, T("%s"), "Repeater");
					break;
				case IFX_MAPI_WLAN_DEV_TYPE_BRIDGE:
					ifx_httpdWrite(wp, T("%s"), "Bridge");
					break;
				default:
					ifx_httpdError(wp, 400, T("Illegal value for AP type\n"));
					goto IFX_Handler;
				}
				ifx_httpdWrite(wp, T("</td>\n"));

				/* security */
				ifx_httpdWrite(wp, T("<td id='beacon_type_%d'>"), i);
				switch (wlSec[i].beaconType) {
				case IFX_MAPI_WLAN_BEACON_BASIC:
					ifx_httpdWrite(wp, T("%s"), "Basic");
					break;
				case IFX_MAPI_WLAN_BEACON_WPA:
					ifx_httpdWrite(wp, T("%s"), "WPA");
					break;
				case IFX_MAPI_WLAN_BEACON_WPA2:
					ifx_httpdWrite(wp, T("%s"), "WPA2");
					break;
				case IFX_MAPI_WLAN_BEACON_WPA_WPA2:
				case IFX_MAPI_WLAN_BEACON_WPA_WPA2_NON_COMPLIANT:
					ifx_httpdWrite(wp, T("%s"), "WPA_WPA2 mixed mode");
					break;
#if defined (CONFIG_LTQ_AEI_CUST)
				case IFX_MAPI_WLAN_BEACON_NONE:
					ifx_httpdWrite(wp, T("%s"), "None");
					break;
#endif
				default:
					ifx_httpdError(wp, 400, T("Illegal value for security configuration\n"));
					goto IFX_Handler;
				}
				ifx_httpdWrite(wp, T("</td>\n"));

				/* encryption */
				ifx_httpdWrite(wp, T("<td id='encr_%d'>"), i);
				switch (wlSec[i].wlEncr) {
				case IFX_MAPI_WLAN_ENCR_NONE:
					ifx_httpdWrite(wp, T("%s"), "None");
					break;
				case IFX_MAPI_WLAN_ENCR_WEP:
					ifx_httpdWrite(wp, T("%s"), "WEP");
					break;
				case IFX_MAPI_WLAN_ENCR_TKIP:
					ifx_httpdWrite(wp, T("%s"), "TKIP");
					break;
				case IFX_MAPI_WLAN_ENCR_CCMP:
					ifx_httpdWrite(wp, T("%s"), "CCMP");
					break;
				case IFX_MAPI_WLAN_ENCR_TKIP_CCMP:
					ifx_httpdWrite(wp, T("%s"), "TKIP and CCMP");
					break;
				default:
					ifx_httpdError(wp, 400, T("Illegal value for encryption parameter\n"));
					goto IFX_Handler;
				}
				ifx_httpdWrite(wp, T("</td>\n"));

				/* authentication */
				ifx_httpdWrite(wp, T("<td id='auth_%d'>"), i);
				switch (wlSec[i].wlAuth) {
				case IFX_MAPI_WLAN_AUTH_OPEN:
					ifx_httpdWrite(wp, T("%s"), "Open");
					break;
				case IFX_MAPI_WLAN_AUTH_SHARED:
					ifx_httpdWrite(wp, T("%s"), "Shared");
					break;
				case IFX_MAPI_WLAN_AUTH_RADIUS:
					ifx_httpdWrite(wp, T("%s"), "Enterprise");
					break;
				case IFX_MAPI_WLAN_AUTH_PERSONAL:
					ifx_httpdWrite(wp, T("%s"), "Personal");
					break;
				default:
					ifx_httpdError(wp, 400, T("Illegal value for authentication parameter\n"));
					goto IFX_Handler;
				}
				ifx_httpdWrite(wp, T("</td>\n"));

				if (ltq_mapi_get_wlan_supported_features(wlMain[i].radioCpeId,
					IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_NETMODE_PER_VAP) {
					networkMode = wlMain[i].networkMode;
				} else {
					networkMode = g_wlPhy[wlMain[i].radioCpeId - 1].standard;
				} /* LTQ_WAVE_NETWORK_MODE_PER_VAP */
				/* net mode */
				IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetApSettings",
					"networkMode: %d", networkMode);
				ifx_httpdWrite(wp, T("<td id='netMode_%d'>"), i);
				switch (networkMode) {
					case IFX_MAPI_WLAN_STD_802_11BG:
						ifx_httpdWrite(wp, T("%s"), "802.11bg");
						break;
					case IFX_MAPI_WLAN_STD_802_11A:
						ifx_httpdWrite(wp, T("%s"), "802.11a");
						break;
					case IFX_MAPI_WLAN_STD_802_11B:
						ifx_httpdWrite(wp, T("%s"), "802.11b");
						break;
					case IFX_MAPI_WLAN_STD_802_11G:
						ifx_httpdWrite(wp, T("%s"), "802.11g");
						break;
					case IFX_MAPI_WLAN_STD_802_11N:
						ifx_httpdWrite(wp, T("%s"), "802.11n");
						break;
					case IFX_MAPI_WLAN_STD_802_11BGN:
						ifx_httpdWrite(wp, T("%s"), "802.11bgn");
						break;
					case IFX_MAPI_WLAN_STD_802_11GN:
						ifx_httpdWrite(wp, T("%s"), "802.11gn");
						break;
					case IFX_MAPI_WLAN_STD_802_11AN:
						ifx_httpdWrite(wp, T("%s"), "802.11an");
						break;
					case IFX_MAPI_WLAN_STD_802_11AC:
						ifx_httpdWrite(wp, T("%s"), "802.11ac");
						break;
					case IFX_MAPI_WLAN_STD_802_11ACN:
						ifx_httpdWrite(wp, T("%s"), "802.11acn");
						break;
					case IFX_MAPI_WLAN_STD_802_11ACNA:
						ifx_httpdWrite(wp, T("%s"), "802.11acna");
						break;
					default:
						ifx_httpdError(wp, 400, T("Illegal value for network mode parameter\n"));
						goto IFX_Handler;
				}
				ifx_httpdWrite(wp, T("</td>\n"));

				ifx_httpdWrite(wp, T("<td><input type='checkbox' name='apEna%d' "
					"value='1' %s disabled></td>\n"), (i + 1),
					(wlMain[i].apEnable == IFX_ENABLED) ? "checked" : "");

				ifx_httpdWrite(wp,
					T("<td><name='vapStatus%d'>%s</td>\n"),
					(i + 1), (wlMain[i].status == IFX_ENABLED) ? "UP" : "DOWN");
				ifx_httpdWrite(wp, T("<td>\n"));
				ifx_httpdWrite(wp, T("<a class='button' "
					"href='#' name='modAp%d' value=' Modify ' "
					"onClick=\"window.location='wlan_cfg.asp?Mod%d'\">"
					"Modify</a>\n"), i + 1, i + 1, i + 1);

				if (wlMain[i].devType == IFX_MAPI_WLAN_DEV_TYPE_VAP) {
					ifx_httpdWrite(wp, T("<a class='button' "
						"href='#' name='delAp%d' value=' Delete ' "
						"onClick=\"return deleteVAP(%d);\">Delete</a>\n"),
						i + 1, i + 1);
				}
				ifx_httpdWrite(wp, T("</td>\n"));
				ifx_httpdWrite(wp, T("</tr>\n"));	/* closing a row */
			}
		}
		ifx_httpdWrite(wp, T("</table>\n</div>\n"));	/* closing a row */

		if (ifx_mapi_get_wlan_sec_capability(&wlCaps, IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400, T("Failed to get the device capabilities\n\r"));
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		if (wlCaps.maxVAPSupported <= nVapRadio2) {
			ifx_httpdWrite(wp, T("<script>\ndocument.getElementById"
				"('addVapButton2').style.display = 'none';\n</script>"));
		}
		/* Is Radio-2 card present? */
		if (ltq_mapi_get_wlan_vendor(2, IFX_F_DEFAULT) ==
			LTQ_MAPI_WLAN_VENDOR_NONE) {
			ifx_httpdWrite(wp, T("<script>\ndocument.getElementById"
				"('radio-2').style.display = 'none';\n</script>\n"));
		}
		/* fake open table */
		ifx_httpdWrite(wp, T("<div align='center'>\n"));
		ifx_httpdWrite(wp, T("<table class='tableInfo' cellspacing='1' cellpadding='6' summary=''>\n"));
	}
#else
	ifx_httpdWrite(wp, T("</table>\n</div>\n"));	/* closing a row */

	ifx_httpdWrite(wp, T("<script>\ndocument.getElementById"
		"('radio-2').style.display = 'none';\n</script>\n"));

	/* fake open table */
	ifx_httpdWrite(wp, T("<div align='center'>\n"));
	ifx_httpdWrite(wp, T("<table class='tableInfo' cellspacing='1' cellpadding='6' summary=''>\n"));
#endif				/* #ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS */

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetApSettings", "ret: %d", ret);
	IFX_MEM_FREE(wlMain);
	IFX_MEM_FREE(wlSec);
	return ret;
}

int IFX_WLAN_GetApValues(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 ret = IFX_SUCCESS, flags = IFX_F_DEFAULT;
	IFX_MAPI_WLAN_MainCfg wlMain;
	IFX_MAPI_WLAN_SecCfg wlSec;
	IFX_MAPI_WLAN_PhyCfg wlPhy;
	char *name;
	char8 sCommand[MAX_DATA_LEN];

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetApValues", "");

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	if (!gstrcmp(name, "GET_VALUES")) {
		memset(&wlMain, 0, sizeof(IFX_MAPI_WLAN_MainCfg));
		sprintf(wlMain.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
		sprintf(wlMain.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

		wlMain.iid.pcpeId.Id = 1;
		wlMain.iid.cpeId.Id = 1;
		wlMain.iid.config_owner = IFX_WEB;

		memset(&wlSec, 0, sizeof(IFX_MAPI_WLAN_SecCfg));
		sprintf(wlSec.iid.cpeId.secName, "%s", TAG_WLAN_SEC);
		sprintf(wlSec.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
		wlSec.iid.config_owner = IFX_WEB;

		wlSec.iid.pcpeId.Id = 1;
		wlSec.iid.cpeId.Id = 1;

		memset(&wlPhy, 0, sizeof(IFX_MAPI_WLAN_PhyCfg));
		sprintf(wlPhy.iid.cpeId.secName, "%s", TAG_WLAN_PHY);
		sprintf(wlPhy.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
		wlPhy.iid.config_owner = IFX_WEB;

		if ((ret =
		     ifx_mapi_get_wlan_main_config(&wlMain,
						   flags)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       T("Failed to get main config\n"));
			goto IFX_Handler;
		}

		if ((ret =
		     ifx_mapi_get_wlan_security_config(&wlSec,
						       flags)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       T
				       ("Failed to get the security configuration\n\r"));
			goto IFX_Handler;
		}

		wlPhy.iid.cpeId.Id = wlMain.radioCpeId;
		if ((ret =
			ifx_mapi_get_wlan_static_phy_config(&wlPhy,
						  flags)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to get wlan phy config");
			goto IFX_Handler;
		}

		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp,
			       T("<td width=\"40%\">WLAN Radio Enable</td>"));
		if (wlPhy.radioEnable)
			ifx_httpdWrite(wp,
				       T
				       ("<td width=\"60%\"><input type=checkbox size=\"1\" name=\"WLANEnable\" value=1 checked></td>"));
		else
			ifx_httpdWrite(wp,
				       T
				       ("<td width=\"60%\"><input type=checkbox size=\"1\" name=\"WLANEnable\" value=1 ></td></td>"));
		ifx_httpdWrite(wp, T("</tr>"));

		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td width=\"40%\">SSID</td>"));
		ifx_httpdWrite(wp,
			       T
			       ("<td width=\"60%\"><input type=\"text\" name=\"vcSetting\" maxlength=\"15\" size=\"12\" "));
		gsprintf(sCommand, "value=\"%s\"></td>", wlMain.ssid);
		ifx_httpdWrite(wp, T(sCommand));
		ifx_httpdWrite(wp, T("</tr>"));

		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td width=\"40%\">Security Type</td>"));
		ifx_httpdWrite(wp,
			       T
			       ("<td width=\"60%\"><select name=\"WT\" size=\"1\" onChange='start(this)'>"));

		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetApValues",
			       "wlSec.beaconType:%d", wlSec.beaconType);
		switch (wlSec.beaconType) {
#if defined (CONFIG_LTQ_AEI_CUST)
		case IFX_MAPI_WLAN_BEACON_NONE:
#endif
		case IFX_MAPI_WLAN_BEACON_BASIC:
			if (wlSec.basicEncr == IFX_MAPI_WLAN_ENCR_NONE)
				sprintf(sCommand,
					"<option value=\"1\" selected>None <option value=\"4\">WPA2 <option value=\"5\">WPA_WPA2_Mixed</option>");
			else
				sprintf(sCommand,
					"<option value=\"1\">None <option value=\"2\" selected>WEP <option value=\"3\">WPA <option value=\"4\">WPA2 <option value=\"5\">WPA_WPA2_Mixed</option>");
			break;
		case IFX_MAPI_WLAN_BEACON_WPA:
			sprintf(sCommand,
				"<option value=\"1\">None <option value=\"3\" selected>WPA <option value=\"4\">WPA2 <option value=\"5\">WPA_WPA2_Mixed</option>");
			break;
		case IFX_MAPI_WLAN_BEACON_WPA2:
			sprintf(sCommand,
				"<option value=\"1\">None <option value=\"4\" selected>WPA2 <option value=\"5\">WPA_WPA2_Mixed</option>");
			break;
		case IFX_MAPI_WLAN_BEACON_WPA_WPA2:
		case IFX_MAPI_WLAN_BEACON_WPA_WPA2_NON_COMPLIANT:
			sprintf(sCommand,
				"<option value=\"1\">None <option value=\"3\">WPA <option value=\"4\">WPA2 <option value=\"5\" selected>WPA_WPA2_Mixed</option>");
			break;
		default:
			sprintf(sCommand,
				"<option value=\"1\">None <option value=\"3\">WPA <option value=\"4\">WPA2 <option value=\"5\" selected>WPA_WPA2_Mixed</option>");
			break;
		}
		ifx_httpdWrite(wp, T(sCommand));
		ifx_httpdWrite(wp, T("</select>"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp, T("</tr>"));

	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetApValues", "ret: %d", ret);
	return ret;

}

/**
   This function gets information required to display the web page for "Advanced
   Settings" properly. It is called from wlan_advsetup.asp.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int LTQ_WLAN_GetMainConfiguration(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 ret = IFX_SUCCESS, apIndex = 0xFF, radioIdx = 0;
	uint32 j = 0, numEntries = 0, i = 0;
	char8 *name = NULL, quotedSsid[2*IFX_MAPI_WLAN_SSID_LEN];
	IFX_MAPI_WLAN_MainCfg *wlMain = NULL;
	IFX_MAPI_WLAN_SecCfg *wlSec = NULL;
	IFX_MAPI_WLAN_Capability wlCaps;
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	IFX_MAPI_WLAN_Capability wlCapsSec;
	uint8 maxClientsPerVapRadio2 = 0;
#endif
	uint8 nReservedClientsRadio1 = 0, nReservedClientsRadio2 = 0;
	uint8 maxClientsPerVapRadio1 = 0;

	IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_GetMainConfiguration", "");
	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	}

	/*
		we pass flag IFX_F_RESET_WEB_CFG to indicate to MAPI that main
		config has been read from web
	*/
	if (ifx_mapi_get_all_wlan_main_config((uint32 *) &numEntries, &wlMain,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get all wlan main config\n"));
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_GetMainConfiguration",
		"numEntries: %d", numEntries);
	/*
		we pass flag IFX_F_RESET_WEB_CFG to indicate to MAPI that main
		config has been read from web
	*/
	if (ifx_mapi_get_all_wlan_security_config((uint32 *) &numEntries, &wlSec,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get all wlan sec config\n"));
		goto LTQ_Handler;
	}

	/* additional validation required */
	if ((!wlMain) || (!wlSec)) {
		ifx_httpdError(wp, 400, T("Failed to get configuration\n\r"));
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	}

	/*
	 * determine the supported capabilites
	*/
	if (ifx_mapi_get_wlan_capability(&wlCaps, IFX_F_DEFAULT) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get the device capabilities\n\r"));
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	}
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	if (ifx_mapi_get_wlan_sec_capability(&wlCapsSec, IFX_F_DEFAULT) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get the second device capabilities\n\r"));
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	}
#endif

	/* determine reserved clients and max clients per VAP */
	for (i=0; i < numEntries; i++) {
		if (wlMain[i].radioCpeId == 1) {
			nReservedClientsRadio1 += wlMain[i].minResSta;
		} else {
			nReservedClientsRadio2 += wlMain[i].minResSta;
		}
	}
	maxClientsPerVapRadio1 = wlCaps.maxClientsPerVAP - nReservedClientsRadio1;
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	maxClientsPerVapRadio2 = wlCapsSec.maxClientsPerVAP - nReservedClientsRadio2;
	IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_GetMainConfiguration",
		"maxClientsPerVapRadio1: %d, maxClientsPerVapRadio2: %d",
		maxClientsPerVapRadio1, maxClientsPerVapRadio2);

#endif
	if (!gstrcmp(name, T("VAP_COUNT"))) {
		ifx_httpdWrite(wp, T("document.write(\"<input type='hidden' "
			"name='net_class' value=%d>\");\n"), g_wlPhy[0].netModeClass);
		ifx_httpdWrite(wp, T("document.write(\"<input type='hidden' "
			"name='num_existing_ap' value=%d>\");\n"), numEntries);
		ifx_httpdWrite(wp, T("document.write(\"<input type='hidden' "
			"name='num_supported_vap' value=%d>\");\n"),
			wlCaps.maxVAPSupported);
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
		ifx_httpdWrite(wp, T("document.write(\"<input type='hidden' "
			"name='net_class_0' value=%d>\");\n"), g_wlPhy[0].netModeClass);
		ifx_httpdWrite(wp, T("document.write(\"<input type='hidden' "
			"name='net_class_1' value=%d>\");\n"), g_wlPhy[1].netModeClass);
		ifx_httpdWrite(wp, T("document.write(\"<input type='hidden' "
			"name='num_existing_vap_radio1' value=%d>\");\n"), gNumVapRadio1);
		ifx_httpdWrite(wp, T("document.write(\"<input type='hidden' "
			"name='num_existing_vap_radio2' value=%d>\");\n"), gNumVapRadio2);
		ifx_httpdWrite(wp, T("document.write(\"<input type='hidden' "
			"name='num_supported_vap_radio2' value=%d>\");\n"),
			wlCapsSec.maxVAPSupported);
#endif /* #ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS */
		ifx_httpdWrite(wp,
			T("document.write(\"<input type='hidden' name='wpsEna' value=0>\");\n"));

		for (i = 0; i < numEntries; i++) {
			IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_GetMainConfiguration",
				       "ap_name_%d: %s", i, wlMain[i].apName);
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<input type='hidden' name='ap_name_%d' value='%s'>\");\n"),
				       i, wlMain[i].apName);
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<input type='hidden' name='apEna_%d' value=%d>\");\n"),
				       i, wlMain[i].apEnable);
		}
		goto LTQ_Handler;
	} else if (!gstrcmp(name, T("CLIENT_LIMIT"))) {
		ifx_httpdWrite(wp, T("document.write(\"<tr>\");\n"));
		ifx_httpdWrite(wp, T("document.write(\"<td>Maximum Client Limit</td>\");\n"));
		ifx_httpdWrite(wp, T("document.write(\"<td>\");\n"));
		ifx_httpdWrite(wp, T("document.write(\"<input name=\\\"max_client_limit\\\" "
			"size=\\\"20\\\" value=\\\"%d\\\">\");\n"), maxClientsPerVapRadio1);
		ifx_httpdWrite(wp, T("document.write(\"</td>\");\n"));
		ifx_httpdWrite(wp, T("document.write(\"</tr>\");\n"));

		ifx_httpdWrite(wp, T("document.write(\"<tr>\");\n"));
		ifx_httpdWrite(wp, T("document.write(\"<td>Number of reserved clients</td>\");\n"));
		ifx_httpdWrite(wp, T("document.write(\"<td>\");\n"));
		ifx_httpdWrite(wp, T("document.write(\"<input name=\\\"min_reserved_clients\\\" "
			"size=\\\"20\\\" value=\\\"0\\\">\");\n"));
		ifx_httpdWrite(wp, T("document.write(\"</td>\");\n"));
		ifx_httpdWrite(wp, T("document.write(\"</tr>\");\n"));
	}
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	else if (!gstrcmp(name, T("UPDATE_CLIENT_LIMIT"))) {
		ifx_httpdWrite(wp, T("if (Number(document.tF0.radio.value) == 1) {\n"));
		ifx_httpdWrite(wp, T("document.tF0.max_client_limit.value = %d;\n"), maxClientsPerVapRadio1);
		ifx_httpdWrite(wp, T("} else if (Number(document.tF0.radio.value) == 2) {\n"));
		ifx_httpdWrite(wp, T("document.tF0.max_client_limit.value = %d;\n}\n"), maxClientsPerVapRadio2);
	}
#endif /* #ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS */
	else if (!gstrcmp(name, T("MOD"))) {
		for (i = 0; i < numEntries; i++) {
			ifx_httpdWrite(wp, T("case \"?Mod%d\":\n"), i + 1);
			ifx_httpdWrite(wp, T("document.tF0.ap_index.value=\"%d\";\n"), i);
			apIndex = i;

			if (ltq_mapi_get_wlan_supported_features(wlMain[i].radioCpeId,
				IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_NETMODE_PER_VAP) {
				ifx_httpdWrite(wp,
					T("document.write(\"<input type='hidden' name='secType' "
					"value=%d>\");\n"), wlSec[apIndex].wlEncr);
			}

			ifx_httpdWrite(wp, T("document.write(\"<input type='hidden' "
				"name='num_existing_ap' value=%d>\");\n"), numEntries);
			ifx_httpdWrite(wp,
				T("document.write(\"<input type='hidden' name='wpsEna' "
				"value=%d>\");\n"), wlMain[apIndex].WPSena);
			ifx_httpdWrite(wp, T("document.tF0.radioCpeId.value=\"%d\";\n"),
				wlMain[apIndex].radioCpeId);
			if (ltq_mapi_get_wlan_vendor(wlMain[apIndex].radioCpeId, IFX_F_DEFAULT) ==
				LTQ_MAPI_WLAN_VENDOR_WAVE300) {
				ifx_httpdWrite(wp,
					T("document.tF0.minResClientsOnLoad.value=\"%d\";\n"),
					wlMain[apIndex].minResSta);
			}
			for (j = 0; j < numEntries; j++) {
				IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_GetMainConfiguration",
					"ap_name_%d: %s", j, wlMain[j].apName);
				ifx_httpdWrite(wp, T("document.write(\"<input type='hidden' "
					"name='ap_name_%d' value='%s'>\");\n"), j, wlMain[j].apName);

				IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_GetMainConfiguration",
					"apEna_%d: %d", j, wlMain[j].apEnable);
				ifx_httpdWrite(wp, T("document.write(\"<input type='hidden' "
					"name='apEna_%d' value=%d>\");\n"), j, wlMain[j].apEnable);
			}

			radioIdx = wlMain[apIndex].radioCpeId - 1;
			if ((radioIdx < 0) || (radioIdx > 1)) {
				IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_GetMainConfiguration", "");
				ret = IFX_FAILURE;
				goto LTQ_Handler;
			}

			if (ltq_mapi_get_wlan_supported_features(wlMain[i].radioCpeId,
				IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_NETMODE_PER_VAP) {
				ifx_httpdWrite(wp, T("document.write(\"<input type='hidden' "
					"name='net_class' value=%d>\");\n"), g_wlPhy[radioIdx].netModeClass);
			}

			/* AP Enable */
			ifx_httpdWrite(wp, T("document.write(\"<tr>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"<td width='20%' "
				"height='30'><font class='subtitle'>Enable AP/VAP</font></td>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"<td width='50%' "
				"height='30'>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"<font class='subtitle'>\");\n"));

//			if (ltq_mapi_get_wlan_vendor(wlMain[apIndex].radioCpeId, IFX_F_DEFAULT) ==
//				LTQ_MAPI_WLAN_VENDOR_WAVE300) {
				if (wlMain[apIndex].devType == IFX_MAPI_WLAN_DEV_TYPE_AP) {
				ifx_httpdWrite(wp, T("document.write(\"<input type='checkbox' "
					"name='apEna' value='1' onclick='updateVAP();' %s disabled>\");\n"),
					(wlMain[apIndex].apEnable == IFX_ENABLED) ? "checked" : "");
				}
				else {
					ifx_httpdWrite(wp, T("\t\tdocument.write(\"<input type='checkbox' "
						"name='apEna' value='1' %s>\");\n"),
						(wlMain[apIndex].apEnable == IFX_ENABLED) ? "checked" : "");
				}
//			} else {
//				ifx_httpdWrite(wp, T("document.write(\"<input type='checkbox' "
//					"name='apEna' value='1' onclick='updateVAP();' "
//					"checked disabled>\");\n"));
//			}

			ifx_httpdWrite(wp,
				       T
				       ("\t\tdocument.write(\"</font></td>\");\n"));
			ifx_httpdWrite(wp,
				       T("\t\tdocument.write(\"</tr>\");\n"));

			/* SSID */
			ifx_httpdWrite(wp,
				       T("\t\tdocument.write(\"<tr>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\tdocument.write(\"<td width='20%' height='30'><font class='subtitle'>SSID \");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\tdocument.write(\"</font></td>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\tdocument.write(\"<td width='50%' height='30'>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\tdocument.write(\"<font class='subtitle'>\");\n"));

			/* single quote ' and double quote " in SSID must be quoted */
			memset(quotedSsid, 0x00, sizeof(quotedSsid));
			ltq_wlan_add_quoting_2_string(wlMain[apIndex].ssid, quotedSsid);
			IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_GetMainConfiguration",
				"quotedSsid: %s", quotedSsid);

			ifx_httpdWrite(wp, T("\t\tdocument.write(\"<input name='new_ssid' "
				"size='20' value=''>\");\n"));
			ifx_httpdWrite(wp, T("\t\tdocument.write(\"<input type='hidden' "
				"name='old_ssid' value=''></td>\");\n"));
			ifx_httpdWrite(wp, T("document.tF0.new_ssid.value='%s';\n"), quotedSsid);
			ifx_httpdWrite(wp, T("document.tF0.old_ssid.value='%s';\n"), quotedSsid);

			ifx_httpdWrite(wp,
				       T
				       ("\t\tdocument.write(\"<input type='hidden' name='old_ap_name' value='%s'></td>\");\n"),
				       wlMain[apIndex].apName);
			ifx_httpdWrite(wp,
				       T
				       ("\t\tdocument.write(\"</font></td>\");\n"));
			ifx_httpdWrite(wp,
				       T("\t\tdocument.write(\"</tr>\");\n"));

			/* AP Name */
			ifx_httpdWrite(wp, T("document.write(\"<tr>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<td width='20%' height='30'><font class='subtitle'>AP Name</font></td>\");\n\r"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<td width='50%' height='30'>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<font class='subtitle'>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<input name='new_apName' size='20' value='%s'>\");\n"),
				       wlMain[apIndex].apName);
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<input type='hidden' name='old_apName' value='%s'></td>\");\n"),
				       wlMain[apIndex].apName);
			ifx_httpdWrite(wp, T("document.write(\"</td>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"</tr>\");\n"));

			/*maximum client limit */
			ifx_httpdWrite(wp, T("document.write(\"<tr>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<td width='20%' height='30'>Maximum Client Limit</td>\");\n\r"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<td width='50%' height='30'>\");\n"));
			/*
				WAVE300 specific section to support setting of max. number of
				WLAN clients
			*/
			if (ltq_mapi_get_wlan_vendor(wlMain[apIndex].radioCpeId, IFX_F_DEFAULT) ==
				LTQ_MAPI_WLAN_VENDOR_WAVE300) {
				if (radioIdx == 0) {
					if (wlMain[apIndex].maxStations > wlCaps.maxWlanClients) {
						ifx_httpdWrite(wp, T("document.write(\"<input "
							"name='max_client_limit' size='20' value='%d'>\");\n"),
							wlCaps.maxWlanClients);
					} else if (wlMain[apIndex].maxStations > (maxClientsPerVapRadio1 + wlMain[apIndex].minResSta)) {
						ifx_httpdWrite(wp, T("document.write(\"<input "
							"name='max_client_limit' size='20' value='%d'>\");\n"),
							maxClientsPerVapRadio1 + wlMain[apIndex].minResSta);
					} else {
						ifx_httpdWrite(wp, T("document.write(\"<input name='max_client_limit' "
							"size='20' value='%d'>\");\n"), wlMain[apIndex].maxStations);
					}
				}
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
				else if (radioIdx == 1) {
					if (wlMain[apIndex].maxStations > wlCapsSec.maxWlanClients) {
						ifx_httpdWrite(wp, T("document.write(\"<input name='max_client_limit' "
							"size='20' value='%d'>\");\n"),
							wlCapsSec.maxWlanClients);
					} else if (wlMain[apIndex].maxStations > (maxClientsPerVapRadio2 + wlMain[apIndex].minResSta)) {
						ifx_httpdWrite(wp, T("document.write(\"<input "
							"name='max_client_limit' size='20' value='%d'>\");\n"),
							(maxClientsPerVapRadio2 + wlMain[apIndex].minResSta));
					} else {
						ifx_httpdWrite(wp, T("document.write(\"<input name='max_client_limit' "
							"size='20' value='%d'>\");\n"), wlMain[apIndex].maxStations);
					}
				}
#endif /* #ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS */
			} else {
				ifx_httpdWrite(wp, T("document.write(\"<input name='max_client_limit' "
					"size='20' value='%d'>\");\n"), wlMain[apIndex].maxStations);
			}
			ifx_httpdWrite(wp, T("document.write(\"</td>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"</tr>\");\n"));

			/*minimum reserved clients */
			ifx_httpdWrite(wp, T("document.write(\"<tr>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<td width='20%' height='30'>Number of reserved clients</td>\");\n\r"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<td width='50%' height='30'>\");\n"));
			/* WAVE300 supports setting of number of reserved clients per VAP */
			if (ltq_mapi_get_wlan_vendor(wlMain[apIndex].radioCpeId, IFX_F_DEFAULT) ==
				LTQ_MAPI_WLAN_VENDOR_WAVE300) {
				ifx_httpdWrite(wp, T("document.write(\"<input "
					"name='min_reserved_clients' size='20' value='%d'>\");\n"),
					wlMain[apIndex].minResSta);
			} else {
				ifx_httpdWrite(wp, T("document.write(\"<input "
					"name='min_reserved_clients' size='20' value='0' "
					"disabled>\");\n"));
			}
			ifx_httpdWrite(wp, T("document.write(\"</td>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"</tr>\");\n"));

			/* AP Type */
			ifx_httpdWrite(wp, T("document.write(\"<tr>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<td width='20%' height='30'><font class='subtitle'>AP Type</font></td>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<td width='50%' height='30'>\");\n"));

			switch (wlMain[apIndex].devType) {
			case IFX_MAPI_WLAN_DEV_TYPE_AP:
				ifx_httpdWrite(wp, T("document.write(\"%s\");"),
					       "AP");
				break;
			case IFX_MAPI_WLAN_DEV_TYPE_STA:
				ifx_httpdWrite(wp, T("document.write(\"%s\");"),
					       "Station");
				break;
			case IFX_MAPI_WLAN_DEV_TYPE_VAP:
				ifx_httpdWrite(wp, T("document.write(\"%s\");"),
					       "VAP");
				break;
			case IFX_MAPI_WLAN_DEV_TYPE_REP:
				ifx_httpdWrite(wp, T("document.write(\"%s\");"),
					       "Repeater");
				break;
			case IFX_MAPI_WLAN_DEV_TYPE_BRIDGE:
				ifx_httpdWrite(wp, T("document.write(\"%s\");"),
					       "Bridge");
				break;
			default:
				ifx_httpdError(wp, 400,
					       T
					       ("Illegal value for device type\n"));
				break;
			}

			ifx_httpdWrite(wp, T("document.write(\"</td>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"</tr>\");\n"));
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
			ifx_httpdWrite(wp, T("document.write(\"<tr>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<td width='20%' height='30'>Physical Radio</td>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<td width='50%' height='30'>\");\n"));

			if (wlMain[apIndex].radioCpeId == 1)
				ifx_httpdWrite(wp, T("document.write(\"%s\");"),
					       "Radio-1");
			else
				ifx_httpdWrite(wp, T("document.write(\"%s\");"),
					       "Radio-2");

			ifx_httpdWrite(wp, T("document.write(\"</td>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"</tr>\");\n"));
#endif
			/* Hidden SSID mode */
			ifx_httpdWrite(wp, T("document.write(\"<tr>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<td width='20%' height='30'><font class='subtitle'>Enable Hidden SSID Mode</font></td>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<td width='50%' height='30'>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<font class='subtitle'>\");\n"));

#ifndef CONFIG_LTQ_AEI_CUST
			ifx_httpdWrite(wp, T("document.write(\"<input type='checkbox' "
				"name='ssidMode' value='1' %s>\");\n"),
				(wlMain[apIndex].ssidMode == IFX_ENABLED) ? "checked" : "");
#else
			ifx_httpdWrite(wp, T("document.write(\"<input type='checkbox' "
				"name='ssidMode' value='1' %s %s>\");\n"),
				(wlMain[apIndex].ssidMode == IFX_ENABLED) ? "checked" : "",
				(wlMain[apIndex].WPSena == IFX_ENABLED) ? "disabled" : "");
#endif

			ifx_httpdWrite(wp, T("document.write(\"</font></td>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"</tr>\");\n"));

//			if (ltq_mapi_get_wlan_supported_features(wlMain[i].radioCpeId,
//				IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_NETMODE_PER_VAP) {
			ifx_httpdWrite(wp, T("document.write(\"</table></div>\");\n"));

			ifx_httpdWrite(wp, T("document.write(\"<div id='net_mode_class_0' align='center'>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"<table class='tableInput' summary=''>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"<tr><td width='20%'>Select Network Mode</td>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"<td width='50%'><select name='net_mode_class_0'>"));
			if (wlMain[apIndex].networkMode == IFX_MAPI_WLAN_STD_802_11B) {
				ifx_httpdWrite(wp, T("<option value='2' selected>802.11B"));
				ifx_httpdWrite(wp, T("<option value='4'>802.11N\");\n"));
			} else {
				ifx_httpdWrite(wp, T("<option value='2'>802.11B"));
				ifx_httpdWrite(wp, T("<option value='4' selected>802.11N\");\n"));
			}
			ifx_httpdWrite(wp, T("document.write(\"</select></td></tr>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"</table></div>\");\n"));

			ifx_httpdWrite(wp, T("document.write(\"<div id='net_mode_class_1' align='center'>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"<table class='tableInput' summary=''>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"<tr><td width='20%'>Select Network Mode</td>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"<td width='50%'><select name='net_mode_class_1'>"));
			if (wlMain[apIndex].networkMode == IFX_MAPI_WLAN_STD_802_11G) {
				ifx_httpdWrite(wp, T("<option value='3' selected>802.11G"));
				ifx_httpdWrite(wp, T("<option value='0'>802.11BG"));
				ifx_httpdWrite(wp, T("<option value='6'>802.11GN"));
				ifx_httpdWrite(wp, T("<option value='5'>802.11BGN\");\n"));
			} else if (wlMain[apIndex].networkMode == IFX_MAPI_WLAN_STD_802_11BG) {
				ifx_httpdWrite(wp, T("<option value='3'>802.11G"));
				ifx_httpdWrite(wp, T("<option value='0' selected>802.11BG"));
				ifx_httpdWrite(wp, T("<option value='6'>802.11GN"));
				ifx_httpdWrite(wp, T("<option value='5'>802.11BGN\");\n"));
			} else if (wlMain[apIndex].networkMode == IFX_MAPI_WLAN_STD_802_11GN) {
				ifx_httpdWrite(wp, T("<option value='3'>802.11G"));
				ifx_httpdWrite(wp, T("<option value='0'>802.11BG"));
				ifx_httpdWrite(wp, T("<option value='6' selected>802.11GN"));
				ifx_httpdWrite(wp, T("<option value='5'>802.11BGN\");\n"));
			} else {
				ifx_httpdWrite(wp, T("<option value='3'>802.11G"));
				ifx_httpdWrite(wp, T("<option value='0'>802.11BG"));
				ifx_httpdWrite(wp, T("<option value='6'>802.11GN"));
				ifx_httpdWrite(wp, T("<option value='5' selected>802.11BGN\");\n"));
			}
			ifx_httpdWrite(wp, T("document.write(\"</select></td></tr>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"</table></div>\");\n"));

			ifx_httpdWrite(wp, T("document.write(\"<div id='net_mode_class_2' align='center'>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"<table class='tableInput' summary=''>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"<tr><td width='20%'>Select Network Mode</td>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"<td width='50%'><select name='net_mode_class_2'>"));
			if (wlMain[apIndex].networkMode == IFX_MAPI_WLAN_STD_802_11A) {
				ifx_httpdWrite(wp, T("<option value='1' selected>802.11A"));
				ifx_httpdWrite(wp, T("<option value='4'>802.11N"));
				ifx_httpdWrite(wp, T("<option value='7'>802.11AN\");\n"));
			} else if (wlMain[apIndex].networkMode == IFX_MAPI_WLAN_STD_802_11N) {
				ifx_httpdWrite(wp, T("<option value='1'>802.11A"));
				ifx_httpdWrite(wp, T("<option value='4' selected>802.11N"));
				ifx_httpdWrite(wp, T("<option value='7'>802.11AN\");\n"));
			} else {
				ifx_httpdWrite(wp, T("<option value='1'>802.11A"));
				ifx_httpdWrite(wp, T("<option value='4'>802.11N"));
				ifx_httpdWrite(wp, T("<option value='7' selected>802.11AN\");\n"));
			}
			ifx_httpdWrite(wp, T("document.write(\"</select></td></tr>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"</table></div>\");\n"));

			ifx_httpdWrite(wp, T("document.write(\"<div align='center'>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"<table class='tableInput' summary=''>\");\n"));
//			} /* LTQ_WAVE_NETWORK_MODE_PER_VAP */

			/* Maximum Bit Rate */
			ifx_httpdWrite(wp, T("document.write(\"<tr>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<td width='20%' height='30'><font class='subtitle'>Maximum Bit Rate</font></td>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<td width='50%' height='30'>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<font class='subtitle'>\");\n"));
			ifx_httpdWrite(wp,
				T("document.write(\"<select name='maxBitRate'>\");\n"));

			if (wlMain[apIndex].maxBitRate == 0)
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<option value='0' selected>Auto\");\n"));
			else
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<option value='0'>Auto\");\n"));

			j = 0;
			/* for 802.11b mode only data rates up to 11Mbit/s are valid */
			if (g_wlPhy[radioIdx].standard == IFX_MAPI_WLAN_STD_802_11B) {
				while ((wlMain[apIndex].operDataRates[j] != 0)
					&& (wlMain[apIndex].operDataRates[j] <= 11)) {
					ifx_httpdWrite(wp, T("document.write(\""
						"<option value='%2.1f' \");\n"),
						wlMain[apIndex].operDataRates[j]);

					if (wlMain[apIndex].maxBitRate == wlMain[apIndex].operDataRates[j])
						ifx_httpdWrite(wp, T("document.write(\"selected\");\n"));

					ifx_httpdWrite(wp, T("document.write(\">%2.1f\");\n"),
						wlMain[apIndex].operDataRates[j]);
					j++;
				}
			} else {
				while (wlMain[apIndex].operDataRates[j] != 0) {
					ifx_httpdWrite(wp, T("document.write(\""
						"<option value='%2.1f' \");\n"),
						wlMain[apIndex].operDataRates[j]);

					if (wlMain[apIndex].maxBitRate == wlMain[apIndex].operDataRates[j])
						ifx_httpdWrite(wp, T("document.write(\"selected\");\n"));

					ifx_httpdWrite(wp, T("document.write(\">%2.1f\");\n"),
						wlMain[apIndex].operDataRates[j]);
					j++;
				}
			}
			ifx_httpdWrite(wp, T("document.write(\"</select> MBit/s\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"</font></td>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"</tr>\");\n"));

			/* AP Isolation */
			ifx_httpdWrite(wp, T("document.write(\"<tr>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<td width='20%' height='30'><font class='subtitle'>AP Isolation</font></td>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<td width='50%' height='30'>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"<font class='subtitle'>\");\n"));

			ifx_httpdWrite(wp,
				T("document.write(\"<select name='apIsolation'>\");\n"));

			switch (wlMain[apIndex].apIsolationEna) {
			case 1:
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<option value='0'>OFF</option>\");\n"));
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<option value='1' selected>ON</option>\");\n"));
				break;
			case 0:
			default:
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<option value='0' selected>OFF</option>\");\n"));
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<option value='1'>ON</option>\");\n"));
				break;
			}

			ifx_httpdWrite(wp,
				       T("document.write(\"</select>\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.write(\"</font></td>\");\n"));
			ifx_httpdWrite(wp, T("document.write(\"</tr>\");\n"));
			ifx_httpdWrite(wp, T("break;\n"));
		}
	} else {
		IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_GetMainConfiguration", "");
		ret = IFX_FAILURE;
		goto LTQ_Handler;
	}

LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/LTQ_WLAN_GetMainConfiguration", "ret: %d", ret);
	IFX_MEM_FREE(wlMain);
	IFX_MEM_FREE(wlSec);
	return ret;
}

/**
   This function gets information required to display the web page for "WMM
   Settings" properly. It is called from wlan_wmm.asp.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int
IFX_WLAN_GetAllWmmConfigurations(int eid, httpd_t wp, int argc, char_t ** argv)
{
	IFX_MAPI_WLAN_AP_WMM_Cfg *wlApWmm = NULL;
	IFX_MAPI_WLAN_STA_WMM_Cfg *wlStaWmm = NULL;
	int32 ret = IFX_SUCCESS, flags = IFX_F_DEFAULT, i;
	uint32 numEntries = 0;
	IFX_MAPI_WLAN_MainCfg *wlMain = NULL;

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetAllWmmConfigurations", "");

	/*
		we pass flag IFX_F_RESET_WEB_CFG to indicate to MAPI that main
		config has been read from web
	*/
	if (ifx_mapi_get_all_wlan_main_config((uint32 *) &numEntries, &wlMain,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get all wlan main config\n"));
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetAllWmmConfigurations", "numEntries: %d", numEntries);


	/* get for each AP/VAP all WMM parameters */
	for (i = 0; i < numEntries; i++) {
		uint32 tmpNumEntries;

		/* for all ap/vap store status of wmm and uapsd in hidden variables */
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"wmmEnable_%d\" value=\"%d\" disabled>\n"),
			       i, wlMain[i].WMMena);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"uapsdEnable_%d\" value=\"%d\">\n"),
			       i, wlMain[i].UAPSDena);
		/*
		   \todo parameter numEntries is probably redundant, check later if if
		   can be removed */
		if ((ret = ifx_mapi_get_all_wlan_wmm_ap_config(wlMain[i].iid.cpeId.Id,
			&tmpNumEntries, &wlApWmm, flags)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
					T("Failed to get the complete AP WMM configuration\n\r"));
			goto IFX_Handler;
		}

		/* store for all ap/vap parameters of AP WMM in hidden variables */
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_cwMin_BE_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 0)->ECWmin);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_cwMin_BK_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 1)->ECWmin);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_cwMin_VI_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 2)->ECWmin);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_cwMin_VO_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 3)->ECWmin);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_cwMax_BE_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 0)->ECWmax);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_cwMax_BK_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 1)->ECWmax);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_cwMax_VI_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 2)->ECWmax);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_cwMax_VO_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 3)->ECWmax);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_aifsn_BE_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 0)->AIFSN);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_aifsn_BK_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 1)->AIFSN);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_aifsn_VI_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 2)->AIFSN);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_aifsn_VO_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 3)->AIFSN);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_txop_BE_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 0)->TXOP);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_txop_BK_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 1)->TXOP);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_txop_VI_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 2)->TXOP);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_txop_VO_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 3)->TXOP);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_admCntrl_BE_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 0)->admCntrl);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_admCntrl_BK_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 1)->admCntrl);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_admCntrl_VI_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 2)->admCntrl);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_admCntrl_VO_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 3)->admCntrl);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_ackPolicy_BE_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 0)->ackPolicyEna);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_ackPolicy_BK_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 1)->ackPolicyEna);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_ackPolicy_VI_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 2)->ackPolicyEna);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"ap_ackPolicy_VO_%d\" value=\"%d\">\n"),
			       i, (wlApWmm + 3)->ackPolicyEna);

		/*
		   \todo parameter numEntries is probably redundant, check later if if
		   can be removed */
		if ((ret = ifx_mapi_get_all_wlan_wmm_sta_config(wlMain[i].iid.cpeId.Id,
			&tmpNumEntries, &wlStaWmm, flags)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
					T("Failed to get the complete STA WMM configuration\n\r"));
			goto IFX_Handler;
		}

		/* store for all ap/vap parameters of STA WMM in hidden variables */
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"sta_cwMin_BE_%d\" value=\"%d\">\n"),
			       i, (wlStaWmm + 0)->ECWmin);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"sta_cwMin_BK_%d\" value=\"%d\">\n"),
			       i, (wlStaWmm + 1)->ECWmin);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"sta_cwMin_VI_%d\" value=\"%d\">\n"),
			       i, (wlStaWmm + 2)->ECWmin);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"sta_cwMin_VO_%d\" value=\"%d\">\n"),
			       i, (wlStaWmm + 3)->ECWmin);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"sta_cwMax_BE_%d\" value=\"%d\">\n"),
			       i, (wlStaWmm + 0)->ECWmax);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"sta_cwMax_BK_%d\" value=\"%d\">\n"),
			       i, (wlStaWmm + 1)->ECWmax);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"sta_cwMax_VI_%d\" value=\"%d\">\n"),
			       i, (wlStaWmm + 2)->ECWmax);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"sta_cwMax_VO_%d\" value=\"%d\">\n"),
			       i, (wlStaWmm + 3)->ECWmax);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"sta_aifsn_BE_%d\" value=\"%d\">\n"),
			       i, (wlStaWmm + 0)->AIFSN);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"sta_aifsn_BK_%d\" value=\"%d\">\n"),
			       i, (wlStaWmm + 1)->AIFSN);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"sta_aifsn_VI_%d\" value=\"%d\">\n"),
			       i, (wlStaWmm + 2)->AIFSN);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"sta_aifsn_VO_%d\" value=\"%d\">\n"),
			       i, (wlStaWmm + 3)->AIFSN);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"sta_txop_BE_%d\" value=\"%d\">\n"),
			       i, (wlStaWmm + 0)->TXOP);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"sta_txop_BK_%d\" value=\"%d\">\n"),
			       i, (wlStaWmm + 1)->TXOP);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"sta_txop_VI_%d\" value=\"%d\">\n"),
			       i, (wlStaWmm + 2)->TXOP);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"sta_txop_VO_%d\" value=\"%d\">\n"),
			       i, (wlStaWmm + 3)->TXOP);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"sta_ackPolicy_BE_%d\" value=\"%d\">\n"),
			       i, (wlStaWmm + 0)->ackPolicyEna);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"sta_ackPolicy_BK_%d\" value=\"%d\">\n"),
			       i, (wlStaWmm + 1)->ackPolicyEna);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"sta_ackPolicy_VI_%d\" value=\"%d\">\n"),
			       i, (wlStaWmm + 2)->ackPolicyEna);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"sta_ackPolicy_VO_%d\" value=\"%d\">\n"),
			       i, (wlStaWmm + 3)->ackPolicyEna);
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetAllWmmConfigurations", "");
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetAllWmmConfigurations", "ret: %d", ret);
	IFX_MEM_FREE(wlApWmm);
	IFX_MEM_FREE(wlStaWmm);
	IFX_MEM_FREE(wlMain);
	return ret;
}

/**
   This function gets information required to display the web page for "WPS
   Settings" properly. It is called from wlan_wps.asp.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int
IFX_WLAN_GetAllWpsConfigurations(int eid, httpd_t wp, int argc, char_t ** argv)
{
	IFX_MAPI_WLAN_WPS_Cfg wlWps;
	IFX_MAPI_WLAN_SecCfg *wlSec = NULL;
	IFX_MAPI_WLAN_MainCfg *wlMain = NULL;
	int32 ret = IFX_SUCCESS, i;
	uint32 numEntries = gNumEntries;

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetAllWpsConfigurations", "");

	memset(&wlWps, 0x00, sizeof(IFX_MAPI_WLAN_WPS_Cfg));

	/*
		we pass flag IFX_F_RESET_WEB_CFG to indicate to MAPI that main
		config has been read from web
	*/
	if (ifx_mapi_get_all_wlan_main_config((uint32 *) &numEntries, &wlMain,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get all wlan main config\n"));
		goto IFX_Handler;
	}

	if ((ret = ifx_mapi_get_all_wlan_security_config(&numEntries, &wlSec,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) ) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400,
				T("Failed to get the complete security configuration\n\r"));
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetAllWpsConfigurations", "numEntries: %d", numEntries);

	if (numEntries <= LTQ_MAX_NUM_VAP) {
		for (i = 0; i < numEntries; i++) {
			/* store in global variable for later use in this page */
			memcpy(&g_wlSec[i], wlSec + i, sizeof(IFX_MAPI_WLAN_SecCfg));
		}
	} else {
		ifx_httpdError(wp, 400,
			T("Number of security instances out of range\n\r"));
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	ifx_httpdWrite(wp,
		T("<input type=\"hidden\" name=\"wlBeacon\" value=\"\">\n"));
	ifx_httpdWrite(wp,
		T("<input type=\"hidden\" name=\"wlEncr\" value=\"\">\n"));
	ifx_httpdWrite(wp,
		T("<input type=\"hidden\" name=\"wlAuth\" value=\"\">\n"));
	ifx_httpdWrite(wp,
		T("<input type=\"hidden\" name=\"hiddenSsid\" value=\"\">\n"));
	/* get for each AP/VAP all WPS parameters */
	for (i = 0; i < numEntries; i++) {
		/* get WPS information */
		wlWps.iid.config_owner = IFX_WEB;
		sprintf(wlWps.iid.cpeId.secName, "%s", TAG_WLAN_WPS);
		sprintf(wlWps.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
		/* parent cpeid of wps object, is cpeID of main object */
		wlWps.iid.pcpeId.Id = wlMain[i].iid.cpeId.Id;

		if ((ret = ifx_mapi_get_wlan_wps_config(&wlWps, IFX_F_DEFAULT)) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
					T("Failed to get the AP WPS configuration\n\r"));
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetAllWpsConfigurations", "");

		/* for all ap/vap store status of wps in hidden variables */
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"wpsEnable_%d\" value=\"%d\">\n"),
			       i, wlWps.enable);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"hiddenSsid_%d\" value=\"%d\">\n"),
			       i, wlMain[i].ssidMode);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"wlEncr_%d\" value=\"%d\">\n"),
			       i, g_wlSec[i].wlEncr);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"wlAuth_%d\" value=\"%d\">\n"),
			       i, g_wlSec[i].wlAuth);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"wlBeacon_%d\" value=\"%d\">\n"),
			       i, g_wlSec[i].beaconType);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"wpsEnrolleeSupport_%d\" value=\"%d\">\n"),
			       i, wlWps.enrolleeEna);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"wpsIntRegsSupport_%d\" value=\"%d\">\n"),
			       i, wlWps.intRegEna);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"wpsProxySupport_%d\" value=\"%d\">\n"),
			       i, wlWps.proxyEna);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"wpsState_%d\" value=\"%d\">\n"),
			       i, wlWps.cfgState);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"wpsApPin_%d\" value=\"%d\">\n"),
			       i, wlWps.apWpsPin);
		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"wpsPinLockout_%d\" "
			"value=\"%d\">\n"), i, wlWps.maxPinLockout);
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetAllWpsConfigurations", "ret: %d", ret);
	IFX_MEM_FREE(wlMain);
	IFX_MEM_FREE(wlSec);
	return ret;
}

/**
   This function gets information required to display the web page for "WPS
   Settings" properly. It is called from wlan_wps.asp.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int IFX_WLAN_GetWpsConfiguration(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 ret = IFX_SUCCESS;
	char8 *name;

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetWpsConfiguration", "");

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetWpsConfiguration", "");

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) != 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetWpsConfiguration", "name: %s",
		       name);

	ifx_httpdWrite(wp, T("<td id=\"wps_pin_gen\">"));
	ifx_httpdWrite(wp, T("<a class=\"buttonLarge\" href=\"#\" "
		"value=\"Generate PIN\" name=\"generatePin\" "
		"onclick=\"return wpsGeneratePin();\">Generate PIN</a>"));
	ifx_httpdWrite(wp, T("</td>"));
#if 0
	ifx_httpdWrite(wp, T("<td>&nbsp;</td>"));
#endif				/* #ifdef CONFIG_FEATURE_WPS_GENERATE_PIN */

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetWpsConfiguration", "ret: %d", ret);
	return ret;
}

/**
   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int
ltq_wlan_get_all_wps_epmac_config(int eid, httpd_t wp, int argc, char_t ** argv)
{
	LTQ_MAPI_WLAN_WPS_EP_MAC_Cfg *wlWpsEpMac = NULL;
	int32 ret = IFX_SUCCESS, i = 0, j = 0;
	uint32 numEntries = 0;
	uint32 mainCpeId = 0, wlWpsEpMacCount = 0;
	IFX_MAPI_WLAN_MainCfg *wlMain = NULL;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_all_wps_epmac_config", "");

	ifx_httpdWrite(wp,
		T("<input type='hidden' name='numAclEntries' value='0'>\n"));

	/*
		we pass flag IFX_F_RESET_WEB_CFG to indicate to MAPI that main
		config has been read from web
	*/
	if (ifx_mapi_get_all_wlan_main_config(&numEntries, &wlMain,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get all wlan main config\n"));
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_all_wps_epmac_config", "numEntries: %d", numEntries);
	
	/* store for all ap/vap parameters in hidden variables */
	for (i = 0; i < numEntries; i++) {
		mainCpeId = wlMain[i].iid.cpeId.Id;
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_all_wps_epmac_config",
			       "mainCpeId: %d", mainCpeId);
		/*
		 * get the ep mac table
		 */
		if ((ret = ltq_mapi_get_all_wlan_wps_endpoint_mac(mainCpeId, &wlWpsEpMacCount,
			&wlWpsEpMac, IFX_F_DEFAULT)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400, T("Failed to get wps ep mac able"));
			goto LTQ_Handler;
		}
		/* store the number of MAC filter entries in global variable */
		gWpsEpMacCount[i] = wlWpsEpMacCount;
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_all_wps_epmac_config",
			"MAC address entries: %d", wlWpsEpMacCount);

		if (wlWpsEpMacCount <= LTQ_MAX_NUM_WPS_EP_MAC)
			memcpy(&g_wlWpsEpMacTable[i][0], wlWpsEpMac,
				sizeof(LTQ_MAPI_WLAN_WPS_EP_MAC_Cfg) * wlWpsEpMacCount);

		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"numAclEntries_%d\" "
			"value=\"%d\">\n"), i, wlWpsEpMacCount);
		for (j = 0; j < LTQ_MAX_NUM_WPS_EP_MAC; j++) {
			ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"macAddr_%d_%d\""
				" value=\"\">\n"), i + 1, j + 1);
			if (j < wlWpsEpMacCount) {
				IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_all_wps_epmac_config",
					"MAC address: %s", (wlWpsEpMac + j)->macAddr);
				ifx_httpdWrite(wp, T("<script type=\"text/javascript\">"
					"document.tF0.macAddr_%d_%d.value='%s';</script>\n"),
					i + 1, j + 1, (wlWpsEpMac + j)->macAddr);
			} else {
				ifx_httpdWrite(wp, T("<script type=\"text/javascript\">"
					"document.tF0.macAddr_%d_%d.value='';</script>\n"), i + 1, j + 1);
			}
		}
	}

LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_all_wps_epmac_config",
		"ret: %d", ret);
	IFX_MEM_FREE(wlWpsEpMac);
	IFX_MEM_FREE(wlMain);
	return ret;
}

/**
   This function gets information required to display the web page for "WLAN MAC
   Control" properly. It is called from wlan_mac_control.asp.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int ltq_wlan_get_wps_ep_mac(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 ret = IFX_SUCCESS, i = 0;
	char8 *name = NULL;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_wps_ep_mac", "");

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return IFX_FAILURE;
	}

	if (!gstrcmp(name, "MAC_ENTRIES")) {
		for (i = 0; i < LTQ_MAX_NUM_WPS_EP_MAC; i++) {
			ifx_httpdWrite(wp, T("<tr>\n\t"));	/* open a row */
			if (i < gWpsEpMacCount[0]) {
				ifx_httpdWrite(wp,
					       T
					       ("<td><input name='macAddr_%d' value='%s'></td>\n\t"),
					       i + 1,
					       g_wlWpsEpMacTable[0][i].macAddr);
				ifx_httpdWrite(wp,
					       T
					       ("<td><input type='checkbox' name='rmid%d' value=1></td>\n\t"),
					       i);
			} else {
				ifx_httpdWrite(wp,
					       T
					       ("<td><input name='macAddr_%d' value=''></td>\n\t"),
					       i + 1);
				ifx_httpdWrite(wp,
					       T
					       ("<td><input type='checkbox' name='rmid%d' value=1 disabled></td>\n\t"),
					       i);
			}
			ifx_httpdWrite(wp, T("</tr>\n\n"));	/* closing a row */
		}
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_wps_ep_mac", "ret: %d", ret);
	return ret;
}

/**
   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int ltq_wlan_update_wps_epmac_table(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 i, j;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_update_wps_epmac_table", "");

	/* for all AP and VAP get the mode and */
	for (i = 0; i < gNumEntries; i++) {
		ifx_httpdWrite(wp, T("case %d:\n"), i);
		ifx_httpdWrite(wp, T("document.tF0.apIndex.value = %d;\n"), i);
		ifx_httpdWrite(wp, T("document.tF0.ssid.value = "
			"document.tF0.ssid%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.numAclEntries.value = "
			"document.tF0.numAclEntries_%d.value;\n"), i);

		for (j = 0; j < LTQ_MAX_NUM_WPS_EP_MAC; j++) {
			if (j < gWpsEpMacCount[i])
				ifx_httpdWrite(wp, T("document.tF0.rmid%d.disabled = "
				"false;\n"), j);
			else
				ifx_httpdWrite(wp, T("document.tF0.rmid%d.disabled = "
				"true;\n"), j);
		}

		for (j = 0; j < gWpsEpMacCount[i]; j++)
			ifx_httpdWrite(wp, T("document.tF0.macAddr_%d.value = "
			"document.tF0.macAddr_%d_%d.value;\n"), j + 1, i + 1, j + 1);

		for (j = gWpsEpMacCount[i]; j < LTQ_MAX_NUM_WPS_EP_MAC; j++)
			ifx_httpdWrite(wp, T("document.tF0.macAddr_%d.value = \"\";\n"),
			j + 1);

		ifx_httpdWrite(wp, T("break;\n"));
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_update_wps_epmac_table", "");
	return IFX_SUCCESS;
}

/**
   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void ltq_prepare_wps_ep_mac_delete(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 i;

	for (i = 0; i < LTQ_MAX_NUM_WPS_EP_MAC; i++) {
		ifx_httpdWrite(wp, T("if (document.tF0.rmid%d.checked == true) {\n"), i);
		ifx_httpdWrite(wp, T("\tnDelEntries++;}\n"));
	}
}

/**
   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void ltq_prepare_wps_ep_mac_add(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 i = 0, k = 0;

	for (i = 0; i < LTQ_MAX_NUM_WPS_EP_MAC; i++) {
		ifx_httpdWrite(wp, T("if(isNValidmac(document.tF0.macAddr_%d.value)) "
			"{\n\t"), i + 1);
			ifx_httpdWrite(wp, T("alert(\"Please input valid MAC address to all"
				" field\");\n"));
			ifx_httpdWrite(wp, T("return false;\n}\n"));
			ifx_httpdWrite(wp, T("else if (!isBlank("
				"document.tF0.macAddr_%d.value)){\n"), i + 1);
			ifx_httpdWrite(wp, T("nMacTableEntries++;\n}\n"));
	}

	for (i = 0; i < LTQ_MAX_NUM_WPS_EP_MAC; i++) {
		ifx_httpdWrite(wp, T("if( (!isBlank(document.tF0.macAddr_%d.value))) {\n"), i+1);
		for (k = i + 1; k < LTQ_MAX_NUM_WPS_EP_MAC; k++) {
			ifx_httpdWrite(wp, T("if( (document.tF0.macAddr_%d.value == "
				"document.tF0.macAddr_%d.value)) {\n"),
				i + 1, k + 1);

			ifx_httpdWrite(wp, T ("alert(\"Same MAC address entered twice. "
				"Please check fields: %d and %d\");\n"), i+1, k+1);
			ifx_httpdWrite(wp, T("return false;\n}\n"));
		}
		ifx_httpdWrite(wp, T("\n}\n"));
	}

	return;
}

/**
   This function gets information required to display the web page for "Security
   Settings" properly. It is called from wlan_sec.asp.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int
IFX_WLAN_GetAllSecurityConfigurations(int eid, httpd_t wp, int argc,
				      char_t ** argv)
{
	IFX_MAPI_WLAN_WEP_Cfg wlWepCfg;
	IFX_MAPI_WLAN_PersonalCfg wlPersonal;
	IFX_MAPI_WLAN_802_1x wlRadius;
	int32 ret = IFX_SUCCESS, i, j;
	char_t sValue[MAX_FILELINE_LEN], quotedPassString[2*IFX_MAPI_PSK_MAX_LEN];
	char_t *delim = ". \n\t";
	char_t *ipaddr1, *ipaddr2, *ipaddr3, *ipaddr4;
	IFX_MAPI_WLAN_MainCfg *wlMain = NULL;
	uint32 numEntries = 0;

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetAllSecurityConfigurations", "");

	memset(&wlWepCfg, 0x00, sizeof(IFX_MAPI_WLAN_WEP_Cfg));
	memset(&wlPersonal, 0x00, sizeof(IFX_MAPI_WLAN_PersonalCfg));
	memset(&wlRadius, 0x00, sizeof(IFX_MAPI_WLAN_802_1x));

	/*
		we pass flag IFX_F_RESET_WEB_CFG to indicate to MAPI that main
		config has been read from web
	*/
	if (ifx_mapi_get_all_wlan_main_config(&numEntries, &wlMain,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get all wlan main config\n"));
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetAllSecurityConfigurations",
		"numEntries: %d", numEntries);

	ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"netModeVap\" value=''>"));
	for (i = 0; i < numEntries; i++) {
		/* store for all ap/vap parameters in hidden variables */
		if (ltq_mapi_get_wlan_supported_features(wlMain[i].radioCpeId,
			IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_NETMODE_PER_VAP) {
			ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"netModeVap%d\" "
				"value=%d>"), i + 1, wlMain[i].networkMode);
		} /* LTQ_WAVE_NETWORK_MODE_PER_VAP */
		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"wpsEna%d\" "
			"value=\"\">"), i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"beaconType%d\" value=\"\">"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"authType%d\" value=\"\">"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"encrType%d\" value=\"\">"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"keyIndex%d\" value=\"\">"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"encrLevel%d\" value=\"\">"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"wepKeyType%d\" value=\"\">"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"wepKey1_%d\" value=\"\">"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"wepKey2_%d\" value=\"\">"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"wepKey3_%d\" value=\"\">"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"wepKey4_%d\" value=\"\">"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"reAuthIntvl%d\" value=\"\">"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"groupKeyIntvl%d\" value=\"\">"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"pskType%d\" value=\"\">"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"preSharedKey%d\" value=\"\">"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"passPhrase%d\" value=\"\">"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"wpa2PreAuthEnable%d\" value=\"\">"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"radiusIp1_%d\" value=\"\">"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"radiusIp2_%d\" value=\"\">"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"radiusIp3_%d\" value=\"\">"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"radiusIp4_%d\" value=\"\">"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"radiusPort%d\" value=\"\">"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"radiusSecret%d\" value=\"\">"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=\"hidden\" name=\"radioOperMode%d\" value=\"\">\n"),
			       i + 1);

		ifx_httpdWrite(wp,
			       T
			       ("<script type=\"text/javascript\">document.tF0.beaconType%d.value = %d;</script>\n"),
			       i + 1, g_wlSec[i].beaconType);
		ifx_httpdWrite(wp,
			       T
			       ("<script type=\"text/javascript\">document.tF0.authType%d.value = %d;</script>\n"),
			       i + 1, g_wlSec[i].wlAuth);
		ifx_httpdWrite(wp,
			       T
			       ("<script type=\"text/javascript\">document.tF0.encrType%d.value = %d;</script>\n"),
			       i + 1, g_wlSec[i].wlEncr);

		for (j = 0; j < IFX_MAPI_NUM_WEP_KEYS; j++)
			wlWepCfg.wepKey[j].iid.pcpeId.Id = g_wlSec[i].iid.cpeId.Id;

		if ((ret = ifx_mapi_get_wlan_wep_config(&wlWepCfg, IFX_F_DEFAULT)) !=
		    IFX_SUCCESS) {
				ifx_httpdError(wp, 400,"Failed to get info of wep keys");
			goto IFX_Handler;
		} else {
			ifx_httpdWrite(wp,
				       T
				       ("<script type=\"text/javascript\">document.tF0.keyIndex%d.value = %d;</script>\n"),
				       i + 1, wlWepCfg.wepKeyIndex);
			ifx_httpdWrite(wp,
				       T
				       ("<script type=\"text/javascript\">document.tF0.encrLevel%d.value = %d;</script>\n"),
				       i + 1, wlWepCfg.wepEncrLevel);
			ifx_httpdWrite(wp,
				       T
				       ("<script type=\"text/javascript\">document.tF0.wepKeyType%d.value = %d;</script>\n"),
				       i + 1, wlWepCfg.wepKeyType);

			for (j = 0; j < IFX_MAPI_NUM_WEP_KEYS; j++) {
				/* single quote ' and double quote " in WEP key must be quoted */
				memset(quotedPassString, 0x00, sizeof(quotedPassString));
				ltq_wlan_add_quoting_2_string(wlWepCfg.wepKey[j].wepKey, quotedPassString);
				ifx_httpdWrite(wp, T("<script type=\"text/javascript\">"
					"document.tF0.wepKey%d_%d.value='%s';</script>\n"),
					j + 1, i + 1, quotedPassString);
				IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetAllSecurityConfigurations",
					"wepKey%d: %s", j+1, wlWepCfg.wepKey[j].wepKey);
			}
		}

		/* parent CPE ID of wlRadius object is cpeID of wlan security object */
		wlRadius.iid.pcpeId.Id = g_wlSec[i].iid.cpeId.Id;
		if ((ret =
		     ifx_mapi_get_wlan_802_1x_config(&wlRadius,
						     IFX_F_DEFAULT)) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to get info of enterprise security");
			goto IFX_Handler;
		} else {
			ifx_httpdWrite(wp,
				       T
				       ("<script type=\"text/javascript\">document.tF0.reAuthIntvl%d.value = %d;</script\n>"),
				       i + 1, wlRadius.wpa2ReAuthIntvl);
			ifx_httpdWrite(wp,
				       T
				       ("<script type=\"text/javascript\">document.tF0.groupKeyIntvl%d.value = %d;</script>\n"),
				       i + 1, wlRadius.groupKeyIntvl);
			ifx_httpdWrite(wp,
				       T
				       ("<script type=\"text/javascript\">document.tF0.wpa2PreAuthEnable%d.value = %d;</script>\n"),
				       i + 1, wlRadius.wpa2PreAuthEna);
			ifx_httpdWrite(wp,
				       T
				       ("<script type=\"text/javascript\">document.tF0.radiusPort%d.value = %d;</script>\n"),
				       i + 1, wlRadius.radiusPort);

			/* single quote ' and double quote " in WEP key must be quoted */
			memset(quotedPassString, 0x00, sizeof(quotedPassString));
			ltq_wlan_add_quoting_2_string(wlRadius.radiusServerSecret, quotedPassString);
			ifx_httpdWrite(wp, T("<script type=\"text/javascript\">"
				"document.tF0.radiusSecret%d.value='%s';</script>\n"),
				i + 1, quotedPassString);

			sprintf(sValue, "%s",
				inet_ntoa(wlRadius.radiusServerIP));
			ipaddr1 = strtok(sValue, delim);
			ipaddr2 = strtok(NULL, delim);
			ipaddr3 = strtok(NULL, delim);
			ipaddr4 = strtok(NULL, delim);
			ifx_httpdWrite(wp,
				       T
				       ("<script type=\"text/javascript\">document.tF0.radiusIp1_%d.value=\"%s\";</script>\n"),
				       i + 1, ipaddr1);
			ifx_httpdWrite(wp,
				       T
				       ("<script type=\"text/javascript\">document.tF0.radiusIp2_%d.value=\"%s\";</script>\n"),
				       i + 1, ipaddr2);
			ifx_httpdWrite(wp,
				       T
				       ("<script type=\"text/javascript\">document.tF0.radiusIp3_%d.value=\"%s\";</script>\n"),
				       i + 1, ipaddr3);
			ifx_httpdWrite(wp,
				       T
				       ("<script type=\"text/javascript\">document.tF0.radiusIp4_%d.value=\"%s\";</script>\n"),
				       i + 1, ipaddr4);
		}

		wlPersonal.psk.iid.pcpeId.Id = g_wlSec[i].iid.cpeId.Id;
		if ((ret =
		     ifx_mapi_get_wlan_personal_config(&wlPersonal,
						       IFX_F_DEFAULT)) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to get info of wpa passphrase");
			goto IFX_Handler;
		} else {
			ifx_httpdWrite(wp,
				       T
				       ("<script type=\"text/javascript\">document.tF0.pskType%d.value = %d;</script>\n"),
				       i + 1, wlPersonal.pskType);
			if (wlPersonal.pskType == IFX_MAPI_WLAN_HEX_KEY) {
				ifx_httpdWrite(wp, T("<script type=\"text/javascript\">"
					"document.tF0.preSharedKey%d.value='%s';</script>\n"),
					i + 1, wlPersonal.psk.preSharedKey);
			} else {
				/* single quote ' and double quote " in WEP key must be quoted */
				memset(quotedPassString, 0x00, sizeof(quotedPassString));
				ltq_wlan_add_quoting_2_string(wlPersonal.psk.passPhrase, quotedPassString);
				ifx_httpdWrite(wp, T("<script type=\"text/javascript\">"
				"document.tF0.passPhrase%d.value='%s';</script>\n"),
				i + 1, quotedPassString);
			}
		}

		ifx_httpdWrite(wp,
			       T
			       ("<script type=\"text/javascript\">document.tF0.wpsEna%d.value='%d';</script>\n"),
			       i + 1, wlMain[i].WPSena);

#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
		ifx_httpdWrite(wp,
			       T
			       ("<script type=\"text/javascript\">document.tF0.radioOperMode%d.value='%d';</script>\n"),
			       i + 1, g_wlPhy[(wlMain[i].radioCpeId - 1)].standard);
#else
		ifx_httpdWrite(wp,
			       T
			       ("<script type=\"text/javascript\">document.tF0.radioOperMode%d.value='%d';</script>\n"),
			       i + 1, g_wlPhy[0].standard);
#endif				// CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetAllSecurityConfigurations", "");
	IFX_MEM_FREE(wlMain);
	return ret;
}

/**
   This function gets information required to display the web page for "Security
   Settings" properly. It is called from wlan_sec.asp.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int
IFX_WLAN_GetSecurityConfiguration(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 ret = IFX_SUCCESS, i;
	char8 *name, *debug;
	IFX_MAPI_WLAN_MainCfg *wlMain = NULL;
	IFX_MAPI_WLAN_SecCfg *wlSec = NULL;
	uint32 numEntries = 0;
	LTQ_MAPI_WLAN_Feature features = LTQ_MAPI_WLAN_FEATURE_NONE;

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetSecurityConfiguration", "");

	if (ifx_httpd_parse_args(argc, argv, T("%s,%s"), &name, &debug) < 1) {
		ret = IFX_FAILURE;
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd,
			"/tmp/IFX_WLAN_GetSecurityConfiguration", "name: %s, debug: %s",
			name, debug);

	/*
		we pass flag IFX_F_RESET_WEB_CFG to indicate to MAPI that main
		config has been read from web
	*/
	if (ifx_mapi_get_all_wlan_main_config(&numEntries, &wlMain,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get all wlan main config\n"));
		goto IFX_Handler;
	}
	if (ifx_mapi_get_all_wlan_security_config((uint32 *) &numEntries, &wlSec,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400,
			T("Failed to get the complete security configuration\n\r"));
		goto IFX_Handler;
	}

	if (!gstrcmp(name, T("UPDATE_OPRMODES"))) {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetSecurityConfiguration", "");
	} else if (!gstrcmp(name, T("UPDATE_OPTIONS"))) {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetSecurityConfiguration", "");

		ifx_httpdWrite(wp, T("switch(beaconType) {\n"));
		ifx_httpdWrite(wp, T("<!-- WLAN_BEACON_BASIC -->\n"));
		ifx_httpdWrite(wp, T("case 0:\n\t"));
#if !defined (CONFIG_LTQ_AEI_CUST)
		for (i = 0; i < numEntries; i++) {
			ifx_httpdWrite(wp, T("if(apIndex == %d) {\n\t\t"),
				       (i + 1));
			ifx_httpdWrite(wp,
				       T
				       ("wpsEna = document.tF0.wpsEna%d.value;\n\t\t"),
				       i + 1);
			ifx_httpdWrite(wp,
				       T
				       ("document.tF0.authType.options[0]=new Option(authTypeArray[0][0], \"0\");\n\t\t"));

			features = ltq_mapi_get_wlan_supported_features(wlMain[i].radioCpeId,
				IFX_F_DEFAULT);
			if (features & LTQ_MAPI_WLAN_FEATURE_NETMODE_PER_VAP) {
				/* if operational mode is 802.n mode, then WEP is not allowed */
				ifx_httpdWrite(wp, T("if ((oprMode == 4) || (oprMode >= 8)) {\n"));
			} else {
				/* if operational mode is any 802.xn mode, then WEP is not allowed */
				ifx_httpdWrite(wp, T("if (oprMode >= 4) {\n"));
			}

			ifx_httpdWrite(wp, T("document.tF0.authType.length= 1;\n"));
			ifx_httpdWrite(wp, T("} else {\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.tF0.authType.options[1]=new Option(authTypeArray[0][1], \"1\");\n\t\t\t"));
			ifx_httpdWrite(wp,
				       T
				       ("document.tF0.authType.length= 2;\n\t\t\t"));

			ifx_httpdWrite(wp, T("}\n"));
			/*
			   wlAuth >= IFX_MAPI_WLAN_AUTH_RADIUS: this means that beaconType
			   has changed; in this case we choose the first of the two new
			   options as selected; otherwise the same as before is selected */
			if (wlSec[i].wlAuth >= IFX_MAPI_WLAN_AUTH_RADIUS)
				ifx_httpdWrite(wp,
					       T
					       ("document.tF0.authType.options[0].selected = true;\n\t\t\t\t\t"));
			else
				ifx_httpdWrite(wp,
					       T
					       ("document.tF0.authType.options[%d].selected = true;\n\t\t\t\t\t"),
					       wlSec[i].wlAuth);

			ifx_httpdWrite(wp,
				       T
				       ("document.tF0.encrType.options[0]=new Option(encryType[0][0], \"0\");\n\t\t\t\t\t"));

			if (features & LTQ_MAPI_WLAN_FEATURE_NETMODE_PER_VAP) {
				ifx_httpdWrite(wp, T("if ((oprMode == 4) || (oprMode >= 8)) {\n\t"));
			} else {
				ifx_httpdWrite(wp, T("if (oprMode >= 4) {\n\t"));
			}

			ifx_httpdWrite(wp, T("document.tF0.encrType.length= 1;\n"));
			ifx_httpdWrite(wp, T("} else {\n\t"));
			ifx_httpdWrite(wp,
				       T
				       ("document.tF0.encrType.options[1]=new Option(encryType[0][1], \"1\");\n\t"));
			ifx_httpdWrite(wp,
				       T
				       ("document.tF0.encrType.length= 2;\n\t"));
			ifx_httpdWrite(wp, T("}\n"));
			/*
			   wlEncr >= IFX_MAPI_WLAN_ENCR_TKIP: this means that beaconType
			   has changed; in this case we chosse the first of the two new
			   options as selected; otherwise the same as before is selected; */
			if (wlSec[i].wlEncr >= IFX_MAPI_WLAN_ENCR_TKIP)
				ifx_httpdWrite(wp,
					       T
					       ("document.tF0.encrType.options[0].selected = true;\n\t\t\t\t}\n\t\t\t"));
			else
				ifx_httpdWrite(wp,
					       T
					       ("document.tF0.encrType.options[%d].selected = true;\n\t\t\t\t}\n\t\t\t"),
					       wlSec[i].wlEncr);
		}
#else /* #if !defined (CONFIG_LTQ_AEI_CUST) */
		for (i = 0; i < numEntries; i++) {
			ifx_httpdWrite(wp, T("if(apIndex == %d) {\n"),
				       (i + 1));
			ifx_httpdWrite(wp,
				       T
				       ("wpsEna             = document.tF0.wpsEna%d.value;\n"),
				       i + 1);
			ifx_httpdWrite(wp,
				       T
				       ("document.tF0.authType.options[0]=new Option(authTypeArray[0][0], \"0\");\n"));
			ifx_httpdWrite(wp, T("if (wpsEna == 1) {\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.tF0.authType.length= 1;\n"));
			ifx_httpdWrite(wp, T("} else {\n\t"));
			ifx_httpdWrite(wp,
				       T
				       ("document.tF0.authType.options[1]=new Option(authTypeArray[0][1], \"1\");\n"));
			ifx_httpdWrite(wp,
				       T
				       ("document.tF0.authType.length= 2;\n"));

			ifx_httpdWrite(wp, T("}\n"));
			/*
			   wlAuth >= IFX_MAPI_WLAN_AUTH_RADIUS: this means that beaconType
			   has changed; in this case we choose the first of the two new
			   options as selected; otherwise the same as before is selected */
			if (wlSec[i].wlAuth >= IFX_MAPI_WLAN_AUTH_RADIUS)
				ifx_httpdWrite(wp,
					       T
					       ("document.tF0.authType.options[0].selected = true;\n"));
			else
				ifx_httpdWrite(wp,
					       T
					       ("document.tF0.authType.options[%d].selected = true;\n"),
					       wlSec[i].wlAuth);

			ifx_httpdWrite(wp, T("document.tF0.encrType.options[0] = "
				"new Option(encryType[0][1], \"1\");\n"));
			ifx_httpdWrite(wp, T("document.tF0.encrType.length= 1;\n"));
			ifx_httpdWrite(wp, T("document.tF0.encrType.options[0].selected = "
				"true;\n}\n"));
		}
		ifx_httpdWrite(wp, T("break;\n"));
		ifx_httpdWrite(wp, T("<!-- WLAN_BEACON_NONE -->\n"));
		ifx_httpdWrite(wp, T("case 5:\n\t"));
		for (i = 0; i < numEntries; i++) {
			ifx_httpdWrite(wp, T("if(apIndex == %d) {\n"), (i + 1));
			ifx_httpdWrite(wp, T("document.tF0.authType.options[0] = "
				"new Option(authTypeArray[0][0], \"0\");\n"));
			ifx_httpdWrite(wp,T ("document.tF0.authType.length= 1;\n"));
			ifx_httpdWrite(wp,
				T("document.tF0.authType.options[0].selected = true;\n"));

			ifx_httpdWrite(wp, T ("document.tF0.encrType.options[0] = "
				"new Option(encryType[0][0], \"0\");\n"));
			ifx_httpdWrite(wp, T("document.tF0.encrType.length= 1;\n"));
			ifx_httpdWrite(wp, T("document.tF0.encrType.options[0].selected = "
				"true;\n}\n"));
		}
#endif /* #if !defined (CONFIG_LTQ_AEI_CUST) */
		ifx_httpdWrite(wp, T("break;\n"));
		ifx_httpdWrite(wp, T("<!-- WLAN_BEACON_WPA_WPA2 -->\n"));
		ifx_httpdWrite(wp, T("case 1:\n"));
		ifx_httpdWrite(wp, T("case 2:\n"));
		ifx_httpdWrite(wp, T("case 3:\n"));
		ifx_httpdWrite(wp, T("case 4:\n"));
		for (i = 0; i < numEntries; i++) {
#if 0
			if (ltq_mapi_get_wlan_vendor(wlMain[i].radioCpeId, IFX_F_DEFAULT) ==
				LTQ_MAPI_WLAN_VENDOR_WAVE300) {
#endif
				ifx_httpdWrite(wp, T("if(apIndex == %d)\n{\n"), (i + 1));
				ifx_httpdWrite(wp, T("wpsEna = "
					"Number(document.tF0.wpsEna%d.value);\n"), i + 1);
				ifx_httpdWrite(wp, T("oprMode = "
					"Number(document.tF0.radioOperMode%d.value);\n"), i + 1);
				ifx_httpdWrite(wp, T("document.tF0.authType.options[0] = "
					"new Option(authTypeArray[1][0], \"2\");\n"));
				ifx_httpdWrite(wp, T("document.tF0.authType.options[1] = "
					"new Option(authTypeArray[1][1], \"3\");\n"));
				ifx_httpdWrite(wp, T("document.tF0.authType.length = "
					"authTypeArray[1].length;\n"));
				/*
					* wlAuth < IFX_MAPI_WLAN_AUTH_RADIUS: this means that beaconType has
					* changed; in this case we choose the first of the two new
					* options as selected; otherwise the same as before is selected
					*/
				if (wlSec[i].wlAuth < IFX_MAPI_WLAN_AUTH_RADIUS)
					ifx_httpdWrite(wp,
						T("document.tF0.authType.options[1].selected = true;\n"));
				else
					ifx_httpdWrite(wp,
						T("document.tF0.authType.options[%d].selected = true;\n"),
						(wlSec[i].wlAuth - IFX_MAPI_WLAN_AUTH_RADIUS));

				/*
					* For 802.11N, BGN, AN, GN mode only CCMP is supported
					* if debug == ALL, then if clause is zero and code is not executed
					* hence no restriction for any .11n modes are written to web page
					*/
				if (gstrcmp(debug, T("ALL"))) {
					IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetSecurityConfiguration", "");
//					ifx_httpdWrite(wp, T("if(oprMode >= 4) {\n"));
					/* Only show TKIP_CCMP if beaconType = WPA-WPA2 */
					ifx_httpdWrite(wp,
						T("if(document.tF0.beaconType.value == 3) {\n"));
					ifx_httpdWrite(wp,
						T("document.tF0.encrType.options[0] = "
						"new Option(encryType[4][0], \"4\");\n"));
					/* Only show TKIP for beaconType = WPA */
					ifx_httpdWrite(wp,
						T("} else if(document.tF0.beaconType.value == 1) {\n"));
					ifx_httpdWrite(wp, T("document.tF0.encrType.options[0] = "
						"new Option(encryType[2][0], \"2\");\n"));
					/* Only show CCMP for other beacon types */
					ifx_httpdWrite(wp, T("} else {\n\t"));
					ifx_httpdWrite(wp, T("document.tF0.encrType.options[0] = "
						"new Option(encryType[3][0], \"3\");\n"));
					ifx_httpdWrite(wp, T("}\n"));
					ifx_httpdWrite(wp, T("document.tF0.encrType.length= 1;\n\t\t"));
					ifx_httpdWrite(wp,
						T("document.tF0.encrType.options[0].selected = true;\n"));
					ifx_httpdWrite(wp, T("}\n\t"));

					/* For all legacy modes TKIP, CCMP and TKIP-CCMP must be supported */
//					ifx_httpdWrite(wp, T("} else { \n\t"));
				} else {
					ifx_httpdWrite(wp, T("document.tF0.encrType.options[0]=new "
						"Option(encryType[2][0], \"2\");\n\t\t\t\t\t"));
					ifx_httpdWrite(wp, T("document.tF0.encrType.options[1]=new "
						"Option(encryType[3][0], \"3\");\n\t\t\t\t\t"));
					ifx_httpdWrite(wp, T("document.tF0.encrType.options[2]=new "
						"Option(encryType[4][0], \"4\");\n\t\t\t\t\t"));
					ifx_httpdWrite(wp, T("document.tF0.encrType.length=3;\n"));
					if (wlSec[i].wlEncr < IFX_MAPI_WLAN_ENCR_TKIP)
						ifx_httpdWrite(wp, T("document.tF0.encrType.options[0].selected "
							"= true;\n\t\t}\n"));
					else
						ifx_httpdWrite(wp, T("document.tF0.encrType.options[%d].selected "
							"= true;\n\t\t}\n"),
							(wlSec[i].wlEncr - IFX_MAPI_WLAN_ENCR_TKIP));
				}
				/* closing bracket for debug code above */
//				if (gstrcmp(debug, T("ALL")))
//					ifx_httpdWrite(wp, T("}\n"));
#if 0
			} else {
				ifx_httpdWrite(wp,
							T
							("if(apIndex == %d)\n\t\t\t\t{\n\t\t\t\t\t"),
							(i + 1));
				ifx_httpdWrite(wp,
							T
							("document.tF0.authType.options[0]=new Option(authTypeArray[1][0], \"2\");\n\t\t\t\t\t"));
				ifx_httpdWrite(wp,
							T
							("document.tF0.authType.options[1]=new Option(authTypeArray[1][1], \"3\");\n\t\t\t\t\t"));
				ifx_httpdWrite(wp,
							T
							("document.tF0.authType.length=authTypeArray[1].length;\n\t\t\t\t\t"));
				/*
					wlAuth < IFX_MAPI_WLAN_AUTH_RADIUS: this means that beaconType
					has changed; in this case we choose the first of the two new
					options as selected; otherwise the same as before is selected */
				if (wlSec[i].wlAuth < IFX_MAPI_WLAN_AUTH_RADIUS)
					ifx_httpdWrite(wp,
								T
								("document.tF0.authType.options[0].selected = true;\n\t\t\t\t"));
				else
					ifx_httpdWrite(wp,
								T
								("document.tF0.authType.options[%d].selected = true;\n\t\t\t\t"),
								(wlSec[i].wlAuth -
							IFX_MAPI_WLAN_AUTH_RADIUS));

				ifx_httpdWrite(wp,
							T
							("document.tF0.encrType.options[0]=new Option(encryType[2][0], \"2\");\n\t\t\t\t\t"));
				ifx_httpdWrite(wp,
							T
							("document.tF0.encrType.options[1]=new Option(encryType[3][0], \"3\");\n\t\t\t\t\t"));
				ifx_httpdWrite(wp,
							T
							("document.tF0.encrType.options[2]=new Option(encryType[4][0], \"4\");\n\t\t\t\t\t"));
				ifx_httpdWrite(wp,
							T
							("document.tF0.encrType.length=3;\n\t\t\t\t\t"));
				/*
					wlEncr < IFX_MAPI_WLAN_ENCR_TKIP: this means that beaconType has
					changed; in this case we chosse the first of the two new options
					as selected; otherwise the same as before is selected; */
				if (wlSec[i].wlEncr < IFX_MAPI_WLAN_ENCR_TKIP)
					ifx_httpdWrite(wp,
								T
								("document.tF0.encrType.options[0].selected = true;\n\t\t\t\t\t}\n\t\t\t"));
				else
					ifx_httpdWrite(wp,
								T
								("document.tF0.encrType.options[%d].selected = true;\n\t\t\t\t}\n\t\t\t\t"),
								(wlSec[i].wlEncr -
							IFX_MAPI_WLAN_ENCR_TKIP));
			}
#endif
		}
		ifx_httpdWrite(wp, T("break;\n"));
		ifx_httpdWrite(wp, T("default:\n"));
		ifx_httpdWrite(wp, T("alert(\"updateAvailableOptions: "
			"Beacon Type invalid\");\n"));
		ifx_httpdWrite(wp, T("return;\n}\n"));
	}
IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetSecurityConfiguration", "");
	IFX_MEM_FREE(wlMain);
	IFX_MEM_FREE(wlSec);
	return ret;
}

/**
   This function gets information required to display a list of available AP/VAP
   used from multiple web pages.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int IFX_WLAN_GetApList(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 ret = IFX_SUCCESS, i;
	char8 *name = NULL, quotedSsid[2*IFX_MAPI_WLAN_SSID_LEN];
	IFX_MAPI_WLAN_MainCfg *wlMain = NULL;
	uint32 numEntries = 0;

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetApList", "");

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return IFX_FAILURE;
	}

	/*
		we pass flag IFX_F_RESET_WEB_CFG to indicate to MAPI that main
		config has been read from web
	*/
	if (ifx_mapi_get_all_wlan_main_config(&numEntries, &wlMain,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get all wlan main config\n"));
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetApList", "numEntries: %d", numEntries);

	if (!gstrcmp(name, T("AP_LIST"))) {
		ifx_httpdWrite(wp,
			       T
			       ("<td width=\"40%\">Select AP/VAP name</td>\n"));
		ifx_httpdWrite(wp,
			       T
			       ("<td width=\"60%\"><select name='apName' onChange='updatePage();'>\n"));
		for (i = 0; i < numEntries; i++) {
			ifx_httpdWrite(wp, T("<option value='%s' %s "),
				       wlMain[i].apName,
				       i == 0 ? "selected" : "");
			ifx_httpdWrite(wp, T(">%s\n"), wlMain[i].apName);
		}
		ifx_httpdWrite(wp, T("</select></td>\n"));

		ifx_httpdWrite(wp, T("</tr>\n"));

		for (i = 0; i < numEntries; i++) {
			/* single quote ' and double quote " in SSID must be quoted */
			memset(quotedSsid, 0x00, sizeof(quotedSsid));
			ltq_wlan_add_quoting_2_string(wlMain[i].ssid, quotedSsid);
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetApList",
				"quotedSsid: %s", quotedSsid);
			ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"ssid%d\" "
				"value=\"\">\n"), i + 1);
			ifx_httpdWrite(wp, T("<script type=\"text/javascript\">"
				"document.tF0.ssid%d.value='%s';</script>\n"),
				i + 1, quotedSsid);
		}
		ifx_httpdWrite(wp, T("<tr>\n"));
		ifx_httpdWrite(wp, T("<td>SSID</td>\n"));
		ifx_httpdWrite(wp, T("<td>\n"));
		ifx_httpdWrite(wp, T("<input name='ssid' size='30' value='' "
			"disabled>\n"));
		ifx_httpdWrite(wp, T("</td>\n"));
	} else if (!gstrcmp(name, T("AP_LIST_FOR_MAC_PAGE"))) {
		ifx_httpdWrite(wp,
			       T("<td width=\"40%\">Select AP/VAP name</td>"));
		ifx_httpdWrite(wp,
			       T
			       ("<td width='60%'><select name='apName' onChange='updatePage();'>"));
		for (i = 0; i < numEntries; i++) {
			ifx_httpdWrite(wp, T("<option value='%s' %s "), wlMain[i].apName,
				i == 0 ? "selected" : "");
			ifx_httpdWrite(wp, T(">%s"), wlMain[i].apName);
		}
		ifx_httpdWrite(wp, T("</select></td>"));
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetApList", "");
	IFX_MEM_FREE(wlMain);
	return ret;
}

/**
   This function gets information required to display the web page for "WLAN MAC
   Control" properly. It is called from wlan_mac_control.asp.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int
IFX_WLAN_GetGlobalMacControlStatus(int eid, httpd_t wp, int argc,
				   char_t ** argv)
{
	IFX_MAPI_GlobalMacControl *gWlMacCntrl;
	int32 ret = IFX_SUCCESS;
	uint32 flags = IFX_F_DEFAULT, nEntries = 0;
	char8 *name;

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetGlobalMacControlStatus", "");

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) > 0) {
		ifx_httpdError(wp, 400, T("Invalid number of args\n"));
		return -1;
	}

	/* get WLAN MAC control list */
	if ((ret =
	     ifx_mapi_get_all_global_mac_control_entries(&nEntries,
							 &gWlMacCntrl,
							 flags) !=
	     IFX_SUCCESS)) {
		ifx_httpdError(wp, 400,
			       "Failed to get global mac control list");
		return ret;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetGlobalMacControlStatus",
		       "nEntries: %d", nEntries);

	ifx_httpdWrite(wp,
		       T
		       ("<td><font class=\"subtitle\"><input type=\"radio\" name=\"mac_control_status\" value="));
	ifx_httpdWrite(wp, T("%d"), IFX_MAPI_MACADDR_CONTROL_DISABLE);
	if (gWlMacCntrl)
		if ((gWlMacCntrl + 0)->cntrlMode ==
		    IFX_MAPI_MACADDR_CONTROL_DISABLE)
			ifx_httpdWrite(wp, T(" checked"));
	ifx_httpdWrite(wp, T(">Disable</td>"));

	ifx_httpdWrite(wp,
		       T
		       ("<td><font class=\"subtitle\"><input type=\"radio\" name=\"mac_control_status\" value="));
	ifx_httpdWrite(wp, T("%d"), IFX_MAPI_MACADDR_CONTROL_ALLOW);
	if (gWlMacCntrl)
		if ((gWlMacCntrl + 0)->cntrlMode ==
		    IFX_MAPI_MACADDR_CONTROL_ALLOW)
			ifx_httpdWrite(wp, T(" checked"));
	ifx_httpdWrite(wp, T(">Allow</td>"));

	ifx_httpdWrite(wp,
		       T
		       ("<td><font class=\"subtitle\"><input type=\"radio\" name=\"mac_control_status\" value="));
	ifx_httpdWrite(wp, T("%d"), IFX_MAPI_MACADDR_CONTROL_DENY);
	if (gWlMacCntrl)
		if ((gWlMacCntrl + 0)->cntrlMode ==
		    IFX_MAPI_MACADDR_CONTROL_DENY)
			ifx_httpdWrite(wp, T(" checked"));
	ifx_httpdWrite(wp, T(">Deny</td>"));

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetGlobalMacControlStatus", "ret: %d",
		       ret);
	IFX_MEM_FREE(gWlMacCntrl);
	return ret;
}

/**
   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void
ltq_wlan_get_all_mac_filter_config(int eid, httpd_t wp, int argc,
				   char_t ** argv)
{
	IFX_MAPI_WLAN_MAC_Control *wlMacControl = NULL;
	IFX_MAPI_WLAN_AssocInfo *wlAssocInfo = NULL;
	int32 i, j, staCount[LTQ_MAX_NUM_VAP];
	uint32 mainCpeId = 0, macCount = 0;
	IFX_MAPI_WLAN_MainCfg *wlMain = NULL;
	uint32 numEntries = 0;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_all_mac_filter_config", "");

	/*
		we pass flag IFX_F_RESET_WEB_CFG to indicate to MAPI that main
		config has been read from web
	*/
	if (ifx_mapi_get_all_wlan_main_config(&numEntries, &wlMain,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get all wlan main config\n"));
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_all_mac_filter_config", "numEntries: %d", numEntries);

	ifx_httpdWrite(wp, T("<input type='hidden' name='connIp' value='%s'>\n"),
		wp->ipaddr);
	ifx_httpdWrite(wp, T("<input type='hidden' name='numAclEntries' "
		"value='0'>\n"));

	/* store all ap/vap parameters in hidden variables */
	for (i = 0; i < numEntries; i++) {
		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"wpsEna%d\" value=\"\">"), i);
		ifx_httpdWrite(wp, T("<script type=\"text/javascript\">"
			"document.tF0.wpsEna%d.value='%d';</script>\n"),
			i, wlMain[i].WPSena);
		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"macAclMode%d\" "
			"value=\"\">\n"), i);
		ifx_httpdWrite(wp, T("<script type=\"text/javascript\">"
			"document.tF0.macAclMode%d.value = %d;</script>\n"),
			i, g_wlSec[i].macAddrCntrlEna);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_all_mac_filter_config",
			"macAclMode%d: %d", i, g_wlSec[i].macAddrCntrlEna);

		mainCpeId = g_wlSec[i].iid.cpeId.Id;
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_all_mac_filter_config",
			"mainCpeId: %d", mainCpeId);
		/*
		 * get the mac filter configuration
		 */
		if (ifx_mapi_get_all_wlan_mac_control_entries(mainCpeId, &macCount,
			&wlMacControl, IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,T("Failed to get wlan mac control table"));
			goto LTQ_Handler;
		}
		/* store the number of MAC filter entries in global variable */
		gMacCount[i] = macCount;
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_all_mac_filter_config",
			"MAC address entries: %d", macCount);

		if (macCount <= LTQ_MAX_NUM_MAC_FILTER_ENTRIES)
			memcpy(&g_wlMacControl[i][0], wlMacControl,
			       sizeof(IFX_MAPI_WLAN_MAC_Control) * macCount);

		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"numAclEntries_%d\" "
			"value=\"%d\">\n"), i, macCount);
		for (j = 0; j < g_wlCaps[0].numMacCntrlEntries; j++) {
			ifx_httpdWrite(wp, T("<input type=\"hidden\" "
				"name=\"macAddr_%d_%d\" value=\"\">\n"), i + 1, j + 1);
			if (j < macCount) {
				IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_all_mac_filter_config",
					"MAC address: %s", (wlMacControl + j)->macAddr);
				ifx_httpdWrite(wp, T("<script type=\"text/javascript\">"
					"document.tF0.macAddr_%d_%d.value='%s';</script>\n"),
					i + 1, j + 1, (wlMacControl + j)->macAddr);
			} else {
				ifx_httpdWrite(wp, T("<script type=\"text/javascript\">"
					"document.tF0.macAddr_%d_%d.value='';</script>\n"),
					i + 1, j + 1);
			}
		}
	}

	/*
	 *  get mac addresses of associated stations: required to prevent
	 *  adding mac of station currently configuring device to black list */
	for (i = 0; i < numEntries; i++) {
		mainCpeId = wlMain[i].iid.cpeId.Id;
		j = 0;
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_all_mac_filter_config",
			"mainCpeId: %d", mainCpeId);
		memset(staCount, 0x00, sizeof(staCount));
		if (ifx_mapi_get_all_wlan_assoc_devices(mainCpeId,
			(uint32 *) &staCount[i], &wlAssocInfo, IFX_F_DEFAULT) !=
			IFX_SUCCESS) {
			IFX_MEM_FREE(wlAssocInfo);
			ifx_httpdError(wp, 500, T("Failed to get associated device list"));
			goto LTQ_Handler;
		}

		ifx_httpdWrite(wp, T("<input type='hidden' name='numAssocSta_%d' "
			"value='%d'>\n"), i, staCount[i]);
		ifx_httpdWrite(wp, T("<input type='hidden' "
			"name='isAssocMacAddr_%d' value='0'>\n"), i);
		if (staCount[i] < 1) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_all_mac_filter_config", "");
		} else {
			/* MAC address */
			for (j = 0; j < staCount[i]; j++) {
				if (!(strcmp(wp->ipaddr,(char *)inet_ntoa((wlAssocInfo + j)->ipAddress)))) {
					IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_all_mac_filter_config",
						"connectionIP found in associated device list");
					ifx_httpdWrite(wp, T("<input type='hidden' name='assocIp' "
						"value='%s'>\n"), (char *)inet_ntoa((wlAssocInfo + j)->ipAddress));
					ifx_httpdWrite(wp, T("<input type='hidden' name='assocMacAddr' "
						"value='%s'>\n"), (wlAssocInfo + j)->macAddress);

					ifx_httpdWrite(wp, T("<script language=\"JavaScript\">\n"));
					ifx_httpdWrite(wp, T("document.tF0.isAssocMacAddr_%d.value = 1;\n"), i);
					ifx_httpdWrite(wp, T("</script>\n"));
				}
			}
		}
	}
	IFX_MEM_FREE(wlAssocInfo);

LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_all_mac_filter_config", "");
	IFX_MEM_FREE(wlMacControl);
	IFX_MEM_FREE(wlMain);
	return;
}

/**
   This function is called from wlan_mac_control.asp.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void ltq_prepare_mac_delete(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 i;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_prepare_mac_delete", "numMacCntrlEntries: %d",
		g_wlCaps[0].numMacCntrlEntries);

	if ((g_wlCaps[0].numMacCntrlEntries > LTQ_MAX_NUM_MAC_FILTER_ENTRIES) ||
		(g_wlCaps[0].numMacCntrlEntries == 0)) {
		g_wlCaps[0].numMacCntrlEntries = LTQ_MAX_NUM_MAC_FILTER_ENTRIES;
	}

	for (i = 0; i < g_wlCaps[0].numMacCntrlEntries; i++) {
		ifx_httpdWrite(wp,
			       T
			       ("\tif (document.tF0.rmid%d.checked == true) {\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("\t\tif (document.tF0.mac_control_status[1].checked == true) {\n"));
		ifx_httpdWrite(wp, T("\t\t\tif (isAssocMacAddr == 1) {\n"));
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t\tif (document.tF0.assocMacAddr.value == document.tF0.macAddr_%d.value) {\n"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t\t\tif (!(confirm('You have selected the MAC address of the device which is currently connected to this AP/VAP.\\nIf you continue you will remove this MAC address from the list of devices which are allowed to connect to the AP.\\nAs a consequence you will be disconnected from the AP/VAP.\\nDo you really want to continue\?\?\?')))\n"));
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t\t\t\treturn true;\n\t\t\t\t}\t\t\t}\t\t}"));
		ifx_httpdWrite(wp, T("\t\tnDelEntries++;\n\t}"));
	}
}

/**
   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void ltq_get_check_mac_add(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 i = 0, k = 0;

	/* validate correctness of MAC in each row */
	for (i = 0; i < g_wlCaps[0].numMacCntrlEntries; i++) {
		ifx_httpdWrite(wp, T("if(isNValidmac(document.tF0.macAddr_%d.value)) {\n\t"), i + 1);
		ifx_httpdWrite(wp, T ("alert(\"Please input valid MAC address to all field\");\n"));
		ifx_httpdWrite(wp, T("return false;\n}\n"));
		ifx_httpdWrite(wp, T("else if (!isBlank(document.tF0.macAddr_%d.value)){\n"), i + 1);
		ifx_httpdWrite(wp, T("nMacTableEntries++;\n}\n"));
	}

	if ((g_wlCaps[0].numMacCntrlEntries > LTQ_MAX_NUM_MAC_FILTER_ENTRIES) ||
		(g_wlCaps[0].numMacCntrlEntries == 0)) {
		g_wlCaps[0].numMacCntrlEntries = LTQ_MAX_NUM_MAC_FILTER_ENTRIES;
	}

	for (i = 0; i < g_wlCaps[0].numMacCntrlEntries; i++) {
		ifx_httpdWrite(wp, T("\tif( (!isBlank(document.tF0.macAddr_%d.value))) {\n"), i+1);
		for (k = i + 1; k < g_wlCaps[0].numMacCntrlEntries; k++) {
			ifx_httpdWrite(wp, T("\tif( (document.tF0.macAddr_%d.value == "
				"document.tF0.macAddr_%d.value)) {\n"),
				i + 1, k + 1);

			ifx_httpdWrite(wp, T ("\t\talert(\"Same MAC address entered twice. "
				"Please check fields: %d and %d\");\n"), i+1, k+1);
			ifx_httpdWrite(wp, T("\t\treturn false;\n\t}\n"));
		}
		ifx_httpdWrite(wp, T("\n\t}\n"));
	}
	return;
}

/**
   This function gets information required to display the web page for "WLAN MAC
   Control" properly. It is called from wlan_mac_control.asp.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int
IFX_WLAN_GetAllGlobalMacContrlEntries(int eid, httpd_t wp, int argc,
				      char_t ** argv)
{
	IFX_MAPI_GlobalMacControl *gWlMacCntrl;
	int32 ret = IFX_SUCCESS;
	uint32 flags = IFX_F_DEFAULT, numEntries = 0, i = 0;
	char_t *name = NULL;

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetAllGlobalMacContrlEntries", "");

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	if ((ret =
	     ifx_mapi_get_all_global_mac_control_entries(&numEntries,
							 &gWlMacCntrl,
							 flags)) !=
	    IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to get wlan mac control table");
		return ret;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetAllGlobalMacContrlEntries",
		       "numEntries: %d", numEntries);

	if (!gstrcmp(name, "mac_count")) {
		ifx_httpdWrite(wp, T("%d"), numEntries);
	} else if (!gstrcmp(name, "mac_entries")) {
		if (numEntries == 0) {
			ifx_httpdWrite(wp, T("<tr bgcolor='#ffffff'>"));
			ifx_httpdWrite(wp,
				       T
				       ("<td width='100%' colspan='2'><p align='center'>"));
			ifx_httpdWrite(wp,
				       T("No Rules Configured</p></td></tr>"));
		} else {
			for (i = 0; i < numEntries; i++) {
				ifx_httpdWrite(wp, T("<tr bgcolor='#ffffff'>"));	/* open
											   a
											   row */
				ifx_httpdWrite(wp,
					       T
					       ("<td><input type='hidden' name='cpeId%d' value='%d'>%s</td>"),
					       i,
					       (gWlMacCntrl + i)->iid.cpeId.Id,
					       (gWlMacCntrl + i)->macAddr);
				ifx_httpdWrite(wp,
					       T
					       ("<td><input type='checkbox' name='rmid%d' value=%d></td>"),
					       i,
					       (gWlMacCntrl + i)->iid.cpeId.Id);
				ifx_httpdWrite(wp, T("</tr>"));	/* closing a row */
			}
		}
	}

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetAllGlobalMacContrlEntries",
		"ret: %d", ret);
	IFX_MEM_FREE(gWlMacCntrl);
	return ret;
}

/**
   This function gets information required to display the web page for "WLAN MAC
   Control" properly. It is called from wlan_mac_control.asp.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int IFX_WLAN_GetMacControl(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 ret = IFX_SUCCESS, i, j;
	static int32 staCount[LTQ_MAX_NUM_VAP];
	IFX_MAPI_WLAN_AssocInfo *wlAssocInfo = NULL;
	uint32 mainCpeId = 0;
	IFX_MAPI_WLAN_MAC_Control *wlMacControl = NULL;
	char_t *name = NULL, *cpeId = NULL;
	IFX_MAPI_WLAN_MainCfg *wlMain = NULL;
	uint32 numEntries = 0;

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetMacControl", "");

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name, &cpeId) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return IFX_FAILURE;
	}

	if (!gstrcmp(name, "MAC_COUNT")) {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetMacControl",
			       "numEntries: %d", gMacCount[0]);
		ifx_httpdWrite(wp, T("%d"), gMacCount[0]);
	} else if (!gstrcmp(name, "MAC_ENTRIES")) {
		for (i = 0; i < g_wlCaps[0].numMacCntrlEntries; i++) {
			ifx_httpdWrite(wp, T("<tr>\n\t"));	/* open a row */
			if (i < gMacCount[0]) {
				ifx_httpdWrite(wp,
					       T
					       ("<td><input name='macAddr_%d' value='%s' disabled></td>\n\t"),
					       i + 1,
					       g_wlMacControl[0][i].macAddr);
				ifx_httpdWrite(wp,
					       T
					       ("<td><input type='checkbox' name='rmid%d' value=1></td>\n\t"),
					       i);
			} else {
				ifx_httpdWrite(wp,
					       T
					       ("<td><input name='macAddr_%d' value='' disabled></td>\n\t"),
					       i + 1);
				ifx_httpdWrite(wp,
					       T
					       ("<td><input type='checkbox' name='rmid%d' value=1 disabled></td>\n\t"),
					       i);
			}
			ifx_httpdWrite(wp, T("</tr>\n\n"));	/* closing a row */
		}
	} else if (!gstrcmp(name, "MAC_CONFIGURATION")) {
		/*
			we pass flag IFX_F_RESET_WEB_CFG to indicate to MAPI that main
			config has been read from web
		*/
		if (ifx_mapi_get_all_wlan_main_config(&numEntries, &wlMain,
			IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400, T("Failed to get all wlan main config\n"));
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetMacControl", "numEntries: %d", numEntries);

		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetMacControl", "ipAddr: %s", wp->ipaddr);
		ifx_httpdWrite(wp, T("<input type='hidden' name='connIp' value='%s'>\n"),
			wp->ipaddr);

		ifx_httpdWrite(wp, T("\t<script language=\"JavaScript\">\n"));
		ifx_httpdWrite(wp,
			       T("\t\tswitch (window.location.search) {\n"));
		for (i = 0; i < numEntries; i++) {
			ifx_httpdWrite(wp, T("\t\t\tcase \"?ap%d\":\n"), i + 1);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\tdocument.tF0.apIndex.value = %d;\n"),
				       i);

			ifx_httpdWrite(wp, T("\t\t\t\tdocument.write(\""));
			ifx_httpdWrite(wp,
				       T
				       ("<input type='hidden' name='aclMode' value='%d'>"),
				       g_wlSec[i].macAddrCntrlEna);
			ifx_httpdWrite(wp, T("\t\t\t\t\");\n"));

			ifx_httpdWrite(wp, T("\t\t\t\tdocument.write(\""));
			for (j = 0; j < g_wlCaps[0].numMacCntrlEntries; j++) {
				if (j < gMacCount[i]) {
					ifx_httpdWrite(wp,
						       T
						       ("<input type='hidden' name='macAddr_%d' value='%s'>"),
						       j + 1,
						       g_wlMacControl[i][j].
						       macAddr);
				} else {
					ifx_httpdWrite(wp,
						       T
						       ("<input type='hidden' name='macAddr_%d' value=''>"),
						       j + 1);
				}
			}
			ifx_httpdWrite(wp, T("\t\t\t\t\");\n"));
			ifx_httpdWrite(wp, T("\t\t\t\tbreak;\n"));
		}
		ifx_httpdWrite(wp, T("\t\t\tdefault:\n"), i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t\talert(\"default \" + window.location.search);\n"));
		ifx_httpdWrite(wp, T("\t\t\t\tbreak;\n"));
		ifx_httpdWrite(wp, T("\t}</script>\n"));

		/* get mac addresses of associated stations: required to prevent adding
		   mac of station currently configuring device to black list */
		for (i = 0; i < numEntries; i++) {
			mainCpeId = wlMain[i].iid.cpeId.Id;
			j = 0;
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetMacControl",
				       "mainCpeId: %d", mainCpeId);
			memset(staCount, 0x00, sizeof(staCount));
			if ((ret =
			     ifx_mapi_get_all_wlan_assoc_devices(mainCpeId,
					(uint32 *) &staCount[i], &wlAssocInfo, IFX_F_DEFAULT)) !=
					IFX_SUCCESS) {
				IFX_MEM_FREE(wlAssocInfo);
				ifx_httpdError(wp, 500,
					       T
					       ("Failed to get associated device list"));
				goto IFX_Handler;
			}
			ifx_httpdWrite(wp,
				       T
				       ("<input type='hidden' name='numAssocSta_%d' value='%d'>\n"),
				       i, staCount[i]);

			if (staCount[i] < 1) {
				IFX_MAPI_DEBUG(fd,
					       "/tmp/IFX_WLAN_GetMacControl",
					       "");
	    /**
               \todo
            */
			} else {
				IFX_MAPI_DEBUG(fd,
					       "/tmp/IFX_WLAN_GetMacControl",
					       "");
	    /**
               \todo
            */

				/* MAC address */
				for (j = 0; j < staCount[i]; j++) {
					ifx_httpdWrite(wp,
						       T
						       ("<input type='hidden' name='assocMacAddr_%d_%d' value='%s'>\n"),
						       i, j,
						       (wlAssocInfo +
							j)->macAddress);
				}

				/* IP address */
				for (j = 0; j < staCount[i]; j++) {
					ifx_httpdWrite(wp,
						       T
						       ("<input type='hidden' name='assocIp_%d_%d' value='%s'>\n"),
						       i, j,
						       (char_t *)
						       inet_ntoa((wlAssocInfo +
								  j)->
								 ipAddress));
				}
			}
		}
		IFX_MEM_FREE(wlAssocInfo);
	} else if (!gstrcmp(name, "MAC_STATUS")) {
		ifx_httpdWrite(wp,
			       T
			       ("<td><input type=\"radio\" name=\"mac_control_status\" value="));
		ifx_httpdWrite(wp, T("%d"), IFX_MAPI_MACADDR_CONTROL_DISABLE);
		if (g_wlSec[0].macAddrCntrlEna ==
		    IFX_MAPI_MACADDR_CONTROL_DISABLE)
			ifx_httpdWrite(wp, T(" checked"));

		ifx_httpdWrite(wp, T(">Disable</td>"));

		ifx_httpdWrite(wp,
			       T
			       ("<td><input type=\"radio\" name=\"mac_control_status\" value="));
		ifx_httpdWrite(wp, T("%d"), IFX_MAPI_MACADDR_CONTROL_ALLOW);
		if (g_wlSec[0].macAddrCntrlEna ==
		    IFX_MAPI_MACADDR_CONTROL_ALLOW)
			ifx_httpdWrite(wp, T(" checked"));

		ifx_httpdWrite(wp, T(">Allow</td>"));

		ifx_httpdWrite(wp,
			       T
			       ("<td><input type=\"radio\" name=\"mac_control_status\" value="));
		ifx_httpdWrite(wp, T("%d"), IFX_MAPI_MACADDR_CONTROL_DENY);
		if (g_wlSec[0].macAddrCntrlEna == IFX_MAPI_MACADDR_CONTROL_DENY)
			ifx_httpdWrite(wp, T(" checked"));

		ifx_httpdWrite(wp, T(">Deny</td>"));
		ifx_httpdWrite(wp, T("<td></td>"));
	} else if (!gstrcmp(name, "UPDATE_PAGE")) {
		for (i = 0; i < gNumEntries; i++) {
			ifx_httpdWrite(wp, T("case %d:\n"), i);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.apIndex.value = %d;\n"),
				       i + 1);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tif (document.tF0.macAclMode%d.value == 0) {\n"),
				       i);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.mac_control_status[0].checked = false;\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.mac_control_status[1].checked = true;\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.mac_control_status[2].checked = false;}\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\telse if (document.tF0.macAclMode%d.value == 1) {\n"),
				       i);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.mac_control_status[0].checked = false;\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.mac_control_status[1].checked = false;\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.mac_control_status[2].checked = true;}\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\telse if (document.tF0.macAclMode%d.value == 2) {\n"),
				       i);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.mac_control_status[0].checked = true;\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.mac_control_status[1].checked = false;\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.mac_control_status[2].checked = false;}\n"));

			for (j = 1; j <= 8; j++)
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\tdocument.getElementById('mac%d').style.display = 'none';\n"),
					       j);

			if (gMacCount[i] > 0)
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\tdocument.getElementById('mac%d').style.display = '';\n"),
					       2 * i + 1);
			else
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\tdocument.getElementById('mac%d').style.display = '';\n"),
					       2 * i + 2);

			for (j = 0; j < g_wlCaps[0].numMacCntrlEntries; j++) {
				if (j < gMacCount[i]) {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\tdocument.tF0.rmid%d.disabled = false;\n"),
						       j);
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\tdocument.tF0.macAddr_%d.value = document.tF0.macAddr_%d_%d.value;\n"),
						       j + 1, i + 1, j + 1);
				}
				else {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\tdocument.tF0.rmid%d.disabled = true;\n"),
						       j);
				}
			}
			ifx_httpdWrite(wp, T("\t\t\tbreak;\n"));
		}
	}
IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetMacControl", "ret: %d", ret);
	IFX_MEM_FREE(wlMacControl);
	IFX_MEM_FREE(wlMain);
	return ret;
}

/**
   This function gets information required to display the web page for "WLAN MAC
   Control" properly. It is called from wlan_mac_control.asp.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int ltq_wlan_update_mac_table(int eid, httpd_t wp, int argc, char_t ** argv)
{
	uint32 i = 0, j = 0, numEntries = 0;
	IFX_MAPI_WLAN_MainCfg *wlMain = NULL;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_update_mac_table", "");
	/*
		we pass flag IFX_F_RESET_WEB_CFG to indicate to MAPI that main
		config has been read from web
	*/
	if (ifx_mapi_get_all_wlan_main_config((uint32 *) &numEntries, &wlMain,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get all wlan main config\n"));
		goto LTQ_Handler;
	}

	/* for all AP and VAP get the mode and */
	for (i = 0; i < numEntries; i++) {
		ifx_httpdWrite(wp, T("case %d:\n"), i);
		ifx_httpdWrite(wp, T("document.tF0.apIndex.value = %d;\n"), i);
		ifx_httpdWrite(wp, T("\tdocument.tF0.wlan_vendor_vap.value = "
			"document.tF0.wlan_vendor_vap_%d.value;\n"), i);
		ifx_httpdWrite(wp, T("document.tF0.radioCpeId.value=\"%d\";\n"),
			wlMain[i].radioCpeId);
		ifx_httpdWrite(wp, T("document.tF0.numAclEntries.value = "
			"document.tF0.numAclEntries_%d.value;\n"), i);
		ifx_httpdWrite(wp, T("if (document.tF0.macAclMode%d.value == 0) {\n"), i);
		ifx_httpdWrite(wp, T("document.tF0.mac_control_status[0].checked "
			"= false;\n"));
		ifx_httpdWrite(wp, T("document.tF0.mac_control_status[1].checked = "
			"true;\n"));
		ifx_httpdWrite(wp, T("document.tF0.mac_control_status[2].checked = "
			"false;\n"));
		for (j = 0; j < g_wlCaps[0].numMacCntrlEntries; j++) {
			ifx_httpdWrite(wp, T("document.tF0.macAddr_%d.disabled = "
				"false;\n"), j + 1);
		}
		ifx_httpdWrite(wp, T("}\n"));
		ifx_httpdWrite(wp, T("else if (document.tF0.macAclMode%d.value == 1) "
			"{\n"), i);
		ifx_httpdWrite(wp, T("document.tF0.mac_control_status[0].checked = "
			"false;\n"));
		ifx_httpdWrite(wp, T("document.tF0.mac_control_status[1].checked = "
			"false;\n"));
		ifx_httpdWrite(wp, T("document.tF0.mac_control_status[2].checked = "
			"true;\n"));
		for (j = 0; j < g_wlCaps[0].numMacCntrlEntries; j++) {
			ifx_httpdWrite(wp, T("document.tF0.macAddr_%d.disabled = "
				"false;\n"), j + 1);
		}
		ifx_httpdWrite(wp, T("}\n"));
		ifx_httpdWrite(wp, T("else if (document.tF0.macAclMode%d.value == 2) "
			"{\n"), i);
		ifx_httpdWrite(wp, T("document.tF0.mac_control_status[0].checked = "
			"true;\n"));
		ifx_httpdWrite(wp, T("document.tF0.mac_control_status[1].checked = "
			"false;\n"));
		ifx_httpdWrite(wp, T("document.tF0.mac_control_status[2].checked = "
			"false;\n"));
		for (j = 0; j < g_wlCaps[0].numMacCntrlEntries; j++) {
			ifx_httpdWrite(wp, T("document.tF0.macAddr_%d.disabled = true;\n"),
				j + 1);
		}
		ifx_httpdWrite(wp, T("}\n"));

		for (j = 0; j < g_wlCaps[0].numMacCntrlEntries; j++) {
			if (j < gMacCount[i])
				ifx_httpdWrite(wp, T("document.tF0.rmid%d.disabled = "
				"false;\n"), j);
			else
				ifx_httpdWrite(wp, T("document.tF0.rmid%d.disabled = true;\n"),
				j);
		}

		for (j = 0; j < gMacCount[i]; j++)
			ifx_httpdWrite(wp, T("document.tF0.macAddr_%d.value = "
			"document.tF0.macAddr_%d_%d.value;\n"), j + 1, i + 1, j + 1);

		for (j = gMacCount[i]; j < g_wlCaps[0].numMacCntrlEntries; j++)
			ifx_httpdWrite(wp, T("document.tF0.macAddr_%d.value = \"\";\n"),
			j + 1);

		ifx_httpdWrite(wp, T("break;\n"));
	}
LTQ_Handler:
	IFX_MEM_FREE(wlMain);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_update_mac_table", "");
	return IFX_SUCCESS;
}

/**
   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int ltq_get_check_for_white_list(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 i;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_check_for_white_list", "numMac: %d",
		       g_wlCaps[0].numMacCntrlEntries);

	if (g_wlCaps[0].numMacCntrlEntries == 0)
		return IFX_FAILURE;

	ifx_httpdWrite(wp, T("if ("));
	for (i = 0; i < g_wlCaps[0].numMacCntrlEntries - 1; i++) {
		ifx_httpdWrite(wp,
			       T
			       ("(document.tF0.assocMacAddr.value != document.tF0.macAddr_%d.value) &&\n"),
			       i + 1);
	}
	i = g_wlCaps[0].numMacCntrlEntries - 1;
	ifx_httpdWrite(wp,
		       T
		       ("(document.tF0.assocMacAddr.value != document.tF0.macAddr_%d.value)) {\n\t"),
		       i + 1);
	ifx_httpdWrite(wp,
		       T
		       ("if (!(confirm('If you continue the specified Access Control List will operate as a White List.\\nThe MAC which is currently configuring this AP/VAP is not part of this Access Control List!!!\\nTherefore you will be disconnected from the AP/VAP.\\nDo you really want to continue\?\?\?')))\n"));
	ifx_httpdWrite(wp, T("return true;\n}"));

	return IFX_SUCCESS;
}

/**
   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int ltq_get_check_for_black_list(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 i;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_check_for_black_list", "numMac: %d",
		       g_wlCaps[0].numMacCntrlEntries);

	if (g_wlCaps[0].numMacCntrlEntries == 0)
		return IFX_FAILURE;

	ifx_httpdWrite(wp, T("if ("));
	for (i = 0; i < g_wlCaps[0].numMacCntrlEntries - 1; i++) {
		ifx_httpdWrite(wp,
			       T
			       ("(document.tF0.assocMacAddr.value == document.tF0.macAddr_%d.value) ||\n"),
			       i + 1);
	}
	i = g_wlCaps[0].numMacCntrlEntries - 1;
	ifx_httpdWrite(wp,
		       T
		       ("(document.tF0.assocMacAddr.value == document.tF0.macAddr_%d.value)) {\n\t"),
		       i + 1);
	ifx_httpdWrite(wp,
		       T
		       ("if (!(confirm('The MAC which is currently configuring this AP/VAP is part of this Access Control List.\\nIf you set the mode of the ACL to DENY, you will be disconnected from the AP/VAP.\\nDo you really want to continue\?\?\?')))\n"));
	ifx_httpdWrite(wp, T("return true;\n}"));

	return IFX_SUCCESS;
}

/**
   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int ltq_enable_all_fields(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 i;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_enable_all_fields", "");

	for (i = 0; i < g_wlCaps[0].numMacCntrlEntries; i++) {
		ifx_httpdWrite(wp,
			       T
			       ("\tdocument.tF0.macAddr_%d.disabled = false;\n"),
			       i + 1);
		ifx_httpdWrite(wp,
			       T("\tdocument.tF0.rmid%d.disabled = false;\n"),
			       i);
	}

	return IFX_SUCCESS;
}

/**
   This function gets information required to display the web page for "WLAN MAC
   Control" properly. It is called from wlan_mac_control.asp.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int IFX_WLAN_GetMacCount(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 ret = IFX_SUCCESS, i, j;
	char_t *name = NULL;
	struct timeval tv;

	gettimeofday(&tv, NULL);
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetMacCount", "%d:%d",
		       (int32) tv.tv_sec, (int32) tv.tv_usec);

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	if ((name) && !gstrcmp(name, "AP_INDEX")) {
		for (i = 0; i < gNumEntries; i++) {
			ifx_httpdWrite(wp, T("case %d:\n"), i);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.apIndex.value = %d;\n"),
				       i + 1);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tif (document.tF0.macAclMode%d.value == 0) {\n"),
				       i);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.mac_control_status[0].checked = false;\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.mac_control_status[1].checked = true;\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.mac_control_status[2].checked = false;}\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\telse if (document.tF0.macAclMode%d.value == 1) {\n"),
				       i);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.mac_control_status[0].checked = false;\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.mac_control_status[1].checked = false;\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.mac_control_status[2].checked = true;}\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\telse if (document.tF0.macAclMode%d.value == 2) {\n"),
				       i);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.mac_control_status[0].checked = true;\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.mac_control_status[1].checked = false;\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.mac_control_status[2].checked = false;}\n"));

			for (j = 1; j <= 8; j++)
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\tdocument.getElementById('mac%d').style.display = 'none';\n"),
					       j);

			if (gMacCount[i] > 0)
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\tdocument.getElementById('mac%d').style.display = '';\n"),
					       2 * i + 1);
			else
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\tdocument.getElementById('mac%d').style.display = '';\n"),
					       2 * i + 2);

			for (j = 0; j < g_wlCaps[0].numMacCntrlEntries; j++) {
				if (j < gMacCount[i])
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\tdocument.tF0.rmid%d.disabled = false;\n"),
						       j);
				else
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\tdocument.tF0.rmid%d.disabled = true;\n"),
						       j);
			}
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.macAddr_1.value = document.tF0.macAddr_%d_1.value;\n"),
				       i + 1);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.macAddr_2.value = document.tF0.macAddr_%d_2.value;\n"),
				       i + 1);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.macAddr_3.value = document.tF0.macAddr_%d_3.value;\n"),
				       i + 1);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.macAddr_4.value = document.tF0.macAddr_%d_4.value;\n"),
				       i + 1);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.macAddr_5.value = document.tF0.macAddr_%d_5.value;\n"),
				       i + 1);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.macAddr_6.value = document.tF0.macAddr_%d_6.value;\n"),
				       i + 1);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.macAddr_7.value = document.tF0.macAddr_%d_7.value;\n"),
				       i + 1);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\tdocument.tF0.macAddr_8.value = document.tF0.macAddr_%d_8.value;\n"),
				       i + 1);
			ifx_httpdWrite(wp, T("\t\t\tbreak;\n"));
		}
	}
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetMacCount", "ret: %d", ret);
	gettimeofday(&tv, NULL);
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetMacCount", "%d:%d",
		       (int32) tv.tv_sec, (int32) tv.tv_usec);
	return ret;
}

/**
   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void IFX_WLAN_GetStatistics(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name = NULL;
	IFX_MAPI_WLAN_Stats wlStats;
	IFX_MAPI_WLAN_PhyStats wlPhyStats;
	uint32 numEntries = 0, i;
	IFX_MAPI_WLAN_MainCfg *wlMain = NULL;

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetStatistics", "");

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdWrite(wp, T(""));
		return;
	}

	/*
		we pass flag IFX_F_RESET_WEB_CFG to indicate to MAPI that main
		config has been read from web
	*/
	if (ifx_mapi_get_all_wlan_main_config(&numEntries, &wlMain,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get all wlan main config\n"));
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetStatistics", "numEntries: %d", numEntries);

	if (!gstrcmp(name, T("STATS"))) {
		for (i = 0; i < numEntries; i++) {
			if (ltq_mapi_get_wlan_vendor((wlMain + i)->radioCpeId,
				IFX_F_DEFAULT) == LTQ_MAPI_WLAN_VENDOR_NONE) {
				continue;
			}
			memset(&wlStats, 0x00, sizeof(wlStats));
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetStatistics",
				"cpeId: %d, pCpeId: %d", (wlMain + i)->iid.cpeId.Id,
				(wlMain + i)->iid.pcpeId.Id);
			wlStats.iid.cpeId.Id = (wlMain + i)->iid.cpeId.Id;
			wlStats.iid.pcpeId.Id = (wlMain + i)->iid.pcpeId.Id;

			if (ifx_mapi_get_wlan_stats(&wlStats, IFX_F_DEFAULT) !=
			    IFX_SUCCESS) {
				ifx_httpdError(wp, 400, T("Failed to get wlan statistics\n\n"));
				goto IFX_Handler;
			}

			ifx_httpdWrite(wp, T("<tr align=\"center\">"));
			ifx_httpdWrite(wp, T("<td>"));
#ifdef CONFIG_FEATURE_LTQ_WIRELESS_VB
			ifx_httpdWrite(wp, T("wlan0"));
#else
			ifx_httpdWrite(wp, T("%s"), (wlMain + i)->apName);
#endif
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("<td>"));
			ifx_httpdWrite(wp,
				       T
				       ("<table border='0' width='100%' cellspacing=\"1\" cellpadding=\"0\" >"));
			ifx_httpdWrite(wp, T("<tr align=\"center\" >"));

			/* tx statistics */
			ifx_httpdWrite(wp, T("<td width='13%'>%lu</td>"),
				       wlStats.pktsTx);
			ifx_httpdWrite(wp, T("<td width='13%'>%lu</td>"),
				       wlStats.bytesTx);
			ifx_httpdWrite(wp, T("<td width='13%'>%lu</td>"),
				       wlStats.errorsTx);
			ifx_httpdWrite(wp, T("<td width='13%'>%lu</td>"),
				       wlStats.discardPktsTx);

			ifx_httpdWrite(wp, T("</tr>"));
			ifx_httpdWrite(wp, T("</table>"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("<td>"));
			ifx_httpdWrite(wp,
				       T
				       ("<table border='0' width='100%' cellspacing=\"1\" cellpadding=\"0\">"));
			ifx_httpdWrite(wp, T("<tr align=\"center\" >"));

			/* rx statistics */
			ifx_httpdWrite(wp, T("<td width='13%'>%lu</td>"),
				       wlStats.pktsRx);
			ifx_httpdWrite(wp, T("<td width='13%'>%lu</td>"),
				       wlStats.bytesRx);
			ifx_httpdWrite(wp, T("<td width='13%'>%lu</td>"),
				       wlStats.errorsRx);
			ifx_httpdWrite(wp, T("<td width='13%'>%lu</td>"),
				       wlStats.discardPktsRx);

			ifx_httpdWrite(wp, T("</tr>"));
			ifx_httpdWrite(wp, T("</table>"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("</tr>"));
		}
	}

	if (!gstrcmp(name, T("VB_STATS_DETAILS"))) {
		for (i = 0; i <= 1; i++) {
			ifx_httpdWrite(wp, T("<th>\n"));
			ifx_httpdWrite(wp, T("<table cellspacing=\"1\" cellpadding=\"0\">\n"));
			ifx_httpdWrite(wp, T("<tr>\n"));
			if (i == 0)
				ifx_httpdWrite(wp, T("<th width=\"25%\" align=\"center\">TX</th>\n"));
			else
				ifx_httpdWrite(wp, T("<th width=\"25%\" align=\"center\">RX</th>\n"));
			ifx_httpdWrite(wp, T("</tr>\n"));

			ifx_httpdWrite(wp, T("<tr>\n"));
			ifx_httpdWrite(wp, T("<td>\n"));
			ifx_httpdWrite(wp, T("<table width=\"100%\" cellspacing=\"1\" cellpadding=\"0\">\n"));
			ifx_httpdWrite(wp, T("<tr>\n"));
			ifx_httpdWrite(wp, T("<th width=\"10%\">Packets</th>\n"));
			ifx_httpdWrite(wp, T("<th width=\"10%\">Bytes</th>\n"));
			ifx_httpdWrite(wp, T("<th width=\"10%\">Errors</th>\n"));
			ifx_httpdWrite(wp, T("<th width=\"10%\">Dropped</th>\n"));
			ifx_httpdWrite(wp, T("<th width=\"10%\">Unicast Packets</th>\n"));
			ifx_httpdWrite(wp, T("<th width=\"10%\">Mulitcast Packets</th>\n"));
			ifx_httpdWrite(wp, T("<th width=\"10%\">Broadcast Packets</th>\n"));
			ifx_httpdWrite(wp, T("</tr>\n"));
			ifx_httpdWrite(wp, T("</table>\n"));
			ifx_httpdWrite(wp, T("</td>\n"));
			ifx_httpdWrite(wp, T("</tr>\n"));
			ifx_httpdWrite(wp, T("</table>\n"));
			ifx_httpdWrite(wp, T("</th>\n"));
		}

		for (i = 0; i < numEntries; i++) {
			memset(&wlStats, 0x00, sizeof(wlStats));
			wlStats.iid.cpeId.Id = (wlMain + i)->iid.cpeId.Id;
			wlStats.iid.pcpeId.Id = (wlMain + i)->iid.pcpeId.Id;
			if (ifx_mapi_get_wlan_stats(&wlStats, IFX_F_DEFAULT) !=
			    IFX_SUCCESS) {
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to get wlan statistics\n\n"));
				goto IFX_Handler;
			}

			ifx_httpdWrite(wp, T("<tr align=\"center\">"));
			ifx_httpdWrite(wp, T("<td>"));
#ifdef CONFIG_FEATURE_LTQ_WIRELESS_VB
			ifx_httpdWrite(wp, T("wlan0"));
#else
			ifx_httpdWrite(wp, T("%s"), (wlMain + i)->apName);
#endif
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("<td>"));
			ifx_httpdWrite(wp,
				       T
				       ("<table border='0' width='100%' cellspacing=\"1\" cellpadding=\"0\" >"));
			ifx_httpdWrite(wp, T("<tr align=\"center\" >"));

			/* tx statistics */
			ifx_httpdWrite(wp, T("<td width='10%'>%lu</td>"),
				       wlStats.pktsTx);
			ifx_httpdWrite(wp, T("<td width='10%'>%lu</td>"),
				       wlStats.bytesTx);
			ifx_httpdWrite(wp, T("<td width='10%'>%lu</td>"),
				       wlStats.errorsTx);
			ifx_httpdWrite(wp, T("<td width='10%'>%lu</td>"),
				       wlStats.discardPktsTx);
			ifx_httpdWrite(wp, T("<td width='10%'>%lu</td>"),
				       wlStats.ucPktsTx);
			ifx_httpdWrite(wp, T("<td width='10%'>%lu</td>"),
				       wlStats.mcPktsTx);
			ifx_httpdWrite(wp, T("<td width='10%'>%lu</td>"),
				       wlStats.bcPktsTx);

			ifx_httpdWrite(wp, T("</tr>"));
			ifx_httpdWrite(wp, T("</table>"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("<td>"));
			ifx_httpdWrite(wp,
				       T
				       ("<table border='0' width='100%' cellspacing=\"1\" cellpadding=\"0\">"));
			ifx_httpdWrite(wp, T("<tr align=\"center\" >"));

			/* rx statistics */
			ifx_httpdWrite(wp, T("<td width='10%'>%lu</td>"),
				       wlStats.pktsRx);
			ifx_httpdWrite(wp, T("<td width='10%'>%lu</td>"),
				       wlStats.bytesRx);
			ifx_httpdWrite(wp, T("<td width='10%'>%lu</td>"),
				       wlStats.errorsRx);
			ifx_httpdWrite(wp, T("<td width='10%'>%lu</td>"),
				       wlStats.discardPktsRx);
			ifx_httpdWrite(wp, T("<td width='10%'>%lu</td>"),
				       wlStats.ucPktsRx);
			ifx_httpdWrite(wp, T("<td width='10%'>%lu</td>"),
				       wlStats.mcPktsRx);
			ifx_httpdWrite(wp, T("<td width='10%'>%lu</td>"),
				       wlStats.bcPktsRx);
			ifx_httpdWrite(wp, T("</tr>"));
			ifx_httpdWrite(wp, T("</table>"));
			ifx_httpdWrite(wp, T("</td>"));
			ifx_httpdWrite(wp, T("</tr>"));
		}
	}

	if (!gstrcmp(name, T("WAVE_STATS_DETAILS_RADIO"))) {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetStatistics", "");
		for (i = 0; i < LTQ_MAX_NUM_RADIO; i++) {
			/* radioCpeId is fixed (i+1) */
			if (ltq_mapi_get_wlan_vendor(i+1, IFX_F_DEFAULT) ==
				LTQ_MAPI_WLAN_VENDOR_WAVE300) {
				ifx_httpdWrite(wp, T("<tr align=\"center\">\n<td id=\"ifName\"> wlan%d </td>\n"), i);
				ifx_httpdWrite(wp, T("<td>\n"));
				ifx_httpdWrite(wp, T("<table class=\"tableInfo\" rules=\"rows\" summary=\"Table\">\n"));
				ifx_httpdWrite(wp, T("<tbody align=\"center\">\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"fcsErrorCount\"> FCS Error </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"rtsSuccessCount\"> RTS Success </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"rtsFailureCount\"> RTS Failure </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"freeTxMsduCount\"> FreeTxMSDUs </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"txMsduUsagePeak\"> TX MSDUs Usage Peak </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"bistCheckPassed\"> BIST Check Passed </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"manMsgSent\"> MAN Msg Sent </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"manMsgConfirmed\"> MAN Msg Confirmed </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"manMsgPeak\"> MAN Msg Peak </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"dbgMsgSent\"> DBG Msg Sent </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"dbgMsgConfirm\"> DBG Msg Confirmed </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"dbgMsgPeak\"> DBG Msg Peak </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"fwLogPktProc\"> FW Logger Packets Processed </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"fwLogPktDrop\"> FW Logger Packets Dropped </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"datFramesReceived\"> DAT Frames Received </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"ctlFramesReceived\"> CTL Frames Received </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"manFramesReceived\"> MAN Frames Received </tr>\n"));
				ifx_httpdWrite(wp, T("</tbody>\n</table>\n</td>\n"));

				memset(&wlPhyStats, 0x00, sizeof(wlPhyStats));
				wlPhyStats.iid.cpeId.Id = (g_wlPhy + i)->iid.cpeId.Id;
				wlPhyStats.iid.pcpeId.Id = (g_wlPhy + i)->iid.pcpeId.Id;
				if (ifx_mapi_get_wlan_phy_stats(&wlPhyStats, IFX_F_DEFAULT) !=
					IFX_SUCCESS) {
					IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetStatistics",
							"Failed to get wlan phy statistics");
					ifx_httpdWrite(wp, T("<td>\n"));
					ifx_httpdWrite(wp, T("<table class=\"tableInfo\" rules=\"rows\" summary=\"Table\">\n"));
					ifx_httpdWrite(wp, T("<tbody align=\"center\">\n"));
					ifx_httpdWrite(wp, T("<tr><td id=\"fcsErrorCountVal\"> n/a </td></tr>\n"));
					ifx_httpdWrite(wp, T("<tr><td id=\"rtsSuccessCountVal\"> n/a </td></tr>\n"));
					ifx_httpdWrite(wp, T("<tr><td id=\"rtsFailureCountVal\"> n/a </td></tr>\n"));
					ifx_httpdWrite(wp, T("<tr><td id=\"freeTxMsduCountVal\"> n/a </td></tr>\n"));
					ifx_httpdWrite(wp, T("<tr><td id=\"txMsduUsagePeakVal\"> n/a </td></tr>\n"));
					ifx_httpdWrite(wp, T("<tr><td id=\"bistCheckPassedVal\"> n/a </td></tr>\n"));
					ifx_httpdWrite(wp, T("<tr><td id=\"manMsgSentVal\"> n/a </td></tr>\n"));
					ifx_httpdWrite(wp, T("<tr><td id=\"manMsgConfirmedVal\"> n/a </td></tr>\n"));
					ifx_httpdWrite(wp, T("<tr><td id=\"manMsgPeakVal\"> n/a </td></tr>\n"));
					ifx_httpdWrite(wp, T("<tr><td id=\"dbgMsgSentVal\"> n/a </td></tr>\n"));
					ifx_httpdWrite(wp, T("<tr><td id=\"dbgMsgConfirmVal\"> n/a </td></tr>\n"));
					ifx_httpdWrite(wp, T("<tr><td id=\"dbgMsgPeakVal\"> n/a </td></tr>\n"));
					ifx_httpdWrite(wp, T("<tr><td id=\"fwLogPktProcVal\"> n/a </td></tr>\n"));
					ifx_httpdWrite(wp, T("<tr><td id=\"fwLogPktDropVal\"> n/a </td></tr>\n"));
					ifx_httpdWrite(wp, T("<tr><td id=\"datFramesReceivedVal\"> n/a </td></tr>\n"));
					ifx_httpdWrite(wp, T("<tr><td id=\"ctlFramesReceivedVal\"> n/a </td></tr>\n"));
					ifx_httpdWrite(wp, T("<tr><td id=\"manFramesReceivedVal\"> n/a </td></tr>\n"));
					ifx_httpdWrite(wp, T("</tbody>\n</table>\n</td>\n"));
					ifx_httpdWrite(wp, T("</tr>\n"));
				}
				else {
					ifx_httpdWrite(wp, T("<td>\n"));
					ifx_httpdWrite(wp, T("<table class=\"tableInfo\" rules=\"rows\" summary=\"Table\">\n"));
					ifx_httpdWrite(wp, T("<tbody align=\"center\">\n"));
					ifx_httpdWrite(wp, T("<tr><td id=\"fcsErrorCountVal\"> %d </td></tr>\n"), wlPhyStats.fcsErrorCount);
					ifx_httpdWrite(wp, T("<tr><td id=\"rtsSuccessCountVal\"> %d </td></tr>\n"), wlPhyStats.rtsSuccessCount);
					ifx_httpdWrite(wp, T("<tr><td id=\"rtsFailureCountVal\"> %d </td></tr>\n"), wlPhyStats.rtsFailureCount);
					ifx_httpdWrite(wp, T("<tr><td id=\"freeTxMsduCountVal\"> %d </td></tr>\n"), wlPhyStats.freeTxMSDUs);
					ifx_httpdWrite(wp, T("<tr><td id=\"txMsduUsagePeakVal\"> %d </td></tr>\n"), wlPhyStats.txMSDUsUsagePeak);
					ifx_httpdWrite(wp, T("<tr><td id=\"bistCheckPassedVal\"> %d </td></tr>\n"), wlPhyStats.bistCheckPassed);
					ifx_httpdWrite(wp, T("<tr><td id=\"manMsgSentVal\"> %d </td></tr>\n"), wlPhyStats.manMsgSent);
					ifx_httpdWrite(wp, T("<tr><td id=\"manMsgConfirmedVal\"> %d </td></tr>\n"), wlPhyStats.manMsgConfirmed);
					ifx_httpdWrite(wp, T("<tr><td id=\"manMsgPeakVal\"> %d </td></tr>\n"), wlPhyStats.manMsgPeak);
					ifx_httpdWrite(wp, T("<tr><td id=\"dbgMsgSentVal\"> %d </td></tr>\n"), wlPhyStats.dbgMsgSent);
					ifx_httpdWrite(wp, T("<tr><td id=\"dbgMsgConfirmVal\"> %d </td></tr>\n"), wlPhyStats.dbgMsgConfirmed);
					ifx_httpdWrite(wp, T("<tr><td id=\"dbgMsgPeakVal\"> %d </td></tr>\n"), wlPhyStats.dbgMsgPeak);
					ifx_httpdWrite(wp, T("<tr><td id=\"fwLogPktProcVal\"> %d </td></tr>\n"), wlPhyStats.fwLoggerPacketsProcessed);
					ifx_httpdWrite(wp, T("<tr><td id=\"fwLogPktDropVal\"> %d </td></tr>\n"), wlPhyStats.fwLoggerPacketsDropped);
					ifx_httpdWrite(wp, T("<tr><td id=\"datFramesReceivedVal\"> %d </td></tr>\n"), wlPhyStats.datFramesReceived);
					ifx_httpdWrite(wp, T("<tr><td id=\"ctlFramesReceivedVal\"> %d </td></tr>\n"), wlPhyStats.ctlFramesReceived);
					ifx_httpdWrite(wp, T("<tr><td id=\"manFramesReceivedVal\"> %d </td></tr>\n"), wlPhyStats.manFramesReceived);
					ifx_httpdWrite(wp, T("</tbody>\n</table>\n</td>\n"));
					ifx_httpdWrite(wp, T("</tr>\n"));
				}
			}
		}
	}

	if (!gstrcmp(name, T("WAVE_STATS_DETAILS_VAP"))) {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetStatistics", "");
		for (i = 0; i < numEntries; i++) {
			if (ltq_mapi_get_wlan_vendor((wlMain + i)->radioCpeId, IFX_F_DEFAULT) ==
				LTQ_MAPI_WLAN_VENDOR_WAVE300) {
				memset(&wlStats, 0x00, sizeof(wlStats));
				wlStats.iid.cpeId.Id = (wlMain + i)->iid.cpeId.Id;
				wlStats.iid.pcpeId.Id = (wlMain + i)->iid.pcpeId.Id;
				if (ifx_mapi_get_wlan_stats(&wlStats, IFX_F_DEFAULT) !=
					IFX_SUCCESS) {
					ifx_httpdError(wp, 400,
							   T
							   ("Failed to get wlan statistics\n\n"));
					goto IFX_Handler;
				}

				ifx_httpdWrite(wp, T("<tr align=\"center\">\n<td id=\"vapName\"> %s </td>\n"), (wlMain + i)->apName);
				ifx_httpdWrite(wp, T("<td>\n"));
				ifx_httpdWrite(wp, T("<table class=\"tableInfo\" rules=\"rows\" summary=\"Table\">\n"));
				ifx_httpdWrite(wp, T("<tbody align=\"center\">\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"bytesSent\"> BytesSent </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"bytesReceived\"> BytesReceived </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"unicastPacketsSent\"> UnicastPacketsSent </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"unicastPacketsReceived\"> UnicastPacketsReceived </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"multicastPacketsSent\"> MulticastPacketsSent </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"multicastPacketsReceived\"> MulticastPacketsReceived </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"broadcastPacketsSent\"> BroadcastPacketsSent </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"broadcastPacketsReceived\"> BroadcastPacketsReceived </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"NACKedPacketsSent\"> NACKedPacketsSent </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"txPacketsDiscardedDrvNoPeers\"> TxPacketsDiscardedDrvNoPeers </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"txPacketsDiscardedDrvACM\"> TxPacketsDiscardedDrvACM </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"txPacketsDiscardedDrvEAPOLCloned\"> TxPacketsDiscardedDrvEAPOLCloned </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"txPacketsDiscardedDrvUnknownDestinationDirected\"> TxPacketsDiscardedDrvUnknownDestinationDirected </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"txPacketsDiscardedDrvUnknownDestinationMcast\"> TxPacketsDiscardedDrvUnknownDestinationMcast </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"txPacketsDiscardedDrvNoResources\"> TxPacketsDiscardedDrvNoResources </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"txPacketsDiscardedDrvSQOverflow\"> TxPacketsDiscardedDrvSQOverflow </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"txPacketsDiscardedDrvEAPOLFilter\"> TxPacketsDiscardedDrvEAPOLFilter </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"txPacketsDiscardedDrvDropAllFilter\"> TxPacketsDiscardedDrvDropAllFilter </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"txPacketsDiscardedDrvTXQueueOverflow\"> TxPacketsDiscardedDrvTXQueueOverflow </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"rxPacketsDiscardedDrvForeign\"> RxPacketsDiscardedDrvForeign </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"rxPacketsDiscardedDrvLoopback\"> RxPacketsDiscardedDrvLoopback </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"rxPacketsDiscardedDrvTooOld\"> RxPacketsDiscardedDrvTooOld </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"rxPacketsDiscardedDrvDuplicate\"> RxPacketsDiscardedDrvDuplicate </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"rxPacketsDiscardedDrvNoResources\"> RxPacketsDiscardedDrvNoResources </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"txPacketsDiscardedFw\"> TxPacketsDiscardedFw </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"rxPacketsDiscardedFw\"> RxPacketsDiscardedFw </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"pairwiseMICFailurePackets\"> PairwiseMICFailurePackets </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"groupMICFailurePackets\"> GroupMICFailurePackets </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"unicastReplayedPackets\"> UnicastReplayedPackets </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"multicastReplayedPackets\"> MulticastReplayedPackets </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"retryCount\"> RetryCount </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"multipleRetryCount\"> MultipleRetryCount </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"fwdRxPackets\"> FwdRxPackets </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"fwdRxBytes\"> FwdRxBytes </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"barFramesCount\"> BARFramesCount </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"macStats\"> MACStats </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"sendQueueStats\"> SendQueueStats </tr>\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"reorderingStats\"> ReorderingStats </tr>\n"));
				ifx_httpdWrite(wp, T("</tbody>\n</table>\n</td>\n"));

				ifx_httpdWrite(wp, T("<td>\n"));
				ifx_httpdWrite(wp, T("<table class=\"tableInfo\" rules=\"rows\" summary=\"Table\">\n"));
				ifx_httpdWrite(wp, T("<tbody align=\"center\">\n"));
				ifx_httpdWrite(wp, T("<tr><td id=\"bytesSentVal\"> %d </td></tr>\n"), wlStats.bytesSent);
				ifx_httpdWrite(wp, T("<tr><td id=\"bytesReceivedVal\"> %d </td></tr>\n"), wlStats.bytesReceived);
				ifx_httpdWrite(wp, T("<tr><td id=\"unicastPacketsSentVal\"> %d </td></tr>\n"), wlStats.unicastPacketsSent);
				ifx_httpdWrite(wp, T("<tr><td id=\"unicastPacketsReceivedVal\"> %d </td></tr>\n"), wlStats.unicastPacketsReceived);
				ifx_httpdWrite(wp, T("<tr><td id=\"multicastPacketsSentVal\"> %d </td></tr>\n"), wlStats.multicastPacketsSent);
				ifx_httpdWrite(wp, T("<tr><td id=\"multicastPacketsReceivedVal\"> %d </td></tr>\n"), wlStats.multicastPacketsReceived);
				ifx_httpdWrite(wp, T("<tr><td id=\"broadcastPacketsSentVal\"> %d </td></tr>\n"), wlStats.broadcastPacketsSent);
				ifx_httpdWrite(wp, T("<tr><td id=\"broadcastPacketsReceivedVal\"> %d </td></tr>\n"), wlStats.broadcastPacketsReceived);
				ifx_httpdWrite(wp, T("<tr><td id=\"NACKedPacketsSentVal\"> %d </td></tr>\n"), wlStats.nACKedPacketsSent);
				ifx_httpdWrite(wp, T("<tr><td id=\"txPacketsDiscardedDrvNoPeersVal\"> %d </td></tr>\n"), wlStats.txPacketsDiscardedDrvNoPeers);
				ifx_httpdWrite(wp, T("<tr><td id=\"txPacketsDiscardedDrvACMVal\"> %d </td></tr>\n"), wlStats.txPacketsDiscardedDrvACM);
				ifx_httpdWrite(wp, T("<tr><td id=\"txPacketsDiscardedDrvEAPOLClonedVal\"> %d </td></tr>\n"), wlStats.txPacketsDiscardedDrvEAPOLCloned);
				ifx_httpdWrite(wp, T("<tr><td id=\"txPacketsDiscardedDrvUnknownDestinationDirectedVal\"> %d </td></tr>\n"), wlStats.txPacketsDiscardedDrvUnknownDestinationDirected);
				ifx_httpdWrite(wp, T("<tr><td id=\"txPacketsDiscardedDrvUnknownDestinationMcastVal\"> %d </td></tr>\n"), wlStats.txPacketsDiscardedDrvUnknownDestinationMcast);
				ifx_httpdWrite(wp, T("<tr><td id=\"txPacketsDiscardedDrvNoResourcesVal\"> %d </td></tr>\n"), wlStats.txPacketsDiscardedDrvNoResources);
				ifx_httpdWrite(wp, T("<tr><td id=\"txPacketsDiscardedDrvSQOverflowVal\"> %d </td></tr>\n"), wlStats.txPacketsDiscardedDrvSQOverflow);
				ifx_httpdWrite(wp, T("<tr><td id=\"txPacketsDiscardedDrvEAPOLFilterVal\"> %d </td></tr>\n"), wlStats.txPacketsDiscardedDrvEAPOLFilter);
				ifx_httpdWrite(wp, T("<tr><td id=\"txPacketsDiscardedDrvDropAllFilterVal\"> %d </td></tr>\n"), wlStats.txPacketsDiscardedDrvDropAllFilter);
				ifx_httpdWrite(wp, T("<tr><td id=\"txPacketsDiscardedDrvTXQueueOverflowVal\"> %d </td></tr>\n"), wlStats.txPacketsDiscardedDrvTXQueueOverflow);
				ifx_httpdWrite(wp, T("<tr><td id=\"rxPacketsDiscardedDrvForeignVal\"> %d </td></tr>\n"), wlStats.rxPacketsDiscardedDrvForeign);
				ifx_httpdWrite(wp, T("<tr><td id=\"rxPacketsDiscardedDrvLoopbackVal\"> %d </td></tr>\n"), wlStats.rxPacketsDiscardedDrvLoopback);
				ifx_httpdWrite(wp, T("<tr><td id=\"rxPacketsDiscardedDrvTooOldVal\"> %d </td></tr>\n"), wlStats.rxPacketsDiscardedDrvTooOld);
				ifx_httpdWrite(wp, T("<tr><td id=\"rxPacketsDiscardedDrvDuplicateVal\"> %d </td></tr>\n"), wlStats.rxPacketsDiscardedDrvDuplicate);
				ifx_httpdWrite(wp, T("<tr><td id=\"rxPacketsDiscardedDrvNoResourcesVal\"> %d </td></tr>\n"), wlStats.rxPacketsDiscardedDrvNoResources);
				ifx_httpdWrite(wp, T("<tr><td id=\"txPacketsDiscardedFwVal\"> %d </td></tr>\n"), wlStats.txPacketsDiscardedFw);
				ifx_httpdWrite(wp, T("<tr><td id=\"rxPacketsDiscardedFwVal\"> %d </td></tr>\n"), wlStats.rxPacketsDiscardedFw);
				ifx_httpdWrite(wp, T("<tr><td id=\"pairwiseMICFailurePacketsVal\"> %d </td></tr>\n"), wlStats.pairwiseMICFailurePackets);
				ifx_httpdWrite(wp, T("<tr><td id=\"groupMICFailurePacketsVal\"> %d </td></tr>\n"), wlStats.groupMICFailurePackets);
				ifx_httpdWrite(wp, T("<tr><td id=\"unicastReplayedPacketsVal\"> %d </td></tr>\n"), wlStats.unicastReplayedPackets);
				ifx_httpdWrite(wp, T("<tr><td id=\"multicastReplayedPacketsVal\"> %d </td></tr>\n"), wlStats.multicastReplayedPackets);
				ifx_httpdWrite(wp, T("<tr><td id=\"retryCountVal\"> %d </td></tr>\n"), wlStats.retryCount);
				ifx_httpdWrite(wp, T("<tr><td id=\"multipleRetryCountVal\"> %d </td></tr>\n"), wlStats.multipleRetryCount);
				ifx_httpdWrite(wp, T("<tr><td id=\"fwdRxPacketsVal\"> %d </td></tr>\n"), wlStats.fwdRxPackets);
				ifx_httpdWrite(wp, T("<tr><td id=\"fwdRxBytesVal\"> %d </td></tr>\n"), wlStats.fwdRxBytes);
				ifx_httpdWrite(wp, T("<tr><td id=\"barFramesCountVal\"> %d </td></tr>\n"), wlStats.barFramesCount);
				ifx_httpdWrite(wp, T("<tr><td id=\"macStatsVal\"> %d </td></tr>\n"), wlStats.macStats);
				ifx_httpdWrite(wp, T("<tr><td id=\"sendQueueStatsVal\"> %d </td></tr>\n"), wlStats.sendQueueStats);
				ifx_httpdWrite(wp, T("<tr><td id=\"reorderingStatsVal\"> %d </td></tr>\n"), wlStats.reorderingStats);
				ifx_httpdWrite(wp, T("</tbody>\n</table>\n</td>\n"));
				ifx_httpdWrite(wp, T("</tr>\n"));
			}
		}
	}
IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetStatistics", "");
	IFX_MEM_FREE(wlMain);
	return;
}

/**
   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void
IFX_WLAN_GetDeviceAssociations(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 i = 0, j = 0, staCount = 0;
	IFX_MAPI_WLAN_AssocInfo *wlAssocInfo = NULL;
	uint32 mainCpeId;
	IFX_MAPI_WLAN_MainCfg *wlMain = NULL;
	uint32 numEntries = 0;

	/*
		we pass flag IFX_F_RESET_WEB_CFG to indicate to MAPI that main
		config has been read from web
	*/
	if (ifx_mapi_get_all_wlan_main_config(&numEntries, &wlMain,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get all wlan main config\n"));
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetDeviceAssociations", "numEntries: %d", numEntries);

	for (i = 0; i < numEntries; i++) {
		mainCpeId = wlMain[i].iid.cpeId.Id;
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetDeviceAssociations",
			       "mainCpeId: %d", mainCpeId);
		if (ifx_mapi_get_all_wlan_assoc_devices
		    (mainCpeId, (uint32 *) & staCount, &wlAssocInfo,
		     IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 500,
				       T
				       ("Failed to get associated device list"));
			return;
		}

		if (staCount < 1) {
			ifx_httpdWrite(wp, T("<tr>"));
			ifx_httpdWrite(wp, T("<td id=\"apname_%d\">%s</td>"), i,
				       wlMain[i].apName);
			ifx_httpdWrite(wp, T("<td id=\"ssid_%d\">%s</td>"), i,
				       wlMain[i].ssid);
			ifx_httpdWrite(wp,
				       T
				       ("<td colspan=4 id=\"found_%d\">No Associated Stations Found</td></tr>"),
				       i);
		} else {
			ifx_httpdWrite(wp, T("</table>\n"));
			ifx_httpdWrite(wp,
				       T
				       ("<table class=\"tableInfo\" cellspacing=\"1\" cellpadding=\"6\" summary=\"\">\n"));
			ifx_httpdWrite(wp, T("<tr>\n"));
			ifx_httpdWrite(wp,
				       T
				       ("<td id=\"apname_%d\" width=\"10%\">%s</td>\n"),
				       i, wlMain[i].apName);
			ifx_httpdWrite(wp,
				       T
				       ("<td id=\"ssid_%d\" width=\"10%\">%s</td>\n"),
				       i, wlMain[i].ssid);

			/* MAC address */
			ifx_httpdWrite(wp, T("<td width=\"20%\">\n"));
			ifx_httpdWrite(wp,
				       T
				       ("<table border='0' cellspacing='1' cellpadding='5''>\n"));
			for (j = 0; j < staCount; j++) {
				ifx_httpdWrite(wp, T("<tr>\n"));
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"mac_addr_%d\">%s</td>\n"),
					       i,
					       (wlAssocInfo + j)->macAddress);
				ifx_httpdWrite(wp, T("</tr>\n"));
			}
			ifx_httpdWrite(wp, T("</table>\n"));
			ifx_httpdWrite(wp, T("</td>\n"));

			/* IP address */
			ifx_httpdWrite(wp, T("<td width=\"20%\">\n"));
			ifx_httpdWrite(wp,
				       T
				       ("<table class=\"tableInfo\" cellspacing=\"1\" cellpadding=\"6\" summary=\"\">\n"));
			for (j = 0; j < staCount; j++) {
				char8 ipAddr[MAX_IP_ADDR_LEN];

				sprintf(ipAddr, "%s",  inet_ntoa((wlAssocInfo + j)->ipAddress));
				IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetDeviceAssociations",
					"ipAddr: %s", ipAddr);
				if (!(strcmp("0.0.0.0", (char *)inet_ntoa((wlAssocInfo + j)->ipAddress)))) {
					IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetDeviceAssociations", "");
					ifx_httpdWrite(wp, T("<tr>\n"));
					ifx_httpdWrite(wp, T("<td id=\"ap_addr_%d\">Unknown</td>"), i);
					ifx_httpdWrite(wp, T("</tr>\n"));
				} else {
					IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetDeviceAssociations", "");
					ifx_httpdWrite(wp, T("<tr>\n"));
					ifx_httpdWrite(wp, T("<td id=\"ap_addr_%d\">%s</td>"), i, 
						(char_t *) inet_ntoa((wlAssocInfo + j)->ipAddress));
					ifx_httpdWrite(wp, T("</tr>\n"));
				}
			}
			ifx_httpdWrite(wp, T("</table>\n"));
			ifx_httpdWrite(wp, T("</td>\n"));

			/* Authentication state */
			ifx_httpdWrite(wp, T("<td width=\"20%\">\n"));
			ifx_httpdWrite(wp,
				       T
				       ("<table class=\"tableInfo\" cellspacing=\"1\" cellpadding=\"6\" summary=\"\">\n"));
			for (j = 0; j < staCount; j++) {
				ifx_httpdWrite(wp, T("<tr>\n"));
				ifx_httpdWrite(wp,
					       T("<td id=\"auth_%d\">%s</td>"),
					       i,
					       ((wlAssocInfo +
						 j)->staAuthenticated ==
						IFX_MAPI_WLAN_STA_AUTHENTICATED)
					       ? "Authenticated" :
					       "Not Authenticated");
				ifx_httpdWrite(wp, T("</tr>\n"));
			}
			ifx_httpdWrite(wp, T("</table>\n"));
			ifx_httpdWrite(wp, T("</td>\n"));

			/* Last data rate */
			ifx_httpdWrite(wp, T("<td width=\"20%\">\n"));
			ifx_httpdWrite(wp,
				       T
				       ("<table class=\"tableInfo\" cellspacing=\"1\" cellpadding=\"6\" summary=\"\">\n"));
			for (j = 0; j < staCount; j++) {
				ifx_httpdWrite(wp, T("<tr>\n"));
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"last_data_tx_%d\">%.1f MBits/s</td>"),
					       i,
					       (wlAssocInfo +
						j)->lastDataTxRate);
				ifx_httpdWrite(wp, T("</tr>\n"));
			}
			ifx_httpdWrite(wp, T("</table>\n"));
			ifx_httpdWrite(wp, T("</td>\n"));
			ifx_httpdWrite(wp, T("</tr>"));
		}
	}

LTQ_Handler:
	IFX_MEM_FREE(wlAssocInfo);
	IFX_MEM_FREE(wlMain);
	return;
}

/**
   This function gets information about the available channel list required to
   display the web page for "Radio Settings" properly. It is called from
   wlan_basic.asp. The available channel list depends on the selected
   country and standard.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int IFX_WLAN_GetChannelList(int eid, httpd_t wp, int argc, char_t ** argv)
{
	IFX_MAPI_WLAN_ChannelList wlChanList;
	int32 ret = IFX_SUCCESS;
	uint32 i = 0, phyCpeId = 0;
	char8 *standard, *country, *frequency;
	char8 var_name[MAX_FILELINE_LEN];
	bool bStd;

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetChannelList", "");

	/* parse arguments passed from web page */
	if ((ret =
	     ifx_httpd_parse_args(argc, argv, T("%s,%s,%s"), &standard,
				  &country, &frequency)) < 1) {
/*
	   ifx_httpdError(wp, 400, T("Insufficient args\n"));
*/
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetChannelList",
		       "standard: %s, country: %s, frequency: %s "
		       "argc: %d, ret: %d", standard, country, frequency, argc,
		       ret);

	/* initialize all structures */
	memset(&wlChanList, 0, sizeof(IFX_MAPI_WLAN_ChannelList));

	/*
	   depending on standard and country setting, different options are
	   displayed */
	memset(&wlChanList, 0x00, sizeof(IFX_MAPI_WLAN_ChannelList));
	if (!gstrcmp(standard, T("IFX_MAPI_WLAN_STD_802_11B")))
		wlChanList.std = IFX_MAPI_WLAN_STD_802_11B;
	else if (!gstrcmp(standard, T("IFX_MAPI_WLAN_STD_802_11BG")))
		wlChanList.std = IFX_MAPI_WLAN_STD_802_11BG;
	else if (!gstrcmp(standard, T("IFX_MAPI_WLAN_STD_802_11A")))
		wlChanList.std = IFX_MAPI_WLAN_STD_802_11A;
	else if (!gstrcmp(standard, T("IFX_MAPI_WLAN_STD_802_11G")))
		wlChanList.std = IFX_MAPI_WLAN_STD_802_11G;
	else if (!gstrcmp(standard, T("IFX_MAPI_WLAN_STD_802_11N")))
		wlChanList.std = IFX_MAPI_WLAN_STD_802_11N;
	else if (!gstrcmp(standard, T("IFX_MAPI_WLAN_STD_802_11BGN")))
		wlChanList.std = IFX_MAPI_WLAN_STD_802_11BGN;
	else if (!gstrcmp(standard, T("IFX_MAPI_WLAN_STD_802_11GN")))
		wlChanList.std = IFX_MAPI_WLAN_STD_802_11GN;
	else if (!gstrcmp(standard, T("IFX_MAPI_WLAN_STD_802_11AN")))
		wlChanList.std = IFX_MAPI_WLAN_STD_802_11AN;
	else {
/*
   	ifx_httpdError(wp, 400, T("Invalid Standard\n\r"));
*/
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	i = 0;
	bStd = FALSE;
	/* do-while to go through all supported standards in capabilities */
	do {
		/* standard is supported */
		if (g_wlCaps[g_idx].std[i] == wlChanList.std) {
			bStd = TRUE;
			break;
		}
		i++;
	} while ((i < IFX_MAPI_WLAN_MAX_STD)
		 && (g_wlCaps[g_idx].std[i] != 0xFF));
	if (bStd == FALSE) {
/*
      ifx_httpdError(wp, 400, T("standard not supported"));
*/
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

/*
	if ( !gstrcmp(country, T("IN")) )
		gstrcpy(wlChanList.country,A;
   else if ( !gstrcmp(country, T("US")) )
		wlChanList.country   = IFX_MAPI_WLAN_COUNTRY_US;
   else if ( !gstrcmp(country, T("CN")) )
		wlChanList.country   = IFX_MAPI_WLAN_COUNTRY_CHINA;
   else if ( !gstrcmp(country, T("FR")) )
		wlChanList.country   = IFX_MAPI_WLAN_COUNTRY_FRANCE;
   else if ( !gstrcmp(country, T("DE")) )
		wlChanList.country   = IFX_MAPI_WLAN_COUNTRY_GER;
   else if ( !gstrcmp(country, T("JP")) )
		wlChanList.country   = IFX_MAPI_WLAN_COUNTRY_JAPAN;
   else
		wlChanList.country   = IFX_MAPI_WLAN_COUNTRY_ESP;
   else
   {
      ret = IFX_FAILURE;
       IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetChannelList", "");
      goto IFX_Handler;
   }*/

	gstrcpy(wlChanList.country, country);
	// manohar start
	if (!gstrcmp(frequency, T("IFX_MAPI_WLAN_2_4_GHz_Freq")))
		wlChanList.freqBand = IFX_MAPI_WLAN_2_4_GHz_Freq;
	else if (!gstrcmp(frequency, T("IFX_MAPI_WLAN_5_GHz_Freq")))
		wlChanList.freqBand = IFX_MAPI_WLAN_5_GHz_Freq;
	else {
/*
   	ifx_httpdError(wp, 400, T("Invalid country\n\r"));
*/
		ret = IFX_FAILURE;
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetChannelList",
			       "standard: %d", wlChanList.std);
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetChannelList",
			       "freqBand: %d", wlChanList.freqBand);
		goto IFX_Handler;
	}

	/* phyCpeId is unused parameter */
	if ((ret =
	     ifx_mapi_get_wlan_channel_list(phyCpeId, &wlChanList,
					    IFX_F_DEFAULT)) != IFX_SUCCESS) {
/*
	   ifx_httpdError(wp, 400, T("Failed to get channel list\n"));
*/
		goto IFX_Handler;
	}

	sprintf(var_name, "%s", "ch_list");
	for (i = 0; i < wlChanList.length; i++) {
		ifx_httpdWrite(wp, T("%s[%d]=\"%d\";\n"), var_name, i,
			       wlChanList.chanNumList[i]);
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetChannelList",
			       "%s[%d]=\"%d\";", var_name, i,
			       wlChanList.chanNumList[i]);
	}

	ifx_httpdWrite(wp, T("for(i=0; i<ch_list.length; i++) {\n"));
	ifx_httpdWrite(wp, T("t_ch = \"\" + ch_list[i];\n"));
	ifx_httpdWrite(wp,
		       T
		       ("document.tF0.channel.options[i]=new Option(t_ch, ch_list[i]);}\n"));
	ifx_httpdWrite(wp, T("document.tF0.channel.length=ch_list.length;\n"));

	for (i = 0; i < wlChanList.length; i++) {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetChannelList",
			       "channel: %d, current: %d",
			       g_wlPhy[g_idx].channelNo,
			       wlChanList.chanNumList[i]);

		if (g_wlPhy[g_idx].channelNo == wlChanList.chanNumList[i])
			ifx_httpdWrite(wp,
				       T
				       ("document.tF0.channel.options[%d].selected = true;\n"),
				       i);
	}
IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_GetChannelList", "ret: %d", ret);
	return ret;
}

int ifx_diag_get_wlan_enable(int eid, httpd_t wp, int argc, char_t ** argv)
{
	IFX_MAPI_WLAN_PhyCfg wlan_phy;
	int32 ret = IFX_SUCCESS;
	uint32 flags = IFX_F_DEFAULT;

	IFX_MAPI_DEBUG(fd, "/tmp/ifx_diag_get_wlan_enable","");
	memset(&wlan_phy, 0, sizeof(IFX_MAPI_WLAN_PhyCfg));
	sprintf(wlan_phy.iid.cpeId.secName, "%s", TAG_WLAN_PHY);
	sprintf(wlan_phy.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

	wlan_phy.iid.cpeId.Id = 1;
	if ((ret =
	     ifx_mapi_get_wlan_phy_config(&wlan_phy, flags)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400,
			       T("Failed to get wlan radio configuration\n"));
		return IFX_FAILURE;
	} else {
		memcpy(&g_wlPhy[0], &wlan_phy, sizeof(IFX_MAPI_WLAN_PhyCfg));
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifx_diag_get_wlan_enable",
		       "radioEnable: %d", wlan_phy.radioEnable);

	/* now get the dynamical information */
	if ((ret = ifx_mapi_get_wlan_dyn_phy_config(&wlan_phy, IFX_F_DEFAULT)
			!= IFX_SUCCESS)) {
				ifx_httpdError(wp, 400,
			    T("Failed to get dynamic wlan radio configuration\n"));
		return IFX_FAILURE;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ifx_diag_get_wlan_enable",
		       "status: %d", wlan_phy.status);

	if (wlan_phy.radioEnable && wlan_phy.status)
		ifx_httpdWrite(wp, T("1"));
	else
		ifx_httpdWrite(wp, T("0"));

	return ret;
}

int ifx_get_concur_dual_band(int eid, httpd_t wp, int argc, char_t ** argv)
{
#if defined CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	ifx_httpdWrite(wp, T("CONCURRENT_DUAL_WIRELESS"));
#endif
	return IFX_SUCCESS;
}

int ltq_get_wlan_fw_version(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32	wlan_vendor_radio1 = LTQ_MAPI_WLAN_VENDOR_NONE;
	int32	wlan_vendor_radio2 = LTQ_MAPI_WLAN_VENDOR_NONE;
	uint32	radioCpeId = 1;
	struct ifx_version_info ver;

	wlan_vendor_radio1 = ltq_mapi_get_wlan_vendor(radioCpeId, IFX_F_DEFAULT);
#if defined CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	radioCpeId = 2;
	wlan_vendor_radio2 = ltq_mapi_get_wlan_vendor(radioCpeId, IFX_F_DEFAULT);
#endif
	if ((wlan_vendor_radio1 == LTQ_MAPI_WLAN_VENDOR_WAVE300) ||
		(wlan_vendor_radio2 == LTQ_MAPI_WLAN_VENDOR_WAVE300)) {
		memset(&ver, 0x00, sizeof(ver));
		if (ifx_get_version_info(&ver) == IFX_SUCCESS) {
			ifx_httpdWrite(wp,
				T("document.write('<tr><td>WAVE300 Version</td><td>%s</td></tr>');"),
				ver.WAVE300_CV);
		}
	}
	return IFX_SUCCESS;
}

int ifx_get_wave300_enable(int eid, httpd_t wp, int argc, char_t ** argv)
{
#if defined CONFIG_FEATURE_IFX_WIRELESS_WAVE300
	ifx_httpdWrite(wp, T("CONFIG_FEATURE_IFX_WIRELESS_WAVE300"));
#endif
	return IFX_SUCCESS;
}

#if defined (CONFIG_LTQ_AEI_CUST)
int ltq_get_wave300_aei_custom(int eid, httpd_t wp, int argc, char_t ** argv)
{
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_wave300_aei_custom", "");
	ifx_httpdWrite(wp, T("CONFIG_LTQ_AEI_CUST"));
	return IFX_SUCCESS;
}

int ltq_get_wave300_aei_custom_net_mode(int eid, httpd_t wp, int argc, char_t ** argv)
{
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_wave300_aei_custom_net_mode", "");
	if (g_wlPhy[0].standard == IFX_MAPI_WLAN_STD_802_11N)
		ifx_httpdWrite(wp, T("CONFIG_LTQ_AEI_CUST_NET_11N"));
	return IFX_SUCCESS;
}
#endif
/**

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int ltq_update_wps_page(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 ret = IFX_SUCCESS;
	int32	j = 0;
	uint32 i = 0, numEntries = 0;
	IFX_MAPI_WLAN_MainCfg *wlMain = NULL;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_update_wps_page", "");

	/*
		we pass flag IFX_F_RESET_WEB_CFG to indicate to MAPI that main
		config has been read from web
	*/
	if (ifx_mapi_get_all_wlan_main_config((uint32 *) &numEntries, &wlMain,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get all wlan main config\n"));
		goto LTQ_Handler;
	}

	ifx_httpdWrite(wp, T("\tdocument.tF0.wpsApPin.disabled = false;\n"));

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_update_wps_page",
		       "maxVapSupported from capabilities: wlan0: %d, wlan1: %d",
		       g_wlCaps[0].maxVAPSupported,
		       g_wlCaps[1].maxVAPSupported);
	ifx_httpdWrite(wp, T("switch (document.tF0.apName.selectedIndex)\n{\n"));
	for (i = 0; i < numEntries; i++) {
		ifx_httpdWrite(wp, T("\t\tcase %d:\n"), i);
		if (ltq_mapi_get_wlan_vendor(wlMain[i].radioCpeId, IFX_F_DEFAULT) ==
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			ifx_httpdWrite(wp, T("with (document.forms[0]) {\n"));
			ifx_httpdWrite(wp, T("if (document.getElementById) {\n"));
			ifx_httpdWrite(wp, T("document.getElementById('wps_pin_gen').style.display	= '';\n"));
			ifx_httpdWrite(wp, T("document.getElementById('wps_ep_mac').style.display	= '';\n"));
			ifx_httpdWrite(wp, T("document.getElementById('wps_config_state_wave').style.display	= '';\n"));
			ifx_httpdWrite(wp, T("document.getElementById('wps_config_state').style.display	= 'none';\n}\n}\n"));
			ifx_httpdWrite(wp,
					   T("document.tF0.wpsEpMacList.options[0]=new Option(\"Any MAC\", \"0\");\n"));
			for (j = 1; j <= gWpsEpMacCount[i]; j++) {
				ifx_httpdWrite(wp,
						   T("document.tF0.wpsEpMacList.options[%d]=new Option(\"%s\", \"%d\");\n"),
						   j, g_wlWpsEpMacTable[i][j-1].macAddr, j);
			}
			ifx_httpdWrite(wp,
					   T("document.tF0.wpsEpMacList.length= %d;\n"),
					   gWpsEpMacCount[i]+1);
		} else {
            ifx_httpdWrite(wp, T("with (document.forms[0]) {\n"));
			ifx_httpdWrite(wp, T("if (document.getElementById) {\n"));
			ifx_httpdWrite(wp, T("document.getElementById('wps_pin_gen').style.display	= 'none';\n"));
			ifx_httpdWrite(wp, T("document.getElementById('wps_ep_mac').style.display	= 'none';\n"));
			ifx_httpdWrite(wp, T("document.getElementById('wps_config_state_wave').style.display	= 'none';\n"));
			ifx_httpdWrite(wp, T("document.getElementById('wps_config_state').style.display	= '';\n}\n}\n"));
			ifx_httpdWrite(wp,
				T("document.tF0.wpsStateNonConfig.disabled = false;\n"));
		}

		ifx_httpdWrite(wp, T("document.tF0.wpsApIndex.value = %d;\n"), i);
		ifx_httpdWrite(wp, T("document.tF0.radioCpeId.value=\"%d\";\n"),
			wlMain[i].radioCpeId);
		ifx_httpdWrite(wp, T("document.tF0.wlan_vendor_vap.value = "
			"document.tF0.wlan_vendor_vap_%d.value;\n"), i);
		ifx_httpdWrite(wp, T("document.tF0.ssid.value = "
			"document.tF0.ssid%d.value;\n"), i + 1);
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\tdocument.tF0.wpsApPin.value = document.tF0.wpsApPin_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp, T("document.tF0.wpsPinLockout.value = "
			"document.tF0.wpsPinLockout_%d.value;\n"), i);
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\tif (document.tF0.wpsEnable_%d.value == 1)\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t\tdocument.tF0.wpsEnable.checked = true;\n"));
		ifx_httpdWrite(wp, T("\t\t\telse\n"));
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t\tdocument.tF0.wpsEnable.checked = false;\n"));
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\tif ((document.tF0.wpsIntRegsSupport_%d.value == 1) ||\n"
				"\t\t\t(document.tF0.wpsProxySupport_%d.value == 1) ||\n"
				"\t\t\t(document.tF0.wpsEnrolleeSupport_%d.value == 1))\n\t\t\t{\n"
				"\t\t\tdocument.tF0.wpsEnable.checked = true;\n}"),
			       i, i, i);
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\telse {\n\t\t\t\tdocument.tF0.wpsEnable.checked = false;\n\t\t\t}\n"));
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\tif (document.tF0.wpsEnrolleeSupport_%d.value == 1)\n"
				"\t\t\t\tdocument.tF0.wpsEnrolleeSupport.checked = true;\n"
				"\t\t\telse\n\t\t\t\tdocument.tF0.wpsEnrolleeSupport.checked = false;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\tif (document.tF0.wpsIntRegsSupport_%d.value == 1)\n"
				"\t\t\t\tdocument.tF0.wpsIntRegsSupport.checked = true;\n"
				"\t\t\telse\n\t\t\tdocument.tF0.wpsIntRegsSupport.checked = false;\n"),
			       i);
		ifx_httpdWrite(wp, T("if (document.tF0.wpsProxySupport_%d.value == 1)\n"
			"document.tF0.wpsProxySupport.checked = true;\nelse\n"
			"document.tF0.wpsProxySupport.checked = false;\n"), i);
		if (ltq_mapi_get_wlan_vendor(wlMain[i].radioCpeId, IFX_F_DEFAULT) !=
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			ifx_httpdWrite(wp,
		       T("\tdocument.tF0.wpsStateConfig.disabled = false;\n"));
			ifx_httpdWrite(wp, T("if (document.tF0.wpsState_%d.value == 1)\n{\n"
				"document.tF0.wpsStateConfig.checked = true;\n"
				"document.tF0.wpsStateNonConfig.checked = false;\n}\n"), i);
			ifx_httpdWrite(wp,
				T("else\n{\ndocument.tF0.wpsStateConfig.checked = false;\n"
				"document.tF0.wpsStateNonConfig.checked = true;\n}\n"));
			ifx_httpdWrite(wp,
		       T("\tdocument.tF0.wpsStateConfig.disabled = true;\n"));
		} else {
			ifx_httpdWrite(wp,
		       T("\tdocument.tF0.wpsStateConfigWave.disabled = false;\n"));
			ifx_httpdWrite(wp,
				T("if (document.tF0.wpsState_%d.value == 2)\n\t\t\t{\n"
				"document.tF0.wpsStateConfigWave.checked = true;\n}\n"), i);
			ifx_httpdWrite(wp,
				T("else\n\t\t\t{\n"
				"document.tF0.wpsStateConfigWave.checked = false;\n}\n"));
			ifx_httpdWrite(wp,
		       T("\tdocument.tF0.wpsStateConfigWave.disabled = true;\n"));
		}

		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.macContrlMode.value = document.tF0.macContrlMode_%d.value;\n"), i);
		ifx_httpdWrite(wp,
			T("document.tF0.wlBeacon.value = document.tF0.wlBeacon_%d.value;\n"), i);
		ifx_httpdWrite(wp,
			T("document.tF0.wlEncr.value = document.tF0.wlEncr_%d.value;\n"), i);
		ifx_httpdWrite(wp,
			T("document.tF0.wlAuth.value = document.tF0.wlAuth_%d.value;\n"), i);
		ifx_httpdWrite(wp,
			T("document.tF0.hiddenSsid.value = document.tF0.hiddenSsid_%d.value;\n"), i);

		if (ltq_mapi_get_wlan_vendor(wlMain[i].radioCpeId, IFX_F_DEFAULT) ==
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			ifx_httpdWrite(wp, T("document.tF0.wpsIntRegsSupport.disabled = true;\n"));
			if (i == 0) {
				ifx_httpdWrite(wp, T("document.tF0.wpsEnable.disabled = false;\n"));
				ifx_httpdWrite(wp, T("document.tF0.wpsEnrolleeSupport.disabled = false;\n"));
	//			ifx_httpdWrite(wp, T("document.tF0.wpsIntRegsSupport.disabled = false;\n"));
				ifx_httpdWrite(wp, T("document.tF0.wpsProxySupport.disabled = false;\n"));
				ifx_httpdWrite(wp, T("document.tF0.wpsEpMacList.disabled = false;\n"));
				ifx_httpdWrite(wp, T("document.tF0.wpsPin.disabled = false;\n"));
				ifx_httpdWrite(wp, T("document.tF0.wpsPinLockout.disabled = false;\n"));
			} else {
				ifx_httpdWrite(wp, T("document.tF0.wpsEnable.disabled = true;\n"));
				ifx_httpdWrite(wp, T("document.tF0.wpsEnrolleeSupport.disabled = true;\n"));
	//			ifx_httpdWrite(wp, T("document.tF0.wpsIntRegsSupport.disabled = true;\n"));
				ifx_httpdWrite(wp, T("document.tF0.wpsProxySupport.disabled = true;\n"));
				ifx_httpdWrite(wp, T("document.tF0.wpsEpMacList.disabled = true;\n"));
				ifx_httpdWrite(wp, T("document.tF0.wpsPin.disabled = true;\n"));
				ifx_httpdWrite(wp, T("document.tF0.wpsPinLockout.disabled = true;\n"));
			}
			ifx_httpdWrite(wp,
		       T("\tdocument.tF0.wpsStateNonConfig.disabled = true;\n"));
		} else {
			ifx_httpdWrite(wp, T("document.tF0.wpsIntRegsSupport.disabled = false;\n"));
		}
		ifx_httpdWrite(wp, T("\t\t\tbreak;\n"));
	}
	ifx_httpdWrite(wp, T("\t\t}\n"));

	ifx_httpdWrite(wp, T("\tif (document.tF0.wpsApPin.value < 10000)\n"));
	ifx_httpdWrite(wp,
		       T
		       ("\t\tdocument.tF0.wpsApPin.value = \"0000\"+document.tF0.wpsApPin.value;\n"));
	ifx_httpdWrite(wp,
		       T("\telse if (document.tF0.wpsApPin.value < 100000)\n"));
	ifx_httpdWrite(wp,
		       T
		       ("\t\tdocument.tF0.wpsApPin.value = \"000\"+document.tF0.wpsApPin.value;\n"));
	ifx_httpdWrite(wp,
		       T
		       ("\telse if (document.tF0.wpsApPin.value < 1000000)\n"));
	ifx_httpdWrite(wp,
		       T
		       ("\t\tdocument.tF0.wpsApPin.value = \"00\"+document.tF0.wpsApPin.value;\n"));
	ifx_httpdWrite(wp,
		       T
		       ("\telse if (document.tF0.wpsApPin.value < 10000000)\n"));
	ifx_httpdWrite(wp,
		       T
		       ("\t\tdocument.tF0.wpsApPin.value = \"0\"+document.tF0.wpsApPin.value;\n"));
	ifx_httpdWrite(wp, T("\tdocument.tF0.wpsApPin.disabled = true;\n"));

LTQ_Handler:
	IFX_MEM_FREE(wlMain);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_update_wps_page", "");
	return ret;
}

/**

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void ltq_get_ap_index_list(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 i, nSupportedVap = 0, firstVapIndex = 0;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_ap_index_list", "");

#if defined(CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS)
	nSupportedVap =
	    g_wlCaps[0].maxVAPSupported + g_wlCaps[1].maxVAPSupported;
	firstVapIndex = 3;
#else
	nSupportedVap = g_wlCaps[0].maxVAPSupported;
	firstVapIndex = 2;
#endif
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_ap_index_list",
		       "number of supported VAP: %d, firstVapIndex: %d",
		       nSupportedVap, firstVapIndex);
	ifx_httpdWrite(wp, T("\tswitch (apIndex)\n\t{\n"));
	for (i = firstVapIndex; i <= nSupportedVap; i++) {
		ifx_httpdWrite(wp, T("\t\tcase %d:\n"), i);
		ifx_httpdWrite(wp, T("\t\t\tdocument.tF0.ap_index.value=\"%d\";\n"), i-1);
		ifx_httpdWrite(wp, T("\t\t\tbreak;\n"));
	}
	ifx_httpdWrite(wp, T("\t\tdefault:\n"));
	ifx_httpdWrite(wp, T("\t\t\talert(\"Invalid AP index. Range\");\n"));
	ifx_httpdWrite(wp, T("\t\t\treturn false;\n"));
	ifx_httpdWrite(wp, T("\t}\n"));

	return;
}

/**

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void ltq_load_global_config(int eid, httpd_t wp, int argc, char_t ** argv)
{
	IFX_MAPI_WLAN_MainCfg *wlMain = NULL;
	IFX_MAPI_WLAN_SecCfg *wlSec = NULL;
	IFX_MAPI_WLAN_PhyCfg	*wlPhyCfg = NULL;
	uint32 i = 0, j = 0, numPhyEntries = 0, numMainEntries = 0;
	char8 *name = NULL, *cpeId = NULL;
	int32 sumMinResStaRadio1 = 0, sumMinResStaRadio2 = 0;
	LTQ_MAPI_WLAN_Feature	wlanFeatSupp = LTQ_MAPI_WLAN_FEATURE_NONE;
	IFX_MAPI_WLAN_Capability wlCaps;
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	IFX_MAPI_WLAN_Capability wlCapsSec;
#endif
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_load_global_config", "");

	/* parse arguments passed from web page */
	if (ifx_httpd_parse_args(argc, argv, T("%s,%s"), &name, &cpeId) < 1) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_load_global_config", "");
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_load_global_config",
		"g_flagConfigLoaded = %d", g_flagConfigLoaded);

	/*
	 * determine the supported capabilites
	*/
	if (ifx_mapi_get_wlan_capability(&wlCaps, IFX_F_DEFAULT)
		!= IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get the device capabilities\n\r"));
		return;
	}

	ifx_httpdWrite(wp, T("<input type='hidden' name='wlan_init_complete_0' "
		"value='%d'>\n"), wlCaps.wlanCapValid);

#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	if (ifx_mapi_get_wlan_sec_capability(&wlCapsSec, IFX_F_DEFAULT)
		!= IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get the secondary device capabilities\n\r"));
		return;
	}
	ifx_httpdWrite(wp, T("<input type='hidden' name='wlan_init_complete_1' "
		"value='%d'>\n"), wlCapsSec.wlanCapValid);
#endif				/* CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS */

	if (ifx_mapi_get_all_wlan_phy_config
		((uint32 *) &numPhyEntries, &wlPhyCfg,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get all wlan phy config\n"));
		goto IFX_Handler;
	}

	/*
		we pass flag IFX_F_RESET_WEB_CFG to indicate to MAPI that main
		config has been read from web
	*/
	if (ifx_mapi_get_all_wlan_main_config((uint32 *) &numMainEntries, &wlMain,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get all wlan main config\n"));
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_load_global_config", "numEntries: %d", numMainEntries);

	if (ifx_mapi_get_all_wlan_security_config((uint32 *) &gNumEntries, &wlSec,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400,
			T("Failed to get the complete security configuration\n\r"));
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_load_global_config", "numEntries: %d", gNumEntries);

	/* store vendor information per vap in hidden variable */
	ifx_httpdWrite(wp, T("<input type='hidden' name='wlan_vendor_vap' value=''>\n"));
	ifx_httpdWrite(wp, T("<input type='hidden' name='wlan_feature_autococ' value=''>\n"));
	ifx_httpdWrite(wp, T("<input type='hidden' name='wlan_feature_netmodevap' value=''>\n"));
	ifx_httpdWrite(wp, T("<input type='hidden' name='wlan_feature_80211ac' value=''>\n"));
	for (i = 0; i < numMainEntries; i++) {
		switch (ltq_mapi_get_wlan_vendor(wlMain[i].radioCpeId, IFX_F_DEFAULT)) {
		case LTQ_MAPI_WLAN_VENDOR_WAVE300:
			ifx_httpdWrite(wp, T("<input type='hidden' name='wlan_vendor_vap_%d' "
				"value='%s'>\n"), i, "LTQ_MAPI_WLAN_VENDOR_WAVE300");
			break;
		case LTQ_MAPI_WLAN_VENDOR_QCA:
			ifx_httpdWrite(wp, T("<input type='hidden' name='wlan_vendor_vap_%d' "
				"value='%s'>\n"), i, "LTQ_MAPI_WLAN_VENDOR_QCA");
			break;
		default:
			ifx_httpdWrite(wp, T("<input type='hidden' name='wlan_vendor_vap_%d' "
				"value='%s'>\n"), i, "LTQ_MAPI_WLAN_VENDOR_NONE");
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_load_global_config","unknown vendor");
			break;
		}

		wlanFeatSupp = ltq_mapi_get_wlan_supported_features(
			wlMain[i].radioCpeId, IFX_F_DEFAULT);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_load_global_config",
			"wlanFeatSupp: 0x%x", wlanFeatSupp);
		if (wlanFeatSupp & LTQ_MAPI_WLAN_FEATURE_AUTOCOC) {
			ifx_httpdWrite(wp, T("<input type='hidden' name='wlan_feature_autococ_%d' "
				"value='1'>\n"), i);
		} else {
			ifx_httpdWrite(wp, T("<input type='hidden' name='wlan_feature_autococ_%d' "
				"value='0'>\n"), i);
		}
		if (wlanFeatSupp & LTQ_MAPI_WLAN_FEATURE_NETMODE_PER_VAP) {
			ifx_httpdWrite(wp, T("<input type='hidden' name='wlan_feature_netmodevap_%d' "
				"value='1'>\n"), i);
		} else {
			ifx_httpdWrite(wp, T("<input type='hidden' name='wlan_feature_netmodevap_%d' "
				"value='0'>\n"), i);
		}
		if (wlanFeatSupp & LTQ_MAPI_WLAN_FEATURE_80211AC) {
			ifx_httpdWrite(wp, T("<input type='hidden' name='wlan_feature_80211ac_%d' "
				"value='1'>\n"), i);
		} else {
			ifx_httpdWrite(wp, T("<input type='hidden' name='wlan_feature_80211ac_%d' "
				"value='0'>\n"), i);
		}
		if (wlanFeatSupp & LTQ_MAPI_WLAN_FEATURE_WDS) {
			ifx_httpdWrite(wp, T("<input type='hidden' name='wlan_feature_wds_%d' "
				"value='1'>\n"), i);
		} else {
			ifx_httpdWrite(wp, T("<input type='hidden' name='wlan_feature_wds_%d' "
				"value='0'>\n"), i);
		}
	}

#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	gNumVapRadio1 = gNumVapRadio2 = 0;
	/* calculate VAPs per RADIO */
	for (i = 0; i < numMainEntries; i++) {
		if (wlMain[i].radioCpeId == 1)
			gNumVapRadio1++;
		else if (wlMain[i].radioCpeId == 2)
			gNumVapRadio2++;
		else
			IFX_MAPI_DEBUG(fd,"/tmp/ltq_load_global_config",
			"Illegal radioCpeId");
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_load_global_config",
		"gNumVapRadio1: %d, gNumVapRadio2: %d", gNumVapRadio1, gNumVapRadio2);
#endif				/* #ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS */
	/* set flag that configuration is stored in global arrays */
	g_flagConfigLoaded = 1;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_load_global_config", "name: %s", name);
	if (name) {
		if (!gstrcmp(name, T("ALL"))) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_load_global_config", "");
			/* only get the dynamical information */
			if (ifx_mapi_get_wlan_dyn_phy_config
			    (&g_wlPhy[0], IFX_F_DEFAULT) != IFX_SUCCESS) {
				ifx_httpdError(wp, 400,
					T("Failed to get dynamic wlan radio configuration\n"));
				goto IFX_Handler;
			}
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
			if (ifx_mapi_get_wlan_dyn_phy_config
			    (&g_wlPhy[1], IFX_F_DEFAULT) != IFX_SUCCESS) {
				ifx_httpdError(wp, 400,
					T("Failed to get wlan radio configuration\n"));
				goto IFX_Handler;
			}
#endif				/* CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS */
			for (i = 0; i < numMainEntries; i++) {
				if (ifx_mapi_get_wlan_dyn_vap_info
				    (&wlMain[i], IFX_F_DEFAULT)
				    != IFX_SUCCESS) {
					ifx_httpdError(wp, 400,
						T("Failed to get wlan dyn vap info\n"));
					goto IFX_Handler;
				}
			}
		} else if (!gstrcmp(name, T("RADIO_DYN"))) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_load_global_config", "");
			g_idx = atoi(cpeId);
			g_idx--;
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
			if ((g_idx < 0) || (g_idx >= 2))
#else
			if ((g_idx < 0) || (g_idx >= 1))
#endif
			{
				ifx_httpdError(wp, 400, T("Radio index out of range\n"));
				goto IFX_Handler;
			}

#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
			if (!g_idx) {
				ifx_httpdWrite(wp, T("<input type='hidden' name='numVap' "
					"value='%d'>\n"), gNumVapRadio1);
			}
			else {
				ifx_httpdWrite(wp, T("<input type='hidden' name='numVap' "
					"value='%d'>\n"), gNumVapRadio2);
			}
#else
			ifx_httpdWrite(wp, T("<input type='hidden' name='numVap' "
				"value='%d'>\n"), gNumEntries);
#endif

			j = 0;
			for (i = 0; i < numMainEntries; i++) {
				if (wlMain[i].radioCpeId == (g_idx+1)) {
					ifx_httpdWrite(wp,
						T("<input type='hidden' name='beaconType_%d' value='%d'>\n"),
						j, g_wlSec[i].beaconType);
					ifx_httpdWrite(wp,
						T("<input type='hidden' name='authType_%d' value='%d'>\n"),
						j, g_wlSec[i].wlAuth);
					ifx_httpdWrite(wp,
						T("<input type='hidden' name='encrType_%d' value='%d'>\n"),
						j, g_wlSec[i].wlEncr);
					j++;
				}
			}

			/* only get the dynamical information */
			if (ifx_mapi_get_wlan_dyn_phy_config
			    (&g_wlPhy[g_idx], IFX_F_DEFAULT)
			    != IFX_SUCCESS) {
				ifx_httpdError(wp, 400,
					T("Failed to get dynamic wlan radio configuration\n"));
				goto IFX_Handler;
			}
		} else if (!gstrcmp(name, T("VAP_DYN"))) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_load_global_config", "");
			for (i = 0; i < numMainEntries; i++) {
				if (ifx_mapi_get_wlan_dyn_vap_info
				    (&wlMain[i], IFX_F_DEFAULT)
				    != IFX_SUCCESS) {
					ifx_httpdError(wp, 400,
						T("Failed to get wlan dyn vap info\n"));
					goto IFX_Handler;
				}
			}
		}
		else if (!gstrcmp(name, T("MAX_WLAN_CLIENTS"))) {
			ifx_httpdWrite(wp,
			       T("<input type='hidden' name='maxWlanClients_1' value='%d'>\n"),
			       wlCaps.maxWlanClients);
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
			ifx_httpdWrite(wp,
			       T("<input type='hidden' name='maxWlanClients_2' value='%d'>\n"),
			       wlCapsSec.maxWlanClients);
#endif
			for (i = 0; i < numMainEntries; i++) {
				if (wlMain[i].radioCpeId == 1)
					sumMinResStaRadio1 += wlMain[i].minResSta;
				else
					sumMinResStaRadio2 += wlMain[i].minResSta;
				ifx_httpdWrite(wp,
				       T
				       ("<input type='hidden' name='minReservedClients_%d' value='%d'>\n"),
				       i, wlMain[i].minResSta);
			}
			ifx_httpdWrite(wp,
			       T
			       ("<input type='hidden' name='sumMinReservedClientsRadio1' value='%d'>\n"),
			       sumMinResStaRadio1);
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
			ifx_httpdWrite(wp,
			       T
			       ("<input type='hidden' name='sumMinReservedClientsRadio2' value='%d'>\n"),
			       sumMinResStaRadio2);
#endif
		}
		else if (!gstrcmp(name, T("WPS_PAGE"))) {
			ifx_httpdWrite(wp,
			       T
			       ("<input type='hidden' name='macContrlMode' value=''>\n"));
			for (i = 0; i < gNumEntries; i++) {
				ifx_httpdWrite(wp,
				       T
				       ("<input type='hidden' name='macContrlMode_%d' value='%d'>\n"),
				       i, g_wlSec[i].macAddrCntrlEna);
			}
		}
	}
#ifdef CONFIG_FEATURE_LTQ_WIRELESS_VB
	ltq_vb_load_global_config(eid, wp, argc, argv);
#endif

IFX_Handler:
	IFX_MEM_FREE(wlPhyCfg);
	IFX_MEM_FREE(wlMain);
	IFX_MEM_FREE(wlSec);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_load_global_config", "");
	return;
}

/**

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void ltq_update_settings_for_vap(int eid, httpd_t wp, int argc, char_t ** argv)
{
	uint32 i = 0, numEntries = 0;
	IFX_MAPI_WLAN_MainCfg *wlMain = NULL;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_update_settings_for_vap", "gNumEntries: %d",
		gNumEntries);
	/*
		we pass flag IFX_F_RESET_WEB_CFG to indicate to MAPI that main
		config has been read from web
	*/
	if (ifx_mapi_get_all_wlan_main_config((uint32 *) &numEntries, &wlMain,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get all wlan main config\n"));
		goto LTQ_Handler;
	}

	for (i = 0; i < gNumEntries; i++) {
		ifx_httpdWrite(wp, T("case %d:\n"), i);
		ifx_httpdWrite(wp, T("document.tF0.ap_index.value=\"%d\";\n"), i);
		ifx_httpdWrite(wp, T("document.tF0.radioCpeId.value=\"%d\";\n"),
			wlMain[i].radioCpeId);
		ifx_httpdWrite(wp, T("document.tF0.wlan_vendor_vap.value = "
			"document.tF0.wlan_vendor_vap_%d.value;\n"), i);
		ifx_httpdWrite(wp, T("document.tF0.wlan_feature_netmodevap.value = "
			"document.tF0.wlan_feature_netmodevap_%d.value;\n"), i);
		ifx_httpdWrite(wp, T("document.tF0.ssid.value = "
			"document.tF0.ssid%d.value;\n"), i+1);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_update_settings_for_vap",
			"radioCpeId: %d", wlMain[i].radioCpeId);
		if (ltq_mapi_get_wlan_supported_features(wlMain[i].radioCpeId,
			IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_NETMODE_PER_VAP) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_update_settings_for_vap", "");
			ifx_httpdWrite(wp, T("document.tF0.netModeVap.value = "
				"document.tF0.netModeVap%d.value;\n"), i+1);
		} /* LTQ_WAVE_NETWORK_MODE_PER_VAP */
		ifx_httpdWrite(wp, T("document.tF0.beaconType.value  = "
			"document.tF0.beaconType%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.authType.value = "
			"document.tF0.authType%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.encrType.value = "
			"document.tF0.encrType%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("if (document.tF0.pskType%d.value == 1) {\n"), i+1);
		ifx_httpdWrite(wp, T("   document.tF0.pskType.checked = true;\n"));
		ifx_httpdWrite(wp, T("   document.tF0.preSharedKey.value = "
			"document.tF0.preSharedKey%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("   document.tF0.preSharedKeyText.value = "
			"document.tF0.preSharedKey%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("   document.tF0.passPhrase.value = \"\";\n"));
		ifx_httpdWrite(wp, T("   document.tF0.passPhraseText.value = \"\";\n"));
		ifx_httpdWrite(wp, T("   document.tF0.passPhrase.disabled = true;\n}\n"));
		ifx_httpdWrite(wp, T("else {\n"));
		ifx_httpdWrite(wp, T("   document.tF0.pskType.checked = false;\n"));
		ifx_httpdWrite(wp, T("   document.tF0.preSharedKey.value = \"\";\n"));
		ifx_httpdWrite(wp, T("   document.tF0.preSharedKeyText.value = \"\";\n"));
		ifx_httpdWrite(wp, T("   document.tF0.passPhrase.value = "
			"document.tF0.passPhrase%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("   document.tF0.passPhraseText.value = "
			"document.tF0.passPhrase%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("   document.tF0.preSharedKey.disabled = true;\n}\n"));
		ifx_httpdWrite(wp, T("updateAvailableOptions();\n"));
		ifx_httpdWrite(wp, T("document.tF0.keyIndex.value = "
			"document.tF0.keyIndex%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.encryptLevel.value = "
			"document.tF0.encrLevel%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.wepKeyType.value = "
			"document.tF0.wepKeyType%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.wepKey1.value = "
			"document.tF0.wepKey1_%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.wepKey2.value = "
			"document.tF0.wepKey2_%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.wepKey3.value = "
			"document.tF0.wepKey3_%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.wepKey4.value = "
			"document.tF0.wepKey4_%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.wepKey1Text.value = "
			"document.tF0.wepKey1_%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.wepKey2Text.value = "
			"document.tF0.wepKey2_%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.wepKey3Text.value = "
			"document.tF0.wepKey3_%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.wepKey4Text.value = "
			"document.tF0.wepKey4_%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.reAuthIntvl.value = "
			"document.tF0.reAuthIntvl%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.groupKeyIntvl.value = "
			"document.tF0.groupKeyIntvl%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.wpa2PreAuthEnable.value = "
			"document.tF0.wpa2PreAuthEnable%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.radiusIp1.value = "
			"document.tF0.radiusIp1_%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.radiusIp2.value = "
			"document.tF0.radiusIp2_%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.radiusIp3.value = "
			"document.tF0.radiusIp3_%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.radiusIp4.value = "
			"document.tF0.radiusIp4_%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.radiusPort.value = "
			"document.tF0.radiusPort%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.radiusSecret.value = "
			"document.tF0.radiusSecret%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("document.tF0.radiusSecretText.value = "
			"document.tF0.radiusSecret%d.value;\n"), i+1);
		ifx_httpdWrite(wp, T("break;\n"));
	}
LTQ_Handler:
	IFX_MEM_FREE(wlMain);
	return;
}

/**

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void ltq_update_settings_wmm(int eid, httpd_t wp, int argc, char_t ** argv)
{
	uint32 i = 0, numEntries = 0;
	IFX_MAPI_WLAN_MainCfg *wlMain = NULL;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_update_settings_wmm", "gNumEntries: %d",
       gNumEntries);
	/*
		we pass flag IFX_F_RESET_WEB_CFG to indicate to MAPI that main
		config has been read from web
	*/
	if (ifx_mapi_get_all_wlan_main_config((uint32 *) &numEntries, &wlMain,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get all wlan main config\n"));
		goto LTQ_Handler;
	}

	ifx_httpdWrite(wp, T("switch (document.tF0.apName.selectedIndex) {\n"));
	for (i = 0; i < gNumEntries; i++) {
		ifx_httpdWrite(wp, T("case %d:\n"), i);
		ifx_httpdWrite(wp, T("document.tF0.wlan_vendor_vap.value = "
			"document.tF0.wlan_vendor_vap_%d.value;\n"), i);
		ifx_httpdWrite(wp, T("document.tF0.wlan_feature_autococ.value = "
			"document.tF0.wlan_feature_autococ_%d.value;\n"), i);
		ifx_httpdWrite(wp, T("document.tF0.wlan_feature_netmodevap.value = "
			"document.tF0.wlan_feature_netmodevap_%d.value;\n"), i);
		ifx_httpdWrite(wp, T("document.tF0.apIndex.value=\"%d\";\n"), i);
		ifx_httpdWrite(wp, T("document.tF0.radioCpeId.value=\"%d\";\n"),
			wlMain[i].radioCpeId);
		ifx_httpdWrite(wp, T("document.tF0.ssid.value = "
			"document.tF0.ssid%d.value;\n"), i + 1);
		ifx_httpdWrite(wp,
			       T("if (document.tF0.wmmEnable_%d.value == 1)\n"),
			       i);
		ifx_httpdWrite(wp,
			       T("document.tF0.wmmEnable.checked = true;\n"));
		ifx_httpdWrite(wp, T("else\n"));
		ifx_httpdWrite(wp,
			       T("document.tF0.wmmEnable.checked = false;\n"));

		ifx_httpdWrite(wp,
			       T
			       ("if (document.tF0.uapsdEnable_%d.value == 1)\n"),
			       i);
		ifx_httpdWrite(wp,
			       T("document.tF0.uapsdEnable.checked = true;\n"));
		ifx_httpdWrite(wp, T("else\n"));
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.uapsdEnable.checked = false;\n"));

		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_cwMin_BE.value = document.tF0.ap_cwMin_BE_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_cwMax_BE.value = document.tF0.ap_cwMax_BE_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_aifsn_BE.value = document.tF0.ap_aifsn_BE_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_txop_BE.value  = document.tF0.ap_txop_BE_%d.value;\n"),
			       i);

		ifx_httpdWrite(wp,
			       T
			       ("if(document.tF0.ap_admCntrl_BE_%d.value == 1)\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_admCntrl_BE.checked = true;\n"));
		ifx_httpdWrite(wp, T("else\n"));
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_admCntrl_BE.checked = false;\n"));

		ifx_httpdWrite(wp,
			       T
			       ("if(document.tF0.ap_ackPolicy_BE_%d.value == 1)\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_ackPolicy_BE.checked = true;\n"));
		ifx_httpdWrite(wp, T("else\n"));
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_ackPolicy_BE.checked = false;\n"));

		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_cwMin_BK.value = document.tF0.ap_cwMin_BK_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_cwMax_BK.value = document.tF0.ap_cwMax_BK_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_aifsn_BK.value = document.tF0.ap_aifsn_BK_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_txop_BK.value  = document.tF0.ap_txop_BK_%d.value;\n"),
			       i);

		ifx_httpdWrite(wp,
			       T
			       ("if(document.tF0.ap_admCntrl_BK_%d.value == 1)\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_admCntrl_BK.checked = true;\n"));
		ifx_httpdWrite(wp, T("else\n"));
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_admCntrl_BK.checked = false;\n"));

		ifx_httpdWrite(wp,
			       T
			       ("if(document.tF0.ap_ackPolicy_BK_%d.value == 1)\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_ackPolicy_BK.checked = true;\n"));
		ifx_httpdWrite(wp, T("else\n"));
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_ackPolicy_BK.checked = false;\n"));

		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_cwMin_VI.value = document.tF0.ap_cwMin_VI_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_cwMax_VI.value = document.tF0.ap_cwMax_VI_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_aifsn_VI.value = document.tF0.ap_aifsn_VI_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_txop_VI.value  = document.tF0.ap_txop_VI_%d.value;\n"),
			       i);

		ifx_httpdWrite(wp,
			       T
			       ("if(document.tF0.ap_admCntrl_VI_%d.value == 1)\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_admCntrl_VI.checked = true;\n"));
		ifx_httpdWrite(wp, T("else\n"));
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_admCntrl_VI.checked = false;\n"));

		ifx_httpdWrite(wp,
			       T
			       ("if(document.tF0.ap_ackPolicy_VI_%d.value == 1)\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_ackPolicy_VI.checked = true;\n"));
		ifx_httpdWrite(wp, T("else\n"));
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_ackPolicy_VI.checked = false;\n"));

		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_cwMin_VO.value      = document.tF0.ap_cwMin_VO_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_cwMax_VO.value      = document.tF0.ap_cwMax_VO_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_aifsn_VO.value      = document.tF0.ap_aifsn_VO_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_txop_VO.value       = document.tF0.ap_txop_VO_%d.value;\n"),
			       i);

		ifx_httpdWrite(wp,
			       T
			       ("if(document.tF0.ap_admCntrl_VO_%d.value == 1)\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_admCntrl_VO.checked = true;\n"));
		ifx_httpdWrite(wp, T("else\n"));
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_admCntrl_VO.checked = false;\n"));

		ifx_httpdWrite(wp,
			       T
			       ("if(document.tF0.ap_ackPolicy_VO_%d.value == 1)\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_ackPolicy_VO.checked = true;\n"));
		ifx_httpdWrite(wp, T("else\n"));
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.ap_ackPolicy_VO.checked = false;\n"));

		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_cwMin_BE.value = document.tF0.sta_cwMin_BE_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_cwMax_BE.value = document.tF0.sta_cwMax_BE_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_aifsn_BE.value = document.tF0.sta_aifsn_BE_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_txop_BE.value  = document.tF0.sta_txop_BE_%d.value;\n"),
			       i);

		ifx_httpdWrite(wp,
			       T
			       ("if(document.tF0.sta_ackPolicy_BE_%d.value == 1)\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_ackPolicy_BE.checked = true;\n"));
		ifx_httpdWrite(wp, T("else\n"));
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_ackPolicy_BE.checked = false;\n"));

		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_cwMin_BK.value = document.tF0.sta_cwMin_BK_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_cwMax_BK.value = document.tF0.sta_cwMax_BK_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_aifsn_BK.value = document.tF0.sta_aifsn_BK_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_txop_BK.value  = document.tF0.sta_txop_BK_%d.value;\n"),
			       i);

		ifx_httpdWrite(wp,
			       T
			       ("if(document.tF0.sta_ackPolicy_BK_%d.value == 1)\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_ackPolicy_BK.checked = true;\n"));
		ifx_httpdWrite(wp, T("else\n"));
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_ackPolicy_BK.checked = false;\n"));

		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_cwMin_VI.value = document.tF0.sta_cwMin_VI_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_cwMax_VI.value = document.tF0.sta_cwMax_VI_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_aifsn_VI.value = document.tF0.sta_aifsn_VI_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_txop_VI.value  = document.tF0.sta_txop_VI_%d.value;\n"),
			       i);

		ifx_httpdWrite(wp,
			       T
			       ("if(document.tF0.sta_ackPolicy_VI_%d.value == 1)\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_ackPolicy_VI.checked = true\n"));
		ifx_httpdWrite(wp, T("else\n"));
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_ackPolicy_VI.checked = false\n"));

		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_cwMin_VO.value = document.tF0.sta_cwMin_VO_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_cwMax_VO.value = document.tF0.sta_cwMax_VO_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_aifsn_VO.value = document.tF0.sta_aifsn_VO_%d.value;\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_txop_VO.value  = document.tF0.sta_txop_VO_%d.value;\n"),
			       i);

		ifx_httpdWrite(wp,
			       T
			       ("if( document.tF0.sta_ackPolicy_VO_%d.value == 1)\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_ackPolicy_VO.checked = true\n"));
		ifx_httpdWrite(wp, T("else\n"));
		ifx_httpdWrite(wp,
			       T
			       ("document.tF0.sta_ackPolicy_VO.checked = false\n"));

		ifx_httpdWrite(wp, T("break;\n"));
	}
	ifx_httpdWrite(wp, T("}\n"));
LTQ_Handler:
	IFX_MEM_FREE(wlMain);
	return;
}

/**

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void ltq_get_validation_before_wpsStart(int eid, httpd_t wp, int argc,
					char_t ** argv)
{
	uint32 i = 0;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_validation_before_wpsStart",
		       "gNumEntries: %d", gNumEntries);

	ifx_httpdWrite(wp, T("switch (document.tF0.apName.selectedIndex) {\n"));
	for (i = 0; i < gNumEntries; i++) {
		ifx_httpdWrite(wp, T("case %d:\n"), i);

		ifx_httpdWrite(wp,
			       T
			       ("if (document.tF0.wpsEnable_%d.value == 0) {\n"),
			       i);
		ifx_httpdWrite(wp,
			       T
			       ("alert(\"WPS must be enabled before starting WPS process!\");\n"));
		ifx_httpdWrite(wp, T("return false;\n}\n"));

		ifx_httpdWrite(wp, T("break;\n"));
	}
	ifx_httpdWrite(wp, T("}\n"));
	return;
}

void ltq_set_date(int eid, httpd_t wp, int argc, char_t ** argv)
{
	struct timeval tv;

	gettimeofday(&tv, NULL);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_date", "%d:%d",
		       (int32) tv.tv_sec, (int32) tv.tv_usec);

	return;
}

/**
   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void
ltq_wlan_get_all_wds_config(int eid, httpd_t wp, int argc, char_t ** argv)
{
	LTQ_MAPI_WLAN_WDS_Cfg		*wlWdsCfg = NULL;
	IFX_MAPI_WLAN_MAC_Control	*wlWdsPeerMacList = NULL;
	IFX_MAPI_WLAN_WEP_Key		wlWepKeys[IFX_MAPI_NUM_WEP_KEYS];
	int32						i, j;
	uint32						mainCpeId = 0, nWdsPeerMac = 0, numEntries = 0;
	char_t						quotedString[2*IFX_MAPI_WEP_KEY_MAX_LEN];

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_all_wds_config", "");

	if (ltq_mapi_get_all_wlan_wds_config(&numEntries, &wlWdsCfg, IFX_F_DEFAULT)
		!= IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get the complete WDS configuration\n\r"));
		goto LTQ_Handler;
	}

	ifx_httpdWrite(wp, T("<input type='hidden' name='wlan_feature_wds' "
		"value=''>\n"));
	ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"coexStatus_0\" "
		"value=\"%d\">\n"), g_wlPhy[0].phy11N.twentyFourtyCoex);
	ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"autoChanSel_0\" "
		"value=\"%d\">\n"), g_wlPhy[0].autoChannelEna);
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"coexStatus_1\" "
		"value=\"%d\">\n"), g_wlPhy[1].phy11N.twentyFourtyCoex);
	ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"autoChanSel_1\" "
		"value=\"%d\">\n"), g_wlPhy[1].autoChannelEna);
#endif

	/* store all wds parameters in hidden variables */
	for (i = 0; i < numEntries; i++) {
		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"wdsStatus_%d\" "
			"value=\"\">\n"), i);
		ifx_httpdWrite(wp, T("<script type=\"text/javascript\">"
			"document.tF0.wdsStatus_%d.value = %d;</script>\n"),
			i, wlWdsCfg[i].enable);

		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"wdsSecType_%d\" "
			"value=\"\">\n"), i);
		ifx_httpdWrite(wp, T("<script type=\"text/javascript\">"
			"document.tF0.wdsSecType_%d.value = %d;</script>\n"),
			i, wlWdsCfg[i].secMode);

		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"wdsWepKeyIdx_%d\" "
			"value=\"\">\n"), i);
		ifx_httpdWrite(wp, T("<script type=\"text/javascript\">"
			"document.tF0.wdsWepKeyIdx_%d.value = %d;</script>\n"),
			i, wlWdsCfg[i].peerAPKeyIdx);

		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"nWdsPeerMacEntries_%d\" "
			"value=\"\">\n"), i);
		ifx_httpdWrite(wp, T("<script type=\"text/javascript\">"
			"document.tF0.nWdsPeerMacEntries_%d.value = %d;</script>\n"),
			i, wlWdsCfg[i].nPeerAPs);

		/* CPE ID of WDS object is the same as CPEID of main object */
		mainCpeId = wlWdsCfg[i].iid.cpeId.Id;
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_all_wds_config", "mainCpeId: %d",
			mainCpeId);
		/*
		 * get the mac filter configuration
		 */
		if (ltq_mapi_get_all_wlan_wds_peer_mac(mainCpeId, &nWdsPeerMac,
			&wlWdsPeerMacList, IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,T("Failed to get wds peer mac table"));
			goto LTQ_Handler;
		}
		/* store the number of MAC filter entries in global variable */
		gWdsPeerMacCount[i] = nWdsPeerMac;
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_all_wds_config",
			"MAC address entries: %d", nWdsPeerMac);

		if (nWdsPeerMac <= LTQ_MAX_NUM_MAC_FILTER_ENTRIES)
			memcpy(&g_wlWdsPeerMacList[i][0], wlWdsPeerMacList,
			       sizeof(IFX_MAPI_WLAN_MAC_Control) * nWdsPeerMac);

		for (j = 0; j < g_wlCaps[0].numMacCntrlEntries; j++) {
			ifx_httpdWrite(wp, T("<input type=\"hidden\" "
				"name=\"macAddr_%d_%d\" value=\"\">\n"), i + 1, j + 1);
			if (j < nWdsPeerMac) {
				IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_all_wds_config",
					"MAC address: %s", (wlWdsPeerMacList + j)->macAddr);
				ifx_httpdWrite(wp, T("<script type=\"text/javascript\">"
					"document.tF0.macAddr_%d_%d.value='%s';</script>\n"),
					i + 1, j + 1, (wlWdsPeerMacList + j)->macAddr);
			}
		}

		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"wepKey1_%d\" "
			"value=\"\">"), i);
		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"wepKey2_%d\" "
			"value=\"\">"), i);
		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"wepKey3_%d\" "
			"value=\"\">"), i);
		ifx_httpdWrite(wp, T("<input type=\"hidden\" name=\"wepKey4_%d\" "
			"value=\"\">"), i);
		/* get the wep key configuration */
		if (ifx_mapi_get_all_wlan_wep_keys(mainCpeId, wlWepKeys, IFX_F_DEFAULT)
			!= IFX_SUCCESS) {
			ifx_httpdError(wp, 400,T("Failed to get wep key configuration"));
			goto LTQ_Handler;
		}

		for (j = 0; j < IFX_MAPI_NUM_WEP_KEYS; j++) {
			/* single quote ' and double quote " in WEP key must be quoted */
			memset(quotedString, 0x00, sizeof(quotedString));
			ltq_wlan_add_quoting_2_string(wlWepKeys[j].wepKey, quotedString);
			ifx_httpdWrite(wp, T("<script type=\"text/javascript\">"
				"document.tF0.wepKey%d_%d.value='%s';</script>\n"),
				j + 1, i, quotedString);
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_all_wds_config",
				"wepKey%d: %s", j+1, wlWepKeys[j].wepKey);
		}

		IFX_MEM_FREE(wlWdsPeerMacList);
	}

LTQ_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_get_all_wds_config", "");
	IFX_MEM_FREE(wlWdsCfg);
	IFX_MEM_FREE(wlWdsPeerMacList);
	return;
}

/**
   This function gets information required to display the web page for "WLAN MAC
   Control" properly. It is called from wlan_mac_control.asp.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void ltq_wlan_wds_update_peer_mac_table(int eid, httpd_t wp, int argc,
		char_t ** argv)
{
	int32 i, j;
	IFX_MAPI_WLAN_MainCfg *wlMain = NULL;
	uint32	nMainEntries = 0;
	uint32 numMacCntrlEntries = 0;
	IFX_MAPI_WLAN_Capability wlCaps;
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	IFX_MAPI_WLAN_Capability wlCapsSec;
#endif

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_wds_update_peer_mac_table", "");

	if (ifx_mapi_get_wlan_capability(&wlCaps, IFX_F_DEFAULT) != 
		IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to get WLAN capabilities", __FUNCTION__, __LINE__);
#endif
		wlCaps.numMacCntrlEntries = LTQ_MAX_NUM_MAC_FILTER_ENTRIES;
	}
	numMacCntrlEntries = wlCaps.numMacCntrlEntries;

#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	if (ifx_mapi_get_wlan_sec_capability(&wlCapsSec, IFX_F_DEFAULT) != 
		IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to get secondary WLAN capabilities", 
			__FUNCTION__, __LINE__);
#endif
		wlCapsSec.numMacCntrlEntries = LTQ_MAX_NUM_MAC_FILTER_ENTRIES;
	}
	numMacCntrlEntries =
		((wlCapsSec.numMacCntrlEntries > wlCaps.numMacCntrlEntries) ?
		wlCapsSec.numMacCntrlEntries :
		wlCaps.numMacCntrlEntries);
#endif /* #ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS */
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_wds_update_peer_mac_table",
		"numMacCntrlEntries: %d", numMacCntrlEntries);

	if (ifx_mapi_get_all_wlan_main_config (&nMainEntries, &wlMain,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get all wlan main config\n"));
		goto IFX_Handler;
	}

	ifx_httpdWrite(wp, T("switch (document.tF0.apName.selectedIndex) {\n"));
	/* for all AP and VAP get the mode and */
	for (i = 0; i < nMainEntries; i++) {
		ifx_httpdWrite(wp, T("case %d:\n"), i);
		ifx_httpdWrite(wp,
			T("document.tF0.ssid.value = document.tF0.ssid%d.value;\n"), i + 1);
		ifx_httpdWrite(wp, T("\tdocument.tF0.apIndex.value = %d;\n"), i);
		ifx_httpdWrite(wp, T("\tdocument.tF0.wlan_vendor_vap.value = "
			"document.tF0.wlan_vendor_vap_%d.value;\n"), i);
		ifx_httpdWrite(wp, T("\tdocument.tF0.wlan_feature_wds.value = "
			"document.tF0.wlan_feature_wds_%d.value;\n"), i);
		ifx_httpdWrite(wp, T("document.tF0.radioCpeId.value=\"%d\";\n"),
			wlMain[i].radioCpeId);
		if (wlMain[i].radioCpeId == 1) {
			ifx_httpdWrite(wp, T("\tdocument.tF0.coexStatus.value = "
				"document.tF0.coexStatus_0.value;\n"));
			ifx_httpdWrite(wp, T("\tdocument.tF0.autoChanSel.value = "
				"document.tF0.autoChanSel_0.value;\n"));
		} else {
			ifx_httpdWrite(wp, T("\tdocument.tF0.coexStatus.value = "
				"document.tF0.coexStatus_1.value;\n"));
			ifx_httpdWrite(wp, T("\tdocument.tF0.autoChanSel.value = "
				"document.tF0.autoChanSel_1.value;\n"));
		}

		ifx_httpdWrite(wp, T("\tdocument.tF0.nWdsPeerMacEntries.value = "
			"document.tF0.nWdsPeerMacEntries_%d.value;\n"), i);

		ifx_httpdWrite(wp, T("\tif (document.tF0.wdsStatus_%d.value == 0) {\n"), i);
		for (j = 0; j < numMacCntrlEntries; j++)
			ifx_httpdWrite(wp, T("\tdocument.tF0.macAddr_%d.disabled = true;\n"),
				j + 1);
		ifx_httpdWrite(wp, T("\tdocument.tF0.wdsStatus.checked = false;\n}\n"));
		ifx_httpdWrite(wp, T("\telse {\n"));
		for (j = 0; j < numMacCntrlEntries; j++)
			ifx_httpdWrite(wp, T("\tdocument.tF0.macAddr_%d.disabled = false;\n"),
				j + 1);
		ifx_httpdWrite(wp, T("\tdocument.tF0.wdsStatus.checked = true;\n}\n"));
		ifx_httpdWrite(wp, T("\tdocument.tF0.wdsStatus.value = document.tF0.wdsStatus_%d.value;\n"), i);

		if (ltq_mapi_get_wlan_vendor(wlMain[i].radioCpeId, IFX_F_DEFAULT) ==
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
#if 0
			ifx_httpdWrite(wp, T("document.getElementById('wep').style.display = '';\n"));
			ifx_httpdWrite(wp, T("document.getElementById('wds_mac_table').style.display = '';\n"));
			ifx_httpdWrite(wp, T("document.getElementById('wdsSecurity').style.display = '';\n"));
#endif
			ifx_httpdWrite(wp, T("\tdocument.tF0.wdsStatus.disabled = false;\n"));
		} else {
#if 0
			ifx_httpdWrite(wp, T("document.getElementById('wep').style.display = 'none';\n"));
			ifx_httpdWrite(wp, T("document.getElementById('wds_mac_table').style.display = 'none';\n"));
			ifx_httpdWrite(wp, T("document.getElementById('wdsSecurity').style.display = 'none';\n"));
#endif
			ifx_httpdWrite(wp, T("\tdocument.tF0.wdsStatus.disabled = true;\n"));
		}

#if 0
		if (ltq_mapi_get_wlan_supported_features(wlMain[i].radioCpeId,
			IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_WDS) {
			ifx_httpdWrite(wp, T("\tdocument.tF0.wdsStatus.disabled = false;\n"));
		} else {
			ifx_httpdWrite(wp, T("\tdocument.tF0.wdsStatus.disabled = true;\n"));
		}
#endif

		ifx_httpdWrite(wp, T("\tdocument.tF0.wdsSecType.value = "
			"document.tF0.wdsSecType_%d.value;\n"), i);

		/* update wep */
		ifx_httpdWrite(wp, T("\tdocument.tF0.wdsWepKeyIdx.value = "
			"document.tF0.wdsWepKeyIdx_%d.value;\n"), i);
		ifx_httpdWrite(wp, T("\tdocument.tF0.wepKey1.value = "
			"document.tF0.wepKey1_%d.value;\n"), i);
		ifx_httpdWrite(wp, T("\tdocument.tF0.wepKey2.value = "
			"document.tF0.wepKey2_%d.value;\n"), i);
		ifx_httpdWrite(wp, T("\tdocument.tF0.wepKey3.value = "
			"document.tF0.wepKey3_%d.value;\n"), i);
		ifx_httpdWrite(wp, T("\tdocument.tF0.wepKey4.value = "
			"document.tF0.wepKey4_%d.value;\n"), i);
		ifx_httpdWrite(wp, T("\tdocument.tF0.wepKey1Text.value = "
			"document.tF0.wepKey1_%d.value;\n"), i);
		ifx_httpdWrite(wp, T("\tdocument.tF0.wepKey2Text.value = "
			"document.tF0.wepKey2_%d.value;\n"), i);
		ifx_httpdWrite(wp, T("\tdocument.tF0.wepKey3Text.value = "
			"document.tF0.wepKey3_%d.value;\n"), i);
		ifx_httpdWrite(wp, T("\tdocument.tF0.wepKey4Text.value = "
			"document.tF0.wepKey4_%d.value;\n"), i);

		IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_wds_update_peer_mac_table", "gWdsPeerMacCount[%d]: %d", i, gWdsPeerMacCount[i]);
		for (j = 0; j < gWdsPeerMacCount[i]; j++)
			ifx_httpdWrite(wp, T("\tdocument.tF0.macAddr_%d.value = "
				"document.tF0.macAddr_%d_%d.value;\n"), j + 1, i + 1, j + 1);

		for (j = gWdsPeerMacCount[i]; j < numMacCntrlEntries; j++)
			ifx_httpdWrite(wp, T("\tdocument.tF0.macAddr_%d.value = \"\";\n"), j + 1);

		for (j = 0; j < numMacCntrlEntries; j++) {
			if (j < gWdsPeerMacCount[i])
				ifx_httpdWrite(wp, T("\tdocument.tF0.rmid%d.disabled = false;\n"), j);
			else
				ifx_httpdWrite(wp, T("\tdocument.tF0.rmid%d.disabled = true;\n"), j);
		}
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
		/* if the number of support entries for MAC table is not the same
			on both radios, then some of the fields must be shown/hidden */
		if (wlCaps.numMacCntrlEntries != wlCapsSec.numMacCntrlEntries) {
			if (wlMain[i].radioCpeId == 1) {
				if (wlCaps.numMacCntrlEntries > wlCapsSec.numMacCntrlEntries) {
					for (j = wlCapsSec.numMacCntrlEntries; j < numMacCntrlEntries; j++) {
						ifx_httpdWrite(wp,
							T("document.getElementById('macAddr_%d').style.display = '';\n"), j);
					}	
				} else {
					for (j = wlCaps.numMacCntrlEntries; j < numMacCntrlEntries; j++) {
						ifx_httpdWrite(wp,
							T("document.getElementById('macAddr_%d').style.display = 'none';\n"), j);
					}	
				}
			} else {
				if (wlCapsSec.numMacCntrlEntries > wlCaps.numMacCntrlEntries) {
					for (j = wlCaps.numMacCntrlEntries; j < numMacCntrlEntries; j++) {
						ifx_httpdWrite(wp,
							T("document.getElementById('macAddr_%d').style.display = '';\n"), j);
					}	
				} else {
					for (j = wlCapsSec.numMacCntrlEntries; j < numMacCntrlEntries; j++) {
						ifx_httpdWrite(wp,
							T("document.getElementById('macAddr_%d').style.display = 'none';\n"), j);
					}	
				}
			}
		}
#endif /* #ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS */
		ifx_httpdWrite(wp, T("\tbreak;\n"));
	}
	ifx_httpdWrite(wp, T("default:\n"));
	ifx_httpdWrite(wp, T("alert(\"AP index out of range!\");\n"));
	ifx_httpdWrite(wp, T("break;\n}\n"));

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_wds_update_peer_mac_table", "");
	IFX_MEM_FREE(wlMain);
	return;
}

/**
   This function gets information required to display the web page for "WLAN MAC
   Control" properly. It is called from wlan_mac_control.asp.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void ltq_wlan_create_peer_mac_table(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 i = 0;
	uint32 numMacCntrlEntries = 0;
	IFX_MAPI_WLAN_Capability wlCaps;
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	IFX_MAPI_WLAN_Capability wlCapsSec;
#endif

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_create_peer_mac_table", "");

	if (ifx_mapi_get_wlan_capability(&wlCaps, IFX_F_DEFAULT) != 
		IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to get WLAN capabilities", __FUNCTION__, __LINE__);
#endif
		wlCaps.numMacCntrlEntries = LTQ_MAX_NUM_MAC_FILTER_ENTRIES;
	}
	numMacCntrlEntries = wlCaps.numMacCntrlEntries;

#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
	if (ifx_mapi_get_wlan_sec_capability(&wlCapsSec, IFX_F_DEFAULT) != 
		IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to get WLAN capabilities", __FUNCTION__, __LINE__);
#endif
		wlCapsSec.numMacCntrlEntries = LTQ_MAX_NUM_MAC_FILTER_ENTRIES;
	}
	numMacCntrlEntries =
		((wlCapsSec.numMacCntrlEntries > wlCaps.numMacCntrlEntries) ?
		wlCapsSec.numMacCntrlEntries :
		wlCaps.numMacCntrlEntries);
#endif
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_create_peer_mac_table",
		"numMacCntrlEntries: %d", numMacCntrlEntries);

	for (i = 0; i < numMacCntrlEntries; i++) {
		ifx_httpdWrite(wp, T("<tr id=\"macAddr_%d\">\n\t"), i);	/* open a row */
		if (i < gWdsPeerMacCount[0]) {
			ifx_httpdWrite(wp, T("<td><input name='macAddr_%d' value='%s'></td>\n\t"),
				i + 1, g_wlWdsPeerMacList[0][i].macAddr);
			ifx_httpdWrite(wp, T("<td><input type='checkbox' name='rmid%d' "
				"value=1></td>\n\t"), i);
		} else {
			ifx_httpdWrite(wp, T("<td><input name='macAddr_%d' value=''></td>\n\t"),
				i + 1);
			ifx_httpdWrite(wp, T("<td><input type='checkbox' name='rmid%d' "
				"value=1 disabled></td>\n\t"), i);
		}
		ifx_httpdWrite(wp, T("</tr>\n\n"));	/* closing a row */
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_create_peer_mac_table", "");
	return;
}

/**
   This function is called from wlan_wds_cfg.asp.

   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void ltq_prepare_wds_peer_mac_delete(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 i;

	for (i = 0; i < g_wlCaps[0].numMacCntrlEntries; i++) {
		ifx_httpdWrite(wp, T("if (document.tF0.rmid%d.checked == true) {\n"), i);
		ifx_httpdWrite(wp, T("\tnDelEntries++;\n}"));
	}
}

/**
   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void ltq_prepare_wds_peer_mac_add(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 i = 0, j = 0, k = 0;
	IFX_MAPI_WLAN_MainCfg *wlMain = NULL;
	uint32	nMainEntries = 0;
	char_t quotedSsid[2*IFX_MAPI_WLAN_SSID_LEN];

	/* validate correctness of MAC in each row */
	for (i = 0; i < g_wlCaps[0].numMacCntrlEntries; i++) {
		ifx_httpdWrite(wp, T("if(isNValidmac(document.tF0.macAddr_%d.value)) {\n\t"), i + 1);
		ifx_httpdWrite(wp, T ("alert(\"Please input valid MAC address to all fields\");\n"));
		ifx_httpdWrite(wp, T("return false;\n} "));
		ifx_httpdWrite(wp, T("else if ("
			"(document.tF0.macAddr_%d.value == \"00:00:00:00:00:00\") ||"
			"(document.tF0.macAddr_%d.value == \"FF:FF:FF:FF:FF:FF\") || "
			"(document.tF0.macAddr_%d.value == \"ff:ff:ff:ff:ff:ff\")) {\n"),
			i+1, i+1, i+1);
		ifx_httpdWrite(wp, T ("alert(\"Please input valid MAC address to all fields\");\n"));
		ifx_httpdWrite(wp, T("return false;\n} "));
		ifx_httpdWrite(wp, T("else if (!isBlank(document.tF0.macAddr_%d.value)){\n"), i + 1);
		ifx_httpdWrite(wp, T("nMacTableEntries++;\n}\n"));
	}

	if (ifx_mapi_get_all_wlan_main_config (&nMainEntries, &wlMain,
		IFX_F_DEFAULT | IFX_F_RESET_WEB_CFG) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get all wlan main config\n"));
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_prepare_wds_peer_mac_add",
		"nMainEntries: %d", nMainEntries);
	for (j = 0; j < nMainEntries; j ++) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_prepare_wds_peer_mac_add", "SSID: %s", wlMain[j].ssid);
		ifx_httpdWrite(wp, T("if(Number(document.tF0.apIndex.value) != %d) {\n"), j);
		for (i = 0; i < g_wlCaps[0].numMacCntrlEntries; i++) {
			ifx_httpdWrite(wp, T("\tif( !isBlank(document.tF0.macAddr_%d.value )) {\n"), i+1);
			for (k = 0; k < g_wlCaps[0].numMacCntrlEntries; k++) {
				ifx_httpdWrite(wp, T("\tif( (document.tF0.macAddr_%d.value == "
					"document.tF0.macAddr_%d_%d.value)) {\n"),
					i + 1, j + 1, k + 1);

				/* single quote ' and double quote " in SSID must be quoted */
				memset(quotedSsid, 0x00, sizeof(quotedSsid));
				ltq_wlan_add_quoting_2_string(wlMain[j].ssid, quotedSsid);
				ifx_httpdWrite(wp, T ("\t\talert(\"MAC address in field %d is "
					"already set in another AP/VAP\\nPlease remove it from that "
					"AP/VAP first (SSID: %s)\");\n"), i+1, quotedSsid);
				ifx_httpdWrite(wp, T("\t\treturn false;\n\t}\n"));

			}
			ifx_httpdWrite(wp, T("\n\t}\n"));
		}
		ifx_httpdWrite(wp, T("}\n"));
		ifx_httpdWrite(wp, T("else {\n"));
		for (i = 0; i < g_wlCaps[0].numMacCntrlEntries; i++) {
			ifx_httpdWrite(wp, T("\tif( (!isBlank(document.tF0.macAddr_%d.value))) {\n"), i+1);
			for (k = i + 1; k < g_wlCaps[0].numMacCntrlEntries; k++) {
				ifx_httpdWrite(wp, T("\tif( (document.tF0.macAddr_%d.value == "
					"document.tF0.macAddr_%d.value)) {\n"),
					i + 1, k + 1);

				ifx_httpdWrite(wp, T ("\t\talert(\"Same MAC address entered twice. "
					"Please check fields: %d and %d\");\n"), i+1, k+1);
				ifx_httpdWrite(wp, T("\t\treturn false;\n\t}\n"));
			}
			ifx_httpdWrite(wp, T("\n\t}\n"));
		}
		ifx_httpdWrite(wp, T("}\n"));
	}

IFX_Handler:
	IFX_MEM_FREE(wlMain);
	return;
}

/**
   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void ltq_update_on_wds_status_change(int eid, httpd_t wp, int argc, char_t ** argv)
{
	IFX_MAPI_WLAN_Capability wlCaps;
	int32	i = 0;

	if (ifx_mapi_get_wlan_capability(&wlCaps, IFX_F_DEFAULT) != 
		IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to get WLAN capabilities", __FUNCTION__, __LINE__);
#endif
		wlCaps.numMacCntrlEntries = LTQ_MAX_NUM_MAC_FILTER_ENTRIES;
	}

	ifx_httpdWrite(wp, T("if (document.tF0.wdsStatus.checked == true) {\n"));
	ifx_httpdWrite(wp, T("document.tF0.wdsStatus.value = 1;\n"));
	ifx_httpdWrite(wp, T("document.tF0.wdsSecType.disabled = false;\n"));
	ifx_httpdWrite(wp, T("document.tF0.wdsWepKeyIdx.disabled = false;\n"));
	ifx_httpdWrite(wp, T("document.tF0.wepKey1.disabled = false;\n"));
	ifx_httpdWrite(wp, T("document.tF0.wepKey1Text.disabled = false;\n"));
	ifx_httpdWrite(wp, T("document.tF0.wepKey2.disabled = false;\n"));
	ifx_httpdWrite(wp, T("document.tF0.wepKey2Text.disabled = false;\n"));
	ifx_httpdWrite(wp, T("document.tF0.wepKey3.disabled = false;\n"));
	ifx_httpdWrite(wp, T("document.tF0.wepKey3Text.disabled = false;\n"));
	ifx_httpdWrite(wp, T("document.tF0.wepKey4.disabled = false;\n"));
	ifx_httpdWrite(wp, T("document.tF0.wepKey4Text.disabled = false;\n"));
	for (i = 1; i <= wlCaps.numMacCntrlEntries; i++) {
		ifx_httpdWrite(wp, T("document.tF0.macAddr_%d.disabled = false;\n"), i);
	}

	ifx_httpdWrite(wp, T("} else {\n"));
	ifx_httpdWrite(wp, T("document.tF0.wdsStatus.value = 0;\n"));
	ifx_httpdWrite(wp, T("document.tF0.wdsSecType.disabled = true;\n"));
	ifx_httpdWrite(wp, T("document.tF0.wdsWepKeyIdx.disabled = true;\n"));
	ifx_httpdWrite(wp, T("document.tF0.wepKey1.disabled = true;\n"));
	ifx_httpdWrite(wp, T("document.tF0.wepKey1Text.disabled = true;\n"));
	ifx_httpdWrite(wp, T("document.tF0.wepKey2.disabled = true;\n"));
	ifx_httpdWrite(wp, T("document.tF0.wepKey2Text.disabled = true;\n"));
	ifx_httpdWrite(wp, T("document.tF0.wepKey3.disabled = true;\n"));
	ifx_httpdWrite(wp, T("document.tF0.wepKey3Text.disabled = true;\n"));
	ifx_httpdWrite(wp, T("document.tF0.wepKey4.disabled = true;\n"));
	ifx_httpdWrite(wp, T("document.tF0.wepKey4Text.disabled = true;\n"));
	for (i = 1; i <= wlCaps.numMacCntrlEntries; i++) {
		ifx_httpdWrite(wp, T("document.tF0.macAddr_%d.disabled = true;\n"), i);
	}
	ifx_httpdWrite(wp, T("}\n"));

	return;
}
/* ========================================================================== */
/*                         Function pointer exports                           */
/* ========================================================================== */
#endif				/* #ifdef CONFIG_FEATURE_IFX_WIRELESS */
