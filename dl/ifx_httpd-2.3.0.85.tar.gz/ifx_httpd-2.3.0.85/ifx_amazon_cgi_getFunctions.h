#ifndef _IFX_AMAZON_CGI_GETFUNCTIONS_H_
#define _IFX_AMAZON_CGI_GETFUNCTIONS_H_

extern char_t *ifx_web_GetNTPServerByIndex(int index);
void websGetIFInfo(int IF_type, int IP_Type, int nIDX, int nReqIdx,
		   bool_t bBreak, char_t * ipAddr, char_t * pRetValue);
int32 ifx_get_lan_ipv6(char8 * name, int32 * num_entries,
		       LAN_IPv6_SL_Config ** ip_array,
		       IP6_ADDR_STRING * addrconf, int32 * lan_ipv6_mode,
		       uint32 flags);
#endif				/* _IFX_AMAZON_CGI_GETFUNCTIONS_H_ */
