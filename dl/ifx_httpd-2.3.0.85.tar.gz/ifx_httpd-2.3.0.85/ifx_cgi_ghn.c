/*****************************************************************************

                              Copyright (c) 2011
                            Lantiq Deutschland GmbH
                     Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ifx_emf.h>
#include "ifx_httpd_method.h"
#include "./ifx_amazon_cgi.h"
#include "./ifx_cgi_common.h"
#include <ifx_api_util.h>
#include <hn_mapi.h>

extern void websNextPage(httpd_t wp);
extern char *status_str;
extern int ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);
int ifx_get_ghn_StatisticsInfo(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_set_ghn_DomainName_passwd(httpd_t wp, char_t * path, char_t * query);
int ifx_get_ghn_DomainName_passwd(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_MacAddressInfo(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_set_ghn_phy_layer_config(httpd_t wp, char_t * path, char_t * query);
int ifx_get_ghn_phy_layer_config(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_set_ghn_mac_layer_config(httpd_t wp, char_t * path, char_t * query);
int ifx_get_ghn_mac_layer_config(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_set_sys_setting(httpd_t wp, char_t * path, char_t * query);
int ifx_get_sys_setting(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_set_upnp_settings(httpd_t wp, char_t * path, char_t * query);
int ifx_get_upnp_settings(int eid, httpd_t wp, int argc, char_t ** argv);

char_t *FW_LOCK="<span class=\"textTitle\">Configuration in progress... FW locked.....</span>";
char_t *MAPI_FAIL="<span class=\"textTitle\">Communication failed \\ Internal error...!!!!!</span>";

int ifx_get_ghn_StatisticsInfo(int eid, httpd_t wp, int argc, char_t ** argv)
{
//      int i = 0;        
	int32 iRet = 0,ret = 0;
//      int32 hn_count=1;
	char_t *name = NULL;
	x_HN_MAPI_Iface_Stats xIfaceStats;
	uint32 uiFlags;

	memset(&xIfaceStats, 0, sizeof(x_HN_MAPI_Iface_Stats));

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return IFX_FAILURE;
	}

	uiFlags = IFX_F_DEFAULT;

	/* Fill the parent cpeId - Mandatory */
	xIfaceStats.iid.pcpeId.Id = 1;

	/* Check the fw availability */

	iRet = hn_mapi_check_fw_availability(HN_MAPI_FW_AVAIL_GET);

	if (!gstrcmp(name, "fwlock")) {
		if (iRet != HN_MAPI_SUCCESS) {
			COPY_TO_STATUS("%s",FW_LOCK);
			ifx_httpdWrite(wp, T("%s"), "0");
			IFX_DBG
			    ("HN MAPI [%s:%d] failed in stat fw availabilility [%d].\n",
			     __FUNCTION__, __LINE__, iRet);
			return HN_MAPI_FAILURE;
	
		}else {
			ifx_httpdWrite(wp, T("%s"), "1");
			return HN_MAPI_SUCCESS;
		}
	}

	iRet = hn_mapi_get_iface_stats(&xIfaceStats, uiFlags);

	if (!gstrcmp(name, "mapi")) {
		if (iRet != HN_MAPI_SUCCESS) {
			COPY_TO_STATUS("%s",MAPI_FAIL);
			ifx_httpdWrite(wp, T("%s"), "0");
			IFX_DBG("HN MAPI [%s:%d] failed in stat mapi [%d].\n",
				__FUNCTION__, __LINE__, iRet);
			return HN_MAPI_FAILURE;

		}else {
			ifx_httpdWrite(wp, T("%s"), "1");
			return HN_MAPI_SUCCESS;
		}
	}

	if (!gstrcmp(name, "count")) {
		ifx_httpdWrite(wp,
			       T
			       ("\n<table class=\"tableInfo\" cellspacing=\"1\" cellpadding=\"6\" summary=\"\">"));
		ifx_httpdWrite(wp, T("\n<tr>"));
		ifx_httpdWrite(wp,
			       T
			       ("\n<th class=\"curveLeft\" width=\"25\%\" </th>"));
		ifx_httpdWrite(wp, T("\n<th width=\"25\%\"> TX</th>"));
		ifx_httpdWrite(wp, T("\n<th width=\"25\%\"> RX</th>"));
		ifx_httpdWrite(wp, T("\n</tr>\n"));
//              for ( i=0; i < hn_count ; i++) {
		ifx_httpdWrite(wp,
			       T
			       ("\n<tr> <th width=\"25\%\" >Packets</th><td id=\"wstst_txp \">%lu</td> <td id=\"wstst_rxp \">%lu</td>"),
			       xIfaceStats.ulTxPkts, xIfaceStats.ulRxPkts);
		ifx_httpdWrite(wp, T("\n</tr>\n"));
		ifx_httpdWrite(wp,
			       T
			       ("\n<tr> <th width=\"25\%\" >Bytes</th><td id=\"wstst_txp \">%lu</td> <td id=\"wstst_rxp \">%lu</td>"),
			       xIfaceStats.ulTxBytes, xIfaceStats.ulRxBytes);
		ifx_httpdWrite(wp, T("\n</tr>\n"));
		ifx_httpdWrite(wp,
			       T
			       ("\n<tr> <th width=\"25\%\">Error</th><td id=\"wstst_txp \">%d</td> <td id=\"wstst_rxp \">%d</td>"),
			       xIfaceStats.uiTxErrorPkts,
			       xIfaceStats.uiRxErrorPkts);
		ifx_httpdWrite(wp, T("\n</tr>\n"));
		ifx_httpdWrite(wp,
			       T
			       ("\n<tr> <th width=\"25\%\">Dropped</th><td id=\"wstst_txp \">%d</td> <td id=\"wstst_rxp \">%d</td>"),
			       xIfaceStats.uiTxDiscardPkts,
			       xIfaceStats.uiRxDiscardPkts);
		ifx_httpdWrite(wp, T("\n</tr>\n"));
		ifx_httpdWrite(wp,
			       T
			       ("\n<tr> <th width=\"25\%\">Ucast Pkts</th><td id=\"wstst_txp \">%lu</td> <td id=\"wstst_rxp \">%lu</td>"),
			       xIfaceStats.ulTxUcastPkts,
			       xIfaceStats.ulRxUcastPkts);
		ifx_httpdWrite(wp, T("\n</tr>\n"));
		ifx_httpdWrite(wp,
			       T
			       ("\n<tr> <th width=\"25\%\">Mcast Pkts</th><td id=\"wstst_txp \">%lu</td> <td id=\"wstst_rxp \">%lu</td>"),
			       xIfaceStats.ulTxMcastPkts,
			       xIfaceStats.ulRxMcastPkts);
		ifx_httpdWrite(wp, T("\n</tr>\n"));
		ifx_httpdWrite(wp,
			       T
			       ("\n<tr> <th width=\"25\%\">Bcast Pkts</th><td id=\"wstst_txp \">%lu</td> <td id=\"wstst_rxp \">%lu</td>"),
			       xIfaceStats.ulTxBcastPkts,
			       xIfaceStats.ulRxBcastPkts);
		ifx_httpdWrite(wp,
			       T
			       ("\n<tr> <th width=\"25\%\">Data Pkts</th><td id=\"wstst_txp \">%d</td> <td id=\"wstst_rxp \">%d</td>"),
			       xIfaceStats.uiTxDataPkts,
			       xIfaceStats.uiRxDataPkts);
		ifx_httpdWrite(wp, T("\n</tr>\n"));
		ifx_httpdWrite(wp,
			       T
			       ("\n<tr> <th width=\"25\%\">Mgmt Pkts</th><td id=\"wstst_txp \">%d</td> <td id=\"wstst_rxp \">%d</td>"),
			       xIfaceStats.uiTxMgmtPkts,
			       xIfaceStats.uiTxMgmtPkts);
		ifx_httpdWrite(wp, T("\n</tr>\n"));

//              }
		ifx_httpdWrite(wp, T("\n</table>"));
	}

	return HN_MAPI_SUCCESS;

IFX_Handler:return HN_MAPI_FAILURE;
				  
}

int ifx_get_MacAddressInfo(int eid, httpd_t wp, int argc, char_t ** argv)
{

	int32 iRet, i, ret = 0,iRet1;
	uint32 uiNumEntries = 0;
	x_HN_MAPI_Associated_Dev *pxAssocDev = NULL;
	x_HN_MAPI_Iface_Cfg xIfaceCfg ;
	char_t *name = NULL;
	uint32 uiFlags;
	char_t *Enable = "Active", *Disable = "InActive";
	uint32 uiIfaceCpeId;

	memset(&xIfaceCfg, 0x00, sizeof(xIfaceCfg));

	/* Fill the cpeId of the interface. */
	xIfaceCfg.iid.cpeId.Id = 1;
	uiIfaceCpeId = 1;

	/* Fill the flags - Mandatory */
	uiFlags = IFX_F_DEFAULT;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return 0;
	}

	/* Check the fw availability */
	iRet = hn_mapi_check_fw_availability(HN_MAPI_FW_AVAIL_GET);

	if (!gstrcmp(name, "fwlock")) {
		if (iRet != HN_MAPI_SUCCESS) {
			COPY_TO_STATUS("%s",FW_LOCK);
			ifx_httpdWrite(wp, T("%s"), "0");
			IFX_DBG
			    ("HN MAPI [%s:%d] failed in mac_address_info Fw_avail [%d].\n",
			     __FUNCTION__, __LINE__, iRet);
			return HN_MAPI_FAILURE;

		
		}else {
			ifx_httpdWrite(wp, T("%s"), "1");
			return HN_MAPI_SUCCESS;
		}
	}

	iRet =
	    hn_mapi_get_all_associated_dev(uiIfaceCpeId, &uiNumEntries,
					   &pxAssocDev, uiFlags);

	iRet1 = 
		hn_mapi_get_iface_cfg(&xIfaceCfg, uiFlags);

	if (!gstrcmp(name, "mapi")) {
		if (iRet != HN_MAPI_SUCCESS || iRet1 != HN_MAPI_SUCCESS ) {
			COPY_TO_STATUS("%s",MAPI_FAIL);
			ifx_httpdWrite(wp, T("%s"), "0");
			IFX_DBG
			    ("HN MAPI [%s:%d] failed in mac_address_info_mapi [%d].\n",
			     __FUNCTION__, __LINE__, iRet);
			IFX_MEM_FREE(pxAssocDev);
			return HN_MAPI_FAILURE;
		
		}else {
			ifx_httpdWrite(wp, T("%s"), "1");
			return HN_MAPI_SUCCESS;
		}
	}

	if (!gstrcmp(name, "count")) {
		
		ifx_httpdWrite(wp, T("\n<table class=\"tableInfo\" summary=\"\">"));
		ifx_httpdWrite(wp, T("\n<tr>"));
		ifx_httpdWrite(wp,
			       T
			       ("\n<th>Available Devices in The Network</th>"));
		ifx_httpdWrite(wp, T("\n</tr>"));
		ifx_httpdWrite(wp, T("\n</table>"));
		ifx_httpdWrite(wp, T("\n<br>"));
		ifx_httpdWrite(wp, T("\n<br>"));
		ifx_httpdWrite(wp, T("\n<table class=\"tableInfo\" summary=\"\">"));
		ifx_httpdWrite(wp, T("\n<tr>"));
		ifx_httpdWrite(wp,
			       T
			       ("\n<th colspan=\"2\"> Own Device </th>"));
		ifx_httpdWrite(wp, T("\n</tr>"));
		ifx_httpdWrite(wp, T("\n<tr>"));
		ifx_httpdWrite(wp, T("\n<th> MAC Address </th>"));
		ifx_httpdWrite(wp, T("\n<th> Status </th>"));
		ifx_httpdWrite(wp, T("\n</tr>"));
		ifx_httpdWrite(wp, T("\n<tr>"));
		ifx_httpdWrite(wp, T("\n <td width=\"25\%\" id=\"mac_ts1\">%s</td> "),xIfaceCfg.acRegId);
		if (xIfaceCfg.eStatus == HN_MAPI_IFACE_UP || xIfaceCfg.eStatus == HN_MAPI_IFACE_DORMANT )
			ifx_httpdWrite(wp, T("\n <td width=\"25\%\"> <font color=\'GREEN\' id=\"mac_ts2\" >UP</font> </td>"));
		else
			ifx_httpdWrite(wp, T("\n <td width=\"25\%\"> <font color=\'RED\' id=\"mac_ts2\" >DOWN</font> </td>"));
		ifx_httpdWrite(wp, T("\n</tr>"));
		ifx_httpdWrite(wp, T("\n</table>"));
		ifx_httpdWrite(wp, T("\n<br>"));
		if (uiNumEntries >= 1 ){
		ifx_httpdWrite(wp, T("\n<table class=\"tableInfo\" summary=\"\">"));
		ifx_httpdWrite(wp, T("\n<tr>"));
		ifx_httpdWrite(wp,
			       T
			       ("\n<th colspan=\"4\" > Other Devices </th>"));
		ifx_httpdWrite(wp, T("\n</tr>"));
		ifx_httpdWrite(wp, T("\n<tr>"));
                ifx_httpdWrite(wp, T("\n<th> MAC Address </th>"));
                ifx_httpdWrite(wp, T("\n<th> Status </th>"));
                ifx_httpdWrite(wp, T("\n<th> Link Rate(Upstream)Mbps</th>"));
                ifx_httpdWrite(wp, T("\n<th> Link Rate(DownStream)Mbps </th>"));
                ifx_httpdWrite(wp, T("\n</tr>\n"));	
		for (i = 0; i < uiNumEntries; i++) {
			ifx_httpdWrite(wp,
				       T
				       ("\n<tr> <td width=\"25\%\" id=\"mac_ts1%d\">%s</td> "),
				       i, (pxAssocDev + i)->acMacAddr);
			if ((pxAssocDev + i)->bActive == 1) {
				ifx_httpdWrite(wp,
					       T
					       ("\n<td width=\"25\%\"> <font color=\'GREEN\' id=\"mac_ts2%d\" >%s</font> </td>"),
					       i, Enable);
			} else {
				ifx_httpdWrite(wp,
					       T
					       ("\n<td width=\"25\%\"> <font color=\'RED\' id=\"mac_ts2%d\" >%s</font> </td>"),
					       i, Disable);
			}
			ifx_httpdWrite(wp,
				       T
				       ("\n<td width=\"25\%\" id=\"mac_ts3%d\" >%f</td>"),
				       i, (pxAssocDev + i)->fTxPhyRate);
			ifx_httpdWrite(wp,
				       T
				       ("\n<td width=\"25\%\" id=\"mac_ts4%d\" >%f</td>"),
				       i, (pxAssocDev + i)->fRxPhyRate);
			ifx_httpdWrite(wp, T("\n</tr>\n"));
		}
			ifx_httpdWrite(wp, T("\n</table>\n"));
	     }
	}

	IFX_MEM_FREE(pxAssocDev);
	return HN_MAPI_SUCCESS;

IFX_Handler:return HN_MAPI_FAILURE;
}

int ifx_set_ghn_DomainName_passwd(httpd_t wp, char_t * path, char_t * query)
{
	int32 iRet = 0;
	uint32 uiOper;
	char_t *domainName, *passwd;
	uint32 uiFlags;

	x_HN_MAPI_Iface_Cfg xIfaceCfg;
	x_HN_MAPI_Security_Cfg xSecCfg;

	memset(&xIfaceCfg, 0x00, sizeof(xIfaceCfg));
	memset(&xSecCfg, 0x00, sizeof(xSecCfg));

	/* Fill the cpeId - Mandatory */
	xIfaceCfg.iid.cpeId.Id = 1;
	xSecCfg.iid.cpeId.Id = 1;

	/* Fill the flags - Mandatory */
	uiFlags = IFX_F_DEFAULT;

	/* Fill the operation - Mandatory */
	uiOper = IFX_OP_MOD;

	/* Check the fw availability */
	iRet = hn_mapi_check_fw_availability(HN_MAPI_FW_AVAIL_SET);

	if (iRet != HN_MAPI_SUCCESS) {
		IFX_DBG("HN MAPI [%s:%d] failed in doamin_set fw avail [%d].\n",
			__FUNCTION__, __LINE__, iRet);
		ifx_httpdError(wp, 400,
			       T
			       ("Configuration in Progress \\ Fw Locked...!!!!!\n"));
		return HN_MAPI_FAILURE;
	}

	/* Get the HN Device interface config */
	iRet = hn_mapi_get_iface_cfg(&xIfaceCfg, uiFlags);

	if (iRet != HN_MAPI_SUCCESS) {
		IFX_DBG("HN MAPI [%s:%d] failed in doamin_set mapi [%d].\n",
			__FUNCTION__, __LINE__, iRet);
		goto HN_Handler;
	}

	/* Get the HN Device security config */
	iRet = hn_mapi_get_security_cfg(&xSecCfg, uiFlags);

	if (iRet != HN_MAPI_SUCCESS) {
		IFX_DBG("HN MAPI [%s:%d] failed in doamin_set mapi [%d].\n",
			__FUNCTION__, __LINE__, iRet);
		goto HN_Handler;
	}

	/* Fill the caller - Mandatory */
	xIfaceCfg.iid.config_owner = IFX_WEB;

	/* Fill the flags - Mandatory */
	uiFlags = IFX_F_MODIFY | IFX_F_DONT_WRITE_TO_FLASH;

	domainName = ifx_httpdGetVar(wp, T("DomainName"), T(""));
	strcpy(xIfaceCfg.acTargetDomainName, domainName);

	iRet = hn_mapi_set_iface_cfg(IFX_OP_MOD, &xIfaceCfg, uiFlags);

	if (iRet != HN_MAPI_SUCCESS) {
		IFX_DBG("HN MAPI [%s:%d] failed in doamin_set mapi [%d].\n",
			__FUNCTION__, __LINE__, iRet);
		goto HN_Handler;
	}

	passwd = ifx_httpdGetVar(wp, T("passwd"), T(""));
	if (!gstrcmp(passwd, ""))
		xSecCfg.bEnable = 0;
	else
		xSecCfg.bEnable = 1;
	strcpy(xSecCfg.acAuthPwd, passwd);

	iRet = hn_mapi_set_security_cfg(IFX_OP_MOD, &xSecCfg, uiFlags);

	if (iRet != HN_MAPI_SUCCESS) {
		IFX_DBG("HN MAPI [%s:%d] failed in doamin_set mapi [%d].\n",
			__FUNCTION__, __LINE__, iRet);
		goto HN_Handler;
	}

	/* Trigger to Firmware reinit */
	iRet = hn_mapi_trigger_fw_cfg();

	if (iRet != HN_MAPI_SUCCESS) {
		IFX_DBG("HN MAPI [%s:%d] failed in domain_set fw trig [%d].\n",
			__FUNCTION__, __LINE__, iRet);
		ifx_httpdError(wp, 400,
			       T
			       ("Configuration in Progress \\ Fw Locked...!!!!!\n"));
		return HN_MAPI_FAILURE;
	} else {
		websNextPage(wp);
	}

	return HN_MAPI_SUCCESS;

      HN_Handler:
	ifx_httpdError(wp, 400,
		       T("Communication failed \\ Internal error...!!!!!\n"));
	/* Release the fw lock */
	hn_mapi_allow_fw_cfg();
	return HN_MAPI_FAILURE;

}

int ifx_get_ghn_DomainName_passwd(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 iRet = 0, iRet1 = 0, ret = 0;
	char_t *name = NULL;
	x_HN_MAPI_Iface_Cfg xIfaceCfg;
	x_HN_MAPI_Security_Cfg xSecCfg;
	uint32 uiFlags;
	char_t *secure = "YES", *fail = "NO";

	memset(&xIfaceCfg, 0, sizeof(x_HN_MAPI_Iface_Cfg));
	memset(&xSecCfg, 0, sizeof(x_HN_MAPI_Security_Cfg));

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return 0;
	}

	/* Fill the cpeId - Mandatory */
	xIfaceCfg.iid.cpeId.Id = 1;
	xSecCfg.iid.cpeId.Id = 1;

	/* Fill the flags - Mandatory */
	uiFlags = IFX_F_DEFAULT;

	/* Check the fw availability */

	iRet = hn_mapi_check_fw_availability(HN_MAPI_FW_AVAIL_GET);

	if (!gstrcmp(name, "fwlock")) {
		if (iRet != HN_MAPI_SUCCESS) {
			COPY_TO_STATUS("%s",FW_LOCK);
			ifx_httpdWrite(wp, T("%s"), "0");
			IFX_DBG
			    ("HN MAPI [%s:%d] failed in domain FW avail check [%d].\n",
			     __FUNCTION__, __LINE__, iRet);
			return HN_MAPI_FAILURE;
		
		}else {
			ifx_httpdWrite(wp, T("%s"), "1");
			return HN_MAPI_SUCCESS;
		}
	}

	iRet1 = hn_mapi_get_iface_cfg(&xIfaceCfg, uiFlags);

	iRet = hn_mapi_get_security_cfg(&xSecCfg, uiFlags);

	if (!gstrcmp(name, "mapi")) {
		if (iRet1 != HN_MAPI_SUCCESS || iRet != HN_MAPI_SUCCESS) {
			COPY_TO_STATUS("%s",MAPI_FAIL);
			ifx_httpdWrite(wp, T("%s"), "0");
			IFX_DBG
			    ("HN MAPI [%s:%d] failed in domain_get mapi [%d].\n",
			     __FUNCTION__, __LINE__, iRet);
			return HN_MAPI_FAILURE;
		
		}else {
			ifx_httpdWrite(wp, T("%s"), "1");
			return HN_MAPI_SUCCESS;
		}

	}

	if (!gstrcmp(name, "count")) {

		ifx_httpdWrite(wp, T("\n<tr>"));
		ifx_httpdWrite(wp,
			       T
			       ("\n<th colspan=\"2\" >Device Registration Status</th>"));
		ifx_httpdWrite(wp, T("\n</tr>"));
		if (xSecCfg.bStatus == 1) {
			ifx_httpdWrite(wp,
				       T
				       ("\n<tr> <td>Secure Network</td><td><font color=\'GREEN\' id=\"sec_sta\"> %s </font></td>"),
				       secure);
			ifx_httpdWrite(wp, T("\n</tr>"));
		} else {
			ifx_httpdWrite(wp,
				       T
				       ("\n<tr> <td>Secure Network</td><td><font color=\'RED\' id=\"sec_sta\"> %s </font></td>"),
				       fail);
			ifx_httpdWrite(wp, T("\n</tr>"));
		}
		ifx_httpdWrite(wp, T("\n<tr>"));
		ifx_httpdWrite(wp,
			       T
			       ("\n<th colspan=\"2\" >Device Domain Configuration</th>"));
		ifx_httpdWrite(wp, T("\n</tr>"));
		ifx_httpdWrite(wp,
			       T
			       ("\n<tr> <td>Domain Name</td><td><input type=\"text\" id=\"DN\" name=\"DomainName\" disabled=\"disabled\" value=\"%s\"> </td>"),
			       xIfaceCfg.acTargetDomainName);
		ifx_httpdWrite(wp, T("\n</tr>"));
		ifx_httpdWrite(wp,
			       T
			       ("\n<tr> <td>Password</td><td><input type=\"password\" id=\"PD\" name=\"passwd\" disabled=\"disabled\" value=\"%s\"> </td>"),
			       xSecCfg.acAuthPwd);
		ifx_httpdWrite(wp, T("\n</tr>"));
	}

	return HN_MAPI_SUCCESS;


IFX_Handler:return HN_MAPI_FAILURE;

}

int ifx_set_ghn_phy_layer_config(httpd_t wp, char_t * path, char_t * query)
{
	int32 iRet, i;
	uint32 uiOper;
	x_HN_MAPI_Phy_Cfg xPhyCfg;
	uint32 uiFlags;
	char_t *Phy_medium = NULL;
	char_t *Sub_cari_grp = NULL;
	char_t *Phy_band_plan = NULL;
	char_t *Phy_band_width = NULL;
	char_t *Sub_cari_count = NULL;
	char_t *Tx_power_limit = NULL;
	char_t *Tone_Idx = NULL;
	char_t *Psd_dbm = NULL;
	char_t *Low_Tone = NULL;
	char_t *High_Tone = NULL;
	int32 PhyBandWidth, PhySubCariCount;
	float PhyTxPowerLimit;
	int32 ToneIdx, PsdDbm, LowTone, HighTone;
	memset(&xPhyCfg, 0x00, sizeof(xPhyCfg));

	/* Check the fw availability */
	iRet = hn_mapi_check_fw_availability(HN_MAPI_FW_AVAIL_SET);
	if (iRet != HN_MAPI_SUCCESS) {
		ifx_httpdError(wp, 400,
			       T
			       ("Configuration in progress \\ FW Locked...!!!!!\n"));
		return HN_MAPI_FAILURE;
	}
	/* Fill the cpeId - Mandatory */
	xPhyCfg.iid.cpeId.Id = 1;

	/* Fill the flags - Mandatory */
	uiFlags = IFX_F_DEFAULT;

	/* Invoke the Get MAPI first. */
	iRet = hn_mapi_get_phy_cfg(&xPhyCfg, uiFlags);

	if (iRet != HN_MAPI_SUCCESS) {
		IFX_DBG("HN MAPI [%s:%d] failed in set_phy mapi [%d].\n",
			__FUNCTION__, __LINE__, iRet);
		goto HN_handler;
	}

	/* Fill the operation - Mandatory */
	uiOper = IFX_OP_MOD;

	/* Fill the cpeId - Mandatory */
	xPhyCfg.iid.cpeId.Id = 1;

	/* Fill the caller - Mandatory */
	xPhyCfg.iid.config_owner = IFX_WEB;

	/* Fill the flags - Mandatory */
	uiFlags = IFX_F_MODIFY | IFX_F_DONT_WRITE_TO_FLASH;

	Phy_medium = ifx_httpdGetVar(wp, T("Phy_medium"), T(""));
	Sub_cari_grp = ifx_httpdGetVar(wp, T("Sub_cari_grp"), T(""));
	Phy_band_plan = ifx_httpdGetVar(wp, T("Phy_band_plan"), T(""));

	if (!gstrcmp(Phy_medium, "Phy_Pb")) {
		xPhyCfg.ePhyType = HN_MAPI_PLC;
	} else if (!gstrcmp(Phy_medium, "Phy_Tb")) {
		xPhyCfg.ePhyType = HN_MAPI_TWISTED_PAIR;
	} else if (!gstrcmp(Phy_medium, "Phy_Cb")) {
		xPhyCfg.ePhyType = HN_MAPI_COAX_CABLE;
	} else if (!gstrcmp(Phy_medium, "Phy_CRF")) {
		xPhyCfg.ePhyType = HN_MAPI_COAX_RF;
	}

	if (!gstrcmp(Sub_cari_grp, "No_Cari")) {
		xPhyCfg.eSubCarrierGrp = HN_MAPI_NO_SUBCARRIER_GRP;
	} else if (!gstrcmp(Sub_cari_grp, "Two_Cari")) {
		xPhyCfg.eSubCarrierGrp = HN_MAPI_2_SUBCARRIER_GRP;
	} else if (!gstrcmp(Sub_cari_grp, "Four_Cari")) {
		xPhyCfg.eSubCarrierGrp = HN_MAPI_4_SUBCARRIER_GRP;
	} else if (!gstrcmp(Sub_cari_grp, "Eight_Cari")) {
		xPhyCfg.eSubCarrierGrp = HN_MAPI_8_SUBCARRIER_GRP;
	} else if (!gstrcmp(Sub_cari_grp, "Sixteen_Cari")) {
		xPhyCfg.eSubCarrierGrp = HN_MAPI_16_SUBCARRIER_GRP;
	}

	if (!gstrcmp(Phy_band_plan, "25MHZ")) {
		xPhyCfg.eBandPlan = HN_MAPI_25MHZ;
	} else if (!gstrcmp(Phy_band_plan, "50MHZ")) {
		xPhyCfg.eBandPlan = HN_MAPI_50MHZ;
	} else if (!gstrcmp(Phy_band_plan, "100MHZ")) {
		xPhyCfg.eBandPlan = HN_MAPI_100MHZ;
	} else if (!gstrcmp(Phy_band_plan, "200MHZ")) {
		xPhyCfg.eBandPlan = HN_MAPI_200MHZ;
	}

	Phy_band_width = ifx_httpdGetVar(wp, T("Phy_band_width"), T(""));
	PhyBandWidth = atoi(Phy_band_width);
	xPhyCfg.uiBandwidth = PhyBandWidth;

	Sub_cari_count = ifx_httpdGetVar(wp, T("Sub_cari_count"), T(""));
	PhySubCariCount = atoi(Sub_cari_count);
	xPhyCfg.uiSubCarrierCount = PhySubCariCount;

	Tx_power_limit = ifx_httpdGetVar(wp, T("Tx_power_limit"), T(""));
	PhyTxPowerLimit = atof(Tx_power_limit);
	xPhyCfg.fTxPowerLimit = PhyTxPowerLimit;

/*	for (i=0 ;i < (xPhyCfg.xPsdShaping.ucNumBreakpoints >  xPhyCfg.xSpectralMask.ucNumBands ? xPhyCfg.xPsdShaping.ucNumBreakpoints : xPhyCfg.xSpectralMask.ucNumBands) ; i++){  */
 	xPhyCfg.xPsdShaping.ucNumBreakpoints = 0;
	for (i = 0; i < 31; i++) {
		char_t Tone_IdxInd[12];
		sprintf(Tone_IdxInd, "Tone_Idx%d", i);
		Tone_Idx = ifx_httpdGetVar(wp, T(Tone_IdxInd), T(""));
		char_t Psd_dbmInd[11];
		sprintf(Psd_dbmInd, "Psd_dbm%d", i);
		Psd_dbm = ifx_httpdGetVar(wp, T(Psd_dbmInd), T(""));

		if (!gstrcmp(Tone_Idx, "") && !gstrcmp(Psd_dbm, ""))
			continue;
		ToneIdx = atoi(Tone_Idx);
		xPhyCfg.xPsdShaping.unBreakptIndex[xPhyCfg.xPsdShaping.
						   ucNumBreakpoints] =
		    (uint16) ToneIdx;

		PsdDbm = atoi(Psd_dbm);
		xPhyCfg.xPsdShaping.unPsdLevel[xPhyCfg.xPsdShaping.
					       ucNumBreakpoints] =
		    (uint32) PsdDbm;

		xPhyCfg.xPsdShaping.ucNumBreakpoints++;
	}
		
	xPhyCfg.xSpectralMask.ucNumBands = 0;
	for (i = 0; i < 31; i++) {
		char_t Low_ToneInd[11];
		sprintf(Low_ToneInd, "Low_Tone%d", i);
		Low_Tone = ifx_httpdGetVar(wp, T(Low_ToneInd), T(""));
		char_t High_ToneInd[12];
		sprintf(High_ToneInd, "High_Tone%d", i);
		High_Tone = ifx_httpdGetVar(wp, T(High_ToneInd), T(""));

		if (!gstrcmp(Low_Tone, "") && !gstrcmp(High_Tone, ""))
			continue;
		LowTone = atoi(Low_Tone);
		xPhyCfg.xSpectralMask.unLowerBand[xPhyCfg.xSpectralMask.
						  ucNumBands] =
		    (uint16) LowTone;

		HighTone = atoi(High_Tone);
		xPhyCfg.xSpectralMask.unHigherBand[xPhyCfg.xSpectralMask.
						   ucNumBands] =
		    (uint16) HighTone;

		xPhyCfg.xSpectralMask.ucNumBands++;
	}
	/* Invoke the MAPI to test. */
	iRet = hn_mapi_set_phy_cfg(uiOper, &xPhyCfg, uiFlags);

	/* Report Status */
	if (iRet != HN_MAPI_SUCCESS) {
		IFX_DBG("HN MAPI [%s:%d] failed in set_phy mapi [%d].\n",
			__FUNCTION__, __LINE__, iRet);
		goto HN_handler;
	}

	/* Trigger to Firmware reinit */
	iRet = hn_mapi_trigger_fw_cfg();
	if (iRet != HN_MAPI_SUCCESS) {
		ifx_httpdError(wp, 400,
			       T
			       ("Configuration in progress \\ FW Locked...!!!!!\n"));
		IFX_DBG("HN MAPI [%s:%d] failed in phy fw trig [%d].\n",
			__FUNCTION__, __LINE__, iRet);
		return HN_MAPI_FAILURE;
	}

	websNextPage(wp);
	return HN_MAPI_SUCCESS;

      HN_handler:
	IFX_DBG("HN MAPI [%s] failed in set_phy [%d].\n", __FUNCTION__, iRet);
	ifx_httpdError(wp, 400,
		       T("Communication failed \\ Internal error...!!!!!\n"));
	/* Release the fw lock */
	hn_mapi_allow_fw_cfg();
	return HN_MAPI_FAILURE;

}

int ifx_get_ghn_phy_layer_config(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 iRet, i, ret = 0;
	char_t *name = NULL;
	x_HN_MAPI_Phy_Cfg xPhyCfg;
	uint32 uiFlags;

	memset(&xPhyCfg, 0x00, sizeof(xPhyCfg));

	/* Fill the cpeId - Mandatory */
	xPhyCfg.iid.cpeId.Id = 1;

	/* Fill the flags - Mandatory */
	uiFlags = IFX_F_DEFAULT;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return 0;
	}

	/* Check the fw availability */
	iRet = hn_mapi_check_fw_availability(HN_MAPI_FW_AVAIL_GET);

	if (!gstrcmp(name, "fwlock")) {
		if (iRet != HN_MAPI_SUCCESS) {
			COPY_TO_STATUS("%s",FW_LOCK);
			ifx_httpdWrite(wp, T("%s"), "0");
			IFX_DBG
			    ("HN MAPI [%s:%d] failed in stat fw availabilility [%d].\n",
			     __FUNCTION__, __LINE__, iRet);
			return HN_MAPI_FAILURE;
		
		}else {
			ifx_httpdWrite(wp, T("%s"), "1");
			return HN_MAPI_SUCCESS;
		}
	}
	/* Invoke the MAPI under test */
	iRet = hn_mapi_get_phy_cfg(&xPhyCfg, uiFlags);

	/* Report Status */
	if (!gstrcmp(name, "mapi")) {
		if (iRet != HN_MAPI_SUCCESS) {
			COPY_TO_STATUS("%s",MAPI_FAIL);
			ifx_httpdWrite(wp, T("%s"), "0");
			IFX_DBG
			    ("HN MAPI [%s:%d] failed in Phy_get mapi [%d].\n",
			     __FUNCTION__, __LINE__, iRet);
			return HN_MAPI_FAILURE;
		}else {
                        ifx_httpdWrite(wp, T("%s"), "1");
                        return HN_MAPI_SUCCESS;
                }
	}

	if (!gstrcmp(name, "Phy_Pb")) {
		ifx_httpdWrite(wp, T("%s"),
			       (xPhyCfg.ePhyType ==
				HN_MAPI_PLC) ? "selected" : "");
	} else if (!gstrcmp(name, "Phy_Tb")) {
		ifx_httpdWrite(wp, T("%s"),
			       (xPhyCfg.ePhyType ==
				HN_MAPI_TWISTED_PAIR) ? "selected" : "");
	} else if (!gstrcmp(name, "Phy_Cb")) {
		ifx_httpdWrite(wp, T("%s"),
			       (xPhyCfg.ePhyType ==
				HN_MAPI_COAX_CABLE) ? "selected" : "");
	} else if (!gstrcmp(name, "Phy_Cb")) {
		ifx_httpdWrite(wp, T("%s"),
			       (xPhyCfg.ePhyType ==
				HN_MAPI_COAX_RF) ? "selected" : "");
	} else if (!gstrcmp(name, "Phy_band_width")) {
		ifx_httpdWrite(wp, T("%d"), xPhyCfg.uiBandwidth);
	} else if (!gstrcmp(name, "No_Cari")) {
		ifx_httpdWrite(wp, T("%s"),
			       (xPhyCfg.eSubCarrierGrp ==
				HN_MAPI_NO_SUBCARRIER_GRP) ? "selected" : "");
	} else if (!gstrcmp(name, "Two_Cari")) {
		ifx_httpdWrite(wp, T("%s"),
			       (xPhyCfg.eSubCarrierGrp ==
				HN_MAPI_2_SUBCARRIER_GRP) ? "selected" : "");
	} else if (!gstrcmp(name, "Four_Cari")) {
		ifx_httpdWrite(wp, T("%s"),
			       (xPhyCfg.eSubCarrierGrp ==
				HN_MAPI_4_SUBCARRIER_GRP) ? "selected" : "");
	} else if (!gstrcmp(name, "Eight_Cari")) {
		ifx_httpdWrite(wp, T("%s"),
			       (xPhyCfg.eSubCarrierGrp ==
				HN_MAPI_8_SUBCARRIER_GRP) ? "selected" : "");
	} else if (!gstrcmp(name, "Sixteen_Cari")) {
		ifx_httpdWrite(wp, T("%s"),
			       (xPhyCfg.eSubCarrierGrp ==
				HN_MAPI_16_SUBCARRIER_GRP) ? "selected" : "");
	} else if (!gstrcmp(name, "Sub_cari_count")) {
		ifx_httpdWrite(wp, T("%d"), xPhyCfg.uiSubCarrierCount);
	} else if (!gstrcmp(name, "25MHZ")) {
		ifx_httpdWrite(wp, T("%s"),
			       (xPhyCfg.eBandPlan ==
				HN_MAPI_25MHZ) ? "selected" : "");
	} else if (!gstrcmp(name, "50MHZ")) {
		ifx_httpdWrite(wp, T("%s"),
			       (xPhyCfg.eBandPlan ==
				HN_MAPI_50MHZ) ? "selected" : "");
	} else if (!gstrcmp(name, "100MHZ")) {
		ifx_httpdWrite(wp, T("%s"),
			       (xPhyCfg.eBandPlan ==
				HN_MAPI_100MHZ) ? "selected" : "");
	} else if (!gstrcmp(name, "200MHZ")) {
		ifx_httpdWrite(wp, T("%s"),
			       (xPhyCfg.eBandPlan ==
				HN_MAPI_200MHZ) ? "selected" : "");
	} else if (!gstrcmp(name, "Tx_power_limit")) {
		ifx_httpdWrite(wp, T("%f"), xPhyCfg.fTxPowerLimit);

	} else if (!gstrcmp(name, "PSD_Shapping")) {
		/*      for (i=0 ;i < (xPhyCfg.xPsdShaping.ucNumBreakpoints >  xPhyCfg.xSpectralMask.ucNumBands ? xPhyCfg.xPsdShaping.ucNumBreakpoints : xPhyCfg.xSpectralMask.ucNumBands) ; i++){  */
		for (i = 0; i < 31; i++) {

			ifx_httpdWrite(wp, T("\n<tr>"));
			if (i < xPhyCfg.xPsdShaping.ucNumBreakpoints) {
				ifx_httpdWrite(wp,
					       T
					       ("\n<td><input type=\"text\" id=\"ToneIDX%d\" name=\"Tone_Idx%d\" value=\"%d\"> </td>"),
					       i, i,
					       xPhyCfg.xPsdShaping.
					       unBreakptIndex[i]);
				ifx_httpdWrite(wp,
					       T
					       ("\n<td><input type=\"text\" id=\"psdDBM%d\" name=\"Psd_dbm%d\" value=\"%d\"> </td>"),
					       i, i,
					       xPhyCfg.xPsdShaping.
					       unPsdLevel[i]);
			} else {
				ifx_httpdWrite(wp,
					       T
					       ("\n<td><input type=\"text\"  id=\"ToneIDX%d\" name=\"Tone_Idx%d\" value=\"\"> </td>"),
					       i, i);
				ifx_httpdWrite(wp,
					       T
					       ("\n<td><input type=\"text\" id=\"psdDBM%d\" name=\"Psd_dbm%d\" value=\"\"> </td>"),
					       i, i);
			}
			if (i < xPhyCfg.xSpectralMask.ucNumBands) {
				ifx_httpdWrite(wp,
					       T
					       ("\n<td><input type=\"text\" id=\"LowTONE%d\" name=\"Low_Tone%d\" value=\"%d\"> </td>"),
					       i, i,
					       xPhyCfg.xSpectralMask.
					       unLowerBand[i]);
				ifx_httpdWrite(wp,
					       T
					       ("\n<td><input type=\"text\" id=\"HighTone%d\" name=\"High_Tone%d\" value=\"%d\"> </td>"),
					       i, i,
					       xPhyCfg.xSpectralMask.
					       unHigherBand[i]);
			} else {
				ifx_httpdWrite(wp,
					       T
					       ("\n<td><input type=\"text\" id=\"LowTONE%d\" name=\"Low_Tone%d\" value=\"\"> </td>"),
					       i, i);
				ifx_httpdWrite(wp,
					       T
					       ("\n<td><input type=\"text\" id=\"HighTone%d\" name=\"High_Tone%d\" value=\"\"> </td>"),
					       i, i);
			}
			ifx_httpdWrite(wp, T("\n</tr>"));
		}
	}else if (!gstrcmp(name, "profile")) {
		char8 *sProfile = NULL;
		ifx_httpdWrite(wp,
                                T
                                ("var bwProfArray = [ "));
		sProfile = strtok(xPhyCfg.acBandwidthProfile, ":");
		for (i = 0; i < 30; i++) {
			if (i % 3 == 0)
				ifx_httpdWrite(wp, T("[\"%s\", "), sProfile);
			else if (i % 3 == 1)
				ifx_httpdWrite(wp, T("\"%s\", "), sProfile);
			else if (i % 3 == 2)
				ifx_httpdWrite(wp, T("\"%s\"], "), sProfile);
			sProfile = strtok(NULL, ":");
		}
		ifx_httpdWrite(wp, T("];\n"));

		ifx_httpdWrite(wp,
                                T
                                ("var scProfArray = [ "));
		sProfile = strtok(xPhyCfg.acSubCarrierCountProfile, ":");
		for (i = 0; i < 30; i++) {
			if (i % 3 == 0)
				ifx_httpdWrite(wp, T("[\"%s\", "), sProfile);
			else if (i % 3 == 1)
				ifx_httpdWrite(wp, T("\"%s\", "), sProfile);
			else if (i % 3 == 2)
				ifx_httpdWrite(wp, T("\"%s\"], "), sProfile);
			sProfile = strtok(NULL, ":");
		}
		ifx_httpdWrite(wp, T("];\n"));
	}

	return HN_MAPI_SUCCESS;

IFX_Handler:return HN_MAPI_FAILURE;
}

int ifx_set_ghn_mac_layer_config(httpd_t wp, char_t * path, char_t * query)
{
	int32 iRet;
	uint32 uiOper;
	x_HN_MAPI_Mac_Cfg xMacCfg;
	char_t *Enable_pr_sig = NULL;
	char_t *Enable_issue_sig = NULL;
	char_t *Enable_rt_ct = NULL;
	char_t *Enable_EFD = NULL;
	char_t *Enable_Ts = NULL;
	char_t *CBTS_mode = NULL;
	char_t *Header_seg = NULL;
	char_t *start_time = NULL;
	char_t *Enable_rtx = NULL;
	uint32 uiFlags;

	memset(&xMacCfg, 0x00, sizeof(xMacCfg));

	/* Fill the cpeId - Mandatory */
	xMacCfg.iid.cpeId.Id = 1;

	/* Fill the flags - Mandatory */
	uiFlags = IFX_F_DEFAULT;

	/* Check the fw availability */
	iRet = hn_mapi_check_fw_availability(HN_MAPI_FW_AVAIL_SET);
	if (iRet != HN_MAPI_SUCCESS) {
		ifx_httpdError(wp, 400,
			       T
			       ("Configuration in progress \\ FW Locked...!!!!!\n"));
		return HN_MAPI_FAILURE;
	}

	/* Invoke the Get MAPI first. */
	iRet = hn_mapi_get_mac_cfg(&xMacCfg, uiFlags);
	if (iRet != HN_MAPI_SUCCESS) {
		IFX_DBG("HN MAPI [%s] failed in set_mac_layer_config [%d].\n",
			__FUNCTION__, iRet);
		goto HN_handler;
	}

	/* Fill the operation - Mandatory */
	uiOper = IFX_OP_MOD;

	/* Fill the flags - Mandatory */
	uiFlags = IFX_F_MODIFY | IFX_F_DONT_WRITE_TO_FLASH;

	CBTS_mode = ifx_httpdGetVar(wp, T("CBTS_MODE"), T(""));
	if (!gstrcmp(CBTS_mode, "0")) {
		xMacCfg.eCBTSClosMode = HN_MAPI_MAC_CBTS_CM_DB;
	} else if (!gstrcmp(CBTS_mode, "1")) {
		xMacCfg.eCBTSClosMode = HN_MAPI_MAC_CBTS_CM_TB_FSS;
	} else if (!gstrcmp(CBTS_mode, "2")) {
		xMacCfg.eCBTSClosMode = HN_MAPI_MAC_CBTS_CM_TB_CBTSS;
	}

	Enable_pr_sig = ifx_httpdGetVar(wp, "ENABLE_PR_sig", T(""));
	if (!gstrcmp(Enable_pr_sig, "1")) {
		xMacCfg.bPriResSignalEnable = IFX_ENABLED;
	} else {
		xMacCfg.bPriResSignalEnable = IFX_DISABLED;
	}

	Header_seg = ifx_httpdGetVar(wp, T("HEADER_SEG"), T(""));
	if (!gstrcmp(Header_seg, "0")) {
		xMacCfg.eHdrSegType = HN_MAPI_MAC_HDR_SEG_ONE_SYM;
	} else if (!gstrcmp(Header_seg, "1")) {
		xMacCfg.eHdrSegType = HN_MAPI_MAC_HDR_SEG_TWO_SYM;
	}

	Enable_issue_sig = ifx_httpdGetVar(wp, "ENABLE_INUSE_SIG", T(""));
	if (!gstrcmp(Enable_issue_sig, "1")) {
		xMacCfg.bInUseSignalEnable = IFX_ENABLED;
	} else {
		xMacCfg.bInUseSignalEnable = IFX_DISABLED;
	}

	start_time = ifx_httpdGetVar(wp, T("START_TIME"), T(""));
	if (!gstrcmp(start_time, "0")) {
		xMacCfg.eTXOPStartTimeType = HN_MAPI_MAC_TXOP_ST_COMPUTE;
	} else if (!gstrcmp(start_time, "1")) {
		xMacCfg.eTXOPStartTimeType = HN_MAPI_MAC_TXOP_ST_PREV;
	}

	Enable_rt_ct = ifx_httpdGetVar(wp, "ENABLE_RTS_CT", T(""));
	if (!gstrcmp(Enable_rt_ct, "1")) {
		xMacCfg.bRtsCtsEnable = IFX_ENABLED;
	} else {
		xMacCfg.bRtsCtsEnable = IFX_DISABLED;
	}

	Enable_EFD = ifx_httpdGetVar(wp, "ENABLE_EFD", T(""));
	if (!gstrcmp(Enable_EFD, "1")) {
		xMacCfg.bEnhFraDetEnable = IFX_ENABLED;
	} else {
		xMacCfg.bEnhFraDetEnable = IFX_DISABLED;
	}

	Enable_Ts = ifx_httpdGetVar(wp, "ENABLE_TS", T(""));
	if (!gstrcmp(Enable_Ts, "1")) {
		xMacCfg.bTSResyncEnable = IFX_ENABLED;
	} else {
		xMacCfg.bTSResyncEnable = IFX_DISABLED;
	}

	Enable_rtx  = ifx_httpdGetVar(wp,"RETX",T(""));
	if (!gstrcmp(Enable_rtx, "1")) {
			xMacCfg.bReTxEnable = IFX_ENABLED;
	}else {
			xMacCfg.bReTxEnable = IFX_DISABLED;
	}


	iRet = hn_mapi_set_mac_cfg(uiOper, &xMacCfg, uiFlags);

	if (iRet != HN_MAPI_SUCCESS) {
		goto HN_handler;
	}

	/* Trigger to Firmware reinit */
	iRet = hn_mapi_trigger_fw_cfg();
	if (iRet != HN_MAPI_SUCCESS) {
		ifx_httpdError(wp, 400,
			       T
			       ("Configuration in progress \\ FW Locked...!!!!!\n"));
		IFX_DBG("HN MAPI [%s:%d] failed in mac_layer_trig [%d].\n",
			__FUNCTION__, __LINE__, iRet);
		return HN_MAPI_FAILURE;
	}

	websNextPage(wp);
	return HN_MAPI_SUCCESS;

      HN_handler:
	IFX_DBG("HN MAPI [%s] failed in set_mac [%d].\n", __FUNCTION__, iRet);
	ifx_httpdError(wp, 400,
		       T("Communication failed \\ Internal error...!!!!!\n"));
	/* Release the fw lock */
	hn_mapi_allow_fw_cfg();
	return HN_MAPI_FAILURE;

}

int ifx_get_ghn_mac_layer_config(int eid, httpd_t wp, int argc, char_t ** argv)
{

	int32 iRet, ret = 0; 
	char_t *name = NULL;
	x_HN_MAPI_Mac_Cfg xMacCfg;
	uint32 uiFlags;

	memset(&xMacCfg, 0, sizeof(x_HN_MAPI_Mac_Cfg));

	/* Fill the cpeId - Mandatory */
	xMacCfg.iid.cpeId.Id = 1;

	/* Fill the flags - Mandatory */
	uiFlags = IFX_F_DEFAULT;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return 0;
	}

	/* Check the fw availability */
	iRet = hn_mapi_check_fw_availability(HN_MAPI_FW_AVAIL_GET);

	if (!gstrcmp(name, "fwlock")) {
		if (iRet != HN_MAPI_SUCCESS) {
			COPY_TO_STATUS("%s",FW_LOCK);
			ifx_httpdWrite(wp, T("%s"), "0");
			IFX_DBG
			    ("HN MAPI [%s:%d] failed in get_mac_layer_config  availabilility [%d].\n",
			     __FUNCTION__, __LINE__, iRet);
			return HN_MAPI_FAILURE;
		
		}else {
			ifx_httpdWrite(wp, T("%s"), "1");
			return HN_MAPI_SUCCESS;
		}
	}

	iRet = hn_mapi_get_mac_cfg(&xMacCfg, uiFlags);

	if (!gstrcmp(name, "mapi")) {
		if (iRet != HN_MAPI_SUCCESS) {
			COPY_TO_STATUS("%s",MAPI_FAIL);
			ifx_httpdWrite(wp, T("%s"), "0");
			IFX_DBG
			    ("HN MAPI [%s:%d] failed in get_mac_layer mapi [%d].\n",
			     __FUNCTION__, __LINE__, iRet);
			return HN_MAPI_FAILURE;
		
		}else {
			ifx_httpdWrite(wp, T("%s"), "1");
			return HN_MAPI_SUCCESS;
		}
	}

	if (!gstrcmp(name, "CBTS_MODE_Duration")) {
		ifx_httpdWrite(wp, T("%s"),
			       (xMacCfg.eCBTSClosMode == 0) ? "selected" : "");
	} else if (!gstrcmp(name, "CBTS_MODE_Time_FSS")) {
		ifx_httpdWrite(wp, T("%s"),
			       (xMacCfg.eCBTSClosMode == 1) ? "selected" : "");
	} else if (!gstrcmp(name, "CBTS_MODE_Time_CBTS")) {
		ifx_httpdWrite(wp, T("%d"),
			       (xMacCfg.eCBTSClosMode == 2) ? "selected" : "");
	}

	if (!gstrcmp(name, "ENABLE_PR_sig"))
		ifx_httpdWrite(wp, T("%s"),
			       (xMacCfg.bPriResSignalEnable ==
				1) ? "checked" : "");

	if (!gstrcmp(name, "Header_seg_fir")) {
		ifx_httpdWrite(wp, T("%s"),
			       (xMacCfg.eHdrSegType == 0) ? "selected" : "");
	} else {
		ifx_httpdWrite(wp, T("%s"),
			       (xMacCfg.eHdrSegType == 1) ? "selected" : "");
	}

	if (!gstrcmp(name, "ENABLE_INUSE_SIG"))
		ifx_httpdWrite(wp, T("%s"),
			       (xMacCfg.bInUseSignalEnable ==
				1) ? "checked" : "");

	if (!gstrcmp(name, "START_TIME_End")) {
		ifx_httpdWrite(wp, T("%s"),
			       (xMacCfg.eTXOPStartTimeType ==
				0) ? "selected" : "");
	} else {
		ifx_httpdWrite(wp, T("%s"),
			       (xMacCfg.eTXOPStartTimeType ==
				1) ? "selected" : "");
	}

	if (!gstrcmp(name, "ENABLE_RTS_CT")) {
		ifx_httpdWrite(wp, T("%s"),
			       (xMacCfg.bRtsCtsEnable == 1) ? "checked" : "");
	}
	if (!gstrcmp(name, "ENABLE_EFD")) {
		ifx_httpdWrite(wp, T("%s"),
			       (xMacCfg.bEnhFraDetEnable ==
				1) ? "checked" : "");
	}
	if (!gstrcmp(name, "ENABLE_TS")) {
		ifx_httpdWrite(wp, T("%s"),
			       (xMacCfg.bTSResyncEnable == 1) ? "checked" : "");
	}
	
	if (!gstrcmp(name,"RETX")){
			ifx_httpdWrite(wp, T("%s"),
                               (xMacCfg.bReTxEnable == 1) ? "checked" : "");
        }
	return HN_MAPI_SUCCESS;

IFX_Handler:return HN_MAPI_FAILURE;
}

int ifx_get_sys_setting(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 iRet, ret = 0;
	char_t *name = NULL;
	x_HN_MAPI_Iface_Cfg xIfaceCfg;
	char_t *enabled = "ENABLED", *disabled = "DISABLED";
	uint32 uiFlags;

	memset(&xIfaceCfg, 0, sizeof(x_HN_MAPI_Iface_Cfg));

	/* Fill the cpeId - Mandatory */
	xIfaceCfg.iid.cpeId.Id = 1;

	/* Fill the flags - Mandatory */
	uiFlags = IFX_F_DEFAULT;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return 0;
	}

	/* Check the fw availability */
	iRet = hn_mapi_check_fw_availability(HN_MAPI_FW_AVAIL_GET);

	if (!gstrcmp(name, "fwlock")) {
		if (iRet != HN_MAPI_SUCCESS) {
			COPY_TO_STATUS("%s",FW_LOCK);
			ifx_httpdWrite(wp, T("%s"), "0");
			IFX_DBG
			    ("HN MAPI [%s:%d] failed in get_sys_set fw availabilility [%d].\n",
			     __FUNCTION__, __LINE__, iRet);
			return HN_MAPI_FAILURE;
		
		}else {
			ifx_httpdWrite(wp, T("%s"), "1");
			return HN_MAPI_SUCCESS;
		}
	}

	iRet = hn_mapi_get_iface_cfg(&xIfaceCfg, uiFlags);

	if (!gstrcmp(name, "mapi")) {
		if (iRet != HN_MAPI_SUCCESS) {
			COPY_TO_STATUS("%s",MAPI_FAIL);
			ifx_httpdWrite(wp, T("%s"), "0");
			IFX_DBG
			    ("HN MAPI [%s:%d] failed in sys_get mapi [%d].\n",
			     __FUNCTION__, __LINE__, iRet);
			return HN_MAPI_FAILURE;
		
		}else {
			ifx_httpdWrite(wp, T("%s"), "1");
			return HN_MAPI_SUCCESS;
		}
	}

	if (!gstrcmp(name, "sys_status")) {
		ifx_httpdWrite(wp, T("\n<tr>"));
		ifx_httpdWrite(wp,
			       T("\n<th colspan=\"2\" >Device Settings</th>"));
		ifx_httpdWrite(wp, T("\n</tr>"));
		ifx_httpdWrite(wp, T("\n<tr> <td>Device Status</td>"));
		ifx_httpdWrite(wp,
			       T
			       ("\n <td> <select id=\"DivS\" name=\"Device_Status\" size=\"1\" > "));
		if (xIfaceCfg.eStatus == HN_MAPI_IFACE_UP || xIfaceCfg.eStatus == HN_MAPI_IFACE_DORMANT) {
			ifx_httpdWrite(wp,
				       T
				       ("<option name=\"Enable\" value=\"1\" selected>Enable</option>\n"));
			ifx_httpdWrite(wp,
				       T
				       ("<option name=\"Disable\" value=\"0\" >Disable</option>\n"));
		} else {
			ifx_httpdWrite(wp,
				       T
				       ("<option name=\"Enable\" value=\"1\" >Enable</option>\n"));
			ifx_httpdWrite(wp,
				       T
				       ("<option name=\"Disable\" value=\"0\" selected>Disable</option>\n"));
		}
		ifx_httpdWrite(wp, T("</select>\n"));
		ifx_httpdWrite(wp, T("</td>\n"));
		ifx_httpdWrite(wp, T("\n</tr>"));
/*		ifx_httpdWrite(wp,
			       T
			       ("\n<tr> <td>REG Code</td><td><input type=\"text\" name=\"DeviceRegCode\"  value=\"\" disabled> </td>"));
		ifx_httpdWrite(wp, T("\n</tr>")); */
#if 0 /* now moved to system hostname */
		ifx_httpdWrite(wp,
			       T
			       ("\n<tr> <td>Device Name</td><td><input type=\"text\" id=\"DivN\" name=\"DeviceName\"  value=\"%s\"> </td>"),
			       xIfaceCfg.acName);
		ifx_httpdWrite(wp, T("\n</tr>"));
#endif
		if (xIfaceCfg.bDMStatus == 1) {
			ifx_httpdWrite(wp,
				       T
				       ("\n<tr> <td>DM Status</td><td><font color=\'GREEN\' id=\"DM_ST\"> %s </font></td>"),
				       enabled);
			ifx_httpdWrite(wp, T("\n</tr>"));
		} else {
			ifx_httpdWrite(wp,
				       T
				       ("\n<tr> <td>DM Status</td><td><font color=\'RED\' id=\"DM_ST\"> %s </font></td>"),
				       disabled);
			ifx_httpdWrite(wp, T("\n</tr>"));
		}

		ifx_httpdWrite(wp, T("\n<tr>"));
		ifx_httpdWrite(wp, T("\n<tr> <td>Device Mode </td> "));
		ifx_httpdWrite(wp,
			       T
			       ("\n <td> <select id=\"DMM\" name=\"DOMAIN_MASTER\" size=\"1\" > "));
		if (xIfaceCfg.eModeRequest == HN_MAPI_IFACE_AUTO ){
			ifx_httpdWrite(wp,
				       T
				       ("<option name=\"Enable\" value=\"0\" selected>Auto</option>\n"));
			ifx_httpdWrite(wp,
				       T
				       ("<option name=\"Disable\" value=\"1\" >DM only</option>\n"));
			ifx_httpdWrite(wp,
				       T
				       ("<option name=\"Disable\" value=\"2\" >EP only</option>\n"));
		}else if (xIfaceCfg.eModeRequest == HN_MAPI_IFACE_DM){
			ifx_httpdWrite(wp,
				       T
				       ("<option name=\"Auto\" value=\"0\" >Auto</option>\n"));
			ifx_httpdWrite(wp,
				       T
				       ("<option name=\"DMonly\" value=\"1\" selected >DM only</option>\n"));
			ifx_httpdWrite(wp,
				       T
				       ("<option name=\"EPonly\" value=\"2\" >EP only</option>\n"));
		}else if (xIfaceCfg.eModeRequest == HN_MAPI_IFACE_EP){
			ifx_httpdWrite(wp,
				       T
				       ("<option name=\"Auto\" value=\"0\" >Auto</option>\n"));
			ifx_httpdWrite(wp,
				       T
				       ("<option name=\"DMonly\" value=\"1\" >DM only</option>\n"));
			ifx_httpdWrite(wp,
				       T
				       ("<option name=\"EPonly\" value=\"2\" selected >EP only</option>\n"));
		}
		ifx_httpdWrite(wp, T("</select>\n"));
		ifx_httpdWrite(wp, T("</td>\n"));
		ifx_httpdWrite(wp, T("\n</tr>"));
/*		ifx_httpdWrite(wp, T("\n<tr>"));
		ifx_httpdWrite(wp, T("\n<tr> <td>DM Ability</td> "));
		ifx_httpdWrite(wp,
			       T
			       ("\n <td> <select id=\"DMM\" name=\"DOMAIN_MASTER\" size=\"1\" > "));
		if (xIfaceCfg.bDMEnable == 1) {
			ifx_httpdWrite(wp,
				       T
				       ("<option name=\"Enable\" value=\"1\" selected>Enable</option>\n"));
			ifx_httpdWrite(wp,
				       T
				       ("<option name=\"Disable\" value=\"0\" >Disable</option>\n"));
		} else {
			ifx_httpdWrite(wp,
				       T
				       ("<option name=\"Enable\" value=\"1\" >Enable</option>\n"));
			ifx_httpdWrite(wp,
				       T
				       ("<option name=\"Disable\" value=\"0\" selected>Disable</option>\n"));
		}
		ifx_httpdWrite(wp, T("</select>\n"));
		ifx_httpdWrite(wp, T("</td>\n"));
		ifx_httpdWrite(wp, T("\n</tr>"));
		ifx_httpdWrite(wp, T("\n<tr> <td>Force Domain Master</td>"));
		ifx_httpdWrite(wp,
			       T
			       ("\n <td> <select id=\"DMMF\" name=\"FORCE_DOMAIN_MASTER\" size=\"1\" > "));
		if (xIfaceCfg.bDMRequest == 1) {
			ifx_httpdWrite(wp,
				       T
				       ("<option name=\"Enable\" value=\"1\" selected>Enable</option>\n"));
			ifx_httpdWrite(wp,
				       T
				       ("<option name=\"Disable\" value=\"0\" >Disable</option>\n"));
		} else {
			ifx_httpdWrite(wp,
				       T
				       ("<option name=\"Enable\" value=\"1\" >Enable</option>\n"));
			ifx_httpdWrite(wp,
				       T
				       ("<option name=\"Disable\" value=\"0\" selected>Disable</option>\n"));
		}
		ifx_httpdWrite(wp, T("</select>\n"));
		ifx_httpdWrite(wp, T("</td>\n"));
		ifx_httpdWrite(wp, T("\n</tr>"));*/
	}

	return HN_MAPI_SUCCESS;

IFX_Handler:return HN_MAPI_FAILURE;

}

int ifx_set_sys_setting(httpd_t wp, char_t * path, char_t * query)
{
	int32 iRet = 0;
	uint32 uiFlags;
	x_HN_MAPI_Iface_Cfg xIfaceCfg;
	uint32 uiOper;
	char_t *DivEnable;
//      char_t  *REGcode; /* FIXME */
#if 0 /* now moved to system hostname */
	char_t *Domain_name;
#endif /* if 0 */
	char_t *DMS;
//	char_t *DMSF;

	memset(&xIfaceCfg, 0x00, sizeof(xIfaceCfg));

	/* Fill the cpeId - Mandatory */
	xIfaceCfg.iid.cpeId.Id = 1;

	/* Fill the flags - Mandatory */
	uiFlags = IFX_F_DEFAULT;

	/* Check the fw availability */
	iRet = hn_mapi_check_fw_availability(HN_MAPI_FW_AVAIL_SET);
	if (iRet != HN_MAPI_SUCCESS) {
		ifx_httpdError(wp, 400,
			       T
			       ("Configuration in progress \\ FW Locked...!!!!!\n"));
		IFX_DBG
		    ("HN MAPI [%s:%d] failed in set_sys fw availabilility [%d].\n",
		     __FUNCTION__, __LINE__, iRet);
		return HN_MAPI_FAILURE;
	}

	/* Invoke the Get MAPI first. */

	iRet = hn_mapi_get_iface_cfg(&xIfaceCfg, uiFlags);

	if (iRet != HN_MAPI_SUCCESS) {
		IFX_DBG("HN MAPI [%s:%d] failed in set _sys mapi check [%d].\n",
			__FUNCTION__, __LINE__, iRet);
		goto HN_handler;
	}

	/* Fill the operation - Mandatory */
	uiOper = IFX_OP_MOD;

	/* Fill the flags - Mandatory */
	uiFlags = IFX_F_MODIFY | IFX_F_DONT_WRITE_TO_FLASH;

	DivEnable = ifx_httpdGetVar(wp, T("Device_Status"), T(""));
	if (!gstrcmp(DivEnable, "1")) {
		xIfaceCfg.bEnable = 1;
	} else {
		xIfaceCfg.bEnable = 0;
	}
	/*FIX ME */
	//REGcode =  ifx_httpdGetVar(wp, T("DeviceRegCode"), T(""));
	//strcpy(xIfaceCfg.acTargetDomainName,REGcode);

#if 0 /* now moved to system hostname */
	Domain_name = ifx_httpdGetVar(wp, T("DeviceName"), T(""));
	strcpy(xIfaceCfg.acName, Domain_name);
#endif /* if 0 */

	DMS = ifx_httpdGetVar(wp, T("DOMAIN_MASTER"), T(""));

	if (!gstrcmp(DMS, "0")) {
		xIfaceCfg.eModeRequest = HN_MAPI_IFACE_AUTO;
	}else if (!gstrcmp(DMS, "1")){
		xIfaceCfg.eModeRequest = HN_MAPI_IFACE_DM;
	}else{
		xIfaceCfg.eModeRequest = HN_MAPI_IFACE_EP;
	}
/*
	DMSF = ifx_httpdGetVar(wp, T("FORCE_DOMAIN_MASTER"), T(""));
	if (!gstrcmp(DMSF, "1")) {
		xIfaceCfg.bDMRequest = IFX_ENABLED;
	} else {
		xIfaceCfg.bDMRequest = IFX_DISABLED;
	}
*/
	iRet =
	    hn_mapi_set_iface_cfg(IFX_OP_MOD, &xIfaceCfg,
				  IFX_F_DONT_WRITE_TO_FLASH);
	if (iRet != HN_MAPI_SUCCESS) {
		IFX_DBG("HN MAPI [%s:%d] failed in set_sys set_mapi [%d].\n",
			__FUNCTION__, __LINE__, iRet);
		goto HN_handler;
	}

	/* Trigger to Firmware reinit */
	iRet = hn_mapi_trigger_fw_cfg();
	if (iRet != HN_MAPI_SUCCESS) {
		ifx_httpdError(wp, 400,
			       T
			       ("Configuration in progress \\ FW Locked...!!!!!\n"));
		IFX_DBG("HN MAPI [%s:%d] failed in set_sys_trig [%d].\n",
			__FUNCTION__, __LINE__, iRet);
		return HN_MAPI_FAILURE;
	}

	websNextPage(wp);
	return HN_MAPI_SUCCESS;

      HN_handler:
	IFX_DBG("HN MAPI [%s] failed in set_set_sys [%d].\n", __FUNCTION__,
		iRet);
	ifx_httpdError(wp, 400,
		       T("Communication failed \\ Internal error...!!!!!\n"));
	/* Release the fw lock */
	hn_mapi_allow_fw_cfg();
	return HN_MAPI_FAILURE;

}


int ifx_set_upnp_settings(httpd_t wp, char_t * path, char_t * query)
{
	char_t *UPnPVar = NULL;
        char_t  sUpnpEnable[MAX_DATA_LEN];

	UPnPVar = ifx_httpdGetVar(wp, "UPNP", T(""));
	if (!gstrcmp(UPnPVar, "1")) {
		sprintf(sUpnpEnable, "upnpdm_enable=\"1\"\n");
	} else {
		sprintf(sUpnpEnable, "upnpdm_enable=\"0\"\n");
	}

	// Update rc.conf in ramdisk
	if (ifx_SetCfgData(FILE_RC_CONF, "upnpdm", 1, sUpnpEnable) == 0) {
		ifx_httpdError(wp, 500, "Fail to set upnpdm_enable");
		return HN_MAPI_FAILURE;
	}

	// save setting
	if (ifx_flash_write()<=0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return HN_MAPI_FAILURE;
	}

	if (!gstrcmp(UPnPVar, "1")) {
		system("/etc/rc.d/init.d/upnpdm restart");
	} else {
		system("/etc/rc.d/init.d/upnpdm stop");
	}

	websNextPage(wp);

	return HN_MAPI_SUCCESS;
}

int ifx_get_upnp_settings(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name = NULL;
        char_t  sValue[2];

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
                ifx_httpdError(wp, 400, T("Insufficient args\n"));
                return 0;
        }

        if ( ifx_GetCfgData(FILE_RC_CONF, "upnpdm", T("upnpdm_enable"), sValue) == 0) {
                ifx_httpdError(wp, 500, T("upnpdm_enable not found"));
                return -1;
        }

 	if (!gstrcmp(name, "UPNP")) {
                ifx_httpdWrite(wp, T("%s"),
                               ( atoi(sValue) == 1) ? "checked" : "");
	}

	return HN_MAPI_SUCCESS;
}
