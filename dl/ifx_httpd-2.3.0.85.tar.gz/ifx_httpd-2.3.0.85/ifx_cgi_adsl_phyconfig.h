#ifndef _IFX_CGI_GET_ADSL_PHYCONFIG_H
#define _IFX_CGI_GET_ADSL_PHYCONFIG_H

#include "ifx_cgi.h"

#endif
