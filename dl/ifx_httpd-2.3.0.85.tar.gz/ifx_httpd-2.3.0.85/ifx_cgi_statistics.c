//#include <sys/syslog.h>
#include <ifx_emf.h>
#include "ifx_httpd_method.h"
//#include <signal.h>
//#include <unistd.h>
//#include <sys/types.h>
//#include <sys/wait.h>
#include <ifx_common.h>
#include "./ifx_amazon_cgi.h"
//#include "./ifx_amazon_cgi_getFunctions.h"
//#include "ifx_snmp_api.h"
//#include "ifx_api_ipt_common.h"
//#include <sys/ioctl.h>
#include "./ifx_cgi_common.h"
#ifdef CONFIG_FEATURE_SYSTEM_PERFORMANCE_CHARTS
typedef struct intrface_stats {
	char tx_bytes[25];
	char rx_bytes[25];
} INTRFACE_STATS;
extern int32 ifx_get_another_fvp_from_dist_fvp(char8 * secName, char8 * fName,
					       char8 * fValue, char8 * fRetName,
					       char8 * fRetValue, uint32 flags);
#endif
extern int ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);
extern int get_vcc_enc(char_t sWAN_VCC[], int *encap);

void ifx_get_wan_statistics(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name = NULL;
	int i = 0, wan_count = 0, wipCnt = 0, wpppCnt = 0, ret = 0;
	IFACE_STATS *iface_stats = NULL;	// XXX this declaration should be array of pointers .
	WAN_CONN_CFG wan_cfg;
	WAN_PHY_CFG pstWanPhy;
	ifx_get_wan_phy_cfg(&pstWanPhy);

	if (ifx_get_sec_count(TAG_WAN_IP, &wipCnt) != IFX_SUCCESS) {

	}

	if (ifx_get_sec_count(TAG_WAN_PPP, &wpppCnt) != IFX_SUCCESS) {

	}

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return;
	}

	if (ifx_get_all_wan_if_stats(&wan_count, &iface_stats, IFX_F_DEFAULT) !=
	    IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get wan statistics\n\n"));
		return;
	}

	if (!gstrcmp(name, "count")) {
		ifx_httpdWrite(wp, T("%d"), wan_count);
	} else if (!gstrcmp(name, "stats")) {
		for (i = 0; i < wan_count; i++) {
			ifx_httpdWrite(wp, T("WAN_IDX[%d]=\"%d\";\n"), i,
				       iface_stats[i].wan_index);
			ifx_httpdWrite(wp, T("WAN_IFACE[%d]=\"%s\";\n"), i,
				       iface_stats[i].iface);
			ifx_httpdWrite(wp, T("TX_PKT[%d]=\"%lu\";\n"), i,
				       iface_stats[i].stats.tx_pkts);
			ifx_httpdWrite(wp, T("TX_BYTES[%d]=\"%lu\";\n"), i,
				       iface_stats[i].stats.tx_bytes);
			ifx_httpdWrite(wp, T("TX_ERR[%d]=\"%lu\";\n"), i,
				       iface_stats[i].stats.tx_error_pkts);
			ifx_httpdWrite(wp, T("TX_DROP[%d]=\"%lu\";\n"), i,
				       iface_stats[i].stats.tx_discard_pkts);
			ifx_httpdWrite(wp, T("RX_PKT[%d]=\"%lu\";\n"), i,
				       iface_stats[i].stats.rx_pkts);
			ifx_httpdWrite(wp, T("RX_BYTES[%d]=\"%lu\";\n"), i,
				       iface_stats[i].stats.rx_bytes);
			ifx_httpdWrite(wp, T("RX_ERR[%d]=\"%lu\";\n"), i,
				       iface_stats[i].stats.rx_error_pkts);
			ifx_httpdWrite(wp, T("RX_DROP[%d]=\"%lu\";\n"), i,
				       iface_stats[i].stats.rx_discard_pkts);
		}
	}

#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] eth wanip count [%d]", __FUNCTION__, __LINE__, wipCnt);

	IFX_DBG("[%s:%d] eth wanppp count [%d]", __FUNCTION__, __LINE__,
		wpppCnt);
#endif

	if (!gstrcmp(name, "display")) {

		for (i = 0; i < wipCnt; i++) {
			wan_cfg.type = WAN_TYPE_IP;

			if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2) {
				if (pstWanPhy.wan_tc == WAN_TC_ATM) {
					ret =
					    mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_ATM,
								       IFX_F_GET_ANY);
				} else {
					ret =
					    mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_PTM,
								   IFX_F_GET_ANY);
				}
			} else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII0 || pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII1) {
				if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII0) 
					ret = mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_ETH0,IFX_F_GET_ANY);
				else
					ret = mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_ETH1,IFX_F_GET_ANY);
			} else if (pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2) {
				if (pstWanPhy.wan_tc == WAN_TC_ATM) {
					ret = mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_VDSL_ATM,IFX_F_GET_ANY);
				} else {
					ret = mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_VDSL_PTM,IFX_F_GET_ANY);
				}
			}

			if (ret == IFX_SUCCESS) {

				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<tr><td id=\'wstat_int%d\'>\" +WAN_IFACE[%d] +\"</td><td id=\'wstst_wch%d\'>\");\n"),
					       i, i, i);
				ifx_httpdWrite(wp,
					       T("get_vcc_encap(%d,\"IP\");\n"),
					       i);
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"</td><td id=\'wstst_ct%d\'>\");\n"),
					       i);
				ifx_httpdWrite(wp,
					       T("get_conn_type(%d,\"IP\");\n"),
					       i);
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"</td>\");\n"));
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<td><table border=\'0\' width=\'100%\' cellspacing=\'1\' cellpadding=\'0\' ><tr>\");\n"));
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<td width=\'25%\' id=\'wstst_txp%d\'>\" + TX_PKT[%d] + \"</td>\");\n"),
					       i, i);
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<td width=\'25%\' id=\'wstst_txb%d\'>\" + TX_BYTES[%d] + \"</td>\");\n"),
					       i, i);
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<td width=\'25%\' id=\'wstst_txe%d\'>\" + TX_ERR[%d] + \"</td>\");\n"),
					       i, i);
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<td width=\'25%\' id=\'wstst_txd%d\'>\" + TX_DROP[%d] + \"</td>\");\n"),
					       i, i);
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"</tr></table></td>\");\n"));
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<td><table border=\'0\' width=\'100%\' cellspacing=\'1\' cellpadding=\'0\'><tr>\");\n"));
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<td width=\'25%\' id=\'wstst_rxp%d\'>\" + RX_PKT[%d] + \"</td>\");\n"),
					       i, i);
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<td width=\'25%\' id=\'wstst_rxb%d\'>\" + RX_BYTES[%d] + \"</td>\");\n"),
					       i, i);
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<td width=\'25%\' id=\'wstst_rxe%d\'>\" + RX_ERR[%d] + \"</td>\");\n"),
					       i, i);
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<td width=\'25%\' id=\'wstst_rxd%d\'>\" + RX_DROP[%d] + \"</td>\");\n"),
					       i, i);
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"</tr></table></td></tr>\");\n"));
			}
		}

		for (i = 0; i < wpppCnt; i++) {
			wan_cfg.type = WAN_TYPE_PPP;

			if (pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2) {
				if (pstWanPhy.wan_tc == WAN_TC_ATM) {
					ret =
					    mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_ATM,
								       IFX_F_GET_ANY);
				} else {
					ret =
					    mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_PTM,
								   IFX_F_GET_ANY);
				}
			} else if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII0 || pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII1) {
				if (pstWanPhy.phy_mode == WAN_PHY_MODE_ETH_MII0)
					ret = mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_ETH0,IFX_F_GET_ANY);
				else
					ret = mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_ETH1,IFX_F_GET_ANY);
			} else if (pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2){
				if (pstWanPhy.wan_tc == WAN_TC_ATM) {
					ret = mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_VDSL_ATM,IFX_F_GET_ANY);
				} else {
					ret = mapi_get_wan_config_for_mode(i, &wan_cfg, WAN_MODE_VDSL_PTM,IFX_F_GET_ANY);
				}
			}

			if (ret == IFX_SUCCESS) {

				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<tr><td id=\'wstat_int%d\'>\" +WAN_IFACE[%d] +\"</td><td id=\'wstst_wch%d\'>\");\n"),
					       wipCnt + i, wipCnt + i,
					       wipCnt + i);
				if(i==0){

					ifx_httpdWrite(wp,
                                               T
                                               ("document.write(\"WWAN\");\n")
                                               );
				}
				else
				{
				ifx_httpdWrite(wp,
					       T
					       ("get_vcc_encap(%d,\"PPP\");\n"),
					       i);
				}
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"</td><td id=\'wstst_ct%d\'>\");\n"),
					       i);
				if(i==0){
                                ifx_httpdWrite(wp,
                                               T
                                               ("document.write(\"PPP\");\n")
                                               );
				}
                                else
                                {
				ifx_httpdWrite(wp,
					       T
					       ("get_conn_type(%d,\"PPP\");\n"),
					       i);
				}
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"</td>\");\n"));
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<td><table border=\'0\' width=\'100%\' cellspacing=\'1\' cellpadding=\'0\' ><tr>\");\n"));
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<td width=\'25%\' id=\'wstst_txp%d\'>\" + TX_PKT[%d] + \"</td>\");\n"),
					       wipCnt + i, wipCnt + i);
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<td width=\'25%\' id=\'wstst_txb%d\'>\" + TX_BYTES[%d] + \"</td>\");\n"),
					       wipCnt + i, wipCnt + i);
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<td width=\'25%\' id=\'wstst_txe%d\'>\" + TX_ERR[%d] + \"</td>\");\n"),
					       wipCnt + i, wipCnt + i);
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<td width=\'25%\' id=\'wstst_txd%d\'>\" + TX_DROP[%d] + \"</td>\");\n"),
					       wipCnt + i, wipCnt + i);
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"</tr></table></td>\");\n"));
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<td><table border=\'0\' width=\'100%\' cellspacing=\'1\' cellpadding=\'0\'><tr>\");\n"));
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<td width=\'25%\' id=\'wstst_rxp%d\'>\" + RX_PKT[%d] + \"</td>\");\n"),
					       wipCnt + i, wipCnt + i);
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<td width=\'25%\' id=\'wstst_rxb%d\'>\" + RX_BYTES[%d] + \"</td>\");\n"),
					       wipCnt + i, wipCnt + i);
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<td width=\'25%\' id=\'wstst_rxe%d\'>\" + RX_ERR[%d] + \"</td>\");\n"),
					       wipCnt + i, wipCnt + i);
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"<td width=\'25%\' id=\'wstst_rxd%d\'>\" + RX_DROP[%d] + \"</td>\");\n"),
					       wipCnt + i, wipCnt + i);
				ifx_httpdWrite(wp,
					       T
					       ("document.write(\"</tr></table></td></tr>\");\n"));
			}
		}

	}
	IFX_MEM_FREE(iface_stats)
}

void ifx_get_wan_statistics_modified(int eid, httpd_t wp, int argc,
				     char_t ** argv)
{
	char_t *name = NULL;
	char_t type[MAX_FIELD_LEN];
	char_t atm_proto[MAX_FIELD_LEN];
	int linkType;
	int i = 0, wan_count = 0;
	/*
	   int             encap = 0;
	   char_t  sWAN_VCC[20];
	 */
	IFACE_STATS *iface_stats = NULL;	// XXX this declaration should be array of pointers .
	WAN_CONN_CFG *wan_cfg = NULL;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return;
	}

	if (ifx_get_all_wan_atm_vcc_config(&wan_count, &wan_cfg, IFX_F_DEFAULT)
	    != IFX_SUCCESS) {
		ifx_httpdError(wp, 500,
			       T
			       ("Failed to get the configured wan connections"));
		IFX_MEM_FREE(wan_cfg);
		return;
	}

	wan_count = 0;
	if (ifx_get_all_wan_if_stats(&wan_count, &iface_stats, IFX_F_DEFAULT) !=
	    IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get wan statistics\n\n"));
		IFX_MEM_FREE(wan_cfg);
		return;
	}

	if (!gstrcmp(name, "count")) {
		ifx_httpdWrite(wp, T("%d"), wan_count);
	} else {
		for (i = 0; i < wan_count; i++) {
			ifx_httpdWrite(wp, T("<tr><td>%s</td>"),
				       iface_stats[i].iface);

			linkType = (wan_cfg + i)->type;
			switch (linkType) {
			case WAN_LINK_TYPE_EOATM:
			case WAN_LINK_TYPE_IPOATM:
			case WAN_LINK_TYPE_CLIP:
				if ((wan_cfg + i)->wancfg.ip.conn_type ==
				    WAN_IP_CONN_TYPE_IP_BRIDGED) {
					sprintf(type, "%s", "Bridge");
				} else if ((wan_cfg + i)->wancfg.ip.conn_type ==
					   WAN_IP_CONN_TYPE_IP_ROUTED) {
					if ((wan_cfg +
					     i)->WAN_IP_CONN.addr_type == 1) {
						sprintf(type, "%s",
							"Dhcp Client<br>");
						if (linkType == 1)
//                                                                                                      sprintf(atm_proto, "%s", "RFC2684 Ethernet over ATM");
							sprintf(atm_proto, "%s",
								"EoA");
						if (linkType == 2)
							sprintf(atm_proto, "%s",
								"IPoA");
						if (linkType == 5)
							sprintf(atm_proto, "%s",
								"CLIP");
					} else if ((wan_cfg + i)->WAN_IP_CONN.
						   addr_type == 2) {
						sprintf(type, "%s",
							"Fix IP<br>");
						if (linkType == 1)
							sprintf(atm_proto, "%s",
								"EoA");
						if (linkType == 2)
							sprintf(atm_proto, "%s",
								"IPoA");
						if (linkType == 5)
							sprintf(atm_proto, "%s",
								"CLIP");
					}
				}
				break;
			case WAN_LINK_TYPE_PPPOATM:
				sprintf(type, "%s", "PPPoA");
				break;
			case WAN_LINK_TYPE_PPPOE:
				sprintf(type, "%s", "PPPoE");
				break;
			default:
				sprintf(type, "%s", "Disabled");
				break;
			}
#if 0				/* TBD */
			sprintf(sWAN_VCC, "%d/%d", (wan_cfg + i)->vc.pvc.vpi,
				(wan_cfg + i)->vc.pvc.vci);
			get_vcc_enc(sWAN_VCC, &encap);

			ifx_httpdWrite(wp, T("<td> %d/%d<br>%s </td>"),
				       (wan_cfg + i)->vc.pvc.vpi,
				       (wan_cfg + i)->vc.pvc.vci,
				       (encap == 0) ? "LLS/SNAP" : "VCMux");
#endif				// 0

			ifx_httpdWrite(wp, T("<td>%lu</td>"),
				       iface_stats[i].stats.tx_pkts);
			ifx_httpdWrite(wp, T("<td>%lu</td>"),
				       iface_stats[i].stats.tx_bytes);
			ifx_httpdWrite(wp, T("<td>%lu</td>"),
				       iface_stats[i].stats.tx_error_pkts);
			ifx_httpdWrite(wp, T("<td>%lu</td>"),
				       iface_stats[i].stats.tx_discard_pkts);
			ifx_httpdWrite(wp, T("<td>%lu</td>"),
				       iface_stats[i].stats.rx_pkts);
			ifx_httpdWrite(wp, T("<td>%lu</td>"),
				       iface_stats[i].stats.rx_bytes);
			ifx_httpdWrite(wp, T("<td>%lu</td>"),
				       iface_stats[i].stats.rx_error_pkts);
			ifx_httpdWrite(wp, T("<td>%lu</td></tr>"),
				       iface_stats[i].stats.rx_discard_pkts);
		}
	}

	IFX_MEM_FREE(wan_cfg)
	    IFX_MEM_FREE(iface_stats)
}

void ifx_get_lan_statistics(int eid, httpd_t wp, int argc, char_t ** argv)
{
	IF_STATS if_stats;

	memset(&if_stats, 0x00, sizeof(IF_STATS));
#ifndef PLATFORM_VB300
	if (ifx_get_if_stats("eth0", &if_stats, IFX_F_DEFAULT) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get wan statistics\n\n"));
		return;
	}
	ifx_httpdWrite(wp, T("ETH_IFACE=\"%s\";\n"), "eth0");
#else
	if (ifx_get_if_stats("eth1", &if_stats, IFX_F_DEFAULT) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get wan statistics\n\n"));
		return;
	}
	ifx_httpdWrite(wp, T("ETH_IFACE=\"%s\";\n"), "eth1");
#endif
	ifx_httpdWrite(wp, T("ETH_TX_PKT=\"%lu\";\n"), if_stats.tx_pkts);
	ifx_httpdWrite(wp, T("ETH_TX_BYTES=\"%lu\";\n"), if_stats.tx_bytes);
	ifx_httpdWrite(wp, T("ETH_TX_ERR=\"%lu\";\n"), if_stats.tx_error_pkts);
	ifx_httpdWrite(wp, T("ETH_TX_DROP=\"%lu\";\n"),
		       if_stats.tx_discard_pkts);
	ifx_httpdWrite(wp, T("ETH_RX_PKT=\"%lu\";\n"), if_stats.rx_pkts);
	ifx_httpdWrite(wp, T("ETH_RX_BYTES=\"%lu\";\n"), if_stats.rx_bytes);
	ifx_httpdWrite(wp, T("ETH_RX_ERR=\"%lu\";\n"), if_stats.rx_error_pkts);
	ifx_httpdWrite(wp, T("ETH_RX_DROP=\"%lu\";\n"),
		       if_stats.rx_discard_pkts);
	memset(&if_stats, 0x00, sizeof(IF_STATS));
#ifdef CONFIG_FEATURE_IFX_USB_DEVICE
	if (ifx_get_if_stats("usb0", &if_stats, IFX_F_DEFAULT) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get wan statistics\n\n"));
		return;
	}
	ifx_httpdWrite(wp, T("USB_IFACE=\"%s\";\n"), "usb0");
	ifx_httpdWrite(wp, T("USB_TX_PKT=\"%lu\";\n"), if_stats.tx_pkts);
	ifx_httpdWrite(wp, T("USB_TX_BYTES=\"%lu\";\n"), if_stats.tx_bytes);
	ifx_httpdWrite(wp, T("USB_TX_ERR=\"%lu\";\n"), if_stats.tx_error_pkts);
	ifx_httpdWrite(wp, T("USB_TX_DROP=\"%lu\";\n"),
		       if_stats.tx_discard_pkts);
	ifx_httpdWrite(wp, T("USB_RX_PKT=\"%lu\";\n"), if_stats.rx_pkts);
	ifx_httpdWrite(wp, T("USB_RX_BYTES=\"%lu\";\n"), if_stats.rx_bytes);
	ifx_httpdWrite(wp, T("USB_RX_ERR=\"%lu\";\n"), if_stats.rx_error_pkts);
	ifx_httpdWrite(wp, T("USB_RX_DROP=\"%lu\";\n"),
		       if_stats.rx_discard_pkts);
#endif
}

void ifx_get_lan_statistics_modified(int eid, httpd_t wp, int argc,
				     char_t ** argv)
{
	IF_STATS if_stats;

	memset(&if_stats, 0x00, sizeof(IF_STATS));

	if (ifx_get_if_stats("eth0", &if_stats, IFX_F_DEFAULT) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get wan statistics\n\n"));
		return;
	}

	ifx_httpdWrite(wp, T("<tr><td>%s</td>"), "eth0");
	ifx_httpdWrite(wp, T("<td>%lu</td>"), if_stats.tx_pkts);
	ifx_httpdWrite(wp, T("<td>%lu</td>"), if_stats.tx_bytes);
	ifx_httpdWrite(wp, T("<td>%lu</td>"), if_stats.tx_error_pkts);
	ifx_httpdWrite(wp, T("<td>%lu</td>"), if_stats.tx_discard_pkts);
	ifx_httpdWrite(wp, T("<td>%lu</td>"), if_stats.rx_pkts);
	ifx_httpdWrite(wp, T("<td>%lu</td>"), if_stats.rx_bytes);
	ifx_httpdWrite(wp, T("<td>%lu</td>"), if_stats.rx_error_pkts);
	ifx_httpdWrite(wp, T("<td>%lu</td></tr>"), if_stats.rx_discard_pkts);

	memset(&if_stats, 0x00, sizeof(IF_STATS));

	if (ifx_get_if_stats("usb0", &if_stats, IFX_F_DEFAULT) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get wan statistics\n\n"));
		return;
	}

	ifx_httpdWrite(wp, T("<tr><td>%s</td>"), "usb0");
	ifx_httpdWrite(wp, T("<td>%lu</td>"), if_stats.tx_pkts);
	ifx_httpdWrite(wp, T("<td>%lu</td>"), if_stats.tx_bytes);
	ifx_httpdWrite(wp, T("<td>%lu</td>"), if_stats.tx_error_pkts);
	ifx_httpdWrite(wp, T("<td>%lu</td>"), if_stats.tx_discard_pkts);
	ifx_httpdWrite(wp, T("<td>%lu</td>"), if_stats.rx_pkts);
	ifx_httpdWrite(wp, T("<td>%lu</td>"), if_stats.rx_bytes);
	ifx_httpdWrite(wp, T("<td>%lu</td>"), if_stats.rx_error_pkts);
	ifx_httpdWrite(wp, T("<td>%lu</td></tr>"), if_stats.rx_discard_pkts);
//              }

}

void ifx_get_phyport_statistics(int eid, httpd_t wp, int argc, char_t ** argv)
{
	struct ifx_phyportstats_info xPort;
	int i, maxPort = 0, j = 1;
#if defined(CONFIG_FEATURE_IFX_SINGLE_PORT) || defined(CONFIG_FEATURE_LTQ_HNX_CONFIG) || defined(CONFIG_FEATURE_LTQ_WIRELESS_VB)
	maxPort = 1;
#else
	maxPort = 4;
#endif

	ifx_httpdWrite(wp,
		       T
		       ("\n<span class=\"textTitle\">Ethernet Ports Statistics</font></span><br>"));
	ifx_httpdWrite(wp, T("\n<div align=\"center\">"));
	ifx_httpdWrite(wp,
		       T
		       ("\n<table class=\"tableInfo\" cellspacing=\"1\" cellpadding=\"6\" summary=\"\">"));
	ifx_httpdWrite(wp, T("\n<tr>"));
	ifx_httpdWrite(wp, T("\n  <th class=\"curveLeft\">Port</th>"));
	ifx_httpdWrite(wp, T("\n  <th>"));
	ifx_httpdWrite(wp,
		       T
		       ("\n    <table border=\"0\" cellspacing=\"1\" cellpadding=\"0\">"));
	ifx_httpdWrite(wp, T("\n      <tr class=\"celltitle\">"));
	ifx_httpdWrite(wp,
		       T
		       ("\n        <th width=\"25%\" align=\"center\">TX</th>"));
	ifx_httpdWrite(wp, T("\n      </tr>"));
	ifx_httpdWrite(wp, T("\n      <tr>"));
	ifx_httpdWrite(wp, T("\n        <td>"));
	ifx_httpdWrite(wp,
		       T
		       ("\n          <table border=\"0\" width=\"100%\" cellspacing=\"1\" cellpadding=\"0\">"));
	ifx_httpdWrite(wp, T("\n            <tr>"));
	ifx_httpdWrite(wp, T("\n              <th width=\"50%\">Packets</th>"));
	ifx_httpdWrite(wp, T("\n              <th width=\"50%\">Bytes</th>"));
	ifx_httpdWrite(wp, T("\n            </tr>"));
	ifx_httpdWrite(wp, T("\n          </table>"));
	ifx_httpdWrite(wp, T("\n        </td>"));
	ifx_httpdWrite(wp, T("\n      </tr>"));
	ifx_httpdWrite(wp, T("\n    </table>"));
	ifx_httpdWrite(wp, T("\n  </th>"));
	ifx_httpdWrite(wp, T("\n  <th>"));
	ifx_httpdWrite(wp,
		       T
		       ("\n    <table border=\"0\"  cellspacing=\"1\" cellpadding=\"0\">"));
	ifx_httpdWrite(wp, T("\n      <tr>"));
	ifx_httpdWrite(wp,
		       T
		       ("\n        <th width=\"25%\" align=\"center\">RX</th>"));
	ifx_httpdWrite(wp, T("\n      </tr>"));
	ifx_httpdWrite(wp, T("\n      <tr>"));
	ifx_httpdWrite(wp, T("\n        <td>"));
	ifx_httpdWrite(wp,
		       T
		       ("\n          <table border=\"0\" width=\"100%\"  cellspacing=\"1\" cellpadding=\"0\">"));
	ifx_httpdWrite(wp, T("\n            <tr>"));
	ifx_httpdWrite(wp, T("\n              <th width=\"50%\">Packets</th>"));
	ifx_httpdWrite(wp, T("\n              <th width=\"50%\">Bytes</th>"));
	ifx_httpdWrite(wp, T("\n            </tr>"));
	ifx_httpdWrite(wp, T("\n          </table>"));
	ifx_httpdWrite(wp, T("\n        </td>"));
	ifx_httpdWrite(wp, T("\n      </tr>"));
	ifx_httpdWrite(wp, T("\n    </table>"));
	ifx_httpdWrite(wp, T("\n  </th>"));
	ifx_httpdWrite(wp, T("\n</tr>"));

	/* Read port statistics */
#if defined(PLATFORM_AR10) && defined(CONFIG_PACKAGE_KMOD_LTQCPE_AR10_F2_SUPPORT)
	for (i = 2; i <= 5; i++, j++) {
#else
	for (i = 0; i < maxPort; i++,++j) {
#endif
		memset(&xPort, '\0', sizeof(xPort));
#if defined(PLATFORM_VB300) || defined(CONFIG_FEATURE_LTQ_HNX_CONFIG)
		/* VB300 does not have PHY port 0 */
		if (i == 0)
			i = 1;
#endif
#if defined(PLATFORM_VR9) || defined(PLATFORM_VB300) || defined(CONFIG_FEATURE_LTQ_HNX_CONFIG) || defined(PLATFORM_AR10)
		if (ifx_get_phyportstats_info(i, &xPort, 0) != IFX_SUCCESS) {
#else
		if (ifx_get_phyportstats_info(i, &xPort, 1) != IFX_SUCCESS) {
#endif
			ifx_httpdError(wp, 400,
				       T("Failed to get port statistics\n\n"));
			return;
		}

		ifx_httpdWrite(wp, T("\n<tr><td id=\"lstat_p%d_no\"> LAN_PORT%d </td>"),
			       j, j);
		ifx_httpdWrite(wp,
			       T
			       ("\n<td><table border=\'0\' width=\'100%\' cellspacing=\"1\" cellpadding=\"0\"><tr>"),
			       i);
		ifx_httpdWrite(wp, T("\n<tr>"));
		ifx_httpdWrite(wp,
			       T
			       ("\n<td id=\"lstat_p%d_txp\" width=\'50%\'> %lu </td>"),
			       i, xPort.txPktCnt);
		ifx_httpdWrite(wp,
			       T
			       ("\n<td id=\"lstat_p%d_txb\" width=\'50%\'> %lu </td>"),
			       i, xPort.txByteCnt);
		ifx_httpdWrite(wp, T("\n</tr></table></td>"));
		ifx_httpdWrite(wp,
			       T
			       ("\n<td><table border=\'0\' width=\'100%\' cellspacing=\"1\" cellpadding=\"0\"><tr>"),
			       i);
		ifx_httpdWrite(wp, T("\n<tr>"));
		ifx_httpdWrite(wp,
			       T
			       ("\n<td id=\"lstat_p%d_rxp\" width=\'50%\'> %lu </td>"),
			       i, xPort.rxPktCnt);
		ifx_httpdWrite(wp,
			       T
			       ("\n<td id=\"lstat_p%d_rxb\" width=\'50%\'> %lu </td>"),
			       i, xPort.rxByteCnt);
		ifx_httpdWrite(wp, T("\n</tr></table></td></tr>"));

	}
	ifx_httpdWrite(wp, T("\n</table>"));
	ifx_httpdWrite(wp, T("\n</tr>"));
}

#ifdef CONFIG_FEATURE_SYSTEM_PERFORMANCE_CHARTS

int get_interface_stats(char *ifname, INTRFACE_STATS * if_stats)
{
	FILE *fp;
	char word[50], *temp;
	char tmp[25];
#ifdef PLATFORM_AR10_VRX318
	uint64 total_tx_cnt=0, total_rx_cnt=0,pkt_cnt=0,temp_cnt=0;
#endif
#ifdef CONFIG_FEATURE_ANY_WAN_SUPPORT
	int32 ret = IFX_SUCCESS; 
	uint32 outFlag = IFX_F_DEFAULT;
	char8 buf[MAX_FILELINE_LEN];	
#endif
	if ((ifname == NULL) || (strlen(ifname) >= 23))
		return 0;

	memset(word, 0, sizeof(word));
	memset(if_stats->rx_bytes, 0, sizeof(word));
	memset(if_stats->tx_bytes, 0, sizeof(word));

#ifdef CONFIG_FEATURE_ANY_WAN_SUPPORT
	memset(buf, 0x00, sizeof(buf));
	ret = ifx_GetObjData(FILE_SYSTEM_STATUS, "AnyWan", "status", IFX_F_DEFAULT,
				&outFlag, buf);
	if(ret == IFX_SUCCESS && atoi(buf)) {
		fp = fopen("/tmp/pkt_cnt", "r");
        	if (fp == NULL) {
                	return 0;
	        }
        	if(fread(word, 1, sizeof(word), fp) > 0) {
                	strcpy(if_stats->rx_bytes, word);
	                if_stats->rx_bytes[strlen(if_stats->rx_bytes) - 1] = '\0'; /* skip newline */
        	}
	        if(fread(word, 1, sizeof(word), fp) > 0) {
        	        strcpy(if_stats->tx_bytes, word);
                	if_stats->tx_bytes[strlen(if_stats->tx_bytes) - 1] = '\0'; /* skip newline */
	        }
		if(fp)
			fclose(fp);
	} else {
#endif
		fp = fopen("/proc/net/dev", "r");
		if (fp == NULL) {
		return 0;
		}
		while (fscanf(fp, "%50s", word) != EOF) {
			if (strstr(word, ifname) != NULL) {
				temp = strchr(word, ':');
	                        if (!temp) {
        	                   fclose(fp);
                	           return 0;
                        	}
				if (strlen(ifname) != strlen(word))
					strncpy(if_stats->rx_bytes, temp + 1,
						strlen(temp));
				else
					fscanf(fp, " %s", if_stats->rx_bytes);
				fscanf(fp, "%s %s %s %s %s %s %s %s %s %s %s", tmp, tmp,
				       tmp, tmp, tmp, tmp, tmp, if_stats->tx_bytes, tmp,
				       tmp, tmp);
				break;
			}
		}
		if(fp)
			fclose(fp);
/*
	conters for ptm0 in vrx318 
	--------------------------
	acc_tx = ppacmd getwan + ig_fast_brg_bytes (cpu bytes in /proc/eth/mib)
	acc_rc = ig_fast_rt_ipv4_bytes + ig_fast_rt_ipv6_bytes + ig_cpu_bytes (ptm0 in /proc/eth/mib)
	 
*/
#ifdef PLATFORM_AR10_VRX318
	if(!strcmp(ifname,"ptm0:")) {
		system("echo enable all > /proc/eth/mib");
		fp = fopen("/proc/eth/mib", "r");
		if (fp == NULL) {
			return 0;
		}
		while (fscanf(fp, "%50s", word) != EOF) {
			if (strstr(word, "ig_fast_rt_ipv4_bytes") != NULL) {
				temp = strchr(word, ':');
				if (!temp) {
					fclose(fp);
					return 0;
				}
				fscanf(fp, "%llu, %llu, %llu, %llu, %llu, %llu, %llu, %llu", &temp_cnt, &temp_cnt, &temp_cnt, &temp_cnt, &temp_cnt, &temp_cnt, &temp_cnt, &pkt_cnt);
				total_rx_cnt += pkt_cnt;
			} else if (strstr(word, "ig_fast_rt_ipv6_bytes") != NULL) {
				temp = strchr(word, ':');
				if (!temp) {
					fclose(fp);
					return 0;
				}
				fscanf(fp, "%llu, %llu, %llu, %llu, %llu, %llu, %llu, %llu", &temp_cnt, &temp_cnt, &temp_cnt, &temp_cnt, &temp_cnt, &temp_cnt, &temp_cnt, &pkt_cnt);
				total_rx_cnt += pkt_cnt;
			}/* else if (strstr(word, "ig_cpu_bytes") != NULL) {
                                temp = strchr(word, ':');
                                if (!temp) {
                                        fclose(fp);
                                        return 0;
                                }
				fscanf(fp, "%llu, %llu, %llu, %llu, %llu, %llu, %llu, %llu", &temp_cnt, &temp_cnt, &temp_cnt, &temp_cnt, &temp_cnt, &temp_cnt, &temp_cnt, &pkt_cnt);
				total_rx_cnt += pkt_cnt;
                        }*/ else  if (strstr(word, "ig_fast_brg_bytes") != NULL) {
				temp = strchr(word, ':');
				if (!temp) {
					fclose(fp);
					return 0;
				}
				fscanf(fp, "%llu, %llu, %llu, %llu, %llu, %llu, %llu, %llu", &temp_cnt, &temp_cnt, &pkt_cnt, &temp_cnt, &temp_cnt, &temp_cnt, &temp_cnt, &temp_cnt);
				total_tx_cnt += pkt_cnt;
			}
		}
		if(fp)
                        fclose(fp);
		fp = popen("ppacmd getwan | grep \"ptm0 \"","r");
		if (fp == NULL) {
                        return 0;
                }
		while (fscanf(fp, "%50s", word) != EOF) {
			if (strstr(word, "ptm0") != NULL) {
				fscanf(fp, "%s %s %llu : %llu", tmp,tmp,&temp_cnt, &pkt_cnt);
				total_tx_cnt += pkt_cnt;
				break;
			} 
		}			
		sprintf(if_stats->rx_bytes,"%llu", total_rx_cnt);
                sprintf(if_stats->tx_bytes,"%llu", total_tx_cnt);
		if(fp)
			pclose(fp);
	}
#endif
#ifdef CONFIG_FEATURE_ANY_WAN_SUPPORT
	}
#endif
	return 1;
}

int ifx_get_dect_calls()
{
	FILE *fp;
	char word[25], tmp[5];
	int count = 0;
	fp = fopen("/proc/driver/dect/gw-stats", "r");
	if (fp == NULL) {
		return 0;
	}

	while (fscanf(fp, "%25s", word) != EOF) {
		if (strstr(word, "Calls\0") != NULL) {
			fscanf(fp, "%5s %d ", tmp, &count);
			break;
		}
	}
	fclose(fp);
	return count;
}

int ifx_get_mm_streams()
{
	FILE *fp;
	int mmstream_count = 0;
	char buffer[10] = "0\0";
	system
	    ("cat /proc/net/nf_conntrack | grep \"udp\" | grep \"src=10.0.0.2\\|200.9.34.1\" | grep \"dport=4321\" |tr -s \"[ ]*\" \" \" | cut -d\' \' -f5 | grep \"[1-6][0-9]\" | wc -l >> /tmp/mmstream_stats");
	system
	    ("cat /proc/net/nf_conntrack | grep \"udp\" | grep \"src=10.0.0.2\\|200.9.34.1\" | grep \"dport=1234\" |tr -s \"[ ]*\" \" \" | cut -d\' \' -f5 | grep \"[1-6][0-9]\" | wc -l >> /tmp/mmstream_stats");

	fp = fopen("/tmp/mmstream_stats", "r");
	if (fp == NULL) {
		return 0;
	}
	while (1) {
		fgets(buffer, 10, fp);
		if (feof(fp))
			break;
		if (atoi(buffer) >= 1)
			mmstream_count++;
	}
	fclose(fp);
	remove("/tmp/mmstream_stats");
	return mmstream_count;
}

int ifx_get_cpu_usage(httpd_t wp)
{
	FILE *fp;
	char buffer[3][30] = { "0", "0" };
	fp = popen
	    ("abc=`pecostat -c pic0=0,pic1=1:EXL,K,S,U,IE,VPEID=0,TCID=0 1 2`;echo \"$abc\" | sed -e 's/\\(^[^,]*\\), .*/\\1/' ; echo \"$abc\" | sed -n \"s,.* : ,,;1p\" | sed -n \"s, .*,,;1p\"",
	     "r");
	if (fp == NULL) {
		ifx_httpdWrite(wp, T("var cpuReads=\"%s %s %s\";"), buffer[0],
			       buffer[1], buffer[2]);
		return 0;
	}
	fscanf(fp, "%30s %30s %30s", buffer[0], buffer[1], buffer[2]);
#ifdef IFX_LOG_DEBUG
	IFX_DBG("buff0=%s \n buff1=%s \nbuff2=%s", buffer[0], buffer[1],
		buffer[2]);
#endif
	if (pclose(fp) == -1) {
		perror("unable to close file pointer of popen");
	}
	ifx_httpdWrite(wp, T("var cpuReads=\"%s %s %s\";"), buffer[0],
		       buffer[1], buffer[2]);
	return 0;
}

void ifx_get_graph_statistics(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 ret=0,wan_mode;
	WAN_PHY_CFG pstWanPhy;
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
	dw_config_info_t dw_attr;
	ret = dw_mapi_cfg_get(&dw_attr, 0);
	memcpy(&pstWanPhy,&dw_attr.pri_wan_cfg,sizeof(WAN_PHY_CFG));
#else
	ret = ifx_get_wan_phy_cfg(&pstWanPhy);	
#endif
	if (ret != IFX_SUCCESS) {
                IFX_DBG("[%s:%d] ERROR: Config File Read", __FUNCTION__,
                                __LINE__);
        }
	//char wanConnName[MAX_CONN_NAME_LEN];
	uint64 tmpTX, tmpRX, tmp1TX, tmp1RX;
#ifndef CONFIG_FEATURE_ANY_WAN_SUPPORT
	uint64 newRX=0, newTX=0;
	//char_t def_gw[8] = { 0 };
	char_t def_id[8] = { 0 };
#endif
	//char_t def_l2ifName[8] = { 0 };
	//int ret = 0;
	IFX_ID iid;
	//int32 nWAN_IDX = 0;
	memset(&iid, 0x00, sizeof(iid));
/*	if (ifx_get_default_wan_if(&iid, &nWAN_IDX, wanConnName, IFX_F_DEFAULT) ==
	    IFX_SUCCESS) {
		sprintf(def_gw, "%s", wanConnName);
	}
	if(strstr(def_gw,"WANIP")) {
	ret = ifx_get_another_fvp_from_dist_fvp(TAG_WAN_IP, "connName", def_gw, "l2ifName", def_l2ifName, IFX_F_GET_ANY);
	}
	else
	ret = ifx_get_another_fvp_from_dist_fvp(TAG_WAN_PPP, "connName", def_gw, "l2ifName", def_l2ifName, IFX_F_GET_ANY);
	
	sprintf(def_id, "%s:", def_l2ifName);*/

	INTRFACE_STATS if_stats;
	int count = 0;
	char8 *name;
	wan_mode = pstWanPhy.phy_mode;
	memset (&if_stats, 0, sizeof (INTRFACE_STATS));
	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 200, T("Insufficient args\n"));
		return;
	}
	if (!gstrcmp(name, T("graph_stats"))) {
		ifx_get_cpu_usage(wp);
		if (wan_mode == 1) {
			get_interface_stats("eth0.2", &if_stats);
			ifx_httpdWrite(wp,
				       T("var ethRX=\"%s\",ethTX=\"%s\";\n"),
				       if_stats.rx_bytes, if_stats.tx_bytes);
		} else {
			get_interface_stats("eth0:", &if_stats);
			ifx_httpdWrite(wp,
				       T("var ethRX=\"%s\",ethTX=\"%s\";\n"),
				       if_stats.rx_bytes, if_stats.tx_bytes);
		}
		get_interface_stats("wlan0:", &if_stats);
		ifx_httpdWrite(wp, T("var wlan0RX=\"%s\",wlan0TX=\"%s\";\n"),
			       if_stats.rx_bytes, if_stats.tx_bytes);
		get_interface_stats("wlan1:", &if_stats);
		ifx_httpdWrite(wp, T("var wlan1RX=\"%s\",wlan1TX=\"%s\";\n"),
			       if_stats.rx_bytes, if_stats.tx_bytes);
		if (wan_mode == WAN_PHY_MODE_ETH_MII1) {
			get_interface_stats("eth1:", &if_stats);
			ifx_httpdWrite(wp,
				       T("var vdslRX=\"%s\",vdslTX=\"%s\";\n"),
				       if_stats.rx_bytes, if_stats.tx_bytes);
		} else if (wan_mode == WAN_PHY_MODE_VDSL2) {
			get_interface_stats("ptm0:", &if_stats);
			ifx_httpdWrite(wp,
				       T("var vdslRX=\"%s\",vdslTX=\"%s\";\n"),
				       if_stats.rx_bytes, if_stats.tx_bytes);
		} else if (wan_mode == WAN_PHY_MODE_ADSL2) {
#ifdef CONFIG_FEATURE_ANY_WAN_SUPPORT
			get_interface_stats("nas", &if_stats);
			ifx_httpdWrite(wp,T("var vdslRX=\"%lu\",vdslTX=\"%lu\";\n"),atol(if_stats.rx_bytes),atol(if_stats.tx_bytes));

#else
			ATM_VCC_INFO *vcc = NULL;
			int num = 0, i;
			if (ifx_get_all_vcc_info(&num, &vcc, IFX_F_DEFAULT) != IFX_SUCCESS) {
				return;
				}
			for (i = 0; i < num; i++) {
				snprintf(def_id,sizeof(def_id), "%s:", (vcc + i)->l2ifname);	
				get_interface_stats(def_id, &if_stats);
				newRX = newRX + atol(if_stats.rx_bytes);
				newTX = newTX + atol(if_stats.tx_bytes);
			}	
			ifx_httpdWrite(wp,T("var vdslRX=\"%lu\",vdslTX=\"%lu\";\n"),newRX, newTX);
			if(vcc)
				free(vcc);
#endif
		} else if (wan_mode == WAN_PHY_MODE_ETH_MII0) {
			get_interface_stats("eth0:", &if_stats);
			tmpRX = atol(if_stats.rx_bytes);
			tmpTX = atol(if_stats.tx_bytes);
			get_interface_stats("eth0.2", &if_stats);
			tmp1RX = atol(if_stats.rx_bytes);
			tmp1TX = atol(if_stats.tx_bytes);
			tmpRX = tmpRX - tmp1RX;
			tmpTX = tmpTX - tmp1TX;
			ifx_httpdWrite(wp,
				       T("var vdslRX=\"%lu\",vdslTX=\"%lu\";\n"),
				       tmpRX, tmpTX);
		} else if (wan_mode == WAN_PHY_MODE_LTE) {
				get_interface_stats("lte0:", &if_stats);
			ifx_httpdWrite(wp,
				       T("var vdslRX=\"%s\",vdslTX=\"%s\";\n"),
				       if_stats.rx_bytes, if_stats.tx_bytes);
		}
#ifdef CONFIG_FEATURE_DUAL_WAN_SUPPORT
		if(dw_attr.fo_state != FO_DISABLE) {
			wan_mode = dw_attr.sec_wan_cfg.phy_mode;
			if (wan_mode == WAN_PHY_MODE_ETH_MII1) {
				get_interface_stats("eth1:", &if_stats);
				ifx_httpdWrite(wp,
					       T("sec_vdslRX=\"%s\";\nsec_vdslTX=\"%s\";\n"),
					       if_stats.rx_bytes, if_stats.tx_bytes);
			} else if (wan_mode == WAN_PHY_MODE_VDSL2) {
				printf("\nreading ptm values..\n");
				get_interface_stats("ptm0:", &if_stats);
				ifx_httpdWrite(wp,
					       T("sec_vdslRX=\"%s\";\nsec_vdslTX=\"%s\";\n"),
					       if_stats.rx_bytes, if_stats.tx_bytes);
			} else if (wan_mode == WAN_PHY_MODE_ADSL2) {
#ifdef CONFIG_FEATURE_ANY_WAN_SUPPORT
				get_interface_stats("nas", &if_stats);
				ifx_httpdWrite(wp,T("sec_vdslRX=\"%lu\";\nsec_vdslTX=\"%lu\";\n"),atol(if_stats.rx_bytes),atol(if_stats.tx_bytes));

#else
				ATM_VCC_INFO *vcc = NULL;
				int num = 0, i;
				if (ifx_get_all_vcc_info(&num, &vcc, IFX_F_DEFAULT) != IFX_SUCCESS) {
					return;
				}
				for (i = 0; i < num; i++) {
					snprintf(def_id,sizeof(def_id), "%s:", (vcc + i)->l2ifname);	
					get_interface_stats(def_id, &if_stats);
					newRX = newRX + atol(if_stats.rx_bytes);
					newTX = newTX + atol(if_stats.tx_bytes);
				}	
				ifx_httpdWrite(wp,T("sec_vdslRX=\"%lu\";\nsec_vdslTX=\"%lu\";\n"),newRX, newTX);
				if(vcc)
					free(vcc);
#endif
			} else if (wan_mode == WAN_PHY_MODE_ETH_MII0) {
				get_interface_stats("eth0:", &if_stats);
				tmpRX = atol(if_stats.rx_bytes);
				tmpTX = atol(if_stats.tx_bytes);
				get_interface_stats("eth0.2", &if_stats);
				tmp1RX = atoi(if_stats.rx_bytes);
				tmp1TX = atoi(if_stats.tx_bytes);
				tmpRX = tmpRX - tmp1RX;
				tmpTX = tmpTX - tmp1TX;
				ifx_httpdWrite(wp,
					       T("sec_vdslRX=\"%lu\";\nsec_vdslTX=\"%lu\";\n"),
					       tmpRX, tmpTX);
			} else if (wan_mode == WAN_PHY_MODE_LTE) {
					get_interface_stats("lte0:", &if_stats);
				ifx_httpdWrite(wp,
					      T(" sec_vdslRX=\"%s\"; \n sec_vdslTX=\"%s\";\n"),
					      if_stats.rx_bytes, if_stats.tx_bytes);
			}
		}
#endif
		count = ifx_get_dect_calls();
		ifx_httpdWrite(wp, T("var dectCalls=Number(%d);\n"), count);
		count = ifx_get_mm_streams();
		ifx_httpdWrite(wp, T("var mmStreams=Number(%d);\n"), count);
	}

}
#endif
