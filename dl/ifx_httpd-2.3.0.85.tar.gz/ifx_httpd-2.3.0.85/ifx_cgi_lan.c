#include <ifx_emf.h>
#include "ifx_httpd_method.h"
#include "./ifx_amazon_cgi.h"
#include "./ifx_amazon_cgi_getFunctions.h"
#include "./ifx_cgi_common.h"
#include <arpa/inet.h>
#include <string.h>
#ifdef CONFIG_FEATURE_IFX_WIRELESS
#include "ltq_cgi_wlan.h"
#endif				/* #ifdef CONFIG_FEATURE_IFX_WIRELESS */

char dhcpCondServerAction[20];
char dhcpCondServerOrder[10];

char static_lease_cpeId[20];

extern struct connection_profil_list *connlist;

#ifdef CONFIG_FEATURE_IPv6
int ifx_get_IPv6Status(int eid, httpd_t wp, int argc, char_t ** argv);	// IPv6 enable/disable feature
int evalute_tunnel_intf_addr(char *wan_sixrdprefix, char *wan_sixrdbrip,
			     char *sixrd_masklen, char *sixrd_prefixlen);
char *create_sixrd_tunnel_err =
    "<span class=\"textTitle\">Cannot create or modify tunnel on that WAN connection.<br></span><p>Please change to relevant operational WAN mode <a href=\"wan_mode_setting.asp\">Here</a> and then try again.</p>";

char *create_sixrd_tunnel_pwan_ipv6_err =
    "<span class=\"textTitle\">Cannot create tunnel or modify tunnel since native ipv6 is enabled on that WAN connection.<br></span><p>Please disable native ipv6 on that WAN <a href=\"wan_vcc_select.asp\">Here</a> and then try again.</p>";

char *create_dslite_tunnel_err =
    "<span class=\"textTitle\">Cannot create or modify tunnel on that WAN connection.<br></span><p>Please change to relevant operational WAN mode <a href=\"wan_mode_setting.asp\">Here</a> and then try again.</p>";

char *create_dslite_tunnel_pwan_ipv6_err =
    "<span class=\"textTitle\">Cannot create tunnel or modify tunnel since native ipv6 is disabled on that WAN connection.<br></span><p>Please enable native ipv6 on that WAN <a href=\"wan_vcc_select.asp\">Here</a> and then try again.</p>";

extern int set_dslite_parameters(uint32 wan_dslitewanidx, char *pCheck_dslite, 
				 char *dslitemode, char *dslite_remoteipv6, 
			 	 char *dslite_tunip, char *dslite_mask, 
				 char *wandslite_mtu, int wantype, 
				 char * wan_name, char *dslite_portrange);

#endif				// CONFIG_FEATURE_IPv6

extern void websNextPage(httpd_t wp);
extern int ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);
extern int ifx_get_all_wan_conn_names(char **wan_conn_names, int *count);
void ifx_set_lan_dhcps(httpd_t wp, char_t * path, char_t * query);
int ifx_get_lan_dhcps(int eid, httpd_t wp, int argc, char_t ** argv);	//lan_dhcps.asp; lan_nodhcp.asp
int ifx_get_lan_IPV6(int eid, httpd_t wp, int argc, char_t ** argv);
#ifdef CONFIG_FEATURE_DHCP_SERVER
int ifx_get_lan_dhcps_LeaseTime(int eid, httpd_t wp, int argc, char_t ** argv);	//lan_dhcps.asp
int ifx_get_lan_dhcp_clients(int eid, httpd_t wp, int argc, char_t ** argv);	//lan_dhcp_clients.asp
int32 ifx_get_dhcp_conditional_entry(IFX_DHCP_COND_SERV_POOL * pp_dhcp_info,
				     uint32 flags);
#endif
#ifdef CONFIG_FEATURE_LTQ_WIRELESS_VB
extern LTQ_MAPI_VB_ETH_PHY_Cfg g_vbEthPhyConfig[2];
extern int g_vbEthPhyCount;
void ltq_set_eth_phy_cfg(httpd_t wp, char_t * path, char_t * query);
int ltq_get_eth_phy_cfg(int eid, httpd_t wp, int argc, char_t ** argv);
#endif
extern char *status_str;

typedef struct {
	/* Web ASP selected option value index */
	uint value;
	/* Web ASP selected option value index content */
	char_t *str;
} CGI_ENUMSEL_S;

#ifdef CONFIG_FEATURE_DHCP_SERVER
static CGI_ENUMSEL_S web_Enum_LeaseTimeList[] = {
	{0, "Half hour"},
	{1, "One hour"},
	{2, "Two hours"},
	{3, "Half day"},
	{4, "One day"},
	{5, "Two days"},
	{6, "One week"},
	{7, "Two weeks"},
};
#endif

ST_LEASE_TIME nSelLeaseTime[] = {
	{0, 1800},
	{1, 3600},
	{2, 7200},
	{3, 43200},
	{4, 86400},
	{5, 172800},
	{6, 604800},
	{7, 1209600},
};

//////////////////////////////////////////////////////////////////
//vipul start

int ifx_get_lan_dhcp_static_lease(int eid, httpd_t wp, int argc,
				  char_t ** argv);

int ifx_get_lan_dhcp_static_lease(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int num, flag = 0;
	char_t *name = NULL;
	char_t *sip[4], *smac[6], shost[MAX_FILELINE_LEN];
	int ret = IFX_SUCCESS, i;
	char8 status[MAX_FILELINE_LEN];
	uint32 Flags = IFX_F_DEFAULT;
	IFX_MAPI_DHCPS_STATIC_LEASE *p_info = NULL;
	ifx_httpd_parse_args(argc, argv, T("%s"), &name);

	ret = ifx_get_all_dhcps_static_lease(&num, &p_info, Flags);

	if (ret == IFX_SUCCESS) {
		for (i = 0; i < num; i++) {
			if (name != NULL && !gstrcmp(name, "modify_info")) {
				if (atoi(static_lease_cpeId) !=
				    (p_info + i)->iid.cpeId.Id) {
					continue;
				} else {
					flag = 1;

					sip[0] =
					    strtok((p_info + i)->ipAddr, ".");
					sip[1] = strtok(NULL, ".");
					sip[2] = strtok(NULL, ".");
					sip[3] = strtok(NULL, ".");
					smac[0] =
					    strtok((p_info + i)->macAddr, ":");
					smac[1] = strtok(NULL, ":");
					smac[2] = strtok(NULL, ":");
					smac[3] = strtok(NULL, ":");
					smac[4] = strtok(NULL, ":");
					smac[5] = strtok(NULL, ":");
					strcpy(shost, (p_info + i)->host);
//              gsprintf(status, T("ldhcp_%d_enable"), i);
					gsprintf(status, "%d",
						 (p_info + i)->enable);
					ifx_httpdWrite(wp,
						       T
						       ("\"%d\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\""),
						       (p_info +
							i)->iid.cpeId.Id, shost,
						       sip[0], sip[1], sip[2],
						       sip[3], smac[0], smac[1],
						       smac[2], smac[3],
						       smac[4], smac[5],
						       status);
					break;
				}
			} else {
				ifx_httpdWrite(wp, T("<tr>\n"));
				ifx_httpdWrite(wp,
					       T
					       ("<td name=\"ip_resv_host%d\">%s</td>\n"),
					       i, (p_info + i)->host);
				ifx_httpdWrite(wp,
					       T
					       ("<td name=\"ip_resv_addr%d\">%s</td>\n"),
					       i, (p_info + i)->ipAddr);
				ifx_httpdWrite(wp,
					       T
					       ("<td name=\"ip_resv_mac%d\">%s</td>\n"),
					       i, (p_info + i)->macAddr);
				ifx_httpdWrite(wp, T("\t\t\t\t<td>"));
//              gsprintf(status, T("ldhcp_%d_enable"), i);
				gsprintf(status, "%d", (p_info + i)->enable);

				if ((p_info + i)->enable < 0) {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t<input type=\"checkbox\" name=\"%s\" value=\"1\" disabled></td>\n"),
						       status);
				} else {
					if ((p_info + i)->enable == 0)
						ifx_httpdWrite(wp,
							       T
							       ("\t\t\t\t\t<input type=\"checkbox\" name=\"%s\" value=\"1\"  disabled></td>\n"),
							       status);
					else
						ifx_httpdWrite(wp,
							       T
							       ("\t\t\t\t\t<input type=\"checkbox\" name=\"%s\" value=\"1\"%s disabled></td>\n"),
							       status,
							       " CHECKED");
				}

				ifx_httpdWrite(wp,
					       T
					       ("<td><a class=\"button\" href=\"#\" value=\"Delete\" onClick=\"DelValue(\'%d\', \'%d\', \'%s\', \'%s\', \'%s\', \'%d\');\">Delete</a></td>\n"),
					       i, (p_info + i)->iid.cpeId.Id,
					       (p_info + i)->host,
					       (p_info + i)->ipAddr,
					       (p_info + i)->macAddr,
					       (p_info + i)->enable);

			}
			ifx_httpdWrite(wp,
				       T
				       ("<td><a class=\"button\" href=\"#\" value=\"Modify\" onClick=\"ModifyValue(\'%d\', \'%d\', \'%s\', \'%s\', \'%s\', \'%d\');\">Modify</a></td>\n"),
				       i, (p_info + i)->iid.cpeId.Id,
				       (p_info + i)->host, (p_info + i)->ipAddr,
				       (p_info + i)->macAddr,
				       (p_info + i)->enable);
		}
		if (flag == 0)
			ifx_httpdWrite(wp, T("</tr>"));

	} else {
		ifx_httpdError(wp, 500, "Error");
	}

	IFX_MEM_FREE(p_info);
	return 0;
}

//vipul end
////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////
// vipul start
void ifx_set_lan_dhcp_static_lease(httpd_t wp, char_t * path, char_t * query);

void ifx_set_lan_dhcp_static_lease(httpd_t wp, char_t * path, char_t * query)
{
	char_t *psysip1, *psysip2, *psysip3, *psysip4, *pSubmit_action;
	char_t *pmac1, *pmac2, *pmac3, *pmac4, *pmac5, *pmac6, *hostname =
	    NULL, *cpeid = NULL, *phost = NULL;
	char_t *macaddress = NULL;
	char_t *ipaddress = NULL;
	char_t *pstatus = NULL;
	char_t sAddIP[MAX_FILELINE_LEN];
	char_t sAddMAC[MAX_FILELINE_LEN];
	char_t sAddHOST[MAX_FILELINE_LEN];
	int32 op = IFX_OP_ADD, ret = IFX_SUCCESS, iRet = IFX_SUCCESS;
	uint32 flags = IFX_F_DEFAULT;
	IFX_MAPI_DHCPS_STATIC_LEASE p_info, *pp_info = NULL ;
	DHCP_SERVER_INFO dhcp;
	uint32 ip_start_token1, ip_start_token2, ip_start_token3, ip_start_token4;
	uint32 ip_end_token1, ip_end_token2, ip_end_token3, ip_end_token4;
	uint32 ip_flag_token = IFX_SUCCESS;
	char_t sDhcpsStartIP[MAX_FILELINE_LEN], sDhcpsEndIP[MAX_FILELINE_LEN];
	uint32 Flags = IFX_F_DEFAULT;
	int32 i=0 , num =0;

	psysip1 = NULL;
	psysip2 = NULL;
	psysip3 = NULL;
	psysip4 = NULL;
	pmac1 = NULL;
	pmac2 = NULL;
	pmac3 = NULL;
	pmac4 = NULL;
	pmac5 = NULL;
	pmac6 = NULL;
	hostname = NULL;

	pSubmit_action = ifx_httpdGetVar(wp, T("submit_action"), T(""));

	psysip1 = ifx_httpdGetVar(wp, T("sysip1"), T(""));
	psysip2 = ifx_httpdGetVar(wp, T("sysip2"), T(""));
	psysip3 = ifx_httpdGetVar(wp, T("sysip3"), T(""));
	psysip4 = ifx_httpdGetVar(wp, T("sysip4"), T(""));
	pmac1 = ifx_httpdGetVar(wp, T("mac1"), T(""));
	pmac2 = ifx_httpdGetVar(wp, T("mac2"), T(""));
	pmac3 = ifx_httpdGetVar(wp, T("mac3"), T(""));
	pmac4 = ifx_httpdGetVar(wp, T("mac4"), T(""));
	pmac5 = ifx_httpdGetVar(wp, T("mac5"), T(""));
	pmac6 = ifx_httpdGetVar(wp, T("mac6"), T(""));
	pstatus = ifx_httpdGetVar(wp, T("fenable"), T(""));

	phost = ifx_httpdGetVar(wp, T("host"), T(""));

	memset(&p_info, 0x00, sizeof(p_info));

	if (!(gstrcmp(pSubmit_action, "add"))) {
		op = IFX_OP_ADD;
		flags = IFX_F_DEFAULT;
		p_info.enable = atoi(pstatus);
	} else if (!(gstrcmp(pSubmit_action, "modify_config"))) {
		cpeid = ifx_httpdGetVar(wp, T("delcpeID"), T(""));
		IFX_DBG("**Vipul**:enter in modify config");
		strcpy(static_lease_cpeId, cpeid);
		ifx_httpdRedirect(wp, "reserve_config.asp");
		return;
	} else if (!gstrcmp(pSubmit_action, "delete")) {
		op = IFX_OP_DEL;
		flags = IFX_F_DELETE;

		cpeid = ifx_httpdGetVar(wp, T("delcpeID"), T(""));
		ipaddress = ifx_httpdGetVar(wp, T("delip"), T(""));
		macaddress = ifx_httpdGetVar(wp, T("delmac"), T(""));
		hostname = ifx_httpdGetVar(wp, T("delhost"), T(""));
	} else if (!gstrcmp(pSubmit_action, "modify")) {
		op = IFX_OP_MOD;
		flags = IFX_F_MODIFY;
	}

	if (op == IFX_OP_ADD || op == IFX_OP_MOD) {
		
		if (op == IFX_OP_ADD) {
			gsprintf(sAddIP, T("%s.%s.%s.%s"), psysip1, psysip2, psysip3, psysip4);
			gsprintf(sAddMAC, T("%s:%s:%s:%s:%s:%s"),pmac1,pmac2,pmac3,pmac4,pmac5,pmac6);	
			ret = ifx_get_all_dhcps_static_lease(&num, &pp_info, Flags);
		        if (ret == IFX_SUCCESS) 
			{
				for (i = 0; i < num; i++) 
				{
					if (!(gstrcmp(sAddIP,(pp_info + i)->ipAddr)) || !(gstrcmp(sAddMAC,(pp_info + i)->macAddr)))
					{
						ifx_httpdError(wp, 500,T("IP ADDRESS RESERVED or MAC ID already used..CHOOSE ANOTHER "));
                                		goto IFX_Handler;
					}
				}
			}
		}

		if (op == IFX_OP_MOD) {
			p_info.iid.cpeId.Id = gatoi(static_lease_cpeId);

			iRet =
			    ifx_get_dhcps_static_lease(&p_info, IFX_F_DEFAULT);
			if (iRet != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ifx_httpdError(wp, 500,
					       T("FAILED TO GET LEASE VALUES"));

				goto IFX_Handler;

			}
		}
		p_info.enable = atoi(pstatus);
		gsprintf(sAddIP, T("%s.%s.%s.%s"), psysip1, psysip2, psysip3,
			 psysip4);
		strcpy(p_info.ipAddr, sAddIP);
		memset(&dhcp, 0x00, sizeof(DHCP_SERVER_INFO));
		iRet = ifx_get_lan_dhcp_server_config(&dhcp, IFX_F_DEFAULT);
		if (iRet != IFX_FAILURE) {
			strcpy(sDhcpsStartIP,inet_ntoa(dhcp.start_ip));
			strcpy(sDhcpsEndIP,inet_ntoa(dhcp.end_ip));

			ip_start_token1 = atoi(strtok (sDhcpsStartIP,"."));
			ip_start_token2 = atoi(strtok (NULL,"."));
			ip_start_token3 = atoi(strtok (NULL,"."));
			ip_start_token4 = atoi(strtok (NULL,"."));
			ip_end_token1 = atoi(strtok (sDhcpsEndIP,"."));
			ip_end_token2 = atoi(strtok (NULL,"."));
			ip_end_token3 = atoi(strtok (NULL,"."));
			ip_end_token4 = atoi(strtok (NULL,"."));

			if(!(ip_start_token1 <= atoi(psysip1) && atoi(psysip1) <= ip_end_token1)) {
				ip_flag_token = IFX_FAILURE;
				goto IFX_Handler;
			}
			if(!(ip_start_token2 <= atoi(psysip2) && atoi(psysip2) <= ip_end_token2)) {
                                ip_flag_token = IFX_FAILURE;
                                goto IFX_Handler;
			}
			if(!(ip_start_token3 <= atoi(psysip3) && atoi(psysip3) <= ip_end_token3)) {
                                ip_flag_token = IFX_FAILURE;
                                goto IFX_Handler;
			}
			if(ip_start_token3 < atoi(psysip3) && atoi(psysip3) == ip_end_token3) {
				if(!(atoi(psysip4) < ip_end_token4)) {
       	                                ip_flag_token = IFX_FAILURE;
               	                        goto IFX_Handler;
				}
			}
			else if(ip_start_token3 == atoi(psysip3) && atoi(psysip3) < ip_end_token3) {
				if(!(atoi(psysip4) > ip_start_token3)) {
               	                        ip_flag_token = IFX_FAILURE;
                       	                goto IFX_Handler;
				}
			}
			else {
				if(!(atoi(psysip4) >= ip_start_token4) || !(atoi(psysip4) <= ip_end_token4) ) {
       	                                ip_flag_token = IFX_FAILURE;
               	                        goto IFX_Handler;
			     }
			}
		}

		gsprintf(sAddMAC, T("%s:%s:%s:%s:%s:%s"), pmac1, pmac2, pmac3,
			 pmac4, pmac5, pmac6);
		strcpy(p_info.macAddr, sAddMAC);

		gsprintf(sAddHOST, T("%s"), phost);
		strcpy(p_info.host, phost);

		p_info.iid.config_owner = IFX_WEB;

	} else if (op == IFX_OP_DEL) {
		strcpy(p_info.ipAddr, ipaddress);
		strcpy(p_info.macAddr, macaddress);
		strcpy(p_info.host, hostname);

		p_info.iid.cpeId.Id = gatoi(cpeid);
	}
	strncpy(p_info.iid.cpeId.secName, TAG_LAN_DHCPS_STATIC_LEASE,
		strlen(TAG_LAN_DHCPS_STATIC_LEASE));
	strncpy(p_info.iid.pcpeId.secName, TAG_LAN_DHCPS,
		strlen(TAG_LAN_DHCPS));
	p_info.iid.config_owner = IFX_WEB;

	if (op == IFX_OP_ADD || op == IFX_OP_DEL || op == IFX_OP_MOD) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = ifx_set_dhcps_static_lease(op, &p_info, flags);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ifx_httpdError(wp, 500,
				       T("FAILED TO UPDATE ENTRIES !!!!"));

			goto IFX_Handler;
		}
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ifx_httpdRedirect(wp, T("reserve.asp"));
	} else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ifx_httpdRedirect(wp, T("reserve.asp"));
	}
      IFX_Handler:
	if(ip_flag_token != IFX_SUCCESS )
	{
		COPY_TO_STATUS("%s",
                                "<span class=\"textTitle\">LAN IP Reservation failed.</span><br><p>Failed to assign IP with this configuration</p>");
		ifx_httpdRedirect(wp, "err_page.html");
	}	
	IFX_MEM_FREE(pp_info)
	return;

}

//vipul end
////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
// vipul start

int ifx_get_lan_ARP(int eid, httpd_t wp, int argc, char_t ** argv);

int ifx_get_lan_ARP(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char *name = NULL;
	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	if (!gstrcmp(name, T("lan-arp")))
	{
		char IP[MAX_FILELINE_LEN], HWType[MAX_FILELINE_LEN],
		     Flags[MAX_FILELINE_LEN], HWAddr[MAX_FILELINE_LEN],
		     Mask[MAX_FILELINE_LEN], Device[MAX_FILELINE_LEN];
		FILE *fp = NULL;
		int i = 1;
		NULL_TERMINATE(IP, 0x00, sizeof(IP));
		NULL_TERMINATE(HWType, 0x00, sizeof(HWType));
		NULL_TERMINATE(Flags, 0x00, sizeof(Flags));
		NULL_TERMINATE(HWAddr, 0x00, sizeof(HWAddr));
		NULL_TERMINATE(Mask, 0x00, sizeof(Mask));
		NULL_TERMINATE(Device, 0x00, sizeof(Device));
		system("killall -SIGUSR1 udhcpd");
		system("cat /proc/net/arp > /tmp/try");
		fp = fopen("/tmp/try", "r");
		if (fp != NULL) {
			fgets(Device, MAX_FILELINE_LEN, fp);
			while (fscanf
					(fp, "%[^ ] %[^ ] %[^ ] %[^ ] %[^ ] %[^\n]\n", IP,
					 HWType, Flags, HWAddr, Mask, Device) > 0) {
				ifx_httpdWrite(wp,
						T
						("<tr> <td id=\"larp_mac_add%d\">%s</td>\n"),
						i, HWAddr);
				ifx_httpdWrite(wp,
						T
						("  <td id=\"larp_ip_add%d\">%s</td>\n"),
						i, IP);
				ifx_httpdWrite(wp,
						T
						("  <td id=\"larp_hw_typ%d\">%s</td></tr>\n"),
						i, HWType);
				i++;
			}
			fclose(fp);
		}
		system("rm -f /tmp/try");
	}
	if (!gstrcmp(name, T("arp-scan")))
	{
		#ifdef CONFIG_FEATURE_WEB_REDIRECTOR
			ifx_httpdWrite(wp,T("<br><br>\n<a class=\"buttonLarge\" href=\"#\" value=\"arp-scan\" name=\"arp-scan\" onClick=\"window.location='lan_ip_host.asp'\">Perform ARP Scan</a>\n"));
		#endif
	}
	return 0;
}

// vipul end
//////////////////////////////////////////////////////////////////

// UPnPDevices
int ifx_get_lan_upnp_devices(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char IP[MAX_FILELINE_LEN], FRND_NAME[MAX_FILELINE_LEN],
	    UUID[MAX_FILELINE_LEN];
	FILE *fp = NULL;
	int i = 0, j = 0, lanCount;

	int32 flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT;
	char buf[MAX_FILELINE_LEN], sVal[MAX_FILELINE_LEN],
	    cmd[MAX_FILELINE_LEN];

	NULL_TERMINATE(IP, 0x00, sizeof(IP));
	NULL_TERMINATE(FRND_NAME, 0x00, sizeof(FRND_NAME));
	NULL_TERMINATE(UUID, 0x00, sizeof(UUID));

	memset(sVal, 0, MAX_FILELINE_LEN);
	sprintf(buf, "%s", "lan_main_Count");
	if (ifx_GetObjData
	    (FILE_RC_CONF, TAG_LAN_MAIN, buf, flags,
	     (IFX_OUT uint32 *) & outFlag, sVal) != IFX_SUCCESS) {
		return 0;
	}

	if (sVal[0] == '\0')
		return 0;

	lanCount = atoi(sVal);

	for (j = 0; j < lanCount; j++) {
		sprintf(buf, "lan_main_%d_interface", j);
		memset(sVal, 0, MAX_FILELINE_LEN);
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_LAN_MAIN, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, sVal) != IFX_SUCCESS) {
			continue;
		}
		if (sVal[0] == '\0')
			continue;

		snprintf(cmd,MAX_FILELINE_LEN, "upnpc -i %s -d 3", sVal);
		system(cmd);

		fp = fopen("/tmp/UPnPDevInfo.txt", "r");
		if (fp != NULL) {
			while (fscanf
			       (fp, "%[^\n]\n%[^\n]\n%[^\n]\n\n", IP, FRND_NAME,
				UUID) > 0) {
				ifx_httpdWrite(wp,
					       T
					       ("  <td id=\"lupnp_ip_add%d\">%s</td>\n"),
					       i, IP);

		                ifx_httpdWrite(wp,
			 		       T
					       ("  <td id=\"lupnp_frnd_name%d\">%s</td>\n"),
					       i, FRND_NAME);
				ifx_httpdWrite(wp,
					       T
					       ("  <td id=\"lupnp_uuid%d\">%s</td></tr>\n"),
					       i, UUID);
				i++;
			}
			fclose(fp);
		}
                else
                {
                         goto IFX_Handler;
                }

	}
IFX_Handler:
	return 0;
}

// UPnPDevices end

void ifx_set_lan_dhcps(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pSysIP1, *pSysIP2, *pSysIP3, *pSysIP4;
	char_t *pSysMASK1, *pSysMASK2, *pSysMASK3, *pSysMASK4;
#if !defined (CONFIG_FEATURE_LTQ_HNX_CONFIG) && !defined (CONFIG_FEATURE_LTQ_WIRELESS_VB)
	struct connection_profil_list *seekPtr = NULL, *prevseekPtr = NULL;
#endif

	char_t *pgSysIP1, *pgSysIP2, *pgSysIP3, *pgSysIP4;
	char_t *pgSysMASK1, *pgSysMASK2, *pgSysMASK3, *pgSysMASK4;

	char_t *pCheck;
	pCheck = ifx_httpdGetVar(wp, T("global_subnet"), T(""));
#if defined (CONFIG_FEATURE_LTQ_HNX_CONFIG) || defined (CONFIG_FEATURE_LTQ_WIRELESS_VB)
	char_t *pSysGw1, *pSysGw2, *pSysGw3, *pSysGw4;
	char_t *pSysDns1, *pSysDns2, *pSysDns3, *pSysDns4;
	char_t *pDhcpDisable;
	IP_MASK_TYPE    *ip_array_type;
        int count = 0;
#endif				/* CONFIG_FEATURE_LTQ_HNX_CONFIG */
        uint32  flags = IFX_F_DEFAULT;
	int ret = TRUE;
#if !defined (CONFIG_FEATURE_LTQ_HNX_CONFIG) && !defined (CONFIG_FEATURE_LTQ_WIRELESS_VB)
	int mode = 0;
	uint32 inflag = IFX_F_GET_ANY, outflag = IFX_F_DEFAULT;
	char_t sValue[MAX_FILELINE_LEN], sValue1[MAX_FILELINE_LEN];
	char_t sDhcpsMask[MAX_IP_ADDR_LEN];
	char_t *pDhcpMode = NULL;
	char_t *pDhcpRelayServer = NULL;
	// char_t *pDhcpRelayIF = NULL, sDhcpRelayIF[MAX_CONN_NAME_LEN];
#endif				/* !CONFIG_FEATURE_LTQ_HNX_CONFIG */
	char_t setCommand[MAX_FILELINE_LEN];

	char_t mask[MAX_IP_ADDR_LEN];
#if !defined (CONFIG_FEATURE_LTQ_HNX_CONFIG) && !defined (CONFIG_FEATURE_LTQ_WIRELESS_VB)
	DHCP_SERVER_INFO server;
	DHCP_RELAY_SERVER relay;
#endif				/* !CONFIG_FEATURE_LTQ_HNX_CONFIG */
	IP_MASK_TYPE ip_mask_type;

#if !defined (CONFIG_FEATURE_LTQ_HNX_CONFIG) && !defined (CONFIG_FEATURE_LTQ_WIRELESS_VB)
#ifdef CONFIG_FEATURE_DHCP_SERVER
	int i, nEnd = 0, nStart = 0;
	int32 nLeaseTime = 0;
	char_t *pDhcpsStartIP1 = NULL, *pDhcpsStartIP2 = NULL, *pDhcpsStartIP3 =
	    NULL, *pDhcpsStartIP4 = NULL, *pDhcpsEndIP1 = NULL, *pDhcpsEndIP2 =
	    NULL, *pDhcpsEndIP3 = NULL, *pDhcpsEndIP4 = NULL, *pLeaseTime =
	    NULL, *pDN = NULL;
	char_t sMaxLease[MAX_NAME_SIZE], sLeaseTime[MAX_NAME_SIZE],
	    sDN[MAX_NAME_LEN];
	char_t sDhcpsStartIP[MAX_FILELINE_LEN], sDhcpsEndIP[MAX_FILELINE_LEN];

	sMaxLease[0] = '\0';
	sLeaseTime[0] = '\0';
	sDN[0] = '\0';
	sDhcpsEndIP[0] = '\0';
	sDhcpsStartIP[0] = '\0';
	sValue[0] = '\0';
	sValue1[0] = '\0';
	setCommand[0] = '\0';
#endif				//CONFIG_FEATURE_DHCP_SERVER

#ifdef CONFIG_FEATURE_IFX_WIRELESS_ATH
	char_t *pWlan;
	char_t sWlan[MAX_FILELINE_LEN];
	char_t sWlan_Command[MAX_FILELINE_LEN];
#endif
#endif				/* !CONFIG_FEATURE_LTQ_HNX_CONFIG */

	char_t *pMac1 = NULL, *pMac2 = NULL, *pMac3 = NULL, *pMac4 =
	    NULL, *pMac5 = NULL, *pMac6 = NULL;
	char_t sMac[20], sOldMac[20], command[40];
	FILE *fp = NULL;

	a_assert(wp);
#if !defined (CONFIG_FEATURE_LTQ_HNX_CONFIG) && !defined (CONFIG_FEATURE_LTQ_WIRELESS_VB)
	char_t *dhcpServerCmd = ifx_httpdGetVar(wp, T("dhcpAction"), T(""));
	if (!gstrcmp(dhcpServerCmd, "Dhcp_conditional_server")) {
		ifx_httpdRedirect(wp, "lan_dhcp_cond_serv_config.asp");
		return;
	}
#endif				/* !CONFIG_FEATURE_LTQ_HNX_CONFIG */
	// memset(sMac,0x00,sizeof(sMac);
	pMac1 = ifx_httpdGetVar(wp, T("mac1"), T(""));
	pMac2 = ifx_httpdGetVar(wp, T("mac2"), T(""));
	pMac3 = ifx_httpdGetVar(wp, T("mac3"), T(""));
	pMac4 = ifx_httpdGetVar(wp, T("mac4"), T(""));
	pMac5 = ifx_httpdGetVar(wp, T("mac5"), T(""));
	pMac6 = ifx_httpdGetVar(wp, T("mac6"), T(""));

	sprintf(sMac, "%s:%s:%s:%s:%s:%s", pMac1, pMac2, pMac3, pMac4, pMac5,
		pMac6);

	memset(&ip_mask_type, 0x00, sizeof(IP_MASK));
#if !defined (CONFIG_FEATURE_LTQ_HNX_CONFIG) && !defined (CONFIG_FEATURE_LTQ_WIRELESS_VB)
	memset(&server, 0x00, sizeof(DHCP_SERVER_INFO));
	memset(&relay, 0x00, sizeof(DHCP_RELAY_SERVER));
	sDhcpsMask[0] = '\0';
	// sDhcpRelayIF[0]='\0';
#endif				/* !CONFIG_FEATURE_LTQ_HNX_CONFIG */

#if defined (CONFIG_FEATURE_LTQ_HNX_CONFIG) || defined (CONFIG_FEATURE_LTQ_WIRELESS_VB)
        pDhcpDisable = ifx_httpdGetVar(wp, T("DHCP_Disable"), T(""));

        if (!gstrcmp(pDhcpDisable, "1")) {
#endif /* CONFIG_FEATURE_LTQ_HNX_CONFIG */

	// Get value from ASP file
	pSysIP1 = ifx_httpdGetVar(wp, T("sysip1"), T(""));
	pSysIP2 = ifx_httpdGetVar(wp, T("sysip2"), T(""));
	pSysIP3 = ifx_httpdGetVar(wp, T("sysip3"), T(""));
	pSysIP4 = ifx_httpdGetVar(wp, T("sysip4"), T(""));
	// Get MASK value from ASP file
	pSysMASK1 = ifx_httpdGetVar(wp, T("sysmask1"), T(""));
	pSysMASK2 = ifx_httpdGetVar(wp, T("sysmask2"), T(""));
	pSysMASK3 = ifx_httpdGetVar(wp, T("sysmask3"), T(""));
	pSysMASK4 = ifx_httpdGetVar(wp, T("sysmask4"), T(""));

	// Get value from ASP file
	pgSysIP1 = ifx_httpdGetVar(wp, T("gsysip1"), T(""));
	pgSysIP2 = ifx_httpdGetVar(wp, T("gsysip2"), T(""));
	pgSysIP3 = ifx_httpdGetVar(wp, T("gsysip3"), T(""));
	pgSysIP4 = ifx_httpdGetVar(wp, T("gsysip4"), T(""));
	// Get MASK value from ASP file
	pgSysMASK1 = ifx_httpdGetVar(wp, T("gsysmask1"), T(""));
	pgSysMASK2 = ifx_httpdGetVar(wp, T("gsysmask2"), T(""));
	pgSysMASK3 = ifx_httpdGetVar(wp, T("gsysmask3"), T(""));
	pgSysMASK4 = ifx_httpdGetVar(wp, T("gsysmask4"), T(""));


#if defined (CONFIG_FEATURE_LTQ_HNX_CONFIG) || defined (CONFIG_FEATURE_LTQ_WIRELESS_VB)

	//Get GW Value from ASP file
	pSysGw1 = ifx_httpdGetVar(wp, T("gatw1"), T(""));
	pSysGw2 = ifx_httpdGetVar(wp, T("gatw2"), T(""));
	pSysGw3 = ifx_httpdGetVar(wp, T("gatw3"), T(""));
	pSysGw4 = ifx_httpdGetVar(wp, T("gatw4"), T(""));

	//Get DNS Value from ASP file

	pSysDns1 = ifx_httpdGetVar(wp, T("dns1"), T(""));
	pSysDns2 = ifx_httpdGetVar(wp, T("dns2"), T(""));
	pSysDns3 = ifx_httpdGetVar(wp, T("dns3"), T(""));
	pSysDns4 = ifx_httpdGetVar(wp, T("dns4"), T(""));

 	} else {
        pSysIP1 = pSysIP2 = pSysIP3 = pSysIP4 = NULL;
        pSysMASK1 = pSysMASK2 = pSysMASK3 = pSysMASK4 = NULL;
        pSysGw1 = pSysGw2 = pSysGw3 = pSysGw4 = NULL;
        pSysDns1 = pSysDns2 = pSysDns3 = pSysDns4 = NULL;

	pgSysIP1 = pgSysIP2 = pgSysIP3 = pgSysIP4 = NULL;
        pgSysMASK1 = pgSysMASK2 = pgSysMASK3 = pgSysMASK4 = NULL;

        ret = ifx_get_lan_ip_mask("br0", &count, &ip_array_type, flags);

        if (ret != IFX_SUCCESS ||
                (ip_array_type == NULL)) {
        IFX_DBG("\n\n GET  FAILED %s \n\n", __FUNCTION__);
                goto IFX_Handler;
        }
        }
#endif				/*CONFIG_FEATURE_LTQ_HNX_CONFIG */

#ifdef CONFIG_FEATURE_DHCP_SERVER
	ret = ifx_get_lan_dhcp_server_config(&server, flags);
        if (ret != IFX_SUCCESS) {
	#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to read current DHCP server config", __FUNCTION__, __LINE__);
	#endif
                goto IFX_Handler;
        }
#endif

#if !defined (CONFIG_FEATURE_LTQ_HNX_CONFIG) && !defined (CONFIG_FEATURE_LTQ_WIRELESS_VB)
#ifdef IFX_LOG_DEBUG
	IFX_DBG("\n\n In Function [%s] : checkpoint 1\n\n", __FUNCTION__);
#endif
	memset(sValue, 0x00, sizeof(sValue));
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, "lan_main_0_ipAddr",
			    inflag, &outflag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n Error : Failed to get ifconfig_lan from rc.conf !! \n\n");
#endif
		goto IFX_Handler;
	}
	memset(sValue1, 0x00, sizeof(sValue1));
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, "lan_main_0_netmask",
			    inflag, &outflag, sValue1)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n Error : Failed to get netmask from rc.conf !! \n\n");
#endif
#ifdef CONFIG_FEATURE_IFX_WIRELESS_ATH
		char_t *pWlan;
		char_t sWlan[MAX_FILELINE_LEN];
		char_t sWlan_Command[MAX_FILELINE_LEN];
#endif

		goto IFX_Handler;
	}
	snprintf(sValue, sizeof(sValue), ("%s netmask %s"), sValue, sValue1);
#else				/* !CONFIG_FEATURE_LTQ_HNX_CONFIG */
	 if (!gstrcmp(pDhcpDisable, "1")) {
#endif 				/* !CONFIG_FEATURE_LTQ_HNX_CONFIG */
	gsprintf(mask, T("%s.%s.%s.%s"), pSysMASK1, pSysMASK2, pSysMASK3,
		 pSysMASK4);

	/* fill in the lan ip mask structure */
	gsprintf(setCommand, T("%s.%s.%s.%s"), pSysIP1, pSysIP2, pSysIP3,
		 pSysIP4);
	ip_mask_type.ip_mask.ip.s_addr = inet_addr(setCommand);
	ip_mask_type.ip_mask.mask.s_addr = inet_addr(mask);

#if defined (CONFIG_FEATURE_LTQ_HNX_CONFIG) || defined (CONFIG_FEATURE_LTQ_WIRELESS_VB)
	 } else {
        memcpy(&ip_mask_type.ip_mask.ip.s_addr, &ip_array_type->ip_mask.ip.s_addr, sizeof(struct in_addr));
        memcpy(&ip_mask_type.ip_mask.mask.s_addr, &ip_array_type->ip_mask.mask.s_addr, sizeof(struct in_addr));
        }
#else /* CONFIG_FEATURE_LTQ_HNX_CONFIG */
	gsprintf(setCommand, T("%s.%s.%s.%s netmask %s"), pSysIP1, pSysIP2,
		 pSysIP3, pSysIP4, mask);
	if (gstrcmp(sValue, setCommand) != 0) {
		// clear all connection record
		seekPtr = connlist;
		prevseekPtr = seekPtr;
		while(seekPtr != NULL) {
			prevseekPtr = seekPtr->next;
			IFX_MEM_FREE(seekPtr)
			seekPtr = prevseekPtr;
		}
		connlist = NULL;
	}
	// Get the DHCP Mode configured from ASP file
	pDhcpMode = ifx_httpdGetVar(wp, T("lan_dhcp_mode"), T(""));
	if (pDhcpMode && !strcmp("server", pDhcpMode)) {
#ifdef CONFIG_FEATURE_DHCP_SERVER
		pDhcpsStartIP1 = ifx_httpdGetVar(wp, T("DhcpsStartIP1"), T(""));
		pDhcpsStartIP2 = ifx_httpdGetVar(wp, T("DhcpsStartIP2"), T(""));
		pDhcpsStartIP3 = ifx_httpdGetVar(wp, T("DhcpsStartIP3"), T(""));
		pDhcpsStartIP4 = ifx_httpdGetVar(wp, T("DhcpsStartIP4"), T(""));

		pDhcpsEndIP1 = ifx_httpdGetVar(wp, T("DhcpsEndIP1"), T(""));
		pDhcpsEndIP2 = ifx_httpdGetVar(wp, T("DhcpsEndIP2"), T(""));
		pDhcpsEndIP3 = ifx_httpdGetVar(wp, T("DhcpsEndIP3"), T(""));
		pDhcpsEndIP4 = ifx_httpdGetVar(wp, T("DhcpsEndIP4"), T(""));

		pLeaseTime = ifx_httpdGetVar(wp, T("LeaseTime"), T(""));
		pDN = ifx_httpdGetVar(wp, T("DN"), T(""));

		nEnd = gatoi(pDhcpsEndIP4);
		nStart = gatoi(pDhcpsStartIP4);

		sprintf(server.iface, "%s", "\0");

		server.netmask.s_addr = inet_addr(mask);

		server.dhcp_mode = IFX_ENABLED;

		
		/******FILL DHCP START ENDIP ***************************/	
		#ifdef CONFIG_FEATURE_DHCP_AUTOFILL
			if(atoi(pCheck) == 1)
			{
		  		gsprintf(mask, T("%s.%s.%s.%s"), pgSysMASK1, pgSysMASK2, pgSysMASK3,
                			 pgSysMASK4);
		        	/* fill in the lan ip mask structure */
	        		gsprintf(setCommand, T("%s.%s.%s.%s"), pgSysIP1, pgSysIP2, pgSysIP3,
        	        		 pgSysIP4);
			}
			else
			{
				gsprintf(mask, T("%s.%s.%s.%s"), pSysMASK1, pSysMASK2, pSysMASK3,
		        	         pSysMASK4);

			        /* fill in the lan ip mask structure */
			        gsprintf(setCommand, T("%s.%s.%s.%s"), pSysIP1, pSysIP2, pSysIP3,
                			 pSysIP4);	
			}
			ret = dhcpmin_maxadress(setCommand ,mask, sDhcpsStartIP, sDhcpsEndIP);
			server.start_ip.s_addr = inet_addr(sDhcpsStartIP);
			server.end_ip.s_addr = inet_addr(sDhcpsEndIP);
		#else 		
			gsprintf(sDhcpsStartIP, T("%s.%s.%s.%s"), pDhcpsStartIP1,
                        	 pDhcpsStartIP2, pDhcpsStartIP3, pDhcpsStartIP4);

			gsprintf(sDhcpsEndIP, T("%s.%s.%s.%s"), pDhcpsEndIP1,
				 pDhcpsEndIP2, pDhcpsEndIP3, pDhcpsEndIP4);

		IFX_DBG(" start ip and endip : %s :%s in line %d ", sDhcpsStartIP,sDhcpsEndIP, __LINE__);
			server.start_ip.s_addr = inet_addr(sDhcpsStartIP);
			server.end_ip.s_addr = inet_addr(sDhcpsEndIP);
		#endif //Autofill macro

		gsprintf(sMaxLease, T("%d\n"), nEnd - nStart);
		/* server.max_leases = gatoi(sMaxLease); */

		if (pDN && *pDN)
			gsprintf(sDN, T("%s"), pDN);
		else
			gsprintf(sDN, T("%s"), "\0");
		gstrcpy(server.dhcp_domain_name, sDN);

		nLeaseTime = gatoi(pLeaseTime);
		for (i = 0; i < sizeof(nSelLeaseTime) / sizeof(ST_LEASE_TIME);
		     i++) {
			if (nLeaseTime == i) {
				nLeaseTime = nSelLeaseTime[i].nValue;
				break;
			}
		}

		gsprintf(sLeaseTime, T("%d\n"), nLeaseTime);
		server.leasetime = nLeaseTime;
#endif
	} else if (pDhcpMode && !strcmp("relay", pDhcpMode)) {
		sprintf(setCommand, "%s", "default_wan_conn_iface");
		if ((ret =
		     ifx_GetObjData(FILE_RC_CONF, TAG_DEFAULT_WAN, setCommand,
				    IFX_F_GET_ANY, &outflag,
				    relay.server_if)) != IFX_SUCCESS) {
			COPY_TO_STATUS("%s",
				       "<span class=\"textTitle\">LAN DHCP Relay configuration failed.</span><br><p>Failed to read Default WAN configuration</p>");
			ifx_httpdRedirect(wp, "err_page.html");
			return;
		}

		pDhcpRelayServer =
		    ifx_httpdGetVar(wp, T("dhcp_relay_server"), T(""));
		relay.dhcp_relay_server.s_addr = inet_addr(pDhcpRelayServer);
	} else {
		server.dhcp_mode = IFX_DISABLED;
	}

	if(atoi(pCheck) == 1)
        {
		gsprintf(sDhcpsMask, T("%s.%s.%s.%s"), pgSysMASK1, pgSysMASK2, pgSysMASK3,
                 pgSysMASK4);
	}
	else
	{
	gsprintf(sDhcpsMask, T("%s.%s.%s.%s"), pSysMASK1, pSysMASK2, pSysMASK3,
		 pSysMASK4);
	}
	server.netmask.s_addr = inet_addr(sDhcpsMask);

/* make the ip address of the lan ip interface 0 as the default gw for the dhcp server */
	if(atoi(pCheck) == 1)
	{
		sprintf(setCommand, "%s", "lan_main_1_ipAddr");
	}	
	else
	{
		sprintf(setCommand, "%s", "lan_main_0_ipAddr");	// hard coded for First Lan Device
	}	
	memset(sValue, 0x00, sizeof(sValue));
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, setCommand,
			    IFX_F_GET_ANY, &outflag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error-->Lan IP Address not found !!\n\n",
		     __FUNCTION__);
#endif
		ret = IFX_FAILURE;
	}
	server.ip_gw.s_addr = inet_addr(sValue);

#ifdef NOT_SUPPORT_FOR_NOW
#ifdef CONFIG_FEATURE_IFX_WIRELESS_ATH
	pWlan = ifx_httpdGetVar(wp, T("wlan_enable"), T(""));
	/* server.wlan_enable = atoi(pWlan); */
#endif
#endif

	gsprintf(mask, T("%s.%s.%s.%s"), pSysMASK1, pSysMASK2, pSysMASK3,pSysMASK4);
	gsprintf(setCommand,T("ifconfig_lan=\"%s.%s.%s.%s\"\nnetmask=\"%s\"\n"), pSysIP1,
		 pSysIP2, pSysIP3, pSysIP4, mask);

	if ((pDhcpMode) && (!strcmp(pDhcpMode, "server")))
		mode = IFX_DHCP_SERVER_MODE;
	else if ((pDhcpMode) && (!strcmp(pDhcpMode, "relay")))
		mode = IFX_DHCP_RELAY_MODE;
	else
		mode = IFX_DISABLED;
#endif				/* CONFIG_FEATURE_LTQ_HNX_CONFIG */

	sprintf(ip_mask_type.iid.cpeId.secName, "%s", TAG_LAN_MAIN);
#if !defined (CONFIG_FEATURE_LTQ_HNX_CONFIG) && !defined (CONFIG_FEATURE_LTQ_WIRELESS_VB)
	sprintf(server.iid.cpeId.secName, "%s", TAG_LAN_DHCPS);
	sprintf(relay.iid.cpeId.secName, "%s", TAG_LAN_DHCP_RELAY);
#endif				/* !CONFIG_FEATURE_LTQ_HNX_CONFIG */
	ip_mask_type.iid.cpeId.Id = 1;
	ip_mask_type.iid.pcpeId.Id = 1;
#if defined (CONFIG_FEATURE_LTQ_HNX_CONFIG) || defined (CONFIG_FEATURE_LTQ_WIRELESS_VB)
	if (!gstrcmp(pDhcpDisable, "1"))
		ip_mask_type.ip_type = IP_TYPE_STATIC;
	else
		ip_mask_type.ip_type = IP_TYPE_DHCP;
#else
	ip_mask_type.ip_type = IP_TYPE_STATIC;
#endif				/* !CONFIG_FEATURE_LTQ_HNX_CONFIG */
	ip_mask_type.f_enable = IFX_ENABLED;

#if !defined (CONFIG_FEATURE_LTQ_HNX_CONFIG) && !defined (CONFIG_FEATURE_LTQ_WIRELESS_VB)
	
		IFX_DBG(" before dhcp set :start ip and endip : %s :%s in line %d ", sDhcpsStartIP,sDhcpsEndIP, __LINE__);
	ret =
	    ifx_set_dhcp_server_mode(mode,
				     IFX_F_MODIFY | IFX_F_DONT_WRITE_TO_FLASH);
	if (ret != IFX_SUCCESS) {
		ifx_httpdError(wp, 500, "Failed to set DHCP Mode !!");
		goto IFX_Handler;
	}

#ifdef CONFIG_FEATURE_IFX_WIRELESS_ATH
	pWlan = ifx_httpdGetVar(wp, T("wlan_enable"), T(""));
	gsprintf(sWlan, T("wlan_enable=\"%d\"\n"), atoi(pWlan));
	ifx_SetCfgData1(FILE_RC_CONF, TAG_WLAN_STATUS, IFX_F_MODIFY, 1, sWlan);
	if (atoi(pWlan) == 0) {
		memset(sWlan_Command, 0x00, MAX_FILELINE_LEN);
		gsprintf(sWlan_Command, T("ifconfig %s down"), IFX_WLAN_IF);
		system(sWlan_Command);
		gsprintf(sWlan_Command, T("brctl delif br0 %s"), IFX_WLAN_IF);
		system(sWlan_Command);
#ifdef CPU_AMAZON
		system("swreset wireless_down");
#else
		system("/etc/rc.d/rc.bringup_wireless stop");
#endif
	}
#endif

	ret = ifx_set_lan_interface("br0", IFX_F_MODIFY | IFX_F_DONT_WRITE_TO_FLASH);	// hard coded as of now
	if (ret != IFX_SUCCESS) {
		ifx_httpdError(wp, 500,
			       "Failed to set Lan device interface !!");
		goto IFX_Handler;
	}

	server.iid.config_owner = IFX_WEB;
	relay.iid.config_owner = IFX_WEB;
	if ((pDhcpMode) && !strcmp("server", pDhcpMode)) {
#ifdef CONFIG_FEATURE_DHCP_SERVER
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\nIn Function [%s] : Trying to configure dhcp server !!\n\n",
		     								__FUNCTION__);
#endif
		
		IFX_DBG(" start ip and endip : %s :%s in line %d ", sDhcpsStartIP,sDhcpsEndIP, __LINE__);
		ret =
		    ifx_set_lan_dhcp_server_config(IFX_OP_MOD, &server,
						   IFX_F_MODIFY |
						   IFX_F_DONT_WRITE_TO_FLASH);
#endif
	}

	else if (pDhcpMode && !strcmp("relay", pDhcpMode)) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\nIn Function [%s] : Trying to configure dhcp relay server !!\n\n",
		     __FUNCTION__);
#endif
		ret =
		    ifx_set_dhcpr_dhcp_server(IFX_OP_MOD, &relay,
					      IFX_F_MODIFY |
					      IFX_F_DONT_WRITE_TO_FLASH);
	}

	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n Error : set api returned IFX_FAILURE !! \n\n");
#endif
		ifx_httpdError(wp, 500, "Failed to save DHCP Setting !!");
		goto IFX_Handler;
	}
#ifdef DEBUG_STMT
	system
	    ("echo \"got back from dhcp api, said cgi !!\n\" >> /tmp/error_log_dhcpscgi");
#endif
#endif				/* !CONFIG_FEATURE_LTQ_HNX_CONFIG */

#if defined (CONFIG_FEATURE_LTQ_HNX_CONFIG) || defined (CONFIG_FEATURE_LTQ_WIRELESS_VB)
	/* fill in the lan gw structure */
	if (!gstrcmp(pDhcpDisable, "1")) {
	gsprintf(setCommand, T("%s.%s.%s.%s"), pSysGw1, pSysGw2, pSysGw3,
		 pSysGw4);
	ip_mask_type.gw.s_addr = inet_addr(setCommand);
	/* fill in the lan dns server structure */
	gsprintf(setCommand, T("%s.%s.%s.%s"), pSysDns1, pSysDns2, pSysDns3,
		 pSysDns4);
	ip_mask_type.dns_servers[0].s_addr = inet_addr(setCommand);
	ip_mask_type.dns_servers[1].s_addr = inet_addr("0.0.0.0");
	} else {
        memcpy(&ip_mask_type.gw.s_addr, &ip_array_type->gw.s_addr, sizeof(struct in_addr));
        memcpy(&ip_mask_type.dns_servers[0].s_addr, &ip_array_type->dns_servers[0].s_addr, sizeof(struct in_addr));
        memcpy(&ip_mask_type.dns_servers[1].s_addr, &ip_array_type->dns_servers[1].s_addr, sizeof(struct in_addr));
        IFX_MEM_FREE(ip_array_type)
        }
#endif				/* CONFIG_FEATURE_LTQ_HNX_CONFIG */

	ip_mask_type.iid.cpeId.Id = 1;
	ip_mask_type.iid.pcpeId.Id = 1;
	sprintf(ip_mask_type.iid.cpeId.secName, "%s", TAG_LAN_MAIN);
	sprintf(ip_mask_type.iid.pcpeId.secName, "%s", TAG_LAN_DHCPS);

	ip_mask_type.vip_enable = 0;
	ip_mask_type.iid.config_owner = IFX_WEB;
	sprintf(ip_mask_type.conn_name, "%s", "LAN0");
	ret = ifx_set_lan_ip_mask(IFX_OP_MOD, 0, "br0", &ip_mask_type,IFX_F_MODIFY);
	if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n Error : set api returned IFX_FAILURE !! \n\n");
#endif
		ifx_httpdError(wp, 500,
			       "Failed to save lan device configuration !!");
		goto IFX_Handler;
	}
	
       	/* Fill in the lan ip mask structure */
	gsprintf(mask, T("%s.%s.%s.%s"), pgSysMASK1, pgSysMASK2, pgSysMASK3,pgSysMASK4);
        gsprintf(setCommand, T("%s.%s.%s.%s"), pgSysIP1, pgSysIP2, pgSysIP3,pgSysIP4);

	ip_mask_type.ip_mask.ip.s_addr = inet_addr(setCommand);
        ip_mask_type.ip_mask.mask.s_addr = inet_addr(mask);

	ip_mask_type.iid.cpeId.Id = 2;
       	ip_mask_type.iid.pcpeId.Id = 1;
        sprintf(ip_mask_type.iid.cpeId.secName, "%s", TAG_LAN_MAIN);
       	sprintf(ip_mask_type.iid.pcpeId.secName, "%s", TAG_LAN_DHCPS);
        ip_mask_type.vip_enable = atoi(pCheck);
	sprintf(ip_mask_type.conn_name, "%s", "LAN1");

	ret =ifx_set_lan_ip_mask(IFX_OP_MOD, 1, "br0:1", &ip_mask_type,IFX_F_MODIFY);
        if (ret != IFX_SUCCESS) 
	{
//		#ifdef IFX_LOG_DEBUG
                IFX_DBG("\n\n Error : ifx_set_lan_ip_mask set api returned IFX_FAILURE br0:1!! \n\n");
//		#endif
               	ifx_httpdError(wp, 500,"Failed to save lan device configuration ifor br0:1!!");
                goto IFX_Handler;
       	}
	
	#ifdef DEBUG_STMT
		system("echo \"got back from lan ip, said cgi !!\n\" >> /tmp/error_log_ipmacgi");
	#endif

      IFX_Handler:

	system("upgrade mac_get 0 > /tmp/rf");
	fp = fopen("/tmp/rf", "r");
	if (fp) {
		fread(sOldMac, 20, 1, fp);
		if (strncmp(sOldMac, sMac, strlen(sMac)) != 0) {
			sprintf(command, "upgrade mac_set %s", sMac);
			system(command);
		}
	}
	if (fp) {
		fclose(fp);
		fp = NULL;
	}
	system("rm -rf /tmp/rf");
	websNextPage(wp);

}

/* This API will return either lan ip or lan nermask */
int ifx_get_lan_IP_MASK(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int ret = IFX_SUCCESS, count = 0, i = 0;
	char ip_token[MAX_IP_ADDR_LEN];
	char ip[MAX_IP_ADDR_LEN], mask[MAX_IP_ADDR_LEN];
#if defined (CONFIG_FEATURE_LTQ_HNX_CONFIG) || defined (CONFIG_FEATURE_LTQ_WIRELESS_VB)
	char gw[MAX_IP_ADDR_LEN], dns[MAX_IP_ADDR_LEN];
#endif				/* CONFIG_FEATURE_LTQ_HNX_CONFIG */
	IP_MASK_TYPE *ip_array_type;
	uint32 flags = IFX_F_DEFAULT;
	char_t *name;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	ip[0] = '\0';
	mask[0] = '\0';
#if defined (CONFIG_FEATURE_LTQ_HNX_CONFIG) || defined (CONFIG_FEATURE_LTQ_WIRELESS_VB)
	gw[0] = '\0';
	dns[0] = '\0';
#endif				/* CONFIG_FEATURE_LTQ_HNX_CONFIG */
	ip_token[0] = '\0';

	ret = ifx_get_lan_ip_mask("br0", &count, &ip_array_type, flags);

	if ((ret == IFX_SUCCESS) && (ip_array_type != NULL)) {

		if (!gstrcmp(name, "cpeId")) {
			ifx_httpdWrite(wp, T("%d"),
				       ip_array_type->iid.cpeId.Id);
		} else if (!gstrcmp(name, "pcpeId")) {
			ifx_httpdWrite(wp, T("%d"),
				       ip_array_type->iid.pcpeId.Id);
		} else if (!gstrcmp(name, "SysGW")) {
			ifx_httpdWrite(wp, T("%s"),
				       (char *)inet_ntoa(ip_array_type->gw));
		} else if (!gstrcmp(name, "SysPDNS")) {
			ifx_httpdWrite(wp, T("%s"),
				       (char *)inet_ntoa(ip_array_type->
							 dns_servers[0]));
		} else if (!gstrcmp(name, "SysSDNS")) {
			ifx_httpdWrite(wp, T("%s"),
				       (char *)inet_ntoa(ip_array_type->
							 dns_servers[1]));
		} else if (!gstrcmp(name, "SysDN")) {
			ifx_httpdWrite(wp, T("%s"), ip_array_type->domainname);
		} else if (!gstrcmp(name, "ConnName0")) {
			ifx_httpdWrite(wp, T("%s"), ip_array_type->conn_name);
#if defined (CONFIG_FEATURE_LTQ_HNX_CONFIG) || defined (CONFIG_FEATURE_LTQ_WIRELESS_VB)
		} else if (!gstrcmp(name, "Static")) {
			ifx_httpdWrite(wp, T("%s"),
				       (ip_array_type->ip_type ==
					IP_TYPE_STATIC) ? "CHECKED" : "");
		} else if (!gstrcmp(name, "Dhcp")) {
			ifx_httpdWrite(wp, T("%s"),
				       (ip_array_type->ip_type ==
					IP_TYPE_DHCP) ? "CHECKED" : "");
#endif				/* CONFIG_FEATURE_LTQ_HNX_CONFIG */
		} 
		else
		{
			for (i = 0; i < count; i++) 
			{
				sprintf(ip, "%s",inet_ntoa((ip_array_type +  i)->ip_mask.ip));

				if (!gstrcmp(name, T("SysIP"))) {
					ifx_httpdWrite(wp, T("%s"), inet_ntoa((ip_array_type + i)->ip_mask.ip));
				} else if (!gstrcmp(name, T("SysIP0"))) {
					websGetIFInfo(OTHER_IF_TYPE, IP_INFO, 1,
						      3, FALSE, ip, ip_token);
				} else if (!gstrcmp(name, T("SysIP1"))) {
					websGetIFInfo(OTHER_IF_TYPE, IP_INFO, 1,
						      1, TRUE, ip, ip_token);
				} else if (!gstrcmp(name, T("SysIP2"))) {
					websGetIFInfo(OTHER_IF_TYPE, IP_INFO, 1,
						      2, TRUE, ip, ip_token);
				} else if (!gstrcmp(name, T("SysIP3"))) {
					websGetIFInfo(OTHER_IF_TYPE, IP_INFO, 1,
						      3, TRUE, ip, ip_token);
				} else if (!gstrcmp(name, T("SysIP4"))) {
					websGetIFInfo(OTHER_IF_TYPE, IP_INFO, 1,
						      4, TRUE, ip, ip_token);
				}

				if (!gstrncmp(name, "SysIP", 5)) {
					ifx_httpdWrite(wp, T("%s"), ip_token);
					continue;
				}

				sprintf(mask, "%s",inet_ntoa((ip_array_type + i)->ip_mask.mask));

				if (!gstrcmp(name, T("SysMASK"))) {
					ifx_httpdWrite(wp, T("%s"),
						       inet_ntoa((ip_array_type
								  +
								  i)->ip_mask.
								 mask));
				} else if (!gstrcmp(name, T("SysMASK1"))) {
					websGetIFInfo(OTHER_IF_TYPE, MASK_INFO,
						      1, 1, TRUE, mask,
						      ip_token);
				} else if (!gstrcmp(name, T("SysMASK2"))) {
					websGetIFInfo(OTHER_IF_TYPE, MASK_INFO,
						      1, 2, TRUE, mask,
						      ip_token);
				} else if (!gstrcmp(name, T("SysMASK3"))) {
					websGetIFInfo(OTHER_IF_TYPE, MASK_INFO,
						      1, 3, TRUE, mask,
						      ip_token);
				} else if (!gstrcmp(name, T("SysMASK4"))) {
					websGetIFInfo(OTHER_IF_TYPE, MASK_INFO,
						      1, 4, TRUE, mask,
						      ip_token);
				}
#if !defined (CONFIG_FEATURE_LTQ_HNX_CONFIG) && !defined (CONFIG_FEATURE_LTQ_WIRELESS_VB)
				ifx_httpdWrite(wp, T("%s"), ip_token);
#else

				if (!gstrncmp(name, "SysMASK", 5)) {
					ifx_httpdWrite(wp, T("%s"), ip_token);
					continue;
				}

				sprintf(gw, "%s",
					inet_ntoa((ip_array_type + i)->gw));

				if (!gstrcmp(name, T("SysGW0"))) {
					websGetIFInfo(OTHER_IF_TYPE, IP_INFO, 1,
						      3, FALSE, gw, ip_token);
				} else if (!gstrcmp(name, T("SysGW1"))) {
					websGetIFInfo(OTHER_IF_TYPE, IP_INFO, 1,
						      1, TRUE, gw, ip_token);
				} else if (!gstrcmp(name, T("SysGW2"))) {
					websGetIFInfo(OTHER_IF_TYPE, IP_INFO, 1,
						      2, TRUE, gw, ip_token);
				} else if (!gstrcmp(name, T("SysGW3"))) {
					websGetIFInfo(OTHER_IF_TYPE, IP_INFO, 1,
						      3, TRUE, gw, ip_token);
				} else if (!gstrcmp(name, T("SysGW4"))) {
					websGetIFInfo(OTHER_IF_TYPE, IP_INFO, 1,
						      4, TRUE, gw, ip_token);
				}
				if (!gstrncmp(name, "SysGW", 5)) {
					ifx_httpdWrite(wp, T("%s"), ip_token);
					continue;
				}

				sprintf(dns, "%s",
					inet_ntoa((ip_array_type +
						   i)->dns_servers[0]));

				if (!gstrcmp(name, T("SysDNS0"))) {
					websGetIFInfo(OTHER_IF_TYPE, IP_INFO, 1,
						      3, FALSE, dns, ip_token);
				} else if (!gstrcmp(name, T("SysDNS1"))) {
					websGetIFInfo(OTHER_IF_TYPE, IP_INFO, 1,
						      1, TRUE, dns, ip_token);
				} else if (!gstrcmp(name, T("SysDNS2"))) {
					websGetIFInfo(OTHER_IF_TYPE, IP_INFO, 1,
						      2, TRUE, dns, ip_token);
				} else if (!gstrcmp(name, T("SysDNS3"))) {
					websGetIFInfo(OTHER_IF_TYPE, IP_INFO, 1,
						      3, TRUE, dns, ip_token);
				} else if (!gstrcmp(name, T("SysDNS4"))) {
					websGetIFInfo(OTHER_IF_TYPE, IP_INFO, 1,
						      4, TRUE, dns, ip_token);
				}
				ifx_httpdWrite(wp, T("%s"), ip_token);
#endif				/* CONFIG_FEATURE_LTQ_HNX_CONFIG */
			}
		}
		IFX_MEM_FREE(ip_array_type)
		}
		ret = ifx_get_lan_ip_mask("br0:1", &count, &ip_array_type, flags);
			if ((ret == IFX_SUCCESS) && (ip_array_type != NULL)) 
			{
				if (!gstrcmp(name, "ConnName1")) {
					ifx_httpdWrite(wp, T("%s"), ip_array_type->conn_name);
				}
				for (i = 0; i < count; i++) 
				{
					sprintf(ip, "%s",inet_ntoa((ip_array_type +  i)->ip_mask.ip));
					if (!gstrcmp(name, T("VIP_Enable")))
                               		{
                                       		if(((ip_array_type +i)->vip_enable)==1)
                                       		{
                                               		ifx_httpdWrite(wp, T("%s"), "checked");
                                       		}
                                       		else
                                       		{
                                               		ifx_httpdWrite(wp, T("%s"), "");
                                       		}
                               		}
					if (!gstrcmp(name, T("gSysIP"))) {
						ifx_httpdWrite(wp, T("%s"),
							       inet_ntoa((ip_array_type  + i)->ip_mask.ip));
					} else if (!gstrcmp(name, T("gSysIP0"))) {
						websGetIFInfo(OTHER_IF_TYPE, IP_INFO, 1, 3, FALSE, ip, ip_token);
					} else if (!gstrcmp(name, T("gSysIP1"))) {
						websGetIFInfo(OTHER_IF_TYPE, IP_INFO, 1, 1, TRUE, ip, ip_token);
					} else if (!gstrcmp(name, T("gSysIP2"))) {
						websGetIFInfo(OTHER_IF_TYPE, IP_INFO, 1, 2, TRUE, ip, ip_token);
					} else if (!gstrcmp(name, T("gSysIP3"))) {
						websGetIFInfo(OTHER_IF_TYPE, IP_INFO, 1, 3, TRUE, ip, ip_token);
					} else if (!gstrcmp(name, T("gSysIP4"))) {
						websGetIFInfo(OTHER_IF_TYPE, IP_INFO, 1, 4, TRUE, ip, ip_token);
					}
					if (!gstrncmp(name, "gSysIP", 6)) {
		                         	ifx_httpdWrite(wp, T("%s"), ip_token);
		                                continue;
        		                }	
				
					sprintf(mask, "%s",inet_ntoa((ip_array_type + i)->ip_mask.mask));
        	                       	if (!gstrcmp(name, T("gSysMASK"))) {
                	                	ifx_httpdWrite(wp, T("%s"), inet_ntoa((ip_array_type + i)->ip_mask.mask));
	        	                } else if (!gstrcmp(name, T("gSysMASK1"))) {
        	        	        	websGetIFInfo(OTHER_IF_TYPE, MASK_INFO,
                	        	                              1, 1, TRUE, mask,
                        	        	                      ip_token);
	                        	} else if (!gstrcmp(name, T("gSysMASK2"))) {
        	                                websGetIFInfo(OTHER_IF_TYPE, MASK_INFO,
                	                       	              1, 2, TRUE, mask,
                        	                       	      ip_token);
	                                } else if (!gstrcmp(name, T("gSysMASK3"))) {
        	                               	websGetIFInfo(OTHER_IF_TYPE, MASK_INFO,
                	                                	      1, 3, TRUE, mask,
	                	                                      ip_token);
        	                	} else if (!gstrcmp(name, T("gSysMASK4"))) {
                	                	        websGetIFInfo(OTHER_IF_TYPE, MASK_INFO,
	                        	                              1, 4, TRUE, mask,
        	                        	                      ip_token);
        		                }
	
                		        if (!gstrncmp(name, "gSysMASK", 8)) {
                        		                ifx_httpdWrite(wp, T("%s"), ip_token);
                                		        continue;
	                                }
				}
				
			IFX_MEM_FREE(ip_array_type)
	}
	return 0;
}

#ifdef CONFIG_FEATURE_DHCP_SERVER	//506271:tc.chen
int ifx_get_lan_dhcps_LeaseTime(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_FILELINE_LEN];
	char_t command[MAX_FILELINE_LEN];
	int i, nSelIdx, nLeaseTime = 0;

	sValue[0] = '\0';
	command[0] = '\0';

	nSelIdx = sizeof(web_Enum_LeaseTimeList) / sizeof(CGI_ENUMSEL_S);

	gsprintf(command,
		 T("grep '^option lease' " FILE_UDHCPD_CONF "|cut -f3 -d' '"));
	if (ifx_GetCfgData((char_t *) command, NULL, "1", sValue) == 1) {
		nLeaseTime = gatoi(sValue);

		if (nLeaseTime <= 7200 && nLeaseTime > 0) {
			nSelIdx = nLeaseTime / 3600;	//For one hour
		} else if (nLeaseTime <= 172800 && nLeaseTime > 7200) {
			nSelIdx = 3 + (nLeaseTime / 86400);	//For one day
		} else if (nLeaseTime <= 1209600 && nLeaseTime > 172800) {
			nSelIdx = 5 + (nLeaseTime / 604800);	//For one week;
		} else if (nLeaseTime > 1209600) {
			nSelIdx = -1;
		}
	} else {
		ifx_httpdWrite(wp, T(""));
	}
	for (i = 0; i < sizeof(web_Enum_LeaseTimeList) / sizeof(CGI_ENUMSEL_S);
	     i++) {
		// Get Selected option index from udhcpd.conf
		if (i == nSelIdx) {
			gstrcpy(sValue, " SELECTED");
		} else {
			gstrcpy(sValue, "");
		}

		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t\t<option name=\"LeaseTime%d\" VALUE=\"%d\"%s> %s </option>\n"),
			       i, i, sValue, web_Enum_LeaseTimeList[i].str);
	}
	return 0;
}

int32 ifx_get_lease_index(int32 nLeaseTime)
{
	int32 nSelIdx = -1;
	if (nLeaseTime <= 7200 && nLeaseTime > 0) {
		nSelIdx = nLeaseTime / 3600;	//For one hour
	} else if (nLeaseTime <= 172800 && nLeaseTime > 7200) {
		nSelIdx = 3 + (nLeaseTime / 86400);	//For one day
	} else if (nLeaseTime <= 1209600 && nLeaseTime > 172800) {
		nSelIdx = 5 + (nLeaseTime / 604800);	//For one week;
	} else if (nLeaseTime > 1209600) {
		nSelIdx = -1;
	}
	return nSelIdx;

}

void ifx_get_dhcp_conditional_operation(int eid, httpd_t wp, int argc,
					char_t ** argv)
{
	ifx_httpdWrite(wp, T("%s"), dhcpCondServerAction);
}

void ifx_get_dhcp_conditional_server_info(int eid, httpd_t wp, int argc,
					  char_t ** argv)
{

	IFX_DHCP_COND_SERV_POOL *pp_dhcp_info = NULL;
	int32 num_entries;
	int32 i;
	int32 nSelIdx;
	int32 order;
	char8 DhcpMode[15];

	if (strcmp(dhcpCondServerAction, "Modify_Config") == 0) {

		order = atoi(dhcpCondServerOrder);
		if (order != 0) {
			if (ifx_get_all_dhcp_conditional_entries
			    (&num_entries, &pp_dhcp_info,
			     IFX_F_GET_ANY) == IFX_SUCCESS) {
				if (num_entries > 0) {
					for (i = 0; i < num_entries; i++) {
						if ((pp_dhcp_info +
						     i)->iid.cpeId.Id ==
						    order) {
							/* Found requsted entry */
							ifx_httpdWrite(wp,
								       T
								       ("\"%d\""),
								       (pp_dhcp_info
									+
									i)->
								       PoolOrder);
							ifx_httpdWrite(wp,
								       T
								       (",\"%s\""),
								       (pp_dhcp_info
									+
									i)->
								       VendorClassID);
							ifx_httpdWrite(wp,
								       T
								       (",\"%s\""),
								       (pp_dhcp_info
									+
									i)->
								       ClientID);
							ifx_httpdWrite(wp,
								       T
								       (",\"%s\""),
								       (pp_dhcp_info
									+
									i)->
								       UserClassID);
							ifx_httpdWrite(wp,
								       T
								       (",\"%s\""),
								       (pp_dhcp_info
									+
									i)->
								       Chaddr);
							ifx_httpdWrite(wp,
								       T
								       (",\"%s\""),
								       (pp_dhcp_info
									+
									i)->
								       ChaddrMask);
							ifx_httpdWrite(wp,
								       T
								       (",\"%d\""),
								       (pp_dhcp_info
									+
									i)->
								       LocallyServed);
							ifx_httpdWrite(wp,
								       T
								       (",\"%d\""),
								       (pp_dhcp_info
									+
									i)->
								       Enable);
							ifx_httpdWrite(wp,
								       T
								       (",\"%s\""),
								       (pp_dhcp_info
									+
									i)->
								       MinAddress);
							ifx_httpdWrite(wp,
								       T
								       (",\"%s\""),
								       (pp_dhcp_info
									+
									i)->
								       MaxAddress);
							ifx_httpdWrite(wp,
								       T
								       (",\"%s\""),
								       (pp_dhcp_info
									+
									i)->
								       SubnetMask);
							ifx_httpdWrite(wp,
								       T
								       (",\"%s\""),
								       (pp_dhcp_info
									+
									i)->
								       DNSServers);
							ifx_httpdWrite(wp,
								       T
								       (",\"%s\""),
								       (pp_dhcp_info
									+
									i)->
								       IPRouters);
							nSelIdx =
							    ifx_get_lease_index((pp_dhcp_info + i)->DHCPLeaseTime);
							ifx_httpdWrite(wp,
								       T
								       (",\"%d\""),
								       nSelIdx);
							ifx_httpdWrite(wp,
								       T
								       (",\"%s\""),
								       (pp_dhcp_info
									+
									i)->
								       DHCPServerIPAddress);

							break;
						}
					}
				}
			}
		}

	}

	else if (strcmp(dhcpCondServerAction, "View_Config") == 0) {
		order = atoi(dhcpCondServerOrder);
		if (order != 0) {
			if (ifx_get_all_dhcp_conditional_entries
			    (&num_entries, &pp_dhcp_info,
			     IFX_F_GET_ANY) == IFX_SUCCESS) {
				if (num_entries > 0) {
					for (i = 0; i < num_entries; i++) {
						if (pp_dhcp_info->iid.cpeId.
						    Id == order) {
							/* Found requsted entry */
							ifx_httpdWrite(wp,
								       T
								       ("\n<div align=\"center\"><table class=\"tableinfo\">"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<tr>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>Pool Order</td>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>%u"),
								       pp_dhcp_info->
								       PoolOrder);
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>\n<tr>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>VendorClassID</td>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>%s"),
								       pp_dhcp_info->
								       VendorClassID);
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>\n<tr>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>ClientID</td>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>%s"),
								       pp_dhcp_info->
								       ClientID);
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>\n<tr>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>UserClassID</td>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>%s"),
								       pp_dhcp_info->
								       UserClassID);
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>\n<tr>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>MAC Address</td>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>%s"),
								       pp_dhcp_info->
								       Chaddr);
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>\n<tr>\n<td>MAC Address Mask</td>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>%s"),
								       pp_dhcp_info->
								       ChaddrMask);
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>"));

							ifx_httpdWrite(wp,
								       T
								       ("\n<tr>\n<td>DHCP Mode</td>"));
							if (pp_dhcp_info->
							    LocallyServed == 1)
								strcpy(DhcpMode,
								       "Server");
							else if (pp_dhcp_info->
								 LocallyServed
								 == 0)
								strcpy(DhcpMode,
								       "Relay Agent");

							ifx_httpdWrite(wp,
								       T
								       ("\n<td>%s"),
								       DhcpMode);
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>\n<tr>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>Enable</td>"));

							if (pp_dhcp_info->
							    Enable == 1)
								strcpy(DhcpMode,
								       "Yes");
							else if (pp_dhcp_info->
								 Enable == 0)
								strcpy(DhcpMode,
								       "No");

							ifx_httpdWrite(wp,
								       T
								       ("\n<td>%s"),
								       DhcpMode);
							ifx_httpdWrite(wp, T("\n</td>\n</tr>\n"));	// </table>\n</tr>\n<tr>\n<br>\n</tr>"));

							if (pp_dhcp_info->
							    LocallyServed ==
							    1) {
//                            ifx_httpdWrite(wp, T("\n<tr>\n<table border=0 cellspacing=1 cellpadding=5 width=\"50%\">"));
								ifx_httpdWrite
								    (wp,
								     T
								     ("\n<tr>\n<td>Start Address</td>"));
								ifx_httpdWrite
								    (wp,
								     T
								     ("\n<td>%s"),
								     pp_dhcp_info->
								     MinAddress);
								ifx_httpdWrite
								    (wp,
								     T
								     ("\n</td>\n</tr>\n<tr>"));
								ifx_httpdWrite
								    (wp,
								     T
								     ("\n<td>End Address</td>"));
								ifx_httpdWrite
								    (wp,
								     T
								     ("\n<td>%s"),
								     pp_dhcp_info->
								     MaxAddress);
								ifx_httpdWrite
								    (wp,
								     T
								     ("\n</td>\n</tr>\n<tr>"));
								ifx_httpdWrite
								    (wp,
								     T
								     ("\n<td>Subnet Mask</td>"));
								ifx_httpdWrite
								    (wp,
								     T
								     ("\n<td>%s"),
								     pp_dhcp_info->
								     SubnetMask);
								ifx_httpdWrite
								    (wp,
								     T
								     ("\n</td>\n</tr>\n<tr>"));
								ifx_httpdWrite
								    (wp,
								     T
								     ("\n<td>DNS Server IP</td>"));
								ifx_httpdWrite
								    (wp,
								     T
								     ("\n<td>%s"),
								     pp_dhcp_info->
								     DNSServers);
								ifx_httpdWrite
								    (wp,
								     T
								     ("\n</td>\n</tr>"));
								ifx_httpdWrite
								    (wp,
								     T
								     ("\n<tr>\n<td>Gateway IP</td>"));
								ifx_httpdWrite
								    (wp,
								     T
								     ("\n<td>%s"),
								     pp_dhcp_info->
								     IPRouters);
								ifx_httpdWrite
								    (wp,
								     T
								     ("\n</td>\n</tr>"));

								ifx_httpdWrite
								    (wp,
								     T
								     ("\n<tr>\n<td>Lease Time</td>"));
								nSelIdx =
								    ifx_get_lease_index
								    (pp_dhcp_info->
								     DHCPLeaseTime);
								if (nSelIdx !=
								    -1) {
									ifx_httpdWrite
									    (wp,
									     T
									     ("\n<td>%s"),
									     web_Enum_LeaseTimeList
									     [nSelIdx].
									     str);
								} else {
									ifx_httpdWrite
									    (wp,
									     T
									     ("\n<td> "));
								}
								ifx_httpdWrite(wp, T("\n</td>\n</tr>\n"));	// </table>\n</tr>"));
							} else
							    if (pp_dhcp_info->
								LocallyServed ==
								0) {
//                            ifx_httpdWrite(wp, T("\n<tr>\n<table border=0 cellspacing=1 cellpadding=5 width=\"50%\">"));
								ifx_httpdWrite
								    (wp,
								     T
								     ("\n<tr>\n<td>Relay IP Address</td>"));
								ifx_httpdWrite
								    (wp,
								     T
								     ("\n<td>%s"),
								     pp_dhcp_info->
								     DHCPServerIPAddress);
								ifx_httpdWrite(wp, T("\n</td>\n</tr>\n"));	// </table>\n</tr>"));
							}

						}
						pp_dhcp_info++;
					}
				}

			}
		}

	}
	IFX_MEM_FREE(pp_dhcp_info);
}

void ifx_set_dhcp_conditional_server(httpd_t wp, char_t * path, char_t * query)
{
	char_t *dhcpAction = ifx_httpdGetVar(wp, T("dhcpAction"), T(""));
	char_t *dhcpOrder = ifx_httpdGetVar(wp, T("dhcpOrder"), T(""));

	char_t Chaddr[MAX_MAC_ADDR_LEN] = { 0 };
	char_t ChaddrMask[MAX_MAC_ADDR_LEN] = { 0 };
	char_t MinAddress[MAX_IP_ADDR_LEN] = { 0 };
	char_t MaxAddress[MAX_IP_ADDR_LEN] = { 0 };
	char_t SubnetMask[MAX_IP_ADDR_LEN] = { 0 };
	char_t DNSServers[MAX_IP_ADDR_LEN] = { 0 };
	char_t Gateway[MAX_IP_ADDR_LEN] = { 0 };
	char_t RelayIP[MAX_IP_ADDR_LEN] = { 0 };

	char_t *pOrder = ifx_httpdGetVar(wp, T("DHCP_POOL_ORDER"), T(""));
	char_t *pVenClassId =
	    ifx_httpdGetVar(wp, T("DHCP_VENDOR_CLASS_ID"), T(""));

	char_t *pClientId = ifx_httpdGetVar(wp, T("DHCP_CLIENT_ID"), T(""));
	char_t *pUserClassId =
	    ifx_httpdGetVar(wp, T("DHCP_USER_CLASS_ID"), T(""));
	char_t *pMac1 = ifx_httpdGetVar(wp, T("DHCP_MAC_ADDR1"), T(""));
	char_t *pMac2 = ifx_httpdGetVar(wp, T("DHCP_MAC_ADDR2"), T(""));
	char_t *pMac3 = ifx_httpdGetVar(wp, T("DHCP_MAC_ADDR3"), T(""));
	char_t *pMac4 = ifx_httpdGetVar(wp, T("DHCP_MAC_ADDR4"), T(""));
	char_t *pMac5 = ifx_httpdGetVar(wp, T("DHCP_MAC_ADDR5"), T(""));
	char_t *pMac6 = ifx_httpdGetVar(wp, T("DHCP_MAC_ADDR6"), T(""));
	char_t *pMacMask1 =
	    ifx_httpdGetVar(wp, T("DHCP_MAC_ADDR_MASK1"), T(""));
	char_t *pMacMask2 =
	    ifx_httpdGetVar(wp, T("DHCP_MAC_ADDR_MASK2"), T(""));
	char_t *pMacMask3 =
	    ifx_httpdGetVar(wp, T("DHCP_MAC_ADDR_MASK3"), T(""));
	char_t *pMacMask4 =
	    ifx_httpdGetVar(wp, T("DHCP_MAC_ADDR_MASK4"), T(""));
	char_t *pMacMask5 =
	    ifx_httpdGetVar(wp, T("DHCP_MAC_ADDR_MASK5"), T(""));
	char_t *pMacMask6 =
	    ifx_httpdGetVar(wp, T("DHCP_MAC_ADDR_MASK6"), T(""));
	char_t *pMode = ifx_httpdGetVar(wp, T("DHCP_SERVER_MODE"), T(""));
	char_t *pMinAddr1 = ifx_httpdGetVar(wp, T("DHCP_MIN_ADDR1"), T(""));
	char_t *pMinAddr2 = ifx_httpdGetVar(wp, T("DHCP_MIN_ADDR2"), T(""));
	char_t *pMinAddr3 = ifx_httpdGetVar(wp, T("DHCP_MIN_ADDR3"), T(""));
	char_t *pMinAddr4 = ifx_httpdGetVar(wp, T("DHCP_MIN_ADDR4"), T(""));
	char_t *pMaxAddr1 = ifx_httpdGetVar(wp, T("DHCP_MAX_ADDR1"), T(""));
	char_t *pMaxAddr2 = ifx_httpdGetVar(wp, T("DHCP_MAX_ADDR2"), T(""));
	char_t *pMaxAddr3 = ifx_httpdGetVar(wp, T("DHCP_MAX_ADDR3"), T(""));
	char_t *pMaxAddr4 = ifx_httpdGetVar(wp, T("DHCP_MAX_ADDR4"), T(""));
	char_t *pNetmask1 = ifx_httpdGetVar(wp, T("DHCP_SUBNET_MASK1"), T(""));
	char_t *pNetmask2 = ifx_httpdGetVar(wp, T("DHCP_SUBNET_MASK2"), T(""));
	char_t *pNetmask3 = ifx_httpdGetVar(wp, T("DHCP_SUBNET_MASK3"), T(""));
	char_t *pNetmask4 = ifx_httpdGetVar(wp, T("DHCP_SUBNET_MASK4"), T(""));
	char_t *pDNS1 = ifx_httpdGetVar(wp, T("DHCP_DNS_ADDR1"), T(""));
	char_t *pDNS2 = ifx_httpdGetVar(wp, T("DHCP_DNS_ADDR2"), T(""));
	char_t *pDNS3 = ifx_httpdGetVar(wp, T("DHCP_DNS_ADDR3"), T(""));
	char_t *pDNS4 = ifx_httpdGetVar(wp, T("DHCP_DNS_ADDR4"), T(""));
	char_t *pGW1 = ifx_httpdGetVar(wp, T("DHCP_GW_ADDR1"), T(""));
	char_t *pGW2 = ifx_httpdGetVar(wp, T("DHCP_GW_ADDR2"), T(""));
	char_t *pGW3 = ifx_httpdGetVar(wp, T("DHCP_GW_ADDR3"), T(""));
	char_t *pGW4 = ifx_httpdGetVar(wp, T("DHCP_GW_ADDR4"), T(""));
	char_t *pLease = ifx_httpdGetVar(wp, T("DHCP_LEASE_TIME"), T(""));
	char_t *pRelayIP1 = ifx_httpdGetVar(wp, T("DHCP_RELAY_ADDR1"), T(""));
	char_t *pRelayIP2 = ifx_httpdGetVar(wp, T("DHCP_RELAY_ADDR2"), T(""));
	char_t *pRelayIP3 = ifx_httpdGetVar(wp, T("DHCP_RELAY_ADDR3"), T(""));
	char_t *pRelayIP4 = ifx_httpdGetVar(wp, T("DHCP_RELAY_ADDR4"), T(""));
	char_t *pEnable = "1";

	int32 instCount;
	int32 operation = IFX_OP_ADD, ret = IFX_SUCCESS;
	int32 nLeaseTime, i;
	uint32 flags = IFX_F_DEFAULT;
	IFX_DHCP_COND_SERV_POOL dhcpCondServ;

	memset(&dhcpCondServ, 0x00, sizeof(dhcpCondServ));

	if (pMac1[0] != '\0' && pMac2[0] != '\0' && pMac3[0] != '\0'
	    && pMac4[0] != '\0' && pMac5[0] != '\0' && pMac6[0] != '\0') {
		strcpy(Chaddr, pMac1);
		strcat(Chaddr, ":");
		strcat(Chaddr, pMac2);
		strcat(Chaddr, ":");
		strcat(Chaddr, pMac3);
		strcat(Chaddr, ":");
		strcat(Chaddr, pMac4);
		strcat(Chaddr, ":");
		strcat(Chaddr, pMac5);
		strcat(Chaddr, ":");
		strcat(Chaddr, pMac6);
	} else {
		Chaddr[0] = '\0';
	}

	if (pMacMask1[0] != '\0' && pMacMask2[0] != '\0' && pMacMask3[0] != '\0'
	    && pMacMask4[0] != '\0' && pMacMask5[0] != '\0'
	    && pMacMask6[0] != '\0') {
		strcpy(ChaddrMask, pMacMask1);
		strcat(ChaddrMask, ":");
		strcat(ChaddrMask, pMacMask2);
		strcat(ChaddrMask, ":");
		strcat(ChaddrMask, pMacMask3);
		strcat(ChaddrMask, ":");
		strcat(ChaddrMask, pMacMask4);
		strcat(ChaddrMask, ":");
		strcat(ChaddrMask, pMacMask5);
		strcat(ChaddrMask, ":");
		strcat(ChaddrMask, pMacMask6);
	} else {
		ChaddrMask[0] = '\0';
	}

	if (pMinAddr1[0] != '\0' && pMinAddr2[0] != '\0' && pMinAddr3[0] != '\0'
	    && pMinAddr4[0] != '\0') {
		strcpy(MinAddress, pMinAddr1);
		strcat(MinAddress, ".");
		strcat(MinAddress, pMinAddr2);
		strcat(MinAddress, ".");
		strcat(MinAddress, pMinAddr3);
		strcat(MinAddress, ".");
		strcat(MinAddress, pMinAddr4);
	} else {
		MinAddress[0] = '\0';
	}

	if (pMaxAddr1[0] != '\0' && pMaxAddr2[0] != '\0' && pMaxAddr3[0] != '\0'
	    && pMaxAddr4[0] != '\0') {
		strcpy(MaxAddress, pMaxAddr1);
		strcat(MaxAddress, ".");
		strcat(MaxAddress, pMaxAddr2);
		strcat(MaxAddress, ".");
		strcat(MaxAddress, pMaxAddr3);
		strcat(MaxAddress, ".");
		strcat(MaxAddress, pMaxAddr4);
	} else {
		MaxAddress[0] = '\0';
	}

	if (pNetmask1[0] != '\0' && pNetmask2[0] != '\0' && pNetmask3[0] != '\0'
	    && pNetmask4[0] != '\0') {
		strcpy(SubnetMask, pNetmask1);
		strcat(SubnetMask, ".");
		strcat(SubnetMask, pNetmask2);
		strcat(SubnetMask, ".");
		strcat(SubnetMask, pNetmask3);
		strcat(SubnetMask, ".");
		strcat(SubnetMask, pNetmask4);
	} else {
		SubnetMask[0] = '\0';
	}

	if (pDNS1[0] != '\0' && pDNS2[0] != '\0' && pDNS3[0] != '\0'
	    && pDNS4[0] != '\0') {
		strcpy(DNSServers, pDNS1);
		strcat(DNSServers, ".");
		strcat(DNSServers, pDNS2);
		strcat(DNSServers, ".");
		strcat(DNSServers, pDNS3);
		strcat(DNSServers, ".");
		strcat(DNSServers, pDNS4);
	} else {
		DNSServers[0] = '\0';
	}

	if (pGW1[0] != '\0' && pGW2[0] != '\0' && pGW3[0] != '\0'
	    && pGW4[0] != '\0') {
		strcpy(Gateway, pGW1);
		strcat(Gateway, ".");
		strcat(Gateway, pGW2);
		strcat(Gateway, ".");
		strcat(Gateway, pGW3);
		strcat(Gateway, ".");
		strcat(Gateway, pGW4);
	} else {
		Gateway[0] = '\0';
	}

	if (pRelayIP1[0] != '\0' && pRelayIP2[0] != '\0' && pRelayIP3[0] != '\0'
	    && pRelayIP4[0] != '\0') {
		strcpy(RelayIP, pRelayIP1);
		strcat(RelayIP, ".");
		strcat(RelayIP, pRelayIP2);
		strcat(RelayIP, ".");
		strcat(RelayIP, pRelayIP3);
		strcat(RelayIP, ".");
		strcat(RelayIP, pRelayIP4);
	} else {
		RelayIP[0] = '\0';
	}

	if (!gstrcmp(dhcpAction, "Add_Config")) {
		if (ifx_get_sec_instance_count
		    (TAG_LAN_DHCP_COND_INFO,
		     (uint32 *) & instCount) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       T
				       ("Failed to read DHCP conditional server pool instance count"));
			return;
		}
		if (instCount == 4) {
			COPY_TO_STATUS("%s",
				       "<span class=\"textTitle\">DHCP conditional server pool configuration failed.</span><br><p>Number of configured DHCP conditional server pool has reached maximum limit(4).<br>Please delete existing entry before configuring new one.</p>");
			ifx_httpdRedirect(wp, "err_page.html");
			if(ret!= IFX_SUCCESS){
			}
			return;
		}
		strcpy(dhcpCondServerAction, dhcpAction);
		strcpy(dhcpCondServerOrder, dhcpOrder);
		ifx_httpdRedirect(wp, "lan_dhcp_cond_serv_config_add.asp");
		return;
	}

	else if (!gstrcmp(dhcpAction, "Modify_Config")) {
		strcpy(dhcpCondServerAction, dhcpAction);
		strcpy(dhcpCondServerOrder, dhcpOrder);
		ifx_httpdRedirect(wp, "lan_dhcp_cond_serv_config_add.asp");
		return;
	}
	/*
	   else if (!gstrcmp(dhcpAction, "Delete_Config")) {
	   strcpy(dhcpCondServerAction, dhcpAction);
	   strcpy(dhcpCondServerOrder, dhcpOrder);
	   return;
	   }
	 */
	else if (!gstrcmp(dhcpAction, "View_Config")) {
		strcpy(dhcpCondServerAction, dhcpAction);
		strcpy(dhcpCondServerOrder, dhcpOrder);
		ifx_httpdRedirect(wp, "lan_dhcp_cond_serv_show.asp");
		return;
	} else if (!gstrcmp(dhcpAction, "Add")) {
		operation = IFX_OP_ADD;
		flags = IFX_F_DEFAULT;
	} else if (!gstrcmp(dhcpAction, "Delete")) {
		operation = IFX_OP_DEL;
		flags = IFX_F_DELETE;
	} else if (!gstrcmp(dhcpAction, "Modify")) {
		operation = IFX_OP_MOD;
		flags = IFX_F_MODIFY;
	}

	if (operation == IFX_OP_ADD || operation == IFX_OP_MOD) {

		if (operation == IFX_OP_MOD) {
			dhcpCondServ.iid.cpeId.Id = atoi(dhcpCondServerOrder);
			if (ifx_get_dhcp_conditional_entry
			    (&dhcpCondServ, IFX_F_DEFAULT) != IFX_SUCCESS) {
				ifx_httpdError(wp, 400, T("%s"),
					       "Failed to get previous DHCP conditional server configuration.");
				return;
			}

			flags = IFX_F_MODIFY;
		}

		//dhcpCondServ.qId = atoi(pQId);
		if (!gstrcmp(pEnable, "1")) {
			dhcpCondServ.Enable = IFX_ENABLED;
		} else {
			dhcpCondServ.Enable = IFX_DISABLED;
			flags |= (IFX_F_DONT_ACTIVATE | IFX_F_DONT_VALIDATE);
		}

		if (pOrder != NULL && strlen(pOrder)) {
			dhcpCondServ.PoolOrder = atoi(pOrder);
		}
		//  if(pVenClassId != NULL && strlen(pVenClassId)) {
		strcpy(dhcpCondServ.VendorClassID, pVenClassId);
		//  }
		//  if(pClientId != NULL && strlen(pClientId)) {
		strcpy(dhcpCondServ.ClientID, pClientId);
		//  }
		//  if(pUserClassId != NULL && strlen(pUserClassId)) {
		strcpy(dhcpCondServ.UserClassID, pUserClassId);
		//  }
		if (Chaddr != NULL && strlen(Chaddr)) {
			strcpy(dhcpCondServ.Chaddr, Chaddr);

			if (ChaddrMask != NULL && strlen(ChaddrMask)) {
				strcpy(dhcpCondServ.ChaddrMask, ChaddrMask);
			}
		}

		if (strcmp(pMode, "server") == 0) {
			dhcpCondServ.LocallyServed = 1;
		} else {
			dhcpCondServ.LocallyServed = 0;
		}

		if (dhcpCondServ.LocallyServed == 1) {	/* Server */
			strcpy(dhcpCondServ.MinAddress, MinAddress);
			strcpy(dhcpCondServ.MaxAddress, MaxAddress);
			strcpy(dhcpCondServ.SubnetMask, SubnetMask);
			strcpy(dhcpCondServ.DNSServers, DNSServers);
			/*sprintf(dhcpCondServ.DomainName, "%s", pDName); */
			strcpy(dhcpCondServ.IPRouters, Gateway);

			nLeaseTime = atoi(pLease);
			for (i = 0;
			     i < sizeof(nSelLeaseTime) / sizeof(ST_LEASE_TIME);
			     i++) {
				if (nLeaseTime == i) {
					nLeaseTime = nSelLeaseTime[i].nValue;
					break;
				}
			}
			dhcpCondServ.DHCPLeaseTime = nLeaseTime;
		} else {
			strcpy(dhcpCondServ.DHCPServerIPAddress, RelayIP);
		}

		sprintf(dhcpCondServ.iid.cpeId.secName, "%s",
			TAG_LAN_DHCP_COND_INFO);
		sprintf(dhcpCondServ.iid.pcpeId.secName, "%s", TAG_LAN_DHCPS);
		dhcpCondServ.iid.config_owner = IFX_WEB;
		dhcpCondServ.iid.pcpeId.Id = 1;

	} else if (operation == IFX_OP_DEL) {
		dhcpCondServ.iid.cpeId.Id = atoi(dhcpOrder);
		if (ifx_get_dhcp_conditional_entry(&dhcpCondServ, IFX_F_GET_ANY)
		    != IFX_SUCCESS) {
			ifx_httpdError(wp, 400, T("%s"),
				       "Failed to get DHCP conditional server configuration.");
			return;
		}
	}

	if (ifx_set_dhcp_conditional_entry(operation, &dhcpCondServ, flags) !=
	    IFX_SUCCESS) {
		COPY_TO_STATUS("%s",
			       "<span class=\"textTitle\">DHCP conditional server Configuration failed</span>");
		ifx_httpdRedirect(wp, "err_page.html");
		return;
	}

      IFX_Handler:
	ifx_httpdRedirect(wp, T("lan_dhcp_cond_serv_config.asp"));
	return;
}

void ifx_get_dhcp_conditional_config(int eid, httpd_t wp, int argc,char_t ** argv)
{
	IFX_DHCP_COND_SERV_POOL *pp_dhcp_info;
	int32 num_entries;
	int32 i;

	if (ifx_get_all_dhcp_conditional_entries(&num_entries, &pp_dhcp_info, IFX_F_GET_ANY) == IFX_SUCCESS) {
		if (num_entries > 0) {
			ifx_httpdWrite(wp,T("\n<table class=\"tableInfo\" cellspacing=\"1\" cellpadding=\"6\" summary=\"\">"));
			ifx_httpdWrite(wp, T("\n<tr>"));
			ifx_httpdWrite(wp,T("\n<th class=\"curveLeft\">Pool Order</th>"));
			ifx_httpdWrite(wp, T("\n<th>Vendor ClassID</th>"));
			ifx_httpdWrite(wp, T("\n<th>ClientID</th>"));
			ifx_httpdWrite(wp, T("\n<th>User ClassID</th>"));
			ifx_httpdWrite(wp, T("\n<th>MAC Address</th>"));
			ifx_httpdWrite(wp, T("\n<th>DHCP Mode</th>"));
			ifx_httpdWrite(wp, T("\n<th>Enable</th>"));
			ifx_httpdWrite(wp,T("\n<th class=\"colInput curveRight\"></th>"));
			ifx_httpdWrite(wp, T("\n</tr>"));
			for (i = 0; i < num_entries; i++) {
				ifx_httpdWrite(wp,T("\n<input type=\"hidden\" name=\"cpeId%d\" value=\"%d\">"),i,(pp_dhcp_info + i)->iid.cpeId.Id);
				ifx_httpdWrite(wp, T("\n<tr>"));
				ifx_httpdWrite(wp,T("\n<td id=\"dhcp_con_porder%d\">%u</td>"),i,(pp_dhcp_info + i)->PoolOrder);
				ifx_httpdWrite(wp,T("\n<td id=\"dhcp_con_vcid%d\">%s</td>"),i,(pp_dhcp_info + i)->VendorClassID);
				ifx_httpdWrite(wp,T("\n<td id=\"dhcp_con_cid%d\">%s</td>"),i,(pp_dhcp_info + i)->ClientID);
				ifx_httpdWrite(wp,T("\n<td id=\"dhcp_con_ucid%d\">%s</td>"),i,(pp_dhcp_info + i)->UserClassID);
				ifx_httpdWrite(wp,T("\n<td id=\"dhcp_con_madd%d\">%s</td>"),i,(pp_dhcp_info + i)->Chaddr);
				if ((pp_dhcp_info + i)->LocallyServed == 1) {
					ifx_httpdWrite(wp,T("\n<td id=\"dhcp_con_mode%d\">Server</td>"));
				} else if ((pp_dhcp_info + i)->LocallyServed == 0) {
					ifx_httpdWrite(wp,T("\n<td id=\"dhcp_con_mode%d\">Relay Agent</td>"),i);
				}
				if ((pp_dhcp_info + i)->Enable == 1) {
					ifx_httpdWrite(wp,T("\n<td id=\"dhcp_con_en%d\">Yes</td>"),i);
				} else {
					ifx_httpdWrite(wp,T("\n<td id=\"dhcp_con_no%d\">No</td>"),i);
				}
				/* Create View/Delete button */
				ifx_httpdWrite(wp, T("\n<td>"));
				ifx_httpdWrite(wp,T("\n<a class=\"button\" href=\"#\" onclick=\"deleteDhcpCond(%d);\" value=\"Delete\">Delete</a>"),(pp_dhcp_info + i)->iid.cpeId.Id);
				ifx_httpdWrite(wp, T("&nbsp;"));
				ifx_httpdWrite(wp,T("\n<a class=\"button\" href=\"#\" onclick=\"modifyDhcpCond(%d);\" value=\"Modify\">Modify</a>"),(pp_dhcp_info + i)->iid.cpeId.Id);
				ifx_httpdWrite(wp, T("\n<br>"));
				ifx_httpdWrite(wp,T("\n<a class=\"button\" href=\"#\" onclick=\"viewDhcpCond(%d);\" value=\"View\">View</a>"),(pp_dhcp_info + i)->iid.cpeId.Id);
				ifx_httpdWrite(wp, T("\n</td>"));
				ifx_httpdWrite(wp, T("\n</tr>"));
			}
			ifx_httpdWrite(wp, T("\n</table>"));
		}
	IFX_MEM_FREE(pp_dhcp_info);
	}
	return;
}

//////////////////////////////////////////////////////////////////////////////////
// lan_dhcp_clients.asp
//
int ifx_get_lan_dhcp_clients(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int ret = IFX_SUCCESS, num, i;
	uint32 flags = IFX_F_DEFAULT;
	char_t *str;
//	char_t sValue[MAX_FILELINE_LEN], sCommand[MAX_FILELINE_LEN];
	DHCP_LEASE_INFO *lease_info = NULL;

	system("killall -SIGUSR1 udhcpd");
//	sValue[0] = '\0';
//	sCommand[0] = '\0';
	ret = ifx_get_lan_dhcp_leases(&num, &lease_info, flags);
//vipul start
	if (ret == 0 && num != 0 && num < 32767) {
		for (i = 0; i < num; i++) {
			ifx_httpdWrite(wp,
				       T
				       (" <tr><td id=\"dhcp_clt_hname%d\">%s</td>\n"),
				       i, (lease_info + i)->host_name);
			ifx_httpdWrite(wp,
				       T
				       (" <td id=\"dhcp_clt_mac%d\">%s</td>\n"),
				       i, (lease_info + i)->cli_id);
			str = inet_ntoa((lease_info + i)->ip);
			ifx_httpdWrite(wp,
				       T(" <td id=\"dhcp_clt_ip%d\">%s</td>\n"),
				       i, str);
			ifx_httpdWrite(wp,
				       T
				       (" <td id=\"dhcp_clt_lease%d\">%d</td></tr>\n"),
				       i, (lease_info + i)->lease_time_left);
//vipul end
		}
	} else if (num != 0) {
		ifx_httpdError(wp, 500, "Error");
	}

	IFX_MEM_FREE(lease_info)
	    return 0;
}

int ifx_get_lan_dhcps(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name, *ip;
	uint32 flags = IFX_F_DEFAULT;
	int32 ret = IFX_SUCCESS, nSelIdx = 0;
	char ipnew[MAX_IP_ADDR_LEN], ip_token[MAX_IP_ADDR_LEN];
#ifdef CONFIG_FEATURE_IFX_WIRELESS_ATH
	int32 i = 0;
	uint32 outFlag = IFX_F_DEFAULT;
#endif
	DHCP_SERVER_INFO dhcp;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	dhcp.iid.config_owner = IFX_WEB;

	ret = ifx_get_lan_dhcp_server_config(&dhcp, flags);
	if (ret != IFX_FAILURE) {
		if (!gstrcmp(name, T("Netmask"))) {
			ip = inet_ntoa(dhcp.netmask);
			ifx_httpdWrite(wp, T("%s"), ip);
		}
#ifdef CONFIG_FEATURE_IFX_WIRELESS_ATH
		else if (!gstrcmp(name, T("wlan_enable"))) {
			if (ifx_GetCfgData1
			    (FILE_RC_CONF, TAG_WLAN_STATUS, "wlan_enable",
			     IFX_F_DEFAULT, &outFlag, sValue) == IFX_SUCCESS) {
				nSelIdx = gatoi(sValue);

				for (i = 0;
				     i <
				     sizeof(WirelessEnable_List) /
				     sizeof(CGI_ENUMSEL_S); i++) {
					if (i == nSelIdx) {
						ifx_httpdWrite(wp,
							       T
							       ("document.write(\"<option value=\"%d\" SELECTED>%s</option>\");\n"),
							       i,
							       WirelessEnable_List
							       [i].str);
					} else {
						ifx_httpdWrite(wp,
							       T
							       ("document.write(\"<option value=\"%d\">%s</option>\");\n"),
							       i,
							       WirelessEnable_List
							       [i].str);
					}
				}
			}
		}
#endif
		else {
			if (!gstrcmp(name, T("lan_dhcp_mode"))) {
				/* Here we need to call the get the dhcp Server mode */
				nSelIdx =
				    ifx_get_dhcp_server_mode(IFX_F_DEFAULT);
				ifx_httpdWrite(wp,
					       T
					       ("<option value=\"disable\" %s>Disable</option>"),
					       nSelIdx == 0 ? "selected" : "");
#ifdef CONFIG_FEATURE_DHCP_SERVER
				ifx_httpdWrite(wp,
					       T
					       ("<option value=\"server\" %s>Server</option>"),
					       nSelIdx == 1 ? "selected" : "");
#endif
				ifx_httpdWrite(wp,
					       T
					       ("<option value=\"relay\" %s>Relay Agent</option>"),
					       nSelIdx == 2 ? "selected" : "");
			}

			else {
				if (!gstrcmp(name, T("DN"))) {
					if (!gstrcmp
					    (dhcp.dhcp_domain_name, "0")) {
						ifx_httpdWrite(wp, T(""));
					} else {
						ifx_httpdWrite(wp, T("%s"),
							       dhcp.
							       dhcp_domain_name);
					}
				} else {
					ipnew[0] = '\0';
					ip_token[0] = '\0';
					sprintf(ipnew, "%s",
						inet_ntoa(dhcp.start_ip));

					if (!gstrcmp(name, T("DhcpsStartIP"))) {
						ifx_httpdWrite(wp, T("%s"),
							       inet_ntoa(dhcp.
									 start_ip));
					} else
					    if (!gstrcmp
						(name, T("DhcpsStartIP0"))) {
						websGetIFInfo(OTHER_IF_TYPE,
							      IP_INFO, 1, 3,
							      FALSE, ipnew,
							      ip_token);
					} else
					    if (!gstrcmp
						(name, T("DhcpsStartIP1"))) {
						websGetIFInfo(OTHER_IF_TYPE,
							      IP_INFO, 1, 1,
							      TRUE, ipnew,
							      ip_token);
					} else
					    if (!gstrcmp
						(name, T("DhcpsStartIP2"))) {
						websGetIFInfo(OTHER_IF_TYPE,
							      IP_INFO, 1, 2,
							      TRUE, ipnew,
							      ip_token);
					} else
					    if (!gstrcmp
						(name, T("DhcpsStartIP3"))) {
						websGetIFInfo(OTHER_IF_TYPE,
							      IP_INFO, 1, 3,
							      TRUE, ipnew,
							      ip_token);
					} else
					    if (!gstrcmp
						(name, T("DhcpsStartIP4"))) {
						websGetIFInfo(OTHER_IF_TYPE,
							      IP_INFO, 1, 4,
							      TRUE, ipnew,
							      ip_token);
					}

					ipnew[0] = '\0';
					sprintf(ipnew, "%s",
						inet_ntoa(dhcp.end_ip));

					if (!gstrcmp(name, T("DhcpsEndIP"))) {
						ifx_httpdWrite(wp, T("%s"),
							       inet_ntoa(dhcp.
									 end_ip));
					} else
					    if (!gstrcmp
						(name, T("DhcpsEndIP0"))) {
						websGetIFInfo(OTHER_IF_TYPE,
							      IP_INFO, 1, 3,
							      FALSE, ipnew,
							      ip_token);
					} else
					    if (!gstrcmp
						(name, T("DhcpsEndIP1"))) {
						websGetIFInfo(OTHER_IF_TYPE,
							      IP_INFO, 1, 1,
							      TRUE, ipnew,
							      ip_token);
					} else
					    if (!gstrcmp
						(name, T("DhcpsEndIP2"))) {
						websGetIFInfo(OTHER_IF_TYPE,
							      IP_INFO, 1, 2,
							      TRUE, ipnew,
							      ip_token);
					} else
					    if (!gstrcmp
						(name, T("DhcpsEndIP3"))) {
						websGetIFInfo(OTHER_IF_TYPE,
							      IP_INFO, 1, 3,
							      TRUE, ipnew,
							      ip_token);
					} else
					    if (!gstrcmp
						(name, T("DhcpsEndIP4"))) {
						websGetIFInfo(OTHER_IF_TYPE,
							      IP_INFO, 1, 4,
							      TRUE, ipnew,
							      ip_token);
					}

					ifx_httpdWrite(wp, T("%s"), ip_token);
				}
			}
		}
	}

	return IFX_SUCCESS;
}

int ifx_get_lan_dhcpr(int eid, httpd_t wp, int argc, char_t ** argv)
{
	DHCP_RELAY_INFO relay;
	char_t *name, *ip;
	uint32 flags = IFX_F_DEFAULT, count = 0;
	int ret = IFX_SUCCESS, i;
	char8 *wan_conn_names = NULL, conn_name[MAX_CONN_NAME_LEN];

	memset(conn_name, 0x00, sizeof(conn_name));

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	ret = ifx_get_dhcp_relay_config(&relay, flags);
	if (ret == IFX_FAILURE) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In function [%s] : Error--> Failed to get relay info from rc.conf !! \n\n",
		     __FUNCTION__);
#endif
		return IFX_FAILURE;
	}

	if (!gstrcmp(name, T("dhcp_relay_if"))) {
		/* TBD : for all ifx_get_wan_connName_from_ifname instances below */
		if (ifx_get_wan_connName_from_ifname
		    (conn_name, relay.dhcpr_servers->server_if,
		     WAN_TYPE_IP) != IFX_SUCCESS) {
			ifx_httpdError(wp, 500,
				       "Failed to get the relay interface");
			return -1;
		}
		if ((ret =
		     ifx_get_all_wan_conn_names(&wan_conn_names,
						(int *)&count)) !=
		    IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("\n\n In Function [%s] : Error--> Failed to get wan connection names !!\n\n",
			     __FUNCTION__);
#endif
			ifx_httpdError(wp, 500,
				       "Failed to get the relay interface");
			goto IFX_Handler;
		}
		IFX_GET_WAN_CONN_NAME_LIST(i, count, conn_name, wan_conn_names)
	} else {
		if (!gstrcmp(name, T("dhcp_relay_server"))) {
			ip = inet_ntoa(relay.dhcpr_servers->dhcp_relay_server);
			ifx_httpdWrite(wp, T("%s"), ip);
		}
	}

      IFX_Handler:
	IFX_MEM_FREE(wan_conn_names)
	    IFX_MEM_FREE(relay.dhcpr_servers)
	    return IFX_SUCCESS;
}
#endif				//CONFIG_FEATURE_DHCP_SERVER

int ifx_get_lan_mac(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
	char_t mac[19], sValue[4];
	int bytenum = -1;
	FILE *fp = NULL;
	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	bytenum = name[strlen(name) - 1] - '0';
	system("upgrade mac_get 0 > /tmp/tmp_mac");
	fp = fopen("/tmp/tmp_mac", "r");
	memset(mac, 0x00, sizeof(mac));
	if (fp) {
		fread(mac, 19, 1, fp);
		fclose(fp);
	}
	//fclose(fp);
	system("rm -rf /tmp/tmp_mac");

	memset(sValue, 0x00, sizeof(sValue));
	sValue[0] = mac[3 * (bytenum - 1)];
	sValue[1] = mac[3 * (bytenum - 1) + 1];
	sValue[2] = 0;

	ifx_httpdWrite(wp, T("%s"), sValue);

	return 0;

}

int set_cloexec_flag(int desc, int value)
{
	int oldflags = fcntl(desc, F_GETFD, 0);
	if (oldflags < 0)
		return oldflags;
	if (value != 0)
		oldflags |= FD_CLOEXEC;
	else
		oldflags &= ~FD_CLOEXEC;
	return fcntl(desc, F_SETFD, oldflags);
}

#ifdef CONFIG_FEATURE_IPv6
int32 ifx_set_ipv6(httpd_t wp, char_t * path, char_t * query)	//(int32 status, uint32 flags)
{
	char8 buf[MAX_FILELINE_LEN], sCommand[MAX_FILELINE_LEN],
	    sValue[MAX_FILELINE_LEN];
	int32 ret = IFX_SUCCESS, outFlag = IFX_SUCCESS;
	char_t *pCheck;
	int32 flags = IFX_F_MODIFY, prev_state = 0, status = 0;
	int32 cmdret = -1;
	a_assert(wp);
	char8 *sVal = NULL;

	// Get value from ASP filz
	pCheck = ifx_httpdGetVar(wp, T("ipv6_status"), T(""));

	status = atoi(pCheck);

	NULL_TERMINATE(buf, 0, sizeof(buf));
	NULL_TERMINATE(sCommand, 0, sizeof(sCommand));

	if (status == 1) {

#ifdef IPV6MODULE
		// call the function ifx_GetObjData store it in buf
		NULL_TERMINATE(sValue, 0, sizeof(sValue));
		sprintf(sCommand, "/usr/sbin/version.sh -k");
		if (ifx_GetCfgData((char_t *) sCommand, NULL, "1", sValue) == 0) {
			COPY_TO_STATUS("%s", "Failed to save setting")
			    ifx_httpdRedirect(wp, "err_page.html");
			return IFX_FAILURE;
		}

		memset(sCommand, 0, sizeof(sCommand));
		sprintf(sCommand, "/sbin/insmod /lib/modules/");
		strncat(sCommand, sValue, strlen(sValue));
		strcat(sCommand, "/ipv6.ko");
#else
		snprintf(sCommand, sizeof(sCommand),
			 "echo 0 >  /proc/sys/net/ipv6/conf/all/disable_ipv6");
#endif
	}

	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_IPV6, "ipv6_status",
			    IFX_F_GET_ANY, (IFX_OUT uint32 *) & outFlag,
			    sValue)) != IFX_SUCCESS) {
		COPY_TO_STATUS("%s", "Failed to save setting")
		    ifx_httpdRedirect(wp, "err_page.html");
		return IFX_FAILURE;
	}

	prev_state = gatoi(sValue);

	if (prev_state == status) {
		goto IFX_Handler;
	}

	snprintf(buf, sizeof(buf), "ipv6_status=\"%d\"\n", status);
	if ((ret =
	     ifx_SetObjData(FILE_RC_CONF, TAG_IPV6, flags, 1,
			    buf)) != IFX_SUCCESS) {
		IFX_DBG("[%s:%d], ERROR IN SETTING 1 [%s]\n", __FUNCTION__,
			__LINE__, FILE_RC_CONF);
		COPY_TO_STATUS("%s", "Failed to save setting")
		    ifx_httpdRedirect(wp, "err_page.html");
		return IFX_FAILURE;
	}
//IPv6
	sVal = (char8 *) malloc(50);
        if (sVal == NULL)
            return IFX_FAILURE;

	sprintf(sVal, "mode=\"Both\"\n");

	if ((ret = ifx_SetObjData(FILE_RC_CONF, "ipprotver",
				  IFX_F_MODIFY, 1, sVal)) != IFX_SUCCESS) {
		free(sVal);
		return IFX_FAILURE;
	}

	free(sVal);
//end IPv6

        if (status == 0) {
            sVal = (char8 *) malloc(50);

            if (sVal == NULL)
                return IFX_FAILURE;
            sprintf(sVal, "route_dynamic_fv6Enable=\"0\"\n");

            if ((ret = ifx_SetObjData(FILE_RC_CONF, "route_dynamic",
                                   IFX_F_MODIFY, 1, sVal)) != IFX_SUCCESS) {
                free(sVal);
                return IFX_FAILURE;
            }  
            free(sVal);
        }

	if (status == 0 && prev_state != status) {
		// save setting
		if (ifx_flash_write() <= 0) {
			COPY_TO_STATUS("%s", "Failed to save settings")
			    ifx_httpdRedirect(wp, "err_page.html");
			return IFX_FAILURE;
		}
#if 1				/*FIXME */
		system("/etc/rc.d/rebootcpe.sh 5 &");
#else
		if (system("echo 1 > /proc/sys/net/ipv6/conf/all/disable_ipv6")) {
			COPY_TO_STATUS("%s",
				       "System Error while trying to enable ipv6")
			    ifx_httpdRedirect(wp, "err_page.html");
			return IFX_FAILURE;
		}
#endif
	}
	//Runtime Change
	cmdret = system(sCommand);
	if (!cmdret) {		// if success return 0 else 256
#ifdef CONFIG_FEATURE_LTQ_WIRELESS_VB
		system("echo 0 > /proc/sys/net/ipv6/conf/all/forwarding");
		system(" /etc/rc.d/rc.bringup_lan v6start");
#else
		system("echo 1 > /proc/sys/net/ipv6/conf/all/forwarding");
		system(". /etc/rc.d/bringup_wan_dhcp6c");
		system(" /etc/rc.d/rc.bringup_lan v6start");
#endif
		ret = IFX_SUCCESS;
	} else {
		/* In case of failure of system configuration , just rollback the configuration */
		sprintf(buf, "ipv6_status=\"%d\"\n", prev_state);
		ifx_SetObjData(FILE_RC_CONF, TAG_IPV6, flags, 1, buf);

		COPY_TO_STATUS("%s", "Failed to enable ipv6")
		    ifx_httpdRedirect(wp, "err_page.html");
		return IFX_FAILURE;
	}

	// save setting
	if (ifx_flash_write() <= 0) {
		COPY_TO_STATUS("%s", "Failed to save settings")
		    ifx_httpdRedirect(wp, "err_page.html");
		return IFX_FAILURE;
	}

      IFX_Handler:
	websNextPage(wp);
	if (!cmdret && ret == IFX_SUCCESS) {
#if 0				/* we dont kill mini-httpd */
		int maxfd = open("/dev/null", O_RDONLY);
		int i = 0;
		if (maxfd < 0) {
			maxfd = 1024;
		} else {
			close(maxfd);
		}
		for (; i < maxfd; i++) {
			set_cloexec_flag(i, 1);
		}
#endif
		system(". /etc/rc.d/start_ipv6_apps telnetd ftpd httpd web &");
	}
	return ret;
}
#endif				// CONFIG_FEATURE_IPv6

#ifdef CONFIG_FEATURE_IPv6
int32 ifx_set_sixrd(httpd_t wp, char_t * path, char_t * query)	//(int32 status, uint32 flags)
{
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
        char8   retVal6[MAX_FILELINE_LEN], retVal7[MAX_FILELINE_LEN], retVal8[MAX_FILELINE_LEN];
	int32 ret = IFX_SUCCESS, outFlag = IFX_SUCCESS;
        int     ret_value_sixrd_tunnel_addr, type=1, type_prev=1;
	char_t *pCheck_sixrd;
	int32 flags = IFX_F_MODIFY, wanMode = 0, phy_mode = 0;
	a_assert(wp);
	pCheck_sixrd = ifx_httpdGetVar(wp, T("sixrd"), T(""));
        uint32 wan_sixrd = 0,prev_wan_sixrdwanidx=0,wan_sixrdwanidxl=0, wan_sixrd_mode = 0, 
               wan_sixrdprefixlen = 0, wan_sixrdmasklen = 0,pwan_ipv6_status=0, 
               sixrd_tunnel_value = 0;
	uint32 wan_mtu = 0;
	char8 wan_sixrdprefix[64], wan_sixrdbrip[MAX_IP_ADDR_LEN];
	char_t *sixrdmode = ifx_httpdGetVar(wp, T("INTRF_SIXRD"), T(""));
	char_t *sixrd_prefix = ifx_httpdGetVar(wp, T("SIXRDPREFIX"), T(""));
	char_t *sixrd_prefixlen =
	    ifx_httpdGetVar(wp, T("SIXRDPREFIXLEN"), T(""));
	char_t *sixrd_brip = ifx_httpdGetVar(wp, T("SIXRDBRIP"), T(""));
	char_t *sixrd_masklen = ifx_httpdGetVar(wp, T("SIXRDMASKLEN"), T(""));
	char_t *wansixrdidx = ifx_httpdGetVar(wp, T("INTRF_WAN"), T(""));
	char_t *wansixrd_mtu = ifx_httpdGetVar(wp, T("MTU"), T(""));
	sValue[0] = '\0';

	if (wansixrd_mtu == NULL) {
		COPY_TO_STATUS("%s",
			       "Internal configuration error. Please validate user inputs and try again.");
		ifx_httpdRedirect(wp, "err_page.html");
		return ret;
	}
	if (wansixrdidx == NULL) {
		COPY_TO_STATUS("%s",
			       "Please select a valid wan interface and then try again");
		ifx_httpdRedirect(wp, "err_page.html");
		return -1;
	}
        if (!strncmp(wansixrdidx, "WANPPP", 6)) {
                type=1;
                wan_sixrdwanidxl=atoi(wansixrdidx + 6);
        }
        else if (!strncmp(wansixrdidx, "WANIP", 5)){
                type=2;
                wan_sixrdwanidxl=atoi(wansixrdidx + 5);
        }
        else
               type=3;

        if (type != 3) {
               if (type == 1 ) {
                       snprintf(buf, sizeof(buf), "wanppp_%d_wanMode", wan_sixrdwanidxl);
                       if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue) != IFX_SUCCESS) {
                               COPY_TO_STATUS("%s", "Internal configuration error. Please validate user inputs and try again.");
                               ifx_httpdRedirect(wp, "err_page.html");
                               #ifdef IFX_LOG_DEBUG
                               IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
                               #endif
                               return IFX_FAILURE;
                       }
               }
               else {
                        snprintf(buf, sizeof(buf), "wanip_%d_wanMode", wan_sixrdwanidxl);
                        if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue) != IFX_SUCCESS) {
                                COPY_TO_STATUS("%s", "Internal configuration error. Please validate user inputs and try again.");
                                ifx_httpdRedirect(wp, "err_page.html");
                                #ifdef IFX_LOG_DEBUG
                                IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
                                #endif
                                return IFX_FAILURE;
                        }
                }

		if (sValue[0] == '\0') {
			COPY_TO_STATUS("%s",
				       "Error: Couldn't get wan mode of the selected wan interface");
			ifx_httpdRedirect(wp, "err_page.html");
			return -1;
		}
		wanMode = atoi(sValue);
		sValue[0] = '\0';
		snprintf(buf, sizeof(buf), "wanphy_phymode");
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_WAN_PHY_CFG, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS) {
			COPY_TO_STATUS("%s",
				       "Internal configuration error. Please validate user inputs and try again.");
			ifx_httpdRedirect(wp, "err_page.html");
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__);
#endif
			return IFX_FAILURE;
		}
		if (sValue[0] == '\0') {
			COPY_TO_STATUS("%s",
				       "Error: Couldn't get courrent wan mode");
			ifx_httpdRedirect(wp, "err_page.html");
			return -1;
		}
		phy_mode = atoi(sValue);
		if ((wanMode == WAN_MODE_ETH0
		     && phy_mode != WAN_PHY_MODE_ETH_MII0)
		    || (wanMode == WAN_MODE_ETH1
			&& phy_mode != WAN_PHY_MODE_ETH_MII1)
		    || ((wanMode == WAN_MODE_ATM || wanMode == WAN_MODE_PTM)
			&& phy_mode != WAN_PHY_MODE_ADSL2)
		    || (wanMode == WAN_MODE_VDSL_PTM
			&& phy_mode != WAN_PHY_MODE_VDSL2)) {

			COPY_TO_STATUS("%s", create_sixrd_tunnel_err);
			ifx_httpdRedirect(wp, "err_page.html");
			return -1;
		}
		sValue[0] = '\0';
#if 0
		snprintf(buf, sizeof(buf), "wan_%d_ipv6", wan_sixrdwanidx);
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_WAN_MAIN, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS) {
			COPY_TO_STATUS("%s",
				       "Internal configuration error. Please validate user inputs and try again.");
			ifx_httpdRedirect(wp, "err_page.html");
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__);
#endif
			return IFX_FAILURE;
		}
#endif

               if (type == 1) {
                       snprintf(buf, sizeof(buf), "wanppp_%d_ipv6", wan_sixrdwanidxl);
                       if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue) != IFX_SUCCESS) {
                               COPY_TO_STATUS("%s", "Internal configuration error. Please validate user inputs and try again.");
                               ifx_httpdRedirect(wp, "err_page.html");
                               #ifdef IFX_LOG_DEBUG
                               IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
                               #endif
                               return IFX_FAILURE;
                       }
               }
               else {
                        snprintf(buf, sizeof(buf), "wanip_%d_ipv6", wan_sixrdwanidxl);
                        if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue) != IFX_SUCCESS) {
                                COPY_TO_STATUS("%s", "Internal configuration error. Please validate user inputs and try again.");
                                ifx_httpdRedirect(wp, "err_page.html");
                                #ifdef IFX_LOG_DEBUG
                                IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
                                #endif
                                return IFX_FAILURE;
                        }
                 }

		pwan_ipv6_status = atoi(sValue);
		if (pwan_ipv6_status == 2) {
			COPY_TO_STATUS("%s", create_sixrd_tunnel_pwan_ipv6_err);
			ifx_httpdRedirect(wp, "err_page.html");
			return -1;
		}
		retVal7[0] = '\0';
                if (type == 1)
                     snprintf(buf, sizeof(buf), "WanPPP%d_IF_Info", wan_sixrdwanidxl);
                else
                     snprintf(buf, sizeof(buf), "WanIP%d_IF_Info", wan_sixrdwanidxl);

		if (ifx_GetObjData
		    (FILE_SYSTEM_STATUS, buf, "STATUS", IFX_F_GET_ANY,
		     (IFX_OUT uint32 *) & outFlag, retVal7) != IFX_SUCCESS) {
			/* WAN instance doesn't exist - hence OP_ADD */
			COPY_TO_STATUS("%s",
				       "Internal configuration error. Please validate user inputs and try again.");
			ifx_httpdRedirect(wp, "err_page.html");
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Form Name=Value buffer Fail",
				__FUNCTION__, __LINE__);
#endif
			return IFX_FAILURE;
		} else {
			if (pCheck_sixrd == NULL) {
				COPY_TO_STATUS("%s",
					       "Internal configuration error. Please validate user inputs and try again.");
				ifx_httpdRedirect(wp, "err_page.html");
				return -1;
			}
			wan_sixrd = atoi(pCheck_sixrd);
			if (wan_sixrd == 1) {
				sValue[0] = '\0';
				snprintf(buf, sizeof(buf), "wan_sixrdwanidx");
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_IPV6, buf, flags,
				     (IFX_OUT uint32 *) & outFlag,
				     sValue) != IFX_SUCCESS) {
					COPY_TO_STATUS("%s",
						       "Internal configuration error. Please validate user inputs and try again.");
					ifx_httpdRedirect(wp, "err_page.html");
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] Form Name=Value buffer Fail",
					     __FUNCTION__, __LINE__);
#endif
					return IFX_FAILURE;
				}
#if 0
				prev_wan_sixrdwanidx = atoi(sValue);
				if (prev_wan_sixrdwanidx != 0) {
					sValue[0] = '\0';
					snprintf(buf, sizeof(buf),
						 "wan_%d_tunnel",
						 prev_wan_sixrdwanidx);
					if (ifx_GetObjData
					    (FILE_RC_CONF, TAG_WAN_MAIN, buf,
					     flags,
					     (IFX_OUT uint32 *) & outFlag,
					     sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
						IFX_DBG
						    ("[%s:%d] Form Name=Value buffer Fail",
						     __FUNCTION__, __LINE__);
#endif
/*                                        	COPY_TO_STATUS("%s", "Failed to save setting");
                                        	ifx_httpdRedirect(wp, "err_page.html");
                                        	#ifdef IFX_LOG_DEBUG
                                        	IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
                                        	#endif
                                        	return IFX_FAILURE;
*/
					}
					if ((!strcmp(sValue, "1"))
					    || (!strcmp(sValue, "3"))) {
						snprintf(buf, sizeof(buf),
							 "/etc/rc.d/6rdtunnel.sh stop %d",
							 prev_wan_sixrdwanidx);
						system(buf);
						if (!strcmp(sValue, "1"))
							snprintf(buf,
								 sizeof(buf),
								 "wan_%d_tunnel=\"0\"\n",
								 prev_wan_sixrdwanidx);
						else if (!strcmp(sValue, "3"))
							snprintf(buf,
								 sizeof(buf),
								 "wan_%d_tunnel=\"2\"\n",
								 prev_wan_sixrdwanidx);

						if (ifx_SetObjData
						    (FILE_RC_CONF, TAG_WAN_MAIN,
						     flags, 1,
						     buf) != IFX_SUCCESS) {
							COPY_TO_STATUS("%s",
								       "Internal configuration error. Please validate user inputs and try again.");
							ifx_httpdRedirect(wp,
									  "err_page.html");
#ifdef IFX_LOG_DEBUG
							IFX_DBG
							    ("[%s:%d] Form Name=Value buffer Fail",
							     __FUNCTION__,
							     __LINE__);
#endif
							return IFX_FAILURE;
						}
						sValue[0] = '\0';
						snprintf(buf, sizeof(buf),
							 "wan_%d_linkType",
							 prev_wan_sixrdwanidx);
						if (ifx_GetObjData
						    (FILE_RC_CONF, TAG_WAN_MAIN,
						     buf, flags,
						     (IFX_OUT uint32 *) &
						     outFlag,
						     sValue) != IFX_SUCCESS) {
							COPY_TO_STATUS("%s",
								       "Internal configuration error. Please validate user inputs and try again.");
							ifx_httpdRedirect(wp,
									  "err_page.html");
#ifdef IFX_LOG_DEBUG
							IFX_DBG
							    ("[%s:%d] Form Name=Value buffer Fail",
							     __FUNCTION__,
							     __LINE__);
#endif
							return IFX_FAILURE;
						}
						if (!strcmp(sValue, "4")) {
							sValue[0] = '\0';
							snprintf(buf,
								 sizeof(buf),
								 "wan_sixrd_mode");
							if (ifx_GetObjData
							    (FILE_RC_CONF,
							     TAG_IPV6, buf,
							     flags,
							     (IFX_OUT uint32 *)
							     & outFlag,
							     sValue) !=
							    IFX_SUCCESS) {
								COPY_TO_STATUS
								    ("%s",
								     "Internal configuration error. Please validate user inputs and try again.");
								ifx_httpdRedirect
								    (wp,
								     "err_page.html");
#ifdef IFX_LOG_DEBUG
								IFX_DBG
								    ("[%s:%d] Form Name=Value buffer Fail",
								     __FUNCTION__,
								     __LINE__);
#endif
								return
								    IFX_FAILURE;
							}
							if (!strcmp
							    (sValue, "0")) {
								snprintf(buf,
									 sizeof
									 (buf),
									 "kill -9 $(cat /var/run/udhcpc%d.pid) 2> /dev/null",
									 prev_wan_sixrdwanidx);
								system(buf);
							}
						}
					}
				}
#endif
                               strncpy(retVal8, sValue, sizeof(retVal8));
                               if (!strncmp(sValue, "WANPPP", 6)) {
                                       type_prev=1;
                                       prev_wan_sixrdwanidx=atoi(sValue + 6);
                               }
                                else if (!strncmp(sValue, "WANIP", 5)) {
                                        type_prev=2;
                                        prev_wan_sixrdwanidx=atoi(sValue + 5);
                                }
                               else
                                       type_prev=3;
                                if(type_prev != 3) {
                                       if (type_prev == 1) {
                                               snprintf(buf, sizeof(buf), "wanppp_%d_tunnel", prev_wan_sixrdwanidx);
                                               if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, flags, 
                                                             (IFX_OUT uint32 *)&outFlag, sValue) != IFX_SUCCESS) {
                                                       #ifdef IFX_LOG_DEBUG
                                                       IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
                                                       #endif
                                               }
                                       }
                                       else {
                                                snprintf(buf, sizeof(buf), "wanip_%d_tunnel", prev_wan_sixrdwanidx);
                                                if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags, 
                                                            (IFX_OUT uint32 *)&outFlag, sValue) != IFX_SUCCESS) {
                                                        #ifdef IFX_LOG_DEBUG
                                                        IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
                                                        #endif
                                                }
                                      }

                                      if((!strcmp(sValue, "1")) || (!strcmp(sValue, "3"))) {
                                              snprintf(buf, sizeof(buf), "/etc/rc.d/6rdtunnel.sh stop %d", prev_wan_sixrdwanidx);
                                              system(buf);
                                              if(type_prev == 1) {
                                                      if(!strcmp(sValue, "1"))
                                                             snprintf(buf, sizeof(buf), "wanppp_%d_tunnel=\"0\"\n", prev_wan_sixrdwanidx);
                                                      else if(!strcmp(sValue, "3"))
                                                             snprintf(buf, sizeof(buf), "wanppp_%d_tunnel=\"2\"\n", prev_wan_sixrdwanidx);

                                                      if(ifx_SetObjData(FILE_RC_CONF, TAG_WAN_PPP, flags, 1, buf) != IFX_SUCCESS) {
                                                              COPY_TO_STATUS("%s", "Internal configuration error. Please validate user inputs and try again.");
                                                              ifx_httpdRedirect(wp, "err_page.html");
                                                              #ifdef IFX_LOG_DEBUG
                                                              IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
                                                              #endif
                                                              return IFX_FAILURE;
                                                       }
                                                       sValue[0]='\0';
                                                       snprintf(buf, sizeof(buf), "wanppp_%d_linkType", prev_wan_sixrdwanidx);
                                                       if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, flags, 
                                                                             (IFX_OUT uint32 *)&outFlag, sValue) != IFX_SUCCESS) {
                                                                COPY_TO_STATUS("%s", "Internal configuration error. Please validate user inputs and try again.");
                                                                ifx_httpdRedirect(wp, "err_page.html");
                                                                #ifdef IFX_LOG_DEBUG
                                                                IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
                                                                #endif
                                                                return IFX_FAILURE;
                                                        }

                                              }
                                              else
                                              {
                                                      if(!strcmp(sValue, "1"))
                                                             snprintf(buf, sizeof(buf), "wanip_%d_tunnel=\"0\"\n", prev_wan_sixrdwanidx);
                                                      else if(!strcmp(sValue, "3"))
                                                             snprintf(buf, sizeof(buf), "wanip_%d_tunnel=\"2\"\n", prev_wan_sixrdwanidx);


                                                      if(ifx_SetObjData(FILE_RC_CONF, TAG_WAN_IP, flags, 1, buf) != IFX_SUCCESS) {
                                                              COPY_TO_STATUS("%s", "Internal configuration error. Please validate user inputs and try again.");
                                                              ifx_httpdRedirect(wp, "err_page.html");
                                                              #ifdef IFX_LOG_DEBUG
                                                              IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
                                                              #endif
                                                              return IFX_FAILURE;
                                                       }
                                                       sValue[0]='\0';
                                                       snprintf(buf, sizeof(buf), "wanip_%d_linkType", prev_wan_sixrdwanidx);
                                                       if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags, (IFX_OUT uint32 *)&outFlag, 
                                                                       sValue) != IFX_SUCCESS) {
                                                                COPY_TO_STATUS("%s", "Internal configuration error. Please validate user inputs and try again.");
                                                                ifx_httpdRedirect(wp, "err_page.html");
                                                                #ifdef IFX_LOG_DEBUG
                                                                IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
                                                                #endif
                                                                return IFX_FAILURE;
                                                        }
                                              }
                                        

					if ((!strcmp(sValue, "4") ) || (!strcmp(sValue, "7"))) {
                                                     sValue[0]='\0';
                                                     snprintf(buf, sizeof(buf), "wan_sixrd_mode");
                                                     if (ifx_GetObjData(FILE_RC_CONF, TAG_IPV6, buf, flags, (IFX_OUT uint32 *)&outFlag, 
                                                                          sValue) != IFX_SUCCESS) {
                                                             COPY_TO_STATUS("%s", "Internal configuration error. Please validate user inputs and try again.");
                                                             ifx_httpdRedirect(wp, "err_page.html");
                                                             #ifdef IFX_LOG_DEBUG
                                                             IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
                                                             #endif
                                                             return IFX_FAILURE;
                                                     }
                                                     if(!strcmp(sValue, "0")) {
							if (type != 1)
                                                             snprintf(buf, sizeof(buf), ". /etc/rc.d/6rdtunnel.sh wan_restart %d %s", prev_wan_sixrdwanidx, "ip");
							else
							      snprintf(buf, sizeof(buf), ". /etc/rc.d/6rdtunnel.sh wan_restart %d %s", prev_wan_sixrdwanidx, "ppp");	
					
                                                             system(buf);
                                                     }
                                              }
                                        } //end of if((!strcmp(sValue, "1")) || (!strcmp(sValue, "3")))
                                } //end of if(type_prev != 3)


                                if (type == 1)
                                snprintf(buf, sizeof(buf), "wan_sixrdwanidx=\"WANPPP%d\"\n", wan_sixrdwanidxl);
                                else
                                snprintf(buf, sizeof(buf), "wan_sixrdwanidx=\"WANIP%d\"\n", wan_sixrdwanidxl);


				if (ifx_SetObjData
				    (FILE_RC_CONF, TAG_IPV6, flags, 1,
				     buf) != IFX_SUCCESS) {
					COPY_TO_STATUS("%s",
						       "Internal configuration error. Please validate user inputs and try again.");
					ifx_httpdRedirect(wp, "err_page.html");
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] Form Name=Value buffer Fail",
					     __FUNCTION__, __LINE__);
#endif
					return IFX_FAILURE;
				}
				if (sixrdmode == NULL) {
					COPY_TO_STATUS("%s",
						       "Please select a valid configuration mode and then try again");
					ifx_httpdRedirect(wp, "err_page.html");
					return -1;
				}
				wan_sixrd_mode = atoi(sixrdmode);
				snprintf(buf, sizeof(buf),
					 "wan_sixrd_mode=\"%d\"\n",
					 wan_sixrd_mode);
				if (ifx_SetObjData
				    (FILE_RC_CONF, TAG_IPV6, flags, 1,
				     buf) != IFX_SUCCESS) {
					COPY_TO_STATUS("%s",
						       "Internal configuration error. Please validate user inputs and try again.");
					ifx_httpdRedirect(wp, "err_page.html");
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] Form Name=Value buffer Fail",
					     __FUNCTION__, __LINE__);
#endif
					return IFX_FAILURE;
				}
				if (!strcmp(wansixrd_mtu, ""))
					wan_mtu = 0;
				else
					wan_mtu = atoi(wansixrd_mtu);
				snprintf(buf, sizeof(buf),
					 "wan_sixrd_mtu=\"%d\"\n", wan_mtu);
				if (ifx_SetObjData
				    (FILE_RC_CONF, TAG_IPV6, flags, 1,
				     buf) != IFX_SUCCESS) {
					COPY_TO_STATUS("%s",
						       "Internal configuration error. Please validate user inputs and try again.");
					ifx_httpdRedirect(wp, "err_page.html");
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] Form Name=Value buffer Fail",
					     __FUNCTION__, __LINE__);
#endif
					return IFX_FAILURE;
				}
				sValue[0] = '\0';
#if 0
				snprintf(buf, sizeof(buf), "wan_%d_tunnel",
					 wan_sixrdwanidx);
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_WAN_MAIN, buf, flags,
				     (IFX_OUT uint32 *) & outFlag,
				     sValue) != IFX_SUCCESS) {
					COPY_TO_STATUS("%s",
						       "Internal configuration error. Please validate user inputs and try again.");
					ifx_httpdRedirect(wp, "err_page.html");
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] Form Name=Value buffer Fail",
					     __FUNCTION__, __LINE__);
#endif
					return IFX_FAILURE;
				}
				if (!strcmp(sValue, "0"))
					sixrd_tunnel_value = 1;
				else if (!strcmp(sValue, "1"))
					sixrd_tunnel_value = 1;
				else if (!strcmp(sValue, "2"))
					sixrd_tunnel_value = 3;
				else if (!strcmp(sValue, "3"))
					sixrd_tunnel_value = 3;
				snprintf(buf, sizeof(buf),
					 "wan_%d_tunnel=\"%d\"\n",
					 wan_sixrdwanidx, sixrd_tunnel_value);

				if (ifx_SetObjData
				    (FILE_RC_CONF, TAG_WAN_MAIN, flags, 1,
				     buf) != IFX_SUCCESS) {
					COPY_TO_STATUS("%s",
						       "Internal configuration error. Please validate user inputs and try again.");
					ifx_httpdRedirect(wp, "err_page.html");
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] Form Name=Value buffer Fail",
					     __FUNCTION__, __LINE__);
#endif
					return IFX_FAILURE;
				}
#endif

              			if (type == 1 ) {

			                snprintf(buf, sizeof(buf), "wanppp_%d_tunnel", wan_sixrdwanidxl);
			                if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, flags, 
                                             (IFX_OUT uint32 *)&outFlag, sValue) != IFX_SUCCESS) {
			                     COPY_TO_STATUS("%s", "Internal configuration error. Please validate user inputs and try again.");
			                     ifx_httpdRedirect(wp, "err_page.html");
#ifdef IFX_LOG_DEBUG
			                     IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
#endif
			                     return IFX_FAILURE;
			                }
			                if(!strcmp(sValue, "0"))
			                    sixrd_tunnel_value = 1;
			                else if (!strcmp(sValue, "1"))
			                    sixrd_tunnel_value = 1;
			                else if (!strcmp(sValue, "2"))
			                    sixrd_tunnel_value = 3;
			                else if (!strcmp(sValue, "3"))
			                    sixrd_tunnel_value = 3;
			                snprintf(buf, sizeof(buf), "wanppp_%d_tunnel=\"%d\"\n", wan_sixrdwanidxl, sixrd_tunnel_value);

			                if(ifx_SetObjData(FILE_RC_CONF, TAG_WAN_PPP, flags, 1, buf) != IFX_SUCCESS) {
			                       COPY_TO_STATUS("%s", "Internal configuration error. Please validate user inputs and try again.");
			                       ifx_httpdRedirect(wp, "err_page.html");
#ifdef IFX_LOG_DEBUG
			                       IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
#endif
			                       return IFX_FAILURE;
			                 }
		             }
		             else {
				         snprintf(buf, sizeof(buf), "wanip_%d_tunnel", wan_sixrdwanidxl);
			                 if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags, (IFX_OUT uint32 *)&outFlag, 
						sValue) != IFX_SUCCESS) {
			                     COPY_TO_STATUS("%s", "Internal configuration error. Please validate user inputs and try again.");
			                     ifx_httpdRedirect(wp, "err_page.html");
#ifdef IFX_LOG_DEBUG
			                     IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
#endif
			                     return IFX_FAILURE;
			 		}
			                if(!strcmp(sValue, "0"))
			                    sixrd_tunnel_value = 1;
			                else if (!strcmp(sValue, "1"))
			                    sixrd_tunnel_value = 1;
			                else if (!strcmp(sValue, "2"))
			                    sixrd_tunnel_value = 3;
			                else if (!strcmp(sValue, "3"))
			                    sixrd_tunnel_value = 3;
			                snprintf(buf, sizeof(buf), "wanip_%d_tunnel=\"%d\"\n", wan_sixrdwanidxl, sixrd_tunnel_value);

			                if(ifx_SetObjData(FILE_RC_CONF, TAG_WAN_IP, flags, 1, buf) != IFX_SUCCESS) {
		                       		COPY_TO_STATUS("%s", "Internal configuration error. Please validate user inputs and try again.");
	                		       ifx_httpdRedirect(wp, "err_page.html");
#ifdef IFX_LOG_DEBUG
			                       IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
#endif
			                       return IFX_FAILURE;
					}
		             }



				if (wan_sixrd_mode == 1) {
					if (sixrd_prefix == NULL) {
						COPY_TO_STATUS("%s",
							       "Please put a valid 6RD Prefix and then try again");
						ifx_httpdRedirect(wp,
								  "err_page.html");
						return -1;
					}
					snprintf(wan_sixrdprefix,
						 sizeof(wan_sixrdprefix),
						 sixrd_prefix);
					if (sixrd_prefixlen == NULL) {
						COPY_TO_STATUS("%s",
							       "Please put a valid 6RD Prefix Length and then try again");
						ifx_httpdRedirect(wp,
								  "err_page.html");
						return -1;
					}
					wan_sixrdprefixlen =
					    atoi(sixrd_prefixlen);
					if (sixrd_brip == NULL) {
						COPY_TO_STATUS("%s",
							       "Please put a valid 6RD BR IP and then try again");
						ifx_httpdRedirect(wp,
								  "err_page.html");
						return -1;
					}
					snprintf(wan_sixrdbrip,
						 sizeof(wan_sixrdbrip),
						 sixrd_brip);
					if (sixrd_masklen == NULL) {
						COPY_TO_STATUS("%s",
							       "Please put a valid IPv4 Mask Length and then try again");
						ifx_httpdRedirect(wp,
								  "err_page.html");
						return -1;
					}
					wan_sixrdmasklen = atoi(sixrd_masklen);
					ret_value_sixrd_tunnel_addr =
					    evalute_tunnel_intf_addr((char *)
								     wan_sixrdprefix,
								     (char *)
								     wan_sixrdbrip,
								     (char *)
								     sixrd_masklen,
								     (char *)
								     sixrd_prefixlen);
					if (ret_value_sixrd_tunnel_addr == 1) {
						COPY_TO_STATUS("%s",
							       "Invalid 6RD Prefix. Please put correct 6RD Prefix and then try again.");
						ifx_httpdRedirect(wp,
								  "err_page.html");
						return -1;
					} else if (ret_value_sixrd_tunnel_addr
						   == 2) {
						COPY_TO_STATUS("%s",
							       "Invalid 6RD BR IP. Please put correct 6RD BR IP and then try again.");
						ifx_httpdRedirect(wp,
								  "err_page.html");
						return -1;
					} else if (ret_value_sixrd_tunnel_addr
						   == 3) {
						COPY_TO_STATUS("%s",
							       "Sum of 6RD Prefix Length and (32-IPv4 Mask Length) exceeds 64. Please put correct 6RD Prefix Length and IPv4 Mask Length and then try again.");
						ifx_httpdRedirect(wp,
								  "err_page.html");
						return -1;
					} else if (ret_value_sixrd_tunnel_addr
						   == 4) {
						COPY_TO_STATUS("%s",
							       "Invalid 6RD Prefix Length. Please put correct 6RD Prefix Length and then try again.");
						ifx_httpdRedirect(wp,
								  "err_page.html");
						return -1;
					} else if (ret_value_sixrd_tunnel_addr
						   != 0) {
						COPY_TO_STATUS("%s",
							       "An error occured please try again.");
						ifx_httpdRedirect(wp,
								  "err_page.html");
						return -1;
					}
					snprintf(buf, sizeof(buf),
						 "wan_sixrdprefix=\"%s\"\n",
						 wan_sixrdprefix);
					if (ifx_SetObjData
					    (FILE_RC_CONF, TAG_IPV6, flags, 1,
					     buf) != IFX_SUCCESS) {
						COPY_TO_STATUS("%s",
							       "Internal configuration error. Please validate user inputs and try again.");
						ifx_httpdRedirect(wp,
								  "err_page.html");
#ifdef IFX_LOG_DEBUG
						IFX_DBG
						    ("[%s:%d] Form Name=Value buffer Fail",
						     __FUNCTION__, __LINE__);
#endif
						return IFX_FAILURE;
					}
					snprintf(buf, sizeof(buf),
						 "wan_sixrdprefixlen=\"%d\"\n",
						 wan_sixrdprefixlen);
					if (ifx_SetObjData
					    (FILE_RC_CONF, TAG_IPV6, flags, 1,
					     buf) != IFX_SUCCESS) {
						COPY_TO_STATUS("%s",
							       "Internal configuration error. Please validate user inputs and try again.");
						ifx_httpdRedirect(wp,
								  "err_page.html");
#ifdef IFX_LOG_DEBUG
						IFX_DBG
						    ("[%s:%d] Form Name=Value buffer Fail",
						     __FUNCTION__, __LINE__);
#endif
						return IFX_FAILURE;
					}
					snprintf(buf, sizeof(buf),
						 "wan_sixrdbrip=\"%s\"\n",
						 wan_sixrdbrip);
					if (ifx_SetObjData
					    (FILE_RC_CONF, TAG_IPV6, flags, 1,
					     buf) != IFX_SUCCESS) {
						COPY_TO_STATUS("%s",
							       "Internal configuration error. Please validate user inputs and try again.");
						ifx_httpdRedirect(wp,
								  "err_page.html");
#ifdef IFX_LOG_DEBUG
						IFX_DBG
						    ("[%s:%d] Form Name=Value buffer Fail",
						     __FUNCTION__, __LINE__);
#endif
						return IFX_FAILURE;
					}
					snprintf(buf, sizeof(buf),
						 "wan_sixrdmasklen=\"%d\"\n",
						 wan_sixrdmasklen);
					if (ifx_SetObjData
					    (FILE_RC_CONF, TAG_IPV6, flags, 1,
					     buf) != IFX_SUCCESS) {
						COPY_TO_STATUS("%s",
							       "Internal configuration error. Please validate user inputs and try again.");
						ifx_httpdRedirect(wp,
								  "err_page.html");
#ifdef IFX_LOG_DEBUG
						IFX_DBG
						    ("[%s:%d] Form Name=Value buffer Fail",
						     __FUNCTION__, __LINE__);
#endif
						return IFX_FAILURE;
					}
					if (!strcmp(retVal7, "CONNECTED")) {
						sValue[0] = '\0';
                                                if (type == 1)
                                                snprintf(buf, sizeof(buf), "WanPPP%d_IF_Info", wan_sixrdwanidxl);
                                                else
                                                snprintf(buf, sizeof(buf), "WanIP%d_IF_Info", wan_sixrdwanidxl);

						if (ifx_GetObjData
						    (FILE_SYSTEM_STATUS, buf,
						     "IP", IFX_F_GET_ANY,
						     (IFX_OUT uint32 *) &
						     outFlag,
						     sValue) != IFX_SUCCESS) {
							COPY_TO_STATUS("%s",
								       "Internal configuration error. Please validate user inputs and try again.");
							ifx_httpdRedirect(wp,
									  "err_page.html");
#ifdef IFX_LOG_DEBUG
							IFX_DBG
							    ("[%s:%d] Form Name=Value buffer Fail",
							     __FUNCTION__,
							     __LINE__);
#endif
							return IFX_FAILURE;
						}
						if (wan_mtu == 0) {
							snprintf(buf,
								 sizeof(buf),
								 "/etc/rc.d/6rdtunnel.sh start %d %s %s %d %s %d",
								 wan_sixrdwanidxl,
								 sValue,
								 wan_sixrdprefix,
								 wan_sixrdprefixlen,
								 wan_sixrdbrip,
								 wan_sixrdmasklen);
							system(buf);
						} else {
							snprintf(buf,
								 sizeof(buf),
								 "/etc/rc.d/6rdtunnel.sh start %d %s %s %d %s %d %d",
								 wan_sixrdwanidxl,
								 sValue,
								 wan_sixrdprefix,
								 wan_sixrdprefixlen,
								 wan_sixrdbrip,
								 wan_sixrdmasklen,
								 wan_mtu);
							system(buf);
						}
					} else {
							if (type != 1)
								snprintf(buf, sizeof(buf), "/etc/rc.d/6rdtunnel.sh wan_restart %d %s", wan_sixrdwanidxl, "ip");
							else
								snprintf(buf, sizeof(buf), "/etc/rc.d/6rdtunnel.sh wan_restart %d %s", wan_sixrdwanidxl, "ppp");
							
						system(buf);
					}
				} else {

							if (type != 1)
								snprintf(buf, sizeof(buf), "/etc/rc.d/6rdtunnel.sh wan_restart %d %s", wan_sixrdwanidxl, "ip");
							else
								snprintf(buf, sizeof(buf), "/etc/rc.d/6rdtunnel.sh wan_restart %d %s", wan_sixrdwanidxl, "ppp");
							


					system(buf);
				}
			} else {
				retVal6[0] = '\0';
#if 0
				snprintf(buf, sizeof(buf), "wan_%d_tunnel",
					 wan_sixrdwanidx);
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_WAN_MAIN, buf, flags,
				     (IFX_OUT uint32 *) & outFlag,
				     retVal6) != IFX_SUCCESS) {
					COPY_TO_STATUS("%s",
						       "Internal configuration error. Please validate user inputs and try again.");
					ifx_httpdRedirect(wp, "err_page.html");
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] Form Name=Value buffer Fail",
					     __FUNCTION__, __LINE__);
#endif
					return IFX_FAILURE;
				}
				if ((!strcmp(retVal6, "1"))
				    || (!strcmp(sValue, "3"))) {
					if (!strcmp(sValue, "1"))
						snprintf(buf, sizeof(buf),
							 "wan_%d_tunnel=\"0\"\n",
							 wan_sixrdwanidx);
					else if (!strcmp(sValue, "3"))
						snprintf(buf, sizeof(buf),
							 "wan_%d_tunnel=\"2\"\n",
							 wan_sixrdwanidx);

					if (ifx_SetObjData
					    (FILE_RC_CONF, TAG_WAN_MAIN, flags,
					     1, buf) != IFX_SUCCESS) {
						COPY_TO_STATUS("%s",
							       "Internal configuration error. Please validate user inputs and try again.");
						ifx_httpdRedirect(wp,
								  "err_page.html");
#ifdef IFX_LOG_DEBUG
						IFX_DBG
						    ("[%s:%d] Form Name=Value buffer Fail",
						     __FUNCTION__, __LINE__);
#endif
						return IFX_FAILURE;
					}
				}
#endif

                                if (type == 1 ) {
	                                snprintf(buf, sizeof(buf), "wanppp_%d_tunnel", wan_sixrdwanidxl);
        	                        if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, flags, 
						(IFX_OUT uint32 *)&outFlag, retVal6) != IFX_SUCCESS) {
	                                        COPY_TO_STATUS("%s", "Internal configuration error. Please validate user inputs and try again.");
	                                        ifx_httpdRedirect(wp, "err_page.html");
#ifdef IFX_LOG_DEBUG
	                                        IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
#endif
	                                        return IFX_FAILURE;
                          		}
			                if((!strcmp(retVal6, "1")) || (!strcmp(sValue, "3"))) {
			                     if(!strcmp(sValue, "1"))
                        			  snprintf(buf, sizeof(buf),"wanppp_%d_tunnel=\"0\"\n", wan_sixrdwanidxl);
			                     else if(!strcmp(sValue, "3"))
                        			  snprintf(buf, sizeof(buf),"wanppp_%d_tunnel=\"2\"\n", wan_sixrdwanidxl);

	                                     if(ifx_SetObjData(FILE_RC_CONF, TAG_WAN_PPP, flags, 1, buf) != IFX_SUCCESS) {
         	                                COPY_TO_STATUS("%s", "Internal configuration error. Please validate user inputs and try again.");
                                                ifx_httpdRedirect(wp, "err_page.html");
#ifdef IFX_LOG_DEBUG
                                                IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
#endif
                                                return IFX_FAILURE;
	                                     }
	                                }	
                             } //end of if (type == 1 )
                             else
                             {
                             	   snprintf(buf, sizeof(buf), "wanip_%d_tunnel", wan_sixrdwanidxl);
                                   if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags, (IFX_OUT uint32 *)&outFlag, 
					retVal6) != IFX_SUCCESS) {
                                        COPY_TO_STATUS("%s", "Internal configuration error. Please validate user inputs and try again.");
                                        ifx_httpdRedirect(wp, "err_page.html");
#ifdef IFX_LOG_DEBUG
                                        IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
#endif
                                        return IFX_FAILURE;
                                   }
		                   if((!strcmp(retVal6, "1")) || (!strcmp(sValue, "3"))) {
                   			  if(!strcmp(sValue, "1"))
			                          snprintf(buf, sizeof(buf),"wanip_%d_tunnel=\"0\"\n", wan_sixrdwanidxl);
			                  else if(!strcmp(sValue, "3"))
                        			  snprintf(buf, sizeof(buf),"wanip_%d_tunnel=\"2\"\n", wan_sixrdwanidxl);

                                          if(ifx_SetObjData(FILE_RC_CONF, TAG_WAN_IP, flags, 1, buf) != IFX_SUCCESS) {
                                                COPY_TO_STATUS("%s", "Internal configuration error. Please validate user inputs and try again.");
                                                ifx_httpdRedirect(wp, "err_page.html");
#ifdef IFX_LOG_DEBUG
                                                IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
#endif
                                                return IFX_FAILURE;
                                          }
                                  }

                             }


				sValue[0] = '\0';
				snprintf(buf, sizeof(buf), "wan_sixrdwanidx");
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_IPV6, buf, flags,
				     (IFX_OUT uint32 *) & outFlag,
				     sValue) != IFX_SUCCESS) {
					COPY_TO_STATUS("%s",
						       "Internal configuration error. Please validate user inputs and try again.");
					ifx_httpdRedirect(wp, "err_page.html");
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("[%s:%d] Form Name=Value buffer Fail",
					     __FUNCTION__, __LINE__);
#endif
					return IFX_FAILURE;
				}
                                if (type == 1)
                                snprintf(buf, sizeof(buf), "WANPPP%d", wan_sixrdwanidxl);
                                else
                                snprintf(buf, sizeof(buf), "WANIP%d", wan_sixrdwanidxl);


				if (!strcmp(sValue, buf)) {
					snprintf(buf, sizeof(buf),
						 "wan_sixrdwanidx=\"0\"\n");
					if (ifx_SetObjData
					    (FILE_RC_CONF, TAG_IPV6, flags, 1,
					     buf) != IFX_SUCCESS) {
						COPY_TO_STATUS("%s",
							       "Internal configuration error. Please validate user inputs and try again.");
						ifx_httpdRedirect(wp,
								  "err_page.html");
#ifdef IFX_LOG_DEBUG
						IFX_DBG
						    ("[%s:%d] Form Name=Value buffer Fail",
						     __FUNCTION__, __LINE__);
#endif
						return IFX_FAILURE;
					}
					snprintf(buf, sizeof(buf),
						 "/etc/rc.d/6rdtunnel.sh stop %d",
						 wan_sixrdwanidxl);
					system(buf);
					sValue[0] = '\0';
#if 0
					snprintf(buf, sizeof(buf),
						 "wan_%d_linkType",
						 wan_sixrdwanidx);
					if (ifx_GetObjData
					    (FILE_RC_CONF, TAG_WAN_MAIN, buf,
					     flags,
					     (IFX_OUT uint32 *) & outFlag,
					     sValue) != IFX_SUCCESS) {
						COPY_TO_STATUS("%s",
							       "Internal configuration error. Please validate user inputs and try again.");
						ifx_httpdRedirect(wp,
								  "err_page.html");
#ifdef IFX_LOG_DEBUG
						IFX_DBG
						    ("[%s:%d] Form Name=Value buffer Fail",
						     __FUNCTION__, __LINE__);
#endif
						return IFX_FAILURE;
					}
#endif

	                                if (type == 1 ) {
        	                                snprintf(buf, sizeof(buf), "wanppp_%d_linkType", wan_sixrdwanidxl);
                	                        if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, flags, (IFX_OUT uint32 *)&outFlag, 
							sValue) != IFX_SUCCESS) {
	                                                COPY_TO_STATUS("%s", "Internal configuration error. Please validate user inputs and try again.");
	                                                ifx_httpdRedirect(wp, "err_page.html");
#ifdef IFX_LOG_DEBUG
	                                                IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
#endif
	                                                return IFX_FAILURE;
        	                                }
                	                }
                        	        else {
                                	        snprintf(buf, sizeof(buf), "wanip_%d_linkType", wan_sixrdwanidxl);
	                                        if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags, (IFX_OUT uint32 *)&outFlag, 
							sValue) != IFX_SUCCESS) {
	                                                COPY_TO_STATUS("%s", "Internal configuration error. Please validate user inputs and try again.");
	                                                ifx_httpdRedirect(wp, "err_page.html");
#ifdef IFX_LOG_DEBUG
	                                                IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
#endif
	                                                return IFX_FAILURE;
        	                                }
                	                }

					if ((!strcmp(sValue, "4") ) || (!strcmp(sValue, "7"))) {
						sValue[0] = '\0';
						snprintf(buf, sizeof(buf),
							 "wan_sixrd_mode");
						if (ifx_GetObjData
						    (FILE_RC_CONF, TAG_IPV6,
						     buf, flags,
						     (IFX_OUT uint32 *) &
						     outFlag,
						     sValue) != IFX_SUCCESS) {
							COPY_TO_STATUS("%s",
								       "Internal configuration error. Please validate user inputs and try again.");
							ifx_httpdRedirect(wp,
									  "err_page.html");
#ifdef IFX_LOG_DEBUG
							IFX_DBG
							    ("[%s:%d] Form Name=Value buffer Fail",
							     __FUNCTION__,
							     __LINE__);
#endif
							return IFX_FAILURE;
						}
						if (!strcmp(sValue, "0")) {
							if (type != 1)
								snprintf(buf, sizeof(buf), "/etc/rc.d/6rdtunnel.sh wan_restart %d %s", wan_sixrdwanidxl, "ip");
							else
								snprintf(buf, sizeof(buf), "/etc/rc.d/6rdtunnel.sh wan_restart %d %s", wan_sixrdwanidxl, "ppp");
							
							system(buf);
						}
					}
					snprintf(buf, sizeof(buf),
						 "wan_sixrd_mtu=\"0\"\n");
					if (ifx_SetObjData
					    (FILE_RC_CONF, TAG_IPV6, flags, 1,
					     buf) != IFX_SUCCESS) {
						COPY_TO_STATUS("%s",
							       "Internal configuration error. Please validate user inputs and try again.");
						ifx_httpdRedirect(wp,
								  "err_page.html");
#ifdef IFX_LOG_DEBUG
						IFX_DBG
						    ("[%s:%d] Form Name=Value buffer Fail",
						     __FUNCTION__, __LINE__);
#endif
						return IFX_FAILURE;
					}
				}
			}
		}
		//save settings
		if (ifx_flash_write() <= 0) {
			COPY_TO_STATUS("%s",
				       "Failed to save settings. Please validate user inputs and try again.")
			    ifx_httpdRedirect(wp, "err_page.html");
			return IFX_FAILURE;
		}
	}
      IFX_Handler:
	websNextPage(wp);
	return IFX_SUCCESS;
}

int evalute_tunnel_intf_addr(char *wan_sixrdprefix, char *wan_sixrdbrip,
			     char *wan_sixrdmasklen, char *wan_sixrdprefixlen)
{
	uint8_t addr_ipv6[64];
	struct in_addr ipv4_dst_str;
	struct in6_addr ipv6_dst_addr;
	int ret;
	int ipv4masklen;
	int prefixlen;
	int ret_ipv4;

	ret = inet_pton(AF_INET6, wan_sixrdprefix, &ipv6_dst_addr);
	if (ret <= 0) {
                snprintf((char *)addr_ipv6, sizeof(addr_ipv6), "%s::", wan_sixrdprefix);
#if 0
		strncpy((char *)addr_ipv6, wan_sixrdprefix,
			sizeof(addr_ipv6) - 2);
		strcat((char *)addr_ipv6, "::");
#endif
		ret = inet_pton(AF_INET6, (char *)addr_ipv6, &ipv6_dst_addr);
		if (ret <= 0)
			return 1;
	}
	ipv4masklen = atoi(wan_sixrdmasklen);
	prefixlen = atoi(wan_sixrdprefixlen);
	ret_ipv4 = inet_pton(AF_INET, wan_sixrdbrip, &ipv4_dst_str);
	if (ret_ipv4 <= 0) {
		return 2;
	}
	if ((prefixlen + (32 - ipv4masklen)) > 64) {
		return 3;
	}
	if (((prefixlen - 1) / 32) >= 2) {
		return 4;
	}
	return 0;
}

int32 ifx_set_dslite(httpd_t wp, char_t * path, char_t * query)	//(int32 status, uint32 flags)
{
	int ret_dslite_tunnel;
	int ret = IFX_SUCCESS;
	char_t *pCheck_dslite;
	int	wantype=0;	/*0 = ppp , 1= ip */
	a_assert(wp);
	pCheck_dslite = ifx_httpdGetVar(wp, T("dslite"), T(""));
        uint32 wan_dslitewanidx=-1;
	char_t *dslitemode = ifx_httpdGetVar(wp, T("INTRF_DSLITE"), T(""));
	char_t *dslite_remoteipv6 =
	    ifx_httpdGetVar(wp, T("DSLITEREMOTEIPv6"), T(""));
	char_t *dslite_tunip = ifx_httpdGetVar(wp, T("DSLITETUNIP"), T(""));
	char_t *dslite_mask = ifx_httpdGetVar(wp, T("DSLITEMASK"), T(""));
	char_t *dslite_portrange = ifx_httpdGetVar(wp, T("PORTRANGE"), T(""));
	char_t *wandsliteidx =
	    ifx_httpdGetVar(wp, T("INTRF_WAN_DSLITE"), T(""));
	char_t *wandslite_mtu = ifx_httpdGetVar(wp, T("MTU_DSLITE"), T(""));
	if (wandslite_mtu == NULL) {
		COPY_TO_STATUS("%s",
			       "1 Internal configuration error. Please validate user inputs and try again.");
		ifx_httpdRedirect(wp, "err_page.html");
		return ret;
	}
	if (wandsliteidx == NULL) {
		COPY_TO_STATUS("%s",
			       "Please select a valid wan interface and then try again");
		ifx_httpdRedirect(wp, "err_page.html");
		return -1;
	}
	if(strstr(wandsliteidx, "PPP")) {
	       	wan_dslitewanidx=atoi(&wandsliteidx[6]);
		wantype = 0;	/* PPP */
	} else if (strstr(wandsliteidx, "IP")) {
	       	wan_dslitewanidx=atoi(&wandsliteidx[5]);
		wantype = 1;	/* IP */
	} else {
                COPY_TO_STATUS("%s", "Invalid parameter received. Please validate user inputs and try again.");
                ifx_httpdRedirect(wp, "err_page.html");
		return -1;
	}
	if(strlen(wandsliteidx) >= 9) {
                COPY_TO_STATUS("%s", "Invalid parameter received. Please validate user inputs and try again.");
                ifx_httpdRedirect(wp, "err_page.html");
		return IFX_FAILURE;
	}
	
       	if (wantype != -1) {
               ret_dslite_tunnel=set_dslite_parameters(wan_dslitewanidx, pCheck_dslite, dslitemode, dslite_remoteipv6, 
				dslite_tunip, dslite_mask, wandslite_mtu, wantype, wandsliteidx, dslite_portrange);

		syslog(0, "set_dslite_parameters returned %d\n", ret_dslite_tunnel);
		syslog(0, "pCheck_dslite returned %s\n", pCheck_dslite);
		switch (ret_dslite_tunnel) {
		case 1:
			COPY_TO_STATUS("%s",
				       "Internal configuration error. Please validate user inputs and try again.");
			ifx_httpdRedirect(wp, "err_page.html");
			return IFX_FAILURE;
		case 2:
			COPY_TO_STATUS("%s",
				       "Error: Couldn't get wan mode of the selected wan interface. Please validate user inputs and try again.");
			ifx_httpdRedirect(wp, "err_page.html");
			return -1;
		case 3:
			COPY_TO_STATUS("%s",
				       "Error: Couldn't get courrent wan mode. Please validate user inputs and try again.");
			ifx_httpdRedirect(wp, "err_page.html");
			return -1;
		case 4:
			COPY_TO_STATUS("%s", create_dslite_tunnel_err);
			ifx_httpdRedirect(wp, "err_page.html");
			return -1;
		case 5:
			COPY_TO_STATUS("%s",
				       create_dslite_tunnel_pwan_ipv6_err);
			ifx_httpdRedirect(wp, "err_page.html");
			return -1;
		case 6:
			COPY_TO_STATUS("%s",
				       "Please select a valid configuration mode and then try again");
			ifx_httpdRedirect(wp, "err_page.html");
			return -1;
		case 7:
			COPY_TO_STATUS("%s",
				       "Please put a valid DS-Lite Remote IPv6 address and then try again");
			ifx_httpdRedirect(wp, "err_page.html");
			return -1;
		case 8:
			COPY_TO_STATUS("%s",
				       "Please put a valid DS-Lite tunnel IP address(IPv4) and then try again");
			ifx_httpdRedirect(wp, "err_page.html");
			return -1;
		case 9:
			COPY_TO_STATUS("%s",
				       "Please put a valid Subnet Mask of the tunnel interface address and then try again");
			ifx_httpdRedirect(wp, "err_page.html");
			return -1;
		case 10:
			COPY_TO_STATUS("%s",
				       "Invalid DS-Lite Remote IPv6 address. Please put correct DS-Lite Remote IPv6 address and then try again.");
			ifx_httpdRedirect(wp, "err_page.html");
			return -1;
		case 11:
			COPY_TO_STATUS("%s",
				       "Invalid DS-Lite tunnel IP address(IPv4). Please put correct DS-Lite tunnel IP address(IPv4) and then try again.");
			ifx_httpdRedirect(wp, "err_page.html");
			return -1;
		case 12:
			COPY_TO_STATUS("%s",
				       "Invalid Subnet Mask. Please put a valid Subnet Mask of the tunnel interface address and then try again.");
			ifx_httpdRedirect(wp, "err_page.html");
			return -1;
		case 65280:
		case 256:
			printf("300.....%d  ....%d\n", sizeof(int),
			       ret_dslite_tunnel);
			COPY_TO_STATUS("%s",
				       "Internal configuration error. Please validate user inputs and try again.");
			ifx_httpdRedirect(wp, "err_page.html");
			return -1;
		case 512:
			//COPY_TO_STATUS("%s",
			//	       "Remote address matches with the prefix of another WAN Connection. Please validate user inputs and try again.");
			COPY_TO_STATUS("%s",
				       "Please validate user inputs and try again.");
			ifx_httpdRedirect(wp, "err_page.html");
			return -1;
		case 768:
			COPY_TO_STATUS("%s",
				       "IPv6 address is not configured on that interface or Worng remote address(Link local address) or remote address matches with the prefix of another WAN connection. Please validate user input and try again");
			ifx_httpdRedirect(wp, "err_page.html");
			return -1;
		case 1024:
			COPY_TO_STATUS("%s",
				       "Invalid WAN index. Please validate user input and try again");
			ifx_httpdRedirect(wp, "err_page.html");
			return -1;
		case 1280:
			COPY_TO_STATUS("%s",
				       "Invalid Ds-lite remote ipv6 address. Please validate inpute and try again");
			ifx_httpdRedirect(wp, "err_page.html");
			return -1;
		}

		if (ret_dslite_tunnel != 0) {
			printf("100.......%d\n", ret_dslite_tunnel);
			COPY_TO_STATUS("%s",
				       "Internal configuration error. Please validate user inputs and try again.");
			ifx_httpdRedirect(wp, "err_page.html");
			return -1;
		}
		//save settings
		if (ifx_flash_write() <= 0) {
			COPY_TO_STATUS("%s",
				       "Failed to save settings. Please validate user inputs and try again.")
			    ifx_httpdRedirect(wp, "err_page.html");
			return IFX_FAILURE;
		}

		/* Call dslite dhcp6c restart script if wan_mode is dynamic */
		if((atoi(dslitemode) == 1) || (atoi(dslitemode) == 3)) {
			char  buf[300];
			snprintf(buf, sizeof(buf),
					"/etc/rc.d/ds-lite.sh dhcp6c_restart %s %d %s",
					wandsliteidx, wan_dslitewanidx, wantype?"ip":"ppp"); 
			system(buf); 
		}
	}
      IFX_Handler:
	websNextPage(wp);
	return IFX_SUCCESS;
}

#endif

#ifdef CONFIG_FEATURE_IPv6
int ifx_get_IPv6Status(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 ret = IFX_SUCCESS, outFlag = IFX_F_DEFAULT, flags = IFX_F_DEFAULT;
	char8 sValue[MAX_FILELINE_LEN];

	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_IPV6, "ipv6_status", flags,
			    (IFX_OUT uint32 *) & outFlag,
			    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	} else {
		ifx_httpdWrite(wp, T("%d"), atoi(sValue));
	}

	return 0;
}

int ifx_get_glob_IPv6()
{
	int32 ret = IFX_SUCCESS, outFlag = IFX_F_DEFAULT, flags = IFX_F_DEFAULT;
	char8 sValue[MAX_FILELINE_LEN];

	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_IPV6, "ipv6_status", flags,
			    (IFX_OUT uint32 *) & outFlag,
			    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return  0;
	} else {
		return atoi(sValue);
	}
}



#else
int ifx_get_IPv6Status(int eid, httpd_t wp, int argc, char_t ** argv)
{
#ifdef CONFIG_FEATURE_IPv6
	ifx_httpdWrite(wp, T("1"));
#else
	ifx_httpdWrite(wp, T("0"));
#endif
	return 0;
}
#endif				// CONFIG_FEATURE_IPv6

#ifdef CONFIG_FEATURE_IPv6
/* This API will return either lan ipv6 parameters (only one value at a time)*/
int ifx_get_lan_IPV6(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int ret = IFX_SUCCESS, count = 0, i = 0;
	char ip[MAX_IP_ADDR_LEN], prefix[MAX_IP_ADDR_LEN];
	LAN_IPv6_SL_Config *ip_array_type;
	IP6_ADDR_STRING addrconf;
	uint32 flags = IFX_F_DEFAULT;
	uint32 outFlag = IFX_F_DEFAULT;
	char_t sValue[MAX_FILELINE_LEN], *name;
	int32 lan_ipv6_mode = 1;

	IFX_DBG("ifx_get_lan_IPV6 [%s:%d]", __FUNCTION__, __LINE__);

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	ip[0] = '\0';
	prefix[0] = '\0';
	//mask[0]='\0';

	ret =
	    ifx_get_lan_ipv6("br0", &count, &ip_array_type, &addrconf,
			     &lan_ipv6_mode, flags);

	if ((ret == IFX_SUCCESS)) {

		if (!gstrcmp(name, "cpeId")) {
			ifx_httpdWrite(wp, T("%d"), (addrconf).iid.cpeId.Id);
		} else if (!gstrcmp(name, "pcpeId")) {
			ifx_httpdWrite(wp, T("%d"), (addrconf).iid.pcpeId.Id);
		} else {
			for (i = 0; i < count; i++) {
				sValue[0] = '\0';

				inet_ntop(AF_INET6, &(addrconf).ip, ip, 46);
				inet_ntop(AF_INET6,
					  &(ip_array_type + i)->ip6Addr.ip,
					  prefix, 46);

				if (!gstrcmp(name, T("address"))) {
					ifx_httpdWrite(wp, T("%s"), ip);
				}
				if (!gstrcmp(name, T("pre_len"))) {
					ifx_httpdWrite(wp, T("%d"),
						       (addrconf).prefix_len);
				}
				if (!gstrcmp(name, T("prefix"))) {
					ifx_httpdWrite(wp, T("%s"), prefix);
				}
				if (!gstrcmp(name, T("rpre_len"))) {
					ifx_httpdWrite(wp, T("%d"),
						       (ip_array_type +
							i)->ip6Addr.prefix_len);
				}
				if (!gstrcmp(name, T("mode"))) {
					ifx_httpdWrite(wp, T("%d"),
						       lan_ipv6_mode);
				}
			}
			IFX_MEM_FREE(ip_array_type)
		}
		memset(sValue, 0, sizeof(sValue));
		if (!gstrcmp(name, "d6saddr_1")) {

			if ((ret =
			     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCP6S_IPV6,
					    "lan_dhcpv6_dnsv6Addr", flags,
					    &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			} else
				ifx_httpdWrite(wp, T("%s"), sValue);
		} else if (!gstrcmp(name, "d6saddr_2")) {

			if ((ret =
			     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCP6S_IPV6,
					    "lan_dhcpv6_dnsv6SecAddr", flags,
					    &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			} else
				ifx_httpdWrite(wp, T("%s"), sValue);

		} else if (!gstrcmp(name, "d6sname")) {
			sValue[0] = '\0';
			if ((ret =
			     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCP6S_IPV6,
					    "lan_dhcpv6_dName", flags, &outFlag,
					    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			} else
				ifx_httpdWrite(wp, T("%s"), sValue);
		} else if (!gstrcmp(name, "route")) {
			sValue[0] = '\0';
			if ((ret =
			     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_RADVD_IPV6,
					    "lan_radvd_gw6addr", flags,
					    &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			} else
				ifx_httpdWrite(wp, T("%s"), sValue);
		} else if (!gstrcmp(name, "rdns6_1")) {
			sValue[0] = '\0';
			if ((ret =
			     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_RADVD_IPV6,
					    "lan_radvd_dnsv6Addr", flags,
					    &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			} else
				ifx_httpdWrite(wp, T("%s"), sValue);
		} else if (!gstrcmp(name, "rdns6_2")) {
			sValue[0] = '\0';
			if ((ret =
			     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_RADVD_IPV6,
					    "lan_radvd_dnsv6SecAddr", flags,
					    &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			} else
				ifx_httpdWrite(wp, T("%s"), sValue);
		} else if (!gstrcmp(name, "d6start_addr")) {
			sValue[0] = '\0';
			if ((ret =
			     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCP6S_IPV6,
					    "lan_dhcpv6_sAddr", flags, &outFlag,
					    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			} else
				ifx_httpdWrite(wp, T("%s"), sValue);

		} else if (!gstrcmp(name, "d6end_addr")) {
			sValue[0] = '\0';
			if ((ret =
			     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCP6S_IPV6,
					    "lan_dhcpv6_eAddr", flags, &outFlag,
					    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			} else
				ifx_httpdWrite(wp, T("%s"), sValue);
		} else if (!gstrcmp(name, "d6pre_len")) {
			sValue[0] = '\0';
			if ((ret =
			     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_DHCP6S_IPV6,
					    "lan_dhcpv6_prelen", flags,
					    &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			} else
				ifx_httpdWrite(wp, T("%s"), sValue);
		}
		IFX_MEM_FREE(ip_array_type)
	}
      IFX_Handler:
	IFX_MEM_FREE(ip_array_type)
	    return 0;
}

int ifx_get_ipv6_interface_prefix(int eid, httpd_t wp, int argc,
				  char_t ** arg_v)
{
	FILE *fp;
	char buf1[10] = { 0 };
	char buf2[64] = { 0 };
	fp = fopen("/var/radvd_pd", "r");
	if (fp == NULL) {
		IFX_DBG("[%s:%d] failed ro read the file /var/radvd_pd",
			__FUNCTION__, __LINE__);
		return -1;
	}
	while (!feof(fp)) {
		memset(buf1, 0, 10);
		memset(buf2, 0, 64);
		fscanf(fp, "%[^ ] %[^\n]\n", buf1, buf2);
		if (strlen(buf1) == 0 || strlen(buf2) == 0)
			continue;
		ifx_httpdWrite(wp, T("<tr align=center>"));
		ifx_httpdWrite(wp,
			       T
			       ("<td class=\"subtitle\" width=\"20%\" nowrap colspan=\"1\"><font size=\"2\">&nbsp;%s</font></td>"),
			       buf1);
		ifx_httpdWrite(wp,
			       T
			       ("<td class=\"subtitle\" width=\"20%\" nowrap colspan=\"1\"><font size=\"2\">&nbsp;%s</font></td>"),
			       buf2);
		ifx_httpdWrite(wp, T("</TR>\n"));
	}
	fclose(fp);
	return IFX_SUCCESS;
}

int ifx_get_lan_table_ipv6(int eid, httpd_t wp, int argc, char_t ** arg_v)
{
	FILE *fp;
	char_t dest[128], hop[128], iface[MAX_FILELINE_LEN], flags[8];
	char_t metric[8], ref[8], use[8];
	int count = 0;
	char ptr[256] = { 0 };
	int line_size = 256;
	system("route -A inet6 -n > /tmp/route_details");
	fp = fopen("/tmp/route_details", "r");
	if (fp == NULL) {
		IFX_DBG("[%s:%d] failed ro read the file /tmp/route_details",
			__FUNCTION__, __LINE__);
		return -1;
	}
	while (!feof(fp)) {
		memset(dest, 0, 128);
		memset(hop, 0, 128);
		memset(flags, 0, 8);
		memset(metric, 0, 8);
		memset(ref, 0, 8);
		memset(use, 0, 8);
		memset(iface, 0, MAX_FILELINE_LEN);
		if (count < 2) {
			fgets(ptr, line_size, fp);
			count++;
			continue;
		}
		fscanf(fp, "%[^ ] %[^ ] %[^ ] %[^ ] %[^ ] %[^ ] %[^\n]\n", dest, hop, flags, metric,
		       ref, use, iface);
		if (strlen(dest) == 0 || strlen(hop) == 0 || strlen(iface) == 0) {
			continue;
		}
		IFX_DBG("[%s:%d] %s %s %s %s %s %s %s", __FUNCTION__, __LINE__,
			dest, hop, flags, metric, ref, use, iface);
		ifx_httpdWrite(wp, T("\t\t<tr>\n"));
		ifx_httpdWrite(wp, T("\t\t\t<td>%s</td>\n"), dest);
		ifx_httpdWrite(wp, T("\t\t\t<td>%s</td>\n"), hop);
		ifx_httpdWrite(wp, T("\t\t\t<td>%s</td>\n"), metric);
		ifx_httpdWrite(wp, T("\t\t\t<td>%s</td>\n"), iface);
		ifx_httpdWrite(wp, T("\t\t</tr>\n"));
	}
	fclose(fp);
	system("rm -rf /tmp/route_details");
	return IFX_SUCCESS;
}

int
ifx_get_lan_ipv6_addr(int eid, httpd_t wp, int argc, char_t ** arg_v)
{
    FILE *fp_ad;
    char_t ip6adr[128], addr_scope[10];
    int ret;

    system("ip -6 addr show dev br0 | grep inet6 | cut -d \" \" -f6,8 > /tmp/lan_ipv6_addr_status");

    fp_ad = fopen("/tmp/lan_ipv6_addr_status", "r");
    if(fp_ad == NULL) {
        IFX_DBG("[%s:%d] failed to read the file ",
                __FUNCTION__, __LINE__);
        return -1;
    }

    while(!feof(fp_ad)) {
        memset(ip6adr, 0, 128);
        memset(addr_scope, 0, 10);
        ret = 0;

        ret = fscanf(fp_ad, "%[^ ] %[^\n]\n", ip6adr, addr_scope );
        if(strlen(ip6adr) == 0 || strlen(addr_scope) == 0 ) {
            continue;
        }

        if (ret != 0) {
                IFX_DBG("[%s:%d] %s %s %d", __FUNCTION__, __LINE__, ip6adr, addr_scope, ret);
                ifx_httpdWrite(wp, T("\t\t<tr>\n"));
                ifx_httpdWrite(wp, T("\t\t\t<td>%s</td>\n"), "br0");
                ifx_httpdWrite(wp, T("\t\t\t<td>%s</td>\n"), ip6adr);
                ifx_httpdWrite(wp, T("\t\t\t<td>%s</td>\n"), addr_scope);
                ifx_httpdWrite(wp, T("\t\t</tr>\n"));
        }
    }
    fclose(fp_ad);
    system("rm -rf /tmp/lan_ipv6_addr_status");
    return IFX_SUCCESS;
}

#endif				/* #ifdef CONFIG_FEATURE_IPv6 */

#ifdef CONFIG_FEATURE_LTQ_WIRELESS_VB
int ltq_get_eth_phy_cfg(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name = NULL;
	int i = 0;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_eth_phy_cfg", "g_vbEthPhyCount: %d",
		       g_vbEthPhyCount);
	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return IFX_FAILURE;
	}

	if (!gstrcmp(name, T("vb_eth_phy_port"))) {
		ifx_httpdWrite(wp,
			       T
			       ("<select name='ethPort' onChange='updatePage();'>"));
		for (i = 0; i < g_vbEthPhyCount; i++) {
			if (!strcmp(g_vbEthPhyConfig[i].ephyName, "eth0")) {
				ifx_httpdWrite(wp,
					       T
					       ("<option value='%d' selected >Port-0\n"),
					       i);
			} else
			    if (!strcmp(g_vbEthPhyConfig[i].ephyName, "eth1")) {
				ifx_httpdWrite(wp,
					       T
					       ("<option value='%d' selected >Port-1\n"),
					       i);
			} else {
				ifx_httpdWrite(wp,
					       T
					       ("<option value='%d' selected >Port-%d\n"),
					       i, i);
			}
		}
		ifx_httpdWrite(wp, T("</select"));
	} else if (!gstrcmp(name, T("vb_eth_phy_flowCntrl"))) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_eth_phy_cfg",
			       "flow control: %d",
			       g_vbEthPhyConfig[0].ephyFlowControlEna);
		if (g_vbEthPhyConfig[0].ephyFlowControlEna == 1)
			ifx_httpdWrite(wp, T("%s"), "checked");
		else
			ifx_httpdWrite(wp, T("%s"), "");

	} else if (!gstrcmp(name, T("vb_eth_phy_maxBitRate"))) {
		ifx_httpdWrite(wp,
			       T("<option value=\"2\" %s>1000Mbit/s</option>"),
			       g_vbEthPhyConfig[0].ephySpeed ==
			       2 ? "selected" : "");
		ifx_httpdWrite(wp,
			       T("<option value=\"1\" %s>100Mbit/s</option>"),
			       g_vbEthPhyConfig[0].ephySpeed ==
			       1 ? "selected" : "");
#if 0
		ifx_httpdWrite(wp,
			       T("<option value=\"3\" %s>10Gbit/s</option>"),
			       g_vbEthPhyConfig[0].ephySpeed ==
			       3 ? "selected" : "");
		ifx_httpdWrite(wp, T("<option value=\"0\" %s>Auto</option>"),
			       g_vbEthPhyConfig[0].ephySpeed ==
			       0 ? "selected" : "");
#endif
	} else if (!gstrcmp(name, T("vb_eth_phy_duplxMode"))) {
		ifx_httpdWrite(wp, T("<option value=\"0\" %s>AUTO</option>"),
			       g_vbEthPhyConfig[0].ephyDuplxMode ==
			       LTQ_MAPI_VB_ETH_PHY_DUPLEX_MODE_AUTO ? "selected"
			       : "");
		ifx_httpdWrite(wp,
			       T("<option value=\"1\" %s>Full Duplex</option>"),
			       g_vbEthPhyConfig[0].ephyDuplxMode ==
			       LTQ_MAPI_VB_ETH_PHY_DUPLEX_MODE_FULL ? "selected"
			       : "");
		ifx_httpdWrite(wp,
			       T("<option value=\"2\" %s>Half Duplex</option>"),
			       g_vbEthPhyConfig[0].ephyDuplxMode ==
			       LTQ_MAPI_VB_ETH_PHY_DUPLEX_MODE_HALF ? "selected"
			       : "");
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_eth_phy_cfg", "");
	return IFX_SUCCESS;
}

void ltq_set_eth_phy_cfg(httpd_t wp, char_t * path, char_t * query)
{
	LTQ_MAPI_VB_ETH_PHY_Cfg vbEthPhyConfig;
	char8 *pValue;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_eth_phy_cfg", "");

	memset(&vbEthPhyConfig, 0, sizeof(LTQ_MAPI_VB_ETH_PHY_Cfg));
	sprintf(vbEthPhyConfig.iid.cpeId.secName, "%s", TAG_VB_ETH_PHY);
	vbEthPhyConfig.iid.cpeId.Id = 1;
	vbEthPhyConfig.iid.config_owner = IFX_WEB;

	if (ltq_mapi_get_vb_eth_phy_config(&vbEthPhyConfig, IFX_F_DEFAULT) !=
	    IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to get eth phy port config");
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_eth_phy_cfg", "");
		return;
	}

	pValue = ifx_httpdGetVar(wp, T("vb_eth_phy_flowCntrl"), T(""));
	vbEthPhyConfig.ephyFlowControlEna = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_eth_phy_cfg",
		       "EPHY: Flow control mode: %d",
		       vbEthPhyConfig.ephyFlowControlEna);

	pValue = ifx_httpdGetVar(wp, T("vb_eth_phy_maxBitRate"), T(""));
	vbEthPhyConfig.ephySpeed = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_eth_phy_cfg",
		       "EPHY: Speed: %d", vbEthPhyConfig.ephySpeed);

	if (ltq_mapi_set_vb_eth_phy_config
	    (IFX_OP_MOD, &vbEthPhyConfig, IFX_F_MODIFY) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_eth_phy_cfg", "");
		ifx_httpdError(wp, 400, "Failed to set eth pyh port config");
		return;
	}

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_eth_phy_cfg", "");
	websNextPage(wp);
	return;
}
#endif				/* #ifdef CONFIG_FEATURE_LTQ_WIRELESS_VB */

/*manohar: Get CGI for the webredirector */
int ifx_get_lan_ip_host_list(int eid, httpd_t wp, int argc, char_t ** argv)
{
#ifdef CONFIG_FEATURE_WEB_REDIRECTOR
	uint numHost = 0, i = 0;
	uint32 Flags = IFX_F_DEFAULT;
	LTQ_MAPI_LAN_IP_Host *ipHost = NULL;
	if (ltq_mapi_get_all_lan_ip_host(&numHost, &ipHost, Flags) !=
			IFX_SUCCESS) {
		IFX_DBG("[%s:%d] Failed", __FUNCTION__, __LINE__);
		IFX_MEM_FREE(ipHost);
		return IFX_FAILURE;
	}
	for (i = 0; i < numHost; i++) {
		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td id=\"host_mac_add_%d\">%s</td>"),i + 1, (ipHost + i)->macAddr);
		ifx_httpdWrite(wp, T("<td id=\"host_ip_add_%d\">%s</td>"),i + 1, (ipHost + i)->ip4Addr);
		if((ipHost + i)->webSrvr == 1)
			ifx_httpdWrite(wp,T("<td id=\"manage_%d\"><a class=\"button\" href=\"javascript:void(0);\" onClick=\"window.open('http://%s');\">Manage</a></td>"),i + 1, (ipHost + i)->ip4Addr);
		else
			ifx_httpdWrite(wp,T("<td></td>"));
			
		ifx_httpdWrite(wp, T("</tr>"));
	}
	IFX_MEM_FREE(ipHost);
#endif
	return IFX_SUCCESS;
}
/*manohar end*/
