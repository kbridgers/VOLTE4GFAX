//#include <sys/syslog.h>
//#include <ifx_emf.h>
//#include "ifx_httpd_method.h"
//#include <signal.h>
//#include <unistd.h>
//#include <sys/types.h>
//#include <sys/wait.h>
//#include <ifx_common.h>
//#include "./ifx_amazon_cgi.h"
//#include "./ifx_amazon_cgi_getFunctions.h"
//#include "ifx_snmp_api.h"
//#include "ifx_api_ipt_common.h"
//#include <sys/ioctl.h>
#ifdef CONFIG_FEATURE_IFX_VOIP
//#include "ifx_basic_types.h"
//#include "ifx_voip_defs.h"
//#include "ifx_cm.h"
//#include "ifx_ipc.h"
#endif

#ifdef CONFIG_FEATURE_IFX_VOIP
int ifx_get_currentaddr_UserManagementOptions(int eid, httpd_t wp, int argc,
					      char_t ** argv);
int ifx_get_currentuserfreez_UserManagementOptions(int eid, httpd_t wp,
						   int argc, char_t ** argv);
void ifx_get_currentUser_authority(int eid, httpd_t wp, int argc,
				   char_t ** argv);
int ifx_get_currentgw_UserManagementOptions(int eid, httpd_t wp, int argc,
					    char_t ** argv);
int ifx_get_currentjb_UserManagementOptions(int eid, httpd_t wp, int argc,
					    char_t ** argv);
int ifx_get_currentother_UserManagementOptions(int eid, httpd_t wp, int argc,
					       char_t ** argv);
int ifx_get_voip_fwd(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_currentphone_UserManagementOptions(int eid, httpd_t wp, int argc,
					       char_t ** argv);
int ifx_get_currentproxy_UserManagementOptions(int eid, httpd_t wp, int argc,
					       char_t ** argv);
int ifx_get_currentreg_UserManagementOptions(int eid, httpd_t wp, int argc,
					     char_t ** argv);
int ifx_get_currentrm_UserManagementOptions(int eid, httpd_t wp, int argc,
					    char_t ** argv);
int ifx_get_currentteluri_UserManagementOptions(int eid, httpd_t wp, int argc,
						char_t ** argv);
int ifx_get_currentsipuser_UserManagementOptions(int eid, httpd_t wp, int argc,
						 char_t ** argv);
int adm_get_currentUser_authority(int eid, httpd_t wp, int argc,
				  char_t ** argv);
int adm_get_currentUser_UserManagementOptions(int eid, httpd_t wp, int argc,
					      char_t ** argv);
#endif
#ifdef CONFIG_FEATURE_IFX_VOIP
int g_nCurrentUserLevel;	//0:admin,1:common user,2:general user
#endif

#ifdef CONFIG_FEATURE_IFX_VOIP
void ifx_set_voip_portset(httpd_t wp, char_t * path, char_t * query);	//voip_portset.htm
void ifx_set_voip_sipset(httpd_t wp, char_t * path, char_t * query);	//voip_sipset.htm
#endif				//CONFIG_FEATURE_IFX_VOIP

#ifdef CONFIG_FEATURE_IFX_VOIP
//voip_portset.htm
void ifx_set_voip_portset(httpd_t wp, char_t * path, char_t * query)
{
	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}

	websNextPage(wp);
}

void ifx_set_voip_sipset(httpd_t wp, char_t * path, char_t * query)
{

	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}
	//<<add_code_here
	//>>

	websNextPage(wp);
}
#endif				//CONFIG_FEATURE_IFX_VOIP
