#include <ifx_emf.h>
#include "ifx_httpd_method.h"
#include "./ifx_amazon_cgi.h"
#include "./ifx_cgi_common.h"

extern int ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);
extern void websNextPage(httpd_t wp);

#ifdef CONFIG_FEATURE_FIREWALL
#ifdef IFX_DOS_ENABLE
void ifx_set_dos_main(httpd_t wp, char_t * path, char_t * query);
void ifx_set_dos_applications(httpd_t wp, char_t * path, char_t * query);
void ifx_set_dos_scans(httpd_t wp, char_t * path, char_t * query);
void ifx_set_dos_networking(httpd_t wp, char_t * path, char_t * query);
#endif
#endif

#ifdef IFX_DOS_ENABLE
void ifx_set_dos_applications(httpd_t wp, char_t * path, char_t * query);
void ifx_set_dos_scans(httpd_t wp, char_t * path, char_t * query);
void ifx_set_dos_networking(httpd_t wp, char_t * path, char_t * query);
#endif

void ifx_set_dos_main(httpd_t wp, char_t * path, char_t * query);

#ifdef CONFIG_FEATURE_FIREWALL
#ifdef IFX_DOS_ENABLE
void ifx_set_dos_main(httpd_t wp, char_t * path, char_t * query)
{
	char_t *buffer = NULL;
	char_t *pCheck = NULL, sCheck[MAX_WEB_DATA];
	char_t sParams[][32] = {
		"DOS_ENABLE",
		"PING_FORWARD",
		"PING_GW"
	};
	int i = 0;
	char_t
	    sCommand[(sizeof(sParams) / (32 * sizeof(char_t)))][MAX_DATA_LEN];

	a_assert(wp);
	sCheck[0] = '\0';

	buffer = (char_t *) malloc(sizeof(char_t) * (BUF_SIZE_50K));
	gstrcpy(buffer, "");

	for (i = 0; i < sizeof(sParams) / (32 * sizeof(char_t)); i++) {
		// Get value from ASP filz
		pCheck = ifx_httpdGetVar(wp, sParams[i], T(""));
		if (!gstrcmp(pCheck, "1")) {
			gsprintf(sCheck, T("%s=\"1\"\n"), sParams[i]);
			sprintf(sCommand[i], "%s --%s 1\n", NAPTCFG,
				sParams[i]);
		} else {
			gsprintf(sCheck, T("%s=\"0\"\n"), sParams[i]);
			sprintf(sCommand[i], "%s --%s 0\n", NAPTCFG,
				sParams[i]);
		}
		gstrcat(buffer, sCheck);
	}

	ifx_SetCfgData(FILE_RC_CONF, TAG_DOS_MAIN, 1, buffer);

	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}

	for (i = 0; i < sizeof(sParams) / (32 * sizeof(char_t)); i++) {
		system(sCommand[i]);
	}
	IFX_MEM_FREE(buffer);
	websNextPage(wp);
}

void ifx_set_dos_applications(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pHotsyncStatus, *pHotsyncPort;
	char_t *pYahooStatus, *pYahooPort;
	char_t *pMimeStatus, *pMimePort;
	char_t *pCodered2Status, *pWebPort, *pCoderedStatus, *pIcqStatus;

	char_t sHotsyncStatus[MAX_WEB_DATA], sHotsyncPort[MAX_WEB_DATA];
	char_t sYahooStatus[MAX_WEB_DATA], sYahooPort[MAX_WEB_DATA];
	char_t sMimeStatus[MAX_WEB_DATA], sMimePort[MAX_WEB_DATA];
	char_t sCodered2Status[MAX_WEB_DATA], sCoderedStatus[MAX_WEB_DATA],
	    sIcqStatus[MAX_WEB_DATA], sWebPort[MAX_WEB_DATA];
	char_t sOldHotsyncPort[MAX_WEB_DATA], sOldYahooPort[MAX_WEB_DATA],
	    sOldMimePort[MAX_WEB_DATA], sOldWebPort[MAX_WEB_DATA];
	char_t sValue[MAX_WEB_DATA];
	//Update Code Red II
	sCodered2Status[0] = '\0';
	sWebPort[0] = '\0';
	sOldWebPort[0] = '\0';
	pCodered2Status = ifx_httpdGetVar(wp, T("codered2_status"), T(""));	// Get value from ASP file
	pWebPort = ifx_httpdGetVar(wp, T("web_port"), T(""));	// Get value from ASP file
	if (!gstrcmp(pCodered2Status, "1"))
		gsprintf(sCodered2Status, T("CODERED2_STATUS=\"1\"\n"));
	else
		gsprintf(sCodered2Status, T("CODERED2_STATUS=\"0\"\n"));
	gsprintf(sWebPort, T("WEB_PORT=\"%s\"\n"), pWebPort);
	//to save same value in rc.conf as old
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_DOS_APPLICATIONS, T("WEB_PORT"), sValue) == 0) {
		strcpy(sValue, "0");
	}
	gsprintf(sOldWebPort, T("OLD_WEB_PORT=\"%s\"\n"), sValue);
	//Update Code Red
	sCoderedStatus[0] = '\0';
	pCoderedStatus = ifx_httpdGetVar(wp, T("codered_status"), T(""));	// Get value from ASP file
	if (!gstrcmp(pCoderedStatus, "1"))
		gsprintf(sCoderedStatus, T("CODERED_STATUS=\"1\"\n"));
	else
		gsprintf(sCoderedStatus, T("CODERED_STATUS=\"0\"\n"));
	//Update ICQ DoS
	sIcqStatus[0] = '\0';
	pIcqStatus = ifx_httpdGetVar(wp, T("icq_status"), T(""));	// Get value from ASP file
	if (!gstrcmp(pIcqStatus, "1"))
		gsprintf(sIcqStatus, T("ICQ_STATUS=\"1\"\n"));
	else
		gsprintf(sIcqStatus, T("ICQ_STATUS=\"0\"\n"));
	//Update HotSync Manager DoS
	sHotsyncStatus[0] = '\0';
	sHotsyncPort[0] = '\0';
	sOldHotsyncPort[0] = '\0';
	pHotsyncStatus = ifx_httpdGetVar(wp, T("hotsync_status"), T(""));	// Get value from ASP file
	pHotsyncPort = ifx_httpdGetVar(wp, T("hotsync_port"), T(""));	// Get value from ASP file
	if (!gstrcmp(pHotsyncStatus, "1"))
		gsprintf(sHotsyncStatus, T("HOTSYNC_STATUS=\"1\"\n"));
	else
		gsprintf(sHotsyncStatus, T("HOTSYNC_STATUS=\"0\"\n"));
	gsprintf(sHotsyncPort, T("HOTSYNC_PORT=\"%s\"\n"), pHotsyncPort);
	//to save same value in rc.conf as old
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_DOS_APPLICATIONS, T("HOTSYNC_PORT"),
	     sValue) == 0) {
		strcpy(sValue, "0");
	}
	gsprintf(sOldHotsyncPort, T("OLD_HOTSYNC_PORT=\"%s\"\n"), sValue);
	//Update Yahoo Messenger DoS
	sYahooStatus[0] = '\0';
	sYahooPort[0] = '\0';
	sOldYahooPort[0] = '\0';
	pYahooStatus = ifx_httpdGetVar(wp, T("yahoo_status"), T(""));	// Get value from ASP file
	pYahooPort = ifx_httpdGetVar(wp, T("yahoo_port"), T(""));	// Get value from ASP file
	if (!gstrcmp(pYahooStatus, "1"))
		gsprintf(sYahooStatus, T("YAHOO_STATUS=\"1\"\n"));
	else
		gsprintf(sYahooStatus, T("YAHOO_STATUS=\"0\"\n"));
	gsprintf(sYahooPort, T("YAHOO_PORT=\"%s\"\n"), pYahooPort);
	//to save same value in rc.conf as old
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_DOS_APPLICATIONS, T("YAHOO_PORT"),
	     sValue) == 0) {
		strcpy(sValue, "0");
	}
	gsprintf(sOldYahooPort, T("OLD_YAHOO_PORT=\"%s\"\n"), sValue);
	//Update Malformed MIME
	sMimeStatus[0] = '\0';
	sMimePort[0] = '\0';
	sOldMimePort[0] = '\0';
	pMimeStatus = ifx_httpdGetVar(wp, T("mime_status"), T(""));	// Get value from ASP file
	pMimePort = ifx_httpdGetVar(wp, T("mime_port"), T(""));	// Get value from ASP file
	if (!gstrcmp(pMimeStatus, "1"))
		gsprintf(sMimeStatus, T("MIME_STATUS=\"1\"\n"));
	else
		gsprintf(sMimeStatus, T("MIME_STATUS=\"0\"\n"));
	gsprintf(sMimePort, T("MIME_PORT=\"%s\"\n"), pMimePort);
	//to save same value in rc.conf as old
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_DOS_APPLICATIONS, T("MIME_PORT"), sValue) == 0) {
		strcpy(sValue, "0");
	}
	gsprintf(sOldMimePort, T("OLD_MIME_PORT=\"%s\"\n"), sValue);
	//Write to rc.conf
	ifx_SetCfgData(FILE_RC_CONF, TAG_DOS_APPLICATIONS, 14,
		       sHotsyncStatus, sHotsyncPort, sOldHotsyncPort,
		       sYahooStatus, sYahooPort, sOldYahooPort,
		       sMimeStatus, sMimePort, sOldMimePort,
		       sCodered2Status, sCoderedStatus, sIcqStatus, sWebPort,
		       sOldWebPort);
	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}
	system(SERVICE_FIREWALL_DOS_RESTART);
	websNextPage(wp);
}

void ifx_set_dos_scans(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pTcpsynfloodStatus, *pTcpsynfloodLimit, *pTcpsynfloodBurst;
	char_t *pPortscanStatus, *pLoportWeight, *pHiportWeight,
	    *pDelayThreshold, *pWeightThreshold;

	char_t sTcpsynfloodStatus[MAX_WEB_DATA],
	    sTcpsynfloodLimit[MAX_WEB_DATA], sTcpsynfloodBurst[MAX_WEB_DATA];
	char_t sPortscanStatus[MAX_WEB_DATA], sLoportWeight[MAX_WEB_DATA],
	    sHiportWeight[MAX_WEB_DATA], sDelayThreshold[MAX_WEB_DATA],
	    sWeightThreshold[MAX_WEB_DATA];
	//old values
	char_t sOldTcpsynfloodLimit[MAX_WEB_DATA],
	    sOldTcpsynfloodBurst[MAX_WEB_DATA], sOldLoportWeight[MAX_WEB_DATA],
	    sOldHiportWeight[MAX_WEB_DATA], sOldDelayThreshold[MAX_WEB_DATA],
	    sOldWeightThreshold[MAX_WEB_DATA];

	char_t sValue[MAX_WEB_DATA];
	//Update TCP Synflood
	sTcpsynfloodStatus[0] = '\0';
	sTcpsynfloodLimit[0] = '\0';
	sTcpsynfloodBurst[0] = '\0';
	sOldTcpsynfloodLimit[0] = '\0';
	sOldTcpsynfloodBurst[0] = '\0';
	pTcpsynfloodStatus = ifx_httpdGetVar(wp, T("tcpsynflood_status"), T(""));	// Get value from ASP file
	pTcpsynfloodLimit = ifx_httpdGetVar(wp, T("tcpsynflood_limit"), T(""));	// Get value from ASP file
	pTcpsynfloodBurst = ifx_httpdGetVar(wp, T("tcpsynflood_burst"), T(""));	// Get value from ASP file
	if (!gstrcmp(pTcpsynfloodStatus, "1"))
		gsprintf(sTcpsynfloodStatus, T("TCPSYNFLOOD_STATUS=\"1\"\n"));
	else
		gsprintf(sTcpsynfloodStatus, T("TCPSYNFLOOD_STATUS=\"0\"\n"));
	gsprintf(sTcpsynfloodLimit, T("TCPSYNFLOOD_LIMIT=\"%s\"\n"),
		 pTcpsynfloodLimit);
	gsprintf(sTcpsynfloodBurst, T("TCPSYNFLOOD_BURST=\"%s\"\n"),
		 pTcpsynfloodBurst);
	//Now save same value in rc.conf as old
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_DOS_SCANS, T("TCPSYNFLOOD_LIMIT"),
	     sValue) == 0) {
		strcpy(sValue, "0");
	}
	gsprintf(sOldTcpsynfloodLimit, T("OLD_TCPSYNFLOOD_LIMIT=\"%s\"\n"),
		 sValue);
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_DOS_SCANS, T("TCPSYNFLOOD_BURST"),
	     sValue) == 0) {
		strcpy(sValue, "0");
	}
	gsprintf(sOldTcpsynfloodBurst, T("OLD_TCPSYNFLOOD_BURST=\"%s\"\n"),
		 sValue);
	//Update Port Scan
	sPortscanStatus[0] = '\0';
	sLoportWeight[0] = '\0';
	sHiportWeight[0] = '\0';
	sDelayThreshold[0] = '\0';
	sWeightThreshold[0] = '\0';
	sOldLoportWeight[0] = '\0';
	sOldHiportWeight[0] = '\0';
	sOldDelayThreshold[0] = '\0';
	sOldWeightThreshold[0] = '\0';
	pPortscanStatus = ifx_httpdGetVar(wp, T("portscan_status"), T(""));	// Get value from ASP file
	pLoportWeight = ifx_httpdGetVar(wp, T("loport_weight"), T(""));	// Get value from ASP file
	pHiportWeight = ifx_httpdGetVar(wp, T("hiport_weight"), T(""));	// Get value from ASP file
	pDelayThreshold = ifx_httpdGetVar(wp, T("delay_threshold"), T(""));	// Get value from ASP file
	pWeightThreshold = ifx_httpdGetVar(wp, T("weight_threshold"), T(""));	// Get value from ASP file
	if (!gstrcmp(pPortscanStatus, "1"))
		gsprintf(sPortscanStatus, T("PORTSCAN_STATUS=\"1\"\n"));
	else
		gsprintf(sPortscanStatus, T("PORTSCAN_STATUS=\"0\"\n"));
	gsprintf(sLoportWeight, T("LOPORT_WEIGHT=\"%s\"\n"), pLoportWeight);
	gsprintf(sHiportWeight, T("HIPORT_WEIGHT=\"%s\"\n"), pHiportWeight);
	gsprintf(sDelayThreshold, T("DELAY_THRESHOLD=\"%s\"\n"),
		 pDelayThreshold);
	gsprintf(sWeightThreshold, T("WEIGHT_THRESHOLD=\"%s\"\n"),
		 pWeightThreshold);
	//Now save same value in rc.conf as old
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_DOS_SCANS, T("LOPORT_WEIGHT"), sValue) == 0) {
		strcpy(sValue, "0");
	}
	gsprintf(sOldLoportWeight, T("OLD_LOPORT_WEIGHT=\"%s\"\n"), sValue);
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_DOS_SCANS, T("HIPORT_WEIGHT"), sValue) == 0) {
		strcpy(sValue, "0");
	}
	//Now save same value in rc.conf as old
	gsprintf(sOldHiportWeight, T("OLD_HIPORT_WEIGHT=\"%s\"\n"), sValue);
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_DOS_SCANS, T("DELAY_THRESHOLD"), sValue) == 0) {
		strcpy(sValue, "0");
	}
	//Now save same value in rc.conf as old
	gsprintf(sOldDelayThreshold, T("OLD_DELAY_THRESHOLD=\"%s\"\n"), sValue);
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_DOS_SCANS, T("WEIGHT_THRESHOLD"), sValue) == 0) {
		strcpy(sValue, "0");
	}
	//Now save same value in rc.conf as old
	gsprintf(sOldWeightThreshold, T("OLD_WEIGHT_THRESHOLD=\"%s\"\n"),
		 sValue);
	//Write to rc.conf
	ifx_SetCfgData(FILE_RC_CONF, TAG_DOS_SCANS, 14,
		       sTcpsynfloodStatus, sTcpsynfloodLimit, sTcpsynfloodBurst,
		       sOldTcpsynfloodLimit, sOldTcpsynfloodBurst,
		       sPortscanStatus, sLoportWeight, sHiportWeight,
		       sDelayThreshold, sWeightThreshold, sOldLoportWeight,
		       sOldHiportWeight, sOldDelayThreshold,
		       sOldWeightThreshold);
	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}
	system(SERVICE_FIREWALL_DOS_RESTART);
	websNextPage(wp);
}

void ifx_set_dos_networking(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pWinnukeStatus, *pWinnukePorts;
	char_t *pXmasStatus;
	char_t *pUdpbombStatus;
	char_t *pUdpportloopbackStatus, *pLoopbackPorts, *pFraggleStatus,
	    *pFraggleRate;
	char_t *pLandStatus;
	char_t *pFtpportrestrictedStatus;
	char_t *pTcphijackingStatus;
	char_t sWinnukeStatus[MAX_WEB_DATA], sWinnukePorts[MAX_WEB_DATA];
	char_t sXmasStatus[MAX_WEB_DATA];
	char_t sUdpbombStatus[MAX_WEB_DATA];
	char_t sUdpportloopbackStatus[MAX_WEB_DATA],
	    sLoopbackPorts[MAX_WEB_DATA], sFraggleStatus[MAX_WEB_DATA],
	    sFraggleRate[MAX_WEB_DATA];
	char_t sLandStatus[MAX_WEB_DATA];
	char_t sFtpportrestrictedStatus[MAX_WEB_DATA];
	char_t sTcphijackingStatus[MAX_WEB_DATA];
	//old values
	char_t sOldWinnukePorts[MAX_WEB_DATA], sOldLoopbackPorts[MAX_WEB_DATA],
	    sOldFraggleRate[MAX_WEB_DATA];
	char_t sValue[MAX_WEB_DATA];
	a_assert(wp);
	//Updaet Winnuke
	sWinnukeStatus[0] = '\0';
	sWinnukePorts[0] = '\0';
	sOldWinnukePorts[0] = '\0';
	pWinnukeStatus = ifx_httpdGetVar(wp, T("winnuke_status"), T(""));	// Get value from ASP file
	pWinnukePorts = ifx_httpdGetVar(wp, T("winnuke_ports"), T(""));	// Get value from ASP file
	if (!gstrcmp(pWinnukeStatus, "1"))
		gsprintf(sWinnukeStatus, T("WINNUKE_STATUS=\"1\"\n"));
	else
		gsprintf(sWinnukeStatus, T("WINNUKE_STATUS=\"0\"\n"));
	gsprintf(sWinnukePorts, T("WINNUKE_PORTS=\"%s\"\n"), pWinnukePorts);
	//to save same value in rc.conf as old
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_DOS_NETWORKING, T("WINNUKE_PORTS"),
	     sValue) == 0) {
		strcpy(sValue, "0");
	}
	gsprintf(sOldWinnukePorts, T("OLD_WINNUKE_PORTS=\"%s\"\n"), sValue);

//Update Xmas
	sXmasStatus[0] = '\0';
	pXmasStatus = ifx_httpdGetVar(wp, T("xmas_status"), T(""));	// Get value from ASP file
	if (!gstrcmp(pXmasStatus, "1"))
		gsprintf(sXmasStatus, T("XMAS_STATUS=\"1\"\n"));
	else
		gsprintf(sXmasStatus, T("XMAS_STATUS=\"0\"\n"));

	//Update UDP Bomb
	sUdpbombStatus[0] = '\0';
	pUdpbombStatus = ifx_httpdGetVar(wp, T("udpbomb_status"), T(""));	// Get value from ASP file
	if (!gstrcmp(pUdpbombStatus, "1"))
		gsprintf(sUdpbombStatus, T("UDPBOMB_STATUS=\"1\"\n"));
	else
		gsprintf(sUdpbombStatus, T("UDPBOMB_STATUS=\"0\"\n"));

	//Update UDP Port Loopback
	sUdpportloopbackStatus[0] = '\0';
	sLoopbackPorts[0] = '\0';
	sOldLoopbackPorts[0] = '\0';
	pUdpportloopbackStatus = ifx_httpdGetVar(wp, T("udpportloopback_status"), T(""));	// Get value from ASP file
	pLoopbackPorts = ifx_httpdGetVar(wp, T("loopback_ports"), T(""));	// Get value from ASP file
	if (!gstrcmp(pUdpportloopbackStatus, "1"))
		gsprintf(sUdpportloopbackStatus,
			 T("UDPPORTLOOPBACK_STATUS=\"1\"\n"));
	else
		gsprintf(sUdpportloopbackStatus,
			 T("UDPPORTLOOPBACK_STATUS=\"0\"\n"));
	gsprintf(sLoopbackPorts, T("LOOPBACK_PORTS=\"%s\"\n"), pLoopbackPorts);
	//to save same value in rc.conf as old
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_DOS_NETWORKING, T("LOOPBACK_PORTS"),
	     sValue) == 0) {
		strcpy(sValue, "0");
	}
	gsprintf(sOldLoopbackPorts, T("OLD_LOOPBACK_PORTS=\"%s\"\n"), sValue);

	//Update Fraggle
	sFraggleStatus[0] = '\0';
	sFraggleRate[0] = '\0';
	sOldFraggleRate[0] = '\0';
	pFraggleStatus = ifx_httpdGetVar(wp, T("fraggle_status"), T(""));	// Get value from ASP file
	pFraggleRate = ifx_httpdGetVar(wp, T("fraggle_rate"), T(""));	// Get value from ASP file
	if (!gstrcmp(pFraggleStatus, "1"))
		gsprintf(sFraggleStatus, T("FRAGGLE_STATUS=\"1\"\n"));
	else
		gsprintf(sFraggleStatus, T("FRAGGLE_STATUS=\"0\"\n"));
	gsprintf(sFraggleRate, T("FRAGGLE_RATE=\"%s\"\n"), pFraggleRate);
	//to save same value in rc.conf as old
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_DOS_NETWORKING, T("FRAGGLE_RATE"),
	     sValue) == 0) {
		strcpy(sValue, "0");
	}
	gsprintf(sOldFraggleRate, T("OLD_FRAGGLE_RATE=\"%s\"\n"), sValue);

	//Update Tcp Hijacking
	sTcphijackingStatus[0] = '\0';
	pTcphijackingStatus = ifx_httpdGetVar(wp, T("tcphijacking_status"), T(""));	// Get value from ASP file
	if (!gstrcmp(pTcphijackingStatus, "1"))
		gsprintf(sTcphijackingStatus, T("TCPHIJACKING_STATUS=\"1\"\n"));
	else
		gsprintf(sTcphijackingStatus, T("TCPHIJACKING_STATUS=\"0\"\n"));

	//Update FTP Port Restricted
	sFtpportrestrictedStatus[0] = '\0';
	pFtpportrestrictedStatus = ifx_httpdGetVar(wp, T("ftpportrestricted_status"), T(""));	// Get value from ASP file
	if (!gstrcmp(pFtpportrestrictedStatus, "1"))
		gsprintf(sFtpportrestrictedStatus,
			 T("FTPPORTRESTRICTED_STATUS=\"1\"\n"));
	else
		gsprintf(sFtpportrestrictedStatus,
			 T("FTPPORTRESTRICTED_STATUS=\"0\"\n"));

	//Update Land Attack
	sLandStatus[0] = '\0';
	pLandStatus = ifx_httpdGetVar(wp, T("land_status"), T(""));	// Get value from ASP file
	if (!gstrcmp(pLandStatus, "1"))
		gsprintf(sLandStatus, T("LAND_STATUS=\"1\"\n"));
	else
		gsprintf(sLandStatus, T("LAND_STATUS=\"0\"\n"));

	//Write to rc.conf
	ifx_SetCfgData(FILE_RC_CONF, TAG_DOS_NETWORKING, 14,
		       sWinnukeStatus, sWinnukePorts, sOldWinnukePorts,
		       sXmasStatus,
		       sUdpbombStatus,
		       sUdpportloopbackStatus, sFraggleStatus, sFraggleRate,
		       sOldFraggleRate, sLoopbackPorts, sOldLoopbackPorts,
		       sLandStatus, sFtpportrestrictedStatus,
		       sTcphijackingStatus);

	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}

	system(SERVICE_FIREWALL_DOS_RESTART);
	websNextPage(wp);
}
#endif
#endif

#ifdef IFX_DOS_ENABLE
int ifx_get_DoSStatus(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
	char_t sValue[MAX_FILELINE_LEN];
	char_t sParams[][32] = {
		"DOS_ENABLE",
		"PING_FORWARD",
		"PING_GW"
	};
	int i = 0;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	sValue[0] = '\0';

	for (i = 0; i < sizeof(sParams) / (32 * sizeof(char_t)); i++) {
		if (!gstrcmp(name, sParams[i])) {
			IFX_WRITE_CHECKBOX_STATUS(TAG_DOS_MAIN, sParams[i],
						  sValue)
		}
	}
	return 0;
}
int ifx_get_dos_applications(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
	char_t sValue[MAX_FILELINE_LEN];

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	//web port
	if (!gstrcmp(name, T("web_port"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DOS_APPLICATIONS, T("WEB_PORT"),
		     sValue)) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		}
	}
	//Code Red
	else if (!gstrcmp(name, T("codered_status"))) {
		IFX_WRITE_CHECKBOX_STATUS(TAG_DOS_APPLICATIONS,
					  "CODERED_STATUS", sValue)
	}
	//Code Red II
	else if (!gstrcmp(name, T("codered2_status"))) {
		IFX_WRITE_CHECKBOX_STATUS(TAG_DOS_APPLICATIONS,
					  "CODERED2_STATUS", sValue)
	}
	//ICQ DoS
	else if (!gstrcmp(name, T("icq_status"))) {
		IFX_WRITE_CHECKBOX_STATUS(TAG_DOS_APPLICATIONS, "ICQ_STATUS",
					  sValue)
	}
	//Hotsync Manager DoS
	else if (!gstrcmp(name, T("hotsync_status"))) {
		IFX_WRITE_CHECKBOX_STATUS(TAG_DOS_APPLICATIONS,
					  "HOTSYNC_STATUS", sValue)
	} else if (!gstrcmp(name, T("hotsync_port"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DOS_APPLICATIONS, T("HOTSYNC_PORT"),
		     sValue)) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		}
	}
	//Yahoo DoS
	else if (!gstrcmp(name, T("yahoo_status"))) {
		IFX_WRITE_CHECKBOX_STATUS(TAG_DOS_APPLICATIONS, "YAHOO_STATUS",
					  sValue)
	} else if (!gstrcmp(name, T("yahoo_port"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DOS_APPLICATIONS, T("YAHOO_PORT"),
		     sValue)) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		}
	}
	//Malformed MIME
	else if (!gstrcmp(name, T("mime_status"))) {
		IFX_WRITE_CHECKBOX_STATUS(TAG_DOS_APPLICATIONS, "MIME_STATUS",
					  sValue)
	} else if (!gstrcmp(name, T("mime_port"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DOS_APPLICATIONS, T("MIME_PORT"),
		     sValue)) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		}
	}

	return 0;
}

//              PAGE : dos_scans.asp
int ifx_get_dos_scans(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
	char_t sValue[MAX_FILELINE_LEN];

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	sValue[0] = '\0';

	//Port Scan
	if (!gstrcmp(name, T("portscan_status"))) {
		IFX_WRITE_CHECKBOX_STATUS(TAG_DOS_SCANS, "PORTSCAN_STATUS",
					  sValue)
	} else if (!gstrcmp(name, T("loport_weight"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DOS_SCANS, T("LOPORT_WEIGHT"), sValue)) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		}
	} else if (!gstrcmp(name, T("hiport_weight"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DOS_SCANS, T("HIPORT_WEIGHT"), sValue)) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		}
	} else if (!gstrcmp(name, T("weight_threshold"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DOS_SCANS, T("WEIGHT_THRESHOLD"),
		     sValue)) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		}
	} else if (!gstrcmp(name, T("delay_threshold"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DOS_SCANS, T("DELAY_THRESHOLD"),
		     sValue)) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		}
	}
	//TCP Syn Flood
	else if (!gstrcmp(name, T("tcpsynflood_status"))) {
		IFX_WRITE_CHECKBOX_STATUS(TAG_DOS_SCANS, "TCPSYNFLOOD_STATUS",
					  sValue)
	} else if (!gstrcmp(name, T("tcpsynflood_limit"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DOS_SCANS, T("TCPSYNFLOOD_LIMIT"),
		     sValue)) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		}
	} else if (!gstrcmp(name, T("tcpsynflood_burst"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DOS_SCANS, T("TCPSYNFLOOD_BURST"),
		     sValue)) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		}
	}
	return 0;
}

//              PAGE : dos_networking.asp
int ifx_get_dos_networking(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
	char_t sValue[MAX_FILELINE_LEN];

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	sValue[0] = '\0';

	// Winnuke
	if (!gstrcmp(name, T("winnuke_status"))) {
		IFX_WRITE_CHECKBOX_STATUS(TAG_DOS_NETWORKING, "WINNUKE_STATUS",
					  sValue)
	} else if (!gstrcmp(name, T("winnuke_ports"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DOS_NETWORKING, T("WINNUKE_PORTS"),
		     sValue)) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		}
	}
	// Xmas
	else if (!gstrcmp(name, T("xmas_status"))) {
		IFX_WRITE_CHECKBOX_STATUS(TAG_DOS_NETWORKING, "XMAS_STATUS",
					  sValue)
	}
	// UDP Bomb
	else if (!gstrcmp(name, T("udpbomb_status"))) {
		IFX_WRITE_CHECKBOX_STATUS(TAG_DOS_NETWORKING, "UDPBOMB_STATUS",
					  sValue)
	}
	//UDP Port Looback
	else if (!gstrcmp(name, T("udpportloopback_status"))) {
		IFX_WRITE_CHECKBOX_STATUS(TAG_DOS_NETWORKING,
					  "UDPPORTLOOPBACK_STATUS", sValue)
	} else if (!gstrcmp(name, T("loopback_ports"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DOS_NETWORKING, T("LOOPBACK_PORTS"),
		     sValue)) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		}
	}
	//Fraggle
	else if (!gstrcmp(name, T("fraggle_status"))) {
		IFX_WRITE_CHECKBOX_STATUS(TAG_DOS_NETWORKING, "FRAGGLE_STATUS",
					  sValue)
	} else if (!gstrcmp(name, T("fraggle_rate"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DOS_NETWORKING, T("FRAGGLE_RATE"),
		     sValue)) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		}
	}
	// Land
	else if (!gstrcmp(name, T("land_status"))) {
		IFX_WRITE_CHECKBOX_STATUS(TAG_DOS_NETWORKING, "LAND_STATUS",
					  sValue)
	}
	//FTP Port Restricted
	else if (!gstrcmp(name, T("ftpportrestricted_status"))) {
		IFX_WRITE_CHECKBOX_STATUS(TAG_DOS_NETWORKING,
					  "FTPPORTRESTRICTED_STATUS", sValue)
	}
	//TCP Hijacking
	else if (!gstrcmp(name, T("tcphijacking_status"))) {
		IFX_WRITE_CHECKBOX_STATUS(TAG_DOS_NETWORKING,
					  "TCPHIJACKING_STATUS", sValue)
	}
	return 0;
}
#endif
