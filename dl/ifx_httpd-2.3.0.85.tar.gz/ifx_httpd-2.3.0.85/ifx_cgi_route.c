//#include <sys/syslog.h>
#include <ifx_emf.h>
#include "ifx_httpd_method.h"
//#include <signal.h>
//#include <unistd.h>
#include <arpa/inet.h>
//#include <sys/types.h>
//#include <sys/wait.h>
//#include <ifx_common.h>
#include "./ifx_amazon_cgi.h"
//#include "./ifx_amazon_cgi_getFunctions.h"
//#include "ifx_snmp_api.h"
//#include "ifx_api_ipt_common.h"
//#include <sys/ioctl.h>
#include "./ifx_cgi_common.h"

extern char_t *status_str;
char *dup_route_err;
char wan_interface_name[MAX_NAME_SIZE];

void ifx_set_route_static(httpd_t wp, char_t * path, char_t * query);	// route_static.asp
int ifx_get_route_static(int eid, httpd_t wp, int argc, char_t ** argv);
#ifdef CONFIG_FEATURE_IPv6
void ifx_set_ipv6_route_static(httpd_t wp, char_t * path, char_t * query);
int ifx_get_ipv6_route_static(int eid, httpd_t wp, int argc, char_t ** argv);
extern int32 ifx_set_ipv6_static_route(int32 operation, ROUTE6_ENTRY * entry,
				       uint32 flags);
extern int32 ifx_get_all_ipv6_static_route_entries(int32 * num_routes,
						   ROUTE6_ENTRY **
						   route_entries, uint32 flags);
#endif
int ifx_get_route_table(int eid, httpd_t wp, int argc, char_t ** argv);	//route_table.asp

// start ......
char *ifx_get_wan_interfaces_cgi(int wan_index)
{
	char8 command[MAX_NAME_SIZE];
	char_t sValue[MAX_FILELINE_LEN];
	int VPI_value, VCI_value, linkType, addrType;

	memset(command, 0x00, MAX_NAME_SIZE);
	memset(sValue, 0x00, MAX_FILELINE_LEN);
	gsprintf(command, "wan_%d_vcc", wan_index + 1);
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_WAN_MAIN, command, sValue) == 0) {
		gsprintf(wan_interface_name, "None");
		return wan_interface_name;
	}
	gsscanf(sValue, "%d/%d", &VPI_value, &VCI_value);

	snprintf(command, sizeof(command), "wan_%d_linkType", wan_index + 1);
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_WAN_MAIN, command, sValue) == 0) {
		gsprintf(wan_interface_name, "None");
		return wan_interface_name;
	}
	gsscanf(sValue, "%d", &linkType);

	if (linkType == 1) {
		snprintf(command, sizeof(command), "wanip_%d_addrType",
			 wan_index + 1);
		if (ifx_GetCfgData(FILE_RC_CONF, TAG_WAN_IP, command, sValue) ==
		    0) {
			gsprintf(wan_interface_name, "None");
			return wan_interface_name;
		}
	}
	gsscanf(sValue, "%d", &addrType);

	wan_interface_name[0] = '\0';
	if ((linkType == 1) || (linkType == 2)) {
		if (addrType == 0)
			gsprintf(wan_interface_name, "WAN%d", wan_index + 1);
		else if (addrType == 1)
			gsprintf(wan_interface_name, "WAN%d", wan_index + 1);
		else if (addrType == 2)
			gsprintf(wan_interface_name, "WAN%d", wan_index + 1);
		else
			gsprintf(wan_interface_name, "None");
	} else if (linkType == 3)
		gsprintf(wan_interface_name, "WAN%d", wan_index + 1);
	else if (linkType == 4)
		gsprintf(wan_interface_name, "WAN%d", wan_index + 1);
	else if (linkType == 5)
		gsprintf(wan_interface_name, "WAN%d", wan_index + 1);
	else
		gsprintf(wan_interface_name, "None");

	return wan_interface_name;
}

//end of ifx_get_wan_interfaces_cgi

// route_static.asp
void ifx_set_route_static(httpd_t wp, char_t * path, char_t * query)
{
	// Update Alias IP here
	char_t *pAdd = ifx_httpdGetVar(wp, T("addflag"), T(""));
	char_t *pDel = ifx_httpdGetVar(wp, T("delflag"), T(""));
	char_t *ip = NULL, *nm = NULL, *gw = NULL;
	char_t *pDelcpeID = NULL;
	char_t sAddIP[MAX_FILELINE_LEN];
	char_t sAddNM[MAX_FILELINE_LEN];
	char_t sAddGW[MAX_FILELINE_LEN];
	uint32 flags = IFX_F_DEFAULT, op = 0;
	ROUTE_ENTRY sroute;
	int ret = TRUE;

	sAddIP[0] = '\0';
	sAddNM[0] = '\0';
	sAddGW[0] = '\0';

	// Submit data form press "Add" button
	char_t *pAIP1 = ifx_httpdGetVar(wp, T("AIP1"), T(""));
	char_t *pAIP2 = ifx_httpdGetVar(wp, T("AIP2"), T(""));
	char_t *pAIP3 = ifx_httpdGetVar(wp, T("AIP3"), T(""));
	char_t *pAIP4 = ifx_httpdGetVar(wp, T("AIP4"), T(""));
	char_t *pANM1 = ifx_httpdGetVar(wp, T("ANM1"), T(""));
	char_t *pANM2 = ifx_httpdGetVar(wp, T("ANM2"), T(""));
	char_t *pANM3 = ifx_httpdGetVar(wp, T("ANM3"), T(""));
	char_t *pANM4 = ifx_httpdGetVar(wp, T("ANM4"), T(""));
	char_t *pAGW1 = ifx_httpdGetVar(wp, T("AGW1"), T(""));
	char_t *pAGW2 = ifx_httpdGetVar(wp, T("AGW2"), T(""));
	char_t *pAGW3 = ifx_httpdGetVar(wp, T("AGW3"), T(""));
	char_t *pAGW4 = ifx_httpdGetVar(wp, T("AGW4"), T(""));
	char_t *pINTRF = ifx_httpdGetVar(wp, T("INTRF"), T(""));
	memset(&sroute, 0x00, sizeof(sroute));

	if (pAdd[0] || !gstrcmp(pAdd, T("1"))) {
		op = IFX_OP_ADD;
	}
	// Update table and system
	if (!gstrcmp(pDel, T("1"))) {
		op = IFX_OP_DEL;

		pDelcpeID = ifx_httpdGetVar(wp, T("delcpeID"), T(""));
		ip = ifx_httpdGetVar(wp, T("deldst"), T(""));
		nm = ifx_httpdGetVar(wp, T("delnetmask"), T(""));
		gw = ifx_httpdGetVar(wp, T("delgw"), T(""));
		ifx_httpdGetVar(wp, T("delintrf"), T(""));

	}

	if (op == IFX_OP_ADD) {
		gsprintf(sAddIP, T("%s.%s.%s.%s"), pAIP1, pAIP2, pAIP3, pAIP4);
		sroute.ip_dst.ip.s_addr = inet_addr(sAddIP);

		gsprintf(sAddNM, T("%s.%s.%s.%s"), pANM1, pANM2, pANM3, pANM4);
		sroute.ip_dst.mask.s_addr = inet_addr(sAddNM);

		gsprintf(sAddGW, T("%s.%s.%s.%s"), pAGW1, pAGW2, pAGW3, pAGW4);
		sroute.gw.s_addr = inet_addr(sAddGW);

		gstrcpy(sroute.route_if, pINTRF);

		sroute.iid.config_owner = IFX_WEB;
	}

	if (op == IFX_OP_DEL) {
		sroute.ip_dst.ip.s_addr = inet_addr(ip);

		sroute.ip_dst.mask.s_addr = inet_addr(nm);

		sroute.gw.s_addr = inet_addr(gw);

		sroute.iid.cpeId.Id = gatoi(pDelcpeID);

		gstrcpy(sroute.route_if, pINTRF);
	}
	strncpy(sroute.iid.cpeId.secName, TAG_ROUTING, strlen(TAG_ROUTING));
	strncpy(sroute.iid.pcpeId.secName, TAG_DEFAULT_WAN,
		strlen(TAG_DEFAULT_WAN));
	sroute.iid.config_owner = IFX_WEB;
	sroute.f_enable = IFX_ENABLED;

	if (op == IFX_OP_ADD || op == IFX_OP_DEL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = ifx_set_static_route(op, &sroute, flags);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		if (ret == IFX_DUPLICATE_ENTRY) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			COPY_TO_STATUS("%s", dup_route_err);
			ifx_httpdRedirect(wp, "err_page.html");
			goto IFX_Handler;
		}
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			if (ret == IFX_ACL_CHECK_FAILED) {
				if (op == IFX_OP_ADD)
					ifx_httpdError(wp, 500,
						       T
						       ("ACL Check Failed for Add !!"));
				else if (op == IFX_OP_DEL)
					ifx_httpdError(wp, 500,
						       T
						       ("ACL Check Failed for Delete !!"));
			} else {
				if (!strcmp
				    (inet_ntoa(sroute.ip_dst.ip), "0.0.0.0")
				    || !strcmp(inet_ntoa(sroute.ip_dst.mask),
					       "0.0.0.0")
				    || !strcmp(inet_ntoa(sroute.gw), "0.0.0.0"))
					ifx_httpdError(wp, 500,
						       T
						       ("Failed to configure the specified route entry, invalid Dest IP or invalid Subnet Mask or invalid Gateway"));
				else
					ifx_httpdError(wp, 500,
						       T
						       ("Failed to configure the specified route entry...."));
			}
			goto IFX_Handler;
		}
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		// websNextPage(wp);
		ifx_httpdRedirect(wp, T("route_static.asp"));
	} else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		// websNextPage(wp);
		ifx_httpdRedirect(wp, T("route_static.asp"));
	}
      IFX_Handler:
	return;
}

#ifdef CONFIG_FEATURE_IPv6
void ifx_set_ipv6_route_static(httpd_t wp, char_t * path, char_t * query)
{
	// Update Alias IP here
	char_t *pAdd = ifx_httpdGetVar(wp, T("addflag"), T(""));
	char_t *pDel = ifx_httpdGetVar(wp, T("delflag"), T(""));
	char_t *ip = NULL, *gw = NULL, *prefix_len = NULL;
	int32 prefixlen = 0;
	char_t *pDelcpeID = NULL;
	char_t sAddIP[MAX_FILELINE_LEN];
	char_t sAddGW[MAX_FILELINE_LEN];
	uint32 flags = IFX_F_DEFAULT, op = 0;
	char ipv6_addr[INET6_ADDRSTRLEN];
	ROUTE6_ENTRY sroute;
	int ret = TRUE, ret_val = 0;

	sAddIP[0] = '\0';
	sAddGW[0] = '\0';

	// Submit data form press "Add" button
	char_t *pAIP1 = ifx_httpdGetVar(wp, T("AIP1"), T(""));
	char_t *pANM1 = ifx_httpdGetVar(wp, T("ANM1"), T(""));
	char_t *pAGW1 = ifx_httpdGetVar(wp, T("AGW1"), T(""));
	char_t *pINTRF = ifx_httpdGetVar(wp, T("INTRF"), T(""));

	memset(&sroute, 0x00, sizeof(sroute));
	if (pAdd[0] || !gstrcmp(pAdd, T("1"))) {
		op = IFX_OP_ADD;
	}
	// Update table and system
	if (!gstrcmp(pDel, T("1"))) {
		op = IFX_OP_DEL;

		pDelcpeID = ifx_httpdGetVar(wp, T("delcpeID"), T(""));
		ip = ifx_httpdGetVar(wp, T("deldst"), T(""));
		prefix_len = ifx_httpdGetVar(wp, T("delprefixlen"), T(""));
		gw = ifx_httpdGetVar(wp, T("delgw"), T(""));
		ifx_httpdGetVar(wp, T("delintrf"), T(""));
	}

	if (op == IFX_OP_ADD) {
		strncpy(sAddIP, pAIP1, sizeof(sAddIP));
		ret_val =
		    inet_pton(AF_INET6, (const char *)sAddIP,
			      &(sroute.ip_dst.ip));
		if (ret_val <= 0) {
			COPY_TO_STATUS("%s",
				       "Please put a valid IPv6 Prefix and then try again");
			ifx_httpdRedirect(wp, "err_page.html");
			return;
		}
		if (pANM1 == NULL) {
			COPY_TO_STATUS("%s",
				       "Please put a valid IPv6 Prefix Length and then try again");
			ifx_httpdRedirect(wp, "err_page.html");
			return;
		}
		prefixlen = atoi(pANM1);
		sroute.ip_dst.prefix_len = prefixlen;
		strncpy(sAddGW, pAGW1, sizeof(sAddGW));
		ret_val =
		    inet_pton(AF_INET6, (const char *)sAddGW, &(sroute.gw));
		if (ret_val <= 0) {
			COPY_TO_STATUS("%s",
				       "Please put a valid IPv6 Next Hop and then try again");
			ifx_httpdRedirect(wp, "err_page.html");
			return;
		}
		if (inet_ntop
		    (AF_INET6, &(sroute.gw), ipv6_addr,
		     INET6_ADDRSTRLEN) != NULL) {
			if (!strcmp(ipv6_addr, "::")) {
				COPY_TO_STATUS("%s",
					       "Please put a valid IPv6 Next Hop and then try again");
				ifx_httpdRedirect(wp, "err_page.html");
				return;
			}
		}
		gstrcpy(sroute.route_if, pINTRF);
		sroute.iid.config_owner = IFX_WEB;
	}
	if (op == IFX_OP_DEL) {
		ret_val =
		    inet_pton(AF_INET6, (const char *)ip, &(sroute.ip_dst.ip));
		if (ret_val <= 0) {
			COPY_TO_STATUS("%s", "Invalid IPv6 Prefix");
			ifx_httpdRedirect(wp, "err_page.html");
			return;
		}
		if (prefix_len == NULL) {
			COPY_TO_STATUS("%s", "Invalid IPv6 Prefix Length");
			ifx_httpdRedirect(wp, "err_page.html");
			return;
		}
		prefixlen = atoi(prefix_len);
		sroute.ip_dst.prefix_len = prefixlen;
		ret_val = inet_pton(AF_INET6, (const char *)gw, &(sroute.gw));
		if (ret_val <= 0) {
			COPY_TO_STATUS("%s",
				       "Please put a valid IPv6 Prefix and then try again");
			ifx_httpdRedirect(wp, "err_page.html");
			return;
		}
		sroute.iid.cpeId.Id = gatoi(pDelcpeID);
		gstrcpy(sroute.route_if, pINTRF);
	}
	strncpy(sroute.iid.cpeId.secName, TAG_ROUTING6, strlen(TAG_ROUTING6));
	strncpy(sroute.iid.pcpeId.secName, TAG_DEFAULT_WAN, strlen(TAG_DEFAULT_WAN));	//fix it
	sroute.iid.config_owner = IFX_WEB;
	sroute.f_enable = IFX_ENABLED;
	if (op == IFX_OP_ADD || op == IFX_OP_DEL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = ifx_set_ipv6_static_route(op, &sroute, flags);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		if (ret == IFX_DUPLICATE_ENTRY) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			COPY_TO_STATUS("%s", dup_route_err);
			ifx_httpdRedirect(wp, "err_page.html");
			goto IFX_Handler;
		}
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			COPY_TO_STATUS("%s",
				       "Failed to configure the specified route entry. Please validate input and try again");
			ifx_httpdRedirect(wp, "err_page.html");
//                      ifx_httpdError(wp, 500, T("Failed to configure the specified route entry. Please validate input and try again"));
			goto IFX_Handler;
		}
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ifx_httpdRedirect(wp, T("route_static_ipv6.asp"));
	} else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ifx_httpdRedirect(wp, T("route_static_ipv6.asp"));
	}
      IFX_Handler:
	return;
}
#endif

int ifx_get_route_static(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int num;
	int ret = IFX_SUCCESS, i;
	uint32 Flags = IFX_F_DEFAULT;
	ROUTE_ENTRY *route = NULL;
	ret = ifx_get_all_static_route_entries(&num, &route, Flags);

	if (ret == IFX_SUCCESS) {
		for (i = 0; i < num; i++) {
			ifx_httpdWrite(wp,
				       "<input type=\"hidden\" name=\"cpeId%d\" value=\"%d\">",
				       i, (route + i)->iid.cpeId.Id);
			ifx_httpdWrite(wp, T("<tr>\n"));
			ifx_httpdWrite(wp,
				       T("<td name=\"srt_dip%d\">%s</td>\n"), i,
				       inet_ntoa((route + i)->ip_dst.ip));
			ifx_httpdWrite(wp,
				       T("<td name=\"srt_smask%d\">%s</td>\n"),
				       i, inet_ntoa((route + i)->ip_dst.mask));
			ifx_httpdWrite(wp, T("<td name=\"srt_gw%d\">%s</td>\n"),
				       i, inet_ntoa((route + i)->gw));
			ifx_httpdWrite(wp,
				       T("<td name=\"srt_intf%d\">%s</td>\n"),
				       i, (route + i)->route_if);

			if ((route + i)->f_enable == IFX_DISABLED) {
				ifx_httpdWrite(wp,
					       T
					       ("<td><a class=\"button\" href=\"#\" value=\"Delete\" onClick=\"staticdel(\'%d\', \'%d\', \'%s\', \'%s\', \'%s\');\" disabled>Delete</a></td>\n"),
					       i, (route + i)->iid.cpeId.Id,
					       inet_ntoa((route +
							  i)->ip_dst.ip),
					       inet_ntoa((route +
							  i)->ip_dst.mask),
					       inet_ntoa((route + i)->gw));
			} else {
				ifx_httpdWrite(wp,
					       T
					       ("<td><a class=\"button\" href=\"#\" value=\"Delete\" onClick=\"staticdel(\'%d\', \'%d\', \'%s\', \'%s\', \'%s\');\">Delete</a></td>\n"),
					       i, (route + i)->iid.cpeId.Id,
					       inet_ntoa((route +
							  i)->ip_dst.ip),
					       inet_ntoa((route +
							  i)->ip_dst.mask),
					       inet_ntoa((route + i)->gw));
			}
			ifx_httpdWrite(wp, T("</tr>"));
		}
	} else {
		ifx_httpdError(wp, 500, "Error");
	}

	IFX_MEM_FREE(route)
	    return 0;
}

//end route_static.asp

#ifdef CONFIG_FEATURE_IPv6
int ifx_get_ipv6_route_static(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int num;
	int ret = IFX_SUCCESS, i;
	uint32 Flags = IFX_F_DEFAULT;
	char buf[MAX_FILELINE_LEN];
	char ipv6_addr[INET6_ADDRSTRLEN];
	char ipv6_addr_gw[INET6_ADDRSTRLEN];
	ROUTE6_ENTRY *route = NULL;
	ret = ifx_get_all_ipv6_static_route_entries(&num, &route, Flags);
	if (ret == IFX_SUCCESS) {
		for (i = 0; i < num; i++) {
			ifx_httpdWrite(wp,
				       "<input type=\"hidden\" id=\"cpeId%d\" name=\"cpeId%d\" value=\"%d\">",
				       i, i, (route + i)->iid.cpeId.Id);
			ifx_httpdWrite(wp, T("<tr>\n"));
			if (inet_ntop
			    (AF_INET6, &((route + i)->ip_dst.ip), ipv6_addr,
			     INET6_ADDRSTRLEN) == NULL) {
				ipv6_addr[0] = '\0';
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"srt_dip%d\" name=\"srt_dip%d\">%s</td>\n"),
					       i, i, "");
			} else {
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"srt_dip%d\" name=\"srt_dip%d\">%s</td>\n"),
					       i, i, ipv6_addr);
			}
			snprintf(buf, sizeof(buf), "%d",
				 (route + i)->ip_dst.prefix_len);
			ifx_httpdWrite(wp,
				       T
				       ("<td id=\"srt_smask%d\" name=\"srt_smask%d\">%s</td>\n"),
				       i, i, buf);
			if (inet_ntop
			    (AF_INET6, &((route + i)->gw), ipv6_addr_gw,
			     INET6_ADDRSTRLEN) == NULL) {
				ipv6_addr_gw[0] = '\0';
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"srt_gw%d\" name=\"srt_gw%d\">%s</td>\n"),
					       i, i, "");
			} else
				ifx_httpdWrite(wp,
					       T
					       ("<td id=\"srt_gw%d\" name=\"srt_gw%d\">%s</td>\n"),
					       i, i, ipv6_addr_gw);
			ifx_httpdWrite(wp,
				       T
				       ("<td id=\"srt_intf%d\" name=\"srt_intf%d\">%s</td>\n"),
				       i, i,
				       route[i].route_if);
			if ((route + i)->f_enable == IFX_DISABLED) {
				ifx_httpdWrite(wp,
					       T
					       ("<td><a class=\"button\" href=\"#\" value=\"Delete\" onClick=\"staticdel(\'%d\', \'%d\', \'%s\', \'%s\', \'%s\');\" disabled>Delete</a></td>\n"),
					       i, (route + i)->iid.cpeId.Id,
					       ipv6_addr, buf, ipv6_addr_gw);
			} else {
				ifx_httpdWrite(wp,
					       T
					       ("<td><a class=\"button\" href=\"#\" value=\"Delete\" onClick=\"staticdel(\'%d\', \'%d\', \'%s\', \'%s\', \'%s\');\">Delete</a></td>\n"),
					       i, (route + i)->iid.cpeId.Id,
					       ipv6_addr, buf, ipv6_addr_gw);
			}
			ifx_httpdWrite(wp, T("</tr>"));
		}
	} else {
		ifx_httpdError(wp, 500, "Error");
	}
	IFX_MEM_FREE(route);
	return 0;
}
#endif

//route_table.asp
int ifx_get_route_table(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t ip[MAX_IP_ADDR_LEN], nm[MAX_IP_ADDR_LEN], gw[MAX_IP_ADDR_LEN],
	    iface[MAX_FILELINE_LEN];
	int ret = IFX_SUCCESS, i = 0, num = 0, metric = 0;
	uint32 Flags = IFX_F_GET_ANY;

	ANY_ROUTE_ENTRY *rt = NULL;

	ret = ifx_get_all_route_entries(&num, &rt, Flags);

	if (ret == IFX_SUCCESS) {
		for (i = 0; i < num; i++) {
			ifx_httpdWrite(wp, T("\t\t<tr>\n"));
			if ((rt + i)->f_policy_route == '1') {
				sprintf(ip, "%s",
					(char_t *) inet_ntoa((rt + i)->ROUTE.
							     policy_route.
							     ip_dst.ip));
				sprintf(nm, "%s",
					(char_t *) inet_ntoa((rt + i)->ROUTE.
							     policy_route.
							     ip_dst.mask));
				sprintf(gw, "%s",
					(char_t *) inet_ntoa((rt + i)->ROUTE.
							     policy_route.gw));
				metric = (rt + i)->ROUTE.policy_route.metric;
				sprintf(iface, "%s",
					(rt + i)->ROUTE.policy_route.route_if);
			} else {
				sprintf(ip, "%s",
					(char_t *) inet_ntoa((rt + i)->ROUTE.
							     route.ip_dst.ip));
				sprintf(nm, "%s",
					(char_t *) inet_ntoa((rt + i)->ROUTE.
							     route.ip_dst.
							     mask));
				sprintf(gw, "%s",
					(char_t *) inet_ntoa((rt + i)->ROUTE.
							     route.gw));
				metric = (rt + i)->ROUTE.route.metric;
				sprintf(iface, "%s",
					(rt + i)->ROUTE.route.route_if);
			}
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t<td id=\"id=rtl_dip%d\">%s</td>\n"),
				       i, ip);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t<td id=\"id=rtl_smask%d\">%s</td>\n"),
				       i, nm);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t<td id=\"id=rtl_gway%d\">%s</td>\n"),
				       i, gw);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t<td id=\"id=rtl_metric%d\">%d</td>\n"),
				       i, metric);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t<td id=\"id=rtl_intf%d\">%s</td>\n"),
				       i, iface);
			ifx_httpdWrite(wp, T("\t\t</tr>\n"));

		}
	} else {
		ifx_httpdError(wp, 400, T("Error\n"));
	}
	ifx_httpdWrite(wp, T("\t\t<tr>\n"));
	IFX_MEM_FREE(rt)

	    return 0;
}

#ifdef POLICY_ROUTING
//              PAGE : policy_routing.asp
void ifx_set_policy_routing(httpd_t wp, char_t * path, char_t * query)
{
	char_t sPrStatus[MAX_DATA_LEN];
	char_t *pPrStatus = NULL;
	char_t *pDel = ifx_httpdGetVar(wp, T("delflag"), T(""));
	char_t sCommand[MAX_DATA_LEN];
	POLICY_ROUTE policy_route;

	a_assert(wp);

	memset(&policy_route, 0x00, sizeof(policy_route));

	// Submit data form press delete button
	if (!gstrcmp(pDel, T("1"))) {
		char_t *pDelcpeID = ifx_httpdGetVar(wp, T("delcpeId"), T(""));
		policy_route.iid.cpeId.Id = atoi(pDelcpeID);
		policy_route.iid.pcpeId.Id = 1;
		/* Set owner as WEB */
		policy_route.iid.config_owner = IFX_WEB;
		if (ifx_set_policy_route
		    (IFX_OP_DEL, &policy_route, IFX_F_DELETE) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to delete the specified policy route entry !!");
			return;
		}
	} else {
		sPrStatus[0] = '\0';
		pPrStatus = ifx_httpdGetVar(wp, T("prStatus"), T(""));

		if (!gstrcmp(pPrStatus, T("1"))) {
			gsprintf(sPrStatus, T("PR_STATUS=\"1\"\n"));
		} else {
			gsprintf(sPrStatus, T("PR_STATUS=\"0\"\n"));
		}
		if (ifx_SetObjData
		    (FILE_RC_CONF, TAG_POLICY_ROUTING_STATUS, IFX_F_MODIFY, 1,
		     sPrStatus) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to enabled policy routing !!");
			return;
		}
		sprintf(sCommand, "%s --PolicyRoutingInit %s\n", NAPTCFG,
			pPrStatus);
		system(sCommand);
		system(SERVICE_POLICY_ROUTING_RESTART);
	}
	websNextPage(wp);
}

//              PAGE : policy_routing_add.asp
void ifx_set_policy_routing_add(httpd_t wp, char_t * path, char_t * query)
{
	POLICY_ROUTE policy_route;

	char_t *pPR_R = ifx_httpdGetVar(wp, T("PR_ADD"), T(""));
	char_t *pPR_SRC_IP = ifx_httpdGetVar(wp, T("PR_SRC_IP"), T(""));
	char_t *pPR_IP_SRC_TYPE =
	    ifx_httpdGetVar(wp, T("PR_IP_SRC_TYPE_ADD"), T(""));
	char_t *pPR_IP_SRC_MASK =
	    ifx_httpdGetVar(wp, T("PR_IP_SRC_MASK_ADD"), T(""));
	char_t *pPR_IP_DST_TYPE =
	    ifx_httpdGetVar(wp, T("PR_IP_DST_TYPE_ADD"), T(""));
	char_t *pPR_IP_DST_MASK =
	    ifx_httpdGetVar(wp, T("PR_IP_DST_MASK_ADD"), T(""));
	char_t *pPR_SRC_PORT = ifx_httpdGetVar(wp, T("PR_SRC_PORT"), T(""));
	char_t *pPR_DST_IP = ifx_httpdGetVar(wp, T("PR_DST_IP"), T(""));
	char_t *pPR_DST_PORT = ifx_httpdGetVar(wp, T("PR_DST_PORT"), T(""));
	char_t *pPR_PROTOCOL = ifx_httpdGetVar(wp, T("PR_PROTOCOL"), T(""));
	char_t *pPR_DIFFSERV = ifx_httpdGetVar(wp, T("PR_DIFFSERV"), T(""));
	char_t *pPR_OPIF = ifx_httpdGetVar(wp, T("PR_OP_IF"), T(""));
	char_t *pPR_GW_IP = ifx_httpdGetVar(wp, T("PR_GW_IP"), T(""));

	// copy data to Policy Routing Table
	memset(&policy_route, 0x00, sizeof(policy_route));
	if (!gstrcmp(pPR_R, "1")) {
		policy_route.f_enable = IFX_ENABLED;
	} else {
		policy_route.f_enable = IFX_DISABLED;
	}

// copy src ip
	if (atoi(pPR_IP_SRC_TYPE) != 0 && strlen(pPR_SRC_IP)) {
		policy_route.ip_src.ip.s_addr = inet_addr(pPR_SRC_IP);
		if (atoi(pPR_IP_SRC_TYPE) == 2 && strlen(pPR_IP_SRC_MASK)) {
			policy_route.ip_src.mask.s_addr =
			    inet_addr(pPR_IP_SRC_MASK);
		} else if (atoi(pPR_IP_SRC_TYPE) == 1) {
			policy_route.ip_src.mask.s_addr =
			    inet_addr("255.255.255.255");
		} else {
			policy_route.ip_src.mask.s_addr = inet_addr("0.0.0.0");
		}
	} else {
		policy_route.ip_src.ip.s_addr = inet_addr("0.0.0.0");	/* wild card entry */
		policy_route.ip_src.mask.s_addr = inet_addr("0.0.0.0");
	}

	// copy src port
	if (strlen(pPR_SRC_PORT) && pPR_SRC_PORT[0] != '*')
		policy_route.src_ports.start_port = atoi(pPR_SRC_PORT);
	else
		policy_route.src_ports.start_port = 0;	/* wild card entry */

	policy_route.src_ports.end_port = policy_route.src_ports.start_port;

	// copy dst ip
	if (atoi(pPR_IP_DST_TYPE) != 0 && strlen(pPR_DST_IP)) {
		policy_route.ip_dst.ip.s_addr = inet_addr(pPR_DST_IP);
		if (atoi(pPR_IP_DST_TYPE) == 2 && strlen(pPR_IP_DST_MASK)) {
			policy_route.ip_dst.mask.s_addr =
			    inet_addr(pPR_IP_DST_MASK);
		} else if (atoi(pPR_IP_DST_TYPE) == 1) {
			policy_route.ip_dst.mask.s_addr =
			    inet_addr("255.255.255.255");
		} else {
			policy_route.ip_dst.mask.s_addr = inet_addr("0.0.0.0");
		}
	} else {
		policy_route.ip_dst.ip.s_addr = inet_addr("0.0.0.0");	/* wild card entry */
		policy_route.ip_dst.mask.s_addr = inet_addr("0.0.0.0");
	}

	// copy dst port
	if (strlen(pPR_DST_PORT) && pPR_DST_PORT[0] != '*')
		policy_route.dst_ports.start_port = atoi(pPR_DST_PORT);
	else
		policy_route.dst_ports.start_port = 0;	/* wild card entry */

	policy_route.dst_ports.end_port = policy_route.dst_ports.start_port;

	// copy protocol
	if (!pPR_PROTOCOL[0])
		policy_route.rt_protocol = -1;	/* FIXME : should not be blank !! */
	else
		policy_route.rt_protocol = atoi(pPR_PROTOCOL);

	// copy diffserv
	if (pPR_DIFFSERV[0])
		policy_route.tos = atoi(pPR_DIFFSERV);

	// copy output interface
	if (pPR_OPIF[0] != '*')
		sprintf(policy_route.route_if, "%s", pPR_OPIF);

	if (strlen(pPR_GW_IP))
		policy_route.gw.s_addr = inet_addr(pPR_GW_IP);

	/* Set owner as WEB */
	policy_route.iid.config_owner = IFX_WEB;

	if (ifx_set_policy_route(IFX_OP_ADD, &policy_route, IFX_F_INT_ADD) !=
	    IFX_SUCCESS) {
		ifx_httpdError(wp, 400,
			       "Failed to add the specified policy route !!");
		return;
	}

	websNextPage(wp);
}

//510251: sumedh end (Policy based Routing)
#endif

#ifdef POLICY_ROUTING
int ifx_get_policy_routing(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name = NULL;
	char_t sValue[MAX_FILELINE_LEN];
	int i = 0;
	int32 ret = IFX_SUCCESS, num = 0;
	POLICY_ROUTE *policy_route = NULL;
#define FORMAT_LINE "\t\t\t\t<td nowrap align=center><font face=\"Arial, Helvetica, sans-serif\" size=\"2\">"

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	sValue[0] = '\0';

	if (!gstrcmp(name, T("prStatus"))) {
		//Get PR_STATUS# value from rc.firewall file.
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_POLICY_ROUTING_STATUS, "PR_STATUS",
		     sValue) == 1) {
			if (!gstrcmp(sValue, "1"))
				ifx_httpdWrite(wp, T("checked"));
			else
				ifx_httpdWrite(wp, T(""));
		} else
			ifx_httpdWrite(wp, T(""));
	} else if (!gstrcmp(name, T("Info"))) {
		ret =
		    ifx_get_all_policy_route_entries(&num, &policy_route,
						     IFX_F_DEFAULT);
		if (ret == IFX_SUCCESS) {
			for (i = 0; i < num && i < PLCY_ROUTING_NUM; i++) {
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t<tr bgcolor=\"#ffffff\" align=left>\n"));
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t<td nowrap align=center>%d</td>\n"),
					       i + 1);
				ifx_httpdWrite(wp, T(FORMAT_LINE));

				if (!gstrcmp
				    (inet_ntoa((policy_route + i)->ip_src.ip),
				     "0.0.0.0"))
					ifx_httpdWrite(wp,
						       T("%s</font></td>\n"),
						       "*");
				else
					ifx_httpdWrite(wp,
						       T("%s</font></td>\n"),
						       inet_ntoa((policy_route +
								  i)->ip_src.
								 ip));

				ifx_httpdWrite(wp, T(FORMAT_LINE));
				if ((policy_route + i)->src_ports.start_port ==
				    0)
					ifx_httpdWrite(wp,
						       T("*</font></td>\n"));
				else
					ifx_httpdWrite(wp,
						       T("%d</font></td>\n"),
						       (policy_route +
							i)->src_ports.
						       start_port);

				ifx_httpdWrite(wp, T(FORMAT_LINE));
				if (!gstrcmp
				    (inet_ntoa((policy_route + i)->ip_dst.ip),
				     "0.0.0.0"))
					ifx_httpdWrite(wp,
						       T("%s</font></td>\n"),
						       "*");
				else
					ifx_httpdWrite(wp,
						       T("%s</font></td>\n"),
						       inet_ntoa((policy_route +
								  i)->ip_dst.
								 ip));

				ifx_httpdWrite(wp, T(FORMAT_LINE));
				if ((policy_route + i)->dst_ports.start_port ==
				    0)
					ifx_httpdWrite(wp,
						       T("*</font></td>\n"));
				else
					ifx_httpdWrite(wp,
						       T("%d</font></td>\n"),
						       (policy_route +
							i)->dst_ports.
						       start_port);

				ifx_httpdWrite(wp, T(FORMAT_LINE));
				if ((policy_route + i)->tos == 0)
					ifx_httpdWrite(wp,
						       T("*</font></td>\n"));
				else
					ifx_httpdWrite(wp,
						       T("%d</font></td>\n"),
						       (policy_route + i)->tos);
				ifx_httpdWrite(wp, T("</font></td>\n"));

				ifx_httpdWrite(wp, T(FORMAT_LINE));
				if ((policy_route + i)->rt_protocol ==
				    PROTO_TCP) {
					ifx_httpdWrite(wp, T("TCP</font>\n"));
				} else if ((policy_route + i)->rt_protocol ==
					   PROTO_UDP) {
					ifx_httpdWrite(wp, T("UDP</font>\n"));
				} else if ((policy_route + i)->rt_protocol ==
					   PROTO_ICMP) {
					ifx_httpdWrite(wp, T("ICMP</font>\n"));
				} else if ((policy_route + i)->rt_protocol ==
					   PROTO_ESP) {
					ifx_httpdWrite(wp, T("ESP</font>\n"));
				} else if ((policy_route + i)->rt_protocol ==
					   PROTO_AH) {
					ifx_httpdWrite(wp, T("AH</font>\n"));
				} else {
					ifx_httpdWrite(wp, T("ALL</font>\n"));
				}

				ifx_httpdWrite(wp, T(FORMAT_LINE));
				if (strlen((policy_route + i)->route_if))
					ifx_httpdWrite(wp,
						       T("%s</font></td>\n"),
						       (policy_route +
							i)->route_if);
				else
					ifx_httpdWrite(wp,
						       T("*</font></td>\n"));

				ifx_httpdWrite(wp, T(FORMAT_LINE));
				if (gstrcmp
				    (inet_ntoa((policy_route + i)->gw),
				     "0.0.0.0"))
					ifx_httpdWrite(wp,
						       T("%s</font></td>\n"),
						       inet_ntoa((policy_route +
								  i)->gw));

				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t<td nowrap align=center><input type=\"checkbox\" name=\"PR_R%d\" value=\"1\"%s></td>\n"),
					       i,
					       (policy_route +
						i)->
					       f_enable ? " CHECKED" : " ");

				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t<td nowrap align=center>\n"));
				if (i < num) {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t<input type=\"button\" name=\"PR_DEL%d\" value=\" Delete \" onClick=\"return delEntry(%d);\">\n"),
						       i,
						       (policy_route +
							i)->iid.cpeId.Id);
				}
				ifx_httpdWrite(wp, T("\t\t\t\t</td></tr>\n"));

			}	//end for
		} else
			ifx_httpdError(wp, 500, T("Error"));
	}

	if (policy_route != NULL)
		free(policy_route);

	return 0;
}
#endif
