#include <ifx_emf.h>
#include "ifx_httpd_method.h"
#include <ifx_common.h>
#include "./ifx_amazon_cgi.h"

extern int ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);
extern int ifx_connect_to_acs();
extern void websNextPage(httpd_t wp);

#if defined(CONFIG_FEATURE_SMASH_SNMP) || defined(CONFIG_FEATURE_SNMPV1) || defined(CONFIG_FEATURE_SNMPV3) || defined (CONFIG_FEATURE_DSL_MANAGEMENT)
#define IFX_HAVE_SNMP
#include "ifx_snmp_api.h"
#endif

#ifdef IFX_HAVE_SNMP
void ifx_set_snmp_settings(httpd_t wp, char_t * path, char_t * query);	//snmp_settings.asp
#ifdef CONFIG_FEATURE_SNMPV3
#define trace(...)
extern int websGetCfgData2Table(httpd_t wp, const char_t * pFileName,
				char_t * pTag, const char_t * pSymbol,
				CGI_TABLE_S * pTable, int nTableType);
int websUpdate_SNMPv3User2File(int nSNMPv3UserDB_Size,
			       CGI_TABLE_S * SNMPv3UsersTable);
void ifx_set_snmpv3_settings(httpd_t wp, char_t * path, char_t * query);
void ifx_set_snmpv3_settings_add(httpd_t wp, char_t * path, char_t * query);
#endif				//CONFIG_FEATURE_SNMPV3
#endif				//IFX_HAVE_SNMP
#ifdef IFX_CONFIG_TR037
void ifx_set_wan_tr037(httpd_t wp, char_t * path, char_t * query);
#endif				//IFX_CONFIG_TR037
#ifdef IFX_HAVE_SNMP
int ifx_get_snmp_setting(int eid, httpd_t wp, int argc, char_t ** argv);	//snmp_settings.asp
int ifx_get_snmp_mib2_system_data(int eid, httpd_t wp, int argc, char_t ** argv);	//snmp_settings.asp
int ifx_get_snmp_transport_data(int eid, httpd_t wp, int argc, char_t ** argv);	//snmp_setting.asp
#ifdef CONFIG_FEATURE_SNMPV3
int ifx_get_snmpv3_status(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_snmpv3_users(int eid, httpd_t wp, int argc, char_t ** argv);
#endif
#endif
#ifdef IFX_CONFIG_TR037
int ifx_get_wan_tr037(int eid, httpd_t wp, int argc, char_t ** argv);
#endif				//IFX_CONFIG_TR037

MGMT_SERVER xMS;
TR69_MISC xtr69_misc;
DEVICE_INFO xDI;

int ifx_connect_to_acs()
{

	typedef struct {
		char ucFrom;
		unsigned char ucTo;
		unsigned int unMsgSize;
		unsigned int uiReserved;

	} xMsgHdr;

	typedef struct {
		xMsgHdr xHdr;
		char acMsg[1];
	} x_IPC_Msg;

	int iFd = 0;
	int iRet = 0;
	x_IPC_Msg xMsg;
	memset(&xMsg, 0, sizeof(xMsg));

	xMsg.xHdr.ucFrom = 100;	//pseudo server
	xMsg.xHdr.ucTo = 0;
	xMsg.xHdr.unMsgSize = 4;
	xMsg.xHdr.uiReserved = 0;
	iFd = open("/tmp/tr", O_RDWR);
	if (iFd < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("In Function [%s] : Failed to open /tmp/tr, retrun fd %d !!",
		     __FUNCTION__, iFd);
#endif
		return IFX_FAILURE;
	}

	if ((iRet = write(iFd, (char *)&xMsg, sizeof(x_IPC_Msg))) < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("In Function [%s] : Failed to write to /tmp/tr, retrun val %d !!",
		     __FUNCTION__, iRet);
#endif
		close(iFd);
		return IFX_FAILURE;
	}

#ifdef IFX_LOG_DEBUG
	IFX_DBG("In Function [%s] : Successfully wrote [%d] to /tmp/tr !!",
		__FUNCTION__, iRet);
#endif

	close(iFd);
	return IFX_SUCCESS;
}

//tr69_web.asp

#ifdef CONFIG_PACKAGE_IFX_DEVM

/* Management Server Set API */
void ifx_set_tr69_mgmtserver(httpd_t wp)
{
	char_t *pTR69_ON, *pTR64_ON, *pUPNP_ON, *pAAUTH, *pAURL, *pAUN, *pAPW, *operation,
	    *pTR69_PERINFENA, *pTR69_PERINFINT;
	char_t *pCRUN, *pCRPW, *pSTUN_ON, *pSURL, *pSPORT, *pSUN, *pSPW;
	int iRet = -1;
	MGMT_SERVER xMS;
	TR69_MISC xtr69_misc;



	a_assert(wp);

	operation = ifx_httpdGetVar(wp, T("operation"), T(""));
	IFX_DBG("In Function [%s] : operation is [%s] !!", __FUNCTION__,
		operation);
	if (!gstrcmp(operation, "acs_connect")) {
		if (ifx_connect_to_acs() != IFX_SUCCESS) {
			ifx_httpdError(wp, 500, "Fail to save Setting");
			IFX_DBG("In Function [%s] : Connect to acs failed !!",
				__FUNCTION__);
			return;
		}
	} else {

		// do a get using mgmtserver api
		iRet = ifx_get_mgmt_server_wrapper(&xMS, 0);
		if (iRet != 0) {
			ifx_httpdError(wp, 500, "Fail to get Settings");
			return;
		}

		iRet = ifx_get_tr69_misc_wrapper(&xtr69_misc, 0);
		if (iRet != 0) {
			ifx_httpdError(wp, 500, "Fail to get Settings");
			return;
		}
		pTR69_ON = ifx_httpdGetVar(wp, T("TR69_ON"), T(""));
		pTR64_ON = ifx_httpdGetVar(wp, T("TR64_ON"), T(""));
		pUPNP_ON = ifx_httpdGetVar(wp, T("UPNP_ON"), T(""));
		pAURL = ifx_httpdGetVar(wp, T("AURL"), T(""));
		pAAUTH = ifx_httpdGetVar(wp, T("AAUTH"), T(""));
		pAUN = ifx_httpdGetVar(wp, T("AUN"), T(""));
		pAPW = ifx_httpdGetVar(wp, T("APW"), T(""));

		pCRUN = ifx_httpdGetVar(wp, T("CRUN"), T(""));
		pCRPW = ifx_httpdGetVar(wp, T("CRPW"), T(""));

		pSTUN_ON = ifx_httpdGetVar(wp, T("STUN_ON"), T(""));
		pSURL = ifx_httpdGetVar(wp, T("SURL"), T(""));
		pSPORT = ifx_httpdGetVar(wp, T("SPORT"), T(""));
		pSUN = ifx_httpdGetVar(wp, T("SUN"), T(""));
		pSPW = ifx_httpdGetVar(wp, T("SPW"), T(""));

		pTR69_PERINFENA =
		    ifx_httpdGetVar(wp, T("TR69_PERINFENA"), T(""));
		pTR69_PERINFINT =
		    ifx_httpdGetVar(wp, T("TR69_PERINFINT"), T(""));

		// set the value using mgmtserver api
		if (pTR69_ON[0] == '1')
			xMS.enable_cwmp = 1;
		else
			xMS.enable_cwmp = 0;

		if (pTR64_ON[0] == '1')
			xtr69_misc.tr64_enable = 1;
		else
			xtr69_misc.tr64_enable = 0;

		if (pUPNP_ON[0] == '1')
			xtr69_misc.upnp_enable = 1;
		else
			xtr69_misc.upnp_enable = 0;

		if (pAAUTH[0] == '1')
			xtr69_misc.auth_acs = 1;
		else
			xtr69_misc.auth_acs = 0;

		gstrcpy(xMS.url, pAURL);
		gstrcpy(xMS.uname, pAUN);
		gstrcpy(xMS.passwd, pAPW);
		gstrcpy(xMS.conn_req_uname, pCRUN);
		gstrcpy(xMS.conn_req_passwd, pCRPW);

		if (pSTUN_ON[0] == '1')
			xMS.stun_enable = 1;
		else
			xMS.stun_enable = 0;

		// stun server address
		inet_aton(pSURL, &(xMS.stun_server_address));

		xMS.stun_server_port = atoi(pSPORT);
		gstrcpy(xMS.stun_server_uname, pSUN);
		gstrcpy(xMS.stun_passwd, pSPW);

		xMS.iid.config_owner = IFX_WEB;
		xtr69_misc.iid.config_owner = IFX_WEB;

		if (pTR69_PERINFENA[0] == '1')
			xMS.period_inform_enable = 1;
		else
			xMS.period_inform_enable = 0;
		xMS.period_inform_interval = atoi(pTR69_PERINFINT);

		IFX_DBG
		    ("In Function [%s] : calling ifx_set_tr69_misc_wrapper api !!",
		     __FUNCTION__);
		iRet = ifx_set_tr69_misc_wrapper(IFX_OP_MOD, &xtr69_misc, 0);
		if (iRet != 0) {
			ifx_httpdError(wp, 500, "Fail to save Setting");
			return;
		}
		IFX_DBG
		    ("In Function [%s] : returned from ifx_set_tr69_misc_wrapper api !!",
		     __FUNCTION__);

		IFX_DBG
		    ("In Function [%s] : calling ifx_set_mgmt_server_wrapper api !!",
		     __FUNCTION__);
		iRet = ifx_set_mgmt_server_wrapper(IFX_OP_MOD, &xMS, 0);
		if (iRet != 0) {
			ifx_httpdError(wp, 500, "Fail to save Setting");
			return;
		}
		IFX_DBG
		    ("In Function [%s] : returned from ifx_set_mgmt_server_wrapper api !!",
		     __FUNCTION__);

	}

	websNextPage(wp);
}
#endif

#ifdef CONFIG_PACKAGE_IFX_DEVM
// help function for tr69 get
//given a feature as string parameter, it tells whether it is enabled in the system config or not by returning 0
// return       write 0         match found
//              write 1         match not found
int ifx_get_macro_enabled(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name = NULL;
	int iRet = -1;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
#ifdef CONFG_FEATURE_IFX_TR69_STUN
	if (!strcasecmp(name, "STUN")) {
		ifx_httpdWrite(wp, T("%s"), "0");
		iRet = 0;	//found
	}
#endif

#ifdef CONFIG_FEATURE_IFX_LMP
	if (!strcasecmp(name, "TR64")) {
		ifx_httpdWrite(wp, T("%s"), "0");
		iRet = 0;	//found
	}
#endif
	if (iRet != 0) {
		ifx_httpdWrite(wp, T("%s"), "1");
	}

	return 0;
}

/* Management Server Get API */
int ifx_get_tr69_mgmtserver(int eid, httpd_t wp, int argc, char **argv)
{
	char_t *name, sValue[MAX_FILELINE_LEN];
	unsigned long int input, seconds, days, hours, minutes;
	char buffer[150];

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	if (!gstrcmp(name, T("OUI"))) {
		memset(&xMS, 0x00, sizeof(xMS));
		memset(&xDI, 0x00, sizeof(xDI));
		memset(&xtr69_misc, 0x00, sizeof(xtr69_misc));

		ifx_get_mgmt_server_wrapper(&xMS, 0);
		ifx_get_device_info_wrapper(&xDI, 0);
		ifx_get_tr69_misc_wrapper(&xtr69_misc, 0);

		// copy into sValue the name from mgmgtserver
		gstrcpy(sValue, xDI.oui);
		gstrcat(sValue, ":");
		gstrcat(sValue, xDI.serial_number);
		if (!gstrcmp(sValue, "0"))
			gstrcpy(sValue, "");

		ifx_httpdWrite(wp, T("%s"), sValue);
	} else if (!gstrcmp(name, T("Uptime"))) {
		input = (unsigned long int)xDI.uptime;
		seconds = ((unsigned long int)input % 60);
		days = input / (24 * 60 * 60);
		hours = (input - (days * 24 * 60 * 60)) / (60 * 60);
		minutes =
		    (input - (days * 24 * 60 * 60) - (hours * 60 * 60)) / 60;

		sprintf(buffer, " %ld days %ld hrs %ld mins %ld sec", days,
			hours, minutes, seconds);

		ifx_httpdWrite(wp, T("%s"), buffer);
	} else if (!gstrcmp(name, T("TR69_ON"))) {
		// copy into sValue the name from mgmgtserver
		if (xMS.enable_cwmp == 0)
			ifx_httpdWrite(wp, "value=\"1\"");
		else if (xMS.enable_cwmp == 1)
			ifx_httpdWrite(wp, "value=\"1\" checked");
	} else if (!gstrcmp(name, T("ACS_AUTH"))) {
		// copy into sValue the name from mgmgtserver
		if (xtr69_misc.auth_acs == 0)
			ifx_httpdWrite(wp, "value=\"1\"");
		else if (xtr69_misc.auth_acs == 1)
			ifx_httpdWrite(wp, "value=\"1\" checked");
	} else if (!gstrcmp(name, T("ACS_URL"))) {

		// copy into sValue the name from mgmgtserver
		gstrcpy(sValue, xMS.url);
		if (!gstrcmp(sValue, "0"))
			gstrcpy(sValue, "");
		ifx_httpdWrite(wp, T("%s"), sValue);
	} else if (!gstrcmp(name, T("ACS_UserName"))) {
		// copy into sValue the name from mgmgtserver
		gstrcpy(sValue, xMS.uname);
		if (!gstrcmp(sValue, "0"))
			gstrcpy(sValue, "");
		ifx_httpdWrite(wp, T("%s"), sValue);
	} else if (!gstrcmp(name, T("ACS_Password"))) {
		// copy into sValue the name from mgmgtserver
		gstrcpy(sValue, xMS.passwd);
		if (!gstrcmp(sValue, "0"))
			gstrcpy(sValue, "");
		ifx_httpdWrite(wp, T("%s"), sValue);
	} else if (!gstrcmp(name, T("CONN_UserName"))) {
		// copy into sValue the name from mgmgtserver
		gstrcpy(sValue, xMS.conn_req_uname);
		if (!gstrcmp(sValue, "0"))
			gstrcpy(sValue, "");
		ifx_httpdWrite(wp, T("%s"), sValue);
	} else if (!gstrcmp(name, T("CONN_Password"))) {
		// copy into sValue the name from mgmgtserver
		gstrcpy(sValue, xMS.conn_req_passwd);
		if (!gstrcmp(sValue, "0"))
			gstrcpy(sValue, "");
		ifx_httpdWrite(wp, T("%s"), sValue);
	} else if (!gstrcmp(name, T("TR64_ON"))) {
		// copy into sValue the name from mgmgtserver
		if (xtr69_misc.tr64_enable == 0)
			ifx_httpdWrite(wp, "'value=\"1\"'");
		else if (xtr69_misc.tr64_enable == 1)
			ifx_httpdWrite(wp, "'value=\"1\" checked'");
	} else if (!gstrcmp(name, T("UPNP_ON"))) {
		// copy into sValue the name from mgmgtserver
		if (xtr69_misc.upnp_enable == 0)
			ifx_httpdWrite(wp, "'value=\"1\"'");
		else if (xtr69_misc.upnp_enable == 1)
			ifx_httpdWrite(wp, "'value=\"1\" checked'");
	} else if (!gstrcmp(name, T("STUN_ON"))) {

		// copy into sValue the name from mgmgtserver
		if (xMS.stun_enable == 0)
			ifx_httpdWrite(wp, "'value=\"1\"'");
		else if (xMS.stun_enable == 1)
			ifx_httpdWrite(wp, "'value=\"1\" checked'");
	}

	else if (!gstrcmp(name, T("STUN_URL"))) {
		// copy into sValue the name from mgmgtserver
		gstrcpy(sValue, inet_ntoa(xMS.stun_server_address));
		if (!gstrcmp(sValue, "0"))
			gstrcpy(sValue, "");
		ifx_httpdWrite(wp, T("'%s'"), sValue);
	} else if (!gstrcmp(name, T("STUN_PORT"))) {
		// copy into sValue the name from mgmgtserver
		ifx_httpdWrite(wp, T("'%d'"), xMS.stun_server_port);
	} else if (!gstrcmp(name, T("STUN_UserName"))) {
		// copy into sValue the name from mgmgtserver
		gstrcpy(sValue, xMS.stun_server_uname);
		if (!gstrcmp(sValue, "0"))
			gstrcpy(sValue, "");
		ifx_httpdWrite(wp, T("'%s'"), sValue);
	} else if (!gstrcmp(name, T("STUN_Password"))) {
		// copy into sValue the name from mgmgtserver
		gstrcpy(sValue, xMS.stun_passwd);
		if (!gstrcmp(sValue, "0"))
			gstrcpy(sValue, "");
		ifx_httpdWrite(wp, T("'%s'"), sValue);
	} else if (!gstrcmp(name, T("TR69_PERINFENA"))) {

		if (xMS.period_inform_enable == 0)
			ifx_httpdWrite(wp, "value=\"1\"");
		else if (xMS.period_inform_enable == 1)
			ifx_httpdWrite(wp, "value=\"1\" checked");

	} else if (!gstrcmp(name, T("TR69_PERINFINT"))) {
		// copy into sValue the name from mgmgtserver
		ifx_httpdWrite(wp, T("%d"), xMS.period_inform_interval);

	}

	return 0;
}
#endif				// TR69_DEFINED

//end tr69_web.asp

//snmp_setting.asp

#ifdef IFX_HAVE_SNMP

//////////////////////////////////////////////////////////////////////////////////
// snmp_settings.asp
//
void ifx_set_snmp_settings(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pSNMPEnable, *pSNMProcommunity, *pSNMPrwcommunity,
	    *pSNMPTrapEnable, *pSNMPTrapIP, *pSNMPTrapPort, *pSNMPTrapCommunity;
	char_t sSNMPEnable[MAX_FILELINE_LEN],
	    sSNMProcommunity[MAX_FILELINE_LEN],
	    sSNMPrwcommunity[MAX_FILELINE_LEN],
	    sSNMPTrapEnable[MAX_FILELINE_LEN], sSNMPTrapIP[MAX_FILELINE_LEN],
	    sSNMPTrapPort[MAX_FILELINE_LEN],
	    sSNMPTrapCommunity[MAX_FILELINE_LEN];
	/* MIB2 System Data */
	char_t *pSysName, *pSysLocation, *pSysContact;
	char_t sSysName[MAX_FILELINE_LEN], sSysLocation[MAX_FILELINE_LEN],
	    sSysContact[MAX_FILELINE_LEN];

	/* SNMP Transport */
	char_t *pUDPEnable, *pUDPPort, *pPVCEnable, *pPVCVpi, *pPVCVci,
	    *pEOCEnable;
	char_t sUDPEnable[MAX_FILELINE_LEN], sUDPPort[MAX_FILELINE_LEN],
	    sPVCEnable[MAX_FILELINE_LEN], sPVCVpiVci[MAX_FILELINE_LEN],
	    sEOCEnable[MAX_FILELINE_LEN], sEOCVpiVci[MAX_FILELINE_LEN],
	    tmpPVCVpiVci[MAX_FILELINE_LEN];

	unsigned long iTrapPort = 0;
	bool bSNMPEnable = 0, bTrapEnable = 0, bUDPEnable = 1, bPVCEnable = 0;	// , bEOCEnable=0;
	snmp_config_data snmpdata;

	a_assert(wp);
	memset(&snmpdata, 0x00, sizeof(snmp_config_data));
	sSNMPEnable[0] = '\0';
	sSysName[0] = '\0';
	sSysLocation[0] = '\0';
	sSysContact[0] = '\0';
	sSNMProcommunity[0] = '\0';
	sSNMPrwcommunity[0] = '\0';
	sSNMPTrapEnable[0] = '\0';
	sSNMPTrapIP[0] = '\0';
	sSNMPTrapPort[0] = '\0';
	sSNMPTrapCommunity[0] = '\0';

	sUDPEnable[0] = '\0';
	sUDPPort[0] = '\0';
	sPVCEnable[0] = '\0';
	sPVCVpiVci[0] = '\0';
	sEOCEnable[0] = '\0';
	sEOCVpiVci[0] = '\0';

	IFX_DBG("[%s]:[%d]\n", __FUNCTION__, __LINE__);

	// Get value from ASP file
	pSNMPEnable = ifx_httpdGetVar(wp, T("SNMPEnable"), T(""));
	pSysName = ifx_httpdGetVar(wp, T("device_info_sysname"), T(""));
	pSysLocation = ifx_httpdGetVar(wp, T("device_info_syslocation"), T(""));
	pSysContact = ifx_httpdGetVar(wp, T("device_info_syscontact"), T(""));
	pSNMProcommunity = ifx_httpdGetVar(wp, T("SNMProcommunity"), T(""));
	pSNMPrwcommunity = ifx_httpdGetVar(wp, T("SNMPrwcommunity"), T(""));

	IFX_DBG("[%s]:[%d]\n", __FUNCTION__, __LINE__);
	/* Trap Info */
	pSNMPTrapEnable = ifx_httpdGetVar(wp, T("SNMPTrapEnable"), T(""));
	pSNMPTrapIP = ifx_httpdGetVar(wp, T("SNMPTrapIP"), T(""));
	pSNMPTrapPort = ifx_httpdGetVar(wp, T("SNMPTrapPort"), T(""));
	pSNMPTrapCommunity = ifx_httpdGetVar(wp, T("SNMPTrapCommunity"), T(""));

	IFX_DBG("[%s]:[%d]\n", __FUNCTION__, __LINE__);
	/* SNMP Transport Info */
	pUDPEnable = ifx_httpdGetVar(wp, T("SNMPTransportUDPEnable"), T(""));
	pUDPPort = ifx_httpdGetVar(wp, T("SNMPTransportUDP"), T(""));
	pPVCEnable = ifx_httpdGetVar(wp, T("SNMPTransportPVCEnable"), T(""));
	pPVCVpi = ifx_httpdGetVar(wp, T("SNMPTransportPVCVpi"), T(""));
	pPVCVci = ifx_httpdGetVar(wp, T("SNMPTransportPVCVci"), T(""));
	pEOCEnable = ifx_httpdGetVar(wp, T("SNMPTransportEOCEnable"), T(""));
	if ((pSNMPEnable) && (!gstrcmp(pSNMPEnable, "1")))
		gsprintf(sSNMPEnable, T("SNMPEnable=\"%s\"\n"), pSNMPEnable);
	else
		gsprintf(sSNMPEnable, T("SNMPEnable=\"0\"\n"));

	gsprintf(sSysName, T("device_info_sysname=\"%s\"\n"), pSysName);
	gsprintf(sSysLocation, T("device_info_syslocation=\"%s\"\n"),
		 pSysLocation);
	gsprintf(sSysContact, T("device_info_syscontact=\"%s\"\n"),
		 pSysContact);
	gsprintf(sSNMProcommunity, T("SNMProcommunity=\"%s\"\n"),
		 pSNMProcommunity);
	gsprintf(sSNMPrwcommunity, T("SNMPrwcommunity=\"%s\"\n"),
		 pSNMPrwcommunity);

	IFX_DBG("[%s]:[%d]\n", __FUNCTION__, __LINE__);
	if ((pSNMPTrapEnable) && (!gstrcmp(pSNMPTrapEnable, "1")))
		gsprintf(sSNMPTrapEnable, T("SNMPTrapEnable=\"%s\"\n"),
			 pSNMPTrapEnable);
	else
		gsprintf(sSNMPTrapEnable, T("SNMPTrapEnable=\"0\"\n"));

	gsprintf(sSNMPTrapIP, T("SNMPTrapIP=\"%s\"\n"), pSNMPTrapIP);
	gsprintf(sSNMPTrapPort, T("SNMPTrapPort=\"%s\"\n"), pSNMPTrapPort);
	gsprintf(sSNMPTrapCommunity, T("SNMPTrapCommunity=\"%s\"\n"),
		 pSNMPTrapCommunity);

	IFX_DBG("[%s]:[%d]\n", __FUNCTION__, __LINE__);
	ifx_SetCfgData(FILE_RC_CONF, TAG_SNMP_AGENT, 7, sSNMPEnable,
		       sSNMProcommunity, sSNMPrwcommunity, sSNMPTrapEnable,
		       sSNMPTrapIP, sSNMPTrapPort, sSNMPTrapCommunity);
	IFX_DBG("[%s]:[%d]\n", __FUNCTION__, __LINE__);
	/* Santosh: */
	// ifx_SetCfgData(FILE_RC_CONF, IFX_DEVICE_INFO_SECTION, 3, sSysName, sSysLocation, sSysContact);
	ifx_SetObjData(FILE_RC_CONF, IFX_DEVICE_INFO_SECTION, IFX_F_MODIFY, 3,
		       sSysName, sSysLocation, sSysContact);

	sSysName[0] = '\0';
	sSysLocation[0] = '\0';
	sSysContact[0] = '\0';
	gsprintf(sSysName, T("MIB2sysName=\"%s\"\n"), pSysName);
	gsprintf(sSysLocation, T("MIB2sysLocation=\"%s\"\n"), pSysLocation);
	gsprintf(sSysContact, T("MIB2sysContact=\"%s\"\n"), pSysContact);
	ifx_SetObjData(FILE_RC_CONF, TAG_MIB2_SYSTEM, IFX_F_MODIFY, 3, sSysName,
		       sSysLocation, sSysContact);

	IFX_DBG("[%s]:[%d]\n", __FUNCTION__, __LINE__);

	if ((pUDPEnable) && (!gstrcmp(pUDPEnable, "1")))
		gsprintf(sUDPEnable, T("SNMPTransportUDPEnable=\"%s\"\n"),
			 pUDPEnable);
	else
		gsprintf(sUDPEnable, T("SNMPTransportUDPEnable=\"0\"\n"));
	gsprintf(sUDPPort, T("SNMPTransportUDP=\"udp:%s\"\n"), pUDPPort);
	if ((pPVCEnable) && (!gstrcmp(pPVCEnable, "1")))
		gsprintf(sPVCEnable, T("SNMPTransportPVCEnable=\"%s\"\n"),
			 pPVCEnable);
	else
		gsprintf(sPVCEnable, T("SNMPTransportPVCEnable=\"0\"\n"));
	sprintf(tmpPVCVpiVci, "%s.%s", pPVCVpi, pPVCVci);
	gsprintf(sPVCVpiVci, T("SNMPTransportPVC=\"pvc:%s\"\n"), tmpPVCVpiVci);

	if (!gstrcmp(pEOCEnable, "1"))
		gsprintf(sEOCEnable, T("SNMPTransportEOCEnable=\"%s\"\n"),
			 pEOCEnable);
	else
		gsprintf(sEOCEnable, T("SNMPTransportEOCEnable=\"0\"\n"));
	gsprintf(sEOCVpiVci, T("SNMPTransportEOC=\"eoc:100.0.100\"\n"));

	IFX_DBG("[%s]:[%d]\n", __FUNCTION__, __LINE__);
	ifx_SetCfgData(FILE_RC_CONF, TAG_SNMP_TRANSPORT, 6, sUDPEnable,
		       sUDPPort, sPVCEnable, sPVCVpiVci, sEOCEnable,
		       sEOCVpiVci);
	IFX_DBG("[%s]:[%d]\n", __FUNCTION__, __LINE__);

	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}

	IFX_DBG("[%s]:[%d]\n", __FUNCTION__, __LINE__);
	//Runtime Change
	if (pSNMPEnable)
		bSNMPEnable = gatoi(pSNMPEnable);
	if (bSNMPEnable == 1) {
		snmpdata.bSNMPEnable = bSNMPEnable;
		if (pSysName)
			strcpy(snmpdata.sSysName, pSysName);
		if (pSysLocation)
			strcpy(snmpdata.sSysLocation, pSysLocation);
		if (pSysContact)
			strcpy(snmpdata.sSysContact, pSysContact);
		if (pSNMProcommunity)
			strcpy(snmpdata.sSNMProcommunity, pSNMProcommunity);
		if (pSNMPrwcommunity)
			strcpy(snmpdata.sSNMPrwcommunity, pSNMPrwcommunity);
		if (pSNMPTrapEnable) {
			bTrapEnable = gatoi(pSNMPTrapEnable);
			snmpdata.bTrapEnable = bTrapEnable;
		} else
			snmpdata.bTrapEnable = 0;
		if (pSNMPTrapIP)
			strcpy(snmpdata.sSNMPTrapIP, pSNMPTrapIP);
		if (pSNMPTrapPort) {
			iTrapPort = gatoi(pSNMPTrapPort);
			snmpdata.TrapPort = iTrapPort;
		}

		if (pSNMPTrapCommunity)
			strcpy(snmpdata.sSNMPTrapCommunity, pSNMPTrapCommunity);

		if (pUDPEnable) {
			bUDPEnable = gatoi(pUDPEnable);
			snmpdata.bUDPEnable = bUDPEnable;
		} else
			snmpdata.bUDPEnable = 0;
		if (pUDPPort)
			snmpdata.UDPPort = gatoi(pUDPPort);

		if (pPVCEnable) {
			bPVCEnable = gatoi(pPVCEnable);
			snmpdata.bPVCEnable = bPVCEnable;
		} else

			snmpdata.bPVCEnable = 0;

		if (pPVCVpi)
			snmpdata.PVCVpi = gatoi(pPVCVpi);
		if (pPVCVci)
			snmpdata.PVCVci = gatoi(pPVCVci);
		/*
		   if (pEOCEnable) {
		   bEOCEnable = gatoi(pEOCEnable);
		   snmpdata.bEOCEnable = bEOCEnable;
		   }
		   else
		 */
		snmpdata.bEOCEnable = 0;
		snmpdata.EOCVpi = 0;
		snmpdata.EOCVci = 100;

		//IFX_SNMPd_Set_Conf(pSNMProcommunity,pSNMPrwcommunity,&bTrapEnable,pSNMPTrapIP,&iTrapPort,pSNMPTrapCommunity);
		IFX_DBG("[%s]:[%d]\n", __FUNCTION__, __LINE__);
		IFX_SNMPd_Set_Conf(&snmpdata);
	}
	IFX_DBG("[%s]:[%d] bSNMPEnable:[%d]\n", __FUNCTION__, __LINE__,
		bSNMPEnable);
	IFX_SNMPd_Set_Enable(bSNMPEnable);
	IFX_DBG("[%s]:[%d]\n", __FUNCTION__, __LINE__);

	websNextPage(wp);
}

#ifdef CONFIG_FEATURE_SNMPV3

int websUpdate_SNMPv3User2File(int nSNMPv3UserDB_Size,
			       CGI_TABLE_S * SNMPv3UsersTable)
{
	int nIndex = 0, nSNMPv3Users_Counter = 0;
	char_t sBuf[BUF_SIZE_50K];
	sBuf[0] = '\0';

	//count the table size
	for (nIndex = 0; nIndex < nSNMPv3UserDB_Size; nIndex++) {
		if (SNMPv3UsersTable[nIndex].nIndex >= 0) {
			nSNMPv3Users_Counter++;
		}
	}

	gsprintf(sBuf, T("%sCount=\"%d\"\n"), PREFIX_SNMPv3_USER,
		 nSNMPv3Users_Counter);
	nSNMPv3Users_Counter = 0;

	// update data from table to file
	for (nIndex = 0; nIndex < nSNMPv3UserDB_Size; nIndex++) {
		if (SNMPv3UsersTable[nIndex].nIndex >= 0) {
			char_t sLine[MAX_FILELINE_LEN];

			gsprintf(sLine, T("%s%d=\"%d\"\n"), PREFIX_SNMPv3_USER,
				 nSNMPv3Users_Counter,
				 SNMPv3UsersTable[nIndex].nState);
			gstrcat(sBuf, sLine);

			gsprintf(sLine, T("%sUserName%d=\"%s\"\n"),
				 PREFIX_SNMPv3_USER, nSNMPv3Users_Counter,
				 SNMPv3UsersTable[nIndex].Data.
				 SNMPv3_USERS_TABLE.sSNMPv3_UserName);
			gstrcat(sBuf, sLine);

			gsprintf(sLine, T("%sUserAccess%d=\"%s\"\n"),
				 PREFIX_SNMPv3_USER, nSNMPv3Users_Counter,
				 SNMPv3UsersTable[nIndex].Data.
				 SNMPv3_USERS_TABLE.sSNMPv3_UserAccess);
			gstrcat(sBuf, sLine);

			gsprintf(sLine, T("%sSecLevel%d=\"%s\"\n"),
				 PREFIX_SNMPv3_USER, nSNMPv3Users_Counter,
				 SNMPv3UsersTable[nIndex].Data.
				 SNMPv3_USERS_TABLE.sSNMPv3_SecLevel);
			gstrcat(sBuf, sLine);

			gsprintf(sLine, T("%sAuthProto%d=\"%s\"\n"),
				 PREFIX_SNMPv3_USER, nSNMPv3Users_Counter,
				 SNMPv3UsersTable[nIndex].Data.
				 SNMPv3_USERS_TABLE.sSNMPv3_AuthProto);
			gstrcat(sBuf, sLine);
			gsprintf(sLine, T("%sAuthPasswd%d=\"%s\"\n"),
				 PREFIX_SNMPv3_USER, nSNMPv3Users_Counter,
				 SNMPv3UsersTable[nIndex].Data.
				 SNMPv3_USERS_TABLE.sSNMPv3_AuthPasswd);
			gstrcat(sBuf, sLine);

			gsprintf(sLine, T("%sPrivProto%d=\"%s\"\n"),
				 PREFIX_SNMPv3_USER, nSNMPv3Users_Counter,
				 SNMPv3UsersTable[nIndex].Data.
				 SNMPv3_USERS_TABLE.sSNMPv3_PrivProto);
			gstrcat(sBuf, sLine);

			gsprintf(sLine, T("%sPrivPasswd%d=\"%s\"\n"),
				 PREFIX_SNMPv3_USER, nSNMPv3Users_Counter,
				 SNMPv3UsersTable[nIndex].Data.
				 SNMPv3_USERS_TABLE.sSNMPv3_PrivPasswd);
			gstrcat(sBuf, sLine);

			nSNMPv3Users_Counter++;
		}
	}
	return (ifx_SetCfgData(FILE_RC_CONF, TAG_SNMPv3_USERDB, 1, sBuf));
}

void ifx_set_snmpv3_settings(httpd_t wp, char_t * path, char_t * query)
{
	char_t buf[MAX_DATA_LEN], sSNMPv3Enable[MAX_DATA_LEN];
	CGI_TABLE_S SNMPv3UsersTable[SNMPv3_USERS_NUM];
	int nIndex, nSNMPv3UserDB_Size = 0;
	char_t *pSNMPv3Enable;
	char_t *pDel = ifx_httpdGetVar(wp, T("delflag"), T(""));
	char_t sSNMPv3User_UserName[MAX_DATA_LEN];

	a_assert(wp);

	sSNMPv3Enable[0] = '\0';
	pSNMPv3Enable = ifx_httpdGetVar(wp, T("SNMPv3Enable"), T(""));

	if (!gstrcmp(pSNMPv3Enable, T("1")))
		gsprintf(sSNMPv3Enable, T("SNMPv3Enable=\"1\"\n"));
	else
		gsprintf(sSNMPv3Enable, T("SNMPv3Enable=\"0\"\n"));
	ifx_SetCfgData(FILE_RC_CONF, TAG_SNMPv3_STATUS, 1, sSNMPv3Enable);
	// Get the SNMPv3 UserDatabase from file
	buf[0] = '\0';
	nSNMPv3UserDB_Size =
	    websGetCfgData2Table(wp, FILE_RC_CONF, TAG_SNMPv3_USERDB,
				 PREFIX_SNMPv3_USER, SNMPv3UsersTable,
				 SNMPv3_USER_TABLE_TYPE);
	if (nSNMPv3UserDB_Size == -1) {
		ifx_httpdError(wp, 500,
			       "Insufficient data for SNMPv3 UserDatabase");
		return;
	}
	// Submit data from delete button pressed
	if (!gstrcmp(pDel, T("1"))) {
		char_t *pDelIndex = ifx_httpdGetVar(wp, T("delindex"), T(""));
		int nDelIndex = gatoi(pDelIndex);
		trace(8, "Del table\n");

		// Get to know which user needs to be deleted
		sSNMPv3User_UserName[0] = '\0';
		gstrcpy(sSNMPv3User_UserName,
			SNMPv3UsersTable[nDelIndex].Data.SNMPv3_USERS_TABLE.
			sSNMPv3_UserName);

		// Remove DelIndex form Table
		for (nIndex = nDelIndex + 1; nIndex < nSNMPv3UserDB_Size;
		     nIndex++)
			SNMPv3UsersTable[nIndex].nIndex--;
		SNMPv3UsersTable[nDelIndex].nIndex = -1;

		if (IFX_delete_snmpv3_user(sSNMPv3User_UserName)) {

			//Update SNMPv3 UserDatabase in persistent store
			websUpdate_SNMPv3User2File(nSNMPv3UserDB_Size,
						   SNMPv3UsersTable);

		} else {
			ifx_httpdError(wp, 500, "Unable to delete User:%s",
				       T("sSNMPv3User_UserName"));
			return;
		}
	}
	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}
	websNextPage(wp);
}

// PAGE :snmpv3_settings_add.asp
void ifx_set_snmpv3_settings_add(httpd_t wp, char_t * path, char_t * query)
{
	CGI_TABLE_S SNMPv3UsersTable[SNMPv3_USERS_NUM];
	int nSNMPv3UserDB_Size = 0;
//  char_t  sCommand[MAX_DATA_LEN];
	char_t *pSNMPv3User_UserAccess =
	    ifx_httpdGetVar(wp, T("SNMPv3User_UserAccess"), T(""));
	char_t *pSNMPv3User_UserName =
	    ifx_httpdGetVar(wp, T("SNMPv3User_UserName"), T(""));
	char_t *pSNMPv3User_SecLevel =
	    ifx_httpdGetVar(wp, T("SNMPv3User_SecLevel"), T(""));
	char_t *pSNMPv3User_AuthProto =
	    ifx_httpdGetVar(wp, T("SNMPv3User_AuthProto"), T(""));
	char_t *pSNMPv3User_AuthPasswd =
	    ifx_httpdGetVar(wp, T("SNMPv3User_AuthPasswd"), T(""));
	char_t *pSNMPv3User_PrivProto =
	    ifx_httpdGetVar(wp, T("SNMPv3User_PrivProto"), T(""));
	char_t *pSNMPv3User_PrivPasswd =
	    ifx_httpdGetVar(wp, T("SNMPv3User_PrivPasswd"), T(""));

	nSNMPv3UserDB_Size =
	    websGetCfgData2Table(wp, FILE_RC_CONF, TAG_SNMPv3_USERDB,
				 PREFIX_SNMPv3_USER, SNMPv3UsersTable,
				 SNMPv3_USER_TABLE_TYPE);
	if (nSNMPv3UserDB_Size >= SNMPv3_USERS_NUM) {
		ifx_httpdError(wp, 500, T("Out of space to add SNMPv3 User"));
		return;
	}
// copy data to SNMPv3 User Table
	memset(&SNMPv3UsersTable[nSNMPv3UserDB_Size], 0x00,
	       sizeof(CGI_TABLE_S));
	SNMPv3UsersTable[nSNMPv3UserDB_Size].nIndex =
	    SNMPv3UsersTable[nSNMPv3UserDB_Size - 1].nIndex + 1;
	SNMPv3UsersTable[nSNMPv3UserDB_Size].nState = 1;

	gstrcpy(SNMPv3UsersTable[nSNMPv3UserDB_Size].Data.SNMPv3_USERS_TABLE.
		sSNMPv3_UserName, pSNMPv3User_UserName);
	gstrcpy(SNMPv3UsersTable[nSNMPv3UserDB_Size].Data.SNMPv3_USERS_TABLE.
		sSNMPv3_UserAccess, pSNMPv3User_UserAccess);
	gstrcpy(SNMPv3UsersTable[nSNMPv3UserDB_Size].Data.SNMPv3_USERS_TABLE.
		sSNMPv3_SecLevel, pSNMPv3User_SecLevel);
	if (!gstrcmp(pSNMPv3User_SecLevel, "noauth")) {
		pSNMPv3User_AuthProto = NULL;
		gsprintf(SNMPv3UsersTable[nSNMPv3UserDB_Size].Data.
			 SNMPv3_USERS_TABLE.sSNMPv3_AuthProto, " ");
		pSNMPv3User_AuthPasswd = NULL;
		gsprintf(SNMPv3UsersTable[nSNMPv3UserDB_Size].Data.
			 SNMPv3_USERS_TABLE.sSNMPv3_AuthPasswd, " ");
		pSNMPv3User_PrivProto = NULL;
		gsprintf(SNMPv3UsersTable[nSNMPv3UserDB_Size].Data.
			 SNMPv3_USERS_TABLE.sSNMPv3_PrivProto, " ");
		pSNMPv3User_PrivPasswd = NULL;
		gsprintf(SNMPv3UsersTable[nSNMPv3UserDB_Size].Data.
			 SNMPv3_USERS_TABLE.sSNMPv3_PrivPasswd, " ");
	} else if (!gstrcmp(pSNMPv3User_SecLevel, "auth")) {
		gstrcpy(SNMPv3UsersTable[nSNMPv3UserDB_Size].Data.
			SNMPv3_USERS_TABLE.sSNMPv3_AuthProto,
			pSNMPv3User_AuthProto);
		gstrcpy(SNMPv3UsersTable[nSNMPv3UserDB_Size].Data.
			SNMPv3_USERS_TABLE.sSNMPv3_AuthPasswd,
			pSNMPv3User_AuthPasswd);
		pSNMPv3User_PrivProto = NULL;
		gsprintf(SNMPv3UsersTable[nSNMPv3UserDB_Size].Data.
			 SNMPv3_USERS_TABLE.sSNMPv3_PrivProto, " ");
		pSNMPv3User_PrivPasswd = NULL;
		gsprintf(SNMPv3UsersTable[nSNMPv3UserDB_Size].Data.
			 SNMPv3_USERS_TABLE.sSNMPv3_PrivPasswd, " ");
	} else {
		gstrcpy(SNMPv3UsersTable[nSNMPv3UserDB_Size].Data.
			SNMPv3_USERS_TABLE.sSNMPv3_AuthProto,
			pSNMPv3User_AuthProto);
		gstrcpy(SNMPv3UsersTable[nSNMPv3UserDB_Size].Data.
			SNMPv3_USERS_TABLE.sSNMPv3_AuthPasswd,
			pSNMPv3User_AuthPasswd);
		gstrcpy(SNMPv3UsersTable[nSNMPv3UserDB_Size].Data.
			SNMPv3_USERS_TABLE.sSNMPv3_PrivProto,
			pSNMPv3User_PrivProto);
		gstrcpy(SNMPv3UsersTable[nSNMPv3UserDB_Size].Data.
			SNMPv3_USERS_TABLE.sSNMPv3_PrivPasswd,
			pSNMPv3User_PrivPasswd);
	}

	nSNMPv3UserDB_Size++;
	// Update the information in snmpd.conf
	if (IFX_add_snmpv3_user(pSNMPv3User_UserName, pSNMPv3User_UserAccess,
				pSNMPv3User_AuthProto, pSNMPv3User_AuthPasswd,
				pSNMPv3User_PrivProto,
				pSNMPv3User_PrivPasswd)) {

		// Update SNMPv3 Users to persistent store
		websUpdate_SNMPv3User2File(nSNMPv3UserDB_Size,
					   SNMPv3UsersTable);

		// save persistent store settings
		if (ifx_flash_write() <= 0) {
			ifx_httpdError(wp, 500,
				       "Failed to save SNMPv3 Setting");
			return;
		}
	} else {
		ifx_httpdError(wp, 500, "Failed to add SNMPv3 User");
		return;
	}

	websNextPage(wp);
}
#endif				//CONFIG_FEATURE_SNMPV3  Subbi SNMPv3 User Add

#endif				//IFX_HAVE_SNMP

#ifdef IFX_HAVE_SNMP
//////////////////////////////////////////////////////////////////////////////////
// snmp_setting.asp
//
int ifx_get_snmp_setting(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
	char_t sValue[MAX_FILELINE_LEN];
	char_t command[MAX_FILELINE_LEN];
	char_t *snmp_parameter_list[] =
	    { "SNMProcommunity", "SNMPrwcommunity", "SNMPTrapIP",
"SNMPTrapPort", "SNMPTrapCommunity" };
	char_t *snmp_enable_parameter_list[] =
	    { "SNMPEnable", "SNMPTrapEnable" };
	int index = 0;

	sValue[0] = '\0';
	command[0] = '\0';

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	for (index = 0; index < 2; index++) {
		if (!gstrcmp(name, snmp_enable_parameter_list[index])) {
			if (ifx_GetCfgData
			    (FILE_RC_CONF, TAG_SNMP_AGENT,
			     snmp_enable_parameter_list[index], sValue) == 0) {
				ifx_httpdError(wp, 500, "SNMPEnable not found");
				return -1;
			}
			if (sValue[0] == '1')
				ifx_httpdWrite(wp, T("checked"));
			else
				ifx_httpdWrite(wp, T(""));
		}
	}
	for (index = 0; index < 5; index++) {
		if (!gstrcmp(name, snmp_parameter_list[index])) {
			if (ifx_GetCfgData
			    (FILE_RC_CONF, TAG_SNMP_AGENT,
			     snmp_parameter_list[index], sValue) == 0) {
				ifx_httpdError(wp, 500, T("%s not found"),
					       snmp_parameter_list[index]);
				return -1;
			}
			ifx_httpdWrite(wp, T("%s"), sValue);
		}
	}

	return 0;
}

int ifx_get_snmp_mib2_system_data(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
	char_t sValue[MAX_FILELINE_LEN];
	char_t command[MAX_FILELINE_LEN];
	char_t *snmp_mib2_parameter_list[] =
	    { "MIB2sysName", "MIB2sysLocation", "MIB2sysContact" };
	int index = 0;

	sValue[0] = '\0';
	command[0] = '\0';

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	for (index = 0; index < 3; index++) {
		if (!gstrcmp(name, snmp_mib2_parameter_list[index])) {
			if (ifx_GetCfgData
			    (FILE_RC_CONF, TAG_MIB2_SYSTEM,
			     snmp_mib2_parameter_list[index], sValue) == 0) {
				ifx_httpdError(wp, 500, T("%s not found"),
					       snmp_mib2_parameter_list[index]);
				return -1;
			}
			ifx_httpdWrite(wp, T("%s"), sValue);
		}
	}
	return 0;
}

int ifx_get_snmp_transport_data(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
	char_t sValue[MAX_FILELINE_LEN];
	char_t command[MAX_FILELINE_LEN];
	unsigned long udp_port = 0;

	sValue[0] = '\0';
	command[0] = '\0';

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	if (!gstrcmp(name, "SNMPTransportUDPEnable")) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_SNMP_TRANSPORT, "SNMPTransportUDPEnable",
		     sValue) == 0) {
			ifx_httpdError(wp, 500, T("%s not found"),
				       "SNMPTransportUDPEnable");
			return -1;
		}
		if (sValue[0] == '1')
			ifx_httpdWrite(wp, T("checked"));
		else
			ifx_httpdWrite(wp, T(""));
	}

	if (!gstrcmp(name, "SNMPTransportUDP")) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_SNMP_TRANSPORT, "SNMPTransportUDP",
		     sValue) == 0) {
			ifx_httpdError(wp, 500, T("%s not found"),
				       "SNMPTransportUDP");
			return -1;
		}
		sscanf(sValue, "udp:%ld", &udp_port);
		sprintf(sValue, "%ld\n", udp_port);
		ifx_httpdWrite(wp, T("%s"), sValue);
	}
#ifdef CONFIG_FEATURE_SNMP_TRANSPORT_ATMPVC_DOMAIN
	//Generate the ATM PVC transport & fill in the VPI/VCI data
	if (!gstrcmp(name, "atmpvc_info")) {
		ifx_httpdWrite(wp,
			       T
			       ("<td><font class=\"subtitle\">ATM PVC</font></td>"));
		ifx_httpdWrite(wp, T("<td><font class=\"subtitile\">"));
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_SNMP_TRANSPORT, "SNMPTransportPVCEnable",
		     sValue) == 0) {
			ifx_httpdError(wp, 500, T("%s not found"),
				       "SNMPTransportPVCEnable");
			return -1;
		}
		ifx_httpdWrite(wp,
			       T
			       ("<input type=CHECKBOX name=\"SNMPTransportPVCEnable\" onClick=\"ChangeStatus();\" value=1 %s>"),
			       sValue[0] == '1' ? "checked" : "");
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp,
			       T
			       ("<td><font class=\"subtitle\">VPI</font></td>"));
		ifx_httpdWrite(wp, T("<td><font class=\"subtitile\">"));
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_SNMP_TRANSPORT, "SNMPTransportPVC",
		     sValue) == 0) {
			ifx_httpdError(wp, 500, T("%s not found"),
				       "SNMPTransportPVC");
			return -1;
		}
		ifx_httpdWrite(wp,
			       T("<input type=hidden name=\"PVC\" value = %s>"),
			       sValue);
		ifx_httpdWrite(wp,
			       T
			       ("<input type=text name=\"SNMPTransportPVCVpi\" size=\"7\" maxlength=\"3\" value=\"\" >"));
		ifx_httpdWrite(wp, T("</td>"));
		ifx_httpdWrite(wp,
			       T
			       ("<td><font class=\"subtitle\">VCI</font></td>"));
		ifx_httpdWrite(wp, T("<td><font class=\"subtitile\">"));
		ifx_httpdWrite(wp,
			       T
			       ("<input type=text name=\"SNMPTransportPVCVci\" size=\"7\" maxlength=\"3\" value=\"\" >"));
		ifx_httpdWrite(wp, T("</td>"));
	}
#ifdef CONFIG_FEATURE_SNMP_TRANSPORT_EOC_DOMAIN
	//Generate the Clear EOC transport
	if (!gstrcmp(name, "cleareoc_info")) {
		ifx_httpdWrite(wp,
			       T
			       ("<td><font class=\"subtitle\">Clear EOC</font></td>"));
		ifx_httpdWrite(wp, T("<td><font class=\"subtitile\">"));
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_SNMP_TRANSPORT, "SNMPTransportEOCEnable",
		     sValue) == 0) {
			ifx_httpdError(wp, 500, T("%s not found"),
				       "SNMPTransportEOCEnable");
			return -1;
		}
		ifx_httpdWrite(wp,
			       T
			       ("<input type=CHECKBOX name=\"SNMPTransportEOCEnable\" onClick=\"ChangeStatus();\" value=1 %s>"),
			       sValue[0] == '1' ? "checked" : "");
		ifx_httpdWrite(wp, T("</td>"));
	}
#endif				/* EOC_DOMAIN */

#endif				/* ATMPVC_DOMAIN */

	return 0;
}

#ifdef CONFIG_FEATURE_SNMPV3

int ifx_get_snmpv3_status(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_FILELINE_LEN];
	char_t command[MAX_FILELINE_LEN];
	char_t *name;

	sValue[0] = '\0';
	command[0] = '\0';
	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_SNMPv3_STATUS, T("SNMPv3Enable"), sValue) == 0) {
		ifx_httpdError(wp, 500, "SNMPv3Enable not found");
		return -1;
	}
	if (sValue[0] == name[0])
		ifx_httpdWrite(wp, T("checked"));
	else
		ifx_httpdWrite(wp, T(""));
	return 0;
}

int ifx_get_snmpv3_users(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
	char_t buf[MAX_DATA_LEN], sValue[MAX_FILELINE_LEN];
	char_t SecLevel[MAX_FILELINE_LEN], UserAccess[MAX_FILELINE_LEN];
	int i = 0, nSNMPv3UserDB_Size = 0;
	CGI_TABLE_S SNMPv3UsersTable[SNMPv3_USERS_NUM];
#define FORMAT_LINE "\t\t\t\t<td nowrap align=center><font face=\"Arial, Helvetica, sans-serif\" size=\"2\">"

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	if (!gstrcmp(name, T("count"))) {
		nSNMPv3UserDB_Size =
		    websGetCfgData2Table(wp, FILE_RC_CONF, TAG_SNMPv3_USERDB,
					 PREFIX_SNMPv3_USER, SNMPv3UsersTable,
					 SNMPv3_USER_TABLE_TYPE);
		ifx_httpdWrite(wp, T("%d"), nSNMPv3UserDB_Size);
	}
	buf[0] = '\0';
	if (!gstrcmp(name, T("SNMPv3UDB"))) {
		nSNMPv3UserDB_Size =
		    websGetCfgData2Table(wp, FILE_RC_CONF, TAG_SNMPv3_USERDB,
					 PREFIX_SNMPv3_USER, SNMPv3UsersTable,
					 SNMPv3_USER_TABLE_TYPE);

		for (i = 0; i < nSNMPv3UserDB_Size && i < SNMPv3_USERS_NUM; i++) {
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t<tr bgcolor=\"#ffffff\" align=left>\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t<td nowrap align=center>%d</td>\n"),
				       i + 1);
			ifx_httpdWrite(wp, T(FORMAT_LINE));
			ifx_httpdWrite(wp, T("%s</font></td>\n"),
				       SNMPv3UsersTable[i].Data.
				       SNMPv3_USERS_TABLE.sSNMPv3_UserName);

			ifx_httpdWrite(wp, T(FORMAT_LINE));
			sValue[0] = '\0';
			UserAccess[0] = '\0';
			strcpy(UserAccess,
			       SNMPv3UsersTable[i].Data.SNMPv3_USERS_TABLE.
			       sSNMPv3_UserAccess);
			if (!strcmp(UserAccess, "rouser"))
				sprintf(sValue, "Read-Only");
			else
				sprintf(sValue, "Read-Write");
			ifx_httpdWrite(wp, T("%s</font></td>\n"), sValue);

			ifx_httpdWrite(wp, T(FORMAT_LINE));
			sValue[0] = '\0';
			SecLevel[0] = '\0';
			strcpy(SecLevel,
			       SNMPv3UsersTable[i].Data.SNMPv3_USERS_TABLE.
			       sSNMPv3_SecLevel);
			if (!strcmp(SecLevel, "noauth"))
				sprintf(sValue, "NoAuth,NoPriv");
			else if (!strcmp(SecLevel, "auth"))
				sprintf(sValue, "Auth,NoPriv");
			else
				sprintf(sValue, "Auth,Priv");
			ifx_httpdWrite(wp, T("%s</font></td>\n"), sValue);

			ifx_httpdWrite(wp, T(FORMAT_LINE));
			ifx_httpdWrite(wp, T("%s</font></td>\n"),
				       SNMPv3UsersTable[i].Data.
				       SNMPv3_USERS_TABLE.sSNMPv3_AuthProto);
			ifx_httpdWrite(wp, T(FORMAT_LINE));
			ifx_httpdWrite(wp, T("%s</font></td>\n"),
				       SNMPv3UsersTable[i].Data.
				       SNMPv3_USERS_TABLE.sSNMPv3_PrivProto);

			ifx_httpdWrite(wp,
				       T("\t\t\t\t<td nowrap align=center>\n"));
			if (i < nSNMPv3UserDB_Size) {
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t<input type=\"button\" name=\"SNMPv3_UserDel%d\" value=\" Delete \" onClick=\"return delEntry(%d);\">\n"),
					       i, i);
			}
			ifx_httpdWrite(wp, T("\t\t\t\t</td></tr>\n"));

		}		//end for
	}

	return 0;
}

#endif				/* CONFIG_FEATURE_SNMPV3 */

#endif				/* IFX_HAVE_SNMP */

//end snmp_settings.asp

//tr037.asp

#ifdef IFX_CONFIG_TR037
////////////////////////////////////////////////////////////////////////////////
// tr037.asp
//
void ifx_set_wan_tr037(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pCheck;
	char_t sCheck[6][MAX_FILELINE_LEN];
	char_t sParams[][32] = {
		"TR037_PROTO",
#ifdef CONFIG_PACKAGE_PPP_MOD_PPPOA
		"TR037_UN", "TR037_PW",
#endif				//CONFIG_PACKAGE_PPP_MOD_PPPOA
		"TR037_IP", "TR037_NM", "TR037_GW"
	};
	int i = 0, j = 0;;
	int proto = 0;
	int sParams_length = 1;

#ifdef CONFIG_PACKAGE_PPP_MOD_PPPOA
	sParams_length += 2;
#endif
	sParams_length += 3;

	a_assert(wp);
	sCheck[0] = '\0';

#ifdef CONFIG_PACKAGE_PPP_MOD_PPPOA
	for (i = 0; i < 3; i++)
#endif				//CONFIG_PACKAGE_PPP_MOD_PPPOA
	{
		// Get value from ASP file
		pCheck = ifx_httpdGetVar(wp, sParams[i], T(""));
		gsprintf(sCheck[i], "%s=\"%s\"\n", sParams[i], pCheck);
		if (i == 0) {
#ifdef CONFIG_PACKAGE_PPP_MOD_PPPOA
			if (!strcmp(pCheck, "PPPOA")) {
				proto = IP_BOOT_PPPOA;
			}
#endif				//CONFIG_PACKAGE_PPP_MOD_PPPOA
			if (!strcmp(pCheck, "BR2684")) {
				proto = IP_BOOT_FIXED;
			}
		}
	}

#ifdef CONFIG_PACKAGE_PPP_MOD_PPPOA
	for (i = 3; i < sParams_length; i++)
#else
	for (i = 1; i < sParams_length; i++)
#endif				//CONFIG_PACKAGE_PPP_MOD_PPPOA
	{
		char IP[MAX_FILELINE_LEN];
		IP[0] = '\0';
		for (j = 1; j < 5; j++) {
			char VarName[MAX_FILELINE_LEN];
			sprintf(VarName, "%s%d", sParams[i], j);
			pCheck = ifx_httpdGetVar(wp, VarName, T(""));
			if (strlen(pCheck) > 0) {
				if (atoi(pCheck) > 255
				    || (atoi(pCheck) <= 0
					&& pCheck[0] != '0')) {
					ifx_httpdError(wp, 400,
						       "Invalidate IP address");
					return;
				}
				strcat(IP, pCheck);
				if (j != 4)
					strcat(IP, ".");
			} else {
				if (proto == IP_BOOT_FIXED) {
					ifx_httpdError(wp, 400,
						       "Invalidate IP address");
					return;
				}
				sprintf(IP, " ");
				break;
			}
		}
		gsprintf(sCheck[i], "%s=\"%s\"\n", sParams[i], IP);
	}
	system(SERVICE_WAN_STOP);
	ifx_SetCfgData(FILE_RC_CONF, TAG_WAN_TR037, 6, sCheck[0], sCheck[1],
		       sCheck[2], sCheck[3], sCheck[4], sCheck[5]);
	// Update Wan Mode to rc.conf
	gsprintf(sCheck[0], "ipoption_wan=\"TR037\"\n");
	ifx_SetCfgData(FILE_RC_CONF, TAG_WAN_MAIN, 1, sCheck[0]);

	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}
	//Runtime Change
	system(SERVICE_WAN_START);

	websNextPage(wp);
}
#endif				//IFX_CONFIG_TR037

////////////////////////////////////////////////////////////////////////////////
// tr037.asp
////////////////////////////////////////////////////////////////////////////////
#ifdef IFX_CONFIG_TR037
int ifx_get_wan_tr037(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_FILELINE_LEN];
	char_t *name, tmp_name[MAX_FILELINE_LEN];

	sValue[0] = '\0';

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	if (!gstrncmp(name, "TR037_IP", 8) || !gstrncmp(name, "TR037_NM", 8)
	    || !gstrncmp(name, "TR037_GW", 8)) {
		memset(tmp_name, 0, sizeof(tmp_name));
		memcpy(tmp_name, name, 8);
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WAN_TR037, tmp_name, sValue) == 1) {
			char *delim = ". \n";
			char *pValue;
			int i = 0;
			pValue = strtok(sValue, delim);
			if (name[8] == '1') {
				if (pValue == NULL) {
					ifx_httpdWrite(wp, T(" "));
					return 0;
				}
				ifx_httpdWrite(wp, T("%s"), pValue);
			}
			for (i = 1; i < 4; i++) {
				pValue = strtok(NULL, delim);
				if (pValue == NULL) {
					ifx_httpdWrite(wp, T(" "));
					return 0;
				}
				if (i == name[8] - '1') {
					ifx_httpdWrite(wp, T("%s"), pValue);
					return 0;
				}
			}
		}

	} else if (ifx_GetCfgData(FILE_RC_CONF, TAG_WAN_TR037, name, sValue) ==
		   1) {
		if (!gstrcmp(name, "TR037_PROTO")) {
			int proto_type = IP_BOOT_UNKNOWN;
#ifdef CONFIG_PACKAGE_PPP_MOD_PPPOA
			if (!gstrcmp(sValue, "PPPOA")) {
				proto_type = IP_BOOT_PPPOA;
			}
#endif				//CONFIG_PACKAGE_PPP_MOD_PPPOA
#ifdef CONFIG_PACKAGE_BR2684CTL
			if (!gstrcmp(sValue, "BR2684")) {
				proto_type = IP_BOOT_FIXED;
			}
#endif				//CONFIG_PACKAGE_BR2684CTL
#ifdef CONFIG_FEATURE_CLIP
			if (!gstrcmp(sValue, "CLIP")) {
				proto_type = IP_BOOT_FIXED;
			}
#endif				//CONFIG_FEATURE_CLIP
			gsprintf(sValue, "%d", proto_type);
			ifx_httpdWrite(wp, sValue);
			return 0;
		}
		ifx_httpdWrite(wp, T("%s"), sValue);
		return 0;
	}

	return 0;
}
#endif				//IFX_CONFIG_TR037

//end tr037.asp
