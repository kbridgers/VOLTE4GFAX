#include <ifx_emf.h>
#include "ifx_httpd_method.h"
#include "./ifx_amazon_cgi.h"
#include "./ifx_amazon_cgi_getFunctions.h"
#include "./ifx_cgi_common.h"

//For diagnostics web page
int lan_ping_return = 0;
int vcc_ping_return = 0;
int gateway_ping_return = 0;
int primdns_ping_return = 0;
int adsl_return = 0;
bool diag_complete = FALSE, bFlag = FALSE;

extern void websNextPage(httpd_t wp);

//For diagnostics web page
void ifx_diag_get_status(httpd_t wp, int id);
int ifx_diag_get_lan_status(int eid, httpd_t wp, int argc, char_t ** argv);
void ifx_diag_oam_ping();
void ifx_diag_lan_ping_return(int eid, httpd_t wp, int argc, char_t ** argv);
void ifx_diag_vcc_ping_return(int eid, httpd_t wp, int argc, char_t ** argv);
void ifx_diag_gateway_ping_return(int eid, httpd_t wp, int argc,
				  char_t ** argv);
void ifx_diag_primdns_ping_return(int eid, httpd_t wp, int argc,
				  char_t ** argv);
void ifx_diag_adsl_return(int eid, httpd_t wp, int argc, char_t ** argv);
void ifx_diag_perform_ping(httpd_t wp);
void ifx_diag_usb_enabled(int eid, httpd_t wp, int argc, char_t ** argv);

void ifx_diag_get_status(httpd_t wp, int id)
{
	char_t sValue[MAX_FILELINE_LEN];
	struct ifx_phyport_info stat;
	memset(sValue, 0x00, sizeof(sValue));
	memset(&stat, 0x00, sizeof(stat));
//#ifdef PLATFORM_VR9
#if defined(PLATFORM_VR9) || defined(PLATFORM_VBX) || defined(CONFIG_FEATURE_LTQ_HNX_CONFIG) || defined(PLATFORM_AR10)
	if (ifx_get_phyport_info(id, &stat, 0) < 0) {
#else
	if (ifx_get_phyport_info(id, &stat, 1) < 0) {
#endif
		ifx_httpdError(wp, 400, T("get status fail\n"));
	} else {
		if (stat.link != 0)
			gstrcat(sValue, "Up");
		else
			gstrcat(sValue, "Down");
	}
	ifx_httpdWrite(wp,
		       T
		       ("<tr><td width=\"70%\" align='left'>ENET LAN - %d</td>"),
		       id);
	if (!gstrcmp(sValue, "Up"))
		ifx_httpdWrite(wp,
			       T
			       ("<td id=\"enet_lan_status1_%d\" width=\"30%\"align='left'><font color=\"green\"><b>%s</b></font></td><tr>"),
			       id, sValue);
	else
		ifx_httpdWrite(wp,
			       T
			       ("<td id=\"enet_lan_status2_%d\" width=\"30%\" align='left'><font color=\"red\"><b>%s</b></font></td><tr>"),
			       id, sValue);
	return;
}

int ifx_diag_get_lan_status(int eid, httpd_t wp, int argc, char_t ** argv)
{
#ifdef CONFIG_FEATURE_LTQ_HNX_CONFIG
        ifx_diag_get_status(wp, 1);
#elif defined(CONFIG_PACKAGE_KMOD_LTQCPE_AR10_F2_SUPPORT)
	int index;
	for (index = 2; index <=5; index++)
		ifx_diag_get_status(wp, index);
#else
#ifndef PLATFORM_VBX
        ifx_diag_get_status(wp, 0);
#ifndef CONFIG_FEATURE_IFX_SINGLE_PORT
        ifx_diag_get_status(wp, 1);
        ifx_diag_get_status(wp, 2);
#if defined(PLATFORM_VR9) 
        ifx_diag_get_status(wp, 4);
#elif defined(PLATFORM_AR9) && !defined(PLATFORM_AR10)
        char_t phy_mode[8] = { 0 };
        uint32 outFlag = IFX_F_DEFAULT;
        ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, "wanphy_phymode",
                       IFX_F_DEFAULT, &outFlag, phy_mode);
        if (gstrcmp(phy_mode, "1")) {
                ifx_diag_get_status(wp, 4);
        }
#else
        ifx_diag_get_status(wp, 3);
#endif
#endif
#else
        ifx_diag_get_status(wp, 1);
#endif
#endif
        ifx_httpdWrite(wp, T("</font>\n"));
        return 0;
}

void ifx_diag_oam_ping()
{
	unsigned int cells_tx, cells_rx, min_resp, max_resp, avg_resp,
	    ping_timeout;
	int vpi = 0, vci = 0, ret;
	char8 sValue[MAX_FILELINE_LEN], sWAN_VCC[MAX_NAME_SIZE];
	uint32 flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT;
	IFX_ID iid;
	/* TBD */
	//int32   nWAN_IDX = 0;
	char *temp = NULL;
	memset(sValue, 0x00, sizeof(sValue));
	memset(sWAN_VCC, 0x00, sizeof(sWAN_VCC));
	memset(&iid, 0x00, sizeof(iid));
	/* TBD */
	//if (ifx_get_default_wan_if(&iid, &nWAN_IDX, IFX_F_DEFAULT) != IFX_SUCCESS)
	//      sprintf(sValue,"wan_0_vcc");
	//else
	//      sprintf(sValue,"wan_%d_vcc",nWAN_IDX);
	max_resp = min_resp = avg_resp = cells_rx = 0;
	ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, sValue, flags, &outFlag,
		       sWAN_VCC);
	cells_tx = 5;
	temp = strtok(sWAN_VCC, "/");
	if (temp)
		vpi = atoi(temp);
	temp = strtok(NULL, "/");
	if (temp)
		vci = atoi(temp);
	ping_timeout = 600;
	ret =
	    ifx_oam_f5_ping(vpi, vci, 4, ping_timeout, cells_tx,
			    (int *)&cells_rx, (int *)&min_resp,
			    (int *)&max_resp, (int *)&avg_resp);
	if (ret == 0)
		vcc_ping_return = 1;
	else
		vcc_ping_return = 2;
}

void ifx_diag_lan_ping_return(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%d"), lan_ping_return);
}

void ifx_diag_vcc_ping_return(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%d"), vcc_ping_return);
}

void ifx_diag_gateway_ping_return(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%d"), gateway_ping_return);
}

void ifx_diag_primdns_ping_return(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%d"), primdns_ping_return);
}

void ifx_diag_adsl_return(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%d"), adsl_return);
}

void ifx_diag_perform_test(int eid, httpd_t wp, int argc, char_t ** argv)
{
	if (diag_complete == TRUE) {

	} else {
		diag_complete = TRUE;        // diag_complete is made to act as a semafore variable
		bFlag = TRUE;
		ifx_diag_perform_ping(wp);
		bFlag = FALSE;
		diag_complete = FALSE;
	}
	return;
}

void ifx_diag_perform_ping(httpd_t wp)
{
	char buffer[30], buffer1[30], buffer2[30];
	char_t sGateway[MAX_IP_ADDR_LEN], sDNS1[MAX_IP_ADDR_LEN];
	int ping_ret;
	FILE *fp;
	char8 *reset;

	memset(buffer1, 0x00, sizeof(buffer1));
	memset(buffer2, 0x00, sizeof(buffer2));
	if (bFlag)
		goto perform_test;

	reset = ifx_httpdGetVar(wp, T("reset_value"), T(""));
	if (!gstrcmp(reset, "1")) {
		vcc_ping_return = lan_ping_return = gateway_ping_return =
		    primdns_ping_return = adsl_return = 0;
		diag_complete = FALSE;
	} else {
	      perform_test:
		adsl_return = 1;
		ifx_diag_oam_ping();
		system("cat /proc/net/arp > /tmp/diag_temp1");
		system("cut -d \" \" -f1 /tmp/diag_temp1 > /tmp/diag_temp2");
		system("cut -d \"I\" -f1 /tmp/diag_temp2 > /tmp/diag_temp3");
		fp = fopen("/tmp/diag_temp3", "r");
		if (fp) {
			if (fscanf(fp, "%29s", buffer1) != EOF)
				fscanf(fp, "%29s", buffer2);
			fclose(fp);
		}
		system("rm -rf diag_temp*");
		gstrcpy(buffer, "ping -c 3 ");
		gstrcat(buffer, buffer1);
		ping_ret = system(buffer);
		if (ping_ret != 0) {
			LTQ_STRNCPY(buffer, "ping -c 3 ",29);
			LTQ_STRNCAT(buffer, buffer2,29);
			ping_ret = system(buffer);
		}
		if (ping_ret == 0)
			lan_ping_return = 1;
		else
			lan_ping_return = 2;
		memset(sGateway, 0x00, sizeof(sGateway));
		if (ifx_get_runtime_gw(sGateway) != IFX_SUCCESS)
			if (!bFlag)
				ifx_httpdError(wp, 400,
					       T("Failed to get Gateway IP\n"));
		gstrcpy(buffer, "ping -c 3 ");
		gstrcat(buffer, sGateway);
		ping_ret = system(buffer);
		if (ping_ret == 0)
			gateway_ping_return = 1;
		else
			gateway_ping_return = 2;
		sDNS1[0] = '\0';
		if (ifx_get_runtime_dns(sDNS1, "1") != IFX_SUCCESS)
			if (!bFlag)
				ifx_httpdError(wp, 400,
					       T("Failed to get DNS\n"));
		gstrcpy(buffer, "ping -c 3 ");
		gstrcat(buffer, sDNS1);
		ping_ret = system(buffer);
		if (ping_ret == 0)
			primdns_ping_return = 1;
		else
			primdns_ping_return = 2;

		diag_complete = TRUE;
	}

	if (!bFlag)
		websNextPage(wp);
}

void ifx_diag_usb_enabled(int eid, httpd_t wp, int argc, char_t ** argv)
{
#ifdef CONFIG_FEATURE_IFX_USB_HOST
	ifx_httpdWrite(wp, T("0"));
#else
	ifx_httpdWrite(wp, T("1"));
#endif
}
