#include <ifx_emf.h>
//#include <ifx_api_structs.h>
#include "ifx_httpd_method.h"
#include "./ifx_amazon_cgi.h"
#include "./ifx_cgi_common.h"
#include "ifx_common.h"
//#include "ltq_mapi_mediaserver.h"

//void ifx_set_dlna_server (httpd_t wp, char_t *path, char_t *query)
//{
  //                              char_t *mserver_name = NULL, *scan_media = NULL, *db_loc = NULL, *dlna_enable = NULL;
    //                            int32 i = 0, *idx_array = NULL, idx_count = 0;

      //                          mserver_name = ifx_httpdGetVar(wp, T("media_server"), T(""));

	//                        char_t *pCheck = NULL;
	  //                      pCheck = ifx_httpdGetVar(wp, T("wan_vlan_status"), T(""));
//#endif

extern int32 ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);

int ifx_get_dlna_server(int eid, httpd_t wp, int argc, char_t ** argv)
{
	LTQ_MAPI_MediaServer my_media;

	char8 *name = NULL;
	int32 ret;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	memset(&my_media, 0, sizeof(LTQ_MAPI_MediaServer));

	ret = ltq_get_mediaserver(&my_media, 0);
	IFX_DBG("In Function [%s:%d:%d]", __FUNCTION__, __LINE__,
		my_media.msEna);
	IFX_DBG("In Function [%s:%d:%s]", __FUNCTION__, __LINE__,
		my_media.extDBpath);
	if ((ret == IFX_SUCCESS)) {

		if (!gstrcmp(name, "dlna_enable")) {
			if (my_media.msEna)
				ifx_httpdWrite(wp, T("checked"));
			else
				ifx_httpdWrite(wp, T(""));
		} else if (!gstrcmp(name, "media_server")) {
			ifx_httpdWrite(wp, T("%s"), my_media.mediaServerName);
		} else if (!gstrcmp(name, "db_loc")) {
			if (my_media.extDBloc)
				ifx_httpdWrite(wp, T("checked"));
			else
				ifx_httpdWrite(wp, T(""));
		} else if (!gstrcmp(name, "db_path")) {
			ifx_httpdWrite(wp, T("%s"), my_media.extDBpath);
		} else if (!gstrcmp(name, "scan_media")) {
			if (my_media.scanAtStart)
				ifx_httpdWrite(wp, T("checked"));
			else
				ifx_httpdWrite(wp, T(""));
		}
//      IFX_MEM_FREE(my_media)
	}
	return 0;
}

void ifx_set_dlna_server(httpd_t wp, char_t * path, char_t * query);
void ifx_set_dlna_server(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pdlna, *pflag;
	char8 *scpeId = NULL;
	LTQ_MAPI_MediaServer my_media;
	LTQ_MAPI_Media_Location my_ml;
	memset(&my_media, 0x00, sizeof(my_media));
	memset(&my_ml, 0x00, sizeof(my_ml));

	pflag = ifx_httpdGetVar(wp, T("choiceflag"), T(""));
	scpeId = ifx_httpdGetVar(wp, "cpeId_selected", T(""));
	IFX_DBG("In Function [%s:%d]", __FUNCTION__, __LINE__);

	if ((gatoi(pflag) == 1)) {
		pdlna = ifx_httpdGetVar(wp, T("dlna_enable"), T(""));
		if (gatoi(pdlna) == 1) {
			my_media.msEna = IFX_ENABLED;
		} else {
			my_media.msEna = IFX_DISABLED;
		}
		pdlna = ifx_httpdGetVar(wp, T("media_server"), T(""));
		sprintf(my_media.mediaServerName, "%s", pdlna ? pdlna : "");

		pdlna = ifx_httpdGetVar(wp, T("db_loc"), T(""));
		if (gatoi(pdlna) == 1) {
			my_media.extDBloc = IFX_ENABLED;
		} else {
			my_media.extDBloc = IFX_DISABLED;
		}

		pdlna = ifx_httpdGetVar(wp, T("db_path"), T(""));
		sprintf(my_media.extDBpath, "%s", pdlna ? pdlna : "");

		pdlna = ifx_httpdGetVar(wp, T("scan_media"), T(""));
		if (gatoi(pdlna) == 1) {
			my_media.scanAtStart = IFX_ENABLED;
		} else {
			my_media.scanAtStart = IFX_DISABLED;
		}
		if (ltq_set_mediaserver(0, &my_media, IFX_F_MODIFY) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 500,
				       T("Failed to save NTP Configurations"));
			return;
		}
	} else if ((gatoi(pflag)) == 2) {
		// SET MEDIA LOCATION SECTION
		IFX_DBG("In Function [%s:%d]", __FUNCTION__, __LINE__);

		pdlna = ifx_httpdGetVar(wp, T("dbloc_path"), T(""));
		sprintf(my_ml.mediaPath, "%s", pdlna ? pdlna : "");

		IFX_DBG("In Function [%s:%d:%s]", __FUNCTION__, __LINE__,
			my_ml.mediaPath);
		pdlna = ifx_httpdGetVar(wp, T("cont_fil"), T(""));
		my_ml.mediaType = (gatoi(pdlna));

		IFX_DBG("In Function [%s:%d:%d]", __FUNCTION__, __LINE__,
			my_ml.mediaType);
		if (ltq_set_media_location(IFX_OP_ADD, &my_ml, IFX_F_DEFAULT) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 500,
				       T
				       ("Failed to save media location Configurations"));
			return;
		}
	} else if ((gatoi(pflag)) == 3) {
		IFX_DBG("In Function [%s:%d]", __FUNCTION__, __LINE__);
		my_ml.iid.cpeId.Id = atoi(scpeId);
		IFX_DBG("In Function [%s:%d:%d]", __FUNCTION__, __LINE__,
			my_ml.iid.cpeId.Id);
		if (ltq_set_media_location(IFX_OP_DEL, &my_ml, IFX_F_DELETE) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 500,
				       T
				       ("Failed to save media location Configurations"));
			return;
		}
	}
	ifx_httpdRedirect(wp, T("dlna.asp"));
}

void ifx_get_media_locations(int eid, httpd_t wp, int argc, char_t ** argv);
void ifx_get_media_locations(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char8 sValue[MAX_FILELINE_LEN];
	char8 *name = NULL;
	uint32 num;
	int ret = IFX_SUCCESS, i;
	uint32 Flags = IFX_F_DEFAULT;
	LTQ_MAPI_Media_Location *media_loc = NULL;
	ifx_httpd_parse_args(argc, argv, T("%s"), &name);

	ret = ltq_get_all_media_location_entries(&num, &media_loc, Flags);

	if (ret == IFX_SUCCESS) {
		if (name != NULL) {
			ifx_httpdWrite(wp, T("\"%d\""), num);
		} else {
			for (i = 0; i < num; i++) {
				ifx_httpdWrite(wp,
					       "<input type=\"hidden\" name=\"cpeId%d\" value=\"%d\">",
					       i,
					       (media_loc + i)->iid.cpeId.Id);
				ifx_httpdWrite(wp, T("<tr>\n"));
				ifx_httpdWrite(wp,
					       T
					       ("<td width=\"40%\" id=\"%d\">%s</td>\n"),
					       i, (media_loc + i)->mediaPath);

				if ((media_loc + i)->mediaType == 0)
					strcpy(sValue, "All Media");
				else if ((media_loc + i)->mediaType == 1)
					strcpy(sValue, "Image");
				else if ((media_loc + i)->mediaType == 2)
					strcpy(sValue, "Audio");
				else if ((media_loc + i)->mediaType == 3)
					strcpy(sValue, "Video");
				ifx_httpdWrite(wp,
					       T
					       ("<td width=\"29%\" id=\"%d\">%s</td>\n"),
					       i, sValue);

				ifx_httpdWrite(wp,
					       T
					       ("<td><a href=\"#\" class=\"button\" value=\"Delete\" onClick=\"DelValue(\'%d\', \'%d\');\">Delete</a>\n"),
					       i,
					       (media_loc + i)->iid.cpeId.Id);
				ifx_httpdWrite(wp, T("</tr>"));

			}
		}
	} else {
		ifx_httpdError(wp, 500, "Error");
	}

	IFX_MEM_FREE(media_loc)
}
