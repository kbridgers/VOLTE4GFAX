var BitsUpValueList = "";
var BitsDownValueList= "";
var BitsUpSize = 0;
var BitsDownSize = 0;

function doBitsBarGraph(UpSize, UpMsg, DownSize , DownMsg)
{
   UpdateBitsValuesList( UpSize, UpMsg, DownSize , DownMsg, 16 );
   doBGColorInfoStart(document );
   doBGColorInfo(document , UpStreamColour ,"Up Stream", 80) ;  
   doBGColorInfo(document , DownStreamColour,"Down Stream", 100 ) ;  
   doBGColorInfo(document , UpDownStreamOverlapColour,"Up/Down Stream OverLap", 180 ) ;  
   doBGColorInfoEnd(document );
   doCompleteBarGraph( document ,  "BITS", "Tones", 20, 64, 4, (1/8),  20, BitsUpSize , BitsUpValueList , BitsDownSize , BitsDownValueList, 16);
}

function UpdateBitsValuesList(  UpSize,UpMsg,  DownSize,  DownMsg, base )
{
   BitsUpValueList = UpMsg.split(" ");
   BitsDownValueList = DownMsg.split(" ");
   BitsUpSize = UpSize;
   BitsDownSize = DownSize;
}

function ExpandBitsGraph( )
{
	var NewWindow = window.open();
   doBGColorInfoStart(NewWindow.document );
   doBGColorInfo(NewWindow.document , UpStreamColour ,"Up Stream", 80) ;  
   doBGColorInfo(NewWindow.document , DownStreamColour,"Down Stream", 100 ) ;  
   doBGColorInfo(NewWindow.document , UpDownStreamOverlapColour,"Up/Down Stream OverLap", 180 ) ;  
   doBGColorInfoEnd(NewWindow.document );
	doCompleteBarGraph( NewWindow.document , "BITS", "Tones", 20, 64, 4, 1,  20,  BitsUpSize , BitsUpValueList , BitsDownSize , BitsDownValueList, 16);
}

function ShowRawBitsValues( )
{
	var NewWindow = window.open();
	ShowRawValuesInTable(NewWindow.document , " BITS " , BitsUpSize, BitsUpValueList , BitsDownSize,  BitsDownValueList , 16 );
}

