function OnReceiveReturn(val)
{
   var text = "Error";
   
	switch(parseInt(val))
	{
		case 0:
      text = "Success";
      break;

      /* *********************************************************************** */
      /* *** Error Codes for PSD/Carrier Masking problems within device      *** */
      /* *** specific implementation                                         *** */
      /* *********************************************************************** */                         
		case -6001:
      text = "An error occured during processing of the PSD mask configuration. " +
             "In this case the maximum number of possible PSD mask breakpoints " +
             "(DSL_G997_MAX_PSD_BREAKPOINTS_DS) is not enough to merge all necessary " +
             "data in it (e.g. carrier masking)";
      break;
   
		case -6000:
      text = "An error occured during processing of the PSD mask configuration." +
             " In this case the PSD mask that is either not written or only written" +
             " incomplete to the device";
      break;

      /* *********************************************************************** */
      /* *** Error Codes for PSD/Carrier Masking configuration settings of   *** */
      /* *** G.997.1                                                         *** */
      /* *********************************************************************** */ 
      case -5001:
      text = "Configuration data for G.997.1 PSD Mask is invalid and was not " +
             "written completley to the data base!" +
             "Attention, " +
             "An incomplete (respective inconsistent) set of breakpoints may be written "+
             "to the data base in this case. Please update the configuration data with "+
             "a valid set of breakpoints to avoid malfunctions!";
      break;
         
		case -5000:
      text = "Configuration data for G.997.1 Carrier Masking is invalid and was not" +
             "written completley to the data base!"; 
      break;
   
      /* *********************************************************************** */
      /* *** Error Codes for Common G.997.1 configuration settings           *** */
      /* *********************************************************************** */ 
		case -4009:
      text = "Configuration parameter for status event mask configuration is invalid" +
             " and will be NOT written to data base!";
      break;

      case -4008:
      text = "Configuration data for G.997.1 Minimum Overhead Rate config is invalid and " +
             "will be NOT written to data base!";
      break;
      
      case -4007:
      text = "Configuration of G.997.1 rate adaptation ration is invalid. In most cases " +
             "this error occurs if the sum over all ratios of all bearer channels does " +
             "not result in 100%. In this case you have to cerrect the settings using " +
             "the DSL API function \ref DSL_G997_ChannelRateAdaptationConfigSet";
      break;
   
		case -4006:
      text = "Configuration data for G.997.1 Rate Adaptation config is invalid and" +
             " will be NOT written to data base!";
      break;

		case -4005:
      text = "Configuration data for G.997.1 ATU System Enabling config includes" +
             " unsopported bit settings and will be NOT written to the data base";
      break;

		case -4004:
      text = "Configuration data for G.997.1 Channel Config is invalid and will be NOT" +
             " writen to data base!";
      break;

		case -4003:
      text = "Configuration data for channel specific G.997.1 Low Power Mode Config is" +
             " invalid and will be NOT writen to data base!";
      break;

		case -4002:
      text = "Configuration data for G.997.1 Low Power Mode Config is invalid and will" +
             " be NOT writen to data base!";
      break;

		case -4001:
      text = "Configuration data for G.997.1 Noise Margin is invalid and will be NOT" +
             " written to data base!";
      break;

		case -4000:
      text = "Configuration data for G.997.1 line activation is invalid and will be NOT" +
             " written to data base!";
      break;

      /* *********************************************************************** */
      /* *** Error Codes for Data Base handling                              *** */
      /* *********************************************************************** */ 		   
      case -3005:
      text = "Access violation for data base. Data base is locked!"; 
      break;

		case -3004:
      text = "Access violation for data base. Data base can not be unlocked!";
      break;

		case -3003:
      text = "The data base parameter is out of the specified range";
      break;

		case -3002:
      text = "Data base access parameter (data type, line number, channel number)" +
             " incorrect";
      break;

		case -3001:
      text = "Data base index out of range";
      break;

		case -3000:
      text = "Data base definition inconstistent (DSL library coding error!)";
      break;


      /* *********************************************************************** */
      /* *** Error Codes for common API parameter handling                   *** */
      /* *********************************************************************** */ 		   
      case -2005:
      text = "Requested function is only available if line is in showtime";
      break;
		
		case -2004:
      text = "Error on activating sending of reverb signal";
      break;

      case -2003:
      text = "User configuration or command not allowed in actual line state";
      break;

		case -2002:
      text = "The answer from the device does not return within the specifies timeout";
      break;
   
		case -2001:
      text = "The library access is already locked and the function can not be" +
             " processed";
      break;

		case -2000:
      text = "Common error on send message and wait for answer handling";
      break;

      /* *********************************************************************** */
      /* *** Error Codes for API parameter range check                       *** */
      /* *********************************************************************** */ 
      case -1002:
      text = "Invalid PSD DSL transmission mode range";
      break;

		case -1001:
      text = "Invalid line range";
      break;

		case -1000:
      text = "Invalid bearer channel range";
      break;

      /* *********************************************************************** */
      /* *** Common Error Codes                                              *** */
      /* *********************************************************************** */ 
		case -11:
      text = "Internal error";
      break;

		case -10:
      text = "Feature or functionality not supported by firmware";
      break;

		case -9:
      text = "Feature or functionality not supported by DSL API";
      break;

		case -8:
      text = "Function returned with timeout";
      break;

		case -7:
      text = "Invalid pointer";
      break;

		case -6:
      text = "Invalid memory";
      break;

		case -5:
      text = "File open failed";
      break;

		case -4:
      text = "File write failed";
      break;

		case -3:
      text = "File reading failed";
      break;

		case -2:
      text = "File close failed";
      break;

		case -1:
      text = "Common error";
      break;
      
      /* *********************************************************************** */
      /* *** Common Warning Codes                                            *** */
      /* *********************************************************************** */
      case 1:
      text = "Configuration parameter was truncated to min./max value";
      break;
      
      case 2:         
      text = "Line inventory information could not be proccessed completely";
      break;

      /* *********************************************************************** */
      /* *** Warning Codes for unsupported parameter                         *** */
      /* *********************************************************************** */
      case 1000:
      text = "There are unsupported parameters but the basic functionality is working " +
             "correctly";
      break;
             
      case 1001:                
      text = "There are one or more unsupported parameters included in the API call " +
             "(inclease the debug level to 'DSL_DBG_WRN' to see additional information) " +
             "but at least one of the given API parameter is used correctly ";
      break;
      
      case 1002:
      text = "Unsupported ATSE modes are selected";
      break;

      /* *********************************************************************** */
      /* *** Warning Codes for PSD/Carrier Masking handling                  *** */
      /* *********************************************************************** */
      case 2000:
      text = "Configuration data for G.997.1 PSD Mask includes minor inconsistent " +
             "settings but was written to the data base, respective to the device. " +
             "Note: It is recommended to correct the PSD configuration values to ensure an " +
             "accurate behaviour of the system.";            
      break;
   }   
   
	if(document.getElementById("nError"))
	{
      if(val == "0")
      {
   		eval("document.getElementById(\"nError\").style.backgroundColor = \"#DDDDDD\";");
      }
      else
      {
   		eval("document.getElementById(\"nError\").style.backgroundColor = \"#FF6600\";");
      }

      text = "DSL Api Error :\n" + text ;
      eval("document.getElementById(\"nError\").innerText = text;");   
   }
}


