var SnrUpValueList = "";
var SnrDownValueList = "";
var SnrUpSize = 0;
var SnrDownSize = 0;

function doSnrBarGraph( UpSize, UpMsg, DownSize , DownMsg)
{
   UpdateSnrValuesList( UpSize, UpMsg, DownSize , DownMsg, 16 );
   doBGColorInfoStart(document );
   doBGColorInfo(document , UpStreamColour ,"Up Stream", 80 ) ;  
   doBGColorInfo(document , DownStreamColour,"Down Stream", 100 ) ;  
   doBGColorInfo(document , UpDownStreamOverlapColour,"Up/Down Stream OverLap", 180 ) ;  
   doBGColorInfo(document , NegativeValueColour,"Negative Values", 120 ) ;  
   doBGColorInfoEnd(document );
   doCompleteBarGraph( document , "SNR", "Tones", 20, 64, 1, 1/8,  260, SnrUpSize , SnrUpValueList, SnrDownSize , SnrDownValueList, 10 );
}

function UpdateSnrValuesList(  UpSize,UpMsg,  DownSize,  DownMsg, base )
{
   SnrUpValueList = UpMsg.split(" ");
   SnrDownValueList = DownMsg.split(" ");
   SnrUpSize = UpSize;
   SnrDownSize = DownSize;
   for (i = 0; i < SnrUpSize; i++)
   {
		UpValue = parseInt(SnrUpValueList[i],base);
		if(UpValue  != 	255)
		{
			SnrUpValueList[i] = (UpValue/2) - 32;
		}
		else
		{
			SnrUpValueList[i] = 0;
		}
	}
   for (i = 0; i < DownSize; i++)
   {
      DownValue = parseInt(SnrDownValueList[i], base);
		if(DownValue != 	255)
		{
			SnrDownValueList[i] = (DownValue /2) - 32 ;
		}
		else
		{
			SnrDownValueList[i] = 0;
		}
   }
}

function ExpandSnrGraph( )
{
	var NewWindow = window.open();

   doBGColorInfoStart(NewWindow.document );
   doBGColorInfo(NewWindow.document , UpStreamColour ,"Up Stream", 80) ;  
   doBGColorInfo(NewWindow.document , DownStreamColour,"Down Stream", 100 ) ;  
   doBGColorInfo(NewWindow.document , UpDownStreamOverlapColour,"Up/Down Stream OverLap", 180 ) ;  
   doBGColorInfo(NewWindow.document , NegativeValueColour,"Negative Values", 120 ) ;  
   doBGColorInfoEnd(NewWindow.document );
  doCompleteBarGraph( NewWindow.document , "SNR", "Tones", 20, 64, 1, 1,  260, SnrUpSize , SnrUpValueList, SnrDownSize , SnrDownValueList, 10 );

}

function ShowRawSnrValues( )
{
	var NewWindow = window.open();
	ShowRawValuesInTable(NewWindow.document , " SNR " , SnrUpSize, SnrUpValueList , SnrDownSize,  SnrDownValueList , 10 );
}


