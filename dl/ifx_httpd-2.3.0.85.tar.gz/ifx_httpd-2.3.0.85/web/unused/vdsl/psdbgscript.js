var NumberOfTones = 4096;
var PsdDownOrigList ="";  
var PsdUpOrigList ="";  
var PsdUpOrigSize  = 0 ;
var PsdDownOrigSize  =  0 ;

var PsdUpValueList = "";
var PsdDownValueList = "";
var PsdUpSize = 0;
var PsdDownSize = 0;
var CmUpValueList = "";
var CmDownValueList= "";
var CmUpSize = 0;
var CmDownSize = 0;
var CmUpBandInfoList = "";
var CmDownBandInfoList = "";
var PsdBandxFactor = 0;



function doNoAxisPsdBarGraph( doc, yTitle, xTitle, yDiff, xDiff, yFactor, xFactor, yMaxSize,  UpSize, UpValueList ,  DownSize,  DownValueList , base )
{
	var xMaxSize = 0;	
	var xFactorSize = 0;	
	var yFactorSize = 0;	

	if( UpSize > DownSize)
	{
		xMaxSize = UpSize ;
	}	   
	else
	{
		xMaxSize = DownSize;
	}	   
	xFactorSize = xMaxSize* xFactor ;
	yFactorSize = yMaxSize* yFactor ;

	doBarGraphTop(doc, yTitle, xFactorSize+45);
	doBarGraphTableStart(doc, yTitle, xFactorSize+45 , yFactorSize);
	doLeftBar(doc, "black", yMaxSize, yDiff, yFactor);
	doAllBarsWrite(doc, yFactor, xFactor, yMaxSize, UpSize, UpValueList ,  DownSize,  DownValueList , base );
	doBarGraphTableEnd(doc );
}

function doNoAxisCmBarGraph( doc, yTitle, xTitle, yDiff, xDiff, yFactor, xFactor, yMaxSize,  UpSize, UpValueList ,  DownSize,  DownValueList , base )
{
	var xMaxSize = 0;	
	var xFactorSize = 0;	
	var yFactorSize = 0;	
	if( UpSize > DownSize)
	{
		xMaxSize = UpSize ;
	}	   
	else
	{
		xMaxSize = DownSize;
	}	   
	xFactorSize = xMaxSize* xFactor ;
	yFactorSize = yMaxSize* yFactor ;

	doBarGraphTableStart(doc, yTitle, (xFactorSize+45) , yFactorSize);
	doLeftCmBar(doc, "black","Band", yFactorSize);
	doCmBandsWrite(doc, xFactor, UpSize, UpValueList ,  DownSize,  DownValueList , base );
	doBarGraphTableEnd(doc );
}


function doCmBandsWrite(doc, xFactor,  UpSize, UpValueList ,  DownSize,  DownValueList , base )
{
	var xMaxSize = 0;	
	var xFactorSize = 0;	
	var width = 1;
	var UpValue = 0;	
	var DownValue = 0;	
  
 
	if( UpSize > DownSize)
	{
		xMaxSize = UpSize ;
	}	   
	else
	{
		xMaxSize = DownSize;
	}	   
	xFactorSize = xMaxSize* xFactor ;

	if ( xFactor > 1) 
	{
		width *= xFactor;
	}

	for (i = 0; i < xMaxSize; i++)
	{
		if ( xFactor < 1) 
		{
		   if( ( i % (1/xFactor) ) != 0) 
		   {
				continue;
		   }		
		}
	   if((UpSize  > i) && (DownSize> i) )
	   {
		   UpValue = parseInt(UpValueList[i], base);
	   	DownValue = parseInt(DownValueList[i], base);
	      if( (UpValue != 0) && (DownValue == 0) )
	      {
				Colour = UpStreamColour;
	      }
	      else if( (UpValue == 0) && (DownValue != 0) )
	      {
				Colour = DownStreamColour;
			}
	      else if( (UpValue != 0) && (DownValue != 0) )
	      {
				Colour = UpDownStreamOverlapColour;
	      }
	      else
	      {
		 		Colour =" ";
			}         
		}
		else if(UpSize   > i)
		{
			UpValue = parseInt(UpValueList[i], base);
			if( UpValue != 0 )
			{
				Colour = UpStreamColour;
			}
			else
			{
				Colour =" ";
			}         
		}
		else 
		{
			DownValue = parseInt(DownValueList[i], base);
			if( DownValue  != 0 )
			{
				Colour = DownStreamColour ;
				Value = DownValue   ;
			}
			else
			{
				Colour =" ";
			}         
		}

		if ( Colour == " "	)
		{
			td = "<td   id=BandTone" + i + " width=" + width +  "></td> ";			
			//	      td = "<td   width=" + width +  "></td> ";			
		}
		else
		{
			td = "<td  bgcolor=" + Colour +  "  id=BandTone" + i + "  width=" + width +  "></td> ";			
			//	      td = "<td  bgcolor=" + Colour +  "  width=" + width +  "></td> ";			
		}
		doc.write(td);
	}
}




function doLeftCmBar(doc, color, yTitle, height)
{
	var td = " ";
	var difffactor ;
	var initheight;
	var barheight;
	var loop;

	td = "<td valign=center align=left width=42 height=" +  height +
	" > " + yTitle ;
	td += "</td>";
	doc.write(td);
	td = "<td VAlign=bottom>";
	td +="<table bgcolor=" + color +
	   "  border=0 cellspacing=0 cellpadding=0 width=3 height=" +
	    height + " ><tr><td></td></tr></table>";
	td += "</td>";
	doc.write(td);

}




function doPsdBarGraph( UpSize, UpMsg, DownSize , DownMsg)
{
	UpdatePsdValuesList( UpSize, UpMsg, DownSize , DownMsg, 16 );
}

function CompressPsdBandBarGraph()
{
	PsdBandxFactor = 1/8;
	doCompletePsdBandBarGraph( document, 1, PsdBandxFactor );
}

function ExpandPsdBandBarGraph( )
{
	var NewWindow = window.open();

	doCompletePsdBandBarGraph( NewWindow.document, 1, 1);
}

function doCompletePsdBandBarGraph( doc, yFactor, xFactor)
{
	var xMaxSize = NumberOfTones;
	var yMaxSize = 100;
	var yDiff = 20;
	var xDiff = 64;
	var Psdbase = 10;
	var xTitle = "Tones";   	
	var yPsdTitle = "PSD";   	

	var Cmbase = 10;
	var yCmTitle = "Band";   	

	xFactorSize = xMaxSize* xFactor ;
	yFactorSize = yMaxSize* yFactor ;

	doBGColorInfoStart(doc );
	doBGColorInfo(doc , UpStreamColour ,"Up Stream", 80 ) ;  
	doBGColorInfo(doc , DownStreamColour,"Down Stream", 100 ) ;  
	doBGColorInfo(doc , UpDownStreamOverlapColour,"Up/Down Stream OverLap", 180 ) ;  
	doBGColorInfoEnd(doc );
	doNoAxisPsdBarGraph( doc , yPsdTitle, xTitle, yDiff, xDiff, yFactor, xFactor,  yMaxSize, 
								PsdUpSize , PsdUpValueList, PsdDownSize , PsdDownValueList, Psdbase );
	doHorizantalBar(doc, "black", (xFactorSize+ xDiff),1 );
	doNoAxisCmBarGraph(   doc, yCmTitle, xTitle, yDiff, xDiff, yFactor, xFactor, 20,  
								CmUpSize, CmUpValueList , CmDownSize,  CmDownValueList , Cmbase );
	doHorizantalBar(doc, "black", (xFactorSize+ xDiff),3 );
	doAxisWrite(doc, xTitle, xDiff, xMaxSize, xFactor );
}


function doCmBarGraph(UpSize, UpMsg, DownSize , DownMsg)
{
	UpdateCmValuesList( UpSize, UpMsg, DownSize , DownMsg, 10);
}

function UpdateCmValuesList(  UpSize,UpMsg,  DownSize,  DownMsg, base )
{
	var UpList = UpMsg.split(" ");
	var DownList = DownMsg.split(" ");
	CmUpSize = UpSize;
	CmDownSize = DownSize ;
	var DownBandMsg ="";  
	var UpBandMsg ="";  
	CmUpBandSize  = UpSize ;
	CmDownBandSize  =  DownSize ;
	var DownValRawMsg = "";
	var UpValRawMsg = "";
	var ActDownSize = DownSize/32;
	var ActUpSize = UpSize/32;
	var ffValue = parseInt("ffffffff",16);
	var DownBandInfoMsg = "" ;
	var UpBandInfoMsg = "" ;
	var MaskVal = 0;
	var ToneNumberStart = 0;
	var ToneNumberEnd = 0;
	var PrevMask = 0;
	var FirstTime = 1 ;
	var x = 0;
	var y = 0;
	var i = 0;
	var j = 0;
	var k = 0;

	for ( i=0 , j=1; i < ActDownSize; i++)
	{
		DownList[i] = DownList[i].replace("(","");
		DownList[i] = DownList[i].replace(")","");
		DownValList = DownList[i].split(",");
		ToneNumberStart = parseInt(DownValList[0],10) ;
		ToneNumberEnd = parseInt(DownValList[1],10) ;
		MaskVal         = parseInt(DownValList[2],16) ;
		if( MaskVal == 0 )
		{
			DownBandMsg  +=    " 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0, 0, 0 ,0 , 0 , 0 , 0 , 0 , 0 , 0 , 0, 0, 0 ,0 , 0 , 0 , 0 , 0 , 0 , 0 , 0, 0, 0 , 0, 0,"
			if((PrevMask &0x80000000) != 0)
			{
				DownBandInfoMsg += (ToneNumberStart - 1) + "," ;
			}
		}
		else if (MaskVal == ffValue )
		{
			DownBandMsg  +=    " 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1, 1, 1 ,1 , 1 , 1 , 1 , 1 , 1 , 1 , 1, 1, 1 ,1 , 1 , 1 , 1 , 1 , 1 , 1 , 1, 1, 1 , 1, 1,"
			if( (PrevMask &0x80000000) == 0)
			{
				DownBandInfoMsg += ToneNumberStart + "," ;
			}
		}
		else 
		{
			BandChange = 0 ;
			FirstTime = 1 ;
			for( y=1, x =0; x<32;x++, y = y<< 1)
			{
				if(MaskVal & y) 
				{
					DownBandMsg  +=    "1 ,";
					if( ( (PrevMask &0x80000000) == 0) &&(FirstTime ==1))
					{
						DownBandInfoMsg += (ToneNumberStart +x) + "," ;
						FirstTime = 0 ;
						BandChange = 1;
					}
					if( ( (PrevMask &0x80000000) != 0) &&(BandChange ==1) )
					{
						DownBandInfoMsg += (ToneNumberStart +x) + "," ;
						FirstTime = 1 ;
						BandChange = 0;
					}
				}
				else 
				{
					DownBandMsg  +=    "0 ,";
					if( ( (PrevMask &0x80000000) != 0) &&(FirstTime ==1) )
					{
						DownBandInfoMsg += (ToneNumberStart +x - 1 )+ "," ;
						FirstTime = 0 ;
						BandChange = 1;
					}
					if( ( (PrevMask &0x80000000) == 0) &&(BandChange ==1) )
					{
						DownBandInfoMsg += (ToneNumberStart -1 +x) + "," ;
						FirstTime = 1 ;
						BandChange = 0;
					}
				}
			}
		}
		PrevMask = MaskVal;
	}
	if(PrevMask &0x80000000)
	{
		DownBandInfoMsg += (NumberOfTones -1 ) + "," ;
	}

	UpBandInfoMsg = "" ;
	MaskVal = 0;
	ToneNumberStart = 0;
	ToneNumberEnd = 0;
	PrevMask = 0;
	FirstTime = 1 ;
	x = 0;
	y = 0;
	i = 0;
	j = 0;
	k = 0;

	for ( i=0 , j=1; i < ActUpSize; i++)
	{
		UpList[i] = UpList[i].replace("(","");
		UpList[i] = UpList[i].replace(")","");
		UpValList = UpList[i].split(",");
		ToneNumberStart = parseInt(UpValList[0],10) ;
		ToneNumberEnd = parseInt(UpValList[1],10) ;
		MaskVal         = parseInt(UpValList[2],16) ;
		if( MaskVal == 0 )
		{
			UpBandMsg  +=    " 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0, 0, 0 ,0 , 0 , 0 , 0 , 0 , 0 , 0 , 0, 0, 0 ,0 , 0 , 0 , 0 , 0 , 0 , 0 , 0, 0, 0 , 0, 0,"
			if( (PrevMask &0x80000000) != 0)
			{
				UpBandInfoMsg += (ToneNumberStart - 1) + "," ;
			}
		}
		else if (MaskVal == ffValue )
		{
			UpBandMsg  +=    " 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1, 1, 1 ,1 , 1 , 1 , 1 , 1 , 1 , 1 , 1, 1, 1 ,1 , 1 , 1 , 1 , 1 , 1 , 1 , 1, 1, 1 , 1, 1,"
			if( (PrevMask &0x80000000) == 0)
			{
				UpBandInfoMsg += ToneNumberStart + "," ;
			}
		}
		else 
		{
			BandChange = 0 ;
			FirstTime = 1 ;
			for( y=1, x =0; x<32;x++, y = y<< 1)
			{
				if(MaskVal & y) 
				{
					UpBandMsg  +=    "1 ,";
					if( ( (PrevMask &0x80000000) == 0) &&(FirstTime ==1))
					{
						UpBandInfoMsg += (ToneNumberStart +x) + "," ;
						FirstTime = 0 ;
						BandChange = 1;
					}
					if( ( (PrevMask &0x80000000) != 0) &&(BandChange ==1) )
					{
						UpBandInfoMsg += (ToneNumberStart +x) + "," ;
						FirstTime = 1 ;
						BandChange = 0;
					}
				}
				else 
				{
					UpBandMsg  +=    "0 ,";
					if( ( (PrevMask &0x80000000) != 0) &&(FirstTime ==1) )
					{
						UpBandInfoMsg += (ToneNumberStart +x - 1 )+ "," ;
						FirstTime = 0 ;
						BandChange = 1;
					}
					if( ( (PrevMask &0x80000000) == 0) &&(BandChange ==1) )
					{
						UpBandInfoMsg += (ToneNumberStart -1 +x) + "," ;
						FirstTime = 1 ;
						BandChange = 0;
					}
				}
			}
		}
		PrevMask = MaskVal;
	}
	if(PrevMask &0x80000000)
	{
		UpBandInfoMsg += (NumberOfTones -1 ) + "," ;
	}

	CmUpBandInfoList = UpBandInfoMsg.split(",");
	CmDownBandInfoList = DownBandInfoMsg.split(",");

	CmUpValueList = UpBandMsg.split(",");
	CmDownValueList = DownBandMsg.split(",");
	CmUpBandInfoList.pop();
	CmDownBandInfoList.pop();
	CmUpValueList.pop();
	CmDownValueList.pop();

}

			
function UpdateBandInfo1()
{
	var DownBandInfoMsg = "";
	var UpBandInfoMsg = "";
	var PrevEnd = -1;
	var NoBand = 0;
	var Band = 0;
	var loop = 0;
	var r_loop = 0;
	var RemainGap = 0;
	var Start = 0;
	var End = 0;
	var Value = 0;
	var x = 0;
	var y = 0;
	var i = 0;
	var j = 0;
	var k = 0;


	for(i =1,PrevEnd = -1 ; i <DSBandNumber ; i++)
	{
		if ( document.getElementById("DisableDSBand"+i).checked == true ) 
		{
			continue;
		}

		Start		= parseInt(document.getElementById("DSStartBand"+i).value,10) ;
		End		= parseInt(document.getElementById("DSEndBand"+i).value,10) ;
		NoBand 	= Start -PrevEnd -1;
		loop 		= NoBand / 32 ;
		r_loop 	= Math.round( loop ) ;

		if(loop >= r_loop )
		{
			loop = r_loop ;
		}	
		else
		{
			loop = r_loop -1;
		}

		RemainGap = NoBand - (loop*32) ;
		for ( j = 0 ; j < loop; j ++)
		{
			DownBandInfoMsg +=  "0x00000000  ";
		}

		if(RemainGap != 0)
		{
			if( RemainGap == 31 )
			{
				Value = 0x80000000 ;
			}
			else
			{
				for( y = 1, x =0; x < RemainGap; x++, y *= 2 );
				Value = (0xffffffff - y +1 ) ;
			}
			DownBandInfoMsg +=  "0x"+Value.toString(16) + " ";
			Start += (32 - RemainGap - 1);
		}


		Band 		= End - Start - 1;
		loop 		= Band / 32 ;
		r_loop 	= Math.round( loop ) ;
		if(loop >= r_loop )
		{
			loop = r_loop ;
		}	
		else
		{
			loop = r_loop -1;
		}
		RemainGap = Band - (loop*32)  ;
		for ( j = 0 ; j < loop; j ++)
		{
			DownBandInfoMsg +=  "0xffffffff  ";
		}
		if(RemainGap != 0)
		{
			if( RemainGap == 31 )
			{
				Value = 0x7fffffff ;
			}
			else
			{
				for( y=1, x =0; x< RemainGap; x++, y = ((y<< 1)|1) );
				Value = y ;
			}
			DownBandInfoMsg +=  "0x"+Value.toString(16) + " ";
			PrevEnd =End + (32 -RemainGap-1);
		}
		else
		{
			PrevEnd =End ;
		}
	}

	RemainGap  = NumberOfTones - 1 - PrevEnd ;
	if(RemainGap != 0)
	{
		loop = RemainGap / 32 ;
		for ( j = 0 ; j < loop; j ++)
		{
			DownBandInfoMsg += "0x00000000  ";
		}
	}

	for(i =1,PrevEnd = -1 ; i <USBandNumber ; i++)
	{
		if ( document.getElementById("DisableUSBand"+i).checked == true ) 
		{
			continue;
		}

		Start 	= parseInt(document.getElementById("USStartBand"+i).value,10) ;
		End 		= parseInt(document.getElementById("USEndBand"+i).value,10) ;
		NoBand 	= Start -PrevEnd -1;
		loop 		= NoBand / 32 ;
		r_loop 	= Math.round( loop ) ;

		if(loop >= r_loop )
		{
			loop = r_loop ;
		}	
		else
		{
			loop = r_loop -1;
		}
		RemainGap = NoBand - (loop*32) ;
		for ( j = 0 ; j < loop; j ++)
		{
			UpBandInfoMsg +=  "0x00000000  ";
		}
		if(RemainGap != 0)
		{
			if( RemainGap == 31 )
			{
				Value = 0x80000000 ;
			}
			else
			{
				for( y = 1, x =0; x < RemainGap; x++, y *= 2 );
				Value = (0xffffffff - y +1 ) ;
			}
			UpBandInfoMsg	+=  "0x"+Value.toString(16) + " ";
			Start 			+= (32 - RemainGap - 1);
		}

		Band 		= End - Start - 1;
		loop 		= Band / 32 ;
		r_loop 	= Math.round( loop ) ;
		if(loop >= r_loop )
		{
			loop = r_loop ;
		}	
		else
		{
			loop = r_loop -1;
		}
		RemainGap = Band - (loop*32)  ;
		for ( j = 0 ; j < loop; j ++)
		{
			UpBandInfoMsg +=  "0xffffffff  ";
		}
		if(RemainGap != 0)
		{
			if( RemainGap == 31 )
			{
				Value = 0x7fffffff ;
			}
			else
			{
				for( y=1, x =0; x< RemainGap; x++, y = ((y<< 1)|1) );
				Value = y ;
			}
			UpBandInfoMsg +=  "0x"+Value.toString(16) + " ";
			PrevEnd =End + (32 -RemainGap-1);
		}
		else
		{
			PrevEnd =End ;
		}
	}

	RemainGap  = NumberOfTones - 1  - PrevEnd ;
	if(RemainGap != 0)
	{
		loop = RemainGap / 32 ;
		for ( j = 0 ; j < loop; j ++)
		{
			UpBandInfoMsg += "0x00000000  ";
		}
	}

	document.getElementById("USBandInfo").value = UpBandInfoMsg;
	document.getElementById("DSBandInfo").value = DownBandInfoMsg;
	return true;
}

function sortNumber(a, b)
{
	return a - b;
}

function UpdateBandInfo()
{
	var DownBandInfoMsg = "";
	var UpBandInfoMsg = "";
	var PrevEnd = -1;
	var NoBand = 0;
	var Band = 0;
	var loop = 0;
	var r_loop = 0;
	var RemainGap = 0;
	var Start = 0;
	var End = 0;
	var Value = 0;
	var x = 0;
	var y = 0;
	var i = 0;
	var j = 0;
	var k = 0;
	var Len = 0;

	var DownBandList = new Array(0);

	for(i =1; i <DSBandNumber ; i++)
	{
		if ( document.getElementById("DisableDSBand"+i).checked == true ) 
		{
			continue;
		}
		DownBandList.push(document.getElementById("DSStartBand"+i).value,
									document.getElementById("DSEndBand"+i).value);
	}
	DownBandList.sort(sortNumber);
	Len = DownBandList.length ;
	for(i =0,PrevEnd = -1 ; i <Len ; i +=2)
	{
		Start		= parseInt(DownBandList[i],10) ;
		End		= parseInt(DownBandList[i+1],10) ;
		NoBand 	= Start -PrevEnd -1;
		loop 		= NoBand / 32 ;
		r_loop 	= Math.round( loop ) ;

		if(loop >= r_loop )
		{
			loop = r_loop ;
		}	
		else
		{
			loop = r_loop -1;
		}

		RemainGap = NoBand - (loop*32) ;
		for ( j = 0 ; j < loop; j ++)
		{
			DownBandInfoMsg +=  "0x00000000  ";
		}

		if(RemainGap != 0)
		{
			if( RemainGap == 31 )
			{
				Value = 0x80000000 ;
			}
			else
			{
				for( y = 1, x =0; x < RemainGap; x++, y *= 2 );
				Value = (0xffffffff - y +1 ) ;
			}
			DownBandInfoMsg +=  "0x"+Value.toString(16) + " ";
			Start += (32 - RemainGap - 1);
		}


		Band 		= End - Start - 1;
		loop 		= Band / 32 ;
		r_loop 	= Math.round( loop ) ;
		if(loop >= r_loop )
		{
			loop = r_loop ;
		}	
		else
		{
			loop = r_loop -1;
		}
		RemainGap = Band - (loop*32)  ;
		for ( j = 0 ; j < loop; j ++)
		{
			DownBandInfoMsg +=  "0xffffffff  ";
		}
		if(RemainGap != 0)
		{
			if( RemainGap == 31 )
			{
				Value = 0x7fffffff ;
			}
			else
			{
				for( y=1, x =0; x< RemainGap; x++, y = ((y<< 1)|1) );
				Value = y ;
			}
			DownBandInfoMsg +=  "0x"+Value.toString(16) + " ";
			PrevEnd =End + (32 -RemainGap-1);
		}
		else
		{
			PrevEnd =End ;
		}
	}

	RemainGap  = NumberOfTones - 1 - PrevEnd ;
	if(RemainGap != 0)
	{
		loop = RemainGap / 32 ;
		for ( j = 0 ; j < loop; j ++)
		{
			DownBandInfoMsg += "0x00000000  ";
		}
	}

	var UpBandList = new Array(0);

	for(i =1; i <USBandNumber ; i++)
	{
		if ( document.getElementById("DisableUSBand"+i).checked == true ) 
		{
			continue;
		}
		UpBandList.push(document.getElementById("USStartBand"+i).value,
									document.getElementById("USEndBand"+i).value);
	}
	UpBandList.sort(sortNumber);
	Len = UpBandList.length ;
	for(i =0,PrevEnd = -1 ; i <Len ; i +=2)
	{
		Start		= parseInt(UpBandList[i],10) ;
		End		= parseInt(UpBandList[i+1],10) ;
		NoBand 	= Start -PrevEnd -1;
		loop 		= NoBand / 32 ;
		r_loop 	= Math.round( loop ) ;

		if(loop >= r_loop )
		{
			loop = r_loop ;
		}	
		else
		{
			loop = r_loop -1;
		}
		RemainGap = NoBand - (loop*32) ;
		for ( j = 0 ; j < loop; j ++)
		{
			UpBandInfoMsg +=  "0x00000000  ";
		}
		if(RemainGap != 0)
		{
			if( RemainGap == 31 )
			{
				Value = 0x80000000 ;
			}
			else
			{
				for( y = 1, x =0; x < RemainGap; x++, y *= 2 );
				Value = (0xffffffff - y +1 ) ;
			}
			UpBandInfoMsg	+=  "0x"+Value.toString(16) + " ";
			Start 			+= (32 - RemainGap - 1);
		}

		Band 		= End - Start - 1;
		loop 		= Band / 32 ;
		r_loop 	= Math.round( loop ) ;
		if(loop >= r_loop )
		{
			loop = r_loop ;
		}	
		else
		{
			loop = r_loop -1;
		}
		RemainGap = Band - (loop*32)  ;
		for ( j = 0 ; j < loop; j ++)
		{
			UpBandInfoMsg +=  "0xffffffff  ";
		}
		if(RemainGap != 0)
		{
			if( RemainGap == 31 )
			{
				Value = 0x7fffffff ;
			}
			else
			{
				for( y=1, x =0; x< RemainGap; x++, y = ((y<< 1)|1) );
				Value = y ;
			}
			UpBandInfoMsg +=  "0x"+Value.toString(16) + " ";
			PrevEnd =End + (32 -RemainGap-1);
		}
		else
		{
			PrevEnd =End ;
		}
	}

	RemainGap  = NumberOfTones - 1  - PrevEnd ;
	if(RemainGap != 0)
	{
		loop = RemainGap / 32 ;
		for ( j = 0 ; j < loop; j ++)
		{
			UpBandInfoMsg += "0x00000000  ";
		}
	}

	document.getElementById("USBandInfo").value = UpBandInfoMsg;
	document.getElementById("DSBandInfo").value = DownBandInfoMsg;
	return true;
}

function InsertUpDownBandRows()
{
	var len = CmUpBandInfoList.length  - 1 ;
	for ( i = 0; i <len ; i += 2)
	{
		InsertRow( 'UpStream', parseInt(CmUpBandInfoList[i+0],10) , parseInt(CmUpBandInfoList[i+1],10)  );
	}

	len = CmDownBandInfoList.length  - 1 ;
	for ( i = 0; i <len ; i += 2)
	{
		InsertRow( 'DownStream', parseInt(CmDownBandInfoList[i+0],10) , parseInt(CmDownBandInfoList[i+1],10)  );
	}
}

function UpdatePsdValuesList(  UpSize,UpMsg,  DownSize,  DownMsg, base )
{
	var UpList = UpMsg.split(" ");
	var DownList = DownMsg.split(" ");
	PsdUpSize = NumberOfTones;
	PsdDownSize = NumberOfTones ;
	var DownOrigMsg ="";  
	var UpOrigMsg ="";  
	var DownValList ="";  
	PsdUpOrigSize  = UpSize ;
	PsdDownOrigSize  =  DownSize ;
	var DownValRawMsg = "";
	var UpValRawMsg = "";
	var ToneNumber = 0;
	var MaskVal = 0;
	var DiffHeight = 0;
	var height = 0;

	for (i = 0, j=0,height = 0; i < DownSize; i++)
	{
		DownList[i]		= DownList[i].replace("(","");
		DownList[i] 	= DownList[i].replace(")","");
		DownOrigMsg		+=  DownList[i] + ",";
		DownValList 	= DownList[i].split(",");
		ToneNumber 		= parseInt(DownValList[1],10) ;
		MaskVal        = parseInt(DownValList[2],10) ;
		MaskVal        = MaskVal / 2 ;

		DiffHeight = (MaskVal - height )/ (ToneNumber - j );
		for(x= j, y = height; x < ToneNumber ; x ++, y += DiffHeight )
		{
			if( y < 1)
			{
				DownValRawMsg = DownValRawMsg + "0 ";
			}	
			else
			{
				DownValRawMsg = DownValRawMsg + y + " ";
			}	
		}
		height = MaskVal ;
		j = ToneNumber;
	}
	DownValRawMsg = DownValRawMsg + height + " ";

	for (++j; j < NumberOfTones; j++)
	{
		DownValRawMsg = DownValRawMsg   + "0 ";
	}
	PsdDownValueList = DownValRawMsg.split(" ");

	for (i = 0, j=0,height = 0; i < UpSize; i++)
	{
		UpList[i]   = UpList[i].replace("(","");
		UpList[i]   = UpList[i].replace(")","");
		UpOrigMsg   +=  UpList[i] + ",";
		UpValList   = UpList[i].split(",");
		ToneNumber  = parseInt(UpValList[1],10) ;
		MaskVal     = parseInt(UpValList[2],10) ;
		MaskVal     = MaskVal / 2 ;

		DiffHeight = (MaskVal - height )/ (ToneNumber - j );

		for(x= j, y = height; x < ToneNumber ; x ++, y += DiffHeight )
		{
			if( y < 1)
			{
				UpValRawMsg = UpValRawMsg + "0 ";
			}	
			else
			{
				UpValRawMsg = UpValRawMsg + y + " ";
			}	
		}
		height = MaskVal ;
		j = ToneNumber;
	}
	UpValRawMsg = UpValRawMsg + height + " ";

	for (++j; j < NumberOfTones; j++)
	{
		UpValRawMsg = UpValRawMsg   + "0 ";
	}
	PsdUpValueList = UpValRawMsg.split(" ");
	PsdUpOrigList = UpOrigMsg.split(",");
	PsdDownOrigList = DownOrigMsg.split(",");
	
}



function ShowRawPsdValues( )
{
	var NewWindow = window.open();
	ShowRawPsdValuesInTable(NewWindow.document , " PSD " , PsdUpOrigSize, PsdUpOrigList , PsdDownOrigSize,  PsdDownOrigList , 10 );
}

function ShowRawPsdValuesInTable(doc , Title, UpSize, UpList , DownSize,  DownList , base )
{
	var  	MaxSize = 0;
	if( UpSize > DownSize)
	{
		MaxSize = UpSize;
	}	   
	else
	{
		MaxSize = DownSize;
	}	   
	table = "<table border=1  >" ;
	table += "<tr>";
	table += " <td width=50% align=center  bgColor =" + UpStreamColour + "  >UpStream " + Title + " </td> ";
	table += " <td width=50% align=center   bgColor =" + DownStreamColour + "  >DownStream " + Title + "  </td> ";
	table += "</tr>";

	tr 	 =	"<tr>"  ;
	td     = "	<td width=50%>"  +
				" 		<table bgColor=pink  border=1  width=100%>" + 
				"			<tr> " +
				"				<td width=33% >Break Point index</td> " +
				"				<td width=33% >Tone Number</td> " +
				"				<td width=33% >PSD Value</td> " +
				"			</tr> " +
				" 		</table  >" + 
				"	</td>"  ;
	tr		+= td ;
	tr		+= td ;
	tr    += "</tr>"  ;
	table	+= tr ;		
	doc.write(table);

	for (i = 0, j= 0; i < MaxSize; i ++, j+=3 )
	{
		tr   = "<tr>" ;
		tr  += "<td width=50%><table border=1 width=100% ><tr>" ;
		tr  += "<td width=33%  bgColor =" + UpStreamColour + " > " + UpList[j+0] + " </td>" ;
		tr  += "<td width=33%  bgColor =" + UpStreamColour + " > " + UpList[j+1] + " </td>" ;
		tr  += "<td width=33%  bgColor =" + UpStreamColour + " > " + UpList[j+2] + " </td>" ;
		tr  += "</tr></table></td>" ;
		tr  += "<td width=50%><table  width=100% border=1  ><tr>" ;
		tr  += "<td width=33%  bgColor =" + DownStreamColour + " > " + DownList[j+0] + " </td>" ;
		tr  += "<td width=33%  bgColor =" + DownStreamColour + " > " + DownList[j+1] + " </td>" ;
		tr  += "<td width=33%  bgColor =" + DownStreamColour + " > " + DownList[j+2] + " </td>" ;
		tr  += "</tr></table></td>" ;
		tr  += "</tr>" ;
		doc.write(tr);
	}
	doc.write("</table>");

}  
function DisableEnableTable( TableId, CheckStatus)
{
	if(CheckStatus == true)
	{
		document.getElementById(TableId).bgColor = "lightgrey";
	}
	else
	{
		document.getElementById(TableId).bgColor = "";
	}

}
		      
function InsertNewBandInfo( Direction ,Start , End)
{
	if( Direction == "US")
	{
		CmUpBandInfoList.push(Start,End);
	}
	else
	{
		CmDownBandInfoList.push(Start,End);
	}
}	

function ChangeGraphBand( Direction , BandNumber )
{
	var xFactor = PsdBandxFactor ;
	var CheckStatus =  document.getElementById("Disable"+Direction + "Band" +BandNumber ).checked;
	var Start =  parseInt( document.getElementById(Direction + "StartBand" +BandNumber ).value ,10);
	var End =  parseInt( document.getElementById(Direction + "EndBand" +BandNumber ).value ,10);
	var x   =  document.getElementById("BandBGTable");
	var xFactorStart = 0;
	var r_xFactorStart = 0;
	if( ((BandNumber >1) && (Start == 0)) || (End == 0)  )
	{
		return;
	}

	if(CheckStatus == false )
	{
		if( Direction == "US")
		{
			ActStart =  parseInt(CmUpBandInfoList[((BandNumber -1)*2)] , 10);
			ActEnd =   parseInt(CmUpBandInfoList[((BandNumber -1)*2)+1] , 10);
		}
		else
		{
			ActStart =  parseInt(CmDownBandInfoList[((BandNumber -1)*2)] , 10);
			ActEnd =   parseInt(CmDownBandInfoList[((BandNumber -1)*2)+1] , 10);
		}
		if( Start > End)
		{
			alert( "Start point of the   " + Direction + "  Band"+ BandNumber + "   cannot be greater then End point of the Band");
			document.getElementById(Direction + "StartBand" +BandNumber ).value = ActStart;
			document.getElementById(Direction + "EndBand" +BandNumber ).value = ActEnd;
			return;
		}
		else if(! ((Start >= 0) && (Start < (NumberOfTones -1)) && (End > 0) && (End < NumberOfTones ) ))
		{
			alert( "Entered data for    "+ Direction + "  Band"+ BandNumber + "    is not valid");
			document.getElementById(Direction + "StartBand" +BandNumber ).value = ActStart;
			document.getElementById(Direction + "EndBand" +BandNumber ).value = ActEnd;
			return;
		}
			
		var TmpStart = 0;
		var TmpEnd = 0;
		var Activate = 0;

		var ActDeactivateList =  new Array( 0 );

		if(Start > ActStart)
		{
			ActDeactivateList.push(ActStart,Start, 0);
		}
		ActDeactivateList.push(Start, End, 1);
		if ( End < ActEnd)
		{
			ActDeactivateList.push(End, ActEnd,0);
		}
		if( Direction == "US")
		{
			CmUpBandInfoList[((BandNumber -1)*2)] = Start;
			CmUpBandInfoList[((BandNumber -1)*2)+1] = End;
		}
		else
		{
			CmDownBandInfoList[((BandNumber -1)*2)] = Start;
			CmDownBandInfoList[((BandNumber -1)*2)+1] = End;
		}
		var Len = ActDeactivateList.length / 3;
		for( j = 0 ; j<Len ; j++)
		{
			TmpStart	=	parseInt(ActDeactivateList[(j  *3)] , 10);
			TmpEnd		=	parseInt(ActDeactivateList[(j  *3)+1] , 10);
			Activate		=	parseInt(ActDeactivateList[(j *3)+2] , 10);

			if ( xFactor < 1) 
			{
				xFactorStart = TmpStart * xFactor  ;

				r_xFactorStart 	= Math.round( xFactorStart) ;

				if(r_xFactorStart >= xFactorStart )
				{
					xFactorStart = r_xFactorStart ;
				}	
				else
				{
					xFactorStart = r_xFactorStart +1;
				}

			}
			else
			{
				xFactorStart = TmpStart;
			}
			for(i = TmpStart ; i < TmpEnd ; i++)
			{
				if ( xFactor < 1) 
				{
				   if( ( i % (1/xFactor) ) != 0) 
				   {
					continue;
				   }		
				}
				if( Direction == "US")
				{
					if( Activate == 1)
					{
						if ( x.rows[0].cells[(xFactorStart+2)].bgColor == DownStreamColour)
						{
							x.rows[0].cells[xFactorStart+2].bgColor = UpDownStreamOverlapColour;
						}
						else if ( x.rows[0].cells[(xFactorStart+2)].bgColor != UpDownStreamOverlapColour )
						{
							x.rows[0].cells[xFactorStart+2].bgColor = UpStreamColour;
						}
					}
					else
					{
						if ( x.rows[0].cells[(xFactorStart+2)].bgColor == UpDownStreamOverlapColour)
						{
							x.rows[0].cells[xFactorStart+2].bgColor = DownStreamColour;
						}
						else
						{
							x.rows[0].cells[xFactorStart+2].bgColor = "";
						}
					}
				}
				else
				{
					if( Activate == 1)
					{
						if ( x.rows[0].cells[(xFactorStart+2)].bgColor == UpStreamColour)
						{
							x.rows[0].cells[xFactorStart+2].bgColor = UpDownStreamOverlapColour;
						}
						else if ( x.rows[0].cells[(xFactorStart+2)].bgColor != UpDownStreamOverlapColour )
						{
							x.rows[0].cells[xFactorStart+2].bgColor = DownStreamColour;
						}
					}
					else
					{
						if ( x.rows[0].cells[(xFactorStart+2)].bgColor == UpDownStreamOverlapColour)
						{
							x.rows[0].cells[xFactorStart+2].bgColor = UpStreamColour;
						}
						else
						{
							x.rows[0].cells[xFactorStart+2].bgColor = "";
						}
					}
				}				
				xFactorStart++;
			} 
		}	
	}
	else
	{
		if ( xFactor < 1) 
		{
			xFactorStart = Start * xFactor  ;

			r_xFactorStart 	= Math.round( xFactorStart) ;

			if(r_xFactorStart >= xFactorStart )
			{
				xFactorStart = r_xFactorStart ;
			}	
			else
			{
				xFactorStart = r_xFactorStart +1;
			}

		}
		else
		{
			xFactorStart = Start;
		}
		

		for(i = Start ; i < End ; i++)
		{
			if ( xFactor < 1) 
			{
			   if( ( i % (1/xFactor) ) != 0) 
			   {
				continue;
			   }		
			}
			if ( x.rows[0].cells[(xFactorStart+2)].bgColor == UpDownStreamOverlapColour)
			{
				if( Direction == "US")
				{
					x.rows[0].cells[xFactorStart+2].bgColor = DownStreamColour;
				}
				else
				{
					x.rows[0].cells[xFactorStart+2].bgColor = UpStreamColour;
				}				
			}
			else
			{
				x.rows[0].cells[xFactorStart+2].bgColor = "";
			}
			xFactorStart++;
		} 	
	}
}
