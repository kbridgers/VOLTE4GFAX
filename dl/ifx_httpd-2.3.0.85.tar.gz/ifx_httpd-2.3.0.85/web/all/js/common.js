function  ReplaceAllStr(ActStr, Str1, Str2)
{
	while (ActStr.indexOf(Str1)>-1) 
	{
	   ActStr=ActStr.replace(Str1,Str2);
	}
	return ActStr;
}
//end of  ReplaceAll()


