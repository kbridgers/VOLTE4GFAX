//#include <sys/syslog.h>
#include <ifx_emf.h>
#include "ifx_httpd_method.h"
//#include <signal.h>
//#include <unistd.h>
//#include <sys/types.h>
//#include <sys/wait.h>
//#include <ifx_common.h>
#include "./ifx_amazon_cgi.h"
//#include "./ifx_amazon_cgi_getFunctions.h"
#include "ifx_snmp_api.h"
//#include "ifx_api_ipt_common.h"
//#include <sys/ioctl.h>

void ifx_set_system_status(httpd_t wp, char_t * path, char_t * query);	// system_log.asp
int ifx_get_RuntimeGatewayIP(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_RuntimeDNSIP(int eid, httpd_t wp, int argc, char_t ** argv);
extern int ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);
extern void websNextPage(httpd_t wp);
extern int32 ifx_get_wanip_conn_type(IP_TYPE * type, int32 wan_idx);

void ifx_set_system_status(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pConnect = ifx_httpdGetVar(wp, T("connectflag"), T(""));
	char_t *pWan_Idx = ifx_httpdGetVar(wp, T("wan_idx"), T(""));
	char_t *pMode_Wan = ifx_httpdGetVar(wp, T("mode_wan"), T(""));
	char_t command[MAX_FILELINE_LEN];
	char_t sValue[MAX_FILELINE_LEN];
	char8 buf[MAX_FILELINE_LEN], sLinkType[MAX_FILELINE_LEN],
	    sAddrType[MAX_FILELINE_LEN];
	uint32 outFlag = IFX_F_DEFAULT;
	int nWanMode = 0;
	int dhcpc_pid = 0;
	FILE *fp;
	IP_TYPE nWanType;
	sLinkType[0] = '\0';
	sAddrType[0] = '\0';
	command[0] = '\0';
	

	if (pWan_Idx == NULL) {
		ifx_httpdError(wp, 400, T("Not specified WAN Index"));
		return;
	}
	/* get the wan mode out of the linkType and addrType fields for the passed wan index */
	if(!strcmp(pMode_Wan, "ip")){
		IFX_DBG("In Function for ip[%s] : value of pMode_Wan is [%s] !!",__FUNCTION__, pMode_Wan);
		sprintf(buf, "%s_%d_%s", PREFIX_WAN_IP, atoi(pWan_Idx), "linkType");
		if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, IFX_F_GET_ANY, &outFlag,sLinkType) != IFX_SUCCESS) {
		ifx_httpdWrite(wp,T("Wan connection selected does not have any atm protocol configured !!"));
		return;
		}
		} 
	else if(!strcmp(pMode_Wan, "ppp")){
		IFX_DBG("In Function for ppp [%s] : value of pMode_Wan is [%s] !!",__FUNCTION__, pMode_Wan);
		sprintf(buf, "%s_%d_%s", PREFIX_WAN_PPP, atoi(pWan_Idx), "linkType");
		if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, IFX_F_GET_ANY, &outFlag,sLinkType) != IFX_SUCCESS) {
		ifx_httpdWrite(wp,T("Wan connection selected does not have any atm protocol configured !!"));
		return;
		}
		}
	 
		switch (atoi(sLinkType)) {
		case LINK_TYPE_PPPOATM:
			nWanMode = IP_BOOT_PPPOA;
			break;
		case LINK_TYPE_PPPOE:
			nWanMode = IP_BOOT_PPPOE;
			break;
		case LINK_TYPE_EOATM:
		case LINK_TYPE_IPOATM:
			sprintf(buf, "%s_%d_%s", PREFIX_WAN_IP, atoi(pWan_Idx),
				"addrType");
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_WAN_IP, buf, IFX_F_GET_ANY,
			     &outFlag, sAddrType) != IFX_SUCCESS) {
				nWanMode = IP_BOOT_UNKNOWN;
			}
			if (atoi(sAddrType) == IP_TYPE_DHCP)
				nWanMode = IP_BOOT_DHCPC;
			break;

		case LINK_TYPE_ETH:
		case LINK_TYPE_PTM:

			if (ifx_get_wanip_conn_type(&nWanType, atoi(pWan_Idx))
			    == IFX_SUCCESS) {
				switch (nWanType) {
				case IP_TYPE_DHCP:
					nWanMode = IP_BOOT_DHCPC;
					break;
				case IP_TYPE_STATIC:
					nWanMode = IP_BOOT_FIXED;
					break;
				case IP_TYPE_AUTO:
					nWanMode = IP_BOOT_BRIDGE;
					break;
				}
			}

		}
	

	if (!gstrcmp(pConnect, T("1"))) {	// Disconnect/Release
		switch (nWanMode) {
		case IP_BOOT_DHCPC:
			sprintf(command, "/etc/rc.d/init.d/udhcpc release %s",
				pWan_Idx);
			system(command);
			break;
		case IP_BOOT_PPPOE:
			sprintf(command, "wanppp_%s_connTrigger", pWan_Idx);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_WAN_PPP, command, IFX_F_GET_ENA,
			     &outFlag, sValue) != IFX_SUCCESS) {
				ifx_httpdWrite(wp,
					       T
					       ("Wan PPP Connection selected is disabled !!"));
				return;
			} else {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("In Function [%s] : value of [%s] is [%s] !!",__FUNCTION__, command, sValue);
#endif
				if (sValue[0] == '1') {
					sprintf(command, "%s %s",
						SERVICE_PPPOE_RESTART,
						pWan_Idx);
				} else {
					sprintf(command, "%s %s",
						SERVICE_PPPOE_STOP, pWan_Idx);
				}
			}
			system(command);
			break;
		case IP_BOOT_PPPOA:
			sprintf(command, "wanppp_%s_connTrigger", pWan_Idx);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_WAN_PPP, command, IFX_F_GET_ENA,
			     &outFlag, sValue) != IFX_SUCCESS) {
				ifx_httpdWrite(wp,
					       T
					       ("Wan PPP Connection selected is disabled !!"));
				return;
			} else {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("In Function [%s] : value of [%s] is [%s] !!",
				     __FUNCTION__, command, sValue);
#endif
				if (sValue[0] == '1') {
					sprintf(command, "%s %s",
						SERVICE_PPPOA_RESTART,
						pWan_Idx);
				} else {
					sprintf(command, "%s %s",
						SERVICE_PPPOA_STOP, pWan_Idx);
				}
			}
			system(command);
			break;
		default:
			ifx_httpdError(wp, 400,
				       T("Not specified Connection type"));
			break;
		}
	} else if (!gstrcmp(pConnect, T("2"))) {	// Connect/Renew
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("In Function [%s] : wan mode is [%d] for wan [%s], req is connect !!",
		     __FUNCTION__, nWanMode, pWan_Idx);
#endif
		switch (nWanMode) {
		case IP_BOOT_DHCPC:
			sprintf(command, "/var/run/udhcpc%s.pid", pWan_Idx);
			fp = fopen(command, "r");
			if (fp != NULL) {
				fscanf(fp, "%d\n", &dhcpc_pid);
				kill(dhcpc_pid, SIGUSR1);
				fclose(fp);
			}
			sleep(3);
			break;
		case IP_BOOT_PPPOE:
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("In Function [%s] : starting pppoe on wan [%s] !!",
			     __FUNCTION__, pWan_Idx);
#endif
			sprintf(command, "%s %s", SERVICE_PPPOE_RESTART,
				pWan_Idx);
			system(command);
			sleep(3);	//000012:fchang
			sprintf(command, "wanppp_%s_connTrigger", pWan_Idx);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_WAN_PPP, command, IFX_F_GET_ENA,
			     &outFlag, sValue) != IFX_SUCCESS) {
				ifx_httpdWrite(wp,
					       T
					       ("Wan PPP Connection selected is disabled !!"));
				return;
			} else {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("In Function [%s] : value of [%s] is [%s] !!",
				     __FUNCTION__, command, sValue);
#endif
				if (sValue[0] == '1') {
					sprintf(command,
						"/etc/rc.d/init.d/ppp_demand.sh %s",
						pWan_Idx);
					system(command);
				}
			}
			break;
		case IP_BOOT_PPPOA:
			sprintf(command, "%s %s", SERVICE_PPPOA_RESTART,
				pWan_Idx);
			system(command);
			sprintf(command, "wanppp_%s_connTrigger", pWan_Idx);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_WAN_PPP, command, IFX_F_GET_ENA,
			     &outFlag, sValue) != IFX_SUCCESS) {
				ifx_httpdWrite(wp,
					       T
					       ("Wan PPP Connection selected is disabled !!"));
				return;
			} else {
				if (sValue[0] == '1') {
					sprintf(command,
						"/etc/rc.d/init.d/ppp_demand.sh %s",
						pWan_Idx);
					system(command);
				}
			}
			break;
		default:
			ifx_httpdError(wp, 400,
				       T("Not specified Connection type"));
			break;
		}
	}
	websNextPage(wp);
}

int ifx_get_RuntimeGatewayIP(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sGateway[MAX_IP_ADDR_LEN];

	memset(sGateway, 0x00, sizeof(sGateway));

	if (ifx_get_runtime_gw(sGateway) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get Gateway IP\n"));
		return -1;
	}

	ifx_httpdWrite(wp, T("%s"), sGateway);
	return 0;
}

int ifx_get_RuntimeDNSIP(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name = NULL;
	char_t sDNS1[MAX_IP_ADDR_LEN], sDNS2[MAX_IP_ADDR_LEN];
#ifdef CONFIG_FEATURE_IPv6
	char_t sDNSv61[INET6_ADDRSTRLEN], sDNSv62[INET6_ADDRSTRLEN];	//AMS
#endif
	sDNS1[0] = '\0';
	sDNS2[0] = '\0';
#ifdef CONFIG_FEATURE_IPv6
	sDNSv61[0] = '\0';
	sDNSv62[0] = '\0';
#endif
	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	if (!strcmp(name, "DNS1") || !strcmp(name, "all")) {
		if (ifx_get_runtime_dns(sDNS1, "1") != IFX_SUCCESS) {
			return -1;
		}
		ifx_httpdWrite(wp, T("%s"), sDNS1);
	} else if (!strcmp(name, "DNS2") || !strcmp(name, "all")) {
		if (ifx_get_runtime_dns(sDNS2, "2") != IFX_SUCCESS) {
			return -1;
		}
		ifx_httpdWrite(wp, T("%s"), sDNS2);
	}
#ifdef CONFIG_FEATURE_IPv6
	else if (!strcmp(name, "DNSv61") || !strcmp(name, "all")) {
		if (ifx_get_runtime_dnsv6(sDNSv61, "1") != IFX_SUCCESS) {
			return -1;
		}
		if (strchr(sDNSv61, ':') != NULL)
			ifx_httpdWrite(wp, T("%s"), sDNSv61);
	} else if (!strcmp(name, "DNSv62") || !strcmp(name, "all")) {
		if (ifx_get_runtime_dnsv6(sDNSv62, "2") != IFX_SUCCESS) {
			return -1;
		}
		if (strchr(sDNSv62, ':') != NULL)
			ifx_httpdWrite(wp, T("%s"), sDNSv62);
	}
#endif
	else
		ifx_httpdWrite(wp, T("0.0.0.0"));

	return 0;
}
