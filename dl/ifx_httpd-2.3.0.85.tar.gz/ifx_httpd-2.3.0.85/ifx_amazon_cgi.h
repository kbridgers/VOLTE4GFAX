/*
000001:tc.chen 2005/06/07 add IP QoS and 802.1P priority queue
510251:sumedh 2005/10/25 Support for DoS Attacks, ALGs, QoS, Policy based routing
604041:sumedh 2006/04/04 Parental Control Feature added (Modified MAC Filter)
*/
#include <ifx_config.h>
#include <ifx_common.h>

#include <ifx_amazon_cfg.h>

/* IFX_MULTIUSER_WEBSUPPORT: Nirav start */
#define IFX_HTTPD_GET_EXIT	-101
/* IFX_MULTIUSER_WEBSUPPORT: Nirav end */

#define xDSLRT 1
#define xDSLGW 2
#define IFX_xDSL_MODE xDSLRT

#ifdef PLATFORM_AR9
#define PLAT_NAME "AMAZON-S"
#elif PLATFORM_DANUBE
#define PLAT_NAME "DANUBE"
#elif PLATFORM_AMAZON_SE
#define PLAT_NAME "AMAZON-SE"
#elif PLATFORM_VR9
#define PLAT_NAME "VR9"
#elif PLATFORM_HN1
#define PLAT_NAME "HNX"
#elif PLATFORM_VBG400
#define PLAT_NAME "VBG400"
#endif

//////////////////////////////////////////////////////////////////////
/* Web ASP Page select structure */

typedef struct {
	char_t sPF_IP_SRC_IP[16];
	char_t sPF_IP_SRC_MASK[3];
	char_t sPF_PORT_SRC_START[6];
	char_t sPF_PORT_SRC_END[6];
	char_t sPF_IP_DST_IP[16];
	char_t sPF_IP_DST_MASK[3];
	char_t sPF_PORT_DST_START[6];
	char_t sPF_PORT_DST_END[6];
	char_t sPF_TYPE[4];
	char_t sPF_IN_IF[6];
	char_t sPF_OUT_IF[6];
//  char_t  sUnused[MAX_DATA_LEN - 54 ];

} CGI_TABLE_PACKET_FILTER;

//510251:sumedh 2005/10/25 (Policy based Routing)
typedef struct {
	char_t sPR_SRC_IP[16];
	char_t sPR_IP_SRC_MASK[3];
	char_t sPR_SRC_PORT[6];
	char_t sPR_DST_IP[16];
	char_t sPR_IP_DST_MASK[3];
	char_t sPR_DST_PORT[6];
	char_t sPR_PROTOCOL[4];
	char_t sPR_DIFFSERV[6];
	char_t sPR_OP_IF[8];

//  char_t  sUnused[MAX_DATA_LEN - 68 ];

} CGI_TABLE_POLICY_ROUTE;

////sumedh (SIP)
//typedef struct
//{
//    char_t  sSIP_PROTOCOL[4];
//      char_t  sSIP_PORT[6];
//    char_t  sSIP_PHONE_IP[16];
//
//    char_t  sUnused[MAX_DATA_LEN - 26 ];
//
//} CGI_TABLE_SIP;

// 000001:tc.chen start qos priority table for configuration
typedef struct {
	char_t sQP_IP_SRC_IP[16];
	char_t sQP_IP_SRC_MASK[3];
	char_t sQP_PORT_SRC_START[6];
	char_t sQP_PORT_SRC_END[6];
	char_t sQP_IP_DST_IP[16];
	char_t sQP_IP_DST_MASK[3];
	char_t sQP_PORT_DST_START[6];
	char_t sQP_PORT_DST_END[6];
	char_t sQP_PROTO[4];
	char_t sQP_IF[2];
	char_t sQP_DIR[2];
	char_t sQP_TYPE[2];
//  char_t  sUnused[MAX_DATA_LEN - 72 ];

} CGI_TABLE_QOS_PRIORITY;
// 000001:tc.chen end

//Subbi 13/06/2006 SNMPv3 User Database
typedef struct {
	char_t sSNMPv3_UserName[20];
	char_t sSNMPv3_UserAccess[10];
	char_t sSNMPv3_SecLevel[10];
	char_t sSNMPv3_AuthProto[5];
	char_t sSNMPv3_AuthPasswd[20];
	char_t sSNMPv3_PrivProto[10];
	char_t sSNMPv3_PrivPasswd[20];

//  char_t  sUnused[MAX_DATA_LEN - 95];

} CGI_TABLE_SNMPv3_USER_DATABASE;

//604041:sumedh - Parental Control (modified MAC Filter) web structure
typedef struct {
	char_t sPC_MAC_ADDR[19];
	char_t sPC_DAY_SELECTION[8];
	char_t sPC_TIME_START[7];
	char_t sPC_TIME_END[7];

//      char sUnused[MAX_DATA_LEN-33];
} CGI_TABLE_PARENTAL_CONTROL;
//604041:sumedh - Parental Control (modified MAC Filter) web structure ends

//604041:sumedh - Parental Control (modified MAC Filter) api structure
struct mac_filter {
	char mac_addr[19];
	char day_selection[8];	//0-Monday...6-Sunday
	char time_start[7];	//HH:MM [5 chars]
	char time_end[7];	//HH:MM [5 chars]
	int state;		//0-disable, 1-deny, 2-accept
};
//604041:sumedh - Parental Control (modified MAC Filter) api structure ends

/* Web ASP Page Table structure */
typedef struct {
	/* Web ASP Page Table index */
	int nIndex;
	/* Web ASP Page Table item status 0: Disable, 1: Enable */
	uint nState;
	/* Web ASP Page Table item value */
	union {
		CGI_TABLE_PACKET_FILTER PF_TABLE;
		CGI_TABLE_QOS_PRIORITY QP_TABLE;	// 000001:tc.chen  qos priority table for configuration
		CGI_TABLE_POLICY_ROUTE PR_TABLE;	// 510251:sumedh 2005/10/25 (Policy based Routing)
		//CGI_TABLE_SIP                 SIP_TABLE;
		CGI_TABLE_SNMPv3_USER_DATABASE SNMPv3_USERS_TABLE;	// Subbi 13/01/2006 SNMPv3 User Database
		CGI_TABLE_PARENTAL_CONTROL PC_TABLE;	//604041:sumedh
		char_t sValue[MAX_TAG_VALUE_LEN];
	} Data;
} CGI_TABLE_S;

/* HTTP connection structure */
struct connection_profil {
	/* HTTP Connected time */
	uint time;
	/* HTTP Connected IP Address */
	char_t ipaddr[44];
#ifdef CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE
	/* HTTP Connected MAC Address */
	char_t macaddr[32];
#endif /* CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE */
	/* HTTP Connected block flag */
	uint block;
	/* HTTP Connected Allow flag */
	uint allowed;
	/* User of this session */
	char user[MAX_UNAME_LEN];
};

struct connection_profil_list {
	struct connection_profil connection;
	struct connection_profil_list *next;
};

#define EATW(s)                            {while (gisspace(*s)) s++;}	// This MACRO is for eating white space.

typedef struct {
	uint nIndex;
	uint nValue;
} ST_LEASE_TIME;

typedef struct {
	uint nRangeIdx;
	char_t sRetValue[MAX_DATA_LEN];
} ST_NAT_PORT_MAP_LIST;

//805071:<IFTW-leon> start
struct auto_pvc {
	int empty;
	int vpi;
	int vci;
	int previous;		//805151:<IFTW-leon>
};
//805071:<IFTW-leon> end
