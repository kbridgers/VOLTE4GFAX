/************************************************************************
 *
 *    Copyright (c) 2005
 *    Infineon Technologies AG
 *    St. Martin Strasse 53; 81669 Muenchen; Germany
 *
 *    THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED
 *    NON-EXCLUSIVE, WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE
 *    AND SUBLICENSE THIS SOFTWARE IS FREE OF CHARGE.
 *    
 *    THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY
 *    DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR
 *    IMPLIED, INCLUDING WITHOUT LIMI?TATION, WAR?RANTIES OR REPRESENTATIONS
 *    OF WORKMANSHIP, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    DURABILITY, THAT THE OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR
 *    FREE OR FREE OF NY THIRD PARTY CALIMS, INCLUDING WITHOUT LIMITATION
 *    CLAIMS OF THIRD PARTY INTELLECTUAL PROPERTY INFRINGEMENT.
 *    
 *    EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND
 *    EXCEPT FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE
 *    FOR ANY CLAIM OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT,
 *    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 *    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *    --------------------------------------------------------------------
 *    
 *        Project : INCA IP Phone - Config Module
 *        Block   :  
 *        Creator : Radvajesh.M
 *        File    : ifx_cm_web.c
 *        Abstract: Management API's to Access CM
 *        Date    : 17-06-2004
 *    
 *    Modification History:
 *           By              Date     Ver.   Modification Description
 *           --------------- -------- -----  -----------------------------
 *           Radvajesh.M     17=06=05 1.0     Initial Dev
 *           Radvajesh.M     09-06-05 2.1    Added SNMP Support
 ************************************************************************/
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <memory.h>
#include "ifx_common_defs.h"
#include "ifx_ipc.h"
#include "ifx_cm.h"

#define IFX_WEB_MAX_PB_ENTRIES 100
STATIC int16 nCmFifoFd, nMgtFifoFd, nMgtId;
char g_cflag;
x_IFX_CM_Msg g_xCmMsg;
x_IFX_CM_AppAddressBookEntry axPBEntry[IFX_WEB_MAX_PB_ENTRIES];
int16 nNoOfPbEntries;
/*****************************************************************************
 *  Function Name   : IFX_CM_MgtInit
 *  Description     : This function is used by webs/snmp to Initialise the 
 *                    CM Interface
 *
 *  Input Values    :
 *  Output Values   :
 *
 *  Return Value    : IFX_CM_SUCCESS - On Success
 *                    IFX_CM_FAIL - On Failure
 *  Notes           :
 ****************************************************************************/
PUBLIC char8 IFX_CM_MgtInit(IN uchar8 ucModuleId)
{
	int16 ntmpfd;

	printf("SHWETA:IN IFX_CM_MgtInit\n");

	if (ucModuleId == IFX_IPC_APP_ID_WEB) {

		/* Check if Web Fifo Exists, if not Create it */
		if (access(IFX_IPC_WEB_FIFO, F_OK) == -1) {
			if (mkfifo(IFX_IPC_WEB_FIFO, IFX_IPC_FIFO_PERM)) {
				return IFX_CM_FAIL;
			}
		}
	}
	if (ucModuleId == IFX_IPC_APP_ID_SNMP) {

		/* Check if SNMP Fifo Exists, if not Create it */
		if (access(IFX_IPC_SNMP_FIFO, F_OK) == -1) {
			if (mkfifo(IFX_IPC_SNMP_FIFO, IFX_IPC_FIFO_PERM)) {
				return IFX_CM_FAIL;
			}
		}
	}

	/* Check if CM Fifo Exists, if not Create it */
	if (access(IFX_IPC_CM_FIFO, F_OK) == -1) {
		if (mkfifo(IFX_IPC_CM_FIFO, IFX_IPC_FIFO_PERM)) {
			return IFX_CM_FAIL;
		}
	}
	ntmpfd = open(IFX_IPC_CM_FIFO, O_RDONLY | O_NDELAY);
	nCmFifoFd = open(IFX_IPC_CM_FIFO, O_WRONLY);

	if (nCmFifoFd < 0) {
		return IFX_CM_FAIL;
	}

	close(ntmpfd);
	if (ucModuleId == IFX_IPC_APP_ID_WEB) {
		/* Open Web fifo in blocking mode */
		ntmpfd = open(IFX_IPC_WEB_FIFO, O_RDONLY | O_NDELAY);
		ntmpfd = open(IFX_IPC_WEB_FIFO, O_WRONLY);
		nMgtFifoFd = open(IFX_IPC_WEB_FIFO, O_RDONLY);
		close(ntmpfd);
		if (nMgtFifoFd < 0) {
			return IFX_CM_FAIL;
		}
		nMgtId = IFX_IPC_APP_ID_WEB;
	}

	if (ucModuleId == IFX_IPC_APP_ID_SNMP) {
		/* Open SNMP fifo in blocking mode */
		ntmpfd = open(IFX_IPC_SNMP_FIFO, O_RDONLY | O_NDELAY);
		ntmpfd = open(IFX_IPC_SNMP_FIFO, O_WRONLY);
		nMgtFifoFd = open(IFX_IPC_SNMP_FIFO, O_RDONLY);
		close(ntmpfd);
		if (nMgtFifoFd < 0) {
			return IFX_CM_FAIL;
		}
		nMgtId = IFX_IPC_APP_ID_SNMP;
	}
	return IFX_CM_SUCCESS;
}

/*****************************************************************************
 * man  Function Name   : IFX_CM_MgtShut
 *  Description     : This function is called by webs/snmp to shutdown the
 *                    CM Interface
 *
 *  Input Values    :
 *  Output Values   :
 *
 *  Return Value    : IFX_CM_SUCCESS - On Success
 *                    IFX_CM_FAIL - On Failure
 *  Notes           :
 ****************************************************************************/
PUBLIC char8 IFX_CM_MgtShut()
{
	close(nCmFifoFd);
	close(nMgtFifoFd);
	return IFX_CM_SUCCESS;
}

/*****************************************************************************
 *  Function Name   : IFX_CM_RecvDataFromCM 
 *  Description     : This function is used by webs to Get Values from CM 
 *                    
 *                   
 *  Input Values    : CM Message 
 *  Output Values   : CM Message 
 *                    
 *  Return Value    : IFX_CM_SUCCESS - On Success
 *                    IFX_CM_FAIL - On Failure
 *  Notes           :
 ****************************************************************************/
PUBLIC char8 IFX_CM_RecvDataFromCM(IN_OUT x_IFX_CM_Msg * pxCmMsg)
{
	int16 nBytes = 0, ncount = 0, nindex = 0, nflag = 0;
	x_IFX_IPC_Msg xTxMsg, xRxMsg;

	/* format the message */
	memcpy(&xTxMsg.acMsg, pxCmMsg, sizeof(x_IFX_CM_Msg));
	xTxMsg.xHdr.ucFrom = nMgtId;
	xTxMsg.xHdr.ucTo = IFX_IPC_APP_ID_CM;
	xTxMsg.xHdr.unMsgSize = sizeof(x_IFX_CM_Msg);

	/* Check the validity of Message Type */
	if (pxCmMsg->ucMsgType == IFX_CM_GET_REQ) {
		/* Write Request to CM Fifo */
		nBytes =
		    write(nCmFifoFd, (char8 *) & xTxMsg,
			  sizeof(x_IFX_CM_Msg) + IFX_IPC_HDR_SIZE);

		if (nBytes != sizeof(x_IFX_CM_Msg) + IFX_IPC_HDR_SIZE) {
			printf("Error Write req bytes to CM %d\n", nBytes);
			return IFX_CM_FAIL;
		}

		/* Block in the WS Fifo */
		nBytes =
		    read(nMgtFifoFd, (char8 *) & xRxMsg,
			 sizeof(x_IFX_CM_Msg) + IFX_IPC_HDR_SIZE);
		if (nBytes < 0) {
			return IFX_CM_FAIL;
		}
		memcpy((char8 *) pxCmMsg, (char8 *) & xRxMsg.acMsg,
		       sizeof(x_IFX_CM_Msg));

		/* Check the response */
		if ((pxCmMsg->ucMsgType == IFX_CM_GET_RSP) ||
		    (pxCmMsg->ucMsgType == IFX_CM_GET_ERR_RSP)) {
			if (pxCmMsg->ucInfoType == IFX_CM_APP_ADDR_ENTRY) {
				for (ncount = 0; ncount < 105; ncount += 5) {
					nindex =
					    pxCmMsg->uxData.xAddrBookCfg.
					    ucNoOfEntries;
					memcpy(&axPBEntry[ncount],
					       &pxCmMsg->uxData.xAddrBookCfg.
					       axAddrBookEntry,
					       sizeof
					       (x_IFX_CM_AppAddressBookEntry) *
					       nindex);

					if (nindex < 5) {
						nNoOfPbEntries =
						    ncount + nindex;
						nflag = 1;
						break;
					}
					nBytes =
					    read(nMgtFifoFd, (char8 *) & xRxMsg,
						 sizeof(x_IFX_CM_Msg) +
						 IFX_IPC_HDR_SIZE);

					memcpy((char8 *) pxCmMsg,
					       (char8 *) & xRxMsg.acMsg,
					       sizeof(x_IFX_CM_Msg));
					if (nBytes < 0) {
						printf("<CM_WEB> Fail 0\n");
						return IFX_CM_FAIL;
					}
				}
				if (nNoOfPbEntries == 99 && !nflag)
					nNoOfPbEntries++;
			}
		} else {
			printf("<CM_WEB> Fail 1\n");
			return IFX_CM_FAIL;
		}
	} else {
		printf("<CM_WEB> Fail 2\n");
		return IFX_CM_FAIL;
	}

	return IFX_CM_SUCCESS;
}

/*****************************************************************************
 *  Function Name   : IFX_CM_SendDataToCM
 *  Description     : This function is used by webs to configure parameters 
 *                    in the CM 
 *
 *  Input Values    : CM Message 
 *  Output Values   : CM Message 
 *                     
 *  Return Value    : IFX_CM_SUCCESS - On Success
 *                    IFX_CM_FAIL - On Failure
 *  Notes           :
 ****************************************************************************/
PUBLIC char8 IFX_CM_SendDataToCM(IN_OUT x_IFX_CM_Msg * pxCmMsg)
{
	int16 nBytes = 0;
	x_IFX_IPC_Msg xTxMsg, xRxMsg;

	/* format the message */
	memcpy(&xTxMsg.acMsg, pxCmMsg, sizeof(x_IFX_CM_Msg));
	xTxMsg.xHdr.ucFrom = nMgtId;
	xTxMsg.xHdr.ucTo = IFX_IPC_APP_ID_CM;
	xTxMsg.xHdr.unMsgSize = sizeof(x_IFX_CM_Msg);

	/* Check the validity of Message Type */
	if (pxCmMsg->ucMsgType == IFX_CM_SET_REQ) {
		/* Write Request to CM Fifo */
		nBytes =
		    write(nCmFifoFd, (char8 *) & xTxMsg,
			  sizeof(x_IFX_CM_Msg) + IFX_IPC_HDR_SIZE);
		if (nBytes != sizeof(x_IFX_CM_Msg) + IFX_IPC_HDR_SIZE) {
			printf("<CM_WEB> write to CM fail\n");
			return IFX_CM_FAIL;
		}

		/* Block in the WS Fifo */
		nBytes =
		    read(nMgtFifoFd, (char8 *) & xRxMsg,
			 sizeof(x_IFX_CM_Msg) + IFX_IPC_HDR_SIZE);
		if (nBytes < 0) {
			printf("<CM_WEB> read from CM fail %d bytes\n", nBytes);
			return IFX_CM_FAIL;
		}
		printf("<CM_WEB> bytes read from cm is %d\n", nBytes);
		/* To check if this would work.  Trying to avoid memcpy here */
		memcpy((char8 *) pxCmMsg, (char8 *) & xRxMsg.acMsg,
		       sizeof(x_IFX_CM_Msg));

		/* Check the response */
		if (pxCmMsg->ucMsgType == IFX_CM_SET_RSP) {
			return IFX_CM_SUCCESS;
		} else if (pxCmMsg->ucMsgType == IFX_CM_SET_ERR_RSP) {
			return IFX_CM_SUCCESS;
		} else {
			printf("<CM_WEB>wrong msg type, the type is %d\n",
			       pxCmMsg->ucMsgType);
			return IFX_CM_FAIL;
		}
	} else {
		printf("<CM_WEB>wrong request\n");
		return IFX_CM_FAIL;
	}
	return IFX_CM_SUCCESS;
}
