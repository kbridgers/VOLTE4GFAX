#include <ifx_emf.h>
//#include <ifx_api_structs.h>
#include "ifx_httpd_method.h"
#include "./ifx_amazon_cgi.h"
#include "./ifx_cgi_common.h"
#include "ifx_common.h"
//#include "ltq_mapi_mediaserver.h"

#if defined(CONFIG_FEATURE_CELL_WAN_SUPPORT) || defined(CONFIG_FEATURE_WWAN_LTE_SUPPORT)

extern int32 ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);

void ltq_get_cell_wan_profiles(int eid, httpd_t wp, int argc, char_t ** argv);
void ltq_get_cell_wan_profiles(int eid, httpd_t wp, int argc, char_t ** argv)
{
	LTQ_MAPI_Cell_WAN cell_wan;

	int32 ret;
	uint32 index = 0, i = 0;
	int32 outFlag = IFX_F_DEFAULT;
	char8 sValue[MAX_NAME_SIZE];

	if (ifx_GetObjData
	    (FILE_RC_CONF, TAG_CELL_WAN, "cell_wan_Count", IFX_F_GET_ANY,
	     (IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS) {
		IFX_API_LOG("GetObjData not success[%s:%d]", __FUNCTION__,
			    __LINE__);
	}
	index = atoi(sValue);

	if (index < 1 || index > 32767) {
		IFX_DBG("FAILURE In Function [%s:%d:index overflow]", __FUNCTION__,
			__LINE__);
	} else {
		memset(&cell_wan, 0, sizeof(LTQ_MAPI_Cell_WAN));
		for (i = 0; i < index; i++) {
			ret = ltq_mapi_get_cell_wan(&cell_wan, i, 0);
			IFX_DBG("In Function [%s:%d:%s]", __FUNCTION__, __LINE__,
				cell_wan.profName);
			IFX_DBG("In Function [%s:%d:%s]", __FUNCTION__, __LINE__,
				cell_wan.user);

			if ((ret == IFX_SUCCESS)) {

				ifx_httpdWrite(wp,
				       T
				       ("<option value=\"%d\" %s>%s</option>"),
				       i, (cell_wan.ena == 1) ? "selected" : "",
				       cell_wan.profName);

			} else {
				IFX_DBG("FAILURE In Function [%s:%d:%s]", __FUNCTION__,
					__LINE__, cell_wan.apn);
				IFX_DBG("In Function [%s:%d:%s]", __FUNCTION__,
					__LINE__, cell_wan.user);
			}

		}
	}
}

void ltq_get_cell_wan(int eid, httpd_t wp, int argc, char_t ** argv);
void ltq_get_cell_wan(int eid, httpd_t wp, int argc, char_t ** argv)
{
	LTQ_MAPI_Cell_WAN cell_wan;

	// char8   *name= NULL;
	//char8   *scpeId = NULL;
	int32 ret;
	uint32 index = 4, i = 0;

	memset(&cell_wan, 0, sizeof(LTQ_MAPI_Cell_WAN));
	for (i = 0; i < index; i++) {
		ret = ltq_mapi_get_cell_wan(&cell_wan, i, 0);
		IFX_DBG("In Function [%s:%d:%s]", __FUNCTION__, __LINE__,
			cell_wan.apn);
		IFX_DBG("In Function [%s:%d:%s]", __FUNCTION__, __LINE__,
			cell_wan.user);

		if ((ret == IFX_SUCCESS)) {
			if (cell_wan.ena) {
				ifx_httpdWrite(wp, T("ena[%d]=1;\n"), i);
			} else {
				ifx_httpdWrite(wp, T("ena[%d]=0;\n"), i);
			}
			ifx_httpdWrite(wp, T("profName[%d]=\"%s\";\n"), i,
				       cell_wan.profName);
			ifx_httpdWrite(wp, T("apn[%d]=\"%s\";\n"), i,
				       cell_wan.apn);
			ifx_httpdWrite(wp, T("user[%d]=\"%s\";\n"), i,
				       cell_wan.user);
			ifx_httpdWrite(wp, T("passwd[%d]=\"%s\";\n"), i,
				       cell_wan.passwd);
			if (cell_wan.authType) {
				ifx_httpdWrite(wp, T("authType[%d]=1;\n"), i);
			} else {
				ifx_httpdWrite(wp, T("authType[%d]=0;\n"), i);
			}
			if (cell_wan.usePIN) {
				ifx_httpdWrite(wp, T("usePIN[%d]=1;\n"), i);
			} else {
				ifx_httpdWrite(wp, T("usePIN[%d]=0;\n"), i);
			}
			ifx_httpdWrite(wp, T("PIN[%d]=\"%d\";\n"), i,
				       cell_wan.pin);
			ifx_httpdWrite(wp, T("dialNum[%d]=\"%s\";\n"), i,
				       cell_wan.dialNum);
			if (cell_wan.idleDisc) {
				ifx_httpdWrite(wp, T("idleDisc[%d]=1;\n"), i);
			} else {
				ifx_httpdWrite(wp, T("idleDisc[%d]=0;\n"), i);
			}
			ifx_httpdWrite(wp, T("idleDiscTO[%d]=\"%d\";\n"), i,
				       (cell_wan.idleDiscTO / 60));
		} else {
			IFX_DBG("In Function [%s:%d:%s]", __FUNCTION__,
				__LINE__, cell_wan.apn);
			IFX_DBG("In Function [%s:%d:%s]", __FUNCTION__,
				__LINE__, cell_wan.user);
		}

	}
}

void ltq_set_cell_wan(httpd_t wp, char_t * path, char_t * query);
void ltq_set_cell_wan(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pcellwan;
	LTQ_MAPI_Cell_WAN cell_wan;
	memset(&cell_wan, 0, sizeof(cell_wan));
	uint32 index = 0, ret = 0, cell_wan_count = 0, i = 0;
	int32 outFlag = IFX_F_DEFAULT;
	char8 sValue[MAX_NAME_SIZE];
	IFX_DBG("In Function [%s:%d]", __FUNCTION__, __LINE__);

	if (ifx_GetObjData
	    (FILE_RC_CONF, TAG_CELL_WAN, "cell_wan_Count", IFX_F_GET_ANY,
	     (IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS) {
		IFX_API_LOG("GetObjData not success[%s:%d]", __FUNCTION__,
			    __LINE__);
	}

	cell_wan_count = atoi(sValue);

	pcellwan = ifx_httpdGetVar(wp, T("cellpro"), T(""));
	index = (gatoi(pcellwan));
	IFX_DBG("In Function [%s:%d:%d]", __FUNCTION__, __LINE__, index);

	pcellwan = ifx_httpdGetVar(wp, T("stat"), T(""));

	for (i = 0; i < cell_wan_count; i++) {
		ret = ltq_mapi_get_cell_wan(&cell_wan, i, 0);
		if (cell_wan.ena && (i != index) && gatoi(pcellwan) == 1) {
			cell_wan.ena = IFX_DISABLED;
			if (ltq_mapi_set_cell_wan
			    (IFX_OP_MOD, &cell_wan,
			     IFX_F_MODIFY) != IFX_SUCCESS) {
				ifx_httpdError(wp, 500,
					       T
					       ("Failed to save WWAN Configurations"));
				return;
			}
			break;
		}

	}

	ret = ltq_mapi_get_cell_wan(&cell_wan, index, 0);
	if (ret != IFX_SUCCESS) {
		ifx_httpdError(wp, 500,
			       T("Failed to save WWAN Configurations"));
		return;
	}

        if (gatoi(pcellwan) == 1) {
                cell_wan.ena = IFX_ENABLED;
        } else {
                cell_wan.ena = IFX_DISABLED;
        }

	IFX_DBG("In Function [%s:%d]", __FUNCTION__, __LINE__);
	pcellwan = ifx_httpdGetVar(wp, T("ProfileName"), T(""));
	sprintf(cell_wan.profName, "%s", pcellwan ? pcellwan : "");

	IFX_DBG("In Function [%s:%d]", __FUNCTION__, __LINE__);
	pcellwan = ifx_httpdGetVar(wp, T("AccessPoint"), T(""));
	sprintf(cell_wan.apn, "%s", pcellwan ? pcellwan : "");

	IFX_DBG("In Function [%s:%d]", __FUNCTION__, __LINE__);
	pcellwan = ifx_httpdGetVar(wp, T("username"), T(""));
	sprintf(cell_wan.user, "%s", pcellwan ? pcellwan : "");

	pcellwan = ifx_httpdGetVar(wp, T("password"), T(""));
	sprintf(cell_wan.passwd, "%s", pcellwan ? pcellwan : "");

	pcellwan = ifx_httpdGetVar(wp, T("authtype"), T(""));
	if (gatoi(pcellwan) == 1) {
		cell_wan.authType = IFX_ENABLED;
	} else {
		cell_wan.authType = IFX_DISABLED;
	}

	pcellwan = ifx_httpdGetVar(wp, T("usePin"), T(""));
	if (gatoi(pcellwan) == 1) {
		cell_wan.usePIN = IFX_ENABLED;
	} else {
		cell_wan.usePIN = IFX_DISABLED;
	}

	pcellwan = ifx_httpdGetVar(wp, T("PinCode"), T(""));
	cell_wan.pin = (gatoi(pcellwan));
	IFX_DBG("In Function [%s:%d]", __FUNCTION__, __LINE__);
	pcellwan = ifx_httpdGetVar(wp, T("num"), T(""));
	sprintf(cell_wan.dialNum, "%s", pcellwan ? pcellwan : "");

	pcellwan = ifx_httpdGetVar(wp, T("idle"), T(""));
	if (gatoi(pcellwan) == 1) {
		cell_wan.idleDisc = IFX_ENABLED;
	} else {
		cell_wan.idleDisc = IFX_DISABLED;
	}
	pcellwan = ifx_httpdGetVar(wp, T("Timeout"), T(""));
	cell_wan.idleDiscTO = (gatoi(pcellwan)* 60);
	if (ltq_mapi_set_cell_wan(IFX_OP_MOD, &cell_wan, IFX_F_MODIFY) !=
	    IFX_SUCCESS) {
		ifx_httpdError(wp, 500,
			       T("Failed to save WWAN Configurations"));
		return;
	}

	ifx_httpdRedirect(wp, T("wwan_setting.asp"));
}

void ltq_get_cell_modem_status(int eid, httpd_t wp, int argc, char_t ** argv);
void ltq_get_cell_modem_status(int eid, httpd_t wp, int argc, char_t ** argv)
{

	LTQ_MAPI_MODEM_STATUS modem_status;

	int32 ret = 0;

	memset(&modem_status, 0, sizeof(LTQ_MAPI_MODEM_STATUS));

	ret = ltq_mapi_get_cell_modem_status(&modem_status, 0);

	if ((ret == IFX_SUCCESS)) {

		ifx_httpdWrite(wp, T("<table class=\"tableInfo\">"));
		ifx_httpdWrite(wp,
			       T
			       ("<tr><th class=\"curveLeft\">WWAN Modem details</th><th class=\"curveRight\">Values</th></tr>"));

		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td>Manufacturer</td>"));
		ifx_httpdWrite(wp, T("<td id=\"modemmanu\" >%s</td>"),
			       modem_status.modemManu);
		ifx_httpdWrite(wp, T("</tr>"));

		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td>Model</td>"));
		ifx_httpdWrite(wp, T("<td id=\"modemmodel\">%s</td>"),
			       modem_status.modemModel);
		ifx_httpdWrite(wp, T("</tr>"));

		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td>IMEI</td>"));
		ifx_httpdWrite(wp, T("<td id=\"imei\">%s</td>"),
			       modem_status.esn_imei);
		ifx_httpdWrite(wp, T("</tr>"));

		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td>Sim Status</td>"));
		if (modem_status.simSta) {
			ifx_httpdWrite(wp,
				       T("<td id=\"simstatus\">Active</td>"));
		} else {
			ifx_httpdWrite(wp,
				       T("<td id=\"simstatus\">Inactive</td>"));
		}
		ifx_httpdWrite(wp, T("</tr>"));

		ifx_httpdWrite(wp, T("</table><br><br>"));

		ifx_httpdWrite(wp, T("<table class=\"tableInfo\">"));
		ifx_httpdWrite(wp,
			       T
			       ("<tr><th class=\"curveLeft\">Service Provider details</th><th class=\"curveRight\">Values</th></tr>"));

		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td>Service Provider</td>"));
		ifx_httpdWrite(wp, T("<td id=\"celloper\" >%s</td>"),
			       modem_status.cellOper);
		ifx_httpdWrite(wp, T("</tr>"));

		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td>Connection Type</td>"));
		if (modem_status.cellWanType) {
			ifx_httpdWrite(wp, T("<td>LTE</td>"));
		} else {
			ifx_httpdWrite(wp, T("<td>3G</td>"));
		}
		ifx_httpdWrite(wp, T("</tr>"));

		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td>Signal Strength</td>"));
		ifx_httpdWrite(wp,
			       T
			       ("<td id=\"sigstrength\"><div id=\"div_tower\" align=\"center\"><script type=\"text/javascript\">tower_anim('',%.0f,1);</script></div></td>"),
			       (float)(((float)modem_status.sigStrngthPct /
					31) * 100));
		ifx_httpdWrite(wp, T("</tr>"));

		ifx_httpdWrite(wp, T("<tr>"));
		ifx_httpdWrite(wp, T("<td>Connection Status</td>"));
		if (modem_status.cellWanSta) {
			ifx_httpdWrite(wp,
				       T("<td id=\"wanstatus\">Active</td>"));
		} else {
			ifx_httpdWrite(wp,
				       T("<td id=\"wanstatus\">Inactive</td>"));
		}
		ifx_httpdWrite(wp, T("</tr>"));

		ifx_httpdWrite(wp, T("</table>"));

		/*                  ifx_httpdWrite(wp, T("cellWanType=\"%d\";\n"),modem_status.cellWanType);
		   ifx_httpdWrite(wp, T("modemManu=\"%s\";\n"),modem_status.modemManu);
		   ifx_httpdWrite(wp, T("modemModel=\"%s\";\n"),modem_status.modemModel);
		   ifx_httpdWrite(wp, T("esn_imei=\"%s\";\n"),modem_status.esn_imei);
		   ifx_httpdWrite(wp, T("cellOper=\"%s\";\n"),modem_status.cellOper);
		   ifx_httpdWrite(wp, T("sigStrngthPct=\"%d\";\n"),modem_status.sigStrngthPct);
		   if(modem_status.simSta){
		   ifx_httpdWrite(wp, T("simSta=1;\n"));
		   }else{
		   ifx_httpdWrite(wp, T("simSta=0;\n"));
		   }
		   if(modem_status.cellWanSta){
		   ifx_httpdWrite(wp, T("cellWanSta=1;\n"));
		   }else{
		   ifx_httpdWrite(wp, T("cellWanSta=0;\n"));
		   } */
	} else {
		ifx_httpdWrite(wp,
			       T
			       ("<div align=\"center\">WWAN USB modem not initialized / connected.</div>"));
	}
}
#endif
