#!/bin/sh

if [ ! -n "$1" ] ; then
	echo "Usage : create_customer_package.sh SOURCE_PATH"
	exit 0
fi

sed -i -e 's/^CONFIG_FULL_PACKAGE/#CONFIG_FULL_PACKAGE/g' build.sh 
cp -a $1/../amazon-sip/ifx_mips/source/user/opensource/ifx_httpd/CGI/voip/libvoip.so . 
rm -f create_customer_package.sh
