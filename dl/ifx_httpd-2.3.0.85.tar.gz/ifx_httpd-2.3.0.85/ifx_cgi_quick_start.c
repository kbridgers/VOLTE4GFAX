//#include <sys/syslog.h>
#include <ifx_emf.h>
#include "ifx_httpd_method.h"
//#include <signal.h>
//#include <unistd.h>
//#include <sys/types.h>
//#include <sys/wait.h>
//#include <ifx_common.h>
#include "./ifx_amazon_cgi.h"
#include "./ifx_cgi_common.h"
//#include "./ifx_amazon_cgi_getFunctions.h"
//#include "ifx_snmp_api.h"
//#include "ifx_api_ipt_common.h"
//#include <sys/ioctl.h>

extern int ifx_get_all_wan_conn_names(char **wan_conn_names, int *count);
extern int32 ifx_set_vcc_encap_type(char *vpivci, VC_ENCAP type, uint32 flags);
extern void ifx_set_adsl_vcconfig(httpd_t wp, char_t * path, char_t * query);
extern void cgi_set_vlan_ch_entry(httpd_t wp, char_t * path, char_t * query);
extern int ifx_set_bridge_settings(httpd_t wp, char_t * path, char_t * query);
extern int ifx_set_wan_static(httpd_t wp, char_t * path, char_t * query);
extern int ifx_set_wan_dhcp(httpd_t wp, char_t * path, char_t * query);
extern int ifx_set_wan_pppoa(httpd_t wp, char_t * path, char_t * query);
extern int ifx_set_wan_pppoe(httpd_t wp, char_t * path, char_t * query);
extern void ifx_set_wan_eth_channel_config(httpd_t wp, char_t * path,
					   char_t * query);
extern void ifx_set_wan_ptm_channel_config(httpd_t wp, char_t * path,
					   char_t * query);
extern int ifx_set_wan(httpd_t wp, char_t * path, char_t * query);
extern int32 ifx_get_another_fvp_from_dist_fvp(char8 * secName, char8 * fName,
					       char8 * fValue, char8 * fRetName,
					       char8 * fRetValue, uint32 flags);
extern int ifx_get_wan_vcc_state(char *vcChannel);
extern void websNextPage(httpd_t wp);
extern char *status_str;
extern int ltq_httpdUpdateVal(httpd_t wp, char_t * var, char_t * value);

int ifx_get_encap(int eid, httpd_t wp, int argc, char_t ** argv)
{
	IFX_ID iid;
	int32 nWAN_IDX = 0, def_encap;
	char wanConnName[MAX_CONN_NAME_LEN];

	memset(&iid, 0x00, sizeof(iid));
	if (ifx_get_default_wan_if(&iid, &nWAN_IDX, wanConnName, IFX_F_DEFAULT)
	    != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to get details of default WAN connection", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;
	}

	if(encap_get_from_wan_iid(&iid, &def_encap) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to get encap mode for WAN [%s]", __FUNCTION__,
			__LINE__, wanConnName);
#endif
		return IFX_FAILURE;
	}
#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] ", __FUNCTION__, __LINE__);
#endif
	ifx_httpdWrite(wp, T("%d"), def_encap);
	return IFX_SUCCESS;
}

int ifx_get_vlanid(int eid, httpd_t wp, int argc, char_t ** argv)
{
	IFX_ID iid;
	int32 nWAN_IDX = 0, def_vlanId;
	char wanConnName[MAX_CONN_NAME_LEN];

	memset(&iid, 0x00, sizeof(iid));
	if (ifx_get_default_wan_if(&iid, &nWAN_IDX, wanConnName, IFX_F_DEFAULT) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to get details of default WAN connection", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;
	}
	if(vlan_get_from_wan_iid(&iid, &def_vlanId) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to get vlan id for WAN [%s]", __FUNCTION__,
			__LINE__, wanConnName);
#endif
		return IFX_FAILURE;
	}
#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] ", __FUNCTION__, __LINE__);
#endif
	if(def_vlanId != -1)
		ifx_httpdWrite(wp, T("%d"), def_vlanId);
	return IFX_SUCCESS;
}

int ifx_get_VcChannel_modified(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t def_vcc[8] = { 0 };
	IFX_ID iid;
	int32 nWAN_IDX = 0;
	char wanConnName[MAX_CONN_NAME_LEN];

	memset(&iid, 0x00, sizeof(iid));
	if (ifx_get_default_wan_if(&iid, &nWAN_IDX, wanConnName, IFX_F_DEFAULT)
	    != IFX_SUCCESS) {
		return IFX_FAILURE;
	}

	if(vcc_get_from_wan_iid(&iid, def_vcc) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s] Error is finding def vcc, return value is : %s",
			__FUNCTION__, def_vcc);
#endif
	} else {
		ifx_httpdWrite(wp, T("%s"), def_vcc);
	}
	return IFX_SUCCESS;
}

int ifx_quick_start_wan(httpd_t wp, char_t * path, char_t * query,
			 char_t * pNewVcc, char_t * pNewConnType,
			 char_t * pNewWANIndex, char_t * pNewVlanId)
{

	uint32		outFlag = IFX_F_DEFAULT;
	int32		iRet = 0, nWAN_IDX = 0;
	IFX_ID		prevDefIID;
	char8		prefixWan[MAX_NAME_SIZE], secName[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN];
	WAN_TYPE new_wan_type = WAN_TYPE_IP;
#ifdef CONFIG_FEATURE_IFX_VOIP
	int32		prev_sip_if = 0;
	WAN_TYPE	prev_wan_type = WAN_TYPE_IP;
#endif				// CONFIG_FEATURE_IFX_VOIP

	char_t *Wan_Mode = ifx_httpdGetVar(wp, T("wan_mode"), T(""));

#ifdef IFX_LOG_DEBUG
	IFX_DBG("In Function [%s]:[%d] :wan mode is %s for idx [%s]!!\n",
		__FUNCTION__, __LINE__, Wan_Mode, pNewWANIndex);
#endif

	memset(buf, 0x00, sizeof(buf));
	memset(&prevDefIID, 0x00, sizeof(prevDefIID));

	if (!gstrcmp(Wan_Mode, "ATM")) {
		iRet = ifx_set_wan(wp, path, query);
		if (iRet != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("In Function [%s]:[%d] :ifx_set_wan failed!!\n",
				__FUNCTION__, __LINE__);
#endif
			goto ErrorHandler;
		}
	} else if (!gstrcmp(Wan_Mode, "PTM")) {
		iRet = ifx_set_wan(wp, path, query);
		if (iRet != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("In Function [%s]:[%d] :ifx_set_wan failed!!\n",
				__FUNCTION__, __LINE__);
#endif
			goto ErrorHandler;
		}
	} else if (!gstrcmp(Wan_Mode, "ETH")) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("In Function [%s] :if eth wan is selected !!\n",
			__FUNCTION__);
#endif
		iRet = ifx_set_wan(wp, path, query);
		if (iRet != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("In Function [%s]:[%d] :ifx_set_wan failed!!\n",
				__FUNCTION__, __LINE__);
#endif
			goto ErrorHandler;
		}
	}

	/* similar to IFX_GET_WAN_SELECTED_INDEX without return statement */
	if(ifx_GetObjData(FILE_SYSTEM_STATUS, "http_wan_vcc_select", "WAN_VCC", IFX_F_DEFAULT,
		  &outFlag, buf) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get wan index !!\n\n"));
		return -1;
	}

	if(strlen(buf)) {
		if(strstr(buf, "WANIP")) {
			sscanf(buf, "WANIP%d", &nWAN_IDX);
			new_wan_type = WAN_TYPE_IP;
			sprintf(prefixWan, "%s", PREFIX_WAN_IP);
			sprintf(secName, "%s", TAG_WAN_IP);
		}
		else {
			sscanf(buf, "WANPPP%d", &nWAN_IDX);
			new_wan_type = WAN_TYPE_PPP;
			sprintf(prefixWan, "%s", PREFIX_WAN_PPP);
			sprintf(secName, "%s", TAG_WAN_PPP);
		}
	}
	else {
		if (!strcmp(pNewConnType, "3") || !strcmp(pNewConnType, "4")) {
			if(ifx_get_sec_count(TAG_WAN_PPP, &nWAN_IDX) !=
					IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("In Function [%s]:[%d] : Failed to get section count for [%s]!!\n",
				__FUNCTION__, __LINE__, TAG_WAN_PPP);
#endif
			return -1;
			}
			new_wan_type = WAN_TYPE_PPP;
			sprintf(prefixWan, "%s", PREFIX_WAN_PPP);
			sprintf(secName, "%s", TAG_WAN_PPP);
		}
		else {
			if(ifx_get_sec_count(TAG_WAN_IP, &nWAN_IDX) !=
					IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("In Function [%s]:[%d] : Failed to get section count for [%s]!!\n",
				__FUNCTION__, __LINE__, TAG_WAN_IP);
#endif
			return -1;
			}
			new_wan_type = WAN_TYPE_IP;
			sprintf(prefixWan, "%s", PREFIX_WAN_IP);
			sprintf(secName, "%s", TAG_WAN_IP);
		}
	}

/* TBD : adaptation needed */
#ifdef CONFIG_FEATURE_IFX_VOIP
	/* configure new WAN connection as default VoIP interface. but pass DONT_ACTIVATE & DONT_WRITE_TO_FLASH flag to mapi */
	if ((ifx_GetObjData
	     (FILE_RC_CONF, TAG_SIP, "SIP_IF", IFX_F_GET_ANY, NULL,
	      buf)) != IFX_SUCCESS) {
		return -1;
	}
	if (strstr(buf, "IP") != NULL) {
		sscanf(buf, "WANIP%d", &prev_sip_if);
		prev_wan_type = WAN_TYPE_IP;
	} else {
		sscanf(buf, "WANPPP%d", &prev_sip_if);
		prev_wan_type = WAN_TYPE_IP;
	}

#if 0
	// set voip for wan connection
	if (ifx_set_voip_interface
	    (nWAN_IDX, new_wan_type,
	     IFX_F_MODIFY | IFX_F_INT_DONT_CONFIGURE |
	     IFX_F_DONT_WRITE_TO_FLASH) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400,
			       "Failed to configure WAN[%d] as the default VoIP interface !!",
			       nWAN_IDX);
		return -1;
	}
#endif
#endif
/* TBD : adaptation needed */

	if (!gstrcmp(pNewConnType, "3")) {
		iRet = ifx_set_wan_pppoe(wp, path, query);
		if (iRet != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("In Function [%s]:[%d] :PPPoE is selected and failed !!\n",__FUNCTION__, __LINE__);
#endif
			goto ErrorHandler;
		}
	} else if (!gstrcmp(pNewConnType, "4")) {
		iRet = ifx_set_wan_pppoa(wp, path, query);
		if (iRet != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("In Function [%s]:[%d] :PPPoA is selected and failed !!\n",__FUNCTION__, __LINE__);
#endif
			goto ErrorHandler;
		}
	} else if (!gstrcmp(pNewConnType, "1")) {
		iRet = ifx_set_wan_dhcp(wp, path, query);
		if (iRet != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("In Function [%s]:[%d] :Dhcp is selected and failed !!\n",__FUNCTION__, __LINE__);
#endif
			goto ErrorHandler;
		}
	} else if (!gstrcmp(pNewConnType, "2")) {
		iRet = ifx_set_wan_static(wp, path, query);
		if (iRet != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("In Function [%s]:[%d] :Static is selected and failed !!\n",__FUNCTION__, __LINE__);
#endif
			goto ErrorHandler;
		}
	} else {
		iRet = ifx_set_bridge_settings(wp, path, query);
		if (iRet != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("In Function [%s]:[%d] :Bridge is selected and failed !!\n",__FUNCTION__, __LINE__);
#endif
			goto ErrorHandler;
		}
	}


      ErrorHandler:
	/* if WAN connection configuration has failed, (iRet == IFX_FAILURE), then restore old default VoIP */
	if (iRet != IFX_SUCCESS) {
#ifdef CONFIG_FEATURE_IFX_VOIP
		iRet =
		    ifx_set_voip_interface(prev_sip_if, prev_wan_type,
					   IFX_F_MODIFY |
					   IFX_F_INT_DONT_CONFIGURE |
					   IFX_F_DONT_WRITE_TO_FLASH);
#endif
	return -1;
	}
	return 0;
}

#ifdef CONFIG_FEATURE_NAPT
int32 ifx_get_wan_port(char_t * pWAN_VCC)
{
	int32 count = 0, ret = IFX_SUCCESS, num_entries = 0;
	int32 i = 0;
	char_t buf[MAX_FILELINE_LEN];
	char_t *wan_conn_names = NULL, wan_conn_name[MAX_NAME_SIZE];
	VIRTUAL_SERVER *virtual = NULL;
	wan_conn_name[0] = '\0';
	if ((ret =
	     ifx_get_all_wan_conn_names(&wan_conn_names,
					&count)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get wan connection names !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}

	if ((ret =
	     ifx_get_virtual_server_info(&num_entries, &virtual,
					 IFX_F_DEFAULT)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get the virtual server info !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}

	for (i = 0; i < num_entries; i++) {
		gsprintf(buf, T("nat_virtualser_%d_wanConnIf"), i);
		if (strlen((virtual + i)->wan_conn_if) == 0)
			sprintf(wan_conn_name, "%s", "\0");
		else {
			memset(wan_conn_name, 0x00, sizeof(wan_conn_name));
			LTQ_STRNCPY(wan_conn_name, (virtual + i)->wan_conn_if,
				MAX_NAME_SIZE);
		}
		if (!gstrcmp(wan_conn_name, pWAN_VCC)) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("%s[%s have port mapping on it]", __FUNCTION__,
				wan_conn_name);
#endif
			IFX_MEM_FREE(virtual)
			    IFX_MEM_FREE(wan_conn_names)
			    return -1;

		}
	}
      IFX_Handler:
	IFX_MEM_FREE(virtual)
	    IFX_MEM_FREE(wan_conn_names)
	    return 0;
}
#endif				//CONFIG_FEATURE_NAPT

//for quickstart
void ifx_quick_start(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pNewConnType = NULL;
	char_t *pNewConnTypeE = NULL;
	char_t *pNewVcc1 = NULL;
	char_t *Wan_Mode = NULL;
	char_t *pNewVlanId = NULL;
	char_t *pChannel = NULL;
	char_t pNewVcc[MAX_NAME_SIZE];
	int ret = -1;
	char8 *retVal = NULL, buf[MAX_FILELINE_LEN], sValue[MAX_NAME_SIZE];
	char_t sNewConnClass[4] = { 0 };
	char_t *pNewWANIndex = NULL;
	int32 iVccExist = 0;
	int32 iVlanExit = 0;
	buf[0] = '\0';
	memset(sValue, 0x00, sizeof(sValue));

	// extract data from the buffer passed from web
	pNewVcc1 = ifx_httpdGetVar(wp, T("vcSetting"), T(""));
	ifx_httpdGetVar(wp, T("vcSetting"), T(""));
	pNewConnType = ifx_httpdGetVar(wp, T("WT"), T(""));
	pNewConnTypeE = ifx_httpdGetVar(wp, T("WT1"), T(""));
	ifx_httpdGetVar(wp, T("CapMode"), T(""));
	Wan_Mode = ifx_httpdGetVar(wp, T("wan_mode"), T(""));
	pNewVlanId = ifx_httpdGetVar(wp, T("vlan_id"), T(""));
	pChannel = ifx_httpdGetVar(wp, T("vcChannel"), T(""));
#ifdef IFX_LOG_DEBUG
	IFX_DBG
	    ("Inside [%s]:[%d] mode selected= %s pNewConnType=%s pNewVlanId = %s, pChannel = %s",
	     __FUNCTION__, __LINE__, Wan_Mode, pNewConnType, pNewVlanId,
	     pChannel);
#endif

/*code added to disable to auto-detect when one try to configure wan from quick setup*/
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
	WAN_MODE wanMode = WAN_MODE_ATM;
	WAN_PHY_CFG pstWanPhy;
	ifx_get_wan_phy_cfg(&pstWanPhy);
	wanMode = compute_wan_mode(pstWanPhy.phy_mode, pstWanPhy.wan_tc);
  mapi_autodetect_disable_for_wanmode(wanMode);
#endif

	if (!gstrcmp(Wan_Mode, "ATM")) {

		// set the new Connection Class ppp or nas
		if ((!strncmp(pNewConnType, "3", 1))
		    || (!strncmp(pNewConnType, "4", 1)))
			strcpy(sNewConnClass, "ppp");
		else
			strcpy(sNewConnClass, "nas");

		// CREATE VPI VCI
		// check if vpi/vci is existing or not
		strcpy(pNewVcc, pNewVcc1);
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("[%s:%d]ifx_ret_substr_from_distfield --------->>>pNewVcc %s",
		     __FUNCTION__, __LINE__, pNewVcc);
#endif
		if ((ret =
		     ifx_ret_substr_from_distfield(FILE_RC_CONF,
						   TAG_ADSL_VCCHANNEL, "vcc",
						   pNewVcc,
						   &retVal)) != IFX_SUCCESS) {
			ifx_set_adsl_vcconfig(wp, path, query);
			ret = IFX_SUCCESS;
		}
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("[%s:%d]ifx_ret_substr_from_distfield ----ADSL--- %s------>>>pNewVcc %s",
		     __FUNCTION__, __LINE__, retVal, pNewVcc);
#endif
		if ((ret =
		     ifx_ret_substr_from_distfield(FILE_RC_CONF,
						   TAG_ADSL_VCCHANNEL, "vcc",
						   pNewVcc,
						   &retVal)) != IFX_SUCCESS) {
			iVccExist = 0;
			ret = IFX_SUCCESS;
		} else {
			sprintf(buf, "%s_l2ifName", retVal);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, buf,
			     IFX_F_GET_ANY, NULL, sValue) == IFX_SUCCESS) {
				sprintf(buf, "%s.%s", sValue, pNewVlanId);
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_VLAN_CFG, buf,
				     IFX_F_GET_ANY, NULL,
				     sValue) != IFX_SUCCESS) {
					iVccExist = 0;
					ret = IFX_SUCCESS;
				}
			}
		}
		if (ret != IFX_SUCCESS) {
			iVccExist = 1;
		}
#ifdef IFX_LOG_DEBUG
		IFX_DBG("%s:%d---iVccExist--- %d", __FUNCTION__, __LINE__,
			iVccExist);
#endif

		if (iVccExist == 0) {
			/* Check for max PVC during WAN connection creation */
			//if(ifx_mapi_get_queue_add_check(IFX_MAPI_QoS_WAN_ATM) != IFX_SUCCESS) {
			/* TODO : pramod */
			/* put some error string for err_page.html */
			/*              COPY_TO_STATUS("%s", "<span class=\"textTitle\">Error : You cannot configure more than 14 WAN connections</span>");
			   ifx_httpdRedirect(wp, "quick_wan.asp");
			   IFX_MEM_FREE(retVal);
			   return;
			   } */

			// create vpi vci
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("Inside [%s]:[%d] mode selected= %s pNewConnType=%s pNewVlanId [%s] pnewvcc [%s]",
			     __FUNCTION__, __LINE__, Wan_Mode, pNewConnType,
			     pNewVlanId, pNewVcc);
#endif
			//if (atoi(pNewVlanId) != -1) {
			if (strlen(pNewVlanId)) {

				cgi_set_vlan_ch_entry(wp, path, query);
			}
			ret = ifx_quick_start_wan(wp, path, query, pNewVcc, pNewConnType, pNewWANIndex, pNewVlanId);
		} else {

			// now you have wan,  vpi/vci and connType to create wan
			// create the wan connection now
			//set as default
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("Inside [%s]:[%d] mode selected= %s pNewConnType=%s pNewVlanId = %s",
			     __FUNCTION__, __LINE__, Wan_Mode, pNewConnType,
			     pNewVlanId);
#endif
			ret = ifx_quick_start_wan(wp, path, query, pNewVcc,
					    pNewConnType, pNewWANIndex,
					    pNewVlanId);
		}
	}

	if (!gstrcmp(Wan_Mode, "ETH")) {
		if ((!strncmp(pNewConnType, "3", 1))
		    || (!strncmp(pNewConnType, "4", 1)))
			strcpy(sNewConnClass, "ppp");
		else
			strcpy(sNewConnClass, "ip");

		if ((ret =
		     ifx_ret_substr_from_distfield(FILE_RC_CONF,
						   TAG_VLAN_CFG, "l2ifName",
						   pChannel,
						   &retVal)) != IFX_SUCCESS) {
			iVlanExit = 0;
		} else {
			iVlanExit = 1;
		}

		if (iVlanExit == 0) {
			// create eth channel
			cgi_set_vlan_ch_entry(wp, path, query);
			 ret = ifx_quick_start_wan(wp, path, query, pNewVcc,
					    pNewConnTypeE, pNewWANIndex,
					    pNewVlanId);
			IFX_MEM_FREE(retVal);
		} else {
			 ret = ifx_quick_start_wan(wp, path, query, pNewVcc,
					    pNewConnType, pNewWANIndex,
					    pNewVlanId);
		}
	}

	if (!gstrcmp(Wan_Mode, "PTM")) {

		if ((!strncmp(pNewConnType, "3", 1))
		    || (!strncmp(pNewConnType, "4", 1)))
			strcpy(sNewConnClass, "ppp");
		else
			strcpy(sNewConnClass, "ip");

		// check if ptm vhannel is existing or not

		if ((ret =
		     ifx_ret_substr_from_distfield(FILE_RC_CONF,
						   TAG_VLAN_CFG, "l2ifName",
						   pChannel,
						   &retVal)) != IFX_SUCCESS) {
			iVlanExit = 0;
		} else {
			iVlanExit = 1;
		}

		if (iVlanExit == 0) {
			// create ptm channel
			cgi_set_vlan_ch_entry(wp, path, query);

			// create new wan connection
			//set as default
			  ret = ifx_quick_start_wan(wp, path, query, pNewVcc,
					    pNewConnTypeE, pNewWANIndex,
					    pNewVlanId);
			IFX_MEM_FREE(retVal);
		} else {
			 ret = ifx_quick_start_wan(wp, path, query, pNewVcc,
					    pNewConnType, pNewWANIndex,
					    pNewVlanId);
		}
	}
	if(ret == IFX_SUCCESS)
	{
	COPY_TO_STATUS("%s",
		       "<font size=\"2\" bold color=\"green\" face=\"Arial, Helvetica, sans-serif\">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;WAN setup is successfully configured!!</font>");
	ifx_httpdRedirect(wp, T("quick_wan.asp"));
	}

IFX_Handler:
	if (ret != IFX_SUCCESS) {
		ifx_httpdRedirect(wp, T("err_page.html"));
	}
	IFX_MEM_FREE(retVal);
	return;

}

void ifx_wlan_enabled(int eid, httpd_t wp, int argc, char_t ** argv)
{
#ifdef CONFIG_FEATURE_IFX_WIRELESS
	ifx_httpdWrite(wp, T("1"));
#else
	ifx_httpdWrite(wp, T("0"));
#endif
}
