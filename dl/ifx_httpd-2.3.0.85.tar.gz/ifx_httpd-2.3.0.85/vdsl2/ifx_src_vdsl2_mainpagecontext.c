
/*******************************************************************************
       Copyright (c) 2002, Infineon Technologies.  All rights reserved.
 
                               No Warranty                                                 
   Because the program is licensed free of charge, there is no warranty for 
   the program, to the extent permitted by applicable law.  Except when     
   otherwise stated in writing the copyright holders and/or other parties   
   provide the program "as is" without warranty of any kind, either         
   expressed or implied, including, but not limited to, the implied         
   warranties of merchantability and fitness for a particular purpose. The  
   entire risk as to the quality and performance of the program is with
   you.  should the program prove defective, you assume the cost of all     
   necessary servicing, repair or correction.                               
                                                                            
   In no event unless required by applicable law or agreed to in writing
   will any copyright holder, or any other party who may modify and/or      
   redistribute the program as permitted above, be liable to you for        
   damages, including any general, special, incidental or consequential     
   damages arising out of the use or inability to use the program           
   (including but not limited to loss of data or data being rendered        
   inaccurate or losses sustained by you or third parties or a failure of   
   the program to operate with any other programs), even if such holder or  
   other party has been advised of the possibility of such damages. 
********************************************************************************       
   Module      : $RCSfile: ifx_src_vdsl2_mainpagecontext.c,v $
   Date        : $Date: 
   Description : 
*******************************************************************************/
#include	<ifx_emf.h>
#include	<signal.h>
#include	<unistd.h>
#include	<sys/types.h>
#include	<sys/wait.h>
#include	<sys/socket.h>
#include	<sys/ioctl.h>
#include	<arpa/inet.h>
#include	<netinet/in.h>
#include	<net/if.h>
#include	<net/if_arp.h>
#include	<ifx_common.h>
#include	"./ifx_amazon_cgi.h"
#include	"ifx_httpd_method.h"

//joelin #include       "ifx_common_defs.h"
//joelin #include       "ifx_web_common.h"
#include	<sys/reboot.h>
#include	"ifx_vdsl2_common.h"

int ifx_get_Vdsl2Main(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
//joelin change from ejArgs to ifx_httpd_parse_args
	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 200, T("Insufficient args\n"));
		return -1;
	}
	ifx_httpdWrite(wp, T(" Vdsl2 Settings \n"));

	return 0;
}

void ifx_Vdsl2_PageTitle(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
//joelin change from ejArgs to ifx_httpd_parse_args
	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 200, T("Insufficient args\n"));
		return;
	}

	if (!gstrcmp(name, T("Vdsl2ChannelConfig"))) {
		ifx_httpdWrite(wp,
			       T
			       (" Configuration of line per bearer basis. \n"));
	}

	if (!gstrcmp(name, T("Vdsl2LineConfig"))) {
		ifx_httpdWrite(wp, T(" Configuration of line . \n"));
	}

	if (!gstrcmp(name, T("Vdsl2ProfileConfig"))) {
		ifx_httpdWrite(wp,
			       T
			       (" Configuration of line for specific band plans. \n"));
	}

	if (!gstrcmp(name, T("Vdsl2BandsConfig"))) {
		ifx_httpdWrite(wp, T("  \n"));
	}

	if (!gstrcmp(name, T("Vdsl2LoopBack"))) {
		ifx_httpdWrite(wp,
			       T
			       (" Setting Of Loop Backs.( System - System Loop,LoopBack after MAC layer or Line Side LoopBack) \n"));
	}

	if (!gstrcmp(name, T("Vdsl2ActivateDeactivate"))) {
		ifx_httpdWrite(wp,
			       T(" Activating or Deactivating the line \n"));
	}

	if (!gstrcmp(name, T("Vdsl2LineStatus"))) {
		ifx_httpdWrite(wp, T(" Status of the Line. \n"));
	}

	if (!gstrcmp(name, T("Vdsl2ChannelStatus"))) {
		ifx_httpdWrite(wp, T(" Status of the bearer . \n"));
	}

	if (!gstrcmp(name, T("Vdsl2xTCStatus"))) {
		ifx_httpdWrite(wp, T(" Status of the Layer2. \n"));
	}

	if (!gstrcmp(name, T("Vdsl2VersionInfo"))) {
		ifx_httpdWrite(wp, T(" Version Numbers. \n"));
	}

	if (!gstrcmp(name, T("Vdsl2SNRGraph"))) {
		ifx_httpdWrite(wp, T("  \n"));
	}

	if (!gstrcmp(name, T("Vdsl2BitsGraph"))) {
		ifx_httpdWrite(wp, T("  \n"));
	}

}
