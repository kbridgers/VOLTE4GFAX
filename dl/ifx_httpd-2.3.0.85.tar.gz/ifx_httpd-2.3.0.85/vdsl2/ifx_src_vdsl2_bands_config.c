
/*******************************************************************************
       Copyright (c) 2002, Infineon Technologies.  All rights reserved.
 
                               No Warranty                                                 
   Because the program is licensed free of charge, there is no warranty for 
   the program, to the extent permitted by applicable law.  Except when     
   otherwise stated in writing the copyright holders and/or other parties   
   provide the program "as is" without warranty of any kind, either         
   expressed or implied, including, but not limited to, the implied         
   warranties of merchantability and fitness for a particular purpose. The  
   entire risk as to the quality and performance of the program is with
   you.  should the program prove defective, you assume the cost of all     
   necessary servicing, repair or correction.                               
                                                                            
   In no event unless required by applicable law or agreed to in writing
   will any copyright holder, or any other party who may modify and/or      
   redistribute the program as permitted above, be liable to you for        
   damages, including any general, special, incidental or consequential     
   damages arising out of the use or inability to use the program           
   (including but not limited to loss of data or data being rendered        
   inaccurate or losses sustained by you or third parties or a failure of   
   the program to operate with any other programs), even if such holder or  
   other party has been advised of the possibility of such damages. 
********************************************************************************       
   Module      : $RCSfile: ifx_src_vdsl2_bands_config.c,v $
   Date        : $Date: 
   Description : 
*******************************************************************************/
#include	<ifx_emf.h>
#include	<signal.h>
#include	<unistd.h>
#include	<sys/types.h>
#include	<sys/wait.h>
#include	<sys/socket.h>
#include	<sys/ioctl.h>
#include	<arpa/inet.h>
#include	<netinet/in.h>
#include	<net/if.h>
#include	<net/if_arp.h>
#include	<ifx_common.h>
#include	"./ifx_amazon_cgi.h"

#include	"ifx_httpd_method.h"
//joelin #include       "ifx_common_defs.h"
//joelin #include       "ifx_web_common.h"
#include	<sys/reboot.h>
#include	"ifx_vdsl2_common.h"

/*********************************************************
* bands_config.asp
********************************************************/

static int ifx_get_vdsl2PsdMaskTblData(httpd_t wp);

static int
ifx_get_vdsl2PsdMaskGetData(unsigned int Direction,
			    unsigned int *pLength, unsigned char **ppValues);

static int ifx_get_vdsl2CmMaskTblData(httpd_t wp);

static int
ifx_get_vdsl2CmMaskGetData(unsigned int Direction,
			   unsigned int *pLength, unsigned char **ppValues);

void ifx_get_wizard_bands_config(httpd_t wp, char_t * path, char_t * query)
{
	websNextPage(wp);
}

void ifx_set_wizard_bands_config(httpd_t wp, char_t * path, char_t * query)
{
	int ret = 0;
	int ret1 = -1;
	char pCommand[MAX_WEB_CMD_NAME_LENGTH];
	char pParams[MAX_WEB_PARAMS_LENGTH];
	char *pResult;
	int LineNumber = 0;
	unsigned int Direction;
	char *pUSBandInfo;
	char *pDSBandInfo;

	Direction = UPSTREAM;
	pUSBandInfo = ifx_httpdGetVar(wp, T("USBandInfo"), T(""));
	if (pUSBandInfo == 0) {
		ifx_httpdError(wp, 200, T("Setup Error"));
		return;
	}
	sprintf(pCommand, "g997smcs");
	sprintf(pParams, "%hu %u %s ", LineNumber, Direction, pUSBandInfo);
	if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS) {
		sscanf(pResult, "nReturn=%d ", &ret1);
	}
	if (ret1 != 0) {
		ret = ret1;
	}

	Direction = DOWNSTREAM;
	pDSBandInfo = ifx_httpdGetVar(wp, T("DSBandInfo"), T(""));
	if (pDSBandInfo == 0) {
		ifx_httpdError(wp, 200, T("Setup Error"));
		return;
	}
	sprintf(pCommand, "g997smcs");
	sprintf(pParams, "%hu %u %s ", LineNumber, Direction, pDSBandInfo);
	if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS) {
		sscanf(pResult, "nReturn=%d ", &ret1);
	}
	if (ret1 != 0) {
		ret = ret1;
	}
	if (ret != 0) {
		ifx_httpdWrite(wp, T("<html>\n"));
		ifx_httpdWrite(wp, T("<head>\n"));
		ifx_httpdWrite(wp,
			       T
			       ("<script language=\"JavaScript\" src=\"../../script.js\"></script>\n"));
		ifx_httpdWrite(wp,
			       T
			       ("<title>Vdsl2 | Bands Config DSL Api Error</title>\n"));
		ifx_httpdWrite(wp, T("</head>\n"));
		ifx_httpdWrite(wp, T("<body bgColor=\"#e4e9f1\">\n"));
		ifx_httpdWrite(wp,
			       T
			       ("<table width=\"80%\" border=\"1\" cellspacing=\"0\" cellpadding=\"10\" height=\"30%\">\n"));
		ifx_httpdWrite(wp, T("<tr align=left>\n"));
		ifx_httpdWrite(wp, T("<td class=\"text\">Status</td>"));
		ifx_httpdWrite(wp, T("<td class=\"text\" id=\"nError\"</td>"));
		ifx_httpdWrite(wp, T("</tr>\n"));
		ifx_httpdWrite(wp, T("</table>\n"));
		ifx_httpdWrite(wp, T("<script language=\"JavaScript\">\n"));
		ifx_httpdWrite(wp, T("OnReceiveReturn(%d)\n"), ret);
		ifx_httpdWrite(wp, T("</script>\n"));
		ifx_httpdWrite(wp, T("</body>\n"));
		ifx_httpdWrite(wp, T("</html>\n"));
		return;
	}
	ifx_httpdNextPage(wp);
}

void
ifx_get_vdsl2_bands_config_graphs_TblData(int eid,
					  httpd_t wp, int argc, char_t ** argv)
{
	int ret = 0, ret1 = 0;

	if ((ret1 = ifx_get_vdsl2PsdMaskTblData(wp)) != 0) {
		ret = ret1;
	}
	if ((ret1 = ifx_get_vdsl2CmMaskTblData(wp)) != 0) {
		ret = ret1;
	}
	ifx_httpdWrite(wp, T("document.getElementById(\"RetVal\").value"));
	ifx_httpdWrite(wp, T(" = %d\n"), ret);
}

static int ifx_get_vdsl2PsdMaskTblData(httpd_t wp)
{
	int ret = -1, ret1 = -1, ret2 = -1;
	unsigned char *pValues;
	unsigned int UpLength = 0;
	unsigned int DownLength = 0;

	do {
		ret1 =
		    ifx_get_vdsl2PsdMaskGetData(UPSTREAM, &UpLength, &pValues);
		if (ret1 == WEB_SUCCESS) {
			printf(" pValues = 0x%x", (unsigned int)pValues);
			printf(" pValues Length= 0x%x", strlen(pValues));
			ifx_httpdWrite(wp, T("doPsdBarGraph( "));
			if (UpLength > 0) {
				ifx_httpdWrite(wp, T("%d,\"%s\","), UpLength,
					       (pValues));
			} else {
				ifx_httpdWrite(wp, T("0,\"\","));
			}
		} else {
			UpLength = 0;
		}
		ret2 =
		    ifx_get_vdsl2PsdMaskGetData(DOWNSTREAM, &DownLength,
						&pValues);
		if ((ret2 == WEB_SUCCESS) && (ret1 == WEB_SUCCESS)) {
			if (DownLength > 0) {
				ifx_httpdWrite(wp, T("%d,\"%s\""), DownLength,
					       pValues);
			} else {
				ifx_httpdWrite(wp, T("0,\"\""));
			}
		} else if ((ret2 == WEB_SUCCESS) && (ret1 != WEB_SUCCESS)) {
			ifx_httpdWrite(wp, T("doPsdBarGraph( "));
			ifx_httpdWrite(wp, T("0,\"\","));
			if (DownLength > 0) {
				ifx_httpdWrite(wp, T("%d,\"%s\""), DownLength,
					       pValues);
			} else {
				ifx_httpdWrite(wp, T("0,\"\""));
			}
		} else if ((ret2 != WEB_SUCCESS) && (ret1 == WEB_SUCCESS)) {
			ifx_httpdWrite(wp, T("0,\"\""));
		} else {
			break;
		}
		ret = 0;
		ifx_httpdWrite(wp, T(");\n"));
	} while (0);
	return ret;
}

static int
ifx_get_vdsl2PsdMaskGetData(unsigned int Direction,
			    unsigned int *pLength, unsigned char **ppValues)
{
	int ret = -1;
	char pCommand[MAX_WEB_CMD_NAME_LENGTH];
	char pParams[MAX_WEB_PARAMS_LENGTH];
	char *pResult, *pParse, *pTemp, pTmpResult[100];
	int Mode = 100;
	int LineNumber = 0;

	sprintf(pCommand, "g997pmcg");
	sprintf(pParams, "%hu %u %u ", LineNumber, Direction, Mode);
	if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS) {

		pParse = pResult;
		sscanf(pParse,
		       "nReturn=%d  nLine=%d nDirection=%d nMode=%d nNumData=%u \n\r",
		       &ret, &LineNumber, &Direction, &Mode, pLength);
		pParse = strpbrk(pParse, "\"");
		pParse++;
		ifx_RemoveNewLines(pParse);
		pTemp = strpbrk(pParse, "\"");
		if (pTemp != NULL) {
			*pTemp = '\0';
		}
		*ppValues = pParse;
	}
	return ret;
}

void ifx_RemoveNewLines(char *pParse)
{
	char *pTmpParse, *pTmpParse1, *pTemp;
	unsigned int Diff;
	pTmpParse = pParse;
	pTmpParse1 = pParse;
	while ((pTemp = strpbrk(pTmpParse, "\n")) != 0) {
		Diff = (pTemp - pTmpParse);
		memcpy(pTmpParse1, pTmpParse, Diff);
		pTmpParse1 += Diff;
		/* *pTmpParse1++ = ' '; */
		pTmpParse += (Diff + 2);
	}

	Diff = strlen(pTmpParse);
	memcpy(pTmpParse1, pTmpParse, Diff);
	pTmpParse1 += Diff;
	*pTmpParse1 = 0;
}

static int ifx_get_vdsl2CmMaskTblData(httpd_t wp)
{
	int ret = -1, ret1 = -1, ret2 = -1;
	unsigned char *pValues;
	unsigned int UpLength = 0;
	unsigned int DownLength = 0;

	do {
		ret1 =
		    ifx_get_vdsl2CmMaskGetData(UPSTREAM, &UpLength, &pValues);
		if (ret1 == WEB_SUCCESS) {
			ifx_httpdWrite(wp, T("doCmBarGraph( "));
			ifx_httpdWrite(wp, T("%d,\"%s\","), UpLength,
				       (pValues));
		} else {
			UpLength = 0;
		}
		ret2 =
		    ifx_get_vdsl2CmMaskGetData(DOWNSTREAM, &DownLength,
					       &pValues);
		if ((ret2 == WEB_SUCCESS) && (ret1 == WEB_SUCCESS)) {
			ifx_httpdWrite(wp, T("%d,\"%s\""), DownLength,
				       (pValues));
		} else if ((ret2 == WEB_SUCCESS) && (ret1 != WEB_SUCCESS)) {
			ifx_httpdWrite(wp, T("doCmBarGraph( "));
			ifx_httpdWrite(wp, T("0,\"\","));
			ifx_httpdWrite(wp, T("%d,\"%s\""), DownLength,
				       (pValues));
		} else if ((ret2 != WEB_SUCCESS) && (ret1 == WEB_SUCCESS)) {
			ifx_httpdWrite(wp, T("0,\"\""));
		} else {
			break;
		}
		ret = 0;
		ifx_httpdWrite(wp, T(");\n"));
	} while (0);
	return ret;
}

static int
ifx_get_vdsl2CmMaskGetData(unsigned int Direction,
			   unsigned int *pLength, unsigned char **ppValues)
{
	int ret = -1;
	char pCommand[MAX_WEB_CMD_NAME_LENGTH];
	char pParams[MAX_WEB_PARAMS_LENGTH];
	char *pResult, *pParse, *pTemp, pTmpResult[100];
	int LineNumber = 0;

	sprintf(pCommand, "g997smcg");
	sprintf(pParams, "%hu %u ", LineNumber, Direction);
	if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS) {
		pParse = pResult;
		sscanf(pParse,
		       "nReturn=%d nLine=%d nDirection=%d nNumData=%u \n\r",
		       &ret, &LineNumber, &Direction, pLength);
		sprintf(pTmpResult,
			"nReturn=%d nLine=%d nDirection=%d nNumData=%u \n\r",
			ret, LineNumber, Direction, *pLength);
		pParse = strpbrk(pParse, "\"");
		pParse++;
		ifx_RemoveNewLines(pParse);
		pTemp = strpbrk(pParse, "\"");
		if (pTemp != NULL) {
			*pTemp = '\0';
		}
		*ppValues = pParse;
	}
	return ret;
}
