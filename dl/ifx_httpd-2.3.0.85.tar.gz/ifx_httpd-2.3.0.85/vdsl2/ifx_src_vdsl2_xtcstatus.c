
/*******************************************************************************
       Copyright (c) 2002, Infineon Technologies.  All rights reserved.
 
                               No Warranty                                                 
   Because the program is licensed free of charge, there is no warranty for 
   the program, to the extent permitted by applicable law.  Except when     
   otherwise stated in writing the copyright holders and/or other parties   
   provide the program "as is" without warranty of any kind, either         
   expressed or implied, including, but not limited to, the implied         
   warranties of merchantability and fitness for a particular purpose. The  
   entire risk as to the quality and performance of the program is with
   you.  should the program prove defective, you assume the cost of all     
   necessary servicing, repair or correction.                               
                                                                            
   In no event unless required by applicable law or agreed to in writing
   will any copyright holder, or any other party who may modify and/or      
   redistribute the program as permitted above, be liable to you for        
   damages, including any general, special, incidental or consequential     
   damages arising out of the use or inability to use the program           
   (including but not limited to loss of data or data being rendered        
   inaccurate or losses sustained by you or third parties or a failure of   
   the program to operate with any other programs), even if such holder or  
   other party has been advised of the possibility of such damages. 
********************************************************************************       
   Module      : $RCSfile: ifx_src_vdsl2_xtcstatus.c,v $
   Date        : $Date: 
   Description : 
*******************************************************************************/
#include	<ifx_emf.h>
#include	<signal.h>
#include	<unistd.h>
#include	<sys/types.h>
#include	<sys/wait.h>
#include	<sys/socket.h>
#include	<sys/ioctl.h>
#include	<arpa/inet.h>
#include	<netinet/in.h>
#include	<net/if.h>
#include	<net/if_arp.h>
#include	<ifx_common.h>
#include	"./ifx_amazon_cgi.h"

#include	"ifx_httpd_method.h"
//joelin #include       "ifx_common_defs.h"
//joelin #include       "ifx_web_common.h"
#include	<sys/reboot.h>
#include	"ifx_vdsl2_common.h"

/*********************************************************
* xtcstatus.asp
********************************************************/
static unsigned int prev_ChannelNumber;
static WebUSignSelect_S ChannelNumberList[] = {
	{0, "Channel0"},
	{1, "Channel1"}
};

void ifx_get_wizard_xtcstatus(httpd_t wp, char_t * path, char_t * query)
{
	char *pChannelNumber;
	pChannelNumber = ifx_httpdGetVar(wp, T("ChannelNumber"), T(""));

/* Get Row Values from ASP file  */
	if (pChannelNumber == 0) {
		ifx_httpdError(wp, 200, T("Setup Error"));
		return;
	}
	sscanf(pChannelNumber, "%u", &prev_ChannelNumber);

	websNextPage(wp);
}

void
ifx_get_vdsl2xtcstatusTblData(int eid, httpd_t wp, int argc, char_t ** argv)
{

	unsigned int nIndex;

	char sValue[10];

	int ret = -1;
	DSL_DataPathCounterTotalData_t DataPathCounterTotalData;
	char pCommand[MAX_WEB_CMD_NAME_LENGTH];
	char pParams[MAX_WEB_PARAMS_LENGTH];
	char *pResult;
	unsigned int LineNumber = 0;
	unsigned short int TmpLineNumber, TmpChannelNumber;
	unsigned int ChannelNumber;
	unsigned int FramesTransmitted;
	unsigned int FramesReceived;
	unsigned int OctetsTransmitted;
	unsigned int OctetsReceived;
	ChannelNumber = prev_ChannelNumber;

	/*
	 * User code from Map file is Inserted here 
	 */
	printf(" Calling DSL API of Status Table\n");

	/*
	 * DSL_DataPathCounterTotalGet 
	 */
	sprintf(pCommand, "dpctg");
	sprintf(pParams, "%hu %hu", LineNumber, ChannelNumber);

	printf(" %s %s \n", pCommand, pParams);
	if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS) {
		sscanf(pResult,
		       "nReturn=%d nLine=%hu nChannel=%hu UnitsTx=%u UnitsRx=%u OctetsTx=%u OctetsRx=%u UnitsCrc=%u UnitsAlign=%u\n\r",
		       &ret, &TmpLineNumber, &TmpChannelNumber,
		       &DataPathCounterTotalData.UnitsTx,
		       &DataPathCounterTotalData.UnitsRx,
		       &DataPathCounterTotalData.OctetsTx,
		       &DataPathCounterTotalData.OctetsRx,
		       &DataPathCounterTotalData.UnitsCrc,
		       &DataPathCounterTotalData.UnitsAlign);
	}
	FramesTransmitted = DataPathCounterTotalData.UnitsTx;
	FramesReceived = DataPathCounterTotalData.UnitsRx;
	OctetsTransmitted = DataPathCounterTotalData.OctetsTx;
	OctetsReceived = DataPathCounterTotalData.OctetsRx;
	WEB_SLEEP;

	ifx_httpdWrite(wp, T("<tr align=left>\n"));
	ifx_httpdWrite(wp, T("<td >"));
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"RetVal\" value=\"%d\">"),
		       ret);
	ifx_httpdWrite(wp, T("</td>"));
	ifx_httpdWrite(wp, T("</tr>\n"));

	if (ret != 0) {
		ifx_httpdWrite(wp, T("<tr align=left>\n"));
		ifx_httpdWrite(wp, T("<td class=\"text\">Status</td>"));
		ifx_httpdWrite(wp, T("<td class=\"text\" id=\"nError\"</td>"));
		ifx_httpdWrite(wp, T("</tr>\n"));

		/*
		 * Setting All Row Values to Default Values
		 */

		FramesTransmitted = 0;
		FramesReceived = 0;
		OctetsTransmitted = 0;
		OctetsReceived = 0;
	}

	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \"><font class=\"subtitle\">Channel Number</font></td>\n"));
	ifx_httpdWrite(wp, T("<td>\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<font face=\"Arial, Helvetica, sans-serif\" size=\"2\" color=\"#0000ff\">\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<select onchange=\"GetValues()\"name=\"ChannelNumber\" style=\"color: #000000\" size=\"1\">\n"));

	for (nIndex = 0;
	     nIndex < sizeof(ChannelNumberList) / sizeof(WebUSignSelect_S);
	     nIndex++) {
		/*
		 * set Selected option 
		 */
		if (ChannelNumberList[nIndex].value == ChannelNumber) {
			strcpy(sValue, "selected");
		} else {
			strcpy(sValue, " ");
		}

		ifx_httpdWrite(wp, T("<option value=\"%u\" %s >%s</option>\n"),
			       ChannelNumberList[nIndex].value, sValue,
			       ChannelNumberList[nIndex].str);

	}

	ifx_httpdWrite(wp, T("</select>\n"));
	ifx_httpdWrite(wp, T("</font>\n"));
	ifx_httpdWrite(wp, T("</td>\n"));

	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \" class=textCell><font class=\"subtitle\">Frames Transmitted</font></td>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td class=textCell><font class=\"subtitle\">%u </font></td>\n"),
		       FramesTransmitted);
	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \" class=textCell><font class=\"subtitle\">Frames Received</font></td>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td class=textCell><font class=\"subtitle\">%u </font></td>\n"),
		       FramesReceived);
	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \" class=textCell><font class=\"subtitle\">Octets Transmitted</font></td>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td class=textCell><font class=\"subtitle\">%u </font></td>\n"),
		       OctetsTransmitted);
	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \" class=textCell><font class=\"subtitle\">Octets Received</font></td>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td class=textCell><font class=\"subtitle\">%u </font></td>\n"),
		       OctetsReceived);
	ifx_httpdWrite(wp, T("</tr>\n"));
}
