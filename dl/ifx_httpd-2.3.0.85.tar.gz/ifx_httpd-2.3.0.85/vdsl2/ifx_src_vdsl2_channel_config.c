
/*******************************************************************************
       Copyright (c) 2002, Infineon Technologies.  All rights reserved.
 
                               No Warranty                                                 
   Because the program is licensed free of charge, there is no warranty for 
   the program, to the extent permitted by applicable law.  Except when     
   otherwise stated in writing the copyright holders and/or other parties   
   provide the program "as is" without warranty of any kind, either         
   expressed or implied, including, but not limited to, the implied         
   warranties of merchantability and fitness for a particular purpose. The  
   entire risk as to the quality and performance of the program is with
   you.  should the program prove defective, you assume the cost of all     
   necessary servicing, repair or correction.                               
                                                                            
   In no event unless required by applicable law or agreed to in writing
   will any copyright holder, or any other party who may modify and/or      
   redistribute the program as permitted above, be liable to you for        
   damages, including any general, special, incidental or consequential     
   damages arising out of the use or inability to use the program           
   (including but not limited to loss of data or data being rendered        
   inaccurate or losses sustained by you or third parties or a failure of   
   the program to operate with any other programs), even if such holder or  
   other party has been advised of the possibility of such damages. 
********************************************************************************       
   Module      : $RCSfile: ifx_src_vdsl2_channel_config.c,v $
   Date        : $Date: 
   Description : 
*******************************************************************************/
#include	<ifx_emf.h>
#include	<signal.h>
#include	<unistd.h>
#include	<sys/types.h>
#include	<sys/wait.h>
#include	<sys/socket.h>
#include	<sys/ioctl.h>
#include	<arpa/inet.h>
#include	<netinet/in.h>
#include	<net/if.h>
#include	<net/if_arp.h>
#include	<ifx_common.h>
#include	"./ifx_amazon_cgi.h"

#include	"ifx_httpd_method.h"
//joelin #include       "ifx_common_defs.h"
//joelin #include       "ifx_web_common.h"
#include	<sys/reboot.h>
#include	"ifx_vdsl2_common.h"

/*********************************************************
* channel_config.asp
********************************************************/
static unsigned int prev_ChannelNumber;
static WebUSignSelect_S ChannelNumberList[] = {
	{0, "Channel0"},
	{1, "Channel1"}
};
static unsigned int prev_Direction;
static WebUSignSelect_S DirectionList[] = {
	{0, "Upstream"},
	{1, "Downstream"}
};

void ifx_set_wizard_channel_config(httpd_t wp, char_t * path, char_t * query)
{
	int ret = -1;
	DSL_G997_ChannelConfig_t ChannelConfig;
	char pCommand[MAX_WEB_CMD_NAME_LENGTH];
	char pParams[MAX_WEB_PARAMS_LENGTH];
	char *pResult;
	int ret1;
	unsigned int LineNumber = 0;
	unsigned short int TmpLineNumber, TmpChannelNumber;
	unsigned int TmpDirection;
	char *pChannelNumber;
	unsigned int ChannelNumber;
	char *pDirection;
	unsigned int Direction;
	char *pMinDataRate;
	unsigned int MinDataRate;
	char *pMaxDataRate;
	unsigned int MaxDataRate;
	char *pMaxInterleaveDelay;
	unsigned int MaxInterleaveDelay;

/* Get Row Values from ASP file  */
	pChannelNumber = ifx_httpdGetVar(wp, T("ChannelNumber"), T(""));
	pDirection = ifx_httpdGetVar(wp, T("Direction"), T(""));
	pMinDataRate = ifx_httpdGetVar(wp, T("MinDataRate"), T(""));
	pMaxDataRate = ifx_httpdGetVar(wp, T("MaxDataRate"), T(""));
	pMaxInterleaveDelay =
	    ifx_httpdGetVar(wp, T("MaxInterleaveDelay"), T(""));
	if (pChannelNumber == 0 || pDirection == 0 || pMinDataRate == 0 ||
	    pMaxDataRate == 0 || pMaxInterleaveDelay == 0) {
		ifx_httpdError(wp, 200, T("Setup Error"));
		return;
	}
	sscanf(pChannelNumber, "%u", &ChannelNumber);
	sscanf(pDirection, "%u", &Direction);
	sscanf(pMinDataRate, "%u", &MinDataRate);
	sscanf(pMaxDataRate, "%u", &MaxDataRate);
	sscanf(pMaxInterleaveDelay, "%u", &MaxInterleaveDelay);

	/*
	 * User code from Map file is Inserted here 
	 */
	printf(" Calling DSL API \n");

	sprintf(pCommand, "g997ccg");
	sprintf(pParams, "%hu %hu %u", LineNumber, ChannelNumber, Direction);

	if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS) {
		sscanf(pResult,
		       "nReturn=%d nLine=%hu nChannel=%hu nDirection=%u MinDataRate=%u MaxDataRate=%u MaxIntDelay=%hu MinINP=%u MaxBER=%u\n\r",
		       &ret1, &TmpLineNumber, &TmpChannelNumber, &TmpDirection,
		       &ChannelConfig.MinDataRate, &ChannelConfig.MaxDataRate,
		       &ChannelConfig.MaxIntDelay,
		       (unsigned int *)&ChannelConfig.MinINP,
		       (unsigned int *)&ChannelConfig.MaxBER);
		ret = 0;	/*  First Time */
	}
	if (ret1 != 0) {
		ret = ret1;
	}
	ChannelConfig.MinDataRate = MinDataRate * 1000;
	ChannelConfig.MaxDataRate = MaxDataRate * 1000;
	ChannelConfig.MaxIntDelay = (unsigned short int)MaxInterleaveDelay;

	/*
	 * DSL_G997_ChannelConfigSet 
	 */
	sprintf(pCommand, "g997ccs");
	sprintf(pParams, "%hu %hu %u %u %u %hu %u %u", LineNumber,
		ChannelNumber, Direction, ChannelConfig.MinDataRate,
		ChannelConfig.MaxDataRate, ChannelConfig.MaxIntDelay,
		ChannelConfig.MinINP, ChannelConfig.MaxBER);

	if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS) {
		sscanf(pResult, "nReturn=%d ", &ret1);
	}

	if (ret1 != 0) {
		ret = ret1;
	}

	if (ret != 0) {
		ifx_httpdWrite(wp, T("<html>\n"));
		ifx_httpdWrite(wp, T("<head>\n"));
		ifx_httpdWrite(wp,
			       T
			       ("<script language=\"JavaScript\" src=\"../../script.js\"></script>\n"));
		ifx_httpdWrite(wp,
			       T
			       ("<title>Vdsl2 | Channel Config DSL Api Error</title>\n"));
		ifx_httpdWrite(wp, T("</head>\n"));
		ifx_httpdWrite(wp, T("<body bgColor=\"#e4e9f1\">\n"));
		ifx_httpdWrite(wp,
			       T
			       ("<table width=\"80%\" border=\"1\" cellspacing=\"0\" cellpadding=\"10\" height=\"30%\">\n"));
		ifx_httpdWrite(wp, T("<tr align=left>\n"));
		ifx_httpdWrite(wp, T("<td class=\"text\">Status</td>"));
		ifx_httpdWrite(wp, T("<td class=\"text\" id=\"nError\"</td>"));
		ifx_httpdWrite(wp, T("</tr>\n"));
		ifx_httpdWrite(wp, T("</table>\n"));
		ifx_httpdWrite(wp, T("<script language=\"JavaScript\">\n"));
		ifx_httpdWrite(wp, T("OnReceiveReturn(%d)\n"), ret);
		ifx_httpdWrite(wp, T("</script>\n"));
		ifx_httpdWrite(wp, T("</body>\n"));
		ifx_httpdWrite(wp, T("</html>\n"));
		return;
	}
	prev_ChannelNumber = ChannelNumber;
	prev_Direction = Direction;

	websNextPage(wp);
}

void ifx_get_wizard_channel_config(httpd_t wp, char_t * path, char_t * query)
{
	char *pChannelNumber;
	char *pDirection;
	pChannelNumber = ifx_httpdGetVar(wp, T("ChannelNumber"), T(""));
	pDirection = ifx_httpdGetVar(wp, T("Direction"), T(""));

/* Get Row Values from ASP file  */
	if (pChannelNumber == 0 || pDirection == 0) {
		ifx_httpdError(wp, 200, T("Setup Error"));
		return;
	}
	sscanf(pChannelNumber, "%u", &prev_ChannelNumber);
	sscanf(pDirection, "%u", &prev_Direction);

	websNextPage(wp);
}

void
ifx_get_vdsl2channel_configTblData(int eid,
				   httpd_t wp, int argc, char_t ** argv)
{

	unsigned int nIndex;

	char sValue[10];

	int ret = -1;
	DSL_G997_ChannelConfig_t ChannelConfig;
	char pCommand[MAX_WEB_CMD_NAME_LENGTH];
	char pParams[MAX_WEB_PARAMS_LENGTH];
	char *pResult;
	int ret1;
	unsigned int LineNumber = 0;
	unsigned short int TmpLineNumber, TmpChannelNumber;
	unsigned int TmpDirection;
	unsigned int ChannelNumber;
	unsigned int Direction;
	unsigned int MinDataRate;
	unsigned int MaxDataRate;
	unsigned int MaxInterleaveDelay;
	ChannelNumber = prev_ChannelNumber;
	Direction = prev_Direction;

	/*
	 * User code from Map file is Inserted here 
	 */
	ret1 = 0;
	printf(" Calling DSL API \n");
	/*
	 * DSL_G997_ChannelConfigGet 
	 */
	sprintf(pCommand, "g997ccg");
	sprintf(pParams, "%hu %hu %u", LineNumber, ChannelNumber, Direction);

	if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS) {
		sscanf(pResult,
		       "nReturn=%d nLine=%hu nChannel=%hu nDirection=%u MinDataRate=%u MaxDataRate=%u MaxIntDelay=%hu MinINP=%u MaxBER=%u\n\r",
		       &ret, &TmpLineNumber, &TmpChannelNumber, &TmpDirection,
		       &ChannelConfig.MinDataRate, &ChannelConfig.MaxDataRate,
		       &ChannelConfig.MaxIntDelay,
		       (unsigned int *)&ChannelConfig.MinINP,
		       (unsigned int *)&ChannelConfig.MaxBER);
	}
	MinDataRate = ChannelConfig.MinDataRate / 1000;
	MaxDataRate = ChannelConfig.MaxDataRate / 1000;
	MaxInterleaveDelay = (unsigned int)ChannelConfig.MaxIntDelay;

	ifx_httpdWrite(wp, T("<tr align=left>\n"));
	ifx_httpdWrite(wp, T("<td >"));
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"RetVal\" value=\"%d\">"),
		       ret);
	ifx_httpdWrite(wp, T("</td>"));
	ifx_httpdWrite(wp, T("</tr>\n"));

	if (ret != 0) {
		ifx_httpdWrite(wp, T("<tr align=left>\n"));
		ifx_httpdWrite(wp, T("<td class=\"text\">Status</td>"));
		ifx_httpdWrite(wp, T("<td class=\"text\" id=\"nError\"</td>"));
		ifx_httpdWrite(wp, T("</tr>\n"));

		/*
		 * Setting All Row Values to Default Values
		 */

		MinDataRate = 0;
		MaxDataRate = 0;
		MaxInterleaveDelay = 0;
	}

	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \"><font class=\"subtitle\">Channel Number</font></td>\n"));
	ifx_httpdWrite(wp, T("<td>\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<font face=\"Arial, Helvetica, sans-serif\" size=\"2\" color=\"#0000ff\">\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<select onchange=\"GetValues()\"name=\"ChannelNumber\" style=\"color: #000000\" size=\"1\">\n"));

	for (nIndex = 0;
	     nIndex < sizeof(ChannelNumberList) / sizeof(WebUSignSelect_S);
	     nIndex++) {
		/*
		 * set Selected option 
		 */
		if (ChannelNumberList[nIndex].value == ChannelNumber) {
			strcpy(sValue, "selected");
		} else {
			strcpy(sValue, " ");
		}

		ifx_httpdWrite(wp, T("<option value=\"%u\" %s >%s</option>\n"),
			       ChannelNumberList[nIndex].value, sValue,
			       ChannelNumberList[nIndex].str);

	}

	ifx_httpdWrite(wp, T("</select>\n"));
	ifx_httpdWrite(wp, T("</font>\n"));
	ifx_httpdWrite(wp, T("</td>\n"));

	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \"><font class=\"subtitle\">Direction</font></td>\n"));
	ifx_httpdWrite(wp, T("<td>\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<font face=\"Arial, Helvetica, sans-serif\" size=\"2\" color=\"#0000ff\">\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<select onchange=\"GetValues()\"name=\"Direction\" style=\"color: #000000\" size=\"1\">\n"));

	for (nIndex = 0;
	     nIndex < sizeof(DirectionList) / sizeof(WebUSignSelect_S);
	     nIndex++) {
		/*
		 * set Selected option 
		 */
		if (DirectionList[nIndex].value == Direction) {
			strcpy(sValue, "selected");
		} else {
			strcpy(sValue, " ");
		}

		ifx_httpdWrite(wp, T("<option value=\"%u\" %s >%s</option>\n"),
			       DirectionList[nIndex].value, sValue,
			       DirectionList[nIndex].str);

	}

	ifx_httpdWrite(wp, T("</select>\n"));
	ifx_httpdWrite(wp, T("</font>\n"));
	ifx_httpdWrite(wp, T("</td>\n"));

	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \"><font class=\"subtitle\">Min Data Rate</font></td>\n"));
	ifx_httpdWrite(wp, T("<td width=\"30%\">\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<input  type=\"text\" name=\"MinDataRate\" size=\"25\" maxlength=\"60\" value=\"%u\">\n"),
		       MinDataRate);
	ifx_httpdWrite(wp, T("</td>\n"));

	ifx_httpdWrite(wp, T("<td width=\"30%\">kbps</td>\n"));

	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \"><font class=\"subtitle\">Max Data Rate</font></td>\n"));
	ifx_httpdWrite(wp, T("<td width=\"30%\">\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<input  type=\"text\" name=\"MaxDataRate\" size=\"25\" maxlength=\"60\" value=\"%u\">\n"),
		       MaxDataRate);
	ifx_httpdWrite(wp, T("</td>\n"));

	ifx_httpdWrite(wp, T("<td width=\"30%\">kbps</td>\n"));

	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \"><font class=\"subtitle\">Max Interleave Delay</font></td>\n"));
	ifx_httpdWrite(wp, T("<td width=\"30%\">\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<input  type=\"text\" name=\"MaxInterleaveDelay\" size=\"25\" maxlength=\"60\" value=\"%u\">\n"),
		       MaxInterleaveDelay);
	ifx_httpdWrite(wp, T("</td>\n"));

	ifx_httpdWrite(wp, T("<td width=\"30%\">ms</td>\n"));

	ifx_httpdWrite(wp, T("</tr>\n"));
}
