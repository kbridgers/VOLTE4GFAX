
/*******************************************************************************
       Copyright (c) 2002, Infineon Technologies.  All rights reserved.
 
                               No Warranty                                                 
   Because the program is licensed free of charge, there is no warranty for 
   the program, to the extent permitted by applicable law.  Except when     
   otherwise stated in writing the copyright holders and/or other parties   
   provide the program "as is" without warranty of any kind, either         
   expressed or implied, including, but not limited to, the implied         
   warranties of merchantability and fitness for a particular purpose. The  
   entire risk as to the quality and performance of the program is with
   you.  should the program prove defective, you assume the cost of all     
   necessary servicing, repair or correction.                               
                                                                            
   In no event unless required by applicable law or agreed to in writing
   will any copyright holder, or any other party who may modify and/or      
   redistribute the program as permitted above, be liable to you for        
   damages, including any general, special, incidental or consequential     
   damages arising out of the use or inability to use the program           
   (including but not limited to loss of data or data being rendered        
   inaccurate or losses sustained by you or third parties or a failure of   
   the program to operate with any other programs), even if such holder or  
   other party has been advised of the possibility of such damages. 
********************************************************************************       
   Module      : $RCSfile: ifx_src_vdsl2_version_info.c,v $
   Date        : $Date: 
   Description : 
*******************************************************************************/
#include	<ifx_emf.h>
#include	<signal.h>
#include	<unistd.h>
#include	<sys/types.h>
#include	<sys/wait.h>
#include	<sys/socket.h>
#include	<sys/ioctl.h>
#include	<arpa/inet.h>
#include	<netinet/in.h>
#include	<net/if.h>
#include	<net/if_arp.h>
#include	<ifx_common.h>
#include	"./ifx_amazon_cgi.h"

#include	"ifx_httpd_method.h"
//joelin #include       "ifx_common_defs.h"
//joelin #include       "ifx_web_common.h"
#include	<sys/reboot.h>
#include	"ifx_vdsl2_common.h"

/*********************************************************
* version_info.asp
********************************************************/

void
ifx_get_vdsl2version_infoTblData(int eid, httpd_t wp, int argc, char_t ** argv)
{

	int ret = -1;
	DSL_VersionInformation_t VersionInformation;
	char pCommand[MAX_WEB_CMD_NAME_LENGTH];
	char pParams[MAX_WEB_PARAMS_LENGTH];
	char *pResult;
	char WebInterfaceVersion[MAX_STR_LEN];
	char DSLAPILibraryVersion[MAX_STR_LEN];
	char ChipSetFWVersion[MAX_STR_LEN];
	char ChipSetHWVersion[MAX_STR_LEN];
	char DSLDriverVersion[MAX_STR_LEN];

	/*
	 * User code from Map file is Inserted here 
	 */

	strcpy(WebInterfaceVersion, WEB_INTERFACE_VERSION);

	printf(" Calling DSL API of Status Table\n");
	/*
	 * DSL_VersionInformationGet 
	 */
	sprintf(pCommand, "vig");
	sprintf(pParams, " ");

	printf(" %s %s \n", pCommand, pParams);
	if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS) {
		sscanf(pResult,
		       "nReturn=%d DSL_APILibraryVersion=%s DSL_ChipSetFWVersion=%s DSL_ChipSetHWVersion=%s DSL_ChipSetType=%s DSL_DriverVersion=%s\n\r",
		       &ret, VersionInformation.DSL_APILibraryVersion,
		       VersionInformation.DSL_ChipSetFWVersion,
		       VersionInformation.DSL_ChipSetHWVersion,
		       VersionInformation.DSL_ChipSetType,
		       VersionInformation.DSL_DriverVersion);
	}

	strcpy(DSLAPILibraryVersion, VersionInformation.DSL_APILibraryVersion);
	strcpy(ChipSetFWVersion, VersionInformation.DSL_ChipSetFWVersion);
	strcpy(ChipSetHWVersion, VersionInformation.DSL_ChipSetHWVersion);
	strcpy(DSLDriverVersion, VersionInformation.DSL_DriverVersion);
	WEB_SLEEP;

	ifx_httpdWrite(wp, T("<tr align=left>\n"));
	ifx_httpdWrite(wp, T("<td >"));
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"RetVal\" value=\"%d\">"),
		       ret);
	ifx_httpdWrite(wp, T("</td>"));
	ifx_httpdWrite(wp, T("</tr>\n"));

	if (ret != 0) {
		ifx_httpdWrite(wp, T("<tr align=left>\n"));
		ifx_httpdWrite(wp, T("<td class=\"text\">Status</td>"));
		ifx_httpdWrite(wp, T("<td class=\"text\" id=\"nError\"</td>"));
		ifx_httpdWrite(wp, T("</tr>\n"));

		/*
		 * Setting All Row Values to Default Values
		 */

		sprintf(WebInterfaceVersion, " ");
		sprintf(DSLAPILibraryVersion, " ");
		sprintf(ChipSetFWVersion, " ");
		sprintf(ChipSetHWVersion, " ");
		sprintf(DSLDriverVersion, " ");
	}

	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \" class=textCell><font class=\"subtitle\">Web Interface Version</font></td>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td class=textCell><font class=\"subtitle\">%s </font></td>\n"),
		       WebInterfaceVersion);
	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \" class=textCell><font class=\"subtitle\">DSL API Library Version</font></td>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td class=textCell><font class=\"subtitle\">%s </font></td>\n"),
		       DSLAPILibraryVersion);
	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \" class=textCell><font class=\"subtitle\">Chip Set FW Version</font></td>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td class=textCell><font class=\"subtitle\">%s </font></td>\n"),
		       ChipSetFWVersion);
	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \" class=textCell><font class=\"subtitle\">Chip Set HW Version</font></td>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td class=textCell><font class=\"subtitle\">%s </font></td>\n"),
		       ChipSetHWVersion);
	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \" class=textCell><font class=\"subtitle\">DSL Driver Version</font></td>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td class=textCell><font class=\"subtitle\">%s </font></td>\n"),
		       DSLDriverVersion);
	ifx_httpdWrite(wp, T("</tr>\n"));
}
