#ifndef		__IFX_VDSL2_COMMON_H__
#define		__IFX_VDSL2_COMMON_H__

/*******************************************************************************
       Copyright (c) 2002, Infineon Technologies.  All rights reserved.
 
                               No Warranty                                                 
   Because the program is licensed free of charge, there is no warranty for 
   the program, to the extent permitted by applicable law.  Except when     
   otherwise stated in writing the copyright holders and/or other parties   
   provide the program "as is" without warranty of any kind, either         
   expressed or implied, including, but not limited to, the implied         
   warranties of merchantability and fitness for a particular purpose. The  
   entire risk as to the quality and performance of the program is with
   you.  should the program prove defective, you assume the cost of all     
   necessary servicing, repair or correction.                               
                                                                            
   In no event unless required by applicable law or agreed to in writing
   will any copyright holder, or any other party who may modify and/or      
   redistribute the program as permitted above, be liable to you for        
   damages, including any general, special, incidental or consequential     
   damages arising out of the use or inability to use the program           
   (including but not limited to loss of data or data being rendered        
   inaccurate or losses sustained by you or third parties or a failure of   
   the program to operate with any other programs), even if such holder or  
   other party has been advised of the possibility of such damages. 
********************************************************************************       
   Module      : $RCSfile: ifx_vdsl2_common.h,v $
   Date        : $Date: 
   Description : 
*******************************************************************************/

#include "lib_dsl_api.h"
#include "lib_dsl_api_g997.h"
#include "lib_dsl_api_pm.h"
/* 2006/10/12 joelin web interface v3.1 for FS6 released*/
//joelin #define WEB_INTERFACE_VERSION "0.3.0"
#define WEB_INTERFACE_VERSION "0.3.1"

#define MAX_WEB_OUT_BUF_SIZE 15000
#define MAX_WEB_CMD_NAME_LENGTH 20
#define MAX_WEB_PARAMS_LENGTH (MAX_WEB_OUT_BUF_SIZE - MAX_WEB_CMD_NAME_LENGTH - 1)

#define MAX_STR_LEN MAX_INFO_STRING_LEN

#define UPSTREAM 0
#define DOWNSTREAM 1

#define WEB_SUCCESS 0
#define WEB_FAIL -1

#define MIN_15 0
#define ONE_DAY 1

#define ACTIVATE 0
#define DEACTIVATE 1

#define WEB_SLEEP

/*usleep(1000) */

/* Web ASP Page select structure */
typedef struct {
	/* Web ASP selected option value index */
	unsigned int value;
	/* Web ASP selected option value index content */
	char *str;
} WebUSignSelect_S;

/* Web ASP Page select structure */
typedef struct {
	/* Web ASP selected option value index */
	int value;
	/* Web ASP selected option value index content */
	char *str;
} WebSelect_S;

int DSL_Cli_Access(char *pCommand, char *pParams, char **ppResult);

void ifx_RemoveNewLines(char *pParse);

#endif
