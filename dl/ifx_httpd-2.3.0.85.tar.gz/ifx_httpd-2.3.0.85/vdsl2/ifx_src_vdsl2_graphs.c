
/*******************************************************************************
       Copyright (c) 2002, Infineon Technologies.  All rights reserved.
 
                               No Warranty                                                 
   Because the program is licensed free of charge, there is no warranty for 
   the program, to the extent permitted by applicable law.  Except when     
   otherwise stated in writing the copyright holders and/or other parties   
   provide the program "as is" without warranty of any kind, either         
   expressed or implied, including, but not limited to, the implied         
   warranties of merchantability and fitness for a particular purpose. The  
   entire risk as to the quality and performance of the program is with
   you.  should the program prove defective, you assume the cost of all     
   necessary servicing, repair or correction.                               
                                                                            
   In no event unless required by applicable law or agreed to in writing
   will any copyright holder, or any other party who may modify and/or      
   redistribute the program as permitted above, be liable to you for        
   damages, including any general, special, incidental or consequential     
   damages arising out of the use or inability to use the program           
   (including but not limited to loss of data or data being rendered        
   inaccurate or losses sustained by you or third parties or a failure of   
   the program to operate with any other programs), even if such holder or  
   other party has been advised of the possibility of such damages. 
********************************************************************************       
   Module      : $RCSfile: ifx_src_vdsl2_graphs.c,v $
   Date        : $Date: 
   Description : 
*******************************************************************************/

#include <ifx_emf.h>
#include <signal.h>
#include	<unistd.h>
#include	<sys/types.h>
#include	<sys/wait.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <net/if.h>
#include <net/if_arp.h>
#include	<ifx_common.h>
#include	"./ifx_amazon_cgi.h"

#include "ifx_httpd_method.h"
//joelin #include "ifx_common_defs.h"
//joelin #include       "ifx_web_common.h"
#include	<sys/reboot.h>
#include	"ifx_vdsl2_common.h"
#include	"ifx_src_vdsl2_graphs.h"

#define SNR  1
#define BITS 2

#define SHORT_FORM 1
#define DEBUG_MSG 0
static void ifx_get_vdsl2_graphs_write_fail_to_web(httpd_t wp, int ret);

static void ifx_get_vdsl2_graphs_SnrBits_TblData(httpd_t wp,
						 unsigned char Type);
static unsigned int ifx_get_vdsl2_graphs_GetSnrBitsData(unsigned char Type,
							unsigned int LineNumber,
							unsigned int Direction,
							unsigned int *pLength,
							unsigned char
							**ppValues,
							char **ppResult);
#if (SIMULATE_DATA == 1)
static char *SimulateData(unsigned int Direction, unsigned int MaxVal,
			  unsigned char Type);

#endif

/*********************************************************
* Graphs.asp
********************************************************/
void ifx_get_wizard_graphs(httpd_t wp, char_t * path, char_t * query)
{
	websNextPage(wp);	//joelin
}

void ifx_get_vdsl2_graphs_snr_TblData(int eid, httpd_t wp, int argc,
				      char_t ** argv)
{
	ifx_get_vdsl2_graphs_SnrBits_TblData(wp, SNR);
}

void ifx_get_vdsl2_graphs_bits_TblData(int eid, httpd_t wp, int argc,
				       char_t ** argv)
{
	ifx_get_vdsl2_graphs_SnrBits_TblData(wp, BITS);
}

static void ifx_get_vdsl2_graphs_SnrBits_TblData(httpd_t wp, unsigned char Type)
{
	int ret = -1, ret1 = -1, ret2 = -1;
	char *pResult;
	unsigned char *pValues;
	unsigned int UpLength = 0;
	unsigned int DownLength = 0;
	char *FunctionName;
	if (Type == SNR) {
		FunctionName = "doSnrBarGraph";
	} else {
		FunctionName = "doBitsBarGraph";
	}

	do {
		ret1 =
		    ifx_get_vdsl2_graphs_GetSnrBitsData(Type, 0, UPSTREAM,
							&UpLength, &pValues,
							&pResult);
		if (ret1 == WEB_SUCCESS) {
			ifx_httpdWrite(wp, T("%s( "), FunctionName);
			ifx_httpdWrite(wp, T("%d,\"%s\","), UpLength,
				       (pValues));
		} else {
			ret = ret1;
			UpLength = 0;
		}

		ret2 =
		    ifx_get_vdsl2_graphs_GetSnrBitsData(Type, 0, DOWNSTREAM,
							&DownLength, &pValues,
							&pResult);
		if ((ret2 == WEB_SUCCESS) && (ret1 == WEB_SUCCESS)) {
			ifx_httpdWrite(wp, T("%d,\"%s\""), DownLength,
				       (pValues));
		} else if ((ret2 == WEB_SUCCESS) && (ret1 != WEB_SUCCESS)) {
			ifx_httpdWrite(wp, T("%s( "), FunctionName);
			ifx_httpdWrite(wp, T("0,\"\","));
			ifx_httpdWrite(wp, T("%d,\"%s\""), DownLength,
				       (pValues));
		} else if ((ret2 != WEB_SUCCESS) && (ret1 == WEB_SUCCESS)) {
			ret = ret2;
			ifx_httpdWrite(wp, T("0,\"\""));
		} else {
			ret = ret2;
			break;
		}
		ret = 0;
		ifx_httpdWrite(wp, T(");\n"));
	} while (0);

	if (ret != WEB_SUCCESS) {
		ifx_get_vdsl2_graphs_write_fail_to_web(wp, ret);
	}
}

static void ifx_get_vdsl2_graphs_write_fail_to_web(httpd_t wp, int ret)
{
	ifx_httpdWrite(wp, T("</script>\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<table width=\"80%\" border=\"1\" cellspacing=\"0\" cellpadding=\"10\" height=\"30%\">\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));
	ifx_httpdWrite(wp, T("<td class=\"text\">Status</td>"));
	ifx_httpdWrite(wp, T("<td class=\"text\" id=\"nError\"</td>"));
	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("</table>\n"));
	ifx_httpdWrite(wp, T("<script language=\"JavaScript\">\n"));
	ifx_httpdWrite(wp, T("document.tF0.RetVal.value = %d ;\n"), ret);
	ifx_httpdWrite(wp, T("</script>\n"));
	ifx_httpdWrite(wp, T("<script language=\"JavaScript\">\n"));

}

static unsigned int ifx_get_vdsl2_graphs_GetSnrBitsData(unsigned char Type,
							unsigned int LineNumber,
							unsigned int Direction,
							unsigned int *pLength,
							unsigned char
							**ppValues,
							char **ppResult)
{
	int ret = -1;
	char pCommand[MAX_WEB_CMD_NAME_LENGTH];
	char pParams[MAX_WEB_PARAMS_LENGTH];
	char *pResult, *pParse, pTmpResult[100];
#if (SIMULATE_DATA == 1)
	unsigned int MaxLength = 0;
#endif

	/* G997_SNRNSCGet */
	if (Type == SNR) {
		sprintf(pCommand, "g997snrnscsg");	//joelin
	} else {
		sprintf(pCommand, "g997banscsg");	//joelin
	}
	sprintf(pParams, "%u %u ", LineNumber, Direction);
#if (SIMULATE_DATA == 0)
	if ((ret = DSL_Cli_Access(pCommand, pParams, &pResult)) == WEB_SUCCESS) {
		pParse = pResult;
#endif
#if (SIMULATE_DATA == 1)
		ret = 0;
		if (Type == SNR) {
			MaxLength = 255;
		} else {
			MaxLength = 15;
		}
		pParse = SimulateData(Direction, MaxLength, Type);
#endif

		printf(" pParseLength =  %d \n", strlen(pParse));

#if (DEBUG_MSG == 1)
		printf(" pParse = \n %s ", pParse);
		printf(" \n");
#endif

		*ppResult = pParse;
		sscanf(pParse,
		       "nReturn=%d nLine=%d nDirection=%d nNumData=%u\n\r",
		       &ret, &LineNumber, &Direction, (short int *)pLength);
		sprintf(pTmpResult,
			"nReturn=%d nLine=%d nDirection=%d nNumData=%u\n\r",
			ret, LineNumber, Direction, *pLength);
#if (DEBUG_MSG == 1)
		printf(" %s ", pTmpResult);
#endif
		pParse += strlen(pTmpResult);
		/* skip additional part of output */
		if (Type == SNR)
			pParse += strlen("nFormat=snr(hex) nData=\"\n\r");
		else
			pParse += strlen("nFormat=bits(hex) nData=\"\n\r");
		if (ret == 0) {
			ifx_RemoveNewLines(pParse);
			*ppValues = pParse;
			pParse[*pLength * 3] = '\0';
		}
#if (SIMULATE_DATA == 0)
	}
#endif
	return ret;
}

#if (SIMULATE_DATA == 1)

static char *SimulateData(unsigned int Direction, unsigned int MaxVal,
			  unsigned char Type)
{
	int ret = 0;
	unsigned int i = 0, j = 0, nNumData = 4096;
	unsigned char Num, *pParse, *pTemp;
	printf(" Simulate Data Start \n");
	if (Direction == UPSTREAM) {
		sprintf(ResultBufUpStream,
			"nReturn=%d nNumData=%u\n\r", ret, nNumData);
#if 0
		if (Type == SNR) {
			sprintf((ResultBufUpStream + strlen(ResultBufUpStream)),
				"nFormat=(tone(dec),snr(hex)) nData=\"");
		} else {
			sprintf((ResultBufUpStream + strlen(ResultBufUpStream)),
				"nFormat=(tone(dec),bits(hex)) nData=\"");
		}
#endif
		pParse = (ResultBufUpStream + strlen(ResultBufUpStream));
		pTemp = pParse;
		for (i = 0; i < nNumData / 2; i++) {
			/*if (i%10 == 0)
			   {
			   sprintf( (ResultBufUpStream + strlen(ResultBufUpStream)),"\n\r");
			   }
			   j = i % MaxVal;  
			   #if (SHORT_FORM == 0)
			   sprintf( (ResultBufUpStream + strlen(ResultBufUpStream)),
			   "(%04u,%02x) ", i,j );
			   #endif
			   #if (SHORT_FORM == 1)
			   sprintf( (ResultBufUpStream + strlen(ResultBufUpStream)),
			   "%03d ", j );
			   #endif
			 */
			j = 0;	/*i % MaxVal;  */
			Num = ((j & 0xf0) >> 4);
			pParse[0] = (Num > 9) ? (55 + Num) : (48 + Num);
			Num = (j & 0x0f);
			pParse[1] = (Num > 9) ? (55 + Num) : (48 + Num);
			pParse[2] = ' ';
			pParse += 3;
		}
		for (; i < nNumData; i++) {
			/* 
			   if (i%10 == 0)
			   {
			   sprintf( (ResultBufUpStream + strlen(ResultBufUpStream)),"\n\r");
			   }
			   #if (SHORT_FORM == 0)
			   sprintf( (ResultBufUpStream + strlen(ResultBufUpStream)),
			   "(%04u,%02x) ", i,0 );
			   #endif
			   #if (SHORT_FORM == 1)
			   sprintf( (ResultBufUpStream + strlen(ResultBufUpStream)),
			   "%03d ", 0 );
			   #endif
			 */
			j = 0;
			Num = ((j & 0xf0) >> 4);
			pParse[0] = (Num > 9) ? (55 + Num) : (48 + Num);
			Num = (j & 0x0f);
			pParse[1] = (Num > 9) ? (55 + Num) : (48 + Num);
			pParse[2] = ' ';
			pParse += 3;

		}
		pParse[0] = '\0';
		printf(" Simulate Data End \n");

		return ResultBufUpStream;
	} else {
		sprintf(ResultBufDownStream,
			"nReturn=%d nNumData=%u\n\r", ret, nNumData);
#if 0
		if (Type == SNR) {
			sprintf((ResultBufDownStream +
				 strlen(ResultBufDownStream)),
				"nFormat=(tone(dec),snr(hex)) nData=\"");
		} else {
			sprintf((ResultBufDownStream +
				 strlen(ResultBufDownStream)),
				"nFormat=(tone(dec),bits(hex)) nData=\"");
		}
#endif
		pParse = (ResultBufDownStream + strlen(ResultBufDownStream));
		for (i = 0; i < (nNumData / 2 - nNumData / 4); i++) {
			/*
			   if (i%10 == 0)
			   {
			   sprintf( (ResultBufDownStream + strlen(ResultBufDownStream)),"\n\r");
			   }
			   #if (SHORT_FORM == 0)
			   sprintf( (ResultBufDownStream + strlen(ResultBufDownStream)),
			   "(%04u,%02x) ", i,0 );
			   #endif
			   #if (SHORT_FORM == 1)
			   sprintf( (ResultBufDownStream + strlen(ResultBufDownStream)),
			   "%03d ", 0 );
			   #endif
			 */
			j = 0;
			Num = ((j & 0xf0) >> 4);
			pParse[0] = (Num > 9) ? (55 + Num) : (48 + Num);
			Num = (j & 0x0f);
			pParse[1] = (Num > 9) ? (55 + Num) : (48 + Num);
			pParse[2] = ' ';
			pParse += 3;
		}
		for (; i < nNumData; i++) {
			/*
			   if (i%10 == 0)
			   {
			   sprintf( (ResultBufDownStream + strlen(ResultBufDownStream)),"\n\r");
			   }
			   j = i % MaxVal;  
			   #if (SHORT_FORM == 0)
			   sprintf( (ResultBufDownStream + strlen(ResultBufDownStream)),
			   "(%04u,%02x) ", i,j );
			   #endif
			   #if (SHORT_FORM == 1)
			   sprintf( (ResultBufDownStream + strlen(ResultBufDownStream)),
			   "%03d ", j );
			   #endif
			 */
			j = 0;	/*i % MaxVal;  */
			Num = ((j & 0xf0) >> 4);
			pParse[0] = (Num > 9) ? (55 + Num) : (48 + Num);
			Num = (j & 0x0f);
			pParse[1] = (Num > 9) ? (55 + Num) : (48 + Num);
			pParse[2] = ' ';
			pParse += 3;

		}
		pParse[0] = '\0';
		printf(" Simulate Data End \n");
		return ResultBufDownStream;
	}
}

#endif
