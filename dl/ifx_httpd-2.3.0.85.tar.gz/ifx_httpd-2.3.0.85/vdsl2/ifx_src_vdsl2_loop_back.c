
/*******************************************************************************
       Copyright (c) 2002, Infineon Technologies.  All rights reserved.
 
                               No Warranty                                                 
   Because the program is licensed free of charge, there is no warranty for 
   the program, to the extent permitted by applicable law.  Except when     
   otherwise stated in writing the copyright holders and/or other parties   
   provide the program "as is" without warranty of any kind, either         
   expressed or implied, including, but not limited to, the implied         
   warranties of merchantability and fitness for a particular purpose. The  
   entire risk as to the quality and performance of the program is with
   you.  should the program prove defective, you assume the cost of all     
   necessary servicing, repair or correction.                               
                                                                            
   In no event unless required by applicable law or agreed to in writing
   will any copyright holder, or any other party who may modify and/or      
   redistribute the program as permitted above, be liable to you for        
   damages, including any general, special, incidental or consequential     
   damages arising out of the use or inability to use the program           
   (including but not limited to loss of data or data being rendered        
   inaccurate or losses sustained by you or third parties or a failure of   
   the program to operate with any other programs), even if such holder or  
   other party has been advised of the possibility of such damages. 
********************************************************************************       
   Module      : $RCSfile: ifx_src_vdsl2_loop_back.c,v $
   Date        : $Date: 
   Description : 
*******************************************************************************/
#include	<ifx_emf.h>
#include	<signal.h>
#include	<unistd.h>
#include	<sys/types.h>
#include	<sys/wait.h>
#include	<sys/socket.h>
#include	<sys/ioctl.h>
#include	<arpa/inet.h>
#include	<netinet/in.h>
#include	<net/if.h>
#include	<net/if_arp.h>
#include	<ifx_common.h>
#include	"./ifx_amazon_cgi.h"

#include	"ifx_httpd_method.h"
//joelin #include       "ifx_common_defs.h"
//joelin #include       "ifx_web_common.h"
#include	<sys/reboot.h>
#include	"ifx_vdsl2_common.h"

/*********************************************************
* loop_back.asp
********************************************************/
static unsigned int prev_ChannelNumber;
static WebUSignSelect_S ChannelNumberList[] = {
	{0, "Channel0"},
	{1, "Channel1"}
};
static unsigned int prev_Loop;
static WebUSignSelect_S LoopList[] = {
	{0, "System - System Loop"},
	{1, "Line Side Loop"}
};
static WebUSignSelect_S StateList[] = {
	{0, "Activate"},
	{1, "Deactivate"}
};

void ifx_set_wizard_loop_back(httpd_t wp, char_t * path, char_t * query)
{
	int ret = -1;
	char pCommand[MAX_WEB_CMD_NAME_LENGTH];
	char pParams[MAX_WEB_PARAMS_LENGTH];
	char *pResult;
	int LineNumber = 0;
	DSL_PayloadLoopConfig_t PayloadLoopConfig;
	char *pChannelNumber;
	unsigned int ChannelNumber;
	char *pLoop;
	unsigned int Loop;
	char *pState;
	unsigned int State;

/* Get Row Values from ASP file  */
	pChannelNumber = ifx_httpdGetVar(wp, T("ChannelNumber"), T(""));
	pLoop = ifx_httpdGetVar(wp, T("Loop"), T(""));
	pState = ifx_httpdGetVar(wp, T("State"), T(""));
	if (pChannelNumber == 0 || pLoop == 0 || pState == 0) {
		ifx_httpdError(wp, 200, T("Setup Error"));
		return;
	}
	sscanf(pChannelNumber, "%u", &ChannelNumber);
	sscanf(pLoop, "%u", &Loop);
	sscanf(pState, "%u", &State);

	/*
	 * User code from Map file is Inserted here 
	 */
	printf(" Calling DSL API \n");

	if (State == ACTIVATE) {
		/*
		 * DSL_PayloadLoopActivate 
		 */
		PayloadLoopConfig.nLoop = Loop;
		sprintf(pCommand, "pla");
		sprintf(pParams, "%hu %hu %u ", LineNumber, ChannelNumber,
			PayloadLoopConfig.nLoop);

		printf(" %s %s \n", pCommand, pParams);
		if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS) {
			sscanf(pResult, "nReturn=%d ", &ret);
		}
	} else if (State == DEACTIVATE) {

		/*
		 * DSL_PayloadLoopDeactivate 
		 */
		PayloadLoopConfig.nLoop = DSL_LOOP_SYSTEMIF;
		sprintf(pCommand, "pld");
		sprintf(pParams, "%hu %hu %u ", LineNumber, ChannelNumber,
			PayloadLoopConfig.nLoop);

		printf(" %s %s \n", pCommand, pParams);
		if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS) {
			sscanf(pResult, "nReturn=%d ", &ret);
		}
	}

	if (ret != 0) {
		ifx_httpdWrite(wp, T("<html>\n"));
		ifx_httpdWrite(wp, T("<head>\n"));
		ifx_httpdWrite(wp,
			       T
			       ("<script language=\"JavaScript\" src=\"../../script.js\"></script>\n"));
		ifx_httpdWrite(wp,
			       T
			       ("<title>Vdsl2 | Loop Back DSL Api Error</title>\n"));
		ifx_httpdWrite(wp, T("</head>\n"));
		ifx_httpdWrite(wp, T("<body bgColor=\"#e4e9f1\">\n"));
		ifx_httpdWrite(wp,
			       T
			       ("<table width=\"80%\" border=\"1\" cellspacing=\"0\" cellpadding=\"10\" height=\"30%\">\n"));
		ifx_httpdWrite(wp, T("<tr align=left>\n"));
		ifx_httpdWrite(wp, T("<td class=\"text\">Status</td>"));
		ifx_httpdWrite(wp, T("<td class=\"text\" id=\"nError\"</td>"));
		ifx_httpdWrite(wp, T("</tr>\n"));
		ifx_httpdWrite(wp, T("</table>\n"));
		ifx_httpdWrite(wp, T("<script language=\"JavaScript\">\n"));
		ifx_httpdWrite(wp, T("OnReceiveReturn(%d)\n"), ret);
		ifx_httpdWrite(wp, T("</script>\n"));
		ifx_httpdWrite(wp, T("</body>\n"));
		ifx_httpdWrite(wp, T("</html>\n"));
		return;
	}
	prev_ChannelNumber = ChannelNumber;
	prev_Loop = Loop;

	websNextPage(wp);
}

void ifx_get_wizard_loop_back(httpd_t wp, char_t * path, char_t * query)
{
	char *pChannelNumber;
	char *pLoop;
	pChannelNumber = ifx_httpdGetVar(wp, T("ChannelNumber"), T(""));
	pLoop = ifx_httpdGetVar(wp, T("Loop"), T(""));

/* Get Row Values from ASP file  */
	if (pChannelNumber == 0 || pLoop == 0) {
		ifx_httpdError(wp, 200, T("Setup Error"));
		return;
	}
	sscanf(pChannelNumber, "%u", &prev_ChannelNumber);
	sscanf(pLoop, "%u", &prev_Loop);

	websNextPage(wp);
}

void
ifx_get_vdsl2loop_backTblData(int eid, httpd_t wp, int argc, char_t ** argv)
{

	unsigned int nIndex;

	char sValue[10];

	int ret = -1;
	char pCommand[MAX_WEB_CMD_NAME_LENGTH];
	char pParams[MAX_WEB_PARAMS_LENGTH];
	char *pResult;
	int LineNumber = 0;
	int LoopVal = 0;
	unsigned short int TmpLineNumber, TmpChannelNumber;
	unsigned int ChannelNumber;
	unsigned int Loop;
	unsigned int State;
	ChannelNumber = prev_ChannelNumber;
	Loop = prev_Loop;

	/*
	 * User code from Map file is Inserted here 
	 */
	sprintf(pCommand, "plsg");
	sprintf(pParams, "%hu %hu", LineNumber, ChannelNumber);

	if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS) {
		sscanf(pResult,
		       "nReturn=%d nLine=%hu nChannel=%hu pData=%hu\n\r", &ret,
		       (unsigned short *)&TmpLineNumber,
		       (unsigned short *)&TmpChannelNumber,
		       (unsigned short *)&LoopVal);
	}
	if (LoopVal & (1 << Loop)) {
		State = ACTIVATE;
	} else {
		State = DEACTIVATE;
	}

	ifx_httpdWrite(wp, T("<tr align=left>\n"));
	ifx_httpdWrite(wp, T("<td >"));
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"RetVal\" value=\"%d\">"),
		       ret);
	ifx_httpdWrite(wp, T("</td>"));
	ifx_httpdWrite(wp, T("</tr>\n"));

	if (ret != 0) {
		ifx_httpdWrite(wp, T("<tr align=left>\n"));
		ifx_httpdWrite(wp, T("<td class=\"text\">Status</td>"));
		ifx_httpdWrite(wp, T("<td class=\"text\" id=\"nError\"</td>"));
		ifx_httpdWrite(wp, T("</tr>\n"));

		/*
		 * Setting All Row Values to Default Values
		 */

		State = 1;
	}

	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \"><font class=\"subtitle\">Channel Number</font></td>\n"));
	ifx_httpdWrite(wp, T("<td>\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<font face=\"Arial, Helvetica, sans-serif\" size=\"2\" color=\"#0000ff\">\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<select onchange=\"GetValues()\"name=\"ChannelNumber\" style=\"color: #000000\" size=\"1\">\n"));

	for (nIndex = 0;
	     nIndex < sizeof(ChannelNumberList) / sizeof(WebUSignSelect_S);
	     nIndex++) {
		/*
		 * set Selected option 
		 */
		if (ChannelNumberList[nIndex].value == ChannelNumber) {
			strcpy(sValue, "selected");
		} else {
			strcpy(sValue, " ");
		}

		ifx_httpdWrite(wp, T("<option value=\"%u\" %s >%s</option>\n"),
			       ChannelNumberList[nIndex].value, sValue,
			       ChannelNumberList[nIndex].str);

	}

	ifx_httpdWrite(wp, T("</select>\n"));
	ifx_httpdWrite(wp, T("</font>\n"));
	ifx_httpdWrite(wp, T("</td>\n"));

	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \"><font class=\"subtitle\">Loop</font></td>\n"));
	ifx_httpdWrite(wp, T("<td>\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<font face=\"Arial, Helvetica, sans-serif\" size=\"2\" color=\"#0000ff\">\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<select onchange=\"GetValues()\"name=\"Loop\" style=\"color: #000000\" size=\"1\">\n"));

	for (nIndex = 0; nIndex < sizeof(LoopList) / sizeof(WebUSignSelect_S);
	     nIndex++) {
		/*
		 * set Selected option 
		 */
		if (LoopList[nIndex].value == Loop) {
			strcpy(sValue, "selected");
		} else {
			strcpy(sValue, " ");
		}

		ifx_httpdWrite(wp, T("<option value=\"%u\" %s >%s</option>\n"),
			       LoopList[nIndex].value, sValue,
			       LoopList[nIndex].str);

	}

	ifx_httpdWrite(wp, T("</select>\n"));
	ifx_httpdWrite(wp, T("</font>\n"));
	ifx_httpdWrite(wp, T("</td>\n"));

	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \"><font class=\"subtitle\">State</font></td>\n"));
	ifx_httpdWrite(wp, T("<td>\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<font face=\"Arial, Helvetica, sans-serif\" size=\"2\" color=\"#0000ff\">\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<select name=\"State\" style=\"color: #000000\" size=\"1\">\n"));

	for (nIndex = 0; nIndex < sizeof(StateList) / sizeof(WebUSignSelect_S);
	     nIndex++) {
		/*
		 * set Selected option 
		 */
		if (StateList[nIndex].value == State) {
			strcpy(sValue, "selected");
		} else {
			strcpy(sValue, " ");
		}

		ifx_httpdWrite(wp, T("<option value=\"%u\" %s >%s</option>\n"),
			       StateList[nIndex].value, sValue,
			       StateList[nIndex].str);

	}

	ifx_httpdWrite(wp, T("</select>\n"));
	ifx_httpdWrite(wp, T("</font>\n"));
	ifx_httpdWrite(wp, T("</td>\n"));

	ifx_httpdWrite(wp, T("</tr>\n"));
}
