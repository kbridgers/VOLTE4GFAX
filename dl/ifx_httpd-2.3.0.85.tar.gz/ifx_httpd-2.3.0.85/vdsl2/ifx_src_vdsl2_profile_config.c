
/*******************************************************************************
       Copyright (c) 2002, Infineon Technologies.  All rights reserved.
 
                               No Warranty                                                 
   Because the program is licensed free of charge, there is no warranty for 
   the program, to the extent permitted by applicable law.  Except when     
   otherwise stated in writing the copyright holders and/or other parties   
   provide the program "as is" without warranty of any kind, either         
   expressed or implied, including, but not limited to, the implied         
   warranties of merchantability and fitness for a particular purpose. The  
   entire risk as to the quality and performance of the program is with
   you.  should the program prove defective, you assume the cost of all     
   necessary servicing, repair or correction.                               
                                                                            
   In no event unless required by applicable law or agreed to in writing
   will any copyright holder, or any other party who may modify and/or      
   redistribute the program as permitted above, be liable to you for        
   damages, including any general, special, incidental or consequential     
   damages arising out of the use or inability to use the program           
   (including but not limited to loss of data or data being rendered        
   inaccurate or losses sustained by you or third parties or a failure of   
   the program to operate with any other programs), even if such holder or  
   other party has been advised of the possibility of such damages. 
********************************************************************************       
   Module      : $RCSfile: ifx_src_vdsl2_profile_config.c,v $
   Date        : $Date: 
   Description : 
*******************************************************************************/
/* 2006/10/12 joelin web interface v3.1 for FS6 released*/
#include	<ifx_emf.h>
#include	<signal.h>
#include	<unistd.h>
#include	<sys/types.h>
#include	<sys/wait.h>
#include	<sys/socket.h>
#include	<sys/ioctl.h>
#include	<arpa/inet.h>
#include	<netinet/in.h>
#include	<net/if.h>
#include	<net/if_arp.h>
#include	<ifx_common.h>
#include	"./ifx_amazon_cgi.h"
#include	"ifx_httpd_method.h"
//joelin #include       "ifx_common_defs.h"
//joelin #include       "ifx_web_common.h"
#include	<sys/reboot.h>
#include	"ifx_vdsl2_common.h"

/*********************************************************
* profile_config.asp
********************************************************/
static WebUSignSelect_S ProfileList[] = {
	{0, "Vdsl2 Profile8a"},
	{1, "Vdsl2 Profile8b"},
	{2, "Vdsl2 Profile8c"},
	{3, "Vdsl2 Profile8d"},
	{4, "Vdsl2 Profile12a"},
	{5, "Vdsl2 Profile12b"},
	{6, "Vdsl2 Profile17a"},
	{7, "Vdsl2 Profile30a"},
	{8, "Vdsl2 Profile17b"}
};
static WebUSignSelect_S BandPlanList[] = {
	{0, "Annex A M1_EU32"},
	{1, "Annex A M9_EU64"},
	{8, "Annex B 997-M2x-A (B05)"},
	{9, "Annex B 997-M2x-M (B06)"},
	{10, "Annex B 998-M1x-A (B07)"},
	{11, "Annex B 998-M1x-B (B08)"},
	{12, "Annex B 998-M1x-NUS0 (B09)"},
	{13, "Annex B 998-M2x-A (B10)"},
	{14, "Annex B 998-M2x-M (B11)"},
	{16, "Annex B 998-M2x-B (B12)"},
	{18, "Annex B 998-M2x-NUS0 (B13)"},
	{19, "Annex B (B13_17)"},
	{20, "Annex C"},
	{21, "Annex C_8K"},
	{22, "Annex B 997-M2x-NUS0"},
	{23, "Annex C 1M1"},
	{24, "Annex C_8K 1M1"},
	{25, "Annex B 998E17-M2x-A"},
	{26, "Annex B 998E17-M2x-NUS0"}
};
static WebUSignSelect_S FilterList[] = {
	{0, "Additional Filter Off"},
	{1, "Additional ISDN Filter"},
	{2, "Additional POTS Filter"},
	{3, "Additional POTS Filter (ADSL)"}
};

void ifx_set_wizard_profile_config(httpd_t wp, char_t * path, char_t * query)
{
	int ret = -1;
	char pCommand[MAX_WEB_CMD_NAME_LENGTH];

	char pParams[MAX_WEB_PARAMS_LENGTH];

	char *pResult;

	unsigned int LineNumber = 0;

	DSL_DeviceLowLevelLineConfig_t data;

	char *pProfile;
	unsigned int Profile;
	char *pBandPlan;
	unsigned int BandPlan;
	char *pFilter;
	unsigned int Filter;

/* Get Row Values from ASP file  */
	pProfile = ifx_httpdGetVar(wp, T("Profile"), T(""));
	pBandPlan = ifx_httpdGetVar(wp, T("BandPlan"), T(""));
	pFilter = ifx_httpdGetVar(wp, T("Filter"), T(""));
	if (pProfile == 0 || pBandPlan == 0 || pFilter == 0) {
		ifx_httpdError(wp, 200, T("Setup Error"));
		return;
	}
	sscanf(pProfile, "%u", &Profile);
	sscanf(pBandPlan, "%u", &BandPlan);
	sscanf(pFilter, "%u", &Filter);

	/*
	 * User code from Map file is Inserted here 
	 */

	sprintf(pCommand, "bpcs");

	sprintf(pParams, "%hu %u %u", LineNumber, BandPlan, Profile);

	if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS)
	{

		sscanf(pResult, "nReturn=%d ", &ret);

	}

	if (Profile == DSL_PROFILE_30A)

		data.nLineMode = DSL_DEV_LINEMODE_VDSL2_V43;

	else

		data.nLineMode = DSL_DEV_LINEMODE_VDSL2_B43;

	sprintf(pCommand, "lllcs");

	sprintf(pParams,
		"%d %d %d %d %d %d %d %d %d %d "
		"%d %d "
		"%u %d %d %d %d "
		"%d\n\r",
		(unsigned int)LineNumber,
		-1,
		-1,
		-1,
		-1,
		-1,
		-1,
		-1,
		-1,
		-1,
		(unsigned int)data.nLineMode,
		(unsigned int)Filter, -1, -1, -1, -1, -1, -1);

	if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS)
	{

		sscanf(pResult, "nReturn=%d ", &ret);

	}

	if (ret != 0) {
		ifx_httpdWrite(wp, T("<html>\n"));
		ifx_httpdWrite(wp, T("<head>\n"));
		ifx_httpdWrite(wp,
			       T
			       ("<script language=\"JavaScript\" src=\"../../script.js\"></script>\n"));
		ifx_httpdWrite(wp,
			       T
			       ("<title>Vdsl2 | Profile Config DSL Api Error</title>\n"));
		ifx_httpdWrite(wp, T("</head>\n"));
		ifx_httpdWrite(wp, T("<body bgColor=\"#e4e9f1\">\n"));
		ifx_httpdWrite(wp,
			       T
			       ("<table width=\"80%\" border=\"1\" cellspacing=\"0\" cellpadding=\"10\" height=\"30%\">\n"));
		ifx_httpdWrite(wp, T("<tr align=left>\n"));
		ifx_httpdWrite(wp, T("<td class=\"text\">Status</td>"));
		ifx_httpdWrite(wp, T("<td class=\"text\" id=\"nError\"</td>"));
		ifx_httpdWrite(wp, T("</tr>\n"));
		ifx_httpdWrite(wp, T("</table>\n"));
		ifx_httpdWrite(wp, T("<script language=\"JavaScript\">\n"));
		ifx_httpdWrite(wp, T("OnReceiveReturn(%d)\n"), ret);
		ifx_httpdWrite(wp, T("</script>\n"));
		ifx_httpdWrite(wp, T("</body>\n"));
		ifx_httpdWrite(wp, T("</html>\n"));
		return;
	}
//joelin        ifx_httpdNextPage(wp);
	websNextPage(wp);	//joelin

}

void
ifx_get_vdsl2profile_configTblData(int eid,
				   httpd_t wp, int argc, char_t ** argv)
{

	unsigned int nIndex;

	char sValue[10];

	int ret = -1;
	char pCommand[MAX_WEB_CMD_NAME_LENGTH];

	char pParams[MAX_WEB_PARAMS_LENGTH];

	char *pResult;

	unsigned int LineNumber = 0;

	DSL_DeviceLowLevelLineConfig_t data;

	DSL_BandPlanConfig_t BandPlanConfig;

	unsigned short int TmpLineNumber;

	unsigned int Profile;
	unsigned int BandPlan;
	unsigned int Filter;

	/*
	 * User code from Map file is Inserted here 
	 */

	/*
	 * 
	 * * User code from Map file is Inserted here 
	 */
	sprintf(pCommand, "bpcg");

	sprintf(pParams, "%hu ", LineNumber);

	if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS)
	{

		sscanf(pResult,
		       "nReturn=%d nLine=%hu nBandPlan=%u nProfile=%u\n\r",
		       &ret, &TmpLineNumber,
		       (unsigned int *)&BandPlanConfig.nBandPlan,
		       (unsigned int *)&BandPlanConfig.nProfile);

	}

	Profile = BandPlanConfig.nProfile;

	BandPlan = BandPlanConfig.nBandPlan;

	sprintf(pCommand, "lllcg");

	sprintf(pParams, "%hu ", LineNumber);

	if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS)
	{

		sscanf(pResult,
		       "nReturn=%d "
		       "nLine=%d "
		       "nGainSelection=%hu "
		       "nUserRxGain=0x%hu "
		       "nUserTxGain=0x%hu "
		       "nClockoutEnable=%d "
		       "nHdlcIfMode=%d "
		       "nMiiClockSource=%d "
		       "nMiiClockChain=%d "
		       "nTcMode=%d "
		       "nMiiMode=%d "
		       "nLineMode=%d "
		       "nFilter=%d "
		       "nBaseAddr=0x%u "
		       "nIrqNum=%d "
		       "nFwDlGroupId=%d "
		       "nBusMasterChipId=%d "
		       "nFwImageId=%d "
		       "nHybridSelection=%d ",
		       &ret,
		       &TmpLineNumber,
		       (int *)&data.nGainSelection,
		       (unsigned int *)&(data.nUserGainSettings.nRxGain),
		       (unsigned int *)&(data.nUserGainSettings.nTxGain),
		       (int *)&data.nClockoutEnable,
		       (int *)&data.nHdlcIfMode,
		       (int *)&data.nMiiClockSource,
		       (int *)&data.nMiiClockChain,
		       (int *)&data.nTcMode,
		       (int *)&data.nMiiMode,
		       (int *)&data.nLineMode,
		       (int *)&data.nFilter,
		       (unsigned int *)&data.nBaseAddr,
		       (unsigned int *)&(data.nIrqNum),
		       (unsigned int *)&(data.nFwDlGroupId),
		       (unsigned int *)&(data.nBusMasterChipId),
		       (unsigned int *)&(data.nFwImageId),
		       (int *)&data.nHybridSelection);

	}

	Filter = data.nFilter;

	ifx_httpdWrite(wp, T("<tr align=left>\n"));
	ifx_httpdWrite(wp, T("<td >"));
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"RetVal\" value=\"%d\">"),
		       ret);
	ifx_httpdWrite(wp, T("</td>"));
	ifx_httpdWrite(wp, T("</tr>\n"));

	if (ret != 0) {
		ifx_httpdWrite(wp, T("<tr align=left>\n"));
		ifx_httpdWrite(wp, T("<td class=\"text\">Status</td>"));
		ifx_httpdWrite(wp, T("<td class=\"text\" id=\"nError\"</td>"));
		ifx_httpdWrite(wp, T("</tr>\n"));

		/*
		 * Setting All Row Values to Default Values
		 */

		Profile = 0;
		BandPlan = 0;
		Filter = 0;
	}

	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \"><font class=\"subtitle\">Profile</font></td>\n"));
	ifx_httpdWrite(wp, T("<td>\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<font face=\"Arial, Helvetica, sans-serif\" size=\"2\" color=\"#0000ff\">\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<select name=\"Profile\" style=\"color: #000000\" size=\"1\">\n"));

	for (nIndex = 0;
	     nIndex < sizeof(ProfileList) / sizeof(WebUSignSelect_S);
	     nIndex++) {
		/*
		 * set Selected option 
		 */
		if (ProfileList[nIndex].value == Profile) {
			strcpy(sValue, "selected");
		} else {
			strcpy(sValue, " ");
		}

		ifx_httpdWrite(wp, T("<option value=\"%u\" %s >%s</option>\n"),
			       ProfileList[nIndex].value, sValue,
			       ProfileList[nIndex].str);

	}

	ifx_httpdWrite(wp, T("</select>\n"));
	ifx_httpdWrite(wp, T("</font>\n"));
	ifx_httpdWrite(wp, T("</td>\n"));

	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \"><font class=\"subtitle\">Band Plan </font></td>\n"));
	ifx_httpdWrite(wp, T("<td>\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<font face=\"Arial, Helvetica, sans-serif\" size=\"2\" color=\"#0000ff\">\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<select name=\"BandPlan\" style=\"color: #000000\" size=\"1\">\n"));

	for (nIndex = 0;
	     nIndex < sizeof(BandPlanList) / sizeof(WebUSignSelect_S); nIndex++)
	{
		/*
		 * set Selected option 
		 */
		if (BandPlanList[nIndex].value == BandPlan) {
			strcpy(sValue, "selected");
		} else {
			strcpy(sValue, " ");
		}

		ifx_httpdWrite(wp, T("<option value=\"%u\" %s >%s</option>\n"),
			       BandPlanList[nIndex].value, sValue,
			       BandPlanList[nIndex].str);

	}

	ifx_httpdWrite(wp, T("</select>\n"));
	ifx_httpdWrite(wp, T("</font>\n"));
	ifx_httpdWrite(wp, T("</td>\n"));

	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \"><font class=\"subtitle\">Filter</font></td>\n"));
	ifx_httpdWrite(wp, T("<td>\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<font face=\"Arial, Helvetica, sans-serif\" size=\"2\" color=\"#0000ff\">\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<select name=\"Filter\" style=\"color: #000000\" size=\"1\">\n"));

	for (nIndex = 0; nIndex < sizeof(FilterList) / sizeof(WebUSignSelect_S);
	     nIndex++) {
		/*
		 * set Selected option 
		 */
		if (FilterList[nIndex].value == Filter) {
			strcpy(sValue, "selected");
		} else {
			strcpy(sValue, " ");
		}

		ifx_httpdWrite(wp, T("<option value=\"%u\" %s >%s</option>\n"),
			       FilterList[nIndex].value, sValue,
			       FilterList[nIndex].str);

	}

	ifx_httpdWrite(wp, T("</select>\n"));
	ifx_httpdWrite(wp, T("</font>\n"));
	ifx_httpdWrite(wp, T("</td>\n"));

	ifx_httpdWrite(wp, T("</tr>\n"));
}
