
/*******************************************************************************
       Copyright (c) 2002, Infineon Technologies.  All rights reserved.
 
                               No Warranty                                                 
   Because the program is licensed free of charge, there is no warranty for 
   the program, to the extent permitted by applicable law.  Except when     
   otherwise stated in writing the copyright holders and/or other parties   
   provide the program "as is" without warranty of any kind, either         
   expressed or implied, including, but not limited to, the implied         
   warranties of merchantability and fitness for a particular purpose. The  
   entire risk as to the quality and performance of the program is with
   you.  should the program prove defective, you assume the cost of all     
   necessary servicing, repair or correction.                               
                                                                            
   In no event unless required by applicable law or agreed to in writing
   will any copyright holder, or any other party who may modify and/or      
   redistribute the program as permitted above, be liable to you for        
   damages, including any general, special, incidental or consequential     
   damages arising out of the use or inability to use the program           
   (including but not limited to loss of data or data being rendered        
   inaccurate or losses sustained by you or third parties or a failure of   
   the program to operate with any other programs), even if such holder or  
   other party has been advised of the possibility of such damages. 
********************************************************************************       
   Module      : $RCSfile: ifx_src_vdsl2_channel_status.c,v $
   Date        : $Date: 
   Description : 
*******************************************************************************/
#include	<ifx_emf.h>
#include	<signal.h>
#include	<unistd.h>
#include	<sys/types.h>
#include	<sys/wait.h>
#include	<sys/socket.h>
#include	<sys/ioctl.h>
#include	<arpa/inet.h>
#include	<netinet/in.h>
#include	<net/if.h>
#include	<net/if_arp.h>
#include	<ifx_common.h>
#include	"./ifx_amazon_cgi.h"

#include	"ifx_httpd_method.h"
//joelin #include       "ifx_common_defs.h"
//joelin #include       "ifx_web_common.h"
#include	<sys/reboot.h>
#include	"ifx_vdsl2_common.h"

/*********************************************************
* channel_status.asp
********************************************************/
static unsigned int prev_ChannelNumber;
static WebUSignSelect_S ChannelNumberList[] = {
	{0, "Channel0"},
	{1, "Channel1"}
};
static WebUSignSelect_S DirectionList[] = {
	{0, "Upstream"},
	{1, "Downstream"}
};

void ifx_get_wizard_channel_status(httpd_t wp, char_t * path, char_t * query)
{
	char *pChannelNumber;
	pChannelNumber = ifx_httpdGetVar(wp, T("ChannelNumber"), T(""));

/* Get Row Values from ASP file  */
	if (pChannelNumber == 0) {
		ifx_httpdError(wp, 200, T("Setup Error"));
		return;
	}
	sscanf(pChannelNumber, "%u", &prev_ChannelNumber);

	websNextPage(wp);
}

#define MAX_LOOP_LEN \
((((sizeof(DirectionList)/sizeof( WebUSignSelect_S ))-1) * (sizeof(DirectionList)/sizeof( WebUSignSelect_S )))+1)

void
ifx_get_vdsl2channel_statusTblData(int eid,
				   httpd_t wp, int argc, char_t ** argv)
{

	unsigned int nIndex;

	char sValue[10];

	int ret = -1;
	DSL_G997_ChannelStatus_t ChannelStatus;
	DSL_ErrorCounterTotalData_t ErrorCounterTotalData;

	int ret1;
	char pCommand[MAX_WEB_CMD_NAME_LENGTH];
	char pParams[MAX_WEB_PARAMS_LENGTH];
	char *pResult;
	unsigned int LineNumber = 0;
	unsigned int TmpDirection;
	unsigned short int TmpLineNumber, TmpChannelNumber;
	unsigned int ChannelNumber;
	unsigned int a_ChannelNumber[MAX_LOOP_LEN];
	unsigned int Direction;
	unsigned int a_Direction[MAX_LOOP_LEN];
	unsigned int DirectionIndex;
	unsigned int DirectionSize =
	    (sizeof(DirectionList) / sizeof(WebUSignSelect_S));
	unsigned int ActualDataRate;
	unsigned int a_ActualDataRate[MAX_LOOP_LEN];
	float ActualInterleaveDelay;
	float a_ActualInterleaveDelay[MAX_LOOP_LEN];
	unsigned int TotalCRCCount;
	unsigned int a_TotalCRCCount[MAX_LOOP_LEN];
	unsigned int TotalFECCount;
	unsigned int a_TotalFECCount[MAX_LOOP_LEN];
	float ActualINP;
	float a_ActualINP[MAX_LOOP_LEN];
	ChannelNumber = prev_ChannelNumber;

	for (DirectionIndex = 0; DirectionIndex < DirectionSize;
	     DirectionIndex++) {
		Direction = DirectionList[DirectionIndex].value;

		/*
		 * User code from Map file is Inserted here 
		 */
		printf(" Calling DSL API of Status Table\n");

		/*
		 * DSL_G997_ChannelStatusGet 
		 */
		sprintf(pCommand, "g997csg");
		sprintf(pParams, "%hu %hu %u", LineNumber, ChannelNumber,
			Direction);

		printf(" %s %s \n", pCommand, pParams);
		if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS) {
			sscanf(pResult,
			       "nReturn=%d nLine=%hu nChannel=%hu nDirection=%u ActualDataRate=%u PreviousDataRate=%u ActualInterleaveDelay=%u ActualImpulseNoiseProtection=%u\n\r",
			       &ret1, &TmpLineNumber, &TmpChannelNumber,
			       &TmpDirection, &ChannelStatus.ActualDataRate,
			       &ChannelStatus.PreviousDataRate,
			       &ChannelStatus.ActualInterleaveDelay,
			       (unsigned int *)&ChannelStatus.
			       ActualImpulseNoiseProtection);
			ret = 0;	/* First time */
		}
		ActualDataRate = ChannelStatus.ActualDataRate / 1000;
		ActualInterleaveDelay =
		    (float)ChannelStatus.ActualInterleaveDelay / 100;
		ActualINP =
		    (float)ChannelStatus.ActualImpulseNoiseProtection / 2;

		if (ret1 != 0) {
			ret = ret1;
		}

		WEB_SLEEP;
		/*
		 * DSL_ErrorCounterTotalGet 
		 */

		sprintf(pCommand, "ectg");
		sprintf(pParams, "%hu %hu %u", LineNumber, ChannelNumber,
			Direction);

		printf(" %s %s \n", pCommand, pParams);
		if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS) {
			sscanf(pResult,
			       "nReturn=%d nLine=%hu nChannel=%hu nDirection=%u FEC=%u CRC=%u HEC=%u\n\r",
			       &ret1, &TmpLineNumber, &TmpChannelNumber,
			       &TmpDirection, &ErrorCounterTotalData.FEC,
			       &ErrorCounterTotalData.CRC,
			       &ErrorCounterTotalData.HEC);
		}
		TotalCRCCount = ErrorCounterTotalData.CRC;
		TotalFECCount = ErrorCounterTotalData.FEC;
		if (ret1 != 0) {
			ret = ret1;
		}

		a_ChannelNumber[(DirectionIndex * DirectionSize)] =
		    ChannelNumber;

		a_Direction[(DirectionIndex * DirectionSize)] = Direction;

		a_ActualDataRate[(DirectionIndex * DirectionSize)] =
		    ActualDataRate;

		a_ActualInterleaveDelay[(DirectionIndex * DirectionSize)] =
		    ActualInterleaveDelay;

		a_TotalCRCCount[(DirectionIndex * DirectionSize)] =
		    TotalCRCCount;

		a_TotalFECCount[(DirectionIndex * DirectionSize)] =
		    TotalFECCount;

		a_ActualINP[(DirectionIndex * DirectionSize)] = ActualINP;

	}

	ifx_httpdWrite(wp, T("<tr align=left>\n"));
	ifx_httpdWrite(wp, T("<td >"));
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"RetVal\" value=\"%d\">"),
		       ret);
	ifx_httpdWrite(wp, T("</td>"));
	ifx_httpdWrite(wp, T("</tr>\n"));

	if (ret != 0) {
		ifx_httpdWrite(wp, T("<tr align=left>\n"));
		ifx_httpdWrite(wp, T("<td class=\"text\">Status</td>"));
		ifx_httpdWrite(wp, T("<td class=\"text\" id=\"nError\"</td>"));
		ifx_httpdWrite(wp, T("</tr>\n"));

		/*
		 * Setting All Row Values to Default Values
		 */

		Direction = 0;
		ActualDataRate = 0;
		ActualInterleaveDelay = 0;
		TotalCRCCount = 0;
		TotalFECCount = 0;
		ActualINP = 0;
	}

	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \"><font class=\"subtitle\">Channel Number</font></td>\n"));
	ifx_httpdWrite(wp, T("<td>\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<font face=\"Arial, Helvetica, sans-serif\" size=\"2\" color=\"#0000ff\">\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<select onchange=\"GetValues()\"name=\"ChannelNumber\" style=\"color: #000000\" size=\"1\">\n"));

	for (nIndex = 0;
	     nIndex < sizeof(ChannelNumberList) / sizeof(WebUSignSelect_S);
	     nIndex++) {
		/*
		 * set Selected option 
		 */
		if (ChannelNumberList[nIndex].value == ChannelNumber) {
			strcpy(sValue, "selected");
		} else {
			strcpy(sValue, " ");
		}

		ifx_httpdWrite(wp, T("<option value=\"%u\" %s >%s</option>\n"),
			       ChannelNumberList[nIndex].value, sValue,
			       ChannelNumberList[nIndex].str);

	}

	ifx_httpdWrite(wp, T("</select>\n"));
	ifx_httpdWrite(wp, T("</font>\n"));
	ifx_httpdWrite(wp, T("</td>\n"));

	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \"><font class=\"subtitle\"></font></td>\n"));

	for (DirectionIndex = 0; DirectionIndex < DirectionSize;
	     DirectionIndex++) {
		ifx_httpdWrite(wp,
			       T
			       ("<td width=\"30% \"><font class=\"subtitle\">%s</font></td>\n"),
			       DirectionList[DirectionIndex].str);
	}

	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \" class=textCell><font class=\"subtitle\">Actual Data Rate</font></td>\n"));

	for (DirectionIndex = 0; DirectionIndex < DirectionSize;
	     DirectionIndex++) {

		ifx_httpdWrite(wp,
			       T
			       ("<td class=textCell><font class=\"subtitle\">%u  kbps </font></td>\n"),
			       a_ActualDataRate[(DirectionIndex *
						 DirectionSize)]);

		ifx_httpdWrite(wp, T("</td>\n"));

	}

	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \" class=textCell><font class=\"subtitle\">Actual Interleave Delay</font></td>\n"));

	for (DirectionIndex = 0; DirectionIndex < DirectionSize;
	     DirectionIndex++) {

		ifx_httpdWrite(wp,
			       T
			       ("<td class=textCell><font class=\"subtitle\">%f  ms </font></td>\n"),
			       a_ActualInterleaveDelay[(DirectionIndex *
							DirectionSize)]);

		ifx_httpdWrite(wp, T("</td>\n"));

	}

	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \" class=textCell><font class=\"subtitle\">Total CRC Count</font></td>\n"));

	for (DirectionIndex = 0; DirectionIndex < DirectionSize;
	     DirectionIndex++) {

		ifx_httpdWrite(wp,
			       T
			       ("<td class=textCell><font class=\"subtitle\">%u  </font></td>\n"),
			       a_TotalCRCCount[(DirectionIndex *
						DirectionSize)]);

		ifx_httpdWrite(wp, T("</td>\n"));

	}

	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \" class=textCell><font class=\"subtitle\">Total FEC Count</font></td>\n"));

	for (DirectionIndex = 0; DirectionIndex < DirectionSize;
	     DirectionIndex++) {

		ifx_httpdWrite(wp,
			       T
			       ("<td class=textCell><font class=\"subtitle\">%u  </font></td>\n"),
			       a_TotalFECCount[(DirectionIndex *
						DirectionSize)]);

		ifx_httpdWrite(wp, T("</td>\n"));

	}

	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \" class=textCell><font class=\"subtitle\">Actual INP</font></td>\n"));

	for (DirectionIndex = 0; DirectionIndex < DirectionSize;
	     DirectionIndex++) {

		ifx_httpdWrite(wp,
			       T
			       ("<td class=textCell><font class=\"subtitle\">%f  Symbols </font></td>\n"),
			       a_ActualINP[(DirectionIndex * DirectionSize)]);

		ifx_httpdWrite(wp, T("</td>\n"));

	}

	ifx_httpdWrite(wp, T("</tr>\n"));
}
