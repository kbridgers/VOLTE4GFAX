
/*******************************************************************************
       Copyright (c) 2002, Infineon Technologies.  All rights reserved.
 
                               No Warranty                                                 
   Because the program is licensed free of charge, there is no warranty for 
   the program, to the extent permitted by applicable law.  Except when     
   otherwise stated in writing the copyright holders and/or other parties   
   provide the program "as is" without warranty of any kind, either         
   expressed or implied, including, but not limited to, the implied         
   warranties of merchantability and fitness for a particular purpose. The  
   entire risk as to the quality and performance of the program is with
   you.  should the program prove defective, you assume the cost of all     
   necessary servicing, repair or correction.                               
                                                                            
   In no event unless required by applicable law or agreed to in writing
   will any copyright holder, or any other party who may modify and/or      
   redistribute the program as permitted above, be liable to you for        
   damages, including any general, special, incidental or consequential     
   damages arising out of the use or inability to use the program           
   (including but not limited to loss of data or data being rendered        
   inaccurate or losses sustained by you or third parties or a failure of   
   the program to operate with any other programs), even if such holder or  
   other party has been advised of the possibility of such damages. 
********************************************************************************       
   Module      : $RCSfile: ifx_src_vdsl2_line_status.c,v $
   Date        : $Date: 
   Description : 
*******************************************************************************/
#include	<ifx_emf.h>
#include	<signal.h>
#include	<unistd.h>
#include	<sys/types.h>
#include	<sys/wait.h>
#include	<sys/socket.h>
#include	<sys/ioctl.h>
#include	<arpa/inet.h>
#include	<netinet/in.h>
#include	<net/if.h>
#include	<net/if_arp.h>
#include	<ifx_common.h>
#include	"./ifx_amazon_cgi.h"

#include	"ifx_httpd_method.h"
//joelin #include       "ifx_common_defs.h"
//joelin #include       "ifx_web_common.h"
#include	<sys/reboot.h>
#include	"ifx_vdsl2_common.h"

/*********************************************************
* line_status.asp
********************************************************/
static WebUSignSelect_S DirectionList[] = {
	{0, "Upstream"},
	{1, "Downstream"}
};
static WebUSignSelect_S StateList[] = {
	{0, "not_initialized"},
	{1, "exception"},
	{255, "idle request"},
	{256, "idle"},
	{511, "silent request"},
	{512, "silent"},
	{768, "handshake"},
	{896, "full init"},
	{1024, "discovery"},
	{1280, "training"},
	{1536, "analysis"},
	{1792, "exchange"},
	{2048, "showtime no sync"},
	{2049, "showtime tc sync"},
	{2304, "fast retrain"},
	{2560, "lowpower l2"},
	{2816, "loopdiagnostic"},
	{3072, "loopdiagnostic complete"},
	{3328, "resync"},
	{16777216, "test"},
	{33554432, "lowpower l3"},
	{50331648, "unknown"}
};

void ifx_get_wizard_line_status(httpd_t wp, char_t * path, char_t * query)
{

	websNextPage(wp);
}

#define MAX_LOOP_LEN \
((((sizeof(DirectionList)/sizeof( WebUSignSelect_S ))-1) * (sizeof(DirectionList)/sizeof( WebUSignSelect_S )))+1)

void
ifx_get_vdsl2line_statusTblData(int eid, httpd_t wp, int argc, char_t ** argv)
{

	unsigned int nIndex;

	int ret = -1;
	DSL_LineState_t LineState;
	DSL_G997_LineStatus_t LineStatus;
	int LineStatusSNR0, LineStatusSNR1, LineStatusSNR2, LineStatusSNR3,
	    LineStatusSNR4;
	int ret1;
	char pCommand[MAX_WEB_CMD_NAME_LENGTH];
	char pParams[MAX_WEB_PARAMS_LENGTH];
	char *pResult;
	unsigned int LineNumber = 0;
	unsigned int TmpDirection;
	unsigned short int TmpLineNumber;
	unsigned int Direction;
	unsigned int a_Direction[MAX_LOOP_LEN];
	unsigned int DirectionIndex;
	unsigned int DirectionSize =
	    (sizeof(DirectionList) / sizeof(WebUSignSelect_S));
	unsigned int State;
	unsigned int a_State[MAX_LOOP_LEN];
	float Band1ActualSNR;
	float a_Band1ActualSNR[MAX_LOOP_LEN];
	float Band2ActualSNR;
	float a_Band2ActualSNR[MAX_LOOP_LEN];
	float Band3ActualSNR;
	float a_Band3ActualSNR[MAX_LOOP_LEN];
	float Band4ActualSNR;
	float a_Band4ActualSNR[MAX_LOOP_LEN];
	float Band5ActualSNR;
	float a_Band5ActualSNR[MAX_LOOP_LEN];

	for (DirectionIndex = 0; DirectionIndex < DirectionSize;
	     DirectionIndex++) {
		Direction = DirectionList[DirectionIndex].value;

		/*
		 * User code from Map file is Inserted here 
		 */
		printf(" Calling DSL API of Status Table\n");

		/*
		 * DSL_LineStateGet 
		 */
		sprintf(pCommand, "lsg");
		sprintf(pParams, "%hu ", LineNumber);

		printf(" %s %s \n", pCommand, pParams);
		if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS) {
			sscanf(pResult,
			       "nReturn=%d nLine=%hu nLineState=%x\n\r", &ret1,
			       &TmpLineNumber,
			       (unsigned int *)&LineState.nLineState);
			ret = 0;	/*  First Time */
		}
		State = LineState.nLineState;
		if (ret1 != 0) {
			ret = ret1;
		}

		WEB_SLEEP;
		/*
		 * DSL_G997_LineStatusGet 
		 */
		sprintf(pCommand, "g997lsg");
		sprintf(pParams, "%hu %u", LineNumber, Direction);

		printf(" %s %s \n", pCommand, pParams);
		if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS) {
			sscanf(pResult,
			       "nReturn=%d nLine=%hu nDirection=%u "
			       "LATN[0]=%hd LATN[1]=%hd LATN[2]=%hd LATN[3]=%hd LATN[4]=%hd "
			       "SATN[0]=%hd SATN[1]=%hd SATN[2]=%hd SATN[3]=%hd SATN[4]=%hd "
			       "SNR[0]=%d SNR[1]=%d SNR[2]=%d SNR[3]=%d SNR[4]=%d "
			       "ATTNDR=%u ACTPS=%d ACTATP=%d\n\r", &ret1,
			       &TmpLineNumber, &TmpDirection,
			       &LineStatus.LATN[0], &LineStatus.LATN[1],
			       &LineStatus.LATN[2], &LineStatus.LATN[3],
			       &LineStatus.LATN[4], &LineStatus.SATN[0],
			       &LineStatus.SATN[1], &LineStatus.SATN[2],
			       &LineStatus.SATN[3], &LineStatus.SATN[4],
			       &LineStatusSNR0, &LineStatusSNR1,
			       &LineStatusSNR2, &LineStatusSNR3,
			       &LineStatusSNR4, &LineStatus.ATTNDR,
			       &LineStatus.ACTPS, &LineStatus.ACTATP);
		}

//joelin                
		Band1ActualSNR = (float)LineStatusSNR0 / 10;
		Band2ActualSNR = (float)LineStatusSNR1 / 10;
		Band3ActualSNR = (float)LineStatusSNR2 / 10;
		Band4ActualSNR = (float)LineStatusSNR3 / 10;
		Band5ActualSNR = (float)LineStatusSNR4 / 10;

		if (ret1 != 0) {
			ret = ret1;
		}

		a_Direction[(DirectionIndex * DirectionSize)] = Direction;

		a_State[(DirectionIndex * DirectionSize)] = State;

		a_Band1ActualSNR[(DirectionIndex * DirectionSize)] =
		    Band1ActualSNR;

		a_Band2ActualSNR[(DirectionIndex * DirectionSize)] =
		    Band2ActualSNR;

		a_Band3ActualSNR[(DirectionIndex * DirectionSize)] =
		    Band3ActualSNR;

		a_Band4ActualSNR[(DirectionIndex * DirectionSize)] =
		    Band4ActualSNR;

		a_Band5ActualSNR[(DirectionIndex * DirectionSize)] =
		    Band5ActualSNR;

	}

	ifx_httpdWrite(wp, T("<tr align=left>\n"));
	ifx_httpdWrite(wp, T("<td >"));
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"RetVal\" value=\"%d\">"),
		       ret);
	ifx_httpdWrite(wp, T("</td>"));
	ifx_httpdWrite(wp, T("</tr>\n"));

	if (ret != 0) {
		ifx_httpdWrite(wp, T("<tr align=left>\n"));
		ifx_httpdWrite(wp, T("<td class=\"text\">Status</td>"));
		ifx_httpdWrite(wp, T("<td class=\"text\" id=\"nError\"</td>"));
		ifx_httpdWrite(wp, T("</tr>\n"));

		/*
		 * Setting All Row Values to Default Values
		 */

		Direction = 0;
		State = 0;
		Band1ActualSNR = 0;
		Band2ActualSNR = 0;
		Band3ActualSNR = 0;
		Band4ActualSNR = 0;
		Band5ActualSNR = 0;
	}

	ifx_httpdWrite(wp, T("<tr align=left>\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \"><font class=\"subtitle\"></font></td>\n"));

	for (DirectionIndex = 0; DirectionIndex < DirectionSize;
	     DirectionIndex++) {
		ifx_httpdWrite(wp,
			       T
			       ("<td width=\"30% \"><font class=\"subtitle\">%s</font></td>\n"),
			       DirectionList[DirectionIndex].str);
	}

	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \" class=textCell><font class=\"subtitle\">State</font></td>\n"));

	for (DirectionIndex = 0; DirectionIndex < DirectionSize;
	     DirectionIndex++) {

		for (nIndex = 0;
		     nIndex < sizeof(StateList) / sizeof(WebUSignSelect_S);
		     nIndex++) {
			/*
			 * set Selected option 
			 */
			if (StateList[nIndex].value ==
			    a_State[(DirectionIndex * DirectionSize)]) {
				break;
			}
		}

		if (nIndex != (sizeof(StateList) / sizeof(WebUSignSelect_S))) {
			ifx_httpdWrite(wp,
				       T
				       ("<td class=textCell><font class=\"subtitle\">%s</font></td>\n"),
				       StateList[nIndex].str);
		} else {
			ifx_httpdWrite(wp,
				       T
				       ("<td class=textCell><font class=\"subtitle\">%u</font></td>\n"),
				       State);
		}

		ifx_httpdWrite(wp, T("</td>\n"));

	}

	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \" class=textCell><font class=\"subtitle\">Band1 Actual SNR</font></td>\n"));

	for (DirectionIndex = 0; DirectionIndex < DirectionSize;
	     DirectionIndex++) {

		ifx_httpdWrite(wp,
			       T
			       ("<td class=textCell><font class=\"subtitle\">%f  dB </font></td>\n"),
			       a_Band1ActualSNR[(DirectionIndex *
						 DirectionSize)]);

		ifx_httpdWrite(wp, T("</td>\n"));

	}

	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \" class=textCell><font class=\"subtitle\">Band2 Actual SNR</font></td>\n"));

	for (DirectionIndex = 0; DirectionIndex < DirectionSize;
	     DirectionIndex++) {

		ifx_httpdWrite(wp,
			       T
			       ("<td class=textCell><font class=\"subtitle\">%f  dB </font></td>\n"),
			       a_Band2ActualSNR[(DirectionIndex *
						 DirectionSize)]);

		ifx_httpdWrite(wp, T("</td>\n"));

	}

	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \" class=textCell><font class=\"subtitle\">Band3 Actual SNR</font></td>\n"));

	for (DirectionIndex = 0; DirectionIndex < DirectionSize;
	     DirectionIndex++) {

		ifx_httpdWrite(wp,
			       T
			       ("<td class=textCell><font class=\"subtitle\">%f  dB </font></td>\n"),
			       a_Band3ActualSNR[(DirectionIndex *
						 DirectionSize)]);

		ifx_httpdWrite(wp, T("</td>\n"));

	}

	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \" class=textCell><font class=\"subtitle\">Band4 Actual SNR</font></td>\n"));

	for (DirectionIndex = 0; DirectionIndex < DirectionSize;
	     DirectionIndex++) {

		ifx_httpdWrite(wp,
			       T
			       ("<td class=textCell><font class=\"subtitle\">%f  dB </font></td>\n"),
			       a_Band4ActualSNR[(DirectionIndex *
						 DirectionSize)]);

		ifx_httpdWrite(wp, T("</td>\n"));

	}

	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \" class=textCell><font class=\"subtitle\">Band5 Actual SNR</font></td>\n"));

	for (DirectionIndex = 0; DirectionIndex < DirectionSize;
	     DirectionIndex++) {

		ifx_httpdWrite(wp,
			       T
			       ("<td class=textCell><font class=\"subtitle\">%f  dB </font></td>\n"),
			       a_Band5ActualSNR[(DirectionIndex *
						 DirectionSize)]);

		ifx_httpdWrite(wp, T("</td>\n"));

	}

	ifx_httpdWrite(wp, T("</tr>\n"));
}
