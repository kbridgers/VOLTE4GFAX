
/*******************************************************************************
       Copyright (c) 2002, Infineon Technologies.  All rights reserved.
 
                               No Warranty                                                 
   Because the program is licensed free of charge, there is no warranty for 
   the program, to the extent permitted by applicable law.  Except when     
   otherwise stated in writing the copyright holders and/or other parties   
   provide the program "as is" without warranty of any kind, either         
   expressed or implied, including, but not limited to, the implied         
   warranties of merchantability and fitness for a particular purpose. The  
   entire risk as to the quality and performance of the program is with
   you.  should the program prove defective, you assume the cost of all     
   necessary servicing, repair or correction.                               
                                                                            
   In no event unless required by applicable law or agreed to in writing
   will any copyright holder, or any other party who may modify and/or      
   redistribute the program as permitted above, be liable to you for        
   damages, including any general, special, incidental or consequential     
   damages arising out of the use or inability to use the program           
   (including but not limited to loss of data or data being rendered        
   inaccurate or losses sustained by you or third parties or a failure of   
   the program to operate with any other programs), even if such holder or  
   other party has been advised of the possibility of such damages. 
********************************************************************************       
   Module      : $RCSfile: ifx_src_vdsl2_line_config.c,v $
   Date        : $Date: 
   Description : 
*******************************************************************************/
#include	<ifx_emf.h>
#include	<signal.h>
#include	<unistd.h>
#include	<sys/types.h>
#include	<sys/wait.h>
#include	<sys/socket.h>
#include	<sys/ioctl.h>
#include	<arpa/inet.h>
#include	<netinet/in.h>
#include	<net/if.h>
#include	<net/if_arp.h>
#include	<ifx_common.h>
#include	"./ifx_amazon_cgi.h"

#include	"ifx_httpd_method.h"
//joelin#include        "ifx_common_defs.h"
//joelin #include       "ifx_web_common.h"
#include	<sys/reboot.h>
#include	"ifx_vdsl2_common.h"

/*********************************************************
* line_config.asp
********************************************************/
static unsigned int prev_Direction;
static WebUSignSelect_S DirectionList[] = {
	{0, "Upstream"},
	{1, "Downstream"}
};

void ifx_set_wizard_line_config(httpd_t wp, char_t * path, char_t * query)
{
	int ret = -1;
	char pCommand[MAX_WEB_CMD_NAME_LENGTH];
	char pParams[MAX_WEB_PARAMS_LENGTH];
	char *pResult;
	unsigned int LineNumber = 0;
	unsigned short int TmpLineNumber;
	DSL_G997_NoiseMarginConfig_t NoiseMarginConfig;
	unsigned int TmpDirection;
	int ret1;
	char *pDirection;
	unsigned int Direction;
	char *pTargetSNRM;
	float TargetSNRM;

/* Get Row Values from ASP file  */
	pDirection = ifx_httpdGetVar(wp, T("Direction"), T(""));
	pTargetSNRM = ifx_httpdGetVar(wp, T("TargetSNRM"), T(""));
	if (pDirection == 0 || pTargetSNRM == 0) {
		ifx_httpdError(wp, 200, T("Setup Error"));
		return;
	}
	sscanf(pDirection, "%u", &Direction);
	sscanf(pTargetSNRM, "%f", &TargetSNRM);

	/*
	 * User code from Map file is Inserted here 
	 */
	sprintf(pCommand, "g997nmcg");
	sprintf(pParams, "%hu %u", LineNumber, Direction);

	if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS) {
		sscanf(pResult,
		       "nReturn=%d nLine=%hu nDirection=%u TARSNRM=%hu MAXSNRM=%hu MINSNRM=%hu\n\r",
		       &ret1, &TmpLineNumber, &TmpDirection,
		       &NoiseMarginConfig.TARSNRM, &NoiseMarginConfig.MAXSNRM,
		       &NoiseMarginConfig.MINSNRM);
		ret = 0;	/*  First Time */
	}
	if (ret1 != 0) {
		ret = ret1;
	}
	NoiseMarginConfig.TARSNRM = TargetSNRM * 10;
	if (NoiseMarginConfig.TARSNRM < NoiseMarginConfig.MINSNRM) {
		NoiseMarginConfig.MINSNRM = NoiseMarginConfig.TARSNRM - 5;
	}
	if (NoiseMarginConfig.TARSNRM > NoiseMarginConfig.MAXSNRM) {
		NoiseMarginConfig.MAXSNRM = NoiseMarginConfig.TARSNRM + 5;
	}
	sprintf(pCommand, "g997nmcs");
	sprintf(pParams, "%hu %u %hu %hu %hu", LineNumber, Direction,
		NoiseMarginConfig.TARSNRM, NoiseMarginConfig.MAXSNRM,
		NoiseMarginConfig.MINSNRM);

	if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS) {
		sscanf(pResult, "nReturn=%d ", &ret1);
	}
	if (ret1 != 0) {
		ret = ret1;
	}

	if (ret != 0) {
		ifx_httpdWrite(wp, T("<html>\n"));
		ifx_httpdWrite(wp, T("<head>\n"));
		ifx_httpdWrite(wp,
			       T
			       ("<script language=\"JavaScript\" src=\"../../script.js\"></script>\n"));
		ifx_httpdWrite(wp,
			       T
			       ("<title>Vdsl2 | Line Config DSL Api Error</title>\n"));
		ifx_httpdWrite(wp, T("</head>\n"));
		ifx_httpdWrite(wp, T("<body bgColor=\"#e4e9f1\">\n"));
		ifx_httpdWrite(wp,
			       T
			       ("<table width=\"80%\" border=\"1\" cellspacing=\"0\" cellpadding=\"10\" height=\"30%\">\n"));
		ifx_httpdWrite(wp, T("<tr align=left>\n"));
		ifx_httpdWrite(wp, T("<td class=\"text\">Status</td>"));
		ifx_httpdWrite(wp, T("<td class=\"text\" id=\"nError\"</td>"));
		ifx_httpdWrite(wp, T("</tr>\n"));
		ifx_httpdWrite(wp, T("</table>\n"));
		ifx_httpdWrite(wp, T("<script language=\"JavaScript\">\n"));
		ifx_httpdWrite(wp, T("OnReceiveReturn(%d)\n"), ret);
		ifx_httpdWrite(wp, T("</script>\n"));
		ifx_httpdWrite(wp, T("</body>\n"));
		ifx_httpdWrite(wp, T("</html>\n"));
		return;
	}
	prev_Direction = Direction;

	websNextPage(wp);
}

void ifx_get_wizard_line_config(httpd_t wp, char_t * path, char_t * query)
{
	char *pDirection;
	pDirection = ifx_httpdGetVar(wp, T("Direction"), T(""));

/* Get Row Values from ASP file  */
	if (pDirection == 0) {
		ifx_httpdError(wp, 200, T("Setup Error"));
		return;
	}
	sscanf(pDirection, "%u", &prev_Direction);

	websNextPage(wp);
}

void
ifx_get_vdsl2line_configTblData(int eid, httpd_t wp, int argc, char_t ** argv)
{

	unsigned int nIndex;

	char sValue[10];

	int ret = -1;
	char pCommand[MAX_WEB_CMD_NAME_LENGTH];
	char pParams[MAX_WEB_PARAMS_LENGTH];
	char *pResult;
	unsigned int LineNumber = 0;
	unsigned short int TmpLineNumber;
	DSL_G997_NoiseMarginConfig_t NoiseMarginConfig;
	unsigned int TmpDirection;
	unsigned int Direction;
	float TargetSNRM;
	Direction = prev_Direction;

	/*
	 * User code from Map file is Inserted here 
	 */
	sprintf(pCommand, "g997nmcg");
	sprintf(pParams, "%hu %u", LineNumber, Direction);

	if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS) {
		sscanf(pResult,
		       "nReturn=%d nLine=%hu nDirection=%u TARSNRM=%hu MAXSNRM=%hu MINSNRM=%hu\n\r",
		       &ret, &TmpLineNumber, &TmpDirection,
		       &NoiseMarginConfig.TARSNRM, &NoiseMarginConfig.MAXSNRM,
		       &NoiseMarginConfig.MINSNRM);
	}
	TargetSNRM = (float)NoiseMarginConfig.TARSNRM / 10;

	ifx_httpdWrite(wp, T("<tr align=left>\n"));
	ifx_httpdWrite(wp, T("<td >"));
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"RetVal\" value=\"%d\">"),
		       ret);
	ifx_httpdWrite(wp, T("</td>"));
	ifx_httpdWrite(wp, T("</tr>\n"));

	if (ret != 0) {
		ifx_httpdWrite(wp, T("<tr align=left>\n"));
		ifx_httpdWrite(wp, T("<td class=\"text\">Status</td>"));
		ifx_httpdWrite(wp, T("<td class=\"text\" id=\"nError\"</td>"));
		ifx_httpdWrite(wp, T("</tr>\n"));

		/*
		 * Setting All Row Values to Default Values
		 */

		TargetSNRM = 0;
	}

	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \"><font class=\"subtitle\">Direction</font></td>\n"));
	ifx_httpdWrite(wp, T("<td>\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<font face=\"Arial, Helvetica, sans-serif\" size=\"2\" color=\"#0000ff\">\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<select onchange=\"GetValues()\"name=\"Direction\" style=\"color: #000000\" size=\"1\">\n"));

	for (nIndex = 0;
	     nIndex < sizeof(DirectionList) / sizeof(WebUSignSelect_S);
	     nIndex++) {
		/*
		 * set Selected option 
		 */
		if (DirectionList[nIndex].value == Direction) {
			strcpy(sValue, "selected");
		} else {
			strcpy(sValue, " ");
		}

		ifx_httpdWrite(wp, T("<option value=\"%u\" %s >%s</option>\n"),
			       DirectionList[nIndex].value, sValue,
			       DirectionList[nIndex].str);

	}

	ifx_httpdWrite(wp, T("</select>\n"));
	ifx_httpdWrite(wp, T("</font>\n"));
	ifx_httpdWrite(wp, T("</td>\n"));

	ifx_httpdWrite(wp, T("</tr>\n"));
	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \"><font class=\"subtitle\">Target SNRM</font></td>\n"));
	ifx_httpdWrite(wp, T("<td width=\"30%\">\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<input  type=\"text\" name=\"TargetSNRM\" size=\"25\" maxlength=\"60\" value=\"%f\">\n"),
		       TargetSNRM);
	ifx_httpdWrite(wp, T("</td>\n"));

	ifx_httpdWrite(wp, T("<td width=\"30%\">dB</td>\n"));

	ifx_httpdWrite(wp, T("</tr>\n"));
}
