
/*******************************************************************************
       Copyright (c) 2002, Infineon Technologies.  All rights reserved.
 
                               No Warranty                                                 
   Because the program is licensed free of charge, there is no warranty for 
   the program, to the extent permitted by applicable law.  Except when     
   otherwise stated in writing the copyright holders and/or other parties   
   provide the program "as is" without warranty of any kind, either         
   expressed or implied, including, but not limited to, the implied         
   warranties of merchantability and fitness for a particular purpose. The  
   entire risk as to the quality and performance of the program is with
   you.  should the program prove defective, you assume the cost of all     
   necessary servicing, repair or correction.                               
                                                                            
   In no event unless required by applicable law or agreed to in writing
   will any copyright holder, or any other party who may modify and/or      
   redistribute the program as permitted above, be liable to you for        
   damages, including any general, special, incidental or consequential     
   damages arising out of the use or inability to use the program           
   (including but not limited to loss of data or data being rendered        
   inaccurate or losses sustained by you or third parties or a failure of   
   the program to operate with any other programs), even if such holder or  
   other party has been advised of the possibility of such damages. 
********************************************************************************       
   Module      : $RCSfile: ifx_vdsl2_main.c,v $
   Date        : $Date: 
   Description : 
*******************************************************************************/

#define _GNU_SOURCE     1
#include <features.h>

#include <stdio.h>
#include <dlfcn.h>
#include <fcntl.h>		/* creat */
#include <sys/ioctl.h>		/* ioctl */

#include <ifx_emf.h>
#include "ifx_httpd_method.h"
#include "ifx_httpd.h"
#include <ifx_exportFunc.h>
//#include "ifx_web_common.h"

#include "ifx_vdsl2_common.h"

#define PIPE_PREFIX "/tmp/pipe/dms1_"

static char Result[MAX_WEB_OUT_BUF_SIZE];
#define WEB_CLI_DEBUG 0

int DSL_Cli_Access(char *pCommand, char *pParams, char **ppResult)
{
	FILE *pipe_cmd, *pipe_ack;
	int read_len, pos = 0;

	printf("\r\nDSLAPI: Command: %s ", pCommand);
	printf("Params: %s \r\n", pParams);

//leejack
//   memset(&Result, 0, MAX_WEB_OUT_BUF_SIZE);
	memset(Result, 0, MAX_WEB_OUT_BUF_SIZE);

	pipe_cmd = fopen(PIPE_PREFIX "cmd", "w");

	if (pipe_cmd == NULL) {
		fprintf(stderr, "fopen %s failed (errno=%d)\r\n",
			PIPE_PREFIX "cmd", errno);
		goto error;
	}

	/* execute command */
	fprintf(pipe_cmd, "%s %s\r\n", pCommand, pParams);
	fclose(pipe_cmd);

	WEB_SLEEP;

	pipe_ack = fopen(PIPE_PREFIX "ack", "r");

	if (pipe_ack == NULL) {
		fprintf(stderr, "fdopen %s failed (errno=%d)\r\n",
			PIPE_PREFIX "ack", errno);
		goto error;
	}

	/* read answer */
	do {
		read_len =
		    fread(&Result[pos], 1, sizeof(Result) - pos, pipe_ack);
		if (read_len > 0)
			pos += read_len;
	}
	while ((read_len > 0) && (pos < sizeof(Result)));

	fclose(pipe_ack);

#if 1
	if (pos < sizeof(Result))
		Result[pos] = '\0';
	else
		Result[sizeof(Result) - 1] = '\0';
#endif
	if (pos <= 0)
		goto error;

	*ppResult = Result;

	return WEB_SUCCESS;

      error:
	sprintf(Result, "nReturn=-1");
	*ppResult = Result;

	return WEB_FAIL;
}
