
/*******************************************************************************
       Copyright (c) 2002, Infineon Technologies.  All rights reserved.
 
                               No Warranty                                                 
   Because the program is licensed free of charge, there is no warranty for 
   the program, to the extent permitted by applicable law.  Except when     
   otherwise stated in writing the copyright holders and/or other parties   
   provide the program "as is" without warranty of any kind, either         
   expressed or implied, including, but not limited to, the implied         
   warranties of merchantability and fitness for a particular purpose. The  
   entire risk as to the quality and performance of the program is with
   you.  should the program prove defective, you assume the cost of all     
   necessary servicing, repair or correction.                               
                                                                            
   In no event unless required by applicable law or agreed to in writing
   will any copyright holder, or any other party who may modify and/or      
   redistribute the program as permitted above, be liable to you for        
   damages, including any general, special, incidental or consequential     
   damages arising out of the use or inability to use the program           
   (including but not limited to loss of data or data being rendered        
   inaccurate or losses sustained by you or third parties or a failure of   
   the program to operate with any other programs), even if such holder or  
   other party has been advised of the possibility of such damages. 
********************************************************************************       
   Module      : $RCSfile: ifx_src_vdsl2_activate_deactivate.c,v $
   Date        : $Date: 
   Description : 
*******************************************************************************/
#include	<ifx_emf.h>
#include	<signal.h>
#include	<unistd.h>
#include	<sys/types.h>
#include	<sys/wait.h>
#include	<sys/socket.h>
#include	<sys/ioctl.h>
#include	<arpa/inet.h>
#include	<netinet/in.h>
#include	<net/if.h>
#include	<net/if_arp.h>
#include	<ifx_common.h>
#include	"./ifx_amazon_cgi.h"

#include	"ifx_httpd_method.h"
//joelin #include       "ifx_common_defs.h"
//joelin #include       "ifx_web_common.h"
#include	<sys/reboot.h>
#include	"ifx_vdsl2_common.h"

/*********************************************************
* activate_deactivate.asp
********************************************************/
static unsigned int prev_Line = 1;
static WebUSignSelect_S LineList[] = {
	{0, "Activate"},
	{1, "Deactivate"}
};

void
ifx_set_wizard_activate_deactivate(httpd_t wp, char_t * path, char_t * query)
{
	int ret = -1;
	char pCommand[MAX_WEB_CMD_NAME_LENGTH];
	char pParams[MAX_WEB_PARAMS_LENGTH];
	char *pResult;
	unsigned int LineNumber = 0;
	unsigned short int TmpLineNumber;

	char *pLine;
	unsigned int Line;

/* Get Row Values from ASP file  */
	pLine = ifx_httpdGetVar(wp, T("Line"), T(""));
	if (pLine == 0) {
		ifx_httpdError(wp, 200, T("Setup Error"));
		return;
	}
	sscanf(pLine, "%u", &Line);

	/*
	 * User code from Map file is Inserted here 
	 */
	printf(" Calling DSL API \n");

	if (Line == ACTIVATE) {
		sprintf(pCommand, "la");
		sprintf(pParams, "%hu ", LineNumber);

		printf(" %s %s \n", pCommand, pParams);
		if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS) {
			sscanf(pResult, "nReturn=%d nLine=%hu\n\r", &ret,
			       &TmpLineNumber);
		}
	} else if (Line == DEACTIVATE) {
		sprintf(pCommand, "ld");
		sprintf(pParams, "%hu ", LineNumber);

		printf(" %s %s \n", pCommand, pParams);
		if (DSL_Cli_Access(pCommand, pParams, &pResult) == WEB_SUCCESS) {
			sscanf(pResult, "nReturn=%d nLine=%hu\n\r", &ret,
			       &TmpLineNumber);
		}
	}

	if (ret != 0) {
		ifx_httpdWrite(wp, T("<html>\n"));
		ifx_httpdWrite(wp, T("<head>\n"));
		ifx_httpdWrite(wp,
			       T
			       ("<script language=\"JavaScript\" src=\"../../script.js\"></script>\n"));
		ifx_httpdWrite(wp,
			       T
			       ("<title>Vdsl2 | Activate Deactivate DSL Api Error</title>\n"));
		ifx_httpdWrite(wp, T("</head>\n"));
		ifx_httpdWrite(wp, T("<body bgColor=\"#e4e9f1\">\n"));
		ifx_httpdWrite(wp,
			       T
			       ("<table width=\"80%\" border=\"1\" cellspacing=\"0\" cellpadding=\"10\" height=\"30%\">\n"));
		ifx_httpdWrite(wp, T("<tr align=left>\n"));
		ifx_httpdWrite(wp, T("<td class=\"text\">Status</td>"));
		ifx_httpdWrite(wp, T("<td class=\"text\" id=\"nError\"</td>"));
		ifx_httpdWrite(wp, T("</tr>\n"));
		ifx_httpdWrite(wp, T("</table>\n"));
		ifx_httpdWrite(wp, T("<script language=\"JavaScript\">\n"));
		ifx_httpdWrite(wp, T("OnReceiveReturn(%d)\n"), ret);
		ifx_httpdWrite(wp, T("</script>\n"));
		ifx_httpdWrite(wp, T("</body>\n"));
		ifx_httpdWrite(wp, T("</html>\n"));
		return;
	}
	prev_Line = Line;

	websNextPage(wp);
}

void
ifx_get_vdsl2activate_deactivateTblData(int eid,
					httpd_t wp, int argc, char_t ** argv)
{

	unsigned int nIndex;

	char sValue[10];

	int ret = 0;
	unsigned int Line;
	Line = prev_Line;

	ifx_httpdWrite(wp, T("<tr align=left>\n"));
	ifx_httpdWrite(wp, T("<td >"));
	ifx_httpdWrite(wp,
		       T
		       ("<input type=\"hidden\" name=\"RetVal\" value=\"%d\">"),
		       ret);
	ifx_httpdWrite(wp, T("</td>"));
	ifx_httpdWrite(wp, T("</tr>\n"));

	ifx_httpdWrite(wp, T("<tr align=left>\n"));

	ifx_httpdWrite(wp,
		       T
		       ("<td width=\"30% \"><font class=\"subtitle\">Line</font></td>\n"));
	ifx_httpdWrite(wp, T("<td>\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<font face=\"Arial, Helvetica, sans-serif\" size=\"2\" color=\"#0000ff\">\n"));
	ifx_httpdWrite(wp,
		       T
		       ("<select name=\"Line\" style=\"color: #000000\" size=\"1\">\n"));

	for (nIndex = 0; nIndex < sizeof(LineList) / sizeof(WebUSignSelect_S);
	     nIndex++) {
		/*
		 * set Selected option 
		 */
		if (LineList[nIndex].value == Line) {
			strcpy(sValue, "selected");
		} else {
			strcpy(sValue, " ");
		}

		ifx_httpdWrite(wp, T("<option value=\"%u\" %s >%s</option>\n"),
			       LineList[nIndex].value, sValue,
			       LineList[nIndex].str);

	}

	ifx_httpdWrite(wp, T("</select>\n"));
	ifx_httpdWrite(wp, T("</font>\n"));
	ifx_httpdWrite(wp, T("</td>\n"));

	ifx_httpdWrite(wp, T("</tr>\n"));
}
