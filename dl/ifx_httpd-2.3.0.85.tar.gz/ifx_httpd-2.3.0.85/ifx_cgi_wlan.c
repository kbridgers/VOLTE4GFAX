#include <sys/syslog.h>
#include <ifx_emf.h>
#include "ifx_httpd_method.h"
#include <signal.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ifx_common.h>
#include "./ifx_amazon_cgi.h"
#include "./ifx_amazon_cgi_getFunctions.h"
#include "ifx_snmp_api.h"
#include "ifx_api_ipt_common.h"
#include <sys/ioctl.h>

#ifdef CONFIG_FEATURE_IFX_WIRELESS_ATH
void ifx_set_wlan_settings(httpd_t wp, char_t * path, char_t * query);	// wireless_settings.asp
void ifx_set_wlan_security(httpd_t wp, char_t * path, char_t * query);	// wireless_security.asp
#endif				// CONFIG_FEATURE_IFX_WIRELESS_ATH

#ifdef CONFIG_FEATURE_IFX_WIRELESS_TSC
void ifx_set_basic_wireless_settings(httpd_t wp, char_t * path, char_t * query);
void ifx_set_advanced_wireless_settings(httpd_t wp, char_t * path,
					char_t * query);
void ifx_set_wireless_security_settings(httpd_t wp, char_t * path,
					char_t * query);
void ifx_set_wireless_macfilter_settings(httpd_t wp, char_t * path,
					 char_t * query);
void ifx_set_wireless_add_macfilter_settings(httpd_t wp, char_t * path,
					     char_t * query);
#endif				// CONFIG_FEATURE_IFX_WIRELESS_TSC

#ifdef CONFIG_FEATURE_IFX_WIRELESS_ATH
int ifx_get_wlan_settings(int eid, httpd_t wp, int argc, char_t ** argv);	// wireless_settings.asp
int ifx_get_wlan_security(int eid, httpd_t wp, int argc, char_t ** argv);	// wireless_security.asp
int ifx_get_radius_ip(int eid, httpd_t wp, int argc, char_t * *argv);
#endif				// CONFIG_FEATURE_IFX_WIRELESS_ATH

#ifdef CONFIG_FEATURE_IFX_WIRELESS_TSC
int ifx_get_wireless_settings(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_all_wireless_ap_settings(int eid, httpd_t wp, int argc,
				     char_t ** argv);
int ifx_get_advanced_wireless_settings(int eid, httpd_t wp, int argc,
				       char_t ** argv);
int ifx_get_wireless_security_settings(int eid, httpd_t wp, int argc,
				       char_t ** argv);
int ifx_get_wireless_dev_assoc(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_all_wireless_mac_ctrl_entries(int eid, httpd_t wp, int argc,
					  char_t ** argv);
int ifx_get_wireless_mac_control_status(int eid, httpd_t wp, int argc,
					char_t ** argv);
void ifx_get_wlan_statistics(int eid, httpd_t wp, int argc, char_t ** argv);
void ifx_get_wlan_dev_associations(int eid, httpd_t wp, int argc,
				   char_t ** argv);
#endif				// CONFIG_FEATURE_IFX_WIRELESS_TSC

#ifdef CONFIG_FEATURE_IFX_WIRELESS_ATH

// wireless_settings.asp
CGI_ENUMSEL_S web_Enum_ChannelMode_List[] = {
	{0, "         "},
	{1, "Channel 1"},
	{2, "Channel 2"},
	{3, "Channel 3"},
	{4, "Channel 4"},
	{5, "Channel 5"},
	{6, "Channel 6"},
	{7, "Channel 7"},
	{8, "Channel 8"},
	{9, "Channel 9"},
	{10, "Channel 10"},
	{11, "Channel 11"},
	{12, "Channel 12"},
	{13, "Channel 13"},
	{14, "Channel 14"}
};

CGI_ENUMSEL_S web_Enum_SSIDMode_List[] = {
	{0, "Advertise SSID"},
	{1, "Hide SSID"},
};

CGI_ENUMSEL_S web_Enum_OPRateMode_List[] = {
	{0, "Auto"},
	{1, "802.11A Mode"},
	{2, "802.11B Mode"},
	{3, "802.11G Mode"},
};
CGI_ENUMSEL_S web_Enum_PreambleMode_List[] = {
	{0, "               "},
	{1, "Long Preamble"},
	{2, "Auto"}
};

CGI_ENUMSEL_S web_Enum_CTS_List[] = {
	{0, "OFF"},
	{1, "ON"}
};

CGI_ENUMSEL_S web_Enum_PowerLevel_List[] = {
	{0, "1 (20%)"},
	{1, "2 (40%)"},
	{2, "3 (60%)"},
	{3, "4 (80%)"},
	{4, "5 (100%)"}
};

CGI_ENUMSEL_S web_Enum_Domain_List[] = {
	{0, "FCC"},
	{1, "IC"},
	{2, "ETSI"},
	{3, "Spain"},
	{4, "France"},
	{5, "MKK"},
	{6, "MKKII"}
};

int g_nRegulationDomain = 0;
int ifx_get_wlan_settings(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name, sValue[MAX_FILELINE_LEN];
	int i, nSelIdx = 0;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	sValue[0] = '\0';
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_DOMAIN", sValue) == 1) {
		/* Get the regulation domain */
		nSelIdx = gatoi(sValue);
		g_nRegulationDomain = nSelIdx;
	}

	if (!gstrcmp(name, T("channel")) || !gstrcmp(name, T("ProvChannel"))) {
		int nOperateIdx = -1;
		int nMinChannel = 1, nMaxChannel = 14;

		// for Operation mode select box
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_OP_RATE",
		     sValue) == 1) {
			nOperateIdx = gatoi(sValue);
		}

		sValue[0] = '\0';
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_CHANNEL",
		     sValue) == 1) {
			nSelIdx = gatoi(sValue);

			if (!gstrcmp(name, T("ProvChannel"))) {
				if (nSelIdx == 1 || nSelIdx == 6
				    || nSelIdx == 11)
					ifx_httpdWrite(wp, sValue);
				return 0;
			}

			switch (g_nRegulationDomain) {
			case 0:
			case 1:
				nMinChannel = 1;
				nMaxChannel = 11;
				break;
			case 2:
				nMinChannel = 1;
				nMaxChannel = 13;
				break;
			case 3:
				nMinChannel = 10;
				nMaxChannel = 11;
				break;
			case 4:
				nMinChannel = 10;
				nMaxChannel = 13;
				break;
			case 5:
				nMinChannel = 14;
				nMaxChannel = 14;
				break;
			case 6:
				nMinChannel = 1;
				nMaxChannel = 14;
				break;
			}

			for (i = nMinChannel; i <= nMaxChannel; i++) {
				if (i == nSelIdx) {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t\t<option value=\"%d\""
							" SELECTED>%s</option>\n"),
						       i,
						       web_Enum_ChannelMode_List
						       [i].str);
				} else {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t\t<option value=\"%d\">"
							"%s</option>\n"), i,
						       web_Enum_ChannelMode_List
						       [i].str);
				}
			}
		}
	} else if (!gstrcmp(name, T("hiddenSsid"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_HIDDEN_SSID",
		     sValue) == 1) {
			nSelIdx = gatoi(sValue);

			for (i = 0;
			     i <
			     sizeof(web_Enum_SSIDMode_List) /
			     sizeof(CGI_ENUMSEL_S); i++) {
				if (i == nSelIdx) {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t\t<option value=\"%d\" SELECTED>%s</option>\n"),
						       i,
						       web_Enum_SSIDMode_List
						       [i].str);
				} else {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t\t<option value=\"%d\">%s</option>\n"),
						       i,
						       web_Enum_SSIDMode_List
						       [i].str);
				}
			}
		}
	} else if (!gstrcmp(name, T("DTIMInterval")) ||
		   !gstrcmp(name, T("ProvDTIMInterval"))) {
		if (ifx_GetCfgData(FILE_RC_CONF, TAG_WLAN_SETTINGS,
				   "WLAN_DTIM_INTERVAL", sValue) == 1) {
			if (!gstrcmp(name, T("ProvDTIMInterval"))) {
				ifx_httpdWrite(wp, sValue);
				return 0;
			}

			ifx_httpdWrite(wp,
				       "<tr><td width=\"48%\" height=\"29\">");
			ifx_httpdWrite(wp,
				       "<font class=\"subtitle\">DTIM Interval"
				       "</font></td>");
			ifx_httpdWrite(wp, "<td width=\"54%\" height=\"29\">");
			ifx_httpdWrite(wp,
				       "<input type=\"text\" name=\"dtim_intval\" "
				       "value=\"%s\" maxlength=\"3\">", sValue);
			ifx_httpdWrite(wp, "</td></tr>");
		}
	} else if (!gstrcmp(name, T("evaltDTIM"))) {
		ifx_httpdWrite(wp, "if(DTIMIntervalNotInRange(document.tF0."
			       "dtim_intval.value)) {");
		ifx_httpdWrite(wp, "alert(ipm4); return false; }");
	} else if (!gstrcmp(name, T("cts")) || !gstrcmp(name, T("ProvCts"))) {
		if (ifx_GetCfgData(FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_CTS",
				   sValue) == 1) {
			if (!gstrcmp(name, T("ProvCts"))) {
				ifx_httpdWrite(wp, sValue);
				return 0;
			}

			ifx_httpdWrite(wp,
				       "<tr><td width=\"48%\" height=\"33\">");
			ifx_httpdWrite(wp,
				       "<font class=\"subtitle\">CTS Protection "
				       "Mode</font></td>");
			ifx_httpdWrite(wp, "<td width=\"54%\" height=\"33\">");
			ifx_httpdWrite(wp, "<select name=\"cts_mode\">");

			for (i = 0;
			     i <
			     sizeof(web_Enum_CTS_List) / sizeof(CGI_ENUMSEL_S);
			     i++) {
				if (i == atoi(sValue)) {
					ifx_httpdWrite(wp,
						       T("<option value=\"%d\""
							 " SELECTED>%s</option>\n"),
						       web_Enum_CTS_List[i].
						       value,
						       web_Enum_CTS_List[i].
						       str);
				} else {
					ifx_httpdWrite(wp,
						       T("<option value=\"%d\">"
							 "%s</option>\n"),
						       web_Enum_CTS_List[i].
						       value,
						       web_Enum_CTS_List[i].
						       str);
				}
			}

			ifx_httpdWrite(wp, "</select></td></tr>");
		}
	} else if (!gstrcmp(name, T("PowerLevel")) ||
		   !gstrcmp(name, T("txpower"))
		   || !gstrcmp(name, T("ProvTxPower"))) {
		CGI_ENUMSEL_S *pPowerLevelList = web_Enum_PowerLevel_List;
		if (ifx_GetCfgData(FILE_RC_CONF, TAG_WLAN_SETTINGS,
				   "WLAN_POWER_LEVEL", sValue) == 1) {
			nSelIdx = gatoi(sValue);

			if (!gstrcmp(name, T("ProvTxPower"))) {
				switch (nSelIdx) {
				case 0:
					strcpy(sValue, "20%");
					break;
				case 1:
					strcpy(sValue, "40%");
					break;
				case 2:
					strcpy(sValue, "60%");
					break;
				case 3:
					strcpy(sValue, "80%");
					break;
				case 4:
					strcpy(sValue, "100%");
					break;
				}
				ifx_httpdWrite(wp, sValue);
				return 0;
			} else if (!gstrcmp(name, T("txpower"))) {
				ifx_httpdWrite(wp, T("%d"), nSelIdx);
				return 0;
			}

			pPowerLevelList = web_Enum_PowerLevel_List;
			for (i = 0; i < 5; i++) {
				if (i == nSelIdx) {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t\t<option value=\"%d\" SELECTED>%s</option>\n"),
						       i,
						       pPowerLevelList[i].str);
				} else {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t\t<option value=\"%d\">%s</option>\n"),
						       i,
						       pPowerLevelList[i].str);
				}
			}
		}
	} else if (!gstrcmp(name, T("RegulationDomain")) ||
		   !gstrcmp(name, T("ProvDomain"))
		   || !gstrcmp(name, T("seldomain"))) {
		if (!gstrcmp(name, T("ProvDomain"))) {
			if (!strcmp
			    (web_Enum_Domain_List[g_nRegulationDomain].str,
			     "FCC"))
				strcpy(sValue, "ALL");
			else
				strcpy(sValue,
				       web_Enum_Domain_List
				       [g_nRegulationDomain].str);

			ifx_httpdWrite(wp, sValue);
			return 0;
		}

		if (!gstrcmp(name, T("seldomain"))) {
			ifx_httpdWrite(wp, T("%d"), g_nRegulationDomain);
			return 0;
		}

		for (i = 0;
		     i < sizeof(web_Enum_Domain_List) / sizeof(CGI_ENUMSEL_S);
		     i++) {
			if (i == g_nRegulationDomain) {
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t\t\t<option value=\"%d\" "
						"SELECTED>%s</option>\n"), i,
					       web_Enum_Domain_List[i].str);
			} else {
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t\t\t<option value=\"%d\">%s"
						"</option>\n"), i,
					       web_Enum_Domain_List[i].str);
			}
		}
	} else if (!gstrcmp(name, T("essid"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_ESSID", sValue)
		    == 1) {
			ifx_web_convert_string(sValue);
			ifx_httpdWrite(wp, sValue);
		}
	} else if (!gstrcmp(name, T("nick"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_AP_NAME",
		     sValue) == 1) {
			ifx_web_convert_string(sValue);
			ifx_httpdWrite(wp, sValue);
		}
	} else if (!gstrcmp(name, T("op_rate"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_OP_RATE",
		     sValue) == 1) {
			nSelIdx = gatoi(sValue);

			for (i = 0;
			     i <
			     sizeof(web_Enum_OPRateMode_List) /
			     sizeof(CGI_ENUMSEL_S); i++) {
				if (i == nSelIdx) {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t\t<option value=\"%d\" SELECTED>%s</option>\n"),
						       i,
						       web_Enum_OPRateMode_List
						       [i].str);
				} else {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t\t<option value=\"%d\">%s</option>\n"),
						       i,
						       web_Enum_OPRateMode_List
						       [i].str);
				}
			}
		}
	} else if (!gstrcmp(name, T("preamble"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_PREAMBLE",
		     sValue) == 1) {
			nSelIdx = gatoi(sValue);

			for (i = 1;
			     i <
			     sizeof(web_Enum_PreambleMode_List) /
			     sizeof(CGI_ENUMSEL_S); i++) {
				if (i == nSelIdx) {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t\t<option value=\"%d\" SELECTED>%s</option>\n"),
						       i,
						       web_Enum_PreambleMode_List
						       [i].str);
				} else {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t\t<option value=\"%d\">%s</option>\n"),
						       i,
						       web_Enum_PreambleMode_List
						       [i].str);
				}
			}
		}
	} else if (!gstrcmp(name, T("beacon_interval"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_BEACON_INTERVAL",
		     sValue) == 1) {
			ifx_httpdWrite(wp, sValue);
		}
	} else if (!gstrcmp(name, T("rts"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_RTS", sValue)
		    == 1) {
			ifx_httpdWrite(wp, sValue);
		}
	} else if (!gstrcmp(name, T("fts"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_FTS", sValue)
		    == 1) {
			ifx_httpdWrite(wp, sValue);
		}
	}

	return 0;
}

// wireless_security.asp
CGI_ENUMSEL_S web_Enum_EncryType_List[] = {
	{
	 0, " "}
	, {
	   WLAN_ENCRY_NONE, "No Encription"}
	, {
	   WLAN_ENCRY_WEP64, "WEP 64  (10 digits)"}
	, {
	   WLAN_ENCRY_WEP128, "WEP 128 (26 digits)"}
	, {
	   WLAN_ENCRY_1X, "Standard 802.1X (WEP)"}
	, {
	   WLAN_ENCRY_TKIP, "TKIP"}
	, {
	   WLAN_ENCRY_AES, "AES"}
	, {
	   WLAN_ENCRY_TKIP_AES, "TKIP/AES"}
	,
};

CGI_ENUMSEL_S web_Enum_AuthType_List[] = {
	{
	 0, " "}
	, {
	   WLAN_AUTH_OPEN, "Open authentication"}
	, {
	   WLAN_AUTH_SHARED, "Shared authentication"}
	, {
	   WLAN_AUTH_SWITCH, "Auto Switch"}
	, {
	   WLAN_AUTH_WPA, "WPA-TLS"}
	, {
	   WLAN_AUTH_PSK, "WPA-PSK"}
	, {
	   WLAN_AUTH_WPA2, "WPA2-TLS"}
	, {
	   WLAN_AUTH_PSK2, "WPA2-PSK"}
	,
};

CGI_ENUMSEL_S web_Enum_KeyUsed_List[] = {
	{
	 0, "None"}
	, {
	   1, "Key 1"}
	, {
	   2, "Key 2"}
	, {
	   3, "Key 3"}
	, {
	   4, "Key 4"}
	,
};

CGI_ENUMSEL_S web_Enum_PSK_Password[] = {
	{
	 0, "PSK"}
	, {
	   1, "PassPhrase"}
	,
};

CGI_ENUMSEL_S web_Enum_1x_key[] = {
	{
	 0, "64 bits"}
	, {
	   1, "128 bits"}
	,
};
int ifx_get_wlan_security(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name, sValue[MAX_FILELINE_LEN];
	int i, nSelIdx = 0;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	sValue[0] = '\0';

	if (!gstrcmp(name, T("EncryType"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_ENCRY_TYPE",
		     sValue) == 1) {
			nSelIdx = gatoi(sValue);

			for (i = 1;
			     i <
			     sizeof(web_Enum_EncryType_List) /
			     sizeof(CGI_ENUMSEL_S); i++) {
				if (i == nSelIdx) {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t<option value=\"%d\" SELECTED>%s</option>\n"),
						       i,
						       web_Enum_EncryType_List
						       [i].str);
				} else {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t<option value=\"%d\">%s</option>\n"),
						       i,
						       web_Enum_EncryType_List
						       [i].str);
				}
			}
		}
	} else if (!gstrcmp(name, T("AuthType"))
		   || !gstrcmp(name, T("authindex"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_AUTH_TYPE",
		     sValue) == 1) {
			nSelIdx = gatoi(sValue);

			if (!gstrcmp(name, T("authindex"))) {
				ifx_httpdWrite(wp, "%d", nSelIdx);
				return 0;
			}
			for (i = 1;
			     i <
			     sizeof(web_Enum_AuthType_List) /
			     sizeof(CGI_ENUMSEL_S); i++) {
				if (i == nSelIdx) {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t<option value=\"%d\" SELECTED>%s</option>\n"),
						       i,
						       web_Enum_AuthType_List
						       [i].str);
				} else {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t<option value=\"%d\">%s</option>\n"),
						       i,
						       web_Enum_AuthType_List
						       [i].str);
				}
			}
		}
	} else if (!gstrcmp(name, T("KeyUsed"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_KEY_USED",
		     sValue) == 1) {
			nSelIdx = gatoi(sValue);

			for (i = 0;
			     i <
			     sizeof(web_Enum_KeyUsed_List) /
			     sizeof(CGI_ENUMSEL_S); i++) {
				if (i == nSelIdx) {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t<option value=\"%d\" SELECTED>%s</option>\n"),
						       i,
						       web_Enum_KeyUsed_List[i].
						       str);
				} else {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t<option value=\"%d\">%s</option>\n"),
						       i,
						       web_Enum_KeyUsed_List[i].
						       str);
				}
			}
		}
	} else if (!gstrcmp(name, T("Key1"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_KEY1", sValue)
		    == 1) {
			if (strlen(sValue) != 1)
				ifx_httpdWrite(wp, sValue);
			else
				ifx_httpdWrite(wp, "");

		}
	} else if (!gstrcmp(name, T("Key2"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_KEY2", sValue)
		    == 1) {
			if (strlen(sValue) != 1)
				ifx_httpdWrite(wp, sValue);
			else
				ifx_httpdWrite(wp, "");
		}
	} else if (!gstrcmp(name, T("Key3"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_KEY3", sValue)
		    == 1) {
			if (strlen(sValue) != 1)
				ifx_httpdWrite(wp, sValue);
			else
				ifx_httpdWrite(wp, "");
		}
	} else if (!gstrcmp(name, T("Key4"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_KEY4", sValue)
		    == 1) {
			if (strlen(sValue) != 1)
				ifx_httpdWrite(wp, sValue);
			else
				ifx_httpdWrite(wp, "");
		}
	} else if (!gstrcmp(name, T("IsPassPhrase"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, T("WLAN_ISPASSPHRASE"),
		     sValue) == 1) {
			nSelIdx = gatoi(sValue);
			if (nSelIdx == 1)
				ifx_httpdWrite(wp, T("checked"));
			else if (nSelIdx == 0)
				ifx_httpdWrite(wp, T(""));
		}
	} else if (!gstrcmp(name, T("GKeyEnable"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_GKEY_ENABLE",
		     sValue) == 1) {
			if (!gstrcmp(sValue, "1")) {
				ifx_httpdWrite(wp, "checked");
			} else {
				ifx_httpdWrite(wp, "");
			}
		}
	} else if (!gstrcmp(name, T("GKeyRenew"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_GKEY_RENEWAL",
		     sValue) == 1)
			ifx_httpdWrite(wp, sValue);
		else
			ifx_httpdWrite(wp, "3600");
	} else if (!gstrcmp(name, T("PSK"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_PSK", sValue)
		    == 1) {
			if (strlen(sValue) != 1)
				ifx_httpdWrite(wp, sValue);
			else
				ifx_httpdWrite(wp, "");
		}
	} else if (!gstrcmp(name, T("P1x_key_len"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_8021X_KEYLEN",
		     sValue) == 1) {
			nSelIdx = gatoi(sValue);
			for (i = 0;
			     i <
			     sizeof(web_Enum_1x_key) / sizeof(CGI_ENUMSEL_S);
			     i++) {
				if (i == nSelIdx) {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t<option value=\"%d\" SELECTED>%s</option>\n"),
						       i,
						       web_Enum_1x_key[i].str);
				} else {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t<option value=\"%d\">%s</option>\n"),
						       i,
						       web_Enum_1x_key[i].str);
				}
			}
		}
	} else if (!gstrcmp(name, T("radius_port"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_RADIUS_SERVER_PORT",
		     sValue) == 1) {
			ifx_httpdWrite(wp, sValue);
		}
	} else if (!gstrcmp(name, T("radius_secret"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY,
		     "WLAN_RADIUS_SERVER_SECRET", sValue) == 1) {
			ifx_httpdWrite(wp, sValue);
		}
	} else if (!gstrcmp(name, T("Nas_iden"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_NAS_ID",
		     sValue) == 1) {
			ifx_httpdWrite(wp, sValue);
		}
	} else if (!gstrcmp(name, T("GKeyRenew"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_GKEY_RENEWAL",
		     sValue) == 1)
			ifx_httpdWrite(wp, sValue);
		else
			ifx_httpdWrite(wp, "3600");
	} else if (!gstrcmp(name, T("PSK"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_PSK", sValue)
		    == 1) {
			if (strlen(sValue) != 1)
				ifx_httpdWrite(wp, sValue);
			else
				ifx_httpdWrite(wp, "");
		}
	}
	return 0;
}

int ifx_get_radius_ip(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_DATA_LEN];
	char_t *name;
	char_t *delim = ". \n\t";
	char_t *ipaddr1, *ipaddr2, *ipaddr3, *ipaddr4;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_WLAN_SECURITY, T("WLAN_RADIUS_SERVER_IP"),
	     sValue) == 1) {
		ipaddr1 = strtok(sValue, delim);
		ipaddr2 = strtok(NULL, delim);
		ipaddr3 = strtok(NULL, delim);
		ipaddr4 = strtok(NULL, delim);

		if (!gstrcmp(name, T("radius_IP1"))) {
			ifx_httpdWrite(wp, T("%s"), ipaddr1);
		} else if (!gstrcmp(name, T("radius_IP2"))) {
			ifx_httpdWrite(wp, T("%s"), ipaddr2);
		} else if (!gstrcmp(name, T("radius_IP3"))) {
			ifx_httpdWrite(wp, T("%s"), ipaddr3);
		} else if (!gstrcmp(name, T("radius_IP4"))) {
			ifx_httpdWrite(wp, T("%s"), ipaddr4);
		}
	} else {
		ifx_httpdError(wp, 204, T("Config file not found"));
		return -1;
	}

	return 0;
}
#endif				// CONFIG_FEATURE_IFX_WIRELESS_ATH

#ifdef CONFIG_FEATURE_IFX_WIRELESS_TSC

char8 wlan_beacon[][32] = {
	{
	 "WLAN_BEACON_BASIC"}
	, {
	   "WLAN_BEACON_WPA"}
	, {
	   "WLAN_BEACON_WPA2"}
	, {
	   "WLAN_BEACON_WPA_WPA2"}
};

char8 wlan_beacon_type[][32] = {
	{
	 "WLAN_BEACON_BASIC"}
	, {
	   "WLAN_BEACON_WPA"}
};

char8 wlan_encr_type[][32] = {
	{
	 "None"}
	, {
	   "WEP"}
	, {
	   "TKIP"}
	, {
	   "AES"}
};

char8 wlan_key_index[][32] = {
	{
	 "Key1"}
	, {
	   "Key2"}
	, {
	   "Key3"}
	, {
	   "Key4"}
};

char8 wlan_encr_lvl[][32] = {
	{
	 "64-bit"}
	, {
	   "128-bit"}
};

char8 wlan_key_type[][32] = {
	{
	 "ASCII Key"}
	, {
	   "HEX Key"}
};
char8 wlan_auth_type[][32] = {
	{
	 "Open Authentication"}
	, {
	   "Shared Authentication"}
	, {
	   "WPA-Enterprise"}
	, {
	   "WPS-Personal"}
	, {
	   "WPA2-Enterprise"}
	, {
	   "WPA2-Personal"}
};

/* Pramod - need clarification from TSC as to what are the country settings they are supporting */
#if 0
char8 wlan_country[][32] = {
	{
	 "U S"}
	, {
	   "JAPAN"}
};
#else
char8 wlan_country[][32] = {
	{
	 "INDIA"}
	, {
	   "U S"}
	, {
	   "EUROPE"}
	, {
	   "JAPAN"}
	, {
	   "IC"}
	, {
	   "FRA"}
};
#endif

#ifdef CONFIG_FEATURE_IFX_WIRELESS_TSC
int32 wlan_country_enum[IFX_MAX_WLAN_COUNTRIES] = {
	WLAN_COUNTRY_IND, WLAN_COUNTRY_US, WLAN_COUNTRY_ETSI, WLAN_COUNTRY_JAPAN
};

char8 wlan_power_level[][32] = {
	{
	 "WLAN_POWER_LEVEL_20"}
	, {
	   "WLAN_POWER_LEVEL_40"}
	, {
	   "WLAN_POWER_LEVEL_60"}
	, {
	   "WLAN_POWER_LEVEL_80"}
	, {
	   "WLAN_POWER_LEVEL_100"}
};
char8 wlan_bit_rates[][32] = {
	{
	 "Auto"}
	, {
	   "1 Mb/s"}
	, {
	   "2 Mb/s"}
	, {
	   "5.5 Mb/s"}
	, {
	   "11 Mb/s"}
};

char8 wlan_preamble[][32] = {
	{
	 "WLAN_PREAMBLE_NONE"}
	, {
	   "WLAN_PREAMBLE_SHORT"}
	, {
	   "WLAN_PREAMBLE_LONG"}
	, {
	   "WLAN_PREAMBLE_AUTO"}

};
int
ifx_get_wireless_channel_length(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int32 ret = IFX_SUCCESS;
	char8 *name;
	WLAN_COUNTRY country;
	WLAN_STANDARD mode;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	if (!gstrcmp(name, T("US-A"))) {
		country = WLAN_COUNTRY_US;
		mode = WLAN_STD_802_11A;
	} else if (!gstrcmp(name, T("ETSI-A"))) {
		country = WLAN_COUNTRY_ETSI;
		mode = WLAN_STD_802_11A;
	} else if (!gstrcmp(name, T("JAPAN-A"))) {
		country = WLAN_COUNTRY_JAPAN;
		mode = WLAN_STD_802_11A;
	}

	if (!gstrcmp(name, T("US-B"))) {
		country = WLAN_COUNTRY_US;
		mode = WLAN_STD_802_11B;
	} else if (!gstrcmp(name, T("ETSI-B"))) {
		country = WLAN_COUNTRY_ETSI;
		mode = WLAN_STD_802_11B;
	} else if (!gstrcmp(name, T("JAPAN-B"))) {
		country = WLAN_COUNTRY_JAPAN;
		mode = WLAN_STD_802_11B;
	}

	ret = ifx_get_wlan_channel_list_len(country, mode);
	ifx_httpdWrite(wp, T("%d"), ret);
}

int ifx_get_wireless_settings(int eid, httpd_t wp, int argc, char_t ** argv)
{
	WLAN_COMMON_CFG wlan_cmn;
	WLAN_CHANNEL_LIST wlan_chan;
	int32 ret = IFX_SUCCESS;
	uint32 i = 0, flags = IFX_F_DEFAULT, j = 0;
	char8 *name, var_name[MAX_FILELINE_LEN];

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	memset(&wlan_cmn, 0, sizeof(WLAN_COMMON_CFG));
	memset(&wlan_chan, 0, sizeof(WLAN_CHANNEL_LIST));

	if ((ret = ifx_get_wlan_common_config(&wlan_cmn, flags)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400,
			       T("Failed to get wlan common config\n"));
		return ret;
	}

	if (!gstrcmp(name, T("WLAN_ENABLE"))) {
		if (wlan_cmn.RadioEnable)
			ifx_httpdWrite(wp, T("checked"));
		else
			ifx_httpdWrite(wp, T(""));

	} else if (!gstrcmp(name, T("BEACON_INT"))) {
		ifx_httpdWrite(wp, T("%d"), wlan_cmn.beaconIntvl);

	} else if (!gstrcmp(name, T("OPER_MODE"))) {
		switch (wlan_cmn.mode) {
		case 0:
			ifx_httpdWrite(wp, T("0"));
			break;
#ifdef WLAN_802_11A_SUPPORTED
		case 1:
			ifx_httpdWrite(wp, T("1"));
			break;
#endif				// WLAN_802_11A_SUPPORTED
		case 2:
			ifx_httpdWrite(wp, T("2"));
			break;
		default:
			ifx_httpdWrite(wp, T("0"));
			break;
		}
	} else if (!gstrcmp(name, T("COUNTRY"))) {
		for (i = 0; i < IFX_MAX_WLAN_COUNTRIES; i++) {	/* Pramod - need
								   clarification from
								   TSC as to what are
								   the country settings 
								   they are supporting */
			ifx_httpdWrite(wp, T("<option value='%d' "),
				       wlan_country_enum[i]);
			if (wlan_cmn.country == wlan_country_enum[i]) {
				ifx_httpdWrite(wp, T("%s"), "selected");
			}
			ifx_httpdWrite(wp, T(">%s"), wlan_country[i]);
		}

	} else if (!gstrcmp(name, T("CHANNEL"))) {
#if 0
		ifx_httpdWrite(wp, T("<option value='0' selected>Auto"));
#else
		/* channel list depends on country & mode */
		wlan_chan.mode = wlan_cmn.mode;
		wlan_chan.country = wlan_cmn.country;
		if ((ret =
		     ifx_get_wlan_ChannelList(&wlan_chan,
					      flags)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       T("Failed to get channel list\n"));
			return ret;
		}

		for (i = 0; i < wlan_chan.length; i++) {
			ifx_httpdWrite(wp, T("<option value='%d' "),
				       wlan_chan.ChannelList[i]);
			if (wlan_cmn.apChannelId == wlan_chan.ChannelList[i]) {
				ifx_httpdWrite(wp, T("%s"), "selected");
			}
			ifx_httpdWrite(wp, T(">Channel-%d"),
				       wlan_chan.ChannelList[i]);
		}
#endif				// 0
	} else if (!gstrcmp(name, T("POWER_LEVEL"))) {
		for (i = 0; i < IFX_MAX_WLAN_POWER_LEVELS; i++) {
			ifx_httpdWrite(wp, T("<option value='%d' "), i);
			if (wlan_cmn.PowerLvl == i) {
				ifx_httpdWrite(wp, T("%s"), "selected");
			}
			ifx_httpdWrite(wp, T(">%s"), wlan_power_level[i]);
		}

	} else if (!gstrcmp(name, T("CHANNEL_LIST"))) {
		/* write supported channel list for all the supported countries */
#ifdef WLAN_802_11A_SUPPORTED
		for (i = 0; i < IFX_MAX_WLAN_COUNTRIES; i++) {
			memset(&wlan_chan, 0x00, sizeof(wlan_chan));
			wlan_chan.country = wlan_country_enum[i];
			wlan_chan.mode = WLAN_STD_802_11A;
			if ((ret =
			     ifx_get_wlan_ChannelList(&wlan_chan,
						      IFX_F_DEFAULT)) !=
			    IFX_SUCCESS) {
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to get channel list\n"));
				return ret;
			}
			switch (wlan_chan.country) {
			case WLAN_COUNTRY_IND:
				sprintf(var_name, "%s", "ind_ch_modeA");
				break;
			case WLAN_COUNTRY_US:
				sprintf(var_name, "%s", "us_ch_modeA");
				break;
			case WLAN_COUNTRY_ETSI:
				sprintf(var_name, "%s", "etsi_ch_modeA");
				break;
			case WLAN_COUNTRY_JAPAN:
				sprintf(var_name, "%s", "jpn_ch_modeA");
				break;
			}
			for (j = 0; j < wlan_chan.length; j++)
				ifx_httpdWrite(wp, T("%s[%d]=\"%d\";\n"),
					       var_name, j,
					       wlan_chan.ChannelList[j]);
		}
#endif				// WLAN_802_11A_SUPPORTED

		for (i = 0; i < IFX_MAX_WLAN_COUNTRIES; i++) {
			memset(&wlan_chan, 0x00, sizeof(wlan_chan));
			wlan_chan.country = wlan_country_enum[i];
			wlan_chan.mode = WLAN_STD_802_11B;
			if ((ret =
			     ifx_get_wlan_ChannelList(&wlan_chan,
						      IFX_F_DEFAULT)) !=
			    IFX_SUCCESS) {
				ifx_httpdError(wp, 400,
					       T
					       ("Failed to get channel list\n"));
				return ret;
			}
			switch (wlan_chan.country) {
			case WLAN_COUNTRY_IND:
				sprintf(var_name, "%s", "ind_ch_modeB");
				break;
			case WLAN_COUNTRY_US:
				sprintf(var_name, "%s", "us_ch_modeB");
				break;
			case WLAN_COUNTRY_ETSI:
				sprintf(var_name, "%s", "etsi_ch_modeB");
				break;
			case WLAN_COUNTRY_JAPAN:
				sprintf(var_name, "%s", "jpn_ch_modeB");
				break;
			}
			for (j = 0; j < wlan_chan.length; j++)
				ifx_httpdWrite(wp, T("%s[%d]=\"%d\";\n"),
					       var_name, j,
					       wlan_chan.ChannelList[j]);
		}

		/* for japan in 802_11BG mode */
		memset(&wlan_chan, 0x00, sizeof(wlan_chan));
		wlan_chan.country = WLAN_COUNTRY_JAPAN;
		wlan_chan.mode = WLAN_STD_802_11BG;
		if ((ret =
		     ifx_get_wlan_ChannelList(&wlan_chan,
					      IFX_F_DEFAULT)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       T("Failed to get channel list\n"));
			return ret;
		}
		sprintf(var_name, "%s", "jpn_ch_modeBG");
		for (j = 0; j < wlan_chan.length; j++)
			ifx_httpdWrite(wp, T("%s[%d]=\"%d\";\n"), var_name, j,
				       wlan_chan.ChannelList[j]);
	}

	return ret;

}

int
ifx_get_all_wireless_ap_settings(int eid, httpd_t wp, int argc, char_t ** argv)
{
	WLAN_MAIN_CFG *wlan_main;
	int32 ret = IFX_SUCCESS, flags = IFX_F_DEFAULT;
	uint32 numEntries = 0, i = 0;
	char8 *name;

	if ((ret =
	     ifx_get_all_wlan_main_config(&numEntries, &wlan_main,
					  flags)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400,
			       T("Failed to get all wlan main config\n"));
		return ret;
	}
	for (i = 0; i < numEntries; i++) {

		ifx_httpdWrite(wp, T("<tr bgcolor='#ffffff' align='center' height='30'>"));	/* opening 
												   a 
												   row 
												 */
		ifx_httpdWrite(wp,
			       T
			       ("<td><input type='radio' name='slno' value=%d></td>"),
			       (i + 1));
		ifx_httpdWrite(wp, T("<td><input name='new_ssid%d' value=\"%s\">"), (i + 1), (wlan_main + i)->SSID);	/* each 
															   column 
															   in 
															   the 
															   row 
															 */
		ifx_httpdWrite(wp,
			       T
			       ("<input type='hidden' name='old_ssid%d' value=\"%s\"></td>"),
			       (i + 1), (wlan_main + i)->SSID);
		ifx_httpdWrite(wp, T("<td>%s</td>"), (wlan_main + i)->bssid);
#if 1				// Pramod : just display type as AP since we
		// have support for only 1 AP configuration

		ifx_httpdWrite(wp, T("<td>AP</td>"));
#endif				// 0
		ifx_httpdWrite(wp,
			       T
			       ("<td><input type='checkbox' name='apEna%d' value='1' %s><td>"),
			       (i + 1),
			       ((wlan_main + i)->apEnable ==
				IFX_ENABLED) ? "checked" : "");
		ifx_httpdWrite(wp, T("</tr>"));	/* closing a row */
	}
	IFX_MEM_FREE(wlan_main);
	return ret;
}

int
ifx_get_advanced_wireless_settings(int eid, httpd_t wp, int argc,
				   char_t ** argv)
{
	WLAN_MAIN_CFG *wlan_main;
	int32 ret = IFX_SUCCESS, flags = IFX_F_DEFAULT;
	uint32 i = 0, j = 0, numEntries = 0;
	char8 *pValue, *name;
	char8 t_buf1[MAX_FILELINE_LEN];
	char8 t_buf2[MAX_FILELINE_LEN];
	char8 t_rate1[MAX_FILELINE_LEN];
	char8 t_rate2[MAX_FILELINE_LEN];

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	if ((ret =
	     ifx_get_all_wlan_main_config(&numEntries, &wlan_main,
					  flags)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400,
			       T("Failed to get all wlan main config\n"));
		return ret;
	}

	if (!gstrcmp(name, T("SSID_LIST"))) {
		for (i = 0; i < numEntries; i++) {
			ifx_httpdWrite(wp, T("<option value='%s' %s "),
				       (wlan_main + i)->SSID,
				       i == 0 ? "selected" : "");
			ifx_httpdWrite(wp, T(">%s"), (wlan_main + i)->SSID);
		}
	} else if (!gstrcmp(name, T("SSID_CHANGE"))) {
		pValue = ifx_httpdGetVar(wp, T("ssid"), T(""));
		for (i = 0; i < numEntries; i++) {
			if (!gstrcmp(pValue, (wlan_main + i)->SSID)) {
				ifx_httpdWrite(wp, T("t_arf=%d;\n"),
					       (wlan_main +
						i)->autoRateFallBackEnable);
				ifx_httpdWrite(wp, T("t_apiso=%d;\n"),
					       (wlan_main + i)->apIsolation);
				j = 0;
				while ((wlan_main + i)->basicDataRates[j] != 0) {
					sprintf(t_buf1, ("%f,"),
						(wlan_main +
						 i)->basicDataRates[j]);
					strcat(t_rate1, t_buf1);
					j++;
				}
				t_rate1[strlen(t_rate1) - 1] = '\0';	/* remove the last ',' */
				ifx_httpdWrite(wp, T("t_basicdr=\"%s\";\n"),
					       t_rate1);
				j = 0;
				while ((wlan_main +
					i)->operationalDataRates[j] != 0) {
					sprintf(t_buf2, ("%f,"),
						wlan_main->
						operationalDataRates[j]);
					strcat(t_rate2, t_buf2);
					i++;
				}
				t_rate2[strlen(t_rate2) - 1] = '\0';	/* remove the last ',' */
				ifx_httpdWrite(wp, T("t_operdr=\"%s\";\n"),
					       t_rate2);

				ifx_httpdWrite(wp, T("t_bitrate=%d;\n"),
					       (wlan_main + i)->maxBitRate);
				ifx_httpdWrite(wp, T("t_preamb=%d;\n"),
					       (wlan_main + i)->preamble);
				ifx_httpdWrite(wp, T("t_rts=%d;\n"),
					       (wlan_main + i)->rts);
				ifx_httpdWrite(wp, T("t_fts=%d;\n"),
					       (wlan_main + i)->fts);
			}
		}
	} else if (!gstrcmp(name, T("ARF"))) {
		if ((wlan_main + 0)->autoRateFallBackEnable)
			ifx_httpdWrite(wp, T("checked"));
		else
			ifx_httpdWrite(wp, T(""));
	} else if (!gstrcmp(name, T("AP_ISOLATION"))) {
		switch ((wlan_main + 0)->apIsolation) {
		case 0:
			ifx_httpdWrite(wp, T("0"));
			break;
		case 1:
			ifx_httpdWrite(wp, T("1"));
			break;
		default:
			ifx_httpdWrite(wp, T("0"));
			break;

		}
	} else if (!gstrcmp(name, T("BASIC_DATA_RATE"))) {
		i = 0;
		while ((wlan_main + 0)->basicDataRates[i] != 0) {
			ifx_httpdWrite(wp, T("%2.1f,"),
				       (wlan_main + 0)->basicDataRates[i]);
			i++;
		}
	} else if (!gstrcmp(name, T("OPER_DATA_RATE"))) {
		i = 0;
		while ((wlan_main + 0)->operationalDataRates[i] != 0) {
			ifx_httpdWrite(wp, T("%2.1f,"),
				       (wlan_main +
					0)->operationalDataRates[i]);
			i++;
		}
	} else if (!gstrcmp(name, T("MAX_BIT_RATE"))) {
		if ((wlan_main + 0)->maxBitRate ==
		    IFX_MAPI_WLAN_AUTO_MAXBITRATE)
			ifx_httpdWrite(wp,
				       T("<option value='%2.1f' selected>Auto"),
				       IFX_MAPI_WLAN_AUTO_MAXBITRATE);
		else
			ifx_httpdWrite(wp, T("<option value='%2.1f'>Auto"),
				       IFX_MAPI_WLAN_AUTO_MAXBITRATE);
		i = 0;
		while ((wlan_main + 0)->operationalDataRates[i] != 0) {
			ifx_httpdWrite(wp, T("<option value='%2.1f' "),
				       (wlan_main +
					0)->operationalDataRates[i]);
			if ((wlan_main + 0)->maxBitRate ==
			    (wlan_main + 0)->operationalDataRates[i])
				ifx_httpdWrite(wp, T("%s"), "selected");
			ifx_httpdWrite(wp, T(">%2.1f"),
				       (wlan_main +
					0)->operationalDataRates[i]);
			i++;
		}
	} else if (!gstrcmp(name, T("PRE_AMB_MODE"))) {
		for (i = 0; i < IFX_MAX_WLAN_PREAMBLE_MODES; i++) {
			ifx_httpdWrite(wp, T("<option value='%d' "), i);
			if ((wlan_main + 0)->preamble == i) {
				ifx_httpdWrite(wp, T("%s"), "selected");
			}
			ifx_httpdWrite(wp, T(">%s"), wlan_preamble[i]);
		}
	} else if (!gstrcmp(name, T("RTS_THRESHOLD"))) {
		ifx_httpdWrite(wp, T("%d"), (wlan_main + 0)->rts);
	} else if (!gstrcmp(name, T("FTS_THRESHOLD"))) {
		ifx_httpdWrite(wp, T("%d"), (wlan_main + 0)->fts);
	}
	IFX_MEM_FREE(wlan_main);
	return ret;
}

int
ifx_get_wireless_security_settings(int eid, httpd_t wp, int argc,
				   char_t ** argv)
{
	WLAN_SEC_CFG wlan_sec;
	WLAN_MAIN_CFG *wlan_main;
	WLAN_WEP_KEY wepKey[IFX_MAX_WLAN_WEP_KEYS];
	WLAN_PSK psk;
	int32 ret = IFX_SUCCESS, flags = IFX_F_DEFAULT;
	uint32 numEntries = 0, i = 0;
	char8 *name;
	char_t sValue[MAX_FILELINE_LEN];

	sValue[0] = '\0';
	memset(&wlan_sec, 0, sizeof(WLAN_SEC_CFG));
	memset(&wepKey, 0x00, sizeof(wepKey));
	memset(&psk, 0x00, sizeof(psk));

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	if (!gstrcmp(name, T("SSID_LIST"))) {
		if ((ret =
		     ifx_get_all_wlan_main_config(&numEntries, &wlan_main,
						  flags)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       T
				       ("Failed to get all wlan main config\n"));
			return ret;
		}
		for (i = 0; i < numEntries; i++) {
			ifx_httpdWrite(wp, T("<option value='%s' %s "),
				       (wlan_main + i)->SSID,
				       i == 0 ? "selected" : "");
			ifx_httpdWrite(wp, T(">%s"), (wlan_main + i)->SSID);
		}
	} else {
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_WLAN_MAIN, "wlanmn_0_ssid",
		     IFX_F_DEFAULT, NULL, sValue) != IFX_SUCCESS) {
			ifx_httpdWrite(wp,
				       T("Failed to get ssid from rc.conf!!"));
			return;
		}
		sprintf(wlan_sec.iid.cpeId.secName, "%s", TAG_WLAN_SEC);
		sprintf(wlan_sec.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

		if (ifx_get_iid_from_ssid(sValue, &wlan_sec.iid) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to get security info for this ssid");
			return -1;
		}
		if ((ret =
		     ifx_get_wlan_security_config(&wlan_sec,
						  flags)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       T
				       ("Failed to get wlan security config\n"));
			return ret;
		}

		if (!gstrcmp(name, T("BEACON_TYPE"))) {
			for (i = 0; i < IFX_MAX_WLAN_BEACON_TYPE; i++) {
				ifx_httpdWrite(wp, T("<option value='%d' "), i);
				if (wlan_sec.beaconType == i) {
					ifx_httpdWrite(wp, T("%s"), "selected");
				}
				ifx_httpdWrite(wp, T(">%s"),
					       wlan_beacon_type[i]);
			}
		} else if (!gstrcmp(name, T("AUTH_TYPE"))) {
			for (i = 0; i < IFX_MAX_WLAN_AUTH_TYPE; i++) {
				ifx_httpdWrite(wp, T("<option value='%d' "), i);
				if (wlan_sec.wlan_auth == i) {
					ifx_httpdWrite(wp, T("%s"), "selected");
				}
				ifx_httpdWrite(wp, T(">%s"), wlan_auth_type[i]);
			}
		} else if (!gstrcmp(name, T("ENCR_TYPE"))) {
			for (i = 0; i < IFX_MAX_WLAN_ENCR_TYPE; i++) {
				ifx_httpdWrite(wp, T("<option value='%d' "), i);
				if (wlan_sec.wlan_encr == i) {
					ifx_httpdWrite(wp, T("%s"), "selected");
				}
				ifx_httpdWrite(wp, T(">%s"), wlan_encr_type[i]);
			}
		} else if (!gstrcmp(name, T("KEY_INDEX"))) {
			for (i = 0; i < IFX_MAX_WLAN_KEY_INDEX; i++) {
				ifx_httpdWrite(wp, T("<option value='%d' "), i);
				if (wlan_sec.keyIndex == i) {
					ifx_httpdWrite(wp, T("%s"), "selected");
				}
				ifx_httpdWrite(wp, T(">%s"), wlan_key_index[i]);
			}
		} else if (!gstrcmp(name, T("ENCR_LVL"))) {
			for (i = 0; i < IFX_MAX_WLAN_ENCR_LVL; i++) {
				ifx_httpdWrite(wp, T("<option value='%d' "), i);
				if (wlan_sec.wepEncrLvl == i) {
					ifx_httpdWrite(wp, T("%s"), "selected");
				}
				ifx_httpdWrite(wp, T(">%s"), wlan_encr_lvl[i]);
			}
		} else if (!gstrcmp(name, T("WEP_KEY_TYPE"))) {
			for (i = 0; i < IFX_MAX_WLAN_KEY_TYPE; i++) {
				ifx_httpdWrite(wp, T("<option value='%d' "), i);
				if (wlan_sec.wepKeyType == i) {
					ifx_httpdWrite(wp, T("%s"), "selected");
				}
				ifx_httpdWrite(wp, T(">%s"), wlan_key_type[i]);

			}
		} else if (!gstrcmp(name, T("PSK_KEY_TYPE"))) {
			for (i = 0; i < IFX_MAX_WLAN_KEY_TYPE; i++) {
				ifx_httpdWrite(wp, T("<option value='%d' "), i);
				if (wlan_sec.pskKeyType == i) {
					ifx_httpdWrite(wp, T("%s"), "selected");
				}
				ifx_httpdWrite(wp, T(">%s"), wlan_key_type[i]);

			}
		} else if (!gstrcmp(name, T("WLAN_KEY1"))) {
			wepKey[0].iid.pcpeId.Id = wlan_sec.iid.cpeId.Id;
			if (ifx_get_wlan_wep_config
			    (0, &wepKey[0], IFX_F_DEFAULT) != IFX_SUCCESS) {
				ifx_httpdError(wp, 400,
					       "Failed to get info of wep keys");
				return ret;
			}
			/* convert hex key to ascii since we store in hex format */
			memset(sValue, 0x00, sizeof(sValue));
			ifx_httpdWrite(wp, T("%s"), wepKey[0].WEP_KEY);
		} else if (!gstrcmp(name, T("WLAN_KEY2"))) {
			wepKey[1].iid.pcpeId.Id = wlan_sec.iid.cpeId.Id;
			if (ifx_get_wlan_wep_config
			    (1, &wepKey[1], IFX_F_DEFAULT) != IFX_SUCCESS) {
				ifx_httpdError(wp, 400,
					       "Failed to get info of wep keys");
				return ret;
			}
			memset(sValue, 0x00, sizeof(sValue));
			ifx_httpdWrite(wp, T("%s"), wepKey[1].WEP_KEY);
		} else if (!gstrcmp(name, T("WLAN_KEY3"))) {
			wepKey[2].iid.pcpeId.Id = wlan_sec.iid.cpeId.Id;
			if (ifx_get_wlan_wep_config
			    (2, &wepKey[2], IFX_F_DEFAULT) != IFX_SUCCESS) {
				ifx_httpdError(wp, 400,
					       "Failed to get info of wep keys");
				return ret;
			}
			memset(sValue, 0x00, sizeof(sValue));
			ifx_httpdWrite(wp, T("%s"), wepKey[2].WEP_KEY);
		} else if (!gstrcmp(name, T("WLAN_KEY4"))) {
			wepKey[3].iid.pcpeId.Id = wlan_sec.iid.cpeId.Id;
			if (ifx_get_wlan_wep_config
			    (3, &wepKey[3], IFX_F_DEFAULT) != IFX_SUCCESS) {
				ifx_httpdError(wp, 400,
					       "Failed to get info of wep keys");
				return ret;
			}
			memset(sValue, 0x00, sizeof(sValue));
			ifx_httpdWrite(wp, T("%s"), wepKey[3].WEP_KEY);
		} else if (!gstrcmp(name, T("WLAN_PASSPHRASE_KEY"))) {
			psk.iid.pcpeId.Id = wlan_sec.iid.cpeId.Id;
			if (ifx_get_wlan_passphrase_config(&psk, IFX_F_DEFAULT)
			    != IFX_SUCCESS) {
				ifx_httpdError(wp, 400,
					       "Failed to get info of wpa passphrase");
				return ret;
			}
			ifx_httpdWrite(wp, T("%s"), psk.passPhrase);
		} else if (!gstrcmp(name, T("WLAN_AUTH_INDEX"))) {
			/* depending on bascon type display selected auth proto */
			switch (wlan_sec.beaconType) {
			case WLAN_BEACON_BASIC:
				switch (wlan_sec.wlan_auth) {
				case WLAN_AUTH_OPEN:
					ifx_httpdWrite(wp, T("%d"), 1);
					break;
				case WLAN_AUTH_SHARED:
					ifx_httpdWrite(wp, T("%d"), 2);
					break;
				default:
					break;
				}
				break;
			case WLAN_BEACON_WPA:
				switch (wlan_sec.wlan_auth) {
				case WLAN_AUTH_WPA_PSK:
					ifx_httpdWrite(wp, T("%d"), 1);
					break;
				case WLAN_AUTH_WPA2_PSK:
					ifx_httpdWrite(wp, T("%d"), 2);
					break;
				default:
					break;
				}
				break;
			default:
				break;
			}
#endif
		} else if (!gstrcmp(name, T("WLAN_ENCR_INDEX"))) {
#if 1
			/* depending on bascon type and auth proto display selected auth
			   proto */
			switch (wlan_sec.beaconType) {
			case WLAN_BEACON_BASIC:
				switch (wlan_sec.wlan_encr) {
				case WLAN_ENCR_NONE:
					ifx_httpdWrite(wp, T("%d"), 1);
					break;
				case WLAN_ENCR_WEP:
					ifx_httpdWrite(wp, T("%d"), 2);
					break;
				default:
					break;
				}
				break;
			case WLAN_BEACON_WPA:
				switch (wlan_sec.wlan_encr) {
				case WLAN_ENCR_TKIP:
					ifx_httpdWrite(wp, T("%d"), 1);
					break;
				case WLAN_ENCR_AES:
					ifx_httpdWrite(wp, T("%d"), 2);
					break;
				default:
					break;
				}
				break;
			default:
				break;
			}
#endif
		}
	}
	return ret;

}

int ifx_get_wireless_dev_assoc(int eid, httpd_t wp, int argc, char_t ** argv)
{
	WLAN_ASSOC *wlan_assoc = NULL;
	int32 ret = IFX_SUCCESS;
	uint32 flags = IFX_F_DEFAULT, numEntries = 0, i = 0;
	char8 sValue[MAX_FILELINE_LEN];

	if ((ret =
	     ifx_get_all_wlan_assoc_devices(&numEntries, &wlan_assoc,
					    flags)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400,
			       "Failed to get info of all wlan associated devices");
		return ret;
	}
	for (i = 0; i < numEntries; i++) {
		ifx_httpdWrite(wp, T("<td><value=\"%s\"></td>"), (wlan_assoc + i)->SSID);	/* each 
												   column 
												   in 
												   the 
												   row 
												 */
		ifx_httpdWrite(wp, T("<td><value=\"%s\"></td>"),
			       (wlan_assoc + i)->macAddress);
		switch ((wlan_assoc + i)->wlanStaAuthState) {
		case 0:
			gstrcpy(sValue, "WLAN_STA_UNAUTHENTICATED");
			break;
		case 1:
			gstrcpy(sValue, "WLAN_STA_AUTHENTICATED");
			break;
		}
		ifx_httpdWrite(wp, T("%s"), sValue);
		switch ((wlan_assoc + i)->wlanStaAssocState) {
		case 0:
			gstrcpy(sValue, "WLAN_STA_UNASSOCIATED");
			break;
		case 1:
			gstrcpy(sValue, "WLAN_STA_ASSOCIATED");
			break;
		}
		ifx_httpdWrite(wp, T("%s"), sValue);
	}
	IFX_MEM_FREE(wlan_assoc);
	return ret;
}

int
ifx_get_wireless_mac_control_status(int eid, httpd_t wp, int argc,
				    char_t ** argv)
{
	WLAN_MAC_CONTROL wlan_mac;
	int32 ret = IFX_SUCCESS;
	uint32 curr_mode = 0, flags = IFX_F_DEFAULT, numEntries = 0, i = 0;
	char8 *name;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	memset(&wlan_mac, 0, sizeof(WLAN_MAC_CONTROL));

	if ((ret =
	     ifx_get_wlan_mac_control_status(&wlan_mac,
					     flags) != IFX_SUCCESS)) {
		ifx_httpdError(wp, 400,
			       "Failed to get wlan mac control status");
		return ret;
	}
	if (!gstrcmp(name, T("DISABLE"))) {
		ifx_httpdWrite(wp, T("%d"), MACADDR_CONTROL_DISABLE);
		curr_mode = MACADDR_CONTROL_DISABLE;
	} else if (!gstrcmp(name, T("ALLOW"))) {
		ifx_httpdWrite(wp, T("%d"), MACADDR_CONTROL_ALLOW);
		curr_mode = MACADDR_CONTROL_ALLOW;
	} else if (!gstrcmp(name, T("DENY"))) {
		ifx_httpdWrite(wp, T("%d"), MACADDR_CONTROL_DENY);
		curr_mode = MACADDR_CONTROL_DENY;
	}

	if (wlan_mac.global_mode == curr_mode) {
		ifx_httpdWrite(wp, T(" checked"));
	}
	return ret;
}

int
ifx_get_all_wireless_mac_ctrl_entries(int eid, httpd_t wp, int argc,
				      char_t ** argv)
{
	WLAN_MAC_CONTROL wlan_mac;
	int32 ret = IFX_SUCCESS;
	uint32 flags = IFX_F_DEFAULT, numEntries = 0, i = 0;
	char_t *name = NULL;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	memset(&wlan_mac, 0, sizeof(WLAN_MAC_CONTROL));
	wlan_mac.macAddrList = NULL;

	if ((ret =
	     ifx_get_all_wlan_mac_controlTbl(&numEntries, &wlan_mac,
					     flags)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to get wlan mac control table");
		return ret;
	}

	if (!gstrcmp(name, "mac_count")) {
		ifx_httpdWrite(wp, T("%d"), numEntries);
	} else if (!gstrcmp(name, "mac_entries")) {
		if (numEntries == 0) {
			ifx_httpdWrite(wp, T("<tr bgcolor='#ffffff'>"));
			ifx_httpdWrite(wp,
				       T
				       ("<td width='100%' colspan='2'><p align='center'>"));
			ifx_httpdWrite(wp,
				       T("No Rules Configured</p></td></tr>"));
		} else {
			for (i = 0; i < numEntries; i++) {
				ifx_httpdWrite(wp, T("<tr bgcolor='#ffffff'>"));	/* open 
											   a
											   row */
				ifx_httpdWrite(wp,
					       T
					       ("<td><input type='hidden' name='cpeId%d' value='%d'>%s</td>"),
					       i,
					       (wlan_mac.macAddrList +
						i)->iid.cpeId.Id,
					       (wlan_mac.macAddrList +
						i)->macAddr);
				ifx_httpdWrite(wp,
					       T
					       ("<td><input type='checkbox' name='rmid%d' value=%d></td>"),
					       i,
					       (wlan_mac.macAddrList +
						i)->iid.cpeId.Id);
				ifx_httpdWrite(wp, T("</tr>"));	/* closing a row */
			}
		}
	}
	IFX_MEM_FREE(wlan_mac.macAddrList);
}
#endif				// CONFIG_FEATURE_IFX_WIRELESS_TSC

#ifdef CONFIG_FEATURE_IFX_WIRELESS_TSC
void ifx_get_wlan_statistics(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name = NULL;
	WLAN_STATS wlan_stats;

	memset(&wlan_stats, 0x00, sizeof(wlan_stats));

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdWrite(wp, T(""));
		return;
	}
	wlan_stats.iid.cpeId.Id = 1;	/* since there is only one ap as of
					   now, hard code the cpeid to 1 */

	if (ifx_get_wlan_stats(&wlan_stats, IFX_F_DEFAULT) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, T("Failed to get wlan statistics\n\n"));
		return;
	}

	if (!gstrcmp(name, "ap_type")) {
		ifx_httpdWrite(wp, T("%s"), "<td>");
#if 1				// Pramod : just display type as AP since we
		// have support for only 1 AP configuration
		ifx_httpdWrite(wp, T("AP"));
#endif				// 0
		ifx_httpdWrite(wp, T("%s"), "</td>");
	} else if (!gstrcmp(name, "tx_stats")) {
		ifx_httpdWrite(wp, T("<td width='25%'>%lu</td>"),
			       wlan_stats.totalPacketsSent);
		ifx_httpdWrite(wp, T("<td width='25%'>0</td>"));
		ifx_httpdWrite(wp, T("<td width='25%'>%lu</td>"),
			       wlan_stats.totalTransmitErrors);
		ifx_httpdWrite(wp, T("<td width='25%'>%lu</td>"),
			       wlan_stats.totalTransmitDrops);
	} else if (!gstrcmp(name, "rx_stats")) {
		ifx_httpdWrite(wp, T("<td width='25%'>%lu</td>"),
			       wlan_stats.totalPacketsReceived);
		ifx_httpdWrite(wp, T("<td width='25%'>0</td>"));
		ifx_httpdWrite(wp, T("<td width='25%'>%lu</td>"),
			       wlan_stats.totalReceiveErrors);
		ifx_httpdWrite(wp, T("<td width='25%'>0</td>"));
	}
}

void
ifx_get_wlan_dev_associations(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int i = 0, count = 0;
	WLAN_ASSOC *wlan_assoc = NULL;

	if (ifx_get_all_wlan_assoc_devices(&count, &wlan_assoc, IFX_F_DEFAULT)
	    != IFX_SUCCESS) {
		ifx_httpdError(wp, 500,
			       T("Failed to get associated device list"));
		return;
	}
	if (count < 1) {
		ifx_httpdWrite(wp, T("</table>"));
		ifx_httpdWrite(wp,
			       T
			       ("<table border='0' cellspacing='1' cellpadding='5' width='80%'>"));
		ifx_httpdWrite(wp,
			       T
			       ("<tr bgcolor='#ffffff'><td align='center'>No Associated Stations Found</td></tr>"));
	} else {
		for (i = 0; i < count; i++) {
			ifx_httpdWrite(wp,
				       T
				       ("<tr align='center' bgcolor='#ffffff'>"));
			ifx_httpdWrite(wp, T("<td width='15%'>%s</td>"),
				       (wlan_assoc + i)->SSID);
			ifx_httpdWrite(wp, T("<td width='15%'>%s</td>"),
				       (wlan_assoc + i)->macAddress);
			ifx_httpdWrite(wp, T("<td width='15%'>%s</td>"),
				       (char_t *) inet_ntoa((wlan_assoc + i)->
							    ipAddress));
			ifx_httpdWrite(wp, T("<td width='15%'>%s</td>"),
				       ((wlan_assoc + i)->wlanStaAuthState ==
					WLAN_STA_AUTHENTICATED) ?
				       "Authenticated" : "Not Authenticated");
			ifx_httpdWrite(wp, T("<td width='15%'>%s</td>"),
				       ((wlan_assoc + i)->wlanStaAssocState ==
					WLAN_STA_ASSOCIATED) ? "Associated" :
				       "Not Associated");
			ifx_httpdWrite(wp, T("</tr>"));
		}
	}

	IFX_MEM_FREE(wlan_assoc)
}
#endif				// CONFIG_FEATURE_IFX_WIRELESS_TSC

#ifdef CONFIG_FEATURE_IFX_WIRELESS_ATH

#define Print_Macro(x)  memset(PrintData,0,500); \
        gsprintf(PrintData, T("echo \" %s \" >>/tmp/Logs "),x); \
        system(PrintData);
void ifx_set_wlan_settings(httpd_t wp, char_t * path, char_t * query)
{

	char_t *pDomain = ifx_httpdGetVar(wp, T("wlan_domain"), T(""));
	char_t *pWlan = ifx_httpdGetVar(wp, T("wlan_enable"), T(""));
	char_t *pChannel = ifx_httpdGetVar(wp, T("channel"), T(""));
	char_t *pHiddenSsid = ifx_httpdGetVar(wp, T("hiddenSsid"), T(""));
	char_t *pESSID = ifx_httpdGetVar(wp, T("essid"), T(""));
	char_t *pAPName = ifx_httpdGetVar(wp, T("nick"), T(""));
	char_t *pOPRate = ifx_httpdGetVar(wp, T("op_rate"), T(""));
	char_t *pCTS = ifx_httpdGetVar(wp, T("cts_mode"), T(""));
	char_t *pPreamble = ifx_httpdGetVar(wp, T("preamble"), T(""));
	char_t *pPowerLevel = ifx_httpdGetVar(wp, T("power_level"), T(""));
	char_t *pDTIM = ifx_httpdGetVar(wp, T("dtim_intval"), T(""));
	char_t *pBeacon = ifx_httpdGetVar(wp, T("beacon_interval"), T(""));
	char_t *pRTS = ifx_httpdGetVar(wp, T("rts"), T(""));
	char_t *pFTS = ifx_httpdGetVar(wp, T("fts"), T(""));
	char_t sChannel[MAX_DATA_LEN], sHiddenSsid[MAX_DATA_LEN],
	    sESSID[MAX_DATA_LEN];
	char_t sAPName[MAX_DATA_LEN], sOPRate[MAX_DATA_LEN];
	char_t sPreamble[MAX_DATA_LEN], sBeacon[MAX_DATA_LEN];
	char_t sRTS[MAX_DATA_LEN], sFTS[MAX_DATA_LEN],
	    sCommand[MAX_FILELINE_LEN];
	char_t sDomain[MAX_DATA_LEN], sWlan[MAX_DATA_LEN];
	char_t sCTS[MAX_DATA_LEN], sPowerLevel[MAX_DATA_LEN],
	    sDTIM[MAX_DATA_LEN];
	char_t sWlan_Command[MAX_FILELINE_LEN];
	ifx_web_convert_string(pESSID);
	ifx_web_convert_string(pAPName);

	if (pChannel[0] == 0 && pBeacon[0] == 0 && pRTS[0] == 0 && pFTS[0] == 0) {
		ifx_httpdError(wp, 500, "Failed to get data form HTML page!\n");
		return;
	}
	// Set to rc.conf file

	gsprintf(sChannel, T("WLAN_CHANNEL=\"%s\"\n"), pChannel);
	gsprintf(sHiddenSsid, T("WLAN_HIDDEN_SSID=\"%d\"\n"),
		 atoi(pHiddenSsid));
	gsprintf(sESSID, T("WLAN_ESSID=\"%s\"\n"), pESSID);
	gsprintf(sAPName, T("WLAN_AP_NAME=\"%s\"\n"), pAPName);
	gsprintf(sOPRate, T("WLAN_OP_RATE=\"%d\"\n"), atoi(pOPRate));
	gsprintf(sPreamble, T("WLAN_PREAMBLE=\"%d\"\n"), atoi(pPreamble));
	gsprintf(sBeacon, T("WLAN_BEACON_INTERVAL=\"%d\"\n"), atoi(pBeacon));
	gsprintf(sRTS, T("WLAN_RTS=\"%d\"\n"), atoi(pRTS));
	gsprintf(sFTS, T("WLAN_FTS=\"%d\"\n"), atoi(pFTS));

	gsprintf(sDomain, T("WLAN_DOMAIN=\"%s\"\n"), pDomain);

	if (pDTIM[0] == 0) {
		ifx_httpdError(wp, 500, "Failed to get data from HTML page!\n");
		return;
	}
	gsprintf(sDTIM, T("WLAN_DTIM_INTERVAL=\"%s\"\n"), pDTIM);

	gsprintf(sCTS, T("WLAN_CTS=\"%s\"\n"), pCTS);

	gsprintf(sPowerLevel, T("WLAN_POWER_LEVEL=\"%s\"\n"), pPowerLevel);

	gsprintf(sCommand, T("ifconfig %s down"), IFX_WLAN_IF);
	system(sCommand);
	gsprintf(sWlan, T("wlan_enable=\"%d\"\n"), atoi(pWlan));

	ifx_SetCfgData1(FILE_RC_CONF, TAG_WLAN_STATUS, IFX_F_MODIFY, 1, sWlan);

	if (atoi(pWlan) == 0) {
		memset(sWlan_Command, 0x00, MAX_FILELINE_LEN);
		gsprintf(sWlan_Command, T("ifconfig %s down"), IFX_WLAN_IF);
		system(sWlan_Command);
		gsprintf(sWlan_Command, T("brctl delif br0 %s"), IFX_WLAN_IF);
		system(sWlan_Command);
		// 6101101:hsur we don't need this anymore
		// 610311:linmars only Amaozn needs it
#ifdef CPU_AMAZON
		system("swreset wireless_down");
#else
		system("/etc/rc.d/rc.bringup_wireless stop");
#endif
	}

	ifx_SetCfgData(FILE_RC_CONF, TAG_WLAN_SETTINGS, 14,
		       "WLAN_debug_LVL=\"0\"\n", sDomain, sChannel,
		       sHiddenSsid, sESSID, sAPName, sOPRate,
		       sPowerLevel, sPreamble, sBeacon, sRTS, sFTS, sDTIM,
		       sCTS);

	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}

	if (atoi(pWlan) == 1) {
		memset(sCommand, 0x00, MAX_FILELINE_LEN);
		gsprintf(sCommand, T("/etc/rc.d/rc.bringup_wireless restart"));
		system(sCommand);
	}
	websNextPage(wp);
}

// wireless_security.asp for AMAZON
int
websGetIPAddress(char_t * Tag, char_t * symbol, int nReqIdx, char_t * pRetValue)
{
	char_t sFullIPValue[MAX_FILELINE_LEN];
	char_t sIpaddr[MAX_DATA_LEN];
	char_t *ip;
	int i = 0;
	int nIndex = 0;

	sFullIPValue[0] = '\0';
	sIpaddr[0] = '\0';
	gstrcpy(pRetValue, "");
	if (ifx_GetCfgData(FILE_RC_CONF, Tag, symbol, sFullIPValue) == 0) {
		return -1;
	}
	websGetIFInfo(OTHER_IF_TYPE, IP_INFO, 1, nReqIdx, TRUE, NULL,
		      pRetValue);

	return 1;
}

void ifx_set_wlan_security(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pEncryType, *pAuthType, *pKeyUsed, *pIsPassPhrase, *p1xKeyLen;
	char_t *pKey1, *pKey2, *pKey3, *pKey4, *pPsk;
	char_t *pNas_iden;
	char_t *pOwnIP1, *pOwnIP2, *pOwnIP3, *pOwnIP4;
	char_t *pRadiusIP1, *pRadiusIP2, *pRadiusIP3, *pRadiusIP4;
	char_t *pRadius_port, *pRadius_secret;
	char_t sEncryType[MAX_DATA_LEN], sAuthType[MAX_DATA_LEN];
	char_t sKeyUsed[MAX_DATA_LEN], sIsPassPhrase[MAX_FILELINE_LEN];
	char_t sNas_iden[MAX_DATA_LEN], sOwnIP[MAX_DATA_LEN];
	char_t sRadiusIP[MAX_DATA_LEN], s1xKeyLen[MAX_DATA_LEN],
	    sRadius_port[MAX_DATA_LEN], sRadius_secret[MAX_DATA_LEN];
	char_t sKey1[MAX_FILELINE_LEN], sKey2[MAX_FILELINE_LEN],
	    sKey3[MAX_FILELINE_LEN], sKey4[MAX_FILELINE_LEN];
	char_t sPsk[MAX_FILELINE_LEN], sPassPhrase[MAX_FILELINE_LEN];
	char_t *pGKeyEnable, *pGKeyRenewal;
	char_t sGKeyEnable[MAX_FILELINE_LEN];
	char_t sGKeyRenewal[MAX_FILELINE_LEN];
	char_t sTempIp1[MAX_FILELINE_LEN], sTempIp2[MAX_FILELINE_LEN];
	char_t sTempIp3[MAX_FILELINE_LEN], sTempIp4[MAX_FILELINE_LEN];
	char_t sValue[MAX_FILELINE_LEN];
	char_t sWepKey[MAX_FILELINE_LEN], sWepKeyIdx[MAX_DATA_LEN];
	char_t sESSID[MAX_FILELINE_LEN];
	char_t sCommand[MAX_FILELINE_LEN];

	a_assert(wp);

	sKey1[0] = '\0';
	sKey2[0] = '\0';
	sKey3[0] = '\0';
	sKey4[0] = '\0';
	sPsk[0] = '\0';
	sPassPhrase[0] = '\0';
	sESSID[0] = '\0';
	sWepKey[0] = '\0';
	sGKeyEnable[0] = '\0';
	sGKeyRenewal[0] = '\0';
	sOwnIP[0] = '\0';
	sTempIp1[0] = '\0';
	sTempIp2[0] = '\0';
	sTempIp3[0] = '\0';
	sTempIp4[0] = '\0';
	sValue[0] = '\0';
	// Get value from ASP file
	pAuthType = ifx_httpdGetVar(wp, T("AuthType"), T(""));
	pEncryType = ifx_httpdGetVar(wp, T("EncryType"), T(""));

	if (pEncryType[0] == 0 && pAuthType[0] == 0) {
		ifx_httpdError(wp, 500, "Failed to get data form HTML page!\n");
		return;
	}

	gsprintf(sAuthType, T("WLAN_AUTH_TYPE=\"%d\"\n"), atoi(pAuthType));
	gsprintf(sEncryType, T("WLAN_ENCRY_TYPE=\"%d\"\n"), atoi(pEncryType));

	gsprintf(sCommand, T("ifconfig %s down"), IFX_WLAN_IF);
	system(sCommand);

	pNas_iden = ifx_httpdGetVar(wp, T("Nas_iden"), T(""));
	pOwnIP1 = ifx_httpdGetVar(wp, T("own_ip1"), T(""));
	pOwnIP2 = ifx_httpdGetVar(wp, T("own_ip2"), T(""));
	pOwnIP3 = ifx_httpdGetVar(wp, T("own_ip3"), T(""));
	pOwnIP4 = ifx_httpdGetVar(wp, T("own_ip4"), T(""));
	pRadiusIP1 = ifx_httpdGetVar(wp, T("radius_ip1"), T(""));
	pRadiusIP2 = ifx_httpdGetVar(wp, T("radius_ip2"), T(""));
	pRadiusIP3 = ifx_httpdGetVar(wp, T("radius_ip3"), T(""));
	pRadiusIP4 = ifx_httpdGetVar(wp, T("radius_ip4"), T(""));
	pRadius_port = ifx_httpdGetVar(wp, T("radius_port"), T(""));
	pRadius_secret = ifx_httpdGetVar(wp, T("radius_secret"), T(""));
	pGKeyEnable = ifx_httpdGetVar(wp, T("GKeyEnable"), T(""));
	pGKeyRenewal = ifx_httpdGetVar(wp, T("GKeyRenew"), T(""));

	if (!*pGKeyEnable) {
		ifx_GetCfgData(FILE_RC_CONF, TAG_WLAN_SECURITY,
			       "WLAN_GKEY_ENABLE", sValue);
		gsprintf(sGKeyEnable, T("WLAN_GKEY_ENABLE=\"%s\"\n"), sValue);
	} else
		gsprintf(sGKeyEnable, T("WLAN_GKEY_ENABLE=\"%s\"\n"),
			 pGKeyEnable);

	if (!*pGKeyRenewal) {
		ifx_GetCfgData(FILE_RC_CONF, TAG_WLAN_SECURITY,
			       "WLAN_GKEY_RENEWAL", sValue);
		gsprintf(sGKeyRenewal, T("WLAN_GKEY_RENEWAL=\"%s\"\n"), sValue);
	} else
		gsprintf(sGKeyRenewal, T("WLAN_GKEY_RENEWAL=\"%s\"\n"),
			 pGKeyRenewal);

	/* If one of RADIUS IP is empty, obtain the original from rc.conf */
	if (!*pRadiusIP1 || !*pRadiusIP2 ||
	    !*pRadiusIP3 || !*pRadiusIP4 ||
	    !*pOwnIP1 || !*pOwnIP2 || !*pOwnIP3 || !*pOwnIP4 ||
	    pNas_iden[0] == 0 || pRadius_secret[0] == 0) {
		if (websGetIPAddress
		    (TAG_WLAN_SECURITY, "WLAN_OWN_IP", 1, sTempIp1) != 1) {
			ifx_httpdError(wp, 500,
				       " --- The WLAN_OWN_IP is not got !\n");
			return;
		}

		if (websGetIPAddress
		    (TAG_WLAN_SECURITY, "WLAN_OWN_IP", 2, sTempIp2) != 1) {
			ifx_httpdError(wp, 500,
				       " --- The WLAN_OWN_IP is not got !\n");
			return;
		}

		if (websGetIPAddress
		    (TAG_WLAN_SECURITY, "WLAN_OWN_IP", 3, sTempIp3) != 1) {
			ifx_httpdError(wp, 500,
				       " --- The WLAN_OWN_IP is not got  !\n");
			return;
		}

		if (websGetIPAddress
		    (TAG_WLAN_SECURITY, "WLAN_OWN_IP", 4, sTempIp4) != 1) {
			ifx_httpdError(wp, 500,
				       " --- The WLAN_OWN_IP is not got  !\n");
			return;
		}

		gsprintf(sOwnIP, T("WLAN_OWN_IP=\"%s.%s.%s.%s\"\n"),
			 sTempIp1, sTempIp2, sTempIp3, sTempIp4);

		if (ifx_GetCfgData(FILE_RC_CONF, TAG_WLAN_SECURITY,
				   "WLAN_NAS_ID", sValue) != 1) {
			ifx_httpdError(wp, 500,
				       " --- The WLAN_NAS_ID is not got  !\n");
			return;
		}
		gsprintf(sNas_iden, T("WLAN_NAS_ID=\"%s\"\n"), sValue);

		if (websGetIPAddress(TAG_WLAN_SECURITY, "WLAN_RADIUS_SERVER_IP",
				     1, sTempIp1) != 1) {
			ifx_httpdError(wp, 500,
				       " --- The WLAN_RADIUS_SERVER_IP1 is"
				       " not got !\n");
			return;
		}

		if (websGetIPAddress(TAG_WLAN_SECURITY, "WLAN_RADIUS_SERVER_IP",
				     2, sTempIp2) != 1) {
			ifx_httpdError(wp, 500,
				       " --- The WLAN_RADIUS_SERVER_IP2 is"
				       " not got !\n");
			return;
		}

		if (websGetIPAddress(TAG_WLAN_SECURITY, "WLAN_RADIUS_SERVER_IP",
				     3, sTempIp3) != 1) {
			ifx_httpdError(wp, 500,
				       " --- The WLAN_RADIUS_SERVER_IP3 is"
				       " not got  !\n");
			return;
		}

		if (websGetIPAddress(TAG_WLAN_SECURITY, "WLAN_RADIUS_SERVER_IP",
				     4, sTempIp4) != 1) {
			ifx_httpdError(wp, 500,
				       " --- The WLAN_RADIUS_SERVER_IP4 is"
				       " not got  !\n");
			return;
		}

		gsprintf(sRadiusIP,
			 T("WLAN_RADIUS_SERVER_IP=\"%s.%s.%s.%s\"\n"), sTempIp1,
			 sTempIp2, sTempIp3, sTempIp4);

		if (ifx_GetCfgData(FILE_RC_CONF, TAG_WLAN_SECURITY,
				   "WLAN_RADIUS_SERVER_PORT", sValue) != 1) {
			ifx_httpdError(wp, 500,
				       " --- The WLAN_RADIUS_SERVER_PORT is"
				       " not got  !\n");
			return;
		}
		gsprintf(sRadius_port, T("WLAN_RADIUS_SERVER_PORT=\"%s\"\n"),
			 sValue);

		if (ifx_GetCfgData(FILE_RC_CONF, TAG_WLAN_SECURITY,
				   "WLAN_RADIUS_SERVER_SECRET", sValue) != 1) {
			ifx_httpdError(wp, 500,
				       " --- The WLAN_RADIUS_SERVER_SECRET is"
				       " not got  !\n");
			return;
		}

		gsprintf(sRadius_secret,
			 T("WLAN_RADIUS_SERVER_SECRET=\"%s\"\n"), sValue);
	} else {
		gsprintf(sOwnIP, T("WLAN_OWN_IP=\"%s.%s.%s.%s\"\n"),
			 pOwnIP1, pOwnIP2, pOwnIP3, pOwnIP4);
		gsprintf(sNas_iden, T("WLAN_NAS_ID=\"%s\"\n"), pNas_iden);
		gsprintf(sRadiusIP,
			 T("WLAN_RADIUS_SERVER_IP=\"%s.%s.%s.%s\"\n"),
			 pRadiusIP1, pRadiusIP2, pRadiusIP3, pRadiusIP4);
		gsprintf(sRadius_port, T("WLAN_RADIUS_SERVER_PORT=\"%s\"\n"),
			 pRadius_port);
		gsprintf(sRadius_secret,
			 T("WLAN_RADIUS_SERVER_SECRET=\"%s\"\n"),
			 pRadius_secret);
	}

	switch (atoi(pAuthType)) {
	case WLAN_AUTH_OPEN:
	case WLAN_AUTH_SHARED:
	case WLAN_AUTH_SWITCH:
		if (atoi(pEncryType) == WLAN_ENCRY_NONE &&
		    atoi(pAuthType) == WLAN_AUTH_OPEN) {
			gsprintf(sKeyUsed, T("WLAN_KEY_USED=\"0\"\n"));
			gsprintf(sKey1, T("WLAN_KEY1=\"0\"\n"));
			gsprintf(sKey2, T("WLAN_KEY2=\"0\"\n"));
			gsprintf(sKey3, T("WLAN_KEY3=\"0\"\n"));
			gsprintf(sKey4, T("WLAN_KEY4=\"0\"\n"));
			gsprintf(s1xKeyLen, T("WLAN_8021X_KEYLEN=\"0\"\n"));
			gsprintf(sIsPassPhrase, T("WLAN_ISPASSPHRASE=\"0\"\n"));
			gsprintf(sPsk, T("WLAN_PSK=\"0\"\n"));
		} else if (atoi(pEncryType) == WLAN_ENCRY_NONE ||
			   atoi(pEncryType) == WLAN_ENCRY_WEP64 ||
			   atoi(pEncryType) == WLAN_ENCRY_WEP128) {
			pKeyUsed = ifx_httpdGetVar(wp, T("KeyUsed"), T(""));
			pKey1 = ifx_httpdGetVar(wp, T("Key1"), T(""));
			pKey2 = ifx_httpdGetVar(wp, T("Key2"), T(""));
			pKey3 = ifx_httpdGetVar(wp, T("Key3"), T(""));
			pKey4 = ifx_httpdGetVar(wp, T("Key4"), T(""));
			if (pKey1[0] == 0)
				gsprintf(pKey1, "0");
			if (pKey2[0] == 0)
				gsprintf(pKey2, "0");
			if (pKey3[0] == 0)
				gsprintf(pKey3, "0");
			if (pKey4[0] == 0)
				gsprintf(pKey4, "0");

			gsprintf(sKeyUsed, T("WLAN_KEY_USED=\"%d\"\n"),
				 atoi(pKeyUsed));
			gsprintf(sKey1, T("WLAN_KEY1=\"%s\"\n"), pKey1);
			gsprintf(sKey2, T("WLAN_KEY2=\"%s\"\n"), pKey2);
			gsprintf(sKey3, T("WLAN_KEY3=\"%s\"\n"), pKey3);
			gsprintf(sKey4, T("WLAN_KEY4=\"%s\"\n"), pKey4);
			gsprintf(s1xKeyLen, T("WLAN_8021X_KEYLEN=\"0\"\n"));
			gsprintf(sIsPassPhrase, T("WLAN_ISPASSPHRASE=\"0\"\n"));
			gsprintf(sPsk, T("WLAN_PSK=\"0\"\n"));

			trace(8, T("Check Key used here..............\n"));
			trace(8, "Key used is %s\n", pKeyUsed);
			// Get Active Key
			if (atoi(pKeyUsed) == 0) {
				ifx_httpdError(wp, 500,
					       "Set Active key error\n");
				return;
			} else if (atoi(pKeyUsed) == 1) {
				gstrcpy(sWepKeyIdx, "1");
				gstrcpy(sWepKey, pKey1);
				gsprintf(sKeyUsed, T("WLAN_KEY_USED=\"1\"\n"));
			} else if (atoi(pKeyUsed) == 2) {
				gstrcpy(sWepKeyIdx, "2");
				gstrcpy(sWepKey, pKey2);
				gsprintf(sKeyUsed, T("WLAN_KEY_USED=\"2\"\n"));
			} else if (atoi(pKeyUsed) == 3) {
				gstrcpy(sWepKeyIdx, "3");
				gstrcpy(sWepKey, pKey3);
				gsprintf(sKeyUsed, T("WLAN_KEY_USED=\"3\"\n"));
			} else if (atoi(pKeyUsed) == 4) {
				gstrcpy(sWepKeyIdx, "4");
				gstrcpy(sWepKey, pKey4);
				gsprintf(sKeyUsed, T("WLAN_KEY_USED=\"4\"\n"));
			}
		} else {
			ifx_httpdError(wp, 500, "Wrong Encripytion Type!\n");
			return;
		}
		break;

	case WLAN_AUTH_WPA:
	case WLAN_AUTH_WPA2:
		switch (atoi(pEncryType)) {
		case WLAN_ENCRY_1X:	// 802.1X (WEP)
		case WLAN_ENCRY_TKIP:	// TKIP
		case WLAN_ENCRY_AES:	// AES
		case WLAN_ENCRY_TKIP_AES:
			p1xKeyLen =
			    ifx_httpdGetVar(wp, T("P1x_key_len"), T(""));
			gsprintf(sKeyUsed, T("WLAN_KEY_USED=\"0\"\n"));
			gsprintf(sKey1, T("WLAN_KEY1=\"0\"\n"));
			gsprintf(sKey2, T("WLAN_KEY2=\"0\"\n"));
			gsprintf(sKey3, T("WLAN_KEY3=\"0\"\n"));
			gsprintf(sKey4, T("WLAN_KEY4=\"0\"\n"));
			gsprintf(s1xKeyLen, T("WLAN_8021X_KEYLEN=\"%d\"\n"),
				 atoi(p1xKeyLen));
			gsprintf(sIsPassPhrase, T("WLAN_ISPASSPHRASE=\"0\"\n"));
			gsprintf(sPsk, T("WLAN_PSK=\"0\"\n"));
			break;
		default:
			ifx_httpdError(wp, 500, "Wrong Encripytion Type!\n");
			return;
		}
		break;
	case WLAN_AUTH_PSK:
	case WLAN_AUTH_PSK2:
		switch (atoi(pEncryType)) {
		case WLAN_ENCRY_TKIP:	// TKIP
		case WLAN_ENCRY_AES:	// AES
		case WLAN_ENCRY_TKIP_AES:
			pIsPassPhrase =
			    ifx_httpdGetVar(wp, T("IsPassPhrase"), T(""));
			pPsk = ifx_httpdGetVar(wp, T("PSK"), T(""));
			ifx_web_convert_string(pPsk);

			gsprintf(sKeyUsed, T("WLAN_KEY_USED=\"0\"\n"));
			gsprintf(sKey1, T("WLAN_KEY1=\"0\"\n"));
			gsprintf(sKey2, T("WLAN_KEY2=\"0\"\n"));
			gsprintf(sKey3, T("WLAN_KEY3=\"0\"\n"));
			gsprintf(sKey4, T("WLAN_KEY4=\"0\"\n"));
			gsprintf(s1xKeyLen, T("WLAN_8021X_KEYLEN=\"0\"\n"));
			gsprintf(sIsPassPhrase, T("WLAN_ISPASSPHRASE=\"%d\"\n"),
				 atoi(pIsPassPhrase));
			gsprintf(sPsk, T("WLAN_PSK=\"%s\"\n"), pPsk);
			break;
		default:
			ifx_httpdError(wp, 500, "Wrong Encripytion Type!\n");
			return;
		}
		break;
	default:
		ifx_httpdError(wp, 500, T("Authentication Range Error = %s"),
			       pAuthType);
		return;
	}
	ifx_SetCfgData(FILE_RC_CONF, TAG_WLAN_SECURITY, 17, sAuthType,
		       sEncryType, sKeyUsed, sKey1, sKey2, sKey3, sKey4, sOwnIP,
		       sNas_iden, sRadiusIP, sRadius_port, sRadius_secret,
		       s1xKeyLen, sIsPassPhrase, sPsk, sGKeyEnable,
		       sGKeyRenewal);

	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}

	system("/etc/rc.d/rc.bringup_wireless restart");

	websNextPage(wp);
}
#endif				// CONFIG_FEATURE_IFX_WIRELESS_ATH

#ifdef CONFIG_FEATURE_IFX_WIRELESS_TSC

void ifx_set_basic_wireless_settings(httpd_t wp, char_t * path, char_t * query)
{
	WLAN_COMMON_CFG wlan_cmn;
	WLAN_MAIN_CFG wlan_main;
	int32 ret = IFX_SUCCESS, flags = 0, oper = 0;
	char_t *pApVapActionType, *pValue;
	int32 apIndex = 0;
	uint32 apEnable = 0;
	char8 sCommand[MAX_DATA_LEN];

	memset(&wlan_cmn, 0, sizeof(WLAN_COMMON_CFG));
	memset(&wlan_main, 0, sizeof(WLAN_MAIN_CFG));

	pApVapActionType = ifx_httpdGetVar(wp, T("submit_action"), T(""));
	if (!pApVapActionType) {
		return ret;
	}

	if (!gstrcmp(pApVapActionType, "modifycommon")) {
		pValue = ifx_httpdGetVar(wp, T("wlan_enable"), T(""));
		wlan_cmn.RadioEnable = gatoi(pValue);

		pValue = ifx_httpdGetVar(wp, T("beacon_int"), T(""));
		wlan_cmn.beaconIntvl = gatoi(pValue);

		pValue = ifx_httpdGetVar(wp, T("op_mode"), T(""));
		wlan_cmn.mode = gatoi(pValue);

		pValue = ifx_httpdGetVar(wp, T("country"), T(""));
		wlan_cmn.country = gatoi(pValue);

		pValue = ifx_httpdGetVar(wp, T("channel"), T(""));
		wlan_cmn.apChannelId = gatoi(pValue);
		/* default power level is 100% */
		wlan_cmn.PowerLvl = WLAN_POWER_LEVEL_100;

		oper = IFX_OP_MOD;
		flags = IFX_F_MODIFY;

		if ((ret =
		     ifx_set_wlan_common_config(oper, &wlan_cmn,
						flags)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to set wlan common config");
			return;
		}
	} else if (!gstrcmp(pApVapActionType, "modssid")) {
#if 1
		pValue = ifx_httpdGetVar(wp, T("slno"), T(""));
		apIndex = gatoi(pValue);

		gsprintf(sCommand, T("apEna%d"), apIndex);
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		apEnable = gatoi(pValue);
		wlan_main.apEnable = apEnable;

		gsprintf(sCommand, T("old_ssid%d"), apIndex);
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		gstrcpy(wlan_main.SSID, pValue);

		sprintf(wlan_main.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
		sprintf(wlan_main.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

		if (ifx_get_iid_from_ssid(pValue, &wlan_main.iid) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 400, "Failed to set ssid");
			return;
		}
		if ((ret =
		     ifx_get_wlan_main_config(&wlan_main,
					      flags)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to get wlan main config");
			return;
		}

		wlan_main.apEnable = apEnable;

		gsprintf(sCommand, T("new_ssid%d"), apIndex);
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		gstrcpy(wlan_main.SSID, pValue);

#else

		pValue = ifx_httpdGetVar(wp, T("slno"), T(""));
		apIndex = gatoi(pValue);

		gsprintf(sCommand, T("apEna"));
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		apEnable = gatoi(pValue);
		wlan_main.apEnable = apEnable;

		gsprintf(sCommand, T("old_ssid"));	/* will be a select item in web 
							   page */
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		gstrcpy(wlan_main.SSID, pValue);

		sprintf(wlan_main.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
		sprintf(wlan_main.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

		if (ifx_get_iid_from_ssid(pValue, &wlan_main.iid) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 400, "Failed to set ssid");
			return;
		}

		if ((ret =
		     ifx_get_wlan_main_config(&wlan_main,
					      flags)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to get wlan main config");
			return;
		}
		wlan_main.apEnable = apEnable;

		gsprintf(sCommand, T("new_ssid"));	/* will be a text box in web
							   page */
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		gstrcpy(wlan_main.SSID, pValue);
#endif				// 0

		oper = IFX_OP_MOD;
		flags = IFX_F_MODIFY;

		if ((ret =
		     ifx_set_wlan_main_config(oper, &wlan_main,
					      flags)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to set wlan main config");
			return;
		}
	} else if (!gstrcmp(pApVapActionType, "delssid")) {
		pValue = ifx_httpdGetVar(wp, T("slno"), T(""));
		apIndex = gatoi(pValue);

		gsprintf(sCommand, T("ssid%d"), apIndex);
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		gstrcpy(wlan_main.SSID, pValue);

		sprintf(wlan_main.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
		sprintf(wlan_main.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

		if (ifx_get_iid_from_ssid(pValue, &wlan_main.iid) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 400, "Failed to set ssid");
			return -1;
		}
		oper = IFX_OP_DEL;
		flags = IFX_F_DELETE;

		if ((ret =
		     ifx_set_wlan_main_config(oper, &wlan_main,
					      flags)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to set wlan main config");
			return;
		}
	} else if (!gstrcmp(pApVapActionType, "req_ch_list")) {
		/* get selected mode and country and store in global variables which
		   will be used by get cgi functions */
		pValue = ifx_httpdGetVar(wp, T("op_mode"), T(""));
		g_op_mode = gatoi(pValue);
		pValue = ifx_httpdGetVar(wp, T("country"), T(""));
		g_country = gatoi(pValue);
	}

	websNextPage(wp);
}

void
ifx_set_advanced_wireless_settings(httpd_t wp, char_t * path, char_t * query)
{
	WLAN_MAIN_CFG wlan_main;
	int32 ret = IFX_SUCCESS, flags = IFX_F_DEFAULT, oper = 0;
	char8 *pApVapActionType = NULL, *pValue = NULL, *pValue2 = NULL;
	uint32 i = 0;
	char_t *ssid = ifx_httpdGetVar(wp, T("ssid"), "");

	memset(&wlan_main, 0, sizeof(WLAN_MAIN_CFG));

	sprintf(wlan_main.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
	sprintf(wlan_main.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

	if (ifx_get_iid_from_ssid(ssid, &wlan_main.iid) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400,
			       "Failed to get advanced info for this ssid");
		return -1;
	}
	if ((ret = ifx_get_wlan_main_config(&wlan_main, flags)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to get wlan main config");
		return;
	}

	pApVapActionType = ifx_httpdGetVar(wp, T("submit_action"), T(""));

	if (!gstrcmp(pApVapActionType, "modify_adv")) {
		pValue = ifx_httpdGetVar(wp, T("ARF"), T(""));
		wlan_main.autoRateFallBackEnable = gatoi(pValue);
		wlan_main.apIsolation = 0;	/* default turned off */

		pValue = ifx_httpdGetVar(wp, T("basic_data_rate"), T(""));
		pValue2 = strtok(pValue, ",");
		for (i = 0; pValue2 != NULL; i++) {
			wlan_main.basicDataRates[i] =
			    (float)strtod(pValue2, (char **)NULL);
			// TODO : is "," required after every value
			pValue2 = strtok(NULL, ",");
		}

		pValue = ifx_httpdGetVar(wp, T("op_data_rate"), T(""));
		pValue2 = strtok(pValue, ",");
		for (i = 0; pValue2 != NULL; i++) {
			wlan_main.operationalDataRates[i] =
			    (float)strtod(pValue2, (char **)NULL);
			// TODO : is "," required after every value
			pValue2 = strtok(NULL, ",");
		}

		pValue = ifx_httpdGetVar(wp, T("max_bit_rate"), T(""));
		wlan_main.maxBitRate = (float)strtod(pValue, (char **)NULL);

		pValue = ifx_httpdGetVar(wp, T("preamble"), T(""));
		wlan_main.preamble = gatoi(pValue);

		/* Using default values for rts and frs */
		wlan_main.rts = 2353;
		wlan_main.fts = 2352;

		oper = IFX_OP_MOD;
		flags = IFX_F_MODIFY;
		if ((ret =
		     ifx_set_wlan_main_config(oper, &wlan_main,
					      flags)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to set wlan main config");
			return;
		}
	}
	websNextPage(wp);
}

void
ifx_set_wireless_security_settings(httpd_t wp, char_t * path, char_t * query)
{
	WLAN_SEC_CFG wlan_sec;
	int32 ret = IFX_SUCCESS, flags = 0, oper = 0;
	uint32 beacontype = 0, authtype = 0, encrtype = 0;
	char_t sValue[MAX_FILELINE_LEN];
	char8 *pValue;

	sValue[0] = '\0';
	memset(&wlan_sec, 0, sizeof(WLAN_SEC_CFG));

	if (ifx_GetObjData
	    (FILE_RC_CONF, TAG_WLAN_MAIN, "wlanmn_0_ssid", IFX_F_DEFAULT, NULL,
	     sValue) != IFX_SUCCESS) {
		ifx_httpdWrite(wp, T("Failed to get ssid from rc.conf!!"));
		return;
	}

	sprintf(wlan_sec.iid.cpeId.secName, "%s", TAG_WLAN_SEC);
	sprintf(wlan_sec.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

	if (ifx_get_iid_from_ssid(sValue, &wlan_sec.iid) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400,
			       "Failed to get security info for this ssid");
		return -1;
	}

	if ((ret =
	     ifx_get_wlan_security_config(&wlan_sec, flags)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400,
			       T("Failed to get wlan security config\n"));
		return ret;
	}
	pValue = ifx_httpdGetVar(wp, T("beacon_type"), T(""));
	beacontype = gatoi(pValue);
	wlan_sec.beaconType = beacontype;

	pValue = ifx_httpdGetVar(wp, T("AuthType"), T(""));
	authtype = gatoi(pValue);

	pValue = ifx_httpdGetVar(wp, T("EncryType"), T(""));
	encrtype = gatoi(pValue);

	switch (beacontype) {
	case WLAN_BEACON_BASIC:
		switch (authtype) {
		case 1:
			wlan_sec.wlan_auth = WLAN_AUTH_OPEN;
			authtype = WLAN_AUTH_OPEN;
			break;
		case 2:
			wlan_sec.wlan_auth = WLAN_AUTH_SHARED;
			authtype = WLAN_AUTH_SHARED;
			break;
		}
		switch (encrtype) {
		case 1:
			wlan_sec.wlan_encr = WLAN_ENCR_NONE;
			encrtype = WLAN_ENCR_NONE;
			break;
		case 2:
			wlan_sec.wlan_encr = WLAN_ENCR_WEP;
			encrtype = WLAN_ENCR_WEP;
			break;
		}
		break;
	case WLAN_BEACON_WPA:
		switch (authtype) {
		case 1:
			wlan_sec.wlan_auth = WLAN_AUTH_WPA_PSK;
			authtype = WLAN_AUTH_WPA_PSK;
			break;
		case 2:
			wlan_sec.wlan_auth = WLAN_AUTH_WPA2_PSK;
			authtype = WLAN_AUTH_WPA2_PSK;
			break;
		}
		switch (encrtype) {
		case 1:
			wlan_sec.wlan_encr = WLAN_ENCR_TKIP;
			encrtype = WLAN_ENCR_TKIP;
			break;
		case 2:
			wlan_sec.wlan_encr = WLAN_ENCR_AES;
			encrtype = WLAN_ENCR_AES;
			break;
		}
		break;
	}
	/* we dont know what was the earlier and new authentication, encryption
	   types. so get earlier wep and wpa config manually */
	if ((wlan_sec.beaconType == WLAN_BEACON_BASIC)
	    && (wlan_sec.wlan_encr == WLAN_ENCR_WEP)) {

		wlan_sec.wlan_secprm.wepKey[0].iid.pcpeId.Id =
		    wlan_sec.iid.cpeId.Id;
		if (ifx_get_wlan_wep_config
		    (0, &wlan_sec.wlan_secprm.wepKey[0],
		     IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to get info of wep keys");
			return ret;
		}
		wlan_sec.wlan_secprm.wepKey[1].iid.pcpeId.Id =
		    wlan_sec.iid.cpeId.Id;
		if (ifx_get_wlan_wep_config
		    (1, &wlan_sec.wlan_secprm.wepKey[1],
		     IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to get info of wep keys");
			return ret;
		}
		wlan_sec.wlan_secprm.wepKey[2].iid.pcpeId.Id =
		    wlan_sec.iid.cpeId.Id;
		if (ifx_get_wlan_wep_config
		    (2, &wlan_sec.wlan_secprm.wepKey[2],
		     IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to get info of wep keys");
			return ret;
		}
		wlan_sec.wlan_secprm.wepKey[3].iid.pcpeId.Id =
		    wlan_sec.iid.cpeId.Id;
		if (ifx_get_wlan_wep_config
		    (3, &wlan_sec.wlan_secprm.wepKey[3],
		     IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to get info of wep keys");
			return ret;
		}

	} else if (wlan_sec.beaconType == WLAN_BEACON_WPA) {

		wlan_sec.wlan_secprm.psk.iid.pcpeId.Id = wlan_sec.iid.cpeId.Id;
		if (ifx_get_wlan_passphrase_config
		    (&wlan_sec.wlan_secprm.psk, IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to get info of wpa passphrase");
			return ret;
		}

	}
	if ((beacontype == WLAN_BEACON_BASIC)
	    && (authtype == WLAN_AUTH_OPEN || authtype == WLAN_AUTH_SHARED)
	    && (encrtype == WLAN_ENCR_NONE)) {
		// do nothing
		oper = IFX_OP_MOD;
		flags = IFX_F_MODIFY;
		if ((ret =
		     ifx_set_wlan_security_config(oper, &wlan_sec,
						  flags)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to set wlan security config");
			return;
		}
	} else if ((beacontype == WLAN_BEACON_BASIC)
		   && (authtype == WLAN_AUTH_OPEN)
		   && (encrtype == WLAN_ENCR_WEP)) {
		pValue = ifx_httpdGetVar(wp, T("KeyIndex"), T(""));
		wlan_sec.keyIndex = gatoi(pValue);

		pValue = ifx_httpdGetVar(wp, T("EncryptLevel"), T(""));
		wlan_sec.wepEncrLvl = gatoi(pValue);
		pValue = ifx_httpdGetVar(wp, T("open_shared_key_type"), T(""));
		wlan_sec.wepKeyType = gatoi(pValue);

		if (wlan_sec.wepKeyType == ASCII_KEY) {
			pValue =
			    ifx_httpdGetVar(wp, T("open_shared_key1"), T(""));
			sprintf(wlan_sec.wlan_secprm.wepKey[0].WEP_KEY, "%s",
				pValue);
			pValue =
			    ifx_httpdGetVar(wp, T("open_shared_key2"), T(""));
			sprintf(wlan_sec.wlan_secprm.wepKey[1].WEP_KEY, "%s",
				pValue);
			pValue =
			    ifx_httpdGetVar(wp, T("open_shared_key3"), T(""));
			sprintf(wlan_sec.wlan_secprm.wepKey[2].WEP_KEY, "%s",
				pValue);
			pValue =
			    ifx_httpdGetVar(wp, T("open_shared_key4"), T(""));
			sprintf(wlan_sec.wlan_secprm.wepKey[3].WEP_KEY, "%s",
				pValue);
		} else {
			pValue =
			    ifx_httpdGetVar(wp, T("open_shared_key1"), T(""));
			gstrcpy(wlan_sec.wlan_secprm.wepKey[0].WEP_KEY, pValue);
			pValue =
			    ifx_httpdGetVar(wp, T("open_shared_key2"), T(""));
			gstrcpy(wlan_sec.wlan_secprm.wepKey[1].WEP_KEY, pValue);
			pValue =
			    ifx_httpdGetVar(wp, T("open_shared_key3"), T(""));
			gstrcpy(wlan_sec.wlan_secprm.wepKey[2].WEP_KEY, pValue);
			pValue =
			    ifx_httpdGetVar(wp, T("open_shared_key4"), T(""));
			gstrcpy(wlan_sec.wlan_secprm.wepKey[3].WEP_KEY, pValue);
		}
		ifx_make_canonical_key(wlan_sec.wlan_secprm.wepKey[0].WEP_KEY);
		ifx_make_canonical_key(wlan_sec.wlan_secprm.wepKey[1].WEP_KEY);
		ifx_make_canonical_key(wlan_sec.wlan_secprm.wepKey[2].WEP_KEY);
		ifx_make_canonical_key(wlan_sec.wlan_secprm.wepKey[3].WEP_KEY);

		oper = IFX_OP_MOD;
		flags = IFX_F_MODIFY;
		if ((ret =
		     ifx_set_wlan_security_config(oper, &wlan_sec,
						  flags)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to set wlan security config");
			return;
		}
	} else if ((beacontype == WLAN_BEACON_BASIC)
		   && (authtype == WLAN_AUTH_SHARED)) {
		pValue = ifx_httpdGetVar(wp, T("KeyIndex"), T(""));
		wlan_sec.keyIndex = gatoi(pValue);

		pValue = ifx_httpdGetVar(wp, T("EncryptLevel"), T(""));
		wlan_sec.wepEncrLvl = gatoi(pValue);
		pValue = ifx_httpdGetVar(wp, T("open_shared_key_type"), T(""));
		wlan_sec.wepKeyType = gatoi(pValue);

		if (wlan_sec.wepKeyType == ASCII_KEY) {
			pValue =
			    ifx_httpdGetVar(wp, T("open_shared_key1"), T(""));
			sprintf(wlan_sec.wlan_secprm.wepKey[0].WEP_KEY, "%s",
				pValue);
			pValue =
			    ifx_httpdGetVar(wp, T("open_shared_key2"), T(""));
			sprintf(wlan_sec.wlan_secprm.wepKey[1].WEP_KEY, "%s",
				pValue);
			pValue =
			    ifx_httpdGetVar(wp, T("open_shared_key3"), T(""));
			sprintf(wlan_sec.wlan_secprm.wepKey[2].WEP_KEY, "%s",
				pValue);
			pValue =
			    ifx_httpdGetVar(wp, T("open_shared_key4"), T(""));
			sprintf(wlan_sec.wlan_secprm.wepKey[3].WEP_KEY, "%s",
				pValue);
		} else {
			pValue =
			    ifx_httpdGetVar(wp, T("open_shared_key1"), T(""));
			gstrcpy(wlan_sec.wlan_secprm.wepKey[0].WEP_KEY, pValue);
			pValue =
			    ifx_httpdGetVar(wp, T("open_shared_key2"), T(""));
			gstrcpy(wlan_sec.wlan_secprm.wepKey[1].WEP_KEY, pValue);
			pValue =
			    ifx_httpdGetVar(wp, T("open_shared_key3"), T(""));
			gstrcpy(wlan_sec.wlan_secprm.wepKey[2].WEP_KEY, pValue);
			pValue =
			    ifx_httpdGetVar(wp, T("open_shared_key4"), T(""));
			gstrcpy(wlan_sec.wlan_secprm.wepKey[3].WEP_KEY, pValue);
		}
		ifx_make_canonical_key(wlan_sec.wlan_secprm.wepKey[0].WEP_KEY);
		ifx_make_canonical_key(wlan_sec.wlan_secprm.wepKey[1].WEP_KEY);
		ifx_make_canonical_key(wlan_sec.wlan_secprm.wepKey[2].WEP_KEY);
		ifx_make_canonical_key(wlan_sec.wlan_secprm.wepKey[3].WEP_KEY);

		oper = IFX_OP_MOD;
		flags = IFX_F_MODIFY;
		if ((ret =
		     ifx_set_wlan_security_config(oper, &wlan_sec,
						  flags)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to set wlan security config");
			return;
		}
	} else if ((beacontype == WLAN_BEACON_WPA)
		   && (authtype == WLAN_AUTH_WPA)
		   && ((encrtype == WLAN_ENCR_TKIP)
		       || (encrtype == WLAN_ENCR_AES))) {
		// do nothing
	} else if ((beacontype == WLAN_BEACON_WPA)
		   && ((authtype == WLAN_AUTH_WPA_PSK)
		       || (authtype == WLAN_AUTH_WPA2_PSK))
		   && ((encrtype == WLAN_ENCR_TKIP)
		       || (encrtype == WLAN_ENCR_AES))) {
		pValue = ifx_httpdGetVar(wp, T("personal_key_type"), T(""));
		wlan_sec.pskKeyType = gatoi(pValue);
		pValue = ifx_httpdGetVar(wp, T("personal_key"), T(""));
		gstrcpy(wlan_sec.wlan_secprm.psk.passPhrase, pValue);

		oper = IFX_OP_MOD;
		flags = IFX_F_MODIFY;
		if ((ret =
		     ifx_set_wlan_security_config(oper, &wlan_sec,
						  flags)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to set wlan security config");
			return;
		}
	} else if ((beacontype == WLAN_BEACON_WPA)
		   && (authtype == WLAN_AUTH_WPA2)
		   && ((encrtype == WLAN_ENCR_TKIP)
		       || (encrtype == WLAN_ENCR_AES))) {
		// do nothing
	}
	websNextPage(wp);
	return;
}

void
ifx_set_wireless_macfilter_settings(httpd_t wp, char_t * path, char_t * query)
{
	WLAN_MAC_CONTROL wlan_mac_ctrl;
	int32 ret = IFX_SUCCESS, flags = 0, oper = 0;
	char8 *pValue;
	char8 buf[MAX_DATA_LEN];
	uint32 numEntries = 0, i = 0;

	memset(&wlan_mac_ctrl, 0, sizeof(WLAN_MAC_CONTROL));

	pValue = ifx_httpdGetVar(wp, T("submit_action"), T(""));

	if (!gstrcmp(pValue, "del_mac")) {
		IFX_MEM_ALLOC(wlan_mac_ctrl.macAddrList, WLAN_MACADDR *,
			      sizeof(WLAN_MACADDR), 1);
		if (!(wlan_mac_ctrl.macAddrList)) {
			ifx_httpdError(wp, 400, "Failed to alloc");
			return;
		}
		if ((ret =
		     ifx_get_all_wlan_mac_controlTbl(&numEntries,
						     &wlan_mac_ctrl,
						     flags)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to get wlan mac control table");
			return;
		}

		for (i = 0; i < numEntries; i++) {
			sprintf(buf, "rmid%d", i);
			pValue = ifx_httpdGetVar(wp, T(buf), T(""));
			if (atoi(pValue)) {
				sprintf(buf, "cpeId%d", i);
				pValue = ifx_httpdGetVar(wp, T(buf), T(""));
				wlan_mac_ctrl.macAddrList->iid.cpeId.Id =
				    gatoi(pValue);

				oper = IFX_OP_DEL;
				flags = IFX_F_DELETE;
				if ((ret =
				     ifx_set_wlan_mac_control(oper,
							      &wlan_mac_ctrl,
							      flags)) !=
				    IFX_SUCCESS) {
					ifx_httpdError(wp, 400,
						       "Failed to set wlan mac control");
					return;
				}
				sleep(2);
			}
		}
	} else if (!gstrcmp(pValue, "mac_ctrl_status")) {
		oper = IFX_OP_MOD;
		flags = IFX_F_MODIFY;

		pValue = ifx_httpdGetVar(wp, T("mac_control_status"), T(""));
		wlan_mac_ctrl.global_mode = gatoi(pValue);
		if ((ret =
		     ifx_set_wlan_mac_control_status(oper, &wlan_mac_ctrl,
						     flags) != IFX_SUCCESS)) {
			ifx_httpdError(wp, 400,
				       "Failed to set wlan mac control status");
			goto IFX_Handler;
		}
	}
      IFX_Handler:
	websNextPage(wp);
	return;
}

void
ifx_set_wireless_add_macfilter_settings(httpd_t wp, char_t * path,
					char_t * query)
{
	WLAN_MAC_CONTROL wlan_mac_ctrl;
	int32 ret = IFX_SUCCESS, flags = 0, oper = 0;
	char8 *pValue;

	memset(&wlan_mac_ctrl, 0, sizeof(WLAN_MAC_CONTROL));

	IFX_MEM_ALLOC(wlan_mac_ctrl.macAddrList, WLAN_MACADDR *,
		      sizeof(WLAN_MACADDR), 1);
	if (!(wlan_mac_ctrl.macAddrList)) {
		ifx_httpdError(wp, 400, "Failed to alloc");
		return;
	}

	pValue = ifx_httpdGetVar(wp, T("mac_address"), T(""));
	gstrncpy(&wlan_mac_ctrl.macAddrList->macAddr[0], pValue,
		 MAX_MAC_ADDR_LEN);

	wlan_mac_ctrl.macAddrList->InterfaceType =
	    MACADDR_CONTROL_INTF_TYPE_WLAN;

	oper = IFX_OP_ADD;
	flags = IFX_F_DEFAULT;
	if ((ret =
	     ifx_set_wlan_mac_control(oper, &wlan_mac_ctrl,
				      flags)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to set wlan mac control");
		return;
	}
	IFX_MEM_FREE(wlan_mac_ctrl.macAddrList);

IFX_Handler:
	ifx_httpdRedirect(wp, T("wlan_mac_filter_cfg.asp"));
	return;
}

#endif				// CONFIG_FEATURE_IFX_WIRELESS_TSC
