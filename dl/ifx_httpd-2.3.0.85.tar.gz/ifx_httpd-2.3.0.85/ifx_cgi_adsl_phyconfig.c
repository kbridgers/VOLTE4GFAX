#if defined(CONFIG_PACKAGE_IFX_DSL_CPE_API)

#include <sys/ioctl.h>
#include "ifx_httpd.h"
#include <ifx_emf.h>
#include "ifx_httpd_method.h"
// #include <ifx_amazon_cfg.h>

// #include <drv_dsl_cpe_api_config.h>
#include <drv_dsl_cpe_api.h>
#include <drv_dsl_cpe_api_ioctl.h>
#include <drv_dsl_cpe_api_g997.h>
extern int reboot_status;

#ifdef CONFIG_FEATURE_VDSL_VECTORING
#include <ifxos/ifx_types.h>
#include <drv_mei_cpe_interface.h>
#endif
#include "ifx_cgi_adsl_phyconfig.h"
#include "ifx_cgi_common.h"
DSL_G997_BitAllocationNsc_t bitAllocationNsc;
DSL_uint8_t UpStreamNSCData[DSL_MAX_NSC];
DSL_uint8_t DownStreamNSCData[DSL_MAX_NSC];

extern char *status_str;
extern int ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);

int ltq_G997_XTUSystemEnablingConfigSet(char_t *xTSE_Value)
{
	
	int fd;
	int ret = 0;
	int i = 0;
	DSL_G997_XTUSystemEnabling_t pData;
	unsigned int nParam[8] = { 0 };
	char dev_name[64];
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	int dsl_line = 0;
	for (dsl_line = 0; dsl_line <= 1; dsl_line++) 
	{
	sprintf(dev_name, DSL_CPE_DEVICE_NAME"/%d", dsl_line);
#else
	sprintf(dev_name, DSL_CPE_DEVICE_NAME);
#endif
	// DSL_Open
	fd = open(dev_name, O_RDWR);
	if(fd < 0) {
	    //ifx_httpdWrite(wp, T("cannot open device %s"), DSL_CPE_DEVICE_NAME);
		IFX_DBG("[%s:%d]  FILE OPEN ERROR\n", __FUNCTION__, __LINE__);
		return -1;
	}

	memset(&pData, 0x0, sizeof(DSL_G997_XTUSystemEnabling_t));

	IFX_DBG("\n--------------------------------\n");
	IFX_DBG("VALUE GOT = %s\n", xTSE_Value);
	IFX_DBG("\n--------------------------------\n");
 
	sscanf(xTSE_Value,"%x_%x_%x_%x_%x_%x_%x_%x", &nParam[0], &nParam[1],&nParam[2],	&nParam[3],	&nParam[4], &nParam[5],	&nParam[6],	&nParam[7]);
 	for (i = 0; i < 8; i++)
	{
		pData.data.XTSE[i] = (uint8_t) nParam[i];
	}
	ret = ioctl(fd, DSL_FIO_G997_XTU_SYSTEM_ENABLING_CONFIG_SET, (int) &pData);
	if ((ret < 0))
	{
		//failure
		IFX_DBG("[%s:%d]  G99 SET IOCTL FAILURE\n", __FUNCTION__, __LINE__);
		return -1;
	}
	close(fd);
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	}
#endif
	IFX_DBG("[%s:%d]  G99 SET IOCTL SUCCESS\n", __FUNCTION__, __LINE__);
	return 0;
}

int ifx_cgi_adsl_phyconfig_get_bit_allocated_per_tone(int eid, httpd_t wp,
						      int argc, char_t ** argv)
{
	int fd = 0;
	int i;

	char dev_name[64];
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	int dsl_line = 0;
	for (dsl_line = 0; dsl_line <= 1; dsl_line++) 
	{
	sprintf(dev_name, DSL_CPE_DEVICE_NAME"/%d", dsl_line);
#else
	sprintf(dev_name, DSL_CPE_DEVICE_NAME);
#endif
	// DSL_Open
	fd = open(dev_name, O_RDWR);
	if (fd < 0) {
		ifx_httpdWrite(wp, T("cannot open device %s"),
			       dev_name);
	}

	memset(&bitAllocationNsc, 0x00, sizeof(DSL_G997_BitAllocationNsc_t));
	memset(&UpStreamNSCData, 0x00, sizeof(DSL_uint8_t) * DSL_MAX_NSC);
	bitAllocationNsc.nDirection = DSL_UPSTREAM;
	ioctl(fd, DSL_FIO_G997_BIT_ALLOCATION_NSC_GET, &bitAllocationNsc);
	for (i = 0; i < bitAllocationNsc.data.bitAllocationNsc.nNumData; i++) {
		UpStreamNSCData[i] =
		    bitAllocationNsc.data.bitAllocationNsc.nNSCData[i];
	}

	memset(&bitAllocationNsc, 0x00, sizeof(DSL_G997_BitAllocationNsc_t));
	memset(&DownStreamNSCData, 0x00, sizeof(DSL_uint8_t) * DSL_MAX_NSC);
	bitAllocationNsc.nDirection = DSL_DOWNSTREAM;
	ioctl(fd, DSL_FIO_G997_BIT_ALLOCATION_NSC_GET, &bitAllocationNsc);
	for (i = 0; i < bitAllocationNsc.data.bitAllocationNsc.nNumData; i++) {
		DownStreamNSCData[i] =
		    bitAllocationNsc.data.bitAllocationNsc.nNSCData[i];
	}

	for (i = 0; i < DSL_MAX_NSC; i++) {
		if (i < 64) {
			ifx_httpdWrite(wp,
				       T
				       ("<tr><td>%d</td><td>%d</td><td>%d</td></tr>"),
				       i, UpStreamNSCData[i],
				       DownStreamNSCData[i]);
		} else {
			ifx_httpdWrite(wp,
				       T
				       ("<tr><td>%d</td><td>0</td><td>%d</td></tr>"),
				       i, DownStreamNSCData[i]);
		}
	}

	// close device
	close(fd);

#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	}
#endif
	return DSL_SUCCESS;
}

int ifx_cgi_adsl_phyconfig_initdata(int eid, httpd_t wp,
				    int argc, char_t ** argv)
{
	// init adsl_mode
	char_t sValue[MAX_PARAMETER_KEY_LEN];
	// int i;
	// int nSelIdx = 0;
	int ret = 0;
	int fd = 0;
	uint32 outFlag = IFX_F_DEFAULT;
	char_t fw_type[8] = { 0 };
	DSL_G997_PowerManagementStatus_t pwrMngStatus;
	DSL_TestModeControl_t testModeCtrl;
	char dev_name[64];
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	int dsl_line = 0;
#endif

	if (ifx_GetObjData
	    (FILE_SYSTEM_STATUS, "dsl_fw_type", "type", IFX_F_DEFAULT, &outFlag,
	     fw_type) != IFX_SUCCESS) {
		return IFX_FAILURE;
	}

	memset(sValue, 0x00, MAX_PARAMETER_KEY_LEN);
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_ADSL_PHY, "ADSL_MODE", sValue) ==
	    1) {
		ifx_httpdWrite(wp, T("var adsl_mode=\"%s\";\n"), sValue);
	} else {
		if (!gstrcmp(fw_type, "a")) {
#if defined PLATFORM_VR9
			ifx_httpdWrite(wp, T("var adsl_mode=\"04_00_04_00_0C_01_00_00\";\n"));
#else
			ifx_httpdWrite(wp, T("var adsl_mode=\"05_00_04_00_0C_01_00_00\";\n"));
#endif
   		} else if(!gstrcmp(fw_type,"b")){ //Default xTSE value is same for VRX and ARX in case of FW "B"
	       	ifx_httpdWrite(wp,T("var adsl_mode=\"10_00_10_00_00_04_00_00\";\n")); 
		}
	}

#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	for (dsl_line = 0; dsl_line <= 1; dsl_line++) 
	{
	sprintf(dev_name, DSL_CPE_DEVICE_NAME"/%d", dsl_line);
#else
	sprintf(dev_name, DSL_CPE_DEVICE_NAME);
#endif
	fd = open(dev_name, O_RDWR);
	if (fd < 0) {
		ifx_httpdWrite(wp, T("cannot open device %s"),
			       dev_name);
	}
	// test_mode_control
	memset(&testModeCtrl, 0x00, sizeof(DSL_TestModeControl_t));
	ret = ioctl(fd, DSL_FIO_TEST_MODE_STATUS_GET, &testModeCtrl);
	if (ret < 0) {
		ifx_httpdWrite(wp, T("var testmode_control=\"Disable\";\n"));
	} else {
		switch (testModeCtrl.data.nTestMode) {
		case DSL_TESTMODE_DISABLE:
			ifx_httpdWrite(wp,
				       T
				       ("var testmode_control=\"Disable\";\n"));
			break;
		case DSL_TESTMODE_SHOWTIME_LOCK:
			ifx_httpdWrite(wp,
				       T
				       ("var testmode_control=\"ShowTimeLock\";\n"));
			break;
		case DSL_TESTMODE_QUIET:
			ifx_httpdWrite(wp,
				       T
				       ("var testmode_control=\"QuietMode\";\n"));
			break;
		default:
			ifx_httpdWrite(wp,
				       T
				       ("var testmode_control=\"Disable\";\n"));
			break;
		}
	}

	// init power_management_control
	memset(&pwrMngStatus, 0x00, sizeof(DSL_G997_PowerManagementStatus_t));
	ret =
	    ioctl(fd, DSL_FIO_G997_POWER_MANAGEMENT_STATUS_GET, &pwrMngStatus);
	if (ret < 0) {
		ifx_httpdWrite(wp,
			       T("var power_management_control=\"PMCL0\";\n"));
	} else {
		switch (pwrMngStatus.data.nPowerManagementStatus) {
		case DSL_G997_PMS_L0:
			ifx_httpdWrite(wp,
				       T
				       ("var power_management_control=\"PMCL0\";\n"));
			break;
		case DSL_G997_PMS_L2:
			ifx_httpdWrite(wp,
				       T
				       ("var power_management_control=\"PMCL2\";\n"));
			break;
		case DSL_G997_PMS_L3:
			ifx_httpdWrite(wp,
				       T
				       ("var power_management_control=\"PMCL3\";\n"));
			break;
		default:
			ifx_httpdWrite(wp,
				       T
				       ("var power_management_control=\"PMCL0\";\n"));
			break;
		}
	}
	close(fd);
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	}
#endif
	return 0;
}

int ifx_cgi_adsl_phyconfig_set_testmode_control(httpd_t wp, int type)
{
	int ret = 0;
	int fd = 0;
	/* Testmode Control */
	DSL_TestModeControl_t testModeCtrl;

	char dev_name[64];
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	int dsl_line = 0;
	for (dsl_line = 0; dsl_line <= 1; dsl_line++) 
	{
	sprintf(dev_name, DSL_CPE_DEVICE_NAME"/%d", dsl_line);
#else
	sprintf(dev_name, DSL_CPE_DEVICE_NAME);
#endif
	// DSL_Open
	fd = open(dev_name, O_RDWR);
	if (fd < 0) {
		IFX_DBG("cannot open device %s", dev_name);
		close(fd);
		return DSL_ERROR;
	}
	memset(&testModeCtrl, 0x00, sizeof(DSL_TestModeControl_t));

	switch (type) {
	case 0:
		testModeCtrl.data.nTestMode = DSL_TESTMODE_SHOWTIME_LOCK;
		ret = ioctl(fd, DSL_FIO_TEST_MODE_CONTROL_SET, &testModeCtrl);
		if (ret < 0) {
			IFX_DBG("Fail to enable showtime lock.");
			close(fd);
			return DSL_ERROR;
		}
		break;
	case 1:
		testModeCtrl.data.nTestMode = DSL_TESTMODE_QUIET;
		ret = ioctl(fd, DSL_FIO_TEST_MODE_CONTROL_SET, &testModeCtrl);
		if (ret < 0) {
			IFX_DBG("Fail to enable quiet mode.");
			close(fd);
			return DSL_ERROR;
		}
		break;
	case 2:
		testModeCtrl.data.nTestMode = DSL_TESTMODE_DISABLE;
		ret = ioctl(fd, DSL_FIO_TEST_MODE_CONTROL_SET, &testModeCtrl);
		if (ret < 0) {
			IFX_DBG("Fail to disable testmode.");
			close(fd);
			return DSL_ERROR;
		}
		break;
	}
	// close device
	close(fd);
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	}
#endif
	return DSL_SUCCESS;
}

/* Power Management Control */
DSL_G997_PowerManagementStateForcedTrigger_t pwrMngStateForcedTrigger;
int ifx_cgi_adsl_phyconfig_set_power_management_control(httpd_t wp, int type)
{
	int ret = 0;
	int fd = 0;

	char dev_name[64];
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	int dsl_line = 0;
	for (dsl_line = 0; dsl_line <= 1; dsl_line++) 
	{
	sprintf(dev_name, DSL_CPE_DEVICE_NAME"/%d", dsl_line);
#else
	sprintf(dev_name, DSL_CPE_DEVICE_NAME);
#endif
	// DSL_Open
	fd = open(dev_name, O_RDWR);
	if (fd < 0) {
		IFX_DBG("cannot open device %s", dev_name);
		close(fd);
		return DSL_ERROR;
	}
	memset(&pwrMngStateForcedTrigger, 0x00,
	       sizeof(DSL_G997_PowerManagementStateForcedTrigger_t));
	switch (type) {
	case 0:
		pwrMngStateForcedTrigger.data.nPowerManagementState =
		    DSL_G997_PMSF_L0_TO_L2;
		ret =
		    ioctl(fd,
			  DSL_FIO_G997_POWER_MANAGEMENT_STATE_FORCED_TRIGGER,
			  &pwrMngStateForcedTrigger);
		if (ret < 0) {
			IFX_DBG("Fail to force into L2 low power state!");
			close(fd);
			return DSL_ERROR;
		}
		break;
	case 1:
		pwrMngStateForcedTrigger.data.nPowerManagementState =
		    DSL_G997_PMSF_LX_TO_L3;
		ret =
		    ioctl(fd,
			  DSL_FIO_G997_POWER_MANAGEMENT_STATE_FORCED_TRIGGER,
			  &pwrMngStateForcedTrigger);
		if (ret < 0) {
			IFX_DBG("Fail to force into L3 idle state!");
			close(fd);
			return DSL_ERROR;
		}
		break;
	case 2:
		pwrMngStateForcedTrigger.data.nPowerManagementState =
		    DSL_G997_PMSF_L3_TO_L0;
		ret =
		    ioctl(fd,
			  DSL_FIO_G997_POWER_MANAGEMENT_STATE_FORCED_TRIGGER,
			  &pwrMngStateForcedTrigger);
		if (ret < 0) {
			IFX_DBG("Fail to force into L0 full-on state !");
			close(fd);
			return DSL_ERROR;
		}
		break;
	}
	// close device
	close(fd);
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	}
#endif
	return DSL_SUCCESS;
}

int ifx_cgi_adsl_phyconfig_set_rate_adaptaion_config(httpd_t wp, int ra_ena)
{
	int ret = 0;
	int fd = 0;
	int direction = 0;
	DSL_G997_RateAdaptationConfig_t raConfig;

	char dev_name[64];
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	int dsl_line = 0;
	for (dsl_line = 0; dsl_line <= 1; dsl_line++) 
	{
	sprintf(dev_name, DSL_CPE_DEVICE_NAME"/%d", dsl_line);
#else
	sprintf(dev_name, DSL_CPE_DEVICE_NAME);
#endif
	// DSL_Open
	fd = open(dev_name, O_RDWR);
	if (fd < 0) {
		IFX_DBG("cannot open device %s", dev_name);
		close(fd);
		return DSL_ERROR;
	}
	for (direction = 0; direction <= 1; direction++) {
		memset(&raConfig, 0x00,
		       sizeof(DSL_G997_RateAdaptationConfig_t));
		raConfig.nDirection = direction;
		if (ra_ena)
			raConfig.data.RA_MODE = DSL_G997_RA_MODE_DYNAMIC;
		else
			raConfig.data.RA_MODE = DSL_G997_RA_MODE_AT_INIT;

		IFX_DBG("Rate Adaptation Config: [Direction:%u, RAEna:%u]",
			raConfig.nDirection, raConfig.data.RA_MODE);
		ret =
		    ioctl(fd, DSL_FIO_G997_RATE_ADAPTATION_CONFIG_SET,
			  (int)&raConfig);
		if (ret < 0) {
			IFX_DBG("Failed to Set Rate Adaption Config");
			close(fd);
			return DSL_ERROR;
		}
	}
	// close device
	close(fd);
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	}
#endif
	return DSL_SUCCESS;
}

int ifx_cgi_adsl_phyconfig_set_line_feature_data(httpd_t wp, int bs_ena,
						 int retx_ena)
{
	int ret = 0;
	int fd = 0;
	int direction = 0;
	DSL_LineFeature_t lineFeatureData;

	char dev_name[64];
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	int dsl_line = 0;
	for (dsl_line = 0; dsl_line <= 1; dsl_line++) 
	{
	sprintf(dev_name, DSL_CPE_DEVICE_NAME"/%d", dsl_line);
#else
	sprintf(dev_name, DSL_CPE_DEVICE_NAME);
#endif
	// DSL_Open
	fd = open(dev_name, O_RDWR);
	if (fd < 0) {
		IFX_DBG("cannot open device %s", dev_name);
		close(fd);
		return DSL_ERROR;
	}
	for (direction = 0; direction <= 1; direction++) {
		memset(&lineFeatureData, 0x00, sizeof(DSL_LineFeature_t));
		lineFeatureData.nDirection = direction;
		ret =
		    ioctl(fd, DSL_FIO_LINE_FEATURE_CONFIG_GET,
			  (int)&lineFeatureData);
		if (ret < 0) {
			IFX_DBG("Fail to get Line Feature Data");
			close(fd);
			return DSL_ERROR;
		} else {
			lineFeatureData.data.bBitswapEnable = bs_ena;
			lineFeatureData.data.bReTxEnable = retx_ena;
			IFX_DBG
			    ("Line Feature Config: [Direction:%u, TrellisEna:%u, BitSwapEna:%u, Re-TxEna:%u, VirtNoiseSupport:%u]",
			     lineFeatureData.nDirection,
			     lineFeatureData.data.bTrellisEnable,
			     lineFeatureData.data.bBitswapEnable,
			     lineFeatureData.data.bReTxEnable,
			     lineFeatureData.data.bVirtualNoiseSupport);
			ret =
			    ioctl(fd, DSL_FIO_LINE_FEATURE_CONFIG_SET,
				  (int)&lineFeatureData);
			if (ret < 0) {
				IFX_DBG
				    ("Failed to Set BitSwap in Line Feature Config");
				close(fd);
				return DSL_ERROR;
			}
		}
	}
	// close device
	close(fd);
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	}
#endif
	return DSL_SUCCESS;
}

#ifdef CONFIG_FEATURE_VDSL_VECTORING
int adsl_phyconfig_dsm_config_set(httpd_t wp, int vect_ena)
{
	int ret = 0, mei_fd;
	IOCTL_MEI_dsmConfig_t pData;
	int device = 0;
	DSL_char_t dev_name[32] = {0};

#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	for (device = 0; device <= 1; device++) 
	{
#endif
	sprintf(dev_name, "/dev/mei_cpe/%u", device);

    mei_fd = open(dev_name, O_RDWR);
	if (mei_fd < 0) {
		IFX_DBG("cannot open device %s", dev_name);
		close(mei_fd);
		return DSL_ERROR;
	}

	memset(&pData, 0x0, sizeof(IOCTL_MEI_dsmConfig_t));
	pData.eVectorControl = vect_ena;
	
	ret = ioctl(mei_fd, FIO_MEI_DSM_CONFIG_SET, (int)&pData);
	if (ret < 0) {
		IFX_DBG("Failed to Set DSM Config");
		close(mei_fd);
		return DSL_ERROR;
	}
	// close device
	close(mei_fd);
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	}
#endif
	return DSL_SUCCESS;
}
#endif

int ifx_cgi_adsl_phyconfig_autoboot_control_set()
{
	int ret = 0;
	int fd = 0;
	DSL_AutobootControl_t pData;

	char dev_name[64];
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	int dsl_line = 0;
	for (dsl_line = 0; dsl_line <= 1; dsl_line++) 
	{
	sprintf(dev_name, DSL_CPE_DEVICE_NAME"/%d", dsl_line);
#else
	sprintf(dev_name, DSL_CPE_DEVICE_NAME);
#endif
	// DSL_Open
	fd = open(dev_name, O_RDWR);
	if (fd < 0) {
		IFX_DBG("cannot open device %s", dev_name);
		close(fd);
		return DSL_ERROR;
	}

	memset(&pData, 0x0, sizeof(DSL_AutobootControl_t));
	pData.data.nCommand = 2;
	ret = ioctl(fd, DSL_FIO_AUTOBOOT_CONTROL_SET, (int)&pData);
	if (ret < 0) {
		IFX_DBG("Failed to Set BitSwap in Line Feature Config");
		close(fd);
		return DSL_ERROR;
	}
	// close device
	close(fd);
#ifdef CONFIG_FEATURE_DSL_BONDING_SUPPORT
	}
#endif
	return DSL_SUCCESS;
}

int ifx_get_firmware_type(int eid, httpd_t wp, int argc, char_t ** arg_v)
{
	char_t fw_type[8] = { 0 };
	uint32 outFlag = IFX_F_DEFAULT;
	char_t *name = NULL;

	ifx_httpd_parse_args(argc, arg_v, T("%s"), &name);
	if (name != NULL) {
		if (!gstrcmp(name, "v_fw_type")) {
			if (ifx_GetObjData
		    	(FILE_SYSTEM_STATUS, "dsl_fw_type", name, IFX_F_DEFAULT, &outFlag, fw_type) != IFX_SUCCESS) {
				return IFX_FAILURE;
			}
			ifx_httpdWrite(wp, T("%s"), fw_type);
			return IFX_SUCCESS;
		}
	}
	if (ifx_GetObjData
	    (FILE_SYSTEM_STATUS, "dsl_fw_type", "type", IFX_F_DEFAULT, &outFlag,
	     fw_type) != IFX_SUCCESS) {
		return IFX_FAILURE;
	}

	if (!gstrcmp(fw_type, "a")) {
		ifx_httpdWrite(wp, T("%s"), "a");
		return IFX_SUCCESS;
	} else if (!gstrcmp(fw_type, "b")) {
		ifx_httpdWrite(wp, T("%s"), "b");
		return IFX_SUCCESS;
	}

	return IFX_SUCCESS;
}

int ifx_get_adsl_phyconfig(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_PARAMETER_KEY_LEN];
	char_t *name = NULL;
	uint32 outFlag = IFX_F_DEFAULT;
	char_t fw_type[8] = { 0 };

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	
	memset(sValue, 0x00, MAX_PARAMETER_KEY_LEN);
	if (ifx_GetObjData
	    (FILE_RC_CONF, TAG_ADSL_PHY, name, IFX_F_DEFAULT, &outFlag,
	     sValue) != IFX_SUCCESS) {
	}

	if (ifx_GetObjData(FILE_SYSTEM_STATUS, "dsl_fw_type", "type", IFX_F_DEFAULT, &outFlag,fw_type) != IFX_SUCCESS) {
		ifx_httpdWrite(wp, T("\"%d\""), -1); 
		return -1;
	}

	if (!gstrcmp(name, "xDSL_MODE")) {
		if (!gstrcmp(sValue, "Multimode-xDSL"))
			ifx_httpdWrite(wp, T("\"%d\""), 0);
		else if (!gstrcmp(sValue, "ansi_t1.413"))
			ifx_httpdWrite(wp, T("\"%d\""), 1);
		else if (!gstrcmp(sValue, "adsl_g.dmt"))
			ifx_httpdWrite(wp, T("\"%d\""), 2);
		else if (!gstrcmp(sValue, "adsl"))
			ifx_httpdWrite(wp, T("\"%d\""), 2);
		else if (!gstrcmp(sValue, "adsl2"))
			ifx_httpdWrite(wp, T("\"%d\""), 3);
		else if (!gstrcmp(sValue, "adsl2+"))
			ifx_httpdWrite(wp, T("\"%d\""), 4);
		else if (!gstrcmp(sValue, "vdsl2"))
			ifx_httpdWrite(wp, T("\"%d\""), 5);
		else if (!gstrcmp(sValue, "Multimode-ADSL"))
			ifx_httpdWrite(wp, T("\"%d\""), 6);
	} else
		ifx_httpdWrite(wp, T("%s"), sValue);
	return 0;
}

void ifx_cgi_adsl_phyconfig(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pSubmit_Action;
	bool_t bRebootFlag = 0;
	int nRetVal = 0;
	int32 ret = IFX_SUCCESS;
	char_t fw_type[8] = { 0 };
	bool flag=0;

	pSubmit_Action = ifx_httpdGetVar(wp, T("submit_action"), T(""));

	if (!gstrcmp(pSubmit_Action, T("get_bat"))) {
		websNextPage(wp);
		return;
	} else {
		char_t *pAdsl_Mode, sAct_Mode[MAX_PARAMETER_KEY_LEN], sAdsl_Mode[40];
		char_t *pVdsl_Mode, sVdsl_Mode[MAX_PARAMETER_KEY_LEN];
		char_t sDSL_Mode[MAX_PARAMETER_KEY_LEN], sTmp_DSL_Str[MAX_PARAMETER_KEY_LEN];
		char_t sADSL_Mode[MAX_PARAMETER_KEY_LEN], sTmp_ADSL_Str[MAX_PARAMETER_KEY_LEN];
		char_t  sValue[MAX_PARAMETER_KEY_LEN];
		char8 sStored_Value[MAX_PARAMETER_KEY_LEN], sStored_Retx_Value[MAX_PARAMETER_KEY_LEN];
		char8 buf[MAX_FILELINE_LEN], sConf_Buf[MAX_PARAMETER_KEY_LEN];
		
		int retx_ret;
		uint32 outFlag = IFX_F_DEFAULT;

		memset(sAdsl_Mode, 0x00, MAX_PARAMETER_KEY_LEN);
		memset(sAct_Mode, 0x00, MAX_PARAMETER_KEY_LEN);

		memset(sVdsl_Mode, 0x00, MAX_PARAMETER_KEY_LEN);
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_ADSL_PHY, "VDSL_MODE", IFX_F_DEFAULT,
		     &outFlag, sVdsl_Mode) != IFX_SUCCESS) {
			return;
		}

		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_ADSL_PHY, "ADSL_MODE", IFX_F_DEFAULT,
		     &outFlag, sAdsl_Mode) != IFX_SUCCESS) {
			return;
		}

		if (ifx_GetObjData
		    (FILE_SYSTEM_STATUS, "dsl_fw_type", "type", IFX_F_DEFAULT,
		     &outFlag, fw_type) != IFX_SUCCESS) {
			return;
		}

		pAdsl_Mode = ifx_httpdGetVar(wp, T("adslmode"), T(""));
		switch (atoi(pAdsl_Mode)) {
		case 0:    //Multimode-xDSL  
			sprintf(sAct_Mode, "xDSL_MODE=\"Multimode-xDSL\"\n");
			if (!gstrcmp(fw_type, "a")) {

#if defined PLATFORM_VR9
   				sprintf(sAdsl_Mode, "%s", "ADSL_MODE=\"04_00_04_00_0C_01_00_07\"\n");
#endif
			}
   			else if(!gstrcmp(fw_type,"b")) //Added Multimode-xDSL for fw "b". Need to check whether it is appropriate
            {
  				sprintf(sAdsl_Mode, "%s", "ADSL_MODE=\"10_00_10_00_00_04_00_07\"\n");
   			}  

			sprintf(sVdsl_Mode, "%s",
				"VDSL_MODE=\"0_0_0_0_0_0_0_7\"\n");
			flag = 1;
			break;
		case 1:
			sprintf(sAct_Mode, "xDSL_MODE=\"ansi_t1.413\"\n");
			break;
		case 2:
			if (!gstrcmp(fw_type, "b"))
				sprintf(sAct_Mode, "xDSL_MODE=\"adsl\"\n");
			else
				sprintf(sAct_Mode,
					"xDSL_MODE=\"adsl_g.dmt\"\n");
			break;
		case 3:
			sprintf(sAct_Mode, "xDSL_MODE=\"adsl2\"\n");
			break;
		case 4:
			sprintf(sAct_Mode, "xDSL_MODE=\"adsl2+\"\n");
			break;
		case 5:
			sprintf(sAct_Mode, "xDSL_MODE=\"vdsl2\"\n");
			memset(sValue, 0x00, MAX_PARAMETER_KEY_LEN);
			memset(sAdsl_Mode, 0x00, MAX_PARAMETER_KEY_LEN);
			if (ifx_GetCfgData
			    (FILE_RC_CONF, TAG_ADSL_PHY, "ADSL_MODE",
			     sValue) == 1) {
				snprintf(sAdsl_Mode, sizeof(sAdsl_Mode),
					 T("ADSL_MODE=\"%s\"\n"), sValue);

			} else {
   				sprintf(sAdsl_Mode, "%s", "ADSL_MODE=\"00_00_00_00_00_00_00_07\"\n");
			}

			pVdsl_Mode = ifx_httpdGetVar(wp, T("adsl_mode"), T(""));
			gsprintf(sVdsl_Mode, T("VDSL_MODE=\"%s\"\n"),
				 pVdsl_Mode);
			flag = 1;
			break;
		case 6:
			sprintf(sAct_Mode, "xDSL_MODE=\"Multimode-ADSL\"\n");
			if (!gstrcmp(fw_type, "a")) {
#if defined PLATFORM_VR9
   				sprintf(sAdsl_Mode, "%s", "ADSL_MODE=\"05_00_04_00_0C_01_00_00\"\n");
#else
   				sprintf(sAdsl_Mode, "%s", "ADSL_MODE=\"05_00_04_00_0C_01_00_00\"\n");
#endif
  			}else if(!gstrcmp(fw_type,"b")) {//Default xTSE value is same for VRX and ARX in case of FW "B" 
   			 	sprintf(sAdsl_Mode, "%s", "ADSL_MODE=\"10_00_10_00_00_04_00_00\"\n");
			}
			sprintf(sVdsl_Mode, "%s",
				"VDSL_MODE=\"0_0_0_0_0_0_0_0\"\n");
			flag = 1;
			break;

		}

		if(flag == 0) {
			memset(sValue, 0x00, MAX_PARAMETER_KEY_LEN);
			memset(sVdsl_Mode, 0x00, MAX_PARAMETER_KEY_LEN);
			if (ifx_GetCfgData
			    (FILE_RC_CONF, TAG_ADSL_PHY, "VDSL_MODE",
			     sValue) == 1) {
				snprintf(sVdsl_Mode, sizeof(sVdsl_Mode),
					 T("VDSL_MODE=\"%s\"\n"), sValue);
			} else {
				gsprintf(sVdsl_Mode, "%s",
					 "VDSL_MODE=\"0_0_0_0_0_0_0_0\"\n");
			}

			pAdsl_Mode = ifx_httpdGetVar(wp, T("adsl_mode"), T(""));
			gsprintf(sAdsl_Mode, T("ADSL_MODE=\"%s\"\n"),
				 pAdsl_Mode);
		}
		memset(sDSL_Mode, 0x00, MAX_PARAMETER_KEY_LEN);
		memset(sTmp_DSL_Str, 0x00, MAX_PARAMETER_KEY_LEN);
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_ADSL_PHY, "xDSL_MODE", IFX_F_DEFAULT,
		     &outFlag, sDSL_Mode) == IFX_SUCCESS) {
			snprintf(sTmp_DSL_Str, sizeof(sTmp_DSL_Str),
				 "xDSL_MODE=\"%s\"\n", sDSL_Mode);
		} else {
			return;
		}
		memset(sADSL_Mode, 0x00, MAX_PARAMETER_KEY_LEN);
		memset(sTmp_ADSL_Str, 0x00, MAX_PARAMETER_KEY_LEN);
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_ADSL_PHY, "ADSL_MODE", IFX_F_DEFAULT,
		     &outFlag, sADSL_Mode) == IFX_SUCCESS) {
			snprintf(sTmp_ADSL_Str, sizeof(sTmp_ADSL_Str),
				 "ADSL_MODE=\"%s\"\n", sADSL_Mode);
		} else {
			return;
		}
		if ((gstrcmp(sTmp_DSL_Str, sAct_Mode) != 0)
		    || (gstrcmp(sTmp_ADSL_Str, sAdsl_Mode) != 0)) {
			IFX_DBG("1) REBOOT FLAG IS SET\n");
			bRebootFlag = 1;
		}

		// Check: ADSL_MODE is modified?
		IFX_DBG(" String Read from rc.conf [%s]\n", sADSL_Mode);
		IFX_DBG(" String Read from web [%s]\n", pAdsl_Mode);
 		if ((gstrcmp(sADSL_Mode, pAdsl_Mode) != 0)) {
			IFX_DBG("2) REBOOT FLAG IS SET\n");
			bRebootFlag = 1;
		} 

		memset(buf, 0x0, MAX_FILELINE_LEN);
		/* -----------------Test Mode Control Start -------- */
		memset(sStored_Value, 0x00, MAX_PARAMETER_KEY_LEN);
		if (ifx_GetObjData(FILE_RC_CONF, TAG_ADSL_PHY, "CNTL_MODE_ENA", IFX_F_DEFAULT,
		     &outFlag, sStored_Value) == IFX_SUCCESS) {

			int32 nCfgd_Cntl_Mode_ena;
			nCfgd_Cntl_Mode_ena = atoi(ifx_httpdGetVar(wp, T("cntl_mode_enable"), T("")));
			if(nCfgd_Cntl_Mode_ena != atoi(sStored_Value)) {
				memset(sConf_Buf, 0x0, MAX_PARAMETER_KEY_LEN);
				sprintf(sConf_Buf, "CNTL_MODE_ENA=\"%d\"\n", nCfgd_Cntl_Mode_ena);
				LTQ_STRNCAT(buf, sConf_Buf, sizeof(sConf_Buf));

				int32 nCfgd_cntl_mode_val;
				nCfgd_cntl_mode_val = atoi(ifx_httpdGetVar(wp, T("cntl_mode"), T("")));

				memset(sStored_Value, 0x00, MAX_PARAMETER_KEY_LEN);
				if(ifx_GetObjData(FILE_RC_CONF, TAG_ADSL_PHY, "CNTL_MODE",
					     IFX_F_DEFAULT, &outFlag, sStored_Value) != IFX_SUCCESS) {
					COPY_TO_STATUS("%s",
						       "<font class=\"textTitle\">Error:Failed to GET Value for Test Mode Control</font>");
					ifx_httpdRedirect(wp, "err_page.html");
					return;
				}
				else {
					if(atoi(sStored_Value) != nCfgd_cntl_mode_val) {
						nRetVal = ifx_cgi_adsl_phyconfig_set_testmode_control (wp, nCfgd_cntl_mode_val);
						if (nRetVal < 0) {
							COPY_TO_STATUS("%s",
							       "<font class=\"textTitle\">Error:Failed to SET Test Mode Control</font>");
							ifx_httpdRedirect(wp, "err_page.html");
							return;
						}
						else {
							memset(sConf_Buf, 0x0, MAX_PARAMETER_KEY_LEN);
							sprintf(sConf_Buf, "CNTL_MODE=\"%d\"\n", nCfgd_cntl_mode_val);
							LTQ_STRNCAT(buf, sConf_Buf, sizeof(sConf_Buf));
						}
					}
				}
			}
		} 
		else {
			COPY_TO_STATUS("%s",
						       "<font class=\"textTitle\">Error:Failed to GET Value for Test Mode Control</font>");
					ifx_httpdRedirect(wp, "err_page.html");
					return;
		}

		/* ----------------- Bit Swap and ReTx Start-------------------- */
		memset(sStored_Value, 0x00, MAX_PARAMETER_KEY_LEN);
		memset(sStored_Retx_Value, 0x00, MAX_PARAMETER_KEY_LEN);
		nRetVal = ifx_GetObjData(FILE_RC_CONF, TAG_ADSL_PHY, "BS_ENA", IFX_F_DEFAULT, &outFlag, sStored_Value);
		retx_ret = ifx_GetObjData(FILE_RC_CONF, TAG_ADSL_PHY, "RETX_ENA", IFX_F_DEFAULT, &outFlag, sStored_Retx_Value);
		if ((nRetVal == IFX_SUCCESS) || (retx_ret == IFX_SUCCESS)) {
			int32 nCfgd_bs_ena = 0;
			int32 nCfgd_retx_ena = 0;
			nCfgd_bs_ena = atoi(ifx_httpdGetVar (wp, T("bitswap_enable"), T("")));
			if(ifx_httpdGetVar (wp, T("retx_enable"), T("")) != NULL)
				nCfgd_retx_ena = atoi(ifx_httpdGetVar (wp, T("retx_enable"), T("")));
			else
				nCfgd_retx_ena = atoi(sStored_Retx_Value);

			if((atoi(sStored_Value) != nCfgd_bs_ena) || (atoi(sStored_Retx_Value) != nCfgd_retx_ena)) {
				nRetVal = ifx_cgi_adsl_phyconfig_set_line_feature_data (wp, nCfgd_bs_ena, nCfgd_retx_ena); 
				if (nRetVal < 0) {
					COPY_TO_STATUS("%s",
						       "<font class=\"textTitle\">Error:Failed to Configure Line Feature Data</font>");
					ifx_httpdRedirect(wp, "err_page.html");
					return;
				} 
				memset(sConf_Buf, 0x0, MAX_PARAMETER_KEY_LEN);
				sprintf(sConf_Buf, "BS_ENA=\"%d\"\n", nCfgd_bs_ena);
				LTQ_STRNCAT(buf, sConf_Buf, sizeof(sConf_Buf));

				memset(sConf_Buf, 0x0, MAX_PARAMETER_KEY_LEN);
				sprintf(sConf_Buf, "RETX_ENA=\"%d\"\n",	nCfgd_retx_ena);
				LTQ_STRNCAT(buf, sConf_Buf, sizeof(sConf_Buf));
			}
		}
		else {
				COPY_TO_STATUS("%s", "<font class=\"textTitle\">Error:Failed to get BitSwap or Retransmission Configuration</font>");
				ifx_httpdRedirect(wp, "err_page.html");
				return;
		}
		/* ----------------- Bit Swap and Retx End -------------------- */

#ifndef PLATFORM_VR9
		/* ----------------- SRA Start --------------------------- */
		memset(sStored_Value, 0x00, MAX_PARAMETER_KEY_LEN);
		if (ifx_GetObjData (FILE_RC_CONF, TAG_ADSL_PHY, "SRA_ENA", IFX_F_DEFAULT,
		     &outFlag, sStored_Value) == IFX_SUCCESS) {
			int32 nCfgd_SRA=0;
			nCfgd_SRA = atoi(ifx_httpdGetVar(wp, T("sra_enable"), T("")));
			if ( nCfgd_SRA != (atoi(sStored_Value))) {
				nRetVal = ifx_cgi_adsl_phyconfig_set_rate_adaptaion_config (wp, nCfgd_SRA);
				if (nRetVal < 0) {
					COPY_TO_STATUS("%s",
						       "<font class=\"textTitle\">Error:Failed to Configure SRA</font>");
					ifx_httpdRedirect(wp, "err_page.html");
					return;
				}
				memset(sConf_Buf, 0x0, MAX_PARAMETER_KEY_LEN);
				sprintf(sConf_Buf, "SRA_ENA=\"%d\"\n", nCfgd_SRA);
				LTQ_STRNCAT(buf, sConf_Buf, sizeof(sConf_Buf));
			}
		}
		else {
				COPY_TO_STATUS("%s", "<font class=\"textTitle\">Error:Failed to get SRA Configuration</font>");
				ifx_httpdRedirect(wp, "err_page.html");
				return;
		}
#endif
#ifdef CONFIG_FEATURE_VDSL_VECTORING 
		memset(sStored_Value, 0x00, MAX_PARAMETER_KEY_LEN);
		if (ifx_GetObjData (FILE_RC_CONF, TAG_ADSL_PHY, "VECT_ENA", IFX_F_DEFAULT,
		     &outFlag, sStored_Value) == IFX_SUCCESS) {
			int32 nCfgd_Vect_ena = 0;
			if (ifx_httpdGetVar(wp, T("vector_ena"), T("")) != NULL)
				nCfgd_Vect_ena = atoi(ifx_httpdGetVar(wp, T("vector_ena"), T("")));
			else
				nCfgd_Vect_ena = atoi(sStored_Value);
			if (atoi(sStored_Value) != nCfgd_Vect_ena) {
				nRetVal=adsl_phyconfig_dsm_config_set(wp, nCfgd_Vect_ena);
				if (nRetVal < 0) {
					COPY_TO_STATUS("%s", "<font class=\"textTitle\">Error:Failed to Configure Vectoring</font>");
					ifx_httpdRedirect(wp, "err_page.html");		
					return;
				}
				memset(sConf_Buf, 0x0, MAX_PARAMETER_KEY_LEN);
				sprintf(sConf_Buf, "VECT_ENA=\"%d\"\n",	nCfgd_Vect_ena);
				LTQ_STRNCAT(buf, sConf_Buf, sizeof(sConf_Buf));
			} 				
		}
		else {
				COPY_TO_STATUS("%s", "<font class=\"textTitle\">Error:Failed to get VECT Configuration</font>");
				ifx_httpdRedirect(wp, "err_page.html");
				return;
		}
#endif
			
		IFX_DBG("[%s:%d] setting [%s:%s:%s:%s]",__FUNCTION__, __LINE__, sAct_Mode, sAdsl_Mode,
			sVdsl_Mode, buf);
		nRetVal = ifx_SetObjData(FILE_RC_CONF, TAG_ADSL_PHY, IFX_F_MODIFY, 4, sAct_Mode, sAdsl_Mode, sVdsl_Mode, buf);
		if (nRetVal < 0) {
			COPY_TO_STATUS("%s", "<font class=\"textTitle\">Error:Failed to Write to Flash</font>");
			ifx_httpdRedirect(wp, "err_page.html");
			return;
		}
		// save setting
		if (ifx_flash_write() <= 0) {
			IFX_DBG("Fail to save Setting");
			COPY_TO_STATUS("%s", "<font class=\"textTitle\">Error:Failed to Save Setting </font>");
			ifx_httpdRedirect(wp, "err_page.html");
		}
		if (bRebootFlag) {
			IFX_DBG("[%s:%d]  BOOT FLAG SET\n", __FUNCTION__, __LINE__);
			reboot_status = 3;
			/*sAdsl_Mode="ADSL_MODE=\"<XTSE BITS>\"" 
			 *Actual xTSE Bits starts from Array index 11
			 */
			if(ltq_G997_XTUSystemEnablingConfigSet(&sAdsl_Mode[11]) < 0){
				IFX_DBG("[%s:%d]  G99 SET IOCTL FAILURE\n", __FUNCTION__, __LINE__);
				COPY_TO_STATUS("%s",
						"<font class=\"textTitle\">Error: G99 Annex Bit Set failed</font>");
				ifx_httpdRedirect(wp,
						"err_page.html");
				return; 
			}
			IFX_DBG("[%s:%d]  G99 SET IOCTL SUCCESS\n", __FUNCTION__, __LINE__);
			// ifx_httpdRedirect(wp, "reboot_cpe.html");	//sleep(15);
			// system("/etc/rc.d/rebootcpe.sh 10 &");
		}
		// autoboot set
		if (ifx_cgi_adsl_phyconfig_autoboot_control_set() < 0) {
			IFX_DBG("[%s:%d]  AUTOBOOT SET IOCTL FAILURE\n", __FUNCTION__, __LINE__);
			COPY_TO_STATUS("%s",
					"<font class=\"textTitle\">Error: ACS 2 failed</font>");
			ifx_httpdRedirect(wp,
					"err_page.html");
			return;
		}
		IFX_DBG("[%s:%d] AUTOBOOT SET IOCTL SUCCESS\n", __FUNCTION__, __LINE__);
		ifx_httpdRedirect(wp, T("xdsl_cfg.asp"));
	}
      IFX_Handler:
	return;
	if(ret!=IFX_SUCCESS){
	}
}

                               

#endif
#if 0
		/* -----------------Power Management Mode Starts -------- */
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_ADSL_PHY, "PWR_MODE_ENA", IFX_F_DEFAULT,
		     &outFlag, sTmp_Vals) == IFX_SUCCESS) {
			char_t *ppower_management_control;
			ppower_management_control =
			    ifx_httpdGetVar(wp, T("power_mode"), T(""));
			mode = atoi(ppower_management_control);
			sprintf(sPwr_Mode, "PWR_MODE=\"%d\"\n", mode);
			if (atoi
			    (ifx_httpdGetVar(wp, T("power_mode_enable"), T("")))
			    == 1) {
				if (ifx_GetObjData
				    (FILE_RC_CONF, TAG_ADSL_PHY, "PWR_MODE",
				     IFX_F_DEFAULT, &outFlag,
				     sTmp_Mode_Vals) == IFX_SUCCESS) {
					if (atoi(sTmp_Mode_Vals) != mode) {
						nRetVal =
						    ifx_cgi_adsl_phyconfig_set_power_management_control
						    (wp, mode);
					}
				} else
					return;
			} else if (atoi(sTmp_Vals) != 0) {
				nRetVal =
				    ifx_cgi_adsl_phyconfig_set_power_management_control
				    (wp, 2);
			}
			if (nRetVal < 0) {
				COPY_TO_STATUS("%s",
					       "<font class=\"textTitle\">Error:Failed to SET PMM Mode</font>");
				ifx_httpdRedirect(wp, "err_page.html");
			}
		}
		sprintf(sPwr_Mode_ena, "PWR_MODE_ENA=\"%d\"\n",
			atoi(ifx_httpdGetVar
			     (wp, T("power_mode_enable"), T(""))));

		sprintf(sPwr_Mode_ena, "PWR_MODE_ENA=\"%d\"\n", atoi("0"));
		sprintf(sPwr_Mode, "PWR_MODE=\"%d\"\n", atoi("0"));
#endif
#if 0 
		/* Not SET from web as of now */
		memset(sStored_Value, 0x00, MAX_PARAMETER_KEY_LEN);
		memset(sDSL_Dbg, 0x00, MAX_PARAMETER_KEY_LEN);
		if (ifx_GetObjData (FILE_RC_CONF, TAG_ADSL_PHY, "DSL_API_DEBUG", IFX_F_DEFAULT,
		     &outFlag, sStored_Value) != IFX_SUCCESS) {
			sprintf(sDSL_Dbg, "DSL_API_DEBUG=\"DISABLE\"\n");
		} else
			snprintf(sDSL_Dbg, sizeof(sDSL_Dbg), "DSL_API_DEBUG=\"%s\"\n", sDSL_Dbg_Val);
#endif

