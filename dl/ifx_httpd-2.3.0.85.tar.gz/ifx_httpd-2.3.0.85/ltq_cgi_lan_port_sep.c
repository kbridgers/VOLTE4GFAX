#include <ifx_emf.h>
#include "ifx_httpd_method.h"
#include "./ifx_amazon_cgi.h"
#include "./ifx_cgi_common.h"
#include "ifx_api_util.h"

#if defined(CONFIG_FEATURE_LTQ_VLAN_SWITCH_PORT_ISOLATION) ||  defined(CONFIG_FEATURE_LTQ_SWITCH_PORT_ISOLATION) 

extern void websNextPage(httpd_t wp);

int32 ifx_get_lan_port_conn_names(int32 eid, httpd_t wp, int32 argc, char8 ** argv)
{
	int32 i = 0, count = 0,ret = IFX_SUCCESS;
	lan_port_sep_cfg_t *lps_conn_names = NULL;
	memset(&lps_conn_names, 0x00, sizeof(lps_conn_names));
	if (mapi_lan_port_sep_info_get(&count, &lps_conn_names, IFX_F_DEFAULT) != IFX_SUCCESS) {
		ifx_httpdError(wp, 500,T("Failed to get lan port information!"));
		goto IFX_Handler;
	}
	if (count > 0 && count < 32767) {
		for (i = 0; i < count; i++) {
			ifx_httpdWrite(wp,T("\t\t\t\t\t<option name=\"intf_%s\" value=\"%s\">%s</option>"),(lps_conn_names + i)->conName,(lps_conn_names + i)->conName,(lps_conn_names + i)->conName);
		}
	}
	IFX_Handler:
	IFX_MEM_FREE(lps_conn_names)
	return ret;
}


int ltq_get_lan_port_sep(int eid, httpd_t wp, int argc, char_t ** argv)
{
        char_t sValue[MAX_FILELINE_LEN];
        lan_port_sep_status_t pSep;

        sValue[0] = '\0';

        memset(&pSep, 0x00, sizeof(pSep));

	IFX_MAPI_DEBUG(fd,"/tmp/ltq_get_lan_port_sep","");

        mapi_lan_port_sep_status_get(&pSep, IFX_F_DEFAULT);

        if (pSep.enable)          //Enable port separation
                gstrcpy(sValue, "1");
        else
                gstrcpy(sValue, "0");

        ifx_httpdWrite(wp, T("%s"), sValue);
        
	IFX_MAPI_DEBUG(fd,"/tmp/ltq_get_lan_port_sep","Status:%d",pSep.enable);

	return 0;
}

void ltq_set_lan_port_sep(httpd_t wp, char_t * path, char_t * query)
{
        char_t *pCheck, sCheck[MAX_FILELINE_LEN];

        lan_port_sep_status_t pSep;

        a_assert(wp);
        sCheck[0] = '\0';

        memset(&pSep, 0x00, sizeof(pSep));

	IFX_MAPI_DEBUG(fd,"/tmp/ltq_set_lan_port_sep","");

        // Get value from ASP file
        pCheck = ifx_httpdGetVar(wp, T("LanPortSepStatus"), T(""));

	/*Mnaohar : when lan port sep is enable or disable delete all packet filter rule*/
	int nIndex, nPacketFilter_Size = 0;
        IFX_MAPI_Firewall_PFRule *pfrules = NULL;
	ifx_mapi_get_firewall_pfrules(&nPacketFilter_Size, &pfrules,IFX_F_DEFAULT);
        for (nIndex = nPacketFilter_Size - 1; nIndex >= 0; nIndex--) {
		pfrules[nIndex].iid.config_owner = IFX_WEB;
		strcpy(pfrules[nIndex].iid.cpeId.secName,TAG_FIREWALL_PACKETFILTER);
		strcpy(pfrules[nIndex].iid.pcpeId.secName,TAG_FIREWALL_PACKETFILTER_STATUS);
		ifx_mapi_set_firewall_pfrule(IFX_OP_DEL,pfrules + nIndex,IFX_F_DELETE | IFX_F_DONT_CHECKPOINT);
	}

	IFX_MAPI_DEBUG(fd,"/tmp/ltq_set_lan_port_sep","");

        pSep.enable = atoi(pCheck);

	IFX_MAPI_DEBUG(fd,"/tmp/ltq_set_lan_port_sep","pSep.enable:%d",pSep.enable );

	mapi_lan_port_sep_status_set(&pSep, IFX_F_MODIFY);

        IFX_MAPI_DEBUG(fd,"/tmp/ltq_set_lan_port_sep","");

	websNextPage(wp);
}
#endif    //CONFIG_FEATURE_LTQ_VLAN_SWITCH_PORT_ISOLATION
