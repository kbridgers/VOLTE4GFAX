//#include <sys/syslog.h>
#include <ifx_emf.h>
#include "ifx_httpd_method.h"
#include "./ifx_amazon_cgi.h"
#include "./ifx_cgi_common.h"

//#define IFX_LOG_DEBUG

extern char *ip_to_ppp_err;
extern char *pcr_chk_err;
extern char *status_str;
extern int32 ifx_cgi_set_wan_config(int32 operation,
				    WAN_CONN_CFG * wan_conn_cfg, uint32 flags);
extern int ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);
extern int32 ifx_get_another_fvp_from_dist_fvp(char8 * secName, char8 * fName,
					       char8 * fValue, char8 * fRetName,
					       char8 * fRetValue, uint32 flags);
extern inline void ifx_check_dw_status(int *def_wan, char *DefWanRet);
extern char newconnName[MAX_CONN_NAME_LEN];
#ifdef CONFIG_PACKAGE_PPP_MOD_PPPOE
int ifx_get_wan_pppoe(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_set_wan_pppoe(httpd_t wp, char_t * path, char_t * query);
#endif

#ifdef CONFIG_PACKAGE_PPP_MOD_PPPOA
int ifx_get_wan_pppoa(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_set_wan_pppoa(httpd_t wp, char_t * path, char_t * query);
#endif

int ifx_get_wan_mode_selected();
#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
	extern pwb_cfg_t *cgi_pwb;
#endif

// wan_pppoe.asp
#if defined(CONFIG_PACKAGE_PPP_MOD_PPPOE) || defined (CONFIG_PACKAGE_PPP_MOD_PPPOA)
int ifx_get_wan_ppp(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name, sValue[MAX_FILELINE_LEN];
	int nWAN_IDX = -1;
	uint32 flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT;
	WAN_CONN_CFG wan_cfg;
	WAN_COMMON_CFG pWan;

	memset(&wan_cfg, 0x00, sizeof(wan_cfg));
	sValue[0] = '\0';

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	IFX_GET_WANPPP_SELECTED_INDEX(IFX_F_GET_ENA, outFlag, sValue, nWAN_IDX)

	name += 3;

	wan_cfg.type = WAN_TYPE_PPP;

	if (mapi_get_wan_config(nWAN_IDX, &wan_cfg, flags) != IFX_SUCCESS) {
#if !defined(PLATFORM_AMAZON_SE)
		if (!gstrcmp(name, T("Relay"))) {
			ifx_httpdWrite(wp, T("<tr>"));
			ifx_httpdWrite(wp,
				       T
				       ("<td>Relay LAN site PPPoE session</td>"));
			ifx_httpdWrite(wp,
				       T
				       ("<td><input type=\"checkbox\" name=\"relay\" value=\"1\" "));
			ifx_httpdWrite(wp, T("></td></tr>"));
		} else if (!gstrcmp(name, T("MTU"))) {
			ifx_httpdWrite(wp, "%d", 1492);
		} else {
			ifx_httpdWrite(wp, "");
		}
#endif
	} else {
		GET_WAN_COMM_PTR_1(pWan, wan_cfg)
		if (!gstrcmp(name, T("UserName")))
			ifx_httpdWrite(wp, T("%s"),
				       wan_cfg.WAN_PPP_CONN.ppp_user_name);
		else if (!gstrcmp(name, T("Password")))
			ifx_httpdWrite(wp, T("%s"),
				       wan_cfg.WAN_PPP_CONN.ppp_user_passwd);
		else if (!gstrcmp(name, T("PasswordVerify")))
			ifx_httpdWrite(wp, T("%s"),
				       wan_cfg.WAN_PPP_CONN.ppp_user_passwd);
		else if (!gstrcmp(name, T("ServiceName")))
			ifx_httpdWrite(wp, T("%s"),
				       wan_cfg.WAN_PPP_CONN.pppoe_service_name);
		else if (!gstrcmp(name, T("AccessConcentratorName")))
			ifx_httpdWrite(wp, T("%s"),
				       wan_cfg.WAN_PPP_CONN.pppoe_ac_name);
		else if (!gstrcmp(name, T("MTU")))
			ifx_httpdWrite(wp, T("%d"), pWan.max_mtu);
		else if (!gstrcmp(name, T("IdleTime")))
			ifx_httpdWrite(wp, T("%d"),
				       wan_cfg.WAN_PPP_CONN.WAN_CONN.
				       idle_disconn_time / 60);
		else if (!gstrcmp(name, T("Reconnect")))
			ifx_httpdWrite(wp, T("%d"),wan_cfg.WAN_PPP_CONN.WAN_CONN_TRIGGER);
		else if (!gstrcmp(name, T("Relay"))) {
#if !defined(PLATFORM_AMAZON_SE)
			ifx_httpdWrite(wp, T("<tr>"));
			ifx_httpdWrite(wp,
				       T
				       ("<td>Relay LAN site PPPoE session</td>"));
			ifx_httpdWrite(wp,
				       T
				       ("<td><input type=\"checkbox\" name=\"relay\" value=\"1\" "));
			ifx_httpdWrite(wp, T("%s"),
				       ((wan_cfg.WAN_PPP_CONN.conn_type ==
					 WAN_PPP_CONN_TYPE_PPPOE_RELAY) ?
					"checked" : ""));
			ifx_httpdWrite(wp, T("></td></tr>"));
#endif
		}
		else if(!gstrcmp(name, T("DNS1"))) {
			ifx_httpdWrite(wp,T("DNS = \"%s\";"),
					inet_ntoa(pWan.wandns.dns_servers[0]));
		}else if(!gstrcmp(name, T("DNS2"))) {
			ifx_httpdWrite(wp,T("DNS = \"%s\";"),
					inet_ntoa(pWan.wandns.dns_servers[1]));
                }else if(!gstrcmp(name, T("DNS_OVERRIDE"))) {
			if (pWan.wandns.DNS_override_allowed == IFX_DISABLED)
	                        ifx_httpdWrite(wp, T("checked"));
        	        else
                	        ifx_httpdWrite(wp, T(" "));
		}
	}

	return 0;
}
#endif				/*CONFIG_PACKAGE_PPP_MOD_PPPOE || CONFIG_PACKAGE_PPP_MOD_PPPOA */

// wan_pppoe.asp
#ifdef CONFIG_PACKAGE_PPP_MOD_PPPOE
int ifx_set_wan_pppoe(httpd_t wp, char_t * path, char_t * query)
{
#ifdef CONFIG_PACKAGE_RP_PPPOE
	char_t *pRelay = NULL;
#endif
	char8 *pUN = NULL, *pPWV = NULL, *pSN = NULL, *pACN = NULL;
	char8 *pMTU = NULL, *pIdle = NULL, *pReconnect = NULL, *pBridge = NULL;
	char8 sValue[20];
	char8 *pconfcon = ifx_httpdGetVar(wp, T("confconname"),T(""));
#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
	char_t igmpoldconnName[MAX_NAME_SIZE]="";
	char_t igmpnewconnName[MAX_NAME_SIZE]="";
	char sVal[MAX_DATA_LEN]="";
	int32 mcast_wan_flag;
#endif
	int32 nWAN_IDX = -1;
	int32 operation = IFX_OP_ADD, ret = IFX_SUCCESS;
	uint32 flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT, wan_cpeId =
	    0, wan_pcpeId = 0;
	/* TBD : Need IPv6 team support here
	   uint32 wan_ipv4 = 0, wan_ipv6 = 0, wan_dhcp_mode = 0, wan_iana = 0, wan_iapd = 0, wan_slaid = 0, wan_rapid = 0, wan_duid_t = 0;
	   uint32 wan_sixrd = 0;
	 */
	char8 buf_tunnel[40];
	char8 buf[MAX_NAME_SIZE];
	char8 retVal6[MAX_FILELINE_LEN];
	WAN_CONN_CFG wan_cfg;
	WAN_COMMON_CFG pWan;
	WAN_TYPE wan_type = WAN_TYPE_IP;

	/* pstWanPhy: Global WAN Mode ADSL2+, MIIO, MII1 or PTM */
	WAN_PHY_CFG pstWanPhy;
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	ifx_get_wan_phy_cfg(&pstWanPhy);

	/* nWAN_IDX: Selected WAN index being configured */
	/* TBD: this macro will return {wanip/wanppp}{index} */
	IFX_GET_WAN_SELECTED_INDEX(flags, outFlag, sValue, nWAN_IDX, wan_type)

	char_t *page = ifx_httpdGetVar(wp, T("page"), T(""));

	/* AMS */
#if 1
	char_t *pVer4 = ifx_httpdGetVar(wp, T("ipv4"), T(""));
	char_t *pVer6 = ifx_httpdGetVar(wp, T("ipv6"), T(""));
	char_t *pIntrf = ifx_httpdGetVar(wp, T("INTRF"), T(""));
	char_t *pIana_id = ifx_httpdGetVar(wp, T("IANA_ID"), T(""));
	char_t *pIapd_id = ifx_httpdGetVar(wp, T("IAPD_ID"), T(""));
	char_t *pSla_id = ifx_httpdGetVar(wp, T("SLA_ID"), T(""));
	char_t *pRapid = ifx_httpdGetVar(wp, T("RAPID"), T(""));
	char_t *pduidt = ifx_httpdGetVar(wp, T("DUID_T"), T(""));
#endif

        char_t *PDNS1 = ifx_httpdGetVar(wp, T("PDNS1"), T(""));
        char_t *PDNS2 = ifx_httpdGetVar(wp, T("PDNS2"), T(""));
        char_t *PDNS3 = ifx_httpdGetVar(wp, T("PDNS3"), T(""));
        char_t *PDNS4 = ifx_httpdGetVar(wp, T("PDNS4"), T(""));
        char_t *SDNS1 = ifx_httpdGetVar(wp, T("SDNS1"), T(""));
        char_t *SDNS2 = ifx_httpdGetVar(wp, T("SDNS2"), T(""));
        char_t *SDNS3 = ifx_httpdGetVar(wp, T("SDNS3"), T(""));
        char_t *SDNS4 = ifx_httpdGetVar(wp, T("SDNS4"), T(""));
	char_t *dns_check = ifx_httpdGetVar(wp, T("dns_check_value"), T(""));

	memset(&wan_cfg, 0x00, sizeof(wan_cfg));

	/* Fetch the user inputs from the web page */
	a_assert(wp);
	pUN = ifx_httpdGetVar(wp, T("UN"), T(""));
	pPWV = ifx_httpdGetVar(wp, T("PWV"), T(""));
	pSN = ifx_httpdGetVar(wp, T("SN"), T(""));
	pACN = ifx_httpdGetVar(wp, T("ACN"), T(""));
	pMTU = ifx_httpdGetVar(wp, T("MTU"), T(""));
	pIdle = ifx_httpdGetVar(wp, T("IDLE"), T(""));
	pBridge = ifx_httpdGetVar(wp, T("bridge_enable"), T(""));
	pReconnect = ifx_httpdGetVar(wp, T("reconnect"), T(""));
#ifdef CONFIG_PACKAGE_RP_PPPOE
	pRelay = ifx_httpdGetVar(wp, T("relay"), T(""));
#endif
	WAN_MODE WanType;
	WanType = ifx_get_wan_mode_selected();

	pWan.tunnel = 0;

	/* Check if a section is present for this index in system_status file
	 * if present the operation is Modify otherwise Add */

	if (wan_type == WAN_TYPE_IP && nWAN_IDX >= 0) {

		wan_cfg.type = wan_type;
		ret =
		    mapi_get_wan_config(nWAN_IDX, &wan_cfg, IFX_F_GET_ANY);

		if (ret != IFX_SUCCESS) {
			IFX_DBG
			    ("[%s:%d] unable to get details of existing WAN IP connection with index [%d]",
			     __FUNCTION__, __LINE__, nWAN_IDX);
			ifx_httpdError(wp, 400,
				       "Unable to get details of existing WAN IP connection with index [%d]",
				       nWAN_IDX);
			return -1;
		}
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] WAN IP get on [%d] succeeded", __FUNCTION__,
			__LINE__, nWAN_IDX);
#endif
		GET_WAN_COMM_PTR_1(pWan, wan_cfg)

		    pWan.wan_index = nWAN_IDX;

		/* Set the DELETE operation & Flags */
		operation = IFX_OP_DEL;
		flags = IFX_F_DELETE;

		/* Store the CPE & pCPE Id for this WAN Device
		 * Since this operation is a modify, we need to ADD back with the same values */
		sprintf(pWan.iid.cpeId.secName, "%s", TAG_WAN_IP);
		wan_cpeId = pWan.iid.cpeId.Id;
		sprintf(buf_tunnel, "wanip_%d_tunnel", nWAN_IDX);
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_WAN_IP, buf_tunnel, flags,
		     (IFX_OUT uint32 *) & outFlag, retVal6) == IFX_SUCCESS) {
			pWan.tunnel = atoi(retVal6);
		}
		sprintf(pWan.iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);
		wan_pcpeId = pWan.iid.pcpeId.Id;
		pWan.iid.config_owner = IFX_WEB;

		memcpy(&wan_cfg.WAN_IP_CONN.wan_cfg, &pWan, sizeof(pWan));
#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
		strcpy(igmpoldconnName,pWan.conn_name);
#endif
		ret = mapi_delete_old_virtualserver(pWan.conn_name,"modify");
		IFX_DBG("[%s:%d] virtual server ", __FUNCTION__,__LINE__);
		if (ret != IFX_SUCCESS) {
                        IFX_DBG
                            ("[%s:%d] unable to delete virtual server of wan index  with index [%d]",
                             __FUNCTION__, __LINE__, pWan.wan_index);
                        return -1;
                }

#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
		if(mapi_pwb_delentry_on_wanchange(pWan.conn_name, &cgi_pwb) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                      	IFX_DBG("delete pwb entry failed in function [%s] line [%d]  !!", __FUNCTION__, __LINE__);
#endif
                }
#endif

		/* Invoke the CGI handler function to DELETE this WAN connection */
		if (ifx_cgi_set_wan_config
		    (operation, &wan_cfg,
		     flags | IFX_F_DONT_WRITE_TO_FLASH) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "WAN[%d] couldn't be modified !!\n",
				       nWAN_IDX);
			return -1;
		}

		memset(&wan_cfg, 0x00, sizeof(wan_cfg));
		memset(&pWan, 0x00, sizeof(pWan));

		/* Populate the CPE and pCPE ID structure by Restoring the 
		 * CPE and pCPE Ids stored during DELETE of this Connection */
		sprintf(pWan.iid.cpeId.secName, "%s", TAG_WAN_PPP);
		pWan.iid.cpeId.Id = wan_cpeId;
		sprintf(pWan.iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);
		pWan.iid.pcpeId.Id = wan_pcpeId;

		/* Set the ADD Operation Flags */
		operation = IFX_OP_ADD;
		flags = IFX_F_INT_ADD;
	} else if (wan_type == WAN_TYPE_PPP && nWAN_IDX >= 0) {

		wan_cfg.type = wan_type;
		ret =
		    mapi_get_wan_config(nWAN_IDX, &wan_cfg, IFX_F_GET_ANY);

		if (ret != IFX_SUCCESS) {
			IFX_DBG
			    ("[%s:%d] unable to get details of existing WAN PPP connection with index [%d]",
			     __FUNCTION__, __LINE__, nWAN_IDX);
			ifx_httpdError(wp, 400,
				       "Unable to get details of existing WAN PPP connection with index [%d]",
				       nWAN_IDX);
			return -1;
		}
		sprintf(buf_tunnel, "wanppp_%d_tunnel", nWAN_IDX);
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_WAN_PPP, buf_tunnel, flags,
		     (IFX_OUT uint32 *) & outFlag, retVal6) == IFX_SUCCESS) {
			pWan.tunnel = atoi(retVal6);
		}

#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] WAN PPP get on [%d] succeeded", __FUNCTION__,
			__LINE__, nWAN_IDX);
#endif
		operation = IFX_OP_MOD;
		flags = IFX_F_MODIFY;

#ifdef LTQ_AEI_CUST
		/* Case of changing WAN type from PPPoE to PPPoA */
		if(wan_cfg.wancfg.ppp.wan_cfg.link_type == WAN_LINK_TYPE_PPPOATM) {
			if(mapi_wan_for_l2_get(wan_cfg.wancfg.ppp.wan_cfg.iid, &vc, &vlan_cfg) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
			    ("[%s:%d] Failed to get details of L2 for this WAN PPP connection with index [%d]",
			     __FUNCTION__, __LINE__, nWAN_IDX);
#endif
				ifx_httpdError(wp, 400,
			    "Failed to get details of L2 for this WAN PPP connection with index [%d]", nWAN_IDX);
				return -1;
			}

			/* Set link type to EoATM and encapsulation to LLC */
			vc.type = LINK_TYPE_EOATM;
			vc.encap = VC_ENCAP_LLC;

			operation = IFX_OP_MOD;
			flags = IFX_F_MODIFY;
			/* this API call would take care of updating L3 as well ! */
			if(ifx_set_vcc_cfg(operation, &vc, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("Failed to modify WAN connection to PPPoA");
#endif
				ifx_httpdError(wp, 400, "Failed to modify WAN connection to PPPoA");
				return -1;
			}
			sprintf(sValue, "WAN_VCC=\"%s\"\n", vc.l2ifname);
			SetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, IFX_F_MODIFY, 1, sValue);
		}
#endif

		GET_WAN_COMM_PTR_1(pWan, wan_cfg)

		    /* CANNOT Modify Disabled WAN Connections.
		     * These are configured from TR069 ACS and can't enable the same from Web */
		    if (pWan.f_enable == IFX_DISABLED) {
			ifx_httpdError(wp, 400,
				       "WAN[%d] is currently disabled - Can't modify !!\n",
				       nWAN_IDX);
			return -1;
		}
	} else {
		operation = IFX_OP_ADD;
		flags = IFX_F_INT_ADD;
	}

	/* Currently assume its only ADD op that is supported. Modify support TBD */
	pWan.ipv4 = atoi(pVer4);
	if (atoi(pVer6) == 2)
		pWan.ipv6 = atoi(pVer6);	/* 2 means enabled */
	else
		pWan.ipv6 = 1;	/* 1 means disabled */
	pWan.dhcp_mode = atoi(pIntrf);
	pWan.iana = atoi(pIana_id);
	pWan.iapd = atoi(pIapd_id);
	pWan.slaid = atoi(pSla_id);
	pWan.rapid = atoi(pRapid);
	pWan.duid_t = atoi(pduidt);

	/* set the link type to pppoe */
	pWan.link_type = WAN_LINK_TYPE_PPPOE;

	/* Set the wan index */
	pWan.wan_index = nWAN_IDX;

	/* TBD: decide if this needed or not */
	if (WanType == WAN_MODE_ATM || WanType == WAN_MODE_VDSL_ATM) {
		ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, "WAN_VCC",
			       IFX_F_GET_ANY, &outFlag, pWan.l2iface_name);
		if (pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2)
			pWan.wan_mode.mode = WAN_MODE_VDSL_ATM;
		else
			pWan.wan_mode.mode = WAN_MODE_ATM;
	} else if (WanType == WAN_MODE_PTM || WanType == WAN_MODE_VDSL_PTM) {
		ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, "WAN_VCC",
			       IFX_F_GET_ANY, &outFlag, pWan.l2iface_name);
		pWan.link_type = WAN_LINK_TYPE_PPPOE;
		/* TBD : This code is needed when ADSL PTM support is available on VRX platforms, take care in future */
		if (pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2)
			pWan.wan_mode.mode = WAN_MODE_VDSL_PTM;
		else
			pWan.wan_mode.mode = WAN_MODE_PTM;
	} else {

		ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, "WAN_VCC",
			       IFX_F_GET_ANY, &outFlag, pWan.l2iface_name);
		pWan.link_type = WAN_LINK_TYPE_PPPOE;

		if (strstr(pWan.l2iface_name, "eth0"))
			pWan.wan_mode.mode = WAN_MODE_ETH0;
		else if (strstr(pWan.l2iface_name, "eth1"))
			pWan.wan_mode.mode = WAN_MODE_ETH1;
		/* In case of global WAN Mode as ADSL, the user is trying to
		 * configure an Ethernet WAN Connection, we assume that it'll be over
		 * MII0 interface */
		/*else if(pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2)
		   gstrcpy(pWan.wan_mode.iface,"eth0"); */
	}

	/* get wan conn name out of wan index */
	if (operation == IFX_OP_ADD) {
#ifdef CONFIG_FEATURE_RIP
		/* Set RIP information based on the Global RIP State & Listen Mode */
		ifx_set_wanif_route_proto(nWAN_IDX, &pWan);
#endif
	}

	pWan.f_enable = IFX_ENABLED;

#ifdef CONFIG_FEATURE_NAPT
	/* Currently we set the NAT on interface level as always ENABLED 
	 * Once the interface level option is configurable, then it can be put here */
	pWan.WAN_CONN_NAT_ENABLED = IFX_ENABLED;
#endif

	if (strlen(pReconnect)) {
		if (pIdle && *pIdle)
			pWan.idle_disconn_time = 60 * gatoi(pIdle);
		else
			pWan.idle_disconn_time = 600;
	}

	pWan.max_mtu = gatoi(pMTU);

	ifx_check_dw_status(&(pWan.def_wan),
			    ifx_httpdGetVar(wp, T("def_wan"), T("")));
	sprintf(pWan.conf_conn_name,"%s" , pconfcon);


	/* set the dns override option to true */
	pWan.wandns.WAN_CONN_DNS_OVERRIDE = IFX_ENABLED;
	if(atoi(dns_check)) {
		pWan.wandns.WAN_CONN_DNS_OVERRIDE = IFX_DISABLED;
	        memset(buf, 0x00, sizeof(buf));
        	snprintf(buf, sizeof(buf), T("%s.%s.%s.%s"), PDNS1, PDNS2, PDNS3, PDNS4);
	        pWan.wandns.dns_servers[0].s_addr = inet_addr(buf);
        	memset(buf, 0x00, sizeof(buf));
	        snprintf(buf, sizeof(buf), T("%s.%s.%s.%s"), SDNS1, SDNS2, SDNS3, SDNS4);
        	pWan.wandns.dns_servers[1].s_addr = inet_addr(buf);
	}

	pWan.iid.config_owner = IFX_WEB;

#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] l2iface [%s]", __FUNCTION__, __LINE__,
		pWan.l2iface_name);
#endif

	memcpy(&wan_cfg.WAN_PPP_CONN.wan_cfg, &pWan, sizeof(pWan));

	if (atoi(pReconnect) == CONN_TRIGGER_ON_DEMAND) {
		wan_cfg.WAN_PPP_CONN.WAN_CONN_TRIGGER = CONN_TRIGGER_ON_DEMAND;

		if (pIdle && *pIdle)
			pWan.idle_disconn_time = 60 * gatoi(pIdle);
		else
			pWan.idle_disconn_time = 600;
	}else if(atoi(pReconnect) == CONN_TRIGGER_MANUAL){
		wan_cfg.WAN_PPP_CONN.WAN_CONN_TRIGGER = CONN_TRIGGER_MANUAL;
	}else
		wan_cfg.WAN_PPP_CONN.WAN_CONN_TRIGGER = CONN_TRIGGER_ALWAYS_ON;

#ifdef CONFIG_PACKAGE_RP_PPPOE
	if (strlen(pRelay) && (atoi(pRelay) == 1))
		wan_cfg.WAN_PPP_CONN.conn_type = WAN_PPP_CONN_TYPE_PPPOE_RELAY;
	else
#endif
		wan_cfg.WAN_PPP_CONN.conn_type = WAN_PPP_CONN_TYPE_IP_ROUTED;

	wan_cfg.WAN_PPP_CONN.conn_status = WAN_PPP_CONN_STATUS_CONNECTING;

	wan_cfg.WAN_PPP_CONN.max_mru_size = gatoi(pMTU);

	sprintf(wan_cfg.WAN_PPP_CONN.ppp_user_name, "%s", pUN);
	sprintf(wan_cfg.WAN_PPP_CONN.ppp_user_passwd, "%s", pPWV);
	sprintf(wan_cfg.WAN_PPP_CONN.pppoe_service_name, "%s", pSN);
	sprintf(wan_cfg.WAN_PPP_CONN.pppoe_ac_name, "%s", pACN);
	wan_cfg.WAN_PPP_CONN.bridge_enable = gatoi(pBridge);

#ifdef IFX_LOG_DEBUG
	IFX_DBG ("ppp details - compression protocol [%d], transport type [%d] !!",   wan_cfg.WAN_PPP_CONN.compr_proto, wan_cfg.WAN_PPP_CONN.transport_type);
	IFX_DBG("ppp details - user name [%s], password [%s] !!",wan_cfg.WAN_PPP_CONN.ppp_user_name,wan_cfg.WAN_PPP_CONN.ppp_user_passwd);
#endif

#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] calling mapi l2iface [%s]", __FUNCTION__, __LINE__,
		wan_cfg.WAN_PPP_CONN.wan_cfg.l2iface_name);
#endif
	wan_cfg.type = WAN_TYPE_PPP;

	ret = ifx_cgi_set_wan_config(operation, &wan_cfg, flags);
	if (ret != IFX_SUCCESS) {
		if (ret == IFX_PCR_CHK_FAIL) {
			COPY_TO_STATUS("%s", pcr_chk_err)
			    ifx_httpdRedirect(wp, T("err_page.html"));
			return 0;
		}
	}
	else
        {
	#ifdef CONFIG_FEATURE_NAPT

		IFX_DBG("[%s:%d:%s] ", __FUNCTION__, __LINE__,newconnName);
		if(strlen(newconnName) != 0)
                {
			IFX_DBG("[%s:%d:%s] ", __FUNCTION__, __LINE__,newconnName);
#ifdef CONFIG_FEATURE_LTQ_IGMP_AUTOWAN_UPDATE
			mcast_wan_flag=Update_mcast_wan_flag(0,0);
			strcpy(igmpnewconnName,newconnName);
			
			ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_upstream_wan", sVal);
			if (strlen(igmpoldconnName) != 0 ) {
				if (mcast_wan_flag == 1) {
					Update_igmp_config(igmpoldconnName,igmpnewconnName,0);
					mcast_wan_flag=0;
				} else if (mcast_wan_flag == 2 ) {
					mcast_wan_flag=0;
				} else if (mcast_wan_flag == 0){
					if ( strstr(sVal,igmpoldconnName) != NULL ) {
						mcast_wan_flag =3;
						Update_mcast_wan_flag(1,mcast_wan_flag);
						Update_igmp_config(igmpoldconnName,igmpnewconnName,0);
						mcast_wan_flag=0;
					}
				}
				Update_mcast_wan_flag(1,mcast_wan_flag);
			}
#endif
#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
      	          	if(mapi_pwb_modentry_on_wanchange(newconnName, cgi_pwb) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                      		IFX_DBG("function [%s] line [%d]  !!", __FUNCTION__, __LINE__);
#endif
               		}               
#endif
#ifdef CONFIG_FEATURE_NAPT
               		ret = Update_virtual_server_config(newconnName,"modify");
#endif
		}
	#endif
        }

IFX_Handler:
	if (!strcmp(page, "wan_pppoe.asp"))
		ifx_httpdRedirect(wp, T("wan_vcc_select.asp"));
	if (!strcmp(page, "wan_vcc_select.asp"))
		ifx_httpdRedirect(wp, T("wan_vcc_select.asp"));
	return 0;
}
#endif				//CONFIG_PACKAGE_PPP_MOD_PPPOE

// wan_pppoa.asp
#ifdef CONFIG_PACKAGE_PPP_MOD_PPPOA
int ifx_set_wan_pppoa(httpd_t wp, char_t * path, char_t * query)
{
	char8 *pUN = NULL, *pPWV = NULL, *pSN = NULL;
	char8 *pMTU = NULL, *pIdle = NULL, *pReconnect = NULL;
	char8 sValue[20];
        char8 buf_tunnel[40];
        char8 retVal6[MAX_FILELINE_LEN];
	char8 buf[MAX_NAME_SIZE];
	int32 nWAN_IDX = -1;
	int32 operation = IFX_OP_ADD, ret = IFX_SUCCESS;
	uint32 flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT;
	WAN_CONN_CFG wan_cfg;
	WAN_COMMON_CFG pWan;
	WAN_TYPE wan_type = WAN_TYPE_IP;
	WAN_MODE WanType;
	WanType = ifx_get_wan_mode_selected();

	/* pstWanPhy: Global WAN Mode ADSL2+, MIIO, MII1 or PTM */
	WAN_PHY_CFG pstWanPhy;
	memset(&pstWanPhy, 0x00, sizeof(pstWanPhy));
	ifx_get_wan_phy_cfg(&pstWanPhy);

	sValue[0] = '\0';
	IFX_GET_WAN_SELECTED_INDEX(flags, outFlag, sValue, nWAN_IDX, wan_type)

	memset(&wan_cfg, 0x00, sizeof(wan_cfg));

	a_assert(wp);
	pUN = ifx_httpdGetVar(wp, T("UN"), T(""));
	pPWV = ifx_httpdGetVar(wp, T("PWV"), T(""));
	pSN = ifx_httpdGetVar(wp, T("SN"), T(""));
	pMTU = ifx_httpdGetVar(wp, T("MTU"), T(""));
	pIdle = ifx_httpdGetVar(wp, T("IDLE"), T(""));
	pReconnect = ifx_httpdGetVar(wp, T("reconnect"), T(""));

	char_t *page = ifx_httpdGetVar(wp, T("page"), T(""));

        /* AMS */
#if 1
        char_t *pVer4 = ifx_httpdGetVar(wp, T("ipv4"), T(""));
        char_t *pVer6 = ifx_httpdGetVar(wp, T("ipv6"), T(""));
        char_t *pIntrf = ifx_httpdGetVar(wp, T("INTRF"), T(""));
        char_t *pIana_id = ifx_httpdGetVar(wp, T("IANA_ID"), T(""));
        char_t *pIapd_id = ifx_httpdGetVar(wp, T("IAPD_ID"), T(""));
        char_t *pSla_id = ifx_httpdGetVar(wp, T("SLA_ID"), T(""));
        char_t *pRapid = ifx_httpdGetVar(wp, T("RAPID"), T(""));
        char_t *pduidt = ifx_httpdGetVar(wp, T("DUID_T"), T(""));
#endif
        pWan.tunnel = 0;
	
	char_t *PDNS1 = ifx_httpdGetVar(wp, T("PDNS1"), T(""));
        char_t *PDNS2 = ifx_httpdGetVar(wp, T("PDNS2"), T(""));
        char_t *PDNS3 = ifx_httpdGetVar(wp, T("PDNS3"), T(""));
        char_t *PDNS4 = ifx_httpdGetVar(wp, T("PDNS4"), T(""));
        char_t *SDNS1 = ifx_httpdGetVar(wp, T("SDNS1"), T(""));
        char_t *SDNS2 = ifx_httpdGetVar(wp, T("SDNS2"), T(""));
        char_t *SDNS3 = ifx_httpdGetVar(wp, T("SDNS3"), T(""));
        char_t *SDNS4 = ifx_httpdGetVar(wp, T("SDNS4"), T(""));
	char_t *dns_check = ifx_httpdGetVar(wp, T("dns_check_value"), T(""));


	if (wan_type == WAN_TYPE_IP && nWAN_IDX >= 0) {
    /* No IP possible in this case ! */
    ifx_httpdError(wp, 400,
             "Configuration was not successful. IP to PPPoA modification is not supported");
    return -1;
#ifdef LTQ_AEI_CUST
		wan_cfg.type = wan_type;
		ret =
		    ifx_mapi_get_wan_config(nWAN_IDX, &wan_cfg, IFX_F_GET_ANY);

		if (ret != IFX_SUCCESS) {
			IFX_DBG
			    ("[%s:%d] unable to get details of existing WAN IP connection with index [%d]",
			     __FUNCTION__, __LINE__, nWAN_IDX);
			ifx_httpdError(wp, 400,
				       "Unable to get details of existing WAN IP connection with index [%d]",
				       nWAN_IDX);
			return -1;
		}
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] WAN IP get on [%d] succeeded", __FUNCTION__,
			__LINE__, nWAN_IDX);
#endif
		GET_WAN_COMM_PTR_1(pWan, wan_cfg)

		wan_cfg.WAN_IP_CONN.wan_cfg.wan_index = nWAN_IDX;

		/* Set the DELETE operation & Flags */
		operation = IFX_OP_DEL;
		flags = IFX_F_DELETE;

		/* Store the CPE & pCPE Id for this WAN Device
		 * Since this operation is a modify, we need to ADD back with the same values */
		sprintf(pWan.iid.cpeId.secName, "%s", TAG_WAN_IP);
		wan_cpeId = pWan.iid.cpeId.Id;
		sprintf(pWan.iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);
		wan_pcpeId = pWan.iid.pcpeId.Id;
		pWan.iid.config_owner = IFX_WEB;

#ifdef CONFIG_PACKAGE_LQ_IGMPD
		strcpy(igmpoldconnName,pWan.conn_name);
#endif
		ret = mapi_delete_old_virtualserver(pWan.conn_name, "modify");
		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
			    ("[%s:%d] unable to delete virtual server of wan index  with index [%d]",
		     __FUNCTION__, __LINE__, pWan.wan_index);
				return -1;
#endif
		}
#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
		if(mapi_pwb_delentry_on_wanchange(pWan.conn_name, &cgi_pwb) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                      	IFX_DBG("delete pwb entry failed in function [%s] line [%d]  !!", __FUNCTION__, __LINE__);
#endif
                }
#endif

		/* Case of changing WAN type from EoA/IPoA to PPPoA */
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] cpeid:sec pcpeid:sec [%d:%s] [%d:%s]", __FUNCTION__, __LINE__,
			wan_cfg.wancfg.ip.wan_cfg.iid.cpeId.Id, wan_cfg.wancfg.ip.wan_cfg.iid.cpeId.secName,
			wan_cfg.wancfg.ip.wan_cfg.iid.pcpeId.Id, wan_cfg.wancfg.ip.wan_cfg.iid.pcpeId.secName);
#endif

		if(wan_cfg.wancfg.ppp.wan_cfg.link_type != WAN_LINK_TYPE_PPPOATM && (WanType == WAN_MODE_ATM || WanType == WAN_MODE_VDSL_ATM)) {
			if(mapi_wan_for_l2_get(wan_cfg.wancfg.ip.wan_cfg.iid, &vc, &vlan_cfg) != IFX_SUCCESS) {
	#ifdef IFX_LOG_DEBUG
				IFX_DBG
			    ("[%s:%d] Failed to get details of L2 for this WAN IP connection with index [%d]",
			     __FUNCTION__, __LINE__, nWAN_IDX);
	#endif
				ifx_httpdError(wp, 400,
			    "Failed to get details of L2 for this WAN IP connection with index [%d]", nWAN_IDX);
				return -1;
			}
		}

		/* Invoke the CGI handler function to DELETE this WAN connection */
		if (ifx_cgi_set_wan_config
		    (operation, &wan_cfg,
		     flags | IFX_F_DONT_WRITE_TO_FLASH) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "WAN[%d] couldn't be modified !!\n",
				       nWAN_IDX);
			return -1;
		}

		if(wan_cfg.wancfg.ppp.wan_cfg.link_type != WAN_LINK_TYPE_PPPOATM && (WanType == WAN_MODE_ATM || WanType == WAN_MODE_VDSL_ATM)) {
			/* Set link type to PPPoATM and encapsulation to VCMUX */
			vc.type = LINK_TYPE_PPPOATM;
			vc.encap = VC_ENCAP_VCMUX;

			operation = IFX_OP_MOD;
			flags = IFX_F_MODIFY;
			/* this API call would take care of updating L3 as well ! */
			if(ifx_set_vcc_cfg(operation, &vc, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("Failed to modify WAN connection to PPPoE");
#endif
				ifx_httpdError(wp, 400, "Failed to modify L2 link type to PPPoA");
				return -1;
			}
			sprintf(sValue, "WAN_VCC=\"%s\"\n", vc.l2ifname);
			SetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, IFX_F_MODIFY, 1, sValue);
		}

		memset(&wan_cfg, 0x00, sizeof(wan_cfg));
		memset(&pWan, 0x00, sizeof(pWan));

		/* Populate the CPE and pCPE ID structure by Restoring the 
		 * CPE and pCPE Ids stored during DELETE of this Connection */
		sprintf(pWan.iid.cpeId.secName, "%s", TAG_WAN_PPP);
		pWan.iid.cpeId.Id = wan_cpeId;
		sprintf(pWan.iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);
		pWan.iid.pcpeId.Id = wan_pcpeId;

		/* Set the ADD Operation Flags */
		operation = IFX_OP_ADD;
		flags = IFX_F_INT_ADD;
#endif
	} else if (wan_type == WAN_TYPE_PPP && nWAN_IDX >= 0) {

		wan_cfg.type = wan_type;
		ret =
		    mapi_get_wan_config(nWAN_IDX, &wan_cfg, IFX_F_GET_ANY);

		if (ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("[%s:%d] unable to get details of existing WAN PPP connection with index [%d]",
			     __FUNCTION__, __LINE__, nWAN_IDX);
#endif
			ifx_httpdError(wp, 400,
				       "Unable to get details of existing WAN PPP connection with index [%d]",
				       nWAN_IDX);
			return -1;
		}

                sprintf(buf_tunnel, "wanppp_%d_tunnel", nWAN_IDX);
                if (ifx_GetObjData
                    (FILE_RC_CONF, TAG_WAN_PPP, buf_tunnel, flags,
                     (IFX_OUT uint32 *) & outFlag, retVal6) == IFX_SUCCESS) {
                        pWan.tunnel = atoi(retVal6);
                }

#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] WAN PPP get on [%d] succeeded", __FUNCTION__,
			__LINE__, nWAN_IDX);
#endif
		operation = IFX_OP_MOD;
		flags = IFX_F_MODIFY;


#ifdef LTQ_AEI_CUST
		/* Case of changing WAN type from PPPoE to PPPoA */
		if(wan_cfg.wancfg.ppp.wan_cfg.link_type == WAN_LINK_TYPE_PPPOE) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] cpeid:sec pcpeid:sec [%d:%s] [%d:%s]", __FUNCTION__, __LINE__,
				wan_cfg.wancfg.ppp.wan_cfg.iid.cpeId.Id, wan_cfg.wancfg.ppp.wan_cfg.iid.cpeId.secName,
				wan_cfg.wancfg.ppp.wan_cfg.iid.pcpeId.Id, wan_cfg.wancfg.ppp.wan_cfg.iid.pcpeId.secName);
#endif
			if(mapi_wan_for_l2_get(wan_cfg.wancfg.ppp.wan_cfg.iid, &vc, &vlan_cfg) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
			    ("[%s:%d] Failed to get details of L2 for this WAN PPP connection with index [%d]",
			     __FUNCTION__, __LINE__, nWAN_IDX);
#endif
				ifx_httpdError(wp, 400,
			    "Failed to get details of L2 for this WAN PPP connection with index [%d]", nWAN_IDX);
				return -1;
			}

			/* Set link type to PPPoATM and encapsulation to VCMUX */
			vc.type = LINK_TYPE_PPPOATM;
			vc.encap = VC_ENCAP_VCMUX;

			operation = IFX_OP_MOD;
			flags = IFX_F_MODIFY;
			/* this API call would take care of updating L3 as well ! */
			if(ifx_set_vcc_cfg(operation, &vc, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("Failed to modify WAN connection to PPPoE");
#endif
				ifx_httpdError(wp, 400, "Failed to modify WAN connection to PPPoE");
				return -1;
			}
			sprintf(sValue, "WAN_VCC=\"%s\"\n", vc.l2ifname);
			SetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, IFX_F_MODIFY, 1, sValue);
		}
#endif

		GET_WAN_COMM_PTR_1(pWan, wan_cfg)

		/* CANNOT Modify Disabled WAN Connections.
		 * These are configured from TR069 ACS and can't enable the same from Web */
		if (pWan.f_enable == IFX_DISABLED) {
			ifx_httpdError(wp, 400,
				       "WAN[%d] is currently disabled - Can't modify !!\n",
				       nWAN_IDX);
			return -1;
		}
	} else {
		operation = IFX_OP_ADD;
		flags = IFX_F_INT_ADD;
	}

        /* AMS */
#if 1
        pWan.ipv4 = atoi(pVer4);
        if (atoi(pVer6) == 2)
                pWan.ipv6 = atoi(pVer6);        /* 2 means enabled */
        else
                pWan.ipv6 = 1;  /* 1 means disabled */
        pWan.dhcp_mode = atoi(pIntrf);
        pWan.iana = atoi(pIana_id);
        pWan.iapd = atoi(pIapd_id);
        pWan.slaid = atoi(pSla_id);
        pWan.rapid = atoi(pRapid);
        pWan.duid_t = atoi(pduidt);
#endif

	if (pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2)
		pWan.wan_mode.mode = WAN_MODE_VDSL_ATM;
	else
		pWan.wan_mode.mode = WAN_MODE_ATM;

	/* set the link type to pppoe */
	pWan.link_type = WAN_LINK_TYPE_PPPOATM;

	/* Set the wan index */
	pWan.wan_index = nWAN_IDX;

	if (WanType == WAN_MODE_ATM || WanType == WAN_MODE_VDSL_ATM) {
		ifx_GetObjData(FILE_SYSTEM_STATUS, TAG_WAN_MAIN, "WAN_VCC",
			       IFX_F_GET_ANY, &outFlag, pWan.l2iface_name);
	} else {
    /* PPPoA is supported only in ATM mode ! */
    ifx_httpdError(wp, 400,
             "Configuration was not successful. PPPoA connection is possible in ATM mode only");
    return -1;
	}

	/* get wan conn name out of wan index */
	if (operation == IFX_OP_ADD) {
#ifdef CONFIG_FEATURE_RIP
		/* Set RIP information based on the Global RIP State & Listen Mode */
		ifx_set_wanif_route_proto(nWAN_IDX, &pWan);
#endif
	}

	pWan.f_enable = IFX_ENABLED;

#ifdef CONFIG_FEATURE_NAPT
	/* Currently we set the NAT on interface level as always ENABLED 
	 * Once the interface level option is configurable, then it can be put here */
	pWan.WAN_CONN_NAT_ENABLED = IFX_ENABLED;
#endif

	if (strlen(pReconnect)) {
		if (pIdle && *pIdle)
			pWan.idle_disconn_time = 60 * gatoi(pIdle);
		else
			pWan.idle_disconn_time = 600;
	}

	pWan.max_mtu = gatoi(pMTU);

	ifx_check_dw_status(&(pWan.def_wan),
			    ifx_httpdGetVar(wp, T("def_wan"), T("")));

	/* set the dns override option to true */
	pWan.wandns.WAN_CONN_DNS_OVERRIDE = IFX_ENABLED;

	if(atoi(dns_check)) {
		pWan.wandns.WAN_CONN_DNS_OVERRIDE = IFX_DISABLED;	
	        memset(buf, 0x00, sizeof(buf));
        	snprintf(buf, sizeof(buf), T("%s.%s.%s.%s"), PDNS1, PDNS2, PDNS3, PDNS4);
	        pWan.wandns.dns_servers[0].s_addr = inet_addr(buf);
        	memset(buf, 0x00, sizeof(buf));
	        snprintf(buf, sizeof(buf), T("%s.%s.%s.%s"), SDNS1, SDNS2, SDNS3, SDNS4);
        	pWan.wandns.dns_servers[1].s_addr = inet_addr(buf);
	}

	pWan.iid.config_owner = IFX_WEB;

#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] l2iface [%s]", __FUNCTION__, __LINE__,
		pWan.l2iface_name);
#endif

	memcpy(&wan_cfg.WAN_PPP_CONN.wan_cfg, &pWan, sizeof(pWan));

	if (atoi(pReconnect) == CONN_TRIGGER_ON_DEMAND) {
		wan_cfg.WAN_PPP_CONN.WAN_CONN_TRIGGER = CONN_TRIGGER_ON_DEMAND;

		if (pIdle && *pIdle)
			pWan.idle_disconn_time = 60 * gatoi(pIdle);
		else
			pWan.idle_disconn_time = 600;
	} else if(atoi(pReconnect) == CONN_TRIGGER_MANUAL){
		 wan_cfg.WAN_PPP_CONN.WAN_CONN_TRIGGER = CONN_TRIGGER_MANUAL;
	}else
		wan_cfg.WAN_PPP_CONN.WAN_CONN_TRIGGER = CONN_TRIGGER_ALWAYS_ON;

	wan_cfg.WAN_PPP_CONN.conn_type = WAN_PPP_CONN_TYPE_IP_ROUTED;

	wan_cfg.WAN_PPP_CONN.conn_status = WAN_PPP_CONN_STATUS_CONNECTING;

	wan_cfg.WAN_PPP_CONN.max_mru_size = gatoi(pMTU);

	sprintf(wan_cfg.WAN_PPP_CONN.ppp_user_name, "%s", pUN);
	sprintf(wan_cfg.WAN_PPP_CONN.ppp_user_passwd, "%s", pPWV);
	sprintf(wan_cfg.WAN_PPP_CONN.pppoe_service_name, "%s", pSN);


#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] calling mapi l2iface [%s]", __FUNCTION__, __LINE__,
		wan_cfg.WAN_PPP_CONN.wan_cfg.l2iface_name);
#endif
	wan_cfg.type = WAN_TYPE_PPP;

	ret = ifx_cgi_set_wan_config(operation, &wan_cfg, flags);
	if (ret != IFX_SUCCESS) {
		if (ret == IFX_PCR_CHK_FAIL) {
			COPY_TO_STATUS("%s", pcr_chk_err)
			    ifx_httpdRedirect(wp, T("err_page.html"));
			return 0;
		}
	}

IFX_Handler:
	if (!strcmp(page, "wan_pppoa.asp"))
		ifx_httpdRedirect(wp, T("wan_vcc_select.asp"));
	if (!strcmp(page, "wan_vcc_select.asp"))
		ifx_httpdRedirect(wp, T("wan_vcc_select.asp"));
	return 0;
}
#endif				//CONFIG_PACKAGE_PPP_MOD_PPPOA
