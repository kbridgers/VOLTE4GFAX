#include <sys/syslog.h>
#include <ifx_emf.h>
#include "ifx_httpd_method.h"
#include <signal.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ifx_common.h>
#include "./ifx_cgi.h"
#include "./ifx_amazon_cgi_getFunctions.h"
#include "ifx_api_proto.h"
#include "./ifx_cgi_common.h"

#define trace(...)

char IpsecTunnelAction[20];
#include "ifx_snmp_api.h"
#include "ifx_api_ipt_common.h"
#include <sys/ioctl.h>

extern char *status_str;

extern int ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);
extern int ifx_get_all_wan_conn_names(char **wan_conn_names, int *count);
char tunnelOrder[10];

void ifx_get_ipsec_tunnel_operation(int eid, httpd_t wp, int argc,
				    char_t ** argv)
{
	ifx_httpdWrite(wp, T("%s"), IpsecTunnelAction);
}

void ifx_get_ipsec_tunnel_info(int eid, httpd_t wp, int argc, char_t ** argv)
{
	IFX_IPSEC_TUNNEL *pp_ipsec_tunnel_info = NULL;
	int32 num_entries;
	int32 i, count = 0, j = 0;
	uint32 outFlag = IFX_F_DEFAULT;
	int32 ret = IFX_SUCCESS;
	char8 *wan_conn_names = NULL, wan_conn_name[MAX_FILELINE_LEN];
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN], *retVal = NULL;
	char8 *name = NULL;
	char8 *ike_cipher_aes192_cbc = "aes192_cbc";
	char8 *ike_cipher_blowfish = "blowfish";
	char8 *ike_mode_ikev1 = "ikev1";
	char8 *ike_mode_ikev2 = "ikev2";
	char8 *ike_cipher_des = "3des_cbc";
	char8 *ike_hash_sha1 = "sha1";
	char8 *ike_hash_md5 = "md5";
	char8 *kmpprfalg_md5 = "hmac_md5";
	char8 *kmpprfalg_sha1 = "hmac_sha1";
	char8 *kmpprfalg_aes = "aes_xcbc";
	char8 *ike_dh_modp1536 = "modp1536";
	char8 *ike_dh_modp2048 = "modp2048";
	char8 *esp_cipher_aes128 = "aes128_cbc";
	char8 *esp_cipher_aes256 = "aes256";
	char8 *esp_cipher_des = "3des_cbc";
	char8 *esp_hash_sha1 = "sha1";
	char8 *esp_hash_md5 = "md5";
	char8 *sServerIP = NULL;

	sValue[0] = '\0';
	buf[0] = '\0';

	if (strcmp(IpsecTunnelAction, "Modify_Config") == 0) {
		if (atoi(tunnelOrder) != 0) {
			if (ifx_get_all_ipsec_tunnel_entries
			    (&num_entries, &pp_ipsec_tunnel_info,
			     IFX_F_GET_ANY) == IFX_SUCCESS) {
				if (num_entries > 0) {
					for (i = 0; i < num_entries; i++) {
						if (ifx_httpd_parse_args
						    (argc, argv, T("%s"),
						     &name) < 1) {
						}
						if ((pp_ipsec_tunnel_info +
						     i)->iid.cpeId.Id ==
						    atoi(tunnelOrder)) {
							/* Found requsted entry */
							if (!gstrcmp
							    (name, "cpeId"))
								ifx_httpdWrite
								    (wp,
								     T("%d"),
								     (pp_ipsec_tunnel_info
								      +
								      i)->iid.
								     cpeId.Id);
							else {
								if (!gstrcmp
								    (name,
								     "tunnel_name"))
								{
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     (pp_ipsec_tunnel_info
									      +
									      i)->
									     TunnelName);
								}
								if (!gstrncmp
								    (name,
								     "left_ip",
								     strlen
								     ("left_ip")))
								{
									sprintf
									    (sValue,
									     "%s",
									     (pp_ipsec_tunnel_info
									      +
									      i)->
									     wan_conn_if);
									sscanf
									    (name,
									     "left_ip%d",
									     &count);
									if (count <= 5) {
										sServerIP
										    =
										    strtok
										    (sValue,
										     ".");
										for (i = 1; i < count; i++) {
											sServerIP
											    =
											    strtok
											    (NULL,
											     ".");
										}
									}
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     sServerIP);
								}
								if (!gstrncmp
								    (name,
								     "left_subnet",
								     strlen
								     ("left_subnet")))
								{
									sprintf
									    (sValue,
									     "%s",
									     (pp_ipsec_tunnel_info
									      +
									      i)->
									     LeftSubnet);
									sscanf
									    (name,
									     "left_subnet%d",
									     &count);
									if (count <= 5) {
										sServerIP
										    =
										    strtok
										    (sValue,
										     "./");
										for (i = 1; i < count; i++) {
											sServerIP
											    =
											    strtok
											    (NULL,
											     "./");
										}
									}
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     sServerIP);
								}
								if (!gstrncmp
								    (name,
								     "right_ip",
								     strlen
								     ("right_ip")))
								{
									sprintf
									    (sValue,
									     "%s",
									     (pp_ipsec_tunnel_info
									      +
									      i)->
									     RightIP);
									sscanf
									    (name,
									     "right_ip%d",
									     &count);
									if (count <= 5) {
										sServerIP
										    =
										    strtok
										    (sValue,
										     ".");
										for (i = 1; i < count; i++) {
											sServerIP
											    =
											    strtok
											    (NULL,
											     ".");
										}
									}
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     sServerIP);
								}
								if (!gstrncmp
								    (name,
								     "right_subnet",
								     strlen
								     ("right_subnet")))
								{
									sprintf
									    (sValue,
									     "%s",
									     (pp_ipsec_tunnel_info
									      +
									      i)->
									     RightSubnet);
									sscanf
									    (name,
									     "right_subnet%d",
									     &count);
									if (count <= 5) {
										sServerIP
										    =
										    strtok
										    (sValue,
										     "./");
										for (i = 1; i < count; i++) {
											sServerIP
											    =
											    strtok
											    (NULL,
											     "./");
										}
									}
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     sServerIP);
								}
								if (!gstrcmp
								    (name,
								     "psk_secret"))
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     (pp_ipsec_tunnel_info
									      +
									      i)->
									     psksecret);

								if (!gstrcmp
								    (name,
								     "ike_cipher_aes192_cbc"))
								{
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     (strcmp
									      ((pp_ipsec_tunnel_info + i)->ike_cipher, ike_cipher_aes192_cbc) == 0 ? "selected" : ""));
								} else
								    if (!gstrcmp
									(name,
									 "ike_cipher_blowfish"))
								{
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     (strcmp
									      ((pp_ipsec_tunnel_info + i)->ike_cipher, ike_cipher_blowfish) == 0 ? "selected" : ""));
								} else
								    if (!gstrcmp
									(name,
									 "ike_cipher_3des_cbc"))
								{
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     (strcmp
									      ((pp_ipsec_tunnel_info + i)->ike_cipher, ike_cipher_des) == 0 ? "selected" : ""));
								}
								if (!gstrcmp
								    (name,
								     "ike_mode_ikev1"))
								{
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     (strcmp
									      ((pp_ipsec_tunnel_info + i)->ike_mode, ike_mode_ikev1) == 0 ? "selected" : ""));
								} else
								    if (!gstrcmp
									(name,
									 "ike_mode_ikev2"))
								{
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     (strcmp
									      ((pp_ipsec_tunnel_info + i)->ike_mode, ike_mode_ikev2) == 0 ? "selected" : ""));
								}
								if (!gstrcmp
								    (name,
								     "ike_hash_sha1"))
								{
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     (strcmp
									      ((pp_ipsec_tunnel_info + i)->ike_hash, ike_hash_sha1) == 0 ? "selected" : ""));
								} else
								    if (!gstrcmp
									(name,
									 "ike_hash_md5"))
								{
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     (strcmp
									      ((pp_ipsec_tunnel_info + i)->ike_hash, ike_hash_md5) == 0 ? "selected" : ""));
								}
								if (!gstrcmp
								    (name,
								     "kmpprfalg_md5"))
								{
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     (strcmp
									      ((pp_ipsec_tunnel_info + i)->kmpprfalg, kmpprfalg_md5) == 0 ? "selected" : ""));
								} else
								    if (!gstrcmp
									(name,
									 "kmpprfalg_sha1"))
								{
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     (strcmp
									      ((pp_ipsec_tunnel_info + i)->kmpprfalg, kmpprfalg_sha1) == 0 ? "selected" : ""));
								} else
								    if (!gstrcmp
									(name,
									 "kmpprfalg_aes"))
								{
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     (strcmp
									      ((pp_ipsec_tunnel_info + i)->kmpprfalg, kmpprfalg_aes) == 0 ? "selected" : ""));
								}
								if (!gstrcmp
								    (name,
								     "ike_dh_modp1536"))
								{
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     (strcmp
									      ((pp_ipsec_tunnel_info + i)->ike_dh, ike_dh_modp1536) == 0 ? "selected" : ""));
								} else
								    if (!gstrcmp
									(name,
									 "ike_dh_modp2048"))
								{
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     (strcmp
									      ((pp_ipsec_tunnel_info + i)->ike_dh, ike_dh_modp2048) == 0 ? "selected" : ""));
								}
								if (!gstrcmp
								    (name,
								     "esp_cipher_aes128_cbc"))
								{
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     (strcmp
									      ((pp_ipsec_tunnel_info + i)->esp_cipher, esp_cipher_aes128) == 0 ? "selected" : ""));
								} else
								    if (!gstrcmp
									(name,
									 "esp_cipher_aes256"))
								{
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     (strcmp
									      ((pp_ipsec_tunnel_info + i)->esp_cipher, esp_cipher_aes256) == 0 ? "selected" : ""));
								} else
								    if (!gstrcmp
									(name,
									 "esp_cipher_3des_cbc"))
								{
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     (strcmp
									      ((pp_ipsec_tunnel_info + i)->esp_cipher, esp_cipher_des) == 0 ? "selected" : ""));
								}
								if (!gstrcmp
								    (name,
								     "esp_hash_sha1"))
								{
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     (strcmp
									      ((pp_ipsec_tunnel_info + i)->esp_hash, esp_hash_sha1) == 0 ? "selected" : ""));
								} else
								    if (!gstrcmp
									(name,
									 "esp_hash_md5"))
								{
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     (strcmp
									      ((pp_ipsec_tunnel_info + i)->esp_hash, esp_hash_md5) == 0 ? "selected" : ""));
								}
								if (!gstrcmp
								    (name,
								     "lifetime"))
									ifx_httpdWrite
									    (wp,
									     T
									     ("%d"),
									     (pp_ipsec_tunnel_info
									      +
									      i)->
									     lifetime);
								if (!gstrcmp
								    (name,
								     "retry")) {
									ifx_httpdWrite
									    (wp,
									     T
									     ("%d"),
									     (pp_ipsec_tunnel_info
									      +
									      i)->
									     retry);
								}
								if (!gstrcmp
								    (name,
								     "f_enable"))
									ifx_httpdWrite
									    (wp,
									     T
									     ("%s"),
									     ((pp_ipsec_tunnel_info + i)->f_enable == 1) ? "CHECKED" : "");

								if (!gstrcmp
								    (name,
								     "wan_conn_if"))
								{
									ifx_get_all_wan_conn_names
									    (&wan_conn_names,
									     &count);
									sprintf
									    (buf,
									     "%d",
									     (pp_ipsec_tunnel_info
									      +
									      i)->
									     iid.
									     cpeId.
									     Id);
									if ((ret
									     =
									     ifx_ret_substr_from_distfield
									     (FILE_RC_CONF,
									      TAG_IPSEC_TUNNEL,
									      "cpeId",
									      buf,
									      &retVal))
									    !=
									    IFX_SUCCESS)
									{
									}
									sprintf
									    (buf,
									     "%s_wanConnIf",
									     retVal);
									IFX_MEM_FREE
									    (retVal)
									    if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPSEC_TUNNEL, buf, IFX_F_DEFAULT, &outFlag, wan_conn_name)) != IFX_SUCCESS) {
									}
									IFX_GET_WAN_CONN_NAME_LIST
									    (j,
									     count,
									     (pp_ipsec_tunnel_info
									      +
									      i)->
									     wan_conn_if,
									     wan_conn_names)
								}
								IFX_MEM_FREE
								    (pp_ipsec_tunnel_info);
								break;
							}
						}
					}
				}
			}
		}
	} else if (strcmp(IpsecTunnelAction, "View_Config") == 0) {
		if (atoi(tunnelOrder) != 0) {
			if (ifx_get_all_ipsec_tunnel_entries
			    (&num_entries, &pp_ipsec_tunnel_info,
			     IFX_F_GET_ANY) == IFX_SUCCESS) {
				if (num_entries > 0) {
					for (i = 0; i < num_entries; i++) {
						if ((pp_ipsec_tunnel_info +
						     i)->iid.cpeId.Id ==
						    atoi(tunnelOrder)) {
							ifx_httpdWrite(wp,
								       T
								       ("\n<div align=\"center\"><table class=\"tableinfo\">"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<tr>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>\n<tr>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>Tunnel Name</td>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>%s"),
								       (pp_ipsec_tunnel_info
									+
									i)->
								       TunnelName);
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>\n<tr>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>IKE Mode</td>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>%s"),
								       (pp_ipsec_tunnel_info
									+
									i)->
								       ike_mode);
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>\n<tr>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>My Address</td>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>%s"),
								       (pp_ipsec_tunnel_info
									+
									i)->
								       wan_conn_if);
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>\n<tr>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>My Subnet</td>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>%s"),
								       (pp_ipsec_tunnel_info
									+
									i)->
								       LeftSubnet);
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>\n<tr>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>Peer Address</td>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>%s"),
								       (pp_ipsec_tunnel_info
									+
									i)->
								       RightIP);
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>\n<tr>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>Peer Subnet</td>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>%s"),
								       (pp_ipsec_tunnel_info
									+
									i)->
								       RightSubnet);
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>\n<tr>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>Enable</td>"));
							if ((pp_ipsec_tunnel_info + i)->f_enable == 1)
								ifx_httpdWrite
								    (wp,
								     T
								     ("\n<td>Yes"));
							else
								ifx_httpdWrite
								    (wp,
								     T
								     ("\n<td>No"));
							//    ifx_httpdWrite(wp, T("\n</td>\n</tr>\n<tr>\n<td>psksecret</td>"));
							//    ifx_httpdWrite(wp, T("\n<td>%s"),(pp_ipsec_tunnel_info+i)->psksecret);
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>\n<tr>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>IKE Cipher</td>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>%s"),
								       (pp_ipsec_tunnel_info
									+
									i)->
								       ike_cipher);
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>\n<tr>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>IKE Hash</td>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>%s"),
								       (pp_ipsec_tunnel_info
									+
									i)->
								       ike_hash);
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>\n<tr>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>IKE DH</td>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>%s"),
								       (pp_ipsec_tunnel_info
									+
									i)->
								       ike_dh);
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>\n<tr>"));
							if (!gstrcmp
							    ((pp_ipsec_tunnel_info + i)->ike_mode, "ikev2")) {
								ifx_httpdWrite
								    (wp,
								     T
								     ("\n<td>IKE PRF</td>"));
								ifx_httpdWrite
								    (wp,
								     T
								     ("\n<td>%s"),
								     (pp_ipsec_tunnel_info
								      +
								      i)->
								     kmpprfalg);
								ifx_httpdWrite
								    (wp,
								     T
								     ("\n</td>\n</tr>\n<tr>"));
							}
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>ESP Cipher</td>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>%s"),
								       (pp_ipsec_tunnel_info
									+
									i)->
								       esp_cipher);
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>\n<tr>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>ESP Hash</td>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>%s"),
								       (pp_ipsec_tunnel_info
									+
									i)->
								       esp_hash);
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>\n<tr>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>Lifetime</td>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>%d"),
								       (pp_ipsec_tunnel_info
									+
									i)->
								       lifetime);
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>\n<tr>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>Retry</td>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n<td>%d"),
								       (pp_ipsec_tunnel_info
									+
									i)->
								       retry);
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>"));
							ifx_httpdWrite(wp,
								       T
								       ("\n</td>\n</tr>\n<tr>"));
						}
					}

				}
			}
		}
	}

	IFX_MEM_FREE(pp_ipsec_tunnel_info);
}

void ifx_set_ipsec_tunnel(httpd_t wp, char_t * path, char_t * query)
{
	int32 instCount;
	int32 operation = IFX_OP_ADD, ret = IFX_SUCCESS;
	uint32 flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT;
	IFX_IPSEC_TUNNEL ipsecStruct;
	char_t *rightIP1, *rightIP2, *rightIP3, *rightIP4;
	char_t *leftsubnet1, *leftsubnet2, *leftsubnet3, *leftsubnet4,
	    *leftsubnet5;
	char_t *rightsubnet1, *rightsubnet2, *rightsubnet3, *rightsubnet4,
	    *rightsubnet5;
	char_t *pskSecret;
	char_t *esp_cipher, *ike_cipher, *ike_mode, *kmpprfalg, *pRetry,
	    *pLifetime;
	int32 lifetime, retry;
	char_t *IPsecAction = ifx_httpdGetVar(wp, T("IPsecAction"), T(""));
	char_t *ipsecWebOrder = ifx_httpdGetVar(wp, T("ipsecWebOrder"), T(""));
	char_t *esp_hash, *ike_hash, *ike_dh;
	char_t *tunnelname;
	char8 *wan_conn_name = NULL, *pFunc =
	    NULL, wan_conn_if[IFNAMSIZE], sValue[MAX_FILELINE_LEN],
	    buf[MAX_FILELINE_LEN], *retVal = NULL;
	WAN_TYPE type;
	char8 secName[MAX_FILELINE_LEN];

	memset(&ipsecStruct, 0x00, sizeof(ipsecStruct));
	wan_conn_if[0] = '\0';

	a_assert(wp);
	// Get value from ASP file
	tunnelname = ifx_httpdGetVar(wp, T("TUNNEL_NAME"), T(""));
	ike_mode = ifx_httpdGetVar(wp, T("IKE_MODE"), T(""));
	leftsubnet1 = ifx_httpdGetVar(wp, T("LEFT_SUBNET1"), T(""));
	leftsubnet2 = ifx_httpdGetVar(wp, T("LEFT_SUBNET2"), T(""));
	leftsubnet3 = ifx_httpdGetVar(wp, T("LEFT_SUBNET3"), T(""));
	leftsubnet4 = ifx_httpdGetVar(wp, T("LEFT_SUBNET4"), T(""));
	leftsubnet5 = ifx_httpdGetVar(wp, T("LEFT_SUBNET5"), T(""));
	rightIP1 = ifx_httpdGetVar(wp, T("RIGHT_IP1"), T(""));
	rightIP2 = ifx_httpdGetVar(wp, T("RIGHT_IP2"), T(""));
	rightIP3 = ifx_httpdGetVar(wp, T("RIGHT_IP3"), T(""));
	rightIP4 = ifx_httpdGetVar(wp, T("RIGHT_IP4"), T(""));
	rightsubnet1 = ifx_httpdGetVar(wp, T("RIGHT_SUBNET1"), T(""));
	rightsubnet2 = ifx_httpdGetVar(wp, T("RIGHT_SUBNET2"), T(""));
	rightsubnet3 = ifx_httpdGetVar(wp, T("RIGHT_SUBNET3"), T(""));
	rightsubnet4 = ifx_httpdGetVar(wp, T("RIGHT_SUBNET4"), T(""));
	rightsubnet5 = ifx_httpdGetVar(wp, T("RIGHT_SUBNET5"), T(""));
	pskSecret = ifx_httpdGetVar(wp, T("PSK_SECRET"), T(""));
	esp_cipher = ifx_httpdGetVar(wp, T("ESP_CIPHER"), T(""));
	esp_hash = ifx_httpdGetVar(wp, T("ESP_HASH"), T(""));
	ike_cipher = ifx_httpdGetVar(wp, T("IKE_CIPHER"), T(""));
	ike_hash = ifx_httpdGetVar(wp, T("IKE_HASH"), T(""));
	ike_dh = ifx_httpdGetVar(wp, T("IKE_DH"), T(""));
	kmpprfalg = ifx_httpdGetVar(wp, T("KMPPRFALG"), T(""));
	pLifetime = ifx_httpdGetVar(wp, T("LIFETIME"), T(""));
	pRetry = ifx_httpdGetVar(wp, T("RETRY"), T(""));
	lifetime = atoi(pLifetime);
	retry = atoi(pRetry);

	if (!gstrcmp(IPsecAction, "Add_Config")) {
		if (ifx_get_sec_instance_count
		    (TAG_IPSEC_INFO, (uint32 *) & instCount) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       T
				       ("Failed to read IPSec tunnel instance count"));
			return;
		}
		if (instCount == 8) {
			COPY_TO_STATUS("%s",
				       "<span class=\"textTitle\">IPSec tunnel configuration failed.</span><br><p>Number of configured tunnels has reached maximum limit(8).<br>Please delete existing entry before configuring new one.</p>");
			ifx_httpdRedirect(wp, "err_page.html");
		}
		strcpy(IpsecTunnelAction, IPsecAction);
		strcpy(tunnelOrder, ipsecWebOrder);
		ifx_httpdRedirect(wp, "ipsec_tunnel_config_add.asp");
		return;
	}

	else if (!gstrcmp(IPsecAction, "Modify_Config")) {
		strcpy(IpsecTunnelAction, IPsecAction);
		strcpy(tunnelOrder, ipsecWebOrder);
		ifx_httpdRedirect(wp, "ipsec_tunnel_config_mod.asp");
		return;
	} else if (!gstrcmp(IPsecAction, "View_Config")) {
		strcpy(IpsecTunnelAction, IPsecAction);
		strcpy(tunnelOrder, ipsecWebOrder);
		ifx_httpdRedirect(wp, "ipsec_tunnel_show.asp");
		return;
	} else if (!gstrcmp(IPsecAction, "Add")) {
		operation = IFX_OP_ADD;
		flags = IFX_F_DEFAULT;
	} else if (!gstrcmp(IPsecAction, "Delete")) {
		operation = IFX_OP_DEL;
		flags = IFX_F_DELETE;
	} else if (!gstrcmp(IPsecAction, "Modify")) {
		operation = IFX_OP_MOD;
		flags = IFX_F_MODIFY;
	}

	if (operation == IFX_OP_ADD || operation == IFX_OP_MOD) {
		wan_conn_name = ifx_httpdGetVar(wp, "IPSEC_WAN_CONN", T(""));
		GET_WAN_TYPE_N_SEC_FROM_CONN_NAME(wan_conn_name, type, secName)

		    ifx_get_wan_ifname_from_connName(wan_conn_name, wan_conn_if,
						     type);
		if (strlen(wan_conn_if) < 1) {
			ifx_httpdError(wp, 400,
				       T
				       ("No wan connection with [%s] name found !!"),
				       wan_conn_name);
			return;
		}
	}
	if (operation == IFX_OP_DEL) {
		wan_conn_name =
		    ifx_httpdGetVar(wp, T("wanConnName_selected"), T(""));
		sprintf(ipsecStruct.wan_conn_if, "%s", wan_conn_name);
		GET_WAN_TYPE_N_SEC_FROM_CONN_NAME(wan_conn_name, type, secName)
	}

	if ((ret =
	     ifx_ret_substr_from_distfield(FILE_RC_CONF,
					   type ==
					   WAN_TYPE_IP ? TAG_WAN_IP :
					   TAG_WAN_PPP, "connName",
					   wan_conn_name,
					   &retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\nIn Function [%s] : Error--> No wan connection exists with the name [%s] !!\n\n",
		     __FUNCTION__, wan_conn_name);
#endif
		IFX_MEM_FREE(retVal)
		    return;
	}
	sprintf(buf, "%s_cpeId", retVal);
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, secName, buf, IFX_F_GET_ANY,
			    (IFX_OUT uint32 *) & outFlag,
			    sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\nIn Function [%s] : Error--> Failed to get the cpeid for the wan connection [%s] !!\n\n",
		     __FUNCTION__, wan_conn_name);
#endif
		IFX_MEM_FREE(retVal)
		    return;
	}
	if (operation == IFX_OP_ADD || operation == IFX_OP_MOD) {
		ipsecStruct.iid.cpeId.Id = atoi(ipsecWebOrder);
		strncpy(ipsecStruct.wan_conn_if, wan_conn_name,
			strlen(wan_conn_name));
		ipsecStruct.iid.pcpeId.Id = atoi(sValue);

		if (operation == IFX_OP_MOD) {
			if (ifx_get_ipsec_tunnel_entry
			    (&ipsecStruct, IFX_F_DEFAULT) != IFX_SUCCESS) {
				ifx_httpdError(wp, 400, T("%s"),
					       "Failed to get previous IPSec tunnel configuration.");
				IFX_MEM_FREE(retVal)
				    return;
			}

			flags = IFX_F_MODIFY;
		}

		if (operation == IFX_OP_ADD || operation == IFX_OP_MOD) {
			gsprintf(buf, T("IPSEC_TUNNEL_F"));
			pFunc = ifx_httpdGetVar(wp, "IPSEC_TUNNEL_F", T(""));
			if (!gstrcmp(pFunc, "1")) {
				ipsecStruct.f_enable = IFX_ENABLED;
			} else {

				ipsecStruct.f_enable = IFX_DISABLED;
				// Pass the Disable flags to hash out the entry in rc.conf
				if (operation == IFX_OP_ADD)
					flags |=
					    (IFX_F_DONT_ACTIVATE |
					     IFX_F_DONT_VALIDATE);
				else if (operation == IFX_OP_MOD)
					flags |= IFX_F_DEACTIVATE;
			}
		}
		ipsecStruct.iid.pcpeId.Id = atoi(sValue);
		sprintf(ipsecStruct.TunnelName, "%s", tunnelname);
		strncpy(ipsecStruct.wan_conn_if, wan_conn_name,
			strlen(wan_conn_name));
		sprintf(ipsecStruct.LeftSubnet, "%s.%s.%s.%s/%s", leftsubnet1,
			leftsubnet2, leftsubnet3, leftsubnet4, leftsubnet5);
		sprintf(ipsecStruct.RightIP, "%s.%s.%s.%s", rightIP1, rightIP2,
			rightIP3, rightIP4);
		sprintf(ipsecStruct.RightSubnet, "%s.%s.%s.%s/%s", rightsubnet1,
			rightsubnet2, rightsubnet3, rightsubnet4, rightsubnet5);
		sprintf(ipsecStruct.psksecret, "%s", pskSecret);
		sprintf(ipsecStruct.esp_cipher, "%s", esp_cipher);
		sprintf(ipsecStruct.esp_hash, "%s", esp_hash);
		sprintf(ipsecStruct.ike_cipher, "%s", ike_cipher);
		sprintf(ipsecStruct.ike_mode, "%s", ike_mode);
		sprintf(ipsecStruct.ike_hash, "%s", ike_hash);
		sprintf(ipsecStruct.ike_dh, "%s", ike_dh);
		sprintf(ipsecStruct.kmpprfalg, "%s", kmpprfalg);
		ipsecStruct.lifetime = lifetime;
		ipsecStruct.retry = retry;

		sprintf(ipsecStruct.iid.cpeId.secName, "%s", TAG_IPSEC_INFO);
		ipsecStruct.iid.config_owner = IFX_WEB;

	} else if (operation == IFX_OP_DEL) {
		wan_conn_name =
		    ifx_httpdGetVar(wp, T("wanConnName_selected"), T(""));
		sprintf(ipsecStruct.wan_conn_if, "%s", wan_conn_name);
		ipsecStruct.iid.cpeId.Id = gatoi(ipsecWebOrder);
		if (ifx_get_ipsec_tunnel_entry(&ipsecStruct, IFX_F_GET_ANY) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 400, T("%s"),
				       "Failed to get IPSec tunnel configuration.");
			IFX_MEM_FREE(retVal)
			    return;
		}
	}
	if (ifx_set_ipsec_tunnel_entry(operation, &ipsecStruct, flags) !=
	    IFX_SUCCESS) {
		COPY_TO_STATUS("%s",
			       "<span class=\"textTitle\">IPSec Tunnel Configuration Failed</span>");
		ifx_httpdRedirect(wp, "err_page.html");
		IFX_MEM_FREE(retVal)
		    return;
	}

      IFX_Handler:
	IFX_MEM_FREE(retVal)
	    ifx_httpdRedirect(wp, T("ipsec_tunnel_config.asp"));
	return;
}

int ifx_get_ipsec_tunnel_config(int eid, httpd_t wp, int argc, char_t ** argv)
{

	IFX_IPSEC_TUNNEL *pp_ipsec_tunnel_info = NULL;
	int32 num_entries;
	int32 count = 0, ret = IFX_SUCCESS;
	char8 *wan_conn_names = NULL, wan_conn_name[MAX_NAME_SIZE];
	char8 buf[MAX_FILELINE_LEN];
	int32 i = 0, j = 0;

	wan_conn_name[0] = '\0';
	if ((ret =
	     ifx_get_all_wan_conn_names(&wan_conn_names,
					&count)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> Failed to get wan connection names !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}
	if (ifx_get_all_ipsec_tunnel_entries
	    (&num_entries, &pp_ipsec_tunnel_info,
	     IFX_F_GET_ANY) != IFX_SUCCESS) {
		IFX_DBG("failed to get ipsec tunnel entries\n");
		goto IFX_Handler;
	}
	if (num_entries > 0) {
		ifx_httpdWrite(wp,
			       T
			       ("\n<table class=\"tableInfo\" cellspacing=\"1\" cellpadding=\"6\" summary=\"\">"));
		ifx_httpdWrite(wp, T("\n<tr>"));
		ifx_httpdWrite(wp, T("\n<th>Tunnel Name</th>"));
		ifx_httpdWrite(wp, T("\n<th>My Address</th>"));
		ifx_httpdWrite(wp, T("\n<th>My Subnet</th>"));
		ifx_httpdWrite(wp, T("\n<th>Peer Address</th>"));
		ifx_httpdWrite(wp, T("\n<th>Peer Subnet</th>"));
		ifx_httpdWrite(wp, T("\n<th>Enable</th>"));
		ifx_httpdWrite(wp,
			       T("\n<th class=\"colInput curveRight\"></th>"));
		ifx_httpdWrite(wp, T("\n</tr>\n"));

		for (i = 0; i < num_entries; i++) {
			ifx_httpdWrite(wp,
				       "<input type=\"hidden\" name=\"cpeId%d\" value=\"%d\">",
				       i,
				       (pp_ipsec_tunnel_info +
					i)->iid.cpeId.Id);
			ifx_httpdWrite(wp, T("\n<tr>"));
			ifx_httpdWrite(wp,
				       T
				       ("\n<td id=\"ipsec_con_tunnelname%d\">%s</td>"),
				       i,
				       (pp_ipsec_tunnel_info + i)->TunnelName);
			ifx_httpdWrite(wp, T("\t\t\t\t<td disabled>"));
			gsprintf(buf, T("ipsec_tunnel_%d_wanConnIf"), i);
			if (strlen((pp_ipsec_tunnel_info + i)->wan_conn_if) ==
			    0) {
				sprintf(wan_conn_name, "%s", "\0");
			} else {
				memset(wan_conn_name, 0x00, sizeof(wan_conn_name));	// PRAMOD : TESTING
				strncpy(wan_conn_name,
					(pp_ipsec_tunnel_info + i)->wan_conn_if,
					strlen(((pp_ipsec_tunnel_info +
						 i))->wan_conn_if));
				wan_conn_name[strlen
					      (((pp_ipsec_tunnel_info +
						 i))->wan_conn_if)] = '\0';
			}
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t<select name=\"%s\" disabled>"),
				       buf);

			for (j = 0; j < count; j++) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("comparing [%s] with array element [%s]!!",
				     wan_conn_name,
				     GET_WAN_CONN_NAME(wan_conn_names, j));
#endif
				if (!gstrcmp
				    (wan_conn_name,
				     GET_WAN_CONN_NAME(wan_conn_names, j)))
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t<option value=\"%s\" selected>%s</option>\n"),
						       GET_WAN_CONN_NAME
						       (wan_conn_names, j),
						       GET_WAN_CONN_NAME
						       (wan_conn_names, j));
				else
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t<option value=\"%s\">%s</option>\n"),
						       GET_WAN_CONN_NAME
						       (wan_conn_names, j),
						       GET_WAN_CONN_NAME
						       (wan_conn_names, j));
			}
			ifx_httpdWrite(wp, T("\t\t\t\t</select></td>\n"));

			ifx_httpdWrite(wp,
				       T
				       ("\n<td id=\"ipsec_con_mysubnet%d\">%s</td>"),
				       i,
				       (pp_ipsec_tunnel_info + i)->LeftSubnet);
			ifx_httpdWrite(wp,
				       T
				       ("\n<td id=\"ipsec_con_peeraddr%d\">%s</td>"),
				       i, (pp_ipsec_tunnel_info + i)->RightIP);
			ifx_httpdWrite(wp,
				       T
				       ("\n<td id=\"ipsec_con_peersubnet%d\">%s</td>"),
				       i,
				       (pp_ipsec_tunnel_info + i)->RightSubnet);
			ifx_httpdWrite(wp, T("\t\t\t\t<td disabled>"));
			gsprintf(buf, T("ipsec_tunnel_%d_fEnable"), i);
			if (((pp_ipsec_tunnel_info + i))->f_enable == 0) {
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t\t<input type=\"checkbox\" name=\"%s\" value=\"1\"  disabled></td>\n"),
					       buf);
			} else {
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t\t<input type=\"checkbox\" name=\"%s\" value=\"1\"%s disabled></td>\n"),
					       buf, " CHECKED");
			}
			ifx_httpdWrite(wp, T("\t\t\t\t<td disabled>"));
//                ifx_httpdWrite(wp, T("\n<td>"));
			ifx_httpdWrite(wp,
				       T
				       ("\n<a class=\"button\" href=\"#\" onclick=\"deleteIPsecTunnel('%d', '%s');\" value=\"Delete\">Delete</a>"),
				       (pp_ipsec_tunnel_info + i)->iid.cpeId.Id,
				       wan_conn_name);
			ifx_httpdWrite(wp, T("&nbsp;"));

			ifx_httpdWrite(wp,
				       T
				       ("\n<a class=\"button\" href=\"#\" onclick=\"modifyIPsecTunnel('%d', '%s');\" value=\"Modify\">Modify</a>"),
				       (pp_ipsec_tunnel_info + i)->iid.cpeId.Id,
				       wan_conn_name);
			ifx_httpdWrite(wp, T("\n<br>"));

			ifx_httpdWrite(wp,
				       T
				       ("\n<a class=\"button\" href=\"#\" onclick=\"viewIPsecTunnel(%d);\" value=\"View\">View</a>"),
				       (pp_ipsec_tunnel_info +
					i)->iid.cpeId.Id);
			ifx_httpdWrite(wp, T("\n</td>"));

			ifx_httpdWrite(wp, T("\n</tr>\n"));

		}

		ifx_httpdWrite(wp, T("\n</table>"));
	}
      IFX_Handler:
	IFX_MEM_FREE(pp_ipsec_tunnel_info)
	    IFX_MEM_FREE(wan_conn_names)
	    return 0;
}
