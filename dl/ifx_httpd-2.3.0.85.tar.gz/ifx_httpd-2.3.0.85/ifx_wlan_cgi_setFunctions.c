/******************************************************************************

                               Copyright (c) 2008
                            Infineon Technologies AG
                     Am Campeon 1-12; 81726 Munich, Germany

  THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED NON-EXCLUSIVE,
  WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE AND SUBLICENSE THIS
  SOFTWARE IS FREE OF CHARGE.

  THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY DISCLAIMS
  ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR IMPLIED, INCLUDING
  WITHOUT LIMITATION, WARRANTIES OR REPRESENTATIONS OF WORKMANSHIP,
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, DURABILITY, THAT THE
  OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR FREE OR FREE OF ANY THIRD
  PARTY CLAIMS, INCLUDING WITHOUT LIMITATION CLAIMS OF THIRD PARTY INTELLECTUAL
  PROPERTY INFRINGEMENT.

  EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND EXCEPT
  FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE FOR ANY CLAIM
  OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
  ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
  DEALINGS IN THE SOFTWARE.

******************************************************************************/

/**
   \file ifx_src_wlan_setFunctions.c
*/

#ifdef CONFIG_FEATURE_IFX_WIRELESS

/* ========================================================================== */
/*                                 Includes                                   */
/* ========================================================================== */
#include <ifx_emf.h>
#include "ifx_httpd_method.h"

#include <sys/types.h>
#include <ifx_common.h>
#include "ifx_cgi.h"
#include <ifx_config.h>
#include <ifx_api_ipt_common.h>
#include "ifx_api_util.h"
#include <sys/time.h>
#include "ltq_cgi_wlan.h"
/* ========================================================================== */
/*                             Macro definitions                              */
/* ========================================================================== */

/* ========================================================================== */
/*                             Type definitions                               */
/* ========================================================================== */

/* ========================================================================== */
/*                             Global variables                               */
/* ========================================================================== */
#if defined (CONFIG_LTQ_AEI_CUST)
	IFX_MAPI_WLAN_Standard gOpMode = IFX_MAPI_WLAN_STD_802_11_ALL;
#endif
	int32	g_2040CoexRadio1 = -1;
	int32	g_2040CoexRadio2 = -1;
static int gCurrentWpsStatusLoop = 0;

/* ========================================================================== */
/*                           Function prototypes                              */
/* ========================================================================== */
static void WLAN_GetApVapSettings(httpd_t wp, IFX_MAPI_WLAN_MainCfg * wlMain,
				  int32 apIndex);
static void WLAN_GetWmmApSettings(httpd_t wp,
				  IFX_MAPI_WLAN_AP_WMM_Cfg * wlApWmm,
				  IFX_MAPI_WLAN_WMM_AC ac);
void ltq_get_wlan_wmmStaConfig(httpd_t wp, IFX_MAPI_WLAN_STA_WMM_Cfg * wlStaWmm,
			       IFX_MAPI_WLAN_WMM_AC ac);

#ifdef CONFIG_FEATURE_IFX_WIRELESS_ATH
void ifx_set_wlan_settings(httpd_t wp, char_t * path, char_t * query);	// wireless_settings.asp
void ifx_set_wlan_security(httpd_t wp, char_t * path, char_t * query);	// wireless_security.asp
#endif				// CONFIG_FEATURE_IFX_WIRELESS_ATH

void IFX_WLAN_SetBasicSettings(httpd_t wp, char_t * path, char_t * query);
void IFX_WLAN_SetAdvancedRadioSettings(httpd_t wp, char_t * path,
				       char_t * query);
void IFX_WLAN_SetMainConfiguration(httpd_t wp, char_t * path, char_t * query);
void IFX_WLAN_SetSecurityConfiguration(httpd_t wp, char_t * path,
				       char_t * query);
void IFX_WLAN_SetWmmConfiguration(httpd_t wp, char_t * path, char_t * query);
void IFX_WLAN_SetWpsConfiguration(httpd_t wp, char_t * path, char_t * query);
void ltq_get_wps_status(int eid, httpd_t wp, int argc, char_t ** argv);
void ltq_get_wps_result(httpd_t wp, char_t * path, char_t * query);

void ifx_WLAN_quick_setup(httpd_t wp, char_t * path, char_t * query);
static int ltq_wlan_redirect(httpd_t wp, char_t * url, int32 apIndex);

static bool mapiWlanChkWdsCfgChg(int32 idx, LTQ_MAPI_WLAN_WDS_Cfg * wlWdsCfg);

/* ========================================================================== */
/*                         Function implementation                            */
/* ========================================================================== */

static int
ltq_wlan_redirect(httpd_t wp, char_t * url, int32 apIndex)
{
	char_t urlNew[WEBS_MAX_URL];

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_redirect", "url: %s, apIndex: %d",
		url, apIndex);

	if (url) {
		/*
			check if urlNew can hold original url + max number of characters
			that are appended
		*/
		if (strlen(url) > WEBS_MAX_URL-3) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_redirect", "strlen(url): %d",
				strlen(url));
			return IFX_FAILURE;
		}

		memset(urlNew, 0, sizeof(urlNew));
		strcpy(urlNew, url);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_redirect", "urlNew: %s", urlNew);
		switch (apIndex) {
		case 0:
			strcat(urlNew, "?0");
			break;
		case 1:
			strcat(urlNew, "?1");
			break;
		case 2:
			strcat(urlNew, "?2");
			break;
		case 3:
			strcat(urlNew, "?3");
			break;
		case 4:
			strcat(urlNew, "?4");
			break;
		case 5:
			strcat(urlNew, "?5");
			break;
		case 6:
			strcat(urlNew, "?6");
			break;
		case 7:
			strcat(urlNew, "?7");
			break;
		case 8:
			strcat(urlNew, "?8");
			break;
		case 9:
			strcat(urlNew, "?9");
			break;
		case 10:
			strcat(urlNew, "?10");
			break;
		case 11:
			strcat(urlNew, "?11");
			break;
		case 12:
			strcat(urlNew, "?12");
			break;
		case 13:
			strcat(urlNew, "?13");
			break;
		case 14:
			strcat(urlNew, "?14");
			break;
		case 15:
			strcat(urlNew, "?15");
			break;
		default:
			websNextPage(wp);
			break;
		}

		IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_redirect", "urlNew: %s", urlNew);
		ifx_httpdRedirect(wp, urlNew);
		return IFX_SUCCESS;
	} else {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_wlan_redirect", "");
		return IFX_FAILURE;
	}
}

/**

   \param wp      web page structure

   \param wlMain

   \param apIndex
*/
static void
WLAN_GetApVapSettings(httpd_t wp, IFX_MAPI_WLAN_MainCfg * wlMain, int32 apIndex)
{
	char8 *pValue = NULL;
	char8 sCommand[MAX_DATA_LEN];
	LTQ_MAPI_WLAN_NetModeClass netClass;

	IFX_MAPI_DEBUG(fd, "/tmp/WLAN_GetApVapSettings", "");
	gsprintf(sCommand, T("apEna"));
	pValue = ifx_httpdGetVar(wp, sCommand, T(""));
	wlMain->apEnable = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/WLAN_GetApVapSettings",
       "pValue: %s, apEnable:%d", pValue, wlMain->apEnable);


	if (apIndex == 0)
		wlMain->devType = IFX_MAPI_WLAN_DEV_TYPE_AP;
	else {
#if defined(CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS)
		if (apIndex > 1)
			wlMain->devType = IFX_MAPI_WLAN_DEV_TYPE_VAP;
		else
			wlMain->devType = IFX_MAPI_WLAN_DEV_TYPE_AP;
#else
		wlMain->devType = IFX_MAPI_WLAN_DEV_TYPE_VAP;
#endif
	}

	gsprintf(sCommand, T("apIsolation"));
	pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
	wlMain->apIsolationEna = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/WLAN_GetApVapSettings", "apIsolation: %d",
		       wlMain->apIsolationEna);

	gsprintf(sCommand, T("new_ssid"));
	pValue = ifx_httpdGetVar(wp, sCommand, T("ifx_default"));
	gstrcpy(wlMain->ssid, pValue);

	// manohar start
	gsprintf(sCommand, T("max_client_limit"));
	pValue = ifx_httpdGetVar(wp, sCommand, T(""));
	wlMain->maxStations = atoi(pValue);
	// manohar end

	gsprintf(sCommand, T("min_reserved_clients"));
	pValue = ifx_httpdGetVar(wp, sCommand, T(""));
	wlMain->minResSta = atoi(pValue);

	gsprintf(sCommand, T("new_apName"));
	pValue = ifx_httpdGetVar(wp, sCommand, T(""));
	gstrcpy(wlMain->apName, pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/WLAN_GetApVapSettings", "apName: %s",
		       wlMain->apName);

	/*
	   checkbox enables hidden ssid mode -> if box is check ssidMode is set to
	   IFX_MAPI_WLAN_SSID_HIDDEN, otherwise to IFX_MAPI_WLAN_SSID_ADVERTISE */
	gsprintf(sCommand, T("ssidMode"));
	pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
	wlMain->ssidMode = gatoi(pValue);

	IFX_MAPI_DEBUG(fd, "/tmp/WLAN_GetApVapSettings", "ssidMode: %d",
		       wlMain->ssidMode);

#if 0
	gsprintf(sCommand, T("basicDataRate"));
	pValue = ifx_httpdGetVar(wp, sCommand, T("1.0,2.0,5.5,11.0"));
	pValue2 = strtok(pValue, ",");

	IFX_MAPI_DEBUG(fd, "/tmp/WLAN_GetApVapSettings",
		       "pValue: %s, pValue2: %s", pValue, pValue2);
	for (i = 0; pValue2 != NULL; i++) {
		wlMain->basicDataRates[i] =
		    (float)strtod(pValue2, (char **)NULL);
		IFX_MAPI_DEBUG(fd, "/tmp/WLAN_GetApVapSettings",
			       "basicDataRate[%d]=%f", i,
			       wlMain->basicDataRates[i]);
		// TODO : is "," required after every value
		pValue2 = strtok(NULL, ",");
	}
	/* set all other values to zero, starting with the first entry after
	   previous loop */
	for (; i < IFX_MAPI_WLAN_MAX_DATA_RATES_NUM; i++)
		wlMain->basicDataRates[i] = 0.0;

	gsprintf(sCommand, T("operDataRate"));
	pValue = ifx_httpdGetVar(wp, sCommand, T("1.0,2.0,5.5,11.0"));
	pValue2 = strtok(pValue, ",");

	IFX_MAPI_DEBUG(fd, "/tmp/WLAN_GetApVapSettings",
		       "pValue: %s, pValue2: %s", pValue, pValue2);
	for (i = 0; pValue2 != NULL; i++) {
		wlMain->operDataRates[i] =
		    (float)strtod(pValue2, (char **)NULL);
		// TODO : is "," required after every value
		pValue2 = strtok(NULL, ",");
	}
	/* set all other values to zero, starting with the first entry after
	   previous loop */
	for (; i < IFX_MAPI_WLAN_MAX_DATA_RATES_NUM; i++)
		wlMain->operDataRates[i] = 0.0;
#endif				/* #if 0 */

	if (ltq_mapi_get_wlan_vendor(wlMain->radioCpeId, IFX_F_DEFAULT) ==
		LTQ_MAPI_WLAN_VENDOR_WAVE300) {
		pValue = ifx_httpdGetVar(wp, T("net_class"), T(""));
		netClass = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/WLAN_GetApVapSettings", "netClass: %d", netClass);
		switch (netClass) {
			case LTQ_MAPI_WLAN_NET_CLASS_B_N:
				pValue = ifx_httpdGetVar(wp, T("net_mode_class_0"), T(""));
				wlMain->networkMode = gatoi(pValue);
				break;
			case LTQ_MAPI_WLAN_NET_CLASS_G_BG_GN_BGN:
				pValue = ifx_httpdGetVar(wp, T("net_mode_class_1"), T(""));
				wlMain->networkMode = gatoi(pValue);
				break;
			case LTQ_MAPI_WLAN_NET_CLASS_A_N_AN:
				pValue = ifx_httpdGetVar(wp, T("net_mode_class_2"), T(""));
				wlMain->networkMode = gatoi(pValue);
				break;
			case LTQ_MAPI_WLAN_NET_CLASS_OFF:
			default:
				IFX_MAPI_DEBUG(fd, "/tmp/WLAN_GetApVapSettings", "");
				break;	
		}
		IFX_MAPI_DEBUG(fd, "/tmp/WLAN_GetApVapSettings",
			"networkMode: %d", wlMain->networkMode);
	}

	gsprintf(sCommand, T("maxBitRate"));
	pValue = ifx_httpdGetVar(wp, sCommand, T("11.0"));
	wlMain->maxBitRate = (float)strtod(pValue, (char **)NULL);

	return;
}

/**

   \param wp      web page structure

   \param wlApWmm

   \param apIndex
*/
static void
WLAN_GetWmmApSettings(httpd_t wp, IFX_MAPI_WLAN_AP_WMM_Cfg * wlApWmm,
		      IFX_MAPI_WLAN_WMM_AC ac)
{
	char8 *pValue = NULL, sCommand[MAX_DATA_LEN];

	IFX_MAPI_DEBUG(fd, "/tmp/WLAN_GetWmmApSettings", "");

	switch (ac) {
	case IFX_MAPI_WLAN_WMM_BE:
		/* ECWmin */
		gsprintf(sCommand, T("ap_cwMin_BE"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("15"));
		wlApWmm->ECWmin = gatoi(pValue);

		/* ECWmax */
		gsprintf(sCommand, T("ap_cwMax_BE"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("1023"));
		wlApWmm->ECWmax = gatoi(pValue);

		/* AIFSN */
		gsprintf(sCommand, T("ap_aifsn_BE"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("3"));
		wlApWmm->AIFSN = gatoi(pValue);

		/* TXOP */
		gsprintf(sCommand, T("ap_txop_BE"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
		wlApWmm->TXOP = gatoi(pValue);

		/* admission control */
		gsprintf(sCommand, T("ap_admCntrl_BE"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
		wlApWmm->admCntrl = gatoi(pValue);

		/* Ack policy */
		gsprintf(sCommand, T("ap_ackPolicy_BE"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
		wlApWmm->ackPolicyEna = gatoi(pValue);

		break;

	case IFX_MAPI_WLAN_WMM_BK:
		/* ECWmin */
		gsprintf(sCommand, T("ap_cwMin_BK"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("15"));
		wlApWmm->ECWmin = gatoi(pValue);

		/* ECWmax */
		gsprintf(sCommand, T("ap_cwMax_BK"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("1023"));
		wlApWmm->ECWmax = gatoi(pValue);

		/* AIFSN */
		gsprintf(sCommand, T("ap_aifsn_BK"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("3"));
		wlApWmm->AIFSN = gatoi(pValue);

		/* TXOP */
		gsprintf(sCommand, T("ap_txop_BK"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
		wlApWmm->TXOP = gatoi(pValue);

		/* admission control */
		gsprintf(sCommand, T("ap_admCntrl_BK"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
		wlApWmm->admCntrl = gatoi(pValue);

		/* Ack policy */
		gsprintf(sCommand, T("ap_ackPolicy_BK"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
		wlApWmm->ackPolicyEna = gatoi(pValue);

		break;
	case IFX_MAPI_WLAN_WMM_VI:
		/* ECWmin */
		gsprintf(sCommand, T("ap_cwMin_VI"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("15"));
		wlApWmm->ECWmin = gatoi(pValue);

		/* ECWmax */
		gsprintf(sCommand, T("ap_cwMax_VI"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("1023"));
		wlApWmm->ECWmax = gatoi(pValue);

		/* AIFSN */
		gsprintf(sCommand, T("ap_aifsn_VI"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("3"));
		wlApWmm->AIFSN = gatoi(pValue);

		/* TXOP */
		gsprintf(sCommand, T("ap_txop_VI"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
		wlApWmm->TXOP = gatoi(pValue);

		/* admission control */
		gsprintf(sCommand, T("ap_admCntrl_VI"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
		wlApWmm->admCntrl = gatoi(pValue);

		/* Ack policy */
		gsprintf(sCommand, T("ap_ackPolicy_VI"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
		wlApWmm->ackPolicyEna = gatoi(pValue);

		break;
	case IFX_MAPI_WLAN_WMM_VO:
		/* ECWmin */
		gsprintf(sCommand, T("ap_cwMin_VO"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("15"));
		wlApWmm->ECWmin = gatoi(pValue);

		/* ECWmax */
		gsprintf(sCommand, T("ap_cwMax_VO"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("1023"));
		wlApWmm->ECWmax = gatoi(pValue);

		/* AIFSN */
		gsprintf(sCommand, T("ap_aifsn_VO"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("3"));
		wlApWmm->AIFSN = gatoi(pValue);

		/* TXOP */
		gsprintf(sCommand, T("ap_txop_VO"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
		wlApWmm->TXOP = gatoi(pValue);

		/* admission control */
		gsprintf(sCommand, T("ap_admCntrl_VO"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
		wlApWmm->admCntrl = gatoi(pValue);

		/* Ack policy */
		gsprintf(sCommand, T("ap_ackPolicy_VO"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
		wlApWmm->ackPolicyEna = gatoi(pValue);

		break;
	default:
		IFX_MAPI_DEBUG(fd, "/tmp/WLAN_GetWmmApSettings",
			       "Illegal value for access category");
		break;
	}
	return;
}

/**

   \param wp      web page structure

   \param wlStaWmm

   \param apIndex
*/
void
ltq_get_wlan_wmmStaConfig(httpd_t wp, IFX_MAPI_WLAN_STA_WMM_Cfg * wlStaWmm,
			  IFX_MAPI_WLAN_WMM_AC ac)
{
	char8 *pValue = NULL, sCommand[MAX_DATA_LEN];

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_wlan_wmmStaConfig", "");

	switch (ac) {
	case IFX_MAPI_WLAN_WMM_BE:
		/* ECWmin */
		gsprintf(sCommand, T("sta_cwMin_BE"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("15"));
		wlStaWmm->ECWmin = gatoi(pValue);

		/* ECWmax */
		gsprintf(sCommand, T("sta_cwMax_BE"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("1023"));
		wlStaWmm->ECWmax = gatoi(pValue);

		/* AIFSN */
		gsprintf(sCommand, T("sta_aifsn_BE"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("3"));
		wlStaWmm->AIFSN = gatoi(pValue);

		/* TXOP */
		gsprintf(sCommand, T("sta_txop_BE"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
		wlStaWmm->TXOP = gatoi(pValue);

		/* Ack policy */
		gsprintf(sCommand, T("sta_ackPolicy_BE"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
		wlStaWmm->ackPolicyEna = gatoi(pValue);

		break;

	case IFX_MAPI_WLAN_WMM_BK:
		/* ECWmin */
		gsprintf(sCommand, T("sta_cwMin_BK"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("15"));
		wlStaWmm->ECWmin = gatoi(pValue);

		/* ECWmax */
		gsprintf(sCommand, T("sta_cwMax_BK"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("1023"));
		wlStaWmm->ECWmax = gatoi(pValue);

		/* AIFSN */
		gsprintf(sCommand, T("sta_aifsn_BK"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("3"));
		wlStaWmm->AIFSN = gatoi(pValue);

		/* TXOP */
		gsprintf(sCommand, T("sta_txop_BK"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
		wlStaWmm->TXOP = gatoi(pValue);

		/* Ack policy */
		gsprintf(sCommand, T("sta_ackPolicy_BK"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
		wlStaWmm->ackPolicyEna = gatoi(pValue);

		break;
	case IFX_MAPI_WLAN_WMM_VI:
		/* ECWmin */
		gsprintf(sCommand, T("sta_cwMin_VI"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("15"));
		wlStaWmm->ECWmin = gatoi(pValue);

		/* ECWmax */
		gsprintf(sCommand, T("sta_cwMax_VI"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("1023"));
		wlStaWmm->ECWmax = gatoi(pValue);

		/* AIFSN */
		gsprintf(sCommand, T("sta_aifsn_VI"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("3"));
		wlStaWmm->AIFSN = gatoi(pValue);

		/* TXOP */
		gsprintf(sCommand, T("sta_txop_VI"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
		wlStaWmm->TXOP = gatoi(pValue);

		/* Ack policy */
		gsprintf(sCommand, T("sta_ackPolicy_VI"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
		wlStaWmm->ackPolicyEna = gatoi(pValue);

		break;
	case IFX_MAPI_WLAN_WMM_VO:
		/* ECWmin */
		gsprintf(sCommand, T("sta_cwMin_VO"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("15"));
		wlStaWmm->ECWmin = gatoi(pValue);

		/* ECWmax */
		gsprintf(sCommand, T("sta_cwMax_VO"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("1023"));
		wlStaWmm->ECWmax = gatoi(pValue);

		/* AIFSN */
		gsprintf(sCommand, T("sta_aifsn_VO"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("3"));
		wlStaWmm->AIFSN = gatoi(pValue);

		/* TXOP */
		gsprintf(sCommand, T("sta_txop_VO"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
		wlStaWmm->TXOP = gatoi(pValue);

		/* Ack policy */
		gsprintf(sCommand, T("sta_ackPolicy_VO"));
		pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
		wlStaWmm->ackPolicyEna = gatoi(pValue);

		break;
	default:
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_wlan_wmmStaConfig",
			       "Illegal value for access category");
		break;
	}
	return;
}

#ifdef CONFIG_FEATURE_IFX_WIRELESS_ATH
void ifx_set_wlan_settings(httpd_t wp, char_t * path, char_t * query)
{

	char_t *pDomain = ifx_httpdGetVar(wp, T("wlan_domain"), T(""));
	char_t *pWlan = ifx_httpdGetVar(wp, T("wlan_enable"), T(""));
	char_t *pChannel = ifx_httpdGetVar(wp, T("channel"), T(""));
	char_t *pHiddenSsid = ifx_httpdGetVar(wp, T("hiddenSsid"), T(""));
	char_t *pESSID = ifx_httpdGetVar(wp, T("essid"), T(""));
	char_t *pAPName = ifx_httpdGetVar(wp, T("nick"), T(""));
	char_t *pOPRate = ifx_httpdGetVar(wp, T("op_rate"), T(""));
	char_t *pCTS = ifx_httpdGetVar(wp, T("cts_mode"), T(""));
	char_t *pPreamble = ifx_httpdGetVar(wp, T("preamble"), T(""));
	char_t *pPowerLevel = ifx_httpdGetVar(wp, T("power_level"), T(""));
	char_t *pDTIM = ifx_httpdGetVar(wp, T("dtim_intval"), T(""));
	char_t *pBeacon = ifx_httpdGetVar(wp, T("beacon_interval"), T(""));
	char_t *pRTS = ifx_httpdGetVar(wp, T("rts"), T(""));
	char_t *pFTS = ifx_httpdGetVar(wp, T("fts"), T(""));
	char_t sChannel[MAX_DATA_LEN], sHiddenSsid[MAX_DATA_LEN],
	    sESSID[MAX_DATA_LEN];
	char_t sAPName[MAX_DATA_LEN], sOPRate[MAX_DATA_LEN];
	char_t sPreamble[MAX_DATA_LEN], sBeacon[MAX_DATA_LEN];
	char_t sRTS[MAX_DATA_LEN], sFTS[MAX_DATA_LEN],
	    sCommand[MAX_FILELINE_LEN];
	char_t sDomain[MAX_DATA_LEN], sWlan[MAX_DATA_LEN];
	char_t sCTS[MAX_DATA_LEN], sPowerLevel[MAX_DATA_LEN],
	    sDTIM[MAX_DATA_LEN];
	char_t sWlan_Command[MAX_FILELINE_LEN];

	ifx_web_convert_string(pESSID);
	ifx_web_convert_string(pAPName);

	if (pChannel[0] == 0 && pBeacon[0] == 0 && pRTS[0] == 0 && pFTS[0] == 0) {
		ifx_httpdError(wp, 500, "Failed to get data form HTML page!\n");
		return;
	}
	// Set to rc.conf file

	gsprintf(sChannel, T("WLAN_CHANNEL=\"%s\"\n"), pChannel);
	gsprintf(sHiddenSsid, T("WLAN_HIDDEN_SSID=\"%d\"\n"),
		 atoi(pHiddenSsid));
	gsprintf(sESSID, T("WLAN_ESSID=\"%s\"\n"), pESSID);
	gsprintf(sAPName, T("WLAN_AP_NAME=\"%s\"\n"), pAPName);
	gsprintf(sOPRate, T("WLAN_OP_RATE=\"%d\"\n"), atoi(pOPRate));
	gsprintf(sPreamble, T("WLAN_PREAMBLE=\"%d\"\n"), atoi(pPreamble));
	gsprintf(sBeacon, T("WLAN_BEACON_INTERVAL=\"%d\"\n"), atoi(pBeacon));
	gsprintf(sRTS, T("WLAN_RTS=\"%d\"\n"), atoi(pRTS));
	gsprintf(sFTS, T("WLAN_FTS=\"%d\"\n"), atoi(pFTS));

	gsprintf(sDomain, T("WLAN_DOMAIN=\"%s\"\n"), pDomain);

	if (pDTIM[0] == 0) {
		ifx_httpdError(wp, 500, "Failed to get data from HTML page!\n");
		return;
	}
	gsprintf(sDTIM, T("WLAN_DTIM_INTERVAL=\"%s\"\n"), pDTIM);

	gsprintf(sCTS, T("WLAN_CTS=\"%s\"\n"), pCTS);

	gsprintf(sPowerLevel, T("WLAN_POWER_LEVEL=\"%s\"\n"), pPowerLevel);

	gsprintf(sCommand, T("ifconfig %s down"), IFX_WLAN_IF);
	system(sCommand);

	gsprintf(sWlan, T("wlan_enable=\"%d\"\n"), atoi(pWlan));

	ifx_SetCfgData1(FILE_RC_CONF, TAG_WLAN_STATUS, IFX_F_MODIFY, 1, sWlan);

	if (atoi(pWlan) == 0) {
		memset(sWlan_Command, 0x00, MAX_FILELINE_LEN);
		gsprintf(sWlan_Command, T("ifconfig %s down"), IFX_WLAN_IF);
		system(sWlan_Command);
		gsprintf(sWlan_Command, T("brctl delif br0 %s"), IFX_WLAN_IF);
		system(sWlan_Command);
		// 6101101:hsur we don't need this anymore
		// 610311:linmars only Amaozn needs it
#ifdef CPU_AMAZON
		system("swreset wireless_down");
#else
		system("/etc/rc.d/rc.bringup_wireless stop");
#endif				/* CPU_AMAZON */
	}

	ifx_SetCfgData(FILE_RC_CONF, TAG_WLAN_SETTINGS, 14,
		       "WLAN_debug_LVL=\"0\"\n", sDomain, sChannel,
		       sHiddenSsid, sESSID, sAPName, sOPRate,
		       sPowerLevel, sPreamble, sBeacon, sRTS, sFTS, sDTIM,
		       sCTS);

	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}

	if (atoi(pWlan) == 1) {
		memset(sCommand, 0x00, MAX_FILELINE_LEN);
		gsprintf(sCommand, T("/etc/rc.d/rc.bringup_wireless restart"));
		system(sCommand);
	}
	websNextPage(wp);
}

//////////////////////////////////////////////////////////////////////////////////
// wireless_security.asp for AMAZON
//

int
websGetIPAddress(char_t * Tag, char_t * symbol, int nReqIdx, char_t * pRetValue)
{
	char_t sFullIPValue[MAX_FILELINE_LEN];
	char_t sIpaddr[MAX_DATA_LEN];
	char_t *ip;
	int i = 0;
	int nIndex = 0;

	sFullIPValue[0] = '\0';
	sIpaddr[0] = '\0';
	gstrcpy(pRetValue, "");

	if (ifx_GetCfgData(FILE_RC_CONF, Tag, symbol, sFullIPValue) == 0) {
		return -1;
	}

	websGetIFInfo(OTHER_IF_TYPE, IP_INFO, 1, nReqIdx, TRUE, NULL,
		      pRetValue);
/*  	for (i = 1; i <= nReqIdx; i++)
    {
        gstrcpy(sIpaddr, sFullIPValue);
        ip = strtok(sIpaddr, ".");
        nIndex = 1;
        while (ip != NULL && nIndex < i )
        {
            nIndex++;
            ip = strtok(NULL, ".");
        }

        if (i == nReqIdx)
        {
            gstrcpy(pRetValue, (const char_t*)ip);
            return 1;
        }
    } */

	return 1;
}

void ifx_set_wlan_security(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pEncryType, *pAuthType, *pKeyUsed, *pIsPassPhrase, *p1xKeyLen;
	char_t *pKey1, *pKey2, *pKey3, *pKey4, *pPsk;
	char_t *pNas_iden;
	char_t *pOwnIP1, *pOwnIP2, *pOwnIP3, *pOwnIP4;
	char_t *pRadiusIP1, *pRadiusIP2, *pRadiusIP3, *pRadiusIP4;
	char_t *pRadius_port, *pRadius_secret;
	char_t sEncryType[MAX_DATA_LEN], sAuthType[MAX_DATA_LEN];
	char_t sKeyUsed[MAX_DATA_LEN], sIsPassPhrase[MAX_FILELINE_LEN];
	char_t sNas_iden[MAX_DATA_LEN], sOwnIP[MAX_DATA_LEN];
	char_t sRadiusIP[MAX_DATA_LEN], s1xKeyLen[MAX_DATA_LEN],
	    sRadius_port[MAX_DATA_LEN], sRadius_secret[MAX_DATA_LEN];
	char_t sKey1[MAX_FILELINE_LEN], sKey2[MAX_FILELINE_LEN],
	    sKey3[MAX_FILELINE_LEN], sKey4[MAX_FILELINE_LEN];
	char_t sPsk[MAX_FILELINE_LEN], sPassPhrase[MAX_FILELINE_LEN];
	char_t *pGKeyEnable, *pGKeyRenewal;
	char_t sGKeyEnable[MAX_FILELINE_LEN];
	char_t sGKeyRenewal[MAX_FILELINE_LEN];
	char_t sTempIp1[MAX_FILELINE_LEN], sTempIp2[MAX_FILELINE_LEN];
	char_t sTempIp3[MAX_FILELINE_LEN], sTempIp4[MAX_FILELINE_LEN];
	char_t sValue[MAX_FILELINE_LEN];
	char_t sWepKey[MAX_FILELINE_LEN], sWepKeyIdx[MAX_DATA_LEN];
	char_t sESSID[MAX_FILELINE_LEN];
	char_t sCommand[MAX_FILELINE_LEN];

	a_assert(wp);

	sKey1[0] = '\0';
	sKey2[0] = '\0';
	sKey3[0] = '\0';
	sKey4[0] = '\0';
	sPsk[0] = '\0';
	sPassPhrase[0] = '\0';
	sESSID[0] = '\0';
	sWepKey[0] = '\0';
	sGKeyEnable[0] = '\0';
	sGKeyRenewal[0] = '\0';
	sOwnIP[0] = '\0';
	sTempIp1[0] = '\0';
	sTempIp2[0] = '\0';
	sTempIp3[0] = '\0';
	sTempIp4[0] = '\0';
	sValue[0] = '\0';

	// Get value from ASP file
	pAuthType = ifx_httpdGetVar(wp, T("AuthType"), T(""));
	pEncryType = ifx_httpdGetVar(wp, T("EncryType"), T(""));

	if (pEncryType[0] == 0 && pAuthType[0] == 0) {
		ifx_httpdError(wp, 500, "Failed to get data form HTML page!\n");
		return;
	}

	gsprintf(sAuthType, T("WLAN_AUTH_TYPE=\"%d\"\n"), atoi(pAuthType));
	gsprintf(sEncryType, T("WLAN_ENCRY_TYPE=\"%d\"\n"), atoi(pEncryType));

	gsprintf(sCommand, T("ifconfig %s down"), IFX_WLAN_IF);
	system(sCommand);

	pNas_iden = ifx_httpdGetVar(wp, T("Nas_iden"), T(""));
	pOwnIP1 = ifx_httpdGetVar(wp, T("own_ip1"), T(""));
	pOwnIP2 = ifx_httpdGetVar(wp, T("own_ip2"), T(""));
	pOwnIP3 = ifx_httpdGetVar(wp, T("own_ip3"), T(""));
	pOwnIP4 = ifx_httpdGetVar(wp, T("own_ip4"), T(""));
	pRadiusIP1 = ifx_httpdGetVar(wp, T("radius_ip1"), T(""));
	pRadiusIP2 = ifx_httpdGetVar(wp, T("radius_ip2"), T(""));
	pRadiusIP3 = ifx_httpdGetVar(wp, T("radius_ip3"), T(""));
	pRadiusIP4 = ifx_httpdGetVar(wp, T("radius_ip4"), T(""));
	pRadius_port = ifx_httpdGetVar(wp, T("radius_port"), T(""));
	pRadius_secret = ifx_httpdGetVar(wp, T("radius_secret"), T(""));
	pGKeyEnable = ifx_httpdGetVar(wp, T("GKeyEnable"), T(""));
	pGKeyRenewal = ifx_httpdGetVar(wp, T("GKeyRenew"), T(""));

	if (!*pGKeyEnable) {
		ifx_GetCfgData(FILE_RC_CONF, TAG_WLAN_SECURITY,
			       "WLAN_GKEY_ENABLE", sValue);
		gsprintf(sGKeyEnable, T("WLAN_GKEY_ENABLE=\"%s\"\n"), sValue);
	} else
		gsprintf(sGKeyEnable, T("WLAN_GKEY_ENABLE=\"%s\"\n"),
			 pGKeyEnable);

	if (!*pGKeyRenewal) {
		ifx_GetCfgData(FILE_RC_CONF, TAG_WLAN_SECURITY,
			       "WLAN_GKEY_RENEWAL", sValue);
		gsprintf(sGKeyRenewal, T("WLAN_GKEY_RENEWAL=\"%s\"\n"), sValue);
	} else
		gsprintf(sGKeyRenewal, T("WLAN_GKEY_RENEWAL=\"%s\"\n"),
			 pGKeyRenewal);

	/* If one of RADIUS IP is empty, obtain the original from rc.conf */
	if (!*pRadiusIP1 || !*pRadiusIP2 ||
	    !*pRadiusIP3 || !*pRadiusIP4 ||
	    !*pOwnIP1 || !*pOwnIP2 || !*pOwnIP3 || !*pOwnIP4 ||
	    pNas_iden[0] == 0 || pRadius_secret[0] == 0) {
		if (websGetIPAddress
		    (TAG_WLAN_SECURITY, "WLAN_OWN_IP", 1, sTempIp1) != 1) {
			ifx_httpdError(wp, 500,
				       " --- The WLAN_OWN_IP is not got !\n");
			return;
		}

		if (websGetIPAddress
		    (TAG_WLAN_SECURITY, "WLAN_OWN_IP", 2, sTempIp2) != 1) {
			ifx_httpdError(wp, 500,
				       " --- The WLAN_OWN_IP is not got !\n");
			return;
		}

		if (websGetIPAddress
		    (TAG_WLAN_SECURITY, "WLAN_OWN_IP", 3, sTempIp3) != 1) {
			ifx_httpdError(wp, 500,
				       " --- The WLAN_OWN_IP is not got  !\n");
			return;
		}

		if (websGetIPAddress
		    (TAG_WLAN_SECURITY, "WLAN_OWN_IP", 4, sTempIp4) != 1) {
			ifx_httpdError(wp, 500,
				       " --- The WLAN_OWN_IP is not got  !\n");
			return;
		}

		gsprintf(sOwnIP, T("WLAN_OWN_IP=\"%s.%s.%s.%s\"\n"),
			 sTempIp1, sTempIp2, sTempIp3, sTempIp4);

		if (ifx_GetCfgData(FILE_RC_CONF, TAG_WLAN_SECURITY,
				   "WLAN_NAS_ID", sValue) != 1) {
			ifx_httpdError(wp, 500,
				       " --- The WLAN_NAS_ID is not got  !\n");
			return;
		}

		gsprintf(sNas_iden, T("WLAN_NAS_ID=\"%s\"\n"), sValue);

		if (websGetIPAddress(TAG_WLAN_SECURITY, "WLAN_RADIUS_SERVER_IP",
				     1, sTempIp1) != 1) {
			ifx_httpdError(wp, 500,
				       " --- The WLAN_RADIUS_SERVER_IP1 is"
				       " not got !\n");
			return;
		}

		if (websGetIPAddress(TAG_WLAN_SECURITY, "WLAN_RADIUS_SERVER_IP",
				     2, sTempIp2) != 1) {
			ifx_httpdError(wp, 500,
				       " --- The WLAN_RADIUS_SERVER_IP2 is"
				       " not got !\n");
			return;
		}

		if (websGetIPAddress(TAG_WLAN_SECURITY, "WLAN_RADIUS_SERVER_IP",
				     3, sTempIp3) != 1) {
			ifx_httpdError(wp, 500,
				       " --- The WLAN_RADIUS_SERVER_IP3 is"
				       " not got  !\n");
			return;
		}

		if (websGetIPAddress(TAG_WLAN_SECURITY, "WLAN_RADIUS_SERVER_IP",
				     4, sTempIp4) != 1) {
			ifx_httpdError(wp, 500,
				       " --- The WLAN_RADIUS_SERVER_IP4 is"
				       " not got  !\n");
			return;
		}

		gsprintf(sRadiusIP,
			 T("WLAN_RADIUS_SERVER_IP=\"%s.%s.%s.%s\"\n"), sTempIp1,
			 sTempIp2, sTempIp3, sTempIp4);

		if (ifx_GetCfgData(FILE_RC_CONF, TAG_WLAN_SECURITY,
				   "WLAN_RADIUS_SERVER_PORT", sValue) != 1) {
			ifx_httpdError(wp, 500,
				       " --- The WLAN_RADIUS_SERVER_PORT is"
				       " not got  !\n");
			return;
		}

		gsprintf(sRadius_port, T("WLAN_RADIUS_SERVER_PORT=\"%s\"\n"),
			 sValue);

		if (ifx_GetCfgData(FILE_RC_CONF, TAG_WLAN_SECURITY,
				   "WLAN_RADIUS_SERVER_SECRET", sValue) != 1) {
			ifx_httpdError(wp, 500,
				       " --- The WLAN_RADIUS_SERVER_SECRET is"
				       " not got  !\n");
			return;
		}

		gsprintf(sRadius_secret,
			 T("WLAN_RADIUS_SERVER_SECRET=\"%s\"\n"), sValue);
	} else {
		gsprintf(sOwnIP, T("WLAN_OWN_IP=\"%s.%s.%s.%s\"\n"),
			 pOwnIP1, pOwnIP2, pOwnIP3, pOwnIP4);
		gsprintf(sNas_iden, T("WLAN_NAS_ID=\"%s\"\n"), pNas_iden);
		gsprintf(sRadiusIP,
			 T("WLAN_RADIUS_SERVER_IP=\"%s.%s.%s.%s\"\n"),
			 pRadiusIP1, pRadiusIP2, pRadiusIP3, pRadiusIP4);
		gsprintf(sRadius_port, T("WLAN_RADIUS_SERVER_PORT=\"%s\"\n"),
			 pRadius_port);
		gsprintf(sRadius_secret,
			 T("WLAN_RADIUS_SERVER_SECRET=\"%s\"\n"),
			 pRadius_secret);
	}

	switch (atoi(pAuthType)) {
	case WLAN_AUTH_OPEN:
	case WLAN_AUTH_SHARED:
	case WLAN_AUTH_SWITCH:

		if (atoi(pEncryType) == WLAN_ENCRY_NONE &&
		    atoi(pAuthType) == WLAN_AUTH_OPEN) {
			gsprintf(sKeyUsed, T("WLAN_KEY_USED=\"0\"\n"));
			gsprintf(sKey1, T("WLAN_KEY1=\"0\"\n"));
			gsprintf(sKey2, T("WLAN_KEY2=\"0\"\n"));
			gsprintf(sKey3, T("WLAN_KEY3=\"0\"\n"));
			gsprintf(sKey4, T("WLAN_KEY4=\"0\"\n"));
			gsprintf(s1xKeyLen, T("WLAN_8021X_KEYLEN=\"0\"\n"));
			gsprintf(sIsPassPhrase, T("WLAN_ISPASSPHRASE=\"0\"\n"));
			gsprintf(sPsk, T("WLAN_PSK=\"0\"\n"));
		} else if (atoi(pEncryType) == WLAN_ENCRY_NONE ||
			   atoi(pEncryType) == WLAN_ENCRY_WEP64 ||
			   atoi(pEncryType) == WLAN_ENCRY_WEP128) {
			pKeyUsed = ifx_httpdGetVar(wp, T("KeyUsed"), T(""));
			pKey1 = ifx_httpdGetVar(wp, T("Key1"), T(""));
			pKey2 = ifx_httpdGetVar(wp, T("Key2"), T(""));
			pKey3 = ifx_httpdGetVar(wp, T("Key3"), T(""));
			pKey4 = ifx_httpdGetVar(wp, T("Key4"), T(""));
			if (pKey1[0] == 0)
				gsprintf(pKey1, "0");
			if (pKey2[0] == 0)
				gsprintf(pKey2, "0");
			if (pKey3[0] == 0)
				gsprintf(pKey3, "0");
			if (pKey4[0] == 0)
				gsprintf(pKey4, "0");

			gsprintf(sKeyUsed, T("WLAN_KEY_USED=\"%d\"\n"),
				 atoi(pKeyUsed));
			gsprintf(sKey1, T("WLAN_KEY1=\"%s\"\n"), pKey1);
			gsprintf(sKey2, T("WLAN_KEY2=\"%s\"\n"), pKey2);
			gsprintf(sKey3, T("WLAN_KEY3=\"%s\"\n"), pKey3);
			gsprintf(sKey4, T("WLAN_KEY4=\"%s\"\n"), pKey4);
			gsprintf(s1xKeyLen, T("WLAN_8021X_KEYLEN=\"0\"\n"));
			gsprintf(sIsPassPhrase, T("WLAN_ISPASSPHRASE=\"0\"\n"));
			gsprintf(sPsk, T("WLAN_PSK=\"0\"\n"));

			trace(8, T("Check Key used here..............\n"));
			trace(8, "Key used is %s\n", pKeyUsed);

			// Get Active Key
			if (atoi(pKeyUsed) == 0) {
				ifx_httpdError(wp, 500,
					       "Set Active key error\n");
				return;
			} else if (atoi(pKeyUsed) == 1) {
				gstrcpy(sWepKeyIdx, "1");
				gstrcpy(sWepKey, pKey1);
				gsprintf(sKeyUsed, T("WLAN_KEY_USED=\"1\"\n"));
			} else if (atoi(pKeyUsed) == 2) {
				gstrcpy(sWepKeyIdx, "2");
				gstrcpy(sWepKey, pKey2);
				gsprintf(sKeyUsed, T("WLAN_KEY_USED=\"2\"\n"));
			} else if (atoi(pKeyUsed) == 3) {
				gstrcpy(sWepKeyIdx, "3");
				gstrcpy(sWepKey, pKey3);
				gsprintf(sKeyUsed, T("WLAN_KEY_USED=\"3\"\n"));
			} else if (atoi(pKeyUsed) == 4) {
				gstrcpy(sWepKeyIdx, "4");
				gstrcpy(sWepKey, pKey4);
				gsprintf(sKeyUsed, T("WLAN_KEY_USED=\"4\"\n"));
			}
		} else {
			ifx_httpdError(wp, 500, "Wrong Encripytion Type!\n");
			return;
		}
		break;

	case IFX_MAPI_WLAN_RADIUS:
		switch (atoi(pEncryType)) {
		case WLAN_ENCRY_1X:	// 802.1X (WEP)
		case WLAN_ENCRY_TKIP:	// TKIP
		case WLAN_ENCRY_AES:	// AES
		case WLAN_ENCRY_TKIP_AES:
			p1xKeyLen =
			    ifx_httpdGetVar(wp, T("P1x_key_len"), T(""));
			gsprintf(sKeyUsed, T("WLAN_KEY_USED=\"0\"\n"));
			gsprintf(sKey1, T("WLAN_KEY1=\"0\"\n"));
			gsprintf(sKey2, T("WLAN_KEY2=\"0\"\n"));
			gsprintf(sKey3, T("WLAN_KEY3=\"0\"\n"));
			gsprintf(sKey4, T("WLAN_KEY4=\"0\"\n"));
			gsprintf(s1xKeyLen, T("WLAN_8021X_KEYLEN=\"%d\"\n"),
				 atoi(p1xKeyLen));
			gsprintf(sIsPassPhrase, T("WLAN_ISPASSPHRASE=\"0\"\n"));
			gsprintf(sPsk, T("WLAN_PSK=\"0\"\n"));
			break;
		default:
			ifx_httpdError(wp, 500, "Wrong Encripytion Type!\n");
			return;
		}
		break;
	case WLAN_AUTH_PSK:
	case WLAN_AUTH_PSK2:
		switch (atoi(pEncryType)) {
		case WLAN_ENCRY_TKIP:	// TKIP
		case WLAN_ENCRY_AES:	// AES
		case WLAN_ENCRY_TKIP_AES:
			pIsPassPhrase =
			    ifx_httpdGetVar(wp, T("IsPassPhrase"), T(""));
			pPsk = ifx_httpdGetVar(wp, T("PSK"), T(""));
			ifx_web_convert_string(pPsk);

			gsprintf(sKeyUsed, T("WLAN_KEY_USED=\"0\"\n"));
			gsprintf(sKey1, T("WLAN_KEY1=\"0\"\n"));
			gsprintf(sKey2, T("WLAN_KEY2=\"0\"\n"));
			gsprintf(sKey3, T("WLAN_KEY3=\"0\"\n"));
			gsprintf(sKey4, T("WLAN_KEY4=\"0\"\n"));
			gsprintf(s1xKeyLen, T("WLAN_8021X_KEYLEN=\"0\"\n"));
			gsprintf(sIsPassPhrase, T("WLAN_ISPASSPHRASE=\"%d\"\n"),
				 atoi(pIsPassPhrase));
			gsprintf(sPsk, T("WLAN_PSK=\"%s\"\n"), pPsk);
			break;
		default:
			ifx_httpdError(wp, 500, "Wrong Encripytion Type!\n");
			return;
		}
		break;
	default:
		ifx_httpdError(wp, 500, T("Authentication Range Error = %s"),
			       pAuthType);
		return;
	}

	ifx_SetCfgData(FILE_RC_CONF, TAG_WLAN_SECURITY, 17, sAuthType,
		       sEncryType, sKeyUsed, sKey1, sKey2, sKey3, sKey4, sOwnIP,
		       sNas_iden, sRadiusIP, sRadius_port, sRadius_secret,
		       s1xKeyLen, sIsPassPhrase, sPsk, sGKeyEnable,
		       sGKeyRenewal);

	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}

	system("/etc/rc.d/rc.bringup_wireless restart");

	websNextPage(wp);
}
#endif				/* CONFIG_FEATURE_IFX_WIRELESS_ATH */

/**
   This function is called from web page wlan_basic.asp. Values entered
   on the web page are retrieved and stored in corresponding structures of type
   IFX_MAPI_WLAN_PhyCfg and IFX_MAPI_WLAN_MainCfg. These structures are provided
   to IFX WLAN MAPI.

   \param wp      web page structure

   \param path

   \param query

   \return
   None
*/
void IFX_WLAN_SetBasicSettings(httpd_t wp, char_t * path, char_t * query)
{
	IFX_MAPI_WLAN_PhyCfg wlan_phy;
	IFX_MAPI_WLAN_MainCfg *wlMain = NULL;
	int32 nCount, i, j;
	int32 ret = IFX_SUCCESS, flags = IFX_F_DEFAULT, oper = 0, apIndex = -1;
	char8 *pApVapActionType, *pValue, *cpeId;
	bool netModeVapEna = FALSE;

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetBasicSettings", "");

	memset(&wlan_phy, 0, sizeof(IFX_MAPI_WLAN_PhyCfg));
	/* set section name of cpeID and pcpeId */
	sprintf(wlan_phy.iid.cpeId.secName, "%s", TAG_WLAN_PHY);
	sprintf(wlan_phy.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
	/* set cpeId.ID and pcpeId.ID of wlan_phy */
	cpeId = ifx_httpdGetVar(wp, T("cpeId"), T(""));
	wlan_phy.iid.cpeId.Id = atoi(cpeId);
	apIndex = wlan_phy.iid.cpeId.Id - 1;
	/* parent is always LAN -> fixed value = 1 */
	wlan_phy.iid.pcpeId.Id = 1;

	pApVapActionType = ifx_httpdGetVar(wp, T("submit_action"), T(""));
	if (!pApVapActionType) {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetBasicSettings",
			"(!pApVapActionType)");
		return;
	}

	if (!gstrcmp(pApVapActionType, "modifycommon")) {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetBasicSettings", "");
		if (ltq_mapi_get_wlan_vendor(wlan_phy.iid.cpeId.Id, IFX_F_DEFAULT) ==
			LTQ_MAPI_WLAN_VENDOR_QCA) {
			if ((ret = ifx_mapi_get_all_wlan_main_config(
				(uint32 *) &nCount, &wlMain, flags)) != IFX_SUCCESS) {
				IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetBasicSettings", "");
				ifx_httpdError(wp, 400, T("Failed to get all wlan main config\n"));
				return;
			}

			if (nCount == 0) {
				ifx_httpdError(wp, 400, "Invalid value for count tag");
				IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetBasicSettings", "");
				goto IFX_Handler;
			}
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetBasicSettings",
					   "nCount: %d", nCount);

			for (j = 0; j < nCount; j++) {
				IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetBasicSettings",
						   "j: %d, nCount: %d", j, nCount);
				if (wlan_phy.standard == IFX_MAPI_WLAN_STD_802_11B) {
					/* for 802.11b mode only data rates up to 11Mbit/s are valid */
					/* to do: verify this for all WLAN devices */
					for (i = 0;
						 i < IFX_MAPI_WLAN_MAX_DATA_RATES_NUM;
						 i++) {
						if ((wlMain + j)->operDataRates[i] > 11)
							(wlMain + j)->operDataRates[i] =
								0;
						else if ((wlMain +
							  j)->operDataRates[i] > 0)
							(wlMain + j)->maxBitRate =
								(wlMain +
								 j)->operDataRates[i];
					}
				} else
					if ((wlan_phy.standard == IFX_MAPI_WLAN_STD_802_11G)
					|| (wlan_phy.standard ==
						IFX_MAPI_WLAN_STD_802_11BG)
					|| (wlan_phy.standard ==
						IFX_MAPI_WLAN_STD_802_11BGN)) {
					IFX_MAPI_DEBUG(fd,
							   "/tmp/IFX_WLAN_SetBasicSettings",
							   "");
					/* for 802.11g mode data rates up to 54Mbit/s are valid */
					/* to do: verify this for all WLAN devices */
					(wlMain + j)->operDataRates[0] = 1.0;
					(wlMain + j)->operDataRates[1] = 2.0;
					(wlMain + j)->operDataRates[2] = 5.5;
					(wlMain + j)->operDataRates[3] = 6.0;
					(wlMain + j)->operDataRates[4] = 9.0;
					(wlMain + j)->operDataRates[5] = 11.0;
					(wlMain + j)->operDataRates[6] = 12.0;
					(wlMain + j)->operDataRates[7] = 18.0;
					(wlMain + j)->operDataRates[8] = 24.0;
					(wlMain + j)->operDataRates[9] = 36.0;
					(wlMain + j)->operDataRates[10] = 48.0;
					(wlMain + j)->operDataRates[11] = 54.0;
					(wlMain + j)->operDataRates[12] = 0.0;
					(wlMain + j)->maxBitRate = 54.0;
				} else {
					IFX_MAPI_DEBUG(fd,
							   "/tmp/IFX_WLAN_SetBasicSettings",
							   "standard: %d",
							   wlan_phy.standard);
				}

				oper = IFX_OP_MOD;
				flags = IFX_F_MODIFY | IFX_F_INT_DONT_CONFIGURE;

				(wlMain + j)->iid.config_owner = IFX_WEB;
				if ((ret = ifx_mapi_set_wlan_main_config(oper, wlMain + j,
					flags | IFX_F_DONT_WRITE_TO_FLASH)) != IFX_SUCCESS) {
					IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetBasicSettings", "");
					ifx_httpdError(wp, 400, "Failed to set wlan main config");
					goto IFX_Handler;
				}
			}
		}

		if (g_flagConfigLoaded) {
			/* use stored configuration */
			memcpy(&wlan_phy, &g_wlPhy[apIndex], sizeof(IFX_MAPI_WLAN_PhyCfg));
		}
		else {
			if ((ret = ifx_mapi_get_wlan_static_phy_config(&wlan_phy,
				IFX_F_DEFAULT)) != IFX_SUCCESS) {
				ifx_httpdError(wp, 400, "Failed to get wlan phy config");
				IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetBasicSettings", "");
				goto IFX_Handler;
			}
		}

		pValue = ifx_httpdGetVar(wp, T("op_mode"), T(""));
		wlan_phy.standard = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetBasicSettings", "standard: %d",
			wlan_phy.standard);
		if (ltq_mapi_get_wlan_supported_features(wlan_phy.iid.cpeId.Id,
			IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_NETMODE_PER_VAP) {
			pValue = ifx_httpdGetVar(wp, T("net_mode_vap_ena"), T(""));
			netModeVapEna = gatoi(pValue);
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetBasicSettings",
				"netModeVapEna: %d", netModeVapEna);
			if (!netModeVapEna)
				wlan_phy.netModeClass = LTQ_MAPI_WLAN_NET_CLASS_OFF;
			else {
				pValue = ifx_httpdGetVar(wp, T("net_mode_class"), T(""));
				wlan_phy.netModeClass = gatoi(pValue);
			}
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetBasicSettings",
				"netModeClass: %d", wlan_phy.netModeClass);
		}

		/* now get the rest of the radio configuration */
		pValue = ifx_httpdGetVar(wp, T("wlan_enable"), T(""));
		wlan_phy.radioEnable = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetBasicSettings",
			       "radioEnable: %d", wlan_phy.radioEnable);

		pValue = ifx_httpdGetVar(wp, T("country"), T(""));
		gstrcpy(wlan_phy.country, pValue);

		pValue = ifx_httpdGetVar(wp, T("frequency"), T("0"));
		wlan_phy.freqBand = gatoi(pValue);

		pValue = ifx_httpdGetVar(wp, T("channel"), T(""));
		wlan_phy.channelNo = gatoi(pValue);

		pValue = ifx_httpdGetVar(wp, T("auto_channel_select"), T(""));
		wlan_phy.autoChannelEna = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetBasicSettings",
			       "autoChannelEna: %d", wlan_phy.autoChannelEna);

		pValue = ifx_httpdGetVar(wp, T("ARF"), T(""));
		wlan_phy.autoRateFallBackEna = gatoi(pValue);

		/* get 11n parameters only if 11n/ac standard is selected */
		if (wlan_phy.standard >= IFX_MAPI_WLAN_STD_802_11N) {
			pValue = ifx_httpdGetVar(wp, T("chan_width"), T("2"));
			wlan_phy.phy11N.chanBW = gatoi(pValue);
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetBasicSettings", "chanBW: %d",
				wlan_phy.phy11N.chanBW);
			/* get parameters only if 11n standard is selected */
			if ((wlan_phy.standard == IFX_MAPI_WLAN_STD_802_11N) ||
				(wlan_phy.standard == IFX_MAPI_WLAN_STD_802_11BGN) ||
				(wlan_phy.standard == IFX_MAPI_WLAN_STD_802_11GN) ||
				(wlan_phy.standard == IFX_MAPI_WLAN_STD_802_11AN)) {
				if (wlan_phy.freqBand == IFX_MAPI_WLAN_2_4_GHz_Freq) {
					pValue = ifx_httpdGetVar(wp, T("twenty_fourty_coex"), T(""));
					wlan_phy.phy11N.twentyFourtyCoex = gatoi(pValue);
					if (g_idx == 0)
						g_2040CoexRadio1 = -1;
					else
						g_2040CoexRadio2 = -1;
				} else {
					/* save 20_40 Coexistence mode */
					if (g_idx == 0)
						g_2040CoexRadio1 = wlan_phy.phy11N.twentyFourtyCoex;
					else
						g_2040CoexRadio2 = wlan_phy.phy11N.twentyFourtyCoex;

					wlan_phy.phy11N.twentyFourtyCoex = IFX_DISABLED;
				}
				IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetBasicSettings",
					"twentyFourtyCoex: %d", wlan_phy.phy11N.twentyFourtyCoex);

				if (ltq_mapi_get_wlan_vendor(wlan_phy.iid.cpeId.Id, IFX_F_DEFAULT) ==
					LTQ_MAPI_WLAN_VENDOR_WAVE300) {
					if ((wlan_phy.phy11N.twentyFourtyCoex) ||
						(wlan_phy.phy11N.chanBW != IFX_MAPI_WLAN_BW_20MHZ)) {
						pValue = ifx_httpdGetVar(wp, T("ext_chan"), T(""));
						wlan_phy.phy11N.extChPos = gatoi(pValue);
						IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetBasicSettings", "ext_chan: %d",
							wlan_phy.phy11N.extChPos);
					}
				} else {
					/*
					   if chanBW == 20MHZ, then extension channel is disabled on web =>
					   do not get parameter from web, leave it as it is */
					if (wlan_phy.phy11N.chanBW != IFX_MAPI_WLAN_BW_20MHZ) {
						pValue =
							ifx_httpdGetVar(wp, T("ext_chan"), T(""));
						wlan_phy.phy11N.extChPos = gatoi(pValue);
						IFX_MAPI_DEBUG(fd,
								   "/tmp/IFX_WLAN_SetBasicSettings",
								   "ext_chan: %d",
								   wlan_phy.phy11N.extChPos);
					}

					pValue = ifx_httpdGetVar(wp, T("mcs"), T(""));
					wlan_phy.phy11N.mcs = gatoi(pValue);
					IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetBasicSettings",
							   "mcs: %d", wlan_phy.phy11N.mcs);
				}

				pValue = ifx_httpdGetVar(wp, T("guard_intvl"), T(""));
				wlan_phy.phy11N.guardIntvl = gatoi(pValue);
				IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetBasicSettings",
						   "guardIntvl: %d",
						   wlan_phy.phy11N.guardIntvl);
			} else {
				/* make sure that 11.n settings are valid for legacy modes */
				/* save 20_40 Coexistence mode */
				if (g_idx == 0)
					g_2040CoexRadio1 = wlan_phy.phy11N.twentyFourtyCoex;
				else
					g_2040CoexRadio2 = wlan_phy.phy11N.twentyFourtyCoex;
			}
		}
		oper = IFX_OP_MOD;
		flags = IFX_F_MODIFY;

		wlan_phy.iid.config_owner = IFX_WEB;
		if ((ret = ifx_mapi_set_wlan_phy_config(oper, &wlan_phy, flags)) !=
			IFX_SUCCESS) {
			ifx_httpdError(wp, 400, "Failed to set wlan phy config");
			goto IFX_Handler;
		}
	}

IFX_Handler:
	IFX_MEM_FREE(wlMain);
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetBasicSettings", "");
	websNextPage(wp);
}

/**
   This function is called from web page wlan_adv_radio_settings.asp. Values entered
   on the web page are retrieved and stored in corresponding structures of type
   IFX_MAPI_WLAN_PhyCfg. These structures are provided to IFX WLAN MAPI.

   \param wp      web page structure

   \param path

   \param query

   \return
   None
*/
void
IFX_WLAN_SetAdvancedRadioSettings(httpd_t wp, char_t * path, char_t * query)
{
	IFX_MAPI_WLAN_PhyCfg wlan_phy;
	int32 ret = IFX_SUCCESS, flags = IFX_F_DEFAULT, oper = 0, staticRateIdx = -1;
	char8 *pApVapActionType, *pValue, *cpeId;

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetAdvancedRadioSettings", "");

	memset(&wlan_phy, 0, sizeof(IFX_MAPI_WLAN_PhyCfg));
	/* set section name of cpeID and pcpeId */
	sprintf(wlan_phy.iid.cpeId.secName, "%s", TAG_WLAN_PHY);
	sprintf(wlan_phy.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
	/* set cpeId.ID and pcpeId.ID of wlan_phy */
	cpeId = ifx_httpdGetVar(wp, T("cpeId"), T(""));
	wlan_phy.iid.cpeId.Id = atoi(cpeId);
	/* parent is always LAN -> fixed value = 1 */
	wlan_phy.iid.pcpeId.Id = 1;

	pApVapActionType = ifx_httpdGetVar(wp, T("submit_action"), T(""));
	if (!pApVapActionType) {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetAdvancedRadioSettings",
			       "(!pApVapActionType)");
		return;
	}

	if (!gstrcmp(pApVapActionType, "modify_enhanced_radio")) {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetAdvancedRadioSettings", "");
		if ((ret =
			ifx_mapi_get_wlan_static_phy_config(&wlan_phy,
						  IFX_F_DEFAULT)) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 400, "Failed to get wlan phy config");
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetAdvancedRadioSettings", "");
			return;
		}

		pValue = ifx_httpdGetVar(wp, T("beacon_int"), T(""));
		wlan_phy.beaconIntvl = gatoi(pValue);
		if ((wlan_phy.beaconIntvl < 1) || (wlan_phy.beaconIntvl > 65535)) {
			ifx_httpdError(wp, 400, "Parameter Beacon Interval out of range");
			return;
		}

		pValue = ifx_httpdGetVar(wp, T("preamble"), T(""));
		wlan_phy.preamble = gatoi(pValue);

		pValue = ifx_httpdGetVar(wp, T("power_level"), T(""));
		wlan_phy.powerLvl = gatoi(pValue);

		if (ltq_mapi_get_wlan_vendor(wlan_phy.iid.cpeId.Id, IFX_F_DEFAULT) ==
			LTQ_MAPI_WLAN_VENDOR_QCA) {
			pValue = ifx_httpdGetVar(wp, T("usage_env"), T(""));
			wlan_phy.usageEnv = gatoi(pValue);
		}

		pValue = ifx_httpdGetVar(wp, T("beacon_tx_enable"), T(""));
		wlan_phy.beaconTxEna = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetAdvancedRadioSettings",
			       "beaconTxEna: %d", wlan_phy.beaconTxEna);

		pValue = ifx_httpdGetVar(wp, T("dtim_int"), T(""));
		wlan_phy.dtimInt = gatoi(pValue);
		/*
		   DTIM interval is [1..255]; since wlan_phy_dtimInt is a uint8 type,
		   it is not required to check if wlan_phy.dtimInt > 255 */
		if (wlan_phy.dtimInt < 1) {
			ifx_httpdError(wp, 400,
				       "Parameter DTIM Interval out of range");
			return;
		}

		pValue = ifx_httpdGetVar(wp, T("rts"), T(""));
		wlan_phy.rts = gatoi(pValue);
		if (wlan_phy.rts > 2347) {
			ifx_httpdError(wp, 400,
				       "Parameter RTS threshold out of range [0..2347]");
			return;
		}

		if (ltq_mapi_get_wlan_vendor(wlan_phy.iid.cpeId.Id, IFX_F_DEFAULT) ==
			LTQ_MAPI_WLAN_VENDOR_QCA) {
			pValue = ifx_httpdGetVar(wp, T("fts"), T(""));
			wlan_phy.fts = gatoi(pValue);
			if ((wlan_phy.fts < 256) || (wlan_phy.fts > 2346)) {
				ifx_httpdError(wp, 400,
						   "Parameter Fragmentation Threshold out of range [256...2346]");
				return;
			}
		}

		pValue = ifx_httpdGetVar(wp, T("static_rate"), T("54.0"));

		staticRateIdx = atoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetAdvancedRadioSettings",
			"standard: %d; bandwidth: %d",
			g_wlPhy[g_idx].standard, g_wlPhy[g_idx].phy11N.chanBW);
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetAdvancedRadioSettings",
			"staticRateIdx: %d", staticRateIdx);
		if (g_wlPhy[g_idx].standard >= IFX_MAPI_WLAN_STD_802_11N) {
			if (g_wlPhy[g_idx].phy11N.chanBW == IFX_MAPI_WLAN_BW_20MHZ) {
				if (staticRateIdx) {
					wlan_phy.staticRate = (float)strtod(wlan_11n_20_rates[staticRateIdx], (char **)NULL);
				} else {
					wlan_phy.staticRate = 0;
				}
			}
			else {
				if (staticRateIdx) {
					wlan_phy.staticRate = (float)strtod(wlan_11n_40_rates[staticRateIdx], (char **)NULL);
				} else {
					wlan_phy.staticRate = 0;
				}
			}
		}
		else if (g_wlPhy[g_idx].standard == IFX_MAPI_WLAN_STD_802_11A) {
			if (staticRateIdx) {
				wlan_phy.staticRate = (float)strtod(wlan_11a_rates[staticRateIdx], (char **)NULL);
			} else {
				wlan_phy.staticRate = 0;
			}
		}
		else if (g_wlPhy[g_idx].standard == IFX_MAPI_WLAN_STD_802_11B) {
			if (staticRateIdx) {
				wlan_phy.staticRate = (float)strtod(wlan_11b_rates[staticRateIdx], (char **)NULL);
			} else {
				wlan_phy.staticRate = 0;
			}
		}
		else {
			if (staticRateIdx) {
				wlan_phy.staticRate = (float)strtod(wlan_11g_rates[staticRateIdx], (char **)NULL);
			} else {
				wlan_phy.staticRate = 0;
			}
		}
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetAdvancedRadioSettings",
			"staticRate: %f", wlan_phy.staticRate);

		if (ltq_mapi_get_wlan_supported_features(wlan_phy.iid.cpeId.Id,
			IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_AUTOCOC) {
			pValue = ifx_httpdGetVar(wp, T("wave_auto_coc_ena"), T(""));
			wlan_phy.phyAutoCoC.autoCocEnable = atoi(pValue);
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetAdvancedRadioSettings",
				"autoCocEnable: %d", wlan_phy.phyAutoCoC.autoCocEnable);
			if (wlan_phy.phyAutoCoC.autoCocEnable == 0) {
				pValue = ifx_httpdGetVar(wp, T("wave_num_antenna"), T(""));
				wlan_phy.phyAutoCoC.nAntennas = atoi(pValue);
				IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetAdvancedRadioSettings",
					"nAntennas: %d", wlan_phy.phyAutoCoC.nAntennas);
			}

			pValue = ifx_httpdGetVar(wp, T("auto_coc_timer_1x1"), T(""));
			wlan_phy.phyAutoCoC.timerIntval_1x1 = atoi(pValue);
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetAdvancedRadioSettings",
				"timerIntval_1x1: %d", wlan_phy.phyAutoCoC.timerIntval_1x1);
			pValue = ifx_httpdGetVar(wp, T("auto_coc_timer_2x2"), T(""));
			wlan_phy.phyAutoCoC.timerIntval_2x2 = atoi(pValue);
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetAdvancedRadioSettings",
				"timerIntval_2x2: %d", wlan_phy.phyAutoCoC.timerIntval_2x2);
			pValue = ifx_httpdGetVar(wp, T("auto_coc_timer_3x3"), T(""));
			wlan_phy.phyAutoCoC.timerIntval_3x3 = atoi(pValue);
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetAdvancedRadioSettings",
				"timerIntval_3x3: %d", wlan_phy.phyAutoCoC.timerIntval_3x3);

			pValue = ifx_httpdGetVar(wp, T("auto_coc_high_lim_1x1"), T(""));
			wlan_phy.phyAutoCoC.highLim_1x1 = atoi(pValue);
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetAdvancedRadioSettings",
				"highLim_1x1: %d", wlan_phy.phyAutoCoC.highLim_1x1);
			pValue = ifx_httpdGetVar(wp, T("auto_coc_high_lim_2x2"), T(""));
			wlan_phy.phyAutoCoC.highLim_2x2 = atoi(pValue);
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetAdvancedRadioSettings",
				"highLim_2x2: %d", wlan_phy.phyAutoCoC.highLim_2x2);
			pValue = ifx_httpdGetVar(wp, T("auto_coc_low_lim_2x2"), T(""));
			wlan_phy.phyAutoCoC.lowLim_2x2 = atoi(pValue);
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetAdvancedRadioSettings",
				"lowLim_2x2: %d", wlan_phy.phyAutoCoC.lowLim_2x2);
			pValue = ifx_httpdGetVar(wp, T("auto_coc_low_lim_3x3"), T(""));
			wlan_phy.phyAutoCoC.lowLim_3x3 = atoi(pValue);
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetAdvancedRadioSettings",
				"lowLim_3x3: %d", wlan_phy.phyAutoCoC.lowLim_3x3);
		}

		/*
		   802.11n parameters, but only in case an appropriate operation mode
		   is selected */
		if ((wlan_phy.standard == IFX_MAPI_WLAN_STD_802_11N) ||
		    (wlan_phy.standard == IFX_MAPI_WLAN_STD_802_11BGN) ||
		    (wlan_phy.standard == IFX_MAPI_WLAN_STD_802_11GN) ||
		    (wlan_phy.standard == IFX_MAPI_WLAN_STD_802_11AN)) {
			if (ltq_mapi_get_wlan_vendor(wlan_phy.iid.cpeId.Id, IFX_F_DEFAULT) ==
				LTQ_MAPI_WLAN_VENDOR_QCA) {
				pValue = ifx_httpdGetVar(wp, T("ba_size"), T(""));
				wlan_phy.phy11N.baWinSize = gatoi(pValue);

				pValue = ifx_httpdGetVar(wp, T("aggr_ampdu_enable"), T(""));
				wlan_phy.phy11N.aggr.ampduEna = gatoi(pValue);

				/* get aggregation parameters only if aggregation is enabled */
				if (wlan_phy.phy11N.aggr.ampduEna == IFX_MAPI_WLAN_ENABLED) {
					pValue = ifx_httpdGetVar(wp, T("ampdu_direction"), T(""));
					wlan_phy.phy11N.aggr.ampduDir = gatoi(pValue);

					pValue = ifx_httpdGetVar(wp, T("ampdu_frame_density"), T(""));
					wlan_phy.phy11N.aggr.ampduFrmsDensity = gatoi(pValue);
				}

				pValue = ifx_httpdGetVar(wp, T("aggr_amsdu_enable"), T(""));
				wlan_phy.phy11N.aggr.amsduEna = gatoi(pValue);

				/* get aggregation parameters only if aggregation is enabled */
				if (wlan_phy.phy11N.aggr.amsduEna == IFX_MAPI_WLAN_ENABLED) {
					uint32 tmpAmsduLength;

					pValue = ifx_httpdGetVar(wp, T("amsdu_direction"), T(""));
					wlan_phy.phy11N.aggr.amsduDir = gatoi(pValue);

					pValue = ifx_httpdGetVar(wp, T("amsdu_length"), T(""));
					tmpAmsduLength = gatoi(pValue);
					switch (tmpAmsduLength) {
					case 0:
						wlan_phy.phy11N.aggr.amsduLen = IFX_MAPI_WLAN_AMSDU_LEN1;
						break;
					case 1:
						wlan_phy.phy11N.aggr.amsduLen = IFX_MAPI_WLAN_AMSDU_LEN2;
						break;
					default:
						break;
					}
				}

				pValue = ifx_httpdGetVar(wp, T("diversity_enable"), T(""));
				wlan_phy.phy11N.diversity.diversityEna = gatoi(pValue);
				/* get diversity parameters only if diversity is enabled */
				if (wlan_phy.phy11N.diversity.diversityEna == IFX_MAPI_WLAN_ENABLED) {
					pValue = ifx_httpdGetVar(wp, T("diversity_direction"),
						T(""));
					wlan_phy.phy11N.diversity.diversityDir = gatoi(pValue);

					pValue = ifx_httpdGetVar(wp, T("num_antenna"), T(""));
					wlan_phy.phy11N.diversity.antenna = gatoi(pValue);
				}
			}

			/* get aggregation parameters only if aggregation is enabled */
			if (wlan_phy.phy11N.aggr.ampduEna == IFX_MAPI_WLAN_ENABLED) {
				uint32 tmpAmpduLength;

				pValue = ifx_httpdGetVar(wp, T("ampdu_length"), T(""));
				tmpAmpduLength = gatoi(pValue);
				switch (tmpAmpduLength) {
				case 0:
					wlan_phy.phy11N.aggr.ampduLen = IFX_MAPI_WLAN_AMPDU_LEN1;
					break;
				case 1:
					wlan_phy.phy11N.aggr.ampduLen = IFX_MAPI_WLAN_AMPDU_LEN2;
					break;
				case 2:
					wlan_phy.phy11N.aggr.ampduLen = IFX_MAPI_WLAN_AMPDU_LEN3;
					break;
				case 3:
					wlan_phy.phy11N.aggr.ampduLen = IFX_MAPI_WLAN_AMPDU_LEN4;
					break;
				default:
					break;
				}
			}

			pValue =
			    ifx_httpdGetVar(wp, T("stbc_direction"), T(""));
			wlan_phy.phy11N.rxStbc = gatoi(pValue);

			if (ltq_mapi_get_wlan_vendor(wlan_phy.iid.cpeId.Id, IFX_F_DEFAULT) ==
				LTQ_MAPI_WLAN_VENDOR_WAVE300) {
				pValue = ifx_httpdGetVar(wp, T("wave_ldpc_ena"), T(""));
				wlan_phy.phy11N.ldpcEna = gatoi(pValue);
			}

			/* Only relevant for 2.4GHz */
			if (wlan_phy.freqBand == IFX_MAPI_WLAN_2_4_GHz_Freq) {
				pValue = ifx_httpdGetVar(wp, T("40M_intolerance"), T(""));
				wlan_phy.phy11N.fourtyMHzIntolerant = gatoi(pValue);

				pValue = ifx_httpdGetVar(wp, T("trans_delay"), T(""));
				wlan_phy.phy11N.transDelayFactor = gatoi(pValue);
				IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetAdvancedRadioSettings",
					"transDelayFactor: %d", wlan_phy.phy11N.transDelayFactor);

				pValue = ifx_httpdGetVar(wp, T("obss_scan"), T(""));
				wlan_phy.phy11N.obssScan = gatoi(pValue);
				IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetAdvancedRadioSettings",
					"obssScan: %d", wlan_phy.phy11N.obssScan);
			}
		}

		if (ltq_mapi_get_wlan_vendor(wlan_phy.iid.cpeId.Id, IFX_F_DEFAULT) ==
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			if (wlan_phy.freqBand == IFX_MAPI_WLAN_5_GHz_Freq) {
				pValue = ifx_httpdGetVar(wp, T("wave_radar_ena"), T(""));
				wlan_phy.radarEna = gatoi(pValue);
			}

			pValue = ifx_httpdGetVar(wp, T("wave_bf_ena"), T(""));
			wlan_phy.beamForm = gatoi(pValue);

			pValue = ifx_httpdGetVar(wp, T("wave_mc2uc_ena"), T(""));
			wlan_phy.mc2ucEna = gatoi(pValue);

			pValue = ifx_httpdGetVar(wp, T("wave_ackBoost"), T(""));
			wlan_phy.boostMode = gatoi(pValue);

			/* only for Radio-1 */
			if (wlan_phy.iid.cpeId.Id == 1) {
				pValue = ifx_httpdGetVar(wp, T("wave_logserver_ena"), T(""));
				wlan_phy.wlVendorWaveCfg.logServerEna = gatoi(pValue);
			}
		}

		oper = IFX_OP_MOD;
		flags = IFX_F_MODIFY;

		wlan_phy.iid.config_owner = IFX_WEB;
		if ((ret =
		     ifx_mapi_set_wlan_phy_config(oper, &wlan_phy,
						  flags)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to set wlan phy config");
			return;
		}
	}

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetAdvancedRadioSettings", "");
	websNextPage(wp);
}

/***********wlan quick setup *********************/

void ifx_WLAN_quick_setup(httpd_t wp, char_t * path, char_t * query)
{
	IFX_MAPI_WLAN_MainCfg wlMain;
	IFX_MAPI_WLAN_SecCfg wlSec;
	IFX_MAPI_WLAN_PhyCfg wlPhy;

	IFX_MAPI_WLAN_WEP_Cfg *wlWep = NULL;

	int32 ret = IFX_SUCCESS, i;
	char8 *pValue = NULL;

	int oldRadioStatus = 0, oldBeaconType = 0;
	char oldWepKey[IFX_MAPI_WEP_KEY_MAX_LEN],
	    oldPassPhrase[IFX_MAPI_PASSPHRASE_MAX_LEN];
	char oldSsid[IFX_MAPI_WLAN_SSID_LEN];

	IFX_MAPI_DEBUG(fd, "/tmp/ifx_quick_wlan_setup", "");

	memset(oldWepKey, 0, IFX_MAPI_WEP_KEY_MAX_LEN);
	memset(oldPassPhrase, 0, IFX_MAPI_PASSPHRASE_MAX_LEN);
	memset(oldSsid, 0, IFX_MAPI_WLAN_SSID_LEN);

	memset(&wlMain, 0, sizeof(IFX_MAPI_WLAN_MainCfg));
	sprintf(wlMain.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
	sprintf(wlMain.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
	wlMain.iid.config_owner = IFX_WEB;
	wlMain.iid.pcpeId.Id = 1;
	wlMain.iid.cpeId.Id = 1;

	memset(&wlPhy, 0, sizeof(IFX_MAPI_WLAN_PhyCfg));
	sprintf(wlPhy.iid.cpeId.secName, "%s", TAG_WLAN_PHY);
	sprintf(wlPhy.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
	wlPhy.iid.cpeId.Id = 1;
	wlPhy.iid.config_owner = IFX_WEB;

	memset(&wlSec, 0, sizeof(IFX_MAPI_WLAN_SecCfg));
	sprintf(wlSec.iid.cpeId.secName, "%s", TAG_WLAN_SEC);
	sprintf(wlSec.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
	wlSec.iid.config_owner = IFX_WEB;

	wlSec.iid.pcpeId.Id = 1;
	wlSec.iid.cpeId.Id = 1;

	if ((ret =
		ifx_mapi_get_wlan_static_phy_config(&wlPhy,
					  IFX_F_GET_ANY)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to get wlan phy config");
		goto IFX_Handler;
	}

	if ((ret =
	     ifx_mapi_get_wlan_main_config(&wlMain,
					   IFX_F_GET_ANY)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to get wlan main config");
		goto IFX_Handler;
	}

	if ((ret =
	     ifx_mapi_get_wlan_security_config(&wlSec,
					       IFX_F_GET_ANY)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to get wlan Security config");
		goto IFX_Handler;
	}

	oldRadioStatus = wlPhy.radioEnable;
	pValue = ifx_httpdGetVar(wp, T("WLANEnable"), T(""));
	if (gatoi(pValue))
		wlPhy.radioEnable = 1;
	else
		wlPhy.radioEnable = 0;
	IFX_MAPI_DEBUG(fd, "/tmp/ifx_quick_wlan_setup", "WLANEnable:%s",
		       pValue);

	gstrcpy(oldSsid, wlMain.ssid);
	pValue = ifx_httpdGetVar(wp, T("vcSetting"), T(""));
	gstrcpy(wlMain.ssid, pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ifx_quick_wlan_setup", "SSID:%s", wlMain.ssid);

	oldBeaconType = wlSec.beaconType;
	pValue = ifx_httpdGetVar(wp, T("WT"), T(""));
	IFX_MAPI_DEBUG(fd, "/tmp/ifx_quick_wlan_setup", "SECTYPE:%s", pValue);
	if (!gstrcmp(pValue, "1")) {
		wlSec.beaconType = IFX_MAPI_WLAN_BEACON_BASIC;
		wlSec.wlEncr = IFX_MAPI_WLAN_ENCR_NONE;
		wlSec.wlAuth = IFX_MAPI_WLAN_AUTH_OPEN;
	} else if (!gstrcmp(pValue, "2")) {
		wlSec.beaconType = IFX_MAPI_WLAN_BEACON_BASIC;
		wlSec.wlEncr = IFX_MAPI_WLAN_ENCR_WEP;
		wlSec.wlAuth = IFX_MAPI_WLAN_AUTH_OPEN;
	} else if (!gstrcmp(pValue, "3")) {
		wlSec.beaconType = IFX_MAPI_WLAN_BEACON_WPA;
		wlSec.wlEncr = IFX_MAPI_WLAN_ENCR_TKIP;
		wlSec.wlAuth = IFX_MAPI_WLAN_AUTH_PERSONAL;
	} else if (!gstrcmp(pValue, "4")) {
		wlSec.beaconType = IFX_MAPI_WLAN_BEACON_WPA2;
		wlSec.wlEncr = IFX_MAPI_WLAN_ENCR_CCMP;
		wlSec.wlAuth = IFX_MAPI_WLAN_AUTH_PERSONAL;

	} else if (!gstrcmp(pValue, "5")) {
		wlSec.beaconType = IFX_MAPI_WLAN_BEACON_WPA_WPA2;
		wlSec.wlEncr = IFX_MAPI_WLAN_ENCR_TKIP_CCMP;
		wlSec.wlAuth = IFX_MAPI_WLAN_AUTH_PERSONAL;
	}

	if (wlSec.beaconType == IFX_MAPI_WLAN_BEACON_BASIC) {
		if (wlSec.wlEncr != IFX_MAPI_WLAN_ENCR_NONE) {
			wlWep = &wlSec.secParams.wepCfg;
			if (oldBeaconType != IFX_MAPI_WLAN_BEACON_BASIC) {
				for (i = 1; i <= 4; i++) {
					wlWep->wepKey[i - 1].iid.config_owner =
					    IFX_WEB;
					wlWep->wepKey[i - 1].iid.cpeId.Id = i;
					wlWep->wepKey[i - 1].iid.pcpeId.Id = 1;

				}

				if ((ret =
				     ifx_mapi_get_wlan_wep_config(wlWep,
								  IFX_F_GET_ANY))
				    != IFX_SUCCESS) {
					ifx_httpdError(wp, 400,
						       "Failed to Get wlan Wep config");
					goto IFX_Handler;
				}
			}
			strcpy(oldWepKey,
			       wlSec.secParams.wepCfg.wepKey[0].wepKey);
			pValue = ifx_httpdGetVar(wp, T("UN"), T(""));
			if (strlen(pValue) == 5)
				wlWep->wepEncrLevel =
				    IFX_MAPI_WEP_ENCR_LVL_64BIT;
			else
				wlWep->wepEncrLevel =
				    IFX_MAPI_WEP_ENCR_LVL_128BIT;
			wlWep->wepKeyType = IFX_MAPI_WLAN_ASCII_KEY;
			wlWep->wepKey[0].iid.config_owner = IFX_WEB;
			wlWep->wepKey[0].iid.cpeId.Id = 1;
			wlWep->wepKey[0].iid.pcpeId.Id = 1;
			wlWep->wepKeyIndex = 0;
			if (strlen(pValue) != 0) {
				gstrcpy(wlWep->wepKey[0].wepKey, pValue);
			}
			IFX_MAPI_DEBUG(fd, "/tmp/ifx_quick_wlan_setup",
				       "wepkey:%s",
				       wlSec.secParams.wepCfg.wepKey[0].wepKey);
		}
	} else {
		if (oldBeaconType == IFX_MAPI_WLAN_BEACON_BASIC) {

			wlSec.secParams.personalCfg.psk.iid.cpeId.Id = 1;
			wlSec.secParams.personalCfg.psk.iid.pcpeId.Id = 1;
			wlSec.secParams.personalCfg.psk.iid.config_owner =
			    IFX_WEB;
			if ((ret =
			     ifx_mapi_get_wlan_personal_config(&wlSec.secParams.
							       personalCfg,
							       IFX_F_GET_ANY))
			    != IFX_SUCCESS) {
				ifx_httpdError(wp, 400,
					       "Failed to Get wlan Wep config");
				goto IFX_Handler;
			}
		}

		strcpy(oldPassPhrase,
		       wlSec.secParams.personalCfg.psk.passPhrase);
		pValue = ifx_httpdGetVar(wp, T("UN1"), T(""));
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_quick_wlan_setup", "passphrase:%s",
			       pValue);
		gstrcpy(wlSec.secParams.personalCfg.psk.passPhrase, pValue);
	}

	if (oldRadioStatus != wlPhy.radioEnable) {
#if 0
#if defined (CONFIG_FEATURE_LTQ_WIRELESS_VB) || defined (CONFIG_FEATURE_LTQ_WIRELESS_STA_SUPPORT)
		if ((ret =
		     ifx_mapi_set_wlan_phy_config(IFX_OP_MOD, &wlPhy,
						  IFX_F_MODIFY | IFX_F_INT_DONT_CHECK_ACL)) !=
		    IFX_SUCCESS) {
#else
		if ((ret =
		     ifx_mapi_set_wlan_phy_config(IFX_OP_MOD, &wlPhy,
						  IFX_F_MODIFY)) !=
		    IFX_SUCCESS) {
#endif
#else
			wlPhy.iid.config_owner = IFX_WEB;
			if ((ret = ifx_mapi_set_wlan_phy_config(IFX_OP_MOD, &wlPhy,
				IFX_F_MODIFY)) != IFX_SUCCESS) {
#endif
			ifx_httpdError(wp, 400,
				       "Failed to Set wlan Phy config");
			goto IFX_Handler;
		}
		sleep(2);
	}

	if (gstrcmp(oldSsid, wlMain.ssid)) {
#if 0
#if defined (CONFIG_FEATURE_LTQ_WIRELESS_VB) || defined (CONFIG_FEATURE_LTQ_WIRELESS_STA_SUPPORT)
		if ((ret =
		     ifx_mapi_set_wlan_main_config(IFX_OP_MOD, &wlMain,
						   IFX_F_MODIFY | IFX_F_INT_DONT_CHECK_ACL)) !=
		    IFX_SUCCESS) {
#else
		if ((ret =
		     ifx_mapi_set_wlan_main_config(IFX_OP_MOD, &wlMain,
						   IFX_F_MODIFY)) !=
		    IFX_SUCCESS) {
#endif
#else
			wlMain.iid.config_owner = IFX_WEB;
		if ((ret =
			 ifx_mapi_set_wlan_main_config(IFX_OP_MOD, &wlMain,
						   IFX_F_MODIFY)) !=
			IFX_SUCCESS) {
#endif
			ifx_httpdError(wp, 400,
				       "Failed to Set wlan Main config");
			goto IFX_Handler;
		}
	}

	if ((wlSec.beaconType == IFX_MAPI_WLAN_BEACON_BASIC
	     && wlSec.wlEncr == IFX_MAPI_WLAN_ENCR_WEP
	     && strlen(wlWep->wepKey[0].wepKey) != 0
	     && strcmp(wlWep->wepKey[0].wepKey, oldWepKey))
	    || (wlSec.beaconType != IFX_MAPI_WLAN_BEACON_BASIC
		&& strlen(wlSec.secParams.personalCfg.psk.passPhrase) != 0)
	    || (wlSec.beaconType == IFX_MAPI_WLAN_BEACON_BASIC
		&& wlSec.wlEncr == IFX_MAPI_WLAN_ENCR_NONE)) {

#if 0
#if defined (CONFIG_FEATURE_LTQ_WIRELESS_VB) || defined (CONFIG_FEATURE_LTQ_WIRELESS_STA_SUPPORT)
		if ((ret =
		     ifx_mapi_set_wlan_security_config(IFX_OP_MOD, &wlSec,
						       IFX_F_MODIFY | IFX_F_INT_DONT_CHECK_ACL)) !=
		    IFX_SUCCESS) {
#else
		if ((ret =
		     ifx_mapi_set_wlan_security_config(IFX_OP_MOD, &wlSec,
						       IFX_F_MODIFY)) !=
		    IFX_SUCCESS) {
#endif
#else
			wlSec.iid.config_owner = IFX_WEB;
		if ((ret =
			 ifx_mapi_set_wlan_security_config(IFX_OP_MOD, &wlSec,
							   IFX_F_MODIFY)) !=
			IFX_SUCCESS) {
#endif
			if (wlSec.beaconType == IFX_MAPI_WLAN_BEACON_BASIC
			    && wlSec.wlEncr != IFX_MAPI_WLAN_ENCR_NONE) {
				wlWep->wepKey[0].iid.config_owner = IFX_WEB;
				if ((ret =
				     ifx_mapi_set_wlan_wep_key(IFX_OP_MOD, 0,
							       &wlWep->
							       wepKey[0],
							       IFX_F_MODIFY)) !=
				    IFX_SUCCESS) {
					ifx_httpdError(wp, 400,
						       "Failed to Set wlan Wep config");
					goto IFX_Handler;
				}
			} else {
				ifx_httpdError(wp, 400,
					       "Failed to Set wlan Security config");
				goto IFX_Handler;

			}

		}
	}

	/*
	 * reset flag to make sure updated configuration is re-loaded to global arrays
	 * the next time a WLAN web page is opened
	 */
	//g_flagConfigLoaded = 0;
	ifx_httpdRedirect(wp, T("quick_wlan.asp"));
	return;

      IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ifx_quick_wlan_setup", "ret: %d", ret);
	if (ret != IFX_SUCCESS)
		return;
	else
		ifx_httpdRedirect(wp, T("quick_wlan.asp"));
}

/**
   This function is called from web pages wlan_advsetup.asp and wlan_cfg.asp.
   Values entered on these web page are retrieved and stored in corresponding
   structures of type IFX_MAPI_WLAN_MainCfg. These structure is provided
   to IFX WLAN MAPI. Two additional parameters (operation and flags) specify the
   operations that will be executed within IFX WLAN MAPI (e.g. add, delete,
   modify).

   \param wp      web page structure

   \param path

   \param query

   \return
   None
*/
void IFX_WLAN_SetMainConfiguration(httpd_t wp, char_t * path, char_t * query)
{
	IFX_MAPI_WLAN_AP_Cfg wlApCfg;
	IFX_MAPI_WLAN_MainCfg wlMain;
	int32 ret = IFX_SUCCESS, flags = IFX_F_DEFAULT, oper = 0, apIndex = 0, i=0;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 *pValue = NULL, *pApIndex = NULL, *pApVapActionType = NULL;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	LTQ_MAPI_WLAN_NetModeClass netClass;

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetMainConfiguration", "");

	memset(&wlMain, 0, sizeof(IFX_MAPI_WLAN_MainCfg));
	sprintf(wlMain.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
	sprintf(wlMain.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

	pApVapActionType = ifx_httpdGetVar(wp, T("submit_action"), T(""));
	if (!gstrcmp(pApVapActionType, "modify_ap_vap")) {
		pApIndex = ifx_httpdGetVar(wp, T("ap_index"), T("1"));
		apIndex = gatoi(pApIndex);
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetMainConfiguration",
			       "ap_index: %d", apIndex);

		pValue = ifx_httpdGetVar(wp, "old_ap_name", T(""));
		gstrcpy(wlMain.apName, pValue);

		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetMainConfiguration",
			       "apName: %s", wlMain.apName);
		if (ifx_get_iid_from_ap_name(wlMain.apName, &wlMain.iid) !=
		    IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to get advanced info for this ssid");
			goto IFX_Handler;
		}

		if ((ret = ifx_mapi_get_wlan_main_config(&wlMain, IFX_F_DEFAULT)) !=
			IFX_SUCCESS) {
			ifx_httpdError(wp, 400, "Failed to get wlan main config");
			goto IFX_Handler;
		}

		WLAN_GetApVapSettings(wp, &wlMain, apIndex);

		oper = IFX_OP_MOD;
		flags = IFX_F_MODIFY;

	   wlMain.iid.config_owner = IFX_WEB;
		if ((ret =
		     ifx_mapi_set_wlan_main_config(oper, &wlMain,
						   flags)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to set wlan main config");
			goto IFX_Handler;
		}
	} else if (!gstrcmp(pApVapActionType, "delete_vap")) {
		memset(&wlApCfg, 0, sizeof(IFX_MAPI_WLAN_AP_Cfg));
		sprintf(wlApCfg.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
		/* wlSec parent is always LAN object */
		sprintf(wlApCfg.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
		wlApCfg.iid.config_owner = IFX_WEB;

		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetMainConfiguration",
			       "delete_vap");
		pApIndex = ifx_httpdGetVar(wp, T("ap_index"), T("1"));
		apIndex = gatoi(pApIndex);

		sprintf(buf, "%s_%d_cpeId", PREFIX_WLAN_MAIN, apIndex);
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetMainConfiguration", "buf: %s", buf);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAIN, buf, IFX_F_DEFAULT,
			&outFlag, sValue)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetMainConfiguration", "");
			ifx_httpdError(wp, 400, "Failed to get cpeId from configuration");
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetMainConfiguration", "sValue: %s", sValue);
		sprintf(wlApCfg.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
		sprintf(wlApCfg.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
		wlApCfg.iid.cpeId.Id = atoi(sValue);
		wlApCfg.iid.pcpeId.Id = 1;
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetMainConfiguration",
			"cpeId: %d, pcpeId: %d", wlApCfg.iid.cpeId.Id, wlApCfg.iid.pcpeId.Id);

		/* delete operation can only be called for VAP */
		wlApCfg.main.devType = IFX_MAPI_WLAN_DEV_TYPE_VAP;
		oper = IFX_OP_DEL;
		wlApCfg.iid.config_owner = IFX_WEB;
		if ((ret = ifx_mapi_set_wlan_ap_config(oper, &wlApCfg, flags))
			!= IFX_SUCCESS) {
			ifx_httpdError(wp, 400, "Failed to set wlan ap config");
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetMainConfiguration", "");
			goto IFX_Handler;
		}
	} else if (!gstrcmp(pApVapActionType, "add_vap")) {
		memset(&wlApCfg, 0, sizeof(IFX_MAPI_WLAN_AP_Cfg));
		sprintf(wlApCfg.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
		/* wlSec parent is always LAN object */
		sprintf(wlApCfg.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
		wlApCfg.iid.pcpeId.Id = 1;
		wlApCfg.iid.config_owner = IFX_WEB;
		sprintf(wlApCfg.phy.iid.cpeId.secName, "%s", TAG_WLAN_PHY);
		/* wlSec parent is always LAN object */
		sprintf(wlApCfg.phy.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
#if defined CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
		pValue = ifx_httpdGetVar(wp, T("radio"), T(""));
		wlApCfg.phy.iid.cpeId.Id = atoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetMainConfiguration",
			       "cpeId: %d", wlApCfg.phy.iid.cpeId.Id);
#else
		wlApCfg.phy.iid.cpeId.Id = 1;
#endif
		wlApCfg.phy.iid.config_owner = IFX_WEB;
		if ((ret =
			ifx_mapi_get_wlan_static_phy_config(&wlApCfg.phy,
						  flags)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetMainConfiguration",
				       "");
			ifx_httpdError(wp, 400,
				       "Failed to get wlan phy config");
			goto IFX_Handler;
		}

		if (ltq_mapi_get_wlan_supported_features(wlApCfg.phy.iid.cpeId.Id,
			IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_WMM) {
			for (i = 0; i < IFX_MAPI_WLAN_WMM_NUM_AC; i++) {
				sprintf(wlApCfg.apWmm[i].iid.cpeId.secName, "%s",
					TAG_WLAN_WMM_AP);
				sprintf(wlApCfg.apWmm[i].iid.pcpeId.secName, "%s",
					TAG_WLAN_MAIN);
				wlApCfg.apWmm[i].iid.config_owner = IFX_WEB;
				sprintf(wlApCfg.staWmm[i].iid.cpeId.secName, "%s",
					TAG_WLAN_WMM_STA);
				sprintf(wlApCfg.staWmm[i].iid.pcpeId.secName, "%s",
					TAG_WLAN_MAIN);
				wlApCfg.staWmm[i].iid.config_owner = IFX_WEB;
			}
		}

		if (ltq_mapi_get_wlan_supported_features(wlApCfg.phy.iid.cpeId.Id,
			IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_WPS) {
			sprintf(wlApCfg.wps.iid.cpeId.secName, "%s", TAG_WLAN_WPS);
			sprintf(wlApCfg.wps.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
			wlApCfg.wps.iid.config_owner = IFX_WEB;
			sprintf(wlApCfg.wpsRegs.iid.cpeId.secName, "%s",
				TAG_WLAN_WPS_REGISTRAR);
			sprintf(wlApCfg.wpsRegs.iid.pcpeId.secName, "%s",
				TAG_WLAN_MAIN);
			wlApCfg.wpsRegs.iid.config_owner = IFX_WEB;
		}

		if (ltq_mapi_get_wlan_supported_features(wlApCfg.phy.iid.cpeId.Id,
			IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_WDS) {
			sprintf(wlApCfg.wds.iid.cpeId.secName, "%s", TAG_WLAN_WDS);
			sprintf(wlApCfg.wds.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
			wlApCfg.wds.iid.config_owner = IFX_WEB;
		}

		pValue = ifx_httpdGetVar(wp, T("new_ap_index"), T(""));
		apIndex = gatoi(pValue);
		pValue = ifx_httpdGetVar(wp, "vapEna", T(""));
		wlApCfg.main.apEnable = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetMainConfiguration",
			       "pValue: %s, apEnable:%d", pValue,
			       wlApCfg.main.apEnable);

		pValue = ifx_httpdGetVar(wp, T("new_apName"), T(""));
		gstrcpy(wlApCfg.main.apName, pValue);

		pValue = ifx_httpdGetVar(wp, T("new_ssid"), T(""));
		gstrcpy(wlApCfg.main.ssid, pValue);

		pValue = ifx_httpdGetVar(wp, T("max_client_limit"), T(""));
		wlApCfg.main.maxStations = atoi(pValue);

		pValue = ifx_httpdGetVar(wp, T("min_reserved_clients"), T(""));
		wlApCfg.main.minResSta = atoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetMainConfiguration",
			"min_reserved_clients: %d", wlApCfg.main.minResSta);

#if defined CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
		pValue = ifx_httpdGetVar(wp, T("radio"), T(""));
		wlApCfg.main.radioCpeId = atoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetMainConfiguration",
			       "radioCpeId: %d", wlApCfg.main.radioCpeId);
#endif

		pValue = ifx_httpdGetVar(wp, T("ssidMode"), T(""));
		wlApCfg.main.ssidMode = gatoi(pValue);

		pValue = ifx_httpdGetVar(wp, T("apIsolation"), T("0"));
		wlApCfg.main.apIsolationEna = gatoi(pValue);

		/* hard-code to VAP for the moment */
		wlApCfg.main.devType = IFX_MAPI_WLAN_DEV_TYPE_VAP;

		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetMainConfiguration",
			       "apIndex:%d: SSID:%s, apEnable:%d, apName:%s, ssidMode: %d",
			       apIndex, wlApCfg.main.ssid,
			       wlApCfg.main.apEnable, wlApCfg.main.apName,
			       wlApCfg.main.ssidMode);

		if (ltq_mapi_get_wlan_supported_features(wlApCfg.phy.iid.cpeId.Id,
			IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_NETMODE_PER_VAP) {
			pValue = ifx_httpdGetVar(wp, T("net_class"), T(""));
			netClass = gatoi(pValue);
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetMainConfiguration", "netClass: %d", netClass);
			switch (netClass) {
				case LTQ_MAPI_WLAN_NET_CLASS_B_N:
					pValue = ifx_httpdGetVar(wp, T("net_mode_class_0"), T(""));
					wlApCfg.main.networkMode = gatoi(pValue);
					break;
				case LTQ_MAPI_WLAN_NET_CLASS_G_BG_GN_BGN:
					pValue = ifx_httpdGetVar(wp, T("net_mode_class_1"), T(""));
					wlApCfg.main.networkMode = gatoi(pValue);
					break;
				case LTQ_MAPI_WLAN_NET_CLASS_A_N_AN:
					pValue = ifx_httpdGetVar(wp, T("net_mode_class_2"), T(""));
					wlApCfg.main.networkMode = gatoi(pValue);
					break;
				case LTQ_MAPI_WLAN_NET_CLASS_OFF:
					wlApCfg.main.networkMode = wlApCfg.phy.standard;
				default:
					IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetMainConfiguration", "");
					break;	
			}
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetMainConfiguration",
				"networkMode: %d", wlApCfg.main.networkMode);
		}

		pValue = ifx_httpdGetVar(wp, "maxBitRate", T("11.0"));
		wlApCfg.main.maxBitRate = (float)strtod(pValue, (char **)NULL);

		/* some defaults for wlMain configuration */
		wlApCfg.main.basicDataRates[0] = 1.;
		wlApCfg.main.basicDataRates[1] = 2.;
		wlApCfg.main.basicDataRates[2] = 5.5;
		wlApCfg.main.basicDataRates[3] = 11.;
		wlApCfg.main.basicDataRates[4] = 0.;

		/* some defaults for wlMain configuration */
		if (wlApCfg.phy.standard == IFX_MAPI_WLAN_STD_802_11B) {
			wlApCfg.main.operDataRates[0] = 1.;
			wlApCfg.main.operDataRates[1] = 2.;
			wlApCfg.main.operDataRates[2] = 5.5;
			wlApCfg.main.operDataRates[3] = 6.;
			wlApCfg.main.operDataRates[4] = 9.;
			wlApCfg.main.operDataRates[5] = 11.;
			wlApCfg.main.operDataRates[6] = 0.;
			if (wlApCfg.main.maxBitRate > 11.)
				wlApCfg.main.maxBitRate = 11.;
		} else if ((wlApCfg.phy.standard == IFX_MAPI_WLAN_STD_802_11GN) ||
			(wlApCfg.phy.standard == IFX_MAPI_WLAN_STD_802_11BGN) ||
			(wlApCfg.phy.standard == IFX_MAPI_WLAN_STD_802_11AN)) {
			wlApCfg.main.operDataRates[0] = 1.;
			wlApCfg.main.operDataRates[1] = 2.;
			wlApCfg.main.operDataRates[2] = 5.5;
			wlApCfg.main.operDataRates[3] = 6.;
			wlApCfg.main.operDataRates[4] = 9.;
			wlApCfg.main.operDataRates[5] = 11.;
			wlApCfg.main.operDataRates[6] = 12.;
			wlApCfg.main.operDataRates[7] = 18.;
			wlApCfg.main.operDataRates[8] = 24.;
			wlApCfg.main.operDataRates[9] = 27.;
			wlApCfg.main.operDataRates[10] = 36.;
			wlApCfg.main.operDataRates[11] = 48.;
			wlApCfg.main.operDataRates[12] = 54.;
			wlApCfg.main.operDataRates[13] = 81.;
			wlApCfg.main.operDataRates[14] = 108.;
			wlApCfg.main.operDataRates[15] = 162.;
			wlApCfg.main.operDataRates[16] = 216.;
			wlApCfg.main.operDataRates[17] = 243.;
			wlApCfg.main.operDataRates[18] = 270.;
			wlApCfg.main.operDataRates[19] = 300.;
			wlApCfg.main.operDataRates[20] = 0.;
		} else if (wlApCfg.phy.standard == IFX_MAPI_WLAN_STD_802_11N) {
			wlApCfg.main.operDataRates[0] = 27.;
			wlApCfg.main.operDataRates[1] = 54.;
			wlApCfg.main.operDataRates[2] = 81.;
			wlApCfg.main.operDataRates[3] = 108.;
			wlApCfg.main.operDataRates[4] = 162.;
			wlApCfg.main.operDataRates[5] = 216.;
			wlApCfg.main.operDataRates[6] = 243.;
			wlApCfg.main.operDataRates[7] = 270.;
			wlApCfg.main.operDataRates[8] = 300.;
			wlApCfg.main.operDataRates[9] = 0.;
		} else if ((wlApCfg.phy.standard == IFX_MAPI_WLAN_STD_802_11G) ||
			(wlApCfg.phy.standard == IFX_MAPI_WLAN_STD_802_11BG)) {
			/* IFX_MAPI_WLAN_STD_802_11G || IFX_MAPI_WLAN_STD_802_11BG */
			wlApCfg.main.operDataRates[0] = 1.;
			wlApCfg.main.operDataRates[1] = 2.;
			wlApCfg.main.operDataRates[2] = 5.5;
			wlApCfg.main.operDataRates[3] = 6.;
			wlApCfg.main.operDataRates[4] = 9.;
			wlApCfg.main.operDataRates[5] = 11.;
			wlApCfg.main.operDataRates[6] = 12.;
			wlApCfg.main.operDataRates[7] = 18.;
			wlApCfg.main.operDataRates[8] = 24.;
			wlApCfg.main.operDataRates[9] = 36.;
			wlApCfg.main.operDataRates[10] = 48.;
			wlApCfg.main.operDataRates[11] = 54.;
			wlApCfg.main.operDataRates[12] = 0.;
			if (wlApCfg.main.maxBitRate > 54.)
				wlApCfg.main.maxBitRate = 54.;
		} else {
			/* IFX_MAPI_WLAN_STD_802_11AC || IFX_MAPI_WLAN_STD_802_11ACN || IFX_MAPI_WLAN_STD_802_11ACNA */
			wlApCfg.main.operDataRates[0] = 1.;
			wlApCfg.main.operDataRates[1] = 2.;
			wlApCfg.main.operDataRates[2] = 5.5;
			wlApCfg.main.operDataRates[3] = 6.;
			wlApCfg.main.operDataRates[4] = 9.;
			wlApCfg.main.operDataRates[5] = 11.;
			wlApCfg.main.operDataRates[6] = 12.;
			wlApCfg.main.operDataRates[7] = 18.;
			wlApCfg.main.operDataRates[8] = 24.;
			wlApCfg.main.operDataRates[9] = 27.;
			wlApCfg.main.operDataRates[10] = 36.;
			wlApCfg.main.operDataRates[11] = 48.;
			wlApCfg.main.operDataRates[12] = 54.;
			wlApCfg.main.operDataRates[13] = 81.;
			wlApCfg.main.operDataRates[14] = 108.;
			wlApCfg.main.operDataRates[15] = 162.;
			wlApCfg.main.operDataRates[16] = 216.;
			wlApCfg.main.operDataRates[17] = 243.;
			wlApCfg.main.operDataRates[18] = 270.;
			wlApCfg.main.operDataRates[19] = 300.;
			wlApCfg.main.operDataRates[20] = 0.;
		}

		/*
		   Now get the security configuration of the new VAP: on each creation
		   of a new VAP, new objects for wep, personal configuration and 802.1x
		   have to be created, independent from the actual security
		   configuration of the new VAP; Note, that the default values for the
		   objects, which are not currently selected in the security
		   configuration can not be set up here, since parameter secParams of
		   IFX_MAPI_WLAN_SecCfg is of type union; this must be done within
		   ifx_mapi_set_wlan_security_config; Example: security configuration
		   is beacon type basic, encrytion type wep => wep object is setup
		   here, objects for personal configuration and 802.1x configuration
		   are set up and filled with default values in
		   ifx_mapi_set_wlan_security_config */

		wlApCfg.sec.beaconType = IFX_MAPI_WLAN_BEACON_BASIC;
		wlApCfg.sec.wlAuth = IFX_MAPI_WLAN_AUTH_OPEN;
		wlApCfg.sec.wlEncr = IFX_MAPI_WLAN_ENCR_NONE;

		/*
			if beacon type is IFX_MAPI_WLAN_BEACON_BASIC, either WEP
			encryption or no encryption is possible; */
		wlApCfg.sec.basicAuth = wlApCfg.sec.wlAuth;
		wlApCfg.sec.basicEncr = wlApCfg.sec.wlEncr;

		/*
			store some mandatory values for wep key object: - pcpeId of wep
			key object is cpeId of wlan securtiy object - section name of
			wep key object is TAG_WLAN_WEP */
		sprintf(wlApCfg.sec.secParams.wepCfg.
			wepKey[IFX_MAPI_WEP_KEY_INDX_1].iid.cpeId.
			secName, "%s", TAG_WLAN_WEP);
		sprintf(wlApCfg.sec.secParams.wepCfg.
			wepKey[IFX_MAPI_WEP_KEY_INDX_2].iid.cpeId.
			secName, "%s", TAG_WLAN_WEP);
		sprintf(wlApCfg.sec.secParams.wepCfg.
			wepKey[IFX_MAPI_WEP_KEY_INDX_3].iid.cpeId.
			secName, "%s", TAG_WLAN_WEP);
		sprintf(wlApCfg.sec.secParams.wepCfg.
			wepKey[IFX_MAPI_WEP_KEY_INDX_4].iid.cpeId.
			secName, "%s", TAG_WLAN_WEP);
		sprintf(wlApCfg.sec.secParams.wepCfg.
			wepKey[IFX_MAPI_WEP_KEY_INDX_1].iid.pcpeId.
			secName, "%s", TAG_WLAN_SEC);
		sprintf(wlApCfg.sec.secParams.wepCfg.
			wepKey[IFX_MAPI_WEP_KEY_INDX_2].iid.pcpeId.
			secName, "%s", TAG_WLAN_SEC);
		sprintf(wlApCfg.sec.secParams.wepCfg.
			wepKey[IFX_MAPI_WEP_KEY_INDX_3].iid.pcpeId.
			secName, "%s", TAG_WLAN_SEC);
		sprintf(wlApCfg.sec.secParams.wepCfg.
			wepKey[IFX_MAPI_WEP_KEY_INDX_4].iid.pcpeId.
			secName, "%s", TAG_WLAN_SEC);

		/* default value for macAddrCntrlType is disabled */
		wlApCfg.sec.macAddrCntrlEna =
			IFX_MAPI_MACADDR_CONTROL_DISABLE;

		if (ltq_mapi_get_wlan_supported_features(wlApCfg.phy.iid.cpeId.Id,
			IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_WMM) {
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetMainConfiguration",
				"vendor: %s", g_wlCaps[wlApCfg.main.radioCpeId - 1].vendor);
			if (!strcmp(g_wlCaps[wlApCfg.main.radioCpeId - 1].vendor, "wave300")) {
				wlApCfg.main.WMMena = TRUE;
			}

			/* default values for new wlan wmm object */
			/* AC: BE (best effort) */
			/* outbound traffic */
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_BE].ac = IFX_MAPI_WLAN_WMM_BE;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_BE].AIFSN = 3;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_BE].ECWmin = 4;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_BE].ECWmax = 6;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_BE].TXOP = 0;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_BE].ackPolicyEna = 0;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_BE].admCntrl = 0;
			/* inbound traffic */
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_BE].ac = IFX_MAPI_WLAN_WMM_BE;
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_BE].AIFSN = 3;
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_BE].ECWmin = 4;
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_BE].ECWmax = 10;
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_BE].TXOP = 0;
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_BE].ackPolicyEna = 0;

			/* AC: BK (background) */
			/* outbound traffic */
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_BK].ac = IFX_MAPI_WLAN_WMM_BK;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_BK].AIFSN = 7;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_BK].ECWmin = 4;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_BK].ECWmax = 10;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_BK].TXOP = 0;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_BK].ackPolicyEna = 0;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_BK].admCntrl = 0;
			/* inbound traffic */
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_BK].ac = IFX_MAPI_WLAN_WMM_BK;
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_BK].AIFSN = 7;
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_BK].ECWmin = 4;
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_BK].ECWmax = 10;
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_BK].TXOP = 0;
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_BK].ackPolicyEna = 0;

			/* AC: VI (voice infrastructure) */
			/* outbound traffic */
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_VI].ac = IFX_MAPI_WLAN_WMM_VI;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_VI].AIFSN = 1;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_VI].ECWmin = 3;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_VI].ECWmax = 4;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_VI].TXOP = 94;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_VI].ackPolicyEna = 0;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_VI].admCntrl = 0;
			/* inbound traffic */
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_VI].ac = IFX_MAPI_WLAN_WMM_VI;
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_VI].AIFSN = 2;
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_VI].ECWmin = 3;
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_VI].ECWmax = 4;
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_VI].TXOP = 94;
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_VI].ackPolicyEna = 0;

			/* AC: VO (video) */
			/* outbound traffic */
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_VO].ac = IFX_MAPI_WLAN_WMM_VO;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_VO].AIFSN = 1;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_VO].ECWmin = 2;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_VO].ECWmax = 3;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_VO].TXOP = 47;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_VO].ackPolicyEna = 0;
			wlApCfg.apWmm[IFX_MAPI_WLAN_WMM_VO].admCntrl = 0;
			/* inbound traffic */
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_VO].ac = IFX_MAPI_WLAN_WMM_VO;
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_VO].AIFSN = 2;
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_VO].ECWmin = 2;
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_VO].ECWmax = 3;
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_VO].TXOP = 47;
			wlApCfg.staWmm[IFX_MAPI_WLAN_WMM_VO].ackPolicyEna = 0;
		}

		if (ltq_mapi_get_wlan_supported_features(wlApCfg.phy.iid.cpeId.Id,
			IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_WPS) {
			/* default values for new wlan wps object */
			wlApCfg.wps.enable = FALSE;
			wlApCfg.wps.enrolleeEna = FALSE;
			wlApCfg.wps.proxyEna = FALSE;
			wlApCfg.wps.intRegEna = FALSE;
			strcpy(wlApCfg.wps.apWpsName, "LTQ-WLAN-ROUTER");
			wlApCfg.wps.apWpsPin = 12345678;
			wlApCfg.wps.enaCfgMethods[0] = IFX_MAPI_WPS_LABEL;
			wlApCfg.wps.enaCfgMethods[1] = IFX_MAPI_WPS_DISPLAY;
			wlApCfg.wps.enaCfgMethods[2] = IFX_MAPI_WPS_PUSH_BUTTON;
			wlApCfg.wps.enaCfgMethods[3] = IFX_MAPI_WPS_KEY_PAD;
			wlApCfg.wps.enaCfgMethods[4] = 0xFF;
			wlApCfg.wps.setupLock = FALSE;

			/* default values for new wlan wps registrar object */
			wlApCfg.wpsRegs.enable = FALSE;
			strcpy(wlApCfg.wpsRegs.regsWpsName, "LTQ_WPS_Registrar");
		}

		if (ltq_mapi_get_wlan_supported_features(wlApCfg.phy.iid.cpeId.Id,
			IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_WDS) {
			/* default values for new wlan wds object */
			wlApCfg.wds.enable = FALSE;
			wlApCfg.wds.secMode = LTQ_MAPI_WDS_OPEN;
			wlApCfg.wds.peerAPKeyIdx = 0;
			wlApCfg.wds.nPeerAPs = 0;
		}

		oper = IFX_OP_ADD;
		wlApCfg.iid.config_owner = IFX_WEB;
		if ((ret = ifx_mapi_set_wlan_ap_config(oper, &wlApCfg, flags)) !=
			IFX_SUCCESS) {
			ifx_httpdError(wp, 400, "Failed to set wlan ap config");
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetMainConfiguration", "");
			goto IFX_Handler;
		}
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetMainConfiguration", "ret: %d", ret);
	if (ret != IFX_SUCCESS)
		return;
	else
		websNextPage(wp);
}

/**
   This function is called from web page wlan_sec.asp. Values entered on the web
   page are retrieved and stored in corresponding structure of type
   IFX_MAPI_WLAN_SecCfg. These structure is provided to IFX WLAN MAPI. Two
   additional parameters (operation and flags) specify the
   operations that will be executed within IFX WLAN MAPI (e.g. add, delete,
   modify). Note, that this function is only called for modify operations.

   \param wp      web page structure

   \param path

   \param query

   \return
   None.
*/
void
IFX_WLAN_SetSecurityConfiguration(httpd_t wp, char_t * path, char_t * query)
{
	IFX_MAPI_WLAN_SecCfg wlSec;
	int32 ret = IFX_SUCCESS, flags = 0, oper = 0, i = 0, apIndex = -1;
	uint32 beacontype = 0, authtype = 0, encrtype = 0, dispmode = 0;
	char8 *pValue, sCommand[MAX_DATA_LEN], ipaddr[MAX_IP_ADDR_LEN];

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetSecurityConfiguration", "");

	memset(&wlSec, 0, sizeof(IFX_MAPI_WLAN_SecCfg));

	sprintf(wlSec.iid.cpeId.secName, "%s", TAG_WLAN_SEC);
	sprintf(wlSec.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

	pValue = ifx_httpdGetVar(wp, "ap_index", T(""));
	apIndex = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetSecurityConfiguration",
		"apIndex: %d", apIndex);

	if ((apIndex < 0) || (apIndex >= LTQ_MAX_NUM_VAP)) {
		ifx_httpdError(wp, 400, "AP index out of range.");
		return;
	}
	/* restore from global variable to save time */
	memcpy(&wlSec, &g_wlSec[apIndex], sizeof(IFX_MAPI_WLAN_SecCfg));

	/*
	   index of security object is used to determine the SSID for this instance
	 */
	gsprintf(sCommand, T("ssid"));
	pValue = ifx_httpdGetVar(wp, sCommand, T(""));
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetSecurityConfiguration", "ssid: %s",
		       pValue);

	gsprintf(sCommand, T("beaconType"));
	/* if variable is not available, default is IFX_MAPI_WLAN_BEACON_BASIC */
	pValue = ifx_httpdGetVar(wp, sCommand, T("0"));
	beacontype = gatoi(pValue);
	wlSec.beaconType = beacontype;

	gsprintf(sCommand, T("authType"));
	/* if variable is not available, default is IFX_MAPI_WLAN_AUTH_SHARED */
	pValue = ifx_httpdGetVar(wp, sCommand, T("1"));
	authtype = gatoi(pValue);
	wlSec.wlAuth = authtype;

	gsprintf(sCommand, T("encrType"));
	/* if variable is not available, default is IFX_MAPI_WLAN_ENCR_WEP */
	pValue = ifx_httpdGetVar(wp, sCommand, T("1"));
	encrtype = gatoi(pValue);
	wlSec.wlEncr = encrtype;

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetSecurityConfiguration",
		       "beacon: %d, auth: %d, encryption: %d", wlSec.beaconType,
		       wlSec.wlAuth, wlSec.wlEncr);

	/*
	   depending on beacon type: authentication and encryption type are stored
	   in wlSec.basicXXX, wlSec.wpaXXX or wlSec.wpa2XXX; this is redundant, but
	   required for TR69; */
	switch (beacontype) {
#ifdef CONFIG_LTQ_AEI_CUST
	case IFX_MAPI_WLAN_BEACON_NONE:
		wlSec.basicAuth = IFX_MAPI_WLAN_AUTH_OPEN;
		wlSec.basicEncr = IFX_MAPI_WLAN_ENCR_NONE;
#endif
	case IFX_MAPI_WLAN_BEACON_BASIC:
		switch (authtype) {
		case IFX_MAPI_WLAN_AUTH_OPEN:
		case IFX_MAPI_WLAN_AUTH_SHARED:
			wlSec.basicAuth = authtype;
			break;
		default:
			ifx_httpdError(wp, 400,
				       "Invalid authentication type for selected Beacon Type (basic)");
			goto IFX_Handler;
		}
		switch (encrtype) {
		case IFX_MAPI_WLAN_ENCR_NONE:
		case IFX_MAPI_WLAN_ENCR_WEP:
			wlSec.basicEncr = encrtype;
			break;
		default:
			ifx_httpdError(wp, 400,
				       "Invalid encryption type for selected Beacon Type (basic)");
			goto IFX_Handler;
		}
		break;
	case IFX_MAPI_WLAN_BEACON_WPA:
		switch (authtype) {
		case IFX_MAPI_WLAN_AUTH_RADIUS:
		case IFX_MAPI_WLAN_AUTH_PERSONAL:
			wlSec.wpaAuth = authtype;
			break;
		default:
			ifx_httpdError(wp, 400,
				       "Invalid authentication type for selected beacon type (wpa/wpa2)");
			goto IFX_Handler;
		}
		switch (encrtype) {
		case IFX_MAPI_WLAN_ENCR_TKIP:
		case IFX_MAPI_WLAN_ENCR_CCMP:
		case IFX_MAPI_WLAN_ENCR_TKIP_CCMP:
			wlSec.wpaEncr = encrtype;
			break;
		default:
			ifx_httpdError(wp, 400,
				       "Invalid encryption type for selected Beacon Type (wpa/wpa2)");
			goto IFX_Handler;
		}
		break;
	case IFX_MAPI_WLAN_BEACON_WPA2:
		switch (authtype) {
		case IFX_MAPI_WLAN_AUTH_RADIUS:
		case IFX_MAPI_WLAN_AUTH_PERSONAL:
			wlSec.wpa2Auth = authtype;
			break;
		default:
			ifx_httpdError(wp, 400,
				       "Invalid authentication type for selected beacon type (wpa/wpa2)");
			goto IFX_Handler;
		}
		switch (encrtype) {
		case IFX_MAPI_WLAN_ENCR_TKIP:
		case IFX_MAPI_WLAN_ENCR_CCMP:
		case IFX_MAPI_WLAN_ENCR_TKIP_CCMP:
			wlSec.wpa2Encr = encrtype;
			break;
		default:
			ifx_httpdError(wp, 400,
				       "Invalid encryption type for selected Beacon Type (wpa/wpa2)");
			goto IFX_Handler;
		}
		break;
	case IFX_MAPI_WLAN_BEACON_WPA_WPA2_NON_COMPLIANT:
	case IFX_MAPI_WLAN_BEACON_WPA_WPA2:
		switch (authtype) {
		case IFX_MAPI_WLAN_AUTH_RADIUS:
		case IFX_MAPI_WLAN_AUTH_PERSONAL:
			wlSec.wpaAuth = authtype;
			wlSec.wpa2Auth = authtype;
			break;
		default:
			ifx_httpdError(wp, 400, "Invalid authentication type for "
				"selected beacon type (wpa/wpa2)");
			return;
		}
		switch (encrtype) {
		case IFX_MAPI_WLAN_ENCR_TKIP_CCMP:
		case IFX_MAPI_WLAN_ENCR_TKIP:
		case IFX_MAPI_WLAN_ENCR_CCMP:
			wlSec.wpaEncr = encrtype;
			wlSec.wpa2Encr = encrtype;
		break;
		default:
			ifx_httpdError(wp, 400, "Invalid encryption type for selected "
				"Beacon Type (wpa/wpa2)");
			return;
		}
		break;
	default:
		ifx_httpdError(wp, 400, "Invalid beacon type");
		return;
	}

	/*
	   we already retrieved the "old" configuration above by calling function
	   ifx_mapi_get_wlan_security_config; however the type of configuration
	   might have changed, therefore we need to get the configuration for WEP,
	   personal or 802.1X again from rc.conf manually */
	if ((wlSec.beaconType == IFX_MAPI_WLAN_BEACON_BASIC)
#if defined (CONFIG_LTQ_AEI_CUST)
		|| (wlSec.beaconType == IFX_MAPI_WLAN_BEACON_NONE)
#endif
		) {
		if (wlSec.wlEncr == IFX_MAPI_WLAN_ENCR_WEP) {
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetSecurityConfiguration",
				"IFX_MAPI_WLAN_BEACON_BASIC/IFX_MAPI_WLAN_ENCR_WEP");
			for (i = 0; i < IFX_MAPI_NUM_WEP_KEYS; i++)
				wlSec.secParams.wepCfg.wepKey[i].iid.pcpeId.Id =
				    wlSec.iid.cpeId.Id;

			/* get current wep configuration from rc.conf */
			if (ifx_mapi_get_wlan_wep_config
			    (&wlSec.secParams.wepCfg,
			     IFX_F_DEFAULT) != IFX_SUCCESS) {
				ifx_httpdError(wp, 400,
					       "Failed to get info of wep keys");
				return;
			}
		}
	}
	/* WPA, WPA2 or mixed WPA_WPA2 */
	else {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetSecurityConfiguration", 
			"WPA, WPA2 or WPA_WPA2_MIXED");
		if (wlSec.wlAuth == IFX_MAPI_WLAN_AUTH_PERSONAL) {
			wlSec.secParams.personalCfg.psk.iid.pcpeId.Id =
			    wlSec.iid.cpeId.Id;
			if (ifx_mapi_get_wlan_personal_config
			    (&wlSec.secParams.personalCfg,
			     IFX_F_DEFAULT) != IFX_SUCCESS) {
				ifx_httpdError(wp, 400,
					       "Failed to get personal configuration");
				return;
			}
		}
		/* IFX_MAPI_WLAN_AUTH_RADIUS */
		else if (wlSec.wlAuth == IFX_MAPI_WLAN_AUTH_RADIUS) {
			wlSec.secParams.wlRadius.iid.pcpeId.Id =
			    wlSec.iid.cpeId.Id;
			if (ifx_mapi_get_wlan_802_1x_config
			    (&wlSec.secParams.wlRadius,
			     IFX_F_DEFAULT) != IFX_SUCCESS) {
				ifx_httpdError(wp, 400,
					       "Failed to get 802.1X configuration");
				return;
			}
		} else {
			ifx_httpdError(wp, 400,
				       "Beacon type and authentication do not match");
			return;
		}
	}

	gsprintf(sCommand, T("wepKeyDisplayType"));
	pValue = ifx_httpdGetVar(wp, sCommand, T(""));
	if (gstrcmp(pValue, "password")) {
		dispmode = 1;
	}

	/*
	   now we retrieve the new values from the web page and store them in wlSec
	 */
#if defined (CONFIG_LTQ_AEI_CUST)
	if (((beacontype == IFX_MAPI_WLAN_BEACON_BASIC) ||
		(beacontype == IFX_MAPI_WLAN_BEACON_NONE))&&
	    (authtype == IFX_MAPI_WLAN_AUTH_OPEN ||
	    authtype == IFX_MAPI_WLAN_AUTH_SHARED) &&
	    (encrtype == IFX_MAPI_WLAN_ENCR_NONE)) {
#else
	if (((beacontype == IFX_MAPI_WLAN_BEACON_BASIC)) &&
	    (authtype == IFX_MAPI_WLAN_AUTH_OPEN ||
	    authtype == IFX_MAPI_WLAN_AUTH_SHARED) &&
	    (encrtype == IFX_MAPI_WLAN_ENCR_NONE)) {
#endif
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetSecurityConfiguration",
			       "IFX_MAPI_WLAN_BEACON_BASIC/IFX_MAPI_WLAN_ENCR_NONE");
		/*
		   no encryption selected, therefore no parameters have to be stored in
		   wlSec.secParams (neither WEP, Personal nor 802.1X) */
	} else if ((beacontype == IFX_MAPI_WLAN_BEACON_BASIC) &&
		   (authtype == IFX_MAPI_WLAN_AUTH_OPEN
		    || authtype == IFX_MAPI_WLAN_AUTH_SHARED)
		   && (encrtype == IFX_MAPI_WLAN_ENCR_WEP)
	    ) {
		/* WLAN WEP selected */
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetSecurityConfiguration",
			       "IFX_MAPI_WLAN_BEACON_BASIC/IFX_MAPI_WLAN_AUTH_OPEN/IFX_MAPI_WLAN_ENCR_WEP");
		gsprintf(sCommand, T("keyIndex"));
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		wlSec.secParams.wepCfg.wepKeyIndex = gatoi(pValue);

		gsprintf(sCommand, T("encryptLevel"));
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		wlSec.secParams.wepCfg.wepEncrLevel = gatoi(pValue);

		gsprintf(sCommand, T("wepKeyType"));
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		wlSec.secParams.wepCfg.wepKeyType = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetSecurityConfiguration",
			       "wepKeyIndex: %d, wepEncrLevel: %d, wepKeyType: %d",
			       wlSec.secParams.wepCfg.wepKeyIndex,
			       wlSec.secParams.wepCfg.wepEncrLevel,
			       wlSec.secParams.wepCfg.wepKeyType);

		for (i = 0; i < IFX_MAX_WLAN_KEY_INDEX; i++) {
			if (dispmode) {
				gsprintf(sCommand, T("wepKey%dText"), i + 1);
			} else {
				gsprintf(sCommand, T("wepKey%d"), i + 1);
			}
			pValue = ifx_httpdGetVar(wp, sCommand, T(""));
			IFX_MAPI_DEBUG(fd,
				       "/tmp/IFX_WLAN_SetSecurityConfiguration",
				       "sCommand: %s, pValue: %s", sCommand,
				       pValue);
			sprintf(wlSec.secParams.wepCfg.wepKey[i].wepKey, "%s",
				pValue);
			IFX_MAPI_DEBUG(fd,
				       "/tmp/IFX_WLAN_SetSecurityConfiguration",
				       "sprintf: wlSec.secParams.wepCfg.wepKey[%d].wepKey: %s",
				       i,
				       wlSec.secParams.wepCfg.wepKey[i].wepKey);
		}

	} else if (((beacontype == IFX_MAPI_WLAN_BEACON_WPA)
		    || (beacontype == IFX_MAPI_WLAN_BEACON_WPA2)
		    || (beacontype == IFX_MAPI_WLAN_BEACON_WPA_WPA2_NON_COMPLIANT)
		    || (beacontype == IFX_MAPI_WLAN_BEACON_WPA_WPA2))
		   && ((encrtype == IFX_MAPI_WLAN_ENCR_TKIP)
		       || (encrtype == IFX_MAPI_WLAN_ENCR_CCMP)
		       || (encrtype == IFX_MAPI_WLAN_ENCR_TKIP_CCMP))
	    ) {
		if (authtype == IFX_MAPI_WLAN_AUTH_PERSONAL) {
			/* WLAN WPA or WPA2 with personal security */
			IFX_MAPI_DEBUG(fd,
				       "/tmp/IFX_WLAN_SetSecurityConfiguration",
				       "IFX_MAPI_WLAN_AUTH_PERSONAL");
			gsprintf(sCommand, T("groupKeyIntvl"));
			pValue = ifx_httpdGetVar(wp, sCommand, T(""));
			wlSec.secParams.personalCfg.groupKeyIntvl =
			    gatoi(pValue);
			wlSec.secParams.personalCfg.groupKeyEna = 1;

			pValue = ifx_httpdGetVar(wp, T("pskType"), T(""));
			wlSec.secParams.personalCfg.pskType = gatoi(pValue);

			if (wlSec.secParams.personalCfg.pskType ==
			    IFX_MAPI_WLAN_HEX_KEY) {
				if (dispmode) {
					gsprintf(sCommand,
						 T("preSharedKeyText"));
				} else {
					gsprintf(sCommand, T("preSharedKey"));
				}
				pValue = ifx_httpdGetVar(wp, sCommand, T(""));
				gstrcpy(wlSec.secParams.personalCfg.psk.
					preSharedKey, pValue);
				gstrcpy(wlSec.secParams.personalCfg.psk.
					passPhrase, "");
			} else {
				if (dispmode) {
					gsprintf(sCommand, T("passPhraseText"));
				} else {
					gsprintf(sCommand, T("passPhrase"));
				}
				pValue = ifx_httpdGetVar(wp, sCommand, T(""));
				gstrcpy(wlSec.secParams.personalCfg.psk.
					preSharedKey, "");
				gstrcpy(wlSec.secParams.personalCfg.psk.
					passPhrase, pValue);
			}
			IFX_MAPI_DEBUG(fd,
				       "/tmp/IFX_WLAN_SetSecurityConfiguration",
				       "passPhrase: %s, psk: %s",
				       wlSec.secParams.personalCfg.psk.
				       passPhrase,
				       wlSec.secParams.personalCfg.psk.
				       preSharedKey);
		} else if (authtype == IFX_MAPI_WLAN_AUTH_RADIUS) {
			/* WLAN WPA or WPA2 with enterprise security */
			IFX_MAPI_DEBUG(fd,
				       "/tmp/IFX_WLAN_SetSecurityConfiguration",
				       "IFX_MAPI_WLAN_AUTH_RADIUS");

			gsprintf(sCommand, T("wpa2PreAuthEnable"));
			pValue = ifx_httpdGetVar(wp, sCommand, T(""));
			wlSec.secParams.wlRadius.wpa2PreAuthEna = gatoi(pValue);
			wlSec.secParams.wlRadius.wpa2ReAuthIntvl = 3600;

			gsprintf(sCommand, T("groupKeyIntvl"));
			pValue = ifx_httpdGetVar(wp, sCommand, T(""));
			wlSec.secParams.wlRadius.groupKeyIntvl = gatoi(pValue);
			wlSec.secParams.wlRadius.groupKeyEna = 1;

			gsprintf(sCommand, T("radiusPort"));
			pValue = ifx_httpdGetVar(wp, sCommand, T(""));
			wlSec.secParams.wlRadius.radiusPort = gatoi(pValue);

			if (dispmode) {
				gsprintf(sCommand, T("radiusSecretText"));
			} else {
				gsprintf(sCommand, T("radiusSecret"));
			}
			pValue = ifx_httpdGetVar(wp, sCommand, T(""));
			gstrcpy(wlSec.secParams.wlRadius.radiusServerSecret,
				pValue);
			IFX_MAPI_DEBUG(fd,
				       "/tmp/IFX_WLAN_SetSecurityConfiguration",
				       "radiusSecret: %s",
				       wlSec.secParams.wlRadius.
				       radiusServerSecret);

			ipaddr[0] = '\0';
			gsprintf(sCommand, T("radiusIp1"));
			pValue = ifx_httpdGetVar(wp, sCommand, T(""));
			strcat(ipaddr, pValue);
			strcat(ipaddr, ".");
			IFX_MAPI_DEBUG(fd,
				       "/tmp/IFX_WLAN_SetSecurityConfiguration",
				       "ipaddr: %s", ipaddr);
			gsprintf(sCommand, T("radiusIp2"));
			pValue = ifx_httpdGetVar(wp, sCommand, T(""));
			strcat(ipaddr, pValue);
			strcat(ipaddr, ".");
			IFX_MAPI_DEBUG(fd,
				       "/tmp/IFX_WLAN_SetSecurityConfiguration",
				       "ipaddr: %s", ipaddr);
			gsprintf(sCommand, T("radiusIp3"));
			pValue = ifx_httpdGetVar(wp, sCommand, T(""));
			strcat(ipaddr, pValue);
			strcat(ipaddr, ".");
			IFX_MAPI_DEBUG(fd,
				       "/tmp/IFX_WLAN_SetSecurityConfiguration",
				       "ipaddr: %s", ipaddr);
			gsprintf(sCommand, T("radiusIp4"));
			pValue = ifx_httpdGetVar(wp, sCommand, T(""));
			strcat(ipaddr, pValue);
			IFX_MAPI_DEBUG(fd,
				       "/tmp/IFX_WLAN_SetSecurityConfiguration",
				       "ipaddr: %s", ipaddr);

			inet_aton(ipaddr,
				  &wlSec.secParams.wlRadius.radiusServerIP);

			gsprintf(sCommand, T("reAuthIntvl"));
			pValue = ifx_httpdGetVar(wp, sCommand, T(""));
			wlSec.secParams.wlRadius.wpa2ReAuthIntvl =
			    gatoi(pValue);
		} else {
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetSecurityConfiguration", "");
			ifx_httpdError(wp, 400,
				       "Mismatch of beacon type, authentication type and encryption type");
			return;
		}
	} else {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetSecurityConfiguration",
			       "");
		ifx_httpdError(wp, 400,
			       "Mismatch of beacon type, authentication type and encryption type");
		return;
	}

	/* set modify flag and call WLAN MAPI function */
	oper = IFX_OP_MOD;
	flags = IFX_F_MODIFY;
	wlSec.iid.config_owner = IFX_WEB;
	if ((ret = ifx_mapi_set_wlan_security_config(oper, &wlSec, flags)) !=
		IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to set wlan security config");
		return;
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetSecurityConfiguration",
		"ret: %d", ret);
	if (ltq_wlan_redirect(wp, "wlan_sec.asp", apIndex) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetSecurityConfiguration", "");
		websNextPage(wp);
	}
}

/**
   This function is called from web page wlan_wmm.asp. Values entered on the web
   page are retrieved and stored in corresponding structures of type
   IFX_MAPI_WLAN_STA_WMM_Cfg and IFX_MAPI_WLAN_AP_WMM_Cfg. These structure are
   provided to IFX WLAN MAPI. Two additional parameters (operation and flags)
   specify the operations that will be executed within IFX WLAN MAPI (e.g. add,
   delete, modify). Note, that this function is only called for modify
   operations.

   \param wp      web page structure

   \param path

   \param query

   \return
   None.
*/
void IFX_WLAN_SetWmmConfiguration(httpd_t wp, char_t * path, char_t * query)
{
	IFX_MAPI_WLAN_MainCfg wlMain;
	uint32	numEntries;
	IFX_MAPI_WLAN_AP_WMM_Cfg *wlApWmmAll = NULL;
	IFX_MAPI_WLAN_STA_WMM_Cfg *wlStaWmmAll = NULL;
	IFX_MAPI_WLAN_AP_WMM_Cfg wlApWmm;
	IFX_MAPI_WLAN_STA_WMM_Cfg wlStaWmm;
	int32 ret = IFX_SUCCESS, i, flags = IFX_F_DEFAULT, apIndex = 0;
	char8 *pValue = NULL, sCommand[MAX_NAME_LEN];

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWmmConfiguration", "");

	/* first init configuration */
	memset(&wlMain, 0, sizeof(IFX_MAPI_WLAN_MainCfg));
	memset(&wlApWmm, 0, sizeof(IFX_MAPI_WLAN_AP_WMM_Cfg));
	memset(&wlStaWmm, 0, sizeof(IFX_MAPI_WLAN_STA_WMM_Cfg));

	pValue = ifx_httpdGetVar(wp, "apIndex", T(""));
	apIndex = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWmmConfiguration",
		"apIndex: %d", apIndex);

	if ((apIndex < 0) || (apIndex >= LTQ_MAX_NUM_VAP)) {
		ifx_httpdError(wp, 400, "AP index out of range.");
		return;
	}

	pValue = ifx_httpdGetVar(wp, "apName", T(""));
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWmmConfiguration",
		"apName: %s", pValue);

	/* IFX ID is extracted from wlan_main object. */
	sprintf(wlMain.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
	sprintf(wlMain.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
	if (ifx_get_iid_from_ap_name(pValue, &wlMain.iid) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400,
			       "Failed to get IFX ID info for this ssid");
		goto IFX_Handler;
	}

	/* get the wlan main configuration from MAPI */
	if ((ret = ifx_mapi_get_wlan_main_config(&wlMain, IFX_F_DEFAULT)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWmmConfiguration", "");
		ifx_httpdError(wp, 400, "Failed to get wlan main config");
		goto IFX_Handler;
	}

	/* get the parameters from web page for enabling/disabling of WMM/U-APSD */
	/* WMM enable */
	gsprintf(sCommand, T("wmmEnable"));
	pValue = ifx_httpdGetVar(wp, sCommand, T(""));
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWmmConfiguration",
		"wmmEnable: %s", pValue);
	wlMain.WMMena = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWmmConfiguration",
		"WMMena: %d", wlMain.WMMena);

	/* U-APSD enable */
	gsprintf(sCommand, T("uapsdEnable"));
	pValue = ifx_httpdGetVar(wp, sCommand, T(""));
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWmmConfiguration",
		       "uapsdEnable: %s", pValue);
	wlMain.UAPSDena = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWmmConfiguration", "UAPSDena: %d",
		       wlMain.UAPSDena);

	/* call API to enable/disable WMM/U-APSD */
	flags = IFX_F_MODIFY;
	/*
		for non-optimized scripts we must not call ifx_mapi_set_wlan_main_config
		now, as it does a stop/start; first set	the new wmm parameters to
		rc.conf	by calling wmm apis below; afterwards ifx_mapi_set_wlan_main_config
		can be called;	for optimized WAVE scripts ifx_mapi_set_wlan_main_config
		can be called directly as it does not call any scripts
	*/
//	if (ltq_mapi_get_wlan_supported_features(wlMain.radioCpeId,
//		IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_OPT_SCRIPTS) {
		/* prevent stop/start sequence here and do not write to flash yet */
		flags |= IFX_F_INT_DONT_CONFIGURE;
		flags |= IFX_F_DONT_WRITE_TO_FLASH;
		wlMain.iid.config_owner = IFX_WEB;
		if ((ret =
			ifx_mapi_set_wlan_main_config(IFX_OP_MOD, &wlMain, flags)) != IFX_SUCCESS) {
				ifx_httpdError(wp, 400, "Failed to set wlan main config");
				goto IFX_Handler;
		}
//	}

	/*
	   do not write to flash now to prevent doing this multiple times, do this
	   when the main configuration is set */
	flags |= IFX_F_DONT_WRITE_TO_FLASH;

	/* before calling wmm apis, make sure iid settings are set correct */
	wlApWmm.iid.config_owner = IFX_WEB;
	wlStaWmm.iid.config_owner = IFX_WEB;
	/* set pCpeId, which is cpeId of parent (wlan_main) */
	wlApWmm.iid.pcpeId.Id = wlMain.iid.cpeId.Id;
	wlStaWmm.iid.pcpeId.Id = wlMain.iid.cpeId.Id;

	/* only activate on the last access category */
	flags |= IFX_F_INT_DONT_CONFIGURE;
	if ((ret = ifx_mapi_get_all_wlan_wmm_ap_config(wlMain.iid.cpeId.Id,
		&numEntries, &wlApWmmAll, IFX_F_DEFAULT)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWmmConfiguration", "");
		goto IFX_Handler;
	}
	if ((ret = ifx_mapi_get_all_wlan_wmm_sta_config(wlMain.iid.cpeId.Id,
		&numEntries, &wlStaWmmAll, IFX_F_DEFAULT)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWmmConfiguration", "");
		goto IFX_Handler;
	}
	for (i = 0; i < IFX_MAPI_WLAN_WMM_NUM_AC; i++) {
		memcpy(&wlApWmm, wlApWmmAll+i, sizeof(IFX_MAPI_WLAN_AP_WMM_Cfg));
		memcpy(&wlStaWmm, wlStaWmmAll+i, sizeof(IFX_MAPI_WLAN_STA_WMM_Cfg));
		WLAN_GetWmmApSettings(wp, &wlApWmm, i);
		ltq_get_wlan_wmmStaConfig(wp, &wlStaWmm, i);

		/* set the wlan wmm configuration */
		if ((ret = ifx_mapi_set_wlan_wmm_ap_config(IFX_OP_MOD, &wlApWmm, flags |
			IFX_F_DONT_WRITE_TO_FLASH)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to set wlan wmm ap config");
			goto IFX_Handler;
		}

		/*
		 * below ifx_mapi_set_wlan_main_config is called => stop/start of AP/VAP
		 * with modifified configuration is done there
		 */

		/*
		   This is the last call to one of the wmm apis; up to this point no
		   script has been called to actually enable the WMM modification. To
		   do this now, the previously set flag has to be removed. This is done
		   to prevent enabling and disabling the complete AP/VAP multiple times
		   (for modification of each AC). */
		if (ltq_mapi_get_wlan_supported_features(wlMain.radioCpeId,
			IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_OPT_SCRIPTS) {
			if (i == (IFX_MAPI_WLAN_WMM_NUM_AC - 1)) {
				/* remove flags for last call */
				flags &= ~IFX_F_INT_DONT_CONFIGURE;
				flags &= ~IFX_F_DONT_WRITE_TO_FLASH;
			}
		}

		/* set the wlan wmm configuration */
		if ((ret =
			ifx_mapi_set_wlan_wmm_sta_config(IFX_OP_MOD, &wlStaWmm, flags)) !=
			IFX_SUCCESS) {
				ifx_httpdError(wp, 400, "Failed to set wlan wmm sta config");
			goto IFX_Handler;
		}
	}

/*
	if (!(ltq_mapi_get_wlan_supported_features(wlMain.radioCpeId,
		IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_OPT_SCRIPTS)) {
		if ((ret =
			ifx_mapi_set_wlan_main_config(IFX_OP_MOD, &wlMain, IFX_F_MODIFY)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400, "Failed to set wlan main config");
			goto IFX_Handler;
		}
	}
*/
IFX_Handler:
	IFX_MEM_FREE(wlApWmmAll);
	IFX_MEM_FREE(wlStaWmmAll);
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWmmConfiguration", "ret: %d", ret);
	if (ret != IFX_SUCCESS)
		return;
	else {
		if (ltq_wlan_redirect(wp, "wlan_wmm.asp", apIndex) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWmmConfiguration", "");
			websNextPage(wp);
		}
	}
}

/**
   This function is called from web page wlan_wps.asp. Values entered on the web
   page are retrieved and stored in corresponding structures of type
   xxx. These structure are
   provided to IFX WLAN MAPI. Two additional parameters (operation and flags)
   specify the operations that will be executed within IFX WLAN MAPI (e.g. add,
   delete, modify). Note, that this function is only called for modify
   operations.

   \param wp      web page structure

   \param path

   \param query

   \return
   None.
*/
void IFX_WLAN_SetWpsConfiguration(httpd_t wp, char_t * path, char_t * query)
{
	IFX_MAPI_WLAN_MainCfg wlMain;
	IFX_MAPI_WLAN_WPS_Cfg wlWps;
	int32 oper = 0, flags = IFX_F_DEFAULT;
	uint32 outFlag = IFX_F_DEFAULT;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	int32 apIndex = 0xFFFFFFFF, ret = IFX_SUCCESS;
	char8 *pApIndex = NULL, *pApVapActionType;
	char8 *pValue = NULL, sCommand[MAX_DATA_LEN];

	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration", "");

	/* first get the index of ap/vap to be configured */
	pApIndex = ifx_httpdGetVar(wp, T("wpsApIndex"), T("1"));
	apIndex = gatoi(pApIndex);
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration", "apIndex: %d",
		       apIndex);
	if ((apIndex < 0) || (apIndex >= LTQ_MAX_NUM_VAP)) {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration",
			"apIndex out of range: %d", apIndex);
		goto IFX_Handler;
	}

	/* IFX ID is extracted from wlan_main object. */
	/* first init configuration */
	memset(&wlMain, 0, sizeof(IFX_MAPI_WLAN_MainCfg));
	sprintf(wlMain.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
	sprintf(wlMain.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
	pValue = ifx_httpdGetVar(wp, "apName", T(""));
	if (ifx_get_iid_from_ap_name(pValue, &wlMain.iid) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to get IFX ID");
		goto IFX_Handler;
	}

	/* get the wlan main configuration from MAPI */
	if ((ret = ifx_mapi_get_wlan_main_config(&wlMain, IFX_F_DEFAULT)) !=
		IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration", "");
		ifx_httpdError(wp, 400, "Failed to get wlan main config");
		goto IFX_Handler;
	}

	pApVapActionType = ifx_httpdGetVar(wp, T("submit_action"), T(""));
	if (!pApVapActionType) {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration",
			       "(!pApVapActionType)");
		return;
	}

	if (!gstrcmp(pApVapActionType, "wpsPbcStart")) {
		/* trigger wps pbc pairing */
		if ((ret =
		     ifx_mapi_trigger_wps_pbc(wlMain.iid.cpeId.Id)) !=
		    IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration",
				       "mainCpeId: %d", wlMain.iid.cpeId.Id);
			ifx_httpdError(wp, 400,
				       "Failed to trigger wps pbc pairing");
			goto IFX_Handler;
		}

		if (ltq_mapi_get_wlan_vendor(wlMain.radioCpeId, IFX_F_DEFAULT) ==
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
#ifdef FIX_JIRA_WAVE300_SW_2384
			gCurrentWpsStatusLoop = 1;
			ifx_httpdRedirect(wp, "wlan_wps_status.asp");
			return;
#endif /* #ifdef FIX_JIRA_WAVE300_SW_2384 */
		}
	} else if (!gstrcmp(pApVapActionType, "wpsPinStart")) {
		char8 clientPin[9];
		uint32	idxAuthEpMacAddr = 0;
		char8 	authEpMacAddr[IFX_MAPI_MAC_ADDR_LEN];

		/* get the entered PIN from web page */
		gsprintf(sCommand, T("wpsPin"));
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		gstrcpy(clientPin, pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration",
			       "clientPin: %s", clientPin);

		if (ltq_mapi_get_wlan_vendor(wlMain.radioCpeId, IFX_F_DEFAULT) ==
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			/* get the selected MAC for authorized PIN pairing */
			gsprintf(sCommand, T("wpsEpMacList"));
			pValue = ifx_httpdGetVar(wp, sCommand, T(""));
			idxAuthEpMacAddr = gatoi(pValue);
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration",
					   "idxAuthEpMacAddr: %d", idxAuthEpMacAddr);
			if (idxAuthEpMacAddr)
				gstrcpy(authEpMacAddr, g_wlWpsEpMacTable[apIndex][idxAuthEpMacAddr-1].macAddr);
			else
				gstrcpy(authEpMacAddr, "FF:FF:FF:FF:FF:FF");
		} else {
			gstrcpy(authEpMacAddr, "FF:FF:FF:FF:FF:FF");
		}
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration",
			"authEpMacAddr: %s", authEpMacAddr);

		/* trigger wps pin pairing */
		if ((ret = ifx_mapi_trigger_wps_pin(wlMain.iid.cpeId.Id, clientPin,
			authEpMacAddr)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400, "Failed to trigger wps pin based pairing");
			goto IFX_Handler;
		}
	} else if (!gstrcmp(pApVapActionType, "wpsRestorePin")) {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration", "");
		/* trigger wps pin restoring */
		if ((ret =
		     ifx_mapi_restore_wps_pin(wlMain.iid.cpeId.Id)) !=
		    IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration",
				       "mainCpeId: %d", wlMain.iid.cpeId.Id);
			ifx_httpdError(wp, 400,
				       "Failed to restore default wps pin");
			goto IFX_Handler;
		}
	} else if (!gstrcmp(pApVapActionType, "wpsGeneratePin")) {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration", "");
		/* trigger wps pin generation */
		if ((ret =
		     ifx_mapi_generate_wps_pin(wlMain.iid.cpeId.Id)) !=
		    IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration",
				       "mainCpeId: %d", wlMain.iid.cpeId.Id);
			ifx_httpdError(wp, 400,
				       "Failed to generate new wps pin");
			goto IFX_Handler;
		}
	} else if (!gstrcmp(pApVapActionType, "wpsConfig")) {
		memset(&wlWps, 0, sizeof(IFX_MAPI_WLAN_WPS_Cfg));
		sprintf(wlWps.iid.cpeId.secName, "%s", TAG_WLAN_WPS);
		sprintf(wlWps.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);

		sprintf(buf, "%s%d_0_cpeId", PREFIX_WLAN_WPS, wlMain.iid.cpeId.Id);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_WPS, buf,
			IFX_F_DEFAULT, &outFlag, sValue)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration", "buf: %s",
				buf);
			ifx_httpdError(wp, 400, "Failed to get cpeId from configuration");
			goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration", "sValue: %s",
			sValue);
		wlWps.iid.cpeId.Id = atoi(sValue);

		sprintf(buf, "%s%d_0_pcpeId", PREFIX_WLAN_WPS, wlMain.iid.cpeId.Id);
		if ((ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_WPS, buf, IFX_F_GET_ANY,
			&outFlag, sValue)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration", "buf: %s",
				buf);
			ifx_httpdError(wp, 400, "Failed to get pcpeId from configuration");
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wlWps.iid.pcpeId.Id = atoi(sValue);

		/* get the wlan wps configuration from MAPI */
		if ((ret = ifx_mapi_get_wlan_wps_config(&wlWps, flags)) !=
			IFX_SUCCESS) {
				ifx_httpdError(wp, 400, "Failed to get wlan wps config");
				goto IFX_Handler;
		}

		/* get the parameters from web page for enabling/disabling of WPS */
		gsprintf(sCommand, T("wpsEnable"));
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		wlWps.enable = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration",
			       "wpsEna: %d", wlWps.enable);

		/* Enrollee Supported */
		gsprintf(sCommand, T("wpsEnrolleeSupport"));
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		wlWps.enrolleeEna = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration",
			       "wpsEnrolleeSupport: %d", wlWps.enrolleeEna);

		/* Internal Registrar Supported */
		gsprintf(sCommand, T("wpsIntRegsSupport"));
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		wlWps.intRegEna = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration",
			       "wpsIntRegsSupport: %d", wlWps.intRegEna);
		if (ltq_mapi_get_wlan_vendor(wlMain.radioCpeId, IFX_F_DEFAULT) ==
			LTQ_MAPI_WLAN_VENDOR_WAVE300) {
			if (wlWps.enable)
				wlWps.intRegEna = TRUE;
			else
				wlWps.intRegEna = FALSE;
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration",
					   "wpsIntRegsSupport: %d", wlWps.intRegEna);
		}

		if (ltq_mapi_get_wlan_supported_features(wlMain.radioCpeId,
			IFX_F_DEFAULT) & LTQ_MAPI_WLAN_FEATURE_WPS_PROXY) {
			/* Proxy Supported */
			gsprintf(sCommand, T("wpsProxySupport"));
			pValue = ifx_httpdGetVar(wp, sCommand, T(""));
			wlWps.proxyEna = gatoi(pValue);
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration",
					   "wpsProxySupport: %d", wlWps.proxyEna);
		} else {
			wlWps.proxyEna = 0;
		}

		/* WPS PIN lockout time */
		gsprintf(sCommand, T("wpsPinLockout"));
		pValue = ifx_httpdGetVar(wp, sCommand, T(""));
		wlWps.maxPinLockout = gatoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration",
			       "maxPinLockout: %d", wlWps.maxPinLockout);

		/* call API to configure WPA */
		oper = IFX_OP_MOD;
		flags = IFX_F_MODIFY;
		/* enable notifications to TR69 */
		flags = IFX_SET_DONT_SEND_NOTIFICATION_FLAG(flags);
		/* enable check of ACL */
		flags = IFX_SET_DONT_CHECK_ACL_FLAG(flags);
		wlWps.iid.config_owner = IFX_WEB;
		if ((ret = ifx_mapi_set_wlan_wps_config(oper, &wlWps, flags))
			!= IFX_SUCCESS) {
				ifx_httpdError(wp, 400, "Failed to set wlan wps config");
				goto IFX_Handler;
		}
	} else if (!gstrcmp(pApVapActionType, "wpsResetOob")) {
		IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration", "");
		if ((ret =
		     ifx_mapi_reset_wps(wlMain.iid.cpeId.Id)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration",
				       "mainCpeId: %d", wlMain.iid.cpeId.Id);
			ifx_httpdError(wp, 400,
				       "Failed to restore default wps out-of-box configuration");
			goto IFX_Handler;
		}
	}

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/IFX_WLAN_SetWpsConfiguration", "ret: %d", ret);
	if (ret != IFX_SUCCESS)
		return;
	else
		websNextPage(wp);
}

/**
   \param wp      web page structure

   \param path

   \param query

   \return
   None.
*/
void ltq_set_wlan_wps_epmac_config(httpd_t wp, char_t * path, char_t * query)
{
	LTQ_MAPI_WLAN_WPS_EP_MAC_Cfg *wlWpsEpMac = NULL;
	uint32 mainCpeId, numEntries = 0;
	int32 ret = IFX_SUCCESS, flags = 0, oper = 0;
	int32 i, apIndex;
	char8 *pValue, buf[MAX_FILELINE_LEN], apName[IFX_MAPI_WLAN_AP_NAME];
	IFX_ID	mainIid;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wps_epmac_config", "");

	pValue = ifx_httpdGetVar(wp, T("apIndex"), T(""));
	apIndex = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wps_epmac_config",
		"apIndex: %d", apIndex);

	memset(&mainIid, 0, sizeof(IFX_ID));
	sprintf(mainIid.cpeId.secName, "%s", TAG_WLAN_MAIN);
	sprintf(mainIid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
	pValue = ifx_httpdGetVar(wp, "apName", T(""));
	gstrcpy(apName, pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wps_epmac_config", "apName: %s", apName);
	if (ifx_get_iid_from_ap_name(apName, &mainIid) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to get iid");
		goto IFX_Handler;
	}

	mainCpeId = mainIid.cpeId.Id;
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wps_epmac_config",
		"mainCpeId: %d", mainCpeId);
	/* get complete ACL */
	if ((ret = ltq_mapi_get_all_wlan_wps_endpoint_mac(mainCpeId, &numEntries,
		&wlWpsEpMac, flags)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to get wlan wps ep mac table");
		return;
	}

	/* allocate memory for one object, if ACL was empty */
	if (numEntries == 0) {
		IFX_MEM_ALLOC((wlWpsEpMac), LTQ_MAPI_WLAN_WPS_EP_MAC_Cfg *, 1, sizeof(LTQ_MAPI_WLAN_WPS_EP_MAC_Cfg))

		sprintf(wlWpsEpMac->iid.cpeId.secName, "%s", TAG_WLAN_WPS_EP_MAC);
		sprintf(wlWpsEpMac->iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
		wlWpsEpMac->iid.pcpeId.Id = mainCpeId;
	} else {
		/*
		 * first remove all MAC entries marked for deletion
		 * but do not call script yet
		 */
		for (i = 0; i < numEntries; i++) {
			oper = IFX_OP_DEL;
			flags = IFX_F_DELETE | IFX_F_INT_DONT_CONFIGURE;
			(wlWpsEpMac + i)->iid.config_owner = IFX_WEB;
			if ((ret =
			     ltq_mapi_set_wlan_wps_endpoint_mac(oper,
			    		 	 	 wlWpsEpMac + i,
							   flags)) !=
			    IFX_SUCCESS) {
				ifx_httpdError(wp, 400,
					       "Failed to set wlan wps ep mac");
				goto IFX_Handler;
			}
		}
	}

	/* reset numEntries to zero and count the new number of entries in ACL */
	numEntries = 0;
	for (i = 0; i < LTQ_MAX_NUM_WPS_EP_MAC; i++) {
		memset(wlWpsEpMac, 0, sizeof(LTQ_MAPI_WLAN_WPS_EP_MAC_Cfg));
		sprintf(wlWpsEpMac->iid.cpeId.secName, "%s",
				TAG_WLAN_WPS_EP_MAC);
		sprintf(wlWpsEpMac->iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
		wlWpsEpMac->iid.pcpeId.Id = mainCpeId;
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wps_epmac_config",
			       "pCpeId: %d", wlWpsEpMac->iid.pcpeId.Id);

		/* do not add if empty of selected for deletion */
		sprintf(buf, "macAddr_%d", i + 1);
		pValue = ifx_httpdGetVar(wp, T(buf), T(""));
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wps_epmac_config",
			       "pValue: %s, strlen: %d", pValue,
			       strlen(pValue));
		if (strlen(pValue) == 0) {
			IFX_MAPI_DEBUG(fd,
				       "/tmp/ltq_set_wlan_wps_epmac_config",
				       "no MAC address entered in line: %d", i);
			continue;
		}
		gstrcpy((wlWpsEpMac + 0)->macAddr, pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wps_epmac_config",
			       "pValue: %s", (wlWpsEpMac + 0)->macAddr);
		sprintf(buf, "rmid%d", i);
		pValue = ifx_httpdGetVar(wp, T(buf), T(""));
		IFX_MAPI_DEBUG(fd, "/tmp/wlWpsEpMac",
			       "pValue: %s", pValue);
		/* was selected for deletion; therefore do not add */
		if (gatoi(pValue) == 1) {
			IFX_MAPI_DEBUG(fd,
				       "/tmp/wlWpsEpMac",
				       "line %d already deleted from list", i);
			continue;
		}
		oper = IFX_OP_ADD;
		flags = IFX_F_DEFAULT | IFX_F_INT_DONT_CONFIGURE;
		wlWpsEpMac->iid.config_owner = IFX_WEB;
		if ((ret = ltq_mapi_set_wlan_wps_endpoint_mac(oper, wlWpsEpMac, flags))
			!= IFX_SUCCESS) {
			ifx_httpdError(wp, 400, "Failed to set wlan wps ep mac");
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wps_epmac_config", "");
			IFX_MEM_FREE(wlWpsEpMac);
			return;
		}
		numEntries++;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wps_epmac_config",
		       "numEntries: %d", numEntries);

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wps_epmac_config", "");
	IFX_MEM_FREE(wlWpsEpMac);
	websNextPage(wp);
	return;
}

/**
   \param eid

   \param wp      web page structure

   \param argc    number of arguments provided in argv

   \param argv    array holding a number of arguments specified with argc

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
void ltq_get_wps_status(int eid, httpd_t wp, int argc, char_t ** argv)
{
	LTQ_MAPI_WPS_ConnectionStatus wpsLinkConnectStatus = LTQ_MAPI_WPS_CONNECTION_IDLE;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_wps_status", "");

	if (ltq_mapi_get_wps_connection_status(&wpsLinkConnectStatus) !=
	    IFX_SUCCESS) {
		ifx_httpdWrite(wp, "wpsStatus = \"IDLE\";\n");
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_wps_status",
			       "Failed to get video bridge wps connection status.");
		goto LTQ_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_wps_status",
		       "Connection status: %d", wpsLinkConnectStatus);

	switch (wpsLinkConnectStatus) {
	case LTQ_MAPI_WPS_CONNECTION_IDLE:
		ifx_httpdWrite(wp, "wpsStatus = \"IDLE\";\n");
		break;
	case LTQ_MAPI_WPS_CONNECTION_IN_PROGRESS:
		ifx_httpdWrite(wp, "wpsStatus = \"IN_PROGRESS\";\n");
		break;
	case LTQ_MAPI_WPS_CONNECTION_TIMEOUT:
		ifx_httpdWrite(wp, "wpsStatus = \"TIMEOUT\";\n");
		break;
	case LTQ_MAPI_WPS_CONNECTION_OVERLAP_ERR:
		ifx_httpdWrite(wp, "wpsStatus = \"OVERLAP\";\n");
		break;
	case LTQ_MAPI_WPS_CONNECTION_SUCCESS:
		ifx_httpdWrite(wp, "wpsStatus = \"SUCCESS\";\n");
		break;
	default:
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_wps_status",
			       "Invalid WPS connection status.");
		break;
	}

LTQ_Handler:
	ifx_httpdWrite(wp, T("loopObjectWps.current = %d;\n"),
		gCurrentWpsStatusLoop++);
}

/**
   \param wp      web page structure

   \param path

   \param query

   \return
   None
*/
void ltq_get_wps_result(httpd_t wp, char_t * path, char_t * query)
{
	char8 *pApVapActionType;

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_wps_result", "");

	pApVapActionType = ifx_httpdGetVar(wp, T("submit_action"), T(""));
	if (!pApVapActionType) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_wps_result",
			       "(!pApVapActionType)");
		return;
	}

	if (!gstrcmp(pApVapActionType, "timeout")) {
		ifx_httpdRedirect(wp, "wlan_wps_status_timeout.html");
	} else if (!gstrcmp(pApVapActionType, "overlap")) {
		ifx_httpdRedirect(wp, "wlan_wps_status_overlap.html");
	} else if (!gstrcmp(pApVapActionType, "success")) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_vb_wps_result", "");
	}

	websNextPage(wp);
}

/**
   \param wp      web page structure

   \param path

   \param query

   \return
   None.
*/
void ltq_set_wlan_mac_filter_config(httpd_t wp, char_t * path, char_t * query)
{
	IFX_MAPI_WLAN_SecCfg wlSec;
	IFX_MAPI_WLAN_MAC_Control *wlMacControl = NULL;
	IFX_MAPI_WLAN_Capability	wlCaps;
	uint32 numEntries = 0, outFlag = IFX_F_DEFAULT, parentCpeId = 0;
	int32 ret = IFX_SUCCESS, flags = 0, oper = 0;
	int32 i, apIndex;
	char8 *pValue, buf[MAX_FILELINE_LEN];
	char8 sValue[MAX_FILELINE_LEN];

	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_mac_filter_config", "");

	memset(&wlSec, 0, sizeof(IFX_MAPI_WLAN_SecCfg));
	sprintf(wlSec.iid.cpeId.secName, "%s", TAG_WLAN_SEC);
	sprintf(wlSec.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

	pValue = ifx_httpdGetVar(wp, T("apIndex"), T(""));
	apIndex = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_mac_filter_config", 
		"apIndex: %d", apIndex);

	sprintf(buf, "%s_%d_cpeId", PREFIX_WLAN_SEC, apIndex);
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_SEC, buf, IFX_F_DEFAULT,
			    &outFlag, sValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_mac_filter_config", "");
		ifx_httpdError(wp, 400,
			       "Failed to get cpeId from configuration");
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_mac_filter_config", "sValue: %s",
		       sValue);
	wlSec.iid.cpeId.Id = parentCpeId = atoi(sValue);

	if ((ret =
	     ifx_mapi_get_wlan_security_config(&wlSec,
					       outFlag)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to get wlan security config");
		goto IFX_Handler;
	}

	/* get complete ACL */
	if ((ret = ifx_mapi_get_all_wlan_mac_control_entries(parentCpeId,
		&numEntries, &wlMacControl, flags)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to get wlan mac control table");
		return;
	}

	/* allocate memory for one object, if ACL was empty */
	if (numEntries == 0) {
		IFX_MEM_ALLOC((wlMacControl), IFX_MAPI_WLAN_MAC_Control *, 1,
			sizeof(IFX_MAPI_WLAN_MAC_Control))
		sprintf(wlMacControl->iid.cpeId.secName, "%s", TAG_WLAN_MAC_CONTROL);
		sprintf(wlMacControl->iid.pcpeId.secName, "%s", TAG_WLAN_SEC);
		wlMacControl->iid.pcpeId.Id = parentCpeId;
	} else {
		/*
		 * first remove all MAC entries marked for deletion
		 * but do not call script yet
		 */
		for (i = 0; i < numEntries; i++) {
			oper = IFX_OP_DEL;
			flags = IFX_F_DELETE | IFX_F_INT_DONT_CONFIGURE | IFX_F_DONT_WRITE_TO_FLASH;
			(wlMacControl + i)->iid.config_owner = IFX_WEB;
			if ((ret =
			     ifx_mapi_set_wlan_mac_control(oper,
							   wlMacControl + i,
							   flags)) !=
			    IFX_SUCCESS) {
				ifx_httpdError(wp, 400, "Failed to set wlan mac control");
				goto IFX_Handler;
			}
		}
	}

	/* �determine number of possible MAC entries from capabilities */
	memset(&wlCaps, 0xFF, sizeof(IFX_MAPI_WLAN_Capability));
	if ((ret = ifx_mapi_get_wlan_capability(&wlCaps, IFX_F_DEFAULT)) !=
		IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to get wlan capablities");
		goto IFX_Handler;
	}
	/* reset numEntries to zero and count the new number of entries in ACL */
	numEntries = 0;
	for (i = 0; i < wlCaps.numMacCntrlEntries; i++) {
		memset(wlMacControl, 0, sizeof(IFX_MAPI_WLAN_MAC_Control));
		sprintf(wlMacControl->iid.cpeId.secName, "%s",
			TAG_WLAN_MAC_CONTROL);
		sprintf(wlMacControl->iid.pcpeId.secName, "%s", TAG_WLAN_SEC);
		wlMacControl->iid.pcpeId.Id = parentCpeId;
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_mac_filter_config",
			       "pCpeId: %d", wlMacControl->iid.pcpeId.Id);

		/* do not add if empty of selected for deletion */
		sprintf(buf, "macAddr_%d", i + 1);
		pValue = ifx_httpdGetVar(wp, T(buf), T(""));
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_mac_filter_config",
			       "pValue: %s, strlen: %d", pValue,
			       strlen(pValue));
		if (strlen(pValue) == 0) {
			IFX_MAPI_DEBUG(fd,
				       "/tmp/ltq_set_wlan_mac_filter_config",
				       "no MAC address entered in line: %d", i);
			continue;
		}
		gstrcpy((wlMacControl + 0)->macAddr, pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_mac_filter_config",
			       "pValue: %s", (wlMacControl + 0)->macAddr);
		sprintf(buf, "rmid%d", i);
		pValue = ifx_httpdGetVar(wp, T(buf), T(""));
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_mac_filter_config",
			       "pValue: %s", pValue);
		/* was selected for deletion; therefore do not add */
		if (gatoi(pValue) == 1) {
			IFX_MAPI_DEBUG(fd,
				       "/tmp/ltq_set_wlan_mac_filter_config",
				       "line %d already deleted from list", i);
			continue;
		}
		oper = IFX_OP_ADD;
		flags = IFX_F_DEFAULT | IFX_F_INT_DONT_CONFIGURE | IFX_F_DONT_WRITE_TO_FLASH;
		wlMacControl->iid.config_owner = IFX_WEB;
		if ((ret =
		     ifx_mapi_set_wlan_mac_control(oper, wlMacControl,
						   flags)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400,
				       "Failed to set wlan mac control");
			IFX_MAPI_DEBUG(fd,
				       "/tmp/ltq_set_wlan_mac_filter_config",
				       "");
			return;
		}
		numEntries++;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_mac_filter_config",
		       "numEntries: %d", numEntries);

	/* proceed with general MAC control settings both in mac control object and
	   in security object */
	/*
	 * do not configure until the last mapi call is done
	 */
	oper = IFX_OP_MOD;

	pValue = ifx_httpdGetVar(wp, T("mac_control_status"), T(""));
	wlSec.macAddrCntrlEna = atoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_mac_filter_config",
		       "macAddrCntrlEna: %d", wlSec.macAddrCntrlEna);

	wlSec.iid.config_owner = IFX_WEB;
	flags = IFX_F_MODIFY | IFX_F_INT_DONT_CONFIGURE;

	if ((ret = ifx_mapi_set_wlan_security_config(oper, &wlSec, flags)) !=
		IFX_SUCCESS) {
			ifx_httpdError(wp, 400, "Failed to set wlan security config");
			goto IFX_Handler;
	}

	/* now write to flash and call required script */
	flags = IFX_F_MODIFY;
	if ((ret = ifx_mapi_set_wlan_mac_control_status(wlSec.iid.cpeId.Id, oper,
		flags)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to set wlan mac filter config");
		goto IFX_Handler;
	}

	/*
	 * reset flag to make sure updated configuration is re-loaded to global arrays
	 * the next time a WLAN web page is loaded
	 */
	g_flagConfigLoaded = 0;

IFX_Handler:
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_mac_filter_config", "");
	IFX_MEM_FREE(wlMacControl);
	if (ltq_wlan_redirect(wp, "wlan_mac_filter_cfg.asp", apIndex) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_mac_filter_config", "");
		websNextPage(wp);
	}
	return;
}

/**
   \param wp      web page structure

   \param path

   \param query

   \return
   None.
*/
void ltq_set_wlan_wds_config(httpd_t wp, char_t * path, char_t * query)
{
	IFX_MAPI_WLAN_MAC_Control	*wlWdsPeerMacList = NULL;
	LTQ_MAPI_WLAN_WDS_Cfg		wlWdsCfg;
	IFX_MAPI_WLAN_WEP_Cfg		wlWepCfg;
	IFX_MAPI_WLAN_MainCfg		wlMain;
	IFX_MAPI_WLAN_Capability	wlCaps;
	uint32						numEntries = 0, dispmode = 0;
	uint32						outFlag = IFX_F_DEFAULT;
	int32						ret = IFX_SUCCESS, flags = 0, oper = 0;
	int32						apIndex, nDelEntries = 0, nAclEntries = 0;
	int32						wepKeyLength = 0, i = 0, j = 0;
	char8						*pValue, buf[MAX_FILELINE_LEN];
	char8						sValue[MAX_FILELINE_LEN], sCommand[MAX_FILELINE_LEN];
	bool						f_wepKeyChanged = FALSE;
	bool						f_wdsStatusChange = FALSE, f_MacListMatch = FALSE;
	int32						flagsWepCfg = 0;

	LTQ_LOG_TIMESTAMP("Begin");

	memset(&wlWdsCfg, 0, sizeof(LTQ_MAPI_WLAN_WDS_Cfg));
	sprintf(wlWdsCfg.iid.cpeId.secName, "%s", TAG_WLAN_WDS);
	sprintf(wlWdsCfg.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);

	/* first get the index of ap/vap to be configured */
	pValue = ifx_httpdGetVar(wp, T("apIndex"), T(""));
	apIndex = gatoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config", "apIndex: %d", apIndex);

	if ((apIndex < 0) || (apIndex >= LTQ_MAX_NUM_VAP)) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config",
			"apIndex out of range: %d", apIndex);
		goto IFX_Handler;
	}

	sprintf(buf, "%s_%d_cpeId", PREFIX_WLAN_WDS, apIndex);
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_WDS, buf, IFX_F_DEFAULT,
			    &outFlag, sValue)) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config", "");
		ifx_httpdError(wp, 400, "Failed to get cpeId from configuration");
		goto IFX_Handler;
	}
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config", "sValue: %s", sValue);
	sprintf(wlWdsCfg.iid.cpeId.secName, "%s", TAG_WLAN_WDS);
	sprintf(wlWdsCfg.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
	wlWdsCfg.iid.cpeId.Id = atoi(sValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config", "cpdId: %d, pcpeId: %d",
		wlWdsCfg.iid.cpeId.Id, wlWdsCfg.iid.pcpeId.Id);

	/* get the wlan wds configuration from MAPI */
	if ((ret = ltq_mapi_get_wlan_wds_config(&wlWdsCfg, IFX_F_DEFAULT)) != IFX_SUCCESS) {
		ifx_httpdError(wp, 400, "Failed to get wlan wds config");
		goto IFX_Handler;
	}

	/* is WDS enabled? */
	pValue = ifx_httpdGetVar(wp, T("wdsStatus"), T(""));
	/* check if WDS status changes */
	if (wlWdsCfg.enable != atoi(pValue))
		f_wdsStatusChange = TRUE;
	wlWdsCfg.enable = atoi(pValue);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config", "wdsEnable: %d", wlWdsCfg.enable);

	/* only update WEP keys if WDS is enabled and WEP security is selected */
	if (wlWdsCfg.enable) {
		pValue = ifx_httpdGetVar(wp, T("wdsSecType"), T(""));
		wlWdsCfg.secMode = atoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config", "secMode: %d", wlWdsCfg.secMode);

		/* IFX ID is extracted from wlan_main object. */
		/* first init configuration */
		memset(&wlMain, 0, sizeof(IFX_MAPI_WLAN_MainCfg));
		sprintf(wlMain.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
		sprintf(wlMain.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
		pValue = ifx_httpdGetVar(wp, "apName", T(""));
		if (ifx_get_iid_from_ap_name(pValue, &wlMain.iid) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400, "Failed to get IFX ID");
			goto IFX_Handler;
		}

		/* get the wlan main configuration from MAPI */
		if ((ret = ifx_mapi_get_wlan_main_config(&wlMain, IFX_F_DEFAULT)) != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config", "");
			ifx_httpdError(wp, 400, "Failed to get wlan main config");
			goto IFX_Handler;
		}

		if ((wlWdsCfg.secMode == LTQ_MAPI_WDS_WEP) || f_wdsStatusChange) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config", "");
			memset(&wlWepCfg, 0x00, sizeof(IFX_MAPI_WLAN_WEP_Cfg));

			for (i = 0; i < IFX_MAPI_NUM_WEP_KEYS; i++)
				wlWepCfg.wepKey[i].iid.pcpeId.Id = wlMain.iid.cpeId.Id;

			if ((ret = ifx_mapi_get_wlan_wep_config(&wlWepCfg, IFX_F_DEFAULT)) !=
				IFX_SUCCESS) {
				ifx_httpdError(wp, 400, "Failed to get wep key configuration");
				goto IFX_Handler;
			}

			pValue = ifx_httpdGetVar(wp, "wepKeyDisplayType", T(""));
			if (gstrcmp(pValue, "password")) {
				dispmode = 1;
			}
			for (i = 0; i < IFX_MAX_WLAN_KEY_INDEX; i++) {
				if (dispmode) {
					gsprintf(sCommand, T("wepKey%dText"), i + 1);
				} else {
					gsprintf(sCommand, T("wepKey%d"), i + 1);
				}
				pValue = ifx_httpdGetVar(wp, sCommand, T(""));
				IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config",
					"\noldKey: %s,\nnewKey: %s", wlWepCfg.wepKey[i].wepKey, pValue);

				/* check if one of the wep keys changed, if yes later on
					sec_modify script must be called*/
				if (strcmp(wlWepCfg.wepKey[i].wepKey, pValue)) {
					IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config", "wepKey changed");
					f_wepKeyChanged = TRUE;
				}

				snprintf(wlWepCfg.wepKey[i].wepKey, IFX_MAPI_WEP_KEY_MAX_LEN, "%s", pValue);
				IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config",
					"wepKey[%d]: %s, length: %d",
					i, wlWepCfg.wepKey[i].wepKey, strlen(wlWepCfg.wepKey[i].wepKey));
			}

			if ( (strlen(wlWepCfg.wepKey[0].wepKey) != strlen(wlWepCfg.wepKey[1].wepKey)) ||
				 (strlen(wlWepCfg.wepKey[0].wepKey) != strlen(wlWepCfg.wepKey[2].wepKey)) ||
				 (strlen(wlWepCfg.wepKey[0].wepKey) != strlen(wlWepCfg.wepKey[3].wepKey))) {
				ifx_httpdError(wp, 400, "All WEP keys must have same length");
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}

			wepKeyLength = strlen(wlWepCfg.wepKey[0].wepKey);
			if (wepKeyLength == 5) {
				wlWepCfg.wepKeyType = IFX_MAPI_WLAN_ASCII_KEY;
				wlWepCfg.wepEncrLevel = IFX_MAPI_WEP_ENCR_LVL_64BIT;
			} else if	(wepKeyLength == 10) {
				wlWepCfg.wepKeyType = IFX_MAPI_WLAN_HEX_KEY;
				wlWepCfg.wepEncrLevel = IFX_MAPI_WEP_ENCR_LVL_64BIT;
			} else if	(wepKeyLength == 13) {
				wlWepCfg.wepKeyType = IFX_MAPI_WLAN_ASCII_KEY;
				wlWepCfg.wepEncrLevel = IFX_MAPI_WEP_ENCR_LVL_128BIT;
			} else if	(wepKeyLength == 26) {
				wlWepCfg.wepKeyType = IFX_MAPI_WLAN_HEX_KEY;
				wlWepCfg.wepEncrLevel = IFX_MAPI_WEP_ENCR_LVL_128BIT;
			} else {
				ifx_httpdError(wp, 400, "Invalid WEP key length");
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config", 
				"wepKeyType: %d, wepEncrLevel: %d",
				wlWepCfg.wepKeyType, wlWepCfg.wepEncrLevel);

			if (f_wepKeyChanged || f_wdsStatusChange) {
				IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config",  "");
				/* only call script if wep key changed or if wds state changed */
				flags = IFX_F_DEFAULT | IFX_F_DONT_WRITE_TO_FLASH;
			} else {
				flags = IFX_F_DEFAULT | IFX_F_DONT_WRITE_TO_FLASH | IFX_F_INT_DONT_CONFIGURE;
			}
			flagsWepCfg = flags;
		}
	}

	/*
		only update Peer AP MAC table if WDS is enabled;
		if WDS is not enabled, it is assumed tht the MAC list has not changed
	*/
	f_MacListMatch = TRUE;
	if (wlWdsCfg.enable) {
		/* �determine number of possible MAC entries from capabilities */
		memset(&wlCaps, 0xFF, sizeof(IFX_MAPI_WLAN_Capability));
		if ((ret = ifx_mapi_get_wlan_capability(&wlCaps, IFX_F_DEFAULT)) !=
			IFX_SUCCESS) {
			ifx_httpdError(wp, 400, "Failed to get wlan capablities");
			goto IFX_Handler;
		}

		/* get complete ACL */
		if ((ret = ltq_mapi_get_all_wlan_wds_peer_mac(wlWdsCfg.iid.cpeId.Id,
			&numEntries, &wlWdsPeerMacList, IFX_F_DEFAULT)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400, "Failed to get wlan mac control table");
			return;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config", "numEntries: %d", numEntries);

		/**
			check if MAC table is unchanged:
			1. check if length of "old" and "new" list match
			2. additional checks are performed below only if the list length match
		*/
		pValue = ifx_httpdGetVar(wp, T("nDelEntries"), T(""));
		nDelEntries = atoi(pValue);
		pValue = ifx_httpdGetVar(wp, T("nWdsPeerMacEntries"), T(""));
		nAclEntries = atoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config",
			"nDelEntries: %d, nAclEntries: %d", nDelEntries, nAclEntries);
		if ((nAclEntries - nDelEntries) == numEntries) {
			f_MacListMatch = TRUE;
		} else {
			f_MacListMatch = FALSE;
		}
		/* allocate memory for one object, if ACL was empty */
		if (numEntries == 0) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config", "");
			IFX_MEM_ALLOC((wlWdsPeerMacList), IFX_MAPI_WLAN_MAC_Control *, 1, sizeof(IFX_MAPI_WLAN_MAC_Control))
			sprintf(wlWdsPeerMacList->iid.cpeId.secName, "%s", TAG_WLAN_WDS_PEER_MAC);
			sprintf(wlWdsPeerMacList->iid.pcpeId.secName, "%s", TAG_WLAN_WDS);
			wlWdsPeerMacList->iid.pcpeId.Id = wlMain.iid.cpeId.Id;
		} else {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config", "");
			/**
				second part of check if MAC table is unchanged (only done if list length match):
				1. check all entries if they are empty or marked for deletion
				2. check if each valid entry has a match in "old" list
			*/
			if (f_MacListMatch) {
				for (i = 0; i < wlCaps.numMacCntrlEntries; i++) {
					/* if entry was selected for deletion, no need to compare */
					sprintf(buf, "rmid%d", i);
					pValue = ifx_httpdGetVar(wp, T(buf), T(""));
					if (gatoi(pValue) == 1) {
						IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config", "");
						continue;
					}
					/* entry is empty => do not compare */
					sprintf(buf, "macAddr_%d", i + 1);
					pValue = ifx_httpdGetVar(wp, T(buf), T(""));
					if (!strlen(pValue)) {
						continue;
					}
					/* check if MAC is in "old" list */
					f_MacListMatch = FALSE;
					for (j = 0; j < numEntries; j++) {
						if (!strcmp(pValue, (wlWdsPeerMacList + i)->macAddr)) {
							f_MacListMatch = TRUE;
						}
					}
					/* no match found, thus list has changed */
					if (!f_MacListMatch)
						break;
				}
			}

			/*
			 * first remove all MAC entries marked for deletion
			 * but do not call script yet
			 */
			pValue = ifx_httpdGetVar(wp, T("nDelEntries"), T(""));
			nDelEntries = atoi(pValue);
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config",
				"number of entries to be deleted: %d", nDelEntries);
			/* delete all and then add */
			for (i = 0; i < numEntries; i++) {
				oper = IFX_OP_DEL;
				flags = IFX_F_DELETE | IFX_F_INT_DONT_CONFIGURE | IFX_F_DONT_WRITE_TO_FLASH;
				(wlWdsPeerMacList + i)->iid.config_owner = IFX_WEB;
				if ((ret = ltq_mapi_set_wlan_wds_peer_mac(
					oper, wlWdsPeerMacList + i, flags)) != IFX_SUCCESS) {
						ifx_httpdError(wp, 400, "Failed to set wlan wds peer mac list");
						goto IFX_Handler;
				}
			}
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config",
			"f_MacListMatch: %d", f_MacListMatch);

		/* reset numEntries to zero and count the new number of entries in ACL */
		numEntries = 0;
		for (i = 0; i < wlCaps.numMacCntrlEntries; i++) {
			memset(wlWdsPeerMacList, 0, sizeof(IFX_MAPI_WLAN_MAC_Control));
			sprintf(wlWdsPeerMacList->iid.cpeId.secName, "%s", TAG_WLAN_WDS_PEER_MAC);
			sprintf(wlWdsPeerMacList->iid.pcpeId.secName, "%s", TAG_WLAN_WDS);
			wlWdsPeerMacList->iid.pcpeId.Id = wlMain.iid.cpeId.Id;

			/* do not add if empty of selected for deletion */
			sprintf(buf, "macAddr_%d", i + 1);
			pValue = ifx_httpdGetVar(wp, T(buf), T(""));
			if (!strlen(pValue)) {
				continue;
			}
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config",
				"pCpeId: %d, pValue: %s, strlen: %d",
				wlWdsPeerMacList->iid.pcpeId.Id, pValue, strlen(pValue));
			gstrcpy((wlWdsPeerMacList + 0)->macAddr, pValue);
			sprintf(buf, "rmid%d", i);
			pValue = ifx_httpdGetVar(wp, T(buf), T(""));
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config",
					   "pValue: %s", pValue);
			/* was selected for deletion; therefore do not add */
			if (gatoi(pValue) == 1) {
				IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config",
					"line %d already deleted from list", i);
				continue;
			}
			oper = IFX_OP_ADD;
			flags = IFX_F_DEFAULT | IFX_F_INT_DONT_CONFIGURE | IFX_F_DONT_WRITE_TO_FLASH;
			wlWdsPeerMacList->iid.config_owner = IFX_WEB;
			if ((ret = ltq_mapi_set_wlan_wds_peer_mac(oper, wlWdsPeerMacList,
				flags)) != IFX_SUCCESS) {
					ifx_httpdError(wp, 400, "Failed to set wlan mac control");
					IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config", "");
				return;
			}
			numEntries++;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config",
				   "numEntries: %d", numEntries);
	}

	/* proceed with general WDS configuration settings */
	/*
	 * do not configure until the last mapi call is done
	 */
	/* only update these parameters  if WDS is enabled */
	if (wlWdsCfg.enable) {
		pValue = ifx_httpdGetVar(wp, T("wdsWepKeyIdx"), T(""));
		wlWdsCfg.peerAPKeyIdx = atoi(pValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config", "peerAPKeyIdx: %d", wlWdsCfg.peerAPKeyIdx);

		wlWdsCfg.nPeerAPs = numEntries;
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config", "nPeerAPs: %d", wlWdsCfg.nPeerAPs);
	}

	oper = IFX_OP_MOD;
	wlWdsCfg.iid.config_owner = IFX_WEB;

	/* only call MAPI if config changed (WDS config or WDS peer MAC list */
	if (mapiWlanChkWdsCfgChg(apIndex, &wlWdsCfg) || !f_MacListMatch) {
		if ((ret =
			 ltq_mapi_set_wlan_wds_config(oper, &wlWdsCfg, IFX_F_DEFAULT |
				IFX_F_INT_DONT_CHECK_ACL)) != IFX_SUCCESS) {
			ifx_httpdError(wp, 400, "Failed to set wlan wds config");
			goto IFX_Handler;
		}
	}

	if (wlWdsCfg.enable) {
		if ((wlWdsCfg.secMode == LTQ_MAPI_WDS_WEP) || f_wdsStatusChange) {
			IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config",  "flags: 0x%x", flags);
			if ((ret = ifx_mapi_set_wlan_wep_config(IFX_OP_MOD, &wlWepCfg, flagsWepCfg))
				!= IFX_SUCCESS) {
				IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config", 
					"ifx_mapi_set_wlan_wep_config has failed");
				ifx_httpdError(wp, 400, "Failed to set wep key configuration");
				goto IFX_Handler;
			}
		}
	}

IFX_Handler:
	IFX_MEM_FREE(wlWdsPeerMacList);
	IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config", "");
	if (ltq_wlan_redirect(wp, "wlan_wds_cfg.asp", apIndex) != IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_set_wlan_wds_config", "");
		websNextPage(wp);
	}
	return;
}

/**
   \param   wlWdsCfg - pointer to LTQ_MAPI_WLAN_WDS_Cfg structure

   \return
      TRUE or FALSE

   \remarks -  checks all parameters of WDS configuration for change
   	   	   	   returns TRUE if one or more parameter changed
   	   	   	   returns FALSE if no parameter changed
*/
static bool mapiWlanChkWdsCfgChg(int32 idx, LTQ_MAPI_WLAN_WDS_Cfg * wlWdsCfg)
{
	LTQ_MAPI_WLAN_WDS_Cfg		wlWdsOldCfg;

	IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkWdsCfgChg", "idx: %d", idx);

	memset(&wlWdsOldCfg, 0, sizeof(LTQ_MAPI_WLAN_WDS_Cfg));
	sprintf(wlWdsOldCfg.iid.cpeId.secName, "%s", TAG_WLAN_WDS);
	sprintf(wlWdsOldCfg.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);

	wlWdsOldCfg.iid.cpeId.Id = wlWdsCfg->iid.cpeId.Id;
	wlWdsOldCfg.iid.pcpeId.Id = wlWdsCfg->iid.pcpeId.Id;
	IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkWdsCfgChg", "cpdId: %d, pcpeId: %d",
		wlWdsOldCfg.iid.cpeId.Id, wlWdsOldCfg.iid.pcpeId.Id);

	/* get the wlan wds configuration from MAPI */
	if (ltq_mapi_get_wlan_wds_config(&wlWdsOldCfg, IFX_F_DEFAULT) !=
		IFX_SUCCESS) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkWdsCfgChg", "");
		return TRUE;
	}

	if (wlWdsCfg->enable != wlWdsOldCfg.enable) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkWdsCfgChg", "");
		return TRUE;
	}

	if (wlWdsCfg->secMode != wlWdsOldCfg.secMode) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkWdsCfgChg", "");
		return TRUE;
	}

	if (wlWdsCfg->peerAPKeyIdx != wlWdsOldCfg.peerAPKeyIdx) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkWdsCfgChg", "");
		return TRUE;
	}

	if (wlWdsCfg->nPeerAPs != wlWdsOldCfg.nPeerAPs) {
		IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanChkWdsCfgChg", "");
		return TRUE;
	}
	return FALSE;
}
#endif				/* #ifdef CONFIG_FEATURE_IFX_WIRELESS */
