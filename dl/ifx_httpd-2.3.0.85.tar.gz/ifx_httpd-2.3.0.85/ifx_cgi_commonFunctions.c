#include <ifx_emf.h>
#include "ifx_httpd_method.h"
#include <unistd.h>
#include "ifx_amazon_cgi.h"
#include <sys/syslog.h>
#include "./ifx_cgi_common.h"
#include <ifx_common.h>
#include "ifx_amazon_cgi_time.h"
#include "ifx_api_util.h"
#include <arpa/inet.h>

#define u16 unsigned short	//050712:fchang
#define u8  unsigned char	//050712:fchang
#define H2D_DEBUG_WRITE_DM      0x0a	//050712:fchang from amazon_mei_ioctl.h
#define H2D_CMV_WRITE           0x04	//050712:fchang from amazon_mei_ioctl.h
#define H2D_CMV_READ            0x00	//512062:fchang
#define TEST                    4	//050712:fchang from amazon_mei_ioctl.h
#define INFO                    3	//050712:fchang from amazon_mei_ioctl.h
#define OPTN                    5	//512062:fchang
#define AMAZON_MEI_CMV_WINHOST  306	//050712:fchang from amazon_mei_app.h

#define uint32_t                unsigned int
#define uint8_t                 unsigned char

#define trace(...)

#if defined(CONFIG_FEATURE_SMASH_SNMP) || defined(CONFIG_FEATURE_SNMPV1) || defined(CONFIG_FEATURE_SNMPV3)
#define IFX_HAVE_SNMP
//#include "ifx_snmp_api.h"
#endif

extern int32 mapi_user_obj_details_get(user_obj_t *user_obj, uint32 flags);
extern int32 mapi_get_all_user_obj_details(int32 *user_count, user_obj_t **user_obj, uint32 flags);
extern int32 mapi_user_obj_details_set(int32 opetation, user_obj_t *user_obj, uint32 flags);
extern int32 mapi_remote_access_details_set(remote_access_t *rt_access, uint32 flags);
extern int32 mapi_remote_access_details_get(remote_access_t *rt_access, uint32 flags);
#if defined(CONFIG_FEATURE_LTQ_VLAN_SWITCH_PORT_ISOLATION) ||  defined(CONFIG_FEATURE_LTQ_SWITCH_PORT_ISOLATION) 
extern int32 ifx_get_lan_port_conn_names(int32 eid, httpd_t wp, int32 argc, char8 ** argv);
extern int lan_port_sep_enable_get();
#endif

extern void ifx_httpdUpdateUsrPwd(char_t *user, char_t *pwd);

extern int32 ifx_get_wanip_conn_type(IP_TYPE * type, int32 wan_idx);

#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
extern int ltq_mapi_get_autodetect_config(auto_detect_cfg_t *config); 
#endif

extern int websGetCfgData2Table(httpd_t wp, const char_t * pFileName,
				char_t * pTag, const char_t * pSymbol,
				CGI_TABLE_S * pTable, int nTableType);
extern int ifx_httpd_parse_args(int argc, char_t ** argv, char_t * fmt, ...);
extern int32 ifx_get_another_fvp_from_dist_fvp(char8 * secName, char8 * fName,
					       char8 * fValue, char8 * fRetName,
					       char8 * fRetValue, uint32 flags);

#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
extern int ifx_cgi_adsl_phyconfig_set_ShowtimeLock(httpd_t wp);
extern int ifx_cgi_adsl_phyconfig_set_QuietMode(httpd_t wp);
extern int ifx_cgi_adsl_phyconfig_get_bit_allocated_per_tone(httpd_t wp);
#endif
int reboot_status = 0;
#ifdef CONFIG_FEATURE_IFX_VOIP
extern int g_nCurrentUserLevel;
#endif
unsigned short Message_web[16];
char vpivci_selected[MAX_FILELINE_LEN];
char natcpeId[MAX_FILELINE_LEN];
char natvsAction[MAX_FILELINE_LEN];
int global_log_mode;
char *status_str = NULL;

#ifdef CONFIG_FEATURE_LTQ_HNX_CONFIG
void ifx_get_hn_status(int eid, httpd_t wp, int argc, char_t ** argv);
#endif
int ifx_get_wan_mode_selected();
int ifx_get_version_info(struct ifx_version_info *);
void ifx_get_error_page(httpd_t wp, char_t * path, char_t * query);
void ifx_set_login(httpd_t wp, char_t * path, char_t * query);
void ifx_set_sysconfig_upgrade(httpd_t wp, char_t * path, char_t * query);	// system_upgrade.asp
#ifdef CONFIG_FEATURE_NAPT
void ifx_set_nat_portmap(httpd_t wp, char_t * path, char_t * query);	//nat_portmap.asp
void ifx_set_firewall_dmz(httpd_t wp, char_t * path, char_t * query);	//firewall_dmz.asp
int ifx_get_nat_portmap(int eid, httpd_t wp, int argc, char_t ** argv);	//nat_portmap.asp
int ifx_get_firewall_dmz(int eid, httpd_t wp, int argc, char_t ** argv);	//firewall_dmz.asp
#endif				//CONFIG_FEATURE_NAPT
#ifdef CONFIG_FEATURE_VLAN
int websUpdate_Vlan(int nCount, char *prefix, char *tag);
void ifx_set_vlan_bridge(httpd_t wp, char_t * path, char_t * query);
#endif				//CONFIG_FEATURE_VLAN
void ifx_set_qos_priority(httpd_t wp, char_t * path, char_t * query);	//ifx_set_qos_priority.asp
void ifx_set_qos_priority_add(httpd_t wp, char_t * path, char_t * query);	//ifx_set_qos_priority.asp
#ifdef CONFIG_FEATURE_RIP
void ifx_set_route_dynamic(httpd_t wp, char_t * path, char_t * query);	//route_dynamic.asp
int ifx_get_route_dynamic(int eid, httpd_t wp, int argc, char_t ** argv);
#endif				//CONFIG_FEATURE_RIP
#ifdef CONFIG_FEATURE_IFX_UPNP
void ifx_set_upnp_config(httpd_t wp, char_t * path, char_t * query);	//upnp_config.asp
#endif
void ifx_set_logout(httpd_t wp, char_t * path, char_t * query);
void ifx_set_adsl_vcconfig(httpd_t wp, char_t * path, char_t * query);	//adsl_vcconfig.asp
#ifdef CONFIG_FEATURE_NAPT
#ifdef CONFIG_FEATURE_ALGS
int ifx_get_algs_setting(int eid, httpd_t wp, int argc, char_t ** argv);
void ifx_set_algs_settings(httpd_t wp, char_t * path, char_t * query);
#endif				//CONFIG_FEATURE_ALGS
int ifx_get_apps_setting(int eid, httpd_t wp, int argc, char_t ** argv);
#endif				// CONFIG_FEATURE_NAPT
int ifx_get_supported_wan_cfg_mode(int eid, httpd_t wp, int argc,
				   char_t ** argv);

extern struct connection_profil_list *connlist;

#if defined(CONFIG_FEATURE_SMASH_SNMP) || defined(CONFIG_FEATURE_SNMPV1) || defined(CONFIG_FEATURE_SNMPV3)
#define IFX_HAVE_SNMP
#endif

#ifndef AMAZON_BRIDGE_DEMO
#if defined(CONFIG_PACKAGE_BR2684CTL) || defined(CONFIG_FEATURE_CLIP)
#define IFX_HAVE_WAN_STATIC_IP
#endif
#endif

int gIndexOfUS_BAT = 0;
int gIndexOfDS_BAT = 0;

char *ppp_to_ip_err =
    "<span class=\"textTitle\">Error:WAN connection configuration failed.</span><br><p>Please delete existing PPP connection and then configure IP connection</p>";
char *ip_to_ppp_err =
    "<span class=\"textTitle\">Error:WAN connection configuration failed.</span><br><p>Please delete existing IP connection and then configure PPP connection</p>";
char *pcr_chk_err =
    "<span class=\"textTitle\">Error:WAN connection configuration failed.</span><br><p>Combined PCR(Peak Cell Rate) of configured WAN Connections should not exceed Upstream Bandwidth Limit</p>";
char *vs_chk_err =
    "<span class=\"textTitle\">Error:Virtual Server entry matching the specified tuple already exists.</span><br><p>Please configure unique tuple</p>";
char *dup_route_err =
    "<span class=\"textTitle\">Error:Static Route matching the tuple already exists.</span><br><p>Please configure unique tuple</p>";
char *dup_vcc_err =
    "<span class=\"textTitle\">Error:VCC entry matching the VPI/VCI already exists.</span><br><p>Please configure unique VPI/VCI</p>";
char *sess_err =
    "<span class=\"textTitle\">Alert:Device is being configured remotely.</span><br><p>Please try again</p>";
char *q_name_err =
    "<span class=\"textTitle\">Error:Queue Configuration failed.</span><br><p>One or more Queues exist matching the Queue %s : %s. Please configure unique Queue %s for this queue</p>";
char *qcl_depend_err =
    "<span class=\"textTitle\">Error:Classifier Configuration failed.</span><br><p>Please check that the Queue configured for this Classifier is present and enabled</p>";
char *max_limit_err =
    "<span class=\"textTitle\">Error:%s Configuration failed.</span><br><p>Number of %ss allowed has reached Maximum Limit. Please delete an exising %s before adding a new %s</p>";
char *def_q_err =
    "<span class=\"textTitle\">Error:Queue Configuration failed.</span><br><p>Cannot delete/disable Default Queue. Please change the Default Queue and then try deleting/disabling this Queue</p>";
char *q_depend_err =
    "<span class=\"textTitle\">Error:Queue Configuration failed.</span><br><p>One or more %sclassifiers exist referencing this queue. Please %s them before %s this Queue.</p>";
/*char *oam_ping_res = "<span class='textTitle'>%s</span><div align='center'><table class='tableinfo' ><br><tr><td width='50%'>VPI/VCI</td><td>%d/%d</td></tr><tr><td>Cells Tx</td><td>%d</td></tr><tr><td>Cells Rx</td><td>%d</td></tr><tr><td>Cells Not Rx</td><td>%d</td></tr><tr><td>Max Resp Time</td><td>%d</td></tr><tr><td>Min Resp Time</td><td>%d</td></tr><tr><td>Avg Resp Time(millisecs)</td><td>%d</td></tr></table></div> ";*/
char *def_prio_err =
    "<span class='title'>Error:Queue Configuration failed.</p><br><p>Cannot modify the Priority of Default Queue.</p>";
char *class_name_err =
    "<p>Error:Classifier Configuration failed.</p><br><p>One or more Classifier exist matching the Classifier %s : %s. Please configure unique Classifier %s for this classifier</p>";

char qosOperation[20];
char qoscpeId[10];
MGMT_SERVER xMS;
DEVICE_INFO xDI;
TR69_MISC xtr69_misc;
int log_disp_level;
int g_op_mode;
int g_country;

void ifx_get_error_page(httpd_t wp, char_t * path, char_t * query)
{
	int ret = IFX_SUCCESS;

	COPY_TO_STATUS("%s", sess_err)
	    ifx_httpdRedirect(wp, "err_page.html");

      IFX_Handler:
	if (ret != IFX_SUCCESS)
	{ }
                return ;

}

void ifx_get_hn_status(int eid, httpd_t wp, int argc, char_t ** argv)
{
#ifdef CONFIG_FEATURE_LTQ_HNX_CONFIG
	ifx_httpdWrite(wp, T("1"));
#else
	ifx_httpdWrite(wp, T("0"));
#endif
}

int ifx_get_model_name(int eid, httpd_t wp, int argc, char_t ** arg_v)
{
	ifx_httpdWrite(wp, T("%s"), CONFIG_IFX_MODEL_NAME);
	return IFX_SUCCESS;
}

void
makeCMV_WebSet(u8 opcode, u8 group, u16 address, u16 index, int size,
	       u16 * data)
{
	memset(Message_web, 0, 16 * 2);
	Message_web[0] = (opcode << 4) + (size & 0xf);
	if (opcode == H2D_DEBUG_WRITE_DM)
		Message_web[1] = (group & 0x7f);
	else
		Message_web[1] = (((index == 0) ? 0 : 1) << 7) + (group & 0x7f);
	Message_web[2] = address;
	Message_web[3] = index;
	if ((opcode == H2D_CMV_WRITE) || (opcode == H2D_DEBUG_WRITE_DM))
		memcpy(Message_web + 4, data, size * 2);

	return;
}

void websNextPage(httpd_t wp)
{
	char_t *pNextPageUrl = ifx_httpdGetVar(wp, T("page"), T(""));	// hidden page

	if (pNextPageUrl && *pNextPageUrl)
		ifx_httpdRedirect(wp, pNextPageUrl);
	else
		ifx_httpdDone(wp, 200);
}

#ifdef CONFIG_FEATURE_QOS_PRIORITY_QUEUE
int websUpdate_QoSPriorityTable2File(int nQoSPriority_Table_Size,
				     CGI_TABLE_S * QoSPriorityTable)
{
	int nIndex = 0, nQoSPriority_Counter = 0;
	char_t sBuf[BUF_SIZE_50K];
	sBuf[0] = '\0';

	//count the table size
	for (nIndex = 0; nIndex < nQoSPriority_Table_Size; nIndex++) {
		if (QoSPriorityTable[nIndex].nIndex >= 0) {
			nQoSPriority_Counter++;
		}
	}
	sprintf(sBuf, "%sCount=\"%d\"\n", PREFIX_QOS_PRIORITY,
		nQoSPriority_Counter);
	nQoSPriority_Counter = 0;
	// update data from table to file
	for (nIndex = 0; nIndex < nQoSPriority_Table_Size; nIndex++) {
		if (QoSPriorityTable[nIndex].nIndex >= 0) {
			char_t sLine[MAX_FILELINE_LEN];
			sprintf(sLine, "%sPRIO%d=\"%d\"\n", PREFIX_QOS_PRIORITY,
				nQoSPriority_Counter,
				QoSPriorityTable[nIndex].nState);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sIP_SRC_IP%d=\"%s\"\n",
				PREFIX_QOS_PRIORITY, nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.
				sQP_IP_SRC_IP);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sIP_SRC_MASK%d=\"%s\"\n",
				PREFIX_QOS_PRIORITY, nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.
				sQP_IP_SRC_MASK);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sPORT_SRC_START%d=\"%s\"\n",
				PREFIX_QOS_PRIORITY, nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.
				sQP_PORT_SRC_START);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sPORT_SRC_END%d=\"%s\"\n",
				PREFIX_QOS_PRIORITY, nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.
				sQP_PORT_SRC_END);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sIP_DST_IP%d=\"%s\"\n",
				PREFIX_QOS_PRIORITY, nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.
				sQP_IP_DST_IP);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sIP_DST_MASK%d=\"%s\"\n",
				PREFIX_QOS_PRIORITY, nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.
				sQP_IP_DST_MASK);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sPORT_DST_START%d=\"%s\"\n",
				PREFIX_QOS_PRIORITY, nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.
				sQP_PORT_DST_START);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sPORT_DST_END%d=\"%s\"\n",
				PREFIX_QOS_PRIORITY, nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.
				sQP_PORT_DST_END);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sPROTO%d=\"%s\"\n",
				PREFIX_QOS_PRIORITY, nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.
				sQP_PROTO);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sIF%d=\"%s\"\n", PREFIX_QOS_PRIORITY,
				nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.sQP_IF);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sDIR%d=\"%s\"\n", PREFIX_QOS_PRIORITY,
				nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.sQP_DIR);
			strcat(sBuf, sLine);
			sprintf(sLine, "%sTYPE%d=\"%s\"\n", PREFIX_QOS_PRIORITY,
				nQoSPriority_Counter,
				QoSPriorityTable[nIndex].Data.QP_TABLE.
				sQP_TYPE);
			strcat(sBuf, sLine);
			nQoSPriority_Counter++;
		}
	}
	return (ifx_SetCfgData(FILE_RC_CONF, TAG_QOS_PRIORITY, 1, sBuf));
}
#endif				// CONFIG_FEATURE_QOS_PRIORITY_QUEUE

#ifdef CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE
int get_remote_hwaddr(IN char_t *ipaddr, OUT char_t *hwaddr)
{
	FILE *fp;
	char line[128];
	int num;
	int type, flags;
	char ip[128];
	char hwa[128];
	char mask[128];
	char dev[128];

	fp = fopen("/proc/net/arp", "r");
        if ( !fp )
          goto err;
	/* Bypass header -- read one line */
	fgets(line, sizeof(line), fp);

	/* Read the ARP cache entries. */
	while (fgets(line, sizeof(line), fp)) {

		mask[0] = '-'; mask[1] = '\0';
		dev[0] = '-'; dev[1] = '\0';
		/* All these strings can't overflow
		 * because fgets above reads limited amount of data */
		num = sscanf(line, "%s 0x%x 0x%x %s %s %s\n", ip, &type, &flags, hwa, mask, dev);

		if (num < 4)
			break;

		/* if the user specified address differs, skip it */
		if (ipaddr && strcmp(ip,ipaddr) != 0)
			continue;

		//printf("ARP cache IP addr : %s, MAC addr : %s\n", ip, hwa);
		strncpy(hwaddr, hwa, 31);
		fclose(fp);
		return 0;
	}

	fclose(fp);
err:
	strcpy(hwaddr, "00:00:00:00:00:00");
	return 1;
}
#endif /* CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE */

//    login.asp
void ifx_set_login(httpd_t wp, char_t * path, char_t * query)
{
#if 0
#ifndef CONFIG_LTQ_AEI_CUST
#ifdef CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE
	char_t macaddr[32];
#endif /* CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE */
#endif
#endif
	char_t *pPwdVerify = NULL, *pUsrVerify = NULL/*, sValue[8]*/,username[256], buf[MAX_FILELINE_LEN];	// = ifx_httpdGetVar(wp, T("pws"), T(""));
	int8 i,auth_flag = 0, ret = IFX_SUCCESS;
	int32 count = 0, iplan = 0, ipwan = 0;
	struct connection_profil conn;
	struct connection_profil_list *seekPtr = NULL, *conn_new = NULL;
	struct in_addr wanip_net, incomingip_net;
	WAN_CONN_CFG	*wanCfg = NULL;
	username[0]='\0';
	pPwdVerify = ifx_httpdGetVar(wp, T("pws"), T(""));
	pUsrVerify = ifx_httpdGetVar(wp, T("usr"), T(""));

	strcpy(username,pUsrVerify);

	if(inet_pton(AF_INET, wp->ipaddr, (void *)buf) > 0) {
		/* IP address is v4 family */

		if(ifx_get_all_wan(&count, &wanCfg, IFX_F_GET_ANY) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to read WAN configuration -> unable to determine HTTP is LAN or WAN access",
				__FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		/* By default, assume traffic to be LAN side */
		iplan = 1;
		ipwan = 0;

		for(i=0; i<count; i++) {
			if( ((wanCfg + i)->wancfg.ppp.conn_status == WAN_PPP_CONN_STATUS_CONNECTED && (wanCfg + i)->type == WAN_TYPE_PPP) ||
			((wanCfg + i)->wancfg.ip.conn_status == WAN_IP_CONN_STATUS_CONNECTED && (wanCfg + i)->type == WAN_TYPE_IP) ) {
				/* Calculate WAN IP subnet - using WAN interface IP and WAN interface netmask */
				wanip_net.s_addr = (wanCfg + i)->wanv4.ip_mask.ip.s_addr & (wanCfg + i)->wanv4.ip_mask.mask.s_addr;
				/* Calculate HTTP session IP subnet - using HTTP session IP and WAN interface netmask */
				incomingip_net.s_addr = inet_addr(wp->ipaddr) & (wanCfg + i)->wanv4.ip_mask.mask.s_addr;
				/* Compare the two subnets to identify if HTTP session is WAN bound or LAN bound */
				if(wanip_net.s_addr == incomingip_net.s_addr) {
					ipwan = 1;
					iplan = 0;
					break;
				}
			}
		}
		IFX_MEM_FREE(wanCfg)
	}
	else {
		/* IP address is v6 family */
		/* Assumed to be LAN always, for now */
		iplan = 1;
		ipwan = 0;
	}

#if 0
	int sess_count = 0;
	if (!nIdleTime) {
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_SYSTEM_WEB_CONFIG, "AutoLogoutTime",
		     IFX_F_GET_ANY, NULL, sValue) != IFX_SUCCESS) {
			/* If value is not found in rc.conf, then use default value */
			IFX_DBG
			    ("[%s:%d] fetching from rc.conf failed and hence idle time out is [%d]",
			     __FUNCTION__, __LINE__, nIdleTime);
			nIdleTime = MAX_WEB_IDELTIME;
		} else {
			nIdleTime = atoi(sValue);
		}
		IFX_DBG("[%s:%d] idle time out is [%d]", __FUNCTION__, __LINE__,
			nIdleTime);
	}

	if(connlist != NULL) {
		seekPtr = connlist;
		prevseekPtr = seekPtr;
		if(seekPtr != NULL && (strncmp(seekPtr->connection.ipaddr, wp.ipaddr, sizeof(seekPtr->connection.ipaddr)) == 0)) {
			/* 1st in the list is matched */
			if (now - seekPtr->connection.time < nIdleTime) {
	#ifdef IFX_LOG_DEBUG
				IFX_DBG("the same  https ip is %s allowed\n",
					seekPtr->connection.ipaddr);
	#endif
				seekPtr->connection.time = now;
				return 0;
			}
			else {
				connlist = seekPtr->next;
				IFX_MEM_FREE(seekPtr)
		    if(atoi(sValue) != 1)
				{ /* do nothing here, new login session to be created below */ }
				else
					return 0;
			}
		}
		else {
			seekPtr = connlist->next;
			prevseekPtr = connlist;
			while(seekPtr != NULL) {
				if((strncmp(seekPtr->connection.ipaddr, wp->ipaddr, sizeof(seekPtr->connection.ipaddr)) == 0)) {
					if (now - seekPtr->connection.time < nIdleTime) {
		#ifdef IFX_LOG_DEBUG
						IFX_DBG("the same  https ip is %s allowed\n",
							seekPtr->connection.ipaddr);
		#endif
						seekPtr->connection.time = now;
						return 0;
					}
					else {
						prevseekPtr->next = seekPtr->next;
						IFX_MEM_FREE(seekPtr)
				    if(atoi(sValue) != 1)
							break;
						else
							return 0;
					}
				}
				else {
					sess_count++;
				}
				prevseekPtr = seekPtr;
				seekPtr = seekPtr -> next;
			}
		}
	}

	if(sess_count >= 4) {
		ifx_httpdWrite(&wp, "Number of active sessions has reached system limit. Please try after some time.");
		return 1;
	}
#endif

#ifdef LTQ_AEI_CUST
	user_obj_t usr_obj;
		if(strcmp(wp->ipaddr, "127.0.0.1") == 0){ //WAN
			for(i=1;i<=2;i++){
				usr_obj.iid.cpeId.Id  = i;
				mapi_user_obj_details_get(&usr_obj, IFX_F_DEFAULT);
#if 0
				if(usr_obj.webAccess != 1){
					ifx_httpdRedirect(wp, "access_denied.htm");
				}
#endif
				/* Check if username and password match and user account is enabled and remote access is enabled */
				if(!strcmp(usr_obj.username,username) && !strcmp(usr_obj.password, pPwdVerify) && !strcmp(user_obj.f_enable, "1") && !strcmp(user_obj.webAccess, "1")){
					auth_flag = 1;
					break;
				}
			}
		}else{  //LAN
			usr_obj.iid.cpeId.Id  = 1;
			mapi_user_obj_details_get(&usr_obj, IFX_F_DEFAULT);
			/* Check if username and password match and user account is enabled */
			if(!strcmp(usr_obj.username, username) && !strcmp(usr_obj.password, pPwdVerify) && !strcmp(user_obj.f_enable, "1")) {
				auth_flag = 1;
			}
		}
#else
		user_obj_t *users = NULL;
		if(mapi_get_all_user_obj_details(&count, &users, IFX_F_DEFAULT) != IFX_SUCCESS) {
		
		}
		else {
			for(i=0; i<count ;i++){
				if(iplan == 1) {
					/* Check if username and password match and user account is enabled */
					if(!strcmp((users + i)->username,username) && !strcmp((users + i)->password, pPwdVerify) && (users + i)->f_enable == 1) {
						auth_flag = 1;
						break;
					}
				}
				else if(ipwan == 1) {
					/* Check if username and password match and user account is enabled and remote access is enabled */
					if(!strcmp((users + i)->username,username) && !strcmp((users + i)->password, pPwdVerify) && (users + i)->f_enable == 1 && (users + i)->webAccess == 1) {
						auth_flag = 1;
						break;
					}
				}
			}
		}
		IFX_MEM_FREE(users)
#endif

	sprintf(conn.user, "%s", username);

	if(auth_flag){
		/* TBD : all references to auto-logout code needs clarification */
		/*if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_SYSTEM_WEB_CONFIG, "AutoLogoutTime",
		     IFX_F_DEFAULT, NULL, sValue) != IFX_SUCCESS) {
			IdleTime = MAX_WEB_IDELTIME;
		} else {
			IdleTime = atoi(sValue);
		}
		*/
#if 0
#ifndef CONFIG_LTQ_AEI_CUST
		if (connection.time && gstrcmp(connection.ipaddr, wp->ipaddr) &&
		    time((time_t *) NULL) - connection.time < IdleTime) {
#ifdef CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE
			memset(macaddr, 0x00, sizeof(macaddr));
			// Get the sender mac address from ARP table
			// Compare the sender mac address
			// If not matched, then only throw Duplicate Administrator error
			if (get_remote_hwaddr(wp->ipaddr, macaddr) || strcasecmp(connection.macaddr, macaddr)) {
#endif /* CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE */
			// duplicate admin....
			ifx_httpdError(wp, 500,
				       T
				       ("<center><h1>Duplicate Administrator <br>This device is managed by %s currently!!<br></h1></center>"),
				       connection.ipaddr);

			return;
#ifdef CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE
			}
#endif /* CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE */
		}
#endif
#endif
		if(!strcmp(wp->ipaddr,"127.0.0.1"))
			memcpy(conn.ipaddr, wp->ipaddr,sizeof(conn.ipaddr) - 1);
		else
			memcpy(conn.ipaddr, wp->ipaddr,sizeof(conn.ipaddr) - 1);
#if 0
#ifndef CONFIG_LTQ_AEI_CUST
#ifdef CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE
		memset(macaddr, 0x00, sizeof(macaddr));
		// Get the sender mac address from ARP table
		// Update the sender MAC address to connection profile
		if (!get_remote_hwaddr(connection.ipaddr, macaddr)) {
			memcpy(connection.macaddr, macaddr, sizeof(connection.macaddr) - 1);
		}
#endif /* CONFIG_FEATURE_MAC_BASED_WEB_SESSION_HANDLE */
#endif
#endif
		conn.time = time(NULL);
		IFX_MEM_ALLOC(conn_new, struct connection_profil_list *, 1, sizeof(struct connection_profil_list))
		memcpy(&conn_new->connection, &conn, sizeof(conn));
		conn_new->next = NULL;
		seekPtr = connlist;
		if(seekPtr != NULL) {
			while(seekPtr->next != NULL)
				seekPtr = seekPtr->next;
			seekPtr->next = conn_new;
		}
		else {
			connlist = conn_new;
		}
#ifdef CONFIG_FEATURE_IFX_VOIP
		g_nCurrentUserLevel = 0;
#endif
		websNextPage(wp);
	} else {
		ifx_httpdRedirect(wp, "loginerr.htm");
	}
IFX_Handler:
	return;
}

#ifdef SIP_QOS
//sumedh start (SIP)
int websUpdate_Sip2File(int nSipTable_size, CGI_TABLE_S * SipTable)
{
	int nIndex = 0, nSip_Counter = 0;
	char_t sBuf[BUF_SIZE_50K];
	memset(sBuf, 0, sizeof(sBuf));

	//count the table size
	for (nIndex = 0; nIndex < nSipTable_size; nIndex++) {
		if (SipTable[nIndex].nIndex >= 0) {
			nSip_Counter++;
		}
	}

	gsprintf(sBuf, T("%sCount=\"%d\"\n"), PREFIX_SIP, nSip_Counter);

	nSip_Counter = 0;
	// update data from table to file
	for (nIndex = 0; nIndex < nSipTable_size; nIndex++) {
		if (SipTable[nIndex].nIndex >= 0) {
			char_t sLine[MAX_FILELINE_LEN];

			gsprintf(sLine, T("%sE%d=\"%d\"\n"), PREFIX_SIP,
				 nSip_Counter, SipTable[nIndex].nState);
			gstrcat(sBuf, sLine);

			gsprintf(sLine, T("%sPROTOCOL%d=\"%s\"\n"), PREFIX_SIP,
				 nSip_Counter,
				 SipTable[nIndex].Data.SIP_TABLE.sSIP_PROTOCOL);
			gstrcat(sBuf, sLine);

			gsprintf(sLine, T("%sPORT%d=\"%s\"\n"), PREFIX_SIP,
				 nSip_Counter,
				 SipTable[nIndex].Data.SIP_TABLE.sSIP_PORT);
			gstrcat(sBuf, sLine);

			gsprintf(sLine, T("%sPHONE_IP%d=\"%s\"\n"), PREFIX_SIP,
				 nSip_Counter,
				 SipTable[nIndex].Data.SIP_TABLE.sSIP_PHONE_IP);
			gstrcat(sBuf, sLine);

			nSip_Counter++;
		}
	}
	return (ifx_SetCfgData(FILE_RC_CONF, TAG_SIP_INFO, 1, sBuf));
}

//              PAGE : sip_qos.asp
void ifx_set_sip_qos(httpd_t wp, char_t * path, char_t * query)
{
	char_t buf[MAX_DATA_LEN], sSipStatus[MAX_DATA_LEN];
	CGI_TABLE_S SipTable[SIP_TABLE_NUM];
	char_t *pCheck, *pSipStatus, *pMaxbw, *pMinbw;
	char_t sMaxbw[MAX_WEB_DATA], sMinbw[MAX_WEB_DATA];
	char_t *pDel = ifx_httpdGetVar(wp, T("delflag"), T(""));
	int nIndex, nSipTable_size = 0;

	a_assert(wp);

	buf[0] = '\0';

	nSipTable_size =
	    websGetCfgData2Table(wp, FILE_RC_CONF, TAG_SIP_INFO, PREFIX_SIP,
				 SipTable, SIP_TABLE_TYPE);
	// Get original data form file
	if (nSipTable_size == -1) {
		ifx_httpdError(wp, 500, "Insufficient data for Sip table");
		return;
	}
	// Get Enable checkbox status & Update SipTable
	for (nIndex = 0; nIndex < nSipTable_size; nIndex++) {
		gsprintf(buf, "SIP_E%d", nIndex);
		pCheck = ifx_httpdGetVar(wp, buf, T(""));

		if (!gstrcmp(pCheck, "1"))
			SipTable[nIndex].nState = 1;
		else
			SipTable[nIndex].nState = 0;
	}

	// Submit data form press delete button
	if (!gstrcmp(pDel, T("1"))) {
		char_t *pDelIndex = ifx_httpdGetVar(wp, T("delindex"), T(""));
		int nDelIndex = gatoi(pDelIndex);
		trace(8, "Del table\n");
		// Remove DelIndex form Table
		for (nIndex = nDelIndex + 1; nIndex < nSipTable_size; nIndex++) {
			SipTable[nIndex].nIndex--;
		}
		SipTable[nDelIndex].nIndex = -1;
	}
	////////// Update Table to File ///////////////
	websUpdate_Sip2File(nSipTable_size, SipTable);

	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}

	sSipStatus[0] = '\0';
	pSipStatus = ifx_httpdGetVar(wp, T("SIP_STATUS"), T(""));

	if (!gstrcmp(pSipStatus, T("1"))) {
		gsprintf(sSipStatus, T("SIP_STATUS=\"1\"\n"));
	} else {
		gsprintf(sSipStatus, T("SIP_STATUS=\"0\"\n"));
	}

	sMaxbw[0] = '\0';
	pMaxbw = ifx_httpdGetVar(wp, T("SIP_MAXBW"), T(""));	// Get value from ASP file
	gsprintf(sMaxbw, T("SIP_MAXBW=\"%s\"\n"), pMaxbw);

	sMinbw[0] = '\0';
	pMinbw = ifx_httpdGetVar(wp, T("SIP_MINBW"), T(""));	// Get value from ASP file
	gsprintf(sMinbw, T("SIP_MINBW=\"%s\"\n"), pMinbw);

	ifx_SetCfgData(FILE_RC_CONF, TAG_SIP_MAIN, 3, sSipStatus, sMaxbw,
		       sMinbw);
	system(SERVICE_QOS_RESTART);

	websNextPage(wp);
}

//              PAGE : policy_routing_add.asp
void ifx_set_sip_add(httpd_t wp, char_t * path, char_t * query)
{
	CGI_TABLE_S SipTable[SIP_TABLE_NUM];
	int nSipTable_size = 0;
	char_t *pSIP_E = ifx_httpdGetVar(wp, T("SIP_ADD"), T(""));
	char_t *pSIP_PROTOCOL = ifx_httpdGetVar(wp, T("SIP_PROTOCOL"), T(""));
	char_t *pSIP_PORT = ifx_httpdGetVar(wp, T("SIP_PORT"), T(""));
	char_t *pSIP_PHONE_IP = ifx_httpdGetVar(wp, T("SIP_PHONE_IP"), T(""));

	nSipTable_size =
	    websGetCfgData2Table(wp, FILE_RC_CONF, TAG_SIP_INFO, PREFIX_SIP,
				 SipTable, SIP_TABLE_TYPE);
	if (nSipTable_size >= SIP_TABLE_NUM) {
		ifx_httpdError(wp, 500, T("Out of space to add Sip entry"));
		return;
	}
	// copy data to Sip Table
	memset(&SipTable[nSipTable_size], 0x00, sizeof(CGI_TABLE_S));
	SipTable[nSipTable_size].nIndex =
	    SipTable[nSipTable_size - 1].nIndex + 1;
	if (!gstrcmp(pSIP_E, "1")) {
		SipTable[nSipTable_size].nState = 1;
	} else {
		SipTable[nSipTable_size].nState = 0;
	}

	// copy protocol
	if (!pSIP_PROTOCOL[0])
		gsprintf(SipTable[nSipTable_size].Data.SIP_TABLE.sSIP_PROTOCOL,
			 "*");
	else
		gstrcpy(SipTable[nSipTable_size].Data.SIP_TABLE.sSIP_PROTOCOL,
			pSIP_PROTOCOL);

	// copy port
	if (!pSIP_PORT[0])
		gsprintf(SipTable[nSipTable_size].Data.SIP_TABLE.sSIP_PORT,
			 "*");
	else
		gstrcpy(SipTable[nSipTable_size].Data.SIP_TABLE.sSIP_PORT,
			pSIP_PORT);

	// copy phone ip
	if (strlen(pSIP_PHONE_IP)) {
		gstrcpy(SipTable[nSipTable_size].Data.SIP_TABLE.sSIP_PHONE_IP,
			pSIP_PHONE_IP);
	} else {
		gsprintf(SipTable[nSipTable_size].Data.SIP_TABLE.sSIP_PHONE_IP,
			 "*");
	}

	nSipTable_size++;

	////////// Update Table to File ///////////////
	websUpdate_Sip2File(nSipTable_size, SipTable);

	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}
	websNextPage(wp);
}

//sumedh - SIP ends
#endif
// lan_dhcps.asp; lan_nodhcp.asp
void ifx_set_lan_dynamic(httpd_t wp, char_t * path, char_t * query)
{
	int32 ret = IFX_SUCCESS, count = 0, op = 0;
	uint32 flags = IFX_F_DEFAULT;
	char8 *operation = NULL;
	IP_MASK_TYPE *ip_mask_type = NULL;

	operation = ifx_httpdGetVar(wp, T("operation"), T(""));

	ret = ifx_get_lan_ip_mask("br0", &count, &ip_mask_type, flags);

	if ((ret == IFX_SUCCESS) && (ip_mask_type != NULL)) {
		/* here we assume that we have only one lan interface, so use the first one in the array for configuration */
		ip_mask_type->iid.cpeId.Id = 1;
		ip_mask_type->iid.pcpeId.Id = 1;
		ip_mask_type->ip_type = IP_TYPE_DHCP;
		ip_mask_type->f_enable = IFX_ENABLED;
		ip_mask_type->iid.config_owner = IFX_WEB;
	}

	if (!gstrcmp(operation, "release"))
		op = IFX_OP_DHCP_RELEASE;
	else if (!gstrcmp(operation, "renew"))
		op = IFX_OP_DHCP_RENEW;
	if (ip_mask_type)
		ret =
		    ifx_set_lan_ip_mask(op, 0, "br0", ip_mask_type,
					IFX_F_DEFAULT);
	else
		goto IFX_Handler;
	if (ret != IFX_SUCCESS) {
		ifx_httpdError(wp, 500,
			       "Failed to save lan device configuration !!");
		goto IFX_Handler;
	}

      IFX_Handler:
	IFX_MEM_FREE(ip_mask_type)
	    websNextPage(wp);
}

#ifdef CONFIG_FEATURE_NAPT
// nat_main.asp
#ifdef NAT_PORTMAP
void ifx_set_nat_portmap(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pCloneIP, *pClonePort, *pCloneEnable, *buffer;
	char_t sServerIP[MAX_DATA_LEN], buf[MAX_FILELINE_LEN];
	char_t sCloneIP[NAT_VS_LINK_NUM][MAX_FILELINE_LEN],
	    sClonePort[NAT_VS_LINK_NUM][MAX_FILELINE_LEN];
	char_t sCloneEnable[NAT_VS_LINK_NUM][MAX_FILELINE_LEN];
	char_t sSerialPort[NAT_VS_CLONE_NUM][MAX_DATA_LEN],
	    sPortsNum[NAT_VS_LINK_NUM][MAX_DATA_LEN];
	int i, idx, nRetNum[NAT_VS_LINK_NUM];
	ST_NAT_PORT_MAP_LIST stPortList[NAT_VS_CLONE_NUM];
	char_t sCommand[MAX_DATA_LEN];

	a_assert(wp);

	for (i = 0; i < NAT_VS_LINK_NUM; i++) {
		//Set CLONE_IP# to rc.iptables.
		memset(sCloneIP[i], 0x00, sizeof(sCloneIP[i]));

		gsprintf(buf, T("CLONE_IP%d"), i + 1);
		pCloneIP = ifx_httpdGetVar(wp, buf, T(""));

		if (pCloneIP[0]) {
			sServerIP[0] = '\0';
			websGetIFInfo(LAN_IF_TYPE, IP_INFO, 1, 3, FALSE, NULL,
				      sServerIP);
			gsprintf(sCloneIP[i], T("%s=\"%s%s\"\n"), buf,
				 sServerIP, pCloneIP);
		} else {
			gsprintf(sCloneIP[i], T("%s=\"\"\n"), buf);
		}
		trace(8, T("%s\n"), sCloneIP[i]);

		//Set CLONE_PORTS# to rc.iptables.
		memset(sClonePort[i], 0x00, sizeof(sClonePort[i]));
		gsprintf(buf, T("CLONE_PORTS%d"), i + 1);
		pClonePort = ifx_httpdGetVar(wp, buf, T(""));

		if (pClonePort[0]) {
			gsprintf(sClonePort[i], T("%s=\"%s\"\n"), buf,
				 pClonePort);
		} else {
			gsprintf(sClonePort[i], T("%s=\"0\"\n"), buf);
		}
		trace(8, T("%s\n"), sClonePort[i]);

		//Set CLONE_ENABLE# to rc.iptables.
		memset(sCloneEnable[i], 0x00, sizeof(sCloneEnable[i]));

		gsprintf(buf, T("CLONE_ENABLE%d"), i + 1);
		pCloneEnable = ifx_httpdGetVar(wp, buf, T(""));

		if (!gstrcmp(pCloneEnable, "1")) {
			if ((pCloneIP && *pCloneIP)
			    && (pClonePort && *pClonePort)) {
				gsprintf(sCloneEnable[i], T("%s=\"%s\"\n"), buf,
					 pCloneEnable);
			} else {
				gsprintf(sCloneEnable[i], T("%s=\"0\"\n"), buf);
			}
		} else {
			gsprintf(sCloneEnable[i], T("%s=\"0\"\n"), buf);
		}
		trace(8, T("%s\n"), sCloneEnable[i]);
	}

	buffer = (char_t *) malloc(sizeof(char_t) * (BUF_SIZE_50K));
	gstrcpy(buffer, "");
	gsprintf(buf, T("CLONE_NUM=\"%d\"\n"), NAT_VS_LINK_NUM);
	gstrcat(buffer, buf);

	for (i = 0; i < NAT_VS_LINK_NUM; i++) {
		gstrcat(buffer, sCloneIP[i]);
		gstrcat(buffer, sClonePort[i]);

		//Set CLONE_PORTS#_NUM to rc.iptables.
		for (idx = 0; idx < NAT_VS_CLONE_NUM; idx++) {
			stPortList[idx].nRangeIdx = 0;
			memset(stPortList[idx].sRetValue, 0x00,
			       sizeof(stPortList[idx].sRetValue));
		}

		nRetNum[i] = -1;
		gsprintf(buf, T("CLONE_PORTS%d"), i + 1);
		pClonePort = ifx_httpdGetVar(wp, buf, T(""));

		nRetNum[i] = websGetPortNums(pClonePort, stPortList);
		memset(sPortsNum[i], 0x00, sizeof(sPortsNum[i]));

		if (nRetNum[i] == -1) {
			gsprintf(sPortsNum[i], T("CLONE_PORTS%d_NUM=\"0\"\n"),
				 i + 1);
			gstrcat(buffer, sPortsNum[i]);
		} else if (nRetNum[i] == -2) {
			gsprintf(sPortsNum[i], T("CLONE_PORTS%d_NUM=\"0\"\n"),
				 i + 1);
			gstrcat(buffer, sPortsNum[i]);
		} else if (nRetNum[i] > 0) {
			gsprintf(sPortsNum[i], T("CLONE_PORTS%d_NUM=\"%d\"\n"),
				 i + 1, nRetNum[i]);
			gstrcat(buffer, sPortsNum[i]);

			for (idx = 0; idx < NAT_VS_CLONE_NUM; idx++) {
				memset(sSerialPort[idx], 0x00,
				       sizeof(sSerialPort[idx]));
			}

			for (idx = 0; idx < nRetNum[i]; idx++) {
				gsprintf(sSerialPort[idx],
					 T("CLONE_PORTS%d_%d=\"%s\"\n"), i + 1,
					 idx + 1, stPortList[idx].sRetValue);
				gstrcat(buffer, sSerialPort[idx]);
			}
		}

		gstrcat(buffer, sCloneEnable[i]);
	}

	trace(8, "buffer=%sEND\n", buffer);
	ifx_SetCfgData(FILE_RC_CONF, TAG_NAT_PORTMAP, 1, buffer);

	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}
#if 1
	IFX_MEM_FREE(buffer);
#endif
	//Runtime Change
	sprintf(sCommand, "%s --PMinit", NAPTCFG);
	if (sCommand) {
		system(sCommand);
	}

	websNextPage(wp);
}
#endif
#endif				//CONFIG_FEATURE_NAPT

#ifdef CONFIG_FEATURE_VLAN
void ifx_set_vlan_bridge(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pAction = ifx_httpdGetVar(wp, T("submit_action"), T(""));
	char_t *pTmp = NULL;
	char_t *sValue = (char_t *) malloc(sizeof(char_t) * BUF_SIZE_50K);
	char_t *sChildName = (char_t *) malloc(sizeof(char_t) * MAX_DATA_LEN);
	char_t *sChildValue = (char_t *) malloc(sizeof(char_t) * MAX_DATA_LEN);
	char_t *sCommand = (char_t *) malloc(sizeof(char_t) * MAX_DATA_LEN);
	int groups = 0, i = 0;

	sValue[0] = '\0';
	sChildName[0] = '\0';
	sChildValue[0] = '\0';
	sCommand[0] = '\0';
	if (!strcmp(pAction, "vbEnable")) {
		pTmp = ifx_httpdGetVar(wp, T("submit_value"), T(""));
		if (!strcmp(pTmp, "1")) {
			sprintf(sValue, "vb_enable=\"1\"\n");
			ifx_SetCfgData(FILE_RC_CONF, TAG_VLAN_BRIDGE, 1,
				       sValue);
		} else {
			sprintf(sValue, "vb_enable=\"0\"\n");
			ifx_SetCfgData(FILE_RC_CONF, TAG_VLAN_BRIDGE, 1,
				       sValue);
		}
	} else if (!strcmp(pAction, "vbPbvgs_add")) {
		pTmp = ifx_httpdGetVar(wp, T("vb_pbvgs_groups"), T("ERROR"));
		groups = atoi(pTmp) + 1;
		sprintf(sValue, T("vb_pbvgs_groups=%d\n"), groups);
		for (i = 1; i <= groups; i++) {
			sChildName[0] = '\0';
			sprintf(sChildName, "vb_pbvgs_groups_%d", i);
			if (i != groups)
				pTmp =
				    ifx_httpdGetVar(wp, sChildName, T("ERROR"));
			else
				pTmp =
				    ifx_httpdGetVar(wp, T("submit_value"),
						    T("ERROR"));
			sChildValue[0] = '\0';
			sprintf(sChildValue, T("%s=%s\n"), sChildName, pTmp);
			strcat(sValue, sChildValue);
		}
		ifx_SetCfgData(FILE_RC_CONF, TAG_VLAN_BRIDGE_PB, 1, sValue);
	} else if (!strcmp(pAction, "vbPbvgs_chg")) {
		pTmp = ifx_httpdGetVar(wp, T("vb_pbvgs_groups"), T("ERROR"));
		groups = atoi(pTmp);
		sprintf(sValue, T("vb_pbvgs_groups=%s\n"), pTmp);
		for (i = 1; i <= groups; i++) {
			sChildName[0] = '\0';
			sprintf(sChildName, "vb_pbvgs_groups_%d", i);
			pTmp = ifx_httpdGetVar(wp, sChildName, T("ERROR"));
			sChildValue[0] = '\0';
			sprintf(sChildValue, T("%s=%s\n"), sChildName, pTmp);
			strcat(sValue, sChildValue);
		}
		ifx_SetCfgData(FILE_RC_CONF, TAG_VLAN_BRIDGE_PB, 1, sValue);
	} else if (!gstrcmp(pAction, "vbPbvgs_del")) {
		pTmp = ifx_httpdGetVar(wp, T("vb_pbvgs_groups"), T("ERROR"));
		groups = atoi(pTmp);
		sprintf(sValue, T("vb_pbvgs_groups=%d\n"), groups - 1);
		for (i = 1; i < groups; i++) {
			sChildName[0] = '\0';
			sprintf(sChildName, "vb_pbvgs_groups_%d", i);
			pTmp = ifx_httpdGetVar(wp, sChildName, T("ERROR"));
			sChildValue[0] = '\0';
			sprintf(sChildValue, T("%s=%s\n"), sChildName, pTmp);
			strcat(sValue, sChildValue);
		}
		ifx_SetCfgData(FILE_RC_CONF, TAG_VLAN_BRIDGE_PB, 1, sValue);
	} else
		goto exit;
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}
	system(SERVICE_VLAN_RESTART);	/* 509024:linmars */

      exit:
	IFX_MEM_FREE(sValue);
	IFX_MEM_FREE(sChildName);
	IFX_MEM_FREE(sChildValue);
	IFX_MEM_FREE(sCommand);
	websNextPage(wp);
	return;
}

int vlanWidx = 0;
CGI_TABLE_S VlanTable[APPS_NUM_OF_ETHFTR_ENTRY];

int ifx_set_vlan_membership(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pvlanWidx = NULL;
	char_t sTmpstr[4];
	char_t prefix[PREFIX_AND_TAG_LEN], tag[PREFIX_AND_TAG_LEN];

	pvlanWidx = ifx_httpdGetVar(wp, T("vlanWidx"), T(""));
	gsprintf(sTmpstr, T("%s"), pvlanWidx);
	vlanWidx = atoi(sTmpstr);

	if (vlanWidx > 0) {

		char_t *pAdd = ifx_httpdGetVar(wp, T("hostAdd1"), T(""));
		char_t *pDel = ifx_httpdGetVar(wp, T("delflag"), T(""));
		int nIndex = 0, nCurNum = 0;

		gsprintf(prefix, T("VM_intf%d_"), vlanWidx);
		gsprintf(tag, T("intf%d_vlan_membership"), vlanWidx);

		for (nCurNum = 0; nCurNum < APPS_NUM_OF_ETHFTR_ENTRY; nCurNum++) {
			VlanTable[nCurNum].nIndex = 0;
			memset(VlanTable[nCurNum].Data.sValue, 0x00,
			       sizeof(VlanTable[nCurNum].Data.sValue));
		}
		nCurNum = 0;
		nCurNum =
		    websGetCfgData2Table(wp, FILE_RC_CONF, tag, prefix,
					 VlanTable, VLAN_TABLE_TYPE);
		if (pAdd[0]) {
			char_t *pA1 =
			    ifx_httpdGetVar(wp, T("VLANIDADD"), T(""));
			char_t *pA2 =
			    ifx_httpdGetVar(wp, T("TAGUNTAGADD"), T(""));
			char_t sA1[5];
			uint nState = 0;

			gsprintf(sA1, T("%s"), pA1);
			nState = atoi(pA2);
			// Update table and system
			for (nIndex = 0; nIndex <= nCurNum; nIndex++) {
				if (gstrncmp
				    (VlanTable[nIndex].Data.sValue, sA1,
				     sizeof(sA1)) == 0) {
					ifx_httpdError(wp, 500,
						       "Duplicate VLAN ID for same port");
					return -1;
				}

				if (VlanTable[nIndex].nIndex == 0
				    && !VlanTable[nIndex].Data.sValue[0]) {
					VlanTable[nIndex].nIndex = nIndex;
					VlanTable[nIndex].nState = nState;
					gstrcpy(VlanTable[nIndex].Data.sValue,
						sA1);

					nCurNum = nIndex + 1;
					break;
				}
			}

			// No more space to add data
			if (nIndex > APPS_NUM_OF_ETHFTR_ENTRY) {

				ifx_httpdError(wp, 500,
					       T("Out of space to add"));
				return -1;
			}
			////////// Update Table to File ///////////////
			websUpdate_Vlan(nCurNum, prefix, tag);
		}
// Submit data form press delete button
		if (!gstrcmp(pDel, T("1"))) {
			char_t *pDelIndex =
			    ifx_httpdGetVar(wp, T("delindex"), T(""));
			int nDelIndex = gatoi(pDelIndex);

			// Remove DelIndex form Table
			for (nIndex = 0; nIndex < nCurNum; nIndex++) {
				if (nIndex >= nDelIndex) {
					VlanTable[nIndex].nIndex =
					    VlanTable[nIndex + 1].nIndex;
					VlanTable[nIndex].nState =
					    VlanTable[nIndex + 1].nState;
					gstrcpy(VlanTable[nIndex].Data.sValue,
						VlanTable[nIndex +
							  1].Data.sValue);
				}
			}

			////////// Update Table to File ///////////////
			websUpdate_Vlan(nCurNum - 1, prefix, tag);
		}
		// save setting
		if (pAdd[0] || !gstrcmp(pDel, T("1"))) {
			char command[128];
			if (ifx_flash_write() <= 0) {
				ifx_httpdError(wp, 500, "Fail to save Setting");
				return -1;
			}
			sprintf(command, "%s %d", SERVICE_VLAN_RESTART,
				vlanWidx);
			system(command);
		}
	}
	websNextPage(wp);
	return 0;
}
int websUpdate_Vlan(int nCount, char *prefix, char *tag)
{
	char_t sBuf[BUF_SIZE_1K];
	int nIndex = 0;
	sBuf[0] = '\0';

	gsprintf(sBuf, T("%sCount=\"%d\"\n"), prefix, nCount);

	for (nIndex = 0; nIndex < nCount; nIndex++) {
		char_t sLine[MAX_FILELINE_LEN];
		// Print following strings
		gsprintf(sLine, T("%sTAG%d=\"%d\"\n%sID%d=\"%s\"\n"), prefix,
			 nIndex, VlanTable[nIndex].nState, prefix, nIndex,
			 VlanTable[nIndex].Data.sValue);

		gstrcat(sBuf, sLine);
	}

	return (ifx_SetCfgData(FILE_RC_CONF, tag, 1, sBuf));
}

#endif				//CONFIG_FEATURE_VLAN

#ifdef CONFIG_FEATURE_RIP
// route_dynamic.asp
void ifx_set_route_dynamic(httpd_t wp, char_t * path, char_t * query)
{
	RIP_CFG rip;
	int ret = 0;
	char_t *pWkMode, *pWkMode6, *pRtListenMode, *pRtSupplyMode;
	int flags = IFX_F_DEFAULT;

	memset(&rip, 0x00, sizeof(rip));
	rip.iid.cpeId.Id = 1;
	rip.iid.pcpeId.Id = 1;

	pWkMode = ifx_httpdGetVar(wp, T("wkMode"), T(""));
	if (!gstrcmp(pWkMode, "1"))	//Enable
		rip.f_enable = IFX_ENABLED;
	else if (!gstrcmp(pWkMode, "0"))
		rip.f_enable = IFX_DISABLED;

	pWkMode6 = ifx_httpdGetVar(wp, T("wkMode6"), T(""));
	if (!gstrcmp(pWkMode6, "1"))	//Enable
		rip.fv6_enable = IFX_ENABLED;
	else if (!gstrcmp(pWkMode6, "0"))
		rip.fv6_enable = IFX_DISABLED;

	pRtSupplyMode = ifx_httpdGetVar(wp, T("RtSupplyMode"), T(""));
	rip.supply_mode = gatoi(pRtSupplyMode);

	pRtListenMode = ifx_httpdGetVar(wp, T("RtListenMode"), T(""));
	rip.listen_mode = gatoi(pRtListenMode);

	snprintf(rip.iid.cpeId.secName, strlen(TAG_ROUTE_DYNAMIC) + 1, "%s",
		 TAG_ROUTE_DYNAMIC);

	rip.iid.config_owner = IFX_WEB;
	ret = ifx_set_rip(&rip, flags | IFX_F_MODIFY);
	if (ret != IFX_SUCCESS) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
	}
	websNextPage(wp);
}
#endif				//CONFIG_FEATURE_RIP

#ifdef CONFIG_FEATURE_IFX_UPNP
// upnp_config.asp
void ifx_set_upnp_config(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pStatus = ifx_httpdGetVar(wp, T("UpnpStatus"), T(""));
	char_t sStatus[MAX_DATA_LEN];
	char_t sCommand[MAX_DATA_LEN] = "";
	char_t sWanIface[MAX_DATA_LEN];
	char_t sLanIface[MAX_DATA_LEN];

	a_assert(wp);
	sStatus[0] = '\0';
	GetLanIface(1, sLanIface);

	memset(sStatus, 0x00, MAX_DATA_LEN);
	memset(sCommand, 0x00, MAX_DATA_LEN);
	memset(sWanIface, 0x00, MAX_DATA_LEN);
	memset(sLanIface, 0x00, MAX_DATA_LEN);

	if (!gstrcmp(pStatus, "1")) {
		gsprintf(sStatus, T("upnp_enable=\"YES\"\n"));
		GetWanIface(0, sWanIface);

		gsprintf(sCommand,
			 T("route add -net 239.0.0.0 netmask 255.0.0.0 %s"),
			 sLanIface);
		system(sCommand);

		snprintf(sCommand, sizeof(sCommand), T("%s %s %s&"),
			 SERVICE_UPNPD_START, sWanIface, sLanIface);
		system(SERVICE_UPNPD_STOP);
		system(sCommand);
	} else {
		gsprintf(sStatus, T("upnp_enable=\"NO\"\n"));
		gsprintf(sCommand,
			 T("route del -net 239.0.0.0 netmask 255.0.0.0"));
		system(sCommand);
		system(SERVICE_UPNPD_STOP);
	}

	ifx_SetCfgData(FILE_RC_CONF, TAG_UPNPCONFIG, 1, sStatus);
	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}

	websNextPage(wp);
}
#endif

void ifx_set_logout(httpd_t wp, char_t * path, char_t * query)
{
	struct connection_profil_list *seekPtr = NULL, *prevseekPtr = NULL;
#ifdef CONFIG_FEATURE_IFX_VOIP
	g_nCurrentUserLevel = 0;
#endif
	if(connlist != NULL) {
		seekPtr = connlist;
		prevseekPtr = seekPtr;
	
		/* 1st in the session list is matched */
		if(seekPtr != NULL && (strncmp(seekPtr->connection.ipaddr, wp->ipaddr, sizeof(seekPtr->connection.ipaddr)) == 0)) {
			connlist = seekPtr->next;
			IFX_MEM_FREE(seekPtr)
		}
		else {
			/* otherwise */
			seekPtr = connlist->next;
			prevseekPtr = connlist;
			while(seekPtr != NULL) {
				if((strncmp(seekPtr->connection.ipaddr, wp->ipaddr, sizeof(seekPtr->connection.ipaddr)) == 0)) {
					prevseekPtr->next = seekPtr->next;
					IFX_MEM_FREE(seekPtr)
					break;
				}
				prevseekPtr = seekPtr;
				seekPtr = seekPtr->next;
			}
		}
	}

	ifx_httpdRedirect(wp, T("login.asp"));
}

/* This function takes the input vcchannel (vpi/vci) and checks if there are any active wan
 * connections configured on this vcchannel it returns IFX_FAILURE otherwise IFX_SUCCESS */
int ifx_get_wan_vcc_state(char *vcChannel)
{
	uint32 flags = IFX_F_GET_ANY, outFlag = IFX_F_DEFAULT, ret = 0, idx_count =0 ,i=0;
	char8 sBuf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN], l2ifname[MAX_FILELINE_LEN];
	char8 *retVal = NULL;

	/* Get substring relevant to vcChannel passed to this function  */
	if  ((ret=(ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_ADSL_VCCHANNEL,"vcc", vcChannel ,&retVal))) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
                 IFX_DBG("\n\n In FUnction [%s] : Error--> Trying to get the wan index for vcc [%s] !!\n\n",__FUNCTION__,vcChannel);
		#endif
		IFX_MEM_FREE(retVal)	
	         return IFX_FAILURE;
        }


	/* get the l2ifname of that particular instance */
	sprintf(sBuf,"%s_l2ifName",retVal);
	if (ifx_GetObjData(FILE_RC_CONF, TAG_ADSL_VCCHANNEL,sBuf, flags, (IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
                IFX_DBG("\n\n In FUnction [%s] : Error--> Trying to get the wan index for vcc [%s] !!\n\n",__FUNCTION__,vcChannel);
	        #endif
		IFX_MEM_FREE(retVal)	
		return IFX_FAILURE;
	}
	snprintf(l2ifname, sizeof(l2ifname),"%s",sValue);

	/*check if any wan on l2ifname of the vpivci */
	if  ((ret=(ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_PPP,"l2ifName", l2ifname ,&retVal))) == IFX_SUCCESS)
        {
                #ifdef IFX_LOG_DEBUG
                 IFX_DBG("\n\n In FUnction [%s] : Error--> Trying to delete vcc with ppp wan over it [%s] !!\n\n",__FUNCTION__,vcChannel);
                #endif
		IFX_MEM_FREE(retVal)	
                 return IFX_FAILURE;
        }
	if  ((ret=(ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_IP,"l2ifName", l2ifname ,&retVal))) == IFX_SUCCESS)
        {
                #ifdef IFX_LOG_DEBUG
                 IFX_DBG("\n\n In FUnction [%s] : Error--> Trying to delete vcc with ip wan over it [%s] !!\n\n",__FUNCTION__,vcChannel);
                #endif
		IFX_MEM_FREE(retVal)	
                 return IFX_FAILURE;
	}

	if (ifx_GetObjData(FILE_RC_CONF,TAG_VLAN_CFG,"vlan_ch_cfg_Count", flags, (IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS)
        {
		#ifdef IFX_LOG_DEBUG
                IFX_DBG("\n\n In FUnction [%s] : Error--> Trying to get the vlan count and  vcc [%s] ret val [%s] !!\n\n",__FUNCTION__,vcChannel, sValue);
		#endif
                return IFX_FAILURE;
        }
	idx_count = atoi(sValue);

	for(i=0;i<idx_count;i++)
	{

		sprintf(sBuf,"vlanch_%d_baseIf",i);
                if (ifx_GetObjData(FILE_RC_CONF,TAG_VLAN_CFG,sBuf, flags, (IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS)
                {
                        #ifdef IFX_LOG_DEBUG
			   IFX_DBG("\n\n In FUnction [%s] : Error--> Trying to get the baseif for vcc [%s}  and  [%s] !!\n\n",__FUNCTION__,vcChannel, sValue);
                           return IFX_FAILURE;
			#endif
                }
		if (strstr(sValue,"nas") != NULL )
		{
			sprintf(sBuf,"vlanch_%d_vlanId",i);
			if (ifx_GetObjData(FILE_RC_CONF,TAG_VLAN_CFG,sBuf, flags, (IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS)
	       		{
				#ifdef IFX_LOG_DEBUG
	                        IFX_DBG("\n\n In FUnction [%s] : Error--> Trying to get the vlanid for vcc [%s] ret val [%s] !!\n\n",__FUNCTION__,vcChannel, sValue);
        			return IFX_FAILURE;
				#endif
        		}

		 	/*Check if there is a vlan channel instance configured on l2ifname has a vlanid */
			if(atoi(sValue) != -1 )
			{
        		  	#ifdef IFX_LOG_DEBUG
				IFX_DBG("\n\n In FUnction [%s] : deleting atm channel [%s] which has VLAN ID on top of it ..vlanid value [%s]!!\n\n",__FUNCTION__,vcChannel, sValue);
				#endif
			 	return IFX_FAILURE;
			}
		}
	}
	IFX_MEM_FREE(retVal)	
	return IFX_SUCCESS;
}

/////////////////////////////////////////////////////////////////////////////////
//websGetCfgData2Table(...)
//    ex1. File Name ==>    if ( websGetCfgData(FILE_RC_CONF, TAG_DHCP_BINPOND, "Server", sValue) == 1)
//    ex2. Pipe       ==>    if ( websGetCfgData(&command, NULL, "1", sValue) == 1 )
//    Variable Name    ==>    File Name        ;    Pipe Command
//-------------------------------------------------------------------------------
//    pFileName        ==>    Open File Name    ;    Open pipe command
//    pTag            ==>    TAG_xxx            ;    NULL
//    pData            ==>    Search Name        ;    which Line obtained
//    pRetValue        ==>    Return string.    ;    Return string.
//
//    Return Value :    0 is FALSE. 1 is TRUE
//

int websGetCfgData2Table(httpd_t wp, const char_t * pFileName, char_t * pTag,
			 const char_t * pSymbol, CGI_TABLE_S * pTable,
			 int nTableType)
{
	FILE *fd = NULL;
	char_t *pString = NULL;
	char_t *buffer = NULL;
	char_t sCommand[MAX_FILELINE_LEN];
	char_t sSubSymbol[15][MAX_TAG_NAME_LEN];	// 000001:tc.chen qos priority using 13 symbol
	int sSubValueIdx[15];	// 000001:tc.chen

	int nReturn = 0;
	int nIndex = 0, nCount = 0, nFileSize = 0, nSubIndex = 0, nSubCount = 0;

	if (pTable == NULL) {
		nReturn = 0;
		goto exit;
	}
	if ((fd = gfopen(pFileName, "r")) != NULL) {

		if ((ifx_GetCfgObject
		     (pFileName, pTag, NULL, IFX_F_GET_ANY, &buffer))) {
			nReturn = 0;
			goto exit;
		}
		if (buffer) {
			nFileSize = strlen(buffer);
		}
		// 1st, get total count "XXXCount"
		gsprintf(sCommand, T("%sCount"), pSymbol);

		pString = buffer;
		if (pString) {
			if (ifx_GetCfgDatafromString
			    (pString, sCommand, NULL, pString) != IFX_SUCCESS) {
				nReturn = 0;
				goto exit;
			}

			nCount = gatoi(pString);
		}

		switch (nTableType) {
		case PACKET_FILTER_TABLE_TYPE:
			gsprintf(sSubSymbol[0], "%sF", pSymbol);
			sSubValueIdx[0] = 0;
			gsprintf(sSubSymbol[1], "%sIP_SRC_IP", pSymbol);
			sSubValueIdx[1] = 0;
			gsprintf(sSubSymbol[2], "%sIP_SRC_MASK", pSymbol);
			sSubValueIdx[2] = 16;
			gsprintf(sSubSymbol[3], "%sPORT_SRC_START", pSymbol);
			sSubValueIdx[3] = 19;
			gsprintf(sSubSymbol[4], "%sPORT_SRC_END", pSymbol);
			sSubValueIdx[4] = 25;
			gsprintf(sSubSymbol[5], "%sIP_DST_IP", pSymbol);
			sSubValueIdx[5] = 31;
			gsprintf(sSubSymbol[6], "%sIP_DST_MASK", pSymbol);
			sSubValueIdx[6] = 47;
			gsprintf(sSubSymbol[7], "%sPORT_DST_START", pSymbol);
			sSubValueIdx[7] = 50;
			gsprintf(sSubSymbol[8], "%sPORT_DST_END", pSymbol);
			sSubValueIdx[8] = 56;
			gsprintf(sSubSymbol[9], "%sTYPE", pSymbol);
			sSubValueIdx[9] = 62;
			gsprintf(sSubSymbol[10], "%sIN_IF", pSymbol);	//Sumedh - For inteface baseed packet filtering
			sSubValueIdx[10] = 66;
			gsprintf(sSubSymbol[11], "%sOUT_IF", pSymbol);	//Sumedh - For inteface baseed packet filtering
			sSubValueIdx[11] = 72;
			nSubCount = 12;
			break;
			// 000001:tc.chen start add qos priority parsing keyword
		case QOS_PRIORITY_TABLE_TYPE:
			gsprintf(sSubSymbol[0], "%sPRIO", pSymbol);
			sSubValueIdx[0] = 0;
			gsprintf(sSubSymbol[1], "%sIP_SRC_IP", pSymbol);
			sSubValueIdx[1] = 0;
			gsprintf(sSubSymbol[2], "%sIP_SRC_MASK", pSymbol);
			sSubValueIdx[2] = 16;
			gsprintf(sSubSymbol[3], "%sPORT_SRC_START", pSymbol);
			sSubValueIdx[3] = 19;
			gsprintf(sSubSymbol[4], "%sPORT_SRC_END", pSymbol);
			sSubValueIdx[4] = 25;
			gsprintf(sSubSymbol[5], "%sIP_DST_IP", pSymbol);
			sSubValueIdx[5] = 31;
			gsprintf(sSubSymbol[6], "%sIP_DST_MASK", pSymbol);
			sSubValueIdx[6] = 47;
			gsprintf(sSubSymbol[7], "%sPORT_DST_START", pSymbol);
			sSubValueIdx[7] = 50;
			gsprintf(sSubSymbol[8], "%sPORT_DST_END", pSymbol);
			sSubValueIdx[8] = 56;
			gsprintf(sSubSymbol[9], "%sPROTO", pSymbol);
			sSubValueIdx[9] = 62;
			gsprintf(sSubSymbol[10], "%sIF", pSymbol);
			sSubValueIdx[10] = 66;
			gsprintf(sSubSymbol[11], "%sDIR", pSymbol);
			sSubValueIdx[11] = 68;
			gsprintf(sSubSymbol[12], "%sTYPE", pSymbol);
			sSubValueIdx[12] = 70;
			nSubCount = 13;
			break;
			// 000001:tc.chen end
			// 604041:sumedh - Parental Control (modified MAC Filter)
		case MAC_FILTER_TABLE_TYPE:
			gsprintf(sSubSymbol[0], "%sSTATUS", pSymbol);
			sSubValueIdx[0] = 0;
			gsprintf(sSubSymbol[1], "%sMACADDR", pSymbol);
			sSubValueIdx[1] = 0;
			gsprintf(sSubSymbol[2], "%sDAYSELECTION", pSymbol);	//DAY Selection
			sSubValueIdx[2] = 19;
			gsprintf(sSubSymbol[3], "%sTIMESTART", pSymbol);	//Time Start
			sSubValueIdx[3] = 27;
			gsprintf(sSubSymbol[4], "%sTIMEEND", pSymbol);	//Time End
			sSubValueIdx[4] = 34;
			nSubCount = 5;
			break;

			// 510251:sumedh start (Policy Routing)
			////sumedh - SIP start
			//case SIP_TABLE_TYPE:
			//              gsprintf(sSubSymbol[0],"%sE",pSymbol);
			//              sSubValueIdx[0]=0;
			//              gsprintf(sSubSymbol[1],"%sPROTOCOL",pSymbol); sSubValueIdx[1]=0;
			//
			//              gsprintf(sSubSymbol[2],"%sPORT",pSymbol); sSubValueIdx[2]=4;
			//
			//              gsprintf(sSubSymbol[3],"%sPHONE_IP",pSymbol); sSubValueIdx[3]=10;
			//
			//              nSubCount = 4;
			//        break;
			////sumedh - SIP ends

		case SNMPv3_USER_TABLE_TYPE:
			gsprintf(sSubSymbol[0], "%s", pSymbol);
			sSubValueIdx[0] = 0;

			gsprintf(sSubSymbol[1], "%sUserName", pSymbol);
			sSubValueIdx[1] = 0;

			gsprintf(sSubSymbol[2], "%sUserAccess", pSymbol);
			sSubValueIdx[2] = 20;

			gsprintf(sSubSymbol[3], "%sSecLevel", pSymbol);
			sSubValueIdx[3] = 30;

			gsprintf(sSubSymbol[4], "%sAuthProto", pSymbol);
			sSubValueIdx[4] = 40;

			gsprintf(sSubSymbol[5], "%sAuthPasswd", pSymbol);
			sSubValueIdx[5] = 45;

			gsprintf(sSubSymbol[6], "%sPrivProto", pSymbol);
			sSubValueIdx[6] = 65;

			gsprintf(sSubSymbol[7], "%sPrivPasswd", pSymbol);
			sSubValueIdx[7] = 75;

			nSubCount = 8;

			break;

			//604042:sumedh start
		case VLAN_TABLE_TYPE:
			gsprintf(sSubSymbol[0], "%sTAG", pSymbol);
			sSubValueIdx[0] = 0;
			gsprintf(sSubSymbol[1], "%sID", pSymbol);
			sSubValueIdx[1] = 0;
			nSubCount = 2;
			break;
			//604042:sumedh ends

		default:
			gsprintf(sSubSymbol[0], "%s", pSymbol);
			sSubValueIdx[0] = 0;
			nSubCount = 1;
			break;
		}

		for (nIndex = 0; nIndex < nCount; nIndex++) {
			memset(pTable[nIndex].Data.sValue, 0x00,
			       sizeof(pTable[nIndex].Data.sValue));
			for (nSubIndex = 0; nSubIndex < nSubCount; nSubIndex++) {
				if (pString) {
					pTable[nIndex].nIndex = nIndex;
					if (pString + gstrlen(pString) + 1 >=
					    buffer + nFileSize) {
						nReturn = 0;
						goto exit;
					} else {
						pString =
						    pString + gstrlen(pString) +
						    1;
					}

					gsprintf(sCommand, T("%s%d"),
						 sSubSymbol[nSubIndex], nIndex);

					if (ifx_GetCfgDatafromString
					    (pString, sCommand, NULL,
					     pString) != IFX_SUCCESS) {
						nReturn = 0;
						goto exit;
					}
					if (nSubCount > 1) {
						if (nSubIndex > 0) {
							if (pString) {
								gstrcpy(&pTable
									[nIndex].
									Data.
									sValue
									[sSubValueIdx
									 [nSubIndex]],
									pString);
							}
						} else {
							/* 000001:tc.chen start
							   if (!gstrcmp(pString, "0"))
							   pTable[nIndex].nState = 0;
							   else
							   pTable[nIndex].nState = 1;
							 */
							pTable[nIndex].nState =
							    atoi(pString);
							// 000001:tc.chen end
						}
					} else {
						gstrcpy(pTable[nIndex].Data.
							sValue, pString);
					}
				}
			}
		}
		nReturn = nCount;
	} else
		nReturn = 0;

      exit:
	IFX_MEM_FREE(buffer);

	if (fd)
		fclose(fd);

	return nReturn;
}

void websGetIFInfo(int IF_type, int IP_Type, int nIDX, int nReqIdx,
		   bool_t bBreak, char_t * ip_Addr, char_t * pRetValue)
{
	char_t sTAG_NAME[MAX_DATA_LEN];
	char_t sCFG_NAME[MAX_DATA_LEN];
	char_t sValue[MAX_DATA_LEN];
	char_t *ip;
	int nIndex = 0;

	if (IF_type == LAN_IF_TYPE) {
		// LAN
		sprintf(sTAG_NAME, "Lan%d_IF_Info", nIDX);
	} else if (IF_type == WAN_IF_TYPE) {
		// WAN
		sprintf(sTAG_NAME, "Wan%d_IF_Info", nIDX);
	} else {
		// OTHER_IF_TYPE
		sprintf(sValue, "%s", ip_Addr);
		goto ip_token;
	}

	if (IP_Type == IP_INFO)
		sprintf(sCFG_NAME, "IP");
	else if (IP_Type == MASK_INFO)
		sprintf(sCFG_NAME, "MASK");
	memset(sValue, 0x00, sizeof(sValue));
	if (ifx_GetCfgData(FILE_SYSTEM_STATUS, sTAG_NAME, sCFG_NAME, sValue) !=
	    IFX_SUCCESS)
		sprintf(sValue, "0.0.0.0");

	if (bBreak == FALSE && nReqIdx == 4) {	// Wanna full IP address
		LTQ_STRNCPY(pRetValue, sValue, sizeof(pRetValue));
		return;
	}

      ip_token:
	nIndex = 0;
	do {
		if (nIndex == 0)
			ip = strtok(sValue, ".");
		else
			ip = strtok(NULL, ".");
		nIndex++;
		if (bBreak == FALSE && ip != NULL) {
			LTQ_STRNCAT(pRetValue, (const char_t *)ip,
				sizeof(pRetValue));
			gstrcat(pRetValue, ".");
		}
	} while (ip != NULL && nIndex < nReqIdx);

	if (bBreak == TRUE && nIndex == nReqIdx && ip != NULL) {
		LTQ_STRNCPY(pRetValue, (const char_t *)ip, sizeof(pRetValue));
		return;
	}
}

void get_atm_proto_name_by_id(char8 name[MAX_FILELINE_LEN], int32 proto)
{
	switch (proto) {
	case 0:
		sprintf(name, "%s", "unconfigured");
		break;
	case 1:
		sprintf(name, "%s", "rfc2684_eoa");
		break;
	case 2:
		sprintf(name, "%s", "rfc2684_ipoa");
		break;
	case 3:
		sprintf(name, "%s", "pppoatm");
		break;
	case 4:
		sprintf(name, "%s", "pppoe");
		break;
	case 5:
		sprintf(name, "%s", "clip");
		break;
	case 7:
		sprintf(name, "%s", "ethernet");
		break;
	case 8:
		sprintf(name, "%s", "ptm");
		break;
	}
}

/****************************** Forward Declarations **************************/
int ifx_create_left_page(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_dhcp_server_module_enable(int eid, httpd_t wp, int argc,
				      char_t ** argv);
int ifx_get_firewall_module_enable(int eid, httpd_t wp, int argc,
				   char_t ** argv);
// system_status.asp
int ifx_get_RuntimeWanIPMask(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_LanIPMask(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_DhcpClientNum(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_RuntimeCodeVersion(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_LanMacaddr(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_Hardwareversion(int eid, httpd_t wp, int argc, char_t ** argv);
int ifx_get_ConnectingStatus(int eid, httpd_t wp, int argc, char_t ** argv);

int ifx_get_SystemDomainName(int eid, httpd_t wp, int argc, char_t ** argv);
// wizard_tz.asp
#ifdef CONFIG_PACKAGE_NTPCLIENT
int ifx_get_Daylight_EndDay(int eid, httpd_t wp, int argc, char_t ** argv);
#endif

#ifdef CONFIG_FEATURE_IFX_UPNP
int ifx_get_UpnpStatus(int eid, httpd_t wp, int argc, char_t ** argv);
#endif

#ifdef CONFIG_FEATURE_DHCP_SERVER
int get_DhcpStatus();
int ifx_get_DhcpStatus(int eid, httpd_t wp, int argc, char_t ** argv);	//lan_dhcps.asp; lan_nodhcp.asp
#endif				//CONFIG_FEATURE_DHCP_SERVER
#ifdef CONFIG_FEATURE_IFX_WIRELESS
#if defined (CONFIG_FEATURE_LTQ_WIRELESS_VB) || defined (CONFIG_FEATURE_LTQ_WIRELESS_STA_SUPPORT)
int get_VbMode();
#endif				/* #ifdef CONFIG_FEATURE_LTQ_WIRELESS_VB */
#ifdef CONFIG_FEATURE_IFX_WIRELESS_ATH
int ifx_get_wlan_settings(int eid, httpd_t wp, int argc, char_t ** argv);	//wireless_settings.asp
int ifx_get_wlan_security(int eid, httpd_t wp, int argc, char_t ** argv);	//wireless_security.asp
int ifx_get_radius_ip(int eid, httpd_t wp, int argc, char_t * *argv);
#endif				//CONFIG_FEATURE_IFX_WIRELESS_ATH
#endif				//CONFIG_FEATURE_IFX_WIRELESS

#ifdef CONFIG_FEATURE_VLAN
int ifx_get_vlan_bridge_cfg(int eid, httpd_t wp, int argc, char_t ** argv);	/* 507082:linmars */
int ifx_get_vlan_membership_wan_ports(int eid, httpd_t wp, int argc, char_t ** arg_v);	//604042:sumedh
#endif				//CONFIG_FEATURE_VLAN

int ifx_get_ADSLVcChannel_List(int eid, httpd_t wp, int argc, char_t ** argv);	//adsl_config.asp;
int ifx_get_VcChannel_modified(int eid, httpd_t wp, int argc, char_t ** argv);
int ltq_cgi_l2channel_list(int eid, httpd_t wp, int argc, char_t **argv);

#ifdef CONFIG_FEATURE_IFX_IGMPPROXY
int ifx_get_wan_cfg(int eid, httpd_t wp, int argc, char_t ** argv);
#endif

int ifx_create_left_page(int eid, httpd_t wp, int argc, char_t ** argv)
{
#ifdef CONFIG_FEATURE_SYSTEM_PERFORMANCE_CHARTS
	FILE *fp = NULL;
#endif
#if defined(CONFIG_FEATURE_IFX_TR69_DEVICE) || defined(CONFIG_FEATURE_LTQ_WIRELESS_VB) || defined(CONFIG_FEATURE_LTQ_HNX_CONFIG)
	ifx_httpdWrite(wp, T("CreateNode('System',null);\n"));
#ifndef CONFIG_FEATURE_LTQ_WIRELESS_VB
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('Host Name Config','system_hostname.asp','System');\n"));
#endif				/* CONFIG_FEATURE_LTQ_WIRELESS_VB */
#ifdef CONFIG_PACKAGE_NTPCLIENT
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('System Time','system_time.asp','System');\n"));
#endif				// CONFIG_PACKAGE_NTPCLIENT
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('User Account Management','system_password.htm','System');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('Web Settings','web_config.asp','System');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('Software/Firmware Upgrade','system_upgrade.asp','System'); \n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('Configuration Settings','sysconfig_update.asp','System'); \n"));
#ifdef CONFIG_FEATURE_SYSTEM_LOG
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('System Log','system_log.asp','System'); \n"));
#endif				// CONFIG_FEATURE_SYSTEM_LOG
#ifndef CONFIG_FEATURE_LTQ_WIRELESS_VB
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('SSL Certificate','system_ssl.asp','System'); \n"));
#endif				/* #ifndef CONFIG_FEATURE_LTQ_WIRELESS_VB */
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('Reset','system_reset.htm','System');\n "));
//      ifx_httpdWrite(wp, T("ChangeDisplay('System'); \n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
	ifx_httpdWrite(wp, T("CreateNode('Statistics',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('LAN','lan_if_stats.asp','Statistics');\n"));

#ifndef CONFIG_FEATURE_LTQ_HNX_CONFIG //Confirm with Ramesh
#ifdef CONFIG_FEATURE_SYSTEM_PERFORMANCE_CHARTS
	if((fp = fopen("/www/highcharts.js", "r"))) {
		ifx_httpdWrite(wp,
		       "CreateSubNode('System Performance','system_statistics_graph.asp','Statistics');\n");
		fclose(fp);
	}
#endif
#ifdef CONFIG_FEATURE_IFX_WIRELESS
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('WLAN','wlan_if_stats.asp','Statistics');\n"));
#endif				// CONFIG_FEATURE_IFX_WIRELESS
#endif				/*!CONFIG_FEATURE_LTQ_HNX_CONFIG */

#if defined(CONFIG_FEATURE_LTQ_HNX_CONFIG) || defined(CONFIG_FEATURE_HNX_ID)
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('G.hn','g_hn_if_stats.asp','Statistics');\n"));
#endif
//      ifx_httpdWrite(wp, T("ChangeDisplay('Statistics');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));

	ifx_httpdWrite(wp, T("CreateNode('LAN',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('UPnP Devices','lan_upnp_devices.asp','LAN');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('ARP List','lan_arp.asp','LAN');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('LAN Settings','lan.asp','LAN');\n"));
#ifdef CONFIG_FEATURE_DHCP_SERVER
	if (get_DhcpStatus() == 1) {
		ifx_httpdWrite(wp, T("document.write(\"<div id='lan_dhcp_config' display=none >\");\n"));
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('DHCP Conditional Config','lan_dhcp_cond_serv_config.asp','LAN');\n"));
		ifx_httpdWrite(wp, T("document.write(\"</div>\");\n"));
		ifx_httpdWrite(wp, T("document.write(\"<div id='lan_dhcp_client' display=none >\");\n"));
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('DHCP Client List','lan_dhcp_clients.asp','LAN');\n"));
		ifx_httpdWrite(wp, T("document.write(\"</div>\");\n"));
	} else if (get_DhcpStatus() == 2) {
		ifx_httpdWrite(wp, T("document.write(\"<div id='lan_dhcp_config' display=none >\");\n"));
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('DHCP Conditional Config','lan_dhcp_cond_serv_config.asp','LAN');\n"));
		ifx_httpdWrite(wp, T("document.write(\"</div>\");\n"));
	}
#endif				// CONFIG_FEATURE_DHCP_SERVER
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));

#ifndef CONFIG_FEATURE_LTQ_WIRELESS_VB
	ifx_httpdWrite(wp, T("CreateNode('Route',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Static Routing','route_static.asp','Route');\n"));
#ifdef CONFIG_FEATURE_RIP
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('RIP Support','route_dynamic.asp','Route');\n"));
#endif				//CONFIG_FEATURE_RIP
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Routing Table List','route_table.asp','Route');\n"));

#ifdef POLICY_ROUTING
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Policy Based Routing','policy_routing.asp','Route');\n"));
#endif
//      ifx_httpdWrite(wp, T("    ChangeDisplay('Route');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif				/* #ifndef CONFIG_FEATURE_LTQ_WIRELESS_VB */

#ifdef CONFIG_FEATURE_IFX_WIRELESS
#ifdef CONFIG_FEATURE_LTQ_WIRELESS_VB
	ifx_httpdWrite(wp, T("CreateNode('Bridge Device',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Config','wlan_vb_config.asp','VideoBridge');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('LAN Config','wlan_vb_lan_bd_cfg.asp','VideoBridge');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
	/* STA */
	if (get_VbMode() == 0) {
		ifx_httpdWrite(wp, T("CreateNode('Wireless',null);\n"));
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('WLAN Settings','wlan_vb_gen_wlan_config.asp','Wireless');\n"));
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('WLAN Status','wlan_vb_status.asp','Wireless');\n"));
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('WMM Settings','wlan_vb_wmm_config.asp','Wireless');\n"));
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('WPS Settings','wlan_vb_wps_config.asp','Wireless');\n"));
		ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
	}
	/* AP */
	else if (get_VbMode() == 1) {
		ifx_httpdWrite(wp, T("CreateNode('Wireless',null);\n"));
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('Radio Settings','wlan_basic.asp','Wireless');\n"));
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('Main AP/VAP Settings','wlan_advsetup.asp','Wireless');\n"));
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('Security Settings','wlan_sec.asp','Wireless');\n"));
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('WMM Settings','wlan_wmm.asp','Wireless');\n"));
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('WPS Settings','wlan_wps.asp','Wireless');\n"));
		ifx_httpdWrite(wp, T("    CreateSubNode('MAC Filter',"
			"'wlan_mac_filter_cfg.asp','Wireless');\n"));
		ifx_httpdWrite(wp, T("    CreateSubNode('WDS Configuration',"
			"'wlan_wds_cfg.asp','Wireless');\n"));
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('Device Association','wlan_dev_association.asp','Wireless');\n"));
		ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
	} else {
		ifx_httpdError(wp, 500, "Error: Invalid VB status");
	}
#endif				/* #ifdef CONFIG_FEATURE_LTQ_WIRELESS_VB */
#endif				/* CONFIG_FEATURE_IFX_WIRELESS */

#ifdef CONFIG_FEATURE_FIREWALL
	ifx_httpdWrite(wp, T("CreateNode('Firewall',null)\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Firewall Setting','firewall_main.asp','Firewall');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Packet Filtering','firewall_packetfilter.asp','Firewall');\n"));
#ifdef CONFIG_FEATURE_URL_FILTERING
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('URL Filtering','url_filter.asp','URL Filtering');\n"));
#endif
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Parental Control','firewall_mac.asp','Firewall');\n"));
#if 0 /* Keep commented until the feature request comes in */
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Application Filtering','firewall_app_main.asp','Firewall');\n"));
#endif
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Application Server Settings','apps_serv.asp','Firewall');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('ACL','servers_acl.asp','Firewall');\n"));
//      ifx_httpdWrite(wp, T("    ChangeDisplay('Firewall');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#ifdef IFX_DOS_ENABLE
	ifx_httpdWrite(wp, T("CreateNode('DoS',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('DoS Setting','dos_main.asp','DoS');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Applications Related','dos_applications.asp','DoS');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Networking Related','dos_networking.asp','DoS');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Scans','dos_scans.asp','DoS');\n"));
//      ifx_httpdWrite(wp, T("    ChangeDisplay('DoS');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif				//IFX_DOS_ENABLE
#endif				//CONFIG_FEATURE_FIREWALL
#ifdef CONFIG_FEATURE_NAPT
	ifx_httpdWrite(wp, T("CreateNode('NAT',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('NAT Settings','nat_main.asp','NAT');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Virtual Server','nat_virtualser.asp','NAT');\n"));
	ifx_httpdWrite(wp,
		       T
		       (" CreateSubNode('Port Triggering','port_trigger.asp','NAT');\n"));
#ifdef NAT_PORTMAP
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Port Mapping','nat_portmap.asp','NAT');\n"));
#endif
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('DMZ','firewall_dmz.asp','NAT');\n"));
//      ifx_httpdWrite(wp, T("    ChangeDisplay('NAT');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif				//CONFIG_FEATURE_NAPT

#ifndef CONFIG_FEATURE_LTQ_WIRELESS_VB
#ifdef CONFIG_FEATURE_IFX_IPQOS
	ifx_httpdWrite(wp, T("CreateNode('QoS',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('QoS Settings', 'qos_settings.asp', 'QoS');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Queue Config', 'qos_queue.asp', 'QoS');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Class Config', 'qos_class.asp', 'QoS');\n"));
	//  ifx_httpdWrite(wp, T("    ChangeDisplay('QoS');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif				// #ifdef CONFIG_FEATURE_IFX_IPQOS
#endif				/* CONFIG_FEATURE_LTQ_WIRELESS_VB */

#ifdef CONFIG_PACKAGE_LQ_IGMPD

	ifx_httpdWrite(wp, T("CreateNode('Multicast',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       (" CreateSubNode('Proxy Settings',       'igmp_proxy.asp',    'Multicast');\n"));
	ifx_httpdWrite(wp,
		       T
		       (" CreateSubNode('Snooping Settings',    'igmp_snooping.asp', 'Multicast');\n"));
	ifx_httpdWrite(wp,
		       T
		       (" CreateSubNode('Advanced Settings','igmp_advanced.asp', 'Multicast');\n"));
	// ifx_httpdWrite(wp, T(" ChangeDisplay('Multicast');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));

#endif				// CONFIG_PACKAGE_LQ_IGMPD

#ifdef CONFIG_FEATURE_VLAN
	ifx_httpdWrite(wp, T("CreateNode('VLAN',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('VLAN Bridge', 'vlan_bridge.asp', 'VLAN');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('VLAN Membership', 'vlan_membership.asp', 'VLAN');\n"));
//      ifx_httpdWrite(wp, T("    ChangeDisplay('VLAN');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif				//CONFIG_FEATURE_VLAN
#ifdef CONFIG_FEATURE_IFX_VOIP
	ifx_httpdWrite(wp, T("CreateNode('VoIP',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Line', 'voip_line_summary.asp', 'VoIP');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Interface', 'voip_int_summary.asp', 'VoIP');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Service', 'voip_profile_main.asp', 'VoIP');\n"));
#ifdef CONFIG_IFX_DECT_SUPPORT
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('DECT Base', 'dect_basestation.asp', 'VoIP');\n"));
#endif
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('System', 'voip_sys_speeddial.asp', 'VoIP');\n"));
#ifdef CONFIG_IFX_DECT_SUPPORT
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('DECT Modem', 'dect_modem_one.asp', 'VoIP');\n"));
#endif
	//ifx_httpdWrite(wp, T("CreateSubNode('Save VoIP Config','writetoflash.asp','VoIP');\n"));
	//ifx_httpdWrite(wp, T("    ChangeDisplaydd('VoIP');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif				// CONFIG_FEATURE_IFX_VOIP

#if defined( CONFIG_FEATURE_LTQ_HNX_CONFIG) || defined(CONFIG_FEATURE_HNX_ID)
	ifx_httpdWrite(wp, T("CreateNode('G.hn',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('G.hn Settings','g_hn_main.asp','G.hn');\n"));
#ifdef CONFIG_FEATURE_LTQ_HNX_CONFIG
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('UPnP Settings','g_hn_upnpdm.asp','G.hn');\n"));
#endif 
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif

#ifdef CONFIG_FEATURE_QOS
	ifx_httpdWrite(wp, T("CreateNode('QoS',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('QoS Setting','qos_main.asp','QoS');\n"));
	ifx_httpdWrite(wp,
		       T("    CreateSubNode('ALGs','qos_algs.asp','QoS');\n"));
#ifdef CONFIG_FEATURE_QOS_PRIORITY_QUEUE
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Priority Setting','qos_priority.asp','QoS');\n"));
#endif				//CONFIG_FEATURE_QOS_PRIORITY_QUEUE
//      ifx_httpdWrite(wp, T("    ChangeDisplay('QoS');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif				//CONFIG_FEATURE_QOS
#ifndef CONFIG_FEATURE_LTQ_WIRELESS_VB
#ifdef CONFIG_FEATURE_IFX_IPSEC_TERMINATION
	ifx_httpdWrite(wp, T("CreateNode('IPsec',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Tunnel Mode','ipsec_tunnel_config.asp','IPSEC');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif
#endif				/* #ifndef CONFIG_FEATURE_LTQ_WIRELESS_VB */

#ifndef CONFIG_FEATURE_LTQ_WIRELESS_VB
#ifdef CONFIG_FEATURE_IPv6
// ifx_httpdWrite(wp, T("CreateNode('IPv6','ipv6_settings.asp','IPv6');\n"));
	ifx_httpdWrite(wp, T("CreateNode('IPv6',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('IPv6 Setting','ipv6_settings.asp','IPv6');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('6RD Configuration','sixrd_settings.asp','IPv6');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('DS-Lite Configuration','dslite_settings.asp','IPv6');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif				//CONFIG_FEATURE_IPv6
#else
#ifdef CONFIG_FEATURE_IPv6
// ifx_httpdWrite(wp, T("CreateNode('IPv6','ipv6_settings.asp','IPv6');\n"));
	ifx_httpdWrite(wp, T("CreateNode('IPv6',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('IPv6 Setting','ipv6_settings.asp','IPv6');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('LAN IPv6 Setting','lan_ipv6_vb.asp','IPv6');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif
#endif

#if defined(CONFIG_PACKAGE_IFX_DEVM) || defined(IFX_HAVE_SNMP)
	ifx_httpdWrite(wp, T("CreateNode('Device Management',null);\n"));
#ifdef CONFIG_PACKAGE_IFX_DEVM
	ifx_httpdWrite(wp,
		       T
		       ("	CreateSubNode('TR - 069/064','tr69_web.asp','Device Management');\n"));
#endif				// CONFIG_PACKAGE_IFX_DEVM
#ifdef IFX_HAVE_SNMP
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('SNMPv2','snmp_settings.asp','Device Management');\n"));
#ifdef CONFIG_FEATURE_SNMPV3
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('SNMPv3','snmpv3_settings.asp','Device Management');\n"));
#endif
#endif
//      ifx_httpdWrite(wp, T("    ChangeDisplay('Device Management');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif

#if defined(CONFIG_FEATURE_IFX_USB_HOST) || (CONFIG_PACKAGE_KMOD_LTQCPE_SATA_AHCI) || (CONFIG_FEATURE_SAMBA) || (CONFIG_FEATURE_MEDIA_SERVER)
	ifx_httpdWrite(wp, T("CreateNode('Content Sharing',null);\n"));
#if defined(CONFIG_FEATURE_IFX_USB_HOST) || if defined(CONFIG_PACKAGE_KMOD_LTQCPE_SATA_AHCI)
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('USB / SATA','usb.asp','Content Sharing');\n"));
#endif				/* CONFIG_FEATURE_IFX_USB_HOST */
#ifdef CONFIG_FEATURE_SAMBA
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('SAMBA Server','samba_settings.asp','Content Sharing');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('Share Management','share_mgmt.asp','Content Sharing');\n"));
#endif				/* CONFIG_PACKAGE_samba3 */
#ifdef CONFIG_FEATURE_MEDIA_SERVER
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('Media Server','dlna.asp','Content Sharing');\n"));
#endif				/* CONFIG_FEATURE_MEDIA_SERVER */
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif

// ]

#else /* defined(CONFIG_FEATURE_IFX_TR69_DEVICE) || defined(CONFIG_FEATURE_LTQ_WIRELESS_VB) || defined(CONFIG_FEATURE_LTQ_HNX_CONFIG) */
	struct connection_profil_list *seekPtr = NULL;
	int		bShowAll = 0;
	char	sValue[MAX_FILELINE_LEN];

	if (GetObjData(FILE_RC_CONF, TAG_SYSTEM_PASSWORD, "PasswdProtect", sValue, IFX_F_DEFAULT) != IFX_SUCCESS) {
		ifx_httpdError(wp, 500, T("passwd protect not found"));
		return -1;
	}
	if(atoi(sValue) == 1) {
		bShowAll = 1;
	}
	else {
		seekPtr = connlist;
		while(seekPtr != NULL) {
			if(strncmp(seekPtr->connection.ipaddr, wp->ipaddr, sizeof(seekPtr->connection.ipaddr)) == 0) {
				if(!strcmp(seekPtr->connection.user, "admin")) {
					bShowAll = 1;
					break;
				}
			}
			seekPtr = seekPtr -> next;
		}
	}

	if(bShowAll) { // [ show only for admin
	ifx_httpdWrite(wp,
		       T
		       ("CreateNode('Quick Setup','quick_wan.asp','Quick Setup');\n"));
	} // show only for admin ]

	ifx_httpdWrite(wp, T("document.write(\"<br>\");\n"));
	ifx_httpdWrite(wp, T("CreateNode('System',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('Host Name Config','system_hostname.asp','System');\n"));
#ifdef CONFIG_PACKAGE_NTPCLIENT
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('System Time','system_time.asp','System');\n"));
#endif				// CONFIG_PACKAGE_NTPCLIENT
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('User Account Management','system_password.htm','System');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('Web Settings','web_config.asp','System');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('Software/Firmware Upgrade','system_upgrade.asp','System'); \n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('Configuration Settings','sysconfig_update.asp','System'); \n"));
#ifdef CONFIG_FEATURE_SYSTEM_LOG
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('System Log','system_log.asp','System'); \n"));
#endif				// CONFIG_FEATURE_SYSTEM_LOG
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('SSL Certificate','system_ssl.asp','System'); \n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('Reset','system_reset.htm','System');\n "));
//      ifx_httpdWrite(wp, T("ChangeDisplay('System'); \n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
	ifx_httpdWrite(wp, T("CreateNode('Statistics',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('LAN','lan_if_stats.asp','Statistics');\n"));

	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('WAN','wan_if_stats.asp','Statistics');\n"));
#ifdef CONFIG_FEATURE_SYSTEM_PERFORMANCE_CHARTS
	if((fp = fopen("/www/highcharts.js", "r"))) {
		ifx_httpdWrite(wp,
		       "CreateSubNode('System Performance','system_statistics_graph.asp','Statistics');\n");
		fclose(fp);
	}
#endif
#ifdef CONFIG_FEATURE_IFX_WIRELESS
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('WLAN','wlan_if_stats.asp','Statistics');\n"));
#endif				// CONFIG_FEATURE_IFX_WIRELESS


//      ifx_httpdWrite(wp, T("ChangeDisplay('Statistics');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
	ifx_httpdWrite(wp, T("CreateNode('xDSL',null); \n"));
	ifx_httpdWrite(wp,
		       T("CreateSubNode('xDSL Status','dsl_line0.asp','xDSL');\n"));
	if(bShowAll) { // [ show only for admin
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('xDSL PHY Configuration','xdsl_cfg.asp','xDSL');\n"));
	} // show only for admin ]

//      ifx_httpdWrite(wp, T("ChangeDisplay('ADSL');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif

	if(bShowAll) { // [ show only for admin
#ifdef CONFIG_FEATURE_IFX_VDSL2
	ifx_httpdWrite(wp,
		       T("CreateNode('Vdsl2','vdsl2_main.asp','Vdsl2');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('ChannelConfig','vdsl2_channel_config.asp','Vdsl2');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('LineConfig','vdsl2_line_config.asp','Vdsl2');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('ProfileConfig','vdsl2_profile_config.asp','Vdsl2');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('BandsConfig','vdsl2_bands_config.asp','Vdsl2');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('LoopBack','vdsl2_loop_back.asp','Vdsl2');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('ActivateDeactivate','vdsl2_activate_deactivate.asp','Vdsl2');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('LineStatus','vdsl2_line_status.asp','Vdsl2');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('ChannelStatus','vdsl2_channel_status.asp','Vdsl2');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('xTCStatus','vdsl2_xtcstatus.asp','Vdsl2');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('VersionInfo','vdsl2_version_info.asp','Vdsl2');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('SNRGraphs','vdsl2_snr_graph.asp','Vdsl2');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('BitsGraphs','vdsl2_bits_graph.asp','Vdsl2');\n"));
//      ifx_httpdWrite(wp, T("ChangeDisplay('Vdsl2'); \n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif				//CONFIG_FEATURE_IFX_VDSL2

	ifx_httpdWrite(wp, T("CreateNode('WAN',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('WAN Mode Selection','wan_mode_setting.asp','WAN');\n"));

#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
	ifx_httpdWrite(wp,T("CreateSubNode('Auto Detect Config','autodetect.asp','WAN');\n"));
#endif
#if defined(CONFIG_FEATURE_ADSL_WAN_SUPPORT)
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('WAN Channel Config','atm_channel_config.asp','WAN');\n"));
#endif				/* #if defined(CONFIG_FEATURE_ADSL_WAN_SUPPORT) */

#if defined(CONFIG_FEATURE_ADSL_WAN_SUPPORT) || defined(CONFIG_FEATURE_PTM_WAN_SUPPORT) || defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
  ifx_httpdWrite(wp, T("    CreateSubNode('VLAN Channel Config','vlan_display.asp','WAN');\n"));
#endif				/* #if defined(CONFIG_FEATURE_ADSL_WAN_SUPPORT) */

#ifdef CONFIG_FEATURE_IFX_MULTIPLE_VCCS
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('WAN Setting','wan_vcc_select.asp','WAN');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('WAN Status','wan_status.asp','WAN');\n"));
#else
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('WAN Setting','wan_main.asp','WAN');\n"));
#endif

#if !defined(AMAZON_BRIDGE_DEMO)
	ifx_httpdWrite(wp,
		       T("    CreateSubNode('DNS','wan_dns.asp','WAN');\n"));
#endif				/* #if !defined(AMAZON_BRIDGE_DEMO) */
#if defined(CONFIG_FEATURE_ADSL_WAN_SUPPORT)
	//  ifx_httpdWrite(wp, T("    CreateSubNode('WAN VLAN Config','wan_vlan_config.asp','WAN');\n"));
#endif

#ifdef CONFIG_FEATURE_DDNS
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('DDNS','ddns_config.asp','WAN');\n"));
#endif				//CONFIG_FEATURE_DDNS
#if defined(CONFIG_FEATURE_ADSL_WAN_SUPPORT) && defined(CONFIG_PACKAGE_IFX_OAM)
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('OAM Configuration','adsl_oamconfig.asp','WAN');\n"));
#endif				// CONFIG_PACKAGE_IFX_OAM
#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
	ifx_httpdWrite(wp, T("CreateSubNode('Port Binding','pwb.asp','WAN');\n"));
#endif
//      ifx_httpdWrite(wp, T("    ChangeDisplay('WAN');\n"));
#if defined(CONFIG_FEATURE_CELL_WAN_SUPPORT) || defined (CONFIG_FEATURE_WWAN_LTE_SUPPORT)
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#if defined(CONFIG_FEATURE_WWAN_LTE_SUPPORT) && defined(CONFIG_FEATURE_CELL_WAN_SUPPORT)
	ifx_httpdWrite(wp, T("CreateNode('3G/LTE WWAN',null);\n"));
#elif defined(CONFIG_FEATURE_WWAN_LTE_SUPPORT)
	ifx_httpdWrite(wp, T("CreateNode('LTE',null);\n"));
#else 
	ifx_httpdWrite(wp, T("CreateNode('3G WWAN',null);\n"));
#endif
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('WWAN Settings','wwan_setting.asp','3G / LTE WWAN');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('WWAN Device Status','wwan_status.asp','3G / LTE WWAN');\n"));
#endif
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
	} // show only for admin ]

	ifx_httpdWrite(wp, T("CreateNode('LAN',null);\n"));
#ifdef CONFIG_FEATURE_DHCP_SERVER
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('LAN ARP List','lan_arp.asp','LAN');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('LAN Settings','lan.asp','LAN');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('UPnP Devices','lan_upnp_devices.asp','LAN');\n"));
	if (get_DhcpStatus() == 1) {
		ifx_httpdWrite(wp, T("document.write(\"<div id='lan_dhcp_config' display=none >\");\n"));
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('DHCP Conditional Config','lan_dhcp_cond_serv_config.asp','LAN');\n"));
		ifx_httpdWrite(wp, T("document.write(\"</div>\");\n"));
		ifx_httpdWrite(wp, T("document.write(\"<div id='lan_dhcp_client' display=none >\");\n"));
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('DHCP Client List','lan_dhcp_clients.asp','LAN');\n"));
		ifx_httpdWrite(wp, T("document.write(\"</div>\");\n"));
	} else if (get_DhcpStatus() == 2) {
		ifx_httpdWrite(wp, T("document.write(\"<div id='lan_dhcp_config' display=none >\");\n"));
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('DHCP Conditional Config','lan_dhcp_cond_serv_config.asp','LAN');\n"));
		ifx_httpdWrite(wp, T("document.write(\"</div>\");\n"));
	}
#else
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('LAN Settings','lan_nodhcp.asp','LAN');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('UPnP Devices','lan_upnp_devices.asp','LAN');\n"));
#endif				// CONFIG_FEATURE_DHCP_SERVER
#if 0   // This webpage is a debug feature so will be hidden
#if defined(CONFIG_FEATURE_LTQ_VLAN_SWITCH_PORT_ISOLATION) ||  defined(CONFIG_FEATURE_LTQ_SWITCH_PORT_ISOLATION) 
	ifx_httpdWrite(wp,
	               T
	               ("    CreateSubNode('LAN Port Separation','lan_port_sep.asp','LAN');\n"));
#endif
#endif
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));

	ifx_httpdWrite(wp, T("CreateNode('Route',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Static Routing','route_static.asp','Route');\n"));
#ifdef CONFIG_FEATURE_RIP
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('RIP Support','route_dynamic.asp','Route');\n"));
#endif				//CONFIG_FEATURE_RIP
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Routing Table List','route_table.asp','Route');\n"));

#ifdef POLICY_ROUTING
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Policy Based Routing','policy_routing.asp','Route');\n"));
#endif
//      ifx_httpdWrite(wp, T("    ChangeDisplay('Route');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));

#ifdef CONFIG_FEATURE_IFX_WIRELESS
#ifdef CONFIG_FEATURE_IFX_WIRELESS_ATH
	ifx_httpdWrite(wp, T("CreateNode('Wireless',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Setting','wireless_settings.asp','Wireless');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Security','wireless_security.asp','Wireless');\n"));
//      ifx_httpdWrite(wp, T("    ChangeDisplay('Wireless');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#elif defined(CONFIG_FEATURE_LTQ_WIRELESS_STA_SUPPORT)
	ifx_httpdWrite(wp, T("CreateNode('Wireless',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Config','wlan_vb_config_debug.asp','Wireless');\n"));
	if (get_VbMode() == 0) {
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('LAN Config','wlan_vb_lan_bd_cfg.asp','Wireless');\n"));
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('WLAN Settings','wlan_vb_gen_wlan_config.asp','Wireless');\n"));
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('WLAN Status','wlan_vb_status.asp','Wireless');\n"));
		ifx_httpdWrite(wp, T("    CreateSubNode('WMM Settings',"
			"'wlan_vb_wmm_config.asp','Wireless');\n"));
		ifx_httpdWrite(wp, T("    CreateSubNode('WPS Settings',"
			"'wlan_vb_wps_config.asp','Wireless');\n"));
	}
	/* AP */
	else if (get_VbMode() == 1) {
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('Radio Settings','wlan_basic.asp','Wireless');\n"));
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('Main AP/VAP Settings','wlan_advsetup.asp','Wireless');\n"));
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('Security Settings','wlan_sec.asp','Wireless');\n"));
		ifx_httpdWrite(wp,
			       T
			       ("    CreateSubNode('WMM Settings','wlan_wmm.asp','Wireless');\n"));
		ifx_httpdWrite(wp, T("    CreateSubNode('WPS Settings',"
			"'wlan_wps.asp','Wireless');\n"));
		ifx_httpdWrite(wp, T("    CreateSubNode('MAC Filter',"
			"'wlan_mac_filter_cfg.asp','Wireless');\n"));
		ifx_httpdWrite(wp, T("    CreateSubNode('WDS Configuration',"
			"'wlan_wds_cfg.asp','Wireless');\n"));
		ifx_httpdWrite(wp, T("    CreateSubNode('Device Association',"
			"'wlan_dev_association.asp','Wireless');\n"));
	}
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#else /* #ifdef CONFIG_FEATURE_IFX_WIRELESS_ATH */
	ifx_httpdWrite(wp, T("CreateNode('Wireless',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Radio Settings','wlan_basic.asp','Wireless');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Main AP/VAP Settings','wlan_advsetup.asp','Wireless');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Security Settings','wlan_sec.asp','Wireless');\n"));
	ifx_httpdWrite(wp,T("    CreateSubNode('WMM Settings','wlan_wmm.asp',"
		"'Wireless');\n"));
	ifx_httpdWrite(wp, T("    CreateSubNode('WPS Settings','wlan_wps.asp',"
		"'Wireless');\n"));
	ifx_httpdWrite(wp, T("    CreateSubNode('MAC Filter',"
		"'wlan_mac_filter_cfg.asp','Wireless');\n"));
	ifx_httpdWrite(wp, T("    CreateSubNode('WDS Configuration',"
		"'wlan_wds_cfg.asp','Wireless');\n"));
	ifx_httpdWrite(wp, T("    CreateSubNode('Device Association',"
		"'wlan_dev_association.asp','Wireless');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif				/* CONFIG_FEATURE_IFX_WIRELESS_ATH */
#endif				/* CONFIG_FEATURE_IFX_WIRELESS */

	if(bShowAll) { // [ show only for admin
#ifdef CONFIG_FEATURE_FIREWALL
	ifx_httpdWrite(wp, T("CreateNode('Firewall',null)\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Firewall Setting','firewall_main.asp','Firewall');\n"));
#ifdef CONFIG_FEATURE_IPv6
#ifdef CONFIG_PACKAGE_ip6tables
	ifx_httpdWrite(wp,
		       T("    CreateSubNode('IPv6 Firewall Setting','firewall_ipv6.asp','Firewall');\n"));
/*	ifx_httpdWrite(wp,
		       T("    CreateSubNode('IPv6 Packet Filtering','firewall_packetfilter_ng.asp','Firewall');\n")); */
#endif
#endif
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Packet Filtering','firewall_packetfilter.asp','Firewall');\n"));
#ifdef CONFIG_FEATURE_URL_FILTERING
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('URL Filtering','url_filter.asp','URL Filtering');\n"));
#endif
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Parental Control','firewall_mac.asp','Firewall');\n"));
#if 0 /* Keep commented until the feature request comes in */
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Application Filtering','firewall_app_main.asp','Firewall');\n"));
#endif
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Application Server Settings','apps_serv.asp','Firewall');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('ACL','servers_acl.asp','Firewall');\n"));
//      ifx_httpdWrite(wp, T("    ChangeDisplay('Firewall');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#ifdef IFX_DOS_ENABLE
	ifx_httpdWrite(wp, T("CreateNode('DoS',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('DoS Setting','dos_main.asp','DoS');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Applications Related','dos_applications.asp','DoS');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Networking Related','dos_networking.asp','DoS');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Scans','dos_scans.asp','DoS');\n"));
//      ifx_httpdWrite(wp, T("    ChangeDisplay('DoS');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif				//IFX_DOS_ENABLE
#endif				//CONFIG_FEATURE_FIREWALL

#ifdef CONFIG_FEATURE_NAPT
	ifx_httpdWrite(wp, T("CreateNode('NAT',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('NAT Settings','nat_main.asp','NAT');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Virtual Server','nat_virtualser.asp','NAT');\n"));
	ifx_httpdWrite(wp,
		       T
		       (" CreateSubNode('Port Triggering','port_trigger.asp','NAT');\n"));
#ifdef NAT_PORTMAP
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Port Mapping','nat_portmap.asp','NAT');\n"));
#endif
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('DMZ','firewall_dmz.asp','NAT');\n"));
//      ifx_httpdWrite(wp, T("    ChangeDisplay('NAT');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif				//CONFIG_FEATURE_NAPT

#ifdef CONFIG_FEATURE_IFX_IPQOS
	ifx_httpdWrite(wp, T("CreateNode('QoS',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('QoS Settings', 'qos_settings.asp', 'QoS');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Queue Config', 'qos_queue.asp', 'QoS');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Class Config', 'qos_class.asp', 'QoS');\n"));
	//  ifx_httpdWrite(wp, T("    ChangeDisplay('QoS');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif				// #ifdef CONFIG_FEATURE_IFX_IPQOS

#ifdef CONFIG_PACKAGE_LQ_IGMPD

	ifx_httpdWrite(wp, T("CreateNode('Multicast',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       (" CreateSubNode('Proxy Settings',       'igmp_proxy.asp',    'Multicast');\n"));
	ifx_httpdWrite(wp,
		       T
		       (" CreateSubNode('Snooping Settings',    'igmp_snooping.asp', 'Multicast');\n"));
	ifx_httpdWrite(wp,
		       T
		       (" CreateSubNode('Advanced Settings','igmp_advanced.asp', 'Multicast');\n"));
	// ifx_httpdWrite(wp, T(" ChangeDisplay('Multicast');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));

#endif				// CONFIG_PACKAGE_LQ_IGMPD

#ifdef CONFIG_FEATURE_VLAN
	ifx_httpdWrite(wp, T("CreateNode('VLAN',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('VLAN Bridge', 'vlan_bridge.asp', 'VLAN');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('VLAN Membership', 'vlan_membership.asp', 'VLAN');\n"));
//      ifx_httpdWrite(wp, T("    ChangeDisplay('VLAN');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif				//CONFIG_FEATURE_VLAN
#ifdef CONFIG_FEATURE_IFX_VOIP
	ifx_httpdWrite(wp, T("CreateNode('VoIP',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Line', 'voip_line_summary.asp', 'VoIP');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Interface', 'voip_int_summary.asp', 'VoIP');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Service', 'voip_profile_main.asp', 'VoIP');\n"));
#ifdef CONFIG_IFX_DECT_SUPPORT
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('DECT Base', 'dect_basestation.asp', 'VoIP');\n"));
#endif
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('System', 'voip_sys_speeddial.asp', 'VoIP');\n"));
#ifdef CONFIG_IFX_DECT_SUPPORT
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('DECT Modem', 'dect_modem_one.asp', 'VoIP');\n"));
#endif
	//ifx_httpdWrite(wp, T("CreateSubNode('Save VoIP Config','writetoflash.asp','VoIP');\n"));
	//ifx_httpdWrite(wp, T("    ChangeDisplaydd('VoIP');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif				// CONFIG_FEATURE_IFX_VOIP

#ifdef CONFIG_FEATURE_QOS
	ifx_httpdWrite(wp, T("CreateNode('QoS',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('QoS Setting','qos_main.asp','QoS');\n"));
	ifx_httpdWrite(wp,
		       T("    CreateSubNode('ALGs','qos_algs.asp','QoS');\n"));
#ifdef CONFIG_FEATURE_QOS_PRIORITY_QUEUE
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Priority Setting','qos_priority.asp','QoS');\n"));
#endif				//CONFIG_FEATURE_QOS_PRIORITY_QUEUE
//      ifx_httpdWrite(wp, T("    ChangeDisplay('QoS');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif				//CONFIG_FEATURE_QOS
#ifdef CONFIG_FEATURE_IFX_IPSEC_TERMINATION
	ifx_httpdWrite(wp, T("CreateNode('IPsec',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('Tunnel Mode','ipsec_tunnel_config.asp','IPSEC');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif

#ifdef CONFIG_FEATURE_IPv6
// ifx_httpdWrite(wp, T("CreateNode('IPv6','ipv6_settings.asp','IPv6');\n"));
	ifx_httpdWrite(wp, T("CreateNode('IPv6',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('IPv6 Setting','ipv6_settings.asp','IPv6');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('6RD Configuration','sixrd_settings.asp','IPv6');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('DS-Lite Configuration','dslite_settings.asp','IPv6');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif				//CONFIG_FEATURE_IPv6
#if defined(CONFIG_PACKAGE_IFX_DEVM) || defined(IFX_HAVE_SNMP)
	ifx_httpdWrite(wp, T("CreateNode('Device Management',null);\n"));
#ifdef CONFIG_PACKAGE_IFX_DEVM
	ifx_httpdWrite(wp,
		       T
		       ("	CreateSubNode('TR - 069/064','tr69_web.asp','Device Management');\n"));
#endif				// CONFIG_PACKAGE_IFX_DEVM
#ifdef IFX_HAVE_SNMP
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('SNMPv2','snmp_settings.asp','Device Management');\n"));
#ifdef CONFIG_FEATURE_SNMPV3
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('SNMPv3','snmpv3_settings.asp','Device Management');\n"));
#endif
#endif
//      ifx_httpdWrite(wp, T("    ChangeDisplay('Device Management');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif
	} // show only for admin ]


	ifx_httpdWrite(wp, T("CreateNode('Diagnostics',null);\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('Diagnostic Test Suite','diagnostics_test_suite.asp','Diagnostics');\n"));
#ifdef CONFIG_FEATURE_IFX_VOIP
#ifdef CONFIG_IFX_DECT_SUPPORT
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('DECT Diag', 'diagnostics_dect.asp', 'Diagnostics');\n"));
#endif
#ifdef CONFIG_IFX_CVOIP_SUPPORT
  ifx_httpdWrite(wp,
           T
           ("    CreateSubNode('CVoIP Diagnostics', 'diagnostics.asp', 'Diagnostics');\n"));
#endif
	ifx_httpdWrite(wp,
		       T
		       ("    CreateSubNode('GR909 Line Testing','gr909lt_test.asp','Diagnostics');\n"));
	//ifx_httpdWrite(wp, T("    CreateSubNode('DECT','diagnostics.asp','Diagnostics');\n"));
#endif				//CONFIG_FEATURE_IFX_VOIP

//      ifx_httpdWrite(wp, T("ChangeDisplay('Diagnostics');\n"));
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#if defined(CONFIG_FEATURE_IFX_USB_HOST) || (CONFIG_PACKAGE_KMOD_LTQCPE_SATA_AHCI) || (CONFIG_FEATURE_SAMBA) || (CONFIG_FEATURE_MEDIA_SERVER)
	ifx_httpdWrite(wp, T("CreateNode('Content Sharing',null);\n"));
#if defined(CONFIG_FEATURE_IFX_USB_HOST) || defined(CONFIG_PACKAGE_KMOD_LTQCPE_SATA_AHCI)
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('USB / SATA','usb.asp','Content Sharing');\n"));
#endif				/* CONFIG_FEATURE_IFX_USB_HOST */
#ifdef CONFIG_FEATURE_SAMBA
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('SAMBA Server','samba_settings.asp','Content Sharing');\n"));
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('Share Management','share_mgmt.asp','Content Sharing');\n"));
#endif				/* CONFIG_PACKAGE_samba3 */
#ifdef CONFIG_FEATURE_MEDIA_SERVER
	ifx_httpdWrite(wp,
		       T
		       ("CreateSubNode('Media Server','dlna.asp','Content Sharing');\n"));
#endif				/* CONFIG_FEATURE_MEDIA_SERVER */
	ifx_httpdWrite(wp, T("document.write(\"</div>\"); \n"));
#endif
#endif				/* defined(CONFIG_FEATURE_IFX_TR69_DEVICE) || defined(CONFIG_FEATURE_LTQ_WIRELESS_VB) || defined(CONFIG_FEATURE_LTQ_HNX_CONFIG) */
	return 0;
}

int ifx_get_dhcp_server_module_enable(int eid, httpd_t wp, int argc,
				      char_t ** argv)
{
	int ret = 0;
	uint32 Flags = IFX_F_DEFAULT;
	ret = ifx_get_dhcp_server_module_support(Flags);
	if (ret == IFX_SUPPORTED)
		ifx_httpdWrite(wp, T("1"));
	else
		ifx_httpdWrite(wp, T("0"));
	return 0;
}

int ifx_get_firewall_module_enable(int eid, httpd_t wp, int argc,
				   char_t ** argv)
{
#ifdef CONFIG_FEATURE_FIREWALL
	ifx_httpdWrite(wp, T("1"));
#else
	ifx_httpdWrite(wp, T("0"));
#endif
	return 0;
}

int ifx_get_RuntimeWanIPMask(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_NAME_SIZE];
	char_t sCFG_NAME[MAX_NAME_SIZE];
	char_t link_name[MAX_FILELINE_LEN];
	uint32 outFlag = IFX_F_DEFAULT, count = 0;
	char *name = NULL, wanIp[MAX_IP_ADDR_LEN],
	       wanMask[MAX_IP_ADDR_LEN], wanStatus[MAX_NAME_LEN], wanGW[MAX_IP_ADDR_LEN];
	int nWanMode = IP_BOOT_UNKNOWN, i = 1, wanIpCnt =
	    0, wanPppCnt = 0;
	WAN_CONN_CFG wan_cfg, *p_wancfg = NULL;
	WAN_COMMON_CFG pWan;

	memset(&wan_cfg, 0x00, sizeof(wan_cfg));

	memset(wanIp, 0x00, sizeof(wanIp));

        memset(wanMask, 0x00, sizeof(wanMask));

        memset(wanStatus, 0x00, sizeof(wanStatus));

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}


	if (!gstrcmp(name, "STATUS") || !gstrcmp(name, "ALL_STATUS")) {

		if (ifx_get_sec_count(TAG_WAN_IP, &wanIpCnt) != IFX_SUCCESS) {
		}

		for (i = 0; i < wanIpCnt; i++) {
			wan_tuple_get(i, WAN_TYPE_IP, wanIp, wanMask, wanGW,
					wanStatus);

			if (gstrcmp(name, "STATUS")) {
				ifx_httpdWrite(wp, T("WANIP_%s[%d]=\"%s\";\n"),
					       "IP", i, wanIp);

				ifx_httpdWrite(wp, T("WANIP_%s[%d]=\"%s\";\n"),
					      "MASK", i, wanMask);
			}
			ifx_httpdWrite(wp, T("WANIP_%s[%d]=\"%s\";\n"),
					       "STATUS", i, wanStatus);
		}


		if (ifx_get_sec_count(TAG_WAN_PPP, &wanPppCnt) != IFX_SUCCESS) {
		}

		for (i = 0; i < wanPppCnt; i++) {
			wan_tuple_get(i, WAN_TYPE_PPP, wanIp, wanMask, wanGW,
					wanStatus);

			if (gstrcmp(name, "STATUS")) {
				ifx_httpdWrite(wp, T("WANPPP_%s[%d]=\"%s\";\n"),
					       "IP", i, wanIp);

				ifx_httpdWrite(wp, T("WANPPP_%s[%d]=\"%s\";\n"),
					      "MASK", i, wanMask);
			}
			ifx_httpdWrite(wp, T("WANPPP_%s[%d]=\"%s\";\n"),
					       "STATUS", i, wanStatus);
		}
	}


	if (!gstrcmp(name, "Mode")) {

		if (ifx_get_all_wan_config
		    (&wanIpCnt, WAN_TYPE_IP, &p_wancfg, IFX_F_DEFAULT)) {
		}

		for (i = 0; i < wanIpCnt; i++) {
			memset(&pWan, 0x00, sizeof(pWan));
			memset(link_name, 0x00, sizeof(link_name));

			GET_WAN_COMM_PTR(pWan, (p_wancfg + i))
			    get_atm_proto_name_by_id(link_name, pWan.link_type);
			ifx_httpdWrite(wp, T("IPATM_PROTO[%d]=\"%s\";\n"), i,
				       link_name);
			/* TBD: exising GetWanMode function to be enhanced to use reqd params frm struct arg to it instead of reading by itself */
			nWanMode = getWanMode(i, WAN_TYPE_IP);
			if (nWanMode == IFX_FAILURE || nWanMode > 6) {
				if (pWan.wan_mode.mode == WAN_MODE_PTM
						|| pWan.wan_mode.mode == WAN_MODE_VDSL_PTM
				    || pWan.wan_mode.mode == WAN_MODE_ETH0
				    || pWan.wan_mode.mode == WAN_MODE_ETH1
#ifdef CONFIG_FEATURE_WWAN_LTE_SUPPORT
				    || pWan.wan_mode.mode == WAN_MODE_LTE 
#endif
			){
					switch ((p_wancfg +
						 i)->wancfg.ip.addr_type) {
					case IP_TYPE_DHCP:
						nWanMode = IP_BOOT_DHCPC;
						break;
					case IP_TYPE_STATIC:
						nWanMode = IP_BOOT_FIXED;
						break;
					case IP_TYPE_AUTO:
						nWanMode = IP_BOOT_BRIDGE;
						break;
					}
				}	//manohar end
			}
			ifx_httpdWrite(wp, T("WANIP_TYPE[%d]=\"%d\";\n"), i,
				       nWanMode);
		}

		/* TBD: free p_wancfg before next use */
		IFX_MEM_FREE(p_wancfg)

		    if (ifx_get_all_wan_config
			(&wanPppCnt, WAN_TYPE_PPP, &p_wancfg, IFX_F_DEFAULT)) {
		}

		for (i = 0; i < wanPppCnt; i++) {
			GET_WAN_COMM_PTR(pWan, (p_wancfg + i))
			    get_atm_proto_name_by_id(link_name, pWan.link_type);
			ifx_httpdWrite(wp, T("PPPATM_PROTO[%d]=\"%s\";\n"), i,
				       link_name);

			if ((p_wancfg + i)->WAN_PPP_CONN.wan_cfg.link_type ==
			    WAN_LINK_TYPE_PPPOE)
				ifx_httpdWrite(wp,
					       T("WANPPP_TYPE[%d]=\"%d\";\n"),
					       i, IP_BOOT_PPPOE);
			else if ((p_wancfg +
				  i)->WAN_PPP_CONN.wan_cfg.link_type ==
				 WAN_LINK_TYPE_PPPOATM)
				ifx_httpdWrite(wp,
					       T("WANPPP_TYPE[%d]=\"%d\";\n"),
					       i, IP_BOOT_PPPOA);
		}
		/* TBD: free p_wancfg before next use */
		IFX_MEM_FREE(p_wancfg)
	}
	else if (!gstrcmp(name, "WANMode")) {
		if (ifx_get_sec_instance_count(TAG_WAN_IP, &count) != IFX_SUCCESS) {
		}

		for (i = 0; i < count; i++) {
			snprintf(sCFG_NAME,MAX_NAME_SIZE, "%s_%d_wanMode", PREFIX_WAN_IP, i);
	     		if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, sCFG_NAME, IFX_F_DEFAULT,
			    (IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS) {
			}
			ifx_httpdWrite(wp, "WANIP_MODE[%d]='%s';\n", i, sValue);
		}

		if (ifx_get_sec_instance_count(TAG_WAN_PPP, &count) != IFX_SUCCESS) {
		}

		for (i = 0; i < count; i++) {
			snprintf(sCFG_NAME,MAX_NAME_SIZE, "%s_%d_wanMode", PREFIX_WAN_PPP, i);
	     		if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, sCFG_NAME, IFX_F_DEFAULT,
			    (IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS) {
			}
			ifx_httpdWrite(wp, "WANPPP_MODE[%d]='%s';\n", i, sValue);
		}
	}
	else if (!gstrcmp(name, "g_wan_mode")) {
		ifx_httpdWrite(wp, "%d", global_wan_mode_get(IFX_F_DEFAULT));
	}
	return 0;
}

#ifdef CONFIG_FEATURE_IPv6

int ifx_get_RuntimeWanIP6(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sTAG_NAME[MAX_NAME_SIZE], sValue[MAX_NAME_SIZE];
	char_t sCFG_NAME[MAX_FILELINE_LEN], sNM6[MAX_IP_ADDR_LEN];
	char_t link_name[MAX_FILELINE_LEN]
	    /*sAtmProto[MAX_FILELINE_LEN] */ ;
	char_t conn_status[MAX_FILELINE_LEN];
	// IP_TYPE nWanType;
	uint32 outFlag = IFX_F_DEFAULT;
	char *name = NULL;
	int nWanMode = IP_BOOT_UNKNOWN, i = 1, j = 0, nWanCnt = 0, wipCnt =
	    0, wpppCnt = 0;
	WAN_CONN_CFG wan_cfg, *p_wancfg = NULL;
	WAN_COMMON_CFG pWan;
        char ovalue[16];
        char wan_id_dhcpv6state[32];
        char cmd[64];

	memset(&wan_cfg, 0x00, sizeof(wan_cfg));

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	if (!gstrcmp(name, "IPv6")) {
//IFX_DBG("[%s:%d] sec [%s]", __FUNCTION__, __LINE__, TAG_WAN_IP);
		if (ifx_get_sec_count(TAG_WAN_IP, &nWanCnt) != IFX_SUCCESS) {
		}
//IFX_DBG("[%s:%d] sec cnt [%d]", __FUNCTION__, __LINE__, nWanCnt);
		for (i = 0; i < nWanCnt; i++) {
			sNM6[0]='\0';
			memset(wan_id_dhcpv6state,'\0', 32);
			memset(ovalue,'\0', 16);
		snprintf(wan_id_dhcpv6state, sizeof(wan_id_dhcpv6state), "wanip_%d_dhcpv6State", i);
                        if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP , wan_id_dhcpv6state, IFX_F_DEFAULT, &outFlag, ovalue) == IFX_SUCCESS) {
                                /* printf("%s = %s\n", wan_id_dhcpv6state, ovalue); */
                                if(strcmp(ovalue, "1") == 0)  {/* SLAAC */
                                        snprintf(cmd, sizeof(cmd), "/etc/rc.d/bringup_wanstatus wanstatus %d \"ip\" && sync", i);
                                        system(cmd);
                                }
                        } else {
                                /* printf("GetObjData(\"wan_%d_dhcpv6State\") failed \n", i); */
                        }

//IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
			snprintf(sCFG_NAME, MAX_FILELINE_LEN,"WanIP%d_IF_IPv6_Info", i);

			if (ifx_GetObjData
			    (FILE_SYSTEM_STATUS, sCFG_NAME, name, IFX_F_GET_ENA,
			     (IFX_OUT uint32 *) & outFlag,
			     sNM6) != IFX_SUCCESS) {
				ifx_httpdWrite(wp, T("WANIP_STATUS[%d]=\"Undefined\";\n"), i);
			} else if (!gstrcmp(sNM6, "UNCONFIGURED")){
				ifx_httpdWrite(wp, T("WANIP_STATUS[%d]=\"UNCONFIGURED\";\n"), i);
				ifx_httpdWrite(wp, T("WANIP_%s[%d]=\"%s\";\n"),
					       name, i, sNM6);
			} else {
                                ifx_httpdWrite(wp, T("WANIP_STATUS[%d]=\"CONNECTED\";\n"), i);
				ifx_httpdWrite(wp, T("WANIP_%s[%d]=\"%s\";\n"),
					       name, i, sNM6);
                        } 
                      
		}

		if (ifx_get_sec_count(TAG_WAN_PPP, &nWanCnt) != IFX_SUCCESS) {
		}
		for (i = 0; i < nWanCnt; i++) {
			sNM6[0]='\0';
			memset(wan_id_dhcpv6state,'\0', 32);
			memset(ovalue,'\0', 16);
		snprintf(wan_id_dhcpv6state, sizeof(wan_id_dhcpv6state), "wanppp_%d_dhcpv6State", i);
                        if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP , wan_id_dhcpv6state, IFX_F_DEFAULT, &outFlag, ovalue) == IFX_SUCCESS) {
                                /* printf("%s = %s\n", wan_id_dhcpv6state, ovalue); */
                                if(strcmp(ovalue, "1") == 0)  {/* SLAAC */
                                        snprintf(cmd, sizeof(cmd), "/etc/rc.d/bringup_wanstatus wanstatus %d \"ppp\" && sync", i);
                                        system(cmd);
                                }
                        } else {
                                /* printf("GetObjData(\"wan_%d_dhcpv6State\") failed \n", i); */
                        }
			snprintf(sCFG_NAME, MAX_FILELINE_LEN, "WanPPP%d_IF_IPv6_Info", i);

			if (ifx_GetObjData
			    (FILE_SYSTEM_STATUS, sCFG_NAME, name, IFX_F_GET_ENA,
			     (IFX_OUT uint32 *) & outFlag,
			     sNM6) != IFX_SUCCESS) {
				ifx_httpdWrite(wp, T("WANPPP_STATUS[%d]=\"Undefined\";\n"), i);
			} else  if (!gstrcmp(sNM6, "UNCONFIGURED")){
				ifx_httpdWrite(wp, T("WANPPP_STATUS[%d]=\"UNCONFIGURED\";\n"), i);
				ifx_httpdWrite(wp, T("WANPPP_%s[%d]=\"%s\";\n"),
					       name, i, sNM6);
			} else {
                                ifx_httpdWrite(wp, T("WANPPP_STATUS[%d]=\"CONNECTED\";\n"), i);
				ifx_httpdWrite(wp, T("WANPPP_%s[%d]=\"%s\";\n"),
					       name, i, sNM6);
                        }
		}
	} else if (!gstrcmp(name, "All_Status")) {
		if (ifx_get_sec_count(TAG_WAN_IP, &wipCnt) != IFX_SUCCESS) {
		}
		if (ifx_get_sec_count(TAG_WAN_PPP, &wpppCnt) != IFX_SUCCESS) {
		}
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] sec ALL status loop [%s]", __FUNCTION__,
			__LINE__, TAG_WAN_IP);
#endif
		for (i = 0; i < wipCnt; i++) {
			wan_cfg.type = WAN_TYPE_IP;
			if (mapi_get_wan_config(i, &wan_cfg, IFX_F_DEFAULT)
			    == IFX_SUCCESS) {
				GET_WAN_COMM_PTR_1(pWan, wan_cfg)
				    switch (pWan.link_type) {
				case WAN_LINK_TYPE_EOATM:
				case WAN_LINK_TYPE_IPOATM:
				case WAN_LINK_TYPE_ETH:
				case WAN_LINK_TYPE_PTM:
				case WAN_LINK_TYPE_CLIP:	/* is an ip connection */
					switch (wan_cfg.WAN_IP_CONN.conn_status) {
					case WAN_IP_CONN_STATUS_UNCONFIGURED:
						sprintf(conn_status, "%s",
							"Unconfigured");
#ifdef IFX_LOG_DEBUG
				 IFX_DBG("[%s:%d] sec ALL status loop [%s]", __FUNCTION__,
                        __LINE__, TAG_WAN_IP);
#endif
						break;
					case WAN_IP_CONN_STATUS_CONNECTING:
						sprintf(conn_status, "%s",
							"Connecting");
						break;
					case WAN_IP_CONN_STATUS_CONNECTED:
						sprintf(conn_status, "%s",
							"Connected");
						break;
					case WAN_IP_CONN_STATUS_PENDING_DISCONNECT:
						sprintf(conn_status, "%s",
							"Pending Disconnect");
						break;
					case WAN_IP_CONN_STATUS_DISCONNECTING:
						sprintf(conn_status, "%s",
							"Disconnecting");
						break;
					case WAN_IP_CONN_STATUS_DISCONNECTED:
						sprintf(conn_status, "%s",
							"Disconnected");
						break;
					}
					ifx_httpdWrite(wp,
						       T
						       ("WANIP_STATUS[%d]=\"%s\";\n"),
						       i, conn_status);
					break;
				default:
					//      ifx_httpdWrite(wp, T("WAN_STATUS[%d]=\"Unconfigured\";\n"), i-1,sValue);
					break;
				}
			} else {
				snprintf(sTAG_NAME,MAX_FILELINE_LEN, "WanIP%d_IF_IPv6_Info", i);
				if (ifx_GetCfgData
				    (FILE_SYSTEM_STATUS, sTAG_NAME, "STATUS",
				     sValue) == 1) {
					for (j = 1; sValue[j] != '\0'; j++) {
						if (sValue[j] >= 65
						    && sValue[j] <= 91)
							sValue[j] =
							    sValue[j] + 32;
					}
					ifx_httpdWrite(wp,
						       T
						       ("WANIP_STATUS[%d]=\"%s\";\n"),
						       i, sValue);
				}
				else
					ifx_httpdWrite(wp, T("WANIP_STATUS[%d]=\"Unconfigured\";\n"), i-1);
			}
		}
		for (i = 0; i < wpppCnt; i++) {
			wan_cfg.type = WAN_TYPE_PPP;
			if (mapi_get_wan_config(i, &wan_cfg, IFX_F_DEFAULT)
			    == IFX_SUCCESS) {
				GET_WAN_COMM_PTR_1(pWan, wan_cfg)
				    switch (pWan.link_type) {
				case WAN_LINK_TYPE_PPPOATM:
				case WAN_LINK_TYPE_PPPOE:	/* is a ppp connection */
					switch (wan_cfg.WAN_PPP_CONN.
						conn_status) {
					case WAN_PPP_CONN_STATUS_UNCONFIGURED:
						sprintf(conn_status, "%s",
							"Unconfigured");
						break;
					case WAN_PPP_CONN_STATUS_CONNECTING:
						sprintf(conn_status, "%s",
							"Connecting");
						break;
					case WAN_PPP_CONN_STATUS_CONNECTED:
						sprintf(conn_status, "%s",
							"Connected");
						break;
					case WAN_PPP_CONN_STATUS_PENDING_DISCONNECT:
						sprintf(conn_status, "%s",
							"Pending Disconnect");
						break;
					case WAN_PPP_CONN_STATUS_DISCONNECTING:
						sprintf(conn_status, "%s",
							"Disconnecting");
						break;
					case WAN_PPP_CONN_STATUS_DISCONNECTED:
						sprintf(conn_status, "%s",
							"Disconnected");
						break;
					case WAN_PPP_CONN_STATUS_AUTHENTICATING:
						if (wan_cfg.WAN_PPP_CONN.
						    last_conn_error ==
						    WANPPP_LAST_CONN_ERROR_AUTHENTICATION_FAILURE)
							sprintf(conn_status,
								"%s",
								"Authentication Failure");
						else
							sprintf(conn_status,
								"%s",
								"Authenticating");
						break;
					}
					ifx_httpdWrite(wp,
						       T
						       ("WANPPP_STATUS[%d]=\"%s\";\n"),
						       i, conn_status);
					break;
				default:
					break;
				}
			} else {
				snprintf(sTAG_NAME,MAX_FILELINE_LEN, "WanPPP%d_IF_IPv6_Info", i);
				memset(sValue, 0x00, sizeof(sValue));
				if (ifx_GetCfgData
				    (FILE_SYSTEM_STATUS, sTAG_NAME, "STATUS",
				     sValue) == 1) {
					for (j = 1; sValue[j] != '\0'; j++) {
						if (sValue[j] >= 65
						    && sValue[j] <= 91)
							sValue[j] =
							    sValue[j] + 32;
					}
					ifx_httpdWrite(wp,
						       T
						       ("WANPPP_STATUS[%d]=\"%s\";\n"),
						       i, sValue);
				}
				else
					ifx_httpdWrite(wp, T("WANPPP_STATUS[%d]=\"Unconfigured\";\n"), i-1,sValue);
			}
		}
	}
#if 0
	/* TBD: Unused code ? */
	else if (!gstrcmp(name, "Status")) {
		sprintf(sTAG_NAME, "Wan%s_IF_Info", name);
		if (ifx_GetCfgData
		    (FILE_SYSTEM_STATUS, sTAG_NAME, "STATUS", sValue) == 1) {
			for (j = 1; sValue[j] != '\0'; j++) {
				if (sValue[j] >= 65 && sValue[j] <= 91)
					sValue[j] = sValue[j] + 32;
			}
			ifx_httpdWrite(wp, T("%s"), sValue);
		}
		//      else
		//      ifx_httpdWrite(wp, T("Unconfigured"), i-1,sValue);
	}
#endif				// 0
	else if (!gstrcmp(name, "Mode")) {
#if 0
		for (i = 1; i <= MAX_VCCs; i++) {
			link_name[0] = '\0';
			sAtmProto[0] = '\0';

			sprintf(sTAG_NAME, "wan_%d_linkType", i);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_WAN_MAIN, sTAG_NAME,
			     IFX_F_DEFAULT, (IFX_OUT uint32 *) & outFlag,
			     sAtmProto) != IFX_SUCCESS) {
				//ifx_httpdWrite(wp, T("ATM_PROTO[%d]=\"0\";\n"), i - 1);
			} else {
				get_atm_proto_name_by_id(link_name,
							 atoi(sAtmProto));
				ifx_httpdWrite(wp, T("ATM_PROTO[%d]=\"%s\";\n"),
					       i - 1, link_name);
			}

			if ((nWanMode = GetWanMode(i)) == IFX_FAILURE) {
				//ifx_httpdWrite(wp, T("WAN_TYPE[%d]=%d;\n"), i - 1, IP_BOOT_UNKNOWN);
			} else {	//Manohar start
				if (nWanMode == IP_BOOT_ETH
				    || nWanMode == IP_BOOT_PTM) {
					if (ifx_get_wanip_conn_type
					    (&nWanType, i) == IFX_SUCCESS) {
						switch (nWanType) {
						case IP_TYPE_DHCP:
							nWanMode =
							    IP_BOOT_DHCPC;
							break;
						case IP_TYPE_STATIC:
							nWanMode =
							    IP_BOOT_FIXED;
							break;
						case IP_TYPE_AUTO:
							nWanMode =
							    IP_BOOT_BRIDGE;
							break;
						}
					}
				}	//manohar end
				ifx_httpdWrite(wp, T("WAN_TYPE[%d]=%d;\n"),
					       i - 1, nWanMode);
			}
		}
#endif

//IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		if (ifx_get_all_wan_config
		    (&wipCnt, WAN_TYPE_IP, &p_wancfg, IFX_F_DEFAULT)) {
		}
//IFX_DBG("[%s:%d] wipCnt [%d]", __FUNCTION__, __LINE__, wipCnt);

		for (i = 0; i < wipCnt; i++) {
//IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
			memset(&pWan, 0x00, sizeof(pWan));
			memset(link_name, 0x00, sizeof(link_name));

			GET_WAN_COMM_PTR(pWan, (p_wancfg + i))
			    get_atm_proto_name_by_id(link_name, pWan.link_type);
			ifx_httpdWrite(wp, T("IPATM_PROTO[%d]=\"%s\";\n"), i,
				       link_name);
			/* TBD: exising GetWanMode function to be enhanced to use reqd params frm struct arg to it instead of reading by itself */
			nWanMode = getWanMode(i, WAN_TYPE_IP);
			if (nWanMode == IFX_FAILURE || nWanMode > 6) {
				if (pWan.wan_mode.mode == WAN_MODE_PTM
						|| pWan.wan_mode.mode == WAN_MODE_VDSL_PTM
				    || pWan.wan_mode.mode == WAN_MODE_ETH0
				    || pWan.wan_mode.mode == WAN_MODE_ETH1) {

					switch ((p_wancfg +
						 i)->wancfg.ip.addr_type) {
					case IP_TYPE_DHCP:
						nWanMode = IP_BOOT_DHCPC;
						break;
					case IP_TYPE_STATIC:
						nWanMode = IP_BOOT_FIXED;
						break;
					case IP_TYPE_AUTO:
						nWanMode = IP_BOOT_BRIDGE;
						break;
					}
				}	//manohar end
			}
			ifx_httpdWrite(wp, T("WANIP_TYPE[%d]=\"%d\";\n"), i,
				       nWanMode);
		}

		/* TBD: free p_wancfg before next use */
		IFX_MEM_FREE(p_wancfg)

		    if (ifx_get_all_wan_config
			(&wpppCnt, WAN_TYPE_PPP, &p_wancfg, IFX_F_DEFAULT)) {
		}

		for (i = 0; i < wpppCnt; i++) {
			GET_WAN_COMM_PTR(pWan, (p_wancfg + i))
			    get_atm_proto_name_by_id(link_name, pWan.link_type);
			ifx_httpdWrite(wp, T("PPPATM_PROTO[%d]=\"%s\";\n"), i,
				       link_name);

			if ((p_wancfg + i)->WAN_PPP_CONN.wan_cfg.link_type ==
			    WAN_LINK_TYPE_PPPOE)
				ifx_httpdWrite(wp,
					       T("WANPPP_TYPE[%d]=\"%d\";\n"),
					       i, IP_BOOT_PPPOE);
			else if ((p_wancfg +
				  i)->WAN_PPP_CONN.wan_cfg.link_type ==
				 WAN_LINK_TYPE_PPPOATM)
				ifx_httpdWrite(wp,
					       T("WANPPP_TYPE[%d]=\"%d\";\n"),
					       i, IP_BOOT_PPPOA);
		}
		/* TBD: free p_wancfg before next use */
		IFX_MEM_FREE(p_wancfg)
	}
	return 0;
}

#endif

int ifx_get_LanIPMask(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name = NULL;
	char_t sValue[MAX_IP_ADDR_LEN];

	memset(sValue, 0x00, MAX_IP_ADDR_LEN);

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	if (!strcmp(name, "IP"))
		websGetIFInfo(LAN_IF_TYPE, IP_INFO, 1, 4, FALSE, NULL, sValue);
	else if (!strcmp(name, "MASK"))
		websGetIFInfo(LAN_IF_TYPE, MASK_INFO, 1, 4, FALSE, NULL,
			      sValue);

	ifx_httpdWrite(wp, sValue);
	return 0;
}

int ifx_get_all_lan_conn_names(char **lan_conn_names, int *count)
{
	int32 ret = IFX_SUCCESS, flags = IFX_F_DEFAULT, outFlag =
	    IFX_F_DEFAULT, tmp_count = 0, i = 0;
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];

	*lan_conn_names = NULL;

	sprintf(buf, "%s_Count", TAG_LAN_MAIN);
	memset(sValue, 0x00, sizeof(sValue));
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, buf, flags,
			    (IFX_OUT uint32 *) & outFlag,
			    sValue)) != IFX_SUCCESS) {
		*count = 0;
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> No wan devices found configured !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}

	tmp_count = *count = atoi(sValue);
	if (atoi(sValue) <= 0)
		return IFX_SUCCESS;

//      *lan_conn_names = (char8 *)calloc(tmp_count, MAX_NAME_LEN);
	if ((tmp_count > 0) && (tmp_count < MAX_NAME_LEN)) {
		*lan_conn_names = (char8 *) calloc(tmp_count, MAX_NAME_LEN);
		for (i = 0; i < tmp_count; i++) {
			/* since lan connection name is not a parameter inside lan object,
			   we hard code the name to be LAN{i} */
			sprintf(((*lan_conn_names) + (i * MAX_NAME_LEN)),
				"LAN%d", i);
		}
	}
      IFX_Handler:
	if (ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;

}

int ifx_get_all_wan_conn_names(char **wan_conn_names, int *count)
{
	int32 i, n = 0,ret = IFX_SUCCESS, flags = IFX_F_DEFAULT, outFlag =
	    IFX_F_DEFAULT, tmp_count = 0, wanIpCnt, wanPppCnt;
	char8 buf[MAX_FILELINE_LEN], sIndxes[MAX_FILELINE_LEN],
	    sValue[MAX_FILELINE_LEN];
	WAN_PHY_CFG pstWanPhy;
        ifx_get_wan_phy_cfg(&pstWanPhy);

	*wan_conn_names = NULL;

	/* WANIP */
	sprintf(buf, "%s", "wan_ip_Count");
	memset(sValue, 0x00, sizeof(sValue));
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags,
			    (IFX_OUT uint32 *) & outFlag,
			    sIndxes)) != IFX_SUCCESS) {
		*count = 0;
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> No wan devices found configured !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}

	wanIpCnt = atoi(sIndxes);
	for (i = 0; i < wanIpCnt; i++) {
		*wan_conn_names =
		    (char8 *) realloc(*wan_conn_names,
				      (tmp_count + 1) * MAX_NAME_LEN);
		sprintf(buf, "wanip_%d_connName", i);
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_WAN_IP, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("\n\nIn Function [%s] : Wan connection name not found for wan (IP) index [%d] !!\n\n",
			     __FUNCTION__, i);
#endif
			goto IFX_Handler;
		} else {
			sprintf(((*wan_conn_names) +
				 (tmp_count * MAX_NAME_LEN)), "%s", sValue);
		}
		tmp_count++;
	}

	/* WANPPP */
	sprintf(buf, "%s", "wan_ppp_Count");
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			    (IFX_OUT uint32 *) & outFlag,
			    sIndxes)) != IFX_SUCCESS) {
		*count = 0;
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> No wan devices found configured !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}

	wanPppCnt = atoi(sIndxes);


#if defined(CONFIG_FEATURE_CELL_WAN_SUPPORT)
	if (pstWanPhy.phy_mode == WAN_PHY_MODE_CELL_WAN) 
		n=0;
	else
		n=1;
#endif
	for (i = n; i < wanPppCnt; i++) 
	{
		*wan_conn_names =
		    (char8 *) realloc(*wan_conn_names,
				      (tmp_count + 1) * MAX_NAME_LEN);
		sprintf(buf, "wanppp_%d_connName", i);
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("\n\nIn Function [%s] : Wan connection name not found for wan (PPP) index [%d] !!\n\n",
			     __FUNCTION__, i);
#endif
			goto IFX_Handler;
		} else {
			sprintf(((*wan_conn_names) +
				 (tmp_count * MAX_NAME_LEN)), "%s", sValue);
		}
		tmp_count++;
	}

	*count = tmp_count;

      IFX_Handler:
	if (ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;

}


int ifx_get_all_wan_confconn_names(char **wan_conn_names, int *count)
{
	int32 i, n = 0,ret = IFX_SUCCESS, flags = IFX_F_DEFAULT, outFlag =
	    IFX_F_DEFAULT, tmp_count = 0, wanIpCnt, wanPppCnt;
	char8 buf[MAX_FILELINE_LEN], sIndxes[MAX_FILELINE_LEN],
	    sValue[MAX_FILELINE_LEN];
	WAN_PHY_CFG pstWanPhy;
        ifx_get_wan_phy_cfg(&pstWanPhy);

	*wan_conn_names = NULL;

	/* WANIP */
	sprintf(buf, "%s", "wan_ip_Count");
	memset(sValue, 0x00, sizeof(sValue));
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags,
			    (IFX_OUT uint32 *) & outFlag,
			    sIndxes)) != IFX_SUCCESS) {
		*count = 0;
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> No wan devices found configured !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}

	wanIpCnt = atoi(sIndxes);
	for (i = 0; i < wanIpCnt; i++) {
		*wan_conn_names =
		    (char8 *) realloc(*wan_conn_names,
				      (tmp_count + 1) * MAX_NAME_LEN);
		sprintf(buf, "wanip_%d_confconnName", i);
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_WAN_IP, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("\n\nIn Function [%s] : Wan connection name not found for wan (IP) index [%d] !!\n\n",
			     __FUNCTION__, i);
#endif
			goto IFX_Handler;
		} else {
			sprintf(((*wan_conn_names) +
				 (tmp_count * MAX_NAME_LEN)), "%s", sValue);
		}
		tmp_count++;
	}

	/* WANPPP */
	sprintf(buf, "%s", "wan_ppp_Count");
	if ((ret =
	     ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			    (IFX_OUT uint32 *) & outFlag,
			    sIndxes)) != IFX_SUCCESS) {
		*count = 0;
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error--> No wan devices found configured !!\n\n",
		     __FUNCTION__);
#endif
		goto IFX_Handler;
	}

	wanPppCnt = atoi(sIndxes);


#if defined(CONFIG_FEATURE_CELL_WAN_SUPPORT)
	if (pstWanPhy.phy_mode == WAN_PHY_MODE_CELL_WAN) 
		n=0;
	else
		n=1;
#endif
	for (i = n; i < wanPppCnt; i++) 
	{
		*wan_conn_names =
		    (char8 *) realloc(*wan_conn_names,
				      (tmp_count + 1) * MAX_NAME_LEN);
		sprintf(buf, "wanppp_%d_confconnName", i);
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
		     (IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("\n\nIn Function [%s] : Wan connection name not found for wan (PPP) index [%d] !!\n\n",
			     __FUNCTION__, i);
#endif
			goto IFX_Handler;
		} else {
			sprintf(((*wan_conn_names) +
				 (tmp_count * MAX_NAME_LEN)), "%s", sValue);
		}
		tmp_count++;
	}

	*count = tmp_count;

      IFX_Handler:
	if (ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;

}

int ifx_get_DhcpClientNum(int eid, httpd_t wp, int argc, char_t ** argv)
{
	/* Initialization Block */
	int ret;
	uint32 flags = IFX_F_DEFAULT;

	ifx_httpdWrite(wp, "document.write(\"<tr>\");\n");
	ifx_httpdWrite(wp,
		       "document.write(\"<td colspan='1'>Connected Clients</td>\");\n");
	ifx_httpdWrite(wp, "document.write(\"<td colspan='2'>\");\n");

	/* API Call Block */
	ret = ifx_get_num_dhcp_clients(flags);

	/* Error Check and HTML Block */
	if (ret != -1) {
		ifx_httpdWrite(wp, T("document.write(\"%d</td></span></tr>\");\n"), ret);	//str);
	} else
		ifx_httpdError(wp, 500, "Error");

	return 0;
}

int ifx_get_RuntimeCodeVersion(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sCommand[MAX_DATA_LEN];
	char_t sValue[MAX_DATA_LEN];
	gsprintf(sCommand, "cat /proc/version | cut -f3,13-20 -d\" \"");
	memset(sValue, 0x00, sizeof(sValue));
	if (ifx_GetCfgData((char_t *) sCommand, NULL, "1", sValue) == 0) {
		ifx_httpdError(wp, 500, "uname command not found");
		return -1;
	}
	ifx_httpdWrite(wp, sValue);
	return 0;
}

int ifx_get_Hardwareversion(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, HARDWARE_VER);
	return 0;
}

int ifx_get_WANStaticVLAN(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
	char_t sValue[MAX_FILENAME_LEN];
	char_t command[MAX_FILENAME_LEN];
	char_t sTAG_NAME[MAX_WEB_DATA];
//	uint32 outFlag = IFX_F_DEFAULT; 
	char var[20];
	int nWAN_IDX = -1;
//	WAN_TYPE sWAN_TYPE; 
	memset(sValue, 0x00, sizeof(sValue));

/*	IFX_GET_WAN_SELECTED_INDEX(IFX_F_GET_ENA, outFlag, sValue, nWAN_IDX,
				   sWAN_TYPE)*/   

	    if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	memset(sValue, 0x00, sizeof(sValue));
	memset(command, 0x00, sizeof(command));

	sprintf(sTAG_NAME, "%s%d", TAG_WAN_VLAN, nWAN_IDX);

	if (!gstrcmp(name, T("VID"))) {
		sprintf(var, "VID%d", nWAN_IDX);
		if (ifx_GetCfgData(FILE_RC_CONF, sTAG_NAME, var, sValue) == 1) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		}
	} else if (!gstrcmp(name, T("VPRIO"))) {
		sprintf(var, "VPRIO%d", nWAN_IDX);
		if (ifx_GetCfgData(FILE_RC_CONF, sTAG_NAME, var, sValue) == 1) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		}
	} else if (!gstrcmp(name, T("VTAG"))) {
		sprintf(var, "VTAG%d", nWAN_IDX);
		if (ifx_GetCfgData(FILE_RC_CONF, sTAG_NAME, var, sValue) == 1) {
			if (!gstrcmp(sValue, "1"))
				ifx_httpdWrite(wp, T("checked"));
			else
				ifx_httpdWrite(wp, T(""));
		}
	} else if (!gstrcmp(name, T("VUNTAG"))) {
		sprintf(var, "VUNTAG%d", nWAN_IDX);
		if (ifx_GetCfgData(FILE_RC_CONF, sTAG_NAME, var, sValue) == 1) {
			if (!gstrcmp(sValue, "1"))
				ifx_httpdWrite(wp, T("checked"));
			else
				ifx_httpdWrite(wp, T(""));
		}
	}
	return IFX_SUCCESS;
}

#ifdef SIP_QOS
int ifx_get_sip(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name;
	char_t sValue[MAX_FILELINE_LEN];
	int i = 0, nSip_Size = 0;
	CGI_TABLE_S SipTable[SIP_TABLE_NUM];
#define FORMAT_LINE "\t\t\t\t<td nowrap align=center><font face=\"Arial, Helvetica, sans-serif\" size=\"2\">"

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	sValue[0] = '\0';

	if (!gstrcmp(name, T("SIP_STATUS"))) {
		IFX_WRITE_CHECKBOX_STATUS(TAG_SIP_MAIN, "SIP_STATUS", sValue)
	} else if (!gstrcmp(name, T("SIP_MAXBW"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_SIP_MAIN, T("SIP_MAXBW"), sValue)) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		}

	} else if (!gstrcmp(name, T("SIP_MINBW"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_SIP_MAIN, T("SIP_MINBW"), sValue)) {
			ifx_httpdWrite(wp, T("%s"), sValue);
		}

	} else if (!gstrcmp(name, T("Info"))) {
		nSip_Size =
		    websGetCfgData2Table(wp, FILE_RC_CONF, TAG_SIP_INFO,
					 PREFIX_SIP, SipTable, SIP_TABLE_TYPE);

		for (i = 0; i < nSip_Size && i < SIP_TABLE_NUM; i++) {
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t<tr bgcolor=\"#ffffff\" align=left>\n"));
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t<td nowrap align=center>%d</td>\n"),
				       i + 1);
			ifx_httpdWrite(wp, T(FORMAT_LINE));
			ifx_httpdWrite(wp, T("%s</font></td>\n"),
				       SipTable[i].Data.SIP_TABLE.
				       sSIP_PHONE_IP);

			ifx_httpdWrite(wp, T(FORMAT_LINE));
			if (atoi(SipTable[i].Data.SIP_TABLE.sSIP_PROTOCOL) ==
			    PROTO_TCP) {
				ifx_httpdWrite(wp, T("TCP</font>\n"));
			} else
			    if (atoi(SipTable[i].Data.SIP_TABLE.sSIP_PROTOCOL)
				== PROTO_UDP) {
				ifx_httpdWrite(wp, T("UDP</font>\n"));
			}

			ifx_httpdWrite(wp, T(FORMAT_LINE));
			ifx_httpdWrite(wp, T("%s</font></td>\n"),
				       SipTable[i].Data.SIP_TABLE.sSIP_PORT);

			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t<td nowrap align=center><input type=\"checkbox\" name=\"SIP_E%d\" value=\"1\"%s></td>\n"),
				       i,
				       SipTable[i].nState ? " CHECKED" : " ");

			ifx_httpdWrite(wp,
				       T("\t\t\t\t<td nowrap align=center>\n"));
			if (i < nSip_Size) {
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t<input type=\"button\" name=\"SIP_DEL%d\" value=\" Delete \" onClick=\"return delEntry(%d);\">\n"),
					       i, i);
			}
			ifx_httpdWrite(wp, T("\t\t\t\t</td></tr>\n"));

		}		//end for
	}

	return 0;
}
#endif

/* This function checks if there are any portmap entries configured on this wan connection
   If so it writes failure -1 else if wan connection itself is diabled it writes -2 else it writes 0
 */

#ifdef CONFIG_FEATURE_IFX_MULTIPLE_VCCS
int ifx_get_vcc_select(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char *name;
	char_t sValue[MAX_NAME_SIZE];
	int32 count = 0;
	memset(sValue, 0x00, sizeof(MAX_NAME_SIZE));

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	if (!gstrcmp("CURRENT_WAN", name)) {
		if (ifx_GetCfgData
		    (FILE_SYSTEM_STATUS, "http_wan_vcc_select", "WAN_VCC",
		     sValue) == 1)
			ifx_httpdWrite(wp, T("%s"), sValue);
		else
			ifx_httpdWrite(wp, T("1"));
	} else if (!gstrcmp("MAX_VCCs", name)) {
		ifx_httpdWrite(wp, T("%d"), MAX_VCCs);
	} else if (!strcmp(name, "ch_count")) {
		if (ifx_get_sec_count(TAG_VLAN_CFG, &count) ==
		    IFX_SUCCESS) {
			ifx_httpdWrite(wp, "%d", count);
		} else {
			ifx_httpdWrite(wp, "%d", 0);
		}
	} else if (!strcmp(name, "WAN_COUNT")) {
		/* TBD : When generic VLAN framework for multi WAN comes in,
		 * count needs to be returned that of VLAN channel section
		 */
		if (ifx_get_sec_count(TAG_WAN_CONN_DEVICE, &count) ==
		    IFX_SUCCESS) {
			ifx_httpdWrite(wp, "%d", count);
		} else {
			ifx_httpdWrite(wp, "%d", 0);
		}
	}
	return 0;
}
#endif

#ifdef CONFIG_FEATURE_IFX_UPNP
//upnp_config.asp
int ifx_get_UpnpStatus(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_DATA_LEN];

	sValue[0] = '\0';
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_UPNPCONFIG, T("upnp_enable"), sValue) == 0) {
		ifx_httpdError(wp, 500, "UPNP status not found");
		return -1;
	}
	if (!gstrcmp(sValue, "YES"))	// Upnp is enabled
		ifx_httpdWrite(wp, T("checked"));
	else
		ifx_httpdWrite(wp, T(""));
	return 0;
}
#endif

#if defined (CONFIG_FEATURE_LTQ_WIRELESS_VB) || defined (CONFIG_FEATURE_LTQ_WIRELESS_STA_SUPPORT)
int get_VbMode()
{
	int ret = IFX_FAILURE;
	uint32 flags = IFX_F_DEFAULT;
	ret = ltq_mapi_get_vb_mode(flags);
	if (ret != IFX_FAILURE)
		return ret;
	else
		return IFX_FAILURE;
}
#endif				/* #ifdef CONFIG_FEATURE_LTQ_WIRELESS_VB */

#ifdef CONFIG_FEATURE_DHCP_SERVER
//////////////////////////////////////////////////////////////////////////////////
// lan_dhcps.asp; lan_nodhcp.asp
//

int get_DhcpStatus()
{
	int ret = IFX_FAILURE;
	uint32 flags = IFX_F_DEFAULT;
	ret = ifx_get_dhcp_server_mode(flags);
	if (ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}

int ifx_get_DhcpStatus(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int ret = 0;
	ret = get_DhcpStatus();
	if (ret != IFX_FAILURE)
		ifx_httpdWrite(wp, T("%d"), ret);
	else
		ifx_httpdError(wp, 500, "Error:Data not found in the file");
	return 0;
}
#endif				//CONFIG_FEATURE_DHCP_SERVER

#ifdef CONFIG_FEATURE_IFX_WIRELESS_ATH
static CGI_ENUMSEL_S WirelessEnable_List[] = {
	{0, "disable"},
	{1, "enable"},
};
#endif

void ifx_get_device_mode(int eid, httpd_t wp, int argc, char_t ** argv)
{
#ifdef CONFIG_FEATURE_IFX_TR69_DEVICE
	ifx_httpdWrite(wp, T("%d"), IFX_PRODUCT_CLASS_DEVICE);
#else
	ifx_httpdWrite(wp, T("%d"), IFX_PRODUCT_CLASS_IGD);
#endif				// CONFIG_FEATURE_IFX_TR69_DEVICE
}

#ifdef CONFIG_FEATURE_IFX_WIRELESS_ATH

CGI_ENUMSEL_S web_Enum_ChannelMode_List[] = {
	{0, "         "},
	{1, "Channel 1"},
	{2, "Channel 2"},
	{3, "Channel 3"},
	{4, "Channel 4"},
	{5, "Channel 5"},
	{6, "Channel 6"},
	{7, "Channel 7"},
	{8, "Channel 8"},
	{9, "Channel 9"},
	{10, "Channel 10"},
	{11, "Channel 11"},
	{12, "Channel 12"},
	{13, "Channel 13"},
	{14, "Channel 14"}
};

CGI_ENUMSEL_S web_Enum_SSIDMode_List[] = {
	{0, "Advertise SSID"},
	{1, "Hide SSID"},
};

CGI_ENUMSEL_S web_Enum_OPRateMode_List[] = {
	{0, "Auto"},
	{1, "802.11A Mode"},
	{2, "802.11B Mode"},
	{3, "802.11G Mode"},
};

CGI_ENUMSEL_S web_Enum_PreambleMode_List[] = {
	{0, "               "},
	{1, "Long Preamble"},
	{2, "Auto"}
};

CGI_ENUMSEL_S web_Enum_CTS_List[] = {
	{0, "OFF"},
	{1, "ON"}
};

CGI_ENUMSEL_S web_Enum_PowerLevel_List[] = {
	{0, "1 (20%)"},
	{1, "2 (40%)"},
	{2, "3 (60%)"},
	{3, "4 (80%)"},
	{4, "5 (100%)"}
};

CGI_ENUMSEL_S web_Enum_Domain_List[] = {
	{0, "FCC"},
	{1, "IC"},
	{2, "ETSI"},
	{3, "Spain"},
	{4, "France"},
	{5, "MKK"},
	{6, "MKKII"}
};

int g_nRegulationDomain = 0;	//default 0:FCC,

int ifx_get_wlan_settings(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name, sValue[MAX_FILELINE_LEN];
	int i, nSelIdx = 0;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	sValue[0] = '\0';
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_DOMAIN", sValue) == 1) {
		/* Get the regulation domain */
		nSelIdx = gatoi(sValue);
		g_nRegulationDomain = nSelIdx;
	}

	if (!gstrcmp(name, T("channel")) || !gstrcmp(name, T("ProvChannel"))) {
		int nOperateIdx = -1;
		int nMinChannel = 1, nMaxChannel = 14;
		//for Operation mode select box
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_OP_RATE",
		     sValue) == 1) {
			nOperateIdx = gatoi(sValue);
		}

		sValue[0] = '\0';
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_CHANNEL",
		     sValue) == 1) {
			nSelIdx = gatoi(sValue);

			if (!gstrcmp(name, T("ProvChannel"))) {
				if (nSelIdx == 1 || nSelIdx == 6
				    || nSelIdx == 11)
					ifx_httpdWrite(wp, sValue);
				return 0;
			}

			switch (g_nRegulationDomain) {
			case 0:
			case 1:
				nMinChannel = 1;
				nMaxChannel = 11;
				break;
			case 2:
				nMinChannel = 1;
				nMaxChannel = 13;
				break;
			case 3:
				nMinChannel = 10;
				nMaxChannel = 11;
				break;
			case 4:
				nMinChannel = 10;
				nMaxChannel = 13;
				break;
			case 5:
				nMinChannel = 14;
				nMaxChannel = 14;
				break;
			case 6:
				nMinChannel = 1;
				nMaxChannel = 14;
				break;
			}

			for (i = nMinChannel; i <= nMaxChannel; i++) {
				if (i == nSelIdx) {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t\t<option value=\"%d\""
							" SELECTED>%s</option>\n"),
						       i,
						       web_Enum_ChannelMode_List
						       [i].str);
				} else {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t\t<option value=\"%d\">"
							"%s</option>\n"), i,
						       web_Enum_ChannelMode_List
						       [i].str);
				}
			}
		}
	} else if (!gstrcmp(name, T("hiddenSsid"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_HIDDEN_SSID",
		     sValue) == 1) {
			nSelIdx = gatoi(sValue);

			for (i = 0;
			     i <
			     sizeof(web_Enum_SSIDMode_List) /
			     sizeof(CGI_ENUMSEL_S); i++) {
				if (i == nSelIdx) {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t\t<option value=\"%d\" SELECTED>%s</option>\n"),
						       i,
						       web_Enum_SSIDMode_List
						       [i].str);
				} else {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t\t<option value=\"%d\">%s</option>\n"),
						       i,
						       web_Enum_SSIDMode_List
						       [i].str);
				}
			}
		}
	} else
	    if (!gstrcmp(name, T("DTIMInterval")) ||
		!gstrcmp(name, T("ProvDTIMInterval"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_DTIM_INTERVAL",
		     sValue) == 1) {
			if (!gstrcmp(name, T("ProvDTIMInterval"))) {
				ifx_httpdWrite(wp, sValue);
				return 0;
			}

			ifx_httpdWrite(wp,
				       "<tr><td width=\"48%\" height=\"29\">");
			ifx_httpdWrite(wp,
				       "<font class=\"subtitle\">DTIM Interval"
				       "</font></td>");
			ifx_httpdWrite(wp, "<td width=\"54%\" height=\"29\">");
			ifx_httpdWrite(wp,
				       "<input type=\"text\" name=\"dtim_intval\" "
				       "value=\"%s\" maxlength=\"3\">", sValue);
			ifx_httpdWrite(wp, "</td></tr>");
		}
	} else if (!gstrcmp(name, T("evaltDTIM"))) {
		ifx_httpdWrite(wp, "if(DTIMIntervalNotInRange(document.tF0."
			       "dtim_intval.value)) {");
		ifx_httpdWrite(wp, "alert(ipm4); return false; }");
	} else if (!gstrcmp(name, T("cts")) || !gstrcmp(name, T("ProvCts"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_CTS",
		     sValue) == 1) {
			if (!gstrcmp(name, T("ProvCts"))) {
				ifx_httpdWrite(wp, sValue);
				return 0;
			}

			ifx_httpdWrite(wp,
				       "<tr><td width=\"48%\" height=\"33\">");
			ifx_httpdWrite(wp,
				       "<font class=\"subtitle\">CTS Protection "
				       "Mode</font></td>");
			ifx_httpdWrite(wp, "<td width=\"54%\" height=\"33\">");
			ifx_httpdWrite(wp, "<select name=\"cts_mode\">");

			for (i = 0;
			     i <
			     sizeof(web_Enum_CTS_List) / sizeof(CGI_ENUMSEL_S);
			     i++) {
				if (i == atoi(sValue)) {
					ifx_httpdWrite(wp,
						       T("<option value=\"%d\""
							 " SELECTED>%s</option>\n"),
						       web_Enum_CTS_List[i].
						       value,
						       web_Enum_CTS_List[i].
						       str);
				} else {
					ifx_httpdWrite(wp,
						       T("<option value=\"%d\">"
							 "%s</option>\n"),
						       web_Enum_CTS_List[i].
						       value,
						       web_Enum_CTS_List[i].
						       str);
				}
			}

			ifx_httpdWrite(wp, "</select></td></tr>");
		}
	} else
	    if (!gstrcmp(name, T("PowerLevel")) ||
		!gstrcmp(name, T("txpower")) ||
		!gstrcmp(name, T("ProvTxPower"))) {
		CGI_ENUMSEL_S *pPowerLevelList = web_Enum_PowerLevel_List;
		if (ifx_GetCfgData(FILE_RC_CONF, TAG_WLAN_SETTINGS,
				   "WLAN_POWER_LEVEL", sValue) == 1) {
			nSelIdx = gatoi(sValue);

			if (!gstrcmp(name, T("ProvTxPower"))) {
				switch (nSelIdx) {
				case 0:
					strcpy(sValue, "20%");
					break;
				case 1:
					strcpy(sValue, "40%");
					break;
				case 2:
					strcpy(sValue, "60%");
					break;
				case 3:
					strcpy(sValue, "80%");
					break;
				case 4:
					strcpy(sValue, "100%");
					break;
				}
				ifx_httpdWrite(wp, sValue);
				return 0;
			} else if (!gstrcmp(name, T("txpower"))) {
				ifx_httpdWrite(wp, T("%d"), nSelIdx);
				return 0;
			}

			pPowerLevelList = web_Enum_PowerLevel_List;

			for (i = 0; i < 5; i++) {
				if (i == nSelIdx) {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t\t<option value=\"%d\" SELECTED>%s</option>\n"),
						       i,
						       pPowerLevelList[i].str);
				} else {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t\t<option value=\"%d\">%s</option>\n"),
						       i,
						       pPowerLevelList[i].str);
				}
			}
		}
	} else
	    if (!gstrcmp(name, T("RegulationDomain")) ||
		!gstrcmp(name, T("ProvDomain")) ||
		!gstrcmp(name, T("seldomain"))) {
		if (!gstrcmp(name, T("ProvDomain"))) {
			if (!strcmp
			    (web_Enum_Domain_List[g_nRegulationDomain].str,
			     "FCC"))
				strcpy(sValue, "ALL");
			else
				strcpy(sValue,
				       web_Enum_Domain_List
				       [g_nRegulationDomain].str);

			ifx_httpdWrite(wp, sValue);
			return 0;
		}

		if (!gstrcmp(name, T("seldomain"))) {
			ifx_httpdWrite(wp, T("%d"), g_nRegulationDomain);
			return 0;
		}

		for (i = 0;
		     i < sizeof(web_Enum_Domain_List) / sizeof(CGI_ENUMSEL_S);
		     i++) {
			if (i == g_nRegulationDomain) {
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t\t\t<option value=\"%d\" "
						"SELECTED>%s</option>\n"), i,
					       web_Enum_Domain_List[i].str);
			} else {
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t\t\t<option value=\"%d\">%s"
						"</option>\n"), i,
					       web_Enum_Domain_List[i].str);
			}
		}
	} else if (!gstrcmp(name, T("essid"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_ESSID",
		     sValue) == 1) {
			ifx_web_convert_string(sValue);
			ifx_httpdWrite(wp, sValue);
		}
	} else if (!gstrcmp(name, T("nick"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_AP_NAME",
		     sValue) == 1) {
			ifx_web_convert_string(sValue);
			ifx_httpdWrite(wp, sValue);
		}
	} else if (!gstrcmp(name, T("op_rate"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_OP_RATE",
		     sValue) == 1) {
			nSelIdx = gatoi(sValue);

			for (i = 0;
			     i <
			     sizeof(web_Enum_OPRateMode_List) /
			     sizeof(CGI_ENUMSEL_S); i++) {
				if (i == nSelIdx) {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t\t<option value=\"%d\" SELECTED>%s</option>\n"),
						       i,
						       web_Enum_OPRateMode_List
						       [i].str);
				} else {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t\t<option value=\"%d\">%s</option>\n"),
						       i,
						       web_Enum_OPRateMode_List
						       [i].str);
				}
			}
		}
	} else if (!gstrcmp(name, T("preamble"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_PREAMBLE",
		     sValue) == 1) {
			nSelIdx = gatoi(sValue);

			for (i = 1;
			     i <
			     sizeof(web_Enum_PreambleMode_List) /
			     sizeof(CGI_ENUMSEL_S); i++) {
				if (i == nSelIdx) {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t\t<option value=\"%d\" SELECTED>%s</option>\n"),
						       i,
						       web_Enum_PreambleMode_List
						       [i].str);
				} else {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t\t\t\t<option value=\"%d\">%s</option>\n"),
						       i,
						       web_Enum_PreambleMode_List
						       [i].str);
				}
			}
		}
	} else if (!gstrcmp(name, T("beacon_interval"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_BEACON_INTERVAL",
		     sValue) == 1) {
			ifx_httpdWrite(wp, sValue);
		}
	} else if (!gstrcmp(name, T("rts"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SETTINGS, "WLAN_RTS",
		     sValue) == 1) {
			ifx_httpdWrite(wp, sValue);
		}
	} else if (!gstrcmp(name, T("fts"))) {

		ifx_httpdWrite(wp, sValue);
	}
}

return 0;
}

// wireless_security.asp
CGI_ENUMSEL_S web_Enum_EncryType_List[] = {
	{0, " "}
	,
	{WLAN_ENCRY_NONE, "No Encription"}
	,
	{WLAN_ENCRY_WEP64, "WEP 64  (10 digits)"}
	,
	{WLAN_ENCRY_WEP128, "WEP 128 (26 digits)"}
	,
	{WLAN_ENCRY_1X, "Standard 802.1X (WEP)"}
	,
	{WLAN_ENCRY_TKIP, "TKIP"}
	,
	{WLAN_ENCRY_AES, "AES"}
	,
	{WLAN_ENCRY_TKIP_AES, "TKIP/AES"}
	,
};

CGI_ENUMSEL_S web_Enum_AuthType_List[] = {
	{0, " "}
	,
	{WLAN_AUTH_OPEN, "Open authentication"}
	,
	{WLAN_AUTH_SHARED, "Shared authentication"}
	,
	{WLAN_AUTH_SWITCH, "Auto Switch"}
	,
	{WLAN_AUTH_WPA, "WPA-TLS"}
	,
	{WLAN_AUTH_PSK, "WPA-PSK"}
	,
	{WLAN_AUTH_WPA2, "WPA2-TLS"}
	,
	{WLAN_AUTH_PSK2, "WPA2-PSK"}
	,
};

CGI_ENUMSEL_S web_Enum_KeyUsed_List[] = {
	{0, "None"}
	,
	{1, "Key 1"}
	,
	{2, "Key 2"}
	,
	{3, "Key 3"}
	,
	{4, "Key 4"}
	,
};

CGI_ENUMSEL_S web_Enum_PSK_Password[] = {
	{0, "PSK"}
	,
	{1, "PassPhrase"}
	,
};

CGI_ENUMSEL_S web_Enum_1x_key[] = {
	{0, "64 bits"}
	,
	{1, "128 bits"}
	,
};

int ifx_get_wlan_security(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t *name, sValue[MAX_FILELINE_LEN];
	int i, nSelIdx = 0;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	sValue[0] = '\0';

	if (!gstrcmp(name, T("EncryType"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_ENCRY_TYPE",
		     sValue) == 1) {
			nSelIdx = gatoi(sValue);

			for (i = 1;
			     i <
			     sizeof(web_Enum_EncryType_List) /
			     sizeof(CGI_ENUMSEL_S); i++) {
				if (i == nSelIdx) {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t<option value=\"%d\" SELECTED>%s</option>\n"),
						       i,
						       web_Enum_EncryType_List
						       [i].str);
				} else {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t<option value=\"%d\">%s</option>\n"),
						       i,
						       web_Enum_EncryType_List
						       [i].str);
				}
			}
		}
	} else if (!gstrcmp(name, T("AuthType")) ||
		   !gstrcmp(name, T("authindex"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_AUTH_TYPE",
		     sValue) == 1) {
			nSelIdx = gatoi(sValue);

			if (!gstrcmp(name, T("authindex"))) {
				ifx_httpdWrite(wp, "%d", nSelIdx);
				return 0;
			}

			for (i = 1;
			     i <
			     sizeof(web_Enum_AuthType_List) /
			     sizeof(CGI_ENUMSEL_S); i++) {
				if (i == nSelIdx) {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t<option value=\"%d\" SELECTED>%s</option>\n"),
						       i,
						       web_Enum_AuthType_List
						       [i].str);
				} else {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t<option value=\"%d\">%s</option>\n"),
						       i,
						       web_Enum_AuthType_List
						       [i].str);
				}
			}
		}
	} else if (!gstrcmp(name, T("KeyUsed"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_KEY_USED",
		     sValue) == 1) {
			nSelIdx = gatoi(sValue);

			for (i = 0;
			     i <
			     sizeof(web_Enum_KeyUsed_List) /
			     sizeof(CGI_ENUMSEL_S); i++) {
				if (i == nSelIdx) {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t<option value=\"%d\" SELECTED>%s</option>\n"),
						       i,
						       web_Enum_KeyUsed_List[i].
						       str);
				} else {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t<option value=\"%d\">%s</option>\n"),
						       i,
						       web_Enum_KeyUsed_List[i].
						       str);
				}
			}
		}
	} else if (!gstrcmp(name, T("Key1"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_KEY1",
		     sValue) == 1) {
			if (strlen(sValue) != 1)
				ifx_httpdWrite(wp, sValue);
			else
				ifx_httpdWrite(wp, "");

		}
	} else if (!gstrcmp(name, T("Key2"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_KEY2",
		     sValue) == 1) {
			if (strlen(sValue) != 1)
				ifx_httpdWrite(wp, sValue);
			else
				ifx_httpdWrite(wp, "");
		}
	} else if (!gstrcmp(name, T("Key3"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_KEY3",
		     sValue) == 1) {
			if (strlen(sValue) != 1)
				ifx_httpdWrite(wp, sValue);
			else
				ifx_httpdWrite(wp, "");
		}
	} else if (!gstrcmp(name, T("Key4"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_KEY4",
		     sValue) == 1) {
			if (strlen(sValue) != 1)
				ifx_httpdWrite(wp, sValue);
			else
				ifx_httpdWrite(wp, "");
		}
	} else if (!gstrcmp(name, T("IsPassPhrase"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, T("WLAN_ISPASSPHRASE"),
		     sValue) == 1) {
			nSelIdx = gatoi(sValue);
			if (nSelIdx == 1)
				ifx_httpdWrite(wp, T("checked"));
			else if (nSelIdx == 0)
				ifx_httpdWrite(wp, T(""));
		}
	} else if (!gstrcmp(name, T("GKeyEnable"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_GKEY_ENABLE",
		     sValue) == 1) {
			if (!gstrcmp(sValue, "1")) {
				ifx_httpdWrite(wp, "checked");
			} else {
				ifx_httpdWrite(wp, "");
			}
		}
	} else if (!gstrcmp(name, T("GKeyRenew"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_GKEY_RENEWAL",
		     sValue) == 1)
			ifx_httpdWrite(wp, sValue);
		else
			ifx_httpdWrite(wp, "3600");
	} else if (!gstrcmp(name, T("PSK"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_PSK",
		     sValue) == 1) {
			if (strlen(sValue) != 1)
				ifx_httpdWrite(wp, sValue);
			else
				ifx_httpdWrite(wp, "");
		}
	} else if (!gstrcmp(name, T("P1x_key_len"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_8021X_KEYLEN",
		     sValue) == 1) {
			nSelIdx = gatoi(sValue);
			for (i = 0;
			     i <
			     sizeof(web_Enum_1x_key) / sizeof(CGI_ENUMSEL_S);
			     i++) {
				if (i == nSelIdx) {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t<option value=\"%d\" SELECTED>%s</option>\n"),
						       i,
						       web_Enum_1x_key[i].str);
				} else {
					ifx_httpdWrite(wp,
						       T
						       ("\t\t\t<option value=\"%d\">%s</option>\n"),
						       i,
						       web_Enum_1x_key[i].str);
				}
			}
		}
	} else if (!gstrcmp(name, T("radius_port"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_RADIUS_SERVER_PORT",
		     sValue) == 1) {
			ifx_httpdWrite(wp, sValue);
		}
	} else if (!gstrcmp(name, T("radius_secret"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY,
		     "WLAN_RADIUS_SERVER_SECRET", sValue) == 1) {
			ifx_httpdWrite(wp, sValue);
		}
	} else if (!gstrcmp(name, T("Nas_iden"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_NAS_ID",
		     sValue) == 1) {
			ifx_httpdWrite(wp, sValue);
		}
	} else if (!gstrcmp(name, T("GKeyRenew"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_GKEY_RENEWAL",
		     sValue) == 1)
			ifx_httpdWrite(wp, sValue);
		else
			ifx_httpdWrite(wp, "3600");
	} else if (!gstrcmp(name, T("PSK"))) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_WLAN_SECURITY, "WLAN_PSK",
		     sValue) == 1) {
			if (strlen(sValue) != 1)
				ifx_httpdWrite(wp, sValue);
			else
				ifx_httpdWrite(wp, "");
		}
	}

	return 0;
}

int ifx_get_radius_ip(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_DATA_LEN];
	char_t *name;
	char_t *delim = ". \n\t";
	char_t *ipaddr1, *ipaddr2, *ipaddr3, *ipaddr4;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_WLAN_SECURITY, T("WLAN_RADIUS_SERVER_IP"),
	     sValue) == 1) {
		ipaddr1 = strtok(sValue, delim);
		ipaddr2 = strtok(NULL, delim);
		ipaddr3 = strtok(NULL, delim);
		ipaddr4 = strtok(NULL, delim);

		if (!gstrcmp(name, T("radius_IP1"))) {
			ifx_httpdWrite(wp, T("%s"), ipaddr1);
		} else if (!gstrcmp(name, T("radius_IP2"))) {
			ifx_httpdWrite(wp, T("%s"), ipaddr2);
		} else if (!gstrcmp(name, T("radius_IP3"))) {
			ifx_httpdWrite(wp, T("%s"), ipaddr3);
		} else if (!gstrcmp(name, T("radius_IP4"))) {
			ifx_httpdWrite(wp, T("%s"), ipaddr4);
		}
	} else {
		ifx_httpdError(wp, 204, T("Config file not found"));
		return -1;
	}

	return 0;
}
#endif				//CONFIG_FEATURE_IFX_WIRELESS_ATH

#ifdef CONFIG_FEATURE_NAPT
int32 ifx_get_lan_conn_names(int32 eid, httpd_t wp, int32 argc, char8 ** argv)
{
	int32 ret = IFX_SUCCESS;
#if defined(CONFIG_FEATURE_LTQ_VLAN_SWITCH_PORT_ISOLATION) ||  defined(CONFIG_FEATURE_LTQ_SWITCH_PORT_ISOLATION) 
	if(lan_port_sep_enable_get() == IFX_SUCCESS){
		ret = ifx_get_lan_port_conn_names(eid,wp,argc,argv);
		goto IFX_Handler;
	}
	else
#endif
	{
		int32 i = 0, count = 0;
		char8 *lan_conn_names = NULL, *name = NULL;

		if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
			ifx_httpdError(wp, 400, "Insufficient Args !!\n");
			return IFX_FAILURE;
		}

		if ((ret =
					ifx_get_all_lan_conn_names(&lan_conn_names,
						&count)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
				("\n\n In Function [%s] : Error--> Failed to get lan connection names !!\n\n",
				 __FUNCTION__);
#endif
			goto IFX_Handler;
		}

		if (count > 0 && count < 32767) {
			for (i = 0; i < count; i++) {
				ifx_httpdWrite(wp,
						T
						("\t\t\t\t\t<option name=\"intf_%s\" value=\"%s\">%s</option>"),
						(lan_conn_names + (i * MAX_NAME_LEN)),
						(lan_conn_names + (i * MAX_NAME_LEN)),
						(lan_conn_names + (i * MAX_NAME_LEN)));
			}
		}
		IFX_MEM_FREE(lan_conn_names)
	}
      IFX_Handler:
	    return ret;
}

int32 ifx_get_wan_conn_names(int32 eid, httpd_t wp, int32 argc, char8 ** argv)
{
	int32 i = 0, count = 0, ret = IFX_SUCCESS, wipCnt, wpppCnt;
	char8 *wan_conn_names = NULL, *name = NULL;
	char8 wan_confconnName[MAX_CONN_NAME_LEN];
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_CONN_NAME_LEN],
	    conn_name[MAX_CONN_NAME_LEN];
	uint32 flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT;
	WAN_TYPE wan_type;

#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
	pwb_cfg_t *pwb = NULL;
	uint32 num = 0,j = 0, pwb_wan_flag = 0;
#endif

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, "Insufficient Args !!\n");
		return IFX_FAILURE;
	}

	if (!gstrcmp(name, "vs")) {
		if ((ret =
		     ifx_get_all_wan_conn_names(&wan_conn_names,&count)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("\n\n In Function [%s] : Error--> Failed to get wan connection names !!\n\n",
			     __FUNCTION__);
#endif
			goto IFX_Handler;
		}
#ifdef REQUIRED_FOR_VENDOR_EXTENSION
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t\t\t<option value=\"ALL\">ALL</option>"));
#endif				// REQUIRED_FOR_VENDOR_EXTENSION

		for (i = 0; i < count; i++) {
			
			if (strstr(GET_WAN_CONN_NAME(wan_conn_names, i),"IP") != NULL) {
				wan_type = WAN_TYPE_IP;
			} else {
				wan_type = WAN_TYPE_PPP;
			}
		
			if (ifx_get_wan_confconnName_from_connName (GET_WAN_CONN_NAME(wan_conn_names, i),wan_confconnName ,wan_type) == IFX_SUCCESS)
			{
				ifx_httpdWrite(wp, T("\"%s\";\n"),wan_confconnName);
			}

			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t\t<option name=\"sroute_%s\" value=\"%s\">%s</option>"),
				       GET_WAN_CONN_NAME(wan_conn_names, i),
				       GET_WAN_CONN_NAME(wan_conn_names, i),
					wan_confconnName);
		}
#if defined(CONFIG_FEATURE_LTQ_PORT_WAN_BINDING)
	} else if(!gstrcmp(name, "pwb"))
	{
		if ((ret = ifx_get_all_wan_conn_names(&wan_conn_names, &count)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("\n\n In Function [%s] : Error--> Failed to get wan connection names !!\n\n", __FUNCTION__);
#endif
			goto IFX_Handler;
		}
#ifdef REQUIRED_FOR_VENDOR_EXTENSION
		ifx_httpdWrite(wp, T("\t\t\t\t\t<option value=\"ALL\">ALL</option>"));
#endif // REQUIRED_FOR_VENDOR_EXTENSION
		for (i = 0; i < count; i++) {
			if(mapi_port_binding_cfg_get_all(&num, &pwb, IFX_F_DEFAULT) != IFX_SUCCESS) {
			ifx_httpdError(wp, 500, "Fail to get all port wan mapping info !!");
			goto IFX_Handler;
			}
			pwb_wan_flag = 0;
			for(j = 0; j < num; j++) {
				if(!gstrcmp((pwb+j)->wanIf.conName, GET_WAN_CONN_NAME(wan_conn_names, i))) {
				pwb_wan_flag=1;
				break;
				}
			}
			if(pwb_wan_flag == 0) {
				ifx_httpdWrite(wp, T("\t\t\t\t\t<option name=\"sroute_%s\" value=\"%s\">%s</option>"),GET_WAN_CONN_NAME(wan_conn_names, i), GET_WAN_CONN_NAME(wan_conn_names, i), GET_WAN_CONN_NAME(wan_conn_names, i));
			}
		}
#endif //CONFIG_FEATURE_LTQ_PORT_WAN_BINDING
	} else if (!gstrcmp(name, "IGMP_WAN_INTF")) {
		if ((ret =
		     ifx_get_all_wan_conn_names(&wan_conn_names,
						&count)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("\n\n In Function [%s] : Error--> Failed to get wan connection names !!\n\n",
			     __FUNCTION__);
#endif
			goto IFX_Handler;
		}
#ifdef REQUIRED_FOR_VENDOR_EXTENSION
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t\t\t<option value=\"ALL\">ALL</option>"));
#endif				// REQUIRED_FOR_VENDOR_EXTENSION
		memset(conn_name, 0x00, sizeof(conn_name));
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_APPLICATION_SERVER, T("IGMP_WAN_INTF"),
		     conn_name) != 1) {
			goto IFX_Handler;
		}
		IFX_GET_WAN_CONN_NAME_LIST(i, count, conn_name, wan_conn_names)
	}
#ifdef CONFIG_FEATURE_DDNS
	else if (!gstrcmp(name, "ddns_if")) {
		if ((ret =
		     ifx_get_all_wan_conn_names(&wan_conn_names,
						&count)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG
			    ("\n\n In Function [%s] : Error--> Failed to get wan connection names !!\n\n",
			     __FUNCTION__);
#endif
			goto IFX_Handler;
		}
#ifdef REQUIRED_FOR_VENDOR_EXTENSION
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t\t\t<option value=\"ALL\">ALL</option>"));
#endif				// REQUIRED_FOR_VENDOR_EXTENSION
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_DDNSCONFIG, T("ddns_if"),
		     conn_name) != 1) {
			goto IFX_Handler;
		}
		IFX_GET_WAN_CONN_NAME_LIST(i, count, conn_name, wan_conn_names)
	}
#endif				//CONFIG_FEATURE_DDNS
	else {

		if (ifx_get_sec_count(TAG_WAN_IP, &wipCnt) != IFX_SUCCESS) {

		}

		if (ifx_get_sec_count(TAG_WAN_PPP, &wpppCnt) != IFX_SUCCESS) {

		}

		for (i = 0; i < wipCnt; i++) {

			sprintf(buf, "%s_%d_connName", PREFIX_WAN_IP, i);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_WAN_IP, buf, flags,
			     (IFX_OUT uint32 *) & outFlag,
			     sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("\n\nIn Function [%s] !!\n\n",__FUNCTION__);
#endif
			} else {
				ifx_httpdWrite(wp,
					       T("WANIP_NAME[%d]=\"%s\";\n"), i,
					       sValue);
			}

		}

		for (i = 0; i < wpppCnt; i++) {

			sprintf(buf, "%s_%d_connName", PREFIX_WAN_PPP, i);
			if (ifx_GetObjData
			    (FILE_RC_CONF, TAG_WAN_PPP, buf, flags,
			     (IFX_OUT uint32 *) & outFlag,
			     sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("\n\nIn Function [%s] !!\n\n",__FUNCTION__);
#endif
			} else {
				ifx_httpdWrite(wp,T("WANPPP_NAME[%d]=\"%s\";\n"),i, sValue);
			}

		}

	}

      IFX_Handler:
	IFX_MEM_FREE(wan_conn_names)
	    return ret;
}
#endif				//CONFIG_FEATURE_NAPT

#ifdef CONFIG_FEATURE_NAPT
#ifdef NAT_PORTMAP
int ifx_get_nat_portmap(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t buf[MAX_DATA_LEN];
	char_t sValue[MAX_FILELINE_LEN], sServerIP[MAX_DATA_LEN];
	char_t getCommand[MAX_FILELINE_LEN], setCommand[MAX_FILELINE_LEN];
	int i;
	setCommand[0] = '\0';
	sServerIP[0] = '\0';
	websGetIFInfo(LAN_IF_TYPE, IP_INFO, 1, 3, FALSE, NULL, sServerIP);

	for (i = 1; i <= NAT_VS_LINK_NUM; i++) {
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t<tr align=center bgcolor=\"#ffffff\">\n"));
		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t\t<td nowrap><font face=\"Arial, Helvetica, sans-serif\" size=\"2\">%d</font></td>\n"),
			       i);

		buf[0] = '\0';
		sValue[0] = '\0';
		getCommand[0] = '\0';

		gsprintf(buf, T("CLONE_IP%d"), i);
		gsprintf(getCommand,
			 T("grep \"%s\" %s | cut -f2 -d\\\" | cut -f4 -d."),
			 buf, FILE_RC_CONF);
		if (ifx_GetCfgData((char_t *) getCommand, NULL, "1", sValue) ==
		    0) {
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t\t<td nowrap><font face=\"Arial, Helvetica, sans-serif\" size=\"2\">%s\n"),
				       sServerIP);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t\t<input maxLength=\"3\" name=\"%s\" size=\"3\" value=\"\"></font></td>\n"),
				       buf);
		} else {
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t\t<td nowrap><font face=\"Arial, Helvetica, sans-serif\" size=\"2\">%s\n"),
				       sServerIP);
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t\t<input maxLength=\"3\" name=\"%s\" size=\"3\" value=\"%s\"></font></td>\n"),
				       buf, sValue);
		}

		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t\t<td nowrap><font size=\"2\" face=\"Arial, Helvetica, sans-serif\">\n"));

		buf[0] = '\0';
		sValue[0] = '\0';

		gsprintf(buf, T("CLONE_PORTS%d"), i);
		if (ifx_GetCfgData(FILE_RC_CONF, TAG_NAT_PORTMAP, buf, sValue)
		    == 0) {
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t\t<input maxLength=\"120\" name=\"%s\" size=\"50\" value=\"\"></font></td>\n"),
				       buf);
		} else {
			if (gstrcmp(sValue, "0") != 0) {
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t\t<input maxLength=\"120\" name=\"%s\" size=\"50\" value=\"%s\"></font></td>\n"),
					       buf, sValue);
			} else if (!gstrcmp(sValue, "0")) {
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t\t<input maxLength=\"120\" name=\"%s\" size=\"50\" value=\"\"></font></td>\n"),
					       buf);
			}
		}

		ifx_httpdWrite(wp,
			       T
			       ("\t\t\t\t<td nowrap> <font size=\"2\" face=\"Arial, Helvetica, sans-serif\">\n"));

		buf[0] = '\0';
		sValue[0] = '\0';

		gsprintf(buf, T("CLONE_ENABLE%d"), i);
		if (ifx_GetCfgData(FILE_RC_CONF, TAG_NAT_PORTMAP, buf, sValue)
		    == 0) {
			ifx_httpdWrite(wp,
				       T
				       ("\t\t\t\t\t<input type=\"checkbox\" name=\"%s\" value=\"1\"></font></td>\n"),
				       buf);
		} else {
			if (!gstrcmp(sValue, "1")) {
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t\t<input type=\"checkbox\" name=\"%s\" value=\"1\"%s></font></td>\n"),
					       buf, " CHECKED");
			} else if (!gstrcmp(sValue, "0")) {
				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t\t<input type=\"checkbox\" name=\"%s\" value=\"1\"%s></font></td>\n"),
					       buf, "");
			}
		}

		ifx_httpdWrite(wp, T("\t\t\t</tr>\n"));
	}

	return 0;
}
#endif

#ifdef CONFIG_FEATURE_VLAN
int ifx_get_vlan_bridge_cfg(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_FILELINE_LEN];
	struct cfg_node {
		char *name;
		char *tag;
		int child;
	} cfg[] = {
		{
		"vb_enable", TAG_VLAN_BRIDGE, 0}, {
		"vb_pbvgs_groups", TAG_VLAN_BRIDGE_PB, 1}, {
		"vb_pmpts_groups", TAG_VLAN_BRIDGE_VB, 1}, {
		"vb_pmpts_ifs", TAG_VLAN_BRIDGE_VB, 0}, {
	NULL, NULL, 0},};
	int i = 0;
	while (cfg[i].name != NULL) {
		if (ifx_GetCfgData
		    (FILE_RC_CONF, cfg[i].tag, cfg[i].name, sValue) == 0) {
			ifx_httpdWrite(wp,
				       T
				       ("<INPUT NAME=\"%s\" VALUE=\"%s\" TYPE=\"hidden\" id=\"%s\">\n"),
				       cfg[i].name, "ERROR", cfg[i].name);
		} else {
			if (cfg[i].child == 0) {
				ifx_httpdWrite(wp,
					       T
					       ("<INPUT NAME=\"%s\" VALUE=\"%s\" TYPE=\"hidden\" id=\"%s\">\n"),
					       cfg[i].name, sValue,
					       cfg[i].name);
			} else {
				char_t sChildName[MAX_FILELINE_LEN];
				char_t sChildValue[MAX_FILELINE_LEN];
				int j = 0, total = atoi(sValue);
				ifx_httpdWrite(wp,
					       T
					       ("<INPUT NAME=\"%s\" VALUE=\"%d\" TYPE=\"hidden\" id=\"%s\">\n"),
					       cfg[i].name, total, cfg[i].name);
				memset(sValue, 0x00, sizeof(sValue));
				for (j = 1; j <= total; j++) {
					memset(sChildName, 0x00,
					       sizeof(sChildName));
					memset(sChildValue, 0x00,
					       sizeof(sChildValue));
					gsprintf(sChildName, "%s_%d",
						 cfg[i].name, j);
					if (ifx_GetCfgData
					    (FILE_RC_CONF, cfg[i].tag,
					     sChildName, sChildValue) == 0) {
						ifx_httpdWrite(wp,
							       T
							       ("<INPUT NAME=\"%s\" VALUE=\"%s\" TYPE=\"hidden\" id=\"%s\">\n"),
							       sChildName,
							       "ERROR",
							       sChildName);
					} else {
						ifx_httpdWrite(wp,
							       T
							       ("<INPUT NAME=\"%s\" VALUE=\"%s\" TYPE=\"hidden\" id=\"%s\">\n"),
							       sChildName,
							       sChildValue,
							       sChildName);
					}
				}
			}
		}
		i++;
	}
	sValue[0] = '\0';
	for (i = 1; i < MAX_VCCs; i++) {
		if (IP_BOOT_BRIDGE == GetWanMode(i)) {
			gstrcat(sValue, "1_");
		} else {
			gstrcat(sValue, "0_");
		}
	}
	if (IP_BOOT_BRIDGE == GetWanMode(MAX_VCCs)) {
		gstrcat(sValue, "1");
	} else {
		gstrcat(sValue, "0");
	}
	ifx_httpdWrite(wp,
		       T
		       ("<INPUT NAME=\"vb_wif_list\" VALUE=\"%d_%s_1_1_1_1_0\" TYPE=HIDDEN id=\"vb_wif_list\">\n"),
		       MAX_VCCs + 5, sValue);
	return 0;
}

extern int vlanWidx;
int ifx_get_vlan_membership_wan_ports(int eid, httpd_t wp, int argc,
				      char_t ** arg_v)
{
	int i;
	char sValue[MAX_DATA_LEN];
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_VLAN_BRIDGE, "vb_enable", sValue)
	    == 0) {
		ifx_httpdWrite(wp,
			       "<b>Error : VLAN Parameters missing !!! </b>");
		return 0;
	}
	if (strcmp(sValue, "1") == 0) {
		ifx_httpdWrite(wp,
			       T
			       ("<td><font class=\"subtitle\">Select Port</font></td>"));
		ifx_httpdWrite(wp, T("<td><font class=\"subtitle\">"));
		ifx_httpdWrite(wp,
			       T
			       ("<select name=\"vlanWidx\" onChange=\"ChangeEvent()\">"));
		if (vlanWidx == 0)
			ifx_httpdWrite(wp,
				       T
				       ("<option value=\"0\" selected>Select Interface</option>"));
		else
			ifx_httpdWrite(wp,
				       T
				       ("<option value=\"0\">Select Interface</option>"));

		for (i = 1; i <= MAX_VCCs; i++) {
			if (IP_BOOT_BRIDGE == GetWanMode(i)) {
				if (vlanWidx == i)
					ifx_httpdWrite(wp,
						       T
						       ("<option value=\"%d\" selected>WAN%d</option>"),
						       i, i);
				else
					ifx_httpdWrite(wp,
						       T
						       ("<option value=\"%d\">WAN%d</option>"),
						       i, i);
			}
		}

		for (i = MAX_VCCs + 1; i < MAX_VCCs + 1 + 4; i++) {
			if (vlanWidx == i)
				ifx_httpdWrite(wp,
					       T
					       ("<option value=\"%d\" selected>swport%d</option>"),
					       i, i - MAX_VCCs - 1);
			else
				ifx_httpdWrite(wp,
					       T
					       ("<option value=\"%d\">swport%d</option>"),
					       i, i - MAX_VCCs - 1);
		}
		ifx_httpdWrite(wp, T("</select>"));
		ifx_httpdWrite(wp, T("</td>"));
	} else {
		ifx_httpdWrite(wp,
			       T
			       ("<b>Please enable VLAN Bridging support!!!</b>"));
	}

	return 0;
}
int ifx_get_vlan_membership_info(int eid, httpd_t wp, int argc, char_t ** arg_v)
{
	char_t sValue[MAX_DATA_LEN], sCommand[MAX_DATA_LEN],
	    sVlanID[MAX_DATA_LEN], sVlanTAG[MAX_DATA_LEN];
	char_t prefix[PREFIX_AND_TAG_LEN], tag[PREFIX_AND_TAG_LEN];
	int nCount = -1, nIndex;

	if (vlanWidx > 0) {
		//Generate the prefix based on the selected port
		gsprintf(prefix, T("VM_intf%d_"), vlanWidx);
		gsprintf(tag, T("intf%d_vlan_membership"), vlanWidx);

		gsprintf(sCommand, T("%sCount"), prefix);
		if (ifx_GetCfgData(FILE_RC_CONF, tag, sCommand, sValue) == 0) {
			goto vlan_exit;
		}

		nCount = gatoi(sValue);
		for (nIndex = 0; nIndex < nCount; nIndex++) {
			// Get VLAN TAG
			gsprintf(sCommand,
				 T("grep \"^%sTAG%d\" %s | cut -f2 -d'\"'"),
				 prefix, nIndex, FILE_RC_CONF);
			if (ifx_GetCfgData
			    ((char_t *) sCommand, NULL, "1", sVlanTAG) == 0) {
				ifx_httpdError(wp, 500, T("%sTAG%d not found"),
					       prefix, nIndex);
				return -1;
			}
			// Get VLAN ID
			gsprintf(sCommand,
				 T("grep \"^%sID%d\" %s | cut -f2 -d'\"'"),
				 prefix, nIndex, FILE_RC_CONF);
			if (ifx_GetCfgData
			    ((char_t *) sCommand, NULL, "1", sVlanID) == 0) {
				ifx_httpdError(wp, 500, T("%sID%d not found"),
					       prefix, nIndex);
				return -1;
			}
			// Print Html file
			ifx_httpdWrite(wp,
				       T
				       ("<tr align=\"center\" bgcolor=\"#ffffff\">\n"));
			ifx_httpdWrite(wp,
				       T
				       ("<td width=\"45%%\"><font face=\"Arial, Helvetica, sans-serif\" size=\"3\">%s</font></td>\n"),
				       sVlanID);
			if (strcmp(sVlanTAG, "1") == 0)
				ifx_httpdWrite(wp,
					       T
					       ("<td width=\"35%%\"><input type=checkbox disabled=\"true\" size=\"1\" value=\"1\" checked></td>\n"),
					       nIndex);
			else
				ifx_httpdWrite(wp,
					       T
					       ("<td width=\"35%%\"><input type=checkbox disabled=\"true\" size=\"1\" value=\"0\"></td>\n"),
					       nIndex);

			ifx_httpdWrite(wp,
				       T
				       ("<td width=\"20%%\"><center><input type=\"button\" name=\"relname\" value=\"Delete\" onClick=\"release(%d);\"></center></td>\n"),
				       nIndex);
			ifx_httpdWrite(wp, T("</tr>\n"));
		}
	}
      vlan_exit:
	vlanWidx = 0;
	return 0;
}
#endif				//CONFIG_FEATURE_VLAN
#endif				//CONFIG_FEATURE_NAPT

#ifdef CONFIG_FEATURE_RIP
CGI_ENUMSEL_S web_Enum_RtListenMode[] = {
	{0, ""}
	,
	{1, "RIP1"}
	,
	{2, "RIP2"}
	,
	{3, "Both(RIP1+RIP2)"}
};

CGI_ENUMSEL_S web_Enum_RtSupplyMode[] = {
	{0, ""}
	,
	{1, "RIP1"}
	,
	{2, "RIP2"}
};

int ifx_get_route_dynamic(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int i, ret = 0;
	char_t *name;
	char_t sValue[MAX_FILELINE_LEN];
	//char_t command[MAX_FILELINE_LEN];
	uint32 Flags = IFX_F_GET_ANY;
	RIP_CFG rip;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	sValue[0] = '\0';
	//command[0] = '\0';

	rip.iid.config_owner = IFX_WEB;
	ret = ifx_get_rip_cfg(&rip, Flags);

	if (ret == IFX_SUCCESS) {
		if (!gstrcmp(name, T("wkMode"))) {
			if (rip.f_enable == 1) {
				gstrcpy(sValue, "1");
			} else {	//Disable
				gstrcpy(sValue, "0");
			}
			//ejSetResult(eid, sValue);
			ifx_httpdWrite(wp, T("%s"), sValue);
		} else if (!gstrcmp(name, T("RtListenMode"))) {

			for (i = 1;
			     i <
			     sizeof(web_Enum_RtListenMode) /
			     sizeof(CGI_ENUMSEL_S); i++) {
				// Get Selected option index from rc.conf
				if (i == rip.listen_mode) {
					gstrcpy(sValue, " SELECTED");
				} else {
					gstrcpy(sValue, "");
				}

				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t<option value=\"%d\"%s> %s </option>"),
					       i, sValue,
					       web_Enum_RtListenMode[i].str);
			}
		} else if (!gstrcmp(name, T("RtSupplyMode"))) {

			for (i = 1;
			     i <
			     sizeof(web_Enum_RtSupplyMode) /
			     sizeof(CGI_ENUMSEL_S); i++) {
				// Get Selected option index from rc.conf
				if (i == rip.supply_mode) {
					gstrcpy(sValue, " SELECTED");
				} else {
					gstrcpy(sValue, "");
				}

				ifx_httpdWrite(wp,
					       T
					       ("\t\t\t\t<option value=\"%d\"%s> %s </option>"),
					       i, sValue,
					       web_Enum_RtSupplyMode[i].str);
			}
		} else if (!gstrcmp(name, T("wkMode6"))) {
                        if (rip.fv6_enable == 1) {
                                gstrcpy(sValue, "1");
                        } else {        //Disable
                                gstrcpy(sValue, "0");
                        }
                        //ejSetResult(eid, sValue);
                        ifx_httpdWrite(wp, T("%s"), sValue);
               }
                  
	} else
		ifx_httpdError(wp, 400, T("Error\n"));

	return 0;
}
#endif				//CONFIG_FEATURE_RIP

void ifx_get_phyport_status(httpd_t wp, int id,int index)
{
	char_t sValue[MAX_FILELINE_LEN];
	struct ifx_phyport_info stat;

	memset(sValue, 0x00, sizeof(sValue));
	memset(&stat, 0x00, sizeof(stat));

#if defined(PLATFORM_VR9) || defined(PLATFORM_VB300) || defined(CONFIG_FEATURE_LTQ_HNX_CONFIG) || defined(PLATFORM_AR10)
	if (ifx_get_phyport_info(id, &stat, 0) < 0)
#else
	if (ifx_get_phyport_info(id, &stat, 1) < 0)
#endif
	{
		//ifx_httpdError(wp, 400, T("get status fail\n")); manohar
	} else {
		if (stat.link != 0) {
			gstrcat(sValue, "Link Up, ");
			if (stat.speed == 0) {
				gstrcat(sValue, "10Mb/s, ");
			} else {
				//gstrcat(sValue, "10Mb/s, ");
				gsprintf(sValue, "%s%dMb/s, ", sValue,
					 stat.speed);
			}
			if (stat.duplex == 0) {
				gstrcat(sValue, "Half Duplex");
			} else {
				if (stat.duplex == 2) {
					gstrcat(sValue, "Half Duplex");
				} else {
					gstrcat(sValue, "Full Duplex");
				}

			}
		} else {
			gstrcat(sValue, "Link Down");
		}
	}

	ifx_httpdWrite(wp,T("<tr><td colspan=\"1\">PORT-%d</td><td colspan=\"2\">%s</td></tr>\n"),index, sValue);
	return;
}

void ifx_get_phyport_status_modified(httpd_t wp, int id)
{
	char_t sValue[MAX_FILELINE_LEN];
	struct ifx_phyport_info stat;

	memset(sValue, 0x00, sizeof(sValue));
	memset(&stat, 0x00, sizeof(stat));

#if defined(PLATFORM_VR9) || defined(PLATFORM_AR10)
	if (ifx_get_phyport_info(id, &stat, 0) < 0) {
#else
	if (ifx_get_phyport_info(id, &stat, 1) < 0) {
#endif
		ifx_httpdError(wp, 400, T("get status fail\n"));
	} else {
		if (stat.link != 0) {
			gstrcat(sValue, "Link Up, ");
			if (stat.speed != 0)
				gstrcat(sValue, "100Mb/s, ");
			else
				gstrcat(sValue, "10Mb/s, ");
			if (stat.duplex != 0)
				gstrcat(sValue, "Full Duplex");
			else
				gstrcat(sValue, "Half Duplex");
		} else
			gstrcat(sValue, "Link Down, ");
	}

	ifx_httpdWrite(wp, T("%s"), sValue);
	return;
}

int ifx_get_lan_phyport_status(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int index = 1;
#ifdef CONFIG_FEATURE_LTQ_HNX_CONFIG
	ifx_get_phyport_status(wp, 1,index++);
#elif defined(CONFIG_PACKAGE_KMOD_LTQCPE_AR10_F2_SUPPORT)
	int32	j = 1;
	for (index = 2; index <=5; index++, j++)
		ifx_get_phyport_status(wp, index, j);
	ifx_get_phyport_status(wp, 1, 5);
#else
#ifndef PLATFORM_VBX
	ifx_get_phyport_status(wp, 0,index++);
#ifndef CONFIG_FEATURE_IFX_SINGLE_PORT
	ifx_get_phyport_status(wp, 1,index++);
	ifx_get_phyport_status(wp, 2,index++);
#if defined(PLATFORM_VR9) || defined(PLATFORM_AR10) || defined(PLATFORM_AR9)
	ifx_get_phyport_status(wp, 4,index++);
#else
	ifx_get_phyport_status(wp, 3,index++);
#endif
#endif
#else
	ifx_get_phyport_status(wp, 1,index++);
#endif
	ifx_get_phyport_status(wp, 5,index++);
#endif /*CONFIG_FEATURE_LTQ_HNX_CONFIG*/
	ifx_httpdWrite(wp, T("\n"));
	return 0;
}

int ifx_get_ADSLVcChannel_List_modified(int eid, httpd_t wp, int argc,
					char_t ** argv)
{
	char_t sValue[MAX_FILELINE_LEN], *name;
	char_t command[MAX_FILELINE_LEN];
	char_t sSelected_Value[MAX_FILELINE_LEN];
	int i = 0, nChannel_Size, Encp_mode = 0, VPI_value = 0, VCI_value =
	    0, QoS_mode = 0, num = 0;
	char_t sWAN_VCC[MAX_FILELINE_LEN], sWAN_TAG[MAX_FILELINE_LEN];
//	char vcc_flag = 0;
	ATM_VCC_INFO *vcc = NULL;
	int uTemp = 0;
	sValue[0] = '\0';
	command[0] = '\0';
	sSelected_Value[0] = '\0';

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	if (!gstrcmp(name, T("WAN_VCList"))
	    || !gstrcmp(name, T("get_used_vcc"))) {
		i = 1;
#ifdef CONFIG_FEATURE_IFX_MULTIPLE_VCCS
		if (ifx_GetCfgData
		    (FILE_SYSTEM_STATUS, "http_wan_vcc_select", "WAN_VCC",
		     sValue) == 1) {
			i = atoi(sValue);
			if (i < 1)
				i = 1;
		}
#endif
		sprintf(sValue, "WAN%d_VCC", i);
		sprintf(command, "%s%d", TAG_WAN_MAIN, i);
		ifx_GetCfgData(FILE_RC_CONF, command, sValue, sSelected_Value);
	}

	if (!gstrcmp(name, T("get_used_vcc"))) {
		for (i = 1; i <= MAX_VCCs; i++) {
			//vcc_flag = 0;
			sprintf(sWAN_TAG, "%s%d", TAG_WAN_MAIN, i);
			sprintf(sValue, "WAN%d_VCC", i);
			if (ifx_GetCfgData
			    (FILE_RC_CONF, sWAN_TAG, sValue, sWAN_VCC) == 1) {
				ifx_httpdWrite(wp, T("WAN_VCCs[%d]=\"%s\";\n"),
					       i - 1, sWAN_VCC);
			} else {
				ifx_httpdWrite(wp, T("WAN_VCCs[%d]=\"0\";\n"),
					       i - 1);
			}
		}
		return 0;
	}
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, T("adsl_vcchannel_Count"),
	     sValue) == 0) {
		ifx_httpdError(wp, 500, "ADSL VCChannelCount not found");
		return -1;
	}

	nChannel_Size = gatoi(sValue);

	/* Print VCC table header */
	ifx_httpdWrite(wp,
		       T
		       ("<tr><th width=\"5%\">No</th>\n<th width=\"15%\"> VPI/VCI </th>\n<th width=\"25%\"> RFC 2684 Encap </th>\n<th width=\"20%\"> QoS Class </th> <th width=\"35%\"> QoS Parameters </th>\n"),
		       i + 1, VPI_value, VCI_value,
		       Encp_mode == 0 ? "LLC/SNAP" : "VCMux",
		       ifx_get_atm_qos_name_by_id(QoS_mode));

	if (ifx_get_all_vcc_info(&num, &vcc, IFX_F_DEFAULT) != IFX_SUCCESS) {
		ifx_httpdError(wp, 500, "Error");
		goto IFX_Handler;
	}
	for (i = 0; i < nChannel_Size; i++) {

		gsprintf(command, "VCChannel_%d_vcc", i);
		if (ifx_GetCfgData
		    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, command, sValue) == 0) {
			ifx_httpdError(wp, 500, "ADSL VCChannel not found");
			return -1;
		}
		gsscanf(sValue, "%d/%d", &VPI_value, &VCI_value);
		if (VPI_value != 256) {
			gsprintf(command, "VCChannel_%d_encap", i);
			if (ifx_GetCfgData
			    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, command,
			     sValue) == 0) {
				ifx_httpdError(wp, 500,
					       "ADSL VCChannel Encap not found");
				return -1;
			}
			gsscanf(sValue, "%d", &Encp_mode);
			gsprintf(command, "VCChannel_%d_qos", i);
			if (ifx_GetCfgData
			    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, command,
			     sValue) == 0) {
				ifx_httpdError(wp, 500,
					       "ADSL VCChannel QoS not found");
				return -1;
			}
			gsscanf(sValue, "%d", &QoS_mode);

			ifx_httpdWrite(wp,
				       T
				       ("<tr><td width=\"5%\"> %d </td>\n<td width=\"10%\"> %d/%d </td>\n<td width=\"25%\"> %s </td>\n<td width=\"20%\"> %s </td>\n"),
				       i + 1 - uTemp, VPI_value, VCI_value,
				       Encp_mode == 0 ? "LLC/SNAP" : "VCMux",
				       ifx_get_atm_qos_name_by_id(QoS_mode));
			ifx_httpdWrite(wp, T("<td>"));
			if ((vcc) && (vcc + i)) {
				if ((vcc + i)->txtp.max_pcr)
					ifx_httpdWrite(wp, "MAX_PCR=%d,",
						       (vcc + i)->txtp.max_pcr);
				if ((vcc + i)->txtp.min_pcr)
					ifx_httpdWrite(wp, "MIN_PCR=%d,",
						       (vcc + i)->txtp.min_pcr);
				if ((vcc + i)->txtp.cdv)
					ifx_httpdWrite(wp, "CDV=%d,",
						       (vcc + i)->txtp.cdv);
				if ((vcc + i)->txtp.scr)
					ifx_httpdWrite(wp, "SCR=%d,",
						       (vcc + i)->txtp.scr);
				if ((vcc + i)->txtp.mbs)
					ifx_httpdWrite(wp, "MBS=%d",
						       (vcc + i)->txtp.mbs);
			}
			ifx_httpdWrite(wp, T("</td></tr>"));
		} else {
			uTemp++;
		}
	}
      IFX_Handler:
	IFX_MEM_FREE(vcc)
	    return 0;
}

int get_vcc_enc(char_t sWAN_VCC[], int *encap)
{
	char8 sValue[MAX_FILELINE_LEN];
	char8 sEncap[MAX_NAME_SIZE];
	char8 *retVal = NULL;
	int outFlag = IFX_F_DEFAULT;

 if (ifx_ret_substr_from_distfield
	    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, "vcc", sWAN_VCC,
	     &retVal) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error-->Failed to get vcchannel index for VCC [%s] !!\n\n",
		     __FUNCTION__, sWAN_VCC);
#endif
		IFX_MEM_FREE(retVal)
		    return -1;
	}

	memset(sEncap, 0x00, sizeof(sEncap));
	sprintf(sValue, "%s_encap", retVal);
	if (ifx_GetObjData
	    (FILE_RC_CONF, TAG_ADSL_VCCHANNEL, sValue, IFX_F_DEFAULT,
	     (IFX_OUT uint32 *) & outFlag, sEncap) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("\n\n In Function [%s] : Error-->Failed to get the encap for VCC [%s] !!\n\n",
		     __FUNCTION__, sWAN_VCC);
#endif
		return -1;
	}

	*encap = atoi(sEncap);
	IFX_MEM_FREE(retVal);
	return 0;
}

#define MAX_FIELD_LEN	128
/* This function is used by CLI */
int ifx_get_wan_vcc_info(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_FIELD_LEN];
	char_t command[MAX_FIELD_LEN];
	char_t sIP[MAX_IP_ADDR_LEN];
	char_t sMask[MAX_IP_ADDR_LEN];
	int i, j = 0;
	int mode = 0, outFlag = 0;
	char type[MAX_FIELD_LEN];
	char Value[MAX_FIELD_LEN];
	char *name;
	char wan_enable[10];
#ifdef CONFIG_FEATURE_IFX_VOIP
	char sipif_idx[10];
#endif
	int encap = 0, nWAN_IDX = 0, vpi = 0, vci = 0;
	IFX_ID iid;
	int linkType;
	WAN_COMMON_CFG pWan;
	WAN_CONN_CFG *t_wan = NULL;

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}

	/* Pramod - use the ifx_get_all_wan_atm_vcc_config api to get the configured wan connections
	   and show them on the page */
	WAN_CONN_CFG *wan_cfg = NULL;
	int wan_count = 0;

	if (ifx_get_all_wan_atm_vcc_config(&wan_count, &wan_cfg, IFX_F_DEFAULT)
	    != IFX_SUCCESS) {
		ifx_httpdError(wp, 500,
			       T
			       ("Failed to get the configured wan connections"));
		IFX_MEM_FREE(wan_cfg);
		return -1;
	}

	if (!gstrcmp(name, "wan_status")) {
		for (i = 0; i < wan_count; i++) {
			mode = 0, encap = 0;
			memset(sIP, 0x00, sizeof(sIP));
			memset(sMask, 0x00, sizeof(sMask));

			/* get encap mode to encap */
			//sprintf(sWAN_VCC, "%d/%d", (wan_cfg+i)->vc.pvc.vpi, (wan_cfg+i)->vc.pvc.vci);
			//get_vcc_enc(sWAN_VCC, &encap);
			t_wan = wan_cfg + i;
			GET_WAN_COMM_PTR(pWan, t_wan)
			    if (ifx_get_another_fvp_from_dist_fvp
				(TAG_ADSL_VCCHANNEL, "l2ifName",
				 pWan.iface_name, "encap", sValue,
				 IFX_F_GET_ANY) != IFX_SUCCESS) {
			}
			encap = atoi(sValue);

			linkType = (wan_cfg + i)->type;

			/* get conn. type and addr. type based on link type */
			switch (linkType) {
			case WAN_LINK_TYPE_EOATM:
			case WAN_LINK_TYPE_IPOATM:
			case WAN_LINK_TYPE_CLIP:
				if ((wan_cfg + i)->wancfg.ip.conn_type ==
				    WAN_IP_CONN_TYPE_IP_BRIDGED)
					strcpy(type, "Bridge");
				else if ((wan_cfg + i)->wancfg.ip.conn_type ==
					 WAN_IP_CONN_TYPE_IP_ROUTED) {
					if ((wan_cfg +
					     i)->WAN_IP_CONN.addr_type == 1)
						strcpy(type, "Dynamic");
					else if ((wan_cfg +
						  i)->WAN_IP_CONN.addr_type ==
						 2)
						strcpy(type, "Static");
					if (linkType == 1)
						strcpy(Value, "EoA");
					if (linkType == 2)
						strcpy(Value, "IPoA");
					if (linkType == 5)
						strcpy(Value, "CLIP");
					mode = 1;
				}
				sprintf(sIP, "%s",
					(char *)inet_ntoa((wan_cfg + i)->
							  WAN_IPv4_CFG.
							  WAN_CONN_IPADDR));
				sprintf(sMask, "%s",
					(char *)inet_ntoa((wan_cfg + i)->
							  WAN_IPv4_CFG.
							  WAN_CONN_IPMASK));
				break;
				/* TBD: for now lets not worry for PPPoATM */
#if 0
			case WAN_LINK_TYPE_PPPOATM:
				strcpy(type, "PPPoA");
				sprintf(sIP, "%s",
					(char *)inet_ntoa((wan_cfg + i)->
							  WAN_PPP_CONN.WAN_CONN.
							  WAN_CONN_IPADDR));
				sprintf(sMask, "%s",
					(char *)inet_ntoa((wan_cfg + i)->
							  WAN_PPP_CONN.WAN_CONN.
							  WAN_CONN_IPMASK));
				break;
#endif				// 0
			case WAN_LINK_TYPE_PPPOE:
				strcpy(type, "PPPoE");
				sprintf(sIP, "%s",
					(char *)inet_ntoa((wan_cfg + i)->
							  WAN_PPP_CONN.
							  remote_addr));
				/* TBD: for PPP connection, we dont need subnet mask !? */
				// sprintf(sMask, "%s", (char *)inet_ntoa((wan_cfg+i)->WAN_PPP_CONN.WAN_CONN_IPMASK));
				break;
			default:
				strcpy(type, "Disabled");
				break;
			}

			if (ifx_get_another_fvp_from_dist_fvp
			    (TAG_ADSL_VCCHANNEL, "l2ifName", pWan.iface_name,
			     "vcc", sValue, IFX_F_GET_ANY) != IFX_SUCCESS) {
			}
			sscanf(sValue, "%d/%d", &vpi, &vci);

			if (mode == 1)
				ifx_httpdWrite(wp,
					       T
					       ("<tr><td> %d </td>\n<td> %d/%d<br>%s </td>\n<td> %s<br>%s </td>"),
					       pWan.wan_index, vpi, vci,
					       encap ==
					       0 ? "LLC/SNAP" : "VCMux", type,
					       Value);
			else
				ifx_httpdWrite(wp,
					       T
					       ("<tr><td> %d </td>\n<td> %d/%d<br>%s </td>\n<td> %s </td>"),
					       pWan.wan_index, vpi, vci,
					       encap ==
					       0 ? "LLC/SNAP" : "VCMux", type);

			t_wan = wan_cfg + i;
			GET_WAN_COMM_PTR(pWan, (wan_cfg + i))
			    IFX_GET_WAN_CONN_STATE_STRING(t_wan, pWan, sValue)

			    ifx_httpdWrite(wp,
					   T
					   ("<td>%s</td><td>%s</td><td>%s</td></tr>"),
					   sValue, sIP, pWan.conf_conn_name);
		}
	} else if (!gstrcmp(name, "wan_vcc")) {
		if (ifx_GetCfgData
		    (FILE_SYSTEM_STATUS, "http_wan_vcc_select", "WAN_VCC",
		     sValue) == 1)

		if (ifx_get_default_wan_if
		    (&iid, &nWAN_IDX, sValue, IFX_F_DEFAULT) != IFX_SUCCESS) {
			nWAN_IDX = 0;
		}
#ifdef CONFIG_FEATURE_IFX_VOIP
		memset(sipif_idx, 0x00, sizeof(sipif_idx));
		if (ifx_GetObjData
		    (FILE_RC_CONF, TAG_SIP, "SIP_IF", IFX_F_DEFAULT,
		     (IFX_OUT uint32 *) & outFlag, sipif_idx) != IFX_SUCCESS) {
			ifx_httpdError(wp, 500, T(""));
			IFX_MEM_FREE(wan_cfg);
			return -1;
		}
#endif

		for (j = 0; j < wan_count; j++) {
			memset(wan_enable, 0x00, sizeof(wan_enable));
			GET_WAN_COMM_PTR(pWan, (wan_cfg + j))
			    ifx_httpdWrite(wp, ("<tr><td><b>WAN%d</b></td>\n"),
					   pWan.wan_index);
			ifx_httpdWrite(wp, "<td>");

			if (ifx_get_another_fvp_from_dist_fvp
			    (TAG_ADSL_VCCHANNEL, "l2ifName", pWan.iface_name,
			     "encap", sValue, IFX_F_GET_ANY) != IFX_SUCCESS) {
			}
			sscanf(sValue, "%d/%d", &vpi, &vci);

			ifx_httpdWrite(wp, T("%d/%d</td><td>"), vpi, vci);

			linkType = pWan.link_type;

			switch (linkType) {
			case WAN_LINK_TYPE_EOATM:
			case WAN_LINK_TYPE_IPOATM:
			case WAN_LINK_TYPE_CLIP:
				if ((wan_cfg + j)->WAN_IP_CONN.conn_type ==
				    WAN_IP_CONN_TYPE_IP_BRIDGED)
					ifx_httpdWrite(wp, "Bridge");
				else if ((wan_cfg + j)->WAN_IP_CONN.conn_type ==
					 WAN_IP_CONN_TYPE_IP_ROUTED) {
					if ((wan_cfg +
					     j)->WAN_IP_CONN.addr_type == 1) {
						ifx_httpdWrite(wp,
							       "Dhcp Client<br>");
						if (linkType == 1)
							ifx_httpdWrite(wp,
								       "RFC2684 Ethernet over ATM");
						if (linkType == 2)
							ifx_httpdWrite(wp,
								       "RFC2684 IP over ATM");
						if (linkType == 5)
							ifx_httpdWrite(wp,
								       "CLIP");
					} else if ((wan_cfg + j)->WAN_IP_CONN.
						   addr_type == 2) {
						ifx_httpdWrite(wp,
							       "Fix IP<br>");
						if (linkType == 1)
							ifx_httpdWrite(wp,
								       "RFC2684 Ethernet over ATM");
						if (linkType == 2)
							ifx_httpdWrite(wp,
								       "RFC2684 IP over ATM");
						if (linkType == 5)
							ifx_httpdWrite(wp,
								       "CLIP");
					}
				}
				break;
			case WAN_LINK_TYPE_PPPOATM:
				ifx_httpdWrite(wp, "PPPoA");
				break;
			case WAN_LINK_TYPE_PPPOE:
				ifx_httpdWrite(wp, "PPPoE");
				break;
			default:
				ifx_httpdWrite(wp, "Disabled");
				break;
			}

			ifx_httpdWrite(wp, ("</td>\n"));

			sprintf(command, "wan_%d_fEnable", j);
			ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, command,
				       IFX_F_DEFAULT,
				       (IFX_OUT uint32 *) & outFlag,
				       wan_enable);

#ifdef CONFIG_FEATURE_IFX_VOIP
			ifx_httpdWrite(wp, ("<td align=center>"));

			ifx_httpdWrite(wp,
				       ("<input type=radio name=\"def_voip_iface\" value=\"%d\" %s"),
				       j,
				       (atoi(wan_enable) ==
					1) ? "enabled" : "disabled");

			if (pWan.wan_index == (atoi(sipif_idx) - 1)) {
				ifx_httpdWrite(wp, (" checked"));
			}
			ifx_httpdWrite(wp, ("></td>\n"));

#endif

			ifx_httpdWrite(wp, (" <td align=center>"));

			ifx_httpdWrite(wp,
				       ("<input type=radio name=\"def_gw\" value=\"%d\" %s"),
				       j,
				       (atoi(wan_enable) ==
					1) ? "enabled" : "disabled");

			if (nWAN_IDX == pWan.wan_index)
				ifx_httpdWrite(wp, (" checked"));

			ifx_httpdWrite(wp, ("></td>\n</tr>\n"));
		}
	}

	IFX_MEM_FREE(wan_cfg);
	return 0;
}

/* TBD: We need not show encapsulation type of VC channel in WAN setting page */
int ifx_get_ADSLVcChannel_List(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char8 sValue[MAX_FILELINE_LEN], command[MAX_NAME_SIZE], *name = NULL;
	char8 sSelected_Value[10]/*, sEncap[MAX_NAME_SIZE]*/, scpeId[10];
	char8 sWAN_VCC[MAX_NAME_SIZE], pcpe_Sec[MAX_NAME_SIZE], *retVal = NULL;
	int num = 0, ret = IFX_SUCCESS, i = 0, k = 0, wanIpCnt = 0, wanPppCnt = 0, idx_count = 0;
#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT) || defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
//	int j = 0;
#endif
#if defined(CONFIG_PACKAGE_IFX_DSL_CPE_API) || defined(CONFIG_FEATURE_ETH_WAN_SUPPORT) || defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
#endif
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
	//int     Encp_mode = 0, QoS_mode = 0;
#endif
	/* Dummy channel counters for ATM & ETH WAN Modes */
	//#if defined(CONFIG_PACKAGE_IFX_DSL_CPE_API) || defined(CONFIG_FEATURE_ETH_WAN_SUPPORT) || defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
	//uint32 uTemp=0;
	//#endif
	int32 sValue1 = -1;
	int32 mode = -1, web_mode = -1; //, idx = 0;	//, idx1 = 0;
	uint32 flags = IFX_F_DEFAULT, outFlag = IFX_F_DEFAULT;
	uint32 tmp_index = 1;
	ATM_VCC_INFO *vcc = NULL;
	vlan_ch_cfg_t *vlan_chcfg = NULL;
#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
	ETH_CH_CFG *eth_cfg = NULL;
#endif
#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
	PTM_CH_CFG *ptm_cfg = NULL;
#endif
	WAN_TYPE sWAN_TYPE;

	sValue[0] = '\0';
	sSelected_Value[0] = '\0';
	scpeId[0] = '\0';
//	sEncap[0] = '\0';
	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
	auto_detect_cfg_t config;
	WAN_MODE WanType;
	int inx = 0;
	ltq_mapi_get_autodetect_config(&config);
	WanType = global_wan_mode_get(IFX_F_DEFAULT);
#if 0 // [ 0
	char8 vcc_l2if[MAX_NAME_SIZE], vlan_l2if[MAX_NAME_SIZE];
	if (ifx_get_all_vcc_info(&num, &vcc, flags) !=
			IFX_SUCCESS) {
		ifx_httpdError(wp, 500, "Error");
		ret = FALSE;
		goto IFX_Handler;
	} 

	if(mapi_get_all_vlan_ch_entries(&idx_count, &vlan_chcfg, flags) != IFX_SUCCESS) {
		ifx_httpdError(wp, 500, "Error");
                ret = FALSE;
                goto IFX_Handler;
	} 
 	/* Search VCC instance where in autodetect is enabled
	 */ 
	if(config.auto_detect_L2 == 1){
        for(i=0; i<num; i++) {
			if((vcc + i)->autodetect == 1){
				strcpy(vcc_l2if, (vcc + i)->l2ifname);
				//get config of autodetect enabled instance
			}
		}
	}

	if(config.auto_detect_Vlan_PTM == 1){
		for(i=0; i<idx_count; i++) {
			if((vlan_chcfg + i)->autodetect == 1) {
				strcpy(vlan_l2if, (vlan_chcfg + i)->l2ifName);
			}
		}
	}
#endif // 0 ]
#endif    
	if (!gstrcmp(name, T("WAN_VCList"))
	    || !gstrcmp(name, T("get_used_vcc"))) {
		i = 1;
		/* TBD: need to find type as IP/PPP then call appropriate macro and sections */
//#ifdef CONFIG_FEATURE_IFX_MULTIPLE_VCCS
		IFX_GET_WAN_SELECTED_INDEX(flags, outFlag, sValue, i, sWAN_TYPE)
//#endif
		    sprintf(sValue, "WAN%d_VCC", i);
		if (sWAN_TYPE == WAN_TYPE_IP) {
			snprintf(command,MAX_NAME_SIZE, "%s_%d_l2ifName", PREFIX_WAN_IP, i);
			ret =
			    ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, command,
					   flags, (IFX_OUT uint32 *) & outFlag,
					   sSelected_Value);
//                      IFX_DBG("[%s:%d] command [%s] sValue [%s]", __FUNCTION__, __LINE__, command, sSelected_Value);

			snprintf(command,MAX_NAME_SIZE, "%s_%d_pcpeId", PREFIX_WAN_IP, i);
			ret =
			    ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, command,
					   flags, (IFX_OUT uint32 *) & outFlag,
					   scpeId);
//                      IFX_DBG("[%s:%d] command [%s] sValue [%s]", __FUNCTION__, __LINE__, command, scpeId);
		} else {
			//v "wanppp_0_*" is reserved for CELL WAN, We are forbidding user to view CELLWAN's PPP info
#if defined(CONFIG_FEATURE_CELL_WAN_SUPPORT)
			if(i != 0){
#endif
			snprintf(command, MAX_NAME_SIZE,"%s_%d_l2ifName", PREFIX_WAN_PPP, i);
			ret =
			    ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, command,
					   flags, (IFX_OUT uint32 *) & outFlag,
					   sSelected_Value);
//                      IFX_DBG("[%s:%d] command [%s] sValue [%s]", __FUNCTION__, __LINE__, command, sSelected_Value);

			snprintf(command,MAX_NAME_SIZE, "%s_%d_pcpeId", PREFIX_WAN_PPP, i);
			ret =
			    ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, command,
					   flags, (IFX_OUT uint32 *) & outFlag,
					   scpeId);
//                      IFX_DBG("[%s:%d] command [%s] sValue [%s]", __FUNCTION__, __LINE__, command, scpeId);
#if defined(CONFIG_FEATURE_CELL_WAN_SUPPORT)
			}
#endif
		}
	} else if (!strcmp(name, "linkType")) {
#if 0
	      NOTE:when modify operation is supported we need to show existing link
		    type configuration
#endif				// 0
		    /* Write list of link types supported */
		    /* read link type of selected vc channel
		     * based on link type (read in linkType), write selected against appropriate option
		     */
		    ifx_httpdWrite(wp,
				   "<option value='%d'>LINK_TYPE_EOATM</option>",
				   LINK_TYPE_EOATM);
		ifx_httpdWrite(wp,
			       "<option value='%d'>LINK_TYPE_IPOATM</option>",
			       LINK_TYPE_IPOATM);
#ifdef CONFIG_PACKAGE_PPP_MOD_PPPOA
		ifx_httpdWrite(wp,
			       "<option value='%d'>LINK_TYPE_PPPOATM</option>",
			       LINK_TYPE_PPPOATM);
#endif				// CONFIG_PACKAGE_PPP_MOD_PPPOA
#ifdef CONFIG_FEATURE_CLIP
		ifx_httpdWrite(wp, "<option %d>LINK_TYPE_CLIP</option>",
			       LINK_TYPE_CLIP);
#endif				// CONFIG_FEATURE_CLIP
		goto IFX_Handler;
	} else if (!strcmp(name, "all_ch_types")) {

	} else if (gstrcmp(name, T("VCConfig_VCList")) != 0) {
		if (vpivci_selected[0] != '\0') {

			gsprintf(sValue, T("%s"), "\0");

			if (strstr(name, "QoSMode_") != NULL) {
				web_mode = name[strlen(name) - 1] - '0';
				switch (web_mode) {
				case 0:	// From WEB : UBR
					mode = ATM_QOS_UBR;
					break;
				case 1:	// From WEB : CBR
					mode = ATM_QOS_CBR;
					break;
				case 2:	// From WEB : NRT_VBR
					mode = ATM_QOS_NRT_VBR;
					break;
				case 3:	// From WEB : RT_VBR
					mode = ATM_QOS_RT_VBR;
					break;
				case 4:	// From WEB : UBR+
					mode = ATM_QOS_UBR_PLUS;
					break;
				default:
					mode = ATM_QOS_UBR;
				}
				sprintf(command, "%s", "QoSMode");
				// command = "QoSMode";
			}

			if (strstr(name, "CapMode_") != NULL) {
				mode = name[strlen(name) - 1] - '0';
				// command = "CapMode";
				sprintf(command, "%s", "CapMode");
			}

			if (ifx_get_all_vcc_info(&num, &vcc, flags) !=
			    IFX_SUCCESS) {
				ifx_httpdError(wp, 500, "Error");
				ret = FALSE;
				goto IFX_Handler;
			}

			if (num == 0) {	/* if no vc channels found, make default values selected */
				if (!gstrcmp(name, T("vcSetting")))
					ifx_httpdWrite(wp, T("0/32"));
				if (!gstrcmp(name, "CapMode_0")
				    || !gstrcmp(name, "QoSMode_0"))
					ifx_httpdWrite(wp, T("selected"));
			} else {
				if (mode != -1) {
					if ((ret =
					     ifx_get_vcc(vcc, num,
							 vpivci_selected,
							 command,
							 &sValue1)) !=
					    IFX_SUCCESS)
						goto IFX_Handler;
				} else {
					if ((ret =
					     ifx_get_vcc(vcc, num,
							 vpivci_selected, name,
							 &sValue1)) !=
					    IFX_SUCCESS)
						goto IFX_Handler;
				}

				if (mode != -1) {
					if (mode == sValue1)
						ifx_httpdWrite(wp,
							       T("selected"));
					else
						ifx_httpdWrite(wp, T(""));
				} else {
					if (!gstrcmp(name, T("vcSetting")))
						ifx_httpdWrite(wp, T("%s"),
							       vpivci_selected);
					else
						ifx_httpdWrite(wp, T("%d"),
							       sValue1);
				}
			}

			ret = IFX_SUCCESS;
			goto IFX_Handler;

		} else {

			if (!gstrcmp(name, T("CapMode")))
				ifx_httpdWrite(wp, T("0"));
			else if (!gstrcmp(name, T("vcSetting")))
				ifx_httpdWrite(wp, T("0/32"));
			else if (!gstrcmp(name, T("QoSMode")))
				ifx_httpdWrite(wp, T("0"));
			else
				ifx_httpdWrite(wp, T(""));

			ret = IFX_SUCCESS;
			goto IFX_Handler;
		}

	}

	if(mapi_get_all_vlan_ch_entries(&idx_count, &vlan_chcfg, flags) != IFX_SUCCESS) {
		ifx_httpdError(wp, 500, "Error");
                ret = FALSE;
                goto IFX_Handler;
	}

	if ( !gstrcmp(name,T("get_used_vcc"))) {

		if (ifx_get_sec_count(TAG_WAN_IP, &wanIpCnt) != IFX_SUCCESS) {
		}

		if (ifx_get_sec_count(TAG_WAN_PPP, &wanPppCnt) != IFX_SUCCESS) {
		}
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
		if(argc >= 2){
			if(config.auto_detect_L2 == 1){
				if(WanType == WAN_MODE_ATM){
					ifx_httpdWrite(wp, T("WANIP_VCCs[%d]=\"ATM : VC - AUTO, VLAN : None\";\n"),inx);
					ifx_httpdWrite(wp, T("WANPPP_VCCs[%d]=\"ATM : VC - AUTO, VLAN : None\";\n"),inx);
					inx = inx + 1;
				}
			}
			if((config.auto_detect_Vlan_ADSL_PTM == 1  && WanType == WAN_MODE_PTM) || (config.auto_detect_Vlan_VDSL_PTM == 1  && WanType == WAN_MODE_VDSL_PTM)) {
					ifx_httpdWrite(wp, T("WANIP_VCCs[%d]=\"PTM : VLAN - AUTO\";\n"),inx);
					ifx_httpdWrite(wp, T("WANPPP_VCCs[%d]=\"PTM : VLAN - AUTO\";\n"),inx);
					inx = inx + 1;
			} 
			if(config.auto_detect_Vlan_ETH1 == 1  && WanType == WAN_MODE_ETH1) {
					ifx_httpdWrite(wp, T("WANIP_VCCs[%d]=\"ETH1 : VLAN - AUTO\";\n"),inx);
					ifx_httpdWrite(wp, T("WANPPP_VCCs[%d]=\"ETH1 : VLAN - AUTO\";\n"),inx);
					inx = inx + 1;
			} 
			if(config.auto_detect_Vlan_ETH0 == 1 && WanType == WAN_MODE_ETH0) {
					ifx_httpdWrite(wp, T("WANIP_VCCs[%d]=\"ETH0 : VLAN - AUTO\";\n"),inx);
					ifx_httpdWrite(wp, T("WANPPP_VCCs[%d]=\"ETH0 : VLAN - AUTO\";\n"),inx);
					inx = inx + 1;
			} 
		}
#endif  

		for (i = 0; i < wanIpCnt; i++) {
			memset(sValue, 0x00, sizeof(sValue));

			snprintf(command,MAX_NAME_SIZE, "%s_%d_pcpeId", PREFIX_WAN_IP, i);
			if(GetObjData(FILE_RC_CONF, TAG_WAN_IP, command, sValue, IFX_F_DEFAULT) != IFX_SUCCESS) {

			}

			for(k=0; k<idx_count; k++) {
				if((vlan_chcfg + k)->iid.cpeId.Id == atoi(sValue)) {
					if(!strcmp((vlan_chcfg + k)->iid.pcpeId.secName, TAG_ADSL_VCCHANNEL)) {
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
						if((config.auto_detect_L2 == 1 && WanType == WAN_MODE_ATM) && (argc >= 2))
							continue;
#endif
						get_vcc_for_vlan_ch((vlan_chcfg + k)->iid.pcpeId, sWAN_VCC);
						if((vlan_chcfg + k)->vlanId == -1)
							ifx_httpdWrite(wp, T("WANIP_VCCs[%d]=\"ATM : VC - %s, VLAN : None\";\n"), i, sWAN_VCC);
						else
							ifx_httpdWrite(wp, T("WANIP_VCCs[%d]=\"ATM : VC - %s, VLAN : %d\";\n"), i, sWAN_VCC, (vlan_chcfg + k)->vlanId);
					}
					else if(!strcmp((vlan_chcfg + k)->iid.pcpeId.secName, TAG_PTM_CHANNEL)) {
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
						if(((config.auto_detect_Vlan_ADSL_PTM == 1 && WanType == WAN_MODE_PTM) || (config.auto_detect_Vlan_VDSL_PTM == 1 && WanType == WAN_MODE_VDSL_PTM)) && (argc >= 2))
							continue;
#endif
						if((vlan_chcfg + k)->vlanId == -1)
							ifx_httpdWrite(wp, T("WANIP_VCCs[%d]=\"PTM : VLAN - None\";\n"), i);
						else
							ifx_httpdWrite(wp, T("WANIP_VCCs[%d]=\"PTM : VLAN - %d\";\n"), i, (vlan_chcfg + k)->vlanId);
					}
					else if(!strcmp((vlan_chcfg + k)->iid.pcpeId.secName, TAG_ETH_CHANNEL)) {
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
						if(((config.auto_detect_Vlan_ETH1 == 1 && WanType == WAN_MODE_ETH1) || (config.auto_detect_Vlan_ETH0 == 1 && WanType == WAN_MODE_ETH0)) && (argc >= 2))
							continue;
#endif
						if(strstr((vlan_chcfg + k)->baseIf, "eth1")) {
							if((vlan_chcfg + k)->vlanId == -1)
								ifx_httpdWrite(wp, T("WANIP_VCCs[%d]=\"ETH (MII1) : VLAN - None\";\n"), i);
							else
								ifx_httpdWrite(wp, T("WANIP_VCCs[%d]=\"ETH (MII1) : VLAN - %d\";\n"), i, (vlan_chcfg + k)->vlanId);
						}
						else {
							if((vlan_chcfg + k)->vlanId == -1)
								ifx_httpdWrite(wp, T("WANIP_VCCs[%d]=\"ETH (MII0) : VLAN - None\";\n"), i);
							else
								ifx_httpdWrite(wp, T("WANIP_VCCs[%d]=\"ETH (MII0) : VLAN - %d\";\n"), i, (vlan_chcfg + k)->vlanId);
						}
        }
#ifdef CONFIG_FEATURE_WWAN_LTE_SUPPORT 
					else if (!strcmp((vlan_chcfg + k )->iid.pcpeId.secName,TAG_LTE_CHANNEL)){
                                               ifx_httpdWrite(wp,T("WANIP_VCCs[%d]=\"LTE\"\n"),i );
					}
#endif
					break;
				}
			}
		}


		//v "wanppp_0_*" is reserved for CELL WAN, We are forbidding user to view CELLWAN's PPP info
#if defined(CONFIG_FEATURE_CELL_WAN_SUPPORT)
		for (i = 1; i < wanPppCnt; i++) {
#else
		for (i = 0; i < wanPppCnt; i++) {
#endif
			memset(sValue, 0x00, sizeof(sValue));

			snprintf(command,MAX_NAME_SIZE, "%s_%d_pcpeId", PREFIX_WAN_PPP, i);
			if(GetObjData(FILE_RC_CONF, TAG_WAN_PPP, command, sValue, IFX_F_DEFAULT) != IFX_SUCCESS) {

			}

			for(k=0; k<idx_count; k++) {
				if((vlan_chcfg + k)->iid.cpeId.Id == atoi(sValue)) {
					if(!strcmp((vlan_chcfg + k)->iid.pcpeId.secName, TAG_ADSL_VCCHANNEL)) {
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
						if((config.auto_detect_L2 == 1 && WanType == WAN_MODE_ATM) && (argc >= 2))
							continue;
#endif   
						get_vcc_for_vlan_ch((vlan_chcfg + k)->iid.pcpeId, sWAN_VCC);
						if((vlan_chcfg + k)->vlanId == -1)
							ifx_httpdWrite(wp, T("WANPPP_VCCs[%d]=\"ATM : VC - %s, VLAN : None\";\n"), i, sWAN_VCC);
						else
							ifx_httpdWrite(wp, T("WANPPP_VCCs[%d]=\"ATM : VC - %s, VLAN : %d\";\n"), i, sWAN_VCC, (vlan_chcfg + k)->vlanId);
					}
					else if(!strcmp((vlan_chcfg + k)->iid.pcpeId.secName, TAG_PTM_CHANNEL)) {
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
							if(((config.auto_detect_Vlan_ADSL_PTM  == 1 && WanType == WAN_MODE_PTM) || (config.auto_detect_Vlan_VDSL_PTM == 1 && WanType == WAN_MODE_VDSL_PTM)) && (argc >= 2))
								continue;
#endif
						if((vlan_chcfg + k)->vlanId == -1)
							ifx_httpdWrite(wp, T("WANPPP_VCCs[%d]=\"PTM : VLAN - None\";\n"), i);
						else
							ifx_httpdWrite(wp, T("WANPPP_VCCs[%d]=\"PTM : VLAN - %d\";\n"), i, (vlan_chcfg + k)->vlanId);
					}
					else if(!strcmp((vlan_chcfg + k)->iid.pcpeId.secName, TAG_ETH_CHANNEL)) {
#ifdef CONFIG_FEATURE_WAN_AUTO_DETECT
							if(((config.auto_detect_Vlan_ETH1 == 1 && WanType == WAN_MODE_ETH1) || (config.auto_detect_Vlan_ETH0 == 1 && WanType == WAN_MODE_ETH0)) && (argc >= 2))
								continue;
#endif
						if(strstr((vlan_chcfg + k)->baseIf, "eth1")) {
							if((vlan_chcfg + k)->vlanId == -1)
								ifx_httpdWrite(wp, T("WANPPP_VCCs[%d]=\"ETH (MII1) : VLAN - None\";\n"), i);
							else
								ifx_httpdWrite(wp, T("WANPPP_VCCs[%d]=\"ETH (MII1) : VLAN - %d\";\n"), i, (vlan_chcfg + k)->vlanId);
						}
						else {
							if((vlan_chcfg + k)->vlanId == -1)
								ifx_httpdWrite(wp, T("WANPPP_VCCs[%d]=\"ETH (MII0) : VLAN - None\";\n"), i);
							else
								ifx_httpdWrite(wp, T("WANPPP_VCCs[%d]=\"ETH (MII0) : VLAN - %d\";\n"), i, (vlan_chcfg + k)->vlanId);
						}
					}
					break;
				}
			}
		}
		goto IFX_Handler;
	}

	else {
#ifdef IFX_LOG_DEBUG
IFX_DBG("[%s:%d]<----------------------------- vlan count-------------------------------> = %d", __FUNCTION__, __LINE__,idx_count);
#endif

		tmp_index = 0;
//v hide index 0 form wan_settings page
#if defined(CONFIG_FEATURE_CELL_WAN_SUPPORT)
		for (i=1;i<idx_count;i++) {
#else
		for (i=0;i<idx_count;i++) {
#endif
				if (!gstrcmp(name, "all_ch_types")) {
						/* Get link type for this VLAN channel entry */
						ifx_httpdWrite(wp, "LT_ARR[%d]=%d;",
										 tmp_index++, get_link_type_based_on_l2if((vlan_chcfg + i)->l2ifName));
				}
				else {

				memset(sWAN_VCC, 0x00, sizeof(sWAN_VCC));
				strncpy(sWAN_VCC, (vlan_chcfg+i)->l2ifName, MAX_NAME_SIZE-1);
                                sWAN_VCC[MAX_NAME_SIZE-1] = '\0';
#ifdef IFX_LOG_DEBUG
IFX_DBG("[%s:%d]<----------------------------- vlan l2ifName-------------------------------> = %s", __FUNCTION__, __LINE__,sWAN_VCC);
#endif
				memset(pcpe_Sec, 0x00, sizeof(pcpe_Sec));
                                strncpy(pcpe_Sec, (vlan_chcfg+i)->iid.pcpeId.secName, MAX_NAME_SIZE-1);
                                pcpe_Sec[MAX_NAME_SIZE-1] = '\0';
                      
#ifdef IFX_LOG_DEBUG
IFX_DBG("[%s:%d]<----------------------------- vlan pcpeSec-------------------------------> = %s", __FUNCTION__, __LINE__,pcpe_Sec);
#endif
		 if ( strstr(pcpe_Sec, "adsl") != NULL ) {
				if ( (gstrlen(sSelected_Value) == 0 && i == 0) || !gstrcmp(sWAN_VCC, sSelected_Value) ) {
					ifx_httpdWrite(wp, T("\t\t\t\t<option name=\"qos_atm_%d\" VALUE=\"%s\" selected >"),i, sWAN_VCC);
				}
				else {
					ifx_httpdWrite(wp, T("\t\t\t\t<option name=\"qos_atm_%d\" VALUE=\"%s\">"),i,sWAN_VCC);
				}
				ifx_httpdWrite(wp, T("%d. VCC : %s </option>\n"), tmp_index, sWAN_VCC);
				}
		else if ( strstr(pcpe_Sec, "ptm") != NULL ) {
				if ( (gstrlen(sSelected_Value) == 0 && i == 0) || !gstrcmp(sWAN_VCC, sSelected_Value) ) {
					ifx_httpdWrite(wp, T("\t\t\t\t<option name=\"qos_ptm_%d\" VALUE=\"%s\" selected >"),i,sWAN_VCC);
				}
				else{
					ifx_httpdWrite(wp, T("\t\t\t\t<option name=\"qos_ptm_%d\" VALUE=\"%s\">"),i,sWAN_VCC);
				}
				ifx_httpdWrite(wp, T("%d. %s </option>\n"),tmp_index,sWAN_VCC);
		}
#ifdef CONFIG_FEATURE_WWAN_LTE_SUPPORT
                else if ( strstr(pcpe_Sec,"lte") != NULL){
                           // do nothin                     
                }
#endif
		else {
				if ( (gstrlen(sSelected_Value) == 0 && i == 0) || !gstrcmp(sWAN_VCC, sSelected_Value) ) {
					ifx_httpdWrite(wp, T("\t\t\t\t<option name=\"qos_eth_%d\" VALUE=\"%s\" selected >"),i,sWAN_VCC);
				}else{
					ifx_httpdWrite(wp, T("\t\t\t\t<option name=\"qos_eth_%d\" VALUE=\"%s\">"),i,sWAN_VCC);
				}
				ifx_httpdWrite(wp, T("%d. %s </option>\n"),tmp_index,sWAN_VCC);
			}
				tmp_index++;
		}
		}

	}

      IFX_Handler:
	IFX_MEM_FREE(vlan_chcfg);
	IFX_MEM_FREE(vcc);
#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
	IFX_MEM_FREE(eth_cfg);
#endif
#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
	IFX_MEM_FREE(ptm_cfg);
#endif
	IFX_MEM_FREE(retVal);
	if (ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}

#ifdef CONFIG_FEATURE_IFX_IGMPPROXY
int ifx_get_wan_cfg(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_DATA_LEN];
	int nSelIdx = 1, i = 0;
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_APPLICATION_SERVER, T("IGMP_WAN_INTF"),
	     sValue) == 1) {
		nSelIdx = atoi(sValue);
	}
	for (i = 1; i <= MAX_VCCs; i++) {
		ifx_httpdWrite(wp,
			       T
			       ("document.write (\"<option value=\\\"%d\\\" %s>WAN%d</option>\");\n"),
			       i, i == nSelIdx ? "SELECTED" : " ", i);
	}
	return 0;

}
#endif

int ifx_get_VLANStatus(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_FILELINE_LEN];

	sValue[0] = '\0';
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_VLAN_BRIDGE, T("vb_enable"), sValue) == 1) {
		if (!gstrcmp(sValue, "1")) {
			gstrcpy(sValue, "1");
		} else {
			gstrcpy(sValue, "0");
		}
	}

	ifx_httpdWrite(wp, T("%s"), sValue);
	return 0;
}

int ifx_get_vlan_portmap(int eid, httpd_t wp, int argc, char_t ** argv)
{
	int i, j/*, vb_enable*/;
	int total_group = 0;
	char vlan_group[5 + 1][80];	// 1:default vlan group, 2-5: vlan group 2-5
	int wan_if_bridge_mode[MAX_VCCs + 5 + 1];	// 1-15:adsl port,16-19:lan port,20:wireless port
	char_t sValue[MAX_FILELINE_LEN];
	char group_title[128], group_member[128], tmp[128];
	/*if (ifx_GetCfgData(FILE_RC_CONF, TAG_VLAN_BRIDGE, "vb_enable", sValue)
	    == 0) {
		// error
		vb_enable = 0;
	} else {
		vb_enable = atoi(sValue);
	}*/
	if (ifx_GetCfgData
	    (FILE_RC_CONF, TAG_VLAN_BRIDGE_PB, "vb_pbvgs_groups",
	     sValue) == 0) {
		// error
	} else {
		char_t sChildName[MAX_FILELINE_LEN];
		char_t sChildValue[MAX_FILELINE_LEN];

		total_group = atoi(sValue);
		if ((total_group != 0) && (total_group < 32767)) {
			for (i = 1; i <= total_group; i++) {
				sChildName[0] = '\0';
				sChildValue[0] = '\0';
				gsprintf(sChildName, "vb_pbvgs_groups_%d", i);
				if (ifx_GetCfgData
				    (FILE_RC_CONF, TAG_VLAN_BRIDGE_PB,
				     sChildName, sChildValue) == 0) {
					// error
				} else {
					LTQ_STRNCPY(&vlan_group[i][0], sChildValue, 79);
                                        vlan_group[i][79] = '\0';
				}	// if
			}	// for
		}
	}

	for (i = 1; i <= MAX_VCCs; i++) {	// adsl port
		if (IP_BOOT_BRIDGE == GetWanMode(i)) {
			wan_if_bridge_mode[i] = 1;
		} else {
			wan_if_bridge_mode[i] = 0;
		}
	}
	for (i = 1; i <= 4; i++) {	// lan port
		wan_if_bridge_mode[MAX_VCCs + i] = 1;
	}
	wan_if_bridge_mode[MAX_VCCs + 5] = 0;	// wireless port

	if (wan_if_bridge_mode[i] == 1) {

	}
	// show title
	strcpy(group_title, "");
	strcpy(tmp, "");
	if (total_group > 0 && total_group < 32767) {
		for (i = 1; i <= total_group; i++) {	// lan port
			sprintf(tmp, "<td>Group%d</td>", i);
			LTQ_STRNCAT(group_title, tmp, sizeof(group_title));
		}
	}
	ifx_httpdWrite(wp, T("<tr><td>IF/group</td> %s</tr>"), group_title);

	// show interface
	for (i = 1; i < MAX_VCCs + 5; i++) {
		char ifname[16];

		strcpy(ifname, "");
		if (i >= 1 && i <= MAX_VCCs) {
			if (wan_if_bridge_mode[i] == 1) {
				sprintf(ifname, "nas%d", i);
			}
		}
		if (i > MAX_VCCs && i <= MAX_VCCs + 4) {
			if (wan_if_bridge_mode[i] == 1) {
				sprintf(ifname, "swport%d", i - MAX_VCCs - 1);
			}
		}
		if (i == MAX_VCCs + 5) {
			if (wan_if_bridge_mode[i] == 1) {
				sprintf(ifname, "wlan0");
			}
		}
		if (strcmp(ifname, "") != 0) {
			strcpy(group_member, "");
			for (j = 1; j <= total_group; j++) {
				if (vlan_group[j][(i - 1) * 2] == '1') {
					strcpy(tmp, "<td>*</td>");
				} else {
					strcpy(tmp, "<td> </td>");
				}
				LTQ_STRNCAT(group_title, tmp, sizeof(group_title));
				// strcat(group_member, tmp);
			}
			ifx_httpdWrite(wp, T("<tr><td>%s</td>%s</tr>"), ifname,
				       group_member);
		}
	}
	return 0;
}

void ifx_get_default_gw_interface(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_NAME_SIZE];
	if (ifx_GetCfgData
	    (FILE_RC_CONF, "default_wan_iface", "default_wan_conn_connName",
	     sValue) == 1) {
		ifx_httpdWrite(wp, T("%s"), sValue);
	} else {
		ifx_httpdWrite(wp, T("NOT FOUND"));
	}
	return;
}

void ifx_get_adsl_mode(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_NAME_SIZE];

	if (IFX_xDSL_MODE == xDSLGW) {
		sprintf(sValue, "%s", "xDSLGW");
		ifx_httpdWrite(wp, T("%s"), sValue);
	} else {
		sprintf(sValue, "%s", "xDSL Router");
		ifx_httpdWrite(wp, T("%s"), sValue);
	}
	return;
}

int ifx_get_dsl_api_config(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char_t sValue[MAX_FILELINE_LEN];
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_ADSL_PHY, "DSL_API_DEBUG", sValue)
	    == 1) {
		if (!gstrcmp(sValue, T("ENABLE"))) {
			ifx_httpdWrite(wp, T("%s"), "checked");
			sprintf(sValue, "%s", "xDSL Router");
		} else {
			ifx_httpdWrite(wp, T("%s"), "");
		}
	} else {
		ifx_httpdWrite(wp, T("%s"), "");
	}

	return 0;
}

void ifx_get_error_msg(int eid, httpd_t wp, int argc, char_t ** argv)
{
	if (status_str != NULL)
		ifx_httpdWrite(wp, T("%s"), status_str);
	IFX_MEM_FREE(status_str)
}

void ifx_get_plat_name(int eid, httpd_t wp, int argc, char_t ** argv)
{
	ifx_httpdWrite(wp, T("%s&trade; %s"), "XWAY", PLAT_NAME);
}

void ifx_dsl_api_config(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pDSL_API_DEBUG_VALUE, DSL_API_DEBUG[MAX_FILELINE_LEN];

	pDSL_API_DEBUG_VALUE = ifx_httpdGetVar(wp, T("DSL_API_DEBUG"), T(""));

	if (!gstrcmp(pDSL_API_DEBUG_VALUE, T("ENABLE"))) {
		gsprintf(DSL_API_DEBUG, T("DSL_API_DEBUG=\"%s\"\n"),
			 pDSL_API_DEBUG_VALUE);
		ifx_SetCfgData(FILE_RC_CONF, TAG_ADSL_PHY, 1, DSL_API_DEBUG);
	} else {
		gsprintf(DSL_API_DEBUG, T("DSL_API_DEBUG=\"%s\"\n"), "DISABLE");
		ifx_SetCfgData(FILE_RC_CONF, TAG_ADSL_PHY, 1, DSL_API_DEBUG);
	}

	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}

	ifx_httpdWrite(wp, T("System will reboot, please wait ... "));
	system("/etc/rc.d/rebootcpe.sh 5 &");

}

#ifdef LTQ_BKUP_RESTR_SIGNATURE
static int upgrFacRestor;
void ltq_set_system_upgrade_confirm( httpd_t wp, char_t *path, char_t *query)
{

   char *pUpgrade = ifx_httpdGetVar(wp,T("Upgrade"),T(""));
   int upgrade, ret;
   
   upgrade = atoi(pUpgrade);

   if (upgrade == 0 ){
       ifx_httpdRedirect(wp,"sysconfig_update.asp");
       return;
   }else if ( upgrade == 1 ){
	ret = ifx_mapi_restore_config( upgrFacRestor,IFX_F_DEFAULT);
        upgrFacRestor = 0;
	switch(ret) {
		case 0:
			ifx_httpdWrite(wp,
			       ("<center><h3> Configuration file restore succeeded. System will now restart.\n Please don't turn off the Amazon system before the process is complete.<br></h3></center>"));
			break;
		case -1:
			ifx_httpdWrite(wp,
			       ("<center><h3> Configuration file restore encountered errors. Restore aborted. System will now restart.\n Please don't turn off the Amazon system before the process is complete.<br></h3></center>"));
			break;
		case -2:
			COPY_TO_STATUS
			    ("<span class=\"textTitle\"> Configuration file Format is Invalid .</span><br><p> Restore process aborted </p><br>\n");
			ifx_httpdRedirect(wp, T("err_page.html"));
			goto IFX_Handler;
			break;
		case -3:
			COPY_TO_STATUS
			    ("<span class=\"textTitle\"> Configuration file Format is Corrupted .</span><br><p> Restore process aborted </p><br>\n");
			ifx_httpdRedirect(wp, T("err_page.html"));
			goto IFX_Handler;
			break;
		case -4:
			COPY_TO_STATUS
			    ("<span class=\"textTitle\"> Insufficient memory. </span><br><p> Restore process aborted </p><br>\n");
			ifx_httpdRedirect(wp, T("err_page.html"));
			goto IFX_Handler;
			break;
		case -5:
			COPY_TO_STATUS
			    ("<span class=\"textTitle\"> Configuration file Format is Invalid .</span><br><p> Restore process aborted </p><br>\n");
			ifx_httpdRedirect(wp, T("err_page.html"));
			goto IFX_Handler;
			break;

	}

	system("/etc/rc.d/backup");
	reboot_status = 3;
	ifx_httpdRedirect(wp, "reboot_cpe.html");
	system("/etc/rc.d/rebootcpe.sh 5 &");
IFX_Handler:
	IFX_DBG("Configuration file restore aborted \n");
   }
} 
#endif

void ifx_set_sysconfig_upgrade(httpd_t wp, char_t * path, char_t * query)
{
	int nWrite = 0/*, nBlen = 0*/;
	int ret = 0;
	int fh = 0;

	char pCheck[20];
	int i = 0;
	struct ifx_arg_list *pArgList = NULL;
	int iTotalSize = 0;
	int iMaxFileSizeAllowed = 0;
	int iMinFileSizeAllowed = 0;
#ifdef LTQ_BKUP_RESTR_SIGNATURE
        char model[256];
#endif
	uint32 flags = IFX_F_DEFAULT;

	memset(pCheck, 0, sizeof(pCheck));

	iMaxFileSizeAllowed = CONFIG_UBOOT_CONFIG_IFX_MEMORY_SIZE * 1024;

/*       if(CONFIG_IFX_CONFIG_FLASH_SIZE == 2)
		iMaxFileSizeAllowed = 16*1024; // max size allowed for download need to move to header file
        if(CONFIG_IFX_CONFIG_FLASH_SIZE == 4)
		iMaxFileSizeAllowed = 32*1024; // max size allowed for download need to move to header file
        if(CONFIG_IFX_CONFIG_FLASH_SIZE == 8)
		iMaxFileSizeAllowed = 32*1024; // max size allowed for download need to move to header file
*/

#ifndef CONFIG_FEATURE_SELECTIVE_BACKUP_RESTORE
	iMinFileSizeAllowed = 3 * 1024;	// max size allowed for download need to move to header file
#endif

	pArgList = wp->ifx_ptr_arg_list;
	for (i = 0; i < wp->ifx_no_argument && pArgList;
	     i++, pArgList = pArgList->next) {
		if (strncmp
		    (pArgList->pifx_param_name, "factoryUpdate",
		     strlen("factoryUpdate")) == 0) {
			sprintf(pCheck, "%s", pArgList->ifx_param_value.buf);
			break;
		}
	}
	pArgList = wp->ifx_ptr_arg_list;
	for (i = 0; i < wp->ifx_no_argument && pArgList;
	     i++, pArgList = pArgList->next) {
		if (strncmp
		    (pArgList->pifx_param_name, "SysconfigUpload",
		     strlen("SysconfigUpload")) == 0)
			break;
	}
	if (pArgList == NULL) {
		ifx_httpdError(wp, 500, T("Cannot find variable webUpload."));
		return;
	}
	IFX_DBG("ifx_set_sysconfig_upgrade : variable webUpload found\n");

#ifndef HOSTENV
	fh = open("/tmp/sysconf.gz", O_RDWR | O_BINARY | O_CREAT);	// ASSUME FILE_RC_CONFIG = /tmp/syscon
#else
	fh = open("/tmp/sysconf.gz", O_RDWR | O_BINARY | O_CREAT, (S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH));	// ASSUME FILE_RC_CONFIG = /tmp/syscon
#endif
	if (fh == -1) {
		ifx_httpdError(wp, 500, T("Cannot open %s file"),
			       "/tmp/syscon.gz");
		close(fh);
		return;
	} else {
#ifdef IFX_LOG_DEBUG
		IFX_DBG
		    ("###In sysconfig_upgrade: writing into file totBufLen [%d : %d ]\n",
		     pArgList->totBufLen, pArgList->numMultiBufs);
#endif
//		nBlen = pArgList->totBufLen;

		i = 0;
		if (pArgList->numMultiBufs != 0) {
			while (i < pArgList->numMultiBufs) {
				nWrite =
				    pArgList->ifx_param_value.pArrMultiBuf[i].
				    len;
				iTotalSize += nWrite;
				if ((iTotalSize > iMaxFileSizeAllowed)
				    || (iTotalSize < iMinFileSizeAllowed)) {
					ifx_httpdError(wp, 500,
						       T
						       ("Incorrect configuration file.<br>File size greater than expected<br>\n"));
#ifdef IFX_LOG_DEBUG
					IFX_DBG
					    ("Incorrect configuration file. File size greater than expected<br>\n");
#endif
					close(fh);
					system("/etc/rc.d/rebootcpe.sh 5 &");
					return;
				}

				ret =
				    write(fh,
					  pArgList->ifx_param_value.
					  pArrMultiBuf[i].buf, nWrite);
				IFX_FREE(pArgList->ifx_param_value.
					 pArrMultiBuf[i].buf);
				pArgList->ifx_param_value.pArrMultiBuf[i].buf =
				    NULL;

				if (ret < nWrite) {
					ifx_httpdError(wp, 500,
						       T
						       ("File write failed.<br> ret = %d while nWrite = %d\n"),
						       ret, nWrite);
					close(fh);
					return;
				}
				i++;
			}

		} else {
			nWrite = pArgList->totBufLen;

			iTotalSize += nWrite;
			if ((iTotalSize > iMaxFileSizeAllowed)
			    || (iTotalSize < iMinFileSizeAllowed)) {
				ifx_httpdError(wp, 500,
					       T
					       ("Incorrect configuration file.<br>File size greater than expected<br>\n"));
#ifdef IFX_LOG_DEBUG
				IFX_DBG
				    ("Incorrect configuration file. File size greater than expected<br>\n");
#endif
				close(fh);
				system("/etc/rc.d/rebootcpe.sh 5 &");
				return;
			}

			ret = write(fh, pArgList->ifx_param_value.buf, nWrite);
			IFX_FREE(pArgList->ifx_param_value.buf);
			pArgList->ifx_param_value.buf = NULL;
			if (ret < nWrite) {
				ifx_httpdError(wp, 500,
					       T
					       ("File write failed.<br> ret = %d while nWrite = %d\n"),
					       ret, nWrite);
				close(fh);
				return;
			}

		}
#ifdef IFX_LOG_DEBUG
		IFX_DBG("###outside  [%d]\n", nWrite);
		ifx_debug_printf("###sysconfig_upgrade : closing the file\n");
#endif
		close(fh);
	}


	/***********************************************/
	/* Subramani - We need to call the backup script
	   so that SSL Certificate is gziped along with rc.conf */

/*      system("gzip /tmp/sysconf");

        system("/usr/sbin/upgrade /tmp/sysconf.gz sysconfig 0 0 ");
*/

	system("rm -f /tmp/rc.conf.gz");
	//system("chmod 777 /tmp/sysconf /flash/rc.conf");
	//system("cp -f /tmp/sysconf /flash/rc.conf > /tmp/log 2> /tmp/err_log");

#if 0
		if (!rename("/tmp/sysconf", "/flash/rc.conf")) {
			IFX_DBG("Copy rc.conf Success\n");

		} else {
			IFX_DBG("Copy rc.conf Fail\n");
		}
#endif

#ifdef LTQ_BKUP_RESTR_SIGNATURE
        ret = ltq_mapi_restore_config_verify( "/tmp/rc.conf.gz", model );
        if (ret == -1 ){
            int upgrFacRestor;
            upgrFacRestor= atoi(pCheck);
            ifx_httpdRedirect( wp,T("sysconfig_upgrade_verify.htm"));
            goto IFX_Handler;
        }
#endif
	ret = ifx_mapi_restore_config(atoi(pCheck), flags);
	switch(ret) {
		case 0:
			ifx_httpdWrite(wp,
			       ("<center><h3> Configuration file restore succeeded. System will now restart.\n Please don't turn off the Amazon system before the process is complete.<br></h3></center>"));
			break;
		case -1:
			ifx_httpdWrite(wp,
			       ("<center><h3> Configuration file restore encountered errors. Restore aborted. System will now restart.\n Please don't turn off the Amazon system before the process is complete.<br></h3></center>"));
			break;
		case -2:
			COPY_TO_STATUS
			    ("<span class=\"textTitle\"> Configuration file Format is Invalid .</span><br><p> Restore process aborted </p><br>\n");
			ifx_httpdRedirect(wp, T("err_page.html"));
			goto IFX_Handler;
			break;
		case -3:
			COPY_TO_STATUS
			    ("<span class=\"textTitle\"> Configuration file Format is Corrupted .</span><br><p> Restore process aborted </p><br>\n");
			ifx_httpdRedirect(wp, T("err_page.html"));
			goto IFX_Handler;
			break;
		case -4:
			COPY_TO_STATUS
			    ("<span class=\"textTitle\"> Insufficient memory. </span><br><p> Restore process aborted </p><br>\n");
			ifx_httpdRedirect(wp, T("err_page.html"));
			goto IFX_Handler;
			break;
		case -5:
			COPY_TO_STATUS
			    ("<span class=\"textTitle\"> Configuration file Format is Invalid .</span><br><p> Restore process aborted </p><br>\n");
			ifx_httpdRedirect(wp, T("err_page.html"));
			goto IFX_Handler;
			break;

	}

	system("/etc/rc.d/backup");
	reboot_status = 3;
	ifx_httpdRedirect(wp, "reboot_cpe.html");
	system("/etc/rc.d/rebootcpe.sh 5 &");
IFX_Handler:
	IFX_DBG("Configuration file restore aborted \n");

}

// 512261:jelly:start
void ifx_set_vlan_main(httpd_t wp, char_t * path, char_t * query)
{
	char_t *pCheck, sCheck[MAX_FILELINE_LEN];

	a_assert(wp);
	memset(sCheck, 0x00, sizeof(sCheck));

	// Get value from ASP filz
	pCheck = ifx_httpdGetVar(wp, T("VLANStatus"), T(""));

	if (!gstrcmp(pCheck, "1")) {
		gsprintf(sCheck, T("vb_enable=\"1\"\n"));
	} else {
		gsprintf(sCheck, T("vb_enable=\"0\"\n"));
	}

	ifx_SetCfgData(FILE_RC_CONF, TAG_VLAN_BRIDGE, 1, sCheck);

	// save setting
	if (ifx_flash_write() <= 0) {
		ifx_httpdError(wp, 500, "Fail to save Setting");
		return;
	}

	websNextPage(wp);
}

//512261:jelly:end
int ifx_get_supported_wan_cfg_mode(int eid, httpd_t wp, int argc,
				   char_t ** argv)
{
#if defined(CONFIG_FEATURE_ADSL_WAN_SUPPORT) && defined(CONFIG_FEATURE_ETH_WAN_SUPPORT) && defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
	ifx_httpdWrite(wp, T("%s"), "ALL");
#elif defined(CONFIG_FEATURE_ADSL_WAN_SUPPORT)
	ifx_httpdWrite(wp, T("%s"), "ADSL");
#elif defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
	ifx_httpdWrite(wp, T("%s"), "ETH");
#elif defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
	ifx_httpdWrite(wp, T("%s"), "PTM");
#endif
	return IFX_SUCCESS;
}

int ifx_get_platform_name(int eid, httpd_t wp, int argc, char_t ** argv)
{
#if defined PLATFORM_DANUBE
	ifx_httpdWrite(wp, T("DANUBE"));
#elif defined PLATFORM_AR10
	#if defined PLATFORM_AR10_VRX318
		ifx_httpdWrite(wp, T("VR9"));
	#else 
		ifx_httpdWrite(wp, T("AR10"));
	#endif
#elif defined PLATFORM_AR9 && !defined(CONFIG_FEATURE_ADSL_WAN_SUPPORT)
#if defined PLATFORM_VB300
	ifx_httpdWrite(wp, T("VBX"));
#else
	ifx_httpdWrite(wp, T("GR9"));
#endif
#elif defined PLATFORM_AR9
	ifx_httpdWrite(wp, T("AR9"));
#elif defined PLATFORM_VB300
	ifx_httpdWrite(wp, T("VBX"));
#elif defined PLATFORM_VBG400
	ifx_httpdWrite(wp, T("VBX"));
#elif defined PLATFORM_AMAZON_SE
	ifx_httpdWrite(wp, T("AMAZON_SE"));
#elif defined PLATFORM_GR9
	ifx_httpdWrite(wp, T("GR9"));
#elif defined PLATFORM_VR9
	ifx_httpdWrite(wp, T("VR9"));
#endif
	return IFX_SUCCESS;
}

int ifx_get_usb_support_type(int eid, httpd_t wp, int argc, char_t ** argv)
{
#if defined(CONFIG_FEATURE_IFX_USB_HOST) && defined(CONFIG_FEATURE_IFX_USB_DEVICE)
	ifx_httpdWrite(wp, T("usb_multi_mode"));
#elif defined(CONFIG_FEATURE_IFX_USB_HOST)
	ifx_httpdWrite(wp, T("usb_host_mode"));
#elif defined(CONFIG_FEATURE_IFX_USB_DEVICE)
	ifx_httpdWrite(wp, T("usb_device_mode"));
#else
	ifx_httpdWrite(wp, T("usb_disabled_mode"));
#endif
	return IFX_SUCCESS;
}

int ifx_get_supported_wan_cfg_modes(int eid, httpd_t wp, int argc,
				    char_t ** argv)
{

	char_t sBuf[BUF_SIZE_1K];
	sBuf[0] = '\0';
#if defined(CONFIG_FEATURE_ADSL_ATM_WAN_SUPPORT)
	strcat(sBuf,"ADSLATM/");
#endif
#if defined(CONFIG_FEATURE_VDSL_ATM_WAN_SUPPORT)
	strcat(sBuf,"VDSLATM/");
#endif
#if defined(CONFIG_FEATURE_ADSL_PTM_WAN_SUPPORT)
	strcat(sBuf,"ADSLPTM/");
#endif
#if defined(CONFIG_FEATURE_VDSL_PTM_WAN_SUPPORT) 
	strcat(sBuf,"VDSLPTM/");
#endif
#if defined(CONFIG_FEATURE_ETH_WAN_MII0_SUPPORT)
	strcat(sBuf,"MII0/");
#endif
#if defined(CONFIG_FEATURE_ETH_WAN_MII1_SUPPORT)
	strcat(sBuf,"MII1/");
#endif
	ifx_httpdWrite(wp, T("%s"), sBuf);
	return IFX_SUCCESS;
}

#if defined(CONFIG_FEATURE_CELL_WAN_SUPPORT)
int ltq_cell_wan_support(int eid, httpd_t wp, int argc, char_t ** argv)
{

#if defined(CONFIG_FEATURE_CELL_WAN_SUPPORT)
	ifx_httpdWrite(wp, T("ENABLED"));
#else
	ifx_httpdWrite(wp, T("DISABLED"));
#endif
	return IFX_SUCCESS;
}
#endif

int ltq_wwan_lte_support(int eid, httpd_t wp, int argc, char_t ** argv)
{
#if defined(CONFIG_FEATURE_WWAN_LTE_SUPPORT)
	ifx_httpdWrite(wp, T("ENABLED"));
#else
	ifx_httpdWrite(wp, T("DISABLED"));
#endif
	return IFX_SUCCESS;
}

int ltq_samba_support(int eid, httpd_t wp, int argc, char_t ** argv)
{
#if defined(CONFIG_FEATURE_SAMBA)
	ifx_httpdWrite(wp, T("ENABLED"));
#else
	ifx_httpdWrite(wp, T("DISABLED"));
#endif
	return IFX_SUCCESS;
}

int ifx_get_supported_wan_phy_tc_modes(int eid, httpd_t wp, int argc,
				       char_t ** argv)
{

#if defined(CONFIG_FEATURE_ADSL_WAN_SUPPORT) && defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
	ifx_httpdWrite(wp, T("ALL"));
#elif defined(CONFIG_FEATURE_ADSL_ATM_WAN_SUPPORT)
	ifx_httpdWrite(wp, T("ATM"));
#elif defined(CONFIG_FEATURE_ADSL_PTM_WAN_SUPPORT)
	ifx_httpdWrite(wp, T("PTM"));
#elif defined(CONFIG_FEATURE_VDSL_PTM_WAN_SUPPORT)
	ifx_httpdWrite(wp, T("PTM"));
#endif
	return IFX_SUCCESS;

}

int ifx_get_wan_eth_mii0_info(int eid, httpd_t wp, int argc, char_t ** argv)
{
	char *name = NULL;
#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT) || defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
	char sValue[4];
	uint32 outFlag = IFX_F_DEFAULT;

	memset(sValue, 0x00, sizeof(sValue));
#endif

	if (ifx_httpd_parse_args(argc, argv, T("%s"), &name) < 1) {
		ifx_httpdError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	if (!gstrcmp(name, "vlan_en")) {
#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT) && !defined(PLATFORM_VR9)
		if (ifx_GetObjData
		    (FILE_RC_CONF, "wan_phy_cfg", "wanphy_ethVlanMode",
		     IFX_F_GET_ANY, (IFX_OUT uint32 *) & outFlag,
		     sValue) != IFX_SUCCESS) {
			ifx_httpdWrite(wp, "");
		} else {
			ifx_httpdWrite(wp, T("%d"), atoi(sValue) == 1 ? 0 : 1);
		}
#else
		ifx_httpdWrite(wp, T("%d"), 0);
#endif
	}

	if (!gstrcmp(name, "mii1_vlan_en")) {
#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT) && !defined(PLATFORM_DANUBE)
		if (ifx_GetObjData
		    (FILE_RC_CONF, "wan_phy_cfg", "wanphy_mii1ethVlanMode",
		     IFX_F_GET_ANY, (IFX_OUT uint32 *) & outFlag,
		     sValue) != IFX_SUCCESS) {
			ifx_httpdWrite(wp, "");
		} else {
			ifx_httpdWrite(wp, T("%d"), atoi(sValue) == 1 ? 0 : 1);
		}
#else
		ifx_httpdWrite(wp, T("%d"), 0);
#endif
	}

	if (!gstrcmp(name, "ptm_vlan_en")) {
#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
		if (ifx_GetObjData
		    (FILE_RC_CONF, "wan_phy_cfg", "wanphy_ptmVlanMode",
		     IFX_F_GET_ANY, (IFX_OUT uint32 *) & outFlag,
		     sValue) != IFX_SUCCESS) {
			ifx_httpdWrite(wp, "");
		} else {
			ifx_httpdWrite(wp, T("%d"), atoi(sValue) == 1 ? 0 : 1);
		}
#else
		ifx_httpdWrite(wp, T("%d"), 0);
#endif
	}
	return 0;
}
int ifx_get_status_message(int eid, httpd_t wp, int argc, char_t ** arg_v)
{

	ifx_httpdWrite(wp, T("%d"), reboot_status);
	return 0;
}

void ifx_get_wan_count_interface(int eid, httpd_t wp, int argc, char_t ** argv)
{

	char_t sValue[14];
	uint32 outFlag = IFX_F_DEFAULT;
	sValue[0] = '\0';
	if (ifx_GetObjData
	    (FILE_RC_CONF, "wan_main", "wan_main_index", IFX_F_DEFAULT,
	     (IFX_OUT uint32 *) & outFlag, sValue) != IFX_SUCCESS) {

		return;
	}
	sValue[strlen(sValue) - 1] = '\0';
//                                ifx_httpdWrite(wp, T("%s"), svalue[strlen(svalue)-1]);
	ifx_httpdWrite(wp, T("%s"), sValue);

}
int ltq_cgi_l2channel_list(int eid, httpd_t wp, int argc, char_t **argv)
{
#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT) || defined(CONFIG_FEATURE_PTM_WAN_SUPPORT) || defined(CONFIG_FEATURE_ADSL_WAN_SUPPORT)
//	char8	sValue[MAX_FILELINE_LEN];
	char8	sSelected_Value[10]/* sEncap[MAX_NAME_SIZE],scpeId[10]*/;
	char8	sWAN_VCC[MAX_NAME_SIZE];/* pcpe_Sec[MAX_NAME_SIZE], *retVal = NULL; */
	int     ret = IFX_SUCCESS, i = 0,num =0, index=1;
	#if defined(CONFIG_PACKAGE_IFX_DSL_CPE_API) || defined(CONFIG_FEATURE_ETH_WAN_SUPPORT) || defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
	//uint32 tmp_index = 0;
	#endif
	#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
	//int     Encp_mode = 0, QoS_mode = 0;
	//uint32 tmp_index = 0;
	#endif
	/* Dummy channel counters for ATM & ETH WAN Modes */
	//#if defined(CONFIG_PACKAGE_IFX_DSL_CPE_API) || defined(CONFIG_FEATURE_ETH_WAN_SUPPORT) || defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
	//uint32 uTemp=0;
	//#endif
	uint32	flags = IFX_F_DEFAULT;
//	uint32 tmp_index = 0;
//	VLAN_CH_CFG *vlan_chcfg = NULL;
	#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
	ETH_CH_CFG *eth_cfg = NULL;
	#endif
	#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
	PTM_CH_CFG *ptm_cfg = NULL;
	#endif
	#if defined(CONFIG_FEATURE_ADSL_WAN_SUPPORT)
	ATM_VCC_INFO    *vcc = NULL;
	#endif
//	sValue[0]='\0';
	sSelected_Value[0]='\0';
//	scpeId[0]='\0';
//	sEncap[0]='\0';


/*		if (ifx_GetObjData(FILE_RC_CONF, "wan_phy_cfg", "wanphy_phymode", IFX_F_GET_ANY, (IFX_OUT uint32 *) &outFlag, sValue) != IFX_SUCCESS) {// Get Global mode
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Failed to obtain global mode", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;

		}
		else {
			phy_mode=atoi(sValue);//Global Mode
		}

		if (ifx_GetObjData(FILE_RC_CONF, "wan_phy_cfg", "wanphy_tc", IFX_F_GET_ANY, (IFX_OUT uint32 *) &outFlag, sValue) != IFX_SUCCESS) {// Get TC value
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Failed to obtain global mode", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;

		}
		else {
			phy_tc=atoi(sValue);//TC
		}
#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
		if (ifx_GetObjData(FILE_RC_CONF, "wan_phy_cfg", "wanphy_ptmVlanMode", IFX_F_GET_ANY, (IFX_OUT uint32 *) &outFlag, sValue) !=  IFX_SUCCESS) {// Get PTM VLAN Support Mode
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Failed to obtain MII1 VLAN mode", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;

		}
		else {
			ptm_vlan_mode=atoi(sValue);//PTM VLAN Support Mode
		}
#endif */

		i=0;

	/*	if(mapi_get_all_vlan_ch_entries(&idx_count, &vlan_chcfg, flags) != IFX_SUCCESS) {
			ifx_httpdError(wp, 500, "Error");
                        ret = FALSE;
                        goto IFX_Handler;
		}*/


	//	IFX_DBG("[%s:%d]<----------------------------- vlan count-------------------------------> = %d", __FUNCTION__, __LINE__,idx_count);

#if defined(CONFIG_FEATURE_ADSL_WAN_SUPPORT)
		if (ifx_get_all_vcc_info(&num, &vcc, flags) != IFX_SUCCESS) {
                        ifx_httpdError(wp, 500, "Error");
                        ret = FALSE;
                        goto IFX_Handler;
                }
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]<----------------------------- vlan count-------------------------------> = %d", __FUNCTION__, __LINE__,num);
#endif
		for (i=0;i<num;i++) {

                                memset(sWAN_VCC, 0x00, sizeof(sWAN_VCC));
                                strncpy(sWAN_VCC, (vcc+i)->l2ifname, MAX_NAME_SIZE - 1);
                                sWAN_VCC[MAX_NAME_SIZE - 1] = '\0';
			/* For modify operations sSelected_Value will hold l2ifname of selected channel */
			if ( (gstrlen(sSelected_Value) == 0 && i == 0) || !gstrcmp(sWAN_VCC, sSelected_Value) )
                                        ifx_httpdWrite(wp, T("\t\t\t\t<option name=\"qos_atm_%d\" VALUE=\"%s\" selected >"),i, sWAN_VCC);
                                else
                                        ifx_httpdWrite(wp, T("\t\t\t\t<option name=\"qos_atm_%d\" VALUE=\"%s\">"),i,sWAN_VCC);
                                ifx_httpdWrite(wp, T("%d. VCC : %s </option>\n"), index, sWAN_VCC);
				index++;
		}
#endif

	#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
		 if (ifx_get_all_eth_info(&num, &eth_cfg, flags) != IFX_SUCCESS) {
                        ifx_httpdError(wp, 500, "Error");
                        ret = FALSE;
                        goto IFX_Handler;
                }
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]<----------------------------- vlan count-------------------------------> = %d", __FUNCTION__, __LINE__,num);
#endif
		for (i=0;i<num;i++) {

				memset(sWAN_VCC, 0x00, sizeof(sWAN_VCC));
				strncpy(sWAN_VCC, (eth_cfg+i)->l2ifname, MAX_NAME_SIZE -1);		
                                sWAN_VCC[MAX_NAME_SIZE -1 ] = '\0';

				/* For modify operations sSelected_Value will hold l2ifname of selected channel */
				if ( (gstrlen(sSelected_Value) == 0 && i == 0) || !gstrcmp(sWAN_VCC, sSelected_Value) ){
					ifx_httpdWrite(wp, T("\t\t\t\t<option name=\"qos_eth_%d\" VALUE=\"%s\" selected >"),i,sWAN_VCC);
				}else{
					ifx_httpdWrite(wp, T("\t\t\t\t<option name=\"qos_eth_%d\" VALUE=\"%s\">"),i,sWAN_VCC);
				}
				ifx_httpdWrite(wp, T("%d. %s : %d </option>\n"),index,(eth_cfg+i)->l2ifname,(eth_cfg+i)->vlanId);
				index++;

		}
	#endif

	#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
		if (ifx_get_all_ptm_info(&num, &ptm_cfg, flags) != IFX_SUCCESS) {
                        ifx_httpdError(wp, 500, "Error");
                        ret = FALSE;
                        goto IFX_Handler;
                }
		for (i=0;i<num;i++) {

                                memset(sWAN_VCC, 0x00, sizeof(sWAN_VCC));
                                strncpy(sWAN_VCC, (ptm_cfg+i)->l2ifname, MAX_NAME_SIZE-1);
                                sWAN_VCC[MAX_NAME_SIZE-1] = '\0';

				/* For modify operations sSelected_Value will hold l2ifname of selected channel */
				if ( (gstrlen(sSelected_Value) == 0 && i == 0) || !gstrcmp(sWAN_VCC, sSelected_Value) )
                                        ifx_httpdWrite(wp, T("\t\t\t\t<option name=\"qos_atm_%d\" VALUE=\"%s\" selected >"),i, sWAN_VCC);
                                else
                                        ifx_httpdWrite(wp, T("\t\t\t\t<option name=\"qos_atm_%d\" VALUE=\"%s\">"),i,sWAN_VCC);
                                ifx_httpdWrite(wp, T("%d. PTM : %d </option>\n"), index, (ptm_cfg+i)->vlanId);
				index++;

		}
	#endif

IFX_Handler:
#if defined(CONFIG_FEATURE_ADSL_WAN_SUPPORT)
		IFX_MEM_FREE(vcc)
#endif
#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
		IFX_MEM_FREE(eth_cfg)
#endif
#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
		IFX_MEM_FREE(ptm_cfg)
#endif
                if (ret != IFX_SUCCESS)
                        return ret;
                else
                        return IFX_SUCCESS;
#else
	return IFX_SUCCESS;
#endif
}
